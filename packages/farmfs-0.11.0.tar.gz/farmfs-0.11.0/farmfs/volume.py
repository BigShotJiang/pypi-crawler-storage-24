from collections.abc import Callable
from errno import ENOENT as NoSuchFile
from farmfs.keydb import BlobKeyDB, JsonKeyDB
from farmfs.keydb import KeyDBWindow
from farmfs.keydb import KeyDBFactory
from farmfs.blobstore import FileBlobstore, ReverserFunction
from farmfs.util import (
    partial,
    ingest,
    fmap,
    pipeline,
    ffilter,
    concat,
    uncurry,
    uniq,
    jaccard_similarity,
)
from farmfs.fs import ensure_symlink, Path, ROOT
from farmfs.fs import (
    ensure_absent,
    ensure_dir,
    ignored_path_checker,
    ftype_selector,
    FILE,
    LINK,
    DIR,
    walk,
    walk_path
)
from farmfs.snapshot import TreeSnapshot, KeySnapshot, SnapDelta, Snapshot, SnapshotItem, SnapItemTypes
from itertools import chain
from json import loads
from typing import Dict, Generator, Iterator, List, Optional, Tuple, TypedDict


def _metadata_path(root: Path) -> Path:
    assert isinstance(root, Path)
    return root.join(".farmfs")


def _keys_path(root: Path) -> Path:
    return _metadata_path(root).join("keys")


def _tmp_path(root: Path) -> Path:
    return _metadata_path(root).join("tmp")


def _snaps_path(root: Path) -> Path:
    return _metadata_path(root).join("snaps")


def _locks_path(root: Path) -> Path:
    return _metadata_path(root).join("locks")


def mkfs(root: Path, udd: Path):
    assert isinstance(root, Path)
    assert isinstance(udd, Path)
    root.mkdir()
    _metadata_path(root).mkdir()
    _keys_path(root).mkdir()
    _snaps_path(root).mkdir()
    _tmp_path(root).mkdir()
    _locks_path(root).mkdir()
    udd.mkdir()
    bs = FileBlobstore(udd, _tmp_path(root))
    blob_db = BlobKeyDB(_keys_path(root), Path(_tmp_path(root)), bs)
    json_db = JsonKeyDB(blob_db)
    # Make sure root key is removed.
    blob_db.delete("root")
    # TODO should I overwrite?
    json_db.write("udd", str(udd), True)
    # TODO should I overwrite?
    json_db.write("status", {}, True)
    FarmFSVolume(root)


def encode_volume(vol: "FarmFSVolume") -> str:
    return str(vol.root)


def decode_volume(vol: str, key: str) -> "FarmFSVolume":
    return FarmFSVolume(Path(vol))


def encode_snapshot(snap: Snapshot) -> List[Dict]:
    snap_items = iter(snap)
    return list(map(lambda x: x.get_dict(), snap_items))


def decode_snapshot(reverser: ReverserFunction):
    def decoder(data: List[SnapItemTypes], key: str) -> KeySnapshot:
        return KeySnapshot(data, key, reverser)
    return decoder

class ImportResult(TypedDict):
    path: Path
    csum: str
    was_dup: bool

def validate_snapshot(key: str, snap: KeySnapshot) -> List[str]:
    errors = []
    items = list(snap)
    sorted_items = sorted(items)
    if items != sorted_items:
        for i, (actual, expected) in enumerate(zip(items, sorted_items)):
            if actual != expected:
                errors.append(f"entry {i}: got {actual._path!r}, expected {expected._path!r}")
                if len(errors) >= 3:
                    errors.append(f"... ({len(items)} entries total)")
                    break
    return errors


def validate_remote(key: str, vol: "FarmFSVolume") -> List[str]:
    errors = []
    root = str(vol.root)
    if not root.startswith("/") and not root.startswith("s3://") and not root.startswith("http"):
        errors.append(f"remote {key}: unrecognised root format: {root}")
    return errors


class FarmFSVolume:
    def __init__(self, root: Path):
        assert isinstance(root, Path)
        self.root = root
        self.mdd = _metadata_path(root)
        self.tmp_dir = Path(_tmp_path(root))  # TODO Hard coded while bs is known single volume.
        assert self.tmp_dir.isdir()
        # Bootstrap: read udd key (file-backed, no blobstore yet)
        keydb_bootstrap = BlobKeyDB(_keys_path(root), self.tmp_dir, blobstore=None)
        self.udd = Path(loads(keydb_bootstrap.read("udd")))
        assert self.udd.isdir()
        self.bs = FileBlobstore(self.udd, self.tmp_dir)
        snap_decoder = decode_snapshot(self.bs.reverser)
        self.blob_db: BlobKeyDB = BlobKeyDB(_keys_path(root), self.tmp_dir, self.bs)
        json_db = JsonKeyDB(self.blob_db)
        self.keydb: JsonKeyDB = json_db  # vol.keydb stays as the JSON layer for existing callers
        self.snapdb: KeyDBFactory[KeySnapshot] = KeyDBFactory(
            KeyDBWindow("snaps", json_db),
            encode_snapshot,
            snap_decoder,
            validate=validate_snapshot,
        )
        self.remotedb: KeyDBFactory[FarmFSVolume] = KeyDBFactory(
            KeyDBWindow("remotes", json_db),
            encode_volume,
            decode_volume,
            validate=validate_remote,
        )

        exclude_file = Path(".farmignore", self.root)
        ignored_patterns = [str(self.mdd)]
        try:
            with exclude_file.open("rb") as exclude_fd:
                for raw_pattern in exclude_fd.readlines():
                    pattern = ingest(raw_pattern.strip())
                    excluded = str(Path(pattern, root))
                    ignored_patterns.append(excluded)
        except IOError as e:
            if e.errno == NoSuchFile:
                pass
            else:
                raise e
        self.is_ignored = ignored_path_checker(ignored_patterns)

    def thawed(self, path: Path) -> Iterator[Path]:
        """Yield set of files not backed by FarmFS under path"""
        keep_files = ftype_selector([FILE])
        just_paths = fmap(walk_path)
        select_userdata_files = pipeline(keep_files, just_paths)
        return select_userdata_files(walk(path, skip=self.is_ignored))

    def frozen(self, path: Path) -> Iterator[Path]:
        """Yield set of files backed by FarmFS under path"""
        select_userdata_files = pipeline(ftype_selector([LINK]), fmap(walk_path))
        return select_userdata_files(walk(path, skip=self.is_ignored))

    def link(self, path: Path, blob: str) -> None:
        """
        Create a path in the volumne bound to a blob in the blobstore.
        This operation is not atomic.
        If path is already a file or directory, those things are destroyed.
        """
        assert isinstance(path, Path)
        assert self.root in path.parents()
        ensure_symlink(path, self.bs.blob_path(blob))

    def freeze(self, path: Path):
        assert isinstance(path, Path)
        assert isinstance(self.udd, Path)
        csum = path.checksum()
        # TODO doesn't work on multi-volume blobstores.
        # TODO we should rework so we try import_via_link then import_via_fd.
        duplicate = self.bs.import_via_link(path, csum)
        # Note ensure_symlink is not atomic, which should be fine for volume.
        self.link(path, csum)
        return ImportResult(path=path, csum=csum, was_dup=duplicate)

    def thaw(self, user_path: Path) -> Path:
        assert isinstance(user_path, Path)
        csum_path = user_path.readlink()
        # TODO using bs.tmp_dir. When we allow alternate topology for bs, this will break.
        csum_path.copy_file(user_path, self.bs.tmp_dir)
        return user_path

    def repair_link(self, path: Path) -> Optional[Path]:
        """Find all broken links and point them back at UDD"""
        assert path.islink()
        oldlink = path.readlink()
        if oldlink.isfile():
            return None
        csum = self.bs.reverser(oldlink)
        newlink = self.bs.blob_path(csum)
        if not newlink.isfile():
            raise ValueError("%s is missing, cannot relink" % newlink)
        else:
            # TODO not atomic.
            path.unlink()
            path.symlink(self.bs.blob_path(csum))
            return newlink

    def link_checker(self) -> Callable[[Iterator[SnapshotItem]], Iterator[SnapshotItem]]:
        """
        Return a pipeline which given a list of SnapshotItems.
        Returns the SnapshotItems with broken links to the blobstore.
        """
        def is_link(item: SnapshotItem) -> bool:
            return item.is_link()
        select_links = ffilter(is_link)
        def is_broken(item: SnapshotItem) -> bool:
            return not self.bs.exists(item.csum())
        select_broken = ffilter(is_broken)
        return pipeline(select_links, select_broken)

    def trees(self) -> Iterator[Snapshot]:
        """
        Returns an iterator which contains all trees for the volume.
        The Local tree and all the snapshots.
        """
        tree = self.tree()
        snaps = map(lambda x: self.snapdb.read(x), self.snapdb.list())
        all_snaps = chain([tree], snaps)
        return all_snaps

    def items(self) -> Iterator[SnapshotItem]:
        """Returns an iterator which lists all SnapshotItems from all local snaps + the working tree"""
        return pipeline(concat)(self.trees())

    def tree(self) -> Snapshot:
        """
        Get a snap object which represents the tree of the volume.
        """
        tree_snap = TreeSnapshot(self.root, self.is_ignored, reverser=self.bs.reverser)
        return tree_snap

    def userdata_csums(self) -> Generator[str, None, None]:
        """
        Yield all the relative paths (str) for all the files in the userdata store.
        """
        # TODO this function is a duplicate of self.bs.blobs()
        # We populate counts with all hash paths from the userdata directory.
        for path, type_ in walk(self.udd):
            assert isinstance(path, Path)
            if type_ == FILE:
                yield self.bs.reverser(path)
            elif type_ == DIR:
                pass
            else:
                raise ValueError("%s is f invalid type %s" % (path, type_))

    def unused_blobs(self, items: Iterator[SnapshotItem]) -> set[str]:
        """Returns the set of blobs not referenced in items"""
        def is_link(item: SnapshotItem) -> bool:
            return item.is_link()
        select_links = ffilter(is_link)
        def csum(item: SnapshotItem) -> str:
            return item.csum()
        get_csums = fmap(csum)
        referenced_hashes = set(pipeline(select_links, get_csums, uniq)(items))
        keydb_hashes = set(self.blob_db.live_blobs())
        udd_hashes = set(self.userdata_csums())
        missing_data = referenced_hashes - udd_hashes
        assert len(missing_data) == 0, "Missing %s\nReferenced %s\nExisting %s\n" % (
            missing_data,
            referenced_hashes,
            udd_hashes,
        )
        orphaned_csums = udd_hashes - referenced_hashes - keydb_hashes
        return orphaned_csums

    def similarity(self, dir_a: Path, dir_b: Path) -> Tuple[int, int, int, float]:
        """
        Returns similarity data for directories:
        (num unique to a, num in both, num unique to b, jaccard similarity)
        """
        @uncurry
        def get_path(p: Path, t: str): return p
        get_paths = fmap(get_path)
        def get_link(p: Path): return p.readlink()
        get_links = fmap(get_link)
        def get_csum(link: Path): return self.bs.reverser(link)
        get_csums = fmap(get_csum)
        select_userdata_csums = pipeline(
            ftype_selector([LINK]),
            get_paths,
            get_links,
            get_csums,
        )
        a: set[str] = set(select_userdata_csums(walk(dir_a, skip=self.is_ignored)))
        b: set[str] = set(select_userdata_csums(walk(dir_b, skip=self.is_ignored)))
        left = a.difference(b)
        both = a.intersection(b)
        right = b.difference(a)
        jaccard = jaccard_similarity(a, b)
        return (len(left), len(both), len(right), jaccard)


def tree_patcher(local_vol: FarmFSVolume, remote_vol: FarmFSVolume):
    return fmap(partial(tree_patch, local_vol, remote_vol))


def noop():
    pass


BlobOperation = Callable[[], bool | None]
TreeOperation = Callable[[], None]
TreeDescription = Tuple[str, Path]

VolumeChangeOperation = Tuple[BlobOperation, TreeOperation, TreeDescription]

def tree_patch(
        local_vol: FarmFSVolume,
        remote_vol: FarmFSVolume,
        delta: SnapDelta) -> VolumeChangeOperation:
    # TODO delta.path signature is ambiguous could be Path or str depending on context.
    path = delta.path(local_vol.root)
    assert isinstance(path, Path)
    assert local_vol.root in path.parents(), (
        "Tried to apply op to %s when root is %s" % (path, local_vol.root)
    )
    csum = delta.csum

    if delta.mode == delta.REMOVED:
        return (noop, partial(ensure_absent, path), ("Apply Removing %s", path))
    elif delta.mode == delta.DIR:
        return (noop, partial(ensure_dir, path), ("Apply mkdir %s", path))
    elif delta.mode == delta.LINK:
        assert csum is not None, "Excpected csum for link"
        _csum: str = csum
        remote_read_handle_fn = lambda: remote_vol.bs.read_handle(_csum)
        def blob_op(csum: str = _csum) -> None:
            with local_vol.bs.session() as sess:
                sess.import_via_fd(remote_read_handle_fn, csum)
        tree_op = lambda: ensure_symlink(path, local_vol.bs.blob_path(csum))
        tree_desc = ("Apply mklink %s -> " + csum, path)
        return (blob_op, tree_op, tree_desc)
    else:
        raise ValueError("Unknown mode in SnapDelta: %s" % delta.mode)


def next_valid_snap_item(
    item_iter: Generator[SnapshotItem, None, None], last_delta: Optional[SnapDelta]
) -> Optional[SnapshotItem]:
    """
    Get the next valid snapshot item from the iterator.
    A valid snapshot item is one which does not belong to
    a parent which was deleted in the last delta.
    """
    if last_delta is None:
        # There could not be a invalid item, because there have been no deltas.
        return next(item_iter, None)
    if last_delta.mode != SnapDelta.REMOVED:
        # If the last delta was not a removal, we can safely return the next item.
        return next(item_iter, None)
    # We last processed a REMOVE, lets comsume children if it was a dir.
    removed_path = last_delta.path(ROOT)
    while True:
        next_item = next(item_iter, None)
        if next_item is None:
            return None
        item_path = next_item.to_path(ROOT)
        if removed_path in list(item_path.parents()):
            continue
        else:
            return next_item


# TODO yields lots of SnapDelta. Maybe in wrong file?
def _tree_diff(tree: Snapshot, snap: Snapshot) -> Generator[SnapDelta, None, None]:
    tree_parts = iter(tree)
    snap_parts = iter(snap)
    t = next(tree_parts, None)
    s = next(snap_parts, None)
    while t is not None or s is not None:
        if t is not None and s is not None:
            # We have components from both sides!
            if t < s:
                # The tree component is not present in the snap. Delete it.
                sd = SnapDelta(t.pathStr(), SnapDelta.REMOVED)
                t = next_valid_snap_item(tree_parts, sd)
                yield sd
            elif s < t:
                # The snap component is not part of the tree. Create it
                yield SnapDelta(*s.get_tuple())
                s = next(snap_parts, None)
            elif t == s:
                if t.is_dir() and s.is_dir():
                    t = next(tree_parts, None)
                    s = next(snap_parts, None)
                elif t.is_link() and s.is_link():
                    if t.csum() == s.csum():
                        t = next(tree_parts, None)
                        s = next(snap_parts, None)
                    else:
                        change = t.get_dict()
                        change["csum"] = s.csum()
                        sd = SnapDelta(t._path, t._type, s._csum)
                        t = next_valid_snap_item(tree_parts, sd)
                        s = next(snap_parts, None)
                        yield sd
                elif t.is_link() and s.is_dir():
                    sd = SnapDelta(t.pathStr(), SnapDelta.REMOVED)
                    t = next_valid_snap_item(tree_parts, sd)
                    yield sd
                    yield SnapDelta(s.pathStr(), SnapDelta.DIR)
                    s = next(snap_parts, None)
                elif t.is_dir() and s.is_link():
                    yield SnapDelta(t.pathStr(), SnapDelta.REMOVED)
                    yield SnapDelta(s.pathStr(), SnapDelta.LINK, s.csum())
                    t = next(tree_parts, None)
                    s = next(snap_parts, None)
                else:
                    raise ValueError(
                        "Unable to process tree/snap: unexpected types:",
                        s.get_dict()["type"],
                        t.get_dict()["type"],
                    )
            else:
                raise ValueError("Found pair that doesn't respond to > < == cases")
        elif t is not None:
            sd = SnapDelta(t.pathStr(), SnapDelta.REMOVED)
            t = next_valid_snap_item(tree_parts, sd)
            yield sd
        elif s is not None:
            yield SnapDelta(*s.get_tuple())
            s = next(snap_parts, None)


def tree_diff(tree: Snapshot, snap: Snapshot) -> List[SnapDelta]:
    return list(_tree_diff(tree, snap))
