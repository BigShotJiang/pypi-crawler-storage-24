from io import BytesIO

import pytest
from farmfs.fs import Path, ensure_copy, ensure_readonly
from farmfs.ui import farmfs_ui, dbg_ui
from farmfs.util import egest
from farmfs.volume import mkfs
from farmfs.api import get_app
from farmfs import getvol
import uuid
from delnone import delnone
from .conftest import build_file, build_checksum, build_link, build_dir, build_blob
from werkzeug.serving import make_server
import threading


@pytest.fixture
def vol1(tmp: Path) -> Path:
    root = tmp.join("vol1")
    udd = root.join(".farmfs").join("userdata")
    mkfs(root, udd)
    return root


@pytest.fixture
def vol2(tmp: Path) -> Path:
    root = tmp.join("vol2")
    udd = root.join(".farmfs").join("userdata")
    mkfs(root, udd)
    return root


@pytest.fixture
def vol3(tmp: Path) -> Path:
    root = tmp.join("vol3")
    udd = root.join(".farmfs").join("userdata")
    mkfs(root, udd)
    return root


def test_builders(vol):
    a = build_file(vol, "a", "a")
    assert a.content("r") == "a"
    assert a.checksum() == build_checksum(b"a")
    ablob = build_blob(vol, b"a")
    assert ablob == a.checksum()
    bblob = build_blob(vol, b"b")
    assert bblob == build_checksum(b"b")
    a2 = build_link(vol, "a2", a.checksum())
    assert a2.checksum() == ablob


def test_farmfs_mkfs(tmp):
    farmfs_ui(["mkfs"], tmp)
    meta = Path(".farmfs", tmp)
    assert meta.isdir()
    userdata = Path("userdata", meta)
    assert userdata.isdir()
    snaps = Path("snaps", meta)
    assert snaps.isdir()
    keys = Path("keys", meta)
    assert keys.isdir()


def test_farmfs_status(vol, capsys):
    build_file(vol, "a", "a")
    r = farmfs_ui(["status"], vol)
    captured = capsys.readouterr()
    assert captured.out == "a\n"
    assert captured.err == ""
    assert r == 0
    # Test relative status report.
    d = build_dir(vol, "d")
    r = farmfs_ui(["status"], d)
    captured = capsys.readouterr()
    assert captured.out == "../a\n"
    assert captured.err == ""
    assert r == 0
    # Freeze a
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0
    # assert captured.out == ""
    assert captured.err == ""
    r = farmfs_ui(["status"], vol)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""
    assert r == 0


def test_farmfs_ignore(vol, capsys):
    build_file(vol, ".farmignore", egest("a\n\u03b1\n"), mode="wb")
    for name in ["a", "b", "\u03b1", "\u03b2"]:
        build_file(vol, name, "hi")
    r = farmfs_ui(["status"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == ".farmignore\nb\n\u03b2\n"
    assert captured.err == ""


@pytest.mark.parametrize(
    "parent,child,snap,content,read,write",
    [
        ("a", "b", "mysnap", "hi", "r", "w"),
        ("a", "b", "mysnap", "hi", "r", "w"),
        ("a", "b", "mysnap", b"hi", "rb", "wb"),
        # (u'par ent', u'ch ild', u'my snap', 'hi', 'r','w'), #TODO relative path bug.
        ("\u03b1", "\u03b2", "mysnap", "hi", "r", "w"),
        ("\u03b1", "\u03b2", "\u0394", "hi", "r", "w"),
    ],
)
def test_farmfs_freeze_snap_thaw(
    vol, parent, child, snap, content, read, write, capsys
):
    # Build a file in a dir.
    parent_path = build_dir(vol, parent)
    child_path = build_file(parent_path, child, content, mode=write)
    csum = child_path.checksum()
    assert parent_path.isdir()
    assert child_path.isfile()
    # Freeze the tree
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == f"Imported {parent}/{child} with checksum {csum}\n"
    assert captured.err == ""
    assert parent_path.isdir()
    assert child_path.islink()
    link = child_path.readlink()
    assert link.isfile()
    userdata = Path(".farmfs/userdata", vol)
    assert userdata in list(link.parents())
    assert link.content(read) == content
    # Build a snap
    r = farmfs_ui(["snap", "make", snap], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == ""
    assert captured.err == ""
    snap_path = vol.join(".farmfs/snap").join(snap)
    snap_path.exists()
    # Check that the snap is listed
    r = farmfs_ui(["snap", "list"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == f"{snap}\n"
    assert captured.err == ""
    # Read snap contents
    r = farmfs_ui(["snap", "read", snap], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert (
        captured.out
        == f"<dir . None>\n<dir {parent} None>\n<link {parent}/{child} {csum}>\n"
    )
    assert captured.err == ""
    # Delete files and restore from snap.
    child_path.unlink()
    assert not child_path.exists()
    assert link.isfile()
    r = farmfs_ui(["snap", "restore", snap], vol)
    assert r == 0
    assert child_path.islink()
    assert link.isfile()
    assert child_path.readlink() == link
    r = farmfs_ui(["thaw", parent], vol)
    assert r == 0
    assert child_path.isfile()
    r = farmfs_ui(["freeze", child], parent_path)
    assert r == 0
    child_path.islink()


def test_farmfs_blob_broken(vol1, vol2, capsys):
    r = farmfs_ui(["remote", "add", "backup", "../vol2"], vol1)
    captured = capsys.readouterr()
    assert r == 0
    for vol in [vol1, vol2]:
        a = build_file(vol, "a", "a")
        a_csum = str(a.checksum())
        r = farmfs_ui(["freeze"], vol)
        captured = capsys.readouterr()
        assert r == 0
    a_blob = vol1.join("a").readlink()
    a_blob.unlink()
    r = farmfs_ui(["fsck", "--quiet", "--missing"], vol1)
    captured = capsys.readouterr()
    assert captured.out == a_csum + "\n\t<tree>\ta\n"
    assert captured.err == ""
    assert r == 1
    # Test relative pathing.
    d = Path("d", vol1)
    d.mkdir()
    r = farmfs_ui(["fsck", "--missing", "--quiet"], d)
    captured = capsys.readouterr()
    assert captured.out == a_csum + "\n\t<tree>\t../a\n"
    assert captured.err == ""
    assert r == 1
    # fix the missing csum
    r = farmfs_ui(["fsck", "--quiet", "--missing", "--fix"], d)
    captured = capsys.readouterr()
    assert (
        captured.out
        == a_csum + "\n\t<tree>\t../a\n" + "\tRestored  " + a_csum + " from remote\n"
    )
    assert captured.err == ""
    assert r == 1
    r = farmfs_ui(["fsck", "--quiet", "--missing"], d)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""
    assert r == 0


def test_farmfs_blob_corruption(vol1, vol2, capsys):
    for vol in [vol1, vol2]:
        a = build_file(vol, "a", "a")
        a_csum = str(a.checksum())
        r = farmfs_ui(["freeze"], vol)
        captured = capsys.readouterr()
        assert r == 0
    r = farmfs_ui(["remote", "add", "backup", "../vol2"], vol1)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""
    assert r == 0
    a = vol1.join("a")
    a_blob = a.readlink()
    a_blob.unlink()
    with a_blob.open("w") as a_fd:
        a_fd.write("b")
    b_csum = str(a.checksum())
    ensure_readonly(a_blob)
    r = farmfs_ui(["fsck", "--quiet", "--checksums"], vol1)
    captured = capsys.readouterr()
    assert captured.out == "CORRUPTION checksum mismatch in blob %s got %s\n" % (
        a_csum,
        b_csum,
    )
    assert captured.err == ""
    assert r == 2
    r = farmfs_ui(["fsck", "--quiet", "--checksums", "--fix"], vol1)
    captured = capsys.readouterr()
    assert (
        captured.out
        == "CORRUPTION checksum mismatch in blob %s got %s\n" % (a_csum, b_csum)
        + "REPLICATED blob "
        + a_csum
        + " from remote\n"
    )
    assert captured.err == ""
    assert r == 2
    r = farmfs_ui(["fsck", "--quiet", "--checksums"], vol1)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""
    assert r == 0


def test_farmfs_blob_permission(vol, capsys):
    a = Path("a", vol)
    with a.open("w") as a_fd:
        a_fd.write("a")
    a_csum = str(a.checksum())
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0
    a_blob = a.readlink()
    a_blob.chmod(0o777)
    r = farmfs_ui(["fsck", "--quiet", "--blob-permissions"], vol)
    captured = capsys.readouterr()
    assert captured.out == "writable blob: " + a_csum + "\n"
    assert captured.err == ""
    assert r == 8
    r = farmfs_ui(["fsck", "--quiet", "--blob-permissions", "--fix"], vol)
    captured = capsys.readouterr()
    assert (
        captured.out
        == "writable blob: "
        + a_csum
        + "\n"
        + "fixed blob permissions: "
        + a_csum
        + "\n"
    )
    assert captured.err == ""
    assert r == 8
    r = farmfs_ui(["fsck", "--quiet", "--blob-permissions"], vol)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""
    assert r == 0


def test_farmfs_blob_unreadable(vol, capsys):
    a = Path("a", vol)
    with a.open("w") as a_fd:
        a_fd.write("a")
    a_csum = str(a.checksum())
    r = farmfs_ui(["freeze"], vol)
    assert r == 0
    capsys.readouterr()
    a_blob = a.readlink()
    a_blob.chmod(0o000)
    r = farmfs_ui(["fsck", "--quiet", "--blob-permissions"], vol)
    captured = capsys.readouterr()
    assert captured.out == "unreadable blob: " + a_csum + "\n"
    assert captured.err == ""
    assert r == 8
    r = farmfs_ui(["fsck", "--quiet", "--blob-permissions", "--fix"], vol)
    captured = capsys.readouterr()
    assert (
        captured.out
        == "unreadable blob: "
        + a_csum
        + "\n"
        + "fixed blob permissions: "
        + a_csum
        + "\n"
    )
    assert captured.err == ""
    assert r == 8
    r = farmfs_ui(["fsck", "--quiet", "--blob-permissions"], vol)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""
    assert r == 0


def test_farmfs_ignore_corruption(vol, capsys):
    build_file(vol, "a", "a")
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0
    with vol.join(".farmignore").open("w") as ignore:
        ignore.write("a")
    r = farmfs_ui(["fsck", "--quiet", "--frozen-ignored"], vol)
    captured = capsys.readouterr()
    assert captured.out == "Ignored file frozen: a\n"
    assert captured.err == ""
    assert r == 4
    r = farmfs_ui(["fsck", "--quiet", "--frozen-ignored", "--fix"], vol)
    captured = capsys.readouterr()
    assert captured.out == "Ignored file frozen: a\nThawed a\n"
    assert captured.err == ""
    assert r == 4
    r = farmfs_ui(["fsck", "--quiet", "--frozen-ignored"], vol)
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""
    assert r == 0

def test_farmdbg_key(vol: Path, capsys):
    # Write a key
    r = dbg_ui(["key", "write", "k1", "v1"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == ""
    assert captured.err == ""
    # Read a key
    r = dbg_ui(["key", "read", "k1"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == '"v1"'
    assert captured.err == ""
    # List keys
    r = dbg_ui(["key", "list"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert "k1" in captured.out.splitlines()
    assert captured.err == ""
    # Delete a key
    r = dbg_ui(["key", "delete", "k1"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == ""
    assert captured.err == ""
    r = dbg_ui(["key", "read", "k1"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert "k1" not in captured.out.splitlines()
    assert captured.err == ""

def test_farmfs_keydb_paren_ordering(vol, capsys):
    """Snapshot with 'dir (extra)' alongside 'dir/' must not falsely fail semantic validation."""
    d = build_dir(vol, "dir")
    build_file(d, "file.mp3", "data")
    d2 = build_dir(vol, "dir (extra)")
    build_file(d2, "file.mp3", "data2")
    r = farmfs_ui(["freeze"], vol)
    assert r == 0
    r = farmfs_ui(["snap", "make", "mysnap"], vol)
    assert r == 0
    r = farmfs_ui(["fsck", "--quiet", "--keydb"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert "CORRUPT" not in captured.out


def test_farmfs_keydb_corruption(vol, capsys):
    from farmfs import getvol
    r = farmfs_ui(["snap", "make", "mysnap"], vol)
    assert r == 0
    # Locate and corrupt the snap key file via blob_db
    fsvol = getvol(vol)
    from posixpath import sep
    snap_key_blob = fsvol.blob_db._key_blob("snaps" + sep + "mysnap")
    with fsvol.bs.session() as sess:
        sess.import_via_fd(lambda: BytesIO(b'corrupt data'), snap_key_blob, force=True)
    r = farmfs_ui(["fsck", "--quiet", "--keydb"], vol)
    captured = capsys.readouterr()
    assert "CORRUPT keydb key: snaps/mysnap" in captured.out
    assert r == 16
    # Make another snap (mysnap2 should be clean)
    farmfs_ui(["snap", "make", "mysnap2"], vol)
    # Confirm keydb still shows mysnap as corrupt
    r = farmfs_ui(["fsck", "--quiet", "--keydb"], vol)
    captured = capsys.readouterr()
    assert "CORRUPT keydb key: snaps/mysnap" in captured.out
    assert r == 16


def test_farmfs_keydb_fix(vol, capsys):
    """
    Write a snap whose JSON uses ensure_ascii=True (old pre-2019 encoder style),
    confirm fsck --keydb detects it, fix it with fsck --keydb --fix, then
    confirm fsck --keydb returns 0.
    """
    from json import JSONEncoder
    from posixpath import sep
    # Create a snap with a Unicode filename so the non-canonical encoding is visible
    d = build_dir(vol, "\u6700\u9ad8")
    build_file(d, "file.txt", "data")
    r = farmfs_ui(["freeze"], vol)
    assert r == 0
    r = farmfs_ui(["snap", "make", "mysnap"], vol)
    assert r == 0
    # Read the canonical JSON written by farmfs, re-encode with ensure_ascii=True
    fsvol = getvol(vol)
    snap_key = "snaps" + sep + "mysnap"
    canonical_bytes = fsvol.blob_db.read(snap_key)
    from json import loads
    decoded = loads(canonical_bytes)
    non_canonical = egest(JSONEncoder(ensure_ascii=True, sort_keys=True).encode(decoded))
    # Write non-canonical bytes as a new properly-checksummed blob and repoint the symlink.
    # (Corrupting the existing blob in-place would trigger a checksum mismatch at Level 1,
    # not a JSON round-trip failure at Level 2.)
    fsvol.blob_db.write(snap_key, non_canonical, overwrite=True)
    # Step 1: fsck detects the non-canonical encoding
    r = farmfs_ui(["fsck", "--quiet", "--keydb"], vol)
    captured = capsys.readouterr()
    assert "CORRUPT keydb key: snaps/mysnap" in captured.out
    assert r == 16
    # Step 2: fsck --fix repairs it
    r = farmfs_ui(["fsck", "--quiet", "--keydb", "--fix"], vol)
    captured = capsys.readouterr()
    assert "FIXED keydb key: snaps/mysnap" in captured.out
    assert r == 0
    # Step 3: fsck confirms clean
    r = farmfs_ui(["fsck", "--quiet", "--keydb"], vol)
    captured = capsys.readouterr()
    assert "CORRUPT" not in captured.out
    assert r == 0
    # Step 4: the snap is still readable and data intact
    fsvol2 = getvol(vol)
    value = fsvol2.keydb.read(snap_key)
    assert value == decoded


def test_farmfs_keydb_blob_backed(vol, capsys):
    """
    Write a snap using the old two-line file format directly (not blob-backed),
    confirm fsck --keydb detects it as LEGACY, fix it with --fix, then
    confirm fsck --keydb returns 0 and the key is now a symlink.
    """
    from hashlib import md5
    from posixpath import sep
    r = farmfs_ui(["snap", "make", "mysnap"], vol)
    assert r == 0
    fsvol = getvol(vol)
    snap_key = "snaps" + sep + "mysnap"
    # Overwrite the blob-backed key with a legacy two-line file
    key_path = fsvol.blob_db.keypath(snap_key)
    value_bytes = fsvol.blob_db.read(snap_key)
    csum = md5(value_bytes).hexdigest()
    from farmfs.fs import ensure_absent
    ensure_absent(key_path)
    with key_path.open("wb") as f:
        f.write(value_bytes + b"\n")
        f.write(csum.encode("utf-8") + b"\n")
    assert not key_path.islink()
    # Step 1: fsck detects the file-backed key
    r = farmfs_ui(["fsck", "--quiet", "--keydb"], vol)
    captured = capsys.readouterr()
    assert "LEGACY keydb key: snaps/mysnap" in captured.out
    assert r == 16
    # Step 2: fsck --fix migrates it to blob-backed
    r = farmfs_ui(["fsck", "--quiet", "--keydb", "--fix"], vol)
    captured = capsys.readouterr()
    assert "FIXED keydb key: snaps/mysnap" in captured.out
    assert r == 0
    # Step 3: fsck confirms clean
    r = farmfs_ui(["fsck", "--quiet", "--keydb"], vol)
    captured = capsys.readouterr()
    assert "LEGACY" not in captured.out
    assert r == 0
    # Step 4: key is now a symlink and data is intact
    fsvol2 = getvol(vol)
    assert fsvol2.blob_db.is_blob_backed(snap_key)
    assert fsvol2.blob_db.read(snap_key) == value_bytes


def test_farmfs_keydb_legacy_absolute_paths(vol, capsys):
    """
    Write a snap whose JSON uses legacy absolute paths ('/' and '/foo').
    fsck --keydb should detect it via the semantic round-trip (encode_snapshot
    normalises paths through SnapshotItem), and --fix should rewrite it.
    """
    import json
    from posixpath import sep
    from farmfs.keydb import keydb_encoder
    from farmfs.util import egest

    r = farmfs_ui(["snap", "make", "mysnap"], vol)
    assert r == 0
    fsvol = getvol(vol)
    snap_key = "snaps" + sep + "mysnap"

    # Read the canonical snap data and rewrite it with absolute paths
    canonical_raw = fsvol.blob_db.read(snap_key)
    canonical_data = json.loads(canonical_raw)
    # Rewrite each entry's path as absolute (. -> /, foo -> /foo)
    legacy_data = []
    for entry in canonical_data:
        e = dict(entry)
        p = e["path"]
        e["path"] = "/" if p == "." else "/" + p
        legacy_data.append(e)
    legacy_raw = egest(keydb_encoder.encode(legacy_data))
    fsvol.blob_db.write(snap_key, legacy_raw, overwrite=True)

    # Step 1: fsck detects the semantic mismatch
    r = farmfs_ui(["fsck", "--quiet", "--keydb"], vol)
    captured = capsys.readouterr()
    assert "CORRUPT keydb key: snaps/mysnap" in captured.out
    assert "encoded form differs" in captured.out
    assert r == 16

    # Step 2: fsck --fix rewrites it
    r = farmfs_ui(["fsck", "--quiet", "--keydb", "--fix"], vol)
    captured = capsys.readouterr()
    assert "FIXED keydb key: snaps/mysnap" in captured.out
    assert r == 0

    # Step 3: fsck confirms clean
    r = farmfs_ui(["fsck", "--quiet", "--keydb"], vol)
    captured = capsys.readouterr()
    assert "CORRUPT" not in captured.out
    assert r == 0

    # Step 4: the stored data now uses relative paths
    fsvol2 = getvol(vol)
    fixed_data = json.loads(fsvol2.blob_db.read(snap_key))
    for entry in fixed_data:
        assert not entry["path"].startswith("/"), f"still absolute: {entry['path']}"


@pytest.mark.parametrize(
    "a,b,c",
    [("a", "b", "c"), ("a", "b", "c"), ("\u03b1", "\u03b2", "\u0394")],
)
def test_farmdbg_reverse(vol, capsys, a, b, c):
    a_path = Path(a, vol)
    with a_path.open("w") as a_fd:
        a_fd.write("a")
    a_csum = str(a_path.checksum())
    bc_path = Path(b, vol).join(c)
    ensure_copy(bc_path, a_path)
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    r = farmfs_ui(["snap", "make", "mysnap"], vol)
    assert r == 0
    r = dbg_ui(["walk", "root"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == ".\tdir\t\n%s\tlink\t%s\n%s\tdir\t\n%s/%s\tlink\t%s\n" % (
        a,
        a_csum,
        b,
        b,
        c,
        a_csum,
    )
    assert captured.err == ""
    r = dbg_ui(["walk", "userdata"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert a_csum in captured.out.splitlines()
    assert captured.err == ""
    r = dbg_ui(["fs", "reverse", a_csum], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert (
        captured.out
        == a_csum + " <tree> " + a + "\n" + a_csum + " <tree> " + b + "/" + c + "\n"
    )
    assert captured.err == ""
    r = dbg_ui(["fs", "reverse", "--all", a_csum], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert (
        captured.out
        == a_csum
        + " <tree> "
        + a
        + "\n"
        + a_csum
        + " <tree> "
        + b
        + "/"
        + c
        + "\n"
        + a_csum
        + " mysnap "
        + a
        + "\n"
        + a_csum
        + " mysnap "
        + b
        + "/"
        + c
        + "\n"
    )
    assert captured.err == ""
    r = dbg_ui(["fs", "reverse", "--snap", "mysnap", a_csum], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert (
        captured.out
        == a_csum + " mysnap " + a + "\n" + a_csum + " mysnap " + b + "/" + c + "\n"
    )
    assert captured.err == ""


def test_gc(vol, capsys):
    sk = Path("sk", vol)
    sd = Path("sd", vol)
    tk = Path("tk", vol)
    td = Path("td", vol)
    # Make sk, freeze, snap, delete
    with sk.open("w") as fd:
        fd.write("sk")
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0
    sk_blob = sk.readlink()
    r = farmfs_ui(["snap", "make", "snk"], vol)
    captured = capsys.readouterr()
    assert r == 0
    sk.unlink()
    # Make sd, freeze, snap, delete, delete snap
    with sd.open("w") as fd:
        fd.write("sd")
    sd_csum = str(sd.checksum())
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0
    sd_blob = sd.readlink()
    r = farmfs_ui(["snap", "make", "snd"], vol)
    captured = capsys.readouterr()
    assert r == 0
    sd.unlink()
    r = farmfs_ui(["snap", "delete", "snd"], vol)
    captured = capsys.readouterr()
    assert r == 0
    # Make tk and td, freeze, delete td
    with tk.open("w") as fd:
        fd.write("tk")
    with td.open("w") as fd:
        fd.write("td")
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0
    tk_blob = tk.readlink()
    td_blob = td.readlink()
    td_csum = str(td.checksum())
    td.unlink()
    # GC --noop
    assert sk_blob.exists()
    assert sd_blob.exists()
    assert tk_blob.exists()
    assert td_blob.exists()
    r = farmfs_ui(["gc", "--noop"], vol)
    captured = capsys.readouterr()
    assert f"Removing {sd_csum}" in captured.out.splitlines()
    assert f"Removing {td_csum}" in captured.out.splitlines()
    assert captured.err == ""
    assert r == 0
    assert sk_blob.exists()
    assert sd_blob.exists()
    assert tk_blob.exists()
    assert td_blob.exists()
    # GC
    r = farmfs_ui(["gc"], vol)
    captured = capsys.readouterr()
    assert f"Removing {sd_csum}" in captured.out.splitlines()
    assert f"Removing {td_csum}" in captured.out.splitlines()
    assert captured.err == ""
    assert r == 0
    assert sk_blob.exists()
    assert not sd_blob.exists()
    assert tk_blob.exists()
    assert not td_blob.exists()


def test_missing(vol, capsys):
    a = Path("a", vol)
    b = Path("b", vol)
    b2 = Path("b2", vol)
    c = Path("c.txt", vol)
    d = Path("d", vol)
    ignore = Path(".farmignore", vol)
    # Make a,b,b2; freeze, snap, delete
    with a.open("w") as fd:
        # Checksum for a_mask should not appear missing, as a exists.
        fd.write("a_masked")
    a_masked_csum = str(a.checksum())
    with b.open("w") as fd:
        fd.write("b")
    b_csum = str(b.checksum())
    with b2.open("w") as fd:
        fd.write("b")
    with c.open("w") as fd:
        fd.write("c")
    r = farmfs_ui(["freeze"], vol)  # csums for a_masked, b, c should be frozen. Paths a, b, b2, c.txt are in tree.
    captured = capsys.readouterr()
    assert r == 0
    r = farmfs_ui(["snap", "make", "snk1"], vol)  # snk1 has items for a (a_masked), b (b), b2 (b), c.txt (c)
    captured = capsys.readouterr()
    # Remove b's
    a.unlink()
    with a.open("w") as fd:
        fd.write("a")
    b.unlink()
    b2.unlink()
    c.unlink()
    # The tree is now a (thawed) only. blobstore still has blobs for a_masked, b, c.
    # Setup ignore
    with ignore.open("w") as fd:
        fd.write("*.txt\n*/*.txt\n")  # c.txt will now be ignored.
    # Look for missing checksum:
    expected_missing = set([
        b_csum + "\tsnk1\tb",  # b at paths b and b2 is missing.
        b_csum + "\tsnk1\tb2",
        a_masked_csum + "\tsnk1\ta"  # a_masked at path a is missing because its masked by a.
        # c at path c.txt is missing, but is ignored so will not be reported.
    ])
    r = dbg_ui(["missing", "snk1"], vol)
    captured = capsys.readouterr()
    assert r == 4
    assert captured.err == ""
    print("captured err:", captured.err)
    assert set(captured.out.splitlines()) == expected_missing
    # Make d; freeze snap, delete
    with d.open("w") as fd:
        fd.write("d")
    d_csum = str(d.checksum())
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0
    r = farmfs_ui(["snap", "make", "snk2"], vol)
    captured = capsys.readouterr()
    d.unlink()
    # Look for missing checksum:
    expected_missing = set([
        b_csum + "\tsnk1\tb",  # b at paths b and b2 is missing.
        b_csum + "\tsnk1\tb2",
        a_masked_csum + "\tsnk1\ta",  # a_masked at path a is missing because its masked by a.
        # c at path c.txt is missing, but is ignored so will not be reported.
        d_csum + "\tsnk2\td",  # d at path d is missing.
    ])
    r = dbg_ui(["missing", "snk1", "snk2"], vol)
    captured = capsys.readouterr()
    assert r == 4
    assert captured.err == ""
    assert set(captured.out.splitlines()) == expected_missing


def test_blob_type(vol, capsys):
    a = Path("a", vol)
    b = Path("b", vol)
    # Make a,b; freeze, snap, delete
    with a.open("w") as fd:
        fd.write("a")
    with b.open("w") as fd:
        fd.write("XSym\n1234\n")
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0
    # Check file type for a
    a_csum = str(a.checksum())
    b_csum = str(b.checksum())
    r = dbg_ui(["blob", "type", a_csum, b_csum], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.err == ""
    assert captured.out == a_csum + " unknown\n" + b_csum + " inode/symlink\n"


def test_fs_type(vol, capsys):
    subdir = Path("sub", vol)
    a = Path("a", vol)
    b = Path("sub/b", vol)
    with a.open("w") as fd:
        fd.write("a")
    subdir.mkdir()
    with b.open("w") as fd:
        fd.write("XSym\n1234\n")
    r = farmfs_ui(["freeze"], vol)
    capsys.readouterr()
    assert r == 0
    # Walk a single file (content "a" has no recognized magic bytes)
    r = dbg_ui(["fs", "type", "a"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.err == ""
    assert captured.out == "a unknown\n"
    # Walk a directory recursively (XSym content is recognized as inode/symlink)
    r = dbg_ui(["fs", "type", "sub"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.err == ""
    assert captured.out == "sub/b inode/symlink\n"
    # Walk the volume root
    r = dbg_ui(["fs", "type", str(vol)], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.err == ""
    lines = set(captured.out.splitlines())
    assert "a unknown" in lines
    assert "sub/b inode/symlink" in lines


def test_fix_link(vol1, vol2, capsys):
    # Setup vol1
    a = build_file(vol1, "a", "a")
    b = build_file(vol1, "b", "b")
    c = Path("c", vol1)
    cd = Path("c/d", vol1)
    # Make a,b; freeze, snap, delete
    a_csum = str(a.checksum())
    r = farmfs_ui(["freeze"], vol1)
    captured = capsys.readouterr()
    assert r == 0
    # Setup vol2
    e = build_file(vol2, "e", "e")
    e_csum = str(e.checksum())
    r = farmfs_ui(["freeze"], vol2)
    captured = capsys.readouterr()
    assert r == 0
    # Setup remote
    r = farmfs_ui(["remote", "add", "vol2", "../vol2"], vol1)
    captured = capsys.readouterr()
    assert r == 0
    # Check file type for a
    r = dbg_ui(["fix", "link", a_csum, "b"], vol1)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.err == ""
    assert captured.out == ""
    assert a.readlink() == b.readlink()
    # Try to fix link to a missing blob, e
    with pytest.raises(ValueError):
        r = dbg_ui(["fix", "link", e_csum, "e"], vol1)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.err == ""
    assert captured.out == "blob " + e_csum + " doesn't exist\n"
    # Pull e from remote.
    r = dbg_ui(["fix", "link", "--remote", "vol2", e_csum, "e"], vol1)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == "blob " + e_csum + " doesn't exist\n"
    assert captured.err == ""
    # Try to fix a link to a missing target.
    r = dbg_ui(["fix", "link", a_csum, "c"], vol1)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.err == ""
    assert captured.out == ""
    assert a.readlink() == c.readlink()
    # Try to fix a link to a missing target, in a dir which is blobked by a link
    r = dbg_ui(["fix", "link", a_csum, "c/d"], vol1)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.err == ""
    assert captured.out == ""
    assert a.readlink() == cd.readlink()


def test_blob(vol, capsys):
    # Make a,b,b2; freeze, snap, delete
    a = build_file(vol, "a", "a")
    a_csum = str(a.checksum())
    b = build_file(vol, "b", "b")
    b_csum = str(b.checksum())
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0
    # get blob paths
    r = dbg_ui(["blob", "path", a_csum, b_csum], vol)
    captured = capsys.readouterr()
    assert r == 0
    a_rel = a.readlink().relative_to(vol)
    b_rel = b.readlink().relative_to(vol)
    assert captured.out == a_csum + " " + a_rel + "\n" + b_csum + " " + b_rel + "\n"
    assert captured.err == ""
    # reverse blob paths back to checksums
    r = dbg_ui(["blob", "reverse", str(a.readlink()), str(b.readlink())], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == a_csum + "\n" + b_csum + "\n"
    assert captured.err == ""
    # get blob value
    r = dbg_ui(["blob", "read", a_csum], vol)
    captured = capsys.readouterr()
    assert captured.out == "a"  # TODO this is str, not bytes.
    assert r == 0
    r = dbg_ui(["blob", "read", b_csum], vol)
    captured = capsys.readouterr()
    assert captured.out == "b"
    assert r == 0
    # test read multiple blobs.
    r = dbg_ui(["blob", "read", a_csum, b_csum], vol)
    captured = capsys.readouterr()
    assert captured.out == "ab"
    assert r == 0


def test_rewrite_links(tmp, vol1, capsys):
    # Make a
    a = build_file(vol1, "a", "a")
    a_csum = str(a.checksum())
    r = farmfs_ui(["freeze"], vol1)
    captured = capsys.readouterr()
    assert r == 0
    # Move from vol1 to vol2
    vol2 = tmp.join("vol2")
    vol1.rename(vol2)
    # Reinit the fs. This will fix the udd directory pointer.
    r = farmfs_ui(["mkfs"], vol2)
    captured = capsys.readouterr()
    assert r == 0
    # Rewrite the links
    r = dbg_ui(["rewrite-links"], vol2)
    captured = capsys.readouterr()
    vol2a = vol2.join("a")
    vol2a_blob = vol2a.readlink()
    assert r == 0
    assert captured.out == "Relinked a to " + str(vol2a_blob) + "\n"
    assert captured.err == ""
    assert a_csum == vol2a.checksum() == vol2a_blob.checksum()


class S3Ctx:
    def __init__(self, *args):
        pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass


class MockServerThread(threading.Thread):
    def __init__(self, app, port):
        threading.Thread.__init__(self)
        self.server = make_server("127.0.0.1", port, app)
        self.ctx = app.app_context()
        self.ctx.push()

    def run(self):
        self.server.serve_forever()

    def shutdown(self):
        self.server.shutdown()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.shutdown()
        self.join()


def run_s3_server(*args):
    return S3Ctx(*args)


def run_api_server(root, port):
    root.mkdir()
    udd = root.join(".farmfs").join("userdata")
    mkfs(root, udd)
    app = get_app({"<root>": str(root)})
    server = MockServerThread(app, port)
    return server


get_s3_endpoint = lambda port: "s3://s3libtestbucket/" + str(uuid.uuid1())
get_api_endpoint = lambda port: f"http://localhost:{port}/{str(uuid.uuid1())}"


class NullServerCtx:
    def __init__(self, root, port):
        root.mkdir()
        udd = root.join(".farmfs").join("userdata")
        mkfs(root, udd)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass


def run_file_server(root, port):
    return NullServerCtx(root, port)


get_file_endpoint = lambda port: str  # unused placeholder; endpoint set from root path


@pytest.mark.parametrize(
    "source_type,snap_name,uploaded,remote_type,get_endpoint,run_server",
    [
        ("local", None, ["a"], "s3", get_s3_endpoint, run_s3_server),
        ("snap", "testsnap", ["a", "b"], "s3", get_s3_endpoint, run_s3_server),
        ("local", None, ["a"], "api", get_api_endpoint, run_api_server),
        ("snap", "testsnap", ["a", "b"], "api", get_api_endpoint, run_api_server),
        ("local", None, ["a"], "file", None, run_file_server),
        ("snap", "testsnap", ["a", "b"], "file", None, run_file_server),
        ("userdata", None, ["a", "b", "c"], "file", None, run_file_server),
    ],
)
def test_remote_upload_download(
    tmp,
    vol1,
    vol2,
    capsys,
    source_type,
    snap_name,
    uploaded,
    remote_type,
    get_endpoint,
    run_server,
):
    server_root1 = tmp.join("server1")
    with run_server(server_root1, 5001):
        url = get_endpoint(5001) if get_endpoint else str(server_root1)
        checksums = set()
        # Make Blobs a, b, c
        blob_a = build_blob(vol1, b"a")
        blob_b = build_blob(vol1, b"b")
        blob_c = build_blob(vol1, b"c")
        if "a" in uploaded:
            checksums.add(blob_a)
        if "b" in uploaded:
            checksums.add(blob_b)
        if "c" in uploaded:
            checksums.add(blob_c)
        # Build a and b in the tree
        a = build_link(vol1, "a", blob_a)
        b = build_link(vol1, "b", blob_b)
        # Build out snapshot: a and b will be in snap.
        r = farmfs_ui(["snap", "make", "testsnap"], vol1)
        assert r == 0
        b.unlink()  # remove b from tree. tree has just a.
        # Determine number of blobs in the remote:
        r = dbg_ui([remote_type, "list", url], vol1)
        captured = capsys.readouterr()
        assert r == 0
        assert captured.err == ""
        # Upload the contents.
        r = dbg_ui(
            delnone([remote_type, "upload", source_type, snap_name, "--quiet", url]),
            vol1,
        )
        captured = capsys.readouterr()
        assert r == 0
        # assert f"Remote Blobs: {len(remote_csums)}" in captured.out.splitlines()
        # assert f"Local Blobs: {uploads}" in captured.out.splitlines()
        # assert f"Missing Blobs: {uploads}" in captured.out.splitlines()
        # assert f"Successfully uploaded: {uploads} Blobs" in captured.out.splitlines()
        assert captured.err == ""
        # Upload again
        r = dbg_ui(
            delnone([remote_type, "upload", source_type, snap_name, "--quiet", url]),
            vol1,
        )
        captured = capsys.readouterr()
        assert r == 0
        # assert f"Remote Blobs: {uploads + len(remote_csums)}" in captured.out.splitlines()
        # assert f"Local Blobs: {uploads}" in captured.out.splitlines()
        assert "Missing Blobs: 0" in captured.out.splitlines()
        assert "Successfully uploaded: 0 Blobs" in captured.out.splitlines()
        assert captured.err == ""
        # verify checksums
        r = dbg_ui([remote_type, "check", "--quiet", url], vol1)
        captured = capsys.readouterr()
        assert r == 0
        assert captured.out == "All remote blobs etags match\n"
        assert captured.err == ""
        # verify corrupt checksum
        a_blob = a.readlink()
        a_blob.unlink()
        with a_blob.open("w") as fd:
            fd.write("b")
        b_csum = str(a.checksum())
        ensure_readonly(a_blob)

        server_root2 = tmp.join("server2")
        with run_server(server_root2, 5002):
            url2 = get_endpoint(5002) if get_endpoint else str(server_root2)
            r = dbg_ui(
                delnone(
                    [remote_type, "upload", source_type, snap_name, "--quiet", url2]
                ),
                vol1,
            )
            captured = capsys.readouterr()
            assert r == 0
            r = dbg_ui([remote_type, "check", "--quiet", url2], vol1)
            captured = capsys.readouterr()
            assert r == 2
            assert captured.out == blob_a + " " + b_csum + "\n"
            assert captured.err == ""
            # Read the files from remote:
            r = dbg_ui([remote_type, "read", url, blob_a, blob_a], vol1)
            captured = capsys.readouterr()
            assert r == 0
            assert captured.out == "aa"
            assert captured.err == ""
            # Copy snapshot over
            # TODO need an API for moving snapshots
            if snap_name is not None:
                # Use farmdbg to get the json snap dump
                # .farmfs/keys/snaps/testsnap
                # .farmfs/tmp/
                src_snap = vol1.join(".farmfs/keys/snaps").join(snap_name)
                assert src_snap.exists()
                dst_dir = vol2.join(".farmfs/keys/snaps")
                dst_dir.mkdir()  # Hack, keydb doesn't create spaces early.
                assert dst_dir.exists()
                dst_snap = dst_dir.join(snap_name)
                tmp_dir = vol2.join(".farmfs/tmp")
                assert tmp_dir.exists()
                src_snap.copy_file(dst_snap, tmpdir=tmp_dir)
                assert dst_snap.exists()
            else:
                pass
            # setup attempt to download blobs.
            r = dbg_ui(
                delnone([remote_type, "download", "userdata", "--quiet", url]), vol2
            )
            captured = capsys.readouterr()
            assert r == 0
            # assert f"Remote Blobs: {uploads + len(remote_csums)}" in captured.out.splitlines()
            # assert f"downloading {expected_downloads} blobs from remote" in captured.out.splitlines()
            assert captured.err == ""
            # download again, no blobs missing:
            r = dbg_ui(
                delnone([remote_type, "download", "userdata", "--quiet", url]), vol2
            )
            captured = capsys.readouterr()
            assert r == 0
            assert "Missing Blobs: 0" in captured.out.splitlines()
            assert "Successfully downloaded: 0 Blobs" in captured.out.splitlines()
            assert captured.err == ""
            # check blobs were added
            r = dbg_ui(delnone(["walk", "userdata"]), vol2)
            captured = capsys.readouterr()
            assert r == 0
            for csum in checksums:
                assert csum in captured.out.splitlines()


def test_farmfs_similarity(vol, capsys):
    a_path = build_dir(vol, "a")
    b_path = build_dir(vol, "b")
    for i in [1, 2, 3]:
        build_file(a_path, str(i), str(i))
    for i in [1, 2, 4, 5]:
        build_file(b_path, str(i), str(i))
    # Freeze
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0
    r = farmfs_ui(["similarity", "a", "b"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == "left\tboth\tright\tjaccard_similarity\n1\t2\t2\t0.4\n"


def test_redact(vol, capsys):
    # Create files with different patterns.
    a = build_file(vol, "a.txt", "a")
    b = Path("b.jpg", vol)
    b = build_file(vol, "b.jpg", "b")
    r = farmfs_ui(["freeze"], vol)
    captured = capsys.readouterr()
    assert r == 0

    # Create a snap with these files in it.
    r = farmfs_ui(["snap", "make", "testsnap"], vol)
    captured = capsys.readouterr()
    assert r == 0

    # Test what files would be redacted.
    r = dbg_ui(["redact", "pattern", "--noop", "*.txt", "testsnap"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == "redacted a.txt\n"

    # Verify that the filesystem wasn't changed.
    r = farmfs_ui(["snap", "restore", "testsnap"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert a.exists()
    assert b.exists()

    # Actually redact these files.
    r = dbg_ui(["redact", "pattern", "*.txt", "testsnap"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert captured.out == "redacted a.txt\n"

    # Verify that the snap has the pattern redacted.
    r = farmfs_ui(["snap", "restore", "testsnap"], vol)
    captured = capsys.readouterr()
    assert r == 0
    assert not a.exists()
    assert b.exists()


def test_farmfs_fetch(vol1: Path, vol2: Path, vol3: Path, capsys):
    # Setup: freeze a file in vol2 and make a snap
    build_file(vol2, "a", "hello")
    r = farmfs_ui(["freeze", "--quiet"], vol2)
    assert r == 0
    r = farmfs_ui(["snap", "make", "release"], vol2)
    assert r == 0

    # Add vol2 as remote on vol1
    r = farmfs_ui(["remote", "add", "origin", str(vol2)], vol1)
    assert r == 0

    # Fetch the snap
    r = farmfs_ui(["fetch", "--quiet", "origin", "release"], vol1)
    assert r == 0

    # Snap appears in vol1 under "origin/release"
    r = farmfs_ui(["snap", "list"], vol1)
    captured = capsys.readouterr()
    assert "origin/release" in captured.out.splitlines()

    # Blobs are now in vol1's blobstore
    fsvol1 = getvol(vol1)
    fsvol2 = getvol(vol2)
    snap2 = fsvol2.snapdb.read("release")
    for item in snap2:
        if item.is_link():
            assert fsvol1.bs.exists(item.csum())

    # Working tree of vol1 is untouched
    assert not vol1.join("a").exists()

    # Re-fetch same content is a no-op
    r = farmfs_ui(["fetch", "--quiet", "origin", "release"], vol1)
    captured = capsys.readouterr()
    assert r == 0
    assert "Already up to date" in captured.out

    # Make a new snap with different content on vol2
    build_file(vol2, "b", "world")
    r = farmfs_ui(["freeze", "--quiet"], vol2)
    assert r == 0
    r = farmfs_ui(["snap", "make", "--force", "release"], vol2)
    assert r == 0

    # Re-fetch changed snap without --force fails
    r = farmfs_ui(["fetch", "--quiet", "origin", "release"], vol1)
    captured = capsys.readouterr()
    assert r != 0
    assert "diverged" in captured.out

    # Re-fetch with --force succeeds
    r = farmfs_ui(["fetch", "--quiet", "--force", "origin", "release"], vol1)
    assert r == 0

    # Fetching a snap that doesn't exist on the remote raises
    with pytest.raises(ValueError):
        farmfs_ui(["fetch", "--quiet", "origin", "nonexistent"], vol1)

    # Fetch all snaps (no snap argument)
    r = farmfs_ui(["snap", "make", "v2"], vol2)
    assert r == 0
    r = farmfs_ui(["fetch", "--quiet", "origin"], vol1)
    assert r == 0
    r = farmfs_ui(["snap", "list"], vol1)
    captured = capsys.readouterr()
    snap_list = captured.out.splitlines()
    assert "origin/release" in snap_list
    assert "origin/v2" in snap_list

    # Fetch all remotes (no arguments) — add a second remote backed by vol3
    build_file(vol3, "c", "extra")
    r = farmfs_ui(["freeze", "--quiet"], vol3)
    assert r == 0
    r = farmfs_ui(["snap", "make", "snap3"], vol3)
    assert r == 0
    r = farmfs_ui(["remote", "add", "other", str(vol3)], vol1)
    assert r == 0
    r = farmfs_ui(["fetch", "--quiet"], vol1)
    assert r == 0
    r = farmfs_ui(["snap", "list"], vol1)
    captured = capsys.readouterr()
    snap_list = captured.out.splitlines()
    assert "origin/release" in snap_list
    assert "origin/v2" in snap_list
    assert "other/snap3" in snap_list
