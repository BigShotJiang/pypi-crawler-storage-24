"""Example scripts."""
