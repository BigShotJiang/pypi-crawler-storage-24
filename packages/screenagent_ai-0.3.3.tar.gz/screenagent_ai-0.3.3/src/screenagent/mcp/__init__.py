"""MCP server for screenagent."""
