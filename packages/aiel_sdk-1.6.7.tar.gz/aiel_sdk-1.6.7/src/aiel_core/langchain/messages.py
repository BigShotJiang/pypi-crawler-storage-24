from __future__ import annotations
from aiel_sdk.errors import RuntimeDependencyError

try:
    from langchain_core.messages import AIMessage, HumanMessage  # type: ignore
except Exception as e:  # pragma: no cover
    raise RuntimeDependencyError("langchain-core", "pip install 'aiel-sdk[langchain]'") from e

__all__ = ["AIMessage", "HumanMessage"]
