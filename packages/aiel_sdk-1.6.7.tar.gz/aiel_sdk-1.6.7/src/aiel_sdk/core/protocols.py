from __future__ import annotations

from typing import Any, List, Protocol, Sequence

from .types import ChatResponse, EmbeddingResponse, Message


class ChatModel(Protocol):
    def invoke(
        self,
        messages: Sequence[Message],
        **kwargs: Any,
    ) -> ChatResponse:
        ...


class EmbeddingModel(Protocol):
    def embed_query(self, text: str, **kwargs: Any) -> List[float]:
        ...

    def embed_documents(self, texts: Sequence[str], **kwargs: Any) -> List[List[float]]:
        ...

    def invoke(self, input: Any, **kwargs: Any) -> EmbeddingResponse:
        ...
