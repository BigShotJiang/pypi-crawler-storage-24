from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional

Json = Dict[str, Any]
Role = Literal["system", "user", "assistant", "tool"]


@dataclass(frozen=True)
class Message:
    role: Role
    content: Any
    name: Optional[str] = None
    tool_call_id: Optional[str] = None
    metadata: Json = field(default_factory=dict)


@dataclass(frozen=True)
class ChatResponse:
    message: Message
    raw: Json = field(default_factory=dict)


@dataclass(frozen=True)
class EmbeddingResponse:
    vectors: List[List[float]]
    raw: Json = field(default_factory=dict)
