try:
    from .langchain import AIELLangChainChatModel, AIELLangChainEmbeddings, make_messages_node
except Exception:  # pragma: no cover - optional dependency (langchain-core)
    AIELLangChainChatModel = None  # type: ignore[assignment]
    AIELLangChainEmbeddings = None  # type: ignore[assignment]
    make_messages_node = None  # type: ignore[assignment]

try:
    from .langgraph import AIELLangGraphCheckpointer
    from .langgraph import AIELLangGraphMemory
    from .langgraph import AIELLangGraphStore
except Exception:  # pragma: no cover - optional dependency (langgraph)
    AIELLangGraphCheckpointer = None  # type: ignore[assignment]
    AIELLangGraphMemory = None  # type: ignore[assignment]
    AIELLangGraphStore = None  # type: ignore[assignment]

__all__ = [
    "AIELLangChainChatModel",
    "AIELLangChainEmbeddings",
    "make_messages_node",
    "AIELLangGraphMemory",
    "AIELLangGraphCheckpointer",
    "AIELLangGraphStore",
]
