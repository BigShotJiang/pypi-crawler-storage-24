from __future__ import annotations

from typing import Any, Dict, List

from ...core.protocols import ChatModel
from ...core.types import Message


def make_messages_node(model: ChatModel):
    def _node(state: Dict[str, Any]) -> Dict[str, List[Message]]:
        messages = state["messages"]
        response = model.invoke(messages)
        # Append assistant output to existing conversation history.
        return {"messages": [*messages, response.message]}

    return _node
