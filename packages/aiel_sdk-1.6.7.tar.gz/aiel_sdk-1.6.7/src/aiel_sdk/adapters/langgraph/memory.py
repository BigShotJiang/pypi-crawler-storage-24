from __future__ import annotations

from ...memory.saver import Saver
from .checkpointer import AIELLangGraphCheckpointer
from .store import AIELLangGraphStore


class AIELLangGraphMemory:
    """
    Convenience wrapper to expose both LangGraph memory adapters from one Saver.

    Example:
        memory = AIELLangGraphMemory(saver)
        app = builder.compile(checkpointer=memory.checkpointer, store=memory.store)
    """

    def __init__(self, saver: Saver) -> None:
        self.saver = saver
        self.checkpointer = AIELLangGraphCheckpointer(saver)
        self.store = AIELLangGraphStore(saver)

