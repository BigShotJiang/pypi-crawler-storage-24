from __future__ import annotations

from abc import ABC, abstractmethod

from .types import (
    DEFAULT_FIREBASE_CAPABILITIES,
    FirebaseCapabilities,
    FirebaseDeleteResult,
    FirebaseDocDeleteRequest,
    FirebaseDocGetRequest,
    FirebaseDocPutRequest,
    FirebaseDocQueryRequest,
    FirebaseDocQueryResult,
    FirebaseDocResult,
    FirebasePingResult,
)


class FirebaseClient(ABC):
    @property
    def capabilities(self) -> FirebaseCapabilities:
        return DEFAULT_FIREBASE_CAPABILITIES

    @abstractmethod
    def doc_get(self, *, req: FirebaseDocGetRequest) -> FirebaseDocResult:
        raise NotImplementedError

    @abstractmethod
    def doc_put(self, *, req: FirebaseDocPutRequest) -> FirebaseDocResult:
        raise NotImplementedError

    @abstractmethod
    def doc_delete(self, *, req: FirebaseDocDeleteRequest) -> FirebaseDeleteResult:
        raise NotImplementedError

    @abstractmethod
    def doc_query(self, *, req: FirebaseDocQueryRequest) -> FirebaseDocQueryResult:
        raise NotImplementedError

    @abstractmethod
    def ping(self) -> FirebasePingResult:
        raise NotImplementedError
