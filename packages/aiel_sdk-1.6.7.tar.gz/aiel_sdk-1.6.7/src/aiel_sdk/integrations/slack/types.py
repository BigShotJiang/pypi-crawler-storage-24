"""
aiel_sdk.integrations.slack.types
=================================

Stable datatypes for the AIEL Slack SDK surface.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

Json = Dict[str, Any]


@dataclass(frozen=True)
class SlackPostMessageRequest:
    """Request payload for ``slack.post_message``."""

    channel: str
    text: str
    thread_ts: Optional[str] = None

    def validate(self) -> None:
        if not (self.channel or "").strip():
            raise ValueError("SlackPostMessageRequest.channel must be non-empty")
        if not (self.text or "").strip():
            raise ValueError("SlackPostMessageRequest.text must be non-empty")

    def to_params(self) -> Json:
        self.validate()
        out: Json = {"channel": self.channel, "text": self.text}
        if (self.thread_ts or "").strip():
            out["thread_ts"] = self.thread_ts
        return out


@dataclass(frozen=True)
class SlackAuthIdentity:
    """Typed view for ``slack.auth_test`` and ``slack.api_test`` responses."""

    user_id: Optional[str] = None
    user: Optional[str] = None
    team: Optional[str] = None
    team_id: Optional[str] = None
    url: Optional[str] = None
    bot_id: Optional[str] = None
    raw: Json = field(default_factory=dict)

    @staticmethod
    def from_json(payload: Json) -> "SlackAuthIdentity":
        return SlackAuthIdentity(
            user_id=payload.get("user_id"),
            user=payload.get("user"),
            team=payload.get("team"),
            team_id=payload.get("team_id"),
            url=payload.get("url"),
            bot_id=payload.get("bot_id"),
            raw=dict(payload or {}),
        )


@dataclass(frozen=True)
class SlackPostMessageResult:
    """Typed view for ``slack.post_message`` response."""

    ok: bool = False
    channel: Optional[str] = None
    ts: Optional[str] = None
    raw: Json = field(default_factory=dict)

    @staticmethod
    def from_json(payload: Json) -> "SlackPostMessageResult":
        return SlackPostMessageResult(
            ok=bool(payload.get("ok", False)),
            channel=payload.get("channel"),
            ts=payload.get("ts"),
            raw=dict(payload or {}),
        )


@dataclass(frozen=True)
class SlackCapability:
    id: str
    label: str
    description: str
    group: str
    group_label: str
    action: str


@dataclass(frozen=True)
class SlackCapabilities:
    items: Tuple[SlackCapability, ...]

    def ids(self) -> List[str]:
        return [c.id for c in self.items]

    def actions(self) -> List[str]:
        return [c.action for c in self.items]


DEFAULT_SLACK_CAPABILITIES = SlackCapabilities(
    items=(
        SlackCapability(
            id="slack:identity:read",
            label="Read Slack Identity",
            description="Read token identity and workspace details (auth_test/api_test).",
            group="Identity",
            group_label="Slack integration",
            action="slack.auth_test",
        ),
        SlackCapability(
            id="slack:message:create",
            label="Post Message",
            description="Post a message to a Slack channel.",
            group="Messaging",
            group_label="Slack integration",
            action="slack.post_message",
        ),
    )
)
