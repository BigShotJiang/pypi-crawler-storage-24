from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict

from .types import (
    DEFAULT_SLACK_CAPABILITIES,
    SlackAuthIdentity,
    SlackCapabilities,
    SlackPostMessageRequest,
    SlackPostMessageResult,
)

Json = Dict[str, Any]


class SlackClient(ABC):
    """Framework-agnostic Slack client for Integrations actions."""

    @property
    def capabilities(self) -> SlackCapabilities:
        return DEFAULT_SLACK_CAPABILITIES

    @abstractmethod
    def auth_test(self, *, use_api_test: bool = False) -> SlackAuthIdentity:
        raise NotImplementedError

    @abstractmethod
    def post_message(self, *, req: SlackPostMessageRequest) -> SlackPostMessageResult:
        raise NotImplementedError
