from __future__ import annotations

from abc import ABC, abstractmethod

from .types import (
    DEFAULT_OPENAI_CAPABILITIES,
    OpenAIActionResult,
    OpenAICapabilities,
    OpenAIChatCompletionsCreateRequest,
    OpenAIEmbeddingsCreateRequest,
    OpenAIPingResult,
    OpenAIResponsesCreateJsonRequest,
    OpenAIResponsesCreateRequest,
)


class OpenAIClient(ABC):
    @property
    def capabilities(self) -> OpenAICapabilities:
        return DEFAULT_OPENAI_CAPABILITIES

    @abstractmethod
    def responses_create(self, *, req: OpenAIResponsesCreateRequest) -> OpenAIActionResult:
        raise NotImplementedError

    @abstractmethod
    def responses_create_json(self, *, req: OpenAIResponsesCreateJsonRequest) -> OpenAIActionResult:
        raise NotImplementedError

    @abstractmethod
    def embeddings_create(self, *, req: OpenAIEmbeddingsCreateRequest) -> OpenAIActionResult:
        raise NotImplementedError

    @abstractmethod
    def chat_completions_create(self, *, req: OpenAIChatCompletionsCreateRequest) -> OpenAIActionResult:
        raise NotImplementedError

    @abstractmethod
    def ping(self) -> OpenAIPingResult:
        raise NotImplementedError
