"""
aiel_sdk.integrations.openai.remote
===================================

Remote-backed OpenAI operations via the AIEL Integrations API.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from ...client import AielClient
from .types import (
    DEFAULT_OPENAI_CAPABILITIES,
    OpenAIActionResult,
    OpenAICapabilities,
    OpenAIChatCompletionsCreateRequest,
    OpenAIEmbeddingsCreateRequest,
    OpenAIPingResult,
    OpenAIResponsesCreateJsonRequest,
    OpenAIResponsesCreateRequest,
)

Json = Dict[str, Any]


def _ensure_non_empty(value: str, name: str) -> str:
    v = (value or "").strip()
    if not v:
        raise ValueError(f"{name} must be non-empty")
    return v


class RemoteOpenAI:
    @property
    def capabilities(self) -> OpenAICapabilities:
        return DEFAULT_OPENAI_CAPABILITIES

    def __init__(
        self,
        client: AielClient,
        *,
        workspace_id: str,
        project_id: str,
        connection_id: str,
    ) -> None:
        self._c = client
        self._ws = _ensure_non_empty(workspace_id, "workspace_id")
        self._proj = _ensure_non_empty(project_id, "project_id")
        self._conn = _ensure_non_empty(connection_id, "connection_id")

    def _invoke(
        self,
        *,
        action: str,
        params: Optional[Json] = None,
        request_id: str | None = None,
    ) -> Any:
        return self._c.integrations.invoke_action(
            self._ws,
            self._proj,
            connection_id=self._conn,
            action=action,
            payload={"params": params or {}},
            request_id=request_id,
        )

    def responses_create(
        self,
        req: OpenAIResponsesCreateRequest,
        *,
        request_id: str | None = None,
    ) -> OpenAIActionResult:
        raw = self._invoke(action="openai.responses.create", params=req.to_params(), request_id=request_id)
        return OpenAIActionResult.from_json(raw if isinstance(raw, dict) else {"raw": raw})

    def responses_create_json(
        self,
        req: OpenAIResponsesCreateJsonRequest,
        *,
        request_id: str | None = None,
    ) -> OpenAIActionResult:
        raw = self._invoke(action="openai.responses.create_json", params=req.to_params(), request_id=request_id)
        return OpenAIActionResult.from_json(raw if isinstance(raw, dict) else {"raw": raw})

    def embeddings_create(
        self,
        req: OpenAIEmbeddingsCreateRequest,
        *,
        request_id: str | None = None,
    ) -> OpenAIActionResult:
        raw = self._invoke(action="openai.embeddings.create", params=req.to_params(), request_id=request_id)
        return OpenAIActionResult.from_json(raw if isinstance(raw, dict) else {"raw": raw})

    def chat_completions_create(
        self,
        req: OpenAIChatCompletionsCreateRequest,
        *,
        request_id: str | None = None,
    ) -> OpenAIActionResult:
        raw = self._invoke(action="openai.chat.completions.create", params=req.to_params(), request_id=request_id)
        return OpenAIActionResult.from_json(raw if isinstance(raw, dict) else {"raw": raw})

    def ping(self, *, request_id: str | None = None) -> OpenAIPingResult:
        raw = self._invoke(action="openai.ping", params={}, request_id=request_id)
        return OpenAIPingResult.from_json(raw if isinstance(raw, dict) else {"raw": raw})
