# tests/test_config.py
import pytest
import tomlkit
from pathlib import Path
from tickticksync.config import load_config, save_config_auth, save_config_mapping, save_config_full, update_config_value, MappingConfig, ProjectMapping, SyncConfig


def test_load_minimal_config(tmp_config):
    cfg = load_config(tmp_config)
    assert cfg.ticktick.client_id == "test_id"
    assert cfg.ticktick.client_secret == "test_secret"


def test_sync_defaults(tmp_config):
    cfg = load_config(tmp_config)
    assert cfg.sync.poll_interval == 60
    assert cfg.sync.batch_window == 5
    assert cfg.sync.socket_path == "/tmp/tickticksync.sock"


def test_mapping_defaults(tmp_config):
    cfg = load_config(tmp_config)
    assert cfg.mapping.default_project == "inbox"


def test_missing_client_id_raises(tmp_path):
    bad = tmp_path / "bad.toml"
    bad.write_text("[ticktick]\nclient_secret = 'x'\n")
    with pytest.raises((KeyError, TypeError)):
        load_config(bad)


def test_custom_poll_interval(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text("""
[ticktick]
client_id = "id"
client_secret = "secret"
[sync]
poll_interval = 30
""")
    cfg = load_config(cfg_path)
    assert cfg.sync.poll_interval == 30


def test_save_config_auth_oauth(tmp_config):
    save_config_auth(tmp_config, "oauth")
    cfg = load_config(tmp_config)
    assert cfg.auth.method == "oauth"
    assert cfg.auth.username is None


def test_save_config_auth_password_with_username(tmp_config):
    save_config_auth(tmp_config, "password", "user@example.com")
    cfg = load_config(tmp_config)
    assert cfg.auth.method == "password"
    assert cfg.auth.username == "user@example.com"


def test_save_config_auth_preserves_other_sections(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text(
        '[ticktick]\nclient_id = "id"\nclient_secret = "secret"\n\n'
        "[sync]\npoll_interval = 120\n"
    )
    save_config_auth(cfg_path, "password", "me@example.com")
    cfg = load_config(cfg_path)
    assert cfg.sync.poll_interval == 120
    assert cfg.auth.method == "password"
    assert cfg.auth.username == "me@example.com"


def test_save_config_auth_creates_auth_from_scratch(tmp_path):
    cfg_path = tmp_path / "missing.toml"
    save_config_auth(cfg_path, "oauth")
    text = cfg_path.read_text()
    assert "oauth" in text


def test_load_config_with_auth_section(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text(
        '[ticktick]\nclient_id = "id"\nclient_secret = "secret"\n\n'
        '[auth]\nmethod = "password"\nusername = "u@e.com"\n'
    )
    cfg = load_config(cfg_path)
    assert cfg.auth.method == "password"
    assert cfg.auth.username == "u@e.com"


def test_load_config_invalid_auth_method(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text(
        '[ticktick]\nclient_id = "id"\nclient_secret = "secret"\n\n'
        '[auth]\nmethod = "oath"\n'
    )
    with pytest.raises(ValueError, match="Invalid auth.method"):
        load_config(cfg_path)


def test_project_mapping_fields():
    pm = ProjectMapping(ticktick="Inbox", taskwarrior="inbox")
    assert pm.ticktick == "Inbox"
    assert pm.taskwarrior == "inbox"


def test_mapping_config_projects_default():
    mc = MappingConfig()
    assert mc.projects == []
    assert isinstance(mc.projects, list)


def test_load_config_with_project_mappings(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text("""\
[ticktick]
client_id = "id"
client_secret = "secret"

[mapping]
default_project = "inbox"

[[mapping.projects]]
ticktick = "Inbox"
taskwarrior = "inbox"

[[mapping.projects]]
ticktick = "Work"
taskwarrior = "work"
""")
    cfg = load_config(cfg_path)
    assert len(cfg.mapping.projects) == 2
    assert cfg.mapping.projects[0].ticktick == "Inbox"
    assert cfg.mapping.projects[0].taskwarrior == "inbox"
    assert cfg.mapping.projects[1].ticktick == "Work"
    assert cfg.mapping.projects[1].taskwarrior == "work"


def test_load_config_without_project_mappings(tmp_config):
    cfg = load_config(tmp_config)
    assert cfg.mapping.projects == []


def test_save_config_mapping_roundtrip(tmp_config):
    projects = [
        ProjectMapping(ticktick="Inbox", taskwarrior="inbox"),
        ProjectMapping(ticktick="Work", taskwarrior="work"),
    ]
    save_config_mapping(tmp_config, projects)
    cfg = load_config(tmp_config)
    assert len(cfg.mapping.projects) == 2
    assert cfg.mapping.projects[0].ticktick == "Inbox"
    assert cfg.mapping.projects[1].taskwarrior == "work"


def test_save_config_mapping_preserves_other_sections(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text("""\
[ticktick]
client_id = "id"
client_secret = "secret"

[sync]
poll_interval = 120

[auth]
method = "password"
username = "me@example.com"
""")
    projects = [ProjectMapping(ticktick="Inbox", taskwarrior="inbox")]
    save_config_mapping(cfg_path, projects)
    cfg = load_config(cfg_path)
    assert cfg.ticktick.client_id == "id"
    assert cfg.sync.poll_interval == 120
    assert cfg.auth.method == "password"
    assert cfg.auth.username == "me@example.com"
    assert len(cfg.mapping.projects) == 1


def test_save_config_mapping_empty_list(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text("""\
[ticktick]
client_id = "id"
client_secret = "secret"

[[mapping.projects]]
ticktick = "Old"
taskwarrior = "old"
""")
    save_config_mapping(cfg_path, [])
    cfg = load_config(cfg_path)
    assert cfg.mapping.projects == []


def test_save_config_mapping_overwrites_existing(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text("""\
[ticktick]
client_id = "id"
client_secret = "secret"

[[mapping.projects]]
ticktick = "Old"
taskwarrior = "old"
""")
    projects = [ProjectMapping(ticktick="New", taskwarrior="new")]
    save_config_mapping(cfg_path, projects)
    cfg = load_config(cfg_path)
    assert len(cfg.mapping.projects) == 1
    assert cfg.mapping.projects[0].ticktick == "New"


def test_load_config_duplicate_project_names(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text("""\
[ticktick]
client_id = "id"
client_secret = "secret"

[[mapping.projects]]
ticktick = "Inbox"
taskwarrior = "inbox"

[[mapping.projects]]
ticktick = "Inbox"
taskwarrior = "inbox_dup"
""")
    cfg = load_config(cfg_path)
    assert len(cfg.mapping.projects) == 2


def test_save_config_mapping_creates_from_scratch(tmp_path):
    cfg_path = tmp_path / "new.toml"
    projects = [ProjectMapping(ticktick="Inbox", taskwarrior="inbox")]
    save_config_mapping(cfg_path, projects)
    text = cfg_path.read_text()
    assert "ticktick" in text
    assert "taskwarrior" in text


def test_save_config_full_writes_all_sections(tmp_path: Path):
    """save_config_full writes a complete config with all sections."""
    config_path = tmp_path / "config.toml"

    save_config_full(
        path=config_path,
        client_id="my_cid",
        client_secret="my_csec",
        auth_method="oauth",
        poll_interval=120,
        socket_path="/tmp/custom.sock",
        projects=[
            ProjectMapping(ticktick="Inbox", taskwarrior="inbox"),
            ProjectMapping(ticktick="Work", taskwarrior="work"),
        ],
    )

    doc = tomlkit.parse(config_path.read_text())
    assert doc["ticktick"]["client_id"] == "my_cid"
    assert doc["ticktick"]["client_secret"] == "my_csec"
    assert doc["auth"]["method"] == "oauth"
    assert doc["sync"]["poll_interval"] == 120
    assert doc["sync"]["batch_window"] == SyncConfig.batch_window
    assert doc["sync"]["socket_path"] == "/tmp/custom.sock"
    assert doc["sync"]["queue_path"] == SyncConfig.queue_path
    assert doc["mapping"]["default_project"] == "inbox"
    projects = doc["mapping"]["projects"]
    assert len(projects) == 2
    assert projects[0]["ticktick"] == "Inbox"
    assert projects[1]["taskwarrior"] == "work"


def test_save_config_full_with_password_auth(tmp_path: Path):
    """save_config_full includes username when auth method is password."""
    config_path = tmp_path / "config.toml"

    save_config_full(
        path=config_path,
        client_id="cid",
        client_secret="csec",
        auth_method="password",
        auth_username="user@example.com",
        poll_interval=60,
        socket_path="/tmp/tickticksync.sock",
        projects=[],
    )

    doc = tomlkit.parse(config_path.read_text())
    assert doc["auth"]["method"] == "password"
    assert doc["auth"]["username"] == "user@example.com"


def test_save_config_full_no_projects(tmp_path: Path):
    """save_config_full works with empty project list."""
    config_path = tmp_path / "config.toml"

    save_config_full(
        path=config_path,
        client_id="cid",
        client_secret="csec",
        auth_method="oauth",
        poll_interval=60,
        socket_path="/tmp/tickticksync.sock",
        projects=[],
    )

    doc = tomlkit.parse(config_path.read_text())
    assert "ticktick" in doc
    assert "auth" in doc
    assert "sync" in doc
    assert "mapping" in doc
    assert doc["mapping"]["default_project"] == "inbox"


def test_save_config_full_preserves_default_project(tmp_path: Path):
    """save_config_full respects an explicit default_project parameter."""
    cfg_path = tmp_path / "config.toml"
    save_config_full(
        cfg_path,
        client_id="cid",
        client_secret="csec",
        auth_method="oauth",
        poll_interval=60,
        socket_path="/tmp/tickticksync.sock",
        projects=[],
        default_project="work",
    )
    loaded = load_config(cfg_path)
    assert loaded.mapping.default_project == "work"


def test_update_config_value_sync_key(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text('[ticktick]\nclient_id = "id"\nclient_secret = "secret"\n\n[sync]\npoll_interval = 60\n')
    update_config_value(cfg_path, "sync", "poll_interval", 120)
    cfg = load_config(cfg_path)
    assert cfg.sync.poll_interval == 120


def test_update_config_value_preserves_other_sections(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text(
        '[ticktick]\nclient_id = "id"\nclient_secret = "secret"\n\n'
        '[sync]\npoll_interval = 60\n\n'
        '[auth]\nmethod = "password"\nusername = "u@e.com"\n'
    )
    update_config_value(cfg_path, "sync", "poll_interval", 120)
    cfg = load_config(cfg_path)
    assert cfg.auth.method == "password"
    assert cfg.auth.username == "u@e.com"
    assert cfg.ticktick.client_id == "id"


def test_update_config_value_creates_section_if_missing(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text('[ticktick]\nclient_id = "id"\nclient_secret = "secret"\n')
    update_config_value(cfg_path, "sync", "poll_interval", 90)
    cfg = load_config(cfg_path)
    assert cfg.sync.poll_interval == 90


def test_update_config_value_mapping_default_project(tmp_path):
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text('[ticktick]\nclient_id = "id"\nclient_secret = "secret"\n\n[mapping]\ndefault_project = "inbox"\n')
    update_config_value(cfg_path, "mapping", "default_project", "work")
    cfg = load_config(cfg_path)
    assert cfg.mapping.default_project == "work"


def test_update_config_value_mapping_default_project_with_projects(tmp_path):
    """update_config_value preserves [[mapping.projects]] AoT when changing default_project."""
    cfg_path = tmp_path / "config.toml"
    cfg_path.write_text(
        '[ticktick]\nclient_id = "id"\nclient_secret = "secret"\n\n'
        '[mapping]\ndefault_project = "inbox"\n\n'
        '[[mapping.projects]]\nticktick = "Inbox"\ntaskwarrior = "inbox"\n'
    )
    update_config_value(cfg_path, "mapping", "default_project", "work")
    cfg = load_config(cfg_path)
    assert cfg.mapping.default_project == "work"
    assert len(cfg.mapping.projects) == 1
    assert cfg.mapping.projects[0].ticktick == "Inbox"


def test_sync_config_preserves_tilde_in_queue_path():
    """SyncConfig stores the raw tilde string without eager expansion."""
    sc = SyncConfig(queue_path="~/.local/share/tickticksync/hook_queue.json")
    assert sc.queue_path == "~/.local/share/tickticksync/hook_queue.json"


def test_sync_config_resolved_paths_expand_tilde():
    """resolved_socket_path / resolved_queue_path expand ~ to absolute paths."""
    sc = SyncConfig(
        socket_path="~/sockets/test.sock",
        queue_path="~/.local/share/tickticksync/hook_queue.json",
    )
    assert "~" not in sc.resolved_socket_path
    assert sc.resolved_socket_path.endswith("/sockets/test.sock")
    assert "~" not in sc.resolved_queue_path
    assert sc.resolved_queue_path.endswith("/.local/share/tickticksync/hook_queue.json")
