"""Scrape service for single URL content extraction.

Anti-Bot Features (automatic, no configuration needed):
    - Basic fingerprint evasion: navigator.webdriver=false, chrome runtime objects,
      plugins array, languages array, WebGL vendor spoofing, canvas noise
    - Standard browser headers: Accept-Language, Sec-Fetch-*, etc.
    - Automatic bot detection: Detects 403/429/503, CAPTCHA pages, Cloudflare challenges

Enhanced Stealth (optional, for heavily protected sites):
    - Install: pip install supacrawl[stealth]
    - Auto-retry: If bot detection is suspected, automatically retries with Patchright
    - Force stealth: Use stealth=True or --stealth flag

CAPTCHA Solving (optional, requires third-party service):
    - Install: pip install supacrawl[captcha]
    - Configure: export CAPTCHA_API_KEY=your-2captcha-api-key
    - Usage: Use solve_captcha=True or --solve-captcha flag
    - Supports: reCAPTCHA v2/v3, hCaptcha, Cloudflare Turnstile
    - COST WARNING: ~$2-3 per 1000 solves
"""

import base64
import logging
import re
from collections.abc import Sequence
from pathlib import Path
from typing import Any, Literal

from bs4 import BeautifulSoup

from supacrawl.cache import CacheManager
from supacrawl.exceptions import ProviderError
from supacrawl.models import ActionsOutput, ScrapeActionResult, ScrapeData, ScrapeMetadata, ScrapeResult
from supacrawl.services.browser import BrowserManager
from supacrawl.services.converter import MarkdownConverter

LOGGER = logging.getLogger(__name__)

# Type alias for wait_until options
type WaitUntilType = Literal["commit", "domcontentloaded", "load", "networkidle"]

# Patterns that indicate bot detection or blocking
BOT_DETECTION_PATTERNS = [
    r"captcha",
    r"challenge",
    r"cloudflare",
    r"ddos.protection",
    r"access.denied",
    r"blocked",
    r"robot",
    r"bot.detection",
    r"verify.you.are.human",
    r"please.wait",
    r"checking.your.browser",
    r"just.a.moment",
    r"enable.javascript",
    r"ray.id",  # Cloudflare Ray ID
]
BOT_DETECTION_REGEX = re.compile("|".join(BOT_DETECTION_PATTERNS), re.IGNORECASE)


def _is_patchright_available() -> bool:
    """Check if patchright is installed for stealth mode."""
    try:
        import patchright  # noqa: F401

        return True
    except ImportError:
        return False


def _looks_like_bot_block(status_code: int, html: str, markdown: str | None) -> bool:
    """Detect if a response looks like bot detection or blocking.

    Args:
        status_code: HTTP status code
        html: Raw HTML content
        markdown: Converted markdown content

    Returns:
        True if bot detection is suspected
    """
    # Check status codes that indicate blocking
    if status_code in (403, 429, 503):
        LOGGER.debug(f"Bot detection suspected: HTTP {status_code}")
        return True

    # Check for very short content (likely a challenge page)
    content_length = len(html) if html else 0
    if content_length < 500:
        # Very short page - might be a redirect or challenge
        if BOT_DETECTION_REGEX.search(html):
            LOGGER.debug("Bot detection suspected: short page with blocking patterns")
            return True

    # Check for bot detection patterns in HTML
    if BOT_DETECTION_REGEX.search(html):
        # Also check if content is suspiciously short for a real page
        word_count = len(markdown.split()) if markdown else 0
        if word_count < 50:
            LOGGER.debug("Bot detection suspected: blocking patterns with low word count")
            return True

    return False


def _is_camoufox_available() -> bool:
    """Check if camoufox is installed for Tier 3 anti-detection."""
    try:
        import camoufox  # noqa: F401

        return True
    except ImportError:
        return False


def _stealth_hint() -> str:
    """Return a hint about stealth mode based on availability.

    Returns a structured hint for both humans and LLM consumers.
    Basic stealth (fingerprint evasion) is always active.
    This hint covers both Patchright (Tier 2) and Camoufox (Tier 3).
    """
    if _is_patchright_available():
        hint = (
            " [HINT: Basic anti-bot evasion is already active. "
            "For enhanced stealth, use --stealth flag or --engine patchright."
        )
        if _is_camoufox_available():
            hint += " For Akamai/advanced protection, use --engine camoufox."
        hint += "]"
        return hint
    elif _is_camoufox_available():
        return " [HINT: Basic anti-bot evasion is active. For Akamai/advanced protection, use --engine camoufox]"
    else:
        return (
            " [HINT: Basic anti-bot evasion is active but site may need enhanced stealth. "
            "Install with: pip install supacrawl[stealth] (Cloudflare) "
            "or pip install supacrawl[camoufox] (Akamai)]"
        )


def _is_captcha_available() -> bool:
    """Check if 2captcha-python is installed for CAPTCHA solving."""
    try:
        import twocaptcha  # noqa: F401

        return True
    except ImportError:
        return False


def _captcha_hint() -> str:
    """Return a hint about CAPTCHA solving based on availability.

    Returns a structured hint for both humans and LLM consumers.
    """
    if _is_captcha_available():
        import os

        if os.environ.get("CAPTCHA_API_KEY"):
            return (
                " [HINT: CAPTCHA detected. Use --solve-captcha flag to auto-solve. "
                "WARNING: Each solve costs ~$0.002-0.003]"
            )
        else:
            return (
                " [HINT: CAPTCHA detected. CAPTCHA solving is installed but not configured. "
                "Set CAPTCHA_API_KEY environment variable, then use --solve-captcha]"
            )
    else:
        return (
            " [HINT: CAPTCHA detected. To auto-solve CAPTCHAs: "
            "1) pip install supacrawl[captcha]"
            "2) export CAPTCHA_API_KEY=your-2captcha-api-key "
            "3) use --solve-captcha flag. WARNING: Each solve costs ~$0.002-0.003]"
        )


def _compute_content_hash(markdown: str | None) -> str:
    """Compute SHA256 hash of markdown content for change tracking.

    Args:
        markdown: Markdown content to hash. None or empty string produces
            a hash of the empty string.

    Returns:
        Hex-encoded SHA256 hash string.
    """
    import hashlib

    content = (markdown or "").encode("utf-8")
    return hashlib.sha256(content).hexdigest()


def _build_change_tracking(
    previous_entry: Any | None,
    current_hash: str,
    current_markdown: str | None,
    change_tracking_modes: list[str] | None = None,
) -> Any:
    """Build change tracking data by comparing current scrape to cached previous.

    Args:
        previous_entry: Previous CacheEntry (from get_previous), or None.
        current_hash: SHA256 hash of current markdown content.
        current_markdown: Current markdown content (for diff generation).
        change_tracking_modes: Optional list of diff modes (e.g. ["git-diff"]).

    Returns:
        ChangeTrackingData with change status and optional diff.
    """
    from supacrawl.models import ChangeTrackingData

    if previous_entry is None:
        return ChangeTrackingData(
            change_status="new",
            content_hash=current_hash,
        )

    previous_hash = previous_entry.content_hash
    previous_scrape_at = previous_entry.cached_at

    # Fast path: hash comparison
    if previous_hash is not None and previous_hash == current_hash:
        return ChangeTrackingData(
            previous_scrape_at=previous_scrape_at,
            change_status="same",
            content_hash=current_hash,
        )

    # Content has changed (or no previous hash to compare — treat as changed)
    diff = None
    if change_tracking_modes and "git-diff" in change_tracking_modes:
        diff = _generate_unified_diff(previous_entry, current_markdown)

    return ChangeTrackingData(
        previous_scrape_at=previous_scrape_at,
        change_status="changed",
        content_hash=current_hash,
        diff=diff,
    )


def _generate_unified_diff(
    previous_entry: Any,
    current_markdown: str | None,
) -> Any:
    """Generate a unified diff between previous and current markdown.

    Args:
        previous_entry: Previous CacheEntry containing the cached response.
        current_markdown: Current markdown content.

    Returns:
        ChangeTrackingDiff with unified diff text, or None if unable to diff.
    """
    import difflib

    from supacrawl.models import ChangeTrackingDiff

    # Extract previous markdown from cached response
    prev_markdown = ""
    try:
        prev_data = previous_entry.response.get("data", {})
        prev_markdown = prev_data.get("markdown") or ""
    except (AttributeError, TypeError):
        return None

    curr_markdown = current_markdown or ""

    prev_lines = prev_markdown.splitlines(keepends=True)
    curr_lines = curr_markdown.splitlines(keepends=True)

    diff_lines = list(
        difflib.unified_diff(
            prev_lines,
            curr_lines,
            fromfile="previous",
            tofile="current",
        )
    )

    if not diff_lines:
        return None

    return ChangeTrackingDiff(text="".join(diff_lines))


class ScrapeService:
    """Scrape a single URL and extract content.

    IMPORTANT FOR LLM/AGENT USERS:
        This service has built-in anti-bot protection that works automatically.
        You do NOT need to configure anything for basic scraping.

    What Works Automatically (no configuration):
        - Fingerprint evasion (webdriver, plugins, WebGL, canvas)
        - Standard browser headers (Accept-Language, Sec-Fetch-*, etc.)
        - Bot detection (403/429/503, CAPTCHA, Cloudflare challenges)
        - Auto-retry with enhanced stealth if patchright is installed

    When You Might Need Enhanced Stealth:
        - Error message contains "[HINT:" with stealth suggestion
        - Getting empty content from sites that should have content
        - Seeing "Access Denied", "Please verify you are human", etc.
        - Solution: Install supacrawl[stealth] and use stealth=True

    When You Might Need CAPTCHA Solving:
        - Error message contains "[HINT: CAPTCHA detected"
        - Site requires human verification that cannot be bypassed
        - Solution: Install supacrawl[captcha], set CAPTCHA_API_KEY, use solve_captcha=True
        - WARNING: CAPTCHA solving costs money (~$0.002-0.003 per solve)

    Usage:
        # Basic scraping - anti-bot evasion is automatic
        service = ScrapeService()
        result = await service.scrape("https://example.com")
        print(result.data.markdown)

        # With caching (recommended for repeated requests)
        service = ScrapeService(cache_dir=Path("~/.supacrawl/cache"))
        result = await service.scrape("https://example.com", max_age=3600)

        # Force enhanced stealth (for heavily protected sites)
        # Requires: pip install supacrawl[stealth]
        service = ScrapeService(stealth=True)
        result = await service.scrape("https://protected-site.com")

        # With CAPTCHA solving (for sites with mandatory verification)
        # Requires: pip install supacrawl[captcha] and CAPTCHA_API_KEY env var
        service = ScrapeService(stealth=True, solve_captcha=True)
        result = await service.scrape("https://captcha-protected-site.com")

    Returns:
        ScrapeResult with success=True/False, data (ScrapeData), and error message.
        Check result.success before accessing result.data.
    """

    def __init__(
        self,
        browser: BrowserManager | None = None,
        converter: MarkdownConverter | None = None,
        locale_config: Any | None = None,  # LocaleConfig, avoid circular import
        cache_dir: Path | None = None,
        stealth: bool = False,
        proxy: str | None = None,
        solve_captcha: bool = False,
        headless: bool | None = None,
        engine: str | None = None,
        firefox_user_prefs: dict[str, Any] | None = None,
    ):
        """Initialize scrape service.

        Args:
            browser: Optional BrowserManager (created if not provided)
            converter: Optional MarkdownConverter (created if not provided)
            locale_config: Optional LocaleConfig for browser locale/timezone settings
            cache_dir: Optional cache directory (enables caching if provided)
            stealth: Enable stealth mode via Patchright for anti-bot evasion.
                Ignored when engine is explicitly set.
            proxy: Proxy URL (e.g., http://user:pass@host:port, socks5://host:port)
            solve_captcha: Enable CAPTCHA solving via 2Captcha (requires pip install supacrawl[captcha]
                          and CAPTCHA_API_KEY environment variable). WARNING: Each solve costs ~$0.002-0.003.
            headless: Run browser in headless mode. Passed through to any BrowserManager
                instances created internally (e.g. for CAPTCHA solving or standalone usage).
            engine: Browser engine to use ("playwright", "patchright", "camoufox").
                Overrides the stealth flag when set.
            firefox_user_prefs: Firefox about:config preferences for Camoufox.
                Only used when engine="camoufox" and browser is created internally.
                Example: {"network.http.http2.enabled": False} to force HTTP/1.1.
        """
        self._browser = browser
        self._converter = converter or MarkdownConverter()
        self._owns_browser = browser is None
        self._locale_config = locale_config
        self._stealth = stealth
        self._proxy = proxy
        self._solve_captcha = solve_captcha
        self._headless = headless
        self._engine = engine
        self._firefox_user_prefs = firefox_user_prefs
        self._cache = CacheManager(cache_dir) if cache_dir else None
        self._captcha_solver: Any = None  # Lazy-loaded CaptchaSolver

    async def scrape(
        self,
        url: str,
        formats: list[
            Literal[
                "markdown",
                "html",
                "rawHtml",
                "links",
                "screenshot",
                "pdf",
                "json",
                "images",
                "branding",
                "summary",
                "changeTracking",
            ]
        ]
        | None = None,
        only_main_content: bool = True,
        wait_for: int = 0,
        timeout: int = 30000,
        screenshot_full_page: bool = True,
        actions: list[Any] | None = None,
        json_schema: dict[str, Any] | None = None,
        json_prompt: str | None = None,
        include_tags: list[str] | None = None,
        exclude_tags: list[str] | None = None,
        max_age: int = 0,
        wait_until: WaitUntilType | None = None,
        change_tracking_modes: list[str] | None = None,
        expand_iframes: Literal["none", "same-origin", "all"] = "same-origin",
        device: str | None = None,
        parse_pdf: Literal["fast", "auto", "ocr"] | None = "auto",
        engine: str | None = None,
    ) -> ScrapeResult:
        """Scrape a URL and return content.

        Args:
            url: URL to scrape
            formats: Content formats to return (default: ["markdown"])
                     Supports: markdown, html, rawHtml, links, screenshot, pdf,
                     json, images, branding, summary, changeTracking
            only_main_content: Extract main content area only
            wait_for: Additional wait time in ms after page load. When > 0,
                     also enables SPA stability polling (DOM hash checking).
            timeout: Page load timeout in ms
            screenshot_full_page: Capture full scrollable page for screenshots
            actions: List of Action objects to execute before capturing content
                     Supports: wait, click, type, scroll, screenshot, press, executeJavascript
            json_schema: JSON schema for structured extraction (for json format)
            json_prompt: Custom prompt for extraction (for json format)
            include_tags: CSS selectors for elements to include.
                         When specified, takes precedence over only_main_content.
            exclude_tags: CSS selectors for elements to exclude.
                         Applied before include_tags filtering.
            max_age: Cache freshness in seconds. 0 = no cache.
                    Returns cached content if available and fresh.
            wait_until: Page load strategy. Options: commit, domcontentloaded (default),
                       load, networkidle. Falls back to SUPACRAWL_WAIT_UNTIL env var if None.
            change_tracking_modes: Optional diff modes for change tracking.
                    Supports: ["git-diff"]. Only used when "changeTracking" is in formats.
            expand_iframes: Iframe expansion mode. "none" strips all (legacy),
                    "same-origin" expands same-origin iframes inline (default),
                    "all" expands all non-blocked iframes including cross-origin.
            device: Playwright device name for mobile emulation (e.g. "iPhone 14",
                    "Pixel 7"). Sets viewport, user agent, device scale factor, and
                    touch support. Use ``--mobile`` as a shortcut for a default device.
            parse_pdf: PDF parsing mode. "auto" (default) detects PDF URLs by
                    file extension (.pdf) and extracts text, falling back to OCR
                    if available. "fast" uses text extraction only. "ocr" forces
                    OCR. None disables PDF parsing entirely.
            engine: Browser engine override for this request. When set and different
                    from the service's default engine, a temporary browser is created.
                    Options: "playwright", "patchright", "camoufox".

        Returns:
            ScrapeResult with scraped content
        """
        formats = formats or ["markdown"]
        wants_change_tracking = "changeTracking" in formats

        # Change tracking requires markdown to compute content hash
        if wants_change_tracking and "markdown" not in formats:
            formats = [*formats, "markdown"]

        # Build cache variant for settings that affect output.
        # Different settings produce different content, so they must map to
        # separate cache entries.
        variant_parts: list[str] = []
        if device:
            variant_parts.append(f"device={device}")
        if "screenshot" in formats and not screenshot_full_page:
            variant_parts.append("screenshot_full_page=False")
        cache_variant: str | None = "|".join(variant_parts) if variant_parts else None

        # Get previous cached entry for change tracking comparison (ignores expiry)
        previous_entry = None
        if wants_change_tracking and self._cache:
            previous_entry = self._cache.get_previous(url, variant=cache_variant)

        # Check cache if max_age > 0 and cache is configured
        # When change tracking is requested, skip the cache shortcut — always do a fresh scrape
        if max_age > 0 and self._cache and not wants_change_tracking:
            cached = self._cache.get(url, max_age, variant=cache_variant)
            if cached:
                LOGGER.debug(f"Cache hit for {url}")
                result = ScrapeResult.model_validate(cached)
                # Mark as cache hit
                if result.data and result.data.metadata:
                    result.data.metadata.cache_hit = True
                return result

        # PDF detection: if parse_pdf is enabled, check if URL points to a PDF
        # and route to the PDF extraction pipeline instead of the browser.
        # Only checks the .pdf file extension — no HEAD requests are sent to
        # avoid per-URL network overhead during bulk scraping.
        if parse_pdf is not None:
            from supacrawl.services.pdf import is_pdf_url

            is_pdf = is_pdf_url(url)

            if is_pdf:
                return await self._scrape_pdf(
                    url=url,
                    mode=parse_pdf,
                    formats=formats,
                    json_schema=json_schema,
                    json_prompt=json_prompt,
                    max_age=max_age,
                    cache_variant=cache_variant,
                    wants_change_tracking=wants_change_tracking,
                    previous_entry=previous_entry,
                    change_tracking_modes=change_tracking_modes,
                )

        try:
            # Determine effective engine for this request
            effective_engine = engine or self._engine

            # Create browser if needed, or use a temporary one for engine override
            browser = self._browser
            owns_browser = self._owns_browser

            # Per-request engine override: if the caller requested a different engine
            # than the shared browser, create a temporary browser for this request.
            needs_engine_override = (
                engine is not None and not owns_browser and browser is not None and browser.engine != engine
            )

            if owns_browser or needs_engine_override:
                browser = BrowserManager(
                    headless=self._headless,
                    timeout_ms=timeout,
                    locale_config=self._locale_config,
                    stealth=self._stealth,
                    proxy=self._proxy,
                    engine=effective_engine,
                    firefox_user_prefs=self._firefox_user_prefs,
                )
                await browser.__aenter__()
                owns_browser = True

            # At this point browser is guaranteed to be set
            if browser is None:
                raise RuntimeError("Browser not initialized")

            try:
                # Determine if we need screenshot or PDF capture
                capture_screenshot = "screenshot" in formats
                capture_pdf = "pdf" in formats

                # Fetch page with actions
                page_content = await browser.fetch_page(
                    url,
                    wait_for_spa=wait_for > 0,
                    spa_timeout_ms=wait_for,
                    capture_screenshot=capture_screenshot,
                    capture_pdf=capture_pdf,
                    screenshot_full_page=screenshot_full_page,
                    actions=actions,
                    wait_until=wait_until,
                    expand_iframes=expand_iframes,
                    device=device,
                )

                # Extract metadata
                metadata = await browser.extract_metadata(page_content.html)

                # Build response based on requested formats
                markdown = None
                html = None
                raw_html = None
                links = None
                images = None
                branding = None
                summary = None
                screenshot_b64 = None
                pdf_b64 = None
                json_data = None

                if "markdown" in formats or "json" in formats or "summary" in formats:
                    # Always need markdown for JSON extraction and summary generation
                    markdown = self._converter.convert(
                        page_content.html,
                        base_url=url,
                        only_main_content=only_main_content,
                        include_tags=include_tags,
                        exclude_tags=exclude_tags,
                    )

                # Check for bot detection and auto-retry with stealth if available
                if not self._stealth and _looks_like_bot_block(page_content.status_code, page_content.html, markdown):
                    if _is_patchright_available():
                        LOGGER.info(f"Bot detection suspected for {url}, retrying with stealth mode")
                        # Close current browser and retry with stealth
                        if owns_browser and browser:
                            await browser.__aexit__(None, None, None)

                        # Create stealth service and retry
                        stealth_service = ScrapeService(
                            converter=self._converter,
                            locale_config=self._locale_config,
                            cache_dir=self._cache.cache_dir if self._cache else None,
                            stealth=True,
                            proxy=self._proxy,
                            solve_captcha=self._solve_captcha,
                            headless=self._headless,
                        )
                        return await stealth_service.scrape(
                            url=url,
                            formats=formats,
                            only_main_content=only_main_content,
                            wait_for=wait_for,
                            timeout=timeout,
                            screenshot_full_page=screenshot_full_page,
                            actions=actions,
                            json_schema=json_schema,
                            json_prompt=json_prompt,
                            include_tags=include_tags,
                            exclude_tags=exclude_tags,
                            max_age=max_age,
                            wait_until=wait_until,
                            change_tracking_modes=change_tracking_modes,
                            expand_iframes=expand_iframes,
                            device=device,
                            parse_pdf=parse_pdf,
                        )
                    else:
                        LOGGER.warning(f"Bot detection suspected for {url}.{_stealth_hint()}")

                # Check for CAPTCHA and solve if enabled
                captcha_detected = self._looks_like_captcha(page_content.html)
                if captcha_detected:
                    if self._solve_captcha:
                        LOGGER.info(f"CAPTCHA detected for {url}, attempting to solve...")
                        try:
                            # Need access to the page for CAPTCHA solving
                            # Re-fetch with CAPTCHA solving
                            solved_result = await self._scrape_with_captcha_solving(
                                url=url,
                                formats=formats,
                                only_main_content=only_main_content,
                                wait_for=wait_for,
                                timeout=timeout,
                                screenshot_full_page=screenshot_full_page,
                                actions=actions,
                                json_schema=json_schema,
                                json_prompt=json_prompt,
                                include_tags=include_tags,
                                exclude_tags=exclude_tags,
                            )
                            if solved_result:
                                return solved_result
                        except Exception as e:
                            LOGGER.warning(f"CAPTCHA solving failed: {e}")
                    else:
                        # Check if content was extracted successfully despite CAPTCHA element
                        content_words = len(markdown.split()) if markdown else 0
                        if content_words >= 50:
                            LOGGER.info(f"CAPTCHA element detected for {url} (content extracted successfully)")
                        else:
                            LOGGER.warning(
                                f"CAPTCHA detected for {url} - content extraction may be incomplete.{_captcha_hint()}"
                            )

                if "html" in formats:
                    # Clean HTML (boilerplate removed)
                    html = self._get_clean_html(
                        page_content.html, only_main_content, include_tags=include_tags, exclude_tags=exclude_tags
                    )

                if "rawHtml" in formats:
                    raw_html = page_content.html

                if "links" in formats:
                    links = self._extract_links_from_html(page_content.html, url)

                if "images" in formats:
                    images = await browser.extract_images(page_content.html, url)

                if "branding" in formats:
                    # Extract branding information
                    from supacrawl.services.branding import BrandingExtractor

                    extractor = BrandingExtractor()
                    branding = extractor.extract(page_content.html, url)

                if capture_screenshot and page_content.screenshot:
                    screenshot_b64 = base64.b64encode(page_content.screenshot).decode("utf-8")

                if capture_pdf and page_content.pdf:
                    pdf_b64 = base64.b64encode(page_content.pdf).decode("utf-8")

                if "json" in formats:
                    # Perform LLM extraction
                    json_data = await self._extract_json(
                        markdown or "",
                        json_schema,
                        json_prompt,
                    )

                if "summary" in formats:
                    # Generate LLM summary of the page content
                    summary = await self._generate_summary(markdown or "")

                # Compute word count from markdown
                word_count = len(markdown.split()) if markdown else None

                # Process action results (screenshots and scrapes)
                actions_output = self._process_action_results(
                    page_content.action_results,
                    only_main_content=only_main_content,
                    include_tags=include_tags,
                    exclude_tags=exclude_tags,
                )

                # Compute change tracking if requested
                change_tracking = None
                current_content_hash = None
                if wants_change_tracking:
                    current_content_hash = _compute_content_hash(markdown)
                    change_tracking = _build_change_tracking(
                        previous_entry=previous_entry,
                        current_hash=current_content_hash,
                        current_markdown=markdown,
                        change_tracking_modes=change_tracking_modes,
                    )

                    # JSON comparison mode: extract structured data from both
                    # versions and compare field-by-field
                    if (
                        change_tracking.change_status == "changed"
                        and change_tracking_modes
                        and "json" in change_tracking_modes
                    ):
                        json_comparison = await self._generate_json_comparison(
                            previous_entry=previous_entry,
                            current_markdown=markdown,
                            current_json=json_data,
                            json_schema=json_schema,
                            json_prompt=json_prompt,
                        )
                        if json_comparison:
                            change_tracking.json_changes = json_comparison

                result = ScrapeResult(
                    success=True,
                    data=ScrapeData(  # type: ignore[call-arg]
                        markdown=markdown,
                        html=html,
                        raw_html=raw_html,
                        screenshot=screenshot_b64,
                        pdf=pdf_b64,
                        llm_extraction=json_data,
                        summary=summary,
                        metadata=ScrapeMetadata(
                            # Core metadata
                            title=metadata.title,
                            description=metadata.description,
                            language=metadata.language,
                            keywords=metadata.keywords,
                            robots=metadata.robots,
                            canonical_url=metadata.canonical_url,
                            # OpenGraph metadata
                            og_title=metadata.og_title,
                            og_description=metadata.og_description,
                            og_image=metadata.og_image,
                            og_url=metadata.og_url,
                            og_site_name=metadata.og_site_name,
                            # Source information
                            source_url=url,
                            status_code=page_content.status_code,
                            # Detected timezone
                            timezone=metadata.timezone,
                            # Content metrics
                            word_count=word_count,
                        ),
                        links=links,
                        images=images,
                        branding=branding,
                        actions=actions_output,
                        change_tracking=change_tracking,
                    ),
                )

                # Store in cache if max_age > 0 and cache is configured
                # When change tracking is active, auto-enable caching so future
                # comparisons have a previous version to diff against.
                effective_max_age = max_age
                if wants_change_tracking and effective_max_age <= 0:
                    effective_max_age = 365 * 24 * 3600  # 1 year default for change tracking
                if effective_max_age > 0 and self._cache:
                    self._cache.set(
                        url,
                        result.model_dump(),
                        effective_max_age,
                        variant=cache_variant,
                        content_hash=current_content_hash,
                    )

                return result

            finally:
                if owns_browser and browser:
                    await browser.__aexit__(None, None, None)

        except Exception as e:
            error_msg = str(e)

            # Auto-retry with Camoufox on HTTP/2 protocol errors.
            # Chromium-based browsers (Playwright/Patchright) can be rejected at the
            # TLS level by aggressive bot detection (e.g. Akamai). Camoufox uses
            # Firefox's TLS stack which has a different fingerprint.
            #
            # Two-stage fallback:
            #   1. Chromium → Camoufox (different TLS fingerprint)
            #   2. Camoufox → Camoufox with HTTP/2 disabled (forces HTTP/1.1)
            #
            # Stage 2 handles environments where even Firefox's TLS fingerprint
            # is rejected over HTTP/2 (reported on some systems).
            if "ERR_HTTP2_PROTOCOL_ERROR" in error_msg and _is_camoufox_available():
                is_camoufox = self._engine == "camoufox" or engine == "camoufox"

                if not is_camoufox:
                    # Stage 1: Chromium failed → try Camoufox with standard HTTP/2
                    LOGGER.info(
                        "HTTP/2 protocol error for %s, retrying with Camoufox engine",
                        url,
                    )
                    camoufox_service = ScrapeService(
                        converter=self._converter,
                        locale_config=self._locale_config,
                        cache_dir=self._cache.cache_dir if self._cache else None,
                        stealth=self._stealth,
                        proxy=self._proxy,
                        solve_captcha=self._solve_captcha,
                        headless=self._headless,
                        engine="camoufox",
                    )
                    return await camoufox_service.scrape(
                        url=url,
                        formats=formats,
                        only_main_content=only_main_content,
                        wait_for=wait_for,
                        timeout=timeout,
                        screenshot_full_page=screenshot_full_page,
                        actions=actions,
                        json_schema=json_schema,
                        json_prompt=json_prompt,
                        include_tags=include_tags,
                        exclude_tags=exclude_tags,
                        max_age=max_age,
                        wait_until=wait_until,
                        change_tracking_modes=change_tracking_modes,
                        expand_iframes=expand_iframes,
                        device=device,
                        parse_pdf=parse_pdf,
                    )

                # Stage 2: Camoufox also failed → retry with HTTP/2 disabled.
                # Guard: if we already have firefox_user_prefs set, don't recurse.
                if not self._firefox_user_prefs:
                    LOGGER.info(
                        "HTTP/2 protocol error for %s with Camoufox, retrying with HTTP/2 disabled",
                        url,
                    )
                    h1_service = ScrapeService(
                        converter=self._converter,
                        locale_config=self._locale_config,
                        cache_dir=self._cache.cache_dir if self._cache else None,
                        stealth=self._stealth,
                        proxy=self._proxy,
                        solve_captcha=self._solve_captcha,
                        headless=self._headless,
                        engine="camoufox",
                        firefox_user_prefs={"network.http.http2.enabled": False},
                    )
                    return await h1_service.scrape(
                        url=url,
                        formats=formats,
                        only_main_content=only_main_content,
                        wait_for=wait_for,
                        timeout=timeout,
                        screenshot_full_page=screenshot_full_page,
                        actions=actions,
                        json_schema=json_schema,
                        json_prompt=json_prompt,
                        include_tags=include_tags,
                        exclude_tags=exclude_tags,
                        max_age=max_age,
                        wait_until=wait_until,
                        change_tracking_modes=change_tracking_modes,
                        expand_iframes=expand_iframes,
                        device=device,
                        parse_pdf=parse_pdf,
                    )

            # Add stealth hint for common bot-detection related errors
            if not self._stealth and any(
                pattern in error_msg.lower()
                for pattern in ["403", "429", "timeout", "blocked", "denied", "err_http2_protocol_error"]
            ):
                error_msg += _stealth_hint()

            LOGGER.error(f"Scrape failed for {url}: {e}", exc_info=True)

            # If change tracking is active and we have a previous version,
            # report "removed" status (URL no longer accessible)
            if wants_change_tracking and previous_entry is not None:
                from supacrawl.models import ChangeTrackingData

                return ScrapeResult(
                    success=False,
                    error=error_msg,
                    data=ScrapeData(  # type: ignore[call-arg]
                        metadata=ScrapeMetadata(source_url=url),
                        change_tracking=ChangeTrackingData(
                            previous_scrape_at=previous_entry.cached_at,
                            change_status="removed",
                        ),
                    ),
                )

            return ScrapeResult(
                success=False,
                error=error_msg,
            )

    async def _scrape_pdf(
        self,
        url: str,
        mode: Literal["fast", "auto", "ocr"],
        formats: Sequence[str],
        json_schema: dict[str, Any] | None = None,
        json_prompt: str | None = None,
        max_age: int = 0,
        cache_variant: str | None = None,
        wants_change_tracking: bool = False,
        previous_entry: Any | None = None,
        change_tracking_modes: list[str] | None = None,
    ) -> ScrapeResult:
        """Scrape a PDF URL by downloading and extracting text.

        Bypasses the browser entirely — downloads the PDF via httpx and
        processes it through the PDF extraction pipeline.
        """
        from supacrawl.services.pdf import parse_pdf as do_parse_pdf

        try:
            pdf_result = await do_parse_pdf(url=url, mode=mode)
        except ImportError as e:
            return ScrapeResult(success=False, error=str(e))
        except Exception as e:
            LOGGER.error(f"PDF extraction failed for {url}: {e}", exc_info=True)
            return ScrapeResult(success=False, error=f"PDF extraction failed: {e}")

        markdown = pdf_result.markdown
        word_count = len(markdown.split()) if markdown else None

        # LLM-powered features on extracted markdown
        json_data = None
        summary = None

        if "json" in formats and markdown:
            json_data = await self._extract_json(markdown, json_schema, json_prompt)

        if "summary" in formats and markdown:
            summary = await self._generate_summary(markdown)

        # Build metadata from PDF properties
        pdf_meta = pdf_result.metadata

        # Change tracking
        change_tracking = None
        current_content_hash = None
        if wants_change_tracking:
            current_content_hash = _compute_content_hash(markdown)
            change_tracking = _build_change_tracking(
                previous_entry=previous_entry,
                current_hash=current_content_hash,
                current_markdown=markdown,
                change_tracking_modes=change_tracking_modes,
            )

        result = ScrapeResult(
            success=True,
            data=ScrapeData(  # type: ignore[call-arg]
                markdown=markdown if "markdown" in formats or "json" in formats or "summary" in formats else None,
                metadata=ScrapeMetadata(
                    title=pdf_meta.title,
                    source_url=url,
                    status_code=200,
                    word_count=word_count,
                    pdf_page_count=pdf_meta.page_count,
                    pdf_author=pdf_meta.author,
                    pdf_creation_date=pdf_meta.creation_date,
                ),
                llm_extraction=json_data,
                summary=summary,
                change_tracking=change_tracking,
            ),
        )

        # Cache the result
        effective_max_age = max_age
        if wants_change_tracking and effective_max_age <= 0:
            effective_max_age = 365 * 24 * 3600
        if effective_max_age > 0 and self._cache:
            self._cache.set(
                url,
                result.model_dump(),
                effective_max_age,
                variant=cache_variant,
                content_hash=current_content_hash,
            )

        return result

    @staticmethod
    def _extract_links_from_html(html: str, base_url: str) -> list[str]:
        """Extract absolute HTTP(S) links from already-fetched HTML.

        Parses anchor tags from the rendered HTML instead of re-navigating
        the browser, avoiding a full page re-fetch.

        Args:
            html: HTML content (post-JavaScript rendering, with iframes expanded)
            base_url: Base URL for resolving relative hrefs

        Returns:
            List of absolute URLs starting with http(s)
        """
        from urllib.parse import urljoin, urlparse

        soup = BeautifulSoup(html, "html.parser")
        links: list[str] = []
        for anchor in soup.find_all("a", href=True):
            href = anchor["href"]
            if isinstance(href, list):
                href = href[0] if href else ""
            if not href:
                continue
            # Resolve relative URLs
            if not urlparse(href).netloc:
                href = urljoin(base_url, href)
            # Only include http(s) links (matches browser.extract_links behaviour)
            if href.startswith("http"):
                links.append(href)
        return links

    def _get_clean_html(
        self,
        html: str,
        only_main_content: bool,
        include_tags: list[str] | None = None,
        exclude_tags: list[str] | None = None,
    ) -> str:
        """Get cleaned HTML with boilerplate removed.

        Args:
            html: Raw HTML
            only_main_content: Extract main content only
            include_tags: CSS selectors for elements to include
            exclude_tags: CSS selectors for elements to exclude

        Returns:
            Cleaned HTML string
        """
        soup = BeautifulSoup(html, "html.parser")

        # Remove boilerplate
        for tag_name in ["script", "style", "nav", "footer", "header", "noscript", "iframe"]:
            for tag in soup.find_all(tag_name):
                tag.decompose()

        # Apply exclude_tags first
        if exclude_tags:
            for selector in exclude_tags:
                try:
                    for element in soup.select(selector):
                        element.decompose()
                except Exception:
                    pass  # Invalid selector, skip

        # Apply include_tags if specified (takes precedence over only_main_content)
        if include_tags:
            matched_elements: list[Any] = []
            for selector in include_tags:
                try:
                    matched_elements.extend(soup.select(selector))
                except Exception:
                    pass  # Invalid selector, skip

            if matched_elements:
                # Create wrapper with matched elements
                wrapper = soup.new_tag("div")
                for element in matched_elements:
                    if element not in [wrapper] + list(wrapper.descendants):
                        wrapper.append(element.extract())
                return str(wrapper)

        # Find main content if requested
        if only_main_content:
            for selector in ["main", "article", "[role='main']", ".content", "#content"]:
                main = soup.select_one(selector)
                if main:
                    return str(main)

        body = soup.find("body")
        return str(body) if body else str(soup)

    async def _extract_json(
        self,
        markdown: str,
        schema: dict[str, Any] | None,
        prompt: str | None,
    ) -> dict[str, Any] | None:
        """Extract structured JSON data from markdown using LLM.

        Args:
            markdown: Markdown content to extract from
            schema: JSON schema for structured extraction
            prompt: Custom extraction prompt

        Returns:
            Extracted JSON data or None on failure
        """
        from supacrawl.services.extract import ExtractService

        # Create ExtractService with self as scrape service
        # We need to avoid circular calls, so we create a minimal scrape wrapper
        class NoOpScrapeService:
            """Wrapper that returns markdown directly without scraping."""

            async def scrape(self, url: str, **kwargs):
                from supacrawl.models import ScrapeData, ScrapeMetadata, ScrapeResult

                return ScrapeResult(
                    success=True,
                    data=ScrapeData(  # type: ignore[call-arg]
                        markdown=markdown,
                        metadata=ScrapeMetadata(),
                    ),
                )

        extract_service = ExtractService(
            scrape_service=NoOpScrapeService(),  # type: ignore[arg-type]
        )

        try:
            # Call extraction with dummy URL (we already have the content)
            result = await extract_service.extract(
                urls=["dummy://content"],
                prompt=prompt,
                schema=schema,
            )

            if result.success and result.data and len(result.data) > 0:
                item = result.data[0]
                if item.success and item.data:
                    return item.data

            LOGGER.warning("JSON extraction failed or returned no data")
            return None

        except Exception as e:
            LOGGER.error(f"JSON extraction error: {e}", exc_info=True)
            return None

    async def _generate_summary(self, markdown: str) -> str | None:
        """Generate a concise LLM summary of the page content.

        Args:
            markdown: Markdown content to summarise

        Returns:
            2-3 sentence summary or None if LLM not configured or on failure
        """
        if not markdown.strip():
            return None

        # Limit content to avoid context overflow (~10k chars as per issue spec)
        max_content = 10000
        content = markdown[:max_content]
        if len(markdown) > max_content:
            content += "\n\n[Content truncated...]"

        from supacrawl.llm import LLMClient, LLMNotConfiguredError, load_llm_config

        # Load config - return None if LLM not configured (summary is optional)
        try:
            config = load_llm_config()
        except LLMNotConfiguredError:
            LOGGER.warning("LLM not configured, skipping summary generation")
            return None

        client = LLMClient(config)

        try:
            messages = [
                {
                    "role": "system",
                    "content": (
                        "You are a summarisation assistant. Your task is to provide "
                        "concise summaries of web page content. Always respond with "
                        "plain text only, no markdown formatting."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        "Summarise the following web page content in 2-3 sentences. "
                        "Focus on the main topic and key information.\n\n"
                        f"Content:\n{content}\n\nSummary:"
                    ),
                },
            ]

            response = await client.chat(messages)

            # Clean up the response
            summary = response.strip()

            # Ensure summary is concise (under 500 chars as per issue spec)
            if len(summary) > 500:
                # Truncate to last complete sentence
                sentences = summary[:500].rsplit(".", 1)
                if len(sentences) > 1:
                    summary = sentences[0] + "."
                else:
                    summary = summary[:497] + "..."

            return summary

        except Exception as e:
            LOGGER.warning(f"Summary generation failed: {e}")
            return None
        finally:
            await client.close()

    async def _generate_json_comparison(
        self,
        previous_entry: Any,
        current_markdown: str | None,
        current_json: dict[str, Any] | None,
        json_schema: dict[str, Any] | None,
        json_prompt: str | None,
    ) -> dict[str, Any] | None:
        """Compare structured JSON fields between previous and current versions.

        Extracts JSON from both previous cached markdown and current markdown
        using the LLM, then returns a field-level comparison of changed values.

        Args:
            previous_entry: Previous CacheEntry with cached response.
            current_markdown: Current markdown content.
            current_json: Already-extracted JSON from current content (avoids
                redundant LLM call when ``json`` is also in formats).
            json_schema: JSON schema for extraction.
            json_prompt: Custom prompt for extraction.

        Returns:
            Dict mapping field names to ``{previous, current}`` values for
            fields that differ, or None if comparison is not possible.
        """
        # Extract previous markdown from cached response
        try:
            prev_data = previous_entry.response.get("data", {})
            prev_markdown = prev_data.get("markdown") or ""
        except (AttributeError, TypeError):
            LOGGER.warning("Cannot extract previous markdown for JSON comparison")
            return None

        if not prev_markdown:
            return None

        # Extract JSON from previous version
        prev_json = await self._extract_json(prev_markdown, json_schema, json_prompt)

        # Extract JSON from current version (reuse if already extracted)
        curr_json = current_json
        if curr_json is None:
            curr_json = await self._extract_json(current_markdown or "", json_schema, json_prompt)

        if not prev_json and not curr_json:
            LOGGER.warning("JSON extraction returned no data for either version")
            return None

        # Compare field by field — only include fields that differ
        all_keys: set[str] = set()
        if prev_json:
            all_keys.update(prev_json.keys())
        if curr_json:
            all_keys.update(curr_json.keys())

        changes: dict[str, Any] = {}
        for key in sorted(all_keys):
            prev_val = prev_json.get(key) if prev_json else None
            curr_val = curr_json.get(key) if curr_json else None
            if prev_val != curr_val:
                changes[key] = {"previous": prev_val, "current": curr_val}

        return changes if changes else None

    def _process_action_results(
        self,
        action_results: list[Any] | None,
        only_main_content: bool = True,
        include_tags: list[str] | None = None,
        exclude_tags: list[str] | None = None,
    ) -> ActionsOutput | None:
        """Process action results to extract screenshots and scrapes.

        Args:
            action_results: List of ActionResult objects from ActionRunner
            only_main_content: Whether to extract main content for markdown conversion
            include_tags: CSS selectors for elements to include
            exclude_tags: CSS selectors for elements to exclude

        Returns:
            ActionsOutput with screenshots and scrapes, or None if no results
        """
        if not action_results:
            return None

        screenshots: list[str] = []
        scrapes: list[ScrapeActionResult] = []

        for result in action_results:
            # Handle screenshot actions
            if result.action_type == "screenshot" and result.screenshot:
                screenshot_b64 = base64.b64encode(result.screenshot).decode("utf-8")
                screenshots.append(screenshot_b64)

            # Handle scrape actions
            if result.action_type == "scrape" and result.scrape:
                # Convert HTML to markdown
                scrape_markdown = self._converter.convert(
                    result.scrape.html,
                    base_url=result.scrape.url,
                    only_main_content=only_main_content,
                    include_tags=include_tags,
                    exclude_tags=exclude_tags,
                )

                scrapes.append(
                    ScrapeActionResult(
                        url=result.scrape.url,
                        html=result.scrape.html,
                        markdown=scrape_markdown,
                    )
                )

        # Return None if no screenshots or scrapes were captured
        if not screenshots and not scrapes:
            return None

        return ActionsOutput(
            screenshots=screenshots if screenshots else None,
            scrapes=scrapes if scrapes else None,
        )

    def _looks_like_captcha(self, html: str) -> bool:
        """Detect if the page contains a CAPTCHA challenge.

        Args:
            html: Raw HTML content

        Returns:
            True if CAPTCHA is detected
        """
        captcha_patterns = [
            # reCAPTCHA
            r"g-recaptcha",
            r"grecaptcha",
            r"recaptcha/api",
            r"data-sitekey",
            # hCaptcha
            r"h-captcha",
            r"hcaptcha.com",
            r'class="h-captcha"',
            # Cloudflare Turnstile
            r"cf-turnstile",
            r"challenges.cloudflare.com/turnstile",
            # Generic CAPTCHA indicators
            r"iframe[^>]*captcha",
        ]

        import re

        for pattern in captcha_patterns:
            if re.search(pattern, html, re.IGNORECASE):
                return True
        return False

    async def _scrape_with_captcha_solving(
        self,
        url: str,
        formats: list[Any],
        only_main_content: bool,
        wait_for: int,
        timeout: int,
        screenshot_full_page: bool,
        actions: list[Any] | None,
        json_schema: dict[str, Any] | None,
        json_prompt: str | None,
        include_tags: list[str] | None,
        exclude_tags: list[str] | None,
    ) -> ScrapeResult | None:
        """Scrape a URL with CAPTCHA solving enabled.

        This method creates a new browser context, navigates to the page,
        detects and solves any CAPTCHA, then continues scraping.

        Args:
            url: URL to scrape
            formats: Output formats
            only_main_content: Extract main content only
            wait_for: Additional wait time after page load
            timeout: Page load timeout
            screenshot_full_page: Full page screenshot
            actions: Actions to execute
            json_schema: JSON schema for extraction
            json_prompt: Prompt for JSON extraction
            include_tags: CSS selectors to include
            exclude_tags: CSS selectors to exclude

        Returns:
            ScrapeResult if successful, None if CAPTCHA solving failed
        """
        from supacrawl.services.captcha import (
            CaptchaSolver,
            CaptchaSolverError,
        )

        # Create browser context for CAPTCHA solving
        browser = BrowserManager(
            headless=self._headless,
            timeout_ms=timeout,
            locale_config=self._locale_config,
            stealth=self._stealth,
            proxy=self._proxy,
            engine=self._engine,
        )

        try:
            await browser.start()

            # Navigate to page
            if browser._browser is None:
                raise ProviderError("Browser failed to start", provider="playwright")

            # Camoufox browser IS the context — don't create a separate one
            if browser.engine == "camoufox":
                context = None
                page = await browser._browser.new_page()
            else:
                context = await browser._browser.new_context(**browser._build_context_options())
                page = await context.new_page()

            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=timeout)

                # Detect and solve CAPTCHA
                solver = CaptchaSolver()
                try:
                    solved = await solver.detect_and_solve(page)
                    if solved:
                        LOGGER.info(f"CAPTCHA solved successfully for {url}")

                        # Wait for page to process the solution
                        await page.wait_for_load_state("networkidle", timeout=10000)

                        # Now re-scrape using the normal flow
                        # Get the new HTML after CAPTCHA is solved
                        html = await page.content()

                        # Check if CAPTCHA is still present
                        if self._looks_like_captcha(html):
                            LOGGER.warning("CAPTCHA still present after solving")
                            return None

                        # Build ScrapeResult from the solved page
                        # This is a simplified version - we could extract more data
                        markdown = self._converter.convert(
                            html,
                            base_url=url,
                            only_main_content=only_main_content,
                            include_tags=include_tags,
                            exclude_tags=exclude_tags,
                        )

                        metadata = await browser.extract_metadata(html)

                        return ScrapeResult(
                            success=True,
                            data=ScrapeData(  # type: ignore[call-arg]
                                markdown=markdown if "markdown" in formats else None,
                                html=self._get_clean_html(html, only_main_content, include_tags, exclude_tags)
                                if "html" in formats
                                else None,
                                raw_html=html if "rawHtml" in formats else None,
                                metadata=ScrapeMetadata(
                                    title=metadata.title,
                                    description=metadata.description,
                                    language=metadata.language,
                                    keywords=metadata.keywords,
                                    robots=metadata.robots,
                                    canonical_url=metadata.canonical_url,
                                    og_title=metadata.og_title,
                                    og_description=metadata.og_description,
                                    og_image=metadata.og_image,
                                    og_url=metadata.og_url,
                                    og_site_name=metadata.og_site_name,
                                    source_url=url,
                                    status_code=200,
                                    timezone=metadata.timezone,
                                    word_count=len(markdown.split()) if markdown else None,
                                ),
                            ),
                        )
                    else:
                        LOGGER.debug("No CAPTCHA found on page during solve attempt")
                        return None

                except CaptchaSolverError as e:
                    LOGGER.warning(f"CAPTCHA solving error: {e}")
                    return None

            finally:
                await page.close()

        finally:
            await browser.stop()
