"""Content preparation utilities."""
