from contextlib import asynccontextmanager
from pathlib import Path
import ssl
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Tuple,
    Optional,
    AsyncIterator,
)

from httpx import AsyncClient
from loguru import logger

import httpx
import asyncio

from pjdev_sn_sdk.api_utilities import async_retry_http, log_server_addr, log_response_headers, log_request_headers
from pjdev_sn_sdk.config_service import get_config


async def check_for_202(r: httpx.Response) -> None:
    if r.status_code == 202:
        logger.warning(
            f"202 status code recieved for {r.request.method.upper()} {r.url.path}"
        )
        await asyncio.sleep(5)
        raise httpx.HTTPError("Too many requests")


class SnApiKeyAuth(httpx.Auth):
    def __init__(self, token):
        self.token = token

    def auth_flow(self, request):
        request.headers["x-sn-apikey"] = self.token
        yield request


def get_http_client() -> httpx.AsyncClient:
    config = get_config()
    if not config.api_key:
        if not config.api_username or not config.api_password:
            raise ValueError("Must set username and password")
        auth = httpx.BasicAuth(
            username=config.api_username, password=config.api_password
        )
    else:
        auth = SnApiKeyAuth(config.api_key)

    return httpx.AsyncClient(
        base_url=config.sn_api_url,
        auth=auth,
        verify=ssl.create_default_context(),
        timeout=None,
        event_hooks={
            "response": [log_server_addr, log_response_headers],
            "request": [log_request_headers],
        },
    )


@asynccontextmanager
async def http_client() -> AsyncIterator[httpx.AsyncClient]:
    async with get_http_client() as _client:
        yield _client


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 405, 404],
)
async def add_table_row(
        table_name: str,
        payload: Dict[str, Any],
        fields: Optional[str] = None,
        client: Optional[AsyncClient] = None,
) -> Dict[str, Any]:
    async def _exec(_client: AsyncClient) -> Dict[str, Any]:
        params = {}
        if fields:
            params["sysparm_fields"] = fields
        r = await _client.post(
            f"/api/now/table/{table_name}", json=payload, params=params
        )
        r.raise_for_status()
        await check_for_202(r=r)

        json_data = r.json()
        logger.info(f"Added row to {table_name}")
        return json_data["result"]

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 405, 404],
)
async def delete_table_row(
        table_name: str, sys_id: str, client: Optional[AsyncClient] = None
) -> None:
    async def _exec(_client: AsyncClient) -> None:
        r = await _client.delete(f"/api/now/table/{table_name}/{sys_id}")
        if not r.is_success and r.status_code != 404:
            r.raise_for_status()
        await check_for_202(r=r)
        if r.status_code != 404:
            logger.info(f"Removed row {sys_id} from {table_name}")

    if not client:
        async with http_client() as _client:
            await _exec(_client)
    else:
        await _exec(client)


async def _paginate_table_rows(
        table_name: str,
        query: Optional[str] = None,
        fields: Optional[str] = None,
        order_by_fields: Optional[List[str]] = None,
        page_size: int = 5000,
        extra_parms: Optional[Dict] = None,
        concurrency: Optional[int] = None,
        get_display_values: Optional[bool] = False,
        page_handler: Optional[Callable[[List[Any], int, int], None]] = None,
        accumulate_results: bool = True,
) -> Tuple[List[Any], int]:
    """
    Internal helper to paginate through table rows with optional result accumulation.

    Args:
        table_name: Name of the ServiceNow table
        query: Query string for filtering
        fields: Comma-separated field names to return
        order_by_fields: List of fields to order by
        page_size: Number of records per page
        extra_parms: Additional query parameters
        concurrency: Number of concurrent requests (default 1)
        get_display_values: Whether to get display values
        page_handler: Optional callback function(page_data, page_num, total_count) called for each page
        accumulate_results: If False, don't accumulate rows in memory (only use page_handler)

    Returns:
        Tuple of (all_rows, total_count). all_rows is empty list if accumulate_results=False
    """
    url = f"/api/now/table/{table_name}"
    params: Dict[str, Any] = {}

    # Build query locally
    full_query = query
    if order_by_fields:
        order_by_query = "^".join(f"ORDERBY{f}" for f in order_by_fields)
        full_query = f"{full_query}^{order_by_query}" if full_query else order_by_query

    if full_query:
        params["sysparm_query"] = full_query

    if fields:
        params["sysparm_fields"] = fields

    if get_display_values:
        params["sysparm_display_value"] = True

    if extra_parms:
        params = {**params, **extra_parms}

    params["sysparm_limit"] = page_size

    async with http_client() as client:
        first_result = await client.get(url, params=params)
        first_result.raise_for_status()
        await check_for_202(r=first_result)

    try:
        first_rows = first_result.json()["result"]
    except Exception:
        logger.exception(f"Unexpected response payload for table: {table_name}")
        raise

    total_count_str = first_result.headers.get("X-Total-Count")
    if not total_count_str:
        logger.warning(
            f"X-Total-Count header was not present in request to table: {table_name}"
        )
        # Best-effort: if header is missing, keep count consistent with returned rows.
        if page_handler:
            page_handler(first_rows, 0, len(first_rows))
        return (first_rows if accumulate_results else [], len(first_rows))

    try:
        total_count = int(total_count_str.strip())
    except (ValueError, AttributeError):
        logger.warning(
            f"Could not parse X-Total-Count={total_count_str!r} for table: {table_name}"
        )
        if page_handler:
            page_handler(first_rows, 0, len(first_rows))
        return (first_rows if accumulate_results else [], len(first_rows))

    if total_count <= 0:
        return ([], 0)

    # Process first page
    if page_handler:
        page_handler(first_rows, 0, total_count)
        logger.info(f"Processed page 0 for {table_name}")

    if total_count <= page_size:
        return (first_rows if accumulate_results else [], total_count)

    # Paginate remaining pages
    concurrency_value = concurrency or 1
    sem = asyncio.Semaphore(value=concurrency_value)
    logger.info(
        f"total records for {table_name}: {total_count} (page_size={page_size}, concurrency={concurrency_value})"
    )

    @async_retry_http(
        status_codes_to_ignore=[400, 401, 403, 405, 404],
    )
    async def __run(offset: int, page_num: int) -> List[Any]:
        async with sem:
            local_params = {**params, "sysparm_offset": offset}
            logger.info(f"Fetching page {page_num} at offset: {offset}")
            async with get_http_client() as _client:
                r = await _client.get(url, params=local_params)
                r.raise_for_status()
                await check_for_202(r=r)
                offset_data = r.json()["result"]

            if total_count - offset >= page_size > len(offset_data):
                raise Exception(
                    f"Did not receive entire payload: {len(offset_data)} rows"
                )

            if page_handler:
                page_handler(offset_data, page_num, total_count)
                logger.info(f"Processed page {page_num} at offset {offset}")

            return offset_data

    # Fetch remaining pages
    offsets = range(page_size, total_count, page_size)
    results_list = await asyncio.gather(*(__run(off, idx + 1) for idx, off in enumerate(offsets)))

    if accumulate_results:
        all_rows = [*first_rows, *(item for sub in results_list for item in sub)]
        return all_rows, total_count
    else:
        return [], total_count


async def stream_table_rows(
        table_name: str,
        page_handler: Callable[[List[Any], int, int], None],
        query: Optional[str] = None,
        fields: Optional[str] = None,
        order_by_fields: Optional[List[str]] = None,
        page_size: int = 5000,
        extra_parms: Optional[Dict] = None,
        concurrency: Optional[int] = None,
        get_display_values: Optional[bool] = False,
) -> int:
    """
    Query table API and paginate through all data without accumulating in memory.
    Each page of data is passed to the page_handler callback.

    Args:
        table_name: Name of the ServiceNow table
        page_handler: Callback function(page_data, page_num, total_count) called for each page
        query: Query string for filtering
        fields: Comma-separated field names to return
        order_by_fields: List of fields to order by
        page_size: Number of records per page (default 5000)
        extra_parms: Additional query parameters
        concurrency: Number of concurrent requests (default 1)
        get_display_values: Whether to get display values

    Returns:
        Total count of records processed
    """
    _, total_count = await _paginate_table_rows(
        table_name=table_name,
        query=query,
        fields=fields,
        order_by_fields=order_by_fields,
        page_size=page_size,
        extra_parms=extra_parms,
        concurrency=concurrency,
        get_display_values=get_display_values,
        page_handler=page_handler,
        accumulate_results=False,
    )
    return total_count


async def get_table_rows(
        table_name: str,
        query: Optional[str] = None,
        fields: Optional[str] = None,
        order_by_fields: Optional[List[str]] = None,
        sysparm_limit: Optional[int] = None,
        paginate: bool = False,
        extra_parms: Optional[Dict] = None,
        concurrency: Optional[int] = None,
        get_display_values: Optional[bool] = False,
) -> Tuple[List[Any], int]:
    """
    Query table API and return all matching rows.

    Args:
        table_name: Name of the ServiceNow table
        query: Query string for filtering
        fields: Comma-separated field names to return
        order_by_fields: List of fields to order by
        sysparm_limit: Page size limit
        paginate: Whether to paginate through all results
        extra_parms: Additional query parameters
        concurrency: Number of concurrent requests (default 1)
        get_display_values: Whether to get display values

    Returns:
        Tuple of (all_rows, total_count)
    """
    if sysparm_limit is not None:
        page_size = sysparm_limit
    elif paginate:
        page_size = 5000
    else:
        page_size = 5000

    if not paginate:
        # Fetch only first page
        url = f"/api/now/table/{table_name}"
        params: Dict[str, Any] = {}

        full_query = query
        if order_by_fields:
            order_by_query = "^".join(f"ORDERBY{f}" for f in order_by_fields)
            full_query = f"{full_query}^{order_by_query}" if full_query else order_by_query

        if full_query:
            params["sysparm_query"] = full_query

        if fields:
            params["sysparm_fields"] = fields

        if get_display_values:
            params["sysparm_display_value"] = True

        if extra_parms:
            params = {**params, **extra_parms}

        params["sysparm_limit"] = page_size

        async with http_client() as client:
            first_result = await client.get(url, params=params)
            first_result.raise_for_status()
            await check_for_202(r=first_result)

        try:
            first_rows = first_result.json()["result"]
        except Exception:
            logger.exception(f"Unexpected response payload for table: {table_name}")
            raise

        total_count_str = first_result.headers.get("X-Total-Count")
        if not total_count_str:
            logger.warning(
                f"X-Total-Count header was not present in request to table: {table_name}"
            )
            return first_rows, len(first_rows)

        try:
            total_count = int(total_count_str.strip())
        except (ValueError, AttributeError):
            logger.warning(
                f"Could not parse X-Total-Count={total_count_str!r} for table: {table_name}"
            )
            return first_rows, len(first_rows)

        if total_count <= 0:
            return [], 0

        return first_rows, total_count

    # Use shared pagination logic
    return await _paginate_table_rows(
        table_name=table_name,
        query=query,
        fields=fields,
        order_by_fields=order_by_fields,
        page_size=page_size,
        extra_parms=extra_parms,
        concurrency=concurrency,
        get_display_values=get_display_values,
        accumulate_results=True,
    )


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 405, 404],
)
async def patch_table_row(
        table_name: str,
        sys_id: str,
        payload: Dict[str, Any],
        fields: Optional[List[str]] = None,
        client: Optional[AsyncClient] = None,
) -> Dict[str, Any]:
    async def _exec(_client: AsyncClient) -> Dict[str, Any]:
        params = {}

        if fields:
            params["sysparm_fields"] = ",".join(fields)

        r = await _client.patch(
            f"/api/now/table/{table_name}/{sys_id}", json=payload, params=params
        )
        r.raise_for_status()
        await check_for_202(r=r)

        logger.info(f"Updated row to {table_name}")

        return r.json()["result"]

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 405, 404],
)
async def move_auth_package_to_step(
        target_step: int, auth_package_sys_id: str, client: Optional[AsyncClient] = None
) -> Dict:
    scripted_api_base_path = get_config().scripted_api_base_path

    async def _exec(_client: AsyncClient) -> Dict:
        r = await _client.patch(
            f"{scripted_api_base_path}/{auth_package_sys_id}",
            json={"target_step": target_step},
        )
        r.raise_for_status()
        await check_for_202(r=r)
        return r.json()["result"]

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


async def update_poam(
        auth_package_sys_id: str,
        poam_sys_id: str,
        payload: Dict[str, Any],
        client: Optional[AsyncClient] = None,
) -> Dict:
    config = get_config()

    async def _exec(_client: AsyncClient) -> Dict:
        r = await _client.patch(
            f"{config.scripted_api_base_path}/{auth_package_sys_id}/poam/{poam_sys_id}",
            json=payload,
        )
        r.raise_for_status()
        await check_for_202(r=r)
        return r.json()["result"]

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 405, 404],
)
async def create_poam(
        auth_package_sys_id: str, payload: Dict, client: Optional[AsyncClient] = None
) -> Dict:
    config = get_config()

    async def _exec(_client: AsyncClient) -> Dict:
        r = await _client.post(
            f"{config.scripted_api_base_path}/{auth_package_sys_id}/poam",
            json=payload,
        )
        r.raise_for_status()
        await check_for_202(r=r)
        return r.json()["result"]

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 405, 404],
)
async def update_auth_package_authorize_info(
        auth_package_sys_id: str,
        payload: Dict[str, Any],
        client: Optional[AsyncClient] = None,
) -> Dict:
    config = get_config()

    async def _exec(_client: AsyncClient) -> Dict:
        r = await _client.patch(
            f"{config.scripted_api_base_path}/{auth_package_sys_id}/authorize",
            json=payload,
        )
        r.raise_for_status()
        await check_for_202(r=r)
        return r.json()["result"]

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 405, 404],
)
async def update_control_status(
        auth_pack_sys_id: str,
        compliance_control_sys_id: str,
        payload: Dict[str, Any],
        client: Optional[AsyncClient] = None,
) -> Dict:
    config = get_config()

    async def _exec(_client: AsyncClient) -> Dict:
        r = await _client.patch(
            f"{config.scripted_api_base_path}/{auth_pack_sys_id}/control/{compliance_control_sys_id}",
            json=payload,
        )
        r.raise_for_status()
        await check_for_202(r=r)
        return r.json()["result"]

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


__sem = asyncio.Semaphore(10)


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 404],
)
async def associate_file_reference_to_compliance_control(
        compliance_control_sys_id: str, text: str, client: Optional[AsyncClient] = None
) -> Dict[str, Any]:
    config = get_config()

    async def _exec(_client: AsyncClient) -> Dict[str, Any]:
        payload = {"u_associated_artifacts": text}

        async with __sem:
            r = await _client.patch(
                f"{config.scripted_api_base_path}/control_artifact_association/{compliance_control_sys_id}",
                json=payload,
            )
            r.raise_for_status()
            await check_for_202(r=r)
        updated_control = r.json()["result"]

        return updated_control["current_values"]

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 404],
)
async def get_attachment_sys_id(
        table_name: str,
        table_row_sys_id: str,
        snow_filename: str,
        client: Optional[AsyncClient] = None,
) -> Optional[str]:
    async def _exec(_client: AsyncClient) -> Optional[str]:
        query_params = {
            "table_name": table_name,
            "table_sys_id": table_row_sys_id,
            "file_name": snow_filename,
        }
        async with __sem:
            r = await _client.get(
                "api/now/attachment",
                params=query_params,
            )

            r.raise_for_status()
            await check_for_202(r=r)
            json_data = r.json()["result"]
            if len(json_data) > 0:
                return json_data[0].get("sys_id")

        return None

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 404],
)
async def get_attachments(
        table_name: str,
        table_row_sys_id: str,
        client: Optional[AsyncClient] = None,
) -> List[Dict[str, Any]]:
    async def _exec(_client: AsyncClient) -> List[Dict[str, Any]]:
        query = f'table_name="{table_name}"^table_sys_id="{table_row_sys_id}"'
        async with __sem:
            r = await _client.get(
                "api/now/attachment",
                params=f"sysparm_query={query}",
            )

            r.raise_for_status()
            await check_for_202(r=r)
            return r.json()["result"]

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 404],
)
async def delete_attachment(
        attachment_id: str, client: Optional[AsyncClient] = None
) -> None:
    async def _exec(_client: AsyncClient) -> None:
        r = await _client.delete(f"api/now/attachment/{attachment_id}")

        r.raise_for_status()
        await check_for_202(r=r)

    if not client:
        async with http_client() as _client:
            await _exec(_client)
    else:
        await _exec(client)


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 404],
)
async def upload_artifact(
        table_name: str,
        table_row_sys_id: str,
        filepath: Path,
        snow_filename: str,
        client: Optional[AsyncClient] = None,
) -> Tuple[str, str]:
    async def _exec(_client: AsyncClient) -> Tuple[str, str]:
        generic_type = "application/octet-stream"
        headers = {"Content-Type": generic_type, "Accept": "application/json"}
        query_params = {
            "table_name": table_name,
            "table_sys_id": table_row_sys_id,
            "file_name": snow_filename,
        }
        async with __sem:
            with open(filepath, mode="rb") as file:
                r = await _client.post(
                    "api/now/attachment/file",
                    headers=headers,
                    params=query_params,
                    content=file.read(),
                )

            if not r.is_success:
                logger.warning(r.text)

            r.raise_for_status()
            await check_for_202(r=r)

            json_data = r.json()["result"]
            filename = json_data.get("file_name")
            attachment_id = json_data.get("sys_id")

            return f"{attachment_id}", filename

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


@async_retry_http(
    status_codes_to_ignore=[400, 401, 403, 404],
)
async def download_artifact(
        attachment_id: str, filename: str, client: Optional[AsyncClient] = None
) -> Path:
    config = get_config()

    async def _exec(_client: AsyncClient) -> Path:
        r = await _client.get(f"api/now/attachment/{attachment_id}/file")

        if not r.is_success:
            logger.warning(r.text)

        r.raise_for_status()
        await check_for_202(r=r)

        with open(config.output_path / filename, mode="wb") as file:
            for chunk in r.iter_bytes():
                file.write(chunk)

        return config.output_path / filename

    if not client:
        async with http_client() as _client:
            return await _exec(_client)
    else:
        return await _exec(client)


def get_attachment_url(attachment_id: str) -> str:
    config = get_config()
    return f"{config.sn_api_url}/nav_to.do?uri=sys_attachment.do?sys_id={attachment_id}"


if __name__ == "__main__":
    async def __test() -> None:
        _data = await get_table_rows("sn_irm_cont_auth_pack", sysparm_limit=1)
        logger.info(_data)


    asyncio.run(__test())
