# Integration Notes — Opus Review Feedback

## Integrating

### 2. Keep `context="game"` as default (ACCEPTED)
Good point about backward compatibility. Changing default to editor silently breaks existing callers. **Keep `context="game"` as default**, require explicit `context="editor"` for editor access.

### 3. Dynamic Script Cleanup on Exception (ACCEPTED)
GDScript has no try/catch, but we can use a guard pattern. If `obj.run()` errors, GDScript won't crash the whole editor — it logs the error and continues. However, cleanup must happen regardless. We'll restructure to ensure remove_child + queue_free always run.

### 4. Unique Temp Filenames (ACCEPTED)
Use `_temp_exec_%d.gd` with a counter to avoid race conditions in the fallback path.

### 5. save_scene API Defensive Check (ACCEPTED)
Treat any return value from save_scene() as success if not an Error. Add defensive handling.

### 10. Allow Helper Functions (ACCEPTED)
Change validation from `starts_with("func run():")` to checking that code `contains` `func run():` or `func run() ->`. This allows helper functions, constants, and comments before `run()`.

### 11. Prompt Guidance (ACCEPTED)
Add explicit note: "Prefer dedicated tools (node_ops, script_ops) over exec_editor. Use exec_editor only for operations not covered by other tools."

## NOT Integrating

### 1. Security Model Redesign
The review suggests configurable allowlists and acknowledges string-matching is limited. This is true but out of scope for this sprint. The current approach matches GDAI's security model. Editor exec is inherently a trust operation — same as giving an agent shell access. We document it as such but don't over-engineer blocklists. Future sprint can add `.godotiq.json` allowlists if needed.

### 6. Richer Serialization
Using `str()` is consistent with game-side exec. Extracting `_serialize_value()` to shared utility is out of scope (modifying runtime.gd is in DO NOT TOUCH list).

### 7. EditorScript Discussion
Noted for documentation but not changing approach. `extends Node` with `add_child()` is simpler and gives the same tree access. EditorScript has its own quirks with `_run()` vs `run()`.

### 8. Response Format
Already using `send_response` / `_send_error` consistently. No change needed.

### 9. Additional Test Cases
Concurrent requests test requires actual concurrency — not practical in unit tests. Await test is a good idea but edge case. Read-only save is an OS-level concern. We'll note these as future improvements.

### 12. MCP Annotations
Can't change per-invocation. Keep current annotations which are already appropriate (destructiveHint: True covers both contexts).
