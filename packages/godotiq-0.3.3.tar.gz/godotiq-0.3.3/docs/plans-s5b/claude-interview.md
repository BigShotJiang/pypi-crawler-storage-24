# Sprint 5b Interview Transcript

## Q1: Safety — What blocked patterns for editor exec?

**Question**: The spec says editor exec should NOT block FileAccess.open (editor legitimately needs file access). But should we block FileAccess.open for WRITE specifically, or allow all file operations?

**Answer**: Block only OS/DirAccess (as spec says). Allow FileAccess.open entirely. Editor scripts legitimately read/write files. Only block OS.execute, OS.kill, OS.shell_open, DirAccess.remove.

## Q2: Tool design — One tool or two?

**Question**: Should we add `context` as a parameter to the existing `godotiq_exec` tool, or create a separate `godotiq_exec_editor` tool?

**Answer**: Add context param to godotiq_exec (as spec says). One tool, context='editor' (default) or context='game'. Simpler, fewer tools to learn.

## Q3: Async handling for fallback

**Question**: The GDScript fallback (_exec_editor_via_file) is synchronous and can't await the filesystem scan. Should we make _handle_exec_editor async?

**Answer**: Keep synchronous (as spec says). Primary approach likely works. Fallback is synchronous with load() — may fail if Godot hasn't scanned yet. Caller retries.

## Q4: EditorInterface.save_scene_as() API

**Question**: Does save_scene_as(path) exist in Godot 4?

**Answer**: User hasn't tested. Research shows it likely doesn't exist — only save_scene() (no params) and save_all_scenes(). save_scene_as(path) was Godot 3.

## Q5: Prompt update

**Question**: After Sprint 5b, update the MCP prompt (godot_development.md) to include exec context parameter and save_scene?

**Answer**: Yes, update prompt in this sprint.

## Q6: Save scene scope — in-place only or Save As?

**Question**: Should we simplify save_scene to only in-place save (drop path parameter), or implement Save As via PackedScene + ResourceSaver?

**Answer**: In-place save only. Just EditorInterface.save_scene(). Simple, reliable. Drop the path parameter. Save As can be added later if needed.

## Key Decisions Summary

1. **Blocked patterns**: OS.execute, OS.kill, OS.shell_open, DirAccess.remove only (FileAccess allowed)
2. **Tool design**: Single `godotiq_exec` with `context` parameter (editor default, game)
3. **Async**: Keep synchronous, fallback may need retry
4. **Save scene**: In-place only via EditorInterface.save_scene(), no path parameter
5. **Prompt**: Update godot_development.md in this sprint
6. **save_scene_as()**: Does NOT exist in Godot 4, confirmed by research
