# acquit-ai
> AI-powered litigation intelligence platform
**Official package by Colin McNamara LLC.** Namespace reservation.
- Website: https://acquit.ai
- License: Proprietary
