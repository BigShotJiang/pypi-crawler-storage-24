# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class MemberJobCard:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'name': 'str',
        'average_score': 'str',
        'score': 'int',
        'send_time': 'str',
        'last_submit_time': 'str'
    }

    attribute_map = {
        'name': 'name',
        'average_score': 'average_score',
        'score': 'score',
        'send_time': 'send_time',
        'last_submit_time': 'last_submit_time'
    }

    def __init__(self, name=None, average_score=None, score=None, send_time=None, last_submit_time=None):
        r"""MemberJobCard

        The model defined in huaweicloud sdk

        :param name: 作业名称
        :type name: str
        :param average_score: 作业均分(作业有均分该字段才返回)
        :type average_score: str
        :param score: 作业得分(作业有分数该字段才返回)
        :type score: int
        :param send_time: 作业下发时间, 日期格式：yyyy-MM-dd HH:mm:ss
        :type send_time: str
        :param last_submit_time: 作业最后一次提交时间, 日期格式：yyyy-MM-dd HH:mm:ss
        :type last_submit_time: str
        """
        
        

        self._name = None
        self._average_score = None
        self._score = None
        self._send_time = None
        self._last_submit_time = None
        self.discriminator = None

        self.name = name
        self.average_score = average_score
        self.score = score
        self.send_time = send_time
        self.last_submit_time = last_submit_time

    @property
    def name(self):
        r"""Gets the name of this MemberJobCard.

        作业名称

        :return: The name of this MemberJobCard.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this MemberJobCard.

        作业名称

        :param name: The name of this MemberJobCard.
        :type name: str
        """
        self._name = name

    @property
    def average_score(self):
        r"""Gets the average_score of this MemberJobCard.

        作业均分(作业有均分该字段才返回)

        :return: The average_score of this MemberJobCard.
        :rtype: str
        """
        return self._average_score

    @average_score.setter
    def average_score(self, average_score):
        r"""Sets the average_score of this MemberJobCard.

        作业均分(作业有均分该字段才返回)

        :param average_score: The average_score of this MemberJobCard.
        :type average_score: str
        """
        self._average_score = average_score

    @property
    def score(self):
        r"""Gets the score of this MemberJobCard.

        作业得分(作业有分数该字段才返回)

        :return: The score of this MemberJobCard.
        :rtype: int
        """
        return self._score

    @score.setter
    def score(self, score):
        r"""Sets the score of this MemberJobCard.

        作业得分(作业有分数该字段才返回)

        :param score: The score of this MemberJobCard.
        :type score: int
        """
        self._score = score

    @property
    def send_time(self):
        r"""Gets the send_time of this MemberJobCard.

        作业下发时间, 日期格式：yyyy-MM-dd HH:mm:ss

        :return: The send_time of this MemberJobCard.
        :rtype: str
        """
        return self._send_time

    @send_time.setter
    def send_time(self, send_time):
        r"""Sets the send_time of this MemberJobCard.

        作业下发时间, 日期格式：yyyy-MM-dd HH:mm:ss

        :param send_time: The send_time of this MemberJobCard.
        :type send_time: str
        """
        self._send_time = send_time

    @property
    def last_submit_time(self):
        r"""Gets the last_submit_time of this MemberJobCard.

        作业最后一次提交时间, 日期格式：yyyy-MM-dd HH:mm:ss

        :return: The last_submit_time of this MemberJobCard.
        :rtype: str
        """
        return self._last_submit_time

    @last_submit_time.setter
    def last_submit_time(self, last_submit_time):
        r"""Sets the last_submit_time of this MemberJobCard.

        作业最后一次提交时间, 日期格式：yyyy-MM-dd HH:mm:ss

        :param last_submit_time: The last_submit_time of this MemberJobCard.
        :type last_submit_time: str
        """
        self._last_submit_time = last_submit_time

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, MemberJobCard):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
