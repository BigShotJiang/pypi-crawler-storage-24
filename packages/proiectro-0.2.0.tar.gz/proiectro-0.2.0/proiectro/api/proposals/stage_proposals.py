from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.stage_proposals import StageProposals
from ...types import Response


def _get_kwargs(
    tenant_path: str,
    stage_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/{tenant_path}/stage_proposals/{stage_id}".format(
            tenant_path=quote(str(tenant_path), safe=""),
            stage_id=quote(str(stage_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> StageProposals | None:
    if response.status_code == 200:
        response_200 = StageProposals.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[StageProposals]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    tenant_path: str,
    stage_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[StageProposals]:
    """Stage Proposals

     Monitor all proposals at a specific pipeline stage for focused sales management.
    Identifies bottlenecks, aging deals, and opportunities requiring attention. Essential
    for sales managers to drive pipeline velocity and forecast accurately. Group coaching
    opportunities become visible when multiple deals stall at the same stage.

    Args:
        tenant_path (str):
        stage_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[StageProposals]
    """

    kwargs = _get_kwargs(
        tenant_path=tenant_path,
        stage_id=stage_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    tenant_path: str,
    stage_id: str,
    *,
    client: AuthenticatedClient,
) -> StageProposals | None:
    """Stage Proposals

     Monitor all proposals at a specific pipeline stage for focused sales management.
    Identifies bottlenecks, aging deals, and opportunities requiring attention. Essential
    for sales managers to drive pipeline velocity and forecast accurately. Group coaching
    opportunities become visible when multiple deals stall at the same stage.

    Args:
        tenant_path (str):
        stage_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        StageProposals
    """

    return sync_detailed(
        tenant_path=tenant_path,
        stage_id=stage_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    tenant_path: str,
    stage_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[StageProposals]:
    """Stage Proposals

     Monitor all proposals at a specific pipeline stage for focused sales management.
    Identifies bottlenecks, aging deals, and opportunities requiring attention. Essential
    for sales managers to drive pipeline velocity and forecast accurately. Group coaching
    opportunities become visible when multiple deals stall at the same stage.

    Args:
        tenant_path (str):
        stage_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[StageProposals]
    """

    kwargs = _get_kwargs(
        tenant_path=tenant_path,
        stage_id=stage_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    tenant_path: str,
    stage_id: str,
    *,
    client: AuthenticatedClient,
) -> StageProposals | None:
    """Stage Proposals

     Monitor all proposals at a specific pipeline stage for focused sales management.
    Identifies bottlenecks, aging deals, and opportunities requiring attention. Essential
    for sales managers to drive pipeline velocity and forecast accurately. Group coaching
    opportunities become visible when multiple deals stall at the same stage.

    Args:
        tenant_path (str):
        stage_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        StageProposals
    """

    return (
        await asyncio_detailed(
            tenant_path=tenant_path,
            stage_id=stage_id,
            client=client,
        )
    ).parsed
