from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.subtenant_info import SubtenantInfo
from ...types import Response


def _get_kwargs(
    tenant_path: str,
    subtenant_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/{tenant_path}/org_details/{subtenant_id}".format(
            tenant_path=quote(str(tenant_path), safe=""),
            subtenant_id=quote(str(subtenant_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> SubtenantInfo | None:
    if response.status_code == 200:
        response_200 = SubtenantInfo.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SubtenantInfo]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    tenant_path: str,
    subtenant_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[SubtenantInfo]:
    """Subtenant Info

     Access core organizational information including timezone, currency, and management
    structure. Essential for understanding customer configuration and operational parameters.
    Shows localization settings that affect all transactions and reporting. Manager
    assignment indicates primary point of contact for account management.

    Args:
        tenant_path (str):
        subtenant_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SubtenantInfo]
    """

    kwargs = _get_kwargs(
        tenant_path=tenant_path,
        subtenant_id=subtenant_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    tenant_path: str,
    subtenant_id: str,
    *,
    client: AuthenticatedClient,
) -> SubtenantInfo | None:
    """Subtenant Info

     Access core organizational information including timezone, currency, and management
    structure. Essential for understanding customer configuration and operational parameters.
    Shows localization settings that affect all transactions and reporting. Manager
    assignment indicates primary point of contact for account management.

    Args:
        tenant_path (str):
        subtenant_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SubtenantInfo
    """

    return sync_detailed(
        tenant_path=tenant_path,
        subtenant_id=subtenant_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    tenant_path: str,
    subtenant_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[SubtenantInfo]:
    """Subtenant Info

     Access core organizational information including timezone, currency, and management
    structure. Essential for understanding customer configuration and operational parameters.
    Shows localization settings that affect all transactions and reporting. Manager
    assignment indicates primary point of contact for account management.

    Args:
        tenant_path (str):
        subtenant_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SubtenantInfo]
    """

    kwargs = _get_kwargs(
        tenant_path=tenant_path,
        subtenant_id=subtenant_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    tenant_path: str,
    subtenant_id: str,
    *,
    client: AuthenticatedClient,
) -> SubtenantInfo | None:
    """Subtenant Info

     Access core organizational information including timezone, currency, and management
    structure. Essential for understanding customer configuration and operational parameters.
    Shows localization settings that affect all transactions and reporting. Manager
    assignment indicates primary point of contact for account management.

    Args:
        tenant_path (str):
        subtenant_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SubtenantInfo
    """

    return (
        await asyncio_detailed(
            tenant_path=tenant_path,
            subtenant_id=subtenant_id,
            client=client,
        )
    ).parsed
