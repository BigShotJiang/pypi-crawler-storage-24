import sys
from setuptools import setup, Extension

# Read the long description from README
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except FileNotFoundError:
    long_description = (
        "A fast native C recursive file scanner and analyzer "
        "with tree and JSON export capabilities."
    )

# Detect platform-specific compiler optimization and linking flags
if sys.platform == "win32":
    # MSVC optimizations and strict warnings
    extra_compile_args = ['/O2', '/W4']
    extra_link_args = []
else:
    # Aggressive POSIX optimizations (GCC/Clang)
    extra_compile_args = ['-O3', '-march=native', '-Wall', '-Wextra', '-Wno-unused-parameter']
    extra_link_args = ['-pthread']

module = Extension(
    'anscom',
    sources=['anscom.c'],
    extra_compile_args=extra_compile_args,
    extra_link_args=extra_link_args,
)

setup(
    name='anscom',
    version='1.3.0',
    author='Aditya Narayan Singh',
    author_email='adityansdsdc@outlook.com',
    description=(
        'A fast native C recursive file scanner and analyzer '
        'with JSON and Tree export capabilities.'
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",

    # Primary links shown on PyPI
    url='https://github.com/PC5518/anscom-nfie-python-extension',
    project_urls={
        "Homepage":    "https://anscomqs.github.io/anscom/",
        "Source":      "https://github.com/PC5518/anscom-nfie-python-extension",
        "Bug Tracker": "https://github.com/PC5518/anscom-nfie-python-extension/issues",
    },

    ext_modules=[module],

    # No hard dependencies — anscom core is pure C
    install_requires=[],

    # Excel export is optional — user installs via: pip install anscom[excel]
    extras_require={
        "excel": ["openpyxl>=3.0.0"],
    },

    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: C",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)