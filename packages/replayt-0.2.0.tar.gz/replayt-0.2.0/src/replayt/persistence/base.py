from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class EventStore(Protocol):
    def append_event(self, run_id: str, *, ts: str, typ: str, payload: dict[str, Any]) -> dict[str, Any]: ...

    def append(self, run_id: str, event: dict[str, Any]) -> None: ...

    def load_events(self, run_id: str) -> list[dict[str, Any]]: ...

    def list_run_ids(self) -> list[str]: ...
