"""Integration tests for NeuralMemory."""
