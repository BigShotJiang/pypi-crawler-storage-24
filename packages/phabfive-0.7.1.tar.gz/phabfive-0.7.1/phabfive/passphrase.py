# -*- coding: utf-8 -*-

# python std lib
import json
import logging
import re

# phabfive imports
from phabfive.constants import MONOGRAMS
from phabfive.core import Phabfive
from phabfive.exceptions import PhabfiveDataException, PhabfiveRemoteException

# 3rd party imports
from phabricator import APIError


log = logging.getLogger(__name__)


class Passphrase(Phabfive):
    def __init__(self):
        super(Passphrase, self).__init__()

    def _validate_identifier(self, id_):
        return re.match(f"^{MONOGRAMS['passphrase']}$", id_)

    def get_secret(self, ids):
        if not self._validate_identifier(ids):
            raise PhabfiveDataException(
                f"Invalid passphrase ID '{ids}'. Expected format: K123"
            )

        ids = ids.replace("K", "")

        try:
            response = self.phab.passphrase.query(
                ids=[ids],
                needSecrets=1,
            )
        except APIError as e:
            raise PhabfiveRemoteException(e)

        has_data = response.get("data", {})

        if not has_data:
            raise PhabfiveDataException(f"K{ids} has no data or other error")

        # TODO: I am doing the logging wrong, in this module the loglevel
        # is INFO, even if env PHABFIVE_DEBUG=1
        log.debug(json.dumps(response["data"], indent=2))

        # When Conduit Access is not accepted for Passphrase the "response" will return value "noAPIAccess" in key "material" instead of the secret
        api_access_value = response["data"].get(next(iter(response["data"])))[
            "material"
        ]
        no_api_access = "noAPIAccess" in api_access_value

        if no_api_access:
            raise PhabfiveDataException(
                f"Access denied, visit {self.url}/K{ids} to allow Conduit",
            )

        # Extract and return the secret value
        for value in response["data"].values():
            for secret_type, secret_value in value["material"].items():
                if secret_type == "password":  # nosec-B105
                    return secret_value

        raise PhabfiveDataException(f"No password found in K{ids}")
