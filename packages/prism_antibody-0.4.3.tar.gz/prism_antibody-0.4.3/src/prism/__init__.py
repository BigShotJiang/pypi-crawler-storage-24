"""
PRISM - Partitioning Residue Identity in Somatic Maturation

A PyTorch Lightning framework for supervised fine-tuning of ESM2 protein
language models on antibody sequences with germline/non-germline awareness.

Quick start::

    import prism

    model = prism.pretrained("checkpoint.ckpt")       # auto-detects GPU
    emb   = model.extract_embedding("EVQLVESGGGLVQ...")  # [H] numpy array
    gl    = model.extract_GL_logit("EVQLVESGGGLVQ...")    # [L, 20] GL log-probs
    ngl   = model.extract_NGL_logit("EVQLVESGGGLVQ...")   # [L, 20] NGL log-probs
    ppl   = model.perplexity("EVQLVESGGGLVQ...")          # scalar perplexity

    # v0.4.0: Binding & developability scoring
    bind  = model.score_binding(wt, mutant)              # scalar delta-binding
    dev   = model.score_developability("EVQLVESGGGLVQ...")  # dict of 6 properties

    # Paired heavy + light chain input
    gl    = model.extract_GL_logit("EVQLV...", light_chains="DIQMT...")

    # score_mutations / score_binding: separate WT and mutant light chains
    score = model.score_mutations(wt_heavy, mut_heavy,
                                  wt_light_chains="DIQMT...",
                                  mut_light_chains="EIVLT...")
    score = model.score_binding(wt_heavy, mut_heavy,
                                wt_light_chain="DIQMT...",
                                mut_light_chains="EIVLT...")

All methods accept a single string or a list of strings.
"""

from .api import pretrained, PrismModel
from .model import SFT_ESM2
from .io_utils import (
    SeqSeqDataset,
    SFTDataModule,
    LazyShardedDataModule,
    make_collate_fn_multihead,
)
from .multimodal_io import (
    GeneVocabulary,
    AntibodyDataset,
    AntibodyDataCollator,
    AntibodyDataCollatorConfig,
    AntibodyMLMCollator,
)
from .utils import get_device

__version__ = "0.4.3"

__all__ = [
    "pretrained",
    "PrismModel",
    "SFT_ESM2",
    "SeqSeqDataset",
    "SFTDataModule",
    "LazyShardedDataModule",
    "make_collate_fn_multihead",
    "GeneVocabulary",
    "AntibodyDataset",
    "AntibodyDataCollator",
    "AntibodyDataCollatorConfig",
    "AntibodyMLMCollator",
    "get_device",
]
