"""Tests for paired heavy/light chain support (v0.4.2).

Tests cover:
- _format_sequences() helper: VH+VL concatenation with <cls><cls> separator
- _tokenize() with paired sequences: correct token ID layout
- All public methods with light_chains= parameter
- Edge cases: mismatched list lengths, None/empty light chains
- score_binding / score_mutations with paired chains
"""

import numpy as np
import pytest
import torch
from unittest.mock import MagicMock

from prism.api import PrismModel


# ---------------------------------------------------------------------------
# Fixtures (reuse mock pattern from test_api.py)
# ---------------------------------------------------------------------------

_AA_ORDER = "ACDEFGHIKLMNPQRSTVWY"
_UPPER_IDS = [5, 23, 13, 9, 18, 6, 21, 12, 15, 4, 20, 17, 14, 16, 10, 8, 11, 7, 22, 19]
_LOWER_IDS = list(range(33, 53))
VOCAB_SIZE = 53
CLS_ID = 0
EOS_ID = 2
PAD_ID = 1


def _make_mock_tokenizer():
    tok = MagicMock()
    tok.cls_token_id = CLS_ID
    tok.pad_token_id = PAD_ID
    tok.eos_token_id = EOS_ID
    tok.unk_token_id = 3
    tok.mask_token_id = 32
    tok.cls_token = "<cls>"

    _token_to_id = {}
    for i, aa in enumerate(_AA_ORDER):
        _token_to_id[aa] = _UPPER_IDS[i]
        _token_to_id[aa.lower()] = _LOWER_IDS[i]

    tok.convert_tokens_to_ids = lambda t: _token_to_id.get(t, tok.unk_token_id)

    def tokenize_call(seqs, return_tensors="pt", padding=True, truncation=True, max_length=512):
        batch_ids = []
        for s in seqs:
            # Handle <cls> special tokens in the string (for paired sequences)
            ids = [CLS_ID]
            i = 0
            while i < len(s):
                if s[i:i+5] == "<cls>":
                    ids.append(CLS_ID)
                    i += 5
                else:
                    ids.append(_token_to_id.get(s[i].upper(), tok.unk_token_id))
                    i += 1
            ids.append(EOS_ID)
            batch_ids.append(ids)
        max_len = max(len(ids) for ids in batch_ids)
        padded = [ids + [PAD_ID] * (max_len - len(ids)) for ids in batch_ids]
        input_ids = torch.tensor(padded)
        attention_mask = (input_ids != PAD_ID).long()
        return {"input_ids": input_ids, "attention_mask": attention_mask}

    tok.side_effect = tokenize_call
    tok.__call__ = tokenize_call
    return tok


def _make_mock_model():
    model = MagicMock()
    model.tokenizer = _make_mock_tokenizer()
    model.eval = MagicMock(return_value=model)
    model.to = MagicMock(return_value=model)
    model.lowercase_aa_token_ids = {_UPPER_IDS[i]: _LOWER_IDS[i] for i in range(20)}

    def forward_multihead(input_ids, attention_mask, v_gene_ids=None, j_gene_ids=None, region_ids=None):
        B, L = input_ids.shape
        logits_aa = torch.randn(B, L, 33)
        logits_aa_ngl = None
        logits_mut = torch.randn(B, L, 2)
        alpha = torch.sigmoid(torch.randn(B, L))
        logits_final = torch.randn(B, L, VOCAB_SIZE)
        hidden = torch.randn(B, L, 480)
        return logits_aa, logits_aa_ngl, logits_mut, alpha, logits_final, hidden

    model._forward_multihead = MagicMock(side_effect=forward_multihead)

    def forward_gene_cond(input_ids, attention_mask, v_gene_ids=None, j_gene_ids=None, region_ids=None, output_hidden_states=False):
        B, L = input_ids.shape
        result = MagicMock()
        result.hidden_states = [torch.randn(B, L, 480)]
        return result

    model._forward_with_gene_conditioning = MagicMock(side_effect=forward_gene_cond)
    return model


@pytest.fixture
def prism_model():
    mock_model = _make_mock_model()
    return PrismModel(mock_model, gene_vocab=None, device="cpu")


# ---------------------------------------------------------------------------
# Tests: _format_sequences
# ---------------------------------------------------------------------------

class TestFormatSequences:
    """Test the internal _format_sequences helper."""

    def test_heavy_only_passthrough(self, prism_model):
        """Without light_chains, sequences should pass through unchanged."""
        result = prism_model._format_sequences(["EVQLV", "DIQMT"], light_chains=None)
        assert result == ["EVQLV", "DIQMT"]

    def test_paired_concatenation(self, prism_model):
        """With light_chains, should concatenate as VH<cls><cls>VL."""
        cls = prism_model.tokenizer.cls_token  # "<cls>"
        result = prism_model._format_sequences(
            ["EVQLV"], light_chains=["DIQMT"]
        )
        assert result == [f"EVQLV{cls}{cls}DIQMT"]

    def test_paired_batch(self, prism_model):
        """Batch of paired sequences."""
        cls = prism_model.tokenizer.cls_token
        result = prism_model._format_sequences(
            ["EVQLV", "QVQLV"], light_chains=["DIQMT", "EIVLT"]
        )
        assert result == [
            f"EVQLV{cls}{cls}DIQMT",
            f"QVQLV{cls}{cls}EIVLT",
        ]

    def test_length_mismatch_raises(self, prism_model):
        """Mismatched heavy/light list lengths should raise ValueError."""
        with pytest.raises(ValueError, match="length.*mismatch"):
            prism_model._format_sequences(
                ["EVQLV", "QVQLV"], light_chains=["DIQMT"]
            )

    def test_single_string_heavy_with_single_string_light(self, prism_model):
        """Single string inputs (not lists) should also work."""
        cls = prism_model.tokenizer.cls_token
        result = prism_model._format_sequences(["EVQLV"], light_chains=["DIQMT"])
        assert result == [f"EVQLV{cls}{cls}DIQMT"]

    def test_empty_light_chain_passthrough(self, prism_model):
        """Empty light_chains list should be treated as None."""
        # light_chains=None means no pairing
        result = prism_model._format_sequences(["EVQLV"], light_chains=None)
        assert result == ["EVQLV"]


# ---------------------------------------------------------------------------
# Tests: tokenization of paired sequences
# ---------------------------------------------------------------------------

class TestPairedTokenization:
    """Verify that paired sequences produce the correct token layout:
    <cls> VH <cls> <cls> VL <eos>
    """

    def test_paired_token_ids_layout(self, prism_model):
        """Paired tokenization should produce <cls>VH<cls><cls>VL<eos>."""
        cls = prism_model.tokenizer.cls_token
        paired_seq = f"ACE{cls}{cls}DF"
        input_ids, attn_mask = prism_model._tokenize([paired_seq])
        ids = input_ids[0].tolist()

        # Expected: [CLS, A, C, E, CLS, CLS, D, F, EOS]
        assert ids[0] == CLS_ID, "Should start with CLS"
        assert ids[-1] == EOS_ID, "Should end with EOS"
        # Internal CLS tokens should be present
        # Positions: 0=CLS, 1=A(5), 2=C(23), 3=E(9), 4=CLS(0), 5=CLS(0), 6=D(13), 7=F(18), 8=EOS
        assert ids[4] == CLS_ID, "Internal separator CLS 1"
        assert ids[5] == CLS_ID, "Internal separator CLS 2"


# ---------------------------------------------------------------------------
# Tests: public methods with light_chains parameter
# ---------------------------------------------------------------------------

class TestExtractGLLogitPaired:
    def test_accepts_light_chains(self, prism_model):
        result = prism_model.extract_GL_logit("EVQLV", light_chains="DIQMT")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 2
        assert result.shape[1] == 20

    def test_batch_with_light_chains(self, prism_model):
        result = prism_model.extract_GL_logit(
            ["EVQLV", "QVQLV"], light_chains=["DIQMT", "EIVLT"]
        )
        assert isinstance(result, list)
        assert len(result) == 2
        assert all(r.shape[1] == 20 for r in result)

    def test_paired_longer_than_heavy_only(self, prism_model):
        """Paired sequence should be longer due to VL + 2 CLS tokens."""
        heavy_only = prism_model.extract_GL_logit("EVQLV")
        paired = prism_model.extract_GL_logit("EVQLV", light_chains="DIQMT")
        # paired has 5 (VH) + 2 (CLS) + 5 (VL) + 2 (BOS+EOS) = 14
        # heavy only has 5 + 2 = 7
        assert paired.shape[0] > heavy_only.shape[0]


class TestExtractNGLLogitPaired:
    def test_accepts_light_chains(self, prism_model):
        result = prism_model.extract_NGL_logit("EVQLV", light_chains="DIQMT")
        assert isinstance(result, np.ndarray)
        assert result.shape[1] == 20


class TestExtractFullLogitPaired:
    def test_accepts_light_chains(self, prism_model):
        result = prism_model.extract_full_logit("EVQLV", light_chains="DIQMT")
        assert isinstance(result, np.ndarray)
        assert result.shape[1] == VOCAB_SIZE


class TestExtractMarginalizedLogitPaired:
    def test_accepts_light_chains(self, prism_model):
        result = prism_model.extract_marginalized_logit("EVQLV", light_chains="DIQMT")
        assert isinstance(result, np.ndarray)
        assert result.shape[1] == 20


class TestExtractAlphaPaired:
    def test_accepts_light_chains(self, prism_model):
        result = prism_model.extract_alpha("EVQLV", light_chains="DIQMT")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 1


class TestPerplexityPaired:
    def test_accepts_light_chains(self, prism_model):
        result = prism_model.perplexity("EVQLV", light_chains="DIQMT")
        assert isinstance(result, (float, np.floating))

    def test_batch_with_light_chains(self, prism_model):
        result = prism_model.perplexity(
            ["EVQLV", "QVQLV"], light_chains=["DIQMT", "EIVLT"]
        )
        assert isinstance(result, np.ndarray)
        assert result.shape == (2,)


class TestPseudoLogLikelihoodPaired:
    def test_accepts_light_chains(self, prism_model):
        result = prism_model.pseudo_log_likelihood("EVQLV", light_chains="DIQMT")
        assert isinstance(result, (float, np.floating))


class TestEmbedPaired:
    def test_mean_embedding_with_light_chains(self, prism_model):
        result = prism_model.embed("EVQLV", light_chains="DIQMT", mode="mean")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 1

    def test_per_residue_embedding_with_light_chains(self, prism_model):
        result = prism_model.embed("EVQLV", light_chains="DIQMT", mode="per_residue")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 2

    def test_cls_embedding_with_light_chains(self, prism_model):
        result = prism_model.embed("EVQLV", light_chains="DIQMT", mode="cls")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 1


class TestExtractEmbeddingPaired:
    def test_alias_works_with_light_chains(self, prism_model):
        result = prism_model.extract_embedding("EVQLV", light_chains="DIQMT")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 1


class TestLogitsPaired:
    def test_accepts_light_chains(self, prism_model):
        result = prism_model.logits("EVQLV", light_chains="DIQMT")
        assert isinstance(result, torch.Tensor)


class TestPredictOriginPaired:
    def test_accepts_light_chains(self, prism_model):
        result = prism_model.predict_origin("EVQLV", light_chains="DIQMT")
        assert isinstance(result, dict)
        assert "origin_logits" in result
        assert "origin_probs" in result


class TestScoreMutationsPaired:
    def test_accepts_light_chains(self, prism_model):
        """Shared light chain for both WT and mutant (backward compat)."""
        result = prism_model.score_mutations(
            "EVQLV", "EVQAV", wt_light_chains="DIQMT", mut_light_chains="DIQMT"
        )
        assert isinstance(result, (float, np.floating))

    def test_batch_with_light_chains(self, prism_model):
        result = prism_model.score_mutations(
            ["EVQLV", "EVQLV"],
            ["EVQAV", "EVQAV"],
            wt_light_chains=["DIQMT", "DIQMT"],
            mut_light_chains=["DIQMT", "DIQMT"],
        )
        assert isinstance(result, np.ndarray)
        assert result.shape == (2,)

    def test_different_wt_and_mut_light_chains(self, prism_model):
        """WT and mutant can have different light chains."""
        result = prism_model.score_mutations(
            "EVQLV", "EVQAV",
            wt_light_chains="DIQMT",
            mut_light_chains="EIVLT",
        )
        assert isinstance(result, (float, np.floating))

    def test_only_wt_light_chains(self, prism_model):
        """Providing only wt_light_chains (mut stays heavy-only) should work."""
        result = prism_model.score_mutations(
            "EVQLV", "EVQAV",
            wt_light_chains="DIQMT",
        )
        assert isinstance(result, (float, np.floating))

    def test_only_mut_light_chains(self, prism_model):
        """Providing only mut_light_chains (wt stays heavy-only) should work."""
        result = prism_model.score_mutations(
            "EVQLV", "EVQAV",
            mut_light_chains="DIQMT",
        )
        assert isinstance(result, (float, np.floating))


class TestScoreDevelopabilityPaired:
    def test_accepts_light_chains(self, prism_model):
        result = prism_model.score_developability("EVQLV", light_chains="DIQMT")
        assert isinstance(result, dict)

    def test_batch_with_light_chains(self, prism_model):
        result = prism_model.score_developability(
            ["EVQLV", "QVQLV"], light_chains=["DIQMT", "EIVLT"]
        )
        assert isinstance(result, list)
        assert len(result) == 2


class TestScoreBindingPaired:
    def test_accepts_light_chains(self, prism_model):
        result = prism_model.score_binding(
            "EVQLV", "EVQAV",
            wt_light_chain="DIQMT", mut_light_chains="DIQMT",
        )
        assert isinstance(result, (float, np.floating))

    def test_batch_with_light_chains(self, prism_model):
        result = prism_model.score_binding(
            "EVQLV",
            ["EVQAV", "EVQAV"],
            wt_light_chain="DIQMT",
            mut_light_chains=["DIQMT", "DIQMT"],
        )
        assert isinstance(result, np.ndarray)
        assert result.shape == (2,)

    def test_different_wt_and_mut_light_chains(self, prism_model):
        """WT and mutant can have different light chains."""
        result = prism_model.score_binding(
            "EVQLV", "EVQAV",
            wt_light_chain="DIQMT",
            mut_light_chains="EIVLT",
        )
        assert isinstance(result, (float, np.floating))

    def test_batch_different_mut_light_chains(self, prism_model):
        """Each mutant can have its own light chain."""
        result = prism_model.score_binding(
            "EVQLV",
            ["EVQAV", "EVQAV"],
            wt_light_chain="DIQMT",
            mut_light_chains=["EIVLT", "NPRST"],
        )
        assert isinstance(result, np.ndarray)
        assert result.shape == (2,)
