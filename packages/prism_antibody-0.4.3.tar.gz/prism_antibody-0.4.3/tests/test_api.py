"""Tests for PRISM public inference API (v0.3.0).

Uses mocking to avoid needing a real checkpoint. Tests cover:
- Single-string input/output (scalar unwrapping)
- List input/output (backward compatibility)
- All extract_* methods and their output shapes
- perplexity() convenience method
- device="auto" resolution
- _load_data() file format handling and auto-split
- finetune() method with mocked Trainer
"""

import numpy as np
import pandas as pd
import pytest
import torch
import torch.nn.functional as F
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock

from prism.api import PrismModel, pretrained


# ---------------------------------------------------------------------------
# Fixtures: build a mock PrismModel without loading a real checkpoint
# ---------------------------------------------------------------------------

# Realistic ESM2 vocab: 33 standard tokens + 20 lowercase = 53
# Standard ESM2 token IDs for uppercase AAs (alphabetical):
# A=5, C=23, D=13, E=9, F=18, G=6, H=21, I=12, K=15, L=4,
# M=20, N=17, P=14, Q=16, R=10, S=8, T=11, V=7, W=22, Y=19
_AA_ORDER = "ACDEFGHIKLMNPQRSTVWY"
_UPPER_IDS = [5, 23, 13, 9, 18, 6, 21, 12, 15, 4, 20, 17, 14, 16, 10, 8, 11, 7, 22, 19]
# Lowercase IDs: 33..52 (added custom tokens)
_LOWER_IDS = list(range(33, 53))
VOCAB_SIZE = 53


def _make_mock_tokenizer():
    """Create a mock tokenizer that behaves like ESM2 + lowercase tokens."""
    tok = MagicMock()
    tok.cls_token_id = 0
    tok.pad_token_id = 1
    tok.eos_token_id = 2
    tok.unk_token_id = 3
    tok.mask_token_id = 32
    tok.cls_token = "<cls>"

    # Build token-to-id mapping
    _token_to_id = {}
    for i, aa in enumerate(_AA_ORDER):
        _token_to_id[aa] = _UPPER_IDS[i]
        _token_to_id[aa.lower()] = _LOWER_IDS[i]

    tok.convert_tokens_to_ids = lambda t: _token_to_id.get(t, tok.unk_token_id)

    # Tokenizer __call__: encode sequences to fake input_ids
    def tokenize_call(seqs, return_tensors="pt", padding=True, truncation=True, max_length=512):
        batch_ids = []
        for s in seqs:
            ids = [tok.cls_token_id] + [_token_to_id.get(c, tok.unk_token_id) for c in s.upper()] + [tok.eos_token_id]
            batch_ids.append(ids)
        max_len = max(len(ids) for ids in batch_ids)
        padded = [ids + [tok.pad_token_id] * (max_len - len(ids)) for ids in batch_ids]
        input_ids = torch.tensor(padded)
        attention_mask = (input_ids != tok.pad_token_id).long()
        return {"input_ids": input_ids, "attention_mask": attention_mask}

    tok.side_effect = tokenize_call
    tok.__call__ = tokenize_call
    return tok


def _make_mock_model():
    """Create a mock SFT_ESM2 model."""
    model = MagicMock()
    model.tokenizer = _make_mock_tokenizer()
    model.eval = MagicMock(return_value=model)
    model.to = MagicMock(return_value=model)

    # lowercase_aa_token_ids: {upper_id: lower_id}
    model.lowercase_aa_token_ids = {
        _UPPER_IDS[i]: _LOWER_IDS[i] for i in range(20)
    }

    # _forward_multihead returns (logits_aa, logits_aa_ngl, logits_mut, alpha, logits_final, hidden)
    def forward_multihead(input_ids, attention_mask, v_gene_ids=None, j_gene_ids=None, region_ids=None):
        B, L = input_ids.shape
        logits_aa = torch.randn(B, L, 33)
        logits_aa_ngl = None  # None when use_dual_aa_heads=False (v34 compat)
        logits_mut = torch.randn(B, L, 2)
        alpha = torch.sigmoid(torch.randn(B, L))
        logits_final = torch.randn(B, L, VOCAB_SIZE)
        hidden = torch.randn(B, L, 480)
        return logits_aa, logits_aa_ngl, logits_mut, alpha, logits_final, hidden

    model._forward_multihead = MagicMock(side_effect=forward_multihead)

    # _forward_with_gene_conditioning for embed()
    def forward_gene_cond(input_ids, attention_mask, v_gene_ids=None, j_gene_ids=None, region_ids=None, output_hidden_states=False):
        B, L = input_ids.shape
        result = MagicMock()
        result.hidden_states = [torch.randn(B, L, 480)]
        return result

    model._forward_with_gene_conditioning = MagicMock(side_effect=forward_gene_cond)

    return model


@pytest.fixture
def prism_model():
    """Build a PrismModel backed by mocks."""
    mock_model = _make_mock_model()
    return PrismModel(mock_model, gene_vocab=None, device="cpu")


# ---------------------------------------------------------------------------
# Tests: device="auto"
# ---------------------------------------------------------------------------

class TestDeviceAuto:
    def test_auto_resolves_to_cpu_when_no_cuda(self):
        with patch("torch.cuda.is_available", return_value=False):
            from prism.api import _resolve_device
            assert _resolve_device("auto") == "cpu"

    def test_auto_resolves_to_cuda_when_available(self):
        with patch("torch.cuda.is_available", return_value=True):
            from prism.api import _resolve_device
            assert _resolve_device("auto") == "cuda"

    def test_explicit_device_passthrough(self):
        from prism.api import _resolve_device
        assert _resolve_device("cpu") == "cpu"
        assert _resolve_device("cuda:1") == "cuda:1"


# ---------------------------------------------------------------------------
# Tests: single-string support helpers
# ---------------------------------------------------------------------------

class TestSingleStringHelpers:
    def test_ensure_list_string(self):
        from prism.api import _ensure_list
        result, was_single = _ensure_list("EVQLV")
        assert result == ["EVQLV"]
        assert was_single is True

    def test_ensure_list_list(self):
        from prism.api import _ensure_list
        result, was_single = _ensure_list(["EVQLV", "DIQMT"])
        assert result == ["EVQLV", "DIQMT"]
        assert was_single is False

    def test_unwrap_single_list(self):
        from prism.api import _unwrap_single
        arr = np.array([1.0, 2.0])
        result = _unwrap_single([arr], was_single=True)
        assert isinstance(result, np.ndarray)
        np.testing.assert_array_equal(result, arr)

    def test_unwrap_single_noop_for_list_input(self):
        from prism.api import _unwrap_single
        items = [np.array([1.0]), np.array([2.0])]
        result = _unwrap_single(items, was_single=False)
        assert len(result) == 2

    def test_unwrap_single_ndarray(self):
        from prism.api import _unwrap_single
        arr = np.array([[1.0, 2.0]])  # shape (1, 2)
        result = _unwrap_single(arr, was_single=True)
        assert result.shape == (2,)

    def test_unwrap_single_scalar(self):
        from prism.api import _unwrap_single
        arr = np.array([3.14])  # shape (1,)
        result = _unwrap_single(arr, was_single=True)
        assert isinstance(result, (float, np.floating))


# ---------------------------------------------------------------------------
# Tests: extract_full_logit
# ---------------------------------------------------------------------------

class TestExtractFullLogit:
    def test_list_input_returns_list(self, prism_model):
        result = prism_model.extract_full_logit(["ACDEF", "GHIKL"])
        assert isinstance(result, list)
        assert len(result) == 2

    def test_single_string_returns_single_array(self, prism_model):
        result = prism_model.extract_full_logit("ACDEF")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 2
        # Shape: [L, 53] where L = len("ACDEF") + 2 (CLS, EOS)
        assert result.shape[1] == VOCAB_SIZE

    def test_output_is_log_softmax(self, prism_model):
        result = prism_model.extract_full_logit("ACDEF")
        # All values should be <= 0 (log probabilities)
        assert np.all(result <= 0.0 + 1e-6)
        # Each row should sum to ~1.0 in probability space
        probs = np.exp(result)
        row_sums = probs.sum(axis=1)
        np.testing.assert_allclose(row_sums, 1.0, atol=1e-5)


# ---------------------------------------------------------------------------
# Tests: extract_GL_logit and extract_NGL_logit
# ---------------------------------------------------------------------------

class TestExtractGLLogit:
    def test_shape_single_string(self, prism_model):
        result = prism_model.extract_GL_logit("ACDEF")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 2
        assert result.shape[1] == 20  # 20 amino acids

    def test_shape_list(self, prism_model):
        result = prism_model.extract_GL_logit(["ACDEF", "GHI"])
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0].shape[1] == 20
        assert result[1].shape[1] == 20

    def test_values_are_log_probs(self, prism_model):
        result = prism_model.extract_GL_logit("ACDEF")
        assert np.all(result <= 0.0 + 1e-6)


class TestExtractNGLLogit:
    def test_shape_single_string(self, prism_model):
        result = prism_model.extract_NGL_logit("ACDEF")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 2
        assert result.shape[1] == 20

    def test_shape_list(self, prism_model):
        result = prism_model.extract_NGL_logit(["ACDEF", "GHI"])
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0].shape[1] == 20

    def test_values_are_log_probs(self, prism_model):
        result = prism_model.extract_NGL_logit("ACDEF")
        assert np.all(result <= 0.0 + 1e-6)


# ---------------------------------------------------------------------------
# Tests: extract_marginalized_logit
# ---------------------------------------------------------------------------

class TestExtractMarginalizedLogit:
    def test_shape_single_string(self, prism_model):
        result = prism_model.extract_marginalized_logit("ACDEF")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 2
        assert result.shape[1] == 20

    def test_shape_list(self, prism_model):
        result = prism_model.extract_marginalized_logit(["ACDEF", "GHI"])
        assert isinstance(result, list)
        assert len(result) == 2

    def test_marginalized_geq_components(self, prism_model):
        """Marginalized (logsumexp) should be >= each component.

        We compute all three from the same full logit to ensure the same
        forward pass is used (mock generates random logits each call).
        """
        seq = "ACDEF"
        full = prism_model.extract_full_logit(seq)  # [L, 53]
        gl = full[:, prism_model._gl_indices]
        ngl = full[:, prism_model._ngl_indices]
        marg = np.logaddexp(gl, ngl)
        # logsumexp(a, b) >= max(a, b) always
        assert np.all(marg >= gl - 1e-5)
        assert np.all(marg >= ngl - 1e-5)


# ---------------------------------------------------------------------------
# Tests: extract_alpha
# ---------------------------------------------------------------------------

class TestExtractAlpha:
    def test_shape_single_string(self, prism_model):
        result = prism_model.extract_alpha("ACDEF")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 1

    def test_shape_list(self, prism_model):
        result = prism_model.extract_alpha(["ACDEF", "GHI"])
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0].ndim == 1
        assert result[1].ndim == 1


# ---------------------------------------------------------------------------
# Tests: extract_embedding (alias for embed)
# ---------------------------------------------------------------------------

class TestExtractEmbedding:
    def test_single_string_returns_1d(self, prism_model):
        result = prism_model.extract_embedding("ACDEF")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 1  # [H] not [1, H]

    def test_list_returns_2d(self, prism_model):
        result = prism_model.extract_embedding(["ACDEF", "GHI"])
        assert isinstance(result, np.ndarray)
        assert result.ndim == 2  # [N, H]

    def test_per_residue_single_string(self, prism_model):
        result = prism_model.extract_embedding("ACDEF", mode="per_residue")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 2  # [L, H]

    def test_per_residue_list(self, prism_model):
        result = prism_model.extract_embedding(["ACDEF", "GHI"], mode="per_residue")
        assert isinstance(result, list)
        assert len(result) == 2


# ---------------------------------------------------------------------------
# Tests: perplexity
# ---------------------------------------------------------------------------

class TestPerplexity:
    def test_single_string_returns_float(self, prism_model):
        # Mock pseudo_log_likelihood to avoid full PLL computation
        prism_model.pseudo_log_likelihood = MagicMock(return_value=np.array([-50.0]))
        result = prism_model.perplexity("ACDEF")
        assert isinstance(result, (float, np.floating))
        assert result > 0  # perplexity is always positive

    def test_list_returns_array(self, prism_model):
        prism_model.pseudo_log_likelihood = MagicMock(return_value=np.array([-50.0, -30.0]))
        result = prism_model.perplexity(["ACDEF", "GHI"])
        assert isinstance(result, np.ndarray)
        assert len(result) == 2
        assert np.all(result > 0)

    def test_perplexity_formula(self, prism_model):
        """PPL = exp(-PLL / seq_length)"""
        prism_model.pseudo_log_likelihood = MagicMock(return_value=np.array([-10.0]))
        result = prism_model.perplexity("ACDEF")
        expected = np.exp(-(-10.0) / 5)  # seq_length = 5
        np.testing.assert_allclose(result, expected, rtol=1e-5)


# ---------------------------------------------------------------------------
# Tests: single-string support on existing methods
# ---------------------------------------------------------------------------

class TestSingleStringExistingMethods:
    def test_logits_single_string(self, prism_model):
        result = prism_model.logits("ACDEF", head="final")
        # Should return a single tensor, not a list
        assert isinstance(result, torch.Tensor)
        assert result.ndim == 2

    def test_logits_list_backward_compat(self, prism_model):
        result = prism_model.logits(["ACDEF", "GHI"], head="final")
        assert isinstance(result, list)
        assert len(result) == 2

    def test_embed_single_string(self, prism_model):
        result = prism_model.embed("ACDEF")
        assert isinstance(result, np.ndarray)
        assert result.ndim == 1  # [H] not [1, H]

    def test_predict_origin_single_string(self, prism_model):
        result = prism_model.predict_origin("ACDEF")
        assert isinstance(result, dict)
        assert "origin_logits" in result

    def test_score_mutations_single_string(self, prism_model):
        result = prism_model.score_mutations("ACDEF", "ACGEF")
        assert isinstance(result, (float, np.floating))


# ---------------------------------------------------------------------------
# Tests: AA_ORDER class attribute
# ---------------------------------------------------------------------------

class TestAAOrder:
    def test_aa_order_exists(self, prism_model):
        assert hasattr(prism_model, "AA_ORDER")
        assert prism_model.AA_ORDER == "ACDEFGHIKLMNPQRSTVWY"
        assert len(prism_model.AA_ORDER) == 20


# ---------------------------------------------------------------------------
# Tests: gene conditioning passthrough
# ---------------------------------------------------------------------------

class TestGeneConditioning:
    def test_extract_gl_with_genes(self, prism_model):
        """Gene args should be forwarded without error."""
        # This just tests it doesn't crash; actual gene encoding requires real vocab
        result = prism_model.extract_GL_logit("ACDEF")
        assert result.shape[1] == 20


# ---------------------------------------------------------------------------
# Tests: _resolve_checkpoint (HF Hub support)
# ---------------------------------------------------------------------------

class TestResolveCheckpoint:
    def test_local_file_passthrough(self, tmp_path):
        """Local .ckpt file should pass through as-is."""
        from prism.api import _resolve_checkpoint
        ckpt = tmp_path / "model.ckpt"
        ckpt.touch()
        assert _resolve_checkpoint(str(ckpt)) == str(ckpt)

    def test_hf_hub_id_detected(self):
        """A string like 'org/model-name' should trigger HF Hub download."""
        from prism.api import _resolve_checkpoint
        with patch("prism.api.hf_hub_download") as mock_dl:
            mock_dl.return_value = "/tmp/cached/checkpoint.ckpt"
            result = _resolve_checkpoint("RomeroLab-Duke/prism-antibody")
            mock_dl.assert_called_once_with(
                repo_id="RomeroLab-Duke/prism-antibody",
                filename="checkpoint.ckpt",
            )
            assert result == "/tmp/cached/checkpoint.ckpt"

    def test_hf_hub_import_error(self):
        """Should raise ImportError with helpful message if huggingface_hub missing."""
        from prism.api import _resolve_checkpoint
        with patch("prism.api.hf_hub_download", None):
            with pytest.raises((ImportError, FileNotFoundError)):
                _resolve_checkpoint("RomeroLab-Duke/prism-antibody")

    def test_nonexistent_local_path_raises(self):
        """Non-existent path that doesn't look like HF ID should raise FileNotFoundError."""
        from prism.api import _resolve_checkpoint
        with pytest.raises(FileNotFoundError):
            _resolve_checkpoint("/nonexistent/path/model.ckpt")

    def test_absolute_path_with_slash_not_treated_as_hf(self, tmp_path):
        """Paths starting with / should not be treated as HF Hub IDs."""
        from prism.api import _resolve_checkpoint
        with pytest.raises(FileNotFoundError):
            _resolve_checkpoint("/org/model-name")

    def test_relative_path_with_dot_not_treated_as_hf(self):
        """Paths starting with . should not be treated as HF Hub IDs."""
        from prism.api import _resolve_checkpoint
        with pytest.raises(FileNotFoundError):
            _resolve_checkpoint("./org/model-name")

    def test_tilde_path_not_treated_as_hf(self):
        """Paths starting with ~ should not be treated as HF Hub IDs."""
        from prism.api import _resolve_checkpoint
        with pytest.raises(FileNotFoundError):
            _resolve_checkpoint("~/org/model-name")


# ---------------------------------------------------------------------------
# Tests: _get_bundled_gene_vocab
# ---------------------------------------------------------------------------

class TestBundledGeneVocab:
    def test_returns_valid_path(self):
        """Should return path to bundled gene_vocabulary.json."""
        from prism.api import _get_bundled_gene_vocab
        path = _get_bundled_gene_vocab()
        assert path.endswith("gene_vocabulary.json")
        assert Path(path).exists()

    def test_file_is_valid_json(self):
        """The bundled gene vocab should be valid JSON."""
        import json
        from prism.api import _get_bundled_gene_vocab
        path = _get_bundled_gene_vocab()
        with open(path) as f:
            data = json.load(f)
        assert isinstance(data, dict)
        assert len(data) > 0


# ---------------------------------------------------------------------------
# Tests: pretrained() with HF Hub ID
# ---------------------------------------------------------------------------

class TestPretrainedHFHub:
    def test_pretrained_calls_resolve_checkpoint(self):
        """pretrained() should use _resolve_checkpoint to handle HF Hub IDs."""
        with patch("prism.api._resolve_checkpoint") as mock_resolve:
            mock_resolve.return_value = "/tmp/cached/checkpoint.ckpt"
            with patch("torch.load") as mock_load:
                mock_load.return_value = {
                    "hyper_parameters": {"model_identifier": "esm2_t12_35M_UR50D"},
                    "state_dict": {},
                }
                with patch("prism.model.SFT_ESM2") as mock_cls:
                    mock_model = _make_mock_model()
                    mock_cls.return_value = mock_model
                    pretrained("RomeroLab-Duke/prism-antibody")
                    mock_resolve.assert_called_once_with("RomeroLab-Duke/prism-antibody")

    def test_pretrained_gene_vocab_fallback_to_bundled(self):
        """When gene vocab path from hparams doesn't exist, should fallback to bundled."""
        with patch("prism.api._resolve_checkpoint", return_value="/tmp/ckpt.ckpt"):
            with patch("torch.load") as mock_load:
                mock_load.return_value = {
                    "hyper_parameters": {
                        "model_identifier": "esm2_t12_35M_UR50D",
                        "use_germline_genes": True,
                        "gene_vocab_path": "/nonexistent/gene_vocabulary.json",
                        "num_genes": 100,
                    },
                    "state_dict": {},
                }
                with patch("prism.model.SFT_ESM2") as mock_cls:
                    mock_model = _make_mock_model()
                    mock_cls.return_value = mock_model
                    with patch("prism.multimodal_io.GeneVocabulary") as mock_vocab_cls:
                        mock_vocab = MagicMock()
                        mock_vocab.__len__ = MagicMock(return_value=100)
                        mock_vocab_cls.from_json.return_value = mock_vocab
                        pretrained("RomeroLab-Duke/prism-antibody")
                        # Should have called from_json with the bundled path
                        call_args = mock_vocab_cls.from_json.call_args
                        if call_args is not None:
                            vocab_path = call_args[0][0]
                            assert "prism/data/gene_vocabulary.json" in vocab_path


# ---------------------------------------------------------------------------
# Helpers for finetune tests
# ---------------------------------------------------------------------------

def _make_test_df(n=100, with_split=False):
    """Create a minimal DataFrame suitable for SFTDataModule."""
    df = pd.DataFrame({
        "HEAVY_CHAIN_AA_SEQUENCE": ["EVQLVESGGGLVQ" + "A" * 10] * n,
        "LIGHT_CHAIN_AA_SEQUENCE": ["DIQMTQSPSSLSA" + "G" * 10] * n,
    })
    if with_split:
        splits = ["train"] * (n - 10) + ["valid"] * 5 + ["test"] * 5
        df["split"] = splits
    return df


# ---------------------------------------------------------------------------
# Tests: _load_data
# ---------------------------------------------------------------------------

class TestLoadData:
    def test_load_parquet_adds_split(self, tmp_path):
        """Loading a parquet file without split column should auto-add 90/5/5 split."""
        df = _make_test_df(100, with_split=False)
        path = tmp_path / "data.parquet"
        df.to_parquet(path)

        result = PrismModel._load_data(str(path))
        assert "split" in result.columns
        assert set(result["split"].unique()) == {"train", "valid", "test"}
        # Check approximate proportions
        n_train = (result["split"] == "train").sum()
        assert n_train >= 85  # ~90% of 100

    def test_load_parquet_preserves_existing_split(self, tmp_path):
        """If split column already exists, it should not be overwritten."""
        df = _make_test_df(100, with_split=True)
        path = tmp_path / "data.parquet"
        df.to_parquet(path)

        result = PrismModel._load_data(str(path))
        assert "split" in result.columns
        # Original split had 90 train, 5 valid, 5 test
        assert (result["split"] == "train").sum() == 90
        assert (result["split"] == "valid").sum() == 5
        assert (result["split"] == "test").sum() == 5

    def test_load_pickle(self, tmp_path):
        """Should load .pkl files correctly."""
        df = _make_test_df(50, with_split=True)
        path = tmp_path / "data.pkl"
        df.to_pickle(path)

        result = PrismModel._load_data(str(path))
        assert len(result) == 50
        assert "split" in result.columns

    def test_load_csv(self, tmp_path):
        """Should load .csv files correctly."""
        df = _make_test_df(50, with_split=True)
        path = tmp_path / "data.csv"
        df.to_csv(path, index=False)

        result = PrismModel._load_data(str(path))
        assert len(result) == 50
        assert "split" in result.columns

    def test_unsupported_format_raises(self, tmp_path):
        """Should raise ValueError for unsupported file formats."""
        path = tmp_path / "data.txt"
        path.write_text("not a valid format")

        with pytest.raises(ValueError, match="Unsupported file format"):
            PrismModel._load_data(str(path))

    def test_auto_split_minimum_one_val_test(self, tmp_path):
        """Even with tiny datasets, should have at least 1 val and 1 test sample."""
        df = _make_test_df(5, with_split=False)
        path = tmp_path / "data.parquet"
        df.to_parquet(path)

        result = PrismModel._load_data(str(path))
        assert (result["split"] == "valid").sum() >= 1
        assert (result["split"] == "test").sum() >= 1


# ---------------------------------------------------------------------------
# Tests: finetune
# ---------------------------------------------------------------------------

class TestFinetune:
    def test_finetune_runs_trainer(self, prism_model, tmp_path):
        """finetune() should create a Trainer and call fit()."""
        # Create test data
        df = _make_test_df(50, with_split=True)
        data_path = tmp_path / "data.parquet"
        df.to_parquet(data_path)

        output_dir = str(tmp_path / "output")

        with patch("prism.io_utils.SFTDataModule") as mock_dm_cls, \
             patch("prism.api.pl.Trainer") as mock_trainer_cls:
            mock_dm = MagicMock()
            mock_dm_cls.return_value = mock_dm

            mock_trainer = MagicMock()
            mock_trainer.callback_metrics = {"val/Final_PPL_All": 2.5}
            mock_ckpt_callback = MagicMock()
            mock_ckpt_callback.best_model_path = str(tmp_path / "best.ckpt")
            mock_trainer.checkpoint_callback = mock_ckpt_callback
            mock_trainer_cls.return_value = mock_trainer

            with patch.object(prism_model, "_reload_best_checkpoint"):
                result = prism_model.finetune(
                    data_path=str(data_path),
                    output_dir=output_dir,
                    max_steps=10,
                )

            # Trainer.fit() should have been called
            mock_trainer.fit.assert_called_once()
            # Should return the best checkpoint path
            assert result == str(tmp_path / "best.ckpt")

    def test_finetune_updates_hparams(self, prism_model, tmp_path):
        """finetune() should update model hparams before training."""
        df = _make_test_df(50, with_split=True)
        data_path = tmp_path / "data.parquet"
        df.to_parquet(data_path)

        with patch("prism.io_utils.SFTDataModule") as mock_dm_cls, \
             patch("prism.api.pl.Trainer") as mock_trainer_cls:
            mock_dm_cls.return_value = MagicMock()
            mock_trainer = MagicMock()
            mock_ckpt_callback = MagicMock()
            mock_ckpt_callback.best_model_path = str(tmp_path / "best.ckpt")
            mock_trainer.checkpoint_callback = mock_ckpt_callback
            mock_trainer_cls.return_value = mock_trainer

            with patch.object(prism_model, "_reload_best_checkpoint"):
                prism_model.finetune(
                    data_path=str(data_path),
                    output_dir=str(tmp_path / "output"),
                    max_steps=200,
                    learning_rate=2e-4,
                    warmup_steps=50,
                    weight_decay=0.05,
                )

            # Check model hparams were updated
            assert prism_model.model.peak_learning_rate == 2e-4
            assert prism_model.model.max_steps == 200
            assert prism_model.model.warmup_steps == 50
            assert prism_model.model.WD == 0.05

    def test_finetune_unfreezes_all_layers(self, prism_model, tmp_path):
        """finetune() should unfreeze all model parameters."""
        df = _make_test_df(50, with_split=True)
        data_path = tmp_path / "data.parquet"
        df.to_parquet(data_path)

        with patch("prism.io_utils.SFTDataModule") as mock_dm_cls, \
             patch("prism.api.pl.Trainer") as mock_trainer_cls:
            mock_dm_cls.return_value = MagicMock()
            mock_trainer = MagicMock()
            mock_ckpt_callback = MagicMock()
            mock_ckpt_callback.best_model_path = str(tmp_path / "best.ckpt")
            mock_trainer.checkpoint_callback = mock_ckpt_callback
            mock_trainer_cls.return_value = mock_trainer

            # Add mock parameters to check unfreezing
            param1 = torch.nn.Parameter(torch.randn(2, 2))
            param1.requires_grad = False
            param2 = torch.nn.Parameter(torch.randn(3, 3))
            param2.requires_grad = False
            prism_model.model.parameters = MagicMock(return_value=[param1, param2])

            with patch.object(prism_model, "_reload_best_checkpoint"):
                prism_model.finetune(
                    data_path=str(data_path),
                    output_dir=str(tmp_path / "output"),
                    max_steps=10,
                )

            # All parameters should be unfrozen
            assert param1.requires_grad is True
            assert param2.requires_grad is True

    def test_finetune_model_in_eval_after(self, prism_model, tmp_path):
        """After finetune(), model should be back in eval mode."""
        df = _make_test_df(50, with_split=True)
        data_path = tmp_path / "data.parquet"
        df.to_parquet(data_path)

        with patch("prism.io_utils.SFTDataModule") as mock_dm_cls, \
             patch("prism.api.pl.Trainer") as mock_trainer_cls:
            mock_dm_cls.return_value = MagicMock()
            mock_trainer = MagicMock()
            mock_ckpt_callback = MagicMock()
            mock_ckpt_callback.best_model_path = str(tmp_path / "best.ckpt")
            mock_trainer.checkpoint_callback = mock_ckpt_callback
            mock_trainer_cls.return_value = mock_trainer

            with patch.object(prism_model, "_reload_best_checkpoint"):
                prism_model.finetune(
                    data_path=str(data_path),
                    output_dir=str(tmp_path / "output"),
                    max_steps=10,
                )

            # model.eval() should have been called after training
            prism_model.model.eval.assert_called()

    def test_finetune_returns_best_path(self, prism_model, tmp_path):
        """finetune() should return the path to the best checkpoint."""
        df = _make_test_df(50, with_split=True)
        data_path = tmp_path / "data.parquet"
        df.to_parquet(data_path)

        expected_path = str(tmp_path / "checkpoints" / "best.ckpt")

        with patch("prism.io_utils.SFTDataModule") as mock_dm_cls, \
             patch("prism.api.pl.Trainer") as mock_trainer_cls:
            mock_dm_cls.return_value = MagicMock()
            mock_trainer = MagicMock()
            mock_ckpt_callback = MagicMock()
            mock_ckpt_callback.best_model_path = expected_path
            mock_trainer.checkpoint_callback = mock_ckpt_callback
            mock_trainer_cls.return_value = mock_trainer

            with patch.object(prism_model, "_reload_best_checkpoint"):
                result = prism_model.finetune(
                    data_path=str(data_path),
                    output_dir=str(tmp_path / "output"),
                    max_steps=10,
                )

            assert result == expected_path
