"""Tests for v35.1 features: ngl_aa_loss_weight, 4-rate masking, AA→NGL head copy,
detach_heads_from_final_loss.
"""

import numpy as np
import pytest
import torch
import torch.nn as nn
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Test 1: ngl_aa_loss_weight parameter in SFT_ESM2
# ---------------------------------------------------------------------------

class TestNglAaLossWeight:
    """Test that ngl_aa_loss_weight is accepted, stored, and defaults correctly."""

    def test_default_ngl_aa_loss_weight_equals_aa_loss_weight(self):
        """When ngl_aa_loss_weight is not provided, it should default to aa_loss_weight."""
        from prism.model import SFT_ESM2

        # We won't instantiate the full model (heavy). Instead, verify the parameter
        # is accepted in the signature and the default logic works.
        import inspect
        sig = inspect.signature(SFT_ESM2.__init__)
        assert 'ngl_aa_loss_weight' in sig.parameters, \
            "SFT_ESM2.__init__ should accept ngl_aa_loss_weight parameter"
        # Default should be None (which means "use aa_loss_weight")
        assert sig.parameters['ngl_aa_loss_weight'].default is None, \
            "ngl_aa_loss_weight default should be None"

    def test_ngl_aa_loss_weight_stored_on_model(self):
        """When ngl_aa_loss_weight is provided, it should be stored as self.ngl_aa_loss_weight."""
        from prism.model import SFT_ESM2
        import inspect
        sig = inspect.signature(SFT_ESM2.__init__)
        # Verify parameter exists
        assert 'ngl_aa_loss_weight' in sig.parameters

    def test_training_step_uses_ngl_aa_loss_weight(self):
        """The _training_step_multihead should use self.ngl_aa_loss_weight for NGL AA loss."""
        from prism.model import SFT_ESM2
        import inspect
        source = inspect.getsource(SFT_ESM2._training_step_multihead)
        # The training step should reference ngl_aa_loss_weight for the NGL AA head loss
        assert 'ngl_aa_loss_weight' in source, \
            "_training_step_multihead should use self.ngl_aa_loss_weight for NGL AA head loss"


# ---------------------------------------------------------------------------
# Test 2: Combined 4-rate masking in make_collate_fn_multihead
# ---------------------------------------------------------------------------

class TestCombined4RateMasking:
    """Test the combined 4-rate region+NGL masking (CDR-NGL, FR-NGL, CDR-GL, FR-GL)."""

    def test_collate_fn_accepts_4rate_params(self):
        """make_collate_fn_multihead should accept cdr_ngl_mask_prob and fr_ngl_mask_prob."""
        from prism.io_utils import make_collate_fn_multihead
        import inspect
        sig = inspect.signature(make_collate_fn_multihead)
        assert 'cdr_ngl_mask_prob' in sig.parameters, \
            "make_collate_fn_multihead should accept cdr_ngl_mask_prob"
        assert 'fr_ngl_mask_prob' in sig.parameters, \
            "make_collate_fn_multihead should accept fr_ngl_mask_prob"

    def test_4rate_masking_applies_different_rates(self):
        """When both region_masking and ngl_targeted_masking are on with 4-rate params,
        CDR-NGL, FR-NGL, CDR-GL, FR-GL positions should get different mask probabilities."""
        from prism.io_utils import make_collate_fn_multihead

        # Create a mock tokenizer
        tok = _make_test_tokenizer()

        # Create collate function with 4-rate masking
        collate_fn = make_collate_fn_multihead(
            tok, mask_prob=0.15,
            ngl_targeted_masking=True, ngl_mask_prob=0.8,
            use_region_embedding=True,
            use_region_masking=True,
            cdr_mask_prob=0.35, fr_mask_prob=0.15,
            cdr_ngl_mask_prob=0.50, fr_ngl_mask_prob=0.40,
            silent=True,
        )

        # Create test batch with known region and NGL patterns
        # 10 tokens: [CLS] F R 1 C D R 1 f r [PAD]
        # Region IDs: 0=FR, 1=CDR, etc.
        # NGL mask: lowercase = NGL
        batch = _make_4rate_test_batch(tok)

        # Run collate many times and check masking rates
        n_trials = 2000
        cdr_ngl_masked = 0
        cdr_ngl_total = 0
        fr_ngl_masked = 0
        fr_ngl_total = 0
        cdr_gl_masked = 0
        cdr_gl_total = 0
        fr_gl_masked = 0
        fr_gl_total = 0

        for _ in range(n_trials):
            result = collate_fn(batch)
            labels_aa = result[1]  # labels_aa
            ngl_masks = result[4]  # ngl_masks_tensor

            # Check which positions are masked (labels_aa != -100)
            masked = (labels_aa != -100)

            # region_ids from our test batch
            region_ids = result[-1] if len(result) > 5 else None
            if region_ids is None:
                pytest.skip("region_ids not returned from collate")

            # CDR positions (region_id in {1, 3, 5})
            is_cdr = (region_ids == 1) | (region_ids == 3) | (region_ids == 5)
            # FR positions (region_id in {0, 2, 4, 6})
            is_fr = (region_ids == 0) | (region_ids == 2) | (region_ids == 4) | (region_ids == 6)

            # NGL positions
            is_ngl = ngl_masks

            # Count
            cdr_ngl_masked += (masked & is_cdr & is_ngl).sum().item()
            cdr_ngl_total += (is_cdr & is_ngl).sum().item()
            fr_ngl_masked += (masked & is_fr & is_ngl).sum().item()
            fr_ngl_total += (is_fr & is_ngl).sum().item()
            cdr_gl_masked += (masked & is_cdr & ~is_ngl).sum().item()
            cdr_gl_total += (is_cdr & ~is_ngl).sum().item()
            fr_gl_masked += (masked & is_fr & ~is_ngl).sum().item()
            fr_gl_total += (is_fr & ~is_ngl).sum().item()

        # Check rates are approximately correct (with tolerance)
        if cdr_ngl_total > 0:
            rate = cdr_ngl_masked / cdr_ngl_total
            assert abs(rate - 0.50) < 0.05, f"CDR-NGL mask rate {rate:.3f}, expected ~0.50"
        if fr_ngl_total > 0:
            rate = fr_ngl_masked / fr_ngl_total
            assert abs(rate - 0.40) < 0.05, f"FR-NGL mask rate {rate:.3f}, expected ~0.40"
        if cdr_gl_total > 0:
            rate = cdr_gl_masked / cdr_gl_total
            assert abs(rate - 0.35) < 0.05, f"CDR-GL mask rate {rate:.3f}, expected ~0.35"
        if fr_gl_total > 0:
            rate = fr_gl_masked / fr_gl_total
            assert abs(rate - 0.15) < 0.05, f"FR-GL mask rate {rate:.3f}, expected ~0.15"

    def test_lazy_sharded_datamodule_accepts_4rate_params(self):
        """LazyShardedDataModule should accept cdr_ngl_mask_prob and fr_ngl_mask_prob."""
        from prism.io_utils import LazyShardedDataModule
        import inspect
        sig = inspect.signature(LazyShardedDataModule.__init__)
        assert 'cdr_ngl_mask_prob' in sig.parameters
        assert 'fr_ngl_mask_prob' in sig.parameters

    def test_sft_datamodule_accepts_4rate_params(self):
        """SFTDataModule should accept cdr_ngl_mask_prob and fr_ngl_mask_prob."""
        from prism.io_utils import SFTDataModule
        import inspect
        sig = inspect.signature(SFTDataModule.__init__)
        assert 'cdr_ngl_mask_prob' in sig.parameters
        assert 'fr_ngl_mask_prob' in sig.parameters


# ---------------------------------------------------------------------------
# Test 3: AA Head → NGL Head Copy logic
# ---------------------------------------------------------------------------

class TestAAHeadCopy:
    """Test the AA head to NGL head weight copy logic."""

    def test_copy_aa_head_to_ngl_copies_weights(self):
        """After copy, NGL head weights should exactly match AA head weights."""
        # Simulate model with dual heads
        model = MagicMock()
        model.use_dual_aa_heads = True
        H = 480
        V = 53

        # Create real tensors for the heads
        model.aa_head_dense = nn.Linear(H, H)
        model.aa_head_layer_norm = nn.LayerNorm(H)
        model.aa_head_decoder = nn.Linear(H, V, bias=False)
        model.aa_head_bias = nn.Parameter(torch.randn(V))

        model.ngl_aa_head_dense = nn.Linear(H, H)
        model.ngl_aa_head_layer_norm = nn.LayerNorm(H)
        model.ngl_aa_head_decoder = nn.Linear(H, V, bias=False)
        model.ngl_aa_head_bias = nn.Parameter(torch.randn(V))

        # Verify they start different
        assert not torch.equal(model.aa_head_dense.weight, model.ngl_aa_head_dense.weight)

        # Execute the copy logic (same as in train_esm.py)
        with torch.no_grad():
            model.ngl_aa_head_dense.weight.copy_(model.aa_head_dense.weight)
            model.ngl_aa_head_dense.bias.copy_(model.aa_head_dense.bias)
            model.ngl_aa_head_layer_norm.weight.copy_(model.aa_head_layer_norm.weight)
            model.ngl_aa_head_layer_norm.bias.copy_(model.aa_head_layer_norm.bias)
            model.ngl_aa_head_decoder.weight.copy_(model.aa_head_decoder.weight)
            model.ngl_aa_head_bias.copy_(model.aa_head_bias)

        # Verify all weights match
        assert torch.equal(model.aa_head_dense.weight, model.ngl_aa_head_dense.weight)
        assert torch.equal(model.aa_head_dense.bias, model.ngl_aa_head_dense.bias)
        assert torch.equal(model.aa_head_layer_norm.weight, model.ngl_aa_head_layer_norm.weight)
        assert torch.equal(model.aa_head_layer_norm.bias, model.ngl_aa_head_layer_norm.bias)
        assert torch.equal(model.aa_head_decoder.weight, model.ngl_aa_head_decoder.weight)
        assert torch.equal(model.aa_head_bias, model.ngl_aa_head_bias)


# ---------------------------------------------------------------------------
# Test 4: detach_heads_from_final_loss
# ---------------------------------------------------------------------------

class TestDetachHeadsFromFinalLoss:
    """Test that detach_heads_from_final_loss parameter exists and is used."""

    def test_parameter_exists_in_init(self):
        """SFT_ESM2 should accept detach_heads_from_final_loss parameter."""
        from prism.model import SFT_ESM2
        import inspect
        sig = inspect.signature(SFT_ESM2.__init__)
        assert 'detach_heads_from_final_loss' in sig.parameters, \
            "SFT_ESM2.__init__ should accept detach_heads_from_final_loss"
        # Default should be False for backward compatibility
        assert sig.parameters['detach_heads_from_final_loss'].default is False

    def test_detach_used_in_dual_heads_logit_construction(self):
        """When detach_heads_from_final_loss=True, the dual-head logit construction
        should detach GL and NGL head outputs so loss_final only trains alpha."""
        from prism.model import SFT_ESM2
        import inspect
        source = inspect.getsource(SFT_ESM2._construct_53_vocab_logits_dual_heads)
        assert 'detach_heads_from_final_loss' in source or 'detach()' in source, \
            "_construct_53_vocab_logits_dual_heads should support detaching head outputs"

    def test_detach_prevents_gradient_flow_to_heads(self):
        """When detached, gradient from final loss should NOT flow to head parameters."""
        logits_gl = torch.randn(2, 5, 33, requires_grad=True)
        logits_ngl = torch.randn(2, 5, 33, requires_grad=True)
        alpha = torch.randn(2, 5, 1, requires_grad=True)  # leaf tensor

        # With detach: gradient should NOT flow to logits_gl or logits_ngl
        log_p_gl_detached = torch.log_softmax(logits_gl.detach(), dim=-1)
        log_p_ngl_detached = torch.log_softmax(logits_ngl.detach(), dim=-1)

        combined = torch.sigmoid(alpha) * log_p_gl_detached + (1 - torch.sigmoid(alpha)) * log_p_ngl_detached
        loss = combined.sum()
        loss.backward()

        # Alpha should have gradient (it's the only trainable path)
        assert alpha.grad is not None, "Alpha should receive gradient"
        # Head logits should NOT have gradient (detached)
        assert logits_gl.grad is None, "GL head should NOT receive gradient when detached"
        assert logits_ngl.grad is None, "NGL head should NOT receive gradient when detached"

    def test_no_detach_allows_gradient_flow(self):
        """Without detach, gradient from final loss SHOULD flow to head parameters."""
        logits_gl = torch.randn(2, 5, 33, requires_grad=True)
        logits_ngl = torch.randn(2, 5, 33, requires_grad=True)
        alpha = torch.randn(2, 5, 1, requires_grad=True)  # leaf tensor

        # Without detach: gradient flows to everything
        log_p_gl = torch.log_softmax(logits_gl, dim=-1)
        log_p_ngl = torch.log_softmax(logits_ngl, dim=-1)

        combined = torch.sigmoid(alpha) * log_p_gl + (1 - torch.sigmoid(alpha)) * log_p_ngl
        loss = combined.sum()
        loss.backward()

        assert alpha.grad is not None
        assert logits_gl.grad is not None, "GL head should receive gradient without detach"
        assert logits_ngl.grad is not None, "NGL head should receive gradient without detach"


# ---------------------------------------------------------------------------
# Helpers for creating test data
# ---------------------------------------------------------------------------

def _make_test_tokenizer():
    """Create a minimal real-like tokenizer for testing collate functions."""
    tok = MagicMock()
    tok.cls_token_id = 0
    tok.cls_token = "<cls>"
    tok.pad_token_id = 1
    tok.eos_token_id = 2
    tok.unk_token_id = 3
    tok.mask_token_id = 32
    tok.vocab_size = 53

    AA_ORDER = "ACDEFGHIKLMNPQRSTVWY"
    UPPER_IDS = [5, 23, 13, 9, 18, 6, 21, 12, 15, 4, 20, 17, 14, 16, 10, 8, 11, 7, 22, 19]
    LOWER_IDS = list(range(33, 53))

    _token_to_id = {}
    for i, aa in enumerate(AA_ORDER):
        _token_to_id[aa] = UPPER_IDS[i]
        _token_to_id[aa.lower()] = LOWER_IDS[i]

    tok.convert_tokens_to_ids = lambda t: _token_to_id.get(t, tok.unk_token_id)
    return tok


def _make_4rate_test_batch(tok):
    """Create a test batch with known region and NGL patterns for 4-rate masking tests.

    Creates 4 sequences, each 12 tokens long:
    [CLS] AA AA AA AA AA AA AA AA AA [EOS] [PAD]

    Region pattern per sequence: FR1(0), CDR1(1), FR2(2), CDR2(3), FR3(4), CDR3(5), FR4(6), FR1(0), CDR1(1), CDR2(3)
    NGL pattern: alternating GL and NGL within each region type
    """
    # Each sample: (input_ids, ngl_mask, region_ids) -- matching use_region_embedding format
    # Sequence of 10 residues: uppercase=GL, lowercase=NGL
    # Regions: 0=FR1, 1=CDR1, 2=FR2, 3=CDR2, 4=FR3, 5=CDR3, 6=FR4

    samples = []
    for _ in range(8):  # 8 samples for statistical power
        # 10 AA residues + CLS + EOS = 12 tokens
        # Mix of GL (uppercase) and NGL (lowercase) across regions
        seq_tokens = [
            tok.cls_token_id,    # pos 0: CLS
            5,   # pos 1: A (GL, FR1)
            33,  # pos 2: a (NGL, CDR1)
            23,  # pos 3: C (GL, FR2)
            34,  # pos 4: c (NGL, CDR2)
            13,  # pos 5: D (GL, FR3)
            35,  # pos 6: d (NGL, CDR3)
            9,   # pos 7: E (GL, FR4)
            36,  # pos 8: e (NGL, FR1)
            18,  # pos 9: F (GL, CDR1)
            37,  # pos 10: f (NGL, CDR2)
            tok.eos_token_id,    # pos 11: EOS
        ]

        ngl_mask = np.array([
            False,  # CLS
            False,  # GL
            True,   # NGL
            False,  # GL
            True,   # NGL
            False,  # GL
            True,   # NGL
            False,  # GL
            True,   # NGL
            False,  # GL
            True,   # NGL
            False,  # EOS
        ])

        region_ids = np.array([
            0,  # CLS (special)
            0,  # FR1
            1,  # CDR1
            2,  # FR2
            3,  # CDR2
            4,  # FR3
            5,  # CDR3
            6,  # FR4
            0,  # FR1
            1,  # CDR1
            3,  # CDR2
            0,  # EOS (special)
        ])

        samples.append((
            torch.tensor(seq_tokens, dtype=torch.long),
            ngl_mask,
            region_ids,
        ))

    return samples
