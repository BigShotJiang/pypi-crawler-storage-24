"""Tests for v37 NGL Coherence Masking.

Tests that:
1. make_collate_fn_multihead accepts coherence masking params
2. Coherence mode: GL positions are never masked, only NGL positions masked
3. coherence_flags tensor is appended to batch output
4. Coherence probability controls activation frequency
5. LazyShardedDataModule passes coherence params through
"""

import inspect
import numpy as np
import pytest
import torch


# ---------------------------------------------------------------------------
# Helper: Create a mock tokenizer for testing
# ---------------------------------------------------------------------------

def _make_test_tokenizer():
    """Create a minimal tokenizer mock for testing collate functions."""
    from unittest.mock import MagicMock

    tok = MagicMock()
    tok.pad_token_id = 1
    tok.cls_token_id = 0
    tok.cls_token = "<cls>"
    tok.mask_token_id = 32
    tok.unk_token_id = 3
    tok.vocab_size = 53

    # Standard AAs: IDs 4-23
    uppercase_aa = ['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L',
                    'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y']
    lowercase_aa = [aa.lower() for aa in uppercase_aa]

    token_map = {}
    for i, aa in enumerate(uppercase_aa):
        token_map[aa] = 4 + i
    for i, aa in enumerate(lowercase_aa):
        token_map[aa] = 33 + i

    def convert_tokens_to_ids(token):
        return token_map.get(token, tok.unk_token_id)

    tok.convert_tokens_to_ids = convert_tokens_to_ids
    return tok


# ---------------------------------------------------------------------------
# Test 1: Parameter acceptance
# ---------------------------------------------------------------------------

class TestCoherenceParams:
    """Test that make_collate_fn_multihead accepts coherence masking params."""

    def test_use_coherence_masking_param(self):
        from prism.io_utils import make_collate_fn_multihead
        sig = inspect.signature(make_collate_fn_multihead)
        assert 'use_coherence_masking' in sig.parameters
        assert sig.parameters['use_coherence_masking'].default == False

    def test_coherence_prob_param(self):
        from prism.io_utils import make_collate_fn_multihead
        sig = inspect.signature(make_collate_fn_multihead)
        assert 'coherence_prob' in sig.parameters
        assert sig.parameters['coherence_prob'].default == 0.3

    def test_coherence_ngl_mask_prob_param(self):
        from prism.io_utils import make_collate_fn_multihead
        sig = inspect.signature(make_collate_fn_multihead)
        assert 'coherence_ngl_mask_prob' in sig.parameters
        assert sig.parameters['coherence_ngl_mask_prob'].default == 0.5


# ---------------------------------------------------------------------------
# Test 2: Coherence mode behavior
# ---------------------------------------------------------------------------

class TestCoherenceMasking:
    """Test coherence masking behavior in collate function."""

    def _make_batch(self, n=20, seq_len=30, ngl_frac=0.3):
        """Create a synthetic batch for testing.

        Returns list of (input_ids, ngl_mask) tuples.
        """
        tok = _make_test_tokenizer()
        batch = []
        for _ in range(n):
            # Random AA sequence (IDs 4-23 for GL, 33-52 for NGL)
            ids = torch.randint(4, 24, (seq_len,))  # all uppercase
            ngl_mask = np.zeros(seq_len, dtype=np.int64)
            # Random NGL positions
            ngl_count = int(seq_len * ngl_frac)
            ngl_positions = np.random.choice(seq_len, size=ngl_count, replace=False)
            ngl_mask[ngl_positions] = 1
            # Mark NGL positions with lowercase token IDs
            for pos in ngl_positions:
                ids[pos] = ids[pos].item() + 29  # shift to lowercase range
            batch.append((ids, ngl_mask))
        return batch, tok

    def test_coherence_mode_batch_has_flags(self):
        """When coherence masking is enabled, batch should include coherence_flags."""
        from prism.io_utils import make_collate_fn_multihead
        tok = _make_test_tokenizer()

        collate_fn = make_collate_fn_multihead(
            tok, mask_prob=0.15,
            use_coherence_masking=True,
            coherence_prob=1.0,  # Force coherence mode always
            coherence_ngl_mask_prob=0.5,
            silent=True,
        )

        batch, _ = self._make_batch(n=4, seq_len=20)
        result = collate_fn(batch)

        # Result should have coherence_flags as the last element
        # Base elements: input_ids, labels_aa, labels_mut, attn_mask, ngl_masks = 5
        # + coherence_flags = 6
        assert len(result) >= 6, \
            f"Batch should include coherence_flags, got {len(result)} elements"

    def test_coherence_mode_gl_not_masked(self):
        """In coherence mode (prob=1.0), GL positions should never be masked."""
        from prism.io_utils import make_collate_fn_multihead
        tok = _make_test_tokenizer()

        # Force coherence mode on every batch
        collate_fn = make_collate_fn_multihead(
            tok, mask_prob=0.15,
            use_coherence_masking=True,
            coherence_prob=1.0,
            coherence_ngl_mask_prob=0.8,
            silent=True,
        )

        batch, _ = self._make_batch(n=8, seq_len=30, ngl_frac=0.3)
        result = collate_fn(batch)

        input_ids = result[0]       # [B, L]
        labels_aa = result[1]       # [B, L] — -100 for unmasked
        ngl_masks = result[4]       # [B, L]

        # GL positions (ngl_mask == 0) should not be masked (labels_aa == -100)
        gl_positions = (ngl_masks == 0)
        gl_labels = labels_aa[gl_positions]

        # In coherence mode, GL positions should all be -100 (not masked)
        assert (gl_labels == -100).all(), \
            f"In coherence mode, GL positions should not be masked, but {(gl_labels != -100).sum()} were masked"


# ---------------------------------------------------------------------------
# Test 3: LazyShardedDataModule passes coherence params
# ---------------------------------------------------------------------------

class TestCoherenceInDataModule:
    """Test that LazyShardedDataModule accepts and stores coherence params."""

    def test_lazy_sharded_accepts_coherence_params(self):
        from prism.io_utils import LazyShardedDataModule
        sig = inspect.signature(LazyShardedDataModule.__init__)
        assert 'use_coherence_masking' in sig.parameters
        assert 'coherence_prob' in sig.parameters
        assert 'coherence_ngl_mask_prob' in sig.parameters


# ---------------------------------------------------------------------------
# Test 4: Model unpacks coherence_flags from batch
# ---------------------------------------------------------------------------

class TestCoherenceInModel:
    """Test that model training/validation steps handle coherence_flags."""

    def test_training_step_handles_coherence(self):
        """_training_step_multihead should handle coherence_flags from batch."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._training_step_multihead)
        assert 'coherence_flag' in source.lower() or 'coherence' in source.lower(), \
            "_training_step_multihead should handle coherence flags"

    def test_validation_logs_coherence_ppl(self):
        """_validation_step_multihead should log NGL_Coherence_PPL."""
        from prism.model import SFT_ESM2
        source = inspect.getsource(SFT_ESM2._validation_step_multihead)
        assert 'NGL_Coherence_PPL' in source, \
            "_validation_step_multihead should log NGL_Coherence_PPL"
