#!/usr/bin/env python3
"""
Variant-driven component examples for the SDUI Python package
"""

import json
import subprocess
from sdui_python import get_available_components

def example_button_variants():
    """Demonstrate different button variants"""
    print("=== Button Variants Example ===")
    
    # Get button component info
    components = get_available_components()
    button = next(c for c in components if c['name'] == 'SduiButton')
    
    print("Button variants:")
    if 'variant' in button['props']:
        print(f"  Available variants: {button['props']['variant']['enumValues']}")
    if 'size' in button['props']:
        print(f"  Available sizes: {button['props']['size']['enumValues']}")
    
    # Create buttons with different variants
    button_examples = [
        {
            "type": "SduiButton",
            "props": {
                "text": "Primary Action",
                "variant": "default",
                "size": "lg"
            }
        },
        {
            "type": "SduiButton",
            "props": {
                "text": "Secondary Action",
                "variant": "outline",
                "size": "sm"
            }
        },
        {
            "type": "SduiButton",
            "props": {
                "text": "Danger",
                "variant": "destructive",
                "size": "default"
            }
        },
        {
            "type": "SduiButton",
            "props": {
                "text": "Link",
                "variant": "link",
                "size": "default"
            }
        }
    ]
    
    # Validate each button variant
    for i, button in enumerate(button_examples, 1):
        result = subprocess.run([
            'node', 'bin/component-cli.js', '--validate-structure'
        ], input=json.dumps(button), capture_output=True, text=True)
        validation_result = json.loads(result.stdout)
        print(f"  Button {i}: '{button['props']['text']}' with variant '{button['props']['variant']}' - Valid: {validation_result['isValid']}")
    
    print()

def example_text_variants():
    """Demonstrate different text variants"""
    print("=== Text Variants Example ===")
    
    # Get text component info
    components = get_available_components()
    text = next(c for c in components if c['name'] == 'SduiText')
    
    print("Text variants:")
    if 'variant' in text['props']:
        print(f"  Available variants: {text['props']['variant']['enumValues']}")
    
    # Create text examples with different variants
    text_examples = [
        {
            "type": "SduiText",
            "props": {
                "text": "Main Title",
                "variant": "h1"
            }
        },
        {
            "type": "SduiText",
            "props": {
                "text": "Section Title",
                "variant": "h2"
            }
        },
        {
            "type": "SduiText",
            "props": {
                "text": "Body text paragraph",
                "variant": "p"
            }
        },
        {
            "type": "SduiText",
            "props": {
                "text": "Important quote",
                "variant": "blockquote"
            }
        },
        {
            "type": "SduiText",
            "props": {
                "text": "code snippet",
                "variant": "code"
            }
        }
    ]
    
    # Validate each text variant
    for i, text in enumerate(text_examples, 1):
        result = subprocess.run([
            'node', 'bin/component-cli.js', '--validate-structure'
        ], input=json.dumps(text), capture_output=True, text=True)
        validation_result = json.loads(result.stdout)
        print(f"  Text {i}: '{text['props']['text']}' with variant '{text['props']['variant']}' - Valid: {validation_result['isValid']}")
    
    print()

def example_new_components():
    """Demonstrate new components added in variant-driven system"""
    print("=== New Components Example ===")
    
    # SduiFloatingButton example
    floating_button = {
        "type": "SduiFloatingButton",
        "props": {
            "icon": "plus",
            "variant": "default",
            "size": "lg",
            "floatingVariant": "bottomRight"
        }
    }
    
    # SduiGrid example
    grid_component = {
        "type": "SduiGrid",
        "props": {
            "variant": "default",
            "columnCount": 3,
            "minimumItemWidth": 200
        }
    }
    
    # Validate new components
    new_components = [
        ("SduiFloatingButton", floating_button),
        ("SduiGrid", grid_component)
    ]
    
    for name, component in new_components:
        result = subprocess.run([
            'node', 'bin/component-cli.js', '--validate-structure'
        ], input=json.dumps(component), capture_output=True, text=True)
        validation_result = json.loads(result.stdout)
        print(f"  {name}: {'Valid' if validation_result['isValid'] else 'Invalid'}")
        if not validation_result['isValid']:
            print(f"    Errors: {validation_result['errors']}")
    
    print()

def example_complex_variant_structure():
    """Demonstrate complex component structure with variants"""
    print("=== Complex Variant Structure Example ===")
    
    complex_component = {
        "type": "SduiVStack",
        "props": {
            "spacing": 20
        },
        "children": [
            {
                "type": "SduiText",
                "props": {
                    "text": "Welcome to SDUI",
                    "variant": "h1"
                }
            },
            {
                "type": "SduiHStack",
                "props": {
                    "spacing": 12
                },
                "children": [
                    {
                        "type": "SduiButton",
                        "props": {
                            "text": "Save",
                            "variant": "default",
                            "size": "lg"
                        }
                    },
                    {
                        "type": "SduiButton",
                        "props": {
                            "text": "Cancel",
                            "variant": "outline",
                            "size": "lg"
                        }
                    }
                ]
            },
            {
                "type": "SduiCard",
                "props": {
                    "variant": "elevated"
                },
                "children": [
                    {
                        "type": "SduiText",
                        "props": {
                            "text": "Card content",
                            "variant": "p"
                        }
                    }
                ]
            }
        ]
    }
    
    # Validate complex structure
    result = subprocess.run([
        'node', 'bin/component-cli.js', '--validate-structure'
    ], input=json.dumps(complex_component), capture_output=True, text=True)
    validation_result = json.loads(result.stdout)
    print(f"Complex structure validation: {'Valid' if validation_result['isValid'] else 'Invalid'}")
    if validation_result['isValid']:
        print("  Root component: SduiVStack")
        print("  Children: 3 (SduiText, SduiHStack, SduiCard)")
    else:
        print(f"  Errors: {validation_result['errors']}")
    
    print()

if __name__ == "__main__":
    print("Variant-Driven Component Examples")
    print("=" * 35)
    print()
    
    try:
        example_button_variants()
        example_text_variants()
        example_new_components()
        example_complex_variant_structure()
        
        print("All examples completed successfully!")
    except Exception as e:
        print(f"Example failed with error: {e}")
        print("Make sure Node.js is installed and the package is properly set up.")