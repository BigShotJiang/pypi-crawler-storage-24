#!/usr/bin/env python3
"""
Example usage script for the SDUI Python package
"""

import json
from sdui_python import (
    get_available_components,
    validate_from_source,
    serialize_from_source,
    get_all_common_properties
)

def example_component_operations():
    print("=== Component Operations Example ===")
    
    # Get available components
    components = get_available_components()
    print(f"Available components ({len(components)}):")
    for component in components[:5]:  # Show first 5
        print(f"  - {component}")
    if len(components) > 5:
        print(f"  ... and {len(components) - 5} more")
    print()

def example_component_validation():
    print("=== Component Validation Example ===")
    
    # Validate component structure
    valid_component = """
function MyComponent() {
    return <SduiText text="Hello World" />;
}
"""
    
    result = validate_from_source(valid_component)
    print("Valid component structure validation:")
    print(f"  Is valid: {result['isValid']}")
    print(f"  Errors: {result['errors']}")
    print()
    
    # Test with invalid component
    invalid_component = """
function MyComponent() {
    return <SduiText />;
}
"""
    
    result = validate_from_source(invalid_component)
    print("Invalid component structure validation:")
    print(f"  Is valid: {result['isValid']}")
    print(f"  Errors: {result['errors']}")
    print()

def example_serialization():
    print("=== Serialization Example ===")
    
    # Serialize JSX source code with variant-driven styling
    jsx_code = """
function MyComponent() {
    return (
        <SduiVStack spacing={16}>
            <SduiText text="Welcome" variant="h1" />
            <SduiButton text="Get Started" variant="default" size="lg" />
        </SduiVStack>
    );
}
"""
    
    result = serialize_from_source(jsx_code)
    if result:
        print("Serialized component successfully:")
        print(f"  Type: {result['type']}")
        print(f"  Props: {result['props']}")
        if 'children' in result and result['children']:
            print(f"  Number of children: {len(result['children'])}")
    else:
        print("Failed to serialize component")
    print()

def example_common_properties():
    print("=== Common Properties Example ===")
    
    # Get all common properties (now only 5 in variant-driven system)
    common_properties = get_all_common_properties()
    print(f"Common properties ({len(common_properties)}):")
    for prop_name, prop_info in common_properties.items():
        print(f"  - {prop_name}: {prop_info['description']}")
    print()
    
    # Show variant-driven components
    components = get_available_components()
    print("=== Variant-Driven Components ===")
    
    # Find components with variants
    variant_components = []
    for component in components:
        if 'variant' in str(component['props']):
            variant_components.append(component)
    
    print(f"Components with variants ({len(variant_components)}):")
    for component in variant_components[:5]:  # Show first 5
        print(f"  - {component['name']}")
        if 'variant' in component['props']:
            print(f"    Variant options: {component['props']['variant']['enumValues']}")
        if 'size' in component['props']:
            print(f"    Size options: {component['props']['size']['enumValues']}")
    print()

if __name__ == "__main__":
    print("SDUI Python Package Usage Example")
    print("=" * 35)
    print()
    
    try:
        example_component_operations()
        example_component_validation()
        example_serialization()
        example_common_properties()
        
        print("Example completed successfully!")
    except Exception as e:
        print(f"Example failed with error: {e}")
        print("Make sure Node.js is installed and the package is properly set up.")