"""
SDUI Components Library - Python Package

This package provides Python bindings for the SDUI Components Library,
allowing Python developers to use the same functionality as the TypeScript version.
"""

import subprocess
import json
import os
import sys
from typing import Dict, List, Any, Optional, Union


class SDUIError(Exception):
    """Base exception class for SDUI Python package errors."""
    pass


class InvalidJSONError(SDUIError):
    """Raised when JSON string is invalid."""
    pass


class ValidationError(SDUIError):
    """Raised when component validation fails."""
    
    def __init__(self, message: str, errors: List[str]):
        super().__init__(message)
        self.errors = errors


class SerializationError(SDUIError):
    """Raised when serialization fails."""
    pass

# Define the public API
__all__ = [
    'get_available_components',
    'validate_from_source',
    'serialize_from_source',
    'validate_and_serialize',
    'get_all_common_properties',
    'get_all_themes'
]

# Type aliases for better readability
Component = Dict[str, Any]
ComponentList = List[Component]
ValidationResult = Dict[str, Union[bool, List[str]]]
SerializedResult = Dict[str, Any]
CommonProperties = Dict[str, Any]
CategorizedCommonProperties = Dict[str, Dict[str, Any]]
ThemeDictionary = Dict[str, str]

# Get the directory of this module
_module_dir = os.path.dirname(os.path.abspath(__file__))
# Path to the CLI tools (relative to this module)
_cli_dir = os.path.join(_module_dir, '..', 'bin')

def _run_cli_tool(tool_name: str, args: Optional[List[str]] = None, input_data: Optional[str] = None) -> Dict[str, Any]:
    """
    Run a CLI tool and return the result.
    
    Args:
        tool_name (str): Name of the CLI tool (without .js extension)
        args (list): List of arguments to pass to the tool
        input_data (str): Input data to pass to the tool via stdin
        
    Returns:
        dict: Parsed JSON result from the tool
        
    Raises:
        FileNotFoundError: If the CLI tool file is not found
        subprocess.CalledProcessError: If the CLI tool execution fails
        json.JSONDecodeError: If the CLI tool output is not valid JSON
        Exception: For other errors
    """
    tool_path = os.path.join(_cli_dir, f'{tool_name}.js')
    
    # Check if the tool exists
    if not os.path.exists(tool_path):
        raise FileNotFoundError(f"CLI tool not found: {tool_path}")
    
    # Build command
    cmd = ['node', tool_path]
    if args:
        cmd.extend(args)
    
    # Run the tool
    try:
        result = subprocess.run(
            cmd,
            input=input_data,
            capture_output=True,
            text=True,
            check=True
        )
        return json.loads(result.stdout)
    except subprocess.CalledProcessError as e:
        # Check stderr first for error message (CLI tools typically output errors to stderr)
        if e.stderr:
            raise Exception(f"CLI tool '{tool_name}' failed: {e.stderr}")
        
        # If no stderr, check stdout for potential JSON error
        error_message = None
        try:
            error_data = json.loads(e.stdout)
            if 'error' in error_data:
                error_message = error_data['error']
        except (json.JSONDecodeError, AttributeError):
            pass
        
        if error_message:
            raise Exception(f"CLI tool '{tool_name}' error: {error_message}")
        else:
            raise Exception(f"CLI tool '{tool_name}' failed with return code {e.returncode}")
    except json.JSONDecodeError as e:
        raise Exception(f"Failed to parse CLI tool '{tool_name}' output as JSON: {e}")
    except Exception as e:
        raise Exception(f"Unexpected error running CLI tool '{tool_name}': {str(e)}")

def get_available_components() -> ComponentList:
    """
    Returns a list of available SDUI components.
    
    Returns:
        list: List of component type strings
    """
    return _run_cli_tool('component-cli', ['--available'])

def validate_from_source(source_code: str) -> ValidationResult:
    """
    Validates a component source code string using auto-detection.
    
    Args:
        source_code (str): Component source code string to validate
        
    Returns:
        dict: Validation result with 'isValid' and 'errors' keys
        
    Raises:
        TypeError: If source_code is not a string
        Exception: For other errors
    """
    # Validate input type
    if not isinstance(source_code, str):
        raise TypeError("source_code must be a string")
    
    try:
        return _run_cli_tool('type-check-cli', ['--code-auto'], source_code)
    except Exception as e:
        # Re-raise with additional context
        raise Exception(f"Failed to validate component source code: {str(e)}")

def serialize_from_source(source_code: str) -> Optional[SerializedResult]:
    """
    Serialize JSX source code to ComponentJSON.
    
    Args:
        source_code (str): JSX source code to serialize
        
    Returns:
        dict: Serialized ComponentJSON or None if serialization failed
    """
    # Handle empty or whitespace-only source code
    if not source_code or not source_code.strip():
        return None
        
    try:
        result = _run_cli_tool('serialize-cli', ['--source'], source_code)
        return result if result is not None else None
    except Exception as e:
        # Log the error but return None as per function contract
        # The error will be captured in validate_and_serialize
        return None

def validate_and_serialize(source_code: str) -> ValidationResult:
    """
    Validates a component source code string and then serializes it if valid.
    
    Args:
        source_code (str): Component source code string to validate and serialize
        
    Returns:
        dict: Result with 'isValid', 'errors', and 'serialized' keys
    """
    # Validate input type
    if not isinstance(source_code, str):
        return {
            "isValid": False,
            "errors": ["source_code must be a string"],
            "serialized": None
        }
    
    # Validate the component source code
    try:
        validation_result = validate_from_source(source_code)
        # If validation failed, return the validation result
        if not validation_result["isValid"]:
            return {
                "isValid": False,
                "errors": validation_result["errors"],
                "serialized": None
            }
    except Exception as e:
        return {
            "isValid": False,
            "errors": [f"Failed to validate component: {str(e)}"],
            "serialized": None
        }
    
    # If validation passed, serialize the component
    try:
        # Try to run the CLI tool directly to get detailed error information
        tool_path = os.path.join(_cli_dir, 'serialize-cli.js')
        cmd = ['node', tool_path, '--source']
        
        result = subprocess.run(
            cmd,
            input=source_code,
            capture_output=True,
            text=True,
            check=False  # Don't raise on non-zero exit
        )
        
        if result.returncode == 0:
            # Success - parse the result
            try:
                serialized_result = json.loads(result.stdout)
                return {
                    "isValid": True,
                    "errors": [],
                    "serialized": serialized_result
                }
            except json.JSONDecodeError as e:
                return {
                    "isValid": False,
                    "errors": [f"Failed to parse serialized result as JSON: {str(e)}"],
                    "serialized": None
                }
        else:
            # Failure - try to extract error message
            error_message = None
            try:
                # Try parsing stderr first (where serialize-cli outputs errors)
                error_data = json.loads(result.stderr)
                if 'error' in error_data:
                    error_message = error_data['error']
            except (json.JSONDecodeError, AttributeError):
                pass
            
            if not error_message:
                try:
                    # Try parsing stdout as fallback
                    error_data = json.loads(result.stdout)
                    if 'error' in error_data:
                        error_message = error_data['error']
                except (json.JSONDecodeError, AttributeError):
                    pass
            
            if not error_message:
                # If we couldn't parse JSON, use the raw stderr or stdout
                error_message = result.stderr or result.stdout or f"CLI tool failed with return code {result.returncode}"
            
            return {
                "isValid": False,
                "errors": [f"Serialization failed: {error_message}"],
                "serialized": None
            }
            
    except Exception as e:
        return {
            "isValid": False,
            "errors": [f"Failed to serialize component: {str(e)}"],
            "serialized": None
        }


def get_all_common_properties() -> Dict[str, Any]:
    """
    Returns a dictionary of all common properties that can be applied to any component.
    
    Returns:
        dict: Dictionary of common properties with their information
    """
    return _run_cli_tool('component-cli', ['--common-properties'])

def get_all_themes() -> ThemeDictionary:
    """
    Returns supported themes with metadata.
    
    Returns:
        dict: Mapping of theme key to description
    """
    return _run_cli_tool('component-cli', ['--themes'])
