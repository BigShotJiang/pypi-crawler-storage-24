"""
CLI entry points for SDUI Components Library
"""

import subprocess
import os
import sys
from typing import NoReturn

def _get_cli_tool_path(tool_name: str) -> str:
    """Get the path to a CLI tool."""
    # Get the directory of this module
    module_dir = os.path.dirname(os.path.abspath(__file__))
    # Path to the CLI tools (relative to this module)
    # In development: module_dir/../bin
    # In installation: module_dir/../../bin or module_dir/../bin
    cli_dir_options = [
        os.path.join(module_dir, '..', 'bin'),  # Development mode
        os.path.join(module_dir, '..', '..', 'bin'),  # Installed mode
        os.path.join(module_dir, '..', '..', '..', 'bin')  # Deep installed mode
    ]
    
    for cli_dir in cli_dir_options:
        tool_path = os.path.join(cli_dir, f'{tool_name}.js')
        if os.path.exists(tool_path):
            return tool_path
    
    # If not found in relative paths, try to find in site-packages/bin
    # This is the case when installed via pip
    site_packages_dir = os.path.dirname(module_dir)
    site_bin_dir = os.path.join(site_packages_dir, 'bin')
    tool_path = os.path.join(site_bin_dir, f'{tool_name}.js')
    if os.path.exists(tool_path):
        return tool_path
    
    raise FileNotFoundError(f"CLI tool not found: {tool_name}.js")

def run_component_cli() -> NoReturn:
    """Run the component CLI tool."""
    try:
        tool_path = _get_cli_tool_path('component-cli')
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Run the tool with all arguments passed to this script
    cmd = ['node', tool_path] + sys.argv[1:]
    try:
        result = subprocess.run(cmd)
        sys.exit(result.returncode)
    except FileNotFoundError:
        print("Error: Node.js not found. Please install Node.js to use this tool.", file=sys.stderr)
        sys.exit(1)

def run_serialize_cli() -> NoReturn:
    """Run the serialize CLI tool."""
    try:
        tool_path = _get_cli_tool_path('serialize-cli')
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Run the tool with all arguments passed to this script
    cmd = ['node', tool_path] + sys.argv[1:]
    try:
        result = subprocess.run(cmd)
        sys.exit(result.returncode)
    except FileNotFoundError:
        print("Error: Node.js not found. Please install Node.js to use this tool.", file=sys.stderr)
        sys.exit(1)

def run_type_check_cli() -> NoReturn:
    """Run the type check CLI tool."""
    try:
        tool_path = _get_cli_tool_path('type-check-cli')
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Run the tool with all arguments passed to this script
    cmd = ['node', tool_path] + sys.argv[1:]
    try:
        result = subprocess.run(cmd)
        sys.exit(result.returncode)
    except FileNotFoundError:
        print("Error: Node.js not found. Please install Node.js to use this tool.", file=sys.stderr)
        sys.exit(1)