#!/usr/bin/env python3
"""
Unit tests for the SDUI Python package component registry functionality
"""

import unittest
import json
from sdui_python import (
    get_available_components,
    validate_from_source,
    serialize_from_source,
    validate_and_serialize
)

class TestComponentRegistry(unittest.TestCase):
    
    def test_get_available_components(self):
        """Test that get_available_components returns a list of components with their properties"""
        components = get_available_components()
        self.assertIsInstance(components, list)
        self.assertGreater(len(components), 0)
        
        # Check that each component has the required structure
        for component in components:
            self.assertIn("name", component)
            self.assertIn("props", component)
            
            # Check that props is a dictionary of property info objects
            self.assertIsInstance(component["props"], dict)
            
            # Check for specific components
            if component["name"] == "SduiButton":
                self.assertIn("text", component["props"])
                # Check that each property has type info
                self.assertIn("type", component["props"]["text"])
                # Check for disabled property (it's optional, so just check if it exists)
                # Note: disabled property is in the extends array, not in props directly
            elif component["name"] == "SduiText":
                self.assertIn("text", component["props"])
                # Check that each property has type info
                self.assertIn("type", component["props"]["text"])
                # Check for font property (it's in the extends array, not in props directly)

    def test_validate_from_source(self):
        """Test component structure validation"""
        # Valid component
        valid_component = """
function MyComponent() {
    return <SduiText text="Hello World" />;
}
"""
        result = validate_from_source(valid_component)
        self.assertTrue(result["isValid"])
        self.assertEqual(len(result["errors"]), 0)
        
        # Invalid component (unknown Sdui component)
        invalid_component = """
function MyComponent() {
    return <SduiUnknownComponent />;
}
"""
        result = validate_from_source(invalid_component)
        self.assertFalse(result["isValid"])
        self.assertGreater(len(result["errors"]), 0)

class TestSerialization(unittest.TestCase):
    """Test serialization functionality"""
    
    def test_serialize_from_source_simple(self):
        """Test serialize_from_source with a simple component"""
        source_code = """
function MyComponent() {
    return <SduiText text="Hello World" font="headline" />;
}
"""
        result = serialize_from_source(source_code)
        self.assertIsInstance(result, dict)
        self.assertIn("type", result)
        self.assertEqual(result["type"], "SduiText")
        self.assertIn("props", result)
        self.assertIn("text", result["props"])
        self.assertEqual(result["props"]["text"], "Hello World")
        # Note: font is a common property that is applied via modifiers, not directly in props
    
    def test_serialize_from_source_complex(self):
        """Test serialize_from_source with a complex component"""
        source_code = """
function ComplexComponent() {
    return (
        <SduiVStack spacing={16}>
            <SduiText text="Welcome" font="headline" />
            <SduiHStack spacing={8}>
                <SduiButton text="Save" />
                <SduiButton text="Cancel" />
            </SduiHStack>
        </SduiVStack>
    );
}
"""
        result = serialize_from_source(source_code)
        self.assertIsInstance(result, dict)
        self.assertIn("type", result)
        self.assertEqual(result["type"], "SduiVStack")
        self.assertIn("props", result)
        self.assertIn("spacing", result["props"])
        self.assertEqual(result["props"]["spacing"], 16)
        self.assertIn("children", result)
        self.assertIsInstance(result["children"], list)
        self.assertEqual(len(result["children"]), 2)
        
        # Check first child (SduiText)
        text_child = result["children"][0]
        self.assertEqual(text_child["type"], "SduiText")
        self.assertEqual(text_child["props"]["text"], "Welcome")
        
        # Check second child (SduiHStack)
        hstack_child = result["children"][1]
        self.assertEqual(hstack_child["type"], "SduiHStack")
        self.assertEqual(hstack_child["props"]["spacing"], 8)
        self.assertIn("children", hstack_child)
        self.assertEqual(len(hstack_child["children"]), 2)
        
        # Check buttons in HStack
        button1 = hstack_child["children"][0]
        button2 = hstack_child["children"][1]
        self.assertEqual(button1["type"], "SduiButton")
        self.assertEqual(button1["props"]["text"], "Save")
        self.assertEqual(button2["type"], "SduiButton")
        self.assertEqual(button2["props"]["text"], "Cancel")

class TestValidateAndSerialize(unittest.TestCase):
    """Test validate and serialize functionality"""
    
    def test_validate_and_serialize_valid(self):
        """Test validate_and_serialize with a valid component"""
        component = """
function MyComponent() {
    return <SduiText text="Hello World" />;
}
"""
        result = validate_and_serialize(component)
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)
        self.assertTrue(result["isValid"])
        self.assertIn("errors", result)
        self.assertEqual(len(result["errors"]), 0)
        self.assertIn("serialized", result)
        self.assertIsInstance(result["serialized"], dict)
        self.assertEqual(result["serialized"]["type"], "SduiText")
        self.assertEqual(result["serialized"]["props"]["text"], "Hello World")
    
    def test_validate_and_serialize_invalid(self):
        """Test validate_and_serialize with an invalid component"""
        component = {
            "props": {"text": "Missing type"}
        }
        result = validate_and_serialize(json.dumps(component))
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)
        self.assertFalse(result["isValid"])
        self.assertIn("errors", result)
        self.assertGreater(len(result["errors"]), 0)
        self.assertIn("serialized", result)
        self.assertIsNone(result["serialized"])

if __name__ == "__main__":
    unittest.main()