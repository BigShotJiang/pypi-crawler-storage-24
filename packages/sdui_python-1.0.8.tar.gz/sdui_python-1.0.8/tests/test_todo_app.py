#!/usr/bin/env python3
"""
TodoApp tests for the SDUI Python package
"""

import unittest
import os
from sdui_python import (
    validate_from_source,
    validate_and_serialize
)

class TestTodoApp(unittest.TestCase):
    """Test TodoApp functionality"""
    
    def setUp(self):
        """Set up test fixtures before each test method."""
        # Read the TodoApp source code
        cases_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'cases')
        todo_app_path = os.path.join(cases_dir, 'test.tsx')
        
        with open(todo_app_path, 'r', encoding='utf-8') as f:
            self.todo_app_source = f.read()
    
    def test_validate_todo_app(self):
        """Test that TodoApp validates correctly"""
        result = validate_from_source(self.todo_app_source)
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)
        self.assertIn("errors", result)
        self.assertIn("warnings", result)
        
        # The TodoApp should be valid
        self.assertTrue(result["isValid"], f"TodoApp should be valid. Errors: {result['errors']}")
        self.assertEqual(len(result["errors"]), 0, f"TodoApp should have no errors. Errors: {result['errors']}")
        
        # Print warnings for informational purposes
        if result["warnings"]:
            print(f"Warnings: {result['warnings']}")
    
    def test_validate_and_serialize_todo_app(self):
        """Test that TodoApp validates and serializes correctly"""
        result = validate_and_serialize(self.todo_app_source)
        import json
        # print(json.dumps(result, indent=4))
        print(f"==============Result============: {json.dumps(result, indent=4)}")
       
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)
        self.assertIn("errors", result)
        self.assertIn("serialized", result)
        
        # The TodoApp should be valid
        self.assertTrue(result["isValid"], f"TodoApp should be valid. Errors: {result['errors']}")
        self.assertEqual(len(result["errors"]), 0, f"TodoApp should have no errors. Errors: {result['errors']}")
        
        # Should have serialized output
        self.assertIsNotNone(result["serialized"], "TodoApp should serialize to a component structure")
        self.assertIsInstance(result["serialized"], dict)
        
        # Check that the serialized component has the expected structure
        # The serializer handles SduiStateProvider by returning the inner component
        serialized = result["serialized"]
        self.assertIn("type", serialized)
        # The actual type might be SduiApp rather than SduiStateProvider
        # This is because the serializer looks for the actual app component inside SduiStateProvider
        self.assertIn(serialized["type"], ["SduiApp", "SduiStateProvider"], "TodoApp should serialize to either SduiApp or SduiStateProvider component")
        
        # Print warnings for informational purposes
        warnings = result.get("warnings", [])
        if warnings:
            print(f"Warnings: {warnings}")

    def test_validate_todo_app_with_auto_detection(self):
        """Test that TodoApp validates correctly with auto-detection (equivalent to TypeScript's validateCodeStringWithAutoDetection)"""
        # This test is equivalent to the TypeScript test:
        # it('should validate TodoApp source code with auto-detection', () => {
        #   const result = SduiTypeChecker.validateCodeStringWithAutoDetection(todoAppSourceCode);
        #   expect(result.isValid).toBe(true);
        #   expect(result.errors).toHaveLength(0);
        # });
        
        # In the Python package, validate_from_source already uses auto-detection
        # through the --code-auto flag in the CLI tool
        result = validate_from_source(self.todo_app_source)
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)
        self.assertIn("errors", result)
        
        # The TodoApp should be valid
        self.assertTrue(result["isValid"], f"TodoApp should be valid with auto-detection. Errors: {result['errors']}")
        self.assertEqual(len(result["errors"]), 0, f"TodoApp should have no errors with auto-detection. Errors: {result['errors']}")

if __name__ == "__main__":
    unittest.main()