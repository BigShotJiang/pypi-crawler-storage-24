# SDUI Python Package Tests

This directory contains all the tests for the SDUI Python package.

## Test Files

- `test_component_registry.py` - Tests for component registry functionality including serialization and validation
- `test_functionality.py` - Comprehensive functionality tests including serialization and validation
- `test_common_properties.py` - Tests for common properties functionality
- `test_todo_app.py` - Tests for the TodoApp example
- `test_all.py` - Integration tests that verify all functions work correctly

## Running Tests

To run all tests:

```bash
python -m pytest tests/
```

Or run individual test files:

```bash
python tests/test_component_registry.py
python tests/test_functionality.py
python tests/test_common_properties.py
python tests/test_todo_app.py
python tests/test_all.py
```