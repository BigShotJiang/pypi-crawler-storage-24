import unittest
import json
from sdui_python import serialize_from_source, validate_and_serialize


class TestTemplateExpressionSupport(unittest.TestCase):
    """Test cases for template expression support in Python package"""

    def test_template_expression_extraction_in_serializer(self):
        """Test that template expressions are preserved when serializing components"""
        source_code = '''
        import React from 'react';
        import { SduiButton } from './SduiButton';

        const TestComponent = () => {
          return (
            <SduiButton
              text="Test Button"
              style={{
                backgroundColor: "{{filter === 'all' ? '#007AFF' : '#E5E5EA'}}",
                cornerRadius: 8
              }}
            />
          );
        };

        export default TestComponent;
        '''

        result = serialize_from_source(source_code)
        self.assertIsNotNone(result)
        
        # Check the result directly (it's already a dict)
        self.assertEqual(result.get("type"), "SduiButton")
        self.assertEqual(result["props"]["text"], "Test Button")
        
        # Check that the template expression is preserved in the style
        if "style" in result:
            self.assertIn("backgroundColor", result["style"])
            self.assertEqual(
                result["style"]["backgroundColor"], 
                "{{filter === 'all' ? '#007AFF' : '#E5E5EA'}}"
            )
            self.assertEqual(result["style"]["cornerRadius"], 8)

    def test_template_expression_in_various_props(self):
        """Test template expressions in different component props"""
        source_code = '''
        import React from 'react';
        import { SduiText } from './SduiText';

        const TestComponent = () => {
          return (
            <SduiText
              text="{{user.name ? 'Hello ' + user.name : 'Welcome Guest'}}"
              foregroundColor="{{user.isPremium ? '#FFD700' : '#000000'}}"
              fontSize={20}
            />
          );
        };

        export default TestComponent;
        '''

        result = serialize_from_source(source_code)
        self.assertIsNotNone(result)
        
        self.assertEqual(result.get("type"), "SduiText")
        
        # Check template expressions are preserved
        self.assertEqual(
            result["props"]["text"], 
            "{{user.name ? 'Hello ' + user.name : 'Welcome Guest'}}"
        )
        self.assertEqual(
            result["props"]["foregroundColor"], 
            "{{user.isPremium ? '#FFD700' : '#000000'}}"
        )
        self.assertEqual(result["props"]["fontSize"], 20)

    def test_type_checker_with_template_expressions(self):
        """Test type checking with template expressions"""
        source_code = '''
        function TestComponent() {
          return (
            <SduiButton
              text="Test Button"
              style={{
                backgroundColor: "{{filter === 'all' ? '#007AFF' : '#E5E5EA'}}",
                cornerRadius: 8
              }}
            />
          );
        }
        '''
        
        result = validate_and_serialize(source_code)
        self.assertTrue(result["isValid"])

    def test_type_checker_with_template_expressions_state_refs(self):
        """Test type checking with template expressions containing state references"""
        source_code = '''
        function TestComponent() {
          return (
            <SduiText
              text="{{user.name ? 'Hello ' + user.name : 'Welcome Guest'}}"
              foregroundColor="{{user.isPremium ? '#FFD700' : '#000000'}}"
              fontSize={16}
            />
          );
        }
        '''

        result = validate_and_serialize(source_code)
        self.assertTrue(result["isValid"])

    def test_complex_template_expressions(self):
        """Test complex template expressions in various contexts"""
        source_code = '''
        import React from 'react';
        import { SduiVStack, SduiButton } from '../index';

        const ComplexComponent = () => {
          return (
            <SduiVStack spacing={10}>
              <SduiButton
                text="Active Filter"
                style={{
                  backgroundColor: "{{filter === 'active' ? '#00FF00' : '#CCCCCC'}}",
                  padding: 10
                }}
              />
              <SduiButton
                text="Completed Filter"
                style={{
                  backgroundColor: "{{filter === 'completed' ? '#0000FF' : '#CCCCCC'}}",
                  padding: "{{theme.isLarge ? 20 : 10}}"
                }}
              />
            </SduiVStack>
          );
        };

        export default ComplexComponent;
        '''

        result = serialize_from_source(source_code)
        self.assertIsNotNone(result)
        
        self.assertEqual(result.get("type"), "SduiVStack")
        self.assertTrue("children" in result)
        self.assertEqual(len(result["children"]), 2)

        # Check first button
        first_button = result["children"][0]
        self.assertEqual(first_button["type"], "SduiButton")
        self.assertEqual(first_button["props"]["text"], "Active Filter")
        self.assertIn("style", first_button)
        if "style" in first_button:
            self.assertEqual(
                first_button["style"]["backgroundColor"],
                "{{filter === 'active' ? '#00FF00' : '#CCCCCC'}}"
            )
            self.assertEqual(first_button["style"]["padding"], 10)

        # Check second button
        second_button = result["children"][1]
        self.assertEqual(second_button["type"], "SduiButton")
        self.assertEqual(second_button["props"]["text"], "Completed Filter")
        self.assertIn("style", second_button)
        if "style" in second_button:
            self.assertEqual(
                second_button["style"]["backgroundColor"],
                "{{filter === 'completed' ? '#0000FF' : '#CCCCCC'}}"
            )
            self.assertEqual(
                second_button["style"]["padding"],
                "{{theme.isLarge ? 20 : 10}}"
            )

    def test_template_expressions_with_conditional_rendering(self):
        """Test template expressions in components that might be in conditional rendering contexts"""
        source_code = '''
        import React from 'react';
        import { SduiText, SduiButton } from '../index';

        const ConditionalComponent = () => {
          return (
            <SduiVStack>
              <SduiText
                text="{{user.name ? 'Welcome ' + user.name : 'Welcome Guest'}}"
                foregroundColor="#000000"
              />
              <SduiButton
                text="Submit"
                style={{
                  backgroundColor: "{{isValid ? '#00FF00' : '#FF0000'}}"
                }}
              />
            </SduiVStack>
          );
        };

        export default ConditionalComponent;
        '''

        # This test verifies that the template expressions are preserved
        # when they exist in the source code, even in components that might
        # be used in conditional rendering contexts
        result = serialize_from_source(source_code)
        self.assertIsNotNone(result)

    def test_template_expression_edge_cases(self):
        """Test edge cases for template expressions"""
        # Test with nested template expressions (should be handled by serializer as strings)
        source_code = '''
        import React from 'react';
        import { SduiText } from './SduiText';

        const EdgeCaseComponent = () => {
          return (
            <SduiText
              text="Hello {{user.name}}, you have {{count}} items"
              foregroundColor="{{theme === 'dark' ? '#FFFFFF' : '#000000'}}"
            />
          );
        };

        export default EdgeCaseComponent;
        '''

        result = serialize_from_source(source_code)
        self.assertIsNotNone(result)
        
        self.assertEqual(result.get("type"), "SduiText")
        
        # Verify the template expressions are preserved
        self.assertEqual(
            result["props"]["text"], 
            "Hello {{user.name}}, you have {{count}} items"
        )
        self.assertEqual(
            result["props"]["foregroundColor"], 
            "{{theme === 'dark' ? '#FFFFFF' : '#000000'}}"
        )


if __name__ == '__main__':
    unittest.main()