#!/usr/bin/env python3
"""
Error handling tests for the SDUI Python package
"""

import unittest
import json
from sdui_python import (
    validate_from_source,
    serialize_from_source,
    validate_and_serialize
)

class TestErrorHandling(unittest.TestCase):
    """Test error handling and edge cases"""
    
    def test_invalid_component_names(self):
        """Test validation with invalid component names"""
        invalid_component = """
function TestComponent() {
    return <UnknownComponent text="This should fail" />;
}
"""
        result = validate_from_source(invalid_component)
        self.assertFalse(result["isValid"])
        self.assertGreater(len(result["errors"]), 0)
        self.assertIn("UnknownComponent", str(result["errors"]))
    
    def test_invalid_component_properties(self):
        """Test validation with invalid component properties"""
        invalid_props = """
function TestComponent() {
    return <SduiText invalidProperty="This should fail" />;
}
"""
        result = validate_from_source(invalid_props)
        self.assertFalse(result["isValid"])
        self.assertGreater(len(result["errors"]), 0)
    
    def test_malformed_jsx(self):
        """Test validation with malformed JSX"""
        malformed_jsx = """
function TestComponent() {
    return <SduiText text="Missing closing tag;
}
"""
        result = validate_from_source(malformed_jsx)
        self.assertFalse(result["isValid"])
        self.assertGreater(len(result["errors"]), 0)
    
    def test_empty_source_code(self):
        """Test with empty source code"""
        result = validate_from_source("")
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)
        # Empty source should not be valid
        self.assertFalse(result["isValid"])
    
    def test_whitespace_only_source(self):
        """Test with whitespace-only source code"""
        result = validate_from_source("   \n   \t   ")
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)
        # Whitespace-only should not be valid
        self.assertFalse(result["isValid"])
    
    def test_invalid_json_input(self):
        """Test validate_and_serialize with invalid input types"""
        # Test with non-string input
        result = validate_and_serialize(123)
        self.assertFalse(result["isValid"])
        self.assertGreater(len(result["errors"]), 0)
        
        # Test with None input
        result = validate_and_serialize(None)
        self.assertFalse(result["isValid"])
        self.assertGreater(len(result["errors"]), 0)
        
        # Test with empty dict
        result = validate_and_serialize({})
        self.assertFalse(result["isValid"])
        self.assertGreater(len(result["errors"]), 0)
    
    def test_invalid_function_syntax(self):
        """Test with invalid function syntax"""
        invalid_syntax = """
function TestComponent() {
    return <SduiText text="Missing closing brace
}
"""
        result = validate_from_source(invalid_syntax)
        self.assertFalse(result["isValid"])
        self.assertGreater(len(result["errors"]), 0)
    
    def test_nested_component_validation_errors(self):
        """Test validation errors in nested components"""
        nested_invalid = """
function TestComponent() {
    return (
        <SduiVStack>
            <SduiText text="Valid" />
            <InvalidComponent text="Invalid" />
            <SduiButton text="Valid" />
        </SduiVStack>
    );
}
"""
        result = validate_from_source(nested_invalid)
        self.assertFalse(result["isValid"])
        self.assertGreater(len(result["errors"]), 0)
    
    def test_serialization_with_invalid_source(self):
        """Test serialization with invalid source code"""
        invalid_source = """
function TestComponent() {
    return <SduiText text="Missing closing tag;
}
"""
        result = serialize_from_source(invalid_source)
        # Should return None for invalid source
        self.assertIsNone(result)
    
    def test_serialization_with_unknown_component(self):
        """Test serialization with unknown component"""
        unknown_component = """
function TestComponent() {
    return <UnknownComponent text="Unknown" />;
}
"""
        result = serialize_from_source(unknown_component)
        # Should return None for unknown components
        self.assertIsNone(result)
    
    def test_very_long_source_code(self):
        """Test with very long source code (edge case)"""
        # Create a very long but valid component
        long_props = ", ".join([f'prop{i}: "value{i}"' for i in range(1000)])
        long_component = f"""
function TestComponent() {{
    return <SduiText text="Long component" {long_props} />;
}}
"""
        result = validate_from_source(long_component)
        # Should handle long source gracefully
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)
    
    def test_special_characters_in_properties(self):
        """Test with special characters in property values"""
        special_chars = """
function TestComponent() {
    return (
        <SduiText 
            text="Special chars: ñáéíóú, emoji: 🚀, symbols: ©®™" 
            placeholder="Input: <>&\"'"
        />
    );
}
"""
        result = validate_from_source(special_chars)
        self.assertIsInstance(result, dict)
        # Should handle special characters gracefully
        self.assertIn("isValid", result)
    
    def test_nested_quotes_in_strings(self):
        """Test with nested quotes in string values"""
        nested_quotes = '''
function TestComponent() {
    return (
        <SduiText 
            text='Single "quoted" text' 
            placeholder="Double 'quoted' text"
        />
    );
}
'''
        result = validate_from_source(nested_quotes)
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)
    
    def test_unicode_identifiers(self):
        """Test with Unicode identifiers (should fail)"""
        unicode_component = """
function 测试组件() {
    return <Sdui文本 text="Unicode identifier" />;
}
"""
        result = validate_from_source(unicode_component)
        # Unicode identifiers might not be supported, so this could fail
        self.assertIsInstance(result, dict)
    
    def test_circular_references_simulation(self):
        """Test with components that might create circular references"""
        circular_sim = """
function ComponentA() {
    return <ComponentB text="A refers to B" />;
}

function ComponentB() {
    return <ComponentA text="B refers to A" />;
}

function TestComponent() {
    return <ComponentA />;
}
"""
        result = validate_from_source(circular_sim)
        self.assertIsInstance(result, dict)
        # Should handle this gracefully without hanging
        self.assertIn("isValid", result)
    
    def test_deeply_nested_components(self):
        """Test with deeply nested components"""
        deeply_nested = """
function TestComponent() {
    return (
        <SduiVStack>
            <SduiVStack>
                <SduiVStack>
                    <SduiVStack>
                        <SduiVStack>
                            <SduiVStack>
                                <SduiVStack>
                                    <SduiVStack>
                                        <SduiVStack>
                                            <SduiText text="Deep nesting" />
                                        </SduiVStack>
                                    </SduiVStack>
                                </SduiVStack>
                            </SduiVStack>
                        </SduiVStack>
                    </SduiVStack>
                </SduiVStack>
            </SduiVStack>
        </SduiVStack>
    );
}
"""
        result = validate_from_source(deeply_nested)
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)

if __name__ == "__main__":
    unittest.main()
