#!/usr/bin/env python3
"""
Direct tests for Action type validation and State value validation in the SDUI Python package
by directly calling the TypeScript validation functions through the Python API.
"""

import sys
import json
import subprocess
import os

# Add the sdui_python package to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from sdui_python import (
    get_available_components,
    validate_from_source,
    serialize_from_source,
    validate_and_serialize,
    get_all_common_properties
)

def test_invalid_action_type_direct():
    """Test invalid action type validation by creating ComponentJSON directly"""
    print("Testing invalid action type validation...")
    
    # Create a ComponentJSON structure with invalid action type
    component_json = {
        "type": "SduiButton",
        "props": {
            "text": "Click me"
        },
        "actions": {
            "type": "INVALID_ACTION_TYPE",
            "payload": {
                "updates": [
                    {
                        "key": "count",
                        "value": 1
                    }
                ]
            }
        }
    }
    
    # Since we can't directly call the TypeScript validation function from Python,
    # we'll test the validation through the CLI tools
    try:
        # Get the directory of this module
        module_dir = os.path.dirname(os.path.abspath(__file__))
        # Path to the CLI tools
        cli_dir = os.path.join(module_dir, '..', 'bin')
        tool_path = os.path.join(cli_dir, 'type-check-cli.js')
        
        # Check if the tool exists
        if os.path.exists(tool_path):
            # Run the tool with the component JSON
            cmd = ['node', tool_path, '--component']
            input_data = json.dumps(component_json)
            
            result = subprocess.run(
                cmd,
                input=input_data,
                capture_output=True,
                text=True,
                check=False  # Don't raise exception on non-zero exit code
            )
            
            print(f"Command: {' '.join(cmd)}")
            print(f"Input: {input_data}")
            print(f"Return code: {result.returncode}")
            print(f"Stdout: {result.stdout}")
            print(f"Stderr: {result.stderr}")
            
            # Parse the result
            if result.stdout:
                try:
                    validation_result = json.loads(result.stdout)
                    print(f"Validation result: {validation_result}")
                    
                    # Check if validation failed as expected
                    if not validation_result.get("isValid", True):
                        print("✓ Invalid action type correctly detected")
                        return True
                    else:
                        print("✗ Invalid action type was not detected")
                        return False
                except json.JSONDecodeError:
                    print(f"Failed to parse JSON output: {result.stdout}")
                    return False
            else:
                print("No output from validation tool")
                return False
        else:
            print(f"CLI tool not found: {tool_path}")
            return False
    except Exception as e:
        print(f"Error running validation: {e}")
        return False

def test_null_state_initial_value_direct():
    """Test null state initialValue validation by creating ComponentJSON directly"""
    print("Testing null state initialValue validation...")
    
    # Create a ComponentJSON structure with null initialValue
    component_json = {
        "type": "SduiVStack",
        "props": {},
        "stateContainer": {
            "globalState": [
                {
                    "key": "username",
                    "type": "string",
                    "initialValue": None  # This should be null in JSON
                }
            ]
        }
    }
    
    # Convert None to null for JSON serialization
    import copy
    json_data = copy.deepcopy(component_json)
    # We need to handle the None to null conversion properly
    
    # Since we can't directly call the TypeScript validation function from Python,
    # we'll test the validation through the CLI tools
    try:
        # Get the directory of this module
        module_dir = os.path.dirname(os.path.abspath(__file__))
        # Path to the CLI tools
        cli_dir = os.path.join(module_dir, '..', 'bin')
        tool_path = os.path.join(cli_dir, 'type-check-cli.js')
        
        # Check if the tool exists
        if os.path.exists(tool_path):
            # Run the tool with the component JSON
            cmd = ['node', tool_path, '--component']
            # Properly serialize None as null
            input_data = json.dumps(component_json, separators=(',', ':')).replace('null', 'null')
            # Actually, Python's json.dumps already converts None to null
            input_data = json.dumps(component_json)
            
            result = subprocess.run(
                cmd,
                input=input_data,
                capture_output=True,
                text=True,
                check=False  # Don't raise exception on non-zero exit code
            )
            
            print(f"Command: {' '.join(cmd)}")
            print(f"Input: {input_data}")
            print(f"Return code: {result.returncode}")
            print(f"Stdout: {result.stdout}")
            print(f"Stderr: {result.stderr}")
            
            # Parse the result
            if result.stdout:
                try:
                    validation_result = json.loads(result.stdout)
                    print(f"Validation result: {validation_result}")
                    
                    # Check if validation failed as expected
                    if not validation_result.get("isValid", True):
                        print("✓ Null state initialValue correctly detected")
                        return True
                    else:
                        print("✗ Null state initialValue was not detected")
                        return False
                except json.JSONDecodeError:
                    print(f"Failed to parse JSON output: {result.stdout}")
                    return False
            else:
                print("No output from validation tool")
                return False
        else:
            print(f"CLI tool not found: {tool_path}")
            return False
    except Exception as e:
        print(f"Error running validation: {e}")
        return False

def main():
    """Run direct validation tests"""
    print("Running Direct Validation Tests for Action Type and State Value Validation\n")
    
    tests = [
        test_invalid_action_type_direct,
        test_null_state_initial_value_direct
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"Test failed with exception: {e}")
    
    print(f"\nDirect Validation Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All direct validation tests passed!")
        return 0
    else:
        print("❌ Some direct validation tests failed!")
        return 1

if __name__ == "__main__":
    sys.exit(main())