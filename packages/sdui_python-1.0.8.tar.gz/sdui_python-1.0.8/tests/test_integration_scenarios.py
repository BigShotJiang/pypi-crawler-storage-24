#!/usr/bin/env python3
"""
Integration scenario tests for the SDUI Python package
"""

import unittest
import json
from sdui_python import (
    validate_from_source,
    serialize_from_source,
    validate_and_serialize,
    get_available_components
)

class TestIntegrationScenarios(unittest.TestCase):
    """Test real-world integration scenarios"""
    
    def test_complete_form_scenario(self):
        """Test a complete form scenario with validation and submission"""
        form_code = """
function LoginForm() {
    return (
        <SduiVStack spacing={20} padding={40}>
            <SduiText 
                text="Welcome Back" 
                font="largeTitle" 
                fontWeight="bold" 
                textAlign="center"
            />
            <SduiText 
                text="Please sign in to your account" 
                font="body" 
                foregroundColor="#666666"
                textAlign="center"
            />
            <SduiForm>
                <SduiTextField 
                    text="@state:email" 
                    placeholder="Email Address"
                    keyboardType="email"
                />
                <SduiSecureField 
                    text="@state:password" 
                    placeholder="Password"
                />
                <SduiButton 
                    text="Sign In"
                    style={{
                        backgroundColor: "#007AFF",
                        color: "#FFFFFF",
                        cornerRadius: 8
                    }}
                    actions={{
                        trigger: "onTap",
                        type: "STATE_UPDATE",
                        payload: {
                            updates: [
                                {
                                    key: "isLoading",
                                    value: true,
                                    operation: "set"
                                }
                            ]
                        }
                    }}
                />
            </SduiForm>
        </SduiVStack>
    );
}
"""
        # Test validation
        result = validate_from_source(form_code)
        self.assertTrue(result["isValid"], f"Form should be valid. Errors: {result['errors']}")
        self.assertEqual(len(result["errors"]), 0)
        
        # Test serialization
        serialized = serialize_from_source(form_code)
        self.assertIsNotNone(serialized)
        self.assertEqual(serialized["type"], "SduiVStack")
        self.assertIn("children", serialized)
        
        # Check that form elements are preserved
        form_child = None
        for child in serialized["children"]:
            if child["type"] == "SduiForm":
                form_child = child
                break
        
        self.assertIsNotNone(form_child, "Form component should be present")
        self.assertGreater(len(form_child["children"]), 2, "Form should have input fields")
    
    def test_dashboard_with_navigation(self):
        """Test a dashboard scenario with multiple views and navigation"""
        dashboard_code = """
function Dashboard() {
    return (
        <SduiApp>
            <SduiVStack spacing={0} fillHeight={true}>
                <SduiHStack padding={20} backgroundColor="#f8f9fa">
                    <SduiText 
                        text="Dashboard" 
                        font="largeTitle" 
                        fontWeight="bold"
                    />
                    <SduiHStack fillWidth={true} />
                    <SduiButton 
                        text="Profile"
                        style={{ backgroundColor: "#e9ecef" }}
                    />
                </SduiHStack>
                <SduiScrollView>
                    <SduiVStack padding={20} spacing={20}>
                        <SduiVStack 
                            padding={20} 
                            backgroundColor="#ffffff"
                            style={{ cornerRadius: 12, shadow: "0 2px 8px rgba(0,0,0,0.1)" }}
                        >
                            <SduiText 
                                text="Quick Stats" 
                                font="headline" 
                                fontWeight="semibold"
                            />
                            <SduiHStack spacing={40}>
                                <SduiVStack spacing={8}>
                                    <SduiText 
                                        text="1,234" 
                                        font="title1" 
                                        fontWeight="bold"
                                        foregroundColor="#007AFF"
                                    />
                                    <SduiText 
                                        text="Active Users" 
                                        font="caption1" 
                                        foregroundColor="#666666"
                                    />
                                </SduiVStack>
                                <SduiVStack spacing={8}>
                                    <SduiText 
                                        text="567" 
                                        font="title1" 
                                        fontWeight="bold"
                                        foregroundColor="#28a745"
                                    />
                                    <SduiText 
                                        text="New Signups" 
                                        font="caption1" 
                                        foregroundColor="#666666"
                                    />
                                </SduiVStack>
                            </SduiHStack>
                        </SduiVStack>
                        
                        <SduiVStack 
                            padding={20} 
                            backgroundColor="#ffffff"
                            style={{ cornerRadius: 12 }}
                        >
                            <SduiText 
                                text="Recent Activity" 
                                font="headline" 
                                fontWeight="semibold"
                                marginBottom={16}
                            />
                            <SduiForEach
                                dataSource="@state:activities"
                                itemKey="id"
                                template={{
                                    type: "SduiHStack",
                                    props: {
                                        spacing: 12,
                                        padding: 12,
                                        alignment: "center"
                                    },
                                    children: [
                                        {
                                            type: "SduiIcon",
                                            props: {
                                                name: "clock.fill",
                                                size: "small",
                                                foregroundColor "#666666"
                                            }
                                        },
                                        {
                                            type: "SduiText",
                                            props: {
                                                text: "{{item.description}}",
                                                font: "body"
                                            }
                                        },
                                        {
                                            type: "SduiHStack",
                                            props: { fillWidth: true }
                                        },
                                        {
                                            type: "SduiText",
                                            props: {
                                                text: "{{item.timestamp}}",
                                                font: "caption1",
                                                foregroundColor "#999999"
                                            }
                                        }
                                    ]
                                }}
                            />
                        </SduiVStack>
                    </SduiVStack>
                </SduiScrollView>
            </SduiVStack>
        </SduiApp>
    );
}
"""
        # Test complete validation and serialization
        result = validate_and_serialize(dashboard_code)
        self.assertTrue(result["isValid"], f"Dashboard should be valid. Errors: {result['errors']}")
        self.assertIsNotNone(result["serialized"])
        
        serialized = result["serialized"]
        self.assertEqual(serialized["type"], "SduiApp")
        
        # Check for nested components
        def has_component_type(component, target_type):
            if isinstance(component, dict):
                if component.get("type") == target_type:
                    return True
                if "children" in component and isinstance(component["children"], list):
                    for child in component["children"]:
                        if has_component_type(child, target_type):
                            return True
            return False
        
        self.assertTrue(has_component_type(serialized, "SduiScrollView"))
        self.assertTrue(has_component_type(serialized, "SduiForEach"))
        self.assertTrue(has_component_type(serialized, "SduiIcon"))
    
    def test_e_commerce_product_list(self):
        """Test an e-commerce product listing scenario"""
        product_list_code = """
function ProductList() {
    return (
        <SduiVStack spacing={0} fillHeight={true}>
            <SduiHStack 
                padding={16} 
                backgroundColor="#ffffff"
                style={{ borderBottomWidth: 1, borderBottomColor: "#e0e0e0" }}
            >
                <SduiText 
                    text="Products" 
                    font="largeTitle" 
                    fontWeight="bold"
                />
                <SduiHStack fillWidth={true} />
                <SduiButton 
                    text="Filter"
                    style={{ backgroundColor: "#f0f0f0" }}
                />
            </SduiHStack>
            
            <SduiScrollView>
                <SduiVStack padding={16} spacing={12}>
                    <SduiForEach
                        dataSource="@state:products"
                        itemKey="id"
                        template={{
                            type: "SduiVStack",
                            props: {
                                padding: 16,
                                backgroundColor: "#ffffff",
                                style: { cornerRadius: 8, shadow: "0 1px 3px rgba(0,0,0,0.1)" }
                            },
                            children: [
                                {
                                    type: "SduiHStack",
                                    props: { spacing: 12, fillWidth: true },
                                    children: [
                                        {
                                            type: "SduiImage",
                                            props: {
                                                source: "{{item.imageUrl}}",
                                                frame: { width: 80, height: 80 },
                                                contentMode: "aspectFill"
                                            }
                                        },
                                        {
                                            type: "SduiVStack",
                                            props: { spacing: 4, fillWidth: true },
                                            children: [
                                                {
                                                    type: "SduiText",
                                                    props: {
                                                        text: "{{item.name}}",
                                                        font: "headline"
                                                    }
                                                },
                                                {
                                                    type: "SduiText",
                                                    props: {
                                                        text: "{{item.description}}",
                                                        font: "body",
                                                        foregroundColor: "#666666",
                                                        numberOfLines: 2
                                                    }
                                                },
                                                {
                                                    type: "SduiHStack",
                                                    props: { spacing: 8, alignment: "center" },
                                                    children: [
                                                        {
                                                            type: "SduiText",
                                                            props: {
                                                                text: "${{item.price}}",
                                                                font: "title3",
                                                                fontWeight: "bold",
                                                                foregroundColor: "#007AFF"
                                                            }
                                                        },
                                                        {
                                                            type: "SduiHStack",
                                                            props: { spacing: 4, alignment: "center" },
                                                            children: [
                                                                {
                                                                    type: "SduiIcon",
                                                                    props: {
                                                                        name: "star.fill",
                                                                        size: "small",
                                                                        foregroundColor: "#FFD700"
                                                                    }
                                                                },
                                                                {
                                                                    type: "SduiText",
                                                                    props: {
                                                                        text: "{{item.rating}}",
                                                                        font: "caption1",
                                                                        foregroundColor: "#666666"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            type: "SduiVStack",
                                            props: { spacing: 8, alignment: "trailing" },
                                            children: [
                                                {
                                                    type: "SduiButton",
                                                    props: {
                                                        text: "Add to Cart",
                                                        style: {
                                                            backgroundColor: "#007AFF",
                                                            color: "#ffffff",
                                                            padding: 8
                                                        }
                                                    }
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }}
                    />
                </SduiVStack>
            </SduiScrollView>
        </SduiVStack>
    );
}
"""
        # Test this complex e-commerce scenario
        result = validate_and_serialize(product_list_code)
        self.assertTrue(result["isValid"], f"Product list should be valid. Errors: {result['errors']}")
        self.assertIsNotNone(result["serialized"])
        
        # Verify complex nested structure
        serialized = result["serialized"]
        self.assertIn("children", serialized)
        
        # Count components to ensure proper structure
        component_count = 0
        def count_components(component):
            nonlocal component_count
            if isinstance(component, dict):
                component_count += 1
                if "children" in component and isinstance(component["children"], list):
                    for child in component["children"]:
                        count_components(child)
        
        count_components(serialized)
        self.assertGreater(component_count, 10, "Should have many nested components")
    
    def test_social_media_feed(self):
        """Test a social media feed scenario"""
        social_feed_code = """
function SocialFeed() {
    return (
        <SduiVStack spacing={0} fillHeight={true}>
            <SduiHStack 
                padding={16} 
                backgroundColor="#1a1a1a"
            >
                <SduiText 
                    text="Social Feed" 
                    font="largeTitle" 
                    fontWeight="bold"
                    foregroundColor="#ffffff"
                />
                <SduiHStack fillWidth={true} />
                <SduiButton 
                    text="New Post"
                    style={{ 
                        backgroundColor: "#007AFF",
                        color: "#ffffff"
                    }}
                />
            </SduiHStack>
            
            <SduiScrollView>
                <SduiVStack spacing={16} padding={16}>
                    <SduiForEach
                        dataSource="@state:posts"
                        itemKey="id"
                        template={{
                            type: "SduiVStack",
                            props: {
                                padding: 16,
                                backgroundColor: "#ffffff",
                                style: { cornerRadius: 12 }
                            },
                            children: [
                                {
                                    type: "SduiHStack",
                                    props: { spacing: 12, alignment: "center" },
                                    children: [
                                        {
                                            type: "SduiImage",
                                            props: {
                                                source: "{{item.author.avatarUrl}}",
                                                frame: { width: 40, height: 40 },
                                                contentMode: "aspectFill"
                                            }
                                        },
                                        {
                                            type: "SduiVStack",
                                            props: { spacing: 2, fillWidth: true },
                                            children: [
                                                {
                                                    type: "SduiText",
                                                    props: {
                                                        text: "{{item.author.name}}",
                                                        font: "headline",
                                                        fontWeight: "semibold"
                                                    }
                                                },
                                                {
                                                    type: "SduiText",
                                                    props: {
                                                        text: "{{item.timestamp}}",
                                                        font: "caption1",
                                                        foregroundColor: "#666666"
                                                    }
                                                }
                                            ]
                                        }
                                    ]
                                },
                                {
                                    type: "SduiText",
                                    props: {
                                        text: "{{item.content}}",
                                        font: "body",
                                        marginTop: 12,
                                        marginBottom: 12
                                    }
                                },
                                {
                                    type: "SduiImage",
                                    props: {
                                        source: "{{item.imageUrl}}",
                                        frame: { width: "100%", height: 200 },
                                        contentMode: "aspectFill",
                                        marginBottom: 12
                                    }
                                },
                                {
                                    type: "SduiHStack",
                                    props: { spacing: 24, alignment: "center" },
                                    children: [
                                        {
                                            type: "SduiHStack",
                                            props: { spacing: 4, alignment: "center" },
                                            children: [
                                                {
                                                    type: "SduiIcon",
                                                    props: {
                                                        name: "heart",
                                                        size: "small",
                                                        foregroundColor: "#666666"
                                                    }
                                                },
                                                {
                                                    type: "SduiText",
                                                    props: {
                                                        text: "{{item.likes}}",
                                                        font: "caption1"
                                                    }
                                                }
                                            ]
                                        },
                                        {
                                            type: "SduiHStack",
                                            props: { spacing: 4, alignment: "center" },
                                            children: [
                                                {
                                                    type: "SduiIcon",
                                                    props: {
                                                        name: "message",
                                                        size: "small",
                                                        foregroundColor: "#666666"
                                                    }
                                                },
                                                {
                                                    type: "SduiText",
                                                    props: {
                                                        text: "{{item.comments}}",
                                                        font: "caption1"
                                                    }
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }}
                    />
                </SduiVStack>
            </SduiScrollView>
        </SduiVStack>
    );
}
"""
        result = validate_and_serialize(social_feed_code)
        self.assertTrue(result["isValid"], f"Social feed should be valid. Errors: {result['errors']}")
        self.assertIsNotNone(result["serialized"])
    
    def test_settings_page(self):
        """Test a settings page scenario"""
        settings_code = """
function SettingsPage() {
    return (
        <SduiVStack spacing={0} fillHeight={true}>
            <SduiText 
                text="Settings" 
                font="largeTitle" 
                fontWeight="bold"
                padding={20}
                backgroundColor="#f8f9fa"
            />
            
            <SduiScrollView>
                <SduiVStack spacing={1} backgroundColor="#e9ecef">
                    <SduiVStack 
                        padding={20} 
                        backgroundColor="#ffffff"
                        style={{ borderRadius: 8, margin: 16 }}
                    >
                        <SduiText 
                            text="Account" 
                            font="headline" 
                            fontWeight="semibold"
                            marginBottom={16}
                        />
                        <SduiVStack spacing={12}>
                            <SduiHStack 
                                padding={12} 
                                alignment="center"
                                style={{ borderRadius: 8 }}
                            >
                                <SduiText 
                                    text="Profile Information" 
                                    font="body"
                                    fillWidth={true}
                                />
                                <SduiIcon 
                                    name="chevron.right" 
                                    size="small" 
                                    foregroundColor="#666666"
                                />
                            </SduiHStack>
                            <SduiHStack 
                                padding={12} 
                                alignment="center"
                                style={{ borderRadius: 8 }}
                            >
                                <SduiText 
                                    text="Privacy Settings" 
                                    font="body"
                                    fillWidth={true}
                                />
                                <SduiIcon 
                                    name="chevron.right" 
                                    size="small" 
                                    foregroundColor="#666666"
                                />
                            </SduiHStack>
                        </SduiVStack>
                    </SduiVStack>
                    
                    <SduiVStack 
                        padding={20} 
                        backgroundColor="#ffffff"
                        style={{ borderRadius: 8, margin: 16 }}
                    >
                        <SduiText 
                            text="Preferences" 
                            font="headline" 
                            fontWeight="semibold"
                            marginBottom={16}
                        />
                        <SduiVStack spacing={16}>
                            <SduiHStack alignment="center">
                                <SduiText 
                                    text="Dark Mode" 
                                    font="body"
                                    fillWidth={true}
                                />
                                <SduiToggle 
                                    isOn={false} 
                                    stateKey="darkMode"
                                />
                            </SduiHStack>
                            <SduiHStack alignment="center">
                                <SduiText 
                                    text="Push Notifications" 
                                    font="body"
                                    fillWidth={true}
                                />
                                <SduiToggle 
                                    isOn={true} 
                                    stateKey="notifications"
                                />
                            </SduiHStack>
                        </SduiVStack>
                    </SduiVStack>
                    
                    <SduiVStack 
                        padding={20} 
                        backgroundColor="#ffffff"
                        style={{ borderRadius: 8, margin: 16 }}
                    >
                        <SduiText 
                            text="Support" 
                            font="headline" 
                            fontWeight="semibold"
                            marginBottom={16}
                        />
                        <SduiVStack spacing={12}>
                            <SduiHStack 
                                padding={12} 
                                alignment="center"
                                style={{ borderRadius: 8 }}
                            >
                                <SduiText 
                                    text="Help Center" 
                                    font="body"
                                    fillWidth={true}
                                />
                                <SduiIcon 
                                    name="chevron.right" 
                                    size="small" 
                                    foregroundColor="#666666"
                                />
                            </SduiHStack>
                            <SduiHStack 
                                padding={12} 
                                alignment="center"
                                style={{ borderRadius: 8 }}
                            >
                                <SduiText 
                                    text="Contact Support" 
                                    font="body"
                                    fillWidth={true}
                                />
                                <SduiIcon 
                                    name="chevron.right" 
                                    size="small" 
                                    foregroundColor="#666666"
                                />
                            </SduiHStack>
                            <SduiHStack 
                                padding={12} 
                                alignment="center"
                                style={{ borderRadius: 8 }}
                            >
                                <SduiText 
                                    text="About" 
                                    font="body"
                                    fillWidth={true}
                                />
                                <SduiIcon 
                                    name="chevron.right" 
                                    size="small" 
                                    foregroundColor="#666666"
                                />
                            </SduiHStack>
                        </SduiVStack>
                    </SduiVStack>
                </SduiVStack>
            </SduiScrollView>
        </SduiVStack>
    );
}
"""
        result = validate_and_serialize(settings_code)
        self.assertTrue(result["isValid"], f"Settings page should be valid. Errors: {result['errors']}")
        self.assertIsNotNone(result["serialized"])

if __name__ == "__main__":
    unittest.main()