#!/usr/bin/env python3
"""
SduiToggle component tests for the SDUI Python package
"""

import unittest
import json
from sdui_python import (
    get_available_components,
    serialize_from_source,
    validate_and_serialize
)

class TestSduiToggleComponent(unittest.TestCase):
    """Test SduiToggle component functionality"""
    
    def test_get_available_components_includes_toggle(self):
        """Test that SduiToggle is included in available components"""
        components = get_available_components()
        self.assertIsInstance(components, list)
        self.assertGreater(len(components), 0)
        
        # Find SduiToggle component
        toggle_component = None
        for component in components:
            if component["name"] == "SduiToggle":
                toggle_component = component
                break
        
        self.assertIsNotNone(toggle_component, "SduiToggle should be in available components")
        
        # Check that SduiToggle has the required properties
        self.assertIn("props", toggle_component)
        self.assertIsInstance(toggle_component["props"], dict)
        
        # Check for required properties
        self.assertIn("isOn", toggle_component["props"])
        self.assertIn("type", toggle_component["props"]["isOn"])
        self.assertEqual(toggle_component["props"]["isOn"]["type"], "boolean")
        
        # Check for optional properties
        self.assertIn("label", toggle_component["props"])
        self.assertIn("type", toggle_component["props"]["label"])
        self.assertEqual(toggle_component["props"]["label"]["type"], "string")
        self.assertIn("optional", toggle_component["props"]["label"])
        self.assertTrue(toggle_component["props"]["label"]["optional"])
        
        self.assertIn("onToggle", toggle_component["props"])
        self.assertIn("type", toggle_component["props"]["onToggle"])
        self.assertEqual(toggle_component["props"]["onToggle"]["type"], "Action")
        self.assertIn("optional", toggle_component["props"]["onToggle"])
        self.assertTrue(toggle_component["props"]["onToggle"]["optional"])
        
        self.assertIn("stateKey", toggle_component["props"])
        self.assertIn("type", toggle_component["props"]["stateKey"])
        self.assertEqual(toggle_component["props"]["stateKey"]["type"], "string")
        self.assertIn("optional", toggle_component["props"]["stateKey"])
        self.assertTrue(toggle_component["props"]["stateKey"]["optional"])

    def test_serialize_toggle_with_static_props(self):
        """Test serializing toggle with static props"""
        source_code = """
function TestComponent() {
    return <SduiToggle isOn={true} label="Test Toggle" />;
}
"""
        result = serialize_from_source(source_code)
        self.assertIsInstance(result, dict)
        self.assertIn("type", result)
        self.assertEqual(result["type"], "SduiToggle")
        self.assertIn("props", result)
        self.assertIn("isOn", result["props"])
        self.assertEqual(result["props"]["isOn"], True)
        self.assertIn("label", result["props"])
        self.assertEqual(result["props"]["label"], "Test Toggle")

    def test_serialize_toggle_with_state_key(self):
        """Test serializing toggle with stateKey"""
        source_code = """
function TestComponent() {
    return <SduiToggle isOn={false} label="State Toggle" stateKey="toggleState" />;
}
"""
        result = serialize_from_source(source_code)
        self.assertIsInstance(result, dict)
        self.assertIn("type", result)
        self.assertEqual(result["type"], "SduiToggle")
        self.assertIn("props", result)
        self.assertIn("isOn", result["props"])
        self.assertEqual(result["props"]["isOn"], False)
        self.assertIn("label", result["props"])
        self.assertEqual(result["props"]["label"], "State Toggle")
        self.assertIn("stateKey", result["props"])
        self.assertEqual(result["props"]["stateKey"], "toggleState")

    def test_serialize_toggle_with_on_toggle_action(self):
        """Test serializing toggle with onToggle action"""
        source_code = """
function TestComponent() {
    const onToggleAction = {
        type: 'STATE_UPDATE',
        payload: {
            updates: [
                {
                    key: 'toggleValue',
                    value: true,
                    operation: 'set'
                }
            ]
        }
    };
    
    return <SduiToggle isOn={false} label="Action Toggle" onToggle={onToggleAction} />;
}
"""
        result = validate_and_serialize(source_code)
        print(result)
        self.assertTrue(result["isValid"], f"Component should be valid. Errors: {result['errors']}")
        self.assertEqual(len(result["errors"]), 0, f"Component should have no errors. Errors: {result['errors']}")
        
        serialized = result["serialized"]
        self.assertIsInstance(serialized, dict)
        self.assertIn("type", serialized)
        self.assertEqual(serialized["type"], "SduiToggle")
        self.assertIn("props", serialized)
        self.assertIn("isOn", serialized["props"])
        self.assertEqual(serialized["props"]["isOn"], False)
        self.assertIn("label", serialized["props"])
        self.assertEqual(serialized["props"]["label"], "Action Toggle")
        self.assertIn("onToggle", serialized["props"])
        # Check that onToggle action is preserved in the serialized output
        self.assertIsInstance(serialized["props"]["onToggle"], dict)
        self.assertIn("type", serialized["props"]["onToggle"])
        self.assertEqual(serialized["props"]["onToggle"]["type"], "STATE_UPDATE")

    def test_serialize_toggle_with_style(self):
        """Test serializing toggle with style"""
        source_code = """
function TestComponent() {
    return <SduiToggle isOn={true} label="Styled Toggle" style={{ padding: 20, backgroundColor: '#f0f0f0' }} />;
}
"""
        result = serialize_from_source(source_code)
        self.assertIsInstance(result, dict)
        self.assertIn("type", result)
        self.assertEqual(result["type"], "SduiToggle")
        self.assertIn("props", result)
        self.assertIn("isOn", result["props"])
        self.assertEqual(result["props"]["isOn"], True)
        self.assertIn("label", result["props"])
        self.assertEqual(result["props"]["label"], "Styled Toggle")
        # Style is a common property, not in props directly
        self.assertIn("style", result)
        self.assertIsInstance(result["style"], dict)
        self.assertIn("padding", result["style"])
        self.assertEqual(result["style"]["padding"], 20)
        self.assertIn("backgroundColor", result["style"])
        self.assertEqual(result["style"]["backgroundColor"], "#f0f0f0")

if __name__ == "__main__":
    unittest.main()