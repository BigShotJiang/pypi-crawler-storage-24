#!/usr/bin/env python3
"""
Unit tests for the SDUI Python package common properties functionality
"""

import unittest
from sdui_python import (
    get_all_common_properties
)

class TestCommonProperties(unittest.TestCase):
    """Test common properties functionality"""
    
    def test_get_all_common_properties(self):
        """Test that get_all_common_properties returns a dictionary of common properties"""
        common_properties = get_all_common_properties()
        self.assertIsInstance(common_properties, dict)
        self.assertGreater(len(common_properties), 0)
        
        # Check for some expected common properties
        self.assertIn("padding", common_properties)
        self.assertIn("frame", common_properties)
        self.assertIn("background", common_properties)
        self.assertIn("foregroundColor", common_properties)
        self.assertIn("font", common_properties)
        self.assertIn("fontWeight", common_properties)
        
        # Check that each property has the required structure
        for prop_name, prop_info in common_properties.items():
            self.assertIsInstance(prop_info, dict)
            self.assertIn("type", prop_info)
            self.assertIn("description", prop_info)
            # Optional fields
            if "optional" in prop_info:
                self.assertIsInstance(prop_info["optional"], bool)
            if "defaultValue" in prop_info:
                # defaultValue can be any type
                pass
            if "enumValues" in prop_info:
                self.assertIsInstance(prop_info["enumValues"], list)

if __name__ == "__main__":
    unittest.main()