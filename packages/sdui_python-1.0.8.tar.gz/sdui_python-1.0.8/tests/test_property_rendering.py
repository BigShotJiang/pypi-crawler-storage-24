#!/usr/bin/env python3
"""
Property rendering tests for the SDUI Python package
"""

import unittest
import os
from sdui_python import (
    validate_from_source,
    serialize_from_source,
    validate_and_serialize
)

class TestPropertyRendering(unittest.TestCase):
    """Test property rendering functionality"""
    
    def setUp(self):
        """Set up test fixtures before each test method."""
        # Read the PropertyRenderingTest source code
        cases_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'cases')
        property_rendering_path = os.path.join(cases_dir, 'property-rendering-test.tsx')
        
        with open(property_rendering_path, 'r', encoding='utf-8') as f:
            self.property_rendering_source = f.read()
    
    def test_validate_property_rendering(self):
        """Test that PropertyRenderingTest validates correctly"""
        result = validate_from_source(self.property_rendering_source)
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)
        self.assertIn("errors", result)
        
        # The PropertyRenderingTest should be valid
        self.assertTrue(result["isValid"], f"PropertyRenderingTest should be valid. Errors: {result['errors']}")
        self.assertEqual(len(result["errors"]), 0, f"PropertyRenderingTest should have no errors. Errors: {result['errors']}")
    
    def test_serialize_property_rendering(self):
        """Test that PropertyRenderingTest serializes correctly"""
        result = serialize_from_source(self.property_rendering_source)
        self.assertIsNotNone(result, "PropertyRenderingTest should serialize to a component structure")
        self.assertIsInstance(result, dict)
        
        # Check that the serialized component has the expected structure
        self.assertIn("type", result)
        # The serializer handles SduiStateProvider by returning the inner component
        self.assertIn(result["type"], ["SduiApp", "SduiStateProvider"], "PropertyRenderingTest should serialize to either SduiApp or SduiStateProvider component")
        
        # Check for main VStack
        self.assertIn("children", result)
        self.assertIsInstance(result["children"], list)
        self.assertGreater(len(result["children"]), 0)
        
        # Get the main VStack (first child)
        main_vstack = result["children"][0]
        self.assertEqual(main_vstack["type"], "SduiVStack")
        self.assertIn("props", main_vstack)
        self.assertIn("spacing", main_vstack["props"])
        self.assertEqual(main_vstack["props"]["spacing"], 20)
        self.assertIn("padding", main_vstack["props"])
        self.assertEqual(main_vstack["props"]["padding"], 20)
        
        # Check for children in main VStack
        self.assertIn("children", main_vstack)
        self.assertIsInstance(main_vstack["children"], list)
        self.assertEqual(len(main_vstack["children"]), 7)  # 1 Text, 2 Dividers, 2 VStacks, 1 Button, 1 Text
        
        # Check first text
        first_text = main_vstack["children"][0]
        self.assertEqual(first_text["type"], "SduiText")
        self.assertIn("props", first_text)
        self.assertIn("text", first_text["props"])
        self.assertEqual(first_text["props"]["text"], "Property Rendering Test")
        self.assertIn("fontSize", first_text["props"])
        self.assertEqual(first_text["props"]["fontSize"], 28)
        self.assertIn("fontWeight", first_text["props"])
        self.assertEqual(first_text["props"]["fontWeight"], "bold")
        self.assertIn("foregroundColor", first_text["props"])
        self.assertEqual(first_text["props"]["foregroundColor"], "#007AFF")
        
        # Check first divider
        first_divider = main_vstack["children"][1]
        self.assertEqual(first_divider["type"], "SduiDivider")
        
        # Check first inner VStack
        first_inner_vstack = main_vstack["children"][2]
        self.assertEqual(first_inner_vstack["type"], "SduiVStack")
        self.assertIn("props", first_inner_vstack)
        self.assertIn("spacing", first_inner_vstack["props"])
        self.assertEqual(first_inner_vstack["props"]["spacing"], 12)
        
        # Check children of first inner VStack
        self.assertIn("children", first_inner_vstack)
        self.assertIsInstance(first_inner_vstack["children"], list)
        self.assertEqual(len(first_inner_vstack["children"]), 2)
        
        # Check "Current Theme:" text
        current_theme_text = first_inner_vstack["children"][0]
        self.assertEqual(current_theme_text["type"], "SduiText")
        self.assertIn("props", current_theme_text)
        self.assertIn("text", current_theme_text["props"])
        self.assertEqual(current_theme_text["props"]["text"], "Current Theme:")
        self.assertIn("fontSize", current_theme_text["props"])
        self.assertEqual(current_theme_text["props"]["fontSize"], 16)
        
        # Check dynamic text (the one with ternary expressions)
        dynamic_text = first_inner_vstack["children"][1]
        self.assertEqual(dynamic_text["type"], "SduiText")
        # Note: In the current implementation, ternary expressions may not be fully preserved
        # in the props, so we just check that it's a SduiText component
        
        # Check second divider
        second_divider = main_vstack["children"][3]
        self.assertEqual(second_divider["type"], "SduiDivider")
        
        # Check second inner VStack
        second_inner_vstack = main_vstack["children"][4]
        self.assertEqual(second_inner_vstack["type"], "SduiVStack")
        self.assertIn("props", second_inner_vstack)
        self.assertIn("spacing", second_inner_vstack["props"])
        self.assertEqual(second_inner_vstack["props"]["spacing"], 12)
        
        # Check the SduiButton
        button = main_vstack["children"][5]
        self.assertEqual(button["type"], "SduiButton")
        self.assertIn("props", button)
        self.assertIn("text", button["props"])
        self.assertEqual(button["props"]["text"], "Toggle Theme")
        self.assertIn("foregroundColor", button["props"])
        self.assertEqual(button["props"]["foregroundColor"], "#FFFFFF")
        self.assertIn("cornerRadius", button["props"])
        self.assertEqual(button["props"]["cornerRadius"], 12)
        self.assertIn("padding", button["props"])
        self.assertEqual(button["props"]["padding"], 16)
        
        # Check the button has actions
        self.assertIn("actions", button)
        self.assertIsInstance(button["actions"], dict)
        self.assertIn("type", button["actions"])
        self.assertEqual(button["actions"]["type"], "STATE_UPDATE")
        self.assertIn("payload", button["actions"])
        self.assertIsInstance(button["actions"]["payload"], dict)
        
        # Check last text
        last_text = main_vstack["children"][6]
        self.assertEqual(last_text["type"], "SduiText")
        self.assertIn("props", last_text)
        self.assertIn("text", last_text["props"])
        self.assertEqual(last_text["props"]["text"], "Tap the button to see dynamic property changes")
        self.assertIn("fontSize", last_text["props"])
        self.assertEqual(last_text["props"]["fontSize"], 12)
        self.assertIn("foregroundColor", last_text["props"])
        self.assertEqual(last_text["props"]["foregroundColor"], "#999999")
    
    def test_validate_and_serialize_property_rendering(self):
        """Test that PropertyRenderingTest validates and serializes correctly"""
        result = validate_and_serialize(self.property_rendering_source)
        self.assertIsInstance(result, dict)
        self.assertIn("isValid", result)
        self.assertIn("errors", result)
        self.assertIn("serialized", result)
        
        # The PropertyRenderingTest should be valid
        self.assertTrue(result["isValid"], f"PropertyRenderingTest should be valid. Errors: {result['errors']}")
        self.assertEqual(len(result["errors"]), 0, f"PropertyRenderingTest should have no errors. Errors: {result['errors']}")
        
        # Should have serialized output
        self.assertIsNotNone(result["serialized"], "PropertyRenderingTest should serialize to a component structure")
        self.assertIsInstance(result["serialized"], dict)

if __name__ == "__main__":
    unittest.main()