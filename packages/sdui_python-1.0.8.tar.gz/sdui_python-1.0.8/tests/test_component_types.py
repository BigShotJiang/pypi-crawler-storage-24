#!/usr/bin/env python3
"""
Component types comprehensive tests for the SDUI Python package
"""

import unittest
import json
from sdui_python import (
    get_available_components,
    serialize_from_source,
    validate_and_serialize
)

class TestComponentTypes(unittest.TestCase):
    """Test different component types functionality"""
    
    def test_layout_components(self):
        """Test layout components (VStack, HStack, ZStack)"""
        # Test VStack
        vstack_code = """
function TestVStack() {
    return (
        <SduiVStack spacing={10} alignment="center">
            <SduiText text="Item 1" />
            <SduiText text="Item 2" />
        </SduiVStack>
    );
}
"""
        result = serialize_from_source(vstack_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiVStack")
        self.assertEqual(result["props"]["spacing"], 10)
        self.assertEqual(result["props"]["alignment"], "center")
        self.assertEqual(len(result["children"]), 2)
        
        # Test HStack
        hstack_code = """
function TestHStack() {
    return (
        <SduiHStack spacing={5} fillWidth={true}>
            <SduiButton text="Left" />
            <SduiButton text="Right" />
        </SduiHStack>
    );
}
"""
        result = serialize_from_source(hstack_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiHStack")
        self.assertEqual(result["props"]["spacing"], 5)
        self.assertTrue(result["props"]["fillWidth"])
        self.assertEqual(len(result["children"]), 2)
    
    def test_input_components(self):
        """Test input components (TextField, SecureField, TextEditor)"""
        # Test TextField
        textfield_code = """
function TestTextField() {
    return (
        <SduiTextField
            text="Hello World"
            placeholder="Enter text..."
            keyboardType="default"
        />
    );
}
"""
        result = serialize_from_source(textfield_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiTextField")
        self.assertEqual(result["props"]["text"], "Hello World")
        self.assertEqual(result["props"]["placeholder"], "Enter text...")
        
        # Test SecureField
        securefield_code = """
function TestSecureField() {
    return (
        <SduiSecureField
            text="secret123"
            placeholder="Enter password..."
        />
    );
}
"""
        result = serialize_from_source(securefield_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiSecureField")
        self.assertEqual(result["props"]["text"], "secret123")
        
        # Test TextEditor
        texteditor_code = """
function TestTextEditor() {
    return (
        <SduiTextEditor
            text="Long text content..."
            placeholder="Enter description..."
        />
    );
}
"""
        result = serialize_from_source(texteditor_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiTextEditor")
        self.assertEqual(result["props"]["text"], "Long text content...")
    
    def test_picker_components(self):
        """Test picker components (Picker, DatePicker)"""
        # Test Picker
        picker_code = """
function TestPicker() {
    return (
        <SduiPicker
            selection="option1"
            options={["option1", "option2", "option3"]}
        />
    );
}
"""
        result = serialize_from_source(picker_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiPicker")
        self.assertEqual(result["props"]["selection"], "option1")
        
        # Test DatePicker
        datepicker_code = """
function TestDatePicker() {
    return (
        <SduiDatePicker
            date="2023-12-25"
            mode="date"
        />
    );
}
"""
        result = serialize_from_source(datepicker_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiDatePicker")
        self.assertEqual(result["props"]["date"], "2023-12-25")
    
    def test_media_components(self):
        """Test media components (Image, Camera)"""
        # Test Image
        image_code = """
function TestImage() {
    return (
        <SduiImage
            source="https://example.com/image.jpg"
            contentMode="aspectFill"
            frame={{ width: 200, height: 200 }}
        />
    );
}
"""
        result = serialize_from_source(image_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiImage")
        self.assertEqual(result["props"]["source"], "https://example.com/image.jpg")
        
        # Test Camera
        camera_code = """
function TestCamera() {
    return (
        <SduiCamera
            mode="photo"
            quality="high"
        />
    );
}
"""
        result = serialize_from_source(camera_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiCamera")
        self.assertEqual(result["props"]["mode"], "photo")
    
    def test_list_components(self):
        """Test list components (List, ForEach)"""
        # Test List
        list_code = """
function TestList() {
    return (
        <SduiList>
            <SduiText text="Item 1" />
            <SduiText text="Item 2" />
            <SduiText text="Item 3" />
        </SduiList>
    );
}
"""
        result = serialize_from_source(list_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiList")
        self.assertEqual(len(result["children"]), 3)
        
        # Test ForEach
        foreach_code = """
function TestForEach() {
    return (
        <SduiForEach
            dataSource="[1, 2, 3]"
            itemKey="index"
            template={{
                type: "SduiText",
                props: { text: "Item {{index}}" }
            }}
        />
    );
}
"""
        result = serialize_from_source(foreach_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiForEach")
        self.assertEqual(result["props"]["dataSource"], "[1, 2, 3]")
    
    def test_form_components(self):
        """Test form components (Form, Alert)"""
        # Test Form
        form_code = """
function TestForm() {
    return (
        <SduiForm>
            <SduiTextField text="Username" />
            <SduiSecureField text="Password" />
            <SduiButton text="Submit" />
        </SduiForm>
    );
}
"""
        result = serialize_from_source(form_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiForm")
        self.assertEqual(len(result["children"]), 3)
        
        # Test Alert
        alert_code = """
function TestAlert() {
    return (
        <SduiAlert
            title="Information"
            message="This is an alert message"
            buttons={["OK", "Cancel"]}
        />
    );
}
"""
        result = serialize_from_source(alert_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiAlert")
        self.assertEqual(result["props"]["title"], "Information")
    
    def test_control_components(self):
        """Test control components (Slider, Stepper, Toggle, ProgressView)"""
        # Test Slider
        slider_code = """
function TestSlider() {
    return (
        <SduiSlider
            value={0.5}
            range={[0, 1]}
            step={0.1}
        />
    );
}
"""
        result = serialize_from_source(slider_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiSlider")
        self.assertEqual(result["props"]["value"], 0.5)
        
        # Test Stepper
        stepper_code = """
function TestStepper() {
    return (
        <SduiStepper
            value={5}
            range={[0, 100]}
            step={1}
        />
    );
}
"""
        result = serialize_from_source(stepper_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiStepper")
        self.assertEqual(result["props"]["value"], 5)
        
        # Test ProgressView
        progress_code = """
function TestProgressView() {
    return (
        <SduiProgressView
            progress={0.75}
            style="bar"
        />
    );
}
"""
        result = serialize_from_source(progress_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiProgressView")
        self.assertEqual(result["props"]["progress"], 0.75)
    
    def test_decorative_components(self):
        """Test decorative components (Divider, Icon)"""
        # Test Divider
        divider_code = """
function TestDivider() {
    return (
        <SduiDivider
            color="#E0E0E0"
            thickness={1}
        />
    );
}
"""
        result = serialize_from_source(divider_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiDivider")
        self.assertEqual(result["props"]["color"], "#E0E0E0")
        
        # Test Icon
        icon_code = """
function TestIcon() {
    return (
        <SduiIcon
            name="heart.fill"
            size="large"
            foregroundColor="#FF0000"
        />
    );
}
"""
        result = serialize_from_source(icon_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiIcon")
        self.assertEqual(result["props"]["name"], "heart.fill")
    
    def test_scroll_components(self):
        """Test scroll components (ScrollView)"""
        scrollview_code = """
function TestScrollView() {
    return (
        <SduiScrollView
            axis="vertical"
            showsIndicators={true}
        >
            <SduiText text="Scrollable content" />
        </SduiScrollView>
    );
}
"""
        result = serialize_from_source(scrollview_code)
        self.assertIsNotNone(result)
        self.assertEqual(result["type"], "SduiScrollView")
        self.assertEqual(result["props"]["axis"], "vertical")
        self.assertTrue(result["props"]["showsIndicators"])

if __name__ == "__main__":
    unittest.main()