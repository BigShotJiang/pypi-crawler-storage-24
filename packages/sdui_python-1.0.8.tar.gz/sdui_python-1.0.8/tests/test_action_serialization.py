#!/usr/bin/env python3
"""
Test to verify action array serialization functionality in the sdui_python package.
"""

import sys
import json
from sdui_python import serialize_from_source

def test_single_action_object_serialization():
    """Test serialization of a component with a single action object."""
    print("Testing single action object serialization...")
    
    source_code = """
function TestComponent() {
    return (
      <SduiButton
        text="Click me"
        actions={{
          trigger: 'onTap',
          type: 'NAVIGATION',
          payload: {
            path: '/next'
          }
        }}
      />
    );
}
"""
    
    result = serialize_from_source(source_code)
    print("Single action object result:")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    assert isinstance(result, dict), "Result should be a dictionary"
    assert result["type"] == "SduiButton", "Component type should be SduiButton"
    assert "actions" in result, "Result should have 'actions' key"
    
    # 验证动作是单个对象格式
    actions = result["actions"]
    assert isinstance(actions, dict), "Actions should be a dictionary"
    assert not isinstance(actions, list), "Actions should not be a list"
    assert actions["trigger"] == "onTap", "Action trigger should be 'onTap'"
    assert actions["type"] == "NAVIGATION", "Action type should be 'NAVIGATION'"
    assert actions["payload"]["path"] == "/next", "Action path should be '/next'"
    
    print("✓ Single action object serialization test passed\n")

def test_single_action_in_array_serialization():
    """Test serialization of a component with a single action in array."""
    print("Testing single action in array serialization...")
    
    source_code = """
function TestComponent() {
    return (
      <SduiButton
        text="Click me"
        actions={[{
          trigger: 'onTap',
          type: 'NAVIGATION',
          payload: {
            path: '/next'
          }
        }]}
      />
    );
}
"""
    
    result = serialize_from_source(source_code)
    print("Single action in array result:")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    assert isinstance(result, dict), "Result should be a dictionary"
    assert result["type"] == "SduiButton", "Component type should be SduiButton"
    assert "actions" in result, "Result should have 'actions' key"
    
    # 验证动作是数组格式
    actions = result["actions"]
    assert isinstance(actions, list), "Actions should be a list"
    assert len(actions) == 1, "Actions should contain one element"
    assert actions[0]["trigger"] == "onTap", "Action trigger should be 'onTap'"
    assert actions[0]["type"] == "NAVIGATION", "Action type should be 'NAVIGATION'"
    assert actions[0]["payload"]["path"] == "/next", "Action path should be '/next'"
    
    print("✓ Single action in array serialization test passed\n")

def test_multiple_actions_in_array_serialization():
    """Test serialization of a component with multiple actions in array."""
    print("Testing multiple actions in array serialization...")
    
    source_code = """
function TestComponent() {
    return (
      <SduiButton
        text="Save"
        buttonStyle="bordered"
        disabled={!currentFortune}
        actions={[{
          trigger: 'onTap',
          type: 'STATE_UPDATE',
          payload: {
            updates: [
              { key: 'favorites', value: "${state.favorites.concat([state.currentFortune]).filter((v,i,a)=>v && a.indexOf(v)===i)}", operation: 'set' },
              { key: 'showSavedAlert', value: true, operation: 'set' }
            ]
          }
        },
        {
          trigger: 'onTap',
          type: 'API_CALL',
          payload: {
            endpoint: '/api/favorites/add',
            method: 'POST',
            body: { message: '@state:currentFortune' },
            onSuccess: {
              type: 'STATE_UPDATE',
              payload: {
                updates: [
                  { key: 'toast', value: "Saved to favorites", operation: 'set' }
                ]
              }
            },
            onError: {
              type: 'STATE_UPDATE',
              payload: {
                updates: [
                  { key: 'toast', value: "${apiResult.msg}", operation: 'set' }
                ]
              }
            }
          }
        }]}
      />
    );
}
"""
    
    result = serialize_from_source(source_code)
    print("Multiple actions in array result:")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    assert isinstance(result, dict), "Result should be a dictionary"
    assert result["type"] == "SduiButton", "Component type should be SduiButton"
    assert "actions" in result, "Result should have 'actions' key"
    
    # 验证动作是数组格式
    actions = result["actions"]
    assert isinstance(actions, list), "Actions should be a list"
    assert len(actions) == 2, "Actions should contain two elements"
    
    # 验证第一个动作
    assert actions[0]["trigger"] == "onTap", "First action trigger should be 'onTap'"
    assert actions[0]["type"] == "STATE_UPDATE", "First action type should be 'STATE_UPDATE'"
    assert len(actions[0]["payload"]["updates"]) == 2, "First action should have two updates"
    
    # 验证第二个动作
    assert actions[1]["trigger"] == "onTap", "Second action trigger should be 'onTap'"
    assert actions[1]["type"] == "API_CALL", "Second action type should be 'API_CALL'"
    assert actions[1]["payload"]["endpoint"] == "/api/favorites/add", "Second action endpoint should be '/api/favorites/add'"
    assert actions[1]["payload"]["method"] == "POST", "Second action method should be 'POST'"
    assert "onSuccess" in actions[1]["payload"], "Second action should have onSuccess"
    assert "onError" in actions[1]["payload"], "Second action should have onError"
    
    print("✓ Multiple actions in array serialization test passed\n")

def main():
    """Run all action serialization tests."""
    print("Running SDUI Python Package Action Serialization Tests\n")
    
    try:
        test_single_action_object_serialization()
        test_single_action_in_array_serialization()
        test_multiple_actions_in_array_serialization()
        print("🎉 All action serialization tests passed!")
        return 0
    except Exception as e:
        print(f"❌ Action serialization test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())