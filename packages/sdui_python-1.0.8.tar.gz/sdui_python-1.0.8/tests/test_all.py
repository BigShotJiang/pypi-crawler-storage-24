#!/usr/bin/env python3
"""
Integration tests to verify all functions in the sdui_python package work correctly.
"""

import sys
import json
from sdui_python import (
    get_available_components,
    validate_from_source,
    serialize_from_source,
    validate_and_serialize,
    get_all_common_properties
)

def test_get_available_components():
    """Test the get_available_components function."""
    print("Testing get_available_components...")
    try:
        components = get_available_components()
        print(f"Available components: {components}")
        assert isinstance(components, list), "Components should be a list"
        assert len(components) > 0, "Should have at least one component"
        
        # Check that each component has the required structure
        for component in components:
            assert "name" in component, "Component should have a name"
            assert "props" in component, "Component should have props"
            
            # Check that props is a dictionary of property info objects
            assert isinstance(component["props"], dict), "Props should be a dictionary"
            
            # Check that each property has type info
            for prop_name, prop_info in component["props"].items():
                assert "type" in prop_info, f"Property {prop_name} should have type info"
        
        print("✓ get_available_components test passed\n")
        return True
    except Exception as e:
        print(f"✗ get_available_components test failed: {e}\n")
        return False

def test_validate_from_source():
    """Test the validate_from_source function."""
    print("Testing validate_from_source...")
    try:
        # Test with a valid component
        valid_component = """
function MyComponent() {
    return <SduiText text=\"Hello World\" />;
}
"""
        result = validate_from_source(valid_component)
        assert isinstance(result, dict), "Result should be a dictionary"
        assert "isValid" in result, "Result should have 'isValid' key"
        assert result["isValid"] == True, "Component should be valid"
        assert len(result["errors"]) == 0, "Valid component should have no errors"
        print("✓ validate_from_source test passed\n")
        return True
    except Exception as e:
        print(f"✗ validate_from_source test failed: {e}\n")
        return False

def test_serialize_from_source():
    """Test the serialize_from_source function."""
    print("Testing serialize_from_source...")
    try:
        # Test with a simple component
        source_code = """
function MyComponent() {
    return <SduiText text=\"Hello World\" font=\"headline\" />;
}
"""
        result = serialize_from_source(source_code)
        assert isinstance(result, dict), "Result should be a dictionary"
        assert "type" in result, "Result should have 'type' key"
        assert result["type"] == "SduiText", "Component type should be SduiText"
        assert "props" in result, "Result should have 'props' key"
        assert result["props"]["text"] == "Hello World", "Text prop should be 'Hello World'"
        # Note: font is a common property that is applied via modifiers, not directly in props
        print("✓ serialize_from_source test passed\n")
        return True
    except Exception as e:
        print(f"✗ serialize_from_source test failed: {e}\n")
        return False

def test_validate_and_serialize():
    """Test the validate_and_serialize function."""
    print("Testing validate_and_serialize...")
    
    # Test with a valid component
    valid_component = """
function MyComponent() {
    return <SduiText text=\"Hello World\" />;
}
"""
    result = validate_and_serialize(valid_component)
    assert isinstance(result, dict), "Result should be a dictionary"
    assert "isValid" in result, "Result should have 'isValid' key"
    assert result["isValid"] == True, "Component should be valid"
    assert "errors" in result, "Result should have 'errors' key"
    assert len(result["errors"]) == 0, "Valid component should have no errors"
    assert "serialized" in result, "Result should have 'serialized' key"
    assert isinstance(result["serialized"], dict), "Serialized should be a dictionary"
    assert result["serialized"]["type"] == "SduiText", "Component type should be SduiText"
    assert result["serialized"]["props"]["text"] == "Hello World", "Text prop should be 'Hello World'"
    
    # Test with an invalid component (should return validation errors)
    invalid_component = """
function MyComponent() {
    return <UnknownComponent />;
}
"""
    result = validate_and_serialize(invalid_component)
    assert isinstance(result, dict), "Result should be a dictionary"
    assert "isValid" in result, "Result should have 'isValid' key"
    assert result["isValid"] == False, "Component should be invalid"
    assert "errors" in result, "Result should have 'errors' key"
    assert len(result["errors"]) > 0, "Invalid component should have errors"
    assert "serialized" in result, "Result should have 'serialized' key"
    assert result["serialized"] is None, "Serialized should be None for invalid components"
    print("✓ validate_and_serialize correctly handled invalid component")
    
    # Test with wrong input type (should return type errors)
    result = validate_and_serialize(123)
    assert isinstance(result, dict), "Result should be a dictionary"
    assert "isValid" in result, "Result should have 'isValid' key"
    assert result["isValid"] == False, "Wrong input type should be invalid"
    assert "errors" in result, "Result should have 'errors' key"
    assert len(result["errors"]) > 0, "Wrong input type should have errors"
    assert "serialized" in result, "Result should have 'serialized' key"
    assert result["serialized"] is None, "Serialized should be None for wrong input type"
    print("✓ validate_and_serialize correctly handled wrong input type")
    
    print("✓ validate_and_serialize test passed\n")
    return True

def test_get_all_common_properties():
    """Test the get_all_common_properties function."""
    print("Testing get_all_common_properties...")
    try:
        common_properties = get_all_common_properties()
        assert isinstance(common_properties, dict), "Common properties should be a dictionary"
        assert len(common_properties) > 0, "Should have at least one common property"
        
        # Check for some expected common properties
        assert "padding" in common_properties, "Should have padding property"
        assert "frame" in common_properties, "Should have frame property"
        assert "background" in common_properties, "Should have background property"
        assert "font" in common_properties, "Should have font property"
        assert "fontWeight" in common_properties, "Should have fontWeight property"
        
        # Check that each property has the required structure
        for prop_name, prop_info in common_properties.items():
            assert isinstance(prop_info, dict), f"Property {prop_name} info should be a dictionary"
            assert "type" in prop_info, f"Property {prop_name} should have type info"
            assert "description" in prop_info, f"Property {prop_name} should have description"
            
            # Check enumValues for font properties
            if prop_name == "font" and "enumValues" in prop_info:
                assert isinstance(prop_info["enumValues"], list), "Font enumValues should be a list"
                assert len(prop_info["enumValues"]) > 0, "Font enumValues should not be empty"
                
            if prop_name == "fontWeight" and "enumValues" in prop_info:
                assert isinstance(prop_info["enumValues"], list), "FontWeight enumValues should be a list"
                assert len(prop_info["enumValues"]) > 0, "FontWeight enumValues should not be empty"
        
        print("✓ get_all_common_properties test passed\n")
        return True
    except Exception as e:
        print(f"✗ get_all_common_properties test failed: {e}\n")
        return False

def test_sdui_toggle_serialization():
    """Test SduiToggle component serialization."""
    print("Testing SduiToggle component serialization...")
    try:
        # Test that SduiToggle is in available components
        components = get_available_components()
        toggle_component = None
        for component in components:
            if component["name"] == "SduiToggle":
                toggle_component = component
                break
        
        assert toggle_component is not None, "SduiToggle should be in available components"
        
        # Test serializing a simple toggle component
        source_code = """
function TestComponent() {
    return <SduiToggle isOn={true} label="Test Toggle" />;
}
"""
        result = serialize_from_source(source_code)
        assert isinstance(result, dict), "Result should be a dictionary"
        assert "type" in result, "Result should have 'type' key"
        assert result["type"] == "SduiToggle", "Component type should be SduiToggle"
        assert "props" in result, "Result should have 'props' key"
        assert result["props"]["isOn"] == True, "isOn prop should be True"
        assert result["props"]["label"] == "Test Toggle", "label prop should be 'Test Toggle'"
        
        print("✓ SduiToggle component serialization test passed\n")
        return True
    except Exception as e:
        print(f"✗ SduiToggle component serialization test failed: {e}\n")
        return False

def main():
    """Run all tests."""
    print("Running SDUI Python Package Integration Tests\n")
    
    tests = [
        test_get_available_components,
        test_validate_from_source,
        test_serialize_from_source,
        test_validate_and_serialize,
        test_get_all_common_properties,
        test_sdui_toggle_serialization
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print(f"Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed!")
        return 0
    else:
        print("❌ Some tests failed!")
        return 1

if __name__ == "__main__":
    sys.exit(main())