from pydantic import BaseModel


class Config(BaseModel):
    """Sentry tracing 插件配置。"""

    sentry_nb_trace_enabled: bool = True
