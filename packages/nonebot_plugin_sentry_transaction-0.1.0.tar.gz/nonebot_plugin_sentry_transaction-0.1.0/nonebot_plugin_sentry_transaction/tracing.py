from __future__ import annotations

import contextlib
import sys
from typing import TYPE_CHECKING

import nonebot.message
import sentry_sdk
from nonebot.exception import StopPropagation
from nonebot.message import run_postprocessor
from sentry_sdk.tracing import Span as SentrySpan

if TYPE_CHECKING:
    from contextlib import AsyncExitStack

    from nonebot.adapters import Bot, Event
    from nonebot.matcher import Matcher
    from nonebot.typing import T_DependencyCache, T_State

    from .config import Config


_original_handle_event = nonebot.message.handle_event


async def traced_handle_event(bot: Bot, event: Event) -> None:
    # isolation_scope 为每个事件创建独立的隔离作用域，防止并发事件之间污染 trace 状态。
    with sentry_sdk.isolation_scope() as scope:
        scope.set_tag('adapter', bot.type)
        scope.set_tag('event_type', event.get_type())

        with sentry_sdk.start_transaction(op='nonebot.event', name=event.get_event_name()) as transaction:
            transaction.set_tag('adapter', bot.type)
            transaction.set_tag('event_type', event.get_type())
            await _original_handle_event(bot, event)


def patch_handle_event() -> None:
    nonebot.message.handle_event = traced_handle_event

    # Adapter 在导入时通过 from nonebot.message import handle_event 绑定了本地引用，
    # 仅替换模块属性无法覆盖这些引用，需遍历 sys.modules 逐一替换。
    for module in sys.modules.values():
        if module is nonebot.message:
            continue
        try:
            module_dict = vars(module)
        except TypeError:
            continue
        for attr_name, attr_value in module_dict.items():
            if attr_value is _original_handle_event:
                with contextlib.suppress(AttributeError, TypeError):
                    setattr(module, attr_name, traced_handle_event)


_original_run_matcher = nonebot.message._run_matcher  # noqa: SLF001


async def traced_run_matcher(  # noqa: PLR0913
    Matcher: type[Matcher],  # noqa: N803
    bot: Bot,
    event: Event,
    state: T_State,
    stack: AsyncExitStack | None = None,
    dependency_cache: T_DependencyCache | None = None,
) -> None:
    # new_scope 分叉当前 scope，防止同优先级并发 matcher 互相覆盖 active span。
    with sentry_sdk.new_scope() as scope:
        span_name = Matcher.plugin_name or Matcher.module_name or Matcher.__name__
        scope.set_tag('matcher.plugin', Matcher.plugin_name or 'unknown')
        scope.set_tag('matcher.module', Matcher.module_name or 'unknown')

        # 在 span 内部捕获 StopPropagation，确保 span 以 ok 状态正常结束，
        # 随后重新抛出以保持 NoneBot 的事件传播语义。
        stop_propagation = False
        with sentry_sdk.start_span(op='nonebot.matcher', name=span_name):
            try:
                await _original_run_matcher(Matcher, bot, event, state, stack, dependency_cache)
            except StopPropagation:
                stop_propagation = True

    if stop_propagation:
        raise StopPropagation


def patch_run_matcher() -> None:
    # check_and_run_matcher 通过模块全局名调用 _run_matcher（运行时解析），
    # 因此只需替换模块属性，无需扫描 sys.modules。
    nonebot.message._run_matcher = traced_run_matcher  # noqa: SLF001


async def _on_matcher_done(exception: Exception | None = None) -> None:
    """检测 matcher 内部异常并将 span 标记为错误。

    _run_matcher 会捕获 matcher 异常但不重新抛出，导致 span 的 __exit__
    无法感知异常。此 hook 通过 exception 参数补充设置 span 状态。
    """
    span = sentry_sdk.get_current_span()
    if isinstance(span, SentrySpan) and exception is not None:
        span.set_status('internal_error')


def setup_tracing(config: Config) -> None:
    """在插件加载时安装 tracing patch。"""
    if not config.sentry_nb_trace_enabled or not sentry_sdk.is_initialized():
        return
    patch_handle_event()
    patch_run_matcher()
    run_postprocessor(_on_matcher_done)
