from nonebot import get_plugin_config, require
from nonebot.plugin import PluginMetadata

require('nonebot_plugin_sentry')

from .config import Config  # noqa: E402
from .tracing import setup_tracing  # noqa: E402

__plugin_meta__ = PluginMetadata(
    name='nonebot-plugin-sentry-transaction',
    description='NoneBot Event 与 Matcher 的非侵入式 Sentry tracing',
    usage='配置 nonebot-plugin-sentry 完成 Sentry 初始化。设置 SENTRY_NB_TRACE_ENABLED=false 可关闭 tracing。',
    type='library',
    config=Config,
    supported_adapters=None,
)

config = get_plugin_config(Config)
setup_tracing(config)
