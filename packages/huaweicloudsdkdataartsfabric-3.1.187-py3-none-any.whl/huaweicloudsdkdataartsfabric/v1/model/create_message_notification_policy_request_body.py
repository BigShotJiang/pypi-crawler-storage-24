# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateMessageNotificationPolicyRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'message_notification_policy_list': 'list[CreateMessageNotificationPolicy]'
    }

    attribute_map = {
        'message_notification_policy_list': 'message_notification_policy_list'
    }

    def __init__(self, message_notification_policy_list=None):
        r"""CreateMessageNotificationPolicyRequestBody

        The model defined in huaweicloud sdk

        :param message_notification_policy_list: 消息通知策略
        :type message_notification_policy_list: list[:class:`huaweicloudsdkdataartsfabric.v1.CreateMessageNotificationPolicy`]
        """
        
        

        self._message_notification_policy_list = None
        self.discriminator = None

        self.message_notification_policy_list = message_notification_policy_list

    @property
    def message_notification_policy_list(self):
        r"""Gets the message_notification_policy_list of this CreateMessageNotificationPolicyRequestBody.

        消息通知策略

        :return: The message_notification_policy_list of this CreateMessageNotificationPolicyRequestBody.
        :rtype: list[:class:`huaweicloudsdkdataartsfabric.v1.CreateMessageNotificationPolicy`]
        """
        return self._message_notification_policy_list

    @message_notification_policy_list.setter
    def message_notification_policy_list(self, message_notification_policy_list):
        r"""Sets the message_notification_policy_list of this CreateMessageNotificationPolicyRequestBody.

        消息通知策略

        :param message_notification_policy_list: The message_notification_policy_list of this CreateMessageNotificationPolicyRequestBody.
        :type message_notification_policy_list: list[:class:`huaweicloudsdkdataartsfabric.v1.CreateMessageNotificationPolicy`]
        """
        self._message_notification_policy_list = message_notification_policy_list

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateMessageNotificationPolicyRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
