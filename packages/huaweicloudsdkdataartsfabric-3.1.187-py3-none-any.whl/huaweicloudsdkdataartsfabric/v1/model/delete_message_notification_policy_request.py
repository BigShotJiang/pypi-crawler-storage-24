# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteMessageNotificationPolicyRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'message_policy_id': 'str',
        'workspace_id': 'str'
    }

    attribute_map = {
        'message_policy_id': 'message_policy_id',
        'workspace_id': 'workspace_id'
    }

    def __init__(self, message_policy_id=None, workspace_id=None):
        r"""DeleteMessageNotificationPolicyRequest

        The model defined in huaweicloud sdk

        :param message_policy_id: 消息通知策略ID
        :type message_policy_id: str
        :param workspace_id: Workspace的ID
        :type workspace_id: str
        """
        
        

        self._message_policy_id = None
        self._workspace_id = None
        self.discriminator = None

        self.message_policy_id = message_policy_id
        self.workspace_id = workspace_id

    @property
    def message_policy_id(self):
        r"""Gets the message_policy_id of this DeleteMessageNotificationPolicyRequest.

        消息通知策略ID

        :return: The message_policy_id of this DeleteMessageNotificationPolicyRequest.
        :rtype: str
        """
        return self._message_policy_id

    @message_policy_id.setter
    def message_policy_id(self, message_policy_id):
        r"""Sets the message_policy_id of this DeleteMessageNotificationPolicyRequest.

        消息通知策略ID

        :param message_policy_id: The message_policy_id of this DeleteMessageNotificationPolicyRequest.
        :type message_policy_id: str
        """
        self._message_policy_id = message_policy_id

    @property
    def workspace_id(self):
        r"""Gets the workspace_id of this DeleteMessageNotificationPolicyRequest.

        Workspace的ID

        :return: The workspace_id of this DeleteMessageNotificationPolicyRequest.
        :rtype: str
        """
        return self._workspace_id

    @workspace_id.setter
    def workspace_id(self, workspace_id):
        r"""Sets the workspace_id of this DeleteMessageNotificationPolicyRequest.

        Workspace的ID

        :param workspace_id: The workspace_id of this DeleteMessageNotificationPolicyRequest.
        :type workspace_id: str
        """
        self._workspace_id = workspace_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteMessageNotificationPolicyRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
