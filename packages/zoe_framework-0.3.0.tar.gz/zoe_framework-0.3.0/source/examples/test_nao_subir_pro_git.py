from zoe import App, Server, Request, Response, HttpCode, Router, Model, Field, NotNull, CookiePair, CookieAttributes, Bytes, Logger, Env, Limiter, Helmet, Hook, Date, DateFormat, ComputedField

import datetime

class UserRegister(Model):
    id: str | None = ComputedField(lambda fields: f"{fields.get('date')}-test-computed")
    date:  datetime.datetime = Field(generator=Date.After(hours=2, minutes=3))

router = Router(prefix="/user")

def ola():
    print("Ola")
    print(Hook.ctx.get("req"))

def ola2():
    print(Hook.ctx.get("legal"))

@router.get("/hello")
@Hook.after(ola)
class Hello:
    async def handle(self, request: Request) -> Response:
        import asyncio
        await asyncio.sleep(0.15)
        Hook.ctx.set("req", request)
        res: Response = Response.json(http_code=HttpCode.OK, body={"Beleza": "sim!"})
        res.headers.cookies.add(CookiePair(name="session", value="24009893"), CookieAttributes(http_only=True))
        return res

@router.post("/test")
@Hook.after(ola2)
def olahandle(req: Request, user: UserRegister) -> Response:
    Hook.ctx.set("legal", "Daora!")
    return Response.json(http_code=HttpCode.OK, body=user)

if __name__ == "__main__":
    zapp = App()
    zserver = Server(application=zapp)
    Env.strict()
    zapp.use(router).use(Logger(verbose=True)).use(Limiter(max_requests=Env.get(key="LIMIT", type_=int, default=1), window_seconds=Env.get("LIMIT_S", type_=int, default=5))).use(Helmet())
    zserver.run()
