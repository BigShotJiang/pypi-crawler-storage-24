"""
Utilidades para Django Dynamic Paginator.
"""

from django.db import models
from typing import Dict, Any, Set, Optional, List
from .exceptions import ModelNotFoundError, InvalidFieldError


def get_model_field_names(model: models.Model) -> Set[str]:
    """
    Obtiene los nombres de campos de un modelo Django.
    
    Args:
        model: Modelo Django del cual obtener los campos
        
    Returns:
        Set de nombres de campos del modelo
        
    Raises:
        ModelNotFoundError: Si el objeto no es un modelo Django válido
    """
    if not hasattr(model, '_meta'):
        raise ModelNotFoundError(f"El objeto {model} no es un modelo Django válido")
    
    return {f.name for f in model._meta.get_fields()}


def build_fk_mapping(model: models.Model) -> Dict[str, str]:
    """
    Construye el mapeo automático de ForeignKeys.
    
    Mapea nombres de campos ForeignKey a sus campos _id correspondientes.
    Ejemplo: 'user' -> 'user_id'
    
    Args:
        model: Modelo Django del cual generar el mapeo
        
    Returns:
        Diccionario con el mapeo {field_name: field_name_id}
        
    Raises:
        ModelNotFoundError: Si el objeto no es un modelo Django válido
    """
    if not hasattr(model, '_meta'):
        raise ModelNotFoundError(f"El objeto {model} no es un modelo Django válido")
    
    fk_mapping = {}
    for field in model._meta.get_fields():
        if (hasattr(field, 'related_model') and 
            hasattr(field, 'many_to_one') and 
            field.many_to_one and 
            not field.one_to_one):
            fk_mapping[field.name] = f"{field.name}_id"
    
    return fk_mapping


def validate_model_fields(model: models.Model, fields: List[str]) -> bool:
    """
    Valida que una lista de campos exista en el modelo.
    
    Args:
        model: Modelo Django a validar
        fields: Lista de nombres de campos a verificar
        
    Returns:
        True si todos los campos son válidos
        
    Raises:
        InvalidFieldError: Si algún campo no existe en el modelo
    """
    if not fields:
        return True
        
    model_fields = get_model_field_names(model)
    invalid_fields = []
    
    for field in fields:
        # Permitir campos relacionados (con __)
        if '__' in field:
            base_field = field.split('__')[0]
            if base_field not in model_fields:
                invalid_fields.append(field)
        elif field not in model_fields:
            invalid_fields.append(field)
    
    if invalid_fields:
        raise InvalidFieldError(
            f"Los campos {invalid_fields} no existen en el modelo {model.__name__}"
        )
    
    return True


def validate_serializer_fields(serializer_class, only_fields: Optional[List[str]] = None) -> bool:
    """
    Valida que los campos de only_fields existan en el serializer.
    
    Args:
        serializer_class: Clase del serializador DRF
        only_fields: Lista de campos a validar
        
    Returns:
        True si todos los campos son válidos
        
    Raises:
        InvalidFieldError: Si algún campo no existe en el serializer
    """
    if not only_fields:
        return True
    
    try:
        # Crear instancia temporal del serializer para obtener campos
        serializer_instance = serializer_class()
        serializer_fields = set(serializer_instance.get_fields().keys())
        only_fields_set = set(only_fields)
        
        invalid_fields = only_fields_set - serializer_fields
        if invalid_fields:
            raise InvalidFieldError(
                f"Los campos {invalid_fields} no existen en {serializer_class.__name__}"
            )
        
        return True
    except Exception as e:
        if isinstance(e, InvalidFieldError):
            raise
        raise InvalidFieldError(f"Error validando serializer {serializer_class.__name__}: {e}")


def clean_filter_value(value: Any) -> Any:
    """
    Limpia y normaliza valores de filtros.
    NO procesa operadores (gt:, gte:, etc.) - eso lo hace parse_filter_operator
    
    Args:
        value: Valor del filtro a limpiar
        
    Returns:
        Valor limpio y normalizado
    """
    if isinstance(value, str):
        # Limpiar espacios en blanco
        value = value.strip()
        
        # Convertir strings boolean
        if value.lower() in ('true', 'false'):
            return value.lower() == 'true'
        
        # Convertir strings numéricos
        if value.isdigit():
            return int(value)
        
        try:
            return float(value)
        except ValueError:
            pass
    
    return value


def parse_filter_operator(field_name: str, value: Any) -> tuple:
    """
    Detecta operadores especiales en valores de filtro y limpia el valor.
    
    Formatos soportados:
        'gt:10' -> ('field__gt', 10, False)
        'gte:5' -> ('field__gte', 5, False)
        'lt:100' -> ('field__lt', 100, False)
        'lte:50' -> ('field__lte', 50, False)
        'ne:0' -> ('field', 0, True) - usar exclude
        
    Args:
        field_name: Nombre del campo
        value: Valor que puede contener operador
        
    Returns:
        tuple: (field_lookup, cleaned_value, use_exclude)
    """
    if not isinstance(value, str):
        return (field_name, clean_filter_value(value), False)
    
    operators = {
        'gt:': '__gt',
        'gte:': '__gte',
        'lt:': '__lt',
        'lte:': '__lte',
        'ne:': '',
    }
    
    for op_prefix, op_suffix in operators.items():
        if value.startswith(op_prefix):
            raw_value = value[len(op_prefix):]
            cleaned_value = clean_filter_value(raw_value)
            
            if op_prefix == 'ne:':
                return (field_name, cleaned_value, True)
            else:
                return (f"{field_name}{op_suffix}", cleaned_value, False)
    
    return (field_name, clean_filter_value(value), False)


def build_search_query_parts(search_query: str, search_fields: List[str]) -> Dict[str, str]:
    """
    Construye las partes de una consulta de búsqueda.

    Args:
        search_query: Término de búsqueda
        search_fields: Lista de campos donde buscar

    Returns:
        Diccionario con los filtros de búsqueda construidos
    """
    if not search_query or not search_fields:
        return {}

    search_filters = {}
    for field in search_fields:
        search_filters[f"{field}__icontains"] = search_query

    return search_filters


def auto_detect_exact_match_fields(model: models.Model, exact_match_filters: Optional[Set[str]] = None, debug: bool = False) -> Set[str]:
    """
    Detecta automáticamente qué campos deben usar igualdad exacta (=)
    en lugar de búsqueda LIKE (icontains) basándose en el tipo de Django Field.

    Campos que SIEMPRE usan igualdad exacta:
    - ForeignKey, OneToOneField (relaciones)
    - IntegerField, AutoField, BigIntegerField, SmallIntegerField (números)
    - BooleanField, NullBooleanField (booleanos)
    - UUIDField (UUIDs)
    - SlugField (slugs - muchas veces son enum-like)
    - ChoiceField con choices definidas (enums)
    - DateField, TimeField, DateTimeField (fechas)

    Campos que usan LIKE (búsqueda textual):
    - CharField, TextField sin choices
    - EmailField, URLField

    Args:
        model: Modelo Django a analizar
        exact_match_filters: Si se proporciona, no se sobrescribe
        debug: Habilita logs de debug

    Returns:
        Set de nombres de campos que usan igualdad exacta
    """
    from django.db import models as django_models

    # Si se pasó explícitamente, no auto-detectar
    if exact_match_filters is not None and len(exact_match_filters) > 0:
        if debug:
            print(f"🔍 [DEBUG] Usando exact_match_filters explícito: {exact_match_filters}")
        return exact_match_filters

    exact_fields = set()

    try:
        for field in model._meta.get_fields():
            # Saltar campos no relevantes
            if field.name.startswith('_'):
                continue

            # 1. ForeignKey, OneToOne → siempre exacto
            if isinstance(field, (django_models.ForeignKey, django_models.OneToOneField)):
                exact_fields.add(field.name)
                if debug:
                    print(f"  ✓ ForeignKey: {field.name}")

            # 2. Campos numéricos → siempre exacto
            elif isinstance(field, (
                django_models.IntegerField,
                django_models.AutoField,
                django_models.BigIntegerField,
                django_models.SmallIntegerField,
                django_models.PositiveIntegerField,
                django_models.PositiveSmallIntegerField,
                django_models.DecimalField,
                django_models.FloatField,
            )):
                exact_fields.add(field.name)
                if debug:
                    print(f"  ✓ Numeric: {field.name}")

            # 3. Booleanos → siempre exacto
            elif isinstance(field, (django_models.BooleanField, django_models.NullBooleanField)):
                exact_fields.add(field.name)
                if debug:
                    print(f"  ✓ Boolean: {field.name}")

            # 4. UUIDField → siempre exacto
            elif isinstance(field, django_models.UUIDField):
                exact_fields.add(field.name)
                if debug:
                    print(f"  ✓ UUID: {field.name}")

            # 5. DateTimeField, DateField, TimeField → siempre exacto
            elif isinstance(field, (
                django_models.DateTimeField,
                django_models.DateField,
                django_models.TimeField,
            )):
                exact_fields.add(field.name)
                if debug:
                    print(f"  ✓ DateTime: {field.name}")

            # 6. Campos con choices (CharField, IntegerField, etc. con choices)
            elif hasattr(field, 'choices') and field.choices:
                exact_fields.add(field.name)
                if debug:
                    print(f"  ✓ ChoiceField: {field.name}")

            # 7. SlugField → similar a choice (generalmente valores controlados)
            elif isinstance(field, django_models.SlugField):
                exact_fields.add(field.name)
                if debug:
                    print(f"  ✓ SlugField: {field.name}")

    except Exception as e:
        if debug:
            print(f"⚠️ Error auto-detectando campos exactos: {e}")

    if debug:
        print(f"\n🔍 [DEBUG] Auto-detected exact_match_filters: {exact_fields}\n")

    return exact_fields


def parse_dynamic_fields(request, enable_dynamic_fields: bool = True, nested_fields: Optional[Dict] = None) -> Dict[str, Any]:
    """
    Parsea los campos dinámicos desde los query parameters del request.

    Query Parameters soportados:
        only_fields: Lista de campos a incluir separados por coma
        exclude_fields: Lista de campos a excluir separados por coma
        nested_fields: JSON string con configuración de campos anidados

    Ejemplos:
        ?only_fields=id,name,code
        ?exclude_fields=created_at,updated_at
        ?nested_fields={"parent_store":{"only_fields":["id","name"]}}

    Args:
        request: Request object de Django REST Framework
        enable_dynamic_fields: Habilita campos dinámicos desde query params
        nested_fields: Configuración de campos anidados por defecto

    Returns:
        dict: Diccionario con configuración de campos dinámicos
    """
    dynamic_config = {}

    if not enable_dynamic_fields:
        return dynamic_config

    # Parsear only_fields
    only_fields_param = request.query_params.get('only_fields')
    if only_fields_param:
        only_fields = [field.strip() for field in only_fields_param.split(',')]
        if only_fields:
            dynamic_config['only_fields'] = only_fields

    # Parsear exclude_fields
    exclude_fields_param = request.query_params.get('exclude_fields')
    if exclude_fields_param:
        exclude_fields = [field.strip() for field in exclude_fields_param.split(',')]
        if exclude_fields:
            dynamic_config['exclude'] = exclude_fields

    # Parsear nested_fields (JSON) desde query params O usar default
    nested_fields_param = request.query_params.get('nested_fields')
    if nested_fields_param:
        try:
            import json
            nested_fields_data = json.loads(nested_fields_param)
            if isinstance(nested_fields_data, dict) and nested_fields_data:
                dynamic_config['nested_fields'] = nested_fields_data
        except (json.JSONDecodeError, ValueError):
            pass
    elif nested_fields:  # ← Usar nested_fields por defecto si no hay query param
        dynamic_config['nested_fields'] = nested_fields

    return dynamic_config


def get_dynamic_select_related(only_fields: Optional[List[str]], static_select_related: List[str], debug: bool = False) -> List[str]:
    """
    Construye dinámicamente select_related basado en los campos solicitados
    dentro de only_fields, permitiendo niveles profundos (a__b__c__d).

    Args:
        only_fields: Lista de campos que el serializer realmente usará.
        static_select_related: Relaciones permitidas definidas por la vista.
        debug: Habilita logs de debug

    Returns:
        list: Lista optimizada de select_related con niveles profundos.
    """
    if not only_fields:
        return static_select_related

    needed_relations = set()

    for field in only_fields:
        # Solo analizamos campos con "__"
        if "__" not in field:
            continue

        # Separar niveles: ej. "created_by__user__username"
        parts = field.split("__")

        # Construir incrementalmente la ruta:
        # created_by
        # created_by__user
        # created_by__user__profile
        for i in range(1, len(parts)):
            relation_path = "__".join(parts[:i])  # ejemplo: created_by__user

            # Agregar solo si está permitido en static_select_related
            # Permite coincidencias parciales o exactas
            if any(
                relation_path == rel or relation_path.startswith(rel + "__")
                for rel in static_select_related
            ):
                needed_relations.add(relation_path)

    dynamic_select_related = sorted(list(needed_relations))

    if debug:
        print("🔍 [DEBUG] Dynamic select_related (deep analysis):")
        print(f"   ➤ Input only_fields: {only_fields}")
        print(f"   ➤ Allowed (static):  {static_select_related}")
        print(f"   ➤ Result:            {dynamic_select_related}")

    return dynamic_select_related


def get_dynamic_prefetch_related(only_fields: Optional[List[str]], static_prefetch_related: List[str]) -> List[str]:
    """
    Determina qué prefetch_related usar basado en los only_fields dinámicos.
    Soporta tanto strings como objetos Prefetch.

    Args:
        only_fields: Lista de campos que se van a usar
        static_prefetch_related: Lista fija de prefetch_related del constructor

    Returns:
        list: Lista optimizada de prefetch necesarios (strings o Prefetch objects)
    """
    from django.db.models import Prefetch
    
    if not only_fields:
        return static_prefetch_related

    needed_prefetch = set()
    prefetch_objects = {}  # Para mantener objetos Prefetch

    # Detectar qué prefetch son realmente necesarios
    for field in only_fields:
        if '__' in field:
            relation = field.split('__')[0]
            # Verificar que la relación esté en la lista permitida de prefetch
            for prefetch in static_prefetch_related:
                # ✅ Manejar tanto strings como Prefetch objects
                if isinstance(prefetch, Prefetch):
                    # Obtener el nombre de la relación del Prefetch
                    prefetch_name = prefetch.prefetch_to if hasattr(prefetch, 'prefetch_to') else str(prefetch)
                    if prefetch_name.startswith(relation):
                        prefetch_objects[prefetch_name] = prefetch
                        needed_prefetch.add(prefetch_name)
                elif isinstance(prefetch, str):
                    if prefetch.startswith(relation):
                        needed_prefetch.add(prefetch)
        # También buscar por nombres directos
        else:
            for prefetch in static_prefetch_related:
                if isinstance(prefetch, Prefetch):
                    prefetch_name = prefetch.prefetch_to if hasattr(prefetch, 'prefetch_to') else str(prefetch)
                    if field == prefetch_name:
                        prefetch_objects[prefetch_name] = prefetch
                        needed_prefetch.add(prefetch_name)
                elif isinstance(prefetch, str):
                    if field == prefetch:
                        needed_prefetch.add(prefetch)

    # Construir lista resultado con el tipo correcto (string o Prefetch)
    result = []
    for item in static_prefetch_related:
        if isinstance(item, Prefetch):
            prefetch_name = item.prefetch_to if hasattr(item, 'prefetch_to') else str(item)
            if prefetch_name in needed_prefetch:
                result.append(item)  # Mantener el objeto Prefetch original
        elif isinstance(item, str):
            if item in needed_prefetch:
                result.append(item)
    
    return result


def validate_sql_only_fields(only_fields: Optional[List[str]], model_field_names: Set[str], model: Optional[models.Model] = None, select_related_fields: Optional[List[str]] = None, debug: bool = False) -> List[str]:
    """
    Valida que los campos para only() sean válidos para SQL.
    Solo agrega FKs que son necesarios:
    1. FKs de relaciones en select_related explícito
    2. FK del modelo padre se agrega en _build_recursive_only_fields

    Args:
        only_fields: Lista de campos a validar
        model_field_names: Set de nombres de campos del modelo
        model: Modelo Django (opcional)
        select_related_fields: Lista de campos en select_related (para agregar sus FKs)
        debug: Habilita logs de debug

    Returns:
        list: Lista de campos válidos para SQL only()
    """
    if not only_fields:
        return []

    if debug:
        print(f"🔍 [validate_sql_only_fields] INPUT only_fields: {only_fields}")
        print(f"🔍 [validate_sql_only_fields] model_field_names: {model_field_names}")

    valid_fields = []
    related_fields = {}

    for field in only_fields:
        if field in ['id', 'pk']:
            valid_fields.append(field)
        elif '__' not in field and field in model_field_names:
            valid_fields.append(field)
        # Campos FK (_id) - verificar si la relación base existe
        elif field.endswith('_id') and '__' not in field:
            relation_name = field[:-3]  # Quitar '_id'
            if relation_name in model_field_names:
                valid_fields.append(field)
                if debug:
                    print(f"  ✅ FK campo agregado: {field} (relación: {relation_name})")
        elif '__' in field:
            relation = field.split('__')[0]
            related_field = field.split('__', 1)[1]

            if relation in model_field_names:
                if relation not in related_fields:
                    related_fields[relation] = []
                related_fields[relation].append(related_field)

    for relation, fields in related_fields.items():
        if relation not in valid_fields:
            valid_fields.append(relation)

        for related_field in fields:
            full_field = f"{relation}__{related_field}"
            valid_fields.append(full_field)

    # Solo agregar FKs de relaciones que están en select_related
    if select_related_fields and model:
        for rel in select_related_fields:
            parts = rel.split('__')
            base_relation = parts[0]
            
            try:
                field_obj = model._meta.get_field(base_relation)
                if isinstance(field_obj, (models.ForeignKey, models.OneToOneField)):
                    fk_field = f"{base_relation}_id"
                    if fk_field not in valid_fields:
                        valid_fields.append(fk_field)
                        if debug:
                            print(f"  ✅ FK agregado por select_related: {fk_field}")
            except:
                pass

    if debug:
        print(f"🔍 [validate_sql_only_fields] OUTPUT valid_fields: {valid_fields}\n")

    return valid_fields


def build_optimized_prefetch(model, prefetch_relation, nested_config, debug=False):
    """
    Construye un Prefetch optimizado con select_related y only() basado en nested_fields.
    """
    from django.db.models import Prefetch
    
    def _build_recursive_only_fields(config, current_model, parent_model):
        
        # Si no hay config, retornamos lista vacía para NO aplicar .only()
        # Esto hace un SELECT * para prefetch_related no especificados (como 'plataformas')
        if not config.get('only_fields') and not config.get('nested_fields') and not config.get('select_related'):
            return []

        only_fields = []
        nested_only = config.get('only_fields', [])
        
        # Soporte para __all__ recursivo
        if '__all__' in nested_only:
            only_fields.extend(list(get_model_field_names(current_model)))
        else:
            only_fields.extend(nested_only)
        
        # Buscar el nombre real del FK que apunta al parent_model
        parent_fk = None
        for field in current_model._meta.get_fields():
            if isinstance(field, (models.ForeignKey, models.OneToOneField)):
                if field.related_model == parent_model:
                    parent_fk = f"{field.name}_id"
                    break
        
        if parent_fk and parent_fk not in only_fields:
            only_fields.append(parent_fk)
            if debug:
                print(f"  ✅ FK padre agregado: {parent_fk}")
        
        if 'id' not in only_fields:
            only_fields.append('id')
        
        if config.get('select_related'):
            for rel_path in config['select_related']:
                for part in rel_path.split('__'):
                    fk_field = f"{part}_id"
                    if fk_field not in only_fields:
                        only_fields.append(fk_field)
                
                base_relation = rel_path.split('__')[0]
                related_id_field = f"{base_relation}__id"
                if related_id_field not in only_fields:
                    only_fields.append(related_id_field)
        
        if config.get('nested_fields'):
            for nested_relation, nested_relation_config in config['nested_fields'].items():
                if not isinstance(nested_relation_config, dict):
                    continue
                
                fk_field = f"{nested_relation}_id"
                if fk_field not in only_fields:
                    only_fields.append(fk_field)
                
                try:
                    nested_related_model = None
                    try:
                        nested_related_model = current_model._meta.get_field(nested_relation).related_model
                    except:
                        nested_related_model = next(
                            (f.related_model for f in current_model._meta.get_fields() 
                            if hasattr(f, 'get_accessor_name') and f.get_accessor_name() == nested_relation), 
                            None
                        )
                    
                    if nested_related_model:
                        deeper_fields = _build_recursive_only_fields(
                            config=nested_relation_config,
                            current_model=nested_related_model,
                            parent_model=current_model
                        )
                        
                        for field in deeper_fields:
                            if field not in ['id', f'{current_model._meta.model_name}_id']:
                                prefixed_field = f"{nested_relation}__{field}"
                                if prefixed_field not in only_fields:
                                    only_fields.append(prefixed_field)
                
                except Exception as e:
                    if debug: print(f"⚠️ Error procesando nested recursivo '{nested_relation}': {e}")
        
        return only_fields
    
    try:
        related_model = None
        try:
            related_model = model._meta.get_field(prefetch_relation).related_model
        except:
            related_model = next(
                (f.related_model for f in model._meta.get_fields() 
                if hasattr(f, 'get_accessor_name') and f.get_accessor_name() == prefetch_relation), 
                None
            )
        
        if not related_model:
            return prefetch_relation

        queryset = related_model._default_manager.all()
        
        try:
            from polymorphic.models import PolymorphicModel
            if issubclass(related_model, PolymorphicModel):
                queryset = queryset.non_polymorphic()
        except ImportError:
            pass
        
        auto_detected_fks = []
        for field in related_model._meta.get_fields():
            if isinstance(field, (models.ForeignKey, models.OneToOneField)):
                auto_detected_fks.append(field.name)
        
        if 'select_related' in nested_config:
            select_related_fields = nested_config['select_related']
        else:
            select_related_fields = auto_detected_fks
        
        if select_related_fields:
            queryset = queryset.select_related(*select_related_fields)
        
        only_fields = _build_recursive_only_fields(
            config=nested_config,
            current_model=related_model,
            parent_model=model
        )
        
        # 🔥 MAGIA 4: Si only_fields viene vacío ([]), saltamos esta validación
        # y NO aplicamos queryset.only(), forzando el SELECT * que buscábamos.
        if only_fields:
            related_model_field_names = get_model_field_names(related_model)
            valid_only_fields = validate_sql_only_fields(
                only_fields=only_fields,
                model_field_names=related_model_field_names,
                model=related_model,
                select_related_fields=select_related_fields,
                debug=debug
            )
            
            if valid_only_fields:
                queryset = queryset.only(*valid_only_fields)
        
        return Prefetch(prefetch_relation, queryset=queryset)
        
    except Exception as e:
        if debug: print(f"⚠️ Error optimizando prefetch '{prefetch_relation}': {e}")
        return prefetch_relation
    
def expand_nested_to_only_fields(
    nested_fields: dict, 
    existing_only_fields: list = None,
    model=None, 
    debug: bool = False
) -> list:
    """
    Auto-expande nested_fields a formato only_fields para optimización SQL.
    Soporta '__all__' para incluir todos los campos de una relación.
     Solo agrega campos que realmente existen en el modelo Django.
    
    Ejemplo:
        nested_fields = {
            'notification': {
                'only_fields': ['id', 'title', 'action_type']  # action_type es SerializerMethodField
            }
        }
        
        → Solo agrega: ['notification', 'notification__id', 'notification__title']
          (action_type se ignora porque no existe en el modelo)
    
    Args:
        nested_fields: Configuración de campos anidados
        existing_only_fields: Campos ya definidos manualmente
        model: Modelo principal para detectar relaciones válidas
        debug: Habilita logs de debug
        
    Returns:
        Lista expandida de only_fields incluyendo solo campos reales del modelo
    """
    expanded_fields = set(existing_only_fields) if existing_only_fields else set()
    
    if not model:
        if debug: print("⚠️ [DEBUG] No se proporcionó modelo, no se puede validar campos relacionados")
        return list(expanded_fields)
    
    for relation_name, config in nested_fields.items():
        if not isinstance(config, dict):
            continue
            
        nested_only = config.get('only_fields', [])
        if not nested_only:
            continue
        
        try:
            related_model = None
            try:
                field = model._meta.get_field(relation_name)
                related_model = field.related_model
            except:
                related_model = next(
                    (f.related_model for f in model._meta.get_fields() 
                     if hasattr(f, 'get_accessor_name') and f.get_accessor_name() == relation_name), 
                    None
                )
            
            if not related_model:
                continue
            
            related_model_fields = get_model_field_names(related_model)
            
            # Soporte para __all__
            if '__all__' in nested_only:
                for field in related_model_fields:
                    expanded_fields.add(f"{relation_name}__{field}")
                expanded_fields.add(relation_name)
                if debug:
                    print(f"  ✅ [__all__] Agregados todos los campos para: {relation_name}")
                continue # Pasamos a la siguiente relación

            for field in nested_only:
                if '__' in field:
                    base_field = field.split('__')[0]
                    if base_field in related_model_fields:
                        expanded_fields.add(f"{relation_name}__{field}")
                elif field in related_model_fields or field in ['id', 'pk']:
                    expanded_field = f"{relation_name}__{field}"
                    expanded_fields.add(expanded_field)
            
            expanded_fields.add(relation_name)
            
        except Exception as e:
            if debug: print(f"⚠️ [DEBUG] Error procesando relación '{relation_name}': {e}")
            continue
    
    result = sorted(list(expanded_fields))
    return result