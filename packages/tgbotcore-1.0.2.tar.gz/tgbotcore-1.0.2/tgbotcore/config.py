from pydantic_settings import BaseSettings
from pydantic import field_validator
from typing import Any

class Settings(BaseSettings):
    # ------------------------------------------------------------------
    # Обязательные — без них бот не запустится
    # ------------------------------------------------------------------
    BOT_TOKEN: str
    ADMIN_IDS: Any = []

    # ------------------------------------------------------------------
    # База данных
    # ------------------------------------------------------------------
    DATABASE_URL: str = "sqlite+aiosqlite:///bot.db"

    # ------------------------------------------------------------------
    # Антиспам
    # ------------------------------------------------------------------
    RATE_LIMIT: int = 30         # максимум сообщений за окно
    RATE_LIMIT_WINDOW: int = 60  # окно в секундах

    # ------------------------------------------------------------------
    # Общие настройки
    # ------------------------------------------------------------------
    DEBUG: bool = False
    TIMEZONE: str = "Europe/Moscow"

    # ------------------------------------------------------------------
    # Реферальная программа
    # ------------------------------------------------------------------
    REFERRAL_BONUS: int = 10

    # ------------------------------------------------------------------
    # Валидация
    # ------------------------------------------------------------------
    @field_validator("ADMIN_IDS", mode="before")
    @classmethod
    def parse_admin_ids(cls, v):
        if not v:
            return []
        if isinstance(v, (int, float)):
            return [int(v)]
        if isinstance(v, list):
            return [int(i) for i in v]
        if isinstance(v, str):
            v = v.strip().strip("'\"")
            if not v:
                return []
            return [int(i.strip()) for i in v.split(",") if i.strip()]
        return []

    @field_validator("BOT_TOKEN")
    @classmethod
    def validate_bot_token(cls, v: str) -> str:
        if ":" not in v:
            raise ValueError("BOT_TOKEN has invalid format, expected '123456:ABC...'")
        return v

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "allow",
    }
