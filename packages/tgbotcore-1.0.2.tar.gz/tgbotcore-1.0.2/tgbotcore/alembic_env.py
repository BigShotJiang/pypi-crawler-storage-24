from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool


def run(database_url: str) -> None:
    """
    Универсальный runner для alembic env.py шаблона.

    Использование в alembic/env.py шаблона:
        from tgbotcore.alembic_env import run
        import db.models
        from config import settings
        run(settings.DATABASE_URL)
    """
    config = context.config
    config.set_main_option("sqlalchemy.url", _sync_url(database_url))

    target_metadata = _get_metadata()

    connectable = engine_from_config(
        config.get_section(config.config_ini_section),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,  # отслеживает изменения типов колонок
            compare_server_default=True,
        )
        with context.begin_transaction():
            context.run_migrations()


def _get_metadata():
    """Берёт metadata из Base — видит все зарегистрированные модели"""
    from tgbotcore.models import Base
    return Base.metadata


def _sync_url(database_url: str) -> str:
    """Конвертирует async URL в sync для alembic"""
    return database_url.replace(
        "postgresql+asyncpg://",
        "postgresql://",
    ).replace(
        "sqlite+aiosqlite://",
        "sqlite://",
    )
