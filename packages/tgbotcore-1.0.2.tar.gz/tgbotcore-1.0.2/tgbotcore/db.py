from collections.abc import AsyncGenerator
from sqlalchemy import select
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    AsyncEngine,
    async_sessionmaker,
    create_async_engine,
)
from alembic import command
from alembic.config import Config
from alembic.script import ScriptDirectory

from tgbotcore.models import Base
import logging

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------
# Глобальные объекты — инициализируются через init_db()
# ------------------------------------------------------------------
_engine: AsyncEngine | None = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def get_engine() -> AsyncEngine:
    if _engine is None:
        raise RuntimeError("Database is not initialized. Call init_db() first.")
    return _engine


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    if _session_factory is None:
        raise RuntimeError("Database is not initialized. Call init_db() first.")
    return _session_factory

def run_migrations(alembic_cfg_path: str = "alembic.ini") -> None:
    """Запускает alembic upgrade head. Если миграций нет — создаёт начальную."""
    config = Config(alembic_cfg_path)
    scripts = ScriptDirectory.from_config(config)

    if not list(scripts.walk_revisions()):
        logger.info("No migrations found — generating initial migration")
        command.revision(config, autogenerate=True, message="initial")
        logger.info("Initial migration created")

    command.upgrade(config, "head")
    logger.info("Migrations applied")

# ------------------------------------------------------------------
# Инициализация — вызывается один раз в main.py
# ------------------------------------------------------------------
async def init_db(database_url: str, create_tables: bool = False,
                  user_model=None, admin_ids: list[int] | None = None) -> None:
    """
    Инициализирует соединение с БД.

    Args:
        database_url:  URL подключения из settings.DATABASE_URL
        create_tables: True  — создать таблицы если не существуют (dev)
                       False — ничего не трогать в схеме (prod)
    """
    global _engine, _session_factory

    _engine = create_async_engine(
        database_url,
        echo=False,
        pool_pre_ping=True,       # проверяет соединение перед использованием
    )

    _session_factory = async_sessionmaker(
        bind=_engine,
        class_=AsyncSession,
        expire_on_commit=False,   # объекты живут после commit()
        autoflush=False,
        autocommit=False,
    )

    if create_tables:
        async with _engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    if user_model and admin_ids:
        await ensure_admins(user_model, admin_ids)


# ------------------------------------------------------------------
# Dependency — используется в middleware и handlers
# ------------------------------------------------------------------
async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Async generator для получения сессии.

    Использование в handler:
        async def handler(message, session: AsyncSession):
            ...

    Middleware инжектит сессию автоматически через data["session"].
    """
    factory = get_session_factory()
    async with factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise

# ------------------------------------------------------------------
# Назначение админов — если не назначены
# ------------------------------------------------------------------
async def ensure_admins(user_model, admin_ids: list[int]) -> None:
    """Назначает админов из ADMIN_IDS если они уже есть в БД"""
    factory = get_session_factory()
    async with factory() as session:
        for telegram_id in admin_ids:
            result = await session.execute(
                select(user_model).where(user_model.telegram_id == telegram_id)
            )
            user = result.scalar_one_or_none()
            if user and not user.is_admin:
                user.is_admin = True
                logger.info(f"Admin assigned: {telegram_id}")
        await session.commit()
