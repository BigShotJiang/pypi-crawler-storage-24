from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder


# ------------------------------------------------------------------
# Пагинация
# ------------------------------------------------------------------
def paginate(
    items: list[tuple[str, str]],
    page: int,
    callback_prefix: str,
    page_size: int = 8,
) -> InlineKeyboardMarkup:
    """
    Инлайн-клавиатура с пагинацией.

    Args:
        items:           список кортежей (текст кнопки, callback_data)
        page:            текущая страница (с 0)
        callback_prefix: префикс для навигационных кнопок
                         результирующий callback: "{prefix}:page:{n}"
        page_size:       количество элементов на странице

    Использование:
        products = [("Товар 1", "product:1"), ("Товар 2", "product:2")]
        kb = paginate(products, page=0, callback_prefix="catalog")

    Навигационные callback'и которые нужно обработать в шаблоне:
        "{callback_prefix}:page:0"
        "{callback_prefix}:page:1"
        ...
    """
    builder = InlineKeyboardBuilder()

    # элементы текущей страницы
    start = page * page_size
    end = start + page_size
    page_items = items[start:end]
    total_pages = (len(items) + page_size - 1) // page_size

    # кнопки элементов — по одной в строку
    for text, callback_data in page_items:
        builder.row(
            InlineKeyboardButton(text=text, callback_data=callback_data)
        )

    # навигационная строка
    nav_buttons = []

    if page > 0:
        nav_buttons.append(
            InlineKeyboardButton(
                text="← Назад",
                callback_data=f"{callback_prefix}:page:{page - 1}",
            )
        )

    if total_pages > 1:
        nav_buttons.append(
            InlineKeyboardButton(
                text=f"{page + 1} / {total_pages}",
                callback_data="pagination:noop",  # ничего не делает
            )
        )

    if page < total_pages - 1:
        nav_buttons.append(
            InlineKeyboardButton(
                text="Вперёд →",
                callback_data=f"{callback_prefix}:page:{page + 1}",
            )
        )

    if nav_buttons:
        builder.row(*nav_buttons)

    return builder.as_markup()


# ------------------------------------------------------------------
# Подтверждение действия
# ------------------------------------------------------------------
def confirm_cancel(
    confirm_text: str = "✅ Подтвердить",
    cancel_text: str = "❌ Отмена",
    confirm_callback: str = "confirm",
    cancel_callback: str = "cancel",
) -> InlineKeyboardMarkup:
    """
    Две кнопки подтверждения и отмены.

    Использование:
        kb = confirm_cancel(
            confirm_text="✅ Оформить заказ",
            cancel_callback="cart:cancel",
        )
    """
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text=confirm_text, callback_data=confirm_callback),
        InlineKeyboardButton(text=cancel_text, callback_data=cancel_callback),
    )
    return builder.as_markup()


# ------------------------------------------------------------------
# Кнопка назад
# ------------------------------------------------------------------
def back_button(
    callback: str,
    text: str = "← Назад",
) -> InlineKeyboardMarkup:
    """
    Одна кнопка назад.

    Использование:
        kb = back_button(callback="catalog:page:0")
    """
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text=text, callback_data=callback)
    )
    return builder.as_markup()


# ------------------------------------------------------------------
# Reply-клавиатура главного меню
# ------------------------------------------------------------------
def main_menu(
    buttons: list[str],
    resize: bool = True,
    one_time: bool = False,
) -> ReplyKeyboardMarkup:
    """
    Reply-клавиатура из списка строк.
    Автоматически строит строки по 2 кнопки.

    Использование:
        kb = main_menu(["🛒 Каталог", "🛍 Корзина", "📦 Заказы", "⚙️ Настройки"])
    """
    builder = ReplyKeyboardBuilder()

    for text in buttons:
        builder.add(KeyboardButton(text=text))

    builder.adjust(2)  # по 2 кнопки в строку

    return builder.as_markup(
        resize_keyboard=resize,
        one_time_keyboard=one_time,
    )


# ------------------------------------------------------------------
# URL-кнопка
# ------------------------------------------------------------------
def url_button(
    text: str,
    url: str,
) -> InlineKeyboardMarkup:
    """
    Одна кнопка со ссылкой.

    Использование:
        kb = url_button("🌐 Открыть сайт", "https://example.com")
    """
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text=text, url=url)
    )
    return builder.as_markup()
