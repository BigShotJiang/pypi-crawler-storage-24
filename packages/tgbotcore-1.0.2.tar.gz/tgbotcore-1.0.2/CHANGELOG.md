# Changelog

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.2] - 2026-03-15

## [1.0.1] - 2026-03-15

## [1.0.0] - 2026-03-15
### Fixed
- `Settings` - исправил валидайию ADMIN_IDS

### Added
- Добавил покрытие тестами всех критически важных функций

## [0.0.0] - 2026-03-15

### Added
- `Settings` — базовый класс конфигурации на pydantic-settings с поддержкой .env
- `UserMixin` — миксин с базовыми полями пользователя включая `referred_by` для реферальной системы
- `TimestampMixin` — миксин `created_at` / `updated_at` для любой модели
- `Base`, `get_session`, `get_session_factory`, `init_db` — асинхронный слой SQLAlchemy
- `ensure_admins` — назначение администраторов из ADMIN_IDS при старте
- `run_migrations` — автоматический запуск alembic миграций при старте бота
- `alembic_env.run()` — универсальный runner для alembic env.py шаблона
- `AntiSpamMiddleware` — ограничение частоты сообщений на пользователя
- `UserMiddleware` — автоматическое получение/создание пользователя и инжект в handler, поддержка `admin_ids` и `is_new_user`
- `paginate` — инлайн-клавиатура с пагинацией
- `confirm_cancel` — клавиатура подтверждения действия
- `back_button` — кнопка назад
- `main_menu` — reply-клавиатура из списка строк
- `url_button` — инлайн-кнопка со ссылкой
- `create_admin_router` — фабрика роутера админки с `/stats`, `/broadcast`, `/ban`, `/unban`, `/user`
