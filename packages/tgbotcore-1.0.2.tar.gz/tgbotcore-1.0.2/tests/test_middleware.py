"""
Тест 5 — Middleware
Проверяет AntiSpamMiddleware и UserMiddleware.
User берётся из conftest.py.
"""
from unittest.mock import AsyncMock, MagicMock

import pytest
import pytest_asyncio


def make_tg_user(user_id=111, username="tester", full_name="Test User"):
    u = MagicMock()
    u.id = user_id
    u.username = username
    u.full_name = full_name
    return u


def make_event():
    return MagicMock()


# ------------------------------------------------------------------
# AntiSpamMiddleware
# ------------------------------------------------------------------

@pytest.mark.asyncio
async def test_antispam_passes_first_message():
    from tgbotcore import AntiSpamMiddleware

    mw = AntiSpamMiddleware(limit=5, window=60)
    handler = AsyncMock(return_value="ok")
    data = {"event_from_user": make_tg_user()}

    result = await mw(handler, make_event(), data)
    assert result == "ok"
    handler.assert_called_once()


@pytest.mark.asyncio
async def test_antispam_blocks_after_limit():
    from tgbotcore import AntiSpamMiddleware

    mw = AntiSpamMiddleware(limit=3, window=60)
    handler = AsyncMock(return_value="ok")
    tg_user = make_tg_user()

    for _ in range(3):
        await mw(handler, make_event(), {"event_from_user": tg_user})

    result = await mw(handler, make_event(), {"event_from_user": tg_user})
    assert result is None
    assert handler.call_count == 3


@pytest.mark.asyncio
async def test_antispam_no_user_passes():
    from tgbotcore import AntiSpamMiddleware

    mw = AntiSpamMiddleware(limit=1, window=60)
    handler = AsyncMock(return_value="ok")

    result = await mw(handler, make_event(), {"event_from_user": None})
    assert result == "ok"


@pytest.mark.asyncio
async def test_antispam_different_users_independent():
    from tgbotcore import AntiSpamMiddleware

    mw = AntiSpamMiddleware(limit=2, window=60)
    handler = AsyncMock(return_value="ok")

    user1 = make_tg_user(user_id=1)
    user2 = make_tg_user(user_id=2)

    await mw(handler, make_event(), {"event_from_user": user1})
    await mw(handler, make_event(), {"event_from_user": user1})
    blocked = await mw(handler, make_event(), {"event_from_user": user1})
    assert blocked is None

    result = await mw(handler, make_event(), {"event_from_user": user2})
    assert result == "ok"


# ------------------------------------------------------------------
# UserMiddleware
# ------------------------------------------------------------------

@pytest.mark.asyncio
async def test_user_middleware_creates_user(db):
    from tgbotcore import UserMiddleware
    from sqlalchemy import select

    factory, User = db
    mw = UserMiddleware(user_model=User)
    handler = AsyncMock(return_value="ok")

    tg_user = make_tg_user(user_id=42)
    await mw(handler, make_event(), {"event_from_user": tg_user})

    async with factory() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == 42)
        )
        user = result.scalar_one_or_none()
        assert user is not None
        assert user.full_name == "Test User"


@pytest.mark.asyncio
async def test_user_middleware_injects_data(db):
    from tgbotcore import UserMiddleware

    factory, User = db
    mw = UserMiddleware(user_model=User)

    injected = {}

    async def handler(event, data):
        injected.update(data)
        return "ok"

    tg_user = make_tg_user(user_id=43)
    await mw(handler, make_event(), {"event_from_user": tg_user})

    assert "user" in injected
    assert "session" in injected
    assert "is_new_user" in injected
    assert injected["is_new_user"] is True


@pytest.mark.asyncio
async def test_user_middleware_existing_user(db):
    from tgbotcore import UserMiddleware

    factory, User = db
    mw = UserMiddleware(user_model=User)

    tg_user = make_tg_user(user_id=44, full_name="Old Name")

    injected = {}

    async def capture(event, d):
        injected.update(d)

    await mw(capture, make_event(), {"event_from_user": tg_user})
    assert injected["is_new_user"] is True

    tg_user.full_name = "New Name"
    await mw(capture, make_event(), {"event_from_user": tg_user})
    assert injected["is_new_user"] is False
    assert injected["user"].full_name == "New Name"


@pytest.mark.asyncio
async def test_user_middleware_admin_ids(db):
    from tgbotcore import UserMiddleware

    factory, User = db
    mw = UserMiddleware(user_model=User, admin_ids=[55])

    tg_user = make_tg_user(user_id=55)
    injected = {}

    async def capture(event, d):
        injected.update(d)

    await mw(capture, make_event(), {"event_from_user": tg_user})
    assert injected["user"].is_admin is True


@pytest.mark.asyncio
async def test_user_middleware_no_user_skips(db):
    from tgbotcore import UserMiddleware

    factory, User = db
    mw = UserMiddleware(user_model=User)
    handler = AsyncMock(return_value="ok")

    result = await mw(handler, make_event(), {"event_from_user": None})
    assert result == "ok"


@pytest.mark.asyncio
async def test_user_middleware_new_user_has_default_fields(db):
    """Новый пользователь имеет дефолтные значения расширенных полей."""
    from tgbotcore import UserMiddleware

    factory, User = db
    mw = UserMiddleware(user_model=User)

    tg_user = make_tg_user(user_id=66)
    injected = {}

    async def capture(event, d):
        injected.update(d)

    await mw(capture, make_event(), {"event_from_user": tg_user})

    user = injected["user"]
    assert user.is_banned is False
    assert user.is_admin is False
    assert hasattr(user, "trial_used")
    assert hasattr(user, "balance")
