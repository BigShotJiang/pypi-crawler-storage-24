"""
Тест 6 — Keyboards
Проверяет что все функции возвращают правильные типы и структуры.
"""
import pytest
from aiogram.types import InlineKeyboardMarkup, ReplyKeyboardMarkup


def test_paginate_returns_markup():
    from tgbotcore import paginate
    items = [(f"Item {i}", f"item:{i}") for i in range(10)]
    kb = paginate(items, page=0, callback_prefix="test")
    assert isinstance(kb, InlineKeyboardMarkup)


def test_paginate_first_page_has_next():
    """На первой странице есть кнопка 'Вперёд'."""
    from tgbotcore import paginate
    items = [(f"Item {i}", f"item:{i}") for i in range(10)]
    kb = paginate(items, page=0, callback_prefix="test", page_size=5)

    all_callbacks = [
        btn.callback_data
        for row in kb.inline_keyboard
        for btn in row
    ]
    assert any("page:1" in cb for cb in all_callbacks)


def test_paginate_last_page_has_prev():
    """На последней странице есть кнопка 'Назад'."""
    from tgbotcore import paginate
    items = [(f"Item {i}", f"item:{i}") for i in range(10)]
    kb = paginate(items, page=1, callback_prefix="test", page_size=5)

    all_callbacks = [
        btn.callback_data
        for row in kb.inline_keyboard
        for btn in row
    ]
    assert any("page:0" in cb for cb in all_callbacks)


def test_paginate_single_page_no_nav():
    """Если один элемент — нет навигации."""
    from tgbotcore import paginate
    kb = paginate([("Only", "only:1")], page=0, callback_prefix="test")

    all_callbacks = [
        btn.callback_data
        for row in kb.inline_keyboard
        for btn in row
    ]
    assert not any("page:" in cb for cb in all_callbacks)


def test_paginate_empty_list():
    """Пустой список — не падает."""
    from tgbotcore import paginate
    kb = paginate([], page=0, callback_prefix="test")
    assert isinstance(kb, InlineKeyboardMarkup)


def test_confirm_cancel_returns_markup():
    from tgbotcore import confirm_cancel
    kb = confirm_cancel()
    assert isinstance(kb, InlineKeyboardMarkup)


def test_confirm_cancel_has_two_buttons():
    from tgbotcore import confirm_cancel
    kb = confirm_cancel(
        confirm_callback="yes",
        cancel_callback="no",
    )
    buttons = [btn for row in kb.inline_keyboard for btn in row]
    callbacks = {btn.callback_data for btn in buttons}
    assert "yes" in callbacks
    assert "no" in callbacks
    assert len(buttons) == 2


def test_back_button_returns_markup():
    from tgbotcore import back_button
    kb = back_button(callback="back:0")
    assert isinstance(kb, InlineKeyboardMarkup)


def test_back_button_callback():
    from tgbotcore import back_button
    kb = back_button(callback="catalog:page:0")
    buttons = [btn for row in kb.inline_keyboard for btn in row]
    assert buttons[0].callback_data == "catalog:page:0"


def test_back_button_custom_text():
    from tgbotcore import back_button
    kb = back_button(callback="back", text="◀ Назад")
    buttons = [btn for row in kb.inline_keyboard for btn in row]
    assert buttons[0].text == "◀ Назад"


def test_main_menu_returns_markup():
    from tgbotcore import main_menu
    kb = main_menu(["Кнопка 1", "Кнопка 2"])
    assert isinstance(kb, ReplyKeyboardMarkup)


def test_main_menu_has_all_buttons():
    from tgbotcore import main_menu
    labels = ["А", "Б", "В", "Г"]
    kb = main_menu(labels)
    all_texts = [btn.text for row in kb.keyboard for btn in row]
    for label in labels:
        assert label in all_texts


def test_url_button_returns_markup():
    from tgbotcore import url_button
    kb = url_button("Сайт", "https://example.com")
    assert isinstance(kb, InlineKeyboardMarkup)


def test_url_button_has_url():
    from tgbotcore import url_button
    kb = url_button("Сайт", "https://example.com")
    buttons = [btn for row in kb.inline_keyboard for btn in row]
    assert buttons[0].url == "https://example.com"
