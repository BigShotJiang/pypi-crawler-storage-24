"""
conftest.py — общие фикстуры для всех тестов.

Ключевая проблема: SQLAlchemy держит Base.metadata глобально.
Если в разных тестах определять class User(UserMixin, Base) — падает с
"Table 'users' is already defined for this MetaData instance."

Решение: определяем User ОДИН РАЗ здесь, все тесты используют его.
"""
import pytest_asyncio
from sqlalchemy.orm import Mapped, mapped_column

from tgbotcore import Base, UserMixin, TimestampMixin


# ------------------------------------------------------------------
# Модели — определяются один раз на весь тестовый прогон
# ------------------------------------------------------------------
class User(UserMixin, Base):
    """Минимальное расширение UserMixin — как в реальном шаблоне."""
    trial_used: Mapped[bool] = mapped_column(default=False, nullable=False)
    balance: Mapped[int] = mapped_column(default=0, nullable=False)


class Subscription(TimestampMixin, Base):
    """Вторая модель — проверяет что Base видит все таблицы."""
    __tablename__ = "subscriptions"
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(nullable=False)
    client_id: Mapped[str] = mapped_column(nullable=False)
    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)


# ------------------------------------------------------------------
# Фикстура БД — пересоздаётся для каждого теста
# ------------------------------------------------------------------
@pytest_asyncio.fixture
async def db():
    """
    Инициализирует SQLite in-memory БД и возвращает (session_factory, User).
    После теста сбрасывает глобальное состояние ядра.
    """
    from tgbotcore import init_db, get_session_factory

    await init_db(database_url="sqlite+aiosqlite:///:memory:", create_tables=True)
    factory = get_session_factory()
    yield factory, User

    from tgbotcore import db as db_module
    if db_module._engine:
        await db_module._engine.dispose()
    db_module._engine = None
    db_module._session_factory = None


@pytest_asyncio.fixture
async def db_with_user(db):
    """БД с одним существующим пользователем."""
    factory, User = db
    async with factory() as session:
        user = User(
            telegram_id=123456,
            username="testuser",
            full_name="Test User",
        )
        session.add(user)
        await session.commit()
    return factory, User
