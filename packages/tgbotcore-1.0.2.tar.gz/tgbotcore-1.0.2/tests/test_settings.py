"""
Тест 2 — Settings
Проверяет валидацию конфига, парсинг ADMIN_IDS и расширение.
"""
import pytest
from pydantic import ValidationError


def test_settings_minimal(monkeypatch):
    """Минимальный конфиг — только обязательные поля."""
    monkeypatch.setenv("BOT_TOKEN", "123456:ABCdef")
    monkeypatch.setenv("ADMIN_IDS", "123456789")

    from tgbotcore import Settings
    s = Settings()
    assert s.BOT_TOKEN == "123456:ABCdef"
    assert s.ADMIN_IDS == [123456789]


def test_settings_defaults(monkeypatch):
    """Дефолтные значения полей."""
    monkeypatch.setenv("BOT_TOKEN", "123456:ABCdef")

    from tgbotcore import Settings
    s = Settings()
    assert s.DATABASE_URL == "sqlite+aiosqlite:///bot.db"
    assert s.RATE_LIMIT == 30
    assert s.RATE_LIMIT_WINDOW == 60
    assert s.DEBUG is False
    assert s.TIMEZONE == "Europe/Moscow"
    assert s.REFERRAL_BONUS == 10


def test_settings_admin_ids_single(monkeypatch):
    """ADMIN_IDS как одно число."""
    monkeypatch.setenv("BOT_TOKEN", "123456:ABCdef")
    monkeypatch.setenv("ADMIN_IDS", "111")

    from tgbotcore import Settings
    s = Settings()
    assert s.ADMIN_IDS == [111]


def test_settings_admin_ids_comma(monkeypatch):
    """ADMIN_IDS через запятую."""
    monkeypatch.setenv("BOT_TOKEN", "123456:ABCdef")
    monkeypatch.setenv("ADMIN_IDS", "111,222,333")

    from tgbotcore import Settings
    s = Settings()
    assert s.ADMIN_IDS == [111, 222, 333]


def test_settings_admin_ids_json(monkeypatch):
    """ADMIN_IDS в JSON-формате."""
    monkeypatch.setenv("BOT_TOKEN", "123456:ABCdef")
    monkeypatch.setenv("ADMIN_IDS", "111, 222")

    from tgbotcore import Settings
    s = Settings()
    assert s.ADMIN_IDS == [111, 222]


def test_settings_invalid_token(monkeypatch):
    """Токен без двоеточия — должен упасть."""
    monkeypatch.setenv("BOT_TOKEN", "invalidtoken")

    from tgbotcore import Settings
    with pytest.raises(ValidationError):
        Settings()


def test_settings_missing_token(monkeypatch):
    """Без токена — должен упасть."""
    monkeypatch.delenv("BOT_TOKEN", raising=False)

    from tgbotcore import Settings
    with pytest.raises(ValidationError):
        Settings()


def test_settings_extension(monkeypatch):
    """Расширение Settings в шаблоне."""
    monkeypatch.setenv("BOT_TOKEN", "123456:ABCdef")
    monkeypatch.setenv("MY_CUSTOM_FIELD", "hello")

    from tgbotcore import Settings

    class MySettings(Settings):
        MY_CUSTOM_FIELD: str
        MY_OPTIONAL: int = 42

    s = MySettings()
    assert s.MY_CUSTOM_FIELD == "hello"
    assert s.MY_OPTIONAL == 42


def test_settings_extra_fields_allowed(monkeypatch):
    """extra='allow' — шаблон может добавлять свои поля."""
    monkeypatch.setenv("BOT_TOKEN", "123456:ABCdef")
    monkeypatch.setenv("SOME_RANDOM_FIELD", "value")

    from tgbotcore import Settings
    # не должно падать
    s = Settings()
    assert s is not None
