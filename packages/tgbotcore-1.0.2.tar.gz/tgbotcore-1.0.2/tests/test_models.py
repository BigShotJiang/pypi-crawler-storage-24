"""
Тест 3 — Models
Проверяет что Base, UserMixin, TimestampMixin правильно определены.
User определён в conftest.py — здесь только проверяем его структуру.
"""
from sqlalchemy import inspect
from sqlalchemy.orm import Mapped, mapped_column


def test_base_is_declarative():
    """Base — DeclarativeBase."""
    from tgbotcore import Base
    assert hasattr(Base, "metadata")
    assert hasattr(Base, "registry")


def test_user_mixin_columns():
    """UserMixin содержит все обязательные колонки."""
    from conftest import User
    from sqlalchemy import inspect

    mapper = inspect(User)
    column_names = {c.key for c in mapper.columns}

    required = {
        "id", "telegram_id", "username", "full_name",
        "is_banned", "is_admin", "last_active",
        "referred_by", "created_at", "updated_at",
    }
    assert required.issubset(column_names)


def test_user_mixin_tablename():
    """UserMixin использует таблицу users."""
    from conftest import User
    assert User.__tablename__ == "users"


def test_user_mixin_extension():
    """Шаблон может добавлять свои колонки — trial_used, balance из conftest."""
    from conftest import User
    from sqlalchemy import inspect

    mapper = inspect(User)
    column_names = {c.key for c in mapper.columns}
    assert "trial_used" in column_names
    assert "balance" in column_names


def test_timestamp_mixin_columns():
    """TimestampMixin добавляет created_at и updated_at."""
    from conftest import Subscription
    from sqlalchemy import inspect

    mapper = inspect(Subscription)
    column_names = {c.key for c in mapper.columns}
    assert "created_at" in column_names
    assert "updated_at" in column_names


def test_single_base():
    """Все модели используют один Base — metadata видит все таблицы."""
    from tgbotcore import Base

    table_names = set(Base.metadata.tables.keys())
    assert "users" in table_names
    assert "subscriptions" in table_names
