"""
Тест 1 — импорты
Проверяет что весь публичный API импортируется без ошибок.
Если этот тест падает — пакет сломан на уровне сборки.
"""


def test_import_package():
    import tgbotcore
    assert tgbotcore.__version__


def test_import_public_api():
    from tgbotcore import (
        # database
        Base,
        get_session,
        get_session_factory,
        init_db,
        ensure_admins,
        run_migrations,
        # models
        UserMixin,
        TimestampMixin,
        # config
        Settings,
        # middleware
        AntiSpamMiddleware,
        UserMiddleware,
        # keyboards
        paginate,
        confirm_cancel,
        back_button,
        main_menu,
        url_button,
        # admin
        create_admin_router,
    )
    # просто проверяем что всё доступно
    assert Base
    assert get_session
    assert get_session_factory
    assert init_db
    assert ensure_admins
    assert run_migrations
    assert UserMixin
    assert TimestampMixin
    assert Settings
    assert AntiSpamMiddleware
    assert UserMiddleware
    assert paginate
    assert confirm_cancel
    assert back_button
    assert main_menu
    assert url_button
    assert create_admin_router


def test_version_format():
    import tgbotcore
    parts = tgbotcore.__version__.split(".")
    assert len(parts) == 3
    assert all(p.isdigit() for p in parts)
