"""
Тест 4 — Database
Проверяет init_db, get_session, ensure_admins на SQLite in-memory.
User берётся из conftest.py — определён там один раз.
"""
import pytest
import pytest_asyncio
from sqlalchemy import select


# ------------------------------------------------------------------
# Тесты init_db
# ------------------------------------------------------------------

@pytest.mark.asyncio
async def test_init_db_creates_tables(db):
    """init_db с create_tables=True создаёт таблицы."""
    from tgbotcore import get_session_factory
    from sqlalchemy import text

    factory, User = db
    async with factory() as session:
        result = await session.execute(
            text("SELECT name FROM sqlite_master WHERE type='table'")
        )
        tables = {row[0] for row in result}
        assert "users" in tables


@pytest.mark.asyncio
async def test_get_session_factory_before_init():
    """get_session_factory до init_db — должен упасть с RuntimeError."""
    from tgbotcore import get_session_factory
    from tgbotcore import db as db_module

    original = db_module._session_factory
    db_module._session_factory = None

    with pytest.raises(RuntimeError, match="init_db"):
        get_session_factory()

    db_module._session_factory = original


@pytest.mark.asyncio
async def test_get_session_crud(db):
    """get_session — можно создать и прочитать запись."""
    factory, User = db

    async with factory() as session:
        user = User(
            telegram_id=999,
            username="crud_user",
            full_name="CRUD User",
        )
        session.add(user)
        await session.commit()

    async with factory() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == 999)
        )
        found = result.scalar_one_or_none()
        assert found is not None
        assert found.full_name == "CRUD User"


# ------------------------------------------------------------------
# Тесты ensure_admins
# ------------------------------------------------------------------

@pytest.mark.asyncio
async def test_ensure_admins_sets_flag(db_with_user):
    """ensure_admins назначает is_admin=True существующему пользователю."""
    from tgbotcore import ensure_admins

    factory, User = db_with_user
    await ensure_admins(User, admin_ids=[123456])

    async with factory() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == 123456)
        )
        user = result.scalar_one()
        assert user.is_admin is True


@pytest.mark.asyncio
async def test_ensure_admins_unknown_user(db):
    """ensure_admins не падает если пользователя нет в БД."""
    from tgbotcore import ensure_admins

    factory, User = db
    await ensure_admins(User, admin_ids=[999999])


@pytest.mark.asyncio
async def test_ensure_admins_already_admin(db_with_user):
    """ensure_admins не ломается если пользователь уже админ."""
    from tgbotcore import ensure_admins

    factory, User = db_with_user
    await ensure_admins(User, admin_ids=[123456])
    await ensure_admins(User, admin_ids=[123456])

    async with factory() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == 123456)
        )
        user = result.scalar_one()
        assert user.is_admin is True


@pytest.mark.asyncio
async def test_user_extension_fields(db):
    """Расширенные поля из conftest (trial_used, balance) работают."""
    factory, User = db

    async with factory() as session:
        user = User(
            telegram_id=777,
            username="vpn_user",
            full_name="VPN User",
            trial_used=False,
            balance=100,
        )
        session.add(user)
        await session.commit()

    async with factory() as session:
        result = await session.execute(
            select(User).where(User.telegram_id == 777)
        )
        found = result.scalar_one()
        assert found.trial_used is False
        assert found.balance == 100
