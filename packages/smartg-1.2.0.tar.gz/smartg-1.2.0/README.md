<p align="center">
<img src="https://hygeos.com/wp-content/uploads/2023/02/SMART-G-300x300.png" width="200">
</p>

SMART-G
=======

[![image](https://img.shields.io/pypi/v/smartg.svg)](https://pypi.python.org/pypi/smartg)
[![image](https://img.shields.io/conda/vn/conda-forge/smartg.svg)](https://anaconda.org/conda-forge/smartg)
[![image](https://pepy.tech/badge/smartg)](https://pepy.tech/project/smartg)
[![image](https://img.shields.io/badge/DOI-10.1038%2Fs41586--020--2649--2-blue)](
https://doi.org/10.1016/j.jqsrt.2018.10.017)

SMART-G (Speed-up Monte Carlo Advanced Radiative Transfer Code using GPU) is a radiative transfer code using a Monte-Carlo technique to simulate the propagation of the polarized light in the atmosphere and/or ocean, and using GPU acceleration.

Didier Ramon  
Mustapha Moulana  
François Steinmetz  
Dominique Jolivet  
Mathieu Compiègne  
[HYGEOS](https://hygeos.com/en/)

----------------------------------------------------------------------  


## 1. Installation

### 1.1 PyPI

To install SMART-G from PyPI:

```bash
pip install smartg
```

To include extra dependencies use instead:

```bash
pip install smartg[extra]
  ```


### 1.2 conda-forge

Use the command:

```bash
conda install -c conda-forge smartg
```

If you need extra dependencies (jax with cuda) we recommend the installation with pip instead.



### 1.3 github clone (for development)
<details>
  <summary>Click here</summary>

  First clone the repository:

  ```bash
  git clone https://github.com/hygeos/smartg.git
  ```

  You can now choose between Pixi or Conda for your development environment.

  #### 1.3.1 Pixi (recommended)
  [Pixi](https://pixi.sh/) is recommended for its fast dependency resolution and robust environment management. Unlike Conda, which only considers Conda packages during conflict resolution, Pixi consider both Conda and pip package versions when solving dependencies.

  To create and activate the environment, use the following command:

  ```bash
  pixi shell
  ```

  To consider all extra dependencies (e.g. jax), use instead:

  ```bash
  pixi shell --environment extra
  ```

  #### 1.3.2 Anaconda/Miniconda (alternative)

  With Anaconda/Miniconda, use the following command:

  ```bash
  conda create -n smartg-env -f environment.yml
  conda activate smartg-env
  ```

  For a full installation (extra dependencies), replace `environment.yml` by `environment-extra.yml`.

</details>

## 2. Nvidia driver and CUDA
An installation guide is available in the nvidia website: [installation-guide](https://docs.nvidia.com/datacenter/tesla/driver-installation-guide/introduction.html).

You can also install CUDA using conda:

```bash
conda install nvidia::cuda
```

## 3. Auxiliary data

The auxiliary data can be downloaded as follow:

```python
>>> # Example to download all the data. See the docstring for more details.
>>> from smartg.auxdata import download
>>> from pathlib import Path
>>> download(Path('dir/path/where/to/save/data/'), data_type='all')
```

The environment variable `SMARTG_DIR_AUXDATA` have to be defined.

For example, in the `.bashrc` / `.zshrc` file the following can be added:

```bash
export SMARTG_DIR_AUXDATA="dir/path/where/to/save/data/"
```

or (not recommended) in a `.env` file in the SMART-G root directory:

```
SMARTG_DIR_AUXDATA =dir/path/where/to/save/data/
```


## 4. Examples

Examples are provided in the [sample notebooks](smartg/notebooks).

[jupyter notebook](http://jupyter.org) has nice possibilities for interactive development and visualization, in particular if you are using a remote cuda computer. Sample notebooks are provided in the folder [notebooks](smartg/notebooks).

## 5. Tests

To check that SMART-G is running correctly, run the following command at the root of the project:

```bash
pytest smartg/tests/test_cuda.py smartg/tests/test_profile.py smartg/tests/test_smartg.py -s -v
```

A full testing is recommended in dev:

```bash
pytest smartg/tests/ -s -v
```

To avoid repeating some pytest arguments, a `pytest.ini` file can be created (in the root directory). The following is an example of the contents of such a file:
```
[pytest]
addopts= --html=test_reportv1.html --self-contained-html -s -v
```
The arguments "--html=test_reportv1.html --self-contained-html" are used to generate an html report containing the results of the tests (sometime with more details e.g. plots), named "test_reportv1.html".

## 6. Hardware tested

GeForce GTX 1070, GeForce TITAN V, GeForce RTX 2080 Ti, Geforce RTX 3070, Geforce RTX 3090, Geforce RTX 4090, A100, Geforce RTX 5070 ti, A6000 blackwell

The use of GPUs before 10xx series (Pascal) is depracated as of SMART-G 1.0.0

## 7. Licensing information

This software is available under the SMART-G license v1.0, available in the LICENSE.TXT file.

## 8. Referencing

When acknowledging the use of SMART-G for scientific papers, reports etc please cite the following reference(s):

* Ramon, D., Steinmetz, F., Jolivet, D., Compiègne, M., & Frouin, R. (2019). Modeling polarized radiative
  transfer in the ocean-atmosphere system with the GPU-accelerated SMART-G Monte Carlo code.
  Journal of Quantitative Spectroscopy and Radiative Transfer, 222, 89-107. https://doi.org/10.1016/j.jqsrt.2018.10.017

* Moulana, M., Cornet, C., Elias, T., Ramon, D., Caliot, C., & Compiègne, M. (2024). Concentrated solar flux
  modeling in solar power  towers with a 3D objects-atmosphere hybrid system to consider atmospheric and environmental
  gains. Solar Energy, 277, 112675. https://doi.org/10.1016/j.solener.2024.112675