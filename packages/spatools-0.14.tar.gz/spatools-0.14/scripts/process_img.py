import os
import cv2 as cv
import numpy as np
import pandas as pd
from anndata import AnnData
from PIL import Image
from skimage import io
from spatools import constants as con
from typing import List, Any, Optional
from pybiomart import Server
import matplotlib.pyplot as plt
from scipy.spatial import distance
from multiprocessing import Pool, cpu_count

def process_image(input_image_path,
                  output_dir: str, 
                  minDist=50, 
                  param1=50, 
                  param2=0.2, 
                  minRadius=50, 
                  maxRadius=100):
    """
    Process an input image to detect circles using Hough Transform.

    Parameters
    ----------
    input_image_path : str
        The path to the input image file.
    output_dir : str
        The directory to save the output files.
    minDist : int, default=50
        Minimum distance between detected circles.
    param1 : int, default=50
        First method-specific parameter for the Hough Transform (higher threshold).
    param2 : float, default=0.2
        Second method-specific parameter for the Hough Transform (accumulator threshold).
    minRadius : int, default=50
        Minimum circle radius to be detected.
    maxRadius : int, default=100
        Maximum circle radius to be detected.

    Returns
    -------
    output_image: png
        Image containing the detected circles outlined by lines generated with Matplotlib.
    output_excel : XLSX
        Path to the Excel file in XLSX format containing a dataframe with the following columns:
        - Center_X: X-coordinate of the center point.
        - Center_Y: Y-coordinate of the center point.
        - Center_Color: Color value of the center point.
        - Neighbor_X: X-coordinate of the neighboring point.
        - Neighbor_Y: Y-coordinate of the neighboring point.
        - Distance: Distance between the center point and the neighboring point.
        - Point_Name: Name of the point in the format "Point_X_Y".
        - Color_Code: Mapped color code from the dictionary.
        - Proximity: Categorization of the distance as 'close' or 'far'.
        - Neighbor_Cluster: Cluster of the neighboring point.
        - Combination: Tuple of sorted color codes of center and neighbor points.
    """
    # Aumentar o limite de pixels
    Image.MAX_IMAGE_PIXELS = None

    # Carregar a imagem
    image = io.imread(input_image_path)

    # Converter RGBA para RGB (ignorando o canal alfa)
    if image.shape[2] == 4:
        image_rgb = image[:, :, :3]
    else:
        image_rgb = image

    # Converter a imagem RGB para escala de cinza
    gray_image = cv.cvtColor(image_rgb, cv.COLOR_BGR2GRAY)

    # Detectar círculos usando a Transformada de Hough
    circles = cv.HoughCircles(
        gray_image,
        cv.HOUGH_GRADIENT_ALT,
        dp=1,
        minDist=minDist,
        param1=param1,
        param2=param2,
        minRadius=minRadius,
        maxRadius=maxRadius 
    )

    if circles is not None:
        circles = np.uint16(np.around(circles[0, :])).astype("int")

        # Obter a cor do centro de cada círculo e seus raios
        centers_colors = [(x, y, image_rgb[y, x]) for x, y, _ in circles]
        radii = circles[:, 2]

        # Calcular a média dos raios e definir a distância limite baseada no círculo e seus 6 vizinhos mais próximos
        mean_radii_with_neighbors = []
        for i, (x, y, r) in enumerate(circles):
            # Calcular a distância para todos os outros círculos
            distances = np.array([distance.euclidean((x, y), (x2, y2)) for (x2, y2, _) in circles if (x2, y2) != (x, y)])
            # Obter os índices dos 6 círculos mais próximos
            nearest_indices = np.argsort(distances)[:6]
            # Calcular a média dos raios desses 6 círculos mais o círculo atual
            mean_radius = np.mean(np.append(radii[nearest_indices], r))
            mean_radii_with_neighbors.append(mean_radius)

        # Definir a distância limite baseada na média dos raios com os vizinhos
        threshold_distance = 2 * np.mean(mean_radii_with_neighbors) * np.sqrt(3) * 0.9

        # Preparar argumentos para paralelização
        args = [(centers_colors, i, threshold_distance) for i in range(len(centers_colors))]

        # Usar Pool para paralelizar o cálculo das distâncias
        with Pool(cpu_count()) as pool:
            results = pool.map(calculate_distances, args)

        # Combinar os resultados
        data = [item for sublist in results for item in sublist]

        df = pd.DataFrame(data, columns=['Center_X', 'Center_Y', 'Center_Color', 'Neighbor_X', 'Neighbor_Y', 'Distance'])

        # Adicionar a coluna 'Point_Name'
        df['Point_Name'] = df.apply(lambda row: f"Point_{row['Center_X']}_{row['Center_Y']}", axis=1)

        # Função para mapear a cor do centro para o dicionário
        def map_color_to_dict(color):
            for key, value in con.COLORS_23.items():
                if tuple(color) == value:
                    return key
            return None

        # Adicionar a coluna 'Color_Code'
        df['Color_Code'] = df['Center_Color'].apply(map_color_to_dict)

        # Adicionar a coluna 'proximity'
        df['proximity'] = df['Distance'].apply(lambda d: 'close' if d < threshold_distance else 'far')

        # Criar um dicionário para mapear as coordenadas dos vizinhos para seus clusters
        neighbor_clusters = {f"{x}_{y}": map_color_to_dict(color) for x, y, color in centers_colors}

        # Adicionar a coluna 'Neighbor_Cluster'
        df['Neighbor_Cluster'] = df.apply(lambda row: neighbor_clusters.get(f"{row['Neighbor_X']}_{row['Neighbor_Y']}"), axis=1)#type:ignore

        # Adicionar a coluna 'combination'
        df['combination'] = df.apply(lambda row: tuple(sorted((row['Color_Code'], row['Neighbor_Cluster']))), axis=1)

        # Salvar o dataframe em Excel
        output_excel_path = os.path.join(output_dir, "output_data.xlsx")
        df.to_excel(output_excel_path, index=False)

        # Plotar a imagem e os círculos detectados
        fig, ax = plt.subplots(figsize=(10, 10))
        ax.imshow(image_rgb)

        # Desenhar os círculos
        for (x, y, r) in circles:
            circle = plt.Circle((x, y), r, color='black', fill=False, linewidth=0.2)#type:ignore
            ax.add_patch(circle)

        ax.set_title('Círculos Detectados')
        plt.axis('off')

        # Salvar a imagem
        output_image_path = os.path.join(output_dir, "detected_circles.png")
        plt.savefig(output_image_path, format="png", dpi=1000)
        plt.close()

        return output_image_path, output_excel_path
    else:
        print("Nenhum círculo foi detectado.")
        return None, None