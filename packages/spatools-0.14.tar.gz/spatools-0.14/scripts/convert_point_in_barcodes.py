import pandas as pd
import scanpy as sc
from spatools.tools.tl import correlate_distances

adata = sc.read("/media/SATA/My_decon_package/redo_/data/output2/concat/scvi_5000_man_cuts.h5ad")
adata = correlate_distances(adata, is_concatenated=True, cluster_col="clusters_0.6", batch_key="batch")

def spot_mean_by_neighbors(adata):
    df = adata.uns["spatools"]
    df_final = pd.DataFrame({})
    for i, n in enumerate(df["point_name"].unique()):
        df_subset_point = df[df["point_name"] == i]
        if df_subset_point["color"].nunique() > 1:
            print("Existe pelo menos um valor diferente")

        elif df["color"].nunique() == 1:
            c = df["color"].unique()[0]
            df["color_neigh"] = [int(i) for i in df["color_neigh"]]
            df_counts = pd.DataFrame(df["color_neigh"].value_counts(normalize=True))
            df_counts["color"] = c
            df_final["color"].iloc[n]

    return 

spot_mean_by_neighbors(adata=adata)



def point_name_to_barcodes(df_barcodes: pd.DataFrame | list, df_point_name: pd.DataFrame | list):
    # convertendo se necessario
    if type(df_barcodes) == list:
        df_barcodes = pd.DataFrame(df_barcodes)
    if type(df_point_name) == list:
        df_point_name = pd.DataFrame(df_point_name)

    pass