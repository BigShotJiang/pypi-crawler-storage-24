"""Tests for KeyManager credential resolution."""

import os
import json
import tempfile
from pathlib import Path

from theprotocol.client import KeyManager


def test_key_from_env(monkeypatch):
    monkeypatch.setenv("THEPROTOCOL_KEY_MYSERVICE", "secret123")
    km = KeyManager(use_keyring=False)
    assert km.get_key("myservice") == "secret123"


def test_key_not_found():
    km = KeyManager(use_keyring=False)
    assert km.get_key("nonexistent") is None


def test_key_from_json_file():
    data = {"myagent": "key-abc-123"}
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(data, f)
        f.flush()
        km = KeyManager(key_file_path=f.name, use_keyring=False)
    assert km.get_key("myagent") == "key-abc-123"
    os.unlink(f.name)


def test_key_from_json_nested():
    data = {"svc": {"apiKey": "nested-key", "oauth": {"clientId": "cid", "clientSecret": "csec"}}}
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(data, f)
        f.flush()
        km = KeyManager(key_file_path=f.name, use_keyring=False)
    assert km.get_key("svc") == "nested-key"
    assert km.get_oauth_client_id("svc") == "cid"
    assert km.get_oauth_client_secret("svc") == "csec"
    os.unlink(f.name)


def test_oauth_from_env(monkeypatch):
    monkeypatch.setenv("THEPROTOCOL_OAUTH_MYAPP_CLIENT_ID", "id-123")
    monkeypatch.setenv("THEPROTOCOL_OAUTH_MYAPP_CLIENT_SECRET", "sec-456")
    km = KeyManager(use_keyring=False)
    assert km.get_oauth_client_id("myapp") == "id-123"
    assert km.get_oauth_client_secret("myapp") == "sec-456"


def test_file_priority_over_env(monkeypatch):
    monkeypatch.setenv("THEPROTOCOL_KEY_SVC", "from-env")
    data = {"svc": "from-file"}
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(data, f)
        f.flush()
        km = KeyManager(key_file_path=f.name, use_keyring=False)
    assert km.get_key("svc") == "from-file"
    os.unlink(f.name)
