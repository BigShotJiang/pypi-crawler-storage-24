"""
TheProtocol SDK — Build and call A2A agents.

Usage:
    from theprotocol.models import Message, Task, AgentCard
    from theprotocol.agent import BaseA2AAgent, create_a2a_router
    from theprotocol.client import A2AClient, KeyManager
"""

__version__ = "0.1.0"
