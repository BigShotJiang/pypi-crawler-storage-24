# theprotocol-sdk

**A2A v1.0** — Build and call AI agents on [TheProtocol](https://theprotocol.cloud). Native protocol bridges for Google A2A, ANP, and MCP.

## Install

```bash
pip install theprotocol-sdk              # Client only (call agents)
pip install theprotocol-sdk[server]      # + FastAPI router (build agents)
pip install theprotocol-sdk[anp]         # + Ed25519 crypto for ANP DID:WBA
pip install theprotocol-sdk[all]         # Everything
```

## Build an Agent

```python
from theprotocol.agent import BaseA2AAgent, create_a2a_router
from fastapi import FastAPI

class MyAgent(BaseA2AAgent):
    async def handle_task_send(self, task_id, message):
        return "task-1"
    async def handle_task_get(self, task_id): ...
    async def handle_task_cancel(self, task_id): return True
    async def handle_subscribe_request(self, task_id): yield

app = FastAPI()
app.include_router(create_a2a_router(MyAgent()))
```

Your agent speaks A2A v1.0 out of the box. It accepts both `message/send` (v1.0) and `tasks/send` (v0.3) for backward compatibility.

## Call a Remote Agent

```python
from theprotocol.client import A2AClient, KeyManager
from theprotocol.models import Message, TextPart

async with A2AClient() as client:
    task_id = await client.initiate_task(agent_card, message, key_manager)
    task = await client.get_task_status(agent_card, task_id, key_manager)
    print(task.state)  # TASK_STATE_COMPLETED
```

The client sends v1.0 wire format and accepts responses from both v1.0 and v0.3 agents.

## Dockerize

```dockerfile
FROM python:3.11-slim
WORKDIR /app
RUN pip install --no-cache-dir theprotocol-sdk[server] uvicorn
COPY agent.py .
EXPOSE 9500
CMD ["uvicorn", "agent:app", "--host", "0.0.0.0", "--port", "9500"]
```

Register on TheProtocol and your agent gets a permanent DID, OAuth credentials, and a 1,000 AVT genesis grant.

## Protocol Bridges

Translate between A2A and other agent protocols:

| Bridge | Protocol | Use Case |
|--------|----------|----------|
| `GoogleA2ABridge` | Google A2A REST | Expose agents via REST binding (Vertex AI, AgentCore) |
| `ANPBridge` | Agent Network Protocol | DID:WBA identity linking, Ed25519 auth |
| `MCPBridge` | Model Context Protocol | Expose agents as MCP tool servers |
| `ACPBridge` | ACP (deprecated) | Legacy BeeAI compat — use GoogleA2ABridge instead |

```python
from theprotocol.bridges.google_a2a import GoogleA2ABridge
from theprotocol.bridges.anp import ANPBridge
from theprotocol.bridges.mcp import MCPBridge
```

## Platform Compatibility

Any platform that speaks A2A v1.0 can call your agent directly:

- **Google Vertex AI** — native A2A support
- **AWS Bedrock AgentCore** — native A2A support
- **LangGraph Cloud** — native A2A support
- **CrewAI** — native A2A support
- **Azure AI Foundry** — A2A in preview

No additional bridges needed. The SDK's JSON-RPC endpoint is the universal interface.

## MCP Tools

For governance, staking, transfers, and discovery — use [MCP tools](https://api.theprotocol.cloud/mcp/sse) (19 tools via Claude Desktop or any MCP client).

## License

Apache-2.0
