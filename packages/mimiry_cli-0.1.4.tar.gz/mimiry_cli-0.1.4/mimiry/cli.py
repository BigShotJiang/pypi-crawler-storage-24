"""Mimiry CLI — agent-friendly command-line interface for GPU cloud resources.

Usage:
    mimiry jobs list [--json]
    mimiry gpu list [--json]
    mimiry config set-key

Install:
    pip install mimiry[cli]
"""

import json
import sys
from typing import Optional

import typer

from .agent import AgentClient
from .client import MimiryClient
from .cli_config import get_api_key, set_api_key, set_default_provider, load_config, get_llm_config, set_llm_config, clear_llm_config
from .cli_formatters import (
    EXIT_OK,
    EXIT_USER_ERROR,
    EXIT_AUTH_ERROR,
    EXIT_CREDITS_ERROR,
    EXIT_NOT_FOUND,
    output_json,
    output_table,
    output_single,
    output_success,
    output_error,
    output_info,
)
from .exceptions import (
    MimiryError,
    AuthenticationError,
    InsufficientCreditsError,
    InsufficientScopeError,
    NotFoundError,
)

# ── App setup ─────────────────────────────────────────────────────

# Custom Click context settings with better color visibility
# Override the default dark blue with bright cyan for help text
CONTEXT_SETTINGS = {
    "help_option_names": ["--help", "-h"],
    "color": True,
}

app = typer.Typer(
    name="mimiry",
    help="Mimiry GPU Cloud CLI — manage instances, jobs, and resources.",
    no_args_is_help=True,
    pretty_exceptions_enable=False,
    rich_markup_mode="rich",
    context_settings=CONTEXT_SETTINGS,
)

jobs_app = typer.Typer(help="Manage batch jobs.", no_args_is_help=True, rich_markup_mode="rich")
gpu_app = typer.Typer(help="GPU instance types and availability.", no_args_is_help=True, rich_markup_mode="rich")
keys_app = typer.Typer(help="Manage SSH keys.", no_args_is_help=True, rich_markup_mode="rich")
registry_app = typer.Typer(help="Manage container registry credentials.", no_args_is_help=True, rich_markup_mode="rich")
config_app = typer.Typer(help="CLI configuration.", no_args_is_help=True, rich_markup_mode="rich")

app.add_typer(jobs_app, name="jobs")
app.add_typer(gpu_app, name="gpu")
app.add_typer(keys_app, name="keys")
app.add_typer(registry_app, name="registry")
app.add_typer(config_app, name="config")


# ── Helpers ───────────────────────────────────────────────────────

def _get_client(api_key: Optional[str] = None) -> MimiryClient:
    """Resolve API key and return a MimiryClient."""
    key = get_api_key(api_key)
    if not key:
        output_error(
            "No API key configured. Run 'mimiry config set-key' or set MIMIRY_API_KEY."
        )
        raise typer.Exit(EXIT_AUTH_ERROR)
    return MimiryClient(api_key=key)


def _handle_error(e: MimiryError) -> None:
    """Map SDK exceptions to exit codes."""
    if isinstance(e, AuthenticationError):
        output_error(f"Authentication failed: {e.message}")
        raise typer.Exit(EXIT_AUTH_ERROR)
    elif isinstance(e, InsufficientCreditsError):
        output_error(f"Insufficient credits: {e.message}")
        raise typer.Exit(EXIT_CREDITS_ERROR)
    elif isinstance(e, (InsufficientScopeError,)):
        output_error(f"Permission denied: {e.message}")
        raise typer.Exit(EXIT_AUTH_ERROR)
    elif isinstance(e, NotFoundError):
        output_error(f"Not found: {e.message}")
        raise typer.Exit(EXIT_NOT_FOUND)
    else:
        output_error(f"API error [{e.status_code}]: {e.message}")
        raise typer.Exit(EXIT_USER_ERROR)


# ── Config commands ───────────────────────────────────────────────

@config_app.command("set-key")
def config_set_key(
    api_key: str = typer.Option(
        ..., prompt="API key (mky_...)", hide_input=True,
        help="Your Mimiry API key.",
    ),
) -> None:
    """Store your API key in ~/.mimiry/config."""
    if not api_key.startswith("mky_"):
        output_error("API key must start with 'mky_'.")
        raise typer.Exit(EXIT_USER_ERROR)
    set_api_key(api_key)
    output_success("API key saved to ~/.mimiry/config")


@config_app.command("set-provider")
def config_set_provider(
    provider: str = typer.Argument(..., help="Default provider slug (e.g. verda, scaleway)."),
) -> None:
    """Set the default cloud provider."""
    set_default_provider(provider)
    output_success(f"Default provider set to '{provider}'.")


@config_app.command("show")
def config_show() -> None:
    """Show current configuration (key is masked)."""
    config = load_config()
    masked = config.copy()
    if "api_key" in masked:
        key = masked["api_key"]
        masked["api_key"] = key[:8] + "..." + key[-4:] if len(key) > 12 else "***"
    output_json(masked)


# ── Jobs commands ─────────────────────────────────────────────────

@jobs_app.command("list")
def jobs_list(
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY", help="API key override."),
) -> None:
    """List all batch jobs."""
    client = _get_client(api_key)
    try:
        data = client.list_jobs()
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_table(
            data,
            columns=[
                ("ID", "id"),
                ("Name", "name"),
                ("Status", "status"),
                ("Instance Type", "instance_type"),
                ("Location", "location"),
                ("Created", "created_at"),
            ],
            title="Batch Jobs",
        )


@jobs_app.command("get")
def jobs_get(
    job_id: str = typer.Argument(..., help="Job UUID."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """Get details of a specific job."""
    client = _get_client(api_key)
    try:
        data = client.get_job(job_id)
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_single(
            data,
            fields=[
                ("ID", "id"),
                ("Name", "name"),
                ("Status", "status"),
                ("Instance Type", "instance_type"),
                ("Location", "location"),
                ("Provider", "provider"),
                ("Created", "created_at"),
                ("Started", "started_at"),
                ("Completed", "completed_at"),
                ("Error", "error_message"),
            ],
            title="Job Details",
        )


@jobs_app.command("submit")
def jobs_submit(
    name: str = typer.Option(..., help="Job name."),
    instance_type: str = typer.Option(..., help="GPU instance type (e.g. 1V100.6V)."),
    image: str = typer.Option(..., help="OS image (e.g. ubuntu-22.04-cuda-12.0)."),
    location: str = typer.Option(..., help="Datacenter code (e.g. FIN-01)."),
    ssh_key_ids: str = typer.Option(..., help="Comma-separated SSH key UUIDs."),
    startup_script: str = typer.Option("", help="Bash startup script."),
    provider: str = typer.Option("verda", help="Cloud provider slug."),
    auto_shutdown: bool = typer.Option(True, help="Terminate when script finishes."),
    heartbeat_timeout: int = typer.Option(600, help="Heartbeat timeout in seconds."),
    max_runtime: Optional[int] = typer.Option(None, help="Max runtime in seconds."),
    container_image: Optional[str] = typer.Option(None, help="Container image URI."),
    registry_credential_id: Optional[str] = typer.Option(None, help="Registry credential UUID."),
    from_json: Optional[str] = typer.Option(None, "--from-json", help="Read job spec from JSON file (use '-' for stdin)."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """Submit a new batch job."""
    client = _get_client(api_key)

    # Support --from-json for agent piping
    if from_json is not None:
        if from_json == "-":
            spec = json.load(sys.stdin)
        else:
            with open(from_json) as f:
                spec = json.load(f)
    else:
        key_list = [k.strip() for k in ssh_key_ids.split(",") if k.strip()]
        spec = {
            "name": name,
            "instance_type": instance_type,
            "image": image,
            "location": location,
            "ssh_key_ids": key_list,
            "startup_script": startup_script,
            "provider": provider,
            "auto_shutdown": auto_shutdown,
            "heartbeat_timeout_seconds": heartbeat_timeout,
        }
        if max_runtime is not None:
            spec["max_runtime_seconds"] = max_runtime
        if container_image is not None:
            spec["container_image"] = container_image
        if registry_credential_id is not None:
            spec["registry_credential_id"] = registry_credential_id

    if not yes:
        output_info(f"Submitting job '{spec.get('name', 'unnamed')}' on {spec.get('instance_type')} at {spec.get('location')}...")
        if not typer.confirm("Proceed?"):
            output_info("Cancelled.")
            raise typer.Exit(EXIT_OK)

    try:
        data = client.submit_job(**spec)
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_success(f"Job submitted: {data.get('id')} (status: {data.get('status')})")


@jobs_app.command("cancel")
def jobs_cancel(
    job_id: str = typer.Argument(..., help="Job UUID to cancel."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """Cancel a running or queued job."""
    client = _get_client(api_key)

    if not yes:
        if not typer.confirm(f"Cancel job {job_id}?"):
            output_info("Cancelled.")
            raise typer.Exit(EXIT_OK)

    try:
        data = client.cancel_job(job_id)
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_success(f"Job {job_id} cancelled.")


@jobs_app.command("wait")
def jobs_wait(
    job_id: str = typer.Argument(..., help="Job UUID to wait on."),
    poll_interval: float = typer.Option(10, help="Seconds between polls."),
    timeout: float = typer.Option(3600, help="Max wait time in seconds."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """Poll a job until it reaches a terminal status."""
    client = _get_client(api_key)
    output_info(f"Waiting for job {job_id}...")

    try:
        data = client.wait_for_job(job_id, poll_interval=poll_interval, timeout=timeout)
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        status = data.get("status", "unknown")
        output_success(f"Job {job_id} finished with status: {status}")


# ── GPU commands ──────────────────────────────────────────────────

@gpu_app.command("list")
def gpu_list(
    currency: str = typer.Option("eur", help="Price currency (eur, usd)."),
    provider: Optional[str] = typer.Option(None, help="Filter by provider slug."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """List available GPU instance types with pricing."""
    client = _get_client(api_key)
    try:
        data = client.list_instance_types(currency=currency, provider=provider)
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        symbol = {"eur": "€", "usd": "$"}.get(currency, currency.upper())
        for row in data:
            if "price_per_hour" in row:
                row["price_display"] = f"{symbol}{row['price_per_hour']}/hr"
        output_table(
            data,
            columns=[
                ("Instance Type", "instance_type"),
                ("Price", "price_display"),
                ("Provider", "provider"),
            ],
            title="GPU Instance Types",
        )


@gpu_app.command("available")
def gpu_available(
    instance_type: Optional[str] = typer.Argument(None, help="Specific instance type to check."),
    provider: Optional[str] = typer.Option(None, help="Filter by provider slug."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """Check real-time GPU availability."""
    client = _get_client(api_key)
    try:
        data = client.check_availability(instance_type=instance_type, provider=provider)
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        if isinstance(data, list):
            rows = []
            for item in data:
                if "availabilities" in item:
                    # Verda: grouped by location
                    for itype in item["availabilities"]:
                        rows.append({
                            "instance_type": itype,
                            "availability": "available",
                            "location": item.get("location_code", "—"),
                            "provider": item.get("provider", "—"),
                        })
                else:
                    # Scaleway: per instance type
                    rows.append({
                        "instance_type": item.get("instance_type", "—"),
                        "availability": item.get("availability", "—"),
                        "location": item.get("location_code", "—"),
                        "provider": item.get("provider", "—"),
                    })
            output_table(
                rows,
                columns=[
                    ("Instance Type", "instance_type"),
                    ("Availability", "availability"),
                    ("Location", "location"),
                    ("Provider", "provider"),
                ],
                title="GPU Availability",
            )
        else:
            output_json(data)


# ── Top-level resource commands ───────────────────────────────────

@app.command("locations")
def locations_list(
    provider: Optional[str] = typer.Option(None, help="Filter by provider slug."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """List available datacenter locations."""
    client = _get_client(api_key)
    try:
        data = client.list_locations(provider=provider)
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_table(
            data,
            columns=[
                ("Code", "code"),
                ("Name", "name"),
                ("Provider", "provider"),
            ],
            title="Locations",
        )


@app.command("images")
def images_list(
    instance_type: Optional[str] = typer.Option(None, help="Filter by compatible instance type."),
    provider: Optional[str] = typer.Option(None, help="Filter by provider slug."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """List available OS images."""
    client = _get_client(api_key)
    try:
        data = client.list_images(instance_type=instance_type, provider=provider)
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_table(
            data,
            columns=[
                ("Image", "code"),
                ("Name", "name"),
                ("Provider", "provider"),
            ],
            title="OS Images",
        )


@app.command("providers")
def providers_list(
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """List supported cloud providers."""
    client = _get_client(api_key)
    try:
        data = client.list_providers()
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_table(data, columns=[("Name", "name"), ("Slug", "slug")], title="Providers")


# ── SSH Keys commands ─────────────────────────────────────────────

@keys_app.command("list")
def keys_list(
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """List all SSH keys."""
    client = _get_client(api_key)
    try:
        data = client.list_ssh_keys()
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_table(
            data,
            columns=[("ID", "id"), ("Name", "name"), ("Created", "created_at")],
            title="SSH Keys",
        )


@keys_app.command("add")
def keys_add(
    name: str = typer.Argument(..., help="Key name."),
    public_key: str = typer.Argument(..., help="SSH public key string."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """Register a new SSH public key."""
    client = _get_client(api_key)
    try:
        data = client.add_ssh_key(name, public_key)
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_success(f"SSH key '{name}' added (id: {data.get('id')}).")


@keys_app.command("delete")
def keys_delete(
    key_id: str = typer.Argument(..., help="SSH key UUID."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """Delete an SSH key."""
    client = _get_client(api_key)

    if not yes:
        if not typer.confirm(f"Delete SSH key {key_id}?"):
            output_info("Cancelled.")
            raise typer.Exit(EXIT_OK)

    try:
        data = client.delete_ssh_key(key_id)
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_success(f"SSH key {key_id} deleted.")


# ── Registry commands ─────────────────────────────────────────────

@registry_app.command("list")
def registry_list(
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """List saved container registry credentials."""
    client = _get_client(api_key)
    try:
        data = client.list_registry_credentials()
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_table(
            data,
            columns=[
                ("ID", "id"),
                ("Name", "name"),
                ("Registry", "registry_url"),
                ("Type", "registry_type"),
                ("Default", "is_default"),
            ],
            title="Registry Credentials",
        )


@registry_app.command("add")
def registry_add(
    name: str = typer.Option(..., help="Credential name."),
    registry_url: str = typer.Option(..., help="Registry hostname (e.g. docker.io)."),
    username: str = typer.Option(..., help="Registry username."),
    password: str = typer.Option(..., prompt=True, hide_input=True, help="Registry password/token."),
    is_default: bool = typer.Option(False, help="Set as default credential."),
    registry_type: str = typer.Option("generic", help="Type: generic, aws_ecr, gcr, acr."),
    aws_region: Optional[str] = typer.Option(None, help="AWS region (for ECR) or Azure tenant ID (for ACR)."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """Save a new container registry credential."""
    client = _get_client(api_key)
    try:
        data = client.add_registry_credential(
            name=name,
            registry_url=registry_url,
            username=username,
            password=password,
            is_default=is_default,
            registry_type=registry_type,
            aws_region=aws_region,
        )
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_success(f"Registry credential '{name}' saved (id: {data.get('id')}).")


@registry_app.command("delete")
def registry_delete(
    credential_id: str = typer.Argument(..., help="Credential UUID."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """Delete a saved registry credential."""
    client = _get_client(api_key)

    if not yes:
        if not typer.confirm(f"Delete credential {credential_id}?"):
            output_info("Cancelled.")
            raise typer.Exit(EXIT_OK)

    try:
        data = client.delete_registry_credential(credential_id)
    except MimiryError as e:
        _handle_error(e)

    if json_output:
        output_json(data)
    else:
        output_success(f"Registry credential {credential_id} deleted.")


# ── AI Mode helpers ───────────────────────────────────────────────

def _get_agent(api_key: Optional[str] = None) -> AgentClient:
    """Resolve API key and return an AgentClient."""
    key = get_api_key(api_key)
    if not key:
        output_error(
            "No API key configured. Run 'mimiry config set-key' or set MIMIRY_API_KEY."
        )
        raise typer.Exit(EXIT_AUTH_ERROR)
    llm = get_llm_config()
    return AgentClient(api_key=key, **llm)


def _execute_action(action, client: MimiryClient, json_output: bool = False) -> None:
    """Execute an AgentAction via MimiryClient and display results."""
    tool = action.tool
    params = action.params

    # Map tool names to client methods
    TOOL_MAP = {
        "list_jobs": lambda: client.list_jobs(),
        "get_job": lambda: client.get_job(params["job_id"]),
        "submit_job": lambda: client.submit_job(**params),
        "cancel_job": lambda: client.cancel_job(params["job_id"]),
        "list_instance_types": lambda: client.list_instance_types(**params),
        "check_availability": lambda: client.check_availability(**params),
        "list_locations": lambda: client.list_locations(**params),
        "list_images": lambda: client.list_images(**params),
        "list_providers": lambda: client.list_providers(),
        "list_ssh_keys": lambda: client.list_ssh_keys(),
        "add_ssh_key": lambda: client.add_ssh_key(params["name"], params["public_key"]),
        "delete_ssh_key": lambda: client.delete_ssh_key(params["key_id"]),
        "list_registry_credentials": lambda: client.list_registry_credentials(),
        "add_registry_credential": lambda: client.add_registry_credential(**params),
        "delete_registry_credential": lambda: client.delete_registry_credential(params["credential_id"]),
    }

    if tool not in TOOL_MAP:
        output_error(f"Unknown tool: {tool}")
        return

    try:
        result = TOOL_MAP[tool]()
    except MimiryError as e:
        _handle_error(e)
        return

    if json_output:
        output_json({"tool": tool, "params": params, "result": result})
    else:
        if isinstance(result, list):
            output_json(result)
        elif isinstance(result, dict):
            output_json(result)
        else:
            print(result)


# ── AI Mode commands ──────────────────────────────────────────────

@app.command("ask")
def ask_command(
    prompt: str = typer.Argument(..., help="Natural language request."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation for mutating actions."),
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """Translate natural language into a Mimiry API action.

    Example: mimiry ask "what GPUs are available right now?"
    """
    agent = _get_agent(api_key)
    client = _get_client(api_key)

    try:
        action = agent.ask(prompt)
    except MimiryError as e:
        _handle_error(e)

    # Direct answer — no API call needed
    if action.is_direct_answer:
        if json_output:
            output_json({"tool": "answer_question", "answer": action.params.get("answer", "")})
        else:
            print(action.params.get("answer", ""))
        return

    # Show explanation
    if action.explanation and not json_output:
        output_info(action.explanation)

    # Confirm mutating actions
    if action.is_mutating and not yes:
        if not typer.confirm("Proceed?"):
            output_info("Cancelled.")
            raise typer.Exit(EXIT_OK)

    _execute_action(action, client, json_output)


@app.command("chat")
def chat_command(
    api_key: Optional[str] = typer.Option(None, "--api-key", envvar="MIMIRY_API_KEY"),
) -> None:
    """Interactive AI chat mode for managing GPU resources.

    Start a conversation with the Mimiry AI assistant. Type 'exit' or 'quit' to leave.
    """
    agent = _get_agent(api_key)
    client = _get_client(api_key)

    output_info("Mimiry AI (type 'exit' to quit)")
    print()

    try:
        while True:
            try:
                user_input = input(">>> ").strip()
            except EOFError:
                break

            if not user_input:
                continue
            if user_input.lower() in ("exit", "quit", "q"):
                break

            try:
                action = agent.ask(user_input, use_history=True)
            except MimiryError as e:
                output_error(str(e))
                continue

            # Direct answer
            if action.is_direct_answer:
                print(action.params.get("answer", ""))
                print()
                continue

            # Show explanation
            if action.explanation:
                output_info(action.explanation)

            # Confirm mutating actions
            if action.is_mutating:
                if not typer.confirm("Proceed?"):
                    output_info("Cancelled.")
                    print()
                    continue

            try:
                _execute_action(action, client)
            except SystemExit:
                pass  # _handle_error raises typer.Exit; catch it in chat mode

            print()

    except KeyboardInterrupt:
        pass

    print()
    output_info("Goodbye!")


# ── Config: LLM commands ─────────────────────────────────────────

@config_app.command("set-llm")
def config_set_llm(
    base_url: str = typer.Option(..., prompt="LLM endpoint URL", help="OpenAI-compatible endpoint."),
    llm_api_key: str = typer.Option(..., prompt="LLM API key", hide_input=True, help="API key for the endpoint."),
) -> None:
    """Configure a custom LLM endpoint for AI mode."""
    set_llm_config(base_url, llm_api_key)
    output_success(f"Custom LLM endpoint saved: {base_url}")


@config_app.command("clear-llm")
def config_clear_llm() -> None:
    """Remove custom LLM config and revert to Lovable AI Gateway."""
    clear_llm_config()
    output_success("Custom LLM config removed. Using Lovable AI Gateway.")


# ── Version ───────────────────────────────────────────────────────

@app.command("version")
def version() -> None:
    """Show the SDK and CLI version."""
    from . import __version__
    print(f"mimiry {__version__}")


# ── Entry point ───────────────────────────────────────────────────

def main() -> None:
    """CLI entry point."""
    app()


if __name__ == "__main__":
    main()
