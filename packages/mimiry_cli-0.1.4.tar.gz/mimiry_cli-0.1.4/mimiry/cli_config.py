"""Configuration management for the Mimiry CLI.

Stores API key and preferences in ~/.mimiry/config.
Priority: --api-key flag > MIMIRY_API_KEY env var > config file.
"""

import os
import json
from pathlib import Path
from typing import Optional


CONFIG_DIR = Path.home() / ".mimiry"
CONFIG_FILE = CONFIG_DIR / "config.json"


def _ensure_config_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    """Load config from disk. Returns empty dict if missing."""
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(config: dict) -> None:
    """Persist config to disk."""
    _ensure_config_dir()
    CONFIG_FILE.write_text(json.dumps(config, indent=2) + "\n")
    # Restrict permissions on config file (owner read/write only)
    try:
        CONFIG_FILE.chmod(0o600)
    except OSError:
        pass


def get_api_key(flag_value: Optional[str] = None) -> Optional[str]:
    """Resolve API key with priority: flag > env > config file.

    Args:
        flag_value: Value passed via --api-key CLI flag.

    Returns:
        API key string or None if not configured.
    """
    if flag_value:
        return flag_value
    env_key = os.environ.get("MIMIRY_API_KEY")
    if env_key:
        return env_key
    config = load_config()
    return config.get("api_key")


def set_api_key(api_key: str) -> None:
    """Store API key in the config file."""
    config = load_config()
    config["api_key"] = api_key
    save_config(config)


def get_default_provider() -> Optional[str]:
    """Get default provider from config, if set."""
    config = load_config()
    return config.get("default_provider")


def set_default_provider(provider: str) -> None:
    """Store default provider in config."""
    config = load_config()
    config["default_provider"] = provider
    save_config(config)


def get_default_output() -> str:
    """Get default output format. Returns 'table' or 'json'."""
    config = load_config()
    return config.get("default_output", "table")


def get_llm_config() -> dict:
    """Get custom LLM configuration, if set.

    Returns:
        Dict with optional 'llm_base_url' and 'llm_api_key' keys.
    """
    config = load_config()
    result = {}
    if config.get("llm_base_url"):
        result["llm_base_url"] = config["llm_base_url"]
    if config.get("llm_api_key"):
        result["llm_api_key"] = config["llm_api_key"]
    return result


def set_llm_config(base_url: str, api_key: str) -> None:
    """Store custom LLM endpoint configuration."""
    config = load_config()
    config["llm_base_url"] = base_url
    config["llm_api_key"] = api_key
    save_config(config)


def clear_llm_config() -> None:
    """Remove custom LLM configuration, reverting to Lovable AI Gateway."""
    config = load_config()
    config.pop("llm_base_url", None)
    config.pop("llm_api_key", None)
    save_config(config)
