"""Output formatters for the Mimiry CLI.

Handles dual-mode output: rich tables for humans, raw JSON for agents.
"""

import json
import sys
from typing import Any, Dict, List, Optional, Sequence

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    from rich.theme import Theme

    HAS_RICH = True
except ImportError:
    HAS_RICH = False

# Custom theme with better color visibility on dark terminals
# Override default styles to use brighter, more readable colors
custom_theme = Theme({
    "info": "cyan",
    "warning": "yellow",
    "error": "bold red",
    "success": "bold green",
    "option": "bright_cyan",  # For --help and other options
    "command": "bright_green",  # For command names
    "argument": "bright_yellow",  # For arguments
}) if HAS_RICH else None

console = Console(stderr=True, theme=custom_theme) if HAS_RICH else None
stdout_console = Console(theme=custom_theme) if HAS_RICH else None


# ── Exit codes ────────────────────────────────────────────────────

EXIT_OK = 0
EXIT_USER_ERROR = 1
EXIT_AUTH_ERROR = 2
EXIT_CREDITS_ERROR = 3
EXIT_NOT_FOUND = 4


def output_json(data: Any) -> None:
    """Print data as JSON to stdout."""
    print(json.dumps(data, indent=2, default=str))


def output_table(
    data: List[Dict],
    columns: Sequence[tuple],
    title: Optional[str] = None,
) -> None:
    """Render a rich table to stdout.

    Args:
        data: List of row dicts.
        columns: Sequence of (header, dict_key) or (header, dict_key, style).
        title: Optional table title.
    """
    if not HAS_RICH:
        # Fallback: print as JSON if rich not installed
        output_json(data)
        return

    table = Table(title=title, show_lines=False, pad_edge=True)
    for col in columns:
        header = col[0]
        style = col[2] if len(col) > 2 else None
        table.add_column(header, style=style)

    for row in data:
        values = []
        for col in columns:
            key = col[1]
            val = row.get(key, "—")
            values.append(str(val) if val is not None else "—")
        table.add_row(*values)

    if stdout_console:
        stdout_console.print(table)


def output_single(data: Dict, fields: Sequence[tuple], title: Optional[str] = None) -> None:
    """Render a single record as a key-value panel.

    Args:
        data: The record dict.
        fields: Sequence of (label, dict_key).
        title: Optional panel title.
    """
    if not HAS_RICH:
        output_json(data)
        return

    lines = []
    for label, key in fields:
        val = data.get(key, "—")
        lines.append(f"[bold]{label}:[/bold] {val}")

    if stdout_console:
        stdout_console.print(Panel("\n".join(lines), title=title or "Details"))


def output_success(message: str) -> None:
    """Print a success message to stderr."""
    if HAS_RICH and console:
        console.print(f"[green]✓[/green] {message}")
    else:
        print(f"✓ {message}", file=sys.stderr)


def output_error(message: str) -> None:
    """Print an error message to stderr."""
    if HAS_RICH and console:
        console.print(f"[red]✗[/red] {message}")
    else:
        print(f"✗ {message}", file=sys.stderr)


def output_warning(message: str) -> None:
    """Print a warning to stderr."""
    if HAS_RICH and console:
        console.print(f"[yellow]⚠[/yellow] {message}")
    else:
        print(f"⚠ {message}", file=sys.stderr)


def output_info(message: str) -> None:
    """Print info to stderr."""
    if HAS_RICH and console:
        console.print(f"[blue]ℹ[/blue] {message}")
    else:
        print(f"ℹ {message}", file=sys.stderr)
