"""Agent client for the Mimiry CLI AI mode.

Sends natural language to the cli-agent edge function, which returns
a structured tool call that the CLI executes locally.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import httpx

from .exceptions import MimiryError, raise_for_status

DEFAULT_AGENT_URL = "https://ypoycmbljujlkmjuhfif.supabase.co/functions/v1/cli-agent"

# Tools that mutate state — require user confirmation
MUTATING_TOOLS = frozenset({
    "submit_job",
    "cancel_job",
    "add_ssh_key",
    "delete_ssh_key",
    "add_registry_credential",
    "delete_registry_credential",
})


@dataclass
class AgentAction:
    """Structured action returned by the AI agent."""

    tool: str
    params: Dict[str, Any]
    explanation: str

    @property
    def is_mutating(self) -> bool:
        """Whether this action changes state and should require confirmation."""
        return self.tool in MUTATING_TOOLS

    @property
    def is_direct_answer(self) -> bool:
        """Whether this is a text answer with no API call needed."""
        return self.tool == "answer_question"


class AgentClient:
    """Client for the Mimiry CLI agent endpoint.

    Maintains in-memory conversation history for interactive sessions.

    Args:
        api_key: Mimiry API key (``mky_...``).
        agent_url: Override the agent endpoint URL.
        llm_base_url: Custom OpenAI-compatible LLM endpoint (optional).
        llm_api_key: API key for custom LLM endpoint (optional).
        timeout: Request timeout in seconds (default 60).
    """

    def __init__(
        self,
        api_key: str,
        agent_url: str = DEFAULT_AGENT_URL,
        llm_base_url: Optional[str] = None,
        llm_api_key: Optional[str] = None,
        timeout: float = 60.0,
    ):
        if not api_key:
            raise MimiryError("api_key is required")

        self._api_key = api_key
        self._agent_url = agent_url.rstrip("/")
        self._llm_base_url = llm_base_url
        self._llm_api_key = llm_api_key
        self._timeout = timeout
        self._history: List[Dict[str, str]] = []
        self._client = httpx.Client(timeout=self._timeout)

    def ask(self, message: str, use_history: bool = False) -> AgentAction:
        """Send a message to the agent and get a structured action back.

        Args:
            message: Natural language request.
            use_history: Whether to include conversation history (for chat mode).

        Returns:
            An ``AgentAction`` with tool name, parameters, and explanation.

        Raises:
            MimiryError: On API or agent errors.
        """
        payload: Dict[str, Any] = {"message": message}

        if use_history and self._history:
            payload["conversation_history"] = self._history

        # Pass custom LLM config if set
        if self._llm_base_url:
            payload["llm_base_url"] = self._llm_base_url
        if self._llm_api_key:
            payload["llm_api_key"] = self._llm_api_key

        response = self._client.post(
            self._agent_url,
            json=payload,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
        )

        body = response.json() if response.content else {}

        if response.status_code != 200:
            error_msg = body.get("error", f"Agent error (HTTP {response.status_code})")
            raise MimiryError(error_msg, status_code=response.status_code)

        action = AgentAction(
            tool=body.get("tool", "answer_question"),
            params=body.get("params", {}),
            explanation=body.get("explanation", ""),
        )

        # Update history for chat mode
        if use_history:
            self._history.append({"role": "user", "content": message})
            # Store the assistant's response as context
            if action.is_direct_answer:
                self._history.append({"role": "assistant", "content": action.explanation})
            else:
                summary = f"Called {action.tool}({action.params})"
                self._history.append({"role": "assistant", "content": summary})

        return action

    def clear_history(self) -> None:
        """Clear the in-memory conversation history."""
        self._history.clear()

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __repr__(self):
        return f"AgentClient(agent_url={self._agent_url!r})"
