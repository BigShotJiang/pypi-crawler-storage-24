from ultralytics import YOLO
import cv2
import numpy as np


class YoloSegmenter:

    def __init__(self, model_path):
        self.model = YOLO(model_path)
        self.names = self.model.names

    def segment(self, frame):

        results = self.model(frame)

        detections = []

        for r in results:

            boxes = r.boxes
            masks = r.masks

            if boxes is None:
                continue

            classes = boxes.cls
            confs = boxes.conf
            xyxy = boxes.xyxy

            if masks is not None:

                for mask, cls, conf in zip(masks.data, classes, confs):

                    label = self.names[int(cls)]

                    mask = mask.cpu().numpy()

                    mask = cv2.resize(mask, (frame.shape[1], frame.shape[0]))

                    mask = (mask > 0.5).astype("uint8") * 255

                    detections.append({
                        "label": label,
                        "confidence": float(conf),
                        "mask": mask
                    })

            else:

                for box, cls, conf in zip(xyxy, classes, confs):

                    label = self.names[int(cls)]

                    x1, y1, x2, y2 = box.cpu().numpy().astype(int)

                    mask = np.zeros(
                        (frame.shape[0], frame.shape[1]),
                        dtype="uint8"
                    )

                    cv2.rectangle(
                        mask,
                        (x1, y1),
                        (x2, y2),
                        255,
                        -1
                    )

                    detections.append({
                        "label": label,
                        "confidence": float(conf),
                        "mask": mask
                    })

        return detections