import cv2
import numpy as np


class SegmentationRenderer:

    COLOR_MAP = {
        "red": (0,0,255),
        "green": (0,255,0),
        "blue": (255,0,0),
        "yellow": (0,255,255),
        "cyan": (255,255,0),
        "magenta": (255,0,255),
        "white": (255,255,255),
        "black": (0,0,0),
        "orange": (0,165,255),
        "purple": (128,0,128),
        "pink": (203,192,255),

        "neon_pink": (147,20,255),
        "lime": (50,205,50),
        "teal": (128,128,0),
        "gold": (0,215,255),
        "navy": (128,0,0),
    }

    def _get_color(self, label, detect_object, detect_color):

        if not detect_object or not detect_color:
            return (0,255,0)

        for i, obj in enumerate(detect_object):

            if obj == label and i < len(detect_color):

                color = detect_color[i]

                if isinstance(color, tuple):
                    return color

                if isinstance(color, str):
                    return self.COLOR_MAP.get(color.lower(), (0,255,0))

        return (0,255,0)

    def draw(
        self,
        frame,
        detections,
        mode="contour",
        detect_object=None,
        detect_color=None,
        thickness=2,
        return_json=False,
        return_toon=False
    ):

        frame_h, frame_w = frame.shape[:2]

        results = []

        for det in detections:

            mask = det.get("mask")

            if mask is None:
                continue

            if mask.shape[:2] != (frame_h, frame_w):
                mask = cv2.resize(mask, (frame_w, frame_h))

            label = det.get("label", "")

            score = det.get("score", det.get("confidence", None))

            color = self._get_color(label, detect_object, detect_color)

            if mode == "box":

                x, y, w, h = cv2.boundingRect(mask)

                cv2.rectangle(
                    frame,
                    (x,y),
                    (x+w, y+h),
                    color,
                    thickness
                )

                cnts = [(x, y, w, h)]

            else:

                contours, _ = cv2.findContours(
                    mask,
                    cv2.RETR_EXTERNAL,
                    cv2.CHAIN_APPROX_SIMPLE
                )

                cnts = []

                for cnt in contours:

                    x, y, w, h = cv2.boundingRect(cnt)

                    cv2.drawContours(
                        frame,
                        [cnt],
                        -1,
                        color,
                        thickness
                    )

                    cnts.append((x, y, w, h))

            for x, y, w, h in cnts:

                text = label

                if score is not None:
                    text = f"{label} {score:.2f}"

                if text:

                    cv2.putText(
                        frame,
                        text,
                        (x, y-5),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,
                        color,
                        thickness
                    )

                if return_json or return_toon:

                    center_x = int(x + w/2)
                    center_y = int(y + h/2)

                    results.append({
                        "label": label,
                        "score": score,
                        "bbox": {
                            "x": int(x),
                            "y": int(y),
                            "width": int(w),
                            "height": int(h)
                        },
                        "center": {
                            "x": center_x,
                            "y": center_y
                        },
                        "area": int(w*h)
                    })

        json_output = None
        toon_output = None

        if return_json:

            json_output = {
                "frame_size": {
                    "width": frame_w,
                    "height": frame_h
                },
                "detections": results
            }

        if return_toon:

            lines = []

            lines.append(
                f"frame_width={frame_w} frame_height={frame_h}"
            )

            for det in results:

                line = (
                    f"label={det['label']} "
                    f"x={det['bbox']['x']} "
                    f"y={det['bbox']['y']} "
                    f"w={det['bbox']['width']} "
                    f"h={det['bbox']['height']} "
                    f"cx={det['center']['x']} "
                    f"cy={det['center']['y']} "
                    f"area={det['area']} "
                    f"score={det['score']}"
                )

                lines.append(line)

            toon_output = "\n".join(lines)

        if return_json and return_toon:
            return frame, json_output, toon_output

        if return_json:
            return frame, json_output

        if return_toon:
            return frame, toon_output

        return frame