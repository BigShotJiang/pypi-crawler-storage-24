"""
Kronvex Python SDK v0.3.0
Persistent memory layer for AI agents.
https://kronvex.io · https://api.kronvex.io/docs
"""

from kronvex.client import (
    Kronvex,
    Memory,
    RecallResult,
    RecallResponse,
    InjectContextResponse,
    KronvexError,
    AuthError,
    RateLimitError,
    NotFoundError,
)

try:
    from kronvex.async_client import AsyncKronvex
except ImportError:
    pass  # httpx not installed

__version__ = "0.3.0"
__all__ = [
    "Kronvex",
    "AsyncKronvex",
    "Memory",
    "RecallResult",
    "RecallResponse",
    "InjectContextResponse",
    "KronvexError",
    "AuthError",
    "RateLimitError",
    "NotFoundError",
]
