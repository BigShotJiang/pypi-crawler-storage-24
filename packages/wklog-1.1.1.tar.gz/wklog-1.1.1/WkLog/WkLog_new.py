# -*- coding: utf-8 -*-
# @Date     : 2026-03-15 13:33:41
# @Author   : WANGKANG
# @Blog     : https://wangkang1717.github.io
# @Email    : 1686617586@qq.com
# @Filepath : WkLog\WkLog_new.py
# @Brief    : 使用logging模块重构的WkLog，兼容loggin模块
# Copyright 2026 WANGKANG, All Rights Reserved.

import logging

from colorama import Fore, Style
from colorama import init as colorama_init

# 初始化 colorama
colorama_init(autoreset=True)


class WkColorFormatter(logging.Formatter):
    """
    一个高性能、非侵入式的彩色日志格式化器。
    完全兼容 Python 原生 logging 模块的所有特性（包括异常堆栈和多参数）。
    """

    LEVEL_COLORS = {
        logging.DEBUG: Fore.BLUE,
        logging.INFO: Fore.GREEN,
        logging.WARNING: Fore.YELLOW,
        logging.ERROR: Fore.RED,
        logging.CRITICAL: Fore.RED + Style.BRIGHT,
    }
    TIME_COLOR = Fore.CYAN

    def formatTime(self, record, datefmt=None):
        """重写时间格式化，单独为时间戳上色"""
        ret = super().formatTime(record, datefmt)
        return f"{self.TIME_COLOR}{ret}{Style.RESET_ALL}"

    def format(self, record):
        # 1. 备份原始属性，确保该 Handler 执行完后 record 状态可恢复
        orig_levelname = record.levelname
        orig_msg = record.msg
        orig_args = record.args

        # 2. 修改属性：为等级和消息正文加色
        level_color = self.LEVEL_COLORS.get(record.levelno, "")
        record.levelname = f"{level_color}{orig_levelname}{Style.RESET_ALL}"

        # 提前进行消息格式化（合并参数），并加色
        # 即使消息不是字符串，getMessage() 也能安全处理
        record.msg = f"{level_color}{record.getMessage()}{Style.RESET_ALL}"
        # 关键：清空 args，防止 super().format() 内部重复格式化导致报错
        record.args = []

        # 3. 调用父类方法：自动处理堆栈信息 (exc_info) 和 最终拼接
        result = super().format(record)

        # 4. 还原现场：彻底消除对其他 Handler 的影响
        record.levelname = orig_levelname
        record.msg = orig_msg
        record.args = orig_args

        # 关键：删除本次格式化产生的缓存。
        # 这样下一个 Handler 运行到此时，会重新生成不带颜色的内容。
        if hasattr(record, "message"):
            del record.message

        return result


log_format = "%(asctime)s | %(levelname)s | %(threadName)s(%(process)d) | %(filename)s:%(funcName)s:%(lineno)d | %(message)s"
date_format = "%Y-%m-%d %H:%M:%S"

logger = logging.getLogger("WkLog")
logger.setLevel(logging.DEBUG)

color_formatter = WkColorFormatter(fmt=log_format, datefmt=date_format)
console_handler = logging.StreamHandler()
console_handler.setFormatter(color_formatter)
logger.addHandler(console_handler)
