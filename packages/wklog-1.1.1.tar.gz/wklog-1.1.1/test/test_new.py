import logging
import os

from colorama import Fore, Style
from colorama import init as colorama_init

from WkLog import WkColorFormatter


def run_test():
    logger = logging.getLogger("WkTest")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()  # 清空已有的 handler 防止重复执行测试

    log_format = "%(asctime)s %(levelname)s --- [%(filename)s:%(funcName)s:%(lineno)d] %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"

    # 1. 控制台 Handler (开启颜色)
    console_handler = logging.StreamHandler()
    color_formatter = WkColorFormatter(fmt=log_format, datefmt=date_format)
    console_handler.setFormatter(color_formatter)
    logger.addHandler(console_handler)

    # 2. 文件 Handler (关闭颜色)
    log_file = "output.log"
    if os.path.exists(log_file):
        os.remove(log_file)
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter(fmt=log_format, datefmt=date_format))
    logger.addHandler(file_handler)

    # 输出日志
    print("--- 检查控制台输出 ---")
    logger.debug("这是蓝色调试信息")
    logger.info("这是绿色普通信息")
    logger.warning("这是黄色警告信息")
    logger.error("这是红色错误信息")
    logger.critical("这是红色错误信息")

    # 验证文件
    print("\n--- 检查文件内容 ---")
    with open(log_file, "r", encoding="utf-8") as f:
        content = f.read()
        if "\x1b[" in content:
            print("❌ 失败：文件中发现了颜色代码！")
        else:
            print("✅ 成功：文件中没有颜色代码。")
        print("文件预览：\n" + content)


def test_args():
    logger = logging.getLogger("CrashTest")
    logger.setLevel(logging.INFO)
    h = logging.StreamHandler()
    h.setFormatter(WkColorFormatter("%(message)s"))
    logger.addHandler(h)

    print("--- 准备测试带参数日志 ---")
    # 这种写法在 Python 日志中非常常见
    logger.info("你好 %s，欢迎回来", "张三")


# 1. 你原始的、带污染隐患的 Formatter
class PollutionFormatter(logging.Formatter):
    def format(self, record):
        orig_msg = record.msg
        # 这一步会间接调用 getMessage() 并创建 record.message
        record.msg = f"{Fore.GREEN}{record.getMessage()}{Style.RESET_ALL}"
        result = super().format(record)
        record.msg = orig_msg
        # 注意：这里故意【不删除】record.message 缓存
        return result


# 2. 一个模拟转发 Handler
class DataObserverHandler(logging.Handler):
    def emit(self, record):
        # 使用 getattr 安全获取，如果不存在说明没被生成，如果存在说明是上个 Handler 留下的
        msg_cache = getattr(record, 'message', '缓存不存在')
        print(f"--- 观察者 Handler 捕捉到的 message 缓存: {repr(msg_cache)}")


def prove_pollution():
    logger = logging.getLogger("Proof")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    # 确保彩色 Handler 先运行
    h1 = logging.StreamHandler()
    h1.setFormatter(PollutionFormatter("%(message)s"))
    logger.addHandler(h1)

    # 观察者 Handler 后运行
    h2 = DataObserverHandler()
    logger.addHandler(h2)

    print("开始发送日志...")
    logger.info("你好世界")


if __name__ == "__main__":
    run_test()
    test_args()
    prove_pollution()
