"""Sherpa Tabular formatter"""

__version__ = "0.6.7"
