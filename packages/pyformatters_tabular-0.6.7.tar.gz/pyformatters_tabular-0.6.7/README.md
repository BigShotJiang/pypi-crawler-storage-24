## Requirements

- Python 3.12+
- uv for package management
- Pydantic v2

## Installation
```
pip install uv
uv sync --extra test
```

## Publish the Python Package to PyPI
- Increment the version of your package in the `__init__.py` file:
```
"""Sherpa Tabular formatter"""

__version__ = 'x.y.z'
```
- Publish
```
uv build
uv publish
```

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
