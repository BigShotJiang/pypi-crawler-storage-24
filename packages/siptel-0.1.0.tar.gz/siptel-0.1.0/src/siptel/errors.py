"""HTTP and API errors raised by the SIPTEL SDK."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


class SiptelError(Exception):
    """Base class for SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: Any | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class AuthenticationError(SiptelError):
    """Invalid or missing API key (HTTP 401)."""


class InvalidRequestError(SiptelError):
    """Bad request / validation (HTTP 400)."""


class NotFoundError(SiptelError):
    """Resource not found (HTTP 404)."""


class PaymentRequiredError(SiptelError):
    """Insufficient balance (HTTP 402)."""


class RateLimitError(SiptelError):
    """Too many requests (HTTP 429)."""


class APIError(SiptelError):
    """Other non-success API responses (e.g. 5xx)."""


def _parse_error_detail(body: Any) -> tuple[str, str | None, str | None]:
    """Extract human message and optional code/param from JSON error body."""
    if not isinstance(body, Mapping):
        return (str(body), None, None)
    err = body.get("error")
    if isinstance(err, Mapping):
        code = err.get("code")
        msg = err.get("message") or str(body)
        param = err.get("param")
        c = str(code) if code is not None else None
        p = str(param) if param is not None else None
        return (str(msg), c, p)
    if body.get("status") == "error" and isinstance(body.get("message"), str):
        return (body["message"], None, None)
    return (str(body), None, None)


def raise_for_status(status_code: int, body: Any) -> None:
    """Raise a typed SiptelError for non-2xx responses when body is JSON or text."""
    if 200 <= status_code < 300:
        return

    msg, code, param = _parse_error_detail(body)
    if param:
        msg = f"{msg} (param: {param})"
    if code:
        msg = f"{msg} [code: {code}]"

    kwargs = {"status_code": status_code, "response_body": body}

    if status_code == 401:
        raise AuthenticationError(msg, **kwargs)
    if status_code == 400:
        raise InvalidRequestError(msg, **kwargs)
    if status_code == 402:
        raise PaymentRequiredError(msg, **kwargs)
    if status_code == 404:
        raise NotFoundError(msg, **kwargs)
    if status_code == 429:
        raise RateLimitError(msg, **kwargs)
    raise APIError(msg, **kwargs)
