"""Low-level HTTP transport (Telnyx-style: one session, Bearer auth, JSON)."""

from __future__ import annotations

import json
import os
from collections.abc import Mapping, MutableMapping
from typing import Any

import requests

from siptel.errors import raise_for_status

DEFAULT_BASE_URL = "https://api.siptel.ai"
DEFAULT_TIMEOUT = 30.0
DEFAULT_UA = "SiptelPythonSDK/0.1"


class HTTPClient:
    """Internal REST client; use :class:`siptel.Client` in application code."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        session: requests.Session | None = None,
        user_agent: str | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required (or set SIPTEL_API_KEY).")
        self._api_key = api_key
        self._base = base_url.rstrip("/")
        self._timeout = timeout
        self._session = session or requests.Session()
        self._user_agent = user_agent or os.environ.get("SIPTEL_USER_AGENT") or DEFAULT_UA

    def _headers(
        self,
        extra: Mapping[str, str] | None = None,
        idempotency_key: str | None = None,
    ) -> MutableMapping[str, str]:
        h: MutableMapping[str, str] = {
            "Authorization": f"Bearer {self._api_key}",
            "Accept": "application/json",
            "User-Agent": self._user_agent,
        }
        if extra:
            h.update(dict(extra))
        if idempotency_key:
            h["Idempotency-Key"] = idempotency_key
        return h

    def request(
        self,
        method: str,
        path: str,
        *,
        json_body: Any = None,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
        idempotency_key: str | None = None,
    ) -> Any:
        url = f"{self._base}{path}" if path.startswith("/") else f"{self._base}/{path}"
        kw: dict[str, Any] = {
            "method": method.upper(),
            "url": url,
            "headers": self._headers(headers, idempotency_key=idempotency_key),
            "timeout": self._timeout,
        }
        if params is not None:
            kw["params"] = dict(params)
        if json_body is not None:
            kw["json"] = json_body
            if "Content-Type" not in kw["headers"]:
                kw["headers"]["Content-Type"] = "application/json"

        resp = self._session.request(**kw)
        text = resp.text
        body: Any
        if text:
            try:
                body = json.loads(text)
            except json.JSONDecodeError:
                body = text
        else:
            body = None

        raise_for_status(resp.status_code, body)
        return body

    def get(
        self,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> Any:
        return self.request("GET", path, params=params, headers=headers)

    def post(
        self,
        path: str,
        *,
        json_body: Any = None,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
        idempotency_key: str | None = None,
    ) -> Any:
        return self.request(
            "POST",
            path,
            json_body=json_body,
            params=params,
            headers=headers,
            idempotency_key=idempotency_key,
        )

    def put(
        self,
        path: str,
        *,
        json_body: Any = None,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
        idempotency_key: str | None = None,
    ) -> Any:
        return self.request(
            "PUT",
            path,
            json_body=json_body,
            params=params,
            headers=headers,
            idempotency_key=idempotency_key,
        )

    def patch(
        self,
        path: str,
        *,
        json_body: Any = None,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> Any:
        return self.request("PATCH", path, json_body=json_body, params=params, headers=headers)

    def delete(
        self,
        path: str,
        *,
        json_body: Any = None,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> Any:
        return self.request("DELETE", path, json_body=json_body, params=params, headers=headers)
