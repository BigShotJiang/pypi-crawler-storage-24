"""Resource namespaces attached to :class:`siptel.Client`."""

from siptel.resources.agent import AgentResource
from siptel.resources.numbers import NumbersResource
from siptel.resources.sip import SipResource
from siptel.resources.sms import SmsResource
from siptel.resources.voice import VoiceApiResource

__all__ = [
    "AgentResource",
    "VoiceApiResource",
    "SipResource",
    "SmsResource",
    "NumbersResource",
]
