"""SMS send and SMS apps."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from siptel.http_client import HTTPClient


class SmsResource:
    """``client.sms`` — SMS sending and app listing."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def send(
        self,
        *,
        app_id: str,
        phone_number: str,
        sender_id: str,
        text: str,
        **extra: Any,
    ) -> Any:
        """POST ``/v1/sms/send``."""
        body: dict[str, Any] = {
            "app_id": app_id,
            "phone_number": phone_number,
            "sender_id": sender_id,
            "text": text,
        }
        body.update(extra)
        return self._http.post("/v1/sms/send", json_body=body)

    def send_raw(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/sms/send`` with a full body."""
        return self._http.post("/v1/sms/send", json_body=dict(body))

    def list_apps(self) -> Any:
        """GET ``/v1/sms/apps``."""
        return self._http.get("/v1/sms/apps")
