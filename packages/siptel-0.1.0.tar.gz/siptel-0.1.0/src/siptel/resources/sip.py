"""SIP users (trunks) API."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from siptel.http_client import HTTPClient


class SipResource:
    """``client.sip`` — SIP trunk / user management."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(self, body: Mapping[str, Any] | None = None) -> Any:
        """POST ``/v1/sip/users``."""
        return self._http.post("/v1/sip/users", json_body=dict(body) if body else {})

    def list(self) -> Any:
        """GET ``/v1/sip/users``."""
        return self._http.get("/v1/sip/users")

    def retrieve(self, device_id: str) -> Any:
        """GET ``/v1/sip/users/{device_id}``."""
        return self._http.get(f"/v1/sip/users/{device_id}")

    def update(self, device_id: str, body: Mapping[str, Any]) -> Any:
        """PATCH ``/v1/sip/users/{device_id}``."""
        return self._http.patch(f"/v1/sip/users/{device_id}", json_body=dict(body))

    def delete(self, device_id: str) -> Any:
        """DELETE ``/v1/sip/users/{device_id}``."""
        return self._http.delete(f"/v1/sip/users/{device_id}")
