"""AI Agent API: outbound agent calls, list agents, get agent."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from siptel.http_client import HTTPClient


class AgentResource:
    """``client.agent`` — AI agent calls and configuration."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create_call(
        self,
        *,
        phone_number: str,
        caller_id: str,
        voice: str,
        record: bool,
        voicemail_action: str,
        greeting_message: str,
        task_prompt: str,
        **extra: Any,
    ) -> Any:
        """
        POST ``/v1/agent/call`` — start an outbound call with an AI agent.

        Required parameters match the public API. Additional optional fields
        (``language``, ``max_duration``, ``webhook_url``, etc.) can be passed as
        keyword arguments.
        """
        body: dict[str, Any] = {
            "phone_number": phone_number,
            "caller_id": caller_id,
            "voice": voice,
            "record": record,
            "voicemail_action": voicemail_action,
            "greeting_message": greeting_message,
            "task_prompt": task_prompt,
        }
        body.update(extra)
        return self._http.post("/v1/agent/call", json_body=body)

    def create_call_raw(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/agent/call`` with a full JSON body mapping."""
        return self._http.post("/v1/agent/call", json_body=dict(body))

    def list_agents(self) -> Any:
        """GET ``/v1/agents`` — list AI agents for the account."""
        return self._http.get("/v1/agents")

    def retrieve(self, agent_id: str) -> Any:
        """GET ``/v1/agent/{agent_id}`` — get a single agent."""
        return self._http.get(f"/v1/agent/{agent_id}")
