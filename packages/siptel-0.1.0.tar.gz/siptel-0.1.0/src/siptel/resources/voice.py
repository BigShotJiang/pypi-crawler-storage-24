"""Voice API: programmable call control (play, gather, transfer, etc.)."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from siptel.http_client import HTTPClient


class VoiceApiResource:
    """``client.voice`` — Voice API (TwiML-like) operations."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create_call(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/voiceapi/call``."""
        return self._http.post("/v1/voiceapi/call", json_body=dict(body))

    def play_text(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/voiceapi/play-text``."""
        return self._http.post("/v1/voiceapi/play-text", json_body=dict(body))

    def play_audio(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/voiceapi/play-audio``."""
        return self._http.post("/v1/voiceapi/play-audio", json_body=dict(body))

    def gather_text(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/voiceapi/gather-text``."""
        return self._http.post("/v1/voiceapi/gather-text", json_body=dict(body))

    def gather_audio(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/voiceapi/gather-audio``."""
        return self._http.post("/v1/voiceapi/gather-audio", json_body=dict(body))

    def hold(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/voiceapi/hold``."""
        return self._http.post("/v1/voiceapi/hold", json_body=dict(body))

    def unhold(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/voiceapi/unhold``."""
        return self._http.post("/v1/voiceapi/unhold", json_body=dict(body))

    def transfer(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/voiceapi/transfer``."""
        return self._http.post("/v1/voiceapi/transfer", json_body=dict(body))

    def hangup(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/voiceapi/hangup``."""
        return self._http.post("/v1/voiceapi/hangup", json_body=dict(body))

    def retrieve_call(self, call_id: str) -> Any:
        """GET ``/v1/voiceapi/call/{call_id}``."""
        return self._http.get(f"/v1/voiceapi/call/{call_id}")

    def list_calls(
        self,
        *,
        limit: int | None = None,
        status: str | None = None,
    ) -> Any:
        """GET ``/v1/voiceapi/calls`` with optional ``limit`` and ``status`` filters."""
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if status is not None:
            params["status"] = status
        return self._http.get("/v1/voiceapi/calls", params=params or None)
