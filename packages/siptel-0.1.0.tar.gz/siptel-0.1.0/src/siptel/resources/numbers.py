"""Phone numbers: list, search, purchase, assign."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from siptel.http_client import HTTPClient


class NumbersResource:
    """``client.numbers`` — DID inventory and purchasing."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self) -> Any:
        """GET ``/v1/numbers``."""
        return self._http.get("/v1/numbers")

    def retrieve(self, number_id: str) -> Any:
        """GET ``/v1/numbers/{number_id}``."""
        return self._http.get(f"/v1/numbers/{number_id}")

    def search(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/numbers/search``."""
        return self._http.post("/v1/numbers/search", json_body=dict(body))

    def purchase(self, body: Mapping[str, Any]) -> Any:
        """POST ``/v1/numbers/purchase``."""
        return self._http.post("/v1/numbers/purchase", json_body=dict(body))

    def assign(self, number_id: str, body: Mapping[str, Any]) -> Any:
        """PUT ``/v1/numbers/{number_id}/assign``."""
        return self._http.put(f"/v1/numbers/{number_id}/assign", json_body=dict(body))

    def release(self, number_id: str) -> Any:
        """DELETE ``/v1/numbers/{number_id}``."""
        return self._http.delete(f"/v1/numbers/{number_id}")
