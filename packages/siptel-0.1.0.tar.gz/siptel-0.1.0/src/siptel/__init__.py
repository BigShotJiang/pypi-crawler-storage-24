"""
SIPTEL Python SDK — REST API client for voice, AI agents, SMS, numbers, and SIP.

    from siptel import Client

    client = Client()  # uses SIPTEL_API_KEY
    print(client.agent.list_agents())

See https://siptel.ai/docs for HTTP reference.
"""

from __future__ import annotations

from siptel.client import Client
from siptel.errors import (
    APIError,
    AuthenticationError,
    InvalidRequestError,
    NotFoundError,
    PaymentRequiredError,
    RateLimitError,
    SiptelError,
)

__version__ = "0.1.0"

__all__ = [
    "Client",
    "__version__",
    "SiptelError",
    "AuthenticationError",
    "InvalidRequestError",
    "NotFoundError",
    "PaymentRequiredError",
    "RateLimitError",
    "APIError",
]
