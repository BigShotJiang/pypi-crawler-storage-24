"""Main SDK client (Telnyx-style: one entry point, resource namespaces)."""

from __future__ import annotations

import os
from collections.abc import Mapping
from typing import Any

import requests

from siptel.http_client import DEFAULT_BASE_URL, DEFAULT_TIMEOUT, HTTPClient
from siptel.resources import (
    AgentResource,
    NumbersResource,
    SipResource,
    SmsResource,
    VoiceApiResource,
)


class Client:
    """
    SIPTEL API client.

    Usage::

        from siptel import Client

        client = Client(api_key=\"sk_live_...\")
        # or: Client() with SIPTEL_API_KEY set in the environment

        agents = client.agent.list_agents()
        client.voice.retrieve_call(\"CA...\")
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        session: requests.Session | None = None,
        user_agent: str | None = None,
    ) -> None:
        key = api_key or os.environ.get("SIPTEL_API_KEY")
        if not key:
            raise ValueError(
                "Pass api_key=... or set the SIPTEL_API_KEY environment variable.",
            )
        self._http = HTTPClient(
            key,
            base_url=base_url,
            timeout=timeout,
            session=session,
            user_agent=user_agent,
        )
        self.agent = AgentResource(self._http)
        self.voice = VoiceApiResource(self._http)
        self.sip = SipResource(self._http)
        self.sms = SmsResource(self._http)
        self.numbers = NumbersResource(self._http)

    @property
    def http(self) -> HTTPClient:
        """Low-level HTTP client (advanced use)."""
        return self._http

    def get(
        self,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> Any:
        """GET arbitrary path under the configured base URL (escape hatch)."""
        return self._http.get(path, params=params, headers=headers)

    def post(
        self,
        path: str,
        *,
        json: Mapping[str, Any] | None = None,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
        idempotency_key: str | None = None,
    ) -> Any:
        """POST arbitrary path (escape hatch for new or undocumented endpoints)."""
        return self._http.post(
            path,
            json_body=dict(json) if json is not None else None,
            params=params,
            headers=headers,
            idempotency_key=idempotency_key,
        )

    def put(
        self,
        path: str,
        *,
        json: Mapping[str, Any] | None = None,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
        idempotency_key: str | None = None,
    ) -> Any:
        return self._http.put(
            path,
            json_body=dict(json) if json is not None else None,
            params=params,
            headers=headers,
            idempotency_key=idempotency_key,
        )

    def patch(
        self,
        path: str,
        *,
        json: Mapping[str, Any] | None = None,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> Any:
        return self._http.patch(
            path,
            json_body=dict(json) if json is not None else None,
            params=params,
            headers=headers,
        )

    def delete(
        self,
        path: str,
        *,
        json: Mapping[str, Any] | None = None,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> Any:
        return self._http.delete(
            path,
            json_body=dict(json) if json is not None else None,
            params=params,
            headers=headers,
        )
