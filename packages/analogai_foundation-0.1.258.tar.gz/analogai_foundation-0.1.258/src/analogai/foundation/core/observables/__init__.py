__all__ = [
    "ObservableService",
    "StatementObservableService",
    "StatementObserver",
    "LearningObservableService",
    "LearningObserver",
    "NotionObservableService",
    "NotionObserver",
    "UserObservableService",
    "UserObserver",
    "Event",
    "StatementCreatedEvent",
    "StatementUpdatedEvent",
]


def __getattr__(name: str):
    if name == "ObservableService":
        from .observable_service import ObservableService
        return ObservableService
    if name in {"StatementObservableService", "StatementObserver"}:
        from .statement_observable_service import StatementObservableService, StatementObserver
        return StatementObservableService if name == "StatementObservableService" else StatementObserver
    if name in {"LearningObservableService", "LearningObserver"}:
        from .learning_observable_service import LearningObservableService, LearningObserver
        return LearningObservableService if name == "LearningObservableService" else LearningObserver
    if name in {"NotionObservableService", "NotionObserver"}:
        from .notion_observable_service import NotionObservableService, NotionObserver
        return NotionObservableService if name == "NotionObservableService" else NotionObserver
    if name in {"UserObservableService", "UserObserver"}:
        from .user_observable_service import UserObservableService, UserObserver
        return UserObservableService if name == "UserObservableService" else UserObserver
    if name == "Event":
        from .event import Event
        return Event
    if name == "StatementCreatedEvent":
        from .statement_created_event import StatementCreatedEvent
        return StatementCreatedEvent
    if name == "StatementUpdatedEvent":
        from .statement_updated_event import StatementUpdatedEvent
        return StatementUpdatedEvent
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")