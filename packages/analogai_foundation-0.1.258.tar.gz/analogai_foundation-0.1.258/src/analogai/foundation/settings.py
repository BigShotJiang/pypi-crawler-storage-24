from __future__ import annotations

import os
from importlib import resources

from dynaconf import Dynaconf

from analogai.foundation.common.utils.config_base import ConfigBase
from analogai.foundation.common.utils.env_utils import load_envs_in_order


load_envs_in_order()
if not os.getenv("ENVIRONMENT"):
    os.environ["ENVIRONMENT"] = "development"

_CONFIG_DIR = resources.files("analogai.foundation.config")
_DEFAULT_CONFIG = _CONFIG_DIR / "default.yaml"
_SCHEMA_CONFIG = _CONFIG_DIR / "schema.yaml"


settings = Dynaconf(
    envvar_prefix=False,
    settings_files=[
        str(_DEFAULT_CONFIG),
    ],
    defaults={
        "ENVIRONMENT": "development",
    },
    environments=False,
    load_dotenv=True,
    validate_on_update=True,
)
config = ConfigBase(settings, schema_path=_SCHEMA_CONFIG)

__all__ = ["settings", "config"]
