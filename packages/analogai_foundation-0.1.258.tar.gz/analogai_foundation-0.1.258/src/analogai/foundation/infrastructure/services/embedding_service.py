from typing import List

from analogai.foundation.common.design_patterns.singleton import Singleton
from analogai.foundation.common.logging.app_logger import app_logger
from analogai.foundation.common.enums.embedding_provider import EmbeddingProvider as EmbeddingProviderEnum
from analogai.foundation.infrastructure.embeddings.base import EmbeddingProvider
from analogai.foundation.infrastructure.embeddings.provider_factory import create_embedding_provider
from analogai.foundation.settings import config

class EmbeddingService(metaclass=Singleton):
    def __init__(self):
        embedding_type = str(config.get("embed.type", "local")).strip().lower()
        embedding_provider = str(config.get("embed.provider", "local")).strip().lower()
        embedding_model = config.get("embed.model", "") or None

        if embedding_type == "local":
            provider_enum = EmbeddingProviderEnum.LOCAL
        else:
            try:
                provider_enum = EmbeddingProviderEnum(embedding_provider)
            except ValueError as exc:
                allowed = ", ".join([p.value for p in EmbeddingProviderEnum])
                raise ValueError(
                    f"Unknown EMBEDDING_PROVIDER value. Use one of: {allowed}."
                ) from exc

        self._provider = create_embedding_provider(provider_enum, model_name=embedding_model)
        app_logger.info(
            "EmbeddingService initialized with type='%s' provider='%s'",
            embedding_type,
            provider_enum.value,
        )

    @property
    def dimension(self) -> int:
        dimension = self._provider.dimension
        if dimension is None:
            raise RuntimeError("Embedding dimension unavailable from provider.")
        return dimension

    def encode(self, text: str) -> List[float]:
        return self._provider.encode(text)

    def encode_batch(self, texts: List[str]) -> List[List[float]]:
        return self._provider.encode_batch(texts)