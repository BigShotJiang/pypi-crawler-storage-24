from analogai.foundation.common.utils.lemmatization.lemmatizer import (
    lemmatize_text,
    is_likely_proper_noun,
)


__all__ = [
    "lemmatize_text",
    "is_likely_proper_noun",
]
