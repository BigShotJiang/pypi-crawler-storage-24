# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Update command implementation.

Updates an existing site with latest code changes:
- Git pull
- Pip install requirements
- Run migrations
- Collect static files
- Restart service
"""

from __future__ import annotations

import shlex
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from types import ModuleType

from sum.exceptions import SetupError
from sum.setup.database import DatabaseManager
from sum.setup.deps import DependencyManager
from sum.setup.infrastructure import (
    build_runtime_version_vars,
    fix_site_ownership,
    render_env_with_updates,
    sync_runtime_version_env,
)
from sum.setup.venv import VenvManager
from sum.system_config import ConfigurationError, SystemConfig, get_system_config
from sum.utils.django import DjangoCommandExecutor
from sum.utils.environment import ExecutionMode
from sum.utils.output import OutputFormatter
from sum.utils.preflight import (
    PostgresClusterCheck,
    PreflightRunner,
    SiteExistsCheck,
    SSHConnectivityCheck,
    SystemConfigCheck,
)
from sum.utils.privilege import require_root_or_escalate
from sum.utils.validation import validate_site_slug

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _as_remote_user(command: str, user: str) -> str:
    quoted_command = shlex.quote(command)
    quoted_user = shlex.quote(user)
    return f"sudo -u {quoted_user} -- sh -lc {quoted_command}"


def _run_git_pull(app_dir: Path, config: SystemConfig) -> None:
    """Pull latest changes from git remote.

    Runs git as the deploy user to handle safe.directory permissions.
    """
    deploy_user = config.defaults.deploy_user
    try:
        result = subprocess.run(
            ["sudo", "-u", deploy_user, "git", "pull", "--ff-only"],
            cwd=app_dir,
            check=True,
            capture_output=True,
            text=True,
        )
        if result.stdout:
            OutputFormatter.info(result.stdout.strip())
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Git pull failed: {exc.stderr}") from exc


def _restart_service(site_slug: str, config: SystemConfig) -> None:
    """Restart the gunicorn service, and the celery worker if it is active."""
    service_name = config.get_systemd_service_name(site_slug)
    try:
        subprocess.run(
            ["systemctl", "restart", service_name],
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to restart service: {exc.stderr}") from exc

    celery_service_name = config.get_celery_service_name(site_slug)
    is_active = subprocess.run(
        ["systemctl", "is-active", "--quiet", celery_service_name],
        capture_output=True,
    )
    if is_active.returncode == 0:
        try:
            subprocess.run(
                ["systemctl", "restart", celery_service_name],
                check=True,
                capture_output=True,
                text=True,
            )
        except subprocess.CalledProcessError as exc:
            raise SetupError(f"Failed to restart celery service: {exc.stderr}") from exc


def _run_remote_update(
    site_slug: str,
    config: SystemConfig,
    skip_migrations: bool = False,
) -> None:
    """Run update on a remote (production) server via SSH."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    app_dir = site_dir / "app"

    # Verify remote site directory exists before running any commands
    try:
        result = subprocess.run(
            ["ssh", ssh_host, "test", "-d", str(app_dir)],
            capture_output=True,
            timeout=30,
        )
        if result.returncode != 0:
            raise SetupError(
                f"Site directory not found on production: {app_dir}\n"
                f"Has the site been promoted? Run: sum-platform promote {site_slug} --domain ..."
            )
    except subprocess.TimeoutExpired as exc:
        raise SetupError(f"Timeout checking production site: {ssh_host}") from exc
    venv_python = site_dir / "venv" / "bin" / "python"
    service_name = config.get_systemd_service_name(site_slug)
    celery_service_name = config.get_celery_service_name(site_slug)
    deploy_user = config.defaults.deploy_user

    # Quote paths for safe shell interpolation
    q_app_dir = shlex.quote(str(app_dir))
    q_venv_python = shlex.quote(str(venv_python))
    q_site_env = shlex.quote(str(site_dir / ".env"))
    q_app_env = shlex.quote(str(app_dir / ".env"))

    # Build remote commands
    commands = [
        _as_remote_user(f"cd {q_app_dir} && git pull --ff-only", deploy_user),
        _as_remote_user(
            f"{q_venv_python} -m pip install -r {q_app_dir}/requirements.txt -q",
            deploy_user,
        ),
    ]

    if not skip_migrations:
        commands.append(
            _as_remote_user(
                f"cd {q_app_dir} && {q_venv_python} manage.py migrate --noinput",
                deploy_user,
            )
        )

    commands.extend(
        [
            _as_remote_user(
                f"cd {q_app_dir} && {q_venv_python} manage.py collectstatic --noinput",
                deploy_user,
            ),
            f"sudo systemctl restart {service_name}",
            # Restart celery only when active; let an actual restart failure propagate.
            (
                f"if systemctl is-active --quiet {shlex.quote(celery_service_name)}; "
                f"then sudo systemctl restart {shlex.quote(celery_service_name)}; fi"
            ),
        ]
    )

    # Execute each command via SSH with timeout
    for cmd in commands:
        OutputFormatter.info(f"Running: {cmd[:60]}...")
        try:
            subprocess.run(
                ["ssh", ssh_host, cmd],
                check=True,
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout for long operations
            )
        except subprocess.TimeoutExpired as exc:
            raise SetupError(
                f"Remote command timed out after 5 minutes: {cmd[:60]}..."
            ) from exc
        except subprocess.CalledProcessError as exc:
            raise SetupError(f"Remote command failed: {exc.stderr}") from exc

    try:
        git_sha_result = subprocess.run(
            [
                "ssh",
                ssh_host,
                _as_remote_user(f"cd {q_app_dir} && git rev-parse HEAD", deploy_user),
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
        git_sha = git_sha_result.stdout.strip()
        if not git_sha:
            raise SetupError("Remote git SHA was empty after update")

        release_result = subprocess.run(
            [
                "ssh",
                ssh_host,
                _as_remote_user(
                    f"cd {q_app_dir} && git describe --tags --exact-match", deploy_user
                ),
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )
        release = (
            release_result.stdout.strip() if release_result.returncode == 0 else None
        )

        env_result = subprocess.run(
            ["ssh", ssh_host, _as_remote_user(f"cat {q_site_env}", deploy_user)],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
        rendered_env = render_env_with_updates(
            env_result.stdout,
            build_runtime_version_vars(
                git_sha,
                release=release,
                deployed_at=datetime.now(UTC),
            ),
        )

        subprocess.run(
            [
                "ssh",
                ssh_host,
                _as_remote_user(f"tee {q_site_env} > /dev/null", deploy_user),
            ],
            check=True,
            capture_output=True,
            text=True,
            input=rendered_env,
            timeout=60,
        )
        subprocess.run(
            [
                "ssh",
                ssh_host,
                _as_remote_user(
                    f"cp {q_site_env} {q_app_env} && chmod 600 {q_app_env}",
                    deploy_user,
                ),
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.TimeoutExpired as exc:
        raise SetupError("Remote runtime version metadata update timed out") from exc
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to refresh remote runtime version metadata: {exc.stderr}"
        ) from exc


def run_update(
    site_name: str,
    *,
    target: str = "staging",
    skip_migrations: bool = False,
    skip_preflight: bool = False,
) -> int:
    """Update an existing site with latest code.

    Args:
        site_name: Name/slug of the site to update.
        target: 'staging' or 'prod'.
        skip_migrations: Skip running database migrations.

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    try:
        validate_site_slug(site_name)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    if target == "staging":
        require_root_or_escalate("update")

    # Pre-flight checks (phase 1: config-independent)
    early_results: list = []
    if not skip_preflight:
        runner = PreflightRunner()
        runner.register(SystemConfigCheck())
        early_results = runner.run()
        if not PreflightRunner.is_go(early_results):
            print(PreflightRunner.format_results(early_results))
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1

    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Pre-flight checks (phase 2: config-dependent)
    if not skip_preflight:
        runner2 = PreflightRunner()
        if target == "prod":
            base_dir = str(config.production.base_dir)
        else:
            base_dir = str(config.staging.base_dir)
        runner2.register(SiteExistsCheck(site_name, base_dir=base_dir))
        if target == "staging":
            runner2.register(PostgresClusterCheck(site_name))
        if target == "prod":
            runner2.register(SSHConnectivityCheck(config.production.ssh_host))
        late_results = runner2.run()
        all_results = early_results + late_results
        print(PreflightRunner.format_results(all_results))
        if not PreflightRunner.is_go(late_results):
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1

    site_dir = config.get_site_dir(site_name, target=target)

    # For production, delegate to remote execution
    if target == "prod":
        OutputFormatter.header(f"Updating {site_name} on production")
        print()
        try:
            _run_remote_update(site_name, config, skip_migrations)
        except SetupError as exc:
            OutputFormatter.error(str(exc))
            return 1
        OutputFormatter.success(f"Site {site_name} updated on production")
        return 0

    # For staging, run locally
    app_dir = site_dir / "app"
    venv_path = site_dir / "venv"

    # Validate site exists
    if not site_dir.exists():
        OutputFormatter.error(f"Site not found: {site_dir}")
        return 1

    if not app_dir.exists():
        OutputFormatter.error(f"App directory not found: {app_dir}")
        return 1

    OutputFormatter.header(f"Updating {site_name} on staging")
    print()

    total_steps = 7 if not skip_migrations else 6
    current_step = 0

    try:
        # Step 1: Git pull
        current_step += 1
        OutputFormatter.progress(current_step, total_steps, "Pulling latest code", "⏳")
        _run_git_pull(app_dir, config)
        OutputFormatter.progress(current_step, total_steps, "Code updated", "✅")

        # Step 2: Install dependencies
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Installing dependencies", "⏳"
        )
        venv_manager = VenvManager(venv_path=venv_path)
        deps_manager = DependencyManager(venv_manager=venv_manager)
        deps_manager.install(app_dir)
        OutputFormatter.progress(
            current_step, total_steps, "Dependencies installed", "✅"
        )

        # Create Django executor
        django_executor = DjangoCommandExecutor(
            app_dir,
            ExecutionMode.STANDALONE,
            python_path=venv_manager.get_python_executable(app_dir),
        )

        # Step 3: Run migrations (optional)
        if not skip_migrations:
            current_step += 1
            OutputFormatter.progress(
                current_step, total_steps, "Running migrations", "⏳"
            )
            db_manager = DatabaseManager(django_executor)
            db_manager.migrate()
            OutputFormatter.progress(
                current_step, total_steps, "Migrations complete", "✅"
            )

        # Step 4: Collect static
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Collecting static files", "⏳"
        )
        django_executor.run_command(["collectstatic", "--noinput"])
        OutputFormatter.progress(
            current_step, total_steps, "Static files collected", "✅"
        )

        # Step 5: Refresh runtime version metadata
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Recording runtime version metadata", "⏳"
        )
        sync_runtime_version_env(site_dir, app_dir)
        OutputFormatter.progress(
            current_step, total_steps, "Runtime version metadata saved", "✅"
        )

        # Step 6: Restore deploy-user ownership after local root-run updates
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Restoring file ownership", "⏳"
        )
        fix_site_ownership(site_name, config)
        OutputFormatter.progress(current_step, total_steps, "Ownership restored", "✅")

        # Step 7: Restart service
        current_step += 1
        OutputFormatter.progress(current_step, total_steps, "Restarting service", "⏳")
        _restart_service(site_name, config)
        OutputFormatter.progress(current_step, total_steps, "Service restarted", "✅")

    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    print()
    OutputFormatter.success(f"Site {site_name} updated successfully")
    return 0


def _update_command(
    site_name: str,
    target: str,
    skip_migrations: bool,
    skip_preflight: bool = False,
) -> None:
    """Update an existing site."""
    result = run_update(
        site_name,
        target=target,
        skip_migrations=skip_migrations,
        skip_preflight=skip_preflight,
    )
    if result != 0:
        raise SystemExit(result)


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the update command")


if click is None:
    update = _missing_click
else:

    @click.command(name="update")
    @click.argument("site_name")
    @click.option(
        "--target",
        type=click.Choice(["staging", "prod"], case_sensitive=False),
        default="staging",
        show_default=True,
        help="Target environment to update.",
    )
    @click.option(
        "--skip-migrations",
        is_flag=True,
        help="Skip running database migrations.",
    )
    @click.pass_context
    def _click_update(
        ctx: click.Context,
        site_name: str,
        target: str,
        skip_migrations: bool,
    ) -> None:
        """Update an existing site with latest code.

        Pulls latest code from git, installs dependencies, runs migrations,
        collects static files, and restarts the service.

        \b
        Examples:
          sum-platform update acme
          sum-platform update acme --target prod
          sum-platform update acme --skip-migrations
        """
        _update_command(
            site_name,
            target=target,
            skip_migrations=skip_migrations,
            skip_preflight=(ctx.obj or {}).get("skip_preflight", False),
        )

    update = _click_update
