"""Tests for the update command — celery worker restart behaviour.

GH-1531: Verifies that production and staging updates restart the celery
worker service when it is active, and skip it gracefully when absent.
"""

from __future__ import annotations

import subprocess
from importlib import import_module
from unittest.mock import MagicMock, patch

import pytest
from sum.exceptions import SetupError
from sum.system_config import (
    AgencyConfig,
    DefaultsConfig,
    ProductionConfig,
    StagingConfig,
    SystemConfig,
    TemplatesConfig,
    reset_system_config,
)

update_module = import_module("sum.commands.update")


@pytest.fixture(autouse=True)
def reset_config():
    reset_system_config()
    yield
    reset_system_config()


@pytest.fixture
def base_config(tmp_path):
    """Minimal SystemConfig suitable for update tests."""
    return SystemConfig(
        agency=AgencyConfig(name="testco"),
        staging=StagingConfig(
            server="staging.example.com",
            domain_pattern="{slug}.staging.example.com",
            base_dir=str(tmp_path / "srv" / "sum"),
        ),
        production=ProductionConfig(
            server="prod.example.com",
            ssh_host="10.0.0.1",
            base_dir="/srv/sum",
        ),
        templates=TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/gunicorn.service",
            caddy="caddy/Caddyfile",
        ),
        defaults=DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        ),
    )


# ---------------------------------------------------------------------------
# Production update — _run_remote_update
# ---------------------------------------------------------------------------


class TestRemoteUpdateCeleryRestart:
    """GH-1531: celery worker is restarted on production update when active."""

    def test_celery_restart_command_included_in_remote_commands(self, base_config):
        """Production update command list includes a conditional celery restart."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append(cmd)
            r = MagicMock()
            r.returncode = 0
            r.stderr = ""
            r.stdout = ""
            if isinstance(cmd, list) and cmd[:2] == ["ssh", "10.0.0.1"]:
                remote_cmd = cmd[2]
                if "git rev-parse HEAD" in remote_cmd:
                    r.stdout = "abc123def4567890\n"
                elif "git describe --tags --exact-match" in remote_cmd:
                    r.returncode = 128
                    r.stderr = "fatal: no tag exactly matches"
                elif "cat " in remote_cmd and "/.env" in remote_cmd:
                    r.stdout = "DJANGO_SECRET_KEY='abc'\n"
            return r

        with patch("subprocess.run", side_effect=capture_run):
            update_module._run_remote_update("acme", base_config)

        # Flatten SSH command strings
        ssh_cmds = [
            " ".join(c) if isinstance(c, list) else str(c)
            for c in calls
            if isinstance(c, list) and c and c[0] == "ssh"
        ]

        celery_cmds = [c for c in ssh_cmds if "sum-acme-celery" in c]
        assert celery_cmds, "Expected a celery-related SSH command"

        # The command should be conditional (if is-active; then restart; fi)
        # so it skips when the service is absent/inactive but fails on real restart errors
        assert any("is-active" in c and "then" in c for c in celery_cmds), (
            "Celery restart must be conditional on is-active and use if/then/fi "
            "so actual restart failures still propagate"
        )

    def test_repo_mutating_commands_run_as_deploy_user(self, base_config):
        """Production update uses the configured deploy user for app-tree mutations."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append(cmd)
            r = MagicMock()
            r.returncode = 0
            r.stderr = ""
            r.stdout = ""
            if isinstance(cmd, list) and cmd[:2] == ["ssh", "10.0.0.1"]:
                remote_cmd = cmd[2]
                if "git rev-parse HEAD" in remote_cmd:
                    r.stdout = "abc123def4567890\n"
                elif "git describe --tags --exact-match" in remote_cmd:
                    r.returncode = 128
                    r.stderr = "fatal: no tag exactly matches"
                elif "cat " in remote_cmd and "/.env" in remote_cmd:
                    r.stdout = "DJANGO_SECRET_KEY='abc'\n"
            return r

        with patch("subprocess.run", side_effect=capture_run):
            update_module._run_remote_update("acme", base_config)

        ssh_cmds = [
            cmd[2]
            for cmd in calls
            if isinstance(cmd, list) and len(cmd) >= 3 and cmd[0] == "ssh"
        ]

        deploy_wrapped = [
            cmd
            for cmd in ssh_cmds
            if "sudo -u deploy -- sh -lc" in cmd
            and (
                "git pull --ff-only" in cmd
                or "pip install -r" in cmd
                or "manage.py migrate --noinput" in cmd
                or "manage.py collectstatic --noinput" in cmd
            )
        ]
        assert len(deploy_wrapped) == 4

    def test_remote_update_honors_custom_deploy_user(self, base_config):
        """Production update does not assume the SSH login user owns the repo."""
        base_config.defaults.deploy_user = "sumapp"
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append(cmd)
            r = MagicMock()
            r.returncode = 0
            r.stderr = ""
            r.stdout = ""
            if isinstance(cmd, list) and cmd[:2] == ["ssh", "10.0.0.1"]:
                remote_cmd = cmd[2]
                if "git rev-parse HEAD" in remote_cmd:
                    r.stdout = "abc123def4567890\n"
                elif "git describe --tags --exact-match" in remote_cmd:
                    r.returncode = 128
                    r.stderr = "fatal: no tag exactly matches"
                elif "cat " in remote_cmd and "/.env" in remote_cmd:
                    r.stdout = "DJANGO_SECRET_KEY='abc'\n"
            return r

        with patch("subprocess.run", side_effect=capture_run):
            update_module._run_remote_update("acme", base_config)

        ssh_cmds = [
            cmd[2]
            for cmd in calls
            if isinstance(cmd, list) and len(cmd) >= 3 and cmd[0] == "ssh"
        ]

        assert any(
            "sudo -u sumapp -- sh -lc" in cmd and "git pull --ff-only" in cmd
            for cmd in ssh_cmds
        )

    def test_remote_update_refreshes_runtime_version_metadata(self, base_config):
        """Production update stamps git/build metadata into site and app env files."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""

            if isinstance(cmd, list) and cmd[:2] == ["ssh", "10.0.0.1"]:
                remote_cmd = cmd[2]
                if "git rev-parse HEAD" in remote_cmd:
                    result.stdout = "abc123def4567890\n"
                elif "git describe --tags --exact-match" in remote_cmd:
                    result.returncode = 128
                    result.stderr = "fatal: no tag exactly matches"
                elif "cat /srv/sum/acme/.env" in remote_cmd:
                    result.stdout = "DJANGO_SECRET_KEY='abc'\n"
            return result

        with patch("subprocess.run", side_effect=capture_run):
            update_module._run_remote_update("acme", base_config)

        ssh_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list) and c["cmd"][:2] == ["ssh", "10.0.0.1"]
        ]
        assert any("git rev-parse HEAD" in c["cmd"][2] for c in ssh_calls)
        tee_calls = [
            c for c in ssh_calls if "tee /srv/sum/acme/.env > /dev/null" in c["cmd"][2]
        ]
        assert tee_calls, "Expected runtime metadata rewrite of site .env"
        rendered_env = tee_calls[0]["kwargs"]["input"]
        assert "GIT_SHA=abc123def4567890" in rendered_env
        assert "BUILD_ID=deploy-" in rendered_env
        assert any(
            "cp /srv/sum/acme/.env /srv/sum/acme/app/.env && chmod 600 /srv/sum/acme/app/.env"
            in c["cmd"][2]
            for c in ssh_calls
        )

    def test_remote_update_fails_when_runtime_version_metadata_missing(
        self, base_config
    ):
        """Production update fails if required /health/ metadata cannot be stamped."""

        def capture_run(cmd, *args, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            return result

        with (
            patch("subprocess.run", side_effect=capture_run),
            pytest.raises(SetupError, match="Remote git SHA was empty after update"),
        ):
            update_module._run_remote_update("acme", base_config)

    def test_celery_restart_uses_correct_service_name(self, base_config):
        """The celery service name follows sum-{slug}-celery convention."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append(cmd)
            r = MagicMock()
            r.returncode = 0
            r.stderr = ""
            r.stdout = ""
            if isinstance(cmd, list) and cmd[:2] == ["ssh", "10.0.0.1"]:
                remote_cmd = cmd[2]
                if "git rev-parse HEAD" in remote_cmd:
                    r.stdout = "abc123def4567890\n"
                elif "git describe --tags --exact-match" in remote_cmd:
                    r.returncode = 128
                    r.stderr = "fatal: no tag exactly matches"
                elif "cat " in remote_cmd and "/.env" in remote_cmd:
                    r.stdout = "DJANGO_SECRET_KEY='abc'\n"
            return r

        with patch("subprocess.run", side_effect=capture_run):
            update_module._run_remote_update("my-site", base_config)

        ssh_cmds = [
            " ".join(c) if isinstance(c, list) else str(c)
            for c in calls
            if isinstance(c, list) and c and c[0] == "ssh"
        ]
        celery_cmds = [c for c in ssh_cmds if "sum-my-site-celery" in c]
        assert celery_cmds, "Expected 'sum-my-site-celery' in remote commands"

    def test_gunicorn_restart_always_runs(self, base_config):
        """Gunicorn service is always restarted regardless of celery state."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append(cmd)
            r = MagicMock()
            r.returncode = 0
            r.stderr = ""
            r.stdout = ""
            if isinstance(cmd, list) and cmd[:2] == ["ssh", "10.0.0.1"]:
                remote_cmd = cmd[2]
                if "git rev-parse HEAD" in remote_cmd:
                    r.stdout = "abc123def4567890\n"
                elif "git describe --tags --exact-match" in remote_cmd:
                    r.returncode = 128
                    r.stderr = "fatal: no tag exactly matches"
                elif "cat " in remote_cmd and "/.env" in remote_cmd:
                    r.stdout = "DJANGO_SECRET_KEY='abc'\n"
            return r

        with patch("subprocess.run", side_effect=capture_run):
            update_module._run_remote_update("acme", base_config)

        ssh_cmds = [
            " ".join(c) if isinstance(c, list) else str(c)
            for c in calls
            if isinstance(c, list) and c and c[0] == "ssh"
        ]
        gunicorn_cmds = [
            c for c in ssh_cmds if "systemctl restart" in c and "sum-acme-gunicorn" in c
        ]
        assert gunicorn_cmds, "Expected unconditional gunicorn restart"
        # Gunicorn restart should NOT be conditional
        assert all(
            "is-active" not in c for c in gunicorn_cmds
        ), "Gunicorn restart must be unconditional"


# ---------------------------------------------------------------------------
# Staging update — _restart_service
# ---------------------------------------------------------------------------


class TestStagingRestartServiceCelery:
    """GH-1531: celery worker is restarted on staging when active, skipped when absent."""

    def test_celery_restarted_when_active(self, base_config):
        """_restart_service restarts celery when systemctl is-active returns 0."""
        restart_calls = []

        def mock_run(cmd, *args, **kwargs):
            r = MagicMock()
            r.returncode = 0
            r.stderr = b""
            r.stdout = b""
            if isinstance(cmd, list) and "is-active" in cmd:
                r.returncode = 0  # celery is active
            if isinstance(cmd, list) and "restart" in cmd:
                restart_calls.append(cmd)
            return r

        with patch("subprocess.run", side_effect=mock_run):
            update_module._restart_service("acme", base_config)

        restarted = [" ".join(c) for c in restart_calls]
        assert any(
            "sum-acme-celery" in s for s in restarted
        ), "Expected celery service to be restarted when active"

    def test_celery_skipped_when_not_active(self, base_config):
        """_restart_service skips celery restart when systemctl is-active returns non-zero."""
        restart_calls = []

        def mock_run(cmd, *args, **kwargs):
            r = MagicMock()
            r.returncode = 0
            r.stderr = b""
            r.stdout = b""
            if isinstance(cmd, list) and "is-active" in cmd:
                r.returncode = 3  # service not active / not found
            if isinstance(cmd, list) and "restart" in cmd:
                restart_calls.append(cmd)
            return r

        with patch("subprocess.run", side_effect=mock_run):
            update_module._restart_service("acme", base_config)

        # Only gunicorn should be restarted
        restarted = [" ".join(c) for c in restart_calls]
        assert any(
            "sum-acme-gunicorn" in s for s in restarted
        ), "Expected gunicorn to always be restarted"
        assert not any(
            "sum-acme-celery" in s for s in restarted
        ), "Celery must NOT be restarted when is-active returns non-zero"

    def test_gunicorn_always_restarted(self, base_config):
        """_restart_service always restarts gunicorn regardless of celery state."""
        restart_calls = []

        def mock_run(cmd, *args, **kwargs):
            r = MagicMock()
            r.returncode = 3  # everything inactive
            r.stderr = b""
            r.stdout = b""
            if isinstance(cmd, list) and "restart" in cmd:
                restart_calls.append(cmd)
                r.returncode = 0
            return r

        with patch("subprocess.run", side_effect=mock_run):
            update_module._restart_service("acme", base_config)

        restarted = [" ".join(c) for c in restart_calls]
        assert any("sum-acme-gunicorn" in s for s in restarted)

    def test_celery_restart_failure_raises_setup_error(self, base_config):
        """_restart_service raises SetupError if celery restart fails."""

        def mock_run(cmd, *args, **kwargs):
            r = MagicMock()
            r.returncode = 0
            r.stderr = b""
            r.stdout = b""
            if isinstance(cmd, list) and "is-active" in cmd:
                r.returncode = 0  # celery is active
            if isinstance(cmd, list) and "restart" in cmd and "celery" in " ".join(cmd):
                raise subprocess.CalledProcessError(1, cmd, stderr=b"failed")
            return r

        with (
            patch("subprocess.run", side_effect=mock_run),
            pytest.raises(SetupError, match="celery"),
        ):
            update_module._restart_service("acme", base_config)

    def test_celery_service_name_for_hyphenated_slug(self, base_config):
        """_restart_service uses correct service name for hyphenated slug."""
        restart_calls = []

        def mock_run(cmd, *args, **kwargs):
            r = MagicMock()
            r.returncode = 0
            r.stderr = b""
            r.stdout = b""
            if isinstance(cmd, list) and "is-active" in cmd:
                r.returncode = 0
            if isinstance(cmd, list) and "restart" in cmd:
                restart_calls.append(cmd)
            return r

        with patch("subprocess.run", side_effect=mock_run):
            update_module._restart_service("my-client-site", base_config)

        restarted = [" ".join(c) for c in restart_calls]
        assert any("sum-my-client-site-celery" in s for s in restarted)


class TestStagingUpdateOwnership:
    """Staging update restores deploy-user ownership after local mutations."""

    def test_staging_update_restores_ownership(self, base_config, monkeypatch):
        site_dir = base_config.get_site_dir("acme", target="staging")
        app_dir = site_dir / "app"
        venv_dir = site_dir / "venv"
        app_dir.mkdir(parents=True, exist_ok=True)
        venv_dir.mkdir(parents=True, exist_ok=True)

        monkeypatch.setattr(update_module, "get_system_config", lambda: base_config)
        monkeypatch.setattr(
            update_module, "require_root_or_escalate", lambda cmd, **kw: True
        )

        ownership_calls = []
        restart_calls = []

        class DummyExecutor:
            def run_command(self, command, env=None, check=True):
                return MagicMock(returncode=0, stdout="", stderr="")

        class DummyDbManager:
            def __init__(self, executor):
                self.executor = executor

            def migrate(self):
                return None

        with (
            patch.object(update_module, "_run_git_pull"),
            patch.object(update_module.DependencyManager, "install"),
            patch.object(
                update_module,
                "DjangoCommandExecutor",
                return_value=DummyExecutor(),
            ),
            patch.object(update_module, "DatabaseManager", DummyDbManager),
            patch.object(update_module, "sync_runtime_version_env"),
            patch.object(
                update_module,
                "fix_site_ownership",
                side_effect=lambda slug, config: ownership_calls.append((slug, config)),
            ),
            patch.object(
                update_module,
                "_restart_service",
                side_effect=lambda slug, config: restart_calls.append((slug, config)),
            ),
        ):
            result = update_module.run_update(
                "acme", target="staging", skip_preflight=True
            )

        assert result == 0
        assert ownership_calls == [("acme", base_config)]
        assert restart_calls == [("acme", base_config)]

    def test_staging_update_refreshes_runtime_version_metadata(
        self, base_config, monkeypatch
    ):
        site_dir = base_config.get_site_dir("acme", target="staging")
        app_dir = site_dir / "app"
        venv_dir = site_dir / "venv"
        app_dir.mkdir(parents=True, exist_ok=True)
        venv_dir.mkdir(parents=True, exist_ok=True)

        monkeypatch.setattr(update_module, "get_system_config", lambda: base_config)
        monkeypatch.setattr(
            update_module, "require_root_or_escalate", lambda cmd, **kw: True
        )

        version_calls = []

        class DummyExecutor:
            def run_command(self, command, env=None, check=True):
                return MagicMock(returncode=0, stdout="", stderr="")

        class DummyDbManager:
            def __init__(self, executor):
                self.executor = executor

            def migrate(self):
                return None

        with (
            patch.object(update_module, "_run_git_pull"),
            patch.object(update_module.DependencyManager, "install"),
            patch.object(
                update_module,
                "DjangoCommandExecutor",
                return_value=DummyExecutor(),
            ),
            patch.object(update_module, "DatabaseManager", DummyDbManager),
            patch.object(
                update_module,
                "sync_runtime_version_env",
                side_effect=lambda site_dir, app_dir: version_calls.append(
                    (site_dir, app_dir)
                ),
            ),
            patch.object(update_module, "fix_site_ownership"),
            patch.object(update_module, "_restart_service"),
        ):
            result = update_module.run_update(
                "acme", target="staging", skip_preflight=True
            )

        assert result == 0
        assert version_calls == [(site_dir, app_dir)]

    def test_staging_update_fails_when_runtime_version_metadata_missing(
        self, base_config, monkeypatch, capsys
    ):
        site_dir = base_config.get_site_dir("acme", target="staging")
        app_dir = site_dir / "app"
        venv_dir = site_dir / "venv"
        app_dir.mkdir(parents=True, exist_ok=True)
        venv_dir.mkdir(parents=True, exist_ok=True)

        monkeypatch.setattr(update_module, "get_system_config", lambda: base_config)
        monkeypatch.setattr(
            update_module, "require_root_or_escalate", lambda cmd, **kw: True
        )

        class DummyExecutor:
            def run_command(self, command, env=None, check=True):
                return MagicMock(returncode=0, stdout="", stderr="")

        class DummyDbManager:
            def __init__(self, executor):
                self.executor = executor

            def migrate(self):
                return None

        with (
            patch.object(update_module, "_run_git_pull"),
            patch.object(update_module.DependencyManager, "install"),
            patch.object(
                update_module,
                "DjangoCommandExecutor",
                return_value=DummyExecutor(),
            ),
            patch.object(update_module, "DatabaseManager", DummyDbManager),
            patch.object(
                update_module,
                "sync_runtime_version_env",
                side_effect=SetupError("Could not determine git SHA for staging app"),
            ),
            patch.object(update_module, "fix_site_ownership"),
            patch.object(update_module, "_restart_service"),
        ):
            result = update_module.run_update(
                "acme", target="staging", skip_preflight=True
            )

        assert result == 1
        captured = capsys.readouterr()
        assert "Could not determine git SHA for staging app" in captured.out
