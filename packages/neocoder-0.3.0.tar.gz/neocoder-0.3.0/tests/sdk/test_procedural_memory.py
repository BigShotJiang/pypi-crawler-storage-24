"""
Tests for Procedural Memory components.

Tests:
- Procedure creation and matching
- ProceduralMemory storage and retrieval
- ProcedureExtractor clustering and extraction
"""

import pytest

from neoCoder.sdk.memory.procedural import (
    Procedure,
    ProceduralMemory,
    ProceduralMemoryConfig,
    ProcedureExtractor,
)
from neoCoder.sdk.memory.episodic import Episode, EpisodicMemory


class TestProcedure:
    """Tests for Procedure dataclass."""

    def test_procedure_creation(self):
        """Test creating a procedure."""
        proc = Procedure(
            id="proc_test",
            name="add_api_endpoint",
            description="Add a new REST API endpoint",
            steps=[
                "Create serializer",
                "Create viewset",
                "Register in urls.py",
                "Add tests",
            ],
            tech_stack=["django", "python"],
            task_types=["coding"],
            trigger_keywords=["api", "endpoint", "rest"],
        )
        
        assert proc.id == "proc_test"
        assert len(proc.steps) == 4
        assert "django" in proc.tech_stack

    def test_procedure_to_dict_round_trip(self):
        """Test serialization/deserialization."""
        original = Procedure(
            id="proc_round",
            name="fix_test",
            description="Fix flaky test",
            steps=["Identify cause", "Mock dependencies", "Run tests"],
            tech_stack=["pytest"],
            conventions=["Use fixtures"],
        )
        
        data = original.to_dict()
        restored = Procedure.from_dict(data)
        
        assert restored.id == original.id
        assert restored.steps == original.steps
        assert restored.conventions == original.conventions

    def test_procedure_to_prompt_string(self):
        """Test formatting procedure for prompt."""
        proc = Procedure(
            id="proc_prompt",
            name="create_model",
            description="Create a Django model",
            steps=["Define fields", "Add Meta class", "Create migration"],
            conventions=["Use snake_case for field names"],
        )
        
        prompt_str = proc.to_prompt_string()
        
        assert "## Procedure: create_model" in prompt_str
        assert "Django model" in prompt_str
        assert "1. Define fields" in prompt_str
        assert "snake_case" in prompt_str

    def test_procedure_matches_task(self):
        """Test task matching scoring."""
        proc = Procedure(
            id="proc_match",
            name="add_endpoint",
            description="Add REST endpoint",
            steps=["..."],
            tech_stack=["django", "python"],
            task_types=["coding"],
            trigger_keywords=["api", "endpoint", "rest"],
        )
        
        # High match
        score1 = proc.matches_task(
            "Create a REST API endpoint for users",
            tech_hints=["django"]
        )
        assert score1 > 0.5
        
        # Low match
        score2 = proc.matches_task(
            "Fix database connection issue",
            tech_hints=["postgres"]
        )
        assert score2 < 0.3

    def test_procedure_matches_task_type(self):
        """Test task type matching."""
        proc = Procedure(
            id="proc_debug",
            name="fix_bug",
            description="Debug and fix issues",
            steps=["..."],
            task_types=["debug"],
            trigger_keywords=["fix", "bug"],
        )
        
        score = proc.matches_task("Fix the authentication bug")
        assert score > 0.3


class TestProceduralMemory:
    """Tests for ProceduralMemory."""

    def test_add_procedure(self):
        """Test adding procedures."""
        memory = ProceduralMemory()
        
        proc = Procedure(
            id="proc_1",
            name="test_proc",
            description="Test procedure",
            steps=["Step 1"],
        )
        
        memory.add_procedure(proc)
        
        assert len(memory.get_all_procedures()) == 1

    def test_max_procedures_limit(self):
        """Test max procedures limit."""
        config = ProceduralMemoryConfig(max_procedures=3)
        memory = ProceduralMemory(config=config)
        
        for i in range(5):
            memory.add_procedure(Procedure(
                id=f"proc_{i}",
                name=f"procedure_{i}",
                description=f"Procedure {i}",
                steps=["..."],
                success_rate=i * 0.2,  # Different success rates
            ))
        
        assert len(memory.get_all_procedures()) == 3

    def test_get_procedure_by_name(self):
        """Test getting procedure by name."""
        memory = ProceduralMemory()
        
        memory.add_procedure(Procedure(
            id="proc_find",
            name="find_me",
            description="Find this procedure",
            steps=["..."],
        ))
        
        found = memory.get_procedure_by_name("find_me")
        assert found is not None
        assert found.id == "proc_find"
        
        not_found = memory.get_procedure_by_name("nonexistent")
        assert not_found is None

    def test_retrieve_for_task(self):
        """Test retrieving procedures for task."""
        memory = ProceduralMemory()
        
        memory.add_procedure(Procedure(
            id="proc_api",
            name="create_api",
            description="Create API endpoint",
            steps=["..."],
            trigger_keywords=["api", "endpoint"],
            tech_stack=["django"],
        ))
        
        memory.add_procedure(Procedure(
            id="proc_test",
            name="write_tests",
            description="Write unit tests",
            steps=["..."],
            trigger_keywords=["test", "unittest"],
            tech_stack=["pytest"],
        ))
        
        results = memory.retrieve_for_task(
            "Create an API endpoint",
            tech_hints=["django"],
        )
        
        assert len(results) > 0
        assert results[0][0].name == "create_api"

    def test_record_outcome(self):
        """Test recording procedure outcome."""
        memory = ProceduralMemory()
        
        memory.add_procedure(Procedure(
            id="proc_outcome",
            name="test_outcome",
            description="Test outcome recording",
            steps=["..."],
            success_rate=1.0,
        ))
        
        # Record failure
        memory.record_outcome("proc_outcome", success=False)
        
        proc = memory.get_procedure_by_name("test_outcome")
        assert proc.success_rate < 1.0

    def test_serialize_deserialize(self):
        """Test memory serialization."""
        memory = ProceduralMemory()
        memory.add_procedure(Procedure(
            id="proc_ser",
            name="serialize_me",
            description="For serialization test",
            steps=["Step 1", "Step 2"],
        ))
        
        data = memory.to_dict()
        restored = ProceduralMemory.from_dict(data)
        
        assert len(restored.get_all_procedures()) == 1
        assert restored.get_all_procedures()[0].name == "serialize_me"


class TestProcedureExtractor:
    """Tests for ProcedureExtractor."""

    def test_find_episode_clusters(self):
        """Test finding clusters of similar episodes."""
        episodic = EpisodicMemory()
        procedural = ProceduralMemory()
        
        # Add similar episodes
        episodic.add_episode(Episode(
            id="ep_1",
            task_description="Create REST API endpoint for users",
            summary="Created users endpoint",
            outcome="success",
        ))
        episodic.add_episode(Episode(
            id="ep_2",
            task_description="Create REST API endpoint for products",
            summary="Created products endpoint",
            outcome="success",
        ))
        episodic.add_episode(Episode(
            id="ep_3",
            task_description="Create REST API endpoint for orders",
            summary="Created orders endpoint",
            outcome="success",
        ))
        
        # Add unrelated episode
        episodic.add_episode(Episode(
            id="ep_4",
            task_description="Fix database connection pooling",
            summary="Fixed pooling issue",
            outcome="success",
        ))
        
        extractor = ProcedureExtractor(episodic, procedural)
        clusters = extractor.find_episode_clusters(min_cluster_size=2)
        
        # Should find at least one cluster (the API endpoints)
        assert len(clusters) >= 1
        # The API cluster should have 3 episodes
        api_cluster = max(clusters, key=len)
        assert len(api_cluster) == 3

    def test_extract_with_mock_llm(self):
        """Test extraction with mocked LLM."""
        episodic = EpisodicMemory()
        procedural = ProceduralMemory()
        
        # Add similar episodes
        for i in range(3):
            episodic.add_episode(Episode(
                id=f"ep_{i}",
                task_description=f"Create Django model for {['User', 'Product', 'Order'][i]}",
                summary=f"Created model with fields",
                outcome="success",
                tags=["django", "python"],
            ))
        
        # Mock LLM extractor
        def mock_llm(prompt: str) -> str:
            return """
PROCEDURE_NAME: create_django_model
DESCRIPTION: Create a Django model with standard patterns
TECH_STACK: django, python
TASK_TYPES: coding
TRIGGER_KEYWORDS: model, django, create

STEPS:
1. Define model class inheriting from models.Model
2. Add fields with appropriate types
3. Add Meta class with ordering
4. Create and run migration

CONVENTIONS:
- Use snake_case for field names
- Add verbose_name to fields
"""
        
        procedural.set_llm_extractor(mock_llm)
        
        extractor = ProcedureExtractor(episodic, procedural)
        extracted = extractor.extract_all()
        
        assert len(extracted) >= 1
        proc = extracted[0]
        assert proc.name == "create_django_model"
        assert "django" in proc.tech_stack
        assert len(proc.steps) >= 3


class TestProcedureMerging:
    """Tests for procedure merging."""

    def test_merge_procedures_with_same_name(self):
        """Test that procedures with same name are merged."""
        memory = ProceduralMemory()
        
        # Add first procedure
        memory.add_procedure(Procedure(
            id="proc_1",
            name="common_procedure",
            description="First version",
            steps=["Step 1"],
            source_episodes=["ep_1"],
            trigger_keywords=["keyword1"],
        ))
        
        # Add second with same name
        memory.add_procedure(Procedure(
            id="proc_2",
            name="common_procedure",
            description="Second version",
            steps=["Step 1", "Step 2", "Step 3"],  # More steps
            source_episodes=["ep_2"],
            trigger_keywords=["keyword2"],
        ))
        
        # Should only have one procedure (merged)
        assert len(memory.get_all_procedures()) == 1
        
        proc = memory.get_procedure_by_name("common_procedure")
        # Should have longer steps list
        assert len(proc.steps) == 3
        # Should have both keywords
        assert "keyword1" in proc.trigger_keywords
        assert "keyword2" in proc.trigger_keywords
        # Should have both source episodes
        assert "ep_1" in proc.source_episodes
        assert "ep_2" in proc.source_episodes
