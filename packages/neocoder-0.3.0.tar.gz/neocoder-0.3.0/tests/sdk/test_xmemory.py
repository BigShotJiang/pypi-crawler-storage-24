"""
Tests for xMemory system.

Tests the hierarchical memory implementation:
- SemanticMemory (L2)
- ThemeManager (L3)
- Sparsity-Semantics scoring
- Top-down retrieval
- Consolidation pipeline
"""

import pytest
import numpy as np
from unittest.mock import Mock, MagicMock

from neoCoder.sdk.memory.xmemory import (
    # Semantic
    SemanticMemory,
    SemanticMemoryConfig,
    SemanticUnit,
    KnowledgeType,
    # Themes
    ThemeNode,
    ThemeManager,
    ThemeManagerConfig,
    # Retrieval
    HierarchicalRetriever,
    RetrieverConfig,
    RetrievalResult,
    # Consolidation
    ConsolidationEngine,
    ConsolidationConfig,
    # Scoring
    SparsitySemanticsScorer,
    ScoringConfig,
    # Integration
    XMemoryIntegration,
    XMemoryConfig,
    create_xmemory_integration,
)
from neoCoder.sdk.memory.episodic import Episode, EpisodicMemory


def make_embedding(dim: int = 1536, seed: int = 42) -> np.ndarray:
    """Generate a random embedding vector."""
    rng = np.random.RandomState(seed)
    vec = rng.randn(dim).astype(np.float32)
    return vec / np.linalg.norm(vec)


def make_similar_embedding(base: np.ndarray, noise: float = 0.1) -> np.ndarray:
    """Generate an embedding similar to base."""
    noise_vec = np.random.randn(len(base)).astype(np.float32) * noise
    result = base + noise_vec
    return result / np.linalg.norm(result)


class TestSemanticUnit:
    """Tests for SemanticUnit dataclass."""
    
    def test_create_unit(self):
        """Test creating a semantic unit."""
        unit = SemanticUnit(
            id="sem_001",
            content="Python uses indentation for code blocks",
            knowledge_type=KnowledgeType.FACTUAL,
        )
        
        assert unit.id == "sem_001"
        assert unit.knowledge_type == KnowledgeType.FACTUAL
        assert unit.embedding is None
        assert unit.theme_id is None
    
    def test_unit_serialization(self):
        """Test serialization round-trip."""
        embedding = make_embedding()
        
        unit = SemanticUnit(
            id="sem_002",
            content="Use pytest for testing",
            knowledge_type=KnowledgeType.PROCEDURAL,
            embedding=embedding,
            keywords=["pytest", "testing"],
        )
        
        data = unit.to_dict()
        restored = SemanticUnit.from_dict(data)
        
        assert restored.id == unit.id
        assert restored.content == unit.content
        assert restored.knowledge_type == unit.knowledge_type
        assert np.allclose(restored.embedding, unit.embedding)
        assert restored.keywords == unit.keywords
    
    def test_record_access(self):
        """Test access tracking."""
        unit = SemanticUnit(
            id="sem_003",
            content="Test content",
            knowledge_type=KnowledgeType.FACTUAL,
        )
        
        initial_count = unit.access_count
        unit.record_access()
        
        assert unit.access_count == initial_count + 1


class TestSemanticMemory:
    """Tests for SemanticMemory manager."""
    
    def test_add_unit(self):
        """Test adding semantic units."""
        config = SemanticMemoryConfig(max_units=100)
        memory = SemanticMemory(config)
        
        unit = SemanticUnit(
            id="sem_001",
            content="Test knowledge",
            knowledge_type=KnowledgeType.FACTUAL,
            embedding=make_embedding(seed=1),
        )
        
        result = memory.add_unit(unit)
        
        assert result is True
        assert memory.get_unit("sem_001") is not None
    
    def test_duplicate_detection(self):
        """Test that duplicates are rejected."""
        memory = SemanticMemory()
        embedding = make_embedding(seed=1)
        
        unit1 = SemanticUnit(
            id="sem_001",
            content="Test knowledge",
            knowledge_type=KnowledgeType.FACTUAL,
            embedding=embedding,
        )
        
        # Nearly identical
        unit2 = SemanticUnit(
            id="sem_002",
            content="Test knowledge slightly different",
            knowledge_type=KnowledgeType.FACTUAL,
            embedding=make_similar_embedding(embedding, noise=0.01),
        )
        
        memory.add_unit(unit1)
        result = memory.add_unit(unit2)
        
        # Should be rejected as duplicate
        assert result is False
    
    def test_search_by_embedding(self):
        """Test embedding-based search."""
        memory = SemanticMemory()
        
        # Add units with different embeddings
        base_emb = make_embedding(seed=10)
        
        for i in range(5):
            unit = SemanticUnit(
                id=f"sem_{i}",
                content=f"Knowledge {i}",
                knowledge_type=KnowledgeType.FACTUAL,
                embedding=make_embedding(seed=i * 100),
            )
            memory.add_unit(unit)
        
        # Add a very similar one
        similar = SemanticUnit(
            id="sem_similar",
            content="Similar knowledge",
            knowledge_type=KnowledgeType.FACTUAL,
            embedding=make_similar_embedding(base_emb, noise=0.05),
        )
        memory.add_unit(similar)
        
        # Search
        results = memory.search_by_embedding(base_emb, top_k=3)
        
        assert len(results) > 0
        # Similar should be in results
        ids = [u.id for u, _ in results]
        assert "sem_similar" in ids
    
    def test_compute_knn(self):
        """Test kNN computation."""
        memory = SemanticMemory()
        
        # Add units
        for i in range(10):
            unit = SemanticUnit(
                id=f"sem_{i}",
                content=f"Knowledge {i}",
                knowledge_type=KnowledgeType.FACTUAL,
                embedding=make_embedding(seed=i),
            )
            memory.add_unit(unit)
        
        memory.compute_knn(k=3)
        
        # Check that neighbors were computed
        unit = memory.get_unit("sem_0")
        assert len(unit.neighbor_ids) == 3
        assert len(unit.neighbor_sims) == 3


class TestThemeNode:
    """Tests for ThemeNode dataclass."""
    
    def test_create_theme(self):
        """Test creating a theme node."""
        theme = ThemeNode(
            id="theme_001",
            summary="Python best practices",
            semantic_ids=["sem_1", "sem_2"],
        )
        
        assert theme.id == "theme_001"
        assert theme.member_count == 2
    
    def test_add_remove_semantic(self):
        """Test adding and removing semantics."""
        theme = ThemeNode(
            id="theme_001",
            summary="Test theme",
        )
        
        theme.add_semantic("sem_1")
        assert "sem_1" in theme.semantic_ids
        
        theme.remove_semantic("sem_1")
        assert "sem_1" not in theme.semantic_ids
    
    def test_serialization(self):
        """Test serialization round-trip."""
        centroid = make_embedding()
        
        theme = ThemeNode(
            id="theme_001",
            summary="Test theme",
            semantic_ids=["sem_1", "sem_2"],
            centroid=centroid,
        )
        
        data = theme.to_dict()
        restored = ThemeNode.from_dict(data)
        
        assert restored.id == theme.id
        assert restored.semantic_ids == theme.semantic_ids
        assert np.allclose(restored.centroid, theme.centroid)


class TestThemeManager:
    """Tests for ThemeManager."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.semantic_memory = SemanticMemory()
        self.manager = ThemeManager(self.semantic_memory)
    
    def test_create_theme_for_semantic(self):
        """Test automatic theme creation."""
        # Add a semantic unit
        unit = SemanticUnit(
            id="sem_001",
            content="Test knowledge",
            knowledge_type=KnowledgeType.FACTUAL,
            embedding=make_embedding(seed=1),
        )
        self.semantic_memory.add_unit(unit)
        
        # Assimilate
        stats = self.manager.assimilate_semantics(["sem_001"])
        
        # Should create a new theme
        assert stats["created"] == 1
        
        # Unit should be assigned
        assert unit.theme_id is not None
    
    def test_attach_to_existing_theme(self):
        """Test attachment to existing theme."""
        base_emb = make_embedding(seed=1)
        
        # Use lower threshold for testing
        config = ThemeManagerConfig(attach_threshold=0.5, lenient_attach_floor=0.3)
        manager = ThemeManager(self.semantic_memory, config)
        
        # Add first unit and create theme
        unit1 = SemanticUnit(
            id="sem_001",
            content="First knowledge",
            knowledge_type=KnowledgeType.FACTUAL,
            embedding=base_emb,
        )
        self.semantic_memory.add_unit(unit1)
        manager.assimilate_semantics(["sem_001"])
        
        # Add very similar unit (low noise = high similarity)
        unit2 = SemanticUnit(
            id="sem_002",
            content="Similar knowledge",
            knowledge_type=KnowledgeType.FACTUAL,
            embedding=make_similar_embedding(base_emb, noise=0.05),
        )
        self.semantic_memory.add_unit(unit2)
        
        stats = manager.assimilate_semantics(["sem_002"])
        
        # Should attach to existing theme (or create if threshold not met)
        # The key is both are now organized
        assert stats["attached"] + stats["created"] == 1
        
        # Both should have themes assigned
        assert unit1.theme_id is not None
        assert unit2.theme_id is not None
    
    def test_split_oversized_theme(self):
        """Test splitting oversized themes."""
        config = ThemeManagerConfig(max_theme_size=3)
        manager = ThemeManager(self.semantic_memory, config)
        
        # Add many similar units to force oversized theme
        base_emb = make_embedding(seed=1)
        
        for i in range(5):
            unit = SemanticUnit(
                id=f"sem_{i}",
                content=f"Knowledge {i}",
                knowledge_type=KnowledgeType.FACTUAL,
                embedding=make_similar_embedding(base_emb, noise=0.1 * i),
            )
            self.semantic_memory.add_unit(unit)
        
        manager.assimilate_semantics([f"sem_{i}" for i in range(5)])
        
        # Accommodate should split
        stats = manager.accommodate()
        
        # Should have split
        assert stats["split"] >= 0  # May or may not split depending on cohesion


class TestSparsitySemanticsScorer:
    """Tests for scoring system."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.semantic_memory = SemanticMemory()
        self.scorer = SparsitySemanticsScorer(self.semantic_memory)
    
    def test_sparsity_score_balanced(self):
        """Test sparsity score for balanced partition."""
        # Create balanced themes
        themes = []
        for i in range(3):
            theme = ThemeNode(
                id=f"theme_{i}",
                summary=f"Theme {i}",
                semantic_ids=[f"sem_{i}_1", f"sem_{i}_2"],
                centroid=make_embedding(seed=i),
            )
            themes.append(theme)
        
        score = self.scorer.score_themes(themes)
        
        # Balanced themes should have good score
        assert score > 0
    
    def test_evaluate_merge(self):
        """Test merge evaluation."""
        # Create two similar themes
        base_emb = make_embedding(seed=1)
        
        theme1 = ThemeNode(
            id="theme_1",
            summary="Theme 1",
            semantic_ids=["sem_1"],
            centroid=base_emb,
        )
        
        theme2 = ThemeNode(
            id="theme_2",
            summary="Theme 2",
            semantic_ids=["sem_2"],
            centroid=make_similar_embedding(base_emb, noise=0.1),
        )
        
        # Add units
        for i in [1, 2]:
            unit = SemanticUnit(
                id=f"sem_{i}",
                content=f"Knowledge {i}",
                knowledge_type=KnowledgeType.FACTUAL,
                embedding=make_embedding(seed=i),
            )
            self.semantic_memory.add_unit(unit)
        
        result = self.scorer.evaluate_merge(theme1, theme2)
        
        assert "before" in result
        assert "after" in result
        assert "delta" in result


class TestHierarchicalRetriever:
    """Tests for hierarchical retriever."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.semantic_memory = SemanticMemory()
        self.theme_manager = ThemeManager(self.semantic_memory)
        self.retriever = HierarchicalRetriever(
            self.theme_manager,
            self.semantic_memory,
        )
        
        # Mock embedding function
        self.retriever.set_embedding_function(lambda x: make_embedding(seed=hash(x) % 1000))
    
    def test_retrieve_empty(self):
        """Test retrieval with empty memory."""
        result = self.retriever.retrieve("test query")
        
        assert len(result.themes) == 0
        assert len(result.semantics) == 0
    
    def test_retrieve_with_content(self):
        """Test retrieval with content."""
        # Populate memory
        for i in range(5):
            unit = SemanticUnit(
                id=f"sem_{i}",
                content=f"Knowledge about topic {i}",
                knowledge_type=KnowledgeType.FACTUAL,
                embedding=make_embedding(seed=i),
            )
            self.semantic_memory.add_unit(unit)
        
        self.theme_manager.assimilate_semantics([f"sem_{i}" for i in range(5)])
        
        result = self.retriever.retrieve("query about topics")
        
        # Should have some results
        assert isinstance(result, RetrievalResult)
        assert result.context  # Should have formatted context
    
    def test_quick_context(self):
        """Test quick context retrieval."""
        # Add a theme
        unit = SemanticUnit(
            id="sem_001",
            content="Python testing best practices",
            knowledge_type=KnowledgeType.FACTUAL,
            embedding=make_embedding(seed=1),
        )
        self.semantic_memory.add_unit(unit)
        self.theme_manager.assimilate_semantics(["sem_001"])
        
        context = self.retriever.get_quick_context("testing")
        
        # May or may not return context depending on similarity
        assert isinstance(context, str)


class TestConsolidationEngine:
    """Tests for consolidation engine."""
    
    def test_process_episode(self):
        """Test processing an episode."""
        engine = ConsolidationEngine()
        
        # Mock extraction function
        def mock_extract(content: str) -> list:
            return [
                {
                    "content": "Learned about testing",
                    "knowledge_type": "procedural",
                    "keywords": ["testing"],
                    "confidence": 0.9,
                }
            ]
        
        def mock_embed(text: str) -> np.ndarray:
            return make_embedding(seed=hash(text) % 1000)
        
        engine.set_extraction_function(mock_extract)
        engine.set_embedding_function(mock_embed)
        
        # Create episode
        episode = Episode(
            id="ep_001",
            task_description="Write tests",
            summary="Successfully wrote tests",
            outcome="success",
        )
        
        result = engine.process_episode(episode)
        
        assert result.success
        assert result.semantics_extracted >= 0
    
    def test_force_consolidation(self):
        """Test forced consolidation."""
        engine = ConsolidationEngine()
        
        def mock_embed(text: str) -> np.ndarray:
            return make_embedding(seed=hash(text) % 1000)
        
        engine.set_embedding_function(mock_embed)
        
        result = engine.force_consolidation()
        
        assert result.success


class TestXMemoryIntegration:
    """Tests for xMemory integration."""
    
    def test_create_integration(self):
        """Test creating integration."""
        integration = create_xmemory_integration()
        
        assert integration is not None
        assert integration.semantic_memory is not None
        assert integration.theme_manager is not None
    
    def test_add_knowledge(self):
        """Test manually adding knowledge."""
        integration = create_xmemory_integration()
        
        def mock_embed(text: str) -> np.ndarray:
            return make_embedding(seed=hash(text) % 1000)
        
        integration._embed_fn = mock_embed
        integration._consolidation.set_embedding_function(mock_embed)
        
        unit = integration.add_knowledge(
            content="Test knowledge",
            knowledge_type="factual",
            keywords=["test"],
        )
        
        assert unit is not None
        assert unit.content == "Test knowledge"
    
    def test_retrieve_context(self):
        """Test context retrieval."""
        integration = create_xmemory_integration()
        
        def mock_embed(text: str) -> np.ndarray:
            return make_embedding(seed=hash(text) % 1000)
        
        integration._embed_fn = mock_embed
        integration._consolidation.set_embedding_function(mock_embed)
        integration._retriever.set_embedding_function(mock_embed)
        
        # Add some knowledge
        integration.add_knowledge("Python testing best practices", "procedural")
        
        context = integration.retrieve_context("testing")
        
        assert isinstance(context, str)
    
    def test_serialization(self):
        """Test state serialization."""
        integration = create_xmemory_integration()
        
        def mock_embed(text: str) -> np.ndarray:
            return make_embedding(seed=hash(text) % 1000)
        
        integration._consolidation.set_embedding_function(mock_embed)
        
        # Add data
        integration.add_knowledge("Test knowledge", "factual")
        
        # Serialize
        data = integration.to_dict()
        
        assert "consolidation" in data
        
        # Restore
        restored = XMemoryIntegration.from_dict(data)
        
        assert restored is not None


class TestIntegrationWithEpisodic:
    """Test integration with existing episodic memory."""
    
    def test_migrate_episodes(self):
        """Test migrating existing episodes."""
        episodic = EpisodicMemory()
        
        # Add some episodes
        for i in range(3):
            episode = Episode(
                id=f"ep_{i}",
                task_description=f"Task {i}",
                summary=f"Completed task {i}",
                outcome="success",
            )
            episodic.add_episode(episode)
        
        integration = create_xmemory_integration(episodic_memory=episodic)
        
        def mock_embed(text: str) -> np.ndarray:
            return make_embedding(seed=hash(text) % 1000)
        
        def mock_extract(content: str) -> list:
            return [
                {
                    "content": f"Knowledge from: {content[:50]}",
                    "knowledge_type": "factual",
                    "keywords": ["test"],
                    "confidence": 0.8,
                }
            ]
        
        integration.configure_llm(
            llm_call=lambda x: "UNIT_1:\nCONTENT: Test\nTYPE: factual\nKEYWORDS: test\nCONFIDENCE: 0.9",
            embed_fn=mock_embed,
        )
        
        # Migrate
        stats = integration.migrate_from_episodic(
            episodic.get_all_episodes(),
            batch_size=2,
        )
        
        assert stats["processed"] > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
