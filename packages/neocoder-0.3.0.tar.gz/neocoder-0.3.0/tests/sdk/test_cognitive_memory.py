"""
Tests for Cognitive Memory components.

Tests:
- EpisodicMemory: episode storage and retrieval
- CognitiveMemoryManager: integration of all memory systems
- Memory consolidation flow
"""

import pytest
import time

from neoCoder.sdk.memory.episodic import (
    Episode,
    EpisodicMemory,
    EpisodicMemoryConfig,
)
from neoCoder.sdk.memory.cognitive import (
    CognitiveMemoryManager,
    CognitiveMemoryConfig,
    ConsolidationResult,
)
from neoCoder.sdk.memory.working import WorkingMemoryConfig


class TestEpisode:
    """Tests for Episode dataclass."""

    def test_episode_creation(self):
        """Test creating an episode."""
        episode = Episode(
            id="ep_test123",
            task_description="Fix bug in auth module",
            summary="Fixed authentication bypass vulnerability",
            outcome="success",
            files_touched=["auth/login.py", "auth/utils.py"],
            key_decisions=["Used bcrypt instead of md5"],
            tags=["debug", "security", "python"],
            task_type="debug",
            complexity=0.7,
        )
        
        assert episode.id == "ep_test123"
        assert episode.outcome == "success"
        assert len(episode.files_touched) == 2
        assert "security" in episode.tags

    def test_episode_to_dict_round_trip(self):
        """Test serialization/deserialization."""
        original = Episode(
            id="ep_round",
            task_description="Create API endpoint",
            summary="Created REST endpoint for users",
            outcome="success",
            files_touched=["api/users.py"],
            tags=["api", "rest"],
        )
        
        data = original.to_dict()
        restored = Episode.from_dict(data)
        
        assert restored.id == original.id
        assert restored.task_description == original.task_description
        assert restored.tags == original.tags

    def test_episode_to_context_string(self):
        """Test formatting episode for context injection."""
        episode = Episode(
            id="ep_ctx",
            task_description="Implement caching layer",
            summary="Added Redis caching for API responses",
            outcome="success",
            files_touched=["cache/redis.py", "api/middleware.py"],
            key_decisions=["Used Redis over Memcached for persistence"],
        )
        
        ctx_str = episode.to_context_string()
        
        assert "Implement caching" in ctx_str
        assert "Redis caching" in ctx_str
        assert "redis.py" in ctx_str


class TestEpisodicMemory:
    """Tests for EpisodicMemory."""

    def test_add_episode(self):
        """Test adding episodes to memory."""
        memory = EpisodicMemory()
        
        episode = Episode(
            id="ep_1",
            task_description="Write unit tests",
            summary="Added pytest tests for auth module",
            outcome="success",
        )
        
        memory.add_episode(episode)
        
        assert len(memory.get_all_episodes()) == 1

    def test_max_episodes_limit(self):
        """Test that memory respects max_episodes limit."""
        config = EpisodicMemoryConfig(max_episodes=3)
        memory = EpisodicMemory(config=config)
        
        for i in range(5):
            memory.add_episode(Episode(
                id=f"ep_{i}",
                task_description=f"Task {i}",
                summary=f"Summary {i}",
                outcome="success",
            ))
        
        episodes = memory.get_all_episodes()
        assert len(episodes) == 3
        assert episodes[0].id == "ep_2"

    def test_retrieve_similar_basic(self):
        """Test basic similarity retrieval."""
        memory = EpisodicMemory()
        
        memory.add_episode(Episode(
            id="ep_auth",
            task_description="Fix authentication bug in login",
            summary="Fixed JWT token validation",
            outcome="success",
            tags=["debug", "auth"],
        ))
        
        memory.add_episode(Episode(
            id="ep_db",
            task_description="Optimize database queries",
            summary="Added indexes to users table",
            outcome="success",
            tags=["database", "performance"],
        ))
        
        results = memory.retrieve_similar("fix login authentication issue")
        
        assert len(results) > 0
        assert results[0][0].id == "ep_auth"

    def test_retrieve_similar_no_matches(self):
        """Test retrieval with no matching episodes."""
        memory = EpisodicMemory()
        
        memory.add_episode(Episode(
            id="ep_1",
            task_description="Setup Docker container",
            summary="Created Dockerfile",
            outcome="success",
        ))
        
        results = memory.retrieve_similar("machine learning model training")
        
        assert len(results) == 0

    def test_format_for_context(self):
        """Test formatting multiple episodes for context."""
        memory = EpisodicMemory()
        
        memory.add_episode(Episode(
            id="ep_1",
            task_description="Fix bug A",
            summary="Fixed issue A",
            outcome="success",
        ))
        memory.add_episode(Episode(
            id="ep_2",
            task_description="Fix bug B",
            summary="Fixed issue B",
            outcome="success",
        ))
        
        episodes = memory.retrieve_similar("fix bug", min_similarity=0.0)
        context = memory.format_for_context(episodes)
        
        assert "[Relevant past tasks]" in context
        assert "Fix bug" in context

    def test_serialize_deserialize(self):
        """Test memory serialization."""
        memory = EpisodicMemory()
        memory.add_episode(Episode(
            id="ep_ser",
            task_description="Test serialization",
            summary="Works",
            outcome="success",
        ))
        
        data = memory.to_dict()
        restored = EpisodicMemory.from_dict(data)
        
        assert len(restored.get_all_episodes()) == 1
        assert restored.get_all_episodes()[0].id == "ep_ser"


class TestCognitiveMemoryManager:
    """Tests for CognitiveMemoryManager."""

    def test_initialization(self):
        """Test manager initialization."""
        manager = CognitiveMemoryManager()
        
        assert manager.working is not None
        assert manager.episodic is not None

    def test_initialization_with_config(self):
        """Test initialization with custom config."""
        config = CognitiveMemoryConfig(
            enable_episodic=True,
            enable_hierarchical=False,
            max_injected_episodes=5,
        )
        manager = CognitiveMemoryManager(config=config)
        
        assert manager.episodic is not None
        assert manager.hierarchical is None

    def test_start_task_no_episodes(self):
        """Test starting task with no prior episodes."""
        manager = CognitiveMemoryManager()
        
        context = manager.start_task("Create new feature")
        
        assert context is None

    def test_start_task_with_episodes(self):
        """Test starting task retrieves relevant episodes."""
        manager = CognitiveMemoryManager()
        
        manager.episodic.add_episode(Episode(
            id="ep_prior",
            task_description="Create REST API endpoint",
            summary="Created users endpoint with CRUD operations",
            outcome="success",
            tags=["api", "rest"],
        ))
        
        context = manager.start_task("Create REST API for orders")
        
        assert context is not None
        assert "REST API" in context or "endpoint" in context

    def test_complete_task_creates_episode(self):
        """Test completing task creates new episode."""
        manager = CognitiveMemoryManager()
        
        manager.start_task("Fix auth bug")
        
        result = manager.complete_task(
            success=True,
            output="Fixed the authentication bypass",
            artifacts={"files_written": ["auth.py"]},
            metrics={"task_type": "debug", "complexity": 0.5},
        )
        
        assert result.success
        assert result.episode_id is not None
        assert len(manager.episodic.get_all_episodes()) == 1

    def test_on_compression(self):
        """Test compression notification."""
        config = CognitiveMemoryConfig(
            consolidate_on_compression=True,
        )
        manager = CognitiveMemoryManager(config=config)
        
        manager.start_task("Long running task")
        manager.on_compression("Summary of conversation", 10)
        
        assert len(manager._compression_summaries) == 1

    def test_reset(self):
        """Test resetting memory."""
        manager = CognitiveMemoryManager()
        
        manager.start_task("Task 1")
        manager.working.add_user_message("test")
        
        manager.reset()
        
        assert manager.working.message_count == 0
        assert manager._current_task == ""

    def test_get_memory_stats(self):
        """Test getting memory statistics."""
        manager = CognitiveMemoryManager()
        
        manager.start_task("Test task")
        manager.working.add_user_message("Hello")
        
        stats = manager.get_memory_stats()
        
        assert "working" in stats
        assert stats["working"]["message_count"] == 1
        assert "episodic" in stats

    def test_export_import(self):
        """Test exporting and importing memory state."""
        manager = CognitiveMemoryManager()
        
        manager.start_task("Export test")
        manager.episodic.add_episode(Episode(
            id="ep_export",
            task_description="Test",
            summary="Test summary",
            outcome="success",
        ))
        
        data = manager.export_to_dict()
        
        restored = CognitiveMemoryManager.from_dict(data)
        
        assert len(restored.episodic.get_all_episodes()) == 1


class TestTagExtraction:
    """Tests for automatic tag extraction."""

    def test_extract_debug_tags(self):
        """Test extracting debug-related tags."""
        manager = CognitiveMemoryManager()
        
        tags = manager._extract_tags("Fix bug in authentication module")
        
        assert "debug" in tags

    def test_extract_tech_tags(self):
        """Test extracting technology tags."""
        manager = CognitiveMemoryManager()
        
        tags = manager._extract_tags("Create Python Flask API endpoint")
        
        assert "python" in tags or "flask" in tags

    def test_extract_multiple_tags(self):
        """Test extracting multiple tag types."""
        manager = CognitiveMemoryManager()
        
        tags = manager._extract_tags(
            "Debug database query in Django REST API"
        )
        
        assert len(tags) >= 2
