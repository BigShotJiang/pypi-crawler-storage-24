"""
Test HierarchicalMemory integration with NCAAgent.
"""

import os
import tempfile
import shutil
import pytest

from neoCoder.sdk.memory.hierarchical import HierarchicalMemory, HierarchicalMemoryConfig, MemoryScope
from neoCoder.nca.config import NCAConfig


class TestHierarchicalMemoryUnit:
    """Unit tests for HierarchicalMemory."""

    def test_create_and_store(self):
        """Test basic create and store operations."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = HierarchicalMemoryConfig(storage_dir=tmpdir, auto_persist=True)
            mem = HierarchicalMemory(config)

            entry_id = mem.create_entry("task_1", metadata={"type": "coding"})
            assert entry_id is not None
            assert "task_1" in entry_id

            mem.store("solution", "Use pytest fixtures")
            value = mem.retrieve("solution")
            assert value == "Use pytest fixtures"

    def test_persistence(self):
        """Test that memory persists across instances."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = HierarchicalMemoryConfig(storage_dir=tmpdir, auto_persist=True)
            
            mem1 = HierarchicalMemory(config)
            entry_id = mem1.create_entry("persistent_task")
            mem1.store("key1", "value1")
            
            mem2 = HierarchicalMemory(config)
            entries = mem2.get_all_entries()
            assert len(entries) >= 1
            assert any("persistent_task" in e["name"] for e in entries)

    def test_hierarchical_structure(self):
        """Test session/entry/runnable hierarchy."""
        mem = HierarchicalMemory()
        
        entry_id = mem.create_entry("main_task")
        runnable_id = mem.create_runnable(entry_id, "attempt_1")
        
        assert runnable_id is not None
        assert mem.get_context() == [entry_id, runnable_id]

    def test_tree_structure(self):
        """Test tree visualization."""
        mem = HierarchicalMemory()
        
        mem.create_entry("task_a")
        mem.store("result", "done")
        
        tree = mem.get_tree_structure()
        assert "root" in tree
        assert "task_a" in tree


class TestNCAConfigHierarchicalMemory:
    """Test NCAConfig hierarchical memory settings."""

    def test_default_enabled(self):
        """HierarchicalMemory should be enabled by default."""
        config = NCAConfig()
        assert config.enable_hierarchical_memory is True

    def test_custom_dir(self):
        """Test custom memory directory."""
        config = NCAConfig(
            hierarchical_memory_dir="/custom/path/memory"
        )
        assert config.hierarchical_memory_dir == "/custom/path/memory"

    def test_orchestrator_config_includes_hierarchical(self):
        """to_orchestrator_config should include hierarchical memory settings."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = NCAConfig(
                working_dir=tmpdir,
                enable_hierarchical_memory=True,
            )
            orch_config = config.to_orchestrator_config()
            
            assert orch_config.enable_hierarchical_memory is True
            assert orch_config.hierarchical_memory_config is not None
            assert tmpdir in orch_config.hierarchical_memory_config.storage_dir

    def test_disabled_hierarchical_memory(self):
        """Test disabling hierarchical memory."""
        config = NCAConfig(enable_hierarchical_memory=False)
        orch_config = config.to_orchestrator_config()
        
        assert orch_config.enable_hierarchical_memory is False
        assert orch_config.hierarchical_memory_config is None


class TestNoteTakerVsHierarchicalMemory:
    """
    Test that NoteTaker and HierarchicalMemory don't conflict.
    
    NoteTaker: Creates human-readable markdown notes from trajectories
    HierarchicalMemory: Structured key-value storage for runtime data
    """

    def test_different_storage_locations(self):
        """NoteTaker and HierarchicalMemory use different storage."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = NCAConfig(
                working_dir=tmpdir,
                enable_hierarchical_memory=True,
            )
            
            orch_config = config.to_orchestrator_config()
            
            notes_dir = os.path.join(tmpdir, ".neoCoder", "notes")
            memory_dir = orch_config.hierarchical_memory_config.storage_dir
            
            assert "notes" in notes_dir
            assert "memory" in memory_dir
            assert notes_dir != memory_dir

    def test_independent_operations(self):
        """Operations on one don't affect the other."""
        from neoCoder.sdk.memory.notes import NotesStorage, NotesConfig
        
        with tempfile.TemporaryDirectory() as tmpdir:
            notes_dir = os.path.join(tmpdir, "notes")
            memory_dir = os.path.join(tmpdir, "memory")
            
            notes = NotesStorage(NotesConfig(storage_dir=notes_dir))
            memory = HierarchicalMemory(HierarchicalMemoryConfig(storage_dir=memory_dir))
            
            note = notes.create_note(
                title="Test Note",
                content="Some content",
                category="test"
            )
            
            memory.create_entry("test_task")
            memory.store("key", "value")
            
            found_notes = notes.search_notes(query="Test")
            assert len(found_notes) == 1
            assert found_notes[0].metadata.id == note.metadata.id
            assert memory.retrieve("key") == "value"
            
            assert len(os.listdir(notes_dir)) >= 1
            assert os.path.exists(os.path.join(memory_dir, "memory.json"))


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
