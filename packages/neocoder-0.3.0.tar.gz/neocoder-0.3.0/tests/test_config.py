"""
Test Configuration for neoCoder SDK
=====================================

Provides consistent test configuration across all tests.
"""

import os
from typing import Dict, Any


def get_test_config() -> Dict[str, Any]:
    """
    Get test configuration with ZenMux settings.
    
    All sensitive values (API keys) must come from environment variables.
    
    Returns:
        Dictionary with test configuration
    """
    return {
        "api_key": os.getenv(
            "ZENMUX_API_KEY",
            "test-api-key-placeholder"
        ),
        "base_url": os.getenv(
            "ZENMUX_BASE_URL",
            "https://zenmux.ai/api/v1"
        ),
        "model": os.getenv(
            "ANTHROPIC_DEFAULT_SONNET_MODEL",
            "anthropic/claude-sonnet-4.5"
        ),
        "provider": "anthropic",
    }


def get_zenmux_client_config() -> Dict[str, Any]:
    """
    Get ZenMux client configuration for tests.
    
    Returns:
        Dictionary with ZenMux client configuration
    """
    config = get_test_config()
    return {
        "provider": config["provider"],
        "api_key": config["api_key"],
        "base_url": config["base_url"],
        "model": config["model"],
    }


def setup_test_env():
    """
    Setup test environment variables.
    
    Note: This function should be called explicitly in tests that need it.
    It is NOT auto-executed on module import to avoid interfering with
    other tests or configurations.
    """
    # Use ZenMux unified endpoint for all providers
    # API keys must be set via environment variables before running tests
    if not os.getenv("ZENMUX_API_KEY"):
        os.environ["ZENMUX_API_KEY"] = "test-api-key-placeholder"
    os.environ["ZENMUX_BASE_URL"] = "https://zenmux.ai/api/v1"
    
    # Legacy environment variables for backward compatibility
    if not os.getenv("ANTHROPIC_AUTH_TOKEN"):
        os.environ["ANTHROPIC_AUTH_TOKEN"] = os.environ.get("ZENMUX_API_KEY", "test-api-key-placeholder")
    os.environ["ANTHROPIC_BASE_URL"] = "https://zenmux.ai/api/v1"
    os.environ["ANTHROPIC_DEFAULT_SONNET_MODEL"] = "anthropic/claude-sonnet-4.5"
    os.environ["ANTHROPIC_DEFAULT_OPUS_MODEL"] = "anthropic/claude-sonnet-4.5"
    os.environ["ANTHROPIC_DEFAULT_HAIKU_MODEL"] = "anthropic/claude-sonnet-4.5"


# NOTE: setup_test_env() is NOT auto-executed on import.
# Tests that need this configuration should call it explicitly.
