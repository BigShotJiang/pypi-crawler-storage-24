"""
Test SessionContext functionality.
"""

import os
import tempfile
import pytest

from neoCoder.sdk.extensions.session_context import (
    SessionContext,
    TechStackContext,
    BrainstormingContext,
    PlanContext,
)


class TestSessionContext:
    """Test SessionContext dataclass."""

    def test_create_empty_context(self):
        """Create empty context."""
        ctx = SessionContext()
        assert ctx.task_description == ""
        assert ctx.tech_stack is not None
        assert ctx.brainstorming is None
        assert ctx.plan is None

    def test_to_markdown_empty(self):
        """Empty context should produce minimal markdown."""
        ctx = SessionContext()
        md = ctx.to_markdown()
        
        assert "# Session Context" in md
        assert "## Tech Stack" in md

    def test_to_markdown_with_task(self):
        """Context with task should include it."""
        ctx = SessionContext()
        ctx.task_description = "Implement user authentication"
        
        md = ctx.to_markdown()
        
        assert "## Current Task" in md
        assert "Implement user authentication" in md

    def test_to_markdown_with_tech_stack(self):
        """Context with tech stack should format it."""
        ctx = SessionContext()
        ctx.update_tech_stack(
            technologies=[
                {"name": "Python", "version": "3.11", "practices": ["Use type hints"]},
            ],
            raw_discovery=["pytest", "ruff"],
        )
        
        md = ctx.to_markdown()
        
        assert "### Technologies" in md
        assert "**Python (3.11)**" in md
        assert "Use type hints" in md
        assert "### Auto-Detected" in md
        assert "pytest" in md

    def test_to_markdown_with_plan(self):
        """Context with plan should show progress."""
        ctx = SessionContext()
        ctx.update_plan(
            goal="Build API",
            steps=[
                {"step": 1, "description": "Create models", "completed": True, "notes": "Done"},
                {"step": 2, "description": "Add routes", "completed": False, "notes": ""},
            ],
        )
        
        md = ctx.to_markdown()
        
        assert "## Plan" in md
        assert "**Goal:** Build API" in md
        assert "**Progress:** 1/2 steps" in md
        assert "[x] Step 1: Create models" in md
        assert "[ ] Step 2: Add routes" in md


class TestSessionContextPersistence:
    """Test context save/load."""

    def test_save_and_load(self):
        """Should persist context to file and load it back."""
        with tempfile.TemporaryDirectory() as tmpdir:
            ctx = SessionContext()
            ctx.task_description = "Test task"
            ctx.update_tech_stack(
                technologies=[{"name": "FastAPI", "practices": ["Use Depends()"]}],
            )
            
            saved_path = ctx.save(tmpdir)
            
            assert saved_path.exists()
            assert saved_path.name == "context.md"
            
            loaded = SessionContext.load(tmpdir)
            
            assert loaded is not None
            assert loaded.task_description == "Test task"

    def test_load_raw(self):
        """Should load raw markdown content."""
        with tempfile.TemporaryDirectory() as tmpdir:
            ctx = SessionContext()
            ctx.task_description = "Raw test"
            ctx.save(tmpdir)
            
            raw = SessionContext.load_raw(tmpdir)
            
            assert raw is not None
            assert "# Session Context" in raw
            assert "Raw test" in raw

    def test_load_nonexistent(self):
        """Should return None for missing file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            loaded = SessionContext.load(tmpdir)
            assert loaded is None
            
            raw = SessionContext.load_raw(tmpdir)
            assert raw is None


class TestSessionContextUpdates:
    """Test context update methods."""

    def test_update_brainstorming(self):
        """Should update brainstorming section."""
        ctx = SessionContext()
        ctx.update_brainstorming(
            goal="Optimize performance",
            thinking="Need to profile first",
            approach="Use cProfile + line_profiler",
            risks=["May require refactoring"],
        )
        
        assert ctx.brainstorming is not None
        assert ctx.brainstorming.goal == "Optimize performance"
        assert ctx.brainstorming.approach == "Use cProfile + line_profiler"
        assert "May require refactoring" in ctx.brainstorming.risks

    def test_update_plan_progress(self):
        """Should mark steps as completed."""
        ctx = SessionContext()
        ctx.update_plan(
            goal="Deploy app",
            steps=[
                {"step": 1, "description": "Build image", "completed": False, "notes": ""},
                {"step": 2, "description": "Push to registry", "completed": False, "notes": ""},
            ],
        )
        
        ctx.update_plan_progress(1, notes="Built with docker")
        
        assert ctx.plan.steps[0]["completed"] is True
        assert ctx.plan.steps[0]["notes"] == "Built with docker"
        assert ctx.plan.steps[1]["completed"] is False


class TestNCAAgentContextIntegration:
    """Test that NCAAgent loads context.md."""

    def test_session_context_property(self):
        """NCAAgent should have session_context property."""
        from neoCoder.nca.config import NCAConfig
        
        with tempfile.TemporaryDirectory() as tmpdir:
            config = NCAConfig(working_dir=tmpdir)
            
            from unittest.mock import patch
            with patch('neoCoder.nca.agent.Orchestrator'):
                from neoCoder.nca.agent import NeoCoderAgent
                
                agent = NeoCoderAgent(
                    config=config,
                    enable_notes=False,
                    enable_compression=False,
                )
                
                assert agent.session_context is not None
                assert isinstance(agent.session_context, SessionContext)

    def test_update_session_context(self):
        """Should update and save context."""
        from neoCoder.nca.config import NCAConfig
        
        with tempfile.TemporaryDirectory() as tmpdir:
            config = NCAConfig(working_dir=tmpdir)
            
            from unittest.mock import patch
            with patch('neoCoder.nca.agent.Orchestrator'):
                from neoCoder.nca.agent import NeoCoderAgent
                
                agent = NeoCoderAgent(
                    config=config,
                    enable_notes=False,
                    enable_compression=False,
                )
                
                agent.update_session_context(
                    task_description="New task",
                    plan={"goal": "Test goal", "steps": [{"step": 1, "description": "Step 1", "completed": False}]},
                )
                
                context_file = os.path.join(tmpdir, ".neoCoder", "context.md")
                assert os.path.exists(context_file)
                
                content = open(context_file).read()
                assert "New task" in content
                assert "Test goal" in content


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
