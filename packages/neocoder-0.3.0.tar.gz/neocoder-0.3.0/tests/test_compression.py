"""
Test context compression functionality.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch

from neoCoder.sdk.memory.working import WorkingMemory, WorkingMemoryConfig, Message
from neoCoder.sdk.agents.architect import ArchitectAgent, ArchitectConfig, CompressionResult


class TestWorkingMemoryCompression:
    """Test WorkingMemory compression support."""

    def test_needs_compression_below_threshold(self):
        """Should not need compression when below threshold."""
        config = WorkingMemoryConfig(max_tokens=1000, compression_threshold=0.8)
        memory = WorkingMemory(config)
        
        memory.add_user_message("Short message")
        
        assert not memory.needs_compression()

    def test_needs_compression_above_threshold(self):
        """Should need compression when above threshold."""
        config = WorkingMemoryConfig(max_tokens=100, compression_threshold=0.8)
        memory = WorkingMemory(config)
        
        for i in range(20):
            memory.add_user_message(f"Message {i} with some content to increase tokens")
        
        assert memory.needs_compression()

    def test_get_compression_candidates(self):
        """Should return messages outside rolling window."""
        config = WorkingMemoryConfig(rolling_window_size=3)
        memory = WorkingMemory(config)
        
        for i in range(10):
            memory.add_user_message(f"Message {i}")
        
        candidates = memory.get_compression_candidates()
        
        assert len(candidates) == 7
        assert all(m.content.startswith("Message") for m in candidates)

    def test_get_compression_candidates_small_history(self):
        """Should return empty when history smaller than window."""
        config = WorkingMemoryConfig(rolling_window_size=5)
        memory = WorkingMemory(config)
        
        for i in range(3):
            memory.add_user_message(f"Message {i}")
        
        candidates = memory.get_compression_candidates()
        assert len(candidates) == 0

    def test_apply_compression(self):
        """Should replace old messages with summary."""
        config = WorkingMemoryConfig(rolling_window_size=3)
        memory = WorkingMemory(config)
        
        for i in range(10):
            memory.add_user_message(f"Message {i}")
        
        memory.apply_compression(
            summary="Summary of messages 0-6",
            compressed_count=7
        )
        
        assert memory._compressed_summary == "Summary of messages 0-6"
        assert len(memory._messages) == 3
        assert memory._messages[0].content == "Message 7"

    def test_get_messages_for_llm_with_summary(self):
        """Should include summary in LLM messages."""
        config = WorkingMemoryConfig(rolling_window_size=2)
        memory = WorkingMemory(config)
        
        for i in range(5):
            memory.add_user_message(f"Message {i}")
        
        memory.apply_compression(
            summary="Previous context summary",
            compressed_count=3
        )
        
        messages = memory.get_messages_for_llm()
        
        assert messages[0]["content"].startswith("[Previous context summary]")
        assert "Previous context summary" in messages[0]["content"]
        assert len(messages) == 3


@pytest.fixture
def mock_architect():
    """Create ArchitectAgent with mocked LLM client."""
    with patch('neoCoder.sdk.agents.architect.create_client') as mock_create:
        mock_llm = Mock()
        mock_create.return_value = mock_llm
        config = ArchitectConfig(api_key="test-key")
        architect = ArchitectAgent(config)
        architect._mock_llm = mock_llm
        yield architect


class TestArchitectAgent:
    """Test ArchitectAgent compression logic."""

    def test_should_compress_below_threshold(self, mock_architect):
        """Should not compress when below threshold."""
        memory = WorkingMemory(WorkingMemoryConfig(max_tokens=1000))
        memory.add_user_message("Short message")
        
        assert not mock_architect.should_compress(memory, max_tokens=1000)

    def test_should_compress_few_messages(self):
        """Should not compress when too few messages."""
        with patch('neoCoder.sdk.agents.architect.create_client'):
            config = ArchitectConfig(
                compression_threshold=0.1,
                min_messages_to_compress=10,
                rolling_window_size=2,
                api_key="test-key"
            )
            architect = ArchitectAgent(config)
            
            memory = WorkingMemory(WorkingMemoryConfig(max_tokens=100))
            for i in range(5):
                memory.add_user_message(f"Message {i} " * 50)
            
            assert not architect.should_compress(memory, max_tokens=100)

    def test_format_messages_for_summary(self, mock_architect):
        """Should format messages correctly."""
        messages = [
            Message.user("Hello"),
            Message.assistant("Hi there!"),
            Message.user("How are you?"),
        ]
        
        formatted = mock_architect._format_messages_for_summary(messages)
        
        assert "USER: Hello" in formatted
        assert "ASSISTANT: Hi there!" in formatted
        assert "USER: How are you?" in formatted

    def test_format_messages_with_tool_blocks(self, mock_architect):
        """Should handle tool use/result blocks."""
        messages = [
            Message(role="assistant", content=[
                {"type": "text", "text": "Let me check"},
                {"type": "tool_use", "name": "bash", "input": {"cmd": "ls"}}
            ]),
            Message(role="user", content=[
                {"type": "tool_result", "tool_use_id": "123", "content": "file1.txt\nfile2.txt"}
            ]),
        ]
        
        formatted = mock_architect._format_messages_for_summary(messages)
        
        assert "Let me check" in formatted
        assert "[Tool: bash]" in formatted
        assert "[Tool Result:" in formatted

    def test_format_truncates_long_messages(self, mock_architect):
        """Should truncate very long messages."""
        long_content = "x" * 3000
        messages = [Message.user(long_content)]
        
        formatted = mock_architect._format_messages_for_summary(messages)
        
        assert len(formatted) < 3000
        assert "[truncated]" in formatted

    def test_compress_applies_to_memory(self):
        """Should apply compression result to memory."""
        with patch('neoCoder.sdk.agents.architect.create_client') as mock_create:
            mock_llm = Mock()
            mock_response = Mock()
            mock_response.content = "### Summary\nThis is a compressed summary"
            mock_llm.invoke = Mock(return_value=mock_response)
            mock_create.return_value = mock_llm
            
            config = ArchitectConfig(api_key="test-key", rolling_window_size=2)
            architect = ArchitectAgent(config)
            
            memory = WorkingMemory(WorkingMemoryConfig(rolling_window_size=2))
            for i in range(10):
                memory.add_user_message(f"Message {i}")
            
            result = architect.compress(memory)
            
            assert result.messages_compressed == 8
            assert "Summary" in result.summary
            assert memory._compressed_summary is not None

    def test_compress_empty_candidates(self, mock_architect):
        """Should handle case with no compression candidates."""
        memory = WorkingMemory(WorkingMemoryConfig(rolling_window_size=10))
        for i in range(3):
            memory.add_user_message(f"Message {i}")
        
        result = mock_architect.compress(memory)
        
        assert result.messages_compressed == 0
        assert result.summary == ""
        assert result.compression_ratio == 1.0

    def test_create_plan_summary(self, mock_architect):
        """Should create formatted plan summary."""
        summary = mock_architect.create_plan_summary(
            task="Build a REST API",
            progress=["Created project structure", "Added models"],
            errors=["Database connection failed"],
            next_steps=["Fix database config", "Add endpoints"],
        )
        
        assert "### Task" in summary
        assert "Build a REST API" in summary
        assert "### Progress" in summary
        assert "Created project structure" in summary
        assert "### Errors" in summary
        assert "Database connection failed" in summary
        assert "### Next Steps" in summary
        assert "Fix database config" in summary


class TestCompressionResult:
    """Test CompressionResult dataclass."""

    def test_compression_result_fields(self):
        """Should store all compression metrics."""
        result = CompressionResult(
            summary="Test summary",
            messages_compressed=10,
            original_tokens=5000,
            compressed_tokens=500,
            compression_ratio=0.1,
        )
        
        assert result.summary == "Test summary"
        assert result.messages_compressed == 10
        assert result.original_tokens == 5000
        assert result.compressed_tokens == 500
        assert result.compression_ratio == 0.1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
