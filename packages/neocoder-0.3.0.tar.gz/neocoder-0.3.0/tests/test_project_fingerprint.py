"""
Test project fingerprint for tech stack caching.
"""

import os
import tempfile
import time
import pytest

from neoCoder.nca.project_fingerprint import (
    compute_project_fingerprint,
    load_cached_fingerprint,
    save_fingerprint,
    fingerprint_changed,
    needs_tech_stack_refresh,
)


class TestProjectFingerprint:
    """Test fingerprint computation."""

    def test_compute_empty_project(self):
        """Empty project should have empty fingerprint."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            fp = compute_project_fingerprint(Path(tmpdir))
            assert fp == {}

    def test_compute_with_pyproject(self):
        """Should detect pyproject.toml."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            pyproject = Path(tmpdir) / "pyproject.toml"
            pyproject.write_text("[project]\nname = 'test'")
            
            fp = compute_project_fingerprint(Path(tmpdir))
            
            assert "pyproject.toml" in fp
            assert ":" in fp["pyproject.toml"]  # mtime:size format

    def test_compute_with_package_json(self):
        """Should detect package.json."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            pkg = Path(tmpdir) / "package.json"
            pkg.write_text('{"name": "test"}')
            
            fp = compute_project_fingerprint(Path(tmpdir))
            
            assert "package.json" in fp


class TestFingerprintPersistence:
    """Test fingerprint save/load."""

    def test_save_and_load(self):
        """Should persist fingerprint to JSON."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            root = Path(tmpdir)
            
            fp = {"pyproject.toml": "123:456", "requirements.txt": "789:100"}
            save_fingerprint(root, fp)
            
            loaded = load_cached_fingerprint(root)
            
            assert loaded is not None
            assert loaded["fingerprint"] == fp
            assert "generated_at" in loaded

    def test_load_missing(self):
        """Should return None for missing fingerprint."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            loaded = load_cached_fingerprint(Path(tmpdir))
            assert loaded is None


class TestFingerprintChanged:
    """Test change detection."""

    def test_no_cache_means_changed(self):
        """No cached fingerprint should indicate change."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            assert fingerprint_changed(Path(tmpdir)) is True

    def test_same_fingerprint_unchanged(self):
        """Same fingerprint should indicate no change."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            root = Path(tmpdir)
            
            pyproject = root / "pyproject.toml"
            pyproject.write_text("[project]")
            
            # Compute and save
            fp = compute_project_fingerprint(root)
            save_fingerprint(root, fp)
            
            # Should not indicate change
            assert fingerprint_changed(root) is False

    def test_modified_file_detected(self):
        """Modified file should be detected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            root = Path(tmpdir)
            
            pyproject = root / "pyproject.toml"
            pyproject.write_text("[project]")
            
            # Save initial fingerprint
            fp = compute_project_fingerprint(root)
            save_fingerprint(root, fp)
            
            # Modify file
            time.sleep(0.01)  # Ensure mtime changes
            pyproject.write_text("[project]\nname = 'changed'")
            
            # Should detect change
            assert fingerprint_changed(root) is True

    def test_new_file_detected(self):
        """New dependency file should be detected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            root = Path(tmpdir)
            
            pyproject = root / "pyproject.toml"
            pyproject.write_text("[project]")
            
            # Save initial fingerprint
            fp = compute_project_fingerprint(root)
            save_fingerprint(root, fp)
            
            # Add new file
            requirements = root / "requirements.txt"
            requirements.write_text("pytest")
            
            # Should detect change
            assert fingerprint_changed(root) is True


class TestNeedsTechStackRefresh:
    """Test refresh decision logic."""

    def test_no_tech_stack_needs_refresh(self):
        """No tech stack in context should need refresh."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            assert needs_tech_stack_refresh(Path(tmpdir), None) is True
            assert needs_tech_stack_refresh(Path(tmpdir), "# Empty") is True

    def test_has_tech_stack_no_fingerprint(self):
        """Has tech stack but no fingerprint should need refresh."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            context = "# Session\n## Tech Stack\n- Python"
            assert needs_tech_stack_refresh(Path(tmpdir), context) is True

    def test_has_tech_stack_fingerprint_match(self):
        """Has tech stack with matching fingerprint should not refresh."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from pathlib import Path
            root = Path(tmpdir)
            
            # Create a file
            pyproject = root / "pyproject.toml"
            pyproject.write_text("[project]")
            
            # Save fingerprint
            fp = compute_project_fingerprint(root)
            save_fingerprint(root, fp)
            
            # Context with tech stack
            context = "# Session\n## Tech Stack\n- Python"
            
            assert needs_tech_stack_refresh(root, context) is False


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
