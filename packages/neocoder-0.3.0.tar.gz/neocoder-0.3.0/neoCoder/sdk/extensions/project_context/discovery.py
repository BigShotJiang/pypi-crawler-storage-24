"""
Project discovery — simple file scanner.

Finds key project files (package.json, pom.xml, etc.) and returns their names.
LLM will analyze the actual content and determine best practices.

No complex parsing, no hardcoded conventions — just detection.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


# Key files that indicate project type/tools
KEY_FILES = [
    # Python
    "pyproject.toml",
    "setup.py",
    "requirements.txt",
    "Pipfile",
    "poetry.lock",
    "manage.py",  # Django
    "alembic.ini",  # Alembic migrations
    # JavaScript/TypeScript
    "package.json",
    "tsconfig.json",
    "vite.config.ts",
    "next.config.js",
    "nuxt.config.ts",
    # Java/Kotlin
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    # Ruby
    "Gemfile",
    "Rakefile",
    # Go
    "go.mod",
    "go.sum",
    # Rust
    "Cargo.toml",
    # .NET
    "*.csproj",
    "*.sln",
    # PHP
    "composer.json",
    "artisan",  # Laravel
    # Config files
    ".eslintrc.js",
    ".eslintrc.json",
    "eslint.config.js",
    "prettier.config.js",
    ".prettierrc",
    "ruff.toml",
    "pyproject.toml",
    ".flake8",
    "mypy.ini",
    "tox.ini",
    "Makefile",
    "Dockerfile",
    "docker-compose.yml",
    "docker-compose.yaml",
]


@dataclass
class DiscoveredFile:
    """A discovered project file."""
    name: str
    path: str
    category: str = ""  # build, config, framework, etc.


@dataclass
class ProjectProfile:
    """Simple project profile — just list of detected files."""
    files: list[DiscoveredFile] = field(default_factory=list)

    @property
    def detected_any(self) -> bool:
        return bool(self.files)

    @property
    def all_detected(self) -> list[DiscoveredFile]:
        return self.files

    def describe(self) -> str:
        """One-line summary of detected files."""
        if not self.files:
            return "No project files detected"
        names = [f.name for f in self.files[:10]]
        suffix = f" (+{len(self.files) - 10} more)" if len(self.files) > 10 else ""
        return ", ".join(names) + suffix

    def tool_names(self) -> list[str]:
        """Return list of tool names for tech stack analyzer."""
        return [f.name for f in self.files]


class ProjectDiscovery:
    """
    Simple file scanner — finds key project files.
    
    No parsing, no conventions, no commands.
    LLM handles the analysis.
    """

    def scan(self, project_dir: str) -> ProjectProfile:
        """Scan project directory for key files."""
        root = Path(project_dir)
        profile = ProjectProfile()
        seen_names: set[str] = set()

        if not root.exists():
            return profile

        def add_file(name: str, path: Path) -> None:
            """Add file if not already seen."""
            if name not in seen_names:
                seen_names.add(name)
                profile.files.append(DiscoveredFile(name=name, path=str(path)))

        # Check root directory for key files
        for key_file in KEY_FILES:
            if "*" in key_file:
                # Glob pattern (e.g., *.csproj)
                for found in root.glob(key_file):
                    if found.is_file():
                        add_file(found.name, found)
            else:
                path = root / key_file
                if path.exists() and path.is_file():
                    add_file(key_file, path)

        # Check common subdirectories
        for subdir in ["src", "app", "config", "src/main/resources"]:
            sub_path = root / subdir
            if sub_path.exists():
                for key_file in KEY_FILES:
                    if "*" not in key_file:
                        path = sub_path / key_file
                        if path.exists() and path.is_file():
                            add_file(key_file, path)

        if profile.files:
            logger.info("Discovered %d project files", len(profile.files))

        return profile
