"""
Configuration for Database Context Extension.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class DatabaseContextConfig:
    """Configuration for database context detection."""

    # Whether the extension is active
    enabled: bool = True

    # Strong keywords — ONE match is enough to activate.
    # These are unambiguously about DB schemas / migrations.
    task_keywords_strong: list[str] = field(default_factory=lambda: [
        "migration",
        "migrate",
        "flyway",
        "liquibase",
        "alembic",
        "ddl",
        "schema-validation",
        "create table",
        "alter table",
        "drop table",
        "add column",
        "foreign key",
    ])

    # Weak keywords — need >= threshold matches to activate.
    # These are common words that may appear outside DB context.
    task_keywords_weak: list[str] = field(default_factory=lambda: [
        "schema",
        "database",
        "entity",
        "table",
        "column",
        "sql",
        "hibernate",
        "jpa",
        "orm",
        "sequelize",
        "typeorm",
        "prisma",
        "activerecord",
        "sqlalchemy",
        "django model",
    ])

    # Minimum number of weak keyword matches to activate.
    weak_keyword_threshold: int = 3
