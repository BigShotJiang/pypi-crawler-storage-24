"""
Database Context Extension for neoCoder Agent.

Lightweight extension that detects DB-related tasks and injects
a protocol/checklist for the LLM to follow. No hardcoded validation —
LLM uses the checklist to self-validate migrations.
"""

from neoCoder.sdk.extensions.db_context.extension import DatabaseContextExtension
from neoCoder.sdk.extensions.db_context.config import DatabaseContextConfig
from neoCoder.sdk.extensions.db_context.detector import (
    DatabaseContextDetector,
    DbContextSnapshot,
)

__all__ = [
    "DatabaseContextExtension",
    "DatabaseContextConfig",
    "DatabaseContextDetector",
    "DbContextSnapshot",
]
