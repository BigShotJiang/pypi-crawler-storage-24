"""
Thinking/Planning extension for structured reasoning.

Provides:
- Brainstorming (context, decomposition, decision, risks)
- Step-by-step planning based on the approved brainstorming
- Progress tracking
- Unified session context persistence (tech stack + brainstorming + plan)

Decision Funnel: Brainstorming (what & why) → Plan (how exactly).

Context is persisted to .neoCoder/context.md for agent access across sessions.
"""

from __future__ import annotations

import copy
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _parse_tech_stack_from_thinking(thinking: str) -> tuple[list[dict], list[dict]]:
    """
    Parse tech stack and integrations from brainstorming thinking output.
    
    Supports multiple formats:
    ```
    Tech Stack:
    - FastAPI 0.100: practice 1; practice 2
    - **PostgreSQL 15**: practice 1; practice 2
    1. Spring Boot 3.2: practice 1; practice 2
    
    Integration:
    - FastAPI + SQLAlchemy: integration practice 1; practice 2
    ```
    
    Returns:
        Tuple of (technologies, integrations)
    """
    technologies: list[dict] = []
    integrations: list[dict] = []
    
    # Find Tech Stack section (various header formats)
    tech_match = re.search(
        r'(?:Tech(?:nology)?\s*Stack|Technologies|Stack):\s*\n((?:[-*\d.]+\s*.+\n?)+)',
        thinking,
        re.IGNORECASE
    )
    if tech_match:
        for line in tech_match.group(1).strip().split('\n'):
            line = line.strip()
            # Skip empty lines and section headers
            if not line or line.lower().startswith(('integration', 'architecture')):
                break
            
            # Remove list markers: -, *, 1., 2., etc.
            line = re.sub(r'^[-*]\s*|^\d+\.\s*', '', line).strip()
            # Remove markdown bold markers
            line = re.sub(r'\*\*([^*]+)\*\*', r'\1', line)
            
            if not line:
                continue
            
            # Parse "Name version: practice 1; practice 2" or "Name (version): ..."
            match = re.match(
                r'([^:(\d]+?)(?:\s*[(\s]*([\d.]+[^\s):]*)[)\s]*)?\s*:\s*(.+)',
                line
            )
            if match:
                name = match.group(1).strip()
                version = (match.group(2) or "").strip()
                practices_str = match.group(3).strip()
                # Support both ; and , as separators
                practices = [p.strip() for p in re.split(r'[;,]', practices_str) if p.strip()]
                
                if name and practices:
                    technologies.append({
                        "name": name,
                        "version": version,
                        "practices": practices,
                    })
    
    # Find Integration section (various header formats)
    int_match = re.search(
        r'(?:Integration|Integrations):\s*\n((?:[-*\d.]+\s*.+\n?)+)',
        thinking,
        re.IGNORECASE
    )
    if int_match:
        for line in int_match.group(1).strip().split('\n'):
            line = line.strip()
            # Skip empty lines and new section headers
            if not line or re.match(r'^(?:Tech|Architecture|##)', line, re.IGNORECASE):
                break
            
            # Remove list markers
            line = re.sub(r'^[-*]\s*|^\d+\.\s*', '', line).strip()
            # Remove markdown bold markers
            line = re.sub(r'\*\*([^*]+)\*\*', r'\1', line)
            
            if not line:
                continue
            
            # Parse "Tech A + Tech B: practice 1; practice 2"
            match = re.match(r'([^:]+)\s*:\s*(.+)', line)
            if match:
                pair = match.group(1).strip()
                practices_str = match.group(2).strip()
                practices = [p.strip() for p in re.split(r'[;,]', practices_str) if p.strip()]
                
                if pair and practices:
                    integrations.append({
                        "pair": pair,
                        "practices": practices,
                    })
    
    return technologies, integrations

from neoCoder.sdk.extensions.base import Extension, ExtensionContext, ExecutionResult
from neoCoder.sdk.extensions.session_context import SessionContext
from neoCoder.sdk.llm.output_parser import Action


@dataclass
class ThinkingConfig:
    """Configuration for thinking extension."""

    enable_planning: bool = True
    max_plan_steps: int = 12
    # Working directory for session context persistence
    working_dir: str | None = None
    # Legacy: output_dir for backward compatibility (deprecated)
    output_dir: str | None = None





class ThinkingExtension(Extension):
    """
    Extension for brainstorming, planning, and progress tracking.

    Implements a Decision Funnel workflow:
      brainstorming  → Think through the problem before coding
      plan           → Break the chosen approach into concrete steps
      progress       → Track step completion
    """

    __slots__ = (
        "config",
        "_current_brainstorming",
        "_current_plan",
        "_current_step",
        "_brainstorming_completed",
        "_session_context",
        "_working_dir",
    )

    def __init__(self, config: ThinkingConfig | None = None):
        """
        Initialize thinking extension.

        Args:
            config: Extension configuration.
        """
        super().__init__()
        self.config = config or ThinkingConfig()
        self._current_brainstorming: dict[str, Any] | None = None
        self._current_plan: list[dict[str, Any]] = []
        self._current_step: int = 0
        self._brainstorming_completed: bool = False
        
        # Session context for unified persistence
        self._working_dir: Path | None = None
        if self.config.working_dir:
            self._working_dir = Path(self.config.working_dir)
        elif self.config.output_dir:
            # Legacy: use output_dir parent as working_dir
            self._working_dir = Path(self.config.output_dir).parent
        
        self._session_context: SessionContext | None = None
        self._load_session_context()

    @property
    def name(self) -> str:
        return "thinking"

    @property
    def xml_tags(self) -> list[str]:
        return ["brainstorming", "plan", "update_progress", "read_context", "pre_commit_check"]

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        return [
            {
                "name": "brainstorming",
                "description": (
                    "Think hard through the problem before coding. "
                    "Brainstorm ideas and develop a high-level solution approach. "
                    "Write step-by-step reasoning in 'thinking', then distill into 'approach'. "
                    "Must be called BEFORE 'plan'."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "goal": {
                            "type": "string",
                            "description": "The high-level goal to achieve",
                        },
                        "thinking": {
                            "type": "string",
                            "description": (
                                "DEEP REASONING SPACE — think critically until you've found the best solution\n\n"
                                "## ⛔ ANTI-HALLUCINATION RULES\n"
                                "- NEVER claim 'the code does X' without having READ that code via file_read/grep\n"
                                "- For every factual claim, ask: 'Did I SEE this or am I ASSUMING it?'\n"
                                "- If assuming → pause thinking, read the actual code, then continue\n"
                                "- When citing framework behavior, specify: version + official doc or verified behavior\n\n"
                                "## EXPLORE\n"
                                "- What is the REAL problem? (not just what was asked)\n"
                                "- What constraints and invariants exist?\n"
                                "- What in the tech stack DIRECTLY affects the solution? (don't repeat known context)\n\n"
                                "## CHALLENGE\n"
                                "- Consider 2-3 approaches. For each: WHY would it work? WHY would it FAIL?\n"
                                "## DECIDE\n"
                                "- ⛔ NEVER take simplest solution, ALWAYS prefer the FRAMEWORK BEST PRACTICES solution\n"
                                "- ⛔ Choose ONLY the FRAMEWORK IDIOMATIC approach even if it is overkill ore overengineering\n"
                                "- IDIOMATIC = DESIGNED: For each candidate approach, answer: "
                                "'Does this use the mechanism the tool/framework/library was DESIGNED "
                                "to provide for this CATEGORY of problem, or does it implement the "
                                "behavior OUTSIDE that mechanism?' The approach that works THROUGH "
                                "the tool's designed architecture — not AROUND it — is idiomatic "
                                "by definition. You may only reject it if you can name a specific "
                                "technical constraint that makes it unsuitable. 'Too complex', "
                                "'overkill for this case', or 'significant refactoring' are NOT valid reasons "
                                "to bypass a tool's own extension architecture.\n"
                                "## ⛔ MENTAL SIMULATION (write output for each!)\n"
                                "For each category below, write what you checked and the result:\n"
                                "- **Happy path**: mentally simulate ALL valid scenarios"
                                "- **Edge cases**: mentally simulate ALL edge cases scenarios\n"
                                "- **Failure paths**: mentally simulate ALL failure paths scenarios\n"
                                "If any issue found → note it and adjust approach.\n\n"
                                "Write in clear paragraphs. Do NOT write code — focus on WHAT and WHY."
                            ),
                        },
                        "approach": {
                            "type": "string",
                            "description": (
                                "Distilled decision: what you will do and why. "
                                "Keep it concise — the details are in 'thinking'."
                            ),
                        },
                        "risks": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Key risks identified during thinking and how to mitigate them",
                        },
                    },
                    "required": ["goal", "thinking", "approach"],
                },
            },
            {
                "name": "plan",
                "description": (
                    "Create a detailed structured plan with numbered steps. "
                    "Must be based on a previously completed brainstorming "
                    "(call 'brainstorming' first). "
                    "⛔ MANDATORY: The plan MUST include these steps in this order: "
                    "1) Implementation steps, "
                    "2) 'Call pre_commit_check tool to verify CRIT rules', "
                    "3) 'Run build to verify compilation' "
                    "pre_commit_check MUST come BEFORE build/test steps."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "goal": {
                            "type": "string",
                            "description": "The goal to achieve",
                        },
                        "steps": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "List of steps. MUST end with: "
                                "1) 'Call pre_commit_check to verify CRIT rules', "
                                "2) 'Run build command' "
                                "pre_commit_check ALWAYS before build/test."
                            ),
                        },
                    },
                    "required": ["goal", "steps"],
                },
            },
            {
                "name": "update_progress",
                "description": (
                    "Update progress on the current plan by marking a step as complete."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "step_number": {
                            "type": "integer",
                            "description": "The step number to mark as complete (1-indexed)",
                        },
                        "notes": {
                            "type": "string",
                            "description": "Optional notes about the completed step",
                        },

                      },
                    "required": ["step_number"],
                },
            },
            {
                "name": "read_context",
                "description": (
                    "Read the current session context including tech stack, brainstorming, and plan. "
                    "Use this when you need to recall previous decisions or check the current plan. "
                    "Context includes: detected technologies with best practices, "
                    "brainstorming approach, and implementation plan with progress."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "section": {
                            "type": "string",
                            "enum": ["all", "tech_stack", "brainstorming", "plan"],
                            "description": "Which section to read (default: all)",
                        },
                    },
                },
            },
            {
                "name": "pre_commit_check",
                "description": (
                    "⛔ MANDATORY before completing any code change task. "
                    "Verify that all CRITICAL rules are satisfied and code is ready for commit. "
                    "You MUST call this tool before saying 'task complete' or 'done'."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "crit_rules_check": {
                            "type": "object",
                            "description": "Verification of each CRIT rule",
                            "properties": {
                                "crit_0_security": {"type": "string", "description": "How CRIT-0 (Security-First) is satisfied"},
                                "crit_1_architecture": {"type": "string", "description": "How CRIT-1 (Architecture) is satisfied"},
                                "crit_2_secrets": {"type": "string", "description": "How CRIT-2 (No Secret Leaks) is satisfied"},
                                "crit_3_cleanup": {"type": "string", "description": "How CRIT-3 (Guaranteed Cleanup) is satisfied"},
                                "crit_4_error_handling": {"type": "string", "description": "How CRIT-4 (Explicit Failure Handling) is satisfied"},
                                "crit_5_dependencies": {"type": "string", "description": "How CRIT-5 (Declare Dependencies) is satisfied"},
                                "crit_6_shared_state": {"type": "string", "description": "How CRIT-6 (Protect Shared State) is satisfied or N/A"},
                            },
                        },
                        "anti_patterns_check": {
                            "type": "string",
                            "description": "Confirm no bottlenecks, blocking calls, inefficient queries",
                        },
                        "files_changed": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "List of files created or modified",
                        },
                        "ready_to_commit": {
                            "type": "boolean",
                            "description": "Final verdict: is the code ready to commit?",
                        },
                        "blockers": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "If not ready, list blockers that must be fixed",
                        },
                    },
                    "required": ["crit_rules_check", "anti_patterns_check", "ready_to_commit"],
                },
            },
        ]

    def can_handle(self, action: Action) -> bool:
        """Check if we can handle this action."""
        return action.name in ["brainstorming", "plan", "update_progress", "read_context", "pre_commit_check"]

    def execute(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """
        Execute a thinking/planning action.

        Args:
            action: Action to execute.
            context: Extension context.

        Returns:
            ExecutionResult.
        """
        if action.name == "brainstorming":
            return self._handle_brainstorming(action, context)
        elif action.name == "plan":
            return self._handle_plan(action, context)
        elif action.name == "update_progress":
            return self._handle_progress(action, context)
        elif action.name == "read_context":
            return self._handle_read_context(action, context)
        elif action.name == "pre_commit_check":
            return self._handle_pre_commit_check(action, context)
        else:
            return ExecutionResult.error_result(f"Unknown thinking action: {action.name}")

    def _require_brainstorming(self) -> ExecutionResult | None:
        """Return an error result if ``brainstorming`` has not been called yet."""
        if self._brainstorming_completed:
            return None
        return ExecutionResult.error_result(
            "Brainstorming required: call 'brainstorming' before 'plan'.\n"
            "The brainstorming tool helps you think through the problem "
            "before jumping into implementation."
        )

    # ------------------------------------------------------------------ #
    #  Session context persistence                                        #
    # ------------------------------------------------------------------ #

    def _load_session_context(self) -> None:
        """Load existing session context if available."""
        if self._working_dir is None:
            self._session_context = SessionContext()
            return
            
        loaded = SessionContext.load(self._working_dir)
        if loaded:
            self._session_context = loaded
            # Restore state from loaded context
            if loaded.brainstorming:
                self._current_brainstorming = {
                    "goal": loaded.brainstorming.goal,
                    "thinking": loaded.brainstorming.thinking,
                    "approach": loaded.brainstorming.approach,
                    "risks": loaded.brainstorming.risks,
                }
                self._brainstorming_completed = True
            if loaded.plan:
                self._current_plan = loaded.plan.steps.copy()
                self._current_step = sum(1 for s in self._current_plan if s.get("completed"))
            logger.info("Restored session context from %s", self._working_dir)
        else:
            self._session_context = SessionContext()

    def _save_session_context(self) -> None:
        """Save current session context to file."""
        if self._working_dir is None or self._session_context is None:
            return
        self._session_context.save(self._working_dir)

    def _sync_to_session_context(self) -> None:
        """Sync current state to session context."""
        if self._session_context is None:
            return
            
        if self._current_brainstorming:
            self._session_context.update_brainstorming(
                goal=self._current_brainstorming.get("goal", ""),
                thinking=self._current_brainstorming.get("thinking", ""),
                approach=self._current_brainstorming.get("approach", ""),
                risks=self._current_brainstorming.get("risks", []),
            )
        
        if self._current_plan:
            goal = ""
            if self._current_brainstorming:
                goal = self._current_brainstorming.get("goal", "")
            self._session_context.update_plan(goal=goal, steps=self._current_plan)

    def get_session_context(self) -> SessionContext | None:
        """Get the current session context for external access."""
        return self._session_context

    def set_working_dir(self, working_dir: str | Path) -> None:
        """Set working directory and reload context."""
        self._working_dir = Path(working_dir)
        self._load_session_context()

    def update_tech_stack(
        self,
        technologies: list[dict[str, Any]] | None = None,
        integrations: list[dict[str, Any]] | None = None,
        codebase_overrides: list[str] | None = None,
        raw_discovery: list[str] | None = None,
    ) -> None:
        """
        Update tech stack in session context.
        
        Called by tech stack analyzer after discovery/confirmation.
        """
        if self._session_context is None:
            self._session_context = SessionContext()
        
        self._session_context.update_tech_stack(
            technologies=technologies,
            integrations=integrations,
            codebase_overrides=codebase_overrides,
            raw_discovery=raw_discovery,
        )
        self._save_session_context()

    def set_task_description(self, task: str) -> None:
        """Set the current task description in session context."""
        if self._session_context is None:
            self._session_context = SessionContext()
        self._session_context.task_description = task
        self._save_session_context()

    # ------------------------------------------------------------------ #
    #  Tool handlers                                                      #
    # ------------------------------------------------------------------ #

    def _handle_brainstorming(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle brainstorming: free-form thinking + distilled decision."""
        goal = action.input.get("goal", "")
        thinking = action.input.get("thinking", "")
        approach = action.input.get("approach", "")
        risks_raw = action.input.get("risks", [])
        
        # Normalize risks to list of strings
        if isinstance(risks_raw, str):
            risks = [risks_raw] if risks_raw else []
        elif isinstance(risks_raw, list):
            risks = [str(r) for r in risks_raw]
        else:
            risks = []

        if not goal:
            return ExecutionResult.error_result("No goal provided for brainstorming")
        if not thinking:
            return ExecutionResult.error_result("No thinking provided — reason through the problem first")
        if not approach:
            return ExecutionResult.error_result("No approach provided — distill your thinking into a decision")

        # Store brainstorming
        self._current_brainstorming = {
            "goal": goal,
            "thinking": thinking,
            "approach": approach,
            "risks": risks,
        }

        # Format output for user display
        lines = [f"[Brainstorming] Goal: {goal}", ""]

        # Show tech stack if available
        if self._session_context and self._session_context.tech_stack.raw_discovery:
            lines.append("  Tech Stack: " + ", ".join(self._session_context.tech_stack.raw_discovery[:10]))
            lines.append("")

        lines.append("  Thinking:")
        for line in thinking.strip().splitlines():
            lines.append(f"     {line.strip()}")
        lines.append("")

        lines.append(f"  Decision: {approach}")
        lines.append("")

        if risks:
            lines.append("  Risks:")
            for risk in risks:
                lines.append(f"     ⚠ {risk}")
            lines.append("")

        user_output = "\n".join(lines)

        # Store in context artifacts
        context.store_artifact("current_brainstorming", self._current_brainstorming)
        self._brainstorming_completed = True

        # Parse and update tech stack from thinking output
        technologies, integrations = _parse_tech_stack_from_thinking(thinking)
        if technologies or integrations:
            self.update_tech_stack(
                technologies=technologies if technologies else None,
                integrations=integrations if integrations else None,
            )
            logger.info(
                "Parsed tech stack from brainstorming: %d technologies, %d integrations",
                len(technologies), len(integrations)
            )

        # Sync and persist to session context
        self._sync_to_session_context()
        self._save_session_context()

        agent_output = "Brainstorming complete. Now create a plan with the 'plan' tool."

        return ExecutionResult.success_result(
            output=agent_output,
            user_output=user_output,
            artifacts={"brainstorming_created": True},
        )

    def _handle_plan(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle a planning action. Must follow brainstorming."""
        gate = self._require_brainstorming()
        if gate is not None:
            return gate

        goal = action.input.get("goal", "")
        steps_raw = action.input.get("steps", [])
        
        # Normalize steps to list of strings
        if isinstance(steps_raw, str):
            steps = [steps_raw] if steps_raw else []
        elif isinstance(steps_raw, list):
            steps = [str(s) for s in steps_raw]
        else:
            steps = []

        if not goal:
            return ExecutionResult.error_result("No goal provided")

        if not steps:
            return ExecutionResult.error_result("No steps provided")

        # Limit steps
        if len(steps) > self.config.max_plan_steps:
            steps = steps[: self.config.max_plan_steps]

        # Store plan
        self._current_plan = [
            {"step": i + 1, "description": step, "completed": False, "notes": ""}
            for i, step in enumerate(steps)
        ]
        self._current_step = 0

        # Format for display
        plan_lines = [f"[Plan] Goal: {goal}", ""]
        if self._current_brainstorming:
            approach_preview = self._current_brainstorming["approach"][:80]
            plan_lines.append(f"  Based on brainstorming: {approach_preview}...")
            plan_lines.append("")
        for item in self._current_plan:
            plan_lines.append(f"  {item['step']}. [ ] {item['description']}")

        user_output = "\n".join(plan_lines)

        # Store in context artifacts
        context.store_artifact("current_plan", {
            "goal": goal,
            "steps": self._current_plan,
            "brainstorming": self._current_brainstorming,
        })

        # Sync and persist to session context
        self._sync_to_session_context()
        self._save_session_context()

        # Reset gate for the next brainstorming→plan cycle
        self._brainstorming_completed = False

        return ExecutionResult.success_result(
            output=f"Plan created with {len(steps)} steps.",
            user_output=user_output,
            artifacts={"plan_created": True},
        )

    def _handle_progress(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle a progress update action."""
        step_number = action.input.get("step_number", 0)
        notes = action.input.get("notes", "")

        if not self._current_plan:
            return ExecutionResult.error_result("No active plan. Create a plan first.")

        if step_number < 1 or step_number > len(self._current_plan):
            return ExecutionResult.error_result(
                f"Invalid step number. Plan has {len(self._current_plan)} steps."
            )

        # Update step
        step_idx = step_number - 1
        self._current_plan[step_idx]["completed"] = True
        self._current_plan[step_idx]["notes"] = notes
        self._current_step = step_number

        # Calculate progress
        completed = sum(1 for s in self._current_plan if s["completed"])
        total = len(self._current_plan)
        progress_pct = (completed / total) * 100

        # Format for display
        step_desc = self._current_plan[step_idx]["description"]
        user_output = f"[Progress] Step {step_number} completed: {step_desc}"
        if notes:
            user_output += f"\n  Notes: {notes}"
        user_output += f"\n  Overall: {completed}/{total} ({progress_pct:.0f}%)"

        # Update session context with progress
        if self._session_context:
            self._session_context.update_plan_progress(step_number, notes)
            self._save_session_context()

        return ExecutionResult.success_result(
            output=f"Step {step_number} marked complete. Progress: {completed}/{total}",
            user_output=user_output,
            artifacts={"progress": progress_pct},
        )

    def _handle_read_context(
        self, action: Action, context: ExtensionContext
    ) -> ExecutionResult:
        """Handle read_context: return session context for agent."""
        if self._session_context is None:
            return ExecutionResult.error_result("No session context available")

        section = action.input.get("section", "all")
        
        if section == "all":
            output = self._session_context.to_markdown()
        elif section == "tech_stack":
            # Build tech stack section only
            lines = ["## Tech Stack", ""]
            ts = self._session_context.tech_stack
            if ts.technologies:
                for tech in ts.technologies:
                    name = tech.get("name", "Unknown")
                    version = tech.get("version", "")
                    version_str = f" ({version})" if version else ""
                    lines.append(f"**{name}{version_str}**")
                    for practice in tech.get("practices", []):
                        lines.append(f"  - {practice}")
            if ts.integrations:
                lines.append("")
                lines.append("### Integrations")
                for integration in ts.integrations:
                    pair = integration.get("pair", "Unknown")
                    lines.append(f"**{pair}**")
                    for practice in integration.get("practices", []):
                        lines.append(f"  - {practice}")
            output = "\n".join(lines) if lines else "No tech stack defined"
        elif section == "brainstorming":
            if self._session_context.brainstorming:
                s = self._session_context.brainstorming
                output = f"**Goal:** {s.goal}\n\n**Approach:** {s.approach}"
                if s.risks:
                    output += "\n\n**Risks:**\n" + "\n".join(f"- {r}" for r in s.risks)
            else:
                output = "No brainstorming defined"
        elif section == "plan":
            if self._session_context.plan and self._session_context.plan.steps:
                p = self._session_context.plan
                completed = sum(1 for s in p.steps if s.get("completed"))
                total = len(p.steps)
                lines = [f"**Goal:** {p.goal}", f"**Progress:** {completed}/{total}", ""]
                for step in p.steps:
                    mark = "x" if step.get("completed") else " "
                    lines.append(f"- [{mark}] Step {step.get('step')}: {step.get('description')}")
                output = "\n".join(lines)
            else:
                output = "No plan defined"
        else:
            return ExecutionResult.error_result(f"Unknown section: {section}")

        return ExecutionResult.success_result(
            output=output,
            user_output=f"[Context: {section}]\n{output[:500]}..." if len(output) > 500 else f"[Context: {section}]\n{output}",
        )

    def get_current_plan(self) -> list[dict[str, Any]]:
        """Get the current plan (deep copy to prevent external mutation)."""
        return copy.deepcopy(self._current_plan)

    def get_progress(self) -> float:
        """Get current progress percentage."""
        if not self._current_plan:
            return 0.0
        completed = sum(1 for s in self._current_plan if s["completed"])
        return (completed / len(self._current_plan)) * 100

    def _handle_pre_commit_check(
        self, action: Action, context: ExtensionContext
    ) -> ExecutionResult:
        """Handle pre_commit_check: verify CRIT rules before completing task."""
        inp = action.input
        
        crit_rules = inp.get("crit_rules_check", {})
        ready_to_commit = inp.get("ready_to_commit", False)
        blockers = inp.get("blockers", [])
        files_changed = inp.get("files_changed", [])
        
        # Normalize blockers
        if isinstance(blockers, str):
            blockers = [blockers] if blockers else []
        elif not isinstance(blockers, list):
            blockers = []
        
        # Build verification report
        lines = ["## ⛔ Pre-Commit Checklist", ""]
        
        # CRIT rules section
        lines.append("### CRIT Rules Verification")
        crit_labels = {
            "crit_0_security": "CRIT-0 Security-First",
            "crit_1_architecture": "CRIT-1 Architecture",
            "crit_2_secrets": "CRIT-2 No Secret Leaks",
            "crit_3_cleanup": "CRIT-3 Guaranteed Cleanup",
            "crit_4_error_handling": "CRIT-4 Error Handling",
            "crit_5_dependencies": "CRIT-5 Dependencies",
            "crit_6_shared_state": "CRIT-6 Shared State",
        }
        for key, label in crit_labels.items():
            value = crit_rules.get(key, "Not checked")
            status = "✓" if value and value.lower() not in ("n/a", "not applicable", "not checked", "") else "○"
            lines.append(f"  [{status}] **{label}**: {value[:100] if value else 'Not checked'}")
        lines.append("")
        
        # Other checks
        if inp.get("anti_patterns_check"):
            lines.append(f"  [✓] **Anti-patterns**: {inp['anti_patterns_check'][:100]}")
        lines.append("")
        
        # Files changed
        if files_changed:
            lines.append("### Files Changed")
            for f in files_changed[:20]:
                lines.append(f"  - {f}")
            lines.append("")
        
        # Verdict
        lines.append("### Verdict")
        if ready_to_commit:
            lines.append("  ✅ **READY TO COMMIT**")
            verdict_msg = "Pre-commit check passed. Code is ready for commit."
        else:
            lines.append("  ❌ **NOT READY - BLOCKERS FOUND**")
            if blockers:
                lines.append("")
                lines.append("  **Blockers:**")
                for blocker in blockers:
                    lines.append(f"    - ⚠ {blocker}")
            verdict_msg = f"Pre-commit check failed. {len(blockers)} blocker(s) must be fixed."
        
        user_output = "\n".join(lines)
        
        # Store in artifacts for orchestrator to check
        context.store_artifact("pre_commit_check", {
            "ready_to_commit": ready_to_commit,
            "blockers": blockers,
            "files_changed": files_changed,
            "crit_rules": crit_rules,
        })
        
        # Store flag for completion detection
        context.store_artifact("pre_commit_completed", True)
        
        return ExecutionResult.success_result(
            output=verdict_msg,
            user_output=user_output,
            artifacts={"pre_commit_ready": ready_to_commit},
            metadata={"task_complete": ready_to_commit and not blockers},
        )

    def signals_continuation(self) -> bool:
        """Thinking actions want continuation."""
        return True
