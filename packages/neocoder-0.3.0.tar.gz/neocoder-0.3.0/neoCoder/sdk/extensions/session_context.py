"""
Session Context — persistent context file for agent continuity.

Combines:
- Tech Stack (detected + confirmed technologies and best practices)
- Brainstorming (current problem analysis and approach)
- Plan (step-by-step implementation plan with progress)

The agent reads this file at session start and updates it during work.
This enables context persistence across sessions and agent restarts.

File format: Markdown (.neoCoder/context.md)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class TechStackContext:
    """Detected and confirmed tech stack with best practices."""

    technologies: list[dict[str, Any]] = field(default_factory=list)
    # Format: {"name": "FastAPI", "version": "0.100+", "practices": ["...", "..."]}
    integrations: list[dict[str, Any]] = field(default_factory=list)
    # Format: {"pair": "SQLAlchemy + PostgreSQL", "practices": ["...", "..."]}
    codebase_overrides: list[str] = field(default_factory=list)
    raw_discovery: list[str] = field(default_factory=list)  # Auto-detected tool names


@dataclass
class BrainstormingContext:
    """Current brainstorming for the task."""

    goal: str = ""
    thinking: str = ""
    approach: str = ""
    risks: list[str] = field(default_factory=list)
    created_at: str = ""


@dataclass
class PlanContext:
    """Current implementation plan."""

    goal: str = ""
    steps: list[dict[str, Any]] = field(default_factory=list)
    # Format: {"step": 1, "description": "...", "completed": False, "notes": ""}
    created_at: str = ""


@dataclass
class SessionContext:
    """
    Complete session context combining tech stack, brainstorming, and plan.
    
    Persisted to .neoCoder/context.md for agent access.
    """

    tech_stack: TechStackContext = field(default_factory=TechStackContext)
    brainstorming: BrainstormingContext | None = None
    plan: PlanContext | None = None
    task_description: str = ""
    last_updated: str = ""

    _CONTEXT_FILENAME = "context.md"
    _CONTEXT_DIR = ".neoCoder"

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_markdown(self) -> str:
        """Render context as Markdown for persistence and agent consumption."""
        lines = [
            "# Session Context",
            "",
            f"*Last updated: {self.last_updated or 'never'}*",
            "",
        ]

        # Task
        if self.task_description:
            lines += [
                "## Current Task",
                "",
                self.task_description,
                "",
            ]

        # Tech Stack
        lines += ["## Tech Stack", ""]
        if self.tech_stack.technologies:
            lines.append("### Technologies")
            lines.append("")
            for tech in self.tech_stack.technologies:
                name = tech.get("name", "Unknown")
                version = tech.get("version", "")
                version_str = f" ({version})" if version else ""
                lines.append(f"**{name}{version_str}**")
                for practice in tech.get("practices", []):
                    lines.append(f"  - {practice}")
            lines.append("")

        if self.tech_stack.integrations:
            lines.append("### Integrations")
            lines.append("")
            for integration in self.tech_stack.integrations:
                pair = integration.get("pair", "Unknown")
                lines.append(f"**{pair}**")
                for practice in integration.get("practices", []):
                    lines.append(f"  - {practice}")
            lines.append("")

        if self.tech_stack.codebase_overrides:
            lines.append("### Codebase Conventions (override defaults)")
            lines.append("")
            for override in self.tech_stack.codebase_overrides:
                lines.append(f"- {override}")
            lines.append("")

        if self.tech_stack.raw_discovery:
            lines.append("### Auto-Detected")
            lines.append("")
            lines.append(", ".join(self.tech_stack.raw_discovery))
            lines.append("")

        # Brainstorming
        if self.brainstorming:
            lines += [
                "## Brainstorming",
                "",
                f"**Goal:** {self.brainstorming.goal}",
                "",
                "### Approach",
                "",
                self.brainstorming.approach,
                "",
            ]
            if self.brainstorming.thinking:
                lines += [
                    "### Thinking",
                    "",
                    self.brainstorming.thinking,
                    "",
                ]
            if self.brainstorming.risks:
                lines.append("### Risks")
                lines.append("")
                for risk in self.brainstorming.risks:
                    lines.append(f"- ⚠ {risk}")
                lines.append("")

        # Plan
        if self.plan and self.plan.steps:
            lines += [
                "## Plan",
                "",
                f"**Goal:** {self.plan.goal}",
                "",
            ]
            completed = sum(1 for s in self.plan.steps if s.get("completed"))
            total = len(self.plan.steps)
            lines.append(f"**Progress:** {completed}/{total} steps")
            lines.append("")
            for step in self.plan.steps:
                mark = "x" if step.get("completed") else " "
                desc = step.get("description", "")
                lines.append(f"- [{mark}] Step {step.get('step', '?')}: {desc}")
                if step.get("notes"):
                    lines.append(f"  - Notes: {step['notes']}")
            lines.append("")

        return "\n".join(lines)

    @classmethod
    def from_markdown(cls, content: str) -> SessionContext:
        """
        Parse context from Markdown.
        
        Note: This is a simplified parser. For complex cases,
        it's better to regenerate context from the session state.
        """
        ctx = cls()
        
        # Extract task description
        if "## Current Task" in content:
            start = content.find("## Current Task")
            end = content.find("\n##", start + 1)
            if end == -1:
                end = len(content)
            task_block = content[start:end]
            lines = task_block.split("\n")[2:]  # Skip header and empty line
            ctx.task_description = "\n".join(lines).strip()

        # Extract last updated
        if "*Last updated:" in content:
            start = content.find("*Last updated:") + len("*Last updated:")
            end = content.find("*", start)
            if end != -1:
                ctx.last_updated = content[start:end].strip()

        return ctx

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, working_dir: str | Path) -> Path:
        """
        Save context to .neoCoder/context.md.
        
        Args:
            working_dir: Project working directory.
            
        Returns:
            Path to saved file.
        """
        self.last_updated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        
        context_dir = Path(working_dir) / self._CONTEXT_DIR
        context_dir.mkdir(parents=True, exist_ok=True)
        
        context_file = context_dir / self._CONTEXT_FILENAME
        content = self.to_markdown()
        
        try:
            context_file.write_text(content, encoding="utf-8")
            logger.info("Session context saved to %s", context_file)
        except OSError as exc:
            logger.warning("Failed to save session context: %s", exc)
            
        return context_file

    @classmethod
    def load(cls, working_dir: str | Path) -> SessionContext | None:
        """
        Load context from .neoCoder/context.md if it exists.
        
        Args:
            working_dir: Project working directory.
            
        Returns:
            SessionContext if file exists and is valid, None otherwise.
        """
        context_file = Path(working_dir) / cls._CONTEXT_DIR / cls._CONTEXT_FILENAME
        
        if not context_file.exists():
            logger.debug("No session context file found at %s", context_file)
            return None
            
        try:
            content = context_file.read_text(encoding="utf-8")
            ctx = cls.from_markdown(content)
            logger.info("Session context loaded from %s", context_file)
            return ctx
        except OSError as exc:
            logger.warning("Failed to load session context: %s", exc)
            return None

    @classmethod
    def load_raw(cls, working_dir: str | Path) -> str | None:
        """
        Load raw context markdown for injection into agent prompt.
        
        Args:
            working_dir: Project working directory.
            
        Returns:
            Raw markdown content if file exists, None otherwise.
        """
        context_file = Path(working_dir) / cls._CONTEXT_DIR / cls._CONTEXT_FILENAME
        
        if not context_file.exists():
            return None
            
        try:
            return context_file.read_text(encoding="utf-8")
        except OSError as exc:
            logger.warning("Failed to read session context: %s", exc)
            return None

    # ------------------------------------------------------------------
    # Update methods
    # ------------------------------------------------------------------

    def update_tech_stack(
        self,
        technologies: list[dict[str, Any]] | None = None,
        integrations: list[dict[str, Any]] | None = None,
        codebase_overrides: list[str] | None = None,
        raw_discovery: list[str] | None = None,
    ) -> None:
        """Update tech stack context."""
        if technologies is not None:
            self.tech_stack.technologies = technologies
        if integrations is not None:
            self.tech_stack.integrations = integrations
        if codebase_overrides is not None:
            self.tech_stack.codebase_overrides = codebase_overrides
        if raw_discovery is not None:
            self.tech_stack.raw_discovery = raw_discovery

    def update_brainstorming(
        self,
        goal: str,
        thinking: str,
        approach: str,
        risks: list[str] | None = None,
    ) -> None:
        """Update brainstorming context."""
        self.brainstorming = BrainstormingContext(
            goal=goal,
            thinking=thinking,
            approach=approach,
            risks=risks or [],
            created_at=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        )

    def update_plan(
        self,
        goal: str,
        steps: list[dict[str, Any]],
    ) -> None:
        """Update plan context."""
        self.plan = PlanContext(
            goal=goal,
            steps=steps,
            created_at=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        )

    def update_plan_progress(self, step_number: int, notes: str = "") -> None:
        """Mark a plan step as completed."""
        if self.plan and 0 < step_number <= len(self.plan.steps):
            self.plan.steps[step_number - 1]["completed"] = True
            if notes:
                self.plan.steps[step_number - 1]["notes"] = notes


# ------------------------------------------------------------------
# Agent tool for reading context
# ------------------------------------------------------------------

def build_context_reader_tool() -> dict[str, Any]:
    """
    Build tool definition for reading session context.
    
    This allows the agent to explicitly request context when needed.
    """
    return {
        "name": "read_context",
        "description": (
            "Read the current session context including tech stack, brainstorming, and plan. "
            "Use this when you need to recall what was decided earlier or check the current plan progress. "
            "The context is also injected automatically at session start."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "section": {
                    "type": "string",
                    "enum": ["all", "tech_stack", "brainstorming", "plan"],
                    "description": "Which section to read (default: all)",
                },
            },
        },
    }


# Allow quick inspection: python -m neoCoder.sdk.extensions.session_context
if __name__ == "__main__":
    # Create sample context
    ctx = SessionContext()
    ctx.task_description = "Implement user authentication with JWT tokens"
    ctx.update_tech_stack(
        technologies=[
            {"name": "FastAPI", "version": "0.100+", "practices": [
                "Use dependency injection for auth middleware",
                "Prefer Pydantic models for request/response validation",
            ]},
            {"name": "SQLAlchemy", "version": "2.0", "practices": [
                "Use async session with asyncpg driver",
                "Prefer select() over legacy Query API",
            ]},
        ],
        integrations=[
            {"pair": "FastAPI + SQLAlchemy", "practices": [
                "Use async_scoped_session for request lifecycle",
                "Inject session via Depends()",
            ]},
        ],
        raw_discovery=["poetry", "pytest", "ruff", "mypy"],
    )
    ctx.update_strategy(
        goal="Implement JWT authentication",
        thinking="Need to use PyJWT for token handling...",
        approach="Use FastAPI OAuth2PasswordBearer with PyJWT",
        risks=["Token refresh strategy not defined"],
    )
    ctx.update_plan(
        goal="Implement JWT auth",
        steps=[
            {"step": 1, "description": "Create auth models", "completed": True, "notes": "Added User model"},
            {"step": 2, "description": "Implement token generation", "completed": False, "notes": ""},
            {"step": 3, "description": "Add auth middleware", "completed": False, "notes": ""},
        ],
    )

    print("=== Generated context.md ===")
    print(ctx.to_markdown())
