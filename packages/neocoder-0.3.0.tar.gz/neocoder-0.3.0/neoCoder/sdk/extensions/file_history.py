"""
File history manager for undo functionality.

Inspired by CCA-SWEBench's FileHistory pattern.
Maintains per-file edit history with tempfile backups for safe undo operations.
"""

from __future__ import annotations

import tempfile
import threading
from pathlib import Path


class FileHistory:
    """
    Manages file edit history for undo operations.
    
    Stores backups in a temporary directory and allows:
    - save_state(): Save current file state before modification
    - undo(): Restore previous version
    - get_first_version(): Get original version for diff
    - get_last_version(): Get most recent backup
    """
    
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._history: dict[Path, list[Path]] = {}
        self._temp_dir_obj = tempfile.TemporaryDirectory(prefix="neocoder_history_")
        self._temp_dir = Path(self._temp_dir_obj.name)
    
    def __del__(self) -> None:
        try:
            self._temp_dir_obj.cleanup()
        except Exception:
            pass
    
    def _create_backup(self, file_path: Path) -> Path:
        """Create a backup copy. Caller must hold self._lock."""
        if not file_path.exists():
            return Path()
        
        version = len(self._history.get(file_path, []))
        backup_path = self._temp_dir / f"{file_path.name}.{version}"
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        backup_path.write_bytes(file_path.read_bytes())
        return backup_path
    
    def save_state(self, file_path: Path) -> None:
        """Save current file state before modification."""
        file_path = Path(file_path).resolve()
        with self._lock:
            if file_path not in self._history:
                self._history[file_path] = []
            backup_path = self._create_backup(file_path)
            if backup_path.exists():
                self._history[file_path].append(backup_path)
    
    def has_history(self, file_path: Path) -> bool:
        """Check if file has undo history."""
        file_path = Path(file_path).resolve()
        with self._lock:
            return bool(self._history.get(file_path))
    
    def get_history_count(self, file_path: Path) -> int:
        """Get number of saved versions for a file."""
        file_path = Path(file_path).resolve()
        with self._lock:
            return len(self._history.get(file_path, []))
    
    def get_first_version(self, file_path: Path) -> Path:
        """Get the original version of the file."""
        file_path = Path(file_path).resolve()
        with self._lock:
            if file_path not in self._history or not self._history[file_path]:
                return Path()
            return self._history[file_path][0]
    
    def get_last_version(self, file_path: Path) -> Path:
        """Get the most recent backup version."""
        file_path = Path(file_path).resolve()
        with self._lock:
            if file_path not in self._history or not self._history[file_path]:
                return Path()
            return self._history[file_path][-1]
    
    def undo(self, file_path: Path) -> str:
        """
        Restore the previous version of the file.
        
        Args:
            file_path: Path to the file to undo
            
        Returns:
            Description of what was undone
            
        Raises:
            ValueError: If no history exists for the file
            FileNotFoundError: If backup is missing
        """
        file_path = Path(file_path).resolve()
        
        with self._lock:
            if file_path not in self._history or not self._history[file_path]:
                raise ValueError(f"No edit history for: {file_path}")
            backup_path = self._history[file_path].pop()
        
        if not backup_path.exists():
            raise FileNotFoundError(f"Backup missing for: {file_path}")
        
        try:
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_bytes(backup_path.read_bytes())
            backup_path.unlink()
            
            remaining = self.get_history_count(file_path)
            return f"Restored previous version. {remaining} more undo(s) available."
        except Exception as e:
            raise RuntimeError(f"Failed to restore: {e}")
    
    def undo_all(self, file_path: Path) -> str:
        """Restore the original version of the file."""
        file_path = Path(file_path).resolve()
        
        first_version = self.get_first_version(file_path)
        if not first_version or not first_version.exists():
            raise ValueError(f"No edit history for: {file_path}")
        
        try:
            file_path.write_bytes(first_version.read_bytes())
            
            with self._lock:
                for backup in self._history.get(file_path, []):
                    try:
                        backup.unlink()
                    except Exception:
                        pass
                self._history[file_path] = []
            
            return "Restored original version."
        except Exception as e:
            raise RuntimeError(f"Failed to restore original: {e}")
    
    def get_all_modified_files(self) -> list[Path]:
        """Get list of all files with edit history."""
        with self._lock:
            return [p for p, h in self._history.items() if h]
    
    def cleanup(self) -> None:
        """Clean up all backup files."""
        try:
            self._temp_dir_obj.cleanup()
        except Exception:
            pass
