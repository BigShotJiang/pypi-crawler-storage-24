"""
File editing extension for creating, reading, and modifying files.

Provides:
- File creation and writing
- File reading
- String replacement edits
- Diff generation for UX
- Compressed results for AX
"""

from __future__ import annotations

import os
import difflib
from pathlib import Path
from dataclasses import dataclass
from typing import Any

from neoCoder.sdk.extensions.base import Extension, ExtensionContext, ExecutionResult
from neoCoder.sdk.extensions.file_history import FileHistory
from neoCoder.sdk.llm.output_parser import Action


@dataclass
class FileEditConfig:
    """Configuration for file edit extension."""

    max_file_size: int = 1_000_000  # Max bytes to read
    max_lines_display: int = 500  # Max lines for UX display
    create_backups: bool = False  # Create .bak files (legacy)
    enable_undo: bool = True  # Enable undo history
    allowed_extensions: list[str] | None = None  # Restrict file types


class FileEditExtension(Extension):
    """
    Extension for file operations.

    Supports:
    - create: Create new file with content
    - read: Read file content
    - edit: Replace old_string with new_string
    - delete: Delete a file
    """

    def __init__(self, config: FileEditConfig | None = None):
        """
        Initialize file edit extension.

        Args:
            config: File edit configuration.
        """
        super().__init__()
        self.config = config or FileEditConfig()
        # Generic list of hooks called before write/edit (each must have pre_file_operation_hook)
        self._pre_operation_hooks: list = []
        # Hooks called AFTER a file is written to disk (each must have post_file_operation_hook)
        self._post_operation_hooks: list = []
        # Track all written/edited files for batch code review later
        self._written_files: list[str] = []
        # File history for undo operations
        self._history: FileHistory | None = FileHistory() if self.config.enable_undo else None

    @property
    def written_files(self) -> list[str]:
        """Files written/edited during this session (for batch code review)."""
        return list(self._written_files)

    def clear_written_files(self) -> None:
        """Reset the written-files tracker (called after batch review)."""
        self._written_files.clear()

    @property
    def name(self) -> str:
        return "file_edit"

    @property
    def xml_tags(self) -> list[str]:
        return ["file_edit", "file_read", "file_write", "file_undo"]

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        return [
            {
                "name": "file_read",
                "description": "Read the contents of a file. Use this to examine existing code or configuration.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to the file to read",
                        },
                        "offset": {
                            "type": "integer",
                            "description": "Line number to start reading from (0-indexed)",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum number of lines to read",
                        },
                    },
                    "required": ["file_path"],
                },
            },
            {
                "name": "file_write",
                "description": "Create or overwrite a file with new content.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to the file to create/write",
                        },
                        "content": {
                            "type": "string",
                            "description": "Content to write to the file",
                        },
                    },
                    "required": ["file_path", "content"],
                },
            },
            {
                "name": "file_edit",
                "description": "Edit a file by replacing old_string with new_string. The old_string must match exactly.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to the file to edit",
                        },
                        "old_string": {
                            "type": "string",
                            "description": "The exact string to find and replace",
                        },
                        "new_string": {
                            "type": "string",
                            "description": "The string to replace it with",
                        },
                    },
                    "required": ["file_path", "old_string", "new_string"],
                },
            },
            {
                "name": "file_undo",
                "description": "Undo the last edit to a file. Use when you made a mistake and need to revert changes.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to the file to undo",
                        },
                        "undo_all": {
                            "type": "boolean",
                            "description": "If true, restore the original version (undo all edits)",
                        },
                    },
                    "required": ["file_path"],
                },
            },
        ]

    def can_handle(self, action: Action) -> bool:
        """Check if we can handle this action."""
        return action.name in ["file_edit", "file_read", "file_write", "file_delete", "file_undo"]

    def _resolve_path(self, file_path: str, context: ExtensionContext) -> Path:
        """Resolve file path relative to working directory."""
        path = Path(file_path)
        if not path.is_absolute():
            path = Path(context.working_dir) / path
        return path.resolve()

    def _generate_diff(self, old_content: str, new_content: str, file_path: str) -> str:
        """Generate a unified diff between old and new content."""
        old_lines = old_content.splitlines(keepends=True)
        new_lines = new_content.splitlines(keepends=True)

        diff = difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{file_path}",
            tofile=f"b/{file_path}",
        )
        return "".join(diff)
    
    def _call_pre_file_operation_hook(
        self,
        operation: str,
        file_path: str,
        content: str,
    ) -> dict[str, Any] | None:
        """
        Call all registered pre-file-operation hooks and merge results.

        Hooks are invoked in order. The first *blocking* result wins;
        otherwise results are merged (issues appended, worst score kept).

        Args:
            operation: Operation type (write/edit)
            file_path: Path to file
            content: File content

        Returns:
            Merged hook result dict, or None if no hooks fired.
        """
        # Collect all hook providers
        providers: list = list(self._pre_operation_hooks)

        if not providers:
            return None

        merged: dict[str, Any] | None = None

        for hook in providers:
            if not hasattr(hook, "pre_file_operation_hook"):
                continue
            try:
                result = hook.pre_file_operation_hook(
                    operation=operation,
                    file_path=file_path,
                    content=content,
                )
            except Exception as e:
                import logging
                logging.getLogger(__name__).warning(
                    "Pre-file hook %s failed: %s", type(hook).__name__, e
                )
                continue

            if not result or not result.get("reviewed", False):
                continue

            if merged is None:
                merged = dict(result)
            else:
                # Merge: append details, keep worst score, OR block
                merged["blocked"] = merged.get("blocked", False) or result.get("blocked", False)
                merged["issues"] = merged.get("issues", 0) + result.get("issues", 0)
                if result.get("details"):
                    prev = merged.get("details") or ""
                    merged["details"] = prev + "\n" + result["details"]
                if result.get("reason"):
                    prev = merged.get("reason") or ""
                    merged["reason"] = (prev + "; " + result["reason"]).lstrip("; ")
                if result.get("issues_list"):
                    prev = merged.get("issues_list") or []
                    merged["issues_list"] = prev + result["issues_list"]
                merged["needs_improvement"] = (
                    merged.get("needs_improvement", False)
                    or result.get("needs_improvement", False)
                )
                # Keep the worst (lowest) score
                merged["score"] = min(
                    merged.get("score", 100), result.get("score", 100)
                )

        return merged

    def _call_post_file_operation_hook(
        self,
        file_path: str,
        project_dir: str,
    ) -> dict[str, Any] | None:
        """
        Call all registered post-file-operation hooks AFTER a file
        has been written to disk.  Hooks run real project tools
        (linters, compilers, schema validators) on the actual file.

        Returns:
            Merged result dict, or None if no hooks fired.
        """
        if not self._post_operation_hooks:
            return None

        merged: dict[str, Any] | None = None

        for hook in self._post_operation_hooks:
            if not hasattr(hook, "post_file_operation_hook"):
                continue
            try:
                result = hook.post_file_operation_hook(
                    file_path=file_path,
                    project_dir=project_dir,
                )
            except Exception as e:
                import logging
                logging.getLogger(__name__).warning(
                    "Post-file hook %s failed: %s", type(hook).__name__, e,
                )
                continue

            if not result:
                continue

            if merged is None:
                merged = dict(result)
            else:
                # Merge: concatenate outputs, combine issues
                if result.get("output"):
                    prev = merged.get("output") or ""
                    merged["output"] = (prev + "\n" + result["output"]).strip()
                if result.get("issues_list"):
                    prev = merged.get("issues_list") or []
                    merged["issues_list"] = prev + result["issues_list"]
                merged["has_errors"] = (
                    merged.get("has_errors", False)
                    or result.get("has_errors", False)
                )

        return merged

    def execute(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """
        Execute a file operation.

        Args:
            action: Action to execute.
            context: Extension context.

        Returns:
            ExecutionResult with operation result.
        """
        # Route to specific handler based on action name
        if action.name == "file_read":
            return self._handle_read(action, context)
        elif action.name == "file_write":
            return self._handle_write(action, context)
        elif action.name == "file_edit":
            return self._handle_edit(action, context)
        elif action.name == "file_delete":
            return self._handle_delete(action, context)
        elif action.name == "file_undo":
            return self._handle_undo(action, context)
        else:
            return ExecutionResult.error_result(f"Unknown file action: {action.name}")

    def _handle_read(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle file read operation."""
        file_path = action.input.get("file_path")
        if not file_path:
            return ExecutionResult.error_result("file_path is required")

        path = self._resolve_path(file_path, context)

        if context.metadata.get("suppress_file_read_user_output"):
            user_output_override = None
        else:
            user_output_override = ...

        if not path.exists():
            return ExecutionResult.error_result(f"File not found: {file_path}")

        if not path.is_file():
            return ExecutionResult.error_result(f"Not a file: {file_path}")

        try:
            # Check file size
            file_size = path.stat().st_size
            if file_size > self.config.max_file_size:
                return ExecutionResult.error_result(
                    f"File too large ({file_size} bytes). Max: {self.config.max_file_size}"
                )

            content = path.read_text(encoding="utf-8")
            lines = content.splitlines()

            # Handle offset and limit
            offset = action.input.get("offset", 0)
            limit = action.input.get("limit", len(lines))

            if offset > 0 or limit < len(lines):
                selected_lines = lines[offset : offset + limit]
                content = "\n".join(selected_lines)

            # User output with line numbers
            numbered_lines = [
                f"{i + offset + 1:4d} | {line}"
                for i, line in enumerate(content.splitlines())
            ]
            user_output = f"File: {file_path}\n" + "\n".join(numbered_lines[:self.config.max_lines_display])
            if len(numbered_lines) > self.config.max_lines_display:
                user_output += f"\n... ({len(numbered_lines) - self.config.max_lines_display} more lines)"

            # Agent gets raw content
            return ExecutionResult.success_result(
                output=content,
                user_output=user_output if user_output_override is ... else user_output_override,
            )

        except UnicodeDecodeError:
            return ExecutionResult.error_result(f"Cannot read binary file: {file_path}")
        except Exception as e:
            return ExecutionResult.error_result(f"Error reading file: {str(e)}")

    def _handle_write(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle file write/create operation."""
        file_path = action.input.get("file_path")
        content = action.input.get("content", "")

        if not file_path:
            return ExecutionResult.error_result("file_path is required")

        path = self._resolve_path(file_path, context)

        try:
            # Create parent directories if needed
            path.parent.mkdir(parents=True, exist_ok=True)

            # Save state for undo before modification
            if self._history and path.exists():
                self._history.save_state(path)

            # Create backup if configured and file exists (legacy)
            if self.config.create_backups and path.exists():
                backup_path = path.with_suffix(path.suffix + ".bak")
                backup_path.write_text(path.read_text(), encoding="utf-8")

            is_new = not path.exists()
            path.write_text(content, encoding="utf-8")

            # Track file for batch code review (Stage 6)
            file_str = str(path)
            if file_str not in self._written_files:
                self._written_files.append(file_str)

            # Post-write verification (linters, compilers)
            post_result = self._call_post_file_operation_hook(
                file_path=file_str,
                project_dir=context.working_dir,
            )

            # Generate output
            action_type = "Created" if is_new else "Updated"
            line_count = len(content.splitlines())
            preview_lines = content.splitlines()[:20]
            preview = "\n".join(preview_lines)
            if len(content.splitlines()) > 20:
                preview += f"\n... ({len(content.splitlines()) - 20} more lines)"

            user_output = f"{action_type} file: {path} ({line_count} lines)\n{preview}"
            agent_output = f"File {action_type.lower()} successfully: {path}"

            # Append post-write verification results
            if post_result and post_result.get("output"):
                verification_output = post_result["output"]
                user_output += f"\n\n🔍 Post-write verification:\n{verification_output}"
                agent_output += f"\n\n🔍 POST-WRITE VERIFICATION:\n{verification_output}"
                if post_result.get("has_errors"):
                    agent_output += (
                        "\n\n❌ VERIFICATION FAILED. The file was written but the project's "
                        "own tools found errors. You MUST fix these errors now — "
                        "re-read the output above, edit the file, and retry."
                    )

            return ExecutionResult.success_result(
                output=agent_output,
                user_output=user_output,
                artifacts={"last_written_file": file_str},
            )

        except Exception as e:
            return ExecutionResult.error_result(f"Error writing file: {str(e)}")

    def _handle_edit(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle file edit (string replacement) operation."""
        file_path = action.input.get("file_path")
        old_string = action.input.get("old_string", "")
        new_string = action.input.get("new_string", "")

        if not file_path:
            return ExecutionResult.error_result("file_path is required")

        if not old_string:
            return ExecutionResult.error_result("old_string is required")

        path = self._resolve_path(file_path, context)

        if not path.exists():
            return ExecutionResult.error_result(f"File not found: {file_path}")

        try:
            old_content = path.read_text(encoding="utf-8")

            # Check if old_string exists
            if old_string not in old_content:
                return ExecutionResult.error_result(
                    f"old_string not found in {file_path}. "
                    "Make sure the string matches exactly including whitespace."
                )

            # Count occurrences
            occurrences = old_content.count(old_string)
            if occurrences > 1:
                return ExecutionResult.error_result(
                    f"old_string found {occurrences} times in {file_path}. "
                    "Please provide a more specific string to ensure unique match."
                )

            # Perform replacement
            new_content = old_content.replace(old_string, new_string, 1)

            # Save state for undo before modification
            if self._history:
                self._history.save_state(path)

            # Create backup if configured (legacy)
            if self.config.create_backups:
                backup_path = path.with_suffix(path.suffix + ".bak")
                backup_path.write_text(old_content, encoding="utf-8")

            # Write new content
            path.write_text(new_content, encoding="utf-8")

            # Track file for batch code review (Stage 6)
            file_str = str(path)
            if file_str not in self._written_files:
                self._written_files.append(file_str)

            # Post-write verification (linters, compilers)
            post_result = self._call_post_file_operation_hook(
                file_path=file_str,
                project_dir=context.working_dir,
            )

            # Generate diff for user
            diff = self._generate_diff(old_content, new_content, file_path)
            user_output = f"Edited file: {file_path}\n\n{diff}"
            agent_output = f"File edited successfully: {file_path}"

            # Append post-write verification results
            if post_result and post_result.get("output"):
                verification_output = post_result["output"]
                user_output += f"\n\n🔍 Post-write verification:\n{verification_output}"
                agent_output += f"\n\n🔍 POST-WRITE VERIFICATION:\n{verification_output}"
                if post_result.get("has_errors"):
                    agent_output += (
                        "\n\n❌ VERIFICATION FAILED. The file was written but the project's "
                        "own tools found errors. You MUST fix these errors now — "
                        "re-read the output above, edit the file, and retry."
                    )

            return ExecutionResult.success_result(
                output=agent_output,
                user_output=user_output,
                artifacts={"last_edited_file": file_str},
            )

        except Exception as e:
            return ExecutionResult.error_result(f"Error editing file: {str(e)}")

    def _handle_delete(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle file delete operation."""
        file_path = action.input.get("file_path")

        if not file_path:
            return ExecutionResult.error_result("file_path is required")

        path = self._resolve_path(file_path, context)

        if not path.exists():
            return ExecutionResult.error_result(f"File not found: {file_path}")

        try:
            path.unlink()

            user_output = f"Deleted file: {file_path}"

            return ExecutionResult.success_result(
                output=f"File deleted: {file_path}",
                user_output=user_output,
            )

        except Exception as e:
            return ExecutionResult.error_result(f"Error deleting file: {str(e)}")

    def _handle_undo(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle file undo operation."""
        if not self._history:
            return ExecutionResult.error_result("Undo is disabled in configuration")

        file_path = action.input.get("file_path")
        undo_all = action.input.get("undo_all", False)

        if not file_path:
            return ExecutionResult.error_result("file_path is required")

        path = self._resolve_path(file_path, context)

        if not self._history.has_history(path):
            return ExecutionResult.error_result(f"No edit history for: {file_path}")

        try:
            if undo_all:
                result = self._history.undo_all(path)
            else:
                result = self._history.undo(path)

            user_output = f"⏪ Undo: {file_path}\n{result}"

            return ExecutionResult.success_result(
                output=result,
                user_output=user_output,
            )

        except ValueError as e:
            return ExecutionResult.error_result(str(e))
        except Exception as e:
            return ExecutionResult.error_result(f"Error during undo: {str(e)}")

    def run_deferred_build_verification(
        self,
        project_dir: str,
    ) -> dict[str, Any] | None:
        """
        Trigger deferred project-scope build verification on all
        post-operation hooks that support it.  Should be called once
        at the end, when all plan items are done.

        Returns merged {output, has_errors, issues_list} or None.
        """
        if not self._post_operation_hooks:
            return None

        merged: dict[str, Any] | None = None

        for hook in self._post_operation_hooks:
            if not hasattr(hook, "run_deferred_build_verification"):
                continue
            try:
                result = hook.run_deferred_build_verification(
                    project_dir=project_dir,
                )
            except Exception as e:
                import logging
                logging.getLogger(__name__).warning(
                    "Deferred build hook %s failed: %s",
                    type(hook).__name__, e,
                )
                continue

            if not result:
                continue

            if merged is None:
                merged = dict(result)
            else:
                if result.get("output"):
                    prev = merged.get("output") or ""
                    merged["output"] = (prev + "\n" + result["output"]).strip()
                if result.get("issues_list"):
                    prev = merged.get("issues_list") or []
                    merged["issues_list"] = prev + result["issues_list"]
                merged["has_errors"] = (
                    merged.get("has_errors", False)
                    or result.get("has_errors", False)
                )

        return merged

    def signals_continuation(self) -> bool:
        """File operations typically want continuation."""
        return True
