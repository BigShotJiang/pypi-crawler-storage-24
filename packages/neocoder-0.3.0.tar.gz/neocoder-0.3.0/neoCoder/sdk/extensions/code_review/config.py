"""
Configuration for code review extension.

Slim config — rules live in ``coding_rules.py`` (single source of truth).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List
from pathlib import Path
import json


@dataclass
class CodeReviewConfig:
    """Configuration for the prompt-based code review extension."""

    enabled: bool = True

    # Review iteration settings
    max_review_iterations: int = 5

    # Glob patterns for files to skip
    ignore_patterns: List[str] = field(default_factory=lambda: [
        "**/__pycache__/**",
        "**/node_modules/**",
        "**/dist/**",
        "**/build/**",
        "**/.git/**",
        "**/*.min.js",
        "**/*.min.css",
    ])

    @classmethod
    def from_file(cls, config_path: Path) -> CodeReviewConfig:
        """Load configuration from JSON file."""
        try:
            data = json.loads(config_path.read_text(encoding="utf-8"))
            return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
        except Exception:
            return cls()
