"""
Code Review Extension — prompt-based.

No regex, no AST, no static analysis.  Instead, the extension:
  1. Collects the list of files written/edited during the session.
  2. Reads their contents.
  3. Builds a review prompt from ``coding_rules.py`` (single source of truth).
  4. Returns the prompt + file contents to the agent so it can review
     them using its full semantic understanding.

The agent IS the reviewer.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

from neoCoder.sdk.extensions.base import Extension, ExtensionContext, ExecutionResult
from neoCoder.sdk.llm.output_parser import Action

from .config import CodeReviewConfig


class CodeReviewExtension(Extension):
    """
    Lightweight code review extension.

    Provides ``batch_review`` and ``review_code`` actions that return
    file contents + coding rules so the **agent** performs the review
    (no brittle regex engine).
    """

    def __init__(self, config: Optional[CodeReviewConfig] = None):
        super().__init__()
        self.config = config or CodeReviewConfig()
        # Set by orchestrator — gives access to written_files list
        self._file_edit_extension = None

    # -----------------------------------------------------------------
    # Extension interface
    # -----------------------------------------------------------------

    @property
    def name(self) -> str:
        return "code_review"

    @property
    def xml_tags(self) -> list[str]:
        return ["code_review", "review", "batch_review"]

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        return [
            {
                "name": "review_code",
                "description": "Review a single file against coding standards.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to file to review",
                        },
                    },
                    "required": ["file_path"],
                },
            },
            {
                "name": "batch_review",
                "description": (
                    "Batch review: reviews ALL files written/edited in this session. "
                    "No arguments needed — file list is collected automatically."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "file_paths": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Override: explicit list of file paths (optional).",
                        },
                    },
                    "required": [],
                },
            },
        ]

    def can_handle(self, action: Action) -> bool:
        return action.name in {"review_code", "code_review", "review", "batch_review"}

    def execute(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        if not self.config.enabled:
            return ExecutionResult.success_result(
                output="Code review is disabled.", user_output="⚠️ Code review disabled.")

        if action.name == "batch_review":
            return self._batch_review(action, context)
        return self._single_review(action, context)

    def signals_continuation(self) -> bool:
        return False

    # -----------------------------------------------------------------
    # Hook compatibility (no-op: we removed per-save review)
    # -----------------------------------------------------------------

    def pre_file_operation_hook(self, **_kwargs) -> dict[str, Any]:
        """No-op — review happens in batch at Stage 6, not on every save."""
        return {"reviewed": False}

    # -----------------------------------------------------------------
    # Single-file review
    # -----------------------------------------------------------------

    def _single_review(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        file_path = action.input.get("file_path", "")
        if not file_path:
            return ExecutionResult.error_result("file_path is required")

        content = self._read_file(file_path)
        if content is None:
            return ExecutionResult.error_result(f"Cannot read file: {file_path}")

        prompt = self._build_review_prompt({file_path: content})

        return ExecutionResult.success_result(
            output=prompt,
            user_output=f"📝 Reviewing: {file_path}",
        )

    # -----------------------------------------------------------------
    # Batch review  (Stage 6 entry point)
    # -----------------------------------------------------------------

    def _batch_review(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        file_paths = action.input.get("file_paths") or self._get_tracked_files(context)

        if not file_paths:
            return ExecutionResult.success_result(
                output="No files to review — nothing was written/edited.",
                user_output="✅ No files to review.")

        # Read all files
        file_contents: dict[str, str] = {}
        errors: list[str] = []
        for fpath in file_paths:
            content = self._read_file(fpath)
            if content is not None:
                file_contents[fpath] = content
            else:
                errors.append(fpath)

        if not file_contents:
            return ExecutionResult.error_result(
                f"Could not read any of the {len(file_paths)} tracked files.")

        prompt = self._build_review_prompt(file_contents)

        if errors:
            prompt += f"\n\n⚠️ Could not read {len(errors)} file(s): {', '.join(errors)}"

        user_output = f"📝 Batch review: {len(file_contents)} file(s)"

        context.store_artifact("batch_review_files", list(file_contents.keys()))

        return ExecutionResult.success_result(
            output=prompt, user_output=user_output)

    # -----------------------------------------------------------------
    # Prompt builder
    # -----------------------------------------------------------------

    @staticmethod
    def _build_review_prompt(files: dict[str, str]) -> str:
        """
        Build a review prompt from coding_rules + file contents.

        The agent receives this and performs the review using its full
        semantic understanding — no regex needed.
        """
        from neoCoder.nca.coding_rules import build_coding_prompt

        parts: list[str] = []

        parts.append("# Code Review Task\n")
        parts.append("Review the following file(s) against the coding standards below.")
        parts.append("For EACH file, list every violation you find with:")
        parts.append("  - File path and line number (or range)")
        parts.append("  - Which rule is violated")
        parts.append("  - Concrete fix suggestion")
        parts.append("")
        parts.append("After listing all issues, fix them all.")
        parts.append("If a file has NO issues, say so explicitly.\n")

        # Rules
        parts.append(build_coding_prompt())
        parts.append("")

        # Files
        parts.append("---\n")
        parts.append(f"## Files to Review ({len(files)})\n")
        for fpath, content in files.items():
            parts.append(f"### `{fpath}`\n```")
            parts.append(content)
            parts.append("```\n")

        return "\n".join(parts)

    # -----------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------

    def _get_tracked_files(self, context: ExtensionContext) -> list[str] | None:
        """Get list of written/edited files from file_edit extension."""
        if self._file_edit_extension is not None:
            return getattr(self._file_edit_extension, "written_files", None)
        return context.get_artifact("written_files")

    @staticmethod
    def _read_file(file_path: str) -> str | None:
        """Read file content, return None on failure."""
        try:
            return Path(file_path).read_text(encoding="utf-8")
        except Exception:
            return None
