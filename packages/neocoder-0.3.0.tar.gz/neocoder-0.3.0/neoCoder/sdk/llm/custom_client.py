"""
Custom API client for non-Anthropic endpoints.

Supports custom base_url and model name formatting.
Used for ZenMux and other compatible providers.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Callable

import anthropic
import httpx
from anthropic.types import Message, ToolUseBlock, TextBlock

from neoCoder.sdk.llm.base_client import BaseLLMClient, ToolDefinition, LLMResponse
from neoCoder.sdk.llm.output_parser import Action, OutputParser
from neoCoder.sdk.llm.native_client import ClaudeClientConfig


logger = logging.getLogger(__name__)


class CustomAPIClient(BaseLLMClient):
    """
    Custom API client for non-Anthropic endpoints.
    
    Supports custom base_url and model name formatting.
    Used for ZenMux and other compatible providers.
    """

    def __init__(self, config: ClaudeClientConfig | None = None, **kwargs):
        """
        Initialize custom API client.
        
        Args:
            config: Client configuration. If not provided, uses defaults.
            **kwargs: Override specific config values.
        
        Raises:
            ValueError: If API key is not provided.
        """
        if config is None:
            config = ClaudeClientConfig()

        # Apply any overrides
        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)

        self.config = config
        self._api_key = config.api_key or os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN")

        if not self._api_key:
            raise ValueError(
                "API key required.\n\n"
                "Set environment variable:\n"
                "  Windows CMD:        set ANTHROPIC_API_KEY=your-key\n"
                "  Windows PowerShell: $env:ANTHROPIC_API_KEY=\"your-key\"\n"
                "  Linux/macOS:        export ANTHROPIC_API_KEY=your-key\n\n"
                "Or edit ~/.neoCoder/settings.json and add your key to 'anthropic.auth_token'\n\n"
                "To create config: neocoder \\init-config"
            )

        # Initialize with custom base_url
        client_kwargs = {"api_key": self._api_key}
        if config.base_url:
            client_kwargs["base_url"] = config.base_url
            logger.info(f"Initialized CustomAPIClient with base_url: {config.base_url}")
        else:
            logger.info("Initialized CustomAPIClient without base_url")
        
        # Add custom headers if provided (for proxy/custom endpoints)
        if config.default_headers:
            client_kwargs["default_headers"] = config.default_headers
            logger.info(f"Added custom headers: {list(config.default_headers.keys())}")

        self._client = anthropic.Anthropic(**client_kwargs)
        self._parser = OutputParser()
        self._tools: list[ToolDefinition] = []

    def _calculate_thinking_budget(self, max_tokens: int) -> int | None:
        """
        Auto-calculate thinking_budget based on thinking_effort and max_tokens.
        
        Similar to OpenAI's reasoning.max_tokens calculation:
        - low: 20% of max_tokens
        - medium: 50% of max_tokens  
        - high: 80% of max_tokens
        
        Anthropic API Requirements:
        - budget_tokens must be >= 1024
        - budget_tokens must be < max_tokens
        
        Args:
            max_tokens: Maximum completion tokens
            
        Returns:
            Calculated thinking_budget or None if thinking not enabled
        """
        # If thinking_budget explicitly set, validate and use it
        if self.config.thinking_budget is not None:
            budget = self.config.thinking_budget
            
            # Validate: must be >= 1024
            if budget < 1024:
                logger.warning(f"thinking_budget ({budget}) < 1024, setting to minimum 1024")
                budget = 1024
            
            # Validate: must be < max_tokens
            if budget >= max_tokens:
                logger.warning(f"thinking_budget ({budget}) >= max_tokens ({max_tokens}), adjusting")
                budget = max(1024, max_tokens - 1024)
            
            return budget
            
        # If thinking_effort not set, no auto-calculation
        if not self.config.thinking_effort:
            return None
            
        # Calculate based on effort level
        effort_ratios = {
            "low": 0.20,
            "medium": 0.50,
            "high": 0.80
        }
        
        effort = self.config.thinking_effort.lower()
        if effort not in effort_ratios:
            logger.warning(f"Invalid thinking_effort '{effort}', expected low/medium/high")
            return None
            
        budget = int(max_tokens * effort_ratios[effort])
        
        # Ensure minimum 1024 tokens
        if budget < 1024:
            logger.warning(f"Calculated budget ({budget}) < 1024, setting to minimum")
            budget = 1024
        
        # Ensure < max_tokens
        if budget >= max_tokens:
            logger.warning(f"Calculated budget ({budget}) >= max_tokens ({max_tokens}), adjusting")
            budget = max(1024, max_tokens - 1024)
        
        logger.debug(f"Auto-calculated thinking_budget: {budget} ({effort} effort, {max_tokens} max_tokens)")
        return budget

    def _format_model_name(self, model: str) -> str:
        """
        Format model name for the target API.
        
        ZenMux uses format like "anthropic/claude-sonnet-4.5"
        while Anthropic uses "claude-sonnet-4-5-20241022"
        
        Args:
            model: Original model name.
            
        Returns:
            Formatted model name.
        """
        if not self.config.use_zenmux_format:
            return model

        # Convert Anthropic format to ZenMux format
        # claude-sonnet-4-5-20241022 -> anthropic/claude-sonnet-4.5
        if model.startswith("claude-"):
            parts = model.split("-")
            if len(parts) >= 4:
                # Extract base name and version
                base = "-".join(parts[:3])  # claude-sonnet-4
                version = parts[3] if len(parts) > 3 else "5"
                return f"anthropic/{base}.{version}"

        return model

    def _ensure_user_message_last(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """
        Ensure messages end with a user message.
        
        Some API providers (like ZenMux) don't support assistant message prefill
        and require the conversation to end with a user message.
        
        If the last message is an assistant message, we append a placeholder
        user message to satisfy the API requirement.
        
        Args:
            messages: List of conversation messages.
            
        Returns:
            Modified messages list ending with a user message.
        """
        if not messages:
            return messages
        
        # Check if last message is assistant
        last_message = messages[-1]
        if last_message.get("role") == "assistant":
            # Append a placeholder user message
            messages = messages.copy()
            messages.append({
                "role": "user",
                "content": "Continue."
            })
            logger.debug("Added placeholder user message to satisfy API requirement (no assistant prefill)")
        
        return messages

    def invoke(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
    ) -> LLMResponse:
        """
        Invoke the LLM with the given messages.

        Args:
            messages: List of conversation messages.
            system: Optional system prompt.
            tools: Optional tools to use for this invocation (overrides registered tools).

        Returns:
            LLMResponse containing the response content and any parsed actions.
        """
        # Ensure messages end with user message (required by some providers)
        messages = self._ensure_user_message_last(messages)
        
        # Build request kwargs
        request_kwargs: dict[str, Any] = {
            "model": self._format_model_name(self.config.model),
            "max_tokens": self.config.max_tokens,
            "messages": messages,
        }

        if system:
            request_kwargs["system"] = system

        # Sampling parameters
        if self.config.top_p is not None:
            request_kwargs["top_p"] = self.config.top_p
        if self.config.top_k is not None:
            request_kwargs["top_k"] = self.config.top_k
        if self.config.stop_sequences:
            request_kwargs["stop_sequences"] = self.config.stop_sequences

        # Metadata (user_id for tracking)
        metadata: dict[str, Any] = {}
        if self.config.metadata:
            metadata.update(self.config.metadata)
        if self.config.user_id:
            metadata.setdefault("user_id", self.config.user_id)
        if metadata:
            request_kwargs["metadata"] = metadata

        # Cache control
        if self.config.cache_control:
            request_kwargs["cache_control"] = self.config.cache_control

        # Add tools if using native tool use
        active_tools = tools if tools is not None else self._tools
        if self.config.use_native_tools and active_tools:
            request_kwargs["tools"] = [
                {
                    "name": t.name,
                    "description": t.description,
                    "input_schema": t.input_schema,
                }
                for t in active_tools
            ]
            # Tool choice (only valid when tools present)
            if self.config.tool_choice is not None:
                request_kwargs["tool_choice"] = self.config.tool_choice

        # Add thinking parameter for Anthropic Extended Thinking
        # When thinking is enabled: temperature MUST be 1, max_tokens > thinking_budget
        # See: https://docs.anthropic.com/en/docs/build-with-claude/extended-thinking
        thinking_budget = self._calculate_thinking_budget(self.config.max_tokens)
        thinking_mode = (self.config.thinking_mode or "auto").lower()
        thinking: dict[str, Any] | None = None

        if thinking_mode == "disabled":
            thinking = {"type": "disabled"}
        elif thinking_budget:
            # Ensure max_tokens > thinking_budget, but don't exceed model's limit
            if self.config.max_tokens <= thinking_budget:
                # Cap at model's maximum (64000 for Claude Sonnet 4.5)
                request_kwargs["max_tokens"] = min(thinking_budget + 1024, 64000)
            t_type = "enabled"
            if thinking_mode == "adaptive":
                t_type = "adaptive"
            elif thinking_mode not in ("auto", "enabled"):
                logger.warning(f"Unknown thinking_mode '{thinking_mode}', defaulting to 'enabled'")
            thinking = {
                "type": t_type,
                "budget_tokens": thinking_budget,
            }

        if thinking:
            if self.config.thinking_display:
                thinking["display"] = self.config.thinking_display
            request_kwargs["thinking"] = thinking
            # Extended Thinking constraint: temperature must be 1, top_k not allowed
            request_kwargs["temperature"] = 1
            if "top_k" in request_kwargs:
                logger.warning("top_k is not supported with Extended Thinking; removing top_k")
                request_kwargs.pop("top_k", None)
        elif self.config.temperature > 0:
            request_kwargs["temperature"] = self.config.temperature

        # Make the API call
        response = self._client.messages.create(**request_kwargs)

        # Parse response
        content_text = ""
        actions: list[Action] = []

        for block in response.content:
            if isinstance(block, TextBlock):
                content_text += block.text
            elif isinstance(block, ToolUseBlock):
                actions.append(
                    Action(
                        type="tool_use",
                        name=block.name,
                        input=block.input,
                        id=block.id,
                    )
                )

        # If not using native tools, parse XML tags from text
        if not self.config.use_native_tools and content_text:
            xml_actions = self._parser.parse_xml_tags(content_text)
            actions.extend(xml_actions)

        # Extract generation ID from response
        generation_id = getattr(response, 'id', None)

        return LLMResponse(
            content=content_text,
            actions=actions,
            raw_response=response,
            stop_reason=response.stop_reason,
            usage={
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens,
            },
            generation_id=generation_id,
        )

    def invoke_stream(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
        on_text: Callable[[str], None] | None = None,
    ) -> LLMResponse:
        """
        Invoke the LLM with streaming, calling on_text for each text chunk.

        Args:
            messages: List of conversation messages.
            system: Optional system prompt.
            tools: Optional tools for this invocation.
            on_text: Callback for each text chunk.

        Returns:
            Complete LLMResponse after stream finishes.
        """
        # Ensure messages end with user message (required by some providers)
        messages = self._ensure_user_message_last(messages)
        
        request_kwargs: dict[str, Any] = {
            "model": self._format_model_name(self.config.model),
            "max_tokens": self.config.max_tokens,
            "messages": messages,
        }

        if system:
            request_kwargs["system"] = system

        # Sampling parameters
        if self.config.top_p is not None:
            request_kwargs["top_p"] = self.config.top_p
        if self.config.top_k is not None:
            request_kwargs["top_k"] = self.config.top_k
        if self.config.stop_sequences:
            request_kwargs["stop_sequences"] = self.config.stop_sequences

        # Metadata (user_id for tracking)
        metadata: dict[str, Any] = {}
        if self.config.metadata:
            metadata.update(self.config.metadata)
        if self.config.user_id:
            metadata.setdefault("user_id", self.config.user_id)
        if metadata:
            request_kwargs["metadata"] = metadata

        # Cache control
        if self.config.cache_control:
            request_kwargs["cache_control"] = self.config.cache_control

        active_tools = tools if tools is not None else self._tools
        if self.config.use_native_tools and active_tools:
            request_kwargs["tools"] = [
                {
                    "name": t.name,
                    "description": t.description,
                    "input_schema": t.input_schema,
                }
                for t in active_tools
            ]
            # Tool choice (only valid when tools present)
            if self.config.tool_choice is not None:
                request_kwargs["tool_choice"] = self.config.tool_choice

        # Add thinking parameter for Anthropic Extended Thinking
        # When thinking is enabled: temperature MUST be 1, max_tokens > thinking_budget
        thinking_budget = self._calculate_thinking_budget(self.config.max_tokens)
        thinking_mode = (self.config.thinking_mode or "auto").lower()
        thinking: dict[str, Any] | None = None

        if thinking_mode == "disabled":
            thinking = {"type": "disabled"}
        elif thinking_budget:
            # Ensure max_tokens > thinking_budget, but don't exceed model's limit
            current_max_tokens = request_kwargs["max_tokens"]
            
            if current_max_tokens <= thinking_budget:
                # Need to increase max_tokens to be > thinking_budget
                # Cap at model's maximum (64000 for Claude Sonnet 4.5)
                new_max_tokens = min(thinking_budget + 1024, 64000)
                request_kwargs["max_tokens"] = new_max_tokens
                logger.debug(
                    f"Adjusted max_tokens from {current_max_tokens} to {new_max_tokens} "
                    f"(thinking_budget={thinking_budget})"
                )
            else:
                logger.debug(
                    f"max_tokens={current_max_tokens} > thinking_budget={thinking_budget}, OK"
                )
            
            t_type = "enabled"
            if thinking_mode == "adaptive":
                t_type = "adaptive"
            elif thinking_mode not in ("auto", "enabled"):
                logger.warning(f"Unknown thinking_mode '{thinking_mode}', defaulting to 'enabled'")
            thinking = {
                "type": t_type,
                "budget_tokens": thinking_budget,
            }

        if thinking:
            if self.config.thinking_display:
                thinking["display"] = self.config.thinking_display
            request_kwargs["thinking"] = thinking
            # Extended Thinking constraint: temperature must be 1, top_k not allowed
            request_kwargs["temperature"] = 1
            if "top_k" in request_kwargs:
                logger.warning("top_k is not supported with Extended Thinking; removing top_k")
                request_kwargs.pop("top_k", None)
        elif self.config.temperature > 0:
            request_kwargs["temperature"] = self.config.temperature

        content_text = ""
        thinking_text = ""  # Separate buffer for thinking blocks
        thinking_signature = ""  # Store signature for thinking block
        actions: list[Action] = []
        input_tokens = 0
        output_tokens = 0
        stop_reason = ""
        final_message = None
        current_block_type = None  # Track current content block type
        current_tool_use = None  # Track current tool use block being built
        tool_use_blocks: list[dict] = []  # Collect tool use blocks during streaming

        max_retries = 3
        retry_delay = 2  # seconds
        
        # Log request for debugging
        logger.debug(f"Streaming request: model={request_kwargs.get('model')}, "
                    f"max_tokens={request_kwargs.get('max_tokens')}, "
                    f"temperature={request_kwargs.get('temperature')}, "
                    f"thinking={request_kwargs.get('thinking')}, "
                    f"tools={'present' if request_kwargs.get('tools') else 'none'}")
        
        for attempt in range(max_retries):
            try:
                _stream_ctx = self._client.messages.stream(**request_kwargs)
                with _stream_ctx as stream:
                    stream_index_error = False
                    try:
                        for event in stream:
                            if hasattr(event, "type"):
                                # Track which content block we're in
                                if event.type == "content_block_start":
                                    if hasattr(event, "content_block") and hasattr(event.content_block, "type"):
                                        current_block_type = event.content_block.type
                                        # Start tracking tool use block
                                        if current_block_type == "tool_use":
                                            block = event.content_block
                                            current_tool_use = {
                                                "id": getattr(block, "id", ""),
                                                "name": getattr(block, "name", ""),
                                                "input_json": "",
                                            }
                                
                                elif event.type == "content_block_delta":
                                    # Handle thinking_delta (Anthropic Extended Thinking)
                                    if hasattr(event.delta, "thinking"):
                                        chunk = event.delta.thinking
                                        thinking_text += chunk
                                        # Don't stream thinking to user - it's internal reasoning
                                        # Thinking will be available in metadata after completion
                                    
                                    # Handle signature_delta (Anthropic Extended Thinking)
                                    elif hasattr(event.delta, "signature"):
                                        thinking_signature = event.delta.signature
                                    
                                    # Handle input_json_delta for tool use
                                    elif hasattr(event.delta, "partial_json") and current_tool_use:
                                        current_tool_use["input_json"] += event.delta.partial_json
                                    
                                    # Handle regular text delta
                                    elif hasattr(event.delta, "text"):
                                        chunk = event.delta.text
                                        content_text += chunk
                                        if on_text:
                                            on_text(chunk)
                                
                                elif event.type == "content_block_stop":
                                    # Save completed tool use block
                                    if current_tool_use and current_block_type == "tool_use":
                                        tool_use_blocks.append(current_tool_use)
                                        current_tool_use = None
                                    current_block_type = None  # Reset block type
                                
                                elif event.type == "message_start":
                                    if hasattr(event.message, "usage"):
                                        input_tokens = event.message.usage.input_tokens
                                elif event.type == "message_delta":
                                    if hasattr(event, "usage"):
                                        output_tokens = event.usage.output_tokens
                                    if hasattr(event.delta, "stop_reason"):
                                        stop_reason = event.delta.stop_reason
                    except IndexError as idx_err:
                        # ZenMux sends content_block_delta with an index that doesn't match
                        # the Anthropic SDK's internal content snapshot when routing OpenAI
                        # models through an Anthropic-compatible endpoint.
                        # Treat as graceful stream end — use whatever was collected.
                        logger.warning(
                            f"Stream IndexError (ZenMux/OpenAI incompatibility), "
                            f"using partial content: {idx_err}"
                        )
                        stream_index_error = True

                    # Get final message for tool use blocks (skip if stream had IndexError)
                    if not stream_index_error:
                        try:
                            final_message = stream.get_final_message()
                            for block in final_message.content:
                                if isinstance(block, ToolUseBlock):
                                    actions.append(
                                        Action(
                                            type="tool_use",
                                            name=block.name,
                                            input=block.input,
                                            id=block.id,
                                        )
                                    )
                        except (AssertionError, IndexError):
                            logger.debug("Stream ended without final message, using collected tool blocks")
                            final_message = None
                    
                    # If stream had IndexError or get_final_message failed — use collected blocks
                    if stream_index_error or final_message is None:
                        if final_message is None:
                            final_message = None  # already set
                        for tool_block in tool_use_blocks:
                            try:
                                import json as json_module
                                input_data = json_module.loads(tool_block["input_json"]) if tool_block["input_json"] else {}
                                actions.append(
                                    Action(
                                        type="tool_use",
                                        name=tool_block["name"],
                                        input=input_data,
                                        id=tool_block["id"],
                                    )
                                )
                            except json_module.JSONDecodeError as e:
                                logger.warning(f"Failed to parse tool input JSON: {e}")
                
                # Success - break out of retry loop
                break

            except (httpx.RemoteProtocolError, httpx.ReadTimeout, httpx.ConnectError) as e:
                if attempt < max_retries - 1:
                    logger.warning(
                        f"Stream interrupted (attempt {attempt + 1}/{max_retries}): {e}. "
                        f"Retrying in {retry_delay}s..."
                    )
                    import time
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                    continue
                else:
                    logger.error(f"Stream failed after {max_retries} attempts: {e}", exc_info=True)
                    raise
            except anthropic.APIStatusError as e:
                # Handle payment/credit errors - raise special exception for retry handling
                if e.status_code == 402:
                    from neoCoder.sdk.llm.base_client import InsufficientBalanceError
                    logger.warning(f"Payment required (402): {e}")
                    raise InsufficientBalanceError(
                        "💳 Insufficient balance. Please top up to continue.",
                        original_error=e
                    )
                logger.error(f"API error: {e}", exc_info=True)
                raise
            except Exception as e:
                logger.error(f"Stream error: {e}", exc_info=True)
                raise

        # Parse XML if not using native tools
        if not self.config.use_native_tools and content_text:
            xml_actions = self._parser.parse_xml_tags(content_text)
            actions.extend(xml_actions)

        # Extract generation ID from final message
        generation_id = getattr(final_message, 'id', None) if final_message else None

        # Prepare metadata with thinking if available
        metadata = {}
        if thinking_text:
            metadata["thinking"] = thinking_text
            if thinking_signature:
                metadata["thinking_signature"] = thinking_signature

        return LLMResponse(
            content=content_text,
            actions=actions,
            raw_response=final_message,
            stop_reason=stop_reason,
            usage={
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            },
            generation_id=generation_id,
            metadata=metadata if metadata else None,
        )

    def register_tool(self, tool: ToolDefinition) -> None:
        """Register a tool that can be used by the LLM."""
        self._tools.append(tool)

    def clear_tools(self) -> None:
        """Clear all registered tools."""
        self._tools.clear()

    def count_tokens(self, text: str) -> int:
        """
        Count tokens in text using tiktoken (approximate for Claude).

        Args:
            text: Text to count tokens for.

        Returns:
            Approximate token count.
        """
        try:
            import tiktoken

            # Use cl100k_base as approximate for Claude
            enc = tiktoken.get_encoding("cl100k_base")
            return len(enc.encode(text))
        except ImportError:
            # Rough estimate if tiktoken not available
            return len(text) // 4
