"""
Claude API client wrapper.

Provides a unified interface for interacting with Claude models,
supporting both native tool use and XML-style fallback.
Works with both Anthropic official API and compatible providers like ZenMux.

This module now uses a factory pattern to automatically select between
native Anthropic client and custom API client based on configuration.
"""

from __future__ import annotations

from neoCoder.sdk.llm.base_client import BaseLLMClient, ToolDefinition, LLMResponse
from neoCoder.sdk.llm.native_client import ClaudeClientConfig
from neoCoder.sdk.llm.client_factory import create_client


def ClaudeClient(config: ClaudeClientConfig | None = None, **kwargs) -> BaseLLMClient:
    """
    Create Claude client (factory function for backward compatibility).
    
    Automatically selects native or custom implementation based on config.
    This function maintains backward compatibility while using the new
    factory pattern under the hood.
    
    Args:
        config: Client configuration. If not provided, uses defaults.
        **kwargs: Override specific config values.
    
    Returns:
        Configured LLM client (native or custom)
        
    Raises:
        ValueError: If configuration is invalid
    
    Examples:
        # Use native Anthropic API (default)
        client = ClaudeClient()
        
        # Use custom API (ZenMux)
        client = ClaudeClient(ClaudeClientConfig(
            base_url="https://zenmux.example.com",
            use_zenmux_format=True
        ))
        
        # Force native client even with base_url
        client = ClaudeClient(ClaudeClientConfig(
            base_url="https://custom.com",
            force_native_anthropic=True
        ))
    """
    if config is None:
        config = ClaudeClientConfig()
    
    # Apply kwargs overrides
    for key, value in kwargs.items():
        if hasattr(config, key):
            setattr(config, key, value)
    
    return create_client(config)


# Export for backward compatibility
__all__ = [
    "ClaudeClient",
    "ClaudeClientConfig",
    "ToolDefinition",
    "LLMResponse",
    "BaseLLMClient",
]
