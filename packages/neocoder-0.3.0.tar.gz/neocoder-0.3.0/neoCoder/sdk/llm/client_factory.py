"""
Client factory for creating appropriate LLM client based on configuration.

Automatically detects whether to use native Anthropic API, custom API,
Responses API (Poe/ZenMux), or Vertex AI API based on configuration and base_url.

Supported API types:
- native_anthropic: Direct Anthropic API (anthropic.com)
- custom_api: ZenMux Anthropic-compatible API (zenmux.ai/api/anthropic)
- responses_api: OpenAI Responses API (Poe, ZenMux /api/v1)
- vertexai_api: Google Vertex AI API (ZenMux /api/vertex-ai)
"""

from __future__ import annotations

import logging
from typing import Literal, Union

from neoCoder.sdk.llm.base_client import BaseLLMClient
from neoCoder.sdk.llm.native_client import ClaudeClientConfig


logger = logging.getLogger(__name__)

APIType = Literal["native_anthropic", "custom_api", "responses_api", "vertexai_api", "openai_chat"]


def detect_api_type(config: ClaudeClientConfig) -> APIType:
    """
    Detect which API implementation to use.
    
    Detection logic:
    1. If force_native_anthropic is True, use native Anthropic client
    2. If force_custom_api is True, use custom client
    3. If force_responses_api is True, use Responses API client
    4. If base_url contains "poe.com", use Responses API client
    5. If model has provider prefix (anthropic/, google/, etc.), use custom client (ZenMux routing)
    6. If base_url is None, use native Anthropic client
    7. If base_url contains "anthropic.com", use native Anthropic client
    8. If base_url contains "zenmux", use custom client (ZenMux)
    9. Otherwise, use custom client
    
    Args:
        config: Client configuration (ClaudeClientConfig)
    
    Returns:
        "native_anthropic", "custom_api", or "responses_api"
        
    Raises:
        ValueError: If multiple force flags are set
    """
    # Check for conflicting flags
    if hasattr(config, "force_native_anthropic") and hasattr(config, "force_custom_api"):
        if config.force_native_anthropic and config.force_custom_api:
            raise ValueError(
                "Cannot force both native and custom API. "
                "Choose one or let system auto-detect."
            )
    
    # Explicit configuration takes precedence
    if hasattr(config, "force_native_anthropic") and config.force_native_anthropic:
        logger.info("Using native Anthropic client (forced by config)")
        return "native_anthropic"
    
    if hasattr(config, "force_custom_api") and config.force_custom_api:
        logger.info("Using custom API client (forced by config)")
        return "custom_api"
    
    if hasattr(config, "force_responses_api") and config.force_responses_api:
        logger.info("Using Responses API client (forced by config)")
        return "responses_api"
    
    if hasattr(config, "force_vertexai_api") and config.force_vertexai_api:
        logger.info("Using Vertex AI client (forced by config)")
        return "vertexai_api"
    
    # Check base_url for API type detection
    if config.base_url:
        base_url_lower = config.base_url.lower()
        
        # Check for Poe API
        if "poe.com" in base_url_lower or "api.poe" in base_url_lower:
            logger.info(f"Using Responses API client (Poe detected: {config.base_url})")
            return "responses_api"
        
        # Check for ZenMux endpoints
        if "zenmux" in base_url_lower:
            # ZenMux Vertex AI endpoint (/api/vertex-ai) -> Vertex AI client
            if "/api/vertex-ai" in base_url_lower or "vertex-ai" in base_url_lower:
                logger.info(f"Using Vertex AI client (ZenMux Vertex AI: {config.base_url})")
                return "vertexai_api"
            # ZenMux OpenAI-compatible endpoint (/api/v1) -> Responses API
            if "/api/v1" in base_url_lower and "/api/anthropic" not in base_url_lower:
                logger.info(f"Using Responses API client (ZenMux OpenAI API: {config.base_url})")
                return "responses_api"
            # ZenMux Anthropic-compatible endpoint (/api/anthropic) -> custom_api
            if "/api/anthropic" in base_url_lower:
                logger.info(f"Using custom API client (ZenMux Anthropic API: {config.base_url})")
                return "custom_api"
            # Default ZenMux without specific path -> check model prefix
            # Fall through to provider prefix check
    
    # Check for provider prefix in model name (ZenMux routing)
    if "/" in config.model:
        provider_prefix = config.model.split("/")[0].lower()
        base_url_lower = config.base_url.lower() if config.base_url else ""
        
        # Google models via ZenMux -> use Vertex AI client
        if provider_prefix == "google":
            if "zenmux" in base_url_lower:
                logger.info(f"Using Vertex AI client (Google model via ZenMux: {config.model})")
                return "vertexai_api"
        
        # OpenAI models via ZenMux -> use Responses API or Chat Completions
        if provider_prefix == "openai":
            if "zenmux" in base_url_lower:
                if hasattr(config, "use_responses_api") and config.use_responses_api:
                    logger.info(f"Using Responses API client (OpenAI model via ZenMux: {config.model})")
                    return "responses_api"
                logger.info(f"Using OpenAI Chat client (OpenAI model via ZenMux: {config.model})")
                return "openai_chat"
        
        # Anthropic models - only use custom_api for /api/anthropic endpoint
        if provider_prefix == "anthropic":
            if "/api/anthropic" in base_url_lower:
                logger.info(f"Using custom API client (Anthropic via ZenMux Anthropic API: {config.model})")
                return "custom_api"
            elif "zenmux" in base_url_lower:
                if hasattr(config, "use_responses_api") and config.use_responses_api:
                    logger.info(f"Using Responses API client (Anthropic model via ZenMux: {config.model})")
                    return "responses_api"
                logger.info(f"Using OpenAI Chat client (Anthropic model via ZenMux: {config.model})")
                return "openai_chat"
        
        # Other providers via ZenMux -> use Chat Completions by default
        if provider_prefix in ["cohere", "mistral", "moonshotai", "deepseek", "qwen"]:
            if "zenmux" in base_url_lower:
                if hasattr(config, "use_responses_api") and config.use_responses_api:
                    logger.info(f"Using Responses API client (provider prefix via ZenMux: {provider_prefix})")
                    return "responses_api"
                logger.info(f"Using OpenAI Chat client (provider prefix via ZenMux: {provider_prefix})")
                return "openai_chat"
            logger.info(f"Using custom API client (provider prefix: {provider_prefix})")
            return "custom_api"
    
    # Auto-detect based on base_url
    if config.base_url is None:
        logger.info("Using native Anthropic client (no base_url)")
        return "native_anthropic"
    
    base_url_lower = config.base_url.lower()
    
    # Check for ZenMux - use OpenAI Chat Completions API by default
    if "zenmux" in base_url_lower:
        # Only use custom_api for explicit /api/anthropic endpoint
        if "/api/anthropic" in base_url_lower:
            logger.info(f"Using custom API client (ZenMux Anthropic API: {config.base_url})")
            return "custom_api"
        logger.info(f"Using OpenAI Chat client (ZenMux: {config.base_url})")
        return "openai_chat"
    
    if "anthropic.com" in base_url_lower:
        logger.info("Using native Anthropic client (anthropic.com detected)")
        return "native_anthropic"
    
    logger.info(f"Using custom API client (base_url: {config.base_url})")
    return "custom_api"


def create_client(config: ClaudeClientConfig | None = None) -> BaseLLMClient:
    """
    Create appropriate LLM client based on configuration.
    
    This factory function automatically selects between native Anthropic client
    and custom API client based on the configuration.
    
    Args:
        config: Client configuration. If None, uses ClaudeClientConfig defaults.
    
    Returns:
        Configured LLM client (native Anthropic or custom)
        
    Raises:
        ValueError: If configuration is invalid
    """
    if config is None:
        config = ClaudeClientConfig()
    
    api_type = detect_api_type(config)
    logger.debug(f"create_client: model={config.model}, api_type={api_type}")
    
    if api_type == "native_anthropic":
        from neoCoder.sdk.llm.native_client import NativeAnthropicClient
        return NativeAnthropicClient(config)
    elif api_type == "responses_api":
        from neoCoder.sdk.llm.responses_client import ResponsesAPIClient, ResponsesClientConfig
        # Convert ClaudeClientConfig to ResponsesClientConfig
        responses_config = ResponsesClientConfig(
            model=config.model,
            api_key=config.api_key,
            base_url=config.base_url or "https://api.poe.com/v1",
            max_output_tokens=config.max_tokens,
            timeout=config.timeout,
        )
        # Transfer reasoning settings if available
        if hasattr(config, "thinking_budget_tokens") and config.thinking_budget_tokens:
            # Map budget to effort: >50k = high, >10k = medium, else low
            if config.thinking_budget_tokens > 50000:
                responses_config.reasoning_effort = "high"
            elif config.thinking_budget_tokens > 10000:
                responses_config.reasoning_effort = "medium"
            else:
                responses_config.reasoning_effort = "low"
        return ResponsesAPIClient(responses_config)
    elif api_type == "vertexai_api":
        from neoCoder.sdk.llm.vertexai_client import VertexAIClient, VertexAIClientConfig
        # Convert ClaudeClientConfig to VertexAIClientConfig
        vertexai_config = VertexAIClientConfig(
            model=config.model,
            api_key=config.api_key,
            base_url=config.base_url or "https://zenmux.ai/api/vertex-ai",
            max_output_tokens=config.max_tokens,
            timeout=config.timeout,
        )
        # Transfer thinking settings if available
        if hasattr(config, "thinking_budget_tokens") and config.thinking_budget_tokens:
            vertexai_config.thinking_budget = config.thinking_budget_tokens
        return VertexAIClient(vertexai_config)
    elif api_type == "openai_chat":
        from neoCoder.sdk.llm.openai_client import OpenAIClient, OpenAIClientConfig
        # Convert ClaudeClientConfig to OpenAIClientConfig for ZenMux Chat Completions
        openai_config = OpenAIClientConfig(
            model=config.model,
            api_key=config.api_key,
            base_url=config.base_url or "https://zenmux.ai/api/v1",
            max_tokens=config.max_tokens,
            timeout=config.timeout,
        )
        # Transfer reasoning settings
        if hasattr(config, "thinking_effort") and config.thinking_effort:
            openai_config.reasoning_effort = config.thinking_effort
        elif hasattr(config, "reasoning_effort") and config.reasoning_effort:
            openai_config.reasoning_effort = config.reasoning_effort
        return OpenAIClient(openai_config)
    else:
        from neoCoder.sdk.llm.custom_client import CustomAPIClient
        return CustomAPIClient(config)
