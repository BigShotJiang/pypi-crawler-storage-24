"""
Output parser for LLM responses.

Handles both native tool calls (JSON) and XML-style tag parsing.
Converts all outputs to a unified Action format.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any
from enum import Enum


class ActionType(Enum):
    """Types of actions that can be parsed from LLM output."""

    TOOL_USE = "tool_use"  # Native Claude tool use
    XML_TAG = "xml_tag"  # XML-style tag action
    TEXT = "text"  # Plain text (no action)


@dataclass
class Action:
    """
    A parsed action from LLM output.

    Represents either a native tool call or an XML-style tag action.
    """

    type: str  # "tool_use" or "xml_tag"
    name: str  # Tool/tag name
    input: dict[str, Any] = field(default_factory=dict)  # Parameters/content
    id: str | None = None  # Tool use ID (for native tools)
    raw_content: str | None = None  # Original raw content

    def __post_init__(self):
        # Ensure input is always a dict
        if self.input is None:
            self.input = {}


@dataclass
class ParseResult:
    """Result of parsing LLM output."""

    actions: list[Action]
    text_content: str  # Non-action text content
    raw_output: str  # Original raw output


class OutputParser:
    """
    Parser for LLM outputs.

    Supports:
    - Native tool use blocks from Claude
    - XML-style tags like <bash>command</bash>
    - Nested XML content
    """

    # Common XML tags used by coding agents
    KNOWN_TAGS = {
        "bash",
        "file_edit",
        "file_read",
        "file_search",
        "thinking",
        "plan",
        "result",
        "error",
    }

    def __init__(self, additional_tags: list[str] | None = None):
        """
        Initialize the parser.

        Args:
            additional_tags: Additional XML tags to recognize.
        """
        self.tags = self.KNOWN_TAGS.copy()
        if additional_tags:
            self.tags.update(additional_tags)

        # Build regex pattern for known tags
        self._tag_pattern = self._build_tag_pattern()

    def _build_tag_pattern(self) -> re.Pattern:
        """Build regex pattern for matching XML tags."""
        # Match tags with optional attributes
        # Pattern: <tag_name attr="value">content</tag_name>
        tags_alternation = "|".join(re.escape(tag) for tag in self.tags)
        pattern = rf"<({tags_alternation})(\s+[^>]*)?>(.+?)</\1>"
        return re.compile(pattern, re.DOTALL)

    def add_tag(self, tag: str) -> None:
        """Add a new tag to recognize."""
        self.tags.add(tag)
        self._tag_pattern = self._build_tag_pattern()

    def parse_xml_tags(self, text: str) -> list[Action]:
        """
        Parse XML-style tags from text.

        Args:
            text: Text containing XML tags.

        Returns:
            List of parsed actions.
        """
        actions = []

        for match in self._tag_pattern.finditer(text):
            tag_name = match.group(1)
            attributes_str = match.group(2) or ""
            content = match.group(3).strip()

            # Parse attributes
            attributes = self._parse_attributes(attributes_str)

            # Build action input
            action_input = {"content": content, **attributes}

            actions.append(
                Action(
                    type="xml_tag",
                    name=tag_name,
                    input=action_input,
                    raw_content=match.group(0),
                )
            )

        return actions

    def _parse_attributes(self, attr_str: str) -> dict[str, str]:
        """Parse XML-style attributes from a string."""
        attributes = {}

        # Pattern for attr="value" or attr='value'
        attr_pattern = r'(\w+)\s*=\s*["\']([^"\']*)["\']'

        for match in re.finditer(attr_pattern, attr_str):
            key = match.group(1)
            value = match.group(2)
            attributes[key] = value

        return attributes

    def parse(self, text: str, tool_use_blocks: list[dict[str, Any]] | None = None) -> ParseResult:
        """
        Parse LLM output into actions and text.

        Args:
            text: Text content from LLM response.
            tool_use_blocks: Optional native tool use blocks.

        Returns:
            ParseResult with actions and remaining text.
        """
        actions = []

        # First, handle native tool use blocks
        if tool_use_blocks:
            for block in tool_use_blocks:
                actions.append(
                    Action(
                        type="tool_use",
                        name=block.get("name", ""),
                        input=block.get("input", {}),
                        id=block.get("id"),
                    )
                )

        # Then parse XML tags from text
        xml_actions = self.parse_xml_tags(text)
        actions.extend(xml_actions)

        # Extract text content without XML tags
        text_content = self._tag_pattern.sub("", text).strip()

        return ParseResult(
            actions=actions,
            text_content=text_content,
            raw_output=text,
        )

    def extract_tag_content(self, text: str, tag_name: str) -> str | None:
        """
        Extract content from a specific tag.

        Args:
            text: Text to search.
            tag_name: Tag name to find.

        Returns:
            Tag content or None if not found.
        """
        pattern = rf"<{re.escape(tag_name)}(?:\s+[^>]*)?>(.+?)</{re.escape(tag_name)}>"
        match = re.search(pattern, text, re.DOTALL)
        return match.group(1).strip() if match else None

    def has_tag(self, text: str, tag_name: str) -> bool:
        """Check if text contains a specific tag."""
        pattern = rf"<{re.escape(tag_name)}(?:\s+[^>]*)?>.*?</{re.escape(tag_name)}>"
        return bool(re.search(pattern, text, re.DOTALL))


def format_tool_result(tool_use_id: str, result: str, is_error: bool = False) -> dict[str, Any]:
    """
    Format a tool result for sending back to Claude.

    Args:
        tool_use_id: ID of the tool use block.
        result: Result content.
        is_error: Whether the result is an error.

    Returns:
        Formatted tool result message content.
    """
    return {
        "type": "tool_result",
        "tool_use_id": tool_use_id,
        "content": result,
        "is_error": is_error,
    }


def format_xml_result(result: str, is_error: bool = False) -> str:
    """
    Format a result for XML-style responses.

    Args:
        result: Result content.
        is_error: Whether the result is an error.

    Returns:
        Formatted XML result string.
    """
    tag = "error" if is_error else "result"
    return f"<{tag}>{result}</{tag}>"
