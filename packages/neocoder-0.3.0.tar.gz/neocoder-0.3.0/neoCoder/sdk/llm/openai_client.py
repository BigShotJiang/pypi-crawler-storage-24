"""
OpenAI API client for OpenAI models via ZenMux.

Uses the OpenAI SDK directly for better compatibility with OpenAI models
including GPT-5.x with extended reasoning (xhigh effort).
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Callable

from openai import OpenAI
import httpx

from neoCoder.sdk.llm.base_client import BaseLLMClient, ToolDefinition, LLMResponse, InsufficientBalanceError
from neoCoder.sdk.llm.output_parser import Action, OutputParser


logger = logging.getLogger(__name__)


@dataclass
class OpenAIClientConfig:
    """Configuration for OpenAI client."""
    
    model: str = "gpt-5.4"
    api_key: str | None = None
    base_url: str | None = None
    max_tokens: int = 8192
    temperature: float = 0.7
    reasoning_effort: str = "xhigh"  # none, minimal, low, medium, high, xhigh
    reasoning_summary: str | None = "detailed"  # auto, concise, detailed (for Responses API)
    timeout: int = 300
    use_native_tools: bool = True
    default_headers: dict[str, str] = field(default_factory=dict)


class OpenAIClient(BaseLLMClient):
    """
    OpenAI API client for OpenAI models via ZenMux.
    
    Supports:
    - GPT-5.x models with 1M context
    - Extended reasoning with xhigh effort
    - Native tool calling
    - Streaming responses
    """

    def __init__(self, config: OpenAIClientConfig | None = None, **kwargs):
        """
        Initialize OpenAI client.
        
        Args:
            config: Client configuration.
            **kwargs: Override specific config values.
        """
        if config is None:
            config = OpenAIClientConfig()

        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)

        self.config = config
        self._api_key = (
            config.api_key 
            or os.environ.get("OPENAI_API_KEY") 
            or os.environ.get("ZENMUX_API_KEY")
        )

        if not self._api_key:
            raise ValueError(
                "OpenAI API key required.\n\n"
                "Set environment variable:\n"
                "  Windows: set OPENAI_API_KEY=your-key\n"
                "  Linux/macOS: export OPENAI_API_KEY=your-key\n"
            )

        client_kwargs = {"api_key": self._api_key}
        if config.base_url:
            client_kwargs["base_url"] = config.base_url
            logger.info(f"Initialized OpenAIClient with base_url: {config.base_url}")
        
        # Ensure proper headers for ZenMux
        default_headers = config.default_headers.copy() if config.default_headers else {}
        default_headers["Content-Type"] = "application/json"
        default_headers["Accept"] = "application/json"
        # Explicitly disable any browser-like behavior
        default_headers["X-Requested-With"] = "XMLHttpRequest"
        client_kwargs["default_headers"] = default_headers
        
        # Increase timeout for long reasoning tasks
        client_kwargs["timeout"] = config.timeout

        self._client = OpenAI(**client_kwargs)
        self._parser = OutputParser()
        self._tools: list[ToolDefinition] = []

    def _build_request_params(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
    ) -> dict[str, Any]:
        """Build request parameters for OpenAI API."""
        
        # Prepend system message if provided
        api_messages = []
        if system:
            api_messages.append({"role": "system", "content": system})
        api_messages.extend(messages)
        
        params: dict[str, Any] = {
            "model": self.config.model,
            "messages": api_messages,
            "max_completion_tokens": self.config.max_tokens,
        }
        
        # Add temperature if not using high reasoning
        if self.config.reasoning_effort not in ("high", "xhigh"):
            params["temperature"] = self.config.temperature
        
        # Add reasoning configuration for ZenMux
        # Supported effort values: none, minimal, low, medium, high, xhigh
        if self.config.reasoning_effort and self.config.reasoning_effort != "none":
            params["reasoning_effort"] = self.config.reasoning_effort
            logger.info(f"Reasoning: effort={self.config.reasoning_effort}")
        
        # Add tools - standard OpenAI format with nested function
        active_tools = tools if tools is not None else self._tools
        if self.config.use_native_tools and active_tools:
            tools_list = [
                {
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.input_schema,
                    }
                }
                for t in active_tools
            ]
            params["tools"] = tools_list
        
        return params

    def invoke(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
    ) -> LLMResponse:
        """
        Invoke the LLM with the given messages.
        """
        params = self._build_request_params(messages, system, tools)
        
        # Use httpx directly for full control over request format
        base_url = self.config.base_url or "https://api.openai.com/v1"
        url = f"{base_url.rstrip('/')}/chat/completions"
        
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        
        try:
            logger.debug(f"OpenAI request: model={params.get('model')}, messages={len(params.get('messages', []))}")
            with httpx.Client(timeout=self.config.timeout) as client:
                resp = client.post(url, json=params, headers=headers)
                resp.raise_for_status()
                response_data = resp.json()
        except httpx.HTTPStatusError as e:
            error_str = str(e)
            logger.error(f"OpenAI API error: {error_str}")
            try:
                error_body = e.response.json()
                error_str = str(error_body)
            except:
                pass
            if "402" in error_str or "insufficient" in error_str.lower():
                raise InsufficientBalanceError(
                    "Insufficient balance for OpenAI API", 
                    original_error=e
                )
            raise
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            raise

        # Extract response content
        message = response_data["choices"][0]["message"]
        content = message.get("content") or ""
        
        # Extract tool calls (handle both nested and flat formats)
        actions = []
        if message.get("tool_calls"):
            for tool_call in message["tool_calls"]:
                # Handle nested format (standard OpenAI)
                if "function" in tool_call:
                    try:
                        input_data = json.loads(tool_call["function"]["arguments"])
                    except json.JSONDecodeError:
                        input_data = {}
                    actions.append(Action(
                        type="tool_use",
                        name=tool_call["function"]["name"],
                        input=input_data,
                        id=tool_call["id"],
                    ))
                # Handle flat format (ZenMux)
                else:
                    try:
                        input_data = json.loads(tool_call.get("arguments", "{}"))
                    except json.JSONDecodeError:
                        input_data = {}
                    actions.append(Action(
                        type="tool_use",
                        name=tool_call.get("name", ""),
                        input=input_data,
                        id=tool_call.get("id") or tool_call.get("call_id", ""),
                    ))

        # Build usage dict
        resp_usage = response_data.get("usage", {})
        usage = {
            "input_tokens": resp_usage.get("prompt_tokens", 0),
            "output_tokens": resp_usage.get("completion_tokens", 0),
        }
        
        # Extract reasoning tokens if available
        completion_details = resp_usage.get("completion_tokens_details", {})
        if completion_details.get("reasoning_tokens"):
            usage["reasoning_tokens"] = completion_details["reasoning_tokens"]

        return LLMResponse(
            content=content,
            actions=actions,
            raw_response=response_data,
            stop_reason=response_data["choices"][0].get("finish_reason") or "stop",
            usage=usage,
            generation_id=response_data.get("id"),
        )

    def invoke_stream(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
        on_text: Callable[[str], None] | None = None,
    ) -> LLMResponse:
        """
        Invoke the LLM with streaming using httpx SSE.
        """
        params = self._build_request_params(messages, system, tools)
        params["stream"] = True
        
        base_url = self.config.base_url or "https://api.openai.com/v1"
        url = f"{base_url.rstrip('/')}/chat/completions"
        
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        
        content_text = ""
        actions: list[Action] = []
        tool_calls_data: dict[int, dict] = {}
        input_tokens = 0
        output_tokens = 0
        reasoning_tokens = 0
        stop_reason = "stop"
        generation_id = None
        
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                with httpx.Client(timeout=self.config.timeout) as client:
                    with client.stream("POST", url, json=params, headers=headers) as resp:
                        resp.raise_for_status()
                        
                        for line in resp.iter_lines():
                            if not line or line.startswith(":"):
                                continue
                            if line == "data: [DONE]":
                                break
                            if line.startswith("data: "):
                                try:
                                    chunk = json.loads(line[6:])
                                except json.JSONDecodeError:
                                    continue
                                
                                if chunk.get("id") and not generation_id:
                                    generation_id = chunk["id"]
                                
                                choices = chunk.get("choices", [])
                                if choices:
                                    delta = choices[0].get("delta", {})
                                    
                                    # Handle text content
                                    if delta.get("content"):
                                        content_text += delta["content"]
                                        if on_text:
                                            on_text(delta["content"])
                                    
                                    # Handle tool calls
                                    if delta.get("tool_calls"):
                                        for tc in delta["tool_calls"]:
                                            idx = tc.get("index", 0)
                                            if idx not in tool_calls_data:
                                                tool_calls_data[idx] = {"id": "", "name": "", "arguments": ""}
                                            
                                            if tc.get("id"):
                                                tool_calls_data[idx]["id"] = tc["id"]
                                            if tc.get("function"):
                                                if tc["function"].get("name"):
                                                    tool_calls_data[idx]["name"] = tc["function"]["name"]
                                                if tc["function"].get("arguments"):
                                                    tool_calls_data[idx]["arguments"] += tc["function"]["arguments"]
                                    
                                    # Handle finish reason
                                    if choices[0].get("finish_reason"):
                                        stop_reason = choices[0]["finish_reason"]
                                
                                # Handle usage in final chunk
                                usage_data = chunk.get("usage")
                                if usage_data:
                                    input_tokens = usage_data.get("prompt_tokens", 0)
                                    output_tokens = usage_data.get("completion_tokens", 0)
                                    details = usage_data.get("completion_tokens_details", {})
                                    if details.get("reasoning_tokens"):
                                        reasoning_tokens = details["reasoning_tokens"]
                
                # Convert tool calls to actions
                for idx in sorted(tool_calls_data.keys()):
                    tc = tool_calls_data[idx]
                    try:
                        input_data = json.loads(tc["arguments"]) if tc["arguments"] else {}
                    except json.JSONDecodeError:
                        input_data = {}
                    
                    actions.append(Action(
                        type="tool_use",
                        name=tc["name"],
                        input=input_data,
                        id=tc["id"],
                    ))
                
                break  # Success
                
            except (httpx.RemoteProtocolError, httpx.ReadTimeout, httpx.ConnectError) as e:
                if attempt < max_retries - 1:
                    logger.warning(f"Stream interrupted (attempt {attempt + 1}): {e}")
                    import time
                    time.sleep(retry_delay)
                    continue
                raise
            except httpx.HTTPStatusError as e:
                error_str = str(e)
                try:
                    error_body = e.response.json()
                    error_str = str(error_body)
                except:
                    pass
                if "402" in error_str or "insufficient" in error_str.lower():
                    raise InsufficientBalanceError(
                        "Insufficient balance for OpenAI API",
                        original_error=e
                    )
                raise
            except Exception as e:
                logger.error(f"OpenAI streaming error: {e}")
                raise

        usage = {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
        }
        if reasoning_tokens:
            usage["reasoning_tokens"] = reasoning_tokens

        return LLMResponse(
            content=content_text,
            actions=actions,
            raw_response=None,
            stop_reason=stop_reason,
            usage=usage,
            generation_id=generation_id,
        )

    def register_tool(self, tool: ToolDefinition) -> None:
        """Register a tool."""
        self._tools.append(tool)

    def clear_tools(self) -> None:
        """Clear all registered tools."""
        self._tools.clear()

    def count_tokens(self, text: str) -> int:
        """Approximate token count."""
        return len(text) // 4
