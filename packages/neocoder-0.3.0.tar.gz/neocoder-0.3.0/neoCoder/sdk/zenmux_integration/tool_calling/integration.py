"""
Tool calling integration module

Provides enhanced tool management for Zenmux API tool execution.
"""

from typing import List, Dict, Any, Optional
from .registry import ToolRegistry
from .executor import ToolExecutor
from .formatter import ToolCallFormatter
from ..utils import get_logger

TOOL_SELECTION_AVAILABLE = False


class EnhancedToolManager:
    """
    Tool manager for Zenmux API tool calling.
    """
    
    def __init__(
        self,
        registry: ToolRegistry,
        executor: ToolExecutor,
        use_intelligent_selection: bool = False
    ):
        """
        Initialize tool manager
        
        Args:
            registry: Tool registry
            executor: Tool executor
            use_intelligent_selection: Unused, kept for API compatibility
        """
        self.logger = get_logger("zenmux_integration.tool_calling")
        self.registry = registry
        self.executor = executor
        self.formatter = ToolCallFormatter()
    
    def recommend_tools(
        self,
        context: str,
        available_tools: Optional[List[str]] = None,
        max_tools: int = 5
    ) -> List[str]:
        """
        Get available tools (returns all tools up to max_tools)
        
        Args:
            context: Task context (unused)
            available_tools: Optional list of available tool names
            max_tools: Maximum number of tools to return
            
        Returns:
            List of tool names
        """
        if available_tools is None:
            available_tools = self.registry.list_tools()
        return available_tools[:max_tools]
    
    def get_tool_definitions_for_context(
        self,
        context: str,
        max_tools: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Get tool definitions
        
        Args:
            context: Task context (unused)
            max_tools: Maximum number of tools
            
        Returns:
            List of tool definitions for API
        """
        recommended = self.recommend_tools(context, max_tools=max_tools)
        return self.registry.get_tool_definitions(allowed_tools=recommended)
    
    async def execute_with_recommendations(
        self,
        tool_calls: List[Any],
        context: str
    ) -> List[Any]:
        """
        Execute tool calls
        
        Args:
            tool_calls: Tool calls to execute
            context: Execution context
            
        Returns:
            List of tool results
        """
        return await self.executor.execute_tool_calls(
            tool_calls,
            context={"context": context}
        )
    
    def is_intelligent_selection_available(self) -> bool:
        """Check if intelligent selection is available"""
        return False
    
    def get_tool_statistics(self) -> Dict[str, Any]:
        """
        Get tool usage statistics
        
        Returns:
            Dictionary with statistics
        """
        return {
            "intelligent_selection_enabled": False,
            "total_tools": len(self.registry),
            "execution_stats": self.executor.get_statistics()
        }
