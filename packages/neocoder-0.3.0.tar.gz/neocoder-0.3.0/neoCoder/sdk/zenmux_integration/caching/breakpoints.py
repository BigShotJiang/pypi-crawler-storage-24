"""
Cache breakpoint placement logic.

Optimally places cache_control breakpoints based on:
- Content stability (tools > system > messages)
- Token count thresholds
- Maximum breakpoint limits
"""

from typing import Any
from dataclasses import dataclass

from .strategy import CacheStrategy, CacheConfig, ExplicitCacheStrategy


@dataclass
class BreakpointLocation:
    """Represents a cache breakpoint location."""
    
    location_type: str  # "tool", "system", "message"
    index: int
    estimated_tokens: int


class CacheBreakpointPlacer:
    """
    Places cache breakpoints optimally.
    
    Breakpoint order (by stability):
    1. Tools (rarely change)
    2. System prompt (changes per session)
    3. Messages (changes per turn)
    
    Uses adaptive TokenEstimator for accurate token counting.
    """
    
    def __init__(self, config: CacheConfig | None = None):
        self.config = config or CacheConfig()
        self._estimator = None
    
    def _get_estimator(self):
        """Lazy load token estimator to avoid circular imports."""
        if self._estimator is None:
            from ..token_estimator import get_token_estimator
            self._estimator = get_token_estimator()
        return self._estimator
    
    def _estimate_tokens(self, content: Any) -> int:
        """Estimate token count using adaptive estimator."""
        return self._get_estimator().estimate_tokens(content)
    
    def should_cache(self, estimated_tokens: int) -> bool:
        """Check if content is large enough to cache."""
        return estimated_tokens >= self.config.min_tokens_for_cache
    
    def apply_tool_caching(
        self,
        tools: list[dict[str, Any]],
        strategy: CacheStrategy,
    ) -> list[dict[str, Any]]:
        """
        Apply cache control to tools.
        
        Only marks the LAST tool with cache_control.
        This caches all tool definitions as a prefix.
        """
        if not tools or not self.config.cache_tools:
            return tools
        
        if not isinstance(strategy, ExplicitCacheStrategy):
            return tools
        
        total_tokens = sum(self._estimate_tokens(t) for t in tools)
        if not self.should_cache(total_tokens):
            return tools
        
        result = list(tools)
        result[-1] = strategy.apply_to_tool(result[-1], is_last=True)
        return result
    
    def apply_system_caching(
        self,
        system: list[dict[str, Any]] | str,
        strategy: CacheStrategy,
    ) -> list[dict[str, Any]]:
        """
        Apply cache control to system prompt.
        
        Converts string to content blocks if needed.
        Marks the last content block with cache_control.
        """
        if not system or not self.config.cache_system_prompt:
            return system if isinstance(system, list) else [{"type": "text", "text": system}] if system else []
        
        if not isinstance(strategy, ExplicitCacheStrategy):
            if isinstance(system, str):
                return [{"type": "text", "text": system}]
            return system
        
        tokens = self._estimate_tokens(system)
        is_cacheable = self.should_cache(tokens)
        
        return strategy.apply_to_content(system, is_last=is_cacheable)
    
    def apply_message_caching(
        self,
        messages: list[dict[str, Any]],
        strategy: CacheStrategy,
        cache_last_user_message: bool = True,
    ) -> list[dict[str, Any]]:
        """
        Apply cache control to conversation messages.
        
        Strategy:
        - Cache long conversation history at key points
        - Always cache the last user message if conversation is long
        """
        if not messages or not self.config.cache_conversation_history:
            return messages
        
        if not isinstance(strategy, ExplicitCacheStrategy):
            return messages
        
        result = list(messages)
        
        total_tokens = sum(self._estimate_tokens(m.get("content", "")) for m in messages)
        
        if not self.should_cache(total_tokens):
            return result
        
        if cache_last_user_message:
            for i in range(len(result) - 1, -1, -1):
                if result[i].get("role") == "user":
                    content = result[i].get("content", "")
                    cached_content = strategy.apply_to_content(content, is_last=True)
                    result[i] = dict(result[i])
                    result[i]["content"] = cached_content
                    break
        
        return result
    
    def get_breakpoint_summary(
        self,
        tools: list[dict[str, Any]] | None,
        system: list[dict[str, Any]] | str | None,
        messages: list[dict[str, Any]] | None,
    ) -> dict[str, Any]:
        """
        Get summary of where breakpoints would be placed.
        
        Returns:
            Dictionary with breakpoint locations and token estimates
        """
        summary = {
            "tools": {
                "count": len(tools) if tools else 0,
                "tokens": sum(self._estimate_tokens(t) for t in tools) if tools else 0,
                "cacheable": False,
            },
            "system": {
                "tokens": self._estimate_tokens(system) if system else 0,
                "cacheable": False,
            },
            "messages": {
                "count": len(messages) if messages else 0,
                "tokens": sum(self._estimate_tokens(m.get("content", "")) for m in messages) if messages else 0,
                "cacheable": False,
            },
            "total_tokens": 0,
            "breakpoints": [],
        }
        
        summary["total_tokens"] = (
            summary["tools"]["tokens"] +
            summary["system"]["tokens"] +
            summary["messages"]["tokens"]
        )
        
        summary["tools"]["cacheable"] = self.should_cache(summary["tools"]["tokens"])
        summary["system"]["cacheable"] = self.should_cache(summary["system"]["tokens"])
        summary["messages"]["cacheable"] = self.should_cache(summary["messages"]["tokens"])
        
        if summary["tools"]["cacheable"]:
            summary["breakpoints"].append("tools")
        if summary["system"]["cacheable"]:
            summary["breakpoints"].append("system")
        if summary["messages"]["cacheable"]:
            summary["breakpoints"].append("messages")
        
        return summary
