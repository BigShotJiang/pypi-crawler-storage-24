"""
Cache strategies for different model providers.

ZenMux supports two caching types:
- Implicit: Auto-managed by model (OpenAI, DeepSeek, Grok, Gemini, Qwen)
- Explicit: Requires cache_control markers (Anthropic Claude)
"""

from abc import ABC, abstractmethod
from typing import Any
from dataclasses import dataclass, field
from enum import Enum


class CacheType(str, Enum):
    IMPLICIT = "implicit"
    EXPLICIT = "explicit"


# Models that support implicit caching (no config needed)
IMPLICIT_CACHE_MODELS = {
    "openai", "gpt",
    "deepseek",
    "grok", "x-ai",
    "gemini", "google",
    "qwen", "alibaba",
    "kimi", "moonshot",
    "glm", "zhipu",
}

# Models that require explicit cache_control
EXPLICIT_CACHE_MODELS = {
    "claude", "anthropic",
}


@dataclass
class CacheConfig:
    """Configuration for prompt caching."""
    
    enabled: bool = True
    min_tokens_for_cache: int = 1024
    max_breakpoints: int = 4
    cache_system_prompt: bool = True
    cache_tools: bool = True
    cache_conversation_history: bool = True
    cache_ttl_minutes: int = 5


class CacheStrategy(ABC):
    """Base class for cache strategies."""
    
    @abstractmethod
    def get_cache_type(self) -> CacheType:
        pass
    
    @abstractmethod
    def apply_to_content(
        self,
        content: list[dict[str, Any]] | str,
        is_last: bool = False,
    ) -> list[dict[str, Any]] | str:
        """Apply cache control to content block."""
        pass
    
    @abstractmethod
    def apply_to_tool(
        self,
        tool: dict[str, Any],
        is_last: bool = False,
    ) -> dict[str, Any]:
        """Apply cache control to tool definition."""
        pass


class ImplicitCacheStrategy(CacheStrategy):
    """
    Strategy for models with implicit caching.
    No modifications needed - caching is automatic.
    """
    
    def get_cache_type(self) -> CacheType:
        return CacheType.IMPLICIT
    
    def apply_to_content(
        self,
        content: list[dict[str, Any]] | str,
        is_last: bool = False,
    ) -> list[dict[str, Any]] | str:
        return content
    
    def apply_to_tool(
        self,
        tool: dict[str, Any],
        is_last: bool = False,
    ) -> dict[str, Any]:
        return tool


class ExplicitCacheStrategy(CacheStrategy):
    """
    Strategy for Anthropic Claude models.
    Adds cache_control markers to content.
    """
    
    CACHE_CONTROL = {"type": "ephemeral"}
    
    def get_cache_type(self) -> CacheType:
        return CacheType.EXPLICIT
    
    def apply_to_content(
        self,
        content: list[dict[str, Any]] | str,
        is_last: bool = False,
    ) -> list[dict[str, Any]]:
        """
        Apply cache_control to content.
        
        For string content, converts to content block format.
        For list content, adds cache_control to last item if is_last=True.
        """
        if isinstance(content, str):
            block = {"type": "text", "text": content}
            if is_last:
                block["cache_control"] = self.CACHE_CONTROL
            return [block]
        
        if not content:
            return content
        
        result = list(content)
        if is_last and result:
            last_block = dict(result[-1])
            last_block["cache_control"] = self.CACHE_CONTROL
            result[-1] = last_block
        
        return result
    
    def apply_to_tool(
        self,
        tool: dict[str, Any],
        is_last: bool = False,
    ) -> dict[str, Any]:
        """Apply cache_control to tool definition."""
        if not is_last:
            return tool
        
        result = dict(tool)
        result["cache_control"] = self.CACHE_CONTROL
        return result


def detect_cache_strategy(model: str) -> CacheStrategy:
    """
    Detect appropriate cache strategy based on model name.
    
    Args:
        model: Model identifier (e.g., "anthropic/claude-sonnet-4.5")
        
    Returns:
        Appropriate CacheStrategy instance
    """
    model_lower = model.lower()
    
    for prefix in EXPLICIT_CACHE_MODELS:
        if prefix in model_lower:
            return ExplicitCacheStrategy()
    
    return ImplicitCacheStrategy()
