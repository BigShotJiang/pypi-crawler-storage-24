"""
Prompt Cache Manager for ZenMux.

Manages prompt caching for both implicit and explicit caching models.
Automatically detects model type and applies appropriate caching strategy.
"""

from typing import Any
import logging

from .strategy import (
    CacheConfig,
    CacheStrategy,
    CacheType,
    detect_cache_strategy,
    ExplicitCacheStrategy,
)
from .breakpoints import CacheBreakpointPlacer
from ..utils import get_logger


class PromptCacheManager:
    """
    Manages prompt caching for ZenMux API calls.
    
    Features:
    - Auto-detection of cache strategy based on model
    - Optimal breakpoint placement
    - Support for tools, system prompt, and conversation caching
    - Cache statistics tracking
    
    Usage:
        manager = PromptCacheManager()
        
        # Apply caching to request
        cached_request = manager.apply_caching(
            model="anthropic/claude-sonnet-4.5",
            messages=messages,
            system=system_prompt,
            tools=tools,
        )
    """
    
    def __init__(self, config: CacheConfig | None = None):
        self.config = config or CacheConfig()
        self.breakpoint_placer = CacheBreakpointPlacer(self.config)
        self.logger = get_logger("zenmux_integration.caching")
        
        self._stats = {
            "requests_processed": 0,
            "explicit_cache_applied": 0,
            "implicit_cache_used": 0,
            "total_cached_tokens": 0,
        }
    
    def apply_caching(
        self,
        model: str,
        messages: list[dict[str, Any]],
        system: list[dict[str, Any]] | str | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """
        Apply prompt caching to API request components.
        
        Args:
            model: Model identifier (e.g., "anthropic/claude-sonnet-4.5")
            messages: Conversation messages
            system: System prompt (string or content blocks)
            tools: Tool definitions
            
        Returns:
            Dictionary with cached components:
            - messages: Messages with cache_control (if applicable)
            - system: System prompt with cache_control (if applicable)
            - tools: Tools with cache_control (if applicable)
            - cache_type: "implicit" or "explicit"
            - breakpoints: List of where breakpoints were placed
        """
        if not self.config.enabled:
            return {
                "messages": messages,
                "system": system,
                "tools": tools,
                "cache_type": None,
                "breakpoints": [],
            }
        
        self._stats["requests_processed"] += 1
        
        strategy = detect_cache_strategy(model)
        cache_type = strategy.get_cache_type()
        
        self.logger.debug(f"Using {cache_type.value} caching for model: {model}")
        
        if cache_type == CacheType.IMPLICIT:
            self._stats["implicit_cache_used"] += 1
            return {
                "messages": messages,
                "system": system,
                "tools": tools,
                "cache_type": cache_type.value,
                "breakpoints": ["auto"],
            }
        
        self._stats["explicit_cache_applied"] += 1
        
        cached_tools = self.breakpoint_placer.apply_tool_caching(tools, strategy) if tools else None
        cached_system = self.breakpoint_placer.apply_system_caching(system, strategy) if system else None
        cached_messages = self.breakpoint_placer.apply_message_caching(messages, strategy)
        
        summary = self.breakpoint_placer.get_breakpoint_summary(tools, system, messages)
        self._stats["total_cached_tokens"] += summary["total_tokens"]
        
        self.logger.info(
            f"Applied explicit caching: {len(summary['breakpoints'])} breakpoints, "
            f"~{summary['total_tokens']} tokens"
        )
        
        return {
            "messages": cached_messages,
            "system": cached_system,
            "tools": cached_tools,
            "cache_type": cache_type.value,
            "breakpoints": summary["breakpoints"],
        }
    
    def prepare_request_params(
        self,
        model: str,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Prepare complete API request parameters with caching applied.
        
        This is a convenience method that returns ready-to-use params.
        
        Args:
            model: Model identifier
            messages: Conversation messages
            system: System prompt
            tools: Tool definitions
            **kwargs: Additional API parameters
            
        Returns:
            Complete request parameters dict
        """
        cached = self.apply_caching(
            model=model,
            messages=messages,
            system=system,
            tools=tools,
        )
        
        params = {
            "model": model,
            "messages": cached["messages"],
            **kwargs,
        }
        
        if cached["system"]:
            strategy = detect_cache_strategy(model)
            if isinstance(strategy, ExplicitCacheStrategy):
                params["system"] = cached["system"]
            else:
                if isinstance(cached["system"], str):
                    params["messages"] = [
                        {"role": "system", "content": cached["system"]}
                    ] + params["messages"]
                elif isinstance(cached["system"], list):
                    params["messages"] = [
                        {"role": "system", "content": cached["system"]}
                    ] + params["messages"]
        
        if cached["tools"]:
            params["tools"] = cached["tools"]
        
        return params
    
    def get_statistics(self) -> dict[str, Any]:
        """Get caching statistics."""
        return dict(self._stats)
    
    def reset_statistics(self) -> None:
        """Reset caching statistics."""
        self._stats = {
            "requests_processed": 0,
            "explicit_cache_applied": 0,
            "implicit_cache_used": 0,
            "total_cached_tokens": 0,
        }
    
    def estimate_cache_savings(
        self,
        model: str,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """
        Estimate potential cache savings for a request.
        
        Args:
            model: Model identifier
            messages: Conversation messages
            system: System prompt
            tools: Tool definitions
            
        Returns:
            Dictionary with:
            - cacheable_tokens: Tokens that can be cached
            - potential_savings_percent: Estimated cost savings (0-90%)
            - cache_type: Type of caching that would be used
        """
        strategy = detect_cache_strategy(model)
        summary = self.breakpoint_placer.get_breakpoint_summary(tools, system, messages)
        
        cacheable_tokens = 0
        if summary["tools"]["cacheable"]:
            cacheable_tokens += summary["tools"]["tokens"]
        if summary["system"]["cacheable"]:
            cacheable_tokens += summary["system"]["tokens"]
        
        total_tokens = summary["total_tokens"]
        savings_percent = (cacheable_tokens / total_tokens * 90) if total_tokens > 0 else 0
        
        return {
            "cacheable_tokens": cacheable_tokens,
            "total_tokens": total_tokens,
            "potential_savings_percent": round(savings_percent, 1),
            "cache_type": strategy.get_cache_type().value,
            "breakpoints": summary["breakpoints"],
        }
