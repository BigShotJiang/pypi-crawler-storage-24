"""
Stream event handlers
"""

from typing import Optional, Callable, Awaitable
from abc import ABC, abstractmethod

from .models import StreamChunk
from ..utils import get_logger


class StreamHandler(ABC):
    """Base handler for stream events"""
    
    def __init__(self):
        self.logger = get_logger("zenmux_integration.streaming")
    
    @abstractmethod
    async def on_start(self):
        """Called when stream starts"""
        pass
    
    @abstractmethod
    async def on_chunk(self, chunk: StreamChunk):
        """Called for each chunk"""
        pass
    
    @abstractmethod
    async def on_complete(self, full_response: str):
        """Called when stream completes"""
        pass
    
    @abstractmethod
    async def on_error(self, error: Exception):
        """Called on stream error"""
        pass


class DefaultStreamHandler(StreamHandler):
    """Default stream handler implementation"""
    
    def __init__(
        self,
        on_chunk_callback: Optional[Callable[[StreamChunk], Awaitable[None]]] = None
    ):
        super().__init__()
        self.on_chunk_callback = on_chunk_callback
        self.chunks = []
    
    async def on_start(self):
        """Called when stream starts"""
        self.logger.debug("Stream started")
        self.chunks = []
    
    async def on_chunk(self, chunk: StreamChunk):
        """Called for each chunk"""
        self.chunks.append(chunk)
        
        if self.on_chunk_callback:
            await self.on_chunk_callback(chunk)
    
    async def on_complete(self, full_response: str):
        """Called when stream completes"""
        self.logger.debug(
            f"Stream completed: {len(self.chunks)} chunks, "
            f"{len(full_response)} characters"
        )
    
    async def on_error(self, error: Exception):
        """Called on stream error"""
        self.logger.error(f"Stream error: {error}")


class PrintStreamHandler(StreamHandler):
    """Stream handler that prints chunks to console"""
    
    def __init__(self, flush: bool = True):
        super().__init__()
        self.flush = flush
    
    async def on_start(self):
        """Called when stream starts"""
        self.logger.debug("Stream started (print mode)")
    
    async def on_chunk(self, chunk: StreamChunk):
        """Called for each chunk"""
        print(chunk.content, end="", flush=self.flush)
    
    async def on_complete(self, full_response: str):
        """Called when stream completes"""
        print()  # New line
        self.logger.debug("Stream completed (print mode)")
    
    async def on_error(self, error: Exception):
        """Called on stream error"""
        print(f"\nError: {error}")
        self.logger.error(f"Stream error: {error}")


class BufferedStreamHandler(StreamHandler):
    """Stream handler that buffers chunks"""
    
    def __init__(self, buffer_size: int = 10):
        super().__init__()
        self.buffer_size = buffer_size
        self.buffer = []
        self.all_chunks = []
    
    async def on_start(self):
        """Called when stream starts"""
        self.buffer = []
        self.all_chunks = []
        self.logger.debug(f"Stream started (buffer size: {self.buffer_size})")
    
    async def on_chunk(self, chunk: StreamChunk):
        """Called for each chunk"""
        self.buffer.append(chunk)
        self.all_chunks.append(chunk)
        
        if len(self.buffer) >= self.buffer_size:
            await self._flush_buffer()
    
    async def on_complete(self, full_response: str):
        """Called when stream completes"""
        if self.buffer:
            await self._flush_buffer()
        
        self.logger.debug(
            f"Stream completed: {len(self.all_chunks)} total chunks, "
            f"buffer size: {self.buffer_size}"
        )
    
    async def on_error(self, error: Exception):
        """Called on stream error"""
        self.logger.error(f"Stream error: {error}")
    
    async def _flush_buffer(self):
        """Flush the buffer"""
        content = "".join(chunk.content for chunk in self.buffer)
        self.logger.debug(f"Flushing buffer: {len(self.buffer)} chunks, {len(content)} chars")
        self.buffer = []
