"""
Streaming manager for Zenmux integration
"""

import time
import asyncio
from typing import Optional, Dict, Any, List, AsyncIterator, Callable, Awaitable

from .models import StreamChunk, StreamMetrics
from .handlers import StreamHandler, DefaultStreamHandler
from .aggregator import ChunkAggregator
from ..exceptions import StreamingError
from ..utils import get_logger


class StreamingManager:
    """Manages streaming responses from Zenmux API"""
    
    def __init__(self, client):
        """
        Initialize streaming manager
        
        Args:
            client: ZenmuxClient instance
        """
        self.client = client
        self.logger = get_logger("zenmux_integration.streaming")
        self.handlers: Dict[str, StreamHandler] = {}
        self.metrics: Dict[str, StreamMetrics] = {}
    
    def register_handler(self, name: str, handler: StreamHandler):
        """
        Register a stream handler
        
        Args:
            name: Handler name
            handler: StreamHandler instance
        """
        self.handlers[name] = handler
        self.logger.debug(f"Registered handler: {name}")
    
    def unregister_handler(self, name: str):
        """
        Unregister a stream handler
        
        Args:
            name: Handler name
        """
        if name in self.handlers:
            del self.handlers[name]
            self.logger.debug(f"Unregistered handler: {name}")
    
    async def stream_completion(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        handler: Optional[StreamHandler] = None,
        on_chunk: Optional[Callable[[StreamChunk], Awaitable[None]]] = None,
        **kwargs
    ) -> AsyncIterator[StreamChunk]:
        """
        Stream completion with event handling
        
        Args:
            messages: List of message dictionaries
            model: Model identifier
            handler: Optional stream handler
            on_chunk: Optional chunk callback
            **kwargs: Additional parameters
            
        Yields:
            StreamChunk instances
        """
        # Use provided handler or create default
        if handler is None:
            handler = DefaultStreamHandler(on_chunk_callback=on_chunk)
        
        # Initialize metrics
        metrics = StreamMetrics()
        start_time = time.time()
        first_chunk_time = None
        
        # Initialize aggregator
        aggregator = ChunkAggregator()
        
        try:
            # Notify handler of stream start
            await handler.on_start()
            
            # Get streaming response from client
            stream = await self.client._openai_client.chat.completions.create(
                model=model,
                messages=messages,
                stream=True,
                **kwargs
            )
            
            # Process stream chunks
            async for chunk_data in stream:
                # Record TTFT
                if first_chunk_time is None:
                    first_chunk_time = time.time()
                    metrics.ttft = first_chunk_time - start_time
                    self.logger.debug(f"TTFT: {metrics.ttft:.3f}s")
                
                # Extract chunk content
                chunk = self._parse_chunk(chunk_data)
                
                # Update metrics
                metrics.chunks_received += 1
                if chunk.content:
                    metrics.total_tokens += len(chunk.content.split())
                
                # Add to aggregator
                aggregator.add_chunk(chunk)
                
                # Notify handler
                await handler.on_chunk(chunk)
                
                # Yield chunk
                yield chunk
            
            # Calculate final metrics
            metrics.total_time = time.time() - start_time
            metrics.calculate_tps()
            
            # Get complete response
            complete_response = aggregator.get_complete_content()
            
            # Notify handler of completion
            await handler.on_complete(complete_response)
            
            # Store metrics
            self.metrics[f"{model}_{int(time.time())}"] = metrics
            
            self.logger.info(
                f"Stream completed: TTFT={metrics.ttft:.3f}s, "
                f"Total={metrics.total_time:.3f}s, "
                f"Chunks={metrics.chunks_received}, "
                f"TPS={metrics.tokens_per_second:.1f}"
            )
            
        except Exception as e:
            self.logger.error(f"Streaming error: {e}")
            await handler.on_error(e)
            raise StreamingError(f"Streaming failed: {e}")
    
    async def stream_tool_calls(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
        model: str,
        handler: Optional[StreamHandler] = None,
        **kwargs
    ) -> AsyncIterator[StreamChunk]:
        """
        Stream tool calls incrementally
        
        Args:
            messages: List of message dictionaries
            tools: Tool definitions
            model: Model identifier
            handler: Optional stream handler
            **kwargs: Additional parameters
            
        Yields:
            StreamChunk instances with tool calls
        """
        # Add tools to kwargs
        kwargs["tools"] = tools
        
        # Stream with tool calls
        async for chunk in self.stream_completion(
            messages=messages,
            model=model,
            handler=handler,
            **kwargs
        ):
            yield chunk
    
    def _parse_chunk(self, chunk_data: Any) -> StreamChunk:
        """
        Parse raw chunk data into StreamChunk
        
        Args:
            chunk_data: Raw chunk data from API
            
        Returns:
            StreamChunk instance
        """
        try:
            # Extract delta from chunk
            if hasattr(chunk_data, "choices") and len(chunk_data.choices) > 0:
                choice = chunk_data.choices[0]
                delta = choice.delta
                
                # Extract content
                content = getattr(delta, "content", "") or ""
                role = getattr(delta, "role", "assistant") or "assistant"
                finish_reason = getattr(choice, "finish_reason", None)
                
                # Extract tool calls
                tool_calls = None
                if hasattr(delta, "tool_calls") and delta.tool_calls:
                    tool_calls = []
                    for tc in delta.tool_calls:
                        tool_call_dict = {
                            "index": getattr(tc, "index", 0),
                            "id": getattr(tc, "id", None),
                            "type": getattr(tc, "type", "function"),
                        }
                        
                        if hasattr(tc, "function"):
                            tool_call_dict["function"] = {
                                "name": getattr(tc.function, "name", None),
                                "arguments": getattr(tc.function, "arguments", ""),
                            }
                        
                        tool_calls.append(tool_call_dict)
                
                return StreamChunk(
                    content=content,
                    role=role,
                    finish_reason=finish_reason,
                    tool_calls=tool_calls,
                    index=0,
                )
            
            # Empty chunk
            return StreamChunk(content="", role="assistant")
            
        except Exception as e:
            self.logger.error(f"Error parsing chunk: {e}")
            return StreamChunk(content="", role="assistant")
    
    def get_metrics(self, model: Optional[str] = None) -> Dict[str, Any]:
        """
        Get streaming metrics
        
        Args:
            model: Optional model filter
            
        Returns:
            Metrics dictionary
        """
        if model:
            # Filter by model
            filtered = {
                k: v for k, v in self.metrics.items()
                if k.startswith(model)
            }
            return filtered
        
        return self.metrics
    
    def get_average_ttft(self) -> float:
        """
        Get average TTFT across all streams
        
        Returns:
            Average TTFT in seconds
        """
        if not self.metrics:
            return 0.0
        
        total_ttft = sum(m.ttft for m in self.metrics.values())
        return total_ttft / len(self.metrics)
    
    def get_average_tps(self) -> float:
        """
        Get average tokens per second
        
        Returns:
            Average TPS
        """
        if not self.metrics:
            return 0.0
        
        total_tps = sum(m.tokens_per_second for m in self.metrics.values())
        return total_tps / len(self.metrics)
    
    def clear_metrics(self):
        """Clear all metrics"""
        self.metrics = {}
        self.logger.debug("Metrics cleared")
