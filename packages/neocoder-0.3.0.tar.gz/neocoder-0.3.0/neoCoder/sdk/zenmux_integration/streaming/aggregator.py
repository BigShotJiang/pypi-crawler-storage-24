"""
Chunk aggregation for streaming responses
"""

from typing import Dict, List, Optional, Any
from .models import StreamChunk, ToolCallChunk
from ..utils import get_logger


class ChunkAggregator:
    """Aggregates streaming chunks into complete responses"""
    
    def __init__(self):
        self.logger = get_logger("zenmux_integration.streaming")
        self.buffer: List[str] = []
        self.tool_calls: Dict[int, ToolCallChunk] = {}
        self.role: str = "assistant"
        self.finish_reason: Optional[str] = None
        self.chunk_count: int = 0
    
    def reset(self):
        """Reset aggregator state"""
        self.buffer = []
        self.tool_calls = {}
        self.role = "assistant"
        self.finish_reason = None
        self.chunk_count = 0
        self.logger.debug("Aggregator reset")
    
    def add_chunk(self, chunk: StreamChunk):
        """
        Add chunk to aggregation buffer
        
        Args:
            chunk: Stream chunk to add
        """
        self.chunk_count += 1
        
        # Add content to buffer
        if chunk.content:
            self.buffer.append(chunk.content)
        
        # Update role
        if chunk.role:
            self.role = chunk.role
        
        # Update finish reason
        if chunk.finish_reason:
            self.finish_reason = chunk.finish_reason
        
        # Aggregate tool calls
        if chunk.tool_calls:
            for tool_call_dict in chunk.tool_calls:
                self._aggregate_tool_call(tool_call_dict)
    
    def _aggregate_tool_call(self, tool_call_dict: Dict[str, Any]):
        """
        Aggregate tool call chunks
        
        Args:
            tool_call_dict: Tool call dictionary from chunk
        """
        index = tool_call_dict.get("index", 0)
        
        if index not in self.tool_calls:
            # Initialize new tool call
            self.tool_calls[index] = ToolCallChunk(
                index=index,
                id=tool_call_dict.get("id"),
                type=tool_call_dict.get("type", "function"),
            )
        
        tool_call = self.tool_calls[index]
        
        # Update ID if provided
        if "id" in tool_call_dict and tool_call_dict["id"]:
            tool_call.id = tool_call_dict["id"]
        
        # Aggregate function information
        if "function" in tool_call_dict:
            function = tool_call_dict["function"]
            
            # Update function name
            if "name" in function and function["name"]:
                tool_call.function_name = function["name"]
            
            # Append function arguments
            if "arguments" in function and function["arguments"]:
                tool_call.function_arguments += function["arguments"]
    
    def get_complete_content(self) -> str:
        """
        Get aggregated complete content
        
        Returns:
            Complete content string
        """
        return "".join(self.buffer)
    
    def get_tool_calls(self) -> List[Dict[str, Any]]:
        """
        Get aggregated tool calls
        
        Returns:
            List of complete tool call dictionaries
        """
        result = []
        
        for tool_call in self.tool_calls.values():
            result.append({
                "id": tool_call.id,
                "type": tool_call.type,
                "function": {
                    "name": tool_call.function_name,
                    "arguments": tool_call.function_arguments,
                }
            })
        
        return result
    
    def get_complete_response(self) -> Dict[str, Any]:
        """
        Get aggregated complete response
        
        Returns:
            Complete response dictionary
        """
        response = {
            "role": self.role,
            "content": self.get_complete_content(),
        }
        
        tool_calls = self.get_tool_calls()
        if tool_calls:
            response["tool_calls"] = tool_calls
        
        if self.finish_reason:
            response["finish_reason"] = self.finish_reason
        
        return response
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get aggregation statistics
        
        Returns:
            Statistics dictionary
        """
        return {
            "chunk_count": self.chunk_count,
            "content_length": len(self.get_complete_content()),
            "tool_calls_count": len(self.tool_calls),
            "finish_reason": self.finish_reason,
        }
