"""
Unified Zenmux client for all advanced features
"""

import time
import asyncio
from typing import Optional, Dict, Any, List, Union, AsyncIterator, Type
from openai import AsyncOpenAI
from pydantic import BaseModel

from .config import ZenmuxConfig
from .exceptions import (
    ZenmuxError,
    AuthenticationError,
    RateLimitError,
)
from .utils import setup_logger, get_logger


class ZenmuxClient:
    """
    Unified client for all Zenmux features
    
    Features:
    - Streaming responses
    - Structured output
    - Enhanced tool calling
    - Reasoning control
    """
    
    def __init__(self, config: Optional[ZenmuxConfig] = None):
        """
        Initialize Zenmux client
        
        Args:
            config: Zenmux configuration. If None, loads from environment.
        """
        self.config = config or ZenmuxConfig.from_env()
        
        # Setup logging
        self.logger = setup_logger(
            name="zenmux_integration",
            level=self.config.log_level
        )
        
        # Initialize HTTP client for Zenmux API (OpenAI-compatible protocol)
        self._openai_client = AsyncOpenAI(
            api_key=self.config.api_key,
            base_url=self.config.base_url,
            timeout=self.config.timeout,
            max_retries=self.config.max_retries,
        )
        
        # Initialize feature managers
        from .streaming import StreamingManager
        from .structured_output import StructuredOutputManager
        from .tool_calling import ToolRegistry, ToolExecutor, ToolCallFormatter, ToolChoiceManager
        from .reasoning import ReasoningController, AdaptiveReasoningManager
        
        self.streaming = StreamingManager(self)  # Phase 2: Streaming
        self.structured = StructuredOutputManager()  # Phase 3: Structured Output
        
        # Phase 4: Tool Calling
        self.tool_registry = ToolRegistry()
        self.tool_executor = ToolExecutor(
            registry=self.tool_registry,
            max_retries=self.config.max_retries,
            timeout=self.config.timeout
        )
        self.tool_formatter = ToolCallFormatter()
        self.tool_choice_manager = ToolChoiceManager()
        
        # Phase 5: Reasoning Control
        self.reasoning = ReasoningController()
        self.adaptive_reasoning = AdaptiveReasoningManager(client=self)
        
        # Phase 6: Prompt Caching
        from .caching import PromptCacheManager, CacheConfig
        cache_config = CacheConfig(
            enabled=self.config.prompt_caching_enabled,
            min_tokens_for_cache=self.config.min_tokens_for_cache,
            max_breakpoints=self.config.max_cache_breakpoints,
        )
        self.cache_manager = PromptCacheManager(config=cache_config)
        
        # Phase 7: Token Estimation
        from .token_estimator import TokenEstimator
        self.token_estimator = TokenEstimator()
        
        # Rate limiting
        self._last_request_time = 0.0
        self._min_request_interval = 0.01  # 10ms between requests (minimal throttling)
        
        self.logger.info("ZenmuxClient initialized successfully")
    
    async def _wait_for_rate_limit(self):
        """Wait if necessary to respect rate limits"""
        current_time = time.time()
        time_since_last_request = current_time - self._last_request_time
        
        if time_since_last_request < self._min_request_interval:
            wait_time = self._min_request_interval - time_since_last_request
            self.logger.debug(f"Rate limiting: waiting {wait_time:.3f}s")
            await asyncio.sleep(wait_time)
        
        self._last_request_time = time.time()
    
    async def _handle_api_error(self, error: Exception, attempt: int) -> bool:
        """
        Handle API errors with retry logic
        
        Args:
            error: The exception that occurred
            attempt: Current attempt number
            
        Returns:
            True if should retry, False otherwise
        """
        if attempt >= self.config.max_retries:
            return False
        
        # Check if error is retryable
        error_str = str(error).lower()
        
        if "rate limit" in error_str or "429" in error_str:
            # Rate limit error - wait and retry
            wait_time = min(2 ** attempt, 60)  # Exponential backoff, max 60s
            self.logger.warning(
                f"Rate limit hit, waiting {wait_time}s before retry "
                f"(attempt {attempt + 1}/{self.config.max_retries})"
            )
            await asyncio.sleep(wait_time)
            return True
        
        if "timeout" in error_str or "connection" in error_str:
            # Network error - retry with backoff
            wait_time = min(2 ** attempt, 30)
            self.logger.warning(
                f"Network error, waiting {wait_time}s before retry "
                f"(attempt {attempt + 1}/{self.config.max_retries})"
            )
            await asyncio.sleep(wait_time)
            return True
        
        if "500" in error_str or "502" in error_str or "503" in error_str:
            # Server error - retry with backoff
            wait_time = min(2 ** attempt, 30)
            self.logger.warning(
                f"Server error, waiting {wait_time}s before retry "
                f"(attempt {attempt + 1}/{self.config.max_retries})"
            )
            await asyncio.sleep(wait_time)
            return True
        
        # Non-retryable error
        return False
    
    async def complete(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        stream: bool = False,
        response_format: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        tool_choice: Optional[str] = None,
        reasoning: Optional[Dict[str, Any]] = None,
        on_chunk: Optional[Any] = None,
        system: Optional[Union[str, List[Dict[str, Any]]]] = None,
        enable_caching: bool = True,
        **kwargs
    ) -> Union[Any, AsyncIterator[Any]]:
        """
        Unified completion method with all features
        
        Args:
            messages: List of message dictionaries
            model: Model identifier (e.g., "anthropic/claude-3-5-sonnet-20241022")
            stream: Enable streaming responses
            response_format: Structured output format
            tools: Tool definitions
            tool_choice: Tool choice strategy
            reasoning: Reasoning parameters
            on_chunk: Optional callback for streaming chunks
            system: System prompt (for explicit caching with Anthropic)
            enable_caching: Enable prompt caching (default: True)
            **kwargs: Additional parameters
            
        Returns:
            Completion response or async iterator for streaming
        """
        # Apply prompt caching if enabled
        if enable_caching and self.config.prompt_caching_enabled:
            cached = self.cache_manager.apply_caching(
                model=model,
                messages=messages,
                system=system,
                tools=tools,
            )
            messages = cached["messages"]
            if cached["tools"]:
                tools = cached["tools"]
            if cached["system"]:
                # For Anthropic, system is passed separately
                # Add to kwargs for proper handling
                kwargs["system"] = cached["system"]
            
            self.logger.debug(
                f"Caching applied: type={cached['cache_type']}, "
                f"breakpoints={cached['breakpoints']}"
            )
        
        # Handle streaming mode
        if stream and self.config.streaming_enabled:
            self.logger.info(f"Streaming request: model={model}, messages={len(messages)}")
            
            # Use streaming manager
            return self.streaming.stream_completion(
                messages=messages,
                model=model,
                on_chunk=on_chunk,
                **kwargs
            )
        
        # Non-streaming mode
        # Apply rate limiting
        await self._wait_for_rate_limit()
        
        # Log request if enabled
        if self.config.log_requests:
            self.logger.info(
                f"API request: model={model}, stream={stream}, "
                f"messages={len(messages)}, tools={len(tools) if tools else 0}"
            )
        
        # Build request parameters
        params = {
            "model": model,
            "messages": messages,
            **kwargs
        }
        
        if stream and self.config.streaming_enabled:
            params["stream"] = True
        
        if response_format and self.config.structured_output_enabled:
            params["response_format"] = response_format
        
        if tools and self.config.tool_calling_enabled:
            params["tools"] = tools
            if tool_choice:
                # Parse and validate tool_choice
                parsed_choice = self.tool_choice_manager.parse_tool_choice(tool_choice)
                if parsed_choice:
                    # Validate against available tools
                    tool_names = [t.get("function", {}).get("name") for t in tools if t.get("function", {}).get("name")]
                    self.tool_choice_manager.validate_tool_choice(parsed_choice, tool_names)
                    params["tool_choice"] = parsed_choice
                    
                    self.logger.debug(f"Using tool_choice: {parsed_choice}")
        
        if reasoning is not None and self.config.reasoning_enabled:
            if isinstance(reasoning, dict):
                # Detect if this is an Anthropic model
                is_anthropic = model and ("claude" in model.lower() or "anthropic" in model.lower())
                
                # Check for pre-built thinking object (from ReasoningParams.to_api_params())
                if "thinking" in reasoning:
                    # Already has thinking object, use directly
                    params.setdefault("extra_body", {})["thinking"] = reasoning["thinking"]
                    self.logger.debug(f"Using pre-built thinking: {reasoning['thinking']}")
                elif is_anthropic and reasoning.get("thinking_budget"):
                    # For Anthropic models with raw thinking_budget
                    # See: https://zenmux.ai/docs/api/anthropic/create-messages-new.html
                    budget = max(1024, reasoning["thinking_budget"])
                    params.setdefault("extra_body", {})["thinking"] = {
                        "type": "enabled",
                        "budget_tokens": budget
                    }
                    self.logger.debug(f"Using thinking for Anthropic: budget_tokens={budget}")
                elif "reasoning_effort" in reasoning or "effort" in reasoning or "max_tokens" in reasoning:
                    # For models using reasoning parameter
                    # See: https://zenmux.ai/docs/guide/advanced/reasoning.html
                    reasoning_config = {
                        "effort": reasoning.get("effort") or reasoning.get("reasoning_effort", self.config.default_reasoning_effort),
                        "max_tokens": reasoning.get("max_tokens", self.config.default_reasoning_max_tokens)
                    }
                    
                    # Add optional parameters if present
                    if "enabled" in reasoning:
                        reasoning_config["enabled"] = reasoning["enabled"]
                    
                    params.setdefault("extra_body", {})["reasoning"] = reasoning_config
                    self.logger.debug(f"Using reasoning: {reasoning_config}")
        
        # Prepare token estimation (for learning)
        prompt_chars = self.token_estimator.prepare_for_request(messages, model)
        self.logger.debug(f"Estimated prompt tokens: {prompt_chars}")
        
        # Make API request with retry logic
        attempt = 0
        while attempt <= self.config.max_retries:
            try:
                response = await self._openai_client.chat.completions.create(**params)
                
                # Learn from response for better future estimation
                usage = self.token_estimator.learn_from_response(response, model=model)
                if usage.total > 0:
                    self.logger.debug(
                        f"Token usage: input={usage.total_input}, output={usage.output_tokens}, "
                        f"cache_read={usage.cache_read_tokens}"
                    )
                
                # Log response if enabled
                if self.config.log_responses:
                    self.logger.debug(f"API response: {response}")
                
                return response
                
            except Exception as e:
                self.logger.error(f"API error (attempt {attempt + 1}): {e}")
                
                should_retry = await self._handle_api_error(e, attempt)
                if not should_retry:
                    # Check if we've exhausted retries
                    if attempt >= self.config.max_retries:
                        # Convert to appropriate exception type even after max retries
                        if "authentication" in str(e).lower() or "401" in str(e):
                            raise AuthenticationError(f"Authentication failed after {self.config.max_retries} retries: {e}")
                        elif "rate limit" in str(e).lower() or "429" in str(e):
                            raise RateLimitError(f"Rate limit exceeded after {self.config.max_retries} retries: {e}")
                        else:
                            raise ZenmuxError(f"Max retries ({self.config.max_retries}) exceeded: {e}")
                    
                    # Convert to appropriate exception type
                    if "authentication" in str(e).lower() or "401" in str(e):
                        raise AuthenticationError(f"Authentication failed: {e}")
                    elif "rate limit" in str(e).lower() or "429" in str(e):
                        raise RateLimitError(f"Rate limit exceeded: {e}")
                    else:
                        raise ZenmuxError(f"API request failed: {e}")
                
                attempt += 1
        
        raise ZenmuxError(f"Max retries ({self.config.max_retries}) exceeded")
    
    async def complete_structured(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        response_model: Type[BaseModel],
        strict: bool = True,
        **kwargs
    ) -> BaseModel:
        """
        Complete with structured output
        
        Args:
            messages: List of message dictionaries
            model: Model identifier
            response_model: Pydantic model for response
            strict: Enable strict mode (default: True)
            **kwargs: Additional parameters
            
        Returns:
            Validated Pydantic model instance
            
        Raises:
            StructuredOutputError: If validation fails
        """
        if not self.config.structured_output_enabled:
            raise ZenmuxError("Structured output is not enabled in config")
        
        # Create response format
        response_format = self.structured.create_response_format(
            schema_type="json_schema",
            model_class=response_model,
            strict=strict,
        )
        
        # Make API call
        response = await self.complete(
            messages=messages,
            model=model,
            response_format=response_format,
            **kwargs
        )
        
        # Extract content
        content = response.choices[0].message.content
        
        # Validate and parse
        validated = self.structured.validate_response(
            response=content,
            model_class=response_model,
        )
        
        return validated
    
    async def complete_with_tools(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
        model: str,
        auto_execute: bool = True,
        max_iterations: int = 5,
        tool_choice: Optional[Union[str, Dict[str, Any]]] = None,
        parallel_execution: bool = True,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Complete with automatic tool execution
        
        Args:
            messages: List of message dictionaries
            tools: Tool definitions
            model: Model identifier
            auto_execute: Automatically execute tool calls (default: True)
            max_iterations: Maximum tool execution iterations (default: 5)
            tool_choice: Tool choice strategy:
                - String: "auto", "any", "none"
                - Dict: {"type": "auto|any|tool|none", "name": "tool_name", "disable_parallel_tool_use": bool}
                - ToolChoice instance
            parallel_execution: Execute multiple tool calls in parallel (default: True)
            **kwargs: Additional parameters
            
        Returns:
            Dictionary with:
                - response: Final completion response
                - tool_calls: List of tool calls made
                - tool_results: List of tool results
                - iterations: Number of iterations
                
        Raises:
            ZenmuxError: If tool calling is not enabled or max iterations exceeded
        """
        if not self.config.tool_calling_enabled:
            raise ZenmuxError("Tool calling is not enabled in config")
        
        # Parse and validate tool_choice
        parsed_tool_choice = None
        if tool_choice:
            parsed_tool_choice = self.tool_choice_manager.parse_tool_choice(tool_choice)
            tool_names = [t.get("function", {}).get("name") for t in tools if t.get("function", {}).get("name")]
            self.tool_choice_manager.validate_tool_choice(parsed_tool_choice, tool_names)
        
        # Check if parallel execution should be disabled by tool_choice
        if parsed_tool_choice and self.tool_choice_manager.is_parallel_disabled(parsed_tool_choice):
            parallel_execution = False
            self.logger.info("Parallel tool execution disabled by tool_choice")
        
        # Initialize tracking
        all_tool_calls = []
        all_tool_results = []
        conversation_messages = messages.copy()
        iteration = 0
        
        self.logger.info(
            f"Starting tool calling: auto_execute={auto_execute}, "
            f"max_iterations={max_iterations}, tools={len(tools)}, "
            f"tool_choice={parsed_tool_choice}, parallel={parallel_execution}"
        )
        
        while iteration < max_iterations:
            iteration += 1
            self.logger.debug(f"Tool calling iteration {iteration}/{max_iterations}")
            
            # Make API call with tools
            response = await self.complete(
                messages=conversation_messages,
                model=model,
                tools=tools,
                tool_choice=parsed_tool_choice,
                **kwargs
            )
            
            # Check if model wants to call tools
            has_tool_calls = self.tool_formatter.has_tool_calls(response)
            
            if not has_tool_calls:
                # No tool calls - return final response
                self.logger.info(
                    f"Completed after {iteration} iterations with "
                    f"{len(all_tool_calls)} total tool calls"
                )
                
                return {
                    "response": response,
                    "tool_calls": all_tool_calls,
                    "tool_results": all_tool_results,
                    "iterations": iteration,
                    "final_message": response.choices[0].message.content,
                }
            
            # Extract tool calls
            tool_calls = self.tool_formatter.extract_tool_calls_from_response(response)
            self.logger.info(f"Model requested {len(tool_calls)} tool calls")
            
            # Add assistant message with tool calls to conversation
            assistant_message = self.tool_formatter.format_tool_call_message(
                tool_calls=tool_calls,
                content=response.choices[0].message.content or ""
            )
            conversation_messages.append(assistant_message)
            
            # Track tool calls
            all_tool_calls.extend(tool_calls)
            
            if not auto_execute:
                # Return without executing tools
                self.logger.info("Auto-execute disabled, returning tool calls")
                return {
                    "response": response,
                    "tool_calls": all_tool_calls,
                    "tool_results": [],
                    "iterations": iteration,
                    "requires_execution": True,
                }
            
            # Execute tool calls
            self.logger.info(f"Executing {len(tool_calls)} tool calls")
            tool_results = await self.tool_executor.execute_tool_calls(
                tool_calls=tool_calls,
                context={"iteration": iteration, "model": model},
                parallel=parallel_execution
            )
            
            # Track results
            all_tool_results.extend(tool_results)
            
            # Add tool results to conversation
            result_messages = self.tool_formatter.format_tool_results_messages(tool_results)
            conversation_messages.extend(result_messages)
            
            # Log execution summary
            successful = sum(1 for r in tool_results if r.is_success())
            failed = len(tool_results) - successful
            self.logger.info(
                f"Tool execution complete: {successful} successful, {failed} failed"
            )
            
            # Check if all tools failed
            if failed == len(tool_results):
                self.logger.warning("All tool calls failed, stopping iteration")
                break
        
        # Max iterations reached
        if iteration >= max_iterations:
            self.logger.warning(f"Max iterations ({max_iterations}) reached")
        
        # Make final call to get response after tool execution
        final_response = await self.complete(
            messages=conversation_messages,
            model=model,
            **kwargs
        )
        
        return {
            "response": final_response,
            "tool_calls": all_tool_calls,
            "tool_results": all_tool_results,
            "iterations": iteration,
            "final_message": final_response.choices[0].message.content,
            "max_iterations_reached": iteration >= max_iterations,
        }
    
    async def execute_with_adaptive_reasoning(
        self,
        task: str,
        messages: List[Dict[str, Any]],
        model: str,
        context: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Execute with adaptive reasoning effort
        
        Automatically detects task complexity and adjusts reasoning effort
        based on historical performance.
        
        Args:
            task: Task description for complexity analysis
            messages: List of message dictionaries
            model: Model identifier (should support reasoning)
            context: Optional context for complexity detection
            **kwargs: Additional parameters
            
        Returns:
            Dictionary with:
                - response: API response
                - performance: Performance metrics
                - trace: Reasoning trace (if available)
                - effort_used: Reasoning effort level used
                - tokens_used: Total tokens used
                - reasoning_tokens: Tokens used for reasoning
                - duration_ms: Execution duration
                
        Example:
            ```python
            result = await client.execute_with_adaptive_reasoning(
                task="Solve this complex mathematical problem",
                messages=[{"role": "user", "content": "..."}],
                model="anthropic/claude-3-5-sonnet-20241022"
            )
            
            print(f"Used {result['effort_used']} effort")
            print(f"Reasoning tokens: {result['reasoning_tokens']}")
            if result['trace']:
                print(result['trace'].get_summary())
            ```
        """
        if not self.config.reasoning_enabled:
            raise ZenmuxError("Reasoning is not enabled in config")
        
        return await self.adaptive_reasoning.execute_with_adaptive_reasoning(
            task=task,
            messages=messages,
            model=model,
            context=context,
            **kwargs
        )
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Get performance metrics
        
        Returns:
            Dictionary of metrics
        """
        metrics = {
            "streaming": {},
            "caching": self.cache_manager.get_statistics() if self.cache_manager else {},
            "token_estimation": self.token_estimator.get_statistics() if self.token_estimator else {},
            "tools": self.tool_executor.get_statistics() if self.tool_executor else {},
            "reasoning": self.adaptive_reasoning.get_statistics() if self.adaptive_reasoning else {},
        }
        
        return metrics
    
    def register_tool(
        self,
        name: str,
        function: Any,
        description: str,
        parameters: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Register a tool for use in completions
        
        Args:
            name: Tool name
            function: Callable function
            description: Tool description
            parameters: JSON Schema for parameters
            metadata: Optional metadata
            
        Example:
            ```python
            def get_weather(location: str) -> str:
                return f"Weather in {location}: Sunny"
            
            client.register_tool(
                name="get_weather",
                function=get_weather,
                description="Get current weather",
                parameters={
                    "type": "object",
                    "properties": {
                        "location": {"type": "string"}
                    },
                    "required": ["location"]
                }
            )
            ```
        """
        self.tool_registry.register(
            name=name,
            function=function,
            description=description,
            parameters=parameters,
            metadata=metadata
        )
        self.logger.info(f"Registered tool: {name}")
    
    def unregister_tool(self, name: str) -> None:
        """
        Unregister a tool
        
        Args:
            name: Tool name
        """
        self.tool_registry.unregister(name)
        self.logger.info(f"Unregistered tool: {name}")
    
    def list_tools(self) -> List[str]:
        """
        List all registered tools
        
        Returns:
            List of tool names
        """
        return self.tool_registry.list_tools()
    
    def get_tool_definitions(
        self,
        allowed_tools: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        Get tool definitions for API
        
        Args:
            allowed_tools: Optional list of allowed tool names
            
        Returns:
            List of tool definitions in API format
        """
        return self.tool_registry.get_tool_definitions(allowed_tools)
    
    async def close(self):
        """Close client and cleanup resources"""
        await self._openai_client.close()
        self.logger.info("ZenmuxClient closed")
