"""
Reasoning trace extractor
"""

import re
import json
from typing import Optional, Dict, Any, List
from .models import ReasoningTrace


class ReasoningTraceExtractor:
    """
    Extracts reasoning traces from model responses
    
    Supports various formats:
    - Structured reasoning in response metadata
    - Thinking tags in content (<thinking>...</thinking>)
    - Step-by-step reasoning patterns
    """
    
    def __init__(self):
        """Initialize extractor"""
        # Patterns for extracting reasoning
        self._thinking_pattern = re.compile(
            r'<thinking>(.*?)</thinking>',
            re.DOTALL | re.IGNORECASE
        )
        
        self._step_pattern = re.compile(
            r'(?:step\s+\d+|^\d+\.|^-\s+)(.+?)(?=step\s+\d+|^\d+\.|^-\s+|$)',
            re.MULTILINE | re.IGNORECASE
        )
    
    def extract(
        self,
        response: Any,
        extract_from_content: bool = True
    ) -> Optional[ReasoningTrace]:
        """
        Extract reasoning trace from response
        
        Args:
            response: API response object
            extract_from_content: Also try to extract from content
            
        Returns:
            ReasoningTrace if found, None otherwise
        """
        # Try to extract from response metadata first
        trace = self._extract_from_metadata(response)
        if trace:
            return trace
        
        # Try to extract from content if enabled
        if extract_from_content:
            trace = self._extract_from_content(response)
            if trace:
                return trace
        
        return None
    
    def _extract_from_metadata(self, response: Any) -> Optional[ReasoningTrace]:
        """
        Extract reasoning from response metadata
        
        Supports:
        - Reasoning metadata
        - Anthropic Extended Thinking blocks (type="thinking" or type="redacted_thinking")
        - Usage tokens
        
        Args:
            response: API response object
            
        Returns:
            ReasoningTrace if found, None otherwise
        """
        try:
            # Check for Anthropic Extended Thinking blocks
            anthropic_trace = self._extract_anthropic_thinking(response)
            if anthropic_trace:
                return anthropic_trace
            
            # Check if response has reasoning metadata
            if hasattr(response, 'reasoning'):
                reasoning_data = response.reasoning
                
                if isinstance(reasoning_data, dict):
                    return ReasoningTrace(
                        thinking=reasoning_data.get('thinking', ''),
                        steps=reasoning_data.get('steps', []),
                        conclusion=reasoning_data.get('conclusion', ''),
                        tokens_used=reasoning_data.get('tokens_used', 0),
                        duration_ms=reasoning_data.get('duration_ms'),
                        metadata=reasoning_data.get('metadata', {})
                    )
            
            # Check usage for reasoning tokens
            if hasattr(response, 'usage'):
                usage = response.usage
                if hasattr(usage, 'reasoning_tokens') and usage.reasoning_tokens > 0:
                    # We have reasoning tokens but no trace
                    # Create minimal trace
                    return ReasoningTrace(
                        thinking="[Reasoning performed but trace not available]",
                        steps=[],
                        conclusion="",
                        tokens_used=usage.reasoning_tokens,
                        metadata={"source": "usage_only"}
                    )
            
        except Exception as e:
            # Silently fail - reasoning extraction is optional
            pass
        
        return None
    
    def _extract_anthropic_thinking(self, response: Any) -> Optional[ReasoningTrace]:
        """
        Extract Anthropic Extended Thinking blocks from response
        
        Anthropic Extended Thinking returns content blocks with:
        - type="thinking": Contains thinking (readable) and signature (encrypted)
        - type="redacted_thinking": Contains data (encrypted)
        
        Args:
            response: API response object
            
        Returns:
            ReasoningTrace if thinking blocks found, None otherwise
        """
        try:
            # Check for content blocks (Anthropic format)
            if hasattr(response, 'content') and isinstance(response.content, list):
                thinking_blocks = []
                thinking_tokens = 0
                
                for block in response.content:
                    # Check for thinking block
                    if hasattr(block, 'type'):
                        if block.type == 'thinking':
                            # Readable thinking block
                            if hasattr(block, 'thinking'):
                                thinking_blocks.append(block.thinking)
                            
                            # Track signature if available
                            if hasattr(block, 'signature'):
                                # Signature is encrypted, just note its presence
                                pass
                        
                        elif block.type == 'redacted_thinking':
                            # Redacted thinking block (encrypted)
                            thinking_blocks.append("[Redacted thinking - encrypted data]")
                
                # If we found thinking blocks, create trace
                if thinking_blocks:
                    combined_thinking = "\n\n".join(thinking_blocks)
                    steps = self._extract_steps(combined_thinking)
                    
                    return ReasoningTrace(
                        thinking=combined_thinking,
                        steps=steps,
                        conclusion=self._extract_conclusion(combined_thinking) if steps else "",
                        tokens_used=self._estimate_tokens(combined_thinking),
                        metadata={
                            "source": "anthropic_thinking_blocks",
                            "num_blocks": len(thinking_blocks)
                        }
                    )
        
        except Exception as e:
            # Silently fail
            pass
        
        return None
    
    def _extract_from_content(self, response: Any) -> Optional[ReasoningTrace]:
        """
        Extract reasoning from response content
        
        Args:
            response: API response object
            
        Returns:
            ReasoningTrace if found, None otherwise
        """
        try:
            # Get content from response
            content = self._get_content(response)
            if not content:
                return None
            
            # Try to extract thinking tags
            thinking_match = self._thinking_pattern.search(content)
            if thinking_match:
                thinking = thinking_match.group(1).strip()
                steps = self._extract_steps(thinking)
                
                return ReasoningTrace(
                    thinking=thinking,
                    steps=steps,
                    conclusion=self._extract_conclusion(thinking),
                    tokens_used=self._estimate_tokens(thinking),
                    metadata={"source": "content_tags"}
                )
            
            # Try to extract step-by-step reasoning
            steps = self._extract_steps(content)
            if len(steps) >= 2:  # At least 2 steps to be considered reasoning
                return ReasoningTrace(
                    thinking=content,
                    steps=steps,
                    conclusion=steps[-1] if steps else "",
                    tokens_used=self._estimate_tokens(content),
                    metadata={"source": "content_steps"}
                )
            
        except Exception as e:
            # Silently fail
            pass
        
        return None
    
    def _get_content(self, response: Any) -> Optional[str]:
        """
        Get content from response
        
        Args:
            response: API response object
            
        Returns:
            Content string or None
        """
        try:
            # Standard chat completion format
            if hasattr(response, 'choices') and response.choices:
                choice = response.choices[0]
                if hasattr(choice, 'message'):
                    return choice.message.content
                elif hasattr(choice, 'text'):
                    return choice.text
            
            # Direct string
            if isinstance(response, str):
                return response
            
            # Dict format
            if isinstance(response, dict):
                if 'content' in response:
                    return response['content']
                if 'text' in response:
                    return response['text']
        
        except Exception:
            pass
        
        return None
    
    def _extract_steps(self, text: str) -> List[str]:
        """
        Extract reasoning steps from text
        
        Args:
            text: Text to extract steps from
            
        Returns:
            List of step descriptions
        """
        steps = []
        
        # Try numbered/bulleted list pattern
        matches = self._step_pattern.findall(text)
        if matches:
            steps = [m.strip() for m in matches if m.strip()]
        
        # If no steps found, try splitting by newlines
        if not steps:
            lines = [line.strip() for line in text.split('\n') if line.strip()]
            # Filter out very short lines (likely not steps)
            steps = [line for line in lines if len(line) > 20]
        
        return steps
    
    def _extract_conclusion(self, text: str) -> str:
        """
        Extract conclusion from reasoning text
        
        Args:
            text: Reasoning text
            
        Returns:
            Conclusion string
        """
        # Look for conclusion keywords
        conclusion_patterns = [
            r'(?:therefore|thus|hence|in conclusion|finally)[,:]?\s*(.+?)(?:\n|$)',
            r'(?:the answer is|the result is|we conclude)[,:]?\s*(.+?)(?:\n|$)',
        ]
        
        for pattern in conclusion_patterns:
            match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
            if match:
                return match.group(1).strip()
        
        # If no explicit conclusion, use last sentence
        sentences = [s.strip() for s in text.split('.') if s.strip()]
        if sentences:
            return sentences[-1]
        
        return ""
    
    def _estimate_tokens(self, text: str) -> int:
        """
        Estimate token count for text
        
        Args:
            text: Text to estimate
            
        Returns:
            Estimated token count
        """
        # Rough estimation: ~4 characters per token
        return len(text) // 4
    
    def format_trace(
        self,
        trace: ReasoningTrace,
        include_thinking: bool = True,
        include_steps: bool = True,
        include_conclusion: bool = True
    ) -> str:
        """
        Format reasoning trace for display
        
        Args:
            trace: Reasoning trace to format
            include_thinking: Include raw thinking
            include_steps: Include step-by-step breakdown
            include_conclusion: Include conclusion
            
        Returns:
            Formatted trace string
        """
        parts = []
        
        if include_thinking and trace.thinking:
            parts.append("=== Thinking ===")
            parts.append(trace.thinking)
            parts.append("")
        
        if include_steps and trace.steps:
            parts.append("=== Steps ===")
            for i, step in enumerate(trace.steps, 1):
                parts.append(f"{i}. {step}")
            parts.append("")
        
        if include_conclusion and trace.conclusion:
            parts.append("=== Conclusion ===")
            parts.append(trace.conclusion)
            parts.append("")
        
        # Add metadata
        parts.append(f"Tokens used: {trace.tokens_used}")
        if trace.duration_ms:
            parts.append(f"Duration: {trace.duration_ms:.2f}ms")
        
        return "\n".join(parts)
    
    def extract_key_insights(self, trace: ReasoningTrace) -> List[str]:
        """
        Extract key insights from reasoning trace
        
        Args:
            trace: Reasoning trace
            
        Returns:
            List of key insights
        """
        insights = []
        
        # Add conclusion as primary insight
        if trace.conclusion:
            insights.append(trace.conclusion)
        
        # Add important steps (longer steps likely more important)
        if trace.steps:
            # Sort by length and take top 3
            important_steps = sorted(
                trace.steps,
                key=len,
                reverse=True
            )[:3]
            insights.extend(important_steps)
        
        return insights
