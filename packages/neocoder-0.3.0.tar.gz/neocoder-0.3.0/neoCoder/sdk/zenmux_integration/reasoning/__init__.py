"""
Reasoning control module for Zenmux integration

This module provides intelligent reasoning control for models that support
extended thinking/reasoning capabilities (e.g., o1, o3, QwQ).

Features:
- Task complexity analysis
- Adaptive reasoning effort adjustment
- Reasoning trace extraction
- Performance tracking and optimization
"""

from .models import (
    ReasoningTrace,
    ReasoningPerformance,
    TaskComplexity,
    ReasoningEffort,
)
from .analyzer import TaskComplexityAnalyzer
from .extractor import ReasoningTraceExtractor
from .controller import ReasoningController
from .manager import AdaptiveReasoningManager

__all__ = [
    # Models
    "ReasoningTrace",
    "ReasoningPerformance",
    "TaskComplexity",
    "ReasoningEffort",
    # Components
    "TaskComplexityAnalyzer",
    "ReasoningTraceExtractor",
    "ReasoningController",
    "AdaptiveReasoningManager",
]
