"""
Task complexity analyzer for reasoning control
"""

import re
from typing import Dict, Any, List, Optional
from .models import TaskComplexity, ReasoningEffort, ReasoningConfig


class TaskComplexityAnalyzer:
    """
    Analyzes task complexity to determine appropriate reasoning effort
    
    Uses heuristics based on:
    - Keywords in task description
    - Task length and structure
    - Context information
    - Historical performance
    """
    
    def __init__(self, config: Optional[ReasoningConfig] = None):
        """
        Initialize analyzer
        
        Args:
            config: Reasoning configuration
        """
        self.config = config or ReasoningConfig()
        
        # Compile keyword patterns for efficiency
        self._keyword_patterns = {
            complexity: [
                re.compile(r'\b' + re.escape(kw) + r'\b', re.IGNORECASE)
                for kw in keywords
            ]
            for complexity, keywords in self.config.complexity_keywords.items()
        }
    
    def analyze(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None
    ) -> TaskComplexity:
        """
        Analyze task complexity
        
        Args:
            task: Task description
            context: Optional context information
            
        Returns:
            Detected task complexity
        """
        context = context or {}
        
        # Calculate complexity scores
        scores = {
            TaskComplexity.LOW: self._calculate_complexity_score(
                task, TaskComplexity.LOW
            ),
            TaskComplexity.MEDIUM: self._calculate_complexity_score(
                task, TaskComplexity.MEDIUM
            ),
            TaskComplexity.HIGH: self._calculate_complexity_score(
                task, TaskComplexity.HIGH
            ),
        }
        
        # Adjust scores based on context
        if context:
            scores = self._adjust_scores_by_context(scores, context)
        
        # Return complexity with highest score
        return max(scores.items(), key=lambda x: x[1])[0]
    
    def _calculate_complexity_score(
        self,
        task: str,
        complexity: TaskComplexity
    ) -> float:
        """
        Calculate complexity score for a specific level
        
        Args:
            task: Task description
            complexity: Complexity level to score
            
        Returns:
            Score (0-1)
        """
        score = 0.0
        patterns = self._keyword_patterns.get(complexity, [])
        
        # Count keyword matches
        matches = sum(
            1 for pattern in patterns
            if pattern.search(task)
        )
        
        # Normalize by number of keywords
        if patterns:
            score = min(matches / len(patterns), 1.0)
        
        # Adjust by task length (longer tasks tend to be more complex)
        length_factor = min(len(task) / 500, 1.0)  # Normalize to 500 chars
        
        if complexity == TaskComplexity.HIGH:
            score += length_factor * 0.3
        elif complexity == TaskComplexity.MEDIUM:
            score += length_factor * 0.2
        else:  # LOW
            score += (1 - length_factor) * 0.2
        
        return min(score, 1.0)
    
    def _adjust_scores_by_context(
        self,
        scores: Dict[TaskComplexity, float],
        context: Dict[str, Any]
    ) -> Dict[TaskComplexity, float]:
        """
        Adjust complexity scores based on context
        
        Args:
            scores: Current complexity scores
            context: Context information
            
        Returns:
            Adjusted scores
        """
        adjusted = scores.copy()
        
        # Check for code-related tasks
        if context.get("has_code", False):
            adjusted[TaskComplexity.MEDIUM] *= 1.2
            adjusted[TaskComplexity.HIGH] *= 1.3
        
        # Check for mathematical tasks
        if context.get("has_math", False):
            adjusted[TaskComplexity.HIGH] *= 1.5
        
        # Check for multi-step tasks
        if context.get("multi_step", False):
            adjusted[TaskComplexity.MEDIUM] *= 1.3
            adjusted[TaskComplexity.HIGH] *= 1.4
        
        # Check for error fixing tasks
        if context.get("is_error_fix", False):
            adjusted[TaskComplexity.MEDIUM] *= 1.2
            adjusted[TaskComplexity.HIGH] *= 1.3
        
        # Check for design/architecture tasks
        if context.get("is_design", False):
            adjusted[TaskComplexity.HIGH] *= 1.5
        
        # Normalize scores
        max_score = max(adjusted.values())
        if max_score > 0:
            adjusted = {k: v / max_score for k, v in adjusted.items()}
        
        return adjusted
    
    def estimate_tokens(
        self,
        complexity: TaskComplexity,
        effort: Optional[ReasoningEffort] = None
    ) -> int:
        """
        Estimate required reasoning tokens
        
        Args:
            complexity: Task complexity
            effort: Reasoning effort (if None, uses default for complexity)
            
        Returns:
            Estimated token count
        """
        # Default effort based on complexity
        if effort is None:
            effort_map = {
                TaskComplexity.LOW: ReasoningEffort.LOW,
                TaskComplexity.MEDIUM: ReasoningEffort.MEDIUM,
                TaskComplexity.HIGH: ReasoningEffort.HIGH,
            }
            effort = effort_map[complexity]
        
        # Get token limit for effort
        return self.config.token_limits.get(effort, 5000)
    
    def recommend_effort(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None
    ) -> ReasoningEffort:
        """
        Recommend reasoning effort for task
        
        Args:
            task: Task description
            context: Optional context information
            
        Returns:
            Recommended reasoning effort
        """
        complexity = self.analyze(task, context)
        
        # Map complexity to effort
        effort_map = {
            TaskComplexity.LOW: ReasoningEffort.LOW,
            TaskComplexity.MEDIUM: ReasoningEffort.MEDIUM,
            TaskComplexity.HIGH: ReasoningEffort.HIGH,
        }
        
        return effort_map[complexity]
    
    def detect_task_features(self, task: str) -> Dict[str, bool]:
        """
        Detect various features in task description
        
        Args:
            task: Task description
            
        Returns:
            Dictionary of detected features
        """
        task_lower = task.lower()
        
        return {
            "has_code": any(
                kw in task_lower
                for kw in ["code", "function", "class", "implement", "debug"]
            ),
            "has_math": any(
                kw in task_lower
                for kw in ["calculate", "equation", "formula", "prove", "mathematical"]
            ),
            "multi_step": any(
                kw in task_lower
                for kw in ["first", "then", "next", "finally", "step"]
            ),
            "is_error_fix": any(
                kw in task_lower
                for kw in ["error", "bug", "fix", "debug", "issue"]
            ),
            "is_design": any(
                kw in task_lower
                for kw in ["design", "architect", "structure", "system"]
            ),
            "is_analysis": any(
                kw in task_lower
                for kw in ["analyze", "review", "evaluate", "assess"]
            ),
        }
