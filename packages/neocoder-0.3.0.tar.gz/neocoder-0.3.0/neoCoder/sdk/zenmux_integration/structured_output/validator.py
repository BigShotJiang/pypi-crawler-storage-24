"""
Response validation for structured output
"""

import json
from typing import Type, Dict, Any, Union
from pydantic import BaseModel, ValidationError

from ..utils import get_logger
from ..exceptions import StructuredOutputError


class ResponseValidator:
    """Validates model responses against schemas"""
    
    def __init__(self):
        self.logger = get_logger("zenmux_integration.structured_output")
    
    def validate(self, response: str, schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate JSON response against schema
        
        Args:
            response: JSON response string
            schema: JSON Schema dictionary
            
        Returns:
            Validated response dictionary
            
        Raises:
            StructuredOutputError: If validation fails
        """
        try:
            # Parse JSON
            data = json.loads(response)
            
            # Basic type validation
            self._validate_against_schema(data, schema)
            
            self.logger.debug("Response validated successfully")
            return data
            
        except json.JSONDecodeError as e:
            self.logger.error(f"Invalid JSON response: {e}")
            raise StructuredOutputError(f"Response is not valid JSON: {e}")
        
        except Exception as e:
            self.logger.error(f"Validation error: {e}")
            raise StructuredOutputError(f"Response validation failed: {e}")
    
    def parse_to_model(
        self,
        response: str,
        model_class: Type[BaseModel]
    ) -> BaseModel:
        """
        Parse and validate response to Pydantic model
        
        Args:
            response: JSON response string
            model_class: Pydantic model class
            
        Returns:
            Validated Pydantic model instance
            
        Raises:
            StructuredOutputError: If parsing or validation fails
        """
        try:
            # Parse JSON
            data = json.loads(response)
            
            # Validate with Pydantic
            model_instance = model_class.model_validate(data)
            
            self.logger.debug(f"Response parsed to {model_class.__name__}")
            return model_instance
            
        except json.JSONDecodeError as e:
            self.logger.error(f"Invalid JSON response: {e}")
            raise StructuredOutputError(f"Response is not valid JSON: {e}")
        
        except ValidationError as e:
            self.logger.error(f"Pydantic validation error: {e}")
            raise StructuredOutputError(f"Response validation failed: {e}")
        
        except Exception as e:
            self.logger.error(f"Unexpected error: {e}")
            raise StructuredOutputError(f"Failed to parse response: {e}")
    
    def _validate_against_schema(
        self,
        data: Any,
        schema: Dict[str, Any]
    ) -> None:
        """
        Validate data against JSON Schema
        
        Args:
            data: Data to validate
            schema: JSON Schema
            
        Raises:
            StructuredOutputError: If validation fails
        """
        schema_type = schema.get("type")
        
        # Validate type
        if schema_type == "object":
            if not isinstance(data, dict):
                raise StructuredOutputError(f"Expected object, got {type(data).__name__}")
            
            # Validate required fields
            required = schema.get("required", [])
            for field in required:
                if field not in data:
                    raise StructuredOutputError(f"Missing required field: {field}")
            
            # Validate properties
            properties = schema.get("properties", {})
            for key, value in data.items():
                if key in properties:
                    self._validate_against_schema(value, properties[key])
        
        elif schema_type == "array":
            if not isinstance(data, list):
                raise StructuredOutputError(f"Expected array, got {type(data).__name__}")
            
            # Validate items
            items_schema = schema.get("items")
            if items_schema:
                for item in data:
                    self._validate_against_schema(item, items_schema)
        
        elif schema_type == "string":
            if not isinstance(data, str):
                raise StructuredOutputError(f"Expected string, got {type(data).__name__}")
        
        elif schema_type == "integer":
            if not isinstance(data, int) or isinstance(data, bool):
                raise StructuredOutputError(f"Expected integer, got {type(data).__name__}")
        
        elif schema_type == "number":
            if not isinstance(data, (int, float)) or isinstance(data, bool):
                raise StructuredOutputError(f"Expected number, got {type(data).__name__}")
        
        elif schema_type == "boolean":
            if not isinstance(data, bool):
                raise StructuredOutputError(f"Expected boolean, got {type(data).__name__}")
        
        elif schema_type == "null":
            if data is not None:
                raise StructuredOutputError(f"Expected null, got {type(data).__name__}")
