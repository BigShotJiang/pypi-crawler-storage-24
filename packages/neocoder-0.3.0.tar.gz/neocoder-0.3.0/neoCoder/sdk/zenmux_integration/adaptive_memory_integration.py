"""
Adaptive Memory Integration with Zenmux features

Extends AdaptiveMemoryManager with:
- Streaming support for memory updates
- Structured output for memory entries
"""

from typing import Dict, Any, Optional, List, Tuple, AsyncIterator
from datetime import datetime

from neoCoder.sdk.adaptive_memory import (
    AdaptiveMemoryManager,
    AdaptiveMemoryConfig,
    AdaptiveMemoryResult,
    WorkingMemoryConfig,
)
from neoCoder.sdk.zenmux_integration.streaming import StreamChunk
from neoCoder.sdk.zenmux_integration.utils import get_logger


class MemoryEntry:
    """Single memory entry with metadata"""
    
    def __init__(
        self,
        content: str,
        role: str = "assistant",
        timestamp: Optional[datetime] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize memory entry
        
        Args:
            content: Entry content
            role: Message role (user/assistant/system)
            timestamp: Entry timestamp
            metadata: Optional metadata
        """
        self.content = content
        self.role = role
        self.timestamp = timestamp or datetime.now()
        self.metadata = metadata or {}
    
    def to_message(self) -> Dict[str, str]:
        """Convert to message format"""
        return {
            "role": self.role,
            "content": self.content
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "content": self.content,
            "role": self.role,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
        }


class CachedMemoryManager(AdaptiveMemoryManager):
    """
    Adaptive Memory Manager with Zenmux features
    
    Features:
    - Streaming support for memory updates
    - Structured output for memory entries
    """
    
    def __init__(
        self,
        config: Optional[AdaptiveMemoryConfig] = None,
        enable_caching: bool = True,
        enable_streaming: bool = True,
    ):
        """
        Initialize cached memory manager
        
        Args:
            config: Adaptive memory configuration
            enable_caching: Kept for backwards compatibility (unused)
            enable_streaming: Enable streaming support
        """
        super().__init__(config)
        
        self.logger = get_logger("cached_memory_manager")
        
        # Initialize streaming
        self.enable_streaming = enable_streaming
        
        # Memory storage
        self.memory_entries: List[MemoryEntry] = []
        self.context_cache: Dict[str, List[Dict[str, str]]] = {}
        
        self.logger.info(
            f"CachedMemoryManager initialized: "
            f"streaming={enable_streaming}"
        )
    
    def add_entry(
        self,
        content: str,
        role: str = "assistant",
        metadata: Optional[Dict[str, Any]] = None
    ) -> MemoryEntry:
        """
        Add memory entry
        
        Args:
            content: Entry content
            role: Message role
            metadata: Optional metadata
            
        Returns:
            Created memory entry
        """
        entry = MemoryEntry(
            content=content,
            role=role,
            metadata=metadata
        )
        self.memory_entries.append(entry)
        
        # Invalidate context cache
        self.context_cache.clear()
        
        self.logger.debug(f"Added memory entry: role={role}, length={len(content)}")
        return entry
    
    async def add_entry_streaming(
        self,
        chunks: AsyncIterator[StreamChunk],
        role: str = "assistant",
        metadata: Optional[Dict[str, Any]] = None
    ) -> MemoryEntry:
        """
        Add memory entry from streaming chunks
        
        Args:
            chunks: Async iterator of stream chunks
            role: Message role
            metadata: Optional metadata
            
        Returns:
            Created memory entry with aggregated content
        """
        if not self.enable_streaming:
            raise ValueError("Streaming is not enabled")
        
        # Aggregate chunks
        content_parts = []
        async for chunk in chunks:
            if chunk.content:
                content_parts.append(chunk.content)
        
        # Create entry
        content = "".join(content_parts)
        return self.add_entry(content, role, metadata)
    
    def get_context_messages(
        self,
        query: str,
        max_entries: Optional[int] = None,
        include_system: bool = True
    ) -> List[Dict[str, str]]:
        """
        Get context as message list
        
        Args:
            query: Query for context retrieval
            max_entries: Maximum number of entries to include
            include_system: Include system message
            
        Returns:
            List of messages
        """
        messages = []
        
        # Add system message if requested
        if include_system:
            # Get memory config for this query
            memory_result = self.get_memory_config(query)
            
            system_content = (
                f"You are an AI assistant with adaptive memory. "
                f"Current task type: {memory_result.task_type}, "
                f"complexity: {memory_result.complexity:.2f}. "
                f"Memory config: compression_threshold={memory_result.config.compression_threshold:.2f}, "
                f"rolling_window={memory_result.config.rolling_window_size}"
            )
            
            messages.append({
                "role": "system",
                "content": system_content
            })
        
        # Add memory entries
        entries_to_include = self.memory_entries
        if max_entries:
            entries_to_include = entries_to_include[-max_entries:]
        
        for entry in entries_to_include:
            messages.append(entry.to_message())
        
        return messages
    
    def get_context_with_caching(
        self,
        query: str,
        max_entries: Optional[int] = None,
        include_system: bool = True,
        **kwargs,
    ) -> Tuple[List[Dict[str, str]], None]:
        """
        Get context messages.
        
        Args:
            query: Query for context retrieval
            max_entries: Maximum number of entries
            include_system: Include system message
            
        Returns:
            Tuple of (messages, None)
        """
        # Check local cache
        cache_key = f"{query}:{max_entries}:{include_system}"
        if cache_key in self.context_cache:
            self.logger.debug(f"Context cache hit: {cache_key}")
            return self.context_cache[cache_key], None
        
        # Get messages
        messages = self.get_context_messages(
            query=query,
            max_entries=max_entries,
            include_system=include_system
        )
        
        self.context_cache[cache_key] = messages
        return messages, None
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """
        Get memory statistics
        
        Returns:
            Dictionary with statistics
        """
        stats = {
            "total_entries": len(self.memory_entries),
            "streaming_enabled": self.enable_streaming,
            "context_cache_size": len(self.context_cache),
        }
        
        # Add entry statistics
        if self.memory_entries:
            total_content_length = sum(len(e.content) for e in self.memory_entries)
            stats["total_content_length"] = total_content_length
            stats["avg_content_length"] = total_content_length / len(self.memory_entries)
            
            # Count by role
            role_counts = {}
            for entry in self.memory_entries:
                role_counts[entry.role] = role_counts.get(entry.role, 0) + 1
            stats["entries_by_role"] = role_counts
        
        return stats
    
    def clear_memory(self):
        """Clear all memory entries and caches"""
        self.memory_entries.clear()
        self.context_cache.clear()
        self.logger.info("Memory cleared")
    
    def export_memory(self) -> Dict[str, Any]:
        """
        Export memory for persistence
        
        Returns:
            Dictionary with all memory data
        """
        return {
            "entries": [entry.to_dict() for entry in self.memory_entries],
            "config": {
                "enable_caching": self.enable_caching,
                "enable_streaming": self.enable_streaming,
            },
            "stats": self.get_memory_stats(),
            "exported_at": datetime.now().isoformat(),
        }
    
    def import_memory(self, data: Dict[str, Any]):
        """
        Import memory from persistence
        
        Args:
            data: Memory data dictionary
        """
        # Clear existing memory
        self.clear_memory()
        
        # Import entries
        if "entries" in data:
            for entry_data in data["entries"]:
                entry = MemoryEntry(
                    content=entry_data["content"],
                    role=entry_data["role"],
                    timestamp=datetime.fromisoformat(entry_data["timestamp"]),
                    metadata=entry_data.get("metadata", {})
                )
                self.memory_entries.append(entry)
        
        self.logger.info(f"Imported {len(self.memory_entries)} memory entries")
