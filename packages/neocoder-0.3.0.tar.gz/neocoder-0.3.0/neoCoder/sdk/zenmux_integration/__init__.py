"""
Zenmux Advanced Features Integration

This module provides integration with Zenmux advanced features:
- Streaming responses
- Structured output
- Enhanced tool calling
- Reasoning control
- Prompt caching
- Adaptive memory integration
"""

from .config import ZenmuxConfig
from .client import ZenmuxClient
from .exceptions import (
    ZenmuxError,
    StreamingError,
    StructuredOutputError,
    ToolExecutionError,
    ReasoningError,
    AuthenticationError,
    RateLimitError,
)

# Streaming components
from .streaming import (
    StreamingManager,
    StreamHandler,
    DefaultStreamHandler,
    PrintStreamHandler,
    BufferedStreamHandler,
    ChunkAggregator,
    StreamChunk,
    StreamMetrics,
    ToolCallChunk,
)

# Structured output components
from .structured_output import (
    StructuredOutputManager,
    SchemaGenerator,
    ResponseValidator,
)

# Tool calling components
from .tool_calling import (
    ToolRegistry,
    ToolExecutor,
    ToolCallFormatter,
    EnhancedToolManager,
    Tool,
    ToolCall,
    ToolResult,
    ToolExecution,
    ToolExecutionStatus,
)

# Reasoning components
from .reasoning import (
    ReasoningController,
    AdaptiveReasoningManager,
    TaskComplexityAnalyzer,
    ReasoningTraceExtractor,
    ReasoningTrace,
    ReasoningPerformance,
    TaskComplexity,
    ReasoningEffort,
)

# Prompt Caching
from .caching import (
    PromptCacheManager,
    CacheStrategy,
    ExplicitCacheStrategy,
    ImplicitCacheStrategy,
    CacheBreakpointPlacer,
)

# Token Estimation
from .token_estimator import (
    TokenEstimator,
    TokenUsage,
    estimate_tokens,
    get_token_estimator,
)

# Adaptive memory integration
from .adaptive_memory_integration import (
    CachedMemoryManager,
    MemoryEntry,
)



# Code cache integration
from .code_cache_integration import (
    EnhancedCodeCacheSystem,
    CodeAnalysisOutput,
    FunctionAnalysis,
    ClassAnalysis,
    DependencyAnalysis,
    CodeInsightOutput,
    AnalysisComplexity,
)

__version__ = "0.1.0"

__all__ = [
    # Core
    "ZenmuxConfig",
    "ZenmuxClient",
    
    # Exceptions
    "ZenmuxError",
    "StreamingError",
    "StructuredOutputError",
    "ToolExecutionError",
    "ReasoningError",
    "AuthenticationError",
    "RateLimitError",
    
    # Streaming
    "StreamingManager",
    "StreamHandler",
    "DefaultStreamHandler",
    "PrintStreamHandler",
    "BufferedStreamHandler",
    "ChunkAggregator",
    "StreamChunk",
    "StreamMetrics",
    "ToolCallChunk",
    
    # Structured Output
    "StructuredOutputManager",
    "SchemaGenerator",
    "ResponseValidator",
    
    # Tool Calling
    "ToolRegistry",
    "ToolExecutor",
    "ToolCallFormatter",
    "EnhancedToolManager",
    "Tool",
    "ToolCall",
    "ToolResult",
    "ToolExecution",
    "ToolExecutionStatus",
    
    # Reasoning
    "ReasoningController",
    "AdaptiveReasoningManager",
    "TaskComplexityAnalyzer",
    "ReasoningTraceExtractor",
    "ReasoningTrace",
    "ReasoningPerformance",
    "TaskComplexity",
    "ReasoningEffort",
    
    # Prompt Caching
    "PromptCacheManager",
    "CacheStrategy",
    "ExplicitCacheStrategy",
    "ImplicitCacheStrategy",
    "CacheBreakpointPlacer",
    
    # Token Estimation
    "TokenEstimator",
    "TokenUsage",
    "estimate_tokens",
    "get_token_estimator",
    
    # Adaptive Memory Integration
    "CachedMemoryManager",
    "MemoryEntry",
    
    # Code Cache Integration
    "EnhancedCodeCacheSystem",
    "CodeAnalysisOutput",
    "FunctionAnalysis",
    "ClassAnalysis",
    "DependencyAnalysis",
    "CodeInsightOutput",
    "AnalysisComplexity",
]
