"""
Code Cache Integration with Zenmux features

Extends CodeUnderstandingCache with:
- Structured output for code analysis
- Caching for code analysis results
- Streaming for large code analysis
- Reasoning for complex code understanding
"""

from typing import Dict, Any, Optional, List, Tuple, AsyncIterator
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from neoCoder.sdk.code_cache import (
    CodeUnderstandingCache,
    CacheConfig,
    CachedFileAnalysis,
    FileMetadata,
    FunctionInfo,
    ClassInfo,
)
from neoCoder.sdk.zenmux_integration.structured_output import (
    StructuredOutputManager,
)
from neoCoder.sdk.zenmux_integration.reasoning import (
    ReasoningController,
    TaskComplexity,
)
from neoCoder.sdk.zenmux_integration.streaming import (
    StreamingManager,
    StreamChunk,
)
from neoCoder.sdk.zenmux_integration.utils import get_logger

from pydantic import BaseModel, Field


# Structured Output Models

class FunctionAnalysis(BaseModel):
    """Structured function analysis"""
    name: str = Field(description="Function name")
    line_start: int = Field(description="Starting line number")
    line_end: int = Field(description="Ending line number")
    args: List[str] = Field(description="Function arguments")
    returns: Optional[str] = Field(None, description="Return type")
    docstring: Optional[str] = Field(None, description="Function docstring")
    complexity: int = Field(description="Cyclomatic complexity")
    purpose: Optional[str] = Field(None, description="Function purpose (AI-generated)")
    usage_examples: List[str] = Field(default_factory=list, description="Usage examples")


class ClassAnalysis(BaseModel):
    """Structured class analysis"""
    name: str = Field(description="Class name")
    line_start: int = Field(description="Starting line number")
    line_end: int = Field(description="Ending line number")
    methods: List[FunctionAnalysis] = Field(description="Class methods")
    bases: List[str] = Field(description="Base classes")
    docstring: Optional[str] = Field(None, description="Class docstring")
    purpose: Optional[str] = Field(None, description="Class purpose (AI-generated)")
    design_patterns: List[str] = Field(default_factory=list, description="Detected design patterns")


class CodeAnalysisOutput(BaseModel):
    """Structured output for code analysis"""
    file_path: str = Field(description="Path to analyzed file")
    language: str = Field(description="Programming language")
    loc: int = Field(description="Lines of code")
    complexity: float = Field(description="Overall complexity score")
    functions: List[FunctionAnalysis] = Field(description="Analyzed functions")
    classes: List[ClassAnalysis] = Field(description="Analyzed classes")
    imports: List[str] = Field(description="Import statements")
    summary: str = Field(description="High-level summary")
    architecture_notes: Optional[str] = Field(None, description="Architecture observations")
    quality_score: float = Field(description="Code quality score 0.0-1.0")
    recommendations: List[str] = Field(default_factory=list, description="Improvement recommendations")


class DependencyAnalysis(BaseModel):
    """Structured dependency analysis"""
    file_path: str = Field(description="Analyzed file")
    direct_imports: List[str] = Field(description="Direct imports")
    indirect_dependencies: List[str] = Field(default_factory=list, description="Indirect dependencies")
    circular_dependencies: List[str] = Field(default_factory=list, description="Circular dependencies")
    unused_imports: List[str] = Field(default_factory=list, description="Unused imports")
    dependency_graph: Dict[str, List[str]] = Field(default_factory=dict, description="Dependency graph")


class CodeInsightOutput(BaseModel):
    """Structured output for deep code insights (with reasoning)"""
    file_path: str = Field(description="Analyzed file")
    key_insights: List[str] = Field(description="Key insights about the code")
    reasoning_steps: List[str] = Field(description="Reasoning steps taken")
    architectural_patterns: List[str] = Field(default_factory=list, description="Detected patterns")
    potential_issues: List[str] = Field(default_factory=list, description="Potential issues")
    refactoring_opportunities: List[str] = Field(default_factory=list, description="Refactoring suggestions")
    complexity_hotspots: List[Dict[str, Any]] = Field(default_factory=list, description="Complex code sections")
    confidence: float = Field(description="Confidence in analysis 0.0-1.0")


# Analysis Complexity

class AnalysisComplexity(Enum):
    """Code analysis complexity levels"""
    SIMPLE = "simple"      # Basic structure parsing
    MODERATE = "moderate"  # Structure + metrics
    COMPLEX = "complex"    # Deep analysis with reasoning


# Enhanced Code Cache System

class EnhancedCodeCacheSystem:
    """
    Enhanced code cache system with Zenmux features
    
    Features:
    - Structured output for code analysis
    - Caching for analysis results
    - Streaming for large file analysis
    - Reasoning for complex code understanding
    """
    
    def __init__(
        self,
        cache_config: Optional[CacheConfig] = None,
        enable_structured_output: bool = True,
        enable_caching: bool = True,
        enable_streaming: bool = True,
        enable_reasoning: bool = True,
    ):
        """
        Initialize enhanced code cache system
        
        Args:
            cache_config: Code cache configuration
            enable_structured_output: Enable structured output
            enable_caching: Enable local analysis caching
            enable_streaming: Enable streaming analysis
            enable_reasoning: Enable reasoning for complex analysis
        """
        # Base cache system
        self.cache = CodeUnderstandingCache(cache_config or CacheConfig())
        
        # Zenmux features
        self.structured_manager = StructuredOutputManager() if enable_structured_output else None
        self.streaming_manager = None  # Will be initialized when needed
        self.reasoning_controller = ReasoningController() if enable_reasoning else None
        
        # Feature flags
        self.enable_structured_output = enable_structured_output
        self.enable_caching = enable_caching
        self.enable_streaming = enable_streaming
        self.enable_reasoning = enable_reasoning
        
        # Logger
        self.logger = get_logger(__name__)
        
        # Analysis cache
        self._analysis_cache: Dict[str, CodeAnalysisOutput] = {}
    
    def analyze_structured(
        self,
        file_path: str,
        include_ai_insights: bool = False,
    ) -> CodeAnalysisOutput:
        """
        Analyze code file with structured output
        
        Args:
            file_path: Path to file to analyze
            include_ai_insights: Include AI-generated insights
            
        Returns:
            Structured code analysis output
        """
        self.logger.info(f"Analyzing file with structured output: {file_path}")
        
        # Get base analysis from cache
        base_analysis = self.cache.analyze_file(file_path)
        
        # Convert to structured output
        structured_output = self._convert_to_structured(
            base_analysis,
            include_ai_insights=include_ai_insights,
        )
        
        return structured_output
    
    def analyze_with_caching(
        self,
        file_path: str,
        force_refresh: bool = False,
    ) -> CodeAnalysisOutput:
        """
        Analyze code with local caching
        
        Args:
            file_path: Path to file to analyze
            force_refresh: Force cache refresh even if valid
            
        Returns:
            Code analysis output
        """
        if not self.enable_caching:
            return self.analyze_structured(file_path)
        
        self.logger.info(f"Analyzing with caching: {file_path}")
        
        # Generate cache key based on file content hash
        cache_key = self._generate_cache_key(file_path)
        
        # Check if already in analysis cache and not forced refresh
        if not force_refresh and cache_key in self._analysis_cache:
            cached_entry = self._analysis_cache[cache_key]
            
            # Validate cache entry is still valid
            if self._is_cache_valid(file_path, cached_entry):
                self.logger.info(f"Cache hit for analysis: {file_path}")
                return cached_entry
            else:
                # Cache invalid, remove entry
                self.logger.info(f"Cache invalid for: {file_path}, removing")
                del self._analysis_cache[cache_key]
        
        # Cache miss - perform analysis
        self.logger.info(f"Cache miss for analysis: {file_path}")
        analysis = self.analyze_structured(file_path)
        
        # Store in cache
        self._analysis_cache[cache_key] = analysis
        
        return analysis
    
    async def analyze_streaming(
        self,
        file_path: str,
    ) -> AsyncIterator[str]:
        """
        Analyze code with streaming output
        
        Args:
            file_path: Path to file to analyze
            
        Yields:
            Analysis chunks as they are generated
        """
        if not self.enable_streaming:
            # Fallback to non-streaming
            analysis = self.analyze_structured(file_path)
            yield analysis.model_dump_json(indent=2)
            return
        
        self.logger.info(f"Analyzing with streaming: {file_path}")
        
        # Get base analysis
        base_analysis = self.cache.analyze_file(file_path)
        
        # Stream analysis results
        yield f"Analyzing file: {file_path}\n"
        yield f"Language: {base_analysis.metadata.language}\n"
        yield f"Lines of code: {base_analysis.loc}\n\n"
        
        if base_analysis.functions:
            yield f"Functions ({len(base_analysis.functions)}):\n"
            for func in base_analysis.functions:
                yield f"  - {func.name} (complexity: {func.complexity})\n"
            yield "\n"
        
        if base_analysis.classes:
            yield f"Classes ({len(base_analysis.classes)}):\n"
            for cls in base_analysis.classes:
                yield f"  - {cls.name} ({len(cls.methods)} methods)\n"
            yield "\n"
        
        if base_analysis.imports:
            yield f"Imports ({len(base_analysis.imports)}):\n"
            for imp in base_analysis.imports[:5]:  # Show first 5
                yield f"  - {imp}\n"
            if len(base_analysis.imports) > 5:
                yield f"  ... and {len(base_analysis.imports) - 5} more\n"
            yield "\n"
        
        yield f"Summary: {base_analysis.summary}\n"
        yield f"Overall complexity: {base_analysis.complexity}\n"
    
    def analyze_with_reasoning(
        self,
        file_path: str,
        complexity: Optional[AnalysisComplexity] = None,
    ) -> CodeInsightOutput:
        """
        Analyze code with reasoning for deep insights
        
        Args:
            file_path: Path to file to analyze
            complexity: Analysis complexity level (auto-detected if None)
            
        Returns:
            Deep code insights with reasoning
        """
        if not self.enable_reasoning or self.reasoning_controller is None:
            raise ValueError("Reasoning is not enabled")
        
        self.logger.info(f"Analyzing with reasoning: {file_path}")
        
        # Get base analysis
        base_analysis = self.cache.analyze_file(file_path)
        
        # Determine complexity if not provided
        if complexity is None:
            complexity = self._assess_analysis_complexity(base_analysis)
        
        self.logger.info(f"Analysis complexity: {complexity.value}")
        
        # Generate deep insights (simulated for now)
        insights = self._generate_deep_insights(base_analysis, complexity)
        
        return insights
    
    def analyze_dependencies(
        self,
        file_path: str,
        recursive: bool = False,
    ) -> DependencyAnalysis:
        """
        Analyze file dependencies
        
        Args:
            file_path: Path to file to analyze
            recursive: Recursively analyze dependencies
            
        Returns:
            Dependency analysis
        """
        self.logger.info(f"Analyzing dependencies: {file_path}")
        
        # Get base analysis
        base_analysis = self.cache.analyze_file(file_path)
        
        # Build dependency analysis
        dependency_analysis = DependencyAnalysis(
            file_path=file_path,
            direct_imports=base_analysis.imports,
            indirect_dependencies=[],
            circular_dependencies=[],
            unused_imports=[],
            dependency_graph={file_path: base_analysis.imports},
        )
        
        # Recursive analysis if requested
        if recursive:
            self._analyze_dependencies_recursive(
                file_path,
                base_analysis.imports,
                dependency_analysis,
                visited=set(),
            )
        
        return dependency_analysis
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics
        
        Returns:
            Dictionary with cache statistics
        """
        base_stats = self.cache.get_stats()
        
        return {
            "base_cache": base_stats,
            "analysis_cache_size": len(self._analysis_cache),
        }
    
    def clear_analysis_cache(self):
        """Clear the analysis cache"""
        self._analysis_cache.clear()
        self.logger.info("Analysis cache cleared")
    
    def invalidate_cache_entry(self, file_path: str):
        """
        Invalidate cache entry for a specific file
        
        Args:
            file_path: Path to file to invalidate
        """
        # Remove all cache entries for this file (all strategies)
        keys_to_remove = [
            key for key in self._analysis_cache.keys()
            if key.startswith(f"{file_path}:")
        ]
        
        for key in keys_to_remove:
            del self._analysis_cache[key]
            self.logger.info(f"Invalidated cache entry: {key}")
    
    # Private helper methods
    
    def _generate_cache_key(self, file_path: str) -> str:
        """
        Generate cache key based on file content hash
        
        Args:
            file_path: Path to file
            
        Returns:
            Cache key string
        """
        try:
            # Read file content
            content = Path(file_path).read_text(encoding="utf-8")
            
            # Generate content hash
            import hashlib
            content_hash = hashlib.md5(content.encode()).hexdigest()[:8]
            
            return f"{file_path}:{content_hash}"
        except Exception as e:
            self.logger.warning(f"Failed to generate cache key for {file_path}: {e}")
            return file_path
    
    def _is_cache_valid(self, file_path: str, cached_analysis: CodeAnalysisOutput) -> bool:
        """
        Check if cached analysis is still valid
        
        Args:
            file_path: Path to file
            cached_analysis: Cached analysis result
            
        Returns:
            True if cache is valid, False otherwise
        """
        try:
            # Check if file still exists
            if not Path(file_path).exists():
                return False
            
            # Check file modification time
            current_mtime = Path(file_path).stat().st_mtime
            
            # Get cached file metadata from base cache
            base_analysis = self.cache.get_analysis(file_path)
            if base_analysis is None:
                # Base cache miss, consider invalid
                return False
            
            # Compare modification times
            if base_analysis.metadata.mtime != current_mtime:
                return False
            
            # Check content hash
            content = Path(file_path).read_text(encoding="utf-8")
            import hashlib
            current_hash = hashlib.md5(content.encode()).hexdigest()
            
            if base_analysis.metadata.content_hash != current_hash:
                return False
            
            return True
        except Exception as e:
            self.logger.warning(f"Cache validation failed for {file_path}: {e}")
            return False
    
    def _estimate_tokens_saved(self, analysis: CodeAnalysisOutput) -> int:
        """
        Estimate tokens saved by cache hit
        
        Args:
            analysis: Cached analysis result
            
        Returns:
            Estimated tokens saved
        """
        # Estimate based on:
        # - File size (LOC)
        # - Number of functions/classes
        # - Complexity
        
        base_tokens = analysis.loc * 2  # ~2 tokens per line
        function_tokens = len(analysis.functions) * 50  # ~50 tokens per function
        class_tokens = len(analysis.classes) * 100  # ~100 tokens per class
        complexity_tokens = int(analysis.complexity * 10)  # Complexity factor
        
        total_tokens = base_tokens + function_tokens + class_tokens + complexity_tokens
        
        # Cache saves significant tokens on repeated analysis
        tokens_saved = int(total_tokens * 0.9)
        
        return max(100, tokens_saved)  # Minimum 100 tokens saved
    
    def _convert_to_structured(
        self,
        base_analysis: CachedFileAnalysis,
        include_ai_insights: bool = False,
    ) -> CodeAnalysisOutput:
        """Convert base analysis to structured output"""
        # Convert functions
        functions = [
            FunctionAnalysis(
                name=func.name,
                line_start=func.line_start,
                line_end=func.line_end,
                args=func.args,
                returns=func.returns,
                docstring=func.docstring,
                complexity=func.complexity,
                purpose=None,  # Would be AI-generated
                usage_examples=[],
            )
            for func in base_analysis.functions
        ]
        
        # Convert classes
        classes = [
            ClassAnalysis(
                name=cls.name,
                line_start=cls.line_start,
                line_end=cls.line_end,
                methods=[
                    FunctionAnalysis(
                        name=method.name,
                        line_start=method.line_start,
                        line_end=method.line_end,
                        args=method.args,
                        returns=method.returns,
                        docstring=method.docstring,
                        complexity=method.complexity,
                        purpose=None,
                        usage_examples=[],
                    )
                    for method in cls.methods
                ],
                bases=cls.bases,
                docstring=cls.docstring,
                purpose=None,  # Would be AI-generated
                design_patterns=[],
            )
            for cls in base_analysis.classes
        ]
        
        # Calculate quality score
        quality_score = self._calculate_quality_score(base_analysis)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(base_analysis)
        
        return CodeAnalysisOutput(
            file_path=base_analysis.metadata.file_path,
            language=base_analysis.metadata.language,
            loc=base_analysis.loc,
            complexity=base_analysis.complexity,
            functions=functions,
            classes=classes,
            imports=base_analysis.imports,
            summary=base_analysis.summary,
            architecture_notes=None,  # Would be AI-generated
            quality_score=quality_score,
            recommendations=recommendations,
        )
    
    def _assess_analysis_complexity(
        self,
        analysis: CachedFileAnalysis,
    ) -> AnalysisComplexity:
        """Assess analysis complexity based on code metrics"""
        # Simple heuristics
        if analysis.loc > 500 or analysis.complexity > 20:
            return AnalysisComplexity.COMPLEX
        elif analysis.loc > 200 or analysis.complexity > 10:
            return AnalysisComplexity.MODERATE
        else:
            return AnalysisComplexity.SIMPLE
    
    def _generate_deep_insights(
        self,
        analysis: CachedFileAnalysis,
        complexity: AnalysisComplexity,
    ) -> CodeInsightOutput:
        """Generate deep insights with reasoning (simulated)"""
        # This would use actual AI reasoning in production
        insights = []
        reasoning_steps = []
        
        # Analyze complexity
        if analysis.complexity > 15:
            insights.append(f"High complexity detected ({analysis.complexity})")
            reasoning_steps.append("Analyzed cyclomatic complexity metrics")
        
        # Analyze structure
        if len(analysis.functions) > 20:
            insights.append(f"Large number of functions ({len(analysis.functions)})")
            reasoning_steps.append("Counted function definitions")
        
        # Detect patterns
        patterns = []
        if any("Factory" in cls.name for cls in analysis.classes):
            patterns.append("Factory Pattern")
        if any("Singleton" in cls.name for cls in analysis.classes):
            patterns.append("Singleton Pattern")
        
        # Find complexity hotspots
        hotspots = [
            {
                "name": func.name,
                "complexity": func.complexity,
                "line": func.line_start,
            }
            for func in analysis.functions
            if func.complexity > 10
        ]
        
        return CodeInsightOutput(
            file_path=analysis.metadata.file_path,
            key_insights=insights,
            reasoning_steps=reasoning_steps,
            architectural_patterns=patterns,
            potential_issues=[],
            refactoring_opportunities=[],
            complexity_hotspots=hotspots,
            confidence=0.85,
        )
    
    def _calculate_quality_score(
        self,
        analysis: CachedFileAnalysis,
    ) -> float:
        """Calculate code quality score"""
        score = 1.0
        
        # Penalize high complexity
        if analysis.complexity > 20:
            score -= 0.3
        elif analysis.complexity > 10:
            score -= 0.1
        
        # Penalize missing docstrings
        functions_with_docs = sum(
            1 for func in analysis.functions if func.docstring
        )
        if analysis.functions:
            doc_ratio = functions_with_docs / len(analysis.functions)
            score -= (1 - doc_ratio) * 0.2
        
        # Penalize very long files
        if analysis.loc > 1000:
            score -= 0.2
        elif analysis.loc > 500:
            score -= 0.1
        
        return max(0.0, min(1.0, score))
    
    def _generate_recommendations(
        self,
        analysis: CachedFileAnalysis,
    ) -> List[str]:
        """Generate improvement recommendations"""
        recommendations = []
        
        # Complexity recommendations
        if analysis.complexity > 15:
            recommendations.append(
                "Consider refactoring to reduce complexity"
            )
        
        # Documentation recommendations
        functions_without_docs = [
            func for func in analysis.functions if not func.docstring
        ]
        if functions_without_docs:
            recommendations.append(
                f"Add docstrings to {len(functions_without_docs)} functions"
            )
        
        # Size recommendations
        if analysis.loc > 500:
            recommendations.append(
                "Consider splitting into smaller modules"
            )
        
        return recommendations
    
    def _analyze_dependencies_recursive(
        self,
        file_path: str,
        imports: List[str],
        result: DependencyAnalysis,
        visited: set,
        depth: int = 0,
        max_depth: int = 3,
    ):
        """Recursively analyze dependencies"""
        if depth >= max_depth:
            return
        
        visited.add(file_path)
        
        for imp in imports:
            if imp in visited:
                # Circular dependency detected
                if imp not in result.circular_dependencies:
                    result.circular_dependencies.append(imp)
                continue
            
            # Try to resolve import to file path
            # This is simplified - would need proper import resolution
            resolved_path = self._resolve_import(imp, file_path)
            if resolved_path and Path(resolved_path).exists():
                try:
                    dep_analysis = self.cache.analyze_file(resolved_path)
                    result.indirect_dependencies.append(resolved_path)
                    result.dependency_graph[resolved_path] = dep_analysis.imports
                    
                    # Recurse
                    self._analyze_dependencies_recursive(
                        resolved_path,
                        dep_analysis.imports,
                        result,
                        visited,
                        depth + 1,
                        max_depth,
                    )
                except Exception as e:
                    self.logger.warning(f"Failed to analyze dependency {resolved_path}: {e}")
    
    def _resolve_import(self, import_name: str, from_file: str) -> Optional[str]:
        """Resolve import to file path (simplified)"""
        # This is a simplified version
        # Real implementation would need proper Python import resolution
        
        # Handle relative imports
        if import_name.startswith("."):
            base_dir = Path(from_file).parent
            parts = import_name.split(".")
            # Navigate up directories for each leading dot
            for part in parts:
                if part == "":
                    base_dir = base_dir.parent
                else:
                    break
            # Construct path
            module_parts = [p for p in parts if p]
            if module_parts:
                return str(base_dir / "/".join(module_parts).replace(".", "/") + ".py")
        
        # Handle absolute imports (simplified)
        # Would need to check sys.path, site-packages, etc.
        return None


# Export all models and main class
__all__ = [
    "EnhancedCodeCacheSystem",
    "CodeAnalysisOutput",
    "FunctionAnalysis",
    "ClassAnalysis",
    "DependencyAnalysis",
    "CodeInsightOutput",
    "AnalysisComplexity",
]
