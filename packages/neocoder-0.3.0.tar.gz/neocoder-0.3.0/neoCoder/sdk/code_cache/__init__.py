"""
Code Understanding Cache for neoCoder SDK.

Caches file analysis results to avoid repeated reads and analysis:
- File content and metadata
- AST parsing results
- Code structure (functions, classes, imports)
- Complexity metrics
"""

from neoCoder.sdk.code_cache.models import (
    CachedFileAnalysis,
    FileMetadata,
    FunctionInfo,
    ClassInfo,
)
from neoCoder.sdk.code_cache.config import CacheConfig
from neoCoder.sdk.code_cache.store import CacheStore
from neoCoder.sdk.code_cache.invalidator import CacheInvalidator
from neoCoder.sdk.code_cache.parser import CodeParser
from neoCoder.sdk.code_cache.analyzer import CodeAnalyzer
from neoCoder.sdk.code_cache.cache import CodeUnderstandingCache
from neoCoder.sdk.code_cache.extension import CodeCacheExtension

__all__ = [
    # Models
    "CachedFileAnalysis",
    "FileMetadata",
    "FunctionInfo",
    "ClassInfo",
    # Config
    "CacheConfig",
    # Components
    "CacheStore",
    "CacheInvalidator",
    "CodeParser",
    "CodeAnalyzer",
    "CodeUnderstandingCache",
    "CodeCacheExtension",
]
