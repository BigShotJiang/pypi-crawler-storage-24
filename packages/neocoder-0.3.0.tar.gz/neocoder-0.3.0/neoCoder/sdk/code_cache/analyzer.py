"""
Code analyzer - analyzes code structure and metrics.
"""

from __future__ import annotations

import ast
from typing import Any

from neoCoder.sdk.code_cache.models import FunctionInfo, ClassInfo


class CodeAnalyzer:
    """Analyzes code structure and calculates metrics."""
    
    def __init__(self):
        """Initialize analyzer."""
        pass
    
    def analyze(
        self,
        code: str,
        functions: list[FunctionInfo],
        classes: list[ClassInfo],
        imports: list[str],
    ) -> dict[str, Any]:
        """
        Analyze code and calculate metrics.
        
        Args:
            code: Source code
            functions: Parsed functions
            classes: Parsed classes
            imports: Parsed imports
            
        Returns:
            Dictionary with:
                - summary: Brief description of the code
                - complexity: Overall complexity score
                - loc: Lines of code (excluding comments/blanks)
        """
        # Calculate lines of code
        loc = self._count_loc(code)
        
        # Calculate complexity
        complexity = self._calculate_complexity(code, functions, classes)
        
        # Generate summary
        summary = self._generate_summary(functions, classes, imports, loc)
        
        # Update function complexities
        self._update_function_complexities(code, functions)
        
        return {
            "summary": summary,
            "complexity": complexity,
            "loc": loc,
        }
    
    def _count_loc(self, code: str) -> int:
        """Count lines of code (excluding comments and blank lines)."""
        lines = code.split("\n")
        loc = 0
        
        for line in lines:
            stripped = line.strip()
            # Skip empty lines and comments
            if stripped and not stripped.startswith("#"):
                loc += 1
        
        return loc
    
    def _calculate_complexity(
        self,
        code: str,
        functions: list[FunctionInfo],
        classes: list[ClassInfo],
    ) -> float:
        """
        Calculate overall code complexity.
        
        Uses a simplified cyclomatic complexity approach:
        - Count decision points (if, for, while, etc.)
        - Normalize by lines of code
        """
        try:
            tree = ast.parse(code)
        except SyntaxError:
            return 0.0
        
        decision_points = 0
        
        for node in ast.walk(tree):
            # Count decision points
            if isinstance(node, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                decision_points += 1
            elif isinstance(node, ast.BoolOp):
                # Count and/or operators
                decision_points += len(node.values) - 1
        
        # Normalize by LOC (avoid division by zero)
        loc = self._count_loc(code)
        if loc == 0:
            return 0.0
        
        # Complexity score: decision points per 10 lines of code
        complexity = (decision_points / loc) * 10
        
        return round(complexity, 2)
    
    def _update_function_complexities(
        self,
        code: str,
        functions: list[FunctionInfo],
    ):
        """Calculate and update complexity for each function."""
        try:
            tree = ast.parse(code)
        except SyntaxError:
            return
        
        # Map function names to their AST nodes
        func_nodes = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                func_nodes[node.name] = node
        
        # Calculate complexity for each function
        for func in functions:
            if func.name in func_nodes:
                node = func_nodes[func.name]
                func.complexity = self._calculate_function_complexity(node)
    
    def _calculate_function_complexity(self, node: ast.FunctionDef) -> int:
        """Calculate cyclomatic complexity for a function."""
        complexity = 1  # Base complexity
        
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                complexity += 1
            elif isinstance(child, ast.BoolOp):
                complexity += len(child.values) - 1
        
        return complexity
    
    def _generate_summary(
        self,
        functions: list[FunctionInfo],
        classes: list[ClassInfo],
        imports: list[str],
        loc: int,
    ) -> str:
        """Generate a brief summary of the code."""
        # Check if file is empty
        if loc == 0 and not functions and not classes and not imports:
            return "Empty file"
        
        parts = []
        
        # LOC
        parts.append(f"{loc} lines of code")
        
        # Classes
        if classes:
            class_names = [c.name for c in classes]
            if len(classes) == 1:
                parts.append(f"defines class {class_names[0]}")
            else:
                parts.append(f"defines {len(classes)} classes: {', '.join(class_names[:3])}")
        
        # Functions
        if functions:
            func_names = [f.name for f in functions]
            if len(functions) == 1:
                parts.append(f"defines function {func_names[0]}")
            else:
                parts.append(f"defines {len(functions)} functions: {', '.join(func_names[:3])}")
        
        # Imports
        if imports:
            main_imports = [imp.split(".")[0] for imp in imports[:3]]
            if len(imports) == 1:
                parts.append(f"imports {main_imports[0]}")
            else:
                parts.append(f"imports {len(imports)} modules: {', '.join(main_imports)}")
        
        # Join parts
        if not parts:
            return "Empty file"
        
        summary = parts[0].capitalize()
        if len(parts) > 1:
            summary += ", " + ", ".join(parts[1:])
        
        return summary + "."
