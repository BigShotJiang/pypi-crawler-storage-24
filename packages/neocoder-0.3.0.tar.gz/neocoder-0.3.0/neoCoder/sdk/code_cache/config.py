"""
Configuration for code cache.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class CacheConfig:
    """Configuration for code understanding cache."""
    
    # Cache behavior
    enabled: bool = True
    max_entries: int = 1000
    ttl_seconds: int = 3600  # 1 hour
    
    # Storage
    storage_path: str | None = None  # None = in-memory only
    use_disk_cache: bool = False
    
    # Invalidation
    check_mtime: bool = True
    check_content_hash: bool = True
    
    # Analysis
    parse_ast: bool = True
    calculate_complexity: bool = True
    extract_docstrings: bool = True
    
    # Performance
    max_file_size_mb: int = 10
    async_analysis: bool = False
    
    def __post_init__(self):
        """Validate configuration."""
        if self.max_entries < 1:
            raise ValueError("max_entries must be >= 1")
        if self.ttl_seconds < 0:
            raise ValueError("ttl_seconds must be >= 0")
        if self.max_file_size_mb <= 0:
            raise ValueError("max_file_size_mb must be > 0")
        
        # Set default storage path if using disk cache
        if self.use_disk_cache and self.storage_path is None:
            self.storage_path = str(Path.home() / ".neoCoder" / "code_cache.json")
