"""
Code parser - extracts structure from source code.
"""

from __future__ import annotations

import ast
from typing import Any

from neoCoder.sdk.code_cache.models import FunctionInfo, ClassInfo


class CodeParser:
    """Parses source code to extract structure using AST."""
    
    def __init__(self):
        """Initialize parser."""
        pass
    
    def parse_python(self, code: str) -> dict[str, Any]:
        """
        Parse Python code and extract structure.
        
        Args:
            code: Python source code
            
        Returns:
            Dictionary with:
                - functions: list of FunctionInfo
                - classes: list of ClassInfo
                - imports: list of import statements
        """
        try:
            tree = ast.parse(code)
        except SyntaxError:
            # Return empty structure if code has syntax errors
            return {
                "functions": [],
                "classes": [],
                "imports": [],
            }
        
        functions = []
        classes = []
        imports = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Only top-level functions (not methods)
                if self._is_top_level(node, tree):
                    functions.append(self._extract_function(node))
            
            elif isinstance(node, ast.ClassDef):
                classes.append(self._extract_class(node))
            
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                imports.extend(self._extract_imports(node))
        
        return {
            "functions": functions,
            "classes": classes,
            "imports": imports,
        }
    
    def _is_top_level(self, node: ast.FunctionDef, tree: ast.Module) -> bool:
        """Check if function is top-level (not a method)."""
        for item in tree.body:
            if item is node:
                return True
        return False
    
    def _extract_function(self, node: ast.FunctionDef) -> FunctionInfo:
        """Extract function information from AST node."""
        # Extract arguments
        args = []
        for arg in node.args.args:
            args.append(arg.arg)
        
        # Extract return type annotation
        returns = None
        if node.returns:
            returns = ast.unparse(node.returns)
        
        # Extract docstring
        docstring = ast.get_docstring(node)
        
        return FunctionInfo(
            name=node.name,
            line_start=node.lineno,
            line_end=node.end_lineno or node.lineno,
            args=args,
            returns=returns,
            docstring=docstring,
            complexity=0,  # Will be calculated by analyzer
        )
    
    def _extract_class(self, node: ast.ClassDef) -> ClassInfo:
        """Extract class information from AST node."""
        # Extract base classes
        bases = []
        for base in node.bases:
            if isinstance(base, ast.Name):
                bases.append(base.id)
            elif isinstance(base, ast.Attribute):
                bases.append(ast.unparse(base))
        
        # Extract methods
        methods = []
        for item in node.body:
            if isinstance(item, ast.FunctionDef):
                methods.append(self._extract_function(item))
        
        # Extract docstring
        docstring = ast.get_docstring(node)
        
        return ClassInfo(
            name=node.name,
            line_start=node.lineno,
            line_end=node.end_lineno or node.lineno,
            methods=methods,
            bases=bases,
            docstring=docstring,
        )
    
    def _extract_imports(self, node: ast.Import | ast.ImportFrom) -> list[str]:
        """Extract import statements."""
        imports = []
        
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            for alias in node.names:
                if module:
                    imports.append(f"{module}.{alias.name}")
                else:
                    imports.append(alias.name)
        
        return imports
