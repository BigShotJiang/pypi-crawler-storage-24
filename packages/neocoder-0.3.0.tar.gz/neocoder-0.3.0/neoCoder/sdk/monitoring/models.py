"""
Data models for monitoring module.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class ModelInfo:
    """Information about a language model."""
    
    name: str
    max_context_tokens: int
    max_output_tokens: int
    reasoning_effort: Optional[str] = None
    reasoning_tokens: Optional[int] = None
    provider: str = "openai"  # or "anthropic"
    
    def __post_init__(self):
        """Validate model info after initialization."""
        if self.max_context_tokens <= 0:
            raise ValueError("max_context_tokens must be positive")
        if self.max_output_tokens <= 0:
            raise ValueError("max_output_tokens must be positive")
        if self.reasoning_tokens is not None and self.reasoning_tokens < 0:
            raise ValueError("reasoning_tokens must be non-negative")
        if self.provider not in ("openai", "anthropic"):
            raise ValueError("provider must be 'openai' or 'anthropic'")


@dataclass
class TokenUsage:
    """Token usage information."""
    
    context_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    total_tokens: int = 0
    
    def __post_init__(self):
        """Validate token usage after initialization."""
        if self.context_tokens < 0:
            raise ValueError("context_tokens must be non-negative")
        if self.output_tokens < 0:
            raise ValueError("output_tokens must be non-negative")
        if self.reasoning_tokens < 0:
            raise ValueError("reasoning_tokens must be non-negative")
        if self.total_tokens < 0:
            raise ValueError("total_tokens must be non-negative")


@dataclass
class UsagePercentages:
    """Usage percentages relative to model limits."""
    
    context_percent: float
    output_percent: float
    reasoning_percent: Optional[float] = None
    
    def __post_init__(self):
        """Validate percentages after initialization."""
        if self.context_percent < 0:
            raise ValueError("context_percent must be non-negative")
        if self.output_percent < 0:
            raise ValueError("output_percent must be non-negative")
        if self.reasoning_percent is not None and self.reasoning_percent < 0:
            raise ValueError("reasoning_percent must be non-negative")
