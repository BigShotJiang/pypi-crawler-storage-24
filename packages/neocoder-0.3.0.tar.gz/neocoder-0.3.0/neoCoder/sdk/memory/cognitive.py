"""
Cognitive Memory Manager for the neoCoder SDK.

Implements "Context as Cognitive Architecture" pattern by integrating:
- Working Memory (short-term, per-session)
- Hierarchical Memory (long-term, cross-session)
- Episodic Memory (task episodes for learning from experience)
- Procedural Memory (learned workflows and patterns)
- Notes Storage (detailed markdown notes from NoteTaker)
- Memory Consolidation (working → long-term transfer)
- xMemory (hierarchical semantic memory with themes) [NEW]

This is the central coordinator for all memory operations.
"""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from neoCoder.sdk.memory.working import WorkingMemory, WorkingMemoryConfig
from neoCoder.sdk.memory.hierarchical import (
    HierarchicalMemory,
    HierarchicalMemoryConfig,
    MemoryScope,
)
from neoCoder.sdk.memory.episodic import (
    Episode,
    EpisodicMemory,
    EpisodicMemoryConfig,
)
from neoCoder.sdk.memory.procedural import (
    Procedure,
    ProceduralMemory,
    ProceduralMemoryConfig,
    ProcedureExtractor,
)
from neoCoder.sdk.memory.notes import NotesStorage, NotesConfig, Note

# xMemory integration (Beyond RAG approach)
from neoCoder.sdk.memory.xmemory.integration import (
    XMemoryIntegration,
    XMemoryConfig,
)

logger = logging.getLogger(__name__)


@dataclass
class CognitiveMemoryConfig:
    """Configuration for cognitive memory system."""

    # Working memory
    working_config: WorkingMemoryConfig | None = None

    # Hierarchical memory
    enable_hierarchical: bool = True
    hierarchical_config: HierarchicalMemoryConfig | None = None
    hierarchical_memory: HierarchicalMemory | None = None  # External instance (avoids dual creation)

    # Episodic memory
    enable_episodic: bool = True
    episodic_config: EpisodicMemoryConfig | None = None

    # Consolidation
    enable_consolidation: bool = True
    consolidate_on_compression: bool = True
    consolidate_on_completion: bool = True

    # Episode retrieval
    inject_episodes_on_start: bool = True
    max_injected_episodes: int = 3

    # Procedural memory
    enable_procedural: bool = True
    procedural_config: ProceduralMemoryConfig | None = None
    inject_procedures_on_start: bool = True
    auto_extract_procedures: bool = True  # Extract from episode clusters
    extraction_interval: int = 5  # Extract after every N completed tasks

    # Notes storage (integration with NoteTaker)
    enable_notes: bool = True
    notes_config: NotesConfig | None = None
    inject_notes_on_start: bool = True
    max_injected_notes: int = 3

    # xMemory (hierarchical semantic memory with themes)
    enable_xmemory: bool = True
    xmemory_config: XMemoryConfig | None = None
    inject_xmemory_on_start: bool = True
    process_episodes_with_xmemory: bool = True  # Auto-process completed episodes


@dataclass
class ConsolidationResult:
    """Result of a memory consolidation operation."""

    success: bool
    summary: str = ""
    episode_id: str | None = None
    error: str | None = None


class CognitiveMemoryManager:
    """
    Central coordinator for cognitive memory operations.

    Manages the flow of information between:
    - Working Memory ↔ LLM context
    - Working Memory → Hierarchical Memory (consolidation)
    - Episodic Memory ↔ Working Memory (retrieval/storage)
    """

    def __init__(self, config: CognitiveMemoryConfig | None = None):
        """
        Initialize cognitive memory manager.

        Args:
            config: Configuration for all memory systems.
        """
        self.config = config or CognitiveMemoryConfig()

        # Initialize memory systems
        self._working = WorkingMemory(config=self.config.working_config)

        self._hierarchical: HierarchicalMemory | None = None
        if self.config.enable_hierarchical:
            # Use external instance if provided, else create new
            if self.config.hierarchical_memory is not None:
                self._hierarchical = self.config.hierarchical_memory
            else:
                self._hierarchical = HierarchicalMemory(
                    config=self.config.hierarchical_config
                )

        self._episodic: EpisodicMemory | None = None
        if self.config.enable_episodic:
            self._episodic = EpisodicMemory(config=self.config.episodic_config)

        # Procedural memory
        self._procedural: ProceduralMemory | None = None
        self._procedure_extractor: ProcedureExtractor | None = None
        if self.config.enable_procedural:
            self._procedural = ProceduralMemory(config=self.config.procedural_config)
            if self._episodic:
                self._procedure_extractor = ProcedureExtractor(
                    episodic_memory=self._episodic,
                    procedural_memory=self._procedural,
                )

        # Notes storage (integration with NoteTaker)
        self._notes: NotesStorage | None = None
        if self.config.enable_notes:
            self._notes = NotesStorage(config=self.config.notes_config)

        # xMemory (hierarchical semantic memory with themes)
        self._xmemory: XMemoryIntegration | None = None
        if self.config.enable_xmemory:
            self._xmemory = XMemoryIntegration(
                episodic_memory=self._episodic,
                config=self.config.xmemory_config,
            )

        # Current task context
        self._current_task: str = ""
        self._current_entry_id: str | None = None
        self._current_tech_hints: list[str] = []
        self._session_id: str = str(uuid.uuid4())
        self._tasks_since_extraction: int = 0

        # Track procedures used in current task
        self._used_procedures: list[str] = []  # Procedure IDs

        # Consolidation state
        self._compression_summaries: list[dict[str, Any]] = []
        
        # Callback for generating summaries (set by orchestrator)
        self._summary_generator: Callable[[str], str] | None = None
        
        # Embedding function (for xMemory)
        self._embed_fn: Callable[[str], np.ndarray] | None = None

    @property
    def working(self) -> WorkingMemory:
        """Access working memory."""
        return self._working

    @property
    def hierarchical(self) -> HierarchicalMemory | None:
        """Access hierarchical memory."""
        return self._hierarchical

    @property
    def episodic(self) -> EpisodicMemory | None:
        """Access episodic memory."""
        return self._episodic

    @property
    def procedural(self) -> ProceduralMemory | None:
        """Access procedural memory."""
        return self._procedural

    @property
    def notes(self) -> NotesStorage | None:
        """Access notes storage."""
        return self._notes

    @property
    def xmemory(self) -> XMemoryIntegration | None:
        """Access xMemory integration."""
        return self._xmemory

    def set_summary_generator(self, generator: Callable[[str], str]) -> None:
        """
        Set the callback for generating summaries.

        This is typically an LLM call provided by the orchestrator.

        Args:
            generator: Function that takes context and returns a summary.
        """
        self._summary_generator = generator
        
        # Also set for procedural memory extraction
        if self._procedural:
            self._procedural.set_llm_extractor(generator)

    def set_embedding_function(self, embed_fn: Callable[[str], np.ndarray]) -> None:
        """
        Set the embedding function for xMemory.

        Args:
            embed_fn: Function that takes text and returns embedding vector.
        """
        self._embed_fn = embed_fn
        
        # Configure xMemory with both LLM and embedding
        if self._xmemory and self._summary_generator:
            self._xmemory.configure_llm(
                llm_call=self._summary_generator,
                embed_fn=embed_fn,
            )

    def set_tech_hints(self, tech_hints: list[str]) -> None:
        """
        Set technology hints for procedure matching.

        Args:
            tech_hints: List of technologies (e.g., ["python", "django", "postgres"]).
        """
        self._current_tech_hints = tech_hints

    def start_task(self, task: str, session_id: str | None = None) -> str | None:
        """
        Initialize memory for a new task.

        Creates hierarchical entry, retrieves relevant episodes,
        and optionally injects them into working memory.

        Args:
            task: Task description.
            session_id: Optional session ID.

        Returns:
            Context string with relevant episodes (if any).
        """
        self._current_task = task
        if session_id:
            self._session_id = session_id

        # Create hierarchical entry for this task
        if self._hierarchical:
            self._current_entry_id = self._hierarchical.create_entry(
                name="task",
                metadata={
                    "task_description": task,
                    "session_id": self._session_id,
                    "created_at": time.time(),
                },
            )
            logger.info(f"Created hierarchical entry: {self._current_entry_id}")

        # Reset used procedures tracking
        self._used_procedures = []

        # Retrieve from xMemory first (hierarchical semantic search)
        # This may include episodes at L1 level, so we track them for deduplication
        xmemory_context: str | None = None
        xmemory_episode_ids: set[str] = set()
        if self.config.inject_xmemory_on_start and self._xmemory:
            xmemory_context = self._xmemory.retrieve_context(
                query=task,
                tech_hints=self._current_tech_hints,
            )
            if xmemory_context:
                logger.info("Retrieved xMemory hierarchical context")
                # Extract episode IDs that xMemory already included (for deduplication)
                xmemory_episode_ids = self._extract_episode_ids_from_xmemory()

        # Retrieve relevant procedures (higher priority than individual episodes)
        procedure_context: str | None = None
        if (
            self.config.inject_procedures_on_start
            and self._procedural
            and self._procedural.get_all_procedures()
        ):
            procedures = self._procedural.retrieve_for_task(
                task=task,
                tech_hints=self._current_tech_hints,
            )
            if procedures:
                procedure_context = self._procedural.format_for_context(procedures)
                # Track which procedures were suggested
                self._used_procedures = [p.id for p, _ in procedures]
                logger.info(f"Retrieved {len(procedures)} relevant procedures")

        # Retrieve relevant episodes (deduplicate against xMemory)
        episode_context: str | None = None
        if (
            self.config.inject_episodes_on_start
            and self._episodic
            and self._episodic.get_all_episodes()
        ):
            episodes = self._episodic.retrieve_similar(
                task=task,
                max_results=self.config.max_injected_episodes,
            )
            # Deduplicate: exclude episodes already included by xMemory
            if episodes and xmemory_episode_ids:
                episodes = [
                    (ep, score) for ep, score in episodes
                    if ep.id not in xmemory_episode_ids
                ]
            if episodes:
                episode_context = self._episodic.format_for_context(episodes)
                logger.info(f"Retrieved {len(episodes)} relevant episodes (deduplicated)")

        # Search relevant notes (from NoteTaker)
        notes_context: str | None = None
        if self.config.inject_notes_on_start and self._notes:
            notes = self._search_relevant_notes(task)
            if notes:
                notes_context = self._format_notes_for_context(notes)
                logger.info(f"Retrieved {len(notes)} relevant notes")

        # Combine contexts with priority policy header
        contexts = []
        
        # Add policy header if we have multiple sources
        has_multiple_sources = sum(bool(x) for x in [
            xmemory_context, procedure_context, episode_context, notes_context
        ]) > 1
        
        if has_multiple_sources:
            policy_header = (
                "[Long-term Memory Context]\n"
                "Priority order if sources conflict: "
                "Procedures > xMemory themes > Recent episodes > Notes.\n"
                "Prefer the current task requirements over any historical context."
            )
            contexts.append(policy_header)
        
        # Order by priority: xMemory (themes) > Procedures > Episodes > Notes
        if xmemory_context:
            contexts.append(xmemory_context)
        if procedure_context:
            contexts.append(procedure_context)
        if episode_context:
            contexts.append(episode_context)
        if notes_context:
            contexts.append(notes_context)

        return "\n\n".join(contexts) if contexts else None
    
    def _extract_episode_ids_from_xmemory(self) -> set[str]:
        """
        Extract episode IDs that xMemory has already included in retrieval.
        
        Returns:
            Set of episode IDs to deduplicate against.
        """
        if not self._xmemory:
            return set()
        
        # Get the last retrieval result from xMemory retriever if available
        try:
            retriever = self._xmemory.retriever
            if hasattr(retriever, '_last_result') and retriever._last_result:
                return {ep.id for ep in retriever._last_result.episodes}
        except Exception:
            pass
        
        return set()

    def on_compression(self, summary: str, compressed_count: int) -> None:
        """
        Handle working memory compression event.

        Stores compression summary in hierarchical memory for
        long-term retention.

        Args:
            summary: The compression summary.
            compressed_count: Number of messages compressed.
        """
        if not self.config.consolidate_on_compression:
            return

        # Store in compression history
        compression_record = {
            "timestamp": time.time(),
            "summary": summary,
            "message_count": compressed_count,
        }
        self._compression_summaries.append(compression_record)

        # Store in hierarchical memory
        if self._hierarchical and self._current_entry_id:
            self._hierarchical.store(
                key="compression_summaries",
                value=self._compression_summaries,
                path=[self._current_entry_id],
            )
            logger.debug("Stored compression summary in hierarchical memory")

    def complete_task(
        self,
        success: bool,
        output: str,
        artifacts: dict[str, Any],
        metrics: dict[str, Any],
    ) -> ConsolidationResult:
        """
        Finalize task and consolidate memory.

        Creates an episode from the task, stores it in episodic memory,
        and persists to hierarchical memory.

        Args:
            success: Whether task completed successfully.
            output: Task output/result.
            artifacts: Task artifacts (files, decisions, etc.).
            metrics: Task metrics (tokens, iterations, etc.).

        Returns:
            ConsolidationResult with episode details.
        """
        if not self.config.consolidate_on_completion:
            return ConsolidationResult(success=True, summary="Consolidation disabled")

        try:
            # Generate summary if we have a generator
            summary = ""
            if self._summary_generator and output:
                try:
                    context = self._build_consolidation_context(output, artifacts)
                    summary = self._summary_generator(context)
                except Exception as e:
                    logger.warning(f"Failed to generate summary: {e}")
                    summary = output[:500] if output else "Task completed"
            else:
                summary = output[:500] if output else "Task completed"

            # Create episode
            episode = Episode(
                id=f"ep_{uuid.uuid4().hex[:8]}",
                task_description=self._current_task,
                summary=summary,
                outcome="success" if success else "failed",
                files_touched=artifacts.get("files_written", []),
                errors_fixed=artifacts.get("errors_fixed", []),
                key_decisions=artifacts.get("key_decisions", []),
                tags=self._extract_tags(self._current_task),
                task_type=metrics.get("task_type", "coding"),
                complexity=metrics.get("complexity", 0.5),
                total_tokens=metrics.get("total_tokens", 0),
                iterations=metrics.get("iterations", 0),
            )

            # Store in episodic memory
            if self._episodic:
                self._episodic.add_episode(episode)
                logger.info(f"Stored episode: {episode.id}")

            # Store in hierarchical memory
            if self._hierarchical and self._current_entry_id:
                self._hierarchical.store(
                    key="episode",
                    value=episode.to_dict(),
                    path=[self._current_entry_id],
                )

            # Update procedure success rates
            if self._procedural and self._used_procedures:
                for proc_id in self._used_procedures:
                    self._procedural.record_outcome(proc_id, success)

            # Trigger automatic procedure extraction periodically
            self._tasks_since_extraction += 1
            if (
                self.config.auto_extract_procedures
                and self._procedure_extractor
                and self._tasks_since_extraction >= self.config.extraction_interval
            ):
                self._trigger_procedure_extraction()
                self._tasks_since_extraction = 0

            # Process episode through xMemory for semantic extraction
            if self.config.process_episodes_with_xmemory and self._xmemory:
                try:
                    xmem_result = self._xmemory.process_episode(episode)
                    if xmem_result.success:
                        logger.info(
                            f"xMemory processed: {xmem_result.semantics_extracted} semantics, "
                            f"quality {xmem_result.quality_before:.2f} → {xmem_result.quality_after:.2f}"
                        )
                except Exception as e:
                    logger.warning(f"xMemory processing failed: {e}")

            return ConsolidationResult(
                success=True,
                summary=summary,
                episode_id=episode.id,
            )

        except Exception as e:
            logger.error(f"Consolidation failed: {e}")
            return ConsolidationResult(
                success=False,
                error=str(e),
            )

    def _trigger_procedure_extraction(self) -> list[Procedure]:
        """
        Trigger automatic extraction of procedures from episode clusters.

        Returns:
            List of newly extracted procedures.
        """
        if not self._procedure_extractor:
            return []

        try:
            extracted = self._procedure_extractor.extract_all()
            if extracted:
                logger.info(f"Auto-extracted {len(extracted)} new procedures")
            return extracted
        except Exception as e:
            logger.warning(f"Procedure extraction failed: {e}")
            return []

    def extract_procedures_now(self) -> list[Procedure]:
        """
        Manually trigger procedure extraction.

        Returns:
            List of newly extracted procedures.
        """
        return self._trigger_procedure_extraction()

    def _search_relevant_notes(self, task: str) -> list[Note]:
        """
        Search notes storage for notes relevant to the task.

        Args:
            task: Task description.

        Returns:
            List of relevant Note objects.
        """
        if not self._notes:
            return []

        # Extract keywords from task for search
        keywords = self._extract_search_keywords(task)
        
        # Search by query and keywords
        notes = self._notes.search_notes(
            query=task[:100],  # Use first part of task as query
            keywords=keywords,
        )

        # Limit results
        return notes[:self.config.max_injected_notes]

    def _extract_search_keywords(self, task: str) -> list[str]:
        """Extract keywords for notes search."""
        import re
        
        keywords = []
        task_lower = task.lower()

        # Extract common task keywords
        keyword_patterns = [
            r"\b(auth|authentication|login|jwt|session)\b",
            r"\b(api|rest|endpoint|route)\b",
            r"\b(database|db|sql|query|migration)\b",
            r"\b(test|testing|pytest|unittest)\b",
            r"\b(error|bug|fix|debug)\b",
            r"\b(performance|optimize|cache)\b",
            r"\b(security|validation|sanitize)\b",
        ]

        for pattern in keyword_patterns:
            matches = re.findall(pattern, task_lower)
            keywords.extend(matches)

        # Add tech stack hints as keywords
        keywords.extend(self._current_tech_hints)

        return list(set(keywords))[:10]  # Dedupe and limit

    def _format_notes_for_context(
        self,
        notes: list[Note],
        max_chars: int = 1200,
    ) -> str:
        """
        Format notes for injection into context.

        Args:
            notes: List of notes to format.
            max_chars: Maximum total characters.

        Returns:
            Formatted context string.
        """
        if not notes:
            return ""

        lines = ["[Relevant Notes from Knowledge Base]", ""]
        current_chars = len(lines[0])

        for note in notes:
            # Build note summary
            note_lines = [
                f"### {note.metadata.title}",
                f"*Category: {note.metadata.category} | Keywords: {', '.join(note.metadata.keywords[:5])}*",
                "",
            ]
            
            # Add truncated content
            content_preview = note.content[:400]
            if len(note.content) > 400:
                content_preview += "..."
            note_lines.append(content_preview)
            note_lines.append("")

            note_str = "\n".join(note_lines)
            
            if current_chars + len(note_str) > max_chars:
                break

            lines.extend(note_lines)
            current_chars += len(note_str)

        return "\n".join(lines)

    def search_notes(
        self,
        query: str | None = None,
        keywords: list[str] | None = None,
        category: str | None = None,
    ) -> list[Note]:
        """
        Search notes directly.

        Args:
            query: Text to search.
            keywords: Keywords to match.
            category: Category filter.

        Returns:
            List of matching notes.
        """
        if not self._notes:
            return []
        return self._notes.search_notes(
            query=query,
            keywords=keywords,
            category=category,
        )

    def _build_consolidation_context(
        self, output: str, artifacts: dict[str, Any]
    ) -> str:
        """Build context string for summary generation."""
        lines = [
            f"Task: {self._current_task}",
            "",
            "Output:",
            output[:2000] if len(output) > 2000 else output,
        ]

        if artifacts.get("files_written"):
            lines.append("")
            lines.append(f"Files written: {', '.join(artifacts['files_written'][:5])}")

        if artifacts.get("key_decisions"):
            lines.append("")
            lines.append("Key decisions:")
            for decision in artifacts["key_decisions"][:3]:
                lines.append(f"- {decision}")

        return "\n".join(lines)

    def _extract_tags(self, task: str) -> list[str]:
        """Extract relevant tags from task description."""
        import re

        tags = []
        task_lower = task.lower()

        # Task type tags
        if any(kw in task_lower for kw in ["debug", "fix", "bug", "error"]):
            tags.append("debug")
        if any(kw in task_lower for kw in ["refactor", "clean", "optimize"]):
            tags.append("refactor")
        if any(kw in task_lower for kw in ["test", "spec", "unittest"]):
            tags.append("testing")
        if any(kw in task_lower for kw in ["api", "endpoint", "rest"]):
            tags.append("api")
        if any(kw in task_lower for kw in ["database", "db", "sql", "query"]):
            tags.append("database")

        # Technology tags
        tech_patterns = [
            r"\b(python|java|javascript|typescript|rust|go|kotlin)\b",
            r"\b(react|vue|angular|svelte|django|flask|spring|fastapi)\b",
            r"\b(postgres|mysql|mongodb|redis|sqlite)\b",
        ]
        for pattern in tech_patterns:
            matches = re.findall(pattern, task_lower)
            tags.extend(matches)

        return list(set(tags))

    def reset(self) -> None:
        """Reset all memory for new session."""
        self._working.clear()
        self._current_task = ""
        self._current_entry_id = None
        self._compression_summaries.clear()
        self._session_id = str(uuid.uuid4())

    def get_memory_stats(self) -> dict[str, Any]:
        """Get statistics about all memory systems."""
        stats = {
            "working": {
                "message_count": self._working.message_count,
                "total_tokens": self._working._total_tokens,
                "has_compressed_summary": self._working._compressed_summary is not None,
            },
        }

        if self._hierarchical:
            stats["hierarchical"] = {
                "entries": len(self._hierarchical.get_all_entries()),
                "current_entry": self._current_entry_id,
            }

        if self._episodic:
            stats["episodic"] = {
                "episode_count": len(self._episodic.get_all_episodes()),
            }

        if self._procedural:
            procedures = self._procedural.get_all_procedures()
            stats["procedural"] = {
                "procedure_count": len(procedures),
                "total_usage": sum(p.usage_count for p in procedures),
                "avg_success_rate": (
                    sum(p.success_rate for p in procedures) / len(procedures)
                    if procedures else 0.0
                ),
            }

        if self._xmemory:
            stats["xmemory"] = self._xmemory.get_quality_metrics()

        return stats

    def export_to_dict(self) -> dict[str, Any]:
        """Export all memory state for persistence."""
        data = {
            "working": self._working.to_dict(),
            "session_id": self._session_id,
            "current_task": self._current_task,
            "compression_summaries": self._compression_summaries,
        }

        if self._episodic:
            data["episodic"] = self._episodic.to_dict()

        if self._procedural:
            data["procedural"] = self._procedural.to_dict()

        if self._xmemory:
            data["xmemory"] = self._xmemory.to_dict()

        return data

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        config: CognitiveMemoryConfig | None = None,
    ) -> CognitiveMemoryManager:
        """Restore memory state from dictionary."""
        manager = cls(config=config)

        if "working" in data:
            manager._working = WorkingMemory.from_dict(
                data["working"],
                config=config.working_config if config else None,
            )

        manager._session_id = data.get("session_id", str(uuid.uuid4()))
        manager._current_task = data.get("current_task", "")
        manager._compression_summaries = data.get("compression_summaries", [])

        if "episodic" in data and manager._episodic:
            manager._episodic = EpisodicMemory.from_dict(
                data["episodic"],
                config=config.episodic_config if config else None,
            )

        if "procedural" in data and manager._procedural:
            manager._procedural = ProceduralMemory.from_dict(
                data["procedural"],
                config=config.procedural_config if config else None,
            )

        if "xmemory" in data and manager._xmemory:
            manager._xmemory = XMemoryIntegration.from_dict(
                data["xmemory"],
                episodic_memory=manager._episodic,
                config=config.xmemory_config if config else None,
            )

        return manager
