"""
Persistent Notes Storage System for the neoCoder SDK.

Provides a file-system-like tree structure for storing notes:
- Markdown files organized in hierarchies
- Typed memory nodes with tags/keywords
- CRUD operations for notes
- Support for cross-session retrieval

Based on Section 2.3.2 (F2: Note-Taking Agent) from the paper.
"""

from __future__ import annotations

import json
import os
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Literal


@dataclass
class NoteMetadata:
    """Metadata for a note."""

    id: str
    title: str
    description: str = ""
    keywords: list[str] = field(default_factory=list)
    category: str = "general"
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    def to_frontmatter(self) -> str:
        """Convert to YAML frontmatter."""
        lines = [
            "---",
            f"id: {self.id}",
            f"title: {self.title}",
            f"description: {self.description}",
            f"keywords:",
        ]
        for kw in self.keywords:
            lines.append(f"- {kw}")
        lines.extend([
            f"category: {self.category}",
            f"created_at: {self.created_at.isoformat()}",
            f"updated_at: {self.updated_at.isoformat()}",
            "---",
        ])
        return "\n".join(lines)

    @classmethod
    def from_frontmatter(cls, text: str) -> NoteMetadata | None:
        """Parse from YAML frontmatter."""
        match = re.match(r"^---\n(.+?)\n---", text, re.DOTALL)
        if not match:
            return None

        frontmatter = match.group(1)
        data = {}

        # Simple YAML parsing
        current_key = None
        current_list = []

        for line in frontmatter.split("\n"):
            if line.startswith("- ") and current_key:
                current_list.append(line[2:].strip())
            elif ":" in line:
                if current_key and current_list:
                    data[current_key] = current_list
                    current_list = []

                key, value = line.split(":", 1)
                key = key.strip()
                value = value.strip()

                if not value:
                    current_key = key
                else:
                    data[key] = value
                    current_key = None

        if current_key and current_list:
            data[current_key] = current_list

        return cls(
            id=data.get("id", str(uuid.uuid4())),
            title=data.get("title", "Untitled"),
            description=data.get("description", ""),
            keywords=data.get("keywords", []),
            category=data.get("category", "general"),
            created_at=datetime.fromisoformat(data["created_at"]) if "created_at" in data else datetime.now(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if "updated_at" in data else datetime.now(),
        )


@dataclass
class Note:
    """A note with metadata and content."""

    metadata: NoteMetadata
    content: str
    path: str  # Relative path within notes directory

    def to_markdown(self) -> str:
        """Convert to markdown with frontmatter."""
        return f"{self.metadata.to_frontmatter()}\n\n{self.content}"

    @classmethod
    def from_markdown(cls, text: str, path: str) -> Note | None:
        """Parse from markdown with frontmatter."""
        metadata = NoteMetadata.from_frontmatter(text)
        if not metadata:
            # No frontmatter, create basic note
            metadata = NoteMetadata(
                id=str(uuid.uuid4()),
                title=Path(path).stem,
            )
            content = text
        else:
            # Extract content after frontmatter
            match = re.match(r"^---\n.+?\n---\n*(.*)$", text, re.DOTALL)
            content = match.group(1) if match else text

        return cls(metadata=metadata, content=content, path=path)


@dataclass
class NotesConfig:
    """Configuration for notes storage."""

    storage_dir: str = ".neoCoder/notes"  # Relative to working_dir
    index_file: str = "README.md"
    max_notes: int = 1000


class NotesStorage:
    """
    Persistent notes storage with file-system structure.

    Organizes notes in a hierarchy:
    ```
    notes/
    ├── README.md (index)
    ├── projects/
    │   └── project_name/
    │       ├── architecture.md
    │       └── findings.md
    ├── shared/
    │   └── python/
    │       └── common_patterns.md
    └── hindsight/
        └── error_handling.md
    ```
    """

    def __init__(self, config: NotesConfig | None = None):
        """
        Initialize notes storage.

        Args:
            config: Storage configuration.
        """
        self.config = config or NotesConfig()
        self._storage_path = Path(self.config.storage_dir)
        self._storage_path.mkdir(parents=True, exist_ok=True)

        # Create index if not exists
        self._ensure_index()

    def _ensure_index(self) -> None:
        """Ensure index file exists."""
        index_path = self._storage_path / self.config.index_file
        if not index_path.exists():
            index_content = """# Notes Index

This directory contains persistent notes from the neoCoder Agent.

## Structure

- `projects/` - Project-specific knowledge
- `shared/` - Generic, reusable insights
- `hindsight/` - Lessons learned from failures

## Usage

Notes are automatically created and updated by the Note-Taking Agent.
They can be searched by keywords or browsed by category.
"""
            index_path.write_text(index_content, encoding="utf-8")

    def create_note(
        self,
        title: str,
        content: str,
        category: str = "general",
        keywords: list[str] | None = None,
        path: str | None = None,
    ) -> Note:
        """
        Create a new note.

        Args:
            title: Note title.
            content: Note content.
            category: Category (projects, shared, hindsight).
            keywords: Search keywords.
            path: Custom path within storage.

        Returns:
            Created Note object.
        """
        note_id = str(uuid.uuid4())[:8]

        # Generate path if not provided
        if path is None:
            safe_title = re.sub(r"[^\w\s-]", "", title.lower())
            safe_title = re.sub(r"[\s]+", "_", safe_title)
            path = f"{category}/{safe_title}.md"

        metadata = NoteMetadata(
            id=note_id,
            title=title,
            keywords=keywords or [],
            category=category,
        )

        note = Note(metadata=metadata, content=content, path=path)

        # Write to disk
        self._write_note(note)

        return note

    def _write_note(self, note: Note) -> None:
        """Write note to disk."""
        full_path = self._storage_path / note.path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(note.to_markdown(), encoding="utf-8")

    def read_note(self, path: str) -> Note | None:
        """
        Read a note by path.

        Args:
            path: Relative path to note.

        Returns:
            Note object or None if not found.
        """
        full_path = self._storage_path / path
        if not full_path.exists():
            return None

        text = full_path.read_text(encoding="utf-8")
        return Note.from_markdown(text, path)

    def update_note(self, path: str, content: str | None = None, **metadata_updates) -> Note | None:
        """
        Update an existing note.

        Args:
            path: Path to note.
            content: New content (optional).
            **metadata_updates: Metadata fields to update.

        Returns:
            Updated Note or None if not found.
        """
        note = self.read_note(path)
        if note is None:
            return None

        if content is not None:
            note.content = content

        for key, value in metadata_updates.items():
            if hasattr(note.metadata, key):
                setattr(note.metadata, key, value)

        note.metadata.updated_at = datetime.now()
        self._write_note(note)

        return note

    def delete_note(self, path: str) -> bool:
        """
        Delete a note.

        Args:
            path: Path to note.

        Returns:
            True if deleted, False if not found.
        """
        full_path = self._storage_path / path
        if not full_path.exists():
            return False

        full_path.unlink()
        return True

    def search_notes(
        self,
        query: str | None = None,
        keywords: list[str] | None = None,
        category: str | None = None,
    ) -> list[Note]:
        """
        Search for notes.

        Args:
            query: Text to search in title/content.
            keywords: Keywords to match.
            category: Category filter.

        Returns:
            List of matching notes.
        """
        results = []

        for note_path in self._storage_path.rglob("*.md"):
            if note_path.name == self.config.index_file:
                continue

            rel_path = str(note_path.relative_to(self._storage_path))
            note = self.read_note(rel_path)

            if note is None:
                continue

            # Apply filters
            if category and note.metadata.category != category:
                continue

            if keywords:
                if not any(kw in note.metadata.keywords for kw in keywords):
                    continue

            if query:
                query_lower = query.lower()
                if query_lower not in note.metadata.title.lower() and query_lower not in note.content.lower():
                    continue

            results.append(note)

        return results

    def list_notes(self, category: str | None = None) -> list[dict[str, Any]]:
        """
        List all notes with basic info.

        Args:
            category: Optional category filter.

        Returns:
            List of note summaries.
        """
        notes = []

        for note_path in self._storage_path.rglob("*.md"):
            if note_path.name == self.config.index_file:
                continue

            rel_path = str(note_path.relative_to(self._storage_path))
            note = self.read_note(rel_path)

            if note is None:
                continue

            if category and note.metadata.category != category:
                continue

            notes.append({
                "path": rel_path,
                "title": note.metadata.title,
                "category": note.metadata.category,
                "keywords": note.metadata.keywords,
                "updated_at": note.metadata.updated_at.isoformat(),
            })

        return sorted(notes, key=lambda x: x["updated_at"], reverse=True)

    def get_tree_structure(self) -> str:
        """Get directory tree structure as string."""
        lines = [str(self._storage_path.name)]
        self._build_tree(self._storage_path, lines, "")
        return "\n".join(lines)

    def _build_tree(self, path: Path, lines: list[str], prefix: str) -> None:
        """Recursively build tree structure."""
        items = sorted(path.iterdir(), key=lambda x: (x.is_file(), x.name))

        for i, item in enumerate(items):
            is_last = i == len(items) - 1
            connector = "└── " if is_last else "├── "
            lines.append(f"{prefix}{connector}{item.name}")

            if item.is_dir():
                extension = "    " if is_last else "│   "
                self._build_tree(item, lines, prefix + extension)
