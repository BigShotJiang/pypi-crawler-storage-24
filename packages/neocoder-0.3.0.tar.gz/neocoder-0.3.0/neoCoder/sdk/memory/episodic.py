"""
Episodic Memory for the neoCoder SDK.

Stores and retrieves task episodes - compact summaries of completed tasks
that can inform future similar tasks.

Based on cognitive architecture research:
- Episodes capture WHAT was done, WHERE, and the OUTCOME
- Simple keyword-based retrieval (can upgrade to embeddings later)
- Integrates with HierarchicalMemory for persistence
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class Episode:
    """A single task episode in memory."""

    id: str
    task_description: str
    summary: str
    outcome: str  # "success", "partial", "failed"
    created_at: float = field(default_factory=time.time)
    
    # Artifacts from the task
    files_touched: list[str] = field(default_factory=list)
    errors_fixed: list[str] = field(default_factory=list)
    key_decisions: list[str] = field(default_factory=list)
    
    # Metadata for retrieval
    tags: list[str] = field(default_factory=list)
    task_type: str = "coding"  # coding, debug, refactor
    complexity: float = 0.5
    
    # Token stats
    total_tokens: int = 0
    iterations: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "id": self.id,
            "task_description": self.task_description,
            "summary": self.summary,
            "outcome": self.outcome,
            "created_at": self.created_at,
            "files_touched": self.files_touched,
            "errors_fixed": self.errors_fixed,
            "key_decisions": self.key_decisions,
            "tags": self.tags,
            "task_type": self.task_type,
            "complexity": self.complexity,
            "total_tokens": self.total_tokens,
            "iterations": self.iterations,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Episode:
        """Deserialize from dictionary."""
        return cls(
            id=data["id"],
            task_description=data["task_description"],
            summary=data["summary"],
            outcome=data.get("outcome", "success"),
            created_at=data.get("created_at", time.time()),
            files_touched=data.get("files_touched", []),
            errors_fixed=data.get("errors_fixed", []),
            key_decisions=data.get("key_decisions", []),
            tags=data.get("tags", []),
            task_type=data.get("task_type", "coding"),
            complexity=data.get("complexity", 0.5),
            total_tokens=data.get("total_tokens", 0),
            iterations=data.get("iterations", 0),
        )

    def to_context_string(self, max_chars: int = 300) -> str:
        """
        Format episode for injection into working memory context.
        
        Args:
            max_chars: Maximum characters for the summary.
            
        Returns:
            Formatted string for context injection.
        """
        lines = [f"- Task: {self.task_description[:100]}"]
        
        date_str = datetime.fromtimestamp(self.created_at).strftime("%Y-%m-%d")
        lines.append(f"  Date: {date_str} | Outcome: {self.outcome}")
        
        if self.summary:
            summary_truncated = self.summary[:max_chars]
            if len(self.summary) > max_chars:
                summary_truncated += "..."
            lines.append(f"  Summary: {summary_truncated}")
        
        if self.files_touched:
            files_str = ", ".join(self.files_touched[:3])
            if len(self.files_touched) > 3:
                files_str += f" (+{len(self.files_touched) - 3} more)"
            lines.append(f"  Files: {files_str}")
        
        if self.key_decisions:
            lines.append(f"  Key decision: {self.key_decisions[0][:80]}")
        
        return "\n".join(lines)


@dataclass
class EpisodicMemoryConfig:
    """Configuration for episodic memory."""

    max_episodes: int = 100  # Maximum episodes to keep
    max_retrieved: int = 3  # Max episodes to retrieve per query
    min_similarity: float = 0.15  # Minimum similarity score to retrieve
    max_context_chars: int = 800  # Max chars for context injection


class EpisodicMemory:
    """
    Episodic memory manager.

    Stores task episodes and retrieves relevant ones for new tasks.
    Uses simple keyword-based similarity (upgradeable to embeddings).
    """

    def __init__(self, config: EpisodicMemoryConfig | None = None):
        """
        Initialize episodic memory.

        Args:
            config: Memory configuration.
        """
        self.config = config or EpisodicMemoryConfig()
        self._episodes: list[Episode] = []
        self._stopwords = {
            "a", "an", "the", "is", "are", "was", "were", "be", "been",
            "being", "have", "has", "had", "do", "does", "did", "will",
            "would", "could", "should", "may", "might", "must", "shall",
            "can", "need", "to", "of", "in", "for", "on", "with", "at",
            "by", "from", "as", "into", "through", "during", "before",
            "after", "above", "below", "between", "under", "again",
            "further", "then", "once", "here", "there", "when", "where",
            "why", "how", "all", "each", "few", "more", "most", "other",
            "some", "such", "no", "nor", "not", "only", "own", "same",
            "so", "than", "too", "very", "just", "and", "but", "if", "or",
            "because", "until", "while", "this", "that", "these", "those",
            "i", "me", "my", "myself", "we", "our", "ours", "you", "your",
            "he", "him", "his", "she", "her", "it", "its", "they", "them",
            "what", "which", "who", "whom", "create", "add", "make", "fix",
            "implement", "write", "code", "file", "function", "class",
        }

    def add_episode(self, episode: Episode) -> None:
        """
        Add an episode to memory.

        Args:
            episode: Episode to add.
        """
        self._episodes.append(episode)
        
        # Prune old episodes if limit exceeded
        if len(self._episodes) > self.config.max_episodes:
            # Remove oldest episodes
            excess = len(self._episodes) - self.config.max_episodes
            self._episodes = self._episodes[excess:]

    def retrieve_similar(
        self,
        task: str,
        max_results: int | None = None,
        min_similarity: float | None = None,
    ) -> list[tuple[Episode, float]]:
        """
        Retrieve episodes similar to the given task.

        Args:
            task: Task description to match.
            max_results: Maximum results to return.
            min_similarity: Minimum similarity threshold.

        Returns:
            List of (episode, similarity_score) tuples, sorted by score descending.
        """
        if not self._episodes:
            return []

        max_results = max_results or self.config.max_retrieved
        min_similarity = min_similarity or self.config.min_similarity

        # Extract keywords from task
        task_keywords = self._extract_keywords(task)
        if not task_keywords:
            return []

        # Score each episode
        scored: list[tuple[Episode, float]] = []
        for episode in self._episodes:
            score = self._compute_similarity(task_keywords, episode)
            if score >= min_similarity:
                scored.append((episode, score))

        # Sort by score descending
        scored.sort(key=lambda x: x[1], reverse=True)

        return scored[:max_results]

    def format_for_context(
        self,
        episodes: list[tuple[Episode, float]],
        max_chars: int | None = None,
    ) -> str:
        """
        Format retrieved episodes for injection into working memory.

        Args:
            episodes: List of (episode, score) tuples.
            max_chars: Maximum total characters.

        Returns:
            Formatted context string.
        """
        if not episodes:
            return ""

        max_chars = max_chars or self.config.max_context_chars
        
        lines = ["[Relevant past tasks]"]
        current_chars = len(lines[0])
        
        for episode, score in episodes:
            # Calculate remaining chars for this episode
            remaining = max_chars - current_chars - 10  # buffer
            if remaining < 50:
                break
                
            episode_str = episode.to_context_string(max_chars=min(300, remaining))
            episode_chars = len(episode_str)
            
            if current_chars + episode_chars > max_chars:
                break
                
            lines.append(episode_str)
            current_chars += episode_chars

        return "\n".join(lines)

    def _extract_keywords(self, text: str) -> set[str]:
        """Extract significant keywords from text."""
        # Normalize and tokenize
        text_lower = text.lower()
        words = re.findall(r'\b[a-z_][a-z0-9_]*\b', text_lower)
        
        # Filter stopwords and short words
        keywords = {
            w for w in words
            if w not in self._stopwords and len(w) > 2
        }
        
        return keywords

    def _compute_similarity(
        self,
        task_keywords: set[str],
        episode: Episode,
    ) -> float:
        """
        Compute similarity between task keywords and an episode.

        Uses Jaccard-like similarity with tag boosting.
        """
        # Extract keywords from episode
        episode_text = f"{episode.task_description} {episode.summary}"
        episode_keywords = self._extract_keywords(episode_text)
        
        # Add tags as keywords
        episode_keywords.update(t.lower() for t in episode.tags)
        
        if not episode_keywords:
            return 0.0

        # Compute intersection
        intersection = task_keywords & episode_keywords
        if not intersection:
            return 0.0

        # Jaccard similarity
        union = task_keywords | episode_keywords
        jaccard = len(intersection) / len(union)
        
        # Boost for matching task type keywords
        type_boost = 0.0
        task_type_keywords = {"debug", "fix", "refactor", "optimize", "implement"}
        if task_keywords & task_type_keywords:
            if any(kw in episode.task_type for kw in task_keywords & task_type_keywords):
                type_boost = 0.1

        return min(1.0, jaccard + type_boost)

    def get_all_episodes(self) -> list[Episode]:
        """Get all stored episodes."""
        return self._episodes.copy()

    def clear(self) -> None:
        """Clear all episodes."""
        self._episodes.clear()

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "episodes": [e.to_dict() for e in self._episodes],
        }

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        config: EpisodicMemoryConfig | None = None,
    ) -> EpisodicMemory:
        """Deserialize from dictionary."""
        memory = cls(config=config)
        for episode_data in data.get("episodes", []):
            memory._episodes.append(Episode.from_dict(episode_data))
        return memory
