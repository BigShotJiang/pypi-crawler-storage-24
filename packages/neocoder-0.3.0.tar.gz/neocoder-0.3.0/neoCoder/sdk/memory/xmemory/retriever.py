"""
Hierarchical Retriever for xMemory.

Implements top-down retrieval with uncertainty-driven expansion:
1. Query themes first (L3)
2. If uncertainty is high, expand to semantics (L2)
3. If still uncertain, ground in episodes (L1)

This approach provides:
- Token efficiency (use high-level summaries when possible)
- Diversity (themes reduce redundancy)
- Precision (expand when needed for multi-fact queries)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from neoCoder.sdk.memory.xmemory.semantic import SemanticMemory, SemanticUnit
from neoCoder.sdk.memory.xmemory.themes import ThemeManager, ThemeNode
from neoCoder.sdk.memory.episodic import EpisodicMemory, Episode

logger = logging.getLogger(__name__)


@dataclass
class RetrieverConfig:
    """Configuration for hierarchical retriever."""
    
    # Theme-level retrieval
    top_k_themes: int = 5
    theme_similarity_threshold: float = 0.3
    
    # Semantic-level expansion
    top_k_semantics_per_theme: int = 3
    semantic_similarity_threshold: float = 0.4
    
    # Episode grounding
    top_k_episodes: int = 3
    episode_similarity_threshold: float = 0.35
    
    # Uncertainty thresholds
    theme_uncertainty_threshold: float = 0.7   # Expand if entropy > this
    semantic_uncertainty_threshold: float = 0.6
    
    # Token budget (approximate chars)
    max_context_chars: int = 4000


@dataclass
class RetrievalResult:
    """Result of hierarchical retrieval."""
    
    # Retrieved content at each level
    themes: list[tuple[ThemeNode, float]] = field(default_factory=list)
    semantics: list[tuple[SemanticUnit, float]] = field(default_factory=list)
    episodes: list[tuple[Episode, float]] = field(default_factory=list)
    
    # Retrieval metadata
    expanded_to_semantics: bool = False
    expanded_to_episodes: bool = False
    theme_uncertainty: float = 0.0
    semantic_uncertainty: float = 0.0
    
    # Formatted context
    context: str = ""
    context_chars: int = 0
    
    def get_all_content(self) -> list[str]:
        """Get all retrieved content as strings."""
        content = []
        
        for theme, _ in self.themes:
            content.append(theme.summary)
        
        for unit, _ in self.semantics:
            content.append(unit.content)
        
        for ep, _ in self.episodes:
            content.append(ep.summary)
        
        return content


class HierarchicalRetriever:
    """
    Top-down hierarchical retriever for xMemory.
    
    Retrieves relevant context by:
    1. Finding matching themes
    2. Expanding to semantics if uncertain
    3. Grounding in episodes if needed
    """
    
    def __init__(
        self,
        theme_manager: ThemeManager,
        semantic_memory: SemanticMemory,
        episodic_memory: EpisodicMemory | None = None,
        config: RetrieverConfig | None = None,
    ):
        """
        Initialize retriever.
        
        Args:
            theme_manager: Theme manager for L3 retrieval.
            semantic_memory: Semantic memory for L2 retrieval.
            episodic_memory: Optional episodic memory for L1 grounding.
            config: Retrieval configuration.
        """
        self.theme_manager = theme_manager
        self.semantic_memory = semantic_memory
        self.episodic_memory = episodic_memory
        self.config = config or RetrieverConfig()
        
        # Embedding function (set externally)
        self._embed_fn: Callable[[str], np.ndarray] | None = None
        
        # Store last retrieval result for deduplication purposes
        self._last_result: RetrievalResult | None = None
    
    def set_embedding_function(self, fn: Callable[[str], np.ndarray]) -> None:
        """Set the embedding function."""
        self._embed_fn = fn
    
    def retrieve(
        self,
        query: str,
        force_expand: bool = False,
    ) -> RetrievalResult:
        """
        Retrieve relevant context for a query.
        
        Args:
            query: Query string.
            force_expand: Force expansion to semantics/episodes.
            
        Returns:
            RetrievalResult with retrieved content.
        """
        result = RetrievalResult()
        
        # Get query embedding
        if not self._embed_fn:
            logger.warning("Embedding function not set")
            return result
        
        try:
            query_embedding = self._embed_fn(query)
        except Exception as e:
            logger.error(f"Query embedding failed: {e}")
            return result
        
        # Phase 1: Retrieve themes (L3)
        result.themes = self._retrieve_themes(query_embedding)
        result.theme_uncertainty = self._compute_uncertainty(
            [sim for _, sim in result.themes]
        )
        
        # Check if expansion needed
        should_expand = (
            force_expand or
            result.theme_uncertainty > self.config.theme_uncertainty_threshold or
            len(result.themes) == 0
        )
        
        # Phase 2: Expand to semantics (L2) if needed
        if should_expand:
            result.expanded_to_semantics = True
            result.semantics = self._retrieve_semantics(
                query_embedding,
                result.themes,
            )
            result.semantic_uncertainty = self._compute_uncertainty(
                [sim for _, sim in result.semantics]
            )
            
            # Phase 3: Ground in episodes (L1) if still uncertain
            if (
                result.semantic_uncertainty > self.config.semantic_uncertainty_threshold
                and self.episodic_memory
            ):
                result.expanded_to_episodes = True
                result.episodes = self._retrieve_episodes(
                    query_embedding,
                    result.semantics,
                )
        
        # Format context
        result.context = self._format_context(result)
        result.context_chars = len(result.context)
        
        # Store for deduplication
        self._last_result = result
        
        return result
    
    def _retrieve_themes(
        self,
        query_embedding: np.ndarray,
    ) -> list[tuple[ThemeNode, float]]:
        """Retrieve themes matching the query."""
        themes = self.theme_manager.search_themes(
            query_embedding,
            top_k=self.config.top_k_themes,
        )
        
        # Filter by threshold
        return [
            (t, sim) for t, sim in themes
            if sim >= self.config.theme_similarity_threshold
        ]
    
    def _retrieve_semantics(
        self,
        query_embedding: np.ndarray,
        themes: list[tuple[ThemeNode, float]],
    ) -> list[tuple[SemanticUnit, float]]:
        """
        Retrieve semantics from matched themes.
        
        Uses theme membership to guide retrieval, but also
        considers direct query similarity.
        """
        semantics: list[tuple[SemanticUnit, float]] = []
        seen_ids: set[str] = set()
        
        # First, get semantics from matched themes
        for theme, theme_sim in themes:
            for sem_id in theme.semantic_ids[:self.config.top_k_semantics_per_theme]:
                if sem_id in seen_ids:
                    continue
                
                unit = self.semantic_memory.get_unit(sem_id)
                if not unit or unit.embedding is None:
                    continue
                
                # Compute direct similarity to query
                sim = self._cosine_similarity(query_embedding, unit.embedding)
                
                if sim >= self.config.semantic_similarity_threshold:
                    semantics.append((unit, sim))
                    seen_ids.add(sem_id)
        
        # Also do direct semantic search for unthemed or missed units
        direct_results = self.semantic_memory.search_by_embedding(
            query_embedding,
            top_k=self.config.top_k_semantics_per_theme * 2,
        )
        
        for unit, sim in direct_results:
            if unit.id in seen_ids:
                continue
            if sim >= self.config.semantic_similarity_threshold:
                semantics.append((unit, sim))
                seen_ids.add(unit.id)
        
        # Sort by similarity
        semantics.sort(key=lambda x: x[1], reverse=True)
        
        # Limit total
        max_semantics = self.config.top_k_themes * self.config.top_k_semantics_per_theme
        return semantics[:max_semantics]
    
    def _retrieve_episodes(
        self,
        query_embedding: np.ndarray,
        semantics: list[tuple[SemanticUnit, float]],
    ) -> list[tuple[Episode, float]]:
        """
        Retrieve episodes that ground the semantics.
        
        Uses semantic source tracking and direct similarity.
        """
        if not self.episodic_memory:
            return []
        
        episodes: list[tuple[Episode, float]] = []
        seen_ids: set[str] = set()
        
        # Get episodes referenced by semantics
        for unit, _ in semantics:
            for ep_id in unit.source_episode_ids:
                if ep_id in seen_ids:
                    continue
                
                # Find episode (simple linear search)
                for ep in self.episodic_memory.get_all_episodes():
                    if ep.id == ep_id:
                        # Compute relevance (use task description)
                        # For now, use a fixed score based on semantic relevance
                        episodes.append((ep, 0.7))
                        seen_ids.add(ep_id)
                        break
        
        # Limit total
        episodes = episodes[:self.config.top_k_episodes]
        
        return episodes
    
    def _compute_uncertainty(self, similarities: list[float]) -> float:
        """
        Compute uncertainty from similarity distribution.
        
        Uses entropy-based measure:
        - Low entropy (one dominant) = low uncertainty
        - High entropy (uniform) = high uncertainty
        """
        if not similarities:
            return 1.0  # Maximum uncertainty if nothing found
        
        if len(similarities) == 1:
            # Single result: uncertainty based on confidence
            return 1.0 - similarities[0]
        
        # Normalize to probabilities
        sims = np.array(similarities)
        sims = np.clip(sims, 0.01, 1.0)  # Avoid zeros
        probs = sims / sims.sum()
        
        # Compute entropy
        entropy = -np.sum(probs * np.log(probs + 1e-10))
        
        # Normalize by max entropy
        max_entropy = np.log(len(probs))
        normalized_entropy = entropy / max_entropy if max_entropy > 0 else 0
        
        return float(normalized_entropy)
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Compute cosine similarity."""
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a < 1e-9 or norm_b < 1e-9:
            return 0.0
        return float(np.dot(a, b) / (norm_a * norm_b))
    
    def _format_context(self, result: RetrievalResult) -> str:
        """
        Format retrieved content into context string.
        
        Respects token budget while maximizing information.
        """
        lines: list[str] = []
        current_chars = 0
        max_chars = self.config.max_context_chars
        
        # Format based on retrieval depth
        if result.expanded_to_episodes:
            header = "[Retrieved Context: Episodes + Semantics + Themes]"
        elif result.expanded_to_semantics:
            header = "[Retrieved Context: Semantics + Themes]"
        else:
            header = "[Retrieved Context: Themes]"
        
        lines.append(header)
        lines.append("")
        current_chars = len(header) + 2
        
        # Add themes
        if result.themes:
            lines.append("## Themes")
            current_chars += 10
            
            for theme, sim in result.themes:
                if current_chars >= max_chars:
                    break
                
                theme_line = f"- [{sim:.2f}] {theme.summary}"
                if current_chars + len(theme_line) > max_chars:
                    break
                
                lines.append(theme_line)
                current_chars += len(theme_line) + 1
            
            lines.append("")
        
        # Add semantics (if expanded)
        if result.expanded_to_semantics and result.semantics:
            lines.append("## Knowledge")
            current_chars += 12
            
            for unit, sim in result.semantics:
                if current_chars >= max_chars:
                    break
                
                # Truncate if needed
                content = unit.content
                remaining = max_chars - current_chars - 20
                if len(content) > remaining:
                    content = content[:remaining] + "..."
                
                sem_line = f"- [{sim:.2f}] {content}"
                lines.append(sem_line)
                current_chars += len(sem_line) + 1
            
            lines.append("")
        
        # Add episodes (if expanded)
        if result.expanded_to_episodes and result.episodes:
            lines.append("## Related Tasks")
            current_chars += 15
            
            for ep, sim in result.episodes:
                if current_chars >= max_chars:
                    break
                
                ep_lines = [
                    f"- Task: {ep.task_description[:100]}",
                    f"  Outcome: {ep.summary[:150]}",
                ]
                ep_text = "\n".join(ep_lines)
                
                if current_chars + len(ep_text) > max_chars:
                    break
                
                lines.extend(ep_lines)
                current_chars += len(ep_text) + 2
        
        return "\n".join(lines)
    
    def retrieve_for_task(
        self,
        task: str,
        tech_hints: list[str] | None = None,
    ) -> RetrievalResult:
        """
        Retrieve context optimized for a coding task.
        
        Args:
            task: Task description.
            tech_hints: Optional technology hints.
            
        Returns:
            RetrievalResult with context.
        """
        # Build enhanced query
        query = task
        if tech_hints:
            query = f"{task} (technologies: {', '.join(tech_hints)})"
        
        return self.retrieve(query)
    
    def get_quick_context(
        self,
        query: str,
        max_themes: int = 3,
    ) -> str:
        """
        Get quick context using only theme summaries.
        
        Useful when token budget is very limited.
        """
        if not self._embed_fn:
            return ""
        
        try:
            query_embedding = self._embed_fn(query)
        except Exception:
            return ""
        
        themes = self.theme_manager.search_themes(
            query_embedding,
            top_k=max_themes,
        )
        
        if not themes:
            return ""
        
        lines = ["[Quick Context]"]
        for theme, sim in themes:
            if sim >= self.config.theme_similarity_threshold:
                lines.append(f"- {theme.summary}")
        
        return "\n".join(lines) if len(lines) > 1 else ""


class AdaptiveRetriever(HierarchicalRetriever):
    """
    Adaptive retriever that learns optimal retrieval depth.
    
    Tracks which retrieval depth works best for different
    query types and adjusts thresholds accordingly.
    """
    
    def __init__(
        self,
        theme_manager: ThemeManager,
        semantic_memory: SemanticMemory,
        episodic_memory: EpisodicMemory | None = None,
        config: RetrieverConfig | None = None,
    ):
        super().__init__(theme_manager, semantic_memory, episodic_memory, config)
        
        # Tracking for adaptation
        self._retrieval_outcomes: list[dict[str, Any]] = []
        self._max_tracked: int = 100
    
    def record_outcome(
        self,
        result: RetrievalResult,
        was_helpful: bool,
        query_type: str = "general",
    ) -> None:
        """
        Record retrieval outcome for learning.
        
        Args:
            result: The retrieval result.
            was_helpful: Whether the retrieval helped.
            query_type: Type of query (debug, implement, etc.).
        """
        outcome = {
            "query_type": query_type,
            "expanded_semantics": result.expanded_to_semantics,
            "expanded_episodes": result.expanded_to_episodes,
            "theme_uncertainty": result.theme_uncertainty,
            "semantic_uncertainty": result.semantic_uncertainty,
            "num_themes": len(result.themes),
            "num_semantics": len(result.semantics),
            "num_episodes": len(result.episodes),
            "was_helpful": was_helpful,
        }
        
        self._retrieval_outcomes.append(outcome)
        
        # Prune old outcomes
        if len(self._retrieval_outcomes) > self._max_tracked:
            self._retrieval_outcomes = self._retrieval_outcomes[-self._max_tracked:]
    
    def get_recommended_config(
        self,
        query_type: str = "general",
    ) -> RetrieverConfig:
        """
        Get recommended config based on past outcomes.
        
        Args:
            query_type: Type of query.
            
        Returns:
            Optimized RetrieverConfig.
        """
        # Filter to relevant outcomes
        relevant = [
            o for o in self._retrieval_outcomes
            if o["query_type"] == query_type and o["was_helpful"]
        ]
        
        if len(relevant) < 5:
            return self.config
        
        # Compute average successful parameters
        avg_theme_uncertainty = np.mean([o["theme_uncertainty"] for o in relevant])
        avg_semantic_uncertainty = np.mean([o["semantic_uncertainty"] for o in relevant])
        
        # Adjust thresholds
        new_config = RetrieverConfig(
            top_k_themes=self.config.top_k_themes,
            theme_similarity_threshold=self.config.theme_similarity_threshold,
            top_k_semantics_per_theme=self.config.top_k_semantics_per_theme,
            semantic_similarity_threshold=self.config.semantic_similarity_threshold,
            top_k_episodes=self.config.top_k_episodes,
            episode_similarity_threshold=self.config.episode_similarity_threshold,
            theme_uncertainty_threshold=float(avg_theme_uncertainty + 0.1),
            semantic_uncertainty_threshold=float(avg_semantic_uncertainty + 0.1),
            max_context_chars=self.config.max_context_chars,
        )
        
        return new_config
