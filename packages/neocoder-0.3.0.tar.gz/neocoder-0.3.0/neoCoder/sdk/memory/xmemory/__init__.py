"""
xMemory - Hierarchical Memory System for neoCoder.

Implements the "Beyond RAG" approach from the xMemory paper:
- 4-level hierarchy: Messages → Episodes → Semantics → Themes
- Sparsity-Semantics scoring for consolidation
- Top-down retrieval with uncertainty-driven expansion
- Automatic split/merge of themes based on cohesion

Key components:
- SemanticMemory: Factual knowledge extracted from episodes (L2)
- ThemeManager: High-level theme organization (L3)
- HierarchicalRetriever: Top-down retrieval with expansion
- ConsolidationEngine: Split/merge optimization
- XMemoryIntegration: Bridge with CognitiveMemoryManager

Usage:
    from neoCoder.sdk.memory.xmemory import (
        XMemoryIntegration,
        create_xmemory_integration,
    )
    
    # Create integration
    xmem = create_xmemory_integration(
        episodic_memory=episodic,
        llm_call=my_llm_fn,
        embed_fn=my_embed_fn,
    )
    
    # Process episodes
    xmem.process_episode(episode)
    
    # Retrieve context
    context = xmem.retrieve_context("implement auth system")
"""

from neoCoder.sdk.memory.xmemory.semantic import (
    SemanticMemory,
    SemanticMemoryConfig,
    SemanticUnit,
    KnowledgeType,
)
from neoCoder.sdk.memory.xmemory.themes import (
    ThemeNode,
    ThemeManager,
    ThemeManagerConfig,
)
from neoCoder.sdk.memory.xmemory.retriever import (
    HierarchicalRetriever,
    AdaptiveRetriever,
    RetrieverConfig,
    RetrievalResult,
)
from neoCoder.sdk.memory.xmemory.consolidation import (
    ConsolidationEngine,
    ConsolidationConfig,
    ConsolidationResult,
    build_semantic_extraction_prompt,
    build_theme_summary_prompt,
)
from neoCoder.sdk.memory.xmemory.scoring import (
    SparsitySemanticsScorer,
    ScoringConfig,
)
from neoCoder.sdk.memory.xmemory.integration import (
    XMemoryIntegration,
    XMemoryConfig,
    create_xmemory_integration,
)

__all__ = [
    # Semantic Memory (L2)
    "SemanticMemory",
    "SemanticMemoryConfig",
    "SemanticUnit",
    "KnowledgeType",
    # Themes (L3)
    "ThemeNode",
    "ThemeManager",
    "ThemeManagerConfig",
    # Retrieval
    "HierarchicalRetriever",
    "AdaptiveRetriever",
    "RetrieverConfig",
    "RetrievalResult",
    # Consolidation
    "ConsolidationEngine",
    "ConsolidationConfig",
    "ConsolidationResult",
    "build_semantic_extraction_prompt",
    "build_theme_summary_prompt",
    # Scoring
    "SparsitySemanticsScorer",
    "ScoringConfig",
    # Integration
    "XMemoryIntegration",
    "XMemoryConfig",
    "create_xmemory_integration",
]
