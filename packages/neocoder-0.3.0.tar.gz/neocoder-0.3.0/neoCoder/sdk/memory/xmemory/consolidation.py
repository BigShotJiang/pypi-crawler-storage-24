"""
Consolidation Engine for xMemory.

Orchestrates the full consolidation pipeline:
1. Extract semantics from new episodes
2. Assimilate semantics into themes (attachment)
3. Accommodate: split oversized/heterogeneous themes
4. Merge similar themes
5. Absorb micro-themes

Uses SparsitySemanticsScorer to guide decisions.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from neoCoder.sdk.memory.xmemory.semantic import (
    SemanticMemory,
    SemanticMemoryConfig,
    SemanticUnit,
    KnowledgeType,
)
from neoCoder.sdk.memory.xmemory.themes import (
    ThemeManager,
    ThemeManagerConfig,
    ThemeNode,
)
from neoCoder.sdk.memory.xmemory.scoring import (
    SparsitySemanticsScorer,
    ScoringConfig,
)
from neoCoder.sdk.memory.episodic import Episode

logger = logging.getLogger(__name__)


@dataclass
class ConsolidationConfig:
    """Configuration for consolidation engine."""
    
    # Semantic memory config
    semantic_config: SemanticMemoryConfig = field(
        default_factory=SemanticMemoryConfig
    )
    
    # Theme manager config
    theme_config: ThemeManagerConfig = field(
        default_factory=ThemeManagerConfig
    )
    
    # Scoring config
    scoring_config: ScoringConfig = field(
        default_factory=ScoringConfig
    )
    
    # Consolidation behavior
    auto_consolidate: bool = True
    consolidate_every_n_episodes: int = 1
    min_episodes_for_extraction: int = 1
    
    # Quality thresholds
    min_quality_score: float = 0.4


@dataclass
class ConsolidationResult:
    """Result of a consolidation operation."""
    
    success: bool
    
    # Statistics
    semantics_extracted: int = 0
    semantics_attached: int = 0
    themes_created: int = 0
    themes_split: int = 0
    themes_merged: int = 0
    themes_absorbed: int = 0
    
    # Quality metrics
    quality_before: float = 0.0
    quality_after: float = 0.0
    
    # Error info
    error: str | None = None


class ConsolidationEngine:
    """
    Central engine for xMemory consolidation.
    
    Coordinates semantic extraction, theme management,
    and quality-driven consolidation operations.
    """
    
    def __init__(self, config: ConsolidationConfig | None = None):
        """
        Initialize consolidation engine.
        
        Args:
            config: Engine configuration.
        """
        self.config = config or ConsolidationConfig()
        
        # Initialize components
        self._semantic_memory = SemanticMemory(self.config.semantic_config)
        self._theme_manager = ThemeManager(
            self._semantic_memory,
            self.config.theme_config,
        )
        self._scorer = SparsitySemanticsScorer(
            self._semantic_memory,
            self.config.scoring_config,
        )
        
        # Episode tracking
        self._episodes_since_consolidation: int = 0
        self._processed_episode_ids: set[str] = set()
        
        # External functions (set by user)
        self._embed_fn: Callable[[str], np.ndarray] | None = None
        self._extract_fn: Callable[[str], list[dict[str, Any]]] | None = None
        self._summarize_fn: Callable[[list[str]], str] | None = None
    
    @property
    def semantic_memory(self) -> SemanticMemory:
        """Access semantic memory."""
        return self._semantic_memory
    
    @property
    def theme_manager(self) -> ThemeManager:
        """Access theme manager."""
        return self._theme_manager
    
    @property
    def scorer(self) -> SparsitySemanticsScorer:
        """Access scorer."""
        return self._scorer
    
    def set_embedding_function(self, fn: Callable[[str], np.ndarray]) -> None:
        """Set the embedding function for all components."""
        self._embed_fn = fn
        self._semantic_memory.set_embedding_function(fn)
        self._theme_manager.set_embedding_function(fn)
    
    def set_extraction_function(
        self,
        fn: Callable[[str], list[dict[str, Any]]],
    ) -> None:
        """
        Set the LLM-based semantic extraction function.
        
        Function should take episode content and return:
        [{"content": str, "knowledge_type": str, "keywords": list[str]}]
        """
        self._extract_fn = fn
        self._semantic_memory.set_extraction_function(fn)
    
    def set_summarize_function(
        self,
        fn: Callable[[list[str]], str],
    ) -> None:
        """Set the LLM-based summarization function."""
        self._summarize_fn = fn
        self._theme_manager.set_summarize_function(fn)
    
    def process_episode(self, episode: Episode) -> ConsolidationResult:
        """
        Process a new episode through the consolidation pipeline.
        
        Args:
            episode: Episode to process.
            
        Returns:
            ConsolidationResult with statistics.
        """
        # Skip if already processed
        if episode.id in self._processed_episode_ids:
            return ConsolidationResult(
                success=True,
                error="Episode already processed",
            )
        
        try:
            # Get quality before
            quality_before = self._get_current_quality()
            
            # Build episode content for extraction
            episode_content = self._build_episode_content(episode)
            
            # Extract semantics
            new_units = self._semantic_memory.extract_from_episode(
                episode.id,
                episode_content,
            )
            
            self._processed_episode_ids.add(episode.id)
            self._episodes_since_consolidation += 1
            
            result = ConsolidationResult(
                success=True,
                semantics_extracted=len(new_units),
                quality_before=quality_before,
            )
            
            # Run consolidation if needed
            if self._should_consolidate():
                consolidation_stats = self._run_consolidation(
                    [u.id for u in new_units]
                )
                result.semantics_attached = consolidation_stats.get("attached", 0)
                result.themes_created = consolidation_stats.get("created", 0)
                result.themes_split = consolidation_stats.get("split", 0)
                result.themes_merged = consolidation_stats.get("merged", 0)
                result.themes_absorbed = consolidation_stats.get("absorbed", 0)
            
            result.quality_after = self._get_current_quality()
            
            logger.info(
                f"Processed episode {episode.id}: "
                f"{result.semantics_extracted} semantics, "
                f"quality {result.quality_before:.2f} → {result.quality_after:.2f}"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Episode processing failed: {e}")
            return ConsolidationResult(
                success=False,
                error=str(e),
            )
    
    def _build_episode_content(self, episode: Episode) -> str:
        """Build content string from episode for extraction."""
        lines = [
            f"Task: {episode.task_description}",
            "",
            f"Summary: {episode.summary}",
        ]
        
        if episode.files_touched:
            lines.append("")
            lines.append(f"Files: {', '.join(episode.files_touched[:10])}")
        
        if episode.key_decisions:
            lines.append("")
            lines.append("Key decisions:")
            for decision in episode.key_decisions[:5]:
                lines.append(f"- {decision}")
        
        if episode.errors_fixed:
            lines.append("")
            lines.append("Errors fixed:")
            for error in episode.errors_fixed[:5]:
                lines.append(f"- {error}")
        
        return "\n".join(lines)
    
    def _should_consolidate(self) -> bool:
        """Check if consolidation should run."""
        if not self.config.auto_consolidate:
            return False
        
        return (
            self._episodes_since_consolidation >=
            self.config.consolidate_every_n_episodes
        )
    
    def _run_consolidation(
        self,
        new_semantic_ids: list[str],
    ) -> dict[str, int]:
        """Run full consolidation pipeline."""
        stats = self._theme_manager.consolidate(new_semantic_ids)
        self._episodes_since_consolidation = 0
        
        # Flatten nested stats
        flat_stats = {}
        if "assimilation" in stats:
            flat_stats.update(stats["assimilation"])
        if "accommodation" in stats:
            flat_stats.update(stats["accommodation"])
        
        return flat_stats
    
    def _get_current_quality(self) -> float:
        """Get current memory quality score."""
        themes = self._theme_manager.get_all_themes()
        if not themes:
            return 0.0
        
        metrics = self._scorer.get_memory_quality_score(themes)
        return metrics["overall"]
    
    def force_consolidation(self) -> ConsolidationResult:
        """
        Force a full consolidation run.
        
        Useful for periodic maintenance or manual triggers.
        """
        try:
            quality_before = self._get_current_quality()
            
            # Get all unassigned semantics
            unassigned = self._semantic_memory.get_unassigned_units()
            unassigned_ids = [u.id for u in unassigned]
            
            # Run consolidation
            stats = self._run_consolidation(unassigned_ids)
            
            quality_after = self._get_current_quality()
            
            return ConsolidationResult(
                success=True,
                semantics_attached=stats.get("attached", 0),
                themes_created=stats.get("created", 0),
                themes_split=stats.get("split", 0),
                themes_merged=stats.get("merged", 0),
                themes_absorbed=stats.get("absorbed", 0),
                quality_before=quality_before,
                quality_after=quality_after,
            )
            
        except Exception as e:
            logger.error(f"Forced consolidation failed: {e}")
            return ConsolidationResult(
                success=False,
                error=str(e),
            )
    
    def add_semantic_unit(
        self,
        content: str,
        knowledge_type: KnowledgeType,
        source_episode_id: str | None = None,
        keywords: list[str] | None = None,
    ) -> SemanticUnit | None:
        """
        Manually add a semantic unit.
        
        Args:
            content: Content text.
            knowledge_type: Type of knowledge.
            source_episode_id: Optional source episode.
            keywords: Optional keywords.
            
        Returns:
            Created SemanticUnit or None if duplicate.
        """
        import uuid
        
        # Generate embedding
        embedding = None
        if self._embed_fn:
            try:
                embedding = self._embed_fn(content)
            except Exception as e:
                logger.warning(f"Embedding generation failed: {e}")
        
        unit = SemanticUnit(
            id=f"sem_{uuid.uuid4().hex[:12]}",
            content=content,
            knowledge_type=knowledge_type,
            source_episode_ids=[source_episode_id] if source_episode_id else [],
            embedding=embedding,
            keywords=keywords or [],
        )
        
        if self._semantic_memory.add_unit(unit):
            # Auto-consolidate if enabled
            if self.config.auto_consolidate:
                self._theme_manager.assimilate_semantics([unit.id])
            return unit
        
        return None
    
    def get_stats(self) -> dict[str, Any]:
        """Get comprehensive statistics."""
        semantic_stats = self._semantic_memory.get_stats()
        theme_stats = self._theme_manager.get_stats()
        quality = self._scorer.get_memory_quality_score(
            self._theme_manager.get_all_themes()
        )
        
        return {
            "semantic_memory": semantic_stats,
            "themes": theme_stats,
            "quality": quality,
            "processed_episodes": len(self._processed_episode_ids),
        }
    
    def clear(self) -> None:
        """Clear all memory."""
        self._semantic_memory.clear()
        self._theme_manager.clear()
        self._processed_episode_ids.clear()
        self._episodes_since_consolidation = 0
    
    def to_dict(self) -> dict[str, Any]:
        """Serialize state to dictionary."""
        return {
            "semantic_memory": self._semantic_memory.to_dict(),
            "themes": self._theme_manager.to_dict(),
            "processed_episode_ids": list(self._processed_episode_ids),
        }
    
    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        config: ConsolidationConfig | None = None,
    ) -> ConsolidationEngine:
        """Deserialize from dictionary."""
        engine = cls(config)
        
        if "semantic_memory" in data:
            engine._semantic_memory = SemanticMemory.from_dict(
                data["semantic_memory"],
                config.semantic_config if config else None,
            )
            engine._theme_manager = ThemeManager(
                engine._semantic_memory,
                config.theme_config if config else None,
            )
        
        if "themes" in data:
            engine._theme_manager = ThemeManager.from_dict(
                data["themes"],
                engine._semantic_memory,
                config.theme_config if config else None,
            )
        
        engine._processed_episode_ids = set(
            data.get("processed_episode_ids", [])
        )
        
        return engine


# Utility function for creating extraction prompts
def build_semantic_extraction_prompt(episode_content: str) -> str:
    """
    Build LLM prompt for semantic extraction.
    
    This can be used with any LLM to extract semantic units.
    
    Args:
        episode_content: Episode content to extract from.
        
    Returns:
        Prompt string for LLM.
    """
    return f"""Analyze this task episode and extract discrete knowledge units.

Episode:
{episode_content}

---

Extract semantic knowledge units from this episode. Each unit should be:
- A self-contained piece of knowledge
- Factual, procedural, or conceptual
- Reusable for future similar tasks

Respond in this EXACT format (one or more units):

```
UNIT_1:
CONTENT: <the knowledge statement>
TYPE: <factual|procedural|conceptual|contextual|preference>
KEYWORDS: <comma-separated keywords>
CONFIDENCE: <0.0 to 1.0>

UNIT_2:
CONTENT: <another knowledge statement>
TYPE: <type>
KEYWORDS: <keywords>
CONFIDENCE: <confidence>
```

Focus on:
- Technical facts learned
- Patterns and best practices identified
- Project-specific conventions discovered
- Problem-solving approaches that worked

Extract 1-5 units from this episode.
"""


def build_theme_summary_prompt(semantic_contents: list[str]) -> str:
    """
    Build LLM prompt for generating theme summary.
    
    Args:
        semantic_contents: Contents of semantic units in the theme.
        
    Returns:
        Prompt string for LLM.
    """
    contents_text = "\n\n".join(
        f"- {content}" for content in semantic_contents[:10]
    )
    
    return f"""Summarize these related knowledge units into a single high-level theme.

Knowledge units:
{contents_text}

---

Write a concise summary (1-2 sentences) that captures the common theme.
The summary should:
- Be general enough to encompass all units
- Be specific enough to be useful for retrieval
- Focus on the main concept or pattern

Respond with ONLY the summary, nothing else.
"""
