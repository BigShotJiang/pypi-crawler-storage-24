"""
xMemory Integration with CognitiveMemoryManager.

Provides seamless integration of xMemory's hierarchical
retrieval into the existing cognitive memory architecture.

This module acts as a bridge, allowing gradual adoption:
- xMemory can run alongside existing episodic/procedural memory
- Retrieval can use both systems and merge results
- Migration path from legacy to xMemory
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from neoCoder.sdk.memory.xmemory.semantic import (
    SemanticMemory,
    SemanticMemoryConfig,
    SemanticUnit,
    KnowledgeType,
)
from neoCoder.sdk.memory.xmemory.themes import (
    ThemeManager,
    ThemeManagerConfig,
    ThemeNode,
)
from neoCoder.sdk.memory.xmemory.retriever import (
    HierarchicalRetriever,
    RetrieverConfig,
    RetrievalResult,
)
from neoCoder.sdk.memory.xmemory.consolidation import (
    ConsolidationEngine,
    ConsolidationConfig,
    ConsolidationResult,
    build_semantic_extraction_prompt,
    build_theme_summary_prompt,
)
from neoCoder.sdk.memory.xmemory.scoring import (
    SparsitySemanticsScorer,
    ScoringConfig,
)
from neoCoder.sdk.memory.episodic import Episode, EpisodicMemory

logger = logging.getLogger(__name__)


@dataclass
class XMemoryConfig:
    """Unified configuration for xMemory integration."""
    
    # Enable/disable xMemory
    enabled: bool = True
    
    # Component configs
    consolidation_config: ConsolidationConfig = field(
        default_factory=ConsolidationConfig
    )
    retriever_config: RetrieverConfig = field(
        default_factory=RetrieverConfig
    )
    
    # Integration behavior
    use_xmemory_retrieval: bool = True      # Use xMemory for retrieval
    use_legacy_retrieval: bool = True       # Also use episodic/procedural
    merge_retrieval_results: bool = True    # Merge both systems' results
    
    # Context injection
    inject_xmemory_context: bool = True
    max_xmemory_context_chars: int = 2000


class XMemoryIntegration:
    """
    Integration layer for xMemory with CognitiveMemoryManager.
    
    Provides:
    - Automatic processing of episodes through xMemory
    - Hierarchical retrieval for task context
    - Quality-aware consolidation
    - Migration utilities
    """
    
    def __init__(
        self,
        episodic_memory: EpisodicMemory | None = None,
        config: XMemoryConfig | None = None,
    ):
        """
        Initialize xMemory integration.
        
        Args:
            episodic_memory: Existing episodic memory (for L1 grounding).
            config: Integration configuration.
        """
        self.config = config or XMemoryConfig()
        self._episodic_memory = episodic_memory
        
        # Initialize xMemory components
        self._consolidation = ConsolidationEngine(self.config.consolidation_config)
        self._retriever = HierarchicalRetriever(
            self._consolidation.theme_manager,
            self._consolidation.semantic_memory,
            episodic_memory,
            self.config.retriever_config,
        )
        
        # LLM functions (set externally)
        self._llm_call: Callable[[str], str] | None = None
        self._embed_fn: Callable[[str], np.ndarray] | None = None
    
    @property
    def semantic_memory(self) -> SemanticMemory:
        """Access semantic memory."""
        return self._consolidation.semantic_memory
    
    @property
    def theme_manager(self) -> ThemeManager:
        """Access theme manager."""
        return self._consolidation.theme_manager
    
    @property
    def retriever(self) -> HierarchicalRetriever:
        """Access retriever."""
        return self._retriever
    
    @property
    def consolidation(self) -> ConsolidationEngine:
        """Access consolidation engine."""
        return self._consolidation
    
    def configure_llm(
        self,
        llm_call: Callable[[str], str],
        embed_fn: Callable[[str], np.ndarray],
    ) -> None:
        """
        Configure LLM functions for xMemory.
        
        Args:
            llm_call: Function that takes prompt and returns LLM response.
            embed_fn: Function that takes text and returns embedding vector.
        """
        self._llm_call = llm_call
        self._embed_fn = embed_fn
        
        # Configure extraction function
        def extract_semantics(content: str) -> list[dict[str, Any]]:
            prompt = build_semantic_extraction_prompt(content)
            response = llm_call(prompt)
            return self._parse_extraction_response(response)
        
        # Configure summarize function
        def summarize_semantics(contents: list[str]) -> str:
            prompt = build_theme_summary_prompt(contents)
            response = llm_call(prompt)
            return response.strip()[:200]
        
        # Set functions on components
        self._consolidation.set_embedding_function(embed_fn)
        self._consolidation.set_extraction_function(extract_semantics)
        self._consolidation.set_summarize_function(summarize_semantics)
        self._retriever.set_embedding_function(embed_fn)
    
    def _parse_extraction_response(
        self,
        response: str,
    ) -> list[dict[str, Any]]:
        """Parse LLM extraction response into semantic units."""
        units = []
        
        # Split by UNIT markers
        unit_blocks = re.split(r'UNIT_\d+:', response)
        
        for block in unit_blocks[1:]:  # Skip first empty part
            unit = {}
            
            # Extract content
            content_match = re.search(r'CONTENT:\s*(.+?)(?=TYPE:|$)', block, re.DOTALL)
            if content_match:
                unit["content"] = content_match.group(1).strip()
            
            # Extract type
            type_match = re.search(r'TYPE:\s*(\w+)', block)
            if type_match:
                unit["knowledge_type"] = type_match.group(1).lower()
            
            # Extract keywords
            keywords_match = re.search(r'KEYWORDS:\s*(.+?)(?=CONFIDENCE:|$)', block)
            if keywords_match:
                keywords_str = keywords_match.group(1).strip()
                unit["keywords"] = [k.strip() for k in keywords_str.split(",")]
            
            # Extract confidence
            conf_match = re.search(r'CONFIDENCE:\s*([\d.]+)', block)
            if conf_match:
                try:
                    unit["confidence"] = float(conf_match.group(1))
                except ValueError:
                    unit["confidence"] = 1.0
            
            if unit.get("content"):
                units.append(unit)
        
        return units
    
    def process_episode(self, episode: Episode) -> ConsolidationResult:
        """
        Process an episode through xMemory consolidation.
        
        Args:
            episode: Episode to process.
            
        Returns:
            ConsolidationResult with statistics.
        """
        if not self.config.enabled:
            return ConsolidationResult(success=True, error="xMemory disabled")
        
        return self._consolidation.process_episode(episode)
    
    def retrieve_context(
        self,
        query: str,
        tech_hints: list[str] | None = None,
    ) -> str:
        """
        Retrieve context using xMemory hierarchical retrieval.
        
        Args:
            query: Query/task description.
            tech_hints: Optional technology hints.
            
        Returns:
            Formatted context string.
        """
        if not self.config.enabled or not self.config.use_xmemory_retrieval:
            return ""
        
        result = self._retriever.retrieve_for_task(query, tech_hints)
        
        # Truncate if needed
        context = result.context
        if len(context) > self.config.max_xmemory_context_chars:
            context = context[:self.config.max_xmemory_context_chars] + "\n..."
        
        return context
    
    def get_combined_context(
        self,
        query: str,
        legacy_context: str | None = None,
        tech_hints: list[str] | None = None,
    ) -> str:
        """
        Get combined context from xMemory and legacy systems.
        
        Args:
            query: Query/task description.
            legacy_context: Context from episodic/procedural memory.
            tech_hints: Optional technology hints.
            
        Returns:
            Merged context string.
        """
        contexts = []
        
        # Get xMemory context
        if self.config.use_xmemory_retrieval:
            xmem_context = self.retrieve_context(query, tech_hints)
            if xmem_context:
                contexts.append(xmem_context)
        
        # Add legacy context
        if self.config.use_legacy_retrieval and legacy_context:
            contexts.append(legacy_context)
        
        if not contexts:
            return ""
        
        if len(contexts) == 1:
            return contexts[0]
        
        # Merge with deduplication header
        return "\n\n---\n\n".join(contexts)
    
    def migrate_from_episodic(
        self,
        episodes: list[Episode],
        batch_size: int = 10,
    ) -> dict[str, int]:
        """
        Migrate existing episodes to xMemory.
        
        Args:
            episodes: Episodes to migrate.
            batch_size: Process in batches.
            
        Returns:
            Migration statistics.
        """
        stats = {
            "processed": 0,
            "semantics_extracted": 0,
            "themes_created": 0,
            "errors": 0,
        }
        
        for i in range(0, len(episodes), batch_size):
            batch = episodes[i:i + batch_size]
            
            for episode in batch:
                result = self.process_episode(episode)
                
                if result.success:
                    stats["processed"] += 1
                    stats["semantics_extracted"] += result.semantics_extracted
                    stats["themes_created"] += result.themes_created
                else:
                    stats["errors"] += 1
            
            # Force consolidation after batch
            self._consolidation.force_consolidation()
        
        logger.info(
            f"Migration complete: {stats['processed']} episodes, "
            f"{stats['semantics_extracted']} semantics, "
            f"{stats['themes_created']} themes"
        )
        
        return stats
    
    def add_knowledge(
        self,
        content: str,
        knowledge_type: str = "factual",
        keywords: list[str] | None = None,
    ) -> SemanticUnit | None:
        """
        Manually add knowledge to xMemory.
        
        Args:
            content: Knowledge content.
            knowledge_type: Type (factual, procedural, etc.).
            keywords: Optional keywords.
            
        Returns:
            Created SemanticUnit or None.
        """
        try:
            kt = KnowledgeType(knowledge_type.lower())
        except ValueError:
            kt = KnowledgeType.FACTUAL
        
        return self._consolidation.add_semantic_unit(
            content=content,
            knowledge_type=kt,
            keywords=keywords,
        )
    
    def get_quality_metrics(self) -> dict[str, Any]:
        """Get xMemory quality metrics."""
        return self._consolidation.get_stats()
    
    def clear(self) -> None:
        """Clear all xMemory data."""
        self._consolidation.clear()
    
    def to_dict(self) -> dict[str, Any]:
        """Serialize xMemory state."""
        return {
            "consolidation": self._consolidation.to_dict(),
            "config": {
                "enabled": self.config.enabled,
                "use_xmemory_retrieval": self.config.use_xmemory_retrieval,
                "use_legacy_retrieval": self.config.use_legacy_retrieval,
            },
        }
    
    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        episodic_memory: EpisodicMemory | None = None,
        config: XMemoryConfig | None = None,
    ) -> XMemoryIntegration:
        """Deserialize xMemory state."""
        integration = cls(episodic_memory, config)
        
        if "consolidation" in data:
            integration._consolidation = ConsolidationEngine.from_dict(
                data["consolidation"],
                config.consolidation_config if config else None,
            )
            integration._retriever = HierarchicalRetriever(
                integration._consolidation.theme_manager,
                integration._consolidation.semantic_memory,
                episodic_memory,
                config.retriever_config if config else None,
            )
        
        return integration


def create_xmemory_integration(
    episodic_memory: EpisodicMemory | None = None,
    llm_call: Callable[[str], str] | None = None,
    embed_fn: Callable[[str], np.ndarray] | None = None,
    config: XMemoryConfig | None = None,
) -> XMemoryIntegration:
    """
    Factory function to create configured xMemory integration.
    
    Args:
        episodic_memory: Existing episodic memory.
        llm_call: LLM call function.
        embed_fn: Embedding function.
        config: Configuration.
        
    Returns:
        Configured XMemoryIntegration instance.
    """
    integration = XMemoryIntegration(episodic_memory, config)
    
    if llm_call and embed_fn:
        integration.configure_llm(llm_call, embed_fn)
    
    return integration
