"""
neoCoder SDK - Scalable Agent Scaffolding for Real-World Codebases

The neoCoder SDK provides a principled agent development platform structured around
three complementary perspectives: Agent Experience (AX), User Experience (UX), and
Developer Experience (DX).
"""

__version__ = "0.1.0"

from neoCoder.sdk.orchestrator import Orchestrator
from neoCoder.sdk.extensions.base import Extension
from neoCoder.sdk.memory.working import WorkingMemory

__all__ = [
    "Orchestrator",
    "Extension",
    "WorkingMemory",
    "__version__",
]
