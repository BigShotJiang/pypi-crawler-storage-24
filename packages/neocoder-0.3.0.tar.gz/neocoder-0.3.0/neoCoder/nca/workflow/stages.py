"""
Workflow stage definitions and data models.

This module defines the core data structures for the workflow preset feature,
including Stage, WorkflowState, and WorkflowConfig dataclasses.
"""

from dataclasses import dataclass, field
from typing import Any, Callable
from datetime import datetime


@dataclass
class Stage:
    """
    Definition of a workflow stage.
    
    A stage represents a distinct phase in the workflow with specific objectives,
    prompts, and completion criteria. Each stage guides the LLM through a focused
    task within the larger development process.
    
    Attributes:
        name: Human-readable name of the stage (e.g., "Problem Breakdown")
        number: Sequential position in the workflow (1-indexed)
        total_stages: Total number of stages in the workflow
        description: Brief description of what this stage accomplishes
        objectives: List of specific goals for this stage
        prompt_template: System prompt template for this stage
        completion_markers: Phrases that indicate stage completion
        validation_rules: Functions to validate stage output
        requires_user_approval: Whether to prompt user before transitioning
    """
    name: str
    number: int
    total_stages: int
    description: str
    objectives: list[str]
    prompt_template: str
    completion_markers: list[str] = field(default_factory=list)
    validation_rules: list[Callable[[str], bool]] = field(default_factory=list)
    requires_user_approval: bool = True


@dataclass
class WorkflowState:
    """
    Persistent workflow state.
    
    This state is saved to disk and restored when resuming a workflow,
    allowing long-running workflows to be interrupted and continued.
    
    Attributes:
        current_stage: Index of the currently active stage (0-indexed)
        stage_outputs: Dictionary mapping stage names to their outputs
        task_description: Original task description provided by user
        started_at: ISO 8601 timestamp when workflow started
        updated_at: ISO 8601 timestamp of last state update
        failures: List of stage failures that have occurred
        retry_count: Number of retries for the current stage
        stage_started_at: ISO 8601 timestamp when current stage started
    """
    current_stage: int
    stage_outputs: dict[str, Any]
    task_description: str
    started_at: str
    updated_at: str
    failures: list[dict[str, Any]] = field(default_factory=list)
    retry_count: int = 0
    stage_started_at: str | None = None
    
    def to_dict(self) -> dict[str, Any]:
        """Convert state to dictionary for JSON serialization."""
        return {
            "current_stage": self.current_stage,
            "stage_outputs": self.stage_outputs,
            "task_description": self.task_description,
            "started_at": self.started_at,
            "updated_at": self.updated_at,
            "failures": self.failures,
            "retry_count": self.retry_count,
            "stage_started_at": self.stage_started_at,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WorkflowState":
        """Create state from dictionary loaded from JSON."""
        return cls(
            current_stage=data["current_stage"],
            stage_outputs=data["stage_outputs"],
            task_description=data["task_description"],
            started_at=data["started_at"],
            updated_at=data["updated_at"],
            failures=data.get("failures", []),
            retry_count=data.get("retry_count", 0),
            stage_started_at=data.get("stage_started_at"),
        )


@dataclass
class StageFailure:
    """
    Record of a stage failure.
    
    Tracks information about a failed stage execution for retry and
    rollback logic.
    
    Attributes:
        stage_name: Name of the stage that failed
        stage_number: Number of the stage that failed
        error_message: Description of the failure
        timestamp: ISO 8601 timestamp when failure occurred
        retry_count: Number of times this stage has been retried
    """
    stage_name: str
    stage_number: int
    error_message: str
    timestamp: str
    retry_count: int = 0
    
    def to_dict(self) -> dict[str, Any]:
        """Convert failure to dictionary for JSON serialization."""
        return {
            "stage_name": self.stage_name,
            "stage_number": self.stage_number,
            "error_message": self.error_message,
            "timestamp": self.timestamp,
            "retry_count": self.retry_count,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "StageFailure":
        """Create failure from dictionary loaded from JSON."""
        return cls(
            stage_name=data["stage_name"],
            stage_number=data["stage_number"],
            error_message=data["error_message"],
            timestamp=data["timestamp"],
            retry_count=data.get("retry_count", 0),
        )


@dataclass
class WorkflowConfig:
    """
    Configuration for workflow execution.
    
    This configuration controls how the workflow executes, including which
    stages to run, whether to auto-transition, and where to persist state.
    
    Attributes:
        stages: List of Stage definitions to execute in order
        enable_auto_transitions: Whether to automatically move to next stage
        require_user_approval: Whether to prompt user before stage transitions
        persist_state: Whether to save workflow state to disk
        state_file: Path to workflow state file (relative to .neoCoder/)
        max_retries: Maximum number of retries per stage before giving up
        stage_timeout_minutes: Timeout in minutes for each stage (0 = no timeout)
    """
    stages: list[Stage]
    enable_auto_transitions: bool = True
    require_user_approval: bool = True
    persist_state: bool = True
    state_file: str = ".neoCoder/workflow_state.json"
    max_retries: int = 3
    stage_timeout_minutes: int = 60

    @dataclass
    class StageFailure:
        """
        Record of a stage failure.

        Tracks information about a failed stage execution for retry and
        rollback logic.

        Attributes:
            stage_name: Name of the stage that failed
            stage_number: Number of the stage that failed
            error_message: Description of the failure
            timestamp: ISO 8601 timestamp when failure occurred
            retry_count: Number of times this stage has been retried
        """
        stage_name: str
        stage_number: int
        error_message: str
        timestamp: str
        retry_count: int = 0

        def to_dict(self) -> dict[str, Any]:
            """Convert failure to dictionary for JSON serialization."""
            return {
                "stage_name": self.stage_name,
                "stage_number": self.stage_number,
                "error_message": self.error_message,
                "timestamp": self.timestamp,
                "retry_count": self.retry_count,
            }

        @classmethod
        def from_dict(cls, data: dict[str, Any]) -> "StageFailure":
            """Create failure from dictionary loaded from JSON."""
            return cls(
                stage_name=data["stage_name"],
                stage_number=data["stage_number"],
                error_message=data["error_message"],
                timestamp=data["timestamp"],
                retry_count=data.get("retry_count", 0),
            )


class StageLibrary:
    """
    Predefined stages for common workflows.
    
    This class provides factory methods for creating standard workflow stages.
    Each method returns a fully configured Stage instance with appropriate
    prompts, objectives, and completion criteria.
    """
    
    TOTAL_STAGES = 7
    """Total number of stages in the default workflow."""

    @staticmethod
    def brainstorming() -> Stage:
        """
        Stage 1: Brainstorming

        Think through the problem before coding: understand context,
        break it down, choose an approach, consider alternatives and risks.

        Returns:
            Stage configured for brainstorming
        """
        return Stage(
            name="Brainstorming",
            number=1,
            total_stages=StageLibrary.TOTAL_STAGES,
            description="Think through the problem before coding",
            objectives=[
                "Reference the tech stack best practices (already discovered)",
                "Reason freely about the problem — explore constraints, assumptions, alternatives",
                "Distill reasoning into a clear decision (approach)",
                "Identify key risks",
            ],
            prompt_template="""You are in the Brainstorming stage (Stage 1/{total}).

Think through the problem BEFORE writing any code.
Use the `brainstorming` tool: write your reasoning in `thinking`, then
distill the decision into `approach`.

⚠️ PRECONDITION: Tech Stack Discovery MUST be completed BEFORE this stage.
The tech stack and best practices are already available in your context.
Reference them — do NOT re-discover.

### Step 1 — Strategic Reasoning
In your thinking, consider whatever is relevant:
- What constraints and assumptions exist? Which might be wrong?
- How does the problem break down? What depends on what?
- What alternatives exist? Why is one better?
- How do the tech stack best practices constrain the approach?

### Step 2 — Mental Simulation (MANDATORY)
To verify, **read the code** with `file_read` / `grep` / `glob` and reason.
Do NOT use shell commands to analyze code.

Apply the full **Mental Simulation Protocol** defined in your system prompt
(Happy path → Edge cases → Failures → Caller → Side effects).

Run ALL steps — do not skip any. Record every issue found →
adjust approach or add to `risks`.

### Output requirements
- `approach` MUST reference the tech stack best practices that constrain
  the chosen solution. These are **binding constraints** for Plan and Implement.
- Do NOT write file-level details or step-by-step instructions —
  that belongs to the Plan stage.

When complete, state "BRAINSTORMING_COMPLETE" and ask for user approval.""",
            completion_markers=[
                "BRAINSTORMING_COMPLETE",
                "brainstorming is complete",
                "ready to proceed to planning",
            ],
            requires_user_approval=True,
        )
    
    @staticmethod
    def plan() -> Stage:
        """
        Stage 2: Implementation Plan

        Creates a detailed step-by-step implementation plan specifying file
        changes, dependencies, and test strategy based on the approved brainstorming.

        Returns:
            Stage configured for implementation planning
        """
        return Stage(
            name="Plan",
            number=2,
            total_stages=StageLibrary.TOTAL_STAGES,
            description="Create a detailed implementation plan based on the approved strategy",
            objectives=[
                "Create a step-by-step implementation plan aligned with the strategy",
                "Specify which files will be created, modified, or deleted",
                "Identify required dependencies and configuration changes",
                "Include test strategy for verifying changes",
            ],
            prompt_template="""You are in the Plan stage (Stage 2/{total}).

Based on the approved strategy from the previous stage, create a DETAILED
implementation plan.

IMPORTANT: The strategy (architectural approach, chosen patterns, trade-off
decisions) is provided in "Previous Stage Outputs" below. Your plan MUST
follow the approved strategic decisions — do NOT re-evaluate alternatives.

Your plan should include:
- Step-by-step implementation sequence
- Files to create (with purpose)
- Files to modify (with specific changes)
- Files to delete (if any)
- New dependencies to add (with version constraints)
- Configuration changes needed
- Test strategy (what to test and how)
- **Tech stack compliance notes**: for each step, reference which best practice
  from the session context applies.

### Mandatory step ordering
The LAST steps of every plan MUST follow this exact sequence:
1. **Mental Simulation** — run the full 6-step Mental Simulation Protocol
   on ALL changes BEFORE any build or test. This catches logical errors,
   CRITICAL rule violations, and missing pieces without wasting build time.
2. **Build** — compile / lint / type-check only AFTER simulation passes.
3. **Test** — run tests only AFTER build succeeds.

Never place build or test steps before mental simulation.

Present your plan clearly and comprehensively. When you have completed the plan,
explicitly state "PLAN_COMPLETE" to signal completion of this stage.

After presenting the plan, ask the user for approval before proceeding to implementation.""",
            completion_markers=[
                "PLAN_COMPLETE",
                "plan is complete",
                "ready to proceed to implementation",
            ],
            requires_user_approval=True,
        )
    
    @staticmethod
    def implement() -> Stage:
        """
        Stage 3: Migrate/Implement
        
        Executes the implementation plan by making code changes using file
        operations extensions.
        
        Returns:
            Stage configured for implementation
        """
        return Stage(
            name="Implement",
            number=3,
            total_stages=StageLibrary.TOTAL_STAGES,
            description="Execute the implementation plan",
            objectives=[
                "Follow the approved implementation plan",
                "Use file_read, file_write, and file_edit extensions to make changes",
                "Make incremental changes and verify each step",
                "Handle errors gracefully and report issues clearly",
                "Summarize all changes made",
            ],
            prompt_template="""You are in the Implement stage (Stage 3/{total}).

IMPORTANT: The detailed implementation plan from the Plan stage is provided in "Previous Stage Outputs" below.
You MUST follow that exact plan - do NOT create a new plan.

Execute the approved implementation plan systematically:

1. Read the "Plan" section from Previous Stage Outputs carefully
2. Follow each step in the order specified
3. Use appropriate file operations (read, write, edit) for each change
4. After EACH code change, run the Mental Simulation Protocol (as defined in system prompt)
   on that change BEFORE moving to the next step. Fix issues immediately.
5. If you encounter errors, analyze and fix them
6. Keep track of all changes made

### After ALL implementation steps are done:
1. **Final Mental Simulation** — run the full Mental Simulation Protocol on the ENTIRE
   set of changes together (cross-file interactions, end-to-end flow). Fix any issues found.
2. **Build / lint / type-check** — only AFTER simulation passes.
3. **Tests** — run tests only AFTER the build succeeds.

Never run build or tests before completing Mental Simulation.

DO NOT skip the plan or create your own approach. The plan has already been approved.

When you have completed all steps including simulation, build, and tests,
explicitly state "IMPLEMENTATION_COMPLETE" and provide a summary of all changes made.""",
            completion_markers=[
                "IMPLEMENTATION_COMPLETE",
                "implementation is complete",
                "all changes have been made",
            ],
            requires_user_approval=False,
        )
    
    @staticmethod
    def integration_test() -> Stage:
        """
        Stage 4: Integration Test
        
        Runs automated tests to verify the implementation works correctly,
        with retry logic for test failures.
        
        Returns:
            Stage configured for integration testing
        """
        return Stage(
            name="Integration Test",
            number=4,
            total_stages=StageLibrary.TOTAL_STAGES,
            description="Run automated tests to verify changes",
            objectives=[
                "Identify relevant test commands",
                "Use bash extension to run tests",
                "Analyze test failures and attempt fixes",
                "Retry tests until they pass or max retries reached",
                "Report test results clearly",
            ],
            prompt_template="""You are in the Integration Test stage (Stage 4/{total}).

Run automated tests to verify your implementation works correctly.

Process:
1. Identify the appropriate test commands for this project
2. Run the tests using bash commands
3. If tests fail:
   - Analyze the failure messages
   - Identify the root cause
   - Make necessary fixes
   - Re-run the tests
4. Repeat until tests pass or you've exhausted reasonable attempts

When all tests pass, explicitly state "TESTS_PASSED" to signal completion.

If tests continue to fail after multiple attempts, explain the issue and ask for guidance.""",
            completion_markers=[
                "TESTS_PASSED",
                "all tests passing",
                "tests are passing",
            ],
            requires_user_approval=False,
        )
    
    @staticmethod
    def tech_stack_review() -> Stage:
        """
        Stage 5: Tech Stack Expert Review
        
        Reviews changes against tech stack best practices and project conventions
        loaded from workspace rules.
        
        Returns:
            Stage configured for tech stack review
        """
        return Stage(
            name="Tech Stack Review",
            number=5,
            total_stages=StageLibrary.TOTAL_STAGES,
            description="Validate changes against tech stack best practices",
            objectives=[
                "Verify every technology's best practices from the strategy were followed",
                "Review stack-integration points (e.g. ORM + framework, Docker + language)",
                "Review changes against project structure conventions",
                "Review changes against dependency management practices",
                "Suggest improvements or approve changes",
            ],
            prompt_template="""You are in the Tech Stack Review stage (Stage 5/{total}).

Review your implementation against the tech stack best practices
that were generated in the Strategy stage.

### Review Process
1. **Re-read** the "Tech Stack & Practices" subsection from the Strategy output.
   This is the authoritative checklist of practices chosen for this task.
2. **For each technology**, verify the implementation actually follows
   every stated practice. Quote the practice and show evidence (code / config).
3. **Check stack-integration points**
   handling between FastAPI and SQLAlchemy, Docker layer caching for Python.
4. **Review general quality** through the lens of your pre-training knowledge:
   - Language-specific idioms and style guides
   - Project structure conventions (module organization, naming)
   - Dependency management (proper imports, pinned versions)
   - Security, error handling, performance
5. **If you find a violation**, fix it and explain which practice it violated.

Consider the workspace rules and project-specific conventions.

When the code meets all tech stack standards,
explicitly state "TECH_REVIEW_COMPLETE" to signal completion.""",
            completion_markers=[
                "TECH_REVIEW_COMPLETE",
                "tech stack review complete",
                "meets all tech stack standards",
            ],
            requires_user_approval=False,
        )
    
    @staticmethod
    def code_review() -> Stage:
        """
        Stage 6: Batch Code Review

        Reviews ALL files written/edited during this session in one pass.
        No per-file review on save — this is the single review checkpoint.

        Returns:
            Stage configured for batch code review
        """
        return Stage(
            name="Code Review",
            number=6,
            total_stages=StageLibrary.TOTAL_STAGES,
            description="Review all changed files against coding standards",
            objectives=[
                "Use batch_review to collect all files written/edited in this session",
                "Review each file against the coding standards in the prompt",
                "Fix every violation found — prioritize critical rules first",
                "Re-read fixed files to confirm no new issues were introduced",
            ],
            prompt_template="""You are in the Code Review stage (Stage 6/{total}).

Review ALL files changed during this session against the coding standards
you received in your system prompt.

Process:
1. Call `batch_review` — it returns every changed file's contents plus
   the full list of coding rules.
2. For each file, check every rule.  List violations with:
   - File path + line number
   - Which rule is violated
   - Concrete fix
3. Apply all fixes.
4. Re-read the fixed files to confirm they are clean.
5. When every file passes, state "CODE_REVIEW_COMPLETE" with a summary
   of what was found and fixed.

Principles:
- YOU are the reviewer — use your semantic understanding, not pattern matching.
- Fix the root cause, not the symptom.
- If a fix introduces new issues, iterate until clean.""",
            completion_markers=[
                "CODE_REVIEW_COMPLETE",
                "code review complete",
                "all rules passing",
            ],
            requires_user_approval=False,
        )
    
    @staticmethod
    def merge_prep() -> Stage:
        """
        Stage 7: Merge Preparation
        
        Generates a comprehensive summary of changes, test results, and code review
        outcomes, with a suggested commit message.
        
        Returns:
            Stage configured for merge preparation
        """
        return Stage(
            name="Merge Preparation",
            number=7,
            total_stages=StageLibrary.TOTAL_STAGES,
            description="Generate merge-ready summary",
            objectives=[
                "Generate a comprehensive change summary",
                "Include list of modified files with change descriptions",
                "Include test results and code review outcomes",
                "Suggest a commit message following conventional commits format",
                "Highlight any remaining manual steps or considerations",
            ],
            prompt_template="""You are in the Merge Preparation stage (Stage 7/{total} - Final Stage).

Create a comprehensive summary of all work completed in this workflow.

Your summary should include:
1. Overview of what was accomplished
2. List of files changed:
   - Created files (with purpose)
   - Modified files (with description of changes)
   - Deleted files (if any)
3. Test results summary
4. Code review outcomes
5. Suggested commit message (conventional commits format)
6. Any remaining manual steps or considerations

When you have completed the summary, explicitly state "MERGE_READY" to signal
that the workflow is complete and changes are ready for commit.""",
            completion_markers=[
                "MERGE_READY",
                "ready for merge",
                "workflow complete",
            ],
            requires_user_approval=False,
        )
    
    @staticmethod
    def get_default_workflow() -> list[Stage]:
        """
        Get the default 7-stage workflow.

        Decision Funnel: Strategy (what & why) → Plan (how) → Implement → Review.

        Returns:
            List of all 7 stages in execution order
        """
        return [
            StageLibrary.strategy(),
            StageLibrary.plan(),
            StageLibrary.implement(),
            StageLibrary.integration_test(),
            StageLibrary.tech_stack_review(),
            StageLibrary.code_review(),
            StageLibrary.merge_prep(),
        ]
