"""
Universal coding guide for LLM-driven code generation.

Three layers, no overlap:
  - CRITICAL: hard invariants (WHAT must never be violated)
  - Pillars:  design philosophy (WHY — without repeating CRITICAL details)
  - Pre-Commit Checklist lives in prompts.py (HOW to verify)

Consumer:
  - ``build_coding_prompt()`` → agent system prompt (Markdown)
"""

from __future__ import annotations

# =====================================================================
# CRITICAL — non-negotiable invariants
# =====================================================================

# (id, short_name, invariant)
# Rules are language-agnostic INVARIANTS.
# The agent derives the concrete implementation from its knowledge of the current tech stack.
_CRITICAL_RULES: list[tuple[str, str, str]] = [
    (
         "CRIT-0", "SECURITY-FIRST DESIGN",
         "Every access-control decision MUST follow whitelist-over-blacklist: "
         "deny all by default, then explicitly permit only what is needed. "
         "Every role/scope/permission MUST grant the minimum access required (least privilege). "
         "Security controls MUST be layered (defense in depth) — NEVER rely on a single gate. "
         "When writing authorization rules: enumerate allowed paths explicitly and end with deny-all as the default.",
    ),
    (
        "CRIT-1", "Architecture Principles",
        "Apply architecture principles appropriate to the tech stack: "
        "For JVM/backend (Java, Kotlin, C#, Python, Go, NodeJS/Express): use SOLID, separation of concerns, composition over inheritance. — "
        "For frontend (React, Vue, Angular, Svelte): use Feature-Sliced Design (FSD) — "
        "organize code by layers (app, processes, pages, widgets, features, entities, shared) "
        "with strict import rules: upper layers import from lower, never vice versa. "
        "Follow Google style class structure where applicable. "
        "Method docstrings must have Args/Returns/Raises sections. "
        "Keep modules focused and cohesive."
    ),
    (
        "CRIT-2", "SECRETS NEVER LEAK",
        "Passwords, tokens, API keys, PII, and internal stack traces must "
        "never appear in logs, API responses, error messages, client-visible "
        "output, OR source code — under any code path, including error paths. "
        "Secrets MUST be loaded from environment variables or a dedicated "
        "secrets manager — never hardcoded in source, config files committed "
        "to the repository, or default values in code. "
        "If you discover existing secrets in the codebase: do NOT copy or reveal "
        "the actual values — refer to them descriptively (e.g., 'hardcoded API key "
        "in config.py line 42') and propose remediation (move to env/secrets manager).",
    ),
    (
        "CRIT-3", "GUARANTEED CLEANUP",
        "Every acquired resource (file, connection, session, lock, stream) "
        "MUST have a cleanup path that executes regardless of success or "
        "failure. Use the idiomatic resource-management construct of the "
        "current language.",
    ),
    (
        "CRIT-4", "EXPLICIT FAILURE HANDLING",
        "Every external call (network, disk, DB, third-party service) MUST "
        "have explicit error handling with a timeout. Failures must be logged "
        "with context and the system must continue operating with reduced "
        "functionality — never silently swallow errors, never crash.",
    ),
    (
        "CRIT-5", "DECLARE ALL DEPENDENCIES",
        "Every dependency the code uses MUST be explicitly declared in the "
        "project's dependency manifest (package.json, requirements.txt, "
        "pyproject.toml, pom.xml, build.gradle, Cargo.toml, go.mod, Gemfile, "
        "etc.). Never rely on transitive, globally installed, or implicitly "
        "available packages. If you add an import — add the dependency.",
    ),
    (
        "CRIT-6", "PROTECT SHARED STATE",
        "CONDITIONAL — applies when data is accessible by multiple concurrent "
        "execution contexts (threads, coroutines, async tasks, requests, "
        "processes, or users). All read-write access to shared mutable state "
        "MUST use explicit synchronization or a concurrency-safe construct "
        "appropriate to the stack. Never assume sequential execution in a "
        "concurrent environment. First ask: IS there shared mutable state? "
        "If yes — prove it is safe, or make it safe.",
    )
]

# Meta-instruction appended after the rules in the prompt.
_CRITICAL_META = (
    "For each CRITICAL rule, determine the CORRECT implementation for the "
    "current tech stack using your knowledge. Example: CRIT-3 (GUARANTEED "
    "CLEANUP) means `try-with-resources` in Java, `with` in Python, `defer` "
    "in Go, `using` in C#, RAII in Rust, etc. "
    "CONDITIONAL rules (marked as such) apply only when their trigger "
    "condition is met — but when it IS met, they are equally non-negotiable. "
    "If you are unsure how a rule applies to the current stack — "
    "investigate the codebase before proceeding."
)

# =====================================================================
# Pillars — compact design principles (unique to CRIT rules)
# =====================================================================

_PILLARS: list[tuple[str, str]] = [
    (
        "Logging Best Practices",
        "Use project's logger (never print()); levels: DEBUG/INFO/WARNING/ERROR; "
        "include context (request_id, user_id); log at boundaries; never log secrets/PII; "
        "write to files with rotation."
    ),
    (
        "Modern Language Features", 
        "Use CURRENT VERSION features (Python 3.10+ pattern matching, Java 16+ records, "
        "React 18 concurrent). Check project's runtime version first."
    ),
    (
        "Resilience",
        "Design for partial failure; retries with backoff; circuit breakers; "
        "graceful degradation when dependencies fail."
    ),
]


# =====================================================================
# Prompt builder
# =====================================================================

def build_critical_rules_block() -> str:
    """
    Render the CRITICAL rules as an XML-delimited block.

    Designed for maximum transformer attention:
    - XML tags create explicit attention boundaries
    - Each rule has a unique ID (CRIT-1 .. CRIT-N) for referencing
    - Block is meant to be placed at the TOP of the system prompt (primacy)
    """
    lines: list[str] = [
        "<CRUCIAL_CODING_RULES>",
        "⛔ CRUCIAL CODING RULES — NEVER VIOLATE",
        "",
        "These are the most important rules for writing code. "
        "Non-negotiable. If ANY rule is violated, the change is BROKEN "
        "regardless of whether it works.",
        "",
    ]
    for rule_id, short_name, rule_text in _CRITICAL_RULES:
        lines.append(f"[{rule_id}] {short_name}: {rule_text}")
        lines.append("")
    lines.append(_CRITICAL_META)
    lines.append("</CRUCIAL_CODING_RULES>")
    return "\n".join(lines)


def build_coding_prompt() -> str:
    """
    Generate compact coding guide (Pillars only, CRIT reminder removed - it's in system prompt).
    """
    lines: list[str] = ["## Additional Best Practices", ""]
    
    for title, principle in _PILLARS:
        lines.append(f"**{title}**: {principle}")
    
    return "\n".join(lines)


# Allow quick inspection:  python -m neoCoder.nca.coding_rules
if __name__ == "__main__":
    print(build_coding_prompt())
