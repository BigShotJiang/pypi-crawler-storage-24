"""
neoCoder Agent (NCA) - Main agent implementation.

NCA is a coding agent instantiated from the neoCoder SDK with
coding-specific extensions, prompts, and configuration.

Features (F1-F4 from paper):
- F1: Context compression via Architect agent
- F2: Persistent notes via Note-Taker agent
- F3: Modular extension system
- F4: Meta-agent support (via separate module)
"""

from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Callable, Any

from neoCoder.sdk.orchestrator import Orchestrator, OrchestratorResult
from neoCoder.sdk.extensions.bash import BashExtension, BashConfig
from neoCoder.sdk.extensions.file_edit import FileEditExtension, FileEditConfig
from neoCoder.sdk.extensions.file_search import FileSearchExtension, FileSearchConfig

from neoCoder.sdk.extensions.thinking import ThinkingExtension, ThinkingConfig
from neoCoder.sdk.extensions.code_review import CodeReviewExtension, CodeReviewConfig
from neoCoder.sdk.extensions.project_context import ProjectContextExtension
from neoCoder.sdk.extensions.db_context import DatabaseContextExtension, DatabaseContextConfig
from neoCoder.sdk.agents.architect import ArchitectAgent, ArchitectConfig
from neoCoder.sdk.agents.note_taker import NoteTakerAgent, NoteTakerConfig
from neoCoder.sdk.extensions.session_context import SessionContext
from neoCoder.nca.config import NCAConfig
from neoCoder.nca.project_fingerprint import (
    needs_tech_stack_refresh,
    save_fingerprint,
    compute_project_fingerprint,
)
from neoCoder.nca.prompts import (
    NCA_SYSTEM_PROMPT,
    NCA_CODING_PROMPT,
    NCA_DEBUG_PROMPT,
    NCA_REFACTOR_PROMPT,
)
from neoCoder.nca.tech_stack_analyzer import build_tech_stack_context

# Simple conversational messages that don't need heavy context injection
_TRIVIAL_PATTERNS = frozenset({
    'hi', 'hello', 'hey', 'yo', 'sup',
    'thanks', 'thank you', 'thx', 'ty',
    'ok', 'okay', 'sure', 'yes', 'no', 'yep', 'nope',
    'bye', 'goodbye', 'cya', 'later',
    'help', '?', 'what', 'who', 'why', 'how',
})


def _is_trivial_task(task: str) -> bool:
    """Check if task is a simple conversational message that doesn't need heavy context."""
    normalized = task.strip().lower().rstrip('?!.')
    if normalized in _TRIVIAL_PATTERNS:
        return True
    # Very short messages (< 15 chars) without code-related keywords
    if len(normalized) < 15:
        code_keywords = {'code', 'file', 'function', 'class', 'bug', 'error', 'fix', 'add', 'create', 'edit', 'change', 'update', 'delete', 'remove', 'test', 'run', 'build'}
        words = set(normalized.split())
        if not words & code_keywords:
            return True
    return False


class NeoCoderAgent:
    """
    The neoCoder Agent.

    A fully configured coding agent with:
    - Bash command execution
    - File reading, writing, and editing
    - Code search and navigation
    - Structured thinking and planning
    - Context compression (F1)
    - Persistent notes (F2)
    """

    def __init__(
        self,
        config: NCAConfig | None = None,
        working_dir: str | None = None,
        enable_notes: bool = True,
        enable_compression: bool = True,
        enable_code_review: bool = True,
    ):
        """
        Initialize the neoCoder Agent.

        Args:
            config: Agent configuration.
            working_dir: Working directory (default: current directory).
            enable_notes: Enable note-taking (F2).
            enable_compression: Enable context compression (F1).
            enable_code_review: Enable automatic code review.
        """
        import logging
        logger = logging.getLogger(__name__)
        
        self.config = config or NCAConfig()

        if working_dir:
            self.config.working_dir = working_dir

        # Feature flags
        self._enable_notes = enable_notes
        self._enable_compression = enable_compression
        self._enable_code_review = enable_code_review

        # Create extensions first (to detect shell type)
        extensions = self._create_extensions()
        
        # Select system prompt based on mode and detected shell
        self._system_prompt = self._get_system_prompt()

        # Create orchestrator with extensions and prompt
        self._orchestrator = Orchestrator(
            config=self.config.to_orchestrator_config(),
            extensions=extensions,
            system_prompt=self._system_prompt,
        )

        # Initialize F1: Architect agent for compression
        if enable_compression:
            self._architect = ArchitectAgent(
                config=ArchitectConfig(
                    model=self.config.architect_model or ArchitectConfig.model,
                    max_tokens=self.config.architect_max_tokens or ArchitectConfig.max_tokens,
                    temperature=self.config.architect_temperature or ArchitectConfig.temperature,
                    thinking_budget=self.config.architect_thinking_budget if self.config.architect_thinking_budget is not None else ArchitectConfig.thinking_budget,
                    compression_threshold=self.config.compression_threshold,
                    rolling_window_size=self.config.rolling_window_size,
                    api_key=self.config.api_key,
                    base_url=self.config.base_url,
                    use_zenmux_format=self.config.use_zenmux_format,
                )
            )
        else:
            self._architect = None

        # Initialize F2: Note-taking agent
        if enable_notes:
            notes_dir = os.path.join(self.config.working_dir, ".neoCoder", "notes")
            self._note_taker = NoteTakerAgent(
                config=NoteTakerConfig(
                    model=self.config.note_taker_model or NoteTakerConfig.model,
                    max_tokens=self.config.note_taker_max_tokens or NoteTakerConfig.max_tokens,
                    temperature=self.config.note_taker_temperature or NoteTakerConfig.temperature,
                    thinking_budget=self.config.note_taker_thinking_budget if self.config.note_taker_thinking_budget is not None else NoteTakerConfig.thinking_budget,
                    notes_dir=notes_dir,
                    api_key=self.config.api_key,
                    base_url=self.config.base_url,
                    use_zenmux_format=self.config.use_zenmux_format,
                )
            )
        else:
            self._note_taker = None

        # Task tracking
        # Tech stack context (lazily populated from ProjectDiscovery)
        self._project_profile = None

        self._current_task: str | None = None
        self._task_count = 0
        self._notes_thread: threading.Thread | None = None
        
        # Compression metrics
        self._compression_count = 0
        self._total_tokens_saved = 0
        
        # Session context (loaded from .neoCoder/context.md)
        self._session_context: SessionContext | None = None
        self._load_session_context()
        
        # Track if tech stack needs refresh (lazy, checked on first non-trivial task)
        self._tech_stack_checked = False
        
        logger.debug(f"NCA initialized: mode={self.config.mode}, notes={enable_notes}, compression={enable_compression}, hierarchical_memory={self.config.enable_hierarchical_memory}")

    def _get_system_prompt(self) -> str:
        """Get system prompt based on mode and detected shell."""
        # Use shell info from bash extension
        shell_type = getattr(self, '_detected_shell', 'unknown')
        shell_name = getattr(self, '_detected_shell_name', 'Shell')
        
        if shell_type == "powershell":
            platform_info = """
## Current Shell: PowerShell (Windows)
You are running in PowerShell. Use PowerShell commands:
- List files: `Get-ChildItem` or `dir`
- View file: `Get-Content filename` or `type filename`
- Create file: Use file_write tool (preferred) or `Set-Content`
- Run Python: `python script.py`
- Do NOT use: `ls -la`, `cat`, `rm -rf` (these are Unix/bash commands that won't work)
"""
        elif shell_type == "cmd":
            platform_info = """
## Current Shell: CMD (Windows Command Prompt)
You are running in CMD. Use CMD commands:
- List files: `dir` or `dir /b`
- View file: `type filename`
- Create file: Use file_write tool (preferred)
- Run Python: `python script.py`
- Do NOT use: `ls`, `cat`, `Get-ChildItem`, `Get-Content` (these won't work in CMD)
"""
        elif shell_type in ("bash", "sh"):
            platform_info = f"""
## Current Shell: {shell_name}
You are running in bash/sh. Use Unix commands:
- List files: `ls -la`
- View file: `cat filename`
- Run Python: `python script.py` or `python3 script.py`
"""
        else:
            import platform
            os_name = platform.system()
            platform_info = f"""
## Current Platform: {os_name}
Shell detection was inconclusive. Use platform-appropriate commands.
"""
        
        base = NCA_SYSTEM_PROMPT + platform_info

        if self.config.mode == "debug":
            return base + "\n\n" + NCA_DEBUG_PROMPT
        elif self.config.mode == "refactor":
            return base + "\n\n" + NCA_REFACTOR_PROMPT
        else:
            return base + "\n\n" + NCA_CODING_PROMPT

    def _create_extensions(self) -> list:
        """Create the extension bundle for NCA."""
        # Create bash extension and capture shell detection
        bash_ext = BashExtension(
            config=BashConfig(
                timeout=self.config.bash_timeout,
                working_dir=self.config.working_dir,
            )
        )
        
        # Store detected shell info for system prompt
        self._detected_shell = bash_ext.shell_type
        self._detected_shell_name = bash_ext.shell_name
        
        extensions = [
            bash_ext,
            FileEditExtension(
                config=FileEditConfig(
                    max_file_size=self.config.max_file_size,
                )
            ),
            FileSearchExtension(
                config=FileSearchConfig(
                    max_file_size=self.config.max_file_size,
                )
            ),

            ThinkingExtension(
                config=ThinkingConfig(
                    output_dir=str(Path(self.config.working_dir) / ".neocoder"),
                )
            ),
        ]
        
        # Add code review extension if enabled
        if self._enable_code_review:
            config_path = Path(self.config.working_dir) / ".kiro" / "code-review-rules.json"
            if config_path.exists():
                code_review_config = CodeReviewConfig.from_file(config_path)
            else:
                code_review_config = CodeReviewConfig()
            
            extensions.append(CodeReviewExtension(config=code_review_config))

        # Always add project context extension (build, linters, frameworks)
        extensions.append(ProjectContextExtension())

        # Add database context extension for migration/schema validation
        extensions.append(DatabaseContextExtension(config=DatabaseContextConfig()))

        return extensions

    def _load_session_context(self) -> None:
        """Load session context from .neoCoder/context.md if exists."""
        import logging
        logger = logging.getLogger(__name__)
        
        self._session_context = SessionContext.load(self.config.working_dir)
        if self._session_context:
            logger.info("Session context loaded from .neoCoder/context.md")
        else:
            self._session_context = SessionContext()

    def _save_session_context(self) -> None:
        """Save session context to .neoCoder/context.md."""
        if self._session_context:
            self._session_context.save(self.config.working_dir)

    def _ensure_tech_stack_fresh(self) -> None:
        """
        Ensure tech stack is up-to-date.
        
        Only rescans project if:
        1. No tech stack in context.md
        2. Dependency files changed (fingerprint mismatch)
        
        This avoids redundant scanning and prompt bloat.
        """
        import logging
        logger = logging.getLogger(__name__)
        
        if self._tech_stack_checked:
            return  # Already checked this session
        
        self._tech_stack_checked = True
        root = Path(self.config.working_dir)
        raw_context = SessionContext.load_raw(self.config.working_dir)
        
        if not needs_tech_stack_refresh(root, raw_context):
            logger.debug("Tech stack is fresh, skipping rescan")
            return
        
        logger.info("Tech stack needs refresh, scanning project...")
        
        # Run discovery
        discovery_results = self._get_discovery_results()
        
        if not discovery_results:
            logger.debug("No technologies detected")
            return
        
        # Build tech stack context
        tech_stack_text = build_tech_stack_context(
            task="",  # Empty task for general discovery
            discovery_results=discovery_results,
        )
        
        # Update session context with discovered tech stack
        if tech_stack_text and self._session_context:
            # Extract raw discovery names for context.md
            raw_names = [r if isinstance(r, str) else getattr(r, 'name', str(r)) 
                         for r in discovery_results]
            self._session_context.update_tech_stack(raw_discovery=raw_names)
            self._save_session_context()
            logger.info("Tech stack updated in context.md: %s", raw_names[:5])
        
        # Save fingerprint for next time
        fingerprint = compute_project_fingerprint(root)
        save_fingerprint(root, fingerprint)

    def _get_session_context_for_injection(self) -> str | None:
        """Get session context markdown for injection into task."""
        raw = SessionContext.load_raw(self.config.working_dir)
        if raw and len(raw.strip()) > 50:  # Has meaningful content
            return f"[Session Context]\n{raw}"
        return None

    @property
    def session_context(self) -> SessionContext:
        """Access to session context."""
        if self._session_context is None:
            self._session_context = SessionContext()
        return self._session_context

    def update_session_context(
        self,
        task_description: str | None = None,
        brainstorming: dict | None = None,
        plan: dict | None = None,
    ) -> None:
        """
        Update and save session context.
        
        Args:
            task_description: Current task description.
            brainstorming: Dict with goal, thinking, approach, risks.
            plan: Dict with goal and steps.
        """
        ctx = self.session_context
        
        if task_description:
            ctx.task_description = task_description
        
        if brainstorming:
            ctx.update_brainstorming(
                goal=brainstorming.get("goal", ""),
                thinking=brainstorming.get("thinking", ""),
                approach=brainstorming.get("approach", ""),
                risks=brainstorming.get("risks", []),
            )
        
        if plan:
            ctx.update_plan(
                goal=plan.get("goal", ""),
                steps=plan.get("steps", []),
            )
        
        self._save_session_context()

    def refresh_tech_stack(self) -> list[str]:
        """
        Force refresh of tech stack (rescan project).
        
        Use when user indicates they installed/upgraded dependencies.
        
        Returns:
            List of detected technology names.
        """
        import logging
        logger = logging.getLogger(__name__)
        
        logger.info("Forcing tech stack refresh...")
        
        # Reset check flag to force rescan
        self._tech_stack_checked = False
        
        # Clear cached fingerprint to force refresh
        root = Path(self.config.working_dir)
        fp_file = root / ".neoCoder" / "tech_stack_fingerprint.json"
        if fp_file.exists():
            fp_file.unlink()
        
        # Run the refresh
        self._ensure_tech_stack_fresh()
        
        # Return detected technologies
        if self._session_context and self._session_context.tech_stack.raw_discovery:
            return self._session_context.tech_stack.raw_discovery
        return []

    def set_callbacks(
        self,
        on_output: Callable[[str], None] | None = None,
        on_stream: Callable[[str], None] | None = None,
        on_iteration: Callable[[int], None] | None = None,
    ) -> None:
        """
        Set output callbacks.

        Args:
            on_output: Callback for complete outputs.
            on_stream: Callback for streamed chunks.
            on_iteration: Callback for iteration updates.
        """
        # Wrap on_iteration to include proactive compression check
        def wrapped_iteration(iteration: int, response) -> None:
            # Proactive compression check every N iterations
            if iteration > 0 and iteration % 5 == 0:
                self._try_compress()
            
            # Call user's callback if provided
            if on_iteration:
                on_iteration(iteration)
        
        self._orchestrator.set_callbacks(
            on_output=on_output,
            on_stream=on_stream,
            on_iteration=wrapped_iteration,
        )

    def run(self, task: str) -> OrchestratorResult:
        """
        Run the agent on a task.

        Args:
            task: The task description.

        Returns:
            OrchestratorResult with output and metadata.
        """
        self._current_task = task
        self._task_count += 1

        # Skip heavy context injection for trivial conversational messages
        if _is_trivial_task(task):
            result = self._orchestrator.run(task)
            return result

        # Ensure tech stack is fresh (only rescan if dependencies changed)
        self._ensure_tech_stack_fresh()

        # Inject session context (includes tech stack) — SINGLE SOURCE OF TRUTH
        session_ctx = self._get_session_context_for_injection()
        if session_ctx:
            task = f"{task}\n\n{session_ctx}"

        # Inject tech stack discovery instruction if tech stack is empty
        # This instructs LLM to analyze and output tech stack in brainstorming
        if self._needs_tech_stack_instruction():
            tech_stack_instruction = self._build_tech_stack_context(task)
            if tech_stack_instruction:
                task = f"{task}\n\n{tech_stack_instruction}"

        # Inject relevant notes if available (F2)
        if self._note_taker:
            relevant_notes = self._note_taker.get_relevant_notes(query=task, limit=3)
            if relevant_notes:
                notes_context = self._format_notes_for_context(relevant_notes)
                task = f"{task}\n\n[Relevant knowledge from previous sessions]\n{notes_context}"

        # Run task
        result = self._orchestrator.run(task)

        # Post-task processing
        self._post_task_processing(result)

        return result

    def _needs_tech_stack_instruction(self) -> bool:
        """
        Check if tech stack discovery instruction should be injected.
        
        Returns True if:
        - Session context has no structured tech stack (technologies list is empty)
        - This is the first task of the session
        """
        if not self._session_context:
            return True
        
        # Check if tech stack has actual technologies (not just raw_discovery)
        if not self._session_context.tech_stack.technologies:
            return True
        
        return False

    def _build_tech_stack_context(self, task: str) -> str:
        """Build tech stack context from codebase discovery + task text."""
        discovery_results = self._get_discovery_results()
        return build_tech_stack_context(
            task=task,
            discovery_results=discovery_results,
        )

    def _get_discovery_results(self) -> list:
        """Extract discovery results from ProjectContextExtension, triggering discovery if needed."""
        for ext in self._orchestrator._extensions:
            if not hasattr(ext, '_ensure_discovery'):
                continue

            # Ensure working dir is set so lazy discovery can run
            if not getattr(ext, '_working_dir', None):
                ext._working_dir = self.config.working_dir

            try:
                profile = ext._ensure_discovery()
                if profile is not None:
                    return profile.all_detected
            except Exception as e:
                import logging
                logging.getLogger(__name__).warning(
                    "Project discovery failed: %s", e,
                )
            break

        return []

    def _format_notes_for_context(self, notes: list) -> str:
        """Format notes for injection into task context."""
        formatted = []
        for note in notes:
            formatted.append(f"### {note.metadata.title}")
            formatted.append(note.content[:500])  # Truncate long notes
            if len(note.content) > 500:
                formatted.append("...")
            formatted.append("")
        return "\n".join(formatted)

    def _try_compress(self, logger=None) -> bool:
        """
        Attempt to compress context if threshold is reached.
        
        Returns:
            True if compression was performed.
        """
        if logger is None:
            import logging
            logger = logging.getLogger(__name__)
        
        if not self._architect or not self._enable_compression:
            return False
        
        if not self._architect.should_compress(
            self._orchestrator.memory,
            self.config.max_memory_tokens
        ):
            return False
        
        # Perform compression
        logger.info(
            f"Context compression triggered: "
            f"{self._orchestrator.memory._total_tokens} tokens, "
            f"{self._orchestrator.memory.message_count} messages"
        )
        
        compression_result = self._architect.compress(self._orchestrator.memory)
        
        # Update metrics
        self._compression_count += 1
        tokens_saved = compression_result.original_tokens - compression_result.compressed_tokens
        self._total_tokens_saved += tokens_saved
        
        logger.info(
            f"Compression complete: {compression_result.messages_compressed} messages → summary, "
            f"ratio={compression_result.compression_ratio:.2f}, "
            f"tokens saved={tokens_saved}"
        )
        
        # Store compression event in hierarchical memory if available
        if self.hierarchical_memory:
            self.store_memory("last_compression", {
                "messages_compressed": compression_result.messages_compressed,
                "compression_ratio": compression_result.compression_ratio,
                "tokens_saved": tokens_saved,
            })
        
        return True

    def _post_task_processing(self, result: OrchestratorResult) -> None:
        """Process after task completion."""
        import logging
        import threading
        
        logger = logging.getLogger(__name__)
        
        # F1: Check for compression
        if self._architect and self._enable_compression:
            self._try_compress(logger)

        # F2: Generate notes in background thread (non-blocking)
        if self._note_taker and self._enable_notes:
            # Only generate notes for non-trivial tasks
            if self._orchestrator.memory.message_count > 5:
                def take_notes_background():
                    try:
                        self._note_taker.take_notes(
                            memory=self._orchestrator.memory,
                            task_description=self._current_task,
                        )
                    except Exception as e:
                        logger.warning(f"Note-taking failed: {e}")
                
                thread = threading.Thread(target=take_notes_background, daemon=True)
                thread.start()
                self._notes_thread = thread

        # Update session context with current task
        if self._current_task and self._session_context:
            self._session_context.task_description = self._current_task
            self._save_session_context()

    def wait_for_notes(self, timeout: float = 10.0) -> None:
        """Wait for background note-taking to complete.

        Args:
            timeout: Maximum seconds to wait.
        """
        if self._notes_thread and self._notes_thread.is_alive():
            self._notes_thread.join(timeout=timeout)

    def reset(self) -> None:
        """Reset the agent for a new session."""
        self.wait_for_notes()
        self._orchestrator.reset()
        self._current_task = None

    @property
    def memory(self):
        """Access to working memory."""
        return self._orchestrator.memory

    @property
    def state(self):
        """Current agent state."""
        return self._orchestrator.state

    @property
    def architect(self) -> ArchitectAgent | None:
        """Access to Architect agent."""
        return self._architect

    @property
    def note_taker(self) -> NoteTakerAgent | None:
        """Access to Note-Taker agent."""
        return self._note_taker

    @property
    def compression_stats(self) -> dict[str, Any]:
        """Get compression statistics."""
        return {
            "compression_count": self._compression_count,
            "total_tokens_saved": self._total_tokens_saved,
            "current_tokens": self._orchestrator.memory._total_tokens,
            "max_tokens": self.config.max_memory_tokens,
            "usage_percent": (
                self._orchestrator.memory._total_tokens / self.config.max_memory_tokens * 100
                if self.config.max_memory_tokens > 0 else 0
            ),
            "has_compressed_summary": self._orchestrator.memory._compressed_summary is not None,
        }

    def force_compress(self) -> bool:
        """
        Force context compression regardless of threshold.
        
        Returns:
            True if compression was performed.
        """
        if not self._architect:
            return False
        
        import logging
        logger = logging.getLogger(__name__)
        
        logger.info("Forcing context compression...")
        compression_result = self._architect.compress(self._orchestrator.memory)
        
        self._compression_count += 1
        tokens_saved = compression_result.original_tokens - compression_result.compressed_tokens
        self._total_tokens_saved += tokens_saved
        
        logger.info(
            f"Forced compression: {compression_result.messages_compressed} messages, "
            f"saved {tokens_saved} tokens"
        )
        return compression_result.messages_compressed > 0

    def get_notes(self, category: str | None = None) -> list:
        """
        Get stored notes.

        Args:
            category: Optional category filter.

        Returns:
            List of notes.
        """
        if not self._note_taker:
            return []
        return self._note_taker.storage.list_notes(category=category)

    def search_notes(self, query: str) -> list:
        """
        Search notes.

        Args:
            query: Search query.

        Returns:
            Matching notes.
        """
        if not self._note_taker:
            return []
        return self._note_taker.storage.search_notes(query=query)

    def create_hindsight_note(
        self,
        error: str,
        solution: str,
        context: str | None = None,
    ) -> Any:
        """
        Manually create a hindsight note.

        Args:
            error: What went wrong.
            solution: How it was fixed.
            context: Additional context.

        Returns:
            Created note.
        """
        if not self._note_taker:
            return None
        return self._note_taker.create_hindsight_note(
            error_description=error,
            solution=solution,
            context=context,
        )

    @property
    def hierarchical_memory(self):
        """Access to hierarchical memory for cross-session persistence."""
        return self._orchestrator._hierarchical_memory

    def store_memory(
        self,
        key: str,
        value: Any,
        path: list[str] | None = None,
    ) -> None:
        """
        Store a value in hierarchical memory.

        Args:
            key: Key for the value.
            value: Value to store.
            path: Optional path (default: current context).
        """
        if self.hierarchical_memory:
            self.hierarchical_memory.store(key, value, path=path)

    def retrieve_memory(
        self,
        key: str,
        path: list[str] | None = None,
        default: Any = None,
    ) -> Any:
        """
        Retrieve a value from hierarchical memory.

        Args:
            key: Key to retrieve.
            path: Optional path (default: current context).
            default: Default value if not found.

        Returns:
            Retrieved value or default.
        """
        if self.hierarchical_memory:
            return self.hierarchical_memory.retrieve(key, path=path, default=default)
        return default

    def create_memory_entry(self, name: str, metadata: dict[str, Any] | None = None) -> str | None:
        """
        Create a new entry (task) in hierarchical memory.

        Args:
            name: Name for the entry.
            metadata: Optional metadata.

        Returns:
            Entry ID or None if memory disabled.
        """
        if self.hierarchical_memory:
            return self.hierarchical_memory.create_entry(name, metadata)
        return None

    def get_memory_tree(self) -> str:
        """Get a text representation of the hierarchical memory tree."""
        if self.hierarchical_memory:
            return self.hierarchical_memory.get_tree_structure()
        return "(hierarchical memory disabled)"
