"""neoCoder Agent - Coding-specific agent instantiation."""

from neoCoder.nca.agent import NeoCoderAgent
from neoCoder.nca.config import NCAConfig

__all__ = ["NeoCoderAgent", "NCAConfig"]
