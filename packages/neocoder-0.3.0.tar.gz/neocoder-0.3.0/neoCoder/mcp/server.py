"""
neoCoder MCP Server (FastMCP)

Exposes the neoCoder Agent as an MCP server that can be used
by Claude Code and other MCP-compatible clients.

Tools provided:
- neocoder_run: Run a coding task with neoCoder agent
- neocoder_search_notes: Search persistent notes from previous sessions
- neocoder_create_note: Create a hindsight note for future reference
- neocoder_list_notes: List all stored notes from previous sessions

Run with: python -m neoCoder.mcp.server
"""

import asyncio
import json
import logging
import os
import sys
import queue
import threading
from datetime import datetime
from typing import Any, List, Optional, Literal
from neoCoder.mcp.toon import dumps as toon_dumps

# Setup logging
log_dir = os.path.expanduser('~/.neoCoder/logs')
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(log_dir, 'mcp_server.log')),
        logging.StreamHandler(sys.stderr)
    ]
)
logger = logging.getLogger(__name__)

# FastMCP imports
try:
    from mcp.server.fastmcp import FastMCP
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False
    print("FastMCP not available. Upgrade mcp package: pip install 'mcp>=1.2.0'", file=sys.stderr)


# Globals for lazy loading
_agent = None
_notes_storage = None
_monitoring_initialized = False
_model_info_fetcher = None
_token_tracker = None
_display = None


def get_agent(working_dir: str = None):
    """Get or create the neoCoder agent."""
    global _agent
    if _agent is None:
        from neoCoder.nca import NeoCoderAgent
        _agent = NeoCoderAgent(
            working_dir=working_dir,
            enable_notes=True,
            enable_compression=True,
        )
    return _agent



def get_notes_storage():
    """Get or create notes storage."""
    global _notes_storage
    if _notes_storage is None:
        from neoCoder.sdk.memory.notes import NotesStorage, NotesConfig
        notes_dir = os.path.join(os.path.expanduser("~"), ".neoCoder", "notes")
        _notes_storage = NotesStorage(NotesConfig(storage_dir=notes_dir))
    return _notes_storage


async def initialize_monitoring():
    """Initialize monitoring components if enabled."""
    global _monitoring_initialized, _model_info_fetcher, _token_tracker, _display

    if _monitoring_initialized:
        return

    try:
        from neoCoder.config import load_settings
        from neoCoder.sdk.monitoring import ModelInfoFetcher, TokenTracker, ModelInfoDisplay

        settings = load_settings()

        # Check if monitoring is enabled
        if not settings.monitoring.enabled:
            logger.info("Monitoring disabled in settings")
            _monitoring_initialized = True
            return

        # Get API key from settings
        api_key = settings.zenmux.api_key
        if not api_key:
            logger.warning("No API key found, monitoring disabled")
            _monitoring_initialized = True
            return

        # Initialize monitoring components
        _model_info_fetcher = ModelInfoFetcher(
            api_key=api_key,
            cache_ttl=settings.monitoring.cache_ttl,
            api_timeout=settings.monitoring.api_timeout,
            base_url=settings.zenmux.base_url,
        )
        _token_tracker = TokenTracker(api_key=api_key)
        _display = ModelInfoDisplay()

        _monitoring_initialized = True
        logger.info("Monitoring initialized successfully")

    except Exception as e:
        logger.warning(f"Failed to initialize monitoring: {e}")
        _monitoring_initialized = True  # Mark as initialized to avoid retrying


async def show_startup_info(working_dir: str, model_name: str):
    """Show model information banner on startup."""
    try:
        from neoCoder.config import load_settings

        settings = load_settings()

        # Check if startup info is enabled
        if not settings.monitoring.enabled or not settings.monitoring.show_startup_info:
            return

        # Ensure monitoring is initialized
        await initialize_monitoring()

        if not _model_info_fetcher or not _display:
            return

        # Fetch model info
        model_info = await _model_info_fetcher.get_model_info(model_name)

        # Format and display banner
        banner = _display.format_startup_banner(working_dir, model_info)
        print(banner, file=sys.stderr)

    except Exception as e:
        logger.debug(f"Failed to show startup info: {e}")
        # Graceful degradation - don't break the agent


async def update_token_usage(generation_id: str):
    """Update token usage after a request."""
    try:
        from neoCoder.config import load_settings

        settings = load_settings()

        # Check if usage updates are enabled
        if not settings.monitoring.enabled or not settings.monitoring.show_usage_updates:
            return

        # Ensure monitoring is initialized
        await initialize_monitoring()

        if not _token_tracker or not _model_info_fetcher or not _display:
            return

        # Update usage from generation API
        usage = await _token_tracker.update_from_generation(generation_id)

        # Get model info for percentage calculation
        model_info = await _model_info_fetcher.get_model_info(settings.default_model)

        # Calculate percentages
        percentages = _token_tracker.calculate_percentages(model_info)

        # Format and display update
        update = _display.format_usage_update(usage, percentages)
        print(update, file=sys.stderr)

    except Exception as e:
        logger.debug(f"Failed to update token usage: {e}")
        # Graceful degradation - don't break the agent


# Create FastMCP instance
if MCP_AVAILABLE:
    mcp = FastMCP("neoCoder")

    @mcp.tool()
    async def neocoder_run(
        task: str,
        working_dir: Optional[str] = None,
        mode: Literal["coding", "debug", "refactor"] = "coding",
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        thinking_budget: Optional[int] = None,
        reasoning_effort: Literal["low", "medium", "high", None] = None,
        timeout: int = 1800
    ) -> str:
        """Run a coding task using the neoCoder Agent.

        The neoCoder agent is a powerful AI coding assistant that can:
        - Execute shell commands
        - Read, write, and edit files
        - Search code with glob and grep
        - Create structured plans
        - Learn from previous sessions via persistent notes

        Use this for complex, multi-step coding tasks that benefit from
        autonomous agent execution.

        Example tasks:
        - "Create a REST API with FastAPI and SQLite"
        - "Debug why the tests in test_auth.py are failing"
        - "Refactor the database module to use async/await"
        """
        # Try to get working directory from MCP roots if not explicitly provided
        if not working_dir:
            try:
                # FastMCP provides access to the request context via mcp.get_context()
                ctx = mcp.get_context()
                if ctx and ctx.session:
                    roots_result = await ctx.session.list_roots()
                    if roots_result and roots_result.roots:
                        # Use the first root as working directory
                        first_root = roots_result.roots[0]
                        root_uri = first_root.uri
                        # Convert file:// URI to path
                        if root_uri.startswith("file://"):
                            working_dir = root_uri[7:]  # Remove "file://"
                            # Handle Windows paths (file:///C:/...)
                            if len(working_dir) > 2 and working_dir[0] == '/' and working_dir[2] == ':':
                                working_dir = working_dir[1:]  # Remove leading /
                            logger.info(f"Using root from client: {working_dir}")
            except Exception as e:
                logger.debug(f"Could not get roots from client: {e}")

        # Fallback to current directory
        if not working_dir:
            working_dir = os.getcwd()

        logger.info(f"Starting task execution: {task[:100]}...")
        logger.info(f"Working directory: {working_dir}")
        logger.info(f"Mode: {mode}")
        if model:
            logger.info(f"Model: {model}")
        if temperature is not None:
            logger.info(f"Temperature: {temperature}")
        if max_tokens:
            logger.info(f"Max tokens: {max_tokens}")
        if thinking_budget:
            logger.info(f"Thinking budget: {thinking_budget}")
        if reasoning_effort:
            logger.info(f"Reasoning effort: {reasoning_effort}")

        if not task:
            return "Error: No task provided"

        try:
            # Import here to check API key
            from neoCoder.nca import NeoCoderAgent
            from neoCoder.nca.config import NCAConfig
            from neoCoder.config import load_settings

            logger.info("Creating agent...")

            # Get event loop
            loop = asyncio.get_event_loop()

            logger.info(f"Running task with timeout: {timeout}s")

            # Pre-load settings
            settings = load_settings()
            effective_model = model or settings.agent_config.default_model

            # Queue for streaming updates
            update_queue = queue.Queue()

            # Collect all updates for final response
            all_updates = []

            # Create agent AND run task in executor to avoid blocking
            def create_and_run_agent():
                """Create agent and run task - all in executor to avoid blocking."""
                logger.info("Creating agent in executor...")

                logger.info("Step 1: Creating NCAConfig from settings...")
                logger.info(f"MCP arguments: model={model}, effective_model={effective_model}")
                # Build config overrides from arguments
                config_overrides = {"mode": mode}
                if model:
                    config_overrides["model"] = model
                    logger.info(f"Setting model override: {model}")
                if temperature is not None:
                    config_overrides["temperature"] = temperature
                if max_tokens:
                    config_overrides["max_tokens"] = max_tokens

                if thinking_budget:
                    config_overrides["thinking_budget"] = thinking_budget
                if reasoning_effort:
                    config_overrides["reasoning_effort"] = reasoning_effort

                # Create config from settings with overrides (reuse pre-loaded settings)
                config = NCAConfig.from_settings(
                    settings,
                    agent_type="coder",
                    **config_overrides
                )

                logger.info(f"Step 2: Config created - model={config.model}, thinking_budget={config.thinking_budget}, reasoning_effort={config.reasoning_effort}")
                logger.info(f"Step 3: Creating NeoCoderAgent with working_dir={working_dir}")
                agent = NeoCoderAgent(
                    config=config,
                    working_dir=working_dir,
                    enable_notes=True,
                    enable_compression=True,
                )
                logger.info(f"Step 4: Agent created - actual working_dir={agent.config.working_dir}")

                # Show startup info banner (async call in executor)
                try:
                    import asyncio
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    loop.run_until_complete(show_startup_info(working_dir, config.model))
                    loop.close()
                except Exception as e:
                    logger.debug(f"Failed to show startup banner: {e}")

                # Collect output
                output_parts = []

                def on_output(text):
                    """Callback for streaming output."""
                    logger.debug(f"Tool output: {text[:100]}...")
                    output_parts.append(text)  # Don't add [Tool Output] here - will be added in formatting
                    # Send to queue for streaming
                    update_queue.put(("output", text))

                def on_stream(text):
                    """Callback for streaming chunks."""
                    logger.debug(f"Stream: {text[:100]}...")
                    update_queue.put(("stream", text))

                def on_iteration(iteration: int):
                    """Callback for iteration updates."""
                    logger.info(f"Starting iteration {iteration}")
                    update_queue.put(("iteration", iteration))

                agent.set_callbacks(
                    on_output=on_output,
                    on_stream=on_stream,
                    on_iteration=on_iteration
                )

                logger.info("Running task...")
                result = agent.run(task)
                logger.info(f"Task completed in {result.iterations} iterations")

                # Update token usage if generation ID is available
                if result.generation_id:
                    try:
                        import asyncio
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        loop.run_until_complete(update_token_usage(result.generation_id))
                        loop.close()
                    except Exception as e:
                        logger.debug(f"Failed to update token usage: {e}")

                # Signal completion
                update_queue.put(("done", None))

                return result, output_parts

            # Start agent in background thread
            result_container = []
            error_container = []

            def run_agent_thread():
                try:
                    result, output_parts = create_and_run_agent()
                    result_container.append((result, output_parts))
                except Exception as e:
                    error_container.append(e)

            agent_thread = threading.Thread(target=run_agent_thread, daemon=True)
            agent_thread.start()

            # Collect updates and build progress message
            iteration_count = 0
            last_update_time = asyncio.get_event_loop().time()
            start_time = datetime.now()

            # Enhanced progress tracking
            progress_lines = [
                "# 🚀 Task Execution Progress\n\n",
                f"**Started:** {start_time.strftime('%H:%M:%S')}\n",
                f"**Task:** {task[:100]}{'...' if len(task) > 100 else ''}\n",
                f"**Mode:** {mode}\n",
                f"**Working Dir:** {working_dir}\n"
            ]

            if model:
                progress_lines.append(f"**Model:** {model}\n")
            if thinking_budget:
                progress_lines.append(f"**Thinking Budget:** {thinking_budget} tokens\n")
            if reasoning_effort:
                progress_lines.append(f"**Reasoning Effort:** {reasoning_effort}\n")

            progress_lines.append("\n---\n\n")

            current_iteration_text = []
            iteration_start_time = None
            tool_output_count = 0

            while agent_thread.is_alive() or not update_queue.empty():
                try:
                    # Get update with timeout (short timeout for responsiveness)
                    update_type, data = update_queue.get(timeout=0.05)

                    if update_type == "done":
                        break

                    elif update_type == "iteration":
                        # Save previous iteration with timing
                        if current_iteration_text:
                            if iteration_start_time:
                                elapsed = (datetime.now() - iteration_start_time).total_seconds()
                                current_iteration_text.append(f"\n⏱️ *Iteration completed in {elapsed:.1f}s*\n")
                            progress_lines.append("".join(current_iteration_text))
                            current_iteration_text = []

                        iteration_count = data
                        iteration_start_time = datetime.now()
                        tool_output_count = 0

                        # Enhanced iteration header
                        current_iteration_text.append(
                            f"## 🔄 Iteration {data}\n"
                            f"*Started: {iteration_start_time.strftime('%H:%M:%S')}*\n\n"
                        )
                        all_updates.append(("iteration", data))

                    elif update_type == "stream":
                        # Accumulate stream text with better formatting
                        if data.strip():  # Only add non-empty content
                            current_iteration_text.append(data)
                        all_updates.append(("stream", data))

                    elif update_type == "output":
                        tool_output_count += 1
                        # Add tool output with better structure
                        output_preview = data[:300] if len(data) > 300 else data
                        has_more = len(data) > 300

                        current_iteration_text.append(
                            f"\n### 🔧 Tool Output #{tool_output_count}\n"
                            f"```\n{output_preview}\n"
                            f"{'... (truncated, ' + str(len(data) - 300) + ' more chars)' if has_more else ''}"
                            f"```\n"
                        )
                        all_updates.append(("output", data))

                    last_update_time = asyncio.get_event_loop().time()

                except queue.Empty:
                    # Check for timeout
                    current_time = asyncio.get_event_loop().time()
                    if current_time - last_update_time > timeout:
                        logger.error(f"Task timed out after {timeout} seconds")
                        return (f"❌ **Error:** Task execution timed out after {timeout} seconds.\n\n"
                                f"Consider breaking the task into smaller steps or increasing the timeout.")
                    continue

                # Small delay to avoid busy waiting (reduced for better responsiveness)
                await asyncio.sleep(0.01)  # 10ms instead of 100ms

            # Add final iteration text with timing
            if current_iteration_text:
                if iteration_start_time:
                    elapsed = (datetime.now() - iteration_start_time).total_seconds()
                    current_iteration_text.append(f"\n⏱️ *Iteration completed in {elapsed:.1f}s*\n")
                progress_lines.append("".join(current_iteration_text))

            # Wait for thread to complete
            agent_thread.join(timeout=5)

            # Check for errors
            if error_container:
                raise error_container[0]

            if not result_container:
                return "Error: Agent execution failed"

            result, output_parts = result_container[0]
            logger.info(f"Task completed successfully in {result.iterations} iterations")

            # Calculate total execution time
            total_time = (datetime.now() - start_time).total_seconds()

            # Format response with enhanced progress
            response = "".join(progress_lines)

            response += (
                "\n---\n\n"
                "# ✅ Task Completed Successfully\n\n"
                "## 📊 Execution Summary\n\n"
                "| Metric | Value |\n"
                "|--------|-------|\n"
                f"| **Status** | {'✅ Success' if result.success else '❌ Failed'} |\n"
                f"| **Total Time** | {total_time:.1f}s ({total_time/60:.1f}m) |\n"
                f"| **Iterations** | {result.iterations} |\n"
                f"| **Tokens Used** | {result.total_tokens:,} |\n"
                f"| **Avg Time/Iteration** | {total_time/result.iterations:.1f}s |\n\n"
                "## 📝 Final Output\n\n"
                f"{result.output}\n"
            )

            if result.error:
                response += (
                    "\n## ⚠️ Errors Encountered\n\n"
                    "```\n"
                    f"{result.error}\n"
                    "```\n"
                )

            return response

        except Exception as e:
            logger.error(f"Error running neoCoder: {str(e)}", exc_info=True)
            return f"Error running neoCoder: {str(e)}"


    @mcp.tool()
    async def neocoder_search_notes(
        query: str,
        category: Literal["projects", "shared", "hindsight", None] = None
    ) -> str:
        """Search neoCoder's persistent knowledge base.

        The agent stores notes from previous coding sessions including:
        - Solutions that worked
        - Patterns discovered
        - Hindsight notes about errors and how they were fixed
        - Architecture insights

        Use this to find relevant knowledge before starting a task.
        """
        try:
            storage = get_notes_storage()
            notes = storage.search_notes(query=query, category=category)

            if not notes:
                return f"No notes found for query: {query}"

            response = f"## Found {len(notes)} notes\n\n"
            for note in notes[:10]:  # Limit to 10
                response += f"### {note.metadata.title}\n"
                response += f"*Category: {note.metadata.category} | Keywords: {', '.join(note.metadata.keywords)}*\n\n"
                response += f"{note.content[:500]}{'...' if len(note.content) > 500 else ''}\n\n"
                response += "---\n\n"

            return response

        except Exception as e:
            return f"Error searching notes: {str(e)}"


    @mcp.tool()
    async def neocoder_create_note(
        title: str,
        content: str,
        category: Literal["projects", "shared", "hindsight"] = "hindsight",
        keywords: Optional[List[str]] = None
    ) -> str:
        """Create a hindsight note for future reference.

        Use this to record:
        - Problems encountered and their solutions
        - Important patterns or approaches discovered
        - Gotchas or edge cases to remember

        These notes will be available in future sessions.
        """
        if keywords is None:
            keywords = []

        try:
            storage = get_notes_storage()
            note = storage.create_note(
                title=title,
                content=content,
                category=category,
                keywords=keywords,
            )

            return f"Note created successfully!\n\nPath: {note.path}\nTitle: {note.metadata.title}"

        except Exception as e:
            return f"Error creating note: {str(e)}"


    @mcp.tool()
    async def neocoder_list_notes(
        category: Literal["projects", "shared", "hindsight", None] = None
    ) -> str:
        """List all stored notes from previous sessions."""
        try:
            storage = get_notes_storage()
            notes = storage.list_notes(category=category)

            if not notes:
                return "No notes found."

            response = f"## {len(notes)} Notes\n\n"
            for note in notes:
                response += f"- **{note['title']}** ({note['category']})\n"
                response += f"  Keywords: {', '.join(note['keywords']) if note['keywords'] else 'none'}\n"
                response += f"  Updated: {note['updated_at']}\n\n"

            return response

        except Exception as e:
            return f"Error listing notes: {str(e)}"


def main():
    """Run the FastMCP server."""
    if not MCP_AVAILABLE:
        print("FastMCP not available. Upgrade mcp package: pip install 'mcp>=1.2.0'", file=sys.stderr)
        sys.exit(1)

    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
