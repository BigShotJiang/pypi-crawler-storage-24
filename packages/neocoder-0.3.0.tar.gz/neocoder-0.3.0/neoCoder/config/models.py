"""Configuration models for neoCoder."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from pathlib import Path


@dataclass
class AnthropicConfig:
    """Anthropic-specific configuration."""
    
    auth_token: Optional[str] = None  # ANTHROPIC_AUTH_TOKEN
    base_url: Optional[str] = None    # ANTHROPIC_BASE_URL
    timeout: int = 60
    max_retries: int = 3
    streaming: bool = True
    
    # Extended thinking configuration
    thinking_enabled: bool = True
    thinking_budget: int = 10000  # Max thinking tokens
    thinking_effort: Optional[str] = None  # "low", "medium", "high" — auto-calculates budget
    thinking_mode: Optional[str] = None  # "auto", "enabled", "adaptive", "disabled"
    thinking_display: Optional[str] = None  # "summarized", "omitted"
    
    # Sampling parameters
    top_p: Optional[float] = None  # Nucleus sampling (0.0-1.0)
    top_k: Optional[int] = None  # Top-K sampling
    stop_sequences: Optional[List[str]] = None  # Custom stop sequences
    
    # Tool control
    tool_choice: Optional[str] = None  # "auto", "none", or specific tool config
    
    # Caching
    cache_control_enabled: bool = False  # Enable prompt caching
    cache_control_ttl: Optional[str] = None  # "5m" or "1h"
    
    # Metadata
    user_id: Optional[str] = None  # For tracking/analytics
    
    extra_params: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ZenMuxConfig:
    """ZenMux provider configuration."""
    
    # API Configuration
    api_key: Optional[str] = None  # ZENMUX_API_KEY
    base_url: str = "https://zenmux.ai/api/v1"
    timeout: int = 60
    max_retries: int = 3
    
    # Model Limits
    max_context_tokens: Optional[int] = None  # Maximum context window
    max_output_tokens: Optional[int] = None  # Maximum output tokens (used for thinking budget)
    
    # Streaming
    streaming_enabled: bool = True
    streaming_chunk_size: int = 1024
    streaming_timeout: int = 120
    
    # Structured Output
    structured_output_enabled: bool = True
    strict_validation: bool = True
    
    # Tool Calling
    tool_calling_enabled: bool = True
    max_tool_calls: int = 10
    tool_timeout: int = 30
    auto_execute_tools: bool = True
    
    # Reasoning
    reasoning_enabled: bool = True
    default_reasoning_effort: str = "medium"  # low, medium, high
    default_reasoning_max_tokens: int = 8192  # Max tokens for reasoning (o1 models)
    adaptive_reasoning: bool = True
    
    # Logging
    log_level: str = "INFO"
    log_requests: bool = True
    log_responses: bool = False





@dataclass
class SpecializedAgentConfig:
    """Configuration for the 3 agents: coder (main), architect (compression), note_taker."""
    
    # Models
    coder_model: str = "claude-3-5-sonnet-20241022"
    architect_model: str = "claude-3-5-sonnet-20241022"
    note_taker_model: str = "claude-3-5-sonnet-20241022"
    
    # Temperature
    coder_temperature: float = 0.3
    architect_temperature: float = 0.7
    note_taker_temperature: float = 0.3
    
    # Max tokens
    coder_max_tokens: int = 8192
    architect_max_tokens: int = 8192
    note_taker_max_tokens: int = 4096
    
    # Thinking budget (for Anthropic models via ZenMux)
    coder_thinking_budget: int = 10000
    architect_thinking_budget: int = 30000
    note_taker_thinking_budget: int = 0


@dataclass
class MemoryConfig:
    """Memory system configuration."""
    
    enabled: bool = True
    max_context_length: int = 100000
    compression_enabled: bool = True
    compression_threshold: float = 0.8
    adaptive_enabled: bool = True
    persistence_enabled: bool = False
    persistence_path: Optional[Path] = None


@dataclass
class CacheConfig:
    """Cache configuration."""
    
    enabled: bool = True
    max_size: int = 1000
    ttl: int = 3600  # seconds
    code_cache_enabled: bool = True
    semantic_cache_enabled: bool = True


@dataclass
class MonitoringConfig:
    """Monitoring configuration."""
    
    enabled: bool = True
    show_startup_info: bool = True
    show_usage_updates: bool = True
    cache_ttl: int = 3600  # 1 hour
    api_timeout: int = 5  # seconds
    display_format: str = "box"  # box, simple, compact
    
    def __post_init__(self):
        """Validate monitoring configuration."""
        if self.cache_ttl <= 0:
            raise ValueError(f"cache_ttl must be positive, got {self.cache_ttl}")
        
        if self.api_timeout <= 0:
            raise ValueError(f"api_timeout must be positive, got {self.api_timeout}")
        
        valid_formats = ["box", "simple", "compact"]
        if self.display_format not in valid_formats:
            raise ValueError(
                f"display_format must be one of {valid_formats}, got '{self.display_format}'"
            )


@dataclass
class AgentConfig:
    """Agent configuration."""
    
    name: str = "neocoder-agent"
    description: str = "neoCoder AI Agent"
    
    # Default model (can be overridden)
    default_model: str = "claude-3-5-sonnet-20241022"
    
    # Provider configurations
    anthropic: AnthropicConfig = field(default_factory=AnthropicConfig)
    zenmux: ZenMuxConfig = field(default_factory=ZenMuxConfig)
    
    # Feature configurations
    specialized_agents: SpecializedAgentConfig = field(default_factory=SpecializedAgentConfig)
    
    # System configurations
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    cache: CacheConfig = field(default_factory=CacheConfig)
    monitoring: MonitoringConfig = field(default_factory=MonitoringConfig)
    
    # General settings
    tools_enabled: bool = True
    reasoning_enabled: bool = True
    max_iterations: int = 10
    debug: bool = False
    log_level: str = "INFO"
