# Notes Index

This directory contains persistent notes from the neoCoder Agent.

## Structure

- `projects/` - Project-specific knowledge
- `shared/` - Generic, reusable insights
- `hindsight/` - Lessons learned from failures

## Usage

Notes are automatically created and updated by the Note-Taking Agent.
They can be searched by keywords or browsed by category.
