# Agent Memory Architecture

This document describes the full technical memory architecture of neoCoder, including runtime context handling, persistent memory layers, consolidation flow, semantic retrieval, and planning-state persistence.

---

## 1. Overview

neoCoder does not treat memory as a single prompt buffer. Instead, it uses a layered architecture where each subsystem is responsible for a different time horizon and knowledge type:

- **Working Memory** — active short-term conversational and tool context
- **Adaptive Memory** — runtime tuning of working-memory parameters
- **Context Compression** — summarization of older context under token pressure
- **Hierarchical Memory** — persistent cross-session structured storage
- **Episodic Memory** — completed task records for experience reuse
- **Procedural Memory** — reusable workflows extracted from experience
- **Notes Storage** — detailed markdown-based retained notes
- **xMemory** — semantic and thematic hierarchical memory on top of episodes
- **Session Context** — persisted planning context (`.neoCoder/context.md`)

At runtime, the **Orchestrator** coordinates these layers and the **CognitiveMemoryManager** acts as the central memory integration point.

---

## 2. Design Goals

The memory system is designed to support:

1. **Long-horizon tasks** without uncontrolled context growth
2. **Cross-session continuity** for resumed work
3. **Experience reuse** from previously completed tasks
4. **Structured knowledge extraction** rather than raw transcript replay
5. **Task-aware memory policy** based on execution type and complexity
6. **Planning persistence** across interrupted workflows
7. **Token efficiency** without losing important engineering state

---

## 3. High-Level Architecture

```mermaid
flowchart TD
    User[User Task]

    subgraph Runtime[Runtime Execution]
        Orch[Orchestrator]
        WM[Working Memory]
        AM[Adaptive Memory]
        CC[Context Compression]
    end

    subgraph Cognitive[Cognitive Layer]
        CMM[Cognitive Memory Manager]
        EM[Episodic Memory]
        PM[Procedural Memory]
        NS[Notes Storage]
        XM[xMemory]
    end

    subgraph Persistent[Persistent Layer]
        HM[Hierarchical Memory]
        SC[Session Context\n.neoCoder/context.md]
    end

    User --> Orch
    Orch --> AM
    Orch --> WM
    WM --> CC
    Orch --> CMM

    CMM --> EM
    CMM --> PM
    CMM --> NS
    CMM --> XM
    Orch --> HM
    CMM --> HM
    Orch --> SC
```

---

## 4. Orchestrator as Memory Coordinator

The orchestrator is the entry point for memory-aware execution.

### Responsibilities

The orchestrator:
- initializes runtime memory systems,
- chooses adaptive memory parameters,
- starts cognitive retrieval for a task,
- appends user / assistant / tool interactions into working memory,
- triggers context compression when needed,
- stores final results into persistent memory,
- finalizes cognitive consolidation after task completion.

### Runtime initialization

The orchestrator can initialize the following systems through configuration flags:

- `enable_adaptive_memory`
- `enable_hierarchical_memory`
- `enable_cognitive_memory`
- `enable_token_tracking`

### Task startup flow

When a task starts, the orchestrator performs the following memory-relevant steps:

1. Resets runtime counters
2. Applies adaptive memory configuration
3. Starts cognitive memory retrieval
4. Injects retrieved context into working memory
5. Enters the iterative execution loop

In code terms, the task startup is centered around these operations:

- adaptive configuration via `_apply_adaptive_memory_config(task)`
- cognitive retrieval via `self._cognitive_memory.start_task(...)`
- insertion of the task or retrieved context into working memory with `self._memory.add_user_message(...)`

---

## 5. Working Memory

### Purpose

Working Memory is the short-term memory buffer used by the LLM during the current run.
It contains:

- user messages,
- assistant responses,
- structured tool-use blocks,
- task-local execution state,
- compressed summaries replacing older context.

### Characteristics

- **Scope:** single active session
- **Persistence:** temporary
- **Primary use:** immediate reasoning loop

### Contents

During execution, the orchestrator stores:

- the current user task,
- assistant textual output,
- tool call blocks,
- tool results,
- compressed historical summaries.

### Role in the execution loop

Working memory is the substrate used to construct prompt context for the LLM. It is the first memory layer consulted for current-state reasoning.

### Constraints

Because LLM context windows are limited, Working Memory must be actively managed. This is why neoCoder pairs it with:

- adaptive tuning,
- rolling-window behavior,
- compression,
- cognitive consolidation.

---

## 6. Adaptive Memory

Adaptive Memory dynamically tunes working-memory parameters based on the task.

### Inputs

Adaptive tuning is based on:

- task description,
- inferred task type,
- estimated complexity,
- optional contextual hints.

### Output parameters

The manager adjusts:

- `compression_threshold`
- `rolling_window_size`

### Task classes

According to the project documentation, tasks are classified into three major groups:

- **debug**
- **refactor**
- **coding**

### Typical behavior

- **Debug tasks** keep more context and compress later
- **Refactor tasks** can compress earlier and use a tighter window
- **Coding tasks** use balanced defaults

### Mid-task updates

The orchestrator can also re-evaluate memory policy during execution when outputs indicate that the task has shifted, for example toward debugging or refactoring.

This makes memory policy dynamic instead of being fixed at session start.

---

## 7. Context Compression

### Purpose

Context compression prevents the active prompt buffer from growing unbounded while still preserving engineering state.

### Trigger

Compression is triggered when working memory reports that compression is needed.

The orchestrator explicitly checks for this in the execution loop.

### Compression procedure

1. Obtain compression candidates from working memory
2. Convert the candidate messages into a summarization input
3. Ask the LLM to create a concise structured summary
4. Replace the original message set with the summary
5. Forward the summary into cognitive memory for consolidation

### Preservation goals

The summarizer is instructed to preserve:

- task goals,
- current state,
- key decisions,
- important findings,
- important errors,
- open TODOs,
- next steps.

### Why it matters

Compression in neoCoder is not raw truncation. It is a memory transformation step that preserves execution-relevant information while reducing token cost.

---

## 8. Hierarchical Memory

### Purpose

Hierarchical Memory is the long-term persistent storage layer used for cross-session retention of task outcomes and structured execution metadata.

### What gets stored

After successful completion, the orchestrator stores durable information such as:

- task description,
- task output,
- success flag,
- artifact summary,
- task type,
- complexity,
- iteration count,
- token usage,
- session ID.

### Characteristics

- **Scope:** multiple sessions
- **Persistence:** durable
- **Primary use:** history, export, task continuity, structured retention

### Role in the architecture

Hierarchical Memory is used in two ways:

1. directly by the orchestrator to store final task outputs,
2. by the cognitive layer to retain compression summaries and episode-linked task structure.

This makes it the main persistent structured memory substrate in the system.

---

## 9. Episodic Memory

### Purpose

Episodic Memory stores completed tasks as reusable experience records called **episodes**.

### Episode structure

An episode may include:

- unique episode ID,
- task description,
- generated summary,
- outcome (`success` / `failed`),
- files touched,
- errors fixed,
- key decisions,
- tags,
- task type,
- complexity,
- total tokens,
- total iterations.

### Retrieval behavior

At the beginning of a task, the cognitive layer can retrieve similar episodes and format them into prompt context.

This gives the agent project-specific experience reuse rather than generic one-shot reasoning.

### Benefits

- reuse of previous solutions,
- better continuity across repeated maintenance tasks,
- support for similar-task bootstrapping,
- practical engineering memory rather than only semantic recall.

---

## 10. Procedural Memory

### Purpose

Procedural Memory stores reusable workflows and task-solving patterns extracted from historical execution.

This layer is meant to represent **how** the agent solved problems successfully, not only **what** happened.

### Sources

Procedural knowledge is derived from prior episodes and can be updated over time.

### Runtime usage

When a new task starts, the cognitive layer can retrieve relevant procedures based on:

- task text,
- technology hints,
- previous success patterns.

The orchestrator then benefits from reusable execution strategies that are already aligned with the repository and its technology stack.

### Additional behavior

The system can track which procedures were used and update success rates after task completion.

---

## 11. Notes Storage

### Purpose

Notes Storage provides detailed markdown-oriented retained knowledge beyond chat turns and episodes.

### Intended content

Notes can capture:

- architectural findings,
- implementation caveats,
- project-specific references,
- research outcomes,
- retained explanations too detailed for direct prompt inclusion.

### Retrieval

Relevant notes can be searched during task start and injected into the prompt context alongside episodes and procedures.

### Value

This allows the memory architecture to include curated written knowledge, not just automatically extracted execution traces.

---

## 12. xMemory Semantic Layer

neoCoder integrates an xMemory-inspired memory system for hierarchical semantic organization.

### Conceptual levels

The xMemory layer is described as:

- **L0 — Messages**: raw conversation turns
- **L1 — Episodes**: task execution records
- **L2 — Semantic Units**: discrete extracted facts or procedures
- **L3 — Themes**: higher-level semantic clusters

### Main components

According to the xMemory documentation, the subsystem includes:

- **SemanticMemory** — stores factual/procedural/conceptual units
- **ThemeManager** — groups semantics into themes
- **HierarchicalRetriever** — retrieves top-down from themes to specifics
- **ConsolidationEngine** — extracts and organizes knowledge from episodes
- **XMemoryIntegration** — bridges xMemory with cognitive memory

### Retrieval strategy

Instead of standard flat top-k retrieval, xMemory uses hierarchical retrieval:

1. query themes,
2. expand into semantic units when uncertainty is high,
3. ground in episodes if more detail is needed.

### Benefits

Compared with flat RAG-style retrieval, this approach provides:

- lower redundancy,
- better semantic grouping,
- more efficient token use,
- higher-level abstraction for repeated engineering knowledge.

### Runtime processing

After a task is completed and transformed into an episode, the episode can be processed by xMemory to:

- extract semantic knowledge,
- update themes,
- improve future retrieval quality.

---

## 13. Cognitive Memory Manager

The Cognitive Memory Manager is the central integration layer for memory.

### Managed subsystems

It coordinates:

- Working Memory,
- Hierarchical Memory,
- Episodic Memory,
- Procedural Memory,
- Notes Storage,
- Consolidation,
- xMemory.

### Core responsibilities

The manager is responsible for:

- starting task memory retrieval,
- combining context from episodes, procedures, notes, and xMemory,
- retaining compression summaries,
- creating an episode after completion,
- updating persistent structures,
- triggering semantic processing,
- optionally extracting new procedures.

### Task startup behavior

On `start_task(...)`, the manager may:

1. create a hierarchical entry for the task,
2. retrieve similar episodes,
3. retrieve relevant procedures,
4. retrieve relevant notes,
5. retrieve semantic context from xMemory,
6. combine everything into a single context block.

### Task completion behavior

On `complete_task(...)`, the manager may:

1. build a summary,
2. create and store an episode,
3. persist task-linked information into hierarchical memory,
4. update procedure outcomes,
5. trigger periodic procedure extraction,
6. process the episode through xMemory.

This is what makes neoCoder’s memory architecture cognitive rather than purely buffer-based.

---

## 14. Session Context Persistence

In addition to runtime and cognitive memory, neoCoder persists planning context through the Thinking extension.

### Persisted file

The extension stores context in:

```text
.neoCoder/context.md
```

### Stored planning state

This file can retain:

- detected tech stack,
- brainstorming goal,
- brainstorming reasoning,
- chosen approach,
- risks,
- implementation plan,
- progress state.

### Why it matters

This persistence layer is especially important for long-running workflow tasks because it preserves not only outputs, but also the reasoning structure behind the work.

It allows a later session to recover:

- what was decided,
- why it was decided,
- what steps were planned,
- which steps were already completed.

---

## 15. Memory Flow During Execution

The end-to-end memory lifecycle for a task is roughly:

### Phase 1 — Task start

- orchestrator receives task,
- adaptive memory selects parameters,
- cognitive manager retrieves reusable context,
- retrieved context is injected into working memory.

### Phase 2 — Active execution

- user/assistant/tool interactions accumulate in working memory,
- iterative LLM execution proceeds,
- tool results shape the next prompt state.

### Phase 3 — Compression

- if working memory exceeds threshold,
- older messages are summarized,
- compressed summary replaces detailed history,
- summary is also retained for cognitive consolidation.

### Phase 4 — Task completion

- final output is persisted to hierarchical memory,
- cognitive manager creates an episode,
- procedure success can be updated,
- xMemory may process the episode,
- planning context remains available in `.neoCoder/context.md`.

---

## 16. Memory Layer Comparison

| Layer | Time Horizon | Retrieval Style | Persistence | Main Content |
|------|--------------|-----------------|-------------|--------------|
| Working Memory | Immediate | Direct prompt context | No | Messages, tool interactions, active task state |
| Adaptive Memory | Immediate | Policy selection | No | Compression/window settings |
| Compression | Session-long | Summary replacement | Semi-retained | Summarized history |
| Hierarchical Memory | Long-term | Structured lookup/export | Yes | Task results, artifacts, metrics |
| Episodic Memory | Long-term | Similar-task retrieval | Yes | Completed task experiences |
| Procedural Memory | Long-term | Workflow/pattern retrieval | Yes | Reusable solution procedures |
| Notes Storage | Long-term | Search/injection | Yes | Detailed notes and markdown knowledge |
| xMemory | Long-term | Hierarchical semantic retrieval | Yes | Semantic units and themes |
| Session Context | Cross-session workflow continuity | Direct load | Yes | Brainstorming, plan, progress, tech stack |

---

## 17. Engineering Advantages

This architecture gives neoCoder several practical advantages over flat-context agents:

### 1. Better long-horizon execution
The agent can continue operating after large numbers of interactions because context is compressed rather than merely dropped.

### 2. Cross-session continuity
Important task outputs and planning state survive beyond a single run.

### 3. Experience reuse
Prior episodes and procedures can be injected into new tasks.

### 4. Better token efficiency
Not every past message must remain in raw form.

### 5. Structured knowledge growth
The system can evolve from raw interactions into reusable semantic and procedural knowledge.

### 6. Stronger workflow support
The planning state file gives reliable continuity for staged engineering processes.

---

## 18. Known Tradeoffs

Like any layered memory architecture, this design introduces tradeoffs:

- higher implementation complexity than a flat prompt buffer,
- dependence on summary quality during compression,
- possible mismatch between semantic extraction quality and task specificity,
- more moving parts to configure and validate,
- potential duplication across persistent layers if consolidation policies are not tuned carefully.

These tradeoffs are acceptable because the target use case is enterprise-scale, long-horizon engineering work rather than short one-shot prompts.

---

## 19. Summary

neoCoder implements memory as a layered cognitive system rather than a single conversation log.

At a technical level:

- **Working Memory** powers the active reasoning loop,
- **Adaptive Memory** tunes runtime retention policy,
- **Compression** preserves state under token pressure,
- **Hierarchical Memory** stores durable structured outcomes,
- **Episodic Memory** captures reusable task experience,
- **Procedural Memory** learns successful workflows,
- **Notes Storage** retains detailed markdown knowledge,
- **xMemory** adds semantic and thematic organization,
- **Session Context** preserves workflow reasoning and planning state.

Together, these layers make neoCoder suitable for complex, multi-step, resumable software-engineering tasks where simple flat prompt history is not enough.
