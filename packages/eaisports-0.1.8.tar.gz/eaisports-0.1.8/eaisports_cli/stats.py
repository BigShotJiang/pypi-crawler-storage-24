"""
EAISports Stats Command -- display creator statistics.

Shows published games, visitor counts, and token balance for the
authenticated wallet.

Usage (from CLI):
    eaisports stats                 # show stats for configured wallet
"""

import logging
import sys

import requests

from eaisports_cli.colors import Colors, color
from eaisports_cli.config import load_config

logger = logging.getLogger(__name__)

DEFAULT_API_URL = "https://api.eaisports.ai"


def run_stats(wallet_address: str = None, api_url: str = None) -> None:
    """Fetch and display creator statistics.

    Parameters
    ----------
    wallet_address:
        Wallet address to query.  Falls back to the configured value.
    api_url:
        Base URL for the EAISports API.  Defaults to ``DEFAULT_API_URL``.
    """
    api_url = api_url or DEFAULT_API_URL
    config = load_config()

    # -- Resolve wallet
    wallet_address = wallet_address or config.get("wallet_address")
    if not wallet_address:
        print(color("  Configure your wallet: `eaisports init`", Colors.RED))
        sys.exit(1)

    stats_url = f"{api_url}/api/creators/{wallet_address}/stats"

    print(color("  Fetching creator stats...", Colors.DIM))
    print()

    try:
        resp = requests.get(stats_url, timeout=30)

        if resp.status_code == 200:
            data = resp.json()
            _display_stats(data, wallet_address)
        elif resp.status_code == 404:
            print(color("  No published games yet. Run `eaisports build` to create one!", Colors.YELLOW))
        else:
            error_msg = ""
            try:
                error_msg = resp.json().get("error", resp.text)
            except Exception:
                error_msg = resp.text
            print(color(f"  API error ({resp.status_code}): {error_msg}", Colors.RED))
            sys.exit(1)

    except requests.ConnectionError:
        print(color("  Could not reach the EAISports API. Check your connection.", Colors.RED))
        sys.exit(1)
    except requests.Timeout:
        print(color("  Request timed out. Try again later.", Colors.RED))
        sys.exit(1)
    except requests.RequestException as exc:
        print(color(f"  Network error: {exc}", Colors.RED))
        sys.exit(1)


def _display_stats(data: dict, wallet_address: str) -> None:
    """Format and print creator statistics."""
    total_games = data.get("total_games", 0)
    total_visitors = data.get("total_visitors", 0)
    token_balance = data.get("token_balance", 0)
    games = data.get("games", [])

    # -- Summary header
    print(color("  Creator Dashboard", Colors.BOLD, Colors.CYAN))
    print(color(f"  Wallet: {wallet_address}", Colors.DIM))
    print()

    # -- Overview stats
    print(color("  Overview", Colors.BOLD))
    print(color("  " + "-" * 40, Colors.DIM))
    print(f"  Published Games   {color(str(total_games), Colors.GREEN, Colors.BOLD)}")
    print(f"  Total Visitors    {color(str(total_visitors), Colors.GREEN, Colors.BOLD)}")
    print(f"  Token Balance     {color(f'{token_balance} EAI', Colors.YELLOW, Colors.BOLD)}")
    print()

    # -- Per-game breakdown
    if not games:
        print(color("  No published games yet. Run `eaisports build` to create one!", Colors.YELLOW))
        return

    print(color("  Games", Colors.BOLD))
    print(color("  " + "-" * 56, Colors.DIM))
    print(color(f"  {'Name':<24} {'Visitors':>10} {'Tokens':>10} {'Status':<10}", Colors.DIM))
    print(color("  " + "-" * 56, Colors.DIM))

    for game in games:
        name = game.get("slug", "unknown")[:24]
        visitors = game.get("visitors", 0)
        tokens = game.get("tokens_earned", 0)
        status = game.get("status", "live")

        status_color = Colors.GREEN if status == "live" else Colors.YELLOW
        print(
            f"  {name:<24} "
            f"{visitors:>10} "
            f"{tokens:>10} "
            f"{color(status, status_color)}"
        )

    print()
