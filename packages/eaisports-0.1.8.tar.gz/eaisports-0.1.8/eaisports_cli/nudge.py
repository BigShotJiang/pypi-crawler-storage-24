"""
Post-build skill extraction nudge for EAISports.

After a build session, scans the game directory for interesting patterns
(custom components, themes, reusable mechanics) and offers to save them
as a local skill under ~/.eaisports/skills/{game_slug}/.
"""

import re
import shutil
from pathlib import Path
from typing import List, Optional, Tuple


def _slugify(name: str) -> str:
    """Convert a directory name to a URL-safe slug."""
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "untitled"


def _scan_components(game_dir: Path) -> List[Path]:
    """Find .jsx files inside a components/ directory."""
    components: List[Path] = []
    for comp_dir in game_dir.rglob("components"):
        if comp_dir.is_dir():
            components.extend(comp_dir.glob("*.jsx"))
    return sorted(set(components))


def _scan_themes(game_dir: Path) -> List[Path]:
    """Find CSS files that look like custom themes."""
    theme_files: List[Path] = []
    for css in game_dir.rglob("*.css"):
        name_lower = css.stem.lower()
        if any(kw in name_lower for kw in ("theme", "style", "custom", "global")):
            theme_files.append(css)
    return sorted(set(theme_files))


def _scan_mechanics(game_dir: Path) -> List[Path]:
    """Find JS/JSX files that look like reusable game mechanics."""
    mechanics: List[Path] = []
    keywords = ("engine", "mechanic", "hook", "util", "helper", "logic", "state")
    for pattern in ("*.js", "*.jsx"):
        for f in game_dir.rglob(pattern):
            if any(kw in f.stem.lower() for kw in keywords):
                mechanics.append(f)
    return sorted(set(mechanics))


def _detect_patterns(game_dir: Path) -> Tuple[List[Path], List[Path], List[Path], List[str]]:
    """Detect interesting patterns in a game directory.

    Returns (components, themes, mechanics, tags).
    """
    components = _scan_components(game_dir)
    themes = _scan_themes(game_dir)
    mechanics = _scan_mechanics(game_dir)

    tags: List[str] = []
    if len(components) > 3:
        tags.append("components")
    if themes:
        tags.append("custom-theme")
    if mechanics:
        tags.append("game-mechanics")

    return components, themes, mechanics, tags


def _build_skill_md(
    game_slug: str,
    tags: List[str],
    components: List[Path],
    themes: List[Path],
    mechanics: List[Path],
    game_dir: Path,
) -> str:
    """Generate SKILL.md content for extracted patterns."""
    tags_str = ", ".join(f'"{t}"' for t in tags)

    # Build component list
    all_files = components + themes + mechanics
    component_lines = ""
    for f in all_files:
        try:
            rel = f.relative_to(game_dir)
        except ValueError:
            rel = f.name
        component_lines += f"- {rel}\n"

    if not component_lines:
        component_lines = "- (none detected)\n"

    content = f"""---
name: {game_slug}
version: "1.0.0"
description: "Patterns extracted from {game_slug} build"
author: "local"
category: "custom"
tags: [{tags_str}]
---

# {game_slug}

Custom skill extracted from a build session.

## Components
{component_lines.rstrip()}

## Usage
Reference these templates when building similar games.
"""
    return content


def _copy_templates(
    skill_dir: Path,
    components: List[Path],
    themes: List[Path],
    mechanics: List[Path],
) -> None:
    """Copy reusable files into the skill's templates/ directory."""
    templates_dir = skill_dir / "templates"
    templates_dir.mkdir(parents=True, exist_ok=True)

    for f in components + themes + mechanics:
        try:
            dest = templates_dir / f.name
            # Avoid overwriting if names collide
            if dest.exists():
                dest = templates_dir / f"{f.stem}_{hash(str(f)) % 10000}{f.suffix}"
            shutil.copy2(f, dest)
        except Exception:
            # Never fail the build over a copy error
            pass


def run_nudge(game_dir: Path, session_summary: Optional[str] = None) -> bool:
    """Check for interesting patterns and offer to save as a local skill.

    Args:
        game_dir: Path to the built game's output directory.
        session_summary: Optional summary text from the build session.

    Returns:
        True if a skill was saved, False otherwise.
    """
    from eaisports_cli.config import get_eaisports_home

    if not game_dir.is_dir():
        return False

    # Detect patterns
    components, themes, mechanics, tags = _detect_patterns(game_dir)

    if not tags:
        # Nothing interesting found
        return False

    # Build a description of what was found
    findings: List[str] = []
    if len(components) > 3:
        findings.append(f"{len(components)} custom components")
    if themes:
        findings.append(f"{len(themes)} custom theme file(s)")
    if mechanics:
        findings.append(f"{len(mechanics)} reusable mechanic(s)")

    from eaisports_cli.colors import Colors, color

    print()
    print(color("  Skill Nudge", Colors.CYAN + Colors.BOLD))
    print(color(f"  Detected interesting patterns: {', '.join(findings)}", Colors.DIM))
    print()

    # Prompt the user
    try:
        from prompt_toolkit import prompt as pt_prompt

        answer = pt_prompt("  Save this game's patterns as a local skill? [y/N]: ").strip().lower()
    except (KeyboardInterrupt, EOFError):
        print()
        return False

    if answer not in ("y", "yes"):
        print(color("  -> Skipped.", Colors.DIM))
        return False

    # Create the skill
    game_slug = _slugify(game_dir.name)
    home = get_eaisports_home()
    skill_dir = home / "skills" / game_slug
    skill_dir.mkdir(parents=True, exist_ok=True)

    # Write SKILL.md
    skill_md = _build_skill_md(game_slug, tags, components, themes, mechanics, game_dir)
    try:
        (skill_dir / "SKILL.md").write_text(skill_md)
    except Exception:
        return False

    # Copy templates
    _copy_templates(skill_dir, components, themes, mechanics)

    print(color(f"  -> Skill saved to {skill_dir}", Colors.GREEN))
    return True
