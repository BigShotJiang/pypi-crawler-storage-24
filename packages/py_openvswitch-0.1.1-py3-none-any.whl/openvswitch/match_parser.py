from __future__ import annotations

from openvswitch import constants, match
from openvswitch.exceptions import (
    InvalidCTStateError,
    InvalidRegisterError,
    InvalidTCPFlagError,
)
from openvswitch.match import Match
from openvswitch.utils import parse_int


def parse_match(key: str, value: str) -> Match | None:
    # Please keep the parser in the same order as match.py for easier maintenance

    # Input Interface
    if key == constants.IN_PORT:
        if value.isdigit():
            return match.InPort(int(value))
        else:
            print(value)
            return match.InPortLabel(value.strip('"'))

    # Tunnel Fields
    if key == constants.TUN_ID:
        tid, mask = split_masked_fields_int(value)
        return match.TunnelID(tid, mask)

    elif key == constants.TUN_SRC:
        return match.TunnelSource(value)

    elif key == constants.TUN_DST:
        return match.TunnelDestination(value)

    elif key == constants.TUN_IPV6_SRC:
        return match.TunnelIPv6Source(value)

    elif key == constants.TUN_IPV6_DST:
        return match.TunnelIPv6Destination(value)

    elif key == constants.VLAN_TCI:
        tci, tci_mask = split_masked_fields_int(value)
        return match.VLANTagControlInfo(tci, tci_mask)

    elif key == constants.VLAN_TCI1:
        tci, tci_mask_1 = split_masked_fields_int(value)
        return match.InnerVLANTagControlInfo(tci, tci_mask_1)

    # Connection Tracking

    elif key == constants.CT_STATE:
        states = parse_ct_states(value)
        return match.ConnectionTrackingState(*states)

    elif key == constants.CT_MARK:
        ct_mark, ct_mark_mask = split_masked_fields_int(value)
        return match.ConnectionTrackingMark(ct_mark, ct_mark_mask)

    elif key == constants.CT_ZONE:
        return match.ConnectionTrackingZone(parse_int(value, allow_none_return=False))

    # Metadata & Registers

    elif key == constants.METADATA:
        metadata, metadata_mask = split_masked_fields_int(value)
        return match.Metadata(metadata, metadata_mask)

    elif key == constants.CONJ_ID:
        return match.ConjunctionID(parse_int(value, allow_none_return=False))

    elif len(key) > 3 and (
        (len(key) > 3 and key[:3] == "reg")
        or (len(key) > 4 and key[:4] == "xreg")
        or (len(key) > 5 and key[:5] == "xxreg")
    ):
        return parse_register(key, value)

    # Layer 2 - Data Link

    elif key == constants.DL_SRC:
        dl_src_addr, dl_src_mask = split_masked_fields_str(value)
        return match.DataLinkSource(dl_src_addr, dl_src_mask)

    elif key == constants.DL_DST:
        dl_dst_addr, dl_dst_mask = split_masked_fields_str(value)
        return match.DataLinkDestination(dl_dst_addr, dl_dst_mask)

    elif key == constants.DL_TYPE:
        return match.DataLinkType(parse_int(value, allow_none_return=False))

    elif key == constants.DL_VLAN:
        return match.DataLinkVLAN(parse_int(value, allow_none_return=False))

    elif key == constants.DL_VLAN_PCP:
        return match.DataLinkVLANPCP(parse_int(value, allow_none_return=False))

    # Layer 3 - Network

    # L3 IPv4
    elif key == constants.NW_SRC:
        ip, cidr = split_ip_cidr(value)
        return match.NetworkSource(ip, cidr)

    elif key == constants.NW_DST:
        ip, cidr = split_ip_cidr(value)
        return match.NetworkDestination(ip, cidr)

    elif key == constants.NW_TOS:
        return match.NetworkTOS(parse_int(value, allow_none_return=False))

    elif key == constants.NW_ECN:
        return match.NetworkECN(parse_int(value, allow_none_return=False))

    elif key == constants.NW_TTL:
        return match.NetworkTTL(parse_int(value, allow_none_return=False))

    elif key == constants.NW_PROTO:
        return match.NetworkProtocol(parse_int(value, allow_none_return=False))

    # L3 IPv6
    elif key == constants.IPV6_SRC:
        return match.IPv6Source(value)

    elif key == constants.IPV6_DST:
        return match.IPv6Destination(value)

    elif key == constants.IPV6_LABEL:
        label, mask = split_masked_fields_int(value)
        return match.IPv6Label(label, mask)

    # L3 ARP
    elif key == constants.ARP_OP:
        return match.ARPOperation(parse_int(value, allow_none_return=False))

    elif key == constants.ARP_SPA:
        return match.ARPSourceProtocolAddress(value)

    elif key == constants.ARP_TPA:
        return match.ARPTargetProtocolAddress(value)

    elif key == constants.ARP_SHA:
        return match.ARPSourceHardwareAddress(value)

    elif key == constants.ARP_THA:
        return match.ARPTargetHardwareAddress(value)

    # Layer 4 - Transport
    elif key == constants.TP_SRC:
        return match.TransportSourcePort(parse_int(value, allow_none_return=False))

    elif key == constants.TP_DST:
        return match.TransportDestinationPort(parse_int(value, allow_none_return=False))

    elif key == constants.TCP_FLAGS:
        flags = parse_tcp_flags(value)
        return match.TCPFlags(*flags)

    elif key == constants.UDP_SRC:
        return match.UDPSourcePort(parse_int(value, allow_none_return=False))

    elif key == constants.UDP_DST:
        return match.UDPDestinationPort(parse_int(value, allow_none_return=False))

    # ICMP + ICMPv6
    elif key == constants.ICMP_TYPE:
        return match.ICMPType(parse_int(value, allow_none_return=False))

    elif key == constants.ICMP_CODE:
        return match.ICMPCode(parse_int(value, allow_none_return=False))

    elif key == constants.ICMPV6_TYPE:
        return match.ICMPv6Type(parse_int(value, allow_none_return=False))

    elif key == constants.ICMPV6_CODE:
        return match.ICMPv6Code(parse_int(value, allow_none_return=False))

    # Neighbor Discovery
    elif key == constants.ND_TARGET:
        return match.NeighborDiscoveryTargetIPv6(value)

    elif key == constants.ND_SLL:
        return match.NeighborDiscoverySourceHardwareAddress(value)

    elif key == constants.ND_TLL:
        return match.NeighborDiscoveryTargetHardwareAddress(value)

    return None


def _parse_flags_expr(value: str) -> list[str]:
    if "|" in value:
        value = "+" + value.replace("|", "+")
    if "+" in value or "-" in value:
        value = value.replace("+", " +").replace("-", " -").strip()
    else:
        value = f"+{value}"
    return value.split()


def parse_tcp_flags(s: str) -> list[match.SetTCPFlag | match.UnsetTCPFlag]:
    flags = _parse_flags_expr(s)
    return [parse_tcp_flag(flag) for flag in flags]


def parse_ct_states(s: str) -> list[match.SetCTState | match.UnsetCTState]:
    states = _parse_flags_expr(s)
    return [parse_ct_state(state) for state in states]


def parse_tcp_flag(s: str) -> match.SetTCPFlag | match.UnsetTCPFlag:
    """Parse '+syn' or '-rst' into a SetTCPFlag / UnsetTCPFlag object."""
    s = s.strip().lower()

    if not s or s[0] not in "+-":
        raise InvalidTCPFlagError(f"invalid TCP flag format: {s!r}")

    op = s[0]
    flag_str = s[1:]

    try:
        flag = match.TCPFlag(flag_str)
    except ValueError:
        raise InvalidTCPFlagError(f"unknown TCP flag: {flag_str!r}") from None

    if op == "+":
        return match.SetTCPFlag(flag)
    else:
        return match.UnsetTCPFlag(flag)


def parse_ct_state(s: str) -> match.SetCTState | match.UnsetCTState:
    """
    Parse '+trk' or '-est' into SetCTState/UnsetCTState.
    Accepts surrounding whitespace and ignores case.
    """

    s = s.strip().lower()
    if not s or s[0] not in "+-":
        raise InvalidCTStateError(f"Invalid CT state format: {s!r}")

    op, value = s[0], s[1:]

    try:
        state = match.CTState(value)  # uses the enum values: 'new','est','trk',...
    except ValueError:
        raise InvalidCTStateError(f"unknown CTState value: {value!r}") from None

    return match.SetCTState(state) if op == "+" else match.UnsetCTState(state)


def parse_register(
    key: str, value: str
) -> match.RegisterX | match.ExtendedRegisterX | match.DoubleExtendedRegisterX:
    if (
        key.startswith(constants.REG_PREFFIX)
        and key[len(constants.REG_PREFFIX) :].isdigit()
    ):
        i = int(key[len(constants.REG_PREFFIX) :])
        if i < 0 or i > 15:
            raise InvalidRegisterError(f"register index out of range: {i}")
        else:
            cls = getattr(match, f"Register{i}")
            assert issubclass(cls, match.RegisterX)

            obj = cls(parse_int(value, allow_none_return=False))
            assert isinstance(obj, match.RegisterX)
            return obj
    elif (
        key.startswith(constants.EXTENDED_REG_PREFIX)
        and key[len(constants.EXTENDED_REG_PREFIX) :].isdigit()
    ):
        i = int(key[len(constants.EXTENDED_REG_PREFIX) :])
        if i < 0 or i > 7:
            raise InvalidRegisterError(f"extended register index out of range: {i}")
        else:
            cls = getattr(match, f"ExtendedRegister{i}")
            assert issubclass(cls, match.ExtendedRegisterX)

            obj = cls(parse_int(value, allow_none_return=False))
            assert isinstance(obj, match.ExtendedRegisterX)
            return obj
    elif (
        key.startswith(constants.DOUBLE_EXTENDED_REG_PREFIX)
        and key[len(constants.DOUBLE_EXTENDED_REG_PREFIX) :].isdigit()
    ):
        i = int(key[len(constants.DOUBLE_EXTENDED_REG_PREFIX) :])
        if i < 0 or i > 3:
            raise InvalidRegisterError(
                f"double extended register index out of range: {i}"
            )
        else:
            cls = getattr(match, f"DoubleExtendedRegister{i}")
            assert issubclass(cls, match.DoubleExtendedRegisterX)

            obj = cls(parse_int(value, allow_none_return=False))
            assert isinstance(obj, match.DoubleExtendedRegisterX)
            return obj

    else:
        raise InvalidRegisterError(f"invalid register key: {key}")


def split_masked_fields_int(value: str) -> tuple[int, int | None]:
    if "/" in value:
        val, mask = value.split("/", 1)
        val_int = parse_int(val.strip(), allow_none_return=False)
        mask_int = parse_int(mask.strip(), allow_none_return=False)
        return val_int, mask_int

    val_int = parse_int(value, allow_none_return=False)
    assert val_int is not None

    return val_int, None


def split_masked_fields_str(value: str) -> tuple[str, str | None]:
    if "/" in value:
        val, mask = value.split("/", 1)
        return val, mask
    return value, None


def split_ip_cidr(value: str) -> tuple[str, int]:
    if "/" in value:
        ip, cidr = value.split("/", 1)
        return ip, int(cidr)
    return (value, 32)
