from __future__ import annotations

from enum import Enum

from openvswitch import constants
from openvswitch.action import Action
from openvswitch.action_parser import parse_actions
from openvswitch.exceptions import BucketError, GroupError
from openvswitch.utils import obj_repr, parse_int, validate_group_id


class GroupType(Enum):
    ALL = "all"
    SELECT = "select"
    INDIRECT = "indirect"
    FAST_FAILOVER = "ff"


class GroupCommonBucketID(Enum):
    ALL = "all"
    FIRST = "first"
    LAST = "last"


class Bucket:
    def __init__(self, actions: list[Action]):
        self.actions: list[Action] = actions

    def marshal_text(self) -> str:
        """
        Converts the bucket to OVS bucket syntax string.

        Returns:
            str: Bucket in OVS text format

        Raises:
            BucketError: If bucket has no actions
        """
        if not self.actions:
            raise BucketError(constants.ERR_BUCKET_NO_ACTIONS)

        actions_text = ",".join([str(a) for a in self.actions])
        return f"{constants.ACTIONS}={actions_text}"

    def __str__(self) -> str:
        return self.marshal_text()

    def __repr__(self) -> str:
        return obj_repr(self)

    @staticmethod
    def parse(text: str) -> Bucket:
        """
        Parses an OVS bucket string into a Bucket object.

        Args:
            text: Bucket string in OVS text format

        Returns:
            Bucket: Parsed bucket object

        Raises:
            BucketError: If bucket string is invalid or has no actions
        """
        # Expecting actions=action1,action2,...

        if not text or not text.startswith(f"{constants.ACTIONS}="):
            raise BucketError(f"invalid bucket actions format: {text}")

        actions_part = text[len(f"{constants.ACTIONS}=") :]
        actions = parse_actions(actions_part)

        if len(actions) == 0:
            raise BucketError(constants.ERR_BUCKET_NO_ACTIONS)

        return Bucket(actions)


class Group:
    def __init__(
        self,
        id: int,
        buckets: list[Bucket],
        type: GroupType | None = None,
        common_bucket_id: GroupCommonBucketID | None = None,
    ):
        self.id = validate_group_id(id)
        self.buckets = buckets
        self.type: GroupType | None = type
        self.common_bucket_id: GroupCommonBucketID | None = common_bucket_id

        if self.type == GroupType.INDIRECT and len(self.buckets) != 1:
            raise GroupError("indirect group must have exactly one bucket")

    def marshal_text(self) -> str:
        """
        Converts the group to OVS group syntax string.

        Returns:
            str: Group in OVS text format
        """
        s = f"{constants.GROUP_ID}={self.id},"
        if self.type:
            s += f"{constants.GROUP_TYPE}={self.type.value},"

        if self.common_bucket_id:
            s += f"{constants.COMMON_BUCKET_ID}={self.common_bucket_id.value},"

        if self.buckets:
            bucket_strs = [f"{constants.BUCKET}={str(b)}" for b in self.buckets]
            s += ",".join(bucket_strs)

        s = s.rstrip(",")
        return s

    def __str__(self) -> str:
        return self.marshal_text()

    def __repr__(self) -> str:
        return obj_repr(self)

    @classmethod
    def parse(cls, text: str, parse_buckets: bool = True) -> Group:
        """
        Parses an OVS group string into a Group object.

        Args:
            text: Group string in OVS text format
            parse_buckets: Whether to parse bucket details

        Returns:
            Group: Parsed group object

        Raises:
            GroupError: If group string is invalid or has invalid configuration
        """
        # Find out group_id
        group_id_idx = text.index(f"{constants.GROUP_ID}=") + len(
            f"{constants.GROUP_ID}="
        )
        group_id = parse_int(
            text[group_id_idx : text.index(",", group_id_idx)].strip(),
            allow_none_return=False,
        )

        # Find out type
        type_idx = text.index(f"{constants.GROUP_TYPE}=") + len(
            f"{constants.GROUP_TYPE}="
        )
        comma_idx = text.find(",", type_idx)
        type_str = text[type_idx : comma_idx if comma_idx != -1 else None].strip()
        try:
            group_type = GroupType(type_str)
        except ValueError:
            raise GroupError(f"invalid group type: {type_str}") from None

        # Check if common_bucket_id exists
        common_bucket_id = None
        if f"{constants.COMMON_BUCKET_ID}=" in text:
            common_bucket_id_idx = text.index(f"{constants.COMMON_BUCKET_ID}=") + len(
                f"{constants.COMMON_BUCKET_ID}="
            )
            common_bucket_id_str = text[
                common_bucket_id_idx : text.index(",", common_bucket_id_idx)
            ].strip()
            try:
                common_bucket_id = GroupCommonBucketID(common_bucket_id_str)
            except ValueError:
                raise GroupError(
                    f"invalid common bucket ID: {common_bucket_id_str}"
                ) from None

        # Find out buckets by buckets=actions=..., bucket=actions=... pattern
        buckets: list[Bucket] = []

        if parse_buckets:
            bucket_parts = text.split(f"{constants.BUCKET}=")
            for bucket_string in bucket_parts:
                bucket_string = bucket_string.strip().rstrip(",")
                if not bucket_string:
                    continue

                if bucket_string.startswith(f"{constants.BUCKET_ID}:"):
                    bucket_string = bucket_string[len(f"{constants.BUCKET_ID}:") :]
                    comma_idx = bucket_string.find(",")
                    if comma_idx != -1 and comma_idx + 1 < len(bucket_string):
                        bucket_string = bucket_string[comma_idx + 1 :].strip()
                    else:
                        continue

                if not bucket_string.startswith(f"{constants.ACTIONS}="):
                    continue

                bucket = Bucket.parse(bucket_string)
                buckets.append(bucket)

        return Group(
            id=group_id,
            type=group_type,
            buckets=buckets,
            common_bucket_id=common_bucket_id,
        )
