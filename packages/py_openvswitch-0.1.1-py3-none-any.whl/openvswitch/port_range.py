from __future__ import annotations

import math

from openvswitch.exceptions import InvalidPortRangeError


class BitRange:
    def __init__(self, value: int, mask: int):
        self.value: int = value
        self.mask: int = mask


class PortRange:
    def __init__(self, start: int, end: int):
        self.start: int = start
        self.end: int = end

    def bitwise_match(self) -> list[BitRange]:
        if self.start <= 0 or self.end <= 0:
            raise InvalidPortRangeError("Port values must be positive")

        if self.start > self.end:
            raise InvalidPortRangeError("Start port must be <= end port")

        # Single port case
        if self.start == self.end:
            return [BitRange(value=self.start, mask=0xFFFF)]

        bit_ranges = []

        # Find the largest window on a binary boundary
        window = (self.end - self.start) + 1
        bit_length = int(math.floor(math.log2(window)))

        range_start, range_end = self._get_range(self.end, bit_length)

        # Decrement mask until we fit inside the desired range
        while range_end > self.end:
            bit_length -= 1
            range_start, range_end = self._get_range(self.end, bit_length)

        current = BitRange(value=range_start, mask=self._get_mask(bit_length))

        # Handle left remainder
        if self.start != range_start:
            left_remainder = PortRange(start=self.start, end=range_start - 1)
            bit_ranges.extend(left_remainder.bitwise_match())

        # Add current range
        bit_ranges.append(current)

        # Handle right remainder
        if self.end != range_end:
            right_remainder = PortRange(start=range_end + 1, end=self.end)
            bit_ranges.extend(right_remainder.bitwise_match())

        return bit_ranges

    @staticmethod
    def _get_mask(bit_length: int) -> int:
        return 0xFFFF ^ ((1 << bit_length) - 1)

    @staticmethod
    def _get_range(end: int, bit_length: int) -> tuple[int, int]:
        range_length = (1 << bit_length) - 1

        # Zero out mask to start at binary boundary
        range_start = end & ~range_length

        # Add mask to end at binary boundary
        range_end = range_start + range_length

        return range_start, range_end
