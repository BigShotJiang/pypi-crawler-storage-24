from __future__ import annotations

from typing import TYPE_CHECKING

from openvswitch import action, constants
from openvswitch.exceptions import ActionError
from openvswitch.utils import parse_int

if TYPE_CHECKING:
    from openvswitch.action import Action


def parse_actions(text: str) -> list[Action]:
    text = text.strip()
    raw = _split_actions(text)
    actions = [a for s in raw if (a := parse_action(s)) is not None]
    return actions


def parse_action(s: str) -> Action | None:
    a = s.lower()

    # Simple actions
    if a == constants.ACTION_ALL:
        return action.All()

    elif a == constants.ACTION_DROP:
        return action.Drop()

    elif a == constants.ACTION_FLOOD:
        return action.Flood()

    elif a == constants.ACTION_IN_PORT:
        return action.InPort()

    elif a == constants.ACTION_LOCAL:
        return action.Local()

    elif a == constants.ACTION_NORMAL:
        return action.Normal()

    elif a == constants.ACTION_STRIP_VLAN:
        return action.StripVLAN()

    elif a == constants.ACTION_DEC_TTL:
        return action.DecTTL()

    # Output Actions

    elif (m := constants.RE_OUTPUT.match(s)) is not None:
        port_or_iff = m.group(1)
        assert port_or_iff is not None
        return action.Output(port_or_iff)

    elif (m := constants.RE_OUTPUT_LABEL.match(s)) is not None:
        field = m.group(1)
        assert field is not None
        return action.OutputField(field)

    # Modify Actions - Layer 2

    elif (m := constants.RE_MOD_DL_SRC.match(s)) is not None:
        addr = m.group(1)
        assert addr is not None
        return action.ModifyDataLinkSourceHardwareAddress(addr)

    elif (m := constants.RE_MOD_DL_DST.match(s)) is not None:
        addr = m.group(1)
        assert addr is not None
        return action.ModifyDataLinkDestinationHardwareAddress(addr)

    elif (m := constants.RE_SET_TUNNEL_ID.match(s)) is not None:
        tid = parse_int(m.group(1))
        assert tid is not None
        return action.SetTunnelID(tid)

    # Modify Actions - Layer 3
    elif (m := constants.RE_MOD_NW_SRC.match(s)) is not None:
        ip = m.group(1)
        assert ip is not None
        return action.ModifyNetworkSource(ip)

    elif (m := constants.RE_MOD_NW_DST.match(s)) is not None:
        ip = m.group(1)
        assert ip is not None
        return action.ModifyNetworkDestination(ip)

    # Modify Actions - Layer 4

    elif (m := constants.RE_MOD_TP_SRC.match(s)) is not None:
        port = parse_int(m.group(1))
        assert port is not None
        return action.ModifyTransportSourcePort(port)

    elif (m := constants.RE_MOD_TP_DST.match(s)) is not None:
        port = parse_int(m.group(1))
        assert port is not None
        return action.ModifyTransportDestinationPort(port)

    elif (m := constants.RE_MOD_VLAN_VID.match(s)) is not None:
        vid = parse_int(m.group(1))
        assert vid is not None
        return action.ModifyVLANVID(vid)

    # Connection Tracking Action

    elif (m := constants.RE_CT.match(s)) is not None:
        flags = m.group(1)
        assert flags is not None
        return action.ConnectionTracking(*[f.strip() for f in flags.split(",")])

    # Forwarding Actions
    elif (m := constants.RE_RESUBMIT.match(s)) is not None:
        port_str = m.group(1)
        table_str = m.group(2)
        port = parse_int(port_str) if port_str else None

        table = parse_int(table_str) if table_str else None
        assert table is not None

        return action.Resubmit(port, table)

    elif (m := constants.RE_RESUBMIT_PORT.match(s)) is not None:
        port = parse_int(m.group(1))
        assert port is not None
        return action.ResubmitPort(port)

    elif (m := constants.RE_GROUP.match(s)) is not None:
        group_id = parse_int(m.group(1))
        assert group_id is not None
        return action.Group(group_id)

    # Field Manipulation Actions
    elif (m := constants.RE_SET_FIELD.match(s)) is not None:
        value = m.group(1)
        assert value is not None
        field = m.group(2)
        assert field is not None
        return action.SetField(value, field)

    elif (m := constants.RE_LOAD_FIELD.match(s)) is not None:
        value = m.group(1)
        assert value is not None
        field = m.group(2)
        assert field is not None
        return action.Load(value, field)

    elif (m := constants.RE_MOVE.match(s)) is not None:
        src = m.group(1)
        assert src is not None

        dst = m.group(2)
        assert dst is not None

        return action.Move(src, dst)

    # Misc Actions
    elif (m := constants.RE_MULTIPATH.match(s)) is not None:
        fields = m.group(1)
        assert isinstance(fields, str), "fields should have been parsed"

        basis = parse_int(m.group(2), allow_none_return=False)

        algorithm_str = str(m.group(3)).lower()
        try:
            algorithm = action.MultipathAlgorithm(algorithm_str)
        except ValueError:
            raise ActionError(f"invalid multipath algorithm: {algorithm_str}") from None

        nlinks = parse_int(m.group(4), allow_none_return=False)
        arg = parse_int(m.group(5), allow_none_return=False)

        dst = m.group(6)
        assert isinstance(dst, str), "dst should have been parsed"

        return action.Multipath(
            fields,
            basis,
            algorithm,
            nlinks,
            arg,
            dst,
        )

    elif (m := constants.RE_LEARN.match(s)) is not None:
        return action.Learn.parse(str(m.group(1)))

    return None


def _split_actions(text: str) -> list[str]:
    parts: list[str] = []
    start = 0
    depth = 0

    for i, ch in enumerate(text):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth < 0:
                raise ActionError(f'invalid action: "{text}"')
        elif ch == "," and depth == 0:
            parts.append(text[start:i].strip())
            start = i + 1

    # last segment
    tail = text[start:].strip()
    if tail:
        parts.append(tail)

    if depth != 0:
        raise ActionError(f'invalid action: "{text}"')

    # drop empties (e.g., trailing commas)
    return [p for p in parts if p]
