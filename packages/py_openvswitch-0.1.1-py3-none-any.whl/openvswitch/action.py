from __future__ import annotations

from enum import Enum

from typing_extensions import override

from openvswitch import constants, match
from openvswitch.exceptions import ActionError
from openvswitch.match import Match
from openvswitch.utils import obj_repr, validate_ip, validate_mac, validate_vlan_id


class MultipathAlgorithm(Enum):
    MODULO_N = "modulo_n"
    HASH_THRESHOLD = "hash_threshold"
    HIGHEST_RANDOM_WEIGHT = "hrw"
    ITERATIVE_HASH = "iter_hash"


class Action:
    def __init__(self, action: str) -> None:
        self.action: str = action

    def marshal_text(self) -> str:
        """
        Converts the action to OVS action syntax.

        Returns:
            str: Action in OVS text format
        """
        return self.action

    @override
    def __str__(self) -> str:
        return self.marshal_text()

    @override
    def __repr__(self) -> str:
        return obj_repr(self, exclude=("action",))


# Simple Actions (With no parameters)


class All(Action):
    def __init__(self) -> None:
        super().__init__(constants.ACTION_ALL)


class Drop(Action):
    def __init__(self) -> None:
        super().__init__(constants.ACTION_DROP)


class Flood(Action):
    def __init__(self) -> None:
        super().__init__(constants.ACTION_FLOOD)


class InPort(Action):
    def __init__(self) -> None:
        super().__init__(constants.ACTION_IN_PORT)


class Local(Action):
    def __init__(self) -> None:
        super().__init__(constants.ACTION_LOCAL)


class Normal(Action):
    def __init__(self) -> None:
        super().__init__(constants.ACTION_NORMAL)


class StripVLAN(Action):
    def __init__(self) -> None:
        super().__init__(constants.ACTION_STRIP_VLAN)


class DecTTL(Action):
    def __init__(self) -> None:
        super().__init__(constants.ACTION_DEC_TTL)


# Output Actions


class Output(Action):
    def __init__(self, port_or_interface: str) -> None:
        self.port_or_interface: str = port_or_interface
        super().__init__(constants.PAT_OUTPUT.format(self.port_or_interface))


class OutputField(Action):
    def __init__(self, field: str) -> None:
        self.field: str = field
        super().__init__(constants.PAT_OUTPUT_FIELD.format(self.field))


# Modify Actions - Layer 2


class ModifyDataLinkSourceHardwareAddress(Action):
    def __init__(self, addr: str) -> None:
        mac = validate_mac(addr)
        super().__init__(constants.PAT_MOD_DL_SRC.format(mac))


class ModifyDataLinkDestinationHardwareAddress(Action):
    def __init__(self, addr: str) -> None:
        mac = validate_mac(addr)
        super().__init__(constants.PAT_MOD_DL_DST.format(mac))


class SetTunnelID(Action):
    def __init__(self, tunnel_id: int) -> None:
        self.tunnel_id: int = tunnel_id
        super().__init__(constants.PAT_SET_TUNNEL_ID.format(f"{self.tunnel_id:#x}"))


# Modify Actions - Layer 3


class ModifyNetworkSource(Action):
    def __init__(self, ip: str) -> None:
        ipv4 = validate_ip(ip, version=4)
        super().__init__(constants.PAT_MOD_NW_SRC.format(ipv4))


class ModifyNetworkDestination(Action):
    def __init__(self, ip: str) -> None:
        ipv4 = validate_ip(ip, version=4)
        super().__init__(constants.PAT_MOD_NW_DST.format(ipv4))


# Modify Actions - Layer 4


class ModifyTransportSourcePort(Action):
    def __init__(self, port: int) -> None:
        self.port: int = port
        super().__init__(constants.PAT_MOD_TP_SRC.format(self.port))


class ModifyTransportDestinationPort(Action):
    def __init__(self, port: int) -> None:
        self.port: int = port
        super().__init__(constants.PAT_MOD_TP_DST.format(self.port))


class ModifyVLANVID(Action):
    def __init__(self, vid: int) -> None:
        self.vid: int = vid

        super().__init__(constants.PAT_MOD_VLAN_VID.format(validate_vlan_id(vid)))


# Connection Tracking Action


class ConnectionTracking(Action):
    def __init__(self, *args: str) -> None:
        self.args: list[str] = list(args)

        super().__init__(constants.PAT_CT.format(",".join(self.args)))


# Forwarding Action


class Resubmit(Action):
    def __init__(self, port: int | None, table: int) -> None:
        self.port: int | None = port
        self.table: int = table

        if self.port is None:
            port_str = ""
        else:
            port_str = str(self.port)

        super().__init__(constants.PAT_RESUBMIT_PT.format(port_str, str(self.table)))


class ResubmitPort(Action):
    def __init__(self, port: int) -> None:
        self.port: int = port
        if self.port < 0 or self.port > 0xFFFFFEFF:
            raise ActionError(constants.ERR_RESUBMIT_PORT_INVALID)
        super().__init__(constants.PAT_RESUBMIT.format(str(int(self.port))))


class Group(Action):
    def __init__(self, group_id: int) -> None:
        self.group_id: int = group_id
        super().__init__(constants.PAT_GROUP.format(str(self.group_id)))


# Field Manipulation Actions


class SetField(Action):
    def __init__(self, value: str, field: str) -> None:
        self.value: str = value
        self.field: str = field
        if not self.value or not self.field:
            raise ActionError(constants.ERR_LOAD_SET_FIELD_ZERO)

        super().__init__(constants.PAT_SET_FIELD.format(self.value, self.field))


class Load(Action):
    def __init__(self, value: str, field: str) -> None:
        self.value: str = value
        self.field: str = field
        if not self.value or not self.field:
            raise ActionError(constants.ERR_LOAD_SET_FIELD_ZERO)

        if self.value.startswith("0x"):
            self.formatted_value: int = int(self.value, 16)

        super().__init__(constants.PAT_LOAD_FIELD.format(self.value, self.field))


class Move(Action):
    def __init__(self, src: str, dst: str) -> None:
        self.src: str = src
        self.dst: str = dst
        if not self.src or not self.dst:
            raise ActionError(constants.ERR_MOVE_EMPTY)
        super().__init__(constants.PAT_MOVE.format(self.src, self.dst))


# Miscellaneous Actions


class Multipath(Action):
    def __init__(
        self,
        fields: str,
        basis: int,
        algorithm: MultipathAlgorithm,
        nlinks: int,
        arg: int,
        dst: str,
    ) -> None:
        self.fields: str = fields
        self.basis: int = basis
        self.algorithm: MultipathAlgorithm = algorithm
        self.nlinks: int = nlinks
        self.arg: int = arg
        self.dst: str = dst
        super().__init__(
            constants.PAT_MULTIPATH.format(
                fields,
                basis,
                algorithm.value,
                nlinks,
                arg,
                dst,
            )
        )


class Conjunction(Action):
    def __init__(self, id: int, dimension_number: int, dimension_size: int) -> None:  # noqa: A002
        self.id: int = id
        self.dimension_number: int = dimension_number
        self.dimension_size: int = dimension_size
        if self.dimension_number > self.dimension_size:
            raise ActionError(constants.ERR_DIMENSION_TOO_LARGE)
        super().__init__(
            constants.PAT_CONJUNCTION.format(
                int(self.id), int(self.dimension_number), int(self.dimension_size)
            )
        )


class Learn(Action):
    def __init__(  # pyright: ignore[reportMissingSuperCall]
        self,
        table: int | None = None,
        priority: int | None = None,
        hard_timeout: int | None = None,
        idle_timeout: int | None = None,
        fin_hard_timeout: int | None = None,
        fin_idle_timeout: int | None = None,
        cookie: int | None = None,
        send_flow_rem: bool = False,
        delete_learned: bool = False,
        specs: str | list[Action | Match] | None = None,
    ) -> None:
        # Store well-known parameters
        self.table: int | None = table
        self.priority: int | None = priority
        self.hard_timeout: int | None = hard_timeout
        self.idle_timeout: int | None = idle_timeout
        self.fin_hard_timeout: int | None = fin_hard_timeout
        self.fin_idle_timeout: int | None = fin_idle_timeout
        self.cookie: int | None = cookie
        self.send_flow_rem: bool = send_flow_rem
        self.delete_learned: bool = delete_learned

        self.specs: str | list[Action | Match] | None = specs

    @override
    def marshal_text(self) -> str:
        data = ""

        # Table
        if self.table is not None:
            data += f"{constants.TABLE}={self.table},"

        # Priority
        if self.priority is not None:
            data += f"{constants.PRIORITY}={self.priority},"

        # Timeouts
        if self.hard_timeout is not None:
            data += f"{constants.HARD_TIMEOUT}={self.hard_timeout},"

        if self.idle_timeout is not None:
            data += f"{constants.IDLE_TIMEOUT}={self.idle_timeout},"

        if self.fin_hard_timeout is not None:
            data += f"{constants.FIN_HARD_TIMEOUT}={self.fin_hard_timeout},"

        if self.fin_idle_timeout is not None:
            data += f"{constants.FIN_IDLE_TIMEOUT}={self.fin_idle_timeout},"

        # Cookie
        if self.cookie is not None:
            data += f"{constants.COOKIE}=0x{self.cookie:X},"

        # Flags
        if self.send_flow_rem:
            data += f"{constants.SEND_FLOW_REM},"

        if self.delete_learned:
            data += f"{constants.DELETE_LEARNED},"

        if self.specs:
            if isinstance(self.specs, str):
                data += self.specs
            else:
                data += ",".join(str(spec) for spec in self.specs)

        return constants.PAT_LEARN.format(data.rstrip(","))

    @classmethod
    def parse(cls, text: str) -> Learn:
        text = text.strip()
        if not text:
            raise ActionError("Empty learn specification")

        f = Learn()
        f.specs = []

        ss = text.split(",")
        for s in ss:
            if "=" not in s:
                if (val := s.strip()) != "":
                    # It could be delete_learned flag

                    if val == "delete_learned":
                        f.delete_learned = True
                        continue

                    elif val == "send_flow_rem":
                        f.send_flow_rem = True
                        continue

                    elif "->" in s and val.startswith("load:"):
                        ss = s[5:].split("->")
                        f.specs.append(Load(value=ss[0].strip(), field=ss[1].strip()))

                    elif "[" in val and "]" in val:
                        # NXM_OF_VLAN_TCI[0..11], it's a shorthand for NXM_OF_VLAN_TCI[0..11]=NXM_OF_VLAN_TCI[0..11]
                        f.specs.append(match.NXMFieldComparison(dst=val, src=val))
                continue

            key, value = s.split("=", 1)
            key = key.strip()

            value = value.strip()
            if key == constants.TABLE:
                f.table = int(value)
            elif key == constants.PRIORITY:
                f.priority = int(value)
            elif key == constants.HARD_TIMEOUT:
                f.hard_timeout = int(value)
            elif key == constants.IDLE_TIMEOUT:
                f.idle_timeout = int(value)
            elif key == constants.FIN_HARD_TIMEOUT:
                f.fin_hard_timeout = int(value)
            elif key == constants.FIN_IDLE_TIMEOUT:
                f.fin_idle_timeout = int(value)
            elif key == constants.COOKIE:
                f.cookie = int(value)
            elif "[" in key and "]" in key and "[" in value and "]" in value:
                f.specs.append(match.NXMFieldComparison(dst=key, src=value))
            else:
                from openvswitch.action_parser import parse_action

                # try to match known actions
                action = parse_action(s)
                if action is not None:
                    f.specs.append(action)

        return f
