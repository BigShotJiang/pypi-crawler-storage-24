import re

from dataclasses import dataclass, replace

from openvswitch.exceptions import TableParseError
from openvswitch.utils import obj_repr


@dataclass
class Table:
    id: int
    active: int = 0
    lookup: int = 0
    matched: int = 0
    max_entries: int = 0

    @classmethod
    def parse(cls, text: str) -> "Table":
        """
        Parses an OVS table dump text into a Table object.

        Args:
            text: Table dump text from OVS

        Returns:
            Table: Parsed table object

        Raises:
            TableParseError: If table text is invalid or empty
        """
        text = text.strip()

        if not text:
            raise TableParseError("Empty table entry")

        lines = text.split("\n")

        # Parse table ID from first line: "table 0:"
        first_line = lines[0].strip()
        match = re.match(r"table\s+(\d+):", first_line)
        if not match:
            raise TableParseError(f"Could not parse table ID from: {first_line}")

        table_id = int(match.group(1))

        # Initialize values
        active = 0
        lookup = 0
        matched = 0
        max_entries = 0

        # Parse remaining lines
        for line in lines[1:]:
            line = line.strip()

            # Skip empty lines and matching section
            if (
                not line
                or line.startswith("matching:")
                or line.startswith("exact match")
            ):
                continue

            # Parse key=value pairs
            if "active=" in line or "lookup=" in line or "matched=" in line:
                # Line like: "active=1, lookup=0, matched=0"
                pairs = line.split(",")
                for pair in pairs:
                    pair = pair.strip()
                    if "=" in pair:
                        key, value = pair.split("=", 1)
                        key = key.strip()
                        value = value.strip()

                        if key == "active":
                            active = int(value)
                        elif key == "lookup":
                            lookup = int(value)
                        elif key == "matched":
                            matched = int(value)

            elif "max_entries=" in line:
                match = re.search(r"max_entries=(\d+)", line)
                if match:
                    max_entries = int(match.group(1))

        return cls(
            id=table_id,
            active=active,
            lookup=lookup,
            matched=matched,
            max_entries=max_entries,
        )

    def __repr__(self) -> str:
        return obj_repr(self)


def parse_tables(text: str) -> dict[int, Table]:
    """
    Parses multiple OVS table dumps into a dictionary of Table objects.

    Args:
        text: Table dumps text from OVS dump-tables command

    Returns:
        dict[int, Table]: Dictionary mapping table IDs to Table objects

    Raises:
        TableParseError: If output is empty
    """
    output = text.strip()
    if not output:
        raise TableParseError("Empty output")

    lines = output.split("\n")
    tables: dict[int, Table] = {}
    current_entry: list[str] = []
    last_full_table: Table | None = None

    def save_current_entry(copy_features_from_last: bool = False) -> None:
        """Parse and save the current entry being collected."""
        nonlocal last_full_table
        if not current_entry:
            return

        entry_text = "\n".join(current_entry)
        try:
            table = Table.parse(entry_text)
            tables[table.id] = table
            if copy_features_from_last and last_full_table:
                table.max_entries = last_full_table.max_entries
            last_full_table = table
        except TableParseError:
            pass  # Skip invalid entries

    for line in lines:
        stripped = line.strip()

        # Skip header line
        if stripped.startswith("OFPST_TABLE"):
            continue

        # Handle "tables X...Y: ditto" notation
        if stripped.startswith("tables") and "ditto" in stripped:
            save_current_entry()
            current_entry = []

            match = re.match(r"tables\s+(\d+)\.\.\.(\d+):\s*ditto", stripped)
            if match and last_full_table:
                start, end = int(match.group(1)), int(match.group(2))
                for table_id in range(start, end + 1):
                    tables[table_id] = replace(last_full_table, id=table_id)
            continue

        # Handle "(same features)" notation
        if "(same features)" in stripped:
            save_current_entry(copy_features_from_last=True)
            current_entry = []
            continue

        # Start of a new table entry
        if stripped.startswith("table"):
            save_current_entry()
            current_entry = [line]
        elif current_entry and stripped:
            # Continue collecting lines for current entry
            current_entry.append(line)

    # Parse any remaining entry
    save_current_entry()

    return tables
