from __future__ import annotations

import re

"""
Few assumptions while defining constants:
1. All constants are defined in UPPER_SNAKE_CASE.
2. Few constants has specific suffixes.
  - PAT_    : These are format string patterns.
  - RE_     : These are regex patterns.
  - ERR_    : These are error message strings.
  - ACTION_ : These are action string constants. Defined for single ovs flow actions.
  - For other constants, the name is same as the string value.

3. Constants are grouped by their usage.
"""

# Flow Related
PRIORITY = "priority"
TABLE = "table"
IDLE_TIMEOUT = "idle_timeout"
HARD_TIMEOUT = "hard_timeout"
FIN_HARD_TIMEOUT = "fin_hard_timeout"
FIN_IDLE_TIMEOUT = "fin_idle_timeout"
SEND_FLOW_REM = "send_flow_rem"
LIMIT = "limit"
DELETE_LEARNED = "delete_learned"
COOKIE = "cookie"
ACTIONS = "actions"
N_PACKETS = "n_packets"
N_BYTES = "n_bytes"
DURATION = "duration"
HARD_AGE = "hard_age"
IDLE_AGE = "idle_age"

PORT_LOCAL_STRING = "LOCAL"
PORT_LOCAL_INT = -1

# Action & Match Related Constants
ARP_OP = "arp_op"
ARP_SHA = "arp_sha"
ARP_SPA = "arp_spa"
ARP_THA = "arp_tha"
ARP_TPA = "arp_tpa"
CONJ_ID = "conj_id"
CT_MARK = "ct_mark"
CT_STATE = "ct_state"
CT_ZONE = "ct_zone"
DL_DST = "dl_dst"
DL_SRC = "dl_src"
DL_TYPE = "dl_type"
DL_VLAN = "dl_vlan"
DL_VLAN_PCP = "dl_vlan_pcp"
ICMPV6_CODE = "icmpv6_code"
ICMPV6_TYPE = "icmpv6_type"
ICMP_CODE = "icmp_code"
ICMP_TYPE = "icmp_type"
ND_SLL = "nd_sll"
ND_TLL = "nd_tll"
ND_TARGET = "nd_target"
IPV6_DST = "ipv6_dst"
IPV6_LABEL = "ipv6_label"
IPV6_SRC = "ipv6_src"
METADATA = "metadata"
NW_DST = "nw_dst"
NW_ECN = "nw_ecn"
NW_PROTO = "nw_proto"
NW_SRC = "nw_src"
NW_TOS = "nw_tos"
NW_TTL = "nw_ttl"
TP_DST = "tp_dst"
TP_SRC = "tp_src"
TUN_DST = "tun_dst"
TCP_DST = "tcp_dst"
TCP_SRC = "tcp_src"
TCP_FLAGS = "tcp_flags"
TUN_ID = "tun_id"
TUN_SRC = "tun_src"
TUN_IPV6_DST = "tun_ipv6_dst"
TUN_IPV6_SRC = "tun_ipv6_src"
VLAN_TCI = "vlan_tci"
VLAN_TCI1 = "vlan_tci1"
UDP_DST = "udp_dst"
UDP_SRC = "udp_src"
IN_PORT = "in_port"
REG_PREFFIX = "reg"
EXTENDED_REG_PREFIX = "xreg"
DOUBLE_EXTENDED_REG_PREFIX = "xxreg"
GROUP_ID = "group_id"
GROUP_TYPE = "type"
BUCKET = "bucket"
BUCKET_ID = "bucket_id"
COMMON_BUCKET_ID = "common_bucket_id"

# Action Related Constants
ACTION_ALL = "all"
ACTION_DROP = "drop"
ACTION_FLOOD = "flood"
ACTION_IN_PORT = "in_port"
ACTION_LOCAL = "local"
ACTION_NORMAL = "normal"
ACTION_STRIP_VLAN = "strip_vlan"
ACTION_DEC_TTL = "dec_ttl"


# Patterns for action formatting
PAT_CT = "ct({})"
PAT_MULTIPATH = "multipath({},{},{},{},{},{})"
PAT_CONJUNCTION = "conjunction({},{}/{})"
PAT_MOD_DL_DST = "mod_dl_dst:{}"
PAT_MOD_DL_SRC = "mod_dl_src:{}"
PAT_MOD_NW_DST = "mod_nw_dst:{}"
PAT_MOD_NW_SRC = "mod_nw_src:{}"
PAT_MOD_TP_DST = "mod_tp_dst:{}"
PAT_MOD_TP_SRC = "mod_tp_src:{}"
PAT_MOD_VLAN_VID = "mod_vlan_vid:{}"
PAT_SET_TUNNEL_ID = "set_tunnel:{}"
PAT_OUTPUT = "output:{}"
PAT_OUTPUT_FIELD = 'output:"{}"'
PAT_RESUBMIT = "resubmit:{}"
PAT_RESUBMIT_PT = "resubmit({},{})"
PAT_LEARN = "learn({})"
PAT_GROUP = "group:{}"
PAT_SET_FIELD = "set_field:{}->{}"
PAT_LOAD_FIELD = "load:{}->{}"
PAT_MOVE = "move:{}->{}"

# Regexes
RE_CT = re.compile(r"^ct\((\S+)\)$")
RE_MULTIPATH = re.compile(
    r"^multipath\(\s*fields\s*=\s*([^,]+)\s*,\s*basis\s*=\s*(\d+)\s*,\s*algorithm\s*=\s*([^,]+)\s*,\s*n_links\s*=\s*(\d+)\s*,\s*arg\s*=\s*(\d+)\s*,\s*dst\s*=\s*([^)]+)\s*\)$"
)
RE_CONJUNCTION = re.compile(r"^conjunction\((\d+),(\d+)/(\d+)\)$")
RE_MOD_DL_DST = re.compile(r"^mod_dl_dst:([0-9A-Fa-f:]+)$")
RE_MOD_DL_SRC = re.compile(r"^mod_dl_src:([0-9A-Fa-f:]+)$")
RE_MOD_NW_DST = re.compile(r"^mod_nw_dst:([0-9\.]+)$")
RE_MOD_NW_SRC = re.compile(r"^mod_nw_src:([0-9\.]+)$")
RE_MOD_TP_DST = re.compile(r"^mod_tp_dst:(\d+)$")
RE_MOD_TP_SRC = re.compile(r"^mod_tp_src:(\d+)$")
RE_MOD_VLAN_VID = re.compile(r"^mod_vlan_vid:(\d+)$")
RE_SET_TUNNEL_ID = re.compile(r"^set_tunnel:(0x[0-9a-fA-F]+|\d+)$")
RE_OUTPUT = re.compile(r"^output:(-?\d+|[A-Za-z_][A-Za-z0-9_]*)$")
RE_OUTPUT_LABEL = re.compile(r"^output:\"(\S+)\"$")
RE_RESUBMIT = re.compile(r"^resubmit\((\d*),(\d*)\)$")
RE_RESUBMIT_PORT = re.compile(r"^resubmit:(\d+)$")
RE_LEARN = re.compile(r"^learn\((\S+)\)$")
RE_GROUP = re.compile(r"^group:(\d+)$")
RE_SET_FIELD = re.compile(r"^set_field:(\S+)->(\S+)$")
RE_LOAD_FIELD = re.compile(r"^load:(\S+)->(\S+)$")
RE_MOVE = re.compile(r"^move:(\S+)->(\S+)$")
RE_FLOW_STATS_PACKET_COUNT = re.compile(r"packet_count=(\d+)")
RE_FLOW_STATS_BYTE_COUNT = re.compile(r"byte_count=(\d+)")
RE_BRIDGE_NOT_FOUND = re.compile(r'ovs-vsctl:\s*no bridge named ([^"]+)')
RE_PORT_NOT_FOUND = re.compile(r'ovs-vsctl:\s*no port named ([^"]+)')
RE_PORT_NOT_FOUND_2 = re.compile(r'ovs-vsctl:\s*no row "([^"]+)" in table Port')
RE_BRIDGE_MISSING = re.compile(r'ovs-vsctl:\s*no row "([^"]+)" in table Bridge')
RE_INTERFACE_MISSING = re.compile(r'ovs-vsctl:\s*no row "([^"]+)" in table Interface')
RE_QUEUE_MISSING = re.compile(r'ovs-vsctl:\s*no row "([^"]+)" in table Queue')
RE_QOS_MISSING = re.compile(r'ovs-vsctl:\s*no row "([^"]+)" in table QoS')
RE_COLUMN_BAD = re.compile(
    r'ovs-vsctl:\s*Bridge does not contain a column whose name matches "([^"]+)"'
)

# Error Messages
ERR_CT_NO_ARGUMENTS = "no arguments for connection tracking"
ERR_INVALID_IPV6_LABEL = "IPv6 label must only use 20 bits"
ERR_INVALID_ARP_OP = "ARP OP must in the range 1-4"
ERR_INVALID_VLAN_VID = "VLAN VID must be between 0 and 4095"
ERR_INVALID_VLAN_PCP = "VLAN PCP must be between 0 and 7"
ERR_OUTPUT_NEGATIVE_PORT = "output port number must not be negative"
ERR_RESUBMIT_PORT_TABLE_ZERO = "both port and table are zero for action resubmit"
ERR_LOAD_SET_FIELD_ZERO = "value and/or field for action load or set_field are empty"
ERR_RESUBMIT_PORT_INVALID = "resubmit port must be between 0 and 65279 inclusive"
ERR_DIMENSION_TOO_LARGE = "dimension number exceeds total number of dimensions"
ERR_MOVE_EMPTY = "src and/or dst field for action move are empty"
ERR_OUTPUT_FIELD_EMPTY = "field for action output (output:field syntax) is empty"
ERR_LEARNED_NIL = "learned flow for action learn is nil"
ERR_NO_ACTIONS = "no actions specified for flow"
ERR_ACTIONS_WITH_DROP = "flow actions include drop, but multiple actions specified"
ERR_BUCKET_NO_ACTIONS = "bucket must have at least one action"
ERR_INVALID_GROUP_TYPE = "invalid group type"
