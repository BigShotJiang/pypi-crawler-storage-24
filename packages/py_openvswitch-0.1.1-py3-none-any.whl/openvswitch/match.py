from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from typing_extensions import override

from openvswitch import constants
from openvswitch.exceptions import OpenFlowError
from openvswitch.utils import (
    obj_repr,
    validate_arp_op,
    validate_cidr,
    validate_ip,
    validate_mac,
)

"""
1st Note : The classes and functions in this module are designed to represent
OVS match fields and parsing logic. They provide a structured way to create,
manipulate, and serialize match criteria for Open vSwitch flows.

Each class should have it's own validation logic to ensure that the values
conform to OVS specifications.

Validation will be done during adding flow or parsing during flow retrieval.

Why during parsing, we are running validation ? - To ensure that any existing flows in OVS are valid
and can be represented correctly in this module.

----

2nd Note : While adding / removing / modifying order of classes, please ensure
to keep the same order in match_parser.py for easier maintenance.

Also, ensure to add the newly added match class in the parse_match function
in match_parser.py.
"""


class CTState(Enum):
    NEW = "new"
    ESTABLISHED = "est"
    TRACKED = "trk"
    RELATED = "rel"
    REPLY = "rpl"
    INVALID = "inv"
    SNAT = "snat"
    DNAT = "dnat"

    def __pos__(self) -> SetCTState:
        """Return a SetCTState for this CTState (e.g., +CTState.NEW)."""
        return SetCTState(self)

    def __neg__(self) -> UnsetCTState:
        """Return an UnsetCTState for this CTState (e.g., -CTState.NEW)."""
        return UnsetCTState(self)


class TCPFlag(Enum):
    URG = "urg"
    ACK = "ack"
    PSH = "psh"
    RST = "rst"
    SYN = "syn"
    FIN = "fin"

    def __pos__(self) -> SetTCPFlag:
        """Return a SetTCPFlag for this flag (e.g., +TCPFlag.SYN)."""
        return SetTCPFlag(self)

    def __neg__(self) -> UnsetTCPFlag:
        """Return an UnsetTCPFlag for this flag (e.g., -TCPFlag.SYN)."""
        return UnsetTCPFlag(self)


@dataclass
class Match:
    key: str
    value: str

    def marshal_text(self) -> str:
        """
        Converts the match to OVS match field syntax.

        Returns:
            str: Match field in OVS text format
        """
        return f"{self.key}={self.value}"

    @override
    def __str__(self) -> str:
        return self.marshal_text()

    @override
    def __repr__(self) -> str:
        return obj_repr(self, exclude=("key", "value"))


# Input Interface (First level of packet identification)


class InPort(Match):
    def __init__(self, port: int) -> None:
        self.port: int = port
        super().__init__(constants.IN_PORT, str(self.port))


class InPortLabel(Match):
    def __init__(self, port: str) -> None:
        self.port: str = port
        super().__init__(constants.IN_PORT, f'"{self.port}"')


# Tunnel Fields (Processed before input packet headers)


class TunnelID(Match):
    def __init__(self, tid: int, mask: int | None = None) -> None:
        self.tid: int = tid
        self.mask: int | None = mask
        if self.mask is not None:
            value = f"0x{self.tid:x}/0x{self.mask:x}"
        else:
            value = f"0x{self.tid:x}"
        super().__init__(constants.TUN_ID, value)


class TunnelSource(Match):
    def __init__(self, ip: str) -> None:
        self.ip: str = validate_ip(ip, version=4)
        super().__init__(constants.TUN_SRC, self.ip)


class TunnelDestination(Match):
    def __init__(self, ip: str) -> None:
        self.ip: str = validate_ip(ip, version=4)
        super().__init__(constants.TUN_DST, self.ip)


class TunnelIPv6Source(Match):
    def __init__(self, ip: str) -> None:
        self.ip: str = validate_ip(ip, version=6)
        super().__init__(constants.TUN_IPV6_SRC, self.ip)


class TunnelIPv6Destination(Match):
    def __init__(self, ip: str) -> None:
        self.ip: str = validate_ip(ip, version=6)
        super().__init__(constants.TUN_IPV6_DST, self.ip)


class VLANTagControlInfo(Match):
    def __init__(self, tci: int, mask: int | None = None) -> None:
        self.tci: int = tci
        self.mask: int | None = mask
        if self.mask is not None:
            value_str = f"{self.tci}/{self.mask}"
        else:
            value_str = str(self.tci)

        super().__init__(constants.VLAN_TCI, value_str)


class InnerVLANTagControlInfo(Match):
    def __init__(self, tci: int, mask: int | None = None) -> None:
        self.tci1: int = tci
        self.mask: int | None = mask
        if self.mask is not None:
            value_str = f"{self.tci1}/{self.mask}"
        else:
            value_str = str(self.tci1)
        super().__init__(constants.VLAN_TCI1, value_str)


# Connection Tracking


class SetCTState:
    """Represents setting a CT state (e.g., '+trk')."""

    def __init__(self, state: CTState) -> None:
        self.state: CTState = state

    def marshal_text(self) -> str:
        return f"+{self.state.value}"

    @override
    def __str__(self) -> str:
        return self.marshal_text()

    @override
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.state.name})"


class UnsetCTState:
    """Represents unsetting a CT state (e.g., '-trk')."""

    def __init__(self, state: CTState) -> None:
        self.state: CTState = state

    def marshal_text(self) -> str:
        return f"-{self.state.value}"

    @override
    def __str__(self) -> str:
        return self.marshal_text()

    @override
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.state.name})"


class ConnectionTrackingState(Match):
    def __init__(self, *states: SetCTState | UnsetCTState) -> None:
        self.states: list[SetCTState | UnsetCTState] = list(states)
        super().__init__(
            constants.CT_STATE, "".join(str(state) for state in self.states)
        )


class ConnectionTrackingMark(Match):
    def __init__(self, mark: int, mask: int | None = None) -> None:
        self.mark: int = mark
        self.mask: int | None = mask
        if self.mask is not None:
            value = f"{self.mark}/{self.mask}"
        else:
            value = str(self.mark)
        super().__init__(constants.CT_MARK, value)


class ConnectionTrackingZone(Match):
    def __init__(self, zone: int) -> None:
        self.zone: int = zone
        super().__init__(constants.CT_ZONE, str(self.zone))


# Metadata & Registers (OVS internal state)


class Metadata(Match):
    def __init__(self, id: int, mask: int | None = None) -> None:
        self.id: int = id
        self.mask: int | None = mask
        if self.mask is not None:
            value = f"{self.id}/{self.mask}"
        else:
            value = str(self.id)
        super().__init__(constants.METADATA, value)


class ConjunctionID(Match):
    def __init__(self, cid: int) -> None:
        self.cid: int = cid
        super().__init__(constants.CONJ_ID, str(self.cid))


class RegisterX(Match):
    def __init__(self, id: int, val: int) -> None:
        self._id: int = id
        self.val: int = val
        super().__init__(f"{constants.REG_PREFFIX}{self._id}", f"0x{self.val:x}")


class ExtendedRegisterX(Match):
    def __init__(self, id: int, val: int) -> None:
        self._id: int = id
        self.val: int = val
        super().__init__(
            f"{constants.EXTENDED_REG_PREFIX}{self._id}", f"0x{self.val:x}"
        )


class DoubleExtendedRegisterX(Match):
    def __init__(self, id: int, val: int) -> None:
        self._id: int = id
        self.val: int = val
        super().__init__(
            f"{constants.DOUBLE_EXTENDED_REG_PREFIX}{self._id}",
            f"0x{self.val:x}",
        )


class Register0(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(0, value)


class Register1(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(1, value)


class Register2(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(2, value)


class Register3(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(3, value)


class Register4(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(4, value)


class Register5(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(5, value)


class Register6(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(6, value)


class Register7(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(7, value)


class Register8(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(8, value)


class Register9(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(9, value)


class Register10(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(10, value)


class Register11(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(11, value)


class Register12(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(12, value)


class Register13(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(13, value)


class Register14(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(14, value)


class Register15(RegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(15, value)


class ExtendedRegister0(ExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(0, value)


class ExtendedRegister1(ExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(1, value)


class ExtendedRegister2(ExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(2, value)


class ExtendedRegister3(ExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(3, value)


class ExtendedRegister4(ExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(4, value)


class ExtendedRegister5(ExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(5, value)


class ExtendedRegister6(ExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(6, value)


class ExtendedRegister7(ExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(7, value)


class DoubleExtendedRegister0(DoubleExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(0, value)


class DoubleExtendedRegister1(DoubleExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(1, value)


class DoubleExtendedRegister2(DoubleExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(2, value)


class DoubleExtendedRegister3(DoubleExtendedRegisterX):
    def __init__(self, value: int) -> None:
        super().__init__(3, value)


# Layer 2 - Data Link


class DataLinkSource(Match):
    def __init__(self, addr: str, mask: str | None) -> None:
        self.addr: str = validate_mac(addr)
        self.mask: str | None = validate_mac(mask) if mask else None
        if self.mask:
            super().__init__(constants.DL_SRC, f"{self.addr}/{self.mask}")
        else:
            super().__init__(constants.DL_SRC, self.addr)


class DataLinkDestination(Match):
    def __init__(self, addr: str, mask: str | None) -> None:
        self.addr: str = validate_mac(addr)
        self.mask: str | None = validate_mac(mask) if mask else None
        if self.mask:
            super().__init__(constants.DL_DST, f"{self.addr}/{self.mask}")
        else:
            super().__init__(constants.DL_DST, self.addr)


class DataLinkType(Match):
    def __init__(self, ether_type: int) -> None:
        self.ether_type: int = ether_type
        super().__init__(constants.DL_TYPE, f"0x{self.ether_type:04x}")


class DataLinkVLAN(Match):
    def __init__(self, vid: int) -> None:
        self.vid: int = vid
        super().__init__(constants.DL_VLAN, str(self.vid))


class DataLinkVLANPCP(Match):
    def __init__(self, pcp: int) -> None:
        self.pcp: int = pcp
        super().__init__(constants.DL_VLAN_PCP, str(self.pcp))


# Layer 3 - Network

# L3 IPV4


class NetworkSource(Match):
    def __init__(self, ip: str, cidr: int = 32) -> None:
        self.ip: str = validate_ip(ip, version=4)
        self.cidr: int = validate_cidr(cidr)
        super().__init__(constants.NW_SRC, f"{self.ip}/{self.cidr}")


class NetworkDestination(Match):
    def __init__(self, ip: str, cidr: int = 32) -> None:
        self.ip: str = validate_ip(ip, version=4)
        self.cidr: int = validate_cidr(cidr, version=4)
        super().__init__(constants.NW_DST, f"{self.ip}/{self.cidr}")


class NetworkTOS(Match):
    def __init__(self, tos: int) -> None:
        self.tos: int = tos
        super().__init__(constants.NW_TOS, str(self.tos))


class NetworkECN(Match):
    def __init__(self, ecn: int) -> None:
        self.ecn: int = ecn
        super().__init__(constants.NW_ECN, str(self.ecn))


class NetworkTTL(Match):
    def __init__(self, ttl: int) -> None:
        self.ttl: int = ttl
        super().__init__(constants.NW_TTL, str(self.ttl))


class NetworkProtocol(Match):
    def __init__(self, proto: int) -> None:
        self.proto: int = proto
        super().__init__(constants.NW_PROTO, str(self.proto))


# L3 IPV6


class IPv6Source(Match):
    def __init__(self, ip: str) -> None:
        self.ip: str = validate_ip(ip, version=6)
        super().__init__(constants.IPV6_SRC, self.ip)


class IPv6Destination(Match):
    def __init__(self, ip: str) -> None:
        self.ip: str = validate_ip(ip, version=6)
        super().__init__(constants.IPV6_DST, self.ip)


class IPv6Label(Match):
    def __init__(self, label: int, mask: int | None = None) -> None:
        self.label: int = label
        self.mask: int | None = mask
        if self.mask is not None:
            value = f"{self.label:#x}/{self.mask:#x}"
        else:
            value = f"{self.label:#x}"
        super().__init__(constants.IPV6_LABEL, value)


# L3 ARP


class ARPOperation(Match):
    def __init__(self, oper: int) -> None:
        self.oper: int = oper
        super().__init__(constants.ARP_OP, str(validate_arp_op(self.oper)))


class ARPSourceProtocolAddress(Match):
    def __init__(self, ip: str) -> None:
        self.ip: str = validate_ip(ip)
        super().__init__(constants.ARP_SPA, self.ip)


class ARPTargetProtocolAddress(Match):
    def __init__(self, ip: str) -> None:
        self.ip: str = validate_ip(ip)
        super().__init__(constants.ARP_TPA, self.ip)


class ARPSourceHardwareAddress(Match):
    def __init__(self, addr: str) -> None:
        self.addr: str = validate_mac(addr)
        super().__init__(constants.ARP_SHA, self.addr)


class ARPTargetHardwareAddress(Match):
    def __init__(self, addr: str) -> None:
        self.addr: str = validate_mac(addr)
        super().__init__(constants.ARP_THA, self.addr)


# Layer 4 - Transport


class TransportSourcePort(Match):
    def __init__(self, port: int) -> None:
        self.port: int = port
        super().__init__(constants.TP_SRC, str(self.port))


class TransportDestinationPort(Match):
    def __init__(self, port: int) -> None:
        self.port: int = port
        super().__init__(constants.TP_DST, str(self.port))


class SetTCPFlag:
    """Represents setting a TCP flag (e.g., '+syn')."""

    def __init__(self, flag: TCPFlag) -> None:
        self.flag: TCPFlag = flag

    def marshal_text(self) -> str:
        return f"+{self.flag.value}"

    @override
    def __str__(self) -> str:
        return self.marshal_text()

    @override
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.flag.name})"


class UnsetTCPFlag:
    """Represents unsetting a TCP flag (e.g., '-rst')."""

    def __init__(self, flag: TCPFlag) -> None:
        self.flag: TCPFlag = flag

    def marshal_text(self) -> str:
        return f"-{self.flag.value}"

    @override
    def __str__(self) -> str:
        return self.marshal_text()

    @override
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.flag.name})"


class TCPFlags(Match):
    def __init__(self, *flags: SetTCPFlag | UnsetTCPFlag) -> None:
        self.flags: list[SetTCPFlag | UnsetTCPFlag] = list(flags)
        super().__init__(
            constants.TCP_FLAGS, ",".join(str(flag) for flag in self.flags)
        )


class UDPSourcePort(Match):
    def __init__(self, port: int) -> None:
        self.port: int = port
        super().__init__(constants.UDP_SRC, str(self.port))


class UDPDestinationPort(Match):
    def __init__(self, port: int) -> None:
        self.port: int = port
        super().__init__(constants.UDP_DST, str(self.port))


# ICMP + ICMPv6


class ICMPType(Match):
    def __init__(self, type: int) -> None:
        self.type: int = type
        super().__init__(constants.ICMP_TYPE, str(self.type))


class ICMPCode(Match):
    def __init__(self, code: int) -> None:
        self.code: int = code
        super().__init__(constants.ICMP_CODE, str(self.code))


class ICMPv6Type(Match):
    def __init__(self, type: int) -> None:
        self.type: int = type
        super().__init__(constants.ICMPV6_TYPE, str(self.type))


class ICMPv6Code(Match):
    def __init__(self, code: int) -> None:
        self.code: int = code
        super().__init__(constants.ICMPV6_CODE, str(self.code))


# Neighbor Discovery


class NeighborDiscoveryTargetIPv6(Match):
    def __init__(self, ip: str) -> None:
        self.ip: str = validate_ip(ip, version=6)
        super().__init__(constants.ND_TARGET, self.ip)


class NeighborDiscoverySourceHardwareAddress(Match):
    def __init__(self, addr: str) -> None:
        self.addr: str = validate_mac(addr)
        super().__init__(constants.ND_SLL, self.addr)


class NeighborDiscoveryTargetHardwareAddress(Match):
    def __init__(self, addr: str) -> None:
        self.addr: str = validate_mac(addr)
        super().__init__(constants.ND_TLL, self.addr)


# NXM Fields


class NXMFieldComparison(Match):
    def __init__(self, dst: str, src: str) -> None:
        self.dst: str = dst
        self.src: str = src

        if (
            "[" not in self.dst
            or "[" not in self.src
            or "]" not in self.dst
            or "]" not in self.src
        ):
            raise OpenFlowError(
                "NXM compare fields must include bit ranges. e.g. NXM_OF_VLAN_TCI[] or NXM_OF_VLAN_TCI[0..11]"
            )

        super().__init__(self.dst, self.src)
