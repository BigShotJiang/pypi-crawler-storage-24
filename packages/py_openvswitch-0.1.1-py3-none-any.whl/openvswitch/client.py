from __future__ import annotations

import logging
import os
import subprocess

from typing import Any


class Client:
    def __init__(
        self,
        sudo: bool = True,
        flags: dict[str, str] | None = None,
        debug: bool = False,
    ):
        # Whether to use sudo for command execution
        self.sudo: bool = sudo

        # Additional flags applied to all OVS actions
        self.flags: dict[str, str] = flags if flags is not None else dict()

        # Enable debug logging
        # use debugf() method for debug prints
        self.debug: bool = debug

        # Setup debug logger
        self._debug_logger: logging.Logger | None = None

        if self.debug:
            self._debug_logger = logging.getLogger(__name__)
            self._debug_logger.setLevel(logging.INFO)
            self._debug_logger.addHandler(logging.StreamHandler())

    def _exec(self, *args: str, input: str | None = None) -> tuple[int, str, str]:
        """
        Execute command with given arguments.
        Optionally provide input to the command's stdin.

        Returns a tuple of (exit_code, stdout, stderr).
        """
        prepared_cmd = self._prepare_cmd(*args)

        self.debugf("exec: {}", " ".join(prepared_cmd))

        """
        Check if HOST_ROOTFS is set
        In case, host's root is mounted inside the container, we need to use chroot to execute the command.

        For example,
            The container has been started with `-v /:/host`
            In that case, we can set `HOST_ROOTFS=/host`, so that the command is executed inside the host's root filesystem.
        """
        if host_rootfs := os.environ.get("HOST_ROOTFS"):
            host_path_env = os.environ.get(
                "HOST_ENV_PATH",
                "/usr/sbin:/usr/bin:/sbin:/bin:/snap/bin:/usr/local/go/bin",
            )
            chroot_cmds = [
                "chroot",
                host_rootfs,
                "/usr/bin/env",
                "-i",
                f"PATH={host_path_env}",
                "HOME=/root",
                "TERM=xterm",
            ]
            prepared_cmd = chroot_cmds + prepared_cmd

        process = subprocess.Popen(
            prepared_cmd,
            stdin=subprocess.PIPE if input else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        stdout, stderr = process.communicate(input=input)

        if process.returncode != 0:
            self.debugf(
                "exec : exit {}: stderr: {}",
                process.returncode,
                stderr.strip(),
            )

        return process.returncode, stdout, stderr

    def _prepare_cmd(self, *args: str) -> list[str]:
        cmd = list(args)

        if self.sudo:
            cmd.insert(0, "sudo")

        for flag, value in self.flags.items():
            cmd.append(f"--{flag}={value}")

        return cmd

    def debugf(self, format_string: str, *args: Any) -> None:
        if not self.debug:
            return None

        if self._debug_logger is None:
            return None

        self._debug_logger.info(("ovs: " + format_string).format(*args))
