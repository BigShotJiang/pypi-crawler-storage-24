from dataclasses import dataclass

from openvswitch.exceptions import InvalidPortStatisticsError
from openvswitch.utils import obj_repr


@dataclass
class PortStatsReceive:
    packets: int = 0
    bytes: int = 0
    dropped: int = 0
    errors: int = 0
    frame: int = 0
    over: int = 0
    crc: int = 0

    def __repr__(self) -> str:
        return obj_repr(self)


@dataclass
class PortStatsTransmit:
    packets: int = 0
    bytes: int = 0
    dropped: int = 0
    errors: int = 0
    collisions: int = 0

    def __repr__(self) -> str:
        return obj_repr(self)


@dataclass
class PortStats:
    port_id: int | str
    received: PortStatsReceive
    transmitted: PortStatsTransmit

    @classmethod
    def parse(cls, text: str) -> "PortStats":
        """
        Parse port stats from ovs-ofctl dump-ports output.

        Expected format:
        port  1: rx pkts=0, bytes=0, drop=0, errs=0, frame=0, over=0, crc=0
                 tx pkts=0, bytes=0, drop=0, errs=0, coll=0
        """
        fields = text.split()

        if (
            len(fields) != 16
            or fields[0] != "port"
            or fields[2] != "rx"
            or fields[10] != "tx"
        ):
            raise InvalidPortStatisticsError("Invalid port statistics format")

        # Parse port ID
        port_id: int | str = fields[1].rstrip(":")
        if port_id != "LOCAL":
            port_id = int(port_id)

        # Helper to parse key=value pairs
        def parse_stat(field: str) -> tuple[str, int]:
            key, val = field.rstrip(",").split("=")
            return key, 0 if val == "?" else int(val)

        # Parse RX stats (fields 3-9)
        rx_stats = dict(parse_stat(f) for f in fields[3:10])
        received = PortStatsReceive(
            packets=rx_stats["pkts"],
            bytes=rx_stats["bytes"],
            dropped=rx_stats["drop"],
            errors=rx_stats["errs"],
            frame=rx_stats["frame"],
            over=rx_stats["over"],
            crc=rx_stats["crc"],
        )

        # Parse TX stats (fields 11-15)
        tx_stats = dict(parse_stat(f) for f in fields[11:16])
        transmitted = PortStatsTransmit(
            packets=tx_stats["pkts"],
            bytes=tx_stats["bytes"],
            dropped=tx_stats["drop"],
            errors=tx_stats["errs"],
            collisions=tx_stats["coll"],
        )

        return cls(port_id=port_id, received=received, transmitted=transmitted)

    def __repr__(self) -> str:
        return obj_repr(self)


def parse_port_stats(text: str) -> dict[int | str, PortStats]:
    result = {}

    lines = text.split("port")

    for line in lines:
        line = line.strip()
        if not line or line.startswith("OFPST_PORT"):
            continue

        # Reconstruct the line with 'port' prefix
        port_line = "port " + line

        try:
            stats = PortStats.parse(port_line)
            result[stats.port_id] = stats
        except (ValueError, IndexError, KeyError):
            # Skip malformed lines
            continue

    return result
