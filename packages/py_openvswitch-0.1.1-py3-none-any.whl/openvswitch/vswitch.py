import contextlib
import json
import re
from dataclasses import dataclass
from enum import Enum

from typing_extensions import Any, override

from openvswitch.client import Client
from openvswitch.exceptions import (
    QoSNotFoundError,
    QueueNotFoundError,
    VSwitchError,
    raise_known_ovs_vsctl_error,
)
from openvswitch.utils import parse_int, validate_mac


class OpenFlowProtocol(Enum):
    v10 = "OpenFlow10"
    v11 = "OpenFlow11"
    v12 = "OpenFlow12"
    v13 = "OpenFlow13"
    v14 = "OpenFlow14"
    v15 = "OpenFlow15"


class InterfaceType(Enum):
    GRE = "gre"
    Internal = "internal"
    Patch = "patch"
    VXLAN = "vxlan"
    STT = "stt"


class FailMode(Enum):
    Secure = "secure"
    Standalone = "standalone"


@dataclass
class BridgeOptions:
    # List of OpenFlow protocols supported by the bridge
    protocols: list[OpenFlowProtocol] | None = None


@dataclass
class InterfaceOptions:
    # Type specifies the Open vSwitch interface type
    type: InterfaceType | None = None

    # Peer interface name for patch interfaces
    peer: str | None = None

    # MTU Request specifies the maximum transmission unit for the interface
    mtu_request: int | None = None

    # Maximum allowed incoming traffic rate in kilobits per second (kbps) for an interface.
    # Packets exceeding this rate are dropped. A value of 0 disables ingress policing.
    ingress_rate_policing: int | None = None

    # Maximum burst size in kilobits (kbit) that can temporarily exceed
    # the configured ingress_policing_rate before packets are dropped.
    ingress_burst_policing: int | None = None

    # RemoteIP is used when the interface is a tunnel type
    # (for example, "stt" or "vxlan"). It specifies the remote
    # endpoint IP address for the tunnel. When set to "flow",
    # the tunnel destination IP is expected to be provided by the flow.
    remote_ip: str | None = None

    # Destination port is used when the interface is a tunnel type
    # (for example, "stt" or "vxlan"). It specifies the UDP
    # destination port for the tunnel.
    dst_port: int | None = None

    # Key is used when the interface is a tunnel type
    # (for example, "stt" or "vxlan"). It specifies the tunnel ID
    # for outgoing tunneled traffic. When set to "flow",
    # the tunnel ID is expected to be provided by the flow.
    key: str | None = None

    @property
    def flags_dict(self) -> dict[str, str]:
        flags: dict[str, str] = dict()

        if self.type:
            flags["type"] = self.type.value

        if self.peer:
            flags["options:peer"] = self.peer

        if self.mtu_request is not None and self.mtu_request > 0:
            flags["mtu_request"] = str(self.mtu_request)

        if self.ingress_rate_policing is not None and self.ingress_rate_policing > 0:
            flags["ingress_policing_rate"] = str(self.ingress_rate_policing)
        else:
            flags["ingress_policing_rate"] = "0"

        if self.ingress_burst_policing is not None and self.ingress_burst_policing > 0:
            flags["ingress_policing_burst"] = str(self.ingress_burst_policing)
        else:
            flags["ingress_policing_burst"] = "0"

        if self.remote_ip:
            flags["options:remote_ip"] = self.remote_ip

        if self.dst_port is not None and self.dst_port > 0:
            flags["options:dst_port"] = str(self.dst_port)

        if self.key:
            flags["options:key"] = self.key

        return flags

    @property
    def flags_list(self) -> list[str]:
        flags: list[str] = []

        for key, value in self.flags_dict.items():
            flags.append(f"{key}={value}")

        return flags


class VSwitchService(Client):
    def __init__(
        self,
        sudo: bool = True,
        flags: dict[str, str] | None = None,
        debug: bool = False,
    ):
        super().__init__(sudo=sudo, flags=flags, debug=debug)

    # Bridge Related Methods

    def get_bridges(self) -> list[str]:
        """
        Retrieves all OVS bridges on the system.

        Returns:
            list[str]: List of bridge names

        Raises:
            VSwitchError: If listing bridges fails

        Reference:
            https://www.openvswitch.org/support/dist-docs/ovs-vsctl.8.html#:~:text=%5B%2D%2Dreal%7C%2D%2Dfake%5D%20list%2Dbr
        """

        exit_code, output, err = self._exec("list-br")
        if exit_code != 0:
            raise VSwitchError(f"failed to list bridges: {err}")

        if not output:
            return []

        return [line.strip() for line in output.splitlines() if line.strip()]

    def add_bridge(self, bridge: str) -> None:
        """
        Creates a new bridge in OVS.

        Args:
            bridge: Name of the bridge to create

        Returns:
            None

        Raises:
            VSwitchError: If creating bridge fails
        """
        exit_code, _, err = self._exec("--may-exist", "add-br", bridge)
        if exit_code != 0:
            raise VSwitchError(f"failed to add bridge {bridge}: {err}")

    def delete_bridge(self, bridge: str) -> None:
        """
        Deletes an existing bridge from OVS.

        Args:
            bridge: Name of the bridge to delete

        Returns:
            None

        Raises:
            VSwitchError: If deleting bridge fails
        """
        exit_code, _, err = self._exec("--if-exists", "del-br", bridge)
        if exit_code != 0:
            raise VSwitchError(f"failed to delete bridge {bridge}: {err}")

    def exists_bridge(self, bridge: str) -> bool:
        """
        Checks if a bridge exists in OVS.

        Args:
            bridge: Name of the bridge to check

        Returns:
            bool: True if bridge exists, False otherwise

        Raises:
            VSwitchError: If checking bridge existence fails
        """
        exit_code, _, err = self._exec("br-exists", bridge)
        if exit_code not in (0, 2):
            raise VSwitchError(f"failed to check if bridge {bridge} exists: {err}")
        return exit_code == 0

    # Bridge Options & Fail Mode Methods

    def get_bridge_options(self, bridge: str) -> BridgeOptions:
        """
        Retrieves configuration options for a bridge.

        Args:
            bridge: Name of the bridge

        Returns:
            BridgeOptions: Bridge configuration options

        Raises:
            VSwitchError: If retrieving bridge options fails
        """
        exit_code, output, err = self._exec(
            "--format=json", "get", "bridge", bridge, "protocols"
        )
        if exit_code != 0:
            raise VSwitchError(f"failed to get options for bridge {bridge}: {err}")

        protocols = re.findall(r"\w+", output) if output else []
        return BridgeOptions(protocols=[OpenFlowProtocol(p) for p in protocols])

    def set_bridge_options(self, bridge: str, options: BridgeOptions) -> None:
        """
        Configures options for a bridge.

        Args:
            bridge: Name of the bridge
            options: Bridge configuration options to apply

        Returns:
            None

        Raises:
            VSwitchError: If setting bridge options fails
        """
        exit_code, _, err = self._exec(
            "set",
            "bridge",
            bridge,
            f"protocols={','.join([p.value for p in options.protocols]) if options.protocols else '[]'}",
        )
        if exit_code != 0:
            raise VSwitchError(f"failed to set options for bridge {bridge}: {err}")

    def get_fail_mode(self, bridge: str) -> FailMode | None:
        """
        Retrieves the fail mode setting of a bridge.

        Args:
            bridge: Name of the bridge

        Returns:
            FailMode | None: Current fail mode, or None if not set

        Raises:
            VSwitchError: If retrieving fail mode fails
        """
        exit_code, output, err = self._exec("get", "bridge", bridge, "fail_mode")
        if exit_code != 0:
            raise VSwitchError(f"failed to get fail mode for bridge {bridge}: {err}")
        mode_str = output.strip()
        if mode_str == "" or mode_str == "[]":
            return None
        return FailMode(mode_str)

    def set_fail_mode(self, bridge: str, mode: FailMode | None) -> None:
        """
        Configures the fail mode for a bridge.

        Args:
            bridge: Name of the bridge
            mode: Fail mode to set, or None to remove

        Returns:
            None

        Raises:
            VSwitchError: If setting fail mode fails
        """
        exit_code, _, err = self._exec(
            "set",
            "bridge",
            bridge,
            f"fail_mode={mode.value}" if mode else "fail_mode=[]",
        )
        if exit_code != 0:
            raise VSwitchError(f"failed to set fail mode for bridge {bridge}: {err}")

    def remove_fail_mode(self, bridge: str) -> None:
        """
        Removes the fail mode configuration from a bridge.

        Args:
            bridge: Name of the bridge

        Returns:
            None
        """
        return self.set_fail_mode(bridge, None)

    # Port Related Methods

    def get_ports(self, bridge: str) -> list[str]:
        """
        Retrieves all ports attached to a bridge.

        Args:
            bridge: Name of the bridge

        Returns:
            list[str]: List of port names

        Raises:
            VSwitchError: If listing ports fails
        """
        exit_code, output, err = self._exec("list-ports", bridge)
        if exit_code != 0:
            raise VSwitchError(f"failed to list ports for bridge {bridge}: {err}")
        return [line.strip() for line in output.splitlines() if line.strip()]

    def add_port(self, bridge: str, port: str) -> None:
        """
        Attaches a port to a bridge.

        Args:
            bridge: Name of the bridge
            port: Name of the port to add

        Returns:
            None

        Raises:
            VSwitchError: If adding port fails
        """
        exit_code, _, err = self._exec("--may-exist", "add-port", bridge, port)
        if exit_code != 0:
            raise VSwitchError(f"failed to add port {port} to bridge {bridge}: {err}")

    def delete_port(self, bridge: str, port: str) -> None:
        """
        Removes a port from a bridge.

        Args:
            bridge: Name of the bridge
            port: Name of the port to remove

        Returns:
            None

        Raises:
            VSwitchError: If removing port fails
        """
        exit_code, _, err = self._exec("--if-exists", "del-port", bridge, port)
        if exit_code != 0:
            raise VSwitchError(
                f"failed to delete port {port} from bridge {bridge}: {err}"
            )

    def get_port_mac(self, port: str) -> str:
        """
        Retrieves the MAC address for a given port.

        Args:
            port: Name of the port

        Returns:
            str: MAC address of the port
        """
        exit_code, output, err = self._exec("get", "Interface", port, "mac_in_use")
        if exit_code != 0:
            raise VSwitchError(f"failed to get MAC for port {port}: {err}")

        output = str(output).strip().replace('"', "").replace("'", "")
        return validate_mac(output)

    def get_interface_openflow_port(self, interface: str) -> int:
        """
        Retrieves the OpenFlow port number for a given interface.

        Args:
            interface: Name of the interface
        Returns:
            int: OpenFlow port number
        """
        exit_code, output, err = self._exec("get", "Interface", interface, "ofport")
        if exit_code != 0:
            raise VSwitchError(f"failed to get ofport for interface {interface}: {err}")

        output = str(output).strip()
        if not output.isdigit():
            raise VSwitchError(
                f"invalid ofport value for interface {interface}: {output}"
            )

        return int(output)

    def port_to_bridge(self, port: str) -> str:
        """
        Finds the bridge to which a port is attached.

        Args:
            port: Name of the port

        Returns:
            str: Name of the bridge containing the port

        Raises:
            VSwitchError: If finding bridge fails
        """
        exit_code, output, err = self._exec("port-to-br", port)
        if exit_code != 0:
            raise VSwitchError(f"failed to get bridge for port {port}: {err}")
        return output.strip()

    # Interface Options Methods

    def set_interface_options(self, interface: str, options: InterfaceOptions) -> None:
        """
        Configures options for an interface.

        Args:
            interface: Name of the interface
            options: Interface configuration options to apply

        Returns:
            None

        Raises:
            VSwitchError: If setting interface options fails
        """
        exit_code, _, err = self._exec(
            "set",
            "interface",
            interface,
            *options.flags_list,
        )
        if exit_code != 0:
            raise VSwitchError(
                f"failed to set options for interface {interface}: {err}"
            )

    def get_interface_options(self, interface: str) -> InterfaceOptions:
        """
        Retrieves configuration options for an interface.

        Args:
            interface: Name of the interface

        Returns:
            InterfaceOptions: Interface configuration options

        Raises:
            VSwitchError: If retrieving interface options fails
        """
        code, out, err = self._exec("--format=json", "list", "interface", interface)
        if code != 0:
            raise VSwitchError(f"failed to get options for {interface}: {err}")

        data = json.loads(out)
        headings = data.get("headings", [])
        values = data.get("data", [[]])[0]
        idx = {k: i for i, k in enumerate(headings)}

        def _pick(k: str) -> str | int | list[Any] | dict[Any, Any] | None:
            return values[idx[k]] if k in idx else None

        iface = InterfaceOptions()

        if (t := _pick("type")) is not None:
            assert isinstance(t, str)
            iface.type = InterfaceType(t) if t != "" else None

        if (rate := _pick("ingress_policing_rate")) is not None:
            assert isinstance(rate, int | str)
            iface.ingress_rate_policing = parse_int(rate, allow_none_return=False)

        if (burst := _pick("ingress_policing_burst")) is not None:
            assert isinstance(burst, int | str)

            iface.ingress_burst_policing = parse_int(burst, allow_none_return=False)

        if (mtu := _pick("mtu_request")) is not None:
            iface.mtu_request = mtu if isinstance(mtu, int) else None

        opts = _pick("options")
        if isinstance(opts, list) and opts and opts[0] == "map":
            opts = dict(opts[1])
        elif not isinstance(opts, dict):
            opts = {}

        iface.remote_ip = opts.get("remote_ip")
        iface.dst_port = parse_int(opts.get("dst_port"))
        iface.key = opts.get("key")

        return iface

    # Port QoS related Methods

    def get_egress_bandwidth_limit(self, interface: str) -> int:
        """
        Retrieves the egress bandwidth limit for a given interface.
        Args:
            interface: Name of the interface

        Returns:
            int: Egress bandwidth limit in kilobits per second (kbps).
                    Returns 0 if no limit is set or on error.

        Raises:
            VSwitchError: If retrieving egress bandwidth limit fails
        """

        exit_code, output, err = self._exec(
            "--format=json", "find", "qos", f"external_ids:interface={interface}"
        )
        if exit_code != 0:
            raise VSwitchError(f"failed to find qos for interface {interface}: {err}")

        try:
            data: list[Any] = json.loads(output).get("data", [])

            # Flatten nested structure
            for item in data:
                for entry in item:
                    if not isinstance(entry, list) or len(entry) < 2:  # pyright: ignore[reportUnknownArgumentType]
                        continue

                    # Look for ["map", [[key, value], ...]] structure
                    if entry[0] == "map":
                        config_list = entry[1]  # pyright: ignore[reportUnknownVariableType]

                        # Find max-rate in the map
                        for key, value in config_list:  # pyright: ignore[reportUnknownVariableType]
                            if (
                                key == "max-rate"
                                and isinstance(value, str)
                                and value.isdigit()
                            ):
                                return round(int(value) / 1024)

            return 0

        except (json.JSONDecodeError, KeyError, IndexError, ValueError, TypeError):
            return 0

    def set_egress_bandwidth_limit(self, interface: str, kbs_per_sec: int) -> None:
        """
        Sets egress bandwidth limit for a given interface.

        Args:
            interface: Name of the interface
            kbs_per_sec: Egress bandwidth limit in kilobits per second (kbps)

        Returns:
            None

        Raises:
            VSwitchError: If setting egress bandwidth limit fails
        """

        # First clear any existing egress bandwidth limit
        # To ensure missing cleanup from previous attempts does not interfere
        with contextlib.suppress(VSwitchError):
            self.remove_egress_bandwidth_limit(interface)

        bytes_per_sec = kbs_per_sec * 1024

        if bytes_per_sec <= 0:
            return

        # Setup new egress bandwidth limit
        cmd = [
            "set",
            "port",
            interface,
            "qos=@qos",
            "--",
            "--id=@qos",
            "create",
            "qos",
            "type=linux-htb",
            f"external_ids:interface={interface}",
            f"other-config:max-rate={bytes_per_sec}",
            "queues=0=@q0",
            "--",
            "--id=@q0",
            "create",
            "queue",
            f"external_ids:interface={interface}",
            f"other-config:max-rate={bytes_per_sec}",
        ]

        exit_code, _, err = self._exec(*cmd)
        if exit_code != 0:
            raise VSwitchError(
                f"failed to set egress bandwidth limit for interface {interface}: {err}"
            )

    def remove_egress_bandwidth_limit(self, interface: str) -> None:
        """
        Removes the egress bandwidth limit for a given interface.
        If the interface has no egress bandwidth limit, this is a no-op.

        Args:
            interface: Name of the interface

        Returns:
            None

        Raises:
            VSwitchError: If removing egress bandwidth limit fails

        """

        # Deatch queue from port
        _, _, _ = self._exec("clear", "port", interface, "qos")

        # Note: It's important to clear the qos entries before the queue entries
        # to avoid referential integrity violations

        # Find out the qos UUID associated with the interface
        exit_code, output, err = self._exec(
            "--format=json", "find", "qos", f"external_ids:interface={interface}"
        )
        if exit_code != 0:
            raise VSwitchError(f"failed to find qos for interface {interface}: {err}")

        data = json.loads(output).get("data", [])
        qos_uuids: list[str] = []
        for item in data:
            for entry in item:
                if isinstance(entry, list):
                    if len(entry) >= 2 and str(entry[0]) == "uuid":  # pyright: ignore[reportUnknownArgumentType]
                        qos_uuids.append(str(entry[1]))

        if qos_uuids:
            # Destroy the qos entries
            for qos_uuid in qos_uuids:
                with contextlib.suppress(QoSNotFoundError):
                    exit_code, _, err = self._exec("destroy", "qos", qos_uuid)
                    if exit_code != 0:
                        raise VSwitchError(
                            f"failed to destroy qos {qos_uuid} for interface {interface}: {err}"
                        )

        # Find out the queue UUID associated with the interface
        exit_code, output, err = self._exec(
            "--format=json", "find", "queue", f"external_ids:interface={interface}"
        )
        if exit_code != 0:
            raise VSwitchError(f"failed to find queue for interface {interface}: {err}")

        data = json.loads(output).get("data", [])
        queue_uuids: list[str] = []
        for item in data:
            for entry in item:
                if (
                    isinstance(entry, list) and len(entry) >= 2 and entry[0] == "uuid"  # pyright: ignore[reportUnknownArgumentType]
                ):
                    queue_uuids.append(str(entry[1]))  # pyright: ignore[reportUnknownArgumentType]

        # Destroy the queues
        if not queue_uuids:
            return

        for queue_uuid in queue_uuids:
            with contextlib.suppress(QueueNotFoundError):
                exit_code, _, err = self._exec("destroy", "queue", queue_uuid)
                if exit_code != 0:
                    raise VSwitchError(
                        f"failed to destroy queue {queue_uuid} for interface {interface}: {err}"
                    )

    # Controller Related Methods

    def get_controllers(self, bridge: str) -> list[str]:
        """
        Retrieves all controllers configured for a bridge.

        Args:
            bridge: Name of the bridge

        Returns:
            list[str]: List of controller addresses

        Raises:
            VSwitchError: If retrieving controllers fails
        """
        exit_code, output, err = self._exec("get-controller", bridge)
        if exit_code != 0:
            raise VSwitchError(f"failed to get controller for bridge {bridge}: {err}")
        return output.strip().splitlines()

    def set_controller(self, bridge: str, address: str) -> None:
        """
        Configures a single controller for a bridge.

        Args:
            bridge: Name of the bridge
            address: Controller address

        Returns:
            None
        """
        return self.set_controllers(bridge, [address])

    def set_controllers(self, bridge: str, addresses: list[str]) -> None:
        """
        Configures multiple controllers for a bridge.

        Args:
            bridge: Name of the bridge
            addresses: List of controller addresses

        Returns:
            None

        Raises:
            VSwitchError: If setting controllers fails
        """
        exit_code, _, err = self._exec("set-controller", bridge, *addresses)
        if exit_code != 0:
            raise VSwitchError(f"failed to set controller for bridge {bridge}: {err}")

    def delete_controllers(self, bridge: str) -> None:
        """
        Removes all controllers from a bridge.

        Args:
            bridge: Name of the bridge

        Returns:
            None

        Raises:
            VSwitchError: If removing controllers fails
        """
        exit_code, _, err = self._exec("del-controller", bridge)
        if exit_code != 0:
            raise VSwitchError(
                f"failed to delete controller for bridge {bridge}: {err}"
            )

    # Internal Methods

    @override
    def _exec(self, *args: str, input: str | None = None) -> tuple[int, str, str]:
        """
        Executes an ovs-vsctl command with the given arguments.
        Raises known OVS errors as custom exceptions.
        """
        exit_code, stdout, stderr = super()._exec("ovs-vsctl", *args, input=input)
        if exit_code != 0:
            raise_known_ovs_vsctl_error(stderr)
        return exit_code, stdout, stderr
