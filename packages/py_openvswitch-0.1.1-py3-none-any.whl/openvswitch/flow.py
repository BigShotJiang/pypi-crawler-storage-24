from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from typing_extensions import override

from openvswitch import constants
from openvswitch.action import Action
from openvswitch.action_parser import parse_actions
from openvswitch.exceptions import OpenFlowError
from openvswitch.match import Match
from openvswitch.match_parser import parse_match
from openvswitch.utils import obj_repr, parse_int


class Protocol(Enum):
    ARP = "arp"
    ICMP = "icmp"
    ICMPv6 = "icmpv6"
    IP = "ip"
    IPv6 = "ipv6"
    TCP = "tcp"
    TCPv6 = "tcp6"
    UDP = "udp"
    UDPv6 = "udp6"


@dataclass
class FlowStats:
    packet_count: int = 0
    byte_count: int = 0


@dataclass
class Flow:
    priority: int = 0
    protocol: Protocol | None = None
    matches: list[Match] = field(default_factory=list)
    table: int = 0
    idle_timeout: int = -1
    cookie: int = 0
    actions: list[Action] = field(default_factory=list)
    stats: FlowStats = field(default_factory=FlowStats)

    # Learned flow specific fields
    is_learned: bool = False
    delete_learned: bool = False
    fin_hard_timeout: int = 0
    hard_timeout: int = -1
    limit: int = -1

    def marshal_text(self) -> str:
        """
        Converts the flow to OVS flow syntax string.

        Returns:
            str: Flow in OVS text format

        Raises:
            OpenFlowError: If flow has no actions or invalid action combinations
        """
        if len(self.actions) == 0:
            raise OpenFlowError(constants.ERR_NO_ACTIONS)

        # Validation on actions
        if len(self.actions) > 1:
            for action in self.actions:
                if str(action) == constants.ACTION_DROP:
                    raise OpenFlowError(constants.ERR_ACTIONS_WITH_DROP)

        actions = marshal_actions(self.actions)

        # Priority
        flow = f"{constants.PRIORITY}={self.priority},"

        # Protocol
        if self.protocol:
            flow += f"{self.protocol.value},"

        # Add matches
        matches = marshal_matches(self.matches)
        if matches:
            flow += ",".join(matches) + ","

        # Table
        flow += f"{constants.TABLE}={self.table},"

        # Idle Timeout
        if self.idle_timeout >= 0:
            flow += f"{constants.IDLE_TIMEOUT}={self.idle_timeout},"

        if self.is_learned:  # Learned Flow Specific
            # Fin Hard Timeout
            if self.fin_hard_timeout:
                flow += f"{constants.FIN_HARD_TIMEOUT}={self.fin_hard_timeout},"

            # Hard Timeout
            if self.hard_timeout >= 0:
                flow += f"{constants.HARD_TIMEOUT}={self.hard_timeout},"

            # Limit
            if self.limit >= 0:
                flow += f"{constants.LIMIT}={self.limit},"

            # Delete Learned
            if self.delete_learned:
                flow += f"{constants.DELETE_LEARNED},"

        # Cookie
        if self.cookie >= 0:
            flow += f"{constants.COOKIE}=0x{self.cookie:x},"

        # Actions
        flow += f"{constants.ACTIONS}=" + ",".join(actions)

        return flow

    @classmethod
    def parse(cls, flow_text: str, learned: bool = False) -> Flow:
        """
        Parses an OVS flow string into a Flow object.

        Args:
            flow_text: Flow string in OVS text format
            learned: Whether this is a learned flow

        Returns:
            Flow: Parsed flow object

        Raises:
            OpenFlowError: If flow string is invalid or malformed
        """
        f = cls(
            actions=[],
            matches=[],
            stats=FlowStats(),
        )
        f.is_learned = learned

        ss = flow_text.split(f"{constants.ACTIONS}=")
        if len(ss) < 2:
            raise OpenFlowError("invalid flow, not enough arguments available")

        if len(ss) != 2 or not ss[1]:
            raise OpenFlowError("invalid flow, missing actions")

        matchers, actions = ss[0], ss[1]

        ss = matchers.split(",")
        for s in ss:
            if "=" not in s:
                if (val := s.strip()) != "":
                    # It could be delete_learned flag
                    if learned and val == constants.DELETE_LEARNED:
                        f.delete_learned = True
                        continue

                    # Else, it could be protocol
                    try:
                        f.protocol = Protocol(val)
                    except ValueError:
                        raise OpenFlowError(f"unknown protocol: {s.strip()}") from None
                continue

            key, value = s.split("=", 1)
            key = key.strip()
            value = value.strip()

            if key == constants.PRIORITY:
                f.priority = int(value)
            elif key == constants.COOKIE:
                if value.startswith("0x") or value.startswith("0X"):
                    f.cookie = int(value, 16)
                else:
                    f.cookie = int(value)

            elif key == constants.IDLE_TIMEOUT:
                f.idle_timeout = parse_int(value) or -1

            elif key == constants.HARD_TIMEOUT:
                f.hard_timeout = parse_int(value) or -1

            elif key == constants.FIN_HARD_TIMEOUT:
                f.fin_hard_timeout = parse_int(value) or -1

            elif key == constants.LIMIT:
                f.limit = parse_int(value) or -1

            elif key == constants.TABLE:
                f.table = int(value)

            elif key == constants.N_PACKETS:
                f.stats.packet_count = int(value)

            elif key == constants.N_BYTES:
                f.stats.byte_count = int(value)

            elif key in (constants.DURATION, constants.HARD_AGE, constants.IDLE_AGE):
                # Ignored for now
                pass
            else:
                # Parse Matches
                match = parse_match(key, value)
                if match:
                    f.matches.append(match)

        # Parse Actions
        f.actions = parse_actions(actions)

        if len(f.actions) > 1:
            for action in f.actions:
                if str(action) == constants.ACTION_DROP:
                    raise OpenFlowError(constants.ERR_ACTIONS_WITH_DROP)

        return f

    @override
    def __str__(self) -> str:
        return self.marshal_text()

    @override
    def __repr__(self) -> str:
        return obj_repr(
            self,
            exclude=("stats",)
            if self.is_learned
            else (
                "delete_learned",
                "fin_hard_timeout",
                "hard_timeout",
                "limit",
                "stats",
            ),
        )


@dataclass
class MatchFlow:
    protocol: Protocol | None
    matches: list[Match]
    cookie: int
    cookie_mask: int | None

    def marshal_text(self) -> str:
        """
        Converts the match flow to OVS flow match syntax string.

        Returns:
            str: Match flow in OVS text format
        """
        flow = ""
        if self.protocol is not None:
            flow += f"{self.protocol.value}, "

        if self.cookie_mask is not None:
            flow += f"{constants.COOKIE}=0x{self.cookie:x}/0x{self.cookie_mask:x}, "
        else:
            flow += f"{constants.COOKIE}=0x{self.cookie:x}/-1, "

        match_strs = [str(match) for match in self.matches]
        flow += ",".join(match_strs)

        return flow

    @override
    def __str__(self) -> str:
        return self.marshal_text()

    @override
    def __repr__(self) -> str:
        return obj_repr(self)

    @classmethod
    def from_flow(cls, flow: Flow, cookie_mask: int | None = None) -> MatchFlow:
        return cls(
            protocol=flow.protocol,
            matches=flow.matches,
            cookie=flow.cookie,
            cookie_mask=cookie_mask,
        )


def marshal_actions(actions: list[Action]) -> list[str]:
    return [str(a) for a in actions]


def marshal_matches(matches: list[Match]) -> list[str]:
    return [str(m) for m in matches]
