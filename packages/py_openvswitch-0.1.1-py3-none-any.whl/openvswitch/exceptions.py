from __future__ import annotations

from openvswitch import constants


class OVSError(Exception):
    """Base exception for all OVS-related errors."""


class VSwitchError(OVSError):
    """Exception raised for ovs-vsctl command errors."""


class OpenFlowError(OVSError):
    """Exception raised for OpenFlow-related errors."""


class BucketError(OpenFlowError):
    """Exception raised for bucket-related errors."""


class GroupError(OpenFlowError):
    """Exception raised for group-related errors."""


class TableParseError(OVSError):
    """Error encountered while parsing a table entry."""


class BridgeNotFoundError(OVSError, LookupError):
    """Exception raised when a bridge is not found."""

    def __init__(self, bridge: str, message: str | None = None) -> None:
        self.bridge: str = bridge
        super().__init__(message or f'bridge "{bridge}" not found')


class InterfaceNotFoundError(OVSError, LookupError):
    """Exception raised when an interface is not found."""

    def __init__(self, interface: str, message: str | None = None) -> None:
        self.interface: str = interface
        super().__init__(message or f'interface "{interface}" not found')


class PortNotFoundError(OVSError, LookupError):
    """Exception raised when a port is not found."""

    def __init__(self, port: str, message: str | None = None) -> None:
        self.port: str = port
        super().__init__(message or f'port "{port}" not found')


class ColumnNotFoundError(VSwitchError):
    """Exception raised when a column is not found in OVS database."""

    def __init__(self, column: str, message: str | None = None) -> None:
        self.column: str = column
        super().__init__(message or f'invalid column: "{column}"')


class QueueNotFoundError(VSwitchError):
    """Exception raised when a queue is not found in OVS database."""

    def __init__(self, queue: str, message: str | None = None) -> None:
        self.queue: str = queue
        super().__init__(message or f'queue "{queue}" not found')


class QoSNotFoundError(VSwitchError):
    """Exception raised when a QoS entry is not found in OVS database."""

    def __init__(self, qos: str, message: str | None = None) -> None:
        self.qos: str = qos
        super().__init__(message or f'QoS "{qos}" not found')


class InvalidARPOpCodeError(ValueError):
    """Exception raised for invalid ARP operation codes."""

    def __init__(self, oper: int, message: str | None = None) -> None:
        self.oper: int = oper
        super().__init__(message or f"invalid ARP operation code: {oper}")


class InvalidIPAddressError(ValueError):
    """Exception raised for invalid IP addresses."""

    def __init__(self, ip: str, message: str | None = None) -> None:
        self.ip: str = ip
        super().__init__(message or f"invalid IP address: {ip}")


class InvalidCIDRError(ValueError):
    """Exception raised for invalid CIDR notations."""

    def __init__(self, cidr: int, message: str | None = None) -> None:
        self.cidr: int = cidr
        super().__init__(message or f"invalid CIDR notation: {cidr}")


class InvalidMACAddressError(ValueError):
    """Exception raised for invalid MAC addresses."""

    def __init__(self, mac: str, message: str | None = None) -> None:
        self.mac: str = mac
        super().__init__(message or f"invalid MAC address: {mac}")


class InvalidOpenFlowProtocolError(ValueError):
    """Exception raised for unsupported OpenFlow protocol versions."""

    def __init__(self, version: str, message: str | None = None) -> None:
        self.version: str = version
        super().__init__(message or f"unsupported OpenFlow protocol version: {version}")


class InvalidPortRangeError(ValueError):
    """Exception raised for invalid port range specifications."""

    def __init__(self, port_range: str, message: str | None = None) -> None:
        self.port_range: str = port_range
        super().__init__(message or f"invalid port range: {port_range}")


class InvalidVLANIDError(ValueError):
    """Exception raised for invalid VLAN IDs."""

    def __init__(self, vlan_id: int, message: str | None = None) -> None:
        self.vlan_id: int = vlan_id
        super().__init__(message or f"invalid VLAN ID: {vlan_id}")


class ActionError(OVSError):
    """Exception raised for invalid or malformed flow actions."""


class MatchFlowError(OpenFlowError):
    """Exception raised for flow matching errors."""


class InvalidCTStateError(ValueError):
    """Exception raised for invalid connection tracking state values."""


class InvalidRegisterError(ValueError):
    """Exception raised for invalid register specifications."""


class InvalidTCPFlagError(ValueError):
    """Exception raised for invalid TCP flag specifications."""


class OpenFlowTransactionError(OpenFlowError):
    """Exception raised for errors during OpenFlow bundle transactions."""


class InvalidPortStatisticsError(ValueError):
    """Exception raised for invalid port statistics data."""


def raise_known_ovs_vsctl_error(stderr: str) -> None:
    """Inspect ovs-vsctl stderr and raise a specific exception if recognized.

    This function parses stderr output from ovs-vsctl commands and raises
    appropriate exceptions based on known error patterns.

    Args:
        stderr: The stderr output from an ovs-vsctl command.

    Raises:
        BridgeNotFoundError: If bridge is not found.
        PortNotFoundError: If port is not found.
        InterfaceNotFoundError: If interface is not found.
        ColumnNotFoundError: If column is invalid.
    """
    if not stderr:
        return

    match = constants.RE_BRIDGE_MISSING.search(stderr)
    if match:
        raise BridgeNotFoundError(match.group(1))

    match = constants.RE_BRIDGE_NOT_FOUND.search(stderr)
    if match:
        raise BridgeNotFoundError(match.group(1).strip())

    match = constants.RE_PORT_NOT_FOUND.search(stderr)
    if match:
        raise PortNotFoundError(match.group(1).strip())

    match = constants.RE_INTERFACE_MISSING.search(stderr)
    if match:
        raise InterfaceNotFoundError(match.group(1).strip())

    match = constants.RE_COLUMN_BAD.search(stderr)
    if match:
        raise ColumnNotFoundError(match.group(1))

    match = constants.RE_QUEUE_MISSING.search(stderr)
    if match:
        raise QueueNotFoundError(match.group(1).strip())

    match = constants.RE_QOS_MISSING.search(stderr)
    if match:
        raise QoSNotFoundError(match.group(1).strip())

    match = constants.RE_PORT_NOT_FOUND_2.search(stderr)
    if match:
        raise PortNotFoundError(match.group(1).strip())
