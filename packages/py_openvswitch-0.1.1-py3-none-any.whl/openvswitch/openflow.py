from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum

from typing_extensions import override

from openvswitch import constants
from openvswitch.client import Client
from openvswitch.exceptions import OpenFlowError, OpenFlowTransactionError
from openvswitch.flow import Flow, FlowStats, MatchFlow
from openvswitch.group import Group
from openvswitch.port_stats import PortStats, parse_port_stats
from openvswitch.table import Table, parse_tables
from openvswitch.utils import validate_group_id


class FlowDirectiveType(Enum):
    ADD = "add"
    DELETE = "delete"


class PortAction(Enum):
    UP = "up"
    DOWN = "down"
    STP = "stp"
    NO_STP = "no-stp"
    RECEIVE = "receive"
    NO_RECEIVE = "no-receive"
    RECEIVE_STP = "receive-stp"
    NO_RECEIVE_STP = "no-receive-stp"
    FORWARD = "forward"
    NO_FORWARD = "no-forward"
    FLOOD = "flood"
    NO_FLOOD = "no-flood"
    PACKET_IN = "packet-in"
    NO_PACKET_IN = "no-packet-in"


@dataclass
class FlowDirective:
    directive: FlowDirectiveType
    flow: str


@dataclass
class FlowTransaction:
    flows: list[FlowDirective] = field(default_factory=list)
    committed: bool = False
    err: Exception | None = None

    def add(self, flow: Flow) -> None:
        """
        Adds a flow to the transaction bundle.

        Args:
            flow: Flow entry to add

        Returns:
            None
        """
        self._push(FlowDirectiveType.ADD, flow)

    def delete(self, flow: MatchFlow) -> None:
        """
        Adds a flow deletion to the transaction bundle.

        Args:
            flow: Flow match criteria for deletion

        Returns:
            None
        """
        self._push(FlowDirectiveType.DELETE, flow)

    def commit(self) -> None:
        """
        Commits the transaction bundle for execution.

        Returns:
            None

        Raises:
            OpenFlowTransactionError: If transaction has existing errors
        """
        if self.err:
            raise OpenFlowTransactionError(
                "cannot commit transaction with existing error"
            ) from self.err
        self.committed = True

    def discard(self, err: Exception | None) -> None:
        """
        Discards the transaction bundle and clears all flows.

        Args:
            err: Optional exception that caused the discard

        Returns:
            None
        """
        self.flows.clear()
        self.committed = False
        self.err = err or OpenFlowTransactionError("transaction discarded")

    def _push(self, directive: FlowDirectiveType, flow: Flow | MatchFlow) -> None:
        try:
            self.flows.append(FlowDirective(directive, str(flow)))
        except Exception as e:
            self.err = e
            raise e


class OpenflowService(Client):
    def __init__(
        self,
        sudo: bool = True,
        flags: dict[str, str] | None = None,
        debug: bool = False,
    ):
        super().__init__(sudo=sudo, flags=flags, debug=debug)

    def dump_tables(self, bridge: str) -> dict[int, Table]:
        """
        Retrieves flow table statistics from a bridge.

        Args:
            bridge: Name of the OVS bridge

        Returns:
            dict[int, Table]: Dictionary mapping table IDs to Table objects

        Raises:
            RuntimeError: If command execution fails
            OpenFlowError: If parsing table output fails
        """
        exit_code, stdout, err = self._exec("dump-tables", bridge)
        if exit_code != 0:
            raise RuntimeError(f"failed to dump tables from bridge {bridge}: {err}")

        try:
            tables = parse_tables(stdout)
            return tables
        except Exception as e:
            raise OpenFlowError(
                f"failed to parse tables from bridge {bridge}: {e}"
            ) from e

    def add_flow(self, bridge: str, flow: Flow) -> None:
        """
        Adds a single flow entry to a bridge.

        Args:
            bridge: Name of the OVS bridge
            flow: Flow entry to add

        Returns:
            None

        Raises:
            OpenFlowError: If adding flow fails
        """
        args = ["add-flow", bridge, str(flow)]
        exit_code, _, err = self._exec(*args)
        if exit_code != 0:
            raise OpenFlowError(f"failed to add flow to bridge {bridge}: {err}")

    def add_flow_bundle(
        self, bridge: str, fn: Callable[[FlowTransaction], None]
    ) -> None:
        """
        Adds multiple flows atomically using a bundle transaction.

        Args:
            bridge: Name of the OVS bridge
            fn: Callback function that builds the transaction

        Returns:
            None

        Raises:
            OpenFlowTransactionError: If transaction fails or not committed
        """
        txn = FlowTransaction()
        fn(txn)

        if txn.err:
            raise txn.err

        if not txn.committed:
            raise OpenFlowTransactionError("transaction not committed")

        if not txn.flows:
            return  # No flows to add

        # Build the command input
        data = ""
        for flow in txn.flows:
            data += f"{flow.directive.value} {str(flow.flow)}\n"

        # Add EOF newline
        data += "\n"
        print(data)

        exit_code, _, err = self._exec("--bundle", "add-flow", bridge, "-", input=data)
        if exit_code != 0:
            raise OpenFlowTransactionError(
                f"failed to add flow bundle to bridge {bridge}: {err}"
            )

    def delete_flows(self, bridge: str, match_flow: MatchFlow | None) -> None:
        """
        Deletes flows from a bridge matching the criteria.

        Args:
            bridge: Name of the OVS bridge
            match_flow: Flow match criteria, or None to delete all flows

        Returns:
            None

        Raises:
            OpenFlowError: If deleting flows fails
        """
        # If no match flow is provided, it will delete all flows
        args = ["del-flows", bridge]
        if match_flow is not None:
            args.append(str(match_flow))

        exit_code, _, err = self._exec(*args)
        if exit_code != 0:
            raise OpenFlowError(f"failed to delete flows from bridge {bridge}: {err}")

    def dump_flows(self, bridge: str) -> list[Flow]:
        """
        Retrieves all OpenFlow rules from a bridge.

        Args:
            bridge: Name of the OVS bridge

        Returns:
            list[Flow]: List of flow entries from the bridge
        """
        return self.dump_flows_with_flow_args(bridge, None)

    def dump_flows_with_flow_args(
        self, bridge: str, flow: MatchFlow | None = None, learned: bool = False
    ) -> list[Flow]:
        """
        Retrieves flows from a bridge with optional match criteria.

        Args:
            bridge: Name of the OVS bridge
            flow: Optional flow match criteria to filter results
            learned: Whether to include learned flows

        Returns:
            list[Flow]: List of matching flow entries

        Raises:
            OpenFlowError: If dumping or parsing flows fails
        """
        args = ["dump-flows", bridge]
        if flow is not None:
            args.append(str(flow))

        exit_code, stdout, err = self._exec(*args)
        if exit_code != 0:
            raise OpenFlowError(f"failed to dump flows from bridge {bridge}: {err}")

        lines = stdout.strip().split("\n")
        lines = [line.strip() for line in lines]
        lines = [line for line in lines if line]

        # First line should have NXST_FLOW
        if not lines or "NXST_FLOW" not in lines[0]:
            raise OpenFlowError(f"invalid flow dump output from bridge {bridge}")

        lines = lines[1:]  # Skip the first line

        # Convert each line to Flow object
        flows: list[Flow] = []
        for line in lines:
            flows.append(Flow.parse(line, learned=learned))

        return flows

    def dump_aggregate(self, bridge: str, flow: MatchFlow | None = None) -> FlowStats:
        """
        Retrieves aggregated statistics for flows on a bridge.

        Args:
            bridge: Name of the OVS bridge
            flow: Optional flow match criteria to filter statistics

        Returns:
            FlowStats: Aggregated packet and byte counts

        Raises:
            OpenFlowError: If dumping or parsing aggregate stats fails
        """
        args = ["dump-aggregate", bridge]
        if flow is not None:
            args.append(str(flow))

        exit_code, output, err = self._exec(*args)
        if exit_code != 0:
            raise OpenFlowError(f"failed to dump aggregate from bridge {bridge}: {err}")

        output = output.strip()
        if "NXST_AGGREGATE" not in output:
            raise OpenFlowError(f"invalid aggregate dump output from bridge {bridge}")

        stats = FlowStats()

        m = constants.RE_FLOW_STATS_PACKET_COUNT.search(output)
        stats.packet_count = int(m.group(1)) if m else 0

        m = constants.RE_FLOW_STATS_BYTE_COUNT.search(output)
        stats.byte_count = int(m.group(1)) if m else 0

        return stats

    def mod_port(self, bridge: str, port: str, action: PortAction) -> None:
        """
        Modifies the state of a port on a bridge.

        Args:
            bridge: Name of the OVS bridge
            port: Port name or number
            action: Port action to apply

        Returns:
            None

        Raises:
            OpenFlowError: If modifying port fails
        """
        exit_code, _, err = self._exec("mod-port", bridge, port, action.value)
        if exit_code != 0:
            raise OpenFlowError(
                f"failed to modify port {port} on bridge {bridge}: {err}"
            )

    def dump_ports(
        self, bridge: str, port: str | int | None
    ) -> dict[int | str, PortStats]:
        """
        Retrieves statistics for ports on a bridge.

        Args:
            bridge: Name of the OVS bridge
            port: Optional port name or number to filter results

        Returns:
            dict[int | str, PortStats]: Dictionary mapping ports to their statistics

        Raises:
            OpenFlowError: If dumping port statistics fails
        """
        args = ["dump-ports", bridge]
        if port is not None and port != "":
            args.append(str(port))
        exit_code, output, err = self._exec(*args)
        if exit_code != 0:
            raise OpenFlowError(
                f"failed to dump port {port} from bridge {bridge}: {err}"
            )

        return parse_port_stats(output)

    def dump_port(self, bridge: str, port: str | int | None) -> PortStats:
        """
        Retrieves statistics for a specific port on a bridge.

        Args:
            bridge: Name of the OVS bridge
            port: Port name or number

        Returns:
            PortStats: Statistics for the specified port

        Raises:
            OpenFlowError: If port not found or no ports exist
        """
        ports = self.dump_ports(bridge, "")
        if port is not None:
            if port in ports:
                return ports[port]
            elif isinstance(port, int) and str(port) in ports:
                return ports[str(port)]
            else:
                raise OpenFlowError(f"port {port} not found in bridge {bridge} ports")

        raise OpenFlowError(f"no ports found in bridge {bridge}")

    def add_group(self, bridge: str, group: Group) -> None:
        """
        Adds a group entry to a bridge.

        Args:
            bridge: Name of the OVS bridge
            group: Group entry to add

        Returns:
            None

        Raises:
            OpenFlowError: If adding group fails
        """
        exit_code, _, err = self._exec("add-group", bridge, str(group))
        if exit_code != 0:
            raise OpenFlowError(f"failed to add group to bridge {bridge}: {err}")
        return None

    def mod_group(self, bridge: str, group: Group) -> None:
        """
        Modifies or creates a group entry on a bridge.

        Args:
            bridge: Name of the OVS bridge
            group: Group entry to modify or create

        Returns:
            None

        Raises:
            OpenFlowError: If modifying group fails
        """
        exit_code, _, err = self._exec("--may-create", "mod-group", bridge, str(group))
        if exit_code != 0:
            raise OpenFlowError(f"failed to modify group on bridge {bridge}: {err}")
        return None

    def delete_groups(self, bridge: str) -> None:
        """
        Deletes all groups from a bridge.

        Args:
            bridge: Name of the OVS bridge

        Returns:
            None
        """
        return self.delete_group(bridge, None)

    def delete_group(self, bridge: str, group_id: int | None = None) -> None:
        """
        Deletes a specific group or all groups from a bridge.

        Args:
            bridge: Name of the OVS bridge
            group_id: Optional group ID to delete, or None to delete all

        Returns:
            None

        Raises:
            OpenFlowError: If deleting groups fails
        """
        args = ["del-groups", bridge]
        if group_id is not None:
            args.append(f"{constants.GROUP_ID}={str(validate_group_id(group_id))}")
        exit_code, _, err = self._exec(*args)
        if exit_code != 0:
            raise OpenFlowError(f"failed to delete groups from bridge {bridge}: {err}")
        return None

    def dump_groups(self, bridge: str, group_id: int | None = None) -> dict[int, Group]:
        """
        Retrieves group entries from a bridge.

        Args:
            bridge: Name of the OVS bridge
            group_id: Optional group ID to filter results

        Returns:
            dict[int, Group]: Dictionary mapping group IDs to Group objects

        Raises:
            OpenFlowError: If dumping or parsing groups fails
        """
        args = ["dump-groups", bridge]
        if group_id is not None:
            args.append(str(validate_group_id(group_id)))

        exit_code, stdout, err = self._exec(*args)
        if exit_code != 0:
            raise OpenFlowError(f"failed to dump groups from bridge {bridge}: {err}")

        if group_id and "not a valid group ID" in stdout.lower():
            return {}

        lines = stdout.strip().split("\n")
        lines = [line.strip() for line in lines]
        lines = [line for line in lines if line]

        # First line should have NXST_GROUP
        if not lines or "NXST_GROUP" not in lines[0]:
            raise OpenFlowError(f"invalid group dump output from bridge {bridge}")

        lines = lines[1:]  # Skip the first line

        groups: dict[int, Group] = {}
        for line in lines:
            group = Group.parse(line)
            groups[group.id] = group

        return groups

    def dump_group(self, bridge: str, group_id: int) -> Group:
        """
        Retrieves a specific group entry from a bridge.

        Args:
            bridge: Name of the OVS bridge
            group_id: Group ID to retrieve

        Returns:
            Group: The requested group entry

        Raises:
            OpenFlowError: If group not found
        """
        groups = self.dump_groups(bridge, group_id)
        if group_id not in groups:
            raise OpenFlowError(
                f"group ID {group_id} not found in bridge {bridge} groups"
            )
        return groups[group_id]

    # Internal Methods
    @override
    def _exec(self, *args: str, input: str | None = None) -> tuple[int, str, str]:
        exit_code, stdout, stderr = super()._exec("ovs-ofctl", *args, input=input)
        return exit_code, stdout, stderr
