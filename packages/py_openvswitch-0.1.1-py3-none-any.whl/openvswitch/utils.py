import ipaddress
import re

from typing import Literal, overload

from openvswitch.exceptions import (
    InvalidARPOpCodeError,
    InvalidCIDRError,
    InvalidIPAddressError,
    InvalidMACAddressError,
    InvalidVLANIDError,
)


@overload
def parse_int(
    value: str | int | None, allow_none_return: Literal[True] = True
) -> int | None: ...


@overload
def parse_int(value: str | int | None, allow_none_return: Literal[False]) -> int: ...


def parse_int(value: str | int | None, allow_none_return: bool = True) -> int | None:
    val = None

    if value is not None:
        if isinstance(value, int):
            val = value
        elif value.startswith("0x") or value.startswith("0X"):
            val = int(value, 16)
        else:
            val = int(value)

    if not allow_none_return:
        assert val is not None, "expected integer value, got None"

    return val


def validate_ip(ip: str, version: int | None = 4) -> str:
    try:
        address = ipaddress.ip_address(ip)
    except ValueError:
        raise InvalidIPAddressError(ip, f"Invalid IP address: {ip}") from None

    if version and address.version != version:
        raise InvalidIPAddressError(ip, f"Expected IPv{version} address: {ip}")

    return str(address)


def validate_cidr(cidr: int, version: int | None = 4) -> int:
    if (version == 4) and not (0 <= cidr <= 32):
        raise InvalidCIDRError(cidr, f"Invalid CIDR: {cidr} for IPv4")
    if (version == 6) and not (0 <= cidr <= 128):
        raise InvalidCIDRError(cidr, f"Invalid CIDR: {cidr} for IPv6")
    return cidr


def validate_ip_cidr(ip: str, version: int | None = 4) -> str:
    try:
        network = ipaddress.ip_network(ip, strict=False)
    except ValueError as e:
        raise InvalidIPAddressError(ip, f"Invalid IP or CIDR: {ip}") from e

    if version and network.version != version:
        raise InvalidIPAddressError(ip, f"Expected IPv{version} address: {ip}")

    return str(network)


def validate_mac(addr: str) -> str:
    if not re.match(r"^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$", addr):
        raise InvalidMACAddressError(addr, f"Invalid MAC address: {addr}")
    return addr


def validate_arp_op(op: int) -> int:
    if not 1 <= op <= 4:
        raise InvalidARPOpCodeError(op)
    return op


def validate_vlan_id(vlan_id: int) -> int:
    if not 0 <= vlan_id <= 4095:
        raise InvalidVLANIDError(
            vlan_id, f"VLAN ID must be in the range 0-4095, got: {vlan_id}"
        )
    return vlan_id


def validate_group_id(group_id: int) -> int:
    if not 0 <= group_id <= 0xFFFFFFFF:
        raise ValueError(f"Group ID must be in the range 0-4294967295, got: {group_id}")
    return group_id


def obj_repr(obj: object, exclude: tuple[str, ...] = (), _depth: int = 0) -> str:
    # Filter attributes
    attrs = {
        k: v
        for k, v in obj.__dict__.items()
        if not k.startswith("_") and k not in exclude and v is not None
    }

    # Build repr items with indentation for lists
    items: list[str] = []
    base_indent = "  " * (_depth + 1)
    list_item_indent = "  " * (_depth + 2)

    for k, v in attrs.items():
        if isinstance(v, list):
            if not v:  # empty list
                items.append(f"{k}=[]")
            else:
                list_items: list[str] = []

                for i in v:  # pyright: ignore[reportUnknownVariableType]
                    item_repr = repr(i)  # pyright: ignore[reportUnknownArgumentType]
                    # Indent nested multi-line reprs
                    if "\n" in item_repr:
                        lines = item_repr.split("\n")
                        indented_lines = [lines[0]] + [
                            list_item_indent + line for line in lines[1:]
                        ]
                        indented_item = "\n".join(indented_lines)
                    else:
                        indented_item = item_repr
                    list_items.append(f"{list_item_indent}{indented_item},")

                formatted = f"{k}=[\n" + "\n".join(list_items) + f"\n{base_indent}]"
                items.append(formatted)
        else:
            value_repr = repr(v)
            # If multi-line, indent properly
            if "\n" in value_repr:
                lines = value_repr.split("\n")
                indented_lines = [lines[0]] + [base_indent + line for line in lines[1:]]
                indented_value = "\n".join(indented_lines)
                items.append(f"{k}={indented_value}")
            else:
                items.append(f"{k}={value_repr}")

    # If there are any attributes, show them
    if items:
        # Check if we should use flat format (2 or fewer attrs, all single-line)
        if len(items) <= 2 and all("\n" not in item for item in items):
            # Flat single-line case
            formatted_items = ", ".join(items)
            return f"{obj.__class__.__name__}({formatted_items})"
        else:
            # Multi-line case with proper indentation
            formatted_items = f",\n{base_indent}".join(items)
            close_indent = "  " * _depth
            return f"{obj.__class__.__name__}(\n{base_indent}{formatted_items}\n{close_indent})"
    else:
        # Default: show class name with no attrs
        return f"{obj.__class__.__name__}()"
