__version__ = "0.0.1"

__all__ = [
    "__version__",
    # Top level services
    "OpenflowService",
    "VSwitchService",
    # Modules
    "action",
    "exceptions",
    "flow",
    "match",
    "openflow",
    "vswitch",
    # Core classes
    "Bucket",
    "Flow",
    "FlowStats",
    "Group",
    "MatchFlow",
    "Table",
    # Enums
    "CTState",
    "FailMode",
    "FlowDirectiveType",
    "GroupCommonBucketID",
    "GroupType",
    "InterfaceType",
    "MultipathAlgorithm",
    "OpenFlowProtocol",
    "PortAction",
    "Protocol",
    "TCPFlag",
]

# Lazy import mapping
from typing import TYPE_CHECKING, Any

_LAZY_IMPORTS = {
    # Modules
    "action": (".", "action"),
    "exceptions": (".", "exceptions"),
    "flow": (".", "flow"),
    "match": (".", "match"),
    "openflow": (".", "openflow"),
    "vswitch": (".", "vswitch"),
    # From action
    "MultipathAlgorithm": (".action", "MultipathAlgorithm"),
    # From flow
    "Flow": (".flow", "Flow"),
    "FlowStats": (".flow", "FlowStats"),
    "MatchFlow": (".flow", "MatchFlow"),
    "Protocol": (".flow", "Protocol"),
    # From group
    "Bucket": (".group", "Bucket"),
    "Group": (".group", "Group"),
    "GroupCommonBucketID": (".group", "GroupCommonBucketID"),
    "GroupType": (".group", "GroupType"),
    # From match
    "CTState": (".match", "CTState"),
    "TCPFlag": (".match", "TCPFlag"),
    # From openflow
    "FlowDirectiveType": (".openflow", "FlowDirectiveType"),
    "OpenflowService": (".openflow", "OpenflowService"),
    "PortAction": (".openflow", "PortAction"),
    # From table
    "Table": (".table", "Table"),
    # From vswitch
    "FailMode": (".vswitch", "FailMode"),
    "InterfaceType": (".vswitch", "InterfaceType"),
    "OpenFlowProtocol": (".vswitch", "OpenFlowProtocol"),
    "VSwitchService": (".vswitch", "VSwitchService"),
}


def __getattr__(name: str) -> Any:
    """Lazy import mechanism for module-level attributes."""
    if name in _LAZY_IMPORTS:
        module_path, attr_name = _LAZY_IMPORTS[name]

        # Import the module
        if module_path == ".":
            # It's a submodule import (e.g., from . import action)
            from importlib import import_module

            module = import_module(module_path + attr_name, package=__name__)
            globals()[name] = module
            return module
        else:
            # It's an attribute from a submodule (e.g., from .flow import Flow)
            from importlib import import_module

            module = import_module(module_path, package=__name__)
            attr = getattr(module, attr_name)
            globals()[name] = attr
            return attr

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    """Return list of available attributes for dir() and autocomplete."""
    return sorted(__all__)


if TYPE_CHECKING:
    # These imports are only for type checkers / IDEs.
    # They are NOT executed at runtime.
    from . import action, exceptions, flow, match, openflow, vswitch
    from .action import MultipathAlgorithm
    from .flow import Flow, FlowStats, MatchFlow, Protocol
    from .group import Bucket, Group, GroupCommonBucketID, GroupType
    from .match import CTState, TCPFlag
    from .openflow import FlowDirectiveType, OpenflowService, PortAction
    from .table import Table
    from .vswitch import FailMode, InterfaceType, OpenFlowProtocol, VSwitchService
