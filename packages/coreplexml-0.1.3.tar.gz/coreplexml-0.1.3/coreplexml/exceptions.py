from __future__ import annotations

"""Exception classes for the CorePlexML Python SDK.

All SDK exceptions inherit from :class:`CorePlexMLError`.
"""


class CorePlexMLError(Exception):
    """Base exception for all CorePlexML SDK errors.

    Attributes:
        message: Human-readable error message.
        status_code: HTTP status code (if applicable).
        detail: Detailed error information from the server.
    """

    def __init__(self, message: str, status_code: int | None = None, detail: str | None = None):
        """Initialize error.

        Args:
            message: Error description.
            status_code: HTTP status code.
            detail: Server error detail.
        """
        self.message = message
        self.status_code = status_code
        self.detail = detail
        super().__init__(message)


class AuthenticationError(CorePlexMLError):
    """Raised when authentication fails (HTTP 401 or 403).

    This indicates an invalid, expired, or missing API key.
    """

    pass


class NotFoundError(CorePlexMLError):
    """Raised when a resource is not found (HTTP 404).

    The requested resource (project, dataset, model, etc.) does not exist
    or is not accessible to the current user.
    """

    pass


class ValidationError(CorePlexMLError):
    """Raised when input validation fails (HTTP 422).

    The request body or parameters did not pass server-side validation.
    """

    pass
