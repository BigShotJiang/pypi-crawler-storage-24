"""CorePlexML Python SDK.

A Python client for the CorePlexML AutoML & MLOps platform.
Provides typed access to projects, datasets, experiments, models,
deployments, reports, privacy suite, synthetic data generation,
and what-if analysis.

Quick start::

    from coreplexml import CorePlexMLClient

    client = CorePlexMLClient("https://your-domain.com", api_key="your-key")
    projects = client.projects.list()

Version: 0.1.3
"""
from coreplexml.client import CorePlexMLClient
from coreplexml.exceptions import CorePlexMLError, AuthenticationError, NotFoundError, ValidationError

__version__ = "0.1.3"
__all__ = ["CorePlexMLClient", "CorePlexMLError", "AuthenticationError", "NotFoundError", "ValidationError", "__version__"]
