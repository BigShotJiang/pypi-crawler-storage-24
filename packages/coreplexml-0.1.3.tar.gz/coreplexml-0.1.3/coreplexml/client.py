from __future__ import annotations

"""Main CorePlexML client."""

from coreplexml._http import HTTPClient
from coreplexml.projects import ProjectsResource
from coreplexml.datasets import DatasetsResource
from coreplexml.experiments import ExperimentsResource
from coreplexml.models import ModelsResource
from coreplexml.deployments import DeploymentsResource
from coreplexml.reports import ReportsResource
from coreplexml.privacy import PrivacyResource
from coreplexml.synthgen import SynthGenResource
from coreplexml.studio import StudioResource


class CorePlexMLClient:
    """Top-level client for the CorePlexML Python SDK.

    Provides access to all API resources through typed sub-clients.

    Args:
        base_url: CorePlexML server URL (default ``http://localhost:8888``).
        api_key: Bearer token for API authentication.
        timeout: Request timeout in seconds (default 30).

    Example::

        from coreplexml import CorePlexMLClient

        client = CorePlexMLClient("https://your-domain.com", api_key="your-key")
        projects = client.projects.list()

    Attributes:
        projects: Manage projects.
        datasets: Upload, list, and manage datasets.
        experiments: Create and monitor AutoML experiments.
        models: Get model info and make predictions.
        deployments: Deploy models and manage production endpoints.
        reports: Generate and download reports.
        privacy: Privacy Suite -- PII detection and data transformation.
        synthgen: Synthetic data generation with CTGAN/CopulaGAN/TVAE/Gaussian Copula.
        studio: What-If Analysis -- scenario comparison.
    """

    def __init__(self, base_url: str = "http://localhost:8888", api_key: str | None = None, timeout: int = 30):
        """Initialize the CorePlexML client.

        Args:
            base_url: Server URL (default ``http://localhost:8888``).
            api_key: API key for Bearer authentication.
            timeout: Request timeout in seconds.
        """
        self._http = HTTPClient(base_url, api_key=api_key, timeout=timeout)
        self.projects = ProjectsResource(self._http)
        self.datasets = DatasetsResource(self._http)
        self.experiments = ExperimentsResource(self._http)
        self.models = ModelsResource(self._http)
        self.deployments = DeploymentsResource(self._http)
        self.reports = ReportsResource(self._http)
        self.privacy = PrivacyResource(self._http)
        self.synthgen = SynthGenResource(self._http)
        self.studio = StudioResource(self._http)

    def close(self) -> None:
        """Close the underlying HTTP session and release connections."""
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __repr__(self) -> str:
        return f"CorePlexMLClient(base_url={self._http.base_url!r})"
