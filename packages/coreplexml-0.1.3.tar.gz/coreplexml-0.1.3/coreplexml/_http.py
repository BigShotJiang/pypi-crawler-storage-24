from __future__ import annotations

"""HTTP transport layer for the CorePlexML Python SDK.

Provides low-level HTTP methods with automatic error handling,
authentication, retry logic, and job polling support.
"""

import time
import logging
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from coreplexml.exceptions import CorePlexMLError, AuthenticationError, NotFoundError, ValidationError

logger = logging.getLogger(__name__)

_SDK_VERSION = "0.1.3"


class HTTPClient:
    """Low-level HTTP client with error handling, retries, and job polling."""

    def __init__(self, base_url: str, api_key: str | None = None, timeout: int = 30):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers["User-Agent"] = f"coreplexml-python/{_SDK_VERSION}"
        self.session.headers["Content-Type"] = "application/json"
        if api_key:
            self.session.headers["Authorization"] = f"Bearer {api_key}"

        # Retry transient failures with exponential backoff
        retry = Retry(
            total=3,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "PUT", "DELETE", "HEAD", "OPTIONS"],
        )
        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def close(self) -> None:
        """Close the underlying HTTP session and release connections."""
        self.session.close()

    def __repr__(self) -> str:
        return f"HTTPClient(base_url={self.base_url!r})"

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _request(self, method: str, path: str, **kwargs) -> requests.Response:
        """Execute HTTP request with connection error wrapping."""
        kwargs.setdefault("timeout", self.timeout)
        try:
            return self.session.request(method, self._url(path), **kwargs)
        except requests.exceptions.Timeout as e:
            raise CorePlexMLError(f"Request timed out: {e}") from e
        except requests.exceptions.ConnectionError as e:
            raise CorePlexMLError(f"Connection failed: {e}") from e
        except requests.exceptions.RequestException as e:
            raise CorePlexMLError(f"Request failed: {e}") from e

    def _handle_response(self, resp: requests.Response) -> dict:
        """Process HTTP response and raise typed exceptions on errors."""
        if resp.status_code == 204:
            return {}
        try:
            data = resp.json()
        except Exception:
            text = resp.text[:500] if resp.text else "No response body"
            data = {"detail": text}

        if resp.status_code >= 400:
            detail = data.get("detail", str(data)) if isinstance(data, dict) else str(data)
            msg = f"HTTP {resp.status_code}: {detail}"
            if resp.status_code in (401, 403):
                raise AuthenticationError(msg, resp.status_code, detail)
            elif resp.status_code == 404:
                raise NotFoundError(msg, resp.status_code, detail)
            elif resp.status_code == 422:
                raise ValidationError(msg, resp.status_code, detail)
            else:
                raise CorePlexMLError(msg, resp.status_code, detail)
        return data

    def get(self, path: str, params: dict | None = None) -> dict:
        """Send GET request."""
        resp = self._request("GET", path, params=params)
        return self._handle_response(resp)

    def post(self, path: str, json: dict | None = None, files: dict | None = None) -> dict:
        """Send POST request."""
        if files:
            saved_ct = self.session.headers.pop("Content-Type", None)
            try:
                resp = self._request("POST", path, data=json, files=files)
            finally:
                if saved_ct:
                    self.session.headers["Content-Type"] = saved_ct
        else:
            resp = self._request("POST", path, json=json)
        return self._handle_response(resp)

    def put(self, path: str, json: dict | None = None) -> dict:
        """Send PUT request."""
        resp = self._request("PUT", path, json=json)
        return self._handle_response(resp)

    def patch(self, path: str, json: dict | None = None) -> dict:
        """Send PATCH request."""
        resp = self._request("PATCH", path, json=json)
        return self._handle_response(resp)

    def delete(self, path: str) -> dict:
        """Send DELETE request."""
        resp = self._request("DELETE", path)
        return self._handle_response(resp)

    def download(self, path: str, output_path: str, params: dict | None = None) -> str:
        """Download a file from the API.

        Returns:
            The output_path where the file was saved.
        """
        resp = self._request("GET", path, params=params, stream=True)
        if resp.status_code >= 400:
            self._handle_response(resp)  # raises typed exception
        with open(output_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)
        return output_path

    def poll_job(self, job_id: str, interval: float = 3.0, timeout: float = 600.0) -> dict:
        """Poll a job until completion or timeout."""
        start = time.time()
        while time.time() - start < timeout:
            data = self.get(f"/api/jobs/{job_id}")
            job = data.get("job", data) if isinstance(data, dict) else {}
            status = job.get("status", "") if isinstance(job, dict) else ""
            if status in ("succeeded", "completed", "failed", "error"):
                return job if isinstance(job, dict) else data
            time.sleep(interval)
        raise CorePlexMLError(f"Job {job_id} timed out after {timeout}s")

    def upload(self, path: str, file_path: str, fields: dict | None = None) -> dict:
        """Upload a file via multipart form."""
        import os
        filename = os.path.basename(file_path)
        with open(file_path, "rb") as f:
            files = {"file": (filename, f)}
            return self.post(path, json=fields, files=files)
