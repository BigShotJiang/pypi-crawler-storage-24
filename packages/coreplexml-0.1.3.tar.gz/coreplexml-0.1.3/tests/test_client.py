"""Unit tests for CorePlexML SDK (mock-based)."""
import unittest
from unittest.mock import patch, MagicMock
from coreplexml import CorePlexMLClient
from coreplexml.exceptions import NotFoundError, AuthenticationError


class TestCorePlexMLClient(unittest.TestCase):
    def setUp(self):
        self.client = CorePlexMLClient("http://localhost:8888", api_key="test.key")

    def test_client_init(self):
        assert self.client._http.base_url == "http://localhost:8888"
        assert self.client.projects is not None
        assert self.client.datasets is not None

    @patch("coreplexml._http.requests.Session")
    def test_projects_list(self, mock_session_cls):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"items": [{"id": "p1", "name": "Test"}], "total": 1}

        mock_session = MagicMock()
        mock_session.request.return_value = mock_resp
        mock_session.headers = {}
        mock_session_cls.return_value = mock_session

        client = CorePlexMLClient("http://localhost:8888", api_key="test.key")
        result = client.projects.list()
        assert result["items"][0]["name"] == "Test"

    def test_resources_available(self):
        """Verify all resource objects are properly initialized."""
        assert hasattr(self.client, "projects")
        assert hasattr(self.client, "datasets")
        assert hasattr(self.client, "experiments")
        assert hasattr(self.client, "models")
        assert hasattr(self.client, "deployments")
        assert hasattr(self.client, "reports")
        assert hasattr(self.client, "privacy")
        assert hasattr(self.client, "synthgen")
        assert hasattr(self.client, "studio")


if __name__ == "__main__":
    unittest.main()
