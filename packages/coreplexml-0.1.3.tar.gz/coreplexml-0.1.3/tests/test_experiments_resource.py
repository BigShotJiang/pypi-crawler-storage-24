from unittest.mock import MagicMock

from coreplexml.experiments import ExperimentsResource


def _resource():
    http = MagicMock()
    http.post.return_value = {"ok": True}
    http.get.return_value = {"ok": True}
    return ExperimentsResource(http), http


def test_create_single_engine_payload():
    resource, http = _resource()
    resource.create(
        project_id="p1",
        dataset_version_id="dv1",
        target_column="target",
        engine="h2o",
        execution_mode="single",
        config={"max_models": 5},
    )

    _, kwargs = http.post.call_args
    assert kwargs["json"]["engine"] == "h2o"
    assert kwargs["json"]["execution_mode"] == "single"
    assert "engines" not in kwargs["json"]


def test_create_parallel_payload():
    resource, http = _resource()
    resource.create(
        project_id="p1",
        dataset_version_id="dv1",
        target_column="target",
        engines=["h2o", "flaml"],
        execution_mode="parallel",
        use_gpu=True,
    )

    _, kwargs = http.post.call_args
    assert kwargs["json"]["engines"] == ["h2o", "flaml"]
    assert kwargs["json"]["execution_mode"] == "parallel"
    assert kwargs["json"]["use_gpu"] is True


def test_capabilities_and_engine_runs_endpoints():
    resource, http = _resource()
    resource.capabilities()
    resource.engine_runs("exp_1")

    assert http.get.call_args_list[0].args[0] == "/api/experiments/capabilities"
    assert http.get.call_args_list[1].args[0] == "/api/experiments/exp_1/engine-runs"
