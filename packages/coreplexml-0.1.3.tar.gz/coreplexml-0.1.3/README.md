# CorePlexML Python SDK

Official Python client for the [CorePlexML](https://coreplexml.io) AutoML & MLOps platform.

## Installation

```bash
pip install coreplexml
```

## Quick Start

```python
from coreplexml import CorePlexMLClient

client = CorePlexMLClient(
    base_url="https://platform.coreplexml.io",
    api_key="your-api-key"
)

# List projects
projects = client.projects.list()

# Create a project
project = client.projects.create(name="My ML Project")

# Upload a dataset
dataset = client.datasets.upload(
    project_id=project["id"],
    file_path="data.csv",
    name="Training Data"
)

# Run an AutoML experiment
caps = client.experiments.capabilities()
print(caps["allowed_engines"], caps["execution_modes"])

experiment = client.experiments.create(
    project_id=project["id"],
    dataset_version_id=dataset["dataset_version_id"],
    target_column="label",
    problem_type="classification",
    engine="h2o",
    execution_mode="single",
    config={"max_models": 10, "max_runtime_secs": 300}
)

# Get the best model
models = client.models.list(project_id=project["id"])
best = models["items"][0]

# Deploy
deployment = client.deployments.create(
    project_id=project["id"],
    model_id=best["id"],
    name="production-v1"
)

# Predict
result = client.deployments.predict(
    deployment_id=deployment["id"],
    inputs={"feature1": 1.0, "feature2": "A"}
)
print(result["predictions"])
```

## Resources

The client provides access to all platform resources:

| Resource | Description |
|----------|-------------|
| `client.projects` | Project CRUD |
| `client.datasets` | Dataset upload, versions, columns |
| `client.experiments` | AutoML experiment management |
| `client.models` | Model listing, metrics, explainability |
| `client.deployments` | Deploy models, predict, A/B tests |
| `client.reports` | Generate PDF/HTML reports |
| `client.privacy` | Privacy Suite (PII detection, compliance) |
| `client.synthgen` | Synthetic data generation (CTGAN, TVAE) |
| `client.studio` | What-If analysis sessions |

## Authentication

Create an API key from **Profile > API Keys** in the platform, then:

```python
client = CorePlexMLClient(
    base_url="https://platform.coreplexml.io",
    api_key="cpx_your_api_key_here"
)
```

## Error Handling

```python
from coreplexml import CorePlexMLClient, NotFoundError, ValidationError

try:
    client.projects.get("nonexistent-id")
except NotFoundError:
    print("Project not found")
except ValidationError as e:
    print(f"Validation error: {e}")
```

## Requirements

- Python >= 3.9
- `requests` >= 2.28

## Plan-Aware AutoML

```python
# Pro: choose one engine
client.experiments.create(
    project_id=project["id"],
    dataset_version_id="VERSION_UUID",
    target_column="label",
    problem_type="classification",
    engine="flaml",
    execution_mode="single"
)

# Enterprise: parallel engines
exp = client.experiments.create(
    project_id=project["id"],
    dataset_version_id="VERSION_UUID",
    target_column="label",
    problem_type="classification",
    execution_mode="parallel",
    engines=["h2o", "flaml"]
)
print(client.experiments.engine_runs(exp.get("experiment_id") or exp["id"]))
```

## Links

- [Platform](https://platform.coreplexml.io)
- [API Documentation](https://platform.coreplexml.io/docs/site/)
- [Website](https://coreplexml.io)

## License

Business Source License 1.1
