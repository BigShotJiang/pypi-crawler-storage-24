from setuptools import setup, find_packages
from pathlib import Path

long_description = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="coreplexml",
    version="0.1.3",
    description="Python SDK for CorePlexML AutoML & MLOps platform",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Rodrigo Henríquez M. - Intellicore",
    author_email="r@coreplexml.io",
    url="https://coreplexml.io",
    project_urls={
        "Platform": "https://platform.coreplexml.io",
        "Documentation": "https://platform.coreplexml.io/docs/site/",
        "Source": "https://platform.coreplexml.io/sdk",
    },
    packages=find_packages(exclude=["tests", "tests.*"]),
    python_requires=">=3.9",
    install_requires=["requests>=2.28"],
    license="BUSL-1.1",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
    ],
    keywords="automl mlops machine-learning h2o deployment monitoring",
)
