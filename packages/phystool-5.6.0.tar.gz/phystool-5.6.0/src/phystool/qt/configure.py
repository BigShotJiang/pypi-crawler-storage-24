from configparser import SectionProxy
from logging import getLogger
from pathlib import Path
import re

from PySide6.QtCore import QCoreApplication, QEventLoop, QProcess, Slot
from PySide6.QtGui import QPalette, Qt
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QFrame,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressDialog,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from phystool.config import CEDbDirNotFound, MyConfigParser, ConfigurationError, config
from phystool.qt.assets import save_assets


logger = getLogger(__name__)


_BUTTON_STYLE = """
QPushButton {
    border-radius: 25px;
    background-color: #2979FF;
    color: white;
    font-size: 24px;
    font-weight: bold;
}
QPushButton:hover {
    background-color: #1565C0;
}
"""


class ConfigFormWidget(QWidget):
    fields: list[tuple] = []

    def __init__(
        self,
        parent: "ConfigWidget",
        button: QPushButton,
        title: str,
        conf: SectionProxy | None = None,
    ):
        super().__init__(parent)
        button.setFixedSize(20, 20)
        button.setStyleSheet(_BUTTON_STYLE)

        layout = QFormLayout(self)

        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setFrameShadow(QFrame.Shadow.Sunken)
        layout.addRow(line)

        layout.addRow(title, button)
        layout.setAlignment(button, Qt.AlignmentFlag.AlignRight)

        self._mapped_fields: dict[str, QLineEdit | QCheckBox] = {}
        self._python_data: dict[str, str | bool | Path] = {}
        self._conf_data: dict[str, str] = {}
        for key, widget, default in self.fields:
            field = widget(self)
            if isinstance(field, QLineEdit):
                field.setText(conf.get(key, fallback=default) if conf else default)
            elif isinstance(field, QCheckBox):
                field.setChecked(
                    conf.getboolean(key, fallback=default) if conf else default
                )
            else:
                raise TypeError
            self._mapped_fields[key] = field
            layout.addRow(f"{key}:", field)

    def as_conf(self) -> dict[str, str]:
        self._validate()
        return self._conf_data

    def __getitem__(self, key: str) -> str | bool | Path:
        if not self._python_data:
            self._validate()
        return self._python_data[key]

    def _validate(self) -> None:
        self._conf_data = {}
        self._python_data = {}
        for key, field in self._mapped_fields.items():
            if isinstance(field, QLineEdit):
                tmp = field.text()
            elif isinstance(field, QCheckBox):
                tmp = field.isChecked()
            else:
                raise TypeError
            if validate := getattr(self, f"validate_{key}", None):
                tmp = validate(tmp)
            self._python_data[key] = tmp
            self._conf_data[key] = str(tmp)


class GeneralFormWidget(ConfigFormWidget):
    fields = [
        ("db", QLineEdit, "physdb_dev"),
        ("editor", QLineEdit, "kile"),
        ("delta", QLineEdit, "dark"),
        ("desktop", QCheckBox, True),
        ("icon", QCheckBox, True),
    ]

    def __init__(self, parent: "ConfigWidget", conf: MyConfigParser):
        button = QPushButton("+")
        button.setToolTip("Ajouter une base de donnée")
        button.clicked.connect(parent.add_database)
        super().__init__(parent, button, "Configuration générale", conf["general"])


class DatabaseFormWidget(ConfigFormWidget):
    fields = [
        ("path", QLineEdit, "~/physdb_dev"),
        ("repo", QLineEdit, "git@bitbucket.org:jdufour/physdb_dev.git"),
    ]

    def __init__(
        self,
        parent: "ConfigWidget",
        section_name: str,
        conf: MyConfigParser | None = None,
    ):
        self.db_name = section_name[3:]
        self.fields = [("name", QLineEdit, self.db_name)] + self.fields

        button = QPushButton("-")
        button.setObjectName(self.db_name)
        button.clicked.connect(parent.remove_database)
        super().__init__(
            parent,
            button,
            "Configurer la base de donnée",
            conf[section_name] if conf else None,
        )

    def validate_path(self, tmp: str) -> Path:
        return Path(tmp)

    def validate_repo(self, tmp: str) -> str:
        if not bool(re.match("git@.*:.*git", tmp)):
            raise ValueError(f"Format error '{tmp}' (git@<hostname>:<repository>.git).")
        return tmp

    def validate_name(self, tmp: str) -> str:
        self.db_name = tmp
        return tmp


class ConfigWidget(QWidget):
    def __init__(self, exception: Exception | None) -> None:
        super().__init__()
        self.setWindowTitle("Configuration")
        self.setMinimumWidth(750)
        self.setMinimumHeight(750)

        conf = MyConfigParser()
        if config.CONF_FILE.exists():
            conf.read(config.CONF_FILE)

        self._general_form = GeneralFormWidget(self, conf)
        self._db_forms = [
            DatabaseFormWidget(self, section_name, conf)
            for section_name in conf.sections()
            if section_name.startswith("db=")
        ]

        self._config_status = QLineEdit()
        self._config_status.setReadOnly(True)
        self._set_config_status(exception)

        layout = QVBoxLayout(self)
        layout.addWidget(self._config_status)
        layout.addWidget(self._config_status)
        layout.addWidget(self._general_form)
        for db_form in self._db_forms:
            layout.addWidget(db_form)

        if not self._db_forms:  # NOTE: add default database form
            self.add_database()

    def _set_config_status(self, exception: Exception | None = None):
        if exception:
            msg = f"{exception.__class__.__name__}: {exception}"
            color = "#ff0000"
        else:
            msg = "Configuration valable"
            color = "#000000"
        palette = self._config_status.palette()
        palette.setColor(QPalette.ColorRole.Text, color)
        self._config_status.setPalette(palette)
        self._config_status.setStyleSheet(f"background-color: #f0f0f0; color: {color};")
        self._config_status.setText(msg)

    @Slot()
    def add_database(self) -> None:
        db_form = DatabaseFormWidget(self, "db=physdb_dev")
        self._db_forms.append(db_form)
        self.layout().addWidget(db_form)

    @Slot()
    def remove_database(self) -> None:
        db_name = self.sender().objectName()
        for form in self._db_forms:
            if form.db_name == db_name:
                form.deleteLater()
        self._db_forms = [form for form in self._db_forms if form.db_name != db_name]

    def save(self) -> bool:
        conf = MyConfigParser()
        conf["general"] = self._general_form.as_conf()
        for form in self._db_forms:
            conf[f"db={form.db_name}"] = form.as_conf()

        if self._is_valid(conf):
            self._set_config_status()
            save_assets(
                bool(self._general_form["desktop"]),
                bool(self._general_form["icon"]),
            )
            with config.CONF_FILE.open("w") as out:
                conf.write(out)
            return True
        return False

    def _is_valid(self, conf: MyConfigParser) -> bool:
        try:
            conf.load()
            return True
        except CEDbDirNotFound as e:
            if self._git_clone(
                conf[f"db={e.db_name}"]["repo"],
                Path(conf[f"db={e.db_name}"]["path"]).expanduser(),
            ):
                return self._is_valid(conf)
            self._set_config_status(e)
        except ConfigurationError as e:
            self._set_config_status(e)
        return False

    def _git_clone(self, repo: str, path: Path) -> bool:
        reply = QMessageBox.question(
            self,
            "Git clone",
            f"Voulez-vous cloner le répertoire {repo} dans {path}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            busy_dialog = QProgressDialog("Cloning", "Annuler", 0, 0, self)
            busy_dialog.setAutoClose(False)
            busy_dialog.setCancelButton(None)
            busy_dialog.setWindowModality(Qt.WindowModality.WindowModal)
            busy_dialog.show()

            loop = QEventLoop()

            self._process = QProcess(self)
            self._process.finished.connect(loop.quit)
            self._process.finished.connect(busy_dialog.close)
            self._process.setProgram("git")
            self._process.setArguments(["clone", repo, str(path)])
            self._process.start()
            loop.exec()
            return True
        return False


class ConfigDialog(QDialog):
    def __init__(self, parent: QWidget):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        self._conf_widget = ConfigWidget(None)
        layout.addWidget(self._conf_widget)

        btn_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Close | QDialogButtonBox.StandardButton.Ok
        )
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)

    def accept(self) -> None:
        if self._conf_widget.save():
            super().accept()
        else:
            QMessageBox.critical(self, "Error", "La configuration n'est pas valable.")


class ConfigWindow(QMainWindow):
    def __init__(self, exception: Exception) -> None:
        super().__init__()
        QCoreApplication.setOrganizationName("phystool")
        QCoreApplication.setApplicationName("physnoob")
        self.setWindowTitle("Configuration")

        btn_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.close)

        self._conf_widget = ConfigWidget(exception)
        self._conf_widget.layout().addWidget(btn_box)
        self.setCentralWidget(self._conf_widget)

    @Slot()
    def accept(self):
        if self._conf_widget.save():
            QMessageBox.information(
                self, "Succès", "La configuration est valable, veuillez redémarrer."
            )
            super().close()
        else:
            QMessageBox.critical(self, "Erreur", "La configuration n'est pas valable.")


class PhysConfig(QApplication):
    def __init__(self, exception: Exception) -> None:
        super().__init__()
        self.setDesktopFileName("Physnoob")
        self.window = ConfigWindow(exception)
        self.window.show()
