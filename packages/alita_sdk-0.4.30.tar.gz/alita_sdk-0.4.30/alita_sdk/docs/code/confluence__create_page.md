# confluence - create_page

**Toolkit**: `confluence`
**Method**: `create_page`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def create_page(self, title: str, body: str, status: str = 'current', space: str = None, parent_id: str = None,
                    representation: str = 'storage', label: str = None):
        """ Creates a page in the Confluence space. Represents content in html (storage) or wiki (wiki) formats
            Page could be either published status='current' or make a draft with status='draft'
        """
        if self.client.get_page_by_title(space=self.space, title=title) is not None:
            return f"Page with title {title} already exists, please use other title."

        # normal user flow: put pages in the Space Home, not in the root of the Space
        user_space = space if space else self.space
        logger.info(f"Page will be created within the space {user_space}")

        # Handle parent_id properly - only fetch homepage if parent_id is not provided
        if parent_id:
            parent_id_filled = parent_id
        else:
            # Try to get space homepage, but handle cases where it doesn't exist
            try:
                space_info = self.client.get_space(user_space)
                parent_id_filled = space_info.get('homepage', {}).get('id')
                if not parent_id_filled:
                    logger.info(f"Space {user_space} has no homepage, creating page at space root level")
            except Exception as e:
                logger.warning(f"Could not retrieve space homepage: {e}. Creating page at space root level")
                parent_id_filled = None

        created_page = self.temp_create_page(space=user_space, title=title, body=body, status=status,
                                             parent_id=parent_id_filled, representation=representation)

        webui_path = created_page['_links']['edit'] if status == 'draft' else created_page['_links']['webui']
        page_details = {
            'title': created_page['title'],
            'id': created_page['id'],
            'space key': created_page['space']['key'],
            'author': created_page['version']['by']['displayName'],
            'link': self._build_page_url(webui_path)
        }

        logger.info(f"Page created: {page_details['link']}")

        if label:
            self.client.set_page_label(page_id=created_page['id'], label=label)
            logger.info(f"Label '{label}' added to the page '{title}'.")
            page_details['label'] = label

        self._add_default_labels(page_id=created_page['id'])

        parent_display = f"parent page '{parent_id_filled}'" if parent_id_filled else "space root level"
        return f"The page '{title}' was created under {parent_display}: '{page_details['link']}'. \nDetails: {str(page_details)}"
```
