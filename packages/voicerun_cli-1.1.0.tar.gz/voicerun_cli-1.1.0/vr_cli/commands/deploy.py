"""
vr deploy command - Deploy agent configuration to an environment.
"""

import sys
from pathlib import Path
from typing import Optional

import questionary
import typer

from vr_cli.utils.utils import (
    console,
    make_request,
    print_success,
    print_error,
    print_info,
    print_warning,
    confirm,
    calculate_project_checksum,
)
from vr_cli.utils.agent_lock import load_agent_lock
from vr_cli.entities.agent_environment import AgentEnvironmentRepository
from vr_cli.utils.helm import (
    require_helm,
    render_templates,
    HelmError,
)
from vr_cli.commands.validate import (
    run_project_validation,
)


def check_unpushed_changes(project_dir: Path, agent_lock: dict) -> bool:
    """
    Check if local project files have changed since the last push by comparing checksums.
    Returns True if safe to proceed, False if user aborts.
    """
    stored_checksum = agent_lock.get("checksum")
    if not stored_checksum:
        # No checksum stored (older push) — skip the check
        return True

    current_checksum = calculate_project_checksum(str(project_dir))

    if current_checksum == stored_checksum:
        return True

    console.print()
    print_warning("Local project files have changed since the last push.")
    print_info("Run 'vr push' first to ensure the deployed code matches your local changes.")

    if not sys.stdin.isatty():
        print_error("Aborting deploy due to unpushed changes in non-interactive mode.")
        print_info("Push your changes first, or use --yes (-y) to skip this check.")
        return False

    return confirm("Continue deploying anyway?", default=False)


def run_deploy_validation(project_dir: Path) -> bool:
    """Run validation checks before deploying. Returns True if valid."""
    result = run_project_validation(project_dir, include_handler=False)

    if not result.is_valid:
        console.print()
        console.print("[bold red]Validation failed:[/bold red]")
        for check, error in result.failed:
            console.print(f"  [red]✗[/red] {check}: {error}")
        console.print()
        return False

    return True


def deploy_to_api(agent_id: str, function_id: str, environment: str, resources: list[dict]) -> dict | None:
    """
    Deploy configuration to the API.

    Args:
        agent_id: The agent ID to deploy to
        function_id: The function ID associated with the agent
        environment: The environment name
        resources: List of rendered deployment resources

    Returns:
        API response or None on failure
    """
    payload = {
        "agentId": agent_id,
        "functionId": function_id,
        "environment": environment,
        "resources": resources,
    }

    response = make_request(
        "/v1/agents/deploy",
        method="POST",
        json=payload,
    )

    return response


def prompt_for_environment(agent_id: str) -> Optional[str]:
    """Prompt user to select an environment from available options on the agent."""
    # Check if stdin is a TTY - interactive prompts require a terminal
    if not sys.stdin.isatty():
        print_error("Cannot prompt for environment: not running in an interactive terminal")
        print_info("Specify the environment as an argument: vr deploy <environment>")
        return None

    repo = AgentEnvironmentRepository(agent_id)
    environments = repo.get()

    if not environments:
        print_error("No environments found for this agent")
        print_info("Create an environment in the VoiceRun dashboard first")
        return None

    # Build choices for questionary select
    choices = []
    for env in environments:
        # Format: "name (phone, stt_model)" for display
        label_parts = [env.name or "unnamed"]
        details = []
        if env.phone_number:
            details.append(env.phone_number)
        if env.stt_model:
            details.append(env.stt_model)
        if details:
            label_parts.append(f"({', '.join(details)})")

        choices.append(questionary.Choice(
            title=" ".join(label_parts),
            value=env.name,
        ))

    # Use questionary for interactive selection
    selected = questionary.select(
        "Select an environment to deploy to:",
        choices=choices,
    ).ask()

    if selected is None:
        # User cancelled (Ctrl+C)
        return None

    return selected


def deploy(
    environment: Optional[str] = typer.Argument(
        None,
        help="Environment to deploy to (e.g., development, production). If not specified, you'll be prompted to select.",
    ),
    values: Optional[Path] = typer.Option(
        None,
        "--values",
        "-f",
        help="Path to values file (required).",
        exists=True,
        resolve_path=True,
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip confirmation prompt.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Render and validate without deploying.",
    ),
):
    """
    Deploy agent configuration to an environment.

    This command renders your templates using Helm with the specified values
    and deploys the configuration to the VoiceRun API.

    Examples:
        vr deploy -f values.yaml                  # Select environment interactively
        vr deploy development -f values.yaml     # Deploy to development
        vr deploy production -f values.yaml -y   # Deploy to production without confirmation
        vr deploy development -f values.yaml --dry-run  # Preview without deploying
    """
    project_dir = Path.cwd()
    voicerun_dir = project_dir / ".voicerun"

    # Check if this is a voicerun project
    if not voicerun_dir.exists():
        print_error("Not a voicerun project (.voicerun directory not found)")
        print_info("Run 'vr init' to create a new project")
        raise typer.Exit(1)

    # Load agent lock to get agent ID (needed for environment listing)
    agent_lock = load_agent_lock(voicerun_dir)
    if not agent_lock or not agent_lock.get("id"):
        print_error("No agent.lock found. Run 'vr push' first to create an agent.")
        raise typer.Exit(1)

    agent_id = agent_lock.get("id")
    function_id = agent_lock.get("functionId")
    if not function_id:
        print_error("No functionId found in agent.lock. Run 'vr push' to update.")
        raise typer.Exit(1)

    # Check for unpushed changes (skip if --yes)
    if not yes and not check_unpushed_changes(project_dir, agent_lock):
        raise typer.Exit(1)

    # Prompt for environment if not provided
    if not environment:
        environment = prompt_for_environment(agent_id)
        if not environment:
            raise typer.Exit(1)

    # Check for Helm
    if not require_helm():
        raise typer.Exit(1)

    # Validate project
    print_info("Validating project...")
    if not run_deploy_validation(project_dir):
        raise typer.Exit(1)

    # Determine values file
    if not values:
        print_error("No values file specified")
        print_info("Specify a values file with --values (-f): vr deploy <environment> -f values.yaml")
        raise typer.Exit(1)

    values_file = values
    print_info(f"Using values file: {values_file}")

    # Render templates
    print_info("Rendering templates...")
    try:
        rendered_docs = render_templates(
            project_dir,
            values_file=values_file,
        )
    except HelmError as e:
        print_error(f"Template rendering failed: {e}")
        raise typer.Exit(1)

    if not rendered_docs:
        print_error("No templates to deploy")
        print_info("Add templates to .voicerun/templates/")
        raise typer.Exit(1)

    # Show summary
    console.print()
    console.print("[bold]Deploy Summary:[/bold]")
    console.print(f"  Agent ID: [cyan]{agent_id[:8]}...[/cyan]")
    console.print(f"  Environment: [yellow]{environment}[/yellow]")
    console.print(f"  Resources: [green]{len(rendered_docs)}[/green]")

    for doc in rendered_docs:
        kind = doc.get("kind", "Unknown")
        name = doc.get("metadata", {}).get("name", "unnamed")
        console.print(f"    - {kind}/{name}")

    console.print()

    # Dry run - just show what would be deployed
    if dry_run:
        print_info("Dry run - no changes made")
        console.print()
        console.print("[bold]Rendered configuration:[/bold]")
        import yaml
        for doc in rendered_docs:
            console.print("---")
            console.print(yaml.dump(doc, default_flow_style=False, sort_keys=False))
        raise typer.Exit(0)

    # Confirm deployment
    if not yes:
        if not sys.stdin.isatty():
            print_error("Cannot prompt for confirmation: not running in an interactive terminal")
            print_info("Use --yes (-y) flag to skip confirmation in non-interactive mode")
            raise typer.Exit(1)
        if not confirm(f"Deploy to {environment}?", default=True):
            print_info("Aborted")
            raise typer.Exit(0)

    # Deploy to API
    print_info("Deploying to server...")

    response = deploy_to_api(agent_id, function_id, environment, rendered_docs)

    if not response:
        print_error("Failed to deploy to server")
        raise typer.Exit(1)

    console.print()
    print_success(f"Deployed to {environment}!")

    # Show deployment details from response
    if isinstance(response, dict):
        deployment_id = response.get("deploymentId")
        if deployment_id:
            console.print(f"  Deployment ID: [cyan]{deployment_id}[/cyan]")
