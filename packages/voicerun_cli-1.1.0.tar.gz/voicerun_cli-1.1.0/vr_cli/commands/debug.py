"""
vr debug - Interactive voice agent debugger

Push local code and start an interactive debug session with bidirectional
audio communication for real-time testing.
"""

import asyncio
import base64
import json
import shutil
import ssl
import threading
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Callable
from urllib.parse import urlencode

import numpy as np
import typer
import websockets

from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.styles import Style as PTStyle

from vr_cli.utils.config import (
    INPUT_SAMPLE_RATE,
    OUTPUT_SAMPLE_RATE,
    DEBUG_ENV_NAME,
)
from vr_cli.utils.utils import make_request
from vr_cli.utils.audio_input import AudioInput
from vr_cli.utils.audio_output import AudioOutput
from vr_cli.commands.push import push_code
from vr_cli.utils.agent_lock import load_agent_lock


# ─────────────────────────────────────────────────────────────────────────────
# Theme & Styling
# ─────────────────────────────────────────────────────────────────────────────

class Theme:
    """Terminal color theme - disabled for compatibility."""
    USER = ""
    AGENT = ""
    SYSTEM = ""
    ERROR = ""
    WARNING = ""
    SUCCESS = ""
    ACCENT = ""
    DIVIDER = ""


# ─────────────────────────────────────────────────────────────────────────────
# Debug Message
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class DebugMessage:
    """Debug message received from the server."""
    type: str
    turn: int
    name: str
    data: dict


class DebugRenderer:
    """Renders debug messages to the terminal in a style similar to AgentMonitoring."""

    # Event icons mapping
    ICONS = {
        "start": "▶️ ",
        "stop": "⏹️ ",
        "interrupt": "⏸️ ",
        "end": "✓ ",
        "timeout": "⏱️ ",
        "text": "⌨️ ",
        "text_to_speech": "🔊",
        "transcript": "🎤",
        "audio": "🎵",
        "silence": "🔇",
        "transfer_call": "📞",
        "merge_call": "📞",
        "context": "📦",
        "error": "❌",
        "log": "ℹ️ ",
        "turn_end": "✅",
    }

    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.current_turn = 0

    def _format_event_name(self, name: str) -> str:
        """Format event name: replace underscores with spaces, capitalize."""
        return name.replace("_", " ").title()

    def _get_icon(self, name: str) -> str:
        """Get icon for event name."""
        return self.ICONS.get(name, "→ ")

    def render(self, message: DebugMessage) -> None:
        """Render a debug message to the terminal."""
        name = message.name or message.type or ""
        data = message.data or {}
        turn = message.turn

        # Render turn header if turn changed
        if turn != self.current_turn and turn is not None:
            self._render_turn_header(turn)
            self.current_turn = turn

        # Skip transcript events (shown via text event)
        if name == "transcript":
            return

        # Dispatch to specific handler or use generic
        handler = getattr(self, f"_render_{name}", None)
        if handler:
            handler(data, message.type)
        elif self.verbose:
            self._render_generic(name, data)

    def _render_turn_header(self, turn: int) -> None:
        """Render a turn header."""
        print()
        print(f"┌─ Turn {turn} ─────────────────────────────────────")

    def _render_user_header(self) -> None:
        """Render a local user input header."""
        print("│ 👤 User")

    def _render_turn_end(self, data: dict, msg_type: str = "") -> None:
        """Render turn completion with duration."""
        duration = data.get("duration", 0)
        print(f"└─ {int(duration)}ms")

    def _render_text(self, data: dict, msg_type: str = "") -> None:
        """Render text input."""
        text = data.get("text", "")
        source = data.get("source", "")
        if not text:
            return

        icon = self._get_icon("transcript" if source == "speech" else "text")
        source_label = f" (via {source})" if source else ""
        print(f"│ {icon} Text{source_label}")
        print(f"│    {text}")

    def _render_text_to_speech(self, data: dict, msg_type: str = "") -> None:
        """Render agent speech output."""
        text = data.get("text", "")
        if text:
            icon = self._get_icon("text_to_speech")
            print(f"│ {icon} Text To Speech")
            print(f"│    {text}")

    def _render_error(self, data: dict, msg_type: str = "") -> None:
        """Render an error message."""
        msg = data.get("message", data.get("error", str(data)))
        icon = self._get_icon("error")
        print(f"│ {icon} Error")
        print(f"│    {msg}")

    def _render_log(self, data: dict, msg_type: str = "") -> None:
        """Render a log message."""
        msg = data.get("message", "")
        if msg:
            icon = self._get_icon("log")
            print(f"│ {icon} Log")
            print(f"│    {msg}")

    def _render_context(self, data: dict, msg_type: str = "") -> None:
        """Render context info."""
        if self.verbose:
            icon = self._get_icon("context")
            keys = list(data.keys())[:5]
            more = f" (+{len(data.keys()) - 5} more)" if len(data.keys()) > 5 else ""
            print(f"│ {icon} Context")
            print(f"│    {', '.join(keys)}{more}")

    def _render_start(self, data: dict, msg_type: str = "") -> None:
        """Render session start."""
        icon = self._get_icon("start")
        print(f"│ {icon} Start")

    def _render_interrupt(self, data: dict, msg_type: str = "") -> None:
        """Render interruption event."""
        icon = self._get_icon("interrupt")
        print(f"│ {icon} Interrupt")

    def _render_transfer_call(self, data: dict, msg_type: str = "") -> None:
        """Render call transfer."""
        icon = self._get_icon("transfer_call")
        to = data.get("to", "")
        print(f"│ {icon} Transfer Call")
        if to:
            print(f"│    to: {to}")

    def _render_merge_call(self, data: dict, msg_type: str = "") -> None:
        """Render call merge."""
        icon = self._get_icon("merge_call")
        print(f"│ {icon} Merge Call")

    def _render_timeout(self, data: dict, msg_type: str = "") -> None:
        """Render timeout event."""
        icon = self._get_icon("timeout")
        print(f"│ {icon} Timeout")

    def _render_silence(self, data: dict, msg_type: str = "") -> None:
        """Render silence event."""
        icon = self._get_icon("silence")
        print(f"│ {icon} Silence")

    def _render_audio(self, data: dict, msg_type: str = "") -> None:
        """Render audio event."""
        icon = self._get_icon("audio")
        print(f"│ {icon} Audio")

    def _render_end(self, data: dict, msg_type: str = "") -> None:
        """Render end event."""
        icon = self._get_icon("end")
        print(f"│ {icon} End")

    def _render_stop(self, data: dict, msg_type: str = "") -> None:
        """Render stop event."""
        icon = self._get_icon("stop")
        print(f"│ {icon} Stop")

    def _render_generic(self, name: str, data: dict) -> None:
        """Render unknown event types (verbose mode)."""
        formatted_name = self._format_event_name(name)
        print(f"│ → {formatted_name}")

    def status(self, message: str) -> None:
        """Print a status message."""
        print(f"● {message}")


class WebSocketDebugClient:
    """WebSocket client for debugging voice agents with bidirectional audio."""

    def __init__(
        self,
        agent_id: str,
        function_id: Optional[str] = None,
        environment: Optional[str] = None,
        verbose: bool = False,
    ):
        self.agent_id = agent_id
        self.function_id = function_id
        self.environment = environment or ""
        self.verbose = verbose

        # Session state
        self.call_sid = ""
        self.stream_sid = ""
        self.websocket: Optional[websockets.WebSocketClientProtocol] = None
        self.server_url: Optional[str] = None
        self.custom_parameters: dict = {}

        # Connection state
        self.is_connected = False
        self.is_listening = False
        self.is_playing = False

        # Audio
        self.audio_input: Optional[AudioInput] = None
        self.audio_output: Optional[AudioOutput] = None

        # Callbacks
        self.on_connect: Optional[Callable] = None
        self.on_disconnect: Optional[Callable] = None
        self.on_debug_message: Optional[Callable[[DebugMessage], None]] = None

        # Redirect handling
        self._initial_agent_id = agent_id
        self._initial_environment = environment
        self._redirected = False
        self._last_redirect_key: Optional[str] = None

        # Internal
        self._stop_event = threading.Event()
        self._audio_task: Optional[asyncio.Task] = None

    def _log(self, message: str) -> None:
        """Log a message if verbose mode is enabled."""
        if self.verbose:
            print(f"→ {message}")

    async def _get_agent_config(self) -> dict:
        """Fetch agent configuration from the API."""
        params = {"inputType": "mic"}

        # Embed functionId in environment parameter if present
        if self.environment:
            env_str = self.environment
            if self.function_id and self.function_id.strip():
                env_str = f"{self.environment}|{self.function_id}"
            params["environment"] = env_str

        # Add custom parameters (non-empty only)
        for key, value in self.custom_parameters.items():
            if value:
                params[f"custom_{key}"] = value

        endpoint = f"/v1/agents/{self.agent_id}/call?{urlencode(params)}"
        self._log(f"API call: {endpoint}")

        response = make_request(endpoint, method="POST", json={})
        self._log(f"API response: {response}")

        if response and "data" in response:
            return response["data"]

        raise Exception("Failed to get agent configuration")

    async def connect(self) -> None:
        """Initialize the WebSocket connection."""
        self.call_sid = str(uuid.uuid4())
        self.stream_sid = str(uuid.uuid4())

        # Fetch server URL
        if not self.server_url:
            config = await self._get_agent_config()
            self.server_url = config.get("url")
            self.custom_parameters = config.get("parameters", {})
            self._log(f"Config: {config}")

        if not self.server_url:
            raise Exception("No server URL available")

        self._log(f"Connecting to {self.server_url}")

        # Connect with permissive SSL for local dev
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE

        self.websocket = await websockets.connect(self.server_url, ssl=ssl_context)
        self.is_connected = True

        # Build start message parameters
        env_string = self.environment
        if self.function_id and self.function_id.strip():
            env_string = f"{self.environment}|{self.function_id}"

        params = {
            k: v for k, v in self.custom_parameters.items() if v and str(v).strip()
        }
        params.update({
            "agentId": self.agent_id,
            "environment": env_string,
            "inputType": "mic",
            "origin": "debugger",
        })
        params.pop("functionId", None)  # Remove if empty

        self._log(f"Start params: {params}")

        await self.websocket.send(json.dumps({
            "start": {
                "streamSid": self.stream_sid,
                "callSid": self.call_sid,
                "customParameters": params,
            }
        }))

        if self.on_connect:
            self.on_connect()

    async def disconnect(self) -> None:
        """Close the WebSocket connection and clean up resources."""
        self._stop_event.set()

        await self.stop_listening()

        if self.audio_output:
            self.audio_output.stop_playback()

        if self.websocket:
            await self.websocket.close()
            self.websocket = None

        self.is_connected = False
        self._last_redirect_key = None
        self.server_url = None
        self.custom_parameters = {}

        # Restore initial agent if redirected
        if self._redirected:
            self.agent_id = self._initial_agent_id
            self.environment = self._initial_environment or ""
            self._redirected = False
            self._log(f"Restored agent: {self.agent_id}")

        if self.on_disconnect:
            self.on_disconnect()

    async def start_listening(self) -> None:
        """Start capturing audio from the microphone."""
        if self.is_listening or not self.is_connected:
            return

        if not self.audio_input:
            self.audio_input = AudioInput(sample_rate=INPUT_SAMPLE_RATE)
        if not self.audio_output:
            self.audio_output = AudioOutput()

        self._stop_event.clear()
        self.audio_input.start_recording()
        self.is_listening = True
        self._audio_task = asyncio.create_task(self._send_audio_loop())

    async def stop_listening(self) -> None:
        """Stop capturing audio from the microphone."""
        if not self.is_listening:
            return

        self._stop_event.set()

        if self._audio_task:
            self._audio_task.cancel()
            try:
                await self._audio_task
            except asyncio.CancelledError:
                pass
            self._audio_task = None

        if self.audio_input:
            self.audio_input.stop_recording()

        self.is_listening = False

    async def send_text(self, text: str) -> None:
        """Send a text message to the server."""
        if not self.websocket or not self.is_connected:
            return

        await self.websocket.send(json.dumps({"event": "text", "text": text}))
        self._log(f"Sent text: {text}")

    async def _send_audio_loop(self) -> None:
        """Continuously send audio data to the server."""
        try:
            while not self._stop_event.is_set() and self.is_connected:
                if not self.audio_input:
                    await asyncio.sleep(0.01)
                    continue

                audio_chunk = self.audio_input.get_audio_chunk()
                if audio_chunk is None:
                    await asyncio.sleep(0.01)
                    continue

                # During playback, only send loud audio (likely interruption)
                if self.is_playing:
                    level = self.audio_input.get_audio_level(audio_chunk)
                    if level <= 0.05:
                        continue

                await self._send_audio(audio_chunk)

        except asyncio.CancelledError:
            pass
        except Exception as e:
            self._log(f"Audio loop error: {e}")

    async def _send_audio(self, audio_data: np.ndarray) -> None:
        """Encode and send audio data to server."""
        if not self.websocket or not self.is_connected:
            return

        try:
            mulaw_data = self.audio_input.mu_law_encode(audio_data)
            payload = base64.b64encode(mulaw_data).decode("utf-8")

            await self.websocket.send(json.dumps({
                "event": "media",
                "streamSid": self.stream_sid,
                "media": {"payload": payload}
            }))
        except Exception as e:
            self._log(f"Send audio error: {e}")

    async def receive_messages(self) -> None:
        """Main loop to receive and handle WebSocket messages."""
        try:
            async for message in self.websocket:
                try:
                    await self._handle_message(json.loads(message))
                except json.JSONDecodeError:
                    self._log(f"Parse error: {message[:100]}")
        except websockets.exceptions.ConnectionClosed:
            pass
        except Exception as e:
            self._log(f"Receive error: {e}")

    async def _handle_message(self, data: dict) -> None:
        """Route message to appropriate handler."""
        handlers = {
            "media": self._handle_audio,
            "clear": self._handle_clear,
            "mark": self._handle_mark,
            "debug": self._handle_debug,
            "control": self._handle_control,
        }
        handler = handlers.get(data.get("event"))
        if handler:
            await handler(data)

    async def _handle_audio(self, data: dict) -> None:
        """Handle incoming audio data."""
        payload = data.get("media", {}).get("payload")
        if not payload or not self.audio_output:
            return

        audio_bytes = base64.b64decode(payload)

        if self.audio_input and not self.is_playing:
            self.audio_input.notify_playback_started()

        self.is_playing = True
        self.audio_output.play_pcm_bytes(audio_bytes, sample_rate=OUTPUT_SAMPLE_RATE)

    async def _handle_clear(self, data: dict) -> None:
        """Handle clear message - stop playback."""
        self._log("Clear received")
        if self.audio_output:
            self.audio_output.stop_playback()
        self.is_playing = False

    async def _handle_mark(self, data: dict) -> None:
        """Handle mark events."""
        mark = data.get("mark", {})
        self._log(f"Mark: {mark.get('name', '')}")

        if self.audio_output and self.websocket:
            self.audio_output.add_mark_event({
                "event": "mark",
                "streamSid": self.stream_sid,
                "mark": mark
            }, self.websocket)

    async def _handle_debug(self, data: dict) -> None:
        """Handle debug messages."""
        msg = DebugMessage(
            type=data.get("type", ""),
            turn=data.get("turn", 0),
            name=data.get("name", ""),
            data=data.get("data", {})
        )

        if self.on_debug_message:
            self.on_debug_message(msg)

    async def _handle_control(self, data: dict) -> None:
        """Handle control messages (redirects)."""
        if data.get("name") != "redirect":
            return

        control = data.get("data", {})
        target_agent = control.get("agentId")
        target_env = control.get("environment", self.environment)

        if not target_agent:
            return

        # Idempotence check
        key = f"{target_agent}|{target_env or ''}"
        is_current = (
            target_agent == self.agent_id and
            (target_env or "") == (self.environment or "") and
            self.is_connected
        )

        if is_current or self._last_redirect_key == key:
            return

        self._log(f"Redirecting to: {target_agent}")

        # Stop and reconnect
        await self.stop_listening()
        if self.audio_output:
            self.audio_output.stop_playback()
        if self.websocket:
            await self.websocket.close()

        self.agent_id = target_agent
        self.environment = target_env or self.environment
        self._redirected = True
        self._last_redirect_key = key
        self.server_url = None

        await self.connect()
        await self.start_listening()


async def run_debug_session(
    agent_id: str,
    function_id: Optional[str] = None,
    environment: Optional[str] = None,
    verbose: bool = False,
) -> None:
    """Run an interactive debug session with a voice agent."""

    renderer = DebugRenderer(verbose=verbose)
    client = WebSocketDebugClient(
        agent_id=agent_id,
        function_id=function_id,
        environment=environment,
        verbose=verbose,
    )

    # Wire up callbacks
    client.on_connect = lambda: renderer.status("connected")
    client.on_disconnect = lambda: renderer.status("disconnected")
    client.on_debug_message = renderer.render

    def get_prompt():
        width = shutil.get_terminal_size().columns
        return FormattedText([
            ("class:divider", "─" * width + "\n"),
            ("", "❯ "),
        ])

    # Build info for bottom toolbar
    fn_id_display = function_id if function_id else "latest"

    def bottom_toolbar():
        width = shutil.get_terminal_size().columns
        return FormattedText([
            ("class:divider", "─" * width + "\n"),
            ("class:label", "  agent: "),
            ("class:value-cyan", f"{agent_id}"),
            ("class:label", "  function: "),
            ("class:value-green", f"{fn_id_display}"),
            ("class:label", "  env: "),
            ("class:value-yellow", f"{environment}"),
        ])

    # Style for toolbar and prompt
    toolbar_style = PTStyle.from_dict({
        "bottom-toolbar": "noreverse",
        "divider": "noreverse #3a3a3a",
        "label": "noreverse #888888",
        "value-cyan": "noreverse #00d7ff",
        "value-green": "noreverse #87d787",
        "value-yellow": "noreverse #ffaf00",
    })

    session = PromptSession(bottom_toolbar=bottom_toolbar, style=toolbar_style)

    try:
        # Header
        print()
        print("🔊 voicerun debug")
        print("   ctrl+c to exit | type to send text")
        print()

        await client.connect()
        await client.start_listening()
        renderer.status("listening 🎧")
        print()

        receive_task = asyncio.create_task(client.receive_messages())

        async def handle_input():
            while client.is_connected:
                try:
                    with patch_stdout():
                        line = await session.prompt_async(get_prompt)
                    if line and line.strip():
                        renderer._render_user_header()
                        print(f"  {line.strip()}")
                        await client.send_text(line.strip())
                except (EOFError, KeyboardInterrupt):
                    break
                except Exception:
                    break

        input_task = asyncio.create_task(handle_input())

        done, pending = await asyncio.wait(
            [receive_task, input_task],
            return_when=asyncio.FIRST_COMPLETED
        )

        for task in pending:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

    except KeyboardInterrupt:
        print()
    except Exception as e:
        print(f"❌ Session error: {e}")
    finally:
        await client.disconnect()
        print()
        print("👋 session ended")


def _start_outbound_call(
    agent_id: str,
    to_phone_number: str,
    from_phone_number: Optional[str],
    environment: str,
) -> None:
    """Start an outbound phone call via the session start API."""
    print(f"📞 Starting outbound call to {to_phone_number}...")

    input_parameters = {"toPhoneNumber": to_phone_number}
    if from_phone_number:
        input_parameters["fromPhoneNumber"] = from_phone_number

    response = make_request(
        f"/v1/agents/{agent_id}/sessions/start",
        method="POST",
        json={
            "inputType": "phone",
            "inputParameters": input_parameters,
            "environment": environment,
            "parameters": {},
        },
    )

    if not response:
        print("❌ Failed to start outbound call")
        raise typer.Exit(1)

    call_id = response.get("data", {}).get("telephonyCallId", "unknown")
    print(f"✅ Outbound call initiated (call ID: {call_id})")


def debug(
    skip_push: bool = typer.Option(
        False, "--skip-push", "-s",
        help="Skip pushing code (use existing deployed code)",
    ),
    environment: Optional[str] = typer.Option(
        None, "--environment", "-e",
        help="Environment name (default: 'debug')",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v",
        help="Enable verbose output",
    ),
    outbound: bool = typer.Option(
        False, "--outbound", "-o",
        help="Start an outbound call instead of a mic session",
    ),
    to_phone_number: Optional[str] = typer.Option(
        None, "--to-phone-number",
        help="Phone number to call (required with --outbound)",
    ),
    from_phone_number: Optional[str] = typer.Option(
        None, "--from-phone-number",
        help="Caller ID / originating phone number for outbound calls",
    ),
):
    """
    Push local code and start an interactive debug session.

    Examples:
        vr debug              # Push and debug
        vr debug -s           # Debug existing deployment
        vr debug -e staging   # Use staging environment
        vr debug --outbound --to-phone-number "+15551234567"  # Outbound call
    """
    project_dir = Path.cwd()
    voicerun_dir = project_dir / ".voicerun"
    environment = environment or DEBUG_ENV_NAME

    if outbound and not to_phone_number:
        print("❌ --to-phone-number is required when using --outbound")
        raise typer.Exit(1)

    if not voicerun_dir.exists():
        print("❌ Not a voicerun project (.voicerun directory not found)")
        print("   Run 'vr init' to create a new project")
        raise typer.Exit(1)

    agent_id: Optional[str] = None
    function_id: Optional[str] = None

    if skip_push:
        # Load from lock file
        agent_lock = load_agent_lock(voicerun_dir)
        if not agent_lock or not agent_lock.get("id"):
            print("❌ No agent.lock found. Run 'vr push' first")
            raise typer.Exit(1)

        agent_id = agent_lock.get("id")
        function_id = agent_lock.get("functionId")
        print("📦 Using existing deployment")
    else:
        # Push first
        print("📤 Pushing code...")
        result = push_code(project_dir=project_dir, silent=True)

        if not result.success:
            print(f"❌ {result.error or 'Push failed'}")
            raise typer.Exit(1)

        agent_id = result.agent_id
        function_id = result.function_id

        if function_id:
            print(f"✅ Pushed {function_id[:8]}...")
        else:
            print("⚠️  Pushed (no function ID)")

    if outbound:
        _start_outbound_call(agent_id, to_phone_number, from_phone_number, environment)
        return

    try:
        asyncio.run(run_debug_session(
            agent_id=agent_id,
            function_id=function_id,
            environment=environment,
            verbose=verbose,
        ))
    except Exception as e:
        print(f"❌ Session failed: {e}")
        raise typer.Exit(1)
