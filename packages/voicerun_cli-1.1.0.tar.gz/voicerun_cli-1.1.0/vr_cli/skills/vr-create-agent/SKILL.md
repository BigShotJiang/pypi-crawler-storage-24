---
name: vr-create-agent
description: Create a new VoiceRun voice agent project
---

# Create a VoiceRun Voice Agent

You are helping the user create a new VoiceRun voice agent project. Follow these steps:

## Step 1: Scaffold the project

Run `vr init <name>` to create the project. Ask the user for a project name if they haven't provided one. Use `--yes` to skip interactive prompts if the user wants defaults.

```bash
vr init <name>
```

This creates the following structure:

```
<name>/
├── handler.py              # Main agent code (entry point)
├── README.md               # Project documentation
├── requirements.txt        # Python dependencies (primfunctions)
├── .gitignore              # Git ignore rules
└── .voicerun/              # VoiceRun configuration
    ├── agent.yaml          # Agent metadata (name, description, dependencies)
    ├── values.yaml         # Environment settings (STT model, environment)
    └── templates/
        └── deployment.yaml # Runtime deployment config (STT, VAD, sessions)
```

## Step 2: Customize the handler

Open `handler.py` and help the user customize the `handler(event, context)` function. This is the entry point for the voice agent. It receives events and yields responses:

- **StartEvent**: Fires when a conversation begins. Yield a `TextToSpeechEvent` to greet the user.
- **TextEvent**: Fires when the user speaks (transcribed text). Process the input and yield `TextToSpeechEvent` responses.
- **StopEvent**: Fires when the conversation ends. Yield a farewell message.

Help the user implement their agent's logic in the `TextEvent` handler. Common patterns:
- Call external APIs or LLMs to generate responses — for anything related to completions, LLMs, or model configuration, refer to the [VoiceRun Completions API Reference](https://docs.voicerun.com/voicerun-completions/api-reference/)
- Maintain conversation state via the `context` object
- Add dependencies to `requirements.txt` as needed

## Step 3: Configure the agent

Help the user edit `.voicerun/agent.yaml` to set:
- `name`: Agent identifier
- `description`: What the agent does
- `dependencies`: Optional references to shared agent packages

Help the user edit `.voicerun/values.yaml` to configure:
- `environment`: development, staging, or production
- `sttModel`: Speech-to-text model (default: `deepgram-flux`)

## Step 4: Write tests

**This step is critical.** Before pushing or deploying, write tests to verify the agent behaves correctly. Tests use Python's `pytest` framework and run via the `vr test` command.

### Create a tests directory and test file

Create a `tests/` directory in the project root with a `test_handler.py` file. Tests should import the handler and simulate events to verify responses.

```python
import pytest
from handler import handler
from primfunctions.events import (
    StartEvent,
    TextEvent,
    StopEvent,
    TextToSpeechEvent,
)
from primfunctions.context import Context


@pytest.fixture
def context():
    """Create a mock context for testing."""
    return Context()


async def collect_responses(handler_gen):
    """Helper to collect all yielded responses from the handler."""
    responses = []
    async for response in handler_gen:
        responses.append(response)
    return responses


@pytest.mark.asyncio
async def test_start_event_greeting(context):
    """Test that the agent greets the user on session start."""
    event = StartEvent()
    responses = await collect_responses(handler(event, context))
    assert len(responses) > 0
    assert isinstance(responses[0], TextToSpeechEvent)
    assert responses[0].text  # Verify greeting is not empty


@pytest.mark.asyncio
async def test_text_event_response(context):
    """Test that the agent responds to user input."""
    event = TextEvent(data={"text": "Hello there"})
    responses = await collect_responses(handler(event, context))
    assert len(responses) > 0
    assert isinstance(responses[0], TextToSpeechEvent)


@pytest.mark.asyncio
async def test_stop_event_farewell(context):
    """Test that the agent says goodbye on session end."""
    event = StopEvent()
    responses = await collect_responses(handler(event, context))
    assert len(responses) > 0
    assert isinstance(responses[0], TextToSpeechEvent)
```

### Test patterns to cover

Write tests that verify the agent's **core behavior**, not just that it responds:

1. **Happy path**: Simulate a full conversation flow (Start → Text interactions → Stop) and assert the agent produces the expected responses.
2. **Edge cases**: Test empty input, unexpected input, and boundary conditions relevant to the agent's logic.
3. **Business logic**: If the agent calls APIs, uses LLMs, or has branching logic, test each path. Mock external dependencies as needed.
4. **Conversation state**: If the agent maintains state via the `context` object, test that state transitions work correctly across multiple events.

### Run tests with `vr test`

```bash
vr test              # Run all tests
vr test -v           # Verbose output
vr test -c           # With coverage reporting
vr test -e development  # With environment secrets loaded
vr test tests/test_handler.py  # Run a specific test file
```

### Iterate until tests pass

Run `vr test` after every change to the handler. The testing loop should be:

1. Write or update `handler.py` with agent logic
2. Write or update tests in `tests/test_handler.py` to cover the new behavior
3. Run `vr test -v` and review results
4. Fix failures and repeat until all tests pass

**Do not consider the agent complete until all tests pass.** Testing ensures the agent correctly handles the user's requirements before deployment.

## Step 5: Next steps

Once the agent is ready and **all tests pass**, suggest these commands:
- `vr push` - Push the agent to VoiceRun
- `vr deploy <environment> -f .voicerun/values.yaml` - Deploy the agent to an environment (values file is required)
- `vr debug` - Push local code and start an interactive debug session
- `vr test` - Run tests for the voice agent project

Refer the user to the [VoiceRun documentation](https://docs.voicerun.com) for detailed guides, API references, and examples.

Ask the user what they'd like to customize first and guide them through the implementation.
