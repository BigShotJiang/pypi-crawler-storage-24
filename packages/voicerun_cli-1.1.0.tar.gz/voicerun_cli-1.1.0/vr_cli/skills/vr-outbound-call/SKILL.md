---
name: vr-outbound-call
description: Make an outbound phone call with a deployed VoiceRun agent
---

# Make an Outbound Call with a VoiceRun Agent

You are helping the user make an outbound phone call using their deployed VoiceRun voice agent. Follow these steps:

## Step 1: Verify prerequisites

The project must be a VoiceRun project. Check that:

1. The project has a `.voicerun/` directory (it's a VoiceRun project)
2. The agent's `handler.py` is ready and working

Note: `vr debug --outbound` **automatically pushes** your local code before starting the call, so a separate `vr push` is not required. If you use `--skip-push`, the agent must have been pushed previously (`agent.lock` must exist).

If targeting a non-debug environment (e.g., production), that environment must be deployed first:

```bash
vr deploy <environment> -f .voicerun/values.<environment>.yaml
```

## Step 2: Make the outbound call

Ask the user for the destination phone number. Phone numbers must be in **E.164 format** (e.g. `+15551234567` — a `+` followed by country code and number, no spaces or dashes).

Run the outbound call command:

```bash
vr debug --outbound --to-phone-number "+15551234567"
```

This pushes the latest local code and initiates a phone call from the agent to the specified number. On success, a `telephonyCallId` is returned for tracking.

## Step 3: Options

The following optional flags are available:

- **`--from-phone-number "+15559876543"`** — Set the caller ID / originating phone number for the outbound call.
- **`--skip-push` / `-s`** — Skip pushing code and use the existing deployed version. Useful when code hasn't changed.
- **`--environment <name>` / `-e <name>`** — Target a specific environment (defaults to `debug`).

Example with all options:

```bash
vr debug --outbound --to-phone-number "+15551234567" --from-phone-number "+15559876543" --skip-push --environment production
```

## Step 4: Troubleshooting

If the call fails, check for these common issues:

- **"Not a voicerun project"** — Run the command from a directory containing a `.voicerun/` folder, or run `vr init` to create a new project.
- **"No agent.lock found"** — Run `vr push` before using `--skip-push`.
- **"Failed to start outbound call"** — Verify the agent is deployed (`vr deploy`) and the phone number is in E.164 format (e.g. `+15551234567`).
- **Push failed** — Check for syntax errors in your agent code or network connectivity issues.

Ask the user for the phone number they'd like to call and guide them through the process.
