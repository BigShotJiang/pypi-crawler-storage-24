from .base import BaseEntity, BaseRepository


class AgentTemplate(BaseEntity):
    def __init__(
        self,
        id: str = None,
        name: str = None,
        description: str = None,
        category: str = None,
        is_public: bool = False,
        variables: list = None,
        files: dict = None,
        organization_id: str = None,
        created_by: str = None,
        created_at: str = None,
        updated_at: str = None,
        deleted_at: str = None,
        **kwargs,
    ):
        super().__init__(id=id, created_at=created_at, updated_at=updated_at, deleted_at=deleted_at, **kwargs)
        self.name = name
        self.description = description
        self.category = category
        self.is_public = is_public
        self.variables = variables
        self.files = files
        self.organization_id = organization_id
        self.created_by = created_by


class AgentTemplateRepository(BaseRepository):
    def __init__(self):
        super().__init__(
            name="agent_template",
            endpoint="/v1/agent-templates",
            entity_class=AgentTemplate,
        )
