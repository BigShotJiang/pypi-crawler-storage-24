from .base import BaseEntity, BaseRepository
from ..utils.utils import make_request

PROVIDER_TYPES = ["twilio", "telnyx"]

PROVIDER_CREDENTIAL_FIELDS = {
    "twilio": [
        ("account_sid", "Account SID"),
        ("api_key_sid", "API Key SID"),
        ("api_key_secret", "API Key Secret"),
    ],
    "telnyx": [
        ("api_key", "API Key"),
    ],
}


class OrganizationTelephony(BaseEntity):
    def __init__(
        self,
        id: str = None,
        organization_id: str = None,
        name: str = None,
        provider_type: str = None,
        created_at: str = None,
        updated_at: str = None,
        deleted_at: str = None,
        **kwargs,
    ):
        self.id = id
        self.organization_id = organization_id
        self.name = name
        self.provider_type = provider_type
        self.created_at = created_at
        self.updated_at = updated_at
        self.deleted_at = deleted_at or None


class OrganizationTelephonyRepository(BaseRepository[OrganizationTelephony]):
    def __init__(self, organization_id: str):
        super().__init__(
            "organization_telephony",
            f"/v1/organizations/{organization_id}/telephony",
            OrganizationTelephony,
        )

    def create_with_credentials(self, name: str, provider_type: str, credentials: dict) -> OrganizationTelephony:
        body = {
            "name": name,
            "providerType": provider_type,
            "credentials": credentials,
        }
        response = make_request(self.endpoint, "POST", json=body)

        if response and "data" in response:
            return self._create_entity(response["data"])

        return None
