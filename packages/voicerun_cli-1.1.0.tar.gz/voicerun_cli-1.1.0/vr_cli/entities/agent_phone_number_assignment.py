from .base import BaseEntity, BaseRepository
from ..utils.utils import make_request


class AgentPhoneNumberAssignment(BaseEntity):
    def __init__(
        self,
        id: str = None,
        agent_id: str = None,
        agent_environment_id: str = None,
        organization_phone_number_id: str = None,
        created_at: str = None,
        updated_at: str = None,
        deleted_at: str = None,
        **kwargs,
    ):
        self.id = id
        self.agent_id = agent_id
        self.agent_environment_id = agent_environment_id
        self.organization_phone_number_id = organization_phone_number_id
        self.created_at = created_at
        self.updated_at = updated_at
        self.deleted_at = deleted_at or None


class AgentPhoneNumberAssignmentRepository(BaseRepository[AgentPhoneNumberAssignment]):
    def __init__(self, agent_id: str):
        super().__init__(
            "agent_phone_number_assignment",
            f"/v1/agents/{agent_id}/phoneNumberAssignments",
            AgentPhoneNumberAssignment,
        )

    def configure(self, id: str) -> AgentPhoneNumberAssignment:
        response = make_request(f"{self.endpoint}/{id}/configure", "POST")

        if response and "data" in response:
            return self._create_entity(response["data"])

        return None
