"""Tests for vr debug command."""

import asyncio
import base64
import json
import pytest
from io import StringIO
from pathlib import Path
from unittest.mock import patch, Mock, AsyncMock, MagicMock

from typer.testing import CliRunner

from vr_cli.cli import app
from vr_cli.commands.debug import (
    DebugMessage,
    DebugRenderer,
    WebSocketDebugClient,
    Theme,
    _start_outbound_call,
)


runner = CliRunner()


# ============================================================================
# DebugMessage Tests
# ============================================================================


class TestDebugMessage:
    """Tests for DebugMessage dataclass."""

    def test_create_debug_message(self):
        """Should create a debug message with all fields."""
        msg = DebugMessage(
            type="event",
            turn=1,
            name="text",
            data={"text": "Hello"}
        )
        assert msg.type == "event"
        assert msg.turn == 1
        assert msg.name == "text"
        assert msg.data == {"text": "Hello"}

    def test_debug_message_empty_data(self):
        """Should handle empty data dict."""
        msg = DebugMessage(type="debug", turn=0, name="start", data={})
        assert msg.data == {}

    def test_debug_message_complex_data(self):
        """Should handle complex nested data."""
        data = {
            "nested": {"key": "value"},
            "list": [1, 2, 3],
            "text": "sample"
        }
        msg = DebugMessage(type="debug", turn=2, name="context", data=data)
        assert msg.data["nested"]["key"] == "value"
        assert msg.data["list"] == [1, 2, 3]


# ============================================================================
# Theme Tests
# ============================================================================


class TestTheme:
    """Tests for Theme class."""

    def test_theme_colors_disabled(self):
        """Theme colors should be empty strings for compatibility."""
        assert Theme.USER == ""
        assert Theme.AGENT == ""
        assert Theme.SYSTEM == ""
        assert Theme.ERROR == ""
        assert Theme.WARNING == ""
        assert Theme.SUCCESS == ""
        assert Theme.ACCENT == ""
        assert Theme.DIVIDER == ""


# ============================================================================
# DebugRenderer Tests
# ============================================================================


class TestDebugRenderer:
    """Tests for DebugRenderer class."""

    def test_init_default_verbose(self):
        """Should initialize with verbose=False by default."""
        renderer = DebugRenderer()
        assert renderer.verbose is False
        assert renderer.current_turn == 0

    def test_init_verbose_mode(self):
        """Should initialize with verbose=True when specified."""
        renderer = DebugRenderer(verbose=True)
        assert renderer.verbose is True

    def test_format_event_name(self):
        """Should format event names correctly."""
        renderer = DebugRenderer()
        assert renderer._format_event_name("text_to_speech") == "Text To Speech"
        assert renderer._format_event_name("transfer_call") == "Transfer Call"
        assert renderer._format_event_name("start") == "Start"

    def test_get_icon_known_events(self):
        """Should return correct icons for known events."""
        renderer = DebugRenderer()
        assert renderer._get_icon("start") == "▶️ "
        assert renderer._get_icon("stop") == "⏹️ "
        assert renderer._get_icon("error") == "❌"
        assert renderer._get_icon("text_to_speech") == "🔊"
        assert renderer._get_icon("transcript") == "🎤"

    def test_get_icon_unknown_event(self):
        """Should return default icon for unknown events."""
        renderer = DebugRenderer()
        assert renderer._get_icon("unknown_event") == "→ "

    def test_render_updates_current_turn(self, capsys):
        """Should update current turn when turn changes."""
        renderer = DebugRenderer()
        assert renderer.current_turn == 0

        msg = DebugMessage(type="debug", turn=1, name="start", data={})
        renderer.render(msg)

        assert renderer.current_turn == 1

    def test_render_skips_transcript_events(self, capsys):
        """Should skip transcript events."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="transcript", data={"text": "test"})
        renderer.render(msg)

        captured = capsys.readouterr()
        # Should only have turn header, not transcript content
        assert "Transcript" not in captured.out

    def test_render_text_event(self, capsys):
        """Should render text events correctly."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="text", data={"text": "Hello world", "source": "keyboard"})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Hello world" in captured.out
        assert "Text" in captured.out

    def test_render_text_from_speech(self, capsys):
        """Should render text from speech with correct icon."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="text", data={"text": "Hello", "source": "speech"})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Hello" in captured.out
        assert "via speech" in captured.out

    def test_render_text_to_speech(self, capsys):
        """Should render text-to-speech events."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="text_to_speech", data={"text": "Agent response"})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Agent response" in captured.out
        assert "Text To Speech" in captured.out

    def test_render_error(self, capsys):
        """Should render error events."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="error", data={"message": "Something went wrong"})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Something went wrong" in captured.out
        assert "Error" in captured.out

    def test_render_error_with_error_key(self, capsys):
        """Should render error events with 'error' key in data."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="error", data={"error": "Error message"})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Error message" in captured.out

    def test_render_log(self, capsys):
        """Should render log events."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="log", data={"message": "Debug log message"})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Debug log message" in captured.out
        assert "Log" in captured.out

    def test_render_log_empty_message(self, capsys):
        """Should handle empty log messages."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="log", data={"message": ""})
        renderer.render(msg)

        captured = capsys.readouterr()
        # Empty message should not produce Log output
        assert "Log" not in captured.out or captured.out.count("Log") == 0

    def test_render_turn_end(self, capsys):
        """Should render turn end with duration."""
        renderer = DebugRenderer()
        renderer.current_turn = 1  # Set current turn first
        msg = DebugMessage(type="debug", turn=1, name="turn_end", data={"duration": 1500})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "1500ms" in captured.out

    def test_render_transfer_call(self, capsys):
        """Should render transfer call events."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="transfer_call", data={"to": "+1234567890"})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Transfer Call" in captured.out
        assert "+1234567890" in captured.out

    def test_render_context_verbose(self, capsys):
        """Should render context events in verbose mode."""
        renderer = DebugRenderer(verbose=True)
        msg = DebugMessage(type="debug", turn=1, name="context", data={"key1": "val1", "key2": "val2"})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Context" in captured.out
        assert "key1" in captured.out

    def test_render_context_non_verbose(self, capsys):
        """Should not render context events in non-verbose mode."""
        renderer = DebugRenderer(verbose=False)
        msg = DebugMessage(type="debug", turn=1, name="context", data={"key1": "val1"})
        renderer.render(msg)

        captured = capsys.readouterr()
        # Context should not appear in non-verbose mode
        assert "Context" not in captured.out

    def test_render_start(self, capsys):
        """Should render start events."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="start", data={})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Start" in captured.out

    def test_render_interrupt(self, capsys):
        """Should render interrupt events."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="interrupt", data={})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Interrupt" in captured.out

    def test_render_timeout(self, capsys):
        """Should render timeout events."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="timeout", data={})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Timeout" in captured.out

    def test_render_silence(self, capsys):
        """Should render silence events."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="silence", data={})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Silence" in captured.out

    def test_render_end(self, capsys):
        """Should render end events."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="end", data={})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "End" in captured.out

    def test_render_stop(self, capsys):
        """Should render stop events."""
        renderer = DebugRenderer()
        msg = DebugMessage(type="debug", turn=1, name="stop", data={})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Stop" in captured.out

    def test_render_generic_verbose(self, capsys):
        """Should render unknown events in verbose mode."""
        renderer = DebugRenderer(verbose=True)
        msg = DebugMessage(type="debug", turn=1, name="custom_event", data={"foo": "bar"})
        renderer.render(msg)

        captured = capsys.readouterr()
        assert "Custom Event" in captured.out

    def test_render_generic_non_verbose(self, capsys):
        """Should not render unknown events in non-verbose mode."""
        renderer = DebugRenderer(verbose=False)
        msg = DebugMessage(type="debug", turn=1, name="custom_event", data={"foo": "bar"})
        renderer.render(msg)

        captured = capsys.readouterr()
        # Custom event should not appear (only turn header if any)
        assert "Custom Event" not in captured.out

    def test_status(self, capsys):
        """Should print status messages."""
        renderer = DebugRenderer()
        renderer.status("connected")

        captured = capsys.readouterr()
        assert "● connected" in captured.out

    def test_render_turn_header(self, capsys):
        """Should render turn header correctly."""
        renderer = DebugRenderer()
        renderer._render_turn_header(5)

        captured = capsys.readouterr()
        assert "Turn 5" in captured.out


# ============================================================================
# WebSocketDebugClient Tests
# ============================================================================


class TestWebSocketDebugClient:
    """Tests for WebSocketDebugClient class."""

    def test_init_default_values(self):
        """Should initialize with default values."""
        client = WebSocketDebugClient(agent_id="test-agent")

        assert client.agent_id == "test-agent"
        assert client.function_id is None
        assert client.environment == ""
        assert client.verbose is False
        assert client.is_connected is False
        assert client.is_listening is False
        assert client.is_playing is False

    def test_init_with_all_params(self):
        """Should initialize with all parameters."""
        client = WebSocketDebugClient(
            agent_id="test-agent",
            function_id="func-123",
            environment="staging",
            verbose=True,
        )

        assert client.agent_id == "test-agent"
        assert client.function_id == "func-123"
        assert client.environment == "staging"
        assert client.verbose is True

    def test_log_verbose_mode(self, capsys):
        """Should log messages in verbose mode."""
        client = WebSocketDebugClient(agent_id="test", verbose=True)
        client._log("test message")

        captured = capsys.readouterr()
        assert "→ test message" in captured.out

    def test_log_non_verbose_mode(self, capsys):
        """Should not log messages in non-verbose mode."""
        client = WebSocketDebugClient(agent_id="test", verbose=False)
        client._log("test message")

        captured = capsys.readouterr()
        assert "test message" not in captured.out

    def test_callbacks_initially_none(self):
        """Should have no callbacks initially."""
        client = WebSocketDebugClient(agent_id="test")
        assert client.on_connect is None
        assert client.on_disconnect is None
        assert client.on_debug_message is None

    def test_redirect_state_initial(self):
        """Should have correct initial redirect state."""
        client = WebSocketDebugClient(agent_id="test-agent", environment="dev")
        assert client._initial_agent_id == "test-agent"
        assert client._initial_environment == "dev"
        assert client._redirected is False
        assert client._last_redirect_key is None

    def test_get_agent_config(self):
        """Should fetch agent configuration from API."""
        client = WebSocketDebugClient(agent_id="test-agent", environment="dev")

        async def run_test():
            with patch("vr_cli.commands.debug.make_request") as mock_request:
                mock_request.return_value = {
                    "data": {
                        "url": "wss://example.com/ws",
                        "parameters": {"key": "value"}
                    }
                }

                config = await client._get_agent_config()

            assert config["url"] == "wss://example.com/ws"
            assert config["parameters"] == {"key": "value"}
            mock_request.assert_called_once()

        asyncio.run(run_test())

    def test_get_agent_config_with_function_id(self):
        """Should include function ID in environment parameter."""
        client = WebSocketDebugClient(
            agent_id="test-agent",
            function_id="func-123",
            environment="dev"
        )

        async def run_test():
            with patch("vr_cli.commands.debug.make_request") as mock_request:
                mock_request.return_value = {"data": {"url": "wss://example.com"}}

                await client._get_agent_config()

            call_args = mock_request.call_args
            endpoint = call_args[0][0]
            assert "environment=dev%7Cfunc-123" in endpoint  # URL encoded dev|func-123

        asyncio.run(run_test())

    def test_get_agent_config_failure(self):
        """Should raise exception on API failure."""
        client = WebSocketDebugClient(agent_id="test-agent")

        async def run_test():
            with patch("vr_cli.commands.debug.make_request") as mock_request:
                mock_request.return_value = None

                with pytest.raises(Exception, match="Failed to get agent configuration"):
                    await client._get_agent_config()

        asyncio.run(run_test())

    def test_connect_sets_state(self):
        """Should set connection state on connect."""
        client = WebSocketDebugClient(agent_id="test-agent", environment="dev")

        async def run_test():
            mock_ws = AsyncMock()
            with patch("vr_cli.commands.debug.make_request") as mock_request, \
                 patch("vr_cli.commands.debug.websockets.connect", new_callable=AsyncMock) as mock_connect:
                mock_request.return_value = {"data": {"url": "wss://example.com"}}
                mock_connect.return_value = mock_ws

                await client.connect()

            assert client.is_connected is True
            assert client.websocket == mock_ws
            assert client.call_sid  # Should be set
            assert client.stream_sid  # Should be set

        asyncio.run(run_test())

    def test_connect_calls_on_connect_callback(self):
        """Should call on_connect callback when connected."""
        client = WebSocketDebugClient(agent_id="test-agent")
        callback = Mock()
        client.on_connect = callback

        async def run_test():
            with patch("vr_cli.commands.debug.make_request") as mock_request, \
                 patch("vr_cli.commands.debug.websockets.connect", new_callable=AsyncMock) as mock_connect:
                mock_request.return_value = {"data": {"url": "wss://example.com"}}
                mock_connect.return_value = AsyncMock()

                await client.connect()

            callback.assert_called_once()

        asyncio.run(run_test())

    def test_connect_no_server_url(self):
        """Should raise exception when no server URL available."""
        client = WebSocketDebugClient(agent_id="test-agent")

        async def run_test():
            with patch("vr_cli.commands.debug.make_request") as mock_request:
                mock_request.return_value = {"data": {"url": None}}

                with pytest.raises(Exception, match="No server URL available"):
                    await client.connect()

        asyncio.run(run_test())

    def test_disconnect_cleans_up(self):
        """Should clean up resources on disconnect."""
        client = WebSocketDebugClient(agent_id="test-agent")
        client.is_connected = True
        mock_ws = AsyncMock()
        client.websocket = mock_ws

        callback = Mock()
        client.on_disconnect = callback

        async def run_test():
            await client.disconnect()

        asyncio.run(run_test())

        assert client.is_connected is False
        assert client.websocket is None
        mock_ws.close.assert_called_once()
        callback.assert_called_once()

    def test_disconnect_restores_agent_after_redirect(self):
        """Should restore initial agent after redirect on disconnect."""
        client = WebSocketDebugClient(agent_id="original-agent", environment="original-env")
        client._redirected = True
        client.agent_id = "redirected-agent"
        client.environment = "redirected-env"
        client.is_connected = True

        async def run_test():
            await client.disconnect()

        asyncio.run(run_test())

        assert client.agent_id == "original-agent"
        assert client.environment == "original-env"
        assert client._redirected is False

    def test_send_text(self):
        """Should send text message through websocket."""
        client = WebSocketDebugClient(agent_id="test-agent")
        mock_ws = AsyncMock()
        client.websocket = mock_ws
        client.is_connected = True

        async def run_test():
            await client.send_text("Hello agent")

        asyncio.run(run_test())

        mock_ws.send.assert_called_once()
        sent_data = json.loads(mock_ws.send.call_args[0][0])
        assert sent_data["event"] == "text"
        assert sent_data["text"] == "Hello agent"

    def test_send_text_not_connected(self):
        """Should not send text when not connected."""
        client = WebSocketDebugClient(agent_id="test-agent")
        client.is_connected = False

        async def run_test():
            await client.send_text("Hello")
            # Should not raise, just return early

        asyncio.run(run_test())

    def test_handle_debug_message(self):
        """Should handle debug messages and call callback."""
        client = WebSocketDebugClient(agent_id="test-agent")
        callback = Mock()
        client.on_debug_message = callback

        async def run_test():
            await client._handle_debug({
                "type": "event",
                "turn": 1,
                "name": "text",
                "data": {"text": "test"}
            })

        asyncio.run(run_test())

        callback.assert_called_once()
        msg = callback.call_args[0][0]
        assert isinstance(msg, DebugMessage)
        assert msg.name == "text"

    def test_handle_clear_stops_playback(self):
        """Should stop playback on clear message."""
        client = WebSocketDebugClient(agent_id="test-agent")
        mock_audio_output = Mock()
        client.audio_output = mock_audio_output
        client.is_playing = True

        async def run_test():
            await client._handle_clear({})

        asyncio.run(run_test())

        mock_audio_output.stop_playback.assert_called_once()
        assert client.is_playing is False

    def test_handle_audio_plays_audio(self):
        """Should play received audio."""
        client = WebSocketDebugClient(agent_id="test-agent")
        mock_audio_output = Mock()
        mock_audio_input = Mock()
        client.audio_output = mock_audio_output
        client.audio_input = mock_audio_input
        client.is_playing = False

        async def run_test():
            audio_payload = base64.b64encode(b"audio data").decode()
            await client._handle_audio({"media": {"payload": audio_payload}})

        asyncio.run(run_test())

        mock_audio_output.play_pcm_bytes.assert_called_once()
        assert client.is_playing is True

    def test_handle_control_redirect(self):
        """Should handle redirect control messages."""
        client = WebSocketDebugClient(agent_id="original-agent", environment="dev")
        client.is_connected = True
        client.websocket = AsyncMock()

        async def run_test():
            with patch("vr_cli.commands.debug.make_request") as mock_request, \
                 patch("vr_cli.commands.debug.websockets.connect", new_callable=AsyncMock) as mock_connect:
                mock_request.return_value = {"data": {"url": "wss://new.example.com"}}
                mock_connect.return_value = AsyncMock()

                await client._handle_control({
                    "name": "redirect",
                    "data": {"agentId": "new-agent", "environment": "staging"}
                })

        asyncio.run(run_test())

        assert client.agent_id == "new-agent"
        assert client.environment == "staging"
        assert client._redirected is True

    def test_handle_control_redirect_same_agent(self):
        """Should not redirect to same agent."""
        client = WebSocketDebugClient(agent_id="test-agent", environment="dev")
        client.is_connected = True

        async def run_test():
            await client._handle_control({
                "name": "redirect",
                "data": {"agentId": "test-agent", "environment": "dev"}
            })

        asyncio.run(run_test())

        # Should not have redirected
        assert client._redirected is False

    def test_handle_control_non_redirect(self):
        """Should ignore non-redirect control messages."""
        client = WebSocketDebugClient(agent_id="test-agent")

        async def run_test():
            # Should not raise
            await client._handle_control({"name": "other_control", "data": {}})

        asyncio.run(run_test())


# ============================================================================
# Debug Command Tests
# ============================================================================


class TestDebugCommand:
    """Tests for the debug CLI command."""

    def test_debug_not_voicerun_project(self, temp_dir, monkeypatch):
        """Should fail when not in a voicerun project."""
        monkeypatch.chdir(temp_dir)

        result = runner.invoke(app, ["debug"])

        assert result.exit_code != 0
        assert "Not a voicerun project" in result.output

    def test_debug_skip_push_no_lock_file(self, temp_dir, monkeypatch):
        """Should fail when skip-push used but no agent.lock exists."""
        monkeypatch.chdir(temp_dir)
        voicerun_dir = temp_dir / ".voicerun"
        voicerun_dir.mkdir()

        result = runner.invoke(app, ["debug", "--skip-push"])

        assert result.exit_code != 0
        assert "No agent.lock found" in result.output

    def test_debug_skip_push_with_lock_file(self, voicerun_project_with_lock, monkeypatch):
        """Should use existing deployment when skip-push is used."""
        monkeypatch.chdir(voicerun_project_with_lock)

        with patch("vr_cli.commands.debug.asyncio.run") as mock_run:
            result = runner.invoke(app, ["debug", "--skip-push"])

        assert "Using existing deployment" in result.output
        mock_run.assert_called_once()

    def test_debug_push_failure(self, voicerun_project, monkeypatch):
        """Should fail when push fails."""
        monkeypatch.chdir(voicerun_project)

        with patch("vr_cli.commands.debug.push_code") as mock_push:
            mock_push.return_value = Mock(success=False, error="Push failed")

            result = runner.invoke(app, ["debug"])

        assert result.exit_code != 0
        assert "Push failed" in result.output

    def test_debug_push_success(self, voicerun_project, monkeypatch):
        """Should push and start debug session."""
        monkeypatch.chdir(voicerun_project)

        with patch("vr_cli.commands.debug.push_code") as mock_push, \
             patch("vr_cli.commands.debug.asyncio.run") as mock_run:
            mock_push.return_value = Mock(
                success=True,
                agent_id="test-agent",
                function_id="func-123"
            )

            result = runner.invoke(app, ["debug"])

        assert "Pushing code" in result.output
        assert "Pushed func-123" in result.output
        mock_run.assert_called_once()

    def test_debug_push_no_function_id(self, voicerun_project, monkeypatch):
        """Should warn when no function ID returned."""
        monkeypatch.chdir(voicerun_project)

        with patch("vr_cli.commands.debug.push_code") as mock_push, \
             patch("vr_cli.commands.debug.asyncio.run") as mock_run:
            mock_push.return_value = Mock(
                success=True,
                agent_id="test-agent",
                function_id=None
            )

            result = runner.invoke(app, ["debug"])

        assert "no function ID" in result.output

    def test_debug_with_environment(self, voicerun_project_with_lock, monkeypatch):
        """Should use specified environment."""
        monkeypatch.chdir(voicerun_project_with_lock)

        with patch("vr_cli.commands.debug.asyncio.run") as mock_run:
            result = runner.invoke(app, ["debug", "--skip-push", "-e", "staging"])

        mock_run.assert_called_once()
        call_args = mock_run.call_args[0][0]
        # The coroutine should have been created with environment='staging'

    def test_debug_session_exception(self, voicerun_project_with_lock, monkeypatch):
        """Should handle session exceptions gracefully."""
        monkeypatch.chdir(voicerun_project_with_lock)

        with patch("vr_cli.commands.debug.asyncio.run") as mock_run:
            mock_run.side_effect = Exception("Connection failed")

            result = runner.invoke(app, ["debug", "--skip-push"])

        assert result.exit_code != 0
        assert "Session failed" in result.output


# ============================================================================
# Outbound Debug Tests
# ============================================================================


class TestOutboundDebug:
    """Tests for --outbound flag on the debug command."""

    def test_outbound_without_to_phone_number(self, temp_dir, monkeypatch):
        """Should error when --outbound is used without --to-phone-number."""
        monkeypatch.chdir(temp_dir)

        result = runner.invoke(app, ["debug", "--outbound"])

        assert result.exit_code != 0
        assert "--to-phone-number is required" in result.output

    def test_outbound_calls_session_start_api(self, voicerun_project_with_lock, monkeypatch):
        """Should call session start API when --outbound is used."""
        monkeypatch.chdir(voicerun_project_with_lock)

        with patch("vr_cli.commands.debug.make_request") as mock_request:
            mock_request.return_value = {
                "data": {"telephonyCallId": "call-abc-123"}
            }

            result = runner.invoke(app, [
                "debug", "--skip-push", "--outbound",
                "--to-phone-number", "+15551234567",
            ])

        assert result.exit_code == 0
        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert "/sessions/start" in call_args[0][0]
        assert call_args[1]["method"] == "POST"
        body = call_args[1]["json"]
        assert body["inputType"] == "phone"
        assert body["inputParameters"]["toPhoneNumber"] == "+15551234567"
        assert "fromPhoneNumber" not in body["inputParameters"]

    def test_outbound_with_from_phone_number(self, voicerun_project_with_lock, monkeypatch):
        """Should include fromPhoneNumber when --from-phone-number is provided."""
        monkeypatch.chdir(voicerun_project_with_lock)

        with patch("vr_cli.commands.debug.make_request") as mock_request:
            mock_request.return_value = {
                "data": {"telephonyCallId": "call-abc-123"}
            }

            result = runner.invoke(app, [
                "debug", "--skip-push", "--outbound",
                "--to-phone-number", "+15551234567",
                "--from-phone-number", "+15559876543",
            ])

        assert result.exit_code == 0
        body = mock_request.call_args[1]["json"]
        assert body["inputParameters"]["toPhoneNumber"] == "+15551234567"
        assert body["inputParameters"]["fromPhoneNumber"] == "+15559876543"

    def test_outbound_success_prints_call_id(self, voicerun_project_with_lock, monkeypatch):
        """Should print telephony call ID on success."""
        monkeypatch.chdir(voicerun_project_with_lock)

        with patch("vr_cli.commands.debug.make_request") as mock_request:
            mock_request.return_value = {
                "data": {"telephonyCallId": "call-xyz-789"}
            }

            result = runner.invoke(app, [
                "debug", "--skip-push", "--outbound",
                "--to-phone-number", "+15551234567",
            ])

        assert result.exit_code == 0
        assert "call-xyz-789" in result.output
        assert "Outbound call initiated" in result.output

    def test_outbound_failure_prints_error(self, voicerun_project_with_lock, monkeypatch):
        """Should print error and exit on API failure."""
        monkeypatch.chdir(voicerun_project_with_lock)

        with patch("vr_cli.commands.debug.make_request") as mock_request:
            mock_request.return_value = None

            result = runner.invoke(app, [
                "debug", "--skip-push", "--outbound",
                "--to-phone-number", "+15551234567",
            ])

        assert result.exit_code != 0
        assert "Failed to start outbound call" in result.output

    def test_outbound_does_not_start_websocket_session(self, voicerun_project_with_lock, monkeypatch):
        """Should not start a WebSocket debug session when --outbound is used."""
        monkeypatch.chdir(voicerun_project_with_lock)

        with patch("vr_cli.commands.debug.make_request") as mock_request, \
             patch("vr_cli.commands.debug.asyncio.run") as mock_run:
            mock_request.return_value = {
                "data": {"telephonyCallId": "call-123"}
            }

            result = runner.invoke(app, [
                "debug", "--skip-push", "--outbound",
                "--to-phone-number", "+15551234567",
            ])

        assert result.exit_code == 0
        mock_run.assert_not_called()

    def test_outbound_with_push(self, voicerun_project, monkeypatch):
        """Should push code then start outbound call."""
        monkeypatch.chdir(voicerun_project)

        with patch("vr_cli.commands.debug.push_code") as mock_push, \
             patch("vr_cli.commands.debug.make_request") as mock_request:
            mock_push.return_value = Mock(
                success=True,
                agent_id="test-agent",
                function_id="func-123",
            )
            mock_request.return_value = {
                "data": {"telephonyCallId": "call-456"}
            }

            result = runner.invoke(app, [
                "debug", "--outbound",
                "--to-phone-number", "+15551234567",
            ])

        assert result.exit_code == 0
        assert "Pushing code" in result.output
        assert "call-456" in result.output
