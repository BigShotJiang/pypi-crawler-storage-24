"""Tests for vr deploy command."""

import json
import pytest
from pathlib import Path
from unittest.mock import patch, Mock

from typer.testing import CliRunner

from vr_cli.cli import app
from vr_cli.commands.deploy import (
    deploy,
    deploy_to_api,
    prompt_for_environment,
    run_deploy_validation,
)


runner = CliRunner()


class TestRunDeployValidation:
    """Tests for run_deploy_validation function."""

    def test_validation_passes_for_valid_project(self, voicerun_project):
        """Should return True for valid project."""
        with patch("vr_cli.commands.deploy.console"):
            result = run_deploy_validation(voicerun_project)
        assert result is True

    def test_validation_fails_for_missing_voicerun_dir(self, temp_dir):
        """Should return False when .voicerun/ is missing."""
        (temp_dir / "handler.py").write_text("async def handler(event): pass\n")

        with patch("vr_cli.commands.deploy.console"):
            result = run_deploy_validation(temp_dir)
        assert result is False


class TestDeployToApi:
    """Tests for deploy_to_api function."""

    def test_deploy_sends_correct_payload(self):
        """Should send correct payload to API."""
        resources = [
            {
                "kind": "Deployment",
                "metadata": {"name": "test-deployment"},
                "spec": {"env": {"KEY": "value"}},
            }
        ]

        with patch("vr_cli.commands.deploy.make_request") as mock_request:
            mock_request.return_value = {"deploymentId": "deploy-123"}

            result = deploy_to_api("agent-123", "func-456", "development", resources)

        mock_request.assert_called_once_with(
            "/v1/agents/deploy",
            method="POST",
            json={
                "agentId": "agent-123",
                "functionId": "func-456",
                "environment": "development",
                "resources": resources,
            },
        )
        assert result == {"deploymentId": "deploy-123"}

    def test_deploy_returns_none_on_failure(self):
        """Should return None when API fails."""
        with patch("vr_cli.commands.deploy.make_request") as mock_request:
            mock_request.return_value = None

            result = deploy_to_api("agent-123", "func-456", "development", [])

        assert result is None


class TestDeployCommand:
    """Tests for the deploy command."""

    def test_deploy_not_voicerun_project(self, temp_dir, monkeypatch):
        """Should fail when not in a voicerun project."""
        monkeypatch.chdir(temp_dir)

        with patch("vr_cli.commands.deploy.print_error"), \
             patch("vr_cli.commands.deploy.print_info"):
            result = runner.invoke(app, ["deploy", "development"])

        assert result.exit_code != 0

    def test_deploy_no_helm(self, voicerun_project_with_lock, monkeypatch):
        """Should fail when Helm is not installed."""
        monkeypatch.chdir(voicerun_project_with_lock)

        with patch("vr_cli.commands.deploy.print_error"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm:
            mock_helm.return_value = False

            result = runner.invoke(app, ["deploy", "development"])

        assert result.exit_code != 0

    def test_deploy_no_agent_lock(self, voicerun_project, monkeypatch):
        """Should fail when agent.lock doesn't exist."""
        monkeypatch.chdir(voicerun_project)

        with patch("vr_cli.commands.deploy.print_error"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm:
            mock_helm.return_value = True

            result = runner.invoke(app, ["deploy", "development"])

        assert result.exit_code != 0

    def test_deploy_missing_values_file(self, voicerun_project_with_lock, monkeypatch):
        """Should fail when values file is not provided."""
        monkeypatch.chdir(voicerun_project_with_lock)

        with patch("vr_cli.commands.deploy.print_error"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm:
            mock_helm.return_value = True

            result = runner.invoke(app, ["deploy", "development"])

        assert result.exit_code != 0

    def test_deploy_dry_run(self, voicerun_project_with_lock, monkeypatch):
        """Should show rendered templates without deploying in dry-run mode."""
        monkeypatch.chdir(voicerun_project_with_lock)

        # Create values file needed for this test
        voicerun_dir = voicerun_project_with_lock / ".voicerun"
        values_file = voicerun_dir / "values.yaml"
        values_file.write_text("environment: development\n")

        with patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render, \
             patch("vr_cli.commands.deploy.make_request") as mock_request:

            mock_helm.return_value = True
            mock_validate.return_value = True
            mock_render.return_value = [
                {
                    "kind": "Deployment",
                    "metadata": {"name": "test-project"},
                    "spec": {"env": {"ENVIRONMENT": "development"}},
                }
            ]

            result = runner.invoke(app, ["deploy", "development", "-f", str(values_file), "--dry-run"])

        # Should not call the API in dry-run mode
        mock_request.assert_not_called()
        assert result.exit_code == 0

    def test_deploy_success(self, voicerun_project_with_lock, monkeypatch):
        """Should deploy successfully."""
        monkeypatch.chdir(voicerun_project_with_lock)

        # Create values file needed for this test
        voicerun_dir = voicerun_project_with_lock / ".voicerun"
        values_file = voicerun_dir / "values.yaml"
        values_file.write_text("environment: development\n")

        with patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.print_success"), \
             patch("vr_cli.commands.deploy.print_error"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render, \
             patch("vr_cli.commands.deploy.make_request") as mock_request:

            mock_helm.return_value = True
            mock_validate.return_value = True
            mock_render.return_value = [
                {
                    "kind": "Deployment",
                    "metadata": {"name": "test-project"},
                    "spec": {"env": {"ENVIRONMENT": "development"}},
                }
            ]
            mock_request.return_value = {"deploymentId": "deploy-123"}

            result = runner.invoke(app, ["deploy", "development", "-f", str(values_file), "--yes"])

        assert result.exit_code == 0
        mock_request.assert_called_once()

    def test_deploy_skip_confirmation(self, voicerun_project_with_lock, monkeypatch):
        """Should skip confirmation with --yes flag."""
        monkeypatch.chdir(voicerun_project_with_lock)

        # Create values file needed for this test
        voicerun_dir = voicerun_project_with_lock / ".voicerun"
        values_file = voicerun_dir / "values.yaml"
        values_file.write_text("environment: development\n")

        with patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.print_success"), \
             patch("vr_cli.commands.deploy.confirm") as mock_confirm, \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render, \
             patch("vr_cli.commands.deploy.make_request") as mock_request:

            mock_helm.return_value = True
            mock_validate.return_value = True
            mock_render.return_value = [
                {
                    "kind": "Deployment",
                    "metadata": {"name": "test-project"},
                    "spec": {"env": {"ENVIRONMENT": "development"}},
                }
            ]
            mock_request.return_value = {"deploymentId": "deploy-123"}

            result = runner.invoke(app, ["deploy", "development", "-f", str(values_file), "--yes"])

        # Confirm should not be called with --yes
        mock_confirm.assert_not_called()
        assert result.exit_code == 0

    def test_deploy_aborted_by_user(self, voicerun_project_with_lock, monkeypatch):
        """Should abort when user declines confirmation."""
        monkeypatch.chdir(voicerun_project_with_lock)

        # Create values file needed for this test
        voicerun_dir = voicerun_project_with_lock / ".voicerun"
        values_file = voicerun_dir / "values.yaml"
        values_file.write_text("environment: development\n")

        with patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.confirm") as mock_confirm, \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render, \
             patch("vr_cli.commands.deploy.make_request") as mock_request:

            mock_confirm.return_value = False
            mock_helm.return_value = True
            mock_validate.return_value = True
            mock_render.return_value = [
                {
                    "kind": "Deployment",
                    "metadata": {"name": "test-project"},
                    "spec": {},
                }
            ]

            result = runner.invoke(app, ["deploy", "development", "-f", str(values_file)])

        # Request should not be made when user aborts
        mock_request.assert_not_called()

    def test_deploy_api_failure(self, voicerun_project_with_lock, monkeypatch):
        """Should handle API failure gracefully."""
        monkeypatch.chdir(voicerun_project_with_lock)

        # Create values file needed for this test
        voicerun_dir = voicerun_project_with_lock / ".voicerun"
        values_file = voicerun_dir / "values.yaml"
        values_file.write_text("environment: development\n")

        with patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.print_error"), \
             patch("vr_cli.commands.deploy.confirm") as mock_confirm, \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render, \
             patch("vr_cli.commands.deploy.make_request") as mock_request:

            mock_confirm.return_value = True
            mock_helm.return_value = True
            mock_validate.return_value = True
            mock_render.return_value = [
                {
                    "kind": "Deployment",
                    "metadata": {"name": "test-project"},
                    "spec": {},
                }
            ]
            mock_request.return_value = None  # API failure

            result = runner.invoke(app, ["deploy", "development", "-f", str(values_file)])

        assert result.exit_code != 0


class TestDeployCommandWithCustomValues:
    """Tests for deploy command with custom values file."""

    def test_deploy_with_custom_values_file(self, voicerun_project_with_lock, monkeypatch, temp_dir):
        """Should use custom values file when provided."""
        monkeypatch.chdir(voicerun_project_with_lock)

        # Create custom values file
        custom_values = temp_dir / "custom-values.yaml"
        custom_values.write_text("environment: custom\n")

        with patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.print_success"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render, \
             patch("vr_cli.commands.deploy.make_request") as mock_request:

            mock_helm.return_value = True
            mock_validate.return_value = True
            mock_render.return_value = [
                {
                    "kind": "Deployment",
                    "metadata": {"name": "test-project"},
                    "spec": {"env": {"ENVIRONMENT": "custom"}},
                }
            ]
            mock_request.return_value = {"deploymentId": "deploy-123"}

            result = runner.invoke(app, ["deploy", "custom-env", "-f", str(custom_values), "--yes"])

        assert result.exit_code == 0
        # Verify render_templates was called with the custom values file
        mock_render.assert_called_once()
        call_kwargs = mock_render.call_args[1]
        # Compare resolved paths (handles /private vs /var on macOS)
        assert call_kwargs["values_file"].resolve() == custom_values.resolve()


class TestDeployCommandEdgeCases:
    """Edge case tests for deploy command."""

    def test_deploy_no_templates(self, voicerun_project_with_lock, monkeypatch):
        """Should fail when no templates exist."""
        monkeypatch.chdir(voicerun_project_with_lock)

        # Create values file needed for this test
        voicerun_dir = voicerun_project_with_lock / ".voicerun"
        values_file = voicerun_dir / "values.yaml"
        values_file.write_text("environment: development\n")

        with patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.print_error"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render:

            mock_helm.return_value = True
            mock_validate.return_value = True
            mock_render.return_value = []  # No templates

            result = runner.invoke(app, ["deploy", "development", "-f", str(values_file), "--yes"])

        assert result.exit_code != 0

    def test_deploy_no_deployment_resources(self, voicerun_project_with_lock, monkeypatch):
        """Should fail when no Deployment resources found."""
        monkeypatch.chdir(voicerun_project_with_lock)

        # Create values file needed for this test
        voicerun_dir = voicerun_project_with_lock / ".voicerun"
        values_file = voicerun_dir / "values.yaml"
        values_file.write_text("environment: development\n")

        with patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.print_error"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render:

            mock_helm.return_value = True
            mock_validate.return_value = True
            # Return a ConfigMap instead of Deployment
            mock_render.return_value = [
                {
                    "kind": "ConfigMap",
                    "metadata": {"name": "test-config"},
                    "data": {"key": "value"},
                }
            ]

            result = runner.invoke(app, ["deploy", "development", "-f", str(values_file), "--yes"])

        assert result.exit_code != 0

    def test_deploy_helm_error(self, voicerun_project_with_lock, monkeypatch):
        """Should handle Helm rendering errors gracefully."""
        monkeypatch.chdir(voicerun_project_with_lock)

        from vr_cli.utils.helm import HelmError

        # Create values file needed for this test
        voicerun_dir = voicerun_project_with_lock / ".voicerun"
        values_file = voicerun_dir / "values.yaml"
        values_file.write_text("environment: development\n")

        with patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.print_error"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render:

            mock_helm.return_value = True
            mock_validate.return_value = True
            mock_render.side_effect = HelmError("Template syntax error")

            result = runner.invoke(app, ["deploy", "development", "-f", str(values_file), "--yes"])

        assert result.exit_code != 0

    def test_deploy_multiple_resources(self, voicerun_project_with_lock, monkeypatch):
        """Should handle multiple resources correctly."""
        monkeypatch.chdir(voicerun_project_with_lock)

        # Create values file needed for this test
        voicerun_dir = voicerun_project_with_lock / ".voicerun"
        values_file = voicerun_dir / "values.yaml"
        values_file.write_text("environment: development\n")

        with patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.print_success"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render, \
             patch("vr_cli.commands.deploy.make_request") as mock_request:

            mock_helm.return_value = True
            mock_validate.return_value = True
            mock_render.return_value = [
                {
                    "kind": "Deployment",
                    "metadata": {"name": "deployment-1"},
                    "spec": {},
                },
                {
                    "kind": "Deployment",
                    "metadata": {"name": "deployment-2"},
                    "spec": {},
                },
            ]
            mock_request.return_value = {"deploymentId": "deploy-123"}

            result = runner.invoke(app, ["deploy", "development", "-f", str(values_file), "--yes"])

        assert result.exit_code == 0
        # Verify both resources were sent
        call_kwargs = mock_request.call_args[1]
        assert len(call_kwargs["json"]["resources"]) == 2


class TestPromptForEnvironment:
    """Tests for prompt_for_environment function."""

    def test_no_environments_available(self):
        """Should return None when no environments exist on the agent."""
        mock_repo = Mock()
        mock_repo.get.return_value = []

        with patch("vr_cli.commands.deploy.AgentEnvironmentRepository", return_value=mock_repo), \
             patch("vr_cli.commands.deploy.print_error"), \
             patch("vr_cli.commands.deploy.print_info"):
            result = prompt_for_environment("agent-123")

        assert result is None

    def test_select_environment_from_list(self):
        """Should return selected environment from interactive list."""
        mock_env = Mock()
        mock_env.name = "staging"
        mock_env.phone_number = "+15555555555"
        mock_env.stt_model = "nova-3"

        mock_repo = Mock()
        mock_repo.get.return_value = [mock_env]

        mock_select = Mock()
        mock_select.ask.return_value = "staging"

        with patch("vr_cli.commands.deploy.sys.stdin") as mock_stdin, \
             patch("vr_cli.commands.deploy.AgentEnvironmentRepository", return_value=mock_repo), \
             patch("vr_cli.commands.deploy.questionary.select", return_value=mock_select):
            mock_stdin.isatty.return_value = True
            result = prompt_for_environment("agent-123")

        assert result == "staging"

    def test_select_from_multiple_environments(self):
        """Should allow user to select from multiple environments."""
        mock_env1 = Mock()
        mock_env1.name = "development"
        mock_env1.phone_number = "+15555555551"
        mock_env1.stt_model = "nova-3"

        mock_env2 = Mock()
        mock_env2.name = "production"
        mock_env2.phone_number = "+15555555552"
        mock_env2.stt_model = "nova-3"

        mock_repo = Mock()
        mock_repo.get.return_value = [mock_env1, mock_env2]

        mock_select = Mock()
        mock_select.ask.return_value = "production"

        with patch("vr_cli.commands.deploy.sys.stdin") as mock_stdin, \
             patch("vr_cli.commands.deploy.AgentEnvironmentRepository", return_value=mock_repo), \
             patch("vr_cli.commands.deploy.questionary.select", return_value=mock_select) as mock_questionary:
            mock_stdin.isatty.return_value = True
            result = prompt_for_environment("agent-123")

        assert result == "production"
        # Verify questionary.select was called with correct choices
        mock_questionary.assert_called_once()

    def test_user_cancels_selection(self):
        """Should return None when user cancels (Ctrl+C)."""
        mock_env = Mock()
        mock_env.name = "development"
        mock_env.phone_number = "+15555555551"
        mock_env.stt_model = "nova-3"

        mock_repo = Mock()
        mock_repo.get.return_value = [mock_env]

        mock_select = Mock()
        mock_select.ask.return_value = None  # User cancelled

        with patch("vr_cli.commands.deploy.AgentEnvironmentRepository", return_value=mock_repo), \
             patch("vr_cli.commands.deploy.questionary.select", return_value=mock_select):
            result = prompt_for_environment("agent-123")

        assert result is None

    def test_environment_without_phone_or_model(self):
        """Should handle environments with missing optional fields."""
        mock_env = Mock()
        mock_env.name = "minimal"
        mock_env.phone_number = None
        mock_env.stt_model = None

        mock_repo = Mock()
        mock_repo.get.return_value = [mock_env]

        mock_select = Mock()
        mock_select.ask.return_value = "minimal"

        with patch("vr_cli.commands.deploy.sys.stdin") as mock_stdin, \
             patch("vr_cli.commands.deploy.AgentEnvironmentRepository", return_value=mock_repo), \
             patch("vr_cli.commands.deploy.questionary.select", return_value=mock_select):
            mock_stdin.isatty.return_value = True
            result = prompt_for_environment("agent-123")

        assert result == "minimal"


class TestDeployInteractiveSelection:
    """Tests for deploy command with interactive environment selection."""

    def test_deploy_without_environment_prompts_user(self, voicerun_project_with_lock, monkeypatch):
        """Should prompt for environment when not provided."""
        monkeypatch.chdir(voicerun_project_with_lock)

        voicerun_dir = voicerun_project_with_lock / ".voicerun"
        values_file = voicerun_dir / "values.yaml"
        values_file.write_text("environment: dev\n")

        with patch("vr_cli.commands.deploy.prompt_for_environment") as mock_prompt_env, \
             patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.print_success"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render, \
             patch("vr_cli.commands.deploy.make_request") as mock_request:

            mock_prompt_env.return_value = "development"
            mock_helm.return_value = True
            mock_validate.return_value = True
            mock_render.return_value = [
                {
                    "kind": "Deployment",
                    "metadata": {"name": "test-project"},
                    "spec": {},
                }
            ]
            mock_request.return_value = {"deploymentId": "deploy-123"}

            result = runner.invoke(app, ["deploy", "-f", str(values_file), "--yes"])

        assert result.exit_code == 0
        # Should have called prompt_for_environment
        mock_prompt_env.assert_called_once()
        # Should have deployed to development (selected via prompt)
        call_kwargs = mock_request.call_args[1]
        assert call_kwargs["json"]["environment"] == "development"

    def test_deploy_without_environment_selects_from_list(self, voicerun_project_with_lock, monkeypatch):
        """Should use interactive selection for environment."""
        monkeypatch.chdir(voicerun_project_with_lock)

        voicerun_dir = voicerun_project_with_lock / ".voicerun"
        values_file = voicerun_dir / "values.yaml"
        values_file.write_text("environment: staging\n")

        with patch("vr_cli.commands.deploy.prompt_for_environment") as mock_prompt_env, \
             patch("vr_cli.commands.deploy.console"), \
             patch("vr_cli.commands.deploy.print_info"), \
             patch("vr_cli.commands.deploy.print_success"), \
             patch("vr_cli.commands.deploy.require_helm") as mock_helm, \
             patch("vr_cli.commands.deploy.run_deploy_validation") as mock_validate, \
             patch("vr_cli.commands.deploy.render_templates") as mock_render, \
             patch("vr_cli.commands.deploy.make_request") as mock_request:

            mock_prompt_env.return_value = "staging"
            mock_helm.return_value = True
            mock_validate.return_value = True
            mock_render.return_value = [
                {
                    "kind": "Deployment",
                    "metadata": {"name": "test-project"},
                    "spec": {},
                }
            ]
            mock_request.return_value = {"deploymentId": "deploy-123"}

            result = runner.invoke(app, ["deploy", "-f", str(values_file), "-y"])

        assert result.exit_code == 0
        call_kwargs = mock_request.call_args[1]
        assert call_kwargs["json"]["environment"] == "staging"

    def test_deploy_without_values_file_fails(self, voicerun_project_with_lock, monkeypatch):
        """Should fail when no values file is provided."""
        monkeypatch.chdir(voicerun_project_with_lock)

        with patch("vr_cli.commands.deploy.print_error"), \
             patch("vr_cli.commands.deploy.print_info"):
            result = runner.invoke(app, ["deploy", "development"])

        assert result.exit_code != 0
