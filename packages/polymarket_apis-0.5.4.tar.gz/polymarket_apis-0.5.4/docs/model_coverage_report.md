# Model Coverage Report

- Universe: `117` Pydantic models
- Directly tested roots: `16`
- Transitively covered through current prod-read tests: `30`
- Not covered by current prod-read tests: `87`

## Directly Tested Roots

- `polymarket_apis.types.clob_types.ClobMarket`
- `polymarket_apis.types.clob_types.OrderBookSummary`
- `polymarket_apis.types.common.TimeseriesPoint`
- `polymarket_apis.types.data_types.Activity`
- `polymarket_apis.types.data_types.ClosedPosition`
- `polymarket_apis.types.data_types.EventLiveVolume`
- `polymarket_apis.types.data_types.HolderResponse`
- `polymarket_apis.types.data_types.LeaderboardUser`
- `polymarket_apis.types.data_types.MarketValue`
- `polymarket_apis.types.data_types.Position`
- `polymarket_apis.types.data_types.Trade`
- `polymarket_apis.types.data_types.UserMetric`
- `polymarket_apis.types.data_types.UserRank`
- `polymarket_apis.types.data_types.ValueResponse`
- `polymarket_apis.types.gamma_types.Event`
- `polymarket_apis.types.gamma_types.GammaMarket`

## Coverage By Module

### `polymarket_apis.types.clob_types`

- Universe: `43` | Direct roots: `2` | Transitively covered: `6` | Not covered: `37`
- Missing:
  - `polymarket_apis.types.clob_types.ApiCreds`
  - `polymarket_apis.types.clob_types.BalanceAllowanceParams`
  - `polymarket_apis.types.clob_types.BidAsk`
  - `polymarket_apis.types.clob_types.BookParams`
  - `polymarket_apis.types.clob_types.ContractConfig`
  - `polymarket_apis.types.clob_types.CreateOrderOptions`
  - `polymarket_apis.types.clob_types.DailyEarnedReward`
  - `polymarket_apis.types.clob_types.DropNotificationParams`
  - `polymarket_apis.types.clob_types.EarnedReward`
  - `polymarket_apis.types.clob_types.MakerOrder`
  - `polymarket_apis.types.clob_types.MarketOrderArgs`
  - `polymarket_apis.types.clob_types.MarketRewards`
  - `polymarket_apis.types.clob_types.Midpoint`
  - `polymarket_apis.types.clob_types.OpenOrder`
  - `polymarket_apis.types.clob_types.OpenOrderParams`
  - `polymarket_apis.types.clob_types.OrderArgs`
  - `polymarket_apis.types.clob_types.OrderCancelResponse`
  - `polymarket_apis.types.clob_types.OrderPostResponse`
  - `polymarket_apis.types.clob_types.PaginatedResponse`
  - `polymarket_apis.types.clob_types.PartialCreateOrderOptions`
  - `polymarket_apis.types.clob_types.PastResultsData`
  - `polymarket_apis.types.clob_types.PastResultsResponse`
  - `polymarket_apis.types.clob_types.PolygonTrade`
  - `polymarket_apis.types.clob_types.PostOrdersArgs`
  - `polymarket_apis.types.clob_types.Price`
  - `polymarket_apis.types.clob_types.PriceHistory`
  - `polymarket_apis.types.clob_types.PriceLevel`
  - `polymarket_apis.types.clob_types.RequestArgs`
  - `polymarket_apis.types.clob_types.RewardConfig`
  - `polymarket_apis.types.clob_types.RewardMarket`
  - `polymarket_apis.types.clob_types.RoundConfig`
  - `polymarket_apis.types.clob_types.Spread`
  - `polymarket_apis.types.clob_types.TokenBidAsk`
  - `polymarket_apis.types.clob_types.TokenBidAskDict`
  - `polymarket_apis.types.clob_types.TokenValue`
  - `polymarket_apis.types.clob_types.TokenValueDict`
  - `polymarket_apis.types.clob_types.TradeParams`

### `polymarket_apis.types.common`

- Universe: `1` | Direct roots: `1` | Transitively covered: `1` | Not covered: `0`

### `polymarket_apis.types.data_types`

- Universe: `18` | Direct roots: `11` | Transitively covered: `12` | Not covered: `6`
- Missing:
  - `polymarket_apis.types.data_types.AccountingSnapshotCSVs`
  - `polymarket_apis.types.data_types.BuilderLeaderboardUser`
  - `polymarket_apis.types.data_types.GQLPosition`
  - `polymarket_apis.types.data_types.User`
  - `polymarket_apis.types.data_types.UserID`
  - `polymarket_apis.types.data_types.UserProfile`

### `polymarket_apis.types.gamma_types`

- Universe: `20` | Direct roots: `2` | Transitively covered: `11` | Not covered: `9`
- Missing:
  - `polymarket_apis.types.gamma_types.Comment`
  - `polymarket_apis.types.gamma_types.Pagination`
  - `polymarket_apis.types.gamma_types.Profile`
  - `polymarket_apis.types.gamma_types.ProfilePosition`
  - `polymarket_apis.types.gamma_types.Reaction`
  - `polymarket_apis.types.gamma_types.SearchResult`
  - `polymarket_apis.types.gamma_types.Sport`
  - `polymarket_apis.types.gamma_types.TagRelation`
  - `polymarket_apis.types.gamma_types.Team`

### `polymarket_apis.types.web3_types`

- Universe: `2` | Direct roots: `0` | Transitively covered: `0` | Not covered: `2`
- Missing:
  - `polymarket_apis.types.web3_types.TransactionLog`
  - `polymarket_apis.types.web3_types.TransactionReceipt`

### `polymarket_apis.types.websockets_types`

- Universe: `33` | Direct roots: `0` | Transitively covered: `0` | Not covered: `33`
- Missing:
  - `polymarket_apis.types.websockets_types.ActivityOrderMatchEvent`
  - `polymarket_apis.types.websockets_types.ActivityTrade`
  - `polymarket_apis.types.websockets_types.ActivityTradeEvent`
  - `polymarket_apis.types.websockets_types.AssetPriceSubscribe`
  - `polymarket_apis.types.websockets_types.AssetPriceSubscribeEvent`
  - `polymarket_apis.types.websockets_types.AssetPriceUpdate`
  - `polymarket_apis.types.websockets_types.AssetPriceUpdateEvent`
  - `polymarket_apis.types.websockets_types.BestBidAskEvent`
  - `polymarket_apis.types.websockets_types.CommentEvent`
  - `polymarket_apis.types.websockets_types.ErrorEvent`
  - `polymarket_apis.types.websockets_types.LastTradePrice`
  - `polymarket_apis.types.websockets_types.LastTradePriceEvent`
  - `polymarket_apis.types.websockets_types.LiveDataClobMarket`
  - `polymarket_apis.types.websockets_types.MarketEvent`
  - `polymarket_apis.types.websockets_types.MarketResolvedEvent`
  - `polymarket_apis.types.websockets_types.NewMarketEvent`
  - `polymarket_apis.types.websockets_types.OrderBookSummaryEvent`
  - `polymarket_apis.types.websockets_types.OrderEvent`
  - `polymarket_apis.types.websockets_types.PriceChange`
  - `polymarket_apis.types.websockets_types.PriceChangeEvent`
  - `polymarket_apis.types.websockets_types.PriceChanges`
  - `polymarket_apis.types.websockets_types.Quote`
  - `polymarket_apis.types.websockets_types.QuoteEvent`
  - `polymarket_apis.types.websockets_types.ReactionEvent`
  - `polymarket_apis.types.websockets_types.RelatedEvent`
  - `polymarket_apis.types.websockets_types.Request`
  - `polymarket_apis.types.websockets_types.RequestEvent`
  - `polymarket_apis.types.websockets_types.ScoreStateFields`
  - `polymarket_apis.types.websockets_types.SportsEventState`
  - `polymarket_apis.types.websockets_types.SportsGameUpdate`
  - `polymarket_apis.types.websockets_types.TickSizeChange`
  - `polymarket_apis.types.websockets_types.TickSizeChangeEvent`
  - `polymarket_apis.types.websockets_types.TradeEvent`

## Full Universe

### `polymarket_apis.types.clob_types`

- `polymarket_apis.types.clob_types.ApiCreds`: `untested`
- `polymarket_apis.types.clob_types.BalanceAllowanceParams`: `untested`
- `polymarket_apis.types.clob_types.BidAsk`: `untested`
- `polymarket_apis.types.clob_types.BookParams`: `untested`
- `polymarket_apis.types.clob_types.ClobMarket`: `direct`
- `polymarket_apis.types.clob_types.ContractConfig`: `untested`
- `polymarket_apis.types.clob_types.CreateOrderOptions`: `untested`
- `polymarket_apis.types.clob_types.DailyEarnedReward`: `untested`
- `polymarket_apis.types.clob_types.DropNotificationParams`: `untested`
- `polymarket_apis.types.clob_types.EarnedReward`: `untested`
- `polymarket_apis.types.clob_types.MakerOrder`: `untested`
- `polymarket_apis.types.clob_types.MarketOrderArgs`: `untested`
- `polymarket_apis.types.clob_types.MarketRewards`: `untested`
- `polymarket_apis.types.clob_types.Midpoint`: `untested`
- `polymarket_apis.types.clob_types.OpenOrder`: `untested`
- `polymarket_apis.types.clob_types.OpenOrderParams`: `untested`
- `polymarket_apis.types.clob_types.OrderArgs`: `untested`
- `polymarket_apis.types.clob_types.OrderBookSummary`: `direct`
- `polymarket_apis.types.clob_types.OrderCancelResponse`: `untested`
- `polymarket_apis.types.clob_types.OrderPostResponse`: `untested`
- `polymarket_apis.types.clob_types.OrderSummary`: `transitive`
- `polymarket_apis.types.clob_types.PaginatedResponse`: `untested`
- `polymarket_apis.types.clob_types.PartialCreateOrderOptions`: `untested`
- `polymarket_apis.types.clob_types.PastResultsData`: `untested`
- `polymarket_apis.types.clob_types.PastResultsResponse`: `untested`
- `polymarket_apis.types.clob_types.PolygonTrade`: `untested`
- `polymarket_apis.types.clob_types.PostOrdersArgs`: `untested`
- `polymarket_apis.types.clob_types.Price`: `untested`
- `polymarket_apis.types.clob_types.PriceHistory`: `untested`
- `polymarket_apis.types.clob_types.PriceLevel`: `untested`
- `polymarket_apis.types.clob_types.RequestArgs`: `untested`
- `polymarket_apis.types.clob_types.RewardConfig`: `untested`
- `polymarket_apis.types.clob_types.RewardMarket`: `untested`
- `polymarket_apis.types.clob_types.RewardRate`: `transitive`
- `polymarket_apis.types.clob_types.Rewards`: `transitive`
- `polymarket_apis.types.clob_types.RoundConfig`: `untested`
- `polymarket_apis.types.clob_types.Spread`: `untested`
- `polymarket_apis.types.clob_types.Token`: `transitive`
- `polymarket_apis.types.clob_types.TokenBidAsk`: `untested`
- `polymarket_apis.types.clob_types.TokenBidAskDict`: `untested`
- `polymarket_apis.types.clob_types.TokenValue`: `untested`
- `polymarket_apis.types.clob_types.TokenValueDict`: `untested`
- `polymarket_apis.types.clob_types.TradeParams`: `untested`

### `polymarket_apis.types.common`

- `polymarket_apis.types.common.TimeseriesPoint`: `direct`

### `polymarket_apis.types.data_types`

- `polymarket_apis.types.data_types.AccountingSnapshotCSVs`: `untested`
- `polymarket_apis.types.data_types.Activity`: `direct`
- `polymarket_apis.types.data_types.BuilderLeaderboardUser`: `untested`
- `polymarket_apis.types.data_types.ClosedPosition`: `direct`
- `polymarket_apis.types.data_types.EventLiveVolume`: `direct`
- `polymarket_apis.types.data_types.GQLPosition`: `untested`
- `polymarket_apis.types.data_types.Holder`: `transitive`
- `polymarket_apis.types.data_types.HolderResponse`: `direct`
- `polymarket_apis.types.data_types.LeaderboardUser`: `direct`
- `polymarket_apis.types.data_types.MarketValue`: `direct`
- `polymarket_apis.types.data_types.Position`: `direct`
- `polymarket_apis.types.data_types.Trade`: `direct`
- `polymarket_apis.types.data_types.User`: `untested`
- `polymarket_apis.types.data_types.UserID`: `untested`
- `polymarket_apis.types.data_types.UserMetric`: `direct`
- `polymarket_apis.types.data_types.UserProfile`: `untested`
- `polymarket_apis.types.data_types.UserRank`: `direct`
- `polymarket_apis.types.data_types.ValueResponse`: `direct`

### `polymarket_apis.types.gamma_types`

- `polymarket_apis.types.gamma_types.Category`: `transitive`
- `polymarket_apis.types.gamma_types.Chat`: `transitive`
- `polymarket_apis.types.gamma_types.ClobReward`: `transitive`
- `polymarket_apis.types.gamma_types.Collection`: `transitive`
- `polymarket_apis.types.gamma_types.Comment`: `untested`
- `polymarket_apis.types.gamma_types.Creator`: `transitive`
- `polymarket_apis.types.gamma_types.Event`: `direct`
- `polymarket_apis.types.gamma_types.GammaMarket`: `direct`
- `polymarket_apis.types.gamma_types.OptimizedImage`: `transitive`
- `polymarket_apis.types.gamma_types.Pagination`: `untested`
- `polymarket_apis.types.gamma_types.Profile`: `untested`
- `polymarket_apis.types.gamma_types.ProfilePosition`: `untested`
- `polymarket_apis.types.gamma_types.Reaction`: `untested`
- `polymarket_apis.types.gamma_types.SearchResult`: `untested`
- `polymarket_apis.types.gamma_types.Series`: `transitive`
- `polymarket_apis.types.gamma_types.Sport`: `untested`
- `polymarket_apis.types.gamma_types.Tag`: `transitive`
- `polymarket_apis.types.gamma_types.TagRelation`: `untested`
- `polymarket_apis.types.gamma_types.Team`: `untested`
- `polymarket_apis.types.gamma_types.Template`: `transitive`

### `polymarket_apis.types.web3_types`

- `polymarket_apis.types.web3_types.TransactionLog`: `untested`
- `polymarket_apis.types.web3_types.TransactionReceipt`: `untested`

### `polymarket_apis.types.websockets_types`

- `polymarket_apis.types.websockets_types.ActivityOrderMatchEvent`: `untested`
- `polymarket_apis.types.websockets_types.ActivityTrade`: `untested`
- `polymarket_apis.types.websockets_types.ActivityTradeEvent`: `untested`
- `polymarket_apis.types.websockets_types.AssetPriceSubscribe`: `untested`
- `polymarket_apis.types.websockets_types.AssetPriceSubscribeEvent`: `untested`
- `polymarket_apis.types.websockets_types.AssetPriceUpdate`: `untested`
- `polymarket_apis.types.websockets_types.AssetPriceUpdateEvent`: `untested`
- `polymarket_apis.types.websockets_types.BestBidAskEvent`: `untested`
- `polymarket_apis.types.websockets_types.CommentEvent`: `untested`
- `polymarket_apis.types.websockets_types.ErrorEvent`: `untested`
- `polymarket_apis.types.websockets_types.LastTradePrice`: `untested`
- `polymarket_apis.types.websockets_types.LastTradePriceEvent`: `untested`
- `polymarket_apis.types.websockets_types.LiveDataClobMarket`: `untested`
- `polymarket_apis.types.websockets_types.MarketEvent`: `untested`
- `polymarket_apis.types.websockets_types.MarketResolvedEvent`: `untested`
- `polymarket_apis.types.websockets_types.NewMarketEvent`: `untested`
- `polymarket_apis.types.websockets_types.OrderBookSummaryEvent`: `untested`
- `polymarket_apis.types.websockets_types.OrderEvent`: `untested`
- `polymarket_apis.types.websockets_types.PriceChange`: `untested`
- `polymarket_apis.types.websockets_types.PriceChangeEvent`: `untested`
- `polymarket_apis.types.websockets_types.PriceChanges`: `untested`
- `polymarket_apis.types.websockets_types.Quote`: `untested`
- `polymarket_apis.types.websockets_types.QuoteEvent`: `untested`
- `polymarket_apis.types.websockets_types.ReactionEvent`: `untested`
- `polymarket_apis.types.websockets_types.RelatedEvent`: `untested`
- `polymarket_apis.types.websockets_types.Request`: `untested`
- `polymarket_apis.types.websockets_types.RequestEvent`: `untested`
- `polymarket_apis.types.websockets_types.ScoreStateFields`: `untested`
- `polymarket_apis.types.websockets_types.SportsEventState`: `untested`
- `polymarket_apis.types.websockets_types.SportsGameUpdate`: `untested`
- `polymarket_apis.types.websockets_types.TickSizeChange`: `untested`
- `polymarket_apis.types.websockets_types.TickSizeChangeEvent`: `untested`
- `polymarket_apis.types.websockets_types.TradeEvent`: `untested`

