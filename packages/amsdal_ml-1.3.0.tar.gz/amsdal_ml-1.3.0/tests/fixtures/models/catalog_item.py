from typing import ClassVar

from amsdal_models.classes.model import Model
from amsdal_utils.models.enums import ModuleType
from pydantic.fields import Field

from tests.fixtures.models.category import Category


class CatalogItem(Model):
    __module_type__: ClassVar[ModuleType] = ModuleType.USER
    __table_name__: ClassVar[str] = 'catalog_items'
    __primary_key__: ClassVar[list[str]] = ['id']

    id: int = Field(..., title='ID')
    name: str = Field(..., title='Name')
    price: float = Field(..., title='Price')
    category: Category = Field(..., title='Category')
    description: str | None = Field(None, title='Description')
