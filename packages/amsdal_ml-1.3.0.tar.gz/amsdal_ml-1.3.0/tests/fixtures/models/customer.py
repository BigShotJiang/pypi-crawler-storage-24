from typing import ClassVar

from amsdal_models.classes.model import Model
from amsdal_models.classes.model import TypeModel
from amsdal_utils.models.enums import ModuleType
from pydantic.fields import Field


class Address(TypeModel):
    city: str = Field(..., title='City')
    street: str = Field(..., title='Street')


class ContactInfo(TypeModel):
    email: str = Field(..., title='Email')
    phone: str = Field(..., title='Phone')
    address: Address = Field(..., title='Address')


class Customer(Model):
    __module_type__ = ModuleType.USER
    __table_name__ = 'customers'
    __primary_key__: ClassVar[list[str]] = ['id']

    id: int = Field(..., title='ID')
    name: str = Field(..., title='Name')
    contact: ContactInfo = Field(..., title='Contact')
