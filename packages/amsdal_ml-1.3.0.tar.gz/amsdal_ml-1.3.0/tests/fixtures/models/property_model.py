from typing import ClassVar

from amsdal_models.classes.model import Model
from amsdal_utils.models.enums import ModuleType
from pydantic.fields import Field


class PropertyModel(Model):
    __module_type__: ClassVar[ModuleType] = ModuleType.USER
    __table_name__ = 'property_model'
    __primary_key__: ClassVar[list[str]] = ['id']

    id: int = Field(..., title='ID')

    @property
    def computed(self) -> str:
        return 'ok'
