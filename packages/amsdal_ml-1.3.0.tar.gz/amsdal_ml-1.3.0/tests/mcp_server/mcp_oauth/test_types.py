from __future__ import annotations

from datetime import UTC
from datetime import datetime

from amsdal_ml.mcp_server.mcp_oauth.services.types import JwtClaims
from amsdal_ml.mcp_server.mcp_oauth.services.types import OAuthConstants
from amsdal_ml.mcp_server.mcp_oauth.services.utils import build_access_payload
from amsdal_ml.ml_config import ml_config


def test_build_access_payload_uses_oauth_constants_in_real_flow():
    payload = build_access_payload(
        sub='user@example.com',
        resource='https://mcp.example.com',
        scope='files:read',
        now=datetime.now(tz=UTC),
    )

    assert payload[JwtClaims.TOKEN_TYPE.value] == OAuthConstants.TOKEN_TYPE_ACCESS.value
    assert payload[JwtClaims.ISSUER.value] == ml_config.oauth_issuer
