from __future__ import annotations

import asyncio
from types import SimpleNamespace
from typing import Any

from amsdal_ml.mcp_server.mcp_oauth.routes.discovery import oauth_authorization_server
from amsdal_ml.mcp_server.mcp_oauth.routes.discovery import oauth_protected_resource
from amsdal_ml.mcp_server.mcp_oauth.services.types import OAuthConstants
from amsdal_ml.ml_config import ml_config


def test_oauth_protected_resource_returns_expected_metadata(monkeypatch):
    monkeypatch.setattr(ml_config, 'oauth_issuer', 'https://auth.example.com')
    request: Any = SimpleNamespace(base_url='https://mcp.example.com/')

    result = asyncio.run(oauth_protected_resource(request))

    assert result['resource'] == 'https://mcp.example.com'
    assert result['authorization_servers'] == ['https://auth.example.com']
    assert result['scopes_supported'] == []
    assert result['resource_documentation'] == 'https://mcp.example.com/docs'


def test_oauth_authorization_server_returns_expected_metadata(monkeypatch):
    monkeypatch.setattr(ml_config, 'oauth_issuer', 'https://auth.example.com')
    request: Any = SimpleNamespace(base_url='https://auth.example.com/')

    result = asyncio.run(oauth_authorization_server(request))

    assert result['issuer'] == 'https://auth.example.com'
    assert result['authorization_endpoint'] == 'https://auth.example.com/oauth/authorize'
    assert result['token_endpoint'] == 'https://auth.example.com/oauth/token'
    assert result['registration_endpoint'] == 'https://auth.example.com/register'
    assert result['code_challenge_methods_supported'] == [OAuthConstants.CODE_CHALLENGE_METHOD_S256.value]
    assert result['scopes_supported'] == []
