from __future__ import annotations

from fastapi import FastAPI
from fastapi.routing import APIRoute

from amsdal_ml.mcp_server.mcp_oauth import init_oauth_routes
from amsdal_ml.mcp_server.mcp_oauth import oauth_router


def test_init_oauth_routes_registers_expected_route_paths():
    app = FastAPI()
    init_oauth_routes()
    app.include_router(oauth_router)

    paths = {route.path for route in app.routes if isinstance(route, APIRoute)}
    assert '/oauth/authorize' in paths
    assert '/oauth/token' in paths
    assert '/register' in paths
    assert '/auth/login' in paths
    assert '/.well-known/oauth-protected-resource' in paths
    assert '/.well-known/oauth-authorization-server' in paths
