from __future__ import annotations

import pytest

from amsdal_ml.mcp_server.server_model_explorer import mcp_server
from amsdal_ml.mcp_server.server_model_explorer.prompts.default_prompt import default_system_prompt  # noqa: F401


@pytest.mark.asyncio
async def test_mcp_server_tools_exist():
    tools = await mcp_server.list_tools()
    tool_names = [tool.name for tool in tools]
    assert 'list_available_models' in tool_names
    assert 'get_model_schema' in tool_names
    assert 'get_model_relationships' in tool_names
    assert 'perform_crud_operation' in tool_names
    assert 'list_available_transactions' in tool_names
    assert 'perform_transaction_operation' in tool_names


@pytest.mark.asyncio
async def test_mcp_server_prompts_exist():
    prompts = await mcp_server.list_prompts()
    prompt_names = [prompt.name for prompt in prompts]
    assert 'default_system_prompt' in prompt_names
