from __future__ import annotations

from amsdal_ml.ml_retrievers.adapters import OpenAIRetrieverAdapter


def test_openairetrieveradapter_wraps_schema_as_strict_data_contract() -> None:
    base_schema = {
        'type': 'object',
        'properties': {
            'query': {'type': 'string'},
            'limit': {'type': 'integer'},
        },
    }

    wrapped = OpenAIRetrieverAdapter().get_response_schema(base_schema)

    assert wrapped['name'] == 'data'
    assert wrapped['strict'] is True
    assert wrapped['schema'] is base_schema


def test_openairetrieveradapter_sets_required_and_additional_properties_recursively() -> None:
    base_schema = {
        'type': 'object',
        'properties': {
            'query': {'type': 'string'},
            'limit': {'type': 'integer'},
            'filters': {
                'type': 'object',
                'properties': {
                    'title': {'type': 'string'},
                    'price': {'type': 'number'},
                },
                'required': ['title'],
            },
        },
        'required': ['query'],
    }

    wrapped = OpenAIRetrieverAdapter().get_response_schema(base_schema)
    schema = wrapped['schema']

    assert schema['required'] == ['query', 'limit', 'filters']
    assert schema['additionalProperties'] is False

    nested = schema['properties']['filters']
    assert nested['required'] == ['title', 'price']
    assert nested['additionalProperties'] is False
