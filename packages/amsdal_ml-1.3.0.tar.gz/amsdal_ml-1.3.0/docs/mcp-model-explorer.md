---
title: MCP Model Explorer
amsdal_docs:
  target: framework/plugins/amsdal-ml/mcp-model-explorer.md
  nav_title: Model Explorer
  nav_section: Framework
  nav_path: ["Plugins & Extensions", "ML", "MCP Server"]
  nav_order: 2
---

# MCP Model Explorer

The Model Explorer is the HTTP/SSE MCP server that lets AI assistants discover, inspect, and operate on your AMSDAL models via natural language.

## Available Tools

### list_available_models

Discover all registered AMSDAL models with their fields and relationships.

**Returns** a list of models with:
- Model name
- Field names
- Foreign key relationships

### get_model_schema

Get the full JSON Schema for a specific model, including computed properties.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `model_name` | `str` | Name of the AMSDAL model |

**Returns** the complete JSON Schema with field types, constraints, defaults, and computed properties.

### get_model_relationships

Inspect a model's foreign key graph — both outgoing (many-to-one) and incoming (one-to-many) relationships.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `model_name` | `str` | Name of the AMSDAL model |

**Returns** outgoing and incoming relationship details with field names, target models, and cardinality.

### get_model_field_values_by_ids

Fetch specific field values for objects by their IDs. Supports history.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `model_name` | `str` | Name of the AMSDAL model |
| `field_name` | `str` | Field name to fetch values for |
| `object_ids` | `list[str]` | Object IDs to fetch |

### perform_crud_operation

Execute CRUD operations using natural language with a two-step confirmation flow.

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `model_name` | `str` | Name of the AMSDAL model |
| `operation` | `str` | One of: `read`, `create`, `update`, `delete` |
| `query` | `str` | Natural language description of the operation |
| `confirm` | `bool` | Set to `true` to execute after preview (default `false`) |
| `preview_limit` | `int` | Max records to show in preview (default `5`) |
| `limit` | `int \| None` | Max records to return (default `30`) |
| `analysis` | `dict \| None` | Analysis from step 1, passed back in step 2 (default `None`) |

**Two-step flow:**

1. First call with `confirm=false` — returns a preview with an `analysis` dict
2. Second call with `confirm=true` and the `analysis` from step 1 — executes the operation

This prevents accidental data modifications through AI assistants.

## Example Conversation

A typical conversation with an AI assistant connected via MCP:

> **User:** What models are available?
>
> *Assistant calls `list_available_models`*
>
> **Assistant:** You have Customer, Order, Product, and Invoice models.
>
> **User:** Show me all customers from New York
>
> *Assistant calls `perform_crud_operation(model_name='Customer', operation='read', query='customers from New York', confirm=false)`*
>
> **Assistant:** Found 12 customers from New York. [shows preview]
>
> **User:** Update John Doe's email to john@new.com
>
> *Assistant calls `perform_crud_operation(model_name='Customer', operation='update', query='update John Doe email to john@new.com', confirm=false)`*
>
> **Assistant:** This will change John Doe's email from john@old.com to john@new.com. Confirm?
>
> **User:** Yes
>
> *Assistant calls with `confirm=true`*

## Row-Level Filtering

The Model Explorer uses `api_objects` manager, which applies row-level permissions automatically. Users only see and modify records they're authorized to access.
