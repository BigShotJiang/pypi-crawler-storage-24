from importlib import import_module

from amsdal_ml.ml_models.models import MLModel


def load_ml_model_class(class_path: str) -> type[MLModel]:
    """Load an ML model class from a module path string like 'module.ClassName'."""
    try:
        module_path, class_name = class_path.rsplit('.', 1)
    except ValueError as exc:
        msg = f"Invalid ml_model_class '{class_path}'. Expected '<module>.<ClassName>'."
        raise ValueError(msg) from exc

    module = import_module(module_path)
    model_cls = getattr(module, class_name, None)
    if model_cls is None:
        msg = f"Model class '{class_name}' not found in module '{module_path}'."
        raise ImportError(msg)
    if not issubclass(model_cls, MLModel):
        msg = f"Configured model '{class_path}' must inherit from MLModel."
        raise TypeError(msg)
    return model_cls
