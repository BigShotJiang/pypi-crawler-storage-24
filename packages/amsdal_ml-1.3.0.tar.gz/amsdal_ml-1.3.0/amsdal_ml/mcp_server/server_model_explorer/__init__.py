from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp_server = FastMCP('amsdal-mcp', host='0.0.0.0')  # noqa: S104

from amsdal_ml.mcp_server.server_model_explorer.tools import crud  # noqa: F401,E402
from amsdal_ml.mcp_server.server_model_explorer.tools import discovery  # noqa: F401,E402
from amsdal_ml.mcp_server.server_model_explorer.tools import execution  # noqa: F401,E402
