from amsdal_ml.mcp_server.mcp_auth import with_amsdal_context
from amsdal_ml.mcp_server.server_model_explorer import mcp_server
from amsdal_ml.prompts import get_prompt


@mcp_server.prompt(name='default_system_prompt', description='Default system prompt for MCP interactions.')
@with_amsdal_context
async def default_system_prompt() -> str:
    prompt = get_prompt('amsdal_mcp_system')
    return prompt.render_text(input='')
