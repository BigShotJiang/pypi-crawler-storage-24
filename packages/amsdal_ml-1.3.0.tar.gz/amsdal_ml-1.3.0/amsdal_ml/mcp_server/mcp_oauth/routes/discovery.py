from __future__ import annotations

from fastapi import Request

from amsdal_ml.mcp_server.mcp_oauth import oauth_router
from amsdal_ml.mcp_server.mcp_oauth.services.types import OAuthAuthorizationServerMetadata
from amsdal_ml.mcp_server.mcp_oauth.services.types import OAuthConstants
from amsdal_ml.mcp_server.mcp_oauth.services.types import OAuthProtectedResourceMetadata
from amsdal_ml.ml_config import ml_config


@oauth_router.get('/.well-known/oauth-protected-resource')
async def oauth_protected_resource(request: Request) -> OAuthProtectedResourceMetadata:
    resource = str(request.base_url).rstrip('/')
    issuer = ml_config.oauth_issuer
    return {
        'resource': resource,
        'authorization_servers': [issuer],
        'scopes_supported': [],
        'resource_documentation': f'{resource}/docs',
    }


@oauth_router.get('/.well-known/oauth-authorization-server')
async def oauth_authorization_server(request: Request) -> OAuthAuthorizationServerMetadata:
    issuer = ml_config.oauth_issuer
    base = str(request.base_url).rstrip('/')
    return {
        'issuer': issuer,
        'authorization_endpoint': f'{base}{oauth_router.url_path_for("authorize")}',
        'token_endpoint': f'{base}{oauth_router.url_path_for("token")}',
        'registration_endpoint': f'{base}{oauth_router.url_path_for("register")}',
        'code_challenge_methods_supported': [OAuthConstants.CODE_CHALLENGE_METHOD_S256.value],
        'scopes_supported': [],
    }
