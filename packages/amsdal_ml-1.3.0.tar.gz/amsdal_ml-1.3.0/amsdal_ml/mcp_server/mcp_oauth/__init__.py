import importlib

from fastapi import APIRouter
from fastapi import Depends

from amsdal_ml.mcp_server.mcp_oauth.services.dependencies import require_oauth_enabled

oauth_router = APIRouter(dependencies=[Depends(require_oauth_enabled)])


def init_oauth_routes() -> None:
    importlib.import_module('amsdal_ml.mcp_server.mcp_oauth.routes.authorize')
    importlib.import_module('amsdal_ml.mcp_server.mcp_oauth.routes.discovery')
    importlib.import_module('amsdal_ml.mcp_server.mcp_oauth.routes.login')
    importlib.import_module('amsdal_ml.mcp_server.mcp_oauth.routes.register')
    importlib.import_module('amsdal_ml.mcp_server.mcp_oauth.routes.token')


__all__ = ['init_oauth_routes', 'oauth_router']
