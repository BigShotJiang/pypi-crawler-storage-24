from __future__ import annotations

from enum import StrEnum
from typing import Literal

from typing_extensions import TypedDict

JWT_ALGORITHM = 'HS256'
TEXT_ENCODING_UTF8 = 'utf-8'
LOGIN_TEMPLATE_PATH = 'templates/login.html'
AUTH_COOKIE_NAME = 'amsdal_auth'
COOKIE_SAMESITE_LAX: Literal['lax'] = 'lax'
DEFAULT_NEXT_PATH = '/'
URL_SCHEME_HTTPS = 'https'
APP_STATE_OAUTH_WWW_AUTHENTICATE_INSTALLED = 'oauth_www_authenticate_installed'


class AuthorizationCodeCacheEntry(TypedDict):
    exp_ts: int


class OAuthProtectedResourceMetadata(TypedDict):
    resource: str
    authorization_servers: list[str]
    scopes_supported: list[str]
    resource_documentation: str


class OAuthAuthorizationServerMetadata(TypedDict):
    issuer: str
    authorization_endpoint: str
    token_endpoint: str
    registration_endpoint: str
    code_challenge_methods_supported: list[str]
    scopes_supported: list[str]


class OAuthConstants(StrEnum):
    CODE_CHALLENGE_METHOD_S256 = 'S256'
    TOKEN_ENDPOINT_AUTH_NONE = 'none'
    BEARER_PREFIX = 'bearer '
    TOKEN_TYPE_BEARER = 'Bearer'
    TOKEN_TYPE_ACCESS = 'access'
    TOKEN_TYPE_REFRESH = 'refresh'


class JwtClaims(StrEnum):
    ISSUER = 'iss'
    SUBJECT = 'sub'
    EMAIL = 'email'
    AUDIENCE = 'aud'
    EXPIRATION = 'exp'
    ISSUED_AT = 'iat'
    JWT_ID = 'jti'
    TOKEN_TYPE = 'token_type'
    CLIENT_ID = 'client_id'
    SCOPE = 'scope'
    RESOURCE = 'resource'
    REDIRECT_URI = 'redirect_uri'
    CODE_CHALLENGE = 'code_challenge'
    CODE_CHALLENGE_METHOD = 'code_challenge_method'

    CODE = 'code'
    STATE = 'state'


class ClientIdTokenClaims(StrEnum):
    ISSUER = 'iss'
    EXPIRATION = 'exp'
    ISSUED_AT = 'iat'
    JWT_ID = 'jti'
    REDIRECT_URIS = 'redirect_uris'
    GRANT_TYPES = 'grant_types'
    RESPONSE_TYPES = 'response_types'
    TOKEN_ENDPOINT_AUTH_METHOD = 'token_endpoint_auth_method'


class GrantTypes(StrEnum):
    AUTHORIZATION_CODE = 'authorization_code'
    REFRESH_TOKEN = 'refresh_token'


class ResponseTypes(StrEnum):
    CODE = 'code'
