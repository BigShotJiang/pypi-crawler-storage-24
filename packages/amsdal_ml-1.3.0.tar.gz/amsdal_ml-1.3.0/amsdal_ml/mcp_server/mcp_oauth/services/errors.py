from fastapi import HTTPException


class OAuthDisabledError(HTTPException):
    def __init__(self):
        super().__init__(status_code=404, detail='OAuth disabled')


class OAuthBadRequestError(HTTPException):
    def __init__(self, detail: str):
        super().__init__(status_code=400, detail=detail)


class OAuthServerError(HTTPException):
    def __init__(self, detail: str):
        super().__init__(status_code=500, detail=detail)


class OAuthAuthUnavailableError(OAuthServerError):
    def __init__(self):
        super().__init__('amsdal.contrib.auth is not available')


class OAuthTokenGenerationError(OAuthServerError):
    def __init__(self):
        super().__init__('LoginSession token not generated')
