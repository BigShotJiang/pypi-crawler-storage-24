from __future__ import annotations

from abc import ABC
from abc import abstractmethod
from typing import NamedTuple

from amsdal.models import Model


class ChunkParams(NamedTuple):
    max_depth: int
    max_chunks: int
    max_tokens_per_chunk: int


class ChunkStrategy(ABC):
    """Abstract base class for chunk strategies that determine ingestion parameters."""

    @abstractmethod
    def get_params(self, obj: Model) -> ChunkParams:
        """Returns chunk parameters for the given model instance."""
        ...


class DefaultChunkStrategy(ChunkStrategy):
    """Default chunk strategy with fixed parameters as originally implemented."""

    def get_params(self, obj: Model) -> ChunkParams:  # noqa: ARG002
        return ChunkParams(
            max_depth=2,
            max_chunks=10,
            max_tokens_per_chunk=800,
        )
