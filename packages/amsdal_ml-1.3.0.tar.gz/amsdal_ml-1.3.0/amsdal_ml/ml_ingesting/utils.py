from typing import Annotated
from typing import Any
from typing import ForwardRef
from typing import get_args
from typing import get_origin

from amsdal.models.core.file import File
from amsdal_utils.models.data_models.reference import Reference


def is_file_annotation(annotation: Any) -> bool:
    if isinstance(annotation, ForwardRef):
        forward = annotation.__forward_arg__
        return 'File' in forward
    if annotation is File:
        return True
    if annotation is Reference:
        return True
    origin = get_origin(annotation)
    if origin is None:
        return False
    if origin is Reference:
        args = get_args(annotation)
        if args:
            return is_file_annotation(args[0])
        return False
    if origin is Annotated:
        args = get_args(annotation)
        if not args:
            return False
        return is_file_annotation(args[0])
    return any(is_file_annotation(arg) for arg in get_args(annotation))
