from __future__ import annotations

from collections.abc import Collection

from amsdal_ml.ml_models.utils import ResponseFormat


def select_response_format(
    supported_formats: Collection[ResponseFormat],
    requested: ResponseFormat | None = None,
) -> ResponseFormat:
    if requested is not None:
        return requested

    if ResponseFormat.JSON_SCHEMA in supported_formats:
        return ResponseFormat.JSON_SCHEMA
    if ResponseFormat.JSON_OBJECT in supported_formats:
        return ResponseFormat.JSON_OBJECT
    return ResponseFormat.PLAIN_TEXT
