from __future__ import annotations

from typing import Any


def deep_merge_dicts(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = dict(base)
    for key, patch_value in patch.items():
        base_value = result.get(key)
        if isinstance(base_value, dict) and isinstance(patch_value, dict):
            result[key] = deep_merge_dicts(base_value, patch_value)
        else:
            result[key] = patch_value
    return result
