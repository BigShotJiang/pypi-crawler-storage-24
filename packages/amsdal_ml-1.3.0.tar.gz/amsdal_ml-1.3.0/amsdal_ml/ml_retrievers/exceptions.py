from __future__ import annotations

import json


class MultipleRecordsError(RuntimeError):
    def __init__(self, message: str, *, total: int, records: list[dict[str, object]]) -> None:
        super().__init__(message)
        self.total = total
        self.records = records

    def __str__(self) -> str:
        base = super().__str__()
        try:
            preview = json.dumps(self.records[:5], ensure_ascii=False)
        except Exception:  # noqa: BLE001
            preview = str(self.records[:5])
        return f'{base} (total={self.total}, preview={preview})'
