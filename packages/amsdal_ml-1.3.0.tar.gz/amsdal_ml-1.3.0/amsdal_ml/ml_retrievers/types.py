from __future__ import annotations

from typing import TypeVar

from amsdal_models.classes.model import Model
from amsdal_models.querysets.base_queryset import QuerySetBase

T = TypeVar('T', bound=Model)
AmsdalQuerySet = QuerySetBase[T]
