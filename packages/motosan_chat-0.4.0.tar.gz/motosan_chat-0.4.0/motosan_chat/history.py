from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Protocol


@dataclass(slots=True)
class HistoryMessage:
    role: str
    content: str

    @classmethod
    def user(cls, content: str) -> HistoryMessage:
        return cls(role="user", content=content)

    @classmethod
    def assistant(cls, content: str) -> HistoryMessage:
        return cls(role="assistant", content=content)


@dataclass
class HistoryRecord:
    messages: list[HistoryMessage]
    updated_at_epoch_secs: float = field(default_factory=time.time)

    def __init__(self, messages: list[HistoryMessage]) -> None:
        self.messages = messages
        self.updated_at_epoch_secs = time.time()


@dataclass
class HistoryConfig:
    max_messages: int = 50
    keep_recent: int = 20
    strategy: str = "truncate"  # "truncate" | "none"
    ttl_seconds: int = 7200


class ConversationStore(Protocol):
    async def load(self, key: str) -> HistoryRecord | None: ...

    async def save(self, key: str, record: HistoryRecord) -> None: ...

    async def clear(self, key: str) -> None: ...


class InMemoryConversationStore:
    def __init__(self) -> None:
        self._records: dict[str, HistoryRecord] = {}

    async def load(self, key: str) -> HistoryRecord | None:
        return self._records.get(key)

    async def save(self, key: str, record: HistoryRecord) -> None:
        self._records[key] = record

    async def clear(self, key: str) -> None:
        self._records.pop(key, None)
