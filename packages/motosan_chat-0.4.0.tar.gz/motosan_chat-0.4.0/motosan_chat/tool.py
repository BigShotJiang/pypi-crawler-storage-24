from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Protocol


@dataclass(slots=True)
class ToolContext:
    caller_id: str
    channel_name: str


@dataclass(slots=True)
class ToolDef:
    name: str
    description: str
    schema: dict[str, Any]

    def validate_args(self, args: dict[str, Any]) -> None:
        required = self.schema.get("required", [])
        for key in required:
            if key not in args:
                raise ValueError(f"missing required field: {key}")

        props = self.schema.get("properties", {})
        for key, value in args.items():
            expected = props.get(key, {}).get("type")
            if expected is None:
                continue
            if expected == "string" and not isinstance(value, str):
                raise ValueError(f"field {key} must be string")
            if expected == "number" and not isinstance(value, (int, float)):
                raise ValueError(f"field {key} must be number")
            if expected == "object" and not isinstance(value, dict):
                raise ValueError(f"field {key} must be object")


@dataclass(slots=True)
class ToolResult:
    is_error: bool
    content: list[Any] = field(default_factory=list)

    @classmethod
    def text(cls, text: str) -> "ToolResult":
        return cls(is_error=False, content=[text])

    @classmethod
    def json(cls, value: dict[str, Any]) -> "ToolResult":
        return cls(is_error=False, content=[value])

    @classmethod
    def error(cls, message: str) -> "ToolResult":
        return cls(is_error=True, content=[message])


class Tool(Protocol):
    def def_(self) -> ToolDef: ...

    async def call(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult: ...


class FunctionTool:
    def __init__(
        self,
        name: str,
        description: str,
        schema: dict[str, Any],
        fn: Callable[[dict[str, Any], ToolContext], Awaitable[ToolResult]],
    ) -> None:
        self._def = ToolDef(name=name, description=description, schema=schema)
        self._fn = fn

    def def_(self) -> ToolDef:
        return self._def

    async def call(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        self._def.validate_args(args)
        result = self._fn(args, ctx)
        if inspect.isawaitable(result):
            return await result
        return result


def tool(
    *,
    name: str,
    description: str,
    schema: dict[str, Any],
) -> Callable[[Callable[[dict[str, Any], ToolContext], Awaitable[ToolResult]]], FunctionTool]:
    def decorator(
        fn: Callable[[dict[str, Any], ToolContext], Awaitable[ToolResult]],
    ) -> FunctionTool:
        return FunctionTool(name=name, description=description, schema=schema, fn=fn)

    return decorator
