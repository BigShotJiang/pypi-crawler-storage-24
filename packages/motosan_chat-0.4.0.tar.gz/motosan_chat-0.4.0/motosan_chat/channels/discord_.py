from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from typing import Protocol

from motosan_chat.core import IncomingEvent


class DiscordApi(Protocol):
    async def start(
        self,
        on_message: Callable[[str, str], Awaitable[None]],
    ) -> None: ...

    async def send_message(self, user_id: str, text: str) -> str: ...

    async def edit_message(self, user_id: str, message_id: str, text: str) -> None: ...


@dataclass
class _StreamState:
    message_id: str | None = None
    buffer: str = ""


class DiscordChannel:
    def __init__(self, token: str, prefix: str = "!", api: DiscordApi | None = None) -> None:
        self._token = token
        self._prefix = prefix
        self._api = api or _DiscordPyApi(token)
        self._incoming_events: asyncio.Queue[IncomingEvent] = asyncio.Queue()
        self._started = False
        self._stream_states: dict[str, _StreamState] = {}

    @property
    def name(self) -> str:
        return "discord"

    async def listen(self) -> AsyncIterator[IncomingEvent]:
        if not self._started:
            self._started = True
            await self._api.start(self._on_message)
        while True:
            yield await self._incoming_events.get()

    async def stream_chunk(self, user_id: str, chunk: str) -> None:
        state = self._stream_states.setdefault(user_id, _StreamState())
        state.buffer += chunk
        if state.message_id is None:
            state.message_id = await self._api.send_message(user_id, state.buffer)
        else:
            await self._api.edit_message(user_id, state.message_id, state.buffer)

    async def stream_done(self, user_id: str) -> None:
        self._stream_states.pop(user_id, None)

    async def send(self, user_id: str, text: str) -> None:
        await self._api.send_message(user_id, text)

    async def _on_message(self, user_id: str, text: str) -> None:
        if text.startswith(self._prefix):
            text = text[len(self._prefix) :]
        await self._incoming_events.put(
            IncomingEvent(
                user_id=user_id,
                content=text,
                channel_name=self.name,
                chat_type="dm",
            )
        )


class _DiscordPyApi:
    def __init__(self, token: str) -> None:
        self._token = token

    async def start(
        self,
        on_message: Callable[[str, str], Awaitable[None]],
    ) -> None:
        try:
            import discord
        except ImportError as exc:
            raise ImportError(
                "discord extras are required. Install with: pip install 'motosan-chat[discord]'"
            ) from exc

        intents = discord.Intents.default()
        intents.message_content = True
        client = discord.Client(intents=intents)

        @client.event
        async def on_message_event(message):  # type: ignore[no-untyped-def]
            if message.author.bot:
                return
            await on_message(str(message.author.id), str(message.content))

        client.event(on_message_event)
        await client.start(self._token)

    async def send_message(self, user_id: str, text: str) -> str:
        _ = (user_id, text)
        raise NotImplementedError("discord live send is not implemented in default api")

    async def edit_message(self, user_id: str, message_id: str, text: str) -> None:
        _ = (user_id, message_id, text)
        raise NotImplementedError("discord live edit is not implemented in default api")
