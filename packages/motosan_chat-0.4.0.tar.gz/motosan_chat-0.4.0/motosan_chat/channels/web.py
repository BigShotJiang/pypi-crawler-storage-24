from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

import asyncio

from motosan_chat.core import IncomingEvent


class WebChannel:
    def __init__(self, host: str = "0.0.0.0", port: int = 8000) -> None:
        self._host = host
        self._port = port
        self._incoming_events: asyncio.Queue[IncomingEvent] = asyncio.Queue()
        self._streams: dict[str, asyncio.Queue[str | None]] = {}

    @property
    def name(self) -> str:
        return "web"

    @property
    def host(self) -> str:
        return self._host

    @property
    def port(self) -> int:
        return self._port

    async def listen(self) -> AsyncIterator[IncomingEvent]:
        while True:
            yield await self._incoming_events.get()

    async def stream_chunk(self, user_id: str, chunk: str) -> None:
        queue = self._streams.setdefault(user_id, asyncio.Queue())
        await queue.put(chunk)

    async def stream_done(self, user_id: str) -> None:
        queue = self._streams.setdefault(user_id, asyncio.Queue())
        await queue.put(None)

    async def send(self, user_id: str, text: str) -> None:
        await self.stream_chunk(user_id, text)
        await self.stream_done(user_id)

    def app(self):  # type: ignore[no-untyped-def]
        try:
            from fastapi import FastAPI
            from fastapi.responses import HTMLResponse, JSONResponse
            from sse_starlette.sse import EventSourceResponse
        except ImportError as exc:
            raise ImportError(
                "web extras are required. Install with: pip install 'motosan-chat[web]'"
            ) from exc

        app = FastAPI()

        @app.get("/", response_class=HTMLResponse)
        async def index() -> str:
            return _INDEX_HTML

        @app.post("/chat")
        async def chat(payload: dict[str, Any]):
            event = IncomingEvent(
                user_id=str(payload["user_id"]),
                content=str(payload["content"]),
                channel_name=self.name,
                chat_type=payload.get("chat_type", "dm"),
            )
            await self._incoming_events.put(event)
            return JSONResponse({"ok": True})

        @app.get("/chat/{user_id}/stream")
        async def stream(user_id: str):
            queue = self._streams.setdefault(user_id, asyncio.Queue())

            async def events() -> AsyncIterator[dict[str, Any]]:
                while True:
                    item = await queue.get()
                    if item is None:
                        yield {"event": "done", "data": ""}
                        break
                    yield {"event": "chunk", "data": item}

            return EventSourceResponse(events())

        return app


_INDEX_HTML = """<!doctype html>
<html>
  <head>
    <meta charset=\"utf-8\" />
    <title>motosan-chat web</title>
  </head>
  <body>
    <h1>motosan-chat web</h1>
    <p>POST /chat and connect GET /chat/{user_id}/stream</p>
  </body>
</html>
"""
