from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from typing import Protocol

from motosan_chat.core import IncomingEvent


class TelegramApi(Protocol):
    async def start_polling(
        self,
        on_text_message: Callable[[str, str], Awaitable[None]],
    ) -> None: ...

    async def send_message(self, user_id: str, text: str) -> str: ...

    async def edit_message_text(self, user_id: str, message_id: str, text: str) -> None: ...


@dataclass
class _StreamState:
    message_id: str | None = None
    buffer: str = ""


class TelegramChannel:
    def __init__(self, token: str, api: TelegramApi | None = None) -> None:
        self._token = token
        self._api = api or _PtbTelegramApi(token)
        self._incoming_events: asyncio.Queue[IncomingEvent] = asyncio.Queue()
        self._polling_started = False
        self._stream_states: dict[str, _StreamState] = {}

    @property
    def name(self) -> str:
        return "telegram"

    async def listen(self) -> AsyncIterator[IncomingEvent]:
        if not self._polling_started:
            self._polling_started = True
            await self._api.start_polling(self._on_text_message)

        while True:
            yield await self._incoming_events.get()

    async def stream_chunk(self, user_id: str, chunk: str) -> None:
        state = self._stream_states.setdefault(user_id, _StreamState())
        state.buffer += chunk
        if state.message_id is None:
            state.message_id = await self._api.send_message(user_id, state.buffer)
        else:
            await self._api.edit_message_text(user_id, state.message_id, state.buffer)

    async def stream_done(self, user_id: str) -> None:
        self._stream_states.pop(user_id, None)

    async def send(self, user_id: str, text: str) -> None:
        await self._api.send_message(user_id, text)

    async def _on_text_message(self, user_id: str, text: str) -> None:
        await self._incoming_events.put(
            IncomingEvent(
                user_id=user_id,
                content=text,
                channel_name=self.name,
                chat_type="dm",
            )
        )


class _PtbTelegramApi:
    def __init__(self, token: str) -> None:
        self._token = token

    async def start_polling(
        self,
        on_text_message: Callable[[str, str], Awaitable[None]],
    ) -> None:
        try:
            from telegram.ext import ApplicationBuilder, MessageHandler, filters
        except ImportError as exc:
            raise ImportError(
                "telegram extras are required. Install with: pip install 'motosan-chat[telegram]'"
            ) from exc

        application = ApplicationBuilder().token(self._token).build()

        async def handle_update(update, context) -> None:  # type: ignore[no-untyped-def]
            _ = context
            if update.effective_user is None or update.effective_message is None:
                return
            text = update.effective_message.text
            if not text:
                return
            await on_text_message(str(update.effective_user.id), text)

        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_update))
        await application.initialize()
        await application.start()
        await application.updater.start_polling()  # type: ignore[union-attr]

    async def send_message(self, user_id: str, text: str) -> str:
        try:
            from telegram import Bot
        except ImportError as exc:
            raise ImportError(
                "telegram extras are required. Install with: pip install 'motosan-chat[telegram]'"
            ) from exc
        bot = Bot(token=self._token)
        message = await bot.send_message(chat_id=user_id, text=text)
        return str(message.message_id)

    async def edit_message_text(self, user_id: str, message_id: str, text: str) -> None:
        try:
            from telegram import Bot
        except ImportError as exc:
            raise ImportError(
                "telegram extras are required. Install with: pip install 'motosan-chat[telegram]'"
            ) from exc
        bot = Bot(token=self._token)
        await bot.edit_message_text(
            chat_id=user_id,
            message_id=int(message_id),
            text=text,
        )
