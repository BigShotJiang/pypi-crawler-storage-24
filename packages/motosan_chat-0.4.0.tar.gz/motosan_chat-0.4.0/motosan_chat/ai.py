from __future__ import annotations

from typing import Any, AsyncIterator

from .agent import LlmResponse, Message, ToolCallItem
from .tool import ToolDef


def _require_motosan_ai() -> Any:
    try:
        import motosan_ai  # type: ignore

        return motosan_ai
    except ImportError as exc:
        raise ImportError(
            "motosan-ai is required. Install with: pip install 'motosan-chat[ai]'"
        ) from exc


class MotosanAiClient:
    def __init__(self, client: Any, system: str | None = None) -> None:
        self._client = client
        self._system = system

    def with_system(self, system: str) -> "MotosanAiClient":
        return MotosanAiClient(self._client, system)

    @classmethod
    def from_motosan_ai_client(cls, client: Any, system: str | None = None) -> "MotosanAiClient":
        _require_motosan_ai()
        return cls(client=client, system=system)

    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        ai_messages = [_to_ai_message(message) for message in messages]
        ai_tools = [_to_ai_tool(tool) for tool in tools]
        response = await self._client.chat(
            ai_messages,
            tools=ai_tools,
            system=self._system,
        )
        tool_calls = getattr(response, "tool_calls", [])
        if len(tool_calls) == 1:
            tc = tool_calls[0]
            return LlmResponse.tool_call(id=tc.id, name=tc.name, args=getattr(tc, "input", {}))
        elif len(tool_calls) > 1:
            return LlmResponse.tool_calls([
                ToolCallItem(id=tc.id, name=tc.name, args=getattr(tc, "input", {}))
                for tc in tool_calls
            ])
        return LlmResponse.message(getattr(response, "content", ""))

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        ai_messages = [_to_ai_message(message) for message in messages]
        async for event in self._client.stream(ai_messages, system=self._system):
            yield getattr(event, "content", "")


def _to_ai_message(message: Message) -> Any:
    motosan_ai = _require_motosan_ai()
    AiMessage = motosan_ai.types.Message
    AiToolCall = motosan_ai.types.ToolCall

    if message.role == "tool":
        return AiMessage.tool_result(message.tool_call_id or "", message.content)

    if message.role == "assistant" and message.tool_calls:
        return AiMessage.assistant_with_tool_calls(
            message.content,
            [
                AiToolCall(id=ref.id, name=ref.name, input={})
                for ref in message.tool_calls
            ],
        )

    if message.role == "assistant":
        return AiMessage.assistant(message.content)

    if message.role == "system":
        return AiMessage.system(message.content)

    return AiMessage.user(message.content)


def _to_ai_tool(tool: ToolDef) -> Any:
    motosan_ai = _require_motosan_ai()
    AiTool = motosan_ai.types.Tool
    return AiTool(
        name=tool.name,
        description=tool.description,
        input_schema=tool.schema,
    )
