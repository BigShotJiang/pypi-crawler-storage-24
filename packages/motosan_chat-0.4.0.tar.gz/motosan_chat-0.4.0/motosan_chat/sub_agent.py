"""SubAgentTool — a Tool that runs an inner AgentLoop to handle sub-tasks."""

from __future__ import annotations
import asyncio
from typing import Any
from .agent import AgentLoop, LlmClient, Message
from .tool import Tool, ToolDef, ToolResult, ToolContext
from .core import Thread, IncomingEvent


class _NoopChannel:
    """Minimal channel stub that silently drops all output."""

    def __init__(self, name: str) -> None:
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    async def listen(self):  # type: ignore[override]
        return
        yield  # make it a generator

    async def stream_chunk(self, user_id: str, chunk: str) -> None:
        pass

    async def stream_done(self, user_id: str) -> None:
        pass

    async def send(self, user_id: str, text: str) -> None:
        pass


def _make_stub_thread(caller_id: str, channel_name: str) -> Thread:
    """Create a lightweight Thread stub for sub-agent execution."""
    event = IncomingEvent(user_id=caller_id, content="", channel_name=channel_name)
    channel = _NoopChannel(name=channel_name)
    return Thread(event=event, channel=channel)


class SubAgentTool:
    """A Tool that runs an inner AgentLoop to handle sub-tasks.

    Spawns a lightweight inner AgentLoop with a different model/tool set,
    isolating context from the main agent.
    """

    def __init__(
        self,
        name: str,
        description: str,
        tools: list[Tool],
        llm: LlmClient,
        max_iterations: int = 3,
        max_subagents: int = 5,
    ) -> None:
        self._def = ToolDef(
            name=name,
            description=description,
            schema={
                "type": "object",
                "properties": {"query": {"type": "string", "description": "task for sub-agent"}},
                "required": ["query"],
            },
        )
        self._loop = AgentLoop(tools=tools, max_iterations=max_iterations)
        self._llm = llm
        self._semaphore = asyncio.Semaphore(max_subagents)

    def def_(self) -> ToolDef:
        return self._def

    async def call(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        stub = _make_stub_thread(caller_id=ctx.caller_id, channel_name=ctx.channel_name)
        try:
            async with asyncio.timeout(30):
                async with self._semaphore:
                    result = await self._loop.run(
                        self._llm, stub, [Message.user(args.get("query", ""))]
                    )
                    return ToolResult.text(result.answer)
        except TimeoutError:
            return ToolResult.error("subagent concurrency limit reached")
        except Exception as e:
            return ToolResult.error(str(e))
