from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Literal, Protocol

from .core import Thread
from .tool import Tool, ToolContext, ToolDef, ToolResult


@dataclass(slots=True)
class ToolCallRef:
    id: str
    name: str


@dataclass(slots=True)
class ToolCallItem:
    id: str
    name: str
    args: dict[str, Any]


@dataclass(slots=True)
class Message:
    role: Literal["system", "user", "assistant", "tool"]
    content: str
    tool_call_id: str | None = None
    tool_calls: list[ToolCallRef] = field(default_factory=list)

    @classmethod
    def system(cls, content: str) -> "Message":
        return cls(role="system", content=content)

    @classmethod
    def user(cls, content: str) -> "Message":
        return cls(role="user", content=content)

    @classmethod
    def assistant(cls, content: str) -> "Message":
        return cls(role="assistant", content=content)

    @classmethod
    def assistant_with_tool_call(
        cls,
        tool_call_id: str,
        tool_name: str,
        content: str = "",
    ) -> "Message":
        return cls(
            role="assistant",
            content=content,
            tool_calls=[ToolCallRef(id=tool_call_id, name=tool_name)],
        )

    @classmethod
    def tool_result(cls, tool_call_id: str, content: str) -> "Message":
        return cls(role="tool", content=content, tool_call_id=tool_call_id)


@dataclass(slots=True)
class LlmResponse:
    kind: Literal["message", "tool_call", "tool_calls"]
    content: str = ""
    tool_call_id: str | None = None
    tool_name: str | None = None
    tool_args: dict[str, Any] = field(default_factory=dict)
    tool_calls_batch: list[ToolCallItem] = field(default_factory=list)

    @classmethod
    def message(cls, content: str) -> "LlmResponse":
        return cls(kind="message", content=content)

    @classmethod
    def tool_call(cls, id: str, name: str, args: dict[str, Any]) -> "LlmResponse":
        return cls(kind="tool_call", tool_call_id=id, tool_name=name, tool_args=args)

    @classmethod
    def tool_calls(cls, items: list[ToolCallItem]) -> "LlmResponse":
        return cls(kind="tool_calls", tool_calls_batch=items)


@dataclass(slots=True)
class StreamChunk:
    kind: Literal["text", "tool_call_start", "tool_call_args", "tool_call_end"]
    content: str = ""
    tool_id: str = ""
    tool_name: str = ""


class LlmClient(Protocol):
    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse: ...

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]: ...

    async def stream_with_tools(
        self,
        messages: list[Message],
        tools: list[ToolDef],
    ) -> AsyncIterator[StreamChunk]: ...


class ContextProvider(Protocol):
    async def build(self, query: str) -> str: ...


@dataclass(slots=True)
class AgentResult:
    answer: str
    tool_calls: list[tuple[str, dict[str, Any]]]
    iterations: int


class AgentLoop:
    def __init__(
        self,
        tools: list[Tool] | None = None,
        context_providers: list[ContextProvider] | None = None,
        max_iterations: int = 10,
    ) -> None:
        self._tools = tools or []
        self._context_providers = context_providers or []
        self._max_iterations = max_iterations

    async def run(
        self,
        llm: LlmClient,
        thread: Thread,
        messages: list[Message],
    ) -> AgentResult:
        tool_calls: list[tuple[str, dict[str, Any]]] = []

        user_query = ""
        for message in reversed(messages):
            if message.role == "user":
                user_query = message.content
                break

        for provider in self._context_providers:
            context = await provider.build(user_query)
            if context:
                messages.append(Message.system(context))

        for iteration in range(1, self._max_iterations + 1):
            defs = [tool.def_() for tool in self._tools]

            # Try stream_with_tools first, fall back to chat
            response: LlmResponse | None = None
            try:
                stream_iter = await llm.stream_with_tools(messages, defs)
                response, streamed_text = await self._consume_stream(
                    stream_iter, thread,
                )
            except AttributeError:
                response = None

            if response is None:
                response = await llm.chat(messages, defs)

            if response.kind == "message":
                return AgentResult(
                    answer=response.content,
                    tool_calls=tool_calls,
                    iterations=iteration,
                )

            # Normalize to batch
            if response.kind == "tool_call":
                batch = [ToolCallItem(
                    id=response.tool_call_id or "",
                    name=response.tool_name or "",
                    args=response.tool_args,
                )]
            elif response.kind == "tool_calls":
                batch = response.tool_calls_batch
            else:
                continue  # shouldn't happen

            ctx = ToolContext(caller_id=thread.user_id, channel_name=thread.channel.name)

            # Stream all tool names
            for tc in batch:
                await thread.stream_chunk(f"🔧 {tc.name}...")

            # Parallel execution
            results = await asyncio.gather(*[
                self._run_tool(tc.name, tc.args, ctx) for tc in batch
            ])

            # Append messages for each tool call
            for tc, output in zip(batch, results):
                tool_calls.append((tc.name, tc.args))
                messages.extend([
                    Message.assistant_with_tool_call(tc.id, tc.name),
                    Message.tool_result(tc.id, self._tool_result_to_message(output)),
                ])

        raise RuntimeError(f"max iterations reached ({self._max_iterations})")

    @staticmethod
    async def _consume_stream(
        stream: AsyncIterator[StreamChunk],
        thread: Thread,
    ) -> tuple[LlmResponse, str]:
        """Consume a stream_with_tools iterator.

        Returns an ``LlmResponse`` synthesised from the accumulated chunks
        together with the concatenated text content.
        """
        text_parts: list[str] = []
        # tool_id -> (name, arg_fragments)
        pending: dict[str, tuple[str, list[str]]] = {}
        completed: list[ToolCallItem] = []

        async for chunk in stream:
            if chunk.kind == "text":
                text_parts.append(chunk.content)
                await thread.stream_chunk(chunk.content)
            elif chunk.kind == "tool_call_start":
                pending[chunk.tool_id] = (chunk.tool_name, [])
            elif chunk.kind == "tool_call_args":
                if chunk.tool_id in pending:
                    pending[chunk.tool_id][1].append(chunk.content)
            elif chunk.kind == "tool_call_end":
                if chunk.tool_id in pending:
                    name, fragments = pending.pop(chunk.tool_id)
                    raw = "".join(fragments)
                    args = json.loads(raw) if raw else {}
                    completed.append(ToolCallItem(id=chunk.tool_id, name=name, args=args))

        full_text = "".join(text_parts)

        if not completed:
            return LlmResponse.message(full_text), full_text

        if len(completed) == 1:
            tc = completed[0]
            return LlmResponse.tool_call(tc.id, tc.name, tc.args), full_text

        return LlmResponse.tool_calls(completed), full_text

    async def _run_tool(
        self,
        tool_name: str,
        args: dict[str, Any],
        ctx: ToolContext,
    ) -> ToolResult:
        for tool in self._tools:
            if tool.def_().name == tool_name:
                return await tool.call(args, ctx)
        return ToolResult.error(f"unknown tool: {tool_name}")

    @staticmethod
    def _tool_result_to_message(result: ToolResult) -> str:
        parts: list[str] = []
        for item in result.content:
            if isinstance(item, dict):
                parts.append(json.dumps(item, ensure_ascii=False))
            else:
                parts.append(str(item))
        return "\n".join(parts)
