from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import AsyncIterator, Awaitable, Callable, Literal, Protocol, Self

from .history import (
    ConversationStore,
    HistoryConfig,
    HistoryMessage,
    HistoryRecord,
)

logger = logging.getLogger(__name__)


class Channel(Protocol):
    @property
    def name(self) -> str: ...

    async def listen(self) -> AsyncIterator["IncomingEvent"]: ...

    async def stream_chunk(self, user_id: str, chunk: str) -> None: ...

    async def stream_done(self, user_id: str) -> None: ...

    async def send(self, user_id: str, text: str) -> None: ...


@dataclass(slots=True)
class IncomingEvent:
    user_id: str
    content: str
    channel_name: str
    chat_type: Literal["dm", "group"] = "dm"


class Thread:
    def __init__(self, event: IncomingEvent, channel: Channel) -> None:
        self.event = event
        self.user_id = event.user_id
        self.channel = channel
        self._store: ConversationStore | None = None
        self._history_config: HistoryConfig = HistoryConfig()

    def with_history_store(
        self,
        store: ConversationStore,
        config: HistoryConfig | None = None,
    ) -> Thread:
        self._store = store
        if config:
            self._history_config = config
        return self

    async def history(self) -> list[HistoryMessage]:
        if not self._store:
            return []
        key = self._history_key()
        record = await self._store.load(key)
        if record is None:
            return []
        # TTL check
        if time.time() - record.updated_at_epoch_secs >= self._history_config.ttl_seconds:
            await self._store.clear(key)
            return []
        messages = record.messages
        self._compact_messages(messages)
        return messages

    async def save_turn(self, user: str, assistant: str) -> None:
        if not self._store:
            return
        key = self._history_key()
        record = await self._store.load(key) or HistoryRecord([])
        record.messages.append(HistoryMessage.user(user))
        record.messages.append(HistoryMessage.assistant(assistant))
        self._compact_messages(record.messages)
        record.updated_at_epoch_secs = time.time()
        await self._store.save(key, record)

    def _history_key(self) -> str:
        return f"history:{self.event.channel_name}:{self.event.user_id}"

    def _compact_messages(self, messages: list[HistoryMessage]) -> None:
        cfg = self._history_config
        if cfg.strategy == "none" or len(messages) <= cfg.max_messages:
            return
        start = len(messages) - cfg.keep_recent
        del messages[:start]

    async def stream_chunk(self, chunk: str) -> None:
        await self.channel.stream_chunk(self.user_id, chunk)

    async def stream_done(self) -> None:
        await self.channel.stream_done(self.user_id)

    async def send(self, text: str) -> None:
        await self.channel.send(self.user_id, text)


Handler = Callable[[Thread], Awaitable[None]]


class BotBuilder:
    def __init__(self) -> None:
        self._channel: Channel | None = None
        self._handler: Handler | None = None

    def channel(self, ch: Channel) -> Self:
        self._channel = ch
        return self

    def handler(self, fn: Handler) -> Self:
        self._handler = fn
        return self

    def build(self) -> "Bot":
        if self._channel is None:
            raise ValueError("channel is required")
        if self._handler is None:
            raise ValueError("handler is required")
        return Bot(channel=self._channel, handler=self._handler)


class Bot:
    def __init__(self, channel: Channel, handler: Handler) -> None:
        self._channel = channel
        self._handler = handler

    @classmethod
    def builder(cls) -> BotBuilder:
        return BotBuilder()

    async def run(self) -> None:
        tasks: set[asyncio.Task[None]] = set()
        async for event in self._channel.listen():
            thread = Thread(event=event, channel=self._channel)
            task = asyncio.create_task(self._safe_handle(thread))
            tasks.add(task)
            task.add_done_callback(tasks.discard)
        # Wait for remaining tasks on shutdown
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _safe_handle(self, thread: Thread) -> None:
        try:
            await self._handler(thread)
        except Exception:
            logger.exception("Handler error for user %s", thread.user_id)
