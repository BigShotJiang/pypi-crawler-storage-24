from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable

import pytest

from motosan_chat.channels.discord_ import DiscordChannel


class MockDiscordApi:
    def __init__(self) -> None:
        self.on_message: Callable[[str, str], Awaitable[None]] | None = None
        self.sent: list[tuple[str, str]] = []
        self.edited: list[tuple[str, str, str]] = []

    async def start(
        self,
        on_message: Callable[[str, str], Awaitable[None]],
    ) -> None:
        self.on_message = on_message

    async def send_message(self, user_id: str, text: str) -> str:
        self.sent.append((user_id, text))
        return "m1"

    async def edit_message(self, user_id: str, message_id: str, text: str) -> None:
        self.edited.append((user_id, message_id, text))

    async def emit(self, user_id: str, text: str) -> None:
        assert self.on_message is not None
        await self.on_message(user_id, text)


@pytest.mark.asyncio
async def test_discord_listen_maps_message_to_event() -> None:
    api = MockDiscordApi()
    channel = DiscordChannel(token="x", api=api)

    task = asyncio.create_task(channel.listen().__anext__())
    await asyncio.sleep(0)
    await api.emit("u1", "hello discord")

    event = await asyncio.wait_for(task, timeout=1)
    assert event.user_id == "u1"
    assert event.content == "hello discord"
    assert event.channel_name == "discord"


@pytest.mark.asyncio
async def test_discord_stream_chunk_send_then_edit() -> None:
    api = MockDiscordApi()
    channel = DiscordChannel(token="x", api=api)

    await channel.stream_chunk("u1", "A")
    await channel.stream_chunk("u1", "B")
    await channel.stream_done("u1")

    assert api.sent == [("u1", "A")]
    assert api.edited == [("u1", "m1", "AB")]


@pytest.mark.asyncio
async def test_discord_send_calls_api_send() -> None:
    api = MockDiscordApi()
    channel = DiscordChannel(token="x", api=api)

    await channel.send("u2", "direct")
    assert api.sent == [("u2", "direct")]
