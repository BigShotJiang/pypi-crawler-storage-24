from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json

import httpx
import pytest

from motosan_chat.channels.line import LineChannel


class MockLineApi:
    def __init__(self) -> None:
        self.pushed: list[tuple[str, str]] = []

    async def push_message(self, user_id: str, text: str) -> None:
        self.pushed.append((user_id, text))


def signed_body(secret: str, payload: dict) -> tuple[bytes, str]:
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    signature = base64.b64encode(
        hmac.new(secret.encode(), body, hashlib.sha256).digest()
    ).decode()
    return body, signature


@pytest.mark.asyncio
async def test_line_webhook_maps_text_message_to_event() -> None:
    secret = "secret"
    channel = LineChannel(secret, "token", api=MockLineApi())
    app = channel.app()
    transport = httpx.ASGITransport(app=app)

    payload = {
        "events": [
            {
                "type": "message",
                "source": {"userId": "u1"},
                "message": {"type": "text", "text": "hello line"},
            }
        ]
    }
    body, signature = signed_body(secret, payload)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/line/webhook",
            content=body,
            headers={"X-Line-Signature": signature, "Content-Type": "application/json"},
        )
        assert response.status_code == 200

    event = await asyncio.wait_for(channel.listen().__anext__(), timeout=1)
    assert event.user_id == "u1"
    assert event.content == "hello line"
    assert event.channel_name == "line"


@pytest.mark.asyncio
async def test_line_stream_chunk_accumulates_and_pushes() -> None:
    api = MockLineApi()
    channel = LineChannel("secret", "token", api=api)

    await channel.stream_chunk("u1", "A")
    await channel.stream_chunk("u1", "B")
    assert api.pushed == []

    await channel.stream_done("u1")
    await channel.send("u1", "final")

    assert api.pushed == [("u1", "AB"), ("u1", "final")]


@pytest.mark.asyncio
async def test_line_stream_done_with_empty_buffer_does_not_push() -> None:
    api = MockLineApi()
    channel = LineChannel("secret", "token", api=api)

    await channel.stream_done("u1")
    assert api.pushed == []


@pytest.mark.asyncio
async def test_line_webhook_rejects_missing_or_invalid_signature() -> None:
    secret = "secret"
    channel = LineChannel(secret, "token", api=MockLineApi())
    app = channel.app()
    transport = httpx.ASGITransport(app=app)

    payload = {
        "events": [
            {
                "type": "message",
                "source": {"userId": "u1"},
                "message": {"type": "text", "text": "hello line"},
            }
        ]
    }
    body, signature = signed_body(secret, payload)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        missing = await client.post(
            "/line/webhook",
            content=body,
            headers={"Content-Type": "application/json"},
        )
        assert missing.status_code == 400

        invalid = await client.post(
            "/line/webhook",
            content=body + b" ",
            headers={"X-Line-Signature": signature, "Content-Type": "application/json"},
        )
        assert invalid.status_code == 400
