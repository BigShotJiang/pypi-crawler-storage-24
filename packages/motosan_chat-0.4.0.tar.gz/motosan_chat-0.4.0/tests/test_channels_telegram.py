from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable

import pytest

from motosan_chat.channels.telegram import TelegramChannel


class MockTelegramApi:
    def __init__(self) -> None:
        self.on_text: Callable[[str, str], Awaitable[None]] | None = None
        self.sent: list[tuple[str, str]] = []
        self.edited: list[tuple[str, str, str]] = []

    async def start_polling(
        self,
        on_text_message: Callable[[str, str], Awaitable[None]],
    ) -> None:
        self.on_text = on_text_message

    async def send_message(self, user_id: str, text: str) -> str:
        self.sent.append((user_id, text))
        return "m1"

    async def edit_message_text(self, user_id: str, message_id: str, text: str) -> None:
        self.edited.append((user_id, message_id, text))

    async def emit(self, user_id: str, text: str) -> None:
        assert self.on_text is not None
        await self.on_text(user_id, text)


@pytest.mark.asyncio
async def test_telegram_listen_maps_text_to_incoming_event() -> None:
    api = MockTelegramApi()
    channel = TelegramChannel(token="tkn", api=api)

    event_task = asyncio.create_task(channel.listen().__anext__())
    await asyncio.sleep(0)
    await api.emit("u1", "hello tg")

    event = await asyncio.wait_for(event_task, timeout=1)
    assert event.user_id == "u1"
    assert event.content == "hello tg"
    assert event.channel_name == "telegram"


@pytest.mark.asyncio
async def test_telegram_stream_chunk_uses_send_then_edit_pattern() -> None:
    api = MockTelegramApi()
    channel = TelegramChannel(token="tkn", api=api)

    await channel.stream_chunk("u1", "Hel")
    await channel.stream_chunk("u1", "lo")
    await channel.stream_done("u1")

    assert api.sent == [("u1", "Hel")]
    assert api.edited == [("u1", "m1", "Hello")]


@pytest.mark.asyncio
async def test_telegram_send_calls_send_message() -> None:
    api = MockTelegramApi()
    channel = TelegramChannel(token="tkn", api=api)

    await channel.send("u2", "direct")
    assert api.sent == [("u2", "direct")]
