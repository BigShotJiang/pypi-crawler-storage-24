"""Tests for SubAgentTool concurrency limiting."""

from __future__ import annotations

import asyncio
from typing import Any, AsyncIterator

import pytest

from motosan_chat.agent import LlmResponse, Message, ToolCallItem, ToolDef
from motosan_chat.sub_agent import SubAgentTool
from motosan_chat.tool import ToolContext


class _SlowLlm:
    """Fake LLM that sleeps before replying, allowing us to observe concurrency."""

    def __init__(self, delay: float = 0.2) -> None:
        self._delay = delay
        self.concurrent = 0
        self.max_concurrent = 0
        self._lock = asyncio.Lock()

    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        async with self._lock:
            self.concurrent += 1
            if self.concurrent > self.max_concurrent:
                self.max_concurrent = self.concurrent
        try:
            await asyncio.sleep(self._delay)
            return LlmResponse.message("done")
        finally:
            async with self._lock:
                self.concurrent -= 1

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        yield "done"


@pytest.mark.asyncio
async def test_max_subagents_limits_concurrency() -> None:
    """With max_subagents=2 and 5 concurrent calls, only 2 should run at once."""
    llm = _SlowLlm(delay=0.3)
    tool = SubAgentTool(
        name="sub",
        description="test sub-agent",
        tools=[],
        llm=llm,
        max_subagents=2,
    )
    ctx = ToolContext(caller_id="u1", channel_name="test")

    # Fire 5 concurrent calls
    results = await asyncio.gather(*[
        tool.call({"query": f"task-{i}"}, ctx) for i in range(5)
    ])

    # All should succeed
    for r in results:
        assert r.is_error is False
        assert r.content == ["done"]

    # At most 2 should have been running simultaneously
    assert llm.max_concurrent <= 2


@pytest.mark.asyncio
async def test_default_max_subagents_is_five() -> None:
    """Default max_subagents should be 5."""
    llm = _SlowLlm(delay=0.1)
    tool = SubAgentTool(
        name="sub",
        description="test sub-agent",
        tools=[],
        llm=llm,
    )
    # Verify via the internal semaphore
    assert tool._semaphore._value == 5


@pytest.mark.asyncio
async def test_timeout_returns_error() -> None:
    """When semaphore acquisition + execution exceeds 30s, should return error."""

    class _HangingLlm:
        async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
            await asyncio.sleep(3600)  # hang forever
            return LlmResponse.message("never")

        async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
            yield "never"

    tool = SubAgentTool(
        name="sub",
        description="test sub-agent",
        tools=[],
        llm=_HangingLlm(),
        max_subagents=1,
    )
    ctx = ToolContext(caller_id="u1", channel_name="test")

    # Patch timeout to be short for the test
    import motosan_chat.sub_agent as mod
    original_call = tool.call

    async def short_timeout_call(args: dict[str, Any], ctx: ToolContext):
        """Override to use a shorter timeout for testing."""
        from motosan_chat.sub_agent import _make_stub_thread
        stub = _make_stub_thread(caller_id=ctx.caller_id, channel_name=ctx.channel_name)
        try:
            async with asyncio.timeout(0.1):  # very short timeout
                async with tool._semaphore:
                    result = await tool._loop.run(
                        tool._llm, stub, [Message.user(args.get("query", ""))]
                    )
                    from motosan_chat.tool import ToolResult
                    return ToolResult.text(result.answer)
        except TimeoutError:
            from motosan_chat.tool import ToolResult
            return ToolResult.error("subagent concurrency limit reached")
        except Exception as e:
            from motosan_chat.tool import ToolResult
            return ToolResult.error(str(e))

    result = await short_timeout_call({"query": "hang"}, ctx)
    assert result.is_error is True
    assert "concurrency limit" in result.content[0]
