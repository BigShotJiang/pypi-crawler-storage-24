from __future__ import annotations

import time
from collections.abc import AsyncIterator

import pytest

from motosan_chat.core import IncomingEvent, Thread
from motosan_chat.history import (
    HistoryConfig,
    HistoryMessage,
    HistoryRecord,
    InMemoryConversationStore,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _StubChannel:
    @property
    def name(self) -> str:
        return "stub"

    async def listen(self) -> AsyncIterator[IncomingEvent]:
        return  # type: ignore[return-value]
        yield  # pragma: no cover

    async def stream_chunk(self, user_id: str, chunk: str) -> None:
        pass

    async def stream_done(self, user_id: str) -> None:
        pass

    async def send(self, user_id: str, text: str) -> None:
        pass


def _make_thread(
    store: InMemoryConversationStore | None = None,
    config: HistoryConfig | None = None,
    user_id: str = "u1",
    channel_name: str = "general",
) -> Thread:
    event = IncomingEvent(user_id=user_id, content="hello", channel_name=channel_name)
    thread = Thread(event=event, channel=_StubChannel())
    if store is not None:
        thread.with_history_store(store, config)
    return thread


# ---------------------------------------------------------------------------
# HistoryMessage
# ---------------------------------------------------------------------------

class TestHistoryMessage:
    def test_user_factory(self) -> None:
        msg = HistoryMessage.user("hi")
        assert msg.role == "user"
        assert msg.content == "hi"

    def test_assistant_factory(self) -> None:
        msg = HistoryMessage.assistant("hello")
        assert msg.role == "assistant"
        assert msg.content == "hello"


# ---------------------------------------------------------------------------
# HistoryRecord
# ---------------------------------------------------------------------------

class TestHistoryRecord:
    def test_timestamp_set_on_init(self) -> None:
        before = time.time()
        record = HistoryRecord([])
        after = time.time()
        assert before <= record.updated_at_epoch_secs <= after


# ---------------------------------------------------------------------------
# InMemoryConversationStore
# ---------------------------------------------------------------------------

class TestInMemoryConversationStore:
    @pytest.mark.asyncio
    async def test_load_missing_returns_none(self) -> None:
        store = InMemoryConversationStore()
        assert await store.load("missing") is None

    @pytest.mark.asyncio
    async def test_save_and_load(self) -> None:
        store = InMemoryConversationStore()
        record = HistoryRecord([HistoryMessage.user("hi")])
        await store.save("k1", record)
        loaded = await store.load("k1")
        assert loaded is not None
        assert len(loaded.messages) == 1
        assert loaded.messages[0].content == "hi"

    @pytest.mark.asyncio
    async def test_clear(self) -> None:
        store = InMemoryConversationStore()
        await store.save("k1", HistoryRecord([]))
        await store.clear("k1")
        assert await store.load("k1") is None

    @pytest.mark.asyncio
    async def test_clear_missing_is_noop(self) -> None:
        store = InMemoryConversationStore()
        await store.clear("nope")  # should not raise


# ---------------------------------------------------------------------------
# Thread history integration
# ---------------------------------------------------------------------------

class TestThreadHistory:
    @pytest.mark.asyncio
    async def test_history_without_store_returns_empty(self) -> None:
        thread = _make_thread()
        assert await thread.history() == []

    @pytest.mark.asyncio
    async def test_save_turn_without_store_is_noop(self) -> None:
        thread = _make_thread()
        await thread.save_turn("hi", "hello")  # should not raise

    @pytest.mark.asyncio
    async def test_save_and_retrieve_turn(self) -> None:
        store = InMemoryConversationStore()
        thread = _make_thread(store=store)
        await thread.save_turn("hi", "hello")

        messages = await thread.history()
        assert len(messages) == 2
        assert messages[0] == HistoryMessage.user("hi")
        assert messages[1] == HistoryMessage.assistant("hello")

    @pytest.mark.asyncio
    async def test_multiple_turns(self) -> None:
        store = InMemoryConversationStore()
        thread = _make_thread(store=store)
        await thread.save_turn("a", "b")
        await thread.save_turn("c", "d")

        messages = await thread.history()
        assert len(messages) == 4
        assert [m.content for m in messages] == ["a", "b", "c", "d"]

    @pytest.mark.asyncio
    async def test_ttl_expiry(self) -> None:
        store = InMemoryConversationStore()
        config = HistoryConfig(ttl_seconds=1)
        thread = _make_thread(store=store, config=config)
        await thread.save_turn("hi", "hello")

        # Manually expire the record
        key = thread._history_key()
        record = await store.load(key)
        assert record is not None
        record.updated_at_epoch_secs = time.time() - 2

        messages = await thread.history()
        assert messages == []
        # Record should be cleared
        assert await store.load(key) is None

    @pytest.mark.asyncio
    async def test_compaction_truncate(self) -> None:
        store = InMemoryConversationStore()
        config = HistoryConfig(max_messages=6, keep_recent=4, strategy="truncate")
        thread = _make_thread(store=store, config=config)

        # Save 4 turns = 8 messages, exceeds max_messages=6
        for i in range(4):
            await thread.save_turn(f"u{i}", f"a{i}")

        messages = await thread.history()
        assert len(messages) == 4  # keep_recent
        assert messages[0].content == "u2"
        assert messages[-1].content == "a3"

    @pytest.mark.asyncio
    async def test_compaction_none_strategy(self) -> None:
        store = InMemoryConversationStore()
        config = HistoryConfig(max_messages=4, keep_recent=2, strategy="none")
        thread = _make_thread(store=store, config=config)

        for i in range(4):
            await thread.save_turn(f"u{i}", f"a{i}")

        messages = await thread.history()
        assert len(messages) == 8  # no compaction

    @pytest.mark.asyncio
    async def test_history_key_includes_channel_and_user(self) -> None:
        thread = _make_thread(user_id="bob", channel_name="sales")
        assert thread._history_key() == "history:sales:bob"

    @pytest.mark.asyncio
    async def test_with_history_store_returns_self(self) -> None:
        store = InMemoryConversationStore()
        thread = _make_thread()
        result = thread.with_history_store(store)
        assert result is thread
