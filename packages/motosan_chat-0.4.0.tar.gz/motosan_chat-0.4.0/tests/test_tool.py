from __future__ import annotations

import pytest

from motosan_chat.tool import ToolContext, ToolResult, tool


@tool(
    name="get_weather",
    description="Get weather",
    schema={
        "type": "object",
        "properties": {"city": {"type": "string"}},
        "required": ["city"],
    },
)
async def get_weather(args: dict, ctx: ToolContext) -> ToolResult:
    _ = ctx
    return ToolResult.text(f"Sunny in {args['city']}")


@pytest.mark.asyncio
async def test_tool_decorator_and_call() -> None:
    result = await get_weather.call({"city": "Taipei"}, ToolContext("u1", "web"))
    assert result.is_error is False
    assert result.content == ["Sunny in Taipei"]


def test_tool_def_validation_rejects_missing_required() -> None:
    with pytest.raises(ValueError):
        get_weather.def_().validate_args({})


def test_tool_result_helpers() -> None:
    assert ToolResult.text("ok").is_error is False
    assert ToolResult.json({"ok": True}).content == [{"ok": True}]
    assert ToolResult.error("bad").is_error is True
