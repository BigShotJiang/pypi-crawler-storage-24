from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator

import pytest

from motosan_chat.core import Bot, IncomingEvent


class MockChannel:
    def __init__(self, events: list[IncomingEvent]) -> None:
        self._events = events
        self.chunks: list[tuple[str, str]] = []
        self.done: list[str] = []
        self.sent: list[tuple[str, str]] = []

    @property
    def name(self) -> str:
        return "mock"

    async def listen(self) -> AsyncIterator[IncomingEvent]:
        for event in self._events:
            yield event

    async def stream_chunk(self, user_id: str, chunk: str) -> None:
        self.chunks.append((user_id, chunk))

    async def stream_done(self, user_id: str) -> None:
        self.done.append(user_id)

    async def send(self, user_id: str, text: str) -> None:
        self.sent.append((user_id, text))


@pytest.mark.asyncio
async def test_bot_dispatches_events_to_handler() -> None:
    channel = MockChannel(
        [
            IncomingEvent(user_id="u1", content="hi", channel_name="mock"),
            IncomingEvent(user_id="u2", content="yo", channel_name="mock"),
        ]
    )
    handled: list[str] = []

    async def handler(thread) -> None:  # type: ignore[no-untyped-def]
        handled.append(thread.event.content)
        await thread.send(f"echo:{thread.event.content}")

    bot = Bot.builder().channel(channel).handler(handler).build()
    await bot.run()

    assert handled == ["hi", "yo"]
    assert channel.sent == [("u1", "echo:hi"), ("u2", "echo:yo")]


@pytest.mark.asyncio
async def test_bot_run_handles_events_concurrently() -> None:
    """Two slow handlers should overlap — total time ~ 1x delay, not 2x."""
    channel = MockChannel(
        [
            IncomingEvent(user_id="u1", content="a", channel_name="mock"),
            IncomingEvent(user_id="u2", content="b", channel_name="mock"),
        ]
    )
    order: list[str] = []

    async def slow_handler(thread) -> None:  # type: ignore[no-untyped-def]
        order.append(f"start:{thread.user_id}")
        await asyncio.sleep(0.15)
        order.append(f"end:{thread.user_id}")
        await thread.send(f"done:{thread.user_id}")

    bot = Bot.builder().channel(channel).handler(slow_handler).build()
    t0 = asyncio.get_event_loop().time()
    await bot.run()
    elapsed = asyncio.get_event_loop().time() - t0

    # Both handlers started before either finished
    assert order.index("start:u1") < order.index("end:u1")
    assert order.index("start:u2") < order.index("end:u2")
    assert order.index("start:u2") < order.index("end:u1")

    # Total time should be ~0.15s (concurrent), not ~0.30s (sequential)
    assert elapsed < 0.25, f"Took {elapsed:.2f}s — handlers ran sequentially"

    assert set(channel.sent) == {("u1", "done:u1"), ("u2", "done:u2")}


@pytest.mark.asyncio
async def test_bot_run_logs_handler_exception(caplog: pytest.LogCaptureFixture) -> None:
    """A handler that raises should be logged, not crash the bot."""
    channel = MockChannel(
        [
            IncomingEvent(user_id="u1", content="boom", channel_name="mock"),
            IncomingEvent(user_id="u2", content="ok", channel_name="mock"),
        ]
    )

    async def failing_handler(thread) -> None:  # type: ignore[no-untyped-def]
        if thread.event.content == "boom":
            raise RuntimeError("kaboom")
        await thread.send("ok")

    bot = Bot.builder().channel(channel).handler(failing_handler).build()
    await bot.run()

    # u2 should still be handled despite u1 raising
    assert ("u2", "ok") in channel.sent
    assert "kaboom" in caplog.text


def test_bot_builder_requires_channel_and_handler() -> None:
    with pytest.raises(ValueError):
        Bot.builder().build()
