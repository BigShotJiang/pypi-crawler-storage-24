from __future__ import annotations

import asyncio

import httpx
import pytest

from motosan_chat.channels.web import WebChannel


@pytest.mark.asyncio
async def test_web_channel_http_post_enqueues_event() -> None:
    channel = WebChannel()
    app = channel.app()
    transport = httpx.ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.post("/chat", json={"user_id": "u1", "content": "hello"})
        assert resp.status_code == 200

    event = await asyncio.wait_for(channel.listen().__anext__(), timeout=1)
    assert event.user_id == "u1"
    assert event.content == "hello"
    assert event.channel_name == "web"


@pytest.mark.asyncio
async def test_web_channel_sse_stream_emits_chunks_and_done() -> None:
    channel = WebChannel()
    app = channel.app()
    transport = httpx.ASGITransport(app=app)

    async def produce() -> None:
        await asyncio.sleep(0.05)
        await channel.stream_chunk("u1", "A")
        await channel.stream_chunk("u1", "B")
        await channel.stream_done("u1")

    producer = asyncio.create_task(produce())
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        async with client.stream("GET", "/chat/u1/stream") as response:
            body = ""
            async for line in response.aiter_lines():
                body += line
                if "event: done" in body:
                    break

    await producer
    assert "event: chunk" in body
    assert "data: A" in body
    assert "data: B" in body
    assert "event: done" in body
