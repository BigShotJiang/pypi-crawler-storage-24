from __future__ import annotations

from collections.abc import AsyncIterator

import pytest

from motosan_chat.agent import AgentLoop, LlmResponse, Message, StreamChunk, ToolCallItem
from motosan_chat.core import IncomingEvent, Thread
from motosan_chat.sub_agent import SubAgentTool
from motosan_chat.tool import ToolContext, ToolDef, ToolResult, tool


class DummyChannel:
    @property
    def name(self) -> str:
        return "web"

    async def listen(self) -> AsyncIterator[IncomingEvent]:
        if False:
            yield IncomingEvent(user_id="", content="", channel_name="web")

    async def stream_chunk(self, user_id: str, chunk: str) -> None:
        _ = (user_id, chunk)

    async def stream_done(self, user_id: str) -> None:
        _ = user_id

    async def send(self, user_id: str, text: str) -> None:
        _ = (user_id, text)


class EchoTool:
    def def_(self) -> ToolDef:
        return ToolDef(name="echo", description="echo", schema={"type": "object"})

    async def call(self, args: dict, ctx: ToolContext) -> ToolResult:
        _ = ctx
        return ToolResult.text(f"echo:{args['value']}")


class MockLlm:
    def __init__(self) -> None:
        self.calls = 0
        self.snapshots: list[list[Message]] = []

    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        _ = tools
        self.snapshots.append(list(messages))
        self.calls += 1
        if self.calls == 1:
            return LlmResponse.tool_call("call-1", "echo", {"value": "hi"})
        return LlmResponse.message("done")

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        _ = messages
        if False:
            yield ""


@pytest.mark.asyncio
async def test_agent_loop_multi_turn_tool_chain() -> None:
    loop_ = AgentLoop(tools=[EchoTool()])
    llm = MockLlm()
    thread = Thread(IncomingEvent("u1", "hello", "web"), DummyChannel())

    result = await loop_.run(llm, thread, [Message.user("hello")])

    assert result.answer == "done"
    assert result.iterations == 2

    second_call_messages = llm.snapshots[1]
    assistant_tool = [m for m in second_call_messages if m.role == "assistant" and m.tool_calls]
    tool_result = [m for m in second_call_messages if m.role == "tool"]

    assert assistant_tool[0].tool_calls[0].id == "call-1"
    assert tool_result[0].tool_call_id == "call-1"


class NeverEndingLlm:
    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        _ = (messages, tools)
        return LlmResponse.tool_call("x", "missing", {})

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        _ = messages
        if False:
            yield ""


@pytest.mark.asyncio
async def test_agent_loop_max_iterations_guard() -> None:
    loop_ = AgentLoop(tools=[], max_iterations=2)
    thread = Thread(IncomingEvent("u1", "hello", "web"), DummyChannel())

    with pytest.raises(RuntimeError, match="max iterations"):
        await loop_.run(NeverEndingLlm(), thread, [Message.user("hello")])


class SequenceLlm:
    """MockLlm that returns a predefined sequence of responses."""

    def __init__(self, responses: list[LlmResponse]) -> None:
        self._responses = list(responses)
        self._index = 0

    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        _ = (messages, tools)
        response = self._responses[self._index]
        self._index += 1
        return response

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        _ = messages
        if False:
            yield ""


def mock_thread() -> Thread:
    return Thread(IncomingEvent("u1", "test", "web"), DummyChannel())


@pytest.mark.asyncio
async def test_agent_loop_parallel_tool_calls() -> None:
    """When LLM returns tool_calls (batch), all tools execute in parallel."""
    call_order: list[str] = []

    @tool(name="tool_a", description="A", schema={"type": "object", "properties": {}})
    async def tool_a(args: dict, ctx: ToolContext) -> ToolResult:
        call_order.append("a")
        return ToolResult.text("result_a")

    @tool(name="tool_b", description="B", schema={"type": "object", "properties": {}})
    async def tool_b(args: dict, ctx: ToolContext) -> ToolResult:
        call_order.append("b")
        return ToolResult.text("result_b")

    seq_llm = SequenceLlm([
        LlmResponse.tool_calls([
            ToolCallItem(id="1", name="tool_a", args={}),
            ToolCallItem(id="2", name="tool_b", args={}),
        ]),
        LlmResponse.message("done"),
    ])

    loop_ = AgentLoop(tools=[tool_a, tool_b])
    result = await loop_.run(seq_llm, mock_thread(), [Message.user("test")])

    assert result.answer == "done"
    assert len(result.tool_calls) == 2
    assert set(call_order) == {"a", "b"}


# ---------------------------------------------------------------------------
# SubAgentTool tests
# ---------------------------------------------------------------------------


class InnerEchoTool:
    """Simple echo tool for inner agent."""

    def def_(self) -> ToolDef:
        return ToolDef(
            name="inner_echo",
            description="echo the query back",
            schema={
                "type": "object",
                "properties": {"text": {"type": "string"}},
                "required": ["text"],
            },
        )

    async def call(self, args: dict, ctx: ToolContext) -> ToolResult:
        _ = ctx
        return ToolResult.text(f"echoed:{args.get('text', '')}")


class InnerMockLlm:
    """Mock LLM that calls inner_echo then returns a final message."""

    def __init__(self) -> None:
        self.calls = 0

    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        _ = tools
        self.calls += 1
        if self.calls == 1:
            # Extract query from user message
            query = next((m.content for m in reversed(messages) if m.role == "user"), "")
            return LlmResponse.tool_call("ic-1", "inner_echo", {"text": query})
        return LlmResponse.message("inner result")

    async def stream(self, messages: list[Message]):  # type: ignore[override]
        _ = messages
        if False:
            yield ""


@pytest.mark.asyncio
async def test_sub_agent_tool_returns_result() -> None:
    """SubAgentTool runs inner agent and returns result without error."""
    inner_llm = InnerMockLlm()
    sub_tool = SubAgentTool(
        name="search",
        description="Search for info",
        tools=[InnerEchoTool()],
        llm=inner_llm,
        max_iterations=3,
    )

    ctx = ToolContext(caller_id="user1", channel_name="test")
    result = await sub_tool.call({"query": "find something"}, ctx)

    assert not result.is_error
    assert "inner result" in result.content[0]


@pytest.mark.asyncio
async def test_sub_agent_tool_def_has_query_schema() -> None:
    """SubAgentTool exposes a ToolDef with the expected name and schema."""

    class SimpleLlm:
        async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
            return LlmResponse.message("ok")

        async def stream(self, messages: list[Message]):  # type: ignore[override]
            if False:
                yield ""

    sub_tool = SubAgentTool(
        name="my_agent",
        description="A sub-agent",
        tools=[],
        llm=SimpleLlm(),
    )
    defn = sub_tool.def_()
    assert defn.name == "my_agent"
    assert "query" in defn.schema["properties"]
    assert "query" in defn.schema["required"]


@pytest.mark.asyncio
async def test_sub_agent_tool_returns_error_on_exception() -> None:
    """SubAgentTool returns ToolResult.error when inner loop raises."""

    class BrokenLlm:
        async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
            raise RuntimeError("llm exploded")

        async def stream(self, messages: list[Message]):  # type: ignore[override]
            if False:
                yield ""

    sub_tool = SubAgentTool(
        name="broken",
        description="will fail",
        tools=[],
        llm=BrokenLlm(),
        max_iterations=1,
    )

    ctx = ToolContext(caller_id="u1", channel_name="ch")
    result = await sub_tool.call({"query": "do something"}, ctx)

    assert result.is_error
    assert "llm exploded" in result.content[0]


# ---------------------------------------------------------------------------
# StreamChunk tests
# ---------------------------------------------------------------------------


class TestStreamChunk:
    def test_text_chunk(self) -> None:
        chunk = StreamChunk(kind="text", content="hello")
        assert chunk.kind == "text"
        assert chunk.content == "hello"
        assert chunk.tool_id == ""
        assert chunk.tool_name == ""

    def test_tool_call_start_chunk(self) -> None:
        chunk = StreamChunk(kind="tool_call_start", tool_id="tc-1", tool_name="echo")
        assert chunk.kind == "tool_call_start"
        assert chunk.tool_id == "tc-1"
        assert chunk.tool_name == "echo"

    def test_tool_call_args_chunk(self) -> None:
        chunk = StreamChunk(kind="tool_call_args", content='{"value":', tool_id="tc-1")
        assert chunk.kind == "tool_call_args"
        assert chunk.content == '{"value":'

    def test_tool_call_end_chunk(self) -> None:
        chunk = StreamChunk(kind="tool_call_end", tool_id="tc-1")
        assert chunk.kind == "tool_call_end"


# ---------------------------------------------------------------------------
# AgentLoop streaming tool call tests
# ---------------------------------------------------------------------------


class StreamingLlm:
    """Mock LLM that supports stream_with_tools, returning a tool call then a message."""

    def __init__(self) -> None:
        self.calls = 0

    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        # Should not be called when stream_with_tools is available
        raise AssertionError("chat() should not be called when stream_with_tools works")

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        _ = messages
        if False:
            yield ""

    async def stream_with_tools(
        self,
        messages: list[Message],
        tools: list[ToolDef],
    ) -> AsyncIterator[StreamChunk]:
        self.calls += 1
        if self.calls == 1:
            # First call: stream a tool call
            async def _gen() -> AsyncIterator[StreamChunk]:
                yield StreamChunk(kind="text", content="Let me ")
                yield StreamChunk(kind="text", content="check.")
                yield StreamChunk(kind="tool_call_start", tool_id="tc-1", tool_name="echo")
                yield StreamChunk(kind="tool_call_args", content='{"value"', tool_id="tc-1")
                yield StreamChunk(kind="tool_call_args", content=': "hi"}', tool_id="tc-1")
                yield StreamChunk(kind="tool_call_end", tool_id="tc-1")
            return _gen()
        else:
            # Second call: just text
            async def _gen2() -> AsyncIterator[StreamChunk]:
                yield StreamChunk(kind="text", content="done")
            return _gen2()


@pytest.mark.asyncio
async def test_agent_loop_stream_with_tools() -> None:
    """AgentLoop uses stream_with_tools when available."""
    loop_ = AgentLoop(tools=[EchoTool()])
    llm = StreamingLlm()
    thread = Thread(IncomingEvent("u1", "hello", "web"), DummyChannel())

    result = await loop_.run(llm, thread, [Message.user("hello")])

    assert result.answer == "done"
    assert result.iterations == 2
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0] == ("echo", {"value": "hi"})


class StreamingMultiToolLlm:
    """Mock LLM streaming multiple tool calls in one response."""

    def __init__(self) -> None:
        self.calls = 0

    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        raise AssertionError("chat() should not be called")

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        if False:
            yield ""

    async def stream_with_tools(
        self,
        messages: list[Message],
        tools: list[ToolDef],
    ) -> AsyncIterator[StreamChunk]:
        self.calls += 1
        if self.calls == 1:
            async def _gen() -> AsyncIterator[StreamChunk]:
                yield StreamChunk(kind="tool_call_start", tool_id="tc-1", tool_name="tool_a")
                yield StreamChunk(kind="tool_call_args", content="{}", tool_id="tc-1")
                yield StreamChunk(kind="tool_call_end", tool_id="tc-1")
                yield StreamChunk(kind="tool_call_start", tool_id="tc-2", tool_name="tool_b")
                yield StreamChunk(kind="tool_call_args", content="{}", tool_id="tc-2")
                yield StreamChunk(kind="tool_call_end", tool_id="tc-2")
            return _gen()
        else:
            async def _gen2() -> AsyncIterator[StreamChunk]:
                yield StreamChunk(kind="text", content="all done")
            return _gen2()


@pytest.mark.asyncio
async def test_agent_loop_stream_with_tools_multi() -> None:
    """AgentLoop handles multiple streamed tool calls."""

    @tool(name="tool_a", description="A", schema={"type": "object", "properties": {}})
    async def tool_a(args: dict, ctx: ToolContext) -> ToolResult:
        return ToolResult.text("result_a")

    @tool(name="tool_b", description="B", schema={"type": "object", "properties": {}})
    async def tool_b(args: dict, ctx: ToolContext) -> ToolResult:
        return ToolResult.text("result_b")

    loop_ = AgentLoop(tools=[tool_a, tool_b])
    llm = StreamingMultiToolLlm()
    thread = mock_thread()

    result = await loop_.run(llm, thread, [Message.user("test")])

    assert result.answer == "all done"
    assert len(result.tool_calls) == 2


class NoStreamLlm:
    """Mock LLM without stream_with_tools — should fall back to chat()."""

    def __init__(self) -> None:
        self.calls = 0

    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        self.calls += 1
        return LlmResponse.message("from chat")

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        if False:
            yield ""


@pytest.mark.asyncio
async def test_agent_loop_fallback_to_chat() -> None:
    """AgentLoop falls back to chat() when stream_with_tools is not available."""
    loop_ = AgentLoop(tools=[])
    llm = NoStreamLlm()
    thread = mock_thread()

    result = await loop_.run(llm, thread, [Message.user("test")])

    assert result.answer == "from chat"
    assert llm.calls == 1
