# Changelog

## 0.1.0 (2026-03-13)

- Initial release
- `format_table()` for string output
- `table()` for quick printing
- Dict list and headers+rows input modes
- Column alignment (left, right, center)
- Cell truncation with max_width
- Border styles: simple, markdown, none
