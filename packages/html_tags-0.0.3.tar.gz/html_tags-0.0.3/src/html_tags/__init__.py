"""concise html tag generation"""
__version__ = '0.0.3'
__author__ = 'Deufel'
from .core import attrmap, render_attrs, is_void, is_raw, tag, to_html, mktag, TagNS
__all__ = [
    "TagNS",
    "attrmap",
    "is_raw",
    "is_void",
    "mktag",
    "render_attrs",
    "tag",
    "to_html",
]
