from collections import namedtuple
from html import escape

VOID_TAGS = frozenset({'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'source', 'track', 'wbr'})
RAW_TAGS = frozenset({'script', 'style'})
Tag = namedtuple('Tag', 'tag children attrs', defaults=((), {}))
_attr_map = dict(cls='class', klass='class', _class='class', _for='for', fr='for')

def attrmap(k): return _attr_map.get(k, k.lstrip('_').replace('_', '-'))

def render_attrs(d):
    parts = []
    for k,v in d.items():
        k = attrmap(k)
        if v is True: parts.append(f' {k}')
        elif v not in (False, None): parts.append(f' {k}="{v}"')
    return ''.join(parts)

def is_void(t): return t.tag in VOID_TAGS

def is_raw(t): return t.tag in RAW_TAGS

def tag(name, *c, **kw):
    children = tuple(o for o in c if not isinstance(o, dict))
    attrs = {k:v for o in c if isinstance(o, dict) for k,v in o.items()}
    return Tag(name, children, {**attrs, **kw})

def to_html(t, raw=False):
    if isinstance(t, str): return t if raw else escape(t)
    attrs = render_attrs(t.attrs)
    if is_void(t): return f'<{t.tag}{attrs}>'
    inner = ''.join(to_html(c, raw=is_raw(t)) for c in t.children)
    return f'<{t.tag}{attrs}>{inner}</{t.tag}>'

def mktag(name):
    def f(*c, **kw): return tag(name, *c, **kw)
    f.__name__ = name.capitalize()
    return f

class TagNS:
    def __getattr__(self, name): return mktag(name.lower())
    def export(self, *names): return [getattr(self, n) for n in names]
