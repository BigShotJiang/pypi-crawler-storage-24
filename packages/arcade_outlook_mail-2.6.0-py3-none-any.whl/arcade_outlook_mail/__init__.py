from arcade_outlook_mail.tools import (
    create_and_send_email,
    create_draft_email,
    get_email,
    list_email_attachments,
    list_emails,
    list_emails_by_property,
    list_emails_in_folder,
    list_mail_folders,
    reply_to_email,
    search_emails,
    send_draft_email,
    update_draft_email,
    who_am_i,
)

__all__ = [
    # Read
    "get_email",
    "list_emails",
    "list_emails_by_property",
    "list_emails_in_folder",
    "list_email_attachments",
    "list_mail_folders",
    "search_emails",
    # Send
    "create_and_send_email",
    "send_draft_email",
    "reply_to_email",
    # Write
    "create_draft_email",
    "update_draft_email",
    # System
    "who_am_i",
]
