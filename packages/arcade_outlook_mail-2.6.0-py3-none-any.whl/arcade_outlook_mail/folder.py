from dataclasses import dataclass
from typing import Any


@dataclass
class MailFolderInfo:
    folder_id: str
    display_name: str
    parent_folder_id: str | None
    sub_folder_count: int
    total_email_messages_count: int
    unread_email_messages_count: int
    is_hidden: bool

    @classmethod
    def from_sdk(cls, folder: Any) -> "MailFolderInfo":
        return cls(
            folder_id=folder.id or "",
            display_name=folder.display_name or "",
            parent_folder_id=folder.parent_folder_id,
            sub_folder_count=folder.child_folder_count or 0,
            total_email_messages_count=folder.total_item_count or 0,
            unread_email_messages_count=folder.unread_item_count or 0,
            is_hidden=folder.is_hidden or False,
        )

    def to_dict(self, include_hidden_field: bool = False) -> dict:
        result = {
            "folder_id": self.folder_id,
            "display_name": self.display_name,
            "parent_folder_id": self.parent_folder_id,
            "sub_folders": {
                "has_sub_folders": self.sub_folder_count > 0,
                "total_count": self.sub_folder_count,
            },
            "total_email_messages_count": self.total_email_messages_count,
            "unread_email_messages_count": self.unread_email_messages_count,
        }
        if include_hidden_field:
            result["is_hidden"] = self.is_hidden
        return result
