from dataclasses import dataclass
from typing import Any

ATTACHMENT_TYPE_MAP = {
    "microsoft.graph.fileattachment": "file",
    "microsoft.graph.itemattachment": "item",
    "microsoft.graph.referenceattachment": "reference",
}

ALLOWED_FIELDS = frozenset({
    "attachment_id",
    "name",
    "size",
    "content_type",
    "is_inline",
    "attachment_type",
    "last_modified_date_time",
})


def _format_size(size_bytes: int) -> str:
    """Format a byte count into a human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} bytes"
    if size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KiB"
    if size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MiB"
    return f"{size_bytes / (1024 * 1024 * 1024):.1f} GiB"


def _normalize_odata_type(raw: str) -> str:
    """Normalize an @odata.type value for consistent lookup.

    Strips the optional leading '#' and lowercases to handle both
    '#microsoft.graph.fileAttachment' and 'microsoft.graph.fileAttachment'.
    """
    return raw.lstrip("#").lower()


@dataclass
class Attachment:
    """Metadata for an email attachment. Content is never included."""

    attachment_id: str = ""
    name: str = ""
    size: str = ""
    content_type: str = ""
    is_inline: bool = False
    attachment_type: str = ""
    last_modified_date_time: str = ""

    @classmethod
    def from_sdk(cls, attachment: Any) -> "Attachment":
        """Convert a Microsoft Graph SDK Attachment object to an Attachment dataclass.

        Uses an allowlist to ensure only approved metadata fields are extracted.
        contentBytes and other content fields are never accessed.
        """
        raw_odata = getattr(attachment, "odata_type", "") or ""
        raw_size = getattr(attachment, "size", 0) or 0
        return cls(
            attachment_id=getattr(attachment, "id", "") or "",
            name=getattr(attachment, "name", "") or "",
            size=_format_size(raw_size),
            content_type=getattr(attachment, "content_type", "") or "",
            is_inline=bool(getattr(attachment, "is_inline", False)),
            attachment_type=ATTACHMENT_TYPE_MAP.get(_normalize_odata_type(raw_odata), ""),
            last_modified_date_time=(
                attachment.last_modified_date_time.isoformat()
                if getattr(attachment, "last_modified_date_time", None)
                else ""
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to a dictionary. Only fields in the allowlist are included."""
        data = {
            "attachment_id": self.attachment_id,
            "name": self.name,
            "size": self.size,
            "content_type": self.content_type,
            "is_inline": self.is_inline,
            "attachment_type": self.attachment_type,
            "last_modified_date_time": self.last_modified_date_time,
        }
        if not set(data.keys()) <= ALLOWED_FIELDS:
            extra = set(data.keys()) - ALLOWED_FIELDS
            raise ValueError(f"Disallowed fields in output: {extra}")
        return data
