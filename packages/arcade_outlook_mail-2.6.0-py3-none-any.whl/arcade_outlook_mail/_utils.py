from typing import NoReturn

from arcade_mcp_server import Context
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_microsoft_utils.utils import validate_pagination_url
from kiota_abstractions.api_error import APIError
from msgraph.generated.models.message_collection_response import MessageCollectionResponse
from msgraph.generated.users.item.mail_folders.item.child_folders.child_folders_request_builder import (  # noqa: E501
    ChildFoldersRequestBuilder,
)
from msgraph.generated.users.item.mail_folders.item.messages.messages_request_builder import (
    MessagesRequestBuilder as MailFolderMessagesRequestBuilder,
)
from msgraph.generated.users.item.mail_folders.mail_folders_request_builder import (
    MailFoldersRequestBuilder,
)
from msgraph.generated.users.item.messages.item.attachments.attachments_request_builder import (
    AttachmentsRequestBuilder,
)
from msgraph.generated.users.item.messages.item.message_item_request_builder import (
    MessageItemRequestBuilder,
)
from msgraph.generated.users.item.messages.item.reply.reply_post_request_body import (
    ReplyPostRequestBody,
)
from msgraph.generated.users.item.messages.item.reply_all.reply_all_post_request_body import (
    ReplyAllPostRequestBody,
)
from msgraph.generated.users.item.messages.messages_request_builder import (
    MessagesRequestBuilder as UserMessagesRequestBuilder,
)

from arcade_outlook_mail.client import get_client
from arcade_outlook_mail.constants import DEFAULT_MESSAGE_FIELDS
from arcade_outlook_mail.enums import (
    EmailFilterProperty,
    EmailSortProperty,
    FilterOperator,
    ReplyType,
    SortOrder,
)


def remove_none_values(data: dict) -> dict:
    """Remove all keys with None values from the dictionary."""
    return {k: v for k, v in data.items() if v is not None}


_SORT_PROPERTY_DUMMY_CLAUSES: dict[EmailSortProperty, str] = {
    EmailSortProperty.RECEIVED_DATE_TIME: "receivedDateTime ge 1900-01-01T00:00:00Z",
    EmailSortProperty.SUBJECT: "subject ne null",
    EmailSortProperty.SENDER: "from/emailAddress/address ne null",
    EmailSortProperty.IMPORTANCE: "importance ne null",
}


def _create_filter_expression(
    property_: EmailFilterProperty | None = None,
    operator: FilterOperator | None = None,
    value: str | None = None,
    sort_by: EmailSortProperty = EmailSortProperty.RECEIVED_DATE_TIME,
) -> str | None:
    if property_ and operator and value:
        property_value = property_.value

        # Workaround: flag/flagStatus eq 'notFlagged' may return empty results
        # due to null handling in Exchange. Rewrite to ne-based compound filter.
        # See: https://stackoverflow.com/questions/54132940
        if (
            property_ == EmailFilterProperty.FLAG_STATUS
            and operator == FilterOperator.EQUAL
            and value == "notFlagged"
        ):
            filter_expr = "flag/flagStatus ne 'flagged' and flag/flagStatus ne 'complete'"
        else:
            # Never use quotes around 'value' for booleans and numerics
            value_quote = "'"
            if value.lower() in ["true", "false"] or value.isdigit():
                value_quote = ""

            if operator.is_function():
                filter_expr = (
                    f"{operator.value}({property_value}, {value_quote}{value}{value_quote})"
                )
            else:
                filter_expr = f"{property_value} {operator.value} {value_quote}{value}{value_quote}"

        # Ensure sort property's OData path is in $filter (Graph API constraint).
        # Note: SENDER sort (from/emailAddress/address) never matches SENDER filter
        # (sender/emailAddress/address) — the dummy clause is always added in that case.
        if sort_by.to_api_value() != property_value:
            dummy = _SORT_PROPERTY_DUMMY_CLAUSES[sort_by]
            filter_expr = f"{dummy} and {filter_expr}"

        return filter_expr

    return None


def prepare_list_emails_request_config(
    limit: int,
    property_: EmailFilterProperty | None = None,
    operator: FilterOperator | None = None,
    value: str | None = None,
    sort_by: EmailSortProperty = EmailSortProperty.RECEIVED_DATE_TIME,
    sort_order: SortOrder = SortOrder.DESCENDING,
) -> MailFolderMessagesRequestBuilder.MessagesRequestBuilderGetRequestConfiguration:
    """Prepare a request configuration for listing emails."""
    limit = max(1, min(limit, 100))

    orderby = [f"{sort_by.to_api_value()} {sort_order.to_api_value()}"]
    filter_expr = _create_filter_expression(property_, operator, value, sort_by=sort_by)

    query_params = MailFolderMessagesRequestBuilder.MessagesRequestBuilderGetQueryParameters(
        count=True,
        select=DEFAULT_MESSAGE_FIELDS,
        orderby=orderby,
        filter=filter_expr,
        top=limit,
    )
    return MailFolderMessagesRequestBuilder.MessagesRequestBuilderGetRequestConfiguration(
        query_parameters=query_params,
    )


async def fetch_emails(
    message_builder: MailFolderMessagesRequestBuilder | UserMessagesRequestBuilder,
    pagination_token: str | None = None,
    request_config: MailFolderMessagesRequestBuilder.MessagesRequestBuilderGetRequestConfiguration
    | None = None,
) -> MessageCollectionResponse:
    """Fetch emails from the user's mailbox.

    Microsoft Graph Python SDK does not support pagination (as of 2025-04-17),
    so we use raw URL for pagination if a pagination token is provided.
    """
    if pagination_token:
        validate_pagination_url(pagination_token)
        return await message_builder.with_url(pagination_token).get()  # type: ignore[return-value]
    return await message_builder.get(request_configuration=request_config)  # type: ignore[return-value, arg-type]


def raise_sort_filter_error(
    error: APIError,
    sort_by: EmailSortProperty,
    filter_property: EmailFilterProperty | None,
) -> NoReturn:
    """Raise a ToolExecutionError with actionable guidance if the Graph API
    rejects the $filter + $orderby combination.

    Re-raises the original error if it is not an InefficientFilter.
    """
    odata_code = getattr(getattr(error, "error", None), "code", None)
    if odata_code != "InefficientFilter":
        raise error

    sort_label = sort_by.name
    if filter_property is not None:
        filter_label = filter_property.name
        raise ToolExecutionError(
            message=(
                f"Cannot sort by {sort_label} while filtering by {filter_label}. "
                f"The Microsoft Graph API requires the sort property to be compatible "
                f"with the filter expression. "
                f"To fix this, either: "
                f"(1) set sort_by to RECEIVED_DATE_TIME, which works with any filter; "
                f"(2) call list_emails with sort_by={sort_label} instead "
                f"(no filter, no constraint); or "
                f"(3) filter by the same property you are sorting by."
            ),
        ) from error
    else:
        raise ToolExecutionError(
            message=(
                f"Cannot sort by {sort_label}. "
                f"The Microsoft Graph API rejected this sort configuration. "
                f"Try sort_by=RECEIVED_DATE_TIME instead."
            ),
        ) from error


DEFAULT_ATTACHMENT_FIELDS = [
    "id",
    "name",
    "size",
    "contentType",
    "isInline",
    "lastModifiedDateTime",
]


def prepare_list_attachments_request_config(
    limit: int,
) -> AttachmentsRequestBuilder.AttachmentsRequestBuilderGetRequestConfiguration:
    """Prepare a request configuration for listing attachments.

    Restricts $select to metadata-only fields — contentBytes is never requested.
    """
    limit = max(1, min(limit, 100))

    query_params = AttachmentsRequestBuilder.AttachmentsRequestBuilderGetQueryParameters(
        select=DEFAULT_ATTACHMENT_FIELDS,
        top=limit,
    )
    return AttachmentsRequestBuilder.AttachmentsRequestBuilderGetRequestConfiguration(
        query_parameters=query_params,
    )


_KQL_SPECIAL_CHARS = str.maketrans({
    '"': '\\"',
    "\\": "\\\\",
    ":": "\\:",
    "(": "\\(",
    ")": "\\)",
})


def _normalize_to_list(value: str | list[str] | None) -> list[str]:
    """Convert str | list[str] | None to a list[str].

    Accepts str for internal callers even though the tool interface uses list[str] | None.
    """
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    return value


def _escape_kql_value(value: str) -> str:
    """Escape KQL special characters in a value."""
    return value.translate(_KQL_SPECIAL_CHARS)


def _quote_if_needed(value: str) -> str:
    """Wrap value in double quotes if it contains spaces."""
    if " " in value:
        return f'"{value}"'
    return value


def _prepare_value(value: str) -> str:
    """Escape special characters and quote if needed."""
    return _quote_if_needed(_escape_kql_value(value))


def _build_or_clause(prefix: str, values: list[str]) -> str:
    """Build an OR-joined clause for a KQL property.

    Single value:  from:sarah@co.com
    Multi value:   (from:alice@co.com OR from:bob@co.com)
    """
    terms = [f"{prefix}:{_prepare_value(v)}" for v in values]
    if len(terms) == 1:
        return terms[0]
    return f"({' OR '.join(terms)})"


def _append_scalar_filters(
    parts: list[str],
    *,
    has_attachments: bool | None,
    importance: str | None,
    is_read: bool | None,
    category: str | None,
    received_after: str | None,
    received_before: str | None,
) -> None:
    """Append scalar KQL filter clauses to *parts* in-place."""
    if has_attachments is not None:
        parts.append(f"hasAttachment:{str(has_attachments).lower()}")
    if importance is not None:
        parts.append(f"importance:{importance}")
    if is_read is not None:
        parts.append(f"isRead:{str(is_read).lower()}")
    if category is not None:
        parts.append(f"category:{_prepare_value(category)}")
    if received_after is not None:
        parts.append(f"received>={received_after}")
    if received_before is not None:
        parts.append(f"received<={received_before}")


def build_search_query(
    *,
    keywords: str | list[str] | None = None,
    sender: str | list[str] | None = None,
    recipient: str | list[str] | None = None,
    attachment_name: str | list[str] | None = None,
    has_attachments: bool | None = None,
    importance: str | None = None,
    is_read: bool | None = None,
    category: str | None = None,
    received_after: str | None = None,
    received_before: str | None = None,
) -> str:
    """Assemble structured search parameters into a KQL query string.

    Cross-parameter join is AND. Within a parameter: keywords use AND,
    while sender, recipient, and attachment_name use OR.
    """
    parts: list[str] = []

    kw_list = _normalize_to_list(keywords)
    if kw_list:
        parts.extend(_prepare_value(kw) for kw in kw_list)

    for prefix, values in [("from", sender), ("to", recipient), ("attachment", attachment_name)]:
        items = _normalize_to_list(values)
        if items:
            parts.append(_build_or_clause(prefix, items))

    _append_scalar_filters(
        parts,
        has_attachments=has_attachments,
        importance=importance,
        is_read=is_read,
        category=category,
        received_after=received_after,
        received_before=received_before,
    )

    return " AND ".join(parts)


def prepare_search_emails_request_config(
    query: str,
    limit: int,
) -> UserMessagesRequestBuilder.MessagesRequestBuilderGetRequestConfiguration:
    """Prepare a request configuration for searching emails.

    Uses $search for full-text/KQL search. $orderby is intentionally omitted —
    the Graph API does not support $orderby with $search on messages.
    """
    limit = max(1, min(limit, 25))

    query_params = UserMessagesRequestBuilder.MessagesRequestBuilderGetQueryParameters(
        search=f'"{query}"',
        select=DEFAULT_MESSAGE_FIELDS,
        top=limit,
    )
    return UserMessagesRequestBuilder.MessagesRequestBuilderGetRequestConfiguration(
        query_parameters=query_params,
    )


def prepare_get_email_request_config() -> (
    MessageItemRequestBuilder.MessageItemRequestBuilderGetRequestConfiguration
):
    """Prepare a request configuration for retrieving a single email by ID."""
    query_params = MessageItemRequestBuilder.MessageItemRequestBuilderGetQueryParameters(
        select=DEFAULT_MESSAGE_FIELDS,
    )
    return MessageItemRequestBuilder.MessageItemRequestBuilderGetRequestConfiguration(
        query_parameters=query_params,
    )


DEFAULT_FOLDER_FIELDS = [
    "id",
    "displayName",
    "parentFolderId",
    "childFolderCount",
    "totalItemCount",
    "unreadItemCount",
    "isHidden",
]


def prepare_list_folders_request_config(
    limit: int,
    include_hidden: bool = False,
) -> MailFoldersRequestBuilder.MailFoldersRequestBuilderGetRequestConfiguration:
    """Prepare a request configuration for listing top-level mail folders."""
    limit = max(1, min(limit, 100))

    query_params = MailFoldersRequestBuilder.MailFoldersRequestBuilderGetQueryParameters(
        select=DEFAULT_FOLDER_FIELDS,
        top=limit,
        include_hidden_folders="true" if include_hidden else None,
    )
    return MailFoldersRequestBuilder.MailFoldersRequestBuilderGetRequestConfiguration(
        query_parameters=query_params,
    )


def prepare_list_child_folders_request_config(
    limit: int,
    include_hidden: bool = False,
) -> ChildFoldersRequestBuilder.ChildFoldersRequestBuilderGetRequestConfiguration:
    """Prepare a request configuration for listing child folders of a parent folder."""
    limit = max(1, min(limit, 100))

    query_params = ChildFoldersRequestBuilder.ChildFoldersRequestBuilderGetQueryParameters(
        select=DEFAULT_FOLDER_FIELDS,
        top=limit,
        include_hidden_folders="true" if include_hidden else None,
    )
    return ChildFoldersRequestBuilder.ChildFoldersRequestBuilderGetRequestConfiguration(
        query_parameters=query_params,
    )


async def send_reply_email(
    context: Context,
    message_id: str,
    body: str,
    reply_type: ReplyType,
) -> dict:
    """Send a reply email to the sender or all recipients of an existing email."""
    client = get_client(context.get_auth_token_or_empty())

    if reply_type == ReplyType.REPLY:
        reply_request_body = ReplyPostRequestBody(comment=body)
        await client.me.messages.by_message_id(message_id).reply.post(reply_request_body)
    elif reply_type == ReplyType.REPLY_ALL:
        reply_all_request_body = ReplyAllPostRequestBody(comment=body)
        await client.me.messages.by_message_id(message_id).reply_all.post(reply_all_request_body)

    return {
        "success": True,
        "message": "Email sent successfully",
    }
