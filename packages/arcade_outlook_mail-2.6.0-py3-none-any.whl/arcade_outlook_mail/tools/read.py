from typing import Annotated

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_microsoft_utils.utils import validate_pagination_url
from kiota_abstractions.api_error import APIError

from arcade_outlook_mail._utils import (
    build_search_query,
    fetch_emails,
    prepare_get_email_request_config,
    prepare_list_child_folders_request_config,
    prepare_list_emails_request_config,
    prepare_list_folders_request_config,
    prepare_search_emails_request_config,
    raise_sort_filter_error,
    remove_none_values,
)
from arcade_outlook_mail.client import get_client
from arcade_outlook_mail.enums import (
    BodyFormat,
    EmailFilterProperty,
    EmailImportance,
    EmailSortProperty,
    FilterOperator,
    FlagStatus,
    SortOrder,
    WellKnownFolderNames,
)
from arcade_outlook_mail.folder import MailFolderInfo
from arcade_outlook_mail.message import Message


@tool(
    requires_auth=Microsoft(scopes=["Mail.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.EMAIL],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_emails(
    context: Context,
    sort_by: Annotated[
        EmailSortProperty,
        "Property to sort results by. Defaults to received date.",
    ] = EmailSortProperty.RECEIVED_DATE_TIME,
    sort_order: Annotated[
        SortOrder,
        "Sort direction. Defaults to descending.",
    ] = SortOrder.DESCENDING,
    limit: Annotated[int, "The number of messages to return. Max is 100. Defaults to 10."] = 10,
    pagination_token: Annotated[
        str | None, "The pagination token to continue a previous request"
    ] = None,
) -> Annotated[dict, "A dictionary containing a list of emails"]:
    """List emails in the user's mailbox across all folders.

    Results are sorted by sort_by in the sort_order direction.
    Defaults to newest first (receivedDateTime descending).

    Since this tool lists email across all folders, it may return sent items,
    drafts, and other items that are not in the inbox.
    """
    client = get_client(context.get_auth_token_or_empty())
    request_config = prepare_list_emails_request_config(
        limit, sort_by=sort_by, sort_order=sort_order
    )
    message_builder = client.me.messages

    try:
        response = await fetch_emails(message_builder, pagination_token, request_config)
    except APIError as e:
        raise_sort_filter_error(e, sort_by, filter_property=None)

    messages = [Message.from_sdk(msg).to_dict() for msg in response.value or []]
    pagination_token = response.odata_next_link

    result = {
        "messages": messages,
        "num_messages": len(messages),
        "pagination_token": pagination_token,
    }
    result = remove_none_values(result)
    return result


@tool(
    requires_auth=Microsoft(scopes=["Mail.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.EMAIL],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_emails_in_folder(
    context: Context,
    well_known_folder_name: Annotated[
        WellKnownFolderNames | None,
        "The name of the folder to list emails from. Defaults to None.",
    ] = None,
    folder_id: Annotated[
        str | None,
        "The ID of the folder to list emails from if the folder is not a well-known folder. "
        "Defaults to None.",
    ] = None,
    sort_by: Annotated[
        EmailSortProperty,
        "Property to sort results by. Defaults to received date.",
    ] = EmailSortProperty.RECEIVED_DATE_TIME,
    sort_order: Annotated[
        SortOrder,
        "Sort direction. Defaults to descending.",
    ] = SortOrder.DESCENDING,
    limit: Annotated[int, "The number of messages to return. Max is 100. Defaults to 10."] = 10,
    pagination_token: Annotated[
        str | None, "The pagination token to continue a previous request"
    ] = None,
) -> Annotated[
    dict, "A dictionary containing a list of emails and a pagination token, if applicable"
]:
    """List the user's emails in the specified folder.

    Exactly one of `well_known_folder_name` or `folder_id` MUST be provided.

    Results are sorted by sort_by in the sort_order direction.
    Defaults to newest first (receivedDateTime descending).
    """
    if not (bool(well_known_folder_name) ^ bool(folder_id)):
        raise ToolExecutionError(
            message="Exactly one of `well_known_folder_name` or `folder_id` must be provided."
        )
    folder_name = well_known_folder_name.value if well_known_folder_name else folder_id
    client = get_client(context.get_auth_token_or_empty())
    request_config = prepare_list_emails_request_config(
        limit, sort_by=sort_by, sort_order=sort_order
    )
    message_builder = client.me.mail_folders.by_mail_folder_id(folder_name).messages  # type: ignore [arg-type]

    try:
        response = await fetch_emails(message_builder, pagination_token, request_config)
    except APIError as e:
        raise_sort_filter_error(e, sort_by, filter_property=None)

    messages = [Message.from_sdk(msg).to_dict() for msg in response.value or []]
    pagination_token = response.odata_next_link

    result = {
        "messages": messages,
        "num_messages": len(messages),
        "pagination_token": pagination_token,
    }
    result = remove_none_values(result)
    return result


@tool(
    requires_auth=Microsoft(scopes=["Mail.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.EMAIL],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_emails_by_property(
    context: Context,
    property: Annotated[EmailFilterProperty, "The property to filter the emails by."],  # noqa: A002
    operator: Annotated[FilterOperator, "The operator to use for the filter."],
    value: Annotated[str, "The value to filter the emails by"],
    sort_by: Annotated[
        EmailSortProperty,
        "Property to sort results by. Defaults to received date. "
        "Sorting by received date works with any filter property. "
        "Sorting by a different property while filtering by another may not be "
        "supported — if the combination fails, use sort_by=RECEIVED_DATE_TIME "
        "or use list_emails with the desired sort_by instead.",
    ] = EmailSortProperty.RECEIVED_DATE_TIME,
    sort_order: Annotated[
        SortOrder,
        "Sort direction. Defaults to descending.",
    ] = SortOrder.DESCENDING,
    limit: Annotated[int, "The number of messages to return. Max is 100. Defaults to 10."] = 10,
    pagination_token: Annotated[
        str | None, "The pagination token to continue a previous request"
    ] = None,
) -> Annotated[dict, "A dictionary containing a list of emails"]:
    """List emails in the user's mailbox across all folders filtering by a property.

    Results are sorted by sort_by in the sort_order direction.
    Defaults to newest first (receivedDateTime descending).

    Sorting by RECEIVED_DATE_TIME works with any filter property. Sorting by
    a different property (SUBJECT, SENDER, IMPORTANCE) while filtering by an
    unrelated property may fail due to a Microsoft Graph API restriction. If
    this happens, either sort by RECEIVED_DATE_TIME, or use list_emails (no
    filter) with the desired sort_by.
    """
    if property == EmailFilterProperty.IMPORTANCE:
        valid = [e.value for e in EmailImportance]
        if value.lower() not in valid:
            raise ToolExecutionError(
                message=f"Invalid importance value: '{value}'. Must be one of: {', '.join(valid)}"
            )
        value = value.lower()

    if property == EmailFilterProperty.FLAG_STATUS:
        lookup = {e.value.lower(): e.value for e in FlagStatus}
        normalized = lookup.get(value.lower())
        if normalized is None:
            raise ToolExecutionError(
                message=f"Invalid flag status value: '{value}'. "
                f"Must be one of: {', '.join(lookup.values())}"
            )
        value = normalized

    if property in (EmailFilterProperty.IS_READ, EmailFilterProperty.HAS_ATTACHMENTS):
        if value.lower() not in ("true", "false"):
            raise ToolExecutionError(
                message=f"Invalid boolean value: '{value}'. Must be 'true' or 'false'."
            )
        value = value.lower()

    client = get_client(context.get_auth_token_or_empty())
    request_config = prepare_list_emails_request_config(
        limit, property, operator, value, sort_by=sort_by, sort_order=sort_order
    )
    message_builder = client.me.messages

    try:
        response = await fetch_emails(message_builder, pagination_token, request_config)
    except APIError as e:
        raise_sort_filter_error(e, sort_by, filter_property=property)

    messages = [Message.from_sdk(msg).to_dict() for msg in response.value or []]
    pagination_token = response.odata_next_link

    result = {
        "messages": messages,
        "num_messages": len(messages),
        "pagination_token": pagination_token,
    }
    result = remove_none_values(result)
    return result


@tool(
    requires_auth=Microsoft(scopes=["Mail.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.EMAIL],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_email(
    context: Context,
    message_id: Annotated[str, "The ID of the email message to retrieve."],
    body_format: Annotated[
        BodyFormat,
        "Format for the returned email body. PLAIN_TEXT strips HTML tags "
        "for clean reading. HTML returns the original markup. "
        "Defaults to PLAIN_TEXT.",
    ] = BodyFormat.PLAIN_TEXT,
    max_body_characters: Annotated[
        int | None,
        "Maximum number of characters to return from the email body. "
        "Defaults to 5000. Set to None to return the full body without a cap.",
    ] = 5000,
    body_offset: Annotated[
        int,
        "Character offset to start reading the body from. "
        "Use this to continue reading a long email body that was previously "
        "capped. Defaults to 0 (start of body).",
    ] = 0,
) -> Annotated[dict, "A dictionary containing the email message."]:
    """Retrieve a single email message by its ID.

    Returns email metadata and body content. By default, the body is returned
    as plain text (HTML tags stripped) and capped at 5000 characters. Set
    body_format to HTML to get the original markup. Use body_offset to
    continue reading long emails, or set max_body_characters to None for the
    full body.

    Use this tool to read the full content of an email after finding it via
    search_emails or any listing tool.
    """
    client = get_client(context.get_auth_token_or_empty())
    request_config = prepare_get_email_request_config()

    try:
        response = await client.me.messages.by_message_id(message_id).get(
            request_configuration=request_config
        )
    except APIError as e:
        if e.response_status_code == 404:
            raise ToolExecutionError(message=f"Message not found: {message_id}") from e
        raise

    msg = Message.from_sdk(response)  # type: ignore[arg-type]
    result = msg.to_dict()

    full_body = msg.body_html if body_format == BodyFormat.HTML else result["body"]
    result["body_format"] = body_format.value
    body_total = len(full_body)
    body_offset = max(0, body_offset)

    if max_body_characters is not None:
        max_body_characters = max(1, max_body_characters)
        chunk = full_body[body_offset : body_offset + max_body_characters]
        body_has_more = (body_offset + max_body_characters) < body_total
        body_next_offset = body_offset + max_body_characters if body_has_more else None
    else:
        chunk = full_body[body_offset:]
        body_has_more = False
        body_next_offset = None

    result["body"] = chunk
    result["body_current_offset"] = body_offset
    result["body_next_offset"] = body_next_offset
    result["body_total_characters"] = body_total
    result["body_has_more"] = body_has_more

    return remove_none_values(result)


@tool(
    requires_auth=Microsoft(scopes=["Mail.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.EMAIL],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def search_emails(
    context: Context,
    keywords: Annotated[
        list[str] | None,
        "Words or phrases to search for across email subject, body, and sender fields. "
        "All terms must match (AND operator). Defaults to None.",
    ] = None,
    sender: Annotated[
        list[str] | None,
        "Filter by sender email address, display name, or alias. "
        "When multiple values are provided, emails from any of the senders "
        "are returned (OR operator). Defaults to None.",
    ] = None,
    recipient: Annotated[
        list[str] | None,
        "Filter by To-recipient email address or display name. "
        "When multiple values are provided, emails to any of the recipients "
        "are returned (OR operator). Defaults to None.",
    ] = None,
    attachment_name: Annotated[
        list[str] | None,
        "Filter by attachment filename. "
        "When multiple values are provided, emails with any of the attachment "
        "names are returned (OR operator). Defaults to None.",
    ] = None,
    has_attachments: Annotated[
        bool | None,
        "Filter for emails with or without attachments. Defaults to None (no filter).",
    ] = None,
    importance: Annotated[
        EmailImportance | None,
        "Filter by email importance level. Defaults to None (no filter).",
    ] = None,
    is_read: Annotated[
        bool | None,
        "Filter by read status. True for read emails, False for unread. "
        "Defaults to None (no filter).",
    ] = None,
    category: Annotated[
        str | None,
        "Filter by email category name. Categories are user-defined. Defaults to None (no filter).",
    ] = None,
    received_after: Annotated[
        str | None,
        "Filter for emails received on or after this date (YYYY-MM-DD). "
        "Dates are interpreted in UTC. Defaults to None (no filter).",
    ] = None,
    received_before: Annotated[
        str | None,
        "Filter for emails received on or before this date (YYYY-MM-DD). "
        "Dates are interpreted in UTC. Defaults to None (no filter).",
    ] = None,
    limit: Annotated[
        int,
        "The maximum number of search results to return. Max is 25. Defaults to 10.",
    ] = 10,
    pagination_token: Annotated[
        str | None,
        "The pagination token to continue a previous request.",
    ] = None,
) -> Annotated[dict, "A dictionary containing a list of matching emails."]:
    """Search emails across the user's entire mailbox.

    Combines full-text keyword search with structured filters for sender,
    read status, attachments, importance, and more. All provided parameters
    are combined with AND. Results are ordered by date sent (most recent first).

    Email bodies are truncated to 255 characters for efficient skimming.
    Use get_email with the message_id to retrieve the full email content.

    Use this tool when the user wants to find emails by content, topic, sender,
    or a combination of criteria. For exact property filtering (e.g., by
    conversationId or flag status), use list_emails_by_property instead.
    """
    client = get_client(context.get_auth_token_or_empty())
    message_builder = client.me.messages

    if pagination_token:
        validate_pagination_url(pagination_token)
        response = await message_builder.with_url(pagination_token).get()
        messages = [
            Message.from_sdk(msg).to_dict(max_body_length=255)
            for msg in (response.value or [])  # type: ignore[union-attr]
        ]
        return remove_none_values({
            "messages": messages,
            "num_messages": len(messages),
            "query": None,
            "pagination_token": response.odata_next_link,  # type: ignore[union-attr]
        })

    importance_value = importance.value if importance else None
    query = build_search_query(
        keywords=keywords,
        sender=sender,
        recipient=recipient,
        attachment_name=attachment_name,
        has_attachments=has_attachments,
        importance=importance_value,
        is_read=is_read,
        category=category,
        received_after=received_after,
        received_before=received_before,
    )

    if not query:
        raise ToolExecutionError(
            message="At least one search parameter is required. "
            "Provide keywords, sender, recipient, or any other filter."
        )

    request_config = prepare_search_emails_request_config(query, limit)
    response = await message_builder.get(request_configuration=request_config)

    messages = [
        Message.from_sdk(msg).to_dict(max_body_length=255)
        for msg in (response.value or [])  # type: ignore[union-attr]
    ]

    return remove_none_values({
        "messages": messages,
        "num_messages": len(messages),
        "query": query,
        "pagination_token": response.odata_next_link,  # type: ignore[union-attr]
    })


@tool(
    requires_auth=Microsoft(scopes=["Mail.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.EMAIL],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_mail_folders(
    context: Context,
    parent_folder_id: Annotated[
        str | None,
        "ID of a parent folder to list child folders of. "
        "When omitted, lists top-level mailbox folders.",
    ] = None,
    include_hidden: Annotated[
        bool,
        "Whether to include hidden folders in the response. Defaults to False.",
    ] = False,
    limit: Annotated[
        int,
        "Maximum number of folders to return. Max is 100. Defaults to 25.",
    ] = 25,
    pagination_token: Annotated[
        str | None,
        "The pagination token to continue a previous request.",
    ] = None,
) -> Annotated[dict, "A dictionary containing a list of mail folders."]:
    """List mail folders in the user's mailbox.

    Returns folder names, IDs, unread counts, and total item counts.
    Use the folder ID in follow-up calls to list_emails_in_folder.
    Omit parent_folder_id to list top-level folders, or provide a folder ID
    to list its child folders.
    """
    client = get_client(context.get_auth_token_or_empty())

    if pagination_token:
        validate_pagination_url(pagination_token)
        response = await client.me.mail_folders.with_url(pagination_token).get()
    elif parent_folder_id:
        child_config = prepare_list_child_folders_request_config(limit, include_hidden)
        response = await client.me.mail_folders.by_mail_folder_id(
            parent_folder_id
        ).child_folders.get(request_configuration=child_config)
    else:
        folders_config = prepare_list_folders_request_config(limit, include_hidden)
        response = await client.me.mail_folders.get(request_configuration=folders_config)

    folders = [
        MailFolderInfo.from_sdk(f).to_dict(include_hidden_field=include_hidden)
        for f in (response.value or [])  # type: ignore[union-attr]
    ]

    return remove_none_values({
        "folders": folders,
        "num_folders": len(folders),
        "pagination_token": response.odata_next_link,  # type: ignore[union-attr]
    })
