from typing import Annotated

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_microsoft_utils.utils import validate_pagination_url
from kiota_abstractions.api_error import APIError

from arcade_outlook_mail._utils import prepare_list_attachments_request_config, remove_none_values
from arcade_outlook_mail.attachment import Attachment
from arcade_outlook_mail.client import get_client


@tool(
    requires_auth=Microsoft(scopes=["Mail.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.EMAIL],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_email_attachments(
    context: Context,
    message_id: Annotated[str, "The ID of the email message to list attachments for."],
    limit: Annotated[
        int, "The maximum number of attachments to return. Max is 100. Defaults to 25."
    ] = 25,
    pagination_token: Annotated[
        str | None, "The pagination token to continue a previous request"
    ] = None,
) -> Annotated[dict, "A dictionary containing a list of attachment metadata objects."]:
    """List attachment metadata for an email message.

    Returns metadata only (name, size, type, etc.). Attachment content is not included.
    Use this tool when the user wants to know what files are attached to an email.
    """
    client = get_client(context.get_auth_token_or_empty())
    request_config = prepare_list_attachments_request_config(limit)
    attachments_builder = client.me.messages.by_message_id(message_id).attachments

    try:
        if pagination_token:
            validate_pagination_url(pagination_token)
            response = await attachments_builder.with_url(pagination_token).get()
        else:
            response = await attachments_builder.get(request_configuration=request_config)
    except APIError as e:
        if e.response_status_code == 404:
            raise ToolExecutionError(message=f"Message not found: {message_id}") from e
        raise

    attachments = [Attachment.from_sdk(att).to_dict() for att in (response.value or [])]  # type: ignore[union-attr]

    result = {
        "attachments": attachments,
        "num_attachments": len(attachments),
        "message_id": message_id,
        "pagination_token": response.odata_next_link,  # type: ignore[union-attr]
    }
    return remove_none_values(result)
