from arcade_outlook_mail.tools.attachments import list_email_attachments
from arcade_outlook_mail.tools.read import (
    get_email,
    list_emails,
    list_emails_by_property,
    list_emails_in_folder,
    list_mail_folders,
    search_emails,
)
from arcade_outlook_mail.tools.send import (
    create_and_send_email,
    reply_to_email,
    send_draft_email,
)
from arcade_outlook_mail.tools.system_context import who_am_i
from arcade_outlook_mail.tools.write import (
    create_draft_email,
    update_draft_email,
)

__all__ = [
    # Read
    "get_email",
    "list_emails",
    "list_emails_by_property",
    "list_emails_in_folder",
    "list_email_attachments",
    "list_mail_folders",
    "search_emails",
    # Send
    "create_and_send_email",
    "reply_to_email",
    "send_draft_email",
    # System Context
    "who_am_i",
    # Write
    "create_draft_email",
    "update_draft_email",
]
