"""
Schema module - imports from local sinew/schema/ directory.

This module re-exports all schema components from the local sinew/schema/
directory to provide the expected import paths:
- sinew.schema.models: Pydantic models for the sinew graph structure
- sinew.schema.validator: Validation logic for sinew.json files

This __init__.py uses importlib to load the modules and re-exports all
components, allowing imports like:
    from sinew.schema.models import Node, Edge, sinewGraph
    from sinew.schema.validator import validate_file, validate_dict
"""

import sys
import importlib.util
from pathlib import Path

# Load models module explicitly from local sinew/schema/
models_path = Path(__file__).parent / "models.py"
spec = importlib.util.spec_from_file_location("sinew.schema.models", models_path)
_models_module = importlib.util.module_from_spec(spec)
sys.modules['sinew.schema.models'] = _models_module
spec.loader.exec_module(_models_module)

# Load validator module explicitly from local sinew/schema/
validator_path = Path(__file__).parent / "validator.py"
spec = importlib.util.spec_from_file_location("sinew.schema.validator", validator_path)
_validator_module = importlib.util.module_from_spec(spec)
sys.modules['sinew.schema.validator'] = _validator_module
spec.loader.exec_module(_validator_module)

# Re-export all components from models
from sinew.schema.models import *  # noqa: F401, F403

# Re-export all components from validator
from sinew.schema.validator import *  # noqa: F401, F403
