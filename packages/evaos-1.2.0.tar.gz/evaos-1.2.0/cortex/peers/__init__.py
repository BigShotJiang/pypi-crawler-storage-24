"""cortex/peers — Peer Modeling subsystem (M15).

Tracks interaction partners (peers) and builds structured representations
of them based on claims and interaction history.

Public API::

    from cortex.peers import PeerManager
    from cortex.types import Peer

    mgr = PeerManager(storage=storage, entity_resolver=resolver)
    peer = await mgr.get_or_create_peer(owner_id="default", entity_name="Alice")
    await mgr.update_interaction(peer.id)
    rep = await mgr.build_representation(peer.id, claims=[...])
"""
from cortex.peers.manager import PeerManager

__all__ = ["PeerManager"]
