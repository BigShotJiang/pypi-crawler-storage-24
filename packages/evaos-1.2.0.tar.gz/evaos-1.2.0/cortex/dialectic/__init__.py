"""
cortex/dialectic — Dialectic Engine (Module 14 / M14).

The "ask your memory" subsystem. Given a natural-language question, the
Dialectic Engine retrieves relevant memories and synthesises a grounded
answer using an LLM.

Fast path: single-shot retrieval + synthesis — no multi-round refinement.
History path: ask_with_history() passes conversation history for follow-up Qs.

Public surface:
    DialecticEngine — main engine class
    DialecticResponse — response dataclass

Usage::

    from cortex.dialectic import DialecticEngine, DialecticResponse
    engine = DialecticEngine(retrieval_engine, llm_provider, config)
    response = await engine.ask("What does the user prefer?", owner_id="user-1")
    print(response.answer)
    print(response.confidence)
    for src in response.sources:
        print(src)
"""

from cortex.dialectic.engine import DialecticEngine, DialecticResponse

__all__ = ["DialecticEngine", "DialecticResponse"]
