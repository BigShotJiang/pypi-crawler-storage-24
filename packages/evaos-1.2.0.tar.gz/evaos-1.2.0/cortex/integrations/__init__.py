"""
cortex.integrations — Bridges between Cortex v3 and host platforms.

Available integrations:
    - openclaw_plugin: OpenClaw memory backend (remember/recall/health)
    - openclaw_config: OpenClaw config format → CortexConfig bridge
    - openclaw_loader: Safe import guard — never crashes on load
"""
