"""
cortex.core — Core subsystem public API.

This package exposes the primary engines, managers, and data types that
comprise the Cortex memory pipeline.  Import from ``cortex.core`` for
convenient access to the public surface.
"""
from __future__ import annotations

from cortex.core.boot_loader import BootSequence, SessionBootLoader
from cortex.core.context_compiler import (
    Bundle,
    BundleType,
    CompiledContext,
    ContextCompiler,
)
from cortex.core.feature_flags import FeatureFlag, FeatureFlagManager
from cortex.core.feedback import FeedbackSystem
from cortex.core.injection_slots import (
    InjectionAssignment,
    InjectionSlotManager,
    SlotPosition,
)
from cortex.core.metrics import MetricsCollector
from cortex.core.promotion import PromotionScore, PromotionScorer, PromotionWeights
from cortex.core.quality_gates import GateResult, QualityGate, QualityGateEngine
from cortex.core.re_retrieval import (
    ReRetrievalEngine,
    ReRetrievalRequest,
    ReRetrievalResult,
    ReRetrievalTrigger,
)
from cortex.core.retrieval_policy import (
    ChannelPolicy,
    PolicyEngine,
    RetrievalPolicy,
)
from cortex.core.task_mode import TaskMode, TaskModeClassifier, TaskModeResult
from cortex.core.token_budget import TokenBudget, TokenBudgetManager
from cortex.core.working_memory import WorkingMemoryCache, WorkingMemoryCategory

__all__ = [
    # Boot loader
    "BootSequence",
    "SessionBootLoader",
    # Context compiler
    "Bundle",
    "BundleType",
    "CompiledContext",
    "ContextCompiler",
    # Feature flags
    "FeatureFlag",
    "FeatureFlagManager",
    # Feedback
    "FeedbackSystem",
    # Injection slots
    "InjectionAssignment",
    "InjectionSlotManager",
    "SlotPosition",
    # Metrics
    "MetricsCollector",
    # Promotion
    "PromotionScore",
    "PromotionScorer",
    "PromotionWeights",
    # Quality gates
    "GateResult",
    "QualityGate",
    "QualityGateEngine",
    # Re-retrieval
    "ReRetrievalEngine",
    "ReRetrievalRequest",
    "ReRetrievalResult",
    "ReRetrievalTrigger",
    # Retrieval policy
    "ChannelPolicy",
    "PolicyEngine",
    "RetrievalPolicy",
    # Task mode
    "TaskMode",
    "TaskModeClassifier",
    "TaskModeResult",
    # Token budget
    "TokenBudget",
    "TokenBudgetManager",
    # Working memory
    "WorkingMemoryCache",
    "WorkingMemoryCategory",
]
