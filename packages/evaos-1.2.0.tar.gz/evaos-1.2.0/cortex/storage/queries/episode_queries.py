"""cortex/storage/queries/episode_queries.py — Episode storage mixin (v8 schema).

Placeholder for episode-specific queries that will be extracted from
claim_queries.py when the v8 schema lands.  Currently, episode operations
(log_episode, etc.) still live in ClaimQueryMixin.
"""
