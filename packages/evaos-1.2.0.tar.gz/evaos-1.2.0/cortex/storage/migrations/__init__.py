"""
cortex/storage/migrations — Schema migration framework for Cortex SQLite database.

Usage:
    from cortex.storage.migrations import MigrationRunner

    runner = MigrationRunner(conn)
    count = await runner.apply_all()

Each migration module must define:
    VERSION     : int        — monotonically increasing schema version
    DESCRIPTION : str        — human-readable summary
    SQL_UP      : str        — DDL/DML to apply
    SQL_DOWN    : str        — rollback instructions (optional, SQLite limitations apply)

Public surface:
    MigrationRunner  — discovers and applies pending migrations
"""
from cortex.storage.migrations.runner import MigrationRunner

__all__ = ["MigrationRunner"]
