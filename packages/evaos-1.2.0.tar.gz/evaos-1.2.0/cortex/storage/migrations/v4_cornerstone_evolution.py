"""
cortex/storage/migrations/v4_cornerstone_evolution.py — M5 Evolution Proposals.

Adds the cornerstone_evolution_proposal table that stores LLM-generated
proposals for updating cornerstone memories.  Proposals always require manual
operator review unless auto_apply_threshold is configured.

Migration: version 3 → 4
"""

VERSION = 4
DESCRIPTION = "Add cornerstone_evolution_proposal table for M5 propose_evolution()"

SQL_UP = """
CREATE TABLE IF NOT EXISTS cornerstone_evolution_proposal (
    id              TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    cornerstone_id  TEXT NOT NULL REFERENCES cornerstone_memory(id),
    owner_id        TEXT NOT NULL DEFAULT 'default',
    new_evidence    TEXT NOT NULL,
    proposed_content TEXT NOT NULL,
    diff            TEXT NOT NULL DEFAULT '',
    reasoning       TEXT NOT NULL DEFAULT '',
    confidence      REAL NOT NULL DEFAULT 0.0,
    status          TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending', 'applied', 'rejected')),
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    applied_at      TEXT
);

CREATE INDEX IF NOT EXISTS idx_evo_proposal_cornerstone
    ON cornerstone_evolution_proposal (cornerstone_id, status);

CREATE INDEX IF NOT EXISTS idx_evo_proposal_owner
    ON cornerstone_evolution_proposal (owner_id, status);
"""

SQL_DOWN = """
DROP INDEX IF EXISTS idx_evo_proposal_owner;
DROP INDEX IF EXISTS idx_evo_proposal_cornerstone;
DROP TABLE IF EXISTS cornerstone_evolution_proposal;
"""
