"""
cortex/storage/migrations/v9_commitments_loops.py — First-class commitments & open loops.

Adds missing columns to the v8 commitment/open_loop tables to support
the full Commitment and OpenLoop dataclass shapes (Issue #364):

  commitment:
    - source_turn_id TEXT  (which conversation turn originated this)

  open_loop:
    - carry_count INTEGER DEFAULT 0  (sleep/wake cycles survived)

Migration: version 8 → 9
"""

VERSION = 9
DESCRIPTION = "Add source_turn_id to commitment and carry_count to open_loop (Issue #364)"

SQL_UP = """
ALTER TABLE commitment ADD COLUMN source_turn_id TEXT DEFAULT NULL;

ALTER TABLE open_loop ADD COLUMN carry_count INTEGER NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_commitment_source_turn
    ON commitment (source_turn_id);

CREATE INDEX IF NOT EXISTS idx_open_loop_carry_count
    ON open_loop (owner_id, carry_count, status);
"""

SQL_DOWN = """
DROP INDEX IF EXISTS idx_open_loop_carry_count;
DROP INDEX IF EXISTS idx_commitment_source_turn;
-- SQLite does not support DROP COLUMN on older versions; skip column removal.
SELECT 1;
"""
