"""
cortex.deprecation — Memory Deprecation Pipeline (MODULE 7)

Exports:
    DeprecationPipeline — main pipeline class
    DeprecationReport   — result from review_session()
    DecayReport         — result from run_decay()
    ReinforcementReport — result from check_reinforcement()

Decay curve:
    apply_decay          — Ebbinghaus forgetting curve
    compute_reinforcement — reinforcement model
    compute_stability     — stability from access count
    compute_retention     — retention from time + stability
"""

from cortex.deprecation.decay import (
    DecayResult,
    ReinforcementResult,
    apply_decay,
    compute_reinforcement,
    compute_retention,
    compute_stability,
)
from cortex.deprecation.pipeline import (
    DecayReport,
    DeprecationDecision,
    DeprecationPipeline,
    DeprecationReport,
    ReinforcementReport,
    SESSION_REVIEW_PROMPT,
    STATUS_ACTIVE,
    STATUS_ARCHIVED,
    STATUS_COOLING,
    STATUS_DEPRECATED,
)

__all__ = [
    # Pipeline
    "DeprecationPipeline",
    "DeprecationReport",
    "DecayReport",
    "DeprecationDecision",
    "ReinforcementReport",
    "SESSION_REVIEW_PROMPT",
    # Status constants
    "STATUS_ACTIVE",
    "STATUS_COOLING",
    "STATUS_DEPRECATED",
    "STATUS_ARCHIVED",
    # Decay curve
    "apply_decay",
    "compute_reinforcement",
    "compute_retention",
    "compute_stability",
    "DecayResult",
    "ReinforcementResult",
]
