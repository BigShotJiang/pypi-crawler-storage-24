"""
cortex/circadian/dream.py — DEPRECATED: renamed to curiosity.py (#394).

This module is retained as a backward-compatibility shim only.
All new code should import from ``cortex.circadian.curiosity`` directly.
"""
from __future__ import annotations

# Re-export everything from the canonical module so existing imports still work.
from cortex.circadian.curiosity import (  # noqa: F401
    CuriosityEngine,
    CuriosityReport,
    CuriositySeed,
    ThemeCluster,
)

__all__ = [
    "CuriosityEngine",
    "CuriosityReport",
    "CuriositySeed",
    "ThemeCluster",
]
