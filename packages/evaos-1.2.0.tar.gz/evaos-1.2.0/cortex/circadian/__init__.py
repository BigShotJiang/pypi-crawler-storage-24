"""
cortex/circadian — Circadian Engine (M6a + M6b + M6c)

M6a: Session lifecycle state machine + scheduler (engine.py)
M6b: Sleep & dream consolidation logic (sleep.py)
M6c: Curiosity seeds + cross-memory connections (dream.py)

Public surface:
    CircadianEngine   — session lifecycle state machine + scheduler (M6a)
    CircadianState    — AWAKE / DROWSY / SLEEPING / DREAMING / WAKING / SHUTDOWN enum (M6a)
    WakeReport        — result of wake() (M6a)
    NapReport         — result of nap() (M6a)
    ShutdownReport    — result of shutdown() (M6a)
    SleepConsolidator — M6b sleep/dream consolidation implementation
    SleepReport       — result of sleep()
    DreamReport       — result of dream()
    CuriosityEngine   — M6c curiosity seeds + cross-memory connections
    CuriosityReport   — result of CuriosityEngine.run()
    CuriositySeed     — individual seed dataclass
    ThemeCluster      — thematic cluster dataclass
"""

from cortex.circadian.engine import (
    CircadianEngine,
    CircadianState,
    WakeReport,
    NapReport,
    SleepReport,
    DreamReport,
    ShutdownReport,
)
from cortex.circadian.sleep import (
    SleepConsolidator,
)
from cortex.circadian.curiosity import (
    CuriosityEngine,
    CuriosityReport,
    CuriositySeed,
    ThemeCluster,
)

__all__ = [
    "CircadianEngine",
    "CircadianState",
    "WakeReport",
    "NapReport",
    "ShutdownReport",
    "SleepConsolidator",
    "SleepReport",
    "DreamReport",
    "CuriosityEngine",
    "CuriosityReport",
    "CuriositySeed",
    "ThemeCluster",
]
