"""
tests/test_tier.py — Unit tests for CortexTier enum + config integration.

Covers:
  - CortexTier enum values
  - CortexConfig.tier defaults to LITE
  - tier can be set to FULL via overlay
  - is_full_tier() helper returns correct bool
"""

import pytest

from cortex.types import CortexTier
from cortex.config import CortexConfig, is_full_tier


class TestCortexTierEnum:
    def test_lite_value(self):
        assert CortexTier.LITE == "lite"
        assert CortexTier.LITE.value == "lite"

    def test_full_value(self):
        assert CortexTier.FULL == "full"
        assert CortexTier.FULL.value == "full"

    def test_is_str_enum(self):
        assert isinstance(CortexTier.LITE, str)
        assert isinstance(CortexTier.FULL, str)

    def test_from_string(self):
        assert CortexTier("lite") is CortexTier.LITE
        assert CortexTier("full") is CortexTier.FULL

    def test_invalid_value_raises(self):
        with pytest.raises(ValueError):
            CortexTier("enterprise")


class TestCortexConfigTierField:
    def test_tier_defaults_to_lite(self):
        """CortexConfig() with no args should default tier to CortexTier.LITE."""
        config = CortexConfig()
        assert config.tier == CortexTier.LITE

    def test_tier_can_be_set_to_full(self):
        """Config with tier='full' (via from_toml overlay) should set FULL."""
        config = CortexConfig.from_toml(
            overlay={"cortex": {"tier": "full"}}
        )
        assert config.tier == CortexTier.FULL

    def test_tier_lite_via_overlay(self):
        """Explicitly passing tier='lite' should keep it LITE."""
        config = CortexConfig.from_toml(
            overlay={"cortex": {"tier": "lite"}}
        )
        assert config.tier == CortexTier.LITE

    def test_tier_direct_instantiation_full(self):
        """Direct instantiation with tier=CortexTier.FULL should work."""
        config = CortexConfig(tier=CortexTier.FULL)
        assert config.tier == CortexTier.FULL

    def test_defaults_toml_loads_lite(self):
        """CortexConfig.defaults() (reads defaults.toml) should be LITE."""
        config = CortexConfig.defaults()
        assert config.tier == CortexTier.LITE


class TestIsFullTierHelper:
    def test_is_full_tier_helper(self):
        """is_full_tier() returns True for FULL, False for LITE."""
        lite_config = CortexConfig(tier=CortexTier.LITE)
        full_config = CortexConfig(tier=CortexTier.FULL)

        assert is_full_tier(full_config) is True
        assert is_full_tier(lite_config) is False

    def test_is_full_tier_default_config(self):
        """Default config is LITE — is_full_tier() must return False."""
        config = CortexConfig()
        assert is_full_tier(config) is False

    def test_is_full_tier_overlay(self):
        """Config loaded with tier='full' overlay → is_full_tier() True."""
        config = CortexConfig.from_toml(overlay={"cortex": {"tier": "full"}})
        assert is_full_tier(config) is True
