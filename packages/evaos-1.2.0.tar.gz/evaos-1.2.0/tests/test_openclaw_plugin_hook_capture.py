from __future__ import annotations

from pathlib import Path


PLUGIN_PATH = Path(__file__).resolve().parents[1] / "integrations" / "openclaw-plugin" / "src" / "index.ts"


def _section(text: str, start: str, end: str) -> str:
    i = text.find(start)
    assert i != -1, f"Missing marker: {start}"
    j = text.find(end, i)
    assert j != -1, f"Missing marker: {end}"
    return text[i:j]


def test_before_agent_start_is_recall_only_no_remember_capture() -> None:
    """Regression guard for #293: before_agent_start must NOT call remember()."""
    src = PLUGIN_PATH.read_text(encoding="utf-8")

    before_block = _section(
        src,
        'api.on("before_agent_start", async (event, ctx) => {',
        "// Auto-capture: store conversation after agent ends",
    )

    assert "client.retrieve(" in before_block
    assert "client.remember(" not in before_block


def test_capture_path_is_agent_end_only() -> None:
    """Regression guard for #293: remember() must be called from agent_end hook."""
    src = PLUGIN_PATH.read_text(encoding="utf-8")

    agent_end_block = _section(
        src,
        'api.on("agent_end", async (event, ctx) => {',
        "// ========================================================================\n    // Service",
    )

    assert "client.remember(formattedMessages, sessionId);" in agent_end_block
