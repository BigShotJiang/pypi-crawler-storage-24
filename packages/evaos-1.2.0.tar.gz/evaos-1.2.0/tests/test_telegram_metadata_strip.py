from cortex.capture.wake_pipeline import (
    strip_transport_metadata_conversation as _strip_transport_metadata_conversation,
    strip_transport_metadata_text as _strip_transport_metadata_text,
)


def test_strip_sender_untrusted_metadata_block():
    raw = (
        'Sender (untrusted metadata):\n'
        '```json\n'
        '{"chat_id":-1001,"sender":{"id":123},"message_id":456}\n'
        '```\n\n'
        'Andrew prefers dark mode.'
    )
    assert _strip_transport_metadata_text(raw) == "Andrew prefers dark mode."


def test_strip_raw_json_telegram_metadata_preamble():
    raw = '{"inbound_meta":{"chat_id":-1001,"message_id":42,"sender":"andrew"}}\nI like TypeScript.'
    assert _strip_transport_metadata_text(raw) == "I like TypeScript."


def test_conversation_cleaning_preserves_normal_messages():
    conv = [
        {"role": "user", "content": '{"chat_id":1,"message_id":2}\nMy favorite editor is Neovim.'},
        {"role": "assistant", "content": "Noted."},
    ]
    cleaned = _strip_transport_metadata_conversation(conv)
    assert cleaned[0]["content"] == "My favorite editor is Neovim."
    assert cleaned[1]["content"] == "Noted."
