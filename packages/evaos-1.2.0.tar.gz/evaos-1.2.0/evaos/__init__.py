"""
evaos — top-level package alias for the cortex memory engine.

Allows the documented import pattern::

    from evaos import Cortex

to work alongside the lower-level ``cortex`` package.
"""

from cortex import Cortex
from cortex.api.plugin import CortexPlugin
from cortex.config import CortexConfig

__all__ = ["Cortex", "CortexPlugin", "CortexConfig"]
