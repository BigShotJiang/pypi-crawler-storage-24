"""TOML-based config loading for ntro SDK.

Config file: ~/.ntro/config.toml  (or $NTRO_HOME/config.toml)

Example:
    default_connection_name = "local"

    [connections.local]
    host = "http://localhost:3000/v1"
    api_key = "ntro_dev_key"
    default_tenant = "acme-fund-admin"

    [connections.production]
    host = "https://api.ntropii.com/v1"
    api_key = "ntro_prod_key"
"""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

import tomli_w

from ntro.workspace.exceptions import ConfigError

DEFAULT_HOST = "https://api.ntropii.com/v1"


@dataclass
class ConnectionConfig:
    name: str
    host: str = DEFAULT_HOST
    api_key: str = ""
    default_tenant: str | None = None
    default_entity: str | None = None


@dataclass
class NtroConfig:
    default_connection_name: str = "production"
    connections: dict[str, ConnectionConfig] = field(default_factory=dict)

    def get_connection(self, name: str | None = None) -> ConnectionConfig:
        target = name or self.default_connection_name
        if target not in self.connections:
            raise ConfigError(
                f"Connection '{target}' not found in config. "
                f"Available: {list(self.connections.keys()) or ['(none)']}\n"
                f"Run 'ntro auth login' to configure a connection."
            )
        return self.connections[target]


def _config_path() -> Path:
    ntro_home = os.environ.get("NTRO_HOME")
    if ntro_home:
        return Path(ntro_home) / "config.toml"
    return Path.home() / ".ntro" / "config.toml"


def load_config() -> NtroConfig:
    """Load config from disk. Returns an empty config (production defaults) if missing."""
    path = _config_path()
    if not path.exists():
        return NtroConfig(
            default_connection_name="production",
            connections={
                "production": ConnectionConfig(
                    name="production",
                    host=DEFAULT_HOST,
                    api_key="",
                )
            },
        )

    with open(path, "rb") as f:
        data = tomllib.load(f)

    connections: dict[str, ConnectionConfig] = {}
    for conn_name, conn_data in data.get("connections", {}).items():
        connections[conn_name] = ConnectionConfig(
            name=conn_name,
            host=conn_data.get("host", DEFAULT_HOST),
            api_key=conn_data.get("api_key", ""),
            default_tenant=conn_data.get("default_tenant"),
            default_entity=conn_data.get("default_entity"),
        )

    return NtroConfig(
        default_connection_name=data.get("default_connection_name", "production"),
        connections=connections,
    )


def save_config(config: NtroConfig) -> None:
    """Write config back to disk."""
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    data: dict[str, object] = {
        "default_connection_name": config.default_connection_name,
        "connections": {},
    }

    conns: dict[str, dict[str, object]] = {}
    for name, conn in config.connections.items():
        entry: dict[str, object] = {"host": conn.host, "api_key": conn.api_key}
        if conn.default_tenant:
            entry["default_tenant"] = conn.default_tenant
        if conn.default_entity:
            entry["default_entity"] = conn.default_entity
        conns[name] = entry

    data["connections"] = conns

    with open(path, "wb") as f:
        tomli_w.dump(data, f)


def write_default_config() -> Path:
    """Write the default config file (local + production connections) if it doesn't exist."""
    path = _config_path()
    if path.exists():
        return path

    config = NtroConfig(
        default_connection_name="local",
        connections={
            "local": ConnectionConfig(
                name="local",
                host="http://localhost:3000/v1",
                api_key="ntro_dev_key",
            ),
            "production": ConnectionConfig(
                name="production",
                host=DEFAULT_HOST,
                api_key="",
            ),
        },
    )
    save_config(config)
    return path
