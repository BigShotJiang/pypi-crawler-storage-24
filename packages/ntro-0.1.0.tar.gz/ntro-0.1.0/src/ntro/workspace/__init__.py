"""ntro.workspace — Workspace API client (control plane)."""

from ntro.workspace.client import Client

__all__ = ["Client"]
