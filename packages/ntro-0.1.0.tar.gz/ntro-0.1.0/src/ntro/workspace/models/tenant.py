"""Tenant models."""

from __future__ import annotations

from pydantic import BaseModel

from ntro.workspace.models.common import TenantStatus


class Tenant(BaseModel):
    id: str
    name: str
    slug: str
    dataPlatformConfigId: str | None = None
    status: TenantStatus = TenantStatus.PROVISIONING
    entityCount: int = 0
    createdAt: str | None = None
    updatedAt: str | None = None


class CreateTenantRequest(BaseModel):
    name: str
    slug: str
    dataPlatformConfigId: str | None = None
