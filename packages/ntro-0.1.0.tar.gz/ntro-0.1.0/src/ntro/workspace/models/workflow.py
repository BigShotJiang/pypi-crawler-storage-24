"""Workflow and capability models."""

from __future__ import annotations

from pydantic import BaseModel


class WorkflowVersion(BaseModel):
    id: str
    workflowId: str
    version: str
    artifactUrl: str | None = None
    createdAt: str | None = None


class Workflow(BaseModel):
    id: str
    name: str
    description: str | None = None
    tenantId: str | None = None
    schedule: str | None = None
    timezone: str | None = None
    latestVersion: str | None = None
    createdAt: str | None = None
    updatedAt: str | None = None


class CreateWorkflowRequest(BaseModel):
    name: str
    description: str | None = None
    tenantId: str | None = None
    schedule: str | None = None
    timezone: str | None = None


class Capability(BaseModel):
    id: str
    name: str
    description: str | None = None
    version: str | None = None
    createdAt: str | None = None


class CreateCapabilityRequest(BaseModel):
    name: str
    description: str | None = None
    version: str | None = None
