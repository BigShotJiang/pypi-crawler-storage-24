"""Common enums and shared types."""

from __future__ import annotations

from enum import Enum
from typing import Generic, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class Provider(str, Enum):
    DATABRICKS = "DATABRICKS"
    SNOWFLAKE = "SNOWFLAKE"
    MICROSOFT_FABRIC = "MICROSOFT_FABRIC"
    GCP_BIGQUERY = "GCP_BIGQUERY"


class Ownership(str, Enum):
    SELF_MANAGED = "SELF_MANAGED"
    NTRO_MANAGED = "NTRO_MANAGED"


class TaskStatus(str, Enum):
    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    BLOCKED = "BLOCKED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class TenantStatus(str, Enum):
    PROVISIONING = "PROVISIONING"
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"


class DeploymentStatus(str, Enum):
    PENDING = "PENDING"
    DEPLOYING = "DEPLOYING"
    DEPLOYED = "DEPLOYED"
    FAILED = "FAILED"


class PaginatedResponse(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int = 1
    pageSize: int = 20
