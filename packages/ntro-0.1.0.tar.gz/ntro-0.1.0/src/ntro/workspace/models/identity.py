"""Identity models."""

from __future__ import annotations

from pydantic import BaseModel


class UserProfile(BaseModel):
    id: str
    email: str
    name: str
    orgId: str
    roles: list[str] = []
