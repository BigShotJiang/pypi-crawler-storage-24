"""Task models (workflow execution instances)."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from ntro.workspace.models.common import TaskStatus


class TaskStep(BaseModel):
    name: str
    status: TaskStatus = TaskStatus.PENDING
    progress: str | None = None


class TaskAssignee(BaseModel):
    id: str
    name: str | None = None


class Task(BaseModel):
    id: str
    title: str | None = None
    status: TaskStatus = TaskStatus.PENDING
    tenantId: str
    entityId: str | None = None
    workflowId: str
    dueDate: str | None = None
    priority: str | None = None
    steps: list[TaskStep] = []
    assignee: TaskAssignee | None = None
    context: dict[str, Any] = {}
    createdAt: str | None = None
    updatedAt: str | None = None


class CreateTaskRequest(BaseModel):
    tenantId: str
    entityId: str | None = None
    workflowId: str
    context: dict[str, Any] = {}
