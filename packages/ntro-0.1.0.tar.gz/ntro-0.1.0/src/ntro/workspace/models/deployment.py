"""Deployment models."""

from __future__ import annotations

from pydantic import BaseModel

from ntro.workspace.models.common import DeploymentStatus


class Deployment(BaseModel):
    id: str
    workflowId: str
    workflowVersionId: str
    tenantId: str | None = None
    entityId: str | None = None
    status: DeploymentStatus = DeploymentStatus.PENDING
    error: str | None = None
    createdAt: str | None = None
    updatedAt: str | None = None


class CreateDeploymentRequest(BaseModel):
    workflowId: str
    workflowVersionId: str
    tenantId: str | None = None
    entityId: str | None = None
