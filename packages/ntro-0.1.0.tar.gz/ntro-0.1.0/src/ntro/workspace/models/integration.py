"""Integration models — data platforms and email sources."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from ntro.workspace.models.common import Ownership, Provider


class DatabricksConfig(BaseModel):
    workspaceUrl: str
    catalog: str
    authType: str = "service-principal"
    clientId: str | None = None
    clientSecret: str | None = None


class DataPlatformConfig(BaseModel):
    id: str
    name: str
    provider: Provider
    ownership: Ownership = Ownership.SELF_MANAGED
    region: str | None = None
    config: dict[str, Any] = {}
    createdAt: str | None = None
    updatedAt: str | None = None


class CreateDataPlatformRequest(BaseModel):
    name: str
    provider: Provider
    ownership: Ownership = Ownership.SELF_MANAGED
    region: str | None = None
    config: dict[str, Any] = {}


class ConnectionTestResult(BaseModel):
    success: bool
    message: str
    latencyMs: int | None = None


class SchemaInfo(BaseModel):
    name: str
    tables: list[str] = []


class EmailIntegration(BaseModel):
    id: str
    tenantId: str
    provider: str
    address: str | None = None
    createdAt: str | None = None


class CreateEmailIntegrationRequest(BaseModel):
    tenantId: str
    provider: str = "microsoft-graph"
    address: str | None = None
