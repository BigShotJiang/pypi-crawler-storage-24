"""Entity models (SPVs / funds within a tenant)."""

from __future__ import annotations

from pydantic import BaseModel


class Entity(BaseModel):
    id: str
    name: str
    slug: str
    tenantId: str
    type: str | None = None
    jurisdiction: str | None = None
    currency: str | None = None
    schema_: str | None = None
    createdAt: str | None = None
    updatedAt: str | None = None

    model_config = {"populate_by_name": True}


class CreateEntityRequest(BaseModel):
    name: str
    slug: str
    type: str | None = None
    jurisdiction: str | None = None
    currency: str | None = None
    schema_: str | None = None

    model_config = {"populate_by_name": True}
