"""Tasks resource — workflow executions."""

from __future__ import annotations

import asyncio
from typing import Any

from ntro.workspace.http import HttpClient
from ntro.workspace.models.task import CreateTaskRequest, Task


class TasksResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def create(self, **kwargs: Any) -> Task:
        dto = CreateTaskRequest(**kwargs)
        data = await self._http.post("/workspace/tasks", json=dto.model_dump(exclude_none=True))
        return Task.model_validate(data)

    def create_sync(self, **kwargs: Any) -> Task:
        return asyncio.run(self.create(**kwargs))

    async def get(self, id: str) -> Task:
        data = await self._http.get(f"/workspace/tasks/{id}")
        return Task.model_validate(data)

    def get_sync(self, id: str) -> Task:
        return asyncio.run(self.get(id))

    async def list_schedule(self) -> list[Task]:
        data = await self._http.get("/workspace/schedule")
        items = data if isinstance(data, list) else data.get("items", data)
        return [Task.model_validate(d) for d in items]

    def list_schedule_sync(self) -> list[Task]:
        return asyncio.run(self.list_schedule())

    async def history(self, tenant_id: str, entity_id: str) -> list[Task]:
        data = await self._http.get(
            f"/workspace/tenants/{tenant_id}/entities/{entity_id}/tasks"
        )
        items = data if isinstance(data, list) else data.get("items", data)
        return [Task.model_validate(d) for d in items]

    def history_sync(self, tenant_id: str, entity_id: str) -> list[Task]:
        return asyncio.run(self.history(tenant_id, entity_id))

    async def list_incoming(self) -> list[dict[str, Any]]:
        data = await self._http.get("/workspace/incoming")
        return data if isinstance(data, list) else data.get("items", data)

    def list_incoming_sync(self) -> list[dict[str, Any]]:
        return asyncio.run(self.list_incoming())

    async def list_pending(self) -> list[dict[str, Any]]:
        data = await self._http.get("/workspace/pending")
        return data if isinstance(data, list) else data.get("items", data)

    def list_pending_sync(self) -> list[dict[str, Any]]:
        return asyncio.run(self.list_pending())
