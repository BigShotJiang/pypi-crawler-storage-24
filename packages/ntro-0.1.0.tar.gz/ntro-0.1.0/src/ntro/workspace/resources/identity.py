"""Identity resource — GET /me."""

from __future__ import annotations

import asyncio

from ntro.workspace.http import HttpClient
from ntro.workspace.models.identity import UserProfile


class IdentityResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def whoami(self) -> UserProfile:
        data = await self._http.get("/me")
        return UserProfile.model_validate(data)

    def whoami_sync(self) -> UserProfile:
        return asyncio.run(self.whoami())
