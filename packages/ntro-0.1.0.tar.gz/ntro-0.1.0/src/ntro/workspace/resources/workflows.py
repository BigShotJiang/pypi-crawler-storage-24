"""Workflows resource."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

from ntro.workspace.http import HttpClient
from ntro.workspace.models.workflow import (
    Capability,
    CreateCapabilityRequest,
    CreateWorkflowRequest,
    Workflow,
    WorkflowVersion,
)


class WorkflowsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def create(self, **kwargs: Any) -> Workflow:
        dto = CreateWorkflowRequest(**kwargs)
        data = await self._http.post(
            "/workspace/registry/workflows", json=dto.model_dump(exclude_none=True)
        )
        return Workflow.model_validate(data)

    def create_sync(self, **kwargs: Any) -> Workflow:
        return asyncio.run(self.create(**kwargs))

    async def list(self) -> list[Workflow]:
        data = await self._http.get("/workspace/registry/workflows")
        items = data if isinstance(data, list) else data.get("items", data)
        return [Workflow.model_validate(d) for d in items]

    def list_sync(self) -> list[Workflow]:
        return asyncio.run(self.list())

    async def get(self, id: str) -> Workflow:
        data = await self._http.get(f"/workspace/registry/workflows/{id}")
        return Workflow.model_validate(data)

    def get_sync(self, id: str) -> Workflow:
        return asyncio.run(self.get(id))

    async def push(self, id: str, artifact: Path) -> WorkflowVersion:
        """Upload a workflow artifact (zip/tar) as a new version."""
        with open(artifact, "rb") as f:
            content = f.read()
        data = await self._http.post(
            f"/workspace/registry/workflows/{id}/versions",
            content=content,
            headers={"Content-Type": "application/octet-stream"},
        )
        return WorkflowVersion.model_validate(data)

    def push_sync(self, id: str, artifact: Path) -> WorkflowVersion:
        return asyncio.run(self.push(id, artifact))

    async def create_capability(self, **kwargs: Any) -> Capability:
        dto = CreateCapabilityRequest(**kwargs)
        data = await self._http.post(
            "/workspace/registry/capabilities", json=dto.model_dump(exclude_none=True)
        )
        return Capability.model_validate(data)

    def create_capability_sync(self, **kwargs: Any) -> Capability:
        return asyncio.run(self.create_capability(**kwargs))
