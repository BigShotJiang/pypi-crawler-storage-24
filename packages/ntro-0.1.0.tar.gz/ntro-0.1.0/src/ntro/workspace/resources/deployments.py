"""Deployments resource."""

from __future__ import annotations

import asyncio
from typing import Any

from ntro.workspace.http import HttpClient
from ntro.workspace.models.deployment import CreateDeploymentRequest, Deployment


class DeploymentsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def create(self, **kwargs: Any) -> Deployment:
        dto = CreateDeploymentRequest(**kwargs)
        data = await self._http.post(
            "/workspace/registry/deployments", json=dto.model_dump(exclude_none=True)
        )
        return Deployment.model_validate(data)

    def create_sync(self, **kwargs: Any) -> Deployment:
        return asyncio.run(self.create(**kwargs))

    async def get(self, id: str) -> Deployment:
        data = await self._http.get(f"/workspace/registry/deployments/{id}")
        return Deployment.model_validate(data)

    def get_sync(self, id: str) -> Deployment:
        return asyncio.run(self.get(id))
