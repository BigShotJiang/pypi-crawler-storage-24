"""Entities resource."""

from __future__ import annotations

import asyncio
from typing import Any

from ntro.workspace.http import HttpClient
from ntro.workspace.models.entity import CreateEntityRequest, Entity


class EntitiesResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def create(self, tenant_id: str, **kwargs: Any) -> Entity:
        dto = CreateEntityRequest(**kwargs)
        data = await self._http.post(
            f"/workspace/tenants/{tenant_id}/entities",
            json=dto.model_dump(exclude_none=True),
        )
        return Entity.model_validate(data)

    def create_sync(self, tenant_id: str, **kwargs: Any) -> Entity:
        return asyncio.run(self.create(tenant_id, **kwargs))

    async def list(self, tenant_id: str | None = None) -> list[Entity]:
        if tenant_id:
            data = await self._http.get(f"/workspace/tenants/{tenant_id}/entities")
        else:
            data = await self._http.get("/workspace/entities")
        items = data if isinstance(data, list) else data.get("items", data)
        return [Entity.model_validate(d) for d in items]

    def list_sync(self, tenant_id: str | None = None) -> list[Entity]:
        return asyncio.run(self.list(tenant_id))
