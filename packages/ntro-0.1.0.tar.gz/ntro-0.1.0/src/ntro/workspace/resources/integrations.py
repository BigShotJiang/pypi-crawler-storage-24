"""Integrations resource — data platforms and email sources."""

from __future__ import annotations

import asyncio
from typing import Any

from ntro.workspace.http import HttpClient
from ntro.workspace.models.integration import (
    ConnectionTestResult,
    CreateDataPlatformRequest,
    CreateEmailIntegrationRequest,
    DataPlatformConfig,
    EmailIntegration,
    SchemaInfo,
)


class IntegrationsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def create_data_platform(self, **kwargs: Any) -> DataPlatformConfig:
        dto = CreateDataPlatformRequest(**kwargs)
        data = await self._http.post("/workspace/data", json=dto.model_dump(exclude_none=True))
        return DataPlatformConfig.model_validate(data)

    def create_data_platform_sync(self, **kwargs: Any) -> DataPlatformConfig:
        return asyncio.run(self.create_data_platform(**kwargs))

    async def list_data_platforms(self) -> list[DataPlatformConfig]:
        data = await self._http.get("/workspace/data")
        items = data if isinstance(data, list) else data.get("items", data)
        return [DataPlatformConfig.model_validate(d) for d in items]

    def list_data_platforms_sync(self) -> list[DataPlatformConfig]:
        return asyncio.run(self.list_data_platforms())

    async def get_data_platform(self, id: str) -> DataPlatformConfig:
        data = await self._http.get(f"/workspace/data/{id}")
        return DataPlatformConfig.model_validate(data)

    def get_data_platform_sync(self, id: str) -> DataPlatformConfig:
        return asyncio.run(self.get_data_platform(id))

    async def test_connection(self, id: str) -> ConnectionTestResult:
        data = await self._http.post(f"/workspace/data/{id}/test")
        return ConnectionTestResult.model_validate(data)

    def test_connection_sync(self, id: str) -> ConnectionTestResult:
        return asyncio.run(self.test_connection(id))

    async def discover_schemas(self, id: str) -> list[SchemaInfo]:
        data = await self._http.get(f"/workspace/data/{id}/schemas")
        items = data if isinstance(data, list) else data.get("items", data)
        return [SchemaInfo.model_validate(d) for d in items]

    def discover_schemas_sync(self, id: str) -> list[SchemaInfo]:
        return asyncio.run(self.discover_schemas(id))

    async def list_platform_tenants(self, id: str) -> list[dict[str, Any]]:
        data = await self._http.get(f"/workspace/data/{id}/tenants")
        return data if isinstance(data, list) else data.get("items", data)

    def list_platform_tenants_sync(self, id: str) -> list[dict[str, Any]]:
        return asyncio.run(self.list_platform_tenants(id))

    async def create_email(self, **kwargs: Any) -> EmailIntegration:
        dto = CreateEmailIntegrationRequest(**kwargs)
        data = await self._http.post("/workspace/integrations/email", json=dto.model_dump(exclude_none=True))
        return EmailIntegration.model_validate(data)

    def create_email_sync(self, **kwargs: Any) -> EmailIntegration:
        return asyncio.run(self.create_email(**kwargs))

    async def list_all(self) -> list[dict[str, Any]]:
        data = await self._http.get("/workspace/integrations")
        return data if isinstance(data, list) else data.get("items", data)

    def list_all_sync(self) -> list[dict[str, Any]]:
        return asyncio.run(self.list_all())
