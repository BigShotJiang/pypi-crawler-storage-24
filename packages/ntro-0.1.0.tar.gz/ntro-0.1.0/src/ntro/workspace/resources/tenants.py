"""Tenants resource."""

from __future__ import annotations

import asyncio
from typing import Any

from ntro.workspace.http import HttpClient
from ntro.workspace.models.tenant import CreateTenantRequest, Tenant


class TenantsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def create(self, **kwargs: Any) -> Tenant:
        dto = CreateTenantRequest(**kwargs)
        data = await self._http.post("/workspace/tenants", json=dto.model_dump(exclude_none=True))
        return Tenant.model_validate(data)

    def create_sync(self, **kwargs: Any) -> Tenant:
        return asyncio.run(self.create(**kwargs))

    async def list(self) -> list[Tenant]:
        data = await self._http.get("/workspace/tenants")
        items = data if isinstance(data, list) else data.get("items", data)
        return [Tenant.model_validate(d) for d in items]

    def list_sync(self) -> list[Tenant]:
        return asyncio.run(self.list())

    async def get(self, id: str) -> Tenant:
        data = await self._http.get(f"/workspace/tenants/{id}")
        return Tenant.model_validate(data)

    def get_sync(self, id: str) -> Tenant:
        return asyncio.run(self.get(id))
