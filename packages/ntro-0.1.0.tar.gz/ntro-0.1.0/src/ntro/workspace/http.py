"""httpx wrapper with auth injection, retry logic, and error mapping."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import httpx

from ntro.workspace.exceptions import (
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    NotFoundError,
    NtroAPIError,
    NtroConnectionError,
    ValidationError,
)

logger = logging.getLogger("ntro.http")

_MAX_RETRIES = 3
_RETRY_BACKOFF_BASE = 0.5  # seconds


def _make_error(status_code: int, body: Any) -> NtroAPIError:
    message = body.get("message", str(body)) if isinstance(body, dict) else str(body)
    detail = body.get("error") if isinstance(body, dict) else None
    kwargs = dict(status_code=status_code, message=message, detail=detail)
    if status_code == 401:
        return AuthenticationError(**kwargs)
    if status_code == 403:
        return AuthorizationError(**kwargs)
    if status_code == 404:
        return NotFoundError(**kwargs)
    if status_code == 409:
        return ConflictError(**kwargs)
    if status_code == 422:
        return ValidationError(**kwargs)
    return NtroAPIError(**kwargs)


class HttpClient:
    """Async httpx client with auth, retry, and error mapping."""

    def __init__(self, base_url: str, api_key: str, debug: bool = False) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._debug = debug
        self._client: httpx.AsyncClient | None = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            headers: dict[str, str] = {"Content-Type": "application/json"}
            if self._api_key:
                headers["Authorization"] = f"Bearer {self._api_key}"
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                headers=headers,
                timeout=30.0,
            )
        return self._client

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        client = self._get_client()
        url = path if path.startswith("/") else f"/{path}"

        for attempt in range(_MAX_RETRIES):
            try:
                if self._debug:
                    logger.debug("%s %s%s kwargs=%s", method.upper(), self._base_url, url, kwargs)

                t0 = time.monotonic()
                response = await client.request(method, url, **kwargs)
                elapsed = (time.monotonic() - t0) * 1000

                if self._debug:
                    logger.debug(
                        "%s %s → %d (%.0fms)", method.upper(), url, response.status_code, elapsed
                    )

                if response.status_code >= 400:
                    try:
                        body = response.json()
                    except Exception:
                        body = response.text
                    raise _make_error(response.status_code, body)

                if response.status_code == 204 or not response.content:
                    return None

                return response.json()

            except NtroAPIError:
                raise
            except httpx.TimeoutException as exc:
                if attempt == _MAX_RETRIES - 1:
                    raise NtroConnectionError(f"Request timed out: {method.upper()} {url}") from exc
            except httpx.ConnectError as exc:
                raise NtroConnectionError(
                    f"Could not connect to {self._base_url}. Is the API running?"
                ) from exc
            except httpx.HTTPError as exc:
                if attempt == _MAX_RETRIES - 1:
                    raise NtroConnectionError(f"HTTP error: {exc}") from exc

            # Exponential backoff for retries (only on timeout/5xx)
            await asyncio.sleep(_RETRY_BACKOFF_BASE * (2**attempt))

        raise NtroConnectionError("Max retries exceeded")  # unreachable but satisfies type checker

    async def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return await self._request("GET", path, params=params)

    async def post(self, path: str, json: Any = None, **kwargs: Any) -> Any:
        return await self._request("POST", path, json=json, **kwargs)

    async def put(self, path: str, json: Any = None) -> Any:
        return await self._request("PUT", path, json=json)

    async def patch(self, path: str, json: Any = None) -> Any:
        return await self._request("PATCH", path, json=json)

    async def delete(self, path: str) -> Any:
        return await self._request("DELETE", path)
