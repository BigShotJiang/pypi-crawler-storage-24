"""Main Client class for the ntro Workspace API."""

from __future__ import annotations

import os

from ntro.workspace.config import ConnectionConfig, load_config
from ntro.workspace.http import HttpClient
from ntro.workspace.resources.deployments import DeploymentsResource
from ntro.workspace.resources.entities import EntitiesResource
from ntro.workspace.resources.identity import IdentityResource
from ntro.workspace.resources.integrations import IntegrationsResource
from ntro.workspace.resources.tasks import TasksResource
from ntro.workspace.resources.tenants import TenantsResource
from ntro.workspace.resources.workflows import WorkflowsResource


class Client:
    """Workspace API client.

    Usage:
        # From config file (reads ~/.ntro/config.toml)
        client = Client.from_config()
        client = Client.from_config(connection="staging")

        # Explicit (for scripting / testing)
        client = Client(host="http://localhost:3000/v1", api_key="ntro_dev_key")
    """

    def __init__(
        self,
        host: str = "https://api.ntropii.com/v1",
        api_key: str = "",
        debug: bool = False,
    ) -> None:
        self._http = HttpClient(base_url=host, api_key=api_key, debug=debug)
        self.identity = IdentityResource(self._http)
        self.integrations = IntegrationsResource(self._http)
        self.tenants = TenantsResource(self._http)
        self.entities = EntitiesResource(self._http)
        self.workflows = WorkflowsResource(self._http)
        self.deployments = DeploymentsResource(self._http)
        self.tasks = TasksResource(self._http)

    @classmethod
    def from_config(
        cls,
        connection: str | None = None,
        debug: bool = False,
    ) -> "Client":
        """Create a Client from ~/.ntro/config.toml.

        Resolution priority:
        1. NTRO_HOST / NTRO_API_KEY env vars (override config)
        2. Named connection (--connection flag or NTRO_DEFAULT_CONNECTION_NAME env var)
        3. default_connection_name in config.toml
        """
        conn_name = connection or os.environ.get("NTRO_DEFAULT_CONNECTION_NAME")
        config = load_config()
        conn: ConnectionConfig = config.get_connection(conn_name)

        host = os.environ.get("NTRO_HOST") or conn.host
        api_key = os.environ.get("NTRO_API_KEY") or conn.api_key

        return cls(host=host, api_key=api_key, debug=debug)

    async def close(self) -> None:
        await self._http.close()
