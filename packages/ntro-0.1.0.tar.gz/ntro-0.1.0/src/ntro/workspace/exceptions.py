"""Typed exceptions for the ntro SDK."""

from __future__ import annotations


class NtroError(Exception):
    """Base class for all ntro SDK errors."""


class NtroAPIError(NtroError):
    """An error response from the Workspace API."""

    def __init__(self, status_code: int, message: str, detail: object = None) -> None:
        self.status_code = status_code
        self.message = message
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {message}")


class NotFoundError(NtroAPIError):
    """404 — Resource not found."""


class AuthenticationError(NtroAPIError):
    """401 — Invalid or missing API key."""


class AuthorizationError(NtroAPIError):
    """403 — Insufficient permissions."""


class ValidationError(NtroAPIError):
    """422 — Request validation failed."""


class ConflictError(NtroAPIError):
    """409 — Resource already exists."""


class NtroConnectionError(NtroError):
    """Failed to connect to the API (network error, timeout, etc.)."""


class ConfigError(NtroError):
    """Invalid or missing configuration."""
