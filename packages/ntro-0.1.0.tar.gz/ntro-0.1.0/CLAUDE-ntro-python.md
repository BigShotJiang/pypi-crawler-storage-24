# ntro-python — Official Python SDK for the ntro platform

## Project Overview

This is the official Python SDK for the **ntro** platform. It provides the `ntro` package on PyPI.

| Install | Import | What you get |
|---------|--------|-------------|
| `pip install ntro` | `from ntro.workspace import Client` | Workspace API client (control plane) |
| (future) | `from ntro.workflow import workflow, activity` | Workflow framework (data plane) |

**Today this repo contains `ntro.workspace` — the Python client for the Workspace API.** The workflow framework will be added later as `ntro.workflow` with optional dependency groups.

The ntro platform automates fund administration (NAV calculation, document extraction, GL classification) for private markets firms. The Workspace API is the control plane backend (a separate TypeScript/NestJS service). This SDK is the Python interface to that API.

**Naming convention:** follows the `{brand}-python` pattern used by Stripe (`stripe-python`), Auth0 (`auth0-python`), and Twilio (`twilio-python`). The repo is `ntro-python`, the PyPI package is `ntro`, the import is `from ntro import ...`.

---

## Architecture

```
┌─────────────┐  ┌─────────────┐
│   ntro-cli  │  │  ntro-mcp   │   ← Separate repos, thin interface layers
│   (Typer)   │  │  (future)   │
└──────┬──────┘  └──────┬──────┘
       │                │
       ▼                ▼
┌─────────────────────────────┐
│     ntro (this package)     │   ← httpx + Pydantic, async-first
│     ntro.workspace          │
└──────────────┬──────────────┘
               │ HTTP/REST
               ▼
┌─────────────────────────────┐
│  Workspace API (TypeScript) │   ← Separate repo (NestJS)
│  https://api.ntropii.com/v1│
└─────────────────────────────┘
```

### Related repos

| Repo | PyPI package | Binary | Purpose |
|------|-------------|--------|---------|
| **ntro-python** (this) | `ntro` | — | Python SDK |
| ntro-cli | `ntro-cli` | `ntro` | CLI tool |
| ntro-mcp | `ntro-mcp` | `ntro-mcp` | MCP server for Claude (future) |
| ntro-workspace-api | — | — | TypeScript/NestJS backend |

---

## Repository Structure

```
ntro-python/
├── CLAUDE.md                        # ← This file
├── pyproject.toml                   # Package metadata, dependencies, build config
├── README.md
│
├── src/
│   └── ntro/
│       ├── __init__.py              # Top-level exports
│       │
│       └── workspace/               # Workspace API client (control plane)
│           ├── __init__.py          # Exports Client
│           ├── client.py            # Main client class, resource mounting
│           ├── config.py            # TOML config loading (~/.ntro/config.toml, env vars)
│           ├── auth.py              # Auth handling (API key for PoC, OAuth future)
│           ├── exceptions.py        # Typed exceptions (NtroAPIError, NotFoundError, etc.)
│           ├── http.py              # httpx wrapper, retry logic, error mapping
│           │
│           ├── models/              # Pydantic v2 models (request/response DTOs)
│           │   ├── __init__.py
│           │   ├── common.py        # Pagination, enums (Provider, Status, etc.)
│           │   ├── identity.py      # UserProfile
│           │   ├── integration.py   # DataPlatformConfig, EmailIntegration, SchemaInfo
│           │   ├── tenant.py        # Tenant, CreateTenantRequest
│           │   ├── entity.py        # Entity, CreateEntityRequest
│           │   ├── workflow.py      # Workflow, WorkflowVersion, Capability
│           │   ├── deployment.py    # Deployment, DeploymentStatus
│           │   └── task.py          # Task, TaskStep, TaskStatus
│           │
│           └── resources/           # API resource classes (one per domain)
│               ├── __init__.py
│               ├── identity.py      # IdentityResource — GET /me
│               ├── integrations.py  # IntegrationsResource — /workspace/data/*, /workspace/integrations/*
│               ├── tenants.py       # TenantsResource — /workspace/tenants/*
│               ├── entities.py      # EntitiesResource — /workspace/entities, /workspace/tenants/{id}/entities
│               ├── workflows.py     # WorkflowsResource — /workspace/registry/workflows/*
│               ├── deployments.py   # DeploymentsResource — /workspace/registry/deployments/*
│               └── tasks.py         # TasksResource — /workspace/tasks/*, /workspace/schedule, etc.
│
├── tests/
│   ├── unit/                        # Mocked HTTP via respx
│   └── integration/                 # Against running API
│
└── docs/
```

---

## Package Configuration

```toml
# pyproject.toml
[project]
name = "ntro"
version = "0.1.0"
description = "Official Python SDK for the ntro platform"
requires-python = ">=3.11"
dependencies = [
    "httpx>=0.27",
    "pydantic>=2.7",
    "tomli-w>=1.0",
]

[project.optional-dependencies]
# Future: workflow framework deps
# workflow = ["temporalio>=1.7", "pdfplumber>=0.11"]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.23",
    "respx>=0.21",
    "ruff>=0.4",
    "mypy>=1.10",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/ntro"]
```

---

## SDK Design

### Client

```python
from ntro.workspace import Client

# From config file (reads ~/.ntro/config.toml)
client = Client.from_config()                         # uses default connection
client = Client.from_config(connection="staging")      # specific connection

# Explicit (for scripting / testing)
client = Client(
    host="http://localhost:3000/v1",
    api_key="ntro_test_key",
)

# Async (MCP server, notebooks)
tenant = await client.tenants.create(name="Acme", slug="acme", data_platform_config_id="dpc_123")

# Sync (CLI, simple scripts)
tenant = client.tenants.create_sync(name="Acme", slug="acme", data_platform_config_id="dpc_123")
```

### Resource Pattern

```python
# src/ntro/workspace/resources/tenants.py
from ntro.workspace.http import HttpClient
from ntro.workspace.models.tenant import Tenant, CreateTenantRequest

class TenantsResource:
    def __init__(self, http: HttpClient):
        self._http = http

    async def create(self, *, name: str, slug: str, data_platform_config_id: str) -> Tenant:
        dto = CreateTenantRequest(name=name, slug=slug, data_platform_config_id=data_platform_config_id)
        response = await self._http.post("/workspace/tenants", json=dto.model_dump())
        return Tenant.model_validate(response)

    def create_sync(self, **kwargs) -> Tenant:
        return asyncio.run(self.create(**kwargs))

    async def list(self) -> list[Tenant]:
        response = await self._http.get("/workspace/tenants")
        return [Tenant.model_validate(t) for t in response]

    def list_sync(self) -> list[Tenant]:
        return asyncio.run(self.list())

    async def get(self, id: str) -> Tenant:
        response = await self._http.get(f"/workspace/tenants/{id}")
        return Tenant.model_validate(response)

    def get_sync(self, id: str) -> Tenant:
        return asyncio.run(self.get(id))
```

### HTTP Client

Use **httpx** with:
- Async by default (`httpx.AsyncClient`)
- Sync wrappers using `asyncio.run()` for CLI consumers
- Base URL injection from config
- Auth header injection (`Authorization: Bearer <api_key>`)
- Automatic retry with exponential backoff for 5xx errors
- Error mapping: 404 → `NotFoundError`, 422 → `ValidationError`, 401 → `AuthenticationError`
- Request/response logging at DEBUG level

### Pydantic Models

All request and response bodies are Pydantic v2 models:

```python
# src/ntro/workspace/models/common.py
from enum import Enum

class Provider(str, Enum):
    DATABRICKS = "DATABRICKS"
    SNOWFLAKE = "SNOWFLAKE"
    MICROSOFT_FABRIC = "MICROSOFT_FABRIC"
    GCP_BIGQUERY = "GCP_BIGQUERY"

class TaskStatus(str, Enum):
    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    BLOCKED = "BLOCKED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"

class TenantStatus(str, Enum):
    PROVISIONING = "PROVISIONING"
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"
```

### Configuration (TOML, Snowflake CLI-style connections)

Config follows the Snowflake CLI convention (`config.toml` with `[connections.<n>]` sections).

**Config file:** `~/.ntro/config.toml`

```toml
# ~/.ntro/config.toml

default_connection_name = "local"

[connections.local]
host = "http://localhost:3000/v1"
api_key = "ntro_dev_key"
default_tenant = "acme-fund-admin"

[connections.staging]
host = "https://staging.api.ntropii.com/v1"
api_key = "ntro_staging_key"
default_tenant = "test-fund-admin"

[connections.production]
host = "https://api.ntropii.com/v1"
api_key = "ntro_prod_key"
default_tenant = "acme-fund-admin"

[cli]
output_format = "table"

[cli.logs]
save_logs = true
level = "info"
path = "~/.ntro/logs"
```

**Resolution priority:**
1. Explicit constructor args
2. Environment variables: `NTRO_HOST`, `NTRO_API_KEY`
3. Per-connection env var overrides: `NTRO_CONNECTIONS_<n>_API_KEY`
4. Named connection in config.toml
5. `default_connection_name` in config.toml

**Config file location:**
1. `NTRO_HOME` env var → `$NTRO_HOME/config.toml`
2. `~/.ntro/config.toml`

Parsed with Python 3.11+ built-in `tomllib` (read) and `tomli_w` (write).

---

## Endpoint → SDK Method Mapping

### Phase 0 — Bootstrap
| API Endpoint | SDK Method |
|---|---|
| `GET /me` | `client.identity.whoami()` |

### Phase 1 — Data Platform & Integrations
| API Endpoint | SDK Method |
|---|---|
| `POST /workspace/data` | `client.integrations.create_data_platform()` |
| `GET /workspace/data` | `client.integrations.list_data_platforms()` |
| `GET /workspace/data/{id}` | `client.integrations.get_data_platform(id)` |
| `POST /workspace/data/{id}/test` | `client.integrations.test_connection(id)` |
| `GET /workspace/data/{id}/schemas` | `client.integrations.discover_schemas(id)` |
| `GET /workspace/data/{id}/tenants` | `client.integrations.list_platform_tenants(id)` |
| `POST /workspace/integrations/email` | `client.integrations.create_email(...)` |
| `GET /workspace/integrations` | `client.integrations.list_all()` |

### Phase 2 — Tenant & Entity
| API Endpoint | SDK Method |
|---|---|
| `POST /workspace/tenants` | `client.tenants.create()` |
| `GET /workspace/tenants` | `client.tenants.list()` |
| `GET /workspace/tenants/{id}` | `client.tenants.get(id)` |
| `POST /workspace/tenants/{id}/entities` | `client.entities.create(tenant_id, ...)` |
| `GET /workspace/entities` | `client.entities.list()` |

### Phase 3 — Workflow Registry
| API Endpoint | SDK Method |
|---|---|
| `POST /workspace/registry/workflows` | `client.workflows.create()` |
| `GET /workspace/registry/workflows` | `client.workflows.list()` |
| `GET /workspace/registry/workflows/{id}` | `client.workflows.get(id)` |
| `POST /workspace/registry/workflows/{id}/versions` | `client.workflows.push(id, artifact)` |
| `POST /workspace/registry/capabilities` | `client.workflows.create_capability()` |

### Phase 4 — Deployment
| API Endpoint | SDK Method |
|---|---|
| `POST /workspace/registry/deployments` | `client.deployments.create()` |
| `GET /workspace/registry/deployments/{id}` | `client.deployments.get(id)` |

### Phase 5 — Execution
| API Endpoint | SDK Method |
|---|---|
| `POST /workspace/tasks` | `client.tasks.create()` |
| `GET /workspace/tasks/{id}` | `client.tasks.get(id)` |
| `GET /workspace/schedule` | `client.tasks.list_schedule()` |
| `GET /workspace/tenants/{tid}/entities/{eid}/tasks` | `client.tasks.history(tenant_id, entity_id)` |
| `GET /workspace/incoming` | `client.tasks.list_incoming()` |
| `GET /workspace/pending` | `client.tasks.list_pending()` |

---

## Build Order

1. **Scaffold** — pyproject.toml, directory structure, dev tooling
2. **Core** — `http.py` (httpx wrapper), `config.py` (TOML loading), `auth.py`, `exceptions.py`
3. **Phase 0** — `resources/identity.py` + `models/identity.py` → `client.identity.whoami()`
4. **Phase 1** — `resources/integrations.py` + `models/integration.py`
5. **Phase 2** — `resources/tenants.py` + `resources/entities.py` + models
6. **Phase 3** — `resources/workflows.py` + models
7. **Phase 4** — `resources/deployments.py` + models
8. **Phase 5** — `resources/tasks.py` + models

Each phase: resource + models → unit tests (mocked HTTP via respx).

---

## PoC Scope

### In scope
- All P0 SDK methods (18 endpoints)
- TOML config file support
- Async + sync wrappers
- Pydantic v2 models (hand-written)
- Unit tests with respx

### Excluded
- `ntro.workflow` module (workflow framework — future)
- OAuth / OIDC auth (PoC uses API key)
- Auto-generated models from OpenAPI spec
- PyPI publishing

---

## Domain Context

- **Tenant** = client organisation (fund admin or asset manager). Contains entities.
- **Entity** = SPV or fund within a tenant. Own schema in customer's Databricks.
- **Workflow** = repeatable process (NAV calc, doc ingestion, period close). Registered, deployed, triggered.
- **Task** = running instance of a workflow, scoped to an entity.
- **Data Platform** = customer's Databricks/Snowflake/Fabric where financial data lives.
- **Built-in workflows** = `coa-import`, `document-ingest`, `nav-monthly`, `period-close`.
