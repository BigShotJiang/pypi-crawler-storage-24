# entropymon

**Terminal system monitor by Electric Entropy Lab**

A powerful, feature-rich terminal system monitor built with Python curses. Better than glances, prettier than htop.

## Features

- **CPU** - per-core usage bars, sparkline history, frequency, load average
- **Memory** - RAM/Swap with usage bars
- **Disk** - partitions with usage, IO rates (read/write)
- **Network** - RX/TX rates with sparklines, per-interface info
- **GPU** - NVIDIA (via NVML) and AMD (via sysfs) - utilization, VRAM, temp, power, fan, clocks
- **Temperatures** - CPU, GPU, NVMe, network adapters
- **Processes** - interactive management with sorting, filtering, kill signals, renice, details
- **Multi-language** - EN, PL, DE, ES, FR, UK, ZH with runtime switching
- **Animated intro** - matrix rain boot sequence with decrypt logo animation

## Install

```bash
pip install entropymon
```

With NVIDIA GPU support:

```bash
pip install entropymon[nvidia]
```

## Usage

```bash
entropymon                 # start with auto-detected language
entropymon --lang pl       # start in Polish
entropymon --no-intro      # skip boot animation
entropymon --reset-lang    # reset saved language preference
entropymon --version       # show version
```

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `h` / `F1` / `?` | Help overlay |
| `L` | Switch language |
| `c` / `m` / `p` / `n` | Sort by CPU/MEM/PID/Name |
| `r` | Reverse sort |
| `j` / `k` / arrows | Navigate processes |
| `T` | Send SIGTERM |
| `K` | Send SIGKILL |
| `F9` | Signal selection menu |
| `+` / `-` | Renice process |
| `d` / `F5` / Enter | Process details |
| `/` / `f` | Filter processes |
| `q` / `Esc` | Quit |

## Requirements

- Python 3.8+
- Linux (uses `/proc`, `/sys`)
- psutil
- pynvml (optional, for NVIDIA GPU)

## License

MIT - Electric Entropy Lab
