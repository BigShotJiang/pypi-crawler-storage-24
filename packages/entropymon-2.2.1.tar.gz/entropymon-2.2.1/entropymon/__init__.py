"""entropymon - Terminal system monitor by Electric Entropy Lab."""

__version__ = "2.2.1"
