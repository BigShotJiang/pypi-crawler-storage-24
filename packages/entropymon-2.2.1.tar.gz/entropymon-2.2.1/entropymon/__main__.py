"""Allow running as: python -m entropymon"""
from entropymon.monitor import main

if __name__ == "__main__":
    main()
