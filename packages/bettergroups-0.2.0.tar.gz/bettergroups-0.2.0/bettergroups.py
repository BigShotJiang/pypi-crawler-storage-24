from collections import Counter
from random import choice, shuffle
from inspect import getmembers, isfunction

# made by Finni

__all__ = ['BetterLists', 'BetterDicts', 'groupby', 'chunk', 'public_methods']

__version__ = "0.2.0"

def public_methods(cls):
    '''shows all of the methods inside of a class'''
    return [
        name for name, obj in getmembers(cls, isfunction)
        if not name.startswith("_")
    ]

def groupby(iterable, key_func):
        result = {}
        for item in iterable:
            key = key_func(item)
            result.setdefault(key, []).append(item)
        return result

def chunk(iterable, size):
    '''split an iterable into chunks of a given size'''
    return [iterable[i:i+size] for i in range(0, len(iterable), size)]

class BetterDicts:
    def __init__(self, d=None):
        if d is None: # check if input was made, if not keep the list empty
            self.data = {}
        else: # if there is input for the list make the input
            self.data = dict(d)
        self.locked = False
        # self.original = self.data

    def add(self, name, value):
        '''add to a dictionary'''
        if self.locked:
            raise RuntimeError("Object is locked")
        self.data[name] = value

    def remove(self, name):
        '''remove from a dictionary'''
        if self.locked:
            raise RuntimeError("Object is locked")
        del self.data[name]
    
    def add_many(self, other_dict):
        if self.locked:
            raise RuntimeError("Object is locked")
        for k, v in other_dict.items():
            self.data[k] = self.data.get(k, 0) + v

    def subtract_many(self, other_dict):
        if self.locked:
            raise RuntimeError('Object is locked')
        for k, v in other_dict.items():
            if k in self.data:
                self.data[k] -= v
    
    def pop(self, key, default=None):
        '''pop something from a dictionary'''
        if self.locked:
            raise RuntimeError("Object is locked")
        return self.data.pop(key, default)

    def invert(self):
        '''returns an inverted version of itself'''
        return BetterDicts({v: k for k, v in self.data.items()})

    def dupe(self):
        '''duplicate a dictionary'''
        return BetterDicts(self.data.copy())

    def combine(self, other):
        '''combine two dictionarys'''
        if isinstance(other, BetterDicts):
            other = other.data
        elif not isinstance(other, dict):
            raise TypeError("Can only combine with dict or BetterDicts")

        new_data = self.data.copy()

        for key, value in other.items():
            if key in new_data:
                if isinstance(new_data[key], list):
                    new_data[key].append(value)
                else:
                    new_data[key] = [new_data[key], value]
            else:
                new_data[key] = value

        return BetterDicts(new_data)
    
    def get(self, keyname, default=None):
        '''return the value of a key'''
        return self.data.get(keyname, default)

    def empty(self):
        '''Empty everything inside a dictionary'''
        if self.locked:
            raise RuntimeError("Object is locked")
        self.data.clear()

    def copy(self):
        '''return a copy of itself'''
        return BetterDicts(self.data.copy())

    def map_values(self, func):
        return BetterDicts({k: func(v) for k, v in self.data.items()})

    def filter(self, func):
        return BetterDicts({k: v for k, v in self.data.items() if func(k, v)})

    def keys(self):
        return self.data.keys()

    def values(self):
        return self.data.values()

    def items(self):
        return self.data.items()

    def lock(self):
        '''make an object uneditable'''
        self.locked = True

    def unlock(self):
        '''make an object editable'''
        self.locked = False

    def __str__(self):
        return str(self.data)
    def __repr__(self):
        return f"BetterDicts(data:{self.data},locked:{self.locked})"
    def __len__(self):
        return len(self.data)
    def __getitem__(self, key):
        return self.data[key]
    def __setitem__(self, key, value):
        if self.locked:
            raise RuntimeError("Object is locked")
        self.data[key] = value
    def __delitem__(self, key):
        if self.locked:
            raise RuntimeError("Object is locked")
        del self.data[key]
    def __contains__(self, key):
        return key in self.data
    def __iter__(self):
        return iter(self.data)
    def __eq__(self, other):
        if isinstance(other, BetterDicts):
            return self.data == other.data
        if isinstance(other, dict):
            return self.data == other
        return False
    def __bool__(self):
        return bool(self.data)
    def __or__(self, other):
        return self.combine(other)

class BetterLists:
    def __init__(self, d=None):
        if d is None: # check if input was made, if not keep the list empty
            self.data = []
        else: # if there is input for the list make the input
            self.data = list(d)
        self.locked = False
    def add(self, d):
        '''add something to a list'''
        if self.locked:
            raise RuntimeError("Object is locked")
        self.data.append(d)

    def remove(self,d):
        '''remove something from a list'''
        if self.locked:
            raise RuntimeError("Object is locked")
        self.data.remove(d)

    def dupe(self):
        '''copy a list to a new list'''
        return BetterLists(self.data.copy())

    def gte(self, value):
        '''return a new list with all the values that are greater than the input'''
        returns = BetterLists()
        for i in self.data:
            if i >= value:
                returns.add(i)
        
        return returns

    greater_than = gte

    def lte(self, value):
        '''return a new list with all the values that are less than the input'''
        returns = BetterLists()
        for i in self.data:
            if i <= value:
                returns.add(i)
        
        return returns

    less_than = lte

    def sorted_new(self, reverse=False):
        '''return a new sorted version of a list'''
        return BetterLists(sorted(self.data, reverse=reverse))
    
    def combine(self, other):
        '''return a list combined with another list'''
        if isinstance(other, BetterLists):
            return BetterLists(self.data + other.data)
        raise TypeError("Must combine with another BetterLists")
    
    def insert(self,d,pos):
        '''insert data to a position of a list'''
        if self.locked:
            raise RuntimeError("Object is locked")
        self.data.insert(pos,d)

    def count(self, char):
        '''count the instances of a character'''
        return self.data.count(char)

    def countinfo(self, char):
        '''count the instances of a character with extra info'''
        return f'character: {char}, shows {self.data.count(char)} times' 

    def reversed(self):
        '''returns itself reversed'''
        return BetterLists(self.data[::-1])

    def sum(self):
        '''return the sum of a list'''
        return sum(self.data)
    
    def average(self):
        '''returns the average number in a list'''
        return sum(self.data) / len(self.data)

    def reverse(self):
        '''reverses itself'''
        if self.locked:
            raise RuntimeError("Object is locked")
        self.data.reverse()

    def return_all_types(self, t):
        '''return all instances of a certant type in a list'''
        returns = BetterLists()

        if not isinstance(t, type): # check if t is a type
            raise TypeError('Expected a type')

        for i in range(len(self.data)):
            if isinstance(self.data[i], t):
                returns.add(self.data[i])

        return returns

    rtypes = return_all_types

    def returnstrs(self):
        '''return all the strings inside of a list'''
        return self.return_all_types(str) 

    def returnints(self):
        '''return all the ints inside of a list'''
        return self.return_all_types(int)

    def returnlists(self):
        '''return all the lists inside of a list'''
        return self.return_all_types(list)
    
    def returndicts(self):
        '''return all the dicts inside of a list'''
        return self.return_all_types(dict)
    
    def even(self):
        '''return all even numbers in a list'''
        returns = BetterLists()
        nums_in_data = self.returnints()
            
        for num in nums_in_data:
            if num % 2 == 0:
                returns.add(num)

        return returns

    def countall(self):
        '''count everything inside of a list'''
        return Counter(self.data)
    
    def unique(self, reversed=False):
        '''return every unique item in a list'''
        if not reversed:
            return BetterLists(list(dict.fromkeys(self.data)))
        return BetterLists(list(dict.fromkeys(self.data[::-1])))

    def empty(self):
        '''clear everything inside a list'''
        if self.locked:
            raise RuntimeError("Object is locked")
        self.data.clear()

    def extend(self, other):
        '''add elements from an iterable'''
        if self.locked:
            raise RuntimeError("Object is locked")
        if isinstance(other, BetterLists):
            other = other.data
        if isinstance(other, BetterDicts):
            other = other.data
        self.data.extend(other)

    def filter(self, func):
        return BetterLists([x for x in self.data if func(x)])

    def map(self, func):
        return BetterLists([func(x) for x in self.data])

    def first(self):
        '''return the first item in a list'''
        return self.data[0] if self.data else None

    def last(self):
        '''return the last item in a list'''
        return self.data[-1] if self.data else None

    def randitem(self):
        '''return a random item inside of a list'''
        return choice(self.data)

    def randorder(self):
        '''shuffle a list like a deck of cards'''
        shuffle(self.data)

    def lock(self):
        '''make an object uneditable'''
        self.locked = True
    
    def unlock(self):
        '''make an object editable'''
        self.locked = False

    def __str__(self):
        return f'{self.data}'
    def __len__(self):
        return len(self.data)
    def __getitem__(self, index):
        return self.data[index]
    def __iter__(self):
        return iter(self.data)
    def __contains__(self, item):
        return item in self.data
    def __repr__(self):
        return f"BetterLists(data:{self.data},locked:{self.locked})"
    def __bool__(self):
        return bool(self.data)
    def __add__(self, other):
        if isinstance(other, BetterLists):
            return BetterLists(self.data + other.data)
        raise TypeError

if __name__ == "__main__":
    pass