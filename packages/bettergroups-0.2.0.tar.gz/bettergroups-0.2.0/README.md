# bettergroups

Lightweight enhanced list and dictionary utilities for Python.

## Features

- BetterLists
- BetterDicts
- groupby
- chunk
- Lockable structures
- Map / Filter helpers

## Installation

pip install bettergroups