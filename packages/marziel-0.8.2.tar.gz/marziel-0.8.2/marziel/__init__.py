"""
Marziel AI — Private Intelligence, Locally Powered.

pip install marziel
marziel serve
"""

__version__ = "0.8.2"

__author__ = "Marziel AI Team"
