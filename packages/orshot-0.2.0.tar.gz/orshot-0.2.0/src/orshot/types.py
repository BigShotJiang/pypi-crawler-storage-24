from dataclasses import dataclass

@dataclass
class RenderOptions:
    template_id: str
    modifications: dict
    response_type: str
    response_format: str

@dataclass
class SignedUrlOptions:
    template_id: str
    response_format: str
    render_type: str
    modifications: dict
    expires_at: int

@dataclass
class StudioResponseOptions:
    type: str = None
    format: str = None
    scale: int = None
    include_pages: list = None
    file_name: str = None

@dataclass
class PdfOptions:
    margin: str = None
    range_from: int = None
    range_to: int = None
    color_mode: str = None
    dpi: int = None

@dataclass
class VideoOptions:
    trim_start: int = None
    trim_end: int = None
    muted: bool = None
    loop: bool = None

@dataclass
class PublishSchedule:
    scheduled_for: str = None

@dataclass
class PublishOptions:
    accounts: list = None
    content: str = None
    is_draft: bool = None
    schedule: PublishSchedule = None
    timezone: str = None
    platform_options: dict = None

@dataclass
class StudioRenderOptions:
    template_id: int
    modifications: dict = None
    response: StudioResponseOptions = None
    pdf_options: PdfOptions = None
    video_options: VideoOptions = None
    publish: PublishOptions = None
