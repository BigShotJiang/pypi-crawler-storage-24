# botcall-print

Local print daemon for botcall. Receives print jobs from the cloud and sends them to your USB thermal printer.

## Installation

```bash
pip install botcall-print
```

Or install from source:

```bash
cd clients/print-daemon
pip install -e .
```

## Setup

1. Get your botcall API key from https://botcall.io
2. Configure the daemon:

```bash
botcall-print setup
# Enter your API key when prompted
```

3. Test your printer:

```bash
botcall-print test "Hello from botcall!"
```

4. Start the daemon:

```bash
botcall-print daemon
```

## Running as a Service

### macOS (launchd)

```bash
# Create launch agent
cat > ~/Library/LaunchAgents/io.botcall.print.plist << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>io.botcall.print</string>
    <key>ProgramArguments</key>
    <array>
        <string>$(which botcall-print)</string>
        <string>daemon</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
</dict>
</plist>
EOF

# Load it
launchctl load ~/Library/LaunchAgents/io.botcall.print.plist
```

### Linux (systemd)

```bash
# Create service file
sudo cat > /etc/systemd/system/botcall-print.service << EOF
[Unit]
Description=botcall print daemon
After=network.target

[Service]
Type=simple
User=$USER
ExecStart=$(which botcall-print) daemon
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# Enable and start
sudo systemctl enable botcall-print
sudo systemctl start botcall-print
```

## Commands

| Command | Description |
|---------|-------------|
| `botcall-print setup` | Configure API key |
| `botcall-print daemon` | Start listening for print jobs |
| `botcall-print test "text"` | Test print some text |
| `botcall-print status` | Show configuration and printer status |

## Supported Printers

Any ESC/POS compatible USB thermal printer. Common models:

- Epson TM-T20/T88
- Star TSP100/TSP650
- Generic 58mm/80mm receipt printers (ZJ-58, XP-58, etc.)

## Troubleshooting

### Printer not found

Check USB connection:
```bash
# macOS
system_profiler SPUSBDataType | grep -A5 -i printer

# Linux
lsusb | grep -i printer
```

### Permission denied (Linux)

Add udev rule:
```bash
echo 'SUBSYSTEM=="usb", ATTR{idVendor}=="0416", MODE="0666"' | sudo tee /etc/udev/rules.d/99-thermal-printer.rules
sudo udevadm control --reload-rules
```

### Slow/corrupted prints on Mac

Known macOS USB driver issue. The daemon includes chunking to work around this, but very image-heavy prints may still have issues. Consider using a Raspberry Pi for best results.
