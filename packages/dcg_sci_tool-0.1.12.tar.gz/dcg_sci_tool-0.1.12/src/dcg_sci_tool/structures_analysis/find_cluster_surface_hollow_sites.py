from scipy.spatial import cKDTree
import numpy as np
from ovito.data import DataCollection

from dcg_sci_tool import *


def find_cluster_surface_hollow_sites(data: DataCollection, type_names_order: list, 
                                     max_triangle_side: float = 4.0, cutoff: float = 3.5, CN_threshold: int = 12) -> list:
    """
    
    输出PdAu团簇表面构成Hollow位点的三原子对，每个三原子对由三个原子索引组成，且满足三原子之间的边长不超过max_triangle_side。
    默认处理对象为致密、严格对称的结构（如代码生成的PdAu标准正二十面体团簇），
    对于MD或者MD帧优化得到的结构，建议调整cutoff和CN_threshold参数以适用更广泛的情况。

    Args:
        data (DataCollection): OVITO 数据对象，包含原子结构信息
        type_names_order (list): 原子类型名称顺序列表，索引对应原子类型编号
        max_triangle_side (float): 构成Hollow位点的三原子之间的最大边长，单位为 Å（默认 4.0 Å）
        cutoff (float): 配位数计算的截断距离，单位为 Å（默认 3.5 Å，适用于致密、严格对称的结构）
        CN_threshold (int): 体相配位数阈值，用于判断原子是否位于表面（默认 12）
    Returns:
        hollowSites (list): 位于 PdAu 簇表面的Hollow位点三原子索引列表，每个元素为一个包含三个原子索引的元组
    
    
    
    """
    hollowSites = set()
    
    surface_indices = get_pdau_surface_atoms(data, type_names_order, cutoff = cutoff, CN_threshold = CN_threshold)
    surface_positions = data.particles.positions[surface_indices]


    # 构建KDTree加速查询
    kdtree = cKDTree(surface_positions)
    search_radius = max_triangle_side * 1.2
    
    for i, idx_i in enumerate(surface_indices):
        current_pos = kdtree.data[i]
        neighbor_indices = kdtree.query_ball_point(current_pos, search_radius)
        neighbor_indices = [idx for idx in neighbor_indices if idx != i]
        
        if len(neighbor_indices) < 2:
            continue
            
        for j in range(len(neighbor_indices)):
            j_idx = neighbor_indices[j]
            pos_j = kdtree.data[j_idx]
            distance_ij = np.linalg.norm(current_pos - pos_j)
            
            if distance_ij > max_triangle_side:
                continue
                
            for k in range(j + 1, len(neighbor_indices)):
                k_idx = neighbor_indices[k]
                pos_k = kdtree.data[k_idx]
                distance_ik = np.linalg.norm(current_pos - pos_k)
                distance_jk = np.linalg.norm(pos_j - pos_k)
                
                if (distance_ik <= max_triangle_side and distance_jk <= max_triangle_side):
                    orig_idx_i = surface_indices[i]
                    orig_idx_j = surface_indices[j_idx] 
                    orig_idx_k = surface_indices[k_idx]
                    triangle = tuple(sorted([orig_idx_i, orig_idx_j, orig_idx_k]))
                    hollowSites.add(triangle)

    
    return hollowSites