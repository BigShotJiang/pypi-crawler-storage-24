from dcg_sci_tool import *
from ovito.data import *
from ase.io import read, write
import csv  # 导入csv模块

pattern = "[0-9]+-[0-9]+_-?[0-9]\.[0-9]+_-?[0-9]\.[0-9]+_[0-9]+_[0-9]+_focused\.xyz"
target_files = find_matching_files("./", pattern)
print("Found files:", target_files)

# 使用csv模块写入CSV文件
with open("ad_config.csv", "w", newline='', encoding='utf-8') as csvfile:
    # 创建csv写入器
    csv_writer = csv.writer(csvfile)
    
    # 写入表头
    csv_writer.writerow(["File", "Ea", "dE", "CO_ad_Config", "O_ad_Config"])
    
    for file in target_files:
        Ea, dE, c_idx, o_idx = parse_nebTraj_file_name(file)
        get_reactants_ad_configs = get_reactants_ad_config(
            file, c_idx, o_idx, 
            c_pd_cutoff=2.5, o_pd_cutoff=2.1, 
            c_au_cutoff=2.5, o_au_cutoff=2.2
        )
        # 将数据写入CSV文件
        csv_writer.writerow([
            file, 
            Ea, 
            dE, 
            get_reactants_ad_configs[0], 
            get_reactants_ad_configs[1]
        ])
        # 同时在控制台输出（可选）
        print(f"{file}\t{Ea}\t{dE}\t{get_reactants_ad_configs[0]}\t{get_reactants_ad_configs[1]}")

print(f"数据已保存到 ad_config.csv")