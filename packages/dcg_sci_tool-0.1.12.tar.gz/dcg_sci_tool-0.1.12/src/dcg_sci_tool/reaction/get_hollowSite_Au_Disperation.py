import numpy as np
from ovito.data import DataCollection
from typing import List, Tuple, Dict
from dcg_sci_tool import *

def get_hollowSite_Au_Disperation(data: DataCollection, 
                                type_names_order: List[str], 
                                hollowSite_atom_indexes: List[int], 
                               ) -> Tuple[float, Dict]:
    """
    计算Hollow位点外圈Au原子的离散值
    
    Args:
        data: OVITO 数据对象
        type_names_order: 原子类型名称顺序列表
        hollowSite_atom_indexes: Hollow位点三个原子的索引列表
    
    Returns:
        tuple: (disperation_value, 原子统计信息)
    """
    # 导入数据
    particles = data.particles
    positions = particles.positions[...]
    
    # 提取原子类型

    types = particles.particle_types[...]
    symbols = np.array([type_names_order[t-1] for t in types])
    
    # 计算内圈三个原子的中心点
    inner_positions = positions[hollowSite_atom_indexes]
    center_point = np.mean(inner_positions, axis=0)
    
    # 统计内圈原子信息
    inner_au_count = 0
    inner_pd_count = 0
    for idx in hollowSite_atom_indexes:
        if symbols[idx] == 'Au':
            inner_au_count += 1
        elif symbols[idx] == 'Pd':
            inner_pd_count += 1
    
    # 筛选外圈中的Au原子
    au_outer_indices = []
    outer_au_count = 0
    outer_pd_count = 0
    outer_atom_indices = get_hollowSite_outer_surface_neighbors(data, type_names_order, hollowSite_atom_indexes)
    for idx in outer_atom_indices:
        if symbols[idx] == 'Au':
            au_outer_indices.append(idx)
            outer_au_count += 1
        elif symbols[idx] == 'Pd':
            outer_pd_count += 1
    
    print(f"  外圈总原子数: {len(outer_atom_indices)}, 其中Au原子数: {len(au_outer_indices)}")
    
    if len(au_outer_indices) == 0:
        print("  警告: 外圈中没有找到Au原子，离散值设为1.0")
        return 1.0, {
            'inner_total': len(hollowSite_atom_indexes),
            'inner_au_count': inner_au_count,
            'inner_pd_count': inner_pd_count,
            'outer_total': len(outer_atom_indices),
            'outer_au_count': outer_au_count,
            'outer_pd_count': outer_pd_count
        }
    
    # 构建从中心点到每个外圈Au原子的向量
    vectors = []
    for au_idx in au_outer_indices:
        au_position = positions[au_idx]
        # 从中心指向外圈Au原子的向量
        vector = au_position - center_point
        vectors.append(vector)
    
    vectors = np.array(vectors)
    
    # 计算每个向量的单位向量
    magnitudes = np.linalg.norm(vectors, axis=1, keepdims=True)
    unit_vectors = vectors / magnitudes
    
    # 计算单位向量的矢量和
    vector_sum = np.sum(unit_vectors, axis=0)
    
    # 除以N得到向量A
    N = len(au_outer_indices)
    vector_A = vector_sum / N
    
    # 计算向量A的模
    magnitude_A = np.linalg.norm(vector_A)
    
    # 计算离散值: 1 - |A|
    disperation_value = 1 - magnitude_A
    
    print(f"  向量A的模: {magnitude_A:.6f}")
    print(f"  离散值 (1 - |A|): {disperation_value:.6f}")
    
    return disperation_value, {
        'inner_total': len(hollowSite_atom_indexes),
        'inner_au_count': inner_au_count,
        'inner_pd_count': inner_pd_count,
        'outer_total': len(outer_atom_indices),
        'outer_au_count': outer_au_count,
        'outer_pd_count': outer_pd_count
    }