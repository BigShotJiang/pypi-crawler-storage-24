import numpy as np
from ovito.data import DataCollection
from pyparsing import Dict
from typing import List

def get_OC_bonded_metal_atoms(data: DataCollection, type_names_order: list, c_index: int, o_index: int  
                          ) -> List[int]:
    """获取与目标C和目标O原子成键的金属原子序号列表
    Args:
        data (DataCollection): 结构的ovito数据集合
        
        type_names_order (list): 原子类型名称列表，索引对应原子类型编号

        c_index (int): 目标C原子索引

        o_index (int): 目标O原子索引
    Returns:
        bonded_metal_atoms (list): 与C和O原子成键的金属原子索引列表
    """
    bond_cutoffs = {
    'Au-C': 2.5,
    'Au-O': 2.2,
    'Pd-C': 2.5,
    'Pd-O': 2.1
}
    particles = data.particles
    
    if particles is None:
        return {'error': '无法读取粒子数据'}
    
    # 获取原子信息
    positions = data.particles.positions[...]
    types = data.particles.particle_types[...]

    symbols = np.array([type_names_order[t-1] for t in types])
    num_atoms = particles.count
    bonded_metal_atoms = set()
    c_pos = positions[c_index]
    o_pos = positions[o_index]
    
    for i in range(num_atoms):
        if symbols[i] in ['Pd', 'Au']:  # 只考虑金属原子
            atom_pos = positions[i]
            metal_type = symbols[i]
            
            # 检查是否与C原子成键
            distance_to_c = np.linalg.norm(atom_pos - c_pos)
            c_cutoff = bond_cutoffs[f'{metal_type}-C']
            if distance_to_c <= c_cutoff:
                bonded_metal_atoms.add(i)
                continue
            
            # 检查是否与O原子成键
            distance_to_o = np.linalg.norm(atom_pos - o_pos)
            o_cutoff = bond_cutoffs[f'{metal_type}-O']
            if distance_to_o <= o_cutoff:
                bonded_metal_atoms.add(i)
    
    return list(bonded_metal_atoms)