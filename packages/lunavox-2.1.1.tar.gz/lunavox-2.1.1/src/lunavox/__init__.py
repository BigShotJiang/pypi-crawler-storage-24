"""LunaVox Python CLI package."""

__all__ = ["__version__"]

__version__ = "2.1.0"

