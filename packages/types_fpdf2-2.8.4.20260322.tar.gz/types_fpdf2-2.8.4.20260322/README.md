## Typing stubs for fpdf2

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`fpdf2`](https://github.com/py-pdf/fpdf2) package. It can be used by type checkers
to check code that uses `fpdf2`. This version of
`types-fpdf2` aims to provide accurate annotations for
`fpdf2==2.8.4`.

*Note:* The `fpdf2` package includes type annotations or type stubs
since version 2.8.6. Please uninstall the `types-fpdf2`
package if you use this or a newer version.


This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/fpdf2`](https://github.com/python/typeshed/tree/main/stubs/fpdf2)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.19.1
* [pyright](https://github.com/microsoft/pyright) 1.1.408

It was generated from typeshed commit
[`282b1a838a565f10a4b2e9139adc26ab828b2e9d`](https://github.com/python/typeshed/commit/282b1a838a565f10a4b2e9139adc26ab828b2e9d).