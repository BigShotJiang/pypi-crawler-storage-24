# c4rlib

> A powerful Python utility library for terminal tools — colors, gradients, logging, HTTP, crypto, files, Discord utils and more.

```bash
pip install c4rlib
```

No external dependencies — pure Python standard library only.

---

## Table of Contents

- [Installation](#installation)
- [Modules](#modules)
  - [ColorUtils](#colorutils)
  - [Gradient](#gradient)
  - [Logger](#logger)
  - [Box](#box)
  - [Banner](#banner)
  - [TextStyle](#textstyle)
  - [Utils](#utils)
  - [Spinner](#spinner)
  - [ProgressBar](#progressbar)
  - [Table](#table)
  - [Console](#console)
  - [Http](#http)
  - [Crypto](#crypto)
  - [Files](#files)
  - [Discord](#discord)

---

## Installation

```bash
pip install c4rlib
```

---

## Modules

### ColorUtils

Apply ANSI colors, styles, and manipulate colors.

```python
from c4rlib import ColorUtils

ColorUtils.paint("text", "#FF4444")
ColorUtils.bg_paint("text", "#000000", "#00ccff")
ColorUtils.bold("text")
ColorUtils.italic("text")
ColorUtils.underline("text")
ColorUtils.strike("text")
ColorUtils.blink("text")
ColorUtils.dim("text")
ColorUtils.overline("text")
ColorUtils.rainbow("text")
ColorUtils.random_color("text")
ColorUtils.style("text", "#FF0000", bold=True, italic=True)

ColorUtils.hex_to_rgb("#00ccff")
ColorUtils.rgb_to_hex(0, 204, 255)
ColorUtils.rgb_to_hsl(0, 204, 255)
ColorUtils.blend("#FF0000", "#0000FF", 0.5)
ColorUtils.lighten("#FF0000", 0.2)
ColorUtils.darken("#FF0000", 0.2)
ColorUtils.complementary("#FF0000")
ColorUtils.palette("#00ccff", steps=5)
ColorUtils.triadic("#FF0000")
```

---

### Gradient

Apply gradient color effects to text.

```python
from c4rlib import Gradient, GradientPresets

Gradient.apply("text", start=(255,0,0), end=(0,0,255))
Gradient.preset("text", GradientPresets.cyan_to_gold)
Gradient.multicolor("text", [(255,0,0), (0,255,0), (0,0,255)])
Gradient.random_gradient("text")
Gradient.bg_apply("text", start=(0,0,0), end=(100,0,200))

Gradient.fire("text")
Gradient.ice("text")
Gradient.toxic("text")
Gradient.sunset("text")
Gradient.ocean("text")
Gradient.galaxy("text")
Gradient.neon("text")
Gradient.matrix("text")
Gradient.lava("text")
Gradient.candy("text")
Gradient.aurora("text")
Gradient.electric("text")
Gradient.rose("text")
```

**GradientPresets** — over 60 presets including: `fire`, `ice`, `toxic`, `sunset`, `ocean`, `galaxy`, `candy`, `matrix`, `lava`, `aurora`, `blood`, `mint`, `rose`, `electric`, `neon_pink_purple`, `neon_green_blue`, `red_to_blue`, `cyan_to_gold`, `purple_to_pink`, and more.

---

### Logger

Colored leveled logger with timestamps.

```python
from c4rlib import Logger

Logger.success("Tag", "message", "extra")
Logger.error("Tag", "message", "extra")
Logger.warning("Tag", "message", "extra")
Logger.info("Tag", "message", "extra")
Logger.debug("Tag", "message", "extra")
Logger.critical("Tag", "message", "extra")
Logger.network("Tag", "message", "extra")
Logger.captcha("Tag", "message", "extra")
Logger.input("Tag", "message", "extra")
Logger.output("Tag", "message", "extra")
Logger.proxy("Tag", "message", "extra")
Logger.token("Tag", "message", "extra")
Logger.upload("Tag", "message", "extra")
Logger.download("Tag", "message", "extra")
Logger.database("Tag", "message", "extra")
Logger.file("Tag", "message", "extra")
Logger.crypto("Tag", "message", "extra")
Logger.wait("Tag", "message", "extra")
Logger.done("Tag", "message", "extra")
Logger.send("Tag", "message", "extra")
Logger.receive("Tag", "message", "extra")
Logger.locked("Tag", "message", "extra")
Logger.unlocked("Tag", "message", "extra")
Logger.custom("#FF69B4", "♥", "LVL", "message", "extra")
Logger.gradient_log("message", start=(0,200,255), end=(200,0,255))
Logger.banner_log("message", hex_color="#00ccff")
Logger.fire("message")
Logger.galaxy("message")
Logger.neon("message")
```

---

### Box

Draw decorative boxes around text.

```python
from c4rlib import Box

Box.rounded("text", color="#00ccff")
Box.double("text", color="#9b5de5")
Box.heavy("text", color="#29bf12")
Box.simple("text", color="#ffd60a")
Box.dots("text", color="#ff7b00")
Box.stars("text", color="#FF69B4")
Box.ascii("text", color="#adb5bd")
Box.diamond("text", color="#00bbf9")
Box.arrows("text", color="#f72585")
Box.classic_round("text", color="#06d6a0")
Box.neon("text", color="#00ccff")
Box.hash_box("text", color="#ffffff")
Box.gradient_box("text", start=(0,200,255), end=(200,0,255))
Box.multiline(["line 1", "line 2", "line 3"], style="rounded", color="#00ccff")
Box.titled("TITLE", ["line 1", "line 2"], style="double", title_color="#ffd60a")
```

---

### Banner

Section dividers and title blocks.

```python
from c4rlib import Banner

Banner.line("text", color="#00ccff")
Banner.double_line("text", color="#9b5de5")
Banner.arrow_line("text", color="#ffd60a")
Banner.heart_line("text", color="#FF69B4")
Banner.wave_line("text", color="#29bf12")
Banner.star_line("text", color="#ffd60a")
Banner.dot_line("text", color="#adb5bd")
Banner.slash_line("text", color="#ff7b00")
Banner.diamond_line("text", color="#00bbf9")
Banner.lightning_line("text", color="#ffd60a")
Banner.fire_line("text", color="#ff4500")
Banner.gradient_banner("text", start=(0,200,255), end=(200,0,255))
Banner.title("text", color="#00ccff")
Banner.gradient_title("text", start=(0,200,255), end=(200,0,255))
Banner.section("text", color="#00ccff")
Banner.center("text", width=80, color="#ffffff")
```

---

### TextStyle

Transform text into different Unicode and styled formats.

```python
from c4rlib import TextStyle

TextStyle.fancy("text")
TextStyle.double_struck("text")
TextStyle.cursive("text")
TextStyle.fraktur("text")
TextStyle.bold_serif("text")
TextStyle.sans_bold("text")
TextStyle.monospace("text")
TextStyle.syllabic("text")
TextStyle.small_caps("text")
TextStyle.wide("text")
TextStyle.bubble("text")
TextStyle.negative_square("text")
TextStyle.leet("text")
TextStyle.alternate_case("text")
TextStyle.reverse("text")
TextStyle.strikethrough("text")
TextStyle.underline_text("text")
TextStyle.overline_text("text")
TextStyle.double_underline("text")
TextStyle.superscript("text")
TextStyle.subscript("text")
TextStyle.space_out("text", spaces=2)
TextStyle.clap("text here")
TextStyle.uwuify("hello world")
TextStyle.zalgo("text", intensity=3)
TextStyle.rot13("text")
TextStyle.caesar("text", shift=3)
TextStyle.morse("sos")
TextStyle.nato("sos")
TextStyle.binary("hi")
TextStyle.hex_encode("hi")
TextStyle.truncate("long text here", max_len=10)
TextStyle.wrap("long paragraph text here", width=40)
```

---

### Utils

General-purpose utility functions.

```python
from c4rlib import Utils

Utils.generate_uuid()
Utils.generate_uuid_hex()
Utils.generate_token(32)
Utils.generate_hex_token(16)
Utils.generate_pin(6)
Utils.generate_password(20, symbols=True)

Utils.timestamp()
Utils.timestamp_seconds()
Utils.log_time()
Utils.log_date()
Utils.log_datetime()
Utils.elapsed(start_time)

Utils.random_string(8)
Utils.random_hex(8)
Utils.hash_md5("text")
Utils.hash_sha1("text")
Utils.hash_sha256("text")
Utils.hash_sha512("text")
Utils.hash_sha3_256("text")

Utils.generate_mac()
Utils.generate_ipv4()
Utils.generate_ipv6()
Utils.generate_port()

Utils.random_name()
Utils.random_first_name()
Utils.random_last_name()
Utils.random_email(domain="gmail.com")
Utils.random_username()
Utils.random_birthdate(min_year=1990, max_year=2000)
Utils.random_phone(country_code="+34")
Utils.random_address()
Utils.random_zip(country="US")
Utils.random_credit_card(brand="visa")
Utils.random_user_agent()
Utils.random_color_hex()

Utils.chunk([1,2,3,4,5,6], size=2)
Utils.flatten([[1,2],[3,[4,5]]])
Utils.unique([1,2,2,3,3])
Utils.clamp(150, 0, 100)
Utils.lerp(0, 100, 0.5)
Utils.percentage(7, 10)
Utils.format_bytes(1536000)
Utils.format_number(1000000)
Utils.retry(func, times=3, delay=1.0)

Utils.is_windows()
Utils.is_linux()
Utils.is_mac()
Utils.os_info()
Utils.run("echo hello")
```

---

### Spinner

Animated terminal spinners with 25 styles.

```python
from c4rlib import Spinner

with Spinner("Loading...", style="dots", color="#00ccff") as sp:
    sp.text = "Still loading..."
    time.sleep(2)

sp = Spinner("Working", style="moon", color="#9b5de5", interval=0.15)
sp.start()
time.sleep(2)
sp.stop("Done!", success=True)
```

**25 styles:** `dots`, `dots2`, `dots3`, `line`, `arrows`, `arrows2`, `bounce`, `circle`, `circle2`, `square`, `star`, `star2`, `grow`, `pulse`, `flip`, `balloon`, `noise`, `point`, `layer`, `earth`, `moon`, `hearts`, `clock`, `runner`, `weather`, `dice`, `aesthetic`, `matrix`

---

### ProgressBar

Animated progress bars with 14 styles.

```python
from c4rlib import ProgressBar

bar = ProgressBar(
    total=100,
    label="Downloading",
    style="block",
    color="#00ccff",
    width=40,
    show_eta=True,
    show_speed=True
)
for i in range(100):
    time.sleep(0.05)
    bar.update(1)
bar.finish("Download complete")

bar.set(50)
```

**14 styles:** `block`, `shade`, `smooth`, `classic`, `arrow`, `dot`, `square`, `diamond`, `line`, `wave`, `star`, `heart`, `fire`, `thin`

---

### Table

Render formatted bordered tables.

```python
from c4rlib import Table

table = Table(
    headers=["Name", "Score", "Status"],
    title="Leaderboard",
    header_color="#ffd60a",
    border_color="#6c757d",
    align="left",
    zebra=True
)
table.add_row(["Alice", "98", "✔ Pass"])
table.add_rows([["Bob", "74", "✔ Pass"], ["Charlie", "41", "✘ Fail"]])
table.print()

print(table.render())
print(table.to_csv())
table.clear()
```

---

### Console

Terminal control utilities.

```python
from c4rlib import Console

Console.clear()
Console.title("My Tool v2.0")
Console.width()
Console.height()
Console.size()
Console.hide_cursor()
Console.show_cursor()
Console.move_cursor(x=10, y=5)
Console.bell()
Console.rule(char="─", color="#6c757d")
Console.gradient_rule(start=(0,200,255), end=(200,0,255))
Console.typewriter("text here", delay=0.04, color="#00ccff")
Console.countdown(5, text="Starting in", color="#FF4444")
Console.input_prompt("Enter your name", color="#00ccff")
Console.confirm("Are you sure?", color="#ffd60a")
Console.select("Choose option", options=["Option A", "Option B", "Option C"])
Console.pause("Press ENTER to continue...")
Console.print_cols(["a","b","c","d","e","f"], cols=3)
```

---

### Http

HTTP requests without external dependencies.

```python
from c4rlib import Http

r = Http.get("https://api.example.com/users", params={"page": 1}, timeout=10)
r = Http.post("https://api.example.com/login", json_data={"user": "c4r", "pass": "1234"})
r = Http.put("https://api.example.com/user/1", json_data={"name": "c4r"})
r = Http.delete("https://api.example.com/user/1")
r = Http.patch("https://api.example.com/user/1", json_data={"score": 99})
r = Http.head("https://api.example.com")

r.status
r.text
r.json()
r.content
r.headers
r.ok()

Http.download("https://example.com/file.zip", "output.zip")
Http.build_headers(token="Bearer xyz", content_type="application/json")
Http.random_headers(token="Bearer xyz")
Http.parse_url("https://example.com/path?foo=bar")
Http.encode_params({"key": "value"})
Http.build_url("https://api.example.com", "users", {"page": 1})
Http.is_reachable("https://google.com")
```

---

### Crypto

Hashing, encoding, encryption, and JWT utilities.

```python
from c4rlib import Crypto

Crypto.md5("text")
Crypto.sha1("text")
Crypto.sha256("text")
Crypto.sha512("text")
Crypto.sha3_256("text")
Crypto.sha3_512("text")
Crypto.blake2b("text")
Crypto.blake2s("text")
Crypto.hmac_sha256("key", "message")
Crypto.hmac_sha512("key", "message")
Crypto.hash_file("path/to/file.txt")
Crypto.compare_hash("text", "expected_hash")

Crypto.b64_encode("text")
Crypto.b64_decode("dGV4dA==")
Crypto.b64_urlsafe_encode("text")
Crypto.b64_urlsafe_decode("dGV4dA")
Crypto.hex_encode("text")
Crypto.hex_decode("74657874")
Crypto.url_encode("hello world")
Crypto.url_decode("hello%20world")
Crypto.html_encode("<script>")
Crypto.html_decode("&lt;script&gt;")

Crypto.xor_encrypt("message", "key")
Crypto.xor_decrypt(encrypted, "key")
Crypto.vigenere_encrypt("message", "key")
Crypto.vigenere_decrypt(encrypted, "key")
Crypto.rot13("text")
Crypto.caesar("text", shift=3)

Crypto.make_jwt({"user": "c4r"}, "secret")
Crypto.decode_jwt(token)
Crypto.verify_jwt(token, "secret")
Crypto.pbkdf2("password", salt="optional_salt")
Crypto.totp("BASE32SECRET")

Crypto.random_bytes(32)
Crypto.random_hex(32)
Crypto.random_urlsafe(32)
```

---

### Files

File system utilities.

```python
from c4rlib import Files

Files.read("file.txt")
Files.read_lines("file.txt")
Files.read_bytes("file.bin")
Files.write("file.txt", "content")
Files.write_bytes("file.bin", b"data")
Files.append("file.txt", "more content")
Files.append_line("file.txt", "a new line")
Files.write_json("data.json", {"key": "value"})
Files.read_json("data.json")

Files.exists("file.txt")
Files.is_file("file.txt")
Files.is_dir("folder/")
Files.mkdir("new/folder/path")
Files.delete("file.txt")
Files.copy("src.txt", "dst.txt")
Files.move("src.txt", "dst.txt")
Files.rename("old.txt", "new.txt")

Files.size("file.txt")
Files.size_human("file.txt")
Files.extension("file.txt")
Files.basename("path/to/file.txt")
Files.dirname("path/to/file.txt")
Files.stem("file.txt")
Files.abspath("file.txt")
Files.join("path", "to", "file.txt")

Files.list_dir(".")
Files.list_files(".", pattern="*.py", recursive=True)
Files.list_dirs(".")
Files.find(".", "config", recursive=True)
Files.find_by_extension(".", "py", recursive=True)
Files.count_lines("file.txt")
Files.hash("file.txt", algorithm="sha256")
Files.modified_time("file.txt")
Files.created_time("file.txt")
Files.tree(".")
Files.safe_filename("bad:file*name?.txt")
Files.temp_path(suffix=".tmp")
Files.cwd()
Files.home()
```

---

### Discord

Discord-specific utilities — no requests library needed.

```python
from c4rlib import Discord

Discord.is_valid_token(token)
Discord.decode_token(token)
Discord.snowflake_to_timestamp(snowflake_id)
Discord.timestamp_to_snowflake(datetime_obj)
Discord.generate_nonce()
Discord.generate_session_id()
Discord.generate_device_id()

Discord.make_xsuper(client_version="1.0.9038", build_number=9038)
Discord.make_headers(token="Bot my_token", xsuper=xsuper)

Discord.generate_username()
Discord.generate_birthdate(min_year=1990, max_year=2000)
Discord.random_invite_code()
Discord.parse_invite("https://discord.gg/abc123")
Discord.invite_link("abc123")
Discord.message_link(guild_id, channel_id, message_id)
Discord.channel_link(guild_id, channel_id)

Discord.format_bold("text")
Discord.format_italic("text")
Discord.format_underline("text")
Discord.format_strikethrough("text")
Discord.format_spoiler("text")
Discord.format_code("code here", "python")
Discord.format_inline_code("code")
Discord.format_mention_user(user_id)
Discord.format_mention_role(role_id)
Discord.format_mention_channel(channel_id)
Discord.format_emoji("name", emoji_id, animated=False)
Discord.format_timestamp(datetime_obj, style="f")
Discord.format_quote("multi\nline\ntext")
Discord.format_embed_color("#5865F2")

Discord.make_embed(
    title="Title",
    description="Description",
    color="#5865F2",
    fields=[Discord.make_field("Name", "Value", inline=True)],
    footer="Footer text",
    thumbnail="https://...",
    image="https://...",
    author="Author name",
    timestamp=True
)
Discord.permissions_to_list(permissions_integer)
```

---

## License

MIT © c4r