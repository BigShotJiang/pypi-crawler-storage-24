import importlib
import sys


SUBMODULES = [
    "assembler",
    "asiic_holographic",
    "core",
    "multi_level",
    "quantum_holocron",
    "transpiler",
    "visualization",
]


def test_import_does_not_require_optional_dependencies(monkeypatch):
    # Aseguramos que el estado de importación esté limpio.
    for mod in list(sys.modules):
        if mod == "holobit_sdk" or mod.startswith("holobit_sdk."):
            monkeypatch.delitem(sys.modules, mod, raising=False)

    holobit_sdk = importlib.import_module("holobit_sdk")

    # Ningún submódulo debe cargarse automáticamente.
    for name in SUBMODULES:
        assert f"holobit_sdk.{name}" not in sys.modules

    # __all__ expone únicamente los submódulos previstos.
    assert holobit_sdk.__all__ == SUBMODULES
