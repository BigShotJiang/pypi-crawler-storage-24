"""Pruebas cruzadas entre implementaciones Python y Cython.

Estas pruebas se ejecutan solo si las extensiones compiladas están
instaladas; en caso contrario se omiten con un mensaje claro para no
falsificar resultados.
"""

from __future__ import annotations

import importlib
import random
import statistics
import time
from importlib import machinery, util
from pathlib import Path
from types import ModuleType

import pytest

from holobit_sdk.utils.safe_eval import safe_eval

REPO_ROOT = Path(__file__).resolve().parents[1]


def _has_compiled_extension(module_name: str) -> bool:
    spec = util.find_spec(module_name)
    return spec is not None and isinstance(spec.loader, machinery.ExtensionFileLoader)


def _load_pure_python_module(module_name: str, file_path: Path) -> ModuleType:
    spec = util.spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:  # pragma: no cover - carga defensiva
        raise ImportError(f"No se pudo cargar el módulo {module_name} desde {file_path}")
    module = util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


CYTHON_VM_AVAILABLE = _has_compiled_extension("holobit_sdk.assembler.virtual_machine")
CYTHON_EVOLUTION_AVAILABLE = _has_compiled_extension(
    "holobit_sdk.quantum_holocron.core.group_evolution"
)

pytestmark = pytest.mark.skipif(
    not (CYTHON_VM_AVAILABLE or CYTHON_EVOLUTION_AVAILABLE),
    reason="No hay extensiones Cython compiladas disponibles para las pruebas cruzadas.",
)


@pytest.mark.skipif(
    not CYTHON_VM_AVAILABLE,
    reason="Extensión Cython de la máquina virtual no disponible; se omite la comparación.",
)
def test_assembler_vm_python_vs_cython_state_equivalence():
    py_vm_cls = importlib.import_module("holobit_sdk.assembler._virtual_machine_py").AssemblerVM
    cy_vm_cls = importlib.import_module("holobit_sdk.assembler.virtual_machine").AssemblerVM

    program = [
        "CREAR q1 (0, 0, 0)",
        "CREAR q2 (1, 0, 0)",
        "SUPERPOS q1 q2",
        "ENTR q1 q2",
        "GRUPO G = {q1, q2}",
    ]

    py_vm = py_vm_cls()
    cy_vm = cy_vm_cls()

    py_vm.run_program(program)
    cy_vm.run_program(program)

    def snapshot(vm):
        holocron = vm.holocron
        reverse = {id(obj): name for name, obj in holocron.holobits.items()}
        groups = {
            name: sorted(reverse.get(id(member), "") for member in members)
            for name, members in holocron.groups.items()
        }
        return {
            "holobits": sorted(holocron.holobits.keys()),
            "groups": groups,
            "states": sorted(holocron._states.keys()),
        }

    assert snapshot(py_vm) == snapshot(cy_vm)


@pytest.mark.skipif(
    not CYTHON_VM_AVAILABLE,
    reason="Extensión Cython de la máquina virtual no disponible; se omite la comparación.",
)
def test_assembler_vm_control_flow_python_vs_cython():
    py_vm_cls = importlib.import_module("holobit_sdk.assembler._virtual_machine_py").AssemblerVM
    cy_vm_cls = importlib.import_module("holobit_sdk.assembler.virtual_machine").AssemblerVM

    def prepare(vm):
        logs: list[str] = []
        instruction_cls = vm.instructions["CREAR"].__class__

        def set_measurement(parser, key, raw):
            parser.measurements[key] = safe_eval(raw, parser.measurements)

        def log(parser, label):
            logs.append(label)

        vm.instructions = dict(vm.instructions)
        vm.instructions["SET"] = instruction_cls("SET", set_measurement)
        vm.instructions["LOG"] = instruction_cls("LOG", log)

        hb1, hb2 = object(), object()
        vm.parser.holocron.holobits = {"alpha": hb1, "beta": hb2}
        vm.parser.holocron.groups = {"G": [hb1, hb2]}
        vm.parser.measurements["flag"] = 1

        return logs

    program = [
        "FUNC saluda",
        "LOG func",
        "ENDFUNC",
        "SET flag 1",
        "SI flag",
        "CALL saluda",
        "SINO",
        "LOG sino",
        "FIN",
        "PARA 2",
        "LOG para",
        "FIN",
        "MIENTRAS flag",
        "LOG while",
        "SET flag 0",
        "FIN",
        "PARAG G",
        "LOG par$",
        "FIN",
        "CASO flag",
        "CUANDO 0",
        "LOG caso0",
        "CUANDO 1",
        "LOG caso1",
        "OTRO",
        "LOG casodefault",
        "FINCASO",
    ]

    py_vm, cy_vm = py_vm_cls(), cy_vm_cls()
    py_logs = prepare(py_vm)
    cy_logs = prepare(cy_vm)

    py_vm.run_program(program)
    cy_vm.run_program(program)

    assert py_logs == cy_logs == [
        "func",
        "para",
        "para",
        "while",
        "paralpha",
        "parbeta",
        "caso0",
    ]
    assert py_vm.parser.measurements["flag"] == cy_vm.parser.measurements["flag"] == 0


@pytest.mark.skipif(
    not CYTHON_EVOLUTION_AVAILABLE,
    reason="Extensión Cython de evolución de grupos no disponible; se omite la comparación.",
)
def test_group_evolution_python_vs_cython_matches():
    cy_module = importlib.import_module("holobit_sdk.quantum_holocron.core.group_evolution")
    py_module = _load_pure_python_module(
        "group_evolution_py",
        REPO_ROOT / "holobit_sdk" / "quantum_holocron" / "core" / "group_evolution.py",
    )

    holobits = {f"h{i}": i for i in range(10)}
    initial = ["h0", "h1", "h2"]

    def criteria(selected):
        return sum(selected)

    random.seed(1234)
    cy_result = cy_module.evolve_group_ids(initial, holobits, criteria, generations=5, population_size=6)

    random.seed(1234)
    py_result = py_module.evolve_group_ids(initial, holobits, criteria, generations=5, population_size=6)

    assert cy_result == py_result


@pytest.mark.skipif(
    not CYTHON_VM_AVAILABLE,
    reason="Extensión Cython de la máquina virtual no disponible; se omiten los benchmarks.",
)
def test_assembler_vm_microbenchmark():
    py_vm_cls = importlib.import_module("holobit_sdk.assembler._virtual_machine_py").AssemblerVM
    cy_vm_cls = importlib.import_module("holobit_sdk.assembler.virtual_machine").AssemblerVM

    program = [
        "CREAR a (0, 0, 0)",
        "CREAR b (1, 0, 0)",
        "SUPERPOS a b",
        "ENTR a b",
        "GRUPO G = {a, b}",
    ]

    def measure(vm_cls):
        samples = []
        for _ in range(5):
            start = time.perf_counter()
            for _ in range(50):
                vm = vm_cls()
                vm.run_program(program)
            samples.append(time.perf_counter() - start)
        return statistics.mean(samples)

    py_time = measure(py_vm_cls)
    cy_time = measure(cy_vm_cls)

    assert cy_time <= py_time * 1.25, (
        "La versión compilada debe mantenerse dentro de un 25% del rendimiento "
        "de referencia para evitar regresiones perceptibles."
    )


@pytest.mark.skipif(
    not CYTHON_EVOLUTION_AVAILABLE,
    reason="Extensión Cython de evolución de grupos no disponible; se omiten los benchmarks.",
)
def test_group_evolution_microbenchmark():
    cy_module = importlib.import_module("holobit_sdk.quantum_holocron.core.group_evolution")
    py_module = _load_pure_python_module(
        "group_evolution_py",
        REPO_ROOT / "holobit_sdk" / "quantum_holocron" / "core" / "group_evolution.py",
    )

    holobits = {f"h{i}": i for i in range(50)}
    initial = ["h0", "h1", "h2", "h3"]

    def criteria(selected):
        return -sum(selected)  # minimización indirecta

    def measure(module: ModuleType):
        samples = []
        for _ in range(5):
            random.seed(2024)
            start = time.perf_counter()
            module.evolve_group_ids(initial, holobits, criteria, generations=12, population_size=24)
            samples.append(time.perf_counter() - start)
        return statistics.mean(samples)

    cy_time = measure(cy_module)
    py_time = measure(py_module)

    assert cy_time <= py_time * 1.25, (
        "La implementación Cython debe conservar una ventaja de rendimiento "
        "respecto a la versión Python para evitar regresiones."
    )
