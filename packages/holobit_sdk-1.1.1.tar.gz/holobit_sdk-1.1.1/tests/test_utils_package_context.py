from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
import pytest


def test_utils_import_with_custom_pythonpath(tmp_path):
    repo_root = Path(__file__).resolve().parents[1]
    package_link = tmp_path / "holobit_sdk"
    try:
        package_link.symlink_to(repo_root / "holobit_sdk", target_is_directory=True)
    except (NotImplementedError, OSError):
        pytest.skip("Symlinks no soportados en este entorno")

    env = os.environ.copy()
    env["PYTHONPATH"] = str(tmp_path)

    result = subprocess.run(
        [sys.executable, str(package_link / "utils" / "__init__.py")],
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )

    assert "ModuleNotFoundError" not in result.stderr
