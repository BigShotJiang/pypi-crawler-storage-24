from __future__ import annotations

"""Benchmarks comparativos entre implementaciones compiladas y puras en Python."""

import numpy as np
import pytest

pytest.importorskip("pytest_benchmark")

from holobit_sdk.core import holobit
from holobit_sdk.core import holobit_py
from holobit_sdk.core import quark_py


ANGLE_DEGREES = 60.0
_IMPLEMENTATIONS = [
    (
        "compiled" if holobit.USING_COMPILED else "fallback",
        holobit.Holobit,
        holobit.Quark,
    ),
    ("python", holobit_py.Holobit, quark_py.Quark),
]


def _build_quarks(quark_cls):
    return [quark_cls(float(i), float(i + 0.5), float(i + 1.0)) for i in range(6)]


def _rotate_once(holobit_cls, quark_cls):
    holobit_instance = holobit_cls(_build_quarks(quark_cls), _build_quarks(quark_cls), spin=0.5)
    holobit_instance.rotar("z", ANGLE_DEGREES)
    return holobit_instance.quarks[0].posicion.copy()


_REFERENCE_ROTATION = _rotate_once(holobit_py.Holobit, quark_py.Quark)


@pytest.mark.benchmark(group="holobit_rotation")
@pytest.mark.parametrize(
    "label,holobit_cls,quark_cls",
    _IMPLEMENTATIONS,
    ids=[impl[0] for impl in _IMPLEMENTATIONS],
)
def test_rotacion_holobit_benchmark(benchmark, label, holobit_cls, quark_cls):
    """Mide el coste de rotar un Holobit y valida la salida contra la versión de referencia."""

    result = benchmark.pedantic(
        lambda: _rotate_once(holobit_cls, quark_cls),
        iterations=1,
        rounds=5,
        warmup_rounds=1,
    )

    assert np.allclose(result, _REFERENCE_ROTATION), f"La rotación {label} no coincide con la referencia"
