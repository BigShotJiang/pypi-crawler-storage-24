import builtins
import importlib.util
from pathlib import Path

import pytest

GRPC_FILE = Path(__file__).resolve().parents[1] / "holobit_sdk" / "api" / "grpc_service.py"


def _load_grpc_service():
    spec = importlib.util.spec_from_file_location("grpc_service", GRPC_FILE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[attr-defined]
    return module


def _simulate_missing_packages(monkeypatch, missing):
    original_import = builtins.__import__

    def _fake_import(name, *args, **kwargs):
        if any(name == mod or name.startswith(f"{mod}.") for mod in missing):
            raise ModuleNotFoundError(f"No module named '{name}'")
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", _fake_import)


def test_aws_backend_reports_missing_sdk(monkeypatch):
    monkeypatch.setenv("HOLOBIT_BACKEND", "aws")
    module = _load_grpc_service()
    _simulate_missing_packages(monkeypatch, ["boto3"])

    with pytest.raises(RuntimeError, match="AWS requiere dependencias opcionales"):
        module._select_backend()


def test_azure_backend_reports_missing_sdk(monkeypatch):
    monkeypatch.setenv("HOLOBIT_BACKEND", "azure")
    module = _load_grpc_service()
    _simulate_missing_packages(monkeypatch, ["azure.identity", "azure.mgmt.batch"])

    with pytest.raises(RuntimeError, match="Azure requiere dependencias opcionales"):
        module._select_backend()


def test_gcp_backend_reports_missing_sdk(monkeypatch):
    monkeypatch.setenv("HOLOBIT_BACKEND", "gcp")
    module = _load_grpc_service()
    _simulate_missing_packages(monkeypatch, ["google.cloud", "google.oauth2"])

    with pytest.raises(RuntimeError, match="GCP requiere dependencias opcionales"):
        module._select_backend()
