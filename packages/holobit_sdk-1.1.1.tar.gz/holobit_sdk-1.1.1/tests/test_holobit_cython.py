import time

import numpy as np
import pytest

from holobit_sdk.core import holobit as holobit_mod
from holobit_sdk.core import holobit_py, quark_py
from holobit_sdk.core import quark as quark_mod

holobit_c = pytest.importorskip("holobit_sdk.core.holobit_c")


_COORDS = [
    (1.0, 0.0, 0.0),
    (0.0, 1.0, 0.0),
    (0.0, 0.0, 1.0),
    (1.0, 1.0, 1.0),
    (2.0, 2.0, 0.0),
    (0.5, 0.5, 0.5),
]


def _build_quarks(cls):
    return [cls(*coords) for coords in _COORDS]


def _build_holobit(cls_quark, cls_holobit):
    quarks = _build_quarks(cls_quark)
    antiquarks = _build_quarks(cls_quark)
    return cls_holobit(quarks, antiquarks, spin=0.5)


def test_rotar_equivalente_cython_vs_python():
    holobit_fast = _build_holobit(holobit_c.Quark, holobit_c.Holobit)
    holobit_py_impl = _build_holobit(quark_py.Quark, holobit_py.Holobit)

    holobit_fast.rotar("z", 45)
    holobit_py_impl.rotar("z", 45)

    for q_fast, q_py in zip(holobit_fast.quarks + holobit_fast.antiquarks, holobit_py_impl.quarks + holobit_py_impl.antiquarks):
        np.testing.assert_allclose(q_fast.posicion, q_py.posicion)


def test_aplicar_puerta_equivalente():
    puerta = np.array([[0, 1], [1, 0]], dtype=np.complex128)
    quark_fast = holobit_c.Quark(1, 0, 0)
    quark_py_impl = quark_py.Quark(1, 0, 0)

    quark_fast.aplicar_puerta(puerta)
    quark_py_impl.aplicar_puerta(puerta)

    np.testing.assert_allclose(quark_fast.estado, quark_py_impl.estado)


def test_tiempo_rotacion_cython_mide_y_compara():
    holobit_fast = _build_holobit(holobit_c.Quark, holobit_c.Holobit)
    holobit_puro = _build_holobit(quark_py.Quark, holobit_py.Holobit)

    repeticiones = 400
    inicio_fast = time.perf_counter()
    for _ in range(repeticiones):
        holobit_fast.rotar("y", 5)
    tiempo_fast = time.perf_counter() - inicio_fast

    inicio_py = time.perf_counter()
    for _ in range(repeticiones):
        holobit_puro.rotar("y", 5)
    tiempo_py = time.perf_counter() - inicio_py

    # Se normaliza por el número de iteraciones para evitar falsos positivos
    ratio = (tiempo_py / repeticiones) / (tiempo_fast / repeticiones)
    assert ratio >= 0.2  # El compilado no debería ser órdenes de magnitud más lento
    assert tiempo_fast > 0 and tiempo_py > 0

    # Mostrar las mediciones en la salida de pytest para referencia.
    holobit_mod_label = "compilado" if holobit_mod.USING_COMPILED else "python"
    quark_mod_label = "compilado" if quark_mod.USING_COMPILED else "python"
    print(
        f"Tiempo medio por rotación (compilado={holobit_mod_label}/{quark_mod_label}): {tiempo_fast / repeticiones:.6f}s; "
        f"python puro: {tiempo_py / repeticiones:.6f}s"
    )
