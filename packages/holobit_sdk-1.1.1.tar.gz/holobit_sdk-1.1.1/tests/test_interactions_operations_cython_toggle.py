"""Pruebas que validan comportamiento con y sin Cython para interacciones y operaciones."""

from __future__ import annotations

import importlib
import os
import statistics
import sys
import time
from typing import Tuple

import numpy as np
import pytest

pytest.importorskip("pytest_benchmark")

from holobit_sdk.core import interactions_py, operations_py, quark
from holobit_sdk.core.holobit_py import Holobit
from holobit_sdk.core.quark_py import Quark as PyQuark


def _reload_with_env(module_name: str, cython_env: str):
    """Recarga un módulo tras forzar el valor de ``HOLOBIT_DISABLE_CYTHON``."""

    os.environ["HOLOBIT_DISABLE_CYTHON"] = cython_env
    for key in list(sys.modules):
        if key == module_name or key.startswith(f"{module_name}."):
            sys.modules.pop(key, None)
    return importlib.import_module(module_name)


def _build_holobit(spin: float = 0.75) -> Holobit:
    quarks = [PyQuark(float(i), float(i + 0.5), float(i + 1.0)) for i in range(6)]
    antiquarks = [PyQuark(float(i + 1.5), float(i + 2.0), float(i + 2.5)) for i in range(6)]
    return Holobit(quarks, antiquarks, spin=spin)


@pytest.fixture(params=["0", "1"], ids=["cython-enabled", "cython-disabled"])
def cython_toggled_modules(monkeypatch, request) -> Tuple[str, object, object]:
    """Proporciona los módulos recargados respetando el valor de la variable de entorno."""

    env_value = request.param
    monkeypatch.setenv("HOLOBIT_DISABLE_CYTHON", env_value)
    interactions = _reload_with_env("holobit_sdk.core.interactions", env_value)
    operations = _reload_with_env("holobit_sdk.core.operations", env_value)
    return env_value, interactions, operations


def test_interactions_match_python_reference(cython_toggled_modules):
    env_value, interactions, _ = cython_toggled_modules

    holobit_under_test = _build_holobit(spin=1.25)
    holobit_reference = _build_holobit(spin=1.25)

    interactions.confinar_quarks(holobit_under_test, limite=1.0)
    interactions_py.confinar_quarks(holobit_reference, limite=1.0)

    assert all(
        np.allclose(h.posicion, r.posicion)
        for h, r in zip(holobit_under_test.quarks + holobit_under_test.antiquarks,
                        holobit_reference.quarks + holobit_reference.antiquarks)
    ), f"La conficación no coincide con el fallback para HOLOBIT_DISABLE_CYTHON={env_value}"

    interactions.cambiar_spin(holobit_under_test, 0.33)
    interactions_py.cambiar_spin(holobit_reference, 0.33)
    assert holobit_under_test.spin == pytest.approx(holobit_reference.spin)

    extra_holobit = _build_holobit(spin=-0.1)
    reference_extra = _build_holobit(spin=-0.1)
    sync_group = interactions.sincronizar_spin([holobit_under_test, extra_holobit])
    reference_group = interactions_py.sincronizar_spin([holobit_reference, reference_extra])

    for synced, expected in zip(sync_group, reference_group):
        assert synced.spin == pytest.approx(expected.spin)


def test_operations_match_python_reference(cython_toggled_modules):
    env_value, _, operations = cython_toggled_modules

    estado1 = np.array([1.0 + 0j, 0.25 + 0.75j])
    estado2 = np.array([0.6 + 0.2j, -0.1 + 0.9j])

    ref_entanglement = operations_py.entrelazar(PyQuark(estado=estado1.copy()), PyQuark(estado=estado2.copy()))

    quark_cls = quark.Quark
    result = operations.entrelazar(quark_cls(estado=estado1.copy()), quark_cls(estado=estado2.copy()))

    assert np.allclose(result, ref_entanglement), (
        "El resultado de entrelazar debe coincidir con la referencia en Python "
        f"(HOLOBIT_DISABLE_CYTHON={env_value})."
    )


@pytest.mark.performance
@pytest.mark.slow
def test_operations_compiled_beats_python(monkeypatch, benchmark):
    compiled_operations = _reload_with_env("holobit_sdk.core.operations", "0")
    if not compiled_operations.USING_COMPILED:
        pytest.skip("Extensión Cython de operaciones no disponible.")

    baseline = operations_py

    def build_inputs(quark_cls):
        return quark_cls(estado=np.array([1.0, 0.0], dtype=complex)), quark_cls(
            estado=np.array([0.5, 0.5], dtype=complex)
        )

    def run_compiled():
        q1, q2 = build_inputs(quark.Quark)
        return compiled_operations.entrelazar(q1, q2)

    compiled_output = benchmark.pedantic(run_compiled, iterations=3, rounds=15, warmup_rounds=2)
    python_output = baseline.entrelazar(*build_inputs(PyQuark))

    assert np.allclose(compiled_output, python_output)

    def manual_time(func, iterations=40, rounds=5):
        samples = []
        for _ in range(rounds):
            start = time.perf_counter()
            for _ in range(iterations):
                func()
            samples.append(time.perf_counter() - start)
        return statistics.mean(samples) / iterations

    compiled_mean = benchmark.stats.stats["mean"]
    python_mean = manual_time(lambda: baseline.entrelazar(*build_inputs(PyQuark)))

    assert compiled_mean <= python_mean * 0.9, (
        "Se espera que la versión compilada mantenga una mejora de al menos un 10% "
        "respecto a la implementación en Python puro."
    )

