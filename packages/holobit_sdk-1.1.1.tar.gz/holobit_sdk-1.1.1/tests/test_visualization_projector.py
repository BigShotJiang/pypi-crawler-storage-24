"""Pruebas unitarias para la visualización 3D de Holobits."""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt

from holobit_sdk.core.holobit import Holobit
from holobit_sdk.core.quark import Quark
from holobit_sdk.visualization.projector import proyectar_holograma


def _crear_holobit(spin: float = 0.5) -> Holobit:
    quarks = [Quark(x, x + 0.1, x + 0.2) for x in range(6)]
    antiquarks = [Quark(-x, -x - 0.1, -x - 0.2) for x in range(6)]
    return Holobit(quarks, antiquarks, spin=spin)


def test_proyectar_holograma_acepta_holobit_individual():
    holobit = _crear_holobit(spin=0.75)
    fig, ax = proyectar_holograma(holobit)

    try:
        assert len(ax.collections) == len(holobit.quarks) + len(holobit.antiquarks)
        textos = {texto.get_text() for texto in ax.texts}
        assert f"spin={holobit.spin}" in textos
    finally:
        plt.close(fig)
