"""Pruebas ligeras de rendimiento de la VM del ensamblador."""

from __future__ import annotations

import pytest

from holobit_sdk.assembler.vm_metrics import (
    EXAMPLE_PROGRAM,
    MAX_PERFORMANCE_RATIO,
    collect_vm_metrics,
    has_compiled_vm,
    load_vm_classes,
    run_microbenchmark,
)


def test_python_vm_microbenchmark_es_estable():
    """La implementación pura debe poder medirse de forma determinista."""

    py_vm_cls, _ = load_vm_classes()
    metrics = run_microbenchmark(py_vm_cls, EXAMPLE_PROGRAM, iterations=20, samples=3)

    assert metrics["mean_s"] > 0
    assert metrics["ips"] > 0


@pytest.mark.xfail(
    not has_compiled_vm(),
    reason="La extensión Cython no está disponible en el entorno de pruebas.",
    strict=False,
)
def test_cython_vm_es_coherente_con_el_umbral():
    """La VM compilada no debe degradar el rendimiento respecto a Python."""

    metrics = collect_vm_metrics(EXAMPLE_PROGRAM, iterations=30, samples=3)
    cy_metrics = metrics.get("cython")
    py_metrics = metrics["python"]

    assert cy_metrics is not None, "Se esperaba contar con métricas de la extensión compilada"
    assert cy_metrics["mean_s"] <= py_metrics["mean_s"] * MAX_PERFORMANCE_RATIO
    assert cy_metrics["ips"] >= py_metrics["ips"] / MAX_PERFORMANCE_RATIO

