"""Pruebas de paridad entre la VM compilada y la versión Python pura."""

from __future__ import annotations

import random
from typing import Dict

import pytest

from holobit_sdk.assembler.vm_metrics import EXAMPLE_PROGRAM, has_compiled_vm, load_vm_classes


def _snapshot(vm) -> Dict[str, object]:
    holocron = vm.holocron
    reverse = {id(obj): name for name, obj in holocron.holobits.items()}
    groups = {
        name: sorted(reverse.get(id(member), "") for member in members)
        for name, members in holocron.groups.items()
    }
    states = {}
    for state, data in holocron._states.items():
        state_holobits = data.get("holobits", {})
        state_reverse = {id(obj): name for name, obj in state_holobits.items()}
        states[state] = {
            "holobits": sorted(state_holobits.keys()),
            "groups": {
                gid: sorted(state_reverse.get(id(member), "") for member in members)
                for gid, members in data.get("groups", {}).items()
            },
        }
    measurements = dict(sorted(vm.parser.measurements.items()))
    return {
        "holobits": sorted(holocron.holobits.keys()),
        "groups": groups,
        "states": states,
        "measurements": measurements,
    }


def _prepare_program() -> list[str]:
    extra = [
        "CASO H1",
        "CUANDO 0",
        "GRUPO GA = {H1}",
        "CUANDO 1",
        "GRUPO GB = {H2}",
        "FINCASO",
    ]
    program = list(EXAMPLE_PROGRAM)
    program.extend(extra)
    return program


@pytest.mark.xfail(
    not has_compiled_vm(),
    reason="La extensión Cython no está disponible en el entorno de pruebas.",
    strict=False,
)
def test_estados_y_mediciones_coinciden_entre_implementaciones():
    py_vm_cls, cy_vm_cls = load_vm_classes()
    assert cy_vm_cls is not None, "Se esperaba la implementación compilada para validar paridad"

    program = _prepare_program()

    random.seed(2024)
    py_vm = py_vm_cls()
    py_vm.run_program(program)
    py_vm.holocron.save_state("final")

    random.seed(2024)
    cy_vm = cy_vm_cls()
    cy_vm.run_program(program)
    cy_vm.holocron.save_state("final")

    assert _snapshot(py_vm) == _snapshot(cy_vm)

