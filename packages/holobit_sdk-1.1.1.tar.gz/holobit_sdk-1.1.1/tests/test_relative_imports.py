from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def _run_script(path: Path, *args: str) -> subprocess.CompletedProcess[str]:
    repo_root = Path(__file__).resolve().parents[1]
    env = os.environ.copy()
    pythonpath = [str(repo_root)]
    if env.get("PYTHONPATH"):
        pythonpath.append(env["PYTHONPATH"])
    env["PYTHONPATH"] = os.pathsep.join(pythonpath)

    return subprocess.run(
        [sys.executable, str(path), *args],
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )


def test_bootstrap_works_without_pyproject(tmp_path):
    repo_root = Path(__file__).resolve().parents[1]
    pyproject = repo_root / "pyproject.toml"
    backup = tmp_path / "pyproject.toml.bak"
    pyproject.replace(backup)
    try:
        _run_script(repo_root / "holobit_sdk" / "api" / "holobit_pb2_grpc.py")
        _run_script(
            repo_root / "holobit_sdk" / "multi_level" / "high_level" / "hololang_cli.py",
            "--help",
        )
    finally:
        backup.replace(pyproject)
