"""Pruebas de consistencia y microbenchmarks para Cython y el *fallback* en Python."""

from __future__ import annotations

import random
import statistics
import time
from dataclasses import dataclass

import numpy as np
import pytest

try:  # pragma: no cover - solo se usa para habilitar los benchmarks
    import pytest_benchmark.plugin  # type: ignore
except ImportError:  # pragma: no cover - entorno sin plugin instalado
    HAS_BENCHMARK = False
else:  # pragma: no cover - ruta dependiente de plugin externo
    HAS_BENCHMARK = True


@dataclass
class DummyHolobit:
    alpha: float
    beta: float
    gamma: float


def _build_optimizer(module, seed: int = 1337):
    random.seed(seed)
    holobit = DummyHolobit(alpha=-0.4, beta=1.2, gamma=0.05)
    bounds = {"alpha": (-1.0, 1.0), "beta": (-2.0, 2.0), "gamma": (0.0, 1.0)}

    def fitness(candidate: DummyHolobit) -> float:
        target = (0.1, 1.1, 0.25)
        return -(
            (candidate.alpha - target[0]) ** 2
            + (candidate.beta - target[1]) ** 2
            + (candidate.gamma - target[2]) ** 2
        )

    optimizer = module.GeneticOptimizer(
        holobit,
        bounds,
        fitness,
        population_size=12,
        generations=6,
        mutation_rate=0.15,
    )
    return optimizer, holobit


def _run_optimizer(module, seed: int = 1337):
    optimizer, holobit = _build_optimizer(module, seed=seed)
    best = optimizer.run()
    return best.genes, holobit


def _manual_time(func, iterations: int = 15, rounds: int = 5) -> float:
    samples: list[float] = []
    for _ in range(rounds):
        start = time.perf_counter()
        for _ in range(iterations):
            func()
        samples.append(time.perf_counter() - start)
    return statistics.mean(samples) / iterations


@pytest.mark.parametrize("seed", [1234, 2024])
def test_genetic_optimizer_matches_python(genetic_optimizer_variants, seed):
    compiled_module, python_module = genetic_optimizer_variants

    compiled_genes, compiled_holobit = _run_optimizer(compiled_module, seed=seed)
    python_genes, python_holobit = _run_optimizer(python_module, seed=seed)

    for key, py_value in python_genes.items():
        assert compiled_genes[key] == pytest.approx(py_value, rel=1e-6, abs=1e-6)
    assert compiled_holobit.alpha == pytest.approx(python_holobit.alpha)
    assert compiled_holobit.beta == pytest.approx(python_holobit.beta)
    assert compiled_holobit.gamma == pytest.approx(python_holobit.gamma)


@pytest.mark.parametrize("dimension", [2, 3])
def test_entrelazar_matches_python(operations_variants, dimension):
    (compiled_module, compiled_quark), (python_module, python_quark) = operations_variants

    estado1 = np.linspace(0, 1, dimension, dtype=complex)
    estado2 = np.linspace(1, 0, dimension, dtype=complex) * (1 + 0.5j)

    compiled_result = compiled_module.entrelazar(
        compiled_quark(estado=estado1), compiled_quark(estado=estado2)
    )
    python_result = python_module.entrelazar(
        python_quark(estado=estado1), python_quark(estado=estado2)
    )

    assert np.allclose(compiled_result, python_result)


@pytest.mark.skipif(not HAS_BENCHMARK, reason="pytest-benchmark no está instalado")
@pytest.mark.benchmark(group="genetic_optimizer_run")
@pytest.mark.slow
def test_genetic_optimizer_benchmark(genetic_optimizer_variants, benchmark):
    compiled_module, python_module = genetic_optimizer_variants

    if not getattr(compiled_module, "USING_COMPILED", False):
        pytest.xfail("Extensión Cython de genetic_optimizer no disponible.")

    def run_compiled():
        optimizer, _ = _build_optimizer(compiled_module, seed=99)
        return optimizer.run()

    compiled_result = benchmark.pedantic(run_compiled, iterations=1, rounds=8, warmup_rounds=2)
    python_mean = _manual_time(lambda: _build_optimizer(python_module, seed=99)[0].run())
    benchmark.extra_info["python_mean"] = python_mean

    assert benchmark.stats.stats["mean"] <= python_mean * 0.9, (
        "La versión compilada debe ofrecer al menos un 10% de mejora frente a la implementación en Python."
    )


@pytest.mark.skipif(not HAS_BENCHMARK, reason="pytest-benchmark no está instalado")
@pytest.mark.benchmark(group="entrelazar")
@pytest.mark.slow
def test_entrelazar_benchmark(operations_variants, benchmark):
    (compiled_module, compiled_quark), (python_module, python_quark) = operations_variants

    if not getattr(compiled_module, "USING_COMPILED", False):
        pytest.xfail("Extensión Cython de operations no disponible.")

    def build_inputs(module, quark_cls):
        estado1 = np.array([1.0 + 0j, 0.25 + 0.75j])
        estado2 = np.array([0.6 + 0.2j, -0.1 + 0.9j])
        return quark_cls(estado=estado1), quark_cls(estado=estado2)

    def run_compiled():
        q1, q2 = build_inputs(compiled_module, compiled_quark)
        return compiled_module.entrelazar(q1, q2)

    compiled_result = benchmark.pedantic(run_compiled, iterations=3, rounds=15, warmup_rounds=2)
    python_output = python_module.entrelazar(*build_inputs(python_module, python_quark))
    python_mean = _manual_time(lambda: python_module.entrelazar(*build_inputs(python_module, python_quark)))
    benchmark.extra_info["python_mean"] = python_mean

    assert np.allclose(compiled_result, python_output)
    assert benchmark.stats.stats["mean"] <= python_mean * 0.9, "Se espera una mejora mínima del 10% en la versión Cython."
