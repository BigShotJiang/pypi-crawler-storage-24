"""Fixtures compartidos para aislar el estado de Cython en las pruebas."""

from __future__ import annotations

import importlib
import sys
from collections.abc import Iterator

import pytest


def _clear_module_variants(module_name: str) -> None:
    """Elimina el módulo objetivo y sus variantes compilada/Python del *cache* de importación."""

    base_package = module_name.rsplit(".", 1)[0]
    module_base = module_name.split(".")[-1]
    variants = {
        module_name,
        f"{base_package}.{module_base}_c",
        f"{base_package}.{module_base}_py",
    }
    for key in list(sys.modules):
        if key in variants or key.startswith(f"{module_name}."):
            sys.modules.pop(key, None)


def _import_with_env(monkeypatch: pytest.MonkeyPatch, module_name: str, env_value: str):
    """Recarga un módulo forzando el valor de ``HOLOBIT_DISABLE_CYTHON``."""

    monkeypatch.setenv("HOLOBIT_DISABLE_CYTHON", env_value)
    _clear_module_variants(module_name)
    return importlib.import_module(module_name)


@pytest.fixture()
def operations_variants(monkeypatch: pytest.MonkeyPatch) -> Iterator[tuple[tuple[object, type], tuple[object, type]]]:
    """Proporciona operaciones y clase ``Quark`` en modos compilado y Python puro, limpiando tras usarlos."""

    compiled_module = _import_with_env(monkeypatch, "holobit_sdk.core.operations", "0")
    compiled_quark = _import_with_env(monkeypatch, "holobit_sdk.core.quark", "0").Quark

    python_module = _import_with_env(monkeypatch, "holobit_sdk.core.operations", "1")
    python_quark = _import_with_env(monkeypatch, "holobit_sdk.core.quark", "1").Quark

    yield (compiled_module, compiled_quark), (python_module, python_quark)
    _clear_module_variants("holobit_sdk.core.operations")
    _clear_module_variants("holobit_sdk.core.quark")


@pytest.fixture()
def genetic_optimizer_variants(monkeypatch: pytest.MonkeyPatch) -> Iterator[tuple[object, object]]:
    """Proporciona las variantes compilada y Python puro del optimizador genético."""

    compiled_module = _import_with_env(monkeypatch, "holobit_sdk.core.genetic_optimizer", "0")
    python_module = _import_with_env(monkeypatch, "holobit_sdk.core.genetic_optimizer", "1")
    yield compiled_module, python_module
    _clear_module_variants("holobit_sdk.core.genetic_optimizer")
