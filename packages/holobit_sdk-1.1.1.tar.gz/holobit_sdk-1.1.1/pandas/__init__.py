"""Subset muy pequeño de :mod:`pandas` necesario para las pruebas."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Sequence

import numpy as np

__all__ = ["DataFrame"]


@dataclass
class DataFrame:
    """Representación tabular mínima basada en ``numpy``."""

    _data: np.ndarray

    def __init__(self, data: Iterable[Sequence[Any]] | np.ndarray) -> None:
        self._data = np.asarray(list(data) if not isinstance(data, np.ndarray) else data, dtype=float)

    def to_numpy(self) -> np.ndarray:
        return np.array(self._data, copy=True)

    def __len__(self) -> int:  # pragma: no cover - compatibilidad
        return len(self._data)

    def __iter__(self):  # pragma: no cover - compatibilidad
        return iter(self._data)
