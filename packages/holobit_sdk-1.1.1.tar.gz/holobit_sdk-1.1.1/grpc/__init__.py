"""Implementación mínima de ``grpc`` para las pruebas del SDK.

Esta versión ligera replica solo la API utilizada por los tests unitarios. No
realiza comunicaciones reales por red; en su lugar comparte instancias de
servidor a través de un registro en memoria para que los canales puedan
invocar los handlers registrados.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import threading
from types import SimpleNamespace
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

__all__ = [
    "StatusCode",
    "ServerInterceptor",
    "ServicerContext",
    "RpcError",
    "RpcMethodHandler",
    "Server",
    "Channel",
    "server",
    "insecure_channel",
    "ssl_server_credentials",
    "unary_unary_rpc_method_handler",
    "unary_stream_rpc_method_handler",
    "stream_unary_rpc_method_handler",
    "stream_stream_rpc_method_handler",
    "method_handlers_generic_handler",
]

__version__ = "1.74.0"


class StatusCode(Enum):
    OK = "ok"
    INVALID_ARGUMENT = "invalid_argument"
    UNAUTHENTICATED = "unauthenticated"
    UNIMPLEMENTED = "unimplemented"


class RpcError(RuntimeError):
    """Excepción que imita la interfaz del cliente de gRPC."""

    def __init__(self, code: StatusCode, details: str) -> None:
        super().__init__(f"{code.name}: {details}")
        self._code = code
        self._details = details

    def code(self) -> StatusCode:
        return self._code

    def details(self) -> str:
        return self._details


class _RpcAbort(RuntimeError):
    def __init__(self, code: StatusCode, details: str) -> None:
        super().__init__(details)
        self.code = code
        self.details = details


class ServicerContext:
    """Contexto simplificado para handlers de servicio."""

    def __init__(self, metadata: Sequence[Tuple[str, str]]) -> None:
        self._metadata = list(metadata)
        self._code = StatusCode.OK
        self._details = ""

    def invocation_metadata(self) -> Sequence[Tuple[str, str]]:
        return list(self._metadata)

    def abort(self, code: StatusCode, details: str) -> None:
        raise _RpcAbort(code, details)

    def set_code(self, code: StatusCode) -> None:  # pragma: no cover - compatibilidad
        self._code = code

    def set_details(self, details: str) -> None:  # pragma: no cover - compatibilidad
        self._details = details


class ServerInterceptor:
    """Interceptor base compatible con la API original."""

    def intercept_service(self, continuation: Callable[["HandlerCallDetails"], "RpcMethodHandler"], handler_call_details: "HandlerCallDetails") -> "RpcMethodHandler":  # noqa: E501
        return continuation(handler_call_details)


@dataclass
class HandlerCallDetails:
    method: str
    invocation_metadata: Sequence[Tuple[str, str]]


class RpcMethodHandler:
    def __init__(
        self,
        unary_unary: Optional[Callable[[Any, ServicerContext], Any]] = None,
        unary_stream: Optional[Callable[[Any, ServicerContext], Iterable[Any]]] = None,
        stream_unary: Optional[Callable[[Iterable[Any], ServicerContext], Any]] = None,
        stream_stream: Optional[Callable[[Iterable[Any], ServicerContext], Iterable[Any]]] = None,
        *,
        request_deserializer: Optional[Callable[[bytes], Any]] = None,
        response_serializer: Optional[Callable[[Any], bytes]] = None,
    ) -> None:
        self.unary_unary = unary_unary
        self.unary_stream = unary_stream
        self.stream_unary = stream_unary
        self.stream_stream = stream_stream
        self.request_deserializer = request_deserializer or (lambda x: x)
        self.response_serializer = response_serializer or (lambda x: x)


def unary_unary_rpc_method_handler(
    behavior: Callable[[Any, ServicerContext], Any],
    *,
    request_deserializer: Optional[Callable[[bytes], Any]] = None,
    response_serializer: Optional[Callable[[Any], bytes]] = None,
) -> RpcMethodHandler:
    return RpcMethodHandler(
        unary_unary=behavior,
        request_deserializer=request_deserializer,
        response_serializer=response_serializer,
    )


def unary_stream_rpc_method_handler(
    behavior: Callable[[Any, ServicerContext], Iterable[Any]],
    *,
    request_deserializer: Optional[Callable[[bytes], Any]] = None,
    response_serializer: Optional[Callable[[Any], bytes]] = None,
) -> RpcMethodHandler:
    return RpcMethodHandler(
        unary_stream=behavior,
        request_deserializer=request_deserializer,
        response_serializer=response_serializer,
    )


def stream_unary_rpc_method_handler(
    behavior: Callable[[Iterable[Any], ServicerContext], Any],
    *,
    request_deserializer: Optional[Callable[[bytes], Any]] = None,
    response_serializer: Optional[Callable[[Any], bytes]] = None,
) -> RpcMethodHandler:
    return RpcMethodHandler(
        stream_unary=behavior,
        request_deserializer=request_deserializer,
        response_serializer=response_serializer,
    )


def stream_stream_rpc_method_handler(
    behavior: Callable[[Iterable[Any], ServicerContext], Iterable[Any]],
    *,
    request_deserializer: Optional[Callable[[bytes], Any]] = None,
    response_serializer: Optional[Callable[[Any], bytes]] = None,
) -> RpcMethodHandler:
    return RpcMethodHandler(
        stream_stream=behavior,
        request_deserializer=request_deserializer,
        response_serializer=response_serializer,
    )


class GenericRpcHandler:
    def __init__(self, service_name: str, methods: Dict[str, RpcMethodHandler]) -> None:
        self.service_name = service_name
        self.methods = methods


def method_handlers_generic_handler(service_name: str, methods: Dict[str, RpcMethodHandler]) -> GenericRpcHandler:
    return GenericRpcHandler(service_name, methods)


_registry: Dict[int, "Server"] = {}
_next_port = 50000


def _extract_port(target: str) -> int:
    """Obtiene el puerto entero desde ``target``.

    Soporta direcciones IPv6 con el formato ``[::]:50051`` además de las
    convenciones ``host:puerto`` utilizadas por IPv4 y ``localhost``.
    """

    if target.startswith("["):
        end = target.find("]")
        if end == -1:
            raise ValueError(f"Dirección IPv6 inválida: {target}")
        remainder = target[end + 1 :]
        if remainder.startswith(":"):
            remainder = remainder[1:]
        port_str = remainder or "0"
    else:
        if ":" in target:
            _, _, port_str = target.rpartition(":")
        else:
            port_str = target

    port_str = port_str.strip()
    if not port_str:
        raise ValueError(f"No se especificó puerto en: {target}")

    return int(port_str)


def _reserve_port(port: int) -> int:
    global _next_port
    if port == 0:
        while _next_port in _registry:
            _next_port += 1
        port = _next_port
        _next_port += 1
    if port in _registry:
        raise RuntimeError(f"El puerto {port} ya está en uso")
    return port


class Server:
    def __init__(self, interceptors: Sequence[ServerInterceptor] = ()) -> None:
        self._interceptors = list(interceptors)
        self._handlers: Dict[str, RpcMethodHandler] = {}
        self._port: Optional[int] = None
        self._started = False
        self._stop_event = threading.Event()

    def add_generic_rpc_handlers(self, handlers: Sequence[GenericRpcHandler]) -> None:
        for handler in handlers:
            for name, rpc_handler in handler.methods.items():
                method = f"/{handler.service_name}/{name}"
                self._handlers[method] = rpc_handler

    def add_registered_method_handlers(self, service_name: str, methods: Dict[str, RpcMethodHandler]) -> None:  # pragma: no cover - compatibilidad
        for name, handler in methods.items():
            self._handlers[f"/{service_name}/{name}"] = handler

    def add_insecure_port(self, target: str) -> int:
        port = _reserve_port(_extract_port(target))
        self._port = port
        return port

    def add_secure_port(self, target: str, _credentials: Any) -> int:  # pragma: no cover - compatibilidad
        return self.add_insecure_port(target)

    def start(self) -> None:
        if self._port is None:
            raise RuntimeError("Debe configurarse un puerto antes de iniciar el servidor")
        _registry[self._port] = self
        self._started = True
        self._stop_event.clear()

    def stop(self, _grace: Optional[float]) -> None:
        if self._port is not None:
            _registry.pop(self._port, None)
        self._started = False
        self._stop_event.set()

    def wait_for_termination(self) -> None:  # pragma: no cover - compatibilidad
        try:
            self._stop_event.wait()
        except KeyboardInterrupt:  # pragma: no cover - comportamiento interactivo
            pass

    def _invoke(self, method: str, payload: bytes, metadata: Sequence[Tuple[str, str]]) -> bytes:
        if method not in self._handlers:
            raise RpcError(StatusCode.UNIMPLEMENTED, f"Método {method} no registrado")
        handler = self._handlers[method]
        call_details = HandlerCallDetails(method=method, invocation_metadata=metadata)

        def _build_continuation(current_handler: RpcMethodHandler) -> Callable[[HandlerCallDetails], RpcMethodHandler]:
            return lambda _details: current_handler

        current_handler = handler
        for interceptor in self._interceptors:
            continuation = _build_continuation(current_handler)
            maybe_handler = interceptor.intercept_service(continuation, call_details)
            if maybe_handler is None:
                return b""
            current_handler = maybe_handler

        request = current_handler.request_deserializer(payload)
        context = ServicerContext(metadata)
        try:
            if current_handler.unary_unary:
                response = current_handler.unary_unary(request, context)
            else:  # pragma: no cover - solo se usan métodos unary-unary en las pruebas
                raise RpcError(StatusCode.UNIMPLEMENTED, "Tipo de RPC no soportado en el stub")
        except _RpcAbort as exc:  # pragma: no cover - el flujo normal no lo usa
            raise RpcError(exc.code, exc.details) from None
        return current_handler.response_serializer(response)


class Channel:
    def __init__(self, target: str) -> None:
        _host, _, port_str = target.partition(":")
        port = int(port_str)
        if port not in _registry:
            raise RuntimeError(f"No hay servidor registrado en el puerto {port}")
        self._server = _registry[port]
        self._target = target

    def unary_unary(
        self,
        method: str,
        *,
        request_serializer: Optional[Callable[[Any], bytes]] = None,
        response_deserializer: Optional[Callable[[bytes], Any]] = None,
        _registered_method: bool | None = None,
    ) -> Callable[[Any, Optional[Sequence[Tuple[str, str]]]], Any]:
        serializer = request_serializer or (lambda obj: obj)
        deserializer = response_deserializer or (lambda data: data)

        def _call(request: Any, *, metadata: Optional[Sequence[Tuple[str, str]]] = None, timeout: Optional[float] = None) -> Any:  # noqa: ARG001 - compatibilidad
            metadata_seq = list(metadata or [])
            payload = serializer(request)
            try:
                response = self._server._invoke(method, payload, metadata_seq)
            except RpcError:
                raise
            return deserializer(response)

        return _call

    def close(self) -> None:  # pragma: no cover - compatibilidad
        pass

    def __enter__(self) -> "Channel":  # pragma: no cover - compatibilidad
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # pragma: no cover - compatibilidad
        self.close()


def server(
    thread_pool: Any,
    *,
    interceptors: Sequence[ServerInterceptor] = (),
) -> Server:
    return Server(interceptors=interceptors)


def insecure_channel(target: str) -> Channel:
    return Channel(target)


def ssl_server_credentials(_pairs: Sequence[Tuple[bytes, bytes]]) -> SimpleNamespace:  # pragma: no cover - compatibilidad
    return SimpleNamespace()


experimental = SimpleNamespace()  # pragma: no cover - compatibilidad
