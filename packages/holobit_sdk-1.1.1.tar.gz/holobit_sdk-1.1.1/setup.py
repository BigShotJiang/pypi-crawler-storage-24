import json
import os
from pathlib import Path

from setuptools import find_packages, setup
from setuptools.command.build_ext import build_ext


EXPLICIT_CYTHON_MODULES = [
    Path("holobit_sdk/assembler/virtual_machine.pyx"),
    Path("holobit_sdk/assembler/parser.pyx"),
    Path("holobit_sdk/core/holobit.pyx"),
    Path("holobit_sdk/core/interactions.pyx"),
    Path("holobit_sdk/core/genetic_optimizer.pyx"),
    Path("holobit_sdk/core/operations.pyx"),
    Path("holobit_sdk/quantum_holocron/core/group_evolution.pyx"),
    Path("holobit_sdk/quantum_holocron/fractal.pyx"),
    Path("holobit_sdk/quantum_holocron/fractal_evolution.pyx"),
    Path("holobit_sdk/quantum_holocron/simulation/collisions.pyx"),
]


def _load_cython_sources() -> list[Path]:
    """Obtiene las rutas a los módulos Cython de forma explícita y admite ampliaciones vía perfilado."""

    cython_targets = Path("build/cython_targets.json")
    configured_sources: set[Path] = {path for path in EXPLICIT_CYTHON_MODULES if path.exists()}

    if cython_targets.exists():
        data = json.loads(cython_targets.read_text())
        candidates = data.get("source_paths", [])
        for candidate in candidates:
            candidate_path = Path(candidate)
            pyx_path = candidate_path.with_suffix(".pyx")
            if pyx_path.exists():
                configured_sources.add(pyx_path)
            elif candidate_path.suffix == ".pyx" and candidate_path.exists():
                configured_sources.add(candidate_path)
            elif candidate_path.suffix == ".py" and candidate_path.exists():
                configured_sources.add(candidate_path)

    return sorted(configured_sources)


def build_extensions():
    try:
        from Cython.Build import cythonize
        from setuptools import Extension
    except ImportError:
        return []

    # Evitar compilación durante importaciones en entornos de prueba o análisis
    # Esto permite importar este módulo para inspección sin requerir toolchain C
    if os.environ.get("PYTEST_CURRENT_TEST") or os.environ.get("HOLOBIT_IMPORT_ONLY") == "1":
        return []

    if os.environ.get("HOLOBIT_DISABLE_CYTHON", "0") == "1":
        return []

    cython_sources = _load_cython_sources()
    if not cython_sources:
        return []

    profile_enabled = os.environ.get("HOLOBIT_CYTHON_PROFILE", "0") == "1"
    define_macros = [("CYTHON_TRACE_NOGIL", "1" if profile_enabled else "0")]
    compiler_directives = {
        "boundscheck": False,
        "language_level": 3,
        "cdivision": True,
    }
    if profile_enabled:
        compiler_directives.update({"profile": True, "linetrace": True})

    extensions = []
    for source in cython_sources:
        stem = source.stem
        module_path = source.with_suffix("")
        if source.with_name(f"{stem}_py.py").exists():
            module_path = module_path.with_name(f"{stem}_c")

        module_name = module_path.as_posix().replace("/", ".")
        extensions.append(Extension(module_name, [str(source)], define_macros=define_macros))

    return cythonize(extensions, compiler_directives=compiler_directives)


def _package_data_files() -> list[str]:
    """Devuelve los archivos relevantes para distribuir junto al paquete."""

    base = Path("holobit_sdk")
    cython_files = [
        str(path.relative_to(base)) for path in _load_cython_sources() if path.exists()
    ]
    pxd_files = [str(path.relative_to(base)) for path in base.rglob("*.pxd")]
    generated_c = [str(path.relative_to(base)) for path in base.rglob("*.c")]

    # Eliminamos duplicados manteniendo el orden de descubrimiento
    seen = set()
    package_files: list[str] = []
    for item in cython_files + pxd_files + generated_c:
        if item not in seen:
            seen.add(item)
            package_files.append(item)

    return package_files


class OptionalBuildExt(build_ext):
    def run(self):
        try:
            super().run()
        except Exception as exc:
            self._handle_build_error(exc)

    def build_extension(self, ext):
        try:
            super().build_extension(ext)
        except Exception as exc:
            self._handle_build_error(exc)

    def _handle_build_error(self, exc):
        self.extensions = []
        self.warn(  # type: ignore[attr-defined]
            f"Fallo al compilar extensiones Cython; se utilizará la versión en Python puro. Detalle: {exc}"
        )

setup(
    name="holobit-sdk",
    version="1.0.10",
    author="Adolfo González Hernández",
    author_email="adolfogonzal@gmail.com",
    description="SDK para la transpilación y ejecución de código holográfico cuántico.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/Alphonsus411/holobit_SDK",
    packages=find_packages(),
    package_data={"holobit_sdk": _package_data_files()},
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.10",
    install_requires=[
        "numpy",
        "matplotlib",
    ],
    extras_require={
        "api": [
            "azure-identity",
            "azure-mgmt-batch",
            "bcrypt",
            "boto3",
            "fastapi",
            "grpcio",
            "grpcio-tools",
            "google-cloud-compute",
            "uvicorn",
        ],
        "cython": ["Cython>=0.29.36"],
        "pure": [],
        "qiskit": ["qiskit"],
        "pennylane": ["pennylane"],
        "cirq": ["cirq"],
        "braket": ["amazon-braket-sdk", "amazon-braket-default-simulator"],
        "qutip": ["qutip"],
        "ml": ["pandas", "scikit-learn", "torch"],
    },
    entry_points={
        "console_scripts": [
            "holobit-transpiler=holobit_sdk.transpiler.machine_code_transpiler:main",
            "hololang=holobit_sdk.multi_level.high_level.hololang_cli:main",
        ],
    },
    ext_modules=build_extensions(),
    cmdclass={"build_ext": OptionalBuildExt},
)
