"""Compatibilidad para los módulos gRPC generados.

Este paquete actúa como un contenedor fino que reexpone los módulos
``holobit_pb2`` y ``holobit_pb2_grpc`` generados a partir de los archivos
``.proto``.  El código real vive en ``holobit_sdk.api`` para que las
importaciones internas del SDK funcionen con rutas absolutas y no fallen
cuando el paquete se instala mediante ``pip``.
"""

from __future__ import annotations

import importlib
import sys

_holobit_pb2 = importlib.import_module("holobit_sdk.api.holobit_pb2")
_holobit_pb2_grpc = importlib.import_module("holobit_sdk.api.holobit_pb2_grpc")

# Atributos disponibles al hacer ``from api import holobit_pb2``
holobit_pb2 = _holobit_pb2
holobit_pb2_grpc = _holobit_pb2_grpc

# Registramos los submódulos para que ``import api.holobit_pb2`` siga
# funcionando, en caso de que alguien dependa de esa ruta.
sys.modules.setdefault(__name__ + ".holobit_pb2", _holobit_pb2)
sys.modules.setdefault(__name__ + ".holobit_pb2_grpc", _holobit_pb2_grpc)

__all__ = ["holobit_pb2", "holobit_pb2_grpc"]
