"""Paquete de ejemplos ejecutables del Holobit SDK.

Este módulo expone utilidades compartidas, en particular la función
``ensure_repo_root_on_path`` que garantiza que la raíz del repositorio esté
disponible en ``sys.path``.  Al centralizar la importación en este archivo
evitamos los errores de importación relativa que se producían cuando los
scripts se ejecutaban directamente con ``python nombre_del_script.py``.
"""

from __future__ import annotations

from ._bootstrap import ensure_repo_root_on_path

__all__ = ["ensure_repo_root_on_path"]
