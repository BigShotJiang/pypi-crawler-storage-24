"""Utilidades compartidas por los ejemplos ejecutables del SDK."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import ModuleType
from typing import MutableMapping

_REPO_ROOT = Path(__file__).resolve().parents[1]


def bootstrap_examples(globals_dict: MutableMapping[str, object]) -> ModuleType:
    """Garantiza que el paquete ``examples`` esté importado al ejecutar scripts.

    Cuando un ejemplo se ejecuta directamente con ``python ruta/al/ejemplo.py`` el
    directorio ``examples`` es la primera entrada en ``sys.path``.  En ese
    contexto, un ``import examples`` fallaría porque Python buscaría un paquete
    ``examples`` dentro del propio directorio, en lugar de cargarlo como paquete
    padre.  Esta función reproduce el mecanismo de importación de Python mediante
    ``importlib`` y registra explícitamente el paquete en ``sys.modules``.  De
    este modo, los scripts pueden realizar importaciones absolutas sin errores de
    importación relativa.

    Parameters
    ----------
    globals_dict:
        El diccionario de ``globals()`` del script que invoca la función.
    """

    package_name = "examples"
    module = sys.modules.get(package_name)
    if module is not None:
        sys.modules.setdefault(f"{package_name}._bootstrap", sys.modules[__name__])
        globals_dict.setdefault("__package__", package_name)
        return module

    script_file = globals_dict.get("__file__")
    if not isinstance(script_file, (str, Path)):
        raise RuntimeError("No se pudo determinar la ruta del script para inicializar 'examples'.")

    package_path = Path(script_file).resolve().parent
    init_file = package_path / "__init__.py"
    spec = importlib.util.spec_from_file_location(package_name, init_file)
    if spec is None or spec.loader is None:
        raise ImportError(f"No se pudo crear el spec del paquete '{package_name}' desde {init_file}.")

    module = importlib.util.module_from_spec(spec)
    # Registrar el módulo tanto con su nombre absoluto como relativo para
    # evitar cargas duplicadas cuando ``examples.__init__`` realiza
    # ``from ._bootstrap import ...``.
    this_module = sys.modules[__name__]
    sys.modules.setdefault(f"{package_name}._bootstrap", this_module)
    sys.modules[package_name] = module
    spec.loader.exec_module(module)  # type: ignore[arg-type]

    globals_dict.setdefault("__package__", package_name)
    return module


def ensure_repo_root_on_path() -> None:
    """Añade la raíz del repositorio al ``sys.path`` si no está presente."""

    repo_root = str(_REPO_ROOT)
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)
