"""Implementación pura de la máquina virtual para entornos sin compilación."""

from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

from pathlib import Path
import os

from holobit_sdk.assembler.parser import AssemblerParser
from holobit_sdk.assembler.executor import AssemblerExecutor
from holobit_sdk.quantum_holocron.core.holocron import Holocron
from holobit_sdk.utils.safe_eval import safe_eval
from holobit_sdk.assembler import macros


class InstructionLimitExceeded(RuntimeError):
    """Se lanza cuando se supera el número máximo de instrucciones."""

    pass


class HolocronInstruction:
    """Representa una instrucción básica del ensamblador holográfico."""

    def __init__(self, name, func):
        self.name = name
        self.func = func

    def execute(self, parser, *args):
        return self.func(parser, *args)


def _crear(parser, nombre, *coords):
    line = f"CREAR {nombre} ({', '.join(coords)})"
    parser.parse_line(line)


def _crear_holobit(parser, nombre, refs):
    line = f"CREAR {nombre} {{{refs}}}"
    parser.parse_line(line)


def _rotar(parser, nombre, eje, angulo):
    line = f"ROT {nombre} {eje} {angulo}"
    parser.parse_line(line)


def _entrelazar(parser, h1, h2):
    """Registra el entrelazamiento entre dos Holobits."""
    line = f"ENTR {h1} {h2}"
    parser.parse_line(line)


def _superpos(parser, *holobits):
    line = "SUPERPOS " + " ".join(holobits)
    parser.parse_line(line)


def _medir(parser, *holobits):
    line = "MEDIR " + " ".join(holobits)
    parser.parse_line(line)


def _sincronizar(parser, *grupos):
    line = "SINCRONIZAR " + " ".join(grupos)
    parser.parse_line(line)


def _entangle(parser, *holobits):
    line = "ENTANGLE " + " ".join(holobits)
    parser.parse_line(line)


def _aplicar(parser, operacion, *grupos):
    op = macros.resolve_alias(operacion)
    if not grupos:
        raise ValueError("Se requiere al menos un grupo")
    if len(grupos) == 1:
        line = f"APLICAR {op} {grupos[0]}"
    else:
        line = f"APLICAR {op} {{{', '.join(grupos)}}}"
    parser.parse_line(line)


def _crear_grupo(parser, holocron, nombre, *holobits):
    line = f"GRUPO {nombre} = {{{', '.join(holobits)}}}"
    parser.parse_line(line)
    holocron.create_group(nombre, list(holobits))


DEFAULT_INSTRUCTIONS = {
    "CREAR": HolocronInstruction("CREAR", _crear),
    "CREAR_HOLOBIT": HolocronInstruction("CREAR_HOLOBIT", _crear_holobit),
    "ROT": HolocronInstruction("ROT", _rotar),
    "ENTR": HolocronInstruction("ENTR", _entrelazar),
    "SUPERPOS": HolocronInstruction("SUPERPOS", _superpos),
    "MEDIR": HolocronInstruction("MEDIR", _medir),
    "SINCRONIZAR": HolocronInstruction("SINCRONIZAR", _sincronizar),
    "ENTANGLE": HolocronInstruction("ENTANGLE", _entangle),
    "APLICAR": HolocronInstruction("APLICAR", _aplicar),
    "GRUPO": HolocronInstruction("GRUPO", _crear_grupo),
}


def _prepare_cache(lines):
    """Prepara versiones strip y split de cada línea para evitar recomputar."""

    stripped = []
    tokens = []
    for line in lines:
        clean = line.strip()
        stripped.append(clean)
        tokens.append(clean.split() if clean else [])
    return stripped, tokens


class AssemblerVM:
    """Pequeña máquina virtual para ejecutar instrucciones holográficas."""

    def __init__(self):
        macros.load_defaults()
        self.parser = AssemblerParser()
        self.executor = AssemblerExecutor(self.parser)
        self.instructions = DEFAULT_INSTRUCTIONS
        self.holocron = Holocron()

    def execute_instruction(self, name, *args):
        name = macros.resolve_alias(name)
        if name not in self.instructions:
            raise ValueError(f"Instrucción desconocida: {name}")
        instr = self.instructions[name]
        if name == "GRUPO":
            instr.execute(self.parser, self.holocron, *args)
        else:
            instr.execute(self.parser, *args)

    def run_program(self, lines, max_instructions=None, _counter=None, _cache=None):
        pc = 0
        stack = []
        if _cache is None:
            stripped, tokens = _prepare_cache(lines)
        else:
            stripped, tokens = _cache
        total = len(lines)
        if _counter is None:
            _counter = {"count": 0}
        while pc < total:
            line = stripped[pc]
            if not line:
                pc += 1
                continue
            if max_instructions is not None:
                _counter["count"] += 1
                if _counter["count"] > max_instructions:
                    raise InstructionLimitExceeded("Límite de instrucciones excedido")
            line_tokens = tokens[pc]
            command = line_tokens[0]
            if command == "FUNC":
                name = line_tokens[1]
                end = self._jump_to_endfunc(tokens, pc + 1)
                self.parser.functions[name] = [ln.strip() for ln in lines[pc + 1 : end]]
                pc = end + 1
                continue
            elif command == "CALL":
                name = line_tokens[1]
                if name not in self.parser.functions:
                    raise KeyError(f"Función desconocida: {name}")
                self.run_program(self.parser.functions[name], max_instructions, _counter)
                pc += 1
                continue
            elif command == "ENDFUNC":
                pc += 1
                continue
            if command == "SI":
                var = line_tokens[1]
                value = self.parser.measurements.get(var, 0)
                if value == True:  # noqa: E712 - comparación explícita para distinguir dicts y enteros
                    pc += 1
                else:
                    pc = self._jump_to_else_or_end(tokens, pc + 1, "SINO")
            elif command == "SINO":
                pc = self._jump_to_end(tokens, pc + 1)
            elif command == "SIQ":
                expr = line[len("SIQ") :].strip()
                try:
                    val = safe_eval(expr, self.parser.measurements)
                except Exception:
                    val = False
                if val == True:  # noqa: E712 - semántica histórica basada en comparación directa
                    pc += 1
                else:
                    pc = self._jump_to_else_or_end(tokens, pc + 1, "ELSEQ")
            elif command == "ELSEQ":
                pc = self._jump_to_end(tokens, pc + 1)
            elif command == "MIENTRAS":
                var = line_tokens[1]
                value = self.parser.measurements.get(var, 0)
                if stack and stack[-1].get("type") == "MIENTRAS" and stack[-1]["start"] == pc:
                    if value == True:  # noqa: E712 - mantener compatibilidad con scripts existentes
                        pc += 1
                    else:
                        stack.pop()
                        pc = self._jump_to_end(tokens, pc + 1)
                else:
                    if value == True:  # noqa: E712 - mantener compatibilidad con scripts existentes
                        stack.append({"type": "MIENTRAS", "start": pc})
                        pc += 1
                    else:
                        pc = self._jump_to_end(tokens, pc + 1)
            elif command == "PARA":
                count = int(line_tokens[1])
                if count <= 0:
                    pc = self._jump_to_end(tokens, pc + 1)
                else:
                    stack.append({"type": "PARA", "start": pc, "remaining": count})
                    pc += 1
            elif command == "PARAG":
                group_id = line_tokens[1]
                group = self.parser.holocron.groups.get(group_id, [])
                end = self._jump_to_end(tokens, pc + 1)
                if not group:
                    pc = end
                else:
                    name_map = {
                        hb: name
                        for name, hb in self.parser.holocron.holobits.items()
                    }
                    block = lines[pc + 1 : end]
                    for hb in group:
                        nombre = name_map.get(hb)
                        if not nombre:
                            continue
                        replaced = [ln.replace("$", nombre) for ln in block]
                        self.run_program(replaced, max_instructions, _counter)
                    pc = end
            elif command == "FIN":
                if stack:
                    top = stack[-1]
                    if top["type"] == "MIENTRAS":
                        pc = top["start"]
                    elif top["type"] == "PARA":
                        top["remaining"] -= 1
                        if top["remaining"] > 0:
                            pc = top["start"] + 1
                        else:
                            stack.pop()
                            pc += 1
                    else:
                        pc += 1
                else:
                    pc += 1
            elif command == "CASO":
                expr = line_tokens[1]
                try:
                    value = int(expr)
                except ValueError:
                    value = self.parser.measurements.get(expr, 0)
                pc = self._execute_caso(lines, tokens, pc, value, max_instructions, _counter)
            elif command in {"CUANDO", "OTRO", "FINCASO"}:
                # Procesados dentro de _execute_caso
                pc += 1
            else:
                self.executor.execute(line)
                pc += 1

    def _jump_to_else_or_end(self, tokens, start, else_token):
        depth = 0
        total = len(tokens)
        for i in range(start, total):
            line_tokens = tokens[i]
            if not line_tokens:
                continue
            cmd = line_tokens[0]
            if cmd in {"SI", "SIQ", "MIENTRAS", "PARA", "PARAG", "CASO"}:
                depth += 1
            elif cmd == "FIN":
                if depth == 0:
                    return i + 1
                depth -= 1
            elif cmd == "FINCASO":
                if depth > 0:
                    depth -= 1
            elif cmd == else_token and depth == 0:
                return i + 1
        return total

    def _jump_to_end(self, tokens, start):
        depth = 0
        total = len(tokens)
        for i in range(start, total):
            line_tokens = tokens[i]
            if not line_tokens:
                continue
            cmd = line_tokens[0]
            if cmd in {"SI", "SIQ", "MIENTRAS", "PARA", "PARAG", "CASO"}:
                depth += 1
            elif cmd == "FIN":
                if depth == 0:
                    return i + 1
                depth -= 1
            elif cmd == "FINCASO" and depth > 0:
                depth -= 1
        return total

    def _execute_caso(self, lines, tokens, start, value, max_instructions, _counter):
        i = start + 1
        total = len(lines)
        cases = []
        default = None
        current_match = None
        block_start = None
        depth = 0
        fin = total
        while i < total:
            line_tokens = tokens[i]
            if not line_tokens:
                i += 1
                continue
            cmd = line_tokens[0]
            if cmd in {"SI", "SIQ", "MIENTRAS", "PARA", "PARAG", "CASO"}:
                depth += 1
            elif cmd == "FIN":
                if depth > 0:
                    depth -= 1
            elif cmd == "FINCASO" and depth == 0:
                if current_match is not None:
                    cases.append((current_match, block_start, i))
                fin = i
                break
            elif depth == 0 and cmd in {"CUANDO", "OTRO"}:
                if current_match is not None:
                    cases.append((current_match, block_start, i))
                current_match = line_tokens[1] if cmd == "CUANDO" else "DEFAULT"
                block_start = i + 1
            i += 1
        for match, start_block, end_block in cases:
            if match == "DEFAULT":
                default = (start_block, end_block)
            elif str(value) == match:
                self.run_program(lines[start_block:end_block], max_instructions, _counter)
                return fin + 1
        if default:
            self.run_program(lines[default[0]:default[1]], max_instructions, _counter)
        return fin + 1

    def _jump_to_endfunc(self, tokens, start):
        depth = 0
        total = len(tokens)
        for i in range(start, total):
            line_tokens = tokens[i]
            if not line_tokens:
                continue
            cmd = line_tokens[0]
            if cmd == "FUNC":
                depth += 1
            elif cmd == "ENDFUNC":
                if depth == 0:
                    return i
                depth -= 1
        return total

    def run_file(self, filepath, max_instructions=None):
        path = Path(filepath)
        root_dir = Path(os.getenv("HOLOBIT_VM_ROOT", Path.cwd())).resolve()

        try:
            real_path = path.resolve(strict=True)
        except FileNotFoundError as exc:
            raise FileNotFoundError(f"Archivo no encontrado: {path}") from exc

        # Endurecimiento: impedir lectura fuera del directorio raíz permitido
        try:
            real_path.relative_to(root_dir)
        except ValueError as exc:
            raise PermissionError("Ruta fuera del directorio permitido") from exc

        # Bloquear enlaces simbólicos y directorios
        if path.is_symlink() or real_path.is_dir():
            raise PermissionError("Acceso no permitido a enlaces simbólicos o directorios")

        try:
            with open(real_path, "r", encoding="utf-8") as f:
                self.run_program(f.readlines(), max_instructions=max_instructions)
        except OSError as exc:
            raise PermissionError(f"No se puede leer el archivo: {real_path}") from exc


__all__ = [
    "AssemblerVM",
    "HolocronInstruction",
    "InstructionLimitExceeded",
    "DEFAULT_INSTRUCTIONS",
]
