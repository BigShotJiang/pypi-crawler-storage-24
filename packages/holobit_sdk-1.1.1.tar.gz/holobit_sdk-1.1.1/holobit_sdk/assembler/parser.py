"""Capa de compatibilidad para el parser del ensamblador.

Carga la extensión Cython compilada cuando está disponible y recurre a la
implementación pura en Python en caso contrario.
"""

from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

try:
    from . import parser_c as _impl
except Exception:  # pragma: no cover - dependiente de compilación
    from . import parser_py as _impl

AssemblerParser = _impl.AssemblerParser

__all__ = ["AssemblerParser"]
