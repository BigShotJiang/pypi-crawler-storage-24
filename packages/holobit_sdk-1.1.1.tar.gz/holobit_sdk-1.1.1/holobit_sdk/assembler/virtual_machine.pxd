# cython: language_level=3
from libc.stddef cimport Py_ssize_t

cdef inline tuple _prepare_cache(list lines)
cdef Py_ssize_t _jump_to_else_or_end(list tokens_cache, Py_ssize_t start, str else_token)
cdef Py_ssize_t _jump_to_end(list tokens_cache, Py_ssize_t start)
cdef Py_ssize_t _jump_to_endfunc(list tokens_cache, Py_ssize_t start)
cdef Py_ssize_t _execute_caso(object self, list lines, list tokens_cache, Py_ssize_t start, object value, object max_instructions, dict _counter)
