"""Punto de entrada de la VM con soporte para compilación opcional.

Si el módulo Cython ``virtual_machine`` está compilado, Python lo cargará de
forma preferente. Este archivo actúa como respaldo puro en entornos donde la
extensión no está disponible e intenta aprovechar la versión compilada si se
encuentra el artefacto junto al archivo fuente.
"""

from importlib import machinery, util
from pathlib import Path


def _load_compiled_module():
    """Carga la extensión compilada si está presente en el mismo paquete."""

    base = Path(__file__).resolve()
    for suffix in machinery.EXTENSION_SUFFIXES:
        candidate = base.with_suffix(suffix)
        if candidate.exists():
            spec = util.spec_from_file_location(
                __name__ + ".__compiled", candidate
            )
            if spec is None or not isinstance(spec.loader, machinery.ExtensionFileLoader):
                continue
            module = util.module_from_spec(spec)
            spec.loader.exec_module(module)  # type: ignore[call-arg]
            return module
    return None


_compiled = _load_compiled_module()

if _compiled is not None:
    for name in getattr(_compiled, "__all__", ()):
        globals()[name] = getattr(_compiled, name)
else:  # pragma: no cover - ruta de compatibilidad
    from . import _virtual_machine_py as _fallback
    for name in getattr(_fallback, "__all__", ()):
        globals()[name] = getattr(_fallback, name)

__all__ = [  # noqa: F822
    "AssemblerVM",
    "HolocronInstruction",
    "InstructionLimitExceeded",
    "DEFAULT_INSTRUCTIONS",
]
