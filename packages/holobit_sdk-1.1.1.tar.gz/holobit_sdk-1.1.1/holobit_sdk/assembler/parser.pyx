# cython: language_level=3, boundscheck=False, cdivision=True

from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

import re
from holobit_sdk.core.holobit import Holobit
from holobit_sdk.core.quark import Quark
from holobit_sdk.assembler import macros

try:  # pragma: no cover - compatibilidad con diferentes puntos de entrada
    from quantum_holocron.core.holocron import Holocron
except ModuleNotFoundError:  # pragma: no cover - Fallback cuando el paquete no está expuesto a nivel superior
    from holobit_sdk.quantum_holocron.core.holocron import Holocron


cdef class AssemblerParser:
    def __cinit__(self):
        self.holobits = {}
        self.entanglements = {}
        self.measurements = {}
        self.holocron = Holocron()
        self.groups = self.holocron.groups
        self.control_tokens = {
            "SI",
            "SINO",
            "SIQ",
            "ELSEQ",
            "MIENTRAS",
            "PARA",
            "PARAG",
            "CASO",
            "CUANDO",
            "OTRO",
            "FIN",
            "FINCASO",
            "CANALIZAR",
            "CANALIZAR_PARALELO",
            "DESENTANGLE",
            "FUNC",
            "ENDFUNC",
            "CALL",
        }
        self._current_macro = None
        self._current_function = None
        self._if_stack = []
        self.functions = {}

    cpdef bint analyze_blocks(self, object lines):
        cdef list stack = []
        cdef Py_ssize_t idx = 0
        cdef Py_ssize_t total
        cdef object line
        cdef str stripped
        cdef str token

        if hasattr(lines, "__len__"):
            total = len(lines)
        else:
            lines = list(lines)
            total = len(lines)

        while idx < total:
            line = lines[idx]
            idx += 1
            stripped = line.strip()
            if not stripped:
                continue
            token = stripped.split()[0]
            if token in {"SI", "SIQ", "MIENTRAS", "PARA", "PARAG", "CASO", "FUNC"}:
                stack.append(token)
            elif token == "FIN":
                if not stack or stack[-1] not in {"SI", "SIQ", "MIENTRAS", "PARA", "PARAG"}:
                    raise ValueError(f"FIN sin bloque en línea {idx}")
                stack.pop()
            elif token == "ENDFUNC":
                if not stack or stack[-1] != "FUNC":
                    raise ValueError(f"ENDFUNC sin FUNC en línea {idx}")
                stack.pop()
            elif token == "FINCASO":
                if not stack or stack[-1] != "CASO":
                    raise ValueError(f"FINCASO sin CASO en línea {idx}")
                stack.pop()
            elif token in {"CUANDO", "OTRO"}:
                if not stack or stack[-1] != "CASO":
                    raise ValueError(f"{token} fuera de CASO en línea {idx}")
        if stack:
            raise ValueError("Bloques sin cerrar: " + ", ".join(stack))
        return True

    cpdef object parse_line(self, object line):
        cdef str raw = str(line).strip()
        cdef str clean
        cdef list tokens
        cdef str command
        cdef object exp_line
        cdef object frame
        cdef dict params
        cdef str nombre
        cdef list referencias
        cdef list quarks
        cdef list holobits_list
        cdef list resultados
        cdef list nombres
        cdef Py_ssize_t idx
        cdef str expr

        if self._current_macro is not None:
            if raw == "#endmacro":
                macros.register_macro(
                    self._current_macro["name"],
                    self._current_macro["params"],
                    self._current_macro["lines"],
                )
                self._current_macro = None
            else:
                if raw and not raw.startswith(";"):
                    self._current_macro["lines"].append(raw)
            return None

        if raw.startswith("#if "):
            expr = raw[4:].strip()
            frame = self._if_stack[-1] if self._if_stack else None
            cond = macros._eval_expr(expr, self.holocron) if (frame is None or frame["active"]) else False
            self._if_stack.append(
                {
                    "cond": cond,
                    "active": (frame is None or frame["active"]) and cond,
                    "parent": True if frame is None else frame["active"],
                    "else": False,
                }
            )
            return None
        if raw == "#else":
            if not self._if_stack:
                raise ValueError("#else sin #if")
            frame = self._if_stack[-1]
            if frame["else"]:
                raise ValueError("Múltiples #else")
            frame["else"] = True
            frame["active"] = frame["parent"] and not frame["cond"]
            return None
        if raw == "#endif":
            if not self._if_stack:
                raise ValueError("#endif sin #if")
            self._if_stack.pop()
            return None
        if self._if_stack and not self._if_stack[-1]["active"]:
            return None

        if raw.startswith("#macro"):
            tokens = raw.split()
            nombre = tokens[1]
            params = {}
            for idx in range(2, len(tokens)):
                p = tokens[idx]
                if "=" in p:
                    key, default = p.split("=", 1)
                else:
                    key, default = p, None
                params[key] = default
            self._current_macro = {"name": nombre, "params": params, "lines": []}
            return None

        clean = raw.split(";")[0].strip()
        if not clean:
            return None

        if self._current_function is not None:
            if clean == "ENDFUNC":
                self._current_function = None
            else:
                self.functions[self._current_function].append(clean)
            return None

        if clean.startswith("FUNC "):
            nombre = clean.split()[1]
            self.functions[nombre] = []
            self._current_function = nombre
            return None

        tokens = clean.split()
        command = macros.resolve_alias(tokens[0])
        tokens[0] = command

        if macros.is_macro(command):
            expanded = macros.expand_macro(command, tokens[1:], self.holocron)
            for exp_line in expanded:
                self.parse_line(exp_line)
            return None

        if command == "CALL":
            if len(tokens) != 2:
                raise ValueError(
                    f"Formato inválido para la instrucción CALL: '{clean}'"
                )
            nombre = tokens[1]
            if nombre not in self.functions:
                raise KeyError(f"La función '{nombre}' no está definida")
            for func_line in self.functions[nombre]:
                self.parse_line(func_line)
            return None

        if command in self.control_tokens:
            if command == "SIQ":
                expr = clean[len("SIQ") :].strip()
                if not expr:
                    raise ValueError(
                        f"Formato inválido para la instrucción {command}: '{clean}'"
                    )
                condicion = macros._eval_expr(expr, self.measurements)
                return {"command": command, "condition": condicion}
            if command in {"SI", "MIENTRAS", "PARA", "PARAG", "CASO"} and len(tokens) != 2:
                raise ValueError(
                    f"Formato inválido para la instrucción {command}: '{clean}'"
                )
            if command in {"SINO", "ELSEQ", "FIN", "OTRO", "FINCASO"} and len(tokens) != 1:
                raise ValueError(
                    f"Formato inválido para la instrucción {command}: '{clean}'"
                )
            if command == "CUANDO" and len(tokens) != 2:
                raise ValueError(
                    f"Formato inválido para la instrucción {command}: '{clean}'"
                )
            if command == "CANALIZAR":
                from holobit_sdk.quantum_holocron.instructions import (
                    AVAILABLE_OPERATIONS,
                )
                if "{" in clean and "}" in clean:
                    match = re.match(r"CANALIZAR\s+\{([^}]*)\}\s+(\w+)", clean)
                    if not match:
                        raise ValueError(
                            f"Formato inválido para la instrucción {command}: '{clean}'"
                        )
                    ops_txt, group = match.groups()
                    operaciones = [
                        macros.resolve_alias(op.strip())
                        for op in ops_txt.split(",")
                        if op.strip()
                    ]
                    if not operaciones:
                        raise ValueError(
                            f"No se especificaron operaciones en {command}: '{clean}'"
                        )
                    resultado = None
                    for op_name in operaciones:
                        if op_name not in AVAILABLE_OPERATIONS:
                            raise KeyError(
                                f"La operación cuántica '{op_name}' no está definida."
                            )
                        operation = AVAILABLE_OPERATIONS[op_name]
                        resultado = self.holocron.execute_quantum_operation(
                            operation, group
                        )
                        self.holocron.groups[group] = resultado
                    return resultado
                if len(tokens) < 3:
                    raise ValueError(
                        f"Formato inválido para la instrucción {command}: '{clean}'"
                    )
                operation_name = macros.resolve_alias(tokens[1])
                grupos = tokens[2:]
                if operation_name not in AVAILABLE_OPERATIONS:
                    raise KeyError(
                        f"La operación cuántica '{operation_name}' no está definida."
                    )
                operation = AVAILABLE_OPERATIONS[operation_name]
                target = grupos[0] if len(grupos) == 1 else grupos
                resultado = self.holocron.execute_quantum_operation(operation, target)
                if isinstance(target, str):
                    self.holocron.groups[target] = resultado
                return resultado
            if command == "CANALIZAR_PARALELO":
                from holobit_sdk.quantum_holocron.instructions import (
                    AVAILABLE_OPERATIONS,
                )
                match = re.match(r"CANALIZAR_PARALELO\s+\{([^}]*)\}\s*$", clean)
                if not match:
                    raise ValueError(
                        f"Formato inválido para la instrucción {command}: '{clean}'"
                    )
                contenido = match.group(1).strip()
                if not contenido:
                    raise ValueError(
                        f"No se especificaron operaciones en {command}: '{clean}'"
                    )
                pares = [p.strip() for p in contenido.split(",") if p.strip()]
                mapping = {}
                for par in pares:
                    if ":" not in par:
                        raise ValueError(
                            f"Par inválido '{par}' en {command}: '{clean}'"
                        )
                    op_txt, grupo = par.split(":", 1)
                    op_name = macros.resolve_alias(op_txt.strip())
                    grupo = grupo.strip()
                    if op_name not in AVAILABLE_OPERATIONS:
                        raise KeyError(
                            f"La operación cuántica '{op_name}' no está definida."
                        )
                    mapping[AVAILABLE_OPERATIONS[op_name]] = grupo
                resultados = self.holocron.execute_parallel_operations(mapping)
                for gid, res in resultados.items():
                    self.holocron.groups[gid] = res
                return resultados
            if command == "DESENTANGLE":
                pass
            else:
                return {"command": command, "args": tokens[1:]}

        if len(tokens) < 2:
            raise ValueError(f"Línea inválida: '{clean}'")

        if command == "CREAR":
            if len(tokens) < 3:
                raise ValueError(f"Formato inválido para la instrucción CREAR: '{clean}'")
            tipo = None
            if tokens[1] in {"QUARK", "HOLOBIT"}:
                tipo = tokens[1]
                if len(tokens) < 4:
                    raise ValueError(
                        f"Formato inválido para la instrucción CREAR: '{clean}'"
                    )
                nombre = tokens[2]
                contenido = " ".join(tokens[3:]).strip()
            else:
                nombre = tokens[1]
                contenido = " ".join(tokens[2:]).strip()

            if tipo is None:
                if contenido.startswith("{") and contenido.endswith("}"):
                    tipo = "HOLOBIT"
                elif contenido.startswith("(") and contenido.endswith(")"):
                    tipo = "QUARK"
                else:
                    raise ValueError(f"Formato inválido para CREAR: '{clean}'")

            if tipo == "HOLOBIT":
                if not (contenido.startswith("{") and contenido.endswith("}")):
                    raise ValueError(
                        f"Se esperaban referencias entre llaves para HOLOBIT: '{clean}'"
                    )
                referencias = contenido[1:-1].split(",")
                referencias = [ref.strip() for ref in referencias if ref.strip()]
                if len(referencias) != 6:
                    raise ValueError(
                        f"Un Holobit requiere exactamente 6 referencias, pero se encontraron {len(referencias)}: '{contenido}'"
                    )

                quarks = []
                for ref in referencias:
                    if ref in self.holobits:
                        quarks.append(self.holobits[ref])
                    else:
                        raise KeyError(
                            f"El quark '{ref}' no existe en la tabla de símbolos."
                        )

                self.holobits[nombre] = Holobit(
                    quarks, [self._crear_antiquark(q) for q in quarks]
                )
                self.holocron.add_holobit(nombre, self.holobits[nombre])
            elif tipo == "QUARK":
                if not (contenido.startswith("(") and contenido.endswith(")")):
                    raise ValueError(
                        f"Se esperaban coordenadas entre paréntesis para QUARK: '{clean}'"
                    )
                coords = self._parse_coordinates(contenido)
                self.holobits[nombre] = Quark(*coords)
            else:
                raise ValueError(f"Tipo desconocido para CREAR: '{tipo}'")
        elif command == "ROT":
            if len(tokens) != 4:
                raise ValueError(f"Formato inválido para la instrucción ROT: '{clean}'")
            holobit_name, axis, angle = tokens[1], tokens[2].lower(), tokens[3]
            if holobit_name not in self.holobits:
                raise KeyError(f"El Holobit '{holobit_name}' no existe en la tabla de símbolos.")
            if axis not in ["x", "y", "z"]:
                raise ValueError(f"Eje inválido para rotación: '{axis}'. Debe ser 'x', 'y' o 'z'.")
            try:
                angle = float(angle)
            except ValueError:
                raise ValueError(f"Ángulo inválido para rotación: '{angle}'. Debe ser un número válido.")

            holobit = self.holobits[holobit_name]
            holobit.rotar(axis, angle)
        elif command == "ENTR":
            if len(tokens) != 3:
                raise ValueError(f"Formato inválido para la instrucción ENTR: '{clean}'")
            h1, h2 = tokens[1], tokens[2]
            if h1 not in self.holobits or h2 not in self.holobits:
                raise KeyError("Uno de los Holobits no existe en la tabla de símbolos.")
            from holobit_sdk.core.operations import entrelazar
            hb1 = self.holobits[h1]
            hb2 = self.holobits[h2]
            estado = entrelazar(hb1.quarks[0], hb2.quarks[0])
            self.entanglements[(h1, h2)] = estado
        elif command == "SUPERPOS":
            if len(tokens) < 2:
                raise ValueError(f"Formato inválido para la instrucción SUPERPOS: '{clean}'")
            nombres = tokens[1:]
            holobits_list = []
            for nombre in nombres:
                if nombre not in self.holobits:
                    raise KeyError(f"El Holobit '{nombre}' no existe en la tabla de símbolos.")
                holobits_list.append(self.holobits[nombre])
            from holobit_sdk.quantum_holocron.quantum_algorithm import superposicion_y_medicion
            resultados = superposicion_y_medicion(holobits_list)
            for nombre, resultado in zip(nombres, resultados):
                self.measurements[nombre] = resultado
            return resultados
        elif command == "MEDIR":
            if len(tokens) < 2:
                raise ValueError(f"Formato inválido para la instrucción MEDIR: '{clean}'")
            nombres = tokens[1:]
            holobits_list = []
            for nombre in nombres:
                if nombre not in self.holobits:
                    raise KeyError(f"El Holobit '{nombre}' no existe en la tabla de símbolos.")
                holobits_list.append(self.holobits[nombre])
            from holobit_sdk.quantum_holocron.quantum_algorithm import superposicion_y_medicion
            resultados = superposicion_y_medicion(holobits_list)
            for nombre, resultado in zip(nombres, resultados):
                self.measurements[nombre] = resultado
            return resultados
        elif command == "SINCRONIZAR":
            if len(tokens) < 3:
                raise ValueError(
                    f"Formato inválido para la instrucción SINCRONIZAR: '{clean}'"
                )
            grupos = tokens[1:]
            resultados = self.holocron.synchronize_measurements(grupos)
            for nombre, resultado in resultados.items():
                self.measurements[nombre] = resultado
            return resultados
        elif command == "ENTANGLE":
            if len(tokens) < 3:
                raise ValueError(f"Formato inválido para la instrucción ENTANGLE: '{clean}'")
            nombres = tokens[1:]
            holobits_list = []
            for nombre in nombres:
                if nombre not in self.holobits:
                    raise KeyError(f"El Holobit '{nombre}' no existe en la tabla de símbolos.")
                holobits_list.append(self.holobits[nombre])
            from holobit_sdk.quantum_holocron.entanglement import entangle_holobits
            resultado = entangle_holobits(holobits_list)
            self.entanglements[tuple(nombres)] = resultado
            return resultado
        elif command == "DESENTANGLE":
            if len(tokens) < 3:
                raise ValueError(
                    f"Formato inválido para la instrucción DESENTANGLE: '{clean}'"
                )
            nombres = tokens[1:]
            key = tuple(nombres)
            estado = self.entanglements.get(key, [])
            from holobit_sdk.quantum_holocron.entanglement import desentangle_holobits
            resultado = desentangle_holobits(estado)
            self.entanglements[key] = resultado
            return resultado
        elif command == "GRUPO":
            if "=" not in clean:
                raise ValueError(
                    f"Formato inválido para la instrucción GRUPO: '{clean}'"
                )
            nombre, contenido = clean[len("GRUPO") :].split("=", 1)
            nombre = nombre.strip()
            contenido = contenido.strip()
            if not (contenido.startswith("{") and contenido.endswith("}")):
                raise ValueError(f"Formato inválido para GRUPO: '{clean}'")
            referencias = [
                ref.strip() for ref in contenido[1:-1].split(",") if ref.strip()
            ]
            if not referencias:
                raise ValueError(
                    f"Se requiere al menos un Holobit para formar un grupo: '{clean}'"
                )
            for ref in referencias:
                if ref not in self.holobits:
                    raise KeyError(
                        f"El Holobit '{ref}' no existe en la tabla de símbolos."
                    )
                if ref not in self.holocron.holobits:
                    self.holocron.add_holobit(ref, self.holobits[ref])
            self.holocron.create_group(nombre, referencias)
        elif command == "AGRUPAR":
            if len(tokens) < 3:
                raise ValueError(
                    f"Formato inválido para la instrucción AGRUPAR: '{clean}'"
                )
            nombre = tokens[1]
            patron_txt = clean.split(None, 2)[2].strip()
            if not (patron_txt.startswith("/") and patron_txt.endswith("/")):
                raise ValueError(f"Patrón inválido para AGRUPAR: '{clean}'")
            patron = patron_txt[1:-1]
            self.holocron.create_group_from_pattern(nombre, patron)
        elif command == "FUSIONAR":
            if "=" not in clean:
                raise ValueError(
                    f"Formato inválido para la instrucción FUSIONAR: '{clean}'"
                )
            nombre, contenido = clean[len("FUSIONAR") :].split("=", 1)
            nombre = nombre.strip()
            contenido = contenido.strip()
            if not (contenido.startswith("{") and contenido.endswith("}")):
                raise ValueError(f"Formato inválido para FUSIONAR: '{clean}'")
            grupos = [g.strip() for g in contenido[1:-1].split(",") if g.strip()]
            if len(grupos) < 2:
                raise ValueError(
                    f"Se requieren al menos dos grupos para fusionar: '{clean}'"
                )
            self.holocron.merge_groups(nombre, grupos)
        elif command == "DIVIDIR":
            if "=" not in clean:
                raise ValueError(
                    f"Formato inválido para la instrucción DIVIDIR: '{clean}'"
                )
            left, contenido = clean[len("DIVIDIR") :].split("=", 1)
            left = left.strip()
            partes = left.split()
            if len(partes) != 2:
                raise ValueError(
                    f"Formato inválido para DIVIDIR, se esperaba 'DIVIDIR origen nuevo = {{...}}': '{clean}'"
                )
            origen, nuevo = partes
            contenido = contenido.strip()
            if not (contenido.startswith("{") and contenido.endswith("}")):
                raise ValueError(f"Formato inválido para DIVIDIR: '{clean}'")
            holobits_ids = [
                ref.strip() for ref in contenido[1:-1].split(",") if ref.strip()
            ]
            if not holobits_ids:
                raise ValueError(
                    f"Se requiere al menos un Holobit para dividir: '{clean}'"
                )
            self.holocron.split_group(origen, nuevo, holobits_ids)
        elif command == "APLICAR":
            if len(tokens) < 3:
                raise ValueError(
                    f"Formato inválido para la instrucción APLICAR: '{clean}'"
                )
            operation_name = macros.resolve_alias(tokens[1])
            if len(tokens) == 3:
                grupos_txt = tokens[2]
                if grupos_txt.startswith("{") and grupos_txt.endswith("}"):
                    grupos = [g.strip() for g in grupos_txt[1:-1].split(",") if g.strip()]
                else:
                    grupos = grupos_txt
            else:
                grupos_txt = " ".join(tokens[2:]).strip()
                if grupos_txt.startswith("{") and grupos_txt.endswith("}"):
                    grupos = [g.strip() for g in grupos_txt[1:-1].split(",") if g.strip()]
                else:
                    grupos = [g.strip() for g in tokens[2:]]

            if operation_name == "SWAP" and isinstance(grupos, list) and len(grupos) > 2:
                raise ValueError("SWAP requiere uno o dos grupos")

            from holobit_sdk.quantum_holocron.instructions import assembler_instructions

            if not hasattr(assembler_instructions, operation_name):
                raise KeyError(
                    f"La operación cuántica '{operation_name}' no está definida."
                )
            operation = getattr(assembler_instructions, operation_name)
            return self.holocron.execute_quantum_operation(operation, grupos)
        elif command == "COMPARAR_ESTADO":
            if len(tokens) != 4:
                raise ValueError(
                    f"Formato inválido para la instrucción COMPARAR_ESTADO: '{clean}'"
                )
            clave, estado_a, estado_b = tokens[1:4]
            resultado = self.holocron.compare_states(estado_a, estado_b)
            self.measurements[clave] = resultado
            return resultado
        elif command == "REGISTRAR":
            if len(tokens) != 2:
                raise ValueError(
                    f"Formato inválido para la instrucción REGISTRAR: '{clean}'"
                )
            self.holocron.save_state(tokens[1])
        elif command == "RECUPERAR":
            if len(tokens) != 2:
                raise ValueError(
                    f"Formato inválido para la instrucción RECUPERAR: '{clean}'"
                )
            self.holocron.restore_state(tokens[1])
        else:
            raise ValueError(f"Comando desconocido: '{command}'")
        return None

    cdef tuple _parse_coordinates(self, object coords_string):
        coords_string = str(coords_string).strip()
        if not (coords_string.startswith("(") and coords_string.endswith(")")):
            raise ValueError(f"Las coordenadas deben estar entre paréntesis: '{coords_string}'")
        coords_content = coords_string[1:-1].strip()
        if not coords_content:
            raise ValueError(f"Las coordenadas están vacías: '{coords_string}'")
        try:
            coords = [float(coord.strip()) for coord in coords_content.split(",")]
            if len(coords) != 3:
                raise ValueError(
                    f"Se requieren exactamente 3 coordenadas, pero se encontraron {len(coords)}: '{coords_string}'")
        except ValueError as e:
            raise ValueError(f"Error al procesar las coordenadas '{coords_string}': {e}")
        return (coords[0], coords[1], coords[2])

    cdef Quark _crear_antiquark(self, Quark quark):
        return Quark(-quark.posicion[0], -quark.posicion[1], -quark.posicion[2], quark.estado)
