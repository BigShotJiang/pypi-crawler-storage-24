"""Utilidades ligeras para medir el rendimiento de la máquina virtual.

El objetivo de este módulo es ofrecer una API compartida entre las pruebas
unitarias y los scripts de CI para capturar métricas básicas (tiempos medios e
instrucciones por segundo) tanto de la implementación pura en Python como de la
extensión Cython cuando está disponible. También documenta el umbral usado para
detectar regresiones: la versión compilada no debería ser más lenta que un
**35 %** por encima de la versión pura.
"""

from __future__ import annotations

import importlib
import os
import statistics
import time
from importlib import machinery, util
from typing import Dict, Iterable, Optional, Tuple


VMModule = Tuple[type, Optional[type]]


EXAMPLE_PROGRAM: list[str] = [
    "CREAR Q1 (0, 0, 0)",
    "CREAR Q2 (1, 0, 0)",
    "CREAR Q3 (0, 1, 0)",
    "CREAR Q4 (0, 0, 1)",
    "CREAR Q5 (1, 1, 0)",
    "CREAR Q6 (1, 0, 1)",
    "CREAR H1 {Q1, Q2, Q3, Q4, Q5, Q6}",
    "CREAR H2 {Q1, Q2, Q3, Q4, Q5, Q6}",
    "SUPERPOS H1 H2",
    "ENTR H1 H2",
    "GRUPO G = {H1, H2}",
    "PARAG G",
    "ROT $ x 45",
    "FIN",
    "MEDIR H1 H2",
]

# Umbral documentado para facilitar la detección de regresiones en CI.
MAX_PERFORMANCE_RATIO = 1.35


def has_compiled_vm() -> bool:
    """Comprueba si la extensión Cython de la VM está disponible y habilitada."""

    if os.getenv("HOLOBIT_DISABLE_CYTHON"):
        return False
    spec = util.find_spec("holobit_sdk.assembler.virtual_machine")
    return spec is not None and isinstance(spec.loader, machinery.ExtensionFileLoader)


def load_vm_classes() -> VMModule:
    """Devuelve las clases :class:`AssemblerVM` (Python y Cython si existe)."""

    py_vm_cls = importlib.import_module("holobit_sdk.assembler._virtual_machine_py").AssemblerVM
    cy_vm_cls = None
    if has_compiled_vm():
        cy_vm_cls = importlib.import_module("holobit_sdk.assembler.virtual_machine").AssemblerVM
    return py_vm_cls, cy_vm_cls


def run_microbenchmark(vm_cls: type, program: Iterable[str], iterations: int = 50, samples: int = 5) -> Dict[str, float]:
    """Ejecuta un microbenchmark sencillo sobre ``vm_cls``.

    Devuelve un diccionario con el tiempo medio en segundos y las instrucciones
    por segundo aproximadas, utilizando ``iterations`` ejecuciones por muestra
    y ``samples`` repeticiones para suavizar la variabilidad.
    """

    durations = []
    for _ in range(samples):
        start = time.perf_counter()
        for _ in range(iterations):
            vm = vm_cls()
            vm.run_program(program)
        durations.append(time.perf_counter() - start)

    mean_s = statistics.mean(durations)
    ips = iterations / mean_s if mean_s > 0 else 0.0
    return {"mean_s": mean_s, "ips": ips}


def collect_vm_metrics(program: Iterable[str] | None = None, iterations: int = 100, samples: int = 5) -> Dict[str, Dict[str, float]]:
    """Calcula métricas para la VM Python y, si procede, la versión Cython."""

    program = list(program or EXAMPLE_PROGRAM)
    py_vm_cls, cy_vm_cls = load_vm_classes()
    metrics = {
        "python": run_microbenchmark(py_vm_cls, program, iterations=iterations, samples=samples),
    }
    if cy_vm_cls is not None:
        metrics["cython"] = run_microbenchmark(cy_vm_cls, program, iterations=iterations, samples=samples)
    return metrics

