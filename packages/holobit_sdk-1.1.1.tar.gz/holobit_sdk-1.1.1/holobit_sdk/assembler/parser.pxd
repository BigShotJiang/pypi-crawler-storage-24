# cython: language_level=3
from holobit_sdk.core.quark cimport Quark

cdef class AssemblerParser:
    cpdef bint analyze_blocks(self, object lines)
    cpdef object parse_line(self, object line)
    cdef tuple _parse_coordinates(self, object coords_string)
    cdef Quark _crear_antiquark(self, Quark quark)
