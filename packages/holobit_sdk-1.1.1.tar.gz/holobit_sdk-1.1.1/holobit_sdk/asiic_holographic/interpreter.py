from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

from holobit_sdk.asiic_holographic.translator import ASIICTranslator
from holobit_sdk.assembler.virtual_machine import AssemblerVM


class ASIICInterpreter:
    """Intérprete del ASIIC Holográfico."""

    def __init__(self, vm: AssemblerVM | None = None):
        """Inicializa el intérprete con una VM opcional."""
        self.vm = vm if vm is not None else AssemblerVM()
        self.translator = ASIICTranslator()

    def interpretar(self, comando):
        """Traduce y ejecuta un comando ASIIC."""

        asm_command = self.translator.traducir(comando)
        if (
            asm_command.startswith("Instrucción desconocida")
            or asm_command == "Comando vacío"
        ):
            return asm_command

        parts = asm_command.split()
        instr = parts[0]
        args = parts[1:]

        try:
            self.vm.execute_instruction(instr, *args)
        except (ValueError, KeyError) as e:
            return str(e)

        return asm_command


# Ejemplo de uso
if __name__ == "__main__":
    interprete = ASIICInterpreter()

    # Preparar quarks y holobits necesarios para las demostraciones
    coordenadas = [
        (0.1, 0.2, 0.3),
        (0.4, 0.5, 0.6),
        (0.7, 0.8, 0.9),
        (-0.1, -0.2, -0.3),
        (-0.4, -0.5, -0.6),
        (-0.7, -0.8, -0.9),
        (0.15, 0.25, 0.35),
        (0.45, 0.55, 0.65),
        (0.75, 0.85, 0.95),
        (-0.15, -0.25, -0.35),
        (-0.45, -0.55, -0.65),
        (-0.75, -0.85, -0.95),
    ]
    for idx, (x, y, z) in enumerate(coordenadas, start=1):
        interprete.vm.execute_instruction(
            "CREAR",
            f"Q{idx}",
            *(str(valor) for valor in (x, y, z)),
        )

    referencias_h1 = ", ".join(f"Q{i}" for i in range(1, 7))
    referencias_h2 = ", ".join(f"Q{i}" for i in range(7, 13))
    interprete.vm.execute_instruction("CREAR_HOLOBIT", "H1", referencias_h1)
    interprete.vm.execute_instruction("CREAR_HOLOBIT", "H2", referencias_h2)

    # Ejecutar comandos de prueba
    print(interprete.interpretar("ROTAR H1 z 90"))
    print(interprete.interpretar("ENTRELAZAR H1 H2"))
