# cython: language_level=3
"""Definiciones compartidas de Cython para ``Holobit`` y ``Quark``."""

from libc.math cimport M_PI

ctypedef double complex complex_t

cdef double _deg2rad(double degrees)
cdef void _crear_matriz_rotacion(char eje, double radianes, double[:, :] matriz)


cdef class Quark:
    cdef public double[:] posicion
    cdef public complex_t[:] estado


cdef class Holobit:
    cdef public list quarks
    cdef public list antiquarks
    cdef public double spin
