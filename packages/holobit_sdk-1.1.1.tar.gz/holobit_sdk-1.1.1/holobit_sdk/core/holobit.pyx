# cython: language_level=3
"""Implementación acelerada en Cython de ``Holobit`` y ``Quark``."""

from __future__ import annotations

from libc.math cimport M_PI, cos, sin
import numpy as np
cimport numpy as cnp

ctypedef double complex complex_t


cdef double _deg2rad(double degrees):
    return degrees * (M_PI / 180.0)


cdef void _crear_matriz_rotacion(char eje, double radianes, double[:, :] matriz):
    cdef double c = cos(radianes)
    cdef double s = sin(radianes)
    if eje == b'x'[0]:
        matriz[0, 0] = 1.0
        matriz[0, 1] = 0.0
        matriz[0, 2] = 0.0
        matriz[1, 0] = 0.0
        matriz[1, 1] = c
        matriz[1, 2] = -s
        matriz[2, 0] = 0.0
        matriz[2, 1] = s
        matriz[2, 2] = c
    elif eje == b'y'[0]:
        matriz[0, 0] = c
        matriz[0, 1] = 0.0
        matriz[0, 2] = s
        matriz[1, 0] = 0.0
        matriz[1, 1] = 1.0
        matriz[1, 2] = 0.0
        matriz[2, 0] = -s
        matriz[2, 1] = 0.0
        matriz[2, 2] = c
    elif eje == b'z'[0]:
        matriz[0, 0] = c
        matriz[0, 1] = -s
        matriz[0, 2] = 0.0
        matriz[1, 0] = s
        matriz[1, 1] = c
        matriz[1, 2] = 0.0
        matriz[2, 0] = 0.0
        matriz[2, 1] = 0.0
        matriz[2, 2] = 1.0
    else:
        raise ValueError("El eje debe ser 'x', 'y' o 'z'.")


cdef void _multiplicar_rotacion(double[:, :] matriz, double[:] posicion, double[::1] salida):
    cdef Py_ssize_t i, j
    cdef double acumulado
    for i in range(3):
        acumulado = 0.0
        for j in range(3):
            acumulado += matriz[i, j] * posicion[j]
        salida[i] = acumulado


cdef class Quark:
    """Representa un quark con posición y estado cuántico."""

    cdef public double[:] posicion
    cdef public complex_t[:] estado

    def __init__(self, *coords, estado=None):
        cdef object coords_obj = coords
        if (
            estado is None
            and len(coords) >= 4
            and isinstance(coords[-1], (list, tuple, np.ndarray))
            and np.asarray(coords[-1]).shape == (2,)
        ):
            coords_obj = coords[:-1]
            estado = coords[-1]
        if not coords_obj:
            coords_obj = (0.0, 0.0, 0.0)
        pos_arr = np.array(coords_obj, dtype=np.float64)
        self.posicion = pos_arr
        if estado is None:
            estado = np.array([1, 0], dtype=np.complex128)
        self.estado = np.array(estado, dtype=np.complex128)

    def aplicar_puerta(self, puerta):
        """Aplica una puerta cuántica con bucles tipados."""
        gate = np.asarray(puerta, dtype=np.complex128)
        if gate.ndim != 2:
            raise ValueError("La puerta debe ser una matriz 2D.")
        state_arr = np.asarray(self.estado, dtype=np.complex128)
        if state_arr.shape[0] != gate.shape[1]:
            raise ValueError("Dimensión de la puerta incompatible con el estado del quark.")

        result = np.empty(gate.shape[0], dtype=np.complex128)
        cdef double complex[:, :] gate_view = gate
        cdef double complex[:] state_view = state_arr
        cdef double complex[:] result_view = result
        cdef Py_ssize_t i, j, rows = gate.shape[0], cols = gate.shape[1]
        cdef double complex acumulado
        for i in range(rows):
            acumulado = 0
            for j in range(cols):
                acumulado += gate_view[i, j] * state_view[j]
            result_view[i] = acumulado

        self.estado = result

    def __repr__(self):
        pos = ', '.join(f"{coord}" for coord in self.posicion)
        estado = ', '.join(str(v) for v in self.estado)
        return f"Quark(posicion=[{pos}], estado=[{estado}])"


cdef class Holobit:
    """Representa un Holobit compuesto por quarks y antiquarks."""

    cdef public list quarks
    cdef public list antiquarks
    cdef public double spin

    def __init__(self, quarks, antiquarks, double spin=0.5):
        if len(quarks) != 6 or len(antiquarks) != 6:
            raise ValueError("Un Holobit debe tener exactamente 6 quarks y 6 antiquarks.")
        self.quarks = list(quarks)
        self.antiquarks = list(antiquarks)
        self.spin = spin

    def rotar(self, eje, angulo):
        """Rota el Holobit en el eje especificado por un ángulo dado."""
        if not isinstance(eje, str) or len(eje) != 1:
            raise ValueError("El eje debe ser 'x', 'y' o 'z'.")
        cdef double radianes = _deg2rad(float(angulo))
        matriz_rotacion = np.empty((3, 3), dtype=np.float64)
        cdef double[:, :] matriz_view = matriz_rotacion
        _crear_matriz_rotacion(eje.encode(), radianes, matriz_view)

        cdef Py_ssize_t i, n
        cdef Quark quark
        cdef double[:] pos_view
        cdef double[3] resultado
        elementos_arr = np.empty(len(self.quarks) + len(self.antiquarks), dtype=object)
        cdef object[:] elementos = elementos_arr

        n = len(self.quarks)
        for i in range(n):
            elementos[i] = self.quarks[i]

        cdef Py_ssize_t offset = n
        n += len(self.antiquarks)
        for i in range(len(self.antiquarks)):
            elementos[offset + i] = self.antiquarks[i]

        for i in range(n):
            quark = <Quark>elementos[i]
            pos_view = np.asarray(quark.posicion, dtype=np.float64)
            if pos_view.shape[0] != 3:
                raise ValueError("La posición debe tener exactamente 3 dimensiones para rotar.")
            _multiplicar_rotacion(matriz_view, pos_view, resultado)
            quark.posicion = np.array([resultado[0], resultado[1], resultado[2]], dtype=np.float64)

    def _crear_matriz_rotacion(self, eje, radianes):
        matriz = np.empty((3, 3), dtype=np.float64)
        _crear_matriz_rotacion(eje.encode(), float(radianes), matriz)
        return matriz

    def __repr__(self):
        return f"Holobit(quarks={self.quarks}, antiquarks={self.antiquarks}, spin={self.spin})"
