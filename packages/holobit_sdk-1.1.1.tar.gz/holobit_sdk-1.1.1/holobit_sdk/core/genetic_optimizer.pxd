from cpython.array cimport array

ctypedef dict GeneBounds
ctypedef object FitnessFunc

cdef class HolobitGenome:
    cdef public list gene_names
    cdef Py_ssize_t gene_count
    cdef array _raw_values
    cdef double[:] _values
    cdef bint _has_fitness
    cdef double _fitness

    cpdef mutate(self, double mutation_rate, GeneBounds bounds)
    @staticmethod
    cpdef HolobitGenome crossover(HolobitGenome parent1, HolobitGenome parent2)


cdef class GeneticOptimizer:
    cdef public object holobit
    cdef GeneBounds gene_bounds
    cdef FitnessFunc fitness_func
    cdef int population_size
    cdef int generations
    cdef double mutation_rate
    cdef list _gene_names
    cdef Py_ssize_t _gene_count

    cdef list _create_initial_population(self)
    cdef void _evaluate(self, HolobitGenome genome)
    cdef list _select(self, list population)
    cdef list _crossover_and_mutate(self, list parents)
    cpdef HolobitGenome run(self)
