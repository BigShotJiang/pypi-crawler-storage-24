"""Capa de compatibilidad para el optimizador genético.

Este módulo intenta utilizar la versión compilada en Cython para acelerar
las operaciones. Si no está disponible o está deshabilitada mediante la
variable de entorno ``HOLOBIT_DISABLE_CYTHON``, recurre automáticamente a la
implementación en Python puro.
"""

from __future__ import annotations

from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

import os

_CYTHON_DISABLED = os.environ.get("HOLOBIT_DISABLE_CYTHON", "0") == "1"

if not _CYTHON_DISABLED:
    try:
        from . import genetic_optimizer_c as _impl
        USING_COMPILED = True
    except ImportError:  # pragma: no cover - la ruta de respaldo se prueba aparte
        from . import genetic_optimizer_py as _impl
        USING_COMPILED = False
else:  # pragma: no cover - la ruta de respaldo se prueba aparte
    from . import genetic_optimizer_py as _impl
    USING_COMPILED = False

HolobitGenome = _impl.HolobitGenome
GeneticOptimizer = _impl.GeneticOptimizer

__all__ = ["HolobitGenome", "GeneticOptimizer", "USING_COMPILED"]
