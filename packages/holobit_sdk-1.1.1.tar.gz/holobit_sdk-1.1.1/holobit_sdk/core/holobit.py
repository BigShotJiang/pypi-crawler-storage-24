"""Capa de compatibilidad para el módulo ``holobit``.

Este archivo intenta usar la versión compilada en Cython para acelerar las
operaciones de rotación y la aplicación de puertas cuánticas. Si no está
 disponible, se recurre automáticamente a la implementación en Python puro.
"""

from __future__ import annotations

from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

import os

_CYTHON_DISABLED = os.environ.get("HOLOBIT_DISABLE_CYTHON", "0") == "1"

if not _CYTHON_DISABLED:
    try:
        from . import holobit_c as _impl
        USING_COMPILED = True
    except ImportError:  # pragma: no cover - la ruta de respaldo se prueba aparte
        from . import holobit_py as _impl
        USING_COMPILED = False
else:  # pragma: no cover - la ruta de respaldo se prueba aparte
    from . import holobit_py as _impl
    USING_COMPILED = False

Holobit = _impl.Holobit
Quark = getattr(_impl, "Quark", None)
if Quark is None:
    from .quark import Quark  # noqa: E402

__all__ = ["Holobit", "Quark", "USING_COMPILED"]
