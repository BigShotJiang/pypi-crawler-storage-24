cdef class Quark:
    cdef public double[:] posicion
    cdef public double complex[:] estado
