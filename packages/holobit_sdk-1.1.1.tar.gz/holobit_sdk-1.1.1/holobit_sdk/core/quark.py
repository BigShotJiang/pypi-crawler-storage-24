"""Capa de compatibilidad para el módulo ``quark``.

El módulo intenta utilizar la versión compilada en Cython disponible en
``holobit_c``. Si no está presente, se recurre automáticamente a la
implementación en Python puro.
"""

from __future__ import annotations

from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

try:
    from . import holobit_c as _impl
    USING_COMPILED = True
except ImportError:  # pragma: no cover - la ruta de respaldo se prueba aparte
    from . import quark_py as _impl
    USING_COMPILED = False

Quark = _impl.Quark

__all__ = ["Quark", "USING_COMPILED"]
