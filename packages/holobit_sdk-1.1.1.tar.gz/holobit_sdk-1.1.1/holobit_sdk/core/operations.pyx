# cython: language_level=3
"""Operaciones cuánticas aceleradas en Cython."""

from __future__ import annotations

import numpy as np
cimport numpy as cnp

from .holobit cimport Quark


def entrelazar(Quark quark1, Quark quark2):
    """Entrelaza dos quarks usando el producto tensorial."""
    cdef cnp.complex128_t[:] estado1 = np.asarray(quark1.estado, dtype=np.complex128)
    cdef cnp.complex128_t[:] estado2 = np.asarray(quark2.estado, dtype=np.complex128)
    quark1.estado = estado1
    quark2.estado = estado2
    return np.kron(np.asarray(estado1, dtype=np.complex128), np.asarray(estado2, dtype=np.complex128))


__all__ = ["entrelazar"]
