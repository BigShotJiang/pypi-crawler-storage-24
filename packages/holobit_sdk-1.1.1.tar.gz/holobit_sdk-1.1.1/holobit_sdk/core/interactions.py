"""Capa de compatibilidad para interacciones de Holobits."""

from __future__ import annotations

import os

_CYTHON_DISABLED = os.environ.get("HOLOBIT_DISABLE_CYTHON", "0") == "1"

if not _CYTHON_DISABLED:
    try:
        from . import interactions_c as _impl
        USING_COMPILED = True
    except ImportError:  # pragma: no cover - la ruta de respaldo se prueba aparte
        from . import interactions_py as _impl
        USING_COMPILED = False
else:  # pragma: no cover - la ruta de respaldo se prueba aparte
    from . import interactions_py as _impl
    USING_COMPILED = False

confinar_quarks = _impl.confinar_quarks
cambiar_spin = _impl.cambiar_spin
sincronizar_spin = _impl.sincronizar_spin

__all__ = [
    "confinar_quarks",
    "cambiar_spin",
    "sincronizar_spin",
    "USING_COMPILED",
]
