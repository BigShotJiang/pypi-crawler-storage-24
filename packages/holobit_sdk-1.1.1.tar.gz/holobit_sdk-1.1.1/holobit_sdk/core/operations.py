"""Capa de compatibilidad para operaciones cuánticas."""

from __future__ import annotations

import os

_CYTHON_DISABLED = os.environ.get("HOLOBIT_DISABLE_CYTHON", "0") == "1"

if not _CYTHON_DISABLED:
    try:
        from . import operations_c as _impl
        USING_COMPILED = True
    except ImportError:  # pragma: no cover - la ruta de respaldo se prueba aparte
        from . import operations_py as _impl
        USING_COMPILED = False
else:  # pragma: no cover - la ruta de respaldo se prueba aparte
    from . import operations_py as _impl
    USING_COMPILED = False

entrelazar = _impl.entrelazar

__all__ = ["entrelazar", "USING_COMPILED"]
