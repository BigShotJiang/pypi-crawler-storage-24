# cython: language_level=3
"""Implementación acelerada en Cython del optimizador genético."""

from __future__ import annotations

import copy
import random
from array import array

ctypedef dict GeneBounds
ctypedef object FitnessFunc


cdef class HolobitGenome:
    """Representa un conjunto de genes de un ``Holobit``.

    La estructura interna almacena los valores como un ``array('d')`` para
    permitir operaciones numéricas más rápidas, pero se expone la misma API
    basada en diccionarios que la versión en Python puro.
    """

    cdef public list gene_names
    cdef Py_ssize_t gene_count
    cdef array _raw_values
    cdef double[:] _values
    cdef bint _has_fitness
    cdef double _fitness

    def __init__(self, mapping):
        self.gene_names = list(mapping.keys())
        self.gene_count = <Py_ssize_t>len(self.gene_names)
        self._raw_values = array("d", [float(mapping[name]) for name in self.gene_names])
        cdef double[:] view = self._raw_values
        self._values = view
        self._has_fitness = False
        self._fitness = float("nan")

    @property
    def genes(self):
        return {name: self._values[i] for i, name in enumerate(self.gene_names)}

    @property
    def fitness(self):
        if self._has_fitness:
            return self._fitness
        return None

    @fitness.setter
    def fitness(self, value):
        if value is None:
            self._has_fitness = False
            self._fitness = float("nan")
        else:
            self._has_fitness = True
            self._fitness = float(value)

    cpdef mutate(self, double mutation_rate, GeneBounds bounds):
        cdef Py_ssize_t i
        cdef double low, high, span, perturb, new_val
        cdef object name
        for i in range(self.gene_count):
            if random.random() < mutation_rate:
                name = self.gene_names[i]
                low, high = bounds[name]
                span = high - low
                perturb = random.uniform(-0.1, 0.1) * span
                new_val = self._values[i] + perturb
                if new_val < low:
                    new_val = low
                elif new_val > high:
                    new_val = high
                self._values[i] = new_val

    @staticmethod
    cpdef HolobitGenome crossover(HolobitGenome parent1, HolobitGenome parent2):
        cdef Py_ssize_t i, n = parent1.gene_count
        cdef dict child_genes = {}
        cdef double chosen
        for i in range(n):
            if random.random() < 0.5:
                chosen = parent1._values[i]
            else:
                chosen = parent2._values[i]
            child_genes[parent1.gene_names[i]] = chosen
        return HolobitGenome(child_genes)


cdef class GeneticOptimizer:
    """Optimizador genético básico para ``Holobit``."""

    cdef public object holobit
    cdef GeneBounds gene_bounds
    cdef FitnessFunc fitness_func
    cdef int population_size
    cdef int generations
    cdef double mutation_rate
    cdef list _gene_names
    cdef Py_ssize_t _gene_count

    def __init__(
        self,
        holobit,
        GeneBounds gene_bounds,
        FitnessFunc fitness_func,
        int population_size = 20,
        int generations = 10,
        double mutation_rate = 0.1,
    ):
        self.holobit = holobit
        self.gene_bounds = gene_bounds
        self.fitness_func = fitness_func
        self.population_size = population_size
        self.generations = generations
        self.mutation_rate = mutation_rate
        self._gene_names = list(gene_bounds.keys())
        self._gene_count = <Py_ssize_t>len(self._gene_names)

    cdef list _create_initial_population(self):
        cdef list population = []
        cdef dict genes
        cdef Py_ssize_t i, n = self._gene_count
        cdef object name
        cdef double low, high
        for _ in range(self.population_size):
            genes = {}
            for i in range(n):
                name = self._gene_names[i]
                low, high = self.gene_bounds[name]
                genes[name] = random.uniform(low, high)
            population.append(HolobitGenome(genes))
        return population

    cdef void _evaluate(self, HolobitGenome genome):
        candidate = copy.deepcopy(self.holobit)
        cdef Py_ssize_t i, n = genome.gene_count
        for i in range(n):
            setattr(candidate, genome.gene_names[i], genome._values[i])
        genome.fitness = self.fitness_func(candidate)

    cdef list _select(self, list population):
        cdef list scored = []
        cdef HolobitGenome genome
        cdef double fitness
        for genome in population:
            if genome._has_fitness:
                fitness = genome._fitness
            else:
                fitness = float("-inf")
            scored.append((fitness, genome))

        scored.sort(key=lambda item: item[0], reverse=True)
        return [pair[1] for pair in scored[: self.population_size // 2]]

    cdef list _crossover_and_mutate(self, list parents):
        cdef list offspring = []
        cdef HolobitGenome child
        cdef int target = self.population_size
        while len(offspring) + len(parents) < target:
            p1, p2 = random.sample(parents, 2)
            child = HolobitGenome.crossover(p1, p2)
            child.mutate(self.mutation_rate, self.gene_bounds)
            offspring.append(child)
        return offspring

    cpdef HolobitGenome run(self):
        cdef list population = self._create_initial_population()
        cdef int _
        cdef HolobitGenome best
        for _ in range(self.generations):
            for genome in population:
                self._evaluate(genome)
            parents = self._select(population)
            offspring = self._crossover_and_mutate(parents)
            population = parents + offspring

        best = max(population, key=lambda g: g._fitness if g._has_fitness else float("-inf"))
        for attr, value in best.genes.items():
            setattr(self.holobit, attr, value)
        return best


__all__ = ["HolobitGenome", "GeneticOptimizer"]
