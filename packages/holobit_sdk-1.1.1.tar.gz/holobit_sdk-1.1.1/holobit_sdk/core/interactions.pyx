# cython: language_level=3
"""Interacciones básicas para Holobits con aceleración en Cython."""

from __future__ import annotations

import numpy as np
cimport numpy as cnp

from .holobit cimport Holobit, Quark


def confinar_quarks(Holobit holobit, double limite=1.0):
    """Limita la posición de cada quark dentro de un cubo de lado ``2*limite``.

    Args:
        holobit: Holobit a modificar.
        limite: Valor absoluto máximo permitido para cada coordenada.
    """
    cdef list elementos = holobit.quarks + holobit.antiquarks
    cdef Py_ssize_t i, j, n = len(elementos)
    cdef Quark quark
    cdef double[:] pos_view

    for i in range(n):
        quark = <Quark>elementos[i]
        pos_view = np.asarray(quark.posicion, dtype=np.float64)
        for j in range(pos_view.shape[0]):
            if pos_view[j] > limite:
                pos_view[j] = limite
            elif pos_view[j] < -limite:
                pos_view[j] = -limite
        quark.posicion = pos_view
    return holobit


def cambiar_spin(Holobit holobit, double nuevo_spin):
    """Modifica el valor del *spin* del Holobit."""
    holobit.spin = nuevo_spin
    return holobit


def sincronizar_spin(holobits):
    """Iguala el *spin* de todos los Holobits al promedio del grupo.

    Args:
        holobits: Conjunto de Holobits a sincronizar.
    """
    holobits_list = list(holobits)
    if not holobits_list:
        return holobits_list

    cdef Py_ssize_t i, n = len(holobits_list)
    cdef double total_spin = 0.0
    for i in range(n):
        total_spin += (<Holobit>holobits_list[i]).spin

    cdef double promedio = total_spin / n
    for i in range(n):
        (<Holobit>holobits_list[i]).spin = promedio

    return holobits_list


__all__ = [
    "confinar_quarks",
    "cambiar_spin",
    "sincronizar_spin",
]
