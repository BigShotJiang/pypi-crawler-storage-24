"""Inicializa el paquete ``holobit_sdk`` exponiendo sus submódulos.

Las importaciones se realizan de forma diferida para evitar cargar
submódulos y dependencias opcionales hasta que se necesiten.
"""

from importlib import import_module
from typing import List


_SUBMODULES: List[str] = [
    "assembler",
    "asiic_holographic",
    "core",
    "multi_level",
    "quantum_holocron",
    "transpiler",
    "visualization",
]

__all__ = _SUBMODULES.copy()


def __getattr__(name: str):
    if name in _SUBMODULES:
        return import_module(f"{__name__}.{name}")
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


def __dir__():
    return sorted(set(globals().keys()) | set(_SUBMODULES))
