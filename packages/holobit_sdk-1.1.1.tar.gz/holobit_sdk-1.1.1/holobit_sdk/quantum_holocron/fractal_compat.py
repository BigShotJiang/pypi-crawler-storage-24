from __future__ import annotations

"""Capa de compatibilidad para el módulo ``fractal``.

Selecciona la variante compilada cuando está disponible y respeta la
configuración ``HOLOBIT_DISABLE_CYTHON`` para forzar el uso de la ruta en
Python puro.
"""

import importlib
import importlib.util
import os
from types import ModuleType
from typing import Tuple

_CYTHON_DISABLED = os.environ.get("HOLOBIT_DISABLE_CYTHON", "0") == "1"


def _load_backend(module_base: str) -> Tuple[ModuleType, bool]:
    """Devuelve el backend seleccionado y si es compilado."""

    compiled_name = f".{module_base}_c"
    if not _CYTHON_DISABLED:
        spec = importlib.util.find_spec(compiled_name, __package__)
        if spec is not None:
            module = importlib.import_module(compiled_name, __package__)
            return module, True

    module = importlib.import_module(f".{module_base}_py", __package__)
    return module, False


_impl, USING_COMPILED = _load_backend("fractal")

Fractal = _impl.Fractal
morphometric_field = _impl.morphometric_field

__all__ = ["Fractal", "morphometric_field", "USING_COMPILED"]
