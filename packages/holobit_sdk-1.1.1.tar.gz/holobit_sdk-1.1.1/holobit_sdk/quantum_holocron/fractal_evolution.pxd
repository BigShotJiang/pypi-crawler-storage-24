# cython: language_level=3
from libc.stddef cimport Py_ssize_t

cdef class GenomaFractal:
    cdef dict densidades
    cdef Py_ssize_t hierarquia_superior

    cpdef GenomaFractal clone(self)
    cpdef GenomaFractal crossover(self, GenomaFractal other, object rng)
    cpdef mutate(self, object rng, double rate_densidad=*, Py_ssize_t max_step_hierarquia=*)
