from typing import Any, Callable, Dict, List

cpdef List[str] evolve_group_ids(
    List[str] initial_ids,
    Dict[str, Any] holobits,
    Callable[[List[Any]], float] criteria_fn,
    int generations,
    int population_size,
)
