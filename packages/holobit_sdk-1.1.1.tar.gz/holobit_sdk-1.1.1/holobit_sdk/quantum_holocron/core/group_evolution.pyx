# cython: boundscheck=False, wraparound=False, nonecheck=False, language_level=3
"""Algoritmos evolutivos para grupos de Holobits (versión optimizada en Cython)."""

from __future__ import annotations

from typing import Any, Callable, Dict, List
import random

from cython cimport view
cimport cython


@cython.cfunc
@cython.inline
def _copy_candidate(Py_ssize_t[:] src, Py_ssize_t[:] dst, Py_ssize_t size) -> None:
    cdef Py_ssize_t i
    for i in range(size):
        dst[i] = src[i]


@cython.cfunc
@cython.inline
def _mutate(
    Py_ssize_t[:] parent,
    Py_ssize_t[:] child,
    Py_ssize_t group_size,
    Py_ssize_t available_count,
) -> None:
    """Copia ``parent`` en ``child`` y muta un índice."""

    cdef Py_ssize_t i
    for i in range(group_size):
        child[i] = parent[i]

    cdef Py_ssize_t pos = random.randrange(group_size)
    cdef Py_ssize_t current_value = child[pos]
    cdef Py_ssize_t candidate

    if available_count > 0:
        if group_size < available_count:
            while True:
                candidate = random.randrange(available_count)
                if candidate == current_value:
                    break

                for i in range(group_size):
                    if i != pos and child[i] == candidate:
                        break
                else:
                    break
        else:
            candidate = current_value

        child[pos] = candidate


@cython.cfunc
@cython.inline
def _fitness(
    Py_ssize_t[:] candidate,
    list available_ids,
    dict holobits,
    object criteria_fn,
    Py_ssize_t group_size,
    object holobits_get,
) -> double:
    cdef list selected = [None] * group_size
    cdef Py_ssize_t i

    for i in range(group_size):
        selected[i] = holobits_get(available_ids[candidate[i]])

    return float(criteria_fn(selected))


cpdef List[str] evolve_group_ids(
    List[str] initial_ids,
    Dict[str, Any] holobits,
    Callable[[List[Any]], float] criteria_fn,
    int generations,
    int population_size,
) -> List[str]:
    """Evoluciona un conjunto de identificadores de Holobits."""

    cdef list available_ids = list(holobits.keys())
    cdef Py_ssize_t group_size = len(initial_ids)
    cdef Py_ssize_t available_count = len(available_ids)

    if group_size == 0 or population_size <= 0:
        return initial_ids[:]

    cdef dict id_to_index = {hid: idx for idx, hid in enumerate(available_ids)}
    cdef Py_ssize_t p, idx

    cdef Py_ssize_t[:, :] population = view.array(
        shape=(population_size, group_size),
        itemsize=cython.sizeof(Py_ssize_t),
        format="n",
        mode="c",
    )
    cdef Py_ssize_t[:, :] next_population = view.array(
        shape=(population_size, group_size),
        itemsize=cython.sizeof(Py_ssize_t),
        format="n",
        mode="c",
    )

    # Población inicial
    for idx in range(group_size):
        population[0, idx] = id_to_index[initial_ids[idx]]

    for p in range(1, population_size):
        sampled = random.sample(available_ids, group_size)
        for idx in range(group_size):
            population[p, idx] = id_to_index[sampled[idx]]

    cdef double best_score = float("-inf")
    cdef double second_score = float("-inf")
    cdef double score
    cdef Py_ssize_t best_row = 0
    cdef Py_ssize_t second_row = -1
    cdef object holobits_get = holobits.__getitem__
    cdef Py_ssize_t gen

    for gen in range(generations):
        best_score = float("-inf")
        second_score = float("-inf")
        best_row = 0
        second_row = -1

        for p in range(population_size):
            score = _fitness(population[p], available_ids, holobits, criteria_fn, group_size, holobits_get)
            if score > best_score:
                second_score = best_score
                second_row = best_row
                best_score = score
                best_row = p
            elif score > second_score:
                second_score = score
                second_row = p

        _copy_candidate(population[best_row], next_population[0], group_size)
        idx = 1

        if second_row >= 0 and population_size > 1:
            _copy_candidate(population[second_row], next_population[1], group_size)
            idx = 2

        while idx < population_size:
            p = best_row if second_row < 0 or random.randint(0, 1) == 0 else second_row
            _mutate(population[p], next_population[idx], group_size, available_count)
            idx += 1

        population, next_population = next_population, population

    best_score = float("-inf")
    best_row = 0
    for p in range(population_size):
        score = _fitness(population[p], available_ids, holobits, criteria_fn, group_size, holobits_get)
        if score > best_score:
            best_score = score
            best_row = p

    return [available_ids[population[best_row, idx]] for idx in range(group_size)]
