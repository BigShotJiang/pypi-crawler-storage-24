# cython: language_level=3, boundscheck=False, wraparound=False, cdivision=True
"""Rutinas genéticas para ajustar parámetros de un fractal (versión Cython)."""

from __future__ import annotations

from libc.stddef cimport Py_ssize_t
cimport cython


cdef class GenomaFractal:
    """Representación genética de un fractal."""

    cdef dict densidades
    cdef Py_ssize_t hierarquia_superior

    def __init__(self, dict densidades, Py_ssize_t hierarquia_superior):
        self.densidades = densidades
        self.hierarquia_superior = hierarquia_superior

    cpdef GenomaFractal clone(self):
        """Devuelve una copia del genoma."""

        return GenomaFractal(self.densidades.copy(), self.hierarquia_superior)

    cpdef GenomaFractal crossover(self, GenomaFractal other, object rng):
        """Cruza dos genomas combinando densidades y jerarquías."""

        cdef dict densidades = {}
        cdef Py_ssize_t dim
        cdef double valor
        cdef double elegido
        cdef double umbral
        cdef double media
        cdef Py_ssize_t hierarquia

        for dim_obj, valor_obj in self.densidades.items():
            dim = <Py_ssize_t>dim_obj
            valor = <double>valor_obj
            umbral = <double>rng.random()
            if umbral < 0.5:
                elegido = valor
            else:
                elegido = <double>other.densidades.get(dim, valor)
            densidades[dim] = elegido

        media = (self.hierarquia_superior + other.hierarquia_superior) / 2.0
        hierarquia = <Py_ssize_t>cython.cast(int, round(media))
        if hierarquia < 1:
            hierarquia = 1

        return GenomaFractal(densidades, hierarquia)

    cpdef mutate(
        self,
        object rng,
        double rate_densidad=0.1,
        Py_ssize_t max_step_hierarquia=3,
    ):
        """Aplica mutaciones a densidades y jerarquía."""

        cdef Py_ssize_t dim
        cdef double valor
        cdef double prob

        for dim_obj, valor_obj in self.densidades.items():
            dim = <Py_ssize_t>dim_obj
            valor = <double>valor_obj
            prob = <double>rng.random()
            if prob < rate_densidad:
                self.densidades[dim] = valor + rng.gauss(0.0, abs(valor) * 0.1)

        prob = <double>rng.random()
        if prob < 0.5:
            self.hierarquia_superior += rng.randint(1, max_step_hierarquia)
