"""Compatibilidad de :mod:`fractal_evolution` delegada a ``_compat``.

También soporta ejecución directa asegurando el contexto de paquete.
"""

from __future__ import annotations

from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

from .fractal_evolution_compat import GenomaFractal, USING_COMPILED

__all__ = ["GenomaFractal", "USING_COMPILED"]
