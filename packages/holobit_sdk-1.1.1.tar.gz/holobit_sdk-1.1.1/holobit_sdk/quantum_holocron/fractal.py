"""Compatibilidad para ``fractal`` delegada a :mod:`fractal_compat`."""

from __future__ import annotations

from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

from .fractal_compat import Fractal, USING_COMPILED, morphometric_field

__all__ = ["Fractal", "morphometric_field", "USING_COMPILED"]
