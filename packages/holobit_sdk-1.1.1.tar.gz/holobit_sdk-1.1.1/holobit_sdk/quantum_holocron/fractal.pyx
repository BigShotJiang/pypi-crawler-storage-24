# cython: language_level=3, boundscheck=False, cdivision=True, wraparound=False
"""Implementación acelerada de fractales del Holocron."""

from __future__ import annotations

from libc.math cimport cos, pow, sin, sqrt
import numpy as np
cimport numpy as cnp

from holobit_sdk.core.quark import Quark
from holobit_sdk.quantum_holocron.core.holocron import Holocron
from holobit_sdk.quantum_holocron.fractal_evolution cimport GenomaFractal

cdef double phi = (1.0 + sqrt(5.0)) / 2.0


cpdef double morphometric_field(
    Py_ssize_t level,
    Py_ssize_t coord,
    Py_ssize_t dimension,
    object density_fn=None,
):
    """Evalúa un campo morfométrico configurable."""

    if density_fn is None:
        return sin(<double>level) * cos(<double>coord)
    return <double>density_fn(level, coord, dimension)


cdef class Fractal:
    cdef object holocron
    cdef object density_fn
    cdef Py_ssize_t dimension
    cdef Py_ssize_t hierarquia_superior
    cdef dict densidades
    cdef dict subniveles
    cdef list spins

    def __init__(
        self,
        Holocron holocron,
        Py_ssize_t dimension=3,
        object density_fn=None,
        dict densidades=None,
        Py_ssize_t hierarquia_superior=36,
    ):
        if not isinstance(holocron, Holocron):
            raise TypeError("Se requiere una instancia válida de Holocron.")

        if len(holocron.holobits) != 10:
            raise ValueError("El Holocron debe contener exactamente 10 holobits.")

        for holobit in holocron.holobits.values():
            if len(getattr(holobit, "quarks", [])) != 6 or len(getattr(holobit, "antiquarks", [])) != 6:
                raise ValueError("Cada Holobit debe poseer 6 quarks y 6 antiquarks.")

        self.holocron = holocron
        self.dimension = dimension
        self.density_fn = density_fn
        self.densidades = densidades if densidades is not None else {i: 0 for i in range(1, 37)}
        self.hierarquia_superior = hierarquia_superior

        self.spins = [getattr(hb, "spin", None) for hb in holocron.holobits.values()]
        if len(self.spins) != 10:
            raise ValueError("Se requieren 10 valores de spin.")

        self.subniveles = {}

    cpdef generar(self):
        """Genera las densidades y posiciones fractales."""

        cdef Py_ssize_t dimension_idx, nivel, coord
        cdef double total_quarks = 0.0
        cdef double norma
        cdef double potencia_phi
        cdef double[:] vector
        cdef double[:] direccion
        cdef cnp.ndarray vector_arr
        cdef cnp.ndarray direccion_arr
        cdef cnp.ndarray posicion_arr

        total_quarks = sum(
            len(hb.quarks) + len(hb.antiquarks) for hb in self.holocron.holobits.values()
        )
        for dimension_idx in self.densidades:
            self.densidades[dimension_idx] = total_quarks * dimension_idx

        self.subniveles = {}
        for nivel in range(1, self.hierarquia_superior + 1):
            vector_arr = np.empty(self.dimension, dtype=np.float64)
            vector = vector_arr
            for coord in range(self.dimension):
                vector[coord] = morphometric_field(nivel, coord, self.dimension, self.density_fn)

            norma = 0.0
            for coord in range(self.dimension):
                norma += vector[coord] * vector[coord]
            norma = sqrt(norma) if norma != 0.0 else 1.0

            direccion_arr = np.empty(self.dimension, dtype=np.float64)
            direccion = direccion_arr
            for coord in range(self.dimension):
                direccion[coord] = vector[coord] / norma

            posicion_arr = np.empty(self.dimension, dtype=np.float64)
            potencia_phi = pow(phi, <double>nivel)
            for coord in range(self.dimension):
                posicion_arr[coord] = direccion[coord] * potencia_phi

            self.subniveles[nivel] = Quark(*np.asarray(posicion_arr, dtype=float))

    cpdef simular_dinamica(self, Py_ssize_t pasos, double dt):
        """Simula la evolución dinámica del fractal."""

        cdef Py_ssize_t _
        cdef Py_ssize_t nivel, coord
        cdef double norma
        cdef double[:] vector
        cdef double[:] direccion
        cdef cnp.ndarray vector_arr
        cdef cnp.ndarray direccion_arr

        for _ in range(pasos):
            for nivel, quark in self.subniveles.items():
                vector_arr = np.empty(self.dimension, dtype=np.float64)
                vector = vector_arr
                for coord in range(self.dimension):
                    vector[coord] = morphometric_field(
                        nivel, coord, self.dimension, self.density_fn
                    )

                norma = 0.0
                for coord in range(self.dimension):
                    norma += vector[coord] * vector[coord]
                norma = sqrt(norma) if norma != 0.0 else 1.0

                direccion_arr = np.empty(self.dimension, dtype=np.float64)
                direccion = direccion_arr
                for coord in range(self.dimension):
                    direccion[coord] = vector[coord] / norma

                quark.posicion = quark.posicion + np.asarray(direccion_arr, dtype=float) * dt

            for dimension_idx in self.densidades:
                self.densidades[dimension_idx] += dimension_idx * dt

    cpdef double densidad(self, Py_ssize_t dimension):
        """Devuelve la densidad registrada para la dimensión solicitada."""

        if dimension not in self.densidades:
            raise ValueError("Dimensión fuera de rango (1-36).")
        return <double>self.densidades[dimension]

    cpdef optimizar_geneticamente(
        self,
        object fitness_fn,
        Py_ssize_t generations=10,
        Py_ssize_t poblacion=4,
    ):
        """Optimiza densidades y jerarquía mediante un algoritmo genético simple."""

        cdef Py_ssize_t _
        cdef object rng = __import__("random").Random(0)

        cdef GenomaFractal base = GenomaFractal(
            self.densidades.copy(), self.hierarquia_superior
        )
        poblacion_genomas = [base.clone()]
        for _ in range(poblacion - 1):
            cdef GenomaFractal g = base.clone()
            g.mutate(rng)
            poblacion_genomas.append(g)

        for _ in range(generations):
            evaluados = []
            for gen in poblacion_genomas:
                fr = Fractal(
                    self.holocron,
                    self.dimension,
                    self.density_fn,
                    densidades=gen.densidades.copy(),
                    hierarquia_superior=gen.hierarquia_superior,
                )
                fr.generar()
                fr.densidades.update(gen.densidades)
                evaluados.append((fitness_fn(fr), gen))

            evaluados.sort(key=lambda x: x[0], reverse=True)
            poblacion_genomas = [evaluados[0][1], evaluados[1][1]]

            while len(poblacion_genomas) < poblacion:
                padre1, padre2 = rng.sample(poblacion_genomas[:2], 2)
                hijo = padre1.crossover(padre2, rng)
                hijo.mutate(rng)
                poblacion_genomas.append(hijo)

        mejor_fractal = None
        mejor_score = None
        mejor_genoma = None
        for gen in poblacion_genomas:
            fr = Fractal(
                self.holocron,
                self.dimension,
                self.density_fn,
                densidades=gen.densidades.copy(),
                hierarquia_superior=gen.hierarquia_superior,
            )
            fr.generar()
            fr.densidades.update(gen.densidades)
            score = fitness_fn(fr)
            if mejor_fractal is None or score > mejor_score:
                mejor_fractal, mejor_score, mejor_genoma = fr, score, gen

        if mejor_genoma is None or mejor_fractal is None:
            return

        self.hierarquia_superior = mejor_genoma.hierarquia_superior
        self.generar()
        self.densidades.update(mejor_genoma.densidades)
