# cython: language_level=3, boundscheck=False, wraparound=False, cdivision=True
"""Implementación acelerada de la simulación de colisiones entre Holobits."""

from libc.math cimport sqrt
import numpy as np
cimport numpy as cnp

__all__ = ["calculate_trajectory", "detect_collision", "simulate_collision", "center_of_mass"]


def center_of_mass(holobit):
    """Calcula el centro de masa de un Holobit."""

    posiciones = np.array([q.posicion for q in holobit.quarks + holobit.antiquarks], dtype=np.float64)
    return posiciones.mean(axis=0)


cdef inline double _norm_sq(double[:] vector):
    cdef Py_ssize_t i, n = vector.shape[0]
    cdef double total = 0.0
    for i in range(n):
        total += vector[i] * vector[i]
    return total


cpdef cnp.ndarray calculate_trajectory(object holobit, object velocidad, Py_ssize_t pasos=10, double dt=1.0):
    """Genera la trayectoria del centro de masa usando vistas de memoria."""

    cdef cnp.ndarray vel_arr = np.asarray(velocidad, dtype=np.float64)
    cdef double[:] velocidad_view = vel_arr
    cdef cnp.ndarray inicio_arr = np.asarray(center_of_mass(holobit), dtype=np.float64)
    cdef double[:] inicio_view = inicio_arr

    cdef Py_ssize_t dims = inicio_view.shape[0]
    cdef cnp.ndarray trayectorias = np.empty((pasos, dims), dtype=np.float64)
    cdef double[:, :] tray_view = trayectorias
    cdef Py_ssize_t i, d

    for i in range(pasos):
        for d in range(dims):
            tray_view[i, d] = inicio_view[d] + velocidad_view[d] * i * dt

    return trayectorias


cpdef object detect_collision(object trayectoria1, object trayectoria2, double umbral=0.1):
    """Detecta el primer impacto entre dos trayectorias de forma eficiente."""

    cdef cnp.ndarray tray1_arr = np.asarray(trayectoria1, dtype=np.float64)
    cdef cnp.ndarray tray2_arr = np.asarray(trayectoria2, dtype=np.float64)
    cdef double[:, :] tray1 = tray1_arr
    cdef double[:, :] tray2 = tray2_arr

    cdef Py_ssize_t pasos = tray1.shape[0]
    cdef Py_ssize_t dims = tray1.shape[1]
    cdef double umbral_sq = umbral * umbral
    cdef double delta, dist_sq
    cdef Py_ssize_t i, d

    for i in range(pasos):
        dist_sq = 0.0
        for d in range(dims):
            delta = tray1[i, d] - tray2[i, d]
            dist_sq += delta * delta
        if dist_sq < umbral_sq:
            return i
    return None


def simulate_collision(h1, h2, parametros):
    """Simula la colisión entre dos Holobits y calcula magnitudes básicas."""

    v1 = np.asarray(parametros.get("v1", [0, 0, 0]), dtype=np.float64)
    v2 = np.asarray(parametros.get("v2", [0, 0, 0]), dtype=np.float64)
    pasos = int(parametros.get("pasos", 10))
    dt = float(parametros.get("dt", 1.0))
    umbral = float(parametros.get("umbral", 0.1))

    tray1 = calculate_trajectory(h1, v1, pasos, dt)
    tray2 = calculate_trajectory(h2, v2, pasos, dt)
    paso_col = detect_collision(tray1, tray2, umbral)

    resultado = {"trayectoria1": tray1, "trayectoria2": tray2, "paso_colision": paso_col}
    if paso_col is not None:
        cdef double[:] delta_v = np.asarray(v1 - v2, dtype=np.float64)
        energia = 0.5 * _norm_sq(delta_v)
        cdef double[:] delta_pos = np.asarray(tray1[paso_col] - tray2[paso_col], dtype=np.float64)
        dispersion = sqrt(_norm_sq(delta_pos))
        resultado.update({"energia": energia, "dispersion": dispersion})
    return resultado
