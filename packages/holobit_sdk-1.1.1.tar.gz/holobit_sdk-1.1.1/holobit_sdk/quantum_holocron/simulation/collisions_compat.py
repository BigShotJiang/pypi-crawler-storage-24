from __future__ import annotations

"""Shim de compatibilidad para ``collisions``.

Intenta usar la extensión compilada cuando está disponible y permite forzar el
uso de la versión en Python puro mediante ``HOLOBIT_DISABLE_CYTHON``.
"""

import importlib
import importlib.util
import os
from types import ModuleType
from typing import Callable, Tuple

_CYTHON_DISABLED = os.environ.get("HOLOBIT_DISABLE_CYTHON", "0") == "1"


def _load_backend(module_base: str) -> Tuple[ModuleType, bool]:
    compiled_name = f".{module_base}_c"
    if not _CYTHON_DISABLED:
        spec = importlib.util.find_spec(compiled_name, __package__)
        if spec is not None:
            module = importlib.import_module(compiled_name, __package__)
            return module, True

    module = importlib.import_module(f".{module_base}_py", __package__)
    return module, False


_backend, USING_COMPILED = _load_backend("collisions")
center_of_mass: Callable = getattr(_backend, "center_of_mass")
calculate_trajectory: Callable = getattr(_backend, "calculate_trajectory")
detect_collision: Callable = getattr(_backend, "detect_collision")
simulate_collision: Callable = getattr(_backend, "simulate_collision")

__all__ = [
    "calculate_trajectory",
    "detect_collision",
    "simulate_collision",
    "center_of_mass",
    "USING_COMPILED",
]
