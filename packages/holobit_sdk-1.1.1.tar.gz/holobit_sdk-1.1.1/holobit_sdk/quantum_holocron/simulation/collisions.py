"""Compatibilidad de colisiones delegada a :mod:`collisions_compat`.

También soporta ejecución directa asegurando el contexto de paquete.
"""

from __future__ import annotations

from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

from .collisions_compat import (
    USING_COMPILED,
    calculate_trajectory,
    center_of_mass,
    detect_collision,
    simulate_collision,
)

__all__ = [
    "calculate_trajectory",
    "detect_collision",
    "simulate_collision",
    "center_of_mass",
    "USING_COMPILED",
]
