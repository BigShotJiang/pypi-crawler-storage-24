# cython: language_level=3
cimport numpy as cnp

cpdef cnp.ndarray calculate_trajectory(object holobit, object velocidad, Py_ssize_t pasos=*, double dt=*)
cpdef object detect_collision(object trayectoria1, object trayectoria2, double umbral=*)
