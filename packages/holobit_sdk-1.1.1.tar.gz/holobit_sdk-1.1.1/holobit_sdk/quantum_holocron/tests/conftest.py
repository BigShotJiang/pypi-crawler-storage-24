from __future__ import annotations

"""Fixtures y utilidades comunes para la batería de pruebas de Holocron."""

from pathlib import Path
import sys

for ancestor in Path(__file__).resolve().parents:
    if (ancestor / "holobit_sdk").exists():
        sys.path.insert(0, str(ancestor))
        break

from holobit_sdk.utils.bootstrap import ensure_package_context
ensure_package_context(globals())

import importlib
import os
from collections.abc import Callable, Iterator

import pytest

from holobit_sdk.core.holobit import Holobit
from holobit_sdk.core.quark import Quark


def _purge_module(module_name: str) -> None:
    """Elimina un módulo y submódulos relacionados del *cache* de importación."""

    compat_variant = f"{module_name}_compat"
    variants = {module_name, compat_variant, f"{module_name}_c", f"{module_name}_py"}

    for key in list(sys.modules):
        if key in variants or any(key.startswith(f"{variant}.") for variant in variants):
            sys.modules.pop(key, None)


def _reload_with_env(module_name: str, env_value: str):
    """Recarga un módulo tras fijar ``HOLOBIT_DISABLE_CYTHON``."""

    os.environ["HOLOBIT_DISABLE_CYTHON"] = env_value
    _purge_module(module_name)
    return importlib.import_module(module_name)


@pytest.fixture
def holobit_pair() -> tuple[Holobit, Holobit]:
    """Crea dos Holobits sencillos con quarks posicionados en una rejilla."""

    def _make_holobit(offset: float) -> Holobit:
        quarks = [Quark(offset, offset + i, offset - i) for i in range(6)]
        antiquarks = [Quark(offset + 0.5, offset + i + 0.5, offset - i - 0.5) for i in range(6)]
        return Holobit(quarks, antiquarks, spin=int(offset))

    return _make_holobit(0.0), _make_holobit(1.0)


@pytest.fixture
def module_variants() -> Iterator[Callable[[str], tuple[object, object, bool]]]:
    """Proporciona una función que devuelve las rutas compilada y pura de un módulo."""

    original_env = os.environ.get("HOLOBIT_DISABLE_CYTHON")
    loaded_modules: list[str] = []

    def _loader(module_name: str) -> tuple[object, object, bool]:
        compiled = _reload_with_env(module_name, "0")
        compiled_available = bool(getattr(compiled, "USING_COMPILED", False))
        python = _reload_with_env(module_name, "1")
        loaded_modules.extend([module_name])
        return compiled, python, compiled_available

    yield _loader

    if original_env is None:
        os.environ.pop("HOLOBIT_DISABLE_CYTHON", None)
    else:
        os.environ["HOLOBIT_DISABLE_CYTHON"] = original_env

    for module_name in loaded_modules:
        _purge_module(module_name)


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:  # pragma: no cover - comportamiento de Pytest
    """Omite benchmarks si Cython está deshabilitado explícitamente."""

    if os.environ.get("HOLOBIT_DISABLE_CYTHON", "0") != "1":
        return

    skip_marker = pytest.mark.skip(reason="Benchmarks deshabilitados cuando HOLOBIT_DISABLE_CYTHON=1")
    for item in items:
        if item.get_closest_marker("benchmark") or item.get_closest_marker("performance"):
            item.add_marker(skip_marker)
