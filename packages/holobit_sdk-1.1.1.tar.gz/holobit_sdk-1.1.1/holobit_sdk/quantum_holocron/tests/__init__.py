from pathlib import Path
import sys

for ancestor in Path(__file__).resolve().parents:
    if (ancestor / "holobit_sdk").exists():
        sys.path.insert(0, str(ancestor))
        break

from holobit_sdk.utils.bootstrap import ensure_package_context
ensure_package_context(globals())

"""Pruebas para el módulo ``quantum_holocron``."""

