from __future__ import annotations

"""Pruebas de equivalencia entre implementaciones Python y Cython."""

from pathlib import Path
import sys

for ancestor in Path(__file__).resolve().parents:
    if (ancestor / "holobit_sdk").exists():
        sys.path.insert(0, str(ancestor))
        break

from holobit_sdk.utils.bootstrap import ensure_package_context
ensure_package_context(globals())

import random
import time

import numpy as np
import pytest

from holobit_sdk.core.holobit import Holobit
from holobit_sdk.core.quark import Quark
from holobit_sdk.quantum_holocron.core.holocron import Holocron


def _holocron_base() -> Holocron:
    holocron = Holocron()
    for idx in range(10):
        quarks = [Quark(idx * 0.01, i * 0.1, -i * 0.1) for i in range(6)]
        antiquarks = [Quark(idx * 0.01, -i * 0.2, i * 0.05) for i in range(6)]
        holocron.add_holobit(f"hb{idx}", Holobit(quarks, antiquarks, spin=idx))
    return holocron


def test_fractal_compiled_matches_python(module_variants):
    compiled, python, has_compiled = module_variants("holobit_sdk.quantum_holocron.fractal")
    if not has_compiled:
        pytest.skip("fractal compilado no disponible")

    holocron = _holocron_base()
    fractal_compiled = compiled.Fractal(holocron)
    fractal_python = python.Fractal(holocron)

    fractal_compiled.generar()
    fractal_python.generar()

    assert fractal_compiled.densidades == fractal_python.densidades
    assert np.allclose(
        fractal_compiled.subniveles[1].posicion, fractal_python.subniveles[1].posicion
    )


def test_genoma_fractal_operations_equivalence(module_variants):
    compiled, python, has_compiled = module_variants("holobit_sdk.quantum_holocron.fractal_evolution")
    if not has_compiled:
        pytest.skip("fractal_evolution compilado no disponible")

    rng_cross_comp = random.Random(123)
    rng_cross_py = random.Random(123)
    rng_mut_comp = random.Random(456)
    rng_mut_py = random.Random(456)

    g1_comp = compiled.GenomaFractal({1: 1.0, 2: 2.0}, 5)
    g2_comp = compiled.GenomaFractal({1: 3.0, 2: 4.0}, 7)
    g1_py = python.GenomaFractal({1: 1.0, 2: 2.0}, 5)
    g2_py = python.GenomaFractal({1: 3.0, 2: 4.0}, 7)

    hijo_comp = g1_comp.crossover(g2_comp, rng_cross_comp)
    hijo_py = g1_py.crossover(g2_py, rng_cross_py)

    hijo_comp.mutate(rng_mut_comp, rate_densidad=1.0, max_step_hierarquia=2)
    hijo_py.mutate(rng_mut_py, rate_densidad=1.0, max_step_hierarquia=2)

    assert hijo_comp.densidades == hijo_py.densidades
    assert hijo_comp.hierarquia_superior == hijo_py.hierarquia_superior


def test_collisions_consistency(module_variants, holobit_pair):
    compiled, python, has_compiled = module_variants("holobit_sdk.quantum_holocron.simulation.collisions")
    if not has_compiled:
        pytest.skip("collisions compilado no disponible")

    h1, h2 = holobit_pair
    params = {"v1": [0.1, 0.1, 0.0], "v2": [-0.1, -0.05, 0.0], "pasos": 5, "dt": 0.5, "umbral": 0.2}

    compiled_result = compiled.simulate_collision(h1, h2, params)
    python_result = python.simulate_collision(h1, h2, params)

    assert compiled_result["paso_colision"] == python_result["paso_colision"]
    assert np.allclose(compiled_result["trayectoria1"], python_result["trayectoria1"])
    assert np.allclose(compiled_result["trayectoria2"], python_result["trayectoria2"])


@pytest.mark.benchmark
@pytest.mark.performance
def test_fractal_generation_benchmark(module_variants):
    compiled, python, has_compiled = module_variants("holobit_sdk.quantum_holocron.fractal")
    if not has_compiled:
        pytest.skip("fractal compilado no disponible")

    holocron = _holocron_base()
    fractal_compiled = compiled.Fractal(holocron)
    fractal_python = python.Fractal(holocron)

    start = time.perf_counter()
    fractal_compiled.generar()
    compiled_time = time.perf_counter() - start

    start = time.perf_counter()
    fractal_python.generar()
    python_time = time.perf_counter() - start

    assert compiled_time <= python_time * 1.5


@pytest.mark.benchmark
@pytest.mark.performance
def test_collision_benchmark(module_variants, holobit_pair):
    compiled, python, has_compiled = module_variants("holobit_sdk.quantum_holocron.simulation.collisions")
    if not has_compiled:
        pytest.skip("collisions compilado no disponible")

    params = {"v1": [0.2, 0.0, 0.0], "v2": [-0.1, 0.0, 0.0], "pasos": 50, "dt": 0.1, "umbral": 0.1}

    start = time.perf_counter()
    compiled.simulate_collision(*holobit_pair, params)
    compiled_time = time.perf_counter() - start

    start = time.perf_counter()
    python.simulate_collision(*holobit_pair, params)
    python_time = time.perf_counter() - start

    assert compiled_time <= python_time * 1.5
