# cython: language_level=3
from libc.stddef cimport Py_ssize_t

cdef double morphometric_field(Py_ssize_t level, Py_ssize_t coord, Py_ssize_t dimension, object density_fn=*)

cdef class Fractal:
    cdef object holocron
    cdef object density_fn
    cdef Py_ssize_t dimension
    cdef Py_ssize_t hierarquia_superior
    cdef dict densidades
    cdef dict subniveles
    cdef list spins

    cpdef generar(self)
    cpdef simular_dinamica(self, Py_ssize_t pasos, double dt)
    cpdef double densidad(self, Py_ssize_t dimension)
    cpdef optimizar_geneticamente(self, object fitness_fn, Py_ssize_t generations=*, Py_ssize_t poblacion=*)
