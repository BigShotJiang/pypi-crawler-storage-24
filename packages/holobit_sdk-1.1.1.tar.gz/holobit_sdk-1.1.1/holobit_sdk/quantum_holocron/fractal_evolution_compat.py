from __future__ import annotations

"""Capa de compatibilidad para ``fractal_evolution``.

Permite seleccionar dinámicamente entre la extensión compilada y la versión en
Python puro respetando la variable ``HOLOBIT_DISABLE_CYTHON``.
"""

import importlib
import importlib.util
import os
from types import ModuleType
from typing import Tuple

_CYTHON_DISABLED = os.environ.get("HOLOBIT_DISABLE_CYTHON", "0") == "1"


def _load_backend(module_base: str) -> Tuple[ModuleType, bool]:
    compiled_name = f".{module_base}_c"
    if not _CYTHON_DISABLED:
        spec = importlib.util.find_spec(compiled_name, __package__)
        if spec is not None:
            module = importlib.import_module(compiled_name, __package__)
            return module, True

    module = importlib.import_module(f".{module_base}_py", __package__)
    return module, False


_impl, USING_COMPILED = _load_backend("fractal_evolution")
GenomaFractal = _impl.GenomaFractal

__all__ = ["GenomaFractal", "USING_COMPILED"]
