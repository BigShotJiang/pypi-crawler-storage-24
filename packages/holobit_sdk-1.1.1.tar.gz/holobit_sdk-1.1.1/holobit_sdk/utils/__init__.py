from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

from holobit_sdk.utils.safe_eval import safe_eval

__all__ = ["ensure_package_context", "safe_eval"]
