"""Utilidades de arranque para ejecución de módulos como scripts."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import MutableMapping


def ensure_package_context(globals_dict: MutableMapping[str, object]) -> None:
    """Carga ``fix_relative_imports`` incluso al ejecutar el módulo como script.

    La función intenta importar ``holobit_sdk._bootstrap`` de manera normal y,
    si no está disponible (por ejemplo, al ejecutar un archivo directamente),
    localiza el paquete raíz a partir de ``__file__``, añade su carpeta padre a
    ``sys.path`` y carga el módulo ``_bootstrap`` desde el disco. Finalmente,
    delega en ``fix_relative_imports`` para ajustar ``__package__`` y ``__spec__``.
    """

    try:
        from holobit_sdk._bootstrap import fix_relative_imports
    except ModuleNotFoundError:  # pragma: no cover - ejecución como script
        file_value = globals_dict.get("__file__")
        if not file_value:
            raise

        file_path = Path(file_value).resolve()
        top_level = None
        current = file_path.parent

        while (current / "__init__.py").is_file():
            top_level = current
            current = current.parent

        if top_level is None:  # pragma: no cover - no debería ocurrir en el paquete
            raise

        parent_dir = str(top_level.parent)
        if parent_dir not in sys.path:
            sys.path.insert(0, parent_dir)

        helper_path = top_level / "_bootstrap.py"
        spec = importlib.util.spec_from_file_location("holobit_sdk._bootstrap", helper_path)
        module = sys.modules.get("holobit_sdk._bootstrap")
        if module is None:
            if spec is None or spec.loader is None:  # pragma: no cover - errores de carga
                raise
            module = importlib.util.module_from_spec(spec)
            sys.modules["holobit_sdk._bootstrap"] = module
            spec.loader.exec_module(module)  # type: ignore[arg-type]
        fix_relative_imports = module.fix_relative_imports  # type: ignore[attr-defined]

    fix_relative_imports(globals_dict)


__all__ = ["ensure_package_context"]
