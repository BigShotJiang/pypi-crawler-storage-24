"""Servicio FastAPI para compilar y ejecutar Holobits.

La configuración se realiza mediante variables de entorno:

* ``HOLOBIT_PORT``: puerto del servidor (por defecto 8000).
* ``HOLOBIT_BACKEND``: backend de cloud a utilizar (``aws``, ``azure``, ``gcp`` o ``universal``).
* ``HOLOBIT_USER`` y ``HOLOBIT_PASSWORD_HASH``: usuario y hash ``bcrypt`` de la contraseña.
* ``HOLOBIT_MAX_AUTH_ATTEMPTS``: número de intentos fallidos permitidos antes de bloquear.
* ``HOLOBIT_LOCK_SECONDS``: tiempo de bloqueo tras exceder los intentos.

El módulo se puede importar aunque falten ``HOLOBIT_USER`` o
``HOLOBIT_PASSWORD_HASH``. En ese caso, los endpoints protegidos responderán
con un error de autenticación hasta que se configuren correctamente las
credenciales.
"""

from __future__ import annotations

from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

import logging
import os
import re
import secrets
import time
from typing import Any, Dict, Tuple

import bcrypt

from fastapi import Depends, FastAPI, HTTPException, Request
from starlette.middleware.httpsredirect import HTTPSRedirectMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware
from contextlib import asynccontextmanager
from fastapi.security import HTTPBasic, HTTPBasicCredentials

from holobit_sdk.cloud import (
    AWSBackend,
    AzureBackend,
    GCPBackend,
    UniversalBackend,
)

@asynccontextmanager
async def _lifespan(_app: FastAPI):
    _load_credentials()
    try:
        _get_backend()
    except RuntimeError:
        logging.error("No se pudo inicializar el backend configurado durante el arranque")
    yield


app = FastAPI(title="Holobit SDK API", lifespan=_lifespan)

security = HTTPBasic()


# Intentos fallidos de autenticación por IP/usuario
_FAILED_ATTEMPTS: Dict[str, Tuple[int, float]] = {}
_MAX_ATTEMPTS = int(os.getenv("HOLOBIT_MAX_AUTH_ATTEMPTS", "3"))
_LOCK_SECONDS = int(os.getenv("HOLOBIT_LOCK_SECONDS", "60"))

# Configuración opcional de TLS
_TLS_CERT = os.getenv("HOLOBIT_TLS_CERT")
_TLS_KEY = os.getenv("HOLOBIT_TLS_KEY")
if _TLS_CERT and _TLS_KEY:
    if not (os.path.isfile(_TLS_CERT) and os.path.isfile(_TLS_KEY)):
        logging.warning(
            "Los archivos TLS especificados no existen; la API debe desplegarse detrás de un proxy HTTPS"
        )
        _TLS_CERT = _TLS_KEY = None
else:
    logging.warning(
        "No se configuraron HOLOBIT_TLS_CERT y HOLOBIT_TLS_KEY; la API debe desplegarse detrás de un proxy HTTPS"
    )

_ENFORCE_HTTPS = os.getenv("HOLOBIT_ENFORCE_HTTPS", "0") == "1"
_TRUSTED_HOSTS = [h.strip() for h in os.getenv("HOLOBIT_TRUSTED_HOSTS", "").split(",") if h.strip()]

# Middlewares de seguridad opcionales
if _ENFORCE_HTTPS:
    app.add_middleware(HTTPSRedirectMiddleware)
if _TRUSTED_HOSTS:
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=_TRUSTED_HOSTS)

def _add_security_headers(headers: Dict[str, str]) -> Dict[str, str]:
    base = {
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "no-referrer",
        "Permissions-Policy": "geolocation=(), microphone=(), camera=()",
    }
    # Solo HSTS si hay TLS directo configurado
    if _TLS_CERT and _TLS_KEY:
        base["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains; preload"
    base.update(headers)
    return base


def _select_backend() -> Any:
    """Selecciona e instancia el backend de cloud configurado."""

    backend = os.getenv("HOLOBIT_BACKEND", "aws").lower()
    if backend == "aws":
        return AWSBackend()
    if backend == "azure":
        return AzureBackend()
    if backend == "gcp":
        return GCPBackend()
    if backend == "universal":
        provider = os.getenv("HOLOBIT_PROVIDER")
        return UniversalBackend(provider)
    raise ValueError(f"Backend desconocido: {backend}")


_USER = None
_PASS_HASH_BYTES = None


def _load_credentials() -> None:
    """Carga las credenciales desde el entorno sin fallar en la importación."""

    global _USER, _PASS_HASH_BYTES

    user = os.getenv("HOLOBIT_USER")
    password_hash = os.getenv("HOLOBIT_PASSWORD_HASH")

    if not (user and password_hash):
        _USER = None
        _PASS_HASH_BYTES = None
        return

    _USER = user
    _PASS_HASH_BYTES = password_hash.encode()


_load_credentials()


backend: Any | None = None  # Permite inyectar un backend de pruebas sin instanciar dependencias
_backend_instance: Any | None = None


def _get_backend() -> Any:
    """Obtiene una instancia de backend evitando fallos de importación tempranos."""

    global _backend_instance
    if backend is not None:
        return backend

    if _backend_instance is None:
        try:
            _backend_instance = _select_backend()
        except ModuleNotFoundError as exc:  # pragma: no cover - dependencias opcionales
            logging.error("Backend no disponible por dependencia faltante: %s", exc)
            raise RuntimeError("El backend configurado requiere dependencias opcionales") from exc
    return _backend_instance


_VALID_TEXT = re.compile(r"^[\x20-\x7E\r\n\t]*$")


def _validate_ascii(value: str, field: str) -> None:
    if not _VALID_TEXT.fullmatch(value):
        raise HTTPException(
            status_code=400,
            detail=f"El campo '{field}' contiene caracteres inválidos",
        )


def _authenticate(
    credentials: HTTPBasicCredentials = Depends(security),
    request: Request = None,
) -> str:
    """Valida credenciales básicas usando hash ``bcrypt``.

    Implementa un contador de intentos fallidos por IP o usuario que bloquea
    temporalmente el acceso tras varios errores consecutivos.
    """
    if _USER is None or _PASS_HASH_BYTES is None:
        _load_credentials()
    if _USER is None or _PASS_HASH_BYTES is None:
        raise HTTPException(
            status_code=401,
            detail="HOLOBIT_USER y HOLOBIT_PASSWORD_HASH no están configuradas",
        )

    key = (
        request.client.host if request and request.client else credentials.username
    )
    now = time.time()
    count, lock_until = _FAILED_ATTEMPTS.get(key, (0, 0.0))
    if lock_until and now < lock_until:
        raise HTTPException(
            status_code=429,
            detail="Demasiados intentos, inténtelo más tarde",
        )
    if lock_until and now >= lock_until:
        count = 0
        lock_until = 0.0

    correct_user = secrets.compare_digest(credentials.username, _USER)
    try:
        correct_pass = bcrypt.checkpw(
            credentials.password.encode(), _PASS_HASH_BYTES
        )
    except ValueError:
        correct_pass = False

    if not (correct_user and correct_pass):
        count += 1
        if count >= _MAX_ATTEMPTS:
            lock_until = now + _LOCK_SECONDS
            _FAILED_ATTEMPTS[key] = (count, lock_until)
            raise HTTPException(
                status_code=429,
                detail="Demasiados intentos, inténtelo más tarde",
            )
        _FAILED_ATTEMPTS[key] = (count, lock_until)
        raise HTTPException(status_code=401, detail="Credenciales inválidas")

    if key in _FAILED_ATTEMPTS:
        del _FAILED_ATTEMPTS[key]
    return credentials.username


@app.post("/compile")
async def compile_holobit(data: Dict[str, Any], _: str = Depends(_authenticate)) -> Dict[str, Any]:
    """Envía código Holobit al backend para su compilación."""
    code = data.get("code")
    if code is None:
        raise HTTPException(status_code=400, detail="Falta el campo 'code'")
    if not isinstance(code, str):
        raise HTTPException(
            status_code=400, detail="El campo 'code' debe ser una cadena"
        )
    if len(code) > 10_000:
        raise HTTPException(
            status_code=413, detail="El campo 'code' excede el tamaño máximo"
        )
    if not code:
        raise HTTPException(status_code=400, detail="Falta el campo 'code'")
    _validate_ascii(code, "code")
    try:
        job_id = _get_backend().submit_job({"code": code})
    except Exception as exc:  # pragma: no cover - defensive
        raise HTTPException(status_code=502, detail="Error en el backend") from exc
    return {"job_id": job_id}


@app.post("/execute")
async def execute_holobit(data: Dict[str, Any], _: str = Depends(_authenticate)) -> Dict[str, Any]:
    """Ejecuta un trabajo previamente compilado.

    El ``job_id`` debe ser una cadena ASCII de hasta 256 caracteres.
    """
    job_id = data.get("job_id")
    if not job_id:
        raise HTTPException(status_code=400, detail="Falta el campo 'job_id'")
    if not isinstance(job_id, str):
        raise HTTPException(
            status_code=400, detail="El campo 'job_id' debe ser una cadena"
        )
    if len(job_id) > 256:
        raise HTTPException(
            status_code=413, detail="El campo 'job_id' excede el tamaño máximo"
        )
    _validate_ascii(job_id, "job_id")
    try:
        result = _get_backend().execute_job(job_id)
    except Exception as exc:  # pragma: no cover - defensive
        raise HTTPException(status_code=502, detail="Error en el backend") from exc
    return {"result": result}


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("HOLOBIT_PORT", "8000"))
    uvicorn.run(
        "holobit_sdk.api.service:app",
        host="0.0.0.0",
        port=port,
        ssl_certfile=_TLS_CERT,
        ssl_keyfile=_TLS_KEY,
    )
