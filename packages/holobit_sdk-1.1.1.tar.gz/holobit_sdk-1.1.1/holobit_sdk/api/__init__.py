"""Servicios API para el Holobit SDK."""

from importlib import import_module
from typing import Any, List


_PYTHON_BRIDGE_ATTRS: List[str] = [
    "HolobitDataset",
    "HolobitTransformer",
    "holobit_dataloader",
    "holobits_from_dataframe",
    "holobits_from_ndarray",
    "holocron_from_dataframe",
    "holocron_from_ndarray",
]

_ML_DEPENDENCY_MESSAGE = (
    "holobit_sdk.api.python_bridge requiere las dependencias del extra 'ml'"
    " (pandas, scikit-learn y torch). Instálalas con `pip install .[ml]` "
    "para habilitar las utilidades del puente de datos. Consulta la sección"
    " 'Extras opcionales' del README:"
    " https://github.com/Alphonsus411/holobit_SDK#extras-opcionales"
)


def __getattr__(name: str) -> Any:  # pragma: no cover - compatibilidad dinámica
    """Importación perezosa de utilidades que dependen de extras opcionales."""

    if name in _PYTHON_BRIDGE_ATTRS:
        module = _load_python_bridge()
        return getattr(module, name)
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")


def __dir__() -> List[str]:  # pragma: no cover - soporte de introspección
    return sorted(list(globals().keys()) + _PYTHON_BRIDGE_ATTRS)


def _load_python_bridge():
    """Carga holobit_sdk.api.python_bridge solo cuando es necesario."""

    try:
        return import_module("holobit_sdk.api.python_bridge")
    except ImportError as exc:  # pragma: no cover - para entornos sin pandas/numpy
        raise ImportError(_ML_DEPENDENCY_MESSAGE) from exc


__all__ = _PYTHON_BRIDGE_ATTRS
