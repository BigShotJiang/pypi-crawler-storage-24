"""Implementación simplificada de los stubs gRPC generados para Holobit."""

from __future__ import annotations

from typing import Callable, Sequence

from holobit_sdk.utils.bootstrap import ensure_package_context

ensure_package_context(globals())

import grpc

from holobit_sdk.api import holobit_pb2 as holobit__pb2


class HolobitServiceStub:
    """Cliente ligero que delega en el ``Channel`` proporcionado."""

    def __init__(self, channel: grpc.Channel) -> None:  # type: ignore[name-defined]
        self._compile = channel.unary_unary(
            "/holobit.HolobitService/Compile",
            request_serializer=holobit__pb2.CodeRequest.SerializeToString,
            response_deserializer=holobit__pb2.JobReply.FromString,
        )
        self._execute = channel.unary_unary(
            "/holobit.HolobitService/Execute",
            request_serializer=holobit__pb2.JobRequest.SerializeToString,
            response_deserializer=holobit__pb2.ResultReply.FromString,
        )

    def Compile(self, request: holobit__pb2.CodeRequest, metadata: Sequence[tuple[str, str]] | None = None):  # noqa: N802
        return self._compile(request, metadata=metadata)

    def Execute(self, request: holobit__pb2.JobRequest, metadata: Sequence[tuple[str, str]] | None = None):  # noqa: N802
        return self._execute(request, metadata=metadata)


class HolobitServiceServicer:
    """Base para implementar el servicio del lado del servidor."""

    def Compile(self, request, context):  # noqa: N802, D401 - interfaz generada
        raise NotImplementedError("Method not implemented!")

    def Execute(self, request, context):  # noqa: N802, D401 - interfaz generada
        raise NotImplementedError("Method not implemented!")


def add_HolobitServiceServicer_to_server(servicer: HolobitServiceServicer, server: grpc.Server) -> None:
    """Registra los handlers del servicio en el servidor proporcionado."""

    handlers = {
        "Compile": _unary_unary_handler(servicer.Compile, holobit__pb2.CodeRequest.FromString, holobit__pb2.JobReply.SerializeToString),
        "Execute": _unary_unary_handler(servicer.Execute, holobit__pb2.JobRequest.FromString, holobit__pb2.ResultReply.SerializeToString),
    }
    generic = grpc.method_handlers_generic_handler("holobit.HolobitService", handlers)
    server.add_generic_rpc_handlers((generic,))


def _unary_unary_handler(
    func: Callable[[object, grpc.ServicerContext], object],
    request_deserializer: Callable[[bytes], object],
    response_serializer: Callable[[object], bytes],
) -> grpc.RpcMethodHandler:
    return grpc.unary_unary_rpc_method_handler(
        func,
        request_deserializer=request_deserializer,
        response_serializer=response_serializer,
    )


__all__ = [
    "HolobitServiceStub",
    "HolobitServiceServicer",
    "add_HolobitServiceServicer_to_server",
]
