# Costara

Costara is an AI cost and performance monitoring SDK.

This initial version is a placeholder package to reserve the package name on PyPI.
