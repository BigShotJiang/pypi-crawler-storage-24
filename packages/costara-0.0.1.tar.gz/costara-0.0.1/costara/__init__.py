"""
Costara - AI Cost & Performance Monitoring SDK
"""

__version__ = "0.0.1"
