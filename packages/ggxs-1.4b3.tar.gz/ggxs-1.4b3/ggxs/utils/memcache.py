import asyncio
import random
import time
from typing import Any, Awaitable, Callable, Dict, Optional

from loguru import logger


class MemCache:
    """
    An in-memory cache with TTL support for both synchronous and asynchronous usage.

    Features:
    - Optional per-key TTL support
    - Background expiration tasks for TTL entries
    - Lazy expiration on read operations
    - Per-key async locking for concurrency-safe async access
    - Optional expiration callback supporting sync or async callables
    - Scheduling helpers for relative and chained expiration

    Best suited for:
    - Short- and medium-lived cache entries
    - Request-scoped or session-like data
    - Async applications that need lightweight in-process caching

    Notes:
    - Synchronous methods do not acquire per-key locks.
    - Asynchronous methods use per-key locks for consistent concurrent access.
    - Expired keys may still remain in memory until read or until the background
      expiration task removes them.
    """

    def __init__(
        self,
        default_ttl: float = 300.0,
        on_expire: Optional[Callable[[Any, Any], Any]] = None,
    ):
        """
        Initialize the cache.

        Args:
            default_ttl: Default TTL in seconds for entries stored with
                ``set_with_ttl()`` when no explicit TTL is provided.
            on_expire: Optional callback invoked when an item expires.
                The callback receives ``(key, value)`` and may be either
                synchronous or asynchronous.
        """
        self._default_ttl = default_ttl
        self._on_expire = on_expire or (lambda k, v: None)

        self._data: Dict[Any, Any] = {}
        self._expires: Dict[Any, float] = {}
        self._tasks: Dict[Any, asyncio.Task] = {}
        self._locks: Dict[Any, asyncio.Lock] = {}

    # ---------------------------------------------------------------------
    # Internal shared helpers
    # ---------------------------------------------------------------------

    def _is_expired_unlocked(self, key: Any, now: Optional[float] = None) -> bool:
        """
        Return whether a key is expired.

        This helper assumes the caller is responsible for any required locking.

        Args:
            key: Cache key to inspect.
            now: Optional current timestamp to avoid repeated ``time.time()``
                calls across hot paths.

        Returns:
            ``True`` if the key has a TTL and that TTL has elapsed, otherwise
            ``False``.
        """
        expire_time = self._expires.get(key)
        if expire_time is None:
            return False

        if now is None:
            now = time.time()

        return now > expire_time

    def _exists_unlocked(self, key: Any, now: Optional[float] = None) -> bool:
        """
        Return whether a key currently exists and is still active.

        This helper assumes the caller is responsible for any required locking.

        Args:
            key: Cache key to inspect.
            now: Optional current timestamp used for TTL validation.

        Returns:
            ``True`` if the key is present and not expired, otherwise ``False``.
        """
        if key not in self._data:
            return False

        return not self._is_expired_unlocked(key, now)

    def _remove_expired_unlocked(self, key: Any) -> Any:
        """
        Remove an expired key without acquiring locks.

        This cancels any scheduled expiration task, removes the cached value,
        and clears the stored expiration timestamp.

        Args:
            key: Cache key to remove.

        Returns:
            The previously stored value, or ``None`` if it was missing.
        """
        self._cancel_task(key)
        value = self._data.pop(key, None)
        self._expires.pop(key, None)
        return value

    def _schedule_callback(self, key: Any, value: Any) -> None:
        """
        Schedule the expiration callback from synchronous code when possible.

        If no event loop is currently running, the callback is skipped because
        there is no safe place to schedule an async task from a sync-only
        context.

        Args:
            key: Expired cache key.
            value: Value associated with the expired key.
        """
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self._safe_callback(key, value))
        except RuntimeError:
            # No running event loop. Skip callback scheduling in pure sync usage.
            pass

    # ---------------------------------------------------------------------
    # Core synchronous API
    # ---------------------------------------------------------------------

    def set(self, key: Any, value: Any) -> None:
        """
        Store a value without expiration.

        Args:
            key: Cache key.
            value: Value to store.
        """
        self._data[key] = value
        self._expires.pop(key, None)
        self._cancel_task(key)

    async def set_with_ttl(self, key: Any, value: Any, ttl: Optional[float] = None) -> None:
        """
        Store a value with a TTL.

        Args:
            key: Cache key.
            value: Value to store.
            ttl: TTL in seconds. If omitted, ``default_ttl`` is used.
        """
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            await self._set_with_ttl_unlocked(key, value, ttl)

    async def _set_with_ttl_unlocked(self, key: Any, value: Any, ttl: Optional[float]) -> None:
        """
        Store a value with a TTL without acquiring a lock.

        Args:
            key: Cache key.
            value: Value to store.
            ttl: TTL in seconds. If omitted, ``default_ttl`` is used.
        """
        self._cancel_task(key)
        self._data[key] = value

        actual_ttl = ttl if ttl is not None else self._default_ttl
        self._expires[key] = time.time() + actual_ttl
        self._tasks[key] = asyncio.create_task(self._expire_after_delay(key, actual_ttl))

    def get(self, key: Any, default: Any = None) -> Any:
        """
        Return a cached value, performing lazy expiration when needed.

        Args:
            key: Cache key to retrieve.
            default: Value returned when the key does not exist or is expired.

        Returns:
            The cached value if present and active, otherwise ``default``.
        """
        if key not in self._data:
            return default

        now = time.time()
        if self._is_expired_unlocked(key, now):
            value = self._remove_expired_unlocked(key)
            if value is not None:
                self._schedule_callback(key, value)
            return default

        return self._data[key]

    def delete(self, key: Any) -> bool:
        """
        Remove a key immediately.

        Args:
            key: Cache key to remove.

        Returns:
            ``True`` if the key existed and was removed, otherwise ``False``.
        """
        if key not in self._data:
            return False

        self._cancel_task(key)
        self._data.pop(key, None)
        self._expires.pop(key, None)
        return True

    def exists(self, key: Any) -> bool:
        """
        Return whether a key exists and is still active.

        This method does not actively remove expired keys; it only reports their
        current status.

        Args:
            key: Cache key to inspect.

        Returns:
            ``True`` if the key is present and not expired, otherwise ``False``.
        """
        return self._exists_unlocked(key, time.time())

    # ---------------------------------------------------------------------
    # Scheduling helpers
    # ---------------------------------------------------------------------

    async def set_in_timeline(self, key: Any, value: Any, delay: float, jitter: float = 0.0) -> None:
        """
        Store a value with a relative delay and optional jitter.

        Args:
            key: Cache key.
            value: Value to store.
            delay: Base delay in seconds before expiration.
            jitter: Random offset added in the range ``[-jitter, +jitter]``.
        """
        jitter_value = random.uniform(-jitter, jitter) if jitter > 0 else 0.0
        actual_delay = max(0.0, delay + jitter_value)
        await self.set_with_ttl(key, value, actual_delay)

    async def chain_schedule(self, key: Any, value: Any, interval: float, jitter: float = 0.0) -> None:
        """
        Extend expiration relative to the last scheduled expiration time.

        If the key is already scheduled to expire in the future, the new TTL is
        chained after that point. Otherwise, the interval starts from now.

        Args:
            key: Cache key.
            value: Value to store.
            interval: Additional interval in seconds.
            jitter: Random offset added in the range ``[-jitter, +jitter]``.
        """
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            now = time.time()
            expiry = self._expires.get(key, now)
            delay = 0.0 if expiry < now else expiry - now

            jitter_value = random.uniform(-jitter, jitter) if jitter > 0 else 0.0
            delay += max(0.0, interval + jitter_value)

            await self._set_with_ttl_unlocked(key, value, delay)

    async def get_or_set(self, key: Any, value_coroutine: Awaitable[Any], ttl: Optional[float] = None) -> Any:
        """
        Return an existing value or compute and store a new one atomically.

        Args:
            key: Cache key.
            value_coroutine: Awaitable used to compute the value when the key is
                not already present.
            ttl: Optional TTL for the computed value.

        Returns:
            The existing or newly computed value.
        """
        existing = self.get(key)
        if existing is not None:
            return existing

        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            existing = self.get(key)
            if existing is not None:
                return existing

            new_value = await value_coroutine
            await self._set_with_ttl_unlocked(key, new_value, ttl)
            return new_value

    # ---------------------------------------------------------------------
    # Expiration internals
    # ---------------------------------------------------------------------

    def _expire_key_sync(self, key: Any) -> None:
        """
        Expire a key from synchronous code and schedule the callback if possible.

        Args:
            key: Cache key to expire.
        """
        if key not in self._data:
            return

        value = self._data.pop(key)
        self._expires.pop(key, None)
        self._tasks.pop(key, None)
        self._schedule_callback(key, value)

    async def _expire_key(self, key: Any) -> None:
        """
        Expire a key from asynchronous code and await the callback.

        Args:
            key: Cache key to expire.
        """
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            if key not in self._data:
                return

            if not self._is_expired_unlocked(key, time.time()):
                return

            value = self._data.pop(key)
            self._expires.pop(key, None)
            self._tasks.pop(key, None)

        await self._safe_callback(key, value)

    async def _expire_after_delay(self, key: Any, delay: float) -> None:
        """
        Sleep until expiration time and then attempt to expire the key.

        Args:
            key: Cache key to expire.
            delay: Delay in seconds before expiration.
        """
        try:
            await asyncio.sleep(delay)
            await self._expire_key(key)
        except asyncio.CancelledError:
            pass

    async def _safe_callback(self, key: Any, value: Any) -> None:
        """
        Execute the expiration callback safely.

        The callback may be either synchronous or asynchronous. Any exception is
        caught and logged.

        Args:
            key: Expired cache key.
            value: Expired value.
        """
        try:
            result = self._on_expire(key, value)
            if asyncio.iscoroutine(result):
                await result
        except Exception as exc:
            logger.error(f"Expiration callback error for key '{key}': {exc}")

    def _cancel_task(self, key: Any) -> None:
        """
        Cancel the scheduled expiration task for a key.

        Args:
            key: Cache key whose task should be cancelled.
        """
        task = self._tasks.pop(key, None)
        if task:
            task.cancel()

    # ---------------------------------------------------------------------
    # Cache management
    # ---------------------------------------------------------------------

    def clear(self) -> None:
        """
        Remove all cache entries and cancel all expiration tasks.

        Expiration callbacks are not executed for cleared entries.
        """
        for task in self._tasks.values():
            task.cancel()

        self._data.clear()
        self._tasks.clear()
        self._expires.clear()
        self._locks.clear()

    async def aclose(self) -> None:
        """
        Gracefully shut down the cache.

        All expiration tasks are cancelled and awaited before internal state is
        cleared.
        """
        tasks = list(self._tasks.values())
        for task in tasks:
            task.cancel()

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        self.clear()

    # ---------------------------------------------------------------------
    # Utility methods
    # ---------------------------------------------------------------------

    def get_remaining_ttl(self, key: Any) -> Optional[float]:
        """
        Return the remaining TTL for a key.

        Args:
            key: Cache key to inspect.

        Returns:
            Remaining TTL in seconds, or ``None`` when the key has no TTL or the
            TTL has already elapsed.
        """
        if key not in self._expires:
            return None

        remaining = self._expires[key] - time.time()
        return remaining if remaining > 0 else None

    def keys(self) -> list:
        """
        Return all currently active keys.

        Returns:
            A list containing keys that are either non-expiring or not yet
            expired.
        """
        now = time.time()
        return [
            key
            for key in self._data
            if key not in self._expires or self._expires[key] > now
        ]

    def __contains__(self, key: Any) -> bool:
        """Return whether a key exists and is still active."""
        return self.exists(key)

    def __len__(self) -> int:
        """Return the number of currently active keys."""
        return len(self.keys())

    # ---------------------------------------------------------------------
    # Async locked variants
    # ---------------------------------------------------------------------

    async def _get(self, key: Any, default: Any = None) -> Any:
        """
        Locked asynchronous version of ``get()``.

        Args:
            key: Cache key to retrieve.
            default: Value returned when the key does not exist or is expired.

        Returns:
            The cached value if present and active, otherwise ``default``.
        """
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            if key not in self._data:
                return default

            now = time.time()
            if self._is_expired_unlocked(key, now):
                value = self._remove_expired_unlocked(key)
                if value is not None:
                    asyncio.create_task(self._safe_callback(key, value))
                return default

            return self._data[key]

    async def _set(self, key: Any, value: Any) -> None:
        """
        Locked asynchronous version of ``set()``.

        Args:
            key: Cache key.
            value: Value to store.
        """
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            self._cancel_task(key)
            self._data[key] = value
            self._expires.pop(key, None)

    async def _delete(self, key: Any) -> bool:
        """
        Locked asynchronous version of ``delete()``.

        Args:
            key: Cache key to remove.

        Returns:
            ``True`` if the key existed and was removed, otherwise ``False``.
        """
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            if key not in self._data:
                return False

            self._cancel_task(key)
            self._data.pop(key, None)
            self._expires.pop(key, None)
            return True

    async def _exists(self, key: Any) -> bool:
        """
        Locked asynchronous version of ``exists()``.

        Args:
            key: Cache key to inspect.

        Returns:
            ``True`` if the key is present and not expired, otherwise ``False``.
        """
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            return self._exists_unlocked(key, time.time())
