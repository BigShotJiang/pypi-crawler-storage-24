# Architecture

## High-Level Design
Specification engineering and SpecPack compiler for AbilityBI requirement management.

## Components
- src/abi_spec/ — SpecPack compiler and validator
- tests/ — specification quality tests

## Interfaces
Inputs: Structured data, policy definitions, or API requests depending on module.
Outputs: Processed results, evidence packs, or structured reports.
