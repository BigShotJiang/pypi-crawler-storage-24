# Determinism Model — abi-spec

## Guarantee

Given identical PRD input, `compile_prd_json_to_specpack()` always produces
byte-identical output files with identical SHA-256 hashes.

## Mechanisms

1. **Canonical JSON serialization**: Keys sorted alphabetically at every nesting
   level, compact separators `(",",":")`, no trailing newline, UTF-8 encoding.

2. **Content-addressed output**: `hashes.json` contains SHA-256 of every emitted
   file, computed from the canonical byte representation.

3. **No timestamps in hashed payload**: The spec_manifest and hashes.json contain
   no timestamp-like fields (timestamp, created_at, time, ts). This is backed by
   explicit regression tests.

4. **Self-referential hash exclusion**: `manifest_hash` in hashes.json is computed
   over spec_manifest.json content, not over hashes.json itself.

## Hash Chain

```
PRD JSON → canonical_hash(prd_content) → prd_hash
spec_manifest.json → canonical_hash(file_bytes) → manifest_hash
hashes.json = { manifest_hash, prd_hash }
```

## Regression Tests

- `test_determinism.py::TestCompileDeterminism` — same input produces same hash
- `test_determinism.py::TestTimestampExclusion` — no timestamp keys in output
- `test_determinism.py::TestKeyOrderInsensitive` — dict order does not affect hash
