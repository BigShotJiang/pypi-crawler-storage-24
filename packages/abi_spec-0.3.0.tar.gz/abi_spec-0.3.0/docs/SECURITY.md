# Security — abi-spec

## Threat Model

abi-spec processes PRD JSON files and produces SpecPack directories.
It does not make network calls, execute arbitrary code, or handle secrets.

## Input Validation

- PRD JSON is validated against expected structure before compilation.
- spec_manifest.json is validated against `spec_manifest.schema.json`
  (JSON Schema Draft 2020-12) before being written.

## Content Integrity

- All output files are content-addressed via SHA-256.
- Downstream consumers can verify SpecPack integrity by recomputing hashes
  and comparing against `hashes.json`.

## Dependency Surface

- Runtime: `jsonschema` only (schema validation).
- No network dependencies, no file-system traversal beyond specified paths.
