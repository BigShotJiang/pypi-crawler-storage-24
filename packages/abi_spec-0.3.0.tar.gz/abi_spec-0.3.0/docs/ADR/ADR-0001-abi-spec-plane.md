# ADR-0001: abi-spec — Specification Engineering Plane

**Date:** 2026-02-28
**Status:** Accepted
**Deciders:** Platform team

---

## Context

The ABI ecosystem needs a structured pipeline that transforms PRD narratives
into machine-readable, content-addressed specification artifacts. Currently,
PRDs are unstructured Markdown with no deterministic compilation path.

## Decision

Create `abi-spec` as a dedicated repo with:

1. **SpecPack Compiler** — transforms PRD JSON into a SpecPack directory containing
   `spec_manifest.json` (schema-validated) and `hashes.json` (SHA-256 content addresses).

2. **Deterministic output** — canonical JSON serialization ensures identical input
   always produces identical output.

3. **Schema validation** — `spec_manifest.schema.json` (`abi-spec-manifest/1.0`)
   enforces structure at compile time.

## Ownership

| Aspect | Owner |
|--------|-------|
| SpecPack Compiler | abi-spec |
| spec_manifest schema | abi-spec (local, migrates to abi-core later) |
| PRD authoring | abi-prd |
| Constraint evaluation | abi-constraints |

## Dependency Direction

- **Rank 1**: abi-spec depends only on abi-core (future schema migration).
- **Forbidden imports**: abi-orchestrator, abi-policy, abi-runtime, abi-plugins,
  abi-evals, abi-observability, abi-promptware.

## Consequences

- Downstream repos can reference specs by `manifest_hash` (SHA-256).
- Acceptance criteria become machine-extractable.
- Future: acceptance scaffold generation, traceability maps.
