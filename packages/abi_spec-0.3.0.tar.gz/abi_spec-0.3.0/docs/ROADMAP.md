# Roadmap

## Near Term
- SpecPack diff and versioning
- Spec-to-test gap analysis

## Later
- Automated SpecPack generation from PRDs
