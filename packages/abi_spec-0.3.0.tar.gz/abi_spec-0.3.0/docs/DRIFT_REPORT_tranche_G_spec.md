# Drift Report — Tranche G: abi-spec

**Date:** 2026-02-28
**Scope:** Pre-implementation audit of spec-like logic across the ABI fleet

---

## Existing Spec-Like Logic

| Location | What It Does | Repo |
|----------|-------------|------|
| `abi-prd/` | PRD narrative authoring, no structured output | abi-prd |
| `abi-orchestrator/src/engine/plan_graph.py` | Plan graph uses `plan_graph/1.0` schema | abi-orchestrator |
| `abi-constraints/schemas/constraint_bundle.schema.json` | Constraint bundles reference requirements indirectly | abi-constraints |

## Gap Analysis

1. **No PRD-to-spec pipeline exists.** PRDs live as unstructured Markdown in abi-prd.
   There is no compiler that transforms them into machine-readable specs.

2. **No content-addressed spec artifact.** Downstream repos cannot reference
   a specific version of requirements by hash.

3. **No acceptance scaffold.** Test stubs are manually created; no generation
   from acceptance criteria.

## What abi-spec Fills

- SpecPack Compiler: PRD JSON → content-addressed spec_manifest.json + hashes.json
- Schema validation: `abi-spec-manifest/1.0` JSON Schema
- Deterministic output: canonical JSON serialization, SHA-256 hashing
- CLI: compile and validate commands

## Dependency Direction

abi-spec depends on abi-core only (future schema migration).
No imports from abi-orchestrator, abi-policy, abi-runtime, abi-plugins.
