# Verification Notes — abi-spec

## Traceability Markers

### Full node ID: determinism

```
tests/test_determinism.py::TestCompileDeterminism::test_same_input_same_hash_100_times
```

Compiles the same PRD 100 times and asserts a single unique `manifest_hash`,
proving the compile pipeline is fully deterministic.

### Full node ID: timestamp exclusion

```
tests/test_determinism.py::TestTimestampExclusion::test_manifest_has_no_timestamp_keys
```

Asserts that `spec_manifest.json` contains zero keys from the set
{timestamp, timestamps, created_at, time, ts}, ensuring no volatile
timestamps leak into hashed payloads.

---

## Tranche History

- **Definition Plane Tranche** (base HEAD `1a3dbad`) — schema integrity, contract rigor

### Definition Plane Tranche — Capability Advancement

**Schema integrity** — 31 tests in `tests/test_schema_integrity.py`

Full node ID:
```
tests/test_schema_integrity.py::TestSchemaSelfValidity::test_schema_is_valid_draft_2020_12
```

31 new tests total. All pass. Draft 2020-12 self-validation, $ref integrity walk,
17 negative validation tests, schema completeness verification.

### Model Governance & Routing Spec v1.0 — Spec Document

**Base HEAD**: `1a3dbad`

Added `docs/MODEL_GOVERNANCE_SPEC_v1.md` — specification document covering model registry, deterministic routing algorithm, RU budget with quota zones, subscription capacity model, evidence ledger, project profiles, and extension strategy.

Doc-only change; no test impact. Pre-existing CLI test failures (2 tests: `No module named abi_spec`) are unrelated — environment issue, not caused by this tranche.

verify.log: EXIT_CODE=1 (pre-existing; 65 passed, 2 failed — CLI module resolution)
