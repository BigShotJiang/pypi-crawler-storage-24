# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

## [0.3.0] - 2026-03-05
### Added
- **Spec-Driven Development (SDD)**: Living spec management and drift detection
  - `SpecTracker` class for tracking spec versions and linked code paths
  - `SpecVersion` dataclass: spec_id, version, SHA-256 content_hash, updated_at, linked_code_paths
  - `DriftResult` dataclass: has_drift, spec_changed_since_code, code_changed_since_spec, details
  - Drift detection with time-based and hash-based analysis
  - CLI commands: `abi-spec drift check` and `abi-spec drift track`
  - Support for tracking individual files or entire directories
  - Tracking metadata stored in `.abi/spec_tracking.json`
- Comprehensive test suite: 14 new tests for spec tracker functionality
- Documentation: `docs/SDD_USAGE.md` with usage guide, workflows, and CI/CD integration examples

### Documentation
- Updated README.md with SDD feature announcement
- Added SDD_USAGE.md with comprehensive guide and examples

## [0.2.0] - 2026-03-04
### Added
- REQ-ID traceability (T-0210): Unique requirement IDs with pattern `REQ-NNN`
- Acceptance criteria parser: Given/When/Then format support
- Requirements index: Enhanced metadata with `title`, `acceptance_criteria`, `source_prd_section`
- Traceability matrix generator: Maps REQ-IDs → test results → pass/fail
- Coverage reporting: Identifies untested requirements
- CLI command `traceability`: Generate traceability matrices from SpecPacks
- Schema validation: Enforces REQ-ID format and GWT structure
- Comprehensive test suite: 98 tests for traceability, acceptance parsing, and validation

### Changed
- Schema version 1.0: Added required `requirements_index` field
- Requirements now support optional `title` and `source_prd_section` fields
- Acceptance criteria must include structured Given/When/Then format

### Documentation
- Added `docs/TRACEABILITY.md`: Complete guide to REQ-ID traceability
- Updated README.md with v0.2.0 features
- Added orchestrator integration examples

## [0.1.1] - 2026-03-02
### Added
- Documentation pack standardization (v1)

### Added
- Presentation standardization: README header block, privacy statement, tier line.

## [0.1.0] — 2026-02-28

### Added
- Tagged: abi-fleet-anchor-phase2-v1 (fleet presentation baseline).
- Initial release: SpecPack compiler, CLI, determinism proofs.
