"""Spec-Driven Development (SDD) support for abi-spec.

This module provides living spec management capabilities:
- Track spec versions and their relationships to code
- Detect drift between specs and implementation
- Support the principle: "Fix the spec first, then regenerate code"
"""

from .spec_tracker import DriftResult, SpecTracker, SpecVersion

__all__ = ["DriftResult", "SpecTracker", "SpecVersion"]
