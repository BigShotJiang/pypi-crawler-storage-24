"""ABI Spec — specification engineering plane for the ABI ecosystem."""
__version__ = "0.3.0"
