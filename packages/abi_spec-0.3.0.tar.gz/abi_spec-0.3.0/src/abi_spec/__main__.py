"""Allow running abi_spec as a module: python -m abi_spec."""
from abi_spec.cli import main

raise SystemExit(main())
