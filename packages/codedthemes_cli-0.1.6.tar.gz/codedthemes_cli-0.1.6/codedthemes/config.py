import json
from pathlib import Path

# Stores token at ~/.codedthemes/config.json
CONFIG_DIR = Path.home() / ".codedthemes"
CONFIG_FILE = CONFIG_DIR / "config.json"


def ensure_config_dir():
    """
    Ensures the configuration directory exists.
    """
    CONFIG_DIR.mkdir(exist_ok=True)


def save_config(data: dict):
    """
    Saves the provided configuration data to the config file.
    """
    ensure_config_dir()
    with open(CONFIG_FILE, "w") as f:
        json.dump(data, f, indent=2)


def load_config():
    """
    Loads the configuration data from the config file.
    """
    if not CONFIG_FILE.exists():
        return {}
    with open(CONFIG_FILE, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}
