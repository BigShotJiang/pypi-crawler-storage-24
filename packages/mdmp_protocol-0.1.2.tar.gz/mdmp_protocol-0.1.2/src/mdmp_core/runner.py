from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
from typing import Any

import numpy as np
import pandas as pd

from .contracts import DataContract


MDMP_PROTOCOL_VERSION = "1.0"
MDMP_GRADE_ORDER = ("raw", "draft", "research_grade", "clinical_grade", "ai_ready")


@dataclass(frozen=True)
class ValidationCheck:
    name: str
    passed: bool
    detail: str
    failed_rows: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "passed": self.passed,
            "detail": self.detail,
            "failed_rows": self.failed_rows,
        }


@dataclass(frozen=True)
class ValidationResult:
    created_utc: str
    protocol_version: str
    is_compliant: bool
    compliance_score: float
    grade: str
    contract_fingerprint_sha256: str
    dataset_fingerprint_sha256: str
    row_count: int
    checks: list[ValidationCheck]
    consent_verified: bool

    def to_dict(self) -> dict[str, Any]:
        return {
            "created_utc": self.created_utc,
            "protocol_version": self.protocol_version,
            "is_compliant": self.is_compliant,
            "compliance_score": self.compliance_score,
            "grade": self.grade,
            "contract_fingerprint_sha256": self.contract_fingerprint_sha256,
            "dataset_fingerprint_sha256": self.dataset_fingerprint_sha256,
            "row_count": self.row_count,
            "consent_verified": self.consent_verified,
            "checks": [c.to_dict() for c in self.checks],
        }


def dataframe_fingerprint(df: pd.DataFrame) -> str:
    normalized = df.copy()
    normalized = normalized.reindex(sorted(normalized.columns), axis=1)
    for col in normalized.columns:
        series = normalized[col]
        if pd.api.types.is_datetime64_any_dtype(series):
            normalized[col] = series.astype("datetime64[ns]").astype("int64").astype(str)
        else:
            normalized[col] = series.astype(str).fillna("__NA__")
    hashed = pd.util.hash_pandas_object(normalized, index=True).to_numpy(dtype=np.uint64, copy=False)
    digest = sha256()
    digest.update(",".join(normalized.columns).encode("utf-8"))
    digest.update(hashed.tobytes())
    return digest.hexdigest()


def _check_type(series: pd.Series, expected: str) -> bool:
    expected = expected.lower()
    if expected in {"float", "number", "numeric"}:
        return bool(pd.api.types.is_numeric_dtype(series))
    if expected in {"int", "integer"}:
        return bool(pd.api.types.is_integer_dtype(series))
    if expected in {"str", "string"}:
        return bool(pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series))
    if expected in {"datetime", "timestamp"}:
        return bool(pd.api.types.is_datetime64_any_dtype(series) or pd.to_datetime(series, errors="coerce").notna().mean() > 0.95)
    if expected in {"bool", "boolean"}:
        return bool(pd.api.types.is_bool_dtype(series))
    return True


def _grade(score: float, is_compliant: bool, consent_ok: bool) -> str:
    if not is_compliant:
        return "raw"
    if score < 75.0:
        return "draft"
    if score < 90.0:
        return "research_grade"
    if score < 95.0 or not consent_ok:
        return "clinical_grade"
    return "ai_ready"


def grade_meets_minimum(actual: str, minimum: str) -> bool:
    try:
        return MDMP_GRADE_ORDER.index(actual) >= MDMP_GRADE_ORDER.index(minimum)
    except ValueError:
        return False


class ContractRunner:
    def __init__(self, contract: DataContract) -> None:
        self.contract = contract

    def run(self, df: pd.DataFrame) -> ValidationResult:
        checks: list[ValidationCheck] = []

        missing = [c.name for c in self.contract.schema.columns if c.required and c.name not in df.columns]
        checks.append(
            ValidationCheck(
                name="schema_columns",
                passed=len(missing) == 0,
                detail="all required columns present" if not missing else f"missing: {missing}",
            )
        )

        type_failures: list[str] = []
        for col in self.contract.schema.columns:
            if col.name not in df.columns:
                continue
            if not _check_type(df[col.name], col.type):
                type_failures.append(f"{col.name}:{col.type}")
        checks.append(
            ValidationCheck(
                name="schema_types",
                passed=len(type_failures) == 0,
                detail="all type checks passed" if not type_failures else f"type mismatch: {type_failures}",
            )
        )

        range_failures = 0
        range_details: list[str] = []
        for col in self.contract.schema.columns:
            if col.bounds is None or col.name not in df.columns:
                continue
            lo, hi = col.bounds
            values = pd.to_numeric(df[col.name], errors="coerce")
            below = int((values < lo).fillna(False).sum())
            above = int((values > hi).fillna(False).sum())
            if below:
                range_failures += below
                range_details.append(f"{col.name}<{lo}:{below}")
            if above:
                range_failures += above
                range_details.append(f"{col.name}>{hi}:{above}")
        checks.append(
            ValidationCheck(
                name="value_bounds",
                passed=range_failures == 0,
                detail="all bounds satisfied" if range_failures == 0 else "; ".join(range_details),
                failed_rows=range_failures,
            )
        )

        consent_ok = bool(self.contract.consent.ai_training_allowed and self.contract.consent.anonymized)
        checks.append(
            ValidationCheck(
                name="consent",
                passed=consent_ok,
                detail=(
                    "ai_training_allowed + anonymized"
                    if consent_ok
                    else "consent requirements failed (need ai_training_allowed=true and anonymized=true)"
                ),
            )
        )

        passed = sum(1 for c in checks if c.passed)
        score = round((passed / len(checks)) * 100.0, 2) if checks else 0.0
        is_compliant = all(c.passed for c in checks[:-1])
        grade = _grade(score=score, is_compliant=is_compliant, consent_ok=consent_ok)

        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        return ValidationResult(
            created_utc=now,
            protocol_version=MDMP_PROTOCOL_VERSION,
            is_compliant=is_compliant,
            compliance_score=score,
            grade=grade,
            contract_fingerprint_sha256=self.contract.fingerprint_sha256(),
            dataset_fingerprint_sha256=dataframe_fingerprint(df),
            row_count=int(len(df)),
            checks=checks,
            consent_verified=consent_ok,
        )
