from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
import json


REGISTRY_VERSION = "mdmp-registry-v0"


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _normalize_fingerprint(value: str) -> str:
    text = value.strip()
    if not text:
        raise ValueError("Fingerprint cannot be empty")
    if text.startswith("sha256:"):
        return text
    return f"sha256:{text}"


def _default_registry() -> Dict[str, Any]:
    return {
        "version": REGISTRY_VERSION,
        "updated_utc": _now_iso(),
        "records": {},
    }


def load_registry(path: Path) -> Dict[str, Any]:
    if not path.is_file():
        return _default_registry()
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        return _default_registry()
    payload.setdefault("version", REGISTRY_VERSION)
    payload.setdefault("updated_utc", _now_iso())
    records = payload.get("records")
    payload["records"] = records if isinstance(records, dict) else {}
    return payload


def save_registry(path: Path, payload: Dict[str, Any]) -> None:
    payload["updated_utc"] = _now_iso()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def init_registry(path: Path) -> Dict[str, Any]:
    payload = _default_registry()
    save_registry(path, payload)
    return payload


def _extract_from_report(report: Dict[str, Any]) -> Dict[str, Any]:
    grade = str(report.get("grade", report.get("mdmp_grade", "draft")))
    protocol = str(report.get("protocol_version", report.get("mdmp_protocol_version", "1.0")))
    dataset_fp_raw = report.get("dataset_fingerprint_sha256", "")
    if not dataset_fp_raw:
        raise ValueError("Report does not contain dataset fingerprint")
    dataset_fp = _normalize_fingerprint(str(dataset_fp_raw))

    staleness = report.get("staleness", {})
    if not isinstance(staleness, dict):
        staleness = {}

    status = str(staleness.get("status", "valid"))
    stale_reason = staleness.get("stale_reason")
    expires = staleness.get("expires") or report.get("expires")

    return {
        "fingerprint": dataset_fp,
        "grade": grade,
        "protocol_version": protocol,
        "contract_fingerprint": (
            _normalize_fingerprint(str(report["contract_fingerprint_sha256"]))
            if report.get("contract_fingerprint_sha256")
            else None
        ),
        "row_count": int(report.get("row_count", 0)),
        "consent_verified": bool(
            report.get("consent_verified", report.get("certified_for_medical_research", False))
        ),
        "compliance_score": float(report.get("compliance_score", 0.0)),
        "status": status,
        "stale_reason": stale_reason,
        "expires": expires,
    }


def upsert_record(
    registry_path: Path,
    *,
    fingerprint: Optional[str] = None,
    report: Optional[Dict[str, Any]] = None,
    grade: Optional[str] = None,
    source: Optional[str] = None,
    visibility: str = "private",
    used_in_models: Optional[List[str]] = None,
    expires: Optional[str] = None,
    status: Optional[str] = None,
    stale_reason: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    if report is None and not fingerprint:
        raise ValueError("Provide fingerprint or report")

    base: Dict[str, Any] = {}
    if report is not None:
        base.update(_extract_from_report(report))
    if fingerprint is not None:
        base["fingerprint"] = _normalize_fingerprint(fingerprint)
    if grade is not None:
        base["grade"] = grade
    if expires is not None:
        base["expires"] = expires
    if status is not None:
        base["status"] = status
    if stale_reason is not None:
        base["stale_reason"] = stale_reason

    fp = _normalize_fingerprint(str(base.get("fingerprint", "")))

    payload = load_registry(registry_path)
    existing = payload["records"].get(fp, {})
    if not isinstance(existing, dict):
        existing = {}

    merged = {
        "fingerprint": fp,
        "grade": base.get("grade", existing.get("grade", "draft")),
        "protocol_version": base.get("protocol_version", existing.get("protocol_version", "1.0")),
        "contract_fingerprint": base.get("contract_fingerprint", existing.get("contract_fingerprint")),
        "row_count": int(base.get("row_count", existing.get("row_count", 0))),
        "consent_verified": bool(base.get("consent_verified", existing.get("consent_verified", False))),
        "compliance_score": float(base.get("compliance_score", existing.get("compliance_score", 0.0))),
        "status": str(base.get("status", existing.get("status", "valid"))),
        "stale_reason": base.get("stale_reason", existing.get("stale_reason")),
        "expires": base.get("expires", existing.get("expires")),
        "visibility": visibility.strip().lower(),
        "source": source or existing.get("source"),
        "used_in_models": sorted(
            set((used_in_models or []) + list(existing.get("used_in_models", [])))
        ),
        "metadata": metadata or existing.get("metadata", {}),
        "published_at_utc": existing.get("published_at_utc", _now_iso()),
        "updated_at_utc": _now_iso(),
    }
    payload["records"][fp] = merged
    save_registry(registry_path, payload)
    return merged


def lookup_record(registry_path: Path, fingerprint: str) -> Optional[Dict[str, Any]]:
    payload = load_registry(registry_path)
    return payload["records"].get(_normalize_fingerprint(fingerprint))


def list_records(
    registry_path: Path,
    *,
    grade: Optional[str] = None,
    visibility: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    payload = load_registry(registry_path)
    records = list(payload["records"].values())
    filtered: List[Dict[str, Any]] = []
    for record in records:
        if not isinstance(record, dict):
            continue
        if grade and str(record.get("grade", "")).strip().lower() != grade.strip().lower():
            continue
        if visibility and str(record.get("visibility", "")).strip().lower() != visibility.strip().lower():
            continue
        if status and str(record.get("status", "")).strip().lower() != status.strip().lower():
            continue
        filtered.append(record)
    filtered.sort(key=lambda row: str(row.get("updated_at_utc", "")), reverse=True)
    return filtered[: max(0, int(limit))]
