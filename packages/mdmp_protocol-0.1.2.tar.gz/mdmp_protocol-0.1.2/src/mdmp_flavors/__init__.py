from __future__ import annotations

from typing import Any, Dict


def health_template() -> Dict[str, Any]:
    return {
        "schema": {
            "name": "cgm_dataset",
            "version": "1.0",
            "industry": "health",
            "columns": [
                {"name": "timestamp", "type": "datetime", "required": True},
                {"name": "glucose", "type": "float", "unit": "mg/dL", "bounds": [40, 400], "required": True},
            ],
        },
        "consent": {
            "ai_training_allowed": True,
            "jurisdiction": "GDPR",
            "anonymized": True,
        },
    }


def finance_template() -> Dict[str, Any]:
    return {
        "schema": {
            "name": "timeseries_dataset",
            "version": "1.0",
            "industry": "finance",
            "columns": [
                {"name": "timestamp", "type": "datetime", "required": True},
                {"name": "value", "type": "float", "required": True},
            ],
        },
        "consent": {
            "ai_training_allowed": True,
            "jurisdiction": "EU",
            "anonymized": True,
        },
    }


def industrial_template() -> Dict[str, Any]:
    return {
        "schema": {
            "name": "sensor_dataset",
            "version": "1.0",
            "industry": "industrial",
            "columns": [
                {"name": "timestamp", "type": "datetime", "required": True},
                {"name": "sensor_value", "type": "float", "required": True},
            ],
        },
        "consent": {
            "ai_training_allowed": True,
            "jurisdiction": "internal",
            "anonymized": True,
        },
    }


TEMPLATES = {
    "health": health_template,
    "finance": finance_template,
    "industrial": industrial_template,
}
