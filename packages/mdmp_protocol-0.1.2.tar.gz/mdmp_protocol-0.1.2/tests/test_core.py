from __future__ import annotations

from pathlib import Path

import pandas as pd

from mdmp_core.contracts import load_contract
from mdmp_core.runner import ContractRunner, dataframe_fingerprint


def test_runner_grades_demo_dataset() -> None:
    root = Path(__file__).resolve().parents[1]
    contract = load_contract(root / "contracts" / "health_demo.yaml")
    df = pd.read_csv(root / "data" / "demo_cgm.csv")
    result = ContractRunner(contract).run(df)

    assert result.is_compliant is True
    assert result.grade in {"clinical_grade", "ai_ready"}
    assert result.row_count == 5


def test_fingerprint_is_stable() -> None:
    root = Path(__file__).resolve().parents[1]
    df = pd.read_csv(root / "data" / "demo_cgm.csv")
    fp1 = dataframe_fingerprint(df)
    fp2 = dataframe_fingerprint(df)
    assert fp1 == fp2
