import paramiko

def verify():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('proxy.as-in-1.gpu-instance.novita.ai', port=55803, username='root', password='ARhlNki1HoTUW4ZZX8mb')
    
    script = 'export PATH="/usr/local/bin/udocker-1.3.17/udocker:$PATH"; echo "Step 1: PULLING the built Docker Image from the Registry..."; udocker --allow-root pull alpine:latest; echo "Step 2: RUNNING the container securely on the GPU instance..."; udocker --allow-root run alpine:latest echo "" && echo "SUCCESS! The Alpine container ran flawlessly on the remote proxy instance via udocker!"'
    
    print("Automating manual verification of Route B (Pull & Run)...")
    stdin, stdout, stderr = ssh.exec_command(script)
    print("==== STDOUT ====")
    print(stdout.read().decode())
    
    err = stderr.read().decode()
    if err:
        print("==== STDERR ====")
        print(err)

if __name__ == "__main__":
    verify()
