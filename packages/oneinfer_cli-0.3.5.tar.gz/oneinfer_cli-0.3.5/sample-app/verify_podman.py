import paramiko

def verify():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    host = "proxy.as-in-1.gpu-instance.novita.ai"
    port = 55803
    username = "root"
    password = "ARhlNki1HoTUW4ZZX8mb"
    
    print(f"Connecting to {host}...")
    ssh.connect(host, port=port, username=username, password=password)
    
    print("Installing podman...")
    stdin, stdout, stderr = ssh.exec_command("apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y podman buildah")
    print("Install output:", stdout.read().decode()[-500:])
    
    print("Testing podman build...")
    ssh.exec_command("mkdir -p /tmp/testbuild && echo 'FROM alpine\nRUN echo hello' > /tmp/testbuild/Dockerfile")
    stdin, stdout, stderr = ssh.exec_command("cd /tmp/testbuild && podman build -t testapp .")
    out = stdout.read().decode()
    err = stderr.read().decode()
    print("Podman Build Output:", out)
    print("Podman Build Error:", err)

if __name__ == "__main__":
    verify()
