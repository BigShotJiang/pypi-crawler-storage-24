import paramiko
import time

def verify():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('proxy.as-in-1.gpu-instance.novita.ai', port=55803, username='root', password='ARhlNki1HoTUW4ZZX8mb')
    
    script = 'export PATH="/usr/local/bin/udocker-1.3.17/udocker:$PATH"; echo "=== Pulling Nginx Web Server ==="; udocker --allow-root pull nginx:alpine; echo "=== Creating Nginx Container ==="; udocker --allow-root rm client-nginx || true; udocker --allow-root create --name=client-nginx nginx:alpine; echo "=== Starting Web Server Securely on GPU Instance ==="; udocker --allow-root run --nosysdirs -p 8080:80 client-nginx > /tmp/nginx.log 2>&1 & sleep 5; echo "=== Testing Web Server with Curl ==="; curl -s http://localhost:8080 | grep "Welcome to nginx!"; echo "=== Success! The container is running and responding! ==="'
    
    print("Testing Route B (Full Server Simulation) on remote proxy...")
    stdin, stdout, stderr = ssh.exec_command(script)
    print("STDOUT:\n", stdout.read().decode())
    print("STDERR:\n", stderr.read().decode())

if __name__ == "__main__":
    verify()
