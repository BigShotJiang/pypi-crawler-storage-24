import paramiko

def verify():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('proxy.as-in-1.gpu-instance.novita.ai', port=55803, username='root', password='ARhlNki1HoTUW4ZZX8mb')
    
    script = 'export PATH="/usr/local/bin/udocker-1.3.17/udocker:$PATH"; mkdir -p /tmp/utest; cd /tmp/utest; echo "FROM alpine" > Dockerfile; echo "CMD [\\"echo\\", \\"udocker native build success!\\"]" >> Dockerfile; udocker --allow-root build -t udtest .; udocker --allow-root run udtest'
    
    print("Testing udocker build natively...")
    stdin, stdout, stderr = ssh.exec_command(script)
    print("STDOUT:\n", stdout.read().decode())
    print("STDERR:\n", stderr.read().decode())

if __name__ == "__main__":
    verify()
