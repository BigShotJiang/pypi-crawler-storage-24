import paramiko
import time

def verify():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    host = "proxy.as-in-1.gpu-instance.novita.ai"
    port = 55803
    username = "root"
    password = "ARhlNki1HoTUW4ZZX8mb"
    
    print(f"Connecting to {host}:{port} as {username}...")
    ssh.connect(host, port=port, username=username, password=password)
    print("Connected successfully!")
    
    # Run the container in the background
    print("Starting the container with udocker...")
    stdin, stdout, stderr = ssh.exec_command("nohup udocker --allow-root run -p 8080:80 sample-app:v1 > /tmp/sample_app.log 2>&1 &")
    # Wait a few seconds for nginx to start
    time.sleep(5)
    
    # Verify using curl
    print("Verifying the deployment using curl...")
    stdin, stdout, stderr = ssh.exec_command("curl -s http://localhost:8080")
    response = stdout.read().decode('utf-8')
    err = stderr.read().decode('utf-8')
    
    if "Hello from OneInfer Dev CLI!" in response:
        print("✅ Verification Successful! The app is running: " + response.strip())
    else:
        print("❌ Verification Failed.")
        print("Response:", response)
        print("Error:", err)
        
    ssh.close()

if __name__ == "__main__":
    verify()
