import os
from importlib.metadata import version as pkg_version
import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from oneinfer_cli import auth, ssh_utils, ci_templates, build_utils
import subprocess

app = typer.Typer(help="OneInfer Developer CLI: Seamlessly push and deploy Docker containers to your GPU.")
console = Console()


def _version_callback(value: bool):
    if value:
        console.print(f"oneinfer-cli v{pkg_version('oneinfer-cli')}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(None, "--version", "-v", callback=_version_callback, is_eager=True, help="Show version and exit."),
):
    pass

@app.command()
def login(
    api_key: str = typer.Option(..., prompt="OneInfer API Key", hide_input=True, help="Your OneInfer API Token"),
    developer_id: str = typer.Option(..., prompt="OneInfer Developer ID", help="Your OneInfer Developer ID")
):
    """Authenticate the CLI with your OneInfer account."""
    if auth.save_token(api_key, developer_id):
        console.print("[bold green]✅ Login successful![/bold green] Credentials saved.")
    else:
        console.print("[bold red]❌ Failed to save credentials.[/bold red]")

@app.command()
def instances():
    """List all your running GPU instances."""
    token = auth.get_token()
    if not token:
        console.print("[bold red]❌ You must be logged in. Run `oneinfer login` first.[/bold red]")
        raise typer.Exit(code=1)
        
    console.print("[bold cyan]Fetching your instances...[/bold cyan]")
    instances = auth.fetch_instances(token)
    
    if not instances:
        console.print("[yellow]No running instances found.[/yellow]")
        return
        
    from rich.table import Table
    table = Table(title="Your GPU Instances")
    table.add_column("Instance ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="magenta")
    table.add_column("State", style="green")
    table.add_column("IP Address", style="blue")
    
    for inst in instances:
        table.add_row(
            inst.get("instance_id", "Unknown"),
            inst.get("instance_name", "Unknown"),
            inst.get("status", "Unknown"),
            inst.get("ip_address", "Unknown")
        )
        
    console.print(table)
    console.print("\n[bold]To deploy an application to one of these instances, run:[/bold]")
    console.print("  [cyan]oneinfer deploy <instance_id> <local_image_name>[/cyan]")


@app.command()
def deploy(
    image: str = typer.Argument(..., help="Local Docker image tag (e.g., my-app:latest)"),
    instance_id: str = typer.Option(..., "--instance-id", "-i", help="OneInfer GPU Instance ID")
):
    """Deploy a local Docker container directly to a remote GPU Instance."""
    token = auth.get_token()
    if not token:
        console.print("[bold red]❌ You must be logged in. Run `oneinfer login` first.[/bold red]")
        raise typer.Exit(code=1)

    console.print(Panel(f"🚀 Deploying [bold cyan]{image}[/bold cyan] to instance [bold yellow]{instance_id}[/bold yellow]"))

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=False,
    ) as progress:
        
        # 1. Fetch SSH Info
        task_fetch = progress.add_task("Fetching instance credentials...", total=None)
        instance_details = auth.fetch_instance_ssh_details(token, instance_id)
        if not instance_details:
            progress.update(task_fetch, completed=True, description="[red]❌ Failed to get instance details.[/red]")
            raise typer.Exit(code=1)
        progress.update(task_fetch, completed=True, description="[green]✅ Instance reachable.[/green]")

        # 2. Export Docker Image
        task_export = progress.add_task(f"Exporting local image [bold]{image}[/bold]...", total=None)
        tar_path = ssh_utils.export_docker_image(image)
        if not tar_path:
             progress.update(task_export, completed=True, description="[red]❌ Failed to export docker image. Is Docker running?[/red]")
             raise typer.Exit(code=1)
        progress.update(task_export, completed=True, description="[green]✅ Image bundled.[/green]")

        # 3. Transfer & Load
        task_upload = progress.add_task("Uploading and loading container to GPU instance over SSH...", total=None)
        success = ssh_utils.transfer_and_load_image(
            tar_path=tar_path, 
            image_name=image,
            ssh_host=instance_details['ssh_host'],
            ssh_port=instance_details['ssh_port'],
            ssh_user=instance_details['ssh_user'],
            ssh_password=instance_details['ssh_password']
        )

        if not success:
            progress.update(task_upload, completed=True, description="[red]❌ Deployment failed.[/red]")
            raise typer.Exit(code=1)
            
        progress.update(task_upload, completed=True, description="[green]✅ Container uploaded and loaded![/green]")

    console.print("\n[bold green]🎉 Deployment Successful![/bold green]")
    console.print(f"To run your app, SSH into your instance and run:\n  > [bold cyan]udocker --allow-root run --nv {image}[/bold cyan]")


@app.command()
def init_ci(
    app_name: str = typer.Argument(..., help="Name of your app (e.g., my-app)"),
    gh_username: str = typer.Argument(..., help="GitHub Username"),
    instance_id: str = typer.Option(..., "--instance-id", "-i", help="OneInfer GPU Instance ID")
):
    """Generate a GitHub Actions workflow for zero-touch remote deployment."""
    token = auth.get_token()
    if not token:
        console.print("[bold red]❌ You must be logged in. Run `oneinfer login` first.[/bold red]")
        raise typer.Exit(code=1)
        
    instance_details = auth.fetch_instance_ssh_details(token, instance_id)
    if not instance_details:
        console.print("[bold red]❌ Failed to fetch instance SSH details.[/bold red]")
        raise typer.Exit(code=1)
        
    os.makedirs(".github/workflows", exist_ok=True)
    workflow_path = ".github/workflows/oneinfer-deploy.yml"
    
    workflow_content = ci_templates.GITHUB_ACTION_TEMPLATE.format(
        app_name=app_name, 
        github_username=gh_username
    )
    
    with open(workflow_path, "w") as f:
        f.write(workflow_content)
        
    console.print(f"[bold green]✅ Generated CI/CD Workflow at {workflow_path}[/bold green]")
    console.print(Panel(
        f"To complete setup, please go to your GitHub Repository -> Settings -> Secrets and add these 4 Repository Secrets:\n"
        f"  PROXY_SSH_HOST: {instance_details['ssh_host']}\n"
        f"  PROXY_SSH_PORT: {instance_details['ssh_port']}\n"
        f"  PROXY_SSH_USER: {instance_details['ssh_user']}\n"
        f"  PROXY_SSH_PASSWORD: {instance_details['ssh_password']}"
    ))

@app.command()
def deploy_registry(
    image: str = typer.Argument(..., help="Full registry image (e.g. ghcr.io/org/my-app:latest)"),
    instance_id: str = typer.Option(..., "--instance-id", "-i", help="OneInfer GPU Instance ID"),
    registry_user: str = typer.Option(None, "--registry-user", "-u", help="Registry username (e.g. GitHub username for ghcr.io)"),
    registry_token: str = typer.Option(None, "--registry-token", "-t", hide_input=True, help="Registry PAT / password"),
    run: bool = typer.Option(False, "--run", help="Also run the container after pulling"),
):
    """Pull a container image from a registry onto a GPU instance using udocker."""
    token = auth.get_token()
    if not token:
        console.print("[bold red]❌ You must be logged in. Run `oneinfer login` first.[/bold red]")
        raise typer.Exit(code=1)

    console.print(Panel(f"📦 Pulling [bold cyan]{image}[/bold cyan] on instance [bold yellow]{instance_id}[/bold yellow]"))

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=False) as progress:
        task_fetch = progress.add_task("Fetching instance credentials...", total=None)
        instance_details = auth.fetch_instance_ssh_details(token, instance_id)
        if not instance_details:
            progress.update(task_fetch, completed=True, description="[red]❌ Failed to get instance details.[/red]")
            raise typer.Exit(code=1)
        progress.update(task_fetch, completed=True, description="[green]✅ Instance reachable.[/green]")

        task_pull = progress.add_task("Pulling image on remote instance via udocker...", total=None)
        success = ssh_utils.pull_and_run_from_registry(
            image=image,
            ssh_host=instance_details['ssh_host'],
            ssh_port=instance_details['ssh_port'],
            ssh_user=instance_details['ssh_user'],
            ssh_password=instance_details['ssh_password'],
            registry_user=registry_user,
            registry_token=registry_token,
            run_container=run,
        )
        if not success:
            progress.update(task_pull, completed=True, description="[red]❌ Pull failed.[/red]")
            raise typer.Exit(code=1)
        progress.update(task_pull, completed=True, description="[green]✅ Image pulled successfully![/green]")

    console.print("\n[bold green]🎉 Done![/bold green]")
    if not run:
        console.print(f"To run your app, SSH into your instance and execute:\n  > [bold cyan]udocker --allow-root run --nv <container_name>[/bold cyan]")


@app.command()
def upload(
    local_path: str = typer.Argument(..., help="Local file path to upload (e.g. ./model.bin)"),
    instance_id: str = typer.Option(..., "--instance-id", "-i", help="OneInfer GPU Instance ID"),
    remote_path: str = typer.Option("/models", "--remote-path", "-r", help="Remote directory on the instance"),
):
    """Upload a large file (e.g. model weights) directly to a GPU instance over SSH."""
    token = auth.get_token()
    if not token:
        console.print("[bold red]❌ You must be logged in. Run `oneinfer login` first.[/bold red]")
        raise typer.Exit(code=1)

    instance_details = auth.fetch_instance_ssh_details(token, instance_id)
    if not instance_details:
        console.print("[bold red]❌ Failed to fetch instance details.[/bold red]")
        raise typer.Exit(code=1)

    import os
    file_size_mb = os.path.getsize(local_path) / (1024 * 1024)
    console.print(Panel(f"📤 Uploading [bold cyan]{local_path}[/bold cyan] ({file_size_mb:.1f} MB) to instance [bold yellow]{instance_id}[/bold yellow]"))

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=False) as progress:
        task = progress.add_task(f"Uploading to {remote_path} via SCP...", total=None)
        dest = ssh_utils.upload_file(
            local_path=local_path,
            remote_path=remote_path,
            ssh_host=instance_details['ssh_host'],
            ssh_port=instance_details['ssh_port'],
            ssh_user=instance_details['ssh_user'],
            ssh_password=instance_details['ssh_password'],
        )
        progress.update(task, completed=True, description=f"[green]✅ Uploaded to {dest}[/green]")

    console.print(f"\n[bold green]🎉 Done![/bold green] File available on instance at: [bold cyan]{dest}[/bold cyan]")
    console.print(f"Mount it in your container with:\n  > [bold cyan]udocker --allow-root run -v {remote_path}:{remote_path} <container>[/bold cyan]")


@app.command()
def logs(
    instance_id: str = typer.Option(..., "--instance-id", "-i", help="OneInfer GPU Instance ID"),
    log_file: str = typer.Option("/tmp/sample-app.log", "--log-file", "-l", help="Path to log file on the remote instance"),
):
    """Stream real-time container logs from a GPU instance. Press Ctrl+C to stop."""
    token = auth.get_token()
    if not token:
        console.print("[bold red]❌ You must be logged in. Run `oneinfer login` first.[/bold red]")
        raise typer.Exit(code=1)

    instance_details = auth.fetch_instance_ssh_details(token, instance_id)
    if not instance_details:
        console.print("[bold red]❌ Failed to fetch instance details.[/bold red]")
        raise typer.Exit(code=1)

    console.print(f"[bold cyan]Streaming logs from {log_file} on instance {instance_id}[/bold cyan] (Ctrl+C to stop)\n")
    ssh_utils.stream_container_logs(
        ssh_host=instance_details['ssh_host'],
        ssh_port=instance_details['ssh_port'],
        ssh_user=instance_details['ssh_user'],
        ssh_password=instance_details['ssh_password'],
        log_file=log_file,
    )


@app.command()
def deploy_remote():
    """Immediately trigger a cloud build and remote deployment by pushing to GitHub."""
    console.print("[bold cyan]Pushing latest code to GitHub to trigger automated UI/CD deployment...[/bold cyan]")
    try:
        subprocess.run(["git", "add", "."], check=True)
        # Catch errors if there's nothing to commit
        subprocess.run(["git", "commit", "-m", "Trigger OneInfer Remote Deploy"], check=False)
        subprocess.run(["git", "push"], check=True)
        console.print("[bold green]✅ Code pushed! GitHub Actions will now build your image and deploy it directly to the remote GPU instance.[/bold green]")
    except Exception as e:
        console.print(f"[bold red]❌ Git operation failed: {e}[/bold red]")
        raise typer.Exit(code=1)


@app.command()
def push(
    local_path: str = typer.Argument(".", help="Local project directory to build and deploy"),
    instance_id: str = typer.Option(..., "--instance-id", "-i", help="OneInfer GPU Instance ID to deploy to"),
    registry_user: str = typer.Option(..., "--registry-user", "-u", prompt="GHCR Username", help="GitHub username (used as ghcr.io/<user>/<app>:latest)"),
    registry_token: str = typer.Option(..., "--registry-token", "-t", prompt="GHCR Token", hide_input=True, help="GitHub PAT with packages:write scope"),
    run: bool = typer.Option(False, "--run", help="Also run the container on the GPU instance after deploying"),
):
    """Build your local repo on a cloud VM and deploy it to a GPU instance.

    Spins up a Novita build VM, transfers your code (including model weights),
    builds the Docker image there, pushes it to ghcr.io, deploys it to
    your GPU instance via udocker, then tears down the build VM.
    """
    import os as _os
    token = auth.get_token()
    if not token:
        console.print("[bold red]❌ You must be logged in. Run `oneinfer login` first.[/bold red]")
        raise typer.Exit(code=1)

    app_name = _os.path.basename(_os.path.abspath(local_path)).lower().replace(" ", "-")
    image = f"ghcr.io/{registry_user}/{app_name}:latest"

    console.print(Panel(
        f"🏗️  Building [bold cyan]{image}[/bold cyan] from [bold]{local_path}[/bold]\n"
        f"   Deploying to GPU instance [bold yellow]{instance_id}[/bold yellow]"
    ))

    build_vm_id = None

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=False) as progress:

        # 1. Provision build VM
        task = progress.add_task("Provisioning Nebius build VM...", total=None)
        build_vm_info = auth.create_build_vm(token)
        if not build_vm_info:
            progress.update(task, description="[red]❌ Failed to provision build VM.[/red]")
            raise typer.Exit(code=1)

        build_vm_id = build_vm_info.get("instance_id")
        build_vm_user = build_vm_info.get("ssh_user", "ubuntu")
        build_vm_password = build_vm_info.get("ssh_password")
        progress.update(task, description=f"[green]✅ Build VM provisioned (id: {build_vm_id}).[/green]")

        # 1b. Poll until VM status is 'running' and IP is available
        task_poll = progress.add_task("Waiting for VM to come online...", total=None)

        def _on_vm_status(status):
            progress.update(task_poll, description=f"⏳ VM status: [bold]{status}[/bold] (waiting for 'running'...)")

        build_ssh_info = auth.poll_build_vm_ssh(token, build_vm_id, on_status=_on_vm_status)
        if not build_ssh_info:
            progress.update(task_poll, description="[red]❌ VM did not reach 'running' state in time.[/red]")
            auth.destroy_build_vm(token, build_vm_id)
            raise typer.Exit(code=1)

        build_ssh = {
            "ssh_host": build_ssh_info["ssh_host"],
            "ssh_port": build_ssh_info["ssh_port"],
            "ssh_user": build_vm_user,
            "ssh_password": build_vm_password,
        }
        progress.update(task_poll, description=f"[green]✅ VM running ({build_ssh['ssh_host']}).[/green]")

        # 2b. Wait for SSH port to actually accept connections
        task_ssh = progress.add_task("Waiting for SSH to be ready...", total=None)

        def _on_ssh_attempt(attempt, elapsed):
            progress.update(task_ssh, description=f"⏳ SSH not ready yet... ({elapsed}s elapsed)")

        if not build_utils.wait_for_ssh(**build_ssh, on_attempt=_on_ssh_attempt):
            progress.update(task_ssh, description="[red]❌ SSH timed out.[/red]")
            auth.destroy_build_vm(token, build_vm_id)
            raise typer.Exit(code=1)
        progress.update(task_ssh, description="[green]✅ SSH port open.[/green]")

        # 2c. Wait for startup script to enable password auth
        task_auth = progress.add_task("Waiting for VM startup script to complete...", total=None)

        def _on_auth_attempt(attempt, elapsed):
            progress.update(task_auth, description=f"⏳ Startup script running... ({elapsed}s elapsed)")

        if not build_utils.wait_for_password_auth(**build_ssh, on_attempt=_on_auth_attempt):
            progress.update(task_auth, description="[red]❌ Could not authenticate — startup script may have failed.[/red]")
            auth.destroy_build_vm(token, build_vm_id)
            raise typer.Exit(code=1)
        progress.update(task_auth, description="[green]✅ VM ready.[/green]")

        # 3. Ensure Docker is installed on build VM
        task_docker = progress.add_task("Setting up Docker on build VM...", total=None)

        def _on_docker_step(msg):
            progress.update(task_docker, description=f"🐳 {msg}")

        if not build_utils.ensure_docker(**build_ssh, on_step=_on_docker_step):
            progress.update(task_docker, description="[red]❌ Docker setup failed on build VM.[/red]")
            auth.destroy_build_vm(token, build_vm_id)
            raise typer.Exit(code=1)
        progress.update(task_docker, description="[green]✅ Docker ready.[/green]")

        # 4. Transfer local repo to build VM
        task = progress.add_task(f"Transferring [bold]{local_path}[/bold] to build VM...", total=None)
        transferred = build_utils.transfer_repo(local_path=local_path, **build_ssh)
        if not transferred:
            progress.update(task, description="[red]❌ Failed to transfer repo.[/red]")
            auth.destroy_build_vm(token, build_vm_id)
            raise typer.Exit(code=1)
        progress.update(task, description="[green]✅ Codebase transferred.[/green]")

    # 5. Build + push (shown outside progress bar so streaming output is visible)
    console.print("\n[bold cyan]Building and pushing image...[/bold cyan]")
    success = build_utils.build_and_push_image(
        image=image,
        remote_dir="/home/ubuntu/build",
        registry_user=registry_user,
        registry_token=registry_token,
        **build_ssh,
    )

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=False) as progress:
        if not success:
            progress.add_task("[red]❌ Build or push failed.[/red]", total=None)
            auth.destroy_build_vm(token, build_vm_id)
            raise typer.Exit(code=1)

        # 6. Deploy to GPU instance via udocker
        task = progress.add_task("Fetching GPU instance credentials...", total=None)
        instance_details = auth.fetch_instance_ssh_details(token, instance_id)
        if not instance_details:
            progress.update(task, description="[red]❌ Failed to get GPU instance details.[/red]")
            auth.destroy_build_vm(token, build_vm_id)
            raise typer.Exit(code=1)
        progress.update(task, description="[green]✅ GPU instance reachable.[/green]")

        task = progress.add_task("Deploying image to GPU instance via udocker...", total=None)
        deployed = ssh_utils.pull_and_run_from_registry(
            image=image,
            ssh_host=instance_details["ssh_host"],
            ssh_port=instance_details["ssh_port"],
            ssh_user=instance_details["ssh_user"],
            ssh_password=instance_details["ssh_password"],
            registry_user=registry_user,
            registry_token=registry_token,
            run_container=run,
        )
        if not deployed:
            progress.update(task, description="[red]❌ Deployment failed.[/red]")
            auth.destroy_build_vm(token, build_vm_id)
            raise typer.Exit(code=1)
        progress.update(task, description="[green]✅ Image deployed to GPU instance![/green]")

        # 7. Tear down build VM
        task = progress.add_task("Tearing down build VM...", total=None)
        auth.destroy_build_vm(token, build_vm_id)
        progress.update(task, description="[green]✅ Build VM terminated.[/green]")

    console.print("\n[bold green]🎉 Done![/bold green]")
    if not run:
        console.print(
            f"To run your app, SSH into the GPU instance and execute:\n"
            f"  > [bold cyan]udocker --allow-root run --name {app_name} {image}[/bold cyan]"
        )


if __name__ == "__main__":
    app()
