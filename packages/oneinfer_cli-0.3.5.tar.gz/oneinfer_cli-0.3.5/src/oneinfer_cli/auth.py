import json
import os
import requests
from pathlib import Path

CONFIG_DIR = Path.home() / ".oneinfer"
CONFIG_FILE = CONFIG_DIR / "config.json"
API_BASE_URL = "https://api.oneinfer.com/v1"  # Production URL or Staging URL

def save_token(token: str, developer_id: str = None) -> bool:
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        config = {}
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
        
        config["api_key"] = token
        if developer_id:
            config["developer_id"] = developer_id
        
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f)
        
        # Secure the file (Unix only)
        if os.name != 'nt':
            os.chmod(CONFIG_FILE, 0o600)
            
        return True
    except Exception as e:
        print(f"Error saving config: {e}")
        return False

def get_token() -> str:
    try:
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
                return config.get("api_key")
        return os.environ.get("ONEINFER_API_KEY") # Fallback to ENV Var
    except Exception:
        return None

def get_developer_id() -> str:
    try:
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
                return config.get("developer_id")
        return os.environ.get("ONEINFER_DEVELOPER_ID")
    except Exception:
        return None

def fetch_instance_ssh_details(token: str, instance_id: str):
    """Hits the API to retrieve SSH host, port, password for a specific instance."""
    instances = fetch_instances(token)
    
    for inst in instances:
        if inst.get("instance_id") == instance_id:
            # Parse ssh_command (e.g., "ssh root@12.34.56.78 -p 22000")
            ssh_command = inst.get("ssh_command", "")
            ssh_user = "root"  # Default fallback
            ssh_host = ""
            ssh_port = 22
            
            # Simple parsing. In a robust setup, backend should return raw host/port
            parts = ssh_command.split()
            for i, part in enumerate(parts):
                if "@" in part:
                    ssh_user = part.split("@")[0]
                    ssh_host = part.split("@")[-1]
                elif part == "-p" and i + 1 < len(parts):
                    ssh_port = int(parts[i+1])
            
            # Fallback to ip_address field if host parsing failed
            if not ssh_host:
                ssh_host = inst.get("ip_address", "")
                
            # Runpod might have ssh_port explicitly
            if inst.get("ssh_port"):
                ssh_port = int(inst.get("ssh_port"))

            return {
                "ssh_user": ssh_user,
                "ssh_host": ssh_host,
                "ssh_port": ssh_port,
                "ssh_password": inst.get("ssh_password", "")
            }
            
    print(f"Instance {instance_id} not found or no SSH details available.")
    return None

def get_base_url() -> str:
    env = os.environ.get("ONEINFER_ENV", "prod").lower()
    if env == "local":
        return "http://127.0.0.1:8000/v1"
    elif env == "staging":
        return "https://staging-api.oneinfer.ai/v1"
    else:
        return "https://api.oneinfer.ai/v1"

def get_jwt_access_token(api_key: str) -> str:
    """Exchanges the opaque API Key for a short-lived ULA JWT access token (is_ula=True)."""
    base_url = get_base_url()
    try:
        url = f"{base_url}/ula/oauth-authentication?api_key={api_key}"
        response = requests.post(url)
        response.raise_for_status()
        data = response.json()
        
        access_token = data.get("data", {}).get("access_token")
        if not access_token:
            print(f"Failed to extract access_token from oauth response. Response: {data}")
            return None
            
        return access_token
    except Exception as e:
        print(f"Authentication Error: {e}")
        return None

def get_cli_jwt_access_token(api_key: str) -> str:
    """Exchanges the opaque API Key for a short-lived non-ULA JWT (is_ula=False).
    Use this for standard developer endpoints like create-instance."""
    base_url = get_base_url()
    try:
        url = f"{base_url}/ula/cli-authentication?api_key={api_key}"
        response = requests.post(url)
        response.raise_for_status()
        data = response.json()

        access_token = data.get("data", {}).get("access_token")
        if not access_token:
            print(f"Failed to extract access_token from cli-authentication response. Response: {data}")
            return None

        return access_token
    except Exception as e:
        print(f"CLI Authentication Error: {e}")
        return None

def create_build_vm(token: str, instance_name: str = None) -> dict:
    """Provision a Nebius build VM via the OneInfer backend API.

    Generates a random SSH password, injects it via startup script so the
    CLI can connect with password auth (disabled by default on Ubuntu cloud images).
    Returns instance_id plus the generated ssh_user/ssh_password.
    """
    import secrets
    import time as _time
    base_url = get_base_url()
    developer_id = get_developer_id()

    access_token = get_cli_jwt_access_token(token)
    if not access_token:
        print("Could not retrieve CLI JWT access token.")
        return None

    headers = {"Authorization": f"Bearer {access_token}"}

    if not instance_name:
        instance_name = f"oneinfer-build-{int(_time.time())}"

    ssh_password = secrets.token_urlsafe(16)

    startup_script = " && ".join([
        # Enable password auth (Ubuntu 22.04 cloud images disable it by default)
        f"echo 'ubuntu:{ssh_password}' | chpasswd",
        "echo 'PasswordAuthentication yes' > /etc/ssh/sshd_config.d/60-cloudimg-settings.conf",
        "systemctl restart ssh",
        # Install Docker
        "apt-get update -qq",
        "apt-get install -y -qq docker.io",
        "systemctl enable docker",
        "systemctl start docker",
    ])

    payload = {
        "provider_name": "nebius_ai",
        "instance_name": instance_name,
        "gpu_id": "",
        "gpu_num": 1,
        "disk_size": 60,
        "image_url": "ubuntu22.04",
        "region": "eu-north1",
        "additional_volume_size": 0,
        "volume_name": "",
        "volume_region": "eu-north1",
        "vcpu": 0,
        "startup_script": startup_script,
    }

    try:
        url = f"{base_url}/developer/{developer_id}/create-instance"
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json().get("data", {})
        instance = data.get("instance", data)
        return {
            "instance_id": instance.get("instance_id"),
            "ssh_user": "ubuntu",
            "ssh_password": ssh_password,
        }
    except Exception as e:
        print(f"Failed to create build VM: {e}")
        return None


def destroy_build_vm(token: str, instance_id: str, provider: str = "nebius_ai") -> bool:
    """Terminate a build VM via the OneInfer backend API."""
    base_url = get_base_url()
    access_token = get_cli_jwt_access_token(token)
    if not access_token:
        return False

    developer_id = get_developer_id()
    headers = {"Authorization": f"Bearer {access_token}"}

    try:
        url = f"{base_url}/developer/{developer_id}/delete-instance"
        response = requests.delete(url, headers=headers, params={"instance_id": instance_id, "provider": provider})
        response.raise_for_status()
        return True
    except Exception as e:
        print(f"Failed to destroy build VM: {e}")
        return False


def fetch_build_vm_details(token: str, instance_id: str) -> dict:
    """Fetch a single Nebius build VM's status + SSH details."""
    base_url = get_base_url()
    access_token = get_cli_jwt_access_token(token)
    if not access_token:
        return None

    developer_id = get_developer_id()
    headers = {"Authorization": f"Bearer {access_token}"}

    try:
        url = f"{base_url}/developer/{developer_id}/get-instance"
        response = requests.get(url, headers=headers, params={
            "instance_id": instance_id,
            "provider_name": "nebius_ai",
        })
        response.raise_for_status()
        inst = response.json().get("data", {}) or {}

        status = inst.get("status") or inst.get("instance_status", "unknown")

        ssh_command = inst.get("ssh_command", "")
        ssh_host = inst.get("ip_address", "")
        ssh_port = 22
        ssh_user = "root"
        parts = ssh_command.split()
        for i, part in enumerate(parts):
            if "@" in part:
                ssh_user = part.split("@")[0]
                ssh_host = part.split("@")[-1]
            elif part == "-p" and i + 1 < len(parts):
                ssh_port = int(parts[i + 1])
        if inst.get("ssh_port"):
            ssh_port = int(inst.get("ssh_port"))

        return {
            "status": status,
            "ssh_host": ssh_host,
            "ssh_port": ssh_port,
            "ssh_user": ssh_user,
            "ssh_password": inst.get("ssh_password", ""),
        }
    except Exception:
        return None


def poll_build_vm_ssh(token: str, instance_id: str, timeout: int = 600, on_status=None) -> dict:
    """Poll get-instance until status is 'running', then return SSH details."""
    import time as _time
    deadline = _time.time() + timeout
    while _time.time() < deadline:
        info = fetch_build_vm_details(token, instance_id)
        status = (info or {}).get("status", "unknown")
        if on_status:
            on_status(status)
        if status == "running" and info.get("ssh_host"):
            return info
        _time.sleep(10)
    return None


def fetch_instances(token: str):
    """Hits the backend API to retrieve all instances for the user."""
    base_url = get_base_url()
    
    # We must exchange the permanent API Key for a JWT access token first
    access_token = get_jwt_access_token(token)
    if not access_token:
        print("Could not retrieve JWT access token.")
        return []
        
    headers = {"Authorization": f"Bearer {access_token}"}
    
    developer_id = get_developer_id()
    if not developer_id:
        # Fallback for JWT tokens if available, or just fallback to token
        developer_id = token  
    
    try:
        url = f"{base_url}/ula/developer/{developer_id}/get-instances?provider_name=all"
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        
        # The backend wraps response in dataResponse
        instances = data.get("data", [])
        # Sometimes standardizing wrapper returns data.get("data").get("dataResponse", []) or just data.get("data", [])
        # Let's check both patterns just in case.
        if isinstance(instances, dict) and "dataResponse" in instances:
            instances = instances["dataResponse"]
        elif instances is None:
            instances = []
        
        return instances
    except Exception as e:
        print(f"API Error fetching instances: {e}")
        return []
