import subprocess
import os
import paramiko
from scp import SCPClient

def stream_container_logs(
    ssh_host: str,
    ssh_port: int,
    ssh_user: str,
    ssh_password: str,
    log_file: str = "/tmp/sample-app.log",
):
    """Stream all container logs in real-time from the remote instance."""
    ssh = create_ssh_client(ssh_host, ssh_port, ssh_user, ssh_password)
    try:
        channel = ssh.get_transport().open_session()
        channel.exec_command(f"tail -f {log_file}")
        channel.setblocking(False)
        NOISE_PATTERNS = (
            "prctl(PR_SET_DUMPABLE)",
            "signal 15 (SIGTERM)",
            "signal 14 (SIGALRM)",
            "signal 17 (SIGCHLD)",
            "signal 29 (SIGIO)",
            "exiting",
            ": exit",
            "worker process",
        )

        def _filter(line: str) -> bool:
            return not any(p in line for p in NOISE_PATTERNS)

        buf = ""
        while True:
            try:
                if channel.recv_ready():
                    buf += channel.recv(4096).decode(errors="replace")
                    while "\n" in buf:
                        line, buf = buf.split("\n", 1)
                        if _filter(line):
                            print(line, flush=True)
                if channel.recv_stderr_ready():
                    data = channel.recv_stderr(4096).decode(errors="replace")
                    for line in data.splitlines():
                        if _filter(line):
                            print(line, flush=True)
                if channel.exit_status_ready():
                    break
            except Exception:
                import time
                time.sleep(0.1)
    except KeyboardInterrupt:
        pass
    finally:
        channel.close()
        ssh.close()


def export_docker_image(image_name: str, output_tar: str = "image.tar") -> str:
    """Exports a local Docker image to a tarball."""
    print(f"Exporting local Docker image '{image_name}'...")
    try:
        # We can pipe through gzip later, but tar is simpler to demonstrate
        result = subprocess.run(
            ["docker", "save", "-o", output_tar, image_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        if result.returncode != 0:
            print(f"Docker save failed: {result.stderr}")
            return None
        return output_tar
    except Exception as e:
        print(f"Failed to find or run docker: {e}")
        return None

def create_ssh_client(server, port, user, password):
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(server, port=port, username=user, password=password)
    return client

def upload_file(
    local_path: str,
    remote_path: str,
    ssh_host: str,
    ssh_port: int,
    ssh_user: str,
    ssh_password: str,
):
    """SCP a local file to a remote path on the instance."""
    import os
    from scp import SCPClient

    ssh = create_ssh_client(ssh_host, ssh_port, ssh_user, ssh_password)
    try:
        ssh.exec_command(f"mkdir -p {remote_path}")
        filename = os.path.basename(local_path)
        dest = f"{remote_path}/{filename}"
        print(f"Uploading {local_path} → {dest} ...")
        with SCPClient(ssh.get_transport(), socket_timeout=600.0) as scp:
            scp.put(local_path, dest)
        return dest
    finally:
        ssh.close()


def pull_and_run_from_registry(
    image: str,
    ssh_host: str,
    ssh_port: int,
    ssh_user: str,
    ssh_password: str,
    registry_user: str = None,
    registry_token: str = None,
    run_container: bool = False,
) -> bool:
    """Authenticates udocker with a registry, pulls the image, and optionally runs it."""
    ssh = None
    try:
        ssh = create_ssh_client(ssh_host, ssh_port, ssh_user, ssh_password)
        udocker = "export PATH=/usr/local/bin/udocker-1.3.17/udocker:$PATH && udocker --allow-root"

        # Derive registry hostname from image (e.g. ghcr.io/org/app -> ghcr.io)
        registry = image.split("/")[0] if "/" in image else "docker.io"

        if registry_user and registry_token:
            login_cmd = f"{udocker} login --username={registry_user} --password={registry_token} --registry={registry}"
            stdin, stdout, stderr = ssh.exec_command(login_cmd)
            exit_status = stdout.channel.recv_exit_status()
            if exit_status != 0:
                print(f"Registry login failed: {stderr.read().decode()}")
                return False

        # Skip pull if image already exists locally
        check_cmd = f"{udocker} images 2>/dev/null | grep -F '{image}'"
        stdin, stdout, _ = ssh.exec_command(check_cmd)
        already_present = bool(stdout.read().decode().strip())

        if not already_present:
            pull_cmd = f"{udocker} pull {image}"
            stdin, stdout, stderr = ssh.exec_command(pull_cmd, timeout=300)
            exit_status = stdout.channel.recv_exit_status()
            out = stdout.read().decode()
            err = stderr.read().decode()
            print(out)
            if exit_status != 0:
                print(f"udocker pull failed: {err}")
                return False

        if run_container:
            container_name = image.replace("/", "-").replace(":", "-")
            run_cmd = (
                f"{udocker} rm {container_name} 2>/dev/null; "
                f"{udocker} create --name={container_name} {image} && "
                f"{udocker} run {container_name}"
            )
            stdin, stdout, stderr = ssh.exec_command(run_cmd, timeout=60)
            print(stdout.read().decode())

        return True
    except Exception as e:
        print(f"SSH operation failed: {e}")
        return False
    finally:
        if ssh:
            ssh.close()


def transfer_and_load_image(tar_path: str, image_name: str, ssh_host: str, ssh_port: int, ssh_user: str, ssh_password: str) -> bool:
    """Uploads the tarball over SSH and loads it using udocker on the remote instance."""
    ssh = None
    try:
        ssh = create_ssh_client(ssh_host, ssh_port, ssh_user, ssh_password)
        
        # 1. SCP Upload
        print(f"Uploading {tar_path} to {ssh_user}@{ssh_host}:{ssh_port} via SCP...")
        with SCPClient(ssh.get_transport(), socket_timeout=600.0) as scp:
            scp.put(tar_path, f"/tmp/{tar_path}")
            
        print("Upload complete. Loading image into remote user-space registry (udocker)...")
        
        # 2. Remote Udocker Load
        # udocker command is pre-installed via the OneInfer startup_script injected during create-instance
        udocker_cmd = f"export PATH=/usr/local/bin/udocker-1.3.17/udocker:$PATH; udocker --allow-root load -i /tmp/{tar_path}"
        stdin, stdout, stderr = ssh.exec_command(udocker_cmd)
        
        # Wait for command to finish
        exit_status = stdout.channel.recv_exit_status()
        if exit_status != 0:
            err = stderr.read().decode('utf-8')
            print(f"Remote udocker load failed: {err}")
            return False
            
        # 3. Clean up remote tarball
        ssh.exec_command(f"rm /tmp/{tar_path}")
        
        # Clean up local tarball
        if os.path.exists(tar_path):
            os.remove(tar_path)
            
        return True
    except Exception as e:
        print(f"SSH/Transfer failed: {e}")
        return False
    finally:
        if ssh:
            ssh.close()
