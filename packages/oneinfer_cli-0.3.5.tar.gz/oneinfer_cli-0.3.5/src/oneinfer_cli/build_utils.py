import os
import tarfile
import tempfile
import time

import paramiko
from scp import SCPClient

from oneinfer_cli.ssh_utils import create_ssh_client

EXCLUDE_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", ".env", "dist", "build", ".mypy_cache"}
EXCLUDE_EXTS = {".pyc", ".pyo"}


def create_repo_tarball(local_path: str) -> str:
    """Pack the local repo into a .tar.gz, excluding common junk."""
    tmp = tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False)
    tmp.close()

    local_path = os.path.abspath(local_path)

    def _exclude(tarinfo):
        name = os.path.basename(tarinfo.name)
        if name in EXCLUDE_DIRS:
            return None
        if os.path.splitext(name)[1] in EXCLUDE_EXTS:
            return None
        return tarinfo

    with tarfile.open(tmp.name, "w:gz") as tar:
        tar.add(local_path, arcname="repo", filter=_exclude)

    return tmp.name


def wait_for_ssh(
    ssh_host: str,
    ssh_port: int,
    ssh_user: str = None,
    ssh_password: str = None,
    timeout: int = 600,
    on_attempt=None,
) -> bool:
    """Poll until SSH port accepts TCP connections (no auth attempt)."""
    import socket
    deadline = time.time() + timeout
    attempt = 0
    while time.time() < deadline:
        attempt += 1
        elapsed = int(time.time() - (deadline - timeout))
        try:
            sock = socket.create_connection((ssh_host, ssh_port), timeout=5)
            sock.close()
            return True
        except Exception:
            if on_attempt:
                on_attempt(attempt, elapsed)
            time.sleep(5)
    return False


def stream_startup_logs(
    ssh_host: str,
    ssh_port: int,
    ssh_user: str,
    ssh_password: str,
    timeout: int = 120,
):
    """Stream cloud-init / startup script logs from the build VM."""
    print("\n[Build VM] Streaming startup logs (cloud-init):\n")
    ssh = create_ssh_client(ssh_host, ssh_port, ssh_user, ssh_password)
    try:
        transport = ssh.get_transport()
        channel = transport.open_session()
        # Follow cloud-init output log until it finishes
        channel.exec_command(
            f"timeout {timeout} tail -f /var/log/cloud-init-output.log 2>/dev/null || "
            f"timeout {timeout} journalctl -u cloud-final -f --no-pager 2>/dev/null || "
            "echo '[Build VM] No startup log available.'"
        )
        channel.setblocking(False)
        deadline = time.time() + timeout
        buf = ""
        while time.time() < deadline:
            try:
                if channel.recv_ready():
                    buf += channel.recv(4096).decode(errors="replace")
                    while "\n" in buf:
                        line, buf = buf.split("\n", 1)
                        print(f"  {line}", flush=True)
                if channel.exit_status_ready():
                    break
            except Exception:
                time.sleep(0.1)
    finally:
        channel.close()
        ssh.close()


def wait_for_password_auth(
    ssh_host: str,
    ssh_port: int,
    ssh_user: str,
    ssh_password: str,
    timeout: int = 300,
    on_attempt=None,
) -> bool:
    """Retry SSH password auth until it succeeds — startup script may take time to enable it."""
    deadline = time.time() + timeout
    attempt = 0
    while time.time() < deadline:
        attempt += 1
        elapsed = int(time.time() - (deadline - timeout))
        try:
            ssh = create_ssh_client(ssh_host, ssh_port, ssh_user, ssh_password)
            ssh.close()
            return True
        except Exception as e:
            if on_attempt:
                on_attempt(attempt, elapsed)
            time.sleep(10)
    return False


def ensure_docker(
    ssh_host: str,
    ssh_port: int,
    ssh_user: str,
    ssh_password: str,
    on_step=None,
) -> bool:
    """Install Docker on the build VM, streaming progress via on_step(msg) callback."""
    ssh = create_ssh_client(ssh_host, ssh_port, ssh_user, ssh_password)
    try:
        _, stdout, _ = ssh.exec_command("sudo docker --version 2>/dev/null")
        if stdout.channel.recv_exit_status() == 0:
            if on_step:
                on_step("Docker already installed.")
            return True

        steps = [
            ("Updating package index...",  "sudo apt-get update -qq"),
            ("Installing Docker...",       "sudo apt-get install -y -qq docker.io"),
            ("Starting Docker service...", "sudo systemctl start docker && sudo systemctl enable docker"),
        ]
        for msg, cmd in steps:
            if on_step:
                on_step(msg)
            _, stdout, stderr = ssh.exec_command(cmd, timeout=180)
            if stdout.channel.recv_exit_status() != 0:
                print(f"\nFailed at '{msg}': {stderr.read().decode()}")
                return False

        return True
    finally:
        ssh.close()


def transfer_repo(
    local_path: str,
    ssh_host: str,
    ssh_port: int,
    ssh_user: str,
    ssh_password: str,
    remote_dir: str = "/home/ubuntu/build",
) -> bool:
    """Tar the local repo and SCP it to the build VM, then extract it."""
    tar_path = create_repo_tarball(local_path)
    ssh = create_ssh_client(ssh_host, ssh_port, ssh_user, ssh_password)
    try:
        remote_tar = "/tmp/repo.tar.gz"
        with SCPClient(ssh.get_transport(), socket_timeout=600.0) as scp:
            scp.put(tar_path, remote_tar)

        _, stdout, stderr = ssh.exec_command(
            f"rm -rf {remote_dir} && mkdir -p {remote_dir} && "
            f"tar xzf {remote_tar} -C {remote_dir} --strip-components=1"
        )
        exit_status = stdout.channel.recv_exit_status()
        if exit_status != 0:
            print(f"Failed to extract repo: {stderr.read().decode()}")
            return False

        ssh.exec_command(f"rm {remote_tar}")
        return True
    finally:
        os.unlink(tar_path)
        ssh.close()


def _stream_channel(channel) -> int:
    """Read stdout/stderr from a paramiko channel and print in real time."""
    channel.setblocking(False)
    buf = ""
    while True:
        try:
            if channel.recv_ready():
                buf += channel.recv(4096).decode(errors="replace")
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    print(line, flush=True)
            if channel.recv_stderr_ready():
                data = channel.recv_stderr(4096).decode(errors="replace")
                for line in data.splitlines():
                    print(line, flush=True)
            if channel.exit_status_ready():
                break
        except Exception:
            time.sleep(0.05)
    # Drain any remaining buffered output after exit
    while channel.recv_ready():
        buf += channel.recv(4096).decode(errors="replace")
    while "\n" in buf:
        line, buf = buf.split("\n", 1)
        print(line, flush=True)
    if buf:
        print(buf, flush=True)
    while channel.recv_stderr_ready():
        data = channel.recv_stderr(4096).decode(errors="replace")
        for line in data.splitlines():
            print(line, flush=True)
    return channel.recv_exit_status()


def build_and_push_image(
    image: str,
    remote_dir: str,
    ssh_host: str,
    ssh_port: int,
    ssh_user: str,
    ssh_password: str,
    registry_user: str = None,
    registry_token: str = None,
) -> bool:
    """Run docker build + docker push on the remote build VM, streaming output."""
    ssh = create_ssh_client(ssh_host, ssh_port, ssh_user, ssh_password)
    try:
        # Derive registry host from image (e.g. ghcr.io/org/app -> ghcr.io)
        registry_host = image.split("/")[0] if "/" in image else "docker.io"

        if registry_user and registry_token:
            login_cmd = f"echo '{registry_token}' | sudo docker login {registry_host} -u {registry_user} --password-stdin"
            _, stdout, stderr = ssh.exec_command(login_cmd)
            if stdout.channel.recv_exit_status() != 0:
                print(f"Registry login failed: {stderr.read().decode()}")
                return False

        print(f"\n--- docker build ---")
        transport = ssh.get_transport()
        channel = transport.open_session()
        channel.exec_command(f"cd {remote_dir} && sudo docker build -t {image} .")
        if _stream_channel(channel) != 0:
            print("docker build failed.")
            return False

        print(f"\n--- docker push ---")
        channel = transport.open_session()
        channel.exec_command(f"sudo docker push {image}")
        if _stream_channel(channel) != 0:
            print("docker push failed.")
            return False

        return True
    finally:
        ssh.close()
