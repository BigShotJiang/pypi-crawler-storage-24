GITHUB_ACTION_TEMPLATE = """name: OneInfer Remote Deploy

on:
  push:
    branches: [ "main", "master" ]
  workflow_dispatch:

env:
  REGISTRY: ghcr.io
  IMAGE_NAME: ghcr.io/{github_username}/{app_name}

jobs:
  build-push-deploy:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      packages: write

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Log in to GitHub Container Registry
        uses: docker/login-action@v3
        with:
          registry: ${{{{ env.REGISTRY }}}}
          username: ${{{{ github.actor }}}}
          password: ${{{{ secrets.GITHUB_TOKEN }}}} # Automatically provided by GitHub!

      - name: Extract metadata
        id: meta
        uses: docker/metadata-action@v5
        with:
          images: ${{{{ env.IMAGE_NAME }}}}
          tags: type=raw,value=latest

      - name: Build and push Docker image
        id: build
        uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: ${{{{ steps.meta.outputs.tags }}}}
          labels: ${{{{ steps.meta.outputs.labels }}}}

      - name: Deploy to GPU Instance via SSH
        uses: appleboy/ssh-action@v1.0.3
        with:
          host: ${{{{ secrets.PROXY_SSH_HOST }}}}
          port: ${{{{ secrets.PROXY_SSH_PORT }}}}
          username: ${{{{ secrets.PROXY_SSH_USER }}}}
          password: ${{{{ secrets.PROXY_SSH_PASSWORD }}}}
          script: |
            export PATH=/usr/local/bin/udocker-1.3.17/udocker:$PATH
            
            echo "Pulling latest image..."
            udocker --allow-root pull ${{{{ env.IMAGE_NAME }}}}:latest
            
            echo "Stopping old container..."
            udocker --allow-root rm {app_name} || true
            
            echo "Creating new container..."
            udocker --allow-root create --name={app_name} ${{{{ env.IMAGE_NAME }}}}:latest
            
            echo "Running new container safely on GPU..."
            udocker --allow-root run -d --nosysdirs --nv {app_name}
"""
