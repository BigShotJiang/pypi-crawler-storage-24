"""bi - Project LLM."""

__version__ = "0.0.1"
