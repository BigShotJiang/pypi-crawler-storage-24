# dooplex

Official Python SDK for sending messages via the Dooplex API.

## Install

```bash
pip install dooplex
```

## Quickstart

```python
from dooplex import DooplexClient

client = DooplexClient(api_key="your-dooplex-api-key")

client.send_message(
    bot_id="00000000-0000-0000-0000-000000000000",
    channel_id="@your_channel",
    text="Hello from dooplex Python SDK",
    parse_mode="Markdown",
)
```

You can also use `DOOPLEX_API_KEY`:

```python
import os
from dooplex import DooplexClient

os.environ["DOOPLEX_API_KEY"] = "your-dooplex-api-key"
client = DooplexClient()
```
