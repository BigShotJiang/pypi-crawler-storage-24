from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Dict, Optional
from urllib import error, request

from .exceptions import DooplexAPIError, DooplexError

_API_BASE_URL = "https://dooplex-api.kluglabs.net"


@dataclass(frozen=True)
class DooplexResponse:
    ok: bool
    raw: Dict[str, Any]


class DooplexClient:
    """Minimal client for the Dooplex REST API."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        timeout: float = 10.0,
    ) -> None:
        resolved_api_key = (api_key or os.getenv("DOOPLEX_API_KEY", "")).strip()
        if not resolved_api_key:
            raise DooplexError("Missing API key. Provide `api_key` or set DOOPLEX_API_KEY.")

        self._api_key = resolved_api_key
        self._timeout = timeout

    def send_message(
        self,
        *,
        bot_id: str,
        channel_id: str,
        text: str,
        parse_mode: str = "",
    ) -> DooplexResponse:
        """
        Send a message through Dooplex.

        Maps to POST /api/v1/messages/send.
        """
        payload = {
            "bot_id": bot_id,
            "channel_id": channel_id,
            "text": text,
            "parse_mode": parse_mode,
        }
        data = json.dumps(payload).encode("utf-8")
        req = request.Request(
            url=f"{_API_BASE_URL}/api/v1/messages/send",
            data=data,
            headers={
                "Content-Type": "application/json",
                "X-API-Key": self._api_key,
            },
            method="POST",
        )

        try:
            with request.urlopen(req, timeout=self._timeout) as resp:
                body = resp.read().decode("utf-8")
                raw = json.loads(body) if body else {}
                return DooplexResponse(ok=bool(raw.get("ok")), raw=raw)
        except error.HTTPError as exc:
            message = _extract_error_message(exc)
            raise DooplexAPIError(status_code=exc.code, message=message) from exc
        except error.URLError as exc:
            raise DooplexError(f"Network error calling Dooplex API: {exc}") from exc


def _extract_error_message(exc: error.HTTPError) -> str:
    try:
        raw = exc.read().decode("utf-8")
        if not raw:
            return "request failed"
        parsed = json.loads(raw)
        if isinstance(parsed, dict) and "error" in parsed:
            return str(parsed["error"])
        return raw
    except Exception:
        return "request failed"
