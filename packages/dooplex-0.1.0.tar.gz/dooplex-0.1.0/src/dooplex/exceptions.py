class DooplexError(Exception):
    """Base exception for the Dooplex SDK."""


class DooplexAPIError(DooplexError):
    """Raised when the Dooplex API returns a non-2xx response."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        self.message = message
        super().__init__(f"Dooplex API error {status_code}: {message}")
