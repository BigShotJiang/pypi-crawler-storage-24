#!/usr/bin/env python3
# -*- coding:UTF-8 -*-
#
# Copyright (C) 2023 Junbo Zheng. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import shutil
import subprocess
import sys
import os
import gzip
import glob
import re
import shlex
import logging as log

import argparse
from enum import IntEnum

try:
    from miwear import __version__
except ImportError:
    __version__ = "0.0.1"


log.basicConfig(
    level=log.DEBUG,
    datefmt="%Y-%m-%d %H:%M:%S",
    format="%(asctime)-19s.%(msecs)03d %(levelname)-8s %(filename)s %(lineno)-3d %(process)d %(message)s",
)


class DefaultCLIParameters:
    remote_path = "/sdcard/Android/data/com.mi.health/files/log/devicelog"
    source_path = "."
    output_path = "./file"
    output_file = "file.tar.gz"
    file_name = "log.tar.gz"
    filter_pattern = "log\\d*|tmp.log"
    tmp_log = "tmp.log"
    special_file_suffix = [".core", ".txt"]


class ShellRunner:
    last_error = ""  # store last command error output

    @staticmethod
    def command_run(command):
        result = subprocess.run(
            command,
            stdin=sys.stdin,
            stdout=sys.stdout,
            stderr=subprocess.PIPE,
            shell=True,
        )
        if result.returncode != 0 and result.stderr:
            ShellRunner.last_error = result.stderr.decode(
                "utf-8", errors="replace"
            ).strip()
        else:
            ShellRunner.last_error = ""
        return result.returncode


class CLIParametersParser:
    def __init__(self):
        # log.debug("Parameter Number :%d", len(sys.argv))
        # log.debug("Shell Name       :%s", str(sys.argv[0]))

        arg_parser = argparse.ArgumentParser(
            description="Extract a file with the suffix `.tar.gz` from the source path or remote path and extract to "
            "output_path."
        )

        arg_parser.add_argument(
            "--version",
            action="store_true",
            help="Show miwear_log version and exit.",
        )

        arg_parser.add_argument(
            "-o",
            "--output_path",
            type=str,
            nargs="+",
            default=DefaultCLIParameters.output_path,
            help="extract packet output path",
        )

        arg_parser.add_argument(
            "-m",
            "--merge_file",
            type=str,
            nargs="?",
            help="extract packet and merge to a new file",
        )
        arg_parser.add_argument(
            "-f",
            "--filename",
            type=str,
            nargs="?",
            default=None,
            help="extract file path (with full path or just filename), such as: /path/to/log.tar.gz or log.tar.gz",
        )
        arg_parser.add_argument(
            "file_path",
            type=str,
            nargs="?",
            default=None,
            help="extract packet file path (positional argument), alternative to -f option",
        )
        arg_parser.add_argument(
            "--phone",
            action="store_true",
            help="pull file from Android phone via adb",
        )
        arg_parser.add_argument(
            "-p",
            "--purge_source_file",
            help="purge source file if is true",
            action="store_true",
            default=False,
        )
        arg_parser.add_argument(
            "-F",
            "--filter_pattern",
            type=str,
            default=DefaultCLIParameters.filter_pattern,
            help="filter the files to be merged",
        )
        arg_parser.add_argument(
            "-l",
            "--log",
            type=str,
            default=DefaultCLIParameters.tmp_log,
            help="special log file name(default: tmp.log)",
        )

        if (len(sys.argv)) <= 1:
            arg_parser.print_help()
            sys.exit(0)

        self.__cli_args = arg_parser.parse_args()
        if self.__cli_args.version:
            print("miwear_log version %s" % __version__)
            sys.exit(0)

        if self.__cli_args.filename is not None:
            input_str = self.__cli_args.filename
        elif self.__cli_args.file_path is not None:
            input_str = self.__cli_args.file_path
        else:
            arg_parser.error(
                "must provide file path via -f/--filename option or positional argument"
            )
            sys.exit(1)

        if os.path.dirname(input_str):
            self.source_path = [os.path.dirname(os.path.abspath(input_str))]
            self.filename = [os.path.basename(input_str)]
        else:
            self.source_path = [os.getcwd()]
            self.filename = [input_str]

        base_name = self.filename[0]
        if re.search(r"\d+", base_name):
            numbers = re.findall(r"\d+", base_name)
            log.debug(f"filename number -> {numbers}")
            if numbers:
                base_name = numbers[0]
                log.debug(
                    f"Extracted number '{base_name}' from input '{self.filename[0]}'"
                )

            if len(numbers) > 1:
                self.merge_file = os.path.join(os.getcwd(), numbers[-2] + ".log")
        else:
            pattern = r"^(.*?)\.tar.*\.gz$"
            match = re.match(pattern, base_name)
            if match:
                base_name = match.group(1)

        # With the input filename parameter as merge file if merge file is not specified
        if self.merge_file is None:
            self.merge_file = os.path.join(os.getcwd(), base_name + ".log")

        log.debug("output_path      :%s", self.output_path)
        log.debug("source_path      :%s", self.source_path)
        log.debug("filename         :%s", self.filename)
        log.debug("purge_source_file:%s", self.purge_source_file)
        log.debug("merge_file       :%s", self.merge_file)

    def __getattr__(self, item):
        return self.__cli_args.__getattribute__(item)

    def __setattr__(self, name, value):
        if name == "_CLIParametersParser__cli_args":
            super().__setattr__(name, value)
        else:
            setattr(self.__cli_args, name, value)


class LogTools:
    def __init__(self, cli_parser):
        self.__cli_parser = cli_parser
        self.log_packet_path = None
        self.log_dir_path = None

    def clear_output_dir(self, ask=True):
        if not os.path.exists(self.__cli_parser.output_path):
            return 0

        # if output path exists, clear
        if ask:
            input_str = input(
                "The %s already exists, will cover it? [Y/N]\n"
                % self.__cli_parser.output_path
            )
            if input_str != "Y":
                log.debug("quit and exit")
                return -1
        cmd = "rm -rf " + shlex.quote(self.__cli_parser.output_path)
        # fmt: off
        log.debug(
            Highlight.Convert("clear") + " exist file %s by command %s",
            self.__cli_parser.output_path,
            cmd
        )
        # fmt: on
        return ShellRunner.command_run(cmd)

    def pull_packet(self):
        if self.__cli_parser.phone:
            adb_cmd = (
                "adb pull " + shlex.quote(DefaultCLIParameters.remote_path) + " ./"
            )
            log.debug(adb_cmd)
            ShellRunner.command_run(adb_cmd)

            filename = self.__cli_parser.filename[0]
            file = os.getcwd() + "/devicelog/**/" + "*" + filename + "*.tar*.gz"
            result = glob.glob(file, recursive=True)
        else:
            filename = self.__cli_parser.filename[0]
            if ".tar" in filename and ".gz" in filename:
                file_path = os.path.join(self.__cli_parser.source_path[0], filename)
                result = [file_path] if os.path.exists(file_path) else []
            else:
                pattern = (
                    self.__cli_parser.source_path[0]
                    + "/"
                    + "*"
                    + filename
                    + "*.tar*.gz"
                )
                result = glob.glob(pattern)

        if len(result) == 0:
            log.error(
                Highlight.Convert(
                    f"Not found file packet, please check source path: {self.__cli_parser.source_path}",
                    Highlight.RED,
                )
            )
            return -1

        # fmt: off
        log.debug(
            Highlight.Convert("pull") + " %s from %s",
            result,
            self.__cli_parser.source_path[0]
        )
        # fmt: on
        if len(result) > 1:
            index = input("Please input the file index you want to extract:\n")
            file = result[int(index)]
        else:
            file = result[0]

        path = os.path.dirname(file)
        filename_base = self.__cli_parser.filename[0]
        if ".tar.gz" in filename_base:
            filename_base = (
                filename_base.replace(".tar.gz", "")
                .replace(".tar", "")
                .replace(".gz", "")
            )
        elif ".tar" in filename_base:
            filename_base = filename_base.replace(".tar", "").replace(".gz", "")
        elif ".gz" in filename_base:
            filename_base = filename_base.replace(".gz", "")
        output = filename_base + "_" + DefaultCLIParameters.output_file
        output = os.path.join(path, output)

        if self.__cli_parser.purge_source_file:
            log.debug("rename to %s", output)
            os.rename(file, output)
        else:
            log.debug("copy to %s", output)
            shutil.copyfile(file, output)
        if output is None:
            log.error(
                Highlight.Convert(f"Not found file packet in {file}", Highlight.RED)
            )
            return -1

        self.log_packet_path = output

        log.debug("output file %s", self.log_packet_path)
        return 0

    def __find_logfiles_path__(self):
        for root, dirs, files in os.walk(self.__cli_parser.output_path):
            for file in files:
                if file == self.__cli_parser.log:
                    self.log_dir_path = os.path.abspath(root)
                    return 0
        return -1

    def __find_special_files(self):
        special_files = []
        for root, dirs, files in os.walk(self.log_dir_path):
            for file in files:
                # Check if the file ends with any suffix in special_file_suffix
                for suffix in DefaultCLIParameters.special_file_suffix:
                    if file.lower().endswith(suffix.lower()):
                        special_files.append(os.path.join(root, file))
        return special_files

    def __remove_all_suffix_gz_file__(self):
        for root, dirs, files in os.walk(self.log_dir_path):
            for file in files:
                if os.path.splitext(file)[-1] == ".gz":
                    os.remove(os.path.join(root, file))
        return 0

    def __gunzip_all__(self):
        if not os.path.exists(self.log_dir_path):
            log.error(
                Highlight.Convert(
                    f"Not found log directory: {self.log_dir_path}", Highlight.RED
                )
            )
            return -1

        dirs = os.listdir(self.log_dir_path)
        for file in dirs:
            if ".gz" in file:
                try:
                    filename = file.replace(".gz", "")
                    gzip_file_path = os.path.join(self.log_dir_path, file)
                    output_file_path = os.path.join(self.log_dir_path, filename)

                    with gzip.open(gzip_file_path, "rb") as gzip_file:
                        with open(output_file_path, "wb+") as f:
                            f.write(gzip_file.read())

                except EOFError as e:
                    log.error(f"file {file} maybe error, code: {e}")
                    continue
                except Exception as e:
                    log.error(f"file {file} error: {e}")
                    continue
        log.debug(Highlight.Convert("gunzip") + " all done")
        return 0

    def extract_special_files(self):
        special_files = self.__find_special_files()
        if not special_files:
            log.debug("No special files found")
            return 0

        log.debug("Special files found:")
        for special_file in special_files:
            log.debug(f"  -> {special_file}")
            des_path = os.path.join(os.getcwd(), os.path.basename(special_file))
            log.debug(f"Copying {special_file} to {des_path}")
            shutil.copy(special_file, des_path)
        return 0

    def __is_gzip_file__(self, filepath):
        try:
            with open(filepath, "rb") as f:
                magic = f.read(2)
                return magic == b"\x1f\x8b"  # gzip magic bytes
        except Exception:
            return False

    def extract_packet(self):
        if not os.path.exists(self.__cli_parser.output_path):
            os.makedirs(self.__cli_parser.output_path)

        if self.__is_gzip_file__(self.log_packet_path):
            cmd = "gzip -d " + shlex.quote(self.log_packet_path)
            log.debug(Highlight.Convert("gzip") + " by command " + cmd)
            ShellRunner.command_run(cmd)
            tar_package = self.log_packet_path.replace(".gz", "")
        else:
            log.debug(
                Highlight.Convert("skip gzip")
                + " - file is not gzip compressed, treating as tar archive"
            )
            tar_package = self.log_packet_path

        cmd = (
            "tar -xvf "
            + shlex.quote(tar_package)
            + " -C "
            + shlex.quote(self.__cli_parser.output_path)
        )
        log.debug(Highlight.Convert("tar") + " by command " + cmd)

        if ShellRunner.command_run(cmd) != 0:
            error_msg = ShellRunner.last_error or "unknown error"
            log.error(
                Highlight.Convert(
                    f"Command failed:\n  Command: {cmd}\n  Error: {error_msg}",
                    Highlight.RED,
                )
            )
            return -1

        cmd = "chmod -R 755" + " " + shlex.quote(self.__cli_parser.output_path)
        if ShellRunner.command_run(cmd) != 0:
            error_msg = ShellRunner.last_error or "unknown error"
            log.error(
                Highlight.Convert(
                    f"Command failed:\n  Command: {cmd}\n  Error: {error_msg}",
                    Highlight.RED,
                )
            )
            return -1

        if (
            tar_package != self.log_packet_path
            or not self.__cli_parser.purge_source_file
        ):
            os.remove(tar_package)

        # find log files dir path
        if self.__find_logfiles_path__() != 0:
            return -1

        # gunzip all *.gz files under path
        if self.__gunzip_all__() != 0:
            return -1

        # remove unused .gz files
        return self.__remove_all_suffix_gz_file__()

    # merge all file to a new file
    def merge_logfiles(self):
        file_list = os.listdir(self.log_dir_path)
        file_list.sort(key=lambda name: (len(name), name))
        log.debug(Highlight.Convert("merge") + " file list %s", file_list)

        if os.path.exists(self.__cli_parser.merge_file):
            log.debug("merge file exist, will remove")
            os.remove(self.__cli_parser.merge_file)

        files_to_merge = []
        for file in file_list:
            if re.match(self.__cli_parser.filter_pattern, file) is None:
                continue
            files_to_merge.append(os.path.join(self.log_dir_path, file))

        if not files_to_merge:
            log.warning("No files match the pattern to merge")
            return False

        try:
            with open(self.__cli_parser.merge_file, "wb") as outfile:
                for file_path in files_to_merge:
                    log.debug(f"prepare merge file {file_path}")
                    try:
                        with open(file_path, "rb") as f:
                            outfile.write(f.read())
                    except Exception as e:
                        log.warning(f"Failed to read {file_path}: {e}")
                        continue

            log.debug(
                "Successfully merged %d files to %s",
                len(files_to_merge),
                self.__cli_parser.merge_file,
            )
            return True

        except Exception as e:
            log.error(f"Failed to merge files: {e}")
            return False

    def get_merge_file(self):
        return self.__cli_parser.merge_file

    def merge_txt_files(self):
        if self.log_dir_path is None or not os.path.exists(self.log_dir_path):
            log.warning("Log directory not found, skip merging txt files")
            return False

        txt_files = []
        for root, dirs, files in os.walk(self.log_dir_path):
            for file in files:
                if file.lower().startswith("crash") and file.lower().endswith(".txt"):
                    txt_files.append(os.path.join(root, file))

        if not txt_files:
            log.debug("No crash txt files found to merge")
            return False

        txt_files.sort()
        log.debug(Highlight.Convert("merge crash txt") + " file list %s", txt_files)

        merge_file_base = os.path.splitext(self.__cli_parser.merge_file)[0]
        txt_merge_file = merge_file_base + ".txt"

        if os.path.exists(txt_merge_file):
            log.debug("txt merge file exists, will remove")
            os.remove(txt_merge_file)

        try:
            with open(txt_merge_file, "wb") as outfile:
                for file_path in txt_files:
                    log.debug(f"prepare merge crash txt file {file_path}")
                    try:
                        with open(file_path, "rb") as f:
                            outfile.write(f.read())
                    except Exception as e:
                        log.warning(f"Failed to read {file_path}: {e}")
                        continue

            log.debug(
                "Successfully merged %d crash txt files to %s",
                len(txt_files),
                txt_merge_file,
            )
            return True

        except Exception as e:
            log.error(f"Failed to merge crash txt files: {e}")
            return False


def CHECK_ERROR_EXIT(ret):
    if ret:
        log.error(
            Highlight.Convert("Extraction failed with code: " + str(ret), Highlight.RED)
        )
        exit(ret)


class Highlight(IntEnum):
    BLACK = 30
    RED = 31
    GREEN = 32
    YELLOW = 33
    BLUE = 34
    WHITE = 37

    @staticmethod
    def Convert(msg, color=BLUE):
        return "\033[;%dm%s\033[0m" % (color, msg)


def main():
    cli_args = CLIParametersParser()
    logtools = LogTools(cli_args)

    # clear exist output dir
    CHECK_ERROR_EXIT(logtools.clear_output_dir())

    # pull log packet from phone or local, depends on command line parameters
    CHECK_ERROR_EXIT(logtools.pull_packet())

    # extract log packet
    CHECK_ERROR_EXIT(logtools.extract_packet())

    # extract special file
    CHECK_ERROR_EXIT(logtools.extract_special_files())

    # merge the log files to one file, then remove output dir
    merge_success = logtools.merge_logfiles()

    # merge crash txt files before removing output dir
    txt_merge_success = logtools.merge_txt_files()
    if txt_merge_success is True:
        merge_file_base = os.path.splitext(logtools.get_merge_file())[0]
        txt_merge_file = merge_file_base + ".txt"
        log.debug(
            Highlight.Convert("crash txt", Highlight.GREEN)
            + f" file at [{txt_merge_file}]"
        )

    if merge_success is True:
        logtools.clear_output_dir(False)

    log.debug(Highlight.Convert("Successful", Highlight.GREEN))
    log.debug(
        f"All done, you can take a look now!(log file at [{logtools.get_merge_file()}])"
    )


if __name__ == "__main__":
    main()
