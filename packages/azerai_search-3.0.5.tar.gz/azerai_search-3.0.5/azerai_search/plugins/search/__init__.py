"""
AzerAI Search Plugin - Veb axtarış plugini
"""

from .main import yandex_search

__all__ = [
    "yandex_search"
]
