"""
AzerAI Search Plugin Info
Search plugini haqqında məlumatlar və metadata
"""

__version__ = "3.0.5"
__author__ = "AzStudio Dev"
__email__ = "info.azstudiodev@gmail.com"
__description__ = "AzerAI Search Plugin - Veb axtarış plugini"

PLUGIN_INFO = {
    "name": "azerai-search",
    "version": __version__,
    "author": __author__,
    "email": __email__,
    "description": __description__,
    "category": "utility",
    "language": "az",
    "functions": [
        "yandex_search"
    ],
    "capabilities": [
        "Yandex search functionality",
        "Last 10 results",
        "Azerbaijani language support",
        "Real-time search results",
        "Background music during search"
    ],
    "dependencies": [
        "livekit-agents",
        "requests",
        "beautifulsoup4",
        "sounddevice",
        "scipy",
        "numpy",
        "playwright"
    ],
    "features": [
        "Yandex search engine",
        "Last 10 results display",
        "Azerbaijani interface",
        "Fast search results",
        "Background music",
        "Real-time search"
    ],
    "tags": ["AzerAI", "plugin", "search", "web", "ai", "azerbaijani", "yandex"]
}

def get_plugin_info():
    """Plugin məlumatlarını qaytarır"""
    return PLUGIN_INFO

def get_plugin_version():
    """Plugin versiyasını qaytarır"""
    return __version__

def get_plugin_description():
    """Plugin təsvirini qaytarır"""
    return __description__
