"""
Axtarış Alətləri - LiveKit Agent Funksiyaları
Veb axtarış sistemi alətləri
"""
import logging
import urllib.parse
import threading
import time
import asyncio
from pathlib import Path
from datetime import datetime
from playwright.async_api import async_playwright
from livekit.agents import function_tool, RunContext
import sounddevice as sd
import scipy.io.wavfile as wavfile
import numpy as np

logger = logging.getLogger("search-tools")

def play_search_music(stop_event):
    """
    Axtarış əməliyyatları üçün arxa plan musiqisi çalır.
    """
    try:
        # Musiqi qovluğunu paket daxilində yarat
        import os
        music_dir = Path(__file__).parent / "music"
        music_dir.mkdir(exist_ok=True)
        music_file = music_dir / "search.wav"
        
        if not music_file.exists():
            # Axtarış əməliyyatları üçün gözəl bir davamlı ton yarat
            sample_rate = 44100
            duration = 8.0  # 8 saniyəlik döngü
            frequency = 523  # C5 notası - parlaq axtarış tonu
            
            t = np.linspace(0, duration, int(sample_rate * duration), False)
            # Harmoniklərlə gözəl bir səs yarat
            wave = 0.3 * np.sin(2 * np.pi * frequency * t) + \
                   0.1 * np.sin(2 * np.pi * frequency * 2 * t) + \
                   0.05 * np.sin(2 * np.pi * frequency * 3 * t)
            
            # Daha yumşaq etmək üçün amma tamamilə səsini kəsməmək üçün incə zərf tətbiq et
            envelope = 0.7 + 0.3 * np.sin(2 * np.pi * 0.5 * t)  # İncə modulyasiya
            wave = wave * envelope
            
            # WAV faylı kimi saxla
            wavfile.write(music_file, sample_rate, (wave * 32767).astype(np.int16))
        
        # Musiqi faylını səhvssiz çalma ilə döngü kimi çal
        sample_rate, data = wavfile.read(str(music_file))
        
        while not stop_event.is_set():
            try:
                sd.play(data, sample_rate)
                # Səsin çalmasını gözlə amma periodik olaraq stop_event yoxla
                audio_duration = len(data) / sample_rate
                start_time = time.time()
                
                while time.time() - start_time < audio_duration:
                    if stop_event.is_set():
                        sd.stop()
                        return
                    time.sleep(0.1)  # Hər 100ms-də bir yoxla
                    
            except Exception as e:
                logging.error("Arxa plan musiqisi çalarkən xəta: %s", e)
                break
                
    except ImportError:
        logging.warning("Arxa plan musiqisi üçün numpy mövcud deyil")
    except Exception as e:
        logging.error("Arxa plan musiqisi thread-ində xəta: %s", e)


async def yandex_last_10_results(query):
    """
    Son 10 nəticəni qaytaran Yandex axtarış funksiyası (async versiya)
    """
    encoded = urllib.parse.quote_plus(query)
    url = f"https://yandex.com.tr/search/?text={encoded}"

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            args=["--disable-blink-features=AutomationControlled"]
        )

        page = await browser.new_page(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/125.0.0.0 Safari/537.36"
            )
        )

        await page.goto(url, timeout=60000)
        await page.wait_for_timeout(3000)

        results = await page.query_selector_all("li.serp-item")

        if not results:
            await browser.close()
            return []

        # 👉 SON 10 NƏTİCƏ
        last_10 = results[-10:]

        data = []

        for i, result in enumerate(last_10, start=1):
            title_el = await result.query_selector("a[href] h2, a[href] h3")
            link_el = await result.query_selector("a[href]")
            desc_el = await result.query_selector(".text-container, .OrganicText")

            title = await title_el.inner_text() if title_el else "Başlıq tapılmadı"
            title = title.strip()
            
            link = await link_el.get_attribute("href") if link_el else "Link tapılmadı"
            
            desc = await desc_el.inner_text() if desc_el else "Təsvir tapılmadı"
            desc = desc.strip()

            data.append({
                "index": i,
                "title": title,
                "link": link,
                "description": desc
            })

        await browser.close()
        return data


@function_tool()
async def yandex_search(
    ctx: RunContext,  # type: ignore
    query: str
) -> str:
    """
    Yandex-də internet axtarışı edir və son 10 nəticəni qaytarır. Axtarış zamanı istifadəçi kəsimləri qarşısı alınır.
    
    Args:
        query: Axtarış sorğusu
    
    Returns:
        Axtarış nəticələri
    """
    logger = logging.getLogger("search-plugin")
    
    try:
        logger.debug("=== SEARCH START: set_audio_enabled(False) called ===")
        # Mikrofonu tamamilə bağla - dinlənmə olmasın
        ctx.session.input.set_audio_enabled(False)

        # Arxa plan musiqisi üçün dayandırma hadisəsi yarat
        stop_music = threading.Event()
        
        # Arxa plan musiqisini ayrı bir thread-də başlat
        music_thread = threading.Thread(
            target=play_search_music, 
            args=(stop_music,),
            daemon=True
        )
        music_thread.start()
        
        try:
            logger.debug("=== SEARCH: Starting Yandex search operation ===")
            
            # Yandex axtarış əməliyyatını et
            def _yandex_search_sync():
                if not query or len(query.strip()) < 2:
                    raise Exception("Axtarış sorğusunda ən azı 2 karakter olmalıdır.")
                
                return asyncio.run(yandex_last_10_results(query))
            
            results = await asyncio.to_thread(
                _yandex_search_sync
            )
            
            logger.info(f"🔍 Yandex axtarışı tamamlandı: {query}")
            
            if not results:
                result_text = f"""❌ AXTARIŞ NƏTİCƏLƏRİ XƏTASI

🔍 Sorğu: {query}
❌ Status: Nəticə tapılmadı
🎵 Arxa plan musiqisi: C5 notası (523 Hz)
⏰ Axtarış vaxtı: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

❌ Xəta: '{query}' üçün nəticə tapılmadı"""
            else:
                response_parts = [f"""🔍 AXTARIŞ NƏTİCƏLƏR

🔍 Sorğu: {query}
✅ Status: Axtarış uğurla tamamlandı
🎵 Arxa plan musiqisi: C5 notası (523 Hz)
⏰ Axtarış vaxtı: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

✅ SON 10 NƏTİCƏ:"""]
                
                for result in results:
                    response_parts.append(f"#{result['index']}")
                    response_parts.append(f"📌 Başlıq: {result['title']}")
                    response_parts.append(f"🔗 Link: {result['link']}")
                    response_parts.append(f"📝 Təsvir: {result['description']}")
                    response_parts.append("-" * 50)
                
                result_text = "\n".join(response_parts)
            
            logger.debug(f"=== SEARCH COMPLETE: Search finished ===")
            return result_text
            
        except Exception as e:
            logger.debug(f"=== SEARCH ERROR: {str(e)} ===")
            return f"Yandex axtarışı uğursuz oldu: {str(e)}"
        finally:
            # Arxa plan musiqisini dayandır
            stop_music.set()
            sd.stop()
            logger.debug("=== SEARCH FINALLY: set_audio_enabled(True) called ===")
            # Mikrofonu yenidən aç - dinlənmə başlasın
            ctx.session.input.set_audio_enabled(True)
        
    except Exception as e:
        logging.error(f"Search plugin xətası: {e}")
        return f"Yandex axtarışı zamanı xəta: {str(e)}"
