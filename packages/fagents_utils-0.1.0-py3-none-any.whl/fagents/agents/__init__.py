"""Agent实现模块 - fagents原生Agent范式"""

from .react_agent import ReActAgent

# 子代理机制（第06章）
from .factory import create_agent, default_subagent_factory

# 向后兼容别名

__all__ = [
    "ReActAgent",

    # 子代理工厂函数
    "create_agent",
    "default_subagent_factory",
]
