import os
import subprocess
import json
import asyncio
class SkillExecutor:
    def __init__(self, base_dir="skills"):
        self.base_dir = base_dir

    def run(self, skill_name, params):
        script_path = os.path.join(
            self.base_dir,
            skill_name,
            "scripts",
            f"{skill_name}.py"
        )

        proc = subprocess.Popen(
            ["python", script_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE
        )

        out, _ = proc.communicate(json.dumps(params).encode())

        return json.loads(out)

class AsyncSkillExecutor:

    def __init__(self, base_dir="skills"):
        self.base_dir = base_dir

    async def run(self, skill_name, params):
        script_path = os.path.join(
            self.base_dir,
            skill_name,
            "scripts",
            f"{skill_name}.py"
        )

        proc = await asyncio.create_subprocess_exec(
            "python", script_path,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        out, err = await proc.communicate(json.dumps(params).encode())

        if proc.returncode != 0:
            raise RuntimeError(err.decode())

        return json.loads(out.decode())