"""版本信息"""

__version__ = "1.0.0"
__author__ = "fagents Team"
__email__ = "jjyaoao@126.com"
__description__ = "灵活、可扩展的多智能体框架 - 基于Datawhale Hello-Agents教程"