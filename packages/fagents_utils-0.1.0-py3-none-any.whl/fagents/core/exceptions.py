"""异常体系"""

class fagentsException(Exception):
    """fagents基础异常类"""
    pass

class LLMException(fagentsException):
    """LLM相关异常"""
    pass

class AgentException(fagentsException):
    """Agent相关异常"""
    pass

class ConfigException(fagentsException):
    """配置相关异常"""
    pass

class ToolException(fagentsException):
    """工具相关异常"""
    pass
