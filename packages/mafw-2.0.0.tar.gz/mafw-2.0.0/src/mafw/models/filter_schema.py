#  Copyright 2025–2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Static metadata describing the models available for filtering."""

from __future__ import annotations

from dataclasses import dataclass, field

from mafw.db.db_model import MAFwBaseModel

__all__ = ['FilterSchema']


@dataclass(frozen=True)
class FilterSchema:
    """
    Static descriptor of the models available to the GUI filter builder.

    :param root_model: Model that controls the primary query entry point.
    :param allowed_models: Supplementary models that can be joined during filtering.
    """

    root_model: type[MAFwBaseModel]
    allowed_models: tuple[type[MAFwBaseModel], ...] = field(default_factory=tuple)
