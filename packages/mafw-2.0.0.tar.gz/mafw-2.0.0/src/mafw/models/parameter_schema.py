#  Copyright 2025–2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Schemas describing processor parameters.

These light-weight dataclasses capture the static metadata that is declared through :class:`.ActiveParameter`
definitions and can be consumed by tooling without instantiating the processor itself.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

__all__ = ['ParameterSchema']


@dataclass(frozen=True)
class ParameterSchema:
    """Static metadata describing a single processor parameter.

    :param name: Symbolic name used in steering files.
    :param annotation: Optional type hint supplied by the processor definition.
    :param default: The default value declared on the descriptor.
    :param help: Documentation text that should be surfaced to the user.
    :param is_list: True if the parameter expects a :class:`list`-like value.
    :param is_dict: True if the parameter expects a :class:`dict`-like value.
    """

    name: str
    annotation: type | None
    default: Any
    help: str | None
    is_list: bool
    is_dict: bool
