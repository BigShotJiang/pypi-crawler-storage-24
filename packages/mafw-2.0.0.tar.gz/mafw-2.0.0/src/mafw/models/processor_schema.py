#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Schemas describing a processor.

These light-weight dataclasses capture the static metadata that is declared through
:class:`.Processor` definitions and can be consumed by tooling without instantiating
the processor itself.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from mafw.models.filter_schema import FilterSchema
from mafw.models.parameter_schema import ParameterSchema

__all__ = ['ProcessorSchema']


@dataclass(frozen=True)
class ProcessorSchema:
    """Static metadata describing a processor.

    :param parameters: List of parameter schemas.
    :param filter: Optional filter schema.
    """

    parameters: List[ParameterSchema]
    filter: Optional[FilterSchema]

    def get_parameter_names(self) -> list[str]:
        """Return the list of parameter names."""
        return [p.name for p in self.parameters]

    def get_parameter(self, parameter_name: str) -> ParameterSchema:
        """Return the parameter schema for the given parameter name."""
        for p in self.parameters:
            if p.name == parameter_name:
                return p
        raise KeyError(f'Parameter {parameter_name} not found in schema.')
