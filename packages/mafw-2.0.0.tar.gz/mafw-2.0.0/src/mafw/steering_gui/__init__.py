#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Application layer for steering GUI orchestration.

:Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
:Description: Expose the steering GUI controller without leaking UI widgets or execution logic.
"""
