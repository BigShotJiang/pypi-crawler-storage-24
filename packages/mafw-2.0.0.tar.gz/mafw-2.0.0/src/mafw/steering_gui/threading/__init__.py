#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Threading utilities made available to the steering GUI.

:Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
:Description: Provide a shared Worker QObject for running operations off the GUI thread.
"""

from .workers import Worker

__all__ = ['Worker']
