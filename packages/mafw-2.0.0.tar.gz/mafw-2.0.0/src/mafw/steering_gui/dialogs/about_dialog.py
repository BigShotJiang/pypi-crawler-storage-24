#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Dialog presenting metadata about the Steering GUI application.

:Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
:Description: Display icon, project description, URLs, and authorship to the user.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from mafw.__about__ import __initial_development__, __version__


class AboutDialog(QDialog):
    """Show the About page for MAFw and the steering GUI.

    :param parent: Optional parent widget for window hierarchy.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle('About MAFw')
        self.setModal(True)

        # Copyright year logic
        initial_year = __initial_development__
        current_year = datetime.now().year

        # Format copyright year based on whether current year is different from initial
        if current_year > initial_year:
            self.copyright_year = f'{initial_year} - {current_year}'
        else:
            self.copyright_year = str(initial_year)

        self._setup_ui()
        self.adjustSize()

    def _setup_ui(self) -> None:
        """Compose the dialog layout and populate the informative labels."""

        icon_path = Path(__file__).parent.parent / 'resources' / 'mafw-logo.png'
        icon_label = QLabel()
        if icon_path.exists():
            pixmap = QPixmap(icon_path)
            icon_label.setPixmap(pixmap.scaled(128, 128, Qt.AspectRatioMode.KeepAspectRatio))

        text_layout = QVBoxLayout()
        text_layout.addWidget(QLabel('<h1>MAFw Steering GUI</h1>'))
        text_layout.addWidget(QLabel(f'Version {__version__}'))
        text_layout.addWidget(QLabel('<p>Visual tool to create, edit, validate and launch steering files.</p>'))
        text_layout.addWidget(QLabel(f'Copyright © {self.copyright_year} European Union'))
        text_layout.addWidget(QLabel('Author: Antonio Bulgheroni (antonio.bulgheroni@ec.europa.eu)'))
        license_label = QLabel(
            'License: <a href="https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12">EUPL-1.2</a>'
        )
        license_label.setOpenExternalLinks(True)
        text_layout.addWidget(license_label)
        source_code_label = QLabel('Source code: <a href="https://code.europa.eu/kada/mafw">GitLab</a>')
        source_code_label.setOpenExternalLinks(True)

        content_layout = QHBoxLayout()
        content_layout.addWidget(icon_label)
        content_layout.addLayout(text_layout)

        button_layout = QHBoxLayout()
        ok_button = QPushButton('OK')
        ok_button.clicked.connect(self.accept)
        button_layout.addStretch()
        button_layout.addWidget(ok_button)

        main_layout = QVBoxLayout()
        main_layout.addLayout(content_layout)
        main_layout.addLayout(button_layout)
        self.setLayout(main_layout)
