#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Dialog helpers for the steering GUI package.

:Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
:Description: expose dialog widgets such as AboutDialog to other modules.
"""

from .about_dialog import AboutDialog
from .add_processor_dialog import AddProcessorDialog
from .steering_text_editor import SteeringTextEditor

__all__ = ['AboutDialog', 'AddProcessorDialog', 'SteeringTextEditor']
