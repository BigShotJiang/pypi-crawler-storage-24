#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Placeholder package for steering GUI views while the GUI is being scaffolded.

:Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
:Description: UI views live here once they are implemented, keeping the controller agnostic of toolkit code.
"""

from .database_editor import DatabaseEditor
from .globals_editor import GlobalsEditor
from .group_editor import GroupEditor
from .meta_editor import MetadataEditor
from .pipeline_editor import PipelineEditor
from .processor_editor import ProcessorEditor
from .processor_parameter_editor import ProcessorParameterEditor
from .steering_tree import SteeringTreeView
from .ui_editor import UIEditor

__all__ = [
    'DatabaseEditor',
    'GlobalsEditor',
    'GroupEditor',
    'MetadataEditor',
    'PipelineEditor',
    'ProcessorEditor',
    'ProcessorParameterEditor',
    'SteeringTreeView',
    'UIEditor',
]
