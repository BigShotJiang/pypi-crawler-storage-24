#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Editor scaffolding for processor-specific configurations.

:Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
:Description: Offer a placeholder layout that will later host processor settings.
"""

from __future__ import annotations

from PySide6.QtWidgets import QFormLayout, QLabel, QWidget


class ProcessorEditor(QWidget):
    """Placeholder widget representing per-processor configuration editors."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QFormLayout()
        layout.addRow('Processor name', QLabel('processorA → processorB'))
        layout.addRow('Filters', QLabel('filter-field (future editor)'))
        layout.addRow('Replica strategy', QLabel('serial'))
        self.setLayout(layout)
