#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Expose the globals editor fields required by the steering GUI.

:Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
:Description: Provide input fields for the analysis metadata and flags managed by the controller.
"""

from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QCheckBox, QFormLayout, QLineEdit, QWidget

from mafw.steering_gui.utils import block_signals


class GlobalsEditor(QWidget):
    """Editor that exposes analysis metadata and global flags without touching the builder."""

    analysis_name_changed = Signal(str)
    description_changed = Signal(str)
    new_only_changed = Signal(bool)
    create_standard_tables_changed = Signal(bool)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.analysis_name_edit = QLineEdit()
        self.description_edit = QLineEdit()
        self.new_only_checkbox = QCheckBox('Run only new data')
        self.new_only_checkbox.setChecked(False)
        self.create_standard_tables_checkbox = QCheckBox('Create standard tables')
        self.create_standard_tables_checkbox.setChecked(False)

        self.analysis_name_edit.textChanged.connect(self.analysis_name_changed)
        self.description_edit.textChanged.connect(self.description_changed)
        self.new_only_checkbox.toggled.connect(self.new_only_changed)
        self.create_standard_tables_checkbox.toggled.connect(self.create_standard_tables_changed)

        layout = QFormLayout()
        layout.addRow('Analysis Name', self.analysis_name_edit)
        layout.addRow('Description', self.description_edit)
        layout.addRow('', self.new_only_checkbox)
        layout.addRow('', self.create_standard_tables_checkbox)
        self.setLayout(layout)

    def set_data(
        self,
        analysis_name: str | None,
        description: str | None,
        new_only: bool | None,
        create_standard_tables: bool | None,
    ) -> None:
        """Populate the widgets and avoid re-triggering their change signals."""

        with block_signals(
            self.analysis_name_edit,
            self.description_edit,
            self.new_only_checkbox,
            self.create_standard_tables_checkbox,
        ):
            self.analysis_name_edit.setText(analysis_name or '')
            self.description_edit.setText(description or '')
            self.new_only_checkbox.setChecked(bool(new_only))
            self.create_standard_tables_checkbox.setChecked(bool(create_standard_tables))

    def current_values(self) -> tuple[str, str, bool, bool]:
        """Return the current UI values without normalizing them."""

        return (
            self.analysis_name_edit.text(),
            self.description_edit.text(),
            self.new_only_checkbox.isChecked(),
            self.create_standard_tables_checkbox.isChecked(),
        )
