#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""UI-only pipeline structures used to render editable processor hierarchies.

:Author: Bulgheroni Antonio
:Description: Lightweight in-memory objects that mirror the processor/group layout for the GUI.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from mafw.steering.models import GroupConfig, ProcessorConfig


@dataclass
class PipelineItem:
    """UI wrapper around a processor or group configuration.

    :param config: Domain configuration backing the item.
    :param parent: Parent pipeline item (None when top-level).
    :param children: Ordered list of child items.
    """

    config: ProcessorConfig | GroupConfig
    parent: PipelineItem | None = None
    children: list['PipelineItem'] = field(default_factory=list)

    def is_group(self) -> bool:
        """Return True if this item wraps a group configuration."""

        return isinstance(self.config, GroupConfig)

    def name(self) -> str:
        """Return the replica-aware processor name or group name."""

        return self.config.name


@dataclass
class ProcessorPipeline:
    """Container for the current processor pipeline tree.

    :param items: Top-level pipeline items in execution order.
    """

    items: list[PipelineItem] = field(default_factory=list)
