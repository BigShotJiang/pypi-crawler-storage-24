#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Entry point for the steering GUI application.

:Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
:Description: Verify dependencies, start QApplication, and show MainWindow.
"""

import sys
from pathlib import Path


def main() -> None:
    """Entry point that creates the QApplication and displays the main window."""
    try:
        from PySide6.QtGui import QIcon
        from PySide6.QtWidgets import QApplication
    except ImportError as exc:
        raise SystemExit(
            "The steering GUI requires the 'steering-gui' extra.\n"
            'Install it with:\n\n'
            '    pip install mafw[steering-gui]\n'
        ) from exc

    from mafw.steering_gui.controllers.steering_controller import SteeringController
    from mafw.steering_gui.main_window import MainWindow
    from mafw.steering_gui.utils.exception_handling import install_exception_handler

    app = QApplication([])
    app.setApplicationName('MAFw Steering GUI')
    install_exception_handler()

    icon_path = Path(__file__).parent / 'resources' / 'mafw-logo.png'
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    controller = SteeringController()
    window = MainWindow(controller)
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
