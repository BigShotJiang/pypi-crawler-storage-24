#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Container for steering GUI application controllers.

:Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
:Description: Hosts orchestrators that expose domain-safe operations to the UI layer.
"""
