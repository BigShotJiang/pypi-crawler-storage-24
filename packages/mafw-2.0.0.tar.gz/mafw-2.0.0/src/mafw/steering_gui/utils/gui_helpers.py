"""Reusable GUI helpers shared across the steering GUI views."""

#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
from __future__ import annotations

import re
from contextlib import contextmanager
from typing import Iterator

from PySide6.QtCore import QObject


@contextmanager
def block_signals(*widgets: QObject) -> Iterator[None]:
    """Temporarily disable Qt signals for a set of widgets."""

    try:
        for widget in widgets:
            widget.blockSignals(True)
        yield
    finally:
        for widget in widgets:
            widget.blockSignals(False)


def coerce_name(text: str) -> str:
    """Replace any whitespace in the provided text with underscores."""
    return re.sub(r'\s+', '_', text)
