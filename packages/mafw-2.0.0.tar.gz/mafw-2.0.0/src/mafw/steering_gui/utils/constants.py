#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Shared constants for the steering GUI."""

INT_RANGE = (-2_147_483_648, 2_147_483_647)
"""Default integer bounds for spin boxes."""

FLOAT_RANGE = (-1_000_000_000.0, 1_000_000_000.0)
"""Default floating-point bounds for spin boxes."""

FLOAT_DECIMALS = 6
"""Default number of decimals for floating-point spin boxes."""
