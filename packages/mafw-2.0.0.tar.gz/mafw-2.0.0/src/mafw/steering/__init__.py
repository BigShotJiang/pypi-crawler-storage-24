#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Steering builder tools for MAFw.

:Author: Bulgheroni Antonio
:Description: Editable data model, validation, and TOML serialization helpers for steering files.
"""
