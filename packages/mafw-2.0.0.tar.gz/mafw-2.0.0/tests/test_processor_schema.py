#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Tests for the ProcessorSchema model."""

import pytest

from mafw.models.parameter_schema import ParameterSchema
from mafw.models.processor_schema import ProcessorSchema


def test_get_parameter_names():
    """Verify that get_parameter_names returns all parameter names in order."""
    params = [
        ParameterSchema(name='p1', annotation=int, default=1, help='h1', is_list=False, is_dict=False),
        ParameterSchema(name='p2', annotation=str, default='s', help='h2', is_list=False, is_dict=False),
    ]
    schema = ProcessorSchema(parameters=params, filter=None)
    assert schema.get_parameter_names() == ['p1', 'p2']


def test_get_parameter_success():
    """Verify that get_parameter returns the correct schema for an existing name."""
    p1 = ParameterSchema(name='p1', annotation=int, default=1, help='h1', is_list=False, is_dict=False)
    p2 = ParameterSchema(name='p2', annotation=str, default='s', help='h2', is_list=False, is_dict=False)
    schema = ProcessorSchema(parameters=[p1, p2], filter=None)

    assert schema.get_parameter('p1') is p1
    assert schema.get_parameter('p2') is p2


def test_get_parameter_failure():
    """Verify that get_parameter raises KeyError for missing parameters."""
    schema = ProcessorSchema(parameters=[], filter=None)
    with pytest.raises(KeyError, match='Parameter unknown not found'):
        schema.get_parameter('unknown')
