#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Unit tests for GUI helpers."""

import pytest

# Skip this module if PySide6 is not available
pytest.importorskip('PySide6', reason='PySide6 is required for GUI tests')

from PySide6.QtCore import QObject

from mafw.steering_gui.utils.gui_helpers import block_signals

pytestmark = pytest.mark.gui


def test_block_signals_context_manager() -> None:
    """Ensure signals are blocked during context and unblocked after."""
    obj1 = QObject()
    obj2 = QObject()

    assert not obj1.signalsBlocked()
    assert not obj2.signalsBlocked()

    with block_signals(obj1, obj2):
        assert obj1.signalsBlocked()
        assert obj2.signalsBlocked()

    assert not obj1.signalsBlocked()
    assert not obj2.signalsBlocked()


def test_block_signals_with_exception() -> None:
    """Ensure signals are unblocked even if an exception occurs."""
    obj = QObject()

    try:
        with block_signals(obj):
            assert obj.signalsBlocked()
            raise RuntimeError('Test exception')
    except RuntimeError:
        pass

    assert not obj.signalsBlocked()
