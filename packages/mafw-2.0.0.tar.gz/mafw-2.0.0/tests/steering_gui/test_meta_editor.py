"""GUI tests covering the metadata summary view."""

#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
from __future__ import annotations

import pytest

pytest.importorskip('PySide6', reason='PySide6 is required for GUI tests')
from PySide6.QtWidgets import QApplication

from mafw.steering_gui.views.meta_editor import MetadataEditor

pytestmark = pytest.mark.gui


@pytest.fixture(scope='session')
def qapp() -> QApplication:
    """Ensure a shared QApplication exists for GUI tests."""

    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def test_update_summary_displays_available_counts(qapp: QApplication) -> None:
    """Ensure configured and available ages appear when plugin data is present."""

    editor = MetadataEditor()
    editor.update_summary('Experiment', 2, 5, 3, 1)

    assert editor._analysis_label.text() == 'Analysis name: Experiment'
    assert editor._processor_label.text() == '2 processors configured.'
    assert editor._available_processors_label.text() == 'Available processor types: 5'
    assert editor._db_modules_label.text() == 'DB modules loaded: 3'
    assert editor._ui_label.text() == 'Available UIs: 1'


def test_update_summary_shows_loading_text(qapp: QApplication) -> None:
    """Ensure the availability rows report the loading state before plugins are ready."""

    editor = MetadataEditor()
    editor.update_summary(None, 0)

    assert editor._analysis_label.text() == 'Analysis name: not set.'
    assert editor._processor_label.text() == 'No processors configured yet.'
    assert editor._available_processors_label.text() == 'Available processors: loading...'
    assert editor._db_modules_label.text() == 'DB modules loaded: loading...'
    assert editor._ui_label.text() == 'Available UIs: loading...'


def test_manual_edit_button_emits_signal(qapp: QApplication) -> None:
    """Ensure the manual edit button triggers its signal."""

    editor = MetadataEditor()
    fired = {'value': False}

    def _mark_fired() -> None:
        fired['value'] = True

    editor.manual_edit_requested.connect(_mark_fired)
    editor._manual_edit_button.click()
    assert fired['value'] is True
