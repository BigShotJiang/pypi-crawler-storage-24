#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
from pathlib import Path

import pytest

pytest.importorskip('PySide6', reason='PySide6 is required for GUI tests')
from PySide6.QtWidgets import QApplication

from mafw.steering_gui.controllers.steering_controller import SteeringController
from mafw.steering_gui.main_window import MainWindow

pytestmark = pytest.mark.gui


@pytest.fixture(scope='session')
def qapp() -> QApplication:
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def test_window_title_updates_on_load(qapp: QApplication, tmp_path: Path) -> None:
    controller = SteeringController()
    window = MainWindow(controller)

    # Initial state
    assert 'Untitled' in window.windowTitle()

    # Create a dummy steering file
    steering_file = tmp_path / 'repro_steering.toml'
    steering_file.write_text("[Globals]\nanalysis_name = 'repro'")

    # Load the file
    window._load_file(steering_file)

    # Verify title updated
    assert 'repro_steering.toml' in window.windowTitle(), (
        f'Expected title to contain repro_steering.toml, but got: {window.windowTitle()}'
    )


def test_window_title_updates_on_new(qapp: QApplication, tmp_path: Path) -> None:
    controller = SteeringController()
    window = MainWindow(controller)

    steering_file = tmp_path / 'repro_steering.toml'
    steering_file.write_text('[Globals]\n')
    window._load_file(steering_file)

    # We expect _load_file to at least set the title, even if it's currently buggy.
    # But for the purpose of testing _new_file, let's assume we want it to go back to Untitled.

    # Manually set a title to simulate a loaded file if _load_file is broken
    window.setWindowTitle('MAFw Steering GUI — repro_steering.toml')

    window._new_file()
    assert 'Untitled' in window.windowTitle(), (
        f'Expected title to contain Untitled after new, but got: {window.windowTitle()}'
    )


def test_window_title_updates_on_save_as(qapp: QApplication, tmp_path: Path, monkeypatch) -> None:
    controller = SteeringController()
    controller.set_validation_level(None)
    window = MainWindow(controller)

    save_file = tmp_path / 'saved_steering.toml'

    # Mock QFileDialog.getSaveFileName to return our save_file path
    from PySide6.QtWidgets import QFileDialog

    monkeypatch.setattr(QFileDialog, 'getSaveFileName', lambda *args, **kwargs: (str(save_file), 'TOML Files (*.toml)'))

    # Make it dirty so we can see if it becomes clean
    controller.set_analysis_name('Something')
    assert '*' in window.windowTitle()

    result = window._perform_save_as()
    assert result is True
    assert 'saved_steering.toml' in window.windowTitle()
    assert '*' not in window.windowTitle()


def test_window_title_updates_on_save(qapp: QApplication, tmp_path: Path) -> None:
    controller = SteeringController()
    controller.set_validation_level(None)
    window = MainWindow(controller)

    steering_file = tmp_path / 'repro_steering.toml'
    steering_file.write_text('[Globals]\n')
    window._load_file(steering_file)

    # Make it dirty
    controller.set_analysis_name('Something else')
    assert '*' in window.windowTitle()

    # Perform save
    result = window._perform_save()
    assert result is True
    assert '*' not in window.windowTitle()


def test_window_icon_is_set(qapp: QApplication) -> None:
    """Verify that the MainWindow has a valid icon set."""
    window = MainWindow()
    assert not window.windowIcon().isNull(), 'MainWindow should have an icon set'
