#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Unit tests for the ModelFilterEditor.

:Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
:Description: Verify that ModelFilterEditor correctly reflects and updates
              ModelFilterConfig and emits action signals.
"""

from __future__ import annotations

import pytest

pytest.importorskip('PySide6', reason='PySide6 is required for GUI tests')
from PySide6.QtCore import QModelIndex
from PySide6.QtWidgets import QApplication

from mafw.steering.models import (
    Condition,
    ConditionalFilterConfig,
    FieldFilterConfig,
    ModelFilterConfig,
    ProcessorConfig,
)
from mafw.steering_gui.views.filter_editors import ModelFilterEditor

pytestmark = pytest.mark.gui


@pytest.fixture(scope='session')
def qapp() -> QApplication:
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def test_model_filter_editor_ui_initialization(qapp: QApplication) -> None:
    editor = ModelFilterEditor()
    config = ProcessorConfig(name='TestProc')
    model_config = ModelFilterConfig(name='ModelA', model='ModelA', enabled=True)
    model_config.conditions['c1'] = Condition('==', 1)
    model_config.logic = 'c1'

    # Add some other filters for stats
    config.filters['ModelA'] = [
        model_config,
        FieldFilterConfig(name='f1', model='ModelA', field_name='f1'),
        ConditionalFilterConfig(name='cnd1', model='ModelA'),
    ]

    index = QModelIndex()  # Dummy index
    editor.set_config(model_config, config, index)

    assert 'ModelA' in editor._title_label.text()
    assert editor._enable_check.isChecked() is True
    assert 'Number of conditions: 1' in editor._info_conditions.text()
    assert 'Number of field filters: 1' in editor._info_fields.text()
    assert 'Number of conditional filters: 1' in editor._info_conditionals.text()
    assert 'Custom logic statement: True' in editor._info_logic.text()
    assert editor._add_logic_btn.isHidden() is False


def test_model_filter_editor_enable_toggle(qapp: QApplication) -> None:
    editor = ModelFilterEditor()
    model_config = ModelFilterConfig(name='ModelA', model='ModelA', enabled=True)
    config = ProcessorConfig(name='TestProc', filters={'ModelA': [model_config]})

    editor.set_config(model_config, config, QModelIndex())

    received = []
    editor.filter_changed.connect(lambda: received.append(True))

    editor._enable_check.setChecked(False)
    assert model_config.enabled is False
    assert received == [True]


def test_model_filter_editor_signals(qapp: QApplication) -> None:
    editor = ModelFilterEditor()
    model_config = ModelFilterConfig(name='ModelA', model='ModelA')
    config = ProcessorConfig(name='TestProc', filters={'ModelA': [model_config]})
    index = QModelIndex()

    editor.set_config(model_config, config, index)

    signals_received = {
        'cond': False,
        'field': False,
        'logic': False,
        'remove': False,
    }

    editor.add_condition_requested.connect(lambda idx: signals_received.update({'cond': True}))
    editor.add_field_filter_requested.connect(lambda idx: signals_received.update({'field': True}))
    editor.add_logic_requested.connect(lambda idx: signals_received.update({'logic': True}))
    editor.remove_requested.connect(lambda idx: signals_received.update({'remove': True}))

    editor._add_cond_btn.click()
    assert signals_received['cond'] is True

    editor._add_field_btn.click()
    assert signals_received['field'] is True

    editor._add_logic_btn.click()
    assert signals_received['logic'] is True

    editor._remove_btn.click()
    assert signals_received['remove'] is True


def test_model_filter_editor_with_str_data(qapp: QApplication) -> None:
    """Verify editor behavior when data is just a model name (str)."""
    editor = ModelFilterEditor()
    config = ProcessorConfig(name='TestProc', filters={'ModelA': []})
    index = QModelIndex()

    editor.set_config('ModelA', config, index)

    assert 'ModelA' in editor._title_label.text()
    assert editor._enable_check.isEnabled() is False
    assert editor._add_cond_btn.isEnabled() is False
    assert editor._add_logic_btn.isHidden() is False
