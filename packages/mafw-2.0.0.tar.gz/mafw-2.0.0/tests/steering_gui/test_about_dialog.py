#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
import pytest

pytest.importorskip('PySide6', reason='PySide6 is required for GUI tests')
from PySide6.QtWidgets import QApplication

from mafw.steering_gui.dialogs.about_dialog import AboutDialog

pytestmark = pytest.mark.gui


@pytest.fixture(scope='session')
def qapp() -> QApplication:
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def test_about_dialog_width(qapp: QApplication) -> None:
    dialog = AboutDialog()
    assert dialog.minimumWidth() != 500, 'AboutDialog should not have a fixed minimum width of 500'
