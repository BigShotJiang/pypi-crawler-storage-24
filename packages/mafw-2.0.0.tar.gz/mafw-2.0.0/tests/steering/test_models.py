#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Unit tests for steering domain models."""

from mafw.steering.models import (
    Condition,
    ConditionalFilterConfig,
    FieldFilterConfig,
    ModelFilterConfig,
    ProcessorConfig,
    _field_type_from_peewee,
    _normalize_field_type,
)


def test_models_setters_coverage():
    """Cover logic and filter_logic setters in models.py."""
    # 1. ModelFilterConfig
    mfc = ModelFilterConfig(name='Model', model='Model')
    mfc.logic = 'a AND b'
    assert mfc.logic_ast is not None
    mfc.logic = 'INVALID('
    assert mfc.logic_ast is None
    mfc.logic = None
    assert mfc.logic_ast is None

    # 2. FieldFilterConfig
    ffc = FieldFilterConfig(name='Field', model='Model', field_name='Field')
    ffc.logic = 'INVALID('
    assert ffc.logic_ast is None
    ffc.logic = None
    assert ffc.logic_ast is None
    # Coverage for getter
    assert ffc.logic is None

    # 3. ProcessorConfig
    pc = ProcessorConfig(name='Proc')
    pc.filter_logic = 'a AND b'
    assert pc.filter_logic == 'a AND b'
    assert pc.logic_ast is not None
    pc.filter_logic = 'INVALID('
    assert pc.filter_logic == 'INVALID('
    assert pc.logic_ast is None
    pc.filter_logic = None
    assert pc.filter_logic is None
    assert pc.logic_ast is None


def test_models_getters():
    """Cover logic and filter_logic getters explicitly."""
    mfc = ModelFilterConfig(name='Model', model='Model')
    mfc.logic = 'test'
    assert mfc.logic == 'test'

    pc = ProcessorConfig(name='Proc')
    pc.filter_logic = 'test'
    assert pc.filter_logic == 'test'


def test_normalize_field_type_paths():
    """Cover various paths in _normalize_field_type."""
    assert _normalize_field_type(int) is int
    assert _normalize_field_type(float) is float
    assert _normalize_field_type(str) is str
    assert _normalize_field_type(bool) is bool

    assert _normalize_field_type('INT') is int
    assert _normalize_field_type('FLOAT') is float
    assert _normalize_field_type('STRING') is str
    assert _normalize_field_type('BOOLEAN') is bool
    assert _normalize_field_type('UNKNOWN') is str
    assert _normalize_field_type(None) is str


def test_field_type_from_peewee_paths():
    """Cover various paths in _field_type_from_peewee."""

    class DummyField:
        def __init__(self, field_type=None, data_type=None):
            if field_type:
                self.field_type = field_type
            if data_type:
                self.data_type = data_type

    assert _field_type_from_peewee(DummyField(field_type='INT')) is int
    assert _field_type_from_peewee(DummyField(data_type='FLOAT')) is float
    assert _field_type_from_peewee(DummyField()) is str


def test_fill_model_info_edge_cases():
    """Cover edge cases in fill_model_info."""
    # model not set
    mfc = ModelFilterConfig(name='test')
    mfc.model = ''
    mfc.fill_model_info()
    assert mfc.model_info is None

    # model not found (KeyError handled by try-except)
    mfc.model = 'NON_EXISTENT_MODEL'
    mfc.fill_model_info()
    assert mfc.model_info is None


def test_conditional_filter_config_fill_model_info_empty_model():
    """Cover line 213 in ConditionalFilterConfig.fill_model_info."""
    from mafw.steering.models import ConditionalFilterConfig

    cfc = ConditionalFilterConfig(name='test', model='')
    cfc.fill_model_info()
    assert cfc.model_info is None


def test_conditional_filter_is_complete() -> None:
    """Test all branches of ConditionalFilterConfig.is_complete."""
    # 1. Missing condition
    cf = ConditionalFilterConfig(name='test', model='ModelA')
    assert cf.is_complete() is False

    # 2. Invalid condition
    cf.condition = Condition(operator='==', value=1, is_valid=False)
    assert cf.is_complete() is False

    # 3. Valid condition, missing then_clause
    cf.condition = Condition(operator='==', value=1, is_valid=True)
    assert cf.is_complete() is False

    # 4. Invalid then_clause
    cf.then_clause = Condition(operator='==', value=2, is_valid=False)
    assert cf.is_complete() is False

    # 5. Valid condition and then_clause, no else_clause
    cf.then_clause = Condition(operator='==', value=2, is_valid=True)
    assert cf.is_complete() is True

    # 6. Invalid else_clause
    cf.else_clause = Condition(operator='==', value=3, is_valid=False)
    assert cf.is_complete() is False

    # 7. All valid
    cf.else_clause = Condition(operator='==', value=3, is_valid=True)
    assert cf.is_complete() is True
