#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Group helpers and validation."""

from mafw.mafw_errors import CyclicGroupIssue
from mafw.steering.builder import SteeringBuilder
from mafw.steering.validation import validate


def test_group_registration_and_lookup() -> None:
    builder = SteeringBuilder()
    builder.add_processor('Base')
    builder.add_group('Pipeline', ['Base'], 'test')

    assert 'Pipeline' in builder.list_groups()
    group = builder.get_group('Pipeline')
    assert group.processors == ['Base']
    assert group.description == 'test'


def test_cycle_detection_raises() -> None:
    builder = SteeringBuilder()
    builder.add_processor('Base')
    builder.add_group('LoopA', ['LoopB'])
    builder.add_group('LoopB', ['LoopA'])
    builder.globals.processors_to_run = ['LoopA']

    issues = validate(builder)
    assert any(isinstance(issue, CyclicGroupIssue) for issue in issues)
