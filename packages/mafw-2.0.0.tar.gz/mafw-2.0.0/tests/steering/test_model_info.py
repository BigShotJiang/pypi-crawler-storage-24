#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Unit tests for ModelInfo and its population in ModelFilterConfig."""

from peewee import AutoField, BooleanField, FloatField, IntegerField, TextField

from mafw.db.db_model import MAFwBaseModel, mafw_model_register
from mafw.steering.models import ModelFilterConfig


class ModelForTest(MAFwBaseModel):
    """A dummy model for testing ModelInfo."""

    id = AutoField(primary_key=True)
    name = TextField(help_text='The name field')
    count = IntegerField()
    ratio = FloatField()
    active = BooleanField()


def test_model_info_population():
    """Verify that ModelFilterConfig populates model_info if model is registered."""
    # Ensure it's registered (it should be automatically happening!!!)
    mafw_model_register.register_model('model_for_test', ModelForTest)

    mfc = ModelFilterConfig(name='test', model='model_for_test')
    assert mfc.model_info is not None
    assert 'id' in mfc.model_info.field_info
    assert 'name' in mfc.model_info.field_info
    assert mfc.model_info.field_info['name'].type is str
    assert mfc.model_info.field_info['name'].help_text == 'The name field'
    assert mfc.model_info.field_info['count'].type is int
    assert mfc.model_info.field_info['ratio'].type is float
    assert mfc.model_info.field_info['active'].type is bool


def test_model_info_empty_for_missing_model():
    """Verify that ModelFilterConfig has None model_info for unregistered model."""
    mfc = ModelFilterConfig(name='test', model='unregistered_model')
    assert mfc.model_info is None
