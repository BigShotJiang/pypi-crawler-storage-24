#  Copyright 2026 European Union
#  Author: Bulgheroni Antonio (antonio.bulgheroni@ec.europa.eu)
#  SPDX-License-Identifier: EUPL-1.2
"""Replica and filter helpers."""

from mafw.steering.builder import SteeringBuilder
from mafw.steering.models import ConditionalFilterConfig, ModelFilterConfig


def test_filter_fields_and_conditionals() -> None:
    builder = SteeringBuilder()
    builder.add_processor('FilterProcessor')
    builder.set_filter_field('FilterProcessor', 'ModelA', 'field', 'value')
    builder.set_filter_logic('FilterProcessor', 'field')
    builder.set_filter_conditionals(
        'FilterProcessor',
        'ModelA',
        [{'condition_field': 'field', 'condition_op': 'eq', 'condition_value': 1}],
    )

    proc = builder.get_processor_config('FilterProcessor')

    model_filters = proc.filters['ModelA']
    model_config = next(f for f in model_filters if isinstance(f, ModelFilterConfig))
    assert model_config.conditions['field'].value == 'value'

    assert any(isinstance(f, ConditionalFilterConfig) for f in model_filters)
    assert proc.filter_logic == 'field'


def test_remove_replica_reference() -> None:
    builder = SteeringBuilder()
    builder.add_processor('Replicated')
    builder.add_replica('Replicated', '001')
    builder.remove_processor('Replicated#001')

    assert builder.globals.processors_to_run == ['Replicated']
