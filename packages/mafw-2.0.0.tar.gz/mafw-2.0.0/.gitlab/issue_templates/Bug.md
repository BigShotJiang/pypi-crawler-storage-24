## 📝 Bug Description
## 👣 Steps to Reproduce
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

## 💥 Current Behavior
## ✅ Expected Behavior
## 🖼 Screenshots / Logs
## 💻 Environment
- **Browser/OS:** [e.g. Chrome 120 / macOS]
- **Environment:** [e.g. Staging, Production]
- **Version/Tag:** [e.g. v1.2.3]

---
/label ~"type::bug" ~"status::triage"