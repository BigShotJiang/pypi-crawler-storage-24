## 💡 Idea definition
## 🚀 Proposed Solution (Optional)
## 🎯 Use Case / Value
## 🛠 Possible Implementation (Optional)
## 🎨 Design / Mockups (Optional)
---
/label ~"type::idea" ~"status::discussion"