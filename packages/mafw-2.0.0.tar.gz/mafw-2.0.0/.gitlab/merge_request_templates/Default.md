## 📝 Description
## 🎯 Proposed Changes
(include here a list of all the features / fixes and refactors that have been included in the branch)
- [ ] Feature:
- [ ] ...
- [ ] Fix:
- [ ] ...
- [ ] Refactoring:
- [ ] ...

## 🧪 How to Test
1. Checkout this branch: `git checkout <branch-name>`
2. Run the build: `hatch test`
3. Steps to reproduce/verify: 
   - [ ] Step A
   - [ ] Step B

## 📸 Screenshots / Recordings
## 🛠 Technical Debt / Considerations
## ✅ Checklist
- [ ] My code follows the style guidelines of this project.
- [ ] My code follows the general architectural prescription of MVC with separation of concern.
- [ ] I have performed a self-review of my own code.
- [ ] I have added tests that prove my fix is effective or that my feature works.
- [ ] New and existing unit tests pass locally with my changes.
- [ ] I have commented on my code, particularly in hard-to-understand areas.

---
/unlabel ~"status::doing"