# Release ${TAG}

## 📝 Description
<!-- 
Provide a high-level summary of this release. 
Highlight major changes, improvements, and any breaking changes.
-->

## 🚀 New Features
<!-- 
List of new features added in this release.
Copy relevant entries from CHANGELOG.md or generate using the project's changelog tool.
Format: * (scope): description of feature
-->

## 🐛 Bug Fixes
<!-- 
List of bug fixes included in this release.
Format: * (scope): description of fix
-->

## ♻️ Refactorings
<!-- 
List of code refactorings and cleanup.
Format: * (scope): description of change
-->

## 📚 Documentation
<!-- 
List of documentation updates.
-->

## 🔧 Other Changes
<!-- 
List of other changes (dependencies, build scripts, etc.).
-->

## 👥 Contributors
<!-- 
Thank the contributors who worked on this release.
-->

## 📊 Statistics
<!-- 
Optional: Add stats like commit count, files changed, etc.
-->
