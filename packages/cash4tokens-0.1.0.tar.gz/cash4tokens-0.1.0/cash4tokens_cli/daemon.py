"""cash4tokens daemon - orchestrates WebSocket connection, heartbeats, and inference."""

from __future__ import annotations

import asyncio
import logging
import platform
import time
from typing import Callable

from .app_version import get_cash4tokens_version
from .connection import DaemonConnection
from .health import DaemonHealth
from .provider.anthropic import AnthropicProvider
from .provider.openai_provider import OpenAIProvider
from .update import UpdateManager, restart_current_process

log = logging.getLogger("cash4tokens.daemon")

HEARTBEAT_INTERVAL_S = 30
UPDATE_POLL_INTERVAL_S = 300


class Cash4TokensDaemon:
    """Main daemon process that connects to the server and serves inference requests."""

    def __init__(
        self,
        config: dict,
        save_config: Callable[[dict], None] | None = None,
    ) -> None:
        self.config = config
        self.server_url = config["server_url"]
        self.daemon_token = config["daemon_token"]
        self.provider_id = config["provider_id"]
        self.machine_name = platform.node() or "provider"
        self.daemon_version = get_cash4tokens_version()
        self.update_manager = UpdateManager(config, save_config)

        self.health = DaemonHealth(provider_id=self.provider_id)
        self.connection = DaemonConnection(
            server_url=self.server_url,
            auth_message_factory=self._build_auth_message,
            on_message=self._handle_message,
        )

        self._anthropic = AnthropicProvider()
        self._openai = OpenAIProvider()

    async def run(self) -> None:
        """Start the daemon: connect, heartbeat, and handle requests."""
        log.info(
            "cash4tokens daemon starting (provider: %s, version: %s)",
            self.provider_id,
            self.daemon_version,
        )

        await self._maybe_apply_update(force=False)

        # Auto-detect available providers
        providers = []
        if await self._anthropic.is_available():
            providers.append("anthropic (Claude Code)")
        if await self._openai.is_available():
            providers.append("openai (Codex)")

        if not providers:
            log.warning(
                "No provider credentials found. Daemon will wait for credentials."
            )
        else:
            log.info("Detected providers: %s", ", ".join(providers))

        # Run connection and heartbeat concurrently
        await asyncio.gather(
            self.connection.connect(),
            self._heartbeat_loop(),
            self._update_loop(),
        )

    async def _build_auth_message(self) -> dict:
        """Build the websocket auth message sent on every connect."""
        return {
            "type": "auth",
            "token": self.daemon_token,
            "machine_name": self.machine_name,
            "daemon_version": self.daemon_version,
            "base_wallet_address": self.config.get("wallet_address", ""),
            "capability": await self.health.collect_capabilities(),
        }

    async def _heartbeat_loop(self) -> None:
        """Send periodic heartbeats to the server."""
        while True:
            await asyncio.sleep(HEARTBEAT_INTERVAL_S)
            try:
                heartbeat = await self.health.build_heartbeat()
                sent = await self.connection.send(heartbeat)
                if sent:
                    log.debug(
                        "Heartbeat sent (load: %d/%d)",
                        self.health.current_load,
                        self.health.max_concurrent,
                    )
            except Exception as e:
                log.error("Heartbeat error: %s", e)

    async def _update_loop(self) -> None:
        """Check the release manifest periodically and update when idle."""
        while True:
            await asyncio.sleep(UPDATE_POLL_INTERVAL_S)
            try:
                await self._maybe_apply_update(force=False)
            except Exception as e:
                log.error("Auto-update loop error: %s", e)

    async def _handle_message(self, msg: dict) -> None:
        """Route incoming server messages."""
        msg_type = msg.get("type")

        if msg_type == "inference_request":
            asyncio.create_task(self._handle_inference(msg))
        elif msg_type == "ping":
            await self.connection.send({"type": "pong"})
        elif msg_type == "config_update":
            self._apply_config(msg)
        elif msg_type == "error":
            log.error(
                "Server error: %s", msg.get("error") or msg.get("message") or "unknown"
            )
        else:
            log.debug("Unknown message type: %s", msg_type)

    async def _handle_inference(self, msg: dict) -> None:
        """Process an inference request from the server."""
        request_id = msg.get("request_id", "unknown")
        vendor = msg.get("vendor", "anthropic")
        model = msg.get("model", "")
        body = msg.get("body", {})

        log.info("Inference request %s: %s/%s", request_id, vendor, model)
        self.health.current_load += 1
        start = time.time()

        try:
            provider = self._anthropic if vendor == "anthropic" else self._openai

            async for chunk in provider.stream_inference(request_id, model, body):
                await self.connection.send(chunk)

        except Exception as e:
            log.error("Inference error for %s: %s", request_id, e)
            await self.connection.send(
                {
                    "type": "stream_error",
                    "request_id": request_id,
                    "error": str(e),
                }
            )

        finally:
            self.health.current_load -= 1
            elapsed_ms = (time.time() - start) * 1000
            self.health.record_latency(elapsed_ms)
            log.info("Request %s completed in %.0fms", request_id, elapsed_ms)

    def _apply_config(self, msg: dict) -> None:
        """Apply runtime config updates from server."""
        if "max_concurrent" in msg:
            self.health.max_concurrent = msg["max_concurrent"]
            log.info("Max concurrent updated to %d", msg["max_concurrent"])

    async def _maybe_apply_update(self, force: bool) -> None:
        """Install and restart into the latest CLI build when safe."""
        result = await asyncio.to_thread(self.update_manager.check_for_update, force)
        if result.status in {
            "not_due",
            "up_to_date",
            "local_install",
            "unknown_version",
        }:
            if result.status == "local_install":
                log.debug(result.message)
            return

        if result.status == "check_failed":
            log.warning(result.message)
            return

        if result.status != "update_available" or not result.manifest:
            return

        if self.health.current_load > 0:
            log.info(
                "CLI update %s is available but the daemon is busy. Will retry when idle.",
                result.latest_version,
            )
            return

        install_result = await asyncio.to_thread(
            self.update_manager.install_update,
            result.manifest,
        )
        if install_result.applied:
            log.info("%s Restarting daemon.", install_result.message)
            await self.connection.close()
            restart_current_process()

        if install_result.required:
            raise RuntimeError(install_result.message)

        log.warning(install_result.message)
