"""Extract and refresh Claude Code OAuth tokens from macOS Keychain."""

from __future__ import annotations

import json
import logging
import subprocess
import time

import httpx

log = logging.getLogger("cash4tokens.token.claude")

# Claude Code OAuth client ID (public, embedded in the CLI binary)
CLAUDE_OAUTH_TOKEN_URL = "https://platform.claude.com/v1/oauth/token"

# Keychain service patterns
KEYCHAIN_SERVICE_PREFIX = "Claude Code-credentials"


def _find_keychain_entry() -> str | None:
    """Find the Claude Code credentials service name in keychain."""
    try:
        result = subprocess.run(
            ["security", "dump-keychain"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        for line in result.stdout.splitlines():
            if KEYCHAIN_SERVICE_PREFIX in line and "svce" in line:
                # Extract service name between quotes
                parts = line.split('"')
                for p in parts:
                    if p.startswith(KEYCHAIN_SERVICE_PREFIX):
                        return p
    except Exception as e:
        log.warning("Failed to search keychain: %s", e)
    return None


def _read_keychain(service: str, account: str | None = None) -> str | None:
    """Read a password from macOS keychain."""
    cmd = ["security", "find-generic-password", "-s", service, "-w"]
    if account:
        cmd.extend(["-a", account])
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception as e:
        log.warning("Keychain read failed: %s", e)
    return None


def get_claude_credential() -> dict | None:
    """Extract Claude Code OAuth credentials from keychain.

    Returns dict with keys: accessToken, refreshToken, expiresAt,
    subscriptionType, rateLimitTier. Or None if not found.
    """
    service = _find_keychain_entry()
    if not service:
        log.info("No Claude Code keychain entry found")
        return None

    raw = _read_keychain(service)
    if not raw:
        log.warning("Could not read Claude Code credentials from keychain")
        return None

    try:
        data = json.loads(raw)
        # Navigate to the OAuth token data
        oauth = data.get("claudeAiOauth") or data
        if "accessToken" not in oauth:
            log.warning("No accessToken in keychain data")
            return None
        return oauth
    except json.JSONDecodeError:
        log.warning("Invalid JSON in keychain entry")
        return None


def is_token_valid(cred: dict, buffer_s: int = 600) -> bool:
    """Check if the access token is still valid (with buffer)."""
    expires_at = cred.get("expiresAt", 0)
    # expiresAt is in milliseconds
    if isinstance(expires_at, (int, float)) and expires_at > 1e12:
        expires_at = expires_at / 1000
    return time.time() < expires_at - buffer_s


async def refresh_token(cred: dict) -> dict | None:
    """Refresh the Claude OAuth token. Returns new credentials or None."""
    refresh = cred.get("refreshToken")
    if not refresh:
        log.warning("No refresh token available")
        return None

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                CLAUDE_OAUTH_TOKEN_URL,
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=30,
            )
            if resp.status_code == 200:
                new_data = resp.json()
                log.info("Claude token refreshed successfully")
                return new_data
            else:
                log.warning(
                    "Token refresh failed: %s %s", resp.status_code, resp.text[:200]
                )
                return None
    except Exception as e:
        log.error("Token refresh error: %s", e)
        return None


async def get_valid_token() -> str | None:
    """Get a valid Claude access token, refreshing if needed."""
    cred = get_claude_credential()
    if cred is None:
        return None

    if is_token_valid(cred):
        return cred["accessToken"]

    # Try refresh
    new_cred = await refresh_token(cred)
    if new_cred and "accessToken" in new_cred:
        return new_cred["accessToken"]

    # Return old token as last resort (might still work briefly)
    return cred.get("accessToken")


def get_subscription_info() -> dict:
    """Get subscription type and rate limit tier."""
    cred = get_claude_credential()
    if cred is None:
        return {"subscription_type": "unknown", "rate_limit_tier": "unknown"}
    return {
        "subscription_type": cred.get("subscriptionType", "unknown"),
        "rate_limit_tier": cred.get("rateLimitTier", "unknown"),
    }
