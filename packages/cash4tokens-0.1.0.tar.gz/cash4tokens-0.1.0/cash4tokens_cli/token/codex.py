"""Extract and refresh Codex/OpenAI OAuth tokens from ~/.codex/auth.json."""

from __future__ import annotations

import base64
import json
import logging
import time
from pathlib import Path

import httpx

log = logging.getLogger("cash4tokens.token.codex")

AUTH_FILE = Path.home() / ".codex" / "auth.json"
OPENAI_TOKEN_URL = "https://auth.openai.com/oauth/token"


def _decode_jwt_payload(token: str) -> dict:
    """Decode JWT payload without verification (just to check exp)."""
    try:
        parts = token.split(".")
        if len(parts) < 2:
            return {}
        # Add padding
        payload = parts[1]
        payload += "=" * (4 - len(payload) % 4)
        decoded = base64.urlsafe_b64decode(payload)
        return json.loads(decoded)
    except Exception:
        return {}


def get_codex_credential() -> dict | None:
    """Read Codex credentials from auth.json.

    Returns dict with keys: id_token, access_token, refresh_token, account_id.
    Or None if not found.
    """
    if not AUTH_FILE.exists():
        log.info("No Codex auth file found at %s", AUTH_FILE)
        return None

    try:
        data = json.loads(AUTH_FILE.read_text())
        tokens = data.get("tokens")
        if not tokens or "access_token" not in tokens:
            log.warning("No access_token in codex auth.json")
            return None
        return tokens
    except (json.JSONDecodeError, OSError) as e:
        log.warning("Failed to read codex auth.json: %s", e)
        return None


def is_token_valid(tokens: dict, buffer_s: int = 600) -> bool:
    """Check if the access token is still valid (with buffer)."""
    access = tokens.get("access_token", "")
    payload = _decode_jwt_payload(access)
    exp = payload.get("exp", 0)
    if not exp:
        # Can't determine expiry - assume it needs refresh
        return False
    return time.time() < exp - buffer_s


async def refresh_token(tokens: dict) -> dict | None:
    """Refresh the Codex OAuth token via token exchange. Returns new tokens or None."""
    id_token = tokens.get("id_token")
    if not id_token:
        log.warning("No id_token available for refresh")
        return None

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                OPENAI_TOKEN_URL,
                data={
                    "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
                    "subject_token": id_token,
                    "subject_token_type": "urn:ietf:params:oauth:token-type:id_token",
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=30,
            )
            if resp.status_code == 200:
                new_data = resp.json()
                # Update auth.json
                _update_auth_file(tokens, new_data)
                log.info("Codex token refreshed successfully")
                return {
                    **tokens,
                    "access_token": new_data.get(
                        "access_token", tokens["access_token"]
                    ),
                    "id_token": new_data.get("id_token", tokens["id_token"]),
                }
            else:
                log.warning(
                    "Codex token refresh failed: %s %s",
                    resp.status_code,
                    resp.text[:200],
                )
                return None
    except Exception as e:
        log.error("Codex token refresh error: %s", e)
        return None


def _update_auth_file(old_tokens: dict, new_data: dict) -> None:
    """Update ~/.codex/auth.json with refreshed tokens."""
    try:
        data = json.loads(AUTH_FILE.read_text())
        if new_data.get("access_token"):
            data["tokens"]["access_token"] = new_data["access_token"]
        if new_data.get("id_token"):
            data["tokens"]["id_token"] = new_data["id_token"]
        from datetime import datetime, timezone

        data["last_refresh"] = datetime.now(timezone.utc).isoformat()
        AUTH_FILE.write_text(json.dumps(data, indent=2))
    except Exception as e:
        log.warning("Failed to update codex auth.json: %s", e)


async def get_valid_token() -> str | None:
    """Get a valid Codex access token, refreshing if needed."""
    tokens = get_codex_credential()
    if tokens is None:
        return None

    if is_token_valid(tokens):
        return tokens["access_token"]

    new_tokens = await refresh_token(tokens)
    if new_tokens and "access_token" in new_tokens:
        return new_tokens["access_token"]

    return tokens.get("access_token")


def get_subscription_info() -> dict:
    """Get subscription info (basic - Codex doesn't expose tier in auth file)."""
    tokens = get_codex_credential()
    if tokens is None:
        return {"subscription_type": "unknown"}

    # Try to infer from JWT claims
    payload = _decode_jwt_payload(tokens.get("access_token", ""))
    return {
        "subscription_type": "codex_pro" if tokens.get("account_id") else "unknown",
        "account_id": tokens.get("account_id"),
    }
