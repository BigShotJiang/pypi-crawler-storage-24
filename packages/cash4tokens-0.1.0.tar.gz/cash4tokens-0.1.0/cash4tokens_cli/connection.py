"""WebSocket client with automatic reconnection for daemon-to-server communication."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable, Coroutine

import websockets
from websockets.asyncio.client import ClientConnection

log = logging.getLogger("cash4tokens.connection")

# Reconnect backoff
INITIAL_BACKOFF_S = 1
MAX_BACKOFF_S = 60


class DaemonConnection:
    """Manages the WebSocket connection from daemon to central server."""

    def __init__(
        self,
        server_url: str,
        auth_message_factory: Callable[[], Coroutine[Any, Any, dict]],
        on_message: Callable[[dict], Coroutine[Any, Any, None]],
    ) -> None:
        ws_scheme = "wss" if server_url.startswith("https") else "ws"
        http_stripped = server_url.replace("https://", "").replace("http://", "")
        self.ws_url = f"{ws_scheme}://{http_stripped}/ws/daemon"
        self.auth_message_factory = auth_message_factory
        self.on_message = on_message
        self._ws: ClientConnection | None = None
        self._running = False

    async def connect(self) -> None:
        """Connect to server with automatic reconnection."""
        self._running = True
        backoff = INITIAL_BACKOFF_S

        while self._running:
            try:
                log.info("Connecting to %s", self.ws_url)
                async with websockets.connect(
                    self.ws_url,
                    ping_interval=20,
                    ping_timeout=10,
                    close_timeout=5,
                ) as ws:
                    self._ws = ws
                    backoff = INITIAL_BACKOFF_S

                    # Send auth message
                    auth_message = await self.auth_message_factory()
                    await ws.send(json.dumps(auth_message))
                    log.info("Connected and authenticated")

                    # Listen for messages
                    async for raw in ws:
                        try:
                            msg = json.loads(raw)
                            await self.on_message(msg)
                        except json.JSONDecodeError:
                            log.warning("Received non-JSON message: %s", raw[:100])
                        except Exception as e:
                            log.error("Error handling message: %s", e)

            except websockets.ConnectionClosed as e:
                log.warning("Connection closed: %s", e)
            except (OSError, ConnectionRefusedError) as e:
                log.warning("Connection failed: %s", e)
            except Exception as e:
                log.error("Unexpected connection error: %s", e)

            self._ws = None
            if self._running:
                log.info("Reconnecting in %ds...", backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, MAX_BACKOFF_S)

    async def send(self, data: dict) -> bool:
        """Send a JSON message to the server. Returns True on success."""
        if not self._ws:
            log.warning("Cannot send - not connected")
            return False
        try:
            await self._ws.send(json.dumps(data))
            return True
        except Exception as e:
            log.error("Send failed: %s", e)
            return False

    async def close(self) -> None:
        """Gracefully close the connection."""
        self._running = False
        if self._ws:
            await self._ws.close()
            self._ws = None
