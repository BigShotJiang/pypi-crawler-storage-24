"""Anthropic provider - calls Claude API using local OAuth tokens."""

from __future__ import annotations

import json
import logging
import time
from typing import AsyncIterator

import httpx

from .base import BaseProvider
from ..token.claude import get_subscription_info, get_valid_token

log = logging.getLogger("cash4tokens.provider.anthropic")

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"

# Model families available per subscription type
SUBSCRIPTION_MODEL = {
    "max": ["claude-opus-4", "claude-sonnet-4", "claude-haiku-4"],
    "pro": ["claude-sonnet-4", "claude-haiku-4"],
    "team": ["claude-sonnet-4", "claude-haiku-4"],
    "free": ["claude-haiku-4"],
}


def _openai_to_anthropic(body: dict) -> dict:
    """Convert OpenAI chat completion request to Anthropic messages format."""
    messages = body.get("messages", [])
    system_part: list[str] = []
    anthropic_msg: list[dict] = []

    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "")
        if role in ("system", "developer"):
            if content:
                system_part.append(
                    content if isinstance(content, str) else str(content)
                )
        elif role == "user":
            anthropic_msg.append({"role": "user", "content": content})
        elif role == "assistant":
            anthropic_msg.append({"role": "assistant", "content": content})
        elif role == "tool":
            anthropic_msg.append({"role": "user", "content": content})

    # Merge consecutive same-role messages (Anthropic requires alternation)
    merged: list[dict] = []
    for m in anthropic_msg:
        if merged and merged[-1]["role"] == m["role"]:
            merged[-1]["content"] = f"{merged[-1]['content']}\n\n{m['content']}"
        else:
            merged.append(m)

    result: dict = {
        "model": body.get("model", "claude-sonnet-4-5-20250929"),
        "messages": merged,
        "max_tokens": body.get("max_tokens") or 4096,
        "stream": True,
    }

    if system_part:
        result["system"] = "\n\n".join(system_part)
    if body.get("temperature") is not None:
        result["temperature"] = body["temperature"]
    if body.get("top_p") is not None:
        result["top_p"] = body["top_p"]
    if body.get("stop"):
        stop = body["stop"]
        result["stop_sequences"] = stop if isinstance(stop, list) else [stop]

    return result


def _anthropic_chunk_to_openai(data: dict, request_id: str, model: str) -> dict | None:
    """Convert Anthropic SSE event to OpenAI streaming chunk."""
    event_type = data.get("type")

    if event_type == "content_block_delta":
        delta = data.get("delta", {})
        if delta.get("type") == "text_delta":
            return {
                "id": f"chatcmpl-{request_id}",
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": model,
                "choices": [
                    {
                        "index": 0,
                        "delta": {"content": delta["text"]},
                        "finish_reason": None,
                    }
                ],
            }

    elif event_type == "message_start":
        return {
            "id": f"chatcmpl-{request_id}",
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": model,
            "choices": [
                {
                    "index": 0,
                    "delta": {"role": "assistant"},
                    "finish_reason": None,
                }
            ],
        }

    elif event_type == "message_delta":
        stop_reason = data.get("delta", {}).get("stop_reason")
        if stop_reason:
            return {
                "id": f"chatcmpl-{request_id}",
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": model,
                "choices": [
                    {
                        "index": 0,
                        "delta": {},
                        "finish_reason": "stop"
                        if stop_reason == "end_turn"
                        else stop_reason,
                    }
                ],
            }

    return None


class AnthropicProvider(BaseProvider):
    async def is_available(self) -> bool:
        token = await get_valid_token()
        return token is not None

    async def get_capability(self) -> dict:
        info = get_subscription_info()
        sub_type = info.get("subscription_type", "unknown")
        model_family = SUBSCRIPTION_MODEL.get(sub_type, ["claude-haiku-4"])

        return {
            "vendor": "anthropic",
            "subscription_type": sub_type,
            "rate_limit_tier": info.get("rate_limit_tier"),
            "model_family": model_family,
        }

    async def stream_inference(
        self, request_id: str, model: str, body: dict
    ) -> AsyncIterator[dict]:
        token = await get_valid_token()
        if not token:
            yield {
                "type": "stream_error",
                "request_id": request_id,
                "error": "Claude token unavailable",
            }
            return

        anthropic_body = _openai_to_anthropic(body)
        input_token = 0
        output_token = 0

        try:
            async with httpx.AsyncClient() as client:
                async with client.stream(
                    "POST",
                    ANTHROPIC_API_URL,
                    headers={
                        "Authorization": f"Bearer {token}",
                        "anthropic-version": ANTHROPIC_VERSION,
                        "Content-Type": "application/json",
                    },
                    json=anthropic_body,
                    timeout=httpx.Timeout(connect=10, read=300, write=10, pool=10),
                ) as response:
                    if response.status_code != 200:
                        error_body = ""
                        async for chunk in response.aiter_text():
                            error_body += chunk
                        yield {
                            "type": "stream_error",
                            "request_id": request_id,
                            "error": f"Anthropic API {response.status_code}: {error_body[:500]}",
                        }
                        return

                    async for line in response.aiter_lines():
                        if not line.startswith("data: "):
                            continue

                        try:
                            data = json.loads(line[6:])
                        except json.JSONDecodeError:
                            continue

                        # Track usage
                        if data.get("type") == "message_start":
                            usage = data.get("message", {}).get("usage", {})
                            input_token = usage.get("input_tokens", 0)
                        elif data.get("type") == "message_delta":
                            usage = data.get("usage", {})
                            output_token = usage.get("output_tokens", output_token)

                        # Convert and yield
                        openai_chunk = _anthropic_chunk_to_openai(
                            data, request_id, model
                        )
                        if openai_chunk:
                            yield {
                                "type": "stream_chunk",
                                "request_id": request_id,
                                "data": openai_chunk,
                            }

            # Done
            yield {
                "type": "stream_complete",
                "request_id": request_id,
                "vendor": "anthropic",
                "model_resolved": anthropic_body["model"],
                "usage": {
                    "input_token": input_token,
                    "output_token": output_token,
                },
            }

        except Exception as e:
            log.error("Anthropic streaming error: %s", e)
            yield {
                "type": "stream_error",
                "request_id": request_id,
                "error": str(e),
            }
