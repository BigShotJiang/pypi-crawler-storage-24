"""OpenAI provider - calls OpenAI API using local Codex OAuth tokens."""

from __future__ import annotations

import json
import logging
from typing import AsyncIterator

import httpx

from .base import BaseProvider
from ..token.codex import get_subscription_info, get_valid_token

log = logging.getLogger("cash4tokens.provider.openai")

OPENAI_API_URL = "https://api.openai.com/v1/chat/completions"

# Model families available via Codex Pro
CODEX_MODEL = [
    "gpt-5",
    "gpt-5-codex",
    "gpt-4o",
    "gpt-4o-mini",
    "o3",
    "o3-mini",
    "o4-mini",
]


class OpenAIProvider(BaseProvider):
    async def is_available(self) -> bool:
        token = await get_valid_token()
        return token is not None

    async def get_capability(self) -> dict:
        info = get_subscription_info()
        return {
            "vendor": "openai",
            "subscription_type": info.get("subscription_type", "unknown"),
            "rate_limit_tier": None,
            "model_family": CODEX_MODEL,
        }

    async def stream_inference(
        self, request_id: str, model: str, body: dict
    ) -> AsyncIterator[dict]:
        token = await get_valid_token()
        if not token:
            yield {
                "type": "stream_error",
                "request_id": request_id,
                "error": "Codex/OpenAI token unavailable",
            }
            return

        # OpenAI-compatible - pass body through mostly as-is
        openai_body = {
            "model": model,
            "messages": body.get("messages", []),
            "stream": True,
        }
        for key in (
            "temperature",
            "max_tokens",
            "top_p",
            "stop",
            "tools",
            "response_format",
        ):
            if body.get(key) is not None:
                openai_body[key] = body[key]

        input_token = 0
        output_token = 0

        try:
            async with httpx.AsyncClient() as client:
                async with client.stream(
                    "POST",
                    OPENAI_API_URL,
                    headers={
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/json",
                    },
                    json=openai_body,
                    timeout=httpx.Timeout(connect=10, read=300, write=10, pool=10),
                ) as response:
                    if response.status_code != 200:
                        error_body = ""
                        async for chunk in response.aiter_text():
                            error_body += chunk
                        yield {
                            "type": "stream_error",
                            "request_id": request_id,
                            "error": f"OpenAI API {response.status_code}: {error_body[:500]}",
                        }
                        return

                    async for line in response.aiter_lines():
                        if not line.startswith("data: "):
                            continue

                        data_str = line[6:].strip()
                        if data_str == "[DONE]":
                            break

                        try:
                            data = json.loads(data_str)
                        except json.JSONDecodeError:
                            continue

                        # Track usage if present
                        if "usage" in data:
                            input_token = data["usage"].get(
                                "prompt_tokens", input_token
                            )
                            output_token = data["usage"].get(
                                "completion_tokens", output_token
                            )

                        yield {
                            "type": "stream_chunk",
                            "request_id": request_id,
                            "data": data,
                        }

            yield {
                "type": "stream_complete",
                "request_id": request_id,
                "vendor": "openai",
                "model_resolved": model,
                "usage": {
                    "input_token": input_token,
                    "output_token": output_token,
                },
            }

        except Exception as e:
            log.error("OpenAI streaming error: %s", e)
            yield {
                "type": "stream_error",
                "request_id": request_id,
                "error": str(e),
            }
