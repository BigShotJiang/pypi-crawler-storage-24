import json
from pathlib import Path
from typing import Any

from nrdp.config.models import DatasetConfig, InterpolationConfig, InterpolationConfig


def _strip_hash_comments(text: str) -> str:
    lines: list[str] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue

        kept = raw_line.split("#", 1)[0].rstrip()
        if kept:
            lines.append(kept)

    return "\n".join(lines)


def load_config_document(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    return json.loads(_strip_hash_comments(text))


def _parse_interpolation_config(nrdp: dict[str, Any]) -> InterpolationConfig:
    """解析 interpolation 配置节点"""
    interp = nrdp.get("interpolation", {})
    return InterpolationConfig(
        spline_order=interp.get("spline_order", 3),
        workers=interp.get("workers", 4),
    )


def load_dataset_config(path: Path) -> DatasetConfig:
    document = load_config_document(path)
    dataset = document["dataset"]
    nrdp = document["nrdp"]
    return DatasetConfig(
        dataset_name=dataset["name*"],
        data_dir=Path(dataset["data*"]["path"]),
        label_dir=Path(dataset["label*"]["path"]),
        output_dir=Path(nrdp["output*"]),
        plan_output_path=Path(nrdp["nrdp_json_output*"]),
        logs_dir=Path(nrdp["logs"]),
        png_output_dir=Path(nrdp["png_output*"]),
        nrdp_times=int(nrdp["times*"]),
        interpolation=_parse_interpolation_config(nrdp),
    )
