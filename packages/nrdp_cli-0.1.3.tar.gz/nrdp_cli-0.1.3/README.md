# NRDP

NRDP (Nrrd Process) CLI - 3D医学影像切片插值处理工具

## 项目目标

NRDP 旨在解决3D医学影像数据中切片稀疏的问题。在医学影像分析中，由于扫描设备或采集条件的限制，某些轴向的切片数量可能较少，影响后续的分割或诊断任务。NRDP 通过智能插值算法在连续切片之间生成新的切片，从而：

- 扩展稀疏轴向的切片数量
- 提升体数据的分辨率和质量
- 为下游任务（如肿瘤分割）提供更丰富的数据

## 项目功能

### 切片插值扩展
- 在3D体数据的连续肿瘤切片之间插入插值切片
- 自动识别最稀疏轴向并进行扩展
- 支持图像数据和标签数据的同步处理

### B-Spline 插值算法
- 支持线性插值 (order=1)
- 支持三次样条插值 (order=3, 默认)
- 支持五次样条插值 (order=5)
- 标签数据使用专门的二值掩码插值算法

### 扩展模式
- **固定倍数模式** (`times >= 2`): 在每对连续切片之间插入固定数量的新切片
- **自适应模式** (`times = 0`): 根据目标切片数自动计算每对切片需要插入的数量

### 多线程并行处理
- 支持多线程并行加载数据
- 支持多线程并行插值处理
- 可配置工作线程数量

### 可视化输出
- 生成原始切片与扩展后切片的 PNG 对比图
- 支持肿瘤区域的高亮显示

## 项目安装

### 环境要求
- Python >= 3.11
- 推荐: conda 虚拟环境

### 安装方式

```bash
# 创建并激活虚拟环境 (推荐)
conda create -n nrdp python=3.11
conda activate nrdp

# 安装
pip install nrdp-cli
```

## 项目CLI使用

### 获取帮助

```bash
nrdp --help
```

### 1. 生成配置模板

```bash
# 生成数据集配置模板 (dataset.jsonl)
nrdp get

# 生成计划文件模板 (plan.jsonl)
nrdp get --plan-template
```

### 2. 分析数据集并生成处理计划

```bash
# 根据 dataset.jsonl 生成处理计划
nrdp plan --input dataset.jsonl

# 修复包含错误的计划文件
nrdp plan --fix --plan output/nrdp/nrdp_bts.jsonl

# 原地修复
nrdp plan --fix --plan output/nrdp/nrdp_bts.jsonl --in-place

# 详细输出模式
nrdp plan --input dataset.jsonl --verbose

# 指定并行工作线程数
nrdp plan --input dataset.jsonl --workers 8
```

### 3. 执行处理计划

```bash
# 执行计划文件进行切片扩展
nrdp start --plan output/nrdp/nrdp_bts.jsonl

# 指定 B-Spline 插值阶数
nrdp start --plan output/nrdp/nrdp_bts.jsonl --spline-order 3

# 详细输出模式
nrdp start --plan output/nrdp/nrdp_bts.jsonl --verbose

# 指定并行工作线程数
nrdp start --plan output/nrdp/nrdp_bts.jsonl --workers 8
```

### 4. 生成可视化输出

```bash
# 生成 PNG 对比图
nrdp print --plan output/nrdp/nrdp_bts.jsonl

# 详细输出模式
nrdp print --plan output/nrdp/nrdp_bts.jsonl --verbose
```

### 5. 运行完整流水线

```bash
# 一次性执行 plan -> start -> print 完整流程
nrdp run --input dataset.jsonl

# 详细输出模式
nrdp run --input dataset.jsonl --verbose

# 指定并行工作线程数
nrdp run --input dataset.jsonl --workers 8
```

### 配置文件说明

配置文件采用 JSONL 格式，包含以下主要字段：

```json
{
    "dataset": {
        "name*": "数据集名称",
        "type*": "nrrd",
        "num_samples*": 样本数量,
        "data*": { "path": "图像数据路径" },
        "label*": { "path": "标签数据路径" }
    },
    "nrdp": {
        "output*": "输出目录",
        "nrdp_json_output*": "计划文件输出路径",
        "times*": 扩展倍数,
        "png_output*": "PNG输出目录",
        "interpolation": {
            "spline_order": 3,
            "workers": 4
        }
    }
}
```

**times 参数说明:**
- `0`: 自适应模式，自动计算目标切片数
- `>= 2`: 固定倍数模式，在每对连续切片间插入 (times-1) 个新切片

**interpolation 配置:**
- `spline_order`: B-Spline 阶数 (1=线性, 3=三次, 5=五次)
- `workers`: 并行工作线程数

---

## 开发环境

- WSL2 (Ubuntu 24.04)
- conda 虚拟环境 "nrdp"
