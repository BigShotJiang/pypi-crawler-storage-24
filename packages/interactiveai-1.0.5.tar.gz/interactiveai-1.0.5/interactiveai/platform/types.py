"""Data types for the InteractiveAI platform API."""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List


@dataclass
class SecretMetadata:
    """Metadata about a secret without its actual values.

    Attributes:
        name: The unique name of the secret.
        type: The type of secret (e.g., "json").
        keys: List of keys available in the secret data.
        created_at: When the secret was created.
    """

    name: str
    type: str
    keys: List[str]
    created_at: datetime


@dataclass
class Secret:
    """A secret with its actual data values.

    Attributes:
        name: The unique name of the secret.
        data: The secret data as a dictionary.
        type: The type of secret (e.g., "json").
        created_at: When the secret was created.
    """

    name: str
    data: Dict[str, Any]
    type: str
    created_at: datetime
