"""Secrets manager for the InteractiveAI platform API."""

from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, cast

from .types import Secret, SecretMetadata

if TYPE_CHECKING:
    from .client import PlatformClient


class SecretsManager:
    """Manage secrets in the InteractiveAI platform.

    Provides async CRUD operations for secrets stored in the platform.
    Secrets are key-value stores that can hold sensitive data like API keys,
    credentials, or configuration values.

    Example:
        ```python
        client = Interactive()

        # List all secrets
        secrets = await client.platform.secrets.list()

        # Get a specific secret
        secret = await client.platform.secrets.get("my-api-key")
        print(secret.data["api_key"])

        # Create a new secret
        await client.platform.secrets.create("my-secret", {"key": "value"})

        # Update an existing secret
        await client.platform.secrets.update("my-secret", {"key": "new-value"})

        # Delete a secret
        await client.platform.secrets.delete("my-secret")
        ```
    """

    def __init__(self, client: "PlatformClient") -> None:
        """Initialize the SecretsManager.

        Args:
            client: The PlatformClient instance to use for API calls.
        """
        self._client = client

    async def list(self) -> List[SecretMetadata]:
        """List all secrets in the project.

        Returns:
            A list of SecretMetadata objects containing metadata about each secret.

        Raises:
            AuthenticationError: If API credentials are invalid.
            PlatformAPIError: If the API request fails.
        """
        await self._client._ensure_initialized()
        path = self._client._build_path("secrets")
        response = await self._client._request("GET", path)

        secrets = []
        for item in response["data"]["secrets"]:
            secrets.append(
                SecretMetadata(
                    name=item["name"],
                    type=item["type"],
                    keys=item.get("keys", []),
                    created_at=datetime.fromisoformat(
                        item["createdAt"].replace("Z", "+00:00")
                    ),
                )
            )
        return secrets

    async def get(self, name: str) -> Secret:
        """Get a specific secret by name.

        Args:
            name: The name of the secret to retrieve.

        Returns:
            A Secret object containing the secret data.

        Raises:
            NotFoundError: If the secret does not exist.
            AuthenticationError: If API credentials are invalid.
            PlatformAPIError: If the API request fails.
        """
        await self._client._ensure_initialized()
        path = self._client._build_path("secrets", name)
        response = await self._client._request("GET", path)
        secret_data = response["data"]

        return Secret(
            name=secret_data["name"],
            data=secret_data["data"],
            type=secret_data["type"],
            created_at=datetime.fromisoformat(
                secret_data["createdAt"].replace("Z", "+00:00")
            ),
        )

    async def create(self, name: str, data: Dict[str, Any]) -> str:
        """Create a new secret.

        Args:
            name: The name for the new secret.
            data: A dictionary of key-value pairs to store in the secret.

        Returns:
            The sanitized name of the created secret.

        Raises:
            ConflictError: If a secret with this name already exists.
            AuthenticationError: If API credentials are invalid.
            PlatformAPIError: If the API request fails.
        """
        await self._client._ensure_initialized()
        path = self._client._build_path("secrets", name)
        payload = {"data": data, "format": "json"}
        response = await self._client._request("POST", path, json=payload)
        return cast(str, response["data"]["name"])

    async def update(self, name: str, data: Dict[str, Any]) -> bool:
        """Update an existing secret.

        Args:
            name: The name of the secret to update.
            data: A dictionary of key-value pairs to replace the existing data.

        Returns:
            True if the update was successful.

        Raises:
            NotFoundError: If the secret does not exist.
            AuthenticationError: If API credentials are invalid.
            PlatformAPIError: If the API request fails.
        """
        await self._client._ensure_initialized()
        path = self._client._build_path("secrets", name)
        payload = {"data": data, "format": "json"}
        await self._client._request("PUT", path, json=payload)
        return True

    async def delete(self, name: str) -> bool:
        """Delete a secret.

        This operation is idempotent - it succeeds even if the secret
        has already been deleted.

        Args:
            name: The name of the secret to delete.

        Returns:
            True if the deletion was successful.

        Raises:
            AuthenticationError: If API credentials are invalid.
            PlatformAPIError: If the API request fails.
        """
        await self._client._ensure_initialized()
        path = self._client._build_path("secrets", name)
        await self._client._request("DELETE", path)
        return True
