"""Platform API clients for InteractiveAI."""

import base64
import threading
from typing import Any, Callable, Dict, Optional

import backoff
import httpx

from interactiveai.logger import interactiveai_logger

from .exceptions import raise_for_status
from .secrets import SecretsManager

API_VERSION = "v1"
API_BASE = f"/api/platform/{API_VERSION}"
_NO_PROJECTS_MSG = (
    "No projects found for the provided API keys. Create a project first."
)


class SyncPlatformClient:
    """Sync HTTP client for the InteractiveAI platform API.

    Provides shared auth, project discovery, and request dispatch used by
    domain managers like ``PlatformPromptsManager``.  Mirrors
    :class:`PlatformClient` but uses a blocking ``httpx.Client``.
    """

    def __init__(
        self,
        public_key: str,
        secret_key: str,
        host: str,
        timeout: float = 30.0,
    ) -> None:
        self._host = host.rstrip("/")
        self._timeout = timeout
        credentials = f"{public_key}:{secret_key}"
        self._auth_header = f"Basic {base64.b64encode(credentials.encode()).decode()}"

        self._project_id: Optional[str] = None
        self._http: Optional[httpx.Client] = None
        self._initialized = False
        self._init_lock = threading.Lock()

    def _build_project_path(self, *segments: str) -> str:
        """Build API path with project context (e.g. prompts)."""
        if self._project_id is None:
            msg = "project_id is not yet available. Call _ensure_initialized() first."
            raise RuntimeError(msg)
        base = f"{API_BASE}/projects/{self._project_id}"
        if segments:
            return f"{base}/{'/'.join(segments)}"
        return base

    def _project_request(
        self,
        method: str,
        *path_segments: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
        error_handler: Optional[Callable[..., None]] = None,
        timeout: Optional[float] = None,
    ) -> Any:
        """Ensure initialized, build project path, and dispatch request."""
        self._ensure_initialized()
        path = self._build_project_path(*path_segments)
        return self._request(
            method,
            path,
            json=json,
            params=params,
            error_handler=error_handler,
            timeout=timeout,
        )

    def _ensure_initialized(self) -> None:
        if self._initialized:
            return

        with self._init_lock:
            if self._initialized:  # double-check locking: another thread may have initialized while we waited
                return  # type: ignore[unreachable]

            if self._http is None:
                self._http = httpx.Client(timeout=self._timeout)

            interactiveai_logger.debug(
                "Initializing sync platform client, discovering project_id"
            )

            @backoff.on_exception(
                backoff.expo,
                (httpx.HTTPError, httpx.TimeoutException),
                max_tries=3,
                logger=None,
            )
            def _discover_project() -> str:
                assert self._http is not None
                response = self._http.get(
                    f"{self._host}{API_BASE}/projects",
                    headers={"Authorization": self._auth_header},
                )
                body = response.json()
                raise_for_status(response.status_code, body)
                projects = body.get("data", [])
                if not projects:
                    raise RuntimeError(_NO_PROJECTS_MSG)
                project_id: str = projects[0]["id"]
                return project_id

            self._project_id = _discover_project()
            self._initialized = True

            interactiveai_logger.debug(
                f"Sync platform client initialized: project_id={self._project_id}"
            )

    def _request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
        error_handler: Optional[Callable[..., None]] = None,
        timeout: Optional[float] = None,
    ) -> Any:
        if self._http is None:
            msg = "HTTP client not initialized"
            raise RuntimeError(msg)

        url = f"{self._host}{path}"
        interactiveai_logger.debug(f"Platform API request: {method} {path}")

        kwargs: Dict[str, Any] = {
            "method": method,
            "url": url,
            "headers": {"Authorization": self._auth_header},
            "json": json,
            "params": params,
        }
        if timeout is not None:
            kwargs["timeout"] = timeout

        try:
            response = self._http.request(**kwargs)
        except httpx.HTTPError as exc:
            from interactiveai.api.core.api_error import ApiError

            error_msg = f"{type(exc).__name__}: {exc}"
            raise ApiError(status_code=None, body=error_msg) from exc

        try:
            body = response.json() if response.content else {}
        except ValueError:
            body = response.text if response.content else ""

        handler = error_handler or raise_for_status
        handler(response.status_code, body)
        return body

    def close(self) -> None:
        """Close the HTTP client and release resources.

        Acquires _init_lock to avoid racing with _ensure_initialized().
        """
        with self._init_lock:
            if self._http is not None:
                self._http.close()
                self._http = None
            self._initialized = False


class PlatformClient:
    """Client for interacting with the InteractiveAI platform API.

    Provides access to platform features like secrets management. The client
    automatically discovers the organization and project IDs from API key
    validation on first use.

    This client is async-only and should be used with `await` for all operations.

    Attributes:
        API_VERSION: The platform API version being used.
        API_BASE: The base path for platform API endpoints.

    Example:
        ```python
        async with PlatformClient(
            public_key="pk_...",
            secret_key="sk_...",
            host="https://dev.interactive.ai"
        ) as client:
            secrets = await client.secrets.list()
        ```
    """

    def __init__(
        self,
        public_key: str,
        secret_key: str,
        host: str,
        timeout: float = 30.0,
    ) -> None:
        """Initialize the PlatformClient.

        Args:
            public_key: InteractiveAI public API key.
            secret_key: InteractiveAI secret API key.
            host: The InteractiveAI API host URL.
            timeout: Request timeout in seconds. Defaults to 30.0.
        """
        self._public_key = public_key
        self._secret_key = secret_key
        self._host = host.rstrip("/")
        self._timeout = timeout
        credentials = f"{public_key}:{secret_key}"
        self._auth_header = f"Basic {base64.b64encode(credentials.encode()).decode()}"

        self._org_id: Optional[str] = None
        self._project_id: Optional[str] = None
        self._http_client: Optional[httpx.AsyncClient] = None
        self._secrets: Optional[SecretsManager] = None
        self._initialized = False

    def _build_path(self, *segments: str) -> str:
        """Build API path with org and project context (e.g. secrets)."""
        base = f"{API_BASE}/organizations/{self._org_id}/projects/{self._project_id}"
        if segments:
            return f"{base}/{'/'.join(segments)}"
        return base

    def _build_global_path(self, *segments: str) -> str:
        """Build API path without project context."""
        if segments:
            return f"{API_BASE}/{'/'.join(segments)}"
        return API_BASE

    def _get_auth_header(self) -> str:
        return self._auth_header

    async def _ensure_initialized(self) -> None:
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(timeout=self._timeout)

        if self._initialized:
            return

        interactiveai_logger.debug(
            "Initializing platform client, discovering org_id and project_id"
        )
        response = await self._http_client.get(
            f"{self._host}{self._build_global_path('projects')}",
            headers={"Authorization": self._auth_header},
        )

        body = response.json()
        raise_for_status(response.status_code, body)

        projects = body.get("data", [])
        if not projects:
            raise RuntimeError(_NO_PROJECTS_MSG)
        self._org_id = projects[0]["orgId"]
        self._project_id = projects[0]["id"]
        self._initialized = True

        interactiveai_logger.debug(
            f"Platform client initialized: org_id={self._org_id}, project_id={self._project_id}"
        )

    async def _request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        await self._ensure_initialized()

        if self._http_client is None:
            msg = "HTTP client not initialized"
            raise RuntimeError(msg)

        url = f"{self._host}{path}"
        interactiveai_logger.debug(f"Platform API request: {method} {path}")

        response = await self._http_client.request(
            method=method,
            url=url,
            headers={"Authorization": self._auth_header},
            json=json,
            params=params,
        )

        body = response.json() if response.content else {}
        raise_for_status(response.status_code, body)
        return body

    @property
    def secrets(self) -> SecretsManager:
        """Access the secrets manager for CRUD operations on secrets."""
        if self._secrets is None:
            self._secrets = SecretsManager(self)
        return self._secrets

    async def __aenter__(self) -> "PlatformClient":
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit async context manager and close resources."""
        await self.close()

    async def close(self) -> None:
        """Close the HTTP client and release resources."""
        if self._http_client is not None:
            await self._http_client.aclose()
            self._http_client = None
