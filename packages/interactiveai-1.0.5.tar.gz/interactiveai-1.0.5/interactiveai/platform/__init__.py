"""InteractiveAI platform module for secrets management and platform features.

This module provides access to InteractiveAI platform features that are
independent of the core tracing functionality.

Example:
    ```python
    from interactiveai import Interactive

    client = Interactive()

    # Access secrets through the platform property
    secrets = await client.platform.secrets.list()

    # Or use PlatformClient directly
    from interactiveai.platform import PlatformClient

    async with PlatformClient(
        public_key="pk_...",
        secret_key="sk_...",
        host="https://dev.interactive.ai"
    ) as platform:
        secret = await platform.secrets.get("my-secret")
    ```
"""

from .client import PlatformClient, SyncPlatformClient
from .exceptions import (
    AuthenticationError,
    ConflictError,
    DeploymentHostError,
    ForbiddenError,
    NotFoundError,
    PlatformAPIError,
)
from .prompts import PlatformPromptsManager
from .secrets import SecretsManager
from .types import Secret, SecretMetadata

__all__ = [
    "PlatformClient",
    "SyncPlatformClient",
    "PlatformPromptsManager",
    "SecretsManager",
    "Secret",
    "SecretMetadata",
    "PlatformAPIError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "ConflictError",
    "DeploymentHostError",
]
