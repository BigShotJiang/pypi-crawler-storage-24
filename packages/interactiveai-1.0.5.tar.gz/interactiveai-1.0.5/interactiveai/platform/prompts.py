"""Prompts manager for the InteractiveAI platform API.

Mirrors the Fern-generated prompt client surface so the SDK prompt
domain can swap transport without changing its calling patterns.
"""

import math
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence, Union

from interactiveai._client._helpers import url_encode

from interactiveai.api.resources.prompts.types import (
    Prompt_Chat,
    Prompt_Text,
    PromptMeta,
    PromptMetaListResponse,
)
from interactiveai.api.resources.utils.resources.pagination.types import MetaResponse

from .exceptions import raise_fern_for_status

if TYPE_CHECKING:
    from .client import SyncPlatformClient


def _platform_data_to_prompt(
    data: Dict[str, Any], prompt_type: str
) -> Union[Prompt_Text, Prompt_Chat]:
    """Convert platform response data to Fern prompt types.

    Structured types (routine, guideline, variable, glossary) are stored as
    text prompts in Langfuse.  The platform backend enriches their ``type``
    field, but ``Prompt_Text`` only accepts ``type="text"``.  We normalise it
    here so Pydantic validation passes while the higher-level prompt-client
    wrappers still see the real type via the ``prompt_type`` argument.
    """
    if prompt_type == "chat":
        return Prompt_Chat(**data)
    if prompt_type != "text":
        data = {**data, "type": "text"}
    return Prompt_Text(**data)


def _platform_data_to_list_response(
    data: Dict[str, Any],
    page: Optional[int],
    limit: Optional[int],
) -> PromptMetaListResponse:
    """Convert platform list response data to Fern list response types."""
    prompts = data.get("prompts", [])
    effective_limit = limit or 50
    total_count = data.get("totalCount", len(prompts))

    meta_items = [
        PromptMeta.construct(
            name=prompt["name"],
            type=prompt.get("type", "text"),
            versions=prompt.get("versions", []),
            labels=prompt.get("labels", []),
            tags=prompt.get("tags", []),
            last_updated_at=prompt.get("lastUpdatedAt"),
            last_config=prompt.get("lastConfig", {}),
        )
        for prompt in prompts
    ]

    return PromptMetaListResponse(
        data=meta_items,
        meta=MetaResponse.construct(
            page=page or 1,
            limit=effective_limit,
            total_items=total_count,
            total_pages=math.ceil(total_count / effective_limit) if total_count else 0,
        ),
    )


class PlatformPromptsManager:
    """Fern-compatible prompt transport through the platform backend.

    Mirrors the Fern prompt client method surface (get, list, create,
    update, delete) so the SDK prompt domain can use it as a drop-in
    transport replacement.

    Delegates HTTP transport to :class:`SyncPlatformClient`.
    """

    def __init__(self, client: "SyncPlatformClient") -> None:
        self._client = client

    def close(self) -> None:
        """Close the underlying HTTP client and release resources."""
        self._client.close()

    # -- Fern-mirror surface --------------------------------------------------

    def get(
        self,
        prompt_name: str,
        *,
        version: Optional[int] = None,
        label: Optional[str] = None,
        fetch_timeout_seconds: Optional[int] = None,
    ) -> Union[Prompt_Text, Prompt_Chat]:
        """Get a prompt by name, optionally filtered by version or label."""
        encoded_name = url_encode(prompt_name)
        params: Dict[str, Any] = {}
        if version is not None:
            params["version"] = version
        if label is not None:
            params["label"] = label

        response = self._client._project_request(
            "GET",
            "prompts",
            encoded_name,
            params=params or None,
            error_handler=raise_fern_for_status,
            timeout=float(fetch_timeout_seconds) if fetch_timeout_seconds else None,
        )
        data = response.get("data", response)
        return _platform_data_to_prompt(data, data.get("type", "text"))

    def list(
        self,
        *,
        name: Optional[str] = None,
        label: Optional[str] = None,
        tag: Optional[str] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        prompt_type: Optional[str] = None,
    ) -> PromptMetaListResponse:
        """List prompts with optional filters."""
        params: Dict[str, Any] = {}
        if name is not None:
            params["name"] = name
        if label is not None:
            params["label"] = label
        if tag is not None:
            params["tag"] = tag
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        if prompt_type is not None:
            params["type"] = prompt_type

        response = self._client._project_request(
            "GET",
            "prompts",
            params=params or None,
            error_handler=raise_fern_for_status,
        )
        return _platform_data_to_list_response(
            response.get("data", response),
            page=page,
            limit=limit,
        )

    def create(
        self,
        *,
        name: str,
        prompt: Any,
        type: str = "text",
        config: Optional[Any] = None,
        labels: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        commit_message: Optional[str] = None,
    ) -> Union[Prompt_Text, Prompt_Chat]:
        """Create a prompt via the platform backend."""
        langfuse_type = type if type in ("text", "chat") else "text"

        payload: Dict[str, Any] = {
            "name": name,
            "prompt": prompt,
            "type": langfuse_type,
            "promptType": type,
        }
        if config is not None:
            payload["config"] = config
        if labels is not None:
            payload["labels"] = labels
        if tags is not None:
            payload["tags"] = tags
        if commit_message is not None:
            payload["commitMessage"] = commit_message

        response = self._client._project_request(
            "POST",
            "prompts",
            json=payload,
            error_handler=raise_fern_for_status,
        )
        data = response.get("data", response)
        return _platform_data_to_prompt(data, type)

    def update(
        self,
        name: str,
        version: int,
        *,
        new_labels: Sequence[str],
    ) -> Union[Prompt_Text, Prompt_Chat]:
        """Update labels for a specific prompt version."""
        encoded_name = url_encode(name)
        response = self._client._project_request(
            "PATCH",
            "prompts",
            encoded_name,
            "versions",
            str(version),
            json={"newLabels": list(new_labels)},
            error_handler=raise_fern_for_status,
        )
        data = response.get("data", response)
        return _platform_data_to_prompt(data, data.get("type", "text"))

    def delete(
        self,
        prompt_name: str,
        *,
        version: Optional[int] = None,
        label: Optional[str] = None,
    ) -> None:
        """Delete prompt versions.

        If neither version nor label is given, deletes all versions.
        """
        encoded_name = url_encode(prompt_name)

        if version is None and label is None:
            # Delete all versions — uses backend's by-name route.
            self._client._project_request(
                "DELETE",
                "prompts",
                "by-name",
                encoded_name,
                error_handler=raise_fern_for_status,
            )
        else:
            params: Dict[str, Any] = {}
            if version is not None:
                params["version"] = version
            if label is not None:
                params["label"] = label
            self._client._project_request(
                "DELETE",
                "prompts",
                encoded_name,
                params=params,
                error_handler=raise_fern_for_status,
            )
