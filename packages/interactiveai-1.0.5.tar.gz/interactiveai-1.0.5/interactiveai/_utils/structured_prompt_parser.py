"""Utilities for parsing structured prompt content (YAML / JSON)."""

from dataclasses import fields as dataclass_fields
from typing import Any, Dict, Type, TypeVar

import yaml  # type: ignore[import-untyped]

T = TypeVar("T")


def parse_structured_content(content: str, prompt_name: str = "") -> Dict[str, Any]:
    """Parse YAML or JSON content into a dictionary.

    YAML is a superset of JSON, so ``yaml.safe_load`` handles both formats.

    Args:
        content: Raw text content to parse.
        prompt_name: Optional prompt name included in error messages.

    Returns:
        Parsed dictionary.

    Raises:
        ValueError: If the content is not valid YAML/JSON or is not a mapping.
    """
    try:
        data = yaml.safe_load(content)
    except yaml.YAMLError as exc:
        msg = f"Failed to parse structured prompt content for '{prompt_name}': {exc}"
        raise ValueError(msg) from exc

    if not isinstance(data, dict):
        got = type(data).__name__
        msg = f"Structured prompt '{prompt_name}' must be a mapping, got {got}"
        raise ValueError(msg)

    return data


def dataclass_from_dict(cls: Type[T], data: Any) -> T:
    """Construct a dataclass instance, silently ignoring unknown keys.

    Raises:
        ValueError: If *data* is not a dict or is missing required fields.
    """
    if not isinstance(data, dict):
        got = type(data).__name__
        msg = f"Expected a mapping for {cls.__name__}, got {got}"
        raise ValueError(msg)

    valid_keys = {f.name for f in dataclass_fields(cls)}  # type: ignore[arg-type]
    try:
        return cls(**{k: v for k, v in data.items() if k in valid_keys})
    except TypeError as exc:
        msg = f"Invalid {cls.__name__} data: {exc}"
        raise ValueError(msg) from exc
