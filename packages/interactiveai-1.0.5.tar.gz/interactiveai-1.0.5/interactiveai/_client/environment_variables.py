"""Environment variable definitions for InteractiveAI OpenTelemetry integration.

This module defines environment variables used to configure the InteractiveAI OpenTelemetry integration.
Each environment variable includes documentation on its purpose, expected values, and defaults.
"""

INTERACTIVEAI_TRACING_ENVIRONMENT = "INTERACTIVEAI_TRACING_ENVIRONMENT"
"""
.. envvar:: INTERACTIVEAI_TRACING_ENVIRONMENT

The tracing environment. Can be any lowercase alphanumeric string with hyphens and underscores that does not start with 'interactiveai'.

**Default value:** ``"default"``
"""

INTERACTIVEAI_RELEASE = "INTERACTIVEAI_RELEASE"
"""
.. envvar:: INTERACTIVEAI_RELEASE

Release number/hash of the application to provide analytics grouped by release.
"""


INTERACTIVEAI_PUBLIC_KEY = "INTERACTIVEAI_PUBLIC_KEY"
"""
.. envvar:: INTERACTIVEAI_PUBLIC_KEY

Public API key of InteractiveAI project
"""

INTERACTIVEAI_SECRET_KEY = "INTERACTIVEAI_SECRET_KEY"
"""
.. envvar:: INTERACTIVEAI_SECRET_KEY

Secret API key of InteractiveAI project
"""

INTERACTIVEAI_BASE_URL = "INTERACTIVEAI_BASE_URL"
"""
.. envvar:: INTERACTIVEAI_BASE_URL

Base URL of InteractiveAI API. Can be set via `INTERACTIVEAI_BASE_URL` environment variable.

**Default value:** ``"https://app.interactive.ai"``
"""

INTERACTIVEAI_HOST = "INTERACTIVEAI_HOST"
"""
.. envvar:: INTERACTIVEAI_HOST

Deprecated. Use INTERACTIVEAI_BASE_URL instead. Host of InteractiveAI API. Can be set via `INTERACTIVEAI_HOST` environment variable.

**Default value:** ``"https://app.interactive.ai"``
"""

INTERACTIVEAI_OTEL_TRACES_EXPORT_PATH = "INTERACTIVEAI_OTEL_TRACES_EXPORT_PATH"
"""
.. envvar:: INTERACTIVEAI_OTEL_TRACES_EXPORT_PATH

URL path on the configured host to export traces to.

**Default value:** ``/api/public/otel/v1/traces``
"""

INTERACTIVEAI_DEBUG = "INTERACTIVEAI_DEBUG"
"""
.. envvar:: INTERACTIVEAI_DEBUG

Enables debug mode for more verbose logging.

**Default value:** ``"False"``
"""

INTERACTIVEAI_TRACING_ENABLED = "INTERACTIVEAI_TRACING_ENABLED"
"""
.. envvar:: INTERACTIVEAI_TRACING_ENABLED

Enables or disables the InteractiveAI client. If disabled, all observability calls to the backend will be no-ops. Default is True. Set to `False` to disable tracing.

**Default value:** ``"True"``
"""

INTERACTIVEAI_MEDIA_UPLOAD_THREAD_COUNT = "INTERACTIVEAI_MEDIA_UPLOAD_THREAD_COUNT"
"""
.. envvar:: INTERACTIVEAI_MEDIA_UPLOAD_THREAD_COUNT 

Number of background threads to handle media uploads from trace ingestion.

**Default value:** ``1``
"""

INTERACTIVEAI_FLUSH_AT = "INTERACTIVEAI_FLUSH_AT"
"""
.. envvar:: INTERACTIVEAI_FLUSH_AT

Max batch size until a new ingestion batch is sent to the API.
**Default value:** same as OTEL ``OTEL_BSP_MAX_EXPORT_BATCH_SIZE``
"""

INTERACTIVEAI_FLUSH_INTERVAL = "INTERACTIVEAI_FLUSH_INTERVAL"
"""
.. envvar:: INTERACTIVEAI_FLUSH_INTERVAL

Max delay in seconds until a new ingestion batch is sent to the API.
**Default value:** same as OTEL ``OTEL_BSP_SCHEDULE_DELAY``
"""

INTERACTIVEAI_SAMPLE_RATE = "INTERACTIVEAI_SAMPLE_RATE"
"""
.. envvar: INTERACTIVEAI_SAMPLE_RATE

Float between 0 and 1 indicating the sample rate of traces to bet sent to InteractiveAI servers.

**Default value**: ``1.0``

"""
INTERACTIVEAI_OBSERVE_DECORATOR_IO_CAPTURE_ENABLED = (
    "INTERACTIVEAI_OBSERVE_DECORATOR_IO_CAPTURE_ENABLED"
)
"""
.. envvar: INTERACTIVEAI_OBSERVE_DECORATOR_IO_CAPTURE_ENABLED

Default capture of function args, kwargs and return value when using the @observe decorator.

Having default IO capture enabled for observe decorated function may have a performance impact on your application
if large or deeply nested objects are attempted to be serialized. Set this value to `False` and use manual
input/output setting on your observation to avoid this.

**Default value**: ``True``
"""

INTERACTIVEAI_MEDIA_UPLOAD_ENABLED = "INTERACTIVEAI_MEDIA_UPLOAD_ENABLED"
"""
.. envvar: INTERACTIVEAI_MEDIA_UPLOAD_ENABLED

Controls whether media detection and upload is attempted by the SDK.

**Default value**: ``True``
"""

INTERACTIVEAI_TIMEOUT = "INTERACTIVEAI_TIMEOUT"
"""
.. envvar: INTERACTIVEAI_TIMEOUT

Controls the timeout for all API requests in seconds

**Default value**: ``5``
"""

INTERACTIVEAI_PROMPT_CACHE_DEFAULT_TTL_SECONDS = (
    "INTERACTIVEAI_PROMPT_CACHE_DEFAULT_TTL_SECONDS"
)
"""
.. envvar: INTERACTIVEAI_PROMPT_CACHE_DEFAULT_TTL_SECONDS

Controls the default time-to-live (TTL) in seconds for cached prompts.
This setting determines how long prompt responses are cached before they expire.

**Default value**: ``60``
"""
