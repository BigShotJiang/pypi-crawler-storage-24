"""Datasets domain service."""

from __future__ import annotations

from typing import Any, Optional

from interactiveai._client._context import SharedContext
from interactiveai._client._helpers import url_encode
from interactiveai._client.datasets import DatasetClient, DatasetItemClient
from interactiveai._utils.parse_error import handle_fern_exception
from interactiveai.api.resources.commons.errors.error import Error
from interactiveai.api.resources.commons.types import DatasetRunWithItems
from interactiveai.api.resources.datasets.types import (
    DeleteDatasetRunResponse,
    PaginatedDatasetRuns,
)
from interactiveai.logger import interactiveai_logger
from interactiveai.model import (
    CreateDatasetItemRequest,
    CreateDatasetRequest,
    Dataset,
    DatasetItem,
    DatasetStatus,
)


class DatasetsClient:
    """Domain service for dataset CRUD operations."""

    def __init__(self, context: SharedContext, facade: Any) -> None:
        self._ctx = context
        self._facade = facade

    def get_dataset(
        self, name: str, *, fetch_items_page_size: Optional[int] = 50
    ) -> DatasetClient:
        """Fetch a dataset by its name.

        Args:
            name (str): The name of the dataset to fetch.
            fetch_items_page_size (Optional[int]): All items of the dataset will be fetched in chunks of this size. Defaults to 50.

        Returns:
            DatasetClient: The dataset with the given name.
        """
        try:
            interactiveai_logger.debug(f"Getting datasets {name}")
            dataset = self._ctx.api.datasets.get(dataset_name=url_encode(name))

            dataset_items = []
            page = 1

            while True:
                new_items = self._ctx.api.dataset_items.list(
                    dataset_name=url_encode(name, is_url_param=True),
                    page=page,
                    limit=fetch_items_page_size,
                )
                dataset_items.extend(new_items.data)

                if new_items.meta.total_pages <= page:
                    break

                page += 1

            items = [
                DatasetItemClient(i, interactiveai=self._facade) for i in dataset_items
            ]

            return DatasetClient(dataset, items=items)

        except Error as e:
            handle_fern_exception(e)
            raise e

    def get_dataset_run(
        self, *, dataset_name: str, run_name: str
    ) -> DatasetRunWithItems:
        """Fetch a dataset run by dataset name and run name.

        Args:
            dataset_name (str): The name of the dataset.
            run_name (str): The name of the run.

        Returns:
            DatasetRunWithItems: The dataset run with its items.
        """
        try:
            return self._ctx.api.datasets.get_run(  # type: ignore[no-any-return]
                dataset_name=url_encode(dataset_name),
                run_name=url_encode(run_name),
                request_options=None,
            )
        except Error as e:
            handle_fern_exception(e)
            raise e

    def get_dataset_runs(
        self,
        *,
        dataset_name: str,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> PaginatedDatasetRuns:
        """Fetch all runs for a dataset.

        Args:
            dataset_name (str): The name of the dataset.
            page (Optional[int]): Page number, starts at 1.
            limit (Optional[int]): Limit of items per page.

        Returns:
            PaginatedDatasetRuns: Paginated list of dataset runs.
        """
        try:
            return self._ctx.api.datasets.get_runs(  # type: ignore[no-any-return]
                dataset_name=url_encode(dataset_name),
                page=page,
                limit=limit,
                request_options=None,
            )
        except Error as e:
            handle_fern_exception(e)
            raise e

    def delete_dataset_run(
        self, *, dataset_name: str, run_name: str
    ) -> DeleteDatasetRunResponse:
        """Delete a dataset run and all its run items. This action is irreversible.

        Args:
            dataset_name (str): The name of the dataset.
            run_name (str): The name of the run.

        Returns:
            DeleteDatasetRunResponse: Confirmation of deletion.
        """
        try:
            return self._ctx.api.datasets.delete_run(  # type: ignore[no-any-return]
                dataset_name=url_encode(dataset_name),
                run_name=url_encode(run_name),
                request_options=None,
            )
        except Error as e:
            handle_fern_exception(e)
            raise e

    def create_dataset(
        self,
        *,
        name: str,
        description: Optional[str] = None,
        metadata: Optional[Any] = None,
        input_schema: Optional[Any] = None,
        expected_output_schema: Optional[Any] = None,
    ) -> Dataset:
        """Create a dataset with the given name on InteractiveAI.

        Args:
            name: Name of the dataset to create.
            description: Description of the dataset. Defaults to None.
            metadata: Additional metadata. Defaults to None.
            input_schema: JSON Schema for validating dataset item inputs. When set, all new items will be validated against this schema.
            expected_output_schema: JSON Schema for validating dataset item expected outputs. When set, all new items will be validated against this schema.

        Returns:
            Dataset: The created dataset as returned by the InteractiveAI API.
        """
        try:
            body = CreateDatasetRequest(
                name=name,
                description=description,
                metadata=metadata,
                inputSchema=input_schema,
                expectedOutputSchema=expected_output_schema,
            )
            interactiveai_logger.debug(f"Creating datasets {body}")

            return self._ctx.api.datasets.create(request=body)  # type: ignore[no-any-return]

        except Error as e:
            handle_fern_exception(e)
            raise e

    def create_dataset_item(
        self,
        *,
        dataset_name: str,
        input: Optional[Any] = None,
        expected_output: Optional[Any] = None,
        metadata: Optional[Any] = None,
        source_trace_id: Optional[str] = None,
        source_observation_id: Optional[str] = None,
        status: Optional[DatasetStatus] = None,
        id: Optional[str] = None,
    ) -> DatasetItem:
        """Create a dataset item.

        Upserts if an item with id already exists.

        Args:
            dataset_name: Name of the dataset in which the dataset item should be created.
            input: Input data. Defaults to None. Can contain any dict, list or scalar.
            expected_output: Expected output data. Defaults to None. Can contain any dict, list or scalar.
            metadata: Additional metadata. Defaults to None. Can contain any dict, list or scalar.
            source_trace_id: Id of the source trace. Defaults to None.
            source_observation_id: Id of the source observation. Defaults to None.
            status: Status of the dataset item. Defaults to ACTIVE for newly created items.
            id: Id of the dataset item. Defaults to None. Provide your own id if you want to dedupe dataset items. Id needs to be globally unique and cannot be reused across datasets.

        Returns:
            DatasetItem: The created dataset item as returned by the InteractiveAI API.

        Example:
            ```python
            from interactiveai import Interactive

            interactiveai = Interactive()

            # Uploading items to the InteractiveAI dataset named "capital_cities"
            interactiveai.create_dataset_item(
                dataset_name="capital_cities",
                input={"input": {"country": "Italy"}},
                expected_output={"expected_output": "Rome"},
                metadata={"foo": "bar"}
            )
            ```
        """
        try:
            body = CreateDatasetItemRequest(
                datasetName=dataset_name,
                input=input,
                expectedOutput=expected_output,
                metadata=metadata,
                sourceTraceId=source_trace_id,
                sourceObservationId=source_observation_id,
                status=status,
                id=id,
            )
            interactiveai_logger.debug(f"Creating dataset item {body}")
            return self._ctx.api.dataset_items.create(request=body)  # type: ignore[no-any-return]
        except Error as e:
            handle_fern_exception(e)
            raise e
