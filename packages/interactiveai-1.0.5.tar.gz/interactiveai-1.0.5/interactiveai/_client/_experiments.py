"""Experiments domain service."""

from __future__ import annotations

import asyncio
from typing import Any, Callable, Dict, List, Literal, Optional, cast

from interactiveai._client._context import SharedContext
from interactiveai._client.attributes import InteractiveAIOtelSpanAttributes, _serialize
from interactiveai._client.constants import INTERACTIVEAI_SDK_EXPERIMENT_ENVIRONMENT
from interactiveai._client.propagation import (
    PropagatedExperimentAttributes,
    _propagate_attributes,
)
from interactiveai._client.utils import get_sha256_hash_hex, run_async_safely
from interactiveai._utils import _get_timestamp
from interactiveai.batch_evaluation import (
    BatchEvaluationResult,
    BatchEvaluationResumeToken,
    BatchEvaluationRunner,
    CompositeEvaluatorFunction,
    MapperFunction,
)
from interactiveai.experiment import (
    Evaluation,
    EvaluatorFunction,
    ExperimentData,
    ExperimentItem,
    ExperimentItemResult,
    ExperimentResult,
    RunEvaluatorFunction,
    TaskFunction,
    _run_evaluator,
    _run_task,
)
from interactiveai.logger import interactiveai_logger
from interactiveai.model import CreateDatasetRunItemRequest


class ExperimentsClient:
    """Domain service for running experiments and batched evaluations."""

    def __init__(self, context: SharedContext, facade: Any) -> None:
        self._ctx = context
        self._facade = facade

    def run_experiment(
        self,
        *,
        name: str,
        run_name: Optional[str] = None,
        description: Optional[str] = None,
        data: ExperimentData,
        task: TaskFunction,
        evaluators: List[EvaluatorFunction] = [],
        composite_evaluator: Optional[CompositeEvaluatorFunction] = None,
        run_evaluators: List[RunEvaluatorFunction] = [],
        max_concurrency: int = 50,
        metadata: Optional[Dict[str, str]] = None,
    ) -> ExperimentResult:
        """Run an experiment on a dataset with automatic tracing and evaluation.

        This method executes a task function on each item in the provided dataset,
        automatically traces all executions with InteractiveAI for observability, runs
        item-level and run-level evaluators on the outputs, and returns comprehensive
        results with evaluation metrics.

        The experiment system provides:
        - Automatic tracing of all task executions
        - Concurrent processing with configurable limits
        - Comprehensive error handling that isolates failures
        - Integration with InteractiveAI datasets for experiment tracking
        - Flexible evaluation framework supporting both sync and async evaluators

        Args:
            name: Human-readable name for the experiment. Used for identification
                in the InteractiveAI UI.
            run_name: Optional exact name for the experiment run. If provided, this will be
                used as the exact dataset run name if the `data` contains InteractiveAI dataset items.
                If not provided, this will default to the experiment name appended with an ISO timestamp.
            description: Optional description explaining the experiment's purpose,
                methodology, or expected outcomes.
            data: Array of data items to process. Can be either:
                - List of dict-like items with 'input', 'expected_output', 'metadata' keys
                - List of InteractiveAI DatasetItem objects from dataset.items
            task: Function that processes each data item and returns output.
                Must accept 'item' as keyword argument and can return sync or async results.
                The task function signature should be: task(*, item, **kwargs) -> Any
            evaluators: List of functions to evaluate each item's output individually.
                Each evaluator receives input, output, expected_output, and metadata.
                Can return single Evaluation dict or list of Evaluation dicts.
            composite_evaluator: Optional function that creates composite scores from item-level evaluations.
                Receives the same inputs as item-level evaluators (input, output, expected_output, metadata)
                plus the list of evaluations from item-level evaluators. Useful for weighted averages,
                pass/fail decisions based on multiple criteria, or custom scoring logic combining multiple metrics.
            run_evaluators: List of functions to evaluate the entire experiment run.
                Each run evaluator receives all item_results and can compute aggregate metrics.
                Useful for calculating averages, distributions, or cross-item comparisons.
            max_concurrency: Maximum number of concurrent task executions (default: 50).
                Controls the number of items processed simultaneously. Adjust based on
                API rate limits and system resources.
            metadata: Optional metadata dictionary to attach to all experiment traces.
                This metadata will be included in every trace created during the experiment.
                If `data` are InteractiveAI dataset items, the metadata will be attached to the dataset run, too.

        Returns:
            ExperimentResult containing:
            - run_name: The experiment run name. This is equal to the dataset run name if experiment was on InteractiveAI dataset.
            - item_results: List of results for each processed item with outputs and evaluations
            - run_evaluations: List of aggregate evaluation results for the entire run
            - dataset_run_id: ID of the dataset run (if using InteractiveAI datasets)
            - dataset_run_url: Direct URL to view results in InteractiveAI UI (if applicable)

        Raises:
            ValueError: If required parameters are missing or invalid
            Exception: If experiment setup fails (individual item failures are handled gracefully)

        Examples:
            Basic experiment with local data:
            ```python
            def summarize_text(*, item, **kwargs):
                return f"Summary: {item['input'][:50]}..."

            def length_evaluator(*, input, output, expected_output=None, **kwargs):
                return {
                    "name": "output_length",
                    "value": len(output),
                    "comment": f"Output contains {len(output)} characters"
                }

            result = interactiveai.run_experiment(
                name="Text Summarization Test",
                description="Evaluate summarization quality and length",
                data=[
                    {"input": "Long article text...", "expected_output": "Expected summary"},
                    {"input": "Another article...", "expected_output": "Another summary"}
                ],
                task=summarize_text,
                evaluators=[length_evaluator]
            )

            print(f"Processed {len(result.item_results)} items")
            for item_result in result.item_results:
                print(f"Input: {item_result.item['input']}")
                print(f"Output: {item_result.output}")
                print(f"Evaluations: {item_result.evaluations}")
            ```

            Advanced experiment with async task and multiple evaluators:
            ```python
            async def llm_task(*, item, **kwargs):
                # Simulate async LLM call
                response = await openai_client.chat.completions.create(
                    model="gpt-4",
                    messages=[{"role": "user", "content": item["input"]}]
                )
                return response.choices[0].message.content

            def accuracy_evaluator(*, input, output, expected_output=None, **kwargs):
                if expected_output and expected_output.lower() in output.lower():
                    return {"name": "accuracy", "value": 1.0, "comment": "Correct answer"}
                return {"name": "accuracy", "value": 0.0, "comment": "Incorrect answer"}

            def toxicity_evaluator(*, input, output, expected_output=None, **kwargs):
                # Simulate toxicity check
                toxicity_score = check_toxicity(output)  # Your toxicity checker
                return {
                    "name": "toxicity",
                    "value": toxicity_score,
                    "comment": f"Toxicity level: {'high' if toxicity_score > 0.7 else 'low'}"
                }

            def average_accuracy(*, item_results, **kwargs):
                accuracies = [
                    eval.value for result in item_results
                    for eval in result.evaluations
                    if eval.name == "accuracy"
                ]
                return {
                    "name": "average_accuracy",
                    "value": sum(accuracies) / len(accuracies) if accuracies else 0,
                    "comment": f"Average accuracy across {len(accuracies)} items"
                }

            result = interactiveai.run_experiment(
                name="LLM Safety and Accuracy Test",
                description="Evaluate model accuracy and safety across diverse prompts",
                data=test_dataset,  # Your dataset items
                task=llm_task,
                evaluators=[accuracy_evaluator, toxicity_evaluator],
                run_evaluators=[average_accuracy],
                max_concurrency=5,  # Limit concurrent API calls
                metadata={"model": "gpt-4", "temperature": 0.7}
            )
            ```

            Using with InteractiveAI datasets:
            ```python
            # Get dataset from InteractiveAI
            dataset = interactiveai.get_dataset("my-eval-dataset")

            result = dataset.run_experiment(
                name="Production Model Evaluation",
                description="Monthly evaluation of production model performance",
                task=my_production_task,
                evaluators=[accuracy_evaluator, latency_evaluator]
            )

            # Results automatically linked to dataset in InteractiveAI UI
            print(f"View results: {result['dataset_run_url']}")
            ```

        Note:
            - Task and evaluator functions can be either synchronous or asynchronous
            - Individual item failures are logged but don't stop the experiment
            - All executions are automatically traced and visible in InteractiveAI UI
            - When using InteractiveAI datasets, results are automatically linked for easy comparison
            - This method works in both sync and async contexts (Jupyter notebooks, web apps, etc.)
            - Async execution is handled automatically with smart event loop detection
        """
        return cast(
            ExperimentResult,
            run_async_safely(
                self._run_experiment_async(
                    name=name,
                    run_name=self._create_experiment_run_name(
                        name=name, run_name=run_name
                    ),
                    description=description,
                    data=data,
                    task=task,
                    evaluators=evaluators or [],
                    composite_evaluator=composite_evaluator,
                    run_evaluators=run_evaluators or [],
                    max_concurrency=max_concurrency,
                    metadata=metadata,
                ),
            ),
        )

    async def _run_experiment_async(
        self,
        *,
        name: str,
        run_name: str,
        description: Optional[str],
        data: ExperimentData,
        task: TaskFunction,
        evaluators: List[EvaluatorFunction],
        composite_evaluator: Optional[CompositeEvaluatorFunction],
        run_evaluators: List[RunEvaluatorFunction],
        max_concurrency: int,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ExperimentResult:
        interactiveai_logger.debug(
            f"Starting experiment '{name}' run '{run_name}' with {len(data)} items"
        )

        # Set up concurrency control
        semaphore = asyncio.Semaphore(max_concurrency)

        # Process all items
        async def process_item(item: ExperimentItem) -> ExperimentItemResult:
            async with semaphore:
                return await self._process_experiment_item(
                    item,
                    task,
                    evaluators,
                    composite_evaluator,
                    name,
                    run_name,
                    description,
                    metadata,
                )

        # Run all items concurrently
        tasks = [process_item(item) for item in data]
        item_results = await asyncio.gather(*tasks, return_exceptions=True)

        # Filter out any exceptions and log errors
        valid_results: List[ExperimentItemResult] = []
        for i, result in enumerate(item_results):
            if isinstance(result, Exception):
                interactiveai_logger.error(f"Item {i} failed: {result}")
            elif isinstance(result, ExperimentItemResult):
                valid_results.append(result)  # type: ignore

        # Run experiment-level evaluators
        run_evaluations: List[Evaluation] = []
        for run_evaluator in run_evaluators:
            try:
                evaluations = await _run_evaluator(
                    run_evaluator, item_results=valid_results
                )
                run_evaluations.extend(evaluations)
            except Exception as e:
                interactiveai_logger.error(f"Run evaluator failed: {e}")

        # Generate dataset run URL if applicable
        dataset_run_id = valid_results[0].dataset_run_id if valid_results else None
        dataset_run_url = None
        if dataset_run_id and data:
            try:
                # Check if the first item has dataset_id (for DatasetItem objects)
                first_item = data[0]
                dataset_id = None

                if hasattr(first_item, "dataset_id"):
                    dataset_id = getattr(first_item, "dataset_id", None)

                if dataset_id:
                    project_id = self._facade._get_project_id()

                    if project_id:
                        dataset_run_url = f"{self._ctx.base_url}/project/{project_id}/datasets/{dataset_id}/runs/{dataset_run_id}"

            except Exception:
                pass  # URL generation is optional

        # Store run-level evaluations as scores
        for evaluation in run_evaluations:
            try:
                if dataset_run_id:
                    self._facade.create_score(
                        dataset_run_id=dataset_run_id,
                        name=evaluation.name or "<unknown>",
                        value=evaluation.value,  # type: ignore
                        comment=evaluation.comment,
                        metadata=evaluation.metadata,
                        data_type=evaluation.data_type,  # type: ignore
                        config_id=evaluation.config_id,
                    )

            except Exception as e:
                interactiveai_logger.error(f"Failed to store run evaluation: {e}")

        # Flush scores and traces
        self._facade.flush()

        return ExperimentResult(
            name=name,
            run_name=run_name,
            description=description,
            item_results=valid_results,
            run_evaluations=run_evaluations,
            dataset_run_id=dataset_run_id,
            dataset_run_url=dataset_run_url,
        )

    async def _process_experiment_item(
        self,
        item: ExperimentItem,
        task: Callable,
        evaluators: List[Callable],
        composite_evaluator: Optional[CompositeEvaluatorFunction],
        experiment_name: str,
        experiment_run_name: str,
        experiment_description: Optional[str],
        experiment_metadata: Optional[Dict[str, Any]] = None,
    ) -> ExperimentItemResult:
        span_name = "experiment-item-run"

        with self._facade.start_as_current_span(name=span_name) as span:
            try:
                input_data = (
                    item.get("input")
                    if isinstance(item, dict)
                    else getattr(item, "input", None)
                )

                if input_data is None:
                    raise ValueError("Experiment Item is missing input. Skipping item.")

                expected_output = (
                    item.get("expected_output")
                    if isinstance(item, dict)
                    else getattr(item, "expected_output", None)
                )

                item_metadata = (
                    item.get("metadata")
                    if isinstance(item, dict)
                    else getattr(item, "metadata", None)
                )

                final_observation_metadata = {
                    "experiment_name": experiment_name,
                    "experiment_run_name": experiment_run_name,
                    **(experiment_metadata or {}),
                }

                trace_id = span.trace_id
                dataset_id = None
                dataset_item_id = None
                dataset_run_id = None

                # Link to dataset run if this is a dataset item
                if hasattr(item, "id") and hasattr(item, "dataset_id"):
                    try:
                        # Use sync API to avoid event loop issues when run_async_safely
                        # creates multiple event loops across different threads
                        dataset_run_item = await asyncio.to_thread(
                            self._ctx.api.dataset_run_items.create,
                            request=CreateDatasetRunItemRequest(
                                runName=experiment_run_name,
                                runDescription=experiment_description,
                                metadata=experiment_metadata,
                                datasetItemId=item.id,  # type: ignore
                                traceId=trace_id,
                                observationId=span.id,
                            ),
                        )

                        dataset_run_id = dataset_run_item.dataset_run_id

                    except Exception as e:
                        interactiveai_logger.error(
                            f"Failed to create dataset run item: {e}"
                        )

                if (
                    not isinstance(item, dict)
                    and hasattr(item, "dataset_id")
                    and hasattr(item, "id")
                ):
                    dataset_id = item.dataset_id
                    dataset_item_id = item.id

                    final_observation_metadata.update(
                        {"dataset_id": dataset_id, "dataset_item_id": dataset_item_id}
                    )

                if isinstance(item_metadata, dict):
                    final_observation_metadata.update(item_metadata)

                experiment_id = dataset_run_id or self._facade._create_observation_id()
                experiment_item_id = (
                    dataset_item_id or get_sha256_hash_hex(_serialize(input_data))[:16]
                )
                span._otel_span.set_attributes(
                    {
                        k: v
                        for k, v in {
                            InteractiveAIOtelSpanAttributes.ENVIRONMENT: INTERACTIVEAI_SDK_EXPERIMENT_ENVIRONMENT,
                            InteractiveAIOtelSpanAttributes.EXPERIMENT_DESCRIPTION: experiment_description,
                            InteractiveAIOtelSpanAttributes.EXPERIMENT_ITEM_EXPECTED_OUTPUT: _serialize(
                                expected_output
                            ),
                        }.items()
                        if v is not None
                    }
                )

                propagated_experiment_attributes = PropagatedExperimentAttributes(
                    experiment_id=experiment_id,
                    experiment_name=experiment_run_name,
                    experiment_metadata=_serialize(experiment_metadata),
                    experiment_dataset_id=dataset_id,
                    experiment_item_id=experiment_item_id,
                    experiment_item_metadata=_serialize(item_metadata),
                    experiment_item_root_observation_id=span.id,
                )

                with _propagate_attributes(experiment=propagated_experiment_attributes):
                    output = await _run_task(task, item)

                span.update(
                    input=input_data,
                    output=output,
                    metadata=final_observation_metadata,
                )

            except Exception as e:
                span.update(
                    output=f"Error: {str(e)}", level="ERROR", status_message=str(e)
                )
                raise e

            # Run evaluators
            evaluations = []

            for evaluator in evaluators:
                try:
                    eval_metadata: Optional[Dict[str, Any]] = None

                    if isinstance(item, dict):
                        eval_metadata = item.get("metadata")
                    elif hasattr(item, "metadata"):
                        eval_metadata = item.metadata

                    with _propagate_attributes(
                        experiment=propagated_experiment_attributes
                    ):
                        eval_results = await _run_evaluator(
                            evaluator,
                            input=input_data,
                            output=output,
                            expected_output=expected_output,
                            metadata=eval_metadata,
                        )
                        evaluations.extend(eval_results)

                        # Store evaluations as scores
                        for evaluation in eval_results:
                            self._facade.create_score(
                                trace_id=trace_id,
                                observation_id=span.id,
                                name=evaluation.name,
                                value=evaluation.value,  # type: ignore
                                comment=evaluation.comment,
                                metadata=evaluation.metadata,
                                config_id=evaluation.config_id,
                                data_type=evaluation.data_type,  # type: ignore
                            )

                except Exception as e:
                    interactiveai_logger.error(f"Evaluator failed: {e}")

            # Run composite evaluator if provided and we have evaluations
            if composite_evaluator and evaluations:
                try:
                    composite_eval_metadata: Optional[Dict[str, Any]] = None
                    if isinstance(item, dict):
                        composite_eval_metadata = item.get("metadata")
                    elif hasattr(item, "metadata"):
                        composite_eval_metadata = item.metadata

                    with _propagate_attributes(
                        experiment=propagated_experiment_attributes
                    ):
                        result = composite_evaluator(
                            input=input_data,
                            output=output,
                            expected_output=expected_output,
                            metadata=composite_eval_metadata,
                            evaluations=evaluations,
                        )

                        # Handle async composite evaluators
                        if asyncio.iscoroutine(result):
                            result = await result

                        # Normalize to list
                        composite_evals: List[Evaluation] = []
                        if isinstance(result, (dict, Evaluation)):
                            composite_evals = [result]  # type: ignore
                        elif isinstance(result, list):
                            composite_evals = result  # type: ignore

                        # Store composite evaluations as scores and add to evaluations list
                        for composite_evaluation in composite_evals:
                            self._facade.create_score(
                                trace_id=trace_id,
                                observation_id=span.id,
                                name=composite_evaluation.name,
                                value=composite_evaluation.value,  # type: ignore
                                comment=composite_evaluation.comment,
                                metadata=composite_evaluation.metadata,
                                config_id=composite_evaluation.config_id,
                                data_type=composite_evaluation.data_type,  # type: ignore
                            )
                            evaluations.append(composite_evaluation)

                except Exception as e:
                    interactiveai_logger.error(f"Composite evaluator failed: {e}")

            return ExperimentItemResult(
                item=item,
                output=output,
                evaluations=evaluations,
                trace_id=trace_id,
                dataset_run_id=dataset_run_id,
            )

    def _create_experiment_run_name(
        self, *, name: Optional[str] = None, run_name: Optional[str] = None
    ) -> str:
        if run_name:
            return run_name

        iso_timestamp = _get_timestamp().isoformat().replace("+00:00", "Z")

        return f"{name} - {iso_timestamp}"

    def run_batched_evaluation(
        self,
        *,
        scope: Literal["traces", "observations"],
        mapper: MapperFunction,
        filter: Optional[str] = None,
        fetch_batch_size: int = 50,
        max_items: Optional[int] = None,
        max_retries: int = 3,
        evaluators: List[EvaluatorFunction],
        composite_evaluator: Optional[CompositeEvaluatorFunction] = None,
        max_concurrency: int = 50,
        metadata: Optional[Dict[str, Any]] = None,
        resume_from: Optional[BatchEvaluationResumeToken] = None,
        verbose: bool = False,
    ) -> BatchEvaluationResult:
        """Fetch traces or observations and run evaluations on each item.

        This method provides a powerful way to evaluate existing data in InteractiveAI at scale.
        It fetches items based on filters, transforms them using a mapper function, runs
        evaluators on each item, and creates scores that are linked back to the original
        entities. This is ideal for:

        - Running evaluations on production traces after deployment
        - Backtesting new evaluation metrics on historical data
        - Batch scoring of observations for quality monitoring
        - Periodic evaluation runs on recent data

        The method uses a streaming/pipeline approach to process items in batches, making
        it memory-efficient for large datasets. It includes comprehensive error handling,
        retry logic, and resume capability for long-running evaluations.

        Args:
            scope: The type of items to evaluate. Must be one of:
                - "traces": Evaluate complete traces with all their observations
                - "observations": Evaluate individual observations (spans, generations, events)
            mapper: Function that transforms API response objects into evaluator inputs.
                Receives a trace/observation object and returns an EvaluatorInputs
                instance with input, output, expected_output, and metadata fields.
                Can be sync or async.
            evaluators: List of evaluation functions to run on each item. Each evaluator
                receives the mapped inputs and returns Evaluation object(s). Evaluator
                failures are logged but don't stop the batch evaluation.
            filter: Optional JSON filter string for querying items (same format as InteractiveAI API). Examples:
                - '{"tags": ["production"]}'
                - '{"user_id": "user123", "timestamp": {"operator": ">", "value": "2024-01-01"}}'
                Default: None (fetches all items).
            fetch_batch_size: Number of items to fetch per API call and hold in memory.
                Larger values may be faster but use more memory. Default: 50.
            max_items: Maximum total number of items to process. If None, processes all
                items matching the filter. Useful for testing or limiting evaluation runs.
                Default: None (process all).
            max_concurrency: Maximum number of items to evaluate concurrently. Controls
                parallelism and resource usage. Default: 50.
            composite_evaluator: Optional function that creates a composite score from
                item-level evaluations. Receives the original item and its evaluations,
                returns a single Evaluation. Useful for weighted averages or combined metrics.
                Default: None.
            metadata: Optional metadata dict to add to all created scores. Useful for
                tracking evaluation runs, versions, or other context. Default: None.
            max_retries: Maximum number of retry attempts for failed batch fetches.
                Uses exponential backoff (1s, 2s, 4s). Default: 3.
            verbose: If True, logs progress information to console. Useful for monitoring
                long-running evaluations. Default: False.
            resume_from: Optional resume token from a previous incomplete run. Allows
                continuing evaluation after interruption or failure. Default: None.


        Returns:
            BatchEvaluationResult containing:
                - total_items_fetched: Number of items fetched from API
                - total_items_processed: Number of items successfully evaluated
                - total_items_failed: Number of items that failed evaluation
                - total_scores_created: Scores created by item-level evaluators
                - total_composite_scores_created: Scores created by composite evaluator
                - total_evaluations_failed: Individual evaluator failures
                - evaluator_stats: Per-evaluator statistics (success rate, scores created)
                - resume_token: Token for resuming if incomplete (None if completed)
                - completed: True if all items processed
                - duration_seconds: Total execution time
                - failed_item_ids: IDs of items that failed
                - error_summary: Error types and counts
                - has_more_items: True if max_items reached but more exist

        Raises:
            ValueError: If invalid scope is provided.

        Examples:
            Basic trace evaluation:
            ```python
            from interactiveai import Interactive, EvaluatorInputs, Evaluation

            client = Interactive()

            # Define mapper to extract fields from traces
            def trace_mapper(trace):
                return EvaluatorInputs(
                    input=trace.input,
                    output=trace.output,
                    expected_output=None,
                    metadata={"trace_id": trace.id}
                )

            # Define evaluator
            def length_evaluator(*, input, output, expected_output, metadata):
                return Evaluation(
                    name="output_length",
                    value=len(output) if output else 0
                )

            # Run batch evaluation
            result = client.run_batched_evaluation(
                scope="traces",
                mapper=trace_mapper,
                evaluators=[length_evaluator],
                filter='{"tags": ["production"]}',
                max_items=1000,
                verbose=True
            )

            print(f"Processed {result.total_items_processed} traces")
            print(f"Created {result.total_scores_created} scores")
            ```

            Evaluation with composite scorer:
            ```python
            def accuracy_evaluator(*, input, output, expected_output, metadata):
                # ... evaluation logic
                return Evaluation(name="accuracy", value=0.85)

            def relevance_evaluator(*, input, output, expected_output, metadata):
                # ... evaluation logic
                return Evaluation(name="relevance", value=0.92)

            def composite_evaluator(*, item, evaluations):
                # Weighted average of evaluations
                weights = {"accuracy": 0.6, "relevance": 0.4}
                total = sum(
                    e.value * weights.get(e.name, 0)
                    for e in evaluations
                    if isinstance(e.value, (int, float))
                )
                return Evaluation(
                    name="composite_score",
                    value=total,
                    comment=f"Weighted average of {len(evaluations)} metrics"
                )

            result = client.run_batched_evaluation(
                scope="traces",
                mapper=trace_mapper,
                evaluators=[accuracy_evaluator, relevance_evaluator],
                composite_evaluator=composite_evaluator,
                filter='{"user_id": "important_user"}',
                verbose=True
            )
            ```

            Handling incomplete runs with resume:
            ```python
            # Initial run that may fail or timeout
            result = client.run_batched_evaluation(
                scope="observations",
                mapper=obs_mapper,
                evaluators=[my_evaluator],
                max_items=10000,
                verbose=True
            )

            # Check if incomplete
            if not result.completed and result.resume_token:
                print(f"Processed {result.resume_token.items_processed} items before interruption")

                # Resume from where it left off
                result = client.run_batched_evaluation(
                    scope="observations",
                    mapper=obs_mapper,
                    evaluators=[my_evaluator],
                    resume_from=result.resume_token,
                    verbose=True
                )

            print(f"Total items processed: {result.total_items_processed}")
            ```

            Monitoring evaluator performance:
            ```python
            result = client.run_batched_evaluation(...)

            for stats in result.evaluator_stats:
                success_rate = stats.successful_runs / stats.total_runs
                print(f"{stats.name}:")
                print(f"  Success rate: {success_rate:.1%}")
                print(f"  Scores created: {stats.total_scores_created}")

                if stats.failed_runs > 0:
                    print(f"  Failed {stats.failed_runs} times")
            ```

        Note:
            - Evaluator failures are logged but don't stop the batch evaluation
            - Individual item failures are tracked but don't stop processing
            - Fetch failures are retried with exponential backoff
            - All scores are automatically flushed to InteractiveAI at the end
            - The resume mechanism uses timestamp-based filtering to avoid duplicates
        """
        runner = BatchEvaluationRunner(self._facade)

        return cast(
            BatchEvaluationResult,
            run_async_safely(
                runner.run_async(
                    scope=scope,
                    mapper=mapper,
                    evaluators=evaluators,
                    filter=filter,
                    fetch_batch_size=fetch_batch_size,
                    max_items=max_items,
                    max_concurrency=max_concurrency,
                    composite_evaluator=composite_evaluator,
                    metadata=metadata,
                    max_retries=max_retries,
                    verbose=verbose,
                    resume_from=resume_from,
                )
            ),
        )
