"""Shared context passed to domain service clients.

SharedContext is a dataclass that bundles the infrastructure every
domain client needs (API clients, caches, etc.) without coupling them to
the Interactive facade or to each other.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Optional

from interactiveai._client.resource_manager import InteractiveAIResourceManager
from interactiveai._utils.prompt_cache import PromptCache

if TYPE_CHECKING:
    from interactiveai.platform.client import SyncPlatformClient


@dataclass
class SharedContext:
    """Bag of dependencies injected into domain service clients."""

    api: Any
    async_api: Any
    resources: Optional[InteractiveAIResourceManager]
    base_url: str = ""
    tracing_enabled: bool = False
    environment: Optional[str] = None
    _sync_platform_client: Optional["SyncPlatformClient"] = field(
        default=None, repr=False
    )

    def get_sync_platform_client(self) -> "SyncPlatformClient":
        """Return a shared SyncPlatformClient, creating it lazily on first use."""
        if self._sync_platform_client is None:
            if self.resources is None:
                msg = (
                    "Platform client is not available."
                    " Ensure the SDK is initialized with valid credentials."
                )
                raise RuntimeError(msg)
            from interactiveai.platform.client import SyncPlatformClient

            self._sync_platform_client = SyncPlatformClient(
                public_key=self.resources.public_key,
                secret_key=self.resources.secret_key,
                host=self.resources.base_url,
            )
        return self._sync_platform_client

    def close_sync_platform_client(self) -> None:
        """Close the shared SyncPlatformClient if it exists."""
        if self._sync_platform_client is not None:
            self._sync_platform_client.close()
            self._sync_platform_client = None

    @property
    def prompt_cache(self) -> PromptCache:
        if self.resources is None:
            raise RuntimeError(
                "SDK is not correctly initialized. Check the init logs for more details."
            )
        return self.resources.prompt_cache
