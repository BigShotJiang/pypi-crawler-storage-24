"""gp4c - Fast joint GP sampling with integral and derivative relationships.

This package provides efficient sampling from joint Gaussian Processes where:
- f(x) is a GP with RBF kernel
- g(x) = integral of f from 0 to x
- h(x) = f'(x), the derivative

All functions maintain exact covariance structure through analytically-derived
cross-covariance kernels.
"""

from importlib.metadata import PackageNotFoundError, version

from . import _core as _core

sample_prior = _core.sample_prior
sample_posterior = _core.sample_posterior

log_marginal_likelihood = getattr(_core, "log_marginal_likelihood", None)
LML = getattr(_core, "LML", None)

# from .plot import (
#     plot_samples_posteriors,
# )
# from .compute import (
#     retrieve_gp_samples_posteriors,
# )

from .types import (
    MeanSpec,
    SamplingSpec,
    GPSamples,
    Observations,
    PosteriorSamples,
    OptimizationResult,
)

try:
    from .optimize import (
        fit,
    )
except ImportError:
    fit = None

try:
    __version__ = version("gp4c")
except PackageNotFoundError:
    __version__ = "0+unknown"

__all__ = [
    "sample_prior",
    "sample_posterior",
    "log_marginal_likelihood",
    "LML",
    # "plot_samples_posteriors",
    # "retrieve_gp_samples_posteriors",
    "fit",
    "MeanSpec",
    "SamplingSpec",
    "GPSamples",
    "Observations",
    "PosteriorSamples",
    "OptimizationResult",
]
