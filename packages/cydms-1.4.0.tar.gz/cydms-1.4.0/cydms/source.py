"""
cydms.source
------------
Forward solution, inverse solution (sLORETA), band power, clean segment selection
"""
import numpy as np
import mne


BANDS = {
    'Delta': (1, 4),
    'Theta': (4, 8),
    'Alpha': (8, 13),
    'Beta':  (13, 30),
    'Gamma': (30, 45),
}

COLORS = {
    'Delta': '#ff3333',
    'Theta': '#ffcc00',
    'Alpha': '#33ff33',
    'Beta':  '#3333ff',
    'Gamma': '#ff33ff',
}

NORMAL_RANGES = {
    'Delta': (5, 25),
    'Theta': (5, 25),
    'Alpha': (25, 45),
    'Beta':  (10, 30),
    'Gamma': (2, 15),
}

DIAG_MAP = {
    'Delta': {
        'high':   '⚠️ สูงกว่าปกติ: เสี่ยง ADHD, บาดเจ็บสมอง, หรือง่วงมาก',
        'normal': '✅ ปกติ: สมองพักผ่อนหรือนอนหลับลึก',
        'low':    '⚠️ ต่ำกว่าปกติ: อาจนอนหลับไม่พอ',
    },
    'Theta': {
        'high':   '⚠️ สูงกว่าปกติ: เสี่ยง ADHD, วิตกกังวล, หรือซึมเศร้า',
        'normal': '✅ ปกติ: ผ่อนคลาย ใกล้หลับ',
        'low':    '⚠️ ต่ำกว่าปกติ: ตื่นตัวสูงมากผิดปกติ',
    },
    'Alpha': {
        'high':   '✅ สูงกว่าปกติ: ผ่อนคลายดีเยี่ยม สมาธิดี',
        'normal': '✅ ปกติ: สมองทำงานสมดุล',
        'low':    '⚠️ ต่ำกว่าปกติ: เครียด วิตกกังวล หรือสมาธิลดลง',
    },
    'Beta': {
        'high':   '⚠️ สูงกว่าปกติ: เครียดสูง วิตกกังวล หรือ OCD',
        'normal': '✅ ปกติ: ตื่นตัว ทำงานได้ดี',
        'low':    '⚠️ ต่ำกว่าปกติ: ง่วงนอน หรือขาดสมาธิ',
    },
    'Gamma': {
        'high':   '⚠️ สูงกว่าปกติ: Hyperactivity หรือเครียดสูงมาก',
        'normal': '✅ ปกติ: ประมวลผลข้อมูลดี',
        'low':    '⚠️ ต่ำกว่าปกติ: การประมวลผลสมองช้าลง',
    },
}


def get_lobe_name(pos_mni_mm):
    """รับ MNI mm จริงๆ (ก่อนลบ ras_center) — Y+ = Anterior, Z- = Inferior"""
    y, z = pos_mni_mm[1], pos_mni_mm[2]
    if y > 25:    return "Frontal Lobe"
    elif y < -45: return "Occipital Lobe"
    elif z < -15: return "Temporal Lobe"
    else:         return "Parietal Lobe"


def find_clean_segment(band_data, sfreq, win_sec=25.0, step_sec=5.0, debug_log=None):
    n_samples = band_data.shape[1]
    win  = int(win_sec * sfreq)
    step = int(step_sec * sfreq)
    if n_samples <= win:
        return None, 'low'

    wins, variances = [], []
    for i in range(0, n_samples - win, step):
        seg = band_data[:, i:i+win]
        wins.append(i)
        variances.append(float(np.var(seg)))

    variances  = np.array(variances)
    median_var = np.median(variances)
    diffs      = np.abs(variances - median_var)
    best_idx   = np.argmin(diffs)

    if median_var == 0 or diffs[best_idx] > median_var * 2:
        if debug_log is not None:
            debug_log.append("⚠️ ไฟล์ noisy มาก — ใช้ทั้งไฟล์แทน")
        return None, 'low'

    start = wins[best_idx]
    return (start, start + win), 'normal'


def compute_source_localization(raw, debug_log=None, ras_center=None):
    if debug_log is None:
        debug_log = []
    src_logs = []

    fs_dir       = mne.datasets.fetch_fsaverage(verbose=False)
    subjects_dir = __import__('os').path.dirname(fs_dir)
    src = mne.setup_source_space('fsaverage', spacing='oct2',
                                  subjects_dir=subjects_dir, add_dist=False, verbose=False)
    bem = __import__('os').path.join(fs_dir, 'bem', 'fsaverage-5120-5120-5120-bem-sol.fif')

    try:
        fwd = mne.make_forward_solution(raw.info, trans='fsaverage', src=src,
                                         bem=bem, eeg=True, mindist=2.0,
                                         ignore_ref=False, verbose=False)
    except Exception as e_fwd:
        err_msg = str(e_fwd)
        if "No EEG channels" in err_msg:
            err_msg += " (Make sure your SET file contains EEG channels)"
        raise RuntimeError(f"Forward solution failed: {err_msg}")

    inv   = mne.minimum_norm.make_inverse_operator(raw.info, fwd,
                                                    mne.make_ad_hoc_cov(raw.info),
                                                    verbose=False)
    sfreq  = raw.info['sfreq']
    ds_w   = max(1, int(sfreq // 50))
    n_lh   = len(src[0]['rr'])
    all_rr = np.vstack([src[0]['rr'], src[1]['rr']])  # (n_src, 3) meters

    if ras_center and len(ras_center) == 3:
        ras_center_mm = np.array(ras_center, dtype=np.float32)
    else:
        ras_center_mm = np.zeros(3, dtype=np.float32)

    final_results = {}
    total_pwr     = 0
    raw_results   = []
    # waveform times จะ set หลัง loop เมื่อรู้ cap จริง
    waveform      = {}
    _waveform_cap = None   # จะ set ใน loop แรก
    # all_stc_mean สะสมจาก clean segment ทุก band — ใช้สำหรับ timeline
    all_stc_mean  = None
    stc_per_band  = {}  # เก็บ stc clean segment ไว้สำหรับ timeline

    for name, (fmin, fmax) in BANDS.items():
        raw_filtered = raw.copy().filter(fmin, fmax, verbose=False)
        band_data    = raw_filtered.get_data()

        seg_range, conf = find_clean_segment(band_data, sfreq, debug_log=src_logs)
        if seg_range:
            clean_data = band_data[:, seg_range[0]:seg_range[1]]
            src_logs.append(f"✅ {name}: ใช้ช่วง {seg_range[0]/sfreq:.1f}s-{seg_range[1]/sfreq:.1f}s")
            raw_clean = raw_filtered.copy().crop(
                tmin=seg_range[0]/sfreq,
                tmax=seg_range[1]/sfreq
            )
        else:
            clean_data = band_data
            raw_clean  = raw_filtered
            src_logs.append(f"{'⚠️' if conf=='low' else '✅'} {name}: ใช้ทั้งไฟล์ (confidence: {conf})")

        # apply_inverse_raw เฉพาะ clean segment — เร็วกว่า full file มาก
        stc_clean = mne.minimum_norm.apply_inverse_raw(raw_clean, inv,
                        lambda2=1.0/9.0, method='sLORETA', verbose=False)
        d_mean = np.mean(np.abs(stc_clean.data), axis=1)

        # top-5 weighted centroid ป้องกัน band ต่างๆ ได้ pos เดียวกัน
        top5_idx = np.argsort(d_mean)[-5:]
        n_src_stc = stc_clean.data.shape[0]
        top5_idx  = top5_idx[top5_idx < n_src_stc]
        if len(top5_idx) == 0:
            top5_idx = np.array([np.argmax(d_mean[:n_src_stc])])
        rr_top5  = np.array([
            src[0]['rr'][i] if i < n_lh else src[1]['rr'][i - n_lh]
            for i in top5_idx
        ])
        weights  = d_mean[top5_idx]
        w_sum    = weights.sum()
        weights  = weights / w_sum if w_sum > 0 else np.ones(len(weights)) / len(weights)
        p_std    = np.average(rr_top5, axis=0, weights=weights)

        pos_mni_mm = p_std * 1000                    # MNI mm จริงๆ — ใช้กับ get_lobe_name
        pos_mm     = pos_mni_mm - ras_center_mm      # centered — ใช้แสดงบน mesh

        pwr = float(np.mean(np.abs(clean_data)))
        total_pwr += pwr

        raw_results.append({
            'name':       name,
            'pos':        pos_mm.tolist(),
            'pos_mni_mm': pos_mni_mm.tolist(),  # MNI mm สำหรับ get_lobe_name
            'pwr':        pwr,
            'confidence': conf,
        })

        avg   = np.mean(band_data, axis=0)
        # cap ไว้ที่ 2000 จุด ป้องกัน JSON ใหญ่เกิน
        cap   = max(1, len(avg) // 2000) if len(avg) > 2000 else ds_w
        cap   = max(cap, ds_w)
        if _waveform_cap is None:
            _waveform_cap = cap
            waveform['times'] = raw.times[::cap].tolist()
        mx    = np.max(np.abs(avg)) or 1
        waveform[name] = (avg[::_waveform_cap] / mx).tolist()

        # เก็บ stc clean segment ไว้สำหรับ timeline — ไม่ต้องรัน full file อีก
        stc_per_band[name] = stc_clean
        all_stc_mean = d_mean if all_stc_mean is None else all_stc_mean + d_mean

    for item in raw_results:
        pct    = round((item['pwr'] / (total_pwr if total_pwr > 0 else 1)) * 100, 2)
        lobe   = get_lobe_name(item['pos_mni_mm'])  # ใช้ MNI mm จริงๆ
        name   = item['name']
        lo, hi = NORMAL_RANGES.get(name, (10, 30))
        status = 'high' if pct > hi else ('low' if pct < lo else 'normal')
        diag   = DIAG_MAP.get(name, {}).get(status, '')
        final_results[name] = {
            'val':        pct,
            'pos':        item['pos'],
            'color':      COLORS[name],
            'lobe':       lobe,
            'status':     status,
            'diag':       diag,
            'confidence': item.get('confidence', 'normal'),
        }
        src_logs.append(f"📍 {name}: MNI=({item['pos_mni_mm'][0]:.1f}, {item['pos_mni_mm'][1]:.1f}, {item['pos_mni_mm'][2]:.1f}) → {lobe}")

    # ── STC Timeline — 100 จุด × window 20s จาก clean segment ──
    stc_timeline = {}
    try:
        if not stc_per_band:
            raise RuntimeError("ไม่มี stc จาก band ใดเลย")
        if all_stc_mean is None:
            raise RuntimeError("all_stc_mean ว่าง")
        n_per_region = 25  # 25 × 4 regions = 100 จุด
        n_src     = len(all_stc_mean)
        n_rr_total = len(all_rr)
        # all_stc_mean มาจาก stc_clean ซึ่งอาจมีขนาดน้อยกว่า all_rr (lh+rh combined)
        # ใช้ขนาดเล็กกว่าเสมอ
        n_iter = min(n_src, n_rr_total)

        # แบ่ง region ด้วย MNI meters (all_rr) ที่ตรงกับ all_stc_mean
        regions = {'frontal': [], 'parietal': [], 'occipital': [], 'temporal': []}
        for i in range(n_iter):
            rr = all_rr[i]
            y, z = rr[1], rr[2]
            if y > 0.025:    regions['frontal'].append(i)
            elif y < -0.045: regions['occipital'].append(i)
            elif z < -0.015: regions['temporal'].append(i)
            else:            regions['parietal'].append(i)

        top_idx = []
        for region, idxs in regions.items():
            if not idxs: continue
            vals = all_stc_mean[np.array(idxs)]
            best = np.array(idxs)[np.argsort(vals)[-n_per_region:]]
            top_idx.extend(best.tolist())

        # clamp ให้ไม่เกิน stc data shape
        n_src_stc = list(stc_per_band.values())[0].data.shape[0]
        top_idx   = np.array([i for i in top_idx if i < n_src_stc], dtype=np.int64)
        if len(top_idx) == 0:
            raise RuntimeError("top_idx ว่างหลัง clamp — ไม่มี source ที่ valid")

        src_logs.append(f"🔍 Regions: frontal={len(regions['frontal'])} parietal={len(regions['parietal'])} occipital={len(regions['occipital'])} temporal={len(regions['temporal'])}")
        src_logs.append(f"🔍 top_idx count: {len(top_idx)}")

        positions = []
        for idx in top_idx:
            rr     = src[0]['rr'][idx] if idx < n_lh else src[1]['rr'][idx - n_lh]
            pos_mm = rr * 1000 - ras_center_mm
            positions.append(pos_mm.tolist())

        window_sec    = 20.0
        band_timeline = {}
        # คำนวณ n_windows จาก band แรก — ทุก band ใช้ clean segment ขนาดเดียวกัน
        first_stc      = list(stc_per_band.values())[0]
        window_samples = int(window_sec * sfreq)
        n_windows      = first_stc.data.shape[1] // window_samples
        times_ds       = [0.0] if n_windows == 0 else [w * window_sec for w in range(n_windows)]

        for band_name, stc_b in stc_per_band.items():
            if n_windows == 0:
                seg = stc_b.data[top_idx, :]
                mx  = np.max(np.abs(seg)) or 1
                band_timeline[band_name] = [(np.mean(np.abs(seg), axis=1) / mx).tolist()]
            else:
                frames = []
                for w in range(n_windows):
                    seg = stc_b.data[top_idx, w*window_samples:(w+1)*window_samples]
                    mx  = np.max(np.abs(seg)) or 1
                    frames.append((np.mean(np.abs(seg), axis=1) / mx).tolist())
                band_timeline[band_name] = frames

        stc_timeline = {'positions': positions, 'times': times_ds, 'bands': band_timeline}
        src_logs.append(f"✅ STC timeline: {len(top_idx)} sources × {len(times_ds)} frames (20s/frame, clean segment)")
    except Exception as e:
        src_logs.append(f"⚠️ STC timeline failed: {e}")

    return final_results, waveform, stc_timeline, src_logs


def compute_clinical_findings(results, thickness, asymmetry_pct):
    asymmetry = asymmetry_pct / 100.0

    delta_pct  = results.get('Delta', {}).get('val', 0)
    theta_pct  = results.get('Theta', {}).get('val', 0)
    alpha_pct  = results.get('Alpha', {}).get('val', 0)
    beta_pct   = results.get('Beta',  {}).get('val', 0)
    gamma_pct  = results.get('Gamma', {}).get('val', 0)

    delta_st   = results.get('Delta', {}).get('status', 'normal')
    theta_st   = results.get('Theta', {}).get('status', 'normal')
    alpha_st   = results.get('Alpha', {}).get('status', 'normal')
    beta_st    = results.get('Beta',  {}).get('status', 'normal')
    gamma_st   = results.get('Gamma', {}).get('status', 'normal')
    delta_lobe = results.get('Delta', {}).get('lobe', '')

    mean_thick      = np.mean(list(thickness.values()))
    mri_focal_thick = any(v > mean_thick * 1.3 for v in thickness.values())
    mri_focal_thin  = any(v < mean_thick * 0.7 for v in thickness.values())
    mri_asymmetry   = asymmetry > 0.08

    findings = []

    if delta_st == 'high' and mri_focal_thick:
        findings.append({
            'condition':  'Suspected Brain Tumor',
            'confidence': 'HIGH' if delta_pct > 30 else 'MEDIUM',
            'evidence':   [f'Delta abnormally high ({delta_pct}%) at {delta_lobe}', 'MRI shows abnormal cortical thickness'],
            'recommend':  'Recommend MRI with contrast for further evaluation',
        })
    elif delta_st == 'high':
        findings.append({
            'condition':  'Possible Brain Tumor',
            'confidence': 'LOW',
            'evidence':   [f'Delta abnormally high ({delta_pct}%) at {delta_lobe}', 'No clear MRI thickness abnormality'],
            'recommend':  'Follow up and further examination recommended',
        })

    if delta_st == 'high' and (mri_focal_thin or mri_asymmetry):
        findings.append({
            'condition':  'Suspected Epilepsy',
            'confidence': 'HIGH' if (mri_focal_thin and mri_asymmetry) else 'MEDIUM',
            'evidence':   [f'Delta abnormally high ({delta_pct}%)',
                           'MRI shows cortical thinning or asymmetry' if mri_focal_thin else 'MRI shows asymmetry'],
            'recommend':  'Recommend prolonged EEG monitoring and neurology consult',
        })
    elif delta_st == 'high' and not mri_focal_thick:
        findings.append({
            'condition':  'Possible Epilepsy',
            'confidence': 'LOW',
            'evidence':   [f'Delta abnormally high ({delta_pct}%)', 'No clear MRI abnormality'],
            'recommend':  'Monitor symptoms and consult a physician',
        })

    if theta_st == 'high' and alpha_st == 'low':
        findings.append({
            'condition':  'Suspected ADHD',
            'confidence': 'MEDIUM',
            'evidence':   [f'Theta elevated ({theta_pct}%)', f'Beta elevated ({beta_pct}%)', f'Alpha low ({alpha_pct}%)'],
            'recommend':  'Recommend psychological assessment and physician consult',
        })

    if delta_st == 'high' and theta_st == 'high' and alpha_st == 'low':
        findings.append({
            'condition':  'Suspected Cognitive Decline / Dementia',
            'confidence': 'MEDIUM',
            'evidence':   [f'Delta elevated ({delta_pct}%)', f'Theta elevated ({theta_pct}%)', f'Alpha low ({alpha_pct}%)'],
            'recommend':  'Recommend cognitive and memory evaluation',
        })

    if beta_st == 'high' and gamma_st == 'high':
        findings.append({
            'condition':  'Suspected Anxiety / OCD',
            'confidence': 'LOW',
            'evidence':   [f'Beta elevated ({beta_pct}%)', f'Gamma elevated ({gamma_pct}%)'],
            'recommend':  'Recommend mental health evaluation',
        })

    if not findings:
        findings.append({
            'condition':  'No significant abnormal pattern detected',
            'confidence': 'NORMAL',
            'evidence':   ['All brainwave bands within normal range', 'No clear MRI abnormality'],
            'recommend':  'Results appear normal. Please confirm with a specialist.',
        })

    return findings
