"""
AntarisBot Command Dispatcher — handles ! prefixed commands.

Commands are resolved before rate-limiting and the normal pipeline so
they are always available regardless of LLM state.
"""
import logging
from dataclasses import dataclass
from typing import Optional

from antarisbot.channels.base import InboundMessage

logger = logging.getLogger(__name__)


@dataclass
class CommandResult:
    handled: bool
    response: Optional[str] = None


class CommandDispatcher:
    """
    Dispatch ! commands from inbound messages.

    Usage:
        dispatcher = CommandDispatcher(bot=bot_instance)
        result = await dispatcher.dispatch(inbound)
        if result.handled:
            return result.response
    """

    def __init__(self, bot=None):
        self.bot = bot
        self._model_overrides: dict[str, str] = {}  # user_id → model override

    def get_model_override(self, user_id: str) -> Optional[str]:
        """Get model override for user, if set."""
        return self._model_overrides.get(user_id)

    async def dispatch(self, inbound: InboundMessage) -> CommandResult:
        """Check if message is a command and handle it."""
        text = (inbound.text or "").strip()
        if not text.startswith("!"):
            return CommandResult(handled=False)

        parts = text.split(maxsplit=1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        logger.debug("Command dispatch: cmd=%s user=%s", cmd, inbound.user_id)

        if cmd == "!status":
            return CommandResult(handled=True, response=await self._cmd_status())

        elif cmd == "!model":
            return CommandResult(handled=True, response=await self._cmd_model(inbound.user_id, args))

        elif cmd == "!gather":
            return CommandResult(handled=True, response=await self._cmd_gather(inbound, args))

        elif cmd == "!recap":
            return CommandResult(handled=True, response=await self._cmd_recap(inbound, args))

        elif cmd == "!focus":
            return CommandResult(handled=True, response=await self._cmd_focus(inbound.user_id, args))

        elif cmd == "!unfocus":
            return CommandResult(handled=True, response=await self._cmd_unfocus(inbound.user_id))

        elif cmd == "!help":
            return CommandResult(handled=True, response=self._cmd_help())

        elif cmd == "!ping":
            return CommandResult(handled=True, response="🏓 Pong!")

        elif cmd == "!memory":
            return CommandResult(
                handled=True,
                response=await self._cmd_memory(inbound.user_id, args),
            )

        elif cmd == "!cron":
            return CommandResult(
                handled=True,
                response=await self._cmd_cron(inbound.user_id, args),
            )

        elif cmd == "!profile":
            return CommandResult(
                handled=True,
                response=await self._cmd_profile(inbound.user_id, args),
            )

        elif cmd == "!teach":
            return CommandResult(
                handled=True,
                response=await self._cmd_teach(inbound.user_id, args),
            )

        elif cmd == "!threads":
            return CommandResult(
                handled=True,
                response=await self._cmd_threads(inbound.user_id),
            )

        elif cmd == "!thread":
            return CommandResult(
                handled=True,
                response=await self._cmd_thread(inbound.user_id, args),
            )

        elif cmd == "!shortcuts":
            return CommandResult(
                handled=True,
                response=await self._cmd_shortcuts(inbound.user_id, args),
            )

        elif cmd == "!export":
            return CommandResult(
                handled=True,
                response=await self._cmd_export(inbound.user_id, args),
            )

        elif cmd == "!feedback":
            return CommandResult(
                handled=True,
                response=await self._cmd_feedback(inbound.user_id, args),
            )

        # Unknown command -- don't handle, let it fall through to the LLM
        return CommandResult(handled=False)

    # ── Commands ──────────────────────────────────────────────────────────

    async def _cmd_status(self) -> str:
        lines = ["**📊 NoFace Status**"]
        try:
            stats = self.bot.memory.stats()
            lines.append(f"🧠 Memory: {stats.get('total', 0):,} entries")
        except Exception:
            lines.append("🧠 Memory: unavailable")
        if self.bot and hasattr(self.bot, 'dispatcher') and self.bot.dispatcher:
            providers = list(self.bot.dispatcher.providers.keys())
            lines.append(f"🔌 Providers: {', '.join(providers)}")
        if self.bot and hasattr(self.bot, 'config'):
            lines.append(f"🤖 Model: {self.bot.config.model} via {self.bot.config.provider_name}")
            lines.append(f"🛡️ Guard: {self.bot.config.guard_mode}")
            lines.append(f"🔒 Security: {getattr(self.bot.config, 'security_mode', 'sandboxed')}")
        if self.bot and getattr(self.bot, 'router', None):
            lines.append("🧭 Router: active")
        else:
            lines.append("🧭 Router: off")
        return "\n".join(lines)

    async def _cmd_model(self, user_id: str, args: str) -> str:
        if not args or args.lower() == "auto":
            self._model_overrides.pop(user_id, None)
            return "🔄 Model routing reset to auto."
        aliases = {
            "opus": "claude-opus-4-6",
            "sonnet": "claude-sonnet-4-6",
            "haiku": "claude-haiku-4-5-20251001",
            "gpt": "gpt-5.4",
            "gpt5": "gpt-5.4",
            "gpt4": "gpt-4o",
            "gemini": "gemini-3.1-pro",
            "flash": "gemini-2.0-flash",
            "qwen": "qwen3.5:4b",
            "qwen9b": "qwen3.5:9b",
            "qwen8b": "qwen3:8b",
        }
        model = aliases.get(args.lower(), args)
        self._model_overrides[user_id] = model
        return f"✅ Model set to `{model}`. Use `!model auto` to reset."

    async def _cmd_gather(self, inbound: InboundMessage, args: str) -> str:
        """Gather and ingest recent Discord channel history."""
        from antarisbot.core import gather as _gather

        # Parse hours argument
        hours = 12
        if args.strip():
            try:
                hours = int(args.strip())
            except ValueError:
                return f"Invalid hours value. Valid options: {', '.join(str(h) for h in _gather.VALID_HOURS)}"

        if hours not in _gather.VALID_HOURS:
            return f"Invalid hours: {hours}. Valid options: {', '.join(str(h) for h in _gather.VALID_HOURS)}"

        # Get the Discord client from the DiscordAdapter if available
        discord_client = None
        for ch in getattr(self.bot, '_channels', []):
            from antarisbot.channels.discord import DiscordAdapter
            if isinstance(ch, DiscordAdapter):
                discord_client = ch._client
                break

        if not discord_client:
            return "Gather requires a connected Discord client. Bot may not be running on Discord."

        channel_ids = list(getattr(self.bot.config, 'discord_open_channels', []))
        if not channel_ids:
            return "No open channels configured. Add channels to discord_open_channels in config."

        try:
            result = await _gather.gather_and_ingest(
                client=discord_client,
                memory=self.bot.memory,
                llm=self.bot.llm,
                channel_ids=channel_ids,
                hours=hours,
                user_id=inbound.user_id,
            )
            synced = result["channels_synced"]
            total = result["total_messages"]
            errors = result.get("errors", [])
            channel_summaries = result.get("channel_summaries", [])

            if not channel_summaries:
                msg = f"No new messages found in the last {hours}h."
                if errors:
                    msg += f" Errors: {'; '.join(errors[:3])}"
                return msg

            lines = [f"**Gathered {synced} channel(s) over the last {hours}h ({total} messages):**\n"]
            for cs in channel_summaries:
                lines.append(f"**#{cs['channel_name']}** ({cs['count']} msgs)")
                lines.append(cs["summary"])
                lines.append("")

            if errors:
                lines.append(f"Errors: {'; '.join(errors[:3])}")

            return "\n".join(lines).strip()
        except Exception as e:
            logger.error("gather failed: %s", e)
            return f"Gather failed: {e}"

    async def _cmd_recap(self, inbound: InboundMessage, args: str) -> str:
        try:
            n = int(args) if args else 10
            n = min(max(n, 1), 50)
        except ValueError:
            n = 10
        return f"📝 Recap of last {n} messages: *coming soon.*"

    def _cmd_help(self) -> str:
        return (
            "**📖 Available Commands:**\n"
            "`!help` — show this message\n"
            "`!ping` — check if bot is alive\n"
            "`!gather [hours]` — sync Discord channel history into memory (3/6/12/18/24/48h)\n"
            "`!memory [clear]` — view or clear conversation memory\n"
            "`!export today` — export today's conversation to markdown\n"
            "`!export week` — export last 7 days to markdown\n"
            "`!export project <name>` — export all conversations about a topic\n"
            "`!export all` — export everything to markdown\n"
            "`!cron list` — list scheduled jobs\n"
            "`!cron remove <id>` — remove a cron job\n"
            "`!cron run <id>` — force-run a cron job\n"
            "`!profile` — view your user profile\n"
            "`!teach <text>` — teach the bot a fact or preference\n"
            "`!teach list` — list all your teachings\n"
            "`!teach remove <n>` — remove teaching #n\n"
            "`!teach clear` — remove all your teachings\n"
            "`!focus [topic] [duration]` — enter focus mode (e.g. `!focus antarisbot 1h`)\n"
            "`!unfocus` — exit focus mode\n"
            "`!threads` — list all active conversation threads\n"
            "`!thread <topic>` — show the conversation thread for a topic\n"
            "`!shortcuts` — list all learned implicit shortcuts\n"
            "`!shortcuts remove <phrase>` — remove a learned shortcut\n"
            "`!feedback` — show reaction feedback stats (👍/👎 on bot messages)\n"
            "`!feedback clear` — clear all feedback\n"
        )

    async def _cmd_focus(self, user_id: str, args: str) -> str:
        """Start, show, or check focus mode."""
        from antarisbot.core.focus import FocusManager, parse_duration_minutes

        focus: Optional[FocusManager] = getattr(self.bot, 'focus', None)
        if focus is None:
            return "Focus mode is not available."

        # No args: show current status
        if not args.strip():
            session = focus.get(user_id)
            if not session:
                return "No active focus session. Use `!focus <topic> [duration]` to start one."
            remaining = session.remaining_minutes
            if remaining < 0:
                time_str = "no time limit"
            else:
                time_str = f"{remaining}m remaining"
            return f"Focused on: **{session.topic}** ({time_str})"

        # Parse "<topic> [duration]"
        parts = args.strip().split()
        topic_parts = []
        duration_minutes = 0

        for part in parts:
            parsed = parse_duration_minutes(part)
            if parsed is not None:
                duration_minutes = parsed
                break
            topic_parts.append(part)

        if not topic_parts:
            return "Usage: `!focus <topic> [duration]` — e.g. `!focus antarisbot 1h`"

        topic = " ".join(topic_parts)
        focus.start(user_id, topic, duration_minutes)

        if duration_minutes > 0:
            time_str = f"{duration_minutes}m"
        else:
            time_str = "no time limit"
        return f"Focus set: **{topic}** ({time_str}). Memory recall and context will prioritize this topic."

    async def _cmd_unfocus(self, user_id: str) -> str:
        """End focus mode."""
        from antarisbot.core.focus import FocusManager

        focus: Optional[FocusManager] = getattr(self.bot, 'focus', None)
        if focus is None:
            return "Focus mode is not available."
        was_active = focus.stop(user_id)
        if was_active:
            return "Focus mode ended. Returning to general mode."
        return "No active focus session."

    async def _cmd_memory(self, user_id: str, args: str) -> str:
        """View or clear memory."""
        pipeline = getattr(self.bot, 'pipeline', None)
        if not pipeline:
            return "❌ Pipeline not available."
        if args.strip().lower() == "clear":
            pipeline.clear_history(user_id)
            return "🧹 Conversation history cleared."
        count = pipeline.history_length(user_id)
        return f"💾 Conversation history: {count} message(s) in context."

    async def _cmd_cron(self, user_id: str, args: str) -> str:
        """Manage cron jobs."""
        cron = getattr(self.bot, 'cron', None)
        if not cron:
            return "❌ Cron scheduler not available."

        parts = args.split(maxsplit=1) if args else []
        subcmd = parts[0].lower() if parts else "list"

        if subcmd == "list":
            jobs = cron.list_jobs()
            if not jobs:
                return "📋 No cron jobs scheduled."
            lines = ["**📋 Cron Jobs:**"]
            for job in jobs:
                status = "✅" if job.enabled else "⏸️"
                lines.append(f"{status} `{job.id[:8]}` **{job.name}** — {job.schedule_kind}")
            return "\n".join(lines)

        elif subcmd == "remove" and len(parts) > 1:
            job_id = parts[1].strip()
            # Try partial match
            for jid in [j.id for j in cron.list_jobs()]:
                if jid.startswith(job_id):
                    cron.remove_job(jid)
                    return f"✅ Removed job `{jid[:8]}`."
            return f"❌ No job found matching `{job_id}`."

        elif subcmd == "run" and len(parts) > 1:
            job_id = parts[1].strip()
            for job in cron.list_jobs():
                if job.id.startswith(job_id):
                    cron.run_now(job.id)
                    return f"▶️ Job `{job.id[:8]}` queued to run next tick."
            return f"❌ No job found matching `{job_id}`."

        return "Usage: `!cron list` | `!cron remove <id>` | `!cron run <id>`"

    async def _cmd_profile(self, user_id: str, args: str) -> str:
        """Show user profile."""
        profiles = getattr(self.bot, 'profiles', None)
        if not profiles:
            return "❌ Profile manager not available."
        profile = profiles.get(user_id)
        lines = [f"**👤 Profile: `{user_id}`**"]
        if profile.display_name:
            lines.append(f"Name: {profile.display_name}")
        lines.append(f"Messages: {profile.message_count}")
        lines.append(f"Style: {profile.conversation_style}")
        if profile.last_seen:
            lines.append(f"Last seen: {profile.last_seen[:19].replace('T', ' ')} UTC")
        if profile.notes:
            lines.append(f"Notes: {len(profile.notes)} stored")
        return "\n".join(lines)

    async def _cmd_teach(self, user_id: str, args: str) -> str:
        """Manage user teachings."""
        teachings = getattr(self.bot, 'teachings', None)
        if not teachings:
            return "❌ Teaching store not available."

        text = args.strip()

        if not text or text.lower() == "list":
            items = teachings.list(user_id)
            if not items:
                return "📚 No teachings stored. Use `!teach <text>` to add one."
            lines = ["**📚 Your Teachings:**"]
            for i, t in enumerate(items, 1):
                lines.append(f"{i}. {t['text']}")
            return "\n".join(lines)

        if text.lower() == "clear":
            count = teachings.clear(user_id)
            if count == 0:
                return "📚 No teachings to clear."
            return f"🧹 Cleared {count} teaching(s)."

        parts = text.split(maxsplit=1)
        if parts[0].lower() == "remove":
            if len(parts) < 2:
                return "Usage: `!teach remove <n>`"
            try:
                index = int(parts[1].strip())
            except ValueError:
                return "Usage: `!teach remove <n>` — n must be a number."
            success = teachings.remove(user_id, index)
            if success:
                return f"✅ Teaching #{index} removed."
            return f"❌ No teaching #{index}. Use `!teach list` to see your teachings."

        # Store the teaching
        count = teachings.add(user_id, text)
        return f"✅ Got it! Teaching stored. You now have {count} teaching(s). Use `!teach list` to review."

    async def _cmd_threads(self, user_id: str) -> str:
        """List all active conversation threads for the user."""
        threads = getattr(self.bot, 'threads', None)
        if not threads:
            return "Thread tracking is not available."
        summaries = threads.list_threads(user_id)
        if not summaries:
            return "No conversation threads yet. Chat a bit and they will appear here."
        lines = ["**🧵 Conversation Threads:**"]
        for s in summaries:
            last_ts = s["last_active"]
            import time as _time
            age_s = _time.time() - last_ts
            if age_s < 3600:
                age = f"{int(age_s // 60)}m ago"
            elif age_s < 86400:
                age = f"{int(age_s // 3600)}h ago"
            else:
                age = f"{int(age_s // 86400)}d ago"
            lines.append(
                f"**{s['name']}** -- {s['turn_count']} turns, last active {age}"
            )
        return "\n".join(lines)

    async def _cmd_thread(self, user_id: str, args: str) -> str:
        """Show the conversation thread matching a topic query."""
        threads = getattr(self.bot, 'threads', None)
        if not threads:
            return "Thread tracking is not available."
        query = args.strip()
        if not query:
            return "Usage: `!thread <topic>` -- e.g. `!thread website` or `!thread deployment`"
        turns = threads.get_thread(user_id, query)
        if not turns:
            return f"No thread found matching '{query}'. Use `!threads` to see available topics."
        lines = [f"**🧵 Thread: {turns[0]['topic']}** ({len(turns)} turns)\n"]
        for t in turns[-20:]:  # show up to 20 most recent turns
            prefix = "You" if t["role"] == "user" else "NoFace"
            snippet = t["content"][:200].replace("\n", " ")
            if len(t["content"]) > 200:
                snippet += "..."
            lines.append(f"**{prefix}:** {snippet}")
        return "\n".join(lines)

    async def _cmd_export(self, user_id: str, args: str) -> str:
        """Export conversation history to a markdown file."""
        exporter = getattr(self.bot, 'exporter', None)
        if not exporter:
            return "Export is not available."

        text = args.strip().lower()

        if not text:
            return (
                "**Export usage:**\n"
                "`!export today` — export today's conversation\n"
                "`!export week` — export last 7 days\n"
                "`!export project <name>` — export conversations about a topic\n"
                "`!export all` — export everything"
            )

        if text == "today":
            filepath, summary = exporter.export_recent(user_id, days=1)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        if text == "week":
            filepath, summary = exporter.export_recent(user_id, days=7)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        if text == "all":
            filepath, summary = exporter.export_all(user_id)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        # project <name>
        parts = args.strip().split(maxsplit=1)
        if parts[0].lower() == "project":
            if len(parts) < 2 or not parts[1].strip():
                return "Usage: `!export project <name>`"
            topic = parts[1].strip()
            filepath, summary = exporter.export_by_topic(user_id, topic)
            if not filepath:
                return summary
            return f"Export complete: {summary}"

        return (
            "Unknown export option. Try:\n"
            "`!export today` | `!export week` | `!export project <name>` | `!export all`"
        )

    async def _cmd_shortcuts(self, user_id: str, args: str) -> str:
        """List or remove learned implicit shortcuts."""
        shortcuts = getattr(self.bot, 'shortcuts', None)
        if not shortcuts:
            return "Shortcut learning is not available."

        text = args.strip()

        if not text:
            items = shortcuts.list_shortcuts(user_id)
            if not items:
                return (
                    "No shortcuts learned yet. "
                    "Use short phrases repeatedly for the same action and I will learn them automatically."
                )
            lines = ["**Learned Shortcuts:**"]
            for item in items:
                lines.append(f'`{item["phrase"]}` -> {item["expansion"]} (seen {item["count"]}x)')
            return "\n".join(lines)

        parts = text.split(maxsplit=1)
        if parts[0].lower() == "remove":
            if len(parts) < 2:
                return "Usage: `!shortcuts remove <phrase>`"
            phrase = parts[1].strip()
            removed = shortcuts.remove(user_id, phrase)
            if removed:
                return f'Shortcut `{phrase}` removed.'
            return f'No shortcut found for `{phrase}`. Use `!shortcuts` to see your shortcuts.'

        return "Usage: `!shortcuts` or `!shortcuts remove <phrase>`"

    async def _cmd_feedback(self, user_id: str, args: str) -> str:
        """Show or clear reaction-based feedback."""
        feedback = getattr(self.bot, 'feedback', None)
        if not feedback:
            return "Feedback tracking is not available."

        text = args.strip().lower()

        if text == "clear":
            feedback.clear(user_id)
            return "Feedback cleared."

        stats = feedback.get_stats(user_id)
        if stats["total"] == 0:
            return (
                "No feedback recorded yet.\n"
                "React to my messages with 👍 or 👎 to train my responses."
            )

        pos = stats["positive"]
        neg = stats["negative"]
        total = stats["total"]
        lines = [
            f"**Reaction Feedback ({total} total)**",
            f"Positive: {pos} (👍 ❤️ ✅ 🔥 💯 👏)",
            f"Negative: {neg} (👎 ❌ 😕 🚫)",
            "",
            "Use `!feedback clear` to reset.",
        ]
        return "\n".join(lines)
