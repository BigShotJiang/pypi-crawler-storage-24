import json
import os
import shutil
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

DEFAULT_CONFIG_DIR = Path.home() / ".antarisbot"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.json"


@dataclass
class Config:
    bot_name: str = "Antaris"
    provider_name: str = "anthropic"
    api_key: str = ""
    model: str = "claude-sonnet-4-6"
    fallback_model: str = "claude-sonnet-4-20250514"
    ollama_base_url: str = "http://localhost:11434/v1"
    discord_token: str = ""
    discord_enabled: bool = False
    discord_open_channels: list = field(default_factory=list)
    discord_bridge_enabled: bool = False
    discord_bridge_channels: list = field(default_factory=list)
    telegram_token: str = ""
    telegram_open_chats: list = field(default_factory=list)
    telegram_enabled: bool = False
    slack_bot_token: str = ""
    slack_app_token: str = ""
    slack_enabled: bool = False
    slack_open_channels: list = field(default_factory=list)
    memory_store: str = str(DEFAULT_CONFIG_DIR / "memory")
    memory_search_limit: int = 10
    memory_min_relevance: float = 0.3
    guard_mode: str = "monitor"  # monitor | warn | block
    security_mode: str = "standard"  # open(0) | standard(1) | sandboxed(2) | secured(3) | encrypted(4)
    context_max_tokens: int = 100000
    rate_limit_messages: int = 20
    rate_limit_window_seconds: int = 60
    auto_update: bool = False
    notify_updates: bool = True
    config_path: str = str(DEFAULT_CONFIG_PATH)
    # Extra provider API keys for multi-provider routing
    anthropic_api_key: str = ""
    openai_api_key: str = ""
    google_api_key: str = ""
    qwen_api_key: str = ""
    # Compaction notification settings
    owner_user_id: str = ""            # Discord user ID to DM on compaction
    compaction_threshold: int = 80     # message count to trigger ping
    pre_compaction_ratio: float = 0.75  # trigger pre-flush at this fraction of threshold
    startup_restore_days: int = 2      # how many days of daily logs to read on startup
    # Memory settings
    per_turn_recall: bool = True       # enable per-turn memory recall
    # Heartbeat settings
    heartbeat_enabled: bool = False    # enable heartbeat system
    heartbeat_interval_minutes: int = 30  # heartbeat check interval

    @classmethod
    def load(cls, path: Optional[str] = None) -> Optional["Config"]:
        config_path = Path(path or DEFAULT_CONFIG_PATH)
        if not config_path.exists():
            return None
        with open(config_path) as f:
            data = json.load(f)
        # Guard: if config.json is empty ({}), treat it as missing/corrupt
        if not data or (not data.get("provider") and not data.get("bot")):
            import logging, traceback
            logging.getLogger(__name__).warning(
                "Config.load(): config.json appears empty or corrupt (no provider/bot section). "
                "File size: %d bytes. Content preview: %s. "
                "Will attempt backup recovery.\nCaller: %s",
                config_path.stat().st_size,
                repr(data)[:200],
                ''.join(traceback.format_stack()[-4:])
            )
            return None
        cfg = cls()
        cfg.config_path = str(config_path)
        cfg.bot_name = data.get("bot", {}).get("name", "Antaris")
        provider = data.get("provider", {})
        cfg.provider_name = provider.get("name", "anthropic")
        cfg.api_key = provider.get("apiKey", "")
        cfg.model = provider.get("model", "claude-sonnet-4-6")
        cfg.fallback_model = provider.get("fallbackModel", "claude-sonnet-4-20250514")
        cfg.ollama_base_url = provider.get("ollamaBaseUrl", "http://localhost:11434/v1")
        # Load extra provider keys for multi-provider routing
        extra_providers = data.get("providers", {})
        cfg.anthropic_api_key = extra_providers.get("anthropic", {}).get("apiKey", cfg.api_key if cfg.provider_name == "anthropic" else "")
        cfg.openai_api_key = extra_providers.get("openai", {}).get("apiKey", cfg.api_key if cfg.provider_name == "openai" else "")
        cfg.google_api_key = extra_providers.get("google", {}).get("apiKey", cfg.api_key if cfg.provider_name == "google" else "")
        cfg.qwen_api_key = extra_providers.get("qwen", {}).get("apiKey", cfg.api_key if cfg.provider_name == "qwen" else "")
        # Ollama base URL can be overridden per-provider in providers block
        _ollama_provider_url = extra_providers.get("ollama", {}).get("baseUrl", "")
        if _ollama_provider_url:
            cfg.ollama_base_url = _ollama_provider_url
        discord = data.get("channels", {}).get("discord", {})
        cfg.discord_enabled = discord.get("enabled", False)
        cfg.discord_token = discord.get("token", "")
        cfg.discord_open_channels = discord.get("openChannels", [])
        cfg.discord_bridge_enabled = discord.get("bridgeEnabled", False)
        cfg.discord_bridge_channels = discord.get("bridgeChannels", [])
        telegram = data.get("channels", {}).get("telegram", {})
        cfg.telegram_enabled = telegram.get("enabled", False)
        cfg.telegram_token = telegram.get("token", "")
        cfg.telegram_open_chats = telegram.get("openChats", [])
        slack = data.get("channels", {}).get("slack", {})
        cfg.slack_enabled = slack.get("enabled", False)
        cfg.slack_bot_token = slack.get("botToken", "")
        cfg.slack_app_token = slack.get("appToken", "")
        cfg.slack_open_channels = slack.get("openChannels", [])
        memory = data.get("memory", {})
        cfg.memory_store = memory.get("store", str(DEFAULT_CONFIG_DIR / "memory"))
        cfg.memory_search_limit = memory.get("searchLimit", 10)
        cfg.memory_min_relevance = memory.get("minRelevance", 0.3)
        guard = data.get("guard", {})
        cfg.guard_mode = guard.get("mode", "monitor")
        security = data.get("security", {})
        cfg.security_mode = security.get("mode", "sandboxed")
        # Derive guard_mode from security_mode (can be overridden by explicit guard config)
        # Guard is ALWAYS on — it's part of Antaris Core (antaris-guard).
        # Security mode only affects the default intensity, never disables it.
        _mode_to_guard = {
            "open": "monitor",       # level 0
            "standard": "monitor",   # level 1
            "sandboxed": "monitor",  # level 2
            "secured": "warn",       # level 3
            "encrypted": "block",    # level 4
            "locked": "block",       # legacy alias for encrypted
        }
        cfg.guard_mode = _mode_to_guard.get(cfg.security_mode, cfg.guard_mode)
        # But still allow explicit guard override in config
        if "mode" in guard:
            cfg.guard_mode = guard.get("mode", cfg.guard_mode)
        rate_limit = data.get("rate_limit", {})
        cfg.rate_limit_messages = rate_limit.get("max_messages", 20)
        cfg.rate_limit_window_seconds = rate_limit.get("window_seconds", 60)
        updates = data.get("updates", {})
        cfg.auto_update = updates.get("autoUpdate", False)
        cfg.notify_updates = updates.get("notifyUpdates", True)
        bot_section = data.get("bot", {})
        cfg.owner_user_id = bot_section.get("ownerUserId", "")
        cfg.compaction_threshold = bot_section.get("compactionThreshold", 80)
        cfg.pre_compaction_ratio = bot_section.get("preCompactionRatio", 0.75)
        cfg.startup_restore_days = bot_section.get("startupRestoreDays", 2)
        # Memory settings  
        memory_section = data.get("memory", {})
        cfg.per_turn_recall = memory_section.get("perTurnRecall", True)
        # Heartbeat settings
        cfg.heartbeat_enabled = bot_section.get("heartbeatEnabled", False)
        cfg.heartbeat_interval_minutes = bot_section.get("heartbeatIntervalMinutes", 30)
        
        # Tools configuration
        cfg._tools_config = data.get("tools", {})
        
        return cfg

    def save(self, path: Optional[str] = None):
        # Guard: never overwrite a valid config with an empty/unconfigured one.
        # Allow oat01 OAuth tokens and standard api03 keys.
        _has_key = bool(self.api_key) or bool(self.anthropic_api_key) or bool(self.openai_api_key)
        if not _has_key and self.provider_name != "ollama":
            import logging, traceback
            logging.getLogger(__name__).warning(
                "Config.save() blocked -- no API key set. Refusing to overwrite config with empty values.\n"
                "Caller traceback:\n%s", ''.join(traceback.format_stack())
            )
            return
        # Forensic logging: trace every save() call to diagnose config wipes
        import logging, traceback
        _logger = logging.getLogger(__name__)
        _logger.info(
            "Config.save() called — bot=%s, provider=%s, has_key=%s, has_discord_token=%s\n"
            "Caller: %s",
            self.bot_name, self.provider_name, bool(self.api_key),
            bool(self.discord_token), ''.join(traceback.format_stack()[-4:])
        )
        config_path = Path(path or self.config_path)
        config_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "bot": {
                "name": self.bot_name,
                "ownerUserId": self.owner_user_id,
                "compactionThreshold": self.compaction_threshold,
                "preCompactionRatio": self.pre_compaction_ratio,
                "startupRestoreDays": self.startup_restore_days,
                "heartbeatEnabled": self.heartbeat_enabled,
                "heartbeatIntervalMinutes": self.heartbeat_interval_minutes,
            },
            "provider": {
                "name": self.provider_name,
                "apiKey": self.api_key,
                "model": self.model,
                "fallbackModel": self.fallback_model,
                "ollamaBaseUrl": self.ollama_base_url,
            },
            "channels": {
                "discord": {
                    "enabled": self.discord_enabled,
                    "token": self.discord_token,
                    "openChannels": self.discord_open_channels or [],
                    "bridgeEnabled": self.discord_bridge_enabled,
                    "bridgeChannels": self.discord_bridge_channels or []
                },
                "telegram": {
                    "enabled": self.telegram_enabled,
                    "token": self.telegram_token,
                    "openChats": self.telegram_open_chats or []
                },
                "slack": {
                    "enabled": self.slack_enabled,
                    "botToken": self.slack_bot_token,
                    "appToken": self.slack_app_token,
                    "openChannels": self.slack_open_channels or []
                }
            },
            "memory": {
                "store": self.memory_store,
                "searchLimit": self.memory_search_limit,
                "minRelevance": self.memory_min_relevance,
                "autoIngest": True,
                "autoRecall": True,
                "perTurnRecall": self.per_turn_recall
            },
            "guard": {"mode": self.guard_mode},
            "security": {"mode": self.security_mode},
            "context": {"maxTokens": self.context_max_tokens},
            "updates": {
                "autoUpdate": self.auto_update,
                "notifyUpdates": self.notify_updates
            },
            "tools": getattr(self, '_tools_config', {})
        }
        # Preserve unknown top-level keys from existing config (providers, router, requireMention, etc.)
        # This prevents data loss when save() doesn't model all fields.
        if config_path.exists() and config_path.stat().st_size > 10:
            try:
                with open(config_path) as _f:
                    existing = json.load(_f)
                if isinstance(existing, dict):
                    for key, value in existing.items():
                        if key not in data:
                            data[key] = value
                            _logger.debug("Config.save(): preserved unknown key '%s' from existing config", key)
                    # Also preserve discord.requireMention and discord.openChannels if not in data
                    existing_discord = existing.get("channels", {}).get("discord", {})
                    if "requireMention" in existing_discord:
                        data["channels"]["discord"]["requireMention"] = existing_discord["requireMention"]
            except (json.JSONDecodeError, OSError, KeyError):
                pass

        # Backup the existing config before overwriting, if it is non-empty valid JSON.
        bak_path = config_path.parent / ("." + config_path.name + ".bak")
        if config_path.exists() and config_path.stat().st_size > 0:
            try:
                with open(config_path) as _f:
                    json.load(_f)
                shutil.copy2(str(config_path), str(bak_path))
            except (json.JSONDecodeError, OSError):
                pass  # existing file is corrupt or unreadable -- skip backup
        # Atomic write: write to a temp file then rename into place.
        tmp_path = config_path.parent / (config_path.name + ".tmp")
        with open(tmp_path, "w") as f:
            json.dump(data, f, indent=2)
        os.rename(str(tmp_path), str(config_path))
        print(f"   Config saved to {config_path}")

    @classmethod
    def load_with_fallback(cls, path: Optional[str] = None) -> Optional["Config"]:
        """Load config, falling back to .bak if main file is empty or corrupt."""
        cfg = cls.load(path)
        if cfg and cfg.api_key:
            return cfg
        # Try backup
        config_path = Path(path or DEFAULT_CONFIG_PATH)
        # Check both naming conventions for backup
        bak_path = config_path.parent / ("." + config_path.name + ".bak")
        if not bak_path.exists():
            bak_path = config_path.parent / (config_path.name + ".bak")
        if bak_path.exists():
            import logging
            logging.getLogger(__name__).warning(
                "Main config empty/corrupt, loading from backup: %s", bak_path
            )
            recovered = cls.load(str(bak_path))
            if recovered and recovered.api_key:
                # Self-heal: restore backup to main config path
                recovered.config_path = str(config_path)
                try:
                    shutil.copy2(str(bak_path), str(config_path))
                    logging.getLogger(__name__).info(
                        "Config self-healed: restored %s from backup", config_path
                    )
                except OSError as e:
                    logging.getLogger(__name__).warning(
                        "Could not self-heal config: %s", e
                    )
                return recovered
            return recovered
        return cfg

    def validate(self) -> list[str]:
        errors = []
        if self.provider_name != "ollama" and not self.api_key:
            errors.append("API key is required")
        if self.discord_enabled and not self.discord_token:
            errors.append("Discord token required when Discord is enabled")
        if self.telegram_enabled and not self.telegram_token:
            errors.append("Telegram token required when Telegram is enabled")
        if self.slack_enabled and not self.slack_bot_token:
            errors.append("Slack bot token required when Slack is enabled")
        if self.slack_enabled and not self.slack_app_token:
            errors.append("Slack app token required when Slack is enabled")
        valid_modes = ("open", "standard", "sandboxed", "secured", "encrypted", "locked")
        if self.security_mode not in valid_modes:
            errors.append(f"Invalid security_mode '{self.security_mode}'. Must be one of: {', '.join(valid_modes)}")
        return errors


def run_init_wizard(security_mode: str = None):
    """Interactive setup wizard.

    Args:
        security_mode: Pre-select security mode ('open', 'sandboxed', 'locked').
                       When provided, the security prompt is skipped entirely.
    """
    print("🤖 Welcome to AntarisBot\n")

    config = Config()
    config_dir = DEFAULT_CONFIG_DIR
    config_dir.mkdir(parents=True, exist_ok=True)

    # Bot name
    name = input(f"Bot name [{config.bot_name}]: ").strip()
    if name:
        config.bot_name = name

    # Provider
    print("\nLLM Provider:")
    print("  [1] Anthropic (Claude) — recommended")
    print("  [2] OpenAI (GPT)")
    print("  [3] Google (Gemini)")
    print("  [4] Ollama (local, fully offline, zero cost)")
    choice = input("Select [1]: ").strip() or "1"
    if choice == "2":
        config.provider_name = "openai"
        config.model = "gpt-5.2"
        config.fallback_model = "gpt-3.5-turbo"
    elif choice == "3":
        config.provider_name = "google"
        config.model = "gemini-3.1-pro"
        config.fallback_model = "gemini-2.0-flash"
    elif choice == "4":
        config.provider_name = "ollama"
        config.api_key = "ollama"
        print("\nOllama model (installed models: run `ollama list`):")
        print("  Recommended: qwen3.5:4b (best balance, ~2.5GB)")
        print("  Lightweight: qwen3.5:2b, qwen3.5:0.8b")
        print("  High quality: qwen3.5:9b, qwen3:8b")
        model = input("Model [qwen3.5:4b]: ").strip() or "qwen3.5:4b"
        config.model = model
        config.fallback_model = model
        base_url = input("Ollama base URL [http://localhost:11434/v1]: ").strip()
        if base_url:
            config.ollama_base_url = base_url

    # API Key (skip for ollama)
    if config.provider_name != "ollama":
        api_key = input(f"\n{config.provider_name.capitalize()} API Key: ").strip()
        config.api_key = api_key

    # Discord
    print("\nDiscord bot token (optional — press Enter to skip):")
    discord_token = input("Token: ").strip()
    if discord_token:
        config.discord_enabled = True
        config.discord_token = discord_token

    # Security mode
    if security_mode:
        # Pre-selected via --security flag — skip the prompt
        config.security_mode = security_mode
        print(f"\nSecurity mode: {security_mode} (pre-selected)")
    else:
        print("\nSecurity mode — how much can your bot access?")
        print("  [0] Open — no restrictions, full access, developer mode")
        print("  [1] Standard (recommended) — light safety net, workspace + home scoped")
        print("  [2] Sandboxed — filesystem restricted, subprocesses blocked")
        print("  [3] Secured — network allowlisted, destructive ops need approval")
        print("  [4] Encrypted — all tools need approval, memory encrypted, full audit")
        sec_choice = input("Select [1]: ").strip() or "1"
        config.security_mode = {
            "0": "open", "1": "standard", "2": "sandboxed",
            "3": "secured", "4": "encrypted"
        }.get(sec_choice, "standard")

    # Validate
    errors = config.validate()
    if errors:
        print("\n⚠️  Validation issues:")
        for e in errors:
            print(f"   - {e}")

    # Save
    config.save()

    # Create default SOUL.md if it doesn't exist
    soul_path = config_dir / "SOUL.md"
    if not soul_path.exists():
        import shutil
        from pathlib import Path as P
        template = P(__file__).parent.parent / "persona" / "templates" / "default_soul.md"
        if template.exists():
            shutil.copy(template, soul_path)
            print(f"   SOUL.md created at {soul_path}")

    # Create USER.md if it doesn't exist
    user_path = config_dir / "USER.md"
    if not user_path.exists():
        user_path.write_text("# About You\n\n*Antaris will learn about you over time.*\n")
        print(f"   USER.md created at {user_path}")

    # Create memory dir
    memory_dir = Path(config.memory_store)
    memory_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n✅ {config.bot_name} initialized at {config_dir}")
    print("   Run 'antarisbot start' to launch.")
    if not config.discord_enabled:
        print("   Tip: Run 'antarisbot chat' to test in terminal first.")
