# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowBuiltInConformancePackTemplateRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'template_id': 'str',
        'x_language': 'str'
    }

    attribute_map = {
        'template_id': 'template_id',
        'x_language': 'X-Language'
    }

    def __init__(self, template_id=None, x_language=None):
        r"""ShowBuiltInConformancePackTemplateRequest

        The model defined in huaweicloud sdk

        :param template_id: 合规规则包模板ID。
        :type template_id: str
        :param x_language: 选择接口返回的信息的语言，默认为\&quot;zh-cn\&quot;中文
        :type x_language: str
        """
        
        

        self._template_id = None
        self._x_language = None
        self.discriminator = None

        self.template_id = template_id
        if x_language is not None:
            self.x_language = x_language

    @property
    def template_id(self):
        r"""Gets the template_id of this ShowBuiltInConformancePackTemplateRequest.

        合规规则包模板ID。

        :return: The template_id of this ShowBuiltInConformancePackTemplateRequest.
        :rtype: str
        """
        return self._template_id

    @template_id.setter
    def template_id(self, template_id):
        r"""Sets the template_id of this ShowBuiltInConformancePackTemplateRequest.

        合规规则包模板ID。

        :param template_id: The template_id of this ShowBuiltInConformancePackTemplateRequest.
        :type template_id: str
        """
        self._template_id = template_id

    @property
    def x_language(self):
        r"""Gets the x_language of this ShowBuiltInConformancePackTemplateRequest.

        选择接口返回的信息的语言，默认为\"zh-cn\"中文

        :return: The x_language of this ShowBuiltInConformancePackTemplateRequest.
        :rtype: str
        """
        return self._x_language

    @x_language.setter
    def x_language(self, x_language):
        r"""Sets the x_language of this ShowBuiltInConformancePackTemplateRequest.

        选择接口返回的信息的语言，默认为\"zh-cn\"中文

        :param x_language: The x_language of this ShowBuiltInConformancePackTemplateRequest.
        :type x_language: str
        """
        self._x_language = x_language

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowBuiltInConformancePackTemplateRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
