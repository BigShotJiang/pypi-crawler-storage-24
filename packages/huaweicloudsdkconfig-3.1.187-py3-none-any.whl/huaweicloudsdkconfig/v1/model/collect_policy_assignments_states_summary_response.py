# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CollectPolicyAssignmentsStatesSummaryResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'compliance_state': 'str',
        'policy_assignment': 'PolicyAssignment',
        'results': 'PolicyComplianceSummaryResults'
    }

    attribute_map = {
        'compliance_state': 'compliance_state',
        'policy_assignment': 'policy_assignment',
        'results': 'results'
    }

    def __init__(self, compliance_state=None, policy_assignment=None, results=None):
        r"""CollectPolicyAssignmentsStatesSummaryResponse

        The model defined in huaweicloud sdk

        :param compliance_state: 规则合规状态
        :type compliance_state: str
        :param policy_assignment: 
        :type policy_assignment: :class:`huaweicloudsdkconfig.v1.PolicyAssignment`
        :param results: 
        :type results: :class:`huaweicloudsdkconfig.v1.PolicyComplianceSummaryResults`
        """
        
        super().__init__()

        self._compliance_state = None
        self._policy_assignment = None
        self._results = None
        self.discriminator = None

        if compliance_state is not None:
            self.compliance_state = compliance_state
        if policy_assignment is not None:
            self.policy_assignment = policy_assignment
        if results is not None:
            self.results = results

    @property
    def compliance_state(self):
        r"""Gets the compliance_state of this CollectPolicyAssignmentsStatesSummaryResponse.

        规则合规状态

        :return: The compliance_state of this CollectPolicyAssignmentsStatesSummaryResponse.
        :rtype: str
        """
        return self._compliance_state

    @compliance_state.setter
    def compliance_state(self, compliance_state):
        r"""Sets the compliance_state of this CollectPolicyAssignmentsStatesSummaryResponse.

        规则合规状态

        :param compliance_state: The compliance_state of this CollectPolicyAssignmentsStatesSummaryResponse.
        :type compliance_state: str
        """
        self._compliance_state = compliance_state

    @property
    def policy_assignment(self):
        r"""Gets the policy_assignment of this CollectPolicyAssignmentsStatesSummaryResponse.

        :return: The policy_assignment of this CollectPolicyAssignmentsStatesSummaryResponse.
        :rtype: :class:`huaweicloudsdkconfig.v1.PolicyAssignment`
        """
        return self._policy_assignment

    @policy_assignment.setter
    def policy_assignment(self, policy_assignment):
        r"""Sets the policy_assignment of this CollectPolicyAssignmentsStatesSummaryResponse.

        :param policy_assignment: The policy_assignment of this CollectPolicyAssignmentsStatesSummaryResponse.
        :type policy_assignment: :class:`huaweicloudsdkconfig.v1.PolicyAssignment`
        """
        self._policy_assignment = policy_assignment

    @property
    def results(self):
        r"""Gets the results of this CollectPolicyAssignmentsStatesSummaryResponse.

        :return: The results of this CollectPolicyAssignmentsStatesSummaryResponse.
        :rtype: :class:`huaweicloudsdkconfig.v1.PolicyComplianceSummaryResults`
        """
        return self._results

    @results.setter
    def results(self, results):
        r"""Sets the results of this CollectPolicyAssignmentsStatesSummaryResponse.

        :param results: The results of this CollectPolicyAssignmentsStatesSummaryResponse.
        :type results: :class:`huaweicloudsdkconfig.v1.PolicyComplianceSummaryResults`
        """
        self._results = results

    def to_dict(self):
        import warnings
        warnings.warn("CollectPolicyAssignmentsStatesSummaryResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CollectPolicyAssignmentsStatesSummaryResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
