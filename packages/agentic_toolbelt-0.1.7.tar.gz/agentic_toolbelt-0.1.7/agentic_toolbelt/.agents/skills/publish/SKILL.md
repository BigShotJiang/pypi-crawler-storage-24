---
name: publish
description: Run the final release-facing gate: verify required evidence exists, summarize validation, disclose skipped checks, and confirm the handoff is ready. Use before final delivery and after AGENTS or skill changes. Do not use as a substitute for implementation or testing.
---
## Use when
- the work is ready for final handoff
- release notes or final verification matter
- AGENTS, skills, or custom-agent files changed

## Do not use when
- implementation has not been completed
- required validation has not been attempted
- the task is still in discovery or planning

## Inputs
- changed files
- validation evidence
- docs impact
- residual risks or waivers

## Outputs
- pass or blocked final status
- commands run and intentionally skipped
- residual risks
- release-facing summary
- final memory snapshot for the completed workflow

## Success criteria
- missing evidence is called out instead of hidden
- the final handoff is short and complete
- AGENTS or skill changes include at least one positive and one negative routing check

## Routing
Calling this skill means execute this agent chain in order:
1. coordinator reads the full memory trail
2. spawn `gatekeeper`

For AGENTS, skills, or custom-agent changes, execute this chain instead:
1. coordinator reads the full memory trail
2. spawn `instruction-maintainer`
3. pass the maintainer result to `reviewer`
4. pass the reviewer result to `gatekeeper`
5. coordinator records the final routing-eval outcome in memory

Do not emulate this chain in one thread. If any required subagent cannot be spawned, stop and report the skill as blocked.
All agents in this skill should also write a compact summary to the shared JSON memory layer.
