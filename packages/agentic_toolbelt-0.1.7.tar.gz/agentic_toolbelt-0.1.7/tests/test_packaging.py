from importlib import resources
import unittest

import agentic_toolbelt
from setup import _data_files


class PackagingTests(unittest.TestCase):
    def test_payload_files_are_available(self):
        root = resources.files(agentic_toolbelt)
        self.assertTrue((root / ".agents").is_dir())
        self.assertTrue((root / ".codex").is_dir())
        self.assertTrue((root / "AGENTS.md").is_file())
        self.assertTrue((root / ".agents" / "ralph" / "agents.sh").is_file())
        self.assertTrue((root / ".codex" / "skills" / "commit" / "SKILL.md").is_file())
        self.assertTrue((root / ".agents" / "skills" / "plan" / "SKILL.md").is_file())
        self.assertTrue((root / ".agents" / "skills" / "implement" / "SKILL.md").is_file())
        self.assertTrue((root / ".agents" / "skills" / "docs" / "SKILL.md").is_file())
        self.assertTrue((root / ".agents" / "skills" / "publish" / "SKILL.md").is_file())
        self.assertTrue((root / ".github" / "skills" / "plan" / "SKILL.md").is_file())
        self.assertTrue((root / ".github" / "skills" / "implement" / "SKILL.md").is_file())
        self.assertTrue((root / ".github" / "skills" / "docs" / "SKILL.md").is_file())
        self.assertTrue((root / ".github" / "skills" / "publish" / "SKILL.md").is_file())

    def test_setup_data_files_excludes_cache_artifacts(self):
        files = _data_files()

        self.assertNotIn("__pycache__/__init__.cpython-312.pyc", files)
        self.assertFalse(any(path.endswith(".pyc") for path in files))
