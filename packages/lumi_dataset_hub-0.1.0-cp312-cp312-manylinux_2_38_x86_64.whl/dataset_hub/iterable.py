from __future__ import annotations

import importlib
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any

from dataset_hub.config import HubClientConfig
from dataset_hub.types import DecodePolicy

try:
    import torch.utils.data as _torch_data  # type: ignore[import-not-found]
except ImportError:
    _TORCH_ITERABLE_DATASET = None
else:
    _TORCH_ITERABLE_DATASET = _torch_data.IterableDataset


def _project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _extension_path() -> Path:
    target_dir = _project_root() / "target" / "debug"
    candidates = sorted(target_dir.rglob("*client_core*.so"))
    if not candidates:
        raise ImportError("Rust extension was not built")
    for candidate in candidates:
        if candidate.name.startswith("libclient_core"):
            return candidate
    return candidates[0]


def _load_native_module():
    module_name = "dataset_hub._client_core"
    if module_name in sys.modules:
        return sys.modules[module_name]

    try:
        module = importlib.import_module(module_name)
    except ModuleNotFoundError as error:
        if error.name != module_name:
            raise
        module = None
    else:
        sys.modules[module_name] = module
        return module

    try:
        path = _extension_path()
    except ImportError as error:
        raise ImportError(
            "Rust extension for dataset_hub is missing. Build it first with `cargo build -p client-core`."
        ) from error

    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load Rust extension from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


class _HubIterableDatasetMixin:
    def __init__(
        self,
        dataset: str,
        split: str,
        config: HubClientConfig | None = None,
        *,
        base_url: str | None = None,
        source_kind: str | None = None,
        repo: str | None = None,
        subset: str | None = None,
        revision: str | None = None,
        dataset_id: str | None = None,
        shuffle: bool = False,
        seed: int | None = None,
        epoch: int | None = None,
        start_offset: int = 0,
        explicit_row_ids: list[int] | None = None,
        required_fields: list[str] | None = None,
        decode_policy: DecodePolicy = DecodePolicy.REFERENCE_ONLY,
        buffer_size: int = 16,
        heartbeat_interval_seconds: float = 30.0,
        heartbeat_initial_delay_seconds: float = 0.0,
        sample_transform: Any = None,
    ):
        if config is None:
            if base_url is None:
                raise TypeError("base_url is required when config is not provided")
            config = HubClientConfig(
                base_url=base_url,
                source_kind=source_kind,
                repo=repo,
                subset=subset,
                revision=revision,
                dataset_id=dataset_id,
                shuffle=shuffle,
                seed=seed,
                epoch=epoch,
                start_offset=start_offset,
                explicit_row_ids=list(explicit_row_ids or []),
                required_fields=list(required_fields or []),
                decode_policy=decode_policy,
                buffer_size=buffer_size,
                heartbeat_interval_seconds=heartbeat_interval_seconds,
                heartbeat_initial_delay_seconds=heartbeat_initial_delay_seconds,
                sample_transform=sample_transform,
            )
        else:
            direct_kwargs_used = (
                base_url is not None
                or source_kind is not None
                or repo is not None
                or subset is not None
                or revision is not None
                or dataset_id is not None
                or shuffle
                or seed is not None
                or epoch is not None
                or start_offset != 0
                or explicit_row_ids is not None
                or required_fields is not None
                or decode_policy is not DecodePolicy.REFERENCE_ONLY
                or buffer_size != 16
                or heartbeat_interval_seconds != 30.0
                or heartbeat_initial_delay_seconds != 0.0
                or sample_transform is not None
            )
            if direct_kwargs_used:
                raise TypeError("pass either config or direct kwargs, not both")

        self._sample_transform = config.sample_transform
        native = _load_native_module()
        options_json = json.dumps(
            {
                "source_kind": config.source_kind,
                "repo": config.repo,
                "subset": config.subset,
                "revision": config.revision,
                "dataset_id": config.dataset_id,
                "shuffle": config.shuffle,
                "seed": config.seed,
                "epoch": config.epoch,
                "start_offset": config.start_offset,
                "explicit_row_ids": config.explicit_row_ids,
                "required_fields": config.required_fields,
                "decode_policy": config.decode_policy.value,
                "buffer_size": config.buffer_size,
                "heartbeat_interval_seconds": config.heartbeat_interval_seconds,
                "heartbeat_initial_delay_seconds": config.heartbeat_initial_delay_seconds,
            }
        )
        self._dataset = native.PyBufferedDataset(
            base_url=config.base_url,
            dataset=dataset,
            split=split,
            options_json=options_json,
        )

    def __iter__(self):
        return self

    def __next__(self):
        sample = next(self._dataset)
        if self._sample_transform is None:
            return sample
        return self._sample_transform(sample)

    def buffered_len(self) -> int:
        return self._dataset.buffered_len()


def _hub_iterable_init(
    self,
    dataset: str,
    split: str,
    config: HubClientConfig | None = None,
    *,
    base_url: str | None = None,
    source_kind: str | None = None,
    repo: str | None = None,
    subset: str | None = None,
    revision: str | None = None,
    dataset_id: str | None = None,
    shuffle: bool = False,
    seed: int | None = None,
    epoch: int | None = None,
    start_offset: int = 0,
    explicit_row_ids: list[int] | None = None,
    required_fields: list[str] | None = None,
    decode_policy: DecodePolicy = DecodePolicy.REFERENCE_ONLY,
    buffer_size: int = 16,
    heartbeat_interval_seconds: float = 30.0,
    heartbeat_initial_delay_seconds: float = 0.0,
    sample_transform: Any = None,
):
    _HubIterableDatasetMixin.__init__(
        self,
        dataset,
        split,
        config,
        base_url=base_url,
        source_kind=source_kind,
        repo=repo,
        subset=subset,
        revision=revision,
        dataset_id=dataset_id,
        shuffle=shuffle,
        seed=seed,
        epoch=epoch,
        start_offset=start_offset,
        explicit_row_ids=explicit_row_ids,
        required_fields=required_fields,
        decode_policy=decode_policy,
        buffer_size=buffer_size,
        heartbeat_interval_seconds=heartbeat_interval_seconds,
        heartbeat_initial_delay_seconds=heartbeat_initial_delay_seconds,
        sample_transform=sample_transform,
    )


if _TORCH_ITERABLE_DATASET is None:

    class _HubIterableDatasetPlain(_HubIterableDatasetMixin):
        __init__ = _hub_iterable_init

    HubIterableDataset = _HubIterableDatasetPlain
else:

    class _HubIterableDatasetTorch(_TORCH_ITERABLE_DATASET, _HubIterableDatasetMixin):
        def __init__(
            self,
            dataset: str,
            split: str,
            config: HubClientConfig | None = None,
            *,
            base_url: str | None = None,
            source_kind: str | None = None,
            repo: str | None = None,
            subset: str | None = None,
            revision: str | None = None,
            dataset_id: str | None = None,
            shuffle: bool = False,
            seed: int | None = None,
            epoch: int | None = None,
            start_offset: int = 0,
            explicit_row_ids: list[int] | None = None,
            required_fields: list[str] | None = None,
            decode_policy: DecodePolicy = DecodePolicy.REFERENCE_ONLY,
            buffer_size: int = 16,
            heartbeat_interval_seconds: float = 30.0,
            heartbeat_initial_delay_seconds: float = 0.0,
            sample_transform: Any = None,
        ):
            _hub_iterable_init(
                self,
                dataset,
                split,
                config,
                base_url=base_url,
                source_kind=source_kind,
                repo=repo,
                subset=subset,
                revision=revision,
                dataset_id=dataset_id,
                shuffle=shuffle,
                seed=seed,
                epoch=epoch,
                start_offset=start_offset,
                explicit_row_ids=explicit_row_ids,
                required_fields=required_fields,
                decode_policy=decode_policy,
                buffer_size=buffer_size,
                heartbeat_interval_seconds=heartbeat_interval_seconds,
                heartbeat_initial_delay_seconds=heartbeat_initial_delay_seconds,
                sample_transform=sample_transform,
            )

    HubIterableDataset = _HubIterableDatasetTorch
