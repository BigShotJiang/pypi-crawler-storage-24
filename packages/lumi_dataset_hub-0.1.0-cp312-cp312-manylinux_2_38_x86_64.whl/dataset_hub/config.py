from dataclasses import dataclass, field

from dataset_hub.types import DecodePolicy, SampleTransform, SourceKind


@dataclass(slots=True)
class HubClientConfig:
    base_url: str
    source_kind: str | SourceKind | None = None
    repo: str | None = None
    subset: str | None = None
    revision: str | None = None
    dataset_id: str | None = None
    shuffle: bool = False
    seed: int | None = None
    epoch: int | None = None
    start_offset: int = 0
    explicit_row_ids: list[int] = field(default_factory=list)
    required_fields: list[str] = field(default_factory=list)
    decode_policy: DecodePolicy = DecodePolicy.REFERENCE_ONLY
    buffer_size: int = 16
    heartbeat_interval_seconds: float = 30.0
    heartbeat_initial_delay_seconds: float = 0.0
    sample_transform: SampleTransform | None = None

    def __post_init__(self):
        if isinstance(self.source_kind, SourceKind):
            self.source_kind = self.source_kind.value
        if self.buffer_size <= 0:
            raise ValueError("buffer_size must be greater than 0")
        if self.heartbeat_interval_seconds <= 0:
            raise ValueError("heartbeat_interval_seconds must be greater than 0")
        if self.heartbeat_initial_delay_seconds < 0:
            raise ValueError("heartbeat_initial_delay_seconds must be non-negative")
