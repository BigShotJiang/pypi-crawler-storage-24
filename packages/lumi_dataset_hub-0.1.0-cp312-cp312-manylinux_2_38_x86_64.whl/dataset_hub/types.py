from enum import Enum
from typing import Any, Callable


class DecodePolicy(str, Enum):
    REFERENCE_ONLY = "reference_only"
    EAGER = "eager"


class SourceKind(str, Enum):
    MOCK_HF = "mock_hf"
    HF_PARQUET = "hf_parquet"


Sample = dict[str, Any]
SampleTransform = Callable[[Sample], Sample]
