# TODO update tag names to be prefixed with domino.agents in order to make origin clear
EVALUATION_TAG_PREFIX = "domino.prog"
DOMINO_INTERNAL_EVAL_TAG = "domino.internal.is_eval"
MIN_MLFLOW_VERSION = "3.2.0"
MIN_DOMINO_VERSION = "6.2.0"
LARGEST_MAX_RESULTS_PAGE_SIZE = 500
EXPERIMENT_AGENT_TAG = "domino.agent"
AGENT_RUN_TAG = "domino.internal.run.is_agent"
