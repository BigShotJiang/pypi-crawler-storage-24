"""
Compatibility utilities for jgo 1.x API.

These functions provide backward compatibility with the old jgo API.
"""

import sys
import warnings

import psutil


def add_jvm_args_as_necessary(argv, gc_option="-XX:+UseConcMarkSweepGC"):
    """
    Extend existing argv with reasonable default values for garbage collection
    and max heap size.

    .. deprecated::
        Use :class:`jgo.exec.config.JVMConfig` instead for new code.
        This function will be removed in jgo 3.0.

    Args:
        argv: Argument vector.
        gc_option: Use this garbage collector settings, if any.
            Note: CMS is deprecated; use G1GC for modern JVMs.

    Returns:
        argv with added JVM arguments.
    """
    warnings.warn(
        "add_jvm_args_as_necessary() is deprecated. "
        "Use jgo.exec.config.JVMConfig instead. "
        "This function will be removed in jgo 3.0.",
        DeprecationWarning,
        stacklevel=2,
    )

    # Add GC option if specified and not already present
    if gc_option and gc_option not in argv:
        argv = list(argv) + [gc_option]
    else:
        argv = list(argv)

    # Check if -Xmx already specified
    for arg in argv:
        if "-Xmx" in arg:
            return argv

    # Auto-detect heap size using psutil (keeping original logic)
    total_memory = psutil.virtual_memory().total
    exponent = 3 if total_memory > 2 * 1024**3 else 2
    memory_unit = "G" if exponent == 3 else "M"
    max_heap_size = "{}{}".format(
        max(total_memory // (1024**exponent) // 2, 1), memory_unit
    )

    # Prepend heap size
    argv = ["-Xmx{}".format(max_heap_size)] + argv

    return argv


def maven_scijava_repository():
    """
    Get the SciJava Maven repository URL.

    .. deprecated::
        This function is deprecated and will be removed in jgo 3.0.
        Use the URL directly: "https://maven.scijava.org/content/groups/public"

    Returns:
        SciJava repository URL.
    """
    warnings.warn(
        "maven_scijava_repository() is deprecated and will be removed in jgo 3.0. "
        'Use the URL directly: "https://maven.scijava.org/content/groups/public"',
        DeprecationWarning,
        stacklevel=2,
    )
    return "https://maven.scijava.org/content/groups/public"


def main_from_endpoint(
    primary_endpoint,
    argv=sys.argv[1:],
    repositories=None,
    primary_endpoint_version=None,
    primary_endpoint_main_class=None,
    secondary_endpoints=(),
):
    """
    Convenience method to populate appropriate argv for jgo.

    This is useful to distribute Java programs as Python modules.

    For example, to run paintera with slf4j logging bindings, call:
        main_from_endpoint(
            'org.janelia.saalfeldlab:paintera',
            primary_endpoint_version='0.8.1',
            secondary_endpoints=('org.slf4j:slf4j-simple:1.7.25',),
        )

    Args:
        primary_endpoint: The primary endpoint of the Java program you want to run.
        repositories: Any maven repository that holds the required jars. Defaults
            to {'scijava.public': maven_scijava_repository()}.
        primary_endpoint_version: Will be appended to primary_endpoint if it
            does not evaluate to False.
        primary_endpoint_main_class: Will be appended to primary_endpoint if it
            does not evaluate to False.
        secondary_endpoints: Any other endpoints that should be added.

    Returns:
        None.
    """
    warnings.warn(
        "jgo.main_from_endpoint() is deprecated. Use the new jgo API: jgo.run()",
        DeprecationWarning,
        stacklevel=2,
    )

    # Import here to avoid circular dependency
    from ..jgo import _jgo_main as main

    if repositories is None:
        repositories = {"scijava.public": maven_scijava_repository()}

    double_dash_index = (
        [i for (i, arg) in enumerate(argv) if arg == "--"][0] if "--" in argv else -1
    )
    jgo_and_jvm_argv = ([] if double_dash_index < 0 else argv[:double_dash_index]) + [
        "--ignore-jgorc"
    ]
    repository_strings = ["-r"] + [
        "{}={}".format(k, v) for (k, v) in repositories.items()
    ]
    primary_endpoint = (
        primary_endpoint + ":{}".format(primary_endpoint_version)
        if primary_endpoint_version
        else primary_endpoint
    )
    primary_endpoint = (
        primary_endpoint + ":{}".format(primary_endpoint_main_class)
        if primary_endpoint_main_class
        else primary_endpoint
    )
    endpoint = ["+".join((primary_endpoint,) + secondary_endpoints)]
    paintera_argv = argv if double_dash_index < 0 else argv[double_dash_index + 1 :]
    argv = (
        add_jvm_args_as_necessary(jgo_and_jvm_argv)
        + repository_strings
        + endpoint
        + paintera_argv
    )

    return main(argv=argv)
