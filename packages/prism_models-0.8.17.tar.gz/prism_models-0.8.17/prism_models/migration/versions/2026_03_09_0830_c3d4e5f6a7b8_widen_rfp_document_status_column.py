"""widen_rfp_document_status_column

Revision ID: c3d4e5f6a7b8
Revises: b2c3d4e5f6a7
Create Date: 2026-03-09 08:30:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'c3d4e5f6a7b8'
down_revision: Union[str, Sequence[str], None] = 'b2c3d4e5f6a7'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Widen status column to accommodate ingestion lifecycle values."""
    op.alter_column(
        'rfp_document',
        'status',
        type_=sa.String(20),
        existing_type=sa.String(10),
        existing_nullable=False,
    )


def downgrade() -> None:
    """Revert status column width."""
    op.alter_column(
        'rfp_document',
        'status',
        type_=sa.String(10),
        existing_type=sa.String(20),
        existing_nullable=False,
    )
