"""
Tests for the schemas module — Pydantic output models and validation.

All tests are unit tests — no API keys required.
"""

import sys
sys.path.insert(0, '.')

import pytest

from api.analysis.schemas import (
    SponsorOutput,
    MarketOutput,
    CompsOutput,
    RentRollOutput,
    CashFlowOutput,
    QuickReviewOutput,
    SCHEMA_REGISTRY,
    get_json_schema,
    validate_output,
)


# ═══════════════════════════════════════════════════════════════════════════
# Schema Registry
# ═══════════════════════════════════════════════════════════════════════════

class TestSchemaRegistry:
    def test_registry_has_16_tools(self):
        """Registry has schemas for all 16 tools."""
        expected = {
            "sponsor_analysis", "market_research", "comp_analysis",
            "rent_roll_analyzer", "cash_flow", "quick_review",
            "deal_screen", "debt_sizing_preview", "loan_sizer",
            "loan_pricing", "nuance_gate", "ic_memo",
            "term_sheet_comparator", "business_plan", "renovation_roi",
            "pref_equity_qr",
        }
        assert set(SCHEMA_REGISTRY.keys()) == expected

    def test_all_schemas_are_pydantic_models(self):
        """All registered schemas are Pydantic BaseModel subclasses."""
        from pydantic import BaseModel
        for name, model in SCHEMA_REGISTRY.items():
            assert issubclass(model, BaseModel), f"{name} is not a BaseModel"

    def test_get_json_schema_returns_dict(self):
        """get_json_schema returns a valid JSON schema dict."""
        for name in SCHEMA_REGISTRY:
            schema = get_json_schema(name)
            assert isinstance(schema, dict), f"Schema for {name} is not a dict"
            assert "properties" in schema or "$defs" in schema, (
                f"Schema for {name} missing properties"
            )

    def test_get_json_schema_missing_returns_none(self):
        assert get_json_schema("nonexistent_tool") is None


# ═══════════════════════════════════════════════════════════════════════════
# Sponsor Output
# ═══════════════════════════════════════════════════════════════════════════

class TestSponsorOutput:
    def test_minimal_valid(self):
        """Minimal valid sponsor output."""
        data = {
            "sponsor_tier": "B",
            "recommendation": "proceed",
        }
        output = SponsorOutput.model_validate(data)
        assert output.sponsor_tier == "B"
        assert output.recommendation == "proceed"
        assert output.strengths == []
        assert output.go_no_go == "GO"

    def test_full_output(self):
        """Full sponsor output with all fields."""
        data = {
            "sponsor_tier": "A",
            "entity_overview": {
                "name": "Test Sponsor LLC",
                "legal_structure": "LLC",
                "headquarters": "Dallas, TX",
                "years_in_operation": 15,
                "principals": ["John Smith", "Jane Doe"],
                "total_units_owned": 5000,
                "markets_active": ["Dallas", "Houston", "Austin"],
            },
            "track_record": {
                "total_deals": 25,
                "total_units": 5000,
                "multifamily_focus_pct": 95.0,
            },
            "financial_capacity": {
                "estimated_net_worth": "$150M+",
                "net_worth_to_loan_ratio": "3.5x",
            },
            "background_check": {
                "litigation_findings": [],
                "default_history": "None identified",
                "bankruptcy_check": "Clear",
            },
            "operational_capability": {
                "property_management": "In-house PM platform",
            },
            "relevant_experience_score": 10,
            "strengths": ["Deep Texas market expertise", "In-house PM"],
            "concerns": ["Geographic concentration"],
            "recommendation": "proceed",
            "recommendation_detail": "Strong institutional sponsor with deep track record.",
            "go_no_go": "GO",
        }
        output = SponsorOutput.model_validate(data)
        assert output.sponsor_tier == "A"
        assert output.relevant_experience_score == 10
        assert len(output.strengths) == 2
        assert output.entity_overview.total_units_owned == 5000


# ═══════════════════════════════════════════════════════════════════════════
# Market Output
# ═══════════════════════════════════════════════════════════════════════════

class TestMarketOutput:
    def test_minimal_valid(self):
        data = {
            "market_rating": "strong",
            "summary": "Dallas market is strong.",
        }
        output = MarketOutput.model_validate(data)
        assert output.market_rating == "strong"
        assert output.strengths == []

    def test_with_nested_profiles(self):
        data = {
            "msa": {"name": "Dallas-Fort Worth, TX", "population": 8000000},
            "employment": {"unemployment_rate": 3.5, "top_employers": ["UT Southwestern"]},
            "multifamily_fundamentals": {"vacancy_rate_pct": 5.2, "rent_growth_yoy_pct": 3.1},
            "supply_pipeline": {"units_under_construction": 25000, "supply_risk_rating": "moderate"},
            "market_rating": "strong",
            "summary": "Strong market fundamentals.",
        }
        output = MarketOutput.model_validate(data)
        assert output.msa.population == 8000000
        assert output.supply_pipeline.supply_risk_rating == "moderate"


# ═══════════════════════════════════════════════════════════════════════════
# Comps Output
# ═══════════════════════════════════════════════════════════════════════════

class TestCompsOutput:
    def test_minimal_valid(self):
        data = {"summary": "Limited comps available."}
        output = CompsOutput.model_validate(data)
        assert output.rent_comps == []

    def test_with_comps(self):
        data = {
            "rent_comps": [
                {"name": "Comp A", "address": "123 Oak St", "units": 200, "avg_rent": 1850.0},
                {"name": "Comp B", "address": "456 Elm St", "units": 150, "avg_rent": 1750.0},
            ],
            "sales_comps": [
                {"name": "Sale A", "sale_price": 45000000, "price_per_unit": 225000, "cap_rate_pct": 5.25},
            ],
            "rent_analysis": {"avg_market_rent": 1800, "loss_to_lease_pct": 3.5},
            "summary": "Market supports current rents.",
        }
        output = CompsOutput.model_validate(data)
        assert len(output.rent_comps) == 2
        assert output.rent_comps[0].avg_rent == 1850.0
        assert output.sales_comps[0].cap_rate_pct == 5.25


# ═══════════════════════════════════════════════════════════════════════════
# Cash Flow Output
# ═══════════════════════════════════════════════════════════════════════════

class TestCashFlowOutput:
    def test_minimal_valid(self):
        data = {"summary": "Cash flow analysis complete."}
        output = CashFlowOutput.model_validate(data)
        assert output.income.gpr is None

    def test_with_dual_scenario(self):
        data = {
            "income": {"gpr": 5000000, "vacancy_pct": 5.0, "effective_gross_income": 4750000},
            "expenses": {"total_operating_expenses": 2000000, "opex_per_unit": 10000},
            "noi": {"stabilized_noi": 2750000, "noi_per_unit": 13750},
            "dual_scenario": {
                "lender_underwrite": {"noi": 2750000},
                "sponsor_proforma": {"noi": 3100000},
                "variance": {"noi_difference": -350000},
            },
            "summary": "Lender NOI 11.3% below sponsor.",
        }
        output = CashFlowOutput.model_validate(data)
        assert output.noi.stabilized_noi == 2750000
        assert output.dual_scenario.lender_underwrite["noi"] == 2750000


# ═══════════════════════════════════════════════════════════════════════════
# Quick Review Output
# ═══════════════════════════════════════════════════════════════════════════

class TestQuickReviewOutput:
    def test_minimal_valid(self):
        data = {
            "screen_result": "PASS",
            "recommendation": "Deal passes credit box.",
        }
        output = QuickReviewOutput.model_validate(data)
        assert output.screen_result == "PASS"
        assert output.strengths == []
        assert output.risks == []

    def test_full_review(self):
        data = {
            "screen_result": "CONDITIONAL",
            "property": {"address": "456 Oak Ave, Dallas, TX", "unit_count": 200},
            "key_metrics": {
                "ltv_as_is": {"value": 68.2, "threshold": 75.0, "status": "pass"},
                "dscr_stabilized": {"value": 1.18, "threshold": 1.05, "status": "pass"},
            },
            "sizing": {
                "max_loan_from_waterfall": 30000000,
                "binding_constraint": "dscr_stabilized",
            },
            "sponsor_assessment": {"name": "Test Sponsor", "tier": "B"},
            "strengths": ["Strong location", "Experienced sponsor"],
            "risks": [{"risk": "Supply", "detail": "High pipeline", "severity": "Medium", "mitigant": "Absorption strong"}],
            "dd_questions": ["Verify T-12 OpEx", "Confirm renovation scope"],
            "recommendation": "Proceed with caution.",
            "recommendation_detail": "Deal meets credit box but supply risk warrants monitoring.",
        }
        output = QuickReviewOutput.model_validate(data)
        assert output.screen_result == "CONDITIONAL"
        assert len(output.risks) == 1
        assert output.risks[0].severity == "Medium"


# ═══════════════════════════════════════════════════════════════════════════
# Validate Output Function
# ═══════════════════════════════════════════════════════════════════════════

class TestValidateOutput:
    def test_valid_output(self):
        data = {"sponsor_tier": "B", "recommendation": "proceed"}
        result = validate_output("sponsor_analysis", data)
        assert result is not None
        assert isinstance(result, SponsorOutput)

    def test_unknown_tool_returns_none(self):
        result = validate_output("unknown_tool", {"key": "value"})
        assert result is None

    def test_invalid_data_returns_none(self):
        # SponsorOutput requires sponsor_tier and recommendation
        # But Pydantic v2 has defaults, so this may still validate
        # Test with truly invalid data
        result = validate_output("sponsor_analysis", "not a dict")
        assert result is None
