"""
Tests for the report mapper — JSON → DOCX builders.

Tests verify that each builder produces valid DOCX bytes
from sample JSON data. Requires python-docx.
"""

import sys
sys.path.insert(0, '.')

import pytest

try:
    import docx
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False

from api.analysis.report.mapper import (
    build_report,
    build_sponsor_report,
    build_market_report,
    build_comps_report,
    build_cash_flow_report,
    build_quick_review_report,
    REPORT_BUILDERS,
    _format_dollar,
    _format_pct,
)


# ═══════════════════════════════════════════════════════════════════════════
# Format Helpers
# ═══════════════════════════════════════════════════════════════════════════

class TestFormatHelpers:
    def test_format_dollar_millions(self):
        assert _format_dollar(42_000_000) == "$42.0M"
        assert _format_dollar(8_900_000) == "$8.9M"

    def test_format_dollar_thousands(self):
        assert _format_dollar(840_000) == "$840K"
        assert _format_dollar(125_000) == "$125K"

    def test_format_dollar_small(self):
        assert _format_dollar(45_000) == "$45,000"
        assert _format_dollar(8_500) == "$8,500"

    def test_format_dollar_none(self):
        assert _format_dollar(None) == "N/A"

    def test_format_dollar_string(self):
        assert _format_dollar("$42.0M") == "$42.0M"

    def test_format_pct(self):
        assert _format_pct(64.1) == "64.1%"
        assert _format_pct(7.8) == "7.8%"
        assert _format_pct(5.25, decimals=2) == "5.25%"

    def test_format_pct_none(self):
        assert _format_pct(None) == "N/A"


# ═══════════════════════════════════════════════════════════════════════════
# Builder Registry
# ═══════════════════════════════════════════════════════════════════════════

class TestBuilderRegistry:
    def test_registry_has_16_builders(self):
        assert len(REPORT_BUILDERS) == 16
        expected = {
            "sponsor_analysis", "market_research", "comp_analysis",
            "cash_flow", "quick_review", "deal_screen", "debt_sizing_preview",
            "loan_sizer", "loan_pricing", "nuance_gate", "ic_memo",
            "term_sheet_comparator", "business_plan", "renovation_roi",
            "rent_roll_analyzer", "pref_equity_qr",
        }
        assert set(REPORT_BUILDERS.keys()) == expected

    def test_unknown_tool_returns_none(self):
        result = build_report("nonexistent_tool", {})
        assert result is None


# ═══════════════════════════════════════════════════════════════════════════
# DOCX Generation Tests (require python-docx)
# ═══════════════════════════════════════════════════════════════════════════

@pytest.mark.skipif(not HAS_DOCX, reason="python-docx not installed")
class TestSponsorReport:
    def test_minimal_data(self):
        data = {
            "sponsor_tier": "B",
            "recommendation": "proceed",
            "recommendation_detail": "Solid sponsor with adequate track record.",
            "strengths": ["Texas market expertise"],
            "concerns": ["Geographic concentration"],
        }
        result = build_sponsor_report(data, "Test Deal")
        assert isinstance(result, bytes)
        assert len(result) > 1000  # Valid DOCX is at least 1KB

    def test_full_data(self):
        data = {
            "sponsor_tier": "A",
            "entity_overview": {
                "name": "Test Sponsor LLC",
                "legal_structure": "LLC",
                "headquarters": "Dallas, TX",
                "years_in_operation": 15,
                "principals": ["John Smith"],
                "total_units_owned": 5000,
                "markets_active": ["Dallas", "Houston"],
            },
            "track_record": {
                "total_deals": 25,
                "total_units": 5000,
                "notable_deals": [
                    {"name": "Oak Park", "units": 300, "market": "Dallas", "status": "Performing"},
                ],
            },
            "financial_capacity": {
                "estimated_net_worth": "$150M+",
                "net_worth_to_loan_ratio": "3.5x",
            },
            "background_check": {
                "litigation_findings": [],
                "default_history": "None",
                "bankruptcy_check": "Clear",
            },
            "operational_capability": {
                "property_management": "In-house",
            },
            "relevant_experience_score": 10,
            "strengths": ["Deep expertise", "In-house PM"],
            "concerns": ["Concentration risk"],
            "recommendation": "proceed",
            "recommendation_detail": "Strong institutional sponsor.",
            "go_no_go": "GO",
        }
        result = build_sponsor_report(data, "Oak Park Test")
        assert isinstance(result, bytes)
        assert len(result) > 5000


@pytest.mark.skipif(not HAS_DOCX, reason="python-docx not installed")
class TestMarketReport:
    def test_minimal_data(self):
        data = {"market_rating": "strong", "summary": "Strong market."}
        result = build_market_report(data, "Test Deal")
        assert isinstance(result, bytes)
        assert len(result) > 1000

    def test_with_profiles(self):
        data = {
            "msa": {"name": "Dallas-Fort Worth, TX", "population": 8000000},
            "employment": {"unemployment_rate": 3.5},
            "multifamily_fundamentals": {"vacancy_rate_pct": 5.2, "rent_growth_yoy_pct": 3.1},
            "supply_pipeline": {"units_under_construction": 25000, "supply_risk_rating": "moderate"},
            "strengths": ["Job growth", "Diversified economy"],
            "risks": ["Supply pipeline elevated"],
            "market_rating": "strong",
            "summary": "Dallas market fundamentals are strong.",
        }
        result = build_market_report(data)
        assert isinstance(result, bytes)
        assert len(result) > 3000


@pytest.mark.skipif(not HAS_DOCX, reason="python-docx not installed")
class TestCompsReport:
    def test_with_comps(self):
        data = {
            "rent_comps": [
                {"name": "Comp A", "units": 200, "avg_rent": 1850.0, "distance_miles": 1.2},
            ],
            "sales_comps": [
                {"name": "Sale A", "sale_price": 45000000, "price_per_unit": 225000, "cap_rate_pct": 5.25},
            ],
            "summary": "Market supports rents.",
        }
        result = build_comps_report(data, "Test Deal")
        assert isinstance(result, bytes)
        assert len(result) > 3000


@pytest.mark.skipif(not HAS_DOCX, reason="python-docx not installed")
class TestCashFlowReport:
    def test_with_dual_scenario(self):
        data = {
            "income": {"gpr": 5000000, "effective_gross_income": 4750000},
            "expenses": {"total_operating_expenses": 2000000},
            "noi": {"stabilized_noi": 2750000, "noi_per_unit": 13750},
            "dual_scenario": {
                "lender_underwrite": {"noi": 2750000},
                "sponsor_proforma": {"noi": 3100000},
            },
            "summary": "Cash flow analysis complete.",
        }
        result = build_cash_flow_report(data, "Test Deal")
        assert isinstance(result, bytes)
        assert len(result) > 3000


@pytest.mark.skipif(not HAS_DOCX, reason="python-docx not installed")
class TestQuickReviewReport:
    def test_minimal_data(self):
        data = {
            "screen_result": "PASS",
            "recommendation": "Deal passes credit box.",
        }
        result = build_quick_review_report(data, "Test Deal")
        assert isinstance(result, bytes)
        assert len(result) > 1000

    def test_full_review(self):
        data = {
            "screen_result": "CONDITIONAL",
            "property": {"address": "456 Oak Ave", "unit_count": 200, "asset_value": 42000000},
            "key_metrics": {
                "ltv_as_is": {"value": 68.2, "threshold": 75.0, "status": "pass"},
                "dscr_stabilized": {"value": 1.18, "threshold": 1.05, "status": "pass"},
            },
            "sizing": {"max_loan_from_waterfall": 30000000, "binding_constraint": "dscr_stabilized"},
            "sponsor_assessment": {"name": "Test Sponsor", "tier": "B"},
            "strengths": ["Strong location"],
            "risks": [{"risk": "Supply", "detail": "High pipeline", "severity": "Medium", "mitigant": "Absorption"}],
            "dd_questions": ["Verify T-12"],
            "recommendation": "Proceed with caution.",
            "recommendation_detail": "Deal meets credit box.",
        }
        result = build_quick_review_report(data)
        assert isinstance(result, bytes)
        assert len(result) > 5000


@pytest.mark.skipif(not HAS_DOCX, reason="python-docx not installed")
class TestBuildReport:
    def test_build_report_dispatch(self):
        """build_report dispatches to correct builder."""
        data = {"sponsor_tier": "B", "recommendation": "proceed"}
        result = build_report("sponsor_analysis", data, "Test")
        assert isinstance(result, bytes)

    def test_build_report_unknown(self):
        result = build_report("nonexistent", {})
        assert result is None
