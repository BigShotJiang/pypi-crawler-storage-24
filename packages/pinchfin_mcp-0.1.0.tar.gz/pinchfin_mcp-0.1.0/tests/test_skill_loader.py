"""
Tests for the skill_loader module — structured SKILL.md parsing.

All tests are unit tests — no API keys required.
"""

import sys
sys.path.insert(0, '.')

import pytest

from api.analysis.skill_loader import (
    parse_skill,
    load_skill_full,
    load_skill_constraints,
    clear_cache,
    MAX_SKILL_CHARS,
    MAX_CONSTRAINT_CHARS,
    _strip_frontmatter,
    _extract_section,
)


@pytest.fixture(autouse=True)
def clear_skill_cache():
    """Clear cache before each test for isolation."""
    clear_cache()
    yield
    clear_cache()


# ═══════════════════════════════════════════════════════════════════════════
# Frontmatter Stripping
# ═══════════════════════════════════════════════════════════════════════════

class TestFrontmatterStripping:
    def test_strips_yaml_frontmatter(self):
        text = "---\nname: test\ntype: skill\n---\n\n# Main Content\nBody text."
        result = _strip_frontmatter(text)
        assert result.startswith("# Main Content")
        assert "name: test" not in result

    def test_no_frontmatter_unchanged(self):
        text = "# No Frontmatter\nJust content."
        result = _strip_frontmatter(text)
        assert result == text

    def test_incomplete_frontmatter_unchanged(self):
        text = "---\nname: test\nNo closing delimiter"
        result = _strip_frontmatter(text)
        # No closing --- means it's not valid frontmatter
        assert "name: test" in result


# ═══════════════════════════════════════════════════════════════════════════
# Section Extraction
# ═══════════════════════════════════════════════════════════════════════════

class TestSectionExtraction:
    def test_extracts_matching_section(self):
        text = "# Introduction\nSome intro.\n## Methodology\nStep 1.\nStep 2.\n## Output\nJSON format."
        result = _extract_section(text, ["methodology"])
        assert "Step 1" in result
        assert "Step 2" in result
        assert "JSON format" not in result

    def test_extracts_nested_content(self):
        text = "# Top\n## Constraints\nRule 1.\nRule 2.\n### Sub-constraint\nDetail.\n## Other\nNope."
        result = _extract_section(text, ["constraint"])
        assert "Rule 1" in result
        assert "Detail" in result
        assert "Nope" not in result

    def test_no_match_returns_empty(self):
        text = "# Introduction\nSome text.\n## Conclusion\nEnd."
        result = _extract_section(text, ["methodology"])
        assert result == ""

    def test_case_insensitive(self):
        text = "# METHODOLOGY\nStep 1.\n# Output\nDone."
        result = _extract_section(text, ["methodology"])
        assert "Step 1" in result


# ═══════════════════════════════════════════════════════════════════════════
# Skill Parsing — Core P1 Skills
# ═══════════════════════════════════════════════════════════════════════════

class TestSkillParsing:
    """Verify all 15 bundled skills parse correctly."""

    CORE_SKILLS = [
        "sponsor-analysis",
        "market-submarket",
        "comp-analysis",
        "rent-roll-analysis",
        "cash-flow-modeling",
        "quick-review",
    ]

    SECONDARY_SKILLS = [
        "loan-sizing",
        "expense-underwriting",
        "cre-calculations",
        "construction-budget-review",
        "institutional-formatting",
        "nuance-gate-analysis",
        "credit-memo",
        "returns-analysis",
        "risk-rating",
    ]

    @pytest.mark.parametrize("skill_name", CORE_SKILLS)
    def test_core_skill_parses(self, skill_name):
        """Core P1 skills parse into structured sections."""
        skill = parse_skill(skill_name)
        assert skill is not None, f"Skill {skill_name} not found"
        assert skill.name == skill_name
        assert len(skill.raw_text) > 100, f"Skill {skill_name} raw text too short"
        # Core skills should have substantial methodology
        assert len(skill.methodology) > 50, (
            f"Skill {skill_name} methodology too short ({len(skill.methodology)} chars)"
        )

    @pytest.mark.parametrize("skill_name", SECONDARY_SKILLS)
    def test_secondary_skill_parses(self, skill_name):
        """Secondary skills parse without errors."""
        skill = parse_skill(skill_name)
        assert skill is not None, f"Skill {skill_name} not found"
        assert len(skill.raw_text) > 50

    def test_sponsor_analysis_depth(self):
        """Sponsor analysis has all major sections."""
        skill = parse_skill("sponsor-analysis")
        assert skill is not None
        # Full skill is 567 lines — should extract substantial content
        assert len(skill.full_prompt) > 2000, "Sponsor skill prompt too short"
        # Should have methodology content
        assert len(skill.methodology) > 500, "Sponsor methodology too short"

    def test_cash_flow_has_constraints(self):
        """Cash flow skill has extractable constraints."""
        skill = parse_skill("cash-flow-modeling")
        assert skill is not None
        block = skill.constraint_block
        # Should have some constraints extracted
        assert len(block) > 0, "Cash flow has no constraint block"

    def test_quick_review_has_methodology(self):
        """Quick review (462 lines) has substantial methodology."""
        skill = parse_skill("quick-review")
        assert skill is not None
        assert len(skill.methodology) > 500, "Quick review methodology too short"


# ═══════════════════════════════════════════════════════════════════════════
# Full Prompt and Constraint Block
# ═══════════════════════════════════════════════════════════════════════════

class TestPromptGeneration:
    def test_full_prompt_within_limits(self):
        """Full prompt stays within MAX_SKILL_CHARS."""
        for name in TestSkillParsing.CORE_SKILLS:
            text = load_skill_full(name)
            assert len(text) <= MAX_SKILL_CHARS + 50  # small buffer for truncation text
            assert len(text) > 100, f"Skill {name} full prompt too short"

    def test_constraint_block_within_limits(self):
        """Constraint blocks stay within MAX_CONSTRAINT_CHARS."""
        for name in TestSkillParsing.SECONDARY_SKILLS:
            text = load_skill_constraints(name)
            assert len(text) <= MAX_CONSTRAINT_CHARS + 50

    def test_full_prompt_has_sections(self):
        """Full prompt includes section headers."""
        text = load_skill_full("sponsor-analysis")
        assert "METHODOLOGY" in text

    def test_missing_skill_returns_empty(self):
        """Missing skill returns empty string."""
        assert load_skill_full("nonexistent-skill-xyz") == ""
        assert load_skill_constraints("nonexistent-skill-xyz") == ""


# ═══════════════════════════════════════════════════════════════════════════
# Caching
# ═══════════════════════════════════════════════════════════════════════════

class TestCaching:
    def test_cache_returns_same_object(self):
        """Second parse returns cached object."""
        skill1 = parse_skill("sponsor-analysis")
        skill2 = parse_skill("sponsor-analysis")
        assert skill1 is skill2

    def test_clear_cache_forces_reparse(self):
        """Clearing cache forces fresh parse."""
        skill1 = parse_skill("sponsor-analysis")
        clear_cache()
        skill2 = parse_skill("sponsor-analysis")
        assert skill1 is not skill2
        assert skill1.raw_text == skill2.raw_text


# ═══════════════════════════════════════════════════════════════════════════
# Backward Compatibility
# ═══════════════════════════════════════════════════════════════════════════

class TestBackwardCompat:
    def test_load_skill_via_prompts_module(self):
        """load_skill() in prompts.py still works (now uses SkillLoader)."""
        from api.analysis.prompts import load_skill
        text = load_skill("sponsor-analysis")
        assert "METHODOLOGY" in text
        assert len(text) > 100

    def test_build_prompt_with_new_skill_text(self):
        """build_analysis_prompt works with structured skill text."""
        from api.analysis.prompts import load_skill, build_analysis_prompt
        skill_text = load_skill("market-submarket")
        system, user = build_analysis_prompt(
            skill_text=skill_text,
            deal_data={"property": "123 Main St", "units": 100},
            task_description="Analyze this market.",
        )
        assert "PinchFin" in system
        assert "METHODOLOGY" in system
        assert "FORMAT ENFORCEMENT" in system
        assert "123 Main St" in user
