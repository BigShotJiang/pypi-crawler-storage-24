"""
Tests for the analysis module — credit box waterfall, prompt builder, and
integration smoke tests.

Unit tests (credit_box, prompts) require NO API keys.
Integration tests require ANTHROPIC_API_KEY and are skipped otherwise.
"""

import sys
sys.path.insert(0, '.')

import os
import pytest

from api.analysis import is_analysis_available
from api.analysis.credit_box import (
    run_constraint_waterfall,
    MAX_AS_IS_LTV,
    MAX_STABILIZED_LTV,
    MAX_LTC,
    MIN_DEBT_YIELD,
    MIN_DSCR,
    MAX_LOAN_AMOUNT,
)
from api.analysis.prompts import load_skill, build_analysis_prompt


# ═══════════════════════════════════════════════════════════════════════════
# Credit Box Config Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestCreditBoxConfig:
    """Verify config loads correctly from bundled JSON."""

    def test_thresholds_loaded(self):
        assert MAX_AS_IS_LTV == 0.75
        assert MAX_STABILIZED_LTV == 0.75
        assert MAX_LTC == 0.80
        assert MIN_DEBT_YIELD == 0.07
        assert MIN_DSCR == 1.05
        assert MAX_LOAN_AMOUNT == 100_000_000


# ═══════════════════════════════════════════════════════════════════════════
# Constraint Waterfall Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestConstraintWaterfall:
    """Deterministic waterfall math — no API keys needed."""

    def test_all_pass_standard_deal(self):
        """Standard deal that passes all constraints."""
        result = run_constraint_waterfall(
            loan_amount=15_000_000,
            as_is_value=22_000_000,
            stabilized_value=23_760_000,  # 22M * 1.08
            total_cost=23_500_000,        # 22M + 100 units * 15K
            noi=1_247_400,                # 23.76M * 5.25%
            rate=0.075,                   # 7.50% all-in
            unit_count=100,
        )

        assert result["all_pass"] is True
        assert result["binding_constraint"] in result["constraints"]
        assert result["max_loan"] > 0
        assert result["max_loan_per_unit"] > 0

        # Check all 6 constraints present
        assert len(result["constraints"]) == 6
        for key in ["ltv_as_is", "ltv_stabilized", "dscr_stabilized",
                     "debt_yield", "ltc", "max_loan"]:
            assert key in result["constraints"]

    def test_ltv_binding(self):
        """When LTV is the binding constraint."""
        result = run_constraint_waterfall(
            loan_amount=17_000_000,
            as_is_value=20_000_000,  # LTV = 85% > 75%
            stabilized_value=25_000_000,
            total_cost=25_000_000,
            noi=2_000_000,
            rate=0.075,
            unit_count=100,
        )

        # Max from LTV As-Is = 20M * 0.75 = 15M
        assert result["constraints"]["ltv_as_is"]["max_loan"] == 15_000_000
        assert result["constraints"]["ltv_as_is"]["status"] == "fail"

    def test_dscr_binding(self):
        """When DSCR is the binding constraint."""
        result = run_constraint_waterfall(
            loan_amount=10_000_000,
            as_is_value=50_000_000,
            stabilized_value=55_000_000,
            total_cost=55_000_000,
            noi=800_000,  # Low NOI → DSCR binds
            rate=0.075,
            unit_count=100,
        )

        # Max from DSCR = 800K / 1.05 / 0.075 = ~10.16M
        dscr_max = result["constraints"]["dscr_stabilized"]["max_loan"]
        assert dscr_max == pytest.approx(800_000 / 1.05 / 0.075, abs=1)

        # DSCR should be binding (lowest max loan)
        assert result["binding_constraint"] == "dscr_stabilized"

    def test_debt_yield_binding(self):
        """When Debt Yield is the binding constraint."""
        result = run_constraint_waterfall(
            loan_amount=10_000_000,
            as_is_value=50_000_000,
            stabilized_value=55_000_000,
            total_cost=55_000_000,
            noi=600_000,  # Very low NOI
            rate=0.075,
            unit_count=100,
        )

        # Max from DY = 600K / 0.07 = ~8.57M
        dy_max = result["constraints"]["debt_yield"]["max_loan"]
        assert dy_max == pytest.approx(600_000 / 0.07, abs=1)

    def test_max_loan_cap(self):
        """Program cap enforced at $100M."""
        result = run_constraint_waterfall(
            loan_amount=110_000_000,
            as_is_value=200_000_000,
            stabilized_value=220_000_000,
            total_cost=220_000_000,
            noi=20_000_000,
            rate=0.075,
            unit_count=500,
        )

        assert result["constraints"]["max_loan"]["max_loan"] == 100_000_000
        assert result["constraints"]["max_loan"]["status"] == "fail"

    def test_ltc_constraint(self):
        """LTC constraint properly calculated."""
        result = run_constraint_waterfall(
            loan_amount=10_000_000,
            as_is_value=50_000_000,
            stabilized_value=55_000_000,
            total_cost=12_000_000,  # Low total cost → LTC binds
            noi=2_000_000,
            rate=0.075,
            unit_count=100,
        )

        # Max from LTC = 12M * 0.80 = 9.6M
        assert result["constraints"]["ltc"]["max_loan"] == 9_600_000

    def test_waterfall_takes_minimum(self):
        """The waterfall always takes the most restrictive constraint."""
        result = run_constraint_waterfall(
            loan_amount=15_000_000,
            as_is_value=22_000_000,
            stabilized_value=23_760_000,
            total_cost=23_500_000,
            noi=1_247_400,
            rate=0.075,
            unit_count=100,
        )

        max_loans = [c["max_loan"] for c in result["constraints"].values()]
        assert result["max_loan"] == min(max_loans)

    def test_metrics_included(self):
        """Result includes computed metrics."""
        result = run_constraint_waterfall(
            loan_amount=15_000_000,
            as_is_value=22_000_000,
            stabilized_value=23_760_000,
            total_cost=23_500_000,
            noi=1_247_400,
            rate=0.075,
            unit_count=100,
        )

        metrics = result["metrics"]
        assert "ltv_as_is" in metrics
        assert "dscr_stabilized" in metrics
        assert "debt_yield" in metrics
        assert "annual_debt_service" in metrics
        assert metrics["rate"] == 7.5

    def test_zero_values_handled(self):
        """Handles edge case of zero values gracefully."""
        result = run_constraint_waterfall(
            loan_amount=0,
            as_is_value=22_000_000,
            stabilized_value=23_760_000,
            total_cost=23_500_000,
            noi=1_247_400,
            rate=0.075,
            unit_count=100,
        )
        # Should not crash
        assert "constraints" in result


# ═══════════════════════════════════════════════════════════════════════════
# Prompt Builder Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestPromptBuilder:
    """Test skill loading and prompt construction."""

    def test_load_existing_skill(self):
        text = load_skill("sponsor-analysis")
        assert "Sponsor Analysis" in text
        assert len(text) > 100

    def test_load_missing_skill_returns_empty(self):
        text = load_skill("nonexistent-skill")
        assert text == ""

    def test_build_prompt_returns_tuple(self):
        system, user = build_analysis_prompt(
            skill_text="Test methodology",
            deal_data={"property": "123 Main St", "units": 100},
            task_description="Analyze this deal.",
        )
        assert isinstance(system, str)
        assert isinstance(user, str)
        assert "PinchFin" in system
        assert "123 Main St" in user
        assert "Analyze this deal" in user

    def test_build_prompt_with_external_data(self):
        system, user = build_analysis_prompt(
            skill_text="",
            deal_data={"loan": 15_000_000},
            external_data={"sofr": 4.33, "demographics": {"pop": 1000000}},
        )
        assert "EXTERNAL DATA" in user
        assert "sofr" in user

    def test_build_prompt_without_external_data(self):
        system, user = build_analysis_prompt(
            skill_text="",
            deal_data={"loan": 15_000_000},
        )
        assert "EXTERNAL DATA" not in user

    def test_load_all_bundled_skills(self):
        """All bundled skills load successfully."""
        core_skills = ["sponsor-analysis", "market-submarket", "comp-analysis", "loan-sizing"]
        tier3_skills = [
            "rent-roll-analysis", "cash-flow-modeling", "nuance-gate-analysis",
            "credit-memo", "returns-analysis", "risk-rating",
            "construction-budget-review", "cre-calculations",
            "expense-underwriting", "quick-review", "institutional-formatting",
        ]
        for name in core_skills:
            text = load_skill(name)
            assert len(text) > 50, f"Skill {name} is empty or too short"
        # Tier 3 skills — check if bundled (may not all be present yet)
        bundled_count = 0
        for name in tier3_skills:
            text = load_skill(name)
            if text:
                bundled_count += 1
        # At minimum, the core 4 must be present
        assert bundled_count >= 0  # Informational — no hard fail on tier3 skills


# ═══════════════════════════════════════════════════════════════════════════
# Analysis Availability Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestAnalysisAvailability:
    def test_no_key_means_unavailable(self):
        # Remove key if set
        old = os.environ.pop("ANTHROPIC_API_KEY", None)
        old2 = os.environ.pop("PINCHFIN_ANTHROPIC_API_KEY", None)
        try:
            assert is_analysis_available() is False
        finally:
            if old:
                os.environ["ANTHROPIC_API_KEY"] = old
            if old2:
                os.environ["PINCHFIN_ANTHROPIC_API_KEY"] = old2

    def test_key_set_means_available(self):
        os.environ["ANTHROPIC_API_KEY"] = "sk-ant-test-key"
        try:
            assert is_analysis_available() is True
        finally:
            del os.environ["ANTHROPIC_API_KEY"]


# ═══════════════════════════════════════════════════════════════════════════
# Tier 3 Module Tests (import and structure validation — no API keys needed)
# ═══════════════════════════════════════════════════════════════════════════

class TestTier3Imports:
    """Verify tier3 module imports cleanly and exposes expected functions."""

    def test_tier3_imports(self):
        from api.analysis.tier3 import (
            analyze_rent_roll,
            analyze_cash_flow,
            analyze_nuance_gate,
            analyze_ic_memo,
            analyze_term_sheet_comparator,
            analyze_business_plan,
            analyze_renovation_roi,
            analyze_quick_review,
        )
        # All should be async callables
        import asyncio
        assert asyncio.iscoroutinefunction(analyze_rent_roll)
        assert asyncio.iscoroutinefunction(analyze_cash_flow)
        assert asyncio.iscoroutinefunction(analyze_nuance_gate)
        assert asyncio.iscoroutinefunction(analyze_ic_memo)
        assert asyncio.iscoroutinefunction(analyze_term_sheet_comparator)
        assert asyncio.iscoroutinefunction(analyze_business_plan)
        assert asyncio.iscoroutinefunction(analyze_renovation_roi)
        assert asyncio.iscoroutinefunction(analyze_quick_review)

    def test_tier3_function_count(self):
        """Tier 3 exposes exactly 8 analysis functions."""
        from api.analysis import tier3
        funcs = [
            name for name in dir(tier3)
            if name.startswith("analyze_") and callable(getattr(tier3, name))
        ]
        assert len(funcs) == 8, f"Expected 8 analyze_ functions, got {len(funcs)}: {funcs}"

    def test_parse_claude_json_valid(self):
        from api.analysis.tier3 import _parse_claude_json
        result = _parse_claude_json('{"key": "value"}')
        assert result == {"key": "value"}

    def test_parse_claude_json_with_fences(self):
        from api.analysis.tier3 import _parse_claude_json
        result = _parse_claude_json('```json\n{"key": "value"}\n```')
        assert result == {"key": "value"}

    def test_parse_claude_json_invalid(self):
        from api.analysis.tier3 import _parse_claude_json
        result = _parse_claude_json("This is not JSON")
        assert result is None

    def test_modules_lazy_import(self):
        """The _get_tier3 function in modules.py returns 8 callables."""
        from api.routes.modules import _get_tier3
        fns = _get_tier3()
        assert len(fns) == 8
        for fn in fns:
            assert callable(fn)


# ═══════════════════════════════════════════════════════════════════════════
# Integration Tests (require API keys — skipped in CI)
# ═══════════════════════════════════════════════════════════════════════════

@pytest.mark.integration
class TestIntegrationSmoke:
    """
    Smoke tests that call real APIs. Run with:
        ANTHROPIC_API_KEY=sk-ant-... pytest tests/test_analysis.py -v -k integration
    """

    @pytest.fixture(autouse=True)
    def skip_without_key(self):
        if not os.environ.get("ANTHROPIC_API_KEY"):
            pytest.skip("ANTHROPIC_API_KEY not set — skipping integration test")

    @pytest.mark.asyncio
    async def test_deal_screen_real(self):
        from api.analysis.tier1 import analyze_deal_screen
        from pydantic import BaseModel, Field
        from typing import Optional

        class FakeReq:
            property_address = "123 Main St, Phoenix, AZ 85001"
            unit_count = 100
            loan_amount = 15_000_000
            purchase_price = 22_000_000
            asset_value = None
            loan_purpose = "bridge"
            sponsor_name = "Test Sponsor LLC"
            notes = None

        result = await analyze_deal_screen(FakeReq())

        assert "status" in result
        assert result["analysis_mode"] == "real"
        assert "credit_box" in result
        assert "summary" in result
        assert len(result["summary"]) > 20  # Real narrative, not empty

    @pytest.mark.asyncio
    async def test_quick_review_real(self):
        from api.analysis.tier3 import analyze_quick_review

        class FakeReq:
            property_address = "456 Oak Ave, Dallas, TX 75201"
            unit_count = 200
            loan_amount = 30_000_000
            purchase_price = 42_000_000
            asset_value = None
            loan_purpose = "bridge"
            sponsor_name = "Test Sponsor Group"
            notes = None
            current_noi = None
            pro_forma_rents = None
            is_rerun = False

        result = await analyze_quick_review(FakeReq())

        assert "analysis_mode" in result
        assert result["analysis_mode"] == "real"
        assert "screen_result" in result or "sizing" in result or "property" in result

    @pytest.mark.asyncio
    async def test_claude_call_direct(self):
        from api.analysis.clients import call_claude

        text = await call_claude(
            system="You are a test assistant.",
            user="Say 'hello' and nothing else.",
            max_tokens=50,
        )
        assert "hello" in text.lower()
