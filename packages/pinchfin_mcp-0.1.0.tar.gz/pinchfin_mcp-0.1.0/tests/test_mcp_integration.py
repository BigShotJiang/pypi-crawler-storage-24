"""
MCP Integration Tests
======================
Tests that start the FastAPI backend (via httpx ASGITransport) and exercise
the MCP server's tool functions by calling them through the live API.

This validates the full stack: MCP tool -> httpx -> FastAPI -> billing/state -> response.

(c) Veleta Capital LLC. All rights reserved.
"""

import sys
import os
import json

# Ensure project root is on sys.path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
import pytest_asyncio

# Skip entire module if mcp package is not available (e.g. CI environment)
try:
    import mcp  # noqa: F401
except ImportError:
    pytest.skip("mcp package not installed — skipping MCP integration tests", allow_module_level=True)
import httpx
from httpx import ASGITransport

from api.main import app
from src.billing import estimate_cost, CostEstimateRequest, ModuleType

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DEMO_KEY = "pf_dev_demo_key_000"
BASE_URL = "http://testserver/v1"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest.fixture
def auth_headers():
    """Standard auth headers for the demo account."""
    return {"Authorization": f"Bearer {DEMO_KEY}"}


@pytest_asyncio.fixture
async def api_client():
    """
    Async httpx client wired to the FastAPI app via ASGITransport.
    This starts the full ASGI app (including lifespan) without needing
    a real TCP server.
    """
    transport = ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url=BASE_URL) as client:
        yield client


# ===========================================================================
# TEST 1: Tool Registration — confirm all 21 MCP tools exist
# ===========================================================================

class TestToolRegistration:
    """Verify the MCP server has all 23 tools registered (16 billable + 7 free)."""

    EXPECTED_TOOLS = [
        # Billing & Account (free)
        "pinchfin_estimate_cost",
        "pinchfin_account",
        "pinchfin_deposit",
        # Core Analysis (billable)
        "pinchfin_deal_screen",
        "pinchfin_deal_book",
        "pinchfin_sponsor_analysis",
        "pinchfin_market_research",
        "pinchfin_comp_analysis",
        "pinchfin_rent_roll_analyzer",
        "pinchfin_cash_flow",
        "pinchfin_loan_sizer",
        "pinchfin_nuance_gate",
        "pinchfin_ic_memo",
        # Beta additions (billable)
        "pinchfin_term_sheet_comparator",
        "pinchfin_loan_pricing",
        "pinchfin_business_plan_analysis",
        "pinchfin_debt_sizing_preview",
        "pinchfin_renovation_roi",
        "pinchfin_pref_equity_qr",
        # Deal management (free)
        "pinchfin_deal_status",
        "pinchfin_list_deals",
        "pinchfin_upload_docs",
        "pinchfin_quick_review",
        "pinchfin_help",
    ]

    def test_tool_count(self):
        """MCP server should have exactly 23 tools."""
        from src.server import mcp
        tools = mcp._tool_manager._tools
        assert len(tools) == 24, (
            f"Expected 24 tools, found {len(tools)}. "
            f"Registered: {sorted(tools.keys())}"
        )

    def test_all_tools_present(self):
        """Every expected tool name must be registered."""
        from src.server import mcp
        registered = set(mcp._tool_manager._tools.keys())
        expected = set(self.EXPECTED_TOOLS)
        missing = expected - registered
        extra = registered - expected
        assert not missing, f"Missing tools: {missing}"
        assert not extra, f"Unexpected tools: {extra}"

    def test_tools_have_descriptions(self):
        """Every tool should have a non-empty description."""
        from src.server import mcp
        for name, tool in mcp._tool_manager._tools.items():
            assert tool.description, f"Tool {name} has no description"


# ===========================================================================
# TEST 2: Estimate Flow — call estimate and verify cost response
# ===========================================================================

class TestEstimateFlow:
    """Test cost estimation through the API (same path MCP tools use)."""

    @pytest.mark.asyncio
    async def test_estimate_deal_screen(self, api_client, auth_headers):
        """Estimate cost for a deal_screen module."""
        resp = await api_client.post(
            "/billing/estimate",
            headers=auth_headers,
            json={"modules": ["deal_screen"], "unit_count": 100},
        )
        assert resp.status_code == 200
        data = resp.json()

        # Verify structure
        assert "estimate" in data
        est = data["estimate"]
        assert "estimate_id" in est
        assert est["estimate_id"].startswith("est_")
        assert "estimated_cost" in est
        assert est["estimated_cost"]["low"] > 0
        assert est["estimated_cost"]["high"] >= est["estimated_cost"]["low"]
        assert est["estimated_cost"]["currency"] == "USD"

        # Verify account info included
        assert "account" in data
        assert data["account"]["available_balance"] >= 0
        assert "sufficient_funds" in data["account"]

    @pytest.mark.asyncio
    async def test_estimate_full_workflow(self, api_client, auth_headers):
        """Estimate cost for the full workflow module."""
        resp = await api_client.post(
            "/billing/estimate",
            headers=auth_headers,
            json={
                "modules": ["full_workflow"],
                "unit_count": 200,
                "document_count": 10,
                "document_pages": 150,
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        est = data["estimate"]

        # Full workflow should be more expensive than a single module
        assert est["estimated_cost"]["low"] >= 5.0
        assert "hold_amount" in est
        assert est["hold_amount"] > est["estimated_cost"]["high"]

    @pytest.mark.asyncio
    async def test_estimate_rerun_discount(self, api_client, auth_headers):
        """Re-run estimates should be ~35% cheaper."""
        # Normal run
        resp_normal = await api_client.post(
            "/billing/estimate",
            headers=auth_headers,
            json={"modules": ["deal_screen"], "unit_count": 100},
        )
        normal_high = resp_normal.json()["estimate"]["estimated_cost"]["high"]

        # Re-run
        resp_rerun = await api_client.post(
            "/billing/estimate",
            headers=auth_headers,
            json={"modules": ["deal_screen"], "unit_count": 100, "is_rerun": True},
        )
        rerun_high = resp_rerun.json()["estimate"]["estimated_cost"]["high"]

        # Re-run should be cheaper (0.65x multiplier)
        assert rerun_high < normal_high
        ratio = rerun_high / normal_high
        assert 0.60 <= ratio <= 0.70, f"Re-run ratio {ratio:.2f} not in expected range"

    def test_estimate_billing_engine_directly(self):
        """Test the billing engine's estimate_cost() function directly."""
        req = CostEstimateRequest(
            modules=[ModuleType.DEAL_SCREEN],
            unit_count=100,
        )
        est = estimate_cost(req)
        assert est.low > 0
        assert est.high >= est.low
        assert est.hold_amount > est.high
        assert "deal_screen" in est.modules
        assert "deal_screen" in est.breakdown


# ===========================================================================
# TEST 3: Deal Screen Flow — submit a deal and get a response
# ===========================================================================

class TestDealScreenFlow:
    """Test the deal screening pipeline through the API."""

    @pytest.mark.asyncio
    async def test_deal_screen_returns_results(self, api_client, auth_headers):
        """Submit a deal screen and verify response structure."""
        resp = await api_client.post(
            "/screen",
            headers=auth_headers,
            json={
                "property_address": "456 Integration Test Blvd, Los Angeles, CA 90012",
                "unit_count": 150,
                "loan_amount": 25000000,
                "purchase_price": 35000000,
                "sponsor_name": "Integration Test Sponsor",
                "loan_purpose": "bridge",
            },
        )
        assert resp.status_code == 200
        data = resp.json()

        # Must have a deal_id assigned
        assert "deal_id" in data
        assert data["deal_id"].startswith("PF-")

        # Must have results
        assert "results" in data

        # Must have cost info (settled)
        assert "cost" in data
        cost = data["cost"]
        assert "actual" in cost
        assert cost["actual"] > 0
        assert "remaining_balance" in cost

    @pytest.mark.asyncio
    async def test_deal_screen_creates_deal_record(self, api_client, auth_headers):
        """After screening, the deal should appear in list_deals."""
        # Screen a deal
        screen_resp = await api_client.post(
            "/screen",
            headers=auth_headers,
            json={
                "property_address": "789 Record Test Ave, Phoenix, AZ 85001",
                "unit_count": 80,
                "loan_amount": 12000000,
                "sponsor_name": "Record Test Sponsor",
            },
        )
        deal_id = screen_resp.json()["deal_id"]

        # Verify it appears in deal list
        list_resp = await api_client.get("/deals/list", headers=auth_headers)
        assert list_resp.status_code == 200
        deals = list_resp.json()["deals"]
        deal_ids = [d["deal_id"] for d in deals]
        assert deal_id in deal_ids

    @pytest.mark.asyncio
    async def test_deal_screen_no_auth_fails(self, api_client):
        """Deal screen without auth should return 401 or 403."""
        resp = await api_client.post(
            "/screen",
            json={
                "property_address": "123 No Auth St, Nowhere, TX 00000",
                "unit_count": 50,
                "loan_amount": 5000000,
            },
        )
        assert resp.status_code in [401, 403]


# ===========================================================================
# TEST 4: Balance Check — verify wallet balance
# ===========================================================================

class TestBalanceCheck:
    """Test account/balance operations through the API."""

    @pytest.mark.asyncio
    async def test_initial_balance(self, api_client, auth_headers):
        """Demo account starts with $10 free credit."""
        resp = await api_client.get("/billing/account", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()

        assert "account" in data
        acct = data["account"]
        assert acct["currency"] == "USD"
        # Balance should be positive (started at $10, may have spent some)
        assert acct["balance"] >= 0

    @pytest.mark.asyncio
    async def test_transactions_included(self, api_client, auth_headers):
        """Account info should include recent transactions."""
        resp = await api_client.get(
            "/billing/account",
            headers=auth_headers,
            params={"include_transactions": True, "transaction_limit": 5},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "recent_transactions" in data
        # At minimum, the free_credit transaction from account seeding
        assert len(data["recent_transactions"]) >= 1
        # Verify transactions have expected structure
        txn = data["recent_transactions"][0]
        assert "type" in txn
        assert "amount" in txn

    @pytest.mark.asyncio
    async def test_balance_decreases_after_analysis(self, api_client, auth_headers):
        """Running an analysis should reduce the account balance."""
        # Get initial balance
        before = (await api_client.get("/billing/account", headers=auth_headers)).json()
        balance_before = before["account"]["balance"]

        # Run a deal screen (cheapest module)
        await api_client.post(
            "/screen",
            headers=auth_headers,
            json={
                "property_address": "100 Balance Test Ln, Denver, CO 80202",
                "unit_count": 50,
                "loan_amount": 8000000,
                "sponsor_name": "Balance Test Sponsor",
            },
        )

        # Check balance after
        after = (await api_client.get("/billing/account", headers=auth_headers)).json()
        balance_after = after["account"]["balance"]

        assert balance_after < balance_before, (
            f"Balance should decrease after analysis: "
            f"before={balance_before}, after={balance_after}"
        )

    @pytest.mark.asyncio
    async def test_no_auth_returns_401(self, api_client):
        """Account endpoint without auth should return 401 or 403."""
        resp = await api_client.get("/billing/account")
        assert resp.status_code in [401, 403]


# ===========================================================================
# TEST 5: Module Endpoints — verify other analysis modules work
# ===========================================================================

class TestModuleEndpoints:
    """Verify individual analysis module endpoints return valid responses."""

    @pytest.mark.asyncio
    async def test_sponsor_analysis(self, api_client, auth_headers):
        resp = await api_client.post(
            "/modules/sponsor-analysis",
            headers=auth_headers,
            json={"sponsor_name": "Integration Sponsor LLC"},
        )
        # 200 if balance remains, 402 if prior tests exhausted demo credit
        assert resp.status_code in [200, 402]
        if resp.status_code == 200:
            data = resp.json()
            assert "deal_id" in data
            assert "cost" in data

    @pytest.mark.asyncio
    async def test_market_research(self, api_client, auth_headers):
        resp = await api_client.post(
            "/modules/market-research",
            headers=auth_headers,
            json={"property_address": "500 Market Test Dr, Austin, TX 78701"},
        )
        # 200 if balance remains, 402 if prior tests exhausted demo credit
        assert resp.status_code in [200, 402]
        if resp.status_code == 200:
            data = resp.json()
            assert "deal_id" in data

    @pytest.mark.asyncio
    async def test_deal_status_for_nonexistent_deal(self, api_client, auth_headers):
        """Checking status for a non-existent deal should return an error or empty."""
        resp = await api_client.get(
            "/deals/status",
            headers=auth_headers,
            params={"deal_id": "PF-9999-999"},
        )
        # Should handle gracefully (200 with error info, or 404)
        assert resp.status_code in [200, 404]

    @pytest.mark.asyncio
    async def test_list_deals_pagination(self, api_client, auth_headers):
        """List deals with pagination params."""
        resp = await api_client.get(
            "/deals/list",
            headers=auth_headers,
            params={"status": "active", "limit": 5, "offset": 0},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "deals" in data
        assert isinstance(data["deals"], list)


# ===========================================================================
# TEST 6: MCP Help Tool (no API call, pure server-side)
# ===========================================================================

class TestMCPHelpTool:
    """Test the help tool which runs entirely server-side."""

    @pytest.mark.asyncio
    async def test_help_returns_tool_list(self):
        """pinchfin_help should return JSON with all tool categories."""
        from src.server import pinchfin_help

        # The help tool takes a Context, but it never uses it (no API call).
        # We can pass None for this test since it doesn't touch ctx.
        result = await pinchfin_help(ctx=None)
        data = json.loads(result)

        assert "tools" in data
        assert "billable" in data["tools"]
        assert "free" in data["tools"]
        assert len(data["tools"]["billable"]) == 17
        assert len(data["tools"]["free"]) == 7
        assert "cost_factors" in data
        assert "tips" in data

    @pytest.mark.asyncio
    async def test_help_includes_pricing(self):
        """Every billable tool should have a cost field."""
        from src.server import pinchfin_help

        result = await pinchfin_help(ctx=None)
        data = json.loads(result)

        for tool in data["tools"]["billable"]:
            assert "cost" in tool, f"Tool {tool['name']} missing cost field"
            assert "$" in tool["cost"], f"Tool {tool['name']} cost not in $ format"


# ===========================================================================
# TEST 7: End-to-End Flow — estimate then execute
# ===========================================================================

class TestEndToEndFlow:
    """Simulate the full MCP user flow: estimate -> confirm -> execute."""

    @pytest.mark.asyncio
    async def test_estimate_then_screen(self, api_client, auth_headers):
        """
        Simulate the two-step MCP flow:
        1. Call estimate to see cost
        2. Call screen to execute
        """
        # Step 1: Estimate
        est_resp = await api_client.post(
            "/billing/estimate",
            headers=auth_headers,
            json={"modules": ["deal_screen"], "unit_count": 120},
        )
        assert est_resp.status_code == 200
        est_data = est_resp.json()
        assert est_data["account"]["sufficient_funds"] is True

        # Step 2: Execute
        exec_resp = await api_client.post(
            "/screen",
            headers=auth_headers,
            json={
                "property_address": "999 E2E Test Blvd, Miami, FL 33101",
                "unit_count": 120,
                "loan_amount": 18000000,
                "purchase_price": 26000000,
                "sponsor_name": "E2E Test Sponsor",
            },
        )
        assert exec_resp.status_code == 200
        exec_data = exec_resp.json()

        # Verify the execution returned cost info
        assert exec_data["cost"]["actual"] > 0
        assert exec_data["cost"]["remaining_balance"] >= 0
