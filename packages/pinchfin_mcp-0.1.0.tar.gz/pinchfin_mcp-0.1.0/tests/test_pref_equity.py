"""
Tests for the Preferred Equity module — constraint waterfall, PIK accrual,
exit waterfall, sponsor impact, and full orchestrator.

All tests are deterministic (no API keys needed).
Validated against 2800 Telegraph deal numbers.

(c) Veleta Capital LLC. All rights reserved.
"""

import sys
sys.path.insert(0, '.')

import pytest

from api.analysis.pref_equity import (
    run_pref_constraint_waterfall,
    compute_pik_schedule,
    compute_exit_waterfall,
    compute_sponsor_impact,
    compute_pref_return_sensitivity,
    size_pref_equity,
    MAX_COMBINED_LTV_AS_IS,
    MAX_COMBINED_LTV_STAB,
    MAX_COMBINED_LTC,
    MIN_PREF_IRR,
    MIN_PREF_MOIC,
    SPONSOR_EQUITY_FLOOR,
    MAX_PREF_COMMON_RATIO,
    MAX_PREF_AMOUNT,
    PIK_ACCRUAL_FLAG,
)


# ═══════════════════════════════════════════════════════════════════════════
# Config Thresholds
# ═══════════════════════════════════════════════════════════════════════════

class TestPrefConfig:
    """Verify pref equity config loads correctly from bundled JSON."""

    def test_thresholds_loaded(self):
        assert MAX_COMBINED_LTV_AS_IS == 0.80
        assert MAX_COMBINED_LTV_STAB == 0.80
        assert MAX_COMBINED_LTC == 0.85
        assert MIN_PREF_IRR == 0.14
        assert MIN_PREF_MOIC == 1.40
        assert SPONSOR_EQUITY_FLOOR == 0.10
        assert MAX_PREF_COMMON_RATIO == 2.0
        assert MAX_PREF_AMOUNT == 25_000_000
        assert PIK_ACCRUAL_FLAG == 0.50


# ═══════════════════════════════════════════════════════════════════════════
# Pass 2 Constraint Waterfall Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestPrefConstraintWaterfall:
    """Pass 2 pref equity constraint waterfall — deterministic math."""

    # Standard test deal inputs
    SENIOR = 15_000_000
    AS_IS = 22_000_000
    STAB = 24_000_000
    COST = 23_000_000
    UNITS = 100

    def test_all_pass(self):
        """Standard deal with modest pref — all constraints pass."""
        pref = 2_000_000  # small pref, should pass everything
        result = run_pref_constraint_waterfall(
            senior_loan=self.SENIOR,
            pref_equity=pref,
            as_is_value=self.AS_IS,
            stabilized_value=self.STAB,
            total_cost=self.COST,
            unit_count=self.UNITS,
        )

        assert result["all_pass"] is True
        assert result["max_pref"] > 0
        assert result["binding_constraint"] in result["constraints"]
        assert result["equity_gap"] == self.COST - self.SENIOR
        assert result["common_equity"] == self.COST - self.SENIOR - pref

        # Verify combined metrics
        combined = self.SENIOR + pref
        expected_cltv_as_is = combined / self.AS_IS * 100
        assert abs(result["metrics"]["combined_ltv_as_is"] - expected_cltv_as_is) < 0.2

    def test_ltv_binding(self):
        """When Combined LTV is the binding constraint (high leverage)."""
        # Low as-is value forces combined LTV to bind
        result = run_pref_constraint_waterfall(
            senior_loan=self.SENIOR,
            pref_equity=5_000_000,
            as_is_value=22_000_000,
            stabilized_value=23_000_000,
            total_cost=30_000_000,
            unit_count=self.UNITS,
        )
        # Combined = 20M. As-is: 20/22 = 90.9% > 80%. Should fail.
        assert result["constraints"]["combined_ltv_as_is"]["status"] == "fail"

    def test_ltc_binding(self):
        """When Combined LTC is the binding constraint."""
        # Large cost basis vs values
        result = run_pref_constraint_waterfall(
            senior_loan=self.SENIOR,
            pref_equity=3_000_000,
            as_is_value=30_000_000,   # plenty of value headroom
            stabilized_value=35_000_000,
            total_cost=20_000_000,    # tight cost basis
            unit_count=self.UNITS,
        )
        # Combined = 18M, LTC = 18/20 = 90% > 85%. Should fail.
        assert result["constraints"]["combined_ltc"]["status"] == "fail"

    def test_sponsor_floor_binding(self):
        """When sponsor equity floor (10%) is the binding constraint."""
        cost = 20_000_000
        senior = 12_000_000
        equity_gap = cost - senior  # 8M
        # If pref = 7.5M, common = 0.5M → 0.5/20 = 2.5% < 10%
        result = run_pref_constraint_waterfall(
            senior_loan=senior,
            pref_equity=7_500_000,
            as_is_value=30_000_000,
            stabilized_value=30_000_000,
            total_cost=cost,
            unit_count=self.UNITS,
        )
        assert result["constraints"]["sponsor_equity_floor"]["status"] == "fail"
        assert result["constraints"]["sponsor_equity_floor"]["value"] < 10.0

    def test_pref_common_ratio_binding(self):
        """When pref:common ratio (≤2.0x) is the binding constraint."""
        cost = 20_000_000
        senior = 10_000_000
        equity_gap = cost - senior  # 10M
        # If pref = 8M, common = 2M → ratio = 4.0x > 2.0x
        result = run_pref_constraint_waterfall(
            senior_loan=senior,
            pref_equity=8_000_000,
            as_is_value=40_000_000,
            stabilized_value=40_000_000,
            total_cost=cost,
            unit_count=self.UNITS,
        )
        assert result["constraints"]["pref_common_ratio"]["status"] == "fail"
        assert result["constraints"]["pref_common_ratio"]["value"] > 2.0

    def test_construction_deal_as_is_analytical(self):
        """Construction deal: as-is LTV is analytical, not binding."""
        # as_is < senior → construction detected
        result = run_pref_constraint_waterfall(
            senior_loan=15_000_000,
            pref_equity=2_000_000,
            as_is_value=5_000_000,   # land value only
            stabilized_value=30_000_000,
            total_cost=25_000_000,
            unit_count=self.UNITS,
            construction_deal=True,
        )
        assert result["constraints"]["combined_ltv_as_is"]["status"] == "analytical"
        # Binding should be from another constraint, not as-is LTV
        assert result["binding_constraint"] != "combined_ltv_as_is"

    def test_max_pref_per_constraint(self):
        """Verify max_pref calculation for each constraint."""
        result = run_pref_constraint_waterfall(
            senior_loan=self.SENIOR,
            pref_equity=2_000_000,
            as_is_value=self.AS_IS,
            stabilized_value=self.STAB,
            total_cost=self.COST,
            unit_count=self.UNITS,
        )
        # Max pref from LTV As-Is: 22M * 0.80 - 15M = 2.6M
        expected_max_cltv = self.AS_IS * 0.80 - self.SENIOR
        assert abs(result["constraints"]["combined_ltv_as_is"]["max_pref"] - expected_max_cltv) < 1

        # Max pref from LTC: 23M * 0.85 - 15M = 4.55M
        expected_max_ltc = self.COST * 0.85 - self.SENIOR
        assert abs(result["constraints"]["combined_ltc"]["max_pref"] - expected_max_ltc) < 1


# ═══════════════════════════════════════════════════════════════════════════
# PIK Accrual Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestPIKAccrual:
    """Quarterly compounding PIK accrual model."""

    def test_quarterly_compounding_accuracy(self):
        """Verify quarterly PIK compounding matches hand-calc."""
        # 2M pref, 14% total, 7% current, 7% PIK
        # 8 construction quarters + 3 lease-up + exit at Q12 (36 months)
        result = compute_pik_schedule(
            pref_amount=2_000_000,
            total_return_rate=0.14,
            current_pay_rate=0.07,
            construction_quarters=8,
            leaseup_quarters=3,
            exit_quarter=12,
            cfads_annual=0,  # no CFADS for simplicity
        )

        schedule = result["schedule"]
        summary = result["summary"]

        # Verify basic structure
        assert len(schedule) == 12
        assert summary["compounding"] == "quarterly"
        assert summary["original_pref"] == 2_000_000
        assert summary["months_full_pik"] == 33  # (8+3)*3

        # Q1: full PIK. Return = 2M * 0.14/4 = 70,000
        q1 = schedule[0]
        assert q1["phase"] == "Construction"
        assert abs(q1["return_due"] - 70_000) < 1
        assert abs(q1["current_paid"]) < 1  # zero during construction
        assert abs(q1["pik_accrual"] - 70_000) < 1

        # Balance at end of Q1 should be 2,070,000
        assert abs(q1["balance_end"] - 2_070_000) < 1

        # Q2: compounds on 2,070,000
        q2 = schedule[1]
        expected_q2_return = 2_070_000 * 0.14 / 4
        assert abs(q2["return_due"] - expected_q2_return) < 1

        # Final balance should be > original due to compounding
        assert summary["pref_balance_at_exit"] > 2_000_000
        assert summary["total_pik_at_exit"] > 0

    def test_pik_50_pct_flag_trigger(self):
        """PIK accrual exceeding 50% of original triggers flag."""
        # Long hold with full PIK — should trigger flag
        result = compute_pik_schedule(
            pref_amount=1_000_000,
            total_return_rate=0.16,
            current_pay_rate=0.06,
            construction_quarters=8,
            leaseup_quarters=4,
            exit_quarter=16,  # 48 months — long hold
            cfads_annual=0,
        )
        # At 16% total return, 48 months, full PIK → accrual should exceed 50%
        assert result["summary"]["accrual_flag"] is True
        assert result["summary"]["accrual_pct_of_original"] > 0.50
        assert "exceeds 50%" in result["summary"]["accrual_flag_note"]

    def test_pik_below_50_pct_no_flag(self):
        """Short hold with moderate PIK stays below 50% flag."""
        result = compute_pik_schedule(
            pref_amount=2_000_000,
            total_return_rate=0.14,
            current_pay_rate=0.07,
            construction_quarters=0,
            leaseup_quarters=2,
            exit_quarter=4,  # 12 months
            cfads_annual=200_000,
        )
        assert result["summary"]["accrual_flag"] is False
        assert result["summary"]["accrual_pct_of_original"] < 0.50
        assert "below 50%" in result["summary"]["accrual_flag_note"]

    def test_current_pay_commences_at_stabilization(self):
        """Current pay starts after construction + lease-up."""
        result = compute_pik_schedule(
            pref_amount=2_000_000,
            total_return_rate=0.14,
            current_pay_rate=0.07,
            construction_quarters=4,
            leaseup_quarters=2,
            exit_quarter=12,
            cfads_annual=500_000,
        )
        schedule = result["schedule"]

        # Quarters 1-4: construction → zero current pay
        for q in range(4):
            assert schedule[q]["phase"] == "Construction"
            assert schedule[q]["current_paid"] == 0

        # Quarters 5-6: lease-up → zero current pay
        for q in range(4, 6):
            assert schedule[q]["phase"] == "Lease-Up"
            assert schedule[q]["current_paid"] == 0

        # Quarter 7+: stabilized → current pay commences
        assert schedule[6]["phase"] == "Stabilized"
        assert schedule[6]["current_paid"] > 0


# ═══════════════════════════════════════════════════════════════════════════
# Exit Waterfall Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestExitWaterfall:
    """5-scenario exit waterfall with priority: Senior → Pref → Common."""

    def _make_pik_result(self, pref_amount=2_000_000, pik_total=500_000, current_total=100_000):
        """Helper to build a minimal PIK schedule result."""
        return {
            "summary": {
                "pref_balance_at_exit": pref_amount + pik_total,
                "total_current_paid": current_total,
            },
            "schedule": [],
        }

    def test_five_scenarios_present(self):
        """Exit waterfall always produces exactly 5 scenarios."""
        pik_result = self._make_pik_result()
        result = compute_exit_waterfall(
            noi_stabilized=1_500_000,
            exit_cap_rate=0.05,
            senior_loan=15_000_000,
            pref_amount=2_000_000,
            pik_schedule_result=pik_result,
            hold_months=36,
        )
        assert len(result["scenarios"]) == 5
        labels = [s["scenario"] for s in result["scenarios"]]
        assert "Base" in labels
        assert "+10% Value" in labels
        assert "-10% Value" in labels
        assert "-20% Value" in labels
        assert "Breakeven" in labels

    def test_base_case_exit_value(self):
        """Base exit value = NOI / cap rate."""
        noi = 1_500_000
        cap = 0.05
        pik_result = self._make_pik_result()
        result = compute_exit_waterfall(
            noi_stabilized=noi,
            exit_cap_rate=cap,
            senior_loan=15_000_000,
            pref_amount=2_000_000,
            pik_schedule_result=pik_result,
            hold_months=36,
        )
        expected = noi / cap  # 30M
        assert abs(result["base_exit_value"] - expected) < 1

    def test_senior_paid_first(self):
        """Senior is always fully paid before pref gets anything."""
        pik_result = self._make_pik_result(pref_amount=2_000_000, pik_total=500_000)
        result = compute_exit_waterfall(
            noi_stabilized=1_500_000,
            exit_cap_rate=0.05,
            senior_loan=15_000_000,
            pref_amount=2_000_000,
            pik_schedule_result=pik_result,
            hold_months=36,
        )
        for s in result["scenarios"]:
            # Senior gets full payoff (or all available if exit < senior)
            if s["exit_value"] >= 15_000_000:
                assert s["senior_payoff"] == 15_000_000
            else:
                assert s["senior_payoff"] == 15_000_000  # senior loan is always reported

    def test_breakeven_common_is_zero(self):
        """At breakeven exit, common equity is exactly $0."""
        pik_result = self._make_pik_result(pref_amount=2_000_000, pik_total=500_000)
        result = compute_exit_waterfall(
            noi_stabilized=1_500_000,
            exit_cap_rate=0.05,
            senior_loan=15_000_000,
            pref_amount=2_000_000,
            pik_schedule_result=pik_result,
            hold_months=36,
        )
        breakeven = [s for s in result["scenarios"] if s["scenario"] == "Breakeven"][0]
        assert breakeven["common_equity"] == 0

        # Breakeven value = senior + pref balance
        pref_bal = 2_500_000  # 2M + 500K PIK
        assert abs(breakeven["exit_value"] - (15_000_000 + pref_bal)) < 1

    def test_pref_shortfall_in_distress(self):
        """In deep distress, pref may not be fully repaid."""
        # Make exit value very low
        pik_result = self._make_pik_result(pref_amount=5_000_000, pik_total=2_000_000)
        result = compute_exit_waterfall(
            noi_stabilized=500_000,
            exit_cap_rate=0.05,     # Exit value = 10M
            senior_loan=12_000_000,  # Senior > exit value in -20% scenario
            pref_amount=5_000_000,
            pik_schedule_result=pik_result,
            hold_months=36,
        )
        # -20% scenario: exit = 10M * 0.80 = 8M < senior 12M
        minus20 = [s for s in result["scenarios"] if s["scenario"] == "-20% Value"][0]
        # Available after senior = max(0, 8M - 12M) = 0
        assert minus20["pref_redemption"] == 0
        assert minus20["pref_shortfall"] > 0


# ═══════════════════════════════════════════════════════════════════════════
# Sponsor Impact Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestSponsorImpact:
    """Sponsor with/without pref equity comparison."""

    def test_sponsor_impact_with_pref(self):
        """Pref equity reduces sponsor equity requirement."""
        result = compute_sponsor_impact(
            total_cost=25_000_000,
            senior_loan=15_000_000,
            pref_amount=5_000_000,
            common_equity=5_000_000,
            noi_stabilized=2_000_000,
            senior_ds=1_125_000,
            current_pay_annual=350_000,
            exit_value=30_000_000,
            pref_balance_at_exit=6_000_000,
            hold_months=36,
        )

        wo = result["without_pref"]
        wi = result["with_pref"]

        # Without pref: sponsor puts up full equity gap (10M)
        assert wo["sponsor_equity"] == 10_000_000
        # With pref: sponsor only puts up common (5M)
        assert wi["sponsor_equity"] == 5_000_000

        # Equity reduction = 5M
        assert result["equity_reduction"] == 5_000_000

        # Leverage effect should be calculated
        assert result["leverage_effect"] in ("positive", "negative")

    def test_sponsor_impact_without_pref(self):
        """Without pref, sponsor takes full equity position."""
        result = compute_sponsor_impact(
            total_cost=20_000_000,
            senior_loan=15_000_000,
            pref_amount=0,
            common_equity=5_000_000,
            noi_stabilized=1_500_000,
            senior_ds=1_125_000,
            current_pay_annual=0,
            exit_value=25_000_000,
            pref_balance_at_exit=0,
            hold_months=36,
        )
        wo = result["without_pref"]
        wi = result["with_pref"]

        # Both should be the same equity gap when pref=0
        assert wo["sponsor_equity"] == 5_000_000
        assert wi["sponsor_equity"] == 5_000_000


# ═══════════════════════════════════════════════════════════════════════════
# Construction Deal Auto-Detection Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestConstructionDealDetection:
    """Construction deal detection: as_is_value < senior_loan."""

    def test_construction_detected(self):
        """When as-is value < senior loan, construction is flagged."""
        result = size_pref_equity(
            senior_loan=15_000_000,
            senior_rate=0.075,
            as_is_value=5_000_000,   # land only — construction
            stabilized_value=30_000_000,
            total_cost=25_000_000,
            noi_stabilized=2_000_000,
            exit_cap_rate=0.0525,
            hold_months=36,
            current_pay_rate=0.07,
            pik_rate=0.07,
            construction_quarters=8,
            leaseup_quarters=3,
            unit_count=100,
        )
        # Should not fail on as-is LTV alone
        # Pass 1 will flag as-is LTV as analytical for construction
        p1 = result.get("pass_1_senior", {})
        if p1.get("construction_deal"):
            assert p1["constraints"]["ltv_as_is"].get("note") is not None

    def test_non_construction_not_flagged(self):
        """Normal deal (as-is > senior) is not construction."""
        result = size_pref_equity(
            senior_loan=15_000_000,
            senior_rate=0.075,
            as_is_value=22_000_000,
            stabilized_value=24_000_000,
            total_cost=23_000_000,
            noi_stabilized=1_750_000,
            exit_cap_rate=0.0525,
            hold_months=36,
            current_pay_rate=0.07,
            pik_rate=0.07,
            construction_quarters=0,
            leaseup_quarters=2,
            unit_count=100,
        )
        p1 = result.get("pass_1_senior", {})
        assert p1.get("construction_deal") is not True


# ═══════════════════════════════════════════════════════════════════════════
# Full Orchestrator Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestSizePrefEquity:
    """Full size_pref_equity() orchestrator — end-to-end."""

    def test_2800_telegraph_validation(self):
        """
        Validate against 2800 Telegraph hand-built QR numbers.
        Sized Pref: ~$2.47M, PIK at 36mo: ~$1.21M, Pref IRR: ~14.8%.

        Note: as-is value = $14M (land + entitled value) triggers construction
        auto-detection (as_is < senior_loan), which makes as-is LTV analytical.
        """
        result = size_pref_equity(
            senior_loan=16_500_000,
            senior_rate=0.075,
            as_is_value=14_000_000,     # land/entitled — triggers construction detection
            stabilized_value=26_000_000,
            total_cost=24_500_000,
            noi_stabilized=1_500_000,
            exit_cap_rate=0.0525,
            hold_months=36,
            current_pay_rate=0.07,
            pik_rate=0.07,
            pref_equity_requested=2_470_000,
            construction_quarters=8,
            leaseup_quarters=3,
            unit_count=165,
        )

        # Should not be a FAIL
        assert result["screen_result"] in ("CONDITIONAL", "PASS")
        assert result["deal_type"] == "preferred_equity"
        assert result["sized_pref_equity"] > 0

        # Pass 1 and Pass 2 present
        assert result["pass_1_senior"] is not None
        assert result["pass_2_pref"] is not None

        # PIK schedule populated
        assert result["pik_schedule"] is not None
        pik_sum = result["pik_schedule"]["summary"]
        assert pik_sum["compounding"] == "quarterly"
        assert pik_sum["pref_balance_at_exit"] > pik_sum["original_pref"]

        # Exit waterfall has 5 scenarios
        assert len(result["exit_waterfall"]["scenarios"]) == 5

        # Sponsor impact present
        assert result["sponsor_impact"] is not None
        assert result["sponsor_impact"]["leverage_effect"] in ("positive", "negative")

        # Pref return sensitivity populated
        assert len(result["pref_return_sensitivity"]) > 0

        # Capital stack sums correctly
        cs = result["capital_stack"]
        assert abs(cs["senior_loan"] + cs["pref_equity"] + cs["common_equity"] - cs["total"]) < 1

    def test_senior_fail_short_circuits(self):
        """If senior fails Pass 1, entire result is FAIL with no pref analysis."""
        result = size_pref_equity(
            senior_loan=90_000_000,     # way over LTV
            senior_rate=0.075,
            as_is_value=50_000_000,     # LTV = 180%
            stabilized_value=60_000_000,
            total_cost=70_000_000,
            noi_stabilized=3_000_000,
            exit_cap_rate=0.0525,
            hold_months=36,
            current_pay_rate=0.07,
            pik_rate=0.07,
            unit_count=100,
        )
        assert result["screen_result"] == "FAIL"
        assert "Pass 1" in result.get("fail_reason", "")
        assert result["pass_2_pref"] is None
        assert result["pik_schedule"] is None
        assert result["exit_waterfall"] is None

    def test_output_schema_shape(self):
        """Verify the full output has all expected top-level keys."""
        result = size_pref_equity(
            senior_loan=15_000_000,
            senior_rate=0.075,
            as_is_value=22_000_000,
            stabilized_value=24_000_000,
            total_cost=23_000_000,
            noi_stabilized=1_750_000,
            exit_cap_rate=0.0525,
            hold_months=36,
            current_pay_rate=0.07,
            pik_rate=0.07,
            unit_count=100,
        )
        expected_keys = {
            "screen_result", "deal_type", "sized_pref_equity", "max_pref_equity",
            "pass_1_senior", "pass_2_pref", "capital_stack", "pik_schedule",
            "exit_waterfall", "sponsor_impact", "pref_return_sensitivity",
            "pref_returns", "yield_metrics",
        }
        assert expected_keys.issubset(set(result.keys()))

    def test_pref_return_sensitivity_exit_months(self):
        """Pref return sensitivity has entries at default exit timings."""
        result = size_pref_equity(
            senior_loan=15_000_000,
            senior_rate=0.075,
            as_is_value=22_000_000,
            stabilized_value=24_000_000,
            total_cost=23_000_000,
            noi_stabilized=1_750_000,
            exit_cap_rate=0.0525,
            hold_months=36,
            current_pay_rate=0.07,
            pik_rate=0.07,
            unit_count=100,
        )
        sens = result["pref_return_sensitivity"]
        exit_months = [s["exit_month"] for s in sens]
        # Default quarters [4,8,10,12,14] → months [12,24,30,36,42]
        assert 12 in exit_months
        assert 24 in exit_months
        assert 36 in exit_months


# ═══════════════════════════════════════════════════════════════════════════
# Report Mapper Tests
# ═══════════════════════════════════════════════════════════════════════════

class TestPrefEquityReportMapper:
    """Verify the DOCX mapper produces output for pref equity QR."""

    def test_builder_registered(self):
        """pref_equity_qr is registered in REPORT_BUILDERS."""
        from api.analysis.report.mapper import REPORT_BUILDERS
        assert "pref_equity_qr" in REPORT_BUILDERS

    def test_builds_docx_bytes(self):
        """Builder produces non-empty bytes from a minimal data dict."""
        from api.analysis.report.mapper import build_pref_equity_qr_report

        # Run a real sizing to get valid data
        data = size_pref_equity(
            senior_loan=15_000_000,
            senior_rate=0.075,
            as_is_value=22_000_000,
            stabilized_value=24_000_000,
            total_cost=23_000_000,
            noi_stabilized=1_750_000,
            exit_cap_rate=0.0525,
            hold_months=36,
            current_pay_rate=0.07,
            pik_rate=0.07,
            unit_count=100,
        )

        result_bytes = build_pref_equity_qr_report(data, deal_name="Test Property")
        assert isinstance(result_bytes, bytes)
        assert len(result_bytes) > 1000  # should be a real DOCX

    def test_build_report_dispatch(self):
        """build_report() dispatches pref_equity_qr correctly."""
        from api.analysis.report.mapper import build_report

        data = size_pref_equity(
            senior_loan=15_000_000,
            senior_rate=0.075,
            as_is_value=22_000_000,
            stabilized_value=24_000_000,
            total_cost=23_000_000,
            noi_stabilized=1_750_000,
            exit_cap_rate=0.0525,
            hold_months=36,
            current_pay_rate=0.07,
            pik_rate=0.07,
            unit_count=100,
        )

        result_bytes = build_report("pref_equity_qr", data, deal_name="Test Property")
        assert result_bytes is not None
        assert len(result_bytes) > 1000
