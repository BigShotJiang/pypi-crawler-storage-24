import sys
sys.path.insert(0, '.')

import pytest
from src.billing import (
    estimate_cost, CostEstimateRequest, ModuleType,
    WalletManager, create_meter,
    MODULE_BASE_COSTS, FREE_CREDIT, MIN_DEPOSIT, HOLD_BUFFER
)


class TestCostEstimation:
    def test_single_module_estimate(self):
        req = CostEstimateRequest(modules=[ModuleType.DEAL_SCREEN], unit_count=100)
        est = estimate_cost(req)
        assert est.low > 0
        assert est.high >= est.low
        assert est.hold_amount == est.high * HOLD_BUFFER
        assert len(est.modules) == 1
        assert est.modules[0] == "deal_screen"

    def test_unit_multiplier_small(self):
        req_small = CostEstimateRequest(modules=[ModuleType.DEAL_SCREEN], unit_count=30)
        req_large = CostEstimateRequest(modules=[ModuleType.DEAL_SCREEN], unit_count=400)
        est_small = estimate_cost(req_small)
        est_large = estimate_cost(req_large)
        assert est_large.high > est_small.high  # larger deal costs more

    def test_rerun_discount(self):
        req_new = CostEstimateRequest(modules=[ModuleType.MARKET_RESEARCH], unit_count=100, is_rerun=False)
        req_rerun = CostEstimateRequest(modules=[ModuleType.MARKET_RESEARCH], unit_count=100, is_rerun=True)
        est_new = estimate_cost(req_new)
        est_rerun = estimate_cost(req_rerun)
        assert est_rerun.high < est_new.high  # rerun is cheaper

    def test_full_workflow_not_double_counted(self):
        req = CostEstimateRequest(modules=[ModuleType.FULL_WORKFLOW], unit_count=200)
        est = estimate_cost(req)
        base_low, base_high = MODULE_BASE_COSTS[ModuleType.FULL_WORKFLOW]
        # Should be based on full_workflow base, not sum of all modules
        assert est.low < 200  # sanity check — not absurdly high

    def test_estimate_has_id(self):
        req = CostEstimateRequest(modules=[ModuleType.DEAL_SCREEN])
        est = estimate_cost(req)
        assert est.estimate_id.startswith("est_")

    def test_to_dict(self):
        req = CostEstimateRequest(modules=[ModuleType.DEAL_SCREEN], unit_count=100)
        est = estimate_cost(req)
        d = est.to_dict()
        assert "estimate_id" in d
        assert "estimated_cost" in d
        assert d["estimated_cost"]["currency"] == "USD"


class TestWalletManager:
    @pytest.fixture
    def wallet(self):
        return WalletManager()

    @pytest.mark.asyncio
    async def test_create_account(self, wallet):
        acct = await wallet.create_account("test@test.com", "key123")
        assert acct.balance == FREE_CREDIT
        assert acct.id.startswith("acct_")

    @pytest.mark.asyncio
    async def test_deposit(self, wallet):
        acct = await wallet.create_account("test@test.com", "key123")
        txn = await wallet.deposit(acct, 50.0, "pi_test123")
        assert acct.balance == FREE_CREDIT + 50.0
        assert txn.type == "deposit"

    @pytest.mark.asyncio
    async def test_deposit_minimum(self, wallet):
        acct = await wallet.create_account("test@test.com", "key123")
        with pytest.raises(ValueError):
            await wallet.deposit(acct, 10.0, "pi_test")  # Below MIN_DEPOSIT

    @pytest.mark.asyncio
    async def test_hold_and_settle(self, wallet):
        acct = await wallet.create_account("test@test.com", "key123")
        req = CostEstimateRequest(modules=[ModuleType.DEAL_SCREEN], unit_count=100)
        est = estimate_cost(req)

        hold_id = await wallet.place_hold(acct, est, "PF-2026-001")
        assert hold_id is not None
        assert acct.held_amount > 0

        txn = await wallet.settle(acct, hold_id, 1.50, ["deal_screen"], "PF-2026-001")
        assert txn.type == "charge"
        assert acct.held_amount == 0
        assert acct.total_analyses == 1

    @pytest.mark.asyncio
    async def test_insufficient_funds(self, wallet):
        acct = await wallet.create_account("test@test.com", "key123")
        # Drain most of the balance first with a successful charge
        req = CostEstimateRequest(modules=[ModuleType.DEAL_SCREEN], unit_count=100)
        est = estimate_cost(req)
        hold_id = await wallet.place_hold(acct, est, "PF-2026-001")
        await wallet.settle(acct, hold_id, 48.00, ["deal_screen"], "PF-2026-001")
        # Now try to hold more than remaining ~$2 balance
        req2 = CostEstimateRequest(modules=[ModuleType.FULL_WORKFLOW], unit_count=500)
        est2 = estimate_cost(req2)
        hold_id2 = await wallet.place_hold(acct, est2, "PF-2026-002")
        assert hold_id2 is None  # Should fail — not enough funds

    @pytest.mark.asyncio
    async def test_settle_failed_releases_hold(self, wallet):
        acct = await wallet.create_account("test@test.com", "key123")
        await wallet.deposit(acct, 100.0, "pi_test")
        req = CostEstimateRequest(modules=[ModuleType.DEAL_SCREEN], unit_count=100)
        est = estimate_cost(req)

        hold_id = await wallet.place_hold(acct, est, "PF-2026-001")
        balance_before = acct.balance

        await wallet.settle_failed(acct, hold_id, "PF-2026-001", "Test failure")
        assert acct.held_amount == 0
        assert acct.balance == balance_before  # No charge


class TestUsageMeter:
    def test_create_meter(self):
        meter = create_meter("PF-2026-001", "acct_123", ["deal_screen"])
        assert meter.meter_id.startswith("mtr_")
        assert meter.total_cost == 0

    def test_record_usage(self):
        meter = create_meter("PF-2026-001", "acct_123", ["deal_screen"])
        meter.record_llm_usage(10000, 2000)
        assert meter.llm_input_tokens == 10000
        assert meter.llm_output_tokens == 2000
        assert meter.llm_cost > 0
        assert meter.total_cost > 0

    def test_finalize(self):
        meter = create_meter("PF-2026-001", "acct_123", ["deal_screen"])
        meter.record_llm_usage(5000, 1000)
        meter.record_rag_query(5)
        result = meter.finalize()
        assert result["completed_at"] is not None
        assert result["total_cost"] > 0
