import sys
sys.path.insert(0, '.')

import pytest
from fastapi.testclient import TestClient
from api.main import app

# The app auto-seeds a demo account with key pf_dev_demo_key_000


class TestHealthCheck:
    def test_health(self):
        with TestClient(app) as client:
            resp = client.get("/health")
            assert resp.status_code == 200
            assert resp.json()["status"] == "healthy"

    def test_root(self):
        with TestClient(app) as client:
            resp = client.get("/")
            assert resp.status_code == 200


class TestAuth:
    def test_no_auth_returns_401(self):
        with TestClient(app) as client:
            resp = client.get("/v1/billing/account")
            assert resp.status_code == 401

    def test_bad_key_returns_401(self):
        with TestClient(app) as client:
            resp = client.get("/v1/billing/account", headers={"Authorization": "Bearer bad_key"})
            assert resp.status_code == 401

    def test_valid_key_works(self):
        with TestClient(app) as client:
            resp = client.get("/v1/billing/account", headers={"Authorization": "Bearer pf_dev_demo_key_000"})
            assert resp.status_code == 200


class TestBilling:
    def _auth(self):
        return {"Authorization": "Bearer pf_dev_demo_key_000"}

    def test_account_info(self):
        with TestClient(app) as client:
            resp = client.get("/v1/billing/account", headers=self._auth())
            data = resp.json()
            assert "account" in data
            assert data["account"]["currency"] == "USD"
            assert data["account"]["balance"] >= 0

    def test_estimate_cost(self):
        with TestClient(app) as client:
            resp = client.post("/v1/billing/estimate", headers=self._auth(), json={
                "modules": ["deal_screen"],
                "unit_count": 100
            })
            assert resp.status_code == 200
            data = resp.json()
            assert "estimate" in data
            assert data["estimate"]["estimated_cost"]["low"] > 0

    def test_deposit_returns_url(self):
        # This will fail without Stripe keys, but should handle gracefully
        with TestClient(app) as client:
            resp = client.post("/v1/billing/deposit", headers=self._auth(), json={"amount": 50.0})
            # Without Stripe configured, should return error or mock URL
            assert resp.status_code in [200, 500, 503]


class TestModules:
    def _auth(self):
        return {"Authorization": "Bearer pf_dev_demo_key_000"}

    def test_deal_screen(self):
        with TestClient(app) as client:
            resp = client.post("/v1/screen", headers=self._auth(), json={
                "property_address": "123 Test St, Phoenix, AZ",
                "unit_count": 100,
                "loan_amount": 15000000,
                "purchase_price": 22000000,
                "sponsor_name": "Test Sponsor"
            })
            assert resp.status_code == 200
            data = resp.json()
            assert "deal_id" in data
            assert "results" in data
            assert "cost" in data

    def test_sponsor_analysis(self):
        with TestClient(app) as client:
            resp = client.post("/v1/modules/sponsor-analysis", headers=self._auth(), json={
                "sponsor_name": "Test Sponsor LLC"
            })
            assert resp.status_code == 200

    def test_market_research(self):
        with TestClient(app) as client:
            resp = client.post("/v1/modules/market-research", headers=self._auth(), json={
                "property_address": "123 Test St, Phoenix, AZ"
            })
            assert resp.status_code == 200


class TestDeals:
    def _auth(self):
        return {"Authorization": "Bearer pf_dev_demo_key_000"}

    def test_list_deals(self):
        with TestClient(app) as client:
            resp = client.get("/v1/deals/list", headers=self._auth())
            assert resp.status_code == 200
            data = resp.json()
            assert "deals" in data
