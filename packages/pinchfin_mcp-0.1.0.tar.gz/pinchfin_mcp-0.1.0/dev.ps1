# pinchfin local dev — runs both backend + MCP server (PowerShell)
# MCP config: .mcp.json (already in .gitignore)

$env:PINCHFIN_API_URL = "http://127.0.0.1:8420/v1"
$env:PINCHFIN_API_KEY = "pf_dev_demo_key_000"

# Start backend
$backend = Start-Process -FilePath python -ArgumentList "-m", "uvicorn", "api.main:app", "--host", "127.0.0.1", "--port", "8420" -PassThru -NoNewWindow
Start-Sleep -Seconds 2
Write-Host "Backend running on :8420 (PID $($backend.Id))"

try {
    python src/server.py
} finally {
    Stop-Process -Id $backend.Id -ErrorAction SilentlyContinue
}
