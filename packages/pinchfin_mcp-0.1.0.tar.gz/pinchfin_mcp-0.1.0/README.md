# pinchfin MCP

**AI-powered CRE credit intelligence in your terminal.**

pinchfin is a commercial real estate operating system built for lenders, brokers, and sponsors. It delivers institutional-grade underwriting, deal screening, market research, sponsor diligence, loan sizing, and credit analysis — all through Claude Code. The platform currently supports multifamily, mixed-use, and stabilized/transitional assets across the capital stack, with additional asset classes coming soon.

---

## Quick Start

```bash
pip install pinchfin-mcp
pinchfin login
# Open Claude Code — pinchfin tools are automatically available
```

New accounts receive **$10.00 in free credits** — enough for several quick screens and a module or two.

---

## Pricing

pinchfin uses **usage-based billing**. You load funds onto your account and pay actual usage per analysis. Every tool shows you a cost estimate before running — you always confirm before being charged.

| Tool | Typical Cost | What It Does |
|------|-------------|--------------|
| `pinchfin_deal_screen` | $0.10 – $0.50 | Quick pass/fail against credit parameters |
| `pinchfin_deal_book` | $0.75 – $3 | Document & transcript synthesis |
| `pinchfin_sponsor_analysis` | $0.50 – $2 | Sponsor due diligence & scoring |
| `pinchfin_market_research` | $0.50 – $1.50 | Market & submarket fundamentals |
| `pinchfin_comp_analysis` | $0.50 – $1.50 | Comparable sales, rents, financing |
| `pinchfin_rent_roll_analyzer` | $0.25 – $1 | Rent roll parsing & analysis |
| `pinchfin_cash_flow` | $0.50 – $1.50 | Cash flow underwriting & projections |
| `pinchfin_loan_sizer` | $0.25 – $1 | Loan sizing with constraint waterfall |
| `pinchfin_loan_pricing` | $0.25 – $1 | Rate build-up, rate cap, interest reserve, all-in cost |
| `pinchfin_term_sheet_comparator` | $0.50 – $1.50 | Side-by-side term sheet comparison |
| `pinchfin_business_plan_analysis` | $0.50 – $2 | Business plan feasibility assessment |
| `pinchfin_debt_sizing_preview` | $0.25 – $0.75 | Quick constraint waterfall sizing |
| `pinchfin_renovation_roi` | $0.50 – $2 | Rehab scope vs. rent premium analysis |
| `pinchfin_nuance_gate` | $0.50 – $2 | Complex deal feature research & operationalization |
| `pinchfin_ic_memo` | $1 – $3 | Investment Committee memo |
| `pinchfin_quick_review` | $2 – $6 | Bundled 10-phase mini-workflow (screen through audit log) |

**Cost varies based on:** property size, document volume and complexity, number of transcripts, market data density, and whether it's a re-run (~35% discount).

**Free tools:** `pinchfin_account`, `pinchfin_deposit`, `pinchfin_estimate_cost`, `pinchfin_deal_status`, `pinchfin_list_deals`, `pinchfin_upload_docs`, `pinchfin_help`

**Load funds:** Minimum $25 deposit via Stripe. Run `pinchfin deposit` or use `pinchfin_deposit` inside Claude Code.

### How Billing Works

```
You: "Screen this deal at 123 Main St, 180 units, $40M loan"

Claude → pinchfin: estimates cost
pinchfin → Claude: "Estimated cost: $0.15-$0.40. Your balance: $47.20. Proceed?"

You: "Yes"

Claude → pinchfin: executes screening
pinchfin → Claude: results + "Cost: $0.28 | Balance: $46.92"
```

You always see the estimate first. You always confirm. You only pay actual usage.

### Cost Planning

| Scenario | Typical Cost | What You Get |
|----------|-------------|--------------|
| Quick screen | ~$0.25 | Pass/fail with key metrics and flags |
| Quick review | ~$3 – $6 | Bundled 10-phase mini-workflow: screen, data pull, market, comps, rent roll, cash flow, narrative, memo, deal record, audit log |
| Individual module | ~$0.50 – $2 | Single focused analysis (sponsor, market, comps, etc.) |
| Full workflow | Coming post-beta | Complete multi-phase underwriting |

**Budget tip:** Start with a screen (~$0.25). If it passes, run a quick review ($3-6). Individual modules let you go deeper on specific areas.

---

## What You Get

### For Lenders

Screen inbound deals in seconds. Size loans against your credit parameters. Generate IC memos. Investigate nuance (ground leases, tax abatements, rent stabilization, affordable overlays) without slowing down the pipeline.

### For Brokers

Compare term sheets side by side. Run debt sizing previews for borrower conversations. Price loans with rate build-up and rate cap analysis. Screen deals before sending them out.

### For Sponsors

Evaluate business plan feasibility. Analyze renovation ROI by scope tier. Preview how much you can borrow before approaching lenders. Research markets and comps independently.

### Quick Review Workflow

The fastest path from "I just got a deal" to "here's my analysis" — a bundled 10-phase mini-workflow (QR-0 through QR-9):

1. **QR-0: Screen** → Pass/fail against credit parameters
2. **QR-1: Data Pull** → SOFR, Census, BLS, FEMA, Walk Score
3. **QR-2: Market Snapshot** → Quick submarket fundamentals
4. **QR-3: Quick Comps** → 3-5 rent comps, 2-3 sale comps
5. **QR-4: Rent Roll Scan** → Validation and anomaly flags
6. **QR-5: Mini Cash Flow** → As-Is + Stabilized NOI, constraint-based sizing
7. **QR-6: Narrative** → Strengths, risks, DD questions, needs list
8. **QR-7: One-Page Memo** → Professional DOCX output
9. **QR-8: Deal Record** → Standardized JSON + markdown
10. **QR-9: Audit Log** → Full execution trail

Suitable for initial deal evaluation, internal discussion, and deciding whether to commit to full underwriting.

**One-command version:** Use `pinchfin_quick_review` to run all 10 phases as a single tool call. Cost: ~$2-$6.

### Full Underwriting Workflow — Coming Post-Beta

The complete multi-phase institutional workflow covers deal intake through credit decision, including document synthesis, sponsor diligence, market and comparable research, lender rent derivation, cash flow underwriting, valuation, loan sizing, structuring, risk assessment, and IC memo generation. Currently optimized for multifamily and mixed-use transitional and stabilized assets. Additional asset classes are in development.

---

## Architecture

```
Your Claude Code Terminal
    │
    ▼
pinchfin MCP Server (our infrastructure)
    │
    ├── Orchestration Engine (private)
    ├── Credit Policy Configuration (private)
    ├── RAG Corpus — 5,900+ documents (private)
    ├── 26 Modules / 290+ Skills (private)
    ├── Deterministic Calculation Engines (private)
    ├── Nuance Gate — 32 deal complexity types (private)
    ├── Valeri Data Services — 25 government data tools (private)
    ├── Billing & Metering Engine
    └── Cost Estimation Engine
        │
        ▼
Structured Results → your terminal
```

All analysis logic runs on pinchfin infrastructure. Your Claude Code session sends deal inputs and receives institutional-grade results. No proprietary logic is exposed.

---

## Usage Patterns

### Quick Screen

```
Screen this deal: 240-unit Class B garden-style in Phoenix, $35M loan,
$52M value, bridge refi. Sponsor has 2,000+ units in the market.
```

### Sponsor Diligence

```
Run sponsor analysis on Greystone Multifamily Partners.
Principal: David Kowalski. Claims 6,500 units across TX and AZ.
```

### Term Sheet Comparison (Broker / Sponsor)

```
Compare these three term sheets for 456 Oak Park Ave:
- Lender A: 65% LTV, SOFR+325, 3+1+1, 1% origination
- Lender B: 70% LTV, SOFR+275, 2+1+1, 1.5% origination
- Lender C: 72% LTV, SOFR+350, 3+1+1, 0.75% origination
Which is the best all-in execution?
```

### Quick Sizing (Broker / Sponsor)

```
How much can I borrow on a 120-unit stabilized property in Austin?
NOI: $1.8M, appraised at $32M, purchase price $30M.
```

### Business Plan Review (Sponsor)

```
Evaluate this business plan: 200-unit Class C value-add in Atlanta.
$45K/unit renovation budget, targeting $250/unit rent premium over 24 months.
Current avg rent $1,150, market comps at $1,450.
```

### Document Synthesis

```
Synthesize all correspondence in ~/deals/oak-park/transcripts/ and
~/deals/oak-park/documents/ into a deal narrative, then run a quick review.
```

### Check Costs

```
How much would it cost to run sponsor analysis + market research +
comp analysis on a 300-unit deal?
```

---

## Folder Organization

```
~/deals/property-name/
├── documents/
│   ├── OM.pdf
│   ├── rent_roll.xlsx
│   ├── t12_operating_statement.pdf
│   └── sponsor_pfs.pdf
└── transcripts/
    ├── broker_call_2025-01-15.txt
    ├── sponsor_call_2025-01-18.txt
    └── email_correspondence.eml
```

**Record and transcribe all deal-related calls.** Conversations contain critical deal intelligence that rarely appears in documents.

---

## Tips for Best Results

1. **Be specific.** Include property type, location, unit count, loan amount, and sponsor details.
2. **Provide context.** Brief the system like you'd brief a senior credit analyst.
3. **Synthesize first.** Process transcripts and emails before running analysis.
4. **Start with screen.** A $0.25 screen can save you from running $6 of analysis on a deal that doesn't work.
5. **Use the right tool for your role.** Lenders: screen → quick review → IC memo. Brokers: debt sizing preview → term sheet comparator. Sponsors: business plan analysis → renovation ROI.

---

## CLI Commands

| Command | Description |
|---------|-------------|
| `pinchfin login` | Authenticate and auto-configure MCP |
| `pinchfin setup` | (Re)install MCP configuration |
| `pinchfin status` | Check connection and balance |
| `pinchfin balance` | Detailed balance and transaction history |
| `pinchfin deposit` | Load funds via Stripe |
| `pinchfin usage` | View per-deal cost history |
| `pinchfin pricing` | Display full pricing table with cost factors |
| `pinchfin help` | List all tools with costs and tips |
| `pinchfin logout` | Remove credentials |

---

## Support

- **Documentation**: [docs.pinchfin.com](https://docs.pinchfin.com)
- **Email**: [support@pinchfin.com](mailto:support@pinchfin.com)

---

© Veleta Capital LLC. All rights reserved.
