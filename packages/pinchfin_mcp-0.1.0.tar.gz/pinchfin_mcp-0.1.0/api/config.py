"""
pinchfin API — Configuration
==============================
Centralized settings loaded from environment variables.
All env vars are prefixed with PINCHFIN_ to avoid collisions.

(c) Veleta Capital LLC. All rights reserved.
"""

import os
from dataclasses import dataclass, field


def _env(key: str, default: str = "") -> str:
    """Read a PINCHFIN_ prefixed environment variable."""
    return os.environ.get(f"PINCHFIN_{key}", default)


def _env_bool(key: str, default: bool = False) -> bool:
    """Read a boolean environment variable."""
    val = _env(key, str(default)).lower()
    return val in ("true", "1", "yes")


def _env_int(key: str, default: int = 0) -> int:
    """Read an integer environment variable."""
    try:
        return int(_env(key, str(default)))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    """Application settings. Immutable after creation."""

    # Server
    HOST: str = field(default_factory=lambda: _env("HOST", "0.0.0.0"))
    PORT: int = field(default_factory=lambda: _env_int("PORT", 8000))
    DEBUG: bool = field(default_factory=lambda: _env_bool("DEBUG", True))

    # Database
    DB_MODE: str = field(default_factory=lambda: _env("DB_MODE", "memory"))
    DATABASE_URL: str = field(default_factory=lambda: _env("DATABASE_URL", ""))

    # Stripe
    STRIPE_SECRET_KEY: str = field(
        default_factory=lambda: _env("STRIPE_SECRET_KEY", "")
    )
    STRIPE_WEBHOOK_SECRET: str = field(
        default_factory=lambda: _env("STRIPE_WEBHOOK_SECRET", "")
    )

    # API
    API_BASE_URL: str = field(
        default_factory=lambda: _env("API_BASE_URL", "https://api.pinchfin.com")
    )
    MCP_URL: str = field(
        default_factory=lambda: _env("MCP_URL", "https://mcp.pinchfin.com/sse")
    )

    # Auth
    API_KEY_PREFIX: str = "pf_"

    # Analysis — real Claude/Perplexity/Valeri Data integration
    ANTHROPIC_API_KEY: str = field(
        default_factory=lambda: (
            os.environ.get("ANTHROPIC_API_KEY", "")
            or _env("ANTHROPIC_API_KEY", "")
        )
    )
    PERPLEXITY_API_KEY: str = field(
        default_factory=lambda: (
            os.environ.get("PERPLEXITY_API_KEY", "")
            or _env("PERPLEXITY_API_KEY", "")
        )
    )
    VALERI_DATA_URL: str = field(
        default_factory=lambda: _env("VALERI_DATA_URL", "http://localhost:3001")
    )
    ANALYSIS_ENABLED: bool = field(
        default_factory=lambda: bool(
            os.environ.get("ANTHROPIC_API_KEY")
            or os.environ.get("PINCHFIN_ANTHROPIC_API_KEY")
        )
    )


# Module-level singleton — import and use directly
settings = Settings()
