"""
pinchfin API — Database Connection Manager
=============================================
Supports two modes:
  DB_MODE=memory  (default) — uses WalletManager from billing.py in-memory
  DB_MODE=postgres           — uses asyncpg connection pool with DATABASE_URL

(c) Veleta Capital LLC. All rights reserved.
"""

import os
import logging
from typing import Optional, Any

LOG = logging.getLogger("pinchfin.db")


class DatabaseConnection:
    """
    Unified database interface.

    In memory mode, this is a thin wrapper that delegates to the in-memory
    WalletManager and AppState. In postgres mode, it manages an asyncpg
    connection pool.
    """

    def __init__(self) -> None:
        self.mode: str = os.environ.get("PINCHFIN_DB_MODE", "memory")
        self.database_url: str = os.environ.get("PINCHFIN_DATABASE_URL", "")
        self._pool: Any = None  # asyncpg.Pool when in postgres mode
        self._connected: bool = False

    @property
    def is_postgres(self) -> bool:
        return self.mode == "postgres"

    @property
    def is_memory(self) -> bool:
        return self.mode == "memory"

    async def connect(self) -> None:
        """Initialize the database connection."""
        if self.is_memory:
            LOG.info("Database running in memory mode (no persistence)")
            self._connected = True
            return

        if self.is_postgres:
            if not self.database_url:
                raise ValueError(
                    "PINCHFIN_DATABASE_URL is required when DB_MODE=postgres"
                )
            try:
                import asyncpg
            except ImportError:
                raise RuntimeError(
                    "asyncpg is required for postgres mode. "
                    "Install with: pip install asyncpg"
                )

            self._pool = await asyncpg.create_pool(
                self.database_url,
                min_size=2,
                max_size=10,
                command_timeout=30,
            )
            LOG.info("Connected to PostgreSQL: %s", self._redact_url())
            self._connected = True
            return

        raise ValueError(
            f"Invalid DB_MODE: {self.mode!r}. Must be 'memory' or 'postgres'."
        )

    async def disconnect(self) -> None:
        """Close the database connection."""
        if self._pool is not None:
            await self._pool.close()
            self._pool = None
            LOG.info("PostgreSQL connection pool closed")
        self._connected = False

    async def execute(self, query: str, *args: Any) -> str:
        """Execute a query (INSERT, UPDATE, DELETE). Returns status string."""
        self._require_postgres("execute")
        async with self._pool.acquire() as conn:
            return await conn.execute(query, *args)

    async def fetch(self, query: str, *args: Any) -> list:
        """Execute a query and return all rows."""
        self._require_postgres("fetch")
        async with self._pool.acquire() as conn:
            return await conn.fetch(query, *args)

    async def fetchrow(self, query: str, *args: Any) -> Optional[Any]:
        """Execute a query and return a single row."""
        self._require_postgres("fetchrow")
        async with self._pool.acquire() as conn:
            return await conn.fetchrow(query, *args)

    async def fetchval(self, query: str, *args: Any) -> Optional[Any]:
        """Execute a query and return a single value."""
        self._require_postgres("fetchval")
        async with self._pool.acquire() as conn:
            return await conn.fetchval(query, *args)

    def _require_postgres(self, method: str) -> None:
        """Guard: SQL methods only work in postgres mode."""
        if not self.is_postgres:
            raise RuntimeError(
                f"db.{method}() requires DB_MODE=postgres. "
                f"Current mode: {self.mode}"
            )
        if self._pool is None:
            raise RuntimeError(
                "Database not connected. Call await db.connect() first."
            )

    def _redact_url(self) -> str:
        """Redact password from database URL for logging."""
        url = self.database_url
        if "@" in url:
            prefix, suffix = url.rsplit("@", 1)
            if ":" in prefix:
                scheme_user = prefix.rsplit(":", 1)[0]
                return f"{scheme_user}:***@{suffix}"
        return url


# Module-level singleton
db = DatabaseConnection()
