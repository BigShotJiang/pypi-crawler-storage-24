"""
pinchfin API — Development Seed Script
=========================================
Creates test data for local development:
  - Test account with dev@pinchfin.com
  - API key (printed to console)
  - $100 balance ($10 free credit + $90 deposit)
  - Sample deal

Usage:
    python -m api.db.seed

(c) Veleta Capital LLC. All rights reserved.
"""

import asyncio
import sys
import os
from pathlib import Path
from datetime import datetime, timezone

# Add project root to sys.path
_project_root = str(Path(__file__).resolve().parent.parent.parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from api.utils import generate_api_key, hash_api_key, generate_id, generate_deal_id
from src.billing import WalletManager, Account, Transaction


async def seed() -> None:
    """Create development seed data."""
    wallet = WalletManager()

    # -----------------------------------------------------------------------
    # 1. Create test account
    # -----------------------------------------------------------------------
    api_key = generate_api_key()
    account = await wallet.create_account(
        email="dev@pinchfin.com",
        api_key=api_key,
    )

    # -----------------------------------------------------------------------
    # 2. Add deposit ($90 on top of $10 free credit = $100 total)
    # -----------------------------------------------------------------------
    await wallet.deposit(
        account=account,
        amount=90.00,
        stripe_payment_id="pi_dev_seed_000000",
    )

    # -----------------------------------------------------------------------
    # 3. Create a sample deal
    # -----------------------------------------------------------------------
    deal_id = generate_deal_id(counter=1)

    # Store deal in the wallet's account for reference
    # (In production this would be a database INSERT)

    # -----------------------------------------------------------------------
    # Print results
    # -----------------------------------------------------------------------
    print("")
    print("=" * 60)
    print("  pinchfin Development Seed")
    print("=" * 60)
    print("")
    print(f"  Account ID:    {account.id}")
    print(f"  Email:         {account.email}")
    print(f"  Balance:       ${account.balance:.2f}")
    print(f"  Free Credit:   $10.00")
    print(f"  Deposit:       $90.00")
    print(f"  Sample Deal:   {deal_id}")
    print("")
    print("  API Key (save this — it won't be shown again):")
    print(f"  {api_key}")
    print("")
    print("  Usage:")
    print(f'    export PINCHFIN_API_KEY="{api_key}"')
    print(f"    curl -H \"Authorization: Bearer {api_key}\" \\")
    print(f"         http://localhost:8000/v1/billing/account")
    print("")
    print("=" * 60)
    print("")


if __name__ == "__main__":
    asyncio.run(seed())
