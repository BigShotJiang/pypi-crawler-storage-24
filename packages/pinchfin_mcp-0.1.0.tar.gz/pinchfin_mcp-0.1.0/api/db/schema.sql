-- pinchfin Database Schema
-- Run against a PostgreSQL database

BEGIN;

-- Accounts
CREATE TABLE IF NOT EXISTS accounts (
    id              TEXT PRIMARY KEY,          -- acct_xxxxxxxxxxxx
    email           TEXT NOT NULL UNIQUE,
    api_key_hash    TEXT NOT NULL UNIQUE,      -- SHA-256 hash of API key
    balance         DECIMAL(10,2) DEFAULT 0,
    held_amount     DECIMAL(10,2) DEFAULT 0,
    total_deposited DECIMAL(10,2) DEFAULT 0,
    total_spent     DECIMAL(10,2) DEFAULT 0,
    total_analyses  INTEGER DEFAULT 0,
    stripe_customer TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Transaction Ledger (append-only)
CREATE TABLE IF NOT EXISTS transactions (
    id              TEXT PRIMARY KEY,          -- txn_xxxxxxxxxxxx
    account_id      TEXT NOT NULL REFERENCES accounts(id),
    type            TEXT NOT NULL,             -- deposit, charge, hold, release, free_credit, refund
    amount          DECIMAL(10,4) NOT NULL,    -- positive=credit, negative=debit
    balance_after   DECIMAL(10,2) NOT NULL,
    description     TEXT,
    deal_id         TEXT,
    module          TEXT,
    estimate_id     TEXT,
    stripe_payment  TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_txn_account ON transactions(account_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_txn_deal ON transactions(deal_id);

-- Active Holds
CREATE TABLE IF NOT EXISTS holds (
    id              TEXT PRIMARY KEY,          -- hold_xxxxxxxxxxxx
    account_id      TEXT NOT NULL REFERENCES accounts(id),
    estimate_id     TEXT,
    deal_id         TEXT,
    hold_amount     DECIMAL(10,2) NOT NULL,
    placed_at       TIMESTAMPTZ DEFAULT NOW(),
    settled_at      TIMESTAMPTZ,
    status          TEXT DEFAULT 'active'      -- active, settled, released
);
CREATE INDEX IF NOT EXISTS idx_holds_account ON holds(account_id, status);

-- Usage Meters (one per analysis run)
CREATE TABLE IF NOT EXISTS usage_meters (
    id                  TEXT PRIMARY KEY,      -- mtr_xxxxxxxxxxxx
    deal_id             TEXT,
    account_id          TEXT NOT NULL REFERENCES accounts(id),
    modules             TEXT[],
    llm_input_tokens    INTEGER DEFAULT 0,
    llm_output_tokens   INTEGER DEFAULT 0,
    document_pages      INTEGER DEFAULT 0,
    rag_queries         INTEGER DEFAULT 0,
    external_api_calls  INTEGER DEFAULT 0,
    compute_seconds     REAL DEFAULT 0,
    llm_cost            DECIMAL(10,4) DEFAULT 0,
    document_cost       DECIMAL(10,4) DEFAULT 0,
    rag_cost            DECIMAL(10,4) DEFAULT 0,
    external_api_cost   DECIMAL(10,4) DEFAULT 0,
    total_cost          DECIMAL(10,2) DEFAULT 0,
    started_at          TIMESTAMPTZ DEFAULT NOW(),
    completed_at        TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_meters_account ON usage_meters(account_id);
CREATE INDEX IF NOT EXISTS idx_meters_deal ON usage_meters(deal_id);

-- Deals
CREATE TABLE IF NOT EXISTS deals (
    id              TEXT PRIMARY KEY,          -- PF-2026-001
    account_id      TEXT NOT NULL REFERENCES accounts(id),
    property_address TEXT,
    property_name    TEXT,
    unit_count      INTEGER,
    loan_amount     DECIMAL(12,2),
    sponsor_name    TEXT,
    status          TEXT DEFAULT 'active',     -- active, completed, archived
    phases_completed TEXT[] DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_deals_account ON deals(account_id, status);

-- API Keys (separate table for key management)
CREATE TABLE IF NOT EXISTS api_keys (
    id              TEXT PRIMARY KEY,
    account_id      TEXT NOT NULL REFERENCES accounts(id),
    key_hash        TEXT NOT NULL UNIQUE,      -- SHA-256
    key_prefix      TEXT NOT NULL,             -- First 8 chars for display
    name            TEXT DEFAULT 'default',
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    last_used_at    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_apikeys_hash ON api_keys(key_hash) WHERE is_active = TRUE;

COMMIT;
