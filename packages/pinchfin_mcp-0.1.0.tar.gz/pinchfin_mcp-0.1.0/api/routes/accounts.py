"""
pinchfin API — Account & Auth Routes
======================================
POST /v1/auth/signup       — Create account (public, no auth)
POST /v1/auth/rotate-key   — Rotate API key (requires auth)
GET  /v1/auth/whoami       — Lightweight account info (requires auth)

(c) Veleta Capital LLC. All rights reserved.
"""

import re

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from api.auth import get_current_account
from api.state import app_state
from api.utils import generate_api_key

router = APIRouter(prefix="/auth", tags=["auth"])

# Simple email regex — catches obvious garbage without over-engineering
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# ---------------------------------------------------------------------------
# Request / Response Models
# ---------------------------------------------------------------------------
class SignupRequest(BaseModel):
    email: str = Field(..., description="Email address for the new account")


class SignupResponse(BaseModel):
    account_id: str
    api_key: str
    balance: float
    message: str


class RotateKeyResponse(BaseModel):
    api_key: str
    message: str


class WhoamiResponse(BaseModel):
    account_id: str
    email: str
    balance: float


# ---------------------------------------------------------------------------
# POST /v1/auth/signup
# ---------------------------------------------------------------------------
@router.post("/signup", response_model=SignupResponse, status_code=201)
async def signup(req: SignupRequest):
    """
    Create a new account with free credit.

    No authentication required. Returns the API key exactly once —
    it is not stored in plaintext and cannot be retrieved later.
    """
    email = req.email.strip().lower()

    if not _EMAIL_RE.match(email):
        raise HTTPException(422, "Invalid email format.")

    # Check for duplicate email across all existing accounts
    if app_state.wallet._use_pg:
        existing = await app_state.wallet.db.fetchval(
            "SELECT id FROM accounts WHERE LOWER(email) = $1", email,
        )
        if existing:
            raise HTTPException(409, "An account with this email already exists.")
    else:
        for acct in app_state.wallet._accounts.values():
            if acct.email.lower() == email:
                raise HTTPException(409, "An account with this email already exists.")

    api_key = generate_api_key()

    account = await app_state.wallet.create_account(
        email=email,
        api_key=api_key,
    )

    return SignupResponse(
        account_id=account.id,
        api_key=api_key,
        balance=round(account.balance, 2),
        message=(
            f"Account created with ${account.balance:.2f} free credit. "
            "Save your API key — it won't be shown again."
        ),
    )


# ---------------------------------------------------------------------------
# POST /v1/auth/rotate-key
# ---------------------------------------------------------------------------
@router.post("/rotate-key", response_model=RotateKeyResponse)
async def rotate_key(account=Depends(get_current_account)):
    """
    Generate a new API key and invalidate the old one.

    Requires the current (soon-to-be-old) API key for authentication.
    """
    new_key = generate_api_key()

    if app_state.wallet._use_pg:
        import hashlib
        new_hash = hashlib.sha256(new_key.encode()).hexdigest()
        new_prefix = new_key[:8]

        async with app_state.wallet.db._pool.acquire() as conn:
            async with conn.transaction():
                # Deactivate all existing keys for this account
                await conn.execute(
                    "UPDATE api_keys SET is_active = FALSE WHERE account_id = $1",
                    account.id,
                )
                # Insert new key
                from api.utils import generate_id
                await conn.execute(
                    "INSERT INTO api_keys "
                    "(id, account_id, key_hash, key_prefix, name) "
                    "VALUES ($1, $2, $3, $4, 'rotated')",
                    generate_id("apikey_"), account.id, new_hash, new_prefix,
                )
                # Update accounts.api_key_hash for direct-lookup compatibility
                await conn.execute(
                    "UPDATE accounts SET api_key_hash = $1, updated_at = NOW() "
                    "WHERE id = $2",
                    new_hash, account.id,
                )
    else:
        # In-memory path: find the old key that maps to this account
        old_key = None
        for key, acct in app_state.wallet._accounts.items():
            if acct.id == account.id:
                old_key = key
                break

        if old_key is None:
            raise HTTPException(500, "Could not locate account entry for key rotation.")

        del app_state.wallet._accounts[old_key]
        account.api_key_hash = new_key
        app_state.wallet._accounts[new_key] = account

    return RotateKeyResponse(
        api_key=new_key,
        message="New key generated. Old key is now invalid.",
    )


# ---------------------------------------------------------------------------
# GET /v1/auth/whoami
# ---------------------------------------------------------------------------
@router.get("/whoami", response_model=WhoamiResponse)
async def whoami(account=Depends(get_current_account)):
    """
    Lightweight identity check — returns account ID, email, and balance.

    No transaction history; use /v1/billing/account for the full view.
    """
    return WhoamiResponse(
        account_id=account.id,
        email=account.email,
        balance=round(account.balance, 2),
    )
