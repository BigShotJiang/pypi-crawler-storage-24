"""
pinchfin API — Billing Routes
===============================
POST /v1/billing/estimate   — Cost estimation
GET  /v1/billing/account    — Account info + transactions
POST /v1/billing/deposit    — Stripe checkout session
POST /v1/billing/webhooks/stripe — Stripe webhook handler

(c) Veleta Capital LLC. All rights reserved.
"""

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from typing import Optional

from api.auth import get_current_account
from api.state import app_state
from src.billing import (
    CostEstimateRequest,
    estimate_cost,
    StripeManager,
    MIN_DEPOSIT,
)

router = APIRouter(prefix="/billing", tags=["billing"])


# ---------------------------------------------------------------------------
# POST /v1/billing/estimate
# ---------------------------------------------------------------------------
@router.post("/estimate")
async def api_estimate_cost(
    req: CostEstimateRequest,
    account=Depends(get_current_account),
):
    """
    Estimate the cost of running one or more analysis modules.

    Returns the cost range, hold amount, per-module breakdown,
    current balance, and whether funds are sufficient.
    """
    est = estimate_cost(req)
    return {
        "estimate": est.to_dict(),
        "account": {
            "balance": round(account.balance, 2),
            "held_amount": round(account.held_amount, 2),
            "available_balance": round(account.available_balance, 2),
            "sufficient_funds": account.available_balance >= est.hold_amount,
        },
    }


# ---------------------------------------------------------------------------
# GET /v1/billing/account
# ---------------------------------------------------------------------------
@router.get("/account")
async def api_account_info(
    include_transactions: bool = True,
    transaction_limit: int = 10,
    account=Depends(get_current_account),
):
    """
    Return account info, balance, and optionally recent transactions.
    """
    result = {"account": account.to_dict()}
    if include_transactions:
        txns = await app_state.wallet.get_transactions(account, limit=transaction_limit)
        result["recent_transactions"] = txns
    return result


# ---------------------------------------------------------------------------
# POST /v1/billing/deposit
# ---------------------------------------------------------------------------
class DepositRequest(BaseModel):
    amount: float = Field(..., ge=25.0, le=10000.0, description="Deposit amount in USD")


@router.post("/deposit")
async def api_create_deposit(
    req: DepositRequest,
    account=Depends(get_current_account),
):
    """
    Create a Stripe checkout session to load funds.

    Returns a checkout URL the client should open in a browser.
    """
    if req.amount < MIN_DEPOSIT:
        raise HTTPException(400, f"Minimum deposit is ${MIN_DEPOSIT:.2f}")

    try:
        if not account.stripe_customer_id:
            account.stripe_customer_id = await StripeManager.create_customer(
                account.email, account.id
            )

        checkout_url = await StripeManager.create_checkout_session(
            account.stripe_customer_id,
            int(req.amount * 100),
        )
        return {"checkout_url": checkout_url}

    except RuntimeError as e:
        # Stripe SDK not installed or not configured
        raise HTTPException(
            503,
            detail=f"Payment processing unavailable: {e}",
        )


# ---------------------------------------------------------------------------
# POST /v1/billing/webhooks/stripe
# ---------------------------------------------------------------------------
@router.post("/webhooks/stripe")
async def api_stripe_webhook(request: Request):
    """
    Handle Stripe webhook events (checkout.session.completed).

    Stripe sends a POST with the event payload. We verify the signature,
    extract payment info, and credit the account.
    """
    payload = await request.body()
    sig = request.headers.get("stripe-signature", "")

    try:
        result = await StripeManager.handle_webhook(payload, sig)
    except RuntimeError:
        raise HTTPException(503, "Payment processing unavailable")

    if result:
        # Find account by stripe customer ID
        customer_id = result["customer_id"]
        target_account = await _find_account_by_stripe_customer(customer_id)

        if target_account:
            await app_state.wallet.deposit(
                target_account,
                result["amount"],
                result["payment_id"],
            )

    return {"ok": True}


async def _find_account_by_stripe_customer(customer_id: str):
    """Look up account by Stripe customer ID (dual-mode)."""
    from src.billing import Account

    if app_state.wallet._use_pg:
        row = await app_state.wallet.db.fetchrow(
            "SELECT * FROM accounts WHERE stripe_customer = $1",
            customer_id,
        )
        return app_state.wallet._row_to_account(row) if row else None

    # In-memory path
    for acct in app_state.wallet._accounts.values():
        if acct.stripe_customer_id == customer_id:
            return acct
    return None
