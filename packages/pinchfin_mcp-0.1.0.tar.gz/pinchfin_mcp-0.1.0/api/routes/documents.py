"""
pinchfin API — Document Download Routes
==========================================
Endpoints for downloading generated DOCX reports.

GET /v1/deals/{deal_id}/documents/{doc_id}

(c) Veleta Capital LLC. All rights reserved.
"""

import logging
from fastapi import APIRouter, HTTPException
from fastapi.responses import Response

from api.analysis.report.storage import retrieve_docx, cleanup_expired

LOG = logging.getLogger("pinchfin.routes.documents")

router = APIRouter(prefix="/v1/deals", tags=["documents"])


@router.get("/{deal_id}/documents/{doc_id}")
async def download_document(deal_id: str, doc_id: str):
    """
    Download a generated DOCX document by its download ID.

    The doc_id is returned in the analysis response when output_format
    is "docx" or "both".
    """
    # Run cleanup on each request (lightweight)
    cleanup_expired()

    result = retrieve_docx(doc_id)
    if result is None:
        raise HTTPException(
            status_code=404,
            detail=f"Document not found or expired (4hr TTL). doc_id={doc_id}",
        )

    content, filename = result

    return Response(
        content=content,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
        },
    )
