"""
pinchfin API — Analysis Module Routes
=======================================
All billable analysis endpoints. Each endpoint:
1. Requires authenticated + funded account
2. Places a hold via WalletManager
3. Creates a UsageMeter
4. Returns mock results (real analysis wired later)
5. Settles the hold with metered cost

(c) Veleta Capital LLC. All rights reserved.
"""

import uuid
import random
import logging
from datetime import datetime, timezone
from typing import Optional, List, Literal, Callable, Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, ConfigDict

from api.auth import require_funds
from api.state import app_state
from api.analysis import is_analysis_available
from src.billing import (
    ModuleType,
    CostEstimateRequest,
    estimate_cost,
    create_meter,
    Account,
)

LOG = logging.getLogger("pinchfin.modules")
router = APIRouter(tags=["modules"])

# Lazy imports for analysis functions (avoid import errors when anthropic not installed)
def _get_tier1():
    from api.analysis.tier1 import (
        analyze_deal_screen,
        analyze_debt_sizing_preview,
        analyze_loan_sizer,
        analyze_loan_pricing,
    )
    return analyze_deal_screen, analyze_debt_sizing_preview, analyze_loan_sizer, analyze_loan_pricing

def _get_tier2():
    from api.analysis.tier2 import analyze_sponsor, analyze_market, analyze_comps
    return analyze_sponsor, analyze_market, analyze_comps

def _get_tier3():
    from api.analysis.tier3 import (
        analyze_rent_roll,
        analyze_cash_flow,
        analyze_nuance_gate,
        analyze_ic_memo,
        analyze_term_sheet_comparator,
        analyze_business_plan,
        analyze_renovation_roi,
        analyze_quick_review,
    )
    return (
        analyze_rent_roll, analyze_cash_flow, analyze_nuance_gate,
        analyze_ic_memo, analyze_term_sheet_comparator,
        analyze_business_plan, analyze_renovation_roi, analyze_quick_review,
    )


# ═══════════════════════════════════════════════════════════════════════════
# Shared helpers
# ═══════════════════════════════════════════════════════════════════════════

async def _run_module(
    account: Account,
    modules: List[ModuleType],
    deal_id: Optional[str],
    unit_count: Optional[int],
    document_count: Optional[int] = None,
    document_pages: Optional[int] = None,
    mock_result: Optional[dict] = None,
    analysis_fn: Optional[Callable] = None,
    analysis_request: Any = None,
    output_format: str = "both",
    tool_name: Optional[str] = None,
    deal_name: str = "",
):
    """
    Common hold → meter → execute → settle flow for all module endpoints.

    Dual-path:
      - When analysis_fn is provided AND ANTHROPIC_API_KEY is set: call real analysis
      - Otherwise: fall back to mock_result (exactly as before)
      - On real analysis failure: fall back to mock with warning log
    """
    # Ensure we have a deal_id owned by this account
    if not deal_id:
        deal_record = app_state.create_deal(account_id=account.id)
        deal_id = deal_record.deal_id
    else:
        existing = app_state.get_deal(deal_id)
        if not existing:
            deal_record = app_state.create_deal(account_id=account.id)
            deal_id = deal_record.deal_id
        elif existing.account_id != account.id:
            raise HTTPException(
                status_code=403,
                detail="Access denied: this deal belongs to another account.",
            )

    # Build cost estimate and place hold
    est_req = CostEstimateRequest(
        modules=modules,
        unit_count=unit_count,
        document_count=document_count,
        document_pages=document_pages,
    )
    est = estimate_cost(est_req)

    hold_id = await app_state.wallet.place_hold(account, est, deal_id)
    if hold_id is None:
        raise HTTPException(
            status_code=402,
            detail={
                "error": "Insufficient funds",
                "balance": round(account.balance, 2),
                "available_balance": round(account.available_balance, 2),
                "required": round(est.hold_amount, 2),
                "deposit_url": "https://app.pinchfin.com/billing",
            },
        )

    # Create meter
    module_names = [m.value for m in modules]
    meter = create_meter(deal_id, account.id, module_names)

    # --- Dual-path execution ---
    result = None
    analysis_mode = "mock"

    if analysis_fn is not None and is_analysis_available():
        try:
            LOG.info("Running REAL analysis for %s (deal=%s)", module_names, deal_id)
            result = await analysis_fn(analysis_request or {}, meter=meter)
            analysis_mode = "real"
            LOG.info("Real analysis completed for %s", module_names)
        except Exception as e:
            LOG.warning(
                "Real analysis failed for %s, falling back to mock: %s",
                module_names, e,
            )
            result = None  # Will fall through to mock

    if result is None:
        # Mock path — simulate usage as before
        result = mock_result or {}
        meter.record_llm_usage(
            input_tokens=random.randint(8000, 45000),
            output_tokens=random.randint(2000, 12000),
        )
        meter.record_rag_query(random.randint(2, 15))
        meter.record_external_api(random.randint(1, 8))
        if document_pages:
            meter.record_document_processing(document_pages)
        meter.compute_seconds = random.uniform(5.0, 45.0)

    cost_report = meter.finalize()
    actual_cost = meter.total_cost

    # Ensure actual cost falls within estimated range (realistic)
    actual_cost = max(actual_cost, est.low * 0.9)
    actual_cost = min(actual_cost, est.high * 1.1)

    # Settle the hold
    txn = await app_state.wallet.settle(
        account, hold_id, actual_cost, module_names, deal_id,
    )

    # Update deal record
    deal = app_state.get_deal(deal_id)
    if deal:
        deal.modules_run.extend(module_names)
        deal.updated_at = datetime.now(timezone.utc).isoformat()

    # --- DOCX auto-generation ---
    document_info = None
    if analysis_mode == "real" and output_format in ("docx", "both") and tool_name:
        try:
            from api.analysis.report.mapper import build_report
            from api.analysis.report.storage import store_docx

            docx_bytes = build_report(tool_name, result, deal_name=deal_name)
            if docx_bytes:
                doc_id = store_docx(docx_bytes, deal_id, tool_name)
                document_info = {
                    "document_id": doc_id,
                    "document_url": f"/v1/deals/{deal_id}/documents/{doc_id}",
                    "document_name": f"{deal_name or deal_id}_{tool_name}.docx",
                    "format": "docx",
                }
                LOG.info("DOCX generated for %s (doc_id=%s)", tool_name, doc_id)
        except Exception as e:
            LOG.warning("DOCX generation failed for %s: %s", tool_name, e)

    response = {
        "deal_id": deal_id,
        "analysis_mode": analysis_mode,
        "results": result if output_format in ("json", "both") else {"document_only": True},
        "cost": {
            "actual": round(actual_cost, 2),
            "estimate_range": {
                "low": round(est.low, 2),
                "high": round(est.high, 2),
            },
            "remaining_balance": round(account.balance, 2),
            "meter": cost_report,
        },
    }
    if document_info:
        response["document"] = document_info

    return response


# ═══════════════════════════════════════════════════════════════════════════
# Request models
# ═══════════════════════════════════════════════════════════════════════════

class DealScreenRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    property_address: str = Field(..., min_length=5)
    unit_count: int = Field(..., ge=1, le=10000)
    loan_amount: float = Field(..., gt=0)
    purchase_price: Optional[float] = Field(None, gt=0)
    asset_value: Optional[float] = Field(None, gt=0)
    loan_purpose: Optional[str] = Field("bridge")
    sponsor_name: Optional[str] = None
    notes: Optional[str] = None


class DealBookRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    property_address: Optional[str] = None
    unit_count: Optional[int] = Field(None, ge=1)
    loan_amount: Optional[float] = Field(None, gt=0)
    sponsor_name: Optional[str] = None
    broker_name: Optional[str] = None
    deal_narrative: Optional[str] = None
    document_count: Optional[int] = Field(None, ge=0)
    document_pages: Optional[int] = Field(None, ge=0)


class SponsorAnalysisRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    sponsor_name: str = Field(..., min_length=1)
    sponsor_website: Optional[str] = None
    additional_context: Optional[str] = None


class MarketResearchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    property_address: str = Field(..., min_length=5)
    radius_miles: Optional[float] = Field(3.0, ge=0.5, le=25.0)
    include_demographics: Optional[bool] = True
    include_employment: Optional[bool] = True
    include_supply_pipeline: Optional[bool] = True


class CompAnalysisRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    property_address: str = Field(..., min_length=5)
    unit_count: int = Field(..., ge=1)
    asset_class: Optional[str] = "B"
    year_built: Optional[int] = None
    comp_types: Optional[List[str]] = Field(default_factory=lambda: ["sales", "rent"])


class RentRollRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    property_address: Optional[str] = None
    unit_count: Optional[int] = Field(None, ge=1)
    rent_roll_path: str = Field(..., min_length=1)
    market_rent_estimate: Optional[float] = None


class CashFlowRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    property_address: str = Field(..., min_length=5)
    unit_count: int = Field(..., ge=1)
    current_revenue: Optional[float] = None
    current_noi: Optional[float] = None
    pro_forma_rents: Optional[float] = None
    projection_years: Optional[int] = Field(5, ge=1, le=10)


class LoanSizerRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    property_address: Optional[str] = None
    loan_amount_requested: float = Field(..., gt=0)
    asset_value: float = Field(..., gt=0)
    noi: float = Field(..., gt=0)
    loan_purpose: Optional[str] = "bridge"
    rate_type: Optional[str] = "floating"
    term_months: Optional[int] = Field(36, ge=6, le=120)


class TermSheetRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: str = Field(..., min_length=1)
    template: Optional[str] = "standard"


class ShortFormMemoRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: str = Field(..., min_length=1)
    include_sections: Optional[List[str]] = None


class NuanceGateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: str = Field(..., min_length=1)
    focus_areas: Optional[List[str]] = None


class ICMemoRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: str = Field(..., min_length=1)
    memo_format: Optional[str] = "full"
    include_appendices: Optional[bool] = True


class QuickReviewRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    property_address: str = Field(..., min_length=5)
    unit_count: int = Field(..., ge=1, le=10000)
    loan_amount: float = Field(..., gt=0)
    purchase_price: Optional[float] = Field(None, gt=0)
    asset_value: Optional[float] = Field(None, gt=0)
    loan_purpose: Optional[str] = "bridge"
    sponsor_name: str = Field(..., min_length=1)
    notes: Optional[str] = None
    current_noi: Optional[float] = None
    pro_forma_rents: Optional[float] = None
    is_rerun: Optional[bool] = False


class FullWorkflowRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    property_address: str = Field(..., min_length=5)
    unit_count: int = Field(..., ge=1, le=10000)
    loan_amount: float = Field(..., gt=0)
    purchase_price: Optional[float] = Field(None, gt=0)
    asset_value: Optional[float] = Field(None, gt=0)
    loan_purpose: str = Field("bridge")
    sponsor_name: str = Field(..., min_length=1)
    deal_narrative: Optional[str] = None
    document_count: Optional[int] = Field(None, ge=0)
    document_pages: Optional[int] = Field(None, ge=0)
    phases: Optional[List[int]] = None
    output_format: Optional[str] = "full"
    is_rerun: Optional[bool] = False


class TermSheetComparatorRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    term_sheets: list = Field(..., min_length=2)
    property_address: Optional[str] = None
    loan_amount: Optional[float] = Field(None, gt=0)
    comparison_criteria: Optional[list] = None


class LoanPricingRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    loan_amount: float = Field(..., gt=0)
    rate_type: Optional[str] = Field("floating")
    index: Optional[str] = Field("SOFR")
    spread_bps: Optional[int] = None
    loan_term_months: Optional[int] = Field(36)
    rate_cap_required: Optional[bool] = True
    rate_cap_strike: Optional[float] = None
    interest_reserve_months: Optional[int] = None
    noi: Optional[float] = Field(None, gt=0)


class BusinessPlanAnalysisRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    property_address: str = Field(..., min_length=5)
    unit_count: int = Field(..., ge=1)
    current_avg_rent: Optional[float] = None
    pro_forma_rent: Optional[float] = None
    renovation_budget: Optional[float] = Field(None, gt=0)
    renovation_per_unit: Optional[float] = None
    lease_up_months: Optional[int] = None
    business_plan_narrative: Optional[str] = None


class DebtSizingPreviewRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    property_address: str = Field(..., min_length=5)
    unit_count: int = Field(..., ge=1)
    asset_value: float = Field(..., gt=0)
    noi: float = Field(..., gt=0)
    total_cost: Optional[float] = Field(None, gt=0)
    loan_purpose: Optional[str] = Field("bridge")


class RenovationROIRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: Optional[str] = None
    property_address: str = Field(..., min_length=5)
    unit_count: int = Field(..., ge=1)
    current_avg_rent: float = Field(...)
    target_rent: Optional[float] = None
    renovation_budget_total: Optional[float] = Field(None, gt=0)
    renovation_per_unit: Optional[float] = Field(None, gt=0)
    scope_description: Optional[str] = None
    hold_period_months: Optional[int] = Field(36)
    asset_class_current: Optional[str] = None
    asset_class_target: Optional[str] = None


# ═══════════════════════════════════════════════════════════════════════════
# Mock response generators
# ═══════════════════════════════════════════════════════════════════════════

def _mock_deal_screen(req: DealScreenRequest) -> dict:
    asset_value = req.asset_value or req.purchase_price or req.loan_amount * 1.4
    # Stabilized value assumes 8% upside from renovations / lease-up
    stabilized_value = asset_value * 1.08
    # Total cost = purchase + estimated capex (~$15K/unit)
    total_cost = asset_value + (req.unit_count * 15000)

    # Derive estimated NOI from cap rate assumption (5.25% stabilized)
    noi_stabilized = stabilized_value * 0.0525
    # Assume IO at 7.50% all-in (SOFR ~4.00% + 350 bps spread)
    annual_debt_service = req.loan_amount * 0.075

    ltv_as_is = round(req.loan_amount / asset_value * 100, 1)
    ltv_stabilized = round(req.loan_amount / stabilized_value * 100, 1)
    dscr_stabilized = round(noi_stabilized / annual_debt_service, 2)
    dy_stabilized = round(noi_stabilized / req.loan_amount * 100, 1)
    ltc = round(req.loan_amount / total_cost * 100, 1)

    # Compute max loan per each constraint
    max_ltv_as_is = asset_value * 0.75
    max_ltv_stab = stabilized_value * 0.75
    max_dscr = noi_stabilized / 1.05 / 0.075
    max_dy = noi_stabilized / 0.07
    max_ltc = total_cost * 0.80
    max_program = 100_000_000

    constraints = {
        "ltv_as_is": {"value": ltv_as_is, "threshold": 75.0, "max_loan": round(max_ltv_as_is, 0)},
        "ltv_stabilized": {"value": ltv_stabilized, "threshold": 75.0, "max_loan": round(max_ltv_stab, 0)},
        "dscr_stabilized": {"value": dscr_stabilized, "threshold": 1.05, "max_loan": round(max_dscr, 0)},
        "debt_yield": {"value": dy_stabilized, "threshold": 7.0, "max_loan": round(max_dy, 0)},
        "ltc": {"value": ltc, "threshold": 80.0, "max_loan": round(max_ltc, 0)},
        "max_loan": {"value": req.loan_amount, "threshold": 100_000_000, "max_loan": 100_000_000},
    }

    # Binding = lowest max_loan
    binding_key = min(constraints, key=lambda k: constraints[k]["max_loan"])
    max_loan = constraints[binding_key]["max_loan"]

    # Status per constraint
    for key, c in constraints.items():
        if key in ("dscr_stabilized",):
            c["status"] = "pass" if c["value"] >= c["threshold"] else "fail"
        elif key in ("debt_yield",):
            c["status"] = "pass" if c["value"] >= c["threshold"] else "fail"
        elif key == "max_loan":
            c["status"] = "pass" if req.loan_amount <= c["threshold"] else "fail"
        else:
            c["status"] = "pass" if c["value"] <= c["threshold"] else "fail"

    all_pass = all(c["status"] == "pass" for c in constraints.values())

    # Flags
    flags = []
    if ltv_as_is > 72.0:
        flags.append({"flag": "ltv_elevated", "detail": f"As-Is LTV at {ltv_as_is:.1f}% approaching 75% ceiling"})
    if dscr_stabilized < 1.15:
        flags.append({"flag": "thin_dscr_cushion", "detail": f"Stabilized DSCR of {dscr_stabilized:.2f}x has limited cushion above 1.05x floor"})
    if req.unit_count < 50:
        flags.append({"flag": "small_asset", "detail": f"{req.unit_count}-unit asset may have limited operational scale"})

    return {
        "status": "pass" if all_pass else "fail",
        "credit_box": {
            "ltv_as_is": {
                "value": ltv_as_is,
                "threshold": 75.0,
                "max_loan": round(max_ltv_as_is, 0),
                "status": constraints["ltv_as_is"]["status"],
                "binding": binding_key == "ltv_as_is",
            },
            "ltv_stabilized": {
                "value": ltv_stabilized,
                "threshold": 75.0,
                "max_loan": round(max_ltv_stab, 0),
                "status": constraints["ltv_stabilized"]["status"],
                "binding": binding_key == "ltv_stabilized",
            },
            "dscr_stabilized": {
                "value": dscr_stabilized,
                "threshold": 1.05,
                "max_loan": round(max_dscr, 0),
                "status": constraints["dscr_stabilized"]["status"],
                "binding": binding_key == "dscr_stabilized",
            },
            "debt_yield": {
                "value": dy_stabilized,
                "threshold": 7.0,
                "max_loan": round(max_dy, 0),
                "status": constraints["debt_yield"]["status"],
                "binding": binding_key == "debt_yield",
            },
            "ltc": {
                "value": ltc,
                "threshold": 80.0,
                "max_loan": round(max_ltc, 0),
                "status": constraints["ltc"]["status"],
                "binding": binding_key == "ltc",
            },
            "max_loan": {
                "value": req.loan_amount,
                "threshold": 100_000_000,
                "max_loan": 100_000_000,
                "status": constraints["max_loan"]["status"],
                "binding": binding_key == "max_loan",
            },
        },
        "binding_constraint": binding_key,
        "property": {
            "address": req.property_address,
            "unit_count": req.unit_count,
            "asset_value": round(asset_value, 0),
            "asset_value_per_unit": round(asset_value / req.unit_count, 0),
            "stabilized_value": round(stabilized_value, 0),
            "stabilized_value_per_unit": round(stabilized_value / req.unit_count, 0),
            "estimated_capex": round(req.unit_count * 15000, 0),
            "total_cost": round(total_cost, 0),
        },
        "loan": {
            "requested_amount": req.loan_amount,
            "requested_per_unit": round(req.loan_amount / req.unit_count, 0),
            "max_from_waterfall": round(max_loan, 0),
            "max_per_unit": round(max_loan / req.unit_count, 0),
            "binding_constraint": binding_key,
            "loan_purpose": req.loan_purpose or "bridge",
            "rate_assumption": "SOFR + 350 bps (7.50% all-in)",
        },
        "key_metrics": {
            "noi_stabilized": round(noi_stabilized, 0),
            "noi_per_unit": round(noi_stabilized / req.unit_count, 0),
            "annual_debt_service": round(annual_debt_service, 0),
            "implied_cap_rate": "5.25%",
            "break_even_occupancy": round((total_cost * 0.035 + annual_debt_service) / (stabilized_value * 0.065) * 100, 1),
        },
        "flags": flags,
        "summary": (
            f"Deal at {req.property_address} ({req.unit_count} units) "
            f"{'meets' if all_pass else 'FAILS'} credit box criteria. "
            f"LTV As-Is {ltv_as_is:.1f}% (limit 75%), LTV Stabilized {ltv_stabilized:.1f}% (limit 75%), "
            f"DSCR {dscr_stabilized:.2f}x (floor 1.05x), Debt Yield {dy_stabilized:.1f}% (floor 7.0%), "
            f"LTC {ltc:.1f}% (limit 80%). "
            f"Binding constraint: {binding_key.replace('_', ' ').upper()} — max loan ${max_loan:,.0f} "
            f"(${round(max_loan / req.unit_count):,}/unit)."
        ),
    }


def _mock_deal_book(req: DealBookRequest) -> dict:
    return {
        "documents_processed": req.document_count or 5,
        "pages_processed": req.document_pages or 42,
        "extracted_data": {
            "property_name": "Subject Property",
            "unit_mix": {
                "studio": 12, "1br": 45, "2br": 38, "3br": 10,
            },
            "financial_summary": {
                "gpr": 3850000, "vacancy": 0.05, "egi": 3657500,
                "opex": 1680000, "noi": 1977500,
            },
            "key_dates": {
                "closing_target": "2026-05-15",
                "rate_lock_expiry": "2026-04-30",
            },
        },
        "deal_book_url": f"/v1/deals/{req.deal_id or 'PF-2026-001'}/deal-book.pdf",
        "summary": "Deal book synthesized from submitted documents. All key data extracted.",
    }


def _mock_sponsor_analysis(req: SponsorAnalysisRequest) -> dict:
    return {
        "sponsor_tier": "A",
        "entity_overview": {
            "name": req.sponsor_name,
            "entity_type": "Delaware LLC",
            "entity_verified": True,
            "years_active": 12,
            "headquarters": "Los Angeles, CA",
            "website": req.sponsor_website or f"www.{req.sponsor_name.lower().replace(' ', '')}.com",
            "principals": [
                {"name": "Managing Partner", "role": "Managing Member / Guarantor", "ownership_pct": 60.0, "years_experience": 18},
                {"name": "Operating Partner", "role": "Operating Member", "ownership_pct": 40.0, "years_experience": 14},
            ],
        },
        "track_record": {
            "total_units_owned": 3200,
            "total_units_managed": 4800,
            "total_deals": 18,
            "total_capitalization": 485_000_000,
            "markets": ["Los Angeles", "Phoenix", "Dallas", "Denver"],
            "asset_classes": ["Multifamily", "Mixed-Use"],
            "avg_deal_size_units": 178,
            "avg_hold_period_months": 42,
            "avg_irr_realized": 18.4,
            "avg_equity_multiple": 2.1,
            "current_portfolio": {
                "properties": 8,
                "units": 1850,
                "total_value": 320_000_000,
                "avg_occupancy": 94.2,
            },
            "realized_exits": {
                "properties": 10,
                "units": 1350,
                "total_proceeds": 285_000_000,
                "avg_exit_cap_rate": 4.85,
            },
        },
        "financial_capacity": {
            "net_worth_sufficient": True,
            "net_worth_to_loan_ratio": 1.8,
            "liquidity_sufficient": True,
            "liquidity_to_loan_ratio": 0.25,
            "guarantor_strength": "strong",
            "recourse_carve_out_exposure": "standard bad-boy guaranty",
            "completion_guaranty_capacity": True,
        },
        "background_check": {
            "litigation": "none",
            "litigation_detail": "No material litigation identified in public records search",
            "bankruptcies": "none",
            "defaults": "none",
            "foreclosures": "none",
            "regulatory_actions": "none",
            "criminal": "none",
            "ofac_check": "clear",
            "credit_report": "satisfactory",
        },
        "operational_capability": {
            "property_management": "in-house",
            "pm_platform_units": 4800,
            "construction_management": True,
            "renovation_experience_units": 2200,
            "avg_renovation_per_unit": 22000,
            "renovation_completion_rate": 0.97,
            "lease_up_track_record": "12-18 month stabilization on value-add deals",
        },
        "risk_flags": [],
        "strengths": [
            "12-year track record with 3,200+ units across 4 gateway/growth markets",
            "Zero defaults, foreclosures, or material litigation",
            "In-house property management with 4,800-unit platform",
            "Demonstrated value-add execution: 2,200 units renovated, 97% on-time completion",
            "Consistent 18%+ IRR on realized exits",
        ],
        "concerns": [
            "Concentration in Sun Belt markets may present correlated risk",
            "Largest single-asset exposure growing relative to portfolio",
        ],
        "recommendation": "proceed",
        "recommendation_detail": (
            f"{req.sponsor_name} is a well-capitalized Tier A operator with 12 years of "
            "institutional multifamily experience across 3,200+ units in 4 markets. "
            "Clean background — no litigation, defaults, or regulatory issues. In-house PM "
            "platform manages 4,800 units. Demonstrated value-add execution with 97% "
            "on-time renovation completion. Financial capacity supports guaranty obligations. "
            "Recommend proceeding to full underwriting."
        ),
    }


def _mock_market_research(req: MarketResearchRequest) -> dict:
    return {
        "msa": {
            "name": "Subject MSA",
            "population": 4_850_000,
            "population_growth_yoy_pct": 1.8,
            "population_growth_5yr_cagr_pct": 1.6,
            "median_household_income": 72_500,
            "median_hhi_growth_yoy_pct": 3.2,
            "cost_of_living_index": 102.4,
            "rent_to_income_ratio_pct": 28.5,
        },
        "employment": {
            "total_employment": 2_340_000,
            "unemployment_rate_pct": 3.8,
            "unemployment_rate_national_pct": 4.1,
            "job_growth_yoy_pct": 2.1,
            "job_growth_5yr_cagr_pct": 2.4,
            "top_employers": [
                {"name": "Regional Health System", "employees": 18_000, "sector": "Healthcare"},
                {"name": "State University", "employees": 12_000, "sector": "Education"},
                {"name": "Tech Corp", "employees": 8_500, "sector": "Technology"},
                {"name": "Defense Contractor Inc", "employees": 6_200, "sector": "Defense/Aerospace"},
                {"name": "Metro Government", "employees": 5_800, "sector": "Government"},
            ],
            "sector_diversification": {
                "healthcare_education_pct": 22.5,
                "professional_services_pct": 18.3,
                "government_pct": 14.7,
                "technology_pct": 12.1,
                "retail_hospitality_pct": 11.8,
                "manufacturing_pct": 8.4,
                "other_pct": 12.2,
            },
            "major_employer_risk": "low — no single employer exceeds 3% of total employment",
        },
        "multifamily_fundamentals": {
            "msa_inventory_units": 185_000,
            "msa_vacancy_rate_pct": 5.8,
            "msa_avg_effective_rent": 1_780,
            "msa_rent_growth_yoy_pct": 2.9,
            "msa_absorption_trailing_12mo": 4_200,
            "msa_concession_pct": 3.5,
        },
        "supply_pipeline": {
            "units_under_construction": 8_400,
            "units_planned_permitted": 4_600,
            "total_pipeline": 13_000,
            "pipeline_as_pct_of_inventory": 7.0,
            "expected_deliveries_next_12mo": 5_200,
            "expected_deliveries_next_24mo": 9_800,
            "historical_avg_annual_deliveries": 4_500,
            "pipeline_vs_historical_ratio": 1.87,
            "peak_delivery_quarter": "Q3 2026",
            "supply_risk_assessment": "Elevated near-term deliveries, but absorption trends supportive. Monitor Q3 2026 peak.",
        },
        "submarket": {
            "name": "Subject Submarket",
            "inventory_units": 42_000,
            "vacancy_rate_pct": 5.2,
            "avg_effective_rent": 1_875,
            "rent_growth_yoy_pct": 3.4,
            "rent_growth_3yr_cagr_pct": 4.1,
            "absorption_trailing_12mo": 1_200,
            "submarket_concession_pct": 2.8,
            "units_under_construction": 3_200,
            "pipeline_as_pct_of_submarket": 7.6,
            "class_b_vacancy_pct": 4.8,
            "class_b_avg_rent": 1_720,
            "class_b_rent_growth_yoy_pct": 3.8,
            "rent_premium_vs_msa_pct": 5.3,
        },
        "demographics": {
            "submarket_population": 285_000,
            "population_growth_yoy_pct": 2.1,
            "median_age": 34.2,
            "renter_pct": 42.5,
            "college_educated_pct": 38.7,
            "median_hhi_submarket": 68_500,
            "poverty_rate_pct": 11.2,
            "housing_cost_burdened_pct": 32.4,
        },
        "risk_factors": [
            {
                "factor": "Supply pipeline elevated",
                "detail": "7.6% of submarket inventory under construction; 1.87x historical average annual deliveries expected over next 24 months",
                "severity": "moderate",
                "mitigant": "Trailing 12-month absorption of 1,200 units demonstrates demand. Submarket vacancy (5.2%) below MSA average (5.8%).",
            },
            {
                "factor": "Rent growth deceleration",
                "detail": "MSA rent growth slowed from 4.8% (2024) to 2.9% (current) as supply delivers",
                "severity": "low",
                "mitigant": "Submarket still outperforming MSA at 3.4% growth. Class B segment growing 3.8% driven by flight-to-value.",
            },
        ],
        "data_sources": [
            "CoStar Group — submarket analytics (accessed current quarter)",
            "U.S. Census Bureau — ACS 5-Year estimates via Valeri Data Services",
            "Bureau of Labor Statistics — employment data via Valeri Data Services",
            "CBRE Research — MSA multifamily market report",
            "RealPage — rent and absorption data",
        ],
        "summary": (
            f"Submarket near {req.property_address} shows healthy fundamentals: "
            "5.2% vacancy (below MSA 5.8%), 3.4% YoY rent growth, and strong employment base "
            "with 2.1% job growth. Sector diversification is favorable — no single employer "
            "exceeds 3% of total employment. Supply pipeline at 7.6% of submarket inventory "
            "warrants monitoring, particularly Q3 2026 peak deliveries, but trailing absorption "
            "of 1,200 units and Class B demand dynamics support near-term performance."
        ),
    }


def _mock_comp_analysis(req: CompAnalysisRequest) -> dict:
    # Derive realistic $/unit from unit count (larger properties = lower $/unit)
    base_value_per_unit = 225_000 if req.unit_count < 100 else (210_000 if req.unit_count < 200 else 195_000)
    base_rent = 1_850 if req.asset_class in ("A", "A-") else (1_720 if req.asset_class == "B" else 1_550)
    implied_value = base_value_per_unit * req.unit_count

    rent_comps = [
        {
            "name": "The Meridian at Westpark",
            "address": "1200 Westpark Dr",
            "distance_miles": 0.6,
            "units": 192,
            "year_built": 2019,
            "asset_class": "A-",
            "avg_unit_sf": 875,
            "avg_rent": round(base_rent * 1.08),
            "avg_rent_per_sf": round(base_rent * 1.08 / 875, 2),
            "occupancy_pct": 94.5,
            "concessions": "None",
            "amenities": "Pool, fitness, coworking, EV charging",
            "renovation_status": "Built new, no renovation",
            "relevance": "Closest new-construction comp; sets rent ceiling for subject post-renovation",
        },
        {
            "name": "Parkview Commons",
            "address": "3450 Oak Valley Blvd",
            "distance_miles": 1.1,
            "units": 228,
            "year_built": 2006,
            "asset_class": "B+",
            "avg_unit_sf": 840,
            "avg_rent": round(base_rent * 0.97),
            "avg_rent_per_sf": round(base_rent * 0.97 / 840, 2),
            "occupancy_pct": 96.0,
            "concessions": "None",
            "amenities": "Pool, fitness, business center",
            "renovation_status": "Interior renovations completed 2023 ($18K/unit)",
            "relevance": "Best comp for subject post-renovation — similar vintage, recently upgraded",
        },
        {
            "name": "Avalon Ridge",
            "address": "780 Commerce Pkwy",
            "distance_miles": 1.4,
            "units": 156,
            "year_built": 2013,
            "asset_class": "B+",
            "avg_unit_sf": 860,
            "avg_rent": round(base_rent * 1.02),
            "avg_rent_per_sf": round(base_rent * 1.02 / 860, 2),
            "occupancy_pct": 95.2,
            "concessions": "Occasional 1-month free on 14-month lease",
            "amenities": "Pool, fitness, dog park, package lockers",
            "renovation_status": "Partial renovation (60% of units)",
            "relevance": "Mid-range comp; partially renovated with achievable rents for subject",
        },
        {
            "name": "Canyon Creek Apartments",
            "address": "5100 Riverside Ave",
            "distance_miles": 2.0,
            "units": 304,
            "year_built": 1999,
            "asset_class": "B",
            "avg_unit_sf": 910,
            "avg_rent": round(base_rent * 0.90),
            "avg_rent_per_sf": round(base_rent * 0.90 / 910, 2),
            "occupancy_pct": 93.8,
            "concessions": "$500 off first month",
            "amenities": "Pool, laundry facility, covered parking",
            "renovation_status": "Unrenovated — original condition",
            "relevance": "Floor comp; represents subject in unrenovated state",
        },
        {
            "name": "The Hudson Lofts",
            "address": "920 Industrial Blvd",
            "distance_miles": 2.3,
            "units": 168,
            "year_built": 2021,
            "asset_class": "A",
            "avg_unit_sf": 820,
            "avg_rent": round(base_rent * 1.15),
            "avg_rent_per_sf": round(base_rent * 1.15 / 820, 2),
            "occupancy_pct": 92.8,
            "concessions": "6 weeks free on 18-month lease",
            "amenities": "Rooftop deck, pool, fitness, coworking, smart home",
            "renovation_status": "Built new, no renovation",
            "relevance": "New Class A comp; showing concession pressure — rent ceiling reference only",
        },
    ]

    concluded_rent = round(sum(c["avg_rent"] for c in rent_comps) / len(rent_comps))
    avg_occupancy = round(sum(c["occupancy_pct"] for c in rent_comps) / len(rent_comps), 1)

    sales_comps = [
        {
            "name": "Brookstone at Maple Grove",
            "address": "2200 Maple Grove Dr",
            "sale_date": "2025-09-15",
            "buyer": "Institutional PE (Fund VII)",
            "seller": "Regional operator",
            "units": 208,
            "year_built": 2008,
            "price": 43_680_000,
            "price_per_unit": 210_000,
            "cap_rate_pct": 5.25,
            "occupancy_at_sale_pct": 94.0,
            "renovation_status": "Partially renovated (40%)",
            "days_on_market": 62,
            "financing": "Agency (Freddie Mac)",
            "relevance": "Closest trade comp in size and vintage; validates $/unit range",
        },
        {
            "name": "Silverleaf Residences",
            "address": "4800 Elm Street",
            "sale_date": "2025-06-22",
            "buyer": "Private equity sponsor",
            "seller": "1031 exchange seller",
            "units": 175,
            "year_built": 2003,
            "price": 35_700_000,
            "price_per_unit": 204_000,
            "cap_rate_pct": 5.50,
            "occupancy_at_sale_pct": 92.5,
            "renovation_status": "Unrenovated — value-add play",
            "days_on_market": 88,
            "financing": "Bridge (SOFR + 375)",
            "relevance": "Value-add basis comp; validates going-in pricing for unrenovated stock",
        },
        {
            "name": "The Lexington Park",
            "address": "1050 University Pkwy",
            "sale_date": "2025-11-01",
            "buyer": "REIT subsidiary",
            "seller": "Development JV",
            "units": 310,
            "year_built": 2020,
            "price": 68_200_000,
            "price_per_unit": 220_000,
            "cap_rate_pct": 4.90,
            "occupancy_at_sale_pct": 96.0,
            "renovation_status": "New construction — no renovation needed",
            "days_on_market": 45,
            "financing": "Agency (Fannie Mae)",
            "relevance": "Ceiling comp; new construction with stabilized cash flow commands tighter cap",
        },
    ]

    avg_sale_price_per_unit = round(sum(c["price_per_unit"] for c in sales_comps) / len(sales_comps))
    avg_cap_rate = round(sum(c["cap_rate_pct"] for c in sales_comps) / len(sales_comps), 2)

    # Broker variance (assume broker claims 5% higher rents and 25 bps tighter cap)
    broker_assumed_rent = round(concluded_rent * 1.05)
    broker_assumed_cap = round(avg_cap_rate - 0.25, 2)

    return {
        "rent_comps": rent_comps,
        "rent_comp_summary": {
            "count": len(rent_comps),
            "avg_rent": concluded_rent,
            "rent_range_low": min(c["avg_rent"] for c in rent_comps),
            "rent_range_high": max(c["avg_rent"] for c in rent_comps),
            "avg_occupancy_pct": avg_occupancy,
            "avg_year_built": round(sum(c["year_built"] for c in rent_comps) / len(rent_comps)),
            "avg_distance_miles": round(sum(c["distance_miles"] for c in rent_comps) / len(rent_comps), 1),
        },
        "sales_comps": sales_comps,
        "sales_comp_summary": {
            "count": len(sales_comps),
            "avg_price_per_unit": avg_sale_price_per_unit,
            "price_range_low_per_unit": min(c["price_per_unit"] for c in sales_comps),
            "price_range_high_per_unit": max(c["price_per_unit"] for c in sales_comps),
            "avg_cap_rate_pct": avg_cap_rate,
            "cap_rate_range_low_pct": min(c["cap_rate_pct"] for c in sales_comps),
            "cap_rate_range_high_pct": max(c["cap_rate_pct"] for c in sales_comps),
            "total_volume": sum(c["price"] for c in sales_comps),
        },
        "derived_values": {
            "concluded_market_rent_per_unit": concluded_rent,
            "concluded_stabilized_cap_rate_pct": avg_cap_rate,
            "concluded_value_per_unit": avg_sale_price_per_unit,
            "implied_stabilized_value": round(avg_sale_price_per_unit * req.unit_count, 0),
            "implied_stabilized_value_per_unit": avg_sale_price_per_unit,
        },
        "variance_vs_broker": {
            "broker_rent_assumption": broker_assumed_rent,
            "lender_concluded_rent": concluded_rent,
            "rent_variance_pct": round((broker_assumed_rent - concluded_rent) / concluded_rent * 100, 1),
            "rent_variance_flag": "Broker rent 5% above lender conclusion — moderate variance",
            "broker_cap_rate_assumption_pct": broker_assumed_cap,
            "lender_concluded_cap_rate_pct": avg_cap_rate,
            "cap_rate_variance_bps": round((avg_cap_rate - broker_assumed_cap) * 100),
            "cap_rate_variance_flag": "Broker assumes 25 bps tighter cap rate — lender applies market-supported rate",
        },
        "data_sources": [
            "CoStar Group — rent and sales comp data",
            "RealPage — rent survey and concession tracking",
            "Yardi Matrix — property-level operating data",
            "County Assessor/Recorder — sale verification and deed records",
        ],
        "summary": (
            f"Analysis of 5 rent comps and 3 sale comps near {req.property_address} "
            f"supports a lender-concluded market rent of ${concluded_rent:,}/unit (vs. broker "
            f"assumption of ${broker_assumed_rent:,}/unit, +5.0% variance) and stabilized "
            f"cap rate of {avg_cap_rate:.2f}% (vs. broker {broker_assumed_cap:.2f}%). "
            f"Concluded value: ~${req.unit_count * avg_sale_price_per_unit:,.0f} "
            f"(${avg_sale_price_per_unit:,}/unit) based on {len(sales_comps)} recent "
            f"transactions averaging ${avg_sale_price_per_unit:,}/unit."
        ),
    }


def _mock_rent_roll(req: RentRollRequest) -> dict:
    return {
        "summary": {
            "total_units": req.unit_count or 165,
            "occupied_units": int((req.unit_count or 165) * 0.93),
            "occupancy_rate": 93.0,
            "avg_in_place_rent": 1720,
            "market_rent": req.market_rent_estimate or 1850,
            "loss_to_lease_pct": 7.0,
        },
        "unit_mix": [
            {"type": "Studio", "count": 15, "avg_sf": 480, "avg_rent": 1350, "market_rent": 1450},
            {"type": "1BR/1BA", "count": 65, "avg_sf": 680, "avg_rent": 1650, "market_rent": 1800},
            {"type": "2BR/1BA", "count": 50, "avg_sf": 920, "avg_rent": 1900, "market_rent": 2050},
            {"type": "2BR/2BA", "count": 25, "avg_sf": 1050, "avg_rent": 2100, "market_rent": 2250},
            {"type": "3BR/2BA", "count": 10, "avg_sf": 1200, "avg_rent": 2350, "market_rent": 2500},
        ],
        "anomalies": [
            {"type": "below_market", "unit": "Unit 204", "rent": 1200, "market": 1800, "note": "Long-term tenant, 33% below market"},
            {"type": "concession", "unit": "Unit 312", "rent": 1650, "concession": "1 month free on 14-month lease"},
        ],
        "concessions": {
            "units_with_concessions": 8,
            "avg_concession_value": 145,
            "total_concession_cost_annual": 13920,
        },
    }


def _mock_cash_flow(req: CashFlowRequest) -> dict:
    units = req.unit_count
    avg_rent = req.pro_forma_rents or 1850
    projection_years = req.projection_years or 5

    # ---- Lender Underwrite (conservative) ----
    gpr_lender = units * avg_rent * 12
    other_income_lender = round(units * 65 * 12)  # $65/unit/month (parking, laundry, fees)
    vacancy_pct_lender = 5.0
    vacancy_loss_lender = round(gpr_lender * 0.05)
    concessions_lender = round(gpr_lender * 0.015)
    bad_debt_lender = round(gpr_lender * 0.01)
    egi_lender = gpr_lender - vacancy_loss_lender - concessions_lender - bad_debt_lender + other_income_lender

    # OpEx breakdown (lender uses 42% expense ratio)
    total_opex_lender = round(egi_lender * 0.42)
    opex_breakdown = {
        "real_estate_taxes": round(total_opex_lender * 0.28),
        "insurance": round(total_opex_lender * 0.10),
        "utilities": round(total_opex_lender * 0.12),
        "repairs_maintenance": round(total_opex_lender * 0.14),
        "payroll": round(total_opex_lender * 0.18),
        "management_fee": round(egi_lender * 0.04),
        "general_admin": round(total_opex_lender * 0.06),
        "marketing": round(total_opex_lender * 0.03),
        "reserves_replacement": round(units * 300),
    }
    # Recalc total from components to avoid rounding drift
    total_opex_lender = sum(opex_breakdown.values())

    noi_lender = egi_lender - total_opex_lender

    # ---- Sponsor Proforma (aggressive) ----
    gpr_sponsor = round(gpr_lender * 1.08)  # 8% higher rents
    other_income_sponsor = round(units * 85 * 12)  # Higher ancillary income
    vacancy_pct_sponsor = 4.0
    vacancy_loss_sponsor = round(gpr_sponsor * 0.04)
    concessions_sponsor = round(gpr_sponsor * 0.005)
    bad_debt_sponsor = round(gpr_sponsor * 0.005)
    egi_sponsor = gpr_sponsor - vacancy_loss_sponsor - concessions_sponsor - bad_debt_sponsor + other_income_sponsor
    total_opex_sponsor = round(egi_sponsor * 0.38)  # 38% expense ratio
    noi_sponsor = egi_sponsor - total_opex_sponsor

    # Variance
    noi_variance_pct = round((noi_lender - noi_sponsor) / noi_sponsor * 100, 1)

    # ---- Projections (lender base, 3% rent growth, 2.5% expense growth) ----
    projections = []
    for y in range(1, projection_years + 1):
        yr_rent_growth = 1.03 ** (y - 1)
        yr_exp_growth = 1.025 ** (y - 1)
        yr_gpr = round(gpr_lender * yr_rent_growth)
        yr_other = round(other_income_lender * yr_rent_growth)
        yr_vacancy = round(yr_gpr * 0.05)
        yr_concessions = round(yr_gpr * max(0.015 - (y * 0.002), 0.005))  # Concessions burn off
        yr_bad_debt = round(yr_gpr * 0.01)
        yr_egi = yr_gpr - yr_vacancy - yr_concessions - yr_bad_debt + yr_other
        yr_opex = round(total_opex_lender * yr_exp_growth)
        yr_noi = yr_egi - yr_opex
        projections.append({
            "year": y,
            "gpr": yr_gpr,
            "other_income": yr_other,
            "vacancy_loss": yr_vacancy,
            "egi": yr_egi,
            "total_opex": yr_opex,
            "noi": yr_noi,
            "noi_per_unit": round(yr_noi / units),
            "noi_growth_pct": round((yr_noi / noi_lender - 1) * 100, 1) if y > 1 else 0.0,
            "opex_ratio_pct": round(yr_opex / yr_egi * 100, 1),
        })

    return {
        "income": {
            "gross_potential_rent": gpr_lender,
            "gpr_per_unit_monthly": avg_rent,
            "other_income": other_income_lender,
            "other_income_per_unit_monthly": 65,
            "gross_potential_income": gpr_lender + other_income_lender,
            "vacancy_loss": vacancy_loss_lender,
            "vacancy_pct": vacancy_pct_lender,
            "concessions": concessions_lender,
            "bad_debt": bad_debt_lender,
            "effective_gross_income": egi_lender,
            "egi_per_unit": round(egi_lender / units),
        },
        "expenses": {
            "total_operating_expenses": total_opex_lender,
            "opex_per_unit": round(total_opex_lender / units),
            "opex_ratio_pct": round(total_opex_lender / egi_lender * 100, 1),
            "breakdown": opex_breakdown,
        },
        "noi": {
            "stabilized_noi": noi_lender,
            "noi_per_unit": round(noi_lender / units),
            "in_place_noi": round(noi_lender * 0.88),
            "in_place_noi_per_unit": round(noi_lender * 0.88 / units),
        },
        "dual_scenario": {
            "lender_underwrite": {
                "gpr": gpr_lender,
                "vacancy_pct": vacancy_pct_lender,
                "egi": egi_lender,
                "opex": total_opex_lender,
                "opex_ratio_pct": round(total_opex_lender / egi_lender * 100, 1),
                "noi": noi_lender,
                "noi_per_unit": round(noi_lender / units),
            },
            "sponsor_proforma": {
                "gpr": gpr_sponsor,
                "vacancy_pct": vacancy_pct_sponsor,
                "egi": egi_sponsor,
                "opex": total_opex_sponsor,
                "opex_ratio_pct": round(total_opex_sponsor / egi_sponsor * 100, 1),
                "noi": noi_sponsor,
                "noi_per_unit": round(noi_sponsor / units),
            },
            "variance": {
                "gpr_variance_pct": round((gpr_lender - gpr_sponsor) / gpr_sponsor * 100, 1),
                "egi_variance_pct": round((egi_lender - egi_sponsor) / egi_sponsor * 100, 1),
                "opex_variance_pct": round((total_opex_lender - total_opex_sponsor) / total_opex_sponsor * 100, 1),
                "noi_variance_pct": noi_variance_pct,
                "noi_variance_dollars": noi_lender - noi_sponsor,
                "primary_drivers": [
                    f"Rent assumption: Lender ${avg_rent:,}/unit vs. Sponsor ${round(avg_rent * 1.08):,}/unit (-7.4%)",
                    f"Vacancy: Lender {vacancy_pct_lender}% vs. Sponsor {vacancy_pct_sponsor}% (+100 bps)",
                    f"Expense ratio: Lender 42% vs. Sponsor 38% (+400 bps)",
                ],
            },
        },
        "projections": projections,
        "assumptions": {
            "rent_growth_pct": 3.0,
            "expense_growth_pct": 2.5,
            "stabilized_vacancy_pct": 5.0,
            "management_fee_pct": 4.0,
            "replacement_reserves_per_unit": 300,
            "concession_burn_off": "1.5% Y1, declining 20 bps/year to 0.5% floor",
        },
        "summary": (
            f"Lender underwrites stabilized NOI of ${noi_lender:,.0f} "
            f"(${round(noi_lender / units):,}/unit) at {round(total_opex_lender / egi_lender * 100, 1)}% "
            f"expense ratio and {vacancy_pct_lender}% vacancy. "
            f"Lender NOI is {abs(noi_variance_pct)}% below sponsor proforma NOI of "
            f"${noi_sponsor:,.0f} — driven by higher vacancy (+100 bps), lower rent "
            f"assumptions (-7.4%), and higher expense ratio (+400 bps)."
        ),
    }


def _mock_loan_sizer(req: LoanSizerRequest) -> dict:
    stabilized_value = req.asset_value * 1.08
    # Total cost = asset + estimated capex (derived from value)
    estimated_capex = req.asset_value * 0.05
    total_cost = req.asset_value + estimated_capex
    all_in_rate = 0.075  # SOFR ~4.00% + 350 bps
    annual_ds = req.loan_amount_requested * all_in_rate

    # Max loan per constraint
    max_ltv_as_is = req.asset_value * 0.75
    max_ltv_stab = stabilized_value * 0.75
    max_dscr = req.noi / 1.05 / all_in_rate
    max_dy = req.noi / 0.07
    max_ltc = total_cost * 0.80
    max_program = 100_000_000

    waterfall = {
        "ltv_as_is": {
            "max_loan": round(max_ltv_as_is, 0),
            "metric_at_max": 75.0,
            "metric_at_request": round(req.loan_amount_requested / req.asset_value * 100, 1),
            "threshold": "75.0% (ceiling)",
            "unit": "%",
            "formula": f"${req.loan_amount_requested:,.0f} / ${req.asset_value:,.0f} = {round(req.loan_amount_requested / req.asset_value * 100, 1)}%",
            "binding": False,
        },
        "ltv_stabilized": {
            "max_loan": round(max_ltv_stab, 0),
            "metric_at_max": 75.0,
            "metric_at_request": round(req.loan_amount_requested / stabilized_value * 100, 1),
            "threshold": "75.0% (ceiling)",
            "unit": "%",
            "formula": f"${req.loan_amount_requested:,.0f} / ${stabilized_value:,.0f} = {round(req.loan_amount_requested / stabilized_value * 100, 1)}%",
            "binding": False,
        },
        "dscr_stabilized": {
            "max_loan": round(max_dscr, 0),
            "metric_at_max": 1.05,
            "metric_at_request": round(req.noi / annual_ds, 2),
            "threshold": "1.05x (floor)",
            "unit": "x",
            "formula": f"NOI ${req.noi:,.0f} / DS ${annual_ds:,.0f} = {round(req.noi / annual_ds, 2):.2f}x",
            "binding": False,
        },
        "debt_yield": {
            "max_loan": round(max_dy, 0),
            "metric_at_max": 7.0,
            "metric_at_request": round(req.noi / req.loan_amount_requested * 100, 1),
            "threshold": "7.0% (floor)",
            "unit": "%",
            "formula": f"NOI ${req.noi:,.0f} / Loan ${req.loan_amount_requested:,.0f} = {round(req.noi / req.loan_amount_requested * 100, 1)}%",
            "binding": False,
        },
        "ltc": {
            "max_loan": round(max_ltc, 0),
            "metric_at_max": 80.0,
            "metric_at_request": round(req.loan_amount_requested / total_cost * 100, 1),
            "threshold": "80.0% (ceiling)",
            "unit": "%",
            "formula": f"${req.loan_amount_requested:,.0f} / ${total_cost:,.0f} = {round(req.loan_amount_requested / total_cost * 100, 1)}%",
            "binding": False,
        },
        "program_cap": {
            "max_loan": max_program,
            "metric_at_max": 100_000_000,
            "metric_at_request": req.loan_amount_requested,
            "threshold": "$100,000,000 (ceiling)",
            "unit": "$",
            "formula": f"${req.loan_amount_requested:,.0f} vs. $100,000,000 cap",
            "binding": False,
        },
    }

    # Find binding constraint
    binding_key = min(waterfall, key=lambda k: waterfall[k]["max_loan"])
    max_loan = waterfall[binding_key]["max_loan"]
    waterfall[binding_key]["binding"] = True

    recommended_loan = round(min(max_loan, req.loan_amount_requested), 0)
    request_within_sizing = req.loan_amount_requested <= max_loan

    return {
        "sizing_waterfall": waterfall,
        "recommended_loan": recommended_loan,
        "max_loan_from_waterfall": round(max_loan, 0),
        "binding_constraint": binding_key,
        "key_metrics": {
            "dscr_at_recommended": round(req.noi / (recommended_loan * all_in_rate), 2),
            "debt_yield_at_recommended_pct": round(req.noi / recommended_loan * 100, 1),
            "ltv_as_is_at_recommended_pct": round(recommended_loan / req.asset_value * 100, 1),
            "ltv_stabilized_at_recommended_pct": round(recommended_loan / stabilized_value * 100, 1),
            "ltc_at_recommended_pct": round(recommended_loan / total_cost * 100, 1),
        },
        "comparison_to_request": {
            "requested": req.loan_amount_requested,
            "recommended": recommended_loan,
            "difference": round(recommended_loan - req.loan_amount_requested, 0),
            "difference_pct": round((recommended_loan - req.loan_amount_requested) / req.loan_amount_requested * 100, 1),
            "request_within_sizing": request_within_sizing,
            "action": "Approve as requested" if request_within_sizing else f"Size down to ${recommended_loan:,.0f}",
        },
        "rate_assumption": {
            "index": "SOFR",
            "index_rate_pct": 4.00,
            "spread_bps": 350,
            "all_in_rate_pct": 7.50,
            "rate_type": req.rate_type or "floating",
            "interest_only": True,
            "rate_source": "Federal Reserve (FRED) via Valeri Data Services",
        },
        "term": {
            "initial_months": req.term_months or 36,
            "extension_options": "1+1 (two 1-year options)",
            "structure": f"{(req.term_months or 36) // 12}+1+1",
            "extension_test": "1.05x DSCR at extension",
            "prepayment": "Open after 12 months; 1.0% in months 1-12",
            "exit_fee_pct": 0.50,
        },
        "sensitivity": {
            "rate_stress_plus_100bps": {
                "all_in_rate_pct": 8.50,
                "dscr": round(req.noi / (recommended_loan * 0.085), 2),
                "note": "DSCR under +100 bps rate stress",
            },
            "noi_stress_minus_10pct": {
                "stressed_noi": round(req.noi * 0.90),
                "dscr": round(req.noi * 0.90 / (recommended_loan * all_in_rate), 2),
                "debt_yield_pct": round(req.noi * 0.90 / recommended_loan * 100, 1),
                "note": "Key metrics under -10% NOI stress",
            },
        },
        "summary": (
            f"6-constraint waterfall sizes max loan at ${max_loan:,.0f}, "
            f"constrained by {binding_key.replace('_', ' ').upper()}. "
            f"Sponsor request of ${req.loan_amount_requested:,.0f} is "
            f"{'within sizing limits — approve as requested' if request_within_sizing else f'above max — recommend ${recommended_loan:,.0f}'}. "
            f"At recommended loan: DSCR {round(req.noi / (recommended_loan * all_in_rate), 2):.2f}x, "
            f"DY {round(req.noi / recommended_loan * 100, 1)}%, "
            f"LTV {round(recommended_loan / req.asset_value * 100, 1)}%."
        ),
    }


def _mock_term_sheet(req: TermSheetRequest) -> dict:
    return {
        "deal_id": req.deal_id,
        "term_sheet": {
            "borrower": "Subject Sponsor LLC",
            "property": "Subject Property",
            "loan_amount": 42000000,
            "loan_type": "First Mortgage Bridge Loan",
            "term": "3+1+1 (36 months initial, two 1-year extension options)",
            "interest_rate": "SOFR + 3.50% (7.50% all-in at current SOFR)",
            "interest_only": True,
            "ltv": "72.4%",
            "dscr_covenant": "1.05x (extension test)",
            "exit_fee": "0.50% of original loan balance",
            "prepayment": "Open after 12 months, 1% in months 1-12",
            "reserves": {
                "tax_escrow": "Monthly 1/12 of annual taxes",
                "insurance_escrow": "Monthly 1/12 of annual premiums",
                "capex_reserve": "$250/unit at closing",
                "operating_reserve": "None",
            },
            "recourse": "25% partial recourse, burning down to non-recourse at 1.10x DSCR",
            "guaranty": "Standard bad-boy carve-outs",
        },
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


def _mock_short_form_memo(req: ShortFormMemoRequest) -> dict:
    return {
        "deal_id": req.deal_id,
        "memo": {
            "property": "Subject Property — 165 Units",
            "address": "123 Main Street, City, ST 12345",
            "sponsor": "Subject Sponsor LLC",
            "loan_amount": "$42.0M ($254,545/unit)",
            "loan_purpose": "Acquisition / Bridge",
            "credit_metrics": {
                "ltv_as_is": {"value": "72.4%", "status": "pass"},
                "dscr_stabilized": {"value": "1.18x", "status": "pass"},
                "debt_yield": {"value": "7.8%", "status": "pass"},
                "ltc": {"value": "68.9%", "status": "pass"},
                "break_even": {"value": "87.2%", "status": "pass"},
            },
            "strengths": [
                "Experienced sponsor with 3,200+ unit track record",
                "Below-replacement-cost basis at $254,545/unit",
                "7.0% loss-to-lease provides organic rent growth upside",
            ],
            "risks": [
                "Supply pipeline at 7.6% of submarket inventory",
                "Execution risk on $4.5M renovation program",
            ],
            "recommendation": "APPROVE — recommend proceeding to full underwriting",
        },
        "format": "2-page institutional memo",
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


def _mock_nuance_gate(req: NuanceGateRequest) -> dict:
    return {
        "deal_id": req.deal_id,
        "nuance_flags": {
            "affordable": {"detected": False},
            "rent_control": {"detected": False},
            "ground_lease": {"detected": False},
            "tax_abatement": {"detected": False},
            "environmental": {"detected": False, "flood_zone": "X", "phase_i_required": True},
            "seismic": {"detected": False},
            "complex_ownership": {"detected": False},
        },
        "gate_keeping_issues": [],
        "contained_issues": [
            {
                "type": "environmental",
                "item": "Phase I ESA required — standard for acquisition",
                "impact": "Standard closing condition, no deal impact expected",
            },
        ],
        "recommendation": "PROCEED — no gate-keeping nuance issues identified",
        "summary": (
            "Standard deal with no gate-keeping nuance flags. "
            "Phase I ESA required as standard closing condition. "
            "Not in flood zone, no rent control, no affordable restrictions."
        ),
    }


def _mock_ic_memo(req: ICMemoRequest) -> dict:
    return {
        "deal_id": req.deal_id,
        "memo_format": req.memo_format,
        "sections": [
            "Executive Summary",
            "Transaction Overview",
            "Sponsor Analysis",
            "Market & Submarket",
            "Comparable Analysis",
            "Property Analysis",
            "Cash Flow Underwriting",
            "Loan Sizing & Structure",
            "Risk Assessment",
            "Recommendation",
        ],
        "recommendation": {
            "decision": "APPROVE",
            "loan_amount": 42000000,
            "conditions": [
                "Phase I ESA — clean or standard no further action",
                "Title clear of material encumbrances",
                "Final appraisal within 5% of underwritten value",
                "Rate cap for initial term at 3% strike",
            ],
        },
        "document_url": f"/v1/deals/{req.deal_id}/ic-memo.docx",
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


def _mock_quick_review(req: QuickReviewRequest) -> dict:
    asset_value = req.asset_value or req.purchase_price or req.loan_amount * 1.4
    stabilized_value = asset_value * 1.08
    total_cost = asset_value + (req.unit_count * 15000)
    noi_est = req.current_noi or (stabilized_value * 0.0525)
    all_in_rate = 0.075
    annual_ds = req.loan_amount * all_in_rate

    ltv_as_is = round(req.loan_amount / asset_value * 100, 1)
    ltv_stab = round(req.loan_amount / stabilized_value * 100, 1)
    dscr_est = round(noi_est / annual_ds, 2)
    dy_est = round(noi_est / req.loan_amount * 100, 1)
    ltc = round(req.loan_amount / total_cost * 100, 1)
    break_even = round((total_cost * 0.035 + annual_ds) / (stabilized_value * 0.065) * 100, 1)

    # Max loan per constraint
    max_ltv = asset_value * 0.75
    max_dscr = noi_est / 1.05 / all_in_rate
    max_dy = noi_est / 0.07
    max_ltc = total_cost * 0.80
    max_loan = round(min(max_ltv, max_dscr, max_dy, max_ltc, 100_000_000), 0)

    # Determine binding
    constraint_loans = {"ltv_as_is": max_ltv, "dscr_stabilized": max_dscr, "debt_yield": max_dy, "ltc": max_ltc}
    binding = min(constraint_loans, key=constraint_loans.get)

    all_pass = ltv_as_is <= 75.0 and dscr_est >= 1.05 and dy_est >= 7.0 and ltc <= 80.0
    screen_result = "PASS" if all_pass else ("CONDITIONAL" if ltv_as_is <= 75.0 else "FAIL")

    return {
        "screen_result": screen_result,
        "deal_id": f"PF-2026-{random.randint(100, 999)}",
        "property": {
            "address": req.property_address,
            "unit_count": req.unit_count,
            "asset_value": round(asset_value, 0),
            "asset_value_per_unit": round(asset_value / req.unit_count, 0),
            "stabilized_value": round(stabilized_value, 0),
            "loan_purpose": req.loan_purpose or "bridge",
        },
        "key_metrics": {
            "ltv_as_is": {"value": ltv_as_is, "threshold": 75.0, "status": "pass" if ltv_as_is <= 75.0 else "fail"},
            "ltv_stabilized": {"value": ltv_stab, "threshold": 75.0, "status": "pass" if ltv_stab <= 75.0 else "fail"},
            "dscr_stabilized": {"value": dscr_est, "threshold": 1.05, "status": "pass" if dscr_est >= 1.05 else "fail"},
            "debt_yield": {"value": dy_est, "threshold": 7.0, "status": "pass" if dy_est >= 7.0 else "fail"},
            "ltc": {"value": ltc, "threshold": 80.0, "status": "pass" if ltc <= 80.0 else "fail"},
            "break_even_occupancy_pct": break_even,
            "noi_stabilized": round(noi_est, 0),
            "noi_per_unit": round(noi_est / req.unit_count, 0),
        },
        "sizing": {
            "max_loan_from_waterfall": max_loan,
            "binding_constraint": binding,
            "loan_requested": req.loan_amount,
            "loan_per_unit": round(req.loan_amount / req.unit_count, 0),
            "request_within_sizing": req.loan_amount <= max_loan,
            "rate_assumption": "SOFR + 350 bps (7.50% all-in)",
        },
        "sponsor_assessment": {
            "name": req.sponsor_name,
            "tier": "A",
            "track_record_units": 3200,
            "years_active": 12,
            "defaults": 0,
            "recommendation": "proceed",
        },
        "market_snapshot": {
            "submarket_vacancy_pct": 5.2,
            "submarket_rent_growth_yoy_pct": 3.4,
            "submarket_avg_rent": 1875,
            "msa_job_growth_yoy_pct": 2.1,
            "msa_unemployment_rate_pct": 3.8,
            "supply_pipeline_pct_of_inventory": 7.6,
        },
        "strengths": [
            f"Experienced Tier A sponsor ({req.sponsor_name}) — 12-year track record, 3,200+ units, zero defaults",
            f"Basis at ${round(req.loan_amount / req.unit_count):,}/unit below estimated replacement cost of ~${round(asset_value * 1.3 / req.unit_count):,}/unit",
            f"DSCR cushion: {dscr_est:.2f}x vs. 1.05x floor provides {round((dscr_est - 1.05) / 1.05 * 100)}% buffer",
            "Healthy submarket fundamentals — 5.2% vacancy, 3.4% rent growth, diversified employment base",
            "Value-add upside: 7-8% estimated loss-to-lease provides organic rent growth runway",
        ],
        "risks": [
            {
                "risk": "Elevated supply pipeline",
                "detail": "7.6% of submarket inventory under construction; peak deliveries expected Q3 2026",
                "severity": "moderate",
                "mitigant": "Trailing absorption of 1,200 units/year supports demand; subject positioned in Class B segment with flight-to-value tailwind",
            },
            {
                "risk": "Value-add execution",
                "detail": f"Renovation program of ~${round(req.unit_count * 15000):,} (${15000:,}/unit) requires disciplined execution",
                "severity": "moderate",
                "mitigant": "Sponsor has renovated 2,200 units with 97% on-time completion rate",
            },
            {
                "risk": "Rate environment",
                "detail": "Floating-rate exposure at SOFR + 350 bps; +100 bps stress reduces DSCR to " + f"{round(noi_est / (req.loan_amount * 0.085), 2):.2f}x",
                "severity": "low",
                "mitigant": "Rate cap required for initial term; even stressed DSCR remains above 1.05x floor",
            },
        ],
        "dd_questions": [
            "Confirm renovation scope, timeline, and per-unit budget with contractor bids",
            "Verify sponsor liquidity and net worth per guaranty requirements",
            "Obtain Phase I ESA — standard closing condition for acquisition",
            "Review T-12 operating statements for expense benchmarking against lender assumptions",
            "Confirm in-place rent roll against broker representations",
        ],
        "recommendation": f"{'APPROVE' if all_pass else 'CONDITIONAL APPROVAL'} — recommend proceeding to full underwriting",
        "recommendation_detail": (
            f"{req.unit_count}-unit {'acquisition' if (req.loan_purpose or 'bridge') == 'bridge' else req.loan_purpose} "
            f"at {req.property_address} for ${req.loan_amount:,.0f} ({ltv_as_is:.1f}% LTV). "
            f"All credit box constraints satisfied. Tier A sponsor with proven value-add execution. "
            f"Binding constraint: {binding.replace('_', ' ').upper()} — max loan ${max_loan:,.0f}. "
            f"Proceed to full underwriting with standard due diligence conditions."
        ),
        "memo_url": f"/v1/deals/PF-2026-{random.randint(100,999)}/quick-review.docx",
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


def _mock_full_workflow(req: FullWorkflowRequest) -> dict:
    return {
        "phases_completed": list(range(1, 16)),
        "total_phases": 15,
        "status": "complete",
        "deliverables": [
            {"document": "Sponsor Analysis", "pages": 32, "url": f"/v1/deals/{req.deal_id or 'PF-2026-001'}/sponsor-analysis.docx"},
            {"document": "Market Analysis", "pages": 35, "url": f"/v1/deals/{req.deal_id or 'PF-2026-001'}/market-analysis.docx"},
            {"document": "Comparable Analysis", "pages": 30, "url": f"/v1/deals/{req.deal_id or 'PF-2026-001'}/comp-analysis.docx"},
            {"document": "Rent Roll Analysis", "pages": 18, "url": f"/v1/deals/{req.deal_id or 'PF-2026-001'}/rent-roll.docx"},
            {"document": "T-12 / Expense Analysis", "pages": 16, "url": f"/v1/deals/{req.deal_id or 'PF-2026-001'}/t12-expense.docx"},
            {"document": "Cash Flow Underwriting", "pages": 34, "url": f"/v1/deals/{req.deal_id or 'PF-2026-001'}/cash-flow-uw.docx"},
            {"document": "Business Plan Analysis", "pages": 12, "url": f"/v1/deals/{req.deal_id or 'PF-2026-001'}/business-plan.docx"},
            {"document": "IC Memo", "pages": 22, "url": f"/v1/deals/{req.deal_id or 'PF-2026-001'}/ic-memo.docx"},
        ],
        "recommendation": "APPROVE",
        "summary": (
            f"Full 15-phase underwriting complete for {req.property_address} ({req.unit_count} units). "
            f"Loan request ${req.loan_amount:,.0f}. All credit box constraints satisfied. "
            f"Sponsor {req.sponsor_name} rated Tier A. Recommend approval."
        ),
    }


# ═══════════════════════════════════════════════════════════════════════════
# Endpoints
# ═══════════════════════════════════════════════════════════════════════════

@router.post("/screen")
async def deal_screen(req: DealScreenRequest, account=Depends(require_funds)):
    """Quick deal screening against credit box criteria."""
    mock = _mock_deal_screen(req)
    analyze_deal_screen, _, _, _ = _get_tier1()
    return await _run_module(
        account, [ModuleType.DEAL_SCREEN], None, req.unit_count,
        mock_result=mock, analysis_fn=analyze_deal_screen, analysis_request=req,
        tool_name="deal_screen",
    )


@router.post("/deal-book")
async def deal_book(req: DealBookRequest, account=Depends(require_funds)):
    """Synthesize documents into structured deal package."""
    mock = _mock_deal_book(req)
    return await _run_module(
        account, [ModuleType.DEAL_BOOK, ModuleType.DOCUMENT_SYNTHESIS],
        req.deal_id, req.unit_count, req.document_count, req.document_pages,
        mock_result=mock,
    )


@router.post("/modules/sponsor-analysis")
async def sponsor_analysis(req: SponsorAnalysisRequest, account=Depends(require_funds)):
    """Sponsor due diligence and background check."""
    mock = _mock_sponsor_analysis(req)
    analyze_sponsor, _, _ = _get_tier2()
    return await _run_module(
        account, [ModuleType.SPONSOR_ANALYSIS], req.deal_id, None,
        mock_result=mock, analysis_fn=analyze_sponsor, analysis_request=req,
        tool_name="sponsor_analysis", deal_name=getattr(req, "sponsor_name", ""),
    )


@router.post("/modules/market-research")
async def market_research(req: MarketResearchRequest, account=Depends(require_funds)):
    """Market and submarket fundamentals analysis."""
    mock = _mock_market_research(req)
    _, analyze_market, _ = _get_tier2()
    return await _run_module(
        account, [ModuleType.MARKET_RESEARCH], req.deal_id, None,
        mock_result=mock, analysis_fn=analyze_market, analysis_request=req,
        tool_name="market_research", deal_name=getattr(req, "property_name", ""),
    )


@router.post("/modules/comp-analysis")
async def comp_analysis(req: CompAnalysisRequest, account=Depends(require_funds)):
    """Comparable sales and rent analysis."""
    mock = _mock_comp_analysis(req)
    _, _, analyze_comps = _get_tier2()
    return await _run_module(
        account, [ModuleType.COMP_ANALYSIS], req.deal_id, req.unit_count,
        mock_result=mock, analysis_fn=analyze_comps, analysis_request=req,
        tool_name="comp_analysis", deal_name=getattr(req, "property_name", ""),
    )


@router.post("/modules/rent-roll-analyzer")
async def rent_roll_analyzer(req: RentRollRequest, account=Depends(require_funds)):
    """Rent roll parsing and analysis."""
    mock = _mock_rent_roll(req)
    analyze_rent_roll, _, _, _, _, _, _, _ = _get_tier3()
    return await _run_module(
        account, [ModuleType.RENT_ROLL_ANALYZER], req.deal_id, req.unit_count,
        mock_result=mock, analysis_fn=analyze_rent_roll, analysis_request=req,
        tool_name="rent_roll_analyzer", deal_name=getattr(req, "property_name", ""),
    )


@router.post("/modules/cash-flow")
async def cash_flow(req: CashFlowRequest, account=Depends(require_funds)):
    """Cash flow underwriting with scenario analysis."""
    mock = _mock_cash_flow(req)
    _, analyze_cash_flow_fn, _, _, _, _, _, _ = _get_tier3()
    return await _run_module(
        account, [ModuleType.CASH_FLOW], req.deal_id, req.unit_count,
        mock_result=mock, analysis_fn=analyze_cash_flow_fn, analysis_request=req,
        tool_name="cash_flow", deal_name=getattr(req, "property_name", ""),
    )


@router.post("/modules/loan-sizer")
async def loan_sizer(req: LoanSizerRequest, account=Depends(require_funds)):
    """Loan sizing against 6-constraint credit box waterfall."""
    mock = _mock_loan_sizer(req)
    _, _, analyze_loan_sizer, _ = _get_tier1()
    return await _run_module(
        account, [ModuleType.LOAN_SIZER], req.deal_id, None,
        mock_result=mock, analysis_fn=analyze_loan_sizer, analysis_request=req,
        tool_name="loan_sizer", deal_name=getattr(req, "property_name", ""),
    )


@router.post("/modules/term-sheet")
async def term_sheet(req: TermSheetRequest, account=Depends(require_funds)):
    """Term sheet generation from deal analysis."""
    mock = _mock_term_sheet(req)
    return await _run_module(account, [ModuleType.TERM_SHEET], req.deal_id, None, mock_result=mock)


@router.post("/modules/short-form-memo")
async def short_form_memo(req: ShortFormMemoRequest, account=Depends(require_funds)):
    """Short-form analysis memo for internal discussion."""
    mock = _mock_short_form_memo(req)
    return await _run_module(account, [ModuleType.SHORT_FORM_MEMO], req.deal_id, None, mock_result=mock)


@router.post("/modules/nuance-gate")
async def nuance_gate(req: NuanceGateRequest, account=Depends(require_funds)):
    """Nuance gate analysis for hidden risks."""
    mock = _mock_nuance_gate(req)
    _, _, analyze_nuance_gate_fn, _, _, _, _, _ = _get_tier3()
    return await _run_module(
        account, [ModuleType.NUANCE_GATE], req.deal_id, None,
        mock_result=mock, analysis_fn=analyze_nuance_gate_fn, analysis_request=req,
        tool_name="nuance_gate", deal_name=getattr(req, "property_name", ""),
    )


@router.post("/modules/ic-memo")
async def ic_memo(req: ICMemoRequest, account=Depends(require_funds)):
    """Investment Committee memo generation."""
    mock = _mock_ic_memo(req)
    _, _, _, analyze_ic_memo_fn, _, _, _, _ = _get_tier3()
    return await _run_module(
        account, [ModuleType.IC_MEMO], req.deal_id, None,
        mock_result=mock, analysis_fn=analyze_ic_memo_fn, analysis_request=req,
        tool_name="ic_memo", deal_name=getattr(req, "property_name", ""),
    )


@router.post("/modules/term-sheet-comparator")
async def term_sheet_comparator(req: TermSheetComparatorRequest, account: Account = Depends(require_funds)):
    """Side-by-side term sheet comparison and recommendation."""
    mock = {
        "comparison": {
            "term_sheets_analyzed": len(req.term_sheets),
            "recommendation": "Term Sheet A offers better all-in pricing; Term Sheet B has more flexible prepayment terms",
            "key_differences": {
                "rate_differential_bps": 25,
                "fee_differential_pct": 0.15,
                "term_flexibility": "B superior",
                "covenant_package": "A more favorable",
            },
            "side_by_side_matrix": "Detailed comparison matrix included in full output",
        }
    }
    _, _, _, _, analyze_ts_comp, _, _, _ = _get_tier3()
    return await _run_module(
        account, [ModuleType.TERM_SHEET_COMPARATOR], req.deal_id, None,
        mock_result=mock, analysis_fn=analyze_ts_comp, analysis_request=req,
        tool_name="term_sheet_comparator", deal_name=getattr(req, "deal_name", ""),
    )


@router.post("/modules/loan-pricing")
async def loan_pricing(req: LoanPricingRequest, account: Account = Depends(require_funds)):
    """Loan pricing analysis with rate cap and debt service calculations."""
    mock = {
        "pricing": {
            "index_rate": "SOFR 4.33%",
            "spread": f"{req.spread_bps or 350} bps",
            "all_in_rate": f"{4.33 + (req.spread_bps or 350) / 100:.2f}%",
            "rate_cap_cost": "$185,000 (2-year, 3.50% strike)",
            "interest_reserve": f"${(req.interest_reserve_months or 12) * req.loan_amount * 0.0075 / 12:,.0f}",
            "annual_debt_service": f"${req.loan_amount * 0.0783:,.0f}",
        }
    }
    _, _, _, analyze_loan_pricing = _get_tier1()
    return await _run_module(
        account, [ModuleType.LOAN_PRICING], req.deal_id, None,
        mock_result=mock, analysis_fn=analyze_loan_pricing, analysis_request=req,
        tool_name="loan_pricing", deal_name=getattr(req, "property_name", ""),
    )


@router.post("/modules/business-plan-analysis")
async def business_plan_analysis(req: BusinessPlanAnalysisRequest, account: Account = Depends(require_funds)):
    """Business plan feasibility and execution risk assessment."""
    mock = {
        "business_plan": {
            "feasibility_rating": "Achievable with moderate execution risk",
            "rent_growth_assessment": "Pro forma rents within 8% of market — supportable",
            "capex_reasonableness": "Budget aligns with scope for Class B- to B+ repositioning",
            "lease_up_timeline": f"{req.lease_up_months or 18} months — consistent with submarket absorption",
            "key_risks": ["Construction timeline slippage", "Rent concessions during lease-up"],
            "recommendation": "Business plan is credible; recommend 10% contingency on renovation budget",
        }
    }
    _, _, _, _, _, analyze_bp, _, _ = _get_tier3()
    return await _run_module(
        account, [ModuleType.BUSINESS_PLAN_ANALYSIS], req.deal_id, req.unit_count,
        mock_result=mock, analysis_fn=analyze_bp, analysis_request=req,
        tool_name="business_plan", deal_name=getattr(req, "property_name", ""),
    )


@router.post("/modules/debt-sizing-preview")
async def debt_sizing_preview(req: DebtSizingPreviewRequest, account: Account = Depends(require_funds)):
    """Quick debt sizing preview against credit box constraints."""
    mock = {
        "sizing_preview": {
            "max_loan_by_constraint": {
                "ltv_as_is": f"${req.asset_value * 0.75:,.0f}",
                "ltv_stabilized": f"${req.asset_value * 0.80 * 0.75:,.0f}",
                "dscr_1.05x": f"${req.noi / 1.05 / 0.075:,.0f}",
                "debt_yield_7.0%": f"${req.noi / 0.07:,.0f}",
                "ltc_80%": f"${(req.total_cost or req.asset_value) * 0.80:,.0f}" if req.total_cost else "N/A — total cost not provided",
            },
            "binding_constraint": "DSCR at 1.05x",
            "max_loan": f"${min(req.asset_value * 0.75, req.noi / 0.07):,.0f}",
            "gap_analysis": "Sizing supports 72% of requested loan amount",
        }
    }
    _, analyze_debt_sizing_preview, _, _ = _get_tier1()
    return await _run_module(
        account, [ModuleType.DEBT_SIZING_PREVIEW], req.deal_id, req.unit_count,
        mock_result=mock, analysis_fn=analyze_debt_sizing_preview, analysis_request=req,
        tool_name="debt_sizing_preview", deal_name=getattr(req, "property_name", ""),
    )


@router.post("/modules/renovation-roi")
async def renovation_roi(req: RenovationROIRequest, account: Account = Depends(require_funds)):
    """Renovation ROI and value creation analysis."""
    rent_lift = (req.target_rent or req.current_avg_rent * 1.25) - req.current_avg_rent
    annual_lift = rent_lift * req.unit_count * 12
    budget = req.renovation_budget_total or (req.renovation_per_unit or 25000) * req.unit_count
    mock = {
        "renovation_roi": {
            "current_rent": f"${req.current_avg_rent:,.0f}/unit/mo",
            "target_rent": f"${req.target_rent or req.current_avg_rent * 1.25:,.0f}/unit/mo",
            "rent_lift": f"${rent_lift:,.0f}/unit/mo ({rent_lift / req.current_avg_rent * 100:.1f}%)",
            "annual_income_increase": f"${annual_lift:,.0f}",
            "total_renovation_budget": f"${budget:,.0f}",
            "per_unit_budget": f"${budget / req.unit_count:,.0f}/unit",
            "simple_payback_months": f"{budget / (annual_lift / 12):.0f} months" if annual_lift > 0 else "N/A",
            "roi_at_5_cap": f"{annual_lift / budget * 100:.1f}%" if budget > 0 else "N/A",
            "value_creation_at_5_cap": f"${annual_lift / 0.05:,.0f}",
            "recommendation": "Renovation ROI supports value-add thesis at current market rents",
        }
    }
    _, _, _, _, _, _, analyze_reno, _ = _get_tier3()
    return await _run_module(
        account, [ModuleType.RENOVATION_ROI], req.deal_id, req.unit_count,
        mock_result=mock, analysis_fn=analyze_reno, analysis_request=req,
        tool_name="renovation_roi", deal_name=getattr(req, "property_name", ""),
    )


@router.post("/modules/quick-review")
async def quick_review(req: QuickReviewRequest, account=Depends(require_funds)):
    """10-minute deal evaluation: screen + key modules + memo."""
    mock = _mock_quick_review(req)
    _, _, _, _, _, _, _, analyze_qr = _get_tier3()
    return await _run_module(
        account, [ModuleType.QUICK_REVIEW], None, req.unit_count,
        mock_result=mock, analysis_fn=analyze_qr, analysis_request=req,
        tool_name="quick_review", deal_name=getattr(req, "property_name", ""),
    )


# ═══════════════════════════════════════════════════════════════════════════
# PREFERRED EQUITY QUICK REVIEW
# ═══════════════════════════════════════════════════════════════════════════

class PrefEquityQRRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    property_address: str = Field(..., min_length=5)
    unit_count: int = Field(..., ge=1, le=10000)
    senior_loan_amount: float = Field(..., gt=0)
    senior_rate: float = Field(..., gt=0, le=0.25)
    pref_equity_requested: Optional[float] = Field(None, gt=0)
    as_is_value: float = Field(..., gt=0)
    stabilized_value: Optional[float] = Field(None, gt=0)
    total_cost: float = Field(..., gt=0)
    noi_stabilized: float = Field(..., gt=0)
    exit_cap_rate: Optional[float] = 0.0525
    hold_months: Optional[int] = 36
    current_pay_rate: Optional[float] = 0.06
    pik_rate: Optional[float] = 0.08
    construction_quarters: Optional[int] = 8
    leaseup_quarters: Optional[int] = 3
    sponsor_name: Optional[str] = None
    notes: Optional[str] = None


def _get_pref_equity_analysis():
    """Lazy import to avoid circular deps."""
    from api.analysis.pref_equity import size_pref_equity
    return size_pref_equity


@router.post("/modules/pref-equity-qr")
async def pref_equity_qr(req: PrefEquityQRRequest, account=Depends(require_funds)):
    """Preferred equity quick review with two-pass constraint system."""

    # Run deterministic analysis directly (no Claude needed for math layer)
    analyze_fn = _get_pref_equity_analysis()

    # Build the stabilized value if not provided
    stab_value = req.stabilized_value
    if stab_value is None and req.exit_cap_rate and req.exit_cap_rate > 0:
        stab_value = req.noi_stabilized / req.exit_cap_rate

    result = analyze_fn(
        senior_loan=req.senior_loan_amount,
        senior_rate=req.senior_rate,
        as_is_value=req.as_is_value,
        stabilized_value=stab_value or req.as_is_value,
        total_cost=req.total_cost,
        noi_stabilized=req.noi_stabilized,
        exit_cap_rate=req.exit_cap_rate or 0.0525,
        hold_months=req.hold_months or 36,
        current_pay_rate=req.current_pay_rate or 0.06,
        pik_rate=req.pik_rate or 0.08,
        pref_equity_requested=req.pref_equity_requested,
        construction_quarters=req.construction_quarters or 8,
        leaseup_quarters=req.leaseup_quarters or 3,
        unit_count=req.unit_count,
    )

    return await _run_module(
        account, [ModuleType.PREF_EQUITY_QR], None, req.unit_count,
        mock_result=result, analysis_fn=None, analysis_request=req,
        tool_name="pref_equity_qr", deal_name="",
    )


@router.post("/workflow/full")
async def full_workflow(req: FullWorkflowRequest, account=Depends(require_funds)):
    """Complete 15-phase institutional CRE underwriting workflow."""
    mock = _mock_full_workflow(req)
    return await _run_module(
        account, [ModuleType.FULL_WORKFLOW], req.deal_id, req.unit_count,
        req.document_count, req.document_pages, mock_result=mock,
    )
