"""
pinchfin API — Deal Utility Routes
=====================================
POST /v1/documents/upload  — Accept document metadata
GET  /v1/deals/status      — Deal status by deal_id
GET  /v1/deals/list         — List deals for account

(c) Veleta Capital LLC. All rights reserved.
"""

import uuid
from datetime import datetime, timezone
from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field, ConfigDict

from api.auth import get_current_account
from api.state import app_state

router = APIRouter(tags=["deals"])


# ═══════════════════════════════════════════════════════════════════════════
# Request models
# ═══════════════════════════════════════════════════════════════════════════

class UploadDocsRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    deal_id: str = Field(..., min_length=1)
    documents_path: str = Field(..., min_length=1)
    document_types: Optional[List[str]] = None


# ═══════════════════════════════════════════════════════════════════════════
# Endpoints
# ═══════════════════════════════════════════════════════════════════════════

@router.post("/documents/upload")
async def upload_documents(
    req: UploadDocsRequest,
    account=Depends(get_current_account),
):
    """
    Accept document metadata for a deal.

    In production this would handle actual file uploads via presigned URLs.
    For now, records the metadata and returns confirmation.
    """
    deal = app_state.get_deal(req.deal_id)
    if not deal:
        deal = app_state.create_deal(account_id=account.id)
    elif deal.account_id != account.id:
        raise HTTPException(403, "Access denied to this deal")

    doc_record = {
        "upload_id": f"upl_{uuid.uuid4().hex[:12]}",
        "documents_path": req.documents_path,
        "document_types": req.document_types or ["unknown"],
        "status": "received",
        "uploaded_at": datetime.now(timezone.utc).isoformat(),
    }
    deal.documents.append(doc_record)
    deal.updated_at = datetime.now(timezone.utc).isoformat()

    return {
        "deal_id": deal.deal_id,
        "upload_id": doc_record["upload_id"],
        "status": "received",
        "document_types": doc_record["document_types"],
        "message": (
            f"Documents registered for deal {deal.deal_id}. "
            "They will be processed when you run an analysis module."
        ),
    }


@router.get("/deals/status")
async def deal_status(
    deal_id: str = Query(..., min_length=1),
    account=Depends(get_current_account),
):
    """
    Return the current status and progress of a deal.
    """
    deal = app_state.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, f"Deal {deal_id} not found")

    if deal.account_id != account.id:
        raise HTTPException(403, "Access denied to this deal")

    # Build phase completion from modules_run
    all_phases = [
        ("Phase 1: Screening", "deal_screen"),
        ("Phase 2: Deal Book", "deal_book"),
        ("Phase 3: Sponsor Analysis", "sponsor_analysis"),
        ("Phase 4: Market Research", "market_research"),
        ("Phase 5: Comp Analysis", "comp_analysis"),
        ("Phase 6: Rent Roll", "rent_roll_analyzer"),
        ("Phase 7: Cash Flow", "cash_flow"),
        ("Phase 8: Loan Sizing", "loan_sizer"),
        ("Phase 9: Term Sheet", "term_sheet"),
        ("Phase 10: Nuance Gate", "nuance_gate"),
        ("Phase 11: Short-Form Memo", "short_form_memo"),
        ("Phase 12: IC Memo", "ic_memo"),
    ]

    phases = []
    for phase_name, module_key in all_phases:
        phases.append({
            "phase": phase_name,
            "status": "complete" if module_key in deal.modules_run else "pending",
        })

    completed = sum(1 for p in phases if p["status"] == "complete")

    return {
        "deal": deal.to_dict(),
        "progress": {
            "phases_completed": completed,
            "total_phases": len(all_phases),
            "pct_complete": round(completed / len(all_phases) * 100, 1),
            "phases": phases,
        },
    }


@router.get("/deals/list")
async def list_deals(
    status: str = Query("active", pattern="^(active|completed|archived|all)$"),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    account=Depends(get_current_account),
):
    """
    List all deals for the authenticated account.
    """
    deals = app_state.get_deals_for_account(
        account.id, status=status, limit=limit, offset=offset,
    )

    return {
        "deals": [d.to_dict() for d in deals],
        "total": len(deals),
        "limit": limit,
        "offset": offset,
        "filters": {"status": status},
    }
