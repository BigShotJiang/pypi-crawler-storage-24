#!/usr/bin/env python3
"""
PinchFin Report Generator — v9 Design System (ValeriReport API)
Drop-in replacement for the V3.1 Valeri generator with PinchFin v9 palette.

Navy (#080D18) / Cherry (#9B2335) / RL Blue (#B8CCDB) / Cloud (#F8F7F4)
Calibri-based typography. Dense label:value layouts.
Excel-quality financial formatting for $50-100M+ transactions.

Usage:
    from valeri_report_v3 import ValeriReport
    report = ValeriReport("Title", "Subtitle")
    report.add_section("SECTION")
    report.save("output.docx")

══════════════════════════════════════════════════════════════════════
REPORT DEPTH & PAGE UTILIZATION RULES (LOCKED — March 2026)
══════════════════════════════════════════════════════════════════════

1. TARGET DEPTH: Each formal report should be 10-13 printed pages of
   dense, IB/PE-quality content. Word count targets are 4,000-6,000
   words depending on report type. Every sentence must be analytically
   accretive — no filler, no padding to hit a word count.

2. PAGE UTILIZATION — CRITICAL:
   Do NOT call add_page_break() after every section. Sections should
   flow continuously on the page. Only insert a page break when:
     - A major thematic shift requires visual separation (e.g.,
       moving from "Credit Strengths" to "Credit Risks")
     - A large table would be split awkwardly across pages
     - The cover page ends (this is automatic)
   A report with 8 sections should have AT MOST 2-3 manual page
   breaks, NOT 7. Use 100% of every page.

3. CONTENT PATTERN: narrative → table → interpretive prose → callout
   box → narrative. Every table must have analytical prose before or
   after it. Tables compress data; narrative provides institutional
   insight.

4. ANTI-PATTERNS (never do these):
   - add_page_break() after every add_section() call
   - Sections that are only 10-20% of the page with the rest blank
   - Reports that are 15 pages but compress to 5-6 after reformatting
   - Filler paragraphs that restate what a table already shows
"""

from docx import Document
from docx.shared import Inches, Pt, RGBColor, Twips
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import os
import re


class Colors:
    # ── PinchFin v9 Primary Palette ──────────────────────────────────────
    NAVY = RGBColor(0x08, 0x0D, 0x18)
    CHARCOAL = RGBColor(0x1D, 0x1D, 0x1F)
    PAPER_WHITE = RGBColor(0xFF, 0xFF, 0xFF)
    CLOUD_MID = RGBColor(0xEE, 0xED, 0xEA)
    RL_BLUE = RGBColor(0xB8, 0xCC, 0xDB)
    CLOUD = RGBColor(0xF8, 0xF7, 0xF4)
    CHERRY = RGBColor(0x9B, 0x23, 0x35)
    CHERRY_DARK = RGBColor(0x7D, 0x1C, 0x2A)
    SLATE_MUTED = RGBColor(0x6B, 0x72, 0x78)

    # ── Semantic Colors (v9) ─────────────────────────────────────────────
    FOREST_GREEN = RGBColor(0x1B, 0x6B, 0x3A)
    PASS_BG = RGBColor(0xD1, 0xFA, 0xE5)
    CRIMSON = RGBColor(0xB2, 0x22, 0x34)
    FAIL_BG = RGBColor(0xFE, 0xE2, 0xE2)
    DARK_AMBER = RGBColor(0x8B, 0x69, 0x14)
    MONITOR_BG = RGBColor(0xFE, 0xF3, 0xC7)

    # ── Hex constants for XML shading ────────────────────────────────────
    NAVY_HEX = "080D18"
    PAPER_WHITE_HEX = "FFFFFF"
    CLOUD_MID_HEX = "EEEDEA"
    RL_BLUE_HEX = "B8CCDB"
    CLOUD_HEX = "F8F7F4"
    CHERRY_HEX = "9B2335"
    CHERRY_DARK_HEX = "7D1C2A"
    SLATE_MUTED_HEX = "6B7278"
    FOREST_GREEN_HEX = "1B6B3A"
    PASS_BG_HEX = "D1FAE5"
    CRIMSON_HEX = "B22234"
    FAIL_BG_HEX = "FEE2E2"
    DARK_AMBER_HEX = "8B6914"
    MONITOR_BG_HEX = "FEF3C7"
    REC_BOX_HEX = "F5F0F1"
    BINDING_HEX = "F0E8EA"

    # ── V3.1 API Compatibility Aliases ───────────────────────────────────
    CARBON_SLATE = NAVY
    INSTITUTIONAL_BLACK = CHARCOAL
    STEEL_GREY = CLOUD_MID
    AETHER = RL_BLUE
    AETHER_LIGHT = CLOUD
    SLATE_5 = CLOUD
    NODE_GREEN = FOREST_GREEN
    CREDIT_RED = CRIMSON
    AMBER = DARK_AMBER
    NOI_GREEN = FOREST_GREEN

    CARBON_SLATE_HEX = NAVY_HEX
    STEEL_GREY_HEX = CLOUD_MID_HEX
    AETHER_HEX = RL_BLUE_HEX
    AETHER_LIGHT_HEX = CLOUD_HEX
    SLATE_5_HEX = CLOUD_HEX
    NODE_GREEN_HEX = FOREST_GREEN_HEX
    CREDIT_RED_HEX = CRIMSON_HEX
    AMBER_HEX = DARK_AMBER_HEX
    INSTITUTIONAL_BLACK_HEX = "1D1D1F"

    # Legacy aliases
    WHITE = PAPER_WHITE
    BLACK = CHARCOAL
    CHARCOAL_ALIAS = NAVY
    MIDNIGHT = NAVY
    TAN = RL_BLUE
    PASS_GREEN = FOREST_GREEN
    FAIL_RED = CRIMSON
    MIDNIGHT_HEX = NAVY_HEX
    WHITE_HEX = PAPER_WHITE_HEX
    MIDNIGHT_10_HEX = CLOUD_MID_HEX
    MIDNIGHT_15_HEX = CLOUD_MID_HEX
    MONITOR_AMBER = DARK_AMBER


class Fonts:
    """Calibri-based typography -- institutional Excel standard."""
    HEADING = 'Calibri'
    BODY = 'Calibri'
    NUMBERS = 'Calibri'
    WORDMARK = 'Calibri'
    # Legacy aliases
    HEADING_FALLBACK = 'Calibri'
    BODY_FALLBACK = 'Calibri'
    MONO = 'Calibri'
    MONO_FALLBACK = 'Calibri'


class ValeriReport:
    """PinchFin v9 report generator -- ValeriReport API compatible."""

    def __init__(self, title: str, subtitle: str = "", date: str = None, version: str = "1.0"):
        self.doc = Document()
        self.title = title
        self.subtitle = subtitle
        self.version = version
        self.date = date or self._get_date()
        self._setup_styles()
        self._add_cover_page()

    def _get_date(self):
        from datetime import datetime
        return datetime.now().strftime("%B %d, %Y")

    def _setup_styles(self):
        style = self.doc.styles['Normal']
        style.font.name = Fonts.BODY
        style.font.size = Pt(9)
        style.font.color.rgb = Colors.CHARCOAL
        style.paragraph_format.space_before = Pt(0)
        style.paragraph_format.space_after = Pt(2)
        style.paragraph_format.line_spacing = 1.0
        for section in self.doc.sections:
            section.top_margin = Inches(0.5)
            section.bottom_margin = Inches(0.5)
            section.left_margin = Inches(0.5)
            section.right_margin = Inches(0.5)

    def _add_cover_page(self):
        """Cover page: pf wordmark in Navy bar, title, property info."""
        # Navy bar with "pf" wordmark
        t = self.doc.add_table(rows=1, cols=1)
        c = t.rows[0].cells[0]
        self._shade(c, Colors.NAVY_HEX)
        self._pad(c, 200, 200, 200, 200)
        c.paragraphs[0].clear()
        p = c.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        r = p.add_run("pf")
        r.font.name = Fonts.WORDMARK
        r.font.size = Pt(18)
        r.font.bold = True
        r.font.color.rgb = Colors.PAPER_WHITE
        self._no_borders(t)

        # Cherry accent line
        a = self.doc.add_paragraph()
        a.paragraph_format.space_after = Pt(0)
        r = a.add_run("\u2501" * 80)
        r.font.color.rgb = Colors.CHERRY
        r.font.size = Pt(4)

        for _ in range(2):
            self._spacer(6)

        # Title
        tp = self.doc.add_paragraph()
        tp.alignment = WD_ALIGN_PARAGRAPH.LEFT
        for line in self.title.split('\n'):
            r = tp.add_run(line.upper())
            r.font.name = Fonts.HEADING
            r.font.size = Pt(22)
            r.font.bold = True
            r.font.color.rgb = Colors.NAVY
            tp.add_run('\n')

        # RL Blue rule
        rl = self.doc.add_paragraph()
        rl.paragraph_format.space_before = Pt(4)
        rl.paragraph_format.space_after = Pt(4)
        r = rl.add_run("\u2501" * 50)
        r.font.color.rgb = Colors.RL_BLUE
        r.font.size = Pt(6)

        # Subtitle lines
        if self.subtitle:
            for line in self.subtitle.split('\n'):
                s = self.doc.add_paragraph()
                s.alignment = WD_ALIGN_PARAGRAPH.LEFT
                r = s.add_run(line)
                r.font.name = Fonts.BODY
                r.font.size = Pt(12)
                r.font.color.rgb = Colors.SLATE_MUTED

        for _ in range(3):
            self._spacer(6)

        self.doc.add_page_break()

    # -- Structure --------------------------------------------------------

    def add_section(self, title: str):
        """Slim Navy bar -- compact section header."""
        self._spacer(4)
        t = self.doc.add_table(rows=1, cols=1)
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        c = t.rows[0].cells[0]
        self._shade(c, Colors.NAVY_HEX)
        self._pad(c, 40, 40, 80, 80)
        c.paragraphs[0].clear()
        p = c.paragraphs[0]
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        r = p.add_run(title.upper())
        r.font.name = Fonts.HEADING
        r.font.size = Pt(9)
        r.font.bold = True
        r.font.color.rgb = Colors.PAPER_WHITE
        self._no_borders(t)
        self._spacer(3)

    def add_subsection(self, title: str):
        """Cherry pipe accent + bold text -- v9 subsection style."""
        t = self.doc.add_table(rows=1, cols=1)
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        c = t.rows[0].cells[0]
        c.text = ""
        self._left_border(c, Colors.CHERRY_HEX, 16)
        self._pad(c, 20, 20, 60, 20)
        p = c.paragraphs[0]
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after = Pt(2)
        r = p.add_run(title)
        r.font.name = Fonts.HEADING
        r.font.size = Pt(10)
        r.font.bold = True
        r.font.color.rgb = Colors.NAVY
        self._no_borders(t)

    def add_paragraph(self, text: str, secondary: bool = False):
        p = self.doc.add_paragraph()
        p.paragraph_format.space_before = Pt(2)
        p.paragraph_format.space_after = Pt(4)
        r = p.add_run(text)
        r.font.name = Fonts.BODY
        r.font.size = Pt(9)
        r.font.color.rgb = Colors.SLATE_MUTED if secondary else Colors.CHARCOAL

    def add_thin_rule(self):
        p = self.doc.add_paragraph()
        p.paragraph_format.space_before = Pt(2)
        p.paragraph_format.space_after = Pt(2)
        pPr = p._p.get_or_add_pPr()
        pBdr = OxmlElement('w:pBdr')
        b = OxmlElement('w:bottom')
        b.set(qn('w:val'), 'single')
        b.set(qn('w:sz'), '4')
        b.set(qn('w:color'), Colors.CLOUD_MID_HEX)
        pBdr.append(b)
        pPr.append(pBdr)

    # -- Key-Value Layouts ------------------------------------------------

    def add_kv_pairs(self, pairs: list, title: str = None):
        """Dense label:value pairs in a single column."""
        if title:
            self.add_subsection(title)
        t = self.doc.add_table(rows=len(pairs), cols=2)
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        for i, (label, value) in enumerate(pairs):
            row = t.rows[i]
            lc = row.cells[0]
            lc.text = ""
            lc.width = Inches(2.5)
            lp = lc.paragraphs[0]
            lp.paragraph_format.space_before = Pt(0)
            lp.paragraph_format.space_after = Pt(0)
            lr = lp.add_run(str(label))
            lr.font.name = Fonts.BODY
            lr.font.size = Pt(9)
            lr.font.color.rgb = Colors.CHARCOAL
            self._pad(lc, 15, 15, 40, 10)

            vc = row.cells[1]
            vc.text = ""
            vc.width = Inches(2.0)
            vp = vc.paragraphs[0]
            vp.paragraph_format.space_before = Pt(0)
            vp.paragraph_format.space_after = Pt(0)
            vp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            vr = vp.add_run(str(value))
            vr.font.name = Fonts.NUMBERS
            vr.font.size = Pt(9)
            vr.font.bold = True
            vr.font.color.rgb = Colors.CHARCOAL
            c = self._val_color(str(value))
            if c:
                vr.font.color.rgb = c
            self._pad(vc, 15, 15, 10, 40)
        self._no_borders(t)

    def add_dual_kv(self, left_title: str, left_pairs: list,
                    right_title: str, right_pairs: list):
        """Two key-value sections side by side -- core institutional layout."""
        max_rows = max(len(left_pairs), len(right_pairs)) + 1
        t = self.doc.add_table(rows=max_rows, cols=5)
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        widths = [Inches(1.85), Inches(1.55), Inches(0.25),
                  Inches(1.85), Inches(1.55)]

        # Title row
        tr = t.rows[0]
        for ci in range(5):
            cell = tr.cells[ci]
            cell.text = ""
            cell.width = widths[ci]
            self._pad(cell, 15, 25, 40, 10)

        # Left title
        ltc = tr.cells[0]
        ltp = ltc.paragraphs[0]
        ltp.paragraph_format.space_before = Pt(0)
        ltp.paragraph_format.space_after = Pt(0)
        r = ltp.add_run(left_title.upper())
        r.font.name = Fonts.HEADING
        r.font.size = Pt(9)
        r.font.bold = True
        r.font.color.rgb = Colors.NAVY
        self._cell_border(ltc, 'bottom', Colors.NAVY_HEX, 6)
        self._cell_border(tr.cells[1], 'bottom', Colors.NAVY_HEX, 6)

        # Right title
        rtc = tr.cells[3]
        rtp = rtc.paragraphs[0]
        rtp.paragraph_format.space_before = Pt(0)
        rtp.paragraph_format.space_after = Pt(0)
        r = rtp.add_run(right_title.upper())
        r.font.name = Fonts.HEADING
        r.font.size = Pt(9)
        r.font.bold = True
        r.font.color.rgb = Colors.NAVY
        self._pad(rtc, 15, 25, 40, 10)
        self._cell_border(rtc, 'bottom', Colors.NAVY_HEX, 6)
        self._cell_border(tr.cells[4], 'bottom', Colors.NAVY_HEX, 6)

        # Data rows
        for i in range(max(len(left_pairs), len(right_pairs))):
            row = t.rows[i + 1]
            for ci in range(5):
                cell = row.cells[ci]
                cell.text = ""
                cell.width = widths[ci]

            if i < len(left_pairs):
                self._kv_cell(row.cells[0], str(left_pairs[i][0]), False)
                self._kv_cell(row.cells[1], str(left_pairs[i][1]), True)

            if i < len(right_pairs):
                self._kv_cell(row.cells[3], str(right_pairs[i][0]), False)
                self._kv_cell(row.cells[4], str(right_pairs[i][1]), True)

        self._no_borders(t)

    # -- Tables -----------------------------------------------------------

    def add_table(self, data: list, color_values: bool = True):
        """Clean table -- bold header text, thin borders, no colored header bg.
        Column alignment determined by scanning data: numeric columns right-align."""
        if not data:
            return
        ncols = len(data[0])
        col_aligns = [self._column_alignment(data, j) for j in range(ncols)]
        t = self.doc.add_table(rows=len(data), cols=ncols)
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        for i, row_data in enumerate(data):
            for j, cell_text in enumerate(row_data):
                cell = t.rows[i].cells[j]
                cell.text = ""
                p = cell.paragraphs[0]
                p.paragraph_format.space_before = Pt(0)
                p.paragraph_format.space_after = Pt(0)
                p.alignment = col_aligns[j]
                txt = str(cell_text)
                r = p.add_run(txt)
                r.font.name = Fonts.BODY
                r.font.size = Pt(9)
                if i == 0:
                    r.font.bold = True
                    r.font.color.rgb = Colors.NAVY
                    r.font.size = Pt(8)
                    self._cell_border(cell, 'bottom', Colors.NAVY_HEX, 8)
                else:
                    r.font.color.rgb = Colors.CHARCOAL
                    if j == 0:
                        r.font.bold = True
                    self._cell_border(cell, 'bottom', Colors.CLOUD_MID_HEX, 2)
                    if color_values:
                        tc = self._val_color(txt)
                        if tc:
                            r.font.color.rgb = tc
                            r.font.bold = True
                self._pad(cell, 25, 25, 40, 40)
        self._outer_off(t)
        self._spacer(2)

    def add_summary_table(self, data: list, highlight_column: int = None,
                          highlight_rows: list = None):
        """Summary table with optional highlighting."""
        if not data:
            return
        ncols = len(data[0])
        col_aligns = [self._column_alignment(data, j) for j in range(ncols)]
        t = self.doc.add_table(rows=len(data), cols=ncols)
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        for i, row_data in enumerate(data):
            hi = highlight_rows and i in highlight_rows
            for j, cell_text in enumerate(row_data):
                cell = t.rows[i].cells[j]
                cell.text = ""
                p = cell.paragraphs[0]
                p.paragraph_format.space_before = Pt(0)
                p.paragraph_format.space_after = Pt(0)
                p.alignment = col_aligns[j]
                txt = str(cell_text)
                r = p.add_run(txt)
                r.font.name = Fonts.BODY
                r.font.size = Pt(9)
                if i == 0:
                    r.font.bold = True
                    r.font.color.rgb = Colors.NAVY
                    r.font.size = Pt(8)
                    self._cell_border(cell, 'bottom', Colors.NAVY_HEX, 8)
                else:
                    r.font.color.rgb = Colors.CHARCOAL
                    if j == 0:
                        r.font.bold = True
                    if hi:
                        self._shade(cell, Colors.CLOUD_HEX)
                        r.font.bold = True
                    if highlight_column and j == highlight_column:
                        r.font.bold = True
                    self._cell_border(cell, 'bottom', Colors.CLOUD_MID_HEX, 2)
                    tc = self._val_color(txt)
                    if tc:
                        r.font.color.rgb = tc
                        r.font.bold = True
                self._pad(cell, 25, 25, 40, 40)
        self._outer_off(t)
        self._spacer(2)

    def add_comparison_table(self, data: list, scenarios: list = None):
        self.add_table(data, color_values=True)

    def add_sensitivity_table(self, data: list, base_row_index: int = 1,
                              dscr_column: int = None):
        """Sensitivity table with base case bold and DSCR coloring."""
        if not data:
            return
        ncols = len(data[0])
        col_aligns = [self._column_alignment(data, j) for j in range(ncols)]
        t = self.doc.add_table(rows=len(data), cols=ncols)
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        for i, row_data in enumerate(data):
            base = (i == base_row_index)
            for j, cell_text in enumerate(row_data):
                cell = t.rows[i].cells[j]
                cell.text = ""
                p = cell.paragraphs[0]
                p.paragraph_format.space_before = Pt(0)
                p.paragraph_format.space_after = Pt(0)
                p.alignment = col_aligns[j]
                txt = str(cell_text)
                r = p.add_run(txt)
                r.font.name = Fonts.BODY
                r.font.size = Pt(9)
                if i == 0:
                    r.font.bold = True
                    r.font.color.rgb = Colors.NAVY
                    r.font.size = Pt(8)
                    self._cell_border(cell, 'bottom', Colors.NAVY_HEX, 8)
                else:
                    r.font.color.rgb = Colors.CHARCOAL
                    if base:
                        r.font.bold = True
                        self._shade(cell, Colors.CLOUD_HEX)
                    if dscr_column is not None and j == dscr_column:
                        dv = self._parse_dscr(txt)
                        if dv is not None:
                            if dv < 1.00:
                                r.font.color.rgb = Colors.CRIMSON
                                r.font.bold = True
                            elif dv < 1.20:
                                r.font.color.rgb = Colors.DARK_AMBER
                                r.font.bold = True
                    self._cell_border(cell, 'bottom', Colors.CLOUD_MID_HEX, 2)
                self._pad(cell, 25, 25, 40, 40)
        self._outer_off(t)
        self._spacer(2)

    def add_risk_table(self, data: list, severity_column: int = 1):
        """Risk table with severity coloring."""
        if not data:
            return
        ncols = len(data[0])
        col_aligns = [self._column_alignment(data, j) for j in range(ncols)]
        t = self.doc.add_table(rows=len(data), cols=ncols)
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        for i, row_data in enumerate(data):
            for j, cell_text in enumerate(row_data):
                cell = t.rows[i].cells[j]
                cell.text = ""
                p = cell.paragraphs[0]
                p.paragraph_format.space_before = Pt(0)
                p.paragraph_format.space_after = Pt(0)
                p.alignment = col_aligns[j]
                txt = str(cell_text)
                r = p.add_run(txt)
                r.font.name = Fonts.BODY
                r.font.size = Pt(9)
                if i == 0:
                    r.font.bold = True
                    r.font.color.rgb = Colors.NAVY
                    r.font.size = Pt(8)
                    self._cell_border(cell, 'bottom', Colors.NAVY_HEX, 8)
                else:
                    r.font.color.rgb = Colors.CHARCOAL
                    if j == 0:
                        r.font.bold = True
                    if j == severity_column:
                        sl = txt.lower().strip()
                        if sl in ('low', 'minor', 'acceptable'):
                            r.font.color.rgb = Colors.FOREST_GREEN
                            r.font.bold = True
                        elif sl in ('med', 'medium', 'moderate'):
                            r.font.color.rgb = Colors.DARK_AMBER
                            r.font.bold = True
                        elif sl in ('high', 'critical', 'severe'):
                            r.font.color.rgb = Colors.CRIMSON
                            r.font.bold = True
                    self._cell_border(cell, 'bottom', Colors.CLOUD_MID_HEX, 2)
                self._pad(cell, 25, 25, 40, 40)
        self._outer_off(t)
        self._spacer(2)

    def add_sources_uses_table(self, sources: list, uses: list):
        """Side-by-side Sources & Uses with totals."""
        def _sum(items):
            total = 0
            for item in items:
                if len(item) > 1:
                    s = str(item[1]).replace('$', '').replace(',', '')
                    try:
                        total += float(s)
                    except ValueError:
                        pass
            return total

        st, ut = _sum(sources), _sum(uses)
        mr = max(len(sources), len(uses)) + 2
        t = self.doc.add_table(rows=mr, cols=7)
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        ws = [Inches(1.6), Inches(1.2), Inches(0.5), Inches(0.2),
              Inches(1.6), Inches(1.2), Inches(0.5)]

        # Headers
        for j, txt in enumerate(['Sources', 'Amount', '%']):
            c = t.rows[0].cells[j]
            c.text = ""
            c.width = ws[j]
            p = c.paragraphs[0]
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            if j > 0:
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            r = p.add_run(txt)
            r.font.name = Fonts.HEADING
            r.font.size = Pt(8)
            r.font.bold = True
            r.font.color.rgb = Colors.NAVY
            self._cell_border(c, 'bottom', Colors.NAVY_HEX, 6)
            self._pad(c, 20, 20, 30, 20)

        t.rows[0].cells[3].text = ""
        t.rows[0].cells[3].width = ws[3]

        for j, txt in enumerate(['Uses', 'Amount', '%']):
            c = t.rows[0].cells[j + 4]
            c.text = ""
            c.width = ws[j + 4]
            p = c.paragraphs[0]
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            if j > 0:
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            r = p.add_run(txt)
            r.font.name = Fonts.HEADING
            r.font.size = Pt(8)
            r.font.bold = True
            r.font.color.rgb = Colors.NAVY
            self._cell_border(c, 'bottom', Colors.NAVY_HEX, 6)
            self._pad(c, 20, 20, 30, 20)

        # Data
        for i in range(max(len(sources), len(uses))):
            ri = i + 1
            row = t.rows[ri]
            if i < len(sources):
                for j in range(min(3, len(sources[i]))):
                    c = row.cells[j]
                    c.text = ""
                    c.width = ws[j]
                    p = c.paragraphs[0]
                    p.paragraph_format.space_before = Pt(0)
                    p.paragraph_format.space_after = Pt(0)
                    if j > 0:
                        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
                    r = p.add_run(str(sources[i][j]))
                    r.font.name = Fonts.BODY
                    r.font.size = Pt(9)
                    r.font.color.rgb = Colors.CHARCOAL
                    if j == 0:
                        r.font.bold = True
                    self._pad(c, 15, 15, 30, 20)
            if i < len(uses):
                for j in range(min(3, len(uses[i]))):
                    c = row.cells[j + 4]
                    c.text = ""
                    c.width = ws[j + 4]
                    p = c.paragraphs[0]
                    p.paragraph_format.space_before = Pt(0)
                    p.paragraph_format.space_after = Pt(0)
                    if j > 0:
                        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
                    r = p.add_run(str(uses[i][j]))
                    r.font.name = Fonts.BODY
                    r.font.size = Pt(9)
                    r.font.color.rgb = Colors.CHARCOAL
                    if j == 0:
                        r.font.bold = True
                    self._pad(c, 15, 15, 30, 20)

        # Totals
        tr_idx = mr - 1
        trow = t.rows[tr_idx]
        for j, txt in enumerate(['Total Sources', f'${st:,.0f}', '100%']):
            c = trow.cells[j]
            c.text = ""
            p = c.paragraphs[0]
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            if j > 0:
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            r = p.add_run(txt)
            r.font.name = Fonts.BODY
            r.font.size = Pt(9)
            r.font.bold = True
            r.font.color.rgb = Colors.NAVY
            self._cell_border(c, 'top', Colors.NAVY_HEX, 6)
            self._pad(c, 20, 20, 30, 20)

        for j, txt in enumerate(['Total Uses', f'${ut:,.0f}', '100%']):
            c = trow.cells[j + 4]
            c.text = ""
            p = c.paragraphs[0]
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            if j > 0:
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            r = p.add_run(txt)
            r.font.name = Fonts.BODY
            r.font.size = Pt(9)
            r.font.bold = True
            r.font.color.rgb = Colors.NAVY
            self._cell_border(c, 'top', Colors.NAVY_HEX, 6)
            self._pad(c, 20, 20, 30, 20)

        self._no_borders(t)

    # -- V3 Components ----------------------------------------------------

    def add_deal_tape_strip(self, metrics: dict):
        """Compact horizontal metric strip -- single row."""
        cols = len(metrics)
        t = self.doc.add_table(rows=1, cols=cols)
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        labels = list(metrics.keys())
        values = list(metrics.values())
        for j in range(cols):
            c = t.rows[0].cells[j]
            c.text = ""
            self._shade(c, Colors.CLOUD_HEX)
            p = c.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(labels[j].upper() + "\n")
            r.font.name = Fonts.BODY
            r.font.size = Pt(7)
            r.font.color.rgb = Colors.SLATE_MUTED
            r = p.add_run(str(values[j]))
            r.font.name = Fonts.NUMBERS
            r.font.size = Pt(10)
            r.font.bold = True
            r.font.color.rgb = Colors.NAVY
            self._pad(c, 25, 25, 15, 15)
        self._strip_borders(t)
        self._spacer(2)

    def add_metric_grid(self, metrics: list, cols: int = 3):
        """Compact metric grid using KV layout."""
        pairs = [(m.get('label', ''), m.get('value', '')) for m in metrics]
        if cols == 2:
            mid = (len(pairs) + 1) // 2
            self.add_dual_kv("", pairs[:mid], "", pairs[mid:])
        else:
            self.add_kv_pairs(pairs)

    def add_micro_table(self, data: list, monospace_numbers: bool = True):
        self.add_table(data, color_values=True)

    def add_bento_row(self, cells: list):
        """Multi-column content blocks."""
        nc = len(cells)
        t = self.doc.add_table(rows=1, cols=nc)
        t.alignment = WD_TABLE_ALIGNMENT.LEFT
        for j, cd in enumerate(cells):
            c = t.rows[0].cells[j]
            c.text = ""
            st = cd.get('style', 'default')
            if st == 'aether':
                self._shade(c, Colors.CLOUD_HEX)
            elif st == 'slate':
                self._shade(c, Colors.CLOUD_HEX)
            self._pad(c, 40, 40, 50, 50)
            title = cd.get('title', '')
            if title:
                p = c.paragraphs[0]
                p.paragraph_format.space_before = Pt(0)
                p.paragraph_format.space_after = Pt(2)
                r = p.add_run(title.upper())
                r.font.name = Fonts.HEADING
                r.font.size = Pt(8)
                r.font.bold = True
                r.font.color.rgb = Colors.NAVY
            content = cd.get('content', '')
            if isinstance(content, list):
                for item in content:
                    cp = c.add_paragraph()
                    cp.paragraph_format.space_before = Pt(0)
                    cp.paragraph_format.space_after = Pt(1)
                    r = cp.add_run(str(item))
                    r.font.name = Fonts.BODY
                    r.font.size = Pt(8)
                    r.font.color.rgb = Colors.CHARCOAL
            elif content:
                cp = c.add_paragraph()
                cp.paragraph_format.space_before = Pt(0)
                cp.paragraph_format.space_after = Pt(1)
                r = cp.add_run(str(content))
                r.font.name = Fonts.BODY
                r.font.size = Pt(8)
                r.font.color.rgb = Colors.CHARCOAL
        self._no_borders(t)
        self._spacer(2)

    def add_sources_uses_side_by_side(self, sources: list, uses: list):
        self.add_sources_uses_table(sources, uses)

    # -- Callouts ---------------------------------------------------------

    def add_insight(self, title: str, finding: str, impact: str,
                    action: str, risk_level: str = "warning"):
        t = self.doc.add_table(rows=1, cols=1)
        c = t.rows[0].cells[0]
        if risk_level == "critical":
            bc, tc = Colors.CRIMSON_HEX, Colors.CRIMSON
        elif risk_level == "positive":
            bc, tc = Colors.FOREST_GREEN_HEX, Colors.FOREST_GREEN
        else:
            bc, tc = Colors.DARK_AMBER_HEX, Colors.DARK_AMBER
        self._shade(c, Colors.CLOUD_HEX)
        self._left_border(c, bc, 16)
        self._pad(c, 50, 50, 70, 70)
        c.paragraphs[0].clear()
        tp = c.paragraphs[0]
        tp.paragraph_format.space_before = Pt(0)
        tp.paragraph_format.space_after = Pt(2)
        r = tp.add_run(title.upper())
        r.font.name = Fonts.HEADING
        r.font.size = Pt(9)
        r.font.bold = True
        r.font.color.rgb = tc
        for lbl, txt in [("Finding", finding), ("Impact", impact), ("Action", action)]:
            p = c.add_paragraph()
            p.paragraph_format.space_before = Pt(1)
            p.paragraph_format.space_after = Pt(1)
            r = p.add_run(f"{lbl}: ")
            r.font.bold = True
            r.font.name = Fonts.BODY
            r.font.size = Pt(8)
            r.font.color.rgb = Colors.CHARCOAL
            r = p.add_run(txt)
            r.font.name = Fonts.BODY
            r.font.size = Pt(8)
            r.font.color.rgb = Colors.CHARCOAL
        self._no_borders(t)
        self._spacer(2)

    def add_highlight_box(self, text: str, style: str = "primary"):
        """Highlight box -- primary uses Cloud bg with Navy left border."""
        t = self.doc.add_table(rows=1, cols=1)
        c = t.rows[0].cells[0]
        if style == "primary":
            self._shade(c, Colors.CLOUD_HEX)
            self._left_border(c, Colors.NAVY_HEX, 16)
            color = Colors.NAVY
        elif style == "positive":
            self._shade(c, Colors.PASS_BG_HEX)
            self._left_border(c, Colors.FOREST_GREEN_HEX, 16)
            color = Colors.FOREST_GREEN
        elif style == "warning":
            self._shade(c, Colors.MONITOR_BG_HEX)
            self._left_border(c, Colors.DARK_AMBER_HEX, 16)
            color = Colors.DARK_AMBER
        elif style == "critical":
            self._shade(c, Colors.FAIL_BG_HEX)
            self._left_border(c, Colors.CRIMSON_HEX, 16)
            color = Colors.CRIMSON
        elif style == "secondary":
            self._shade(c, Colors.REC_BOX_HEX)
            self._left_border(c, Colors.CHERRY_HEX, 16)
            color = Colors.CHERRY
        else:
            self._shade(c, Colors.CLOUD_HEX)
            self._left_border(c, Colors.NAVY_HEX, 16)
            color = Colors.NAVY
        self._pad(c, 40, 40, 70, 70)
        c.paragraphs[0].clear()
        p = c.paragraphs[0]
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        r = p.add_run(text)
        r.font.name = Fonts.HEADING
        r.font.size = Pt(9)
        r.font.bold = True
        r.font.color.rgb = color
        self._no_borders(t)
        self._spacer(2)

    def add_callout_box(self, title: str, body: str, style: str = "aether"):
        """Key finding / assessment callout box."""
        t = self.doc.add_table(rows=1, cols=1)
        c = t.rows[0].cells[0]
        if style == "aether":
            self._shade(c, Colors.CLOUD_HEX)
            self._left_border(c, Colors.NAVY_HEX, 16)
        elif style == "grey":
            self._shade(c, Colors.CLOUD_HEX)
            self._left_border(c, Colors.NAVY_HEX, 16)
        elif style == "positive":
            self._shade(c, Colors.PASS_BG_HEX)
            self._left_border(c, Colors.FOREST_GREEN_HEX, 16)
        elif style == "warning":
            self._shade(c, Colors.MONITOR_BG_HEX)
            self._left_border(c, Colors.DARK_AMBER_HEX, 16)
        elif style == "critical":
            self._shade(c, Colors.FAIL_BG_HEX)
            self._left_border(c, Colors.CRIMSON_HEX, 16)
        else:
            self._shade(c, Colors.CLOUD_HEX)
            self._left_border(c, Colors.NAVY_HEX, 16)
        self._pad(c, 50, 50, 70, 70)
        c.paragraphs[0].clear()
        # Title
        tp = c.paragraphs[0]
        tp.paragraph_format.space_before = Pt(0)
        tp.paragraph_format.space_after = Pt(2)
        r = tp.add_run(title.upper())
        r.font.name = Fonts.HEADING
        r.font.size = Pt(9)
        r.font.bold = True
        r.font.color.rgb = Colors.NAVY
        # Body
        bp = c.add_paragraph()
        bp.paragraph_format.space_before = Pt(1)
        bp.paragraph_format.space_after = Pt(1)
        r = bp.add_run(body)
        r.font.name = Fonts.BODY
        r.font.size = Pt(9)
        r.font.color.rgb = Colors.CHARCOAL
        self._no_borders(t)
        self._spacer(2)

    def add_decision_box(self, title: str, points: list):
        t = self.doc.add_table(rows=1, cols=1)
        c = t.rows[0].cells[0]
        self._shade(c, Colors.CLOUD_HEX)
        self._left_border(c, Colors.NAVY_HEX, 16)
        self._pad(c, 50, 50, 70, 70)
        c.paragraphs[0].clear()
        tp = c.paragraphs[0]
        tp.paragraph_format.space_before = Pt(0)
        tp.paragraph_format.space_after = Pt(2)
        r = tp.add_run(title.upper())
        r.font.name = Fonts.HEADING
        r.font.size = Pt(9)
        r.font.bold = True
        r.font.color.rgb = Colors.NAVY
        for pt in points:
            p = c.add_paragraph()
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(1)
            r = p.add_run(f"  {pt}")
            r.font.name = Fonts.BODY
            r.font.size = Pt(8)
            r.font.color.rgb = Colors.CHARCOAL
        self._no_borders(t)
        self._spacer(2)

    def add_numbered_list(self, title: str, items: list):
        self.add_subsection(title)
        for i, item in enumerate(items, 1):
            p = self.doc.add_paragraph()
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(2)
            r = p.add_run(f"{i}. ")
            r.font.name = Fonts.BODY
            r.font.size = Pt(9)
            r.font.bold = True
            r.font.color.rgb = Colors.NAVY
            r = p.add_run(item)
            r.font.name = Fonts.BODY
            r.font.size = Pt(9)
            r.font.color.rgb = Colors.CHARCOAL

    def add_footer_text(self, text: str):
        p = self.doc.add_paragraph()
        p.paragraph_format.space_before = Pt(8)
        r = p.add_run(text)
        r.font.name = Fonts.BODY
        r.font.size = Pt(7)
        r.font.color.rgb = Colors.SLATE_MUTED

    def add_page_break(self):
        self.doc.add_page_break()

    # -- Internal Helpers -------------------------------------------------

    def _spacer(self, pts=4):
        s = self.doc.add_paragraph()
        s.paragraph_format.space_before = Pt(0)
        s.paragraph_format.space_after = Pt(pts)

    def _kv_cell(self, cell, text, is_value):
        """Format a single KV cell (label or value)."""
        cell.text = ""
        p = cell.paragraphs[0]
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        if is_value:
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        r = p.add_run(text)
        r.font.name = Fonts.BODY
        r.font.size = Pt(9)
        if is_value:
            r.font.bold = True
            c = self._val_color(text)
            r.font.color.rgb = c if c else Colors.CHARCOAL
        else:
            r.font.color.rgb = Colors.CHARCOAL
        if is_value:
            self._pad(cell, 12, 12, 10, 40)
        else:
            self._pad(cell, 12, 12, 40, 10)

    def _is_numeric(self, text: str) -> bool:
        """Check if text represents a numeric/financial value."""
        t = text.strip()
        if not t:
            return False
        if '$' in t:
            return True
        if t.endswith('%'):
            return True
        if t.lower().endswith('x') and len(t) > 1:
            cleaned = t[:-1].strip().replace(',', '').replace(' ', '')
            try:
                float(cleaned)
                return True
            except ValueError:
                pass
        if 'bps' in t.lower() or 'bp' in t.lower():
            return True
        if any(t.lower().endswith(s) for s in ['/sf', '/unit', ' sf', ' units']):
            return True
        cleaned = t.replace(',', '').replace('(', '').replace(')', '')
        cleaned = cleaned.replace('+', '').replace('-', '', 1).replace(' ', '')
        if not cleaned:
            return False
        try:
            float(cleaned)
            return True
        except ValueError:
            return False

    def _column_alignment(self, data: list, col_idx: int) -> object:
        """Determine alignment for a column based on its data content."""
        if col_idx == 0:
            return WD_ALIGN_PARAGRAPH.LEFT
        numeric_count = 0
        text_count = 0
        for i in range(1, len(data)):
            if col_idx < len(data[i]):
                val = str(data[i][col_idx]).strip()
                if val and val != '\u2014' and val != '-' and val != 'N/A':
                    if self._is_numeric(val):
                        numeric_count += 1
                    else:
                        text_count += 1
        if numeric_count >= text_count and numeric_count > 0:
            return WD_ALIGN_PARAGRAPH.RIGHT
        return WD_ALIGN_PARAGRAPH.LEFT

    def _parse_dscr(self, text: str):
        text = text.strip().lower().replace('x', '')
        try:
            return float(text)
        except ValueError:
            m = re.search(r'(\d+\.?\d*)', text)
            if m:
                try:
                    return float(m.group(1))
                except ValueError:
                    pass
        return None

    def _val_color(self, text: str):
        tl = text.lower().strip()
        if '\u2713' in text:
            return Colors.FOREST_GREEN
        if '\u2717' in text:
            return Colors.CRIMSON
        if re.match(r'^\([\$\d,.%]+\)$', tl):
            return Colors.CRIMSON
        if any(x in tl for x in [
            'pass', 'strong', 'positive', 'favorable', 'healthy',
            'stable', 'excellent', 'institutional', 'meets',
            'manageable', 'low risk', 'approved', 'complete',
            'outperform', 'above average', 'well-positioned',
            'adequate', 'sufficient', 'performing', 'go',
            'attractive', 'accretive', 'robust',
        ]):
            return Colors.FOREST_GREEN
        if any(x in tl for x in [
            'fail', 'critical', 'high risk', 'negative', 'decline',
            'impaired', 'aggressive', 'no-go', 'reject',
            'insufficient', 'deficient', 'distressed', 'default',
            'delinquent', 'below market', 'underperform',
            'significant risk', 'major concern', 'non-compliant',
            'shortfall', 'breach', 'violation',
        ]):
            return Colors.CRIMSON
        if any(x in tl for x in [
            'monitor', 'watch', 'caution', 'moderate', 'marginal',
            'elevated', 'tight', 'constrained', 'neutral',
            'medium risk', 'conditional', 'mixed', 'transitional',
            'below average', 'limited', 'at risk', 'aging',
            'pending', 'deferred',
        ]):
            return Colors.DARK_AMBER
        return None

    # Legacy alias
    def _apply_status_formatting(self, cell, text):
        return self._val_color(text)

    def _shade(self, cell, hex_color):
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        shd = OxmlElement('w:shd')
        shd.set(qn('w:fill'), hex_color)
        tcPr.append(shd)

    def _pad(self, cell, top=60, bottom=60, left=60, right=60):
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        tcMar = OxmlElement('w:tcMar')
        for side, val in [('top', top), ('left', left),
                          ('bottom', bottom), ('right', right)]:
            n = OxmlElement(f'w:{side}')
            n.set(qn('w:w'), str(val))
            n.set(qn('w:type'), 'dxa')
            tcMar.append(n)
        tcPr.append(tcMar)

    def _left_border(self, cell, hex_color, size):
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        tcB = OxmlElement('w:tcBorders')
        l = OxmlElement('w:left')
        l.set(qn('w:val'), 'single')
        l.set(qn('w:sz'), str(size))
        l.set(qn('w:color'), hex_color)
        tcB.append(l)
        tcPr.append(tcB)

    def _cell_border(self, cell, side, hex_color, size):
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        tcB = OxmlElement('w:tcBorders')
        b = OxmlElement(f'w:{side}')
        b.set(qn('w:val'), 'single')
        b.set(qn('w:sz'), str(size))
        b.set(qn('w:color'), hex_color)
        tcB.append(b)
        tcPr.append(tcB)

    def _no_borders(self, table):
        tbl = table._tbl
        tblPr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
        tblB = OxmlElement('w:tblBorders')
        for name in ['top', 'left', 'bottom', 'right', 'insideH', 'insideV']:
            b = OxmlElement(f'w:{name}')
            b.set(qn('w:val'), 'none')
            b.set(qn('w:sz'), '0')
            b.set(qn('w:color'), 'auto')
            tblB.append(b)
        tblPr.append(tblB)
        if tbl.tblPr is None:
            tbl.insert(0, tblPr)

    def _outer_off(self, table):
        tbl = table._tbl
        tblPr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
        tblB = OxmlElement('w:tblBorders')
        for name in ['top', 'left', 'bottom', 'right', 'insideV']:
            b = OxmlElement(f'w:{name}')
            b.set(qn('w:val'), 'none')
            b.set(qn('w:sz'), '0')
            b.set(qn('w:color'), 'auto')
            tblB.append(b)
        tblPr.append(tblB)
        if tbl.tblPr is None:
            tbl.insert(0, tblPr)

    def _strip_borders(self, table):
        tbl = table._tbl
        tblPr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
        tblB = OxmlElement('w:tblBorders')
        iv = OxmlElement('w:insideV')
        iv.set(qn('w:val'), 'single')
        iv.set(qn('w:sz'), '2')
        iv.set(qn('w:color'), Colors.CLOUD_MID_HEX)
        tblB.append(iv)
        for name in ['insideH', 'top', 'bottom', 'left', 'right']:
            b = OxmlElement(f'w:{name}')
            b.set(qn('w:val'), 'none')
            b.set(qn('w:sz'), '0')
            b.set(qn('w:color'), 'auto')
            tblB.append(b)
        tblPr.append(tblB)
        if tbl.tblPr is None:
            tbl.insert(0, tblPr)

    # Legacy method aliases
    def _set_cell_shading(self, cell, hex_color):
        self._shade(cell, hex_color)

    def _set_cell_padding(self, cell, twips):
        self._pad(cell, twips, twips, twips, twips)

    def _set_cell_left_border(self, cell, hex_color, size):
        self._left_border(cell, hex_color, size)

    def _set_cell_border(self, cell, side, hex_color, size):
        self._cell_border(cell, side, hex_color, size)

    def _apply_table_borders_v3(self, table):
        self._outer_off(table)

    def _apply_deal_tape_borders(self, table, cols):
        self._strip_borders(table)

    def _apply_micro_table_borders(self, table):
        self._outer_off(table)

    def _remove_all_borders(self, table):
        self._no_borders(table)

    def save(self, filepath):
        """Save document to file path or file-like object (e.g., BytesIO)."""
        if isinstance(filepath, (str, os.PathLike)):
            d = os.path.dirname(filepath)
            if d:
                os.makedirs(d, exist_ok=True)
            self.doc.save(filepath)
            print(f"[OK] Saved: {filepath}")
            return filepath
        else:
            # File-like object (BytesIO, etc.)
            self.doc.save(filepath)
            return filepath
