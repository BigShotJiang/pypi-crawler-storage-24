"""
pinchfin API — Report Generation Package
==========================================
DOCX generation via ValeriReport (PinchFin v9 design).

(c) Veleta Capital LLC. All rights reserved.
"""
