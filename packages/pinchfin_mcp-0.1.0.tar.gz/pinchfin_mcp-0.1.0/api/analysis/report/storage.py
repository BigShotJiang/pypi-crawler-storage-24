"""
pinchfin API — Temporary DOCX Storage
=======================================
Stores generated DOCX files with 4-hour TTL for download.

Uses a simple filesystem-based approach with periodic cleanup.

(c) Veleta Capital LLC. All rights reserved.
"""

import logging
import os
import time
import uuid
from pathlib import Path
from typing import Optional

LOG = logging.getLogger("pinchfin.analysis.report.storage")

# Default TTL: 4 hours
DEFAULT_TTL_SECONDS = 4 * 60 * 60

# Storage directory
_STORAGE_DIR = Path(os.environ.get("PINCHFIN_DOCX_DIR", "")) or Path(__file__).parent.parent.parent.parent / ".docx_cache"


def _ensure_storage_dir() -> Path:
    """Ensure storage directory exists."""
    _STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    return _STORAGE_DIR


def store_docx(content: bytes, deal_id: str, document_name: str) -> str:
    """
    Store a DOCX file and return its download ID.

    Args:
        content: DOCX file bytes
        deal_id: Deal identifier
        document_name: Document name (e.g., "sponsor_analysis")

    Returns:
        Download ID (UUID) that can be used to retrieve the file.
    """
    storage_dir = _ensure_storage_dir()
    doc_id = str(uuid.uuid4())

    # Create filename with metadata
    timestamp = int(time.time())
    filename = f"{doc_id}_{deal_id}_{document_name}_{timestamp}.docx"
    filepath = storage_dir / filename

    filepath.write_bytes(content)
    LOG.info("Stored DOCX: %s (%d bytes)", filename, len(content))

    return doc_id


def retrieve_docx(doc_id: str) -> Optional[tuple[bytes, str]]:
    """
    Retrieve a stored DOCX file by ID.

    Args:
        doc_id: Download ID returned by store_docx

    Returns:
        Tuple of (file_bytes, original_filename) or None if not found/expired.
    """
    storage_dir = _ensure_storage_dir()

    # Find file matching doc_id
    for filepath in storage_dir.glob(f"{doc_id}_*.docx"):
        # Check TTL
        parts = filepath.stem.split("_")
        if len(parts) >= 4:
            try:
                timestamp = int(parts[-1])
                if time.time() - timestamp > DEFAULT_TTL_SECONDS:
                    filepath.unlink(missing_ok=True)
                    LOG.info("DOCX expired: %s", filepath.name)
                    return None
            except (ValueError, IndexError):
                pass

        # Read and return
        content = filepath.read_bytes()
        # Reconstruct a nice filename
        deal_id = parts[1] if len(parts) >= 2 else "unknown"
        doc_name = parts[2] if len(parts) >= 3 else "document"
        nice_name = f"{deal_id}_{doc_name}.docx"
        return content, nice_name

    return None


def cleanup_expired():
    """Remove all expired DOCX files from storage."""
    storage_dir = _ensure_storage_dir()
    now = time.time()
    removed = 0

    for filepath in storage_dir.glob("*.docx"):
        parts = filepath.stem.split("_")
        if len(parts) >= 4:
            try:
                timestamp = int(parts[-1])
                if now - timestamp > DEFAULT_TTL_SECONDS:
                    filepath.unlink(missing_ok=True)
                    removed += 1
            except (ValueError, IndexError):
                pass

    if removed:
        LOG.info("Cleaned up %d expired DOCX files", removed)
    return removed
