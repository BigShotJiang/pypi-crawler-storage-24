"""
pinchfin API — Report Mapper (JSON → DOCX)
=============================================
Per-tool builder methods that map structured JSON analysis output
to ValeriReport calls, producing branded PinchFin v9 DOCX files.

Each builder is ~80-150 lines. DOCX is deterministic Python,
not AI-generated.

(c) Veleta Capital LLC. All rights reserved.
"""

import io
import logging
from datetime import datetime
from typing import Optional

LOG = logging.getLogger("pinchfin.analysis.report.mapper")


def _get_report_class():
    """Lazy import of ValeriReport to avoid import-time dependency on python-docx."""
    from api.analysis.report.valeri_report_v3 import ValeriReport
    return ValeriReport


def _safe_get(data: dict, *keys, default=""):
    """Safely navigate nested dict keys."""
    current = data
    for key in keys:
        if isinstance(current, dict):
            current = current.get(key, default)
        else:
            return default
    return current if current is not None else default


def _format_dollar(value) -> str:
    """Format dollar amounts per PinchFin v9 rules."""
    if value is None:
        return "N/A"
    if isinstance(value, str):
        return value
    try:
        val = float(value)
    except (ValueError, TypeError):
        return str(value)
    if abs(val) >= 1_000_000:
        return f"${val / 1_000_000:,.1f}M"
    elif abs(val) >= 100_000:
        return f"${val / 1_000:,.0f}K"
    else:
        return f"${val:,.0f}"


def _format_dollar_full(value) -> str:
    """Format dollar amounts in FULL format for Sources & Uses ($42,000,000)."""
    if value is None:
        return "N/A"
    if isinstance(value, str):
        return value
    try:
        val = float(value)
    except (ValueError, TypeError):
        return str(value)
    return f"${val:,.0f}"


def _format_pct(value, decimals=1) -> str:
    """Format percentage values."""
    if value is None:
        return "N/A"
    if isinstance(value, str):
        return value
    try:
        return f"{float(value):.{decimals}f}%"
    except (ValueError, TypeError):
        return str(value)


def _format_dscr(value) -> str:
    """Format DSCR as X.XXx."""
    if value is None:
        return "N/A"
    if isinstance(value, str):
        return value
    try:
        return f"{float(value):.2f}x"
    except (ValueError, TypeError):
        return str(value)


def _format_cap_rate(value) -> str:
    """Format cap rate as X.XX% (always 2 decimals)."""
    if value is None:
        return "N/A"
    if isinstance(value, str):
        return value
    try:
        return f"{float(value):.2f}%"
    except (ValueError, TypeError):
        return str(value)


def _format_rate(value) -> str:
    """Format interest rate as X.XX% (always 2 decimals)."""
    return _format_cap_rate(value)


# ═══════════════════════════════════════════════════════════════════════════
# Existing Builders (5)
# ═══════════════════════════════════════════════════════════════════════════

def build_sponsor_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Sponsor Analysis DOCX from JSON output.

    v9 Report 1 — 7 sections:
      1. Executive Summary (deal tape strip + narrative)
      2. Entity Overview (dual KV: entity profile left, principals right + narrative)
      3. Track Record (notable deals table + KV pairs + narrative)
      4. Financial Capacity (KV pairs + narrative)
      5. Background & Compliance (risk table + litigation + narrative)
      6. Operational Capability (KV pairs + insight boxes)
      7. Recommendation (decision box with GO/NO-GO)
    """
    ValeriReport = _get_report_class()

    title = "Sponsor Analysis"
    subtitle = deal_name or _safe_get(data, "entity_overview", "name") or "Sponsor"
    report = ValeriReport(title, subtitle)

    tier = _safe_get(data, "sponsor_tier", default="N/A")
    recommendation = _safe_get(data, "recommendation", default="")
    go_no_go = _safe_get(data, "go_no_go", default="")
    detail = _safe_get(data, "recommendation_detail", default="")

    # ═══════════════════════════════════════════════════════════════════════
    # Section 1: EXECUTIVE SUMMARY
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Executive Summary")

    report.add_deal_tape_strip({
        "Sponsor Tier": tier,
        "Recommendation": recommendation.title() if recommendation else "N/A",
        "GO/NO-GO": go_no_go or "Pending",
        "Experience Score": str(_safe_get(data, "relevant_experience_score", default="N/A")),
    })

    exec_summary = _safe_get(data, "executive_summary", default="")
    if exec_summary:
        report.add_paragraph(exec_summary)
    elif detail:
        report.add_paragraph(detail)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 2: ENTITY OVERVIEW
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Entity Overview")
    eo = _safe_get(data, "entity_overview", default={})
    if isinstance(eo, dict) and eo:
        # Dual KV: entity profile left, principals/markets right
        left_pairs = []
        for key, label in [
            ("name", "Entity Name"),
            ("legal_structure", "Legal Structure"),
            ("headquarters", "Headquarters"),
            ("formation_date", "Formation Date"),
            ("years_in_operation", "Years in Operation"),
        ]:
            val = eo.get(key)
            if val:
                left_pairs.append((label, str(val)))
        if eo.get("total_units_owned"):
            left_pairs.append(("Total Units Owned/Managed",
                              f"{eo['total_units_owned']:,}" if isinstance(eo['total_units_owned'], (int, float)) else str(eo['total_units_owned'])))
        if eo.get("total_portfolio_value"):
            left_pairs.append(("Portfolio Value", _format_dollar(eo["total_portfolio_value"])))

        right_pairs = []
        principals = eo.get("principals", [])
        if principals:
            if isinstance(principals[0], dict):
                for p in principals[:4]:
                    name = p.get("name", "")
                    role = p.get("role", p.get("title", ""))
                    right_pairs.append((name, role))
            else:
                for i, p in enumerate(principals[:4], 1):
                    right_pairs.append((f"Principal {i}", str(p)))

        markets = eo.get("markets_active", [])
        if markets:
            right_pairs.append(("Markets Active", ", ".join(markets[:8])))

        aum = eo.get("aum", eo.get("assets_under_management"))
        if aum:
            right_pairs.append(("AUM", _format_dollar(aum)))

        if left_pairs and right_pairs:
            report.add_dual_kv("Entity Profile", left_pairs, "Principals & Markets", right_pairs)
        elif left_pairs:
            report.add_kv_pairs(left_pairs, title="Entity Profile")

        entity_narrative = eo.get("narrative", _safe_get(data, "entity_narrative", default=""))
        if entity_narrative:
            report.add_paragraph(entity_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 3: TRACK RECORD
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Track Record")
    tr = _safe_get(data, "track_record", default={})
    if isinstance(tr, dict) and tr:
        pairs = []
        if tr.get("total_deals"):
            pairs.append(("Total Deals", str(tr["total_deals"])))
        if tr.get("total_units"):
            pairs.append(("Total Units", f"{tr['total_units']:,}" if isinstance(tr['total_units'], (int, float)) else str(tr['total_units'])))
        if tr.get("total_value"):
            pairs.append(("Total Value", _format_dollar(tr["total_value"])))
        if tr.get("multifamily_focus_pct") is not None:
            pairs.append(("Multifamily Focus", _format_pct(tr["multifamily_focus_pct"])))
        if tr.get("avg_hold_period_months"):
            pairs.append(("Avg Hold Period", f"{tr['avg_hold_period_months']} months"))
        if tr.get("loan_performance"):
            pairs.append(("Loan Performance", str(tr["loan_performance"])))
        if tr.get("default_history"):
            pairs.append(("Default History", str(tr["default_history"])))
        if pairs:
            report.add_kv_pairs(pairs)

        notable = tr.get("notable_deals", tr.get("notable_transactions", []))
        if notable:
            report.add_subsection("Notable Transactions")
            table_data = [["Property", "Units", "Market", "Acq Date", "Status", "Outcome"]]
            for deal in notable[:10]:
                if isinstance(deal, dict):
                    table_data.append([
                        deal.get("name", deal.get("property", "")),
                        str(deal.get("units", "")),
                        deal.get("market", deal.get("location", "")),
                        str(deal.get("acquisition_date", deal.get("date", ""))),
                        deal.get("status", ""),
                        deal.get("outcome", deal.get("performance", "")),
                    ])
            if len(table_data) > 1:
                report.add_table(table_data)

        tr_narrative = tr.get("narrative", "")
        if tr_narrative:
            report.add_paragraph(tr_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 4: FINANCIAL CAPACITY
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Financial Capacity")
    fc = _safe_get(data, "financial_capacity", default={})
    if isinstance(fc, dict) and fc:
        pairs = []
        for key, label in [
            ("estimated_net_worth", "Estimated Net Worth"),
            ("net_worth_to_loan_ratio", "NW/Loan Ratio"),
            ("liquidity", "Liquidity"),
            ("liquidity_assessment", "Liquidity Assessment"),
            ("leverage_assessment", "Leverage Assessment"),
            ("guaranty_capacity", "Guaranty Capacity"),
            ("cash_reserves", "Cash Reserves"),
            ("credit_score_range", "Credit Score Range"),
        ]:
            val = fc.get(key)
            if val:
                if "net_worth" in key or "liquidity" == key or "reserves" in key:
                    pairs.append((label, _format_dollar(val) if isinstance(val, (int, float)) else str(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

        fc_narrative = fc.get("narrative", "")
        if fc_narrative:
            report.add_paragraph(fc_narrative)

        # Financial capacity assessment insight
        fc_assessment = fc.get("assessment", "")
        if fc_assessment:
            report.add_callout_box("Financial Capacity Assessment", fc_assessment, style="primary")

    # ═══════════════════════════════════════════════════════════════════════
    # Section 5: BACKGROUND & COMPLIANCE
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Background & Compliance")
    bc = _safe_get(data, "background_check", default={})
    if isinstance(bc, dict) and bc:
        # Background check table
        check_items = []
        for key, label in [
            ("default_history", "Default History"),
            ("bankruptcy_check", "Bankruptcy"),
            ("criminal_check", "Criminal"),
            ("ofac_check", "OFAC/Sanctions"),
            ("sec_check", "SEC/Regulatory"),
        ]:
            val = bc.get(key)
            if val:
                status = "✓" if str(val).lower() in ("clear", "clean", "none", "no issues", "pass") else "✗"
                check_items.append([label, str(val), status])

        if check_items:
            table_data = [["Check", "Finding", "Status"]]
            table_data.extend(check_items)
            report.add_table(table_data)

        litigation = bc.get("litigation_findings", bc.get("litigation", []))
        if litigation and isinstance(litigation, list) and len(litigation) > 0:
            report.add_subsection("Litigation Findings")
            for item in litigation:
                if isinstance(item, dict):
                    report.add_paragraph(f"- {item.get('case', item.get('description', str(item)))}")
                else:
                    report.add_paragraph(f"- {item}")
        elif isinstance(litigation, list):
            report.add_paragraph("No litigation findings identified.")

        risk_flags = bc.get("risk_flags", [])
        if risk_flags:
            report.add_subsection("Risk Flags")
            risk_table = [["#", "Flag", "Severity", "Detail"]]
            for i, flag in enumerate(risk_flags, 1):
                if isinstance(flag, dict):
                    risk_table.append([
                        str(i),
                        flag.get("flag", flag.get("name", "")),
                        flag.get("severity", ""),
                        flag.get("detail", flag.get("description", "")),
                    ])
                else:
                    risk_table.append([str(i), str(flag), "", ""])
            if len(risk_table) > 1:
                report.add_risk_table(risk_table, severity_column=2)

        bc_narrative = bc.get("narrative", "")
        if bc_narrative:
            report.add_paragraph(bc_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 6: OPERATIONAL CAPABILITY
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Operational Capability")
    oc = _safe_get(data, "operational_capability", default={})
    if isinstance(oc, dict) and oc:
        pairs = []
        for key, label in [
            ("property_management", "Property Management"),
            ("renovation_execution", "Renovation Execution"),
            ("lease_up_capability", "Lease-Up Capability"),
            ("asset_management", "Asset Management"),
            ("construction_management", "Construction Management"),
        ]:
            val = oc.get(key)
            if val:
                pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

        oc_narrative = oc.get("narrative", "")
        if oc_narrative:
            report.add_paragraph(oc_narrative)

    # Strengths & Concerns as insight boxes
    strengths = data.get("strengths", [])
    concerns = data.get("concerns", [])
    if strengths:
        for s in strengths[:5]:
            if isinstance(s, dict):
                report.add_insight(
                    s.get("title", "Strength"),
                    s.get("finding", s.get("detail", str(s))),
                    s.get("impact", ""),
                    s.get("action", ""),
                    risk_level="positive",
                )
            else:
                report.add_insight("Strength", str(s), "", "", risk_level="positive")
    if concerns:
        for c in concerns[:5]:
            if isinstance(c, dict):
                report.add_insight(
                    c.get("title", "Concern"),
                    c.get("finding", c.get("detail", str(c))),
                    c.get("impact", ""),
                    c.get("action", ""),
                    risk_level="warning",
                )
            else:
                report.add_insight("Concern", str(c), "", "", risk_level="warning")

    # ═══════════════════════════════════════════════════════════════════════
    # Section 7: RECOMMENDATION
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Recommendation")
    rec_points = []
    if detail:
        rec_points.append(detail)
    rec_narrative = _safe_get(data, "recommendation_narrative", default="")
    if rec_narrative:
        rec_points.append(rec_narrative)
    if not rec_points:
        rec_points = [f"Tier {tier} sponsor — {recommendation}" if recommendation else f"Tier {tier} sponsor assessment."]

    conditions = data.get("conditions", [])
    if conditions:
        cond_text = "Conditions: " + "; ".join(
            c.get("condition", str(c)) if isinstance(c, dict) else str(c)
            for c in conditions[:5]
        )
        rec_points.append(cond_text)

    report.add_decision_box(
        f"SPONSOR ASSESSMENT: {go_no_go or recommendation.upper() or 'PENDING'}",
        rec_points,
    )

    # Save to bytes
    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_market_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Market & Submarket Analysis DOCX from JSON output.

    v9 Report 2 — 8 sections:
      1. Executive Summary (deal tape strip + narrative)
      2. MSA Economic Profile (dual KV: demographics left, economy right + narrative)
      3. Employment Analysis (KV pairs + top employers table + narrative)
      4. Multifamily Fundamentals (KV pairs + rent growth table + narrative)
      5. Supply Pipeline (KV pairs + pipeline table + supply risk insight)
      6. Submarket Deep Dive (dual KV: submarket left, location data right + narrative)
      7. Supportable Assumptions (KV pairs + justification narrative)
      8. Market Assessment (risk table + recommendation box)
    """
    ValeriReport = _get_report_class()

    msa_name = _safe_get(data, "msa", "name", default="Market")
    report = ValeriReport("Market & Submarket Analysis", deal_name or msa_name)

    rating = _safe_get(data, "market_rating", default="")
    summary = _safe_get(data, "summary", default="")

    # ═══════════════════════════════════════════════════════════════════════
    # Section 1: EXECUTIVE SUMMARY
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Executive Summary")

    strip = {}
    if rating:
        strip["Market Rating"] = rating.title()
    sub_name = _safe_get(data, "submarket", "name", default="")
    if sub_name:
        strip["Submarket"] = sub_name
    if msa_name and msa_name != "Market":
        strip["MSA"] = msa_name
    supply_risk = _safe_get(data, "supply_pipeline", "supply_risk_rating", default="")
    if supply_risk:
        strip["Supply Risk"] = supply_risk.title()
    if strip:
        report.add_deal_tape_strip(strip)

    if summary:
        report.add_paragraph(summary)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 2: MSA ECONOMIC PROFILE
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("MSA Economic Profile")
    msa = _safe_get(data, "msa", default={})
    if isinstance(msa, dict) and msa:
        left_pairs = []
        if msa.get("name"):
            left_pairs.append(("MSA", msa["name"]))
        if msa.get("population"):
            left_pairs.append(("Population", f"{msa['population']:,}" if isinstance(msa['population'], (int, float)) else str(msa['population'])))
        if msa.get("population_growth_pct") is not None:
            left_pairs.append(("Population Growth", _format_pct(msa["population_growth_pct"])))
        if msa.get("median_household_income"):
            left_pairs.append(("Median HH Income", _format_dollar(msa["median_household_income"])))
        if msa.get("median_age"):
            left_pairs.append(("Median Age", str(msa["median_age"])))
        if msa.get("cost_of_living_index"):
            left_pairs.append(("Cost of Living Index", str(msa["cost_of_living_index"])))

        right_pairs = []
        if msa.get("gdp") or msa.get("gdp_growth_pct"):
            if msa.get("gdp"):
                right_pairs.append(("Metro GDP", _format_dollar(msa["gdp"])))
            if msa.get("gdp_growth_pct") is not None:
                right_pairs.append(("GDP Growth", _format_pct(msa["gdp_growth_pct"])))
        drivers = msa.get("economic_drivers", [])
        if drivers:
            right_pairs.append(("Key Economic Drivers", ", ".join(drivers[:6])))
        if msa.get("major_industries"):
            right_pairs.append(("Major Industries", ", ".join(msa["major_industries"][:5])))
        if msa.get("education_attainment"):
            right_pairs.append(("College Attainment", str(msa["education_attainment"])))

        if left_pairs and right_pairs:
            report.add_dual_kv("Demographics", left_pairs, "Economy", right_pairs)
        elif left_pairs:
            report.add_kv_pairs(left_pairs)

        msa_narrative = msa.get("narrative", "")
        if msa_narrative:
            report.add_paragraph(msa_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 3: EMPLOYMENT ANALYSIS
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Employment Analysis")
    emp = _safe_get(data, "employment", default={})
    if isinstance(emp, dict) and emp:
        pairs = []
        if emp.get("unemployment_rate") is not None:
            pairs.append(("Unemployment Rate", _format_pct(emp["unemployment_rate"])))
        if emp.get("job_growth_pct") is not None:
            pairs.append(("Job Growth", _format_pct(emp["job_growth_pct"])))
        if emp.get("total_employment"):
            pairs.append(("Total Employment", f"{emp['total_employment']:,}" if isinstance(emp['total_employment'], (int, float)) else str(emp['total_employment'])))
        if emp.get("industry_diversification"):
            pairs.append(("Industry Diversification", emp["industry_diversification"]))
        if emp.get("labor_force_participation"):
            pairs.append(("Labor Force Participation", _format_pct(emp["labor_force_participation"])))
        if pairs:
            report.add_kv_pairs(pairs)

        employers = emp.get("top_employers", [])
        if employers:
            report.add_subsection("Top Employers")
            if isinstance(employers[0], dict):
                table_data = [["Employer", "Industry", "Employees"]]
                for e in employers[:10]:
                    table_data.append([
                        e.get("name", ""),
                        e.get("industry", e.get("sector", "")),
                        str(e.get("employees", e.get("employee_count", ""))),
                    ])
                report.add_table(table_data)
            else:
                report.add_paragraph(", ".join(str(e) for e in employers[:10]))

        emp_narrative = emp.get("narrative", "")
        if emp_narrative:
            report.add_paragraph(emp_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 4: MULTIFAMILY FUNDAMENTALS
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Multifamily Fundamentals")
    mf = _safe_get(data, "multifamily_fundamentals", default={})
    if isinstance(mf, dict) and mf:
        pairs = []
        if mf.get("vacancy_rate_pct") is not None:
            pairs.append(("Vacancy Rate", _format_pct(mf["vacancy_rate_pct"])))
        if mf.get("effective_rent_avg") is not None:
            pairs.append(("Avg Effective Rent", _format_dollar(mf["effective_rent_avg"])))
        if mf.get("rent_growth_yoy_pct") is not None:
            pairs.append(("Rent Growth YoY", _format_pct(mf["rent_growth_yoy_pct"])))
        if mf.get("absorption_units") is not None:
            pairs.append(("Net Absorption", f"{mf['absorption_units']:,} units" if isinstance(mf['absorption_units'], (int, float)) else str(mf['absorption_units'])))
        if mf.get("inventory_units") is not None:
            pairs.append(("Total Inventory", f"{mf['inventory_units']:,} units" if isinstance(mf['inventory_units'], (int, float)) else str(mf['inventory_units'])))
        if mf.get("concession_pct") is not None:
            pairs.append(("Avg Concessions", _format_pct(mf["concession_pct"])))
        if pairs:
            report.add_kv_pairs(pairs)

        # Rent growth trend table
        rent_trends = mf.get("rent_trends", mf.get("historical_rents", []))
        if rent_trends and isinstance(rent_trends, list):
            report.add_subsection("Rent Growth Trend")
            table_data = [["Period", "Avg Rent", "Growth", "Vacancy"]]
            for t in rent_trends:
                if isinstance(t, dict):
                    table_data.append([
                        str(t.get("period", t.get("year", ""))),
                        _format_dollar(t.get("avg_rent", t.get("rent"))),
                        _format_pct(t.get("growth_pct", t.get("rent_growth"))),
                        _format_pct(t.get("vacancy_pct", t.get("vacancy"))),
                    ])
            if len(table_data) > 1:
                report.add_table(table_data)

        mf_narrative = mf.get("narrative", "")
        if mf_narrative:
            report.add_paragraph(mf_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 5: SUPPLY PIPELINE
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Supply Pipeline")
    sp = _safe_get(data, "supply_pipeline", default={})
    if isinstance(sp, dict) and sp:
        pairs = []
        if sp.get("units_under_construction") is not None:
            pairs.append(("Under Construction", f"{sp['units_under_construction']:,} units" if isinstance(sp['units_under_construction'], (int, float)) else str(sp['units_under_construction'])))
        if sp.get("units_planned") is not None:
            pairs.append(("Planned/Proposed", f"{sp['units_planned']:,} units" if isinstance(sp['units_planned'], (int, float)) else str(sp['units_planned'])))
        if sp.get("pct_of_inventory") is not None:
            pairs.append(("% of Inventory", _format_pct(sp["pct_of_inventory"])))
        if sp.get("deliveries_next_12_months") is not None:
            pairs.append(("12-Month Deliveries", f"{sp['deliveries_next_12_months']:,} units" if isinstance(sp['deliveries_next_12_months'], (int, float)) else str(sp['deliveries_next_12_months'])))
        if sp.get("supply_risk_rating"):
            pairs.append(("Supply Risk Rating", sp["supply_risk_rating"].title()))
        if pairs:
            report.add_kv_pairs(pairs)

        # Pipeline projects table
        projects = sp.get("notable_projects", sp.get("projects", []))
        if projects:
            report.add_subsection("Notable Pipeline Projects")
            table_data = [["Project", "Units", "Delivery", "Distance", "Status"]]
            for p in projects[:8]:
                if isinstance(p, dict):
                    table_data.append([
                        p.get("name", p.get("project", "")),
                        str(p.get("units", "")),
                        str(p.get("delivery", p.get("delivery_date", ""))),
                        f"{p.get('distance_miles', ''):.1f} mi" if p.get("distance_miles") else str(p.get("distance", "")),
                        p.get("status", ""),
                    ])
            if len(table_data) > 1:
                report.add_table(table_data)

        sp_narrative = sp.get("narrative", "")
        if sp_narrative:
            report.add_paragraph(sp_narrative)

        # Supply risk insight
        if sp.get("supply_risk_rating"):
            risk_level = "warning" if sp["supply_risk_rating"].lower() in ("elevated", "high") else "positive"
            report.add_insight(
                "Supply Risk Assessment",
                f"Supply risk rated {sp['supply_risk_rating'].title()}.",
                sp.get("supply_risk_detail", ""),
                sp.get("supply_risk_mitigant", ""),
                risk_level=risk_level,
            )

    # ═══════════════════════════════════════════════════════════════════════
    # Section 6: SUBMARKET DEEP DIVE
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Submarket Deep Dive")
    sub = _safe_get(data, "submarket", default={})
    if isinstance(sub, dict) and sub:
        left_pairs = []
        if sub.get("name"):
            left_pairs.append(("Submarket", sub["name"]))
        if sub.get("vacancy_rate_pct") is not None:
            left_pairs.append(("Vacancy", _format_pct(sub["vacancy_rate_pct"])))
        if sub.get("avg_rent") is not None:
            left_pairs.append(("Avg Rent", _format_dollar(sub["avg_rent"])))
        if sub.get("rent_growth_pct") is not None:
            left_pairs.append(("Rent Growth", _format_pct(sub["rent_growth_pct"])))
        if sub.get("inventory_units") is not None:
            left_pairs.append(("Inventory", f"{sub['inventory_units']:,} units" if isinstance(sub['inventory_units'], (int, float)) else str(sub['inventory_units'])))
        if sub.get("absorption_units") is not None:
            left_pairs.append(("Net Absorption", f"{sub['absorption_units']:,} units" if isinstance(sub['absorption_units'], (int, float)) else str(sub['absorption_units'])))

        right_pairs = []
        location = _safe_get(data, "location_data", default={})
        if isinstance(location, dict):
            if location.get("walk_score") is not None:
                right_pairs.append(("Walk Score", str(location["walk_score"])))
            if location.get("transit_score") is not None:
                right_pairs.append(("Transit Score", str(location["transit_score"])))
            if location.get("bike_score") is not None:
                right_pairs.append(("Bike Score", str(location["bike_score"])))
            if location.get("flood_zone"):
                right_pairs.append(("Flood Zone", location["flood_zone"]))
            if location.get("median_hh_income"):
                right_pairs.append(("Tract Median HH Income", _format_dollar(location["median_hh_income"])))
            if location.get("hud_fmr"):
                right_pairs.append(("HUD FMR", _format_dollar(location["hud_fmr"])))

        if left_pairs and right_pairs:
            report.add_dual_kv(sub.get("name", "Submarket"), left_pairs, "Location Data", right_pairs)
        elif left_pairs:
            report.add_kv_pairs(left_pairs)

        sub_narrative = sub.get("narrative", "")
        if sub_narrative:
            report.add_paragraph(sub_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 7: SUPPORTABLE ASSUMPTIONS
    # ═══════════════════════════════════════════════════════════════════════
    sa = _safe_get(data, "supportable_assumptions", default={})
    if isinstance(sa, dict) and sa:
        report.add_section("Supportable Assumptions")
        pairs = []
        if sa.get("rent_growth_pct") is not None:
            pairs.append(("Rent Growth", _format_pct(sa["rent_growth_pct"])))
        if sa.get("vacancy_rate_pct") is not None:
            pairs.append(("Stabilized Vacancy", _format_pct(sa["vacancy_rate_pct"])))
        if sa.get("exit_cap_rate_pct") is not None:
            pairs.append(("Exit Cap Rate", _format_cap_rate(sa["exit_cap_rate_pct"])))
        if sa.get("expense_growth_pct") is not None:
            pairs.append(("Expense Growth", _format_pct(sa["expense_growth_pct"])))
        if sa.get("absorption_pace"):
            pairs.append(("Absorption Pace", str(sa["absorption_pace"])))
        if pairs:
            report.add_kv_pairs(pairs)
        if sa.get("justification"):
            report.add_paragraph(sa["justification"])

    # ═══════════════════════════════════════════════════════════════════════
    # Section 8: MARKET ASSESSMENT
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Market Assessment")

    # Strengths & Risks as risk table
    strengths = data.get("strengths", [])
    risks = data.get("risks", [])

    if strengths:
        report.add_subsection("Market Strengths")
        for s in strengths:
            if isinstance(s, str):
                report.add_paragraph(f"- {s}")
            elif isinstance(s, dict):
                report.add_paragraph(f"- {s.get('strength', s.get('detail', str(s)))}")

    if risks:
        report.add_subsection("Market Risks")
        risk_table = [["#", "Risk", "Severity", "Assessment"]]
        for i, r in enumerate(risks, 1):
            if isinstance(r, dict):
                risk_table.append([
                    str(i),
                    r.get("risk", r.get("name", "")),
                    r.get("severity", "Med"),
                    r.get("assessment", r.get("detail", "")),
                ])
            else:
                risk_table.append([str(i), str(r), "Med", ""])
        if len(risk_table) > 1:
            report.add_risk_table(risk_table, severity_column=2)

    # Assessment conclusion
    assessment = _safe_get(data, "assessment", default="")
    if assessment:
        report.add_paragraph(assessment)

    report.add_highlight_box(
        f"Market Rating: {rating.upper()}" if rating else "Market assessment complete.",
        style="primary",
    )

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_comps_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Comparable Analysis DOCX from JSON output.

    v9 Report 3 — 6 sections:
      1. Executive Summary (deal tape strip + narrative)
      2. Subject Property Profile (KV pairs + property context)
      3. Rent Comparables (comp table min 5 + subject row + avg row + rent analysis KVs + narrative)
      4. Sales Comparables (comp table min 3 + subject row + avg row + value positioning KVs + narrative)
      5. Valuation Synthesis (dual KV: as-is left, stabilized right + cap rate sensitivity + narrative)
      6. Assessment (broker variance table + strengths/concerns + recommendation)
    """
    ValeriReport = _get_report_class()
    report = ValeriReport("Comparable Analysis", deal_name or "Property")

    summary = _safe_get(data, "summary", default="")

    # ═══════════════════════════════════════════════════════════════════════
    # Section 1: EXECUTIVE SUMMARY
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Executive Summary")

    strip = {}
    ra = _safe_get(data, "rent_analysis", default={})
    if isinstance(ra, dict):
        if ra.get("avg_market_rent") is not None:
            strip["Avg Market Rent"] = _format_dollar(ra["avg_market_rent"])
        if ra.get("loss_to_lease_pct") is not None:
            strip["Loss-to-Lease"] = _format_pct(ra["loss_to_lease_pct"])
    va = _safe_get(data, "value_analysis", default={})
    if isinstance(va, dict):
        if va.get("avg_cap_rate_pct") is not None:
            strip["Avg Sale Cap Rate"] = _format_cap_rate(va["avg_cap_rate_pct"])
        if va.get("as_stabilized_value") is not None:
            strip["Stabilized Value"] = _format_dollar(va["as_stabilized_value"])
    rent_comps_count = len(data.get("rent_comps", []))
    sales_comps_count = len(data.get("sales_comps", []))
    if rent_comps_count:
        strip["Rent Comps"] = str(rent_comps_count)
    if sales_comps_count:
        strip["Sale Comps"] = str(sales_comps_count)
    if strip:
        report.add_deal_tape_strip(strip)

    if summary:
        report.add_paragraph(summary)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 2: SUBJECT PROPERTY PROFILE
    # ═══════════════════════════════════════════════════════════════════════
    subject = _safe_get(data, "subject_property", _safe_get(data, "subject", default={}))
    if isinstance(subject, dict) and subject:
        report.add_section("Subject Property Profile")
        pairs = []
        for key, label in [
            ("name", "Property"),
            ("address", "Address"),
            ("units", "Units"),
            ("year_built", "Year Built"),
            ("property_type", "Property Type"),
            ("avg_unit_sf", "Avg Unit SF"),
            ("occupancy_pct", "Current Occupancy"),
            ("avg_in_place_rent", "Avg In-Place Rent"),
            ("avg_market_rent", "Lender UW Rent"),
            ("condition", "Condition"),
        ]:
            val = subject.get(key)
            if val is not None and val != "":
                if "rent" in key or "value" in key:
                    pairs.append((label, _format_dollar(val)))
                elif "pct" in key or "occupancy" in key:
                    pairs.append((label, _format_pct(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

        subject_narrative = subject.get("narrative", "")
        if subject_narrative:
            report.add_paragraph(subject_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 3: RENT COMPARABLES
    # ═══════════════════════════════════════════════════════════════════════
    rent_comps = data.get("rent_comps", [])
    report.add_section("Rent Comparables")

    # Intro paragraph
    rent_intro = _safe_get(data, "rent_comps_intro", default="")
    if rent_intro:
        report.add_paragraph(rent_intro)
    elif rent_comps:
        report.add_paragraph(
            f"{len(rent_comps)} rent comparable properties were identified within "
            f"the subject's competitive set, filtered by geography, vintage, and product type."
        )

    if rent_comps:
        table_data = [["Property", "Year", "Units", "Avg Rent", "Avg SF", "$/SF", "Occ"]]

        # Subject row first (if available)
        if isinstance(subject, dict) and subject:
            subj_rent = subject.get("avg_in_place_rent", subject.get("avg_rent"))
            subj_sf = subject.get("avg_unit_sf", subject.get("avg_sf"))
            subj_psf = ""
            if subj_rent and subj_sf:
                try:
                    subj_psf = f"${float(subj_rent) / float(subj_sf):.2f}"
                except (ValueError, TypeError, ZeroDivisionError):
                    subj_psf = ""
            table_data.append([
                f"{subject.get('name', 'Subject')} (Subject)",
                str(subject.get("year_built", "")),
                str(subject.get("units", "")),
                _format_dollar(subj_rent),
                str(subj_sf) if subj_sf else "",
                subj_psf,
                _format_pct(subject.get("occupancy_pct")) if subject.get("occupancy_pct") else "",
            ])

        for comp in rent_comps:
            if isinstance(comp, dict):
                avg_rent = comp.get("avg_rent")
                avg_sf = comp.get("avg_sf", comp.get("avg_unit_sf"))
                psf = ""
                if avg_rent and avg_sf:
                    try:
                        psf = f"${float(avg_rent) / float(avg_sf):.2f}"
                    except (ValueError, TypeError, ZeroDivisionError):
                        psf = str(comp.get("rent_per_sf", ""))
                elif comp.get("rent_per_sf"):
                    psf = f"${comp['rent_per_sf']:.2f}" if isinstance(comp['rent_per_sf'], (int, float)) else str(comp['rent_per_sf'])
                table_data.append([
                    comp.get("name", comp.get("property", "")),
                    str(comp.get("year_built", comp.get("year", ""))),
                    str(comp.get("units", "")),
                    _format_dollar(avg_rent),
                    str(avg_sf) if avg_sf else "",
                    psf,
                    _format_pct(comp.get("occupancy_pct", comp.get("occ"))) if comp.get("occupancy_pct", comp.get("occ")) else "",
                ])

        # Comp average row
        comp_avg = _safe_get(data, "rent_comp_average", default={})
        if isinstance(comp_avg, dict) and comp_avg:
            table_data.append([
                "Comp Average",
                "",
                str(comp_avg.get("units", "")),
                _format_dollar(comp_avg.get("avg_rent")),
                str(comp_avg.get("avg_sf", "")) if comp_avg.get("avg_sf") else "",
                f"${comp_avg['rent_per_sf']:.2f}" if comp_avg.get("rent_per_sf") else "",
                _format_pct(comp_avg.get("occupancy_pct")) if comp_avg.get("occupancy_pct") else "",
            ])

        if len(table_data) > 1:
            report.add_table(table_data)

    # Rent analysis KV pairs
    if isinstance(ra, dict) and ra:
        pairs = []
        if ra.get("avg_market_rent") is not None:
            pairs.append(("Avg Market Rent (Comps)", _format_dollar(ra["avg_market_rent"])))
        if ra.get("subject_in_place_rent") is not None:
            pairs.append(("Subject In-Place Rent", _format_dollar(ra["subject_in_place_rent"])))
        if ra.get("lender_underwritten_rent") is not None:
            pairs.append(("Lender Underwritten Rent", _format_dollar(ra["lender_underwritten_rent"])))
        if ra.get("loss_to_lease_pct") is not None:
            pairs.append(("Loss-to-Lease", _format_pct(ra["loss_to_lease_pct"])))
        if ra.get("rent_premium_discount") is not None:
            pairs.append(("Subject vs. Comps", _format_pct(ra["rent_premium_discount"])))
        if pairs:
            report.add_kv_pairs(pairs)

    # Positioning narrative
    rent_narrative = _safe_get(data, "rent_positioning_narrative", ra.get("narrative", "") if isinstance(ra, dict) else "")
    if rent_narrative:
        report.add_paragraph(rent_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 4: SALES COMPARABLES
    # ═══════════════════════════════════════════════════════════════════════
    sales_comps = data.get("sales_comps", [])
    report.add_section("Sales Comparables")

    # Intro paragraph
    sales_intro = _safe_get(data, "sales_comps_intro", default="")
    if sales_intro:
        report.add_paragraph(sales_intro)
    elif sales_comps:
        report.add_paragraph(
            f"{len(sales_comps)} sales comparable transactions were identified "
            f"within the subject's geographic and product-type universe."
        )

    if sales_comps:
        table_data = [["Property", "Units", "Year", "Sale Date", "Price", "$/Unit", "Cap Rate"]]
        for comp in sales_comps:
            if isinstance(comp, dict):
                cap_rate = comp.get("cap_rate_pct", comp.get("cap_rate"))
                table_data.append([
                    comp.get("name", comp.get("property", "")),
                    str(comp.get("units", "")),
                    str(comp.get("year_built", comp.get("year", ""))),
                    comp.get("sale_date", comp.get("date", "")),
                    _format_dollar(comp.get("sale_price", comp.get("price"))),
                    _format_dollar(comp.get("price_per_unit", comp.get("per_unit"))),
                    _format_cap_rate(cap_rate) if cap_rate is not None else "",
                ])

        # Comp average row
        sales_avg = _safe_get(data, "sales_comp_average", default={})
        if isinstance(sales_avg, dict) and sales_avg:
            table_data.append([
                "Comp Average",
                "",
                "",
                "",
                _format_dollar(sales_avg.get("avg_price")),
                _format_dollar(sales_avg.get("avg_per_unit")),
                _format_cap_rate(sales_avg.get("avg_cap_rate")) if sales_avg.get("avg_cap_rate") is not None else "",
            ])

        # Subject row
        if isinstance(va, dict) and va:
            subj_value = va.get("as_stabilized_value", va.get("subject_value"))
            subj_per_unit = va.get("value_per_unit", va.get("subject_per_unit"))
            subj_cap = va.get("exit_cap_rate_pct", va.get("subject_cap_rate"))
            if subj_value:
                table_data.append([
                    f"{subject.get('name', 'Subject') if isinstance(subject, dict) else 'Subject'} (Lender UW)",
                    str(subject.get("units", "")) if isinstance(subject, dict) else "",
                    "",
                    "",
                    _format_dollar(subj_value),
                    _format_dollar(subj_per_unit) if subj_per_unit else "",
                    _format_cap_rate(subj_cap) if subj_cap is not None else "",
                ])

        if len(table_data) > 1:
            report.add_table(table_data)

    # Subject positioning KV pairs
    if isinstance(va, dict) and va:
        pos_pairs = []
        if va.get("as_stabilized_value") is not None:
            val_str = _format_dollar(va["as_stabilized_value"])
            if va.get("value_per_unit"):
                val_str += f" ({_format_dollar(va['value_per_unit'])}/unit)"
            pos_pairs.append(("Subject Implied Value (Stabilized)", val_str))
        if va.get("subject_vs_comp_avg_pct") is not None:
            pos_pairs.append(("Subject vs. Comp Avg $/Unit", _format_pct(va["subject_vs_comp_avg_pct"])))
        if va.get("loan_basis_per_unit") is not None:
            pos_pairs.append(("Loan Basis $/Unit", _format_dollar(va["loan_basis_per_unit"])))
        if va.get("equity_cushion_pct") is not None:
            pos_pairs.append(("Equity Cushion", _format_pct(va["equity_cushion_pct"])))
        if va.get("exit_cap_rate_pct") is not None:
            pos_pairs.append(("Exit Cap Rate Used", _format_cap_rate(va["exit_cap_rate_pct"])))
        if pos_pairs:
            report.add_kv_pairs(pos_pairs)

    # Positioning narrative
    sales_narrative = _safe_get(data, "sales_positioning_narrative", va.get("narrative", "") if isinstance(va, dict) else "")
    if sales_narrative:
        report.add_paragraph(sales_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 5: VALUATION SYNTHESIS
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Valuation Synthesis")
    if isinstance(va, dict) and va:
        left_pairs = []
        if va.get("as_is_value") is not None:
            val_str = _format_dollar(va["as_is_value"])
            if va.get("as_is_per_unit"):
                val_str += f" ({_format_dollar(va['as_is_per_unit'])}/unit)"
            left_pairs.append(("As-Is Value", val_str))
        if va.get("as_is_cap_rate") is not None:
            left_pairs.append(("As-Is Cap Rate", _format_cap_rate(va["as_is_cap_rate"])))
        if va.get("in_place_noi") is not None:
            left_pairs.append(("In-Place NOI", _format_dollar(va["in_place_noi"])))

        right_pairs = []
        if va.get("as_stabilized_value") is not None:
            val_str = _format_dollar(va["as_stabilized_value"])
            if va.get("value_per_unit"):
                val_str += f" ({_format_dollar(va['value_per_unit'])}/unit)"
            right_pairs.append(("Stabilized Value", val_str))
        if va.get("exit_cap_rate_pct", va.get("stabilized_cap_rate")) is not None:
            right_pairs.append(("Exit Cap Rate", _format_cap_rate(va.get("exit_cap_rate_pct", va.get("stabilized_cap_rate")))))
        if va.get("stabilized_noi") is not None:
            right_pairs.append(("Stabilized NOI", _format_dollar(va["stabilized_noi"])))
        if va.get("avg_cap_rate_pct") is not None:
            right_pairs.append(("Comp Avg Cap Rate", _format_cap_rate(va["avg_cap_rate_pct"])))

        if left_pairs and right_pairs:
            report.add_dual_kv("As-Is Valuation", left_pairs, "Stabilized Valuation", right_pairs)
        elif left_pairs:
            report.add_kv_pairs(left_pairs)
        elif right_pairs:
            report.add_kv_pairs(right_pairs)

    # Cap rate sensitivity (if provided)
    cap_sensitivity = data.get("cap_rate_sensitivity", [])
    if cap_sensitivity:
        report.add_subsection("Cap Rate Sensitivity")
        report.add_sensitivity_table(
            cap_sensitivity,
            base_row_index=_find_base_row(cap_sensitivity),
        )

    valuation_narrative = _safe_get(data, "valuation_narrative", default="")
    if valuation_narrative:
        report.add_paragraph(valuation_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 6: ASSESSMENT
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Assessment")

    # Broker variance
    broker_variance = _safe_get(data, "broker_variance", default={})
    if isinstance(broker_variance, dict) and broker_variance:
        report.add_subsection("Broker Variance Analysis")
        bv_pairs = []
        if broker_variance.get("broker_value") is not None:
            bv_pairs.append(("Broker Value", _format_dollar(broker_variance["broker_value"])))
        if broker_variance.get("lender_value") is not None:
            bv_pairs.append(("Lender Value", _format_dollar(broker_variance["lender_value"])))
        if broker_variance.get("variance_pct") is not None:
            bv_pairs.append(("Variance", _format_pct(broker_variance["variance_pct"])))
        if broker_variance.get("assessment"):
            bv_pairs.append(("Assessment", str(broker_variance["assessment"])))
        if bv_pairs:
            report.add_kv_pairs(bv_pairs)
        if broker_variance.get("narrative"):
            report.add_paragraph(broker_variance["narrative"])

    strengths = data.get("strengths", [])
    concerns = data.get("concerns", [])
    if strengths:
        report.add_subsection("Comp Set Strengths")
        for s in strengths:
            if isinstance(s, str):
                report.add_paragraph(f"- {s}")
            elif isinstance(s, dict):
                report.add_paragraph(f"- {s.get('detail', str(s))}")
    if concerns:
        report.add_subsection("Comp Set Concerns")
        for c in concerns:
            if isinstance(c, str):
                report.add_paragraph(f"- {c}")
            elif isinstance(c, dict):
                report.add_paragraph(f"- {c.get('detail', str(c))}")

    # Overall assessment narrative
    assessment = _safe_get(data, "assessment", default="")
    if assessment:
        report.add_paragraph(assessment)

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_cash_flow_report(data: dict, deal_name: str = "") -> bytes:
    """Build Cash Flow Underwriting DOCX from JSON output."""
    ValeriReport = _get_report_class()
    report = ValeriReport("Cash Flow Underwriting Analysis", deal_name or "Property")

    # ── Executive Summary ──
    report.add_section("EXECUTIVE SUMMARY")
    summary = _safe_get(data, "summary", default="")
    if summary:
        report.add_paragraph(summary)

    # ── Income ──
    income = _safe_get(data, "income", default={})
    if isinstance(income, dict) and income:
        report.add_section("INCOME ANALYSIS")
        pairs = []
        for key, label in [
            ("gpr", "Gross Potential Rent"),
            ("other_income", "Other Income"),
            ("vacancy_loss", "Vacancy Loss"),
            ("concessions", "Concessions"),
            ("bad_debt", "Bad Debt"),
            ("effective_gross_income", "Effective Gross Income"),
        ]:
            val = income.get(key)
            if val is not None:
                pairs.append((label, _format_dollar(val)))
        if income.get("vacancy_pct") is not None:
            pairs.append(("Vacancy Rate", _format_pct(income["vacancy_pct"])))
        if income.get("egi_per_unit") is not None:
            pairs.append(("EGI/Unit", _format_dollar(income["egi_per_unit"])))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Expenses ──
    expenses = _safe_get(data, "expenses", default={})
    if isinstance(expenses, dict) and expenses:
        report.add_section("OPERATING EXPENSES")
        pairs = []
        if expenses.get("total_operating_expenses") is not None:
            pairs.append(("Total OpEx", _format_dollar(expenses["total_operating_expenses"])))
        if expenses.get("opex_per_unit") is not None:
            pairs.append(("OpEx/Unit", _format_dollar(expenses["opex_per_unit"])))
        if expenses.get("opex_ratio_pct") is not None:
            pairs.append(("OpEx Ratio", _format_pct(expenses["opex_ratio_pct"])))
        if pairs:
            report.add_kv_pairs(pairs)

        breakdown = expenses.get("breakdown", {})
        if isinstance(breakdown, dict) and breakdown:
            report.add_subsection("Expense Breakdown")
            table_data = [["Category", "Amount"]]
            for cat, amt in breakdown.items():
                table_data.append([cat.replace("_", " ").title(), _format_dollar(amt)])
            report.add_table(table_data)

    # ── NOI ──
    noi = _safe_get(data, "noi", default={})
    if isinstance(noi, dict) and noi:
        report.add_section("NET OPERATING INCOME")
        pairs = []
        if noi.get("stabilized_noi") is not None:
            pairs.append(("Stabilized NOI", _format_dollar(noi["stabilized_noi"])))
        if noi.get("noi_per_unit") is not None:
            pairs.append(("NOI/Unit", _format_dollar(noi["noi_per_unit"])))
        if noi.get("in_place_noi") is not None:
            pairs.append(("In-Place NOI", _format_dollar(noi["in_place_noi"])))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Dual Scenario ──
    dual = _safe_get(data, "dual_scenario", default={})
    if isinstance(dual, dict) and dual:
        lender = dual.get("lender_underwrite", {})
        sponsor = dual.get("sponsor_proforma", {})
        if lender or sponsor:
            report.add_section("DUAL SCENARIO ANALYSIS")
            left_pairs = [(k.replace("_", " ").title(), _format_dollar(v) if isinstance(v, (int, float)) else str(v))
                          for k, v in (lender.items() if isinstance(lender, dict) else [])]
            right_pairs = [(k.replace("_", " ").title(), _format_dollar(v) if isinstance(v, (int, float)) else str(v))
                           for k, v in (sponsor.items() if isinstance(sponsor, dict) else [])]
            if left_pairs and right_pairs:
                report.add_dual_kv("LENDER UNDERWRITE", left_pairs[:8], "SPONSOR PROFORMA", right_pairs[:8])

    # ── Projections ──
    projections = data.get("projections", [])
    if projections:
        report.add_section("5-YEAR PROJECTIONS")
        table_data = [["Year", "GPR", "EGI", "OpEx", "NOI", "NOI/Unit"]]
        for proj in projections:
            if isinstance(proj, dict):
                table_data.append([
                    str(proj.get("year", "")),
                    _format_dollar(proj.get("gpr")),
                    _format_dollar(proj.get("egi")),
                    _format_dollar(proj.get("total_opex")),
                    _format_dollar(proj.get("noi")),
                    _format_dollar(proj.get("noi_per_unit")),
                ])
        report.add_table(table_data)

    # ── Sizing Waterfall ──
    sizing = _safe_get(data, "sizing_waterfall", default={})
    if isinstance(sizing, dict) and sizing:
        report.add_section("LOAN SIZING WATERFALL")
        constraints = sizing.get("constraints", {})
        if isinstance(constraints, dict):
            table_data = [["Constraint", "Value", "Threshold", "Max Loan", "Status"]]
            for name, info in constraints.items():
                if isinstance(info, dict):
                    table_data.append([
                        name.replace("_", " ").title(),
                        str(info.get("value", "")),
                        str(info.get("threshold", "")),
                        _format_dollar(info.get("max_loan")),
                        "✓" if info.get("status") == "pass" else "✗",
                    ])
            report.add_table(table_data)

        if sizing.get("binding_constraint"):
            report.add_highlight_box(
                f"Binding Constraint: {sizing['binding_constraint'].replace('_', ' ').title()} — "
                f"Max Loan: {_format_dollar(sizing.get('max_loan'))}",
                style="primary",
            )

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_quick_review_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Quick Review DOCX from JSON output.

    v9 Report 4 — Full 18-section LOCKED structure per QUICK_REVIEW_MEMO_FORMAT_SPEC v1.0.
    Gold standard: Parklyn v8 memo.

    Sections:
      1.  Deal Overview (opening narrative + dual KV: Property Profile / Loan Summary)
      2.  Sources & Uses (side-by-side S&U table + narrative)
      3.  Credit Metrics (intro + metrics table: As-Is / Stabilized / Threshold / Status)
      4.  Lender Rent Underwriting (narrative + unit mix/rent table + supporting KVs)
      5.  Rent Comparables (intro + comp table min 5 + positioning narrative)
      6.  Sales Comparables (intro + comp table min 3 + positioning KVs + narrative)
      7.  Conditional Section (deal-specific, if applicable)
      8.  Three-Year Cash Flow (Y1/Y2/Y3 cash flow table)
      9.  Sizing Waterfall (narrative + 6-constraint table with BINDING)
      10. Interest Reserve Analysis (KV pairs + monthly draw table + narrative)
      11. Sensitivity Analysis (TWO SEPARATE tables: cap rate + vacancy)
      12. Sponsor Overview (narrative + insight/warning box)
      13. Market Overview (dual KV: MSA left, submarket right + narrative)
      14. Key Risks & Mitigants (risk table 5-8 risks)
      15. Lender Returns (unlevered ONLY — IRR/MOIC at 12/24/36 months)
      16. Diligence Needs List (needs table with Priority + Workstream)
      17. Recommendation (recommendation box with 2-3 paragraphs)
      18. Sources (source list by category)
    """
    ValeriReport = _get_report_class()

    prop = _safe_get(data, "property", default={})
    if not isinstance(prop, dict):
        prop = {}
    address = prop.get("address", "Property")
    prop_name = prop.get("name", deal_name or address)
    recommendation = _safe_get(data, "recommendation", default="")
    screen = _safe_get(data, "screen_result", default=recommendation)
    units = prop.get("unit_count", prop.get("units", ""))

    report = ValeriReport("Quick Review - First-Look Screening", deal_name or prop_name)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 1: DEAL OVERVIEW
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Deal Overview")

    # Opening narrative paragraph
    deal_narrative = _safe_get(data, "deal_overview_narrative",
                               _safe_get(data, "deal_overview", "narrative",
                                         default=_safe_get(data, "summary", default="")))
    if deal_narrative:
        report.add_paragraph(deal_narrative)

    # Dual KV: Property Profile (left) / Loan Summary (right)
    left_pairs = []
    left_pairs.append(("Property", prop_name))
    if prop.get("address"):
        left_pairs.append(("Location", prop["address"]))
    if prop.get("property_type", prop.get("type")):
        left_pairs.append(("Type", str(prop.get("property_type", prop.get("type", "")))))
    if units:
        unit_str = str(units)
        if prop.get("total_sf"):
            unit_str += f" | {prop['total_sf']:,} SF" if isinstance(prop['total_sf'], (int, float)) else f" | {prop['total_sf']} SF"
        if prop.get("avg_sf"):
            unit_str += f" | {prop['avg_sf']} avg SF"
        left_pairs.append(("Residential", unit_str))
    if prop.get("retail_sf"):
        left_pairs.append(("Retail/Commercial", f"{prop['retail_sf']:,} SF" if isinstance(prop['retail_sf'], (int, float)) else str(prop['retail_sf'])))
    if prop.get("year_built") or prop.get("construction_status"):
        left_pairs.append(("Construction/Condition", str(prop.get("construction_status", prop.get("year_built", "")))))
    if prop.get("occupancy_pct") is not None:
        left_pairs.append(("Occupancy", _format_pct(prop["occupancy_pct"])))
    if prop.get("manager", prop.get("property_manager")):
        left_pairs.append(("Manager", str(prop.get("manager", prop.get("property_manager", "")))))

    loan = _safe_get(data, "loan", _safe_get(data, "loan_summary", default={}))
    if not isinstance(loan, dict):
        loan = {}
    sizing = _safe_get(data, "sizing", default={})
    if not isinstance(sizing, dict):
        sizing = {}

    right_pairs = []
    rec_loan = sizing.get("recommended_loan", sizing.get("max_loan_from_waterfall", loan.get("recommended_loan", loan.get("loan_amount"))))
    if rec_loan is not None:
        loan_str = _format_dollar(rec_loan)
        if units:
            try:
                per_unit = float(rec_loan) / float(units)
                loan_str += f" ({_format_dollar(per_unit)}/unit)"
            except (ValueError, TypeError, ZeroDivisionError):
                pass
        right_pairs.append(("Recommended Loan", loan_str))
    sponsor_request = sizing.get("loan_requested", loan.get("loan_requested", loan.get("sponsor_request")))
    if sponsor_request is not None:
        req_str = _format_dollar(sponsor_request)
        if units:
            try:
                per_unit = float(sponsor_request) / float(units)
                req_str += f" ({_format_dollar(per_unit)}/unit)"
            except (ValueError, TypeError, ZeroDivisionError):
                pass
        right_pairs.append(("Sponsor Request", req_str))
    if rec_loan and sponsor_request:
        try:
            variance = float(rec_loan) - float(sponsor_request)
            direction = "above" if variance > 0 else "below"
            right_pairs.append(("Variance", f"({_format_dollar(abs(variance))}) {direction} request"))
        except (ValueError, TypeError):
            pass
    rate = loan.get("rate", loan.get("all_in_rate", sizing.get("rate_assumption")))
    if rate:
        right_pairs.append(("Rate", _format_rate(rate) if isinstance(rate, (int, float)) else str(rate)))
    term = loan.get("term", loan.get("structure"))
    if term:
        right_pairs.append(("Term", str(term)))
    annual_ds = loan.get("annual_debt_service", loan.get("debt_service"))
    if annual_ds is not None:
        right_pairs.append(("Annual Debt Service", _format_dollar_full(annual_ds)))
    binding = sizing.get("binding_constraint", loan.get("binding_constraint", ""))
    if binding:
        right_pairs.append(("Binding Constraint", binding.replace("_", " ").title() if isinstance(binding, str) else str(binding)))
    source = loan.get("source", loan.get("deal_source", ""))
    if source:
        right_pairs.append(("Source", str(source)))

    if left_pairs and right_pairs:
        report.add_dual_kv("Property Profile", left_pairs, "Loan Summary", right_pairs)
    elif left_pairs:
        report.add_kv_pairs(left_pairs, title="Property Profile")

    # ═══════════════════════════════════════════════════════════════════════
    # Section 2: SOURCES & USES
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Sources & Uses")

    sources = data.get("sources", _safe_get(data, "sources_and_uses", "sources", default=[]))
    uses = data.get("uses", _safe_get(data, "sources_and_uses", "uses", default=[]))
    if sources and uses:
        # Format as full dollar amounts for S&U
        formatted_sources = []
        for s in sources:
            if isinstance(s, (list, tuple)) and len(s) >= 2:
                formatted_sources.append([s[0], _format_dollar_full(s[1]) if isinstance(s[1], (int, float)) else str(s[1])])
            elif isinstance(s, dict):
                formatted_sources.append([s.get("name", s.get("source", "")), _format_dollar_full(s.get("amount")) if isinstance(s.get("amount"), (int, float)) else str(s.get("amount", ""))])
            else:
                formatted_sources.append(s)
        formatted_uses = []
        for u in uses:
            if isinstance(u, (list, tuple)) and len(u) >= 2:
                formatted_uses.append([u[0], _format_dollar_full(u[1]) if isinstance(u[1], (int, float)) else str(u[1])])
            elif isinstance(u, dict):
                formatted_uses.append([u.get("name", u.get("use", "")), _format_dollar_full(u.get("amount")) if isinstance(u.get("amount"), (int, float)) else str(u.get("amount", ""))])
            else:
                formatted_uses.append(u)
        report.add_sources_uses_table(formatted_sources, formatted_uses)

    su_narrative = _safe_get(data, "sources_uses_narrative",
                             _safe_get(data, "sources_and_uses", "narrative", default=""))
    if su_narrative:
        report.add_paragraph(su_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 3: CREDIT METRICS
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Credit Metrics")

    metrics_intro = _safe_get(data, "credit_metrics_intro",
                              _safe_get(data, "credit_metrics", "intro", default=""))
    if metrics_intro:
        report.add_paragraph(metrics_intro)

    # Credit metrics table: Metric | As-Is/Y1 | Stabilized | Threshold | Status
    credit_metrics = data.get("credit_metrics", data.get("key_metrics", {}))
    if isinstance(credit_metrics, dict) and credit_metrics:
        # Check if it has nested metric dicts
        metrics_list = credit_metrics.get("metrics", [])
        if metrics_list and isinstance(metrics_list, list):
            table_data = [["Metric", "As-Is / Y1", "Stabilized", "Threshold", "Status"]]
            for m in metrics_list:
                if isinstance(m, dict):
                    status_raw = m.get("status", "")
                    if status_raw in ("pass", "✓", True):
                        status = "✓"
                    elif status_raw in ("soft", "Soft"):
                        status = "Soft ✓"
                    elif status_raw in ("fail", "✗", False):
                        status = "✗"
                    else:
                        status = str(status_raw) if status_raw else "✓"
                    table_data.append([
                        m.get("name", m.get("metric", "")),
                        str(m.get("as_is", m.get("y1", m.get("going_in", "—")))),
                        str(m.get("stabilized", m.get("proforma", "—"))),
                        str(m.get("threshold", "")),
                        status,
                    ])
            if len(table_data) > 1:
                report.add_table(table_data)
        else:
            # Flat dict format: key → {value, threshold, status}
            table_data = [["Metric", "As-Is / Y1", "Stabilized", "Threshold", "Status"]]
            for name, info in credit_metrics.items():
                if name in ("intro", "narrative", "metrics"):
                    continue
                if isinstance(info, dict):
                    status_raw = info.get("status", "")
                    if status_raw in ("pass", "✓", True):
                        status = "✓"
                    elif status_raw in ("soft", "Soft"):
                        status = "Soft ✓"
                    elif status_raw in ("fail", "✗", False):
                        status = "✗"
                    else:
                        status = str(status_raw) if status_raw else "✓"
                    table_data.append([
                        name.replace("_", " ").upper(),
                        str(info.get("as_is", info.get("y1", "—"))),
                        str(info.get("stabilized", info.get("value", "—"))),
                        str(info.get("threshold", "")),
                        status,
                    ])
            if len(table_data) > 1:
                report.add_table(table_data)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 4: LENDER RENT UNDERWRITING
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Lender Rent Underwriting")

    rent_uw = _safe_get(data, "lender_rent_underwriting", _safe_get(data, "rent_underwriting", default={}))
    if not isinstance(rent_uw, dict):
        rent_uw = {}

    rent_narrative = rent_uw.get("narrative", _safe_get(data, "rent_uw_narrative", default=""))
    if rent_narrative:
        report.add_paragraph(rent_narrative)

    # Unit mix / rent table
    unit_mix = rent_uw.get("unit_mix", data.get("unit_mix", []))
    if unit_mix:
        table_data = [["Type", "Units", "SF", "Sponsor", "Lender", "vs Sponsor", "$/SF"]]
        for mix in unit_mix:
            if isinstance(mix, dict):
                sponsor_rent = mix.get("sponsor_rent", mix.get("broker_rent"))
                lender_rent = mix.get("lender_rent", mix.get("rent_roll_rent", mix.get("uw_rent")))
                variance = ""
                if sponsor_rent and lender_rent:
                    try:
                        var_pct = (float(lender_rent) - float(sponsor_rent)) / float(sponsor_rent) * 100
                        variance = f"{var_pct:+.1f}%"
                    except (ValueError, TypeError, ZeroDivisionError):
                        variance = str(mix.get("variance", ""))
                elif mix.get("variance"):
                    variance = str(mix["variance"])
                rent_psf = ""
                if lender_rent and mix.get("sf", mix.get("avg_sf")):
                    try:
                        rent_psf = f"${float(lender_rent) / float(mix.get('sf', mix.get('avg_sf'))):.2f}"
                    except (ValueError, TypeError, ZeroDivisionError):
                        rent_psf = str(mix.get("rent_per_sf", ""))
                elif mix.get("rent_per_sf"):
                    rent_psf = f"${mix['rent_per_sf']:.2f}" if isinstance(mix['rent_per_sf'], (int, float)) else str(mix['rent_per_sf'])
                table_data.append([
                    mix.get("type", mix.get("unit_type", "")),
                    str(mix.get("units", mix.get("count", ""))),
                    str(mix.get("sf", mix.get("avg_sf", ""))),
                    _format_dollar(sponsor_rent) if sponsor_rent else "—",
                    _format_dollar(lender_rent) if lender_rent else "—",
                    variance or "—",
                    rent_psf or "—",
                ])
        # Totals row
        totals = rent_uw.get("totals", rent_uw.get("weighted_avg", {}))
        if isinstance(totals, dict) and totals:
            table_data.append([
                "Wtd Avg / Total",
                str(totals.get("units", totals.get("total_units", ""))),
                str(totals.get("sf", totals.get("avg_sf", ""))),
                _format_dollar(totals.get("sponsor_rent")) if totals.get("sponsor_rent") else "—",
                _format_dollar(totals.get("lender_rent")) if totals.get("lender_rent") else "—",
                str(totals.get("variance", "")) if totals.get("variance") else "—",
                "",
            ])
        if len(table_data) > 1:
            report.add_table(table_data)

    # Supporting KV pairs
    rent_kvs = []
    if rent_uw.get("monthly_gpr") is not None:
        rent_kvs.append(("Lender Monthly GPR", _format_dollar_full(rent_uw["monthly_gpr"])))
    if rent_uw.get("annual_gpr") is not None:
        rent_kvs.append(("Lender Annual GPR", _format_dollar_full(rent_uw["annual_gpr"])))
    if rent_uw.get("rent_basis"):
        rent_kvs.append(("Rent Basis", str(rent_uw["rent_basis"])))
    if rent_uw.get("lease_evidence"):
        rent_kvs.append(("Pre-Leased / Lease Evidence", str(rent_uw["lease_evidence"])))
    if rent_uw.get("key_comps"):
        rent_kvs.append(("Key Comps", str(rent_uw["key_comps"])))
    if rent_uw.get("rent_growth") is not None:
        rent_kvs.append(("Rent Growth Assumption", _format_pct(rent_uw["rent_growth"])))
    if rent_uw.get("stabilized_occupancy") is not None:
        rent_kvs.append(("Stabilized Occupancy", _format_pct(rent_uw["stabilized_occupancy"])))
    if rent_kvs:
        report.add_kv_pairs(rent_kvs)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 5: RENT COMPARABLES
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Rent Comparables")

    rent_comps_intro = _safe_get(data, "rent_comps_intro", default="")
    if rent_comps_intro:
        report.add_paragraph(rent_comps_intro)

    rent_comps = data.get("rent_comps", [])
    if rent_comps:
        table_data = [["Property", "Year", "Units", "Avg Rent", "Avg SF", "$/SF", "Occ"]]
        for comp in rent_comps:
            if isinstance(comp, dict):
                avg_rent = comp.get("avg_rent", comp.get("rent"))
                avg_sf = comp.get("avg_sf", comp.get("avg_unit_sf"))
                psf = ""
                if avg_rent and avg_sf:
                    try:
                        psf = f"${float(avg_rent) / float(avg_sf):.2f}"
                    except (ValueError, TypeError, ZeroDivisionError):
                        psf = str(comp.get("rent_per_sf", ""))
                elif comp.get("rent_per_sf"):
                    psf = f"${comp['rent_per_sf']:.2f}" if isinstance(comp['rent_per_sf'], (int, float)) else str(comp['rent_per_sf'])
                table_data.append([
                    comp.get("name", comp.get("property", "")),
                    str(comp.get("year_built", comp.get("year", ""))),
                    str(comp.get("units", "")),
                    _format_dollar(avg_rent),
                    str(avg_sf) if avg_sf else "",
                    psf,
                    _format_pct(comp.get("occupancy_pct", comp.get("occ"))) if comp.get("occupancy_pct", comp.get("occ")) else "",
                ])
        if len(table_data) > 1:
            report.add_table(table_data)

    rent_positioning = _safe_get(data, "rent_positioning_narrative", default="")
    if rent_positioning:
        report.add_paragraph(rent_positioning)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 6: SALES COMPARABLES
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Sales Comparables")

    sales_comps_intro = _safe_get(data, "sales_comps_intro", default="")
    if sales_comps_intro:
        report.add_paragraph(sales_comps_intro)

    sales_comps = data.get("sales_comps", [])
    if sales_comps:
        table_data = [["Property", "Units", "Year", "Sale Date", "Price", "$/Unit", "Cap Rate"]]
        for comp in sales_comps:
            if isinstance(comp, dict):
                cap_rate = comp.get("cap_rate_pct", comp.get("cap_rate"))
                table_data.append([
                    comp.get("name", comp.get("property", "")),
                    str(comp.get("units", "")),
                    str(comp.get("year_built", comp.get("year", ""))),
                    comp.get("sale_date", comp.get("date", "")),
                    _format_dollar(comp.get("sale_price", comp.get("price"))),
                    _format_dollar(comp.get("price_per_unit", comp.get("per_unit"))),
                    _format_cap_rate(cap_rate) if cap_rate is not None else "",
                ])
        if len(table_data) > 1:
            report.add_table(table_data)

    # Subject positioning KVs
    sales_positioning = _safe_get(data, "sales_positioning", default={})
    if isinstance(sales_positioning, dict) and sales_positioning:
        pos_pairs = []
        if sales_positioning.get("subject_implied_value") is not None:
            val_str = _format_dollar(sales_positioning["subject_implied_value"])
            if sales_positioning.get("subject_per_unit"):
                val_str += f" ({_format_dollar(sales_positioning['subject_per_unit'])}/unit)"
            pos_pairs.append(("Subject Implied Value", val_str))
        if sales_positioning.get("subject_vs_comp_avg") is not None:
            pos_pairs.append(("Subject vs. Comp Avg $/Unit", str(sales_positioning["subject_vs_comp_avg"])))
        if sales_positioning.get("loan_basis_per_unit") is not None:
            pos_pairs.append(("Loan Basis $/Unit", _format_dollar(sales_positioning["loan_basis_per_unit"])))
        if sales_positioning.get("exit_cap_rate") is not None:
            pos_pairs.append(("Exit Cap Rate Used", _format_cap_rate(sales_positioning["exit_cap_rate"])))
        if pos_pairs:
            report.add_kv_pairs(pos_pairs)

    sales_narrative = _safe_get(data, "sales_positioning_narrative", default="")
    if sales_narrative:
        report.add_paragraph(sales_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 7: CONDITIONAL — Deal-Specific Section(s)
    # ═══════════════════════════════════════════════════════════════════════
    conditional = data.get("conditional_sections", data.get("conditional", []))
    if isinstance(conditional, list):
        for section in conditional[:2]:
            if isinstance(section, dict):
                section_title = section.get("title", section.get("name", "Additional Analysis"))
                report.add_section(section_title)
                if section.get("narrative"):
                    report.add_paragraph(section["narrative"])
                if section.get("table") and isinstance(section["table"], list):
                    report.add_table(section["table"])
                if section.get("kv_pairs") and isinstance(section["kv_pairs"], list):
                    report.add_kv_pairs(section["kv_pairs"])
    elif isinstance(conditional, dict) and conditional:
        section_title = conditional.get("title", "Additional Analysis")
        report.add_section(section_title)
        if conditional.get("narrative"):
            report.add_paragraph(conditional["narrative"])

    # ═══════════════════════════════════════════════════════════════════════
    # Section 8: THREE-YEAR CASH FLOW (LENDER UNDERWRITE)
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Three-Year Cash Flow (Lender Underwrite)")

    cash_flow = data.get("cash_flow", data.get("three_year_cash_flow", []))
    if isinstance(cash_flow, list) and cash_flow:
        # List of rows (pre-formatted table data)
        report.add_table(cash_flow)
    elif isinstance(cash_flow, dict):
        # Build from structured Y1/Y2/Y3 data
        y1 = cash_flow.get("y1", cash_flow.get("year_1", {}))
        y2 = cash_flow.get("y2", cash_flow.get("year_2", {}))
        y3 = cash_flow.get("y3", cash_flow.get("year_3", {}))
        if isinstance(y1, dict) or isinstance(y2, dict) or isinstance(y3, dict):
            if not isinstance(y1, dict):
                y1 = {}
            if not isinstance(y2, dict):
                y2 = {}
            if not isinstance(y3, dict):
                y3 = {}
            cf_rows = [
                ["", "Y1", "Y2", "Y3"],
            ]
            cf_fields = [
                ("occupancy", "Average Occupancy", "pct"),
                ("gpr", "Residential GPR", "dollar_full"),
                ("gross_collected", "Gross Collected", "dollar_full"),
                ("concessions", "Less Concessions", "dollar_full_neg"),
                ("credit_loss", "Less Credit Loss", "dollar_full_neg"),
                ("net_residential", "Net Residential", "dollar_full"),
                ("retail_income", "Retail Income", "dollar_full"),
                ("other_income", "Other Income", "dollar_full"),
                ("egi", "Effective Gross Income", "dollar_full"),
                ("total_opex", "Total Operating Expenses", "dollar_full_neg"),
                ("noi", "Net Operating Income", "dollar_full"),
            ]
            for key, label, fmt in cf_fields:
                v1 = y1.get(key)
                v2 = y2.get(key)
                v3 = y3.get(key)
                if v1 is not None or v2 is not None or v3 is not None:
                    row = [label]
                    for v in [v1, v2, v3]:
                        if v is None:
                            row.append("—")
                        elif fmt == "pct":
                            row.append(_format_pct(v))
                        elif fmt == "dollar_full":
                            row.append(_format_dollar_full(v))
                        elif fmt == "dollar_full_neg":
                            row.append(f"({_format_dollar_full(abs(float(v)))})" if v else "—")
                        else:
                            row.append(str(v))
                    cf_rows.append(row)

            # Sizing NOI row (if two-track)
            sizing_noi = cash_flow.get("sizing_noi")
            if sizing_noi is not None:
                cf_rows.append(["", "", "", ""])
                cf_rows.append(["Sizing NOI", "—", "—", _format_dollar_full(sizing_noi)])

            if len(cf_rows) > 1:
                report.add_table(cf_rows)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 9: SIZING WATERFALL
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Sizing Waterfall")

    sizing_narrative = _safe_get(data, "sizing_narrative",
                                  _safe_get(data, "sizing", "narrative", default=""))
    if sizing_narrative:
        report.add_paragraph(sizing_narrative)

    # Waterfall table: Constraint | Basis/Calculation | Max Loan | Status
    waterfall = data.get("sizing_waterfall", sizing.get("waterfall", sizing.get("constraints", [])))
    if isinstance(waterfall, list) and waterfall:
        table_data = [["Constraint", "Basis / Calculation", "Max Loan", "Status"]]
        for c in waterfall:
            if isinstance(c, dict):
                status_raw = c.get("status", "")
                if status_raw in ("binding", "BINDING"):
                    status = "BINDING"
                elif status_raw in ("soft", "Soft"):
                    status = "Soft"
                elif status_raw in ("pass", "✓", True):
                    status = "✓"
                elif status_raw in ("fail", "✗", False):
                    status = "✗"
                else:
                    status = str(status_raw) if status_raw else "✓"
                table_data.append([
                    c.get("name", c.get("constraint", "")),
                    c.get("basis", c.get("calculation", c.get("value", ""))),
                    _format_dollar(c.get("max_loan")),
                    status,
                ])
        # Lender Maximum row
        lender_max = sizing.get("max_loan_from_waterfall", sizing.get("recommended_loan"))
        if lender_max is not None:
            max_str = _format_dollar(lender_max)
            if units:
                try:
                    per_unit = float(lender_max) / float(units)
                    max_str += f" ({_format_dollar(per_unit)}/unit)"
                except (ValueError, TypeError, ZeroDivisionError):
                    pass
            table_data.append(["Lender Maximum", "", max_str, ""])
        if len(table_data) > 1:
            report.add_table(table_data)
    elif isinstance(waterfall, dict) and waterfall:
        table_data = [["Constraint", "Basis / Calculation", "Max Loan", "Status"]]
        for name, info in waterfall.items():
            if isinstance(info, dict):
                status_raw = info.get("status", "")
                if status_raw in ("binding", "BINDING"):
                    status = "BINDING"
                elif status_raw in ("soft", "Soft"):
                    status = "Soft"
                elif status_raw in ("pass", "✓", True):
                    status = "✓"
                else:
                    status = "✗"
                table_data.append([
                    name.replace("_", " ").title(),
                    str(info.get("basis", info.get("calculation", info.get("value", "")))),
                    _format_dollar(info.get("max_loan")),
                    status,
                ])
        if len(table_data) > 1:
            report.add_table(table_data)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 10: INTEREST RESERVE ANALYSIS
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Interest Reserve Analysis")

    ir = _safe_get(data, "interest_reserve", default={})
    if isinstance(ir, dict) and ir:
        ir_kvs = []
        for key, label in [
            ("reserve_amount", "Interest Reserve"),
            ("monthly_debt_service", "Monthly Debt Service"),
            ("monthly_burn", "Monthly Burn (Empty)"),
            ("coverage_months_empty", "Coverage on Empty Building"),
            ("self_sustaining_month", "Self-Sustaining Month"),
            ("total_projected_draws", "Total Projected IR Draws"),
            ("ending_balance", "IR Ending Balance"),
        ]:
            val = ir.get(key)
            if val is not None:
                if "month" in key and "coverage" not in key and "sustaining" not in key:
                    ir_kvs.append((label, _format_dollar(val)))
                elif "month" in key.lower() and isinstance(val, (int, float)):
                    ir_kvs.append((label, f"{val} months" if "coverage" in key else f"Month {int(val)}"))
                elif isinstance(val, (int, float)):
                    ir_kvs.append((label, _format_dollar(val)))
                else:
                    ir_kvs.append((label, str(val)))
        if ir_kvs:
            report.add_kv_pairs(ir_kvs)

        # Monthly draw table
        monthly_draws = ir.get("monthly_draws", ir.get("draw_schedule", []))
        if monthly_draws and isinstance(monthly_draws, list):
            draw_table = [["Month", "Units", "Occ %", "Net CF", "IR Draw", "IR Balance"]]
            for draw in monthly_draws:
                if isinstance(draw, dict):
                    draw_table.append([
                        str(draw.get("month", "")),
                        str(draw.get("units", "")),
                        _format_pct(draw.get("occupancy_pct")) if draw.get("occupancy_pct") is not None else "",
                        _format_dollar(draw.get("net_cf", draw.get("net_cash_flow"))),
                        _format_dollar(draw.get("ir_draw", draw.get("draw"))),
                        _format_dollar(draw.get("ir_balance", draw.get("balance"))),
                    ])
            if len(draw_table) > 1:
                report.add_table(draw_table)

        ir_narrative = ir.get("narrative", "")
        if ir_narrative:
            report.add_paragraph(ir_narrative)
    else:
        report.add_paragraph("No interest reserve required — stabilized asset with no lease-up period.", secondary=True)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 11: SENSITIVITY ANALYSIS — TWO SEPARATE TABLES
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Sensitivity Analysis")

    # Table 1: Cap Rate Sensitivity
    cap_sensitivity = data.get("cap_rate_sensitivity", [])
    if cap_sensitivity:
        report.add_subsection("Cap Rate Sensitivity")
        report.add_sensitivity_table(
            cap_sensitivity,
            base_row_index=_find_base_row(cap_sensitivity),
        )

    # Table 2: Vacancy Stress — ALWAYS separate from cap rate
    vacancy_sensitivity = data.get("vacancy_sensitivity", data.get("vacancy_stress", []))
    if vacancy_sensitivity:
        report.add_subsection("Vacancy Stress (Sizing Basis)")
        report.add_sensitivity_table(
            vacancy_sensitivity,
            base_row_index=_find_base_row(vacancy_sensitivity),
            dscr_column=_find_dscr_column(vacancy_sensitivity),
        )

    # ═══════════════════════════════════════════════════════════════════════
    # Section 12: SPONSOR OVERVIEW
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Sponsor Overview")

    sponsor = _safe_get(data, "sponsor_overview", _safe_get(data, "sponsor_assessment", default={}))
    if not isinstance(sponsor, dict):
        sponsor = {}

    sponsor_narrative = sponsor.get("narrative", sponsor.get("detail", ""))
    if sponsor_narrative:
        report.add_paragraph(sponsor_narrative)
    else:
        # Build minimal sponsor paragraph from KV data
        sponsor_parts = []
        if sponsor.get("name"):
            sponsor_parts.append(f"Sponsor: {sponsor['name']}.")
        if sponsor.get("tier"):
            sponsor_parts.append(f"Tier {sponsor['tier']} classification.")
        if sponsor.get("track_record"):
            sponsor_parts.append(str(sponsor["track_record"]))
        if sponsor_parts:
            report.add_paragraph(" ".join(sponsor_parts))

    # Insight/warning box
    sponsor_flags = sponsor.get("flags", sponsor.get("concerns", []))
    if sponsor_flags:
        if isinstance(sponsor_flags, list) and sponsor_flags:
            for flag in sponsor_flags[:3]:
                if isinstance(flag, dict):
                    report.add_insight(
                        flag.get("title", flag.get("flag", "Sponsor Flag")),
                        flag.get("finding", flag.get("detail", str(flag))),
                        flag.get("impact", ""),
                        flag.get("action", flag.get("mitigant", "")),
                        risk_level=flag.get("severity", "warning"),
                    )
                else:
                    report.add_insight("Sponsor Note", str(flag), "", "", risk_level="warning")
    elif sponsor.get("recommendation"):
        report.add_callout_box(
            "Sponsor Assessment",
            f"{sponsor.get('name', 'Sponsor')} — {sponsor.get('recommendation', 'Pending')}",
            style="primary",
        )

    # ═══════════════════════════════════════════════════════════════════════
    # Section 13: MARKET OVERVIEW
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Market Overview")

    market = _safe_get(data, "market_overview", _safe_get(data, "market", default={}))
    if not isinstance(market, dict):
        market = {}

    # Dual KV: MSA (left) / Submarket (right)
    msa_pairs = []
    msa = market.get("msa", {})
    if isinstance(msa, dict):
        if msa.get("population"):
            msa_pairs.append(("Population", f"{msa['population']:,}" if isinstance(msa['population'], (int, float)) else str(msa['population'])))
        if msa.get("employment"):
            msa_pairs.append(("Employment", str(msa["employment"])))
        if msa.get("unemployment_rate") is not None:
            msa_pairs.append(("Unemployment", _format_pct(msa["unemployment_rate"])))
        if msa.get("mf_vacancy") is not None:
            msa_pairs.append(("MF Vacancy", _format_pct(msa["mf_vacancy"])))
        if msa.get("pipeline_units") is not None:
            msa_pairs.append(("Pipeline", f"{msa['pipeline_units']:,} units" if isinstance(msa['pipeline_units'], (int, float)) else str(msa['pipeline_units'])))
        if msa.get("absorption"):
            msa_pairs.append(("Absorption", str(msa["absorption"])))
    # Fallback: market-level fields
    if not msa_pairs:
        if market.get("population"):
            msa_pairs.append(("Population", str(market["population"])))
        if market.get("unemployment_rate") is not None:
            msa_pairs.append(("Unemployment", _format_pct(market["unemployment_rate"])))
        if market.get("vacancy_rate") is not None:
            msa_pairs.append(("MF Vacancy", _format_pct(market["vacancy_rate"])))

    sub_pairs = []
    submarket = market.get("submarket", {})
    if isinstance(submarket, dict):
        if submarket.get("median_hh_income"):
            sub_pairs.append(("Tract Median HH Income", _format_dollar(submarket["median_hh_income"])))
        if submarket.get("hud_fmr"):
            sub_pairs.append(("HUD FMR", _format_dollar(submarket["hud_fmr"])))
        if submarket.get("walk_score") is not None:
            sub_pairs.append(("Walk Score", str(submarket["walk_score"])))
        if submarket.get("transit_score") is not None:
            sub_pairs.append(("Transit Score", str(submarket["transit_score"])))
        if submarket.get("bike_score") is not None:
            sub_pairs.append(("Bike Score", str(submarket["bike_score"])))
        if submarket.get("flood_zone"):
            sub_pairs.append(("Flood Zone", str(submarket["flood_zone"])))

    msa_title = msa.get("name", market.get("msa_name", "MSA"))
    sub_title = submarket.get("name", market.get("submarket_name", "Submarket"))

    if msa_pairs and sub_pairs:
        report.add_dual_kv(msa_title, msa_pairs, sub_title, sub_pairs)
    elif msa_pairs:
        report.add_kv_pairs(msa_pairs)
    elif sub_pairs:
        report.add_kv_pairs(sub_pairs)

    market_narrative = market.get("narrative", _safe_get(data, "market_narrative", default=""))
    if market_narrative:
        report.add_paragraph(market_narrative)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 14: KEY RISKS & MITIGANTS
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Key Risks & Mitigants")

    risks = data.get("risks", data.get("key_risks", []))
    if risks and isinstance(risks, list):
        risk_table = [["#", "Risk Factor", "Severity", "Assessment", "Mitigant"]]
        for i, r in enumerate(risks, 1):
            if isinstance(r, dict):
                risk_table.append([
                    str(i),
                    r.get("risk", r.get("name", r.get("factor", ""))),
                    r.get("severity", "Med"),
                    r.get("assessment", r.get("detail", "")),
                    r.get("mitigant", r.get("mitigation", "")),
                ])
            else:
                risk_table.append([str(i), str(r), "Med", "", ""])
        if len(risk_table) > 1:
            report.add_risk_table(risk_table, severity_column=2)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 15: LENDER RETURNS — UNLEVERED ONLY
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Lender Returns")

    returns = data.get("lender_returns", data.get("returns", {}))
    if isinstance(returns, list) and returns:
        # Pre-formatted table data
        report.add_table(returns)
    elif isinstance(returns, dict) and returns:
        returns_table = [["", "12-Month", "24-Month", "36-Month"]]
        for key, label in [
            ("origination_fee", "Origination Fee"),
            ("interest_income", "Interest Income"),
            ("exit_fee", "Exit Fee"),
            ("unlevered_irr", "Unlevered IRR"),
            ("unlevered_moic", "Unlevered MOIC"),
        ]:
            m12 = returns.get("m12", returns.get("12_month", returns.get("12m", {})))
            m24 = returns.get("m24", returns.get("24_month", returns.get("24m", {})))
            m36 = returns.get("m36", returns.get("36_month", returns.get("36m", {})))
            if not isinstance(m12, dict):
                m12 = {}
            if not isinstance(m24, dict):
                m24 = {}
            if not isinstance(m36, dict):
                m36 = {}
            v12 = m12.get(key)
            v24 = m24.get(key)
            v36 = m36.get(key)
            if v12 is not None or v24 is not None or v36 is not None:
                row = [label]
                for v in [v12, v24, v36]:
                    if v is None:
                        row.append("—")
                    elif "irr" in key:
                        row.append(_format_pct(v))
                    elif "moic" in key:
                        row.append(_format_dscr(v))
                    elif "fee" in key or "income" in key:
                        row.append(_format_dollar(v))
                    else:
                        row.append(str(v))
                returns_table.append(row)

        # Fallback: flat returns structure
        if len(returns_table) <= 1:
            for period_key, period_label in [("12", "12-Month"), ("24", "24-Month"), ("36", "36-Month")]:
                irr = returns.get(f"unlevered_irr_{period_key}m", returns.get(f"irr_{period_key}m"))
                moic = returns.get(f"unlevered_moic_{period_key}m", returns.get(f"moic_{period_key}m"))
                if irr is not None or moic is not None:
                    if len(returns_table) == 1:
                        returns_table.append(["Unlevered IRR", "—", "—", "—"])
                        returns_table.append(["Unlevered MOIC", "—", "—", "—"])
                    col_idx = {"12": 1, "24": 2, "36": 3}[period_key]
                    if irr is not None:
                        returns_table[1][col_idx] = _format_pct(irr)
                    if moic is not None:
                        returns_table[2][col_idx] = _format_dscr(moic)

        if len(returns_table) > 1:
            report.add_table(returns_table)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 16: DILIGENCE NEEDS LIST
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Diligence Needs List")

    dd_needs = data.get("diligence_needs", data.get("dd_needs", data.get("dd_questions", [])))
    if dd_needs and isinstance(dd_needs, list):
        needs_table = [["#", "Document", "Priority", "Workstream"]]
        for i, need in enumerate(dd_needs, 1):
            if isinstance(need, dict):
                needs_table.append([
                    str(i),
                    need.get("document", need.get("item", need.get("name", ""))),
                    need.get("priority", "High"),
                    need.get("workstream", need.get("category", "")),
                ])
            else:
                needs_table.append([str(i), str(need), "High", ""])
        if len(needs_table) > 1:
            report.add_table(needs_table)

    # ═══════════════════════════════════════════════════════════════════════
    # Section 17: RECOMMENDATION
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Recommendation")

    rec_points = []
    recommendation_detail = _safe_get(data, "recommendation_detail", default="")
    recommendation_paragraphs = data.get("recommendation_paragraphs", [])

    if recommendation_paragraphs and isinstance(recommendation_paragraphs, list):
        rec_points = [str(p) for p in recommendation_paragraphs[:3]]
    else:
        # Build 2-3 substantive paragraphs
        # Para 1: loan amount, metrics, value
        rec_p1 = _safe_get(data, "recommendation_p1", default="")
        if rec_p1:
            rec_points.append(rec_p1)
        elif rec_loan is not None:
            p1_parts = [f"Maximum supportable loan of {_format_dollar(rec_loan)}"]
            if binding:
                p1_parts.append(f"governed by {binding.replace('_', ' ').title()}")
            rec_points.append(". ".join(p1_parts) + ".")

        # Para 2: equity, reserves, coverage
        rec_p2 = _safe_get(data, "recommendation_p2", default="")
        if rec_p2:
            rec_points.append(rec_p2)
        elif recommendation_detail:
            rec_points.append(recommendation_detail)

        # Para 3: conditions
        rec_p3 = _safe_get(data, "recommendation_p3", default="")
        if rec_p3:
            rec_points.append(rec_p3)
        else:
            conditions = data.get("conditions", [])
            if conditions:
                cond_text = "Conditions to proceed: " + "; ".join(
                    f"({i+1}) {c.get('condition', str(c)) if isinstance(c, dict) else str(c)}"
                    for i, c in enumerate(conditions[:5])
                )
                rec_points.append(cond_text)

    if not rec_points:
        rec_points = [recommendation or screen or "Pending review."]

    report.add_decision_box(
        f"{screen.upper() or recommendation.upper() or 'PENDING'}",
        rec_points,
    )

    # ═══════════════════════════════════════════════════════════════════════
    # Section 18: SOURCES
    # ═══════════════════════════════════════════════════════════════════════
    report.add_section("Sources")

    report.add_paragraph(
        "In addition to standard industry data sources, below is a partial sample "
        "of additional sources referenced in this analysis.",
        secondary=True,
    )

    source_list = data.get("sources", data.get("source_list", []))
    if isinstance(source_list, list) and source_list:
        source_text_parts = []
        for s in source_list:
            if isinstance(s, dict):
                category = s.get("category", "")
                items = s.get("items", s.get("sources", []))
                if category and items:
                    source_text_parts.append(f"{category}: {', '.join(str(i) for i in items)}")
                elif category:
                    source_text_parts.append(str(category))
            else:
                source_text_parts.append(str(s))
        if source_text_parts:
            report.add_paragraph(" | ".join(source_text_parts), secondary=True)
    elif isinstance(source_list, str) and source_list:
        report.add_paragraph(source_list, secondary=True)

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


# ═══════════════════════════════════════════════════════════════════════════
# New Builders (10)
# ═══════════════════════════════════════════════════════════════════════════

def build_deal_screen_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Deal Screen DOCX from JSON output.

    1-2 page deal screening summary with credit box, property/loan summary,
    flags, binding constraint, and narrative.
    """
    ValeriReport = _get_report_class()

    prop_name = _safe_get(data, "property", "name", default="Property")
    report = ValeriReport("Deal Screening Summary", deal_name or prop_name)

    # ── Deal Tape Strip ──
    screen_result = _safe_get(data, "screen_result", default="")
    strip = {"Screen Result": screen_result}
    units = _safe_get(data, "property", "unit_count")
    if units:
        strip["Units"] = str(units)
    prop_type = _safe_get(data, "property", "property_type")
    if prop_type:
        strip["Type"] = prop_type
    loan_purpose = _safe_get(data, "property", "loan_purpose")
    if loan_purpose:
        strip["Purpose"] = loan_purpose
    report.add_deal_tape_strip(strip)

    # ── Property Summary ──
    report.add_section("PROPERTY SUMMARY")
    prop = _safe_get(data, "property", default={})
    if isinstance(prop, dict) and prop:
        pairs = []
        for key, label in [
            ("name", "Property Name"),
            ("address", "Address"),
            ("city", "City"),
            ("state", "State"),
            ("property_type", "Property Type"),
            ("unit_count", "Units"),
            ("year_built", "Year Built"),
            ("square_footage", "Square Footage"),
        ]:
            val = prop.get(key)
            if val is not None and val != "":
                if key == "unit_count":
                    pairs.append((label, f"{val:,}" if isinstance(val, (int, float)) else str(val)))
                elif key == "square_footage":
                    pairs.append((label, f"{val:,} SF" if isinstance(val, (int, float)) else str(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Loan Summary ──
    report.add_section("LOAN SUMMARY")
    loan = _safe_get(data, "loan", default={})
    if isinstance(loan, dict) and loan:
        pairs = []
        for key, label in [
            ("loan_amount", "Loan Amount"),
            ("loan_purpose", "Purpose"),
            ("term", "Term"),
            ("rate", "Rate"),
        ]:
            val = loan.get(key)
            if val is not None and val != "":
                if key == "loan_amount":
                    pairs.append((label, _format_dollar(val)))
                elif key == "rate":
                    pairs.append((label, _format_rate(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Credit Box (6 Constraints) ──
    report.add_section("CREDIT BOX — 6-CONSTRAINT CHECK")
    constraints = data.get("credit_box", data.get("constraints", []))
    if isinstance(constraints, list) and constraints:
        table_data = [["Constraint", "Value", "Threshold", "Status"]]
        for c in constraints:
            if isinstance(c, dict):
                status = "✓" if c.get("status") in ("pass", "✓", True) else "✗"
                table_data.append([
                    c.get("name", ""),
                    str(c.get("value", "N/A")),
                    str(c.get("threshold", "")),
                    status,
                ])
        report.add_table(table_data)
    elif isinstance(constraints, dict) and constraints:
        table_data = [["Constraint", "Value", "Threshold", "Status"]]
        for name, info in constraints.items():
            if isinstance(info, dict):
                status = "✓" if info.get("status") in ("pass", "✓", True) else "✗"
                table_data.append([
                    name.replace("_", " ").title(),
                    str(info.get("value", "N/A")),
                    str(info.get("threshold", "")),
                    status,
                ])
        report.add_table(table_data)

    # ── Binding Constraint ──
    binding = _safe_get(data, "binding_constraint", default="")
    max_loan = _safe_get(data, "max_loan")
    if binding:
        bc_text = f"Binding Constraint: {binding.replace('_', ' ').title()}"
        if max_loan:
            bc_text += f" — Max Loan: {_format_dollar(max_loan)}"
        report.add_highlight_box(bc_text, style="primary")

    # ── Flags ──
    flags = data.get("flags", [])
    if flags:
        report.add_section("SCREENING FLAGS")
        for f in flags:
            if isinstance(f, dict):
                report.add_paragraph(f"- **{f.get('flag', '')}**: {f.get('detail', '')}")
            else:
                report.add_paragraph(f"- {f}")

    # ── Narrative ──
    narrative = _safe_get(data, "narrative", default="")
    if narrative:
        report.add_section("NARRATIVE ASSESSMENT")
        report.add_paragraph(narrative)

    # ── Recommendation ──
    recommendation = _safe_get(data, "recommendation", default="")
    if recommendation or screen_result:
        report.add_section("RECOMMENDATION")
        report.add_decision_box(
            f"DEAL SCREEN: {screen_result or recommendation}",
            [recommendation] if recommendation else [screen_result],
        )

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_debt_sizing_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Debt Sizing Preview DOCX from JSON output.

    1 page sizing preview with max loan by constraint, binding constraint
    highlight, and rate assumptions.
    """
    ValeriReport = _get_report_class()

    report = ValeriReport("Debt Sizing Preview", deal_name or "Property")

    # ── Deal Tape Strip ──
    strip = {}
    max_loan = _safe_get(data, "max_loan")
    if max_loan:
        strip["Max Loan"] = _format_dollar(max_loan)
    binding = _safe_get(data, "binding_constraint", default="")
    if binding:
        strip["Binding Constraint"] = binding.replace("_", " ").title()
    rate = _safe_get(data, "rate_assumption", default="")
    if rate:
        strip["Rate"] = _format_rate(rate) if isinstance(rate, (int, float)) else str(rate)
    if strip:
        report.add_deal_tape_strip(strip)

    # ── Max Loan by Constraint ──
    report.add_section("MAX LOAN BY CONSTRAINT")
    constraints = data.get("constraints", [])
    if isinstance(constraints, list) and constraints:
        table_data = [["Constraint", "Threshold", "Max Loan", "Status"]]
        for c in constraints:
            if isinstance(c, dict):
                status = "✓" if c.get("status") in ("pass", "✓", True) else "✗"
                table_data.append([
                    c.get("name", ""),
                    str(c.get("threshold", "")),
                    _format_dollar(c.get("max_loan")),
                    status,
                ])
        report.add_table(table_data)
    elif isinstance(constraints, dict) and constraints:
        table_data = [["Constraint", "Threshold", "Max Loan", "Status"]]
        for name, info in constraints.items():
            if isinstance(info, dict):
                status = "✓" if info.get("status") in ("pass", "✓", True) else "✗"
                table_data.append([
                    name.replace("_", " ").title(),
                    str(info.get("threshold", "")),
                    _format_dollar(info.get("max_loan")),
                    status,
                ])
        report.add_table(table_data)

    # ── Binding Constraint Highlight ──
    if binding and max_loan:
        report.add_highlight_box(
            f"Binding Constraint: {binding.replace('_', ' ').title()} — "
            f"Max Loan: {_format_dollar(max_loan)}",
            style="primary",
        )

    # ── Rate Assumptions ──
    report.add_section("RATE ASSUMPTIONS")
    rate_data = _safe_get(data, "rate_assumptions", default={})
    if isinstance(rate_data, dict) and rate_data:
        pairs = []
        for key, label in [
            ("index", "Index"),
            ("index_rate", "Index Rate"),
            ("spread", "Spread"),
            ("all_in_rate", "All-In Rate"),
            ("floor_rate", "Floor Rate"),
            ("rate_cap", "Rate Cap"),
            ("rate_date", "Rate Date"),
        ]:
            val = rate_data.get(key)
            if val is not None and val != "":
                if key in ("index_rate", "spread", "all_in_rate", "floor_rate", "rate_cap"):
                    pairs.append((label, _format_rate(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
    elif rate:
        report.add_kv_pairs([("All-In Rate", _format_rate(rate) if isinstance(rate, (int, float)) else str(rate))])

    # ── Key Inputs ──
    inputs = _safe_get(data, "key_inputs", default={})
    if isinstance(inputs, dict) and inputs:
        report.add_section("KEY INPUTS")
        pairs = []
        for key, label in [
            ("stabilized_noi", "Stabilized NOI"),
            ("as_is_value", "As-Is Value"),
            ("as_stabilized_value", "As-Stabilized Value"),
            ("total_cost", "Total Cost"),
        ]:
            val = inputs.get(key)
            if val is not None:
                pairs.append((label, _format_dollar(val)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Narrative ──
    narrative = _safe_get(data, "narrative", default="")
    if narrative:
        report.add_paragraph(narrative)

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_loan_sizer_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Full Loan Sizing DOCX from JSON output.

    2-3 page report with waterfall table, binding constraint, metrics at
    recommended, comparison to request, rate assumptions, term structure,
    and sensitivity tables.
    """
    ValeriReport = _get_report_class()

    report = ValeriReport("Loan Sizing Analysis", deal_name or "Property")

    # ── Executive Summary ──
    report.add_section("EXECUTIVE SUMMARY")
    summary = _safe_get(data, "summary", default="")
    if summary:
        report.add_paragraph(summary)

    strip = {}
    max_loan = _safe_get(data, "recommended_loan", default=_safe_get(data, "max_loan"))
    if max_loan:
        strip["Recommended Loan"] = _format_dollar(max_loan)
    binding = _safe_get(data, "binding_constraint", default="")
    if binding:
        strip["Binding Constraint"] = binding.replace("_", " ").title()
    requested = _safe_get(data, "loan_requested")
    if requested:
        strip["Loan Requested"] = _format_dollar(requested)
    if strip:
        report.add_deal_tape_strip(strip)

    # ── 6-Constraint Sizing Waterfall ──
    report.add_section("SIZING WATERFALL — 6-CONSTRAINT ANALYSIS")
    constraints = data.get("constraints", data.get("waterfall", []))
    if isinstance(constraints, list) and constraints:
        table_data = [["Constraint", "Value", "Threshold", "Max Loan", "Status"]]
        for c in constraints:
            if isinstance(c, dict):
                status = "✓" if c.get("status") in ("pass", "✓", True) else "✗"
                table_data.append([
                    c.get("name", ""),
                    str(c.get("value", "N/A")),
                    str(c.get("threshold", "")),
                    _format_dollar(c.get("max_loan")),
                    status,
                ])
        report.add_table(table_data)
    elif isinstance(constraints, dict) and constraints:
        table_data = [["Constraint", "Value", "Threshold", "Max Loan", "Status"]]
        for name, info in constraints.items():
            if isinstance(info, dict):
                status = "✓" if info.get("status") in ("pass", "✓", True) else "✗"
                table_data.append([
                    name.replace("_", " ").title(),
                    str(info.get("value", "N/A")),
                    str(info.get("threshold", "")),
                    _format_dollar(info.get("max_loan")),
                    status,
                ])
        report.add_table(table_data)

    if binding:
        bc_text = f"Binding Constraint: {binding.replace('_', ' ').title()}"
        if max_loan:
            bc_text += f" — Recommended Loan: {_format_dollar(max_loan)}"
        report.add_highlight_box(bc_text, style="primary")

    # ── Metrics at Recommended Loan ──
    report.add_section("METRICS AT RECOMMENDED LOAN")
    metrics = _safe_get(data, "metrics_at_recommended", default={})
    if isinstance(metrics, dict) and metrics:
        pairs = []
        for key, label, fmt in [
            ("ltv_as_is", "LTV As-Is", "pct"),
            ("ltv_stabilized", "LTV Stabilized", "pct"),
            ("dscr_stabilized", "DSCR Stabilized", "dscr"),
            ("debt_yield_stabilized", "Debt Yield Stabilized", "pct"),
            ("ltc", "LTC", "pct"),
            ("loan_per_unit", "Loan/Unit", "dollar"),
        ]:
            val = metrics.get(key)
            if val is not None:
                if fmt == "pct":
                    pairs.append((label, _format_pct(val)))
                elif fmt == "dscr":
                    pairs.append((label, _format_dscr(val)))
                elif fmt == "dollar":
                    pairs.append((label, _format_dollar(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Comparison to Request ──
    comparison = _safe_get(data, "comparison_to_request", default={})
    if isinstance(comparison, dict) and comparison:
        report.add_section("COMPARISON TO SPONSOR REQUEST")
        pairs = []
        if comparison.get("loan_requested") is not None:
            pairs.append(("Loan Requested", _format_dollar(comparison["loan_requested"])))
        if comparison.get("recommended_loan") is not None:
            pairs.append(("Recommended Loan", _format_dollar(comparison["recommended_loan"])))
        if comparison.get("variance") is not None:
            pairs.append(("Variance", _format_dollar(comparison["variance"])))
        if comparison.get("variance_pct") is not None:
            pairs.append(("Variance %", _format_pct(comparison["variance_pct"])))
        if comparison.get("assessment"):
            pairs.append(("Assessment", comparison["assessment"]))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Rate Assumptions ──
    report.add_section("RATE ASSUMPTIONS")
    rate_data = _safe_get(data, "rate_assumptions", default={})
    if isinstance(rate_data, dict) and rate_data:
        pairs = []
        for key, label in [
            ("index", "Index"),
            ("index_rate", "Index Rate"),
            ("spread", "Spread"),
            ("all_in_rate", "All-In Rate"),
            ("floor_rate", "Floor Rate"),
        ]:
            val = rate_data.get(key)
            if val is not None and val != "":
                if key in ("index_rate", "spread", "all_in_rate", "floor_rate"):
                    pairs.append((label, _format_rate(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Term Structure ──
    term = _safe_get(data, "term_structure", default={})
    if isinstance(term, dict) and term:
        report.add_section("TERM STRUCTURE")
        pairs = []
        for key, label in [
            ("initial_term", "Initial Term"),
            ("extensions", "Extensions"),
            ("total_term", "Total Term"),
            ("io_period", "Interest-Only Period"),
            ("amortization", "Amortization"),
        ]:
            val = term.get(key)
            if val is not None and val != "":
                pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Rate Stress Sensitivity ──
    rate_sensitivity = data.get("rate_sensitivity", [])
    if rate_sensitivity:
        report.add_section("RATE STRESS SENSITIVITY")
        report.add_paragraph("Impact of rate changes on debt service and DSCR at recommended loan amount.")
        report.add_sensitivity_table(
            rate_sensitivity,
            base_row_index=_find_base_row(rate_sensitivity),
            dscr_column=_find_dscr_column(rate_sensitivity),
        )

    # ── NOI Stress Sensitivity ──
    noi_sensitivity = data.get("noi_sensitivity", [])
    if noi_sensitivity:
        report.add_section("NOI STRESS SENSITIVITY")
        report.add_paragraph("Impact of NOI haircuts on DSCR and debt yield at recommended loan amount.")
        report.add_sensitivity_table(
            noi_sensitivity,
            base_row_index=_find_base_row(noi_sensitivity),
            dscr_column=_find_dscr_column(noi_sensitivity),
        )

    # ── Narrative ──
    narrative = _safe_get(data, "narrative", default="")
    if narrative:
        report.add_section("SIZING NARRATIVE")
        report.add_paragraph(narrative)

    # ── Recommendation ──
    recommendation = _safe_get(data, "recommendation", default="")
    if recommendation:
        report.add_section("RECOMMENDATION")
        report.add_decision_box(
            f"LOAN SIZING: {_format_dollar(max_loan) if max_loan else 'N/A'}",
            [recommendation],
        )

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def _find_base_row(table_data: list) -> int:
    """Find base case row index in sensitivity data (row marked 'base' or middle row)."""
    for i, row in enumerate(table_data):
        if i == 0:
            continue  # skip header
        for cell in row:
            if isinstance(cell, str) and "base" in cell.lower():
                return i
    # Default to middle data row
    return max(1, len(table_data) // 2)


def _find_dscr_column(table_data: list) -> int:
    """Find DSCR column index in sensitivity header."""
    if not table_data:
        return None
    header = table_data[0]
    for j, h in enumerate(header):
        if isinstance(h, str) and "dscr" in h.lower():
            return j
    return None


def build_loan_pricing_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Loan Pricing Analysis DOCX from JSON output.

    1-2 page pricing analysis with rate build-up, rate cap, interest reserve,
    debt service, and DSCR.
    """
    ValeriReport = _get_report_class()

    report = ValeriReport("Loan Pricing Analysis", deal_name or "Property")

    # ── Executive Summary ──
    report.add_section("EXECUTIVE SUMMARY")
    summary = _safe_get(data, "summary", default="")
    if summary:
        report.add_paragraph(summary)

    strip = {}
    all_in = _safe_get(data, "all_in_rate")
    if all_in:
        strip["All-In Rate"] = _format_rate(all_in)
    ds = _safe_get(data, "annual_debt_service")
    if ds:
        strip["Annual DS"] = _format_dollar(ds)
    dscr = _safe_get(data, "dscr_stabilized")
    if dscr:
        strip["DSCR"] = _format_dscr(dscr)
    if strip:
        report.add_deal_tape_strip(strip)

    # ── Rate Build-Up ──
    report.add_section("RATE BUILD-UP")
    buildup = _safe_get(data, "rate_buildup", default={})
    if isinstance(buildup, dict) and buildup:
        pairs = []
        for key, label in [
            ("index", "Index"),
            ("index_rate", "Index Rate"),
            ("credit_spread", "Credit Spread"),
            ("origination_fee", "Origination Fee"),
            ("exit_fee", "Exit Fee"),
            ("all_in_rate", "All-In Rate"),
            ("floor_rate", "Floor Rate"),
            ("rate_date", "Rate As-Of Date"),
        ]:
            val = buildup.get(key)
            if val is not None and val != "":
                if key in ("index_rate", "credit_spread", "all_in_rate", "floor_rate"):
                    pairs.append((label, _format_rate(val)))
                elif key in ("origination_fee", "exit_fee"):
                    pairs.append((label, _format_pct(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Rate Cap Analysis ──
    rate_cap = _safe_get(data, "rate_cap", default={})
    if isinstance(rate_cap, dict) and rate_cap:
        report.add_section("RATE CAP ANALYSIS")
        pairs = []
        for key, label in [
            ("strike_rate", "Strike Rate"),
            ("cap_cost", "Cap Cost"),
            ("cap_provider", "Provider"),
            ("term_months", "Term"),
            ("notional_amount", "Notional Amount"),
        ]:
            val = rate_cap.get(key)
            if val is not None and val != "":
                if key == "strike_rate":
                    pairs.append((label, _format_rate(val)))
                elif key in ("cap_cost", "notional_amount"):
                    pairs.append((label, _format_dollar(val)))
                elif key == "term_months":
                    pairs.append((label, f"{val} months"))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Interest Reserve ──
    ir = _safe_get(data, "interest_reserve", default={})
    if isinstance(ir, dict) and ir:
        report.add_section("INTEREST RESERVE")
        pairs = []
        for key, label in [
            ("reserve_amount", "Reserve Amount"),
            ("months_coverage", "Months Coverage"),
            ("monthly_interest", "Monthly Interest"),
        ]:
            val = ir.get(key)
            if val is not None and val != "":
                if key in ("reserve_amount", "monthly_interest"):
                    pairs.append((label, _format_dollar(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Debt Service ──
    report.add_section("DEBT SERVICE ANALYSIS")
    ds_data = _safe_get(data, "debt_service", default={})
    if isinstance(ds_data, dict) and ds_data:
        pairs = []
        for key, label in [
            ("loan_amount", "Loan Amount"),
            ("annual_debt_service", "Annual Debt Service"),
            ("monthly_debt_service", "Monthly Debt Service"),
            ("io_payment", "IO Payment"),
            ("amortizing_payment", "Amortizing Payment"),
        ]:
            val = ds_data.get(key)
            if val is not None:
                pairs.append((label, _format_dollar(val)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── DSCR Analysis ──
    dscr_data = _safe_get(data, "dscr_analysis", default={})
    if isinstance(dscr_data, dict) and dscr_data:
        report.add_section("DSCR ANALYSIS")
        pairs = []
        for key, label in [
            ("stabilized_noi", "Stabilized NOI"),
            ("dscr_stabilized", "DSCR Stabilized"),
            ("dscr_in_place", "DSCR In-Place (analytical)"),
            ("breakeven_occupancy", "Break-Even Occupancy"),
        ]:
            val = dscr_data.get(key)
            if val is not None:
                if "dscr" in key:
                    pairs.append((label, _format_dscr(val)))
                elif "noi" in key:
                    pairs.append((label, _format_dollar(val)))
                elif "occupancy" in key or "pct" in key:
                    pairs.append((label, _format_pct(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Narrative ──
    narrative = _safe_get(data, "narrative", default="")
    if narrative:
        report.add_paragraph(narrative)

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_nuance_gate_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Nuance Gate Analysis DOCX from JSON output.

    3-5 page nuance gate report with flags, regulatory framework, financial
    impact, Go/No-Go determination, and conditions.
    """
    ValeriReport = _get_report_class()

    report = ValeriReport("Nuance Gate Analysis", deal_name or "Property")

    # ── Executive Summary ──
    report.add_section("EXECUTIVE SUMMARY")
    summary = _safe_get(data, "summary", default="")
    determination = _safe_get(data, "determination", default="")
    if summary:
        report.add_paragraph(summary)

    strip = {}
    if determination:
        strip["Determination"] = determination
    nuance_count = len(data.get("nuance_flags", []))
    if nuance_count:
        strip["Nuance Flags"] = str(nuance_count)
    total_impact = _safe_get(data, "financial_impact", "total_impact")
    if total_impact:
        strip["Total Financial Impact"] = _format_dollar(total_impact)
    if strip:
        report.add_deal_tape_strip(strip)

    # ── Nuance Flags ──
    flags = data.get("nuance_flags", [])
    if flags:
        report.add_section("NUANCE FLAGS IDENTIFIED")
        table_data = [["#", "Flag", "Category", "Severity", "Status"]]
        for i, flag in enumerate(flags, 1):
            if isinstance(flag, dict):
                table_data.append([
                    str(i),
                    flag.get("name", flag.get("flag", "")),
                    flag.get("category", ""),
                    flag.get("severity", ""),
                    "✓" if flag.get("resolved", False) else "✗",
                ])
            else:
                table_data.append([str(i), str(flag), "", "", "✗"])
        report.add_table(table_data)

        # Individual flag analysis
        for flag in flags:
            if isinstance(flag, dict) and flag.get("analysis"):
                flag_name = flag.get("name", flag.get("flag", ""))
                report.add_subsection(flag_name)
                report.add_paragraph(flag["analysis"])

    # ── Regulatory Framework ──
    regulatory = _safe_get(data, "regulatory_framework", default={})
    if isinstance(regulatory, dict) and regulatory:
        report.add_section("REGULATORY FRAMEWORK")
        if regulatory.get("jurisdiction"):
            report.add_paragraph(f"**Jurisdiction:** {regulatory['jurisdiction']}")
        if regulatory.get("applicable_regulations"):
            report.add_subsection("Applicable Regulations")
            regs = regulatory["applicable_regulations"]
            if isinstance(regs, list):
                for reg in regs:
                    report.add_paragraph(f"- {reg}")
            else:
                report.add_paragraph(str(regs))
        if regulatory.get("compliance_requirements"):
            report.add_subsection("Compliance Requirements")
            reqs = regulatory["compliance_requirements"]
            if isinstance(reqs, list):
                for req in reqs:
                    report.add_paragraph(f"- {req}")
            else:
                report.add_paragraph(str(reqs))
        if regulatory.get("narrative"):
            report.add_paragraph(regulatory["narrative"])
    elif _safe_get(data, "regulatory_narrative"):
        report.add_section("REGULATORY FRAMEWORK")
        report.add_paragraph(data["regulatory_narrative"])

    # ── Financial Impact Quantification ──
    fi = _safe_get(data, "financial_impact", default={})
    if isinstance(fi, dict) and fi:
        report.add_section("FINANCIAL IMPACT QUANTIFICATION")
        table_data = [["Impact Category", "Annual Impact", "Loan-Term Impact"]]
        for key, label in [
            ("revenue_impact", "Revenue Impact"),
            ("expense_impact", "Expense Impact"),
            ("value_impact", "Value Impact"),
            ("total_impact", "Total Impact"),
        ]:
            val = fi.get(key)
            if val is not None:
                annual = _format_dollar(val)
                term_val = fi.get(f"{key}_term")
                term = _format_dollar(term_val) if term_val is not None else "N/A"
                table_data.append([label, annual, term])
        if len(table_data) > 1:
            report.add_table(table_data)

        if fi.get("narrative"):
            report.add_paragraph(fi["narrative"])

    # ── Go/No-Go Determination ──
    report.add_section("GO/NO-GO DETERMINATION")
    criteria = data.get("go_no_go_criteria", [])
    if criteria:
        table_data = [["Criterion", "Assessment", "Status"]]
        for c in criteria:
            if isinstance(c, dict):
                status = "✓" if c.get("pass", c.get("status") in ("pass", "✓", True)) else "✗"
                table_data.append([
                    c.get("criterion", c.get("name", "")),
                    c.get("assessment", c.get("detail", "")),
                    status,
                ])
        if len(table_data) > 1:
            report.add_table(table_data)

    if determination:
        report.add_highlight_box(
            f"Nuance Gate Determination: {determination}",
            style="primary",
        )

    # ── Conditions ──
    conditions = data.get("conditions", [])
    if conditions:
        report.add_section("CONDITIONS & MITIGANTS")
        for i, cond in enumerate(conditions, 1):
            if isinstance(cond, dict):
                report.add_paragraph(f"{i}. **{cond.get('condition', '')}** — {cond.get('detail', '')}")
            else:
                report.add_paragraph(f"{i}. {cond}")

    # ── Narrative ──
    narrative = _safe_get(data, "narrative", default="")
    if narrative:
        report.add_section("ANALYTICAL NARRATIVE")
        report.add_paragraph(narrative)

    # ── Recommendation ──
    recommendation = _safe_get(data, "recommendation", default="")
    if recommendation or determination:
        report.add_section("RECOMMENDATION")
        points = [recommendation] if recommendation else []
        if conditions:
            cond_summary = f"{len(conditions)} condition(s) must be satisfied prior to closing."
            points.append(cond_summary)
        report.add_decision_box(
            f"NUANCE GATE: {determination or 'PENDING'}",
            points or [determination],
        )

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_ic_memo_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build IC Memo DOCX from JSON output.

    10-20 page institutional IC memo with executive summary, transaction
    overview, sponsor, market, comps, property, cash flow, sizing, risk,
    and recommendation.
    """
    ValeriReport = _get_report_class()

    prop_name = _safe_get(data, "property", "name", default="Property")
    report = ValeriReport("Investment Committee Memorandum", deal_name or prop_name)

    # ── Executive Summary ──
    report.add_section("EXECUTIVE SUMMARY")
    exec_summary = _safe_get(data, "executive_summary", default="")
    if exec_summary:
        report.add_paragraph(exec_summary)

    strip = {}
    loan_amt = _safe_get(data, "loan_amount")
    if loan_amt:
        strip["Loan Amount"] = _format_dollar(loan_amt)
    prop_value = _safe_get(data, "property", "value")
    if prop_value:
        strip["Property Value"] = _format_dollar(prop_value)
    units = _safe_get(data, "property", "unit_count")
    if units:
        strip["Units"] = str(units)
    purpose = _safe_get(data, "loan_purpose", default="")
    if purpose:
        strip["Purpose"] = purpose
    recommendation = _safe_get(data, "recommendation", default="")
    if recommendation:
        strip["Recommendation"] = recommendation
    if strip:
        report.add_deal_tape_strip(strip)

    # ── Transaction Overview ──
    report.add_section("TRANSACTION OVERVIEW")
    txn = _safe_get(data, "transaction_overview", default={})
    if isinstance(txn, dict) and txn:
        pairs = []
        for key, label in [
            ("property_name", "Property"),
            ("address", "Address"),
            ("property_type", "Property Type"),
            ("unit_count", "Units"),
            ("year_built", "Year Built"),
            ("loan_amount", "Loan Amount"),
            ("loan_purpose", "Loan Purpose"),
            ("term", "Term"),
            ("rate", "Rate"),
            ("ltv", "LTV"),
            ("dscr", "DSCR"),
        ]:
            val = txn.get(key)
            if val is not None and val != "":
                if "amount" in key or "value" in key:
                    pairs.append((label, _format_dollar(val)))
                elif key == "rate":
                    pairs.append((label, _format_rate(val)))
                elif key == "ltv":
                    pairs.append((label, _format_pct(val)))
                elif key == "dscr":
                    pairs.append((label, _format_dscr(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
    elif _safe_get(data, "transaction_narrative"):
        report.add_paragraph(data["transaction_narrative"])

    # ── Sources & Uses ──
    sources = data.get("sources", [])
    uses = data.get("uses", [])
    if sources and uses:
        report.add_section("SOURCES & USES")
        # Format as full dollar amounts for S&U
        formatted_sources = []
        for s in sources:
            if isinstance(s, (list, tuple)) and len(s) >= 2:
                formatted_sources.append([s[0], _format_dollar_full(s[1]) if isinstance(s[1], (int, float)) else str(s[1])])
            else:
                formatted_sources.append(s)
        formatted_uses = []
        for u in uses:
            if isinstance(u, (list, tuple)) and len(u) >= 2:
                formatted_uses.append([u[0], _format_dollar_full(u[1]) if isinstance(u[1], (int, float)) else str(u[1])])
            else:
                formatted_uses.append(u)
        report.add_sources_uses_table(formatted_sources, formatted_uses)

    # ── Sponsor Assessment ──
    sponsor = _safe_get(data, "sponsor_assessment", default={})
    if isinstance(sponsor, dict) and sponsor:
        report.add_section("SPONSOR ASSESSMENT")
        pairs = []
        for key, label in [
            ("name", "Sponsor"),
            ("tier", "Tier"),
            ("experience_score", "Experience Score"),
            ("net_worth", "Net Worth"),
            ("recommendation", "Recommendation"),
        ]:
            val = sponsor.get(key)
            if val is not None and val != "":
                if key == "net_worth":
                    pairs.append((label, _format_dollar(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
        if sponsor.get("narrative"):
            report.add_paragraph(sponsor["narrative"])

    # ── Market Summary ──
    market = _safe_get(data, "market_summary", default={})
    if isinstance(market, dict) and market:
        report.add_section("MARKET SUMMARY")
        pairs = []
        for key, label in [
            ("msa", "MSA"),
            ("submarket", "Submarket"),
            ("market_rating", "Market Rating"),
            ("vacancy_rate", "Vacancy Rate"),
            ("rent_growth", "Rent Growth"),
            ("supply_risk", "Supply Risk"),
        ]:
            val = market.get(key)
            if val is not None and val != "":
                if "rate" in key or "growth" in key:
                    pairs.append((label, _format_pct(val) if isinstance(val, (int, float)) else str(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
        if market.get("narrative"):
            report.add_paragraph(market["narrative"])

    # ── Comps Summary ──
    comps = _safe_get(data, "comps_summary", default={})
    if isinstance(comps, dict) and comps:
        report.add_section("COMPARABLE ANALYSIS SUMMARY")
        pairs = []
        for key, label in [
            ("avg_market_rent", "Avg Market Rent"),
            ("avg_cap_rate", "Avg Cap Rate"),
            ("avg_price_per_unit", "Avg Price/Unit"),
            ("as_stabilized_value", "As-Stabilized Value"),
        ]:
            val = comps.get(key)
            if val is not None:
                if "cap_rate" in key:
                    pairs.append((label, _format_cap_rate(val)))
                elif "rent" in key or "unit" in key or "value" in key:
                    pairs.append((label, _format_dollar(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
        if comps.get("narrative"):
            report.add_paragraph(comps["narrative"])

    # ── Property Analysis ──
    prop_analysis = _safe_get(data, "property_analysis", default={})
    if isinstance(prop_analysis, dict) and prop_analysis:
        report.add_section("PROPERTY ANALYSIS")
        if prop_analysis.get("narrative"):
            report.add_paragraph(prop_analysis["narrative"])
        if prop_analysis.get("condition"):
            report.add_paragraph(f"**Condition Assessment:** {prop_analysis['condition']}")
        if prop_analysis.get("strengths"):
            report.add_subsection("Strengths")
            for s in prop_analysis["strengths"]:
                report.add_paragraph(f"- {s}")
        if prop_analysis.get("concerns"):
            report.add_subsection("Concerns")
            for c in prop_analysis["concerns"]:
                report.add_paragraph(f"- {c}")

    # ── Cash Flow Underwriting ──
    cash_flow = _safe_get(data, "cash_flow_underwriting", default={})
    if isinstance(cash_flow, dict) and cash_flow:
        report.add_section("CASH FLOW UNDERWRITING")
        pairs = []
        for key, label in [
            ("gpr", "Gross Potential Rent"),
            ("egi", "Effective Gross Income"),
            ("total_opex", "Total Operating Expenses"),
            ("stabilized_noi", "Stabilized NOI"),
            ("in_place_noi", "In-Place NOI"),
            ("noi_per_unit", "NOI/Unit"),
            ("opex_ratio", "OpEx Ratio"),
        ]:
            val = cash_flow.get(key)
            if val is not None:
                if "ratio" in key or "pct" in key:
                    pairs.append((label, _format_pct(val)))
                elif "noi" in key or "gpr" in key or "egi" in key or "opex" in key.lower() or "unit" in key:
                    pairs.append((label, _format_dollar(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
        if cash_flow.get("narrative"):
            report.add_paragraph(cash_flow["narrative"])

    # ── Loan Sizing ──
    sizing = _safe_get(data, "loan_sizing", default={})
    if isinstance(sizing, dict) and sizing:
        report.add_section("LOAN SIZING")
        pairs = []
        for key, label in [
            ("recommended_loan", "Recommended Loan"),
            ("binding_constraint", "Binding Constraint"),
            ("ltv_as_is", "LTV As-Is"),
            ("ltv_stabilized", "LTV Stabilized"),
            ("dscr_stabilized", "DSCR Stabilized"),
            ("debt_yield", "Debt Yield"),
            ("ltc", "LTC"),
        ]:
            val = sizing.get(key)
            if val is not None and val != "":
                if "loan" in key:
                    pairs.append((label, _format_dollar(val)))
                elif "dscr" in key:
                    pairs.append((label, _format_dscr(val)))
                elif "ltv" in key or "ltc" in key or "yield" in key:
                    pairs.append((label, _format_pct(val)))
                elif key == "binding_constraint":
                    pairs.append((label, val.replace("_", " ").title() if isinstance(val, str) else str(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
        if sizing.get("narrative"):
            report.add_paragraph(sizing["narrative"])

    # ── Risk Assessment ──
    risks = data.get("risk_assessment", [])
    if risks:
        report.add_section("RISK ASSESSMENT")
        if isinstance(risks, list):
            table_data = [["Risk", "Severity", "Mitigant"]]
            for r in risks:
                if isinstance(r, dict):
                    table_data.append([
                        r.get("risk", r.get("name", "")),
                        r.get("severity", ""),
                        r.get("mitigant", r.get("mitigation", "")),
                    ])
                else:
                    table_data.append([str(r), "", ""])
            if len(table_data) > 1:
                report.add_risk_table(table_data, severity_column=1)
        elif isinstance(risks, dict) and risks.get("narrative"):
            report.add_paragraph(risks["narrative"])

    # ── Strengths & Concerns ──
    strengths = data.get("strengths", data.get("credit_strengths", []))
    concerns = data.get("concerns", data.get("credit_concerns", []))
    if strengths or concerns:
        report.add_section("CREDIT STRENGTHS & CONCERNS")
        if strengths:
            report.add_subsection("Credit Strengths")
            for s in strengths:
                report.add_paragraph(f"- {s}")
        if concerns:
            report.add_subsection("Credit Concerns")
            for c in concerns:
                report.add_paragraph(f"- {c}")

    # ── Recommendation ──
    report.add_section("RECOMMENDATION")
    rec_detail = _safe_get(data, "recommendation_detail", default="")
    conditions = data.get("conditions", [])
    points = []
    if rec_detail:
        points.append(rec_detail)
    if conditions:
        for cond in conditions:
            if isinstance(cond, dict):
                points.append(f"Condition: {cond.get('condition', cond.get('name', ''))}")
            else:
                points.append(f"Condition: {cond}")
    if not points:
        points = [recommendation or "Pending IC review."]
    report.add_decision_box(
        f"IC RECOMMENDATION: {recommendation or 'PENDING'}",
        points,
    )

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_term_sheet_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Term Sheet Comparison DOCX from JSON output.

    2-3 page comparison with side-by-side matrix, pricing analysis,
    structure comparison, covenant comparison, and recommendation.
    """
    ValeriReport = _get_report_class()

    report = ValeriReport("Term Sheet Comparison", deal_name or "Property")

    # ── Executive Summary ──
    report.add_section("EXECUTIVE SUMMARY")
    summary = _safe_get(data, "summary", default="")
    if summary:
        report.add_paragraph(summary)

    recommended = _safe_get(data, "recommended_lender", default="")
    if recommended:
        report.add_deal_tape_strip({"Recommended Lender": recommended})

    # ── Side-by-Side Matrix ──
    report.add_section("TERM SHEET COMPARISON MATRIX")
    lenders = data.get("lenders", data.get("term_sheets", []))
    if lenders:
        # Build header row from lender names
        header = ["Term"]
        for lender in lenders:
            if isinstance(lender, dict):
                header.append(lender.get("name", lender.get("lender", f"Lender {len(header)}")))

        # Build comparison rows
        comparison_fields = [
            ("loan_amount", "Loan Amount", "dollar"),
            ("rate", "Rate", "rate"),
            ("spread", "Spread", "rate"),
            ("term", "Term", "text"),
            ("io_period", "IO Period", "text"),
            ("ltv", "LTV", "pct"),
            ("dscr_requirement", "DSCR Requirement", "dscr"),
            ("origination_fee", "Origination Fee", "pct"),
            ("exit_fee", "Exit Fee", "pct"),
            ("prepayment", "Prepayment", "text"),
            ("recourse", "Recourse", "text"),
            ("rate_cap", "Rate Cap Required", "text"),
            ("reserves", "Reserves", "text"),
        ]

        table_data = [header]
        for field_key, field_label, fmt in comparison_fields:
            row = [field_label]
            has_data = False
            for lender in lenders:
                if isinstance(lender, dict):
                    val = lender.get(field_key)
                    if val is not None:
                        has_data = True
                        if fmt == "dollar":
                            row.append(_format_dollar(val))
                        elif fmt == "rate":
                            row.append(_format_rate(val))
                        elif fmt == "pct":
                            row.append(_format_pct(val))
                        elif fmt == "dscr":
                            row.append(_format_dscr(val))
                        else:
                            row.append(str(val))
                    else:
                        row.append("N/A")
                else:
                    row.append("N/A")
            if has_data:
                table_data.append(row)

        if len(table_data) > 1:
            report.add_table(table_data)

    # ── Pricing Analysis ──
    pricing = _safe_get(data, "pricing_analysis", default={})
    if isinstance(pricing, dict) and pricing:
        report.add_section("PRICING ANALYSIS")
        if pricing.get("narrative"):
            report.add_paragraph(pricing["narrative"])
        if pricing.get("comparison"):
            pairs = []
            for lender_name, details in pricing["comparison"].items():
                if isinstance(details, dict):
                    for k, v in details.items():
                        pairs.append((f"{lender_name} — {k.replace('_', ' ').title()}", str(v)))
            if pairs:
                report.add_kv_pairs(pairs)

    # ── Structure Comparison ──
    structure = _safe_get(data, "structure_comparison", default={})
    if isinstance(structure, dict) and structure:
        report.add_section("STRUCTURE COMPARISON")
        if structure.get("narrative"):
            report.add_paragraph(structure["narrative"])

    # ── Covenant Comparison ──
    covenants = _safe_get(data, "covenant_comparison", default={})
    if isinstance(covenants, dict) and covenants:
        report.add_section("COVENANT COMPARISON")
        cov_items = covenants.get("items", [])
        if cov_items:
            cov_header = ["Covenant"]
            for lender in lenders:
                if isinstance(lender, dict):
                    cov_header.append(lender.get("name", lender.get("lender", "")))
            table_data = [cov_header]
            for item in cov_items:
                if isinstance(item, dict):
                    row = [item.get("covenant", item.get("name", ""))]
                    values = item.get("values", [])
                    for val in values:
                        row.append(str(val) if val is not None else "N/A")
                    # Pad row to match header length
                    while len(row) < len(cov_header):
                        row.append("N/A")
                    table_data.append(row)
            if len(table_data) > 1:
                report.add_table(table_data)
        if covenants.get("narrative"):
            report.add_paragraph(covenants["narrative"])

    # ── Recommendation ──
    recommendation = _safe_get(data, "recommendation", default="")
    rec_detail = _safe_get(data, "recommendation_detail", default="")
    if recommendation or recommended:
        report.add_section("RECOMMENDATION")
        points = []
        if rec_detail:
            points.append(rec_detail)
        if not points:
            points = [recommendation or f"Recommended lender: {recommended}"]
        report.add_decision_box(
            f"TERM SHEET RECOMMENDATION: {recommended or recommendation}",
            points,
        )

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_business_plan_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Business Plan Assessment DOCX from JSON output.

    2-3 page business plan assessment with feasibility rating, renovation
    analysis, rent analysis, timeline, key risks, and recommendation.
    """
    ValeriReport = _get_report_class()

    report = ValeriReport("Business Plan Assessment", deal_name or "Property")

    # ── Executive Summary ──
    report.add_section("EXECUTIVE SUMMARY")
    summary = _safe_get(data, "summary", default="")
    if summary:
        report.add_paragraph(summary)

    feasibility = _safe_get(data, "feasibility_rating", default="")
    strip = {}
    if feasibility:
        strip["Feasibility"] = feasibility
    total_budget = _safe_get(data, "total_renovation_budget")
    if total_budget:
        strip["Renovation Budget"] = _format_dollar(total_budget)
    rent_premium = _safe_get(data, "rent_premium_pct")
    if rent_premium:
        strip["Rent Premium"] = _format_pct(rent_premium)
    if strip:
        report.add_deal_tape_strip(strip)

    # ── Feasibility Rating ──
    report.add_section("FEASIBILITY ASSESSMENT")
    if feasibility:
        report.add_highlight_box(f"Business Plan Feasibility: {feasibility}", style="primary")
    feasibility_detail = _safe_get(data, "feasibility_detail", default="")
    if feasibility_detail:
        report.add_paragraph(feasibility_detail)

    # ── Renovation Analysis ──
    renovations = data.get("renovations", data.get("renovation_items", []))
    if renovations:
        report.add_section("RENOVATION ANALYSIS")
        table_data = [["Item", "Budget", "$/Unit", "Timeline"]]
        for item in renovations:
            if isinstance(item, dict):
                table_data.append([
                    item.get("item", item.get("name", "")),
                    _format_dollar(item.get("budget", item.get("cost"))),
                    _format_dollar(item.get("cost_per_unit")),
                    str(item.get("timeline", item.get("duration", ""))),
                ])
        if len(table_data) > 1:
            report.add_table(table_data)

        # Total budget
        if total_budget:
            report.add_kv_pairs([
                ("Total Renovation Budget", _format_dollar(total_budget)),
                ("Budget/Unit", _format_dollar(_safe_get(data, "renovation_budget_per_unit"))),
            ])

    renovation_narrative = _safe_get(data, "renovation_narrative", default="")
    if renovation_narrative:
        report.add_paragraph(renovation_narrative)

    # ── Rent Analysis ──
    rent_analysis = _safe_get(data, "rent_analysis", default={})
    if isinstance(rent_analysis, dict) and rent_analysis:
        report.add_section("RENT ANALYSIS")
        pairs = []
        for key, label in [
            ("current_avg_rent", "Current Avg Rent"),
            ("renovated_target_rent", "Renovated Target Rent"),
            ("rent_premium", "Rent Premium"),
            ("rent_premium_pct", "Premium %"),
            ("market_rent", "Market Rent"),
            ("achievability_assessment", "Achievability"),
        ]:
            val = rent_analysis.get(key)
            if val is not None and val != "":
                if "rent" in key and "pct" not in key and key != "achievability_assessment":
                    pairs.append((label, _format_dollar(val)))
                elif "pct" in key:
                    pairs.append((label, _format_pct(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
        if rent_analysis.get("narrative"):
            report.add_paragraph(rent_analysis["narrative"])

    # ── Timeline Assessment ──
    timeline = _safe_get(data, "timeline", default={})
    if isinstance(timeline, dict) and timeline:
        report.add_section("TIMELINE ASSESSMENT")
        pairs = []
        for key, label in [
            ("renovation_start", "Renovation Start"),
            ("renovation_completion", "Renovation Completion"),
            ("stabilization_target", "Stabilization Target"),
            ("total_months", "Total Duration"),
            ("lease_up_months", "Lease-Up Period"),
            ("assessment", "Assessment"),
        ]:
            val = timeline.get(key)
            if val is not None and val != "":
                if key == "total_months" or key == "lease_up_months":
                    pairs.append((label, f"{val} months" if isinstance(val, (int, float)) else str(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
        if timeline.get("narrative"):
            report.add_paragraph(timeline["narrative"])

    # ── Key Risks ──
    risks = data.get("key_risks", data.get("risks", []))
    if risks:
        report.add_section("KEY RISKS")
        if isinstance(risks, list):
            for r in risks:
                if isinstance(r, dict):
                    report.add_insight(
                        r.get("risk", r.get("name", "")),
                        r.get("detail", r.get("finding", "")),
                        r.get("impact", ""),
                        r.get("mitigant", r.get("action", "")),
                        risk_level=r.get("severity", "warning"),
                    )
                else:
                    report.add_paragraph(f"- {r}")

    # ── Recommendation ──
    recommendation = _safe_get(data, "recommendation", default="")
    if recommendation or feasibility:
        report.add_section("RECOMMENDATION")
        report.add_decision_box(
            f"BUSINESS PLAN: {feasibility or recommendation}",
            [recommendation] if recommendation else [f"Feasibility rating: {feasibility}"],
        )

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_renovation_roi_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Renovation ROI Analysis DOCX from JSON output.

    2 page ROI analysis with metrics table, cap rate sensitivity,
    value creation analysis, risk factors, and recommendation.
    """
    ValeriReport = _get_report_class()

    report = ValeriReport("Renovation ROI Analysis", deal_name or "Property")

    # ── Executive Summary ──
    report.add_section("EXECUTIVE SUMMARY")
    summary = _safe_get(data, "summary", default="")
    if summary:
        report.add_paragraph(summary)

    strip = {}
    roi = _safe_get(data, "roi_pct")
    if roi is not None:
        strip["ROI"] = _format_pct(roi)
    value_created = _safe_get(data, "value_created")
    if value_created:
        strip["Value Created"] = _format_dollar(value_created)
    total_cost = _safe_get(data, "total_renovation_cost")
    if total_cost:
        strip["Renovation Cost"] = _format_dollar(total_cost)
    if strip:
        report.add_deal_tape_strip(strip)

    # ── ROI Metrics ──
    report.add_section("ROI METRICS")
    metrics = _safe_get(data, "roi_metrics", default={})
    if isinstance(metrics, dict) and metrics:
        pairs = []
        for key, label in [
            ("total_renovation_cost", "Total Renovation Cost"),
            ("cost_per_unit", "Cost/Unit"),
            ("incremental_noi", "Incremental NOI"),
            ("incremental_noi_per_unit", "Incremental NOI/Unit"),
            ("roi_pct", "ROI"),
            ("payback_months", "Payback Period"),
            ("value_created", "Value Created"),
            ("value_created_per_unit", "Value Created/Unit"),
        ]:
            val = metrics.get(key)
            if val is not None:
                if "cost" in key or "noi" in key or "value" in key:
                    pairs.append((label, _format_dollar(val)))
                elif "pct" in key:
                    pairs.append((label, _format_pct(val)))
                elif "months" in key:
                    pairs.append((label, f"{val} months" if isinstance(val, (int, float)) else str(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
    else:
        # Fallback: build from top-level data
        pairs = []
        if total_cost:
            pairs.append(("Total Renovation Cost", _format_dollar(total_cost)))
        cost_per_unit = _safe_get(data, "cost_per_unit")
        if cost_per_unit:
            pairs.append(("Cost/Unit", _format_dollar(cost_per_unit)))
        inc_noi = _safe_get(data, "incremental_noi")
        if inc_noi:
            pairs.append(("Incremental NOI", _format_dollar(inc_noi)))
        if roi is not None:
            pairs.append(("ROI", _format_pct(roi)))
        if value_created:
            pairs.append(("Value Created", _format_dollar(value_created)))
        payback = _safe_get(data, "payback_months")
        if payback:
            pairs.append(("Payback Period", f"{payback} months" if isinstance(payback, (int, float)) else str(payback)))
        if pairs:
            report.add_kv_pairs(pairs)

    # ── Cap Rate Sensitivity ──
    cap_sensitivity = data.get("cap_rate_sensitivity", [])
    if cap_sensitivity:
        report.add_section("CAP RATE SENSITIVITY")
        report.add_paragraph("Value creation sensitivity to exit cap rate assumptions.")
        report.add_sensitivity_table(
            cap_sensitivity,
            base_row_index=_find_base_row(cap_sensitivity),
        )

    # ── Value Creation Analysis ──
    value_analysis = _safe_get(data, "value_creation", default={})
    if isinstance(value_analysis, dict) and value_analysis:
        report.add_section("VALUE CREATION ANALYSIS")
        pairs = []
        for key, label in [
            ("pre_renovation_value", "Pre-Renovation Value"),
            ("post_renovation_value", "Post-Renovation Value"),
            ("value_uplift", "Value Uplift"),
            ("value_uplift_pct", "Value Uplift %"),
            ("pre_renovation_noi", "Pre-Renovation NOI"),
            ("post_renovation_noi", "Post-Renovation NOI"),
            ("noi_uplift", "NOI Uplift"),
        ]:
            val = value_analysis.get(key)
            if val is not None:
                if "pct" in key:
                    pairs.append((label, _format_pct(val)))
                else:
                    pairs.append((label, _format_dollar(val)))
        if pairs:
            report.add_kv_pairs(pairs)
        if value_analysis.get("narrative"):
            report.add_paragraph(value_analysis["narrative"])

    # ── Risk Factors ──
    risks = data.get("risk_factors", data.get("risks", []))
    if risks:
        report.add_section("RISK FACTORS")
        for r in risks:
            if isinstance(r, dict):
                report.add_insight(
                    r.get("risk", r.get("name", "")),
                    r.get("detail", r.get("finding", "")),
                    r.get("impact", ""),
                    r.get("mitigant", r.get("action", "")),
                    risk_level=r.get("severity", "warning"),
                )
            else:
                report.add_paragraph(f"- {r}")

    # ── Recommendation ──
    recommendation = _safe_get(data, "recommendation", default="")
    if recommendation:
        report.add_section("RECOMMENDATION")
        report.add_decision_box(
            "RENOVATION ROI ASSESSMENT",
            [recommendation],
        )

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


def build_rent_roll_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Rent Roll Analysis DOCX from JSON output.

    3-5 page rent roll analysis with unit mix, occupancy, loss-to-lease,
    anomalies, concessions, renovation segmentation, lease expiration
    waterfall, and T-12 reconciliation.
    """
    ValeriReport = _get_report_class()

    report = ValeriReport("Rent Roll Analysis", deal_name or "Property")

    # ── Executive Summary ──
    report.add_section("EXECUTIVE SUMMARY")
    summary = _safe_get(data, "summary", default="")
    if summary:
        report.add_paragraph(summary)

    strip = {}
    total_units = _safe_get(data, "total_units")
    if total_units:
        strip["Total Units"] = str(total_units)
    physical_occ = _safe_get(data, "physical_occupancy_pct")
    if physical_occ is not None:
        strip["Physical Occupancy"] = _format_pct(physical_occ)
    economic_occ = _safe_get(data, "economic_occupancy_pct")
    if economic_occ is not None:
        strip["Economic Occupancy"] = _format_pct(economic_occ)
    avg_rent = _safe_get(data, "avg_in_place_rent")
    if avg_rent:
        strip["Avg In-Place Rent"] = _format_dollar(avg_rent)
    if strip:
        report.add_deal_tape_strip(strip)

    # ── Unit Mix Summary ──
    unit_mix = data.get("unit_mix", [])
    if unit_mix:
        report.add_section("UNIT MIX SUMMARY")
        table_data = [["Unit Type", "Count", "Avg SF", "Avg Rent", "Avg Rent/SF", "% of Total"]]
        for mix in unit_mix:
            if isinstance(mix, dict):
                table_data.append([
                    mix.get("type", mix.get("unit_type", "")),
                    str(mix.get("count", mix.get("units", ""))),
                    str(mix.get("avg_sf", "")),
                    _format_dollar(mix.get("avg_rent")),
                    f"${mix.get('avg_rent_per_sf', ''):.2f}" if mix.get("avg_rent_per_sf") else "N/A",
                    _format_pct(mix.get("pct_of_total")),
                ])
        if len(table_data) > 1:
            report.add_table(table_data)

    # ── Occupancy Analysis ──
    report.add_section("OCCUPANCY ANALYSIS")
    occ = _safe_get(data, "occupancy", default={})
    if isinstance(occ, dict) and occ:
        pairs = []
        for key, label in [
            ("physical_occupancy_pct", "Physical Occupancy"),
            ("economic_occupancy_pct", "Economic Occupancy"),
            ("occupied_units", "Occupied Units"),
            ("vacant_units", "Vacant Units"),
            ("total_units", "Total Units"),
            ("model_units", "Model Units"),
            ("down_units", "Down Units"),
        ]:
            val = occ.get(key)
            if val is not None:
                if "pct" in key:
                    pairs.append((label, _format_pct(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
    else:
        # Fallback to top-level occupancy fields
        pairs = []
        if physical_occ is not None:
            pairs.append(("Physical Occupancy", _format_pct(physical_occ)))
        if economic_occ is not None:
            pairs.append(("Economic Occupancy", _format_pct(economic_occ)))
        vacant = _safe_get(data, "vacant_units")
        if vacant is not None:
            pairs.append(("Vacant Units", str(vacant)))
        if pairs:
            report.add_kv_pairs(pairs)

    if _safe_get(data, "occupancy_narrative"):
        report.add_paragraph(data["occupancy_narrative"])

    # ── Loss-to-Lease ──
    ltl = _safe_get(data, "loss_to_lease", default={})
    if isinstance(ltl, dict) and ltl:
        report.add_section("LOSS-TO-LEASE ANALYSIS")
        pairs = []
        for key, label in [
            ("total_loss_to_lease", "Total Loss-to-Lease"),
            ("loss_to_lease_pct", "Loss-to-Lease %"),
            ("avg_in_place_rent", "Avg In-Place Rent"),
            ("avg_market_rent", "Avg Market Rent"),
        ]:
            val = ltl.get(key)
            if val is not None:
                if "pct" in key:
                    pairs.append((label, _format_pct(val)))
                elif "rent" in key or "loss" in key:
                    pairs.append((label, _format_dollar(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)

        # Per-unit-type loss-to-lease table
        ltl_by_type = ltl.get("by_unit_type", [])
        if ltl_by_type:
            report.add_subsection("Loss-to-Lease by Unit Type")
            table_data = [["Unit Type", "In-Place Rent", "Market Rent", "Loss-to-Lease", "L-t-L %"]]
            for item in ltl_by_type:
                if isinstance(item, dict):
                    table_data.append([
                        item.get("type", item.get("unit_type", "")),
                        _format_dollar(item.get("in_place_rent")),
                        _format_dollar(item.get("market_rent")),
                        _format_dollar(item.get("loss_to_lease")),
                        _format_pct(item.get("loss_to_lease_pct")),
                    ])
            if len(table_data) > 1:
                report.add_table(table_data)

    # ── Anomalies ──
    anomalies = data.get("anomalies", [])
    if anomalies:
        report.add_section("RENT ROLL ANOMALIES")
        table_data = [["#", "Unit/Issue", "Detail", "Severity"]]
        for i, anom in enumerate(anomalies, 1):
            if isinstance(anom, dict):
                table_data.append([
                    str(i),
                    anom.get("unit", anom.get("issue", "")),
                    anom.get("detail", anom.get("description", "")),
                    anom.get("severity", ""),
                ])
            else:
                table_data.append([str(i), str(anom), "", ""])
        if len(table_data) > 1:
            report.add_risk_table(table_data, severity_column=3)

    # ── Concessions ──
    concessions = _safe_get(data, "concessions", default={})
    if isinstance(concessions, dict) and concessions:
        report.add_section("CONCESSIONS ANALYSIS")
        pairs = []
        for key, label in [
            ("total_concessions", "Total Concessions"),
            ("concessions_pct_of_gpr", "Concessions % of GPR"),
            ("units_with_concessions", "Units with Concessions"),
            ("avg_concession_per_unit", "Avg Concession/Unit"),
            ("concession_types", "Concession Types"),
        ]:
            val = concessions.get(key)
            if val is not None and val != "":
                if "total" in key or "avg" in key:
                    pairs.append((label, _format_dollar(val)))
                elif "pct" in key:
                    pairs.append((label, _format_pct(val)))
                elif isinstance(val, list):
                    pairs.append((label, ", ".join(str(v) for v in val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
        if concessions.get("narrative"):
            report.add_paragraph(concessions["narrative"])

    # ── Renovation Segmentation ──
    reno_seg = _safe_get(data, "renovation_segmentation", default={})
    if isinstance(reno_seg, dict) and reno_seg:
        report.add_section("RENOVATION SEGMENTATION")
        segments = reno_seg.get("segments", [])
        if segments:
            table_data = [["Segment", "Units", "Avg Rent", "Rent Premium", "% of Total"]]
            for seg in segments:
                if isinstance(seg, dict):
                    table_data.append([
                        seg.get("name", seg.get("segment", "")),
                        str(seg.get("units", seg.get("count", ""))),
                        _format_dollar(seg.get("avg_rent")),
                        _format_dollar(seg.get("rent_premium")),
                        _format_pct(seg.get("pct_of_total")),
                    ])
            if len(table_data) > 1:
                report.add_table(table_data)
        if reno_seg.get("narrative"):
            report.add_paragraph(reno_seg["narrative"])

    # ── Lease Expiration Waterfall ──
    lease_exp = data.get("lease_expirations", [])
    if lease_exp:
        report.add_section("LEASE EXPIRATION WATERFALL")
        table_data = [["Period", "Expirations", "% of Total", "Cumulative %"]]
        for exp in lease_exp:
            if isinstance(exp, dict):
                table_data.append([
                    exp.get("period", exp.get("month", exp.get("quarter", ""))),
                    str(exp.get("count", exp.get("units", ""))),
                    _format_pct(exp.get("pct_of_total")),
                    _format_pct(exp.get("cumulative_pct")),
                ])
        if len(table_data) > 1:
            report.add_table(table_data)

    # ── T-12 Reconciliation ──
    t12 = _safe_get(data, "t12_reconciliation", default={})
    if isinstance(t12, dict) and t12:
        report.add_section("T-12 RECONCILIATION")
        pairs = []
        for key, label in [
            ("rent_roll_gpr", "Rent Roll GPR (annualized)"),
            ("t12_rental_income", "T-12 Rental Income"),
            ("variance", "Variance"),
            ("variance_pct", "Variance %"),
            ("assessment", "Assessment"),
        ]:
            val = t12.get(key)
            if val is not None and val != "":
                if "gpr" in key or "income" in key or key == "variance":
                    pairs.append((label, _format_dollar(val)))
                elif "pct" in key:
                    pairs.append((label, _format_pct(val)))
                else:
                    pairs.append((label, str(val)))
        if pairs:
            report.add_kv_pairs(pairs)
        if t12.get("narrative"):
            report.add_paragraph(t12["narrative"])

    # ── Narrative ──
    narrative = _safe_get(data, "narrative", default="")
    if narrative:
        report.add_section("ANALYTICAL NARRATIVE")
        report.add_paragraph(narrative)

    # ── Recommendation ──
    recommendation = _safe_get(data, "recommendation", default="")
    if recommendation:
        report.add_section("RECOMMENDATION")
        report.add_decision_box(
            "RENT ROLL ASSESSMENT",
            [recommendation],
        )

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


# ═══════════════════════════════════════════════════════════════════════════
# Preferred Equity Quick Review Builder (22-section structure)
# ═══════════════════════════════════════════════════════════════════════════

def build_pref_equity_qr_report(data: dict, deal_name: str = "") -> bytes:
    """
    Build Preferred Equity Quick Review DOCX from JSON output.

    22-section structure per PREF_EQUITY_QR_MEMO_FORMAT_SPEC.md v1.0.
    Maps the deterministic output from pref_equity.size_pref_equity()
    to PinchFin v9 branded DOCX via ValeriReport.

    Sections:
      1.  Deal Overview (Capital Structure Summary — NOT Loan Summary)
      2.  Sources & Uses (3-tranche: Senior + Pref + Sponsor)
      3.  Senior Debt Credit Metrics (pref excluded)
      4.  Capital Stack & Combined Metrics (NEW)
      5.  Lender Rent Underwriting (same as debt QR)
      6.  Rent Comparables (same as debt QR)
      7.  Sales Comparables (same as debt QR)
      7A. Conditional (same rules)
      8.  Preferred Equity Structure (NEW)
      9.  Cash Flow & Distribution Waterfall (modified — pref rows)
      10. Dual Sizing Waterfall (Sub-table A: senior, Sub-table B: pref)
      11. PIK Accrual Analysis (replaces IR Analysis)
      12. Sensitivity Analysis (3 tables: cap rate, vacancy, pref return)
      13. Exit Waterfall & Sponsor Impact (NEW)
      14. Sponsor Overview (same)
      15. Market Overview (same)
      16. Key Risks & Mitigants (modified — pref-specific risks)
      17. Veleta Pref Equity Returns (pref returns, not lender debt)
      18. Diligence Needs List (modified — OA, governance, senior consent)
      19. Recommendation
      20. Sources
    """
    ValeriReport = _get_report_class()

    screen = _safe_get(data, "screen_result", default="CONDITIONAL")
    sized_pref = _safe_get(data, "sized_pref_equity", default=0)
    max_pref = _safe_get(data, "max_pref_equity", default=0)
    cap_stack = data.get("capital_stack", {})
    pass_1 = data.get("pass_1_senior", {})
    pass_2 = data.get("pass_2_pref", {})
    pik_data = data.get("pik_schedule", {})
    exit_wf = data.get("exit_waterfall", {})
    sponsor_imp = data.get("sponsor_impact", {})
    pref_sens = data.get("pref_return_sensitivity", [])
    pref_returns = data.get("pref_returns", {})
    yield_met = data.get("yield_metrics", {})

    report = ValeriReport(
        "Preferred Equity Quick Review",
        deal_name or "Property",
    )

    # ═══════════════════════════════════════════════════════════════════
    # Section 1: DEAL OVERVIEW
    # ═══════════════════════════════════════════════════════════════════
    report.add_section("Deal Overview")

    narrative = _safe_get(data, "deal_overview_narrative", default="")
    if narrative:
        report.add_paragraph(narrative)

    # Left: Property Profile
    prop = data.get("property", {}) if isinstance(data.get("property"), dict) else {}
    left_kv = []
    if prop.get("name"):
        left_kv.append(("Property", prop["name"]))
    if prop.get("address"):
        left_kv.append(("Location", prop["address"]))
    if prop.get("property_type"):
        left_kv.append(("Type", str(prop["property_type"])))
    if prop.get("unit_count"):
        left_kv.append(("Units", str(prop["unit_count"])))
    if prop.get("occupancy_pct") is not None:
        left_kv.append(("Occupancy", _format_pct(prop["occupancy_pct"])))

    # Right: Capital Structure Summary
    right_kv = []
    if cap_stack.get("senior_loan"):
        right_kv.append(("Senior Loan", _format_dollar(cap_stack["senior_loan"])))
    if sized_pref:
        right_kv.append(("Pref Equity (Veleta)", _format_dollar(sized_pref)))
    if cap_stack.get("common_equity"):
        right_kv.append(("Sponsor Equity", _format_dollar(cap_stack["common_equity"])))
    if cap_stack.get("total"):
        right_kv.append(("Total Capital Stack", _format_dollar(cap_stack["total"])))
    if pref_returns.get("current_pay_rate"):
        right_kv.append(("Pref Current Pay", _format_pct(pref_returns["current_pay_rate"] * 100)))
    if pref_returns.get("pik_rate"):
        right_kv.append(("Pref PIK Rate", _format_pct(pref_returns["pik_rate"] * 100)))
    if pref_returns.get("total_return"):
        right_kv.append(("Pref Total Return", _format_pct(pref_returns["total_return"] * 100)))
    p2_met = pass_2.get("metrics", {})
    if p2_met.get("combined_ltv_stabilized"):
        right_kv.append(("Combined LTV (Stab)", _format_pct(p2_met["combined_ltv_stabilized"])))

    if left_kv and right_kv:
        report.add_dual_kv("Property Profile", left_kv, "Capital Structure Summary", right_kv)
    elif right_kv:
        report.add_kv_pairs(right_kv, title="Capital Structure Summary")

    # ═══════════════════════════════════════════════════════════════════
    # Section 2: SOURCES & USES (3-tranche)
    # ═══════════════════════════════════════════════════════════════════
    report.add_section("Sources & Uses")

    sources = data.get("sources", [])
    uses = data.get("uses", [])
    if sources and uses:
        fmt_src = [[s[0], _format_dollar_full(s[1])] if isinstance(s, (list, tuple)) else s for s in sources]
        fmt_use = [[u[0], _format_dollar_full(u[1])] if isinstance(u, (list, tuple)) else u for u in uses]
        report.add_sources_uses_table(fmt_src, fmt_use)
    elif cap_stack:
        # Auto-generate from capital stack
        auto_src = [
            ["Senior Loan", _format_dollar_full(cap_stack.get("senior_loan", 0))],
            ["Preferred Equity", _format_dollar_full(sized_pref)],
            ["Sponsor Equity", _format_dollar_full(cap_stack.get("common_equity", 0))],
        ]
        auto_use = [
            ["Total Cost", _format_dollar_full(cap_stack.get("total", 0))],
        ]
        report.add_sources_uses_table(auto_src, auto_use)

    su_narrative = _safe_get(data, "sources_uses_narrative", default="")
    if su_narrative:
        report.add_paragraph(su_narrative)

    # ═══════════════════════════════════════════════════════════════════
    # Section 3: SENIOR DEBT CREDIT METRICS
    # ═══════════════════════════════════════════════════════════════════
    report.add_section("Senior Debt Credit Metrics")
    report.add_paragraph(
        "Senior loan validated independently (Pass 1). "
        "Preferred equity is EQUITY and excluded from all debt metrics below."
    )

    p1_constraints = pass_1.get("constraints", {})
    if p1_constraints:
        tbl = [["Constraint", "Threshold", "Result", "Status"]]
        for key, info in p1_constraints.items():
            if isinstance(info, dict):
                status = "✓" if info.get("status") in ("pass", True) else "✗"
                note = info.get("note", "")
                label = info.get("label", key.replace("_", " ").title())
                val_str = str(info.get("value", ""))
                thresh_str = str(info.get("threshold", ""))
                if note:
                    status = "Analytical"
                tbl.append([label, thresh_str, val_str, status])
        report.add_table(tbl)
        report.add_paragraph(
            "Note: Preferred equity is excluded from all debt metrics above. "
            "Pref is equity, not debt."
        )

    # ═══════════════════════════════════════════════════════════════════
    # Section 4: CAPITAL STACK & COMBINED METRICS (NEW)
    # ═══════════════════════════════════════════════════════════════════
    report.add_section("Capital Stack & Combined Metrics")

    if cap_stack:
        cs_tbl = [["Tranche", "Amount", "% of Stack", "Cost", "Priority"]]
        cs_tbl.append([
            "Senior Loan",
            _format_dollar(cap_stack.get("senior_loan", 0)),
            _format_pct(cap_stack.get("senior_pct", 0) * 100),
            _format_rate(cap_stack.get("senior_cost", 0)),
            "1st (Debt)",
        ])
        cs_tbl.append([
            "Preferred Equity",
            _format_dollar(sized_pref),
            _format_pct(cap_stack.get("pref_pct", 0) * 100),
            _format_pct(cap_stack.get("pref_cost", 0) * 100),
            "2nd (Equity)",
        ])
        cs_tbl.append([
            "Sponsor Equity",
            _format_dollar(cap_stack.get("common_equity", 0)),
            _format_pct(cap_stack.get("common_pct", 0) * 100),
            "Residual",
            "Last",
        ])
        cs_tbl.append([
            "Total",
            _format_dollar(cap_stack.get("total", 0)),
            "100.0%",
            _format_pct(cap_stack.get("blended_cost", 0) * 100) + " blended",
            "",
        ])
        report.add_table(cs_tbl)

    # Combined Metrics KV
    if p2_met:
        comb_kv = []
        if p2_met.get("combined_ltv_as_is"):
            comb_kv.append(("Combined LTV As-Is", _format_pct(p2_met["combined_ltv_as_is"])))
        if p2_met.get("combined_ltv_stabilized"):
            comb_kv.append(("Combined LTV Stabilized", _format_pct(p2_met["combined_ltv_stabilized"])))
        if p2_met.get("combined_ltc"):
            comb_kv.append(("Combined LTC", _format_pct(p2_met["combined_ltc"])))
        if p2_met.get("equity_cushion_pct"):
            comb_kv.append(("Equity Cushion", _format_pct(p2_met["equity_cushion_pct"])))
        if cap_stack.get("blended_cost"):
            comb_kv.append(("Blended Cost of Capital", _format_pct(cap_stack["blended_cost"] * 100)))
        if comb_kv:
            report.add_kv_pairs(comb_kv)

    # ═══════════════════════════════════════════════════════════════════
    # Sections 5-7: RENT UW, RENT COMPS, SALES COMPS (pass-through)
    # ═══════════════════════════════════════════════════════════════════
    # These are populated by the orchestration layer when narrative data
    # is supplied. Placeholder sections for structure.
    for sec_name in ["Lender Rent Underwriting", "Rent Comparables", "Sales Comparables"]:
        sec_key = sec_name.lower().replace(" ", "_").replace("&", "and")
        sec_data = data.get(sec_key, data.get(sec_name.lower().replace(" ", "_"), ""))
        if sec_data:
            report.add_section(sec_name)
            if isinstance(sec_data, str):
                report.add_paragraph(sec_data)
            elif isinstance(sec_data, dict) and sec_data.get("narrative"):
                report.add_paragraph(sec_data["narrative"])

    # ═══════════════════════════════════════════════════════════════════
    # Section 7A: CONDITIONAL (deal-specific)
    # ═══════════════════════════════════════════════════════════════════
    conditional = data.get("conditional_sections", [])
    if conditional:
        for cs in conditional:
            if isinstance(cs, dict):
                report.add_section(cs.get("title", "Deal-Specific Analysis"))
                if cs.get("narrative"):
                    report.add_paragraph(cs["narrative"])

    # ═══════════════════════════════════════════════════════════════════
    # Section 8: PREFERRED EQUITY STRUCTURE (NEW)
    # ═══════════════════════════════════════════════════════════════════
    report.add_section("Preferred Equity Structure")

    pref_terms_kv = []
    if sized_pref:
        pref_terms_kv.append(("Pref Equity Amount", _format_dollar(sized_pref)))
    if pref_returns.get("current_pay_rate"):
        pref_terms_kv.append(("Current Pay Rate", _format_pct(pref_returns["current_pay_rate"] * 100)))
    if pref_returns.get("pik_rate"):
        pref_terms_kv.append(("PIK Rate", _format_pct(pref_returns["pik_rate"] * 100)))
    if pref_returns.get("total_return"):
        pref_terms_kv.append(("Total Pref Return", _format_pct(pref_returns["total_return"] * 100)))
    pref_terms_kv.append(("Compounding", "Quarterly"))
    pik_summary = pik_data.get("summary", {})
    if pik_summary.get("months_full_pik"):
        pref_terms_kv.append(("Months Full PIK", str(pik_summary["months_full_pik"])))
    if pref_terms_kv:
        report.add_kv_pairs(pref_terms_kv, title="Preferred Equity Terms")

    # Mezz vs Pref comparison table (MANDATORY)
    mezz_tbl = [
        ["Feature", "Mezzanine", "Preferred Equity (This Deal)"],
        ["Legal Structure", "Secured debt", "Equity interest"],
        ["Priority", "Behind senior", "Behind all debt, above common"],
        ["Foreclosure Rights", "Yes", "No"],
        ["ICA Required", "Yes", "No"],
        ["Impact on Senior LTV", "Increases combined leverage", "Not debt — no LTV impact"],
        ["Tax Treatment", "Deductible", "Not deductible"],
        ["Default Remedy", "Acceleration + foreclosure", "GP removal, forced sale"],
        ["Typical Cost", "10-15% total", "12-18% IRR"],
    ]
    report.add_table(mezz_tbl)

    # ═══════════════════════════════════════════════════════════════════
    # Section 9: CASH FLOW & DISTRIBUTION WATERFALL
    # ═══════════════════════════════════════════════════════════════════
    cf_data = data.get("cash_flow", {})
    if cf_data or yield_met:
        report.add_section("Cash Flow & Distribution Waterfall")
        if isinstance(cf_data, dict) and cf_data.get("narrative"):
            report.add_paragraph(cf_data["narrative"])
        elif yield_met:
            # Auto-generate summary from yield metrics
            noi = yield_met.get("noi_stabilized", 0)
            cfads = yield_met.get("cfads_stabilized", 0)
            yoc = yield_met.get("yield_on_cost", 0)
            if noi:
                cf_kv = [
                    ("Stabilized NOI", _format_dollar(noi)),
                    ("CFADS (Stabilized)", _format_dollar(cfads)),
                    ("Yield on Cost", _format_pct(yoc * 100)),
                ]
                if yield_met.get("development_spread_bps"):
                    cf_kv.append(("Development Spread", f"{yield_met['development_spread_bps']:.0f} bps"))
                report.add_kv_pairs(cf_kv)

    # ═══════════════════════════════════════════════════════════════════
    # Section 10: DUAL SIZING WATERFALL
    # ═══════════════════════════════════════════════════════════════════
    report.add_section("Dual Sizing Waterfall")

    # Sub-table A: Senior 6-constraint waterfall
    report.add_subsection("Sub-table A: Senior Sizing Waterfall")
    if p1_constraints:
        s_tbl = [["Constraint", "Threshold", "Max Loan", "Status"]]
        binding_p1 = pass_1.get("binding_constraint", "")
        for key, info in p1_constraints.items():
            if isinstance(info, dict):
                status = "✓" if info.get("status") in ("pass", True) else "✗"
                label = info.get("label", key.replace("_", " ").title())
                max_loan = info.get("max_loan", "")
                if info.get("note"):
                    status = "Analytical"
                row = [label, str(info.get("threshold", "")), _format_dollar(max_loan), status]
                s_tbl.append(row)
        report.add_table(s_tbl)
        if binding_p1:
            report.add_paragraph(f"Binding senior constraint: {binding_p1.replace('_', ' ').title()}")
        report.add_paragraph("Note: Pref equity excluded from all metrics above.")

    # Sub-table B: Pref equity constraints
    report.add_subsection("Sub-table B: Pref Equity Constraint Validation")
    p2_constraints = pass_2.get("constraints", {})
    if p2_constraints:
        p_tbl = [["Constraint", "Threshold", "Result", "Max Pref", "Status"]]
        for key, info in p2_constraints.items():
            if isinstance(info, dict):
                status_raw = info.get("status", "")
                if status_raw in ("pass", True):
                    status = "✓"
                elif status_raw == "analytical":
                    status = "Analytical"
                else:
                    status = "✗"
                label = info.get("label", key.replace("_", " ").title())
                val = info.get("value", "")
                thresh = info.get("threshold", "")
                mp = info.get("max_pref", "")
                # Format based on constraint type
                if "ltv" in key.lower() or "ltc" in key.lower() or "equity_floor" in key.lower() or "irr" in key.lower():
                    val_str = _format_pct(val)
                    thresh_str = f"{'≤' if 'ltv' in key.lower() or 'ltc' in key.lower() else '≥'}{_format_pct(thresh)}"
                elif "moic" in key.lower():
                    val_str = f"{val:.2f}x" if isinstance(val, (int, float)) else str(val)
                    thresh_str = f"≥{thresh:.2f}x" if isinstance(thresh, (int, float)) else str(thresh)
                elif "ratio" in key.lower():
                    val_str = f"{val:.2f}x" if isinstance(val, (int, float)) else str(val)
                    thresh_str = f"≤{thresh:.1f}x" if isinstance(thresh, (int, float)) else str(thresh)
                elif "max_pref" in key.lower():
                    val_str = _format_dollar(val)
                    thresh_str = _format_dollar(thresh)
                else:
                    val_str = str(val)
                    thresh_str = str(thresh)
                p_tbl.append([label, thresh_str, val_str, _format_dollar(mp), status])
        report.add_table(p_tbl)

    binding_p2 = pass_2.get("binding_label", "")
    if binding_p2:
        report.add_highlight_box(
            f"Binding Pref Constraint: {binding_p2} — "
            f"Max Pref: {_format_dollar(max_pref)}",
            style="primary",
        )

    # ═══════════════════════════════════════════════════════════════════
    # Section 11: PIK ACCRUAL ANALYSIS
    # ═══════════════════════════════════════════════════════════════════
    report.add_section("PIK Accrual Analysis")

    if pik_summary:
        pik_kv = [
            ("Original Pref Amount", _format_dollar(pik_summary.get("original_pref", 0))),
            ("Current Pay Rate", _format_pct(pik_summary.get("current_pay_rate", 0) * 100)),
            ("PIK Rate", _format_pct(pik_summary.get("pik_rate", 0) * 100)),
            ("Total Return", _format_pct(pik_summary.get("total_return_rate", 0) * 100)),
            ("Compounding", pik_summary.get("compounding", "Quarterly").title()),
            ("Months Full PIK", str(pik_summary.get("months_full_pik", 0))),
            ("Cumul PIK at Exit", _format_dollar(pik_summary.get("total_pik_at_exit", 0))),
            ("Pref Balance at Exit", _format_dollar(pik_summary.get("pref_balance_at_exit", 0))),
            ("Accrual % of Original", _format_pct(pik_summary.get("accrual_pct_of_original", 0) * 100)),
        ]
        report.add_kv_pairs(pik_kv)

        # Accrual flag
        if pik_summary.get("accrual_flag"):
            report.add_highlight_box(pik_summary.get("accrual_flag_note", ""), style="secondary")

    # Quarterly schedule table
    schedule = pik_data.get("schedule", [])
    if schedule:
        q_tbl = [["Quarter", "Phase", "Return Due", "Current Paid", "PIK Accrual", "Cumul PIK", "Balance"]]
        for entry in schedule:
            q_tbl.append([
                f"Q{entry.get('quarter', '')}",
                entry.get("phase", ""),
                _format_dollar(entry.get("return_due", 0)),
                _format_dollar(entry.get("current_paid", 0)),
                _format_dollar(entry.get("pik_accrual", 0)),
                _format_dollar(entry.get("cumul_pik", 0)),
                _format_dollar(entry.get("balance_end", 0)),
            ])
        report.add_table(q_tbl)

    # ═══════════════════════════════════════════════════════════════════
    # Section 12: SENSITIVITY ANALYSIS (3 separate tables)
    # ═══════════════════════════════════════════════════════════════════
    report.add_section("Sensitivity Analysis")

    # Table 1: Cap Rate Sensitivity (if provided)
    cap_sens = data.get("cap_rate_sensitivity", [])
    if cap_sens:
        report.add_subsection("Cap Rate Sensitivity — Pref Returns")
        cs_tbl = [["Cap Rate", "Exit Value", "Pref Redemption", "Pref IRR", "Pref MOIC"]]
        for row in cap_sens:
            if isinstance(row, dict):
                cs_tbl.append([
                    _format_cap_rate(row.get("cap_rate")),
                    _format_dollar(row.get("exit_value")),
                    _format_dollar(row.get("pref_redemption")),
                    _format_pct(row.get("pref_irr", 0) * 100 if isinstance(row.get("pref_irr"), float) and row["pref_irr"] < 1 else row.get("pref_irr", 0)),
                    f"{row.get('pref_moic', 0):.2f}x",
                ])
        if len(cs_tbl) > 1:
            report.add_table(cs_tbl)

    # Table 2: Vacancy Stress (if provided)
    vac_sens = data.get("vacancy_stress", [])
    if vac_sens:
        report.add_subsection("Vacancy Stress")
        vs_tbl = [["Vacancy", "NOI", "DSCR (Senior)", "Cash After DS", "Pref Coverage"]]
        for row in vac_sens:
            if isinstance(row, dict):
                vs_tbl.append([
                    _format_pct(row.get("vacancy")),
                    _format_dollar(row.get("noi")),
                    _format_dscr(row.get("dscr")),
                    _format_dollar(row.get("cash_after_ds")),
                    _format_dscr(row.get("pref_coverage")),
                ])
        if len(vs_tbl) > 1:
            report.add_table(vs_tbl)

    # Table 3: Pref Return Sensitivity (from pref_return_sensitivity)
    if pref_sens:
        report.add_subsection("Pref Return Sensitivity")
        ps_tbl = [["Exit Month", "PIK Accrual", "Pref Redemption", "Pref IRR", "Pref MOIC"]]
        for row in pref_sens:
            if isinstance(row, dict):
                irr_val = row.get("pref_irr", 0)
                irr_display = irr_val * 100 if isinstance(irr_val, float) and irr_val < 1 else irr_val
                ps_tbl.append([
                    str(row.get("exit_month", "")),
                    _format_dollar(row.get("pik_accrual", 0)),
                    _format_dollar(row.get("pref_redemption", 0)),
                    _format_pct(irr_display),
                    f"{row.get('pref_moic', 0):.2f}x",
                ])
        if len(ps_tbl) > 1:
            report.add_table(ps_tbl)

    # ═══════════════════════════════════════════════════════════════════
    # Section 13: EXIT WATERFALL & SPONSOR IMPACT (NEW)
    # ═══════════════════════════════════════════════════════════════════
    report.add_section("Exit Waterfall & Sponsor Impact")

    # Exit scenario table
    scenarios = exit_wf.get("scenarios", [])
    if scenarios:
        exit_tbl = [["Scenario", "Exit Value", "Senior Payoff", "Pref Redemption", "Common Equity", "Pref IRR", "Pref MOIC"]]
        for s in scenarios:
            if isinstance(s, dict):
                irr_val = s.get("pref_irr", 0)
                irr_display = irr_val * 100 if isinstance(irr_val, float) and irr_val < 1 else irr_val
                exit_tbl.append([
                    s.get("scenario", ""),
                    _format_dollar(s.get("exit_value", 0)),
                    _format_dollar(s.get("senior_payoff", 0)),
                    _format_dollar(s.get("pref_redemption", 0)),
                    _format_dollar(s.get("common_equity", 0)),
                    _format_pct(irr_display),
                    f"{s.get('pref_moic', 0):.2f}x",
                ])
        report.add_table(exit_tbl)

    # Decline-to-breakeven
    decline_pct = exit_wf.get("decline_to_breakeven_pct", 0)
    if decline_pct:
        report.add_paragraph(
            f"Value must decline {_format_pct(decline_pct * 100)} from base before pref takes a loss."
        )

    # Sponsor with/without comparison (MANDATORY)
    if sponsor_imp:
        report.add_subsection("Sponsor With/Without Comparison")
        wo = sponsor_imp.get("without_pref", {})
        wi = sponsor_imp.get("with_pref", {})
        sp_tbl = [
            ["Metric", "Without Pref", "With Pref"],
            ["Sponsor Equity", _format_dollar(wo.get("sponsor_equity", 0)), _format_dollar(wi.get("sponsor_equity", 0))],
            ["Annual CF (Stabilized)", _format_dollar(wo.get("annual_cf_stabilized", 0)), _format_dollar(wi.get("annual_cf_stabilized", 0))],
            ["Cash-on-Cash", _format_pct(wo.get("cash_on_cash", 0) * 100), _format_pct(wi.get("cash_on_cash", 0) * 100)],
            ["Exit Equity (Base)", _format_dollar(wo.get("exit_equity", 0)), _format_dollar(wi.get("exit_equity", 0))],
            ["Sponsor MOIC", f"{wo.get('moic', 0):.2f}x", f"{wi.get('moic', 0):.2f}x"],
            ["Sponsor IRR", _format_pct(wo.get("irr", 0) * 100), _format_pct(wi.get("irr", 0) * 100)],
        ]
        report.add_table(sp_tbl)

        lev = sponsor_imp.get("leverage_effect", "")
        if lev:
            report.add_paragraph(
                f"Preferred equity creates {lev} leverage for the sponsor. "
                f"MOIC delta: {sponsor_imp.get('moic_delta', 0):+.2f}x."
            )

    # ═══════════════════════════════════════════════════════════════════
    # Sections 14-15: SPONSOR OVERVIEW, MARKET OVERVIEW (pass-through)
    # ═══════════════════════════════════════════════════════════════════
    for sec_name, sec_key in [("Sponsor Overview", "sponsor_overview"), ("Market Overview", "market_overview")]:
        sec_content = data.get(sec_key, "")
        if sec_content:
            report.add_section(sec_name)
            if isinstance(sec_content, str):
                report.add_paragraph(sec_content)
            elif isinstance(sec_content, dict) and sec_content.get("narrative"):
                report.add_paragraph(sec_content["narrative"])

    # ═══════════════════════════════════════════════════════════════════
    # Section 16: KEY RISKS & MITIGANTS
    # ═══════════════════════════════════════════════════════════════════
    risks = data.get("risks", data.get("key_risks", []))
    if risks:
        report.add_section("Key Risks & Mitigants")
        if isinstance(risks, list) and risks:
            r_tbl = [["Risk", "Severity", "Mitigant"]]
            for r in risks:
                if isinstance(r, dict):
                    r_tbl.append([
                        r.get("risk", r.get("category", "")),
                        r.get("severity", "Med"),
                        r.get("mitigant", r.get("mitigation", "")),
                    ])
                elif isinstance(r, str):
                    r_tbl.append([r, "Med", ""])
            if len(r_tbl) > 1:
                report.add_table(r_tbl)

    # ═══════════════════════════════════════════════════════════════════
    # Section 17: VELETA PREF EQUITY RETURNS
    # ═══════════════════════════════════════════════════════════════════
    report.add_section("Veleta Preferred Equity Returns")

    if pref_sens:
        # Build returns table at 12/24/36 from sensitivity data
        ret_tbl = [["", "12-Month", "24-Month", "36-Month"]]
        # Find matching exit months
        by_month = {r.get("exit_month"): r for r in pref_sens if isinstance(r, dict)}
        m12 = by_month.get(12, {})
        m24 = by_month.get(24, {})
        m36 = by_month.get(36, {})

        ret_tbl.append([
            "Current Pay Income",
            _format_dollar(m12.get("current_pay_income", 0)),
            _format_dollar(m24.get("current_pay_income", 0)),
            _format_dollar(m36.get("current_pay_income", 0)),
        ])
        ret_tbl.append([
            "PIK Accrual",
            _format_dollar(m12.get("pik_accrual", 0)),
            _format_dollar(m24.get("pik_accrual", 0)),
            _format_dollar(m36.get("pik_accrual", 0)),
        ])
        ret_tbl.append([
            "Exit Redemption",
            _format_dollar(m12.get("pref_redemption", 0)),
            _format_dollar(m24.get("pref_redemption", 0)),
            _format_dollar(m36.get("pref_redemption", 0)),
        ])
        for label, key, fmt in [
            ("Pref IRR", "pref_irr", "pct"),
            ("Pref MOIC", "pref_moic", "moic"),
        ]:
            vals = []
            for m in [m12, m24, m36]:
                v = m.get(key, 0)
                if fmt == "pct":
                    vals.append(_format_pct(v * 100 if isinstance(v, float) and v < 1 else v))
                else:
                    vals.append(f"{v:.2f}x")
            ret_tbl.append([label] + vals)

        report.add_table(ret_tbl)

    # ═══════════════════════════════════════════════════════════════════
    # Section 18: DILIGENCE NEEDS LIST
    # ═══════════════════════════════════════════════════════════════════
    diligence = data.get("diligence_needs", data.get("diligence", []))
    # Always include pref-specific items
    pref_dd_items = [
        {"item": "Operating Agreement (full review)", "priority": "Critical", "workstream": "Legal / Pref Structure"},
        {"item": "Governance provisions (consent, removal, reporting)", "priority": "Critical", "workstream": "Legal / Pref Structure"},
        {"item": "Senior lender consent to pref equity", "priority": "Critical", "workstream": "Capital Structure"},
        {"item": "Sponsor org chart / entity structure", "priority": "High", "workstream": "Sponsor DD"},
        {"item": "Prior pref equity or JV track record", "priority": "High", "workstream": "Sponsor DD"},
    ]
    report.add_section("Diligence Needs List")
    dd_tbl = [["#", "Document", "Priority", "Workstream"]]
    idx = 1
    for item in pref_dd_items:
        dd_tbl.append([str(idx), item["item"], item["priority"], item["workstream"]])
        idx += 1
    if isinstance(diligence, list):
        for d in diligence:
            if isinstance(d, dict):
                dd_tbl.append([str(idx), d.get("item", d.get("document", "")), d.get("priority", "High"), d.get("workstream", "")])
            elif isinstance(d, str):
                dd_tbl.append([str(idx), d, "High", ""])
            idx += 1
    report.add_table(dd_tbl)

    # ═══════════════════════════════════════════════════════════════════
    # Section 19: RECOMMENDATION
    # ═══════════════════════════════════════════════════════════════════
    report.add_section("Recommendation")

    rec_text = _safe_get(data, "recommendation_narrative", default="")
    if rec_text:
        report.add_decision_box(screen, [rec_text])
    else:
        # Auto-generate from results
        base = exit_wf.get("scenarios", [{}])[0] if exit_wf.get("scenarios") else {}
        irr_str = _format_pct(base.get("pref_irr", 0) * 100) if base else "N/A"
        moic_str = f"{base.get('pref_moic', 0):.2f}x" if base else "N/A"
        auto_rec = (
            f"Maximum supportable preferred equity: {_format_dollar(max_pref)}. "
            f"Sized pref: {_format_dollar(sized_pref)}. "
            f"Binding constraint: {pass_2.get('binding_label', 'N/A')}. "
            f"Base-case pref IRR: {irr_str}, MOIC: {moic_str}."
        )
        report.add_decision_box(screen, [auto_rec])

    # ═══════════════════════════════════════════════════════════════════
    # Section 20: SOURCES
    # ═══════════════════════════════════════════════════════════════════
    sources_list = data.get("sources_list", data.get("sources_cited", []))
    if sources_list:
        report.add_section("Sources")
        report.add_paragraph(
            "In addition to standard industry data sources, below is a partial "
            "sample of additional sources referenced in this analysis."
        )
        if isinstance(sources_list, list):
            for s in sources_list:
                report.add_paragraph(f"• {s}" if isinstance(s, str) else f"• {s}")

    buffer = io.BytesIO()
    report.save(buffer)
    return buffer.getvalue()


# ═══════════════════════════════════════════════════════════════════════════
# Builder Registry
# ═══════════════════════════════════════════════════════════════════════════

REPORT_BUILDERS = {
    # ── Existing 5 ──
    "sponsor_analysis": build_sponsor_report,
    "market_research": build_market_report,
    "comp_analysis": build_comps_report,
    "cash_flow": build_cash_flow_report,
    "quick_review": build_quick_review_report,
    # ── New 11 ──
    "deal_screen": build_deal_screen_report,
    "debt_sizing_preview": build_debt_sizing_report,
    "loan_sizer": build_loan_sizer_report,
    "loan_pricing": build_loan_pricing_report,
    "nuance_gate": build_nuance_gate_report,
    "ic_memo": build_ic_memo_report,
    "term_sheet_comparator": build_term_sheet_report,
    "business_plan": build_business_plan_report,
    "renovation_roi": build_renovation_roi_report,
    "rent_roll_analyzer": build_rent_roll_report,
    "pref_equity_qr": build_pref_equity_qr_report,
}


def build_report(tool_name: str, data: dict, deal_name: str = "") -> Optional[bytes]:
    """
    Build a DOCX report for the given tool output.

    Args:
        tool_name: Analysis tool name (e.g., "sponsor_analysis")
        data: JSON output from the analysis
        deal_name: Optional deal name for report title

    Returns:
        DOCX file bytes, or None if no builder exists for this tool.
    """
    builder = REPORT_BUILDERS.get(tool_name)
    if builder is None:
        LOG.warning("No report builder for tool: %s", tool_name)
        return None

    try:
        return builder(data, deal_name)
    except Exception as e:
        LOG.error("Report generation failed for %s: %s", tool_name, e, exc_info=True)
        return None
