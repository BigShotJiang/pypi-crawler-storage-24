"""
pinchfin API — Tier 3 Analysis Functions (Synthesis / Judgment)
================================================================
These tools use Claude with full SKILL.md methodology for deep analysis.
Some also use Perplexity research and Valeri Data Services.

Architecture Reset: Full skills via SkillLoader, multi-skill composition
with constraint blocks, structured JSON via call_claude_structured(),
max_tokens 8192-16384.

8. analyze_rent_roll — Rent roll parsing, anomaly detection, loss-to-lease
9. analyze_cash_flow — Dual-scenario cash flow (lender vs sponsor) + projections
10. analyze_nuance_gate — Nuance flag detection and gate-keeping classification
11. analyze_ic_memo — Investment Committee memo synthesis
12. analyze_term_sheet_comparator — Side-by-side term sheet comparison
13. analyze_business_plan — Business plan feasibility and execution risk
14. analyze_renovation_roi — Renovation ROI and value creation analysis
15. analyze_quick_review — 10-minute deal screening with full analysis

(c) Veleta Capital LLC. All rights reserved.
"""

import asyncio
import json
import logging
from typing import Optional

from api.analysis.clients import (
    call_claude,
    call_claude_structured,
    call_perplexity,
    call_valeri_data,
    get_current_sofr,
)
from api.analysis.credit_box import run_constraint_waterfall
from api.analysis.prompts import (
    load_skill,
    build_analysis_prompt,
    load_memo_format_spec,
    load_methodology,
    extract_methodology_section,
)
from api.analysis.skill_loader import load_skill_constraints
from api.analysis.schemas import get_json_schema, validate_output

LOG = logging.getLogger("pinchfin.analysis.tier3")


async def _parallel_perplexity(queries: list, meter=None) -> list:
    """Run multiple Perplexity queries in parallel."""
    tasks = [call_perplexity(q, meter=meter) for q in queries]
    return await asyncio.gather(*tasks, return_exceptions=True)


def _parse_claude_json(text: str) -> Optional[dict]:
    """Try to parse Claude's response as JSON, handling ```json blocks."""
    clean = text.strip()
    if clean.startswith("```"):
        clean = clean.split("\n", 1)[1]
        if clean.endswith("```"):
            clean = clean[:-3]
    try:
        return json.loads(clean)
    except (json.JSONDecodeError, IndexError):
        pass
    # Try to find JSON in text
    brace_start = clean.find("{")
    brace_end = clean.rfind("}")
    if brace_start != -1 and brace_end > brace_start:
        try:
            return json.loads(clean[brace_start:brace_end + 1])
        except (json.JSONDecodeError, ValueError):
            pass
    return None


# ═══════════════════════════════════════════════════════════════════════════
# 8. Rent Roll Analysis
# ═══════════════════════════════════════════════════════════════════════════

async def analyze_rent_roll(req, meter=None) -> dict:
    """
    Real rent roll analysis: parse structured rent roll data, detect anomalies,
    calculate loss-to-lease, assess occupancy and unit mix.

    Uses full rent-roll-analysis SKILL.md (266 lines):
    - 7-step validation process
    - Unit mix summary with loss-to-lease by type
    - Physical vs economic occupancy
    - Renovation status segmentation
    - 18-month lease expiration waterfall
    - Rent roll to T-12 reconciliation

    Accepts structured rent_roll_data (list of unit dicts) for deterministic
    calculations. Claude verifies and adds narrative — it does NOT invent numbers.
    """
    skill_text = load_skill("rent-roll-analysis")

    # --- Determine data availability ---
    rent_roll_data = getattr(req, "rent_roll_data", None)
    property_address = getattr(req, "property_address", None)
    unit_count = getattr(req, "unit_count", None)

    # If no rent_roll_data AND no summary metrics, return error
    has_summary = any([
        getattr(req, "avg_rent", None),
        getattr(req, "occupancy_pct", None),
        getattr(req, "market_rent_estimate", None),
    ])

    if not rent_roll_data and not has_summary:
        return {
            "error": "Rent roll data required — provide unit-level data via rent_roll_data or summary metrics (avg_rent, occupancy_pct, unit_count)",
            "analysis_mode": "real",
            "status": "insufficient_data",
        }

    # --- Pull market rents from Valeri Data Services ---
    market_rent_survey = None
    if property_address:
        market_rent_survey = await call_valeri_data(
            "market-rent-survey", {"address": property_address}, meter=meter
        )

    # --- Deterministic calculations on unit-level data ---
    calculated_metrics = {}
    if rent_roll_data and isinstance(rent_roll_data, list) and len(rent_roll_data) > 0:
        total_units = len(rent_roll_data)
        occupied_units = 0
        vacant_units = 0
        down_units = 0
        model_units = 0
        total_rent = 0.0
        total_market_rent = 0.0
        total_sqft = 0.0
        concession_count = 0
        total_concession_value = 0.0

        # Unit mix aggregation
        unit_mix = {}
        renovation_segments = {"classic": [], "partial": [], "full": [], "unknown": []}

        # Lease expiration schedule
        lease_expirations = {}

        for unit in rent_roll_data:
            status = str(unit.get("status", "occupied")).lower()
            if status in ("occupied", "leased", "current"):
                occupied_units += 1
                current_rent = float(unit.get("current_rent", 0) or 0)
                total_rent += current_rent
            elif status in ("vacant", "available"):
                vacant_units += 1
            elif status in ("down", "renovation", "under renovation"):
                down_units += 1
            elif status in ("model",):
                model_units += 1
            else:
                # Default to occupied if unclear
                occupied_units += 1
                current_rent = float(unit.get("current_rent", 0) or 0)
                total_rent += current_rent

            sqft = float(unit.get("sqft", 0) or 0)
            total_sqft += sqft

            market_rent = float(unit.get("market_rent", 0) or 0)
            total_market_rent += market_rent

            # Unit type aggregation
            unit_type = unit.get("unit_type") or unit.get("bedrooms", "Unknown")
            unit_type_key = str(unit_type)
            if unit_type_key not in unit_mix:
                unit_mix[unit_type_key] = {
                    "count": 0, "total_rent": 0.0, "total_market_rent": 0.0,
                    "total_sqft": 0.0, "occupied": 0,
                }
            um = unit_mix[unit_type_key]
            um["count"] += 1
            um["total_sqft"] += sqft
            um["total_market_rent"] += market_rent
            if status in ("occupied", "leased", "current") or status not in ("vacant", "available", "down", "renovation", "under renovation", "model"):
                um["occupied"] += 1
                um["total_rent"] += float(unit.get("current_rent", 0) or 0)

            # Concessions
            concession = unit.get("concessions")
            if concession and float(concession or 0) > 0:
                concession_count += 1
                total_concession_value += float(concession)

            # Renovation status
            reno = str(unit.get("renovation_status", "unknown")).lower()
            if reno in ("classic", "unrenovated", "original"):
                renovation_segments["classic"].append(unit)
            elif reno in ("partial", "partial renovation"):
                renovation_segments["partial"].append(unit)
            elif reno in ("full", "full renovation", "renovated"):
                renovation_segments["full"].append(unit)
            else:
                renovation_segments["unknown"].append(unit)

            # Lease expiration
            lease_end = unit.get("lease_end")
            if lease_end:
                month_key = str(lease_end)[:7]  # YYYY-MM
                lease_expirations[month_key] = lease_expirations.get(month_key, 0) + 1

        # Calculate physical occupancy
        physical_occupancy = (occupied_units / total_units * 100) if total_units > 0 else 0
        avg_rent = (total_rent / occupied_units) if occupied_units > 0 else 0

        # Calculate GPR for economic occupancy
        gpr = total_market_rent * 12 if total_market_rent > 0 else (avg_rent * total_units * 12)
        actual_collected = total_rent * 12
        economic_occupancy = (actual_collected / gpr * 100) if gpr > 0 else 0

        # Unit mix summary
        unit_mix_summary = []
        for utype, data in sorted(unit_mix.items()):
            avg_sf = (data["total_sqft"] / data["count"]) if data["count"] > 0 else 0
            avg_in_place = (data["total_rent"] / data["occupied"]) if data["occupied"] > 0 else 0
            avg_market = (data["total_market_rent"] / data["count"]) if data["count"] > 0 else 0
            ltl_pct = ((avg_market - avg_in_place) / avg_market * 100) if avg_market > 0 and avg_in_place > 0 else 0
            unit_mix_summary.append({
                "unit_type": utype,
                "units": data["count"],
                "pct_mix": round(data["count"] / total_units * 100, 1),
                "avg_sf": round(avg_sf, 0),
                "avg_in_place_rent": round(avg_in_place, 2),
                "avg_market_rent": round(avg_market, 2),
                "loss_to_lease_pct": round(ltl_pct, 1),
            })

        # Loss-to-lease aggregate
        total_ltl_annual = 0.0
        below_market_count = 0
        at_market_count = 0
        above_market_count = 0
        for unit in rent_roll_data:
            cr = float(unit.get("current_rent", 0) or 0)
            mr = float(unit.get("market_rent", 0) or 0)
            if cr > 0 and mr > 0:
                gap_pct = (mr - cr) / mr * 100
                if gap_pct > 2:
                    below_market_count += 1
                    total_ltl_annual += (mr - cr) * 12
                elif gap_pct < -2:
                    above_market_count += 1
                else:
                    at_market_count += 1

        # Renovation segmentation summary
        reno_summary = {}
        for seg_name, seg_units in renovation_segments.items():
            if seg_units:
                seg_rents = [float(u.get("current_rent", 0) or 0) for u in seg_units if float(u.get("current_rent", 0) or 0) > 0]
                reno_summary[seg_name] = {
                    "units": len(seg_units),
                    "avg_rent": round(sum(seg_rents) / len(seg_rents), 2) if seg_rents else 0,
                }

        calculated_metrics = {
            "total_units": total_units,
            "occupied_units": occupied_units,
            "vacant_units": vacant_units,
            "down_units": down_units,
            "model_units": model_units,
            "physical_occupancy_pct": round(physical_occupancy, 1),
            "economic_occupancy_pct": round(economic_occupancy, 1),
            "avg_in_place_rent": round(avg_rent, 2),
            "total_monthly_rent": round(total_rent, 2),
            "total_monthly_market_rent": round(total_market_rent, 2),
            "unit_mix_summary": unit_mix_summary,
            "loss_to_lease": {
                "total_annual_ltl_dollars": round(total_ltl_annual, 2),
                "below_market_units": below_market_count,
                "at_market_units": at_market_count,
                "above_market_units": above_market_count,
            },
            "concessions": {
                "units_with_concessions": concession_count,
                "total_annual_concession_cost": round(total_concession_value * 12, 2),
            },
            "renovation_segmentation": reno_summary,
            "lease_expiration_schedule": dict(sorted(lease_expirations.items())),
        }

    # --- Build deal_data ---
    deal_data = {
        "property_address": property_address,
        "unit_count": unit_count,
    }

    if calculated_metrics:
        deal_data["calculated_metrics"] = calculated_metrics
        deal_data["data_source"] = "unit_level_rent_roll"
    else:
        # Summary-only mode
        deal_data["avg_rent"] = getattr(req, "avg_rent", None)
        deal_data["occupancy_pct"] = getattr(req, "occupancy_pct", None)
        deal_data["market_rent_estimate"] = getattr(req, "market_rent_estimate", None)
        deal_data["data_source"] = "summary_metrics_only"
        deal_data["data_limitation"] = (
            "Unit-level rent roll data was NOT provided. Analysis is based on summary "
            "metrics only. Loss-to-lease by unit type, lease expiration waterfall, "
            "renovation segmentation, and T-12 reconciliation cannot be performed."
        )

    external_data = {}
    if market_rent_survey:
        external_data["market_rent_survey"] = market_rent_survey

    schema = get_json_schema("rent_roll_analyzer")

    data_mode_note = ""
    if not rent_roll_data:
        data_mode_note = (
            "\n\nDATA LIMITATION: Only summary metrics are available. You MUST clearly "
            "note this limitation. Do NOT invent unit-level data. Report what can be "
            "determined from summary metrics and flag what cannot be assessed."
        )

    system, user = build_analysis_prompt(
        skill_text=skill_text,
        deal_data=deal_data,
        external_data=external_data if external_data else None,
        json_schema=schema,
        task_description=(
            "Analyze this rent roll for institutional bridge lending using the full "
            "7-step methodology. Produce a comprehensive structured JSON response.\n\n"
            "DETERMINISTIC METRICS HAVE BEEN PRE-CALCULATED AND ARE PROVIDED IN "
            "calculated_metrics. Use these numbers as the authoritative source. Your job "
            "is to VERIFY the calculations, add institutional narrative and interpretation, "
            "flag anomalies, and provide risk assessment. Do NOT recalculate or override "
            "the deterministic metrics unless you find an error (explain if so).\n\n"
            "DEPTH REQUIREMENTS:\n"
            "- Summary: total units, occupied, vacancy rate, avg in-place rent, market rent\n"
            "- Unit mix: by type with count, avg SF, avg rent, market rent, loss-to-lease %\n"
            "- Occupancy: physical vs economic, vacant/down/model units\n"
            "- Loss-to-lease: overall and by segment (below/at/above market)\n"
            "- Anomalies: flagged units with type, unit #, rent, market, explanation\n"
            "- Concessions: units with concessions, avg value, total annual cost\n"
            "- Renovation segmentation: classic vs partial vs full, premium %\n"
            "- Lease expiration waterfall: 18-month monthly schedule, concentration risk\n"
            "- T-12 reconciliation: variance check +/-5%\n\n"
            "CRITICAL: NEVER invent unit-level data. Every number must trace to the "
            "provided rent_roll_data or calculated_metrics. If data is missing, state "
            "'Not Available — insufficient data' for that section."
            + data_mode_note
        ),
    )

    parsed = await call_claude_structured(system, user, meter=meter, max_tokens=8192)
    parsed["analysis_mode"] = "real"

    # Inject deterministic metrics as authoritative layer
    if calculated_metrics:
        parsed["deterministic_metrics"] = calculated_metrics

    parsed["data_sources"] = {
        "unit_level_data": bool(rent_roll_data),
        "market_rent_survey": bool(market_rent_survey),
    }

    validated = validate_output("rent_roll_analyzer", parsed)
    if validated:
        LOG.info("Rent roll analysis output validated against schema")

    return parsed


# ═══════════════════════════════════════════════════════════════════════════
# 9. Cash Flow Modeling
# ═══════════════════════════════════════════════════════════════════════════

async def analyze_cash_flow(req, meter=None) -> dict:
    """
    Real cash flow underwriting: dual scenario (lender vs sponsor),
    OpEx breakdown, NOI projections, 6-constraint sizing waterfall.

    Uses multi-skill composition:
    - PRIMARY: cash-flow-modeling SKILL.md (368 lines) — full methodology
    - SECONDARY: expense-underwriting — constraint block only
    - SECONDARY: cre-calculations — constraint block only

    Includes CF-1 through CF-10 full workflow.

    All constraint metrics (DSCR, DY, LTV, LTC) are calculated deterministically
    in Python via run_constraint_waterfall(). Claude narrates and interprets only.
    """
    skill_text = load_skill("cash-flow-modeling")

    # Multi-skill composition: primary + constraint blocks
    expense_constraints = load_skill_constraints("expense-underwriting")
    calc_constraints = load_skill_constraints("cre-calculations")

    # Pull macro data for rent growth / expense assumptions
    macro = await call_valeri_data("macro-indicators", {}, meter=meter)

    # ─── Deterministic pre-calculation: SOFR + constraint waterfall ───────
    sofr = await get_current_sofr(meter=meter)
    spread_bps = 350
    all_in_rate = (sofr + spread_bps / 100) / 100  # decimal, e.g. 0.0750

    # Derive values from request fields (mirror quick_review pattern)
    noi_est = req.current_noi or 0.0
    current_revenue = req.current_revenue or 0.0
    pro_forma_rents = req.pro_forma_rents or 0.0

    # Estimate asset value from NOI at 5.25% cap if not provided
    if noi_est > 0:
        asset_value_est = noi_est / 0.0525
    elif current_revenue > 0:
        asset_value_est = current_revenue * 0.55 / 0.0525  # 45% expense ratio
    else:
        asset_value_est = pro_forma_rents * 12 * req.unit_count * 0.55 / 0.0525

    stabilized_value_est = asset_value_est * 1.08
    total_cost_est = asset_value_est + (req.unit_count * 15000)

    # Estimate loan amount at 70% LTV if not derivable
    loan_amount_est = asset_value_est * 0.70

    # Stabilized NOI estimate (use current or derive from revenue)
    if noi_est > 0:
        stabilized_noi = noi_est
    elif current_revenue > 0:
        stabilized_noi = current_revenue * 0.55
    else:
        stabilized_noi = pro_forma_rents * 12 * req.unit_count * 0.55

    # Run the deterministic 6-constraint waterfall
    waterfall = run_constraint_waterfall(
        loan_amount=loan_amount_est,
        as_is_value=asset_value_est,
        stabilized_value=stabilized_value_est,
        total_cost=total_cost_est,
        noi=stabilized_noi,
        rate=all_in_rate,
        unit_count=req.unit_count,
    )

    # Pre-calculate analytical metrics (Y1 — NOT sizing gates)
    annual_ds = loan_amount_est * all_in_rate if all_in_rate > 0 else 1.0
    y1_dscr = round(noi_est / annual_ds, 2) if noi_est > 0 and annual_ds > 0 else None
    y1_dy = round((noi_est / loan_amount_est) * 100, 2) if noi_est > 0 and loan_amount_est > 0 else None
    as_is_ltv = round((loan_amount_est / asset_value_est) * 100, 1) if asset_value_est > 0 else None

    deterministic_metrics = {
        "sofr": sofr,
        "spread_bps": spread_bps,
        "all_in_rate_pct": round(all_in_rate * 100, 2),
        "loan_amount_estimated": round(loan_amount_est, 0),
        "asset_value_estimated": round(asset_value_est, 0),
        "stabilized_value_estimated": round(stabilized_value_est, 0),
        "total_cost_estimated": round(total_cost_est, 0),
        "stabilized_noi": round(stabilized_noi, 0),
        "annual_debt_service": round(annual_ds, 0),
        "y1_dscr": y1_dscr,
        "y1_debt_yield_pct": y1_dy,
        "as_is_ltv_pct": as_is_ltv,
        "waterfall": waterfall,
    }

    deal_data = {
        "property_address": req.property_address,
        "unit_count": req.unit_count,
        "current_revenue": req.current_revenue,
        "current_noi": req.current_noi,
        "pro_forma_rents": req.pro_forma_rents,
        "projection_years": req.projection_years or 5,
        "deterministic_metrics": deterministic_metrics,
    }

    # Compose skill text: full primary + constraint blocks for secondaries
    combined_skill = skill_text
    if expense_constraints:
        combined_skill += "\n\n=== EXPENSE UNDERWRITING CONSTRAINTS ===\n" + expense_constraints
    if calc_constraints:
        combined_skill += "\n\n=== CRE CALCULATIONS CONSTRAINTS ===\n" + calc_constraints

    external_data = {}
    if macro:
        external_data["macro_indicators"] = macro

    schema = get_json_schema("cash_flow")

    system, user = build_analysis_prompt(
        skill_text=combined_skill,
        deal_data=deal_data,
        external_data=external_data if external_data else None,
        json_schema=schema,
        task_description=(
            "Produce a comprehensive cash flow underwriting analysis using the full "
            "CF-1 through CF-10 methodology. This must include:\n\n"
            "CONSTRAINT WATERFALL AND ALL METRICS HAVE BEEN PRE-CALCULATED. "
            "Use the provided waterfall data in deal_data.deterministic_metrics as "
            "authoritative. Your job is to narrate and interpret, NOT calculate. "
            "Report the pre-calculated DSCR, DY, LTV, LTC, and waterfall results "
            "verbatim — do NOT re-derive or recalculate them.\n\n"
            "DEPTH REQUIREMENTS:\n"
            "- Income: GPR, other income, vacancy loss, concessions, bad debt, EGI, EGI/unit\n"
            "- Expenses: total OpEx, per unit, ratio %, line-item breakdown (taxes, insurance, "
            "utilities, R&M, payroll, management, G&A, marketing, reserves)\n"
            "- NOI: stabilized and in-place with per-unit figures\n"
            "- Dual scenario: BOTH lender underwrite AND sponsor proforma with variance analysis "
            "showing GPR, vacancy, EGI, OpEx, ratio, NOI differences and primary drivers\n"
            "- 5-year projections: year-by-year GPR, EGI, OpEx, NOI, NOI/unit\n"
            "- 6-constraint sizing waterfall: USE THE PRE-CALCULATED WATERFALL from "
            "deterministic_metrics — present all 6 constraints, identify binding\n"
            "- Sensitivity: SEPARATE cap rate and vacancy stress tables\n"
            "- Assumptions: rent growth, expense growth, vacancy, management fee, reserves/unit\n"
            "- Analytical outputs: Y1 DSCR, Y1 DY, As-Is LTV — USE PRE-CALCULATED VALUES "
            "(analytical only, NOT sizing gates)\n\n"
            "CRITICAL: SOFR is provided as deterministic_metrics.sofr. All-in rate is "
            "deterministic_metrics.all_in_rate_pct. Apply institutional expense ratios. "
            "DSCR 1.05x is the ONLY threshold. Y1 metrics are analytical, not constraints."
        ),
    )

    parsed = await call_claude_structured(system, user, meter=meter, max_tokens=16384)

    parsed["analysis_mode"] = "real"
    parsed["data_sources"] = {
        "macro_indicators": bool(macro),
        "sofr_live": True,
    }

    # ─── Override: stamp deterministic metrics as authoritative ───────────
    # Claude may return its own metric values — always override with Python-calculated
    constraints = waterfall["constraints"]
    parsed["key_metrics"] = {
        k: {"value": v["value"], "threshold": v["threshold"], "status": v["status"]}
        for k, v in constraints.items()
    }
    parsed["sizing_waterfall"] = {
        "max_loan": round(waterfall["max_loan"], 0),
        "binding_constraint": waterfall["binding_constraint"],
        "constraints": constraints,
        "rate_assumption": f"SOFR ({sofr:.2f}%) + {spread_bps} bps ({all_in_rate * 100:.2f}% all-in)",
    }
    parsed["deterministic_metrics"] = deterministic_metrics

    validated = validate_output("cash_flow", parsed)
    if validated:
        LOG.info("Cash flow analysis output validated against schema")

    return parsed


# ═══════════════════════════════════════════════════════════════════════════
# 10. Nuance Gate Analysis
# ═══════════════════════════════════════════════════════════════════════════

async def analyze_nuance_gate(req, meter=None) -> dict:
    """
    Real nuance gate: detect affordable, rent control, ground lease,
    tax abatement, environmental, seismic, complex ownership flags.

    Uses full nuance-gate-analysis SKILL.md (150 lines):
    - 5-step methodology per nuance
    - Regulatory research via Perplexity
    - HUD data for affordable/Section 8 deals
    - Financial impact assessment from research findings
    - Go/No-Go determination (binary with conditions)
    """
    skill_text = load_skill("nuance-gate-analysis")

    # --- Extract inputs ---
    property_address = getattr(req, "property_address", None)
    nuance_flags = getattr(req, "nuance_flags", None) or []
    deal_context = getattr(req, "deal_context", None) or {}
    focus_areas = getattr(req, "focus_areas", None) or []
    deal_id = getattr(req, "deal_id", None)

    # If no nuance_flags provided, construct research topics from focus_areas
    if not nuance_flags and focus_areas:
        nuance_flags = focus_areas if isinstance(focus_areas, list) else [focus_areas]

    # --- Parse address for location context ---
    city = ""
    state = ""
    if property_address:
        addr_parts = property_address.split(",")
        city = addr_parts[-2].strip() if len(addr_parts) >= 3 else addr_parts[0].strip()
        state = addr_parts[-1].strip().split()[0] if len(addr_parts) >= 2 else ""

    # --- Build Perplexity research queries based on detected nuance types ---
    nuance_type_queries = {
        "affordable": [
            f"affordable housing LIHTC tax credits {city} {state} current rules requirements 2025 2026",
            f"affordable housing compliance obligations penalties {city} {state}",
        ],
        "lihtc": [
            f"LIHTC 4% credits {state} current rules requirements allocation 2025 2026",
            f"LIHTC compliance monitoring penalties recapture {state}",
        ],
        "section_8": [
            f"Section 8 HAP contract {city} {state} renewal requirements HUD",
            f"Section 8 project-based voucher rent caps compliance {state}",
        ],
        "rent_control": [
            f"rent stabilization rent control {city} {state} compliance obligations current rules",
            f"rent control maximum allowable increase {city} {state} 2025 2026 penalties",
        ],
        "ground_lease": [
            f"ground lease CRE lending requirements {state} typical terms",
            f"ground lease financing risk subordination {state} lender considerations",
        ],
        "tax_abatement": [
            f"tax abatement property tax exemption {city} {state} multifamily programs current",
            f"tax abatement expiration impact property value {city} {state}",
        ],
        "environmental": [
            f"environmental contamination Phase I ESA {city} {state} remediation requirements",
            f"EPA brownfield cleanup requirements {state} lender liability CERCLA",
        ],
        "seismic": [
            f"seismic retrofit requirements {city} {state} soft-story ordinance compliance",
            f"seismic retrofit cost multifamily {city} {state} timeline penalties",
        ],
        "complex_ownership": [
            f"TIC tenancy in common financing {state} requirements",
            f"complex ownership structure CRE lending joint venture {state}",
        ],
    }

    # Collect queries based on detected flags
    queries = []
    for flag in nuance_flags:
        flag_lower = str(flag).lower().replace(" ", "_").replace("-", "_")
        if flag_lower in nuance_type_queries:
            queries.extend(nuance_type_queries[flag_lower])
        else:
            # Generic research for unknown nuance types
            queries.append(f"{flag} CRE commercial real estate {city} {state} requirements compliance 2025 2026")
            queries.append(f"{flag} financial impact lending risk {city} {state}")

    # If no specific flags but we have an address, do broad screening
    if not queries and property_address:
        queries = [
            f"{property_address} property regulatory issues affordable rent control",
            f"{city} {state} multifamily regulatory environment rent control tax abatement 2025",
        ]

    # Cap at 8 queries max to control costs
    queries = queries[:8]

    # --- Run research + data pulls in parallel ---
    research_task = _parallel_perplexity(queries, meter=meter) if queries else asyncio.coroutine(lambda: [])()

    # Check for affordable/Section 8 flags — pull HUD data
    affordable_flags = {"affordable", "lihtc", "section_8", "section 8", "hap", "mfte", "421-a", "421a", "lura"}
    has_affordable = any(
        str(f).lower().replace("-", "_").replace(" ", "_") in affordable_flags
        for f in nuance_flags
    )

    hud_task = None
    ami_task = None
    if has_affordable and property_address:
        hud_task = call_valeri_data("hud-data", {"address": property_address}, meter=meter)
        ami_task = call_valeri_data("get_ami_income_limits", {"address": property_address}, meter=meter)

    # Gather all parallel tasks
    tasks_to_gather = [research_task]
    if hud_task:
        tasks_to_gather.append(hud_task)
    if ami_task:
        tasks_to_gather.append(ami_task)

    gathered = await asyncio.gather(*tasks_to_gather, return_exceptions=True)

    research_results = gathered[0] if not isinstance(gathered[0], Exception) else []
    hud_data = gathered[1] if len(gathered) > 1 and not isinstance(gathered[1], Exception) else None
    ami_data = gathered[2] if len(gathered) > 2 and not isinstance(gathered[2], Exception) else None

    # --- Build external_data ---
    external_data = {}

    # Structure research results
    research_data = {}
    if isinstance(research_results, list):
        for i, result in enumerate(research_results):
            if isinstance(result, str) and result:
                query_label = queries[i][:60].replace(" ", "_") if i < len(queries) else f"query_{i}"
                research_data[f"research_{i+1}"] = {
                    "query": queries[i] if i < len(queries) else "",
                    "result": result,
                }
    if research_data:
        external_data["regulatory_research"] = research_data

    if hud_data:
        external_data["hud_data"] = hud_data
    if ami_data:
        external_data["ami_income_limits"] = ami_data

    # --- Build deal_data ---
    deal_data = {
        "deal_id": deal_id,
        "property_address": property_address,
        "nuance_flags_detected": nuance_flags,
        "deal_context": deal_context,
        "focus_areas": focus_areas,
    }

    schema = get_json_schema("nuance_gate")

    system, user = build_analysis_prompt(
        skill_text=skill_text,
        deal_data=deal_data,
        external_data=external_data if external_data else None,
        json_schema=schema,
        task_description=(
            "Analyze this deal for nuance flags using the full 5-step methodology. "
            "Execute ALL steps for EACH detected nuance flag.\n\n"
            "STEP 1 — IDENTIFICATION CONFIRMATION:\n"
            "Confirm each nuance type and specific program/regulation. Identify the "
            "jurisdiction and governing authority. Note available documentation.\n\n"
            "STEP 2 — REGULATORY RESEARCH:\n"
            "Use the provided research data to document current rules, compliance "
            "obligations, penalties, timelines, and recent regulatory changes. "
            "Cite specific statutes, ordinances, or program rules.\n\n"
            "STEP 3 — STATUS ASSESSMENT:\n"
            "Assess compliance standing (compliant/at-risk/violation), years remaining "
            "on program/contract, recent inspections or audits, outstanding issues.\n\n"
            "STEP 4 — FINANCIAL IMPACT ASSESSMENT:\n"
            "Report financial impacts discovered through research. Where research provides "
            "specific numbers (e.g., rent caps, compliance fees, abatement schedules), "
            "present them as findings from the research with source context. Where the "
            "research yields enough data to estimate ranges (e.g., market rent vs restricted "
            "rent per unit), present estimated ranges with assumptions clearly stated.\n"
            "Categories to assess:\n"
            "- Revenue impact: rent caps vs market rents, restricted growth — report "
            "specific caps/limits found in research\n"
            "- Expense impact: compliance costs, monitoring fees, reporting costs — report "
            "fees/costs cited in regulatory sources\n"
            "- Value impact: cap rate premium considerations based on comparable transactions\n"
            "- Cash flow impact: directional NOI effect under restricted vs unrestricted scenarios\n"
            "Where exact impacts cannot be determined from available data, state "
            "'requires property-specific analysis' rather than inventing numbers. "
            "NEVER say 'significant', 'material', 'substantial', or 'meaningful' without "
            "supporting data from research.\n\n"
            "STEP 5 — GO/NO-GO DETERMINATION:\n"
            "Score each criterion (Pass / Fail / Conditional):\n"
            "- DSCR achievable at restricted income levels\n"
            "- LTV supportable at restricted valuation\n"
            "- Sponsor has relevant program experience\n"
            "- Viable exit pathway exists within loan term\n"
            "- Pricing adequately compensates for regulatory risk\n"
            "Decision: All Critical items must Pass or Conditional. Any Critical Fail = NO-GO.\n\n"
            "PRODUCE structured JSON with:\n"
            "- nuance_flags: dict with each flag type containing 'detected' bool, 'program', "
            "'jurisdiction', 'compliance_status', 'financial_impact' (with dollar amounts), 'details'\n"
            "- gate_keeping_issues: list of deal-critical concerns with type, item, "
            "dollar_impact, severity\n"
            "- contained_issues: list of manageable concerns with type, item, "
            "dollar_impact, mitigation\n"
            "- financial_impact_basis: always set to 'research-derived estimates, not deterministic calculations'\n"
            "- financial_impact_summary: estimated annual revenue impact, estimated annual "
            "expense impact, estimated value effect, estimated annual NOI delta — "
            "use ranges where exact figures are unavailable, cite research sources\n"
            "- go_no_go_scorecard: list of criteria with criterion, status (Pass/Fail/Conditional), notes\n"
            "- recommendation: PROCEED/PROCEED_WITH_CONDITIONS/NO_GO with conditions list\n"
            "- summary: 3-5 sentences referencing specific findings from research"
        ),
    )

    parsed = await call_claude_structured(system, user, meter=meter, max_tokens=8192)
    parsed["analysis_mode"] = "real"
    parsed["financial_impact_basis"] = "research-derived estimates, not deterministic calculations"
    parsed["data_sources"] = {
        "perplexity_queries": len([r for r in (research_results if isinstance(research_results, list) else []) if isinstance(r, str) and r]),
        "hud_data": bool(hud_data),
        "ami_data": bool(ami_data),
    }

    validated = validate_output("nuance_gate", parsed)
    if validated:
        LOG.info("Nuance gate analysis output validated against schema")

    return parsed


# ═══════════════════════════════════════════════════════════════════════════
# 11. IC Memo
# ═══════════════════════════════════════════════════════════════════════════

async def analyze_ic_memo(req, meter=None) -> dict:
    """
    Real IC memo generation: synthesize all prior analysis into
    investment committee recommendation.

    Uses multi-skill composition:
    - PRIMARY: credit-memo SKILL.md (361 lines) — full 10-section methodology
    - SECONDARY: institutional-formatting — constraint block for V3.1 standards
    - SECONDARY: loan-sizing — constraint block for sizing waterfall

    Accepts all prior phase results as optional dicts to build a comprehensive
    synthesis. Every number traces to prior phase output or deterministic calculation.
    """
    skill_text = load_skill("credit-memo")

    # Multi-skill composition: primary + constraint blocks
    formatting_constraints = load_skill_constraints("institutional-formatting")
    sizing_constraints = load_skill_constraints("loan-sizing")

    combined_skill = skill_text
    if formatting_constraints:
        combined_skill += "\n\n=== FORMATTING CONSTRAINTS ===\n" + formatting_constraints
    if sizing_constraints:
        combined_skill += "\n\n=== LOAN SIZING CONSTRAINTS ===\n" + sizing_constraints

    # --- Extract all available prior phase results ---
    deal_id = getattr(req, "deal_id", None)
    property_address = getattr(req, "property_address", None)
    unit_count = getattr(req, "unit_count", None)
    loan_amount = getattr(req, "loan_amount", None)
    memo_format = getattr(req, "memo_format", None) or "full"
    include_appendices = getattr(req, "include_appendices", None)

    # Prior phase data — all optional, used to build comprehensive deal_data
    sponsor_data = getattr(req, "sponsor_data", None) or {}
    market_data = getattr(req, "market_data", None) or {}
    comp_data = getattr(req, "comp_data", None) or {}
    rent_roll_data = getattr(req, "rent_roll_data", None) or {}
    cash_flow_data = getattr(req, "cash_flow_data", None) or {}
    sizing_data = getattr(req, "sizing_data", None) or {}

    # Build comprehensive deal_data from all available sources
    deal_data = {
        "deal_id": deal_id,
        "property_address": property_address,
        "unit_count": unit_count,
        "loan_amount": loan_amount,
        "memo_format": memo_format,
        "include_appendices": include_appendices,
    }

    # Attach all prior phase results
    prior_phases = {}
    if sponsor_data:
        prior_phases["sponsor_analysis"] = sponsor_data
    if market_data:
        prior_phases["market_analysis"] = market_data
    if comp_data:
        prior_phases["comparable_analysis"] = comp_data
    if rent_roll_data:
        prior_phases["rent_roll_analysis"] = rent_roll_data
    if cash_flow_data:
        prior_phases["cash_flow_underwriting"] = cash_flow_data
    if sizing_data:
        prior_phases["loan_sizing"] = sizing_data

    if prior_phases:
        deal_data["prior_phase_results"] = prior_phases

    # Track which phases are available vs missing
    phase_availability = {
        "sponsor_analysis": bool(sponsor_data),
        "market_analysis": bool(market_data),
        "comparable_analysis": bool(comp_data),
        "rent_roll_analysis": bool(rent_roll_data),
        "cash_flow_underwriting": bool(cash_flow_data),
        "loan_sizing": bool(sizing_data),
    }
    deal_data["phase_availability"] = phase_availability

    missing_phases = [k for k, v in phase_availability.items() if not v]
    available_phases = [k for k, v in phase_availability.items() if v]

    schema = get_json_schema("ic_memo")

    system, user = build_analysis_prompt(
        skill_text=combined_skill,
        deal_data=deal_data,
        json_schema=schema,
        task_description=(
            "Generate a comprehensive Investment Committee Memorandum as structured JSON "
            "using the full 10-section methodology. This is the CAPSTONE document — it "
            "synthesizes and draws conclusions from all prior analysis.\n\n"
            "REQUIRED SECTIONS (all 10 must be present):\n\n"
            "1. DEAL TAPE STRIP — Single-page dashboard: property, units, year built, "
            "sponsor (name + tier), risk rating, loan request, recommended loan, rate "
            "(SOFR + spread, all-in %), term, LTV (As-Is), LTV (Stabilized), LTC, "
            "DSCR (Stabilized), DY (Stabilized), binding constraint, recommendation.\n\n"
            "2. TRANSACTION SUMMARY — Property overview, sponsor overview, transaction "
            "purpose, loan request vs recommended, business plan summary.\n"
            "   SOURCES & USES TABLE (MANDATORY): Full S&U with Sources (Senior Loan, "
            "Sponsor Equity — include interest reserve, capex holdback if applicable) "
            "and Uses (Purchase Price or Loan Payoff, Capex/Renovation Budget, Closing "
            "Costs, Reserves, Interest Reserve). Sources MUST EQUAL Uses. Use full dollar "
            "format ($42,000,000 not $42.0M). Show percentage column for each side.\n\n"
            "3. SPONSOR SUMMARY — Tier classification with rationale, track record "
            "(units, markets, performance), financial capacity (NW, liquidity), key "
            "strengths and concerns.\n\n"
            "4. MARKET SUMMARY — Market rating, population/employment trends, "
            "supply/demand dynamics, submarket positioning, rent growth trajectory, "
            "key market risks.\n\n"
            "5. PROPERTY & CASH FLOW — Unit mix summary table, dual-scenario "
            "presentation (Sponsor Proforma vs Lender Underwrite), NOI bridge (T-12 "
            "to Lender Stabilized), key variance analysis, expense ratio analysis.\n\n"
            "6. VALUATION — As-Is value methodology and conclusion, stabilized value "
            "methodology and conclusion, cap rate support from comps, $/unit analysis.\n\n"
            "7. LOAN SIZING & SOURCES AND USES — 6-constraint waterfall table showing "
            "ALL constraints (LTV As-Is <=75%, LTV Stabilized <=75%, DSCR Stabilized "
            ">=1.05x, DY Stabilized >=7.0%, LTC <=80%, $100M cap). Show threshold, "
            "max loan, and binding indicator for each. Binding constraint = MIN of all 6. "
            "Broker request comparison.\n\n"
            "8. DEAL STRUCTURE — Rate, term, extensions, IO/amort, fee structure, "
            "covenants (DSCR test, occupancy test), reserves, rate cap, cash management "
            "triggers, extension conditions.\n\n"
            "9. RISK ANALYSIS — Key risks with specific mitigants. Cap rate sensitivity "
            "table (SEPARATE). Vacancy stress table (SEPARATE). Breakeven occupancy. "
            "Lender returns (unlevered + levered IRR/MOIC at 12/24/36 months).\n\n"
            "10. CREDIT RECOMMENDATION — Decision: APPROVE / APPROVE_WITH_CONDITIONS / "
            "DECLINE. Rationale (3-5 sentences). Conditions (if applicable, specific and "
            "measurable). Key strengths (3-5). Key weaknesses (3-5). Exceptions required.\n\n"
            "CRITICAL RULES:\n"
            "- Every number must trace to prior_phase_results or deterministic calculation. "
            "If a phase is missing, state 'Not Available — [phase] not completed' for that "
            "section. NEVER invent numbers.\n"
            "- All metrics from LENDER underwrite, never sponsor/broker proforma.\n"
            "- Sources & Uses MUST balance exactly.\n"
            "- Sensitivity tables MUST be separate (cap rate vs vacancy).\n"
            "- Recommendation must be clear and actionable — no hedging.\n"
            f"- Missing phases: {missing_phases if missing_phases else 'None — all phases available'}\n"
            f"- Available phases: {available_phases}"
        ),
    )

    parsed = await call_claude_structured(system, user, meter=meter, max_tokens=16384)
    parsed["analysis_mode"] = "real"
    parsed["phase_availability"] = phase_availability

    validated = validate_output("ic_memo", parsed)
    if validated:
        LOG.info("IC memo output validated against schema")

    return parsed


# ═══════════════════════════════════════════════════════════════════════════
# 12. Term Sheet Comparator
# ═══════════════════════════════════════════════════════════════════════════

async def analyze_term_sheet_comparator(req, meter=None) -> dict:
    """
    Real term sheet comparison: side-by-side analysis of multiple
    term sheets with deterministic pricing, structure, and covenant assessment.

    No dedicated SKILL.md exists — uses comprehensive inline methodology
    covering rate, fees, term, prepayment, covenants, reserves, and recourse.

    Deterministic comparisons (rate differential, fee differential, total cost)
    are calculated first. Claude adds institutional narrative and recommendation.
    """
    # --- Extract inputs ---
    term_sheets = getattr(req, "term_sheets", None) or []
    property_address = getattr(req, "property_address", None)
    loan_amount = getattr(req, "loan_amount", None)
    comparison_criteria = getattr(req, "comparison_criteria", None)

    if not term_sheets or len(term_sheets) < 2:
        return {
            "error": "At least 2 term sheets required for comparison. Provide term_sheets as list of dicts with lender_name and structured terms.",
            "analysis_mode": "real",
            "status": "insufficient_data",
        }

    # --- Build comprehensive inline methodology (no SKILL.md exists) ---
    comparator_methodology = """
=== TERM SHEET COMPARATOR METHODOLOGY ===

PURPOSE: Compare multiple CRE bridge loan term sheets side-by-side to identify
the optimal financing option from the BORROWER'S perspective. Evaluate total
cost of capital, structural flexibility, and covenant burden.

COMPARISON DIMENSIONS (all must be analyzed):

1. RATE ANALYSIS
   - Index (SOFR, Prime, Fixed)
   - Spread (bps)
   - All-in rate (index + spread)
   - Rate cap requirement and cost
   - Floor rate (if any)

2. FEE ANALYSIS
   - Origination fee (% and $)
   - Exit fee (% and $)
   - Extension fee (% per extension)
   - Application / commitment / legal fees
   - Total Day-1 cost (origination + closing)
   - Total cost over full term (all fees)

3. TERM & STRUCTURE
   - Initial term (months)
   - Extension options (number x duration)
   - Total possible term
   - IO period vs amortization schedule
   - Minimum hold period / lockout

4. PREPAYMENT
   - Lockout period (months)
   - Prepayment penalty schedule (declining %)
   - Open window (months before maturity)
   - Yield maintenance vs step-down vs open

5. COVENANTS
   - DSCR test (trigger, test frequency, cure period)
   - Debt yield test
   - Occupancy test
   - Cash trap triggers and release
   - Cash sweep provisions

6. RESERVES
   - Tax escrow (required or waived)
   - Insurance escrow
   - Capex / replacement reserve ($/unit/year)
   - Interest reserve (months)
   - Operating reserve
   - Total upfront reserve requirement

7. RECOURSE & GUARANTY
   - Recourse type (non-recourse, partial, full)
   - Carve-out guaranty scope
   - Net worth requirement (ratio to loan)
   - Liquidity requirement
   - Burn-off provisions

8. REPORTING & OPERATIONAL
   - Financial reporting frequency
   - Rent roll submission frequency
   - Budget approval requirements
   - Management approval rights
   - Transfer / assumption provisions

SCORING: Rate each dimension as ADVANTAGE / NEUTRAL / DISADVANTAGE per lender.
Count total advantages to determine overall recommendation.

CRITICAL: Calculate deterministic metrics first (rate differential, fee differential,
total cost of capital). Narrative adds institutional context but numbers are authoritative.
"""

    # --- Deterministic comparison calculations ---
    deterministic_comparisons = {}

    # Parse rates and fees from each term sheet
    parsed_sheets = []
    for ts in term_sheets:
        lender = ts.get("lender_name", "Unknown")
        terms = ts if not ts.get("terms") else ts.get("terms", {})

        # Extract key numeric fields
        spread_bps = float(terms.get("spread_bps", 0) or terms.get("spread", 0) or 0)
        index_rate = float(terms.get("index_rate", 0) or terms.get("sofr", 0) or 0)
        all_in_rate = float(terms.get("all_in_rate", 0) or 0)
        if not all_in_rate and (index_rate or spread_bps):
            all_in_rate = index_rate + spread_bps / 100

        origination_pct = float(terms.get("origination_fee_pct", 0) or terms.get("origination_fee", 0) or 0)
        exit_fee_pct = float(terms.get("exit_fee_pct", 0) or terms.get("exit_fee", 0) or 0)
        extension_fee_pct = float(terms.get("extension_fee_pct", 0) or terms.get("extension_fee", 0) or 0)

        initial_term_months = int(terms.get("initial_term_months", 0) or terms.get("term_months", 0) or 0)
        extensions = terms.get("extensions", "")
        io_months = int(terms.get("io_months", 0) or terms.get("io_period", 0) or 0)

        parsed_sheets.append({
            "lender_name": lender,
            "spread_bps": spread_bps,
            "index_rate": index_rate,
            "all_in_rate": all_in_rate,
            "origination_fee_pct": origination_pct,
            "exit_fee_pct": exit_fee_pct,
            "extension_fee_pct": extension_fee_pct,
            "initial_term_months": initial_term_months,
            "extensions": extensions,
            "io_months": io_months,
            "raw_terms": terms,
        })

    # Calculate differentials (relative to first term sheet as baseline)
    if len(parsed_sheets) >= 2:
        base = parsed_sheets[0]
        comparisons = []
        for i, ts in enumerate(parsed_sheets[1:], 1):
            rate_diff_bps = round((ts["all_in_rate"] - base["all_in_rate"]) * 100, 1) if (ts["all_in_rate"] and base["all_in_rate"]) else None
            origination_diff_pct = round(ts["origination_fee_pct"] - base["origination_fee_pct"], 2) if (ts["origination_fee_pct"] or base["origination_fee_pct"]) else None

            # Total cost of capital over hold period (assume 24 months if not specified)
            hold_months = 24
            if loan_amount:
                la = float(loan_amount)
                base_total_cost = (
                    la * (base["all_in_rate"] / 100) * (hold_months / 12)
                    + la * base["origination_fee_pct"] / 100
                    + la * base["exit_fee_pct"] / 100
                ) if base["all_in_rate"] else 0

                ts_total_cost = (
                    la * (ts["all_in_rate"] / 100) * (hold_months / 12)
                    + la * ts["origination_fee_pct"] / 100
                    + la * ts["exit_fee_pct"] / 100
                ) if ts["all_in_rate"] else 0

                cost_diff = round(ts_total_cost - base_total_cost, 2) if (base_total_cost and ts_total_cost) else None
            else:
                base_total_cost = None
                ts_total_cost = None
                cost_diff = None

            comparisons.append({
                "lender_a": base["lender_name"],
                "lender_b": ts["lender_name"],
                "rate_differential_bps": rate_diff_bps,
                "origination_fee_differential_pct": origination_diff_pct,
                "total_cost_lender_a": round(base_total_cost, 2) if base_total_cost else None,
                "total_cost_lender_b": round(ts_total_cost, 2) if ts_total_cost else None,
                "total_cost_differential": cost_diff,
                "hold_period_months": hold_months,
            })

        deterministic_comparisons = {
            "pairwise_comparisons": comparisons,
            "parsed_term_sheets": parsed_sheets,
        }

    # --- Build deal_data ---
    deal_data = {
        "term_sheets": term_sheets,
        "property_address": property_address,
        "loan_amount": loan_amount,
        "comparison_criteria": comparison_criteria,
    }

    if deterministic_comparisons:
        deal_data["deterministic_comparisons"] = deterministic_comparisons

    schema = get_json_schema("term_sheet_comparator")

    system, user = build_analysis_prompt(
        skill_text=comparator_methodology,
        deal_data=deal_data,
        json_schema=schema,
        task_description=(
            "Compare these term sheets side-by-side for a CRE bridge loan using the full "
            "8-dimension methodology. Produce comprehensive structured JSON.\n\n"
            "DETERMINISTIC COMPARISONS HAVE BEEN PRE-CALCULATED and are provided in "
            "deterministic_comparisons. Use these as the authoritative numbers for rate "
            "differential, fee differential, and total cost of capital. Your job is to "
            "add institutional narrative, assess qualitative dimensions (covenant burden, "
            "structural flexibility, recourse), and provide a recommendation.\n\n"
            "REQUIRED OUTPUT:\n"
            "- comparison_summary: term_sheets_analyzed count, recommendation (lender name), "
            "recommendation_rationale (2-3 sentences)\n"
            "- rate_analysis: per lender — index, spread_bps, all_in_rate, rate_diff_bps_vs_best\n"
            "- fee_analysis: per lender — origination_pct, exit_pct, extension_pct, "
            "total_day1_cost, total_cost_over_term\n"
            "- term_analysis: per lender — initial_term, extensions, total_term, io_period, lockout\n"
            "- prepayment_analysis: per lender — lockout, penalty_schedule, open_window\n"
            "- covenant_analysis: per lender — dscr_test, dy_test, occupancy_test, "
            "cash_trap_triggers, covenant_burden_rating (Light/Moderate/Heavy)\n"
            "- reserve_analysis: per lender — tax_escrow, insurance_escrow, capex_reserve, "
            "interest_reserve, total_upfront_reserves\n"
            "- recourse_analysis: per lender — recourse_type, nw_requirement, "
            "liquidity_requirement, carveout_scope\n"
            "- side_by_side_matrix: list of comparison dimensions with value per lender "
            "and advantage indicator\n"
            "- scoring_summary: per lender — advantages_count, disadvantages_count, "
            "neutral_count, overall_score\n"
            "- recommendation: which term sheet is superior, rationale, key differentiators, "
            "negotiation_points (what to push back on with each lender)\n"
            "- total_cost_comparison: per lender — total cost of capital at 12/24/36 month "
            "hold periods (if loan_amount provided)\n"
            "- summary: 1 paragraph institutional assessment\n\n"
            "CRITICAL: Numbers in rate_analysis and fee_analysis must match the "
            "deterministic_comparisons provided. Do NOT override calculated figures. "
            "If term sheet data is incomplete for a dimension, state 'Not specified' — "
            "never invent terms."
        ),
    )

    parsed = await call_claude_structured(system, user, meter=meter, max_tokens=8192)
    parsed["analysis_mode"] = "real"

    # Inject deterministic comparisons as authoritative layer
    if deterministic_comparisons:
        parsed["deterministic_comparisons"] = deterministic_comparisons

    validated = validate_output("term_sheet_comparator", parsed)
    if validated:
        LOG.info("Term sheet comparator output validated against schema")

    return parsed


# ═══════════════════════════════════════════════════════════════════════════
# 13. Business Plan Analysis
# ═══════════════════════════════════════════════════════════════════════════

async def analyze_business_plan(req, meter=None) -> dict:
    """
    Real business plan analysis: feasibility assessment, renovation scope,
    rent growth achievability, execution risk evaluation.

    Uses construction-budget-review SKILL.md (239 lines) as primary
    with returns-analysis constraint block.
    """
    skill_text = load_skill("construction-budget-review")
    returns_constraints = load_skill_constraints("returns-analysis")

    combined_skill = skill_text
    if returns_constraints:
        combined_skill += "\n\n=== RETURNS ANALYSIS CONSTRAINTS ===\n" + returns_constraints

    # Research comparable renovation projects
    addr_parts = req.property_address.split(",")
    city = addr_parts[-2].strip() if len(addr_parts) >= 3 else addr_parts[0]
    state = addr_parts[-1].strip().split()[0] if len(addr_parts) >= 2 else ""

    queries = [
        f"{city} {state} multifamily renovation cost per unit 2024 2025 2026 value-add",
        f"{city} {state} apartment value-add rent premium after renovation Class B C",
    ]
    results = await _parallel_perplexity(queries, meter=meter)

    research_data = {}
    for label, result in zip(["renovation_costs", "rent_premium"], results):
        if isinstance(result, str) and result:
            research_data[label] = result

    deal_data = {
        "property_address": req.property_address,
        "unit_count": req.unit_count,
        "current_avg_rent": req.current_avg_rent,
        "pro_forma_rent": req.pro_forma_rent,
        "renovation_budget": req.renovation_budget,
        "renovation_per_unit": req.renovation_per_unit,
        "lease_up_months": req.lease_up_months,
        "business_plan_narrative": req.business_plan_narrative,
    }

    system, user = build_analysis_prompt(
        skill_text=combined_skill,
        deal_data=deal_data,
        external_data=research_data if research_data else None,
        task_description=(
            "Assess this value-add business plan for a CRE bridge loan. Produce JSON with:\n"
            "- business_plan: feasibility_rating, rent_growth_assessment, capex_reasonableness, "
            "lease_up_timeline, key_risks list, recommendation\n"
            "- renovation_analysis: budget_total, per_unit, scope_assessment, "
            "market_benchmark_per_unit, budget_vs_benchmark\n"
            "- rent_analysis: current_rent, target_rent, lift_pct, market_support_assessment\n"
            "- timeline_assessment: renovation_months, lease_up_months, total_stabilization_months, "
            "risk_level\n"
            "- summary: 1 paragraph"
        ),
    )

    parsed = await call_claude_structured(system, user, meter=meter, max_tokens=8192)
    parsed["analysis_mode"] = "real"
    parsed["research_queries"] = len([r for r in results if isinstance(r, str) and r])
    return parsed


# ═══════════════════════════════════════════════════════════════════════════
# 14. Renovation ROI
# ═══════════════════════════════════════════════════════════════════════════

async def analyze_renovation_roi(req, meter=None) -> dict:
    """
    Real renovation ROI: rent lift analysis, payback period,
    value creation at various cap rates, IRR sensitivity.

    Uses construction-budget-review + returns-analysis constraint block.
    """
    skill_text = load_skill("construction-budget-review")
    returns_constraints = load_skill_constraints("returns-analysis")

    target_rent = req.target_rent or req.current_avg_rent * 1.25
    rent_lift = target_rent - req.current_avg_rent
    annual_lift = rent_lift * req.unit_count * 12
    budget = req.renovation_budget_total or (req.renovation_per_unit or 25000) * req.unit_count

    # ─── Pre-calculate ALL financial metrics deterministically ──────
    per_unit_budget = budget / req.unit_count if req.unit_count > 0 else 0
    rent_lift_pct = (rent_lift / req.current_avg_rent * 100) if req.current_avg_rent > 0 else 0
    simple_payback_months = round(budget / (annual_lift / 12)) if annual_lift > 0 else 0
    roi_at_5_cap = (annual_lift / budget * 100) if budget > 0 else 0
    roi_at_5_25_cap = (annual_lift / budget * 100) if budget > 0 else 0
    roi_at_5_5_cap = (annual_lift / budget * 100) if budget > 0 else 0
    value_creation_at_5_cap = annual_lift / 0.05 if annual_lift > 0 else 0
    value_creation_at_5_25_cap = annual_lift / 0.0525 if annual_lift > 0 else 0
    value_creation_at_5_5_cap = annual_lift / 0.055 if annual_lift > 0 else 0

    deterministic_metrics = {
        "current_rent": f"${req.current_avg_rent:,.0f}",
        "target_rent": f"${target_rent:,.0f}",
        "rent_lift": f"${rent_lift:,.0f}",
        "rent_lift_pct": f"{rent_lift_pct:.1f}%",
        "annual_income_increase": f"${annual_lift:,.0f}",
        "total_renovation_budget": f"${budget:,.0f}",
        "per_unit_budget": f"${per_unit_budget:,.0f}",
        "simple_payback_months": simple_payback_months,
        "roi_at_5_cap": f"{roi_at_5_cap:.1f}%",
        "roi_at_5_25_cap": f"{roi_at_5_25_cap:.1f}%",
        "roi_at_5_5_cap": f"{roi_at_5_5_cap:.1f}%",
        "value_creation_at_5_cap": f"${value_creation_at_5_cap:,.0f}",
        "value_creation_at_5_25_cap": f"${value_creation_at_5_25_cap:,.0f}",
        "value_creation_at_5_5_cap": f"${value_creation_at_5_5_cap:,.0f}",
    }

    deal_data = {
        "property_address": req.property_address,
        "unit_count": req.unit_count,
        "current_avg_rent": req.current_avg_rent,
        "target_rent": target_rent,
        "rent_lift_per_unit": rent_lift,
        "annual_income_increase": annual_lift,
        "renovation_budget_total": budget,
        "renovation_per_unit": per_unit_budget,
        "hold_period_months": req.hold_period_months or 36,
        "scope_description": req.scope_description,
        "asset_class_current": req.asset_class_current,
        "asset_class_target": req.asset_class_target,
        "deterministic_metrics": deterministic_metrics,
    }

    combined_skill = skill_text
    if returns_constraints:
        combined_skill += "\n\n=== RETURNS ANALYSIS CONSTRAINTS ===\n" + returns_constraints

    system, user = build_analysis_prompt(
        skill_text=combined_skill,
        deal_data=deal_data,
        task_description=(
            "Analyze renovation ROI for this value-add CRE deal.\n\n"
            "ALL ROI METRICS HAVE BEEN PRE-CALCULATED. Use the provided "
            "deterministic_metrics as authoritative. Your job is to narrate "
            "and interpret, assess market reasonableness, and provide "
            "institutional judgment. Do NOT recalculate.\n\n"
            "Produce JSON with:\n"
            "- renovation_roi: current_rent, target_rent, rent_lift, rent_lift_pct, "
            "annual_income_increase, total_renovation_budget, per_unit_budget, "
            "simple_payback_months, roi_at_5_cap, roi_at_5_25_cap, roi_at_5_5_cap, "
            "value_creation_at_5_cap, value_creation_at_5_25_cap, value_creation_at_5_5_cap, "
            "recommendation\n"
            "- sensitivity: cap_rate_scenarios list with cap_rate, value_creation, roi_pct\n"
            "- risk_factors: list of strings\n"
            "- summary: 1 paragraph\n\n"
            "Use the exact values from deterministic_metrics for all numeric fields."
        ),
    )

    parsed = await call_claude_structured(system, user, meter=meter, max_tokens=4096)

    # Override parsed output with deterministic values (Python is authoritative)
    parsed.setdefault("renovation_roi", {})
    parsed["renovation_roi"].update(deterministic_metrics)

    parsed["analysis_mode"] = "real"
    return parsed


# ═══════════════════════════════════════════════════════════════════════════
# 15. Quick Review
# ═══════════════════════════════════════════════════════════════════════════

async def analyze_quick_review(req, meter=None) -> dict:
    """
    Orchestrated Quick Review: internally runs sponsor → market → comps analysis
    in parallel, then synthesizes into a comprehensive screening memo.

    Produces 4 DOCX outputs:
    - Quick Review screening memo
    - Sponsor Analysis report
    - Market Research report
    - Comparable Analysis report

    Uses full quick-review SKILL.md (462 lines):
    - QR-0 through QR-9 (10 phases)
    - 6-constraint sizing waterfall
    - Full sponsor / market / comps orchestration
    - Property context from data services
    """
    from types import SimpleNamespace

    # ─── Phase 0: Deal intake & deterministic sizing ───────────────────

    sofr = await get_current_sofr(meter=meter)
    spread_bps = 350
    all_in_rate = (sofr + spread_bps / 100) / 100

    asset_value = req.asset_value or req.purchase_price or req.loan_amount * 1.4
    stabilized_value = asset_value * 1.08
    total_cost = asset_value + (req.unit_count * 15000)
    noi_est = req.current_noi or (stabilized_value * 0.0525)

    waterfall = run_constraint_waterfall(
        loan_amount=req.loan_amount,
        as_is_value=asset_value,
        stabilized_value=stabilized_value,
        total_cost=total_cost,
        noi=noi_est,
        rate=all_in_rate,
        unit_count=req.unit_count,
    )

    # ─── Phase 1-3: Parallel sponsor + market + comps analysis ─────────
    # Build lightweight request objects for tier2 functions
    from api.analysis.tier2 import analyze_sponsor, analyze_market, analyze_comps

    # Load v9 methodology and extract phase-specific overrides for each sub-tool
    full_methodology = load_methodology()
    sponsor_methodology = extract_methodology_section(
        full_methodology,
        ["Phase 2", "Sponsor", "Report 1", "sponsor research", "sponsor due diligence"],
    ) if full_methodology else ""
    market_methodology = extract_methodology_section(
        full_methodology,
        ["Phase 3", "Market", "Submarket", "Report 2", "metro", "MSA", "market research"],
    ) if full_methodology else ""
    comps_methodology = extract_methodology_section(
        full_methodology,
        ["Phase 3", "Comp", "Comparable", "Report 3", "rent comp", "sales comp"],
    ) if full_methodology else ""

    LOG.info(
        "Quick Review: methodology loaded (%d chars) — sponsor=%d, market=%d, comps=%d",
        len(full_methodology),
        len(sponsor_methodology),
        len(market_methodology),
        len(comps_methodology),
    )

    sponsor_req = SimpleNamespace(
        sponsor_name=req.sponsor_name,
        sponsor_website=None,
        additional_context=req.notes,
    )
    market_req = SimpleNamespace(
        property_address=req.property_address,
        radius_miles=3.0,
        include_demographics=True,
        include_employment=True,
        include_supply_pipeline=True,
    )
    comps_req = SimpleNamespace(
        property_address=req.property_address,
        unit_count=req.unit_count,
        asset_class="B",
        year_built=None,
        comp_types=["sales", "rent"],
    )

    # Run all three in parallel — full depth, same as standalone calls
    # Each gets its phase-specific methodology override from the v9 spec
    LOG.info("Quick Review: launching parallel sponsor + market + comps analysis")
    sponsor_task = analyze_sponsor(
        sponsor_req, meter=meter, methodology_override=sponsor_methodology,
    )
    market_task = analyze_market(
        market_req, meter=meter, methodology_override=market_methodology,
    )
    comps_task = analyze_comps(
        comps_req, meter=meter, methodology_override=comps_methodology,
    )

    # Gather with exception handling so one failure doesn't kill the others
    phase_results = await asyncio.gather(
        sponsor_task, market_task, comps_task,
        return_exceptions=True,
    )

    sponsor_result = phase_results[0] if isinstance(phase_results[0], dict) else {}
    market_result = phase_results[1] if isinstance(phase_results[1], dict) else {}
    comps_result = phase_results[2] if isinstance(phase_results[2], dict) else {}

    if isinstance(phase_results[0], Exception):
        LOG.warning("Quick Review: sponsor analysis failed: %s", phase_results[0])
    if isinstance(phase_results[1], Exception):
        LOG.warning("Quick Review: market analysis failed: %s", phase_results[1])
    if isinstance(phase_results[2], Exception):
        LOG.warning("Quick Review: comps analysis failed: %s", phase_results[2])

    LOG.info(
        "Quick Review: phase results collected — sponsor=%s, market=%s, comps=%s",
        "OK" if sponsor_result else "FAILED",
        "OK" if market_result else "FAILED",
        "OK" if comps_result else "FAILED",
    )

    # ─── Phase 4-6: Quick cash flow + synthesis ────────────────────────
    # Build synthesis prompt with ALL prior phase data
    skill_text = load_skill("quick-review")

    deal_data = {
        "property_address": req.property_address,
        "unit_count": req.unit_count,
        "loan_amount": req.loan_amount,
        "asset_value": asset_value,
        "stabilized_value": stabilized_value,
        "total_cost": total_cost,
        "noi_estimate": noi_est,
        "sponsor_name": req.sponsor_name,
        "loan_purpose": req.loan_purpose or "bridge",
        "sofr": sofr,
        "all_in_rate_pct": round(all_in_rate * 100, 2),
        "waterfall": waterfall,
        "notes": req.notes,
    }

    external_data = {
        "sponsor_analysis": sponsor_result,
        "market_analysis": market_result,
        "comp_analysis": comps_result,
    }

    schema = get_json_schema("quick_review")

    # Load the LOCKED memo format spec — authoritative output format
    qr_format_spec = load_memo_format_spec("quick_review")

    system, user = build_analysis_prompt(
        skill_text=skill_text,
        deal_data=deal_data,
        external_data=external_data,
        json_schema=schema,
        task_description=(
            "You are synthesizing a QUICK REVIEW screening memo from completed "
            "sponsor, market, and comparable analyses. All three analyses have already "
            "been run in full — their results are provided below as external_data.\n\n"
            "Your job is to SYNTHESIZE these results into the Quick Review format "
            "following the MEMO FORMAT SPECIFICATION provided in the system prompt. "
            "The format spec defines the EXACT section structure, ordering, and content "
            "requirements for the memo output. DO NOT deviate from the spec.\n\n"
            "DO NOT re-analyze — summarize and draw credit conclusions.\n\n"
            "METHODOLOGY SECTIONS TO FOLLOW:\n"
            "- Use the Sizing & Constraint Waterfall section for all credit metrics\n"
            "- Use the Sponsor Assessment Framework for tier classification\n"
            "- Use the Market Snapshot Requirements for market rating\n"
            "- Use the Risk Assessment Framework for strengths/risks\n"
            "- Use the Report Structure section for output organization\n\n"
            "DEPTH REQUIREMENTS:\n"
            "- screen_result: PASS/CONDITIONAL/FAIL with rationale\n"
            "- property: address, unit_count, asset_value, per_unit, stabilized, purpose\n"
            "- key_metrics: ALL 5 constraints (ltv_as_is, ltv_stabilized, dscr_stabilized, "
            "debt_yield, ltc) each with value, threshold, status — USE WATERFALL DATA\n"
            "- sizing: max_loan from waterfall, binding constraint, requested vs sized, "
            "rate assumption with SOFR breakdown — USE WATERFALL DATA\n"
            "- sponsor_assessment: name, tier, recommendation — PULL FROM sponsor_analysis\n"
            "- market_snapshot: vacancy, rent growth, supply pipeline, rating — PULL FROM market_analysis\n"
            "- strengths: 3-5 specific, evidence-based from all phases\n"
            "- risks: 3-5 with risk, detail, severity, mitigant from all phases\n"
            "- dd_questions: 5-10 specific due diligence questions\n"
            "- recommendation: 1-2 sentences\n"
            "- recommendation_detail: full paragraph with credit rationale referencing "
            "sponsor, market, comps, and sizing\n\n"
            "The waterfall data is DETERMINISTIC — use it verbatim for all credit metrics. "
            "The sponsor/market/comps data is RESEARCH-BASED — synthesize for narrative."
        ),
        methodology=full_methodology,
        memo_format_spec=qr_format_spec,
    )

    parsed = await call_claude_structured(system, user, meter=meter, max_tokens=16384)

    parsed["analysis_mode"] = "real"
    parsed["orchestration"] = {
        "phases_executed": ["sponsor_analysis", "market_research", "comp_analysis", "synthesis"],
        "sponsor_status": "completed" if sponsor_result else "failed",
        "market_status": "completed" if market_result else "failed",
        "comps_status": "completed" if comps_result else "failed",
    }
    parsed["data_sources"] = {
        "sofr_live": True,
        "sponsor_queries": sponsor_result.get("research_queries_executed", 0),
        "market_queries": market_result.get("data_sources", {}).get("perplexity_queries", 0),
        "comps_queries": comps_result.get("data_sources", {}).get("perplexity_queries", 0),
    }

    # Enrich with deterministic waterfall data (authoritative — always override)
    constraints = waterfall["constraints"]
    parsed["key_metrics"] = {
        k: {"value": v["value"], "threshold": v["threshold"], "status": v["status"]}
        for k, v in constraints.items()
    }

    max_loan = waterfall["max_loan"]
    parsed["sizing"] = {
        "max_loan_from_waterfall": round(max_loan, 0),
        "binding_constraint": waterfall["binding_constraint"],
        "loan_requested": req.loan_amount,
        "request_within_sizing": req.loan_amount <= max_loan,
        "rate_assumption": f"SOFR ({sofr:.2f}%) + {spread_bps} bps ({all_in_rate * 100:.2f}% all-in)",
    }

    validated = validate_output("quick_review", parsed)
    if validated:
        LOG.info("Quick review output validated against schema")

    # ─── Phase 7-8: Generate DOCX reports ──────────────────────────────
    # Generate DOCX for sub-tools + the QR memo itself
    documents = []
    try:
        from api.analysis.report.mapper import build_report
        from api.analysis.report.storage import store_docx

        deal_name = getattr(req, "property_name", "") or req.property_address.split(",")[0].strip()

        # Generate sub-tool reports
        report_specs = [
            ("sponsor_analysis", sponsor_result),
            ("market_research", market_result),
            ("comp_analysis", comps_result),
        ]
        for tool, data in report_specs:
            if data:
                try:
                    docx_bytes = build_report(tool, data, deal_name=deal_name)
                    if docx_bytes:
                        doc_id = store_docx(docx_bytes, "qr", tool)
                        documents.append({
                            "document_id": doc_id,
                            "document_url": f"/v1/deals/qr/documents/{doc_id}",
                            "document_name": f"{deal_name}_{tool}.docx",
                            "format": "docx",
                            "tool": tool,
                        })
                        LOG.info("Quick Review: generated %s DOCX (doc_id=%s)", tool, doc_id)
                except Exception as e:
                    LOG.warning("Quick Review: %s DOCX generation failed: %s", tool, e)

        # Generate Quick Review memo DOCX
        try:
            qr_bytes = build_report("quick_review", parsed, deal_name=deal_name)
            if qr_bytes:
                qr_doc_id = store_docx(qr_bytes, "qr", "quick_review")
                documents.append({
                    "document_id": qr_doc_id,
                    "document_url": f"/v1/deals/qr/documents/{qr_doc_id}",
                    "document_name": f"{deal_name}_quick_review.docx",
                    "format": "docx",
                    "tool": "quick_review",
                })
                LOG.info("Quick Review: generated QR memo DOCX (doc_id=%s)", qr_doc_id)
        except Exception as e:
            LOG.warning("Quick Review: QR memo DOCX generation failed: %s", e)

    except ImportError:
        LOG.warning("Quick Review: DOCX generation not available (python-docx not installed)")

    if documents:
        parsed["documents"] = documents

    # Include sub-results so the user gets the full depth
    parsed["sub_analyses"] = {
        "sponsor_analysis": sponsor_result,
        "market_research": market_result,
        "comp_analysis": comps_result,
    }

    return parsed
