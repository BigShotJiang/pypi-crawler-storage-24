"""
pinchfin API — Structured Skill Loader
========================================
Parses SKILL.md files into structured sections at load time.
Extracts methodology, output schema, constraints, quality gates.
Skips YAML frontmatter, phase context, cross-references.

Caches parsed skills in memory for fast repeated access.

(c) Veleta Capital LLC. All rights reserved.
"""

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

LOG = logging.getLogger("pinchfin.analysis.skill_loader")

_SKILLS_DIR = Path(__file__).parent / "config" / "skills"

# Max chars for full skill injection into prompts
MAX_SKILL_CHARS = 20_000

# Max chars for constraint-only blocks (secondary skills)
MAX_CONSTRAINT_CHARS = 2_000


@dataclass
class ParsedSkill:
    """Structured representation of a SKILL.md file."""

    name: str
    raw_text: str
    methodology: str = ""
    output_schema: str = ""
    constraints: str = ""
    quality_gates: str = ""
    worked_example: str = ""
    error_handling: str = ""
    source_hierarchy: str = ""

    @property
    def full_prompt(self) -> str:
        """Full skill content for primary skill injection (truncated to MAX_SKILL_CHARS)."""
        parts = []
        if self.methodology:
            parts.append("=== METHODOLOGY ===\n" + self.methodology)
        if self.output_schema:
            parts.append("=== OUTPUT SCHEMA ===\n" + self.output_schema)
        if self.constraints:
            parts.append("=== CONSTRAINTS & RULES ===\n" + self.constraints)
        if self.quality_gates:
            parts.append("=== QUALITY GATES ===\n" + self.quality_gates)
        if self.worked_example:
            parts.append("=== WORKED EXAMPLE ===\n" + self.worked_example)
        if self.error_handling:
            parts.append("=== ERROR HANDLING ===\n" + self.error_handling)
        if self.source_hierarchy:
            parts.append("=== SOURCE HIERARCHY ===\n" + self.source_hierarchy)

        text = "\n\n".join(parts)
        if len(text) > MAX_SKILL_CHARS:
            text = text[:MAX_SKILL_CHARS] + "\n[... truncated at 20K chars]"
        return text

    @property
    def constraint_block(self) -> str:
        """Compact constraint-only block for secondary skill injection (~15-30 lines)."""
        parts = []
        if self.constraints:
            parts.append(self.constraints)
        if self.quality_gates:
            parts.append(self.quality_gates)
        text = "\n\n".join(parts)
        if len(text) > MAX_CONSTRAINT_CHARS:
            text = text[:MAX_CONSTRAINT_CHARS] + "\n[... truncated]"
        return text


# In-memory cache
_cache: dict[str, Optional[ParsedSkill]] = {}


def _strip_frontmatter(text: str) -> str:
    """Remove YAML frontmatter delimited by --- lines."""
    if text.startswith("---"):
        end = text.find("---", 3)
        if end != -1:
            text = text[end + 3:].lstrip("\n")
    return text


def _extract_section(text: str, headers: list[str]) -> str:
    """
    Extract content under any of the given header patterns.
    Returns all matching content concatenated.
    """
    results = []
    lines = text.split("\n")
    capturing = False
    current_level = 0

    for line in lines:
        # Check if this is a markdown header
        header_match = re.match(r"^(#{1,4})\s+(.+)", line)
        if header_match:
            level = len(header_match.group(1))
            title = header_match.group(2).strip().lower()

            # Check if this header matches our target
            matched = any(h.lower() in title for h in headers)

            if matched:
                capturing = True
                current_level = level
                continue
            elif capturing and level <= current_level:
                # Hit a same-level or higher-level header — stop capturing
                capturing = False
                continue

        if capturing:
            results.append(line)

    return "\n".join(results).strip()


def parse_skill(name: str) -> Optional[ParsedSkill]:
    """
    Load and parse a SKILL.md file into structured sections.

    Args:
        name: Skill directory name (e.g. "sponsor-analysis")

    Returns:
        ParsedSkill with extracted sections, or None if not found.
    """
    if name in _cache:
        return _cache[name]

    skill_path = _SKILLS_DIR / name / "SKILL.md"
    if not skill_path.exists():
        LOG.warning("Skill file not found: %s", skill_path)
        _cache[name] = None
        return None

    raw = skill_path.read_text(encoding="utf-8")
    clean = _strip_frontmatter(raw)

    skill = ParsedSkill(
        name=name,
        raw_text=raw,
        methodology=_extract_section(clean, [
            "methodology", "process", "step", "phase", "how",
            "analysis", "approach", "procedure",
        ]),
        output_schema=_extract_section(clean, [
            "output", "deliverable", "json", "schema", "format",
            "docx", "document",
        ]),
        constraints=_extract_section(clean, [
            "constraint", "rule", "critical", "mandatory", "must",
            "never", "always", "requirement", "threshold",
            "validation", "enforcement",
        ]),
        quality_gates=_extract_section(clean, [
            "quality gate", "gate", "validation rule", "checklist",
            "verification", "blocking",
        ]),
        worked_example=_extract_section(clean, [
            "worked example", "example", "walkthrough", "sample",
            "illustration", "demonstration",
        ]),
        error_handling=_extract_section(clean, [
            "error", "edge case", "failure", "fallback", "exception",
            "handling", "when data",
        ]),
        source_hierarchy=_extract_section(clean, [
            "source", "data source", "tier 1", "hierarchy",
            "citation", "reference",
        ]),
    )

    # If methodology extraction is too sparse, use the full clean text
    # (some skills have non-standard headers)
    if len(skill.methodology) < 100 and len(clean) > 200:
        skill.methodology = clean

    _cache[name] = skill
    LOG.info(
        "Parsed skill '%s': methodology=%d, schema=%d, constraints=%d, gates=%d chars",
        name,
        len(skill.methodology),
        len(skill.output_schema),
        len(skill.constraints),
        len(skill.quality_gates),
    )

    return skill


def load_skill_full(name: str) -> str:
    """
    Load a skill and return the full structured prompt text.

    This is the replacement for the old load_skill() that just returned
    raw text truncated at 8K. Now returns structured, parsed content
    up to 20K chars.
    """
    skill = parse_skill(name)
    if skill is None:
        return ""
    return skill.full_prompt


def load_skill_constraints(name: str) -> str:
    """
    Load only the constraint/rules block from a skill.

    Used for secondary skills in multi-skill composition.
    Returns ~15-30 lines of key rules/ratios.
    """
    skill = parse_skill(name)
    if skill is None:
        return ""
    return skill.constraint_block


def clear_cache():
    """Clear the skill cache (useful for tests)."""
    _cache.clear()
