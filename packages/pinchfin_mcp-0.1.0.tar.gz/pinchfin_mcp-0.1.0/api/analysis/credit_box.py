"""
pinchfin API — Deterministic Constraint Waterfall
====================================================
Pure math. No API calls. Shared by deal_screen, debt_sizing_preview,
loan_sizer, and loan_pricing.

Loads thresholds from bundled credit_box_config.json at import time.

(c) Veleta Capital LLC. All rights reserved.
"""

import json
import logging
from pathlib import Path
from typing import Optional

LOG = logging.getLogger("pinchfin.analysis.credit_box")

# ---------------------------------------------------------------------------
# Load config at import time
# ---------------------------------------------------------------------------

_CONFIG_PATH = Path(__file__).parent / "config" / "credit_box_config.json"

with open(_CONFIG_PATH) as _f:
    _CONFIG = json.load(_f)

_CONSTRAINTS = _CONFIG["sizing_constraints"]

# Extract thresholds
MAX_AS_IS_LTV = _CONSTRAINTS["max_as_is_ltv"]["default"]          # 0.75
MAX_STABILIZED_LTV = _CONSTRAINTS["max_stabilized_ltv"]["default"]  # 0.75
MAX_LTC = _CONSTRAINTS["max_ltc"]["default"]                        # 0.80
MIN_DEBT_YIELD = _CONSTRAINTS["min_stabilized_debt_yield"]["default"]  # 0.07
MIN_DSCR = _CONSTRAINTS["min_exit_dscr"]["default"]                 # 1.05
MAX_LOAN_AMOUNT = _CONSTRAINTS["max_loan_amount"]["default"]        # 100_000_000


def run_constraint_waterfall(
    loan_amount: float,
    as_is_value: float,
    stabilized_value: float,
    total_cost: float,
    noi: float,
    rate: float,
    unit_count: int = 1,
) -> dict:
    """
    Run the 6-constraint credit box waterfall.

    All inputs are dollar amounts except rate (decimal, e.g. 0.075 for 7.50%)
    and unit_count.

    Returns dict matching the shape of _mock_deal_screen constraints block,
    plus summary fields.
    """
    # Annual debt service (interest-only)
    annual_ds = loan_amount * rate if rate > 0 else 1.0

    # Actual metrics at requested loan amount
    ltv_as_is = loan_amount / as_is_value * 100 if as_is_value > 0 else 999.0
    ltv_stabilized = loan_amount / stabilized_value * 100 if stabilized_value > 0 else 999.0
    dscr_stabilized = noi / annual_ds if annual_ds > 0 else 0.0
    dy_stabilized = noi / loan_amount * 100 if loan_amount > 0 else 0.0
    ltc = loan_amount / total_cost * 100 if total_cost > 0 else 999.0

    # Max loan per each constraint
    max_ltv_as_is = as_is_value * MAX_AS_IS_LTV
    max_ltv_stab = stabilized_value * MAX_STABILIZED_LTV
    max_dscr = noi / MIN_DSCR / rate if rate > 0 else MAX_LOAN_AMOUNT
    max_dy = noi / MIN_DEBT_YIELD
    max_ltc_loan = total_cost * MAX_LTC
    max_program = MAX_LOAN_AMOUNT

    constraints = {
        "ltv_as_is": {
            "value": round(ltv_as_is, 1),
            "threshold": MAX_AS_IS_LTV * 100,
            "max_loan": round(max_ltv_as_is, 0),
            "status": "pass" if ltv_as_is <= MAX_AS_IS_LTV * 100 else "fail",
        },
        "ltv_stabilized": {
            "value": round(ltv_stabilized, 1),
            "threshold": MAX_STABILIZED_LTV * 100,
            "max_loan": round(max_ltv_stab, 0),
            "status": "pass" if ltv_stabilized <= MAX_STABILIZED_LTV * 100 else "fail",
        },
        "dscr_stabilized": {
            "value": round(dscr_stabilized, 2),
            "threshold": MIN_DSCR,
            "max_loan": round(max_dscr, 0),
            "status": "pass" if dscr_stabilized >= MIN_DSCR else "fail",
        },
        "debt_yield": {
            "value": round(dy_stabilized, 1),
            "threshold": MIN_DEBT_YIELD * 100,
            "max_loan": round(max_dy, 0),
            "status": "pass" if dy_stabilized >= MIN_DEBT_YIELD * 100 else "fail",
        },
        "ltc": {
            "value": round(ltc, 1),
            "threshold": MAX_LTC * 100,
            "max_loan": round(max_ltc_loan, 0),
            "status": "pass" if ltc <= MAX_LTC * 100 else "fail",
        },
        "max_loan": {
            "value": loan_amount,
            "threshold": max_program,
            "max_loan": max_program,
            "status": "pass" if loan_amount <= max_program else "fail",
        },
    }

    # Binding = lowest max_loan
    binding_key = min(constraints, key=lambda k: constraints[k]["max_loan"])
    max_loan = constraints[binding_key]["max_loan"]

    # Add binding flag
    for key in constraints:
        constraints[key]["binding"] = key == binding_key

    all_pass = all(c["status"] == "pass" for c in constraints.values())

    return {
        "constraints": constraints,
        "binding_constraint": binding_key,
        "max_loan": round(max_loan, 0),
        "max_loan_per_unit": round(max_loan / unit_count, 0) if unit_count > 0 else 0,
        "all_pass": all_pass,
        "metrics": {
            "ltv_as_is": round(ltv_as_is, 1),
            "ltv_stabilized": round(ltv_stabilized, 1),
            "dscr_stabilized": round(dscr_stabilized, 2),
            "debt_yield": round(dy_stabilized, 1),
            "ltc": round(ltc, 1),
            "annual_debt_service": round(annual_ds, 0),
            "noi": round(noi, 0),
            "rate": round(rate * 100, 2),
        },
    }
