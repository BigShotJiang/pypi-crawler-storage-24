"""
pinchfin API — Pydantic Output Schemas
========================================
Structured output models for each analysis tool.
These define the JSON schema that Claude must conform to.

(c) Veleta Capital LLC. All rights reserved.
"""

from pydantic import BaseModel, ConfigDict, Field
from typing import Optional


# ═══════════════════════════════════════════════════════════════════════════
# Sponsor Analysis
# ═══════════════════════════════════════════════════════════════════════════

class EntityOverview(BaseModel):
    model_config = ConfigDict(extra="allow")
    name: str = ""
    legal_structure: str = ""
    headquarters: str = ""
    years_in_operation: Optional[int] = None
    principals: list[str] = Field(default_factory=list)
    total_units_owned: Optional[int] = None
    total_portfolio_value: str = ""
    markets_active: list[str] = Field(default_factory=list)

class TrackRecord(BaseModel):
    model_config = ConfigDict(extra="allow")
    total_deals: Optional[int] = None
    total_units: Optional[int] = None
    multifamily_focus_pct: Optional[float] = None
    avg_hold_period_months: Optional[int] = None
    notable_deals: list[dict] = Field(default_factory=list)
    loan_performance: str = ""

class FinancialCapacity(BaseModel):
    model_config = ConfigDict(extra="allow")
    estimated_net_worth: str = ""
    net_worth_to_loan_ratio: str = ""
    liquidity_assessment: str = ""
    leverage_assessment: str = ""
    guaranty_capacity: str = ""

class BackgroundCheck(BaseModel):
    model_config = ConfigDict(extra="allow")
    litigation_findings: list[str] = Field(default_factory=list)
    default_history: str = ""
    bankruptcy_check: str = ""
    regulatory_issues: list[str] = Field(default_factory=list)
    risk_flags: list[str] = Field(default_factory=list)

class OperationalCapability(BaseModel):
    model_config = ConfigDict(extra="allow")
    property_management: str = ""
    renovation_execution: str = ""
    lease_up_capability: str = ""
    asset_management: str = ""

class SponsorOutput(BaseModel):
    model_config = ConfigDict(extra="allow")
    sponsor_tier: str = Field(description="A, A-, B+, B, B-, C, or D")
    entity_overview: EntityOverview = Field(default_factory=EntityOverview)
    track_record: TrackRecord = Field(default_factory=TrackRecord)
    financial_capacity: FinancialCapacity = Field(default_factory=FinancialCapacity)
    background_check: BackgroundCheck = Field(default_factory=BackgroundCheck)
    operational_capability: OperationalCapability = Field(default_factory=OperationalCapability)
    relevant_experience_score: Optional[int] = Field(None, description="0-12 score")
    strengths: list[str] = Field(default_factory=list)
    concerns: list[str] = Field(default_factory=list)
    recommendation: str = Field(description="proceed / caution / decline")
    recommendation_detail: str = ""
    go_no_go: str = Field(default="GO", description="GO or NO-GO")


# ═══════════════════════════════════════════════════════════════════════════
# Market Analysis
# ═══════════════════════════════════════════════════════════════════════════

class MSAProfile(BaseModel):
    model_config = ConfigDict(extra="allow")
    name: str = ""
    population: Optional[int] = None
    population_growth_pct: Optional[float] = None
    median_household_income: Optional[int] = None
    cost_of_living_index: Optional[float] = None
    economic_drivers: list[str] = Field(default_factory=list)

class EmploymentProfile(BaseModel):
    model_config = ConfigDict(extra="allow")
    unemployment_rate: Optional[float] = None
    job_growth_pct: Optional[float] = None
    top_employers: list[str] = Field(default_factory=list)
    industry_diversification: str = ""
    affordability_ratio: Optional[float] = None

class MultifamilyFundamentals(BaseModel):
    model_config = ConfigDict(extra="allow")
    vacancy_rate_pct: Optional[float] = None
    effective_rent_avg: Optional[float] = None
    rent_growth_yoy_pct: Optional[float] = None
    absorption_units: Optional[int] = None
    concession_trends: str = ""

class SupplyPipeline(BaseModel):
    model_config = ConfigDict(extra="allow")
    units_under_construction: Optional[int] = None
    units_planned: Optional[int] = None
    pct_of_inventory: Optional[float] = None
    supply_risk_rating: str = Field(default="", description="low/moderate/elevated/high")
    peak_delivery_year: Optional[int] = None

class SubmarketProfile(BaseModel):
    model_config = ConfigDict(extra="allow")
    name: str = ""
    vacancy_rate_pct: Optional[float] = None
    avg_rent: Optional[float] = None
    rent_growth_pct: Optional[float] = None
    class_mix: str = ""
    competitive_set: list[str] = Field(default_factory=list)

class SupportableAssumptions(BaseModel):
    model_config = ConfigDict(extra="allow")
    rent_growth_pct: Optional[float] = None
    vacancy_rate_pct: Optional[float] = None
    exit_cap_rate_pct: Optional[float] = None
    expense_growth_pct: Optional[float] = None
    justification: str = ""

class MarketOutput(BaseModel):
    model_config = ConfigDict(extra="allow")
    msa: MSAProfile = Field(default_factory=MSAProfile)
    employment: EmploymentProfile = Field(default_factory=EmploymentProfile)
    multifamily_fundamentals: MultifamilyFundamentals = Field(default_factory=MultifamilyFundamentals)
    supply_pipeline: SupplyPipeline = Field(default_factory=SupplyPipeline)
    submarket: SubmarketProfile = Field(default_factory=SubmarketProfile)
    regulatory: dict = Field(default_factory=dict)
    supportable_assumptions: SupportableAssumptions = Field(default_factory=SupportableAssumptions)
    strengths: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    market_rating: str = Field(default="moderate", description="strong/moderate/weak")
    summary: str = ""


# ═══════════════════════════════════════════════════════════════════════════
# Comparable Analysis
# ═══════════════════════════════════════════════════════════════════════════

class RentComp(BaseModel):
    model_config = ConfigDict(extra="allow")
    name: str = ""
    address: str = ""
    units: Optional[int] = None
    year_built: Optional[int] = None
    distance_miles: Optional[float] = None
    avg_rent: Optional[float] = None
    rent_per_sf: Optional[float] = None
    occupancy_pct: Optional[float] = None
    adjustments: dict = Field(default_factory=dict)
    adjusted_rent: Optional[float] = None

class SalesComp(BaseModel):
    model_config = ConfigDict(extra="allow")
    name: str = ""
    address: str = ""
    units: Optional[int] = None
    year_built: Optional[int] = None
    sale_price: Optional[float] = None
    price_per_unit: Optional[float] = None
    cap_rate_pct: Optional[float] = None
    sale_date: str = ""
    adjustments: dict = Field(default_factory=dict)
    adjusted_price_per_unit: Optional[float] = None

class RentAnalysis(BaseModel):
    model_config = ConfigDict(extra="allow")
    avg_market_rent: Optional[float] = None
    avg_adjusted_rent: Optional[float] = None
    subject_in_place_rent: Optional[float] = None
    loss_to_lease_pct: Optional[float] = None
    rent_conclusion_by_type: dict = Field(default_factory=dict)

class ValueAnalysis(BaseModel):
    model_config = ConfigDict(extra="allow")
    avg_cap_rate_pct: Optional[float] = None
    implied_value_range: dict = Field(default_factory=dict)
    as_is_value: Optional[float] = None
    as_stabilized_value: Optional[float] = None
    value_per_unit: Optional[float] = None

class CompsOutput(BaseModel):
    model_config = ConfigDict(extra="allow")
    rent_comps: list[RentComp] = Field(default_factory=list)
    sales_comps: list[SalesComp] = Field(default_factory=list)
    rent_analysis: RentAnalysis = Field(default_factory=RentAnalysis)
    value_analysis: ValueAnalysis = Field(default_factory=ValueAnalysis)
    strengths: list[str] = Field(default_factory=list)
    concerns: list[str] = Field(default_factory=list)
    summary: str = ""


# ═══════════════════════════════════════════════════════════════════════════
# Rent Roll Analysis
# ═══════════════════════════════════════════════════════════════════════════

class UnitMixEntry(BaseModel):
    model_config = ConfigDict(extra="allow")
    type: str = ""
    count: Optional[int] = None
    avg_sf: Optional[float] = None
    avg_rent: Optional[float] = None
    market_rent: Optional[float] = None
    loss_to_lease_pct: Optional[float] = None

class RentRollAnomaly(BaseModel):
    model_config = ConfigDict(extra="allow")
    type: str = ""
    unit: str = ""
    rent: Optional[float] = None
    market: Optional[float] = None
    note: str = ""

class OccupancyAnalysis(BaseModel):
    model_config = ConfigDict(extra="allow")
    physical_occupancy_pct: Optional[float] = None
    economic_occupancy_pct: Optional[float] = None
    vacant_units: Optional[int] = None
    down_units: Optional[int] = None
    model_units: Optional[int] = None

class LeaseExpiration(BaseModel):
    model_config = ConfigDict(extra="allow")
    month: str = ""
    count: Optional[int] = None
    pct_of_total: Optional[float] = None
    concentration_risk: str = ""

class RentRollOutput(BaseModel):
    model_config = ConfigDict(extra="allow")
    summary: dict = Field(default_factory=dict)
    unit_mix: list[UnitMixEntry] = Field(default_factory=list)
    occupancy: OccupancyAnalysis = Field(default_factory=OccupancyAnalysis)
    loss_to_lease: dict = Field(default_factory=dict)
    anomalies: list[RentRollAnomaly] = Field(default_factory=list)
    concessions: dict = Field(default_factory=dict)
    renovation_segmentation: dict = Field(default_factory=dict)
    lease_expiration_waterfall: list[LeaseExpiration] = Field(default_factory=list)
    t12_reconciliation: dict = Field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════════════════
# Cash Flow Modeling
# ═══════════════════════════════════════════════════════════════════════════

class IncomeBreakdown(BaseModel):
    model_config = ConfigDict(extra="allow")
    gpr: Optional[float] = None
    other_income: Optional[float] = None
    vacancy_loss: Optional[float] = None
    vacancy_pct: Optional[float] = None
    concessions: Optional[float] = None
    bad_debt: Optional[float] = None
    effective_gross_income: Optional[float] = None
    egi_per_unit: Optional[float] = None

class ExpenseBreakdown(BaseModel):
    model_config = ConfigDict(extra="allow")
    total_operating_expenses: Optional[float] = None
    opex_per_unit: Optional[float] = None
    opex_ratio_pct: Optional[float] = None
    breakdown: dict = Field(default_factory=dict)

class NOIResult(BaseModel):
    model_config = ConfigDict(extra="allow")
    stabilized_noi: Optional[float] = None
    noi_per_unit: Optional[float] = None
    in_place_noi: Optional[float] = None
    in_place_noi_per_unit: Optional[float] = None

class DualScenario(BaseModel):
    model_config = ConfigDict(extra="allow")
    lender_underwrite: dict = Field(default_factory=dict)
    sponsor_proforma: dict = Field(default_factory=dict)
    variance: dict = Field(default_factory=dict)

class CashFlowProjection(BaseModel):
    model_config = ConfigDict(extra="allow")
    year: int = 0
    gpr: Optional[float] = None
    egi: Optional[float] = None
    total_opex: Optional[float] = None
    noi: Optional[float] = None
    noi_per_unit: Optional[float] = None

class SizingWaterfall(BaseModel):
    model_config = ConfigDict(extra="allow")
    constraints: dict = Field(default_factory=dict)
    binding_constraint: str = ""
    max_loan: Optional[float] = None
    max_loan_per_unit: Optional[float] = None

class CashFlowOutput(BaseModel):
    model_config = ConfigDict(extra="allow")
    income: IncomeBreakdown = Field(default_factory=IncomeBreakdown)
    expenses: ExpenseBreakdown = Field(default_factory=ExpenseBreakdown)
    noi: NOIResult = Field(default_factory=NOIResult)
    dual_scenario: DualScenario = Field(default_factory=DualScenario)
    projections: list[CashFlowProjection] = Field(default_factory=list)
    sizing_waterfall: SizingWaterfall = Field(default_factory=SizingWaterfall)
    sensitivity: dict = Field(default_factory=dict)
    assumptions: dict = Field(default_factory=dict)
    analytical_outputs: dict = Field(default_factory=dict)
    summary: str = ""


# ═══════════════════════════════════════════════════════════════════════════
# Quick Review
# ═══════════════════════════════════════════════════════════════════════════

class PropertySnapshot(BaseModel):
    model_config = ConfigDict(extra="allow")
    address: str = ""
    unit_count: Optional[int] = None
    asset_value: Optional[float] = None
    asset_value_per_unit: Optional[float] = None
    stabilized_value: Optional[float] = None
    year_built: Optional[int] = None
    asset_class: str = ""
    loan_purpose: str = ""

class KeyMetrics(BaseModel):
    model_config = ConfigDict(extra="allow")
    ltv_as_is: dict = Field(default_factory=dict)
    ltv_stabilized: dict = Field(default_factory=dict)
    dscr_stabilized: dict = Field(default_factory=dict)
    debt_yield: dict = Field(default_factory=dict)
    ltc: dict = Field(default_factory=dict)

class SizingResult(BaseModel):
    model_config = ConfigDict(extra="allow")
    max_loan_from_waterfall: Optional[float] = None
    binding_constraint: str = ""
    loan_requested: Optional[float] = None
    request_within_sizing: Optional[bool] = None
    rate_assumption: str = ""

class RiskItem(BaseModel):
    model_config = ConfigDict(extra="allow")
    risk: str = ""
    detail: str = ""
    severity: str = ""
    mitigant: str = ""

class SponsorAssessment(BaseModel):
    model_config = ConfigDict(extra="allow")
    name: str = ""
    tier: str = ""
    recommendation: str = ""
    detail: str = ""

class MarketSnapshot(BaseModel):
    model_config = ConfigDict(extra="allow")
    submarket_vacancy_pct: Optional[float] = None
    rent_growth_yoy_pct: Optional[float] = None
    supply_pipeline_pct: Optional[float] = None
    market_rating: str = ""

class QuickReviewOutput(BaseModel):
    model_config = ConfigDict(extra="allow")
    screen_result: str = Field(description="PASS / CONDITIONAL / FAIL")
    property: PropertySnapshot = Field(default_factory=PropertySnapshot)
    key_metrics: KeyMetrics = Field(default_factory=KeyMetrics)
    sizing: SizingResult = Field(default_factory=SizingResult)
    sponsor_assessment: SponsorAssessment = Field(default_factory=SponsorAssessment)
    market_snapshot: MarketSnapshot = Field(default_factory=MarketSnapshot)
    strengths: list[str] = Field(default_factory=list)
    risks: list[RiskItem] = Field(default_factory=list)
    dd_questions: list[str] = Field(default_factory=list)
    recommendation: str = ""
    recommendation_detail: str = ""


# ═══════════════════════════════════════════════════════════════════════════
# Deal Screen
# ═══════════════════════════════════════════════════════════════════════════

class CreditBoxConstraint(BaseModel):
    """A single constraint in the 6-constraint credit box waterfall."""
    model_config = ConfigDict(extra="allow")
    name: str = Field(description="e.g. LTV As-Is, LTV Stabilized, DSCR Stabilized, DY Stabilized, LTC, Max Loan")
    value: Optional[float] = Field(None, description="Actual metric value (e.g., 72.5 for LTV pct, 1.18 for DSCR)")
    threshold: Optional[float] = Field(None, description="Constraint threshold (e.g., 75.0 for LTV pct, 1.05 for DSCR)")
    status: str = Field(default="", description="PASS or FAIL")
    is_binding: Optional[bool] = Field(None, description="True if this constraint is the most restrictive")

class DealScreenPropertySummary(BaseModel):
    model_config = ConfigDict(extra="allow")
    name: str = ""
    address: str = ""
    unit_count: Optional[int] = None
    year_built: Optional[int] = None
    asset_class: str = ""
    loan_purpose: str = ""

class DealScreenLoanSummary(BaseModel):
    model_config = ConfigDict(extra="allow")
    loan_amount_requested: Optional[float] = None
    loan_amount_per_unit: Optional[float] = None
    rate_assumption: str = ""
    term_structure: str = ""

class DealScreenOutput(BaseModel):
    """Credit box pass/fail screening with 6-constraint waterfall."""
    model_config = ConfigDict(extra="allow")
    screen_result: str = Field(default="", description="PASS / CONDITIONAL / FAIL")
    constraints: list[CreditBoxConstraint] = Field(default_factory=list, description="6 credit box constraints")
    binding_constraint: str = Field(default="", description="Name of the most restrictive constraint")
    property_summary: DealScreenPropertySummary = Field(default_factory=DealScreenPropertySummary)
    loan_summary: DealScreenLoanSummary = Field(default_factory=DealScreenLoanSummary)
    flags: list[str] = Field(default_factory=list, description="Risk or data-quality flags")
    narrative: str = Field(default="", description="1-2 paragraph screening summary")


# ═══════════════════════════════════════════════════════════════════════════
# Debt Sizing Preview
# ═══════════════════════════════════════════════════════════════════════════

class DebtSizingConstraintResult(BaseModel):
    """Max loan from a single constraint."""
    model_config = ConfigDict(extra="allow")
    constraint_name: str = ""
    max_loan: Optional[float] = None
    is_binding: Optional[bool] = None

class DebtSizingPreviewOutput(BaseModel):
    """Lightweight max-loan-by-constraint preview before full sizing."""
    model_config = ConfigDict(extra="allow")
    constraints: list[DebtSizingConstraintResult] = Field(default_factory=list)
    binding_constraint: str = Field(default="", description="Name of the most restrictive constraint")
    max_loan: Optional[float] = Field(None, description="Max loan from binding constraint")
    rate_assumption_pct: Optional[float] = Field(None, description="All-in rate used for sizing (e.g. 7.30)")
    narrative: str = ""


# ═══════════════════════════════════════════════════════════════════════════
# Loan Sizer (Full Waterfall)
# ═══════════════════════════════════════════════════════════════════════════

class LoanSizerConstraint(BaseModel):
    """Full detail for one constraint in the 6-constraint waterfall."""
    model_config = ConfigDict(extra="allow")
    name: str = Field(default="", description="e.g. LTC, LTV As-Is, LTV Stabilized, DSCR Stabilized, DY Stabilized, Max Loan")
    max_loan: Optional[float] = Field(None, description="Maximum loan amount under this constraint")
    value: Optional[float] = Field(None, description="Resulting metric at max loan (e.g., 75.0 for LTV pct)")
    threshold: Optional[float] = Field(None, description="Constraint threshold (e.g., 75.0)")
    status: str = Field(default="", description="PASS or FAIL")
    is_binding: Optional[bool] = None

class MetricsAtRecommended(BaseModel):
    """Credit metrics computed at the recommended loan amount."""
    model_config = ConfigDict(extra="allow")
    ltv_as_is_pct: Optional[float] = None
    ltv_stabilized_pct: Optional[float] = None
    ltc_pct: Optional[float] = None
    dscr_stabilized: Optional[float] = None
    debt_yield_stabilized_pct: Optional[float] = None
    dscr_y1: Optional[float] = Field(None, description="Analytical output only — not a sizing constraint")
    debt_yield_y1_pct: Optional[float] = Field(None, description="Analytical output only — not a sizing constraint")

class ComparisonToRequest(BaseModel):
    """Broker/sponsor request vs. constrained loan."""
    model_config = ConfigDict(extra="allow")
    broker_request: Optional[float] = None
    constrained_loan: Optional[float] = None
    variance: Optional[float] = None
    variance_pct: Optional[float] = None
    status: str = Field(default="", description="WITHIN CONSTRAINTS / EXCEPTION / STRETCH / DECLINE")

class RateStressScenario(BaseModel):
    model_config = ConfigDict(extra="allow")
    rate_pct: Optional[float] = None
    max_loan_dscr: Optional[float] = None
    max_loan_dy: Optional[float] = None
    binding_constraint: str = ""
    max_loan: Optional[float] = None

class NOIStressScenario(BaseModel):
    model_config = ConfigDict(extra="allow")
    noi_haircut_pct: Optional[float] = Field(None, description="e.g. 5.0 means 5% reduction")
    stressed_noi: Optional[float] = None
    max_loan_dscr: Optional[float] = None
    max_loan_dy: Optional[float] = None
    binding_constraint: str = ""
    max_loan: Optional[float] = None

class LoanSizerSensitivity(BaseModel):
    model_config = ConfigDict(extra="allow")
    rate_stress: list[RateStressScenario] = Field(default_factory=list)
    noi_stress: list[NOIStressScenario] = Field(default_factory=list)

class LoanSizerOutput(BaseModel):
    """Full 6-constraint waterfall loan sizing output."""
    model_config = ConfigDict(extra="allow")
    constraints: list[LoanSizerConstraint] = Field(default_factory=list, description="6-constraint waterfall results")
    binding_constraint: str = Field(default="", description="Name of the most restrictive constraint")
    max_loan: Optional[float] = Field(None, description="Max loan from binding constraint")
    recommended_loan: Optional[float] = Field(None, description="Final recommended loan (may be rounded down or capped at broker request)")
    metrics_at_recommended: MetricsAtRecommended = Field(default_factory=MetricsAtRecommended)
    comparison_to_request: ComparisonToRequest = Field(default_factory=ComparisonToRequest)
    rate_assumption_pct: Optional[float] = Field(None, description="All-in rate (e.g. 7.30)")
    rate_index: str = Field(default="", description="e.g. SOFR")
    rate_spread_bps: Optional[int] = Field(None, description="Spread in basis points (e.g. 300)")
    term_structure: str = Field(default="", description="e.g. 3+1+1")
    io_period_months: Optional[int] = None
    sensitivity: LoanSizerSensitivity = Field(default_factory=LoanSizerSensitivity)
    negative_carry_analysis: dict = Field(default_factory=dict, description="Monthly shortfall, months to breakeven, IR reserve")
    refinance_exit_test: dict = Field(default_factory=dict, description="Exit cap, perm rate, supportable perm, refi gap")
    narrative: str = ""


# ═══════════════════════════════════════════════════════════════════════════
# Loan Pricing
# ═══════════════════════════════════════════════════════════════════════════

class PricingDetail(BaseModel):
    model_config = ConfigDict(extra="allow")
    index: str = Field(default="", description="e.g. SOFR")
    index_rate_pct: Optional[float] = Field(None, description="Current index rate (e.g. 4.30)")
    spread_bps: Optional[int] = Field(None, description="Spread over index in basis points")
    all_in_rate_pct: Optional[float] = Field(None, description="Index + spread (e.g. 7.30)")
    annual_debt_service: Optional[float] = None
    monthly_debt_service: Optional[float] = None

class RateCapDetail(BaseModel):
    model_config = ConfigDict(extra="allow")
    required: Optional[bool] = None
    strike_rate_pct: Optional[float] = Field(None, description="Cap strike rate (e.g. 5.50)")
    estimated_cost: Optional[float] = None
    term_months: Optional[int] = None
    notional: Optional[float] = None

class LoanPricingOutput(BaseModel):
    """Loan pricing, rate cap, and interest reserve output."""
    model_config = ConfigDict(extra="allow")
    pricing: PricingDetail = Field(default_factory=PricingDetail)
    rate_cap: RateCapDetail = Field(default_factory=RateCapDetail)
    interest_reserve: Optional[float] = Field(None, description="Interest reserve holdback amount")
    interest_reserve_months: Optional[int] = Field(None, description="Coverage period in months")
    dscr_at_pricing: Optional[float] = Field(None, description="Stabilized DSCR at all-in rate")
    origination_fee_pct: Optional[float] = None
    origination_fee_amount: Optional[float] = None
    exit_fee_pct: Optional[float] = None
    exit_fee_amount: Optional[float] = None
    narrative: str = ""


# ═══════════════════════════════════════════════════════════════════════════
# Nuance Gate
# ═══════════════════════════════════════════════════════════════════════════

class NuanceFlag(BaseModel):
    """A single nuance flag detection result."""
    model_config = ConfigDict(extra="allow")
    flag_type: str = Field(default="", description="e.g. LIHTC, Section 8, Rent Control, Ground Lease, Tax Abatement")
    detected: Optional[bool] = None
    details: str = ""
    severity: str = Field(default="", description="gate-keeping / contained / none")

class RegulatoryResearch(BaseModel):
    model_config = ConfigDict(extra="allow")
    jurisdiction: str = ""
    program: str = ""
    key_rules: list[str] = Field(default_factory=list)
    expiration: str = Field(default="", description="Expiration date or 'N/A'")
    compliance_status: str = Field(default="", description="compliant / at-risk / violation")
    years_remaining: Optional[int] = None

class NuanceFinancialImpact(BaseModel):
    model_config = ConfigDict(extra="allow")
    revenue_impact: Optional[float] = Field(None, description="Annual revenue impact (negative = loss)")
    expense_impact: Optional[float] = Field(None, description="Annual expense impact (negative = cost)")
    value_impact: Optional[float] = Field(None, description="Reduction in property value")
    annual_total_dollars: Optional[float] = Field(None, description="Total annual NOI impact")
    cap_rate_adjustment_bps: Optional[int] = Field(None, description="Cap rate premium in bps for regulatory complexity")

class GoNoGoCriterion(BaseModel):
    model_config = ConfigDict(extra="allow")
    criterion: str = ""
    status: str = Field(default="", description="Pass / Fail / Conditional")
    notes: str = ""

class GoNoGoDetermination(BaseModel):
    model_config = ConfigDict(extra="allow")
    determination: str = Field(default="", description="PROCEED / CONDITIONAL / NO-GO")
    criteria: list[GoNoGoCriterion] = Field(default_factory=list)
    conditions: list[str] = Field(default_factory=list, description="Required conditions if CONDITIONAL")

class NuanceGateOutput(BaseModel):
    """Gate-keeping nuance analysis with go/no-go determination."""
    model_config = ConfigDict(extra="allow")
    nuance_flags: list[NuanceFlag] = Field(default_factory=list)
    regulatory_research: list[RegulatoryResearch] = Field(default_factory=list)
    financial_impact: NuanceFinancialImpact = Field(default_factory=NuanceFinancialImpact)
    go_no_go: GoNoGoDetermination = Field(default_factory=GoNoGoDetermination)
    narrative: str = ""


# ═══════════════════════════════════════════════════════════════════════════
# IC Memo
# ═══════════════════════════════════════════════════════════════════════════

class MemoSection(BaseModel):
    """A section within the IC memo."""
    model_config = ConfigDict(extra="allow")
    title: str = ""
    content: str = ""

class ICMemoRecommendation(BaseModel):
    model_config = ConfigDict(extra="allow")
    decision: str = Field(default="", description="APPROVE / APPROVE WITH CONDITIONS / DECLINE")
    loan_amount: Optional[float] = None
    conditions: list[str] = Field(default_factory=list)
    rationale: str = ""

class SourcesAndUses(BaseModel):
    model_config = ConfigDict(extra="allow")
    sources: list[dict] = Field(default_factory=list, description="List of {name, amount, pct}")
    uses: list[dict] = Field(default_factory=list, description="List of {name, amount, pct}")
    total_sources: Optional[float] = None
    total_uses: Optional[float] = None

class ICMemoOutput(BaseModel):
    """Investment Committee Memorandum — capstone document (Document 8 of 8)."""
    model_config = ConfigDict(extra="allow")
    executive_summary: str = ""
    sections: list[MemoSection] = Field(default_factory=list)
    recommendation: ICMemoRecommendation = Field(default_factory=ICMemoRecommendation)
    key_metrics: dict = Field(default_factory=dict, description="Deal tape strip metrics")
    key_strengths: list[str] = Field(default_factory=list)
    key_risks: list[str] = Field(default_factory=list)
    sources_and_uses: SourcesAndUses = Field(default_factory=SourcesAndUses)
    risk_rating: str = Field(default="", description="Composite risk rating (A/B/C/D)")
    risk_score: Optional[float] = Field(None, description="Composite risk score (e.g. 2.55)")


# ═══════════════════════════════════════════════════════════════════════════
# Term Sheet Comparator
# ═══════════════════════════════════════════════════════════════════════════

class ComparisonDimension(BaseModel):
    """A single row in the side-by-side term sheet comparison matrix."""
    model_config = ConfigDict(extra="allow")
    dimension: str = Field(default="", description="e.g. Loan Amount, Rate, Term, IO Period, Prepayment")
    values: dict = Field(default_factory=dict, description="Lender name -> value for each term sheet")

class TermSheetRecommendation(BaseModel):
    model_config = ConfigDict(extra="allow")
    preferred_lender: str = ""
    rationale: str = ""

class TermSheetComparatorOutput(BaseModel):
    """Side-by-side term sheet comparison and recommendation."""
    model_config = ConfigDict(extra="allow")
    term_sheets_analyzed: Optional[int] = Field(None, description="Number of term sheets compared")
    side_by_side_matrix: list[ComparisonDimension] = Field(default_factory=list)
    pricing_analysis: str = Field(default="", description="Rate, spread, fee comparison narrative")
    structure_analysis: str = Field(default="", description="Term, IO, amort, prepayment comparison narrative")
    covenant_analysis: str = Field(default="", description="DSCR test, cash management, reserves comparison")
    recommendation: TermSheetRecommendation = Field(default_factory=TermSheetRecommendation)
    narrative: str = ""


# ═══════════════════════════════════════════════════════════════════════════
# Business Plan
# ═══════════════════════════════════════════════════════════════════════════

class RenovationAnalysis(BaseModel):
    model_config = ConfigDict(extra="allow")
    total_budget: Optional[float] = None
    budget_per_unit: Optional[float] = None
    scope_description: str = ""
    benchmark_per_unit: Optional[float] = Field(None, description="RSMeans or comparable benchmark $/unit")
    benchmark_source: str = ""
    assessment: str = Field(default="", description="e.g. within benchmark / above / below / deficient")
    contingency_pct: Optional[float] = None
    gc_contract_type: str = Field(default="", description="GMP / Stipulated Sum / Cost-Plus")

class RentLiftAnalysis(BaseModel):
    model_config = ConfigDict(extra="allow")
    current_avg_rent: Optional[float] = None
    target_avg_rent: Optional[float] = None
    rent_lift: Optional[float] = Field(None, description="Dollar lift per unit per month")
    rent_lift_pct: Optional[float] = Field(None, description="Percentage lift (e.g. 15.0)")
    market_support: str = Field(default="", description="Supported / Aggressive / Unsupported")
    comp_basis: str = Field(default="", description="Brief description of comp support for target rents")

class TimelineAssessment(BaseModel):
    model_config = ConfigDict(extra="allow")
    renovation_months: Optional[int] = None
    leaseup_months: Optional[int] = None
    total_months: Optional[int] = None
    risk_level: str = Field(default="", description="low / moderate / high")
    schedule_float_days: Optional[int] = None

class BusinessPlanOutput(BaseModel):
    """Business plan feasibility assessment for value-add / transitional deals."""
    model_config = ConfigDict(extra="allow")
    feasibility_rating: str = Field(default="", description="strong / moderate / weak / not feasible")
    renovation_analysis: RenovationAnalysis = Field(default_factory=RenovationAnalysis)
    rent_analysis: RentLiftAnalysis = Field(default_factory=RentLiftAnalysis)
    timeline_assessment: TimelineAssessment = Field(default_factory=TimelineAssessment)
    key_risks: list[str] = Field(default_factory=list)
    key_mitigants: list[str] = Field(default_factory=list)
    recommendation: str = Field(default="", description="PROCEED / CONDITIONAL / NO-GO")
    conditions: list[str] = Field(default_factory=list)
    narrative: str = ""


# ═══════════════════════════════════════════════════════════════════════════
# Renovation ROI
# ═══════════════════════════════════════════════════════════════════════════

class ROIMetrics(BaseModel):
    model_config = ConfigDict(extra="allow")
    current_avg_rent: Optional[float] = None
    target_avg_rent: Optional[float] = None
    rent_lift: Optional[float] = Field(None, description="Dollar lift per unit per month")
    rent_lift_pct: Optional[float] = Field(None, description="Percentage lift (e.g. 18.5)")
    annual_income_increase: Optional[float] = Field(None, description="Total annual income gain from renovations")
    total_budget: Optional[float] = None
    budget_per_unit: Optional[float] = None
    payback_months: Optional[int] = Field(None, description="Simple payback period in months")
    roi_at_various_caps: dict = Field(
        default_factory=dict,
        description="Cap rate -> value creation (e.g. {'5.00': 1200000, '5.25': 1100000})"
    )
    value_creation: Optional[float] = Field(None, description="Value creation at base cap rate")

class CapRateROIScenario(BaseModel):
    model_config = ConfigDict(extra="allow")
    cap_rate_pct: Optional[float] = None
    incremental_value: Optional[float] = None
    roi_pct: Optional[float] = Field(None, description="ROI = incremental value / budget")

class RenovationROIOutput(BaseModel):
    """Renovation return-on-investment analysis."""
    model_config = ConfigDict(extra="allow")
    roi_metrics: ROIMetrics = Field(default_factory=ROIMetrics)
    sensitivity: list[CapRateROIScenario] = Field(default_factory=list, description="Cap rate sensitivity on value creation")
    risk_factors: list[str] = Field(default_factory=list)
    recommendation: str = Field(default="", description="e.g. Strong ROI / Marginal / Not Justified")
    narrative: str = ""


# ═══════════════════════════════════════════════════════════════════════════
# Preferred Equity Quick Review
# ═══════════════════════════════════════════════════════════════════════════


class PrefConstraintResult(BaseModel):
    model_config = ConfigDict(extra="allow")
    label: str = ""
    value: Optional[float] = None
    threshold: Optional[float] = None
    max_pref: Optional[float] = None
    status: str = ""
    binding: Optional[bool] = None
    note: Optional[str] = None


class PIKScheduleEntry(BaseModel):
    model_config = ConfigDict(extra="allow")
    quarter: int = 0
    phase: str = ""
    balance_start: Optional[float] = None
    return_due: Optional[float] = None
    current_paid: Optional[float] = None
    pik_accrual: Optional[float] = None
    cumul_pik: Optional[float] = None
    balance_end: Optional[float] = None


class ExitScenario(BaseModel):
    model_config = ConfigDict(extra="allow")
    scenario: str = ""
    exit_value: Optional[float] = None
    senior_payoff: Optional[float] = None
    pref_redemption: Optional[float] = None
    common_equity: Optional[float] = None
    pref_irr: Optional[float] = None
    pref_moic: Optional[float] = None
    pref_shortfall: Optional[float] = None


class PrefEquityQROutput(BaseModel):
    model_config = ConfigDict(extra="allow")
    screen_result: str = Field(description="CONDITIONAL / FAIL")
    deal_type: str = "preferred_equity"
    sized_pref_equity: Optional[float] = None
    max_pref_equity: Optional[float] = None
    pass_1_senior: dict = Field(default_factory=dict)
    pass_2_pref: dict = Field(default_factory=dict)
    capital_stack: dict = Field(default_factory=dict)
    pik_schedule: dict = Field(default_factory=dict)
    exit_waterfall: dict = Field(default_factory=dict)
    sponsor_impact: dict = Field(default_factory=dict)
    pref_return_sensitivity: list = Field(default_factory=list)
    pref_returns: dict = Field(default_factory=dict)
    yield_metrics: dict = Field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════════════════
# Schema Registry — map tool names to their output models
# ═══════════════════════════════════════════════════════════════════════════

SCHEMA_REGISTRY: dict[str, type[BaseModel]] = {
    # Existing
    "sponsor_analysis": SponsorOutput,
    "market_research": MarketOutput,
    "comp_analysis": CompsOutput,
    "rent_roll_analyzer": RentRollOutput,
    "cash_flow": CashFlowOutput,
    "quick_review": QuickReviewOutput,
    # New
    "deal_screen": DealScreenOutput,
    "debt_sizing_preview": DebtSizingPreviewOutput,
    "loan_sizer": LoanSizerOutput,
    "loan_pricing": LoanPricingOutput,
    "nuance_gate": NuanceGateOutput,
    "ic_memo": ICMemoOutput,
    "term_sheet_comparator": TermSheetComparatorOutput,
    "business_plan": BusinessPlanOutput,
    "renovation_roi": RenovationROIOutput,
    "pref_equity_qr": PrefEquityQROutput,
}


def get_json_schema(tool_name: str) -> Optional[dict]:
    """Get the JSON schema for a tool's output, suitable for Claude prompt injection."""
    model = SCHEMA_REGISTRY.get(tool_name)
    if model is None:
        return None
    return model.model_json_schema()


def validate_output(tool_name: str, data: dict) -> Optional[BaseModel]:
    """
    Validate Claude's JSON output against the expected schema.

    Returns the validated model instance, or None if validation fails.
    """
    model = SCHEMA_REGISTRY.get(tool_name)
    if model is None:
        return None
    try:
        return model.model_validate(data)
    except Exception:
        return None
