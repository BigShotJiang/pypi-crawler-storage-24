# PinchFin Memo Format Specification — LOCKED

**Version:** 1.2 — LOCKED
**Date:** March 19, 2026
**Status:** PRODUCTION — DO NOT MODIFY WITHOUT OPERATOR APPROVAL
**Gold Standard:** PF-QR-WHITE-PINES-2026-001 Quick Analysis (March 2026)
**Generator:** `pinchfin_qr_memo.py` → `PinchfinQRMemo` class
**Design System:** PinchFin v9 (Navy #080D18 / Cherry #9B2335 / RL Blue #B8CCDB / Cloud #F8F7F4)
**Applies To:** ALL memo types — Quick Analysis, Quick Review/Screening, Short-Form, Full UW Memo

---

## 1. Purpose

This specification LOCKS the section structure, ordering, formatting rules, and narrative standards for ALL memos produced by the PinchFin / Valeri system. Every memo — Quick Analysis, Quick Screening, Short-Form, and Full UW — uses this baseline structure. Deal-specific sections may be ADDED via the conditional slot (Section 9) but baseline sections are NEVER removed, reordered, or reformatted.

**The White Pines Quick Analysis (March 2026) is the gold standard.** Every future memo must match its structure, density, narrative quality, and institutional tone.

### v1.2 Changes (March 19, 2026)
1. **Section order updated:** Sponsor Overview and Market Overview moved to Sections 2-3 (immediately after Deal Overview, before Sources & Uses). Reader sees context before numbers.
2. **Generator locked:** `pinchfin_qr_memo.py` → `PinchfinQRMemo` class is the ONLY generator for all memo types. `ValeriReport` is for multi-page standalone reports ONLY (Sponsor, Market, Comps, IC Memo).
3. **Narrative mandate:** Every table MUST have interpretive prose — introductory context and/or closing analysis. Tables without narrative are non-compliant. Use institutional copy and structured credit terminology.
4. **Scope expanded:** This spec now governs ALL memo types, not just Quick Review. Section depth scales by memo type but structure and order are fixed.
5. **Archived:** v1.0 (Mar 12), v1.1 (Mar 18), PINCHFIN_QUICK_ANALYSIS_COMMAND_v9.md — all moved to `_ARCHIVE_RETIRED_DESIGNS/`.

---

## 2. Generator & Import

```python
import sys
sys.path.insert(0, r"C:\Users\BrianMurphy\OneDrive - Veleta Capital, LLC\Valeri\Valeri Design - Elevated")
from pinchfin_qr_memo import PinchfinQRMemo, COL_TEMPLATES
```

**NEVER use for memos:**
- `valeri_report_v3.py` / `ValeriReport` (multi-page reports ONLY — Sponsor, Market, Comps, IC)
- `pinchfin_report.py` (archived — old orange palette)
- `valeri_report_alt.py` (deprecated)
- Node.js `docx` library
- Raw `python-docx` without PinchfinQRMemo wrapper

---

## 3. Title Bar (No Cover Page)

```python
report = PinchfinQRMemo(
    title="Quick Review - First-Look Screening",
    property_line="[Property Name] | [City, State]",
    detail_line="[Units] Units | [Property Description] | [Deal ID: PF-QR-XXXX-YYYY-NNN]",
    recommendation="[CONDITIONAL / APPROVE / DECLINE]",
    loan_amount="$XX.XM",
    date="[Month Year]",
    mode="memo"
)
```

**Rules:**
- `title` is ALWAYS "Quick Review - First-Look Screening"
- `property_line` = Property name + city/state, pipe-separated
- `detail_line` = Unit count + property type descriptor + deal ID
- `recommendation` = one of CONDITIONAL, APPROVE, DECLINE
- `loan_amount` = lender-sized loan in $XX.XM format
- `mode` = "memo" (IB-density, 7-8pt) or "report" (8-9pt, for longer memos)
- **No cover page** — compact Navy title bar sits inline on page 1

---

## 4. LOCKED Section Structure (18 Sections + 1 Conditional)

Every memo contains these sections IN THIS EXACT ORDER. All 18 baseline sections are MANDATORY. Section 9 is the conditional slot for deal-specific analysis.

**LOCKED ORDER (v1.2 — March 19, 2026):**

| # | Section | Method | Narrative Required |
|---|---------|--------|--------------------|
| 1 | Deal Overview | `add_section` + `add_dual_kv` | Opening paragraph (4-6 sentences) |
| 2 | Sponsor Overview | `add_section` + `add_insight` | Sponsor narrative (3-5 sentences) |
| 3 | Market Overview | `add_section` + `add_dual_kv` | Market narrative (1-2 paragraphs) |
| 4 | Sources & Uses | `add_sources_uses` | S&U context paragraph |
| 5 | Credit Metrics | `add_table` + `add_insight` | Methodology paragraph |
| 6 | Lender Rent Underwriting | `add_table` + `add_kv_pairs` | Rent basis paragraph |
| 7 | Rent Comparables | `add_table` | Comp selection intro + positioning narrative |
| 8 | Sales Comparables | `add_table` + `add_kv_pairs` | Transaction context intro + value positioning |
| 9 | [Conditional] | varies | Deal-specific (bridge analysis, lease-up, etc.) |
| 10 | Three-Year Cash Flow | `add_table` | Assumptions intro + performance narrative |
| 11 | Sizing Waterfall | `add_table` | Constraint methodology + closing interpretation |
| 12 | Interest Reserve | `add_kv_pairs` | Adequacy narrative |
| 13 | Sensitivity Analysis | `add_sensitivity_table` × 2 | Framing intro + interpretive close per table |
| 14 | Key Risks & Mitigants | `add_risk_table` | Risk concentration narrative |
| 15 | Lender Returns | `add_table` | Return profile narrative |
| 16 | Diligence Needs | `add_table` | Priority framework narrative |
| 17 | Recommendation | `add_recommendation_box` | 3-bullet structured recommendation |
| 18 | Sources | `add_paragraph(secondary)` | Source attribution |

**KEY CHANGE from v1.1:** Sponsor (was Section 12) and Market (was Section 13) now appear at Sections 2-3. Sources & Uses (was Section 2) moves to Section 4. Reader gets deal context → who → where → then numbers.

### Section 1: DEAL OVERVIEW

**Method:** `report.add_section("Deal Overview")`

**Components (in order):**

1. **Opening Narrative Paragraph** — 4-6 sentences covering:
   - Property name, unit count, construction type, location (MSA)
   - Sponsor name and principals
   - Loan request amount and purpose (acquisition, refinance, takeout)
   - Property status (occupancy, construction completion, lease-up stage)
   - Lender underwriting approach summary (1 sentence)
   - Maximum supportable loan result + binding constraint + equity requirement

2. **Dual KV Layout** — `report.add_dual_kv()` with two panels:

   **Left Panel: "Property Profile"**
   | Field | Format |
   |-------|--------|
   | Property | Name (fka if applicable) |
   | Location | Full address |
   | Type | Stories, construction type, mixed-use if applicable |
   | Residential | Units | total SF | avg SF |
   | Retail/Commercial | SF + bay/suite count (if applicable) |
   | Construction/Condition | % complete, TCO date, or year built/renovated |
   | Occupancy | Current % + detail (pre-leased, vacant, etc.) |
   | Manager | Property management company |

   **Right Panel: "Loan Summary"**
   | Field | Format |
   |-------|--------|
   | Recommended Loan | $X,XXX,XXX ($/unit) |
   | Sponsor Request | $X,XXX,XXX ($/unit) |
   | Variance | ($X.XM) above/below request |
   | Rate | X.XX% (SOFR X.XX% + XXX bps) |
   | Term | X+X+X format |
   | Annual Debt Service | $X,XXX,XXX |
   | Binding Constraint | Name of binding constraint |
   | Source | Direct / Broker name |

---

### Section 2: SOURCES & USES

**Method:** `report.add_section("Sources & Uses")`

**Components:**

1. **S&U Table** — `report.add_sources_uses()` with side-by-side format
   - Sources: Loan + Sponsor Equity + any other sources → Total Sources
   - Uses: Itemized line items → Total Uses
   - **MUST BALANCE exactly**
   - Dollar format: FULL ($XX,XXX,XXX) — not abbreviated
   - Percentage column on each side
   - Totals row bold

2. **S&U Narrative** — 2-3 sentences explaining:
   - How the S&U was constructed (lender-sized, not sponsor request)
   - Any notable items (trapped equity, circular entries corrected, etc.)
   - Sponsor equity context

---

### Section 3: CREDIT METRICS

**Method:** `report.add_section("Credit Metrics")`

**Components:**

1. **Introductory Paragraph** — 2-3 sentences explaining:
   - What NOI basis is used (full vs. sizing, if two-track)
   - Any deal-specific constraint modifications (e.g., elevated exit DY)

2. **Credit Metrics Table** — `report.add_table()`

   | Column | Width | Content |
   |--------|-------|---------|
   | Metric | 1.10" | Metric name |
   | As-Is / Y1 | 0.80" | Going-in metric (analytical only) |
   | Stabilized (Full) | 1.00" | Full NOI basis |
   | Sizing Basis | 1.10" | If two-track; otherwise omit column |
   | Threshold | 0.90" | Credit box threshold |
   | Status | 0.60" | ✓ or ✗ ONLY |

   **Required rows:** DSCR, Debt Yield, LTV (Proforma), LTV (As-Is), LTC, Break-Even Occ

   **Formatting rules:**
   - Status column: ✓ (checkmark) or ✗ (x-mark) ONLY — never "Pass", "Fail", "ok"
   - As-Is LTV status: "Soft ✓" or "Soft ✗" (analytical marker, not binding)
   - DSCR: X.XXx format (two decimals + x)
   - DY: X.X% format
   - LTV/LTC: XX.X% format
   - Break-Even: XX.X% format

---

### Section 4: LENDER RENT UNDERWRITING

**Method:** `report.add_section("Lender Rent Underwriting")`

**Components:**

1. **Narrative Paragraph** — 3-4 sentences covering:
   - Rent basis (rent roll market rents, T-12 in-place, comp-derived)
   - Any haircut applied or not, with justification
   - Pre-lease / actual lease evidence supporting rents
   - Comparable property rent ranges

2. **Unit Mix / Rent Table** — `report.add_table()`

   | Column | Content |
   |--------|---------|
   | Type | Unit type name |
   | Units | Count |
   | SF | Average square feet |
   | Sponsor | Sponsor's rent |
   | Rent Roll / Lender | Lender underwritten rent |
   | vs Sponsor | % variance (+/-) |
   | $/SF | Rent per square foot |
   | **Totals Row** | Weighted averages |

3. **Supporting KV Pairs** — `report.add_kv_pairs()`
   - Lender Monthly GPR
   - Lender Annual GPR
   - Rent Basis (source description)
   - Pre-Leased / Lease Evidence
   - Key Comps (names + rent ranges)
   - Rent Growth + Stabilized Occupancy assumptions

---

### Section 5: RENT COMPARABLES

**Method:** `report.add_section("Rent Comparables")`

**MANDATORY on every deal.** Shows where the subject sits vs. the competitive set on rents, unit size, and occupancy.

**Components:**

1. **Introductory Paragraph** — 2-3 sentences covering:
   - Comp selection criteria (geography, vintage, product type)
   - Number of comps identified and data sources
   - Any limitations (e.g., limited active adult comps, income-restricted properties excluded)

2. **Rent Comp Table** — `report.add_table()`

   | Column | Content |
   |--------|---------|
   | Property | Comp name |
   | Year | Year built |
   | Units | Unit count |
   | Avg Rent | Weighted average rent |
   | Avg SF | Average unit size |
   | $/SF | Rent per square foot |
   | Occ | Occupancy rate |

   **Required rows:** Minimum 5 comp properties + Subject row (bold) + Comp Average row
   **Subject row placement:** First data row (immediately after header) or last row — must be clearly identified
   **Col widths:** `COL_TEMPLATES["sales_comp_7"]` or custom 7-column

3. **Positioning Narrative** — 2-3 sentences explaining:
   - Where the subject falls in the comp range (above/at/below market)
   - Key drivers of any variance (unit size, vintage, amenity level, product type)
   - Implication for rent growth potential or downside risk

**Rules:**
- Exclude income-restricted / LIHTC properties from the primary comp table. If included for context, flag clearly as "Income-Restricted" in the table.
- Show $/SF column — critical for apples-to-apples comparison when unit sizes vary
- Subject row must show both contract/in-place rents AND lender-underwritten rents if different

---

### Section 6: SALES COMPARABLES

**Method:** `report.add_section("Sales Comparables")`

**MANDATORY on every deal.** Shows where the subject's implied value sits vs. recent transactions on a $/unit and $/SF basis.

**Components:**

1. **Introductory Paragraph** — 2-3 sentences covering:
   - Transaction universe (geography, vintage, timeframe)
   - Number of sales comps and data quality assessment
   - Any limitations (e.g., no product-type-specific sales, stale comps flagged)

2. **Sales Comp Table** — `report.add_table()`

   | Column | Content |
   |--------|---------|
   | Property | Comp name |
   | Units | Unit count |
   | Year | Year built |
   | Sale Date | Month-Year |
   | Price | Total sale price |
   | $/Unit | Price per unit |
   | Cap Rate | Implied or reported cap rate |

   **Required rows:** Minimum 3 sale comps + Comp Average row + Subject row
   **Subject row:** Shows lender-underwritten value (Stabilized NOI / exit cap), $/unit, and exit cap rate
   **Col widths:** `COL_TEMPLATES["sales_comp_7"]`

3. **Subject Positioning KV Pairs** — `report.add_kv_pairs()`
   - Subject Implied Value (stabilized)
   - Subject $/Unit vs. Comp Average
   - Subject $/SF vs. Comp Average (if SF data available)
   - Discount/Premium to Comps (% and rationale)
   - Exit Cap Rate Used

4. **Positioning Narrative** — 2-3 sentences explaining:
   - Where the subject's basis/value sits vs. the transaction market
   - Whether the loan basis provides adequate downside protection
   - Any stale, outlier, or non-comparable sales flagged

**Rules:**
- Flag any sale comp older than 18 months as "Stale — pre-current-rate environment"
- Flag any outlier (trophy location, distressed sale) and note why it's not representative
- Always show the subject's loan basis $/unit alongside value $/unit — the spread between them is the equity cushion
- If no product-type-specific sales exist (e.g., active adult), note the gap and explain the adjustment methodology used

---

### Section 7: CONDITIONAL — Deal-Specific Section(s)

*(See Section 12: Conditional Sections)*

Examples: Tiered Concession Plan, Retail Component, Commercial Tenant Detail, Affordable/LIHTC Income Restrictions, Lease-Up Analysis

---

### Section 8: THREE-YEAR CASH FLOW (LENDER UNDERWRITE)

**Method:** `report.add_section("Three-Year Cash Flow (Lender Underwrite)")`

For stabilized deals, this may be a 1-year or As-Is vs. Stabilized format.

**Components:**

1. **Cash Flow Table** — `report.add_table()` with 4 columns:

   | Row | Y1 | Y2 | Y3 |
   |-----|----|----|-----|
   | Average Occupancy | X.X% (XX units) | X.X% (XX units) | X.X% (XX units) |
   | Residential GPR | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | Gross Collected | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | Less Concessions | ($X,XXX,XXX) | ($X,XXX,XXX) | ($X,XXX,XXX) |
   | Less Credit Loss | ($X,XXX,XXX) | ($X,XXX,XXX) | ($X,XXX,XXX) |
   | Net Residential | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | Retail Income | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | Other Income | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | **Effective Gross Income** | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | Total Operating Expenses | ($X,XXX,XXX) | ($X,XXX,XXX) | ($X,XXX,XXX) |
   | **Net Operating Income** | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | *blank row* | | | |
   | Sizing NOI (if two-track) | — | — | $X,XXX,XXX |

   **Formatting:**
   - Use `COL_TEMPLATES["comparison_4"]` for widths
   - NOI row: bold
   - Deductions shown in parentheses: ($X,XXX,XXX)
   - All dollar amounts in full format within the table

---

### Section 9: SIZING WATERFALL

**Method:** `report.add_section("Sizing Waterfall")`

**Components:**

1. **Narrative Paragraph** — 2-3 sentences explaining:
   - Framework used (single-track vs. two-track)
   - Value basis (proforma value at X.XX% cap on full/sizing NOI)
   - Which constraints use which NOI basis
   - As-Is LTV classification (soft/analytical)

2. **Waterfall Table** — `report.add_table()`

   | Constraint | Basis / Calculation | Max Loan | Status |
   |------------|---------------------|----------|--------|
   | LTC (80%) | $XX.XM cost x 80% | $XX.XM | ✓ |
   | LTV As-Is (75%) | $XX.XM value x 75% | $XX.XM | Soft |
   | LTV Proforma (75%) | $XX.XM value x 75% | $XX.XM | ✓ |
   | Exit DSCR (1.05x) | $X,XXX,XXX / 1.05 / X.XX% | $XX.XM | ✓ or BINDING |
   | Exit DY (X.X%) | $X,XXX,XXX / X.X% | $XX.XM | ✓ or BINDING |
   | Program Cap | Program maximum | $100.0M | ✓ |
   | **Lender Maximum** | $/unit | $XX.XM | |

   **Rules:**
   - Show ALL 6 constraints — minimum governs
   - BINDING constraint labeled "BINDING" in status
   - As-Is LTV labeled "Soft" (analytical, not binding)
   - Calculation column shows the actual math

---

### Section 10: INTEREST RESERVE ANALYSIS

**Method:** `report.add_section("Interest Reserve Analysis")`

*For lease-up / transitional deals. For stabilized acquisitions with no IR, this section becomes a brief note.*

**Components:**

1. **Summary KV Pairs** — `report.add_kv_pairs()`
   - Interest Reserve amount
   - Monthly Debt Service
   - Monthly Burn (empty building breakdown)
   - Coverage on Empty Building (months)
   - Self-Sustaining Month
   - Total Projected IR Draws
   - IR Ending Balance

2. **Monthly IR Draw Table** — Selected months showing:
   | Month | Units | Occ % | Net CF | IR Draw | IR Balance |

3. **IR Narrative** — 2-3 sentences on adequacy

---

### Section 11: SENSITIVITY ANALYSIS

**Method:** `report.add_section("Sensitivity Analysis")`

**Components — TWO SEPARATE TABLES (NEVER COMBINED):**

1. **Cap Rate Sensitivity** — `report.add_subsection("Cap Rate Sensitivity")`

   | Cap Rate | Value (Full NOI) | $/Unit | LTV |
   |----------|-----------------|--------|-----|
   | Base ± 75bps in 25bps steps (7 rows) or ± 50bps in 25bps steps (5 rows) |

   - Base row: BOLD
   - Use `report.add_sensitivity_table()` with `base_row_index`
   - Col widths: `COL_TEMPLATES["sens_4"]`

2. **Vacancy Stress** — `report.add_subsection("Vacancy Stress (Sizing Basis)")`

   | Vacancy | Sizing NOI | Exit DSCR | Exit DY |
   |---------|-----------|-----------|---------|
   | 5-6 rows from 5% to 25% |

   - Base row: BOLD
   - DSCR < 1.00x: red
   - Use `report.add_sensitivity_table()` with `base_row_index` and `dscr_column`

---

### Section 12: SPONSOR OVERVIEW

**Method:** `report.add_section("Sponsor Overview")`

**Components:**

1. **Sponsor Narrative** — 3-5 sentences covering:
   - Firm name, location, formation date
   - Principals and their backgrounds
   - Track record (completed projects, unit count, markets)
   - Relevant prior lender relationships

2. **Insight/Warning Box** (if applicable) — `report.add_insight()`
   - Performance benchmarks from prior deals
   - Flags or concerns
   - DD requirements

---

### Section 13: MARKET OVERVIEW

**Method:** `report.add_section("Market Overview")`

**Components:**

1. **Dual KV Layout** — `report.add_dual_kv()` with two panels:

   **Left Panel: "[MSA Name]"**
   - Population
   - Employment + unemployment rate
   - MF Vacancy (overall + Class A/B)
   - Pipeline (units under construction)
   - Absorption trend

   **Right Panel: "[Submarket Name]"**
   - Tract/County Median HH Income (+ affordability calc)
   - HUD FMR by bedroom count
   - Walk Score / Transit / Bike
   - Flood Zone (from FEMA — NEVER assumed)

2. **Market Narrative** — 1-2 substantive paragraphs covering:
   - Supply/demand dynamics
   - Rent growth trajectory
   - Competitive properties and their performance
   - Affordability context
   - Retail market conditions (if mixed-use)

---

### Section 14: KEY RISKS & MITIGANTS

**Method:** `report.add_section("Key Risks & Mitigants")`

**Components:**

1. **Risk Table** — `report.add_risk_table()`

   | # | Risk Factor | Severity | Assessment | Mitigant |
   |---|-------------|----------|------------|----------|
   | 1-8 risks, deal-specific |

   **Rules:**
   - Minimum 5 risks, maximum 8
   - Severity: High / Med-High / Med / Low (NOT "HIGH" or "MEDIUM")
   - Risks must be SPECIFIC to this deal — no generic CRE boilerplate
   - Assessment column: 1-2 sentences on WHY this is a risk for THIS deal
   - Mitigant column: concrete structural or market protections
   - Use `COL_TEMPLATES["nuance_risk_5"]` for widths

---

### Section 15: LENDER RETURNS — UNLEVERED ONLY

**Method:** `report.add_section("Lender Returns")`

**Components:**

1. **Returns Table** — `report.add_table()` with 4 columns:

   | | 12-Month | 24-Month | 36-Month |
   |--|----------|----------|----------|
   | Origination Fee (X.X%) | $XXX,XXX | $XXX,XXX | $XXX,XXX |
   | Interest Income | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | Exit Fee (X.XX%) | $XXX,XXX | $XXX,XXX | $XXX,XXX |
   | **Unlevered IRR** | X.X% | X.X% | X.X% |
   | **Unlevered MOIC** | X.XXx | X.XXx | X.XXx |

   **CRITICAL — REMOVED ITEMS (NEVER INCLUDE):**
   - ~~Warehouse advance line~~ — REMOVED
   - ~~Net Spread Income~~ — REMOVED
   - ~~Levered IRR~~ — REMOVED
   - ~~Levered MOIC~~ — REMOVED
   - ~~Any reference to warehouse (+175) or 75% advance~~ — REMOVED

   These are internal balance sheet metrics. The Quick Review is a forward-facing document — show unlevered economics only.

   **Col widths:** `COL_TEMPLATES["comparison_4"]`

---

### Section 16: DILIGENCE NEEDS LIST

**Method:** `report.add_section("Diligence Needs List")`

**Components:**

1. **Needs Table** — `report.add_table()`

   | # | Document | Priority | Workstream |
   |---|----------|----------|------------|
   | 1-12 items, deal-specific |

   **Rules:**
   - Priority: Critical / High / Med
   - Workstream: Sponsor DD, Valuation, Construction, Expenses, Retail, Legal, Environmental, Existing Debt
   - Items must be SPECIFIC — not "financial statements" but "Sponsor financial statements / net worth / liquidity"
   - Col widths: `COL_TEMPLATES["report_4a"]`

---

### Section 17: RECOMMENDATION

**Method:** `report.add_section("Recommendation")`

**Components:**

1. **Recommendation Box** — `report.add_recommendation_box()`

   ```python
   report.add_recommendation_box(
       "CONDITIONAL",  # or "APPROVE" or "DECLINE"
       [
           "Paragraph 1: Maximum supportable loan, binding constraint, proforma value, "
           "exit metrics summary.",
           "Paragraph 2: Sponsor equity requirement, IR adequacy, lease-up coverage.",
           "Paragraph 3: Conditions to proceed (numbered list within the paragraph).",
       ]
   )
   ```

   **Rules:**
   - 2-3 substantive paragraphs
   - First paragraph: loan amount, metrics, value
   - Second paragraph: equity, reserves, coverage
   - Third paragraph: numbered conditions (if CONDITIONAL)

---

### Section 18: SOURCES

**Method:** `report.add_section("Sources")`

**Components:**

1. **Introductory line** — `report.add_paragraph(..., secondary=True)`:
   "In addition to standard industry data sources, below is a partial sample of additional sources referenced in this analysis."

2. **Source List** — `report.add_paragraph(..., secondary=True)`:
   Organized by category: Data Services, Rent Roll, Concessions, Sponsor, Market, Comps
   - Use publication/source names — NEVER raw Perplexity query strings
   - Include pull dates for API data

---

## 5. Color Palette — PinchFin v9 (LOCKED)

| Role | Color | Hex | Usage |
|------|-------|-----|-------|
| Section headers | Navy | #080D18 | Section header bars, table header text, KV title borders |
| Body text | Charcoal | #1D1D1F | All body text, table data |
| Accent (subsections) | Cherry | #9B2335 | Subsection pipe borders, cover accent line |
| Accent (highlight) | RL Blue | #B8CCDB | Cover rule line |
| Backgrounds | Cloud | #F8F7F4 | Deal tape strip, callout boxes, sensitivity base rows |
| Dividers | Cloud Mid | #EEEDEA | Table bottom borders, thin rules |
| Semantic: Pass | Forest Green | #1B6B3A | Checkmarks, positive signals, NOI rows |
| Semantic: Fail | Crimson | #B22234 | X-marks, DSCR < 1.00x |
| Semantic: Monitor | Dark Amber | #8B6914 | DSCR 1.00-1.19x, warnings |

**NEVER USE:**
- Orange (#B85A30) — old PinchFin v4, archived
- Carbon Slate (#2F363C) — old V3.1
- Aether (#C2DCDB) — old V3.1
- Steel Grey (#E5E5E5) — old V3.1

---

## 6. Typography (LOCKED)

- **ALL text:** Calibri — no exceptions
- Body: 9pt Regular, Charcoal
- Table headers: 8pt Bold, Navy
- Table data: 9pt Regular/Bold, Charcoal
- Section headers: 9pt Bold, White on Navy
- Subsections: 10pt Bold, Navy with Cherry pipe
- Numbers: Bold, right-aligned
- **Wordmark:** `pf` in lowercase Calibri Bold

---

## 7. Numeric Formatting (LOCKED)

Per VALERI_FORMAT_ENFORCER:
- **$1M+:** $XX.XM (one decimal)
- **$100K-$999K:** $XXXK (no decimal)
- **< $100K:** $XX,XXX (full with commas)
- **S&U tables:** Full format ($XX,XXX,XXX)
- **DSCR:** X.XXx (two decimals + x)
- **DY:** X.X% (one decimal + %)
- **LTV/LTC:** XX.X% (one decimal + %)
- **Cap Rate:** X.XX% (ALWAYS two decimals)
- **Interest Rate:** X.XX% (ALWAYS two decimals)
- **$/Unit:** Always shown next to value and loan figures: "$57.7M ($349,697/unit)"
- **Status:** ✓ or ✗ ONLY — NEVER "Pass", "Fail", "ok", "yes", "no"
- **NEVER:** $XX,XXXK format

---

## 8. Structural Rules (LOCKED)

1. **Section order is FIXED** — Sections 1-18 always appear in this order
2. **No sections may be removed** from the baseline (Sections 1-6, 8-18)
3. **Conditional section (7)** is added when the deal requires it
4. **No page breaks between every section** — content flows continuously; use page breaks only for major thematic shifts
5. **Every table has interpretive prose** before or after it
6. **Tables are fixed-width** — use COL_TEMPLATES, never auto-size
7. **No vertical borders in tables** — horizontal dividers only
8. **Cap rate and vacancy are ALWAYS separate tables** — never combined
9. **Sources = Uses** — must balance exactly
10. **Lender returns: UNLEVERED ONLY** — no warehouse, no levered metrics
11. **All dollar figures with $/unit** next to value and loan amounts

---

## 9. Anti-Patterns (NEVER DO)

| Anti-Pattern | Correct Approach |
|-------------|-----------------|
| Combined cap rate + vacancy table | Two separate sensitivity tables |
| Status shows "Pass" or "ok" | ✓ or ✗ only |
| Severity "HIGH" / "MEDIUM" / "LOW" | High / Med-High / Med / Low |
| Two S&U tables | ONE S&U table built from lender-sized loan |
| Sponsor's request shown as a table | Mention variance in narrative |
| Levered returns / warehouse line | Unlevered only — this is forward-facing |
| Old orange (#B85A30) colors | v9 Navy/Cherry/RL Blue/Cloud |
| pinchfin_report.py generator | valeri_report_v3.py → ValeriReport |
| System methodology in output | Analysis REFLECTS methodology, doesn't NARRATE it |
| Generic boilerplate risks | Deal-specific risks with concrete assessments |
| Assumed flood zone | FEMA data from Valeri Data Services |
| Assumed SOFR rate | Current SOFR from FRED via MCP tools |
| 1.10x/1.15x/1.20x/1.25x DSCR thresholds | 1.05x is the ONLY DSCR threshold |

---

## 10. Conditional Section (Section 7)

One conditional section slot exists between Section 6 (Sales Comparables) and Section 8 (Cash Flow) for deal-specific analysis.

### When to Add Conditional Section 7

| Deal Characteristic | Conditional Section |
|--------------------|---------------------|
| Lease-up with tiered concessions | Tiered Concession Plan |
| Mixed-use with retail/commercial | Retail Component |
| Ground lease | Ground Lease Analysis |
| LIHTC / Affordable | Affordable Income Restrictions |
| Tax abatement | Tax Abatement Impact |
| Rent control / stabilization | Rent Regulation Analysis |
| Significant renovation program | Renovation / Value-Add Plan |
| Complex ownership (TIC, JV) | Ownership Structure |
| Active lease-up | Lease-Up Analysis |

### Rules for Conditional Section

1. Conditional section uses the same formatting (section headers, tables, KV pairs, narrative)
2. It slots at Section 9 between Sales Comparables and Three-Year Cash Flow
3. Maximum 2 conditional sections per deal — if more complexity is needed, escalate to full underwriting
4. Each conditional section must have: narrative paragraph + supporting table or KV pairs

---

## 11. Narrative Mandate — LOCKED

**Every table, KV block, and sensitivity grid MUST have interpretive prose.** This is non-negotiable.

**Rule:** No table stands alone. Before and/or after every data element, include institutional narrative that:
- Frames the methodology or data source for the reader
- Interprets the key finding or positioning implication
- Uses structured credit terminology (binding constraint, coverage failure, equity cushion, structural floor, funded-forward, negative leverage, etc.)
- Is analytically accretive — every sentence adds insight, not filler

**Anti-patterns (NEVER do):**
- Table with no prose above or below it
- One-liner intros like "Metrics on $9.0M at 7.15% IO." — this is a label, not narrative
- Generic boilerplate that could apply to any deal
- Restating what the table already shows without adding interpretation

**Depth by memo type:**
| Memo Type | Narrative Depth | Target Length |
|-----------|----------------|---------------|
| Quick Screening / Short-Form | 2-3 sentences per section | 3-5 pages |
| Quick Analysis | 3-5 sentences per section, full interpretive prose | 6-10 pages |
| Full UW Memo | Full paragraphs, dual-scenario narrative, risk correlation | 12-20 pages |

---

## 12. File Naming Convention

```
PF-QR-[DEAL_NAME]-[YEAR]-[NNN]_Quick_Analysis.docx
```

Examples:
- `PF-QR-WHITE-PINES-2026-001_Quick_Analysis.docx`
- `PF-QR-SUNSET-RIDGE-2026-002_Quick_Analysis.docx`
- `PF-QR-OAKWOOD-2026-003_Quick_Analysis.docx`

---

## 13. Verification Checklist

Before delivering any memo:

- [ ] Generator: `pinchfin_qr_memo.py` → `PinchfinQRMemo` (NOT ValeriReport for memos)
- [ ] Colors: Navy #080D18 in section headers (NOT old orange #B85A30 or Carbon Slate #2F363C)
- [ ] Section order: Deal Overview → Sponsor → Market → S&U → Credit Metrics → ... (v1.2 order)
- [ ] All 18 baseline sections present (+ conditional if applicable)
- [ ] **NARRATIVE CHECK:** Every table/KV/sensitivity has interpretive prose — no orphan tables
- [ ] Deal Overview: narrative + dual KV (Property Profile / Loan Summary)
- [ ] S&U: ONE table, full dollar format, balances exactly
- [ ] Credit Metrics: As-Is/Stabilized/Threshold/Status columns, ✓/✗ only
- [ ] DSCR threshold: 1.05x (NOT 1.10x, 1.20x, 1.25x)
- [ ] Lender Rent: unit mix table + supporting KV pairs
- [ ] Rent Comps: minimum 5 comps with avg rent, $/SF, occ + subject positioning
- [ ] Sales Comps: minimum 3 comps with $/unit, cap rate + subject implied value
- [ ] Cash Flow: 3-year (or As-Is/Stab) table with full line items
- [ ] Sizing Waterfall: ALL 6 constraints shown, binding identified
- [ ] Sensitivity: Cap rate and vacancy in SEPARATE tables
- [ ] Sponsor: narrative + insight box if applicable
- [ ] Market: dual KV + narrative paragraph(s)
- [ ] Risks: 5-8 deal-specific items with severity + assessment + mitigant
- [ ] Returns: UNLEVERED ONLY — no warehouse, no levered IRR/MOIC
- [ ] Diligence Needs: prioritized with workstreams
- [ ] Recommendation: APPROVE/CONDITIONAL/DECLINE with 2-3 paragraph rationale
- [ ] Sources: publication names, not raw queries
- [ ] $/unit shown next to all value and loan figures
- [ ] SOFR from FRED (not assumed)
- [ ] Flood zone from FEMA (not assumed)
- [ ] No $XX,XXXK format anywhere
- [ ] Font: Calibri ONLY

---

## 14. Generator Routing — Which Class for What

| Output Type | Generator | Class | Mode |
|-------------|-----------|-------|------|
| Quick Analysis Memo | `pinchfin_qr_memo.py` | `PinchfinQRMemo` | `memo` |
| Quick Screening Memo | `pinchfin_qr_memo.py` | `PinchfinQRMemo` | `memo` |
| Short-Form Memo | `pinchfin_qr_memo.py` | `PinchfinQRMemo` | `memo` |
| Full UW Memo | `pinchfin_qr_memo.py` | `PinchfinQRMemo` | `report` |
| Sponsor Analysis (standalone) | `valeri_report_v3.py` | `ValeriReport` | — |
| Market Analysis (standalone) | `valeri_report_v3.py` | `ValeriReport` | — |
| Comparable Analysis (standalone) | `valeri_report_v3.py` | `ValeriReport` | — |
| IC Memo (standalone) | `valeri_report_v3.py` | `ValeriReport` | — |

**Rule:** If the output is a MEMO (single document, sizing + recommendation), use `PinchfinQRMemo`. If the output is a standalone REPORT (single topic, 10+ pages), use `ValeriReport`.

---

## 15. Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-03-12 | Initial release. Locked format based on Parklyn v8 gold standard. Updated palette from PinchFin v4 (orange) to v9 (Navy/Cherry/RL Blue/Cloud). Removed levered returns (warehouse/levered IRR/MOIC). Established 17-section baseline with conditional section slots. |
| 1.1 | 2026-03-18 | Added Rent Comparables (Section 5) and Sales Comparables (Section 6) as BASELINE sections. 18 baseline + 1 conditional = 19. Renumbered all downstream sections. |
| **1.2** | **2026-03-19** | **MAJOR UPDATE.** (1) Section order changed: Sponsor Overview and Market Overview moved to Sections 2-3, immediately after Deal Overview, before Sources & Uses. Reader sees context before numbers. (2) Generator locked to `pinchfin_qr_memo.py` → `PinchfinQRMemo` for ALL memo types. `ValeriReport` reserved for standalone multi-page reports only. (3) Narrative mandate: every table must have interpretive prose using institutional copy and structured credit terminology. No orphan tables. (4) Scope expanded: spec now governs Quick Analysis, Quick Screening, Short-Form, AND Full UW Memo — not just Quick Review. (5) Gold standard updated to White Pines Quick Analysis (PF-QR-WHITE-PINES-2026-001). (6) Archived: v1.0, v1.1, PINCHFIN_QUICK_ANALYSIS_COMMAND_v9.md moved to `_ARCHIVE_RETIRED_DESIGNS/`. |
