# Preferred Equity Quick Review Memo — FORMAT SPECIFICATION

**Version:** 1.0
**Date:** March 19, 2026
**Status:** PRODUCTION
**Base Spec:** QUICK_REVIEW_MEMO_FORMAT_SPEC.md v1.1 (debt QR — 19-section structure)
**Generator:** `valeri_report_v3.py` → `ValeriReport` class
**Design System:** PinchFin v9 (Navy #080D18 / Cherry #9B2335 / RL Blue #B8CCDB / Cloud #F8F7F4)
**Sizing Config:** `pref_equity_credit_box_config.json` v1.0 (Pass 2) + `credit_box_config.json` v4.1 (Pass 1)

---

## 1. Purpose

This specification defines the section structure, ordering, and formatting rules for ALL Preferred Equity Quick Review memos. It extends the debt QR format spec with 3 new sections and modifications to existing sections to accommodate the two-pass constraint system, PIK accrual modeling, exit waterfall, and sponsor impact analysis.

**Relationship to debt QR spec:**
- 14 sections are REUSED or MODIFIED from the debt QR
- 3 sections are NET NEW (Sections 4, 8, 13)
- Same generator (`valeri_report_v3.py`), same palette, same formatting rules
- All VALERI_FORMAT_ENFORCER rules apply unchanged

---

## 2. Generator & Import

```python
import sys
sys.path.insert(0, r"C:\Users\BrianMurphy\OneDrive - Veleta Capital, LLC\Valeri\Valeri Design - Elevated")
from valeri_report_v3 import ValeriReport
```

**NEVER use:**
- `pinchfin_report.py` (archived — old orange palette)
- `valeri_report_alt.py` (deprecated)
- Node.js `docx` library
- Raw `python-docx` without ValeriReport wrapper

---

## 3. Cover Page / Header

```python
report = ValeriReport(
    title="Preferred Equity Quick Review",
    property_line="[Property Name] | [City, State]",
    detail_line="[Units] Units | [Property Description] | [Deal ID: PF-PQEQ-XXXX-YYYY-NNN]",
    recommendation="[APPROVE / CONDITIONAL / DECLINE]",
    loan_amount="$XX.XM Pref Equity",
    date="[Month Year]",
    mode="report"
)
```

**Rules:**
- `title` is ALWAYS "Preferred Equity Quick Review"
- `loan_amount` shows the PREF EQUITY amount (not senior loan)
- `detail_line` includes the `PF-PQEQ-` deal ID prefix
- `mode` = ALWAYS "report"

---

## 4. LOCKED Section Structure (22 Sections)

Every Pref Equity Quick Review contains these sections IN THIS EXACT ORDER. Section 7A is conditional. All others are MANDATORY.

---

### Section 1: DEAL OVERVIEW (MODIFIED)

**Method:** `report.add_section("Deal Overview")`

**Modification vs. debt QR:** The right-panel KV is "Capital Structure Summary" instead of "Loan Summary". Opening narrative must reference both the senior debt and the pref equity position.

**Components (in order):**

1. **Opening Narrative Paragraph** — 4-6 sentences covering:
   - Property name, unit count, construction type, location (MSA)
   - Sponsor name and principals
   - Capital structure: senior loan amount + pref equity amount + sponsor equity
   - Property status (occupancy, construction completion, lease-up stage)
   - Why preferred equity (not senior-only or mezz): 1 sentence
   - Maximum supportable pref equity + binding constraint

2. **Dual KV Layout** — `report.add_dual_kv()` with two panels:

   **Left Panel: "Property Profile"** — SAME as debt QR

   **Right Panel: "Capital Structure Summary"**
   | Field | Format |
   |-------|--------|
   | Senior Loan | $X,XXX,XXX ($/unit) |
   | Pref Equity (Veleta) | $X,XXX,XXX ($/unit) |
   | Sponsor Equity | $X,XXX,XXX ($/unit) |
   | Total Capital Stack | $X,XXX,XXX |
   | Pref Current Pay | X.X% |
   | Pref PIK Rate | X.X% |
   | Pref Total Return | XX.X% |
   | Combined LTV (Stab) | XX.X% |
   | Source | Direct / Broker name |

---

### Section 2: SOURCES & USES — 3-Tranche (MODIFIED)

**Method:** `report.add_section("Sources & Uses")`

**Modification:** Sources now show three tranches: Senior Loan + Pref Equity + Sponsor Equity.

**Components:**

1. **S&U Table** — `report.add_sources_uses()` with side-by-side format
   - Sources: Senior Loan + Preferred Equity + Sponsor Equity → Total Sources
   - Uses: Itemized line items → Total Uses
   - **MUST BALANCE exactly**
   - Dollar format: FULL ($XX,XXX,XXX) — not abbreviated
   - Percentage column on each side
   - Totals row bold

2. **S&U Narrative** — 2-3 sentences explaining:
   - Three-tranche capital structure
   - Pref equity fills equity gap between senior and sponsor
   - Sponsor equity percentage of total cost

---

### Section 3: SENIOR DEBT CREDIT METRICS (MODIFIED)

**Method:** `report.add_section("Senior Debt Credit Metrics")`

**Modification:** Explicit note that pref equity is excluded from all debt metrics. Same 6-constraint table as debt QR.

**Components:**

1. **Introductory Paragraph** — 2-3 sentences explaining:
   - Senior loan is validated independently (Pass 1)
   - Pref equity is EQUITY and excluded from all debt metrics
   - Which NOI basis is used

2. **Credit Metrics Table** — Same format as debt QR Section 3
   - All 6 constraints shown
   - Status: ✓ / ✗ ONLY
   - Add footnote row: "Note: Preferred equity is excluded from all debt metrics above. Pref is equity, not debt."

---

### Section 4: CAPITAL STACK & COMBINED METRICS (NEW)

**Method:** `report.add_section("Capital Stack & Combined Metrics")`

**This section is NET NEW — does not exist in the debt QR.**

**Components:**

1. **Capital Stack Table** — `report.add_table()`

   | Tranche | Amount | % of Stack | Cost | Priority |
   |---------|--------|-----------|------|----------|
   | Senior Loan | $XX.XM ($/unit) | XX.X% | X.XX% | 1st (Debt) |
   | Preferred Equity | $X.XM ($/unit) | XX.X% | XX.X% (current + PIK) | 2nd (Equity) |
   | Sponsor Equity | $X.XM ($/unit) | XX.X% | Residual | Last |
   | **Total** | **$XX.XM** | **100.0%** | **X.XX% blended** | |

2. **Combined Metrics KV Pairs** — `report.add_kv_pairs()`
   - Combined LTV As-Is (Senior + Pref) / As-Is Value
   - Combined LTV Stabilized (Senior + Pref) / Stab Value
   - Combined LTC (Senior + Pref) / Total Cost
   - Equity Cushion (Pref + Common) / Stab Value
   - Blended Cost of Capital
   - Senior Lender Equity Cushion (all equity below senior)

3. **Narrative** — 2-3 sentences on capital structure positioning

---

### Section 5: LENDER RENT UNDERWRITING (SAME)

**Method:** `report.add_section("Lender Rent Underwriting")`

Identical to debt QR Section 4. No modifications.

---

### Section 6: RENT COMPARABLES (SAME)

**Method:** `report.add_section("Rent Comparables")`

Identical to debt QR Section 5. No modifications.

---

### Section 7: SALES COMPARABLES (SAME)

**Method:** `report.add_section("Sales Comparables")`

Identical to debt QR Section 6. No modifications.

---

### Section 7A: CONDITIONAL — Deal-Specific Section(s) (SAME)

Same rules as debt QR Section 7. Examples: Tiered Concession Plan, Retail Component, Affordable/LIHTC.

---

### Section 8: PREF EQUITY STRUCTURE (NEW)

**Method:** `report.add_section("Preferred Equity Structure")`

**This section is NET NEW — does not exist in the debt QR.**

**Components:**

1. **Pref Terms KV Pairs** — `report.add_kv_pairs()`
   - Pref Equity Amount
   - Current Pay Rate
   - PIK Rate
   - Total Pref Return
   - Compounding (Quarterly)
   - Term Structure (e.g., 2+1+1)
   - Lockout Period
   - Redemption Mechanism
   - Participation (if any)
   - Governance Rights (summary — consent, GP removal, reporting)

2. **Mezz vs. Pref Comparison Table** — `report.add_table()`

   | Feature | Mezzanine | Preferred Equity (This Deal) |
   |---------|-----------|------------------------------|
   | Legal Structure | Secured debt | Equity interest |
   | Priority | Behind senior | Behind all debt, above common |
   | Foreclosure Rights | Yes | No |
   | ICA Required | Yes | No |
   | Impact on Senior LTV | Increases combined leverage | Not debt — no LTV impact |
   | Tax Treatment | Deductible | Not deductible |
   | Default Remedy | Acceleration + foreclosure | GP removal, forced sale |
   | Typical Cost | 10-15% total | 12-18% IRR |

3. **Structuring Rationale** — 2-3 sentences on why pref equity is the appropriate structure for this deal

---

### Section 9: CASH FLOW & DISTRIBUTION WATERFALL (MODIFIED)

**Method:** `report.add_section("Cash Flow & Distribution Waterfall")`

**Modification:** Adds pref equity current pay, PIK accrual, and cash to common rows below the NOI line.

**Components:**

1. **Cash Flow Table** — Extended from debt QR:

   | Row | Y1 | Y2 | Y3 |
   |-----|----|----|-----|
   | Average Occupancy | X.X% | X.X% | X.X% |
   | Residential GPR | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | *[standard revenue lines]* | | | |
   | **Effective Gross Income** | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | Total Operating Expenses | ($X,XXX,XXX) | ($X,XXX,XXX) | ($X,XXX,XXX) |
   | **Net Operating Income** | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | *blank row* | | | |
   | Senior Debt Service | ($X,XXX,XXX) | ($X,XXX,XXX) | ($X,XXX,XXX) |
   | **Cash After Senior DS** | $XXX,XXX | $XXX,XXX | $XXX,XXX |
   | Pref Current Pay | ($XXX,XXX) | ($XXX,XXX) | ($XXX,XXX) |
   | Pref PIK Accrual | ($XXX,XXX) | ($XXX,XXX) | ($XXX,XXX) |
   | **Cash to Common Equity** | $XXX,XXX | $XXX,XXX | $XXX,XXX |

---

### Section 10: DUAL SIZING WATERFALL (MODIFIED)

**Method:** `report.add_section("Dual Sizing Waterfall")`

**Modification:** Two sub-tables: (A) Senior 6-constraint waterfall, (B) Pref equity constraint validation.

**Components:**

1. **Sub-table A: Senior Sizing Waterfall** — Same as debt QR sizing waterfall
   - All 6 constraints, binding identified
   - Note: "Pref equity excluded from all metrics above"

2. **Sub-table B: Pref Equity Constraint Validation**

   | Constraint | Threshold | Result | Status |
   |------------|-----------|--------|--------|
   | Combined LTV As-Is | <=80% | XX.X% | ✓ / ✗ |
   | Combined LTV Stab | <=80% | XX.X% | ✓ / ✗ |
   | Combined LTC | <=85% | XX.X% | ✓ / ✗ |
   | Pref IRR (Base) | >=14.0% | XX.X% | ✓ / ✗ |
   | Pref MOIC (Base) | >=1.40x | X.XXx | ✓ / ✗ |
   | Sponsor Equity Floor | >=10% | XX.X% | ✓ / ✗ |
   | Pref:Common Ratio | <=2.0x | X.Xx | ✓ / ✗ |
   | Max Pref Amount | $25M | $XX.XM | ✓ / ✗ |
   | **Binding Pref Constraint** | | | |

---

### Section 11: PIK ACCRUAL ANALYSIS (MODIFIED — replaces IR Analysis)

**Method:** `report.add_section("PIK Accrual Analysis")`

**Modification:** Replaces Interest Reserve Analysis from debt QR. Models pref equity accrual instead.

**Components:**

1. **Summary KV Pairs** — `report.add_kv_pairs()`
   - Original Pref Amount
   - Current Pay Rate / PIK Rate / Total Return
   - Compounding Method (Quarterly)
   - Months of Full PIK (before current pay commences)
   - Cumulative PIK Accrual at Exit
   - Pref Balance at Exit
   - Accrual as % of Original (flag if >50%)

2. **Quarterly Accrual Table** — `report.add_table()`

   | Quarter | Pref Return Due | Cash Available | Current Pay Paid | PIK Accrual | Cumul Accrual | Pref Balance |
   |---------|----------------|----------------|-----------------|-------------|---------------|-------------|

   Show all quarters through exit. Base row (stabilization quarter) in BOLD.

3. **Accrual Narrative** — 2-3 sentences on PIK trajectory, when current pay commences, total compounding effect

---

### Section 12: SENSITIVITY ANALYSIS (MODIFIED)

**Method:** `report.add_section("Sensitivity Analysis")`

**Modification:** Three tables instead of two. Adds pref return sensitivity.

**Components — THREE SEPARATE TABLES (NEVER COMBINED):**

1. **Cap Rate Impact on Pref** — `report.add_subsection("Cap Rate Sensitivity — Pref Returns")`

   | Cap Rate | Exit Value | Pref Redemption | Pref IRR | Pref MOIC |
   |----------|-----------|----------------|----------|-----------|
   | Base ± 75bps in 25bps steps (7 rows) |

   Base row: BOLD.

2. **Vacancy Stress** — `report.add_subsection("Vacancy Stress")`

   | Vacancy | NOI | DSCR (Senior) | Cash After DS | Pref Coverage |
   |---------|-----|---------------|---------------|---------------|
   | 5-6 rows from 5% to 25% |

   Base row: BOLD. DSCR < 1.00x: red.

3. **Pref Return Sensitivity** — `report.add_subsection("Pref Return Sensitivity")`

   | Exit Month | PIK Accrual | Pref Redemption | Pref IRR | Pref MOIC |
   |-----------|-------------|----------------|----------|-----------|
   | 12 | $XXX,XXX | $X.XM | XX.X% | X.XXx |
   | 18 | $XXX,XXX | $X.XM | XX.X% | X.XXx |
   | 24 | $XXX,XXX | $X.XM | XX.X% | X.XXx |
   | 30 | $XXX,XXX | $X.XM | XX.X% | X.XXx |
   | 36 | $XXX,XXX | $X.XM | XX.X% | X.XXx |

---

### Section 13: EXIT WATERFALL & SPONSOR IMPACT (NEW)

**Method:** `report.add_section("Exit Waterfall & Sponsor Impact")`

**This section is NET NEW — does not exist in the debt QR.**

**Components:**

1. **Exit Scenario Table** — `report.add_table()`

   | Scenario | Exit Value | Senior Payoff | Pref Redemption | Common Equity | Pref IRR | Pref MOIC |
   |----------|-----------|--------------|----------------|---------------|----------|-----------|
   | Base | $XX.XM | $XX.XM | $X.XM | $X.XM | XX.X% | X.XXx |
   | +10% | $XX.XM | $XX.XM | $X.XM | $X.XM | XX.X% | X.XXx |
   | -10% | $XX.XM | $XX.XM | $X.XM | $X.XM | XX.X% | X.XXx |
   | -20% | $XX.XM | $XX.XM | $X.XM | $X.XM | XX.X% | X.XXx |
   | Breakeven | $XX.XM | $XX.XM | $X.XM | $0 | XX.X% | X.XXx |

2. **Sponsor With/Without Comparison** — `report.add_table()`

   | Metric | Without Pref | With Pref |
   |--------|-------------|-----------|
   | Sponsor Equity | $X.XM | $X.XM |
   | Annual CF (Stabilized) | $XXX,XXX | $XXX,XXX |
   | Cash-on-Cash | X.X% | X.X% |
   | Exit Equity (Base) | $X.XM | $X.XM |
   | Sponsor MOIC | X.XXx | X.XXx |
   | Sponsor IRR | XX.X% | XX.X% |

3. **Impact Narrative** — 2-3 sentences on whether pref equity creates positive or negative leverage for the sponsor, and the key driver

---

### Section 14: SPONSOR OVERVIEW (SAME)

Identical to debt QR Section 12. No modifications.

---

### Section 15: MARKET OVERVIEW (SAME)

Identical to debt QR Section 13. No modifications.

---

### Section 16: KEY RISKS & MITIGANTS (MODIFIED)

**Method:** `report.add_section("Key Risks & Mitigants")`

**Modification:** Adds pref-specific risks to the standard risk table.

**Components:** Same format as debt QR but must include AT LEAST 2 of these pref-specific risks:

| Risk Category | Examples |
|--------------|---------|
| PIK Accrual Risk | Compounding burden if lease-up extends; accrual at exit exceeds $X |
| Governance / GP Removal | Pref investor can seek GP removal if return chronically unpaid |
| Recharacterization Risk | If pref terms resemble debt, potential recharacterization by lender or court |
| Inverted Stack | If pref > common equity, sponsor alignment concern |
| Exit Timing | Pref accrual grows with time; delayed exit increases redemption burden |
| Subordination | Pref is last to recover in distress after senior debt |

Minimum 5 risks total, maximum 8. At least 2 must be pref-specific.

---

### Section 17: VELETA PREF EQUITY RETURNS (MODIFIED)

**Method:** `report.add_section("Veleta Preferred Equity Returns")`

**Modification:** Shows pref equity returns instead of lender debt returns.

**Components:**

1. **Returns Table** — `report.add_table()` with 4 columns:

   | | 12-Month | 24-Month | 36-Month |
   |--|----------|----------|----------|
   | Current Pay Income | $XXX,XXX | $XXX,XXX | $XXX,XXX |
   | PIK Accrual | $XXX,XXX | $XXX,XXX | $XXX,XXX |
   | Exit Redemption | $X,XXX,XXX | $X,XXX,XXX | $X,XXX,XXX |
   | **Pref IRR** | XX.X% | XX.X% | XX.X% |
   | **Pref MOIC** | X.XXx | X.XXx | X.XXx |
   | Current Yield | X.X% | X.X% | X.X% |
   | Total Return | X.X% | X.X% | X.X% |

   **Col widths:** `COL_TEMPLATES["comparison_4"]`

---

### Section 18: DILIGENCE NEEDS LIST (MODIFIED)

**Method:** `report.add_section("Diligence Needs List")`

**Modification:** Adds pref-specific diligence items.

**Components:** Same format as debt QR but must include:

| # | Document | Priority | Workstream |
|---|----------|----------|------------|
| | Operating Agreement (full review) | Critical | Legal / Pref Structure |
| | Governance provisions (consent, removal, reporting) | Critical | Legal / Pref Structure |
| | Senior lender consent to pref equity | Critical | Capital Structure |
| | Sponsor org chart / entity structure | High | Sponsor DD |
| | Prior pref equity or JV track record | High | Sponsor DD |

These are IN ADDITION to standard diligence items from the debt QR.

---

### Section 19: RECOMMENDATION (MODIFIED)

**Method:** `report.add_section("Recommendation")`

**Modification:** Recommendation covers the pref equity position specifically, not senior debt.

**Components:**

1. **Recommendation Box** — `report.add_recommendation_box()`

   ```python
   report.add_recommendation_box(
       "CONDITIONAL",  # or "APPROVE" or "DECLINE"
       [
           "Paragraph 1: Maximum supportable pref equity, binding constraint, "
           "combined LTV, pref IRR/MOIC at base case.",
           "Paragraph 2: PIK accrual trajectory, current pay adequacy, sponsor "
           "equity percentage, alignment assessment.",
           "Paragraph 3: Conditions to proceed (numbered — OA review, senior "
           "lender consent, governance provisions, etc.).",
       ]
   )
   ```

---

### Section 20: SOURCES (SAME)

Identical to debt QR Section 18. No modifications.

---

## 5. Color Palette — PinchFin v9 (LOCKED)

Same as debt QR spec. See QUICK_REVIEW_MEMO_FORMAT_SPEC.md Section 5.

---

## 6. Typography (LOCKED)

Same as debt QR spec. See QUICK_REVIEW_MEMO_FORMAT_SPEC.md Section 6.

---

## 7. Numeric Formatting (LOCKED)

Same as debt QR spec plus:
- **Pref Return Rate:** X.X% (one decimal)
- **Combined LTV/LTC:** XX.X% (one decimal)
- **Pref:Common Ratio:** X.Xx (two decimals + x, same as MOIC format)
- **PIK Accrual:** Full format in tables ($XXX,XXX), abbreviated in narrative ($XXXk)

All VALERI_FORMAT_ENFORCER rules apply unchanged.

---

## 8. Structural Rules (LOCKED)

All rules from debt QR spec apply, plus:
1. **Section order is FIXED** — Sections 1-20 always appear in this order
2. **Three sensitivity tables** (not two) — cap rate, vacancy, pref return are ALWAYS separate
3. **Two sub-tables in Section 10** — Senior waterfall (A) and Pref constraints (B) are separate
4. **Exit waterfall shows 5 scenarios** — never fewer
5. **Sponsor with/without comparison is MANDATORY** — the fundamental pref equity question
6. **Mezz vs. pref comparison is MANDATORY** — Section 8
7. **PIK accrual table shows every quarter** — never summarized or abbreviated

---

## 9. Anti-Patterns (NEVER DO)

All anti-patterns from debt QR spec apply, plus:

| Anti-Pattern | Correct Approach |
|-------------|-----------------|
| Include pref in senior LTV/DSCR/DY | Pref is EQUITY — excluded from all debt metrics |
| Combined sensitivity tables (cap rate + vacancy + pref) | THREE separate tables |
| Skip mezz vs. pref comparison | Always include — Section 8 |
| Skip sponsor with/without | Always include — Section 13 |
| Annual or simple interest for PIK | Quarterly compounding — no exceptions |
| Show only base-case exit | 5 scenarios required |
| Recommend pref below 14% IRR or 1.40x MOIC | Deal does not work for pref — decline or restructure |
| Use "Loan Summary" panel in Deal Overview | Use "Capital Structure Summary" panel |
| Show senior debt returns in Section 17 | Show PREF EQUITY returns |

---

## 10. File Naming Convention

```
PF-PQEQ-[DEAL_NAME]-[YEAR]-[NNN]_Pref_Equity_QR.docx
```

Examples:
- `PF-PQEQ-CRESTVIEW-2026-001_Pref_Equity_QR.docx`
- `PF-PQEQ-SUMMIT-RIDGE-2026-002_Pref_Equity_QR.docx`

---

## 11. Section Summary (22 Sections)

| # | Section | Status vs Debt QR |
|---|---------|-------------------|
| 1 | Deal Overview | MODIFIED — "Capital Structure Summary" replaces "Loan Summary" |
| 2 | Sources & Uses (3-Tranche) | MODIFIED — Senior + Pref + Sponsor Equity |
| 3 | Senior Debt Credit Metrics | MODIFIED — note pref excluded |
| 4 | **Capital Stack & Combined Metrics** | **NEW** |
| 5 | Lender Rent Underwriting | SAME |
| 6 | Rent Comparables | SAME |
| 7 | Sales Comparables | SAME |
| 7A | Conditional | SAME rules |
| 8 | **Preferred Equity Structure** | **NEW** |
| 9 | Cash Flow & Distribution Waterfall | MODIFIED — adds pref rows |
| 10 | Dual Sizing Waterfall | MODIFIED — Sub-table A (senior) + B (pref) |
| 11 | PIK Accrual Analysis | MODIFIED — replaces IR Analysis |
| 12 | Sensitivity Analysis | MODIFIED — 3 tables (cap rate, vacancy, pref return) |
| 13 | **Exit Waterfall & Sponsor Impact** | **NEW** |
| 14 | Sponsor Overview | SAME |
| 15 | Market Overview | SAME |
| 16 | Key Risks & Mitigants | MODIFIED — adds pref-specific risks |
| 17 | Veleta Pref Equity Returns | MODIFIED — pref returns (not lender debt returns) |
| 18 | Diligence Needs List | MODIFIED — adds OA, governance, senior consent |
| 19 | Recommendation | MODIFIED — covers pref equity position |
| 20 | Sources | SAME |

---

## 12. Verification Checklist

Before delivering any Pref Equity Quick Review memo:

- [ ] Generator: `valeri_report_v3.py` → `ValeriReport` (NOT pinchfin_report.py)
- [ ] Colors: Navy #080D18 in section headers
- [ ] All 22 sections present in correct order (including 3 new sections)
- [ ] Deal Overview: "Capital Structure Summary" panel (not "Loan Summary")
- [ ] S&U: THREE tranches (Senior + Pref + Sponsor), full dollar format, balances exactly
- [ ] Senior metrics: Pref EXCLUDED from all debt calculations, noted in Section 3
- [ ] Capital Stack table with all 3 tranches, $/unit, % of stack, cost, priority
- [ ] Combined metrics (LTV, LTC) shown with both senior and pref in numerator
- [ ] Pref Structure: terms KV + mezz vs. pref comparison table
- [ ] Cash Flow: includes pref current pay, PIK accrual, and cash to common rows
- [ ] Dual Waterfall: Sub-table A (senior 6-constraint) + Sub-table B (pref 9-constraint)
- [ ] PIK Accrual: quarterly table through exit, 50% flag if triggered
- [ ] Sensitivity: THREE separate tables (cap rate, vacancy, pref return)
- [ ] Exit Waterfall: 5 scenarios (base, +10%, -10%, -20%, breakeven)
- [ ] Sponsor with/without comparison table included
- [ ] Risks: minimum 2 pref-specific risks out of 5-8 total
- [ ] Returns: PREF EQUITY returns (IRR, MOIC, current yield, total return at 12/24/36)
- [ ] Diligence: OA review, governance, senior consent included
- [ ] Recommendation: covers pref equity position specifically
- [ ] All VALERI_FORMAT_ENFORCER rules applied
- [ ] SOFR from FRED (not assumed)
- [ ] Flood zone from FEMA (not assumed)
- [ ] $/unit shown next to all value and loan figures
- [ ] Pref IRR >= 14.0% and MOIC >= 1.40x at base case (or deal declined)

---

## 13. Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-03-19 | Initial release. 22-section structure (3 new: Capital Stack, Pref Structure, Exit Waterfall). Based on QUICK_REVIEW_MEMO_FORMAT_SPEC.md v1.1. Two-pass constraint system. PIK accrual quarterly table. 5-scenario exit waterfall. Sponsor with/without comparison. Mezz vs. pref comparison mandatory. Three sensitivity tables. PF-PQEQ deal ID prefix. |
