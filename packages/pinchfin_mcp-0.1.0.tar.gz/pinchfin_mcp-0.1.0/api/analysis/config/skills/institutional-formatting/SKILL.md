---
name: institutional-formatting
version: 3.0
phase: 12
domain: Document Design & Presentation
dependencies: []
inputs:
  - Raw analysis content (from any phase)
  - valeri_report_v3.py API reference
  - VALERI_BRAND_V3.md specification
outputs:
  - Properly formatted DOCX documents per Elevated V3.1 standard
  - Format compliance verification
credit_box_config: v3.0
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# Institutional Formatting Skill -- V3 Enterprise Edition

## Purpose

Define and enforce the definitive formatting standard for all Valeri documents. This
skill is the single source of truth for colors, typography, table design, number
formatting, and layout rules. All reports use the Elevated V3.1 design system
exclusively, generated through valeri_report_v3.py.

### CRITICAL RULES

1. **V3.1 ELEVATED IS THE ONLY STANDARD.** No legacy themes (Parchment, Night Sky).
   No Space Grotesk, Inter, Roboto Mono, Georgia (except wordmark), or Arial.
2. **CALIBRI ONLY.** All text in all documents uses Calibri. Bold for headings (9pt),
   Regular for body (10pt), Bold right-aligned for numbers.
3. **FORMAT ENFORCER IS NON-NEGOTIABLE.** Every number in every document must comply
   with the Format Enforcer rules below. No exceptions.
4. **NO BLOCKY TABLES.** Tables use horizontal Steel Grey dividers only. No vertical
   borders. No colored header backgrounds. Bold text with thin Carbon Slate bottom
   border for headers.
5. **GENERATOR: valeri_report_v3.py.** This is the ONLY generator for DOCX output.
   Do not use valeri_report_alt.py or valeri_report.py.

## Inputs

| Input | Source | Required |
|---|---|---|
| Analysis content | Any phase output | Yes |
| valeri_report_v3.py | Valeri Design - Elevated folder | Yes |
| VALERI_BRAND_V3.md | Valeri Design - Elevated folder | Reference |
| Format Enforcer rules | CLAUDE.md / this skill | Yes |

## Color Palette (Elevated V3.1)

| Color | Hex | Usage |
|---|---|---|
| Carbon Slate | #2F363C | Section header bars, primary accent |
| Aether Blue | #C2DCEB | Context backgrounds, light callout boxes |
| Steel Grey | #E5E5E5 | Table dividers, zebra stripes |
| Institutional Black | #0F0F0F | Body text |
| Paper White | #FFFFFF | Canvas, table backgrounds |
| Green (NOI) | #0A7B4E | NOI row text (bold) |
| Amber (caution) | #D97706 | DSCR 1.00x-1.04x |
| Red (alert) | #B91C1C | DSCR < 1.00x |

**DEPRECATED COLORS (NEVER USE):**
- Night Sky (#292B31 + #BDA07F) -- old alt theme
- Navy (#1E3A5F) -- old institutional-formatting v1
- Charcoal (#2D2D2D) -- old v1
- Muted Gold -- old v1

## Typography Rules

| Element | Font | Size | Weight | Alignment |
|---|---|---|---|---|
| Section headers | Calibri | 9pt | Bold | Left (white on Carbon Slate bar) |
| Subsection headers | Calibri | 10pt | Bold | Left |
| Body text | Calibri | 10pt | Regular | Left (justified in paragraphs) |
| Table headers | Calibri | 9pt | Bold | Auto-detect from data |
| Table data | Calibri | 10pt | Regular | Auto-detect from data |
| Numbers ($, %, x, bps) | Calibri | 10pt | Bold | Right-aligned (including header) |
| VALERI wordmark | Georgia | -- | Bold | -- |

**DEPRECATED FONTS (NEVER USE):**
- Space Grotesk, Inter, Roboto Mono (V3.0, replaced by Calibri in V3.1)
- Arial (old institutional-formatting v1)
- Georgia as body font (only for VALERI wordmark)

## Number Formatting Rules (FORMAT ENFORCER)

### Dollar Amounts

| Range | Format | Example | WRONG |
|---|---|---|---|
| $1,000,000+ | $X.XM (one decimal) | $42.0M | $42M, $42.00M, $42,000K |
| $100,000-$999,999 | $XXXK (no decimals) | $840K | $0.84M, $840.0K |
| Below $100,000 | $XX,XXX (full format) | $45,000 | $45K, $45000 |
| Sources & Uses | Full format with commas | $42,000,000 | $42.0M in S&U tables |

**ABSOLUTE PROHIBITION:** Never use "$XX,XXXK" format (e.g., $45,210K, $42,000K).

### Credit Metrics

| Metric | Format | Example | WRONG |
|---|---|---|---|
| DSCR | X.XXx (two decimals + x) | 1.18x, 0.84x | 1.2x, 1.20, 120% |
| Debt Yield | X.X% (one decimal) | 7.8%, 6.0% | 7.80%, 7.8, .078 |
| LTV / LTC | XX.X% (one decimal) | 64.1%, 74.2% | 64.14%, 0.641 |
| Cap Rate | X.XX% (ALWAYS two decimals) | 5.00%, 5.25% | 5%, 5.0%, 5.2% |
| Interest Rate | X.XX% (ALWAYS two decimals) | 6.90%, 7.25% | 6.9%, 7.3% |
| Break-Even | XX.X% (one decimal) | 94.7%, 85.0% | 94.7, 95% |

### Unit Economics

| Metric | Format | Example |
|---|---|---|
| $/Unit | Commas, no decimals | $210,000/unit, $1,853/unit |
| $/SF | Commas, no decimals (unless cents) | $192/SF, $1.85/SF (for rent) |

## Table Design Rules

### Header Row
- Bold Calibri text
- Thin Carbon Slate (#2F363C) bottom border
- NO colored background (no navy, no grey fill)
- Column alignment auto-detected from data type

### Data Rows
- Calibri Regular 10pt
- Steel Grey (#E5E5E5) horizontal dividers between rows
- NO vertical borders anywhere
- Zebra striping optional (alternating White / #F5F5F5)

### Column Alignment (Auto-Detect)
- Text columns: Left-aligned (header AND data)
- Dollar columns: Right-aligned (header AND data)
- Percentage columns: Right-aligned (header AND data)
- Multiplier columns (x): Right-aligned (header AND data)
- BPS columns: Right-aligned (header AND data)

### Special Row Formatting
- NOI rows: Bold green (#0A7B4E)
- Total rows: Bold throughout
- Base case in sensitivity: Bold
- DSCR >= 1.05x: Normal black (pass)
- DSCR 1.00x-1.04x: Bold amber (#D97706) (monitor -- at/near floor)
- DSCR < 1.00x: Bold red (#B91C1C)

### Status Indicators
- Passing: checkmark character
- Failing: x-mark character
- NEVER use: "ok", "pass", "fail", "yes", "no"

## Layout Rules

### Section Headers
Slim Carbon Slate (#2F363C) bar with white Calibri Bold 9pt text.
Generated via `report.add_section("Title")` in valeri_report_v3.py.

### Callout Boxes

| Type | Background | Text | Use For |
|---|---|---|---|
| Section header bar | Carbon Slate #2F363C | White Bold | Section titles only |
| Key finding / assessment | Aether #C2DCEB at 30% opacity (#E8F0F6) | Dark Carbon Slate | Key findings, assessments |
| Neutral highlight | Light grey #F5F5F5 | Dark Carbon Slate | General emphasis |
| NEVER | Dark Carbon Slate bg | White text | Narrative callouts (DISCONTINUED) |

### KV Pair Layouts
- Use `report.add_kv_pairs()` for single-column key-value displays
- Use `report.add_dual_kv()` for side-by-side two-column layouts
- Dense formatting -- minimize whitespace between pairs
- Modeled after institutional Excel sizer format (Coastline Portfolio standard)

### Sensitivity Tables (MANDATORY SEPARATION)

Cap rate sensitivity and vacancy stress are ALWAYS two separate tables:

**Cap Rate Sensitivity -- 4 columns:**
Cap Rate | Value | LTV | $/Unit

**Vacancy Stress -- 4 columns:**
Vacancy | EGI | NOI | DSCR

Base case row BOLD in both. DSCR < 1.00x RED in vacancy table.
NEVER combine into a single 8-column table.

### Sources & Uses -- Side by Side

```
SOURCES                               USES
[Item]         $XX,XXX,XXX   XX%      [Item]         $XX,XXX,XXX   XX%
[Item]          $X,XXX,XXX    X%      [Item]          $X,XXX,XXX    X%
---------------------------------------
Total Sources  $XX,XXX,XXX  100%      Total Uses     $XX,XXX,XXX  100%
```

Full dollar format (not abbreviated). Must balance exactly. Total rows bold.

### Title Pages
Show ONLY:
- Document title
- Property name
- Property address
- Unit count

NO dates, versions, sponsor names, loan amounts, or confidentiality notices on title page.

### Page Breaks
- No page break mid-table
- No orphaned headers (header on one page, data on next)
- No auto-sizing tables (fixed column widths)

## Methodology

### Step 1: Content Preparation

Receive raw analysis content from the source phase. Identify all numeric values
and apply Format Enforcer rules before any document generation.

### Step 2: Document Structure

Map content to appropriate valeri_report_v3.py API calls:
- `add_section()` for major sections
- `add_subsection()` for sub-headers
- `add_paragraph()` for body text
- `add_kv_pairs()` / `add_dual_kv()` for key-value layouts
- `add_table()` for data tables
- `add_sensitivity_table()` for cap rate / vacancy tables
- `add_sources_uses_table()` for S&U
- `add_insight()` for key findings (light Aether background)
- `add_highlight_box()` for emphasis boxes

### Step 3: Format Verification

Run pre-flight checklist against completed document:

```
PRE-FLIGHT CHECKLIST:
[ ] No "$XX,XXXK" format anywhere
[ ] M format has exactly one decimal ($42.0M)
[ ] K format has no decimals ($840K)
[ ] Sources = Uses (exact balance)
[ ] DSCR shows two decimals + x (1.18x)
[ ] DY shows one decimal + % (7.8%)
[ ] Cap rate shows two decimals + % (5.25%)
[ ] Interest rate shows two decimals + % (7.30%)
[ ] Status columns use checkmark / x-mark only
[ ] Cap rate and vacancy are SEPARATE tables
[ ] Base case rows BOLD in sensitivity tables
[ ] DSCR < 1.00x is RED
[ ] NOI rows are GREEN
[ ] No auto-sized tables
[ ] No dark background callout boxes (except section headers)
[ ] Title page has only: title, property, address, units
[ ] No system rules in reader-facing text
[ ] No calculation echo after tables
```

## Outputs

| Output | Format | Destination |
|---|---|---|
| Formatted DOCX | Per Elevated V3.1 | Deal folder / outputs |
| Format verification log | Checklist | QA documentation |

## Quality Gates

- [ ] All colors from Elevated V3.1 palette only
- [ ] All text in Calibri (except VALERI wordmark in Georgia)
- [ ] All numbers formatted per Format Enforcer
- [ ] No vertical table borders
- [ ] No colored table header backgrounds
- [ ] Sensitivity tables separate (cap rate and vacancy)
- [ ] Sources & Uses in full dollar format, balanced
- [ ] Title page minimal (4 items only)
- [ ] Pre-flight checklist passed (all items)

## Error Handling

| Error Condition | Detection | Resolution |
|---|---|---|
| Legacy font detected | Non-Calibri font in document | Replace with Calibri. Flag which section. |
| Legacy color detected | Navy, charcoal, muted gold | Replace with Elevated V3.1 palette |
| Combined sensitivity table | Single table with cap rate + vacancy | Split into two separate tables |
| "$XX,XXXK" format | Dollar amount with commas before K | Convert to $M or $K per scale rules |
| Dark callout box on narrative | Carbon Slate bg on non-header box | Convert to light Aether/grey background |
| Vertical table borders | Any vertical lines in tables | Remove; use horizontal Steel Grey only |
| Auto-sized columns | Column widths changing per content | Set fixed column widths |
| Title page metadata | Dates, versions, sponsor on title | Remove; keep only title, property, address, units |

## Worked Example: Format Correction Log

**Input (incorrect):**
```
Loan Amount: $42,000K
Cap Rate: 5.2%
DSCR: 1.2x
Interest Rate: 7.3%
Status: ok
Table: Navy header with white text, vertical borders
Callout: Dark Carbon Slate background with white text key finding
Title page: "IC Memo | Oakwood Gardens | 200 Units | Feb 14, 2026 | CONFIDENTIAL"
```

**Output (corrected):**
```
Loan Amount: $42.0M
Cap Rate: 5.20%
DSCR: 1.18x
Interest Rate: 7.30%
Status: checkmark
Table: Bold text header, thin Carbon Slate bottom border, no vertical borders
Callout: Light Aether (#E8F0F6) background with Carbon Slate text
Title page: "Investment Committee Memorandum | Oakwood Gardens | 1234 Elm St, Dallas TX | 200 Units"
```

**Corrections Applied:**
1. $42,000K -> $42.0M (prohibited $XX,XXXK format)
2. 5.2% -> 5.20% (cap rates ALWAYS two decimals)
3. 1.2x -> 1.18x (DSCR ALWAYS two decimals)
4. 7.3% -> 7.30% (interest rates ALWAYS two decimals)
5. "ok" -> checkmark character (no text status indicators)
6. Navy header -> bold text with thin border (V3.1 table standard)
7. Dark callout -> light Aether background (dark bg only for section headers)
8. Title page stripped of date and confidentiality notice

## Version History

| Version | Date | Changes |
|---|---|---|
| 1.0 | Dec 2025 | Initial release with old Navy/Arial standard |
| 2.0 | Jan 2026 | Updated to Night Sky theme |
| 3.0 | Feb 2026 | V3 Enterprise: Complete rewrite to Elevated V3.1. Calibri only. Carbon Slate / Aether / Steel Grey palette. Format Enforcer integration. Table design rules (no vertical borders, no colored headers). Callout box rules. valeri_report_v3.py as sole generator. Deprecated all legacy themes and fonts. |
