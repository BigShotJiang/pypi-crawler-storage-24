---
name: comp-analysis
version: 3.0
phase: 6 — Comparable Analysis
domain: valuation
dependencies:
  - market-submarket (Phase 3 — market context)
  - data-infrastructure-pull (Phase 2 — verified data)
inputs:
  - input: Subject property details (address, units, vintage, class, unit mix)
    source: OM / Rent Roll
    required: true
  - input: Market Analysis output
    source: Phase 3
    required: true
  - input: Phase 2 PropertyContext
    source: mcp__valeri-data__
    required: true
outputs:
  - output: Comparable_Analysis.docx
    format: PinchFin V4 DOCX (30+ pages)
  - output: phase_04_comps.json
    format: JSON workflow state
credit_box_config: v3.0
mcp_tools:
  - mcp__perplexity__search
  - mcp__valeri-data__get_hud_data
  - mcp__valeri-data__get_walk_score
design_system: PinchFin V4 (Navy #070B1A, Orange #B85A30, Calibri)
---

# Comparable Analysis (Phase 4)

## Purpose

Comparable analysis establishes market-derived rent levels and property values through systematic comparison of the subject property against peer assets. This phase produces the rent comp adjustment grid and sales comp analysis that drive all downstream cash flow and valuation assumptions.

The distinction between good underwriting and deal processing is here: a deal processor accepts the broker's comps at face value. An underwriter selects independent comps, applies MAI-compliant adjustments, and derives lender rents that may differ materially from the broker's claims. The output of this phase feeds directly into Phase 6A (Lender Underwritten Rent).

CRITICAL RULES: Minimum 5 rent comps and 3 sales comps required. Every comp must have a documented adjustment grid. Net adjustments exceeding 20% on any single comp indicate the comp is not truly comparable and should be replaced or its weight reduced. Adjustments must be explained, not just stated. The output feeds Phase 6A lender rent derivation — do not skip or shortcut this phase.

## Inputs

| Input | Source | Required |
|-------|--------|----------|
| Subject property address, units, vintage, class | OM / Rent Roll | Yes |
| Subject unit mix (types, SF, current rents) | Rent Roll | Yes |
| Market Analysis output (submarket rents, vacancy, supply) | Phase 3 | Yes |
| HUD Fair Market Rents | mcp__valeri-data__get_hud_data | Yes |
| Walk Score / Transit Score | mcp__valeri-data__get_walk_score | Yes |
| Broker's rent comp set (if provided) | OM | No |
| Broker's sales comp set (if provided) | OM | No |

## Methodology

### Step 1: Subject Property Profile

Before selecting comps, establish a detailed subject property profile. This is the benchmark against which all adjustments are measured.

Document:
- Property name, address, year built, total units, net rentable SF
- Property class (A, B, C) and current condition (original, partially renovated, fully renovated)
- Unit mix with unit count, average SF, current in-place rent, and current $/SF per type
- Amenity package: in-unit (W/D, dishwasher, balcony, updated finishes) and property-level (pool, gym, clubhouse, parking type)
- Current occupancy (physical and economic)
- Walk Score, Transit Score, Bike Score from Phase 2
- Recent capital improvements (last 5 years)

### Step 2: Rent Comp Selection

Select 5-7 rent comps using these criteria (in priority order):

| Criterion | Ideal | Acceptable | Expand If Needed |
|-----------|-------|------------|------------------|
| Proximity | <1 mile | <2 miles | <5 miles (document why) |
| Vintage | +/- 5 years | +/- 10 years | +/- 15 years with condition adjustment |
| Unit count | +/- 25% of subject | +/- 50% of subject | Any size with scale note |
| Class | Same class | Adjacent class (B vs. B+/B-) | One class away with adjustment |
| Type | Market rate | Market rate | Exclude affordable/student unless subject is |

**Perplexity Query 1:** `"[PROPERTY ADDRESS]" comparable apartments nearby`
**Perplexity Query 2:** `"[SUBMARKET]" apartment rent comps Class [B/C]`
**Perplexity Query 3:** `"[SUBMARKET]" "[CITY]" apartment rents 2025 2026`

For each comp, collect:
- Property name and address
- Distance from subject (miles)
- Year built
- Total units
- Property class and condition
- Average rent by unit type (1BR, 2BR, 3BR)
- Average SF by unit type
- $/SF by unit type
- Current occupancy
- Amenity package (in-unit and property-level)
- Concessions offered (e.g., "1 month free on 12-month lease" = 8.3% effective discount)
- Recent renovations or capital improvements

### Step 3: Rent Comp Adjustment Grid (MAI Methodology)

Apply systematic adjustments to each comp's rent to derive what the subject property SHOULD achieve. Adjustments are applied to the COMP's rent to make it equivalent to the subject.

**Adjustment categories and typical ranges:**

| Category | Adjustment Basis | Typical Range | Direction Logic |
|----------|-----------------|---------------|-----------------|
| Location | Walk Score differential, proximity to employment/transit | +/- 5-15% | Comp in better location = negative adj (comp rent overstates subject) |
| Age/Condition | Year built differential, renovation status | +/- 5-10% | Comp newer/renovated = negative adj |
| Unit Size (SF) | SF differential per unit type | +/- $0.05-$0.15/SF | Comp larger = negative adj (larger units rent for less $/SF) |
| In-Unit Amenities | W/D, finishes, balcony, appliances | +/- 3-8% | Comp has W/D, subject does not = negative adj |
| Property Amenities | Pool, gym, parking, clubhouse | +/- 2-5% | Comp has pool+gym, subject has neither = negative adj |
| Concessions | Convert gross to effective rent | Actual concession % | Comp offers 1 month free = -8.3% adj to effective rent |

**Adjustment grid template (per comp, per unit type):**

```
Comp: [Name] — [Unit Type]
Unadjusted Rent: $[amount]

Location:           [Superior/Similar/Inferior]  →  [+/-X%]  =  $[amount]
Age/Condition:      [Superior/Similar/Inferior]  →  [+/-X%]  =  $[amount]
Unit Size:          [Larger/Similar/Smaller]     →  [+/-X%]  =  $[amount]
In-Unit Amenities:  [Superior/Similar/Inferior]  →  [+/-X%]  =  $[amount]
Property Amenities: [Superior/Similar/Inferior]  →  [+/-X%]  =  $[amount]
Concessions:        [Yes: X mo free / No]        →  [-X%]    =  $[amount]
─────────────────────────────────────────────────────────────────
Net Adjustment:                                     [+/-X%]
Adjusted Rent:                                      $[amount]
```

### Step 4: Market Rent Conclusion

Synthesize adjusted rents from all comps into a market rent conclusion by unit type. Weight comps based on comparability (most similar comps get highest weight).

Weighting criteria:
- Proximity: closer = higher weight
- Vintage match: closer vintage = higher weight
- Unit count match: similar size = higher weight
- Adjustment magnitude: lower net adjustment = higher weight (more comparable)

```
Market Rent Conclusion — [Unit Type]

Comp 1: [Name]  Adjusted: $[amt]  Weight: [X]%
Comp 2: [Name]  Adjusted: $[amt]  Weight: [X]%
Comp 3: [Name]  Adjusted: $[amt]  Weight: [X]%
Comp 4: [Name]  Adjusted: $[amt]  Weight: [X]%
Comp 5: [Name]  Adjusted: $[amt]  Weight: [X]%
────────────────────────────────────────────────
Weighted Average Market Rent:       $[amt]
Subject Current In-Place:           $[amt]
Variance (Loss-to-Lease or Premium): [+/-X%]
```

### Step 5: Sales Comp Selection and Analysis

Select 3-5 sales comps for valuation support and cap rate derivation.

**Perplexity Query 4:** `"[SUBMARKET]" multifamily sales transactions 2024 2025`
**Perplexity Query 5:** `"[MSA NAME]" apartment sales cap rates Class [B/C]`

Selection criteria:
- Timeframe: Last 24 months (prefer last 12)
- Proximity: 2-5 mile radius
- Size: Similar unit count (+/- 50%)
- Transaction type: Arm's length only (exclude distressed, related party, 1031 exchange premiums)

For each sales comp, collect:
- Property name and address
- Sale date and sale price
- Price per unit and price per SF
- Cap rate (actual NOI / sale price, or stated)
- Year built, units, class, condition at sale
- Buyer/seller and transaction context (portfolio sale, 1031, stabilized vs. value-add)

### Step 6: Sales Comp Adjustments

Apply time and condition adjustments to sales comps:

| Adjustment | Basis | Typical Range |
|------------|-------|---------------|
| Time/Market conditions | Months since sale x cap rate trend | +/- 0-25 bps per quarter |
| Condition | Renovation status at time of sale vs. subject | +/- 5-15% on $/unit |
| Scale | Unit count differential (larger assets trade at lower cap rates) | +/- 0-25 bps |
| Location quality | Submarket quality vs. subject | +/- 0-50 bps |

### Step 7: Valuation Conclusion

Derive As-Is and As-Stabilized values using the income approach (NOI / cap rate):

```
As-Is Valuation:
  In-Place NOI:           $[amount]
  Selected Cap Rate:      [X.XX]%
  As-Is Value:            $[amount]
  $/Unit:                 $[amount]

As-Stabilized Valuation:
  Stabilized NOI:         $[amount]  (from Phase 6 lender underwrite)
  Selected Cap Rate:      [X.XX]%
  Stabilized Value:       $[amount]
  $/Unit:                 $[amount]
```

Cap rate selection must be supported by sales comp evidence and bracket the selected rate with the observed range.

## Outputs

| Section | Content | Pages |
|---------|---------|-------|
| Executive Summary | Market rent conclusion, value range, cap rate range | 2-3 |
| Subject Property Profile | Unit mix, amenities, condition, Walk Score | 3-4 |
| Rent Comparables | 5-7 comps with full data profiles | 10-12 |
| Rent Adjustment Grids | Per-comp, per-unit-type adjustment detail | Embedded in above |
| Market Rent Conclusion | Weighted average by unit type, loss-to-lease | 3-4 |
| Sales Comparables | 3-5 comps with transaction detail | 5-6 |
| Valuation Conclusion | As-Is and As-Stabilized values, cap rate support | 4-5 |

## OUTPUT DEPTH & QUALITY STANDARDS

This is a core deal report. Every report must be institutional-grade, accurate,
and deep enough that a credit officer can make a lending decision without asking
follow-up questions. Quality and accuracy always take priority over word count.

**Target range: 5,000–8,000 words of narrative** (excluding table cells).
Do not pad, fill, or stretch to hit a number. If a deal has limited comps and the
analysis is thorough at 5,000 words, that is fine. If a complex market with many
comps, nuanced cap rate dynamics, and multi-approach valuation requires 9,000 words,
write it. The content dictates the length — not the other way around.

Tables SUPPORT the narrative — they never REPLACE it. Every data table must be
preceded or followed by at least one analytical paragraph that interprets the data.

### Section-Level Depth Guidance

| Section | Target Words | Required Narrative Elements |
|---------|-------------|----------------------------|
| Executive Summary | 400–600 | Cap rate range finding, value range finding, key comp conclusions narrative |
| Subject Property Profile | 600–1,000 | Property overview narrative, unit mix table with positioning narrative, current rent levels with renovated/unrenovated premium analysis, amenity package |
| Rent Comparables (1BR) | 600–1,200 | Each comp profiled with address/distance/vintage, summary comparison table, analytical paragraph for EACH comp positioning relative to subject |
| Rent Comparables (2BR) | 600–1,200 | Same depth as 1BR section |
| Market Rent Summary | 400–800 | Full rent table by unit type, subject vs market variance narrative, loss-to-lease analysis |
| Broker vs Lender | 400–800 | Side-by-side table (broker vs lender by unit type), growth comparison, variance analysis narrative |
| Sales Comparables | 800–1,500 | Market sales volume narrative with trend analysis, individual sales comp profiles (each with address, units, price, $/unit, cap rate, buyer/seller context) |
| Cap Rate Analysis | 400–800 | Cap rates by property class table, subject cap rate assessment narrative with 3-4 scenarios |
| Value Synthesis | 600–1,000 | Income Approach In-Place, Stabilized (Lender), Stabilized (Broker), Sales Comparison Approach, reconciliation table with weights |
| Appendices | Complete | 5 research queries with dates and tools, sources per Source Hierarchy |

### Research Source Hierarchy — MANDATORY

Accuracy depends on source quality. The following hierarchy governs ALL research:

**Tier 1 — Institutional Research (PREFERRED, use first):**
- Market reports: CBRE, JLL, Newmark, Cushman & Wakefield, Marcus & Millichap, Colliers, NAI Capital
- Data platforms: CoStar, RealPage, Yardi Matrix, REIS (Moody's Analytics), RCA (MSCI), Trepp
- Transaction data: County recorder, CoStar transaction records, brokerage press releases
- Valeri Data Services MCP: Property context, demographics, employment, macro, HUD FMR, walk score, flood
- Industry bodies: NMHC, NAA, MBA, CREFC, Freddie Mac Research, Fannie Mae Research

**Tier 2 — Verified Aggregators (supplement Tier 1, cross-reference):**
- Listing platforms: Apartments.com, RentCafe, Zumper (for rent confirmation — not as primary source)
- Transaction aggregators: Zillow, Redfin (for sales data cross-reference)
- News/press: The Real Deal, Commercial Observer, Bisnow, GlobeSt (for transaction reporting)

**Tier 3 — Never Cite:**
- Consulting blogs, content marketing, SEO articles, crowd-sourced forums
- Any source that would not be cited in a CREFC white paper or OCC examiner's report

RULE: When Tier 1 and Tier 2 sources conflict, Tier 1 governs. For rent comps,
prefer CoStar/Yardi/RealPage over RentCafe/Zumper — aggregator sites reflect
advertised asking rents which may differ from effective rents. For sales comps,
prefer brokerage press releases and county recorder data over news summaries.
Always note the source tier in the appendix.

### Anti-Pattern

Converting detailed comp analysis into a single summary row:
  BAD:  | Comp 1 | $1,625 | -7% | $1,511 |
  GOOD: "Henderson Lofts (0.4 miles east) is the subject's closest comparable,
         sharing the same Knox-Henderson submarket and similar 2000s vintage.
         At 180 units, it is modestly smaller than the subject but offers a
         comparable amenity package including a renovated fitness center and
         resort-style pool. Henderson Lofts commands a 2BR asking rent of $1,625,
         reflecting its full-building renovation completed in 2023..."
         [FOLLOWED BY adjustment grid table]

## REPORT QUALITY ENFORCEMENT — GLOBAL STANDARD

This report is a standalone institutional research document intended for credit
committee, investors, capital partners, and public MCP consumers. It is NOT a
summary memo, NOT a dashboard, and NOT an IC presentation slide.

QUALITY REQUIREMENTS:
1. Target narrative word count (excluding table cells): 5,000–8,000 words
2. Every section heading must have at least 2 substantive paragraphs beneath it
3. Every data table must have interpretive narrative before or after it
4. All research queries must be executed and findings integrated into prose
5. Formatting uses PinchFin V4 design (Navy/Orange, Calibri, pinchfin_report.py)
6. Tables compress data efficiently — use them for metrics, timelines, comparisons
7. Narrative provides context, interpretation, and institutional insight
8. Source hierarchy must be followed — Tier 1 institutional sources first
9. Every factual claim must be traceable to a named, institutional-grade source
10. No filler copy — every sentence must add analytical value

QUALITY CHECK BEFORE FINALIZING:
- Is every section substantive with real analytical content (not padding)?
- Are sources primarily Tier 1 institutional research, not just internet aggregators?
- Could a credit officer read this report and make a lending decision without
  asking follow-up questions? If not, you've left out critical analysis.
- Is every number accurate and sourced? Cross-reference key figures across sources.

## Quality Gates

- [ ] Minimum 5 rent comps documented with full data profiles
- [ ] Minimum 3 sales comps documented with transaction detail
- [ ] Adjustment grid completed for every rent comp, every unit type
- [ ] No single comp has net adjustment exceeding +/-20% (replace or reduce weight if so)
- [ ] Market rent conclusion stated by unit type with weighted average
- [ ] Loss-to-lease calculated (market rent vs. in-place)
- [ ] Cap rate range derived from sales evidence
- [ ] As-Is and As-Stabilized values calculated
- [ ] All 5 Perplexity queries executed
- [ ] DOCX output is 30+ pages

## Error Handling

| Error | Resolution |
|-------|-----------|
| Fewer than 5 rent comps within 2-mile radius | Expand radius to 5 miles. If still insufficient, expand to adjacent submarkets and note "limited comp availability" with explanation |
| Fewer than 3 sales comps within 24 months | Expand timeframe to 36 months with time adjustments. Expand radius to 10 miles. If still insufficient, use MSA-level cap rate data from brokerage reports |
| Comp has net adjustment exceeding 20% | Replace with a more comparable property. If no better comp exists, keep but reduce weight to 10% and note "significant adjustment — low comparability" |
| Conflicting rent data between sources | Use the source with the most recent data date. Note discrepancy and use the more conservative figure |
| Sales comp was distressed/non-arm's-length | Exclude from cap rate derivation. Note in analysis. Find replacement |
| Subject property has no direct comp (unique asset) | Use bracket approach — find comps slightly above and below in quality. Derive market rent as midpoint with qualitative adjustment |
| Broker comps materially differ from independent comps | Flag the variance. Use independent comps for lender underwrite. Document broker comp weaknesses (stale data, cherry-picked, wrong submarket) |

## Worked Example

**Subject:** Oakwood Terrace — 200-unit Class B, built 1998, partially renovated (60 units upgraded), Knox-Henderson submarket, Dallas, TX.

**Subject Unit Mix:**

| Type | Units | Avg SF | In-Place Rent | $/SF |
|------|-------|--------|---------------|------|
| 1BR/1BA | 80 | 725 | $1,285 | $1.77 |
| 2BR/2BA | 90 | 1,050 | $1,545 | $1.47 |
| 3BR/2BA | 30 | 1,325 | $1,810 | $1.37 |
| Total/Wtd | 200 | 937 | $1,469 | $1.57 |

Current occupancy: 93.0%. Amenities: pool, small gym, surface parking, no in-unit W/D in classic units, W/D in renovated units.

**Rent Comp Summary (5 comps):**

| # | Property | Dist | Year | Units | Occ | 2BR Rent | 2BR $/SF |
|---|----------|------|------|-------|-----|----------|----------|
| 1 | Henderson Lofts | 0.4 mi | 2002 | 180 | 94% | $1,625 | $1.55 |
| 2 | McKinney Village | 0.9 mi | 1996 | 240 | 91% | $1,480 | $1.41 |
| 3 | Knox Park Apts | 1.1 mi | 2000 | 165 | 95% | $1,590 | $1.51 |
| 4 | Cole Avenue Place | 1.8 mi | 2005 | 220 | 92% | $1,680 | $1.60 |
| 5 | Fitzhugh Crossing | 2.1 mi | 1994 | 150 | 89% | $1,410 | $1.34 |

**Adjustment Grid Example — Comp 1 (Henderson Lofts), 2BR:**

```
Unadjusted 2BR Rent: $1,625

Location:           Similar (0.4 mi, same submarket)       →   0.0%
Age/Condition:      Similar (2002 vs 1998, both partial reno) →   0.0%
Unit Size:          Comp 1,048 SF vs Subject 1,050 SF       →   0.0%
In-Unit Amenities:  Superior (full W/D all units vs 33%)    →  -4.0%
Property Amenities: Superior (rooftop deck, upgraded gym)   →  -3.0%
Concessions:        None                                     →   0.0%
──────────────────────────────────────────────────────────────────
Net Adjustment:                                                -7.0%
Adjusted 2BR Rent:  $1,625 x 0.93 = $1,511
```

**Market Rent Conclusion — 2BR/2BA:**

| Comp | Unadjusted | Net Adj | Adjusted | Weight |
|------|-----------|---------|----------|--------|
| Henderson Lofts | $1,625 | -7.0% | $1,511 | 25% |
| McKinney Village | $1,480 | +3.0% | $1,524 | 20% |
| Knox Park Apts | $1,590 | -5.0% | $1,511 | 25% |
| Cole Avenue Place | $1,680 | -10.0% | $1,512 | 15% |
| Fitzhugh Crossing | $1,410 | +8.0% | $1,523 | 15% |
| **Weighted Avg** | | | **$1,515** | 100% |

Subject in-place 2BR: $1,545. Market conclusion: $1,515. Subject is slightly above market (+2.0%) — likely reflects recent renovations on 60 upgraded units. Non-renovated units are below market.

**Sales Comp Summary (3 comps):**

| # | Property | Date | Price | $/Unit | Cap Rate | Year |
|---|----------|------|-------|--------|----------|------|
| 1 | Uptown B Portfolio | Mar 2025 | $38.2M | $191,000 | 5.10% | 2001 |
| 2 | Cole Apts | Nov 2024 | $22.5M | $180,000 | 5.30% | 1997 |
| 3 | Knox District Res | Jul 2024 | $29.8M | $170,909 | 5.45% | 1995 |

Cap rate range: 5.10%-5.45%. Selected cap rate for As-Stabilized: 5.25% (midpoint, appropriate for partially renovated Class B). Selected cap rate for As-Is: 5.50% (25 bps premium for lease-up/renovation risk).
