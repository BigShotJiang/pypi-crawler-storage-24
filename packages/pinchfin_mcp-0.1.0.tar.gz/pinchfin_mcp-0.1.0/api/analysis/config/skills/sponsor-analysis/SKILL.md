---
name: sponsor-analysis
description: >
  Institutional-quality sponsor due diligence for CRE bridge lending.
  Evaluates entity structure, track record, financial capacity, operational
  capability, background risk, and relevant experience to produce a GO/NO-GO
  recommendation with tier classification. Output is a 30+ page DOCX analysis
  plus structured JSON for workflow state.
version: 3.0
phase: 2 — Sponsor Due Diligence
domain: credit-analysis
dependencies:
  - planning-phase-protocol (Phase -1 Context Brief)
  - nuance-registry (Phase 1 Document Intake)
inputs:
  - input: Sponsor entity name and principals
    source: OM / Term Sheet / Broker Package
    required: true
  - input: Operator Context Brief
    source: Phase -1 output
    required: true
  - input: Sponsor-provided materials (PFS, org chart, track record)
    source: Sponsor / Broker
    required: false
  - input: Prior {{PLATFORM_NAME}} loan history
    source: Internal records
    required: false
outputs:
  - output: Sponsor_Analysis.docx
    format: PinchFin V4 DOCX (30+ pages)
  - output: phase_02_sponsor.json
    format: JSON workflow state
credit_box_config: "{{WORKSPACE_ROOT}}/Valeri/system-docs/credit_box_config.json"
mcp_tools:
  - mcp__perplexity__search
  - mcp__perplexity__reason
  - mcp__perplexity__deep_research
design_system: PinchFin V4 (Navy #070B1A, Orange #B85A30, Calibri)
---

# Sponsor Analysis (Phase 2)

## Role Definition

You are a senior credit analyst performing institutional-quality sponsor due diligence for a CRE bridge lending platform. Your analysis determines whether the borrower has the track record, financial capacity, and operational capability to execute the proposed business plan. You must be thorough, skeptical, and evidence-based. Every claim about the sponsor must be sourced from verifiable public data, sponsor-provided materials, or internal records. You do not accept representations at face value. Your output directly informs the credit decision and loan structuring — a weak analysis here cascades errors through every downstream phase.

## Purpose

Sponsor analysis is the first substantive underwriting phase on every transaction. Its objective is to answer three questions with institutional rigor:

1. **Can this sponsor execute this specific business plan?**
2. **What is their verifiable track record?**
3. **Are there risk flags that should prevent us from lending?**

This phase establishes the human element of the deal before any property or financial analysis begins. A strong sponsor can rescue a marginal deal through execution and capital reserves; a weak sponsor can destroy a strong asset through mismanagement or fraud. Every subsequent assumption in the underwrite — rent achievability, renovation timeline, lease-up velocity — is filtered through sponsor capability.

**CRITICAL RULES:**
- Sponsor analysis is ALWAYS Phase 2 and ALWAYS executed.
- If the sponsor is assessed as a NO-GO, the workflow stops entirely — do not proceed to market, comps, or cash flow.
- All 8 Perplexity queries listed below must be executed.
- The output must be a 30+ page DOCX with substantive analysis in every section, not a summary or template.

## Inputs

| Input | Source | Required |
|-------|--------|----------|
| Sponsor entity name | OM / Term Sheet | Yes |
| Principal names and titles | OM / Broker | Yes |
| Operator Context Brief | Phase -1 | Yes |
| Personal Financial Statement (PFS) | Sponsor | No (request if missing) |
| Organizational chart | Sponsor | No |
| Track record summary | Sponsor / Broker | No |
| Prior {{PLATFORM_NAME}} loan history | Internal records | No |

## Constraints

- All constraint thresholds referenced from `{{WORKSPACE_ROOT}}/Valeri/system-docs/credit_box_config.json` v4.0.
- Sponsor tier classification informs downstream structuring decisions (reserves, covenants, reporting frequency, holdback conditions) per credit_box_config.
- Tier D sponsors are generally a NO-GO unless accompanied by a Tier A or B co-sponsor or guarantor with direct oversight.
- Tier C sponsors proceed with enhanced structuring (higher reserves, tighter covenants, monthly reporting).
- Net worth should exceed 1.0x the loan amount. Below 1.0x is not automatically disqualifying but requires documented mitigants.
- Post-close liquidity must cover 12 months of debt service plus remaining renovation budget.
- All research must use `mcp__perplexity__search` or `mcp__perplexity__reason`. Do not fabricate findings.
- Do not use other company names as aspirational benchmarks. {{PLATFORM_NAME}} is the standard.
- DOCX output uses PinchFin V4 design exclusively (`pinchfin_report.py`).

## Instructions

### Step 1: Entity Structure Research

Identify the legal borrowing entity, its parent structure, and all related affiliates. Document state of formation, principal office, and ownership percentages. Flag any complex structures (TIC, land trust, JV waterfall, fund-level borrowers).

**Perplexity Query 1:** `"[SPONSOR NAME]" real estate company portfolio overview`
**Perplexity Query 2:** `"[SPONSOR NAME]" principals founders leadership team`

Deliverables:
- Full legal name, state of formation, date of formation
- Principal office address
- All key principals with ownership percentages and titles
- Related entities (PM company, construction arm, fund vehicles)
- Organizational chart (if complex or multi-entity)

### Step 2: Track Record Quantification

Build a transaction history table with verifiable data points. For each transaction, capture: property name, location, unit count, acquisition date, purchase price, disposition date and price (if sold), hold period, and business plan type.

**Perplexity Query 3:** `"[SPONSOR NAME]" multifamily acquisitions transactions`
**Perplexity Query 4:** `"[SPONSOR NAME]" "[CITY/STATE]" properties investments`

Calculate portfolio-level metrics:
- Total units currently owned
- Total units acquired lifetime
- Total transaction volume ($ acquired + $ disposed)
- Average hold period
- Geographic concentration (number of MSAs)
- Weighted average vintage of portfolio
- Completion rate on value-add business plans (completed / attempted)
- Disposition track record (realized gains, losses, forced sales)

### Step 3: Sponsor Tier Classification

Assign a tier based on quantitative criteria. This tier informs downstream structuring decisions (reserves, covenants, reporting frequency).

| Tier | Label | Current Units | Markets | Track Record | Net Worth | Institutional Capital |
|------|-------|--------------|---------|--------------|-----------|----------------------|
| A | Institutional | 5,000+ | 5+ MSAs | 15+ years | $50M+ | Yes — named LP/JV partners |
| A- | Strong Institutional | 3,000-4,999 | 4+ MSAs | 12+ years | $30M-$50M | Yes — institutional LP |
| B+ | Acceptable with monitoring | 2,000-2,999 | 3+ MSAs | 10+ years | $15M-$30M | Some institutional |
| B | Established | 1,000-1,999 | 3+ MSAs | 7-9 years | $10M-$15M | Some institutional |
| B- | Established with conditions | 500-999 | 2+ MSAs | 5-6 years | $5M-$10M | Limited — HNW/family |
| C | Emerging | 250-499 | 1-2 MSAs | 3-4 years | $3M-$5M | Limited — HNW/family |
| D | New/Thin | <250 | 1 MSA | <3 years | <$3M | None |

**Scoring Rubric:**
- Meet ALL column thresholds to qualify for a tier. If the sponsor meets 4 of 6 criteria for a tier and falls short on 2, assign one notch below.
- Upward adjustment (+1 notch): prior {{PLATFORM_NAME}} loan with perfect payment history, or verifiable institutional JV partner on this deal.
- Downward adjustment (-1 notch): active litigation with potential material exposure, or net worth below 0.5x loan amount without strong mitigants.

### Step 4: Financial Capacity Assessment

Evaluate whether the sponsor has the balance sheet to support the deal through stress scenarios. Key tests:

- **Net Worth Test:** Net worth should exceed the loan amount (1.0x NW/Loan minimum). Below 1.0x requires documented mitigants (e.g., strong portfolio equity, co-guarantor).
- **Liquidity Test:** Post-close liquidity should cover 12 months of debt service plus renovation budget remaining.
- **Global Cash Flow:** Evaluate other income sources beyond subject property — stabilized portfolio cash flow, fee income, outside business income.
- **Existing Leverage:** Total debt / total assets ratio across the sponsor's global portfolio. Flag if above 75%.

**Perplexity Query 5:** `"[SPONSOR NAME]" capital partners investors equity`

### Step 5: Operational Capability Assessment

Evaluate property management infrastructure, construction management capability, and asset management depth. For value-add deals, construction execution is a critical risk factor.

**Perplexity Query 6:** `"[SPONSOR NAME]" property management track record`

Key questions:
- In-house PM or third-party? If third-party, who and what is their track record?
- Has the sponsor executed renovations of similar scope and scale?
- What is the on-site staffing model (headcount per 100 units)?
- Does the sponsor have a dedicated asset management team or is it principal-only?
- For value-add: what is the average renovation timeline vs. plan? How many units renovated per month?

### Step 6: Background and Risk Flag Search

Search for litigation, bankruptcies, foreclosures, regulatory actions, and negative press. This is a blocking gate — material adverse findings require escalation.

**Perplexity Query 7:** `"[SPONSOR NAME]" litigation lawsuits legal issues`
**Perplexity Query 8:** `"[SPONSOR NAME]" bankruptcy defaults foreclosures`

Document findings in a risk flag matrix:

| Category | Finding | Severity | Mitigant |
|----------|---------|----------|----------|
| Litigation (plaintiff) | Details or "None identified" | Low/Med/High | -- |
| Litigation (defendant) | Details or "None identified" | Low/Med/High | -- |
| Bankruptcy | Details or "None identified" | Low/Med/High | -- |
| Foreclosure / DIL | Details or "None identified" | Low/Med/High | -- |
| Regulatory violations | Details or "None identified" | Low/Med/High | -- |
| Criminal history | Details or "None identified" | Low/Med/High | -- |
| Negative press | Details or "None identified" | Low/Med/High | -- |

**Severity Definitions:**
- **High:** Active litigation with exposure exceeding 10% of net worth, any bankruptcy within 7 years, any foreclosure within 5 years, criminal charges, active regulatory enforcement.
- **Med:** Resolved litigation with material settlement, bankruptcy 7-15 years ago, foreclosure 5-10 years ago, negative press with reputational impact.
- **Low:** Routine tenant disputes, resolved matters with immaterial settlements, negative press that is minor or unrelated to real estate operations.

### Step 7: Relevant Experience Scoring

Score the sponsor's relevance to the subject deal on four dimensions:

| Dimension | Strong (3 pts) | Moderate (2 pts) | Limited (1 pt) |
|-----------|----------------|-------------------|-----------------|
| Similar asset (size, vintage, class) | Owned 3+ comparable properties | Owned 1-2 comparable | No comparable assets |
| Similar business plan | Executed same strategy 3+ times | Executed 1-2 times | First attempt |
| Subject market presence | Active in MSA with 500+ units | Active in MSA with <500 units | No MSA presence |
| Similar financing | Completed 3+ bridge loans | Completed 1-2 bridge loans | First bridge loan |

**Aggregate Score:**
- 10-12 points: Strong relevant experience
- 7-9 points: Moderate relevant experience
- 4-6 points: Limited relevant experience (enhanced DD and structuring required)

### Step 8: GO/NO-GO Recommendation

Synthesize all findings into a clear recommendation:

- **PROCEED** — Sponsor meets all criteria; no material concerns. Standard structuring.
- **PROCEED WITH CONDITIONS** — Acceptable with enhanced structuring. Specify conditions: higher reserves, guarantor addition, tighter covenants, monthly reporting, holdback conditions.
- **DECLINE** — Material risk flags or insufficient capability for this business plan. Document rationale.

## Chain of Thought

Follow this explicit reasoning sequence when performing the analysis. Do not skip steps.

```
1. IDENTIFY: Extract sponsor entity name, principal names, and any broker-provided
   track record from deal documents and Operator Context Brief.

2. RESEARCH: Execute ALL 8 Perplexity queries. For each query, extract and record:
   - Source name and date
   - Key data points found
   - Confidence level in the data (verified/unverified/conflicting)

3. RECONCILE: Compare broker-provided track record against Perplexity findings.
   Flag any discrepancies. Use the most conservative figure where data conflicts.

4. CLASSIFY: Walk through the tier classification table row by row.
   For each column, state the sponsor's value and whether it meets the threshold.
   Assign the tier. Document any notch adjustments with rationale.

5. ASSESS CAPACITY: Calculate NW/Loan ratio, liquidity coverage months,
   global leverage ratio. State each number explicitly.

6. ASSESS OPERATIONS: Score each operational dimension. Identify the weakest
   link in the sponsor's operational chain.

7. FLAG RISKS: For each of the 7 risk categories, state the finding.
   If "None identified," state that explicitly — do not leave blank.

8. SCORE RELEVANCE: Score each of 4 dimensions (1-3 points each).
   Calculate aggregate score. Map to Strong/Moderate/Limited.

9. SYNTHESIZE: Combine tier, financial capacity, operational capability,
   risk flags, and relevant experience into a single recommendation.
   State the recommendation and all conditions.

10. VALIDATE: Run through all quality gates before finalizing output.
```

## Worked Example

**Subject:** Pinnacle Property Group, LLC seeking $28.5M bridge loan for a 196-unit Class B value-add acquisition in Irving, TX (Dallas-Fort Worth MSA).

---

**Step 1 — Entity Research:**

- **Legal Entity:** Pinnacle Property Group, LLC — Texas LLC formed March 2013
- **Principal Office:** 4700 Sigma Rd, Suite 120, Dallas, TX 75244
- **Key Principals:**
  - David Kowalski (Managing Partner, 55%) — 18 years CRE experience, former VP at regional brokerage
  - Rachel Torres (COO, 30%) — 14 years multifamily operations, CPM designation
  - LP investors (15%) — mix of HNW individuals and a family office allocation
- **Related Entities:**
  - Pinnacle Management Services LLC (in-house PM, manages 100% of portfolio)
  - Pinnacle Renovation LLC (in-house construction arm, handles interior turns)
  - Pinnacle Fund II LP (discretionary fund vehicle, 2021 vintage)

**Step 2 — Track Record:**

| # | Property | Market | Units | Acquired | Price | Status | Business Plan |
|---|----------|--------|-------|----------|-------|--------|---------------|
| 1 | Oakmont Ridge | Dallas, TX | 224 | 2014 | $15.2M | Sold 2018 — $24.8M | Value-add |
| 2 | Timber Creek | Fort Worth, TX | 312 | 2015 | $22.1M | Sold 2019 — $38.5M | Value-add |
| 3 | Meadow Glen | Dallas, TX | 186 | 2016 | $16.8M | Held — stabilized | Value-add |
| 4 | Ridgeline Terrace | San Antonio, TX | 268 | 2017 | $24.5M | Held — stabilized | Value-add |
| 5 | Park Vista | Austin, TX | 340 | 2018 | $38.0M | Held — stabilized | Value-add |
| 6 | Summit Pointe | Dallas, TX | 198 | 2019 | $21.7M | Held — stabilized | Value-add |
| 7 | Creekside Village | Houston, TX | 280 | 2020 | $30.4M | Held — stabilized | Value-add |
| 8 | Lakewood Manor | Fort Worth, TX | 256 | 2021 | $32.0M | Held — in renovation | Value-add |
| 9 | Westgate Crossing | Dallas, TX | 416 | 2022 | $52.8M | Held — in lease-up | Value-add |
| 10 | Belmont Trails | Plano, TX | 312 | 2023 | $42.5M | Held — in renovation | Value-add |
| 11 | Heritage Oaks | Irving, TX | 192 | 2024 | $26.0M | Held — in renovation | Value-add |

**Portfolio Metrics:**
- Currently owned: 3,284 units across 9 properties (2 sold)
- Lifetime acquired: 3,520 units across 11 properties
- Total acquisition volume: $322.0M
- Disposition volume: $63.3M (2 assets, both profitable exits)
- Average hold period: 3.8 years (sold assets)
- Markets: Dallas, Fort Worth, San Antonio, Austin, Houston — 4 MSAs
- Value-add completion rate: 7 of 9 active plans completed or on track (78%)
- 2 assets currently in renovation — on schedule per broker representation

**Step 3 — Tier Classification:**

| Criterion | Threshold (B+) | Pinnacle Value | Meets? |
|-----------|----------------|----------------|--------|
| Current units | 2,000-2,999 | 3,284 | Yes (exceeds) |
| Markets | 3+ MSAs | 4 MSAs | Yes |
| Track record | 10+ years | 13 years (2013) | Yes |
| Net worth | $15M-$30M | $22.4M per PFS | Yes |
| Institutional capital | Some institutional | Family office LP only | Borderline |

Pinnacle meets 4 of 5 criteria cleanly for B+ and exceeds the unit count into A- territory. However, the institutional capital base is limited (family office, not named institutional LP). The unit count alone does not justify A-. One downward factor: a litigation item identified in Step 6.

**Tier Assignment: B+ (Acceptable with monitoring)**

Rationale: Strong unit count and geographic diversification push toward A-, but limited institutional capital and one litigation flag (see Step 6) hold the classification at B+. No notch adjustments applied — the positive and negative factors offset.

**Step 4 — Financial Capacity:**

| Metric | Value | Threshold | Status |
|--------|-------|-----------|--------|
| Net Worth | $22.4M | $28.5M (1.0x loan) | 0.79x — below target |
| Post-Close Liquidity | $5.8M | $3.6M (12 mo DS + reno remaining) | 1.61x — pass |
| Global Cash Flow | $2.9M annual | Positive | Pass |
| Global Leverage | 71% debt/assets | <75% | Pass (monitor) |

**Assessment:** Net worth is below the 1.0x loan target at 0.79x. This is not automatically disqualifying but requires mitigants. Mitigants present: (1) $5.8M post-close liquidity covers 19 months of debt service, providing substantial cushion; (2) $2.9M annual global cash flow from stabilized portfolio provides ongoing replenishment; (3) $322M lifetime acquisition volume demonstrates capacity to attract and deploy capital; (4) global leverage at 71% is within acceptable range. Recommendation: proceed with the NW shortfall documented and enhanced liquidity covenant.

**Step 5 — Operational Capability:**

- **Property Management:** In-house via Pinnacle Management Services LLC. Manages all 3,284 units. Staffing ratio of approximately 1 FTE per 55 units (above industry average). CPM-designated COO oversees operations.
- **Construction Management:** In-house via Pinnacle Renovation LLC. Interior unit turns are the core competency — has completed 1,800+ unit renovations across 7 properties.
- **Renovation Velocity:** Averages 18-22 units per month per property. Lakewood Manor and Belmont Trails are on schedule per broker representation (to be verified with draw inspection reports).
- **Asset Management:** Two-person asset management team plus principals. Weekly reporting on renovation properties, monthly on stabilized.

**Step 6 — Background and Risk Flags:**

| Category | Finding | Severity | Mitigant |
|----------|---------|----------|----------|
| Litigation (plaintiff) | None identified | -- | -- |
| Litigation (defendant) | Fair Housing complaint filed 2022 re: Creekside Village; settled 2023 for $85K with no admission of wrongdoing | Med | Settled, immaterial amount relative to portfolio. PM procedures updated post-settlement per Perplexity source. |
| Bankruptcy | None identified | -- | -- |
| Foreclosure / DIL | Partial interest in a 48-unit JV asset in Tulsa, OK returned to lender via deed-in-lieu in 2018 (8 years ago). Pinnacle was a minority partner (20%) with no management control. | Med | 8 years ago, minority position, no management control. Not a Pinnacle-operated asset. All Pinnacle-managed assets have performed. |
| Regulatory violations | None identified | -- | -- |
| Criminal history | None identified | -- | -- |
| Negative press | None identified | -- | -- |

**Step 7 — Relevant Experience Score:**

| Dimension | Score | Rationale |
|-----------|-------|-----------|
| Similar asset (196-unit Class B, 1990s vintage) | Strong (3) | Heritage Oaks (192 units, Irving) is nearly identical; Summit Pointe (198 units, Dallas) comparable |
| Similar business plan (value-add, interior renovations) | Strong (3) | 7 completed value-add executions across Texas |
| Subject market presence (DFW MSA) | Strong (3) | 5 properties in DFW totaling 1,588 units |
| Similar financing (bridge loan) | Moderate (2) | 3 prior bridge loans confirmed, remainder conventional |

**Aggregate Score: 11/12 — Strong relevant experience**

**Step 8 — Recommendation:**

**PROCEED WITH CONDITIONS**

Pinnacle Property Group is a B+ sponsor with strong execution track record in the DFW market and demonstrated capability on comparable value-add business plans. The 3,284-unit portfolio across 4 Texas MSAs, 13-year track record, and 7 successful value-add completions establish credible execution capacity for a 196-unit renovation in Irving.

Two items require enhanced structuring:
1. **Net worth at 0.79x loan amount** — below the 1.0x target. Mitigated by strong liquidity ($5.8M post-close, covering 19 months DS) and $2.9M annual global cash flow. Condition: enhanced liquidity covenant requiring maintenance of 9-month DS reserve throughout the loan term.
2. **Historical DIL (2018, minority JV position)** — immaterial given 8-year seasoning, minority interest, and no management control. No additional structuring required, but document in credit file.

Standard structuring otherwise applies. Monthly reporting given active renovation status.

---

## Error Handling

| Scenario | Severity | Resolution |
|----------|----------|------------|
| Sparse web presence — Perplexity returns few or no results for entity name | Medium | Try alternate entity names, DBA names, principal names individually. Search state LLC databases. If still nothing: classify as "Limited Public Information," assign Tier D, require sponsor to provide track record materials directly, and apply enhanced DD protocol. |
| Conflicting data — different sources show different unit counts or transaction details | Medium | Use the most conservative figure in the analysis. Note the discrepancy with citations to both sources. Request sponsor clarification. If unresolved, use the lower/worse figure for tier classification. |
| New entity with no operating history — sponsor formed the entity recently for this deal | Medium | Look through the entity to the principals. Research principals individually. Classify based on principals' track records at prior firms. If principals also lack verifiable history: Tier D, NO-GO unless co-sponsor or guarantor with Tier A/B credentials is added. |
| International sponsor — entity or principals domiciled outside the United States | High | Flag for enhanced DD. Verify U.S. entity formation and registered agent. Assess enforceability of guarantees under relevant jurisdiction. Require U.S.-based co-guarantor if principals reside outside the U.S. Consult legal on OFAC/sanctions screening. |
| Litigation found — active or resolved legal matters discovered | Variable | Apply severity definitions from Step 6. High severity items (active fraud, criminal, material exposure): immediate NO-GO, escalate to senior credit. Medium severity: document with mitigants, apply enhanced structuring. Low severity: document and proceed. |
| Sponsor unresponsive — PFS and track record materials not provided after request | High | Note "Financial capacity TBD — Pending PFS" in output. Request through broker with 5-business-day deadline. Apply Tier C structuring (enhanced reserves, monthly reporting) as interim assumption. If PFS not received before credit submission: NO-GO on financial capacity grounds. |
| Complex entity structure — fund vehicle, TIC, multiple GPs, or layered JV | Medium | Map full organizational chart. Identify who has day-to-day operational control vs. passive capital. Assess guarantor strength separately from entity. If operational control is unclear or split: require designation of a single responsible party with recourse obligations. |
| Prior {{PLATFORM_NAME}} loan exists | Low (positive) | Pull internal performance data — payment history, covenant compliance, reporting quality, draw inspection results. Weight internal experience heavily in tier classification. Perfect internal history: +1 notch adjustment. |

## Output Schema

### JSON Output (`phase_02_sponsor.json`)

```json
{
  "phase": "02_sponsor",
  "deal_id": "VUL-YYYY-NNN",
  "sponsor_name": "",
  "sponsor_entity_legal": "",
  "state_of_formation": "",
  "date_of_formation": "",
  "principals": [
    {
      "name": "",
      "title": "",
      "ownership_pct": 0.0,
      "years_experience": 0
    }
  ],
  "related_entities": [],
  "sponsor_tier": "A/A-/B+/B/B-/C/D",
  "tier_rationale": "",
  "recommendation": "PROCEED / PROCEED_WITH_CONDITIONS / DECLINE",
  "conditions": [],
  "current_units": 0,
  "lifetime_units": 0,
  "total_acquisition_volume": "",
  "total_disposition_volume": "",
  "properties_count": 0,
  "markets": [],
  "years_experience": 0,
  "value_add_completion_rate": "",
  "net_worth": "",
  "nw_loan_ratio": 0.0,
  "post_close_liquidity": "",
  "liquidity_coverage_months": 0,
  "global_cash_flow": "",
  "global_leverage": "",
  "risk_flags": [
    {
      "category": "",
      "finding": "",
      "severity": "Low/Med/High",
      "mitigant": ""
    }
  ],
  "relevant_experience_score": {
    "similar_asset": 0,
    "similar_business_plan": 0,
    "subject_market_presence": 0,
    "similar_financing": 0,
    "aggregate": 0,
    "classification": "Strong/Moderate/Limited"
  },
  "perplexity_queries_executed": 8,
  "data_confidence": "High/Medium/Low",
  "structuring_implications": []
}
```

### DOCX Output Structure (`[DEAL_NAME]_Sponsor_Analysis.docx`)

The Sponsor Analysis DOCX must contain these sections with the specified depth:

| # | Section | Content | Target Pages |
|---|---------|---------|-------------|
| 1 | Executive Summary | 2-3 sentence assessment, tier classification, recommendation, key conditions | 2-3 |
| 2 | Entity Overview | Legal structure, formation details, principals with bios, ownership chart, related entities, organizational structure | 3-4 |
| 3 | Track Record Analysis | Full transaction history table, portfolio metrics (units, volume, hold period, markets), disposition performance, value-add completion rate, execution quality narrative | 8-10 |
| 4 | Financial Capacity | Net worth analysis with NW/Loan ratio, post-close liquidity with months coverage, global cash flow, global leverage, stress scenario (what if renovation costs 20% more), capacity conclusion | 4-5 |
| 5 | Operational Capability | PM infrastructure (in-house vs. third-party, staffing ratios), construction management (renovation velocity, scope history), asset management depth, technology and reporting capabilities | 3-4 |
| 6 | Background Check | Full risk flag matrix across all 7 categories, detail on any findings, source citations, severity assessment with defined thresholds | 4-5 |
| 7 | Relevant Experience Assessment | 4-dimension scoring matrix with rationale per dimension, aggregate score, comparison to subject deal requirements, experience gaps identified | 3-4 |
| 8 | Conclusion and Recommendation | GO/NO-GO with full rationale, all conditions listed, structuring implications for downstream phases, monitoring requirements | 2-3 |
| -- | Appendix: Sources | All Perplexity sources with publication names and dates accessed. Begin with: "In addition to standard industry data sources, below is a partial sample of additional sources referenced in this analysis." | 1-2 |

**Total: 30+ pages**

All formatting must use PinchFin V4 design via `pinchfin_report.py`. Section headers use Navy (#070B1A) bars with Orange (#B85A30) accents. Tables use bold header text with thin bottom border. Numbers right-aligned in Calibri Bold.

## OUTPUT DEPTH & QUALITY STANDARDS

This is a core deal report. Every report must be institutional-grade, accurate,
and deep enough that a credit officer can make a lending decision without asking
follow-up questions. Quality and accuracy always take priority over word count.

**Target range: 5,000–8,000 words of narrative** (excluding table cells).
Do not pad, fill, or stretch to hit a number. If the sponsor is straightforward
and the analysis is complete at 5,500 words, that is fine. If a complex sponsor
with 30 years of transactions and active litigation requires 9,000 words, write it.
The content dictates the length — not the other way around.

Tables SUPPORT the narrative — they never REPLACE it. Every data table must be
preceded or followed by at least one analytical paragraph that interprets the data.

### Section-Level Depth Guidance

| Section | Target Words | Required Narrative Elements | Tables Expected |
|---------|-------------|----------------------------|-----------------|
| Executive Summary | 400–600 | 2-3 paragraph assessment with tier classification, key strengths/concerns narrative, GO/NO-GO rationale | 1 key findings table |
| Entity Overview | 600–1,000 | Company profile narrative (founding, evolution, investment philosophy), principal bios with career narrative (not just table), organizational structure explanation, related entities and their roles | 3-4 tables |
| Track Record Analysis | 1,500–2,500 | Year-by-year transaction narrative, portfolio evolution story, disposition performance narrative, value-add completion analysis, geographic expansion narrative, market-specific experience for subject deal | 5-8 tables |
| Financial Capacity | 600–1,000 | Capital formation narrative, leverage strategy analysis, NW/Loan ratio discussion with context, liquidity analysis with stress scenario narrative | 3-4 tables |
| Operational Capability | 400–800 | PM infrastructure narrative, value-add execution capability narrative, renovation/construction management assessment | 2-3 tables |
| Background Check | 600–1,000 | Detailed narrative on any litigation found (case details, dates, allegations, resolution, credit impact assessment), bankruptcy/default search narrative (even if "none found" — state what was searched), regulatory search results | 2-3 tables |
| Risk Assessment | 400–800 | Strengths enumerated with context, concerns enumerated with impact assessment, mitigants for each concern with evidence | 2-3 tables |
| Conclusion & Recommendation | 300–600 | Summary assessment table plus narrative recommendation with full rationale, sponsor-specific considerations for downstream phases | 1-2 tables |
| Appendix: Research Log | Complete | All 8 queries with dates and tools used | 1 table |
| Appendix: Sources | Complete | Named sources with publication names per Source Hierarchy | List |

### Research Source Hierarchy — MANDATORY

Accuracy depends on source quality. The following hierarchy governs ALL research:

**Tier 1 — Institutional Research (PREFERRED, use first):**
- Brokerage research: CBRE, JLL, Newmark, Cushman & Wakefield, Marcus & Millichap, Colliers, NAI Capital
- Data platforms: CoStar, RealPage, Yardi Matrix, REIS (Moody's Analytics), RCA (MSCI), Trepp
- Sponsor-provided documents: Offering memorandums, financial statements, organizational charts
- Government/regulatory: SEC EDGAR, state SOS filings, PACER (litigation), county recorder
- Industry bodies: NMHC, NAA, MBA, CREFC, Urban Land Institute

**Tier 2 — Verified Aggregators (supplement Tier 1, cross-reference):**
- Listing platforms: Apartments.com, Zillow, Redfin (for transaction data verification)
- Market aggregators: RentCafe, Zumper (for rent trend confirmation — not as primary source)
- News/press: The Real Deal, Commercial Observer, Bisnow, GlobeSt (for transaction reporting)

**Tier 3 — Never Cite:**
- Consulting blogs, content marketing, SEO articles, crowd-sourced forums
- Any source that would not be cited in a CREFC white paper or OCC examiner's report

RULE: When Tier 1 and Tier 2 sources conflict, Tier 1 governs. Always note the source
tier in the appendix. Prefer brokerage market reports and CoStar/Yardi data over
internet aggregator averages.

### Anti-Pattern

Converting a multi-paragraph analysis into a single table row:
  BAD:  | Track Record | 28 years, 52,000 units, $8.5B AUM | Strong |
  GOOD: "Pacific Urban Investors has maintained an active acquisition pipeline
         across market cycles, acquiring 52,000+ units over 28 years with a total
         transaction volume of $15.9 billion. The firm's 2021 record year ($1.6B)
         demonstrates institutional capital access even in competitive markets..."
         [FOLLOWED BY detailed transaction table]

## REPORT QUALITY ENFORCEMENT — GLOBAL STANDARD

This report is a standalone institutional research document intended for credit
committee, investors, capital partners, and public MCP consumers. It is NOT a
summary memo, NOT a dashboard, and NOT an IC presentation slide.

QUALITY REQUIREMENTS:
1. Target narrative word count (excluding table cells): 5,000–8,000 words
2. Every section heading must have at least 2 substantive paragraphs beneath it
3. Every data table must have interpretive narrative before or after it
4. All research queries must be executed and findings integrated into prose
5. Formatting uses PinchFin V4 design (Navy/Orange, Calibri, pinchfin_report.py)
6. Tables compress data efficiently — use them for metrics, timelines, comparisons
7. Narrative provides context, interpretation, and institutional insight
8. Source hierarchy must be followed — Tier 1 institutional sources first
9. Every factual claim must be traceable to a named, institutional-grade source
10. No filler copy — every sentence must add analytical value

QUALITY CHECK BEFORE FINALIZING:
- Is every section substantive with real analytical content (not padding)?
- Are sources primarily Tier 1 institutional research, not just internet aggregators?
- Could a credit officer read this report and make a lending decision without
  asking follow-up questions? If not, you've left out critical analysis.
- Is every number accurate and sourced? Cross-reference key figures across sources.

## Validation Rules

All quality gates must pass before the phase is marked complete. A single failure blocks Phase 3.

| # | Gate | Validation Criteria | Blocking |
|---|------|-------------------|----------|
| 1 | Perplexity Coverage | All 8 queries executed (verifiable in conversation history via `mcp__perplexity__search` calls) | Yes |
| 2 | Entity Documentation | Legal name, state of formation, all principals with ownership percentages documented | Yes |
| 3 | Track Record Minimum | At least 3 verifiable transactions identified, OR explicitly documented as "Limited Track Record — Tier D" with rationale | Yes |
| 4 | Tier Assignment | Sponsor tier assigned using the classification table with supporting data for each column; notch adjustments documented if applied | Yes |
| 5 | Risk Flag Completeness | All 7 risk flag categories addressed — each row states a finding or "None identified" (no blanks) | Yes |
| 6 | Financial Capacity | NW/Loan ratio calculated, post-close liquidity in months calculated, global leverage stated — even if PFS pending (note "TBD — Pending PFS" with interim assumptions) | Yes |
| 7 | Relevant Experience | All 4 dimensions scored (1-3 points each), aggregate calculated, classification mapped | Yes |
| 8 | Recommendation Stated | Explicit PROCEED / PROCEED_WITH_CONDITIONS / DECLINE with rationale and all conditions listed | Yes |
| 9 | DOCX Completeness | Output is 30+ pages with substantive content in all 8 sections plus appendix — no placeholder text, no "TBD" sections (except PFS-dependent items) | Yes |
| 10 | JSON State Saved | `phase_02_sponsor.json` written to deal workflow folder with all fields populated | Yes |
| 11 | Source Attribution | Every factual claim about the sponsor traces to a named source (Perplexity result, sponsor-provided document, or internal records) | Yes |
| 12 | Downstream Handoff | Structuring implications clearly stated for use by Phase 9 (sizing) and Phase 10 (structuring) — reserve requirements, reporting frequency, covenant conditions | Yes |
