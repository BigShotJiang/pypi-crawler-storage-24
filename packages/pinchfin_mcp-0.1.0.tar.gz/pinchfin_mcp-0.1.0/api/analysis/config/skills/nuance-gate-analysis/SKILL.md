---
name: nuance-gate-analysis
version: 3.0
phase: 9
domain: nuance-analysis
dependencies: [nuance-registry, comp-analysis, market-submarket]
inputs: [nuance-registry-output, deal-documents, rent-roll, operating-statements]
outputs: [gate-analysis-report, go-no-go-determination, financial-impact-quantification]
credit_box_config: v3.0
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# Gate-Keeping Nuance Analysis

## Purpose

Conduct deep research on deal-critical nuances that could materially impact the financing decision. Each gate-keeping nuance identified during registry must be analyzed for regulatory framework, compliance status, financial impact, and deal viability before proceeding to cash flow modeling.

### CRITICAL RULES
1. NEVER proceed to financial modeling without completing gate analysis for ALL flagged nuances
2. ALWAYS quantify financial impact in dollar terms -- vague "significant" or "material" is unacceptable
3. ALWAYS research jurisdiction-specific rules via Perplexity -- do not rely on general knowledge alone
4. IF multiple gate-keeping nuances interact, model the COMBINED impact, not each in isolation
5. Go/No-Go determination must be binary with conditions -- no "maybe" or "to be determined"
6. Use mcp__valeri-data__get_hud_data for Section 8 / affordable rent cap verification

## Inputs

| Input | Source | Required |
|-------|--------|----------|
| Nuance registry output | Phase 1 nuance-registry | Yes |
| Deal documents (OM, term sheet) | Sponsor submission | Yes |
| Rent roll with unit-level detail | Sponsor submission | Yes |
| T-12 operating statement | Sponsor submission | Yes |
| Property address | Deal intake | Yes |
| Jurisdiction-specific program docs | Sponsor / public records | If applicable |

## Methodology

### Step 1: Nuance Identification Confirmation
Review nuance-registry output. For each GATE-KEEPING nuance flagged, confirm:
- Nuance type and specific program/regulation
- Jurisdiction and governing authority
- Available documentation from sponsor

### Step 2: Regulatory Research (per nuance)
Execute targeted Perplexity queries:
- `[Program Name] [Jurisdiction] current rules requirements`
- `[Program Name] compliance obligations penalties`
- `[Program Name] expiration implications timeline`
- `[Property Address] [Program] specific records` (if public)

### Step 3: Current Status Assessment
For each nuance, document:
- Compliance standing (compliant / at-risk / violation)
- Years remaining on program/contract
- Recent inspections, audits, or regulatory actions
- Outstanding issues or pending changes

### Step 4: Financial Impact Quantification
Model the dollar impact across four dimensions:
- **Revenue impact**: Rent caps, contract rents vs. market, restricted growth
- **Expense impact**: Compliance costs, reporting, monitoring fees
- **Value impact**: Cap rate premium, buyer pool limitation, exit discount
- **Cash flow impact**: NOI delta between restricted and unrestricted scenarios

Formula: Annual Impact = (Market GPR - Restricted GPR) + Compliance Costs + Value Discount

### Step 5: Go/No-Go Determination
Score each criterion (Pass / Fail / Conditional):
- DSCR achievable at restricted income levels
- LTV supportable at restricted valuation
- Sponsor has relevant program experience
- Viable exit pathway exists within loan term
- Pricing adequately compensates for regulatory risk

**Decision Matrix**: All Critical items must Pass or Conditional. Any Critical Fail = NO-GO.

## Outputs

| Output | Format | Destination |
|--------|--------|-------------|
| Gate Analysis Report | DOCX via valeri_report_v3.py | Deal outputs folder |
| Go/No-Go Determination | JSON + DOCX section | Workflow state + report |
| Financial Impact Summary | Table with dollar amounts | Feeds into cash flow Phase 6 |
| Conditions List | Bullet list | Term sheet / closing checklist |

## Quality Gates

- [ ] All GATE-KEEPING nuances from registry analyzed
- [ ] Jurisdiction-specific rules researched via Perplexity (not assumed)
- [ ] Financial impact quantified in dollars for each nuance
- [ ] Go/No-Go determination made with explicit pass/fail on each criterion
- [ ] If PROCEED WITH CONDITIONS, conditions are specific and actionable
- [ ] If multiple nuances, combined impact modeled
- [ ] HUD data pulled via mcp__valeri-data__get_hud_data for affordable deals

## Error Handling

| Error Condition | Response | Severity |
|----------------|----------|----------|
| Nuance registry missing or incomplete | STOP -- cannot proceed without classification | Critical |
| Program documentation unavailable from sponsor | Research public records; flag data gap; may require NO-GO | High |
| Jurisdiction rules ambiguous or recently changed | Use most restrictive interpretation; note uncertainty | High |
| Financial impact cannot be quantified (missing data) | Use conservative proxy from comparable programs; flag | Medium |
| Multiple nuances with interacting effects | Model worst-case combined scenario; do not sum independently | Medium |
| Sponsor claims exemption without documentation | Treat as subject to program until proven otherwise | High |

## Worked Example: LIHTC Property with Rent Caps (40% of Units)

**Property**: Oakwood Commons, 200 units, Austin TX
**Nuance**: LIHTC 9% allocation, 40% of units (80 units) restricted at 60% AMI

### Step 2: Regulatory Research
- LIHTC Extended Use Period: 30 years from placed-in-service (2008), expires 2038
- 60% AMI rent cap (Austin 2025): 1BR = $1,134/mo, 2BR = $1,361/mo
- Compliance: Annual income certifications, physical inspections, IRS 8609 filings
- Penalty for non-compliance: Recapture of tax credits, potential loss of exemption

### Step 4: Financial Impact Quantification
| Metric | Restricted (80 units) | If Market Rate | Delta |
|--------|----------------------|----------------|-------|
| Avg Rent/Unit | $1,248/mo | $1,625/mo | ($377/mo) |
| Annual GPR (restricted) | $1,198,080 | $1,560,000 | ($361,920) |
| Compliance costs | $24,000/yr | $0 | ($24,000) |
| **Annual NOI Impact** | | | **($385,920)** |

Cap rate adjustment: +25 bps for LIHTC complexity
- Market value at 5.00% cap: $48.0M
- Restricted value at 5.25% cap: $44.0M
- **Value discount: ($4.0M) or -8.3%**

### Step 5: Go/No-Go
| Criterion | Status | Notes |
|-----------|--------|-------|
| DSCR at restricted rents | Pass | 1.18x stabilized at restricted NOI |
| LTV at restricted value | Pass | 68.2% at $44.0M value |
| Sponsor LIHTC experience | Pass | 3 prior LIHTC properties, clean compliance |
| Exit pathway | Conditional | Must target affordable housing buyers |
| Pricing compensation | Pass | +15 bps spread adequate |

**DETERMINATION: PROCEED WITH CONDITIONS**
- Condition 1: Require annual LIHTC compliance certification
- Condition 2: Reserve $24K/yr for compliance monitoring
- Condition 3: Exit strategy limited to mission-driven buyers -- size accordingly

## Handoff

If PROCEED/CONDITIONAL: Save report, note conditions for IC memo, proceed to Phase 5.
If NO-GO: Save report, notify deal team, document decline rationale, archive deal.
