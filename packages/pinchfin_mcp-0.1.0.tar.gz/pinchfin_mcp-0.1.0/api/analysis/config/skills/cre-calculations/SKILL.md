---
name: cre-calculations
version: 3.0
phase: reference
domain: CRE Financial Mathematics
dependencies: []
inputs:
  - Deal-specific financial data
  - Market data and assumptions
  - Loan terms and structure
outputs:
  - Deterministic calculation results
  - Formula reference for all Valeri phases
credit_box_config: v3.0
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# CRE Calculations Skill -- V3 Enterprise Edition

## Purpose

Definitive reference for ALL commercial real estate financial formulas used across the
Valeri platform. Every calculation in every phase traces back to this skill. All
formulas are deterministic -- show the math, verify the result, never approximate.

### CRITICAL RULES

1. **DETERMINISTIC CALCULATIONS ONLY.** Every formula produces an exact result given
   exact inputs. No "approximately," no rounding mid-calculation.
2. **SHOW YOUR WORK.** Every calculation in every document must display:
   Formula -> Inputs -> Computation -> Result
3. **LENDER INPUTS ONLY.** All formulas use Lender Underwrite figures unless explicitly
   computing a sponsor comparison scenario.
4. **DECIMAL PRECISION PER FORMAT ENFORCER.** DSCR = X.XXx, DY = X.X%, LTV = XX.X%,
   Cap Rate = X.XX%, Interest Rate = X.XX%.
5. **VELETA CONSTRAINT THRESHOLDS** come from credit_box_config.json v3.0. This skill
   provides formulas; the config provides thresholds.

## Inputs

| Input | Source | Required |
|---|---|---|
| Financial data | Deal documents, T-12, rent roll | Per formula |
| Loan terms | Term sheet, deal structure | Per formula |
| Market data | Comps, market research | Per formula |
| Constraint thresholds | credit_box_config.json v3.0 | For sizing formulas |

## 1. INCOME CALCULATIONS

### Gross Potential Rent (GPR)

```
GPR = Total_Units x Average_Monthly_Rent x 12
```

**Example:** 200 units x $1,450/mo x 12 = $3,480,000

### Vacancy & Credit Loss

```
Vacancy_Loss = GPR x Vacancy_Rate
```

**Example:** $3,480,000 x 6% = $208,800

Standard vacancy assumptions:
- Stabilized multifamily: 5-7%
- Lease-up / value-add: 8-15% (declining to stabilized)
- Never underwrite below 5% without exceptional justification

### Effective Gross Income (EGI)

```
EGI = GPR - Vacancy_Loss + Other_Income
```

Other Income includes: parking, laundry, pet fees, RUBS, late fees, application fees.

**Example:** $3,480,000 - $208,800 + $180,000 = $3,451,200

### Net Operating Income (NOI)

```
NOI = EGI - Operating_Expenses
```

**INCLUDES:** Property taxes, insurance, utilities, management fee, repairs & maintenance,
payroll, admin, contract services, marketing, replacement reserves.

**EXCLUDES:** Debt service, capital expenditures, depreciation, income taxes, owner draws.

**Example:** $3,451,200 - $1,656,576 = $1,794,624

### Operating Expense Ratio

```
OpEx_Ratio = Operating_Expenses / EGI
```

**Example:** $1,656,576 / $3,451,200 = 48.0%

Typical ranges:
- Class A multifamily: 35-42%
- Class B multifamily: 40-48%
- Class C multifamily: 45-55%
- Full-service (older): 50-60%

### NOI Margin

```
NOI_Margin = NOI / EGI = 1 - OpEx_Ratio
```

**Example:** $1,794,624 / $3,451,200 = 52.0%

## 2. DEBT SERVICE CALCULATIONS

### Interest-Only Debt Service

```
Annual_DS_IO = Loan_Amount x Interest_Rate
Monthly_DS_IO = Loan_Amount x Interest_Rate / 12
```

**Example:** $21,000,000 x 7.30% = $1,533,000/year = $127,750/month

### Amortizing Debt Service

```
Monthly_Payment = Loan x (r x (1+r)^n) / ((1+r)^n - 1)
  where: r = monthly rate (annual / 12), n = total months

Annual_DS = Monthly_Payment x 12
```

**Example:** $21M at 7.30%, 30-year amortization:
```
r = 0.073 / 12 = 0.006083
n = 360
Monthly = $21,000,000 x (0.006083 x 1.006083^360) / (1.006083^360 - 1)
Monthly = $21,000,000 x 0.006855 = $143,955
Annual = $143,955 x 12 = $1,727,460
```

Excel: `=PMT(0.073/12, 360, -21000000) * 12`

### Debt Constant (Mortgage Constant)

```
Debt_Constant = Annual_Debt_Service / Loan_Amount
```

**IO Example:** $1,533,000 / $21,000,000 = 7.30% (equals the interest rate for IO)
**Amort Example:** $1,727,460 / $21,000,000 = 8.23%

### Loan Constants Reference Table

| Rate | IO | 25-Year Amort | 30-Year Amort |
|---|---|---|---|
| 6.00% | 6.00% | 7.73% | 7.20% |
| 6.50% | 6.50% | 8.13% | 7.59% |
| 7.00% | 7.00% | 8.53% | 7.99% |
| 7.30% | 7.30% | 8.77% | 8.23% |
| 7.50% | 7.50% | 8.94% | 8.39% |
| 8.00% | 8.00% | 9.36% | 8.81% |
| 8.50% | 8.50% | 9.78% | 9.23% |

## 3. CREDIT METRICS

### Debt Service Coverage Ratio (DSCR)

```
DSCR = NOI / Annual_Debt_Service
```

**IO Example:** $1,794,624 / $1,533,000 = 1.17x
**Amort Example:** $1,794,624 / $1,727,460 = 1.04x

**Sizing (solve for max loan at target DSCR):**
```
Max_Annual_DS = NOI / Target_DSCR
Max_Loan_IO = Max_Annual_DS / Interest_Rate
Max_Loan_Amort = Max_Annual_DS / Mortgage_Constant
```

**Example (IO, 1.05x floor):**
$1,794,624 / 1.05 = $1,709,166 max DS
$1,709,166 / 0.073 = $23,413,233 max loan

Platform threshold: >= 1.05x stabilized (credit_box_config.json).
Y1 DSCR is analytical only -- not a sizing constraint.

### Debt Yield (DY)

```
DY = NOI / Loan_Amount
```

**Example:** $1,794,624 / $21,000,000 = 8.5%

**Sizing (solve for max loan at target DY):**
```
Max_Loan = NOI / Target_DY
```

**Example (7.00% floor):** $1,794,624 / 0.07 = $25,637,486

Platform threshold: >= 7.00% stabilized (credit_box_config.json).
Y1 DY is analytical only -- not a sizing constraint.

### Loan-to-Value (LTV)

```
LTV = Loan_Amount / Property_Value
```

**Example:** $21,000,000 / $35,000,000 = 60.0%

**Sizing:**
```
Max_Loan = Property_Value x Max_LTV
```

**Example (As-Is, 75%):** $32,000,000 x 0.75 = $24,000,000
**Example (Stab, 75%):** $35,000,000 x 0.75 = $26,250,000

### Loan-to-Cost (LTC)

```
LTC = Loan_Amount / Total_Cost
Total_Cost = Purchase_Price + CapEx + Closing_Costs + Reserves
```

**Example:**
```
Purchase: $27,000,000
CapEx:     $2,500,000
Closing:     $675,000
Reserves:    $325,000
Total Cost: $30,500,000

LTC = $21,000,000 / $30,500,000 = 68.9%
```

**Sizing:** Max_Loan = Total_Cost x 0.80 = $24,400,000

### Break-Even Occupancy

```
BEO = (Operating_Expenses + Annual_Debt_Service) / GPR
```

**Example:**
```
OpEx: $1,656,576
DS:   $1,533,000
GPR:  $3,480,000

BEO = ($1,656,576 + $1,533,000) / $3,480,000 = 91.6%
```

Target: <= 85%. Above 90% is a red flag.

## 4. VALUATION

### Direct Capitalization

```
Value = NOI / Cap_Rate
Cap_Rate = NOI / Value
```

**Example:** $1,794,624 / 5.25% = $34,183,314

### Price Per Unit

```
PPU = Value / Units
```

**Example:** $34,183,314 / 200 = $170,917/unit

### Price Per SF

```
PSF = Value / Rentable_SF
```

**Example:** $34,183,314 / 180,000 SF = $189.91/SF

### Gross Rent Multiplier (GRM)

```
GRM = Value / Gross_Annual_Rent
```

**Example:** $34,183,314 / $3,480,000 = 9.82x

## 5. LOAN SIZING -- 6-CONSTRAINT WATERFALL

The binding constraint is the MINIMUM of all 5 maximum loan amounts.

```python
# From credit_box_config.json v3.0:
max_ltc = 0.80
max_ltv_as_is = 0.75
max_ltv_stab = 0.75
min_dscr_stab = 1.05  # hard floor
min_dy_stab = 0.07    # hard floor

# Calculate each constraint:
max_loan_ltc = total_cost * max_ltc
max_loan_ltv_as_is = value_as_is * max_ltv_as_is
max_loan_ltv_stab = value_stab * max_ltv_stab
max_loan_dscr = (noi_stab / min_dscr_stab) / interest_rate  # IO
max_loan_dy = noi_stab / min_dy_stab

# Binding constraint = MINIMUM:
binding = min(max_loan_ltc, max_loan_ltv_as_is, max_loan_ltv_stab,
              max_loan_dscr, max_loan_dy)
```

**Worked Example:**
```
Total Cost:    $30,500,000
Value As-Is:   $32,000,000
Value Stab:    $34,183,000
NOI Stab:      $1,794,624
Rate (IO):     7.30%

LTC:           $30,500,000 x 0.80      = $24,400,000
LTV As-Is:     $32,000,000 x 0.75      = $24,000,000
LTV Stab:      $34,183,000 x 0.75      = $25,637,250
DSCR Stab:     $1,794,624 / 1.05 / 0.073 = $23,413,233
DY Stab:       $1,794,624 / 0.07        = $25,637,486

BINDING: DSCR (Stabilized) at $23,413,233
```

### Analytical Outputs (NOT in MIN function)

```
DSCR_Y1 = NOI_Y1 / Annual_DS  -> reported, not a constraint
DY_Y1 = NOI_Y1 / Loan_Amount  -> reported, not a constraint
```

## 6. RETURN METRICS

### Unlevered IRR (Whole Loan)

```python
# Cash flows:
T0: -Loan_Amount + Origination_Fee
T1 to T(n-1): +Monthly_Interest
Tn: +Monthly_Interest + Principal_Return + Exit_Fee

IRR_monthly = solve for r where NPV = 0
IRR_annual = (1 + IRR_monthly)^12 - 1
```

### Levered IRR (With Warehouse)

```python
Equity = Loan_Amount * 0.25  # 75% warehouse advance
Monthly_Net = (Loan_Amount * Loan_Rate / 12) - (Loan_Amount * 0.75 * WH_Rate / 12)

T0: -Equity + Origination_Fee
T1 to T(n-1): +Monthly_Net
Tn: +Monthly_Net + Equity + Exit_Fee

IRR_monthly = solve for r where NPV = 0
IRR_annual = (1 + IRR_monthly)^12 - 1
```

### MOIC (Multiple on Invested Capital)

```
MOIC = Total_Proceeds / Total_Investment
```

**Unlevered:** (Principal + Interest + Fees) / Loan_Amount
**Levered:** (Equity_Return + Net_Interest + Fees) / Equity_Investment

### Cash-on-Cash Return (Levered)

```
CoC = Annual_Net_Interest / Equity_Investment
```

**Example:**
```
Loan: $21,000,000 at 7.30%
Warehouse: $15,750,000 at 6.05%
Equity: $5,250,000

Annual Interest: $21,000,000 x 7.30% = $1,533,000
Annual WH Cost:  $15,750,000 x 6.05% = $952,875
Net Interest:    $1,533,000 - $952,875 = $580,125
CoC:             $580,125 / $5,250,000 = 11.05%
```

## 7. GROWTH & PROJECTION

### Compound Annual Growth Rate (CAGR)

```
CAGR = (Ending_Value / Beginning_Value)^(1/n) - 1
```

**Example:** Rent grew from $1,200 to $1,450 over 4 years:
($1,450 / $1,200)^(1/4) - 1 = 4.85%

### Rent Growth Projection

```
Year_N_Rent = Year_0_Rent x (1 + Annual_Growth)^N
```

**Example:** $1,450 at 3% growth:
Year 1: $1,450 x 1.03 = $1,493.50
Year 2: $1,450 x 1.03^2 = $1,538.31
Year 3: $1,450 x 1.03^3 = $1,584.46

### Stabilization Timeline

```
Months_to_Stabilize = Vacant_Units / Monthly_Absorption_Rate
```

**Example:** 26 vacant units / 4 units per month = 6.5 months

## 8. EXPENSE CALCULATIONS

### Management Fee

```
Management_Fee = EGI x Management_Rate
```

Typical: 3-5% of EGI. Higher for smaller properties.

**Example:** $3,451,200 x 4% = $138,048

### Replacement Reserves

```
Annual_Reserves = Units x Reserve_Per_Unit
```

Typical: $250-$500/unit/year.

**Example:** 200 units x $300/unit = $60,000

### Tax Reassessment Estimate

```
New_Taxes = New_Assessed_Value x Mill_Rate / 1000
```

Always reassess to purchase price on acquisitions. Check local rules.

## 9. TRANSACTION COSTS

### Standard Acquisition Costs

| Item | Typical Range |
|---|---|
| Title Insurance | 0.10-0.30% |
| Legal (buyer) | $15,000-$50,000 |
| Due Diligence (PCA, ESA, survey) | $15,000-$40,000 |
| Appraisal | $3,000-$8,000 |
| Lender Origination | 0.50-1.50% |
| Rate Cap Premium | 0.10-0.75% of loan |
| Total Closing | 1.5-3.0% of purchase |

### Standard Disposition Costs

| Item | Typical Range |
|---|---|
| Brokerage Commission | 1.0-3.0% |
| Transfer Taxes | Varies by state |
| Legal (seller) | $10,000-$25,000 |
| Loan Prepayment/Exit Fee | 0.25-1.00% |
| Total Disposition | 2.0-4.0% of sale |

## 10. STRESS TESTING

### Standard Stress Scenarios

| Scenario | Rate | Vacancy | Cap Rate |
|---|---|---|---|
| Base Case | Actual | UW assumption | Market |
| Moderate Stress | +100 bps | +5% | +25 bps |
| Severe Stress | +200 bps | +10% | +50 bps |
| Downside | +300 bps | +15% | +100 bps |

### Interest Rate Stress (DSCR Impact)

```
Stressed_Rate = Base_Rate + Stress_BPS
Stressed_DS = Loan_Amount x Stressed_Rate  (IO)
Stressed_DSCR = NOI / Stressed_DS
```

**Example:**
```
Base: $21M x 7.30% = $1,533,000 DS -> DSCR 1.17x
+100: $21M x 8.30% = $1,743,000 DS -> DSCR 1.03x
+200: $21M x 9.30% = $1,953,000 DS -> DSCR 0.92x (RED)
```

## 11. PYTHON REFERENCE

```python
import numpy_financial as npf

# Debt Service (annual, amortizing)
annual_ds = npf.pmt(rate/12, years*12, -loan_amount) * 12

# Debt Service (IO)
annual_ds_io = loan_amount * rate

# IRR
irr_monthly = npf.irr(monthly_cash_flows)
irr_annual = (1 + irr_monthly) ** 12 - 1

# NPV
npv = npf.npv(monthly_rate, cash_flows)

# Loan constant
def loan_constant(rate, years):
    r = rate / 12
    n = years * 12
    return (r * (1 + r)**n) / ((1 + r)**n - 1) * 12

# DSCR sizing (IO)
def max_loan_dscr_io(noi, min_dscr, rate):
    return (noi / min_dscr) / rate

# DY sizing
def max_loan_dy(noi, min_dy):
    return noi / min_dy

# 6-constraint waterfall
def size_loan(noi_stab, value_as_is, value_stab, total_cost, rate):
    from credit_box_config import CONSTRAINTS  # v3.0
    loans = {
        'LTC': total_cost * 0.80,
        'LTV_AsIs': value_as_is * 0.75,
        'LTV_Stab': value_stab * 0.75,
        'DSCR_Stab': (noi_stab / 1.05) / rate,
        'DY_Stab': noi_stab / 0.07,
    }
    binding = min(loans, key=loans.get)
    return loans[binding], binding, loans
```

## 12. EXCEL FORMULA CHEAT SHEET

```excel
=PMT(rate/12, years*12, -loan)              ' Monthly payment
=PMT(rate/12, years*12, -loan)*12           ' Annual debt service
=noi/(PMT(rate/12, years*12, -1)*12)        ' Max loan from DSCR
=noi/target_dy                               ' Max loan from DY
=value*max_ltv                               ' Max loan from LTV
=noi/cap_rate                                ' Property value
=IRR(cash_flow_range)                        ' IRR (periodic)
=(1+IRR(monthly_range))^12-1                 ' IRR (annualized from monthly)
=NPV(rate, cash_flows)+initial               ' NPV
=(ending/beginning)^(1/years)-1              ' CAGR
=(opex+ds)/gpr                               ' Break-even occupancy
```

## Quality Gates

- [ ] All formulas produce deterministic results
- [ ] Every worked example shows: formula, inputs, computation, result
- [ ] Constraint thresholds reference credit_box_config.json v3.0
- [ ] Y1 metrics flagged as analytical only (not sizing constraints)
- [ ] IO and amortizing variants shown for DS and DSCR
- [ ] Number formatting matches Format Enforcer standards

## Error Handling

| Error Condition | Detection | Resolution |
|---|---|---|
| Division by zero | Cap rate = 0, rate = 0, DY target = 0 | BLOCK: Input error. Cannot compute with zero denominator. |
| Negative NOI | EGI < OpEx | FLAG: Property operating at a loss. Cannot value via cap rate. Use cost approach. |
| DSCR < 0 | Negative NOI with positive DS | Report as negative DSCR. Property cannot service any debt. |
| IRR does not converge | Non-standard cash flow pattern | Use XIRR with explicit dates or bisection method. |
| LTC > 100% | Loan exceeds total cost | ERROR: Check total cost calculation. Missing components? |
| BEO > 100% | DS + OpEx > GPR | CRITICAL: Property cannot break even at any occupancy. Decline. |
| Rounding error accumulation | Multi-step calculation drift | Carry full precision through intermediate steps. Round only final output. |

## Version History

| Version | Date | Changes |
|---|---|---|
| 1.0 | Dec 2024 | Initial reference with basic formulas |
| 2.0 | Dec 2025 | Added 6-constraint waterfall, transitional lending updates |
| 3.0 | Feb 2026 | V3 Enterprise: Full frontmatter, all formulas with worked examples, Python + Excel references, 6-constraint waterfall with credit_box_config reference, stress testing parameters, error handling, IO vs. amort variants throughout |
