---
name: expense-underwriting
version: 3.0
phase: 7 — Expense Assumption Development
domain: financial-analysis
dependencies:
  - rent-roll-analysis (Phase 5 — revenue baseline)
  - market-submarket (Phase 3 — market context for benchmarks)
inputs:
  - input: T-12 operating statement
    source: Sponsor / PM Company
    required: true
  - input: Property details (units, vintage, class, location)
    source: OM / Phase 1
    required: true
  - input: Market analysis output
    source: Phase 3
    required: true
  - input: Property tax bill
    source: Sponsor / County records
    required: false
  - input: Insurance declarations page
    source: Sponsor / Broker
    required: false
outputs:
  - output: Expense assumptions integrated into T12_Expense_Analysis.docx
    format: V3.1 Elevated DOCX (combined with T-12 analysis)
  - output: phase_07_expenses.json
    format: JSON workflow state
credit_box_config: v3.0
mcp_tools:
  - mcp__valeri-data__get_property_context
  - mcp__valeri-data__get_flood_zone
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# Expense Underwriting (Phase 7)

## Purpose

Expense underwriting develops supportable, market-benchmarked operating expense assumptions for the lender pro forma. This skill works in tandem with the T-12 analysis (Phase 6) — the T-12 provides the historical baseline, and expense underwriting validates each line item against market benchmarks and property-specific factors.

The goal is to ensure the lender's expense assumptions are neither too low (which inflates NOI and oversizes the loan) nor unnecessarily punitive (which kills viable deals). Every line item must be defensible to an IC or external credit reviewer with reference to either the T-12 actual, a market benchmark, or a property-specific adjustment.

CRITICAL RULES: Per-unit expense floors are hard minimums — the lender never underwrites below these without written justification. For sub-stabilized properties (<90% occupancy), variable expenses must be normalized to stabilized occupancy levels. Self-managed properties must have a 3.5-4.0% management fee loaded regardless of the T-12 showing zero. Insurance in disaster-prone markets (FL, Gulf Coast, CA wildfire) must be stress-tested at 150% of current cost.

## Inputs

| Input | Source | Required |
|-------|--------|----------|
| T-12 operating statement | Sponsor / PM | Yes |
| Property vintage, class, unit count | OM | Yes |
| Property location (state, county, flood zone) | OM / Phase 2 | Yes |
| Market analysis (expense benchmarks, insurance conditions) | Phase 3 | Yes |
| Property tax bill (current year) | Sponsor / County | No |
| Insurance declarations page | Sponsor / Broker | No |
| Flood zone status | mcp__valeri-data__get_flood_zone | Yes |
| Purchase price (for tax reassessment) | OM / Term Sheet | Yes (acquisitions) |

## Methodology

### Step 1: Establish Per-Unit Expense Floors

These are the minimum acceptable expense assumptions by category. The lender NEVER underwrites below these without explicit written justification.

| Category | Floor ($/Unit/Year) | Adjustment Factors |
|----------|--------------------|--------------------|
| Real Estate Taxes | Market-specific | Reassess on acquisition; jurisdiction-specific mill rate |
| Insurance | $400 | FL/Gulf: $800; CA wildfire: $700; SFHA flood zone: add $200 |
| Utilities | $800 | Master-metered: $1,200+; tenant-paid electric: $600 |
| Repairs & Maintenance | $500 | Pre-1990 vintage: $700; pre-1980: $900 |
| Contract Services | $300 | Elevator buildings: $500+; large landscaping: $400+ |
| Payroll & Benefits | $800 | <100 units: $1,200+ (less efficient staffing); 300+ units: $700 |
| Marketing | $100 | Lease-up: $300; stabilized Class A: $150 |
| Administrative / G&A | $150 | — |
| Management Fee | 3.5% of EGI | Self-managed: 4.0%; institutional PM: 3.0% acceptable |
| Replacement Reserves | $250 | 20+ year vintage: $300; 30+ year: $350 |

### Step 2: T-12 Baseline Extraction (Per-Unit)

Convert every T-12 expense line to a per-unit annual figure:

```
T-12 $/Unit = T-12 Annual Expense / Total Units

Example:
  T-12 Insurance: $120,000
  Total Units: 200
  T-12 $/Unit: $120,000 / 200 = $600/unit
```

### Step 3: Occupancy-Adjusted Normalization for Sub-Stabilized Properties

When the T-12 reflects sub-stabilized occupancy (<90%), certain variable expenses are artificially depressed. They must be adjusted upward.

**Variable expenses (scale with occupancy):**
- Utilities (tenant-occupied portion — typically 60-70% of total utility cost is variable)
- Repairs & Maintenance (more units occupied = more service requests)
- Turnover costs (embedded in R&M)
- Trash removal

**Formula:**
```
Normalized Variable Expense = T-12 Variable Expense x (Stabilized Occ / Average T-12 Occ)

Example at 75% average occupancy, targeting 95% stabilized:
  T-12 Utilities (variable portion): $135,000
  Adjustment factor: 0.95 / 0.75 = 1.267
  Normalized: $135,000 x 1.267 = $171,000

  T-12 Utilities (fixed portion — common area): $45,000
  No adjustment needed

  Total Normalized Utilities: $171,000 + $45,000 = $216,000
```

**Fixed expenses — do NOT adjust for occupancy:**
- Real Estate Taxes
- Insurance
- Payroll (minimum staffing required regardless of occupancy)
- Most Contract Services (landscaping, pest control are fixed)
- Management Fee — recalculate as % of STABILIZED EGI, not sub-stabilized

### Step 4: Line-by-Line Underwriting

**4a. Real Estate Taxes**
```
IF acquisition:
  Reassessed Tax = Purchase Price x Assessment Ratio x Mill Rate
  Lender Tax = MAX(Current Tax, Reassessed Tax)

IF refinance (no recent sale):
  Lender Tax = T-12 Tax x (1 + Annual Assessment Growth)
  Typical growth: 2-5% annually depending on jurisdiction

Jurisdiction-specific notes:
  - Texas: No state income tax; property taxes are HIGH ($2,000-$3,500/unit typical)
  - Florida: Save-Our-Homes cap for homestead only; commercial reassesses on sale
  - California: Prop 13 limits to 2% annual increase until sale triggers reassessment
  - New York: Complex assessed-to-market-value ratio; use actual tax bill
```

**4b. Insurance**
```
Lender Insurance = MAX(T-12 Insurance, Floor from Step 1)

Apply stress multiplier for disaster-prone markets:
  Florida / Gulf Coast: 1.5x current (hurricane risk, reinsurance costs)
  California wildfire zones: 1.3x current
  SFHA flood zone (A, AE, V, VE): Add flood insurance at $200/unit/year minimum

Growth rate assumption:
  Standard markets: 5% annual
  FL/Gulf/CA: 10% annual (insurance crisis markets)
```

**4c. Utilities**
```
Metering matters:
  - Master-metered (owner pays all): $1,200-$1,600/unit
  - Sub-metered or RUBS: $800-$1,200/unit (partial reimbursement)
  - Tenant-paid electric: $500-$800/unit (owner pays water/sewer/common)

Lender Utility = MAX(T-12 Utility [occupancy-adjusted], Floor)
```

**4d. Repairs & Maintenance**
```
Vintage adjustment:
  2010+:      $500-$700/unit (newer systems, warranty coverage)
  2000-2009:  $650-$850/unit
  1990-1999:  $750-$1,000/unit (aging HVAC, plumbing, roofing)
  Pre-1990:   $900-$1,200/unit (expect major system replacements)

Lender R&M = MAX(T-12 R&M [occupancy-adjusted], Vintage-based floor)
```

**4e. Management Fee**
```
Lender Mgmt Fee = MAX(T-12 Mgmt Fee %, 3.5%) x Lender EGI

Special cases:
  Self-managed / owner as PM: Use 4.0% (must load third-party cost)
  Institutional PM with contract: Use contract rate if 3.0%+ (acceptable)
  PM entity is sponsor affiliate: Use 3.5% minimum (related-party risk)
```

**4f. Replacement Reserves**
```
Lender Reserves = MAX(T-12 Reserves, Vintage-based floor)

  Vintage 2010+:   $250/unit/year
  Vintage 2000-09: $275/unit/year
  Vintage 1990-99: $300/unit/year
  Pre-1990:        $350/unit/year

Note: Reserves are BELOW the line (after OpEx, before NOI).
If sponsor has a funded CapEx reserve at closing, this does not reduce annual reserves.
```

### Step 5: Expense Ratio Reasonableness Check

After all adjustments, verify the total expense ratio is within reasonable bounds:

```
Expense Ratio = Total OpEx / EGI

Typical ranges by property class:
  Class A (2015+):     35-42% of EGI
  Class B (1990-2014): 42-50% of EGI
  Class C (pre-1990):  48-58% of EGI

IF Lender Expense Ratio < Class floor:
  FLAG: "Expense ratio below typical range — verify all line items are loaded"

IF Lender Expense Ratio > Class ceiling:
  Investigate which line item is driving elevated ratio
  May be acceptable if justified (high-tax jurisdiction, older property)
```

### Step 6: Sponsor vs. Lender Comparison

Build a side-by-side comparison of sponsor and lender expense assumptions:

| Category | T-12 $/Unit | Sponsor UW $/Unit | Lender UW $/Unit | Variance | Notes |
|----------|-----------|-------------------|-------------------|----------|-------|
| Taxes | | | | | |
| Insurance | | | | | |
| Utilities | | | | | |
| R&M | | | | | |
| Contract | | | | | |
| Payroll | | | | | |
| Marketing | | | | | |
| Admin | | | | | |
| Mgmt Fee | | | | | |
| Reserves | | | | | |
| **Total** | | | | | |

## Outputs

Expense underwriting output is integrated into the T12_Expense_Analysis.docx (Document 5 of 8). The JSON state includes:

```json
{
  "phase": "07_expenses",
  "total_opex_lender": 0,
  "opex_per_unit": 0,
  "expense_ratio": 0.0,
  "mgmt_fee_pct": 0.035,
  "reserves_per_unit": 250,
  "insurance_per_unit": 0,
  "tax_per_unit": 0,
  "occupancy_adjustment_applied": false,
  "adjustments": []
}
```

## Quality Gates

- [ ] Every expense category has a per-unit figure benchmarked against market
- [ ] No line item below the established floor without written justification
- [ ] Management fee at minimum 3.5% of EGI (4.0% if self-managed)
- [ ] Reserves at minimum $250/unit (higher for older vintage)
- [ ] Tax reassessment calculated for acquisitions
- [ ] Insurance stress-tested for disaster-prone markets
- [ ] Occupancy-adjusted normalization applied if average T-12 occupancy <90%
- [ ] Total expense ratio falls within reasonable range for property class
- [ ] Sponsor vs. lender comparison table completed

## Error Handling

| Error | Resolution |
|-------|-----------|
| T-12 expense breakdown not provided (only total OpEx) | Apply market benchmarks per category. Flag as "T-12 detail unavailable — market benchmarks applied." Request detailed statement from PM |
| Property tax bill not provided | Use county assessor website for current assessed value. Apply local mill rate. Flag as "estimated — tax bill not provided" |
| Insurance in FL/Gulf showing below $800/unit | Do not accept at face value. Request insurance declarations page. If policy is expiring soon, quote current market rates. Underwrite at $800 minimum |
| Sponsor shows $0 for reserves | Add reserves per vintage floor. This is non-negotiable — replacement reserves are a lender requirement |
| Self-managed property shows no management fee | Load 4.0% of EGI. Document as "no PM fee in T-12 — self-managed. Lender loads third-party cost at 4.0% of EGI" |
| Utility expenses appear extremely low | Investigate metering structure. If master-metered, $800/unit is the absolute floor. If sub-metered, verify RUBS reimbursement revenue in Other Income |
| Sponsor projects expense REDUCTIONS post-acquisition | Never credit future savings. Use T-12 actual or market benchmark. Exception: signed PM contract at lower fee (use contract rate if 3.0%+) |

## Worked Example

**Subject:** Oakwood Terrace — 200 units, Class B, built 1998, Knox-Henderson, Dallas, TX. Average T-12 occupancy: 88%. Stabilized target: 93%. Purchase price: $38.0M.

**Expense Build-Up:**

| Category | T-12 $/Unit | Sponsor $/Unit | Lender $/Unit | Variance vs. Sponsor | Methodology |
|----------|-----------|---------------|---------------|---------------------|-------------|
| Taxes | $2,060 | $2,200 | $2,500 | +$300 (+13.6%) | Reassessment: $38.0M x 100% ratio x 1.316% mill = $500K |
| Insurance | $480 | $500 | $600 | +$100 (+20.0%) | T-12 at $480 < $600 floor. TX market stable but normalize to mid |
| Utilities | $960 | $1,000 | $1,154 | +$154 (+15.4%) | Occupancy-adjusted: $960 x (0.95/0.88) = $1,036, round up for 1998 vintage |
| R&M | $640 | $650 | $732 | +$82 (+12.6%) | Occupancy-adjusted: $640 x (0.95/0.88) + vintage adj = $732 |
| Contract Svc | $420 | $420 | $420 | $0 (0.0%) | In range — no adjustment needed |
| Payroll | $1,080 | $1,080 | $1,080 | $0 (0.0%) | In range — staffing adequate for 200 units |
| Marketing | $260 | $200 | $200 | $0 (0.0%) | Remove $60 lease-up blitz; $200 normalized |
| Admin/G&A | $220 | $220 | $220 | $0 (0.0%) | In range |
| Mgmt Fee | $475 (3.0%) | $523 (3.5%) | $558 (3.5%) | +$35 (+6.7%) | Normalize to 3.5% of lender EGI (higher EGI base) |
| Reserves | $0 | $250 | $300 | +$50 (+20.0%) | 1998 vintage = $300/unit floor |
| **Total** | **$6,595** | **$7,043** | **$7,764** | **+$721 (+10.2%)** | |

**Expense Ratio:** Lender OpEx ($1,492,718 excl. reserves) / Lender EGI ($3,188,052) = 46.8% — within Class B range of 42-50%.

**Key Findings:**
- Lender total expenses are $721/unit (10.2%) above sponsor assumptions
- Primary drivers: tax reassessment (+$300/unit), insurance normalization (+$100/unit), occupancy-adjusted utilities/R&M (+$236/unit combined)
- All expense lines are within market benchmark ranges after adjustment
- No expense line below the established floor
