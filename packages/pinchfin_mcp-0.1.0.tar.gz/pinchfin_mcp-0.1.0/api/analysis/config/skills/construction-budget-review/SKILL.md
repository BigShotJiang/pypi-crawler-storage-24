---
name: construction-budget-review
version: 3.0
phase: 7
domain: financial-analysis
dependencies: [pca-review, appraisal-review, rent-roll-analysis]
inputs: [construction-budget, gc-contract, cost-consultant-report, construction-schedule, sponsor-track-record]
outputs: [construction-review-report, reserve-recommendations, draw-protocol]
credit_box_config: v3.0
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# Construction & Renovation Budget Review

## Purpose

Conduct institutional-grade review of construction and renovation budgets for bridge loans with significant CapEx components. Validate per-unit and per-SF costs against RSMeans benchmarks, assess GC contract terms and documentation completeness, stress-test schedule and cost overrun scenarios, size holdback and escrow requirements, and establish draw protocols for the loan term.

### CRITICAL RULES
1. ALWAYS benchmark hard costs against RSMeans regional data -- if sponsor budget is >15% above OR below benchmark, investigate (below may indicate underscoping; above may indicate inefficiency)
2. Minimum contingency: 5% of hard costs for light renovation, 10% for heavy renovation, 15% for ground-up -- contingency below these thresholds is DEFICIENT
3. Sponsor equity MUST be first-dollar-in -- lender funds drawn AFTER sponsor equity is fully invested (no co-funding from day one)
4. Retainage: Minimum 10% on all trades until 50% complete, then 5% -- retainage below these levels weakens lender protection
5. IF third-party cost consultant report is not provided for budgets >$2.0M, require one as condition to closing -- sponsor self-estimates are insufficient for institutional lending
6. GC contract MUST be GMP or stipulated sum for lender-funded work -- cost-plus contracts without a cap shift risk entirely to the project and are NOT acceptable without a completion guarantee

## Inputs

| Input | Source | Required |
|-------|--------|----------|
| Detailed construction / renovation budget | Sponsor | Yes |
| GC contract (AIA A102 or equivalent) | Sponsor / GC | Yes (if GC engaged) |
| Third-party cost consultant report | Cost consultant | Required if budget >$2.0M |
| Construction schedule (Gantt/CPM) | Sponsor / GC | Yes |
| Sponsor construction track record | Sponsor DD | Yes |
| RSMeans / Marshall & Swift data | Industry reference | For benchmarking |
| Insurance certificates (Builder's Risk, GL) | Insurance broker | At closing |
| PCA report (for deferred maintenance alignment) | PCA consultant | Yes |

## Methodology

### Step 1: Budget Structure Validation
Verify the budget is organized by trade or CSI division and includes:
- Hard costs (by trade: demo, framing, plumbing, electrical, HVAC, finishes, etc.)
- Soft costs (A&E, permits, inspections, legal, accounting)
- GC general conditions and overhead
- GC fee (typically 5-10% of hard costs)
- Developer fee (if applicable, typically 3-5%)
- Contingency (see minimum thresholds above)
- Financing costs (interest reserve, origination, legal)
- Operating reserves during construction/lease-up

### Step 2: Per-Unit & Per-SF Cost Benchmarking
Compare to RSMeans and industry data:
- Total renovation cost per unit: Light ($5K-$15K), Medium ($15K-$30K), Heavy ($30K-$60K+)
- Hard cost per SF: Compare to RSMeans regional data by construction type
- Soft cost as percentage of hard cost: Typical 15-25% for renovation, 25-35% for ground-up
- GC fee: Typical 5-10% of hard costs
- Contingency: 5-15% depending on scope complexity

Flag variances >15% from benchmarks for investigation.

### Step 3: Line-Item Reasonableness Assessment
Review individual line items for scope adequacy:
- Are all necessary trades included? (Common omission: fire sprinkler, ADA compliance, abatement)
- Are unit counts and quantities consistent with rent roll / site plan?
- Are material specifications consistent with the intended Class position?
- Are allowances reasonable or suspiciously low?
- Cross-reference PCA immediate repairs -- are they included in the budget?

### Step 4: GC Contract & Documentation Review
Evaluate contract protections:
- Contract form: GMP (preferred) or Stipulated Sum (acceptable) or Cost-Plus (REQUIRES cap)
- Schedule of values: Must be attached and match budget line items
- Retainage terms: Minimum 10% early, 5% later
- Liquidated damages: Present and reasonable (typically $500-$2,000/day)
- Insurance: Builder's Risk, GL, Workers' Comp, Professional Liability
- Performance bond or subcontractor default insurance (SDI)
- Payment bond (protects against mechanic's liens)
- Change order process: Written approval required, lender consent for changes >$X

### Step 5: Schedule Assessment & Stress Testing
Evaluate construction timeline:
- Total duration vs. comparable projects (is it aggressive or reasonable?)
- Critical path milestones identified
- Float in schedule (buffer for delays)
- Seasonal considerations (winter weather, hurricane season)

Stress test 3 scenarios:
| Scenario | Delay | Additional Interest Carry | Contingency Impact |
|----------|-------|--------------------------|-------------------|
| Base case | On time | $0 | Contingency intact |
| 3-month delay | +3 months | Additional carrying cost at loan rate | Partial contingency draw |
| 6-month delay | +6 months | Additional carrying cost | Contingency may be exhausted |

### Step 6: Cost Overrun Analysis
Model overrun scenarios:
- 5% hard cost overrun: Covered by contingency? Yes/No
- 10% hard cost overrun: Source of additional funds? (Sponsor equity call, completion guarantee)
- Contingency exhaustion: What triggers the completion guarantee?
- Material price escalation risk: Are major trades contracted or subject to market pricing?

### Step 7: Draw Protocol Design
Establish monitoring and disbursement framework:
- Draw frequency: Monthly (standard)
- Minimum draw amount: Typically $25K-$50K
- Required documentation per draw: AIA G702/G703, conditional lien waivers (unconditional for prior draws), progress photos, schedule update
- Third-party inspector required for each draw
- Title bringdown at each draw (confirm no mechanic's liens)
- Retainage release: Upon substantial completion and final lien waiver period
- Cost-to-complete test: Required after 50% disbursement

### Step 8: Holdback Sizing
Determine lender holdback structure:
- Construction holdback: Total budget amount held in escrow, released per draw protocol
- Contingency holdback: Held separately, released only for documented cost overruns
- Completion holdback: Final 10% released upon TCO/CO and final inspections
- Interest reserve: Sized for full construction period plus cushion

## Outputs

| Output | Format | Destination |
|--------|--------|-------------|
| Construction Review Report | DOCX via valeri_report_v3.py | Deal outputs folder |
| Reserve & Holdback Recommendations | Dollar amounts by category | Loan sizing S&U |
| Draw Protocol | Terms and conditions | Term sheet / loan agreement |

## Quality Gates

- [ ] Budget organized by trade/CSI division with complete line items
- [ ] Per-unit and per-SF costs benchmarked against RSMeans regional data
- [ ] Variances >15% from benchmarks investigated and explained
- [ ] GC contract reviewed (form, retainage, LD, insurance, bonds)
- [ ] Third-party cost consultant report obtained (if budget >$2.0M)
- [ ] Construction schedule assessed for realism and float
- [ ] Delay and cost overrun scenarios stress-tested
- [ ] Draw protocol established with documentation requirements
- [ ] Holdback structure sized (construction, contingency, completion, interest)
- [ ] PCA immediate repairs cross-referenced to budget
- [ ] Sponsor construction experience documented

## Error Handling

| Error Condition | Response | Severity |
|----------------|----------|----------|
| No third-party cost report for budget >$2.0M | Require cost consultant report as condition to closing | High |
| Contingency below minimum threshold (5-15%) | Require sponsor to increase contingency or provide additional equity | High |
| GC contract is cost-plus without cap | Require GMP amendment or completion guarantee | Critical |
| Sponsor equity not first-dollar-in | Restructure funding sequence; lender cannot fund ahead of sponsor | Critical |
| Budget omits trades identified in PCA (fire sprinkler, ADA) | Flag gaps; require budget revision to include all PCA items | High |
| Schedule shows no float (every milestone on critical path) | Flag as aggressive; recommend 10-15% schedule buffer | Medium |
| No liquidated damages in GC contract | Require LD provision or enhanced completion guarantee | Medium |

## Worked Example

**Property**: Ridgewood Manor, 150 units, Charlotte NC
**Scope**: Medium renovation -- $15K/unit interior + $500K common area/exterior
**Total Budget**: $2,750,000
**GC**: Southeastern Builders Inc., AIA A102 GMP
**Timeline**: 18 months

### Step 1: Budget Structure
| Category | Amount | % of Total | $/Unit |
|----------|--------|------------|--------|
| Hard Costs - Interior (150 units) | $1,875,000 | 68.2% | $12,500 |
| Hard Costs - Common Area/Exterior | $500,000 | 18.2% | $3,333 |
| GC General Conditions | $118,750 | 4.3% | $792 |
| GC Fee (5% of hard costs) | $118,750 | 4.3% | $792 |
| Contingency (7.5% of hard costs) | $178,125 | 6.5% | $1,188 |
| Soft Costs (A&E, permits) | $85,000 | 3.1% | $567 |
| **Total** | **$2,875,625** | **104.6%** | **$19,171** |

Note: Sponsor budget of $2,750,000 does not include GC fee separately -- it is embedded in line items. Lender-adjusted total with explicit GC fee: $2,875,625. Discrepancy: $125,625 (4.6%). Sponsor must clarify.

### Step 2: Cost Benchmarking
| Item | Budget | RSMeans (SE Region) | Variance |
|------|--------|---------------------|----------|
| Interior renovation $/unit | $12,500 | $13,200 | -5.3% (below) |
| Kitchen package (cabinets, counters, appliances) | $6,500/unit | $7,000/unit | -7.1% |
| Flooring (LVP, full unit) | $2,200/unit | $2,400/unit | -8.3% |
| Bathroom renovation | $2,800/unit | $2,600/unit | +7.7% |
| Common area/exterior $/unit | $3,333/unit | $3,000/unit | +11.1% |

All variances within 15% threshold -- ACCEPTABLE. Interior costs are slightly below benchmark, suggesting efficient scope but not underscoped (confirmed by itemized SOV).

### Step 3: PCA Cross-Reference
| PCA Item | PCA Cost | In Budget? | Notes |
|----------|----------|------------|-------|
| Fire alarm panel upgrade | $18,000 | Yes | Included in common area line |
| Parking lot seal coat | $22,000 | Yes | Included in exterior line |
| Roof repairs (flashing) | $8,500 | No | MISSING -- must add |
| ADA ramp upgrade | $6,000 | No | MISSING -- must add |

**Gap identified**: $14,500 in PCA items not in sponsor budget. Require budget revision or separate lender holdback.

### Step 4: GC Contract Review
| Element | Status | Acceptable |
|---------|--------|------------|
| Contract form | AIA A102 GMP | Yes |
| Schedule of values | Attached, matches budget | Yes |
| Retainage | 10% to 50%, then 5% | Yes |
| Liquidated damages | $1,000/day after month 18 | Yes |
| Builder's Risk insurance | $3.0M, named insured includes lender | Yes |
| General Liability | $2.0M per occurrence | Yes |
| Performance bond | Waived (SDI in lieu, $2.0M) | Acceptable |
| Change order process | Written, lender consent >$25K | Yes |

Contract terms: ACCEPTABLE. SDI coverage in lieu of performance bond is standard for renovation scope at this budget level.

### Step 5: Schedule Stress Test
| Scenario | Completion | Add'l Interest ($2.75M at 8.50%) | Contingency Status |
|----------|-----------|----------------------------------|-------------------|
| Base (18 months) | July 2027 | $0 | $178K intact |
| +3 months (21 months) | Oct 2027 | $58,438 | $120K remaining |
| +6 months (24 months) | Jan 2028 | $116,875 | $61K remaining |

Schedule has 45 days of float built in. 3-month delay scenario is manageable. 6-month delay would nearly exhaust contingency -- would require sponsor equity call or completion guarantee.

### Step 8: Holdback Sizing
| Holdback | Amount | Release Trigger |
|----------|--------|----------------|
| Construction holdback | $2,375,000 | Per monthly draw protocol |
| Contingency holdback | $178,125 | Documented cost overruns only |
| PCA gap holdback | $14,500 | Upon completion of missing PCA items |
| Completion holdback (10%) | $237,500 | TCO/CO + final lien waiver period |
| Interest reserve (18 months) | $351,563 | Monthly during construction |
| **Total held** | **$3,156,688** | |

**Construction Budget Assessment: ACCEPTABLE** -- Budget is well-organized, costs benchmark within 15% of RSMeans, GC contract terms are adequate, and schedule is reasonable with built-in float. Two PCA items missing from budget ($14,500) require resolution. Contingency at 7.5% exceeds 5% minimum for medium renovation but is below the 10% threshold that would provide more comfort -- acceptable given GMP contract and experienced GC.

**Recommendation: PROCEED WITH CONDITIONS**
1. Sponsor must add $14,500 to budget for missing PCA items (or lender holds separately)
2. Third-party cost consultant report required as condition to closing (budget >$2.0M)
3. Monthly draw inspections by lender-approved inspector
4. Sponsor equity ($625K) funded first before any lender draws

## Handoff

Save report. Update S&U with holdback amounts. Add draw protocol terms to term sheet. Require cost consultant report as CP. Coordinate with PCA review for deferred maintenance alignment. Note construction risk assessment in IC memo.
