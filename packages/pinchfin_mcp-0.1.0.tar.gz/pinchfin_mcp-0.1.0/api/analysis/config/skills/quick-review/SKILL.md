---
name: quick-review
version: 3.0
phase: "QR — Quick Review (10-Phase Screening)"
domain: workflow
description: |
  10-minute deal screening workflow producing a 1-page institutional memo. Run on
  EVERY inbound deal for pipeline triage. 10 phases (QR-0 through QR-9) covering
  intake, data services, market snapshot, comp analysis, rent/expense scan, mini
  cash flow, narrative/risk assessment, memo generation, deal data record, and
  skill chain log. Balances speed with rigor — every number traceable, every
  constraint checked, every risk flagged.
dependencies:
  - skill: deal-data-record
    phase: "QR-8 — generates standardized deal record"
  - skill: skill-chain-audit
    phase: "QR-9 — generates execution audit log"
  - skill: planning-protocol
    phase: "Phase -1 — consumes Planning Brief for scope"
  - skill: credit-box-config
    phase: "QR-5 — constraint thresholds for sizing"
inputs:
  - input: Deal folder with documents
    source: Operator-provided path (OM, rent roll, T-12, broker package)
    required: false
  - input: Operator context (deal description)
    source: Conversational input or Planning Brief
    required: true
  - input: credit_box_config.json
    source: "Valeri/system-docs/credit_box_config.json v4.0"
    required: true
  - input: brand_config.json
    source: "Valeri/brand_config.json"
    required: true
  - input: master_repo data
    source: "Valeri/master_repo/ (markets, comps, expenses)"
    required: false
outputs:
  - output: "[DEAL_NAME]_Quick_Review.docx"
    format: DOCX (Elevated V3.1 design)
  - output: "[DEAL_NAME]_Deal_Record.json"
    format: JSON (machine-readable)
  - output: "[DEAL_NAME]_Deal_Record.md"
    format: Markdown (human-readable)
  - output: "[DEAL_NAME]_QR_Skill_Chain.md"
    format: Markdown (execution audit log)
credit_box_config: v4.0
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# Quick Review — 10-Minute Deal Screening

## Purpose

A fast, lightweight screening pass that can be run on EVERY inbound deal. Produces a 1-page institutional memo with narrative, cash flow snapshot, loan sizing, strengths/weaknesses/risks, DD questions, and needs list. This is NOT full underwriting — it is intelligent triage that identifies the best opportunities and surfaces the right questions for deeper analysis.

### Three Functions
1. **Screening gate** — Run on all pipeline deals to identify the best opportunities fast
2. **Broker response** — Same-day turnaround with intelligent questions and basic feedback
3. **Full UW intake prep** — Establishes accurate baseline data so the full underwrite starts clean

> **CRITICAL RULE:** Quick Review balances speed with rigor. Every number must be traceable to a source, every constraint must be checked against credit_box_config.json, and every risk must be flagged. Use the EXACT SOFR rate from FRED — never round, never assume.

## HARD RULES

1. Quick Review is NOT full underwriting — it is a screening pass
2. Total execution target: approximately 10 minutes
3. Use current SOFR from FRED via `mcp__valeri-data__get_macro_indicators` — do not use stale rates
4. All 6 sizing constraints must be checked — minimum governs (load from credit_box_config.json)
5. DSCR threshold is 1.05x — the ONLY threshold for sizing
6. Save comp and market data to master_repo for compounding intelligence
7. Every run produces: 1-page memo + deal data record + skill chain log (3 mandatory outputs)
8. Elevated design (V3.1) for the DOCX output using `valeri_report_v3.py`
9. VALERI_FORMAT_ENFORCER rules apply to all numeric formatting
10. This is a screening tool — conservative assumptions, flag uncertainties prominently
11. Check master_repo BEFORE running Perplexity research queries
12. Flood zone data must come from FEMA via data services — do not assume from research

## Inputs

| Input | Source | Required |
|-------|--------|----------|
| Deal folder with documents | Operator-provided path | No |
| Operator context / Planning Brief | Conversational input | Yes |
| credit_box_config.json | Valeri/system-docs/ v4.0 | Yes |
| brand_config.json | Valeri/brand_config.json | Yes |
| master_repo (markets, comps, expenses) | Valeri/master_repo/ | No |

## Methodology

### Phase QR-0: INTAKE & OCR

**Objective:** Scan deal folder, classify documents, extract all salient data.

**Actions:**
1. Scan deal folder for all documents (OM, rent roll, T-12, broker package, term sheet, etc.)
2. Classify each document by type
3. Extract all salient data:
   - Property: name, address, units, year built, class, stories, avg SF, total SF, acres
   - Sponsor: entity name, principals, prior experience
   - Loan request: amount, term, rate, IO period, structure
   - Unit mix: types, counts, rents, SF
   - Occupancy: current rate, vacant units
   - Financial: GPR, EGI, expenses, NOI, capex
   - Transaction: purchase price, cost basis, existing debt
4. Flag any OCR/extraction issues immediately

**Output:** `intake_extract.json`

---

### Phase QR-1: DATA SERVICES VERIFICATION

**Objective:** Pull verified government data and cross-check against broker claims.

**Actions:**
1. Run `mcp__valeri-data__get_macro_indicators` — Pull current SOFR, Treasury curve, CPI
2. Run `mcp__valeri-data__get_property_context` with the property address — Pulls:
   - Census/ACS demographics (population, median income, poverty rate)
   - BLS employment data (unemployment, labor force)
   - FEMA flood zone
   - Walk Score / Transit Score / Bike Score
   - EPA environmental flags
   - HUD Fair Market Rents
3. Cross-check broker-provided data against API data
4. Flag discrepancies between broker claims and verified data

**Output:** `data_services_verification.json`

**CRITICAL:** Use the EXACT SOFR rate returned from FRED. Do not round. Do not use an old assumption.

---

### Phase QR-2: QUICK MARKET SNAPSHOT

**Objective:** 1-paragraph market narrative with key fundamentals.

**Actions:**
1. Check `master_repo/markets/` for existing market report (within 60 days)
   - If exists: load as baseline, supplement only
   - If not: proceed with fresh research
2. Run 2-3 Perplexity queries:
   - `[MSA] multifamily market fundamentals population employment`
   - `[SUBMARKET] apartment vacancy rent growth trends`
   - `[MSA] multifamily construction pipeline new supply`
3. Synthesize into 1-paragraph market narrative covering:
   - Population growth trajectory
   - Employment drivers and job growth
   - Rent trends and vacancy
   - Supply pipeline (new construction threat)
4. Save new market data to master_repo if > 60 days stale

**Output:** `market_snapshot.json`

---

### Phase QR-3: QUICK COMP ANALYSIS

**Objective:** Establish preliminary lender underwritten rent from comps.

**Actions:**
1. Check `master_repo/comps/` for existing comp records in this market
   - If exists: load as starting set, supplement with new research
   - If not: proceed with fresh research
2. Run 2-3 Perplexity queries:
   - `[SUBMARKET] Class [B/C] apartment rent comps`
   - `[PROPERTY ADDRESS] comparable apartments nearby`
   - `[MSA] multifamily sales transactions cap rates`
3. Identify:
   - 3-5 rent comps (name, units, year built, avg rent, rent/SF)
   - 2-3 sale comps (name, sale date, price, price/unit, cap rate)
4. Establish preliminary lender underwritten rent
5. Compare to broker's pro forma assumptions
6. Save all new comps to master_repo individually

**Output:** `comp_snapshot.json`

---

### Phase QR-4: RENT ROLL & EXPENSE SCAN

**Objective:** Quick validation of rent roll and expense data.

**Actions:**
1. Rent Roll Scan:
   - Calculate average in-place rent (weighted and unweighted)
   - Count vacant units, calculate occupancy
   - Identify loss-to-lease (in-place vs. market)
   - Flag concessions, free rent periods, MTM leases
2. T-12 Expense Review:
   - Calculate total expenses per unit
   - Check tax assessment reasonableness
   - Check insurance per unit
   - Flag any obvious anomalies (expenses materially below market norms)
3. Preliminary lender UW rent recommendation based on comp data
4. Flag: rents above market, expenses below norms, any red flags

**Output:** `rent_expense_scan.json`

---

### Phase QR-5: MINI CASH FLOW UNDERWRITE

**Objective:** Simplified dual-scenario NOI and loan sizing.

**Actions:**
1. Build simplified As-Is cash flow:
   ```
   GPR = actual in-place rent x occupied units
   Vacancy = actual vacancy from rent roll
   Other Income = from T-12
   Expenses = from T-12 (per unit)
   As-Is NOI = EGI - Expenses
   ```

2. Build simplified Stabilized cash flow:
   ```
   GPR = lender UW rent x total units
   Vacancy = 5% (default) or market-justified
   Expenses = T-12 per unit with reasonable growth
   Stabilized NOI = EGI - Expenses
   ```

3. Loan sizing against credit_box_config.json constraints:

   **6-Constraint Waterfall (ALL must be checked — MINIMUM governs):**
   **Load thresholds from credit_box_config.json — do not hardcode.**

   | Constraint | Threshold | Formula |
   |------------|-----------|---------|
   | LTV As-Is | ≤75% | `Max Loan = As-Is Value x 0.75` |
   | LTV Stabilized | ≤75% | `Max Loan = Stabilized Value x 0.75` |
   | DSCR Stabilized | ≥1.05x | `Max Loan = Stabilized NOI / (1.05 x rate)` |
   | DY Stabilized | ≥7.00% | `Max Loan = Stabilized NOI / 0.07` |
   | LTC | ≤80% | `Max Loan = Total Cost x 0.80` |
   | Max Loan Amount | $100M | Program cap |

   **CRITICAL:** 1.05x is the ONLY DSCR threshold. There is no going-in DSCR requirement.

4. Calculate all key metrics: DSCR (as-is and stabilized), DY, LTV, LTC
5. Identify binding constraint (MIN of all 6)
6. Rate = current SOFR (from Phase QR-1) + deal spread

**Output:** `mini_cashflow.json`

---

### Phase QR-6: NARRATIVE & RISK ASSESSMENT

**Objective:** Qualitative deal assessment.

**Actions:**
1. Write 2-3 sentence deal narrative:
   - What is this deal?
   - What is the business plan?
   - Why does it work or not?
2. Identify top 3 strengths (e.g., strong market, below-market basis, experienced sponsor)
3. Identify top 3 weaknesses/risks (e.g., lease-up risk, deferred maintenance, rate risk)
4. Generate 5-10 specific DD questions (not generic — deal-specific)
5. Create needs list (missing documents, data gaps, items needed to proceed)

**Output:** `narrative_risk.json`

---

### Phase QR-7: ONE-PAGE MEMO GENERATION

**Objective:** Compile all phase outputs into a single-page institutional DOCX.

**Actions:**
1. Compile all QR-0 through QR-6 outputs
2. Generate single-page DOCX using Elevated design (`valeri_report_v3.py`)
3. Layout per the One-Page Memo Spec below

**Output:** `[DEAL_NAME]_Quick_Review.docx`

### One-Page Memo Layout

```
+---------------------------------------------------------------+
|  QUICK REVIEW — [PROPERTY NAME]                               |
|  [Address] | [Units] Units | [Year Built] | [Sponsor]         |
+---------------------------------------------------------------+
|                                                                |
|  NARRATIVE (3-5 sentences)                                     |
|  What is this deal, what's the story, why does it work or not  |
|                                                                |
+-----------------------------+---------------------------------+
|  PROPERTY SNAPSHOT          |  LOAN SIZING SNAPSHOT            |
|  Units: ___                 |  Loan Request: $___M             |
|  Occupancy: ___%            |  Lender Sized: $___M             |
|  Avg Rent: $___             |  LTV: ___%  LTC: ___%            |
|  Avg SF: ___                |  DSCR: ___x  DY: ___%           |
|  Year Built: ____           |  Binding Constraint: ____        |
|  Basis: $___M               |  Rate: SOFR + ___bps             |
|  Cost/Unit: $___K           |  Term: ___                       |
+-----------------------------+---------------------------------+
|  CASH FLOW SNAPSHOT                                            |
|  +--------------+------------+--------------+                  |
|  |              |  As-Is     |  Stabilized  |                  |
|  |  EGI         |  $___      |  $___        |                  |
|  |  Expenses    |  $___      |  $___        |                  |
|  |  NOI         |  $___      |  $___        |                  |
|  |  NOI/Unit    |  $___      |  $___        |                  |
|  |  DSCR        |  ___x      |  ___x        |                  |
|  |  Debt Yield  |  ___%      |  ___%        |                  |
|  +--------------+------------+--------------+                  |
+---------------------------------------------------------------+
|  STRENGTHS                   |  RISKS & WEAKNESSES             |
|  1. _______________________  |  1. _______________________     |
|  2. _______________________  |  2. _______________________     |
|  3. _______________________  |  3. _______________________     |
+---------------------------------------------------------------+
|  DD QUESTIONS & NEEDS LIST                                     |
|  1. ______________________________________________________     |
|  2. ______________________________________________________     |
|  3. ______________________________________________________     |
|  4. ______________________________________________________     |
|  5. ______________________________________________________     |
+---------------------------------------------------------------+
|  Valeri Quick Review | Veleta Capital | [Date]                 |
|  NOT A COMMITMENT — Screening Analysis Only                    |
+---------------------------------------------------------------+
```

**Design Standards (V3.1 Elevated):**
- Carbon Slate (#2F363C), Aether (#C2DCEB), Steel Grey (#E5E5E5), Calibri
- Section headers: Slim Carbon Slate bar, white Calibri Bold 9pt
- Table headers: Bold text, thin Carbon Slate bottom border, no colored background
- Numbers: Calibri Bold, right-aligned
- $, %, x, bps columns: right-align (including headers)
- No vertical borders, horizontal Steel Grey dividers only
- Footer: "NOT A COMMITMENT — Screening Analysis Only"

---

### Phase QR-8: DEAL DATA RECORD

**Objective:** Generate standardized deal data record for institutional database.

**Actions:**
1. Compile all extracted and calculated data into the Deal Data Record schema
2. Save as both JSON (machine-readable) and markdown (human-readable)
3. Save to deal folder AND to `master_repo/deal_records/[YEAR]/[MONTH]/`

**Output:**
- `[DEAL_NAME]_Deal_Record.json`
- `[DEAL_NAME]_Deal_Record.md`

**Skill Reference:** See `deal-data-record/SKILL.md` for full schema.

---

### Phase QR-9: SKILL CHAIN LOG

**Objective:** Record every skill, tool, API, and data source used in this run.

**Actions:**
1. Compile execution log from all phases
2. Record: phase, skill/tool name, status (executed/skipped/failed), duration, notes
3. Flag any skills that should have fired but didn't
4. Flag any API calls that failed or returned incomplete data
5. Save to deal folder AND to `skill_chain_logs/`

**Output:** `[DEAL_NAME]_QR_Skill_Chain.md`

**Skill Reference:** See `skill-chain-audit/SKILL.md` for full log format.

## Outputs

| Output | Format | Purpose |
|--------|--------|---------|
| `[DEAL_NAME]_Quick_Review.docx` | DOCX (Elevated V3.1) | The 1-page institutional memo |
| `[DEAL_NAME]_Deal_Record.json` | JSON | Machine-readable deal record |
| `[DEAL_NAME]_Deal_Record.md` | Markdown | Human-readable deal record |
| `[DEAL_NAME]_QR_Skill_Chain.md` | Markdown | Execution audit log |
| Comp records (individual) | Markdown | Saved to master_repo/comps/ |
| Market data | JSON | Saved to master_repo/markets/ |

## Quality Gates

- [ ] All 10 phases executed (QR-0 through QR-9)
- [ ] SOFR rate is current from FRED API (not rounded, not stale)
- [ ] All 6 sizing constraints evaluated — binding constraint is MIN of all 6
- [ ] DSCR threshold is 1.05x (no other threshold used)
- [ ] master_repo checked BEFORE Perplexity research (read-before-research)
- [ ] New comps and market data saved TO master_repo after analysis
- [ ] DOCX memo produced (not just JSON/markdown)
- [ ] Deal Data Record produced in both JSON and markdown
- [ ] Skill Chain Log produced with all phases logged
- [ ] VALERI_FORMAT_ENFORCER applied to all numeric values
- [ ] Flood zone data from FEMA (not assumed)
- [ ] All numbers traceable to source document or calculation
- [ ] Loan amount does not exceed broker request
- [ ] Y1 DSCR and Y1 DY shown as analytical outputs only

## Error Handling

| Condition | Detection | Resolution |
|-----------|-----------|------------|
| OCR extraction failure | Key fields missing or obviously wrong | Flag in memo: "Data extraction incomplete — manual review required." Use available data only. |
| All MCP API calls fail | get_property_context and get_macro_indicators both return errors | Proceed without government data. Use broker-provided figures with prominent disclaimer. Flag in skill chain log. |
| No rent comps found | Perplexity returns zero relevant rent comparables | Expand search radius to MSA level. If still none, note "No independent rent validation available." Use broker rents with 5% haircut. |
| No sale comps found | Perplexity returns zero relevant sales | Note "No recent sales data available" in valuation section. Skip cap rate sensitivity. Flag for full UW. |
| SOFR rate unavailable | FRED API returns error or stale date | Use last known SOFR from deal folder or master_repo. Note the date in memo. NEVER use an assumed rate without disclosure. |
| Sponsor has no web presence | All Perplexity queries return no meaningful results | Note "Limited sponsor information available — full DD required." Classify as "Unknown" tier. Flag as DD question. |
| Deal documents incomplete | Missing rent roll, T-12, or both | Produce partial memo with available data. List missing documents in Needs List. Note which phases were skipped. |
| Property in flood zone | FEMA data shows SFHA (A, AE, V, VE) | Add flood insurance estimate to expenses ($2,000-5,000/unit depending on zone). Flag in risks. |
| master_repo read fails | Directory missing or corrupt | Proceed with fresh research. Note in skill chain log. |

## Worked Example

**Context:** Inbound deal — Sunset Ridge Apartments, 180 units, Class B-, 1992, Phoenix AZ metro. Sponsor requests $22M bridge loan for acquisition at $28.5M.

**Phase QR-1 Data Services:**
- SOFR: 4.33% (from FRED, pulled 2026-02-28)
- Flood Zone: X (not SFHA)
- Walk Score: 52
- Unemployment: 3.8%
- Median HHI: $72,400

**Phase QR-5 Mini Cash Flow:**
```
As-Is:
  GPR = $1,225 avg rent x 166 occupied = $2,439,000
  Vacancy = 7.8% (14 units vacant)
  Other Income = $180,000
  EGI = $2,427,000
  Expenses = $7,200/unit x 180 = $1,296,000
  As-Is NOI = $1,131,000

Stabilized:
  GPR = $1,350 UW rent x 180 = $2,916,000
  Vacancy = 5% = $145,800
  Other Income = $195,000
  EGI = $2,965,200
  Expenses = $7,500/unit x 180 = $1,350,000
  Stabilized NOI = $1,615,200
```

**Sizing Waterfall (Rate = 4.33% + 3.00% = 7.33%):**

| Constraint | Formula | Max Loan | Binding? |
|------------|---------|----------|----------|
| LTV As-Is | $24.0M x 0.75 | $18.0M | |
| LTV Stabilized | $32.3M x 0.75 | $24.2M | |
| DSCR 1.05x | $1,615,200 / (1.05 x 0.0733) | $20.98M | |
| DY 7.00% | $1,615,200 / 0.07 | $23.07M | |
| LTC | $32.1M x 0.80 | $25.7M | |
| Max Loan | $100M cap | $100M | |
| **Binding** | **LTV As-Is** | **$18.0M** | **YES** |

Lender-sized loan: $18.0M vs. broker request $22.0M — gap of $4.0M.

## Version History

| Version | Date | Notes |
|---------|------|-------|
| 1.0 | 2026-02-19 | Initial release. 10-phase Quick Review workflow with memo layout. |
| 2.0 | 2026-02-21 | Added role definition, error handling table, data services integration, master_repo protocol. Expanded constraint waterfall with formulas. |
| 3.0 | 2026-02-28 | Enterprise v3.0 format. Added YAML frontmatter, HARD RULES, quality gates, worked example with full sizing waterfall. Preserved all 10 phases, memo layout, constraint waterfall, design standards, error handling. Added phase integration notes and credit box references. |
