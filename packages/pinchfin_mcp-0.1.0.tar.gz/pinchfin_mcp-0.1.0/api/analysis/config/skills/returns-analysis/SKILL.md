---
name: returns-analysis
version: 3.0
phase: 11
domain: Lender Economics & Returns
dependencies:
  - loan-sizing
  - cash-flow-modeling
  - cre-calculations
inputs:
  - Recommended loan amount
  - All-in interest rate (SOFR + spread)
  - Current SOFR (from macro pull)
  - Origination fee (% and $)
  - Exit fee (% and $)
  - Lender NOI (Y1 and Stabilized)
  - As-Is and Stabilized values
  - Stabilized cap rate
outputs:
  - Unlevered IRR and MOIC (12, 24, 36 months)
  - Levered IRR and MOIC (12, 24, 36 months)
  - Cash-on-cash yield (levered)
  - Economics breakdown (spread, net interest, equity basis)
  - Cap rate sensitivity table
  - Vacancy stress table
credit_box_config: v3.0
mcp_tools:
  - mcp__valeri-data__get_macro_indicators
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# Returns Analysis Skill -- V3 Enterprise Edition

## Purpose

Calculate loan-level returns for {{FIRM_NAME}} as lender across unlevered (whole loan,
100% equity) and levered (with warehouse line) scenarios. Model across three standard
hold periods. Produce sensitivity analysis on cap rate and vacancy. This analysis
supports the Cash Flow UW Report (Document 7) and IC Memo (Document 8).

### CRITICAL RULES

1. **ALWAYS MODEL BOTH UNLEVERED AND LEVERED.** Unlevered = whole loan economics.
   Levered = with warehouse financing amplifying equity returns.
2. **WAREHOUSE ASSUMPTIONS ARE STANDARD:** 75% advance rate, SOFR + 175 bps.
   Do not modify without explicit operator direction.
3. **USE EXACT SOFR FROM MACRO PULL.** Do not round or use stale rates.
4. **INCLUDE ORIGINATION AND EXIT FEES** in return calculations. These are real cash
   flows that materially impact short-hold IRR.
5. **CAP RATE AND VACANCY ARE SEPARATE SENSITIVITY TABLES.** Never combine.
6. **HOLD PERIODS: 12, 24, 36 MONTHS.** Always model all three.

## Inputs

| Input | Source | Required |
|---|---|---|
| Loan_Amount | Loan Sizing (recommended) | Yes |
| Loan_Rate | SOFR + deal spread | Yes |
| SOFR | mcp__valeri-data__get_macro_indicators | Yes |
| Warehouse_Advance | 75% (standard) | Yes |
| Warehouse_Rate | SOFR + 175 bps | Yes |
| Origination_Fee_Pct | Deal terms (typical 1.00%) | Yes |
| Exit_Fee_Pct | Deal terms (typical 0.50%) | Yes |
| Lender_NOI_Y1 | Cash Flow Skill | Yes |
| Lender_NOI_Stab | Cash Flow Skill | Yes |
| Value_AsIs | Appraisal | Yes |
| Value_Stab | Lender UW | Yes |
| Stab_Cap_Rate | Lender UW | Yes |

## Methodology

### Step 1: Establish Rate Inputs

```
SOFR:             [exact from macro pull, e.g. 4.30%]
Deal Spread:      [deal-specific, e.g. 300 bps]
All-In Loan Rate: SOFR + Spread = [e.g. 7.30%]
Warehouse Rate:   SOFR + 175 bps = [e.g. 6.05%]
Net Spread:       Loan Rate - Warehouse Rate = [e.g. 125 bps]
```

### Step 2: Unlevered Returns (Whole Loan -- 100% Equity)

The lender deploys the full loan amount from its own capital.

```python
# For each hold period (12, 24, 36 months):

Investment = Loan_Amount  # T0 outflow
Origination_Fee = Loan_Amount * Orig_Fee_Pct  # Collected at T0
Monthly_Interest = Loan_Amount * Loan_Rate / 12  # Collected monthly
Exit_Fee = Loan_Amount * Exit_Fee_Pct  # Collected at payoff
Principal_Return = Loan_Amount  # Returned at payoff

# Cash flow array:
T0:   -Loan_Amount + Origination_Fee
T1-Tn: +Monthly_Interest
Tn:   +Monthly_Interest + Principal_Return + Exit_Fee

# Metrics:
IRR_monthly = numpy.irr(cash_flows)
IRR_annual = (1 + IRR_monthly)^12 - 1

Total_Interest = Monthly_Interest * hold_months
Total_Proceeds = Principal_Return + Total_Interest + Origination_Fee + Exit_Fee
MOIC = Total_Proceeds / Loan_Amount
```

### Step 3: Levered Returns (With Warehouse)

The lender uses a warehouse line to lever the investment, deploying only 25% equity.

```python
# Standard warehouse structure:
Warehouse_Amount = Loan_Amount * 0.75
Equity_Investment = Loan_Amount * 0.25

# Monthly cash flows:
Monthly_Loan_Interest = Loan_Amount * Loan_Rate / 12
Monthly_Warehouse_Cost = Warehouse_Amount * Warehouse_Rate / 12
Monthly_Net_Interest = Monthly_Loan_Interest - Monthly_Warehouse_Cost

# The lender earns the spread on the FULL loan but funds only 25%
# This amplifies returns on equity

# Cash flow array:
T0:   -Equity_Investment + Origination_Fee
T1-Tn: +Monthly_Net_Interest
Tn:   +Monthly_Net_Interest + Equity_Investment + Exit_Fee
       (warehouse is repaid from principal return -- net to equity)

# Metrics:
IRR_monthly = numpy.irr(cash_flows)
IRR_annual = (1 + IRR_monthly)^12 - 1
MOIC = Total_Equity_Proceeds / Equity_Investment
Cash_on_Cash = (Monthly_Net_Interest * 12) / Equity_Investment
```

### Step 4: Cap Rate Sensitivity

Show impact of cap rate changes on value and LTV. Five scenarios centered on base.

```
Cap Rate:  Base - 50bps | Base - 25bps | BASE | Base + 25bps | Base + 50bps
Value:     NOI / Cap    | NOI / Cap    | BASE | NOI / Cap    | NOI / Cap
LTV:       Loan / Value | Loan / Value | BASE | Loan / Value | Loan / Value
$/Unit:    Value / Units| Value / Units| BASE | Value / Units| Value / Units
```

Cap rates formatted to two decimals (5.25%). Values in $M format ($65.5M).
LTV to one decimal (64.1%). Base row BOLD.

### Step 5: Vacancy Stress

Show impact of vacancy increases on NOI and debt service coverage.

```
Vacancy:  Base | Base + 5% | Base + 10% | Base + 15%
EGI:      GPR * (1 - Vac) + Other Income
NOI:      EGI - OpEx
DSCR:     NOI / Annual_DS
```

DSCR < 1.00x formatted RED. Base row BOLD.

### Step 6: Economics Breakdown

Present the deal economics as a clean summary:

```
Loan Amount:              $XX,XXX,XXX
Loan Rate:                X.XX%
Annual Interest Income:   $X,XXX,XXX

Warehouse Amount (75%):   $XX,XXX,XXX
Warehouse Rate:           X.XX%
Annual Warehouse Cost:    $X,XXX,XXX

Net Spread:               XXX bps
Annual Net Interest:      $X,XXX,XXX
Equity Investment (25%):  $X,XXX,XXX
Cash-on-Cash Yield:       XX.X%

Origination Fee (X.XX%):  $XXX,XXX
Exit Fee (X.XX%):         $XXX,XXX
```

## Outputs

| Output | Format | Destination |
|---|---|---|
| Unlevered Returns Table | 3 hold periods, IRR + MOIC | Cash Flow UW Report (Doc 7) |
| Levered Returns Table | 3 hold periods, IRR + MOIC + CoC | Cash Flow UW Report (Doc 7) |
| Cap Rate Sensitivity | 5-column table | Cash Flow UW Report, IC Memo |
| Vacancy Stress | 4-column table | Cash Flow UW Report, IC Memo |
| Economics Breakdown | KV pairs | Cash Flow UW Report |

## Quality Gates

- [ ] Current SOFR rate used (exact from macro pull, not rounded)
- [ ] Both unlevered AND levered returns calculated
- [ ] All three hold periods modeled (12, 24, 36 months)
- [ ] Cap rate and vacancy are SEPARATE tables
- [ ] Origination and exit fees included in cash flows
- [ ] IRR annualized correctly from monthly ((1+r)^12 - 1)
- [ ] MOIC formula correct (Total Proceeds / Total Investment)
- [ ] Warehouse at 75% advance, SOFR + 175 bps (standard)
- [ ] Numbers formatted per Format Enforcer rules

## Error Handling

| Error Condition | Detection | Resolution |
|---|---|---|
| Stale SOFR rate | Macro pull > 5 business days old | Re-run get_macro_indicators before calculating |
| Missing origination fee | No fee in deal terms | Default to 1.00%; flag assumption |
| Missing exit fee | No fee in deal terms | Default to 0.50%; flag assumption |
| Negative levered IRR | Warehouse cost > loan income | ALERT: Deal economics inverted. Check rate assumptions. |
| IRR calculation fails | numpy.irr does not converge | Use numpy.npv bisection or XIRR with dates |
| Warehouse rate > loan rate | Spread inversion | BLOCK: Cannot warehouse this loan profitably |
| Hold period mismatch | Loan term < hold period | Cap hold period at loan term (incl. extensions) |
| MOIC < 1.00x | Total proceeds < investment | ALERT: Loss scenario. Flag for IC review. |

## Worked Example: 200-Unit Dallas Bridge Loan

**Inputs:**
```
Loan Amount:     $21,000,000
Loan Rate:       7.30% (SOFR 4.30% + 300 bps)
SOFR:            4.30% (from macro pull 2026-02-14)
Warehouse:       75% = $15,750,000
Warehouse Rate:  6.05% (SOFR 4.30% + 175 bps)
Equity:          25% = $5,250,000
Origination Fee: 1.00% = $210,000
Exit Fee:        0.50% = $105,000
```

**Unlevered Returns (Whole Loan):**

| Metric | 12 Months | 24 Months | 36 Months |
|---|---|---|---|
| Investment | $21,000,000 | $21,000,000 | $21,000,000 |
| Interest Income | $1,533,000 | $3,066,000 | $4,599,000 |
| Origination Fee | $210,000 | $210,000 | $210,000 |
| Exit Fee | $105,000 | $105,000 | $105,000 |
| Principal Return | $21,000,000 | $21,000,000 | $21,000,000 |
| Total Proceeds | $22,848,000 | $24,381,000 | $25,914,000 |
| IRR | 8.94% | 8.63% | 8.51% |
| MOIC | 1.09x | 1.16x | 1.23x |

Calculation detail (12-month):
```
T0: -$21,000,000 + $210,000 = -$20,790,000
T1-T11: +$127,750/mo ($21M x 7.30% / 12)
T12: +$127,750 + $21,000,000 + $105,000 = $21,232,750
Monthly IRR: 0.7155%
Annual IRR: (1.007155)^12 - 1 = 8.94%
MOIC: ($1,533,000 + $210,000 + $105,000 + $21,000,000) / $21,000,000 = 1.088x
```

**Levered Returns (With Warehouse):**

| Metric | 12 Months | 24 Months | 36 Months |
|---|---|---|---|
| Equity Investment | $5,250,000 | $5,250,000 | $5,250,000 |
| Gross Interest | $1,533,000 | $3,066,000 | $4,599,000 |
| Warehouse Cost | ($952,875) | ($1,905,750) | ($2,858,625) |
| Net Interest | $580,125 | $1,160,250 | $1,740,375 |
| Origination Fee | $210,000 | $210,000 | $210,000 |
| Exit Fee | $105,000 | $105,000 | $105,000 |
| Equity Return | $5,250,000 | $5,250,000 | $5,250,000 |
| Total Proceeds | $6,145,125 | $6,725,250 | $7,305,375 |
| IRR | 21.52% | 17.55% | 16.13% |
| MOIC | 1.17x | 1.28x | 1.39x |
| Cash-on-Cash | 11.05% | 11.05% | 11.05% |

Calculation detail (12-month):
```
T0: -$5,250,000 + $210,000 = -$5,040,000
T1-T11: +$48,344/mo (net interest: $127,750 - $79,406)
T12: +$48,344 + $5,250,000 + $105,000 = $5,403,344
Monthly IRR: 1.634%
Annual IRR: (1.01634)^12 - 1 = 21.52%
Cash-on-Cash: ($580,125) / $5,250,000 = 11.05%
```

**Economics Summary:**
```
Net Spread:            125 bps (7.30% - 6.05%)
Annual Net Interest:   $580,125
Equity Basis:          $5,250,000
Cash-on-Cash Yield:    11.05%
Total Fee Income:      $315,000 (orig $210K + exit $105K)
```

## Version History

| Version | Date | Changes |
|---|---|---|
| 1.0 | Jan 2026 | Initial release |
| 2.0 | Feb 2026 | Added levered/unlevered structure, hold periods |
| 3.0 | Feb 2026 | V3 Enterprise: Full frontmatter, error handling, worked example with real math, fee inclusion in IRR, economics breakdown, warehouse interaction detail |
