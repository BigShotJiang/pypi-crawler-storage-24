---
name: market-submarket
version: 3.0
phase: 3 — Market & Submarket Analysis
domain: market-research
dependencies:
  - sponsor-analysis (Phase 2 — GO required)
  - data-infrastructure-pull (Phase 2A — verified government data)
inputs:
  - input: Property address
    source: OM / Term Sheet
    required: true
  - input: Phase 2A Data Infrastructure Pull
    source: mcp__valeri-data__ output
    required: true
  - input: Sponsor Analysis GO decision
    source: Phase 2 output
    required: true
outputs:
  - output: Market_Analysis.docx
    format: PinchFin V4 DOCX (30+ pages)
  - output: phase_03_market.json
    format: JSON workflow state
credit_box_config: v3.0
mcp_tools:
  - mcp__valeri-data__get_property_context
  - mcp__valeri-data__get_demographics
  - mcp__valeri-data__get_employment
  - mcp__valeri-data__get_walk_score
  - mcp__valeri-data__get_macro_indicators
  - mcp__perplexity__search
  - mcp__perplexity__reason
design_system: PinchFin V4 (Navy #070B1A, Orange #B85A30, Calibri)
---

# Market & Submarket Analysis (Phase 3)

## Purpose

Market and submarket analysis determines whether the deal's location supports the investment thesis. It answers: Is this an MSA with durable economic drivers? Is the submarket supply/demand balance favorable? Are the sponsor's rent and occupancy assumptions achievable given local fundamentals?

This phase combines verified government data from Phase 2A (Census, BLS, FRED) with primary research via Perplexity to build a comprehensive market picture. The output directly informs comp selection criteria, rent growth assumptions, stabilized vacancy, cap rate selection, and exit assumptions used in all downstream phases.

CRITICAL RULES: Phase 2A Data Infrastructure Pull must be completed BEFORE this phase begins. Use verified Census/BLS data as the baseline — never rely solely on broker claims for demographic or employment data. All 8 Perplexity queries must be executed. Output must be a 30+ page DOCX with 10 sections.

## Inputs

| Input | Source | Required |
|-------|--------|----------|
| Property address | OM / Term Sheet | Yes |
| Phase 2A PropertyContext JSON | mcp__valeri-data__ | Yes |
| Phase 2A Macro Indicators JSON | mcp__valeri-data__ | Yes |
| Sponsor Analysis GO decision | Phase 2 output | Yes |
| Property class, unit count, vintage | OM | Yes |
| Broker's market assumptions (rent growth, vacancy) | OM | No |

## Methodology

### Step 0: Load Phase 2A Verified Data

Before any Perplexity research, load the Phase 2A data infrastructure pull outputs. Extract:

- **Demographics:** Population, median household income, median age, renter percentage, poverty rate (tract and county)
- **Employment:** Unemployment rate, labor force size, employment count
- **Macro:** SOFR, Treasury yields, CPI YoY, 30Y mortgage rate
- **Walk/Transit/Bike Scores:** Walkability and transit access
- **Flood Zone:** SFHA status
- **HUD FMR:** Fair Market Rents by bedroom count (relevant for affordable comps)

These are ground-truth data points. Use them as anchors; do not override with broker OM claims.

### Step 1: MSA Economic Profile

Build a comprehensive economic overview of the metro area. Cover population growth trajectory, economic diversification, and cost-of-living positioning relative to national benchmarks.

**Perplexity Query 1:** `"[MSA NAME]" population growth demographics 2025 2026`
**Perplexity Query 2:** `"[MSA NAME]" employment largest employers job growth`

Key data to capture:
- MSA population and 5-year growth rate
- GDP or GMP if available
- Cost of living index (100 = national)
- Economic diversification score (Herfindahl index or qualitative assessment)
- Top 10 employers with employee count, industry, and expansion/contraction trend

### Step 2: Employment Deep Dive

Layer BLS data from Phase 2A with Perplexity research on employer trends, sector composition, and wage growth. Employment is the single most important demand driver for multifamily.

Employment analysis must include:
- Current unemployment rate vs. national (from BLS via Phase 2A)
- Job growth trailing 12 months and 5-year CAGR
- Sector composition (% by NAICS sector)
- Wage growth vs. rent growth (affordability check)
- Major employer announcements (expansions, relocations, layoffs)

**Affordability Test:** Median HH income / (market rent x 12) = housing affordability ratio. Healthy range is 3.0x-5.0x. Below 3.0x signals rent ceiling risk.

### Step 3: Multifamily Market Fundamentals

Research MSA-level multifamily metrics: vacancy, rent growth, absorption, effective rents. This establishes the macro-market context before drilling into the submarket.

**Perplexity Query 3:** `"[MSA NAME]" multifamily market vacancy rates 2025 2026`
**Perplexity Query 4:** `"[MSA NAME]" apartment rent growth trends`

Key metrics table (5-year history required):

| Metric | 2021 | 2022 | 2023 | 2024 | Current | 5-Yr Avg |
|--------|------|------|------|------|---------|----------|
| Vacancy Rate | | | | | | |
| Avg Effective Rent | | | | | | |
| Rent Growth YoY | | | | | | |
| Net Absorption (units) | | | | | | |
| Deliveries (units) | | | | | | |

### Step 4: Supply Pipeline Analysis

Quantify new construction in the MSA and submarket. Supply risk is the primary threat to rent growth and occupancy assumptions.

**Perplexity Query 5:** `"[MSA NAME]" multifamily construction pipeline supply 2025 2026`
**Perplexity Query 6:** `"[MSA NAME]" multifamily absorption demand`

Calculate supply risk metrics:
- Under construction as % of existing inventory (>5% = elevated risk)
- Trailing 12-month absorption vs. trailing 12-month deliveries (absorption ratio)
- Forward 24-month deliveries vs. projected absorption
- Identify competitive projects within 3-mile radius (name, units, delivery date, class)

Supply Risk Rating:
- Low: Under construction <3% of inventory, absorption ratio >1.2x
- Moderate: Under construction 3-5%, absorption ratio 0.8-1.2x
- Elevated: Under construction 5-8%, absorption ratio 0.5-0.8x
- High: Under construction >8% OR absorption ratio <0.5x

### Step 5: Submarket Deep Dive

Narrow focus to the specific submarket containing the subject property. The submarket may perform differently from the MSA.

**Perplexity Query 7:** `"[SUBMARKET NAME]" "[CITY]" apartment market overview`

Submarket analysis must include:
- Submarket boundaries and total inventory (units)
- Subject property as % of submarket inventory
- Submarket vacancy vs. MSA vacancy (is submarket outperforming or underperforming?)
- Submarket rent levels by unit type and class
- Submarket-specific supply pipeline
- Key demand generators (employers, institutions, transit) within 3-mile radius
- Barriers to entry (land availability, zoning restrictions, entitlement difficulty)

### Step 6: Regulatory and Policy Environment

Assess rent control, affordable housing mandates, zoning changes, and tax policy that could impact the investment.

**Perplexity Query 8:** `"[MSA NAME]" rent control housing regulations`

Document:
- Rent control/stabilization (does it apply to this property?)
- Inclusionary zoning requirements
- Property tax reassessment methodology on sale
- Insurance market conditions (especially FL, TX, CA coastal)
- Any pending legislation that could affect multifamily operations

### Step 7: Supportable Assumptions Derivation

Based on all research, derive the lender's supportable market assumptions:

| Assumption | Broker Claim | Lender View | Basis |
|------------|-------------|-------------|-------|
| Rent growth (annual) | | | 5-yr avg rent growth, capped at 3.0% |
| Stabilized vacancy | | | 5-yr avg vacancy, floored at 5.0% |
| Exit cap rate | | | Current cap rate + 25-50 bps spread |
| Expense growth | | | CPI YoY from FRED, floored at 3.0% |

## Outputs

The Market Analysis produces a 30+ page DOCX document with these sections:

| Section | Content | Pages |
|---------|---------|-------|
| Executive Summary | Market quality assessment, key findings, supportable assumptions | 2-3 |
| MSA Overview | Population, geography, economic profile, cost of living | 5-6 |
| Economic Analysis | Employment, sectors, wages, major employers, announcements | 5-6 |
| Multifamily Fundamentals | Vacancy, rents, absorption, 5-year trends | 6-8 |
| Supply Pipeline | Under construction, planned, competitive projects, supply risk rating | 4-5 |
| Submarket Deep Dive | Boundaries, inventory, demand generators, barriers to entry | 5-6 |
| Competitive Landscape | Adjacent submarkets, competitive set positioning | 3-4 |
| Regulatory Environment | Rent control, tax policy, insurance, pending legislation | 2-3 |
| Market Risks | Supply risk, demand risk, regulatory risk, macro risk | 3-4 |
| Conclusion | Market quality rating, supportable assumptions, downstream implications | 2 |

## OUTPUT DEPTH & QUALITY STANDARDS

This is a core deal report. Every report must be institutional-grade, accurate,
and deep enough that a credit officer can make a lending decision without asking
follow-up questions. Quality and accuracy always take priority over word count.

**Target range: 6,000–8,000 words of narrative** (excluding table cells).
Market & Submarket is typically the longest of the three core research reports
because it covers MSA demographics, employment, multifamily fundamentals, supply,
submarket positioning, and regulatory environment. Do not pad or stretch — but this
report naturally requires depth across many dimensions. If a simple, stable market
can be fully characterized in 5,500 words, that is fine. If a complex MSA with
multiple employment centers, active supply pipeline, and regulatory nuances requires
9,000+ words, write it.

Tables SUPPORT the narrative — they never REPLACE it. Every data table must be
preceded or followed by at least one analytical paragraph that interprets the data.

### Section-Level Depth Guidance

| Section | Target Words | Required Narrative Elements |
|---------|-------------|----------------------------|
| Executive Summary | 400–600 | Market quality narrative, key metrics interpretation, recommendation with reasoning |
| MSA Overview | 800–1,500 | Geographic context narrative, population trends with year-by-year interpretation, demographic characteristics, quality of life factors, submarket-specific demographics |
| Economic Analysis | 800–1,500 | Employment by sector with NARRATIVE analysis of top employers (not just a table), regional employment center narrative, employment trend analysis, economic driver assessment |
| Multifamily Fundamentals | 1,000–2,000 | Quarterly vacancy trend narrative with interpretation, rent levels by unit type with market positioning narrative, rent growth history (5-year), subject property vs. market comparison |
| Supply Pipeline | 500–1,000 | Under construction by submarket narrative, notable projects described, supply as % of inventory, comparison to absorption, supply risk assessment |
| Submarket Deep Dive | 600–1,200 | Submarket character narrative, positioning assessment, property location analysis, competitive set overview, submarket-specific supply analysis |
| Regulatory Environment | 500–1,000 | Rent control applicability (cap calculation, just cause, vacancy decontrol), property tax methodology, insurance environment, zoning |
| Market Risks | 400–800 | Risk matrix with severity/probability narrative, mitigants for each risk, overall risk assessment |
| Conclusion | 400–700 | Market summary table plus narrative, underwriting recommendations (broker vs lender), market recommendation with rationale |
| Appendices | Complete | 8 research queries with dates and tools, 10+ named sources per Source Hierarchy |

### Research Source Hierarchy — MANDATORY

Accuracy depends on source quality. The following hierarchy governs ALL research:

**Tier 1 — Institutional Research (PREFERRED, use first):**
- Market reports: CBRE, JLL, Newmark, Cushman & Wakefield, Marcus & Millichap, Colliers, NAI Capital
- Data platforms: CoStar, RealPage, Yardi Matrix, REIS (Moody's Analytics), RCA (MSCI), Trepp
- Government data: U.S. Census Bureau (ACS), Bureau of Labor Statistics, FRED, HUD, FEMA
- Valeri Data Services MCP: Demographics, employment, macro indicators, HUD FMR, walk score, flood zone
- Industry bodies: NMHC, NAA, MBA, CREFC, Urban Land Institute, Freddie Mac Research

**Tier 2 — Verified Aggregators (supplement Tier 1, cross-reference):**
- Listing/rent platforms: Apartments.com, RentCafe, Zumper, Zillow (for trend confirmation — not primary)
- News/press: The Real Deal, Commercial Observer, Bisnow, GlobeSt, local business journals
- Municipal sources: City planning departments, economic development agencies

**Tier 3 — Never Cite:**
- Consulting blogs, content marketing, SEO articles, crowd-sourced forums
- Any source that would not be cited in a CREFC white paper or OCC examiner's report

RULE: When Tier 1 and Tier 2 sources conflict, Tier 1 governs. For rent and vacancy
data, prefer CoStar/Yardi/RealPage over RentCafe/Zumper. For employment and demographics,
Census/BLS via Valeri Data Services is authoritative. Always note the source tier in
the appendix.

### Anti-Pattern

Converting a multi-paragraph employment analysis into a single table:
  BAD:  | Employer | Employees | Trend |
        | Naval Base | 32,000 | Stable |
  GOOD: "Naval Base Ventura County remains the single largest employer in the
         Oxnard-Thousand Oaks-Ventura MSA, supporting approximately 32,000 military
         and civilian positions. The base's economic footprint extends well beyond
         direct employment — an estimated 1.8x multiplier generates an additional
         57,600 indirect jobs in housing, retail, healthcare, and professional
         services throughout the region..."
         [FOLLOWED BY top employers table]

## REPORT QUALITY ENFORCEMENT — GLOBAL STANDARD

This report is a standalone institutional research document intended for credit
committee, investors, capital partners, and public MCP consumers. It is NOT a
summary memo, NOT a dashboard, and NOT an IC presentation slide.

QUALITY REQUIREMENTS:
1. Target narrative word count (excluding table cells): 6,000–8,000 words
2. Every section heading must have at least 2 substantive paragraphs beneath it
3. Every data table must have interpretive narrative before or after it
4. All research queries must be executed and findings integrated into prose
5. Formatting uses PinchFin V4 design (Navy/Orange, Calibri, pinchfin_report.py)
6. Tables compress data efficiently — use them for metrics, timelines, comparisons
7. Narrative provides context, interpretation, and institutional insight
8. Source hierarchy must be followed — Tier 1 institutional sources first
9. Every factual claim must be traceable to a named, institutional-grade source
10. No filler copy — every sentence must add analytical value

QUALITY CHECK BEFORE FINALIZING:
- Is every section substantive with real analytical content (not padding)?
- Are sources primarily Tier 1 institutional research, not just internet aggregators?
- Could a credit officer read this report and make a lending decision without
  asking follow-up questions? If not, you've left out critical analysis.
- Is every number accurate and sourced? Cross-reference key figures across sources.

## Quality Gates

- [ ] All 8 Perplexity queries executed
- [ ] Phase 2A verified data loaded and referenced (Census, BLS, FRED)
- [ ] MSA employment data documented with unemployment rate and job growth
- [ ] 5-year historical trend table completed for vacancy, rents, absorption
- [ ] Supply pipeline quantified with supply risk rating assigned
- [ ] At least 3 demand generators identified for submarket
- [ ] Supportable rent growth assumption stated and justified
- [ ] Supportable stabilized vacancy stated and justified
- [ ] Broker claims compared to lender assumptions with variance noted
- [ ] DOCX output is 30+ pages with substantive content in every section

## Error Handling

| Error | Resolution |
|-------|-----------|
| Phase 2A data infrastructure pull not completed | STOP. Cannot proceed without verified government data. Run get_property_context and get_macro_indicators first |
| MCP tool timeout on get_demographics or get_employment | Retry once. If persistent, use Perplexity to source Census/BLS data directly, but flag as "unverified — MCP unavailable" |
| Submarket data unavailable (too granular for Perplexity) | Expand to MSA-level data and note "submarket-specific data limited." Use MSA averages with qualitative submarket adjustments |
| Conflicting data between sources (CoStar vs. RealPage vs. Yardi) | Report the range. Use the median or most conservative figure for underwriting. Note all sources |
| Rent control or regulatory risk identified | Flag as GATE-KEEPING nuance. Ensure nuance-gate-analysis skill is triggered in Phase 4B |
| Insurance market in crisis (FL, coastal TX, CA wildfire zones) | Apply insurance stress test: underwrite insurance at 150% of current cost. Note in risk factors |
| Walk Score unavailable | Note as "Walk Score unavailable" and assess walkability qualitatively from Google Maps |

## Worked Example

**Subject:** 280-unit Class B multifamily in Dallas-Fort Worth MSA, Uptown/Knox-Henderson submarket.

**Phase 2A Verified Data (from mcp__valeri-data__):**
- Census tract population: 4,812 | County population: 2,613,539
- Median HH income (tract): $82,450 | County: $67,134
- Unemployment rate (Dallas County): 3.8% | Labor force: 1,421,000
- SOFR: 4.30% | 10Y Treasury: 4.52% | CPI YoY: 2.7%
- Walk Score: 78 | Transit Score: 52 | Bike Score: 64
- Flood Zone: X (not in SFHA)
- HUD FMR: 1BR $1,310 | 2BR $1,560 | 3BR $2,040

**MSA Economic Profile:**
- DFW MSA population: 8.1M (1.8% 5-year CAGR — top-5 growth nationally)
- Unemployment: 3.8% (vs. 3.9% national)
- Job growth trailing 12 months: +98,000 jobs (+2.4%)
- Cost of living: 97 (slightly below national average)
- Economic diversification: Strong — no single sector >18% of employment

**Top Employers:**

| Employer | Employees | Industry | Trend |
|----------|-----------|----------|-------|
| American Airlines | 30,000+ | Aviation | Stable |
| AT&T | 28,000+ | Telecom | Stable |
| Texas Health Resources | 24,000+ | Healthcare | Growing |
| Baylor Scott & White | 22,000+ | Healthcare | Growing |
| JPMorgan Chase | 16,000+ | Finance | Growing |

**Multifamily Fundamentals:**

| Metric | 2021 | 2022 | 2023 | 2024 | Current | 5-Yr Avg |
|--------|------|------|------|------|---------|----------|
| Vacancy | 4.8% | 5.2% | 7.1% | 7.8% | 7.2% | 6.4% |
| Avg Rent | $1,285 | $1,410 | $1,425 | $1,405 | $1,418 | $1,389 |
| Rent Growth | 14.2% | 9.7% | 1.1% | -1.4% | 0.9% | 4.9% |
| Absorption | 42,100 | 28,400 | 18,200 | 31,500 | 34,800 | 31,000 |
| Deliveries | 24,500 | 32,800 | 38,100 | 42,300 | 35,200 | 34,580 |

**Supply Risk Assessment: Elevated**
- Under construction: 38,400 units (4.8% of 800,000 inventory)
- Absorption ratio: 34,800 / 35,200 = 0.99x (absorption slightly trailing deliveries)
- Uptown/Knox-Henderson specific: 1,200 units under construction within 3-mile radius
- Supply risk is elevated MSA-wide but moderating as starts decline

**Competitive Projects (3-mile radius):**

| Project | Units | Delivery | Distance | Class |
|---------|-------|----------|----------|-------|
| The Victor Uptown | 310 | Q3 2026 | 0.8 mi | A |
| Knox at McKinney | 185 | Q1 2027 | 1.2 mi | A |
| Henderson Ave Lofts | 142 | Q4 2026 | 1.5 mi | B+ |

**Supportable Assumptions:**

| Assumption | Broker Claim | Lender View | Basis |
|------------|-------------|-------------|-------|
| Rent growth | 4.0% annual | 2.0% annual | 5-yr avg 4.9% skewed by 2021-2022; post-supply-wave growth muted. 2.0% conservative |
| Stabilized vacancy | 5.0% | 7.0% | Current submarket vacancy 7.2%, 5-yr avg 6.4%. Floor at 7.0% until supply wave absorbed |
| Exit cap rate | 4.75% | 5.25% | Current Class B trades at 5.00%-5.25% in DFW. Add 25 bps for market uncertainty |
| Expense growth | 2.5% | 3.0% | CPI YoY 2.7%, insurance and tax pressure in TX. Floor at 3.0% |

**Affordability Test:** $82,450 / ($1,418 x 12) = 4.84x — healthy. Submarket income supports current rents.

**Market Quality: Acceptable (with caution)**
Strong economic fundamentals and population growth are offset by elevated near-term supply risk. The submarket will absorb new deliveries by mid-2027, but the next 12-18 months will see concession pressure on Class B assets competing with new Class A product. Rent growth should be underwritten conservatively at 2.0% until supply clears.
