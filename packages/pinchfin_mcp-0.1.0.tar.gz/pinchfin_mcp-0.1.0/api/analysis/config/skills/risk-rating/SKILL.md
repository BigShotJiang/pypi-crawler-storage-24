---
name: risk-rating
version: 3.0
phase: 11
domain: Credit Risk Assessment
dependencies:
  - sponsor-analysis
  - market-submarket
  - cash-flow-modeling
  - loan-sizing
  - comp-analysis
inputs:
  - Sponsor tier and track record
  - Market rating and fundamentals
  - Property condition and occupancy
  - Lender NOI and credit metrics (DSCR, DY, LTV, LTC)
  - Loan structure and covenants
outputs:
  - 5-component weighted risk score (1-5 scale)
  - Composite rating (A/B/C/D tier)
  - Component-level rationale
  - Key risk factors and mitigants
  - Rating justification narrative
credit_box_config: v3.0
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# Risk Rating Skill -- V3 Enterprise Edition

## Purpose

Assign an institutional risk rating to each loan using a quantitative 5-component
weighted scoring methodology. The rating drives loss reserve calculations, portfolio
stratification, IC presentation, and regulatory reporting. Ratings are aligned with
OCC CRE guidance and map to an A/B/C/D tier system.

### CRITICAL RULES

1. **QUANTITATIVE FIRST.** Score each component 1-5 using defined criteria before
   applying qualitative judgment. The composite score drives the tier, not gut feel.
2. **WEIGHTS ARE FIXED:** Sponsor 25%, Market 20%, Property 20%, Cash Flow 20%,
   Structure 15%. Do not modify without IC approval.
3. **USE LENDER METRICS.** All credit metrics (DSCR, DY, LTV) must be from Lender UW,
   not sponsor/broker figures.
4. **DOCUMENT RATIONALE.** Every component score requires 2-3 sentences of justification.
   No bare scores.
5. **STABILIZED METRICS FOR RATING.** Rate against stabilized performance, not Y1.
   Y1 metrics inform the narrative but do not drive the score.

## Inputs

| Input | Source | Required |
|---|---|---|
| Sponsor_Tier | Sponsor Analysis (Phase 2) | Yes |
| Sponsor_NW_Liquidity | Sponsor Analysis | Yes |
| Sponsor_Track_Record | Sponsor Analysis | Yes |
| Market_Rating | Market Analysis (Phase 3) | Yes |
| Market_Vacancy | Market Analysis | Yes |
| Market_Rent_Growth | Market Analysis | Yes |
| Property_Age | Property docs | Yes |
| Property_Occupancy | Rent Roll Analysis | Yes |
| Property_Condition | PCA / operator context | Yes |
| DSCR_Stab | Loan Sizing (Phase 9) | Yes |
| DY_Stab | Loan Sizing | Yes |
| LTV_Stab | Loan Sizing | Yes |
| LTC | Loan Sizing | Yes |
| Loan_Structure | Deal terms | Yes |
| Covenant_Package | Deal terms | Yes |

## Methodology

### Step 1: Score Each Component (1-5 Scale)

**Component 1: Sponsor (25% weight)**

| Score | Criteria |
|---|---|
| 1 | Institutional sponsor. 5,000+ units owned. 10+ years. NW > 2x loan. No red flags. |
| 2 | Experienced regional. 2,000+ units. 5+ years. NW > 1.5x loan. Clean background. |
| 3 | Proven operator. 500+ units. 3+ years. NW > 1x loan. Minor flags with explanation. |
| 4 | Limited track record. < 500 units. < 3 years. NW ~ 1x loan. Needs strong structure. |
| 5 | First-time sponsor or material red flags (litigation, defaults, thin capitalization). |

**Component 2: Market (20% weight)**

| Score | Criteria |
|---|---|
| 1 | Top-10 MSA. Population growth > 2%. Job growth > 3%. Vacancy < 4%. Rent growth > 5%. |
| 2 | Top-25 MSA. Pop growth > 1%. Job growth > 2%. Vacancy < 5%. Rent growth > 3%. |
| 3 | Top-50 MSA. Stable population. Moderate job growth. Vacancy 5-7%. Rent growth 2-3%. |
| 4 | Secondary market. Flat/declining population. Limited employers. Vacancy 7-10%. |
| 5 | Tertiary market. Population decline. Single employer dependency. Vacancy > 10%. |

**Component 3: Property (20% weight)**

| Score | Criteria |
|---|---|
| 1 | Built post-2010. Excellent condition. 95%+ occupancy. Class A amenities. Prime location. |
| 2 | Built 2000-2010. Good condition. 92%+ occupancy. Class B+ amenities. Strong location. |
| 3 | Built 1985-2000. Average condition. 88%+ occupancy. Class B. Adequate location. |
| 4 | Built 1970-1985. Deferred maintenance. 80-88% occupancy. Class C. Secondary location. |
| 5 | Pre-1970. Significant deferred maintenance. < 80% occupancy. Functional obsolescence. |

**Component 4: Cash Flow (20% weight)**

| Score | Criteria |
|---|---|
| 1 | Stabilized DSCR > 1.40x. DY > 10%. LTV < 60%. Strong NOI margin (> 60%). |
| 2 | Stabilized DSCR 1.25-1.40x. DY 8.5-10%. LTV 60-65%. Healthy NOI margin (55-60%). |
| 3 | Stabilized DSCR 1.15-1.25x. DY 7.5-8.5%. LTV 65-70%. Adequate margin (50-55%). |
| 4 | Stabilized DSCR 1.05-1.15x. DY 7.0-7.5%. LTV 70-75%. Thin margin (45-50%). |
| 5 | Stabilized DSCR < 1.05x. DY < 7.0%. LTV > 75%. Negative carry or margin < 45%. |

**Component 5: Structure (15% weight)**

| Score | Criteria |
|---|---|
| 1 | Conservative LTC (< 65%). Full recourse. Funded reserves. Strong covenants. Rate cap. |
| 2 | Moderate LTC (65-70%). Partial recourse. Adequate reserves. Standard covenants. |
| 3 | Standard LTC (70-75%). Non-recourse with carve-outs. Basic reserves. Standard terms. |
| 4 | Elevated LTC (75-80%). Non-recourse. Minimal reserves. Weak covenants. |
| 5 | Max LTC (80%). Non-recourse. No reserves. No covenants. No extension conditions. |

### Step 2: Calculate Composite Score

```
Composite = (Sponsor_Score x 0.25)
          + (Market_Score x 0.20)
          + (Property_Score x 0.20)
          + (Cash_Flow_Score x 0.20)
          + (Structure_Score x 0.15)
```

### Step 3: Map to Tier

| Composite Score | Tier | Classification | Action |
|---|---|---|---|
| 1.00 - 1.75 | A | Excellent | Approve with standard terms |
| 1.76 - 2.50 | B | Good | Approve, may need minor conditions |
| 2.51 - 3.50 | C | Acceptable | Approve with conditions or enhanced structure |
| 3.51 - 4.50 | D | Watch / Decline | Requires IC escalation or decline |
| 4.51 - 5.00 | D- | Substandard | Decline or workout |

### Step 4: Identify Key Risks and Mitigants

For each component scoring 3 or above, document:
- The specific risk factor driving the elevated score
- Available mitigants (structural, market, sponsor-driven)
- Whether the mitigant is sufficient to justify the deal

### Step 5: Draft Rating Justification

Write a 3-5 sentence narrative explaining:
- The composite score and tier assignment
- Which components are strongest and weakest
- Whether any single component is a deal-killer regardless of composite
- Conditions required to maintain the rating

## Outputs

| Output | Format | Destination |
|---|---|---|
| Component Scorecard | Weighted table | IC Memo Section 9 |
| Composite Score | X.XX | IC Memo, Cash Flow UW Report |
| Tier Assignment | A/B/C/D | IC Memo header, Deal Tape |
| Risk Factors | Bulleted list | IC Memo Section 9 |
| Mitigants | Bulleted list | IC Memo Section 9 |
| Rating Justification | Narrative paragraph | IC Memo Section 9 |

## Quality Gates

- [ ] All 5 components scored with rationale
- [ ] Weights sum to 100% (25+20+20+20+15)
- [ ] Composite score calculated correctly
- [ ] Tier assignment matches score range
- [ ] Credit metrics from Lender UW (not sponsor)
- [ ] Each elevated score (3+) has documented risk and mitigant
- [ ] Rating justification narrative is 3-5 sentences
- [ ] No single-component override without IC escalation note

## Error Handling

| Error Condition | Detection | Resolution |
|---|---|---|
| Missing sponsor analysis | No Phase 2 output | BLOCK: Cannot rate without sponsor data |
| Stale market data | Market analysis > 6 months old | Re-run Phase 3 market research |
| Sponsor score = 5, composite = B | Single-component override | FLAG: Sponsor risk may override composite. Escalate to IC. |
| All components = 3 | Composite = 3.00 | Valid but note: deal is uniformly mediocre. No strength to offset weakness. |
| Credit metrics from sponsor | NOI source mismatch | BLOCK: Recalculate with Lender UW figures |
| Missing PCA or condition data | No property inspection | Default property to score 3; flag "no PCA -- conservative assumption" |
| Composite = 2.49 vs 2.51 | Borderline tier | Document both tiers and rationale; let IC decide |

## Worked Example: Oakwood Gardens -- 200 Units, Dallas TX

**Inputs:**
```
Sponsor: Tier B regional operator, 3,200 units, 8 years, NW $42M (1.5x loan)
Market: Dallas-Fort Worth MSA, pop growth 1.8%, vacancy 5.2%, rent growth 3.1%
Property: Built 1998, Class B, 87% occupancy, moderate deferred maintenance
Cash Flow: Stab DSCR 1.18x, DY 7.8%, LTV 68.2%, NOI margin 52%
Structure: LTC 73%, non-recourse with carve-outs, 6-month IR holdback, rate cap
```

**Scoring:**

| Component | Weight | Score | Wtd Score | Rationale |
|---|---|---|---|---|
| Sponsor | 25% | 2 | 0.50 | Experienced regional with 3,200 units and 8 years. NW 1.5x loan. Clean background. Strong operator with DFW experience. |
| Market | 20% | 2 | 0.40 | Top-10 MSA with robust population and employment growth. Vacancy manageable at 5.2%. Rent growth above national average at 3.1%. |
| Property | 20% | 3 | 0.60 | 1998 vintage Class B with moderate deferred maintenance. 87% occupancy is below stabilized target but consistent with value-add thesis. Location is adequate but not prime. |
| Cash Flow | 20% | 3 | 0.60 | Stabilized DSCR 1.18x and DY 7.8% are adequate but not strong. LTV 68.2% provides reasonable cushion. NOI margin 52% is middle-of-range. |
| Structure | 15% | 3 | 0.45 | LTC 73% is within guidelines. Non-recourse with carve-outs is standard. IR holdback and rate cap provide structural protection. Covenants are basic. |

**Composite Score: 2.55**
**Tier: C (Acceptable)**

**Rating Justification:**
Oakwood Gardens receives a C rating (composite 2.55) driven by a strong sponsor and
favorable market offset by a property requiring renovation and adequate-but-not-strong
cash flow coverage. The sponsor's regional experience and 1.5x net worth coverage
provide meaningful downside protection. The deal benefits from Dallas-Fort Worth's
favorable demographics but carries execution risk on the renovation program. Conditions
for approval should include milestone-based draw schedule, quarterly financial reporting,
and DSCR test at extension. No single component presents a deal-killing risk.

**Key Risks:**
- Property condition (score 3): Deferred maintenance requires $5M renovation budget
- Cash flow (score 3): DSCR 1.18x provides limited cushion during lease-up
- 87% in-place occupancy: Must absorb to 94% during 24-month term

**Mitigants:**
- Sponsor has completed 4 similar renovations in DFW (3,200 units total)
- IR holdback covers 12 months of negative carry
- Rate cap limits downside on floating rate exposure
- DFW market fundamentals support rent growth thesis

## Version History

| Version | Date | Changes |
|---|---|---|
| 1.0 | Dec 2025 | Initial release with basic 4-component model |
| 2.0 | Jan 2026 | Added OCC alignment, expanded criteria |
| 3.0 | Feb 2026 | V3 Enterprise: 5-component model (Sponsor 25%, Market 20%, Property 20%, Cash Flow 20%, Structure 15%), A/B/C/D tier mapping, full scoring criteria tables, worked example with real numbers, error handling |
