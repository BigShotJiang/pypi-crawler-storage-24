---
name: rent-roll-analysis
version: 3.0
phase: 5 — Rent Roll Validation
domain: property-analysis
dependencies:
  - comp-analysis (Phase 6 — market rent conclusions)
  - lender-underwritten-rent (Phase 6A — lender rents)
inputs:
  - input: Current rent roll (Excel/CSV/PDF)
    source: Sponsor / Broker / PM company
    required: true
  - input: Market rent conclusions by unit type
    source: Phase 6 Comparable Analysis
    required: true
  - input: Lender Underwritten Rents
    source: Phase 6A Lender Rent output
    required: true
  - input: Unit mix and SF data
    source: OM / Rent Roll
    required: true
outputs:
  - output: Rent_Roll_Analysis.docx
    format: V3.1 Elevated DOCX (15+ pages)
  - output: phase_05_rentroll.json
    format: JSON workflow state
credit_box_config: v3.0
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# Rent Roll Analysis (Phase 5)

## Purpose

Rent roll analysis validates the property's actual income at the unit level. This phase reconciles the sponsor's rent roll against Phase 6A lender-derived market rents to quantify loss-to-lease, mark-to-market potential, and lease expiration risk. The output establishes the in-place revenue baseline that anchors the T-12 reconciliation in Phase 6.

A rent roll is the single source of truth for what the property is actually collecting. The OM narrative may claim "$1,500 average rents" while the rent roll reveals a bimodal distribution with renovated units at $1,650 and classic units at $1,280. This phase catches those discrepancies before they contaminate the cash flow model.

CRITICAL RULES: Always use Phase 6A lender rents (not broker rents) as the market rent benchmark. Every unit must be accounted for — total units on the rent roll must match the OM unit count. Flag any unit with rent exceeding lender market rent by more than 5% (potential outlier or error). Physical occupancy and economic occupancy must both be calculated and reconciled.

## Inputs

| Input | Source | Required |
|-------|--------|----------|
| Rent roll (unit-level detail) | Sponsor / PM | Yes |
| Lender market rents by unit type | Phase 6A | Yes |
| Phase 6 market rent conclusions | Phase 6 Comparable Analysis | Yes |
| Property unit count and mix | OM / Rent Roll | Yes |
| T-12 rental income total (for reconciliation) | T-12 Statement | Yes |

## Methodology

### Step 1: Data Extraction and Validation

Extract the following fields for every unit from the rent roll. If the rent roll is in Excel/CSV, use Python for extraction. If PDF, extract manually or via OCR.

Required fields per unit:
- Unit number
- Unit type (Studio/1BR/2BR/3BR) and bed/bath count
- Square footage
- Occupancy status (occupied/vacant/down/model)
- Current monthly rent (or "market ready" rent for vacant units)
- Lease start date
- Lease end date
- Move-in date
- Tenant name (for occupancy verification — do not include in output)
- Security deposit amount
- Concessions (if any)
- Renovation status (classic/partial/full renovation)

**Validation checks:**
- Total units on rent roll = total units in OM (if mismatch, flag immediately)
- No duplicate unit numbers
- No negative or zero rents on occupied units
- Lease end dates are in the future for occupied units (expired leases = month-to-month)
- Square footage totals are reasonable (total net rentable SF should match OM)

### Step 2: Unit Mix Summary

Aggregate unit-level data into a unit mix summary table:

| Type | Units | % Mix | Avg SF | In-Place Rent | In-Place $/SF | Lender Mkt Rent | LTL % |
|------|-------|-------|--------|---------------|---------------|-----------------|-------|
| 1BR/1BA | | | | | | | |
| 2BR/2BA | | | | | | | |
| 3BR/2BA | | | | | | | |
| **Total/Wtd** | | **100%** | | | | | |

### Step 3: Occupancy Analysis

Calculate physical and economic occupancy:

```
Physical Occupancy = Occupied Units / Total Units
Economic Occupancy = (Actual Collected Rent + Other Income) / (Gross Potential Rent)
                   = (GPR - Vacancy Loss - Concessions - Bad Debt) / GPR
```

Reconcile with T-12:
- T-12 rental income / 12 = average monthly collected rent
- Compare to: sum of all occupied unit rents on rent roll
- Variance >3% requires explanation (timing, move-ins/outs, concessions)

Categorize non-occupied units:
- Vacant — available and market-ready
- Down — under renovation, not leasable
- Model — used as leasing model, not generating revenue
- Employee — staff unit, may be at reduced or zero rent

### Step 4: Loss-to-Lease Analysis

Loss-to-lease (LTL) measures the gap between in-place rents and achievable market rents. This is the income upside available at lease turnover without any capital investment.

```
Unit-Level LTL ($) = Lender Market Rent - In-Place Rent
Unit-Level LTL (%) = (Lender Market Rent - In-Place Rent) / Lender Market Rent
```

Aggregate by unit type:

| Type | Units | In-Place Avg | Lender Mkt | LTL $/Unit | LTL % | Annual LTL $ |
|------|-------|-------------|-----------|-----------|-------|-------------|
| 1BR | | | | | | |
| 2BR | | | | | | |
| 3BR | | | | | | |
| **Total** | | | | | | |

Where Annual LTL $ = sum of (Lender Market Rent - In-Place Rent) x 12 for all units below market.

Classify units:
- Below market (positive LTL): count and average gap
- At market (+/- 2%): count
- Above market (negative LTL / premium): count and average premium — investigate why (recent renovation, concession burn-off, or potential rollback risk)

### Step 5: Renovation Status Segmentation

If the property has a value-add component, segment the rent roll by renovation status:

| Segment | Units | Avg Rent | Avg $/SF | vs. Classic Premium | vs. Market |
|---------|-------|----------|----------|--------------------|-----------|
| Classic (unrenovated) | | | | — | |
| Partial renovation | | | | | |
| Full renovation | | | | | |
| Vacant/Down | | | | — | — |

Calculate the renovation premium: (Renovated Avg Rent - Classic Avg Rent) / Classic Avg Rent. Typical Class B value-add premium range: $150-$300/month or 12-22%. Premiums exceeding 25% should be scrutinized against comps.

### Step 6: Lease Expiration Waterfall

Build a monthly lease expiration schedule for the next 18 months:

| Month | Expirations | % of Total | Cumulative % | Rolling 3-Mo |
|-------|-------------|------------|--------------|-------------|
| Mar 2026 | | | | |
| Apr 2026 | | | | |
| ... | | | | |
| Aug 2027 | | | | |

**Concentration Risk Test:**
- Flag any single month with >10% of leases expiring
- Flag any rolling 3-month window with >25% of leases expiring
- Flag if >15% of leases are month-to-month (expired leases)

Month-to-month tenants represent immediate turnover risk but also immediate mark-to-market opportunity.

### Step 7: Rent Roll-to-T-12 Reconciliation

Verify that the rent roll supports the T-12 rental income:

```
Rent Roll Implied Annual Revenue = Sum of all occupied unit rents x 12
T-12 Gross Rental Revenue = T-12 line item

Reconciliation Variance = (Rent Roll Implied - T-12 Actual) / T-12 Actual

If variance > +5%: Rents may have increased recently (rent roll is forward-looking)
If variance < -5%: Possible bad debt, concessions, or down units not reflected in rent roll
```

## Outputs

| Section | Content | Pages |
|---------|---------|-------|
| Summary Metrics | Occupancy, avg rent, LTL, key findings | 2-3 |
| Unit Mix Analysis | Table with SF, rents, $/SF, LTL by type | 2-3 |
| Occupancy Analysis | Physical/economic, vacant unit detail | 2-3 |
| Loss-to-Lease Analysis | Unit-level LTL, aggregate by type | 3-4 |
| Renovation Segmentation | Classic vs. renovated performance | 2-3 |
| Lease Expiration Waterfall | Monthly schedule, concentration risk | 2-3 |
| T-12 Reconciliation | Rent roll vs. T-12, variance explanation | 1-2 |

## Quality Gates

- [ ] Total units on rent roll match OM unit count
- [ ] Physical and economic occupancy both calculated
- [ ] Loss-to-lease calculated using Phase 6A LENDER rents (not broker rents)
- [ ] Every unit type has a market rent comparison
- [ ] Lease expiration concentration flagged if >25% in any rolling 3-month window
- [ ] Rent roll income reconciled to T-12 within 5%
- [ ] Units above market rent identified and investigated
- [ ] Renovation segmentation completed (if value-add deal)
- [ ] Down/model/employee units identified and excluded from occupancy
- [ ] DOCX output is 15+ pages with unit-level detail

## Error Handling

| Error | Resolution |
|-------|-----------|
| Rent roll unit count does not match OM | Flag immediately. Common causes: OM includes commercial units, OM excludes employee/model units, rent roll is stale. Request clarification from broker |
| Rent roll is a PDF with poor formatting | Use Python OCR or manual extraction. Flag any units where data is unclear. Request Excel version from PM company |
| Lease dates are missing or incomplete | Assume month-to-month for units without lease end dates. Note count of MTM units in analysis |
| Multiple rents shown per unit (base + premium) | Use total rent (base + premium) for analysis. Note the premium amount separately for renovation analysis |
| T-12 reconciliation variance exceeds 10% | Likely indicates the rent roll date and T-12 period are misaligned, or there are significant concessions/bad debt. Request a rent roll date-matched to T-12 end date |
| Phase 6A lender rents not yet available | STOP. Phase 6A must be completed before this analysis. Use Phase 6 market rent conclusions as interim proxy but flag as "pending lender rent confirmation" |
| Units with $0 rent or negative rent | Classify as employee units, model units, or data errors. Exclude from revenue calculations. Document each |

## Worked Example

**Subject:** Oakwood Terrace — 200 units, Knox-Henderson, Dallas, TX. Rent roll dated January 31, 2026.

**Unit Mix Summary:**

| Type | Units | % Mix | Avg SF | In-Place | $/SF | Lender Mkt | LTL % |
|------|-------|-------|--------|----------|------|-----------|-------|
| 1BR/1BA | 80 | 40% | 725 | $1,285 | $1.77 | $1,340 | 4.1% |
| 2BR/2BA | 90 | 45% | 1,050 | $1,545 | $1.47 | $1,515 | -2.0% |
| 3BR/2BA | 30 | 15% | 1,325 | $1,810 | $1.37 | $1,850 | 2.2% |
| **Total/Wtd** | **200** | **100%** | **937** | **$1,469** | **$1.57** | **$1,485** | **1.1%** |

**Occupancy:**
- Physical: 186 / 200 = 93.0%
- Vacant: 8 units (market-ready)
- Down (under renovation): 4 units
- Model: 2 units
- Economic: ($1,469 x 186 x 12) / ($1,469 x 200 x 12) = 91.4% (reflects vacancy + concessions)

**Loss-to-Lease by Segment:**

| Segment | Units | Avg Rent | Lender Mkt | LTL $/Unit | Annual LTL |
|---------|-------|----------|-----------|-----------|-----------|
| Classic 1BR | 50 | $1,195 | $1,340 | $145 | $87,000 |
| Renovated 1BR | 30 | $1,435 | $1,340 | -$95 | — (above market) |
| Classic 2BR | 48 | $1,410 | $1,515 | $105 | $60,480 |
| Renovated 2BR | 42 | $1,698 | $1,515 | -$183 | — (above market) |
| Classic 3BR | 18 | $1,720 | $1,850 | $130 | $28,080 |
| Renovated 3BR | 12 | $1,945 | $1,850 | -$95 | — (above market) |

Total LTL on classic units: $175,560/year (mark-to-market upside at turnover). Renovated units are $95-$183 above lender market rent — this premium reflects renovation investment and appears reasonable at 7-12% above classic, but should be monitored for sustainability.

**Lease Expiration Concentration:**

| Quarter | Expirations | % of Total | Cumulative |
|---------|-------------|------------|------------|
| Q1 2026 | 28 | 14.0% | 14.0% |
| Q2 2026 | 42 | 21.0% | 35.0% |
| Q3 2026 | 38 | 19.0% | 54.0% |
| Q4 2026 | 35 | 17.5% | 71.5% |
| MTM | 22 | 11.0% | — |

Q2 2026 has 21.0% concentration — within acceptable range but worth monitoring. 22 units (11.0%) are month-to-month, representing immediate mark-to-market opportunity but also turnover risk.

**T-12 Reconciliation:**
- Rent roll implied annual: $1,469 x 186 x 12 = $3,278,808
- T-12 gross rental revenue: $3,201,450
- Variance: +2.4% — reasonable; reflects modest rent increases during the T-12 period (rent roll captures current rates, T-12 captures blended historical rates)
