---
name: credit-memo
version: 3.0
phase: 12
domain: Credit Decision & IC Documentation
dependencies:
  - sponsor-analysis
  - market-submarket
  - comp-analysis
  - rent-roll-analysis
  - t12-analysis
  - cash-flow-modeling
  - loan-sizing
  - returns-analysis
  - risk-rating
inputs:
  - All 7 prior documents in the 8-document model
  - Phase outputs (JSON) from workflow-state
  - Operator context brief
  - Deal terms and structure
outputs:
  - IC Memo (Document 8 of 8) -- 20+ pages
  - Credit recommendation (Approve / Approve with Conditions / Decline)
  - Short-form memo (2 pages, if requested)
credit_box_config: v3.0
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# Credit Memo Skill -- V3 Enterprise Edition

## Purpose

Generate the Investment Committee Memorandum as the CAPSTONE document (Document 8 of 8)
that synthesizes all prior analysis into a comprehensive, actionable credit recommendation.
This is the single document the IC reads to make a lending decision.

### CRITICAL RULES

1. **THE IC MEMO REFERENCES, DOES NOT REPLICATE.** The 7 prior documents contain the deep
   analysis. The IC Memo synthesizes and draws conclusions. Do not copy 30 pages of market
   research into the memo -- distill the key findings and reference the standalone document.
2. **RECOMMENDATION MUST BE CLEAR AND ACTIONABLE.** Approve / Approve with Conditions /
   Decline. No hedging, no "maybe." State the recommendation and defend it.
3. **ALL METRICS FROM LENDER UW.** Every number in the IC Memo traces to Lender Underwrite,
   never sponsor/broker proforma. If a sponsor figure is shown, it is labeled and contrasted.
4. **8-DOCUMENT MODEL INTEGRATION.** The memo must reference and synthesize findings from:
   Doc 1 (Sponsor), Doc 2 (Market), Doc 3 (Comps), Doc 4 (Rent Roll), Doc 5 (T-12/Expense),
   Doc 6 (Business Plan), Doc 7 (Cash Flow UW / Sizing / Returns consolidated).
5. **FORMAT ENFORCER RULES APPLY.** Cap rates two decimals, DSCR two decimals + x,
   dollars per Format Enforcer, sensitivity tables SEPARATE.
6. **NO SYSTEM RULES IN OUTPUT.** The memo reflects the methodology without narrating it.
   Lines like "Y1 DSCR is analytical not a constraint" are system instructions, not memo content.
7. **TITLE PAGE:** Shows ONLY "Investment Committee Memorandum", Property Name, Address,
   Unit Count. No dates, versions, or metadata on title page.

## Inputs

| Input | Source | Required |
|---|---|---|
| Doc 1: Sponsor Analysis | Phase 2 DOCX | Yes |
| Doc 2: Market Analysis | Phase 3 DOCX | Yes |
| Doc 3: Comparable Analysis | Phase 4 DOCX | Yes |
| Doc 4: Rent Roll Analysis | Phase 5 DOCX | Yes |
| Doc 5: T-12 / Expense Analysis | Phase 5 DOCX | Yes |
| Doc 6: Business Plan Analysis | Phase 7 DOCX | Yes (skip if stabilized) |
| Doc 7: Cash Flow UW Analysis | Phase 6-9 DOCX (consolidated) | Yes |
| Operator Context Brief | Phase -1 | Yes |
| Risk Rating Output | Phase 11 | Yes |
| Deal Terms | Term sheet / LOI | Yes |

## Methodology

### Section 1: Deal Tape Strip (1 page)

A single-page dashboard presenting all key metrics at a glance.

```
DEAL TAPE STRIP:
  Property:           [Name], [City, State]
  Units:              [###]
  Year Built:         [YYYY]
  Sponsor:            [Name] (Tier [A/B/C/D])
  Risk Rating:        [A/B/C/D] (composite [X.XX])

  Loan Request:       $[XX.X]M
  Recommended Loan:   $[XX.X]M
  Rate:               SOFR + [XXX] bps ([X.XX]% all-in)
  Term:               [XX]+[XX]+[XX] months
  LTV (As-Is):        [XX.X]%
  LTV (Stabilized):   [XX.X]%
  LTC:                [XX.X]%
  DSCR (Stabilized):  [X.XX]x
  DY (Stabilized):    [X.X]%
  Binding Constraint: [Constraint] at $[XX.X]M

  Recommendation:     [APPROVE / APPROVE WITH CONDITIONS / DECLINE]
```

### Section 2: Transaction Summary (2-3 pages)

- Property overview: location, type, unit count, year built, recent renovations
- Sponsor overview: entity, principals, tier classification
- Transaction purpose: acquisition, refinance, recapitalization
- Loan request vs. recommended amount
- Business plan summary: value-add, stabilization, timeline
- Sources & Uses table — invoke PF-SUA node in MODE: full. Include scenario code, classification rationale, full S&U tables, residual label, capital stack disclosure (separate from S&U), and variance table (if intake_sua_registry exists)

### Section 3: Sponsor Summary (2 pages)

Synthesize Doc 1 findings:
- Tier classification with rationale
- Track record: total units, markets, loan performance
- Financial capacity: NW relative to loan, liquidity
- Key strengths and concerns
- Prior relationship with the lender (if any)

### Section 4: Market Summary (2 pages)

Synthesize Doc 2 findings:
- Market rating with key drivers
- Population and employment trends
- Multifamily supply/demand dynamics
- Submarket positioning
- Rent growth trajectory and vacancy trends
- Key market risks (supply pipeline, employer concentration)

### Section 5: Property & Cash Flow (3-4 pages)

Synthesize Docs 4, 5, 6, and 7:
- Unit mix summary table
- Dual-scenario presentation: Sponsor Proforma vs. Lender Underwrite
- NOI bridge: T-12 actual to Lender Stabilized
- Key variance analysis (where lender disagrees with sponsor)
- Expense ratio analysis and reasonableness

### Section 6: Valuation (2 pages)

From Doc 7 (consolidated):
- As-Is value methodology and conclusion
- Stabilized value methodology and conclusion
- Cap rate support from comparable sales (Doc 3)
- Price per unit analysis vs. comps

### Section 7: Loan Sizing & Sources and Uses (2-3 pages)

From Doc 7 (consolidated):
- 6-constraint waterfall table (full calculation shown)
- Binding constraint identification
- Broker request comparison and variance
- Recommended loan: Conservative / Standard / Stretch scenarios
- Negative carry analysis and IR sizing (if applicable)

**S&U Sub-Section (PF-SUA full mode):**
Invoke PF-SUA node in MODE: full after five-constraint waterfall is complete. The S&U section must include:
1. Scenario code + one-sentence classification rationale
2. Full sources table (all line items, amounts, percentages)
3. Full uses table (all line items, amounts, percentages)
4. Residual (explicit label and amount — derived last, never assumed zero)
5. Capital stack disclosure (SEPARATE from S&U — surviving obligations, combined LTV)
6. Variance table (if intake_sua_registry exists):

```
BROKER SUBMISSION vs. UNDERWRITTEN REALITY

Line Item         Broker       Underwritten   Variance
───────────────── ────────     ────────────   ────────
[each line]       $X           $Y             +/-$Z  X%

Scenario (Broker implied):   SCN-X
Scenario (Underwritten):     SCN-Y
[Flag any variance > 2% of loan amount]
```

**QA gate:** PF-SUA full mode checklist must return `sua_checklist_status = CLEARED` before credit memo S&U section is finalized. Any FAIL escalates to Resolver.

### Section 8: Deal Structure (2 pages)

- Loan terms: rate, term, extensions, IO/amort
- Fee structure: origination, exit, extension
- Covenants: DSCR test, occupancy test, NW/liquidity
- Reserves: IR holdback, capex, tax/insurance escrow
- Rate cap requirement
- Cash management triggers
- Extension conditions

### Section 9: Risk Analysis (2-3 pages)

Synthesize risk-rating output:
- 5-component scorecard table
- Composite score and tier
- Key risks (bulleted, specific)
- Mitigants (bulleted, specific)
- Cap rate sensitivity table (SEPARATE)
- Vacancy stress table (SEPARATE)
- Breakeven occupancy (one line)
- Lender returns summary (unlevered and levered IRR/MOIC)

### Section 10: Credit Recommendation (1-2 pages)

The recommendation section with clear decision framework:

```
RECOMMENDATION FRAMEWORK:

APPROVE:
  - All 6 sizing constraints pass
  - Risk rating A or B
  - No material exceptions required
  - Strong sponsor and market

APPROVE WITH CONDITIONS:
  - Minor exceptions (1-2 constraints marginal)
  - Risk rating B or C
  - Conditions enumerated and achievable
  - Structural mitigants available

DECLINE:
  - Multiple constraint failures
  - Risk rating D
  - Broker request exceeds constraints by > 20%
  - Material sponsor or market concerns
  - No viable structural mitigants
```

Present as:
- Recommendation: [APPROVE / APPROVE WITH CONDITIONS / DECLINE]
- Rationale: 3-5 sentences defending the recommendation
- Conditions (if applicable): Numbered list of specific, measurable conditions
- Strengths: 3-5 key deal strengths
- Weaknesses: 3-5 key deal weaknesses
- Exceptions required: Any constraint exceptions with mitigants

## Outputs

| Output | Format | Destination |
|---|---|---|
| IC Memo (long-form) | DOCX, 20+ pages, Elevated V3.1 | IC Package |
| Short-form memo | DOCX, 2 pages (if requested) | Screening / Quick Decision |
| Credit Recommendation JSON | Structured data | workflow-state/ |

### Short-Form Memo (2 pages, if requested)

Condensed version for screening. Contains:
- Page 1: Deal tape strip + transaction summary + sponsor/market highlights
- Page 2: Credit metrics table + sizing waterfall + recommendation

## Quality Gates

- [ ] All 10 sections present with substantive content
- [ ] All metrics from Lender UW (not sponsor/broker)
- [ ] 6-constraint waterfall table with binding constraint shown
- [ ] Cap rate and vacancy sensitivity tables SEPARATE
- [ ] Sources & Uses balances exactly
- [ ] Recommendation is clear: Approve / Approve with Conditions / Decline
- [ ] Conditions are specific and measurable (not vague)
- [ ] Risk rating scorecard included with composite and tier
- [ ] Title page shows ONLY: title, property name, address, unit count
- [ ] No system rules or methodology narration in output text
- [ ] No calculation echo after tables
- [ ] Format Enforcer rules applied to all numbers
- [ ] Callout boxes use light Aether/grey background (not dark Carbon Slate)
- [ ] All 7 prior documents referenced (not replicated)

## Error Handling

| Error Condition | Detection | Resolution |
|---|---|---|
| Missing prior document | Doc 1-7 not found in workflow-state | BLOCK: Cannot produce IC Memo without complete analysis. Return to missing phase. |
| Metrics inconsistency | DSCR in Section 7 differs from Section 1 | BLOCK: Reconcile. Single source of truth = Doc 7 sizing output. |
| Recommendation without rationale | "Approve" with no defense | BLOCK: Minimum 3 sentences defending the recommendation. |
| Sponsor NOI in credit metrics | Source field = "sponsor" | BLOCK: Replace with Lender UW figures throughout. |
| Sources & Uses imbalance | Total Sources != Total Uses | BLOCK: Re-run PF-SUA full mode. Reconcile before proceeding. Common error: missing closing costs. |
| PF-SUA checklist FAIL | Any of 15 checklist items returns FAIL | BLOCK: Escalate to Resolver. Document failed items and resolution before S&U section is finalized. |
| Vague conditions | "Maintain adequate occupancy" | Rewrite as measurable: "Achieve 90% occupancy by Month 12" |
| No risk rating | Phase 11 not completed | Run risk-rating skill before memo generation |
| Dark background callout boxes | Carbon Slate bg on narrative boxes | Convert to light Aether/grey background with dark text |

## Worked Example: IC Memo Outline -- Oakwood Gardens, 200 Units, Dallas TX

**Title Page:**
```
INVESTMENT COMMITTEE MEMORANDUM

Oakwood Gardens
1234 Elm Street, Dallas, TX 75201
200 Units
```

**Section 1 -- Deal Tape Strip:**

| Metric | Value |
|---|---|
| Property | Oakwood Gardens, Dallas TX |
| Units | 200 |
| Year Built | 1998 |
| Sponsor | Oakwood Capital Partners (Tier B) |
| Risk Rating | C (2.55) |
| Loan Request | $28,000,000 |
| Recommended Loan | $21,000,000 |
| Rate | SOFR + 300 bps (7.30% all-in) |
| Term | 24+6+6 months |
| LTV (As-Is) | 65.6% |
| LTV (Stabilized) | 60.0% |
| LTC | 72.4% |
| DSCR (Stabilized) | 1.18x |
| DY (Stabilized) | 7.8% |
| Binding Constraint | DY (Stabilized) at $21.1M |
| Recommendation | APPROVE WITH CONDITIONS |

**Section 7 -- Sizing Waterfall:**

| Constraint | Threshold | Max Loan | Binding? |
|---|---|---|---|
| LTC | 80% | $23,200,000 | |
| LTV (As-Is) | 75% | $24,000,000 | |
| LTV (Stabilized) | 75% | $26,250,000 | |
| DSCR (Stabilized) | 1.05x | $21,327,000 | |
| DY (Stabilized) | 7.00% | $23,571,000 | |
| **BINDING** | **DSCR (Stab)** | **$21,327,000** | **YES** |

Recommended: $21,000,000 (rounded down from DSCR constraint)

**Section 10 -- Recommendation:**

APPROVE WITH CONDITIONS

Oakwood Gardens is recommended for a $21.0M bridge loan, sized to the stabilized DSCR
constraint at 1.18x. The deal benefits from an experienced Tier B sponsor with 3,200
units in the DFW market and favorable population/employment fundamentals. The primary
risk is execution on the $5M renovation program, mitigated by the sponsor's track record
of 4 completed comparable projects. The interest reserve holdback of $1.8M covers
approximately 14 months of negative carry, providing adequate cushion for the lease-up
timeline.

**Conditions:**
1. Achieve 90% occupancy by Month 12 (DSCR test trigger)
2. Complete 80% of unit renovations by Month 15
3. Maintain minimum NW of 1.0x loan balance throughout term
4. Provide monthly operating statements and quarterly rent rolls
5. Purchase interest rate cap with SOFR strike at 5.50%
6. Sponsor to fund $1.2M of renovation budget from equity (balance from loan proceeds)

**Strengths:**
- Experienced DFW operator with demonstrated renovation track record
- Top-10 MSA with strong employment diversification
- Attractive basis at $145,000/unit vs. replacement cost of $225,000/unit
- IR holdback covers 14 months at current burn rate

**Weaknesses:**
- In-place occupancy of 87% requires meaningful lease-up
- DSCR cushion at 1.18x is adequate but not strong
- Non-recourse structure limits lender remedies
- Renovation budget has limited contingency (8%)

## Version History

| Version | Date | Changes |
|---|---|---|
| 1.0 | Dec 2025 | Initial release |
| 2.0 | Jan 2026 | Added 8-document model integration, dual-scenario |
| 3.0 | Feb 2026 | V3 Enterprise: Full frontmatter, 10-section structure, recommendation framework (Approve/Conditions/Decline), worked IC memo outline, error handling, 8-document cross-reference, format enforcer integration, quality gates |
