---
name: loan-sizing
version: 3.0
phase: 9
domain: Loan Structuring & Sizing
dependencies:
  - cash-flow-modeling
  - cre-calculations
  - expense-underwriting
  - comp-analysis
inputs:
  - Lender NOI (Y1 and Stabilized)
  - As-Is Value (appraised or purchase price)
  - Stabilized Value (Lender UW cap rate)
  - Total Cost (purchase + capex + closing + reserves)
  - Interest Rate (SOFR + deal spread from macro pull)
  - IO/Amort structure
  - Broker loan request
outputs:
  - 6-constraint waterfall table with binding constraint
  - Recommended loan amount (Conservative / Standard / Stretch)
  - Negative carry analysis with interest reserve sizing
  - Refinance exit test
  - Broker request variance analysis
  - Credit metrics summary at recommended loan
credit_box_config: v3.0
mcp_tools:
  - mcp__valeri-data__get_macro_indicators
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# Loan Sizing Skill -- V3 Enterprise Edition

## Purpose

Size bridge/transitional loans by running the full 6-constraint waterfall and selecting
the MINIMUM (most restrictive) as the binding constraint. The recommended loan amount
is derived from credit metrics, not from the broker request.

### CRITICAL RULES

1. **SIZE TO CONSTRAINTS, NOT BROKER REQUEST.** The loan amount = MIN(6 constraints).
   The broker request is compared AFTER sizing, never used as the starting point.
2. **LENDER NOI ONLY.** All sizing uses Lender Underwrite NOI, never Sponsor/Broker NOI.
3. **Y1 DSCR AND Y1 DY ARE ANALYTICAL OUTPUTS ONLY.** They do NOT enter the MIN()
   function. Transitional loans have sub-stabilized going-in cash flow by design.
4. **REFERENCE credit_box_config.json v3.0** for all constraint thresholds. Do not use
   hardcoded thresholds from any other source.
5. **NEVER ASSUME THE BINDING CONSTRAINT.** Run all 5 and let the math decide.
6. **NEVER RECOMMEND MORE THAN BROKER REQUEST** even if constraints allow it.
7. **AS-IS VALUE METHODOLOGY:** Purchase = appraised value. Refi within 2 years still
   stabilizing = purchase price.

## Inputs

| Input | Source | Required |
|---|---|---|
| Lender_NOI_Y1 | Cash Flow Skill (Lender UW) | Yes |
| Lender_NOI_Stab | Cash Flow Skill (Lender UW) | Yes |
| Value_AsIs | Appraisal or purchase price | Yes |
| Value_Stab | Lender UW NOI / Lender cap rate | Yes |
| Total_Cost | Purchase + CapEx + Closing + Reserves | Yes |
| Interest_Rate | SOFR + deal spread (from macro pull) | Yes |
| IO_Period_Months | Loan term structure | Yes |
| Amort_Years | If applicable after IO period | Conditional |
| Broker_Request | Broker/sponsor loan ask | Yes |
| Stab_Timeline_Months | Months to stabilization | Yes |
| Annual_Debt_Service | Rate x Loan (IO) or mortgage constant | Derived |

## Methodology

### Step 1: Input Validation

Confirm all inputs are from Lender Underwrite, not Sponsor/Broker proforma.

```
VALIDATION CHECKLIST:
- Lender_NOI_Stab derived from Lender UW rents (Phase 4A output)
- Value_Stab = Lender_NOI_Stab / Lender_Cap_Rate (not broker cap)
- Total_Cost includes ALL cost components (not just purchase price)
- Interest_Rate = exact SOFR from macro pull + deal spread (basic addition)
- If SOFR = 4.30% and spread = 300 bps, rate = 7.30%. No rounding.
```

### Step 2: Calculate Maximum Loan Under Each Constraint

**Constraint 1 -- LTC (ceiling: 80%)**
```
Max_Loan_LTC = Total_Cost x 0.80
```

**Constraint 2 -- LTV As-Is (ceiling: 75%)**
```
Max_Loan_LTV_AsIs = Value_AsIs x 0.75
```

**Constraint 3 -- LTV Stabilized (ceiling: 75%)**
```
Max_Loan_LTV_Stab = Value_Stab x 0.75
```

**Constraint 4 -- DSCR Stabilized (floor: 1.05x)**
For IO loans:
```
Max_Annual_DS = Lender_NOI_Stab / 1.05
Max_Loan_DSCR = Max_Annual_DS / Interest_Rate
```
For amortizing loans:
```
Max_Annual_DS = Lender_NOI_Stab / 1.05
Max_Loan_DSCR = Max_Annual_DS / Mortgage_Constant
Where: Mortgage_Constant = PMT(rate/12, amort_months, 1) x 12
```

**Constraint 5 -- Debt Yield Stabilized (floor: 7.00%)**
```
Max_Loan_DY = Lender_NOI_Stab / 0.07
```

### Step 3: Identify Binding Constraint

```python
Constrained_Loan = MIN(
    Max_Loan_LTC,
    Max_Loan_LTV_AsIs,
    Max_Loan_LTV_Stab,
    Max_Loan_DSCR,
    Max_Loan_DY
)
```

Present as waterfall table:

| Constraint | Threshold | Max Loan | Binding? |
|---|---|---|---|
| LTC | 80% | $_______ | |
| LTV (As-Is) | 75% | $_______ | |
| LTV (Stabilized) | 75% | $_______ | |
| DSCR (Stabilized) | 1.05x | $_______ | |
| DY (Stabilized) | 7.00% | $_______ | |
| **BINDING** | | **$_______** | **YES** |

### Step 4: Compute Analytical Outputs (NOT Sizing Constraints)

```
DSCR_Y1 = Lender_NOI_Y1 / Annual_Debt_Service
DY_Y1 = Lender_NOI_Y1 / Recommended_Loan
```
Report in credit memo. Do not use for sizing.

### Step 5: Broker Request Comparison

```python
IF Broker_Request > Constrained_Loan:
    Variance = Broker_Request - Constrained_Loan
    Variance_Pct = Variance / Constrained_Loan

    IF Variance_Pct > 0.20:
        STATUS = "DECLINE -- exceeds constraints by >20%"
    ELIF Variance_Pct > 0.10:
        STATUS = "STRETCH -- requires multiple credit exceptions"
    ELSE:
        STATUS = "EXCEPTION -- minor exception may be acceptable"

IF Broker_Request <= Constrained_Loan:
    STATUS = "WITHIN CONSTRAINTS"
    Recommended_Loan = Broker_Request  # Never exceed broker ask
```

### Step 6: Negative Carry & Interest Reserve

```python
IF Lender_NOI_Y1 < Annual_Debt_Service:
    Monthly_Shortfall = (Annual_Debt_Service - Lender_NOI_Y1) / 12
    Monthly_NOI_Growth = (Lender_NOI_Stab - Lender_NOI_Y1) / (Stab_Months)
    Months_to_Breakeven = Monthly_Shortfall / Monthly_NOI_Growth
    IR_Reserve = Monthly_Shortfall * Months_to_Breakeven * 1.25  # 25% cushion

    # Interest reserve is funded at closing from loan proceeds or sponsor equity
    # It ADDS to Total Cost (increasing LTC) but does NOT change the loan sizing
    # constraint outputs -- it is a structural feature, not a sizing input.

    FLAGS:
      - "NEGATIVE CARRY LOAN"
      - Interest reserve of $_______ funded at closing
      - Full recourse until DSCR >= 1.05x
      - Cash management from Day 1
      - Monthly draw-down reporting required
```

**Interest Reserve Interaction with Sizing:**
The IR holdback is part of the loan proceeds. It increases the effective LTC
because it adds to total project cost. If the IR causes LTC to breach 80%,
either reduce the initial advance or require the sponsor to fund the IR from
equity. The IR is NOT new lending capacity -- it is a use of proceeds.

### Step 7: Refinance Exit Test

```
Exit_Cap = Entry_Cap + 25-50 bps (market stress)
Exit_Value = Lender_NOI_Stab / Exit_Cap
Perm_Rate = 10Y Treasury + 200-250 bps (agency spread)
Perm_Amort = 30 years
Perm_DSCR_Req = 1.25x
Mortgage_Constant = PMT(Perm_Rate/12, 360, 1) x 12
Max_Perm_DS = Lender_NOI_Stab / 1.25
Supportable_Perm = Max_Perm_DS / Mortgage_Constant
Refi_Gap = Recommended_Loan - Supportable_Perm
Gap_Pct = Refi_Gap / Recommended_Loan
```

Flag if Gap > 10%: borrower may need equity at exit.
Flag if Gap > 15%: HIGH refinance risk -- consider reducing loan.

### Step 8: Final Recommendation

```
RECOMMENDED SCENARIOS:
  Conservative: Constrained_Loan (no exceptions)
  Standard:     Constrained_Loan x 1.05 (one minor exception)
  Stretch:      Constrained_Loan x 1.10 (multiple exceptions, mitigants required)
  Decline:      > Constrained_Loan x 1.10

NEVER exceed Broker_Request regardless of constraint headroom.
```

## Outputs

| Output | Format | Destination |
|---|---|---|
| 6-Constraint Waterfall Table | Markdown table | Cash Flow UW Report (Doc 7) |
| Binding Constraint ID | Text | Cash Flow UW Report, IC Memo |
| Recommended Loan Amount | Dollar, 3 scenarios | Cash Flow UW Report |
| Broker Variance Analysis | Table | Cash Flow UW Report |
| Negative Carry / IR Sizing | Dollar + months | Cash Flow UW Report |
| Refinance Exit Test | Table | Cash Flow UW Report |
| Credit Metrics at Rec. Loan | Summary table | Cash Flow UW Report, IC Memo |
| Phase 9 JSON | Structured data | workflow-state/ |

## Quality Gates

- [ ] Used LENDER NOI (not Sponsor/Broker NOI)
- [ ] All 6 sizing constraints calculated
- [ ] Y1 DSCR and Y1 DY computed as analytical outputs ONLY (not in MIN)
- [ ] Binding constraint identified as MIN of 6 constraints
- [ ] Broker request compared AFTER sizing
- [ ] Recommended loan <= Broker request
- [ ] Negative carry analyzed if Day-1 DSCR < 1.00x
- [ ] Interest reserve sized with 25% cushion if negative carry
- [ ] Refinance exit test completed
- [ ] All constraint thresholds match credit_box_config.json v3.0
- [ ] SOFR and rate are EXACT values from macro pull (no rounding)

## Error Handling

| Error Condition | Detection | Resolution |
|---|---|---|
| Sponsor NOI used instead of Lender NOI | NOI source field mismatch | BLOCK: Return to Phase 6 for Lender UW |
| Missing As-Is value on refi | No appraisal and refi within 2 yrs | Use purchase price; flag in memo |
| SOFR not current | Macro pull date > 5 business days old | Re-run mcp__valeri-data__get_macro_indicators |
| Total Cost incomplete | Missing closing costs or reserves | Estimate at 2-3% of purchase; flag assumption |
| Rate mismatch | SOFR + spread != stated rate | BLOCK: Recalculate. Basic addition error is unacceptable. |
| Negative carry with no IR budget | Day-1 DSCR < 1.00x, no reserve line | BLOCK: Size IR reserve before proceeding |
| Constraint produces negative loan | NOI <= 0 or Value <= 0 | DECLINE: Cannot size a loan with no cash flow or value |
| LTC > 100% due to IR inclusion | IR holdback inflates total cost | Require sponsor to fund IR from equity |
| Broker request undefined | No loan ask in deal materials | Size to constraints; present range to sponsor |

## Worked Example: The Westmont -- 200 Units, Dallas TX

**Inputs (Lender Underwrite):**
```
Lender NOI (Y1):         $3,480,000  (sub-stabilized, 82% occupancy)
Lender NOI (Stab):       $5,200,000  (94% occupancy, lender rents)
Value As-Is:             $113,000,000 (appraised)
Value Stabilized:        $118,000,000 ($5.2M / 4.41% lender cap)
Total Cost:              $109,500,000 (purchase $102M + capex $5M + closing $2.5M)
Interest Rate:           7.33%  (SOFR 4.33% + 300 bps)
IO Period:               36 months
Broker Request:          $98,000,000
```

**6-Constraint Waterfall:**

| Constraint | Threshold | Calculation | Max Loan |
|---|---|---|---|
| LTC | 80% | $109.5M x 0.80 | $87,600,000 |
| LTV (As-Is) | 75% | $113.0M x 0.75 | $84,750,000 |
| LTV (Stabilized) | 75% | $118.0M x 0.75 | $88,500,000 |
| DSCR (Stabilized) | 1.05x | $5.2M / 1.05 / 0.0733 | $67,531,000 |
| DY (Stabilized) | 7.00% | $5.2M / 0.07 | $74,286,000 |

**BINDING: DSCR (Stabilized) at $67,531,000**

**Analytical Outputs (NOT constraints):**
```
DSCR (Y1) at $67.5M: $3.48M / ($67.5M x 7.33%) = $3.48M / $4.95M = 0.70x
  -> Negative carry expected. IR holdback required.
DY (Y1) at $67.5M: $3.48M / $67.5M = 5.16%
  -> Sub-stabilized, consistent with bridge thesis.
```

**Broker Comparison:**
```
Broker Request:   $98,000,000
Constrained Loan: $67,531,000
Variance:         $30,469,000 (+45.1%)
STATUS:           DECLINE -- exceeds constraints by >20%
```

**Negative Carry Analysis:**
```
Annual DS at $67.5M: $67,500,000 x 7.33% = $4,947,750
Annual NOI Y1:       $3,480,000
Annual Shortfall:    $1,467,750
Monthly Shortfall:   $122,313

Monthly NOI Growth:  ($5,200,000 - $3,480,000) / 24 months = $71,667
Months to Breakeven: $122,313 / $71,667 = 17.1 months
IR Reserve:          $122,313 x 17.1 x 1.25 = $2,612,437
                     Round to: $2,650,000
```

**Recommendation:**
```
Conservative: $67,500,000  (DSCR constrained, no exceptions)
Standard:     $70,000,000  (minor DSCR exception to 1.01x, mitigants required)
Stretch:      $74,000,000  (up to DY constraint, interest reserve + recourse)
Decline:      > $80,000,000

Recommended:  $67,500,000 (Conservative) with $2.65M interest reserve
```

## Version History

| Version | Date | Changes |
|---|---|---|
| 1.0 | Dec 2025 | Initial release |
| 2.0 | Dec 2025 | Added constraint enforcement, broker override rejection, negative carry |
| 3.0 | Feb 2026 | V3 Enterprise: Added frontmatter, error handling, IR interaction with sizing, refi exit test detail, credit_box_config.json reference, analytical vs. sizing distinction enforcement |
