---
name: cash-flow-modeling
version: 3.0
phase: 6
domain: financial-analysis
dependencies:
  - rent-roll-analysis (Phase 5A — in-place revenue)
  - expense-underwriting (Phase 5B — expense assumptions)
  - t12-analysis (Phase 6 — normalized baseline)
  - lender-underwritten-rent (Phase 4A — lender rents)
  - comp-analysis (Phase 4 — valuation inputs)
inputs:
  - input: Normalized T-12
    source: Phase 6 T-12 analysis
    required: true
  - input: Lender Underwritten Rents
    source: Phase 4A
    required: true
  - input: Lender expense assumptions
    source: Phase 5B
    required: true
  - input: Sponsor pro forma
    source: OM / Broker package
    required: true
  - input: Macro indicators (SOFR, Treasury curve)
    source: Phase 2A mcp__valeri-data__
    required: true
  - input: Cap rate conclusions
    source: Phase 4 Comparable Analysis
    required: true
outputs:
  - output: Cash_Flow_Underwriting_Analysis.docx
    format: V3.1 Elevated DOCX (30+ pages, consolidated Document 7)
  - output: phase_06_cashflow.json
    format: JSON workflow state
credit_box_config: v3.0
mcp_tools:
  - mcp__valeri-data__get_macro_indicators
design_system: Elevated V3.1 (Carbon Slate #2F363C, Calibri)
---

# Cash Flow Underwriting (Phase 6 — Consolidated Document 7 of 8)

## Purpose

Cash flow underwriting is the analytical core of the deal. This skill produces Document 7 of 8 — a consolidated analysis that combines dual-scenario cash flow modeling, valuation, loan sizing, structuring, sensitivity/stress testing, returns analysis, and the deal financials snapshot into a single comprehensive document.

The lender's job is to stress-test sponsor assumptions, not accept them. This skill enforces the dual-scenario discipline: Scenario 1 is the Sponsor Proforma (for reference only), and Scenario 2 is the Lender Underwrite (for loan sizing). The lender underwrite uses Phase 4A lender rents, Phase 5B lender expenses, and conservative growth assumptions. All loan sizing decisions flow from the Lender Underwrite NOI — never from the Sponsor Proforma.

CRITICAL RULES: ALWAYS produce two scenarios (Sponsor and Lender). ALWAYS use lender underwrite NOI for sizing. ALWAYS show the 6-constraint waterfall with formulas. ALWAYS show cap rate and vacancy sensitivity as SEPARATE tables. ALWAYS use the SOFR rate from Phase 2A get_macro_indicators — never hardcode or round rates. Reference credit_box_config.json v3.0 for all constraint thresholds.

## Inputs

| Input | Source | Required |
|-------|--------|----------|
| Normalized T-12 (baseline NOI) | Phase 6 T-12 analysis | Yes |
| Lender rents by unit type | Phase 4A | Yes |
| Lender expense assumptions ($/unit) | Phase 5B | Yes |
| Sponsor pro forma (Y1 and Stabilized) | OM / Broker | Yes |
| SOFR rate | Phase 2A mcp__valeri-data__ | Yes |
| Deal spread | Term sheet / Operator context | Yes |
| Loan term and structure | Term sheet | Yes |
| Cap rate conclusions | Phase 4 Comparable Analysis | Yes |
| Purchase price / As-Is value | OM / Appraisal | Yes |
| Total cost basis (price + capex + closing) | OM / Sponsor budget | Yes |

## Methodology

### CF-1: T-12 Baseline Extraction

Extract from normalized T-12 (Phase 6 output):
```
T12_GPR:          $[amount]
T12_Vacancy:      $[amount]  ([X]%)
T12_Concessions:  $[amount]  ([X]%)
T12_Bad_Debt:     $[amount]  ([X]%)
T12_Other_Income: $[amount]
T12_EGI:          $[amount]
T12_OpEx:         $[amount]
T12_NOI:          $[amount]
T12_Occupancy:    [X]%
```

### CF-2: Sponsor Proforma Extraction

Extract sponsor's Year 1 and Stabilized projections from the OM:
```
SPONSOR_GPR_Y1:           $[amount]
SPONSOR_Vacancy_Y1:       [X]%
SPONSOR_NOI_Y1:           $[amount]
SPONSOR_NOI_Stab:         $[amount]
SPONSOR_Rent_Growth:      [X]%
SPONSOR_Expense_Growth:   [X]%
SPONSOR_Stabilization_Yr: [X]
```

### CF-3: Variance Analysis (MANDATORY)

| Metric | T-12 | Sponsor Y1 | Variance | FLAG? |
|--------|------|------------|----------|-------|
| GPR | | | | |
| Vacancy | | | | |
| EGI | | | | |
| OpEx | | | | |
| NOI | | | | |

**Automatic flags:**
- Sponsor NOI Y1 > T-12 NOI x 1.20: FLAG — "NOI growth >20%, haircut required"
- Sponsor NOI Y1 > T-12 NOI x 1.50: FLAG — "NOI growth >50%, aggressive pro forma, major haircut required"
- Sponsor vacancy < T-12 vacancy AND T-12 vacancy > 5%: FLAG — "Vacancy below actuals"
- Sponsor vacancy < 5%: FLAG — "Vacancy below market floor — use 5% minimum"
- Sponsor OpEx/unit < T-12 OpEx/unit x 0.90: FLAG — "Expense reduction not justified"

### CF-4: Lender Underwrite Construction

Build the lender cash flow using Phase 4A rents and Phase 5B expenses:

**Income:**
```
Lender_GPR = Units x Lender_Rent_Per_Unit x 12
Lender_Vacancy = MAX(T12_Vacancy%, Market_Vacancy%, 5.0%)
Lender_Concessions = MAX(T12_Concessions%, 1.0%)
Lender_Bad_Debt = MAX(T12_Bad_Debt%, 0.5%)
Lender_Other_Income = MIN(Sponsor_Other_Income, Units x $100/mo x 12)
Lender_EGI = Lender_GPR x (1 - Vacancy - Concessions - Bad_Debt) + Other_Income
```

**Expenses:**
```
Lender_OpEx = Sum of all Phase 5B lender expense assumptions
Lender_Reserves = Units x $250-$350/unit/year (per vintage)
Lender_NOI_Y1 = Lender_EGI - Lender_OpEx - Lender_Reserves
```

**Sanity check:** If Lender NOI Y1 > T-12 NOI x 1.25, review assumptions — the lender underwrite should be more conservative than what the property is currently producing, unless occupancy has materially improved since the T-12 period.

### CF-5: Stabilized Projection

```
Lender_Rent_Growth = MIN(Sponsor_Rent_Growth, Market_Rent_Growth, 3.0%)
Lender_Expense_Growth = MAX(CPI_YoY, 3.0%)
Lender_Stabilized_Vacancy = CF-3 supportable vacancy (floored at 5.0%)

Lender_GPR_Stab = Lender_GPR_Y1 x (1 + Rent_Growth) ^ Years_to_Stabilization
Lender_EGI_Stab = Lender_GPR_Stab x (1 - Stab_Vacancy - 0.005 - 0.005) + Other_Income_Grown
Lender_OpEx_Stab = Lender_OpEx x (1 + Expense_Growth) ^ Years_to_Stabilization
Lender_NOI_Stab = Lender_EGI_Stab - Lender_OpEx_Stab - Reserves
```

### CF-6: 5-Year Pro Forma Projection

Build a year-by-year pro forma for the hold period (typically 3-5 years for bridge loans):

| Line Item | T-12 | Year 1 | Year 2 | Year 3 (Stab) | Year 4 | Year 5 |
|-----------|------|--------|--------|---------------|--------|--------|
| GPR | | | | | | |
| Vacancy | | | | | | |
| Concessions | | | | | | |
| Bad Debt | | | | | | |
| Other Income | | | | | | |
| **EGI** | | | | | | |
| OpEx | | | | | | |
| Reserves | | | | | | |
| **NOI** | | | | | | |

Growth assumptions applied:
- GPR: Lender rent growth per year
- Vacancy: Ramp down to stabilized over Years 1-3
- OpEx: Lender expense growth per year
- Other Income: 2% annual growth

### CF-7: Dual Scenario Output

**Scenario 1: Sponsor Proforma (REFERENCE ONLY — DO NOT USE FOR SIZING)**

| Line Item | T-12 | Sponsor Y1 | Sponsor Stab |
|-----------|------|------------|--------------|
| GPR | | | |
| Vacancy | | | |
| EGI | | | |
| OpEx | | | |
| NOI | | | |

**Scenario 2: Lender Underwrite (FOR SIZING)**

| Line Item | T-12 | Lender Y1 | Lender Stab | Haircut Applied |
|-----------|------|-----------|-------------|-----------------|
| GPR | | | | |
| Vacancy | | | | |
| EGI | | | | |
| OpEx | | | | |
| NOI | | | | |

### CF-8: 6-Constraint Sizing Waterfall

> **Cross-reference:** For the authoritative loan sizing methodology, see loan-sizing/SKILL.md. This section provides a summary for inclusion in Document 7.

Reference credit_box_config.json v3.0. Run all 6 constraints using LENDER STABILIZED NOI:

```
All-In Rate = SOFR + Spread = [exact from Phase 2A] + [deal spread]
Annual Debt Service (IO) = Loan Amount x All-In Rate

Constraint 1: Max LTV As-Is (75%)
  Max Loan = As_Is_Value x 0.75

Constraint 2: Max LTV Stabilized (75%)
  Stabilized Value = Lender_NOI_Stab / Cap_Rate
  Max Loan = Stabilized Value x 0.75

Constraint 3: Max LTC (80%)
  Total Cost = Purchase Price + CapEx + Closing Costs
  Max Loan = Total Cost x 0.80

Constraint 4: Min DSCR Stabilized (1.05x)
  Max Debt Service = Lender_NOI_Stab / 1.05
  Max Loan = Max Debt Service / All_In_Rate

Constraint 5: Min Debt Yield Stabilized (7.00%)
  Max Loan = Lender_NOI_Stab / 0.07

Constraint 6: Max Loan Amount ($100M)
  Max Loan = $100,000,000

BINDING CONSTRAINT = MIN(Constraint 1, 2, 3, 4, 5, 6)
```

Show the waterfall table:

| Constraint | Threshold | Basis | Max Loan | Binding? |
|------------|-----------|-------|----------|----------|
| LTV As-Is | 75.0% | $[As-Is Value] | $[Max] | |
| LTV Stabilized | 75.0% | $[Stab Value] | $[Max] | |
| LTC | 80.0% | $[Total Cost] | $[Max] | |
| DSCR Stabilized | 1.05x | $[Stab NOI] | $[Max] | |
| Debt Yield Stab | 7.0% | $[Stab NOI] | $[Max] | |
| Max Loan Amount | $100M | Program cap | $100.0M | |
| **Recommended** | | **Binding:** | **$[Min]** | |

Compare to broker request: if broker request > binding constraint, the loan is oversized. Recommend the binding constraint amount.

### CF-9: Sensitivity and Stress Testing

**Cap Rate Sensitivity (SEPARATE TABLE):**

| Cap Rate | Value | LTV | $/Unit |
|----------|-------|-----|--------|
| [Base-50bps] | | | |
| [Base-25bps] | | | |
| **[Base]** | | | |
| [Base+25bps] | | | |
| [Base+50bps] | | | |

**Vacancy Stress (SEPARATE TABLE):**

| Vacancy | EGI | NOI | DSCR |
|---------|-----|-----|------|
| **[Base]** | | | |
| [Base+5%] | | | |
| [Base+10%] | | | |
| [Base+15%] | | | |
| [Base+20%] | | | |

### CF-10: Analytical Outputs (NOT for Sizing)

Report Y1 in-place metrics as analytical outputs:
```
Y1 In-Place DSCR = Lender_NOI_Y1 / Annual_Debt_Service
  → Analytical only. May be below 1.0x on transitional deals.

Y1 In-Place DY = Lender_NOI_Y1 / Loan_Amount
  → Analytical only. Does not constrain sizing.

As-Is LTV = Loan_Amount / As_Is_Value
  → Analytical only. May exceed 75% on value-add basis.
```

## Outputs

Document 7 (Cash_Flow_Underwriting_Analysis.docx) includes all of the above plus:
- Sources & Uses table (full dollar format, must balance)
- Loan structuring summary (rate, term, IO period, extension options, covenants)
- Breakeven occupancy calculation
- Deal financials snapshot (per credit_box_config.json)
- Broker comparison summary

Minimum 30 pages.

## Quality Gates

- [ ] T-12 data extracted and validated against rent roll
- [ ] Sponsor proforma documented
- [ ] Variance analysis completed with all flags addressed
- [ ] Lender underwrite uses Phase 4A rents and Phase 5B expenses
- [ ] Dual scenario output produced (Sponsor vs. Lender)
- [ ] Lender NOI Stab <= T-12 NOI x 1.25 (or justified exception)
- [ ] 6-constraint waterfall shown with formulas and binding constraint identified
- [ ] SOFR rate from Phase 2A used exactly (not rounded or assumed)
- [ ] Cap rate and vacancy sensitivity are SEPARATE tables
- [ ] Sources = Uses (exact balance)
- [ ] All formatting follows VALERI_FORMAT_ENFORCER_v2.0

## Error Handling

| Error | Resolution |
|-------|-----------|
| Sponsor pro forma not provided | Build lender underwrite from T-12 + lender assumptions. Note "sponsor pro forma not available — lender underwrite is sole scenario" |
| SOFR rate from Phase 2A not available | Run mcp__valeri-data__get_macro_indicators. NEVER hardcode or assume a SOFR rate |
| Lender NOI exceeds T-12 x 1.25 even after haircuts | Review each assumption. Additional haircut may be needed on rent growth or vacancy. Document reasoning if justified (e.g., property was 60% occupied during T-12 and is now 92%) |
| Deal spread not provided by operator | Ask the operator. Do not assume a spread — it is a deal-specific term. Flag as "spread TBD — sizing pending operator confirmation" |
| 6-constraint waterfall shows negative DSCR coverage | Loan is not viable at the requested rate/amount. Report the maximum viable loan amount at each constraint. Consider if rate buydown or additional equity can cure |
| Sources do not equal Uses | STOP. This is a blocking error. Recheck all line items. Sources and Uses must balance exactly |
| Cap rate from Phase 4 not available | STOP. Phase 4 must be completed before valuation. Use Phase 4 cap rate conclusion |

## Worked Example

**Subject:** Oakwood Terrace — 200 units, Knox-Henderson, Dallas, TX. Purchase price: $38.0M. Total cost: $42.5M (price + $3.5M renovation + $1.0M closing/reserves). Broker requests $32.0M bridge loan.

**Rate Construction:**
- SOFR (from Phase 2A): 4.30%
- Deal Spread: S+325 bps
- All-In Rate: 4.30% + 3.25% = 7.55%

**Dual Scenario Summary:**

| Line Item | T-12 Normalized | Lender Y1 | Lender Stab (Y3) | Sponsor Stab |
|-----------|----------------|-----------|-------------------|--------------|
| GPR | $3,525,600 | $3,564,000 | $3,708,422 | $3,890,000 |
| Vacancy | (12.0%) | (7.0%) | (7.0%) | (5.0%) |
| Concessions | (2.0%) | (1.5%) | (0.5%) | (0.5%) |
| Bad Debt | (1.0%) | (0.5%) | (0.5%) | (0.3%) |
| Other Income | $120,000 | $120,000 | $124,848 | $145,000 |
| **EGI** | $3,188,052 | $3,370,500 | $3,537,970 | $3,765,300 |
| OpEx | $1,492,718 | $1,492,718 | $1,583,632 | $1,420,000 |
| Reserves | $60,000 | $60,000 | $60,000 | $50,000 |
| **NOI** | **$1,635,334** | **$1,817,782** | **$1,894,338** | **$2,295,300** |

**6-Constraint Sizing Waterfall:**

| Constraint | Threshold | Basis | Max Loan | Binding? |
|------------|-----------|-------|----------|----------|
| LTV Stabilized | 75.0% | $36.1M value ($1,894,338 / 5.25%) | $27.1M | |
| LTC | 80.0% | $42.5M total cost | $34.0M | |
| DSCR Stab | 1.05x | $1,894,338 NOI | $23.9M | BINDING |
| DY Stab | 7.0% | $1,894,338 NOI | $27.1M | |
| Max Loan | $100M | Program cap | $100.0M | |

```
DSCR constraint calculation:
  Max DS = $1,894,338 / 1.05 = $1,804,131
  Max Loan = $1,804,131 / 0.0755 = $23,896,437
  Round to: $23.9M
```

**Recommendation:** $23.9M (DSCR Stab binding at 1.05x). Broker requested $32.0M — $8.1M gap. The deal needs additional equity or a lower rate to size to the broker's request.

**Vacancy Stress:**

| Vacancy | EGI | NOI | DSCR |
|---------|-----|-----|------|
| **7.0%** | **$3,537,970** | **$1,894,338** | **1.05x** |
| 12.0% | $3,352,497 | $1,708,865 | 0.95x |
| 17.0% | $3,167,023 | $1,523,391 | 0.84x |
| 22.0% | $2,981,550 | $1,337,918 | 0.74x |
| 27.0% | $2,796,076 | $1,152,444 | 0.64x |

At 12% vacancy (5% above base), DSCR falls below 1.00x — limited cushion. The property needs to maintain at or near stabilized occupancy for debt service coverage.
