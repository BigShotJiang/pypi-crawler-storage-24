"""
pinchfin API — Skill Prompt Builder
=====================================
Loads bundled SKILL.md files and builds analysis prompts
for Claude API calls. Uses SkillLoader for structured parsing.

Methodology injection: load_methodology() reads the Quick Analysis
methodology spec and prepends it to every Claude call for full v9
analytical framework coverage.

(c) Veleta Capital LLC. All rights reserved.
"""

import json
import logging
import os
from pathlib import Path
from typing import Optional

LOG = logging.getLogger("pinchfin.analysis.prompts")

_SKILLS_DIR = Path(__file__).parent / "config" / "skills"


def load_skill(name: str) -> str:
    """
    Load a bundled SKILL.md file by name using structured parser.

    Args:
        name: Skill directory name (e.g. "sponsor-analysis")

    Returns:
        Structured skill content (up to 20K chars), or empty string if not found.
    """
    from api.analysis.skill_loader import load_skill_full
    return load_skill_full(name)


def load_skill_raw(name: str) -> str:
    """
    Load raw SKILL.md text without parsing (legacy compatibility).

    Args:
        name: Skill directory name (e.g. "sponsor-analysis")

    Returns:
        Raw contents of the SKILL.md file, or empty string if not found.
    """
    skill_path = _SKILLS_DIR / name / "SKILL.md"
    if not skill_path.exists():
        LOG.warning("Skill file not found: %s", skill_path)
        return ""
    return skill_path.read_text(encoding="utf-8")


def load_methodology() -> str:
    """Load the Quick Analysis methodology spec for deep prompt injection.

    Reads QUICK_ANALYSIS_METHODOLOGY.md from the config directory and returns
    its contents (truncated to 15K chars to stay within prompt budget).

    Returns:
        Methodology text, or empty string if the file is not found.
    """
    methodology_path = os.path.join(
        os.path.dirname(__file__), "config", "QUICK_ANALYSIS_METHODOLOGY.md"
    )
    try:
        with open(methodology_path, "r", encoding="utf-8") as f:
            text = f.read()
        # Truncate if too long (keep under 15K chars for prompt budget)
        if len(text) > 15000:
            text = text[:15000] + "\n\n[TRUNCATED — methodology continues]"
        return text
    except FileNotFoundError:
        LOG.warning("Quick Analysis methodology not found at %s", methodology_path)
        return ""


# ─────────────────────────────────────────────────────────────────────────
# Memo Format Specs — LOCKED output instructions for QR memos
# ─────────────────────────────────────────────────────────────────────────

# Map tool names to their format spec files
_FORMAT_SPEC_FILES = {
    "quick_review": "QUICK_REVIEW_MEMO_FORMAT_SPEC.md",
    "pref_equity_qr": "PREF_EQUITY_QR_MEMO_FORMAT_SPEC.md",
}


def load_memo_format_spec(tool_name: str) -> str:
    """Load the locked memo format spec for a QR tool.

    These are the AUTHORITATIVE output format instructions from
    Valeri Design - Elevated (3/19/2026). Every QR memo output
    MUST conform to these specs exactly.

    Args:
        tool_name: Analysis tool name (e.g. "quick_review", "pref_equity_qr")

    Returns:
        Full format spec text (truncated to 20K chars for prompt budget),
        or empty string if no spec exists for this tool.
    """
    spec_file = _FORMAT_SPEC_FILES.get(tool_name)
    if not spec_file:
        return ""

    spec_path = os.path.join(os.path.dirname(__file__), "config", spec_file)
    try:
        with open(spec_path, "r", encoding="utf-8") as f:
            text = f.read()
        if len(text) > 20000:
            text = text[:20000] + "\n\n[TRUNCATED — format spec continues]"
        LOG.info("Loaded memo format spec: %s (%d chars)", spec_file, len(text))
        return text
    except FileNotFoundError:
        LOG.warning("Memo format spec not found: %s", spec_path)
        return ""


def extract_methodology_section(methodology: str, section_markers: list[str]) -> str:
    """Extract a subset of the methodology relevant to a specific analysis phase.

    Scans the methodology text for lines containing any of the section_markers
    and captures content under matching headers until the next same-level or
    higher-level header is encountered.

    Args:
        methodology: Full methodology text from load_methodology().
        section_markers: List of case-insensitive substrings to match in headers.
            Example: ["Phase 2", "Sponsor", "Report 1"]

    Returns:
        Extracted sections concatenated, or empty string if nothing matched.
    """
    if not methodology or not section_markers:
        return ""

    import re

    lines = methodology.split("\n")
    results: list[str] = []
    capturing = False
    current_level = 0

    for line in lines:
        header_match = re.match(r"^(#{1,4})\s+(.+)", line)
        if header_match:
            level = len(header_match.group(1))
            title = header_match.group(2).strip().lower()

            matched = any(m.lower() in title for m in section_markers)

            if matched:
                capturing = True
                current_level = level
                results.append(line)  # Include the header itself
                continue
            elif capturing and level <= current_level:
                capturing = False
                continue

        if capturing:
            results.append(line)

    extracted = "\n".join(results).strip()
    # Cap at 5K chars per section extract to avoid bloating prompts
    if len(extracted) > 5000:
        extracted = extracted[:5000] + "\n\n[... section truncated]"
    return extracted


# ─────────────────────────────────────────────────────────────────────────
# Format enforcement rules injected into every system prompt
# ─────────────────────────────────────────────────────────────────────────

FORMAT_RULES = """
=== FORMAT ENFORCEMENT (MANDATORY) ===
- DSCR: X.XXx (two decimals + x). Example: 1.18x
- Debt Yield: X.X% (one decimal). Example: 7.8%
- LTV/LTC: XX.X% (one decimal). Example: 64.1%
- Cap Rate: X.XX% (ALWAYS two decimals). Example: 5.25%
- Interest Rate: X.XX% (ALWAYS two decimals). Example: 7.50%
- Dollar amounts $1M+: $X.XM (one decimal). Example: $42.0M
- Dollar amounts $100K-$999K: $XXXK (no decimals). Example: $840K
- Dollar amounts <$100K: full format. Example: $45,000
- $/unit: commas, no decimals. Example: $327,745/unit
- Status: ✓ (pass) / ✗ (fail). NEVER "ok", "pass", "fail", "yes", "no"
- Sources = Uses must balance exactly
- Show all calculation work
""".strip()


def build_analysis_prompt(
    skill_text: str,
    deal_data: dict,
    external_data: Optional[dict] = None,
    task_description: str = "",
    json_schema: Optional[dict] = None,
    methodology: str = "",
    memo_format_spec: str = "",
) -> tuple:
    """
    Build system + user prompt pair for a Claude analysis call.

    Args:
        skill_text: Structured skill methodology text
        deal_data: Deal parameters as dict
        external_data: External research/data as dict
        task_description: What Claude should produce
        json_schema: Optional JSON schema for structured output
        methodology: Optional Quick Analysis methodology text. When provided,
            prepended to the system prompt BEFORE the skill text so that
            every Claude call gets the full analytical framework.
        memo_format_spec: Optional memo format spec (LOCKED output instructions).
            When provided, injected AFTER methodology and BEFORE skill text.
            This is the authoritative output format for QR memos.

    Returns:
        (system_prompt, user_prompt) tuple of strings.
    """
    system_parts = [
        "You are PinchFin, an institutional-grade CRE credit analysis platform.",
        "You produce comprehensive, quantitative analysis for commercial real estate lending professionals.",
        "Use precise numbers, show your work, and cite data sources.",
        "Every analysis must be thorough — institutional depth, not summaries.",
        "Produce narrative-first content with tables that support the narrative.",
        "",
        FORMAT_RULES,
        "",
    ]

    # Methodology injection — prepended BEFORE skill text so the full
    # analytical framework is available to every Claude call
    if methodology:
        system_parts.append("=== QUICK ANALYSIS METHODOLOGY (v9) ===")
        if len(methodology) > 15_000:
            methodology = methodology[:15_000] + "\n[... methodology truncated]"
        system_parts.append(methodology)
        system_parts.append("")

    # Memo format spec injection — LOCKED output format for QR memos.
    # Injected AFTER methodology but BEFORE skill text so it governs
    # the output structure. This is the AUTHORITATIVE format.
    if memo_format_spec:
        system_parts.append("=== MEMO FORMAT SPECIFICATION (LOCKED — DO NOT DEVIATE) ===")
        system_parts.append(
            "The following format specification is the AUTHORITATIVE output format. "
            "Every section, table, KV pair, and formatting rule below MUST be followed "
            "exactly. This spec overrides any conflicting instructions in the skill text."
        )
        if len(memo_format_spec) > 20_000:
            memo_format_spec = memo_format_spec[:20_000] + "\n[... format spec truncated]"
        system_parts.append(memo_format_spec)
        system_parts.append("")

    if skill_text:
        system_parts.append("=== ANALYSIS METHODOLOGY ===")
        # Truncation now handled by SkillLoader (20K max)
        if len(skill_text) > 20_000:
            skill_text = skill_text[:20_000] + "\n[... truncated for API call]"
        system_parts.append(skill_text)

    if json_schema:
        system_parts.append("")
        system_parts.append("=== REQUIRED OUTPUT FORMAT ===")
        system_parts.append(
            "You MUST respond with a valid JSON object conforming to this schema. "
            "Do NOT include markdown fences, commentary, or text outside the JSON object."
        )
        system_parts.append(json.dumps(json_schema, indent=2))

    system_prompt = "\n".join(system_parts)

    # Build user prompt
    user_parts = []

    if task_description:
        user_parts.append(task_description)
        user_parts.append("")

    user_parts.append("=== DEAL DATA ===")
    user_parts.append(json.dumps(deal_data, indent=2, default=str))

    if external_data:
        user_parts.append("")
        user_parts.append("=== EXTERNAL DATA (Verified Sources) ===")
        user_parts.append(json.dumps(external_data, indent=2, default=str))

    user_prompt = "\n".join(user_parts)

    return system_prompt, user_prompt
