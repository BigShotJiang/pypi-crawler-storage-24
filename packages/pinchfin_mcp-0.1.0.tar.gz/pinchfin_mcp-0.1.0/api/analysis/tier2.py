"""
pinchfin API — Tier 2 Analysis Functions (Research-Heavy)
==========================================================
These tools use Perplexity for market research and Claude for synthesis.
Higher API cost, slower execution, richer output.

5. analyze_sponsor — 8 Perplexity queries (parallel) + Claude synthesis
6. analyze_market — valeri-data + 8 Perplexity queries + Claude synthesis
7. analyze_comps — valeri-data + 5 Perplexity queries + Claude synthesis

Architecture Reset: Full SKILL.md methodology via SkillLoader,
structured JSON output via call_claude_structured(), max_tokens 8192.

(c) Veleta Capital LLC. All rights reserved.
"""

import asyncio
import logging
from typing import Optional

from api.analysis.clients import (
    call_claude_structured,
    call_perplexity,
    call_valeri_data,
    get_current_sofr,
)
from api.analysis.prompts import load_skill, build_analysis_prompt
from api.analysis.schemas import get_json_schema, validate_output

LOG = logging.getLogger("pinchfin.analysis.tier2")


async def _parallel_perplexity(queries: list, meter=None) -> list:
    """Run multiple Perplexity queries in parallel."""
    tasks = [call_perplexity(q, meter=meter) for q in queries]
    return await asyncio.gather(*tasks, return_exceptions=True)


async def analyze_sponsor(req, meter=None, methodology_override: str = "") -> dict:
    """
    Real sponsor analysis: 8 Perplexity queries + Claude synthesis.

    Uses full sponsor-analysis SKILL.md methodology (567 lines):
    - 8-step institutional due diligence
    - Tier classification (A/A-/B+/B/B-/C/D with scoring rubric)
    - 7-category risk matrix
    - Relevant experience scoring (4 dimensions × 3 points)
    - GO/NO-GO recommendation
    """
    sponsor = req.sponsor_name

    # 1. Parallel Perplexity research (8 queries per skill methodology)
    queries = [
        f"{sponsor} real estate company portfolio overview total units markets",
        f"{sponsor} multifamily acquisitions transactions deal history",
        f"{sponsor} principals founders leadership team background",
        f"{sponsor} litigation lawsuits legal issues court filings",
        f"{sponsor} bankruptcy defaults foreclosures loan performance",
        f"{sponsor} capital partners investors equity institutional relationships",
        f"{sponsor} property management operations track record reviews",
        f"{sponsor} real estate investments recent news transactions 2024 2025 2026",
    ]

    results = await _parallel_perplexity(queries, meter=meter)

    # Collect successful results
    research_data = {}
    query_labels = [
        "portfolio", "transactions", "leadership", "litigation",
        "defaults", "capital_partners", "property_management", "recent_news",
    ]
    for label, result in zip(query_labels, results):
        if isinstance(result, str) and result:
            research_data[label] = result
        elif isinstance(result, Exception):
            LOG.warning("Perplexity query failed for %s: %s", label, result)

    # 2. Claude synthesis with full skill methodology
    skill_text = load_skill("sponsor-analysis")

    deal_data = {
        "sponsor_name": sponsor,
        "sponsor_website": req.sponsor_website,
        "additional_context": req.additional_context,
    }

    # Get JSON schema for structured output
    schema = get_json_schema("sponsor_analysis")

    system, user = build_analysis_prompt(
        skill_text=skill_text,
        deal_data=deal_data,
        external_data=research_data,
        json_schema=schema,
        task_description=(
            "Analyze this CRE sponsor for institutional bridge lending using the full "
            "8-step methodology provided. Produce a comprehensive, institutional-grade "
            "sponsor analysis as a structured JSON object.\n\n"
            "DEPTH REQUIREMENTS:\n"
            "- Entity overview: legal structure, principals, HQ, portfolio size, markets\n"
            "- Track record: total deals, units, multifamily focus %, notable transactions\n"
            "- Financial capacity: net worth assessment, NW/loan ratio, liquidity, leverage\n"
            "- Background check: litigation findings, defaults, bankruptcy, regulatory\n"
            "- Operational capability: PM platform, renovation execution, lease-up\n"
            "- Relevant experience score: rate 0-12 across 4 dimensions\n"
            "- Sponsor tier: classify using the rubric (A/A-/B+/B/B-/C/D)\n"
            "- Strengths: 3-5 specific, evidence-based strengths\n"
            "- Concerns: 3-5 specific concerns with severity\n"
            "- GO/NO-GO recommendation with detailed rationale\n\n"
            "Base analysis on the research data provided. If research data is limited, "
            "note what could not be verified and adjust tier accordingly."
        ),
        methodology=methodology_override,
    )

    parsed = await call_claude_structured(system, user, meter=meter, max_tokens=8192)

    # Validate and enrich
    parsed["analysis_mode"] = "real"
    parsed["research_queries_executed"] = len([r for r in results if isinstance(r, str) and r])

    # Validate against schema (non-blocking — log if invalid)
    validated = validate_output("sponsor_analysis", parsed)
    if validated:
        LOG.info("Sponsor analysis output validated against schema")
    else:
        LOG.warning("Sponsor analysis output did not fully match schema — returning raw")

    return parsed


async def analyze_market(req, meter=None, methodology_override: str = "") -> dict:
    """
    Real market analysis: valeri-data demographics + Perplexity research + Claude synthesis.

    Uses full market-submarket SKILL.md methodology (379 lines):
    - 8-step MSA and submarket analysis
    - Employment deep dive with affordability test
    - 5-year historical trend analysis
    - Supply pipeline risk rating
    - Supportable assumptions derivation
    """
    address = req.property_address

    # 1. Pull verified data from Valeri Data Services
    property_context = await call_valeri_data(
        "property-context",
        {"address": address},
        meter=meter,
    )
    macro = await call_valeri_data("macro-indicators", {}, meter=meter)

    # 2. Parallel Perplexity research (8 queries per skill methodology)
    addr_parts = address.split(",")
    city = addr_parts[-2].strip() if len(addr_parts) >= 3 else addr_parts[0]
    state = addr_parts[-1].strip().split()[0] if len(addr_parts) >= 2 else ""
    msa = f"{city}, {state}"

    queries = [
        f"{msa} MSA population growth demographics income trends 2024 2025 2026",
        f"{msa} employment largest employers job growth industry diversification",
        f"{msa} multifamily apartment market vacancy rates occupancy trends",
        f"{msa} apartment rent growth trends effective rents 2024 2025 2026",
        f"{msa} multifamily construction pipeline new supply deliveries permits",
        f"{msa} multifamily absorption demand net absorption units",
        f"{city} {state} apartment submarket overview neighborhood analysis",
        f"{msa} rent control housing regulations tenant protections policy",
    ]

    results = await _parallel_perplexity(queries, meter=meter)

    research_data = {}
    query_labels = [
        "demographics", "employment", "vacancy", "rent_growth",
        "supply_pipeline", "absorption", "submarket", "regulations",
    ]
    for label, result in zip(query_labels, results):
        if isinstance(result, str) and result:
            research_data[label] = result

    # 3. Claude synthesis with full skill methodology
    skill_text = load_skill("market-submarket")

    deal_data = {
        "property_address": address,
        "msa": msa,
        "radius_miles": req.radius_miles or 3.0,
    }

    external_data = {
        "valeri_data_services": {
            "property_context": property_context,
            "macro_indicators": macro,
        },
        "perplexity_research": research_data,
    }

    schema = get_json_schema("market_research")

    system, user = build_analysis_prompt(
        skill_text=skill_text,
        deal_data=deal_data,
        external_data=external_data,
        json_schema=schema,
        task_description=(
            "Analyze this CRE market for institutional bridge lending using the full "
            "8-step methodology provided. Produce a comprehensive, institutional-grade "
            "market analysis as a structured JSON object.\n\n"
            "DEPTH REQUIREMENTS:\n"
            "- MSA profile: population, growth, income, cost of living, economic drivers\n"
            "- Employment: unemployment rate, job growth %, top employers, diversification\n"
            "- Multifamily fundamentals: vacancy, effective rents, rent growth YoY, absorption\n"
            "- Supply pipeline: units under construction, planned, % of inventory, risk rating\n"
            "- Submarket deep dive: vacancy, rents, growth, class mix, competitive set\n"
            "- Regulatory environment: rent control status, housing regulations\n"
            "- Supportable assumptions: rent growth, vacancy, exit cap, expense growth with justification\n"
            "- Strengths: 3-5 specific market strengths with evidence\n"
            "- Risks: 3-5 specific market risks with severity\n"
            "- Market rating: strong/moderate/weak with rationale\n\n"
            "Use verified data from Valeri Data Services as baseline. Research data supplements."
        ),
        methodology=methodology_override,
    )

    parsed = await call_claude_structured(system, user, meter=meter, max_tokens=8192)

    parsed["analysis_mode"] = "real"
    parsed["data_sources"] = {
        "valeri_data_services": bool(property_context),
        "perplexity_queries": len([r for r in results if isinstance(r, str) and r]),
    }

    validated = validate_output("market_research", parsed)
    if validated:
        LOG.info("Market analysis output validated against schema")

    return parsed


async def analyze_comps(req, meter=None, methodology_override: str = "") -> dict:
    """
    Real comparable analysis: valeri-data + Perplexity research + Claude synthesis.

    Uses full comp-analysis SKILL.md methodology (400 lines):
    - MAI-compliant comparable selection
    - Rent comp adjustment grid (6 categories)
    - Sales comp adjustments (time, condition, scale, location)
    - Market rent conclusion by unit type
    - Valuation synthesis (As-Is & As-Stabilized)
    """
    address = req.property_address

    # 1. Pull data from Valeri Data Services
    walk_score = await call_valeri_data(
        "walk-score",
        {"address": address},
        meter=meter,
    )
    hud_data = await call_valeri_data(
        "hud-data",
        {"address": address},
        meter=meter,
    )
    market_rents = await call_valeri_data(
        "market-rent-survey",
        {"address": address},
        meter=meter,
    )

    # 2. Perplexity research (5+ queries per skill methodology)
    addr_parts = address.split(",")
    city = addr_parts[-2].strip() if len(addr_parts) >= 3 else addr_parts[0]
    state = addr_parts[-1].strip().split()[0] if len(addr_parts) >= 2 else ""
    submarket = f"{city}, {state}"

    asset_class = req.asset_class or "B"
    unit_count = req.unit_count or 0
    year_built = req.year_built or 0

    queries = [
        f"{address} comparable apartments nearby similar properties {unit_count} units",
        f"{submarket} apartment rent comps Class {asset_class} {year_built} vintage",
        f"{submarket} multifamily sales transactions 2024 2025 2026 price per unit",
        f"{submarket} apartment sales cap rates multifamily investment market",
        f"{submarket} Class {asset_class} apartment rents per unit per SF amenities",
    ]

    results = await _parallel_perplexity(queries, meter=meter)

    research_data = {}
    query_labels = ["nearby", "rent_comps", "sales", "cap_rates", "class_rents"]
    for label, result in zip(query_labels, results):
        if isinstance(result, str) and result:
            research_data[label] = result

    # 3. Claude synthesis with full skill methodology
    skill_text = load_skill("comp-analysis")

    deal_data = {
        "property_address": address,
        "unit_count": unit_count,
        "asset_class": asset_class,
        "year_built": year_built,
        "comp_types": req.comp_types or ["sales", "rent"],
    }

    external_data = {
        "valeri_data_services": {
            "walk_score": walk_score,
            "hud_fmr": hud_data,
            "market_rent_survey": market_rents,
        },
        "perplexity_research": research_data,
    }

    schema = get_json_schema("comp_analysis")

    system, user = build_analysis_prompt(
        skill_text=skill_text,
        deal_data=deal_data,
        external_data=external_data,
        json_schema=schema,
        task_description=(
            "Analyze comparable properties for this CRE deal using the full MAI-compliant "
            "methodology provided. Produce a comprehensive, institutional-grade comparable "
            "analysis as a structured JSON object.\n\n"
            "DEPTH REQUIREMENTS:\n"
            "- Rent comps: 5-7 comps minimum with name, address, units, year built, avg rent, "
            "distance, occupancy, adjustment grid (location, age, SF, amenities, concessions), "
            "adjusted rent\n"
            "- Sales comps: 3-5 comps with name, address, units, sale price, price/unit, cap rate, "
            "sale date, adjustments (time, condition, scale, location), adjusted price/unit\n"
            "- Rent analysis: market rent conclusion by unit type, loss-to-lease calculation\n"
            "- Value analysis: income approach valuation, As-Is and As-Stabilized values\n"
            "- Strengths and concerns with evidence\n\n"
            "Extract specific comp data from research. If data is limited, note the gaps."
        ),
        methodology=methodology_override,
    )

    parsed = await call_claude_structured(system, user, meter=meter, max_tokens=8192)

    parsed["analysis_mode"] = "real"
    parsed["data_sources"] = {
        "walk_score": bool(walk_score),
        "hud_fmr": bool(hud_data),
        "market_rent_survey": bool(market_rents),
        "perplexity_queries": len([r for r in results if isinstance(r, str) and r]),
    }

    validated = validate_output("comp_analysis", parsed)
    if validated:
        LOG.info("Comp analysis output validated against schema")

    return parsed
