"""
pinchfin API — Tier 1 Analysis Functions (Deterministic + Claude Narrative)
============================================================================
These tools are primarily deterministic (constraint waterfall math) with
Claude providing narrative synthesis. Low API cost, fast execution.

1. analyze_deal_screen — SOFR from valeri-data, constraint waterfall, Claude narrative
2. analyze_debt_sizing_preview — Same waterfall, lighter analysis + narrative
3. analyze_loan_sizer — Full waterfall + binding constraint detail
4. analyze_loan_pricing — SOFR + spread build-up, rate cap, IR sizing + narrative

(c) Veleta Capital LLC. All rights reserved.
"""

import logging

from api.analysis.credit_box import run_constraint_waterfall
from api.analysis.clients import call_claude, call_claude_structured, get_current_sofr, call_valeri_data
from api.analysis.prompts import load_skill, build_analysis_prompt
from api.analysis.schemas import get_json_schema, validate_output

LOG = logging.getLogger("pinchfin.analysis.tier1")

# Default spread assumption (bps)
DEFAULT_SPREAD_BPS = 350


async def analyze_deal_screen(req, meter=None) -> dict:
    """
    Real deal screening: SOFR from data services + property context + constraint
    waterfall + Claude structured narrative via loan-sizing skill.
    """
    # 1. Get current SOFR
    sofr = await get_current_sofr(meter=meter)
    spread_bps = DEFAULT_SPREAD_BPS
    all_in_rate = (sofr + spread_bps / 100) / 100  # decimal

    # 2. Pull property context from Valeri Data Services
    property_context = await call_valeri_data(
        "property-context",
        {"address": req.property_address},
        meter=meter,
    )

    # 3. Derive values
    asset_value = req.asset_value or req.purchase_price or req.loan_amount * 1.4
    stabilized_value = asset_value * 1.08
    total_cost = asset_value + (req.unit_count * 15000)
    noi_stabilized = stabilized_value * 0.0525

    # 4. Run deterministic waterfall
    waterfall = run_constraint_waterfall(
        loan_amount=req.loan_amount,
        as_is_value=asset_value,
        stabilized_value=stabilized_value,
        total_cost=total_cost,
        noi=noi_stabilized,
        rate=all_in_rate,
        unit_count=req.unit_count,
    )

    # 5. Build deal data for Claude narrative
    deal_data = {
        "property_address": req.property_address,
        "unit_count": req.unit_count,
        "loan_amount": req.loan_amount,
        "asset_value": asset_value,
        "stabilized_value": stabilized_value,
        "total_cost": total_cost,
        "noi_stabilized": noi_stabilized,
        "sofr": sofr,
        "spread_bps": spread_bps,
        "all_in_rate_pct": round(all_in_rate * 100, 2),
        "loan_purpose": req.loan_purpose or "bridge",
        "sponsor_name": req.sponsor_name,
        "waterfall": waterfall,
    }

    # Include property context in deal_data so Claude has real data
    if property_context:
        deal_data["property_context"] = property_context

    # 6. Load loan-sizing skill for institutional methodology
    skill_text = load_skill("loan-sizing")

    # 7. Get JSON schema for structured output
    json_schema = get_json_schema("deal_screen")

    # 8. Claude structured narrative synthesis
    system, user = build_analysis_prompt(
        skill_text=skill_text,
        deal_data=deal_data,
        task_description=(
            "Produce an institutional credit screening analysis for this deal. "
            "Assess whether it passes or fails the 6-constraint credit box waterfall. "
            "Identify the binding constraint and explain why it governs. "
            "Evaluate the property context data (demographics, employment, flood zone, "
            "walk score) and flag any location-level risks or strengths. "
            "Note any credit flags or concerns with specific numbers. "
            "Provide a 3-5 sentence narrative summary suitable for a credit committee "
            "screening deck."
        ),
        json_schema=json_schema,
    )

    claude_result = await call_claude_structured(
        system, user, meter=meter, max_tokens=4096
    )

    # Extract narrative from Claude's structured response
    narrative = None
    if isinstance(claude_result, dict):
        # Validate against schema
        validated = validate_output("deal_screen", claude_result)
        narrative = claude_result.get("summary") or claude_result.get("narrative")

    # 9. Build response (same shape as before for backwards compatibility)
    constraints = waterfall["constraints"]
    binding_key = waterfall["binding_constraint"]
    max_loan = waterfall["max_loan"]
    all_pass = waterfall["all_pass"]

    flags = []
    if constraints["ltv_as_is"]["value"] > 72.0:
        flags.append({
            "flag": "ltv_elevated",
            "detail": f"As-Is LTV at {constraints['ltv_as_is']['value']:.1f}% approaching 75% ceiling",
        })
    if constraints["dscr_stabilized"]["value"] < 1.15:
        flags.append({
            "flag": "thin_dscr_cushion",
            "detail": f"Stabilized DSCR of {constraints['dscr_stabilized']['value']:.2f}x has limited cushion above 1.05x floor",
        })
    if req.unit_count < 50:
        flags.append({
            "flag": "small_asset",
            "detail": f"{req.unit_count}-unit asset may have limited operational scale",
        })

    return {
        "status": "pass" if all_pass else "fail",
        "analysis_mode": "real",
        "credit_box": {
            k: {**v} for k, v in constraints.items()
        },
        "binding_constraint": binding_key,
        "property": {
            "address": req.property_address,
            "unit_count": req.unit_count,
            "asset_value": round(asset_value, 0),
            "asset_value_per_unit": round(asset_value / req.unit_count, 0),
            "stabilized_value": round(stabilized_value, 0),
            "stabilized_value_per_unit": round(stabilized_value / req.unit_count, 0),
            "estimated_capex": round(req.unit_count * 15000, 0),
            "total_cost": round(total_cost, 0),
        },
        "loan": {
            "requested_amount": req.loan_amount,
            "requested_per_unit": round(req.loan_amount / req.unit_count, 0),
            "max_from_waterfall": round(max_loan, 0),
            "max_per_unit": round(max_loan / req.unit_count, 0),
            "binding_constraint": binding_key,
            "loan_purpose": req.loan_purpose or "bridge",
            "rate_assumption": f"SOFR ({sofr:.2f}%) + {spread_bps} bps ({all_in_rate * 100:.2f}% all-in)",
        },
        "key_metrics": waterfall["metrics"],
        "flags": flags,
        "property_context": property_context,
        "summary": narrative or (
            f"Deal {'meets' if all_pass else 'FAILS'} credit box criteria. "
            f"Binding constraint: {binding_key}."
        ),
    }


async def analyze_debt_sizing_preview(req, meter=None) -> dict:
    """
    Quick debt sizing preview — lighter version of full loan sizer with
    Claude narrative explaining the binding constraint and max loan.
    """
    sofr = await get_current_sofr(meter=meter)
    all_in_rate = (sofr + DEFAULT_SPREAD_BPS / 100) / 100

    total_cost = req.total_cost or req.asset_value
    stabilized_value = req.asset_value * 1.08

    waterfall = run_constraint_waterfall(
        loan_amount=req.noi / 0.07,  # Use DY-implied loan as reference
        as_is_value=req.asset_value,
        stabilized_value=stabilized_value,
        total_cost=total_cost,
        noi=req.noi,
        rate=all_in_rate,
        unit_count=req.unit_count,
    )

    # Load loan-sizing skill for institutional methodology
    skill_text = load_skill("loan-sizing")

    # Get JSON schema for structured output
    json_schema = get_json_schema("debt_sizing_preview")

    # Build deal data for Claude narrative
    deal_data = {
        "asset_value": req.asset_value,
        "stabilized_value": stabilized_value,
        "total_cost": total_cost,
        "noi": req.noi,
        "unit_count": req.unit_count,
        "sofr": sofr,
        "spread_bps": DEFAULT_SPREAD_BPS,
        "all_in_rate_pct": round(all_in_rate * 100, 2),
        "waterfall": waterfall,
    }

    # Claude structured narrative synthesis
    system, user = build_analysis_prompt(
        skill_text=skill_text,
        deal_data=deal_data,
        task_description=(
            "Produce a 2-3 sentence debt sizing preview narrative. "
            "Identify the binding constraint and explain why it governs the maximum loan amount. "
            "State the max loan from the waterfall and what it implies per unit. "
            "Be specific with numbers. Respond as a JSON object with a 'narrative' field."
        ),
        json_schema=json_schema,
    )

    claude_result = await call_claude_structured(
        system, user, meter=meter, max_tokens=4096
    )

    # Extract narrative from Claude's structured response
    narrative = None
    if isinstance(claude_result, dict):
        validated = validate_output("debt_sizing_preview", claude_result)
        narrative = claude_result.get("narrative") or claude_result.get("summary")

    # Build default narrative fallback from deterministic data
    binding_key = waterfall["binding_constraint"]
    max_loan = waterfall["max_loan"]
    default_narrative = (
        f"The 6-constraint credit box waterfall sizes the maximum loan at "
        f"${max_loan:,.0f} (${waterfall['max_loan_per_unit']:,}/unit), "
        f"with {binding_key.replace('_', ' ')} as the binding constraint at "
        f"a {all_in_rate * 100:.2f}% all-in rate (SOFR {sofr:.2f}% + {DEFAULT_SPREAD_BPS} bps)."
    )

    return {
        "analysis_mode": "real",
        "sizing_preview": {
            "max_loan_by_constraint": {
                k: f"${v['max_loan']:,.0f}"
                for k, v in waterfall["constraints"].items()
            },
            "binding_constraint": waterfall["binding_constraint"],
            "max_loan": f"${waterfall['max_loan']:,.0f}",
            "max_loan_per_unit": f"${waterfall['max_loan_per_unit']:,}",
            "rate_assumption": f"SOFR ({sofr:.2f}%) + {DEFAULT_SPREAD_BPS} bps",
            "noi_used": round(req.noi, 0),
        },
        "narrative": narrative or default_narrative,
    }


async def analyze_loan_sizer(req, meter=None) -> dict:
    """
    Full loan sizing with 6-constraint waterfall + Claude structured narrative.
    """
    sofr = await get_current_sofr(meter=meter)
    spread_bps = DEFAULT_SPREAD_BPS
    all_in_rate = (sofr + spread_bps / 100) / 100

    stabilized_value = req.asset_value * 1.08
    total_cost = req.asset_value + (req.noi / 0.0525 - req.asset_value) * 0.15 + req.asset_value * 0.05

    waterfall = run_constraint_waterfall(
        loan_amount=req.loan_amount_requested,
        as_is_value=req.asset_value,
        stabilized_value=stabilized_value,
        total_cost=total_cost,
        noi=req.noi,
        rate=all_in_rate,
        unit_count=1,  # LoanSizerRequest doesn't have unit_count
    )

    max_loan = waterfall["max_loan"]
    recommended_loan = min(max_loan, req.loan_amount_requested)
    request_within_sizing = req.loan_amount_requested <= max_loan
    binding_key = waterfall["binding_constraint"]

    # Claude structured narrative for sizing summary
    deal_data = {
        "loan_requested": req.loan_amount_requested,
        "asset_value": req.asset_value,
        "stabilized_value": stabilized_value,
        "noi": req.noi,
        "rate": all_in_rate * 100,
        "sofr": sofr,
        "waterfall": waterfall,
        "recommended_loan": recommended_loan,
        "request_within_sizing": request_within_sizing,
    }

    # Get JSON schema for structured output
    json_schema = get_json_schema("loan_sizer")

    system, user = build_analysis_prompt(
        skill_text=load_skill("loan-sizing"),
        deal_data=deal_data,
        task_description=(
            "Produce a 3-4 sentence loan sizing summary. State the binding constraint, "
            "max loan from waterfall, and whether the request is within limits. "
            "Show the key math for the binding constraint."
        ),
        json_schema=json_schema,
    )

    claude_result = await call_claude_structured(
        system, user, meter=meter, max_tokens=4096
    )

    # Extract narrative from Claude's structured response
    narrative = None
    if isinstance(claude_result, dict):
        validated = validate_output("loan_sizer", claude_result)
        narrative = claude_result.get("summary") or claude_result.get("narrative")

    return {
        "analysis_mode": "real",
        "waterfall": {
            k: {
                "max_loan": round(v["max_loan"], 0),
                "value_at_requested": v["value"],
                "threshold": v["threshold"],
                "status": v["status"],
                "binding": v["binding"],
            }
            for k, v in waterfall["constraints"].items()
        },
        "binding_constraint": binding_key,
        "max_loan": round(max_loan, 0),
        "recommended_loan": round(recommended_loan, 0),
        "metrics_at_recommended": {
            "dscr": round(req.noi / (recommended_loan * all_in_rate), 2) if recommended_loan > 0 else 0,
            "debt_yield_pct": round(req.noi / recommended_loan * 100, 1) if recommended_loan > 0 else 0,
            "ltv_as_is_pct": round(recommended_loan / req.asset_value * 100, 1),
            "ltv_stabilized_pct": round(recommended_loan / stabilized_value * 100, 1),
            "ltc_pct": round(recommended_loan / total_cost * 100, 1),
        },
        "comparison_to_request": {
            "requested": req.loan_amount_requested,
            "recommended": recommended_loan,
            "difference": round(recommended_loan - req.loan_amount_requested, 0),
            "request_within_sizing": request_within_sizing,
            "action": "Approve as requested" if request_within_sizing else f"Size down to ${recommended_loan:,.0f}",
        },
        "rate_assumption": {
            "index": "SOFR",
            "index_rate_pct": round(sofr, 2),
            "spread_bps": spread_bps,
            "all_in_rate_pct": round(all_in_rate * 100, 2),
            "rate_type": req.rate_type or "floating",
            "interest_only": True,
            "rate_source": "Federal Reserve (FRED) via Valeri Data Services",
        },
        "term": {
            "initial_months": req.term_months or 36,
            "extension_options": "1+1 (two 1-year options)",
            "structure": f"{(req.term_months or 36) // 12}+1+1",
        },
        "sensitivity": {
            "rate_stress_plus_100bps": {
                "all_in_rate_pct": round(all_in_rate * 100 + 1.0, 2),
                "dscr": round(req.noi / (recommended_loan * (all_in_rate + 0.01)), 2) if recommended_loan > 0 else 0,
            },
            "noi_stress_minus_10pct": {
                "stressed_noi": round(req.noi * 0.90),
                "dscr": round(req.noi * 0.90 / (recommended_loan * all_in_rate), 2) if recommended_loan > 0 else 0,
                "debt_yield_pct": round(req.noi * 0.90 / recommended_loan * 100, 1) if recommended_loan > 0 else 0,
            },
        },
        "summary": narrative or f"Waterfall sizes max loan at ${max_loan:,.0f}, binding: {binding_key}.",
    }


async def analyze_loan_pricing(req, meter=None) -> dict:
    """
    Loan pricing with real SOFR + spread build-up + Claude narrative.
    """
    sofr = await get_current_sofr(meter=meter)
    spread_bps = req.spread_bps or DEFAULT_SPREAD_BPS
    all_in_rate = (sofr + spread_bps / 100) / 100

    # Rate cap estimation (rough: 0.5-1.5% of loan amount for 2yr cap)
    rate_cap_strike = req.rate_cap_strike or (sofr / 100 + 0.015)  # 150 bps above current SOFR
    rate_cap_cost = req.loan_amount * 0.005  # ~50 bps of loan amount (simplified)

    # Interest reserve
    ir_months = req.interest_reserve_months or 12
    monthly_interest = req.loan_amount * all_in_rate / 12
    interest_reserve = monthly_interest * ir_months

    # Annual debt service
    annual_ds = req.loan_amount * all_in_rate

    # DSCR if NOI provided
    dscr = round(req.noi / annual_ds, 2) if req.noi and annual_ds > 0 else None

    # Get JSON schema for structured output
    json_schema = get_json_schema("loan_pricing")

    # Build deal data for Claude pricing narrative
    deal_data = {
        "loan_amount": req.loan_amount,
        "sofr": sofr,
        "spread_bps": spread_bps,
        "all_in_rate_pct": round(all_in_rate * 100, 2),
        "rate_type": req.rate_type or "floating",
        "annual_debt_service": round(annual_ds, 0),
        "monthly_debt_service": round(annual_ds / 12, 0),
        "rate_cap_strike_pct": round(rate_cap_strike * 100, 2),
        "rate_cap_cost": round(rate_cap_cost, 0),
        "interest_reserve_months": ir_months,
        "interest_reserve_total": round(interest_reserve, 0),
        "dscr": dscr,
        "noi": req.noi,
    }

    system, user = build_analysis_prompt(
        skill_text="",  # Pricing is deterministic, no full skill needed
        deal_data=deal_data,
        task_description=(
            "Produce a 2-3 sentence loan pricing summary. Explain the rate build-up "
            "(index + spread = all-in), the rate cap requirement and estimated cost, "
            "and the interest reserve sizing. If DSCR is provided, note whether "
            "debt service coverage is adequate. Be specific with numbers."
        ),
        json_schema=json_schema,
    )

    claude_result = await call_claude_structured(
        system, user, meter=meter, max_tokens=4096
    )

    # Extract narrative from Claude's structured response
    narrative = None
    if isinstance(claude_result, dict):
        validated = validate_output("loan_pricing", claude_result)
        narrative = claude_result.get("narrative") or claude_result.get("summary")

    # Build default narrative fallback
    default_narrative = (
        f"Pricing builds from SOFR ({sofr:.2f}%) + {spread_bps} bps spread for an "
        f"all-in rate of {all_in_rate * 100:.2f}%. Annual debt service on the "
        f"${req.loan_amount:,.0f} loan is ${annual_ds:,.0f}."
    )
    if dscr is not None:
        default_narrative += f" DSCR at this pricing: {dscr:.2f}x."

    return {
        "analysis_mode": "real",
        "pricing": {
            "index": "SOFR",
            "index_rate_pct": round(sofr, 2),
            "spread_bps": spread_bps,
            "all_in_rate_pct": round(all_in_rate * 100, 2),
            "rate_type": req.rate_type or "floating",
            "interest_only": True,
            "rate_source": "Federal Reserve (FRED) via Valeri Data Services",
            "annual_debt_service": round(annual_ds, 0),
            "monthly_debt_service": round(annual_ds / 12, 0),
        },
        "rate_cap": {
            "required": req.rate_cap_required if req.rate_cap_required is not None else True,
            "strike_pct": round(rate_cap_strike * 100, 2),
            "estimated_cost": round(rate_cap_cost, 0),
            "term_years": 2,
        },
        "interest_reserve": {
            "months": ir_months,
            "monthly_amount": round(monthly_interest, 0),
            "total_reserve": round(interest_reserve, 0),
        },
        "dscr_at_pricing": dscr,
        "narrative": narrative or default_narrative,
    }
