"""
pinchfin API — Real Analysis Integration
==========================================
Dual-path analysis: real (Claude + Perplexity + Valeri Data Services) when
API keys are configured, mock fallback when they're not.

(c) Veleta Capital LLC. All rights reserved.
"""

import os
import logging

LOG = logging.getLogger("pinchfin.analysis")


def is_analysis_available() -> bool:
    """Check whether real analysis is configured (ANTHROPIC_API_KEY present)."""
    return bool(
        os.environ.get("ANTHROPIC_API_KEY")
        or os.environ.get("PINCHFIN_ANTHROPIC_API_KEY")
    )
