"""
pinchfin API — Preferred Equity Sizing & Analysis
====================================================
Pure deterministic math. No API calls. No Claude. No Perplexity.

Two-pass constraint system:
  Pass 1: Senior debt validated via credit_box.run_constraint_waterfall()
  Pass 2: Pref equity constraints from pref_equity_credit_box_config.json

Loads pref equity config at import time (same pattern as credit_box.py).

(c) Veleta Capital LLC. All rights reserved.
"""

import json
import logging
import math
from pathlib import Path
from typing import Optional

from api.analysis.credit_box import run_constraint_waterfall

LOG = logging.getLogger("pinchfin.analysis.pref_equity")

# ---------------------------------------------------------------------------
# Load pref equity config at import time
# ---------------------------------------------------------------------------

_CONFIG_PATH = Path(__file__).parent / "config" / "pref_equity_credit_box_config.json"

with open(_CONFIG_PATH) as _f:
    _PREF_CONFIG = json.load(_f)

_PREF_CONSTRAINTS = _PREF_CONFIG["two_pass_system"]["pass_2_pref_equity"]["sizing_constraints"]
_PIK_PARAMS = _PREF_CONFIG["pik_parameters"]

# Extract thresholds
MAX_COMBINED_LTV_AS_IS = _PREF_CONSTRAINTS["combined_ltv_as_is"]["default"]      # 0.80
MAX_COMBINED_LTV_STAB = _PREF_CONSTRAINTS["combined_ltv_stabilized"]["default"]  # 0.80
MAX_COMBINED_LTC = _PREF_CONSTRAINTS["combined_ltc"]["default"]                  # 0.85
MIN_PREF_IRR = _PREF_CONSTRAINTS["pref_min_irr"]["default"]                      # 0.14
MIN_PREF_MOIC = _PREF_CONSTRAINTS["pref_min_moic"]["default"]                    # 1.40
CURRENT_PAY_MIN = _PREF_CONSTRAINTS["current_pay_rate_range"]["min"]             # 0.06
CURRENT_PAY_MAX = _PREF_CONSTRAINTS["current_pay_rate_range"]["max"]             # 0.08
MAX_PREF_AMOUNT = _PREF_CONSTRAINTS["max_pref_amount"]["default"]                # 25_000_000
SPONSOR_EQUITY_FLOOR = _PREF_CONSTRAINTS["sponsor_equity_floor"]["default"]      # 0.10
MAX_PREF_COMMON_RATIO = _PREF_CONSTRAINTS["pref_common_ratio"]["default"]        # 2.0
PIK_ACCRUAL_FLAG = _PIK_PARAMS["accrual_flag_threshold"]                         # 0.50


# ═══════════════════════════════════════════════════════════════════════════
# XIRR SOLVER (pure Python — no scipy dependency)
# ═══════════════════════════════════════════════════════════════════════════

def _xirr(cashflows: list[tuple[float, float]], guess: float = 0.10,
           max_iter: int = 200, tol: float = 1e-7) -> Optional[float]:
    """
    Compute XIRR given a list of (day_offset, amount) tuples.
    day_offset is fractional years from the first cash flow.
    Uses Newton-Raphson with bisection fallback.
    Returns annualized IRR as decimal (e.g. 0.14 for 14%), or None if no convergence.
    """
    if not cashflows or len(cashflows) < 2:
        return None

    def _npv(rate):
        return sum(amt / (1 + rate) ** t for t, amt in cashflows)

    def _npv_deriv(rate):
        return sum(-t * amt / (1 + rate) ** (t + 1) for t, amt in cashflows)

    # Newton-Raphson
    rate = guess
    for _ in range(max_iter):
        npv = _npv(rate)
        deriv = _npv_deriv(rate)
        if abs(npv) < tol:
            return rate
        if abs(deriv) < 1e-12:
            break
        new_rate = rate - npv / deriv
        # Clamp to reasonable range
        new_rate = max(-0.99, min(10.0, new_rate))
        rate = new_rate

    # Bisection fallback
    lo, hi = -0.50, 5.0
    if _npv(lo) * _npv(hi) > 0:
        return None
    for _ in range(200):
        mid = (lo + hi) / 2
        if abs(_npv(mid)) < tol or (hi - lo) < tol:
            return mid
        if _npv(lo) * _npv(mid) < 0:
            hi = mid
        else:
            lo = mid
    return (lo + hi) / 2


# ═══════════════════════════════════════════════════════════════════════════
# PASS 2: PREF EQUITY CONSTRAINT WATERFALL
# ═══════════════════════════════════════════════════════════════════════════

def run_pref_constraint_waterfall(
    senior_loan: float,
    pref_equity: float,
    as_is_value: float,
    stabilized_value: float,
    total_cost: float,
    unit_count: int = 1,
    construction_deal: bool = False,
) -> dict:
    """
    Run the 9-constraint pref equity waterfall (Pass 2).

    Assumes Pass 1 (senior) has already passed. Pref equity is EQUITY,
    excluded from all debt metrics. Combined metrics = senior + pref.

    Returns dict with constraints, binding constraint, max pref, and metrics.
    """
    equity_gap = total_cost - senior_loan
    common_equity = equity_gap - pref_equity

    # Combined metrics
    combined = senior_loan + pref_equity
    cltv_as_is = combined / as_is_value * 100 if as_is_value > 0 else 999.0
    cltv_stab = combined / stabilized_value * 100 if stabilized_value > 0 else 999.0
    cltc = combined / total_cost * 100 if total_cost > 0 else 999.0
    sponsor_eq_pct = common_equity / total_cost * 100 if total_cost > 0 else 0.0
    pref_common_ratio = pref_equity / common_equity if common_equity > 0 else 999.0

    # Max pref per each constraint
    max_cltv_as_is = max(0, as_is_value * MAX_COMBINED_LTV_AS_IS - senior_loan)
    max_cltv_stab = max(0, stabilized_value * MAX_COMBINED_LTV_STAB - senior_loan)
    max_cltc = max(0, total_cost * MAX_COMBINED_LTC - senior_loan)
    max_sponsor_floor = max(0, equity_gap - total_cost * SPONSOR_EQUITY_FLOOR)
    # Pref <= 2x Common. If P = pref, C = equity_gap - P. P <= 2C = 2(equity_gap - P) → 3P <= 2*equity_gap
    max_pref_common = equity_gap * MAX_PREF_COMMON_RATIO / (1 + MAX_PREF_COMMON_RATIO)
    max_program = MAX_PREF_AMOUNT

    constraints = {
        "combined_ltv_as_is": {
            "label": "Combined LTV As-Is",
            "value": round(cltv_as_is, 1),
            "threshold": MAX_COMBINED_LTV_AS_IS * 100,
            "max_pref": round(max_cltv_as_is, 0),
            "status": "pass" if cltv_as_is <= MAX_COMBINED_LTV_AS_IS * 100 else "fail",
        },
        "combined_ltv_stabilized": {
            "label": "Combined LTV Stabilized",
            "value": round(cltv_stab, 1),
            "threshold": MAX_COMBINED_LTV_STAB * 100,
            "max_pref": round(max_cltv_stab, 0),
            "status": "pass" if cltv_stab <= MAX_COMBINED_LTV_STAB * 100 else "fail",
        },
        "combined_ltc": {
            "label": "Combined LTC",
            "value": round(cltc, 1),
            "threshold": MAX_COMBINED_LTC * 100,
            "max_pref": round(max_cltc, 0),
            "status": "pass" if cltc <= MAX_COMBINED_LTC * 100 else "fail",
        },
        "sponsor_equity_floor": {
            "label": "Sponsor Equity Floor",
            "value": round(sponsor_eq_pct, 1),
            "threshold": SPONSOR_EQUITY_FLOOR * 100,
            "max_pref": round(max_sponsor_floor, 0),
            "status": "pass" if sponsor_eq_pct >= SPONSOR_EQUITY_FLOOR * 100 else "fail",
        },
        "pref_common_ratio": {
            "label": "Pref:Common Ratio",
            "value": round(pref_common_ratio, 2),
            "threshold": MAX_PREF_COMMON_RATIO,
            "max_pref": round(max_pref_common, 0),
            "status": "pass" if pref_common_ratio <= MAX_PREF_COMMON_RATIO else "fail",
        },
        "max_pref_amount": {
            "label": "Max Pref Amount",
            "value": pref_equity,
            "threshold": max_program,
            "max_pref": max_program,
            "status": "pass" if pref_equity <= max_program else "fail",
        },
    }

    # For construction deals, as-is LTV is analytical only (land value != completed value)
    if construction_deal:
        constraints["combined_ltv_as_is"]["status"] = "analytical"
        constraints["combined_ltv_as_is"]["note"] = "Analytical only — as-is value is land for construction deals"

    # Binding = lowest max_pref (across sizing constraints only, excluding analytical)
    sizing_keys = [
        k for k in constraints
        if constraints[k].get("status") != "analytical"
        and _PREF_CONSTRAINTS.get(k, {}).get("enters_min_function", True)
    ]
    binding_key = min(sizing_keys, key=lambda k: constraints[k]["max_pref"])
    max_pref = constraints[binding_key]["max_pref"]

    for key in constraints:
        constraints[key]["binding"] = key == binding_key

    all_pass = all(
        c["status"] in ("pass", "analytical") for c in constraints.values()
    )

    return {
        "constraints": constraints,
        "binding_constraint": binding_key,
        "binding_label": constraints[binding_key]["label"],
        "max_pref": round(max_pref, 0),
        "max_pref_per_unit": round(max_pref / unit_count, 0) if unit_count > 0 else 0,
        "all_pass": all_pass,
        "equity_gap": round(equity_gap, 0),
        "common_equity": round(common_equity, 0),
        "metrics": {
            "combined_ltv_as_is": round(cltv_as_is, 1),
            "combined_ltv_stabilized": round(cltv_stab, 1),
            "combined_ltc": round(cltc, 1),
            "sponsor_equity_pct": round(sponsor_eq_pct, 1),
            "pref_common_ratio": round(pref_common_ratio, 2),
            "equity_cushion_pct": round((pref_equity + common_equity) / stabilized_value * 100, 1) if stabilized_value > 0 else 0,
        },
    }


# ═══════════════════════════════════════════════════════════════════════════
# PIK ACCRUAL MODEL (Quarterly Compounding)
# ═══════════════════════════════════════════════════════════════════════════

def compute_pik_schedule(
    pref_amount: float,
    total_return_rate: float,
    current_pay_rate: float,
    construction_quarters: int,
    leaseup_quarters: int,
    exit_quarter: int,
    cfads_annual: float = 0.0,
) -> dict:
    """
    Model quarterly PIK accrual with construction/lease-up/stabilized phases.

    During construction and lease-up: full PIK (no cash flow).
    At stabilization: current pay commences from CFADS, remainder accrues as PIK.

    HARD RULE: Quarterly compounding. No annual or simple interest approximations.

    Returns schedule, summary, and accrual flag status.
    """
    quarterly_total = total_return_rate / 4
    quarterly_current = current_pay_rate / 4
    pik_rate_annual = total_return_rate - current_pay_rate
    quarterly_pik_only = pik_rate_annual / 4

    schedule = []
    balance = pref_amount
    cumul_pik = 0.0
    cumul_current = 0.0
    stab_start_quarter = construction_quarters + leaseup_quarters + 1

    for q in range(1, exit_quarter + 1):
        balance_start = balance
        return_due = balance * quarterly_total

        if q <= construction_quarters:
            # Construction: zero cash, full PIK
            current_paid = 0.0
            phase = "Construction"
        elif q <= construction_quarters + leaseup_quarters:
            # Lease-up: minimal/zero cash, full PIK
            current_paid = 0.0
            phase = "Lease-Up"
        else:
            # Stabilized: CFADS supports current pay
            current_due = balance * quarterly_current
            cash_available = cfads_annual / 4 if cfads_annual > 0 else 0.0
            current_paid = min(cash_available, current_due)
            phase = "Stabilized"

        pik_accrual = return_due - current_paid
        cumul_pik += pik_accrual
        cumul_current += current_paid
        balance += pik_accrual

        schedule.append({
            "quarter": q,
            "month_start": (q - 1) * 3 + 1,
            "month_end": q * 3,
            "phase": phase,
            "balance_start": round(balance_start, 2),
            "return_due": round(return_due, 2),
            "current_paid": round(current_paid, 2),
            "pik_accrual": round(pik_accrual, 2),
            "cumul_pik": round(cumul_pik, 2),
            "balance_end": round(balance, 2),
        })

    accrual_pct = cumul_pik / pref_amount if pref_amount > 0 else 0.0
    accrual_flag = accrual_pct > PIK_ACCRUAL_FLAG

    return {
        "schedule": schedule,
        "summary": {
            "original_pref": round(pref_amount, 2),
            "total_return_rate": total_return_rate,
            "current_pay_rate": current_pay_rate,
            "pik_rate": pik_rate_annual,
            "compounding": "quarterly",
            "construction_quarters": construction_quarters,
            "leaseup_quarters": leaseup_quarters,
            "months_full_pik": (construction_quarters + leaseup_quarters) * 3,
            "total_pik_at_exit": round(cumul_pik, 2),
            "total_current_paid": round(cumul_current, 2),
            "pref_balance_at_exit": round(balance, 2),
            "accrual_pct_of_original": round(accrual_pct, 4),
            "accrual_flag": accrual_flag,
            "accrual_flag_note": (
                f"PIK accrual of {accrual_pct:.1%} exceeds 50% threshold — elevated compounding risk"
                if accrual_flag else
                f"PIK accrual of {accrual_pct:.1%} is below 50% threshold"
            ),
        },
    }


# ═══════════════════════════════════════════════════════════════════════════
# EXIT WATERFALL & RETURNS (5 Scenarios)
# ═══════════════════════════════════════════════════════════════════════════

def compute_exit_waterfall(
    noi_stabilized: float,
    exit_cap_rate: float,
    senior_loan: float,
    pref_amount: float,
    pik_schedule_result: dict,
    hold_months: int,
) -> dict:
    """
    Compute 5-scenario exit waterfall per pref-equity-sizing SKILL.md.

    Scenarios: Base, +10%, -10%, -20%, Breakeven.
    Priority: Senior payoff → Pref capital + accrued PIK → Common equity.

    Returns scenarios list with IRR/MOIC for pref and sponsor.
    """
    pik_summary = pik_schedule_result["summary"]
    pref_balance = pik_summary["pref_balance_at_exit"]
    total_current_paid = pik_summary["total_current_paid"]
    hold_years = hold_months / 12

    base_exit_value = noi_stabilized / exit_cap_rate if exit_cap_rate > 0 else 0

    # Build pref cash flow timeline for XIRR
    # (year_fraction, amount)
    def _pref_irr(exit_value):
        """Compute pref IRR using XIRR on quarterly cash flows."""
        cfs = [(0.0, -pref_amount)]  # initial investment

        # Add quarterly current pay (if any)
        for entry in pik_schedule_result["schedule"]:
            if entry["current_paid"] > 0:
                t = entry["month_end"] / 12
                cfs.append((t, entry["current_paid"]))

        # Exit: pref gets min(pref_balance, available after senior)
        avail = max(0, exit_value - senior_loan)
        pref_proceeds = min(pref_balance, avail)
        cfs.append((hold_years, pref_proceeds))

        irr = _xirr(cfs, guess=0.12)
        return irr if irr is not None else 0.0

    def _pref_moic(exit_value):
        avail = max(0, exit_value - senior_loan)
        pref_proceeds = min(pref_balance, avail)
        total_to_pref = total_current_paid + pref_proceeds
        return total_to_pref / pref_amount if pref_amount > 0 else 0.0

    def _scenario(label, exit_value):
        avail = max(0, exit_value - senior_loan)
        pref_proceeds = min(pref_balance, avail)
        common_proceeds = max(0, avail - pref_proceeds)
        pref_irr = _pref_irr(exit_value)
        pref_moic = _pref_moic(exit_value)
        return {
            "scenario": label,
            "exit_value": round(exit_value, 0),
            "senior_payoff": round(senior_loan, 0),
            "pref_redemption": round(pref_proceeds, 0),
            "common_equity": round(common_proceeds, 0),
            "pref_irr": round(pref_irr, 4),
            "pref_moic": round(pref_moic, 2),
            "pref_shortfall": round(max(0, pref_balance - avail), 0),
        }

    scenarios = [
        _scenario("Base", base_exit_value),
        _scenario("+10% Value", base_exit_value * 1.10),
        _scenario("-10% Value", base_exit_value * 0.90),
        _scenario("-20% Value", base_exit_value * 0.80),
    ]

    # Breakeven: exit value where common = $0 → exit = senior + pref_balance
    breakeven_value = senior_loan + pref_balance
    scenarios.append(_scenario("Breakeven", breakeven_value))

    # Decline from base to breakeven
    decline_to_breakeven = (
        (base_exit_value - breakeven_value) / base_exit_value
        if base_exit_value > 0 else 0
    )

    return {
        "scenarios": scenarios,
        "base_exit_value": round(base_exit_value, 0),
        "exit_cap_rate": exit_cap_rate,
        "breakeven_exit_value": round(breakeven_value, 0),
        "decline_to_breakeven_pct": round(decline_to_breakeven, 4),
        "pref_balance_at_exit": round(pref_balance, 0),
    }


# ═══════════════════════════════════════════════════════════════════════════
# SPONSOR IMPACT (With vs. Without Pref)
# ═══════════════════════════════════════════════════════════════════════════

def compute_sponsor_impact(
    total_cost: float,
    senior_loan: float,
    pref_amount: float,
    common_equity: float,
    noi_stabilized: float,
    senior_ds: float,
    current_pay_annual: float,
    exit_value: float,
    pref_balance_at_exit: float,
    hold_months: int,
) -> dict:
    """
    Compare sponsor returns with and without preferred equity.

    Without pref: sponsor fills the entire equity gap.
    With pref: sponsor puts up common equity, pref takes priority.
    """
    equity_gap = total_cost - senior_loan
    hold_years = hold_months / 12
    cfads = noi_stabilized - senior_ds

    # --- Without pref ---
    sponsor_eq_without = equity_gap
    cf_annual_without = cfads
    coc_without = cf_annual_without / sponsor_eq_without if sponsor_eq_without > 0 else 0
    exit_eq_without = max(0, exit_value - senior_loan)
    moic_without = exit_eq_without / sponsor_eq_without if sponsor_eq_without > 0 else 0
    # XIRR: invest at t=0, receive exit equity at hold_years
    irr_without = _xirr([(0, -sponsor_eq_without), (hold_years, exit_eq_without)], guess=0.15)
    irr_without = irr_without if irr_without is not None else 0.0

    # --- With pref ---
    sponsor_eq_with = common_equity
    cf_annual_with = max(0, cfads - current_pay_annual)
    coc_with = cf_annual_with / sponsor_eq_with if sponsor_eq_with > 0 else 0
    exit_eq_with = max(0, exit_value - senior_loan - pref_balance_at_exit)
    moic_with = exit_eq_with / sponsor_eq_with if sponsor_eq_with > 0 else 0
    irr_with = _xirr([(0, -sponsor_eq_with), (hold_years, exit_eq_with)], guess=0.20)
    irr_with = irr_with if irr_with is not None else 0.0

    leverage_effect = "positive" if moic_with > moic_without else "negative"

    return {
        "without_pref": {
            "sponsor_equity": round(sponsor_eq_without, 0),
            "annual_cf_stabilized": round(cf_annual_without, 0),
            "cash_on_cash": round(coc_without, 4),
            "exit_equity": round(exit_eq_without, 0),
            "moic": round(moic_without, 2),
            "irr": round(irr_without, 4),
        },
        "with_pref": {
            "sponsor_equity": round(sponsor_eq_with, 0),
            "annual_cf_stabilized": round(cf_annual_with, 0),
            "cash_on_cash": round(coc_with, 4),
            "exit_equity": round(exit_eq_with, 0),
            "moic": round(moic_with, 2),
            "irr": round(irr_with, 4),
        },
        "leverage_effect": leverage_effect,
        "equity_reduction": round(sponsor_eq_without - sponsor_eq_with, 0),
        "equity_reduction_pct": round((sponsor_eq_without - sponsor_eq_with) / sponsor_eq_without, 4) if sponsor_eq_without > 0 else 0,
        "moic_delta": round(moic_with - moic_without, 2),
        "irr_delta": round(irr_with - irr_without, 4),
        "coc_delta": round(coc_with - coc_without, 4),
    }


# ═══════════════════════════════════════════════════════════════════════════
# PREF RETURN SENSITIVITY (by exit timing)
# ═══════════════════════════════════════════════════════════════════════════

def compute_pref_return_sensitivity(
    pref_amount: float,
    total_return_rate: float,
    current_pay_rate: float,
    construction_quarters: int,
    leaseup_quarters: int,
    exit_value: float,
    senior_loan: float,
    exit_quarters: list[int] = None,
) -> list[dict]:
    """
    Compute pref returns at various exit timings.
    Default exit points: 12, 24, 30, 36, 42 months.
    """
    if exit_quarters is None:
        exit_quarters = [4, 8, 10, 12, 14]

    results = []
    for eq in exit_quarters:
        months = eq * 3
        pik_result = compute_pik_schedule(
            pref_amount, total_return_rate, current_pay_rate,
            construction_quarters, leaseup_quarters, eq,
        )
        bal = pik_result["summary"]["pref_balance_at_exit"]
        curr = pik_result["summary"]["total_current_paid"]
        pik = pik_result["summary"]["total_pik_at_exit"]

        avail = max(0, exit_value - senior_loan)
        pref_proceeds = min(bal, avail)
        total_to_pref = curr + pref_proceeds
        moic = total_to_pref / pref_amount if pref_amount > 0 else 0

        # XIRR
        cfs = [(0.0, -pref_amount)]
        for entry in pik_result["schedule"]:
            if entry["current_paid"] > 0:
                cfs.append((entry["month_end"] / 12, entry["current_paid"]))
        cfs.append((months / 12, pref_proceeds))
        irr = _xirr(cfs, guess=0.12)
        irr = irr if irr is not None else 0.0

        results.append({
            "exit_month": months,
            "exit_quarter": eq,
            "pik_accrual": round(pik, 0),
            "pref_balance": round(bal, 0),
            "current_pay_income": round(curr, 0),
            "pref_redemption": round(pref_proceeds, 0),
            "pref_irr": round(irr, 4),
            "pref_moic": round(moic, 2),
            "accrual_pct": round(pik / pref_amount, 4) if pref_amount > 0 else 0,
        })

    return results


# ═══════════════════════════════════════════════════════════════════════════
# SIZING ORCHESTRATOR — ties all components together
# ═══════════════════════════════════════════════════════════════════════════

def size_pref_equity(
    senior_loan: float,
    senior_rate: float,
    as_is_value: float,
    stabilized_value: float,
    total_cost: float,
    noi_stabilized: float,
    noi_y1: Optional[float] = None,
    exit_cap_rate: float = 0.0525,
    hold_months: int = 36,
    current_pay_rate: float = 0.07,
    pik_rate: float = 0.07,
    pref_equity_requested: Optional[float] = None,
    construction_quarters: int = 8,
    leaseup_quarters: int = 3,
    unit_count: int = 1,
) -> dict:
    """
    Full pref equity sizing: Pass 1 → Pass 2 → PIK → Exit → Sponsor Impact.

    This is the main entry point called by the API endpoint.
    100% deterministic — no external API calls.

    Returns the consolidated result matching PrefEquityQROutput schema.
    """
    total_return_rate = current_pay_rate + pik_rate
    senior_ds = senior_loan * senior_rate
    cfads = noi_stabilized - senior_ds
    equity_gap = total_cost - senior_loan
    exit_quarter = hold_months // 3

    # Detect construction deals: as-is value < senior loan indicates land-only valuation
    is_construction = as_is_value < senior_loan

    # ── Pass 1: Validate senior independently ──
    pass_1 = run_constraint_waterfall(
        loan_amount=senior_loan,
        as_is_value=as_is_value,
        stabilized_value=stabilized_value,
        total_cost=total_cost,
        noi=noi_stabilized,
        rate=senior_rate,
        unit_count=unit_count,
    )

    # For construction deals, as-is LTV will fail (land value only) — expected.
    # We check all constraints EXCEPT as-is LTV for construction deals.
    exclude_from_pass1 = {"ltv_as_is"} if is_construction else set()
    senior_failures = [
        k for k, v in pass_1["constraints"].items()
        if v["status"] == "fail" and k not in exclude_from_pass1
    ]
    if is_construction:
        pass_1["construction_deal"] = True
        pass_1["constraints"]["ltv_as_is"]["note"] = "Analytical only — land value for construction"

    if senior_failures:
        return {
            "screen_result": "FAIL",
            "fail_reason": f"Senior loan fails Pass 1 constraints: {', '.join(senior_failures)}",
            "pass_1_senior": pass_1,
            "pass_2_pref": None,
            "pik_schedule": None,
            "exit_waterfall": None,
            "sponsor_impact": None,
            "pref_returns": None,
        }

    # ── Determine pref amount ──
    # First, compute max pref from Pass 2 waterfall
    # Use a placeholder pref equal to the request or the equity gap
    pref_test = pref_equity_requested if pref_equity_requested else equity_gap * 0.5

    pass_2 = run_pref_constraint_waterfall(
        senior_loan=senior_loan,
        pref_equity=pref_test,
        as_is_value=as_is_value,
        stabilized_value=stabilized_value,
        total_cost=total_cost,
        unit_count=unit_count,
        construction_deal=is_construction,
    )

    max_pref = min(pass_2["max_pref"], equity_gap)
    sized_pref = pref_equity_requested if pref_equity_requested and pref_equity_requested <= max_pref else max_pref
    common_equity = equity_gap - sized_pref

    # Re-run Pass 2 with the actual sized pref
    pass_2_final = run_pref_constraint_waterfall(
        senior_loan=senior_loan,
        pref_equity=sized_pref,
        as_is_value=as_is_value,
        stabilized_value=stabilized_value,
        total_cost=total_cost,
        unit_count=unit_count,
        construction_deal=is_construction,
    )

    # ── PIK Accrual ──
    pik_result = compute_pik_schedule(
        pref_amount=sized_pref,
        total_return_rate=total_return_rate,
        current_pay_rate=current_pay_rate,
        construction_quarters=construction_quarters,
        leaseup_quarters=leaseup_quarters,
        exit_quarter=exit_quarter,
        cfads_annual=cfads,
    )

    # ── Exit Waterfall ──
    exit_result = compute_exit_waterfall(
        noi_stabilized=noi_stabilized,
        exit_cap_rate=exit_cap_rate,
        senior_loan=senior_loan,
        pref_amount=sized_pref,
        pik_schedule_result=pik_result,
        hold_months=hold_months,
    )

    # ── Check IRR/MOIC floors ──
    base_scenario = exit_result["scenarios"][0]
    meets_irr = base_scenario["pref_irr"] >= MIN_PREF_IRR
    meets_moic = base_scenario["pref_moic"] >= MIN_PREF_MOIC

    # Add IRR/MOIC validation to Pass 2
    pass_2_final["constraints"]["pref_min_irr"] = {
        "label": "Pref Min IRR",
        "value": round(base_scenario["pref_irr"] * 100, 1),
        "threshold": MIN_PREF_IRR * 100,
        "max_pref": sized_pref if meets_irr else 0,
        "status": "pass" if meets_irr else "fail",
        "binding": False,
    }
    pass_2_final["constraints"]["pref_min_moic"] = {
        "label": "Pref Min MOIC",
        "value": base_scenario["pref_moic"],
        "threshold": MIN_PREF_MOIC,
        "max_pref": sized_pref if meets_moic else 0,
        "status": "pass" if meets_moic else "fail",
        "binding": False,
    }
    pass_2_final["all_pass"] = pass_2_final["all_pass"] and meets_irr and meets_moic

    # ── Sponsor Impact ──
    pref_balance = pik_result["summary"]["pref_balance_at_exit"]
    base_exit = exit_result["base_exit_value"]

    sponsor_impact = compute_sponsor_impact(
        total_cost=total_cost,
        senior_loan=senior_loan,
        pref_amount=sized_pref,
        common_equity=common_equity,
        noi_stabilized=noi_stabilized,
        senior_ds=senior_ds,
        current_pay_annual=sized_pref * current_pay_rate,
        exit_value=base_exit,
        pref_balance_at_exit=pref_balance,
        hold_months=hold_months,
    )

    # ── Pref Return Sensitivity ──
    pref_sensitivity = compute_pref_return_sensitivity(
        pref_amount=sized_pref,
        total_return_rate=total_return_rate,
        current_pay_rate=current_pay_rate,
        construction_quarters=construction_quarters,
        leaseup_quarters=leaseup_quarters,
        exit_value=base_exit,
        senior_loan=senior_loan,
    )

    # ── Screen Result ──
    if not pass_2_final["all_pass"]:
        screen = "FAIL"
    elif pik_result["summary"]["accrual_flag"]:
        screen = "CONDITIONAL"
    elif not meets_irr or not meets_moic:
        screen = "FAIL"
    else:
        screen = "CONDITIONAL"  # QR is always conditional pending DD

    # ── Capital Stack ──
    capital_stack = {
        "senior_loan": round(senior_loan, 0),
        "senior_pct": round(senior_loan / total_cost, 4),
        "senior_cost": senior_rate,
        "pref_equity": round(sized_pref, 0),
        "pref_pct": round(sized_pref / total_cost, 4),
        "pref_cost": total_return_rate,
        "common_equity": round(common_equity, 0),
        "common_pct": round(common_equity / total_cost, 4),
        "total": round(total_cost, 0),
        "blended_cost": round(
            (senior_loan * senior_rate + sized_pref * total_return_rate) / (senior_loan + sized_pref), 4
        ) if (senior_loan + sized_pref) > 0 else 0,
    }

    return {
        "screen_result": screen,
        "deal_type": "preferred_equity",
        "sized_pref_equity": round(sized_pref, 0),
        "max_pref_equity": round(max_pref, 0),
        "pass_1_senior": pass_1,
        "pass_2_pref": pass_2_final,
        "capital_stack": capital_stack,
        "pik_schedule": pik_result,
        "exit_waterfall": exit_result,
        "sponsor_impact": sponsor_impact,
        "pref_return_sensitivity": pref_sensitivity,
        "pref_returns": {
            "pref_irr_base": base_scenario["pref_irr"],
            "pref_moic_base": base_scenario["pref_moic"],
            "meets_irr_floor": meets_irr,
            "meets_moic_floor": meets_moic,
            "current_pay_rate": current_pay_rate,
            "pik_rate": pik_rate,
            "total_return": total_return_rate,
        },
        "yield_metrics": {
            "noi_stabilized": round(noi_stabilized, 0),
            "yield_on_cost": round(noi_stabilized / total_cost, 4) if total_cost > 0 else 0,
            "development_spread_bps": round((noi_stabilized / total_cost - exit_cap_rate) * 10000, 0) if total_cost > 0 else 0,
            "cfads_stabilized": round(cfads, 0),
            "cfads_coverage_6pct": round(cfads / (sized_pref * 0.06), 2) if sized_pref > 0 else 0,
            "cfads_coverage_8pct": round(cfads / (sized_pref * 0.08), 2) if sized_pref > 0 else 0,
        },
    }
