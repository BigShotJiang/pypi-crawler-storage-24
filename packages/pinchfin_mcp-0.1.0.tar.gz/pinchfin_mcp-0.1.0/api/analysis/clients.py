"""
pinchfin API — Shared API Clients
===================================
Lazy singleton clients for Claude, Perplexity, and Valeri Data Services.
All clients are async and record usage to the billing meter.

(c) Veleta Capital LLC. All rights reserved.
"""

import os
import logging
from typing import Optional

import httpx

LOG = logging.getLogger("pinchfin.analysis.clients")

# ---------------------------------------------------------------------------
# Lazy singletons
# ---------------------------------------------------------------------------

_claude_client = None
_perplexity_client = None
_valeri_data_client = None

# Default SOFR when valeri-data sidecar is unreachable
SOFR_FALLBACK = 4.30


def _get_api_key(name: str) -> str:
    """Get API key from env, supporting PINCHFIN_ prefix."""
    return os.environ.get(name, "") or os.environ.get(f"PINCHFIN_{name}", "")


def get_claude_client():
    """Lazy singleton for Anthropic AsyncAnthropic client."""
    global _claude_client
    if _claude_client is None:
        try:
            import anthropic
        except ImportError:
            raise RuntimeError(
                "anthropic SDK required for real analysis. "
                "Install with: pip install anthropic>=0.40.0"
            )
        api_key = _get_api_key("ANTHROPIC_API_KEY")
        if not api_key:
            raise RuntimeError("ANTHROPIC_API_KEY not set")
        _claude_client = anthropic.AsyncAnthropic(api_key=api_key)
    return _claude_client


def get_perplexity_client() -> httpx.AsyncClient:
    """Lazy singleton for Perplexity API client."""
    global _perplexity_client
    if _perplexity_client is None:
        api_key = _get_api_key("PERPLEXITY_API_KEY")
        headers = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        _perplexity_client = httpx.AsyncClient(
            base_url="https://api.perplexity.ai",
            headers=headers,
            timeout=60.0,
        )
    return _perplexity_client


def get_valeri_data_client() -> httpx.AsyncClient:
    """Lazy singleton for Valeri Data Services sidecar."""
    global _valeri_data_client
    if _valeri_data_client is None:
        base_url = (
            os.environ.get("VALERI_DATA_URL")
            or os.environ.get("PINCHFIN_VALERI_DATA_URL")
            or "http://localhost:3001"
        )
        _valeri_data_client = httpx.AsyncClient(
            base_url=base_url,
            timeout=30.0,
        )
    return _valeri_data_client


# ---------------------------------------------------------------------------
# Wrapped API calls with metering
# ---------------------------------------------------------------------------

async def call_claude(
    system: str,
    user: str,
    model: str = "claude-sonnet-4-20250514",
    meter=None,
    max_tokens: int = 4096,
) -> str:
    """
    Call Claude API and record token usage to meter.

    Returns the text content of the response.
    """
    client = get_claude_client()

    response = await client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": user}],
    )

    # Extract text
    text = ""
    for block in response.content:
        if hasattr(block, "text"):
            text += block.text

    # Record to meter
    if meter is not None:
        meter.record_llm_usage(
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
        )

    LOG.info(
        "Claude call: model=%s, input=%d, output=%d",
        model,
        response.usage.input_tokens,
        response.usage.output_tokens,
    )

    return text


async def call_claude_structured(
    system: str,
    user: str,
    model: str = "claude-sonnet-4-20250514",
    meter=None,
    max_tokens: int = 8192,
    max_retries: int = 2,
) -> dict:
    """
    Call Claude API with JSON enforcement and retry/fallback.

    Attempts to parse the response as JSON. On parse failure,
    retries with explicit instruction, then falls back to
    wrapping the narrative in a dict.

    Returns a dict (parsed JSON or fallback wrapper).
    """
    import json

    for attempt in range(max_retries + 1):
        if attempt > 0:
            # On retry, add explicit JSON reminder to user prompt
            retry_user = (
                user + "\n\nIMPORTANT: Your previous response was not valid JSON. "
                "Respond with ONLY a raw JSON object — no markdown fences, no text "
                "before or after the JSON. Start with { and end with }."
            )
        else:
            retry_user = user

        text = await call_claude(
            system=system,
            user=retry_user,
            model=model,
            meter=meter,
            max_tokens=max_tokens,
        )

        # Try to parse JSON
        parsed = _try_parse_json(text)
        if parsed is not None:
            return parsed

        LOG.warning(
            "Claude structured call attempt %d/%d failed to parse JSON (len=%d)",
            attempt + 1,
            max_retries + 1,
            len(text),
        )

    # Final fallback: wrap narrative in dict
    LOG.warning("All structured call attempts failed — returning narrative fallback")
    return {
        "_parse_failed": True,
        "narrative": text,
    }


def _try_parse_json(text: str) -> Optional[dict]:
    """Try to parse text as JSON, handling ```json fences and leading/trailing text."""
    import json

    clean = text.strip()

    # Handle ```json blocks
    if clean.startswith("```"):
        clean = clean.split("\n", 1)[1] if "\n" in clean else clean[3:]
        if clean.endswith("```"):
            clean = clean[:-3].strip()

    # Try direct parse
    try:
        result = json.loads(clean)
        if isinstance(result, dict):
            return result
    except (json.JSONDecodeError, ValueError):
        pass

    # Try to find JSON object in the text
    brace_start = clean.find("{")
    brace_end = clean.rfind("}")
    if brace_start != -1 and brace_end > brace_start:
        try:
            result = json.loads(clean[brace_start:brace_end + 1])
            if isinstance(result, dict):
                return result
        except (json.JSONDecodeError, ValueError):
            pass

    return None


async def call_perplexity(
    query: str,
    meter=None,
    model: str = "sonar",
) -> str:
    """
    Call Perplexity search API and record usage.

    Returns the text content. Falls back gracefully if no API key.
    """
    api_key = _get_api_key("PERPLEXITY_API_KEY")
    if not api_key:
        LOG.warning("No PERPLEXITY_API_KEY — skipping research query: %s", query[:80])
        return ""

    client = get_perplexity_client()

    try:
        resp = await client.post(
            "/chat/completions",
            json={
                "model": model,
                "messages": [{"role": "user", "content": query}],
            },
        )
        resp.raise_for_status()
        data = resp.json()

        text = data.get("choices", [{}])[0].get("message", {}).get("content", "")

        if meter is not None:
            usage = data.get("usage", {})
            meter.record_llm_usage(
                input_tokens=usage.get("prompt_tokens", 0),
                output_tokens=usage.get("completion_tokens", 0),
            )
            meter.record_external_api(1)

        return text

    except Exception as e:
        LOG.warning("Perplexity call failed: %s", e)
        return ""


async def call_valeri_data(
    tool: str,
    params: dict,
    meter=None,
) -> Optional[dict]:
    """
    Call Valeri Data Services sidecar.

    Returns JSON response or None on failure.
    """
    client = get_valeri_data_client()

    try:
        resp = await client.get(f"/api/{tool}", params=params)
        resp.raise_for_status()
        data = resp.json()

        if meter is not None:
            meter.record_external_api(1)

        return data

    except Exception as e:
        LOG.warning("Valeri Data Services call failed (tool=%s): %s", tool, e)
        return None


async def get_current_sofr(meter=None) -> float:
    """
    Fetch current SOFR from Valeri Data Services.

    Falls back to SOFR_FALLBACK (4.30%) if sidecar is unavailable.
    """
    data = await call_valeri_data("macro-indicators", {}, meter=meter)
    if data and "sofr" in data:
        try:
            return float(data["sofr"])
        except (ValueError, TypeError):
            pass

    # Try nested structure
    if data and "data" in data:
        inner = data["data"]
        if isinstance(inner, dict) and "sofr" in inner:
            try:
                return float(inner["sofr"])
            except (ValueError, TypeError):
                pass

    LOG.warning("SOFR unavailable from data services, using fallback %.2f%%", SOFR_FALLBACK)
    return SOFR_FALLBACK
