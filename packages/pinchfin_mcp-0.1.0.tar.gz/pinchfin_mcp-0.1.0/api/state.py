"""
pinchfin API — Application State
=================================
Singleton state holder for shared resources across the FastAPI application.
Accessed by routes via FastAPI dependency injection.

Dual-mode:
  DB_MODE=memory   (default) — pure in-memory, no persistence
  DB_MODE=postgres           — WalletManager routes through asyncpg pool

(c) Veleta Capital LLC. All rights reserved.
"""

import sys
import os
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime, timezone

# Add project root to sys.path so we can import src.billing
_project_root = str(Path(__file__).resolve().parent.parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from src.billing import WalletManager


@dataclass
class DealRecord:
    """In-memory deal record."""
    deal_id: str
    account_id: str
    property_address: Optional[str] = None
    unit_count: Optional[int] = None
    loan_amount: Optional[float] = None
    sponsor_name: Optional[str] = None
    loan_purpose: Optional[str] = None
    status: str = "active"  # active, completed, archived
    modules_run: List[str] = field(default_factory=list)
    documents: List[Dict[str, Any]] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        return {
            "deal_id": self.deal_id,
            "account_id": self.account_id,
            "property_address": self.property_address,
            "unit_count": self.unit_count,
            "loan_amount": self.loan_amount,
            "sponsor_name": self.sponsor_name,
            "loan_purpose": self.loan_purpose,
            "status": self.status,
            "modules_run": self.modules_run,
            "documents": self.documents,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


class AppState:
    """
    Application-wide shared state.

    When PINCHFIN_DB_MODE=postgres, the WalletManager is wired to the
    DatabaseConnection pool so all wallet operations hit Postgres.
    Otherwise everything stays in-memory.
    """

    def __init__(self, db=None):
        self.db = db  # DatabaseConnection or None
        self.wallet: WalletManager = WalletManager(db=db)
        self.deals: Dict[str, DealRecord] = {}
        self._deal_counter: int = 0

    def next_deal_id(self) -> str:
        """Generate next sequential deal ID."""
        self._deal_counter += 1
        year = datetime.now(timezone.utc).year
        return f"PF-{year}-{self._deal_counter:03d}"

    def get_deal(self, deal_id: str) -> Optional[DealRecord]:
        return self.deals.get(deal_id)

    def create_deal(self, account_id: str, **kwargs) -> DealRecord:
        deal_id = self.next_deal_id()
        deal = DealRecord(deal_id=deal_id, account_id=account_id, **kwargs)
        self.deals[deal_id] = deal
        return deal

    def get_deals_for_account(
        self, account_id: str, status: str = "all",
        limit: int = 20, offset: int = 0
    ) -> List[DealRecord]:
        account_deals = [
            d for d in self.deals.values()
            if d.account_id == account_id
            and (status == "all" or d.status == status)
        ]
        account_deals.sort(key=lambda d: d.created_at, reverse=True)
        return account_deals[offset: offset + limit]


def _build_app_state() -> AppState:
    """
    Build the AppState singleton, wiring in the DatabaseConnection
    when PINCHFIN_DB_MODE=postgres.

    The DB pool itself is NOT connected here — ``api.main.lifespan``
    calls ``db.connect()`` at startup and ``db.disconnect()`` at
    shutdown.  We just pass the reference so WalletManager can use it.
    """
    from api.db.connection import db

    if db.is_postgres:
        return AppState(db=db)
    return AppState()


# Module-level singleton — initialized once at import time
app_state = _build_app_state()
