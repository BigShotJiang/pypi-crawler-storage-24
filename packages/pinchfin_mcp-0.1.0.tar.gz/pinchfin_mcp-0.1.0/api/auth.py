"""
pinchfin API — Authentication
==============================
API key authentication middleware and dependency injection for FastAPI routes.

(c) Veleta Capital LLC. All rights reserved.
"""

from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from api.state import app_state

security = HTTPBearer()


async def get_current_account(
    credentials: HTTPAuthorizationCredentials = Depends(security),
):
    """
    FastAPI dependency: extract Bearer token, look up account.

    Usage:
        @router.get("/endpoint")
        async def handler(account = Depends(get_current_account)):
            ...
    """
    api_key = credentials.credentials

    account = await app_state.wallet.get_account(api_key)
    if account is None:
        raise HTTPException(
            status_code=401,
            detail="Invalid API key. Run `pinchfin login` or check your PINCHFIN_API_KEY.",
        )
    return account


async def require_funds(
    credentials: HTTPAuthorizationCredentials = Depends(security),
):
    """
    FastAPI dependency: same as get_current_account but also checks balance > 0.

    Returns the Account if valid and funded, raises 402 otherwise.
    """
    account = await get_current_account(credentials)

    if account.available_balance <= 0:
        raise HTTPException(
            status_code=402,
            detail={
                "error": "Insufficient funds",
                "balance": round(account.balance, 2),
                "held_amount": round(account.held_amount, 2),
                "available_balance": round(account.available_balance, 2),
                "deposit_url": "https://app.pinchfin.com/billing",
                "message": (
                    f"Your available balance is ${account.available_balance:.2f}. "
                    "Load funds before running analysis."
                ),
            },
        )
    return account
