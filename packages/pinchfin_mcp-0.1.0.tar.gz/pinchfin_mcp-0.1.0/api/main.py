"""
pinchfin API — FastAPI Application
====================================
Main application entry point. Serves all /v1/ endpoints for the
pinchfin MCP platform.

Run:
    uvicorn api.main:app --host 0.0.0.0 --port 8000

(c) Veleta Capital LLC. All rights reserved.
"""

import sys
import logging
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

# Ensure project root is on sys.path for src.billing imports
_project_root = str(Path(__file__).resolve().parent.parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from api.db.connection import db
from api.state import app_state
from api.routes import accounts, billing, modules, deals, documents

LOG = logging.getLogger("pinchfin.api")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")


# ---------------------------------------------------------------------------
# Lifespan — startup / shutdown
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application startup and shutdown events.

    On startup:
    - Connect database (postgres mode) or log memory mode
    - Seed a demo account for local development

    On shutdown:
    - Disconnect database pool
    """
    LOG.info("pinchfin API starting up...")

    # Connect the database pool (no-op in memory mode)
    await db.connect()
    LOG.info(f"Database mode: {db.mode}")

    # Seed a demo account for local dev / testing (skip if already exists in Postgres)
    demo_key = "pf_dev_demo_key_000"
    existing = await app_state.wallet.get_account(demo_key)
    if existing:
        LOG.info(f"Demo account already exists: {existing.id} (balance: ${existing.balance:.2f})")
    else:
        demo_account = await app_state.wallet.create_account(
            email="demo@pinchfin.com",
            api_key=demo_key,
        )
        LOG.info(
            f"Demo account seeded: {demo_account.id} "
            f"(balance: ${demo_account.balance:.2f}, key: {demo_key})"
        )

    yield

    LOG.info("pinchfin API shutting down...")
    await db.disconnect()


# ---------------------------------------------------------------------------
# OpenAPI tag metadata
# ---------------------------------------------------------------------------
tags_metadata = [
    {"name": "Billing", "description": "Account management, cost estimation, and fund loading"},
    {"name": "Screening", "description": "Quick deal screening against credit box"},
    {"name": "Modules", "description": "Individual analysis modules (sponsor, market, comps, etc.)"},
    {"name": "Workflow", "description": "Full 15-phase underwriting workflow"},
    {"name": "Deals", "description": "Deal management and document upload"},
    {"name": "Auth", "description": "Account creation and API key management"},
    {"name": "Documents", "description": "Download generated DOCX reports"},
]


# ---------------------------------------------------------------------------
# Application
# ---------------------------------------------------------------------------
app = FastAPI(
    title="pinchfin API",
    description="Institutional-grade CRE underwriting platform. Usage-based billing with prepaid wallet.",
    version="0.1.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    contact={
        "name": "pinchfin Support",
        "email": "support@pinchfin.com",
    },
    license_info={
        "name": "Proprietary",
    },
    openapi_tags=tags_metadata,
)

# CORS — allow all origins in dev, lock down in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Production: restrict to app.pinchfin.com
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Mount route blueprints under /v1/
# ---------------------------------------------------------------------------
app.include_router(accounts.router, prefix="/v1", tags=["Auth"])
app.include_router(billing.router, prefix="/v1", tags=["Billing"])
app.include_router(modules.router, prefix="/v1", tags=["Screening", "Modules", "Workflow"])
app.include_router(deals.router, prefix="/v1", tags=["Deals"])
app.include_router(documents.router, tags=["Documents"])


# ---------------------------------------------------------------------------
# Exception handlers
# ---------------------------------------------------------------------------
@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    return JSONResponse(
        status_code=422,
        content={"detail": str(exc)},
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    LOG.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error. Please retry or contact support@pinchfin.com."},
    )


# ---------------------------------------------------------------------------
# Health check (no auth required)
# ---------------------------------------------------------------------------
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "pinchfin-api",
        "version": "0.1.0",
    }


@app.get("/")
async def root():
    return {
        "service": "pinchfin API",
        "version": "0.1.0",
        "docs": "/docs",
        "health": "/health",
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "api.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )
