"""
pinchfin API — Shared Utilities
=================================
ID generation, API key management, and common helpers.

(c) Veleta Capital LLC. All rights reserved.
"""

import hashlib
import secrets
import uuid
from datetime import datetime, timezone
from typing import Optional

# ---------------------------------------------------------------------------
# API Key Management
# ---------------------------------------------------------------------------

API_KEY_PREFIX = "pf_"


def generate_api_key() -> str:
    """
    Generate a new API key.

    Format: pf_ + 32 hex characters (128 bits of entropy).
    Example: pf_a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6
    """
    return f"{API_KEY_PREFIX}{secrets.token_hex(16)}"


def hash_api_key(key: str) -> str:
    """
    SHA-256 hash of an API key for secure storage.

    The raw key is never stored — only this hash is persisted in the database.
    """
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def get_key_prefix(key: str) -> str:
    """
    Extract the display prefix from an API key.

    Returns the first 8 characters (e.g., 'pf_a1b2c') for safe display
    in dashboards and logs without exposing the full key.
    """
    return key[:8]


# ---------------------------------------------------------------------------
# ID Generation
# ---------------------------------------------------------------------------

# Thread-safe deal counter (in-memory only — Postgres uses a sequence)
_deal_counter: int = 0


def generate_id(prefix: str) -> str:
    """
    Generate a unique ID with the given prefix.

    Supported prefixes: acct_, txn_, hold_, mtr_, est_
    Format: {prefix}{12 hex chars}
    Example: acct_a1b2c3d4e5f6
    """
    return f"{prefix}{uuid.uuid4().hex[:12]}"


def generate_deal_id(counter: Optional[int] = None) -> str:
    """
    Generate a deal ID in PF-YYYY-NNN format.

    Args:
        counter: Explicit sequence number. If None, uses and increments
                 the module-level counter (for in-memory mode).

    Examples:
        PF-2026-001
        PF-2026-042
    """
    global _deal_counter

    if counter is not None:
        seq = counter
    else:
        _deal_counter += 1
        seq = _deal_counter

    year = datetime.now(timezone.utc).year
    return f"PF-{year}-{seq:03d}"


def reset_deal_counter(value: int = 0) -> None:
    """Reset the in-memory deal counter. Used in testing and seed scripts."""
    global _deal_counter
    _deal_counter = value
