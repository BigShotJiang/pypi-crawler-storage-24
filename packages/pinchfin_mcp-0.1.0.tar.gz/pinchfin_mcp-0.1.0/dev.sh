#!/bin/bash
# pinchfin local dev — runs both backend + MCP server
# MCP config: .mcp.json (already in .gitignore)

export PINCHFIN_API_URL="http://127.0.0.1:8420/v1"
export PINCHFIN_API_KEY="pf_dev_demo_key_000"

# Start FastAPI backend
python -m uvicorn api.main:app --host 127.0.0.1 --port 8420 &
BACKEND_PID=$!
trap "kill $BACKEND_PID 2>/dev/null" EXIT

sleep 2
echo "Backend running on :8420 (PID $BACKEND_PID)"

# Start MCP server in stdio mode
python src/server.py
