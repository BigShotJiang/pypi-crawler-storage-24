# ═══════════════════════════════════════════════════════════════════════════
# pinchfin — Example Submission Prompts
# ═══════════════════════════════════════════════════════════════════════════
#
# Copy and adapt these prompts for your deals. The more context you
# provide, the better the analysis. Be honest and thorough — pinchfin's
# value comes from institutional-grade analysis, not from optimistic inputs.
#
# ═══════════════════════════════════════════════════════════════════════════


# ───────────────────────────────────────────────────────────────────────────
# 1. QUICK SCREEN — 30-second deal triage
# ───────────────────────────────────────────────────────────────────────────
#
# Use this when a broker calls or emails a new deal and you need a
# quick pass/fail before spending time on it.

QUICK_SCREEN_EXAMPLE = """
Screen this deal:

Property: Sunset Ridge Apartments, 4521 W Sunset Blvd, Los Angeles, CA 90027
Units: 186
Loan Request: $42,000,000
Purchase Price: $58,000,000
Loan Purpose: Acquisition / bridge
Sponsor: Pacific Coast Capital Group

Notes: Class B, 1972 vintage, partially renovated (60 of 186 units completed).
Broker says in-place rents are 15-20% below market on unrenovated units.
Current occupancy 93%. Sponsor wants 36-month bridge to complete renovation
and stabilize before agency takeout.
"""


# ───────────────────────────────────────────────────────────────────────────
# 2. QUICK SCREEN — Minimal info version
# ───────────────────────────────────────────────────────────────────────────
#
# Sometimes all you have is a one-liner from a broker. That's fine.

QUICK_SCREEN_MINIMAL = """
Screen: 240-unit garden-style in Phoenix, $35M loan, $52M value, bridge refi.
Sponsor is a local operator with 2,000+ units in the market.
"""


# ───────────────────────────────────────────────────────────────────────────
# 3. QUICK REVIEW — 10-minute deal evaluation
# ───────────────────────────────────────────────────────────────────────────
#
# The fastest path from "I just got a deal" to "here's my analysis."
# Runs screen → sponsor + market + comps + cash flow + sizing → memo
# as a single tool call. ~$8-$25.

QUICK_REVIEW_EXAMPLE = """
Run a quick review on this deal:

Property: Ridgewood Park Apartments, 8200 N Central Expressway, Dallas, TX 75206
Units: 220
Loan Request: $38,000,000
Purchase Price: $55,000,000
Loan Purpose: Acquisition / bridge
Sponsor: Ridgewater Capital Partners (Mark Sullivan, 12yr experience, ~3,000 units in DFW)

Notes: Class B-, 1985 vintage, 85% occupied. Sponsor plans $18K/unit renovation
over 24 months (kitchens, baths, common areas). In-place rents $1,050 avg,
market comps suggesting $1,350+ post-renovation. Current T-12 NOI around $2.8M.
"""


# ───────────────────────────────────────────────────────────────────────────
# 4. FULL WORKFLOW — Comprehensive submission with documents
# ───────────────────────────────────────────────────────────────────────────
#
# This is the gold standard. Provide everything you have.
# The more context, the better the output.

FULL_WORKFLOW_EXAMPLE = """
Run the full pinchfin workflow on this deal:

Property: The Meridian at Eastlake
Address: 2200 Eastlake Parkway, Chula Vista, CA 91915
Units: 312 (264 market-rate, 48 affordable at 80% AMI)
Year Built: 2008
Asset Class: B+

Loan Request: $78,000,000
Purpose: Refinance — current loan maturing in 6 months (Wells Fargo)
Estimated Value: $112,000,000
Current Debt: $71,000,000 (originated 2021 at 3.85%)

Sponsor: Eastlake Property Partners LLC
  - Principal: James Chen, 18 years multifamily experience
  - Portfolio: ~4,200 units across Southern California
  - Has been our borrower on 2 prior deals (performing)
  - Net worth ~$85M, liquidity ~$12M per last PFS

In-Place Performance:
  - Occupancy: 95.2%
  - Average rent: $2,340/mo (market-rate), $1,680/mo (affordable)
  - T-12 NOI: $6,180,000
  - T-12 EGI: $9,850,000
  - Operating expense ratio: ~37%

Business Plan:
  Sponsor plans light capex ($8,500/unit) on common areas and unit interiors
  over 24 months. Targeting 10-12% rent bumps on market-rate units at
  turnover. No change to affordable units. Expect stabilized NOI of ~$7.2M
  by Year 3.

Documents are in: ~/deals/meridian-eastlake/
  - /documents/ (OM, rent roll, T-12, sponsor PFS, entity docs)
  - /transcripts/ (3 broker calls, 2 sponsor calls, email thread)

Special considerations:
  - 48 affordable units have LIHTC restrictions expiring 2031
  - Property is in a Qualified Opportunity Zone
  - New 280-unit competing project breaking ground 0.8 miles east
  - Sponsor's partner (minority interest) had a resolved bankruptcy in 2019
"""


# ───────────────────────────────────────────────────────────────────────────
# 5. INDIVIDUAL MODULE — Sponsor analysis only
# ───────────────────────────────────────────────────────────────────────────

SPONSOR_ANALYSIS_EXAMPLE = """
Run sponsor analysis on:

Sponsor: Greystone Multifamily Partners
Principal: David Kowalski
Website: www.greystonemfp.com

Context: First-time borrower with us. Claims 6,500 units across Texas and
Arizona. Has done agency loans with Freddie and FHA. Was referred by CIM Group.
We need full background — litigation, bankruptcy, portfolio verification,
and experience scoring.
"""


# ───────────────────────────────────────────────────────────────────────────
# 6. INDIVIDUAL MODULE — Market research only
# ───────────────────────────────────────────────────────────────────────────

MARKET_RESEARCH_EXAMPLE = """
Run market research for a multifamily property at:
1850 N Congress Ave, Boynton Beach, FL 33426

Focus on:
- Rent trends for B-class multifamily in the submarket
- New supply pipeline within 3 miles
- Employment drivers and population growth
- Insurance market conditions (this is coastal Florida)
- Flood zone status and recent storm history
"""


# ───────────────────────────────────────────────────────────────────────────
# 7. DOCUMENT SYNTHESIS — Transcripts and emails first
# ───────────────────────────────────────────────────────────────────────────
#
# RECOMMENDED: If you have broker calls, sponsor calls, and email
# correspondence, synthesize those FIRST before running the workflow.
# This gives pinchfin the full context of what's been discussed.

DOCUMENT_SYNTHESIS_EXAMPLE = """
I have a new deal I'm evaluating. Before we run the full workflow,
I need you to synthesize all my correspondence first.

The deal folder is at: ~/deals/oak-park-commons/

In /transcripts/ you'll find:
  - broker_initial_call_jan15.txt (first pitch call with CBRE broker)
  - sponsor_call_jan18.txt (intro call with borrower)
  - sponsor_followup_jan22.txt (follow-up on financials questions)
  - email_thread_broker.eml (full email chain with broker)
  - email_thread_sponsor.eml (direct correspondence with borrower)

In /documents/ you'll find:
  - Oak_Park_Commons_OM.pdf
  - Rent_Roll_Dec2025.xlsx
  - T12_Operating_Statement.pdf
  - Sponsor_PFS_2025.pdf

Please synthesize all transcripts and emails into a deal narrative,
then create the deal book, then we'll proceed to the full workflow.
"""


# ───────────────────────────────────────────────────────────────────────────
# 8. RESUME A DEAL — Continue from where you left off
# ───────────────────────────────────────────────────────────────────────────

RESUME_DEAL_EXAMPLE = """
Check the status of deal DL-2025-0142 and continue the workflow
from wherever it stopped. I think we completed through Phase 7
last time.
"""


# ───────────────────────────────────────────────────────────────────────────
# TIPS FOR BEST RESULTS
# ───────────────────────────────────────────────────────────────────────────
#
# 1. BE HONEST: Don't sugarcoat the deal narrative. If there are issues
#    (sponsor concerns, market headwinds, structural complexity), say so.
#    The analysis is only as good as the inputs.
#
# 2. PROVIDE CONTEXT: The more narrative you give, the better. Think of
#    it like briefing a senior credit analyst — what would they need to
#    know to evaluate this deal?
#
# 3. SYNTHESIZE FIRST: If you have transcripts and emails, always
#    synthesize those before running the workflow. Context from
#    conversations often contains critical deal intelligence that
#    isn't in the formal documents.
#
# 4. ORGANIZE YOUR FOLDER: Keep deal documents in a clean folder
#    structure. pinchfin works best when files are organized:
#
#    ~/deals/property-name/
#    ├── documents/
#    │   ├── OM.pdf
#    │   ├── rent_roll.xlsx
#    │   ├── t12.pdf
#    │   ├── sponsor_pfs.pdf
#    │   └── ...
#    └── transcripts/
#        ├── broker_call_1.txt
#        ├── sponsor_call_1.txt
#        └── emails.eml
#
# 5. START WITH SCREEN: For new deals, always start with a quick screen.
#    If it passes, then invest time in the full workflow. Don't run 15
#    phases on a deal that fails basic credit box criteria.
