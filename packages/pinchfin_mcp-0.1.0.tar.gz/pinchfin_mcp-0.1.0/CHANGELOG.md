# Changelog

## [0.1.0] - 2026-03-11

### Added
- MCP server with 21 tools (14 billable + 7 free)
- FastAPI backend with all 19 API endpoints
- Usage-based billing engine with cost estimation
- Wallet management (hold → execute → settle flow)
- Stripe integration for fund loading
- CLI: login, setup, status, balance, deposit, usage, pricing, help, logout
- API key authentication
- Postgres schema (6 tables)
- Dual-mode database (memory for dev, postgres for prod)
- 27 tests (unit + integration), all passing
- Docker + docker-compose deployment
- Mock analysis responses with realistic CRE metrics
- Dev tooling (dev.sh, dev.ps1, smoke tests)
