"""
pinchfin Billing Engine
========================
Usage-based billing with Stripe integration, cost estimation,
wallet management, and real-time metering.

All costs are tracked per-run with pre-authorization and settlement.
Users load funds onto their account and pay actual usage.

(c) Veleta Capital LLC. All rights reserved.
"""

import os
import json
import uuid
import logging
from enum import Enum
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone
from dataclasses import dataclass, field

try:
    import stripe
except ImportError:
    stripe = None  # Server-side only — not required for MCP client

from pydantic import BaseModel, Field, ConfigDict

LOG = logging.getLogger("pinchfin.billing")

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
if stripe is not None:
    stripe.api_key = os.environ.get("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
MIN_DEPOSIT = 25.00  # Minimum fund load
FREE_CREDIT = 50.00  # Beta tester starting credit
HOLD_BUFFER = 1.25   # Hold 125% of high estimate as authorization
LOW_BALANCE_THRESHOLD = 5.00  # Warn user when balance drops below this after a charge


# ═══════════════════════════════════════════════════════════════════════════
# COST ESTIMATION
# ═══════════════════════════════════════════════════════════════════════════

class ModuleType(str, Enum):
    """Billable module identifiers."""
    DEAL_SCREEN = "deal_screen"
    DEAL_BOOK = "deal_book"
    SPONSOR_ANALYSIS = "sponsor_analysis"
    MARKET_RESEARCH = "market_research"
    COMP_ANALYSIS = "comp_analysis"
    PROPERTY_CONDITION = "property_condition"
    CASH_FLOW = "cash_flow"
    LOAN_SIZER = "loan_sizer"
    NUANCE_GATE = "nuance_gate"
    LEGAL_REVIEW = "legal_review"
    ENVIRONMENTAL = "environmental"
    IC_MEMO = "ic_memo"
    TERM_SHEET = "term_sheet"
    COMMITTEE_PACKAGE = "committee_package"
    POST_CLOSE = "post_close"
    RENT_ROLL_ANALYZER = "rent_roll_analyzer"
    DOCUMENT_SYNTHESIS = "document_synthesis"
    SHORT_FORM_MEMO = "short_form_memo"
    FULL_WORKFLOW = "full_workflow"
    QUICK_REVIEW = "quick_review"
    TERM_SHEET_COMPARATOR = "term_sheet_comparator"
    LOAN_PRICING = "loan_pricing"
    BUSINESS_PLAN_ANALYSIS = "business_plan_analysis"
    DEBT_SIZING_PREVIEW = "debt_sizing_preview"
    RENOVATION_ROI = "renovation_roi"
    PREF_EQUITY_QR = "pref_equity_qr"


# Base cost ranges per module (low, high) in dollars
# These are starting estimates — refined with actual usage data over time
MODULE_BASE_COSTS: Dict[ModuleType, tuple] = {
    ModuleType.DEAL_SCREEN:        (0.10, 0.50),
    ModuleType.DEAL_BOOK:          (0.75, 3.00),
    ModuleType.SPONSOR_ANALYSIS:   (0.50, 2.00),
    ModuleType.MARKET_RESEARCH:    (0.50, 1.50),
    ModuleType.COMP_ANALYSIS:      (0.50, 1.50),
    ModuleType.PROPERTY_CONDITION: (0.25, 1.00),
    ModuleType.CASH_FLOW:          (0.50, 1.50),
    ModuleType.LOAN_SIZER:         (0.25, 1.00),
    ModuleType.NUANCE_GATE:        (0.50, 2.00),
    ModuleType.LEGAL_REVIEW:       (0.50, 1.50),
    ModuleType.ENVIRONMENTAL:      (0.25, 1.00),
    ModuleType.IC_MEMO:            (1.00, 3.00),
    ModuleType.TERM_SHEET:         (0.50, 1.50),
    ModuleType.COMMITTEE_PACKAGE:  (1.50, 5.00),
    ModuleType.POST_CLOSE:         (0.25, 1.00),
    ModuleType.RENT_ROLL_ANALYZER: (0.25, 1.00),
    ModuleType.DOCUMENT_SYNTHESIS: (0.50, 3.00),
    ModuleType.SHORT_FORM_MEMO:    (0.50, 2.00),
    ModuleType.FULL_WORKFLOW:      (5.00, 20.00),
    ModuleType.QUICK_REVIEW:       (2.00, 6.00),
    ModuleType.TERM_SHEET_COMPARATOR: (0.50, 1.50),
    ModuleType.LOAN_PRICING:          (0.25, 1.00),
    ModuleType.BUSINESS_PLAN_ANALYSIS:(0.50, 2.00),
    ModuleType.DEBT_SIZING_PREVIEW:   (0.25, 0.75),
    ModuleType.RENOVATION_ROI:        (0.50, 2.00),
    ModuleType.PREF_EQUITY_QR:        (3.00, 8.00),
}

# Complexity multipliers based on deal characteristics
UNIT_COUNT_MULTIPLIERS = [
    (50,   0.8),   # < 50 units: simpler
    (150,  1.0),   # 50-150: baseline
    (300,  1.2),   # 150-300: moderate complexity
    (500,  1.4),   # 300-500: complex
    (9999, 1.6),   # 500+: high complexity
]

DOCUMENT_COUNT_MULTIPLIERS = [
    (3,   0.9),    # 1-3 docs: light
    (8,   1.0),    # 4-8 docs: standard
    (15,  1.3),    # 9-15 docs: heavy
    (99,  1.6),    # 15+: very document-intensive
]

DOCUMENT_PAGE_COST = 0.05    # Per page of document processing
RAG_QUERY_COST = 0.02        # Per RAG corpus query
EXTERNAL_API_COST = 0.08     # Per external data API call (avg)
LLM_TOKEN_COST_INPUT = 0.003 / 1000   # Per input token (Sonnet-tier)
LLM_TOKEN_COST_OUTPUT = 0.015 / 1000  # Per output token


def _get_multiplier(value: int, brackets: list) -> float:
    """Get multiplier from bracket table."""
    for threshold, mult in brackets:
        if value <= threshold:
            return mult
    return brackets[-1][1]


class CostEstimateRequest(BaseModel):
    """Input for cost estimation."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    modules: List[ModuleType] = Field(..., description="Modules to run", min_length=1)
    unit_count: Optional[int] = Field(None, description="Property unit count", ge=1)
    document_count: Optional[int] = Field(None, description="Number of documents to process", ge=0)
    document_pages: Optional[int] = Field(None, description="Estimated total document pages", ge=0)
    transcript_count: Optional[int] = Field(None, description="Number of transcripts/emails", ge=0)
    is_rerun: Optional[bool] = Field(False, description="Whether this is a re-run of a prior analysis")


@dataclass
class CostEstimate:
    """Cost estimate result."""
    estimate_id: str
    modules: List[str]
    low: float
    high: float
    hold_amount: float  # Amount to authorize/hold
    breakdown: Dict[str, Dict[str, float]]  # Per-module low/high
    factors: Dict[str, Any]  # What drove the estimate
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        return {
            "estimate_id": self.estimate_id,
            "modules": self.modules,
            "estimated_cost": {
                "low": round(self.low, 2),
                "high": round(self.high, 2),
                "currency": "USD",
            },
            "hold_amount": round(self.hold_amount, 2),
            "breakdown": {
                k: {"low": round(v["low"], 2), "high": round(v["high"], 2)}
                for k, v in self.breakdown.items()
            },
            "factors": self.factors,
            "created_at": self.created_at,
        }


def estimate_cost(req: CostEstimateRequest) -> CostEstimate:
    """
    Estimate the cost of running requested modules.

    Returns a range (low-high) based on module selection and deal complexity.
    """
    unit_mult = _get_multiplier(req.unit_count or 100, UNIT_COUNT_MULTIPLIERS)
    doc_mult = _get_multiplier(req.document_count or 5, DOCUMENT_COUNT_MULTIPLIERS)
    rerun_mult = 0.65 if req.is_rerun else 1.0  # Re-runs are cheaper (cached context)

    total_low = 0.0
    total_high = 0.0
    breakdown = {}

    for module in req.modules:
        base_low, base_high = MODULE_BASE_COSTS.get(module, (2.0, 6.0))

        # Apply multipliers
        mod_low = base_low * unit_mult * doc_mult * rerun_mult
        mod_high = base_high * unit_mult * doc_mult * rerun_mult

        # Add document processing costs if applicable
        if module in (ModuleType.DEAL_BOOK, ModuleType.DOCUMENT_SYNTHESIS,
                      ModuleType.RENT_ROLL_ANALYZER, ModuleType.FULL_WORKFLOW):
            page_cost = (req.document_pages or 0) * DOCUMENT_PAGE_COST
            mod_low += page_cost * 0.8
            mod_high += page_cost * 1.2

        total_low += mod_low
        total_high += mod_high
        breakdown[module.value] = {"low": mod_low, "high": mod_high}

    # For full workflow, don't double-count — use the full_workflow base, not sum of parts
    if ModuleType.FULL_WORKFLOW in req.modules and len(req.modules) == 1:
        pass  # Already calculated correctly
    elif ModuleType.FULL_WORKFLOW in req.modules:
        # If they specified full_workflow plus individual modules, just use full_workflow
        fw_low, fw_high = MODULE_BASE_COSTS[ModuleType.FULL_WORKFLOW]
        total_low = fw_low * unit_mult * doc_mult * rerun_mult
        total_high = fw_high * unit_mult * doc_mult * rerun_mult

    hold_amount = total_high * HOLD_BUFFER

    return CostEstimate(
        estimate_id=f"est_{uuid.uuid4().hex[:12]}",
        modules=[m.value for m in req.modules],
        low=total_low,
        high=total_high,
        hold_amount=hold_amount,
        breakdown=breakdown,
        factors={
            "unit_count": req.unit_count,
            "unit_multiplier": unit_mult,
            "document_count": req.document_count,
            "document_multiplier": doc_mult,
            "document_pages": req.document_pages,
            "is_rerun": req.is_rerun,
            "rerun_multiplier": rerun_mult,
        },
    )


# ═══════════════════════════════════════════════════════════════════════════
# WALLET / ACCOUNT MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class Transaction:
    """Single ledger entry."""
    id: str
    account_id: str
    type: str          # "deposit", "charge", "hold", "release", "refund", "free_credit"
    amount: float      # Positive for credits, negative for debits
    balance_after: float
    description: str
    deal_id: Optional[str] = None
    module: Optional[str] = None
    estimate_id: Optional[str] = None
    stripe_payment_id: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class Account:
    """User account with wallet balance."""
    id: str
    email: str
    api_key_hash: str
    balance: float = 0.0
    held_amount: float = 0.0  # Funds currently held for in-progress analyses
    total_deposited: float = 0.0
    total_spent: float = 0.0
    total_analyses: int = 0
    stripe_customer_id: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def available_balance(self) -> float:
        """Balance minus any active holds."""
        return self.balance - self.held_amount

    def to_dict(self) -> dict:
        return {
            "account_id": self.id,
            "balance": round(self.balance, 2),
            "held_amount": round(self.held_amount, 2),
            "available_balance": round(self.available_balance, 2),
            "total_deposited": round(self.total_deposited, 2),
            "total_spent": round(self.total_spent, 2),
            "total_analyses": self.total_analyses,
            "currency": "USD",
        }


class WalletManager:
    """
    Manages account balances, holds, and settlements.

    Dual-mode:
      DB_MODE=memory   (default) — in-memory dicts, no persistence
      DB_MODE=postgres           — asyncpg queries against schema.sql tables

    The ``db`` parameter accepts a ``DatabaseConnection`` instance (from
    ``api.db.connection``).  When ``db`` is ``None`` or ``db.is_memory``,
    the manager falls back to the in-memory path so all existing tests
    and local dev workflows continue to work unchanged.
    """

    def __init__(self, db=None):
        self.db = db  # DatabaseConnection (or None for pure in-memory)
        # In-memory stores — used when db is None or db.is_memory
        self._accounts: Dict[str, Account] = {}
        self._transactions: List[Transaction] = []
        self._holds: Dict[str, dict] = {}  # hold_id -> hold info

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @property
    def _use_pg(self) -> bool:
        """Return True when we should route through Postgres."""
        return self.db is not None and getattr(self.db, "is_postgres", False)

    @staticmethod
    def _row_to_account(row) -> Account:
        """Map an asyncpg Record (accounts table) to an Account dataclass."""
        return Account(
            id=row["id"],
            email=row["email"],
            api_key_hash=row["api_key_hash"],
            balance=float(row["balance"]),
            held_amount=float(row["held_amount"]),
            total_deposited=float(row["total_deposited"]),
            total_spent=float(row["total_spent"]),
            total_analyses=row["total_analyses"],
            stripe_customer_id=row.get("stripe_customer"),
            created_at=row["created_at"].isoformat() if row["created_at"] else None,
        )

    # ------------------------------------------------------------------
    # get_account
    # ------------------------------------------------------------------

    async def get_account(self, api_key: str) -> Optional[Account]:
        """Look up account by API key."""
        if self._use_pg:
            import hashlib
            key_hash = hashlib.sha256(api_key.encode()).hexdigest()
            row = await self.db.fetchrow(
                "SELECT a.* FROM accounts a "
                "JOIN api_keys k ON k.account_id = a.id "
                "WHERE k.key_hash = $1 AND k.is_active = TRUE",
                key_hash,
            )
            if row is None:
                # Fallback: check accounts.api_key_hash directly
                # (covers demo/seed accounts stored inline)
                row = await self.db.fetchrow(
                    "SELECT * FROM accounts WHERE api_key_hash = $1",
                    key_hash,
                )
            return self._row_to_account(row) if row else None

        # In-memory path
        return self._accounts.get(api_key)

    # ------------------------------------------------------------------
    # create_account
    # ------------------------------------------------------------------

    async def create_account(self, email: str, api_key: str) -> Account:
        """Create new account with free credit."""
        acct_id = f"acct_{uuid.uuid4().hex[:12]}"
        txn_id = f"txn_{uuid.uuid4().hex[:12]}"

        if self._use_pg:
            import hashlib
            key_hash = hashlib.sha256(api_key.encode()).hexdigest()
            key_prefix = api_key[:8]

            async with self.db._pool.acquire() as conn:
                async with conn.transaction():
                    await conn.execute(
                        "INSERT INTO accounts "
                        "(id, email, api_key_hash, balance, held_amount, "
                        " total_deposited, total_spent, total_analyses) "
                        "VALUES ($1, $2, $3, $4, 0, 0, 0, 0)",
                        acct_id, email, key_hash, FREE_CREDIT,
                    )
                    await conn.execute(
                        "INSERT INTO api_keys "
                        "(id, account_id, key_hash, key_prefix, name) "
                        "VALUES ($1, $2, $3, $4, 'default')",
                        f"apikey_{uuid.uuid4().hex[:12]}", acct_id,
                        key_hash, key_prefix,
                    )
                    await conn.execute(
                        "INSERT INTO transactions "
                        "(id, account_id, type, amount, balance_after, description) "
                        "VALUES ($1, $2, 'free_credit', $3, $3, $4)",
                        txn_id, acct_id, FREE_CREDIT,
                        f"Welcome credit: ${FREE_CREDIT:.2f}",
                    )
                    row = await conn.fetchrow(
                        "SELECT * FROM accounts WHERE id = $1", acct_id
                    )
            return self._row_to_account(row)

        # In-memory path
        account = Account(
            id=acct_id,
            email=email,
            api_key_hash=api_key,  # In-memory: store raw key for lookup
            balance=FREE_CREDIT,
        )
        self._accounts[api_key] = account

        txn = Transaction(
            id=txn_id,
            account_id=account.id,
            type="free_credit",
            amount=FREE_CREDIT,
            balance_after=FREE_CREDIT,
            description=f"Welcome credit: ${FREE_CREDIT:.2f}",
        )
        self._transactions.append(txn)
        return account

    # ------------------------------------------------------------------
    # deposit
    # ------------------------------------------------------------------

    async def deposit(self, account: Account, amount: float,
                      stripe_payment_id: str) -> Transaction:
        """Add funds to account after successful Stripe payment."""
        if amount < MIN_DEPOSIT:
            raise ValueError(f"Minimum deposit is ${MIN_DEPOSIT:.2f}")

        txn_id = f"txn_{uuid.uuid4().hex[:12]}"

        if self._use_pg:
            async with self.db._pool.acquire() as conn:
                async with conn.transaction():
                    row = await conn.fetchrow(
                        "UPDATE accounts "
                        "SET balance = balance + $1, "
                        "    total_deposited = total_deposited + $1, "
                        "    updated_at = NOW() "
                        "WHERE id = $2 "
                        "RETURNING balance",
                        amount, account.id,
                    )
                    new_balance = float(row["balance"])
                    await conn.execute(
                        "INSERT INTO transactions "
                        "(id, account_id, type, amount, balance_after, "
                        " description, stripe_payment) "
                        "VALUES ($1, $2, 'deposit', $3, $4, $5, $6)",
                        txn_id, account.id, amount, new_balance,
                        f"Deposit: ${amount:.2f}", stripe_payment_id,
                    )
            # Sync the in-process Account object
            account.balance = new_balance
            account.total_deposited += amount

            return Transaction(
                id=txn_id, account_id=account.id, type="deposit",
                amount=amount, balance_after=new_balance,
                description=f"Deposit: ${amount:.2f}",
                stripe_payment_id=stripe_payment_id,
            )

        # In-memory path
        account.balance += amount
        account.total_deposited += amount

        txn = Transaction(
            id=txn_id,
            account_id=account.id,
            type="deposit",
            amount=amount,
            balance_after=account.balance,
            description=f"Deposit: ${amount:.2f}",
            stripe_payment_id=stripe_payment_id,
        )
        self._transactions.append(txn)
        return txn

    # ------------------------------------------------------------------
    # place_hold
    # ------------------------------------------------------------------

    async def place_hold(self, account: Account, estimate: CostEstimate,
                         deal_id: str) -> Optional[str]:
        """
        Place a hold on funds before running analysis.

        Returns hold_id if successful, None if insufficient funds.
        """
        hold_amount = estimate.hold_amount
        hold_id = f"hold_{uuid.uuid4().hex[:12]}"
        txn_id = f"txn_{uuid.uuid4().hex[:12]}"

        if self._use_pg:
            async with self.db._pool.acquire() as conn:
                async with conn.transaction():
                    row = await conn.fetchrow(
                        "SELECT balance, held_amount FROM accounts WHERE id = $1 FOR UPDATE",
                        account.id,
                    )
                    available = float(row["balance"]) - float(row["held_amount"])
                    if available < hold_amount:
                        return None  # Insufficient funds

                    await conn.execute(
                        "UPDATE accounts SET held_amount = held_amount + $1, "
                        "updated_at = NOW() WHERE id = $2",
                        hold_amount, account.id,
                    )
                    await conn.execute(
                        "INSERT INTO holds "
                        "(id, account_id, estimate_id, deal_id, hold_amount, status) "
                        "VALUES ($1, $2, $3, $4, $5, 'active')",
                        hold_id, account.id, estimate.estimate_id,
                        deal_id, hold_amount,
                    )
                    new_available = available - hold_amount
                    await conn.execute(
                        "INSERT INTO transactions "
                        "(id, account_id, type, amount, balance_after, "
                        " description, deal_id, estimate_id) "
                        "VALUES ($1, $2, 'hold', $3, $4, $5, $6, $7)",
                        txn_id, account.id, -hold_amount, new_available,
                        f"Hold for analysis (est. ${estimate.low:.2f}-${estimate.high:.2f})",
                        deal_id, estimate.estimate_id,
                    )
            # Sync in-process object
            account.held_amount += hold_amount
            return hold_id

        # In-memory path
        if account.available_balance < hold_amount:
            return None

        account.held_amount += hold_amount

        self._holds[hold_id] = {
            "account_id": account.id,
            "estimate_id": estimate.estimate_id,
            "deal_id": deal_id,
            "hold_amount": hold_amount,
            "placed_at": datetime.now(timezone.utc).isoformat(),
        }

        txn = Transaction(
            id=txn_id,
            account_id=account.id,
            type="hold",
            amount=-hold_amount,
            balance_after=account.available_balance,
            description=f"Hold for analysis (est. ${estimate.low:.2f}-${estimate.high:.2f})",
            deal_id=deal_id,
            estimate_id=estimate.estimate_id,
        )
        self._transactions.append(txn)
        return hold_id

    # ------------------------------------------------------------------
    # settle
    # ------------------------------------------------------------------

    async def settle(self, account: Account, hold_id: str,
                     actual_cost: float, modules_used: List[str],
                     deal_id: str) -> Transaction:
        """
        Settle a hold after analysis completes.

        Charges actual cost and releases remainder of hold.
        """
        txn_id = f"txn_{uuid.uuid4().hex[:12]}"

        if self._use_pg:
            async with self.db._pool.acquire() as conn:
                async with conn.transaction():
                    hold_row = await conn.fetchrow(
                        "SELECT * FROM holds WHERE id = $1 AND status = 'active'",
                        hold_id,
                    )
                    if not hold_row:
                        raise ValueError(f"Hold {hold_id} not found")

                    hold_amount = float(hold_row["hold_amount"])

                    if actual_cost > hold_amount:
                        LOG.warning(
                            f"Actual cost ${actual_cost:.2f} exceeds hold "
                            f"${hold_amount:.2f} for deal {deal_id}. "
                            "Charging actual amount."
                        )

                    # Release hold, charge actual cost
                    row = await conn.fetchrow(
                        "UPDATE accounts "
                        "SET held_amount = held_amount - $1, "
                        "    balance = balance - $2, "
                        "    total_spent = total_spent + $2, "
                        "    total_analyses = total_analyses + 1, "
                        "    updated_at = NOW() "
                        "WHERE id = $3 "
                        "RETURNING balance, held_amount",
                        hold_amount, actual_cost, account.id,
                    )
                    new_balance = float(row["balance"])

                    # Mark hold as settled
                    await conn.execute(
                        "UPDATE holds SET status = 'settled', "
                        "settled_at = NOW() WHERE id = $1",
                        hold_id,
                    )

                    # Charge transaction
                    modules_str = ", ".join(modules_used)
                    await conn.execute(
                        "INSERT INTO transactions "
                        "(id, account_id, type, amount, balance_after, "
                        " description, deal_id, module) "
                        "VALUES ($1, $2, 'charge', $3, $4, $5, $6, $7)",
                        txn_id, account.id, -actual_cost, new_balance,
                        f"Analysis: {modules_str} - ${actual_cost:.2f}",
                        deal_id, modules_str,
                    )

                    # Release transaction if hold exceeded actual cost
                    released = hold_amount - actual_cost
                    if released > 0.01:
                        await conn.execute(
                            "INSERT INTO transactions "
                            "(id, account_id, type, amount, balance_after, "
                            " description, deal_id) "
                            "VALUES ($1, $2, 'release', $3, $4, $5, $6)",
                            f"txn_{uuid.uuid4().hex[:12]}", account.id,
                            released, new_balance,
                            f"Hold release: ${released:.2f}", deal_id,
                        )

            # Sync in-process object
            account.held_amount -= hold_amount
            account.balance -= actual_cost
            account.total_spent += actual_cost
            account.total_analyses += 1

            if account.balance < LOW_BALANCE_THRESHOLD:
                LOG.warning(
                    f"Account {account.id} balance is ${account.balance:.2f} "
                    f"(below ${LOW_BALANCE_THRESHOLD:.2f} threshold)"
                )

            return Transaction(
                id=txn_id, account_id=account.id, type="charge",
                amount=-actual_cost, balance_after=new_balance,
                description=f"Analysis: {', '.join(modules_used)} - ${actual_cost:.2f}",
                deal_id=deal_id, module=", ".join(modules_used),
            )

        # In-memory path
        hold = self._holds.get(hold_id)
        if not hold:
            raise ValueError(f"Hold {hold_id} not found")

        hold_amount = hold["hold_amount"]

        if actual_cost > hold_amount:
            LOG.warning(
                f"Actual cost ${actual_cost:.2f} exceeds hold ${hold_amount:.2f} "
                f"for deal {deal_id}. Charging actual amount."
            )

        account.held_amount -= hold_amount
        account.balance -= actual_cost
        account.total_spent += actual_cost
        account.total_analyses += 1

        del self._holds[hold_id]

        txn = Transaction(
            id=txn_id,
            account_id=account.id,
            type="charge",
            amount=-actual_cost,
            balance_after=account.balance,
            description=f"Analysis: {', '.join(modules_used)} - ${actual_cost:.2f}",
            deal_id=deal_id,
            module=", ".join(modules_used),
        )
        self._transactions.append(txn)

        released = hold_amount - actual_cost
        if released > 0.01:
            release_txn = Transaction(
                id=f"txn_{uuid.uuid4().hex[:12]}",
                account_id=account.id,
                type="release",
                amount=released,
                balance_after=account.balance,
                description=f"Hold release: ${released:.2f}",
                deal_id=deal_id,
            )
            self._transactions.append(release_txn)

        if account.balance < LOW_BALANCE_THRESHOLD:
            LOG.warning(
                f"Account {account.id} balance is ${account.balance:.2f} "
                f"(below ${LOW_BALANCE_THRESHOLD:.2f} threshold)"
            )

        return txn

    # ------------------------------------------------------------------
    # settle_failed
    # ------------------------------------------------------------------

    async def settle_failed(self, account: Account, hold_id: str,
                            deal_id: str, reason: str = "Analysis failed") -> Transaction:
        """
        Release a hold without charging when analysis errors out.

        Releases the full hold amount back to available balance.
        """
        txn_id = f"txn_{uuid.uuid4().hex[:12]}"

        if self._use_pg:
            async with self.db._pool.acquire() as conn:
                async with conn.transaction():
                    hold_row = await conn.fetchrow(
                        "SELECT * FROM holds WHERE id = $1 AND status = 'active'",
                        hold_id,
                    )
                    if not hold_row:
                        raise ValueError(f"Hold {hold_id} not found")

                    hold_amount = float(hold_row["hold_amount"])

                    row = await conn.fetchrow(
                        "UPDATE accounts "
                        "SET held_amount = held_amount - $1, "
                        "    updated_at = NOW() "
                        "WHERE id = $2 "
                        "RETURNING balance, held_amount",
                        hold_amount, account.id,
                    )
                    new_available = float(row["balance"]) - float(row["held_amount"])

                    await conn.execute(
                        "UPDATE holds SET status = 'released', "
                        "settled_at = NOW() WHERE id = $1",
                        hold_id,
                    )
                    await conn.execute(
                        "INSERT INTO transactions "
                        "(id, account_id, type, amount, balance_after, "
                        " description, deal_id) "
                        "VALUES ($1, $2, 'release', $3, $4, $5, $6)",
                        txn_id, account.id, hold_amount, new_available,
                        f"Hold released (no charge): {reason}", deal_id,
                    )

            # Sync in-process object
            account.held_amount -= hold_amount

            return Transaction(
                id=txn_id, account_id=account.id, type="release",
                amount=hold_amount, balance_after=new_available,
                description=f"Hold released (no charge): {reason}",
                deal_id=deal_id,
            )

        # In-memory path
        hold = self._holds.get(hold_id)
        if not hold:
            raise ValueError(f"Hold {hold_id} not found")

        hold_amount = hold["hold_amount"]
        account.held_amount -= hold_amount
        del self._holds[hold_id]

        txn = Transaction(
            id=txn_id,
            account_id=account.id,
            type="release",
            amount=hold_amount,
            balance_after=account.available_balance,
            description=f"Hold released (no charge): {reason}",
            deal_id=deal_id,
        )
        self._transactions.append(txn)
        return txn

    # ------------------------------------------------------------------
    # get_transactions
    # ------------------------------------------------------------------

    async def get_transactions(self, account: Account,
                               limit: int = 20) -> List[Dict]:
        """Get recent transactions for an account."""
        if self._use_pg:
            rows = await self.db.fetch(
                "SELECT id, type, amount, balance_after, description, "
                "deal_id, created_at "
                "FROM transactions "
                "WHERE account_id = $1 "
                "ORDER BY created_at DESC "
                "LIMIT $2",
                account.id, limit,
            )
            return [
                {
                    "id": r["id"],
                    "type": r["type"],
                    "amount": round(float(r["amount"]), 2),
                    "balance_after": round(float(r["balance_after"]), 2),
                    "description": r["description"],
                    "deal_id": r["deal_id"],
                    "created_at": r["created_at"].isoformat() if r["created_at"] else None,
                }
                for r in rows
            ]

        # In-memory path
        acct_txns = [
            t for t in self._transactions
            if t.account_id == account.id
        ]
        acct_txns.sort(key=lambda t: t.created_at, reverse=True)
        return [
            {
                "id": t.id,
                "type": t.type,
                "amount": round(t.amount, 2),
                "balance_after": round(t.balance_after, 2),
                "description": t.description,
                "deal_id": t.deal_id,
                "created_at": t.created_at,
            }
            for t in acct_txns[:limit]
        ]


# ═══════════════════════════════════════════════════════════════════════════
# USAGE METERING
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class UsageMeter:
    """
    Tracks real-time resource consumption during an analysis run.

    Created at the start of each run, updated during execution,
    finalized at completion. The total_cost is what gets charged.
    """
    meter_id: str
    deal_id: str
    account_id: str
    modules: List[str]
    started_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    completed_at: Optional[str] = None

    # Resource counters
    llm_input_tokens: int = 0
    llm_output_tokens: int = 0
    document_pages_processed: int = 0
    rag_queries: int = 0
    external_api_calls: int = 0
    compute_seconds: float = 0.0

    # Cost accumulators
    llm_cost: float = 0.0
    document_cost: float = 0.0
    rag_cost: float = 0.0
    external_api_cost: float = 0.0
    total_cost: float = 0.0

    def record_llm_usage(self, input_tokens: int, output_tokens: int):
        """Record an LLM API call."""
        self.llm_input_tokens += input_tokens
        self.llm_output_tokens += output_tokens
        cost = (input_tokens * LLM_TOKEN_COST_INPUT +
                output_tokens * LLM_TOKEN_COST_OUTPUT)
        self.llm_cost += cost
        self.total_cost += cost

    def record_document_processing(self, pages: int):
        """Record document pages processed."""
        self.document_pages_processed += pages
        cost = pages * DOCUMENT_PAGE_COST
        self.document_cost += cost
        self.total_cost += cost

    def record_rag_query(self, count: int = 1):
        """Record RAG corpus queries."""
        self.rag_queries += count
        cost = count * RAG_QUERY_COST
        self.rag_cost += cost
        self.total_cost += cost

    def record_external_api(self, count: int = 1):
        """Record external data API calls."""
        self.external_api_calls += count
        cost = count * EXTERNAL_API_COST
        self.external_api_cost += cost
        self.total_cost += cost

    def finalize(self) -> dict:
        """Finalize the meter and return cost summary."""
        self.completed_at = datetime.now(timezone.utc).isoformat()
        return {
            "meter_id": self.meter_id,
            "deal_id": self.deal_id,
            "modules": self.modules,
            "duration_seconds": self.compute_seconds,
            "resources": {
                "llm_tokens": {
                    "input": self.llm_input_tokens,
                    "output": self.llm_output_tokens,
                    "cost": round(self.llm_cost, 4),
                },
                "documents": {
                    "pages": self.document_pages_processed,
                    "cost": round(self.document_cost, 4),
                },
                "rag_queries": {
                    "count": self.rag_queries,
                    "cost": round(self.rag_cost, 4),
                },
                "external_apis": {
                    "count": self.external_api_calls,
                    "cost": round(self.external_api_cost, 4),
                },
            },
            "total_cost": round(self.total_cost, 2),
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }


def create_meter(deal_id: str, account_id: str, modules: List[str]) -> UsageMeter:
    """Create a new usage meter for an analysis run."""
    return UsageMeter(
        meter_id=f"mtr_{uuid.uuid4().hex[:12]}",
        deal_id=deal_id,
        account_id=account_id,
        modules=modules,
    )


# ═══════════════════════════════════════════════════════════════════════════
# STRIPE INTEGRATION
# ═══════════════════════════════════════════════════════════════════════════

class StripeManager:
    """Handles Stripe payment operations. Requires stripe SDK (server-side only)."""

    @staticmethod
    def _require_stripe():
        if stripe is None:
            raise RuntimeError("stripe SDK required for billing operations. Install with: pip install stripe>=7.0.0")

    @staticmethod
    async def create_customer(email: str, account_id: str) -> str:
        """Create a Stripe customer for a new account."""
        StripeManager._require_stripe()
        customer = stripe.Customer.create(
            email=email,
            metadata={"pinchfin_account_id": account_id},
        )
        return customer.id

    @staticmethod
    async def create_checkout_session(
        customer_id: str,
        amount_cents: int,
        success_url: str = "https://app.pinchfin.com/billing/success",
        cancel_url: str = "https://app.pinchfin.com/billing/cancel",
    ) -> str:
        """
        Create a Stripe Checkout session for loading funds.

        Returns the checkout URL to redirect the user to.
        """
        StripeManager._require_stripe()
        session = stripe.checkout.Session.create(
            customer=customer_id,
            payment_method_types=["card"],
            line_items=[{
                "price_data": {
                    "currency": "usd",
                    "product_data": {
                        "name": "pinchfin Account Funds",
                        "description": f"Load ${amount_cents / 100:.2f} to your pinchfin account",
                    },
                    "unit_amount": amount_cents,
                },
                "quantity": 1,
            }],
            mode="payment",
            success_url=success_url + "?session_id={CHECKOUT_SESSION_ID}",
            cancel_url=cancel_url,
            metadata={"type": "account_deposit"},
        )
        return session.url

    @staticmethod
    async def handle_webhook(payload: bytes, sig_header: str) -> Optional[dict]:
        """
        Handle Stripe webhook events.

        Returns deposit info if payment succeeded, None otherwise.
        """
        StripeManager._require_stripe()
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, STRIPE_WEBHOOK_SECRET
            )
        except (ValueError, stripe.SignatureVerificationError):
            return None

        if event["type"] == "checkout.session.completed":
            session = event["data"]["object"]
            if session.get("metadata", {}).get("type") == "account_deposit":
                return {
                    "customer_id": session["customer"],
                    "amount": session["amount_total"] / 100,  # Cents to dollars
                    "payment_id": session["payment_intent"],
                }

        return None


# ═══════════════════════════════════════════════════════════════════════════
# FASTAPI BILLING ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════

"""
These endpoints would be added to your FastAPI application.
Shown here as route handlers for reference.

Production: integrate into your main FastAPI app with proper
database connections, auth middleware, and error handling.
"""

# Example FastAPI integration (pseudocode — wire into your actual app):
#
# from fastapi import FastAPI, Depends, HTTPException, Request
#
# app = FastAPI()
# wallet = WalletManager(db=database)
# stripe_mgr = StripeManager()
#
#
# @app.post("/v1/billing/estimate")
# async def api_estimate_cost(req: CostEstimateRequest, account = Depends(get_account)):
#     estimate = estimate_cost(req)
#     return {
#         "estimate": estimate.to_dict(),
#         "account": {
#             "available_balance": account.available_balance,
#             "sufficient_funds": account.available_balance >= estimate.hold_amount,
#         }
#     }
#
#
# @app.post("/v1/billing/deposit")
# async def api_create_deposit(amount: float, account = Depends(get_account)):
#     if amount < MIN_DEPOSIT:
#         raise HTTPException(400, f"Minimum deposit is ${MIN_DEPOSIT:.2f}")
#     if not account.stripe_customer_id:
#         account.stripe_customer_id = await stripe_mgr.create_customer(
#             account.email, account.id
#         )
#     checkout_url = await stripe_mgr.create_checkout_session(
#         account.stripe_customer_id,
#         int(amount * 100),
#     )
#     return {"checkout_url": checkout_url}
#
#
# @app.get("/v1/billing/account")
# async def api_account_info(account = Depends(get_account)):
#     transactions = await wallet.get_transactions(account)
#     return {
#         "account": account.to_dict(),
#         "recent_transactions": transactions,
#     }
#
#
# @app.post("/v1/billing/webhooks/stripe")
# async def api_stripe_webhook(request: Request):
#     payload = await request.body()
#     sig = request.headers.get("stripe-signature", "")
#     result = await stripe_mgr.handle_webhook(payload, sig)
#     if result:
#         account = await wallet.get_account_by_stripe_customer(result["customer_id"])
#         await wallet.deposit(account, result["amount"], result["payment_id"])
#     return {"ok": True}
