"""
pinchfin MCP Server
====================
Remote MCP server exposing pinchfin CRE underwriting capabilities.
All orchestration, prompts, credit box logic, and RAG corpus remain server-side.
Users interact via Claude Code tool calls only.

Every analysis tool follows the estimate > confirm > execute > settle flow.
Users see cost estimates before any billable work runs.

(c) Veleta Capital LLC. All rights reserved.
"""

import os
import json
import httpx
import logging
from typing import Optional, List, Literal
from contextlib import asynccontextmanager

from mcp.server.fastmcp import FastMCP, Context
from pydantic import BaseModel, Field, ConfigDict

PINCHFIN_API_BASE = os.environ.get("PINCHFIN_API_URL", "https://pinchfin-api-production.up.railway.app/v1")
LOG = logging.getLogger("pinchfin_mcp")


@asynccontextmanager
async def app_lifespan(server):
    api_key = os.environ.get("PINCHFIN_API_KEY", "")
    client = httpx.AsyncClient(
        base_url=PINCHFIN_API_BASE,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "X-Client": "pinchfin-mcp",
        },
        timeout=120.0,
    )
    yield {"client": client}
    await client.aclose()


mcp = FastMCP("pinchfin_mcp", lifespan=app_lifespan)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------
async def _api_call(ctx: Context, endpoint: str, payload: dict) -> dict:
    client: httpx.AsyncClient = ctx.request_context.lifespan_state["client"]
    try:
        resp = await client.post(endpoint, json=payload)
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPStatusError as e:
        status = e.response.status_code
        if status == 401:
            return {"error": "Authentication failed. Run `pinchfin login` to refresh your API key."}
        elif status == 402:
            body = e.response.json()
            return {
                "error": "Insufficient funds.",
                "balance": body.get("balance"),
                "required": body.get("required"),
                "deposit_url": body.get("deposit_url"),
                "message": (
                    f"Your balance is ${body.get('balance', 0):.2f}. "
                    f"This analysis requires approximately ${body.get('required', 0):.2f}. "
                    f"Load funds at: {body.get('deposit_url', 'https://app.pinchfin.com/billing')}"
                ),
            }
        elif status == 403:
            return {"error": "Access denied. Contact support@pinchfin.com."}
        elif status == 429:
            return {"error": "Rate limit reached. Please wait before retrying."}
        elif status == 422:
            detail = e.response.json().get("detail", "Validation error")
            return {"error": f"Input validation failed: {detail}"}
        return {"error": f"API error (HTTP {status}). Please retry or contact support."}
    except httpx.TimeoutException:
        return {"error": "Request timed out. Full workflows can take 60-90s. Please retry."}
    except Exception as e:
        LOG.error(f"Unexpected error: {e}")
        return {"error": "Unexpected error. Please retry or contact support@pinchfin.com."}


async def _api_get(ctx: Context, endpoint: str, params: dict = None) -> dict:
    client: httpx.AsyncClient = ctx.request_context.lifespan_state["client"]
    try:
        resp = await client.get(endpoint, params=params)
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPStatusError as e:
        status = e.response.status_code
        if status == 401:
            return {"error": "Authentication failed. Run `pinchfin login` to refresh your API key."}
        elif status == 403:
            return {"error": "Access denied. Contact support@pinchfin.com."}
        elif status == 429:
            return {"error": "Rate limit reached. Please wait before retrying."}
        return {"error": f"API error (HTTP {status}). Please retry or contact support."}
    except httpx.TimeoutException:
        return {"error": "Request timed out. Please retry."}
    except Exception as e:
        LOG.error(f"Unexpected error: {e}")
        return {"error": "Unexpected error. Please retry or contact support@pinchfin.com."}


def _format_result(data: dict) -> str:
    if "error" in data:
        return json.dumps({"error": data.get("message", data["error"])}, indent=2)
    return json.dumps(data, indent=2, default=str)


def _format_cost_report(data: dict) -> str:
    cost = data.get("cost", {})
    if cost:
        return json.dumps({
            "billing": {
                "actual_cost": round(cost.get("actual", 0), 2),
                "remaining_balance": round(cost.get("remaining_balance", 0), 2),
            }
        }, indent=2)
    return ""


async def _estimate_or_execute(ctx, params, modules: list, endpoint: str,
                                unit_count=None, doc_count=None, doc_pages=None,
                                transcript_count=None, is_rerun=False):
    """Shared estimate-then-execute flow for all billable tools."""
    payload = params.model_dump(exclude_none=True)
    confirmed = payload.pop("confirmed", False)

    if not confirmed:
        estimate_payload = {
            "modules": modules,
            "unit_count": unit_count,
            "document_count": doc_count,
            "document_pages": doc_pages,
            "transcript_count": transcript_count,
            "is_rerun": is_rerun,
        }
        # Remove None values
        estimate_payload = {k: v for k, v in estimate_payload.items() if v is not None}
        result = await _api_call(ctx, "/billing/estimate", estimate_payload)
        if "error" not in result:
            result["action_required"] = "Review the cost estimate. To proceed, call this tool again with confirmed=true."
        return _format_result(result)

    await ctx.report_progress(progress=0.1, total=1.0)
    result = await _api_call(ctx, endpoint, payload)
    if "error" not in result:
        await ctx.report_progress(progress=1.0, total=1.0)
    return _format_result(result)


# =====================================================================
# BILLING & ACCOUNT TOOLS (free)
# =====================================================================

class EstimateCostInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    modules: List[str] = Field(..., description="List of analysis modules to estimate cost for (e.g. ['deal_screen', 'market_research'])", min_length=1)
    unit_count: Optional[int] = Field(None, ge=1, description="Total residential unit count at the property")
    document_count: Optional[int] = Field(None, ge=0, description="Number of documents to be processed")
    document_pages: Optional[int] = Field(None, ge=0, description="Total page count across all documents")
    transcript_count: Optional[int] = Field(None, ge=0, description="Number of call transcripts or email threads to process")
    is_rerun: Optional[bool] = Field(False, description="Whether this is a re-run of a previously executed analysis (discounted ~35%)")

@mcp.tool(name="pinchfin_estimate_cost", annotations={"title": "Estimate Analysis Cost", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_estimate_cost(params: EstimateCostInput, ctx: Context) -> str:
    """Estimate cost before running analysis. Returns cost range and current balance. Always call before billable work."""
    result = await _api_call(ctx, "/billing/estimate", params.model_dump(exclude_none=True))
    return _format_result(result)


class AccountInfoInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    include_transactions: Optional[bool] = Field(True, description="Whether to include recent transaction history in the response")
    transaction_limit: Optional[int] = Field(10, ge=1, le=50, description="Maximum number of recent transactions to return")

@mcp.tool(name="pinchfin_account", annotations={"title": "Account Info & Balance", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_account(params: AccountInfoInput, ctx: Context) -> str:
    """Check balance, available funds, and recent transactions. FREE."""
    result = await _api_get(ctx, "/billing/account", params=params.model_dump(exclude_none=True))
    return _format_result(result)


class DepositFundsInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    amount: float = Field(..., description="Amount in USD to deposit (minimum $25, maximum $10,000)", ge=25.0, le=10000.0)

@mcp.tool(name="pinchfin_deposit", annotations={"title": "Load Funds", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": True})
async def pinchfin_deposit(params: DepositFundsInput, ctx: Context) -> str:
    """Load funds via Stripe. Returns a secure checkout URL. Minimum $25."""
    result = await _api_call(ctx, "/billing/deposit", params.model_dump())
    return _format_result(result)


# =====================================================================
# DEAL SCREENING (Phase 1) — ~$0.10-$0.50
# =====================================================================

class DealScreenInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    property_address: str = Field(..., min_length=5, description="Full street address of the property")
    unit_count: int = Field(..., ge=1, le=10000, description="Total residential unit count")
    loan_amount: float = Field(..., gt=0, description="Requested loan amount in USD")
    purchase_price: Optional[float] = Field(None, gt=0, description="Purchase price in USD (for acquisitions)")
    asset_value: Optional[float] = Field(None, gt=0, description="Estimated or appraised asset value in USD")
    loan_purpose: Optional[Literal["bridge", "acquisition", "refinance", "construction", "permanent"]] = Field("bridge", description="Purpose of the loan")
    sponsor_name: Optional[str] = Field(None, description="Name of the sponsoring entity or principal")
    notes: Optional[str] = Field(None, max_length=5000, description="Additional deal context, business plan, or known issues")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_deal_screen", annotations={"title": "Quick Deal Screening", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_deal_screen(params: DealScreenInput, ctx: Context) -> str:
    """Screen a multifamily deal against credit box criteria. ~$0.10-$0.50. First call returns cost estimate; set confirmed=true to execute."""
    return await _estimate_or_execute(ctx, params, ["deal_screen"], "/screen",
                                       unit_count=params.unit_count)


# =====================================================================
# DEAL BOOK (Phase 2) — ~$0.75-$3 depending on documents
# =====================================================================

class DealBookInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Existing deal ID to associate with this analysis")
    property_address: Optional[str] = Field(None, description="Full street address of the property")
    unit_count: Optional[int] = Field(None, ge=1, description="Total residential unit count")
    loan_amount: Optional[float] = Field(None, gt=0, description="Requested loan amount in USD")
    documents_path: Optional[str] = Field(None, description="Local path to deal documents folder")
    transcript_path: Optional[str] = Field(None, description="Local path to call transcripts and email correspondence")
    sponsor_name: Optional[str] = Field(None, description="Name of the sponsoring entity or principal")
    broker_name: Optional[str] = Field(None, description="Name of the originating broker or intermediary")
    deal_narrative: Optional[str] = Field(None, max_length=10000, description="Free-form deal narrative, business plan summary, or operator notes")
    document_count: Optional[int] = Field(None, ge=0, description="Number of documents to be processed")
    document_pages: Optional[int] = Field(None, ge=0, description="Total page count across all documents")
    transcript_count: Optional[int] = Field(None, ge=0, description="Number of call transcripts or email threads to process")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_deal_book", annotations={"title": "Create Deal Book", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": True})
async def pinchfin_deal_book(params: DealBookInput, ctx: Context) -> str:
    """Synthesize documents, transcripts, and emails into a structured deal package. ~$0.75-$3 based on document volume."""
    return await _estimate_or_execute(ctx, params, ["deal_book", "document_synthesis"], "/deal-book",
                                       unit_count=params.unit_count, doc_count=params.document_count,
                                       doc_pages=params.document_pages, transcript_count=params.transcript_count)


# =====================================================================
# INDIVIDUAL MODULES (each ~$0.25-$3)
# =====================================================================

class SponsorAnalysisInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Existing deal ID to associate with this analysis")
    sponsor_name: str = Field(..., min_length=1, description="Name of the sponsoring entity or principal")
    sponsor_website: Optional[str] = Field(None, description="URL of the sponsor's website for additional context")
    additional_context: Optional[str] = Field(None, max_length=5000, description="Additional context about the sponsor (e.g. prior relationship, known track record)")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_sponsor_analysis", annotations={"title": "Sponsor Analysis", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_sponsor_analysis(params: SponsorAnalysisInput, ctx: Context) -> str:
    """Sponsor due diligence: entity verification, portfolio, litigation, bankruptcy, experience scoring. ~$0.50-$2.00."""
    return await _estimate_or_execute(ctx, params, ["sponsor_analysis"], "/modules/sponsor-analysis")


class MarketResearchInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Existing deal ID to associate with this analysis")
    property_address: str = Field(..., min_length=5, description="Full street address of the property")
    radius_miles: Optional[float] = Field(3.0, ge=0.5, le=25.0, description="Search radius in miles for market data and comps")
    include_demographics: Optional[bool] = Field(True, description="Include Census/ACS demographic analysis")
    include_employment: Optional[bool] = Field(True, description="Include BLS employment and major employer analysis")
    include_supply_pipeline: Optional[bool] = Field(True, description="Include multifamily construction pipeline and absorption data")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_market_research", annotations={"title": "Market Research & Demographics", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_market_research(params: MarketResearchInput, ctx: Context) -> str:
    """Submarket fundamentals: rent trends, vacancy, demographics, employment, supply pipeline. ~$0.50-$1.50."""
    return await _estimate_or_execute(ctx, params, ["market_research"], "/modules/market-research")


class CompAnalysisInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Existing deal ID to associate with this analysis")
    property_address: str = Field(..., min_length=5, description="Full street address of the property")
    unit_count: int = Field(..., ge=1, description="Total residential unit count")
    asset_class: Optional[Literal["A", "B", "C", "D", "B+", "B-", "C+"]] = Field("B", description="Property asset class grade")
    year_built: Optional[int] = Field(None, description="Year the property was originally constructed")
    comp_types: Optional[List[str]] = Field(default_factory=lambda: ["sales", "rent"], description="Types of comparables to search (e.g. 'sales', 'rent')")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_comp_analysis", annotations={"title": "Comparable Sales & Rent Analysis", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_comp_analysis(params: CompAnalysisInput, ctx: Context) -> str:
    """Comparable sales, rents, and financing analysis with adjustments. ~$0.50-$1.50."""
    return await _estimate_or_execute(ctx, params, ["comp_analysis"], "/modules/comp-analysis",
                                       unit_count=params.unit_count)


class RentRollAnalyzerInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Existing deal ID to associate with this analysis")
    property_address: Optional[str] = Field(None, description="Full street address of the property")
    unit_count: Optional[int] = Field(None, ge=1, description="Total residential unit count")
    rent_roll_path: str = Field(..., min_length=1, description="Local file path to the rent roll document (PDF, Excel, or CSV)")
    market_rent_estimate: Optional[float] = Field(None, description="Estimated market rent per unit per month for loss-to-lease analysis")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_rent_roll_analyzer", annotations={"title": "Rent Roll Analyzer", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_rent_roll_analyzer(params: RentRollAnalyzerInput, ctx: Context) -> str:
    """Parse and analyze rent rolls: occupancy, loss-to-lease, concessions, unit mix, anomalies. ~$0.25-$1."""
    return await _estimate_or_execute(ctx, params, ["rent_roll_analyzer"], "/modules/rent-roll-analyzer",
                                       unit_count=params.unit_count)


class CashFlowInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Existing deal ID to associate with this analysis")
    property_address: str = Field(..., min_length=5, description="Full street address of the property")
    unit_count: int = Field(..., ge=1, description="Total residential unit count")
    current_revenue: Optional[float] = Field(None, description="Current annualized gross revenue in USD")
    current_noi: Optional[float] = Field(None, description="Current annualized net operating income in USD")
    pro_forma_rents: Optional[float] = Field(None, description="Projected stabilized rent per unit per month in USD")
    t12_path: Optional[str] = Field(None, description="Local file path to trailing 12-month operating statement")
    rent_roll_path: Optional[str] = Field(None, description="Local file path to current rent roll document")
    projection_years: Optional[int] = Field(5, ge=1, le=10, description="Number of years to project cash flows (1-10)")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_cash_flow", annotations={"title": "Cash Flow Underwriting", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_cash_flow(params: CashFlowInput, ctx: Context) -> str:
    """Deterministic cash flow underwriting with base/upside/downside scenarios. ~$0.50-$1.50."""
    return await _estimate_or_execute(ctx, params, ["cash_flow"], "/modules/cash-flow",
                                       unit_count=params.unit_count)


class LoanSizerInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Existing deal ID to associate with this analysis")
    property_address: Optional[str] = Field(None, description="Full street address of the property")
    loan_amount_requested: float = Field(..., gt=0, description="Sponsor's requested loan amount in USD")
    asset_value: float = Field(..., gt=0, description="Estimated or appraised asset value in USD")
    noi: float = Field(..., gt=0, description="Net operating income used for sizing (stabilized/proforma) in USD")
    loan_purpose: Optional[Literal["bridge", "acquisition", "refinance", "construction", "permanent"]] = Field("bridge", description="Purpose of the loan")
    rate_type: Optional[Literal["floating", "fixed"]] = Field("floating", description="Interest rate type for debt service calculation")
    term_months: Optional[int] = Field(36, ge=6, le=120, description="Loan term in months (6-120)")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_loan_sizer", annotations={"title": "Loan Sizing (Lender Sizer)", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_loan_sizer(params: LoanSizerInput, ctx: Context) -> str:
    """Size loan against credit box: LTV, DSCR, debt yield, constraint binding analysis. ~$0.25-$1."""
    return await _estimate_or_execute(ctx, params, ["loan_sizer"], "/modules/loan-sizer")


class NuanceGateInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: str = Field(..., min_length=1, description="Deal ID to run nuance gate analysis on")
    nuance_topic: Optional[str] = Field(None, description="Specific nuance to investigate (e.g. 'ground lease', 'reverse 1031 exchange', 'LIHTC 4% credits', 'rent stabilization')")
    focus_areas: Optional[List[str]] = Field(None, description="Specific nuance areas to focus on (e.g. 'affordable', 'ground_lease', 'rent_control')")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_nuance_gate", annotations={"title": "Nuance Gate Analysis (NGM)", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_nuance_gate(params: NuanceGateInput, ctx: Context) -> str:
    """Deep nuance research, classification, and operationalization. Investigates complex deal features (ground leases, 1031 exchanges, LIHTC, rent stabilization, etc.), classifies their impact, and produces a report explaining how to underwrite the transaction. ~$0.50-$2."""
    return await _estimate_or_execute(ctx, params, ["nuance_gate"], "/modules/nuance-gate")


class ICMemoInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: str = Field(..., min_length=1, description="Deal ID to generate IC memo for (must have Phases 1-11 complete)")
    memo_format: Optional[Literal["full", "summary"]] = Field("full", description="Memo format: 'full' for complete IC memo, 'summary' for condensed version")
    include_appendices: Optional[bool] = Field(True, description="Whether to include detailed appendices with supporting data")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_ic_memo", annotations={"title": "IC Memo Generation", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_ic_memo(params: ICMemoInput, ctx: Context) -> str:
    """Institutional-grade Investment Committee memo. Requires Phases 1-11. ~$1-$3."""
    return await _estimate_or_execute(ctx, params, ["ic_memo"], "/modules/ic-memo")


# =====================================================================
# TERM SHEET COMPARATOR — ~$0.50-$1.50
# =====================================================================

class TermSheetComparatorInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Deal ID to associate comparison with")
    term_sheets: List[dict] = Field(..., min_length=2, description="List of term sheet data objects to compare. Each should include lender_name, loan_amount, rate, term, fees, and structure details.")
    property_address: Optional[str] = Field(None, description="Property address for context")
    loan_amount: Optional[float] = Field(None, gt=0, description="Target loan amount in USD")
    comparison_criteria: Optional[List[str]] = Field(None, description="Specific criteria to emphasize (e.g. 'prepayment', 'extension_options', 'rate_cap', 'covenants')")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_term_sheet_comparator", annotations={"title": "Term Sheet Comparator", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_term_sheet_comparator(params: TermSheetComparatorInput, ctx: Context) -> str:
    """Compare multiple term sheets side by side: rates, fees, structure, covenants, prepay, extensions, all-in cost. ~$0.50-$1.50."""
    return await _estimate_or_execute(ctx, params, ["term_sheet_comparator"], "/modules/term-sheet-comparator")


# =====================================================================
# LOAN PRICING — ~$0.25-$1
# =====================================================================

class LoanPricingInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Deal ID to associate pricing with")
    loan_amount: float = Field(..., gt=0, description="Loan amount in USD")
    rate_type: Literal["floating", "fixed"] = Field("floating", description="Interest rate type")
    index: Optional[Literal["SOFR", "Prime", "Treasury"]] = Field("SOFR", description="Rate index for floating rate loans")
    spread_bps: Optional[int] = Field(None, ge=0, le=1000, description="Spread over index in basis points")
    loan_term_months: Optional[int] = Field(36, ge=6, le=120, description="Loan term in months")
    rate_cap_required: Optional[bool] = Field(True, description="Whether to include rate cap analysis")
    rate_cap_strike: Optional[float] = Field(None, description="Rate cap strike rate (if known)")
    interest_reserve_months: Optional[int] = Field(None, ge=0, le=24, description="Months of interest reserve to analyze")
    noi: Optional[float] = Field(None, gt=0, description="Net operating income for debt service coverage")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_loan_pricing", annotations={"title": "Loan Pricing & Rate Cap Analysis", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_loan_pricing(params: LoanPricingInput, ctx: Context) -> str:
    """Rate build-up (index + spread), rate cap cost analysis, interest reserve sizing, all-in cost of capital. ~$0.25-$1."""
    return await _estimate_or_execute(ctx, params, ["loan_pricing"], "/modules/loan-pricing")


# =====================================================================
# BUSINESS PLAN ANALYSIS — ~$0.50-$2
# =====================================================================

class BusinessPlanAnalysisInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Deal ID to associate analysis with")
    property_address: str = Field(..., min_length=5, description="Full street address of the property")
    unit_count: int = Field(..., ge=1, description="Total residential unit count")
    current_avg_rent: Optional[float] = Field(None, description="Current average in-place rent per unit per month")
    pro_forma_rent: Optional[float] = Field(None, description="Sponsor's projected stabilized rent per unit per month")
    renovation_budget: Optional[float] = Field(None, gt=0, description="Total renovation/capex budget in USD")
    renovation_per_unit: Optional[float] = Field(None, description="Renovation budget per unit in USD")
    lease_up_months: Optional[int] = Field(None, ge=0, description="Projected months to stabilization")
    rent_growth_assumption: Optional[float] = Field(None, description="Annual rent growth assumption as decimal (e.g. 0.03 for 3%)")
    business_plan_narrative: Optional[str] = Field(None, max_length=10000, description="Sponsor's business plan description, renovation scope, and value-add thesis")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_business_plan_analysis", annotations={"title": "Business Plan Analysis", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_business_plan_analysis(params: BusinessPlanAnalysisInput, ctx: Context) -> str:
    """Evaluate sponsor's business plan: rent growth assumptions, capex budget, timeline, lease-up curve, feasibility assessment. ~$0.50-$2."""
    return await _estimate_or_execute(ctx, params, ["business_plan_analysis"], "/modules/business-plan-analysis",
                                       unit_count=params.unit_count)


# =====================================================================
# DEBT SIZING PREVIEW — ~$0.25-$0.75
# =====================================================================

class DebtSizingPreviewInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Deal ID to associate with")
    property_address: str = Field(..., min_length=5, description="Full street address of the property")
    unit_count: int = Field(..., ge=1, description="Total residential unit count")
    asset_value: float = Field(..., gt=0, description="Estimated or appraised asset value in USD")
    noi: float = Field(..., gt=0, description="Net operating income (stabilized) in USD")
    total_cost: Optional[float] = Field(None, gt=0, description="Total project cost (acquisition + renovation) in USD")
    loan_purpose: Optional[Literal["bridge", "acquisition", "refinance"]] = Field("bridge", description="Purpose of the loan")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_debt_sizing_preview", annotations={"title": "Debt Sizing Preview", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_debt_sizing_preview(params: DebtSizingPreviewInput, ctx: Context) -> str:
    """Quick debt sizing: 'How much can I borrow?' Constraint waterfall, binding constraint identification, gap analysis. Lighter than full loan_sizer. ~$0.25-$0.75."""
    return await _estimate_or_execute(ctx, params, ["debt_sizing_preview"], "/modules/debt-sizing-preview",
                                       unit_count=params.unit_count)


# =====================================================================
# RENOVATION ROI — ~$0.50-$2
# =====================================================================

class RenovationROIInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: Optional[str] = Field(None, description="Deal ID to associate with")
    property_address: str = Field(..., min_length=5, description="Full street address of the property")
    unit_count: int = Field(..., ge=1, description="Total residential unit count")
    current_avg_rent: float = Field(..., description="Current average in-place rent per unit per month")
    target_rent: Optional[float] = Field(None, description="Target rent per unit per month after renovation")
    renovation_budget_total: Optional[float] = Field(None, gt=0, description="Total renovation budget in USD")
    renovation_per_unit: Optional[float] = Field(None, gt=0, description="Renovation budget per unit in USD")
    scope_description: Optional[str] = Field(None, max_length=5000, description="Description of renovation scope (e.g. 'full interior rehab: kitchens, baths, flooring, appliances')")
    hold_period_months: Optional[int] = Field(36, ge=12, le=120, description="Expected hold period in months for ROI calculation")
    asset_class_current: Optional[Literal["A", "B", "C", "D", "B+", "B-", "C+"]] = Field(None, description="Current asset class before renovation")
    asset_class_target: Optional[Literal["A", "B", "C", "D", "B+", "B-", "C+"]] = Field(None, description="Target asset class after renovation")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_renovation_roi", annotations={"title": "Renovation ROI Analysis", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_renovation_roi(params: RenovationROIInput, ctx: Context) -> str:
    """Analyze rehab scope vs. rent premium: renovation budget, rent lift potential, payback period, ROI by scope tier. ~$0.50-$2."""
    return await _estimate_or_execute(ctx, params, ["renovation_roi"], "/modules/renovation-roi",
                                       unit_count=params.unit_count)


# =====================================================================
# FREE UTILITY TOOLS
# =====================================================================

class DealStatusInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: str = Field(..., min_length=1, description="Deal ID to check workflow progress for")

@mcp.tool(name="pinchfin_deal_status", annotations={"title": "Check Deal Status", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_deal_status(params: DealStatusInput, ctx: Context) -> str:
    """Check workflow progress on any deal. FREE."""
    return _format_result(await _api_get(ctx, "/deals/status", params=params.model_dump()))

class ListDealsInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    status: Optional[Literal["active", "completed", "archived", "all"]] = Field("active", description="Filter deals by status")
    limit: Optional[int] = Field(20, ge=1, le=100, description="Maximum number of deals to return (1-100)")
    offset: Optional[int] = Field(0, ge=0, description="Number of deals to skip for pagination")

@mcp.tool(name="pinchfin_list_deals", annotations={"title": "List Deals", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_list_deals(params: ListDealsInput, ctx: Context) -> str:
    """List all deals in your account. FREE."""
    return _format_result(await _api_get(ctx, "/deals/list", params=params.model_dump(exclude_none=True)))

class UploadDocsInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    deal_id: str = Field(..., min_length=1, description="Deal ID to upload documents to")
    documents_path: str = Field(..., min_length=1, description="Local path to the documents folder or file to upload")
    document_types: Optional[List[str]] = Field(None, description="List of document types being uploaded (e.g. 'rent_roll', 't12', 'appraisal', 'om')")

@mcp.tool(name="pinchfin_upload_docs", annotations={"title": "Upload Deal Documents", "readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": True})
async def pinchfin_upload_docs(params: UploadDocsInput, ctx: Context) -> str:
    """Upload documents to a deal. FREE — processing costs included in analysis modules."""
    await ctx.report_progress(progress=0.1, total=1.0)
    result = await _api_call(ctx, "/documents/upload", params.model_dump(exclude_none=True))
    await ctx.report_progress(progress=1.0, total=1.0)
    return _format_result(result)


# =====================================================================
# COMPOSITE TOOLS
# =====================================================================

class QuickReviewInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    property_address: str = Field(..., min_length=5, description="Full street address of the property")
    unit_count: int = Field(..., ge=1, le=10000, description="Total residential unit count")
    loan_amount: float = Field(..., gt=0, description="Requested loan amount in USD")
    purchase_price: Optional[float] = Field(None, gt=0, description="Purchase price in USD (for acquisitions)")
    asset_value: Optional[float] = Field(None, gt=0, description="Estimated or appraised asset value in USD")
    loan_purpose: Optional[Literal["bridge", "acquisition", "refinance", "construction", "permanent"]] = Field("bridge", description="Purpose of the loan")
    sponsor_name: str = Field(..., min_length=1, description="Name of the sponsoring entity or principal")
    notes: Optional[str] = Field(None, max_length=10000, description="Deal context, business plan, known issues, or broker intel")
    current_noi: Optional[float] = Field(None, description="Current annualized net operating income in USD")
    pro_forma_rents: Optional[float] = Field(None, description="Projected stabilized rent per unit per month in USD")
    is_rerun: Optional[bool] = Field(False, description="Whether this is a re-run of a previously evaluated deal (discounted ~35%)")
    confirmed: Optional[bool] = Field(False, description="Set to true after reviewing cost estimate to execute the analysis")

@mcp.tool(name="pinchfin_quick_review", annotations={"title": "Quick Review (10-Minute Workflow)", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": True})
async def pinchfin_quick_review(params: QuickReviewInput, ctx: Context) -> str:
    """10-minute deal evaluation: screen + sponsor + market + comps + cash flow + sizing + short-form memo in one call. ~$2-$6."""
    return await _estimate_or_execute(ctx, params, ["quick_review"], "/modules/quick-review",
                                       unit_count=params.unit_count, is_rerun=params.is_rerun or False)


# =====================================================================
# PREFERRED EQUITY QUICK REVIEW
# =====================================================================

class PrefEquityQRInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    property_address: str = Field(..., min_length=5, description="Full street address of the property")
    unit_count: int = Field(..., ge=1, le=10000, description="Total residential unit count")
    senior_loan_amount: float = Field(..., gt=0, description="Senior loan amount in USD")
    senior_rate: float = Field(..., gt=0, le=0.25, description="Senior loan interest rate (decimal, e.g. 0.0775)")
    pref_equity_requested: Optional[float] = Field(None, gt=0, description="Requested pref equity amount in USD (optional — system will size if omitted)")
    as_is_value: float = Field(..., gt=0, description="As-is appraised value in USD (land value for construction)")
    stabilized_value: Optional[float] = Field(None, gt=0, description="Stabilized value in USD (if known)")
    total_cost: float = Field(..., gt=0, description="Total project cost in USD")
    noi_stabilized: float = Field(..., gt=0, description="Stabilized NOI (lender underwrite) in USD")
    exit_cap_rate: Optional[float] = Field(0.0525, gt=0, le=0.15, description="Exit cap rate (decimal)")
    hold_months: Optional[int] = Field(36, ge=12, le=60, description="Expected hold period in months")
    current_pay_rate: Optional[float] = Field(0.06, ge=0, le=0.12, description="Pref current pay rate (decimal)")
    pik_rate: Optional[float] = Field(0.08, ge=0, le=0.15, description="PIK accrual rate (decimal)")
    construction_quarters: Optional[int] = Field(8, ge=0, le=16, description="Construction period in quarters (0 for stabilized acquisitions)")
    leaseup_quarters: Optional[int] = Field(3, ge=0, le=8, description="Lease-up period in quarters")
    sponsor_name: Optional[str] = Field(None, min_length=1, description="Sponsor entity name")
    notes: Optional[str] = Field(None, max_length=10000, description="Additional deal context")
    confirmed: Optional[bool] = Field(False, description="Set True after reviewing cost estimate to execute")
    is_rerun: Optional[bool] = Field(False, description="True if re-running a previously analyzed deal")


@mcp.tool(
    name="pinchfin_pref_equity_qr",
    annotations={
        "title": "Preferred Equity Quick Review",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def pinchfin_pref_equity_qr(params: PrefEquityQRInput, ctx: Context) -> str:
    """Preferred equity sizing & analysis: two-pass constraint waterfall (senior + pref), PIK accrual modeling, 5-scenario exit waterfall, sponsor impact, and return sensitivity. ~$3-$8."""
    return await _estimate_or_execute(
        ctx, params, ["pref_equity_qr"], "/modules/pref-equity-qr",
        unit_count=params.unit_count, is_rerun=params.is_rerun or False,
    )


# =====================================================================
# FREE INFORMATION TOOL
# =====================================================================

@mcp.tool(name="pinchfin_help", annotations={"title": "pinchfin Help & Pricing", "readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False})
async def pinchfin_help(ctx: Context) -> str:
    """List all available pinchfin tools with costs, descriptions, and usage tips. FREE — no API call."""
    help_data = {
        "tools": {
            "billable": [
                {"name": "pinchfin_deal_screen", "cost": "$0.10-$0.50", "description": "Quick pass/fail screening against credit box"},
                {"name": "pinchfin_deal_book", "cost": "$0.75-$3", "description": "Document and transcript synthesis into structured deal narrative"},
                {"name": "pinchfin_sponsor_analysis", "cost": "$0.50-$2", "description": "30+ page institutional sponsor due diligence report"},
                {"name": "pinchfin_market_research", "cost": "$0.50-$1.50", "description": "30+ page market & submarket analysis report"},
                {"name": "pinchfin_comp_analysis", "cost": "$0.50-$1.50", "description": "30+ page comparable analysis & synthesis report"},
                {"name": "pinchfin_rent_roll_analyzer", "cost": "$0.25-$1", "description": "Rent roll parsing: occupancy, loss-to-lease, unit mix, anomalies"},
                {"name": "pinchfin_cash_flow", "cost": "$0.50-$1.50", "description": "Dual-scenario cash flow underwriting with T-12 anchor and expense normalization"},
                {"name": "pinchfin_loan_sizer", "cost": "$0.25-$1", "description": "6-constraint waterfall loan sizing with lender sizer output"},
                {"name": "pinchfin_nuance_gate", "cost": "$0.50-$2", "description": "Deep nuance research: ground leases, 1031s, LIHTC, rent stabilization — full investigation and operationalization"},
                {"name": "pinchfin_ic_memo", "cost": "$1-$3", "description": "Full Investment Committee memo"},
                {"name": "pinchfin_term_sheet_comparator", "cost": "$0.50-$1.50", "description": "Side-by-side comparison of multiple term sheets"},
                {"name": "pinchfin_loan_pricing", "cost": "$0.25-$1", "description": "Rate build-up, rate cap analysis, interest reserve sizing, all-in cost"},
                {"name": "pinchfin_business_plan_analysis", "cost": "$0.50-$2", "description": "Evaluate sponsor business plan: rent growth, capex, timeline, feasibility"},
                {"name": "pinchfin_debt_sizing_preview", "cost": "$0.25-$0.75", "description": "Quick debt sizing preview with constraint waterfall and gap analysis"},
                {"name": "pinchfin_renovation_roi", "cost": "$0.50-$2", "description": "Renovation scope vs. rent premium: budget, rent lift, payback, ROI by tier"},
                {"name": "pinchfin_quick_review", "cost": "$2-$6", "description": "10-minute screening: deal screen + rent roll + expense + cash flow + sizing + memo"},
                {"name": "pinchfin_pref_equity_qr", "cost": "$3-$8", "description": "Pref equity sizing: two-pass constraint waterfall, PIK accrual, exit waterfall, sponsor impact, return sensitivity"},
            ],
            "free": [
                {"name": "pinchfin_estimate_cost", "description": "Pre-run cost estimate for any module combination"},
                {"name": "pinchfin_account", "description": "Check balance, held funds, and recent transactions"},
                {"name": "pinchfin_deposit", "description": "Load funds via Stripe checkout"},
                {"name": "pinchfin_deal_status", "description": "Check workflow progress on any deal"},
                {"name": "pinchfin_list_deals", "description": "List all deals in your account"},
                {"name": "pinchfin_upload_docs", "description": "Upload documents to a deal"},
                {"name": "pinchfin_help", "description": "This help message"},
            ],
        },
        "cost_factors": {
            "unit_count": "<50 units: 0.8x | 50-150: 1.0x | 150-300: 1.2x | 300-500: 1.4x | 500+: 1.6x",
            "document_count": "1-3: 0.9x | 4-8: 1.0x | 9-15: 1.3x | 15+: 1.6x",
            "rerun_discount": "35% discount on re-runs (cached context)",
            "document_pages": "$0.05/page additional for document-heavy modules",
        },
        "tips": [
            "Start with pinchfin_deal_screen (~$0.25) to pre-qualify before deeper analysis",
            "Use pinchfin_quick_review (~$3-5) for the fastest path to an analysis memo",
            "Run the 3 core reports (sponsor + market + comps) for institutional-grade research",
            "Brokers: use pinchfin_term_sheet_comparator to evaluate competing offers",
            "Sponsors: use pinchfin_debt_sizing_preview for quick 'how much can I borrow' answers",
            "Use pinchfin_nuance_gate when you encounter complex deal features (ground lease, LIHTC, etc.)",
            "Re-runs are ~35% cheaper thanks to cached context",
        ],
        "billing": {
            "minimum_deposit": "$25",
            "new_account_credit": "$10 free",
            "estimate_before_charge": "Every billable tool shows cost estimate first — you always confirm",
        },
    }
    return json.dumps(help_data, indent=2)


# =====================================================================
# ENTRY POINT
# =====================================================================
if __name__ == "__main__":
    import sys
    transport = "streamable_http" if "--remote" in sys.argv else "stdio"
    port = int(os.environ.get("PINCHFIN_MCP_PORT", "8420"))
    if transport == "streamable_http":
        mcp.run(transport="streamable_http", port=port)
    else:
        mcp.run()
