"""
pinchfin CLI — Setup, authentication, and account management.

Usage:
    pinchfin login          Authenticate with your pinchfin account
    pinchfin setup          Install MCP server config into Claude Code
    pinchfin status         Check connection and subscription status
    pinchfin balance        Check account balance and recent charges
    pinchfin deposit        Load funds into your account
    pinchfin usage          View usage history and per-deal costs
    pinchfin pricing        Display full pricing table
    pinchfin help           List all tools with costs and tips
    pinchfin logout         Remove credentials
"""

import os
import sys
import json
import getpass
import webbrowser
from pathlib import Path

import httpx

# ---------------------------------------------------------------------------
# Paths & Config
# ---------------------------------------------------------------------------
HOME = Path.home()
PINCHFIN_DIR = HOME / ".pinchfin"
CREDENTIALS_FILE = PINCHFIN_DIR / "credentials.json"
PROJECT_MCP_CONFIG = Path(".mcp.json")

PINCHFIN_API_URL = "https://pinchfin-api-production.up.railway.app/v1"
MIN_DEPOSIT = 25.00


def ensure_dirs():
    PINCHFIN_DIR.mkdir(parents=True, exist_ok=True)
    (HOME / ".claude").mkdir(parents=True, exist_ok=True)


def _load_creds() -> dict:
    if not CREDENTIALS_FILE.exists():
        print("\n  ❌ Not authenticated. Run `pinchfin login` first.\n")
        sys.exit(1)
    return json.loads(CREDENTIALS_FILE.read_text())


def _api_get(endpoint: str, api_key: str) -> dict:
    """Make authenticated GET request to pinchfin API."""
    try:
        resp = httpx.get(
            f"{PINCHFIN_API_URL}{endpoint}",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=15.0,
        )
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPStatusError as e:
        return {"error": f"API error (HTTP {e.response.status_code})"}
    except Exception as e:
        return {"error": str(e)}


def _api_post(endpoint: str, api_key: str, data: dict = None) -> dict:
    """Make authenticated POST request to pinchfin API."""
    try:
        resp = httpx.post(
            f"{PINCHFIN_API_URL}{endpoint}",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json=data or {},
            timeout=15.0,
        )
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPStatusError as e:
        return {"error": f"API error (HTTP {e.response.status_code})"}
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_login():
    """Authenticate with pinchfin and store API key."""
    ensure_dirs()

    print("\n  🏛️  pinchfin — CRE Underwriting Platform")
    print("  ─────────────────────────────────────────\n")
    print("  Enter your pinchfin API key.")
    print("  (Find it at https://app.pinchfin.com/settings/api-keys)\n")

    api_key = getpass.getpass("  API Key: ").strip()

    if not api_key:
        print("\n  ❌ No API key provided. Aborting.")
        sys.exit(1)

    # Validate against API
    print("\n  Validating...")
    result = _api_get("/billing/account", api_key)

    if "error" in result:
        print(f"  ❌ Authentication failed: {result['error']}")
        print("  Check your API key and try again.\n")
        sys.exit(1)

    creds = {"api_key": api_key, "api_url": PINCHFIN_API_URL}
    CREDENTIALS_FILE.write_text(json.dumps(creds, indent=2))
    if sys.platform != "win32":
        os.chmod(CREDENTIALS_FILE, 0o600)

    account = result.get("account", {})
    balance = account.get("balance", 0)

    print("  ✅ Authenticated successfully.")
    print(f"  Account balance: ${balance:.2f}")

    if balance == 0:
        print(f"\n  💡 New account detected. You have $10.00 in free credits.")

    print(f"\n  Credentials stored in {CREDENTIALS_FILE}\n")

    # Auto-run setup
    cmd_setup()


def cmd_setup():
    """Install pinchfin MCP server configuration into Claude Code."""
    ensure_dirs()
    creds = _load_creds()
    api_key = creds.get("api_key", "")

    config = {
        "mcpServers": {
            "pinchfin": {
                "type": "stdio",
                "command": "python",
                "args": ["-m", "pinchfin_mcp"],
                "env": {
                    "PINCHFIN_API_KEY": api_key,
                    "PINCHFIN_API_URL": PINCHFIN_API_URL,
                },
                "description": "pinchfin CRE underwriting — multifamily bridge loan analysis",
            }
        }
    }

    if PROJECT_MCP_CONFIG.exists():
        existing = json.loads(PROJECT_MCP_CONFIG.read_text())
        existing.setdefault("mcpServers", {})
        existing["mcpServers"]["pinchfin"] = config["mcpServers"]["pinchfin"]
        PROJECT_MCP_CONFIG.write_text(json.dumps(existing, indent=2))
    else:
        PROJECT_MCP_CONFIG.write_text(json.dumps(config, indent=2))

    print(f"\n  ✅ MCP config written to {PROJECT_MCP_CONFIG.resolve()}")
    print()
    print("  Billable tools (cost shown before each run):")
    print("    • pinchfin_deal_screen         ~$0.50-2     Quick pass/fail")
    print("    • pinchfin_deal_book            ~$2-15       Document synthesis")
    print("    • pinchfin_sponsor_analysis     ~$2.50-7     Sponsor due diligence")
    print("    • pinchfin_market_research      ~$2-6        Market & demographics")
    print("    • pinchfin_comp_analysis        ~$2-6        Sales & rent comps")
    print("    • pinchfin_rent_roll_analyzer   ~$1.50-5     Rent roll parsing")
    print("    • pinchfin_cash_flow            ~$2.50-7     Cash flow projections")
    print("    • pinchfin_loan_sizer           ~$1-3        Credit box sizing")
    print("    • pinchfin_term_sheet           ~$2-5        Term sheet drafting")
    print("    • pinchfin_short_form_memo      ~$3-8        Quick analysis memo")
    print("    • pinchfin_nuance_gate          ~$2-5        Hidden risk analysis")
    print("    • pinchfin_ic_memo              ~$4-12       Full IC memo")
    print("    • pinchfin_quick_review         ~$8-25       Screen + modules + memo")
    print("    • pinchfin_full_workflow        ~$25-75+     Complete 15-phase")
    print()
    print("  Free tools:")
    print("    • pinchfin_account              Check balance")
    print("    • pinchfin_deposit              Load funds")
    print("    • pinchfin_estimate_cost        Pre-run cost estimate")
    print("    • pinchfin_deal_status          Check deal progress")
    print("    • pinchfin_list_deals           List all deals")
    print("    • pinchfin_upload_docs          Upload documents")
    print("    • pinchfin_help                 Tool list and tips")
    print()
    print("  Every billable tool shows cost estimate before running.")
    print("  You only pay for actual usage.\n")


def cmd_balance():
    """Check account balance and recent transactions."""
    creds = _load_creds()
    result = _api_get("/billing/account", creds["api_key"])

    if "error" in result:
        print(f"\n  ❌ {result['error']}\n")
        sys.exit(1)

    acct = result.get("account", {})
    txns = result.get("recent_transactions", [])

    print(f"\n  🏛️  pinchfin Account")
    print(f"  ─────────────────────────────────────────")
    print(f"  Balance:           ${acct.get('balance', 0):>10.2f}")
    print(f"  Held (in-progress): ${acct.get('held_amount', 0):>9.2f}")
    print(f"  Available:         ${acct.get('available_balance', 0):>10.2f}")
    print(f"  Total deposited:   ${acct.get('total_deposited', 0):>10.2f}")
    print(f"  Total spent:       ${acct.get('total_spent', 0):>10.2f}")
    print(f"  Analyses run:      {acct.get('total_analyses', 0):>10}")

    if txns:
        print(f"\n  Recent Transactions")
        print(f"  ─────────────────────────────────────────")
        for t in txns[:10]:
            sign = "+" if t["amount"] > 0 else ""
            print(f"  {t['created_at'][:10]}  {sign}${t['amount']:>8.2f}  {t['description']}")

    print()


def cmd_deposit():
    """Load funds into account."""
    creds = _load_creds()

    print("\n  🏛️  Load Funds")
    print("  ─────────────────────────────────────────\n")

    try:
        amount_str = input(f"  Amount (minimum ${MIN_DEPOSIT:.0f}): $").strip()
    except (KeyboardInterrupt, EOFError):
        print("\n  Cancelled.")
        sys.exit(0)
    try:
        amount = float(amount_str)
    except ValueError:
        print("  ❌ Invalid amount.")
        sys.exit(1)

    if amount < MIN_DEPOSIT:
        print(f"  ❌ Minimum deposit is ${MIN_DEPOSIT:.2f}")
        sys.exit(1)

    result = _api_post("/billing/deposit", creds["api_key"], {"amount": amount})

    if "error" in result:
        print(f"\n  ❌ {result['error']}\n")
        sys.exit(1)

    checkout_url = result.get("checkout_url")
    if checkout_url:
        print(f"\n  Opening Stripe checkout for ${amount:.2f}...")
        print(f"  URL: {checkout_url}\n")
        webbrowser.open(checkout_url)
    else:
        print("\n  ❌ Could not create checkout session. Try again or visit app.pinchfin.com/billing\n")


def cmd_usage():
    """View detailed usage history."""
    creds = _load_creds()
    result = _api_get("/billing/account?include_transactions=true&transaction_limit=30", creds["api_key"])

    if "error" in result:
        print(f"\n  ❌ {result['error']}\n")
        sys.exit(1)

    txns = result.get("recent_transactions", [])
    charges = [t for t in txns if t["type"] == "charge"]

    print(f"\n  🏛️  Usage History")
    print(f"  ─────────────────────────────────────────")

    if not charges:
        print("  No analyses run yet.\n")
        return

    total = sum(abs(t["amount"]) for t in charges)
    print(f"  Total charges shown: ${total:.2f} ({len(charges)} analyses)\n")

    for t in charges:
        print(f"  {t['created_at'][:10]}  ${abs(t['amount']):>7.2f}  {t['description']}")

    print()


def cmd_status():
    """Check connection and configuration status."""
    if not CREDENTIALS_FILE.exists():
        print("\n  ❌ Not authenticated. Run `pinchfin login` first.\n")
        sys.exit(1)

    creds = json.loads(CREDENTIALS_FILE.read_text())
    key = creds.get("api_key", "")

    print(f"\n  🏛️  pinchfin Status")
    print(f"  API: {creds.get('api_url', 'not set')}")
    print(f"  Key: {'*' * 8}...{key[-4:]}")

    # Check MCP config
    if PROJECT_MCP_CONFIG.exists():
        mcp_config = json.loads(PROJECT_MCP_CONFIG.read_text())
        if "pinchfin" in mcp_config.get("mcpServers", {}):
            print(f"  MCP: ✅ Active ({PROJECT_MCP_CONFIG.resolve()})")
        else:
            print(f"  MCP: ⚠️ File exists but pinchfin not configured")
    else:
        print(f"  MCP: ❌ Not found. Run `pinchfin setup`")

    # Check balance
    result = _api_get("/billing/account", key)
    if "error" not in result:
        acct = result.get("account", {})
        print(f"  Balance: ${acct.get('available_balance', 0):.2f} available")
    else:
        print(f"  Balance: ❌ Could not connect")

    print()


def cmd_pricing():
    """Display full pricing table."""
    print("\n  pinchfin Pricing")
    print("  ─────────────────────────────────────────────────────────────────\n")
    print("  Usage-based billing. You load funds and pay actual usage per run.")
    print("  Every tool shows a cost estimate before executing.\n")
    print("  Billable Tools                         Typical Cost")
    print("  ─────────────────────────────────────────────────────────────────")
    print("  pinchfin_deal_screen                   $0.50 – $2.00")
    print("  pinchfin_deal_book                     $2.00 – $15.00")
    print("  pinchfin_sponsor_analysis              $2.50 – $7.00")
    print("  pinchfin_market_research               $2.00 – $6.00")
    print("  pinchfin_comp_analysis                 $2.00 – $6.00")
    print("  pinchfin_rent_roll_analyzer            $1.50 – $5.00")
    print("  pinchfin_cash_flow                     $2.50 – $7.00")
    print("  pinchfin_loan_sizer                    $1.00 – $3.00")
    print("  pinchfin_term_sheet                    $2.00 – $5.00")
    print("  pinchfin_short_form_memo               $3.00 – $8.00")
    print("  pinchfin_nuance_gate                   $2.00 – $5.00")
    print("  pinchfin_ic_memo                       $4.00 – $12.00")
    print("  pinchfin_quick_review                  $8.00 – $25.00")
    print("  pinchfin_full_workflow                  $25.00 – $75.00+")
    print()
    print("  Free Tools")
    print("  ─────────────────────────────────────────────────────────────────")
    print("  pinchfin_estimate_cost                 Pre-run cost estimate")
    print("  pinchfin_account                       Check balance")
    print("  pinchfin_deposit                       Load funds")
    print("  pinchfin_deal_status                   Check deal progress")
    print("  pinchfin_list_deals                    List all deals")
    print("  pinchfin_upload_docs                   Upload documents")
    print("  pinchfin_help                          Tool list and tips")
    print()
    print("  Cost Factors")
    print("  ─────────────────────────────────────────────────────────────────")
    print("  Unit count:   <50 units → 0.8x  |  50-150 → 1.0x  |  150-300 → 1.2x")
    print("                300-500 → 1.4x    |  500+ → 1.6x")
    print("  Documents:    1-3 → 0.9x  |  4-8 → 1.0x  |  9-15 → 1.3x  |  15+ → 1.6x")
    print("  Re-runs:      35% discount (cached context)")
    print("  Doc pages:    $0.05/page additional for document-heavy modules")
    print()
    print("  Example Scenarios")
    print("  ─────────────────────────────────────────────────────────────────")
    print("  Quick screen (100-unit deal):           ~$1")
    print("  Quick review (screen + key modules):    ~$15 – $25")
    print("  Full workflow (200 units, 10 docs):     ~$40 – $75")
    print()
    print("  Minimum deposit: $25  |  New accounts: $10 free credit")
    print()


def cmd_help():
    """List all available pinchfin tools with descriptions and costs."""
    print("\n  pinchfin — CRE Underwriting Platform")
    print("  ─────────────────────────────────────────────────────────────────\n")
    print("  CLI Commands:")
    print("    pinchfin login       Authenticate and configure MCP")
    print("    pinchfin setup       (Re)install MCP server config")
    print("    pinchfin status      Check connection and balance")
    print("    pinchfin balance     Detailed balance and transactions")
    print("    pinchfin deposit     Load funds via Stripe")
    print("    pinchfin usage       View per-deal cost history")
    print("    pinchfin pricing     Full pricing table")
    print("    pinchfin help        This help message")
    print("    pinchfin logout      Remove credentials")
    print()
    print("  Claude Code Tools (available after `pinchfin login`):")
    print()
    print("    Billable (estimate shown before each run):")
    print("      pinchfin_deal_screen        Quick pass/fail screening       ~$0.50-2")
    print("      pinchfin_deal_book          Document synthesis               ~$2-15")
    print("      pinchfin_sponsor_analysis   Sponsor due diligence            ~$2.50-7")
    print("      pinchfin_market_research    Market & demographics            ~$2-6")
    print("      pinchfin_comp_analysis      Sales & rent comps               ~$2-6")
    print("      pinchfin_rent_roll_analyzer Rent roll parsing                ~$1.50-5")
    print("      pinchfin_cash_flow          Cash flow projections            ~$2.50-7")
    print("      pinchfin_loan_sizer         Credit box sizing                ~$1-3")
    print("      pinchfin_term_sheet         Term sheet drafting              ~$2-5")
    print("      pinchfin_short_form_memo    Quick analysis memo              ~$3-8")
    print("      pinchfin_nuance_gate        Hidden risk analysis             ~$2-5")
    print("      pinchfin_ic_memo            Full IC memo                     ~$4-12")
    print("      pinchfin_quick_review       Screen + key modules + memo      ~$8-25")
    print("      pinchfin_full_workflow      Complete 15-phase workflow        ~$25-75+")
    print()
    print("    Free:")
    print("      pinchfin_estimate_cost      Pre-run cost estimate")
    print("      pinchfin_account            Check balance and transactions")
    print("      pinchfin_deposit            Load funds via Stripe")
    print("      pinchfin_deal_status        Check deal workflow progress")
    print("      pinchfin_list_deals         List all deals in account")
    print("      pinchfin_upload_docs        Upload documents to a deal")
    print("      pinchfin_help               Tool list, costs, and tips")
    print()
    print("  Tips:")
    print("    1. Start with a screen — don't run 15 phases on a deal that fails basics")
    print("    2. Synthesize transcripts first — conversations contain critical intel")
    print("    3. Check estimates before confirming, especially on large deals")
    print("    4. Re-runs are 35% cheaper (cached context)")
    print()
    print("  Support: support@pinchfin.com")
    print("  Docs:    docs.pinchfin.com")
    print()


def cmd_logout():
    """Remove credentials."""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()
        print("  ✅ Credentials removed.")
    else:
        print("  No credentials found.")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)

    commands = {
        "login": cmd_login,
        "setup": cmd_setup,
        "status": cmd_status,
        "balance": cmd_balance,
        "deposit": cmd_deposit,
        "usage": cmd_usage,
        "pricing": cmd_pricing,
        "help": cmd_help,
        "logout": cmd_logout,
    }

    cmd = sys.argv[1].lower()
    if cmd in commands:
        commands[cmd]()
    else:
        print(f"  Unknown command: {cmd}")
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
