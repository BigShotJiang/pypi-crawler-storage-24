"""Entry point for `python -m pinchfin_mcp`."""
from pinchfin_mcp.server import mcp

if __name__ == "__main__":
    mcp.run()
