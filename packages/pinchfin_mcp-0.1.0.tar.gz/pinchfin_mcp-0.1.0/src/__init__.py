"""pinchfin MCP — CRE underwriting platform for Claude Code."""

__version__ = "0.1.0"
