# Wire Real Analysis into PinchFin MCP

## Context
You are continuing the PinchFin MCP build. The platform shell is complete: 23 MCP tools,
FastAPI backend, billing engine, auth, tests (48/48), CI, deploy configs. Everything returns
**mock analysis results**. Your job is to wire REAL Valeri skill-powered analysis so that
3rd-party credit analysts can run actual deals through the platform.

## Project Location
- **MCP Platform:** `C:\Users\BrianMurphy\OneDrive - Veleta Capital, LLC\Valeri\pinchfin-mcp\`
- **Valeri Skills:** `C:\Users\BrianMurphy\.claude\skills\Valeri Skills\`
- **Credit Box Config:** `C:\Users\BrianMurphy\OneDrive - Veleta Capital, LLC\Valeri\system-docs\credit_box_config.json` (v4.1)
- **Report Generator:** `C:\Users\BrianMurphy\OneDrive - Veleta Capital, LLC\Valeri\Valeri Design - Elevated\valeri_report_v3.py`
- **Valeri Data Services:** `C:\Users\BrianMurphy\valeri-data-services\` (25 MCP tools, Node.js)
- **GitHub:** `Pinchfin/pinchfin-mcp` (private), 11 commits on master

## What's Built (DO NOT REBUILD)
- `src/server.py` — 23 MCP tools (16 billable + 7 free) with FastMCP, Pydantic schemas
- `src/billing.py` — Cost estimation, WalletManager (dual-mode), UsageMeter, StripeManager
- `src/cli.py` — 9 CLI commands
- `api/routes/modules.py` — 29 endpoints, ALL returning mock data via `_run_module()`
- `api/routes/billing.py`, `accounts.py`, `deals.py` — working billing/auth/deal management
- `api/db/` — Postgres schema + dual-mode connection
- `tests/` — 48 tests (16 billing + 12 API + 21 MCP integration)
- Deploy configs: Dockerfile, docker-compose.yml, fly.toml, railway.json
- `.github/workflows/ci.yml` — GitHub Actions CI

## What Needs to Be Built

### 1. Analysis Engine (`api/analysis/engine.py`) — NEW
The core integration layer. Replaces mock responses with real Claude API + skill execution.

Architecture:
```
api/analysis/
├── engine.py          — Main orchestrator: load skill → gather data → call Claude → parse
├── skills_loader.py   — Reads SKILL.md files, constructs system prompts
├── data_services.py   — Calls valeri-data tools (REST or direct)
├── research.py        — Calls Perplexity API for sponsor/market/comp research
├── report_generator.py — Calls valeri_report_v3.py for DOCX output
└── config/
    ├── credit_box_config.json  — Copy from system-docs (6-constraint waterfall)
    └── skills/                 — Bundled SKILL.md files for each module
```

For each analysis request:
1. Load the relevant SKILL.md as system prompt context
2. Gather external data (Perplexity for research, valeri-data for government data)
3. Construct full prompt: skill instructions + external data + deal input
4. Call Claude API via Anthropic SDK (Sonnet for most, Opus for IC memo)
5. Parse structured JSON response
6. Record actual token usage in UsageMeter
7. (Optional) Generate DOCX report via valeri_report_v3.py subprocess
8. Return structured results

### 2. External Data Integration
- **Perplexity REST API** — sponsor research (8 queries), market (8 queries), comps (5 queries)
  - Endpoint: `https://api.perplexity.ai/chat/completions`
  - Need: PERPLEXITY_API_KEY env var
- **Valeri Data Services** — government data (Census, BLS, FRED, FEMA, HUD, Walk Score)
  - Option A: Run valeri-data-services as a sidecar and call its HTTP endpoints
  - Option B: Import the Node.js services directly or rewrite critical ones in Python
  - Option C: Call the MCP tools via MCP client protocol
  - Recommended: Option A for beta (simplest)
- **Anthropic API** — Claude Sonnet/Opus for analysis
  - Need: ANTHROPIC_API_KEY env var
  - SDK: `pip install anthropic`

### 3. Wire Each Module Endpoint
Replace the mock path in `_run_module()` (api/routes/modules.py) with real analysis calls.

Priority order for wiring (ship the most impactful first):

**Tier 1 — Wire First (core value):**
1. `deal_screen` — credit box validation (mostly deterministic, least LLM-dependent)
2. `debt_sizing_preview` — constraint waterfall (deterministic + light LLM)
3. `loan_sizer` — full sizing with credit_box_config.json
4. `loan_pricing` — rate build-up calculations (mostly deterministic)
5. `rent_roll_analyzer` — parse and analyze rent rolls

**Tier 2 — Wire Next (research-heavy, need Perplexity):**
6. `sponsor_analysis` — 8 Perplexity queries + Claude synthesis
7. `market_research` — valeri-data pull + 8 Perplexity queries + Claude synthesis
8. `comp_analysis` — valeri-data pull + 5 Perplexity queries + Claude synthesis

**Tier 3 — Wire After (synthesis/judgment):**
9. `cash_flow` — deterministic calcs + Claude narrative
10. `business_plan_analysis` — Claude evaluation of sponsor plan
11. `renovation_roi` — rehab scope analysis
12. `nuance_gate` — research + classification + operationalization
13. `term_sheet_comparator` — structured comparison logic
14. `ic_memo` — capstone synthesis of all prior outputs

**Tier 4 — Wire Last (orchestrated bundles):**
15. `deal_book` — document ingestion + synthesis
16. `quick_review` — orchestrate QR-0 through QR-9 phases

### 4. Deploy for Beta Testers
- Deploy backend to Fly.io or Railway (Dockerfile ready)
- Provision Postgres (Fly Postgres or Railway addon)
- Set env vars: ANTHROPIC_API_KEY, PERPLEXITY_API_KEY, STRIPE_SECRET_KEY, DATABASE_URL
- Domain: api.pinchfin.com (or temporary fly.dev URL for beta)
- Create beta tester accounts with generous free credit ($100+)
- Publish to PyPI: `hatch build && twine upload dist/*`
- Testers install: `pip install pinchfin-mcp && pinchfin login`

### 5. Tester Onboarding
- Testers are senior structured credit analysts and chief credit officers
- They will run REAL deals through the system
- They need: API key, install instructions, 2-minute getting-started guide
- They should be able to: screen deals, run individual modules, run quick reviews
- Feedback loop: what works, what doesn't, what's missing, quality assessment

## Key Architecture Decisions
- **Anthropic SDK** for Claude API calls (not subprocess/CLI)
- **Perplexity REST API** directly (not through MCP protocol)
- **Valeri Data Services** as HTTP sidecar (docker-compose adds it)
- **Skills bundled** in api/analysis/config/skills/ (copied from ~/.claude/skills/)
- **DOCX generation** via subprocess call to valeri_report_v3.py
- **credit_box_config.json** bundled in api/analysis/config/
- **UsageMeter** wired to real Anthropic API usage callbacks

## Files to Read First
1. `api/routes/modules.py` — current mock implementation (the thing you're replacing)
2. `src/billing.py` — UsageMeter class (wire to real token counts)
3. `api/analysis/engine.py` — CREATE THIS (the core new code)
4. Relevant SKILL.md files in `~/.claude/skills/Valeri Skills/[skill-name]/`
5. `credit_box_config.json` — constraint thresholds for sizing tools

## Environment Variables Needed
```
ANTHROPIC_API_KEY=sk-ant-...        # Claude API access
PERPLEXITY_API_KEY=pplx-...         # Perplexity research
STRIPE_SECRET_KEY=sk_test_...       # Stripe billing (test mode)
STRIPE_WEBHOOK_SECRET=whsec_...     # Stripe webhooks
DATABASE_URL=postgresql://...        # Postgres connection
DB_MODE=postgres                     # Enable Postgres mode
PINCHFIN_API_URL=https://api.pinchfin.com/v1
```

## Testing Strategy
- Existing 48 tests must keep passing (mock path preserved)
- Add integration tests for real analysis engine (mark with @pytest.mark.integration)
- Add a smoke test that runs deal_screen with real Claude API call
- Test with a real deal: 150-unit multifamily in Phoenix, $25M loan request

## Run Tests
```bash
# Brian's Python
/c/Users/BrianMurphy/AppData/Local/Programs/Python/Python313/python.exe -m pytest tests/ -v
```

## Git Workflow
```bash
# Push from project root
cd "/c/Users/BrianMurphy/OneDrive - Veleta Capital, LLC/Valeri/pinchfin-mcp"
PATH="/tmp/gh_extracted/bin:$PATH" git push
```
