Launch the complete pinchfin 15-phase underwriting workflow.

Ask the user for:
1. Property address and unit count
2. Loan amount and purpose
3. Sponsor name and background
4. Purchase price or asset value
5. Any in-place performance metrics (occupancy, NOI, avg rents)
6. Business plan / value-add thesis
7. Path to deal documents folder (if available)
8. Path to transcripts/emails folder (if available)
9. Any special considerations (regulatory, environmental, structural)

If the user has transcripts and emails, recommend synthesizing those first by calling pinchfin_deal_book before launching the full workflow.

Then call pinchfin_full_workflow with all provided information.

Monitor progress and present results as each phase completes.
