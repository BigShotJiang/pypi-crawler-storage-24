Run a pinchfin quick review — the 10-minute deal evaluation workflow.

Ask the user for:
1. Property address
2. Number of units
3. Loan amount requested
4. Purchase price or estimated value
5. Loan purpose (bridge, acquisition, refinance)
6. Sponsor name
7. Any additional context (business plan, known issues, broker intel)
8. Current NOI if available
9. Target stabilized rents if available

Then call the pinchfin_quick_review tool with the provided information.

This runs screen + sponsor + market + comps + cash flow + sizing + short-form memo as a single tool call. Typical cost: ~$8-$25.

After the review completes, present key findings and ask if they want to:
- Run the full 15-phase workflow for deeper analysis
- Run individual modules for specific areas of concern
- Proceed to IC memo
