# Finish Wiring Real Analysis — PinchFin MCP

## Context
The PinchFin MCP dual-path architecture is built and tested (66 pass, 0 fail). 7 of 16 billable tools are wired to real analysis. The remaining 9 still return mock/fake data. This is unacceptable — ALL 16 tools must fire real analysis using Claude + Perplexity + Valeri Data Services + bundled SKILL.md methodology.

## What's Done (DO NOT REBUILD)
- `api/analysis/__init__.py` — `is_analysis_available()`
- `api/analysis/clients.py` — Claude, Perplexity, Valeri Data clients with metering
- `api/analysis/credit_box.py` — Deterministic 6-constraint waterfall
- `api/analysis/prompts.py` — Skill loader + prompt builder
- `api/analysis/tier1.py` — 4 functions: deal_screen, debt_sizing_preview, loan_sizer, loan_pricing
- `api/analysis/tier2.py` — 3 functions: sponsor, market, comps
- `api/routes/modules.py` — `_run_module()` supports dual-path with `analysis_fn` + `analysis_request`
- 7 endpoints wired: screen, sponsor, market, comps, loan_sizer, loan_pricing, debt_sizing_preview
- `api/config.py` — ANTHROPIC_API_KEY, PERPLEXITY_API_KEY, VALERI_DATA_URL added
- `requirements.txt` — anthropic>=0.40.0 added
- `docker-compose.yml` — valeri-data sidecar added
- `tests/test_analysis.py` — 18 tests (credit box, prompts, availability)
- All 66 tests passing

## What Needs to Be Done

### 1. Bundle remaining SKILL.md files
Copy methodology from `C:\Users\BrianMurphy\.claude\skills\Valeri Skills\` into `api/analysis/config/skills/`:
- `rent-roll-analysis/SKILL.md`
- `cash-flow-modeling/SKILL.md`
- `nuance-gate-analysis/SKILL.md`
- `credit-memo/SKILL.md` (for ic_memo)
- `institutional-formatting/SKILL.md` (for term_sheet, short_form_memo)
- `cre-calculations/SKILL.md` (for cash_flow)
- `expense-underwriting/SKILL.md` (for cash_flow)
- `loan-sizing/SKILL.md` (already done)
- `returns-analysis/SKILL.md` (for quick_review)
- `risk-rating/SKILL.md` (for quick_review)
- `quick-review/SKILL.md`
- `construction-budget-review/SKILL.md` (for renovation_roi and business_plan)

### 2. Build `api/analysis/tier3.py` — Remaining 9 Analysis Functions
Each function follows the same pattern as tier1/tier2:
- Load bundled SKILL.md for the methodology
- Pull data from Valeri Data Services where applicable
- Run Perplexity research where applicable
- Call Claude with full skill methodology + deal data + external data
- Record all usage to the billing meter
- Return structured JSON matching the mock output shape

Functions needed:
```python
async def analyze_rent_roll(req, meter=None) -> dict
async def analyze_cash_flow(req, meter=None) -> dict
async def analyze_nuance_gate(req, meter=None) -> dict
async def analyze_ic_memo(req, meter=None) -> dict
async def analyze_term_sheet(req, meter=None) -> dict
async def analyze_short_form_memo(req, meter=None) -> dict
async def analyze_business_plan(req, meter=None) -> dict
async def analyze_renovation_roi(req, meter=None) -> dict
async def analyze_quick_review(req, meter=None) -> dict
```

### 3. Wire remaining 9 endpoints in `api/routes/modules.py`
Same pattern as the 7 already wired — add `analysis_fn=analyze_X, analysis_request=req` to each `_run_module()` call:
- `rent_roll_analyzer` endpoint → `analyze_rent_roll`
- `cash_flow` endpoint → `analyze_cash_flow`
- `nuance_gate` endpoint → `analyze_nuance_gate`
- `ic_memo` endpoint → `analyze_ic_memo`
- `term_sheet` endpoint → `analyze_term_sheet`
- `short_form_memo` endpoint → `analyze_short_form_memo`
- `business_plan_analysis` endpoint → `analyze_business_plan`
- `renovation_roi` endpoint → `analyze_renovation_roi`
- `quick_review` endpoint → `analyze_quick_review`

### 4. Add integration tests for new functions
Add to `tests/test_analysis.py`

### 5. Run full test suite — all 66+ existing tests must still pass

## Key Files
- Codebase: `C:\Users\BrianMurphy\OneDrive - Veleta Capital, LLC\Valeri\pinchfin-mcp\`
- Skills source: `C:\Users\BrianMurphy\.claude\skills\Valeri Skills\`
- Valeri Data Services (25 MCP tools): `C:\Users\BrianMurphy\valeri-data-services\`

## Quality Standard
Every tool must produce institutional-grade output. When a user runs rent roll analysis, it loads the full rent-roll-analysis SKILL.md methodology, fires Claude with that methodology, and produces output that matches what Veleta Capital would produce internally. We do not settle for less.

## Verification
```bash
cd "C:/Users/BrianMurphy/OneDrive - Veleta Capital, LLC/Valeri/pinchfin-mcp"
py -m pytest tests/ -v --tb=short
# Must: all pass, 0 failures
```
