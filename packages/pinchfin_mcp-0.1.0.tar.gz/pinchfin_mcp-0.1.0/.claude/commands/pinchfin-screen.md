Screen a multifamily deal using pinchfin.

Ask the user for:
1. Property address
2. Number of units
3. Loan amount requested
4. Purchase price or estimated value
5. Loan purpose (bridge, acquisition, refinance)
6. Sponsor name
7. Any additional context or notes

Then call the pinchfin_deal_screen tool with the provided information.

If the deal passes screening, ask if they want to proceed to the full workflow or run individual modules.
