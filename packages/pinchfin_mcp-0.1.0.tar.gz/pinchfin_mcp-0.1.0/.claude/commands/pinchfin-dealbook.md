Synthesize deal documents, transcripts, and email correspondence into a structured deal book using pinchfin.

Ask the user for:
1. Property name and address
2. Path to their deal documents folder
3. Path to their transcripts/emails folder
4. Sponsor name
5. Any additional deal context or narrative

Remind the user that for best results they should:
- Organize documents in a clean folder structure
- Include transcripts of all broker and sponsor calls
- Export email threads as .txt or .eml files
- Provide honest, comprehensive deal context

Then call pinchfin_deal_book to synthesize everything into a structured deal package.

After the deal book is created, ask if they want to continue to the full workflow.
