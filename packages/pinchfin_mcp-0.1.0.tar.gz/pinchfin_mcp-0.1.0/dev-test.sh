#!/bin/bash
# pinchfin API smoke test — run after dev.sh is up
API="http://127.0.0.1:8420/v1"
KEY="pf_dev_demo_key_000"
AUTH="Authorization: Bearer $KEY"

echo "=== pinchfin API Smoke Test ==="
echo ""

echo "1. Health check..."
curl -s $API/../health | python -m json.tool
echo ""

echo "2. Account balance..."
curl -s -H "$AUTH" $API/billing/account | python -m json.tool
echo ""

echo "3. Cost estimate (deal_screen, 150 units)..."
curl -s -X POST $API/billing/estimate \
  -H "$AUTH" -H "Content-Type: application/json" \
  -d '{"modules":["deal_screen"],"unit_count":150}' | python -m json.tool
echo ""

echo "4. Deal screen..."
curl -s -X POST $API/screen \
  -H "$AUTH" -H "Content-Type: application/json" \
  -d '{"property_address":"100 Test Ave, Phoenix, AZ","unit_count":150,"loan_amount":25000000,"purchase_price":35000000,"sponsor_name":"Test Sponsor LLC"}' | python -m json.tool
echo ""

echo "5. List deals..."
curl -s -H "$AUTH" "$API/deals/list" | python -m json.tool
echo ""

echo "6. Account balance (post-screen)..."
curl -s -H "$AUTH" $API/billing/account | python -m json.tool
echo ""

echo "=== Smoke test complete ==="
