# PinchFin MCP — Beta Setup Guide

**Welcome to the PinchFin beta.** PinchFin is an institutional-grade CRE underwriting platform that runs inside Claude Code. You ask questions about deals, and PinchFin runs real analysis — sponsor due diligence, market research, comparable analysis, loan sizing, cash flow underwriting, and more.

Your account comes with **$50 in free credits.** Each analysis costs $0.10–$6 depending on complexity. A typical deal screen is ~$0.15. A full Quick Review (screen + sponsor + market + comps + sizing + memo) is ~$3–6.

---

## Requirements

- **Claude Code** with a Pro or Max subscription — [claude.ai/download](https://claude.ai/download)
- **Python 3.10+** — [python.org/downloads](https://www.python.org/downloads/)

---

## Step 1: Install the PinchFin MCP package

Open your terminal and run:

```bash
pip install git+https://github.com/Pinchfin/pinchfin-mcp.git
```

This installs the PinchFin MCP client and the `pinchfin` CLI.

---

## Step 2: Add PinchFin to Claude Code

Open your Claude Code config file:

- **Mac/Linux:** `~/.claude.json`
- **Windows:** `C:\Users\YOUR_NAME\.claude.json`

Find the `"mcpServers"` section and add the `pinchfin` entry:

```json
"mcpServers": {
    "pinchfin": {
        "type": "stdio",
        "command": "python",
        "args": ["-m", "pinchfin_mcp.server"],
        "env": {
            "PINCHFIN_API_URL": "https://pinchfin-api-production.up.railway.app/v1",
            "PINCHFIN_API_KEY": "YOUR_API_KEY_HERE"
        }
    }
}
```

Replace `YOUR_API_KEY_HERE` with the API key you received.

**Windows users:** Use `"command": "py"` instead of `"command": "python"` if `python` isn't in your PATH.

---

## Step 3: Restart Claude Code

Close and reopen Claude Code. You should see PinchFin tools available (23 tools total).

---

## Step 4: Try it

Start a new Claude Code conversation and try any of these:

**Quick deal screen (~$0.15):**
> Screen this deal: 456 Oak Avenue, Austin TX 78701, 200 units, $30M loan request, sponsor is ABC Capital

**Full Quick Review (~$3–6):**
> Run a Quick Review on 123 Main St, Dallas TX 75201. 165-unit multifamily, Class B, 1985 vintage. $42M loan request for acquisition. Sponsor is XYZ Realty Group.

**Sponsor analysis (~$1–2):**
> Run sponsor analysis on Greystar Real Estate Partners

**Market research (~$1–1.50):**
> Analyze the multifamily market around 5700 Clemson Dr, Dallas TX 75214

**Loan sizing (~$0.25–1):**
> Size a loan: $60M asset value, $3.2M stabilized NOI, sponsor requesting $42M

**Check your balance (free):**
> Check my PinchFin balance

---

## What You Get

Every analysis tool returns:
- **Structured JSON results** directly in your Claude Code conversation
- **DOCX reports** (institutional-grade, branded documents) available for download
- **Real data** — live SOFR rates, Census demographics, BLS employment, FEMA flood zones
- **Deterministic math** — all financial calculations are done in Python, not AI-generated

---

## Available Tools

### Analysis Tools (billable — cost shown before each run)

| Tool | What It Does | Typical Cost |
|------|-------------|-------------|
| `pinchfin_deal_screen` | Credit box pass/fail screening | $0.10–$0.50 |
| `pinchfin_sponsor_analysis` | Sponsor due diligence report | $0.50–$2.00 |
| `pinchfin_market_research` | Market & submarket fundamentals | $0.50–$1.50 |
| `pinchfin_comp_analysis` | Comparable sales & rents | $0.50–$1.50 |
| `pinchfin_rent_roll_analyzer` | Rent roll parsing & anomalies | $0.25–$1.00 |
| `pinchfin_cash_flow` | Dual-scenario cash flow underwriting | $0.50–$1.50 |
| `pinchfin_loan_sizer` | 6-constraint waterfall loan sizing | $0.25–$1.00 |
| `pinchfin_loan_pricing` | Rate build-up, rate cap, IR sizing | $0.25–$1.00 |
| `pinchfin_debt_sizing_preview` | Quick "how much can I borrow" | $0.25–$0.75 |
| `pinchfin_nuance_gate` | Complex deal features (LIHTC, ground lease, etc.) | $0.50–$2.00 |
| `pinchfin_business_plan_analysis` | Value-add feasibility assessment | $0.50–$2.00 |
| `pinchfin_renovation_roi` | Renovation ROI & payback analysis | $0.50–$2.00 |
| `pinchfin_term_sheet_comparator` | Side-by-side term sheet comparison | $0.50–$1.50 |
| `pinchfin_ic_memo` | Investment Committee memo | $1.00–$3.00 |
| `pinchfin_deal_book` | Document synthesis into deal package | $0.75–$3.00 |
| `pinchfin_quick_review` | Full 10-minute screening workflow | $2.00–$6.00 |

### Free Tools (no charge)

| Tool | What It Does |
|------|-------------|
| `pinchfin_estimate_cost` | Pre-run cost estimate for any analysis |
| `pinchfin_account` | Check balance and transaction history |
| `pinchfin_deal_status` | Check workflow progress on a deal |
| `pinchfin_list_deals` | List all deals in your account |
| `pinchfin_upload_docs` | Upload documents to a deal |
| `pinchfin_help` | Full tool list with tips |

---

## How Billing Works

1. **Every billable tool shows a cost estimate before running.** You confirm before any charge.
2. Actual cost is based on real API usage (tokens, queries, compute time).
3. Charges appear in your transaction history (`pinchfin_account` tool or "check my balance").
4. Your $50 credit covers dozens of analyses.

---

## Troubleshooting

**"pinchfin tools not showing up"**
- Make sure you edited `~/.claude.json` (not a different config file)
- Make sure the JSON is valid (no trailing commas, proper brackets)
- Restart Claude Code completely (close and reopen)

**"Authentication failed"**
- Double-check your API key in the config
- Make sure there are no extra spaces or quotes around the key

**"Insufficient funds"**
- Check your balance: ask Claude Code "check my PinchFin balance"
- Contact us for additional credits during the beta

---

## Feedback

We want to hear everything — what worked, what broke, what's missing. Send feedback to:

**brian@pinchfin.com** (or reply to the email that invited you)

---

*PinchFin is built by Veleta Capital. All analysis is institutional-grade and uses the same methodology as our internal underwriting platform.*
