# PinchFin Quick Analysis — Command Template

## How It Works

PinchFin performs best when you give it complete deal context upfront. The more detail you provide in your initial prompt, the deeper and more accurate the analysis. Copy the template below, fill in your deal details, and paste it into Claude Code.

---

## The Command

```
Run a PinchFin Quick Review on this deal.

Property: [Full street address, city, state, zip]
Units: [Total unit count]
Year Built: [Year]
Asset Class: [A / B+ / B / B- / C]
Property Type: [Multifamily / Mixed-Use / Student / Senior]

Loan Request: $[Amount]
Loan Purpose: [Acquisition / Refinance / Recapitalization]
Purchase Price: $[Amount] (if acquisition)
Current As-Is Value: $[Amount] (if refinance or known)

Sponsor: [Entity name]
Sponsor Website: [URL if known]

Financials (if available):
- Current In-Place NOI: $[Amount]
- Current Average Rent: $[Amount]/unit
- Pro Forma / Target Rent: $[Amount]/unit
- Occupancy: [Current %]
- Renovation Budget: $[Amount] total ($[Amount]/unit)

Business Plan: [Brief description — what does the sponsor plan to do?
Example: "Light value-add — unit interiors, common areas, amenity upgrades.
Targeting $200/unit rent premium over 18-month renovation program."]

Additional Context: [Anything else relevant — market intel, broker notes,
known issues, prior relationship with sponsor, timeline pressures]

Run the full screening. Confirm costs before proceeding.
```

---

## Example (Filled In)

```
Run a PinchFin Quick Review on this deal.

Property: 5700 Clemson Dr, Dallas, TX 75214
Units: 165
Year Built: 1985
Asset Class: B-
Property Type: Multifamily

Loan Request: $42,000,000
Loan Purpose: Acquisition
Purchase Price: $57,750,000

Sponsor: Lone Star Realty Partners
Sponsor Website: lonestarrealty.com

Financials:
- Current In-Place NOI: $2,850,000
- Current Average Rent: $1,425/unit
- Pro Forma / Target Rent: $1,750/unit
- Occupancy: 91%
- Renovation Budget: $4,950,000 total ($30,000/unit)

Business Plan: Interior renovations on 120 of 165 units — new kitchens,
baths, flooring, fixtures. Exterior: parking lot resurfacing, pool area,
dog park, package lockers. Targeting $325/unit premium on renovated units
over a 24-month program. Sponsor has completed 3 similar projects in DFW.

Additional Context: Broker is IPA Dallas. Competitive process — sponsor
needs term sheet by end of month. Property is in a FEMA Zone X (no flood
risk expected). No affordable or rent-restricted units.

Run the full screening. Confirm costs before proceeding.
```

---

## What You Get Back

PinchFin runs a multi-step analysis internally:

1. **Deal Screening** — 6-constraint credit box waterfall (pass/fail)
2. **Sponsor Due Diligence** — entity verification, track record, litigation, experience score
3. **Market Research** — MSA fundamentals, employment, rent trends, supply pipeline
4. **Comparable Analysis** — rent and sales comps with adjustments
5. **Cash Flow & Sizing** — constraint-based loan sizing with sensitivity analysis
6. **Synthesis** — overall recommendation with risk assessment and DD questions

**Output:** Screening recommendation (PASS / CONDITIONAL / FAIL) with full supporting analysis and branded DOCX reports.

**Typical cost:** $3–6 for the full Quick Review.
**Typical time:** ~2 minutes.

---

## Tips

**More context = better analysis.** The fields above aren't all required, but every detail you provide makes the output sharper. At minimum, provide: address, units, loan amount, and sponsor name.

**Don't worry about formatting.** You can write it as a paragraph, bullet points, or the template above. PinchFin extracts what it needs regardless of format.

**You can go deeper after the screen.** Once you see the Quick Review results, ask follow-up questions:
- "The sponsor came back B-tier. What specifically are the concerns?"
- "Run a deeper market analysis — I want supply pipeline detail."
- "Size the loan at a 300bps spread instead of 350."
- "What if NOI is 10% lower than projected?"

**Cost estimates first.** PinchFin always shows you the cost before running. You confirm every charge.

---

## Standalone Commands

You don't always need the full Quick Review. Use individual tools when you need one specific answer:

| What You Need | What to Say |
|---|---|
| Quick pass/fail | "Screen this deal: [address], [units] units, $[amount] loan" |
| How much can they borrow | "How much can I lend on a $60M asset with $3.2M NOI?" |
| Sponsor background | "Run sponsor diligence on [Sponsor Name]" |
| Market snapshot | "What does the multifamily market look like around [address]?" |
| Rent and sale comps | "Pull comps for a 200-unit Class B in [city/submarket]" |
| Rate and pricing | "Price a $30M floating rate loan at SOFR + 350" |
| Compare term sheets | "Compare these term sheets: [paste details]" |
| Value-add feasibility | "Is a $25K/unit renovation justified at [address]?" |
| Complex deal features | "This deal has a ground lease expiring in 40 years. Analyze the impact." |
| Check your balance | "Check my PinchFin balance" |
