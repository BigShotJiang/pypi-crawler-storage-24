# PinchFin Provider Guide

**Server deployment, configuration, and operations for the PinchFin MCP platform.**

This guide is for the team deploying and maintaining the PinchFin API server and MCP infrastructure.

---

## Architecture Overview

```
End User (Claude Code / Claude Desktop)
    │
    ▼
MCP Client Layer (src/server.py)
    │  — Tool definitions, input validation, estimate/confirm flow
    │  — Runs locally on user's machine via pip install
    │
    ▼  HTTPS
API Server (api/)
    │  — FastAPI application
    │  — Authentication, billing, wallet management
    │  — Analysis orchestration engine
    │  — Skill loading (SKILL.md files)
    │  — Deterministic calculation engines
    │  — DOCX report generation
    │  — Perplexity research integration
    │  — Valeri Data Services integration
    │
    ├── Tier 1: Deterministic (deal screen, loan sizer, loan pricing, debt sizing)
    ├── Tier 2: Research-Heavy (sponsor, market, comps — Perplexity + data services)
    └── Tier 3: Synthesis (cash flow, rent roll, IC memo, nuance gate, quick review)
```

**Key principle:** All proprietary logic stays server-side. The MCP client is a thin proxy that handles tool schemas, cost estimation, and response formatting. Users never see algorithms, prompts, skills, or credit policy.

---

## 1. Prerequisites

- Python 3.10+
- Anthropic API key (for Claude analysis calls)
- Perplexity API key (for research queries)
- Stripe account (for billing)
- Valeri Data Services MCP (for government data — Census, BLS, FRED, FEMA, HUD, etc.)

---

## 2. Server Setup

### Clone and Install

```bash
git clone https://github.com/Pinchfin/pinchfin-mcp.git
cd pinchfin-mcp
pip install -e ".[dev]"
```

### Environment Variables

Create `.env` at the project root:

```bash
# Required for real analysis
ANTHROPIC_API_KEY=sk-ant-...
PERPLEXITY_API_KEY=pplx-...

# Billing
PINCHFIN_STRIPE_SECRET_KEY=sk_test_...
PINCHFIN_STRIPE_WEBHOOK_SECRET=whsec_...

# Server
PINCHFIN_HOST=0.0.0.0
PINCHFIN_PORT=8000
PINCHFIN_DEBUG=true

# Database (default: in-memory for dev)
PINCHFIN_DB_MODE=memory
# For production:
# PINCHFIN_DB_MODE=postgres
# PINCHFIN_DATABASE_URL=postgresql://user:pass@host:5432/pinchfin

# DOCX cache directory (default: .docx_cache/)
# PINCHFIN_DOCX_DIR=/var/pinchfin/docx_cache
```

### Run the Server

```bash
# Development
uvicorn api.main:app --host 0.0.0.0 --port 8000 --reload

# Production
uvicorn api.main:app --host 0.0.0.0 --port 8000 --workers 4
```

### Verify

```bash
curl http://localhost:8000/health
# → {"status": "ok"}
```

---

## 3. Docker Deployment

```bash
docker build -t pinchfin-mcp .
docker run -p 8000:8000 --env-file .env pinchfin-mcp
```

Health check is built in: `GET /health` returns 200 when ready.

---

## 4. Project Structure

```
pinchfin-mcp/
├── api/                          # FastAPI server
│   ├── main.py                   # App entry, middleware, routes
│   ├── auth.py                   # API key authentication
│   ├── state.py                  # App state, deal registry
│   ├── routes/
│   │   ├── modules.py            # All 15+ analysis endpoints
│   │   ├── billing.py            # Estimate, deposit, balance
│   │   └── documents.py          # DOCX download endpoint
│   └── analysis/
│       ├── tier1.py              # Deterministic tools (screen, sizer, pricing)
│       ├── tier2.py              # Research tools (sponsor, market, comps)
│       ├── tier3.py              # Synthesis tools (cash flow, IC memo, quick review)
│       ├── clients.py            # Claude, Perplexity, Valeri Data clients
│       ├── credit_box.py         # 6-constraint waterfall engine
│       ├── prompts.py            # Prompt builder (skill + data + schema → system/user)
│       ├── skill_loader.py       # SKILL.md file loader with caching
│       ├── schemas.py            # Pydantic output models (15 tools)
│       └── report/
│           ├── mapper.py         # JSON → DOCX builder (15 tools)
│           └── storage.py        # Temp DOCX storage with 4hr TTL
├── src/
│   ├── server.py                 # MCP client (tool definitions, estimate/confirm flow)
│   ├── cli.py                    # CLI (login, deposit, balance, etc.)
│   └── billing.py                # Cost estimation, metering, module types
├── tests/                        # 141 tests
├── .env.example
├── .mcp.json                     # MCP configuration template
├── Dockerfile
├── pyproject.toml
└── README.md
```

---

## 5. Analysis Pipeline

### Dual-Path Execution

Every endpoint supports two modes:

1. **Real mode** — When `ANTHROPIC_API_KEY` is set: loads skills, runs research, calls Claude, generates DOCX
2. **Mock mode** — When no API key: returns realistic mock data for testing and development

The system falls back to mock automatically if real analysis fails.

### Execution Flow

```
Endpoint called
    │
    ▼
_run_module()
    ├── Create deal record (if new)
    ├── Estimate cost → place hold on wallet
    ├── Create usage meter
    │
    ├── [Real path]
    │   ├── Load SKILL.md via SkillLoader
    │   ├── Pull data (Valeri Data Services, Perplexity)
    │   ├── Pre-calculate deterministic metrics (Python)
    │   ├── Build prompt (skill + data + schema)
    │   ├── Call Claude (structured JSON output)
    │   ├── Override Claude output with deterministic values
    │   ├── Validate against Pydantic schema
    │   ├── Generate DOCX report
    │   ├── Store DOCX (4hr TTL)
    │   └── Return results + document download URL
    │
    ├── [Mock path]
    │   └── Return pre-built mock data
    │
    ├── Settle hold (charge actual cost)
    └── Return response
```

### Math Rules

All financial calculations are deterministic Python. Claude never computes numbers.

- `run_constraint_waterfall()` — 6-constraint sizing (LTV, DSCR, DY, LTC)
- All NOI, DSCR, Debt Yield, LTV, LTC, payback, ROI computed in Python
- Claude receives pre-calculated metrics in `deal_data.deterministic_metrics`
- After Claude responds, Python overrides any metric values Claude returned
- Claude's role: institutional narrative, risk assessment, judgment

### Skill Loading

Skills are loaded from `~/.claude/skills/Valeri Skills/[skill-name]/SKILL.md` via `SkillLoader`:

- 20K character limit per skill file
- In-memory cache (loaded once per server lifetime)
- Constraint blocks extracted via `load_skill_constraints()` for multi-skill composition

### Quick Review Orchestration

The Quick Review internally calls three full analysis functions in parallel:

```
analyze_quick_review()
    │
    ├── get_current_sofr()          → Live SOFR rate
    ├── run_constraint_waterfall()  → Deterministic sizing
    │
    ├── [Parallel]
    │   ├── analyze_sponsor()       → 8 Perplexity queries + Claude
    │   ├── analyze_market()        → 8 Perplexity queries + data services + Claude
    │   └── analyze_comps()         → 5 Perplexity queries + data services + Claude
    │
    ├── Claude synthesis            → Combine all results into Quick Review
    │
    └── DOCX generation (4 reports)
        ├── Quick Review memo
        ├── Sponsor Analysis report
        ├── Market Research report
        └── Comparable Analysis report
```

---

## 6. DOCX Report System

### Generation

Reports are generated by `api/analysis/report/mapper.py`. Each tool has a dedicated builder function:

```python
REPORT_BUILDERS = {
    "sponsor_analysis": build_sponsor_report,
    "market_research": build_market_report,
    "comp_analysis": build_comps_report,
    "cash_flow": build_cash_flow_report,
    "quick_review": build_quick_review_report,
    # ... 10 more
}
```

### Storage

DOCX files are stored temporarily in `.docx_cache/` with a 4-hour TTL:

- `store_docx(bytes, deal_id, tool_name)` → returns download ID
- `retrieve_docx(doc_id)` → returns bytes + filename
- `cleanup_expired()` → removes expired files

### Download Endpoint

```
GET /v1/deals/{deal_id}/documents/{doc_id}
```

Returns the DOCX file as `application/vnd.openxmlformats-officedocument.wordprocessingml.document`.

---

## 7. Billing Engine

### Cost Estimation

```python
CostEstimateRequest(
    modules=[ModuleType.SPONSOR_ANALYSIS],
    unit_count=200,
    document_count=3,
    document_pages=45,
)
```

Returns low/high estimate based on module base cost * size multiplier * document multiplier.

### Wallet Flow

```
1. estimate_cost()     → Calculate cost range
2. place_hold()        → Reserve funds from balance
3. create_meter()      → Track LLM tokens, RAG queries, API calls
4. [Analysis runs]     → Meter records actual usage
5. meter.finalize()    → Compute actual cost
6. settle()            → Charge actual cost, release excess hold
```

### Size Multipliers

| Units | Multiplier |
|-------|-----------|
| < 50 | 0.8x |
| 50 – 150 | 1.0x |
| 150 – 300 | 1.2x |
| 300 – 500 | 1.4x |
| 500+ | 1.6x |

Re-run discount: 0.65x.

---

## 8. Testing

```bash
# Run all tests
py -m pytest tests/ -x -q

# Current: 141 passed, 3 skipped
# Skipped tests require python-docx (optional dependency)
```

### Test Coverage

- `test_api.py` — 72 endpoint tests (auth, billing, all modules)
- `test_schemas.py` — 15 Pydantic output model tests
- `test_report_mapper.py` — 15 DOCX builder tests + format helpers
- `test_billing.py` — Cost estimation, metering, wallet operations

---

## 9. Adding a New Tool

1. **Define the analysis function** in `tier1.py`, `tier2.py`, or `tier3.py`
2. **Add Pydantic output model** in `schemas.py` + register in `SCHEMA_REGISTRY`
3. **Add DOCX builder** in `report/mapper.py` + register in `REPORT_BUILDERS`
4. **Add request model** in `routes/modules.py`
5. **Add endpoint** in `routes/modules.py` with `tool_name` parameter
6. **Add MCP tool definition** in `src/server.py`
7. **Add module type** in `src/billing.py`
8. **Add tests** in `tests/`

---

## 10. Monitoring

### Logs

```bash
# Analysis logs
tail -f logs/pinchfin.log | grep "pinchfin.analysis"

# Billing logs
tail -f logs/pinchfin.log | grep "pinchfin.billing"
```

### Key Log Events

- `Running REAL analysis for [module] (deal=...)` — Real analysis started
- `Real analysis completed for [module]` — Success
- `Real analysis failed for [module], falling back to mock` — Failure + fallback
- `DOCX generated for [tool] (doc_id=...)` — Report created
- `Stored DOCX: [filename] (N bytes)` — Report stored
- `Cleaned up N expired DOCX files` — TTL cleanup ran

---

## 11. Security

- API keys are validated on every request via `require_funds` dependency
- No proprietary logic exposed to MCP clients
- Skills, prompts, and credit policy stay server-side
- DOCX files expire after 4 hours
- Stripe webhooks validated with webhook secret
- All inputs validated via Pydantic models with `extra="forbid"`

---

## 12. Environment-Specific Notes

### Development

```bash
PINCHFIN_DB_MODE=memory
PINCHFIN_DEBUG=true
```

No database needed. All state in memory. Mock mode works without API keys.

### Staging

```bash
PINCHFIN_DB_MODE=memory
PINCHFIN_DEBUG=false
ANTHROPIC_API_KEY=sk-ant-...
PERPLEXITY_API_KEY=pplx-...
```

Real analysis enabled. In-memory state (resets on restart).

### Production

```bash
PINCHFIN_DB_MODE=postgres
PINCHFIN_DATABASE_URL=postgresql://...
PINCHFIN_DEBUG=false
ANTHROPIC_API_KEY=sk-ant-...
PERPLEXITY_API_KEY=pplx-...
PINCHFIN_STRIPE_SECRET_KEY=sk_live_...
PINCHFIN_STRIPE_WEBHOOK_SECRET=whsec_...
```

Persistent state. Real billing. Rate limiting enabled.

---

(c) Veleta Capital LLC. All rights reserved.
