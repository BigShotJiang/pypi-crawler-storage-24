# PinchFin MCP — Beta Setup Guide

Welcome to the PinchFin beta. PinchFin is an institutional-grade CRE underwriting platform that runs inside Claude Code. You ask questions about deals in plain English, and PinchFin runs real analysis — sponsor due diligence, market research, comparable analysis, loan sizing, cash flow underwriting, and more.

Your account comes with **$50 in free credits.** Each analysis costs $0.10–$6 depending on complexity.

---

## What You Need

1. **Claude Code** (requires a Claude Pro or Max subscription) — https://claude.ai/download
2. **Python 3.10 or newer** — https://www.python.org/downloads/
3. **Your PinchFin API key** (included below)

---

## Setup (5 minutes)

### Step 1: Install the PinchFin package

Open your terminal (Mac: Terminal, Windows: PowerShell) and run:

```
pip install git+https://github.com/Pinchfin/pinchfin-mcp.git
```

If that doesn't work, try:

```
python -m pip install git+https://github.com/Pinchfin/pinchfin-mcp.git
```

### Step 2: Add PinchFin to Claude Code

You need to edit one config file. Open it in any text editor:

- **Mac/Linux:** `~/.claude.json`
- **Windows:** `C:\Users\YOUR_NAME\.claude.json`

Find the `"mcpServers"` section (it should already exist). Add `"pinchfin"` inside it. If there are already other entries, add a comma after the last one before pasting this:

```json
"pinchfin": {
    "type": "stdio",
    "command": "python",
    "args": ["-m", "pinchfin_mcp.server"],
    "env": {
        "PINCHFIN_API_URL": "https://pinchfin-api-production.up.railway.app/v1",
        "PINCHFIN_API_KEY": "PASTE_YOUR_API_KEY_HERE"
    }
}
```

**Replace** `PASTE_YOUR_API_KEY_HERE` with your API key.

**Windows users:** If `"python"` doesn't work, change it to `"py"`.

### Step 3: Restart Claude Code

Close Claude Code completely and reopen it. PinchFin tools will now be available.

---

## Try It

Open Claude Code and type any of these:

**Quick deal screen (~$0.15):**
> Screen this deal: 456 Oak Avenue, Austin TX 78701, 200 units, $30M loan request, sponsor is ABC Capital

**Sponsor analysis (~$1–2):**
> Run sponsor analysis on Greystar Real Estate Partners

**Market research (~$1–1.50):**
> Analyze the multifamily market around 5700 Clemson Dr, Dallas TX 75214

**Loan sizing (~$0.25–1):**
> Size a loan: $60M asset value, $3.2M stabilized NOI, sponsor requesting $42M

**Full Quick Review (~$3–6):**
> Run a Quick Review on 123 Main St, Dallas TX 75201. 165-unit multifamily, Class B, 1985 vintage. $42M loan request for acquisition. Sponsor is XYZ Realty Group.

**Check your balance (free):**
> Check my PinchFin balance

---

## All Available Tools

**Analysis Tools** (cost shown before each run — you always confirm):

| Tool | What It Does | Cost |
|------|-------------|------|
| Deal Screen | Credit box pass/fail screening | $0.10–$0.50 |
| Sponsor Analysis | Entity verification, portfolio, litigation, experience scoring | $0.50–$2.00 |
| Market Research | MSA demographics, employment, rent trends, supply pipeline | $0.50–$1.50 |
| Comp Analysis | Comparable sales and rents with adjustments | $0.50–$1.50 |
| Rent Roll Analyzer | Occupancy, loss-to-lease, unit mix, anomalies | $0.25–$1.00 |
| Cash Flow | Dual-scenario cash flow underwriting | $0.50–$1.50 |
| Loan Sizer | 6-constraint waterfall loan sizing | $0.25–$1.00 |
| Loan Pricing | Rate build-up, rate cap, interest reserve sizing | $0.25–$1.00 |
| Debt Sizing Preview | Quick "how much can I borrow" answer | $0.25–$0.75 |
| Nuance Gate | Complex deal features (LIHTC, ground lease, rent control) | $0.50–$2.00 |
| Business Plan Analysis | Value-add feasibility and execution risk | $0.50–$2.00 |
| Renovation ROI | Rehab scope vs. rent premium, payback analysis | $0.50–$2.00 |
| Term Sheet Comparator | Side-by-side comparison of competing offers | $0.50–$1.50 |
| IC Memo | Investment Committee memorandum | $1.00–$3.00 |
| Quick Review | Full 10-minute screening workflow | $2.00–$6.00 |

**Free Tools** (no charge): Check balance, cost estimates, list deals, deal progress.

---

## How Billing Works

- Every tool shows a cost estimate before running. You confirm before any charge.
- Actual cost is based on real usage, not the estimate.
- You start with $50 in free credits — that covers dozens of analyses.
- Check your balance anytime: ask Claude Code "check my PinchFin balance."

---

## Troubleshooting

**PinchFin tools not showing up:**
- Make sure `~/.claude.json` was saved with valid JSON
- Restart Claude Code completely (close and reopen)
- Check Python is in your PATH (run `python --version` in your terminal)

**Authentication failed:**
- Double-check your API key — no extra spaces
- Make sure you pasted the full key

**Insufficient funds:**
- Ask Claude Code "check my PinchFin balance"
- Reply to this email for additional credits

---

## Feedback

We want to hear everything — what worked, what didn't, what you wish it did.

Reply to this email directly.

---

*Built by Veleta Capital. All analysis uses institutional-grade methodology with deterministic financial calculations.*
