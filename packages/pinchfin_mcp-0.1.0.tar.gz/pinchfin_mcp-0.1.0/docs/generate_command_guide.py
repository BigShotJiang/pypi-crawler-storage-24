#!/usr/bin/env python3
"""Generate PinchFin Quick Analysis Command Guide as branded DOCX."""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from api.analysis.report.valeri_report_v3 import ValeriReport


def main():
    report = ValeriReport("Quick Analysis Command Guide", "PinchFin MCP — Beta Release")

    # ── Intro ──
    report.add_section("HOW TO GET THE BEST RESULTS")
    report.add_paragraph(
        "PinchFin performs best when you give it complete deal context upfront. "
        "The more detail you provide in your initial prompt, the deeper and more "
        "accurate the analysis. Copy the command template below, fill in your deal "
        "details, and paste it into Claude Code."
    )

    # ── The Template ──
    report.add_section("QUICK REVIEW COMMAND TEMPLATE")
    report.add_paragraph(
        "Copy this template, replace the bracketed fields with your deal details, "
        "and paste into Claude Code. Fields marked (if available) are optional but "
        "improve analysis depth."
    )
    report.add_callout_box(
        "Command Template",
        'Run a PinchFin Quick Review on this deal.\n\n'
        'Property: [Full street address, city, state, zip]\n'
        'Units: [Total unit count]\n'
        'Year Built: [Year]\n'
        'Asset Class: [A / B+ / B / B- / C]\n'
        'Property Type: [Multifamily / Mixed-Use / Student / Senior]\n\n'
        'Loan Request: $[Amount]\n'
        'Loan Purpose: [Acquisition / Refinance / Recapitalization]\n'
        'Purchase Price: $[Amount] (if acquisition)\n'
        'Current As-Is Value: $[Amount] (if refinance or known)\n\n'
        'Sponsor: [Entity name]\n'
        'Sponsor Website: [URL if known]\n\n'
        'Financials (if available):\n'
        '- Current In-Place NOI: $[Amount]\n'
        '- Current Average Rent: $[Amount]/unit\n'
        '- Pro Forma / Target Rent: $[Amount]/unit\n'
        '- Occupancy: [Current %]\n'
        '- Renovation Budget: $[Amount] total ($[Amount]/unit)\n\n'
        'Business Plan: [Brief description - what does the sponsor plan to do?]\n\n'
        'Additional Context: [Anything else relevant - market intel, broker notes,\n'
        'known issues, prior relationship with sponsor, timeline pressures]\n\n'
        'Run the full screening. Confirm costs before proceeding.',
        style="aether",
    )

    # ── Example ──
    report.add_section("EXAMPLE (FILLED IN)")
    report.add_callout_box(
        "Sample Command",
        'Run a PinchFin Quick Review on this deal.\n\n'
        'Property: 5700 Clemson Dr, Dallas, TX 75214\n'
        'Units: 165\n'
        'Year Built: 1985\n'
        'Asset Class: B-\n'
        'Property Type: Multifamily\n\n'
        'Loan Request: $42,000,000\n'
        'Loan Purpose: Acquisition\n'
        'Purchase Price: $57,750,000\n\n'
        'Sponsor: Lone Star Realty Partners\n'
        'Sponsor Website: lonestarrealty.com\n\n'
        'Financials:\n'
        '- Current In-Place NOI: $2,850,000\n'
        '- Current Average Rent: $1,425/unit\n'
        '- Pro Forma / Target Rent: $1,750/unit\n'
        '- Occupancy: 91%\n'
        '- Renovation Budget: $4,950,000 total ($30,000/unit)\n\n'
        'Business Plan: Interior renovations on 120 of 165 units - new kitchens,\n'
        'baths, flooring, fixtures. Exterior: parking lot, pool, dog park, package\n'
        'lockers. Targeting $325/unit premium on renovated units over 24 months.\n'
        'Sponsor has completed 3 similar projects in DFW.\n\n'
        'Additional Context: Broker is IPA Dallas. Competitive process - sponsor\n'
        'needs term sheet by end of month. Zone X (no flood). No affordable units.\n\n'
        'Run the full screening. Confirm costs before proceeding.',
        style="aether",
    )

    # ── What You Get ──
    report.add_section("WHAT YOU GET BACK")
    report.add_paragraph(
        "PinchFin runs a multi-step analysis internally and returns a comprehensive "
        "screening package:"
    )
    report.add_table([
        ["Step", "Analysis", "What It Covers"],
        ["1", "Deal Screening", "6-constraint credit box waterfall — pass/fail with binding constraint"],
        ["2", "Sponsor Due Diligence", "Entity verification, track record, litigation, experience score (0-12)"],
        ["3", "Market Research", "MSA fundamentals, employment, rent trends, vacancy, supply pipeline"],
        ["4", "Comparable Analysis", "5-7 rent comps, 3-5 sales comps with adjustments and conclusions"],
        ["5", "Cash Flow & Sizing", "Constraint-based loan sizing with rate stress and NOI sensitivity"],
        ["6", "Synthesis", "Overall recommendation with risk assessment and DD questions"],
    ])
    report.add_kv_pairs([
        ("Output", "PASS / CONDITIONAL / FAIL recommendation with full supporting analysis"),
        ("Reports", "Branded DOCX reports available for download"),
        ("Typical Cost", "$3–6 for the full Quick Review"),
        ("Typical Time", "~2 minutes"),
    ])

    # ── Follow-ups ──
    report.add_section("GOING DEEPER — FOLLOW-UP PROMPTS")
    report.add_paragraph(
        "After the Quick Review, stay in the same conversation and ask follow-up "
        "questions. Claude maintains context from the screening."
    )
    report.add_table([
        ["Scenario", "What to Say"],
        ["Sponsor came back B-tier", '"What specifically are the concerns with this sponsor?"'],
        ["Need more market detail", '"Run a deeper market analysis — I want supply pipeline detail"'],
        ["Test different spread", '"Size the loan at SOFR + 300 instead of 350"'],
        ["Stress test NOI", '"What if NOI is 10% lower than projected?"'],
        ["Compare to another deal", '"How does this compare to the Austin deal I screened earlier?"'],
        ["Need comp detail", '"Show me more detail on the rent comps — adjusted rents by unit type"'],
        ["Nuance question", '"This deal has a PILOT tax abatement expiring in 2029. Analyze the impact."'],
    ])

    # ── Standalone Commands ──
    report.add_section("STANDALONE COMMANDS")
    report.add_paragraph(
        "You don't always need the full Quick Review. Use individual tools when "
        "you need one specific answer."
    )
    report.add_table([
        ["What You Need", "What to Say"],
        ["Quick pass/fail", '"Screen this deal: [address], [units] units, $[amount] loan"'],
        ["How much can they borrow", '"How much can I lend on a $60M asset with $3.2M NOI?"'],
        ["Sponsor background", '"Run sponsor diligence on [Sponsor Name]"'],
        ["Market snapshot", '"What does the multifamily market look like around [address]?"'],
        ["Rent and sale comps", '"Pull comps for a 200-unit Class B in [city/submarket]"'],
        ["Rate and pricing", '"Price a $30M floating rate loan at SOFR + 350"'],
        ["Compare term sheets", '"Compare these term sheets: [paste details]"'],
        ["Value-add feasibility", '"Is a $25K/unit renovation justified at [address]?"'],
        ["Complex deal features", '"This deal has a ground lease expiring in 40 years. Analyze the impact."'],
        ["Check your balance", '"Check my PinchFin balance"'],
    ])

    # ── Tips ──
    report.add_section("TIPS")
    report.add_paragraph(
        "More context = better analysis. The template fields aren't all required, but every "
        "detail you provide makes the output sharper. At minimum, provide: address, units, "
        "loan amount, and sponsor name."
    )
    report.add_paragraph(
        "Don't worry about formatting. You can write it as a paragraph, bullet points, or "
        "the template above. PinchFin extracts what it needs regardless of format."
    )
    report.add_paragraph(
        "Cost estimates first. PinchFin always shows you the cost before running. You "
        "confirm every charge. No surprises."
    )
    report.add_paragraph(
        "Chain analyses in conversation. Run a screen first, then drill into sponsor or "
        "market as needed. Claude maintains context across the conversation."
    )
    report.add_paragraph(
        "Re-runs are 35% cheaper. If you need to re-analyze a deal with updated assumptions, "
        "mention it's a re-run for the discount."
    )

    out = os.path.join(os.path.dirname(__file__), "PinchFin_Quick_Analysis_Command_Guide.docx")
    report.save(out)
    print(f"[OK] Command Guide saved: {out}")


if __name__ == "__main__":
    main()
