# PinchFin User Guide

**CRE credit intelligence in your terminal.**

This guide covers installation, setup, and daily use of PinchFin inside Claude Code or Claude Desktop.

---

## 1. Install

```bash
pip install pinchfin-mcp
```

Requires Python 3.10+.

---

## 2. Authenticate

```bash
pinchfin login
```

This creates your account, assigns an API key, and auto-configures the MCP connection. New accounts receive **$10.00 in free credits**.

To verify everything is working:

```bash
pinchfin status
```

You should see your API key, balance, and a green connection status.

---

## 3. Open Claude Code

```bash
claude
```

PinchFin tools are automatically available. No additional configuration needed. Type `pinchfin_help` inside Claude Code to see all available tools.

---

## 4. Your First Analysis

### Screen a Deal (~$0.25)

Just describe the deal in plain English:

```
Screen this deal: 180-unit Class B garden-style in Phoenix.
$28M loan request, $42M appraised value. Bridge refi.
Sponsor: Mesa Capital Partners, 3,500 units in AZ.
```

PinchFin will:
1. Show you a cost estimate
2. Wait for your confirmation
3. Run the analysis
4. Return results with cost and remaining balance

### Quick Review (~$3-6)

The Quick Review is the flagship tool. One command triggers a full 10-phase analysis:

```
Run a quick review on this deal:
- 240 units at 4500 W Camelback Rd, Phoenix, AZ 85031
- $35M loan, $52M value, bridge acquisition
- Sponsor: Sonoran Multifamily Group
- Current NOI: $2.8M
```

**What you get:**
- Full sponsor due diligence (8 research queries)
- Market and submarket analysis (8 research queries + government data)
- Comparable rent and sales analysis (5 research queries)
- Credit box screening with 6-constraint sizing waterfall
- Professional screening memo (DOCX)
- Standalone Sponsor Analysis report (DOCX)
- Standalone Market Research report (DOCX)
- Standalone Comparable Analysis report (DOCX)

All four DOCX reports are generated automatically. Download links are included in the response.

---

## 5. Available Tools

### Billable Tools

| Tool | Cost | Use When |
|------|------|----------|
| **Quick Review** | $2 – $6 | First look at any deal. Start here. |
| **Deal Screen** | $0.10 – $0.50 | Fast pass/fail before committing to deeper work |
| **Sponsor Analysis** | $0.50 – $2 | Deep due diligence on a borrower or GP |
| **Market Research** | $0.50 – $1.50 | MSA and submarket fundamentals |
| **Comp Analysis** | $0.50 – $1.50 | Rent and sales comparables with adjustments |
| **Rent Roll Analyzer** | $0.25 – $1 | Parse and analyze a rent roll for anomalies |
| **Cash Flow** | $0.50 – $1.50 | Dual-scenario underwriting (lender vs sponsor) |
| **Loan Sizer** | $0.25 – $1 | Size a loan against 6 credit constraints |
| **Loan Pricing** | $0.25 – $1 | Rate build-up, rate cap, debt service, all-in cost |
| **Debt Sizing Preview** | $0.25 – $0.75 | Quick "how much can I borrow?" |
| **Term Sheet Comparator** | $0.50 – $1.50 | Side-by-side comparison of 2+ term sheets |
| **Business Plan Analysis** | $0.50 – $2 | Feasibility, rent growth, execution risk |
| **Renovation ROI** | $0.50 – $2 | Rehab scope, rent premium, payback period |
| **Nuance Gate** | $0.50 – $2 | Deep-dive into complex deal features |
| **IC Memo** | $1 – $3 | Investment Committee memo |
| **Deal Book** | $0.75 – $3 | Document synthesis into structured narrative |

### Free Tools

| Tool | Use |
|------|-----|
| `pinchfin_estimate_cost` | See cost before running anything |
| `pinchfin_account` | Check balance and transactions |
| `pinchfin_deposit` | Load funds via Stripe |
| `pinchfin_deal_status` | Check progress on a deal |
| `pinchfin_list_deals` | List all deals in your account |
| `pinchfin_upload_docs` | Upload documents to a deal |
| `pinchfin_help` | List all tools with costs |

---

## 6. How Billing Works

Every billable tool follows the same flow:

```
1. You describe what you want
2. PinchFin shows estimated cost and your balance
3. You confirm ("yes", "go ahead", "proceed")
4. Analysis runs
5. Results returned with actual cost and updated balance
```

You are never charged without confirmation. Re-runs on the same deal cost ~35% less.

### Loading Funds

```bash
pinchfin deposit
```

Minimum deposit: $25. Payments processed via Stripe.

### Checking Balance

```bash
pinchfin balance
```

Or inside Claude Code: ask "What's my PinchFin balance?"

---

## 7. Understanding Output

### Structured Results

Every tool returns structured JSON with institutional-grade analysis. Key sections vary by tool but typically include:

- **Credit metrics** — LTV, DSCR, Debt Yield, LTC with pass/fail status
- **Sizing waterfall** — Maximum loan from each of 6 constraints, binding constraint identified
- **Narrative** — Institutional prose suitable for IC presentation
- **Strengths / Risks** — Evidence-based with severity and mitigants
- **Recommendation** — Clear go/no-go with rationale

### DOCX Reports

Tools that produce DOCX reports include a download link in the response. Reports use PinchFin institutional formatting — suitable for external distribution to investment committees, capital partners, or internal credit files.

### Deterministic Math

All financial calculations (DSCR, LTV, Debt Yield, LTC, NOI, loan sizing) are computed deterministically. The AI writes narrative and provides judgment — it never computes numbers.

The 6-constraint credit box waterfall:

| Constraint | Threshold | Type |
|---|---|---|
| LTV As-Is | ≤ 75% | Hard ceiling |
| LTV Stabilized | ≤ 75% | Hard ceiling |
| DSCR Stabilized | ≥ 1.05x | Hard floor |
| Debt Yield | ≥ 7.0% | Hard floor |
| LTC | ≤ 80% | Hard ceiling |
| Max Loan | $100M | Program cap |

The most restrictive constraint governs. Every sizing shows all six constraints.

---

## 8. Recommended Workflows

### Lender Pipeline Triage

```
1. Deal Screen ($0.25)        → Pass/fail in seconds
2. Quick Review ($3-6)        → Full screening with 4 DOCX reports
3. Individual modules         → Go deeper where needed
4. IC Memo ($1-3)             → Formal recommendation
```

### Broker Deal Packaging

```
1. Debt Sizing Preview ($0.25)       → Quick constraint sizing
2. Term Sheet Comparator ($0.50)     → Compare lender offers
3. Market Research ($0.50)           → Support the narrative
```

### Sponsor Self-Assessment

```
1. Business Plan Analysis ($0.50)    → Is my plan realistic?
2. Renovation ROI ($0.50)            → Does the rehab pencil?
3. Loan Sizer ($0.25)               → How much can I borrow?
4. Comp Analysis ($0.50)             → What are market rents?
```

---

## 9. Nuance Gate

The Nuance Gate handles complex deal features that require specialized analysis:

- **Affordable housing** — LIHTC, Section 8, HAP contracts, MFTE, 421-a, LURA
- **Rent control / stabilization** — Local ordinances, allowable increases, vacancy decontrol
- **Ground leases** — Remaining term, rent resets, lender consent provisions
- **Tax abatements** — PILOT, abatement schedules, expiration risk
- **Seismic** — Retrofit requirements, insurance, soft-story mandates
- **Environmental** — Phase I/II findings, remediation, brownfield status
- **Complex structures** — TIC, land trust, JV waterfall, 1031 exchange

When a deal has one or more of these features, run the Nuance Gate to get a full regulatory research report with risk classification and financial impact assessment.

---

## 10. Tips

1. **Be specific.** Include address, unit count, loan amount, asset value, sponsor name.
2. **Start with a screen.** A $0.25 screen saves you from spending $6 on a deal that fails.
3. **Provide context.** Brief PinchFin like you'd brief a senior credit analyst.
4. **Use Quick Review for pipeline.** One tool call, four DOCX reports, full analysis.
5. **Check your balance.** Run `pinchfin balance` anytime.

---

## 11. CLI Reference

| Command | What It Does |
|---------|-------------|
| `pinchfin login` | Authenticate and configure MCP |
| `pinchfin setup` | Reinstall MCP configuration |
| `pinchfin status` | Check connection and balance |
| `pinchfin balance` | Detailed balance + transaction history |
| `pinchfin deposit` | Load funds via Stripe |
| `pinchfin usage` | Per-deal cost history |
| `pinchfin pricing` | Full pricing table |
| `pinchfin help` | All tools with costs |
| `pinchfin logout` | Remove credentials |

---

## Support

- **Email:** support@pinchfin.com
- **Documentation:** docs.pinchfin.com

---

(c) Veleta Capital LLC. All rights reserved.
