# pinchfin MCP — Architecture & Build Plan

## Internal Reference (Not for Distribution)

---

## What Ships to Users

```bash
pip install pinchfin-mcp
```

| Component | Purpose |
|-----------|---------|
| `pinchfin_mcp/server.py` | MCP tool definitions — schemas, estimate→confirm→execute flow, API stubs |
| `pinchfin_mcp/billing.py` | Cost estimation engine, wallet manager, usage metering, Stripe integration |
| `pinchfin_mcp/cli.py` | `pinchfin login/setup/balance/deposit/usage/status/logout` CLI |
| `.claude/commands/` | Slash commands for Claude Code convenience |
| `examples/` | Submission prompt templates |
| `README.md` | User documentation with pricing |

**What is NOT in the package:**
- Orchestration logic, prompt templates, credit_box_config.json
- RAG corpus, scoring algorithms, workflow state machine
- Module implementations, Nuance Gate logic
- Any proprietary analysis code

The package is a thin client. It defines input schemas, handles billing flow,
and makes authenticated HTTP calls to your API.

---

## Server-Side: What You Build

### 1. FastAPI Application

Every MCP tool maps to an API endpoint:

```
# Billing (build first)
POST /v1/billing/estimate           → Cost estimation
GET  /v1/billing/account            → Balance, transactions
POST /v1/billing/deposit            → Stripe checkout session
POST /v1/billing/webhooks/stripe    → Stripe webhook handler

# Analysis (wrap existing modules)
POST /v1/screen                     → Deal screening
POST /v1/deal-book                  → Deal book creation
POST /v1/workflow/full              → Full 15-phase workflow
POST /v1/modules/sponsor-analysis   → Sponsor module
POST /v1/modules/market-research    → Market module
POST /v1/modules/comp-analysis      → Comp module
POST /v1/modules/rent-roll-analyzer → Rent roll analyzer
POST /v1/modules/cash-flow          → Cash flow module
POST /v1/modules/loan-sizer         → Loan sizer
POST /v1/modules/term-sheet         → Term sheet generator
POST /v1/modules/short-form-memo    → Short-form memo
POST /v1/modules/nuance-gate        → Nuance Gate (NGM)
POST /v1/modules/ic-memo            → IC memo generation
POST /v1/modules/quick-review       → Quick review (composite)

# Utilities (free)
POST /v1/documents/upload           → Document processing
GET  /v1/deals/status               → Deal status
GET  /v1/deals/list                 → List deals

# Free (local, no API call)
pinchfin_help                       → Tool list, costs, tips (no API call)
```

### 2. Billing Infrastructure (Critical Path)

This is the infrastructure that makes this a business. Build BEFORE launching.

#### 2a. Database Schema (Postgres)

```sql
-- Accounts
CREATE TABLE accounts (
    id              TEXT PRIMARY KEY,          -- acct_xxxxxxxxxxxx
    email           TEXT NOT NULL UNIQUE,
    api_key_hash    TEXT NOT NULL UNIQUE,
    balance         DECIMAL(10,2) DEFAULT 0,
    held_amount     DECIMAL(10,2) DEFAULT 0,
    total_deposited DECIMAL(10,2) DEFAULT 0,
    total_spent     DECIMAL(10,2) DEFAULT 0,
    total_analyses  INTEGER DEFAULT 0,
    stripe_customer TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Transaction Ledger (append-only)
CREATE TABLE transactions (
    id              TEXT PRIMARY KEY,          -- txn_xxxxxxxxxxxx
    account_id      TEXT REFERENCES accounts(id),
    type            TEXT NOT NULL,             -- deposit, charge, hold, release, free_credit, refund
    amount          DECIMAL(10,4) NOT NULL,    -- positive=credit, negative=debit
    balance_after   DECIMAL(10,2) NOT NULL,
    description     TEXT,
    deal_id         TEXT,
    module          TEXT,
    estimate_id     TEXT,
    stripe_payment  TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_txn_account ON transactions(account_id, created_at DESC);

-- Active Holds
CREATE TABLE holds (
    id              TEXT PRIMARY KEY,          -- hold_xxxxxxxxxxxx
    account_id      TEXT REFERENCES accounts(id),
    estimate_id     TEXT,
    deal_id         TEXT,
    hold_amount     DECIMAL(10,2) NOT NULL,
    placed_at       TIMESTAMPTZ DEFAULT NOW(),
    settled_at      TIMESTAMPTZ,
    status          TEXT DEFAULT 'active'      -- active, settled, released
);

-- Usage Meters (one per analysis run)
CREATE TABLE usage_meters (
    id                  TEXT PRIMARY KEY,      -- mtr_xxxxxxxxxxxx
    deal_id             TEXT,
    account_id          TEXT REFERENCES accounts(id),
    modules             TEXT[],
    llm_input_tokens    INTEGER DEFAULT 0,
    llm_output_tokens   INTEGER DEFAULT 0,
    document_pages      INTEGER DEFAULT 0,
    rag_queries         INTEGER DEFAULT 0,
    external_api_calls  INTEGER DEFAULT 0,
    compute_seconds     REAL DEFAULT 0,
    llm_cost            DECIMAL(10,4) DEFAULT 0,
    document_cost       DECIMAL(10,4) DEFAULT 0,
    rag_cost            DECIMAL(10,4) DEFAULT 0,
    external_api_cost   DECIMAL(10,4) DEFAULT 0,
    total_cost          DECIMAL(10,2) DEFAULT 0,
    started_at          TIMESTAMPTZ DEFAULT NOW(),
    completed_at        TIMESTAMPTZ
);
```

#### 2b. Billing Flow (Every Billable Request)

```
1. Request arrives with API key
2. Authenticate → get account
3. Estimate cost based on: modules, unit_count, doc_count, is_rerun
4. If not confirmed:
   → Return estimate + balance + "confirm to proceed"
5. If confirmed:
   a. Check available_balance >= hold_amount
   b. If insufficient → HTTP 402 with deposit URL
   c. Place hold (balance -= hold_amount, held += hold_amount)
   d. Create usage meter
   e. Execute analysis (meter records actual consumption)
   f. Finalize meter → actual_cost
   g. Settle: release hold, charge actual_cost
   h. Return results + cost report
```

#### 2c. Cost Estimation Model

Starting estimates (refine with actual data):

```python
MODULE_BASE_COSTS = {
    "deal_screen":        (0.50, 2.00),
    "deal_book":          (2.00, 8.00),
    "sponsor_analysis":   (2.50, 7.00),
    "market_research":    (2.00, 6.00),
    "comp_analysis":      (2.00, 6.00),
    "rent_roll_analyzer": (1.50, 5.00),
    "cash_flow":          (2.50, 7.00),
    "loan_sizer":         (1.00, 3.00),
    "term_sheet":         (2.00, 5.00),
    "short_form_memo":    (3.00, 8.00),
    "nuance_gate":        (2.00, 5.00),
    "ic_memo":            (4.00, 12.00),
    "quick_review":       (8.00, 25.00),
    "full_workflow":      (25.00, 75.00),
    "document_synthesis": (2.00, 10.00),
}

# Multipliers
Unit count:  <50 → 0.8x | 50-150 → 1.0x | 150-300 → 1.2x | 300-500 → 1.4x | 500+ → 1.6x
Doc count:   1-3 → 0.9x | 4-8 → 1.0x | 9-15 → 1.3x | 15+ → 1.6x
Re-run:      0.65x (cached context reduces LLM calls)
Doc pages:   $0.05/page additional for doc-heavy modules
```

**Important:** These are starting estimates. After 50-100 real analyses, you'll have
actual cost data to refine the model. The metering system captures real resource
consumption so you can calibrate.

#### 2d. Stripe Integration

Minimal Stripe setup needed:

1. **Stripe account** (you probably have one for Veleta)
2. **Checkout Sessions** for deposits (one-time payments, not subscriptions)
3. **Webhook endpoint** to credit account when payment succeeds
4. **Customer objects** linked to pinchfin accounts

No subscription products needed. No recurring billing. Pure prepaid wallet model.

### 3. MCP Endpoint

For claude.ai connector support + Claude Code remote:

```
https://mcp.pinchfin.com/sse
```

Same server.py running in `streamable_http` mode behind nginx/caddy with TLS.

### 4. Document Upload Pipeline

Files need to get from user's local machine to your server:

**Option A (MVP — simplest):**
- User provides local file path
- Claude Code reads files locally
- Content sent in API request body (base64 or multipart)
- Works for files under ~10MB

**Option B (Production):**
- MCP server requests a pre-signed S3 upload URL from API
- Claude Code uploads file directly to S3
- API processes from S3
- Handles any file size

Start with Option A. Move to B when file sizes become an issue.

### 5. Web Dashboard (app.pinchfin.com)

Minimal web UI for account management:

```
/signup              → Create account, get API key
/settings/api-keys   → View/rotate API keys
/billing             → Balance, load funds, transaction history
/billing/success     → Stripe redirect after successful payment
/deals               → List deals, view status
```

This can be very simple — even a single-page app. The primary interface is Claude Code.
The dashboard exists for account management and billing.

---

## User Experience Flow

### First Time (3 minutes)

```bash
$ pip install pinchfin-mcp
$ pinchfin login
  🏛️  pinchfin — CRE Underwriting Platform
  Enter your API key: ****************************
  ✅ Authenticated successfully.
  Account balance: $10.00
  💡 New account — you have $10.00 in free credits.
  ✅ MCP config written to .mcp.json
```

### Running Analysis

```
$ claude

> Screen this deal at 4521 W Sunset Blvd, LA, 186 units, $42M loan,
  $58M purchase. Sponsor: Pacific Coast Capital Group.

Claude: Let me estimate the cost first.

  Estimated cost: $0.80 - $1.60
  Your balance: $10.00
  Proceed?

> Yes

Claude: [runs screening]

  ✅ PASS — Deal meets credit box criteria.
  [detailed results...]
  Cost: $1.20 | Balance: $8.80

> Now run sponsor analysis on Pacific Coast Capital Group.

Claude: Estimated cost: $3.50 - $5.80. Balance: $8.80. Proceed?

> Yes

Claude: [runs analysis]
  [sponsor results...]
  Cost: $4.20 | Balance: $4.60

> I want to run the full workflow but I need more funds.

Claude: Your balance is $4.60. The full workflow is estimated at $28-$52
  for this deal. Let me help you load funds.

  [calls pinchfin_deposit → returns Stripe checkout URL]
```

### Checking Costs

```bash
$ pinchfin balance

  🏛️  pinchfin Account
  ─────────────────────────────────────────
  Balance:           $     46.00
  Available:         $     46.00
  Total deposited:   $     50.00
  Total spent:       $     14.00
  Analyses run:             3

  Recent Transactions
  ─────────────────────────────────────────
  2025-03-15  -$  4.20  Analysis: sponsor_analysis — $4.20
  2025-03-15  -$  1.20  Analysis: deal_screen — $1.20
  2025-03-14  +$ 50.00  Deposit: $50.00
  2025-03-14  +$ 10.00  Welcome credit: $10.00
```

---

## Build Priority

### Sprint 1: Billing Foundation (Week 1-2)

Build billing BEFORE analysis endpoints. You need this to not lose money.

1. Postgres schema for accounts, transactions, holds, meters
2. Stripe integration (checkout sessions + webhook)
3. FastAPI billing endpoints (estimate, account, deposit)
4. API key authentication middleware
5. Cost estimation engine (start with base costs + multipliers)

### Sprint 2: Core Analysis Endpoints (Week 2-4)

Wrap existing modules as API endpoints. Start with the launch modules:

6. Deal screening endpoint (wrap existing Phase 1)
7. Sponsor analysis endpoint
8. Market research endpoint
9. Comp analysis endpoint
10. Rent roll analyzer endpoint
11. Cash flow endpoint
12. Loan sizer endpoint
13. Short-form memo endpoint

### Sprint 3: Ship It (Week 4-5)

14. MCP server deployed (streamable_http mode)
15. Package published to PyPI
16. Minimal web dashboard (signup, API keys, billing)
17. Documentation site

### Sprint 4: Full Workflow & Polish (Week 5-8)

18. Full 15-phase workflow endpoint
19. IC memo endpoint
20. Term sheet endpoint
21. Nuance Gate endpoint
22. Document upload pipeline
23. Usage metering refinement (calibrate estimates with real data)

### Sprint 5: Growth (Month 3+)

24. Deal persistence and resume
25. SFR/BTR pool module
26. Claude.ai connector listing
27. Team/org accounts
28. Usage analytics dashboard

---

## Key Metrics to Track

From day one, capture:

- **Signups** → API keys created
- **Free credit usage** → how many use all $10, how fast
- **First deposit** → conversion rate and time-to-deposit
- **Cost per analysis** → actual vs. estimated (calibration data)
- **Module popularity** → which tools get used most
- **Re-run rate** → how often people re-run (quality signal)
- **Balance exhaustion** → how many hit $0 and don't reload (churn signal)

---

## File Inventory

```
pinchfin-mcp/
├── pyproject.toml                  # Package config
├── README.md                       # User docs with pricing
├── src/
│   ├── __init__.py
│   ├── server.py                   # MCP server — estimate→confirm→execute flow
│   ├── billing.py                  # Cost estimation, wallet, metering, Stripe
│   └── cli.py                      # login/setup/balance/deposit/usage/status/logout
├── examples/
│   └── submission_prompts.py       # Prompt templates
├── .claude/
│   └── commands/
│       ├── pinchfin-screen.md
│       ├── pinchfin-workflow.md
│       ├── pinchfin-dealbook.md
│       └── pinchfin-quick-review.md
└── docs/
    └── architecture.md             # This file (internal only)
```
