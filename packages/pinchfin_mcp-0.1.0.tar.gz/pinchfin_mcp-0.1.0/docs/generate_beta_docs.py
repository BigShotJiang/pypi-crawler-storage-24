#!/usr/bin/env python3
"""
Generate PinchFin MCP beta documents:
1. MCP Tool Roster — all 23 tools with descriptions
2. User Manual — how to use PinchFin in Claude Code CLI
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from api.analysis.report.valeri_report_v3 import ValeriReport


def generate_tool_roster():
    """MCP Tool Roster — branded PinchFin v9 document."""
    report = ValeriReport("MCP Tool Roster", "PinchFin v0.1.0 — Beta Release")

    # ── Overview ──
    report.add_section("PLATFORM OVERVIEW")
    report.add_paragraph(
        "PinchFin MCP exposes 24 tools through the Model Context Protocol, "
        "enabling institutional-grade CRE underwriting directly inside Claude Code. "
        "17 tools are billable analysis modules; 7 are free account and utility tools. "
        "All analysis uses deterministic financial calculations with Claude providing "
        "institutional narrative synthesis."
    )
    report.add_deal_tape_strip({
        "Total Tools": "24",
        "Billable": "17",
        "Free": "7",
        "Analysis Engine": "Claude + Perplexity + Valeri Data",
        "Output Formats": "JSON + DOCX",
    })

    # ── Tier 1: Deterministic Tools ──
    report.add_section("TIER 1 — DETERMINISTIC TOOLS")
    report.add_paragraph(
        "Fast, low-cost tools powered primarily by deterministic Python calculations "
        "(constraint waterfall, rate math, sensitivity analysis) with Claude providing "
        "narrative synthesis. SOFR and macro data pulled live from Federal Reserve via "
        "Valeri Data Services."
    )
    report.add_table([
        ["Tool", "Description", "Cost"],
        [
            "pinchfin_deal_screen",
            "Credit box pass/fail screening. Runs the 6-constraint waterfall "
            "(LTV As-Is, LTV Stabilized, DSCR, Debt Yield, LTC, Max Loan) against "
            "Veleta credit parameters. Identifies binding constraint. Pulls live SOFR "
            "and property context data. Returns pass/fail with narrative.",
            "$0.10–$0.50"
        ],
        [
            "pinchfin_debt_sizing_preview",
            "Quick 'how much can I borrow?' answer. Lightweight version of the full "
            "loan sizer — shows max loan by each constraint without full narrative. "
            "Ideal for initial sponsor conversations.",
            "$0.25–$0.75"
        ],
        [
            "pinchfin_loan_sizer",
            "Full 6-constraint waterfall loan sizing with sensitivity analysis. "
            "Shows max loan from each constraint, binding constraint detail, rate "
            "stress (+100bps), NOI stress (-10%), and comparison to broker request. "
            "Includes refinance exit test.",
            "$0.25–$1.00"
        ],
        [
            "pinchfin_loan_pricing",
            "Rate build-up analysis: index (SOFR) + spread = all-in rate. Rate cap "
            "strike and estimated cost. Interest reserve sizing (month-by-month "
            "shortfall method). Annual and monthly debt service. DSCR at pricing.",
            "$0.25–$1.00"
        ],
        [
            "pinchfin_pref_equity_qr",
            "Preferred equity sizing and quick review. Two-pass constraint system: "
            "Pass 1 validates senior debt independently, Pass 2 sizes pref equity "
            "against 9 constraints (combined LTV ≤80%, combined LTC ≤85%, pref IRR "
            "≥14%, MOIC ≥1.40x, sponsor equity ≥10%, pref:common ≤2.0x, $25M cap). "
            "Quarterly-compounding PIK accrual model with 50% flag. 5-scenario exit "
            "waterfall. Sponsor with/without comparison. Full 22-section DOCX output.",
            "$3.00–$8.00"
        ],
    ])

    # ── Tier 2: Research Tools ──
    report.add_section("TIER 2 — RESEARCH TOOLS")
    report.add_paragraph(
        "Deep research modules that combine Perplexity web intelligence, Valeri Data "
        "Services (Census, BLS, FRED, FEMA, HUD, Walk Score), and Claude synthesis. "
        "Each tool runs 5–8 parallel research queries and produces institutional-grade "
        "narrative with structured data."
    )
    report.add_table([
        ["Tool", "Description", "Cost"],
        [
            "pinchfin_sponsor_analysis",
            "Institutional sponsor due diligence. Entity verification, portfolio "
            "overview, track record analysis (deals, units, markets), financial "
            "capacity assessment, litigation and bankruptcy screening, operational "
            "capability evaluation. Returns sponsor tier (A/B/C/D), experience score "
            "(0–12), GO/NO-GO recommendation. 8 parallel research queries.",
            "$0.50–$2.00"
        ],
        [
            "pinchfin_market_research",
            "MSA and submarket fundamentals. Population growth, median household "
            "income, employment drivers, unemployment rate, multifamily vacancy and "
            "rent trends, absorption, supply pipeline (units under construction as "
            "% of inventory), regulatory environment. Returns market rating "
            "(strong/moderate/weak) with supportable assumptions. 8 parallel queries.",
            "$0.50–$1.50"
        ],
        [
            "pinchfin_comp_analysis",
            "Comparable sales and rent analysis. Identifies 5–7 rent comps and 3–5 "
            "sales comps within the submarket. Applies adjustments for vintage, "
            "condition, amenities, and location. Derives market rent conclusion, "
            "loss-to-lease estimate, implied value range, and cap rate bracket. "
            "5 parallel research queries.",
            "$0.50–$1.50"
        ],
    ])

    # ── Tier 3: Synthesis Tools ──
    report.add_section("TIER 3 — SYNTHESIS & JUDGMENT TOOLS")
    report.add_paragraph(
        "Complex analysis tools that combine multiple data sources, apply institutional "
        "methodology via loaded skill files, and produce deep analytical output. These "
        "tools use full SKILL.md methodology (150–600 lines each) with multi-skill "
        "composition and structured JSON output validation."
    )
    report.add_table([
        ["Tool", "Description", "Cost"],
        [
            "pinchfin_rent_roll_analyzer",
            "Rent roll parsing and anomaly detection. Unit mix aggregation, physical "
            "and economic occupancy, loss-to-lease by unit type, concession analysis, "
            "renovation segmentation (classic vs. renovated), lease expiration "
            "waterfall, and T-12 reconciliation flags.",
            "$0.25–$1.00"
        ],
        [
            "pinchfin_cash_flow",
            "Dual-scenario cash flow underwriting. Builds both Lender Underwrite and "
            "Sponsor Proforma scenarios. Income breakdown (GPR, other income, vacancy, "
            "concessions, bad debt), expense normalization, NOI derivation, 5-year "
            "projections, and 6-constraint sizing waterfall. All financial math is "
            "deterministic — Claude provides narrative only.",
            "$0.50–$1.50"
        ],
        [
            "pinchfin_nuance_gate",
            "Complex deal feature analysis. Detects and evaluates nuance flags: "
            "LIHTC (4%/9%), Section 8/HAP, rent control/stabilization, ground leases, "
            "tax abatements (421-a, PILOT), seismic retrofit, environmental concerns, "
            "complex ownership (TIC, JV). Returns GO/NO-GO/CONDITIONAL with financial "
            "impact estimates and regulatory research.",
            "$0.50–$2.00"
        ],
        [
            "pinchfin_business_plan_analysis",
            "Value-add business plan feasibility. Evaluates renovation budget against "
            "RSMeans benchmarks, rent lift potential vs. market support, lease-up "
            "timeline, and execution risk. Returns feasibility rating "
            "(strong/moderate/weak/not feasible) with conditions.",
            "$0.50–$2.00"
        ],
        [
            "pinchfin_renovation_roi",
            "Renovation return-on-investment analysis. Current rent vs. target rent, "
            "annual income increase, payback period in months, value creation at "
            "multiple cap rates (sensitivity table), and ROI recommendation. All "
            "calculations deterministic.",
            "$0.50–$2.00"
        ],
        [
            "pinchfin_term_sheet_comparator",
            "Side-by-side term sheet comparison. Analyzes 2+ competing term sheets "
            "across rate, spread, fees, term, IO period, prepayment, extensions, "
            "covenants, cash management, and reserves. Returns comparison matrix "
            "and preferred lender recommendation with rationale.",
            "$0.50–$1.50"
        ],
        [
            "pinchfin_ic_memo",
            "Investment Committee memorandum — the capstone document. Executive "
            "summary, deal narrative, sponsor assessment, market overview, financial "
            "analysis, risk assessment, sources and uses, key metrics strip, and "
            "recommendation (Approve / Approve with Conditions / Decline). Requires "
            "prior phase outputs for full depth.",
            "$1.00–$3.00"
        ],
        [
            "pinchfin_deal_book",
            "Document synthesis. Processes uploaded deal documents (OM, rent roll, "
            "T-12, appraisal, term sheets) into a structured deal package with "
            "extracted data points and cross-referenced findings.",
            "$0.75–$3.00"
        ],
    ])

    # ── Composite Tools ──
    report.add_section("COMPOSITE WORKFLOWS")
    report.add_paragraph(
        "Multi-step orchestrated workflows that internally call multiple Tier 1–3 "
        "tools in sequence, producing comprehensive analysis packages."
    )
    report.add_table([
        ["Tool", "Description", "Cost"],
        [
            "pinchfin_quick_review",
            "Full 10-minute deal screening workflow. Internally orchestrates: "
            "deal screen → sponsor analysis → market research → comp analysis → "
            "cash flow sizing → synthesis. Runs 21 parallel Perplexity queries, "
            "pulls live macro data, executes the full constraint waterfall, and "
            "produces a screening recommendation with 4 DOCX reports (Quick Review "
            "memo, Sponsor report, Market report, Comps report).",
            "$2.00–$6.00"
        ],
    ])

    # ── Free Tools ──
    report.add_section("FREE TOOLS")
    report.add_paragraph(
        "Account management and utility tools. No charge, no balance required."
    )
    report.add_table([
        ["Tool", "Description"],
        ["pinchfin_estimate_cost", "Pre-run cost estimate for any module combination. Shows low/high range and hold amount."],
        ["pinchfin_account", "Check balance, held funds, available balance, and recent transaction history."],
        ["pinchfin_deposit", "Load funds via Stripe checkout. Returns a secure payment URL. Minimum $25."],
        ["pinchfin_deal_status", "Check workflow progress on any deal — phases completed, percentage, next steps."],
        ["pinchfin_list_deals", "List all deals in your account. Filter by status (active/completed/archived)."],
        ["pinchfin_upload_docs", "Upload document metadata to a deal. Documents processed when analysis runs."],
        ["pinchfin_help", "Full tool list with costs, descriptions, cost factors, and usage tips."],
    ])

    # ── Billing ──
    report.add_section("BILLING MODEL")
    report.add_kv_pairs([
        ("Billing Type", "Usage-based prepaid wallet"),
        ("Starting Credit", "$50.00 (beta)"),
        ("Minimum Deposit", "$25.00"),
        ("Low Balance Alert", "$5.00"),
        ("Cost Visibility", "Estimate shown before every billable tool — you always confirm"),
        ("Actual Charge", "Based on real token usage, not the estimate"),
    ])
    report.add_thin_rule()
    report.add_subsection("Cost Factors")
    report.add_table([
        ["Factor", "Effect"],
        ["Unit count <50", "0.8x (simpler asset)"],
        ["Unit count 50–150", "1.0x (baseline)"],
        ["Unit count 150–300", "1.2x (moderate complexity)"],
        ["Unit count 300–500", "1.4x (complex)"],
        ["Unit count 500+", "1.6x (high complexity)"],
        ["Re-run discount", "35% off (cached context)"],
        ["Document pages", "$0.05/page additional"],
    ])

    out = os.path.join(os.path.dirname(__file__), "PinchFin_MCP_Tool_Roster.docx")
    report.save(out)
    print(f"[OK] Tool Roster saved: {out}")


def generate_user_manual():
    """User Manual — how to use PinchFin in Claude Code CLI."""
    report = ValeriReport("User Manual", "PinchFin MCP for Claude Code")

    # ── Getting Started ──
    report.add_section("GETTING STARTED")
    report.add_paragraph(
        "PinchFin runs inside Claude Code as an MCP (Model Context Protocol) integration. "
        "You interact with PinchFin by talking to Claude in plain English. Claude recognizes "
        "when a PinchFin tool is relevant and calls it automatically — or you can request "
        "specific tools directly."
    )
    report.add_subsection("Prerequisites")
    report.add_kv_pairs([
        ("Claude Code", "Pro or Max subscription (claude.ai/download)"),
        ("Python", "3.10 or newer (python.org/downloads)"),
        ("PinchFin Package", "pip install git+https://github.com/Pinchfin/pinchfin-mcp.git"),
        ("API Key", "Provided in your beta invite"),
    ])

    report.add_subsection("Configuration")
    report.add_paragraph(
        'Add PinchFin to your Claude Code config file (~/.claude.json on Mac/Linux, '
        'C:\\Users\\YOUR_NAME\\.claude.json on Windows). Add the following inside the '
        '"mcpServers" section:'
    )
    report.add_callout_box(
        "claude.json Configuration",
        '"pinchfin": {\n'
        '    "type": "stdio",\n'
        '    "command": "python",\n'
        '    "args": ["-m", "pinchfin_mcp.server"],\n'
        '    "env": {\n'
        '        "PINCHFIN_API_URL": "https://pinchfin-api-production.up.railway.app/v1",\n'
        '        "PINCHFIN_API_KEY": "YOUR_API_KEY_HERE"\n'
        '    }\n'
        '}',
        style="aether",
    )
    report.add_paragraph(
        'Windows users: change "python" to "py" if python is not in your PATH. '
        "After saving, restart Claude Code completely."
    )

    # ── How to Use ──
    report.add_section("HOW TO USE PINCHFIN")
    report.add_paragraph(
        "PinchFin is conversational. You describe what you need in plain English, and Claude "
        "determines which PinchFin tools to call. You can also request specific tools directly."
    )

    report.add_subsection("Natural Language (Recommended)")
    report.add_paragraph(
        "Just describe the deal and what you want to know. Claude will select the right tool, "
        "show you the cost estimate, and ask for confirmation before running."
    )
    report.add_table([
        ["What You Type", "What Happens"],
        [
            '"Screen this deal: 200 Main St, Austin TX, 150 units, $30M loan"',
            "Claude calls pinchfin_deal_screen with your parameters"
        ],
        [
            '"How much can I borrow on a $60M asset with $3.2M NOI?"',
            "Claude calls pinchfin_loan_sizer or pinchfin_debt_sizing_preview"
        ],
        [
            '"Run sponsor diligence on Greystar Real Estate Partners"',
            "Claude calls pinchfin_sponsor_analysis"
        ],
        [
            '"What does the multifamily market look like in Dallas?"',
            "Claude calls pinchfin_market_research"
        ],
        [
            '"Compare these two term sheets" (paste term sheet details)',
            "Claude calls pinchfin_term_sheet_comparator"
        ],
        [
            '"Give me a full screening on this deal" (provide deal details)',
            "Claude calls pinchfin_quick_review (orchestrated workflow)"
        ],
        [
            '"Size a pref equity position on this deal — $16.5M senior, $24.5M cost..."',
            "Claude calls pinchfin_pref_equity_qr"
        ],
    ])

    report.add_subsection("Direct Tool Requests")
    report.add_paragraph(
        "You can also request specific tools by name if you know exactly what you want."
    )
    report.add_table([
        ["What You Type", "Tool Called"],
        ['"Run pinchfin_deal_screen on 500 Oak Ave..."', "pinchfin_deal_screen"],
        ['"Check my PinchFin balance"', "pinchfin_account"],
        ['"What PinchFin tools are available?"', "pinchfin_help"],
        ['"How much would a sponsor analysis cost?"', "pinchfin_estimate_cost"],
    ])

    # ── Workflow Patterns ──
    report.add_section("RECOMMENDED WORKFLOWS")

    report.add_subsection("1. Quick Screening (1–2 minutes, ~$0.15)")
    report.add_paragraph(
        "Start every deal here. Fast, cheap, tells you whether to spend more time."
    )
    report.add_callout_box(
        "Example Prompt",
        "Screen this deal: 5700 Clemson Dr, Dallas TX 75214. "
        "165-unit Class B multifamily, 1985 vintage. "
        "Sponsor: ABC Realty Group. Loan request: $42M acquisition.",
        style="aether",
    )
    report.add_paragraph(
        "You get: pass/fail against 6 credit constraints, binding constraint identified, "
        "property context data, risk flags, and a narrative summary."
    )

    report.add_subsection("2. Targeted Deep Dive (5–10 minutes, ~$1–3)")
    report.add_paragraph(
        "When you need depth on a specific dimension — run individual tools."
    )
    report.add_table([
        ["Scenario", "Tool to Use"],
        ["New sponsor, need background", "pinchfin_sponsor_analysis"],
        ["Unfamiliar market", "pinchfin_market_research"],
        ["Need rent/sale comps", "pinchfin_comp_analysis"],
        ["Value-add feasibility check", "pinchfin_business_plan_analysis"],
        ["Comparing lender offers", "pinchfin_term_sheet_comparator"],
        ["Complex deal features (LIHTC, ground lease)", "pinchfin_nuance_gate"],
        ["Preferred equity sizing", "pinchfin_pref_equity_qr"],
    ])

    report.add_subsection("2A. Preferred Equity Sizing (~$3–8)")
    report.add_paragraph(
        "Size a preferred equity position behind an existing or proposed senior loan. "
        "Validates the senior debt independently, then sizes pref against 9 constraints "
        "with PIK accrual modeling and exit scenario analysis."
    )
    report.add_callout_box(
        "Example Prompt",
        "Size a pref equity position on this deal: 2800 Telegraph Ave, Oakland CA. "
        "165-unit new construction, $24.5M total cost, $16.5M senior loan at 7.50%. "
        "Stabilized NOI $1.5M, exit cap 5.25%. Sponsor requesting $2.5M pref at "
        "7% current / 7% PIK. 24 months construction, 9 months lease-up.",
        style="aether",
    )
    report.add_paragraph(
        "You get: max supportable pref equity, binding constraint, quarterly PIK schedule, "
        "5 exit scenarios (base, ±10%, -20%, breakeven), sponsor MOIC/IRR with and without "
        "pref, return sensitivity by exit timing, and a 22-section DOCX memo."
    )

    report.add_subsection("3. Full Quick Review (10 minutes, ~$3–6)")
    report.add_paragraph(
        "The flagship workflow. Internally runs sponsor + market + comps + cash flow + "
        "sizing and synthesizes everything into a screening recommendation with 4 DOCX reports."
    )
    report.add_callout_box(
        "Example Prompt",
        "Run a full Quick Review on 123 Main St, Dallas TX 75201. "
        "165-unit multifamily, Class B, 1985 vintage. "
        "$42M loan request for acquisition. Sponsor is XYZ Realty Group. "
        "Current NOI around $2.5M, pro forma rents ~$1,800/unit.",
        style="aether",
    )
    report.add_paragraph(
        "You get: screening recommendation (PASS/CONDITIONAL/FAIL), sponsor tier, "
        "market rating, comp-supported rent conclusions, constraint waterfall, "
        "risk assessment, and due diligence questions."
    )

    report.add_subsection("4. Iterative Analysis")
    report.add_paragraph(
        "PinchFin tools work within your Claude Code conversation. You can chain analyses "
        "naturally:"
    )
    report.add_callout_box(
        "Conversation Flow",
        "You: Screen this deal — 200 units, $25M, Austin TX\n"
        "Claude: [runs deal screen] Deal passes. Binding constraint: DSCR at 1.08x.\n\n"
        "You: The sponsor is new to us. Run a background check.\n"
        "Claude: [runs sponsor analysis] Sponsor rated B+. 12 prior deals...\n\n"
        "You: Looks good. How does the Austin market look?\n"
        "Claude: [runs market research] Austin multifamily: 4.2% vacancy, 3.1% rent growth...\n\n"
        "You: Size the loan at our constraints.\n"
        "Claude: [runs loan sizer] Max loan $23.8M, binding: DSCR at 1.05x...",
        style="aether",
    )

    # ── Understanding Output ──
    report.add_section("UNDERSTANDING YOUR RESULTS")

    report.add_subsection("JSON Results")
    report.add_paragraph(
        "Every tool returns structured JSON directly in your Claude Code conversation. "
        "Claude will interpret and summarize the results for you. Key fields to look for:"
    )
    report.add_table([
        ["Field", "What It Means"],
        ["status: pass/fail", "Whether the deal meets credit box criteria"],
        ["binding_constraint", "The most restrictive constraint (governs max loan)"],
        ["sponsor_tier: A/B/C/D", "Sponsor quality classification"],
        ["market_rating: strong/moderate/weak", "Overall market assessment"],
        ["screen_result: PASS/CONDITIONAL/FAIL", "Quick Review recommendation"],
        ["go_no_go: GO/NO-GO/CONDITIONAL", "Nuance gate or sponsor determination"],
    ])

    report.add_subsection("DOCX Reports")
    report.add_paragraph(
        "When analysis runs in real mode, branded PinchFin DOCX reports are automatically "
        "generated and available for download. Reports use institutional formatting with "
        "the PinchFin v9 design system — ready to share with investment committees, "
        "credit officers, or capital partners."
    )

    report.add_subsection("Credit Box Constraints")
    report.add_paragraph(
        "PinchFin uses a 6-constraint waterfall for all loan sizing. The most restrictive "
        "constraint governs the maximum loan amount."
    )
    report.add_table([
        ["Constraint", "Threshold", "Type"],
        ["LTV As-Is", "75.0%", "Hard ceiling"],
        ["LTV Stabilized", "75.0%", "Hard ceiling"],
        ["DSCR Stabilized", "1.05x", "Hard floor (sizes the loan)"],
        ["Debt Yield Stabilized", "7.00%", "Hard floor"],
        ["LTC", "80.0%", "Hard ceiling"],
        ["Max Loan", "$100M", "Program cap"],
    ])

    # ── Account Management ──
    report.add_section("MANAGING YOUR ACCOUNT")
    report.add_table([
        ["Action", "What to Say"],
        ["Check balance", '"Check my PinchFin balance" or "How much credit do I have?"'],
        ["See transaction history", '"Show my PinchFin transactions"'],
        ["Get a cost estimate", '"How much would a sponsor analysis cost for a 200-unit deal?"'],
        ["List your deals", '"List my PinchFin deals"'],
        ["Check deal progress", '"What\'s the status of deal PF-2026-001?"'],
    ])

    # ── Tips ──
    report.add_section("TIPS FOR BEST RESULTS")

    report.add_paragraph(
        "1. Start with a screen. At $0.10–$0.50, it's the cheapest way to filter deals "
        "before committing to deeper analysis."
    )
    report.add_paragraph(
        "2. Provide complete deal details. The more context you give (address, units, "
        "loan amount, sponsor name, NOI, business plan), the better the analysis."
    )
    report.add_paragraph(
        "3. Use the Quick Review for pipeline screening. At $3–6, it replaces hours "
        "of manual work with a structured recommendation in 10 minutes."
    )
    report.add_paragraph(
        "4. Re-runs are 35% cheaper. If you need to re-analyze a deal with updated "
        "assumptions, the system applies a discount for cached context."
    )
    report.add_paragraph(
        "5. Chain tools in conversation. Run a screen first, then drill into sponsor "
        "or market as needed. Claude maintains context across the conversation."
    )
    report.add_paragraph(
        "6. Every billable tool shows cost before running. You always confirm. "
        "No surprises."
    )

    # ── Troubleshooting ──
    report.add_section("TROUBLESHOOTING")
    report.add_table([
        ["Issue", "Fix"],
        [
            "PinchFin tools not showing up",
            "Verify ~/.claude.json has valid JSON with pinchfin in mcpServers. "
            "Restart Claude Code completely (close and reopen)."
        ],
        [
            "Authentication failed",
            "Double-check your API key — no extra spaces or quotes. "
            "Make sure you pasted the full key starting with pf_"
        ],
        [
            "Insufficient funds",
            'Ask "check my PinchFin balance" to see remaining credits. '
            "Contact your PinchFin admin for additional credits during beta."
        ],
        [
            '"python" not found (Windows)',
            'Change "command": "python" to "command": "py" in your claude.json config.'
        ],
        [
            "Tool returns mock/simulated data",
            "This means the server is running in fallback mode. Contact support — "
            "the analysis engine may need to be restarted."
        ],
    ])

    report.add_section("SUPPORT")
    report.add_paragraph(
        "For questions, issues, or feedback during the beta, contact your PinchFin admin "
        "directly. We want to hear everything — what worked, what broke, what you wish it did."
    )

    out = os.path.join(os.path.dirname(__file__), "PinchFin_MCP_User_Manual.docx")
    report.save(out)
    print(f"[OK] User Manual saved: {out}")


if __name__ == "__main__":
    generate_tool_roster()
    generate_user_manual()
