# Claude Instructions for owlbear

## Project Overview
Owlbear is a Python client that bridges AWS Athena and Polars. It executes Athena SQL queries and returns results as typed Polars DataFrames via PyArrow. Named for its two halves: Owl (Athena) + Bear (Polars).

## Development Guidelines
- Use Polars for all data processing operations
- Follow Python packaging best practices with pyproject.toml
- Maintain compatibility with Python 3.10+

## Dependencies
- polars: Core data processing library
- boto3: AWS SDK for Athena integration

## Development Dependencies
- pytest: Testing framework
- black: Code formatter
- ruff: Linter
- mypy: Type checker

## Commands
- Install dependencies: `pip install -e .[dev]`
- Run tests: `pytest`
- Format code: `black .`
- Lint code: `ruff check .`
- Type check: `mypy src/` or `pyright src/owlbear/`

## Notes
- Pre-commit hook blocks `Co-Authored-By:.*Claude` in commit messages
- `dist/` has build artifacts from the PyPI upload (not gitignored but also not tracked)
- Athena `DESCRIBE` fails on partitioned tables with ragged metadata — always use `_get_columns()` (information_schema first, DESCRIBE fallback) for schema introspection
- Release flow: bump version in pyproject.toml, commit, push, `python -m build`, `python -m twine upload dist/owlbear-X.Y.Z*`
- MCP server: 20 tools (10 data-lake + 10 DataFrame cache), 2 prompts, 1 resource — configured in `~/.mcp.json`
- `OWLBEAR_MAX_ROWS` env var controls max_rows cap (0 = no cap, default). Previously hardcoded at 10,000.
- S3 direct-read (v0.9.0): Parquet-configured workgroups get a near zero-copy path (S3 Parquet → Arrow → Polars). Non-Parquet outputs fall back to the paginated JSON API.

## 🔄 RESUME CONTEXT - DELETE AFTER READING

### Current Status
v0.9.0 released and published to PyPI.

### What Was Built
- Replaced CSV S3 direct-read with Parquet path (`pq.read_table()` / `pq.ParquetFile.iter_batches()`). Detection checks `.endswith(".parquet")` on OutputLocation.
- Removed dead CSV helpers. 59 tests pass, ruff/black clean.

### Next Actions
- Smoke test via MCP against a Parquet-configured workgroup if available
- Consider whether CSV S3 path is worth restoring as a middle tier (Parquet → S3, CSV → S3, else → JSON API)
