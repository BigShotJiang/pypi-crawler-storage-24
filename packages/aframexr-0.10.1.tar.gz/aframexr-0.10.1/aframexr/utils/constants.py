"""Constant / default values utils file"""

# ----- CONSTANTS -----
AVAILABLE_AGGREGATES = {'count', 'max', 'median', 'mean', 'min', 'std', 'sum', 'var'}
AVAILABLE_COLORS = ['red', 'green', 'blue', 'yellow', 'magenta', 'cyan']  # Using list to maintain order
AVAILABLE_ENCODING_TYPES = {'Q': 'quantitative', 'N': 'nominal'}
AVAILABLE_ENVIRONMENTS = {'default', 'contact', 'egypt', 'checkerboard', 'forest', 'goaland', 'yavapai', 'goldmine',
                          'arches', 'threetowers', 'poison', 'tron', 'japan', 'dream', 'volcano', 'starry', 'osiris'}
AVAILABLE_MARKS = {'arc', 'bar', 'line', 'point'}

ENTITY_IS_MOVABLE = False

EPSILON = 1e-5  # To avoid floating problems

START_LABEL_OFFSET = 0.25  # Offset for the start label of the axis
X_LABELS_Z_DELTA = 0.5  # Variation in the y-axis between the labels and the axis (add to x-axis pos for label pos)
LABELS_X_DELTA = -0.5  # Variation in the x-axis between the labels and the axis (add to y and z axis pos for label pos)
LABELS_Y_DELTA = 0.01  # Variation in the y-axis between the labels and the axis (add to x and z axis pos for label pos)

LABELS_SCALE = '1.5 1.5 1.5'

LEGEND_WIDTH = 3  # Width of the legend
LEGEND_HEIGHT_PER_ELEMENT = 0.6  # Legend's height per element in the legend

PLANE_TITLE_HEIGHT = 1  # Height of the title's plane
PLANE_TITLE_SEPARATION = 0.5  # Separation between the chart and the title
TITLE_TEXT_COLOR = 'black'
TITLE_TEXT_SCALE = '2 2 2'

# ----- DEFAULTS -----
# General
DEFAULT_CHART_POS = '0 0 0'  # Default position of the chart
DEFAULT_CHART_ROTATION = '0 0 0'  # Default chart rotation
DEFAULT_CHART_DEPTH = 2  # Default depth of the chart
DEFAULT_CHART_HEIGHT = 4  # Default height of the chart
DEFAULT_CHART_WIDTH = 4  # Default width of the chart

DEFAULT_ELEMENTS_COLOR_IN_CHART = 'blue'  # Default elements color in chart

DEFAULT_NUM_OF_TICKS_IF_QUANTITATIVE_AXIS = 5  # Number of ticks in the axis if it is quantitative

# Bar chart
DEFAULT_BAR_PADDING = 0.2  # Default padding in bar chart

# Line chart
DEFAULT_VERTICES_POINT_DISPLAY = False  # Default points' display in line's vertices
DEFAULT_VERTICES_POINT_VOLUME = 0.002  # Default points' volume in vertices (if displayed)
DEFAULT_VERTICES_SPACING = 0.5  # Default spacing between vertices of the line

# Pie chart
DEFAULT_PIE_RADIUS = 1  # Default radius of the pie chart
DEFAULT_PIE_ROTATION = '-90 0 0'  # Default pie chart rotation

# Point chart
DEFAULT_POINT_VOLUME = 0.7  # Default point's volume

# ========== ERROR MESSAGES ==========
ERROR_MESSAGES = {
    'ALIGN': "Invalid align property: {align}. Must be one of ['center', 'left', 'right']",
    'AGGREGATE_OPERATION': 'Invalid aggregate operation: {operation}',
    'AGGREGATE_OPERATION_NOT_IN_AGGREGATE': 'Aggregate must contain key "op"',
    'COLOR_ENCODING_NOT_NOMINAL': 'Color encoding type must be nominal, got "{color_encoding}"',
    'DATA_WITH_VALUES_AND_URL_IN_SPECS': 'Data cannot contain both "values" and "url"; they are mutually exclusive',
    'DATA_WITH_NOT_VALUES_NEITHER_URL_IN_SPECS': 'Data must contain key "values" or "url"',
    'DATA_NOT_IN_SPECS': 'Invalid chart specifications. Must contain key "data"',
    'ELEMENT_TYPE': 'Invalid element type: {element}',
    'ENCODING_NOT_IN_SPECS': 'Invalid chart specifications. Must contain key "encoding"',
    'ENCODING_TYPE': 'Invalid encoding type: {encoding_type}',
    'ENVIRONMENT': 'Invalid environment: {environment}',
    'LESS_THAN_2_XYZ_ENCODING': 'At least 2 of (x, y, z) must be specified when encoding "mark_bar" or "mark_point"',
    'MARK_AND_ELEMENT_IN_SPECS': 'Specifications cannot contain both "mark" and "element"; they are mutually exclusive',
    'MARK_AND_ELEMENT_NOT_IN_SPECS': 'Invalid chart specifications. Must contain key "mark" or "element"',
    'MARK_TYPE': 'Invalid mark type: {mark_type}',
    'NAME_NOT_IN_PARAM': 'Param specs must contain key "name"',
    'NOT_3_AXES_POSITION_OR_ROTATION': 'The {pos_or_rot}: {pos_or_rot_value} is not correct. Must be "x y z"',
    'NOT_ALL_DATA_VALUES_ARE_DICT': 'Data field "values" must be a list of dictionaries',
    'NOT_ALL_ENCODINGS_ARE_DICT': 'Encoding channels must be dictionaries',
    'PARAM_NOT_SPECIFIED_IN_MARK_ARC': 'Parameter "{param}" must be specified in arc chart',
    'POSITIVE_NUMBER': 'The "{param_name}" must be greater than 0.',
    'SIZE_ENCODING_NOT_QUANTITATIVE': 'Size encoding type must be quantitative, got "{size_encoding}"',
    'TRANSFORM_TYPE': 'Invalid transform type: {transform_type}',
    'TYPE': 'Expected "{param_name}" to be {expected_type}, got {current_type} instead',
}
