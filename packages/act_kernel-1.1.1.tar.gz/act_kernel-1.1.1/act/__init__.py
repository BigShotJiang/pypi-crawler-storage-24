"""ACT Kernel – Deterministic Execution Kernel for AI Agents"""

from .kernel import ACTKernel
from .tooling import tool, register_tools_from_module
from .protocol import (
    Envelope, ExecutionInfo,
    Status, BreakerState,
    ACTError, TimeoutError, CircuitOpenError, ToolError,
    RetryExhaustedError, ToolUnavailableError, ACTPermissionError, ResourceExhaustedError,
    error_code_from_exception
)

__all__ = [
    "ACTKernel",
    "tool",
    "register_tools_from_module",
    "Envelope",
    "ExecutionInfo",
    "Status",
    "BreakerState",
    "ACTError",
    "TimeoutError",
    "CircuitOpenError",
    "ToolError",
    "RetryExhaustedError",
    "ToolUnavailableError",
    "ACTPermissionError",
    "ResourceExhaustedError",
    "error_code_from_exception",
]
