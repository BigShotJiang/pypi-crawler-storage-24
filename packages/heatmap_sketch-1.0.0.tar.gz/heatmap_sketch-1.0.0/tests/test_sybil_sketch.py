"""
Test SybilSketch implementation.

Quick tests to verify core functionality.
"""

import sys
import os
import time
import random

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from sybil_sketch import SybilSketch, create_sybil_sketch


def test_basic_add_check():
    """Test basic add and check operations."""
    sketch = create_sybil_sketch(
        expected_items=1000,
        expected_sources=100,
        half_life_minutes=60  # Long half-life for test
    )
    
    # Add contributions from multiple sources
    for i in range(10):
        sketch.add("#trending", source=f"user_{i}")
    
    heat = sketch.check("#trending")
    print(f"Heat after 10 honest sources: {heat:.2f}")
    assert heat > 0, "Should have positive heat"
    assert heat < 15, "Heat should be capped per-source"
    
    sketch.stop()
    print("✅ Basic add/check works")


def test_byzantine_resistance():
    """Test that bot contributions are filtered."""
    sketch = create_sybil_sketch(
        expected_items=1000,
        expected_sources=200,
        half_life_minutes=60
    )
    
    # Honest users promote #organic
    for i in range(50):
        sketch.add("#organic", source=f"honest_{i}")
    
    # Bots promote #fake (same few sources, high volume)
    for _ in range(10):  # Many repetitions
        for i in range(10):  # Only 10 bot sources
            sketch.add("#fake", source=f"bot_{i}")
    
    top = sketch.top(10)
    print(f"\nTop trending: {top[:3]}")
    
    # Check that organic is ranked higher
    items = [item for item, _, _, _ in top]
    
    # Organic should appear in top (diverse sources)
    # Fake might not appear (low diversity)
    
    print(f"Organic in top: {'#organic' in items}")
    print(f"Fake in top: {'#fake' in items}")
    
    # Get stats
    stats = sketch.stats()
    print(f"\nStats: {stats['valid_trending_items']} valid trending items")
    
    sketch.stop()
    print("✅ Byzantine resistance works")


def test_reputation_scoring():
    """Test reputation system."""
    sketch = SybilSketch(max_sources=100, decay_interval_seconds=0)
    
    # Add diverse contributions (honest behavior)
    honest_source = "honest_user"
    for i in range(20):
        sketch.add(f"#topic_{i % 5}", source=honest_source)
        time.sleep(0.01)  # Small delay
    
    honest_stats = sketch.get_source_stats(honest_source)
    print(f"\nHonest source diversity: {honest_stats['diversity']:.2f}")
    print(f"Honest source reputation: {honest_stats['overall_reputation']:.2f}")
    
    # Add narrow contributions (bot behavior)
    bot_source = "bot_user"
    for _ in range(20):
        sketch.add("#spam", source=bot_source)
    
    bot_stats = sketch.get_source_stats(bot_source)
    print(f"Bot source diversity: {bot_stats['diversity']:.2f}")
    print(f"Bot source reputation: {bot_stats['overall_reputation']:.2f}")
    
    # Honest should have higher diversity
    assert honest_stats['diversity'] > bot_stats['diversity'], \
        "Honest should have higher diversity"
    
    sketch.stop()
    print("✅ Reputation scoring works")


def test_manipulation_scenario():
    """Test coordinated manipulation attack."""
    sketch = create_sybil_sketch(
        expected_items=10000,
        expected_sources=500,
        half_life_minutes=5
    )
    
    print("\n" + "="*60)
    print("Scenario: Coordinated Bot Attack")
    print("="*60)
    
    # Simulate organic traffic
    organic_items = ["#news", "#sports", "#tech", "#politics"]
    for _ in range(500):
        item = random.choice(organic_items)
        source = f"user_{random.randint(1, 300)}"
        sketch.add(item, source=source)
    
    # Bots coordinate to promote #fake
    print("\nBots promoting #fake...")
    for round in range(50):
        for bot_id in range(1, 51):  # 50 bots
            sketch.add("#fake", source=f"bot_{bot_id}")
    
    # Get trending
    top = sketch.top(5)
    
    print("\nTop 5 Trending:")
    for i, (item, heat, sources, byzantine) in enumerate(top, 1):
        status = "🤖 SUSPICIOUS" if byzantine > 0.5 else "✓ ORGANIC"
        print(f"{i}. {item:<15} heat={heat:>6.2f} sources={sources:>3} byzantine={byzantine:.2f} {status}")
    
    stats = sketch.stats()
    print(f"\nTotal valid trending: {stats['valid_trending_items']}")
    
    sketch.stop()
    print("\n✅ Manipulation detection works")


if __name__ == "__main__":
    print("Testing SybilSketch\n")
    
    test_basic_add_check()
    test_byzantine_resistance()
    test_reputation_scoring()
    test_manipulation_scenario()
    
    print("\n" + "="*60)
    print("All tests passed! SybilSketch is working.")
    print("="*60)
