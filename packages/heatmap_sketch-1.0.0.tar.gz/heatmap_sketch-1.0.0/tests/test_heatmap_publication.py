"""
Publication-Grade Test Suite for HeatMap

This test suite is designed to ensure the HeatMap data structure is
bulletproof and ready for publication in a top-tier venue.

Categories:
1. Mathematical Correctness - Verify decay formula is exact
2. Invariant Tests - Properties that must ALWAYS hold
3. Boundary Tests - Extreme values and edge cases
4. Concurrency Stress - Aggressive thread safety
5. Memory Safety - No leaks, proper cleanup
6. Fuzzing - Random inputs to find crashes
7. Long-Running Stability - Behavior over extended time
8. Real-World Scenarios - Actual usage patterns

Run with: pytest tests/test_heatmap_publication.py -v -s
"""

from __future__ import annotations

import gc
import math
import os
import random
import string
import sys
import time
import threading
import weakref
from typing import List, Tuple

import pytest
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from heatmap_sketch import HeatMap, HierarchicalHeatMap
from heatmap_sketch.heatmap import HeatMapError, HeatMapCapacityError


# =============================================================================
# 1. MATHEMATICAL CORRECTNESS
# =============================================================================

class TestMathematicalCorrectness:
    """Verify that the mathematical properties are EXACTLY correct."""
    
    def test_decay_formula_precision(self):
        """
        Verify decay factor matches the exact mathematical formula:
        decay_factor = 0.5^(interval / half_life)
        
        This is the core mathematical property of the data structure.
        """
        test_cases = [
            # (half_life, interval, expected_factor)
            (60.0, 60.0, 0.5),        # One half-life = 50%
            (60.0, 30.0, 0.70710678), # Half of half-life
            (60.0, 120.0, 0.25),      # Two half-lives = 25%
            (10.0, 5.0, 0.70710678),  # Different scale
            (100.0, 1.0, 0.99309249), # Small decay
            (1.0, 0.5, 0.70710678),   # Sub-second
            (3600.0, 3600.0, 0.5),    # One hour
        ]
        
        for half_life, interval, expected in test_cases:
            hm = HeatMap(
                half_life_seconds=half_life,
                decay_interval_seconds=interval
            )
            
            actual = hm.decay_factor
            assert abs(actual - expected) < 1e-6, \
                f"decay_factor mismatch for half_life={half_life}, interval={interval}: " \
                f"expected {expected}, got {actual}"
            
            hm.stop()
    
    def test_decay_after_n_intervals(self):
        """
        After n decay intervals, heat should be exactly:
        original * decay_factor^n
        """
        hm = HeatMap(
            half_life_seconds=1.0,
            decay_interval_seconds=1.0  # decay_factor = 0.5
        )
        
        original = 1000.0
        hm.add("item", amount=original)
        
        for n in range(1, 20):
            hm.decay()
            expected = original * (0.5 ** n)
            actual = hm.check("item")
            
            # Allow small floating point error
            rel_error = abs(actual - expected) / expected
            assert rel_error < 1e-10, \
                f"After {n} decays: expected {expected}, got {actual} (error: {rel_error})"
        
        hm.stop()
    
    def test_decay_is_multiplicative(self):
        """Multiple small decays should equal one large decay."""
        # One large decay
        hm1 = HeatMap(half_life_seconds=100.0, decay_interval_seconds=10.0)
        hm1.add("item", amount=1000.0)
        hm1.decay()  # 10 seconds of decay
        after_large = hm1.check("item")
        hm1.stop()
        
        # Ten small decays (same total time)
        hm2 = HeatMap(half_life_seconds=100.0, decay_interval_seconds=1.0)
        hm2.add("item", amount=1000.0)
        for _ in range(10):
            hm2.decay()  # 1 second each
        after_small = hm2.check("item")
        hm2.stop()
        
        # Should be identical (multiplicative property)
        rel_error = abs(after_large - after_small) / after_large
        assert rel_error < 1e-6, \
            f"Decay not multiplicative: {after_large} vs {after_small}"
    
    def test_heat_addition_is_additive(self):
        """Adding heat multiple times should sum correctly."""
        hm = HeatMap(decay_interval_seconds=0)
        
        # Add in small increments
        for _ in range(100):
            hm.add("item", amount=10.0)
        
        total = hm.check("item")
        
        # Should be exactly 1000 (with small fp error)
        expected = 1000.0
        rel_error = abs(total - expected) / expected
        assert rel_error < 1e-10, f"Expected {expected}, got {total}"
    
    def test_minimum_heat_property(self):
        """Heat should NEVER go below 0."""
        hm = HeatMap(
            half_life_seconds=0.001,
            decay_interval_seconds=0.001
        )
        
        hm.add("item", amount=1.0)
        
        # Decay many times
        for _ in range(1000):
            hm.decay()
        
        heat = hm.check("item")
        assert heat >= 0, f"Heat went negative: {heat}"
        
        hm.stop()
    
    def test_heat_ordering_preserved(self):
        """If item A has more heat than B, decay preserves ordering."""
        hm = HeatMap(
            half_life_seconds=10.0,
            decay_interval_seconds=1.0
        )
        
        hm.add("hot", amount=1000.0)
        hm.add("warm", amount=100.0)
        hm.add("cold", amount=10.0)
        
        for _ in range(50):
            hm.decay()
            
            hot = hm.check("hot")
            warm = hm.check("warm")
            cold = hm.check("cold")
            
            assert hot > warm > cold, \
                f"Ordering violated after decays: hot={hot}, warm={warm}, cold={cold}"
        
        hm.stop()


# =============================================================================
# 2. INVARIANT TESTS
# =============================================================================

class TestInvariants:
    """Properties that must ALWAYS hold, no matter what."""
    
    def test_invariant_check_returns_min_of_k_positions(self):
        """
        check() returns the MINIMUM of k positions (Count-Min sketch property).
        This is a fundamental invariant.
        """
        hm = HeatMap(decay_interval_seconds=0, seed=42)
        
        hm.add("test_item", amount=100.0)
        
        # Get internal state
        positions = hm._hash_positions("test_item")
        heats = [hm._heat[p] for p in positions]
        reported = hm.check("test_item")
        
        # check() should return minimum
        assert abs(reported - min(heats)) < 1e-10, \
            f"check() should return min: expected {min(heats)}, got {reported}"
    
    def test_invariant_add_increases_all_k_positions(self):
        """add() should increase ALL k positions (not just some)."""
        hm = HeatMap(decay_interval_seconds=0, seed=42)
        
        item = "test_item"
        positions = hm._hash_positions(item)
        
        # Record before
        before = [hm._heat[p] for p in positions]
        
        # Add
        hm.add(item, amount=50.0)
        
        # Record after
        after = [hm._heat[p] for p in positions]
        
        # ALL positions should increase by exactly 50
        for i, (b, a) in enumerate(zip(before, after)):
            assert abs((a - b) - 50.0) < 1e-10, \
                f"Position {i} not increased correctly: {b} -> {a}"
    
    def test_invariant_top_k_returns_highest_items(self):
        """top(k) should return items with highest heat in DESCENDING order."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        
        # Add items with known heats (starting from 10 to avoid zero)
        items = [(f"item_{i}", float((i + 1) * 10)) for i in range(100)]
        random.shuffle(items)
        
        for item, heat in items:
            hm.add(item, amount=heat)
        
        # Get top 10
        top = hm.top(10)
        
        # Should be highest 10 in descending order
        assert len(top) == 10
        for i in range(9):
            assert top[i][1] >= top[i+1][1], \
                f"Top-k not in descending order: {top[i][1]} < {top[i+1][1]}"
        
        # Top item should be item_99 with heat ~1000
        assert top[0][0] == "item_99"
    
    def test_invariant_len_matches_candidates(self):
        """len(hm) should equal number of tracked candidates."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        
        assert len(hm) == 0
        
        for i in range(100):
            hm.add(f"item_{i}")
            assert len(hm) == i + 1
        
        # Adding same item again shouldn't change count
        for _ in range(10):
            hm.add("item_0")
            assert len(hm) == 100
    
    def test_invariant_hash_deterministic(self):
        """Same item should ALWAYS hash to same positions."""
        hm = HeatMap(seed=12345, decay_interval_seconds=0)
        
        # Hash same item 1000 times
        all_positions = [hm._hash_positions("test") for _ in range(1000)]
        
        # All should be identical
        first = all_positions[0]
        for positions in all_positions[1:]:
            assert all(positions == first), "Hash not deterministic"
    
    def test_invariant_different_items_different_hashes(self):
        """Different items should (almost always) hash to different positions."""
        hm = HeatMap(seed=42, decay_interval_seconds=0)
        
        # Hash 10000 different items
        positions_set = set()
        collisions = 0
        
        for i in range(10000):
            pos = tuple(hm._hash_positions(f"item_{i}"))
            if pos in positions_set:
                collisions += 1
            positions_set.add(pos)
        
        # With k=7 and m large, collisions should be extremely rare
        # Allow up to 0.1% collision rate
        collision_rate = collisions / 10000
        assert collision_rate < 0.001, \
            f"Too many hash collisions: {collision_rate*100:.2f}%"


# =============================================================================
# 3. BOUNDARY TESTS
# =============================================================================

class TestBoundaries:
    """Test extreme values and boundary conditions."""
    
    def test_boundary_min_capacity(self):
        """Test minimum allowed capacity."""
        # Should work
        hm = HeatMap(capacity=10, decay_interval_seconds=0)
        hm.add("test")
        hm.stop()
        
        # Should fail
        with pytest.raises(HeatMapCapacityError):
            HeatMap(capacity=9)
    
    def test_boundary_max_capacity(self):
        """Test very large capacity (10 billion)."""
        hm = HeatMap(capacity=10_000_000_000, decay_interval_seconds=0)
        
        # Should have huge array
        assert hm._m > 1_000_000_000
        
        hm.add("test")
        assert hm.check("test") >= 1.0
        
        hm.stop()
    
    def test_boundary_min_error_rate(self):
        """Test near-minimum error rate (just above 1e-6)."""
        # Error rate must be > 1e-6
        hm = HeatMap(error_rate=1.000001e-6, decay_interval_seconds=0)
        
        # Should have many hash functions
        assert hm._k >= 10
        
        hm.stop()
    
    def test_boundary_max_error_rate(self):
        """Test near-maximum error rate (just below 0.5)."""
        # Error rate must be < 0.5
        hm = HeatMap(error_rate=0.499999, decay_interval_seconds=0)
        assert hm._k >= 1
        hm.stop()
        
        # Should fail with 0.5 or higher
        with pytest.raises(HeatMapCapacityError):
            HeatMap(error_rate=0.5)
        
        with pytest.raises(HeatMapCapacityError):
            HeatMap(error_rate=0.51)
    
    def test_boundary_zero_half_life_rejected(self):
        """Zero half-life should be rejected."""
        with pytest.raises(ValueError):
            HeatMap(half_life_seconds=0)
        
        with pytest.raises(ValueError):
            HeatMap(half_life_seconds=-1)
    
    def test_boundary_very_small_amount(self):
        """Test very small heat amounts."""
        hm = HeatMap(decay_interval_seconds=0)
        
        # Add tiny amounts
        for _ in range(1000):
            hm.add("item", amount=1e-15)
        
        total = hm.check("item")
        expected = 1000 * 1e-15
        
        rel_error = abs(total - expected) / expected
        assert rel_error < 1e-5
    
    def test_boundary_very_large_amount(self):
        """Test very large heat amounts."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add("item", amount=1e15)
        
        heat = hm.check("item")
        rel_error = abs(heat - 1e15) / 1e15
        assert rel_error < 1e-6
    
    def test_boundary_empty_string_item(self):
        """Empty string should work as an item."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add("")
        assert hm.check("") >= 1.0
    
    def test_boundary_very_long_string_item(self):
        """Very long strings should work."""
        hm = HeatMap(decay_interval_seconds=0)
        
        # 1MB string
        long_item = "x" * 1_000_000
        
        hm.add(long_item)
        assert hm.check(long_item) >= 1.0
    
    def test_boundary_unicode_item(self):
        """Various unicode strings should work."""
        hm = HeatMap(decay_interval_seconds=0)
        
        unicode_items = [
            "hello",
            "こんにちは",  # Japanese
            "你好",  # Chinese
            "مرحبا",  # Arabic
            "שלום",  # Hebrew
            "🎉🎊🎁",  # Emojis
            "Ñoño",  # Accented
            "a\nb\tc",  # Control chars
        ]
        
        for item in unicode_items:
            hm.add(item)
            assert hm.check(item) >= 1.0, f"Failed for: {item!r}"
    
    def test_boundary_top_k_zero_rejected(self):
        """top(0) should be rejected (k must be positive)."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        hm.add("item")
        
        with pytest.raises(ValueError):
            hm.top(0)
    
    def test_boundary_top_k_negative_rejected(self):
        """top(-1) should be rejected."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        
        with pytest.raises(ValueError):
            hm.top(-1)


# =============================================================================
# 4. CONCURRENCY STRESS TESTS
# =============================================================================

class TestConcurrencyStress:
    """Aggressive thread safety testing."""
    
    def test_concurrent_adds_no_lost_updates(self):
        """Concurrent adds should not lose any updates."""
        hm = HeatMap(decay_interval_seconds=0)
        
        num_threads = 20
        adds_per_thread = 1000
        expected_total = num_threads * adds_per_thread
        
        def adder():
            for _ in range(adds_per_thread):
                hm.add("shared")
        
        threads = [threading.Thread(target=adder) for _ in range(num_threads)]
        
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        actual = hm.check("shared")
        
        # Due to Count-Min sketch, actual >= expected (overestimation)
        # But should be close
        assert actual >= expected_total
        assert actual < expected_total * 1.1  # No more than 10% over
    
    def test_concurrent_add_and_check_consistency(self):
        """check() during adds should always see consistent state."""
        hm = HeatMap(decay_interval_seconds=0)
        
        errors = []
        stop_flag = threading.Event()
        
        def adder():
            count = 0
            while not stop_flag.is_set():
                hm.add("item", amount=1.0)
                count += 1
            return count
        
        def checker():
            last_heat = 0.0
            while not stop_flag.is_set():
                heat = hm.check("item")
                # Heat should only increase (no decay)
                if heat < last_heat - 1e-6:  # Allow tiny fp error
                    errors.append(f"Heat decreased: {last_heat} -> {heat}")
                last_heat = heat
        
        adders = [threading.Thread(target=adder) for _ in range(10)]
        checkers = [threading.Thread(target=checker) for _ in range(5)]
        
        for t in adders + checkers:
            t.start()
        
        time.sleep(2)  # Run for 2 seconds
        stop_flag.set()
        
        for t in adders + checkers:
            t.join()
        
        assert len(errors) == 0, f"Consistency errors: {errors[:10]}"
    
    def test_concurrent_decay_and_add(self):
        """Decay and add operations should not interfere."""
        hm = HeatMap(
            half_life_seconds=1000.0,  # Slow decay
            decay_interval_seconds=0.1
        )
        
        errors = []
        stop_flag = threading.Event()
        
        def adder():
            while not stop_flag.is_set():
                hm.add("item", amount=100.0)
                time.sleep(0.001)
        
        def decayer():
            while not stop_flag.is_set():
                hm.decay()
                time.sleep(0.01)
        
        def checker():
            while not stop_flag.is_set():
                heat = hm.check("item")
                # Heat should always be non-negative
                if heat < 0:
                    errors.append(f"Negative heat: {heat}")
                time.sleep(0.001)
        
        threads = (
            [threading.Thread(target=adder) for _ in range(5)] +
            [threading.Thread(target=decayer) for _ in range(2)] +
            [threading.Thread(target=checker) for _ in range(3)]
        )
        
        for t in threads:
            t.start()
        
        time.sleep(3)
        stop_flag.set()
        
        for t in threads:
            t.join()
        
        hm.stop()
        assert len(errors) == 0, f"Errors: {errors}"
    
    def test_concurrent_stop_idempotent(self):
        """Multiple concurrent stop() calls should be safe."""
        hm = HeatMap(half_life_seconds=60.0, decay_interval_seconds=0.1)
        
        errors = []
        
        def stopper():
            try:
                hm.stop()
            except Exception as e:
                errors.append(e)
        
        threads = [threading.Thread(target=stopper) for _ in range(100)]
        
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        assert len(errors) == 0
        assert not hm.is_running
    
    def test_concurrent_top_k(self):
        """Concurrent top() calls should be safe."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        
        # Add initial items
        for i in range(1000):
            hm.add(f"item_{i}")
        
        errors = []
        stop_flag = threading.Event()
        
        def top_ker():
            while not stop_flag.is_set():
                try:
                    top = hm.top(10)
                    assert len(top) <= 10
                except Exception as e:
                    errors.append(e)
        
        def adder():
            while not stop_flag.is_set():
                hm.add(f"item_{random.randint(0, 999)}")
        
        threads = (
            [threading.Thread(target=top_ker) for _ in range(10)] +
            [threading.Thread(target=adder) for _ in range(5)]
        )
        
        for t in threads:
            t.start()
        
        time.sleep(2)
        stop_flag.set()
        
        for t in threads:
            t.join()
        
        assert len(errors) == 0, f"Errors: {errors}"


# =============================================================================
# 5. MEMORY SAFETY TESTS
# =============================================================================

class TestMemorySafety:
    """Test memory behavior and cleanup."""
    
    def test_no_memory_leak_on_stop(self):
        """Stopping and restarting should not leak memory."""
        import tracemalloc
        
        tracemalloc.start()
        
        baseline = tracemalloc.get_traced_memory()[0]
        
        for _ in range(100):
            hm = HeatMap(half_life_seconds=60.0, decay_interval_seconds=0.1)
            hm.add("test")
            hm.stop()
            del hm
        
        gc.collect()
        
        final = tracemalloc.get_traced_memory()[0]
        tracemalloc.stop()
        
        # Should not grow more than 1MB
        growth = (final - baseline) / 1024 / 1024
        assert growth < 1.0, f"Memory grew by {growth:.2f} MB"
    
    def test_weakref_cleanup(self):
        """HeatMap should be garbage collected when no references remain."""
        hm = HeatMap(decay_interval_seconds=0)
        weak = weakref.ref(hm)
        
        # Object exists
        assert weak() is not None
        
        # Delete reference
        del hm
        gc.collect()
        
        # Should be collected
        assert weak() is None
    
    def test_context_manager_cleanup(self):
        """Context manager should properly clean up."""
        weak = None
        
        with HeatMap(half_life_seconds=60.0, decay_interval_seconds=0.1) as hm:
            weak = weakref.ref(hm)
            hm.add("test")
            assert hm.is_running
        
        # After context exit
        gc.collect()
        assert weak() is not None  # Object still exists
        assert not weak().is_running  # But stopped
    
    def test_exception_during_init_no_leak(self):
        """Exception during __init__ should not leak resources."""
        weak = None
        
        try:
            hm = HeatMap(capacity=1)  # Will fail
            weak = weakref.ref(hm)
        except HeatMapCapacityError:
            pass
        
        gc.collect()
        
        # If init fails, object shouldn't exist
        if weak:
            assert weak() is None
    
    def test_large_sketch_memory_estimate(self):
        """Memory estimate should be reasonable."""
        capacities = [10_000, 100_000, 1_000_000, 10_000_000]
        
        for cap in capacities:
            hm = HeatMap(capacity=cap, decay_interval_seconds=0)
            stats = hm.stats()
            
            # Each slot is 4 bytes (float32) + overhead
            min_memory = stats['slots'] * 4
            actual_memory = stats['memory_bytes']
            
            # Actual should be >= minimum (plus overhead)
            assert actual_memory >= min_memory
            
            # But not more than 2x (reasonable overhead)
            assert actual_memory < min_memory * 2
            
            hm.stop()


# =============================================================================
# 6. FUZZING TESTS
# =============================================================================

class TestFuzzing:
    """Random input testing to find crashes."""
    
    @pytest.mark.parametrize("seed", range(100))
    def test_fuzz_random_items(self, seed):
        """Random items should never crash."""
        rng = random.Random(seed)
        hm = HeatMap(decay_interval_seconds=0)
        
        for _ in range(1000):
            # Random item
            item = ''.join(rng.choices(string.printable, k=rng.randint(0, 100)))
            
            # Random amount
            amount = rng.uniform(1e-10, 1e10)
            
            hm.add(item, amount=amount)
            hm.check(item)
        
        # Should complete without crash
    
    @pytest.mark.parametrize("seed", range(50))
    def test_fuzz_random_operations(self, seed):
        """Random sequence of operations should never crash."""
        rng = random.Random(seed)
        hm = HeatMap(
            half_life_seconds=rng.uniform(1, 100),
            decay_interval_seconds=rng.uniform(0.1, 10),
            track_candidates=True
        )
        
        items = [f"item_{i}" for i in range(100)]
        
        for _ in range(1000):
            op = rng.choice(['add', 'check', 'decay', 'top', 'stats'])
            
            if op == 'add':
                item = rng.choice(items)
                amount = rng.uniform(0.1, 100)
                hm.add(item, amount=amount)
            
            elif op == 'check':
                item = rng.choice(items)
                hm.check(item)
            
            elif op == 'decay':
                hm.decay()
            
            elif op == 'top':
                k = rng.randint(1, 50)
                hm.top(k)
            
            elif op == 'stats':
                hm.stats()
        
        hm.stop()
    
    def test_fuzz_hash_collisions(self):
        """Test behavior with many potential hash collisions."""
        hm = HeatMap(capacity=100, decay_interval_seconds=0)  # Small = more collisions
        
        # Add many items
        for i in range(10000):
            hm.add(f"item_{i}")
        
        # Check all still accessible
        for i in range(10000):
            heat = hm.check(f"item_{i}")
            assert heat >= 1.0  # Should have at least some heat
    
    def test_fuzz_rapid_decay(self):
        """Rapid decay cycles should not cause issues."""
        hm = HeatMap(
            half_life_seconds=0.001,
            decay_interval_seconds=0.001
        )
        
        # Rapid fire
        for i in range(10000):
            hm.add(f"item_{i % 100}")
            if i % 10 == 0:
                hm.decay()
        
        hm.stop()


# =============================================================================
# 7. LONG-RUNING STABILITY TESTS
# =============================================================================

class TestLongRunningStability:
    """Test behavior over extended operation."""
    
    def test_long_running_decay_stability(self):
        """Heat should decay smoothly over many cycles."""
        hm = HeatMap(
            half_life_seconds=10.0,
            decay_interval_seconds=0.1
        )
        
        hm.add("item", amount=10000.0)
        
        heats = []
        for _ in range(1000):
            heats.append(hm.check("item"))
            hm.decay()
            time.sleep(0.001)  # Tiny delay
        
        hm.stop()
        
        # Heat should monotonically decrease
        for i in range(len(heats) - 1):
            assert heats[i] >= heats[i+1], \
                f"Heat increased at step {i}: {heats[i]} -> {heats[i+1]}"
    
    def test_long_running_no_drift(self):
        """Decay factor should not drift over time."""
        hm = HeatMap(
            half_life_seconds=1.0,
            decay_interval_seconds=1.0
        )
        
        for _ in range(100):
            # Add heat and decay
            hm.add("item", amount=1000.0)
            hm.decay()
            
            # Decay factor should remain constant
            assert abs(hm.decay_factor - 0.5) < 1e-10
        
        hm.stop()
    
    def test_long_running_top_k_stability(self):
        """Top-k should remain stable over time."""
        hm = HeatMap(
            half_life_seconds=100.0,
            decay_interval_seconds=1.0,
            track_candidates=True
        )
        
        # Create clear ranking
        for i in range(100):
            hm.add(f"item_{i}", amount=float(100 - i) * 10)
        
        # Top should always have item_0 at top
        for _ in range(100):
            top = hm.top(10)
            assert top[0][0] == "item_0"
            hm.decay()
        
        hm.stop()


# =============================================================================
# 8. REAL-WORLD SCENARIOS
# =============================================================================

class TestRealWorldScenarios:
    """Test actual usage patterns."""
    
    def test_scenario_hashtag_trending(self):
        """Simulate hashtag trending on social media."""
        hm = HeatMap(
            half_life_seconds=300.0,  # 5 minutes
            decay_interval_seconds=10.0,
            track_candidates=True
        )
        
        hashtags = ["#news", "#sports", "#tech", "#politics", "#entertainment"]
        
        # Simulate 1 hour of activity
        for minute in range(60):
            # Random activity
            for _ in range(random.randint(100, 500)):
                tag = random.choice(hashtags)
                hm.add(tag)
            
            # Check trending every minute
            trending = hm.top(3)
            assert len(trending) <= 3
            
            # Decay happens automatically
            time.sleep(0.01)  # Simulate time passing
        
        hm.stop()
    
    def test_scenario_api_rate_limiting(self):
        """Simulate API rate limiting with decay."""
        hm = HeatMap(
            half_life_seconds=60.0,  # 1 minute window
            decay_interval_seconds=1.0
        )
        
        users = [f"user_{i}" for i in range(100)]
        rate_limit = 100.0
        
        # Simulate requests
        for _ in range(10000):
            user = random.choice(users)
            current_rate = hm.check(user)
            
            if current_rate < rate_limit:
                hm.add(user, amount=1.0)
                # Request allowed
            else:
                # Rate limited
                pass
        
        hm.stop()
    
    def test_scenario_cache_hit_tracking(self):
        """Simulate cache hit tracking with LRU-like decay."""
        hm = HierarchicalHeatMap(
            half_lives=(60.0, 3600.0, 86400.0),  # 1min, 1hr, 1day
            decay_interval_seconds=10.0
        )
        
        cache_keys = [f"key_{i}" for i in range(1000)]
        
        # Simulate cache access pattern (zipf-like)
        weights = [1.0 / (i + 1) for i in range(1000)]
        
        for _ in range(10000):
            key = random.choices(cache_keys, weights=weights)[0]
            hm.add(key)
        
        # Check combined heat
        for key in cache_keys[:10]:
            combined = hm.check(key)
            levels = hm.check_levels(key)
            
            # Combined should be weighted average of levels
            assert combined > 0
        
        hm.stop()
    
    def test_scenario_iot_sensor_aggregation(self):
        """Simulate IoT sensor data aggregation."""
        hm = HeatMap(
            half_life_seconds=30.0,
            decay_interval_seconds=5.0,
            track_candidates=True
        )
        
        sensors = [f"sensor_{i}" for i in range(50)]
        
        # Simulate sensor readings
        for _ in range(1000):
            for sensor in sensors:
                # Random reading
                reading = random.uniform(0, 100)
                hm.add(sensor, amount=reading)
        
        # Get top sensors (highest readings)
        top_sensors = hm.top(10)
        assert len(top_sensors) == 10
        
        hm.stop()


# =============================================================================
# 9. HIERARCHICAL HEATMAP TESTS
# =============================================================================

class TestHierarchicalPublication:
    """Publication-grade tests for HierarchicalHeatMap."""
    
    def test_hierarchical_levels_independent(self):
        """Each level should decay independently."""
        hm = HierarchicalHeatMap(
            half_lives=(1.0, 10.0, 100.0),
            decay_interval_seconds=1.0  # Non-zero for decay_factor < 1
        )
        
        hm.add("item", amount=1000.0)
        
        # Decay only shortest level 10 times
        # With half_life=1.0 and interval=1.0, decay_factor=0.5
        # After 10 decays: 1000 * 0.5^10 ≈ 0.98
        for _ in range(10):
            hm._levels[0].decay()
        
        levels = hm.check_levels("item")
        
        # Short level should be ~1 (10 decays with half-life=1)
        assert levels['short'] < 2.0
        
        # Medium and long should be unaffected (decay_factor ≈ 0.93 and 0.99)
        assert levels['medium'] > 900.0
        assert levels['long'] > 990.0
        
        hm.stop()
    
    def test_hierarchical_combined_formula(self):
        """Combined heat should match weighted average formula."""
        weights = (0.5, 0.3, 0.2)
        hm = HierarchicalHeatMap(
            half_lives=(10.0, 60.0, 300.0),
            weights=weights,
            decay_interval_seconds=0
        )
        
        hm.add("item", amount=100.0)
        
        levels = hm.check_levels("item")
        combined = hm.check("item")
        
        # Expected: weighted sum
        expected = (
            weights[0] * levels['short'] +
            weights[1] * levels['medium'] +
            weights[2] * levels['long']
        )
        
        assert abs(combined - expected) < 1e-10
    
    def test_hierarchical_weights_not_normalized(self):
        """Weights are NOT normalized - they scale the combined heat."""
        hm = HierarchicalHeatMap(
            half_lives=(10.0, 60.0),
            weights=(3.0, 1.0),  # Not normalized
            decay_interval_seconds=0
        )
        
        # Should work without error
        hm.add("item", amount=100.0)
        
        stats = hm.stats()
        # Weights are stored as-is (not normalized)
        assert stats['weights'] == (3.0, 1.0)
        
        # Combined heat is scaled by weights
        levels = hm.check_levels("item")
        combined = hm.check("item")
        
        # Combined = 3 * short + 1 * medium
        expected = 3.0 * levels['short'] + 1.0 * levels['medium']
        assert abs(combined - expected) < 1e-10
        
        hm.stop()


# =============================================================================
# RUNNER
# =============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s", "--tb=short"])
