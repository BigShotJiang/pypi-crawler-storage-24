"""Tests for TrendingBloom"""

import pytest
import time
import sys
sys.path.insert(0, 'src')

from trending_bloom import TrendingBloom, TrendingBloomWithCandidates


class TestTrendingBloom:
    
    def test_basic_add_check(self):
        """Adding an item should make it detectable."""
        tbf = TrendingBloom(capacity=1000)
        tbf.add("hello")
        assert tbf.check("hello") >= 1
        assert tbf.check("not_added") == 0
    
    def test_multiple_adds_increase_count(self):
        """Multiple adds should increase the count."""
        tbf = TrendingBloom(capacity=1000, decay_interval=0)  # No auto-decay
        
        for i in range(10):
            tbf.add("item")
        
        assert tbf.check("item") >= 10
    
    def test_decay_reduces_counts(self):
        """Decay should reduce all counts."""
        tbf = TrendingBloom(capacity=1000, decay_rate=0.5, decay_interval=0)
        
        tbf.add("item", count=100)
        assert tbf.check("item") >= 100
        
        tbf.decay()
        assert tbf.check("item") >= 50  # Should be roughly halved
    
    def test_decay_to_zero(self):
        """Repeated decay should eventually zero out."""
        tbf = TrendingBloom(capacity=1000, decay_rate=0.5, decay_interval=0)
        
        tbf.add("item", count=1)
        
        for _ in range(20):
            tbf.decay()
        
        assert tbf.check("item") == 0
    
    def test_different_items_different_positions(self):
        """Different items should (likely) have different counts."""
        tbf = TrendingBloom(capacity=10000, decay_interval=0)
        
        tbf.add("apple", count=10)
        tbf.add("banana", count=20)
        tbf.add("cherry", count=30)
        
        # They shouldn't all have the same count due to hash collisions
        # (with high probability on a decent-sized filter)
        counts = [tbf.check(x) for x in ["apple", "banana", "cherry"]]
        assert counts[0] >= 10
        assert counts[1] >= 20
        assert counts[2] >= 30
    
    def test_stats(self):
        """Stats should return useful info."""
        tbf = TrendingBloom(capacity=1000)
        stats = tbf.stats()
        
        assert 'total_slots' in stats
        assert 'hash_functions' in stats
        assert 'memory_bytes' in stats
        assert stats['total_slots'] > 0
    
    def test_reset(self):
        """Reset should clear all counts."""
        tbf = TrendingBloom(capacity=1000, decay_interval=0)
        
        tbf.add("item1", count=100)
        tbf.add("item2", count=200)
        
        tbf.reset()
        
        assert tbf.check("item1") == 0
        assert tbf.check("item2") == 0


class TestTrendingBloomWithCandidates:
    
    def test_candidate_tracking(self):
        """Should track candidates and return trending items."""
        tbf = TrendingBloom(capacity=1000, decay_interval=0)
        wrapper = TrendingBloomWithCandidates(tbf)
        
        wrapper.add("trending_item", count=100)
        wrapper.add("less_popular", count=10)
        wrapper.add("barely_there", count=1)
        
        trending = wrapper.get_trending(threshold=5)
        
        assert len(trending) >= 2
        assert trending[0][0] == "trending_item"
        assert trending[0][1] >= 100
    
    def test_threshold_filtering(self):
        """Threshold should filter out low-count items."""
        tbf = TrendingBloom(capacity=1000, decay_interval=0)
        wrapper = TrendingBloomWithCandidates(tbf)
        
        wrapper.add("high", count=100)
        wrapper.add("low", count=5)
        
        trending = wrapper.get_trending(threshold=50)
        
        items = [item for item, _ in trending]
        assert "high" in items
        assert "low" not in items
    
    def test_prune_candidates(self):
        """Pruning should remove old candidates."""
        tbf = TrendingBloom(capacity=1000, decay_interval=0)
        wrapper = TrendingBloomWithCandidates(tbf)
        
        wrapper.add("old_item")
        time.sleep(0.1)
        
        removed = wrapper.prune_candidates(max_age_seconds=0.05)
        
        assert removed >= 1
        assert "old_item" not in wrapper.candidates


class TestPerformance:
    """Performance characteristics tests."""
    
    def test_add_is_fast(self, benchmark):
        """Add should be very fast."""
        tbf = TrendingBloom(capacity=1_000_000, decay_interval=0)
        
        def add_items():
            for i in range(100):
                tbf.add(f"item_{i}")
        
        benchmark(add_items)
    
    def test_add_many_is_fast(self, benchmark):
        """Bulk add should be very fast."""
        tbf = TrendingBloom(capacity=1_000_000, decay_interval=0)
        items = [f"item_{i}" for i in range(100)]
        
        benchmark(lambda: tbf.add_many(items))
    
    def test_check_is_fast(self, benchmark):
        """Check should be very fast."""
        tbf = TrendingBloom(capacity=1_000_000, decay_interval=0)
        
        for i in range(1000):
            tbf.add(f"item_{i}")
        
        def check_items():
            for i in range(100):
                tbf.check(f"item_{i}")
        
        benchmark(check_items)
    
    def test_check_many_is_fast(self, benchmark):
        """Bulk check should be very fast."""
        tbf = TrendingBloom(capacity=1_000_000, decay_interval=0)
        
        for i in range(1000):
            tbf.add(f"item_{i}")
        
        items = [f"item_{i}" for i in range(100)]
        benchmark(lambda: tbf.check_many(items))
    
    def test_decay_is_fast(self, benchmark):
        """Decay should be fast even with many slots."""
        tbf = TrendingBloom(capacity=1_000_000, decay_interval=0)
        
        # Add some data
        for i in range(10000):
            tbf.add(f"item_{i}")
        
        benchmark(tbf.decay)
