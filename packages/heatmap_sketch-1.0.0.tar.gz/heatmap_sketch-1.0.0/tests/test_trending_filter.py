"""Tests for TrendingFilter"""

import pytest
import time
import sys
sys.path.insert(0, 'src')

from trending_filter import TrendingFilter, SlidingWindowTrendingFilter, TrendingItem


class TestTrendingFilter:
    
    def test_basic_add_check(self):
        """Adding an item should make it detectable."""
        tf = TrendingFilter(top_n=10, decay_interval_seconds=0)  # No auto-decay
        tf.add("hello")
        raw, decayed = tf.check("hello")
        assert raw >= 1
        assert decayed >= 1
    
    def test_multiple_adds_increase_count(self):
        """Multiple adds should increase the count."""
        tf = TrendingFilter(top_n=10, decay_interval_seconds=0)
        
        for _ in range(10):
            tf.add("item")
        
        raw, decayed = tf.check("item")
        assert raw >= 10
        assert decayed >= 10
    
    def test_add_many(self):
        """Bulk add should work."""
        tf = TrendingFilter(top_n=10, decay_interval_seconds=0)
        items = [f"item_{i}" for i in range(100)]
        
        tf.add_many(items)
        
        raw, _ = tf.check("item_50")
        assert raw >= 1
    
    def test_get_trending(self):
        """get_trending should return top items sorted by heat."""
        tf = TrendingFilter(top_n=5, decay_interval_seconds=0)
        
        tf.add("low", count=1)
        tf.add("medium", count=10)
        tf.add("high", count=100)
        
        trending = tf.get_trending()
        
        assert len(trending) <= 5
        assert trending[0][0] == "high"  # Highest first
    
    def test_decay_reduces_count(self):
        """Decay should reduce counts."""
        tf = TrendingFilter(top_n=10, decay_factor=0.5, decay_interval_seconds=0)
        
        tf.add("item", count=100)
        _, decayed_before = tf.check("item")
        
        tf.decay()
        _, decayed_after = tf.check("item")
        
        assert decayed_after < decayed_before
    
    def test_competitive_displacement(self):
        """New hot items should displace old cold items."""
        tf = TrendingFilter(top_n=3, decay_factor=0.5, decay_interval_seconds=0)
        
        # Add old items
        tf.add("old1", count=10)
        tf.add("old2", count=10)
        tf.add("old3", count=10)
        
        # Decay them
        tf.decay()
        tf.decay()
        tf.decay()
        
        # Add new hot item
        tf.add("new_hot", count=100)
        
        trending = tf.get_trending()
        items = [t[0] for t in trending]
        
        # New hot item should be on top
        assert "new_hot" in items
    
    def test_top_n_limit(self):
        """Should track at most top_n items in get_trending."""
        tf = TrendingFilter(top_n=3, decay_interval_seconds=0)
        
        for i in range(100):
            tf.add(f"item_{i}", count=i)
        
        trending = tf.get_trending()
        assert len(trending) <= 3
    
    def test_reset(self):
        """Reset should clear all data."""
        tf = TrendingFilter(top_n=10, decay_interval_seconds=0)
        
        tf.add("item1", count=100)
        tf.add("item2", count=200)
        
        tf.reset()
        
        raw, _ = tf.check("item1")
        assert raw == 0
        
        trending = tf.get_trending()
        assert len(trending) == 0
    
    def test_thread_safety(self):
        """Should be safe for concurrent access."""
        import threading
        
        tf = TrendingFilter(top_n=10, decay_interval_seconds=0)
        errors = []
        
        def add_items(start, count):
            try:
                for i in range(start, start + count):
                    tf.add(f"item_{i}")
            except Exception as e:
                errors.append(e)
        
        threads = [
            threading.Thread(target=add_items, args=(i * 1000, 1000))
            for i in range(10)
        ]
        
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        assert len(errors) == 0
    
    def test_auto_decay(self):
        """Auto-decay thread should run automatically."""
        tf = TrendingFilter(
            top_n=10,
            decay_factor=0.5,
            decay_interval_seconds=0.1  # Fast decay for test
        )
        
        tf.add("item", count=100)
        _, decayed_before = tf.check("item")
        
        time.sleep(0.3)  # Let decay run
        
        _, decayed_after = tf.check("item")
        
        tf.stop()
        
        assert decayed_after < decayed_before


class TestSlidingWindowTrendingFilter:
    
    def test_basic_add_check(self):
        """Basic add/check should work."""
        tf = SlidingWindowTrendingFilter(
            top_n=10,
            num_windows=3,
            window_seconds=1.0
        )
        
        tf.add("hello")
        raw, _ = tf.check("hello")
        
        tf.stop()
        assert raw >= 1
    
    def test_window_rotation(self):
        """Windows should rotate and clear old data."""
        tf = SlidingWindowTrendingFilter(
            top_n=10,
            num_windows=2,
            window_seconds=0.2  # Fast rotation
        )
        
        tf.add("item", count=100)
        
        time.sleep(0.5)  # Wait for rotation
        
        # Old data should be cleared from one window
        # but still exist in aggregated view briefly
        
        tf.stop()
    
    def test_get_trending(self):
        """get_trending should aggregate across windows."""
        tf = SlidingWindowTrendingFilter(
            top_n=10,
            num_windows=3,
            window_seconds=10.0  # Slow for test
        )
        
        tf.add("high", count=100)
        tf.add("medium", count=50)
        tf.add("low", count=10)
        
        trending = tf.get_trending()
        
        tf.stop()
        
        assert len(trending) <= 10
        if len(trending) > 0:
            assert trending[0][0] == "high"


class TestPerformance:
    """Performance benchmarks."""
    
    def test_add_performance(self, benchmark):
        """Single add should be fast."""
        tf = TrendingFilter(top_n=10, decay_interval_seconds=0)
        
        def add_items():
            for i in range(100):
                tf.add(f"item_{i}")
        
        benchmark(add_items)
        tf.stop()
    
    def test_add_many_performance(self, benchmark):
        """Bulk add should be very fast."""
        tf = TrendingFilter(top_n=10, decay_interval_seconds=0)
        items = [f"item_{i}" for i in range(1000)]
        
        benchmark(lambda: tf.add_many(items))
        tf.stop()
    
    def test_check_performance(self, benchmark):
        """Check should be fast."""
        tf = TrendingFilter(top_n=10, decay_interval_seconds=0)
        
        for i in range(1000):
            tf.add(f"item_{i}")
        
        def check_items():
            for i in range(100):
                tf.check(f"item_{i}")
        
        benchmark(check_items)
        tf.stop()
    
    def test_get_trending_performance(self, benchmark):
        """get_trending should be fast."""
        tf = TrendingFilter(top_n=10, decay_interval_seconds=0)
        
        for i in range(1000):
            tf.add(f"item_{i}", count=i)
        
        benchmark(tf.get_trending)
        tf.stop()
    
    def test_decay_performance(self, benchmark):
        """Decay should be fast."""
        tf = TrendingFilter(top_n=100, decay_interval_seconds=0)
        
        for i in range(10000):
            tf.add(f"item_{i}")
        
        benchmark(tf.decay)
        tf.stop()
