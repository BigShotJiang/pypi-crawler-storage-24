"""
Tests for HeatMap data structure.

Run with: pytest tests/test_heatmap.py -v
"""

from __future__ import annotations

import time
import threading
import pytest
import sys
import os

# Add src to path for testing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from heatmap_sketch import HeatMap, HierarchicalHeatMap
from heatmap_sketch.heatmap import HeatMapError, HeatMapCapacityError


class TestHeatMapInit:
    """Test HeatMap initialization and validation."""
    
    def test_default_init(self):
        """Default parameters should work."""
        hm = HeatMap()
        assert hm.m > 0
        assert hm.k > 0
        assert hm.half_life == 60.0
        hm.stop()
    
    def test_custom_init(self):
        """Custom parameters should be accepted."""
        hm = HeatMap(
            capacity=100_000,
            error_rate=0.001,
            half_life_seconds=30.0,
            decay_interval_seconds=5.0,
            seed=42
        )
        assert hm.half_life == 30.0
        assert hm.decay_interval == 5.0
        hm.stop()
    
    def test_capacity_too_small(self):
        """Should reject capacity < 10."""
        with pytest.raises(HeatMapCapacityError):
            HeatMap(capacity=5)
    
    def test_error_rate_too_high(self):
        """Should reject error_rate >= 0.5."""
        with pytest.raises(HeatMapCapacityError):
            HeatMap(error_rate=0.6)
    
    def test_error_rate_too_low(self):
        """Should reject error_rate <= 1e-6."""
        with pytest.raises(HeatMapCapacityError):
            HeatMap(error_rate=1e-7)
    
    def test_half_life_must_be_positive(self):
        """Should reject non-positive half_life."""
        with pytest.raises(ValueError):
            HeatMap(half_life_seconds=0)
        
        with pytest.raises(ValueError):
            HeatMap(half_life_seconds=-1.0)
    
    def test_decay_interval_must_be_non_negative(self):
        """Should reject negative decay_interval."""
        with pytest.raises(ValueError):
            HeatMap(decay_interval_seconds=-1.0)


class TestHeatMapBasicOperations:
    """Test basic add/check operations."""
    
    def test_basic_add_check(self):
        """Adding an item should make it detectable."""
        hm = HeatMap(decay_interval_seconds=0)
        hm.add("hello")
        assert hm.check("hello") >= 1.0
    
    def test_add_increases_heat(self):
        """Multiple adds should increase heat."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add("item", amount=10.0)
        before = hm.check("item")
        
        hm.add("item", amount=5.0)
        after = hm.check("item")
        
        assert after > before
    
    def test_add_many(self):
        """Bulk add should work."""
        hm = HeatMap(decay_interval_seconds=0)
        items = [f"item_{i}" for i in range(100)]
        
        hm.add_many(items, amount=2.0)
        
        assert hm.check("item_50") >= 2.0
    
    def test_check_nonexistent(self):
        """Checking non-existent item should return 0 or near 0."""
        hm = HeatMap(decay_interval_seconds=0)
        
        # Should be very low (maybe not exactly 0 due to hash collisions)
        heat = hm.check("never_added")
        assert heat < 1.0
    
    def test_add_invalid_amount(self):
        """Should reject non-positive amounts."""
        hm = HeatMap(decay_interval_seconds=0)
        
        with pytest.raises(ValueError):
            hm.add("item", amount=0)
        
        with pytest.raises(ValueError):
            hm.add("item", amount=-1.0)
    
    def test_context_manager(self):
        """Context manager should work."""
        with HeatMap() as hm:
            hm.add("item")
            assert hm.check("item") >= 1.0
        # Should be stopped after exit


class TestHeatMapDecay:
    """Test decay functionality."""
    
    def test_decay_reduces_heat(self):
        """Decay should reduce heat values."""
        hm = HeatMap(
            half_life_seconds=10.0,
            decay_interval_seconds=1.0
        )
        
        hm.add("item", amount=100.0)
        before = hm.check("item")
        
        hm.decay()
        after = hm.check("item")
        
        hm.stop()
        
        assert after < before
    
    def test_decay_factor_calculation(self):
        """Decay factor should match half-life formula."""
        # With half_life=1s and decay_interval=1s, decay_factor should be 0.5
        hm = HeatMap(
            half_life_seconds=1.0,
            decay_interval_seconds=1.0
        )
        assert abs(hm.decay_factor - 0.5) < 0.01
        hm.stop()
    
    def test_auto_decay(self):
        """Auto-decay thread should work."""
        hm = HeatMap(
            half_life_seconds=0.5,
            decay_interval_seconds=0.1
        )
        
        hm.add("item", amount=100.0)
        before = hm.check("item")
        
        time.sleep(0.5)  # Let decay run
        
        after = hm.check("item")
        
        hm.stop()
        
        assert after < before
    
    def test_manual_decay(self):
        """Manual decay should work when auto-decay is disabled."""
        # Must use positive decay_interval for decay_factor < 1
        hm = HeatMap(
            half_life_seconds=10.0,
            decay_interval_seconds=1.0
        )
        
        hm.add("item", amount=100.0)
        before = hm.check("item")
        
        hm.decay()
        after = hm.check("item")
        
        hm.stop()
        
        assert after < before


class TestHeatMapTopK:
    """Test top-k functionality."""
    
    def test_top_k(self):
        """top() should return hottest items."""
        hm = HeatMap(decay_interval_seconds=0, track_candidates=True)
        
        hm.add("low", amount=1.0)
        hm.add("medium", amount=10.0)
        hm.add("high", amount=100.0)
        
        top = hm.top(3)
        
        assert len(top) == 3
        assert top[0][0] == "high"  # Hottest first
        assert top[0][1] >= 100.0
    
    def test_top_k_empty(self):
        """top() on empty HeatMap should return empty list."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        
        top = hm.top(10)
        
        assert top == []
    
    def test_top_k_without_tracking_raises(self):
        """top() without candidate tracking should raise."""
        hm = HeatMap(track_candidates=False, decay_interval_seconds=0)
        hm.add("item")
        
        with pytest.raises(RuntimeError):
            hm.top(10)
    
    def test_top_k_invalid_k(self):
        """top() with invalid k should raise."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        
        with pytest.raises(ValueError):
            hm.top(0)
        
        with pytest.raises(ValueError):
            hm.top(-1)


class TestHeatMapIsHot:
    """Test is_hot functionality."""
    
    def test_is_hot_above_threshold(self):
        """is_hot should return True for hot items."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add("hot", amount=100.0)
        
        assert hm.is_hot("hot", threshold=50.0) is True
    
    def test_is_hot_below_threshold(self):
        """is_hot should return False for cold items."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add("cold", amount=1.0)
        
        assert hm.is_hot("cold", threshold=50.0) is False
    
    def test_is_hot_invalid_threshold(self):
        """is_hot with negative threshold should raise."""
        hm = HeatMap(decay_interval_seconds=0)
        
        with pytest.raises(ValueError):
            hm.is_hot("item", threshold=-1.0)


class TestHeatMapStats:
    """Test statistics functionality."""
    
    def test_stats_returns_dict(self):
        """stats() should return a dictionary."""
        hm = HeatMap()
        stats = hm.stats()
        
        assert isinstance(stats, dict)
        hm.stop()
    
    def test_stats_has_required_keys(self):
        """stats() should have required keys."""
        hm = HeatMap()
        stats = hm.stats()
        
        required_keys = [
            'slots', 'hash_functions', 'half_life_seconds',
            'nonzero_slots', 'max_heat', 'memory_bytes'
        ]
        
        for key in required_keys:
            assert key in stats
        
        hm.stop()


class TestHeatMapThreadSafety:
    """Test thread safety."""
    
    def test_concurrent_adds(self):
        """Should handle concurrent adds."""
        hm = HeatMap(decay_interval_seconds=0)
        errors = []
        
        def add_items(start, count):
            try:
                for i in range(start, start + count):
                    hm.add(f"item_{i}")
            except Exception as e:
                errors.append(e)
        
        threads = [
            threading.Thread(target=add_items, args=(i * 1000, 1000))
            for i in range(10)
        ]
        
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        assert len(errors) == 0


class TestHeatMapSpecialMethods:
    """Test special methods."""
    
    def test_len(self):
        """len() should return candidate count."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        
        hm.add("item1")
        hm.add("item2")
        
        assert len(hm) == 2
    
    def test_contains(self):
        """in operator should work."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add("item")
        
        assert "item" in hm
        assert "not_added" not in hm
    
    def test_repr(self):
        """repr() should be informative."""
        hm = HeatMap()
        r = repr(hm)
        
        assert "HeatMap" in r
        assert "m=" in r
        hm.stop()


class TestHierarchicalHeatMap:
    """Test HierarchicalHeatMap."""
    
    def test_default_init(self):
        """Default parameters should work."""
        hm = HierarchicalHeatMap()
        assert hm.num_levels == 3
        hm.stop()
    
    def test_check_levels(self):
        """check_levels() should return heat at each level."""
        hm = HierarchicalHeatMap(
            half_lives=(1.0, 10.0, 100.0),
            decay_interval_seconds=0
        )
        
        hm.add("item", amount=10.0)
        
        levels = hm.check_levels("item")
        
        assert 'short' in levels
        assert 'medium' in levels
        assert 'long' in levels
    
    def test_combined_heat(self):
        """check() should return combined heat."""
        hm = HierarchicalHeatMap(
            half_lives=(10.0, 100.0),
            weights=(0.5, 0.5),
            decay_interval_seconds=0
        )
        
        hm.add("item", amount=10.0)
        
        combined = hm.check("item")
        levels = hm.check_levels("item")
        
        expected = 0.5 * levels['short'] + 0.5 * levels['medium']
        assert abs(combined - expected) < 1e-6
    
    def test_invalid_weights(self):
        """Should reject invalid weights."""
        with pytest.raises(ValueError):
            HierarchicalHeatMap(weights=(1.0, 2.0))  # Wrong length
        
        with pytest.raises(ValueError):
            HierarchicalHeatMap(weights=(-1.0, 2.0))  # Negative
    
    def test_empty_half_lives(self):
        """Should reject empty half_lives."""
        with pytest.raises(ValueError):
            HierarchicalHeatMap(half_lives=())


class TestPerformance:
    """Performance benchmarks."""
    
    def test_add_performance(self, benchmark):
        """Single add should be fast."""
        hm = HeatMap(decay_interval_seconds=0)
        
        def add_items():
            for i in range(100):
                hm.add(f"item_{i}")
        
        benchmark(add_items)
        hm.stop()
    
    def test_add_many_performance(self, benchmark):
        """Bulk add should be fast."""
        hm = HeatMap(decay_interval_seconds=0)
        items = [f"item_{i}" for i in range(1000)]
        
        benchmark(lambda: hm.add_many(items))
        hm.stop()
    
    def test_check_performance(self, benchmark):
        """Check should be fast."""
        hm = HeatMap(decay_interval_seconds=0)
        
        for i in range(1000):
            hm.add(f"item_{i}")
        
        def check_items():
            for i in range(100):
                hm.check(f"item_{i}")
        
        benchmark(check_items)
        hm.stop()
    
    def test_top_k_performance(self, benchmark):
        """top-k should be fast."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        
        for i in range(1, 1001):  # Start from 1 to avoid amount=0
            hm.add(f"item_{i}", amount=float(i))
        
        benchmark(lambda: hm.top(10))
        hm.stop()
