"""
Additional comprehensive tests for HeatMap data structure.

Tests edge cases, stress tests, thread safety, and error paths.
Run with: pytest tests/test_heatmap_extra.py -v
"""

from __future__ import annotations

import gc
import time
import threading
import pytest
import sys
import os
import weakref

# Add src to path for testing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from heatmap_sketch import HeatMap, HierarchicalHeatMap
from heatmap_sketch.heatmap import HeatMapError, HeatMapCapacityError


class TestHeatMapPartialInit:
    """Test handling of partial initialization (error paths)."""
    
    def test_stop_on_invalid_capacity(self):
        """stop() should not crash even if __init__ fails early."""
        with pytest.raises(HeatMapCapacityError):
            hm = HeatMap(capacity=1)  # Too small
        
        # Force garbage collection - should not crash
        gc.collect()
    
    def test_stop_on_invalid_error_rate(self):
        """stop() should not crash after invalid error_rate."""
        with pytest.raises(HeatMapCapacityError):
            hm = HeatMap(error_rate=0.99)  # Too high
        
        gc.collect()
    
    def test_stop_on_invalid_half_life(self):
        """stop() should not crash after invalid half_life."""
        with pytest.raises(ValueError):
            hm = HeatMap(half_life_seconds=0)
        
        gc.collect()
    
    def test_del_on_failed_init(self):
        """__del__ should be safe after __init__ exception."""
        # Create a weakref to track object lifecycle
        with pytest.raises(HeatMapCapacityError):
            obj = HeatMap(capacity=1)
        
        # GC should not crash
        gc.collect()
    
    def test_stop_without_decay_thread(self):
        """stop() should work when decay thread was never started."""
        hm = HeatMap(decay_interval_seconds=0)  # No decay thread
        hm.stop()  # Should be safe
        hm.stop()  # Calling twice should also be safe


class TestHeatMapReset:
    """Test reset() functionality."""
    
    def test_reset_clears_heat(self):
        """reset() should clear all heat values."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add("item1", amount=100.0)
        hm.add("item2", amount=50.0)
        
        assert hm.check("item1") >= 100.0
        assert hm.check("item2") >= 50.0
        
        hm.reset()
        
        assert hm.check("item1") < 1.0
        assert hm.check("item2") < 1.0
    
    def test_reset_clears_candidates(self):
        """reset() should clear candidate tracking."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        
        hm.add("item1")
        hm.add("item2")
        
        assert len(hm) == 2
        
        hm.reset()
        
        assert len(hm) == 0
        assert hm.top(10) == []
    
    def test_reset_idempotent(self):
        """reset() should be safe to call multiple times."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add("item")
        hm.reset()
        hm.reset()
        hm.reset()
        
        assert hm.check("item") < 1.0


class TestHeatMapDecayEdgeCases:
    """Test decay behavior at edge cases."""
    
    def test_very_short_half_life(self):
        """Very short half-life with manual decay should decay quickly."""
        # Use manual decay to avoid thread timing issues
        hm = HeatMap(
            half_life_seconds=0.1,  # 100ms
            decay_interval_seconds=0.05  # 50ms -> decay_factor = 0.707
        )
        
        hm.add("item", amount=1000.0)
        
        # Manual decays to test behavior precisely
        for _ in range(10):
            hm.decay()
        
        after = hm.check("item")
        hm.stop()
        
        # Decay factor = 0.5^(0.05/0.1) ≈ 0.707
        # After 10 manual decays: 1000 * 0.707^10 ≈ 25
        expected = 1000 * (0.5 ** 0.5) ** 10
        assert abs(after - expected) < 10  # Allow for small numerical errors
    
    def test_auto_decay_thread_works(self):
        """Verify auto-decay thread actually runs."""
        hm = HeatMap(
            half_life_seconds=0.5,
            decay_interval_seconds=0.1
        )
        
        hm.add("item", amount=100.0)
        initial = hm.check("item")
        
        # Wait and let auto-decay run
        time.sleep(1.5)  # Should be ~15 decay cycles
        
        after = hm.check("item")
        hm.stop()
        
        # Should have decayed (being lenient about exact timing)
        assert after < initial
    
    def test_very_long_half_life(self):
        """Very long half-life should decay slowly."""
        hm = HeatMap(
            half_life_seconds=3600,  # 1 hour
            decay_interval_seconds=1.0
        )
        
        hm.add("item", amount=100.0)
        before = hm.check("item")
        
        time.sleep(2)
        
        after = hm.check("item")
        hm.stop()
        
        # After 2 seconds with 1-hour half-life, decay should be minimal
        assert after > before * 0.99
    
    def test_zero_decay_interval_no_auto_decay(self):
        """decay_interval=0 should disable auto-decay."""
        hm = HeatMap(
            half_life_seconds=0.1,
            decay_interval_seconds=0
        )
        
        hm.add("item", amount=100.0)
        before = hm.check("item")
        
        time.sleep(0.5)  # Would decay significantly if auto-decay was on
        
        after = hm.check("item")
        
        # Should be unchanged (no auto-decay)
        assert abs(after - before) < 0.1
    
    def test_manual_decay_multiple_times(self):
        """Multiple manual decays should compound."""
        # Need non-zero decay_interval for decay_factor < 1
        hm = HeatMap(
            half_life_seconds=1.0,
            decay_interval_seconds=1.0  # Same as half-life = 0.5 factor
        )
        
        hm.add("item", amount=100.0)
        
        for _ in range(5):
            hm.decay()
        
        after = hm.check("item")
        
        # After 5 decays with 0.5 factor each: 100 * 0.5^5 = 3.125
        assert 2 < after < 5
        
        hm.stop()
    
    def test_decay_removes_cold_candidates(self):
        """Decay should remove candidates with very low heat."""
        hm = HeatMap(
            half_life_seconds=0.01,
            decay_interval_seconds=0.005,
            track_candidates=True
        )
        
        hm.add("cold", amount=1.0)  # Will decay to near-zero quickly
        hm.add("hot", amount=10000.0)  # Will stay hot
        
        time.sleep(0.2)  # Let decay run
        
        candidates = hm.top(100)
        hm.stop()
        
        # Cold item should have been removed
        items = [item for item, _ in candidates]
        assert "hot" in items
        # "cold" might be there but with very low heat


class TestHeatMapTopKEdgeCases:
    """Test top-k with edge cases."""
    
    def test_top_k_more_than_candidates(self):
        """top(k) where k > candidates should return all candidates."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        
        hm.add("item1")
        hm.add("item2")
        
        top = hm.top(100)
        
        assert len(top) == 2
    
    def test_top_k_with_equal_heat(self):
        """top-k should handle items with equal heat."""
        hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
        
        for i in range(10):
            hm.add(f"item_{i}", amount=10.0)
        
        top = hm.top(5)
        
        assert len(top) == 5
        # All should have similar heat
        heats = [heat for _, heat in top]
        assert all(9.0 < h < 11.0 for h in heats)
    
    def test_top_k_after_decay(self):
        """top-k should reflect decayed values."""
        hm = HeatMap(
            half_life_seconds=10.0,
            decay_interval_seconds=1.0,
            track_candidates=True
        )
        
        hm.add("hot", amount=1000.0)
        hm.add("cold", amount=10.0)
        
        time.sleep(3)  # Let decay run
        
        top = hm.top(10)
        hm.stop()
        
        # Order should be preserved
        assert len(top) >= 1
        assert top[0][0] == "hot"


class TestHeatMapThreadSafetyStress:
    """Stress test thread safety."""
    
    def test_concurrent_add_check_decay(self):
        """Should handle concurrent adds, checks, and decays."""
        hm = HeatMap(
            half_life_seconds=10.0,
            decay_interval_seconds=0.01,  # Very frequent decay
            track_candidates=True
        )
        
        errors = []
        operations = []
        
        def adder():
            try:
                for i in range(1000):
                    hm.add(f"item_{i % 100}", amount=1.0)
                    operations.append('add')
            except Exception as e:
                errors.append(e)
        
        def checker():
            try:
                for i in range(1000):
                    heat = hm.check(f"item_{i % 100}")
                    operations.append('check')
            except Exception as e:
                errors.append(e)
        
        def top_ker():
            try:
                for _ in range(100):
                    hm.top(10)
                    operations.append('top')
            except Exception as e:
                errors.append(e)
        
        threads = [
            threading.Thread(target=adder),
            threading.Thread(target=adder),
            threading.Thread(target=checker),
            threading.Thread(target=checker),
            threading.Thread(target=top_ker),
        ]
        
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        hm.stop()
        
        assert len(errors) == 0, f"Errors: {errors}"
        assert len(operations) > 4000  # All operations should complete
    
    def test_concurrent_stop(self):
        """Concurrent stop() calls should be safe."""
        hm = HeatMap(half_life_seconds=60.0, decay_interval_seconds=0.1)
        
        errors = []
        
        def stopper():
            try:
                hm.stop()
            except Exception as e:
                errors.append(e)
        
        threads = [threading.Thread(target=stopper) for _ in range(10)]
        
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        assert len(errors) == 0
    
    def test_add_during_decay(self):
        """Adds during decay should not be lost."""
        hm = HeatMap(
            half_life_seconds=1000.0,  # Slow decay
            decay_interval_seconds=0.01,
            track_candidates=True
        )
        
        total_adds = [0]
        lock = threading.Lock()
        
        def adder(thread_id):
            for i in range(500):
                # Each thread adds unique items: thread_0 adds 0-499, thread_1 adds 500-999, etc.
                hm.add(f"item_{thread_id * 500 + i}", amount=10.0)
                with lock:
                    total_adds[0] += 1
        
        threads = [
            threading.Thread(target=adder, args=(i,))
            for i in range(4)
        ]
        
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        # All 2000 unique items should exist
        assert len(hm.top(3000)) == 2000
        
        hm.stop()


class TestHeatMapLargeScale:
    """Test with large numbers of items."""
    
    def test_large_number_of_unique_items(self):
        """Should handle millions of unique items."""
        hm = HeatMap(
            capacity=10_000_000,
            decay_interval_seconds=0,
            track_candidates=True
        )
        
        # Add 1M items in batches
        batch_size = 10000
        for batch in range(100):
            items = [f"item_{batch * batch_size + i}" for i in range(batch_size)]
            hm.add_many(items)
        
        # Check some items
        assert hm.check("item_0") >= 1.0
        assert hm.check("item_500000") >= 1.0
        assert hm.check("item_999999") >= 1.0
        
        # Top-k should work
        top = hm.top(10)
        assert len(top) == 10
    
    def test_large_heat_values(self):
        """Should handle very large heat values."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add("item", amount=1e12)  # 1 trillion
        
        heat = hm.check("item")
        assert heat >= 1e12 * 0.5  # Should be close to 1 trillion
    
    def test_small_heat_values(self):
        """Should handle very small heat values."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add("item", amount=1e-6)  # Very small
        
        heat = hm.check("item")
        assert heat > 0  # Should still be detectable
    
    def test_rapid_adds(self):
        """Should handle rapid successive adds."""
        hm = HeatMap(decay_interval_seconds=0)
        
        start = time.time()
        for i in range(100000):
            hm.add(f"item_{i % 1000}")
        elapsed = time.time() - start
        
        # Should be fast
        assert elapsed < 5.0  # 100K adds in under 5 seconds


class TestHeatMapHashBehavior:
    """Test hash function behavior."""
    
    def test_same_item_same_positions(self):
        """Same item should always hash to same positions."""
        hm = HeatMap(decay_interval_seconds=0)
        
        pos1 = hm._hash_positions("test_item")
        pos2 = hm._hash_positions("test_item")
        
        assert all(pos1 == pos2)
    
    def test_different_items_different_positions(self):
        """Different items should (usually) hash to different positions."""
        hm = HeatMap(decay_interval_seconds=0)
        
        pos1 = hm._hash_positions("item1")
        pos2 = hm._hash_positions("item2")
        pos3 = hm._hash_positions("item3")
        
        # Very unlikely all positions are identical
        assert not (all(pos1 == pos2) and all(pos2 == pos3))
    
    def test_unicode_items(self):
        """Should handle unicode strings."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add("日本語")
        hm.add("🎉")
        hm.add("café")
        
        assert hm.check("日本語") >= 1.0
        assert hm.check("🎉") >= 1.0
        assert hm.check("café") >= 1.0
    
    def test_numeric_items(self):
        """Should handle numeric items."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add(123)
        hm.add(3.14)
        
        assert hm.check(123) >= 1.0
        assert hm.check(3.14) >= 1.0
    
    def test_bytes_items(self):
        """Should handle bytes items."""
        hm = HeatMap(decay_interval_seconds=0)
        
        hm.add(b"bytes_item")
        
        # Will be converted to string representation
        heat = hm.check(b"bytes_item")
        assert heat >= 1.0


class TestHeatMapStatsDetailed:
    """Detailed stats tests."""
    
    def test_stats_after_operations(self):
        """Stats should reflect operations."""
        hm = HeatMap(decay_interval_seconds=0)
        
        stats1 = hm.stats()
        assert stats1['nonzero_slots'] == 0
        assert stats1['max_heat'] == 0.0
        
        hm.add("item1", amount=100.0)
        
        stats2 = hm.stats()
        assert stats2['nonzero_slots'] > 0
        assert stats2['max_heat'] >= 100.0
        
        hm.stop()
    
    def test_stats_memory_calculation(self):
        """Memory stats should be reasonable."""
        hm = HeatMap(capacity=1_000_000)
        
        stats = hm.stats()
        
        # Main array + overhead (float32 = 4 bytes by default)
        expected_min = stats['slots'] * 4
        assert stats['memory_bytes'] >= expected_min
        
        hm.stop()


class TestHierarchicalHeatMapExtra:
    """Additional HierarchicalHeatMap tests."""
    
    def test_multiple_adds_compound(self):
        """Multiple adds should compound across levels."""
        hm = HierarchicalHeatMap(
            half_lives=(1.0, 10.0, 100.0),
            decay_interval_seconds=0
        )
        
        for _ in range(10):
            hm.add("item", amount=10.0)
        
        levels = hm.check_levels("item")
        
        # All levels should have heat
        assert levels['short'] > 0
        assert levels['medium'] > 0
        assert levels['long'] > 0
        
        hm.stop()
    
    def test_different_weights_affect_combined(self):
        """Different weights should affect combined heat."""
        hm1 = HierarchicalHeatMap(
            half_lives=(10.0, 100.0),
            weights=(1.0, 0.0),  # Only short-term
            decay_interval_seconds=0
        )
        
        hm2 = HierarchicalHeatMap(
            half_lives=(10.0, 100.0),
            weights=(0.0, 1.0),  # Only long-term
            decay_interval_seconds=0
        )
        
        hm1.add("item", amount=100.0)
        hm2.add("item", amount=100.0)
        
        combined1 = hm1.check("item")
        combined2 = hm2.check("item")
        
        # Combined should be equal since both use 100% of one level
        assert abs(combined1 - combined2) < 1.0
        
        hm1.stop()
        hm2.stop()
    
    def test_four_levels(self):
        """Should support more than 3 levels."""
        hm = HierarchicalHeatMap(
            half_lives=(1.0, 10.0, 100.0, 1000.0),
            decay_interval_seconds=0
        )
        
        assert hm.num_levels == 4
        
        hm.add("item")
        levels = hm.check_levels("item")
        
        assert 'level_3' in levels  # Fourth level
        
        hm.stop()
    
    def test_single_level(self):
        """Single level should work like regular HeatMap."""
        hm = HierarchicalHeatMap(
            half_lives=(60.0,),
            weights=(1.0,),
            decay_interval_seconds=0
        )
        
        hm.add("item", amount=100.0)
        
        combined = hm.check("item")
        levels = hm.check_levels("item")
        
        # With single level, combined = short
        assert abs(combined - levels['short']) < 1e-6
        
        hm.stop()
    
    def test_stats_includes_level_stats(self):
        """Stats should include per-level information."""
        hm = HierarchicalHeatMap(
            half_lives=(10.0, 60.0),
            decay_interval_seconds=0
        )
        
        stats = hm.stats()
        
        assert 'num_levels' in stats
        assert 'half_lives' in stats
        assert 'weights' in stats
        assert 'levels' in stats
        assert len(stats['levels']) == 2
        
        hm.stop()


class TestHeatMapContextManagers:
    """Test context manager behavior."""
    
    def test_context_manager_stops_thread(self):
        """Context manager should stop decay thread on exit."""
        with HeatMap(half_life_seconds=60.0, decay_interval_seconds=0.1) as hm:
            assert hm.is_running
            hm.add("item")
        
        # Thread should be stopped after exit
        assert not hm.is_running
    
    def test_hierarchical_context_manager(self):
        """HierarchicalHeatMap context manager should work."""
        with HierarchicalHeatMap() as hm:
            hm.add("item")
            assert hm.check("item") >= 1.0


class TestHeatMapSpecialValues:
    """Test handling of special float values."""
    
    def test_infinity_heat_rejected(self):
        """Should reject infinity values."""
        hm = HeatMap(decay_interval_seconds=0)
        
        # Adding infinity should be rejected
        with pytest.raises(ValueError, match="cannot be infinite"):
            hm.add("inf", amount=float('inf'))
        
        hm.stop()
    
    def test_nan_heat_rejected(self):
        """Should reject NaN values."""
        hm = HeatMap(decay_interval_seconds=0)
        
        # NaN addition should be rejected
        with pytest.raises(ValueError, match="cannot be NaN"):
            hm.add("nan", amount=float('nan'))
        
        hm.stop()


class TestHeatMapReproducibility:
    """Test reproducibility with seeds."""
    
    def test_same_seed_same_behavior(self):
        """Same seed should produce identical behavior."""
        hm1 = HeatMap(seed=42, decay_interval_seconds=0)
        hm2 = HeatMap(seed=42, decay_interval_seconds=0)
        
        # Should have same hash seeds
        assert all(hm1._hash_seeds == hm2._hash_seeds)
        
        # Should produce same hashes
        assert all(hm1._hash_positions("test") == hm2._hash_positions("test"))
        
        hm1.stop()
        hm2.stop()
    
    def test_different_seeds_different_hashes(self):
        """Different seeds should produce different hashes."""
        hm1 = HeatMap(seed=42, decay_interval_seconds=0)
        hm2 = HeatMap(seed=123, decay_interval_seconds=0)
        
        # Very unlikely to have same hash seeds
        assert not all(hm1._hash_seeds == hm2._hash_seeds)
        
        hm1.stop()
        hm2.stop()


class TestHeatMapDecayMath:
    """Test mathematical properties of decay."""
    
    def test_decay_factor_formula(self):
        """Decay factor should match formula: 0.5^(interval/half_life)."""
        test_cases = [
            (60.0, 1.0),   # 1s interval, 60s half-life
            (10.0, 2.0),   # 2s interval, 10s half-life
            (30.0, 5.0),   # 5s interval, 30s half-life
        ]
        
        for half_life, interval in test_cases:
            hm = HeatMap(
                half_life_seconds=half_life,
                decay_interval_seconds=interval
            )
            
            expected = 0.5 ** (interval / half_life)
            assert abs(hm.decay_factor - expected) < 1e-6
            
            hm.stop()
    
    def test_half_life_reduces_by_half(self):
        """After one half-life of decays, heat should be ~50%."""
        # With half_life=1s and interval=1s, each decay = 50%
        hm = HeatMap(
            half_life_seconds=1.0,
            decay_interval_seconds=1.0  # Non-zero for decay_factor < 1
        )
        
        hm.add("item", amount=100.0)
        
        hm.decay()  # Should reduce to ~50%
        
        after = hm.check("item")
        
        assert 45 < after < 55  # Allow some tolerance
        
        hm.stop()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
