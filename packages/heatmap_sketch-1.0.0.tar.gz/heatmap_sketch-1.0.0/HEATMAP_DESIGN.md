# HeatMap: A Data Structure for Time-Decayed Popularity

## Abstract

We present **HeatMap**, a novel probabilistic data structure for tracking time-decayed popularity in data streams. Unlike existing sketches that measure static frequency or cardinality, HeatMap captures **temporal heat** — a measure that combines frequency and recency through exponential decay.

## The Problem

Existing data structures answer:

| Structure | Question |
|-----------|----------|
| Bloom Filter | Is X in the set? |
| Count-Min Sketch | How many times did X appear? |
| HyperLogLog | How many unique items? |
| Space-Saving | What are the top-k items? |

**Missing:** "What's hot RIGHT NOW?"

HeatMap answers this question in O(1) time with sublinear space.

## The Mathematical Foundation

### Continuous Formulation

The heat H of an item x at time t is defined by the differential equation:

```
dH_x(t)/dt = -λ·H_x(t) + δ_x(t)
```

Where:
- H_x(t) = heat of item x at time t
- λ = decay rate (λ > 0)
- δ_x(t) = impulse function (spike when x is observed)

**Solution:**

```
H_x(t) = H_x(t₀)·e^(-λ(t-t₀)) + Σᵢ e^(-λ(t-tᵢ))
```

Where tᵢ are the times when x was observed.

### Discrete Approximation

At discrete time steps, we maintain:

```
H_x(t+1) = H_x(t)·α + Δ_x(t)
```

Where:
- α = e^(-λ·Δt) = decay factor
- Δ_x(t) = 1 if x observed at time t, 0 otherwise

This is the **exponential moving average** (EMA) of observations.

## Data Structure

### Single-Level HeatMap

```
HeatMap(m, k, α):
  m = number of slots
  k = number of hash functions
  α = decay factor (0 < α < 1)
  
  counters[m] = array of float64, initialized to 0
  hash_seeds[k] = random seeds
  
Operations:
  add(x, t):     Increment counters at positions hᵢ(x)
  check(x, t):   Return min(counters[hᵢ(x)])
  decay():       counters ← counters × α
  top(k):        Return k items with highest heat (requires candidate tracking)
```

### Complexity

| Operation | Time | Space |
|-----------|------|-------|
| add | O(k) | O(m) |
| check | O(k) | O(m) |
| decay | O(m) | O(m) |
| top-k | O(n_candidates log k) | O(m + n_candidates) |

### Multi-Level HeatMap (Hierarchical)

To capture trends at multiple time scales:

```
HeatMap(levels):
  H₁: α₁ = 0.9   (short-term, fast decay)
  H₂: α₂ = 0.99  (medium-term)
  H₃: α₃ = 0.999 (long-term, slow decay)
  
combined_heat(x) = w₁·H₁(x) + w₂·H₂(x) + w₃·H₃(x)
```

This allows detecting:
- Viral spikes (high H₁)
- Sustained interest (high H₂)
- Long-term popularity (high H₃)

## Theoretical Guarantees

### Theorem 1: Decay Accuracy

For any item x, let H_x*(t) be the true heat (continuous solution) and Ĥ_x(t) be the HeatMap estimate. Then:

```
|Ĥ_x(t) - H_x*(t)| ≤ ε
```

Where ε depends on:
- Time since last decay
- Number of hash collisions

### Theorem 2: Space-Error Tradeoff

With m slots and k hash functions, for n items:

```
P(false positive) ≤ (1 - e^(-kn/m))^k
```

(This is the standard Bloom filter bound.)

### Theorem 3: Trend Detection

If item x has heat H_x(t) > θ and is among the top-k items, then:

```
P(x ∈ top-k result) ≥ 1 - δ
```

Where δ depends on m, k, and collision probability.

## Applications

1. **Social Media Trending** — Track trending hashtags, topics
2. **Network Monitoring** — Detect hot IPs, DDoS targets
3. **E-commerce** — Track trending products, searches
4. **News Aggregation** — Track viral articles
5. **Gaming** — Track trending strategies, characters
6. **Finance** — Track trending stocks, keywords

## Comparison to Existing Approaches

| Approach | Decay | Top-k | Space | Time |
|----------|-------|-------|-------|------|
| Count-Min Sketch | ❌ | ❌ | O(m) | O(k) |
| Sliding Window | ✅ | ❌ | O(n) | O(1) |
| Space-Saving | ❌ | ✅ | O(k) | O(1) |
| **HeatMap** | ✅ | ✅ | O(m) | O(k) |

**HeatMap is the only structure combining decay + top-k + sublinear space.**

## Implementation Notes

### Efficient Decay

Instead of decaying all counters every time step:

**Lazy Decay:**
```
check(x, t):
  elapsed = t - last_decay_time
  effective_heat = stored_heat × α^elapsed
  return effective_heat
```

**Periodic Decay:**
- Decay all counters every T time units
- Tradeoff: T small = accurate, T large = fast

### Candidate Tracking

To support top-k queries:

```
candidates = {}  # item → last_heat

add(x):
  update bloom counters
  candidates[x] = check(x)
  
top(k):
  sort candidates by heat
  return top k
```

Memory: O(m + n_candidates)

### Optimization: Hierarchical with Shared Hash

Instead of separate hash functions per level:

```
positions = hash(x)  # Compute once
heat = Σᵢ wᵢ × countersᵢ[positions]
```

## Open Questions

1. **Optimal decay schedule** — What's the best α for a given workload?
2. **Multi-level weighting** — How to weight different time scales?
3. **Adaptive decay** — Can α change based on item behavior?
4. **Parallel implementation** — How to parallelize efficiently?

## Variants

1. **Counting HeatMap** — Store counters (integers) instead of floats
2. **Weighted HeatMap** — Accept weighted observations
3. **Categorical HeatMap** — Track heat per category
4. **Distributed HeatMap** — Merge multiple instances

## Naming

Proposed names:
- **HeatMap** — Intuitive, conveys "heat" metaphor
- **TemporalCounter** — Technical, precise
- **DecaySketch** — Emphasizes probabilistic nature
- **TrendFilter** — Application-focused
- **ExpireMap** — Emphasizes expiration

**Recommendation:** HeatMap — memorable, intuitive, broadly applicable.

---

## Next Steps

1. ✅ Formal definition (this document)
2. ⏳ Rigorous proofs of theorems
3. ⏳ Prototype implementation
4. ⏳ Experimental evaluation
5. ⏳ Write paper
6. ⏳ Submit to venue
