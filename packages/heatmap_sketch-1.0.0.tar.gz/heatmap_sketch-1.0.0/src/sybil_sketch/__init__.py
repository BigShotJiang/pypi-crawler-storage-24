"""
SybilSketch: Sybil-Resistant Trending Sketch

A novel data structure for tracking time-decayed popularity while
resisting manipulation by coordinated bot attacks.
"""

from .sybil import (
    SybilSketch,
    SybilSketchError,
    SourceReputation,
    SourceSketch,
    HeatEstimate,
    create_sybil_sketch
)

__version__ = "1.0.0"
__all__ = [
    "SybilSketch",
    "SybilSketchError",
    "SourceReputation",
    "SourceSketch",
    "HeatEstimate",
    "create_sybil_sketch"
]
