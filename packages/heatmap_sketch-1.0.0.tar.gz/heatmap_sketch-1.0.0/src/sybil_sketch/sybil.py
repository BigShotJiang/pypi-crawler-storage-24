"""
SybilSketch: A Sybil-Resistant Trending Sketch

A novel data structure that tracks time-decayed popularity while resisting
manipulation by coordinated bot attacks.

Key Innovation: Combines Byzantine fault tolerance with trending detection,
ensuring that "trending" items reflect organic popularity, not manipulation.

Mathematical Foundation:
    - Per-source heat tracking with caps
    - Robust aggregation (trimmed mean, median of means)
    - Reputation-based filtering
    - Temporal diversity analysis

Author: Teja
License: MIT
Version: 1.0.0
"""

from __future__ import annotations

import hashlib
import math
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

import numpy as np
from numpy.typing import NDArray

# Import HeatMap as base
from heatmap_sketch import HeatMap


__version__ = "1.0.0"


class SybilSketchError(Exception):
    """Base exception for SybilSketch errors."""
    pass


@dataclass
class SourceReputation:
    """Reputation score for a source (user/IP/etc)."""
    source_id: str
    consistency_score: float = 1.0  # How consistent over time
    diversity_score: float = 1.0    # How diverse item selection
    temporal_score: float = 1.0     # How natural timing patterns
    contribution_count: int = 0
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    
    @property
    def overall_score(self) -> float:
        """Combined reputation score."""
        # Weighted average with recency penalty for new sources
        age_hours = (time.time() - self.first_seen) / 3600
        age_factor = min(1.0, age_hours / 24.0)  # Full trust after 24 hours
        
        base_score = (
            0.4 * self.consistency_score +
            0.3 * self.diversity_score +
            0.3 * self.temporal_score
        )
        
        return base_score * age_factor


@dataclass
class CandidateItem:
    """Tracked candidate for top-k queries."""
    item: str
    robust_heat: float
    source_count: int
    byzantine_score: float  # Lower = more organic
    first_seen: float
    last_seen: float


class SourceSketch:
    """Mini-sketch for tracking a single source's contributions."""
    
    def __init__(self, capacity: int = 1000, decay_factor: float = 0.99):
        """Initialize source sketch."""
        self.capacity = capacity
        self.decay_factor = decay_factor
        self.items: Dict[str, float] = {}  # item -> heat
        self.total_heat: float = 0.0
        self.contribution_times: List[float] = []
        self._lock = threading.Lock()
    
    def add(self, item: str, amount: float = 1.0) -> None:
        """Add contribution to item."""
        with self._lock:
            self.items[item] = self.items.get(item, 0.0) + amount
            self.total_heat += amount
            self.contribution_times.append(time.time())
            
            # Evict if too many items
            if len(self.items) > self.capacity:
                self._evict_coldest()
    
    def _evict_coldest(self) -> None:
        """Evict coldest items."""
        if len(self.items) > self.capacity:
            sorted_items = sorted(self.items.items(), key=lambda x: x[1])
            for item, _ in sorted_items[:self.capacity // 10]:
                del self.items[item]
    
    def get_heat(self, item: str) -> float:
        """Get heat for item."""
        return self.items.get(item, 0.0)
    
    def decay(self) -> None:
        """Apply decay to all items."""
        with self._lock:
            for item in self.items:
                self.items[item] *= self.decay_factor
            self.total_heat *= self.decay_factor
            
            # Remove very cold items
            self.items = {k: v for k, v in self.items.items() if v > 0.001}
    
    def get_diversity(self) -> float:
        """Calculate item diversity (entropy-based)."""
        if not self.items:
            return 0.0
        
        total = sum(self.items.values())
        if total == 0:
            return 0.0
        
        # Normalized entropy
        entropy = 0.0
        for heat in self.items.values():
            p = heat / total
            if p > 0:
                entropy -= p * math.log2(p)
        
        # Normalize to [0, 1]
        max_entropy = math.log2(len(self.items)) if len(self.items) > 1 else 1.0
        return entropy / max_entropy if max_entropy > 0 else 0.0
    
    def get_temporal_score(self) -> float:
        """Calculate temporal naturalness (CV of inter-arrival times)."""
        if len(self.contribution_times) < 3:
            return 0.5  # Neutral for new sources
        
        # Get inter-arrival times
        times = sorted(self.contribution_times[-100:])  # Last 100
        intervals = [times[i+1] - times[i] for i in range(len(times)-1)]
        
        if not intervals:
            return 0.5
        
        mean_interval = np.mean(intervals)
        std_interval = np.std(intervals)
        
        # Coefficient of variation
        cv = std_interval / mean_interval if mean_interval > 0 else 0
        
        # CV ~1.0 is natural (exponential distribution)
        # CV << 1 is suspicious (regular intervals)
        # CV >> 1 is also suspicious (bursty)
        naturalness = 1.0 - abs(cv - 1.0) / 2.0
        return max(0.0, min(1.0, naturalness))


class SybilSketch:
    """
    Sybil-resistant trending sketch.
    
    Tracks time-decayed popularity while resisting manipulation by
    coordinated bot attacks through:
    1. Per-source contribution caps
    2. Robust aggregation (trimmed mean, median)
    3. Reputation-based filtering
    4. Temporal diversity analysis
    
    Example:
        >>> sketch = SybilSketch(max_sources=10000)
        >>> sketch.add("#trending", source="user_123")
        >>> sketch.add("#trending", source="bot_456")  # Bot contribution
        >>> top = sketch.top(10)  # Returns organic trends only
    """
    
    def __init__(
        self,
        capacity: int = 100_000,
        error_rate: float = 0.05,
        half_life_seconds: float = 300.0,  # 5 minutes
        decay_interval_seconds: float = 10.0,
        max_sources: int = 100_000,
        max_source_heat: float = 100.0,
        byzantine_fraction: float = 0.2,
        reputation_threshold: float = 0.3,
        diversity_threshold: float = 0.1,
        seed: Optional[int] = None
    ) -> None:
        """
        Initialize SybilSketch.
        
        Args:
            capacity: Expected number of unique items
            error_rate: Error tolerance for sketches
            half_life_seconds: Time for heat to decay by 50%
            decay_interval_seconds: How often to auto-decay
            max_sources: Maximum unique sources to track
            max_source_heat: Cap per-source contribution per item
            byzantine_fraction: Expected fraction of Byzantine sources
            reputation_threshold: Minimum reputation to trust source
            diversity_threshold: Minimum source diversity for trending
            seed: Random seed for reproducibility
        """
        # Core sketch
        self.item_heat = HeatMap(
            capacity=capacity,
            error_rate=error_rate,
            half_life_seconds=half_life_seconds,
            decay_interval_seconds=0,  # Manual decay
            track_candidates=False,  # We manage candidates ourselves
            seed=seed
        )
        
        # Per-source tracking
        self.source_sketches: Dict[str, SourceSketch] = {}
        self.max_sources = max_sources
        
        # Reputation system
        self.source_reputation: Dict[str, SourceReputation] = {}
        self.reputation_threshold = reputation_threshold
        
        # Byzantine resistance parameters
        self.max_source_heat = max_source_heat
        self.byzantine_fraction = byzantine_fraction
        self.diversity_threshold = diversity_threshold
        
        # Candidate tracking
        self.candidates: Dict[str, CandidateItem] = {}
        
        # Item -> sources mapping (for diversity)
        self.item_sources: Dict[str, Set[str]] = defaultdict(set)
        
        # Threading
        self._lock = threading.RLock()
        self._running = False
        self._decay_thread: Optional[threading.Thread] = None
        self._decay_interval = decay_interval_seconds
        
        # Start decay thread
        if decay_interval_seconds > 0:
            self._start_decay_thread()
    
    def _start_decay_thread(self) -> None:
        """Start background decay thread."""
        self._running = True
        self._decay_thread = threading.Thread(target=self._decay_loop, daemon=True)
        self._decay_thread.start()
    
    def _decay_loop(self) -> None:
        """Background decay."""
        while self._running:
            time.sleep(self._decay_interval)
            if self._running:
                self.decay()
    
    def stop(self) -> None:
        """Stop background thread."""
        self._running = False
        if self._decay_thread:
            self._decay_thread.join(timeout=2.0)
        self.item_heat.stop()
    
    def add(
        self,
        item: str,
        source: str,
        amount: float = 1.0,
        timestamp: Optional[float] = None
    ) -> None:
        """
        Add contribution from source to item.
        
        Args:
            item: The item to add heat to (e.g., hashtag)
            source: The source of the contribution (e.g., user_id)
            amount: Amount of heat to add
            timestamp: Optional timestamp (default: now)
        """
        with self._lock:
            # Update source sketch
            if source not in self.source_sketches:
                if len(self.source_sketches) >= self.max_sources:
                    self._evict_coldest_source()
                self.source_sketches[source] = SourceSketch()
                self.source_reputation[source] = SourceReputation(source_id=source)
            
            source_sketch = self.source_sketches[source]
            
            # Cap per-source contribution (Byzantine resistance)
            current_heat = source_sketch.get_heat(item)
            capped_amount = min(amount, self.max_source_heat - current_heat)
            
            if capped_amount > 0:
                source_sketch.add(item, capped_amount)
                
                # Update global heat (reputation-weighted)
                reputation = self.source_reputation[source].overall_score
                weighted_amount = capped_amount * max(0.01, reputation)  # Min 0.01 to avoid zero
                
                self.item_heat.add(item, amount=weighted_amount)
                
                # Track item-source mapping
                self.item_sources[item].add(source)
                
                # Update candidate
                self._update_candidate(item)
                
                # Update reputation
                self._update_reputation(source)
    
    def _evict_coldest_source(self) -> None:
        """Evict source with lowest reputation."""
        if not self.source_reputation:
            return
        
        # Find lowest reputation source
        min_source = min(
            self.source_reputation.keys(),
            key=lambda s: self.source_reputation[s].overall_score
        )
        
        del self.source_sketches[min_source]
        del self.source_reputation[min_source]
        
        # Remove from item_sources
        for item in list(self.item_sources.keys()):
            self.item_sources[item].discard(min_source)
    
    def _update_reputation(self, source: str) -> None:
        """Update reputation scores for source."""
        rep = self.source_reputation[source]
        sketch = self.source_sketches[source]
        
        rep.contribution_count += 1
        rep.last_seen = time.time()
        
        # Update diversity score
        rep.diversity_score = sketch.get_diversity()
        
        # Update temporal score
        rep.temporal_score = sketch.get_temporal_score()
        
        # Consistency: how similar to historical behavior
        if rep.contribution_count > 10:
            # Compare recent diversity to historical
            recent_diversity = sketch.get_diversity()
            rep.consistency_score = 1.0 - abs(recent_diversity - rep.diversity_score)
    
    def _update_candidate(self, item: str) -> None:
        """Update candidate entry for item."""
        sources = self.item_sources.get(item, set())
        source_count = len(sources)
        
        # Calculate robust heat (trimmed mean of source contributions)
        heats = []
        for source in sources:
            if source in self.source_sketches:
                heats.append(self.source_sketches[source].get_heat(item))
        
        if not heats:
            return
        
        # Trimmed mean (remove top/bottom 20%)
        heats.sort()
        trim = max(1, len(heats) // 5)
        trimmed = heats[trim:-trim] if trim < len(heats) // 2 else heats
        robust_heat = np.mean(trimmed) if trimmed else 0.0
        
        # Byzantine score: how concentrated are contributions?
        if heats:
            max_heat = max(heats)
            total_heat = sum(heats)
            concentration = max_heat / total_heat if total_heat > 0 else 0
            byzantine_score = concentration  # Higher = more suspicious
        else:
            byzantine_score = 1.0
        
        # Update or create candidate
        if item in self.candidates:
            cand = self.candidates[item]
            cand.robust_heat = robust_heat
            cand.source_count = source_count
            cand.byzantine_score = byzantine_score
            cand.last_seen = time.time()
        else:
            self.candidates[item] = CandidateItem(
                item=item,
                robust_heat=robust_heat,
                source_count=source_count,
                byzantine_score=byzantine_score,
                first_seen=time.time(),
                last_seen=time.time()
            )
    
    def check(self, item: str) -> float:
        """
        Get robust heat estimate for item.
        
        Returns 0 if item doesn't meet diversity threshold.
        """
        with self._lock:
            # Check source diversity
            sources = self.item_sources.get(item, set())
            if len(sources) < 2:
                return 0.0  # Need at least 2 sources
            
            # Get candidate if exists
            if item in self.candidates:
                cand = self.candidates[item]
                
                # Filter by diversity
                if cand.source_count < 3 and cand.byzantine_score > 0.8:
                    return 0.0  # Suspicious: few sources, high concentration
                
                return cand.robust_heat
            
            return self.item_heat.check(item)
    
    def detailed_check(self, item: str) -> "HeatEstimate":
        """
        Get detailed heat estimate for item.
        
        Returns HeatEstimate with all metadata.
        """
        with self._lock:
            sources = self.item_sources.get(item, set())
            source_count = len(sources)
            raw_heat = self.item_heat.check(item)
            
            if item in self.candidates:
                cand = self.candidates[item]
                robust_heat = cand.robust_heat
                byzantine_score = cand.byzantine_score
            else:
                robust_heat = raw_heat
                byzantine_score = 1.0 if source_count < 3 else 0.5
            
            is_trending = (
                source_count >= 3 and
                byzantine_score < 0.7 and
                robust_heat > 0.1
            )
            
            return HeatEstimate(
                raw_heat=raw_heat,
                robust_heat=robust_heat,
                source_count=source_count,
                byzantine_score=byzantine_score,
                is_trending=is_trending
            )
    
    def top(self, k: int = 10) -> List[Tuple[str, float, int, float]]:
        """
        Get top-k trending items (robust to manipulation).
        
        Returns:
            List of (item, robust_heat, source_count, byzantine_score) tuples
        """
        with self._lock:
            # Filter candidates by diversity and Byzantine score
            valid_candidates = []
            
            for item, cand in self.candidates.items():
                # Filter 1: Minimum source diversity
                if cand.source_count < 3:
                    continue
                
                # Filter 2: Low Byzantine score (organic)
                if cand.byzantine_score > 0.7:
                    continue
                
                # Filter 3: Sufficient heat
                if cand.robust_heat < 0.1:
                    continue
                
                valid_candidates.append(cand)
            
            # Sort by robust heat
            valid_candidates.sort(key=lambda c: -c.robust_heat)
            
            # Return top k with metadata
            return [
                (c.item, c.robust_heat, c.source_count, c.byzantine_score)
                for c in valid_candidates[:k]
            ]
    
    def decay(self) -> None:
        """Apply decay to all components."""
        with self._lock:
            # Decay global heat
            self.item_heat.decay()
            
            # Decay source sketches
            for sketch in self.source_sketches.values():
                sketch.decay()
            
            # Decay reputation scores (slowly)
            for rep in self.source_reputation.values():
                rep.consistency_score *= 0.999
                rep.diversity_score *= 0.999
                rep.temporal_score *= 0.999
            
            # Remove cold candidates
            self.candidates = {
                item: cand
                for item, cand in self.candidates.items()
                if cand.robust_heat > 0.01 and
                   time.time() - cand.last_seen < 3600  # Active in last hour
            }
    
    def get_source_stats(self, source: str) -> Optional[Dict]:
        """Get statistics for a source."""
        with self._lock:
            if source not in self.source_sketches:
                return None
            
            sketch = self.source_sketches[source]
            rep = self.source_reputation[source]
            
            return {
                'contribution_count': rep.contribution_count,
                'overall_reputation': rep.overall_score,
                'consistency': rep.consistency_score,
                'diversity': rep.diversity_score,
                'temporal': rep.temporal_score,
                'unique_items': len(sketch.items),
                'total_heat': sketch.total_heat
            }
    
    def stats(self) -> Dict:
        """Get overall statistics."""
        with self._lock:
            # Calculate reputation distribution
            reputations = [r.overall_score for r in self.source_reputation.values()]
            
            return {
                'unique_items': len(self.candidates),
                'unique_sources': len(self.source_sketches),
                'valid_trending_items': len([
                    c for c in self.candidates.values()
                    if c.source_count >= 3 and c.byzantine_score < 0.7
                ]),
                'avg_reputation': np.mean(reputations) if reputations else 0.0,
                'low_reputation_sources': len([
                    r for r in reputations if r < self.reputation_threshold
                ]),
                'memory_bytes': (
                    self.item_heat.stats()['memory_bytes'] +
                    len(self.source_sketches) * 1000 +  # Rough estimate
                    len(self.candidates) * 200
                )
            }
    
    def __del__(self) -> None:
        """Cleanup."""
        self.stop()
    
    def __enter__(self) -> "SybilSketch":
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.stop()


@dataclass
class HeatEstimate:
    """Detailed heat estimate for an item."""
    raw_heat: float
    robust_heat: float
    source_count: int
    byzantine_score: float
    is_trending: bool


def create_sybil_sketch(
    expected_items: int = 100_000,
    expected_sources: int = 10_000,
    half_life_minutes: float = 5.0,
    byzantine_fraction: float = 0.2
) -> SybilSketch:
    """
    Create a SybilSketch with sensible defaults.
    
    Args:
        expected_items: Expected number of unique items
        expected_sources: Expected number of unique sources
        half_life_minutes: Half-life in minutes
        byzantine_fraction: Expected fraction of malicious sources
    
    Returns:
        Configured SybilSketch
    """
    return SybilSketch(
        capacity=expected_items,
        max_sources=expected_sources,
        half_life_seconds=half_life_minutes * 60,
        decay_interval_seconds=half_life_minutes * 6,  # Decay every 10% of half-life
        byzantine_fraction=byzantine_fraction
    )
