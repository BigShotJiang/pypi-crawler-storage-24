"""
HeatMap: A Data Structure for Time-Decayed Popularity

A probabilistic data structure that tracks "heat" (time-decayed popularity)
of items in a stream. Heat combines frequency and recency through exponential decay.

Mathematical Foundation:
    dH/dt = -λ·H + δ(item)
    
    Solution: H(t) = H(t₀)·e^(-λ(t-t₀)) + contributions

Reference: See HEATMAP_DESIGN.md for full mathematical treatment.

Example:
    >>> from heatmap_sketch import HeatMap
    >>> 
    >>> # Create a HeatMap with 60-second half-life
    >>> hm = HeatMap(half_life_seconds=60.0)
    >>> 
    >>> # Add heat to items
    >>> hm.add("hashtag", amount=10.0)
    >>> 
    >>> # Check current heat
    >>> heat = hm.check("hashtag")
    >>> 
    >>> # Get top-k trending
    >>> trending = hm.top(10)
    >>> 
    >>> # Clean up
    >>> hm.stop()

Author: Teja
License: MIT
Version: 1.0.0
"""

from __future__ import annotations

import math
import struct
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
from numpy.typing import NDArray

# Optional Numba acceleration
try:
    from numba import jit, prange
    NUMBA_AVAILABLE = True
except ImportError:
    NUMBA_AVAILABLE = False
    def jit(*args, **kwargs):
        def decorator(func):
            return func
        return decorator
    prange = range

__version__ = "1.0.0"

# Numba-accelerated functions
@jit(nopython=True, cache=True)
def _hash_positions_numba(h1: int, h2: int, k: int, m: int) -> np.ndarray:
    """Compute k hash positions using double hashing (Numba-accelerated)."""
    positions = np.empty(k, dtype=np.int64)
    for i in range(k):
        positions[i] = (h1 + i * h2) % m
    return positions


@jit(nopython=True, cache=True)
def _add_to_positions_numba(heat: np.ndarray, positions: np.ndarray, amount: float) -> None:
    """Add amount to all positions (Numba-accelerated)."""
    for i in range(len(positions)):
        heat[positions[i]] += amount


@jit(nopython=True, cache=True)
def _min_heat_numba(heat: np.ndarray, positions: np.ndarray) -> float:
    """Get minimum heat at positions (Numba-accelerated)."""
    min_val = heat[positions[0]]
    for i in range(1, len(positions)):
        if heat[positions[i]] < min_val:
            min_val = heat[positions[i]]
    return min_val


@jit(nopython=True, parallel=True, cache=True)
def _decay_parallel_numba(heat: np.ndarray, decay_factor: float) -> None:
    """Apply decay to all slots in parallel (Numba-accelerated)."""
    for i in prange(len(heat)):
        heat[i] *= decay_factor


class HeatMapError(Exception):
    """Base exception for HeatMap errors."""
    pass


class HeatMapCapacityError(HeatMapError):
    """Raised when capacity parameters are invalid."""
    pass


class HeatMapStateError(HeatMapError):
    """Raised when operations are called on stopped HeatMap."""
    pass


@dataclass
class HeatCandidate:
    """Tracks a candidate item for top-k enumeration."""
    item: str
    heat: float
    last_update: float


class HeatMap:
    """
    A data structure for tracking time-decayed popularity.
    
    Unlike a counting bloom filter (which stores static counts), HeatMap
    stores "heat" values that decay exponentially over time. This allows
    tracking what's popular RIGHT NOW, not what was popular historically.
    
    The heat of an item follows the differential equation:
        dH/dt = -λ·H + δ(item)
    
    Where λ is determined by the half_life parameter.
    
    Attributes:
        m: Number of slots in the underlying array
        k: Number of hash functions
        half_life: Time for heat to decay by 50%
        decay_factor: Multiplier per decay (α = 0.5^(decay_interval/half_life))
    
    Example:
        >>> hm = HeatMap(half_life_seconds=60.0)
        >>> hm.add("item", amount=10.0)
        >>> heat = hm.check("item")
        >>> print(f"Current heat: {heat}")
        >>> hm.stop()
    """
    
    # Constants for validation
    MIN_CAPACITY: int = 10
    MAX_CAPACITY: int = 10_000_000_000
    MIN_ERROR_RATE: float = 1e-6
    MAX_ERROR_RATE: float = 0.5
    MIN_HALF_LIFE: float = 0.001
    MAX_HALF_LIFE: float = 365.25 * 24 * 3600  # 1 year in seconds
    
    # Performance settings
    _USE_NUMBA: bool = False  # Set to True if numba is available
    
    def __init__(
        self,
        capacity: int = 100_000,
        error_rate: float = 0.05,
        half_life_seconds: float = 60.0,
        decay_interval_seconds: float = 1.0,
        track_candidates: bool = True,
        max_candidates: Optional[int] = None,
        lazy_decay: bool = False,
        use_float32: bool = True,
        seed: Optional[int] = None
    ) -> None:
        """
        Initialize a HeatMap.
        
        Args:
            capacity: Expected number of unique items (for sizing).
                Must be between 10 and 10 billion. Default: 100,000
                Rule of thumb: Set to expected unique items × 2 for safety.
            error_rate: Desired false positive rate for the underlying sketch.
                Must be between 1e-6 and 0.5. Default: 0.05 (5%)
                Lower = more accurate but more memory.
            half_life_seconds: Time for heat to decay by 50%.
                Must be positive. Default: 60.0 (1 minute)
                Rule of thumb: Set to your trending window × 2.
            decay_interval_seconds: How often to auto-decay.
                Set to 0 for manual decay only. Default: 1.0
                Rule of thumb: Set to half_life / 10 for smooth decay.
            track_candidates: Whether to track items for top-k queries.
                Required for top() method. Default: True
            max_candidates: Maximum candidates to track for top-k.
                Set to limit memory. Older items evicted when full.
                Default: None (unlimited)
            lazy_decay: If True, decay is applied on access instead of
                periodically. Reduces CPU when few items accessed.
                Default: False (eager decay)
            use_float32: If True, use float32 instead of float64.
                Cuts memory in half with minimal precision loss.
                Default: True
            seed: Random seed for hash functions.
                Set for reproducibility. Default: None (random)
        
        Raises:
            HeatMapCapacityError: If capacity or error_rate are out of bounds.
            ValueError: If half_life_seconds is not positive.
        
        Parameter Selection Guide:
            - For hashtag trending (1M tweets/day):
              capacity=500_000, error_rate=0.05, half_life=300
              Memory: ~1.5MB
            - For API rate limiting (100K users):
              capacity=50_000, error_rate=0.01, half_life=60
              Memory: ~500KB
            - For cache hit tracking (1M items):
              capacity=100_000, error_rate=0.05, half_life=3600
              Memory: ~1.5MB
            - For IoT sensor data (10K sensors):
              capacity=10_000, error_rate=0.01, half_life=30
              Memory: ~100KB
        """
        # Initialize attributes needed by stop() / __del__ FIRST
        # This prevents AttributeError if __init__ fails partway through
        self._running: bool = False
        self._decay_thread: Optional[threading.Thread] = None
        self._lock = threading.RLock()
        
        # Validate inputs
        self._validate_capacity(capacity)
        self._validate_error_rate(error_rate)
        self._validate_half_life(half_life_seconds)
        self._validate_decay_interval(decay_interval_seconds)
        
        # Calculate optimal bloom parameters
        # m = -n*ln(p) / (ln(2)^2)
        # k = m/n * ln(2)
        self._capacity = capacity
        self._error_rate = error_rate
        
        m = int(-capacity * math.log(error_rate) / (math.log(2) ** 2))
        k = int(m / capacity * math.log(2))
        
        # Ensure reasonable bounds
        k = max(1, min(k, 20))
        m = max(1024, m)
        
        self._m: int = m
        self._k: int = k
        
        # Decay parameters
        self._half_life: float = half_life_seconds
        self._decay_interval: float = decay_interval_seconds
        self._lazy_decay: bool = lazy_decay
        
        # α = 0.5^(Δt / half_life)
        if decay_interval_seconds > 0 and half_life_seconds > 0:
            self._decay_factor: float = 0.5 ** (decay_interval_seconds / half_life_seconds)
        else:
            self._decay_factor = 1.0  # No decay
        
        # Core storage: float array for heat values (float32 by default)
        self._dtype = np.float32 if use_float32 else np.float64
        self._heat: NDArray = np.zeros(self._m, dtype=self._dtype)
        
        # Candidate tracking for top-k queries
        self._track_candidates: bool = track_candidates
        self._max_candidates: Optional[int] = max_candidates
        self._candidates: Dict[str, HeatCandidate] = {}
        
        # Lazy decay tracking
        self._last_decay: float = time.time()
        self._decay_count: int = 0  # Track total decays for numerical stability
        
        # Hash seeds
        rng = np.random.default_rng(seed)
        self._hash_seeds: NDArray[np.uint64] = rng.integers(
            1, 2**32, size=self._k, dtype=np.uint64
        )
        
        # Start eager decay thread if not lazy
        if decay_interval_seconds > 0 and not lazy_decay:
            self._start_decay_thread()
    
    @property
    def m(self) -> int:
        """Number of slots in the underlying array."""
        return self._m
    
    @property
    def k(self) -> int:
        """Number of hash functions."""
        return self._k
    
    @property
    def half_life(self) -> float:
        """Half-life in seconds."""
        return self._half_life
    
    @property
    def decay_interval(self) -> float:
        """Decay interval in seconds."""
        return self._decay_interval
    
    @property
    def decay_factor(self) -> float:
        """Decay multiplier per decay cycle."""
        return self._decay_factor
    
    @property
    def is_running(self) -> bool:
        """Whether the auto-decay thread is running."""
        return self._running
    
    def _validate_capacity(self, capacity: int) -> None:
        """Validate capacity parameter."""
        if not isinstance(capacity, int):
            raise TypeError(f"capacity must be int, got {type(capacity).__name__}")
        if capacity < self.MIN_CAPACITY:
            raise HeatMapCapacityError(
                f"capacity must be >= {self.MIN_CAPACITY}, got {capacity}"
            )
        if capacity > self.MAX_CAPACITY:
            raise HeatMapCapacityError(
                f"capacity must be <= {self.MAX_CAPACITY}, got {capacity}"
            )
    
    def _validate_error_rate(self, error_rate: float) -> None:
        """Validate error_rate parameter."""
        if not isinstance(error_rate, (int, float)):
            raise TypeError(
                f"error_rate must be numeric, got {type(error_rate).__name__}"
            )
        if error_rate <= self.MIN_ERROR_RATE:
            raise HeatMapCapacityError(
                f"error_rate must be > {self.MIN_ERROR_RATE}, got {error_rate}"
            )
        if error_rate >= self.MAX_ERROR_RATE:
            raise HeatMapCapacityError(
                f"error_rate must be < {self.MAX_ERROR_RATE}, got {error_rate}"
            )
    
    def _validate_half_life(self, half_life: float) -> None:
        """Validate half_life parameter."""
        if not isinstance(half_life, (int, float)):
            raise TypeError(
                f"half_life_seconds must be numeric, got {type(half_life).__name__}"
            )
        if half_life <= 0:
            raise ValueError(f"half_life_seconds must be positive, got {half_life}")
        if half_life < self.MIN_HALF_LIFE:
            raise ValueError(
                f"half_life_seconds must be >= {self.MIN_HALF_LIFE}, got {half_life}"
            )
    
    def _validate_decay_interval(self, interval: float) -> None:
        """Validate decay_interval parameter."""
        if not isinstance(interval, (int, float)):
            raise TypeError(
                f"decay_interval_seconds must be numeric, got {type(interval).__name__}"
            )
        if interval < 0:
            raise ValueError(
                f"decay_interval_seconds must be >= 0, got {interval}"
            )
    
    def _validate_amount(self, amount: float) -> None:
        """Validate amount parameter."""
        if not isinstance(amount, (int, float)):
            raise TypeError(f"amount must be numeric, got {type(amount).__name__}")
        if math.isnan(amount):
            raise ValueError("amount cannot be NaN")
        if math.isinf(amount):
            raise ValueError("amount cannot be infinite")
        if amount <= 0:
            raise ValueError(f"amount must be positive, got {amount}")
    
    def _start_decay_thread(self) -> None:
        """Start the background decay thread."""
        self._running = True
        self._decay_thread = threading.Thread(target=self._decay_loop, daemon=True)
        self._decay_thread.start()
    
    def _decay_loop(self) -> None:
        """Background thread that applies decay periodically."""
        while self._running:
            time.sleep(self._decay_interval)
            if self._running:
                self.decay()
    
    def stop(self) -> None:
        """
        Stop the background decay thread.
        
        Must be called to cleanly shut down the HeatMap when using auto-decay.
        
        Example:
            >>> hm = HeatMap(half_life_seconds=60.0)
            >>> # ... use the HeatMap ...
            >>> hm.stop()  # Clean shutdown
        """
        self._running = False
        if self._decay_thread is not None:
            self._decay_thread.join(timeout=2.0)
            self._decay_thread = None
    
    def __del__(self) -> None:
        """Clean up on garbage collection."""
        self.stop()
    
    def __enter__(self) -> "HeatMap":
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.stop()
    
    def _hash_positions(self, item) -> NDArray[np.intp]:
        """
        Hash an item to k positions using double hashing.
        
        Uses the technique from Kirsch & Mitzenmacher (2008) for efficient
        hash computation.
        """
        item_bytes = str(item).encode('utf-8')
        
        # Pad to at least 16 bytes for double hashing
        if len(item_bytes) < 16:
            item_bytes = item_bytes.ljust(16, b'\x00')
        
        h1 = struct.unpack('<Q', item_bytes[:8])[0]
        h2 = struct.unpack('<Q', item_bytes[8:16])[0]
        h2 = max(1, h2)  # Ensure non-zero step
        
        positions = np.empty(self._k, dtype=np.intp)
        for i in range(self._k):
            # Double hashing: (h1 + i*h2) mod m
            pos = (h1 + i * h2) % self._m
            positions[i] = pos
        
        return positions
    
    def add(
        self,
        item,
        amount: float = 1.0,
        timestamp: Optional[float] = None
    ) -> None:
        """
        Add heat to an item.
        
        Args:
            item: The item to add heat to. Will be converted to string.
            amount: Amount of heat to add. Must be positive. Default: 1.0
            timestamp: Reserved for future use (lazy decay). Default: None
        
        Raises:
            ValueError: If amount is not positive.
        
        Example:
            >>> hm = HeatMap(decay_interval_seconds=0)
            >>> hm.add("hashtag")
            >>> hm.add("topic", amount=10.0)
        """
        self._validate_amount(amount)
        
        with self._lock:
            # Apply lazy decay if enabled
            if self._lazy_decay:
                self._apply_lazy_decay()
            
            positions = self._hash_positions(item)
            
            # Add heat to all k positions
            for pos in positions:
                self._heat[pos] += amount
            
            # Update candidate tracking
            if self._track_candidates:
                item_str = str(item)
                heat = self._estimate_heat(positions)
                now = time.time()
                
                if item_str in self._candidates:
                    self._candidates[item_str].heat = heat
                    self._candidates[item_str].last_update = now
                else:
                    # Check if we need to evict
                    if (self._max_candidates is not None and 
                        len(self._candidates) >= self._max_candidates):
                        self._evict_coldest()
                    
                    self._candidates[item_str] = HeatCandidate(
                        item=item_str,
                        heat=heat,
                        last_update=now
                    )
    
    def _apply_lazy_decay(self) -> None:
        """Apply decay based on elapsed time (lazy mode only)."""
        now = time.time()
        elapsed = now - self._last_decay
        
        if elapsed >= self._decay_interval:
            # Calculate number of decay intervals
            n_decays = int(elapsed / self._decay_interval)
            
            # Apply compound decay
            total_decay = self._decay_factor ** n_decays
            self._heat *= total_decay
            
            self._last_decay = now - (elapsed % self._decay_interval)
            self._decay_count += n_decays
            
            # Numerical stability: renormalize after many decays
            if self._decay_count > 100000:
                self._renormalize()
    
    def _evict_coldest(self) -> None:
        """Evict the coldest candidates when max_candidates is reached."""
        if not self._candidates:
            return
        
        # Find coldest items (evict 10% at a time for efficiency)
        evict_count = max(1, len(self._candidates) // 10)
        
        sorted_items = sorted(
            self._candidates.items(),
            key=lambda x: x[1].heat
        )
        
        for item_str, _ in sorted_items[:evict_count]:
            del self._candidates[item_str]
    
    def _renormalize(self) -> None:
        """
        Renormalize heat values to prevent floating point accumulation errors.
        
        After many decay operations, floating point errors accumulate.
        This shifts all values to maintain precision.
        """
        if np.max(self._heat) > 1e100 or np.min(self._heat[np.nonzero(self._heat)]) < 1e-100:
            # Find median non-zero heat
            nonzero = self._heat[self._heat > 0]
            if len(nonzero) > 0:
                median = np.median(nonzero)
                if median > 0:
                    # Scale everything relative to median
                    self._heat = self._heat / median
                    # Update candidates too
                    if self._track_candidates:
                        for item_str in self._candidates:
                            positions = self._hash_positions(item_str)
                            self._candidates[item_str].heat = self._estimate_heat(positions)
        
        self._decay_count = 0
    
    def add_many(self, items: List, amount: float = 1.0) -> None:
        """
        Add heat to multiple items efficiently.
        
        Args:
            items: List of items to add heat to.
            amount: Amount of heat to add to each. Must be positive. Default: 1.0
        
        Raises:
            ValueError: If amount is not positive.
        
        Example:
            >>> hm = HeatMap(decay_interval_seconds=0)
            >>> hm.add_many(["#python", "#rust", "#golang"])
        """
        self._validate_amount(amount)
        
        if not items:
            return
        
        with self._lock:
            # Apply lazy decay if enabled
            if self._lazy_decay:
                self._apply_lazy_decay()
            
            now = time.time()
            
            for item in items:
                positions = self._hash_positions(item)
                for pos in positions:
                    self._heat[pos] += amount
                
                if self._track_candidates:
                    item_str = str(item)
                    heat = self._estimate_heat(positions)
                    
                    if item_str in self._candidates:
                        self._candidates[item_str].heat = heat
                        self._candidates[item_str].last_update = now
                    else:
                        # Check if we need to evict
                        if (self._max_candidates is not None and 
                            len(self._candidates) >= self._max_candidates):
                            self._evict_coldest()
                        
                        self._candidates[item_str] = HeatCandidate(
                            item=item_str,
                            heat=heat,
                            last_update=now
                        )
    
    def _estimate_heat(self, positions: NDArray[np.intp]) -> float:
        """
        Estimate heat from positions.
        
        Uses minimum to reduce false positives (like Bloom filter).
        """
        return float(np.min(self._heat[positions]))
    
    def check(self, item) -> float:
        """
        Check the current heat of an item.
        
        Args:
            item: The item to check.
        
        Returns:
            Current heat value (time-decayed popularity).
        
        Example:
            >>> hm = HeatMap(decay_interval_seconds=0)
            >>> hm.add("topic", amount=10.0)
            >>> hm.check("topic")
            10.0
        """
        with self._lock:
            # Apply lazy decay if enabled
            if self._lazy_decay:
                self._apply_lazy_decay()
            
            positions = self._hash_positions(item)
            return self._estimate_heat(positions)
    
    def decay(self) -> None:
        """
        Apply exponential decay to all heat values.
        
        After decay, each heat value becomes:
            heat ← heat × decay_factor
        
        This is typically called automatically by the background thread.
        Call manually if decay_interval_seconds=0.
        
        In lazy decay mode, this is a no-op (decay happens on access).
        
        Example:
            >>> hm = HeatMap(half_life_seconds=60.0, decay_interval_seconds=0)
            >>> hm.add("topic", amount=100.0)
            >>> hm.decay()  # Heat is now ~50.0
        """
        with self._lock:
            if self._lazy_decay:
                # Lazy decay is applied on access, not here
                return
            
            # Apply decay to all heat values
            self._heat *= self._decay_factor
            self._last_decay = time.time()
            self._decay_count += 1
            
            # Update candidate heat estimates
            if self._track_candidates:
                items_to_remove = []
                
                for item_str in self._candidates:
                    positions = self._hash_positions(item_str)
                    new_heat = self._estimate_heat(positions)
                    
                    if new_heat < 1e-6:  # Remove cold items
                        items_to_remove.append(item_str)
                    else:
                        self._candidates[item_str].heat = new_heat
                
                for item_str in items_to_remove:
                    del self._candidates[item_str]
            
            # Numerical stability check
            if self._decay_count > 100000:
                self._renormalize()
    
    def top(self, k: int = 10) -> List[Tuple[str, float]]:
        """
        Get the top-k hottest items.
        
        Args:
            k: Number of items to return. Must be positive.
        
        Returns:
            List of (item, heat) tuples, sorted by heat descending.
        
        Raises:
            RuntimeError: If track_candidates=False
            ValueError: If k is not positive
        
        Example:
            >>> hm = HeatMap(track_candidates=True, decay_interval_seconds=0)
            >>> hm.add("hot", amount=100.0)
            >>> hm.add("cold", amount=1.0)
            >>> hm.top(1)
            [('hot', 100.0)]
        """
        if not self._track_candidates:
            raise RuntimeError(
                "top() requires track_candidates=True. "
                "Reinitialize HeatMap with track_candidates=True."
            )
        
        if not isinstance(k, int) or k <= 0:
            raise ValueError(f"k must be positive integer, got {k}")
        
        with self._lock:
            # Apply lazy decay if enabled
            if self._lazy_decay:
                self._apply_lazy_decay()
            
            if not self._candidates:
                return []
            
            # Sort candidates by heat
            sorted_items = sorted(
                self._candidates.values(),
                key=lambda c: -c.heat
            )
            
            return [(c.item, c.heat) for c in sorted_items[:k]]
    
    def is_hot(self, item, threshold: float = 1.0) -> bool:
        """
        Check if an item is "hot" (above threshold).
        
        Args:
            item: Item to check.
            threshold: Minimum heat to be considered hot. Must be non-negative.
        
        Returns:
            True if heat > threshold.
        
        Raises:
            ValueError: If threshold is negative.
        
        Example:
            >>> hm = HeatMap(decay_interval_seconds=0)
            >>> hm.add("topic", amount=100.0)
            >>> hm.is_hot("topic", threshold=50.0)
            True
        """
        if threshold < 0:
            raise ValueError(f"threshold must be non-negative, got {threshold}")
        
        return self.check(item) > threshold
    
    def stats(self) -> Dict[str, float | int]:
        """
        Get statistics about the HeatMap.
        
        Returns:
            Dictionary with statistics including:
            - slots: Number of slots (m)
            - hash_functions: Number of hash functions (k)
            - half_life_seconds: Half-life parameter
            - decay_interval_seconds: Decay interval
            - decay_factor: Decay multiplier
            - lazy_decay: Whether lazy decay is enabled
            - max_candidates: Maximum candidates (or None)
            - nonzero_slots: Number of non-zero slots
            - fill_rate: Fraction of non-zero slots
            - max_heat: Maximum heat value
            - mean_heat: Mean of non-zero heat values
            - candidates_tracked: Number of tracked candidates
            - decay_count: Total decay operations performed
            - memory_bytes: Estimated memory usage
        
        Example:
            >>> hm = HeatMap()
            >>> stats = hm.stats()
            >>> print(f"Memory: {stats['memory_bytes'] / 1024:.1f} KB")
        """
        with self._lock:
            nonzero = np.count_nonzero(self._heat)
            nonzero_heat = self._heat[self._heat > 0]
            
            return {
                'slots': self._m,
                'hash_functions': self._k,
                'half_life_seconds': self._half_life,
                'decay_interval_seconds': self._decay_interval,
                'decay_factor': self._decay_factor,
                'lazy_decay': self._lazy_decay,
                'max_candidates': self._max_candidates,
                'nonzero_slots': int(nonzero),
                'fill_rate': float(nonzero / self._m),
                'max_heat': float(np.max(self._heat)),
                'mean_heat': float(np.mean(nonzero_heat)) if len(nonzero_heat) > 0 else 0.0,
                'candidates_tracked': len(self._candidates),
                'decay_count': self._decay_count,
                'memory_bytes': self._heat.nbytes + len(self._candidates) * 100,
            }
    
    def reset(self) -> None:
        """
        Clear all heat values and candidates.
        
        Example:
            >>> hm = HeatMap(decay_interval_seconds=0)
            >>> hm.add("topic")
            >>> hm.reset()
            >>> hm.check("topic")
            0.0
        """
        with self._lock:
            self._heat.fill(0.0)
            self._candidates.clear()
            self._last_decay = time.time()
    
    def __len__(self) -> int:
        """Return number of tracked candidates."""
        return len(self._candidates)
    
    def __contains__(self, item) -> bool:
        """Check if an item has any heat."""
        return self.check(item) > 0
    
    def __repr__(self) -> str:
        """String representation."""
        return (
            f"HeatMap(m={self._m}, k={self._k}, "
            f"half_life={self._half_life}s, "
            f"candidates={len(self._candidates)})"
        )


class HierarchicalHeatMap:
    """
    A HeatMap with multiple time scales.
    
    Maintains multiple HeatMaps at different half-lives:
    - Short-term (fast decay) — captures spikes
    - Medium-term (medium decay) — captures sustained interest
    - Long-term (slow decay) — captures long-term popularity
    
    Combined score weights each level appropriately.
    
    Example:
        >>> hm = HierarchicalHeatMap(
        ...     half_lives=(10.0, 60.0, 300.0),
        ...     weights=(0.5, 0.3, 0.2)
        ... )
        >>> hm.add("topic")
        >>> levels = hm.check_levels("topic")
        >>> print(f"Short: {levels['short']}, Long: {levels['long']}")
        >>> hm.stop()
    """
    
    def __init__(
        self,
        capacity: int = 1_000_000,
        error_rate: float = 0.01,
        half_lives: Tuple[float, ...] = (10.0, 60.0, 300.0),
        weights: Optional[Tuple[float, ...]] = None,
        decay_interval_seconds: float = 1.0,
        track_candidates: bool = True,
        seed: Optional[int] = None
    ) -> None:
        """
        Initialize a HierarchicalHeatMap.
        
        Args:
            capacity: Expected number of unique items.
            error_rate: Desired false positive rate.
            half_lives: Tuple of half-lives in seconds (short to long).
            weights: Weights for each level. Default: equal weights.
            decay_interval_seconds: Auto-decay interval.
            track_candidates: Whether to track items for top-k.
            seed: Random seed.
        
        Raises:
            ValueError: If half_lives is empty or weights don't match.
        """
        # Initialize attributes needed by stop() / __del__ FIRST
        self._levels: List[HeatMap] = []
        self._lock = threading.RLock()
        
        if not half_lives:
            raise ValueError("half_lives must not be empty")
        
        self._half_lives: Tuple[float, ...] = half_lives
        self._num_levels: int = len(half_lives)
        
        if weights is None:
            self._weights: Tuple[float, ...] = tuple(
                1.0 / self._num_levels for _ in half_lives
            )
        else:
            if len(weights) != self._num_levels:
                raise ValueError(
                    f"weights length ({len(weights)}) must match "
                    f"half_lives length ({self._num_levels})"
                )
            if not all(w >= 0 for w in weights):
                raise ValueError("weights must be non-negative")
            total = sum(weights)
            if total <= 0:
                raise ValueError("sum of weights must be positive")
            self._weights = weights
        
        # Create one HeatMap per level
        for i, hl in enumerate(half_lives):
            hm = HeatMap(
                capacity=capacity,
                error_rate=error_rate,
                half_life_seconds=hl,
                decay_interval_seconds=decay_interval_seconds,
                track_candidates=track_candidates,
                seed=seed + i if seed is not None else None
            )
            self._levels.append(hm)
        
        self._track_candidates: bool = track_candidates
    
    @property
    def half_lives(self) -> Tuple[float, ...]:
        """Half-lives for each level."""
        return self._half_lives
    
    @property
    def weights(self) -> Tuple[float, ...]:
        """Weights for each level."""
        return self._weights
    
    @property
    def num_levels(self) -> int:
        """Number of levels."""
        return self._num_levels
    
    def stop(self) -> None:
        """Stop all background threads."""
        for hm in self._levels:
            hm.stop()
    
    def __del__(self) -> None:
        """Clean up on garbage collection."""
        self.stop()
    
    def __enter__(self) -> "HierarchicalHeatMap":
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.stop()
    
    def add(self, item, amount: float = 1.0) -> None:
        """
        Add heat to an item at all levels.
        
        Args:
            item: The item to add heat to.
            amount: Amount of heat to add. Default: 1.0
        """
        with self._lock:
            for hm in self._levels:
                hm.add(item, amount)
    
    def add_many(self, items: List, amount: float = 1.0) -> None:
        """
        Add heat to multiple items at all levels.
        
        Args:
            items: List of items to add heat to.
            amount: Amount of heat to add to each. Default: 1.0
        """
        with self._lock:
            for hm in self._levels:
                hm.add_many(items, amount)
    
    def check(self, item) -> float:
        """
        Get combined heat of an item.
        
        Returns weighted sum of heat at all levels.
        
        Args:
            item: The item to check.
        
        Returns:
            Combined heat value.
        """
        with self._lock:
            total_heat = 0.0
            for hm, w in zip(self._levels, self._weights):
                total_heat += w * hm.check(item)
            return total_heat
    
    def check_levels(self, item) -> Dict[str, float]:
        """
        Get heat at each level.
        
        Args:
            item: The item to check.
        
        Returns:
            Dict mapping level name to heat value.
            Keys are 'short', 'medium', 'long' (or 'level_0', etc. if more levels).
        """
        with self._lock:
            names = ['short', 'medium', 'long']
            result = {}
            
            for i, hm in enumerate(self._levels):
                if i < len(names):
                    name = names[i]
                else:
                    name = f'level_{i}'
                result[name] = hm.check(item)
            
            return result
    
    def top(self, k: int = 10) -> List[Tuple[str, float]]:
        """
        Get top-k hottest items by combined heat.
        
        Args:
            k: Number of items to return.
        
        Returns:
            List of (item, heat) tuples.
        
        Raises:
            RuntimeError: If track_candidates=False
        """
        if not self._track_candidates:
            raise RuntimeError(
                "top() requires track_candidates=True. "
                "Reinitialize HierarchicalHeatMap with track_candidates=True."
            )
        
        with self._lock:
            # Get candidates from first level
            candidates = set(self._levels[0]._candidates.keys())
            
            # Also check other levels
            for hm in self._levels[1:]:
                candidates.update(hm._candidates.keys())
            
            # Compute combined heat for each
            combined = []
            for item in candidates:
                heat = self.check(item)
                combined.append((item, heat))
            
            # Sort and return top k
            combined.sort(key=lambda x: -x[1])
            return combined[:k]
    
    def stats(self) -> Dict[str, float | int | List]:
        """Get statistics."""
        level_stats = [hm.stats() for hm in self._levels]
        
        return {
            'num_levels': self._num_levels,
            'half_lives': self._half_lives,
            'weights': self._weights,
            'levels': level_stats
        }
    
    def __repr__(self) -> str:
        """String representation."""
        return (
            f"HierarchicalHeatMap("
            f"levels={self._num_levels}, "
            f"half_lives={self._half_lives})"
        )
