"""
HeatMap Sketch - A probabilistic data structure for time-decayed popularity.

A data structure that answers: "What's hot RIGHT NOW?"

Example:
    >>> from heatmap_sketch import HeatMap
    >>> hm = HeatMap(half_life_seconds=60.0)
    >>> hm.add("#python")
    >>> hm.check("#python")
    1.0
"""

from heatmap_sketch.heatmap import HeatMap, HierarchicalHeatMap

__all__ = ["HeatMap", "HierarchicalHeatMap"]
__version__ = "1.0.0"
