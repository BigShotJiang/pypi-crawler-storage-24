"""
HeatMap: A Data Structure for Time-Decayed Popularity

A probabilistic data structure that tracks "heat" (time-decayed popularity) 
of items in a stream. Heat combines frequency and recency through exponential decay.

Mathematical Foundation:
    dH/dt = -λ·H + δ(item)
    
    Solution: H(t) = H(t₀)·e^(-λ(t-t₀)) + contributions

Reference: HEATMAP_DESIGN.md

Example:
    hm = HeatMap(capacity=1_000_000, half_life_seconds=60.0)
    hm.add("hashtag", timestamp=time.time())
    heat = hm.check("hashtag")
    trending = hm.top(10)
"""

import numpy as np
from typing import Optional, List, Tuple, Dict
import struct
import time
import threading
from dataclasses import dataclass


@dataclass
class HeatCandidate:
    """Tracks a candidate item for top-k enumeration."""
    item: str
    heat: float
    last_update: float


class HeatMap:
    """
    A data structure for tracking time-decayed popularity.
    
    Unlike a counting bloom filter (which stores static counts), HeatMap
    stores "heat" values that decay exponentially over time. This allows
    tracking what's popular RIGHT NOW, not what was popular historically.
    
    Attributes:
        m: Number of slots in the underlying array
        k: Number of hash functions
        half_life: Time for heat to decay by 50%
        decay_factor: Multiplier per decay (α = 0.5^(decay_interval/half_life))
    
    Operations:
        add(item): Add heat to an item
        check(item): Get current heat of an item
        top(k): Get top-k hottest items
        decay(): Apply time decay to all heat values
    """
    
    def __init__(
        self,
        capacity: int = 1_000_000,
        error_rate: float = 0.01,
        half_life_seconds: float = 60.0,
        decay_interval_seconds: float = 1.0,
        track_candidates: bool = True,
        seed: int = 42
    ):
        """
        Initialize a HeatMap.
        
        Args:
            capacity: Expected number of unique items (for sizing)
            error_rate: Desired false positive rate
            half_life_seconds: Time for heat to decay by 50%
            decay_interval_seconds: How often to auto-decay (0 = manual)
            track_candidates: Whether to track items for top-k queries
            seed: Random seed for hash functions
        """
        # Calculate optimal bloom parameters
        self.m = int(-capacity * np.log(error_rate) / (np.log(2) ** 2))
        self.k = int(self.m / capacity * np.log(2))
        self.k = max(1, min(self.k, 20))
        self.m = max(1024, self.m)
        
        # Decay parameters
        self.half_life = half_life_seconds
        self.decay_interval = decay_interval_seconds
        
        # α = 0.5^(Δt / half_life)
        # This ensures heat halves every half_life seconds
        if decay_interval_seconds > 0:
            self.decay_factor = 0.5 ** (decay_interval_seconds / half_life_seconds)
        else:
            self.decay_factor = 1.0  # No auto-decay
        
        # Core storage: float array for heat values
        self.heat = np.zeros(self.m, dtype=np.float64)
        
        # Candidate tracking for top-k queries
        self.track_candidates = track_candidates
        self._candidates: Dict[str, HeatCandidate] = {}
        
        # Hash seeds
        rng = np.random.default_rng(seed)
        self.hash_seeds = rng.integers(1, 2**32, size=self.k, dtype=np.uint64)
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Auto-decay thread
        self._running = False
        self._decay_thread: Optional[threading.Thread] = None
        self._last_decay = time.time()
        
        if decay_interval_seconds > 0:
            self._start_decay_thread()
    
    def _start_decay_thread(self):
        """Start the background decay thread."""
        self._running = True
        self._decay_thread = threading.Thread(target=self._decay_loop, daemon=True)
        self._decay_thread.start()
    
    def _decay_loop(self):
        """Background thread that applies decay periodically."""
        while self._running:
            time.sleep(self.decay_interval)
            if self._running:
                self.decay()
    
    def stop(self):
        """Stop the background decay thread."""
        self._running = False
        if self._decay_thread:
            self._decay_thread.join(timeout=1.0)
    
    def __del__(self):
        self.stop()
    
    def _hash_positions(self, item) -> np.ndarray:
        """Hash an item to k positions using double hashing."""
        item_bytes = str(item).encode('utf-8')
        data = item_bytes[:8].ljust(8, b'\x00')
        h1 = struct.unpack('<Q', data)[0]
        
        # Second hash for double hashing
        data2 = item_bytes[8:16].ljust(8, b'\x00')
        h2 = struct.unpack('<Q', data2)[0]
        h2 = max(1, h2)  # Ensure non-zero step
        
        positions = np.empty(self.k, dtype=np.intp)
        for i in range(self.k):
            # Double hashing: (h1 + i*h2) mod m
            pos = (h1 + i * h2) % self.m
            positions[i] = pos
        
        return positions
    
    def add(self, item, amount: float = 1.0, timestamp: Optional[float] = None) -> None:
        """
        Add heat to an item.
        
        Args:
            item: The item to add heat to
            amount: Amount of heat to add (default 1.0)
            timestamp: Optional timestamp (for lazy decay, not yet implemented)
        """
        with self._lock:
            positions = self._hash_positions(item)
            
            # Add heat to all k positions
            for pos in positions:
                self.heat[pos] += amount
            
            # Update candidate tracking
            if self.track_candidates:
                item_str = str(item)
                heat = self._estimate_heat(positions)
                now = time.time()
                
                if item_str in self._candidates:
                    self._candidates[item_str].heat = heat
                    self._candidates[item_str].last_update = now
                else:
                    self._candidates[item_str] = HeatCandidate(
                        item=item_str,
                        heat=heat,
                        last_update=now
                    )
    
    def add_many(self, items: List, amount: float = 1.0) -> None:
        """
        Add heat to multiple items efficiently.
        
        Args:
            items: List of items to add heat to
            amount: Amount of heat to add to each (default 1.0)
        """
        with self._lock:
            for item in items:
                positions = self._hash_positions(item)
                for pos in positions:
                    self.heat[pos] += amount
            
            # Update candidates
            if self.track_candidates:
                now = time.time()
                for item in items:
                    item_str = str(item)
                    positions = self._hash_positions(item)
                    heat = self._estimate_heat(positions)
                    
                    if item_str in self._candidates:
                        self._candidates[item_str].heat = heat
                        self._candidates[item_str].last_update = now
                    else:
                        self._candidates[item_str] = HeatCandidate(
                            item=item_str,
                            heat=heat,
                            last_update=now
                        )
    
    def _estimate_heat(self, positions: np.ndarray) -> float:
        """
        Estimate heat from positions.
        
        Uses minimum to reduce false positives (like Bloom filter).
        """
        return float(np.min(self.heat[positions]))
    
    def check(self, item) -> float:
        """
        Check the current heat of an item.
        
        Args:
            item: The item to check
            
        Returns:
            Current heat value (time-decayed popularity)
        """
        with self._lock:
            positions = self._hash_positions(item)
            
            # Return minimum (to reduce false positives)
            return self._estimate_heat(positions)
    
    def decay(self) -> None:
        """
        Apply exponential decay to all heat values.
        
        After decay, each heat value becomes:
            heat ← heat × decay_factor
        
        This is typically called automatically by the background thread.
        """
        with self._lock:
            # Apply decay to all heat values
            self.heat *= self.decay_factor
            self._last_decay = time.time()
            
            # Update candidate heat estimates
            if self.track_candidates:
                for item_str in list(self._candidates.keys()):
                    positions = self._hash_positions(item_str)
                    new_heat = self._estimate_heat(positions)
                    
                    if new_heat < 0.01:  # Remove cold items
                        del self._candidates[item_str]
                    else:
                        self._candidates[item_str].heat = new_heat
    
    def top(self, k: int = 10) -> List[Tuple[str, float]]:
        """
        Get the top-k hottest items.
        
        Args:
            k: Number of items to return
            
        Returns:
            List of (item, heat) tuples, sorted by heat descending
        """
        with self._lock:
            if not self.track_candidates:
                raise RuntimeError("top() requires track_candidates=True")
            
            # Sort candidates by heat
            sorted_items = sorted(
                self._candidates.values(),
                key=lambda c: -c.heat
            )
            
            return [(c.item, c.heat) for c in sorted_items[:k]]
    
    def is_hot(self, item, threshold: float = 1.0) -> bool:
        """
        Check if an item is "hot" (above threshold).
        
        Args:
            item: Item to check
            threshold: Minimum heat to be considered hot
            
        Returns:
            True if heat > threshold
        """
        return self.check(item) > threshold
    
    def stats(self) -> dict:
        """Get statistics about the HeatMap."""
        with self._lock:
            nonzero = np.count_nonzero(self.heat)
            return {
                'slots': self.m,
                'hash_functions': self.k,
                'half_life_seconds': self.half_life,
                'decay_interval_seconds': self.decay_interval,
                'decay_factor': self.decay_factor,
                'nonzero_slots': int(nonzero),
                'fill_rate': float(nonzero / self.m),
                'max_heat': float(np.max(self.heat)),
                'mean_heat': float(np.mean(self.heat[self.heat > 0])) if nonzero > 0 else 0.0,
                'candidates_tracked': len(self._candidates),
                'memory_bytes': self.heat.nbytes + len(self._candidates) * 100,
            }
    
    def reset(self) -> None:
        """Clear all heat values and candidates."""
        with self._lock:
            self.heat.fill(0)
            self._candidates.clear()
            self._last_decay = time.time()


class HierarchicalHeatMap:
    """
    A HeatMap with multiple time scales.
    
    Maintains multiple HeatMaps at different half-lives:
    - Short-term (fast decay) — captures spikes
    - Medium-term (medium decay) — captures sustained interest
    - Long-term (slow decay) — captures long-term popularity
    
    Combined score weights each level appropriately.
    """
    
    def __init__(
        self,
        capacity: int = 1_000_000,
        error_rate: float = 0.01,
        half_lives: Tuple[float, ...] = (10.0, 60.0, 300.0),
        weights: Optional[Tuple[float, ...]] = None,
        decay_interval_seconds: float = 1.0,
        track_candidates: bool = True,
        seed: int = 42
    ):
        """
        Initialize a HierarchicalHeatMap.
        
        Args:
            capacity: Expected number of unique items
            error_rate: Desired false positive rate
            half_lives: Tuple of half-lives in seconds (short, medium, long)
            weights: Weights for each level (default: equal weights)
            decay_interval_seconds: Auto-decay interval
            track_candidates: Whether to track items for top-k
            seed: Random seed
        """
        self.half_lives = half_lives
        self.num_levels = len(half_lives)
        
        if weights is None:
            self.weights = tuple(1.0 / self.num_levels for _ in half_lives)
        else:
            assert len(weights) == self.num_levels
            self.weights = weights
        
        # Create one HeatMap per level
        self.levels: List[HeatMap] = []
        for i, hl in enumerate(half_lives):
            hm = HeatMap(
                capacity=capacity,
                error_rate=error_rate,
                half_life_seconds=hl,
                decay_interval_seconds=decay_interval_seconds,
                track_candidates=track_candidates,
                seed=seed + i
            )
            self.levels.append(hm)
        
        self.track_candidates = track_candidates
        self._lock = threading.RLock()
    
    def stop(self):
        """Stop all background threads."""
        for hm in self.levels:
            hm.stop()
    
    def __del__(self):
        self.stop()
    
    def add(self, item, amount: float = 1.0) -> None:
        """Add heat to an item at all levels."""
        with self._lock:
            for hm in self.levels:
                hm.add(item, amount)
    
    def add_many(self, items: List, amount: float = 1.0) -> None:
        """Add heat to multiple items at all levels."""
        with self._lock:
            for hm in self.levels:
                hm.add_many(items, amount)
    
    def check(self, item) -> float:
        """
        Get combined heat of an item.
        
        Returns weighted sum of heat at all levels.
        """
        with self._lock:
            total_heat = 0.0
            for hm, w in zip(self.levels, self.weights):
                total_heat += w * hm.check(item)
            return total_heat
    
    def check_levels(self, item) -> Dict[str, float]:
        """
        Get heat at each level.
        
        Returns:
            Dict mapping level name to heat value
        """
        with self._lock:
            result = {}
            names = ['short', 'medium', 'long']
            for i, (hm, name) in enumerate(zip(self.levels, names[:self.num_levels])):
                result[name] = hm.check(item)
            return result
    
    def top(self, k: int = 10) -> List[Tuple[str, float]]:
        """
        Get top-k hottest items by combined heat.
        """
        with self._lock:
            if not self.track_candidates:
                raise RuntimeError("top() requires track_candidates=True")
            
            # Get candidates from first level
            candidates = set(self.levels[0]._candidates.keys())
            
            # Compute combined heat for each
            combined = []
            for item in candidates:
                heat = self.check(item)
                combined.append((item, heat))
            
            # Sort and return top k
            combined.sort(key=lambda x: -x[1])
            return combined[:k]
    
    def stats(self) -> dict:
        """Get statistics."""
        level_stats = [hm.stats() for hm in self.levels]
        return {
            'num_levels': self.num_levels,
            'half_lives': self.half_lives,
            'weights': self.weights,
            'levels': level_stats
        }
