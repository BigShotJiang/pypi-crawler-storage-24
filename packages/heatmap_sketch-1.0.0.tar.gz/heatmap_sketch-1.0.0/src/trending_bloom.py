"""
Decaying Counting Bloom Filter for Trend Detection

A probabilistic data structure that tracks item "heat" over time with automatic decay.
"""

import numpy as np
from typing import Optional, List, Tuple
import struct
import time


class TrendingBloom:
    """
    A counting bloom filter with exponential decay for trend detection.
    
    Operations:
    - add(item): Boost the item's count
    - add_many(items): Bulk add (vectorized, faster)
    - check(item): Get approximate current "heat" score
    - decay(): Apply time-based decay to all counters
    
    Properties:
    - O(k) add/check where k = number of hash functions
    - Memory efficient: uses numpy uint16 array
    - Time-aware via exponential decay
    """
    
    def __init__(
        self,
        capacity: int = 1_000_000,
        error_rate: float = 0.01,
        decay_rate: float = 0.95,
        decay_interval: float = 1.0,
        seed: int = 42
    ):
        # Calculate optimal parameters
        self.capacity = capacity
        self.error_rate = error_rate
        
        # m = number of bits/counters
        # k = number of hash functions
        self.m = int(-capacity * np.log(error_rate) / (np.log(2) ** 2))
        self.k = int(self.m / capacity * np.log(2))
        
        self.k = max(1, min(self.k, 20))
        self.m = max(1024, self.m)
        
        # Core storage - uint16 allows counts up to 65535
        self.counters = np.zeros(self.m, dtype=np.uint16)
        
        # Decay parameters
        self.decay_rate = decay_rate
        self.decay_interval = decay_interval
        self.last_decay = time.time()
        
        # Hash seeds
        rng = np.random.default_rng(seed)
        self.hash_seeds = rng.integers(1, 2**32, size=self.k, dtype=np.uint64)
    
    def _hash_single(self, data: bytes) -> np.ndarray:
        """Hash a single item to k positions."""
        data = data[:8].ljust(8, b'\x00')
        h = struct.unpack('<Q', data)[0]
        
        positions = np.empty(self.k, dtype=np.intp)
        for i in range(self.k):
            mixed = h ^ int(self.hash_seeds[i])
            mixed = (mixed * 0xff51afd7ed558ccd) & 0xFFFFFFFFFFFFFFFF
            mixed = ((mixed >> 33) | (mixed << 31)) & 0xFFFFFFFFFFFFFFFF
            mixed = (mixed * 0xc4ceb9fe1a85ec53) & 0xFFFFFFFFFFFFFFFF
            positions[i] = mixed % self.m
        
        return positions
    
    def _hash_many(self, items: List[bytes]) -> np.ndarray:
        """Hash multiple items to positions (n_items x k)."""
        n = len(items)
        positions = np.empty((n, self.k), dtype=np.intp)
        
        for i, item in enumerate(items):
            data = item[:8].ljust(8, b'\x00')
            h = struct.unpack('<Q', data)[0]
            
            for j in range(self.k):
                mixed = h ^ int(self.hash_seeds[j])
                mixed = (mixed * 0xff51afd7ed558ccd) & 0xFFFFFFFFFFFFFFFF
                mixed = ((mixed >> 33) | (mixed << 31)) & 0xFFFFFFFFFFFFFFFF
                mixed = (mixed * 0xc4ceb9fe1a85ec53) & 0xFFFFFFFFFFFFFFFF
                positions[i, j] = mixed % self.m
        
        return positions
    
    def _auto_decay(self):
        if self.decay_interval > 0:
            now = time.time()
            if now - self.last_decay >= self.decay_interval:
                self.decay()
    
    def add(self, item, count: int = 1) -> None:
        """Add a single item."""
        self._auto_decay()
        
        if not isinstance(item, bytes):
            item = str(item).encode('utf-8')
        
        positions = self._hash_single(item)
        np.add.at(self.counters, positions, count)
        self.counters = np.clip(self.counters, 0, 65535).astype(np.uint16)
    
    def add_many(self, items: List, count: int = 1) -> None:
        """
        Add multiple items efficiently (vectorized).
        Much faster than calling add() in a loop.
        """
        self._auto_decay()
        
        # Convert to bytes
        encoded = []
        for item in items:
            if isinstance(item, bytes):
                encoded.append(item)
            else:
                encoded.append(str(item).encode('utf-8'))
        
        # Get all positions
        all_positions = self._hash_many(encoded)
        
        # Increment all at once
        np.add.at(self.counters, all_positions.ravel(), count)
        self.counters = np.clip(self.counters, 0, 65535).astype(np.uint16)
    
    def check(self, item) -> int:
        """Check the current heat of an item."""
        self._auto_decay()
        
        if not isinstance(item, bytes):
            item = str(item).encode('utf-8')
        
        positions = self._hash_single(item)
        return int(np.min(self.counters[positions]))
    
    def check_many(self, items: List) -> List[int]:
        """Check heat of multiple items."""
        self._auto_decay()
        
        encoded = []
        for item in items:
            if isinstance(item, bytes):
                encoded.append(item)
            else:
                encoded.append(str(item).encode('utf-8'))
        
        all_positions = self._hash_many(encoded)
        results = [int(np.min(self.counters[pos])) for pos in all_positions]
        return results
    
    def decay(self, factor: Optional[float] = None) -> None:
        """Apply exponential decay to all counters."""
        factor = factor or self.decay_rate
        self.counters = (self.counters.astype(np.float64) * factor).astype(np.uint16)
        self.last_decay = time.time()
    
    def stats(self) -> dict:
        """Get statistics about the filter state."""
        nonzero = np.count_nonzero(self.counters)
        return {
            'total_slots': self.m,
            'hash_functions': self.k,
            'nonzero_slots': nonzero,
            'fill_rate': nonzero / self.m,
            'max_count': int(np.max(self.counters)),
            'mean_count': float(np.mean(self.counters[self.counters > 0])) if nonzero > 0 else 0,
            'memory_bytes': self.counters.nbytes
        }
    
    def reset(self) -> None:
        """Clear all counters."""
        self.counters.fill(0)
        self.last_decay = time.time()


class TrendingBloomWithCandidates:
    """
    Wrapper that tracks candidates for trend enumeration.
    Use when you need "what's trending?" not just "is X trending?"
    """
    
    def __init__(self, bloom: TrendingBloom):
        self.bloom = bloom
        self.candidates = {}  # item -> last_seen_time
    
    def add(self, item, count: int = 1) -> None:
        self.bloom.add(item, count)
        self.candidates[item] = time.time()
    
    def add_many(self, items: List, count: int = 1) -> None:
        self.bloom.add_many(items, count)
        now = time.time()
        for item in items:
            self.candidates[item] = now
    
    def check(self, item) -> int:
        return self.bloom.check(item)
    
    def get_trending(self, threshold: int, max_items: int = 100) -> List[Tuple]:
        """Get items above threshold, sorted by heat."""
        results = []
        for item in self.candidates:
            heat = self.bloom.check(item)
            if heat >= threshold:
                results.append((item, heat))
        
        results.sort(key=lambda x: -x[1])
        return results[:max_items]
    
    def prune_candidates(self, max_age_seconds: float = 3600) -> int:
        """Remove old candidates to save memory."""
        cutoff = time.time() - max_age_seconds
        before = len(self.candidates)
        self.candidates = {k: v for k, v in self.candidates.items() if v > cutoff}
        return before - len(self.candidates)
    
    def stats(self) -> dict:
        s = self.bloom.stats()
        s['candidates'] = len(self.candidates)
        return s
