"""
Numba-accelerated TrendingFilter for maximum performance.

This module provides a high-performance implementation using Numba JIT compilation.
Falls back to pure Python if Numba is not available.
"""

import numpy as np
from typing import Optional, List, Tuple, Dict
import struct
import time
import threading
from dataclasses import dataclass

try:
    from numba import jit, prange
    NUMBA_AVAILABLE = True
except ImportError:
    NUMBA_AVAILABLE = False
    
    def jit(*args, **kwargs):
        def decorator(func):
            return func
        return decorator
    
    prange = range


@jit(nopython=True, cache=True)
def _hash_positions_numba(h: int, seeds: np.ndarray, m: int) -> np.ndarray:
    """Numba-accelerated hash computation."""
    k = len(seeds)
    positions = np.empty(k, dtype=np.int64)
    
    c1 = 0xff51afd7ed558ccd
    c2 = 0xc4ceb9fe1a85ec53
    
    for i in range(k):
        mixed = h ^ int(seeds[i])
        mixed = (mixed * c1) & 0xFFFFFFFFFFFFFFFF
        mixed = ((mixed >> 33) | (mixed << 31)) & 0xFFFFFFFFFFFFFFFF
        mixed = (mixed * c2) & 0xFFFFFFFFFFFFFFFF
        positions[i] = mixed % m
    
    return positions


@jit(nopython=True, cache=True)
def _add_to_bloom_numba(counters: np.ndarray, positions: np.ndarray, count: int) -> np.ndarray:
    """Numba-accelerated add to bloom filter."""
    for i in range(len(positions)):
        new_val = counters[positions[i]] + count
        if new_val > 65535:
            new_val = 65535
        counters[positions[i]] = new_val
    return counters


@jit(nopython=True, cache=True)
def _check_bloom_numba(counters: np.ndarray, positions: np.ndarray) -> int:
    """Numba-accelerated bloom check."""
    min_val = 65535
    for i in range(len(positions)):
        if counters[positions[i]] < min_val:
            min_val = counters[positions[i]]
    return min_val


@jit(nopython=True, parallel=True, cache=True)
def _decay_bloom_numba(counters: np.ndarray, decay_factor: float) -> np.ndarray:
    """Numba-accelerated bloom decay."""
    for i in prange(len(counters)):
        counters[i] = int(counters[i] * decay_factor)
    return counters


@jit(nopython=True, cache=True)
def _hash_many_numba(hashes: np.ndarray, seeds: np.ndarray, m: int) -> np.ndarray:
    """Hash multiple items to positions."""
    n = len(hashes)
    k = len(seeds)
    positions = np.empty((n, k), dtype=np.int64)
    
    c1 = 0xff51afd7ed558ccd
    c2 = 0xc4ceb9fe1a85ec53
    
    for i in range(n):
        h = hashes[i]
        for j in range(k):
            mixed = h ^ int(seeds[j])
            mixed = (mixed * c1) & 0xFFFFFFFFFFFFFFFF
            mixed = ((mixed >> 33) | (mixed << 31)) & 0xFFFFFFFFFFFFFFFF
            mixed = (mixed * c2) & 0xFFFFFFFFFFFFFFFF
            positions[i, j] = mixed % m
    
    return positions


@dataclass
class TrendingItemFast:
    """Fast trending item tracking."""
    item: str
    raw_count: int
    decayed_count: float
    last_hit_time: float


class TrendingFilterFast:
    """
    High-performance TrendingFilter with Numba acceleration.
    
    Provides 10-100x speedup over pure Python for core operations.
    """
    
    def __init__(
        self,
        top_n: int = 10,
        decay_factor: float = 0.95,
        decay_interval_seconds: float = 1.0,
        error_rate: float = 0.01,
        expected_items: int = 100_000,
        seed: int = 42
    ):
        self.top_n = top_n
        self.decay_factor = decay_factor
        self.decay_interval = decay_interval_seconds
        self.error_rate = error_rate
        
        # Calculate bloom parameters
        self.m = int(-expected_items * np.log(error_rate) / (np.log(2) ** 2))
        self.k = int(self.m / expected_items * np.log(2))
        self.k = max(1, min(self.k, 20))
        self.m = max(1024, self.m)
        
        # Use int64 for numba compatibility
        self.counters = np.zeros(self.m, dtype=np.uint16)
        
        # Candidate tracking (Python, not performance-critical)
        self._candidates: Dict[str, TrendingItemFast] = {}
        
        # Hash seeds as int64 array for numba
        rng = np.random.default_rng(seed)
        self.hash_seeds = rng.integers(1, 2**32, size=self.k, dtype=np.int64)
        
        # Thread management
        self._lock = threading.RLock()
        self._running = False
        self._decay_thread: Optional[threading.Thread] = None
        
        if decay_interval_seconds > 0:
            self._start_decay_thread()
        
        self._numba_enabled = NUMBA_AVAILABLE
    
    def _start_decay_thread(self):
        self._running = True
        self._decay_thread = threading.Thread(target=self._decay_loop, daemon=True)
        self._decay_thread.start()
    
    def _decay_loop(self):
        while self._running:
            time.sleep(self.decay_interval)
            if self._running:
                self.decay()
    
    def stop(self):
        self._running = False
        if self._decay_thread:
            self._decay_thread.join(timeout=1.0)
    
    def __del__(self):
        self.stop()
    
    def _hash_item(self, item_str: str) -> np.ndarray:
        """Hash item to positions using Numba."""
        data = item_str.encode('utf-8')[:8].ljust(8, b'\x00')
        h = struct.unpack('<Q', data)[0]
        return _hash_positions_numba(h, self.hash_seeds, self.m)
    
    def add(self, item, count: int = 1) -> None:
        """Add item with Numba acceleration."""
        with self._lock:
            item_str = str(item) if not isinstance(item, str) else item
            positions = self._hash_item(item_str)
            
            # Use numba-accelerated add
            self.counters = _add_to_bloom_numba(self.counters, positions, count)
            
            # Update candidate tracking
            raw_count = int(_check_bloom_numba(self.counters, positions))
            now = time.time()
            
            if item_str in self._candidates:
                existing = self._candidates[item_str]
                existing.raw_count = raw_count
                existing.decayed_count += float(count)
                existing.last_hit_time = now
            else:
                self._candidates[item_str] = TrendingItemFast(
                    item=item_str,
                    raw_count=raw_count,
                    decayed_count=float(raw_count),
                    last_hit_time=now
                )
    
    def add_many(self, items: List, count: int = 1) -> None:
        """Bulk add with Numba acceleration."""
        with self._lock:
            # Hash all items
            item_strs = [str(item) if not isinstance(item, str) else item for item in items]
            
            # Compute hashes
            hashes = np.array([
                struct.unpack('<Q', s.encode('utf-8')[:8].ljust(8, b'\x00'))[0]
                for s in item_strs
            ], dtype=np.int64)
            
            positions = _hash_many_numba(hashes, self.hash_seeds, self.m)
            
            # Add all at once
            for pos in positions:
                self.counters = _add_to_bloom_numba(self.counters, pos, count)
            
            # Update candidates
            now = time.time()
            for item_str, pos in zip(item_strs, positions):
                raw_count = int(_check_bloom_numba(self.counters, pos))
                
                if item_str in self._candidates:
                    existing = self._candidates[item_str]
                    existing.raw_count = raw_count
                    existing.decayed_count += float(count)
                    existing.last_hit_time = now
                else:
                    self._candidates[item_str] = TrendingItemFast(
                        item=item_str,
                        raw_count=raw_count,
                        decayed_count=float(raw_count),
                        last_hit_time=now
                    )
    
    def check(self, item) -> Tuple[int, float]:
        """Check item heat."""
        with self._lock:
            item_str = str(item) if not isinstance(item, str) else item
            positions = self._hash_item(item_str)
            
            raw_count = int(_check_bloom_numba(self.counters, positions))
            
            if item_str in self._candidates:
                decayed = self._candidates[item_str].decayed_count
                return (raw_count, decayed)
            
            return (raw_count, float(raw_count))
    
    def decay(self) -> None:
        """Apply decay with Numba acceleration."""
        with self._lock:
            # Numba-accelerated decay
            self.counters = _decay_bloom_numba(self.counters, self.decay_factor)
            
            # Update candidates
            items_to_remove = []
            
            for item_str, tracked in self._candidates.items():
                tracked.decayed_count *= self.decay_factor
                
                positions = self._hash_item(item_str)
                tracked.raw_count = int(_check_bloom_numba(self.counters, positions))
                
                if tracked.decayed_count < 0.5 and tracked.raw_count == 0:
                    items_to_remove.append(item_str)
            
            for item_str in items_to_remove:
                del self._candidates[item_str]
    
    def get_trending(self, n: Optional[int] = None) -> List[Tuple[str, int, float]]:
        """Get top N trending items."""
        with self._lock:
            n = n or self.top_n
            
            sorted_items = sorted(
                self._candidates.items(),
                key=lambda x: (-x[1].decayed_count, -x[1].raw_count)
            )
            
            return [
                (item_str, tracked.raw_count, tracked.decayed_count)
                for item_str, tracked in sorted_items[:n]
            ]
    
    def stats(self) -> dict:
        """Get statistics."""
        with self._lock:
            nonzero = np.count_nonzero(self.counters)
            return {
                'top_n': self.top_n,
                'decay_factor': self.decay_factor,
                'bloom_slots': self.m,
                'hash_functions': self.k,
                'nonzero_slots': int(nonzero),
                'tracked_items': len(self._candidates),
                'numba_enabled': self._numba_enabled,
                'memory_bytes': self.counters.nbytes + len(self._candidates) * 100,
            }
    
    def reset(self) -> None:
        """Clear all data."""
        with self._lock:
            self.counters.fill(0)
            self._candidates.clear()
