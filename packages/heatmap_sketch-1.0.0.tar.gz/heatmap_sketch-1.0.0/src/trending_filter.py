"""
TrendingFilter - A competitive displacement bloom filter for trend detection.

Items compete for slots in the "top N" trending list. Decay is automatic.
Hot items stay because they keep getting boosted. Cold items fade away.
New trends naturally displace old ones.

Like a standard bloom filter, but for trending data with time-decay.
"""

import numpy as np
from typing import Optional, List, Tuple, Dict
import struct
import time
import threading
from dataclasses import dataclass, field
from collections import OrderedDict


@dataclass
class TrendingItem:
    """Represents a tracked trending item."""
    item: str
    raw_count: int
    last_decay_count: int  # count at last decay snapshot
    decayed_count: float
    last_hit_time: float


class TrendingFilter:
    """
    A bloom filter variant that tracks trending items with automatic decay.
    
    Items are added and compete for top-N slots. Decay happens automatically
    in a background thread. Old trends naturally fade; new ones rise.
    
    Example:
        tf = TrendingFilter(top_n=10, decay_factor=0.9, decay_interval_seconds=5.0)
        tf.add("#ai")
        tf.add("#python", count=5)
        tf.get_trending()  # Returns top 10
        tf.check("#ai")    # Returns (raw_count, decayed_count)
    """
    
    def __init__(
        self,
        top_n: int = 10,
        decay_factor: float = 0.95,
        decay_interval_seconds: float = 1.0,
        error_rate: float = 0.01,
        expected_items: int = 100_000,
        seed: int = 42
    ):
        """
        Initialize the TrendingFilter.
        
        Args:
            top_n: Number of trending items to track (default 10)
            decay_factor: Multiplier applied each decay cycle (0.95 = 5% loss)
            decay_interval_seconds: How often to decay (default 1 second)
            error_rate: Bloom filter false positive rate
            expected_items: Expected number of unique items for bloom sizing
            seed: Random seed for hash functions
        """
        self.top_n = top_n
        self.decay_factor = decay_factor
        self.decay_interval = decay_interval_seconds
        self.error_rate = error_rate
        self.seed = seed
        
        # Calculate bloom filter parameters
        # m = number of slots, k = number of hash functions
        self.m = int(-expected_items * np.log(error_rate) / (np.log(2) ** 2))
        self.k = int(self.m / expected_items * np.log(2))
        self.k = max(1, min(self.k, 20))
        self.m = max(1024, self.m)
        
        # Core bloom filter storage
        self.counters = np.zeros(self.m, dtype=np.uint16)
        
        # Track candidates for top-N enumeration
        self._candidates: Dict[str, TrendingItem] = OrderedDict()
        
        # Hash seeds
        rng = np.random.default_rng(seed)
        self.hash_seeds = rng.integers(1, 2**32, size=self.k, dtype=np.uint64)
        
        # Decay thread management
        self._decay_thread: Optional[threading.Thread] = None
        self._running = False
        self._lock = threading.RLock()
        self._last_decay_time = time.time()
        
        # Start auto-decay
        if decay_interval_seconds > 0:
            self._start_decay_thread()
    
    def _start_decay_thread(self):
        """Start the background decay thread."""
        self._running = True
        self._decay_thread = threading.Thread(target=self._decay_loop, daemon=True)
        self._decay_thread.start()
    
    def _decay_loop(self):
        """Background thread that applies decay periodically."""
        while self._running:
            time.sleep(self.decay_interval)
            if self._running:
                self.decay()
    
    def stop(self):
        """Stop the background decay thread."""
        self._running = False
        if self._decay_thread:
            self._decay_thread.join(timeout=1.0)
    
    def __del__(self):
        self.stop()
    
    def _hash_single(self, data: bytes) -> np.ndarray:
        """Hash a single item to k positions."""
        data = data[:8].ljust(8, b'\x00')
        h = struct.unpack('<Q', data)[0]
        
        positions = np.empty(self.k, dtype=np.intp)
        for i in range(self.k):
            mixed = h ^ int(self.hash_seeds[i])
            mixed = (mixed * 0xff51afd7ed558ccd) & 0xFFFFFFFFFFFFFFFF
            mixed = ((mixed >> 33) | (mixed << 31)) & 0xFFFFFFFFFFFFFFFF
            mixed = (mixed * 0xc4ceb9fe1a85ec53) & 0xFFFFFFFFFFFFFFFF
            positions[i] = mixed % self.m
        
        return positions
    
    def _hash_many(self, items: List[bytes]) -> np.ndarray:
        """Hash multiple items to positions (n_items x k)."""
        n = len(items)
        positions = np.empty((n, self.k), dtype=np.intp)
        
        for i, item in enumerate(items):
            data = item[:8].ljust(8, b'\x00')
            h = struct.unpack('<Q', data)[0]
            
            for j in range(self.k):
                mixed = h ^ int(self.hash_seeds[j])
                mixed = (mixed * 0xff51afd7ed558ccd) & 0xFFFFFFFFFFFFFFFF
                mixed = ((mixed >> 33) | (mixed << 31)) & 0xFFFFFFFFFFFFFFFF
                mixed = (mixed * 0xc4ceb9fe1a85ec53) & 0xFFFFFFFFFFFFFFFF
                positions[i, j] = mixed % self.m
        
        return positions
    
    def _get_bloom_count(self, item) -> int:
        """Get raw count from bloom filter."""
        if isinstance(item, bytes):
            positions = self._hash_single(item)
        else:
            positions = self._hash_single(str(item).encode('utf-8'))
        return int(np.min(self.counters[positions]))
    
    def add(self, item, count: int = 1) -> None:
        """
        Add an item (boost its heat).
        
        Args:
            item: Any hashable object (will be converted to string)
            count: Amount to increase (default 1)
        """
        with self._lock:
            item_str = str(item) if not isinstance(item, str) else item
            item_bytes = item_str.encode('utf-8')
            
            positions = self._hash_single(item_bytes)
            np.add.at(self.counters, positions, count)
            self.counters = np.clip(self.counters, 0, 65535).astype(np.uint16)
            
            # Update candidate tracking
            raw_count = int(np.min(self.counters[positions]))
            now = time.time()
            
            if item_str in self._candidates:
                # Update existing - add to decayed count
                existing = self._candidates[item_str]
                existing.raw_count = raw_count
                existing.decayed_count += float(count)  # Boost the decayed value
                existing.last_hit_time = now
            else:
                self._candidates[item_str] = TrendingItem(
                    item=item_str,
                    raw_count=raw_count,
                    last_decay_count=raw_count,
                    decayed_count=float(raw_count),
                    last_hit_time=now
                )
    
    def add_many(self, items: List, count: int = 1) -> None:
        """
        Add multiple items efficiently.
        
        Args:
            items: List of items to add
            count: Amount to increase each (default 1)
        """
        with self._lock:
            encoded = [str(item).encode('utf-8') for item in items]
            all_positions = self._hash_many(encoded)
            
            np.add.at(self.counters, all_positions.ravel(), count)
            self.counters = np.clip(self.counters, 0, 65535).astype(np.uint16)
            
            now = time.time()
            for item, positions in zip(items, all_positions):
                item_str = str(item) if not isinstance(item, str) else item
                raw_count = int(np.min(self.counters[positions]))
                
                if item_str in self._candidates:
                    existing = self._candidates[item_str]
                    existing.raw_count = raw_count
                    existing.decayed_count += float(count)
                    existing.last_hit_time = now
                else:
                    self._candidates[item_str] = TrendingItem(
                        item=item_str,
                        raw_count=raw_count,
                        last_decay_count=raw_count,
                        decayed_count=float(raw_count),
                        last_hit_time=now
                    )
    
    def check(self, item) -> Tuple[int, float]:
        """
        Check an item's current heat.
        
        Args:
            item: Item to check
            
        Returns:
            Tuple of (raw_count, decayed_count)
            raw_count is the bloom filter minimum
            decayed_count is the time-adjusted value
        """
        with self._lock:
            item_str = str(item) if not isinstance(item, str) else item
            
            raw_count = self._get_bloom_count(item)
            
            if item_str in self._candidates:
                decayed = self._candidates[item_str].decayed_count
                return (raw_count, decayed)
            
            return (raw_count, float(raw_count))
    
    def decay(self) -> None:
        """
        Apply decay to all tracked candidates.
        Called automatically by background thread.
        """
        with self._lock:
            self._last_decay_time = time.time()
            
            # Decay bloom filter counters
            self.counters = (self.counters.astype(np.float64) * self.decay_factor).astype(np.uint16)
            
            # Decay candidate tracking
            items_to_remove = []
            
            for item_str, tracked in self._candidates.items():
                # Apply decay to the tracked item
                tracked.decayed_count *= self.decay_factor
                
                # Update raw count from bloom
                raw = self._get_bloom_count(item_str)
                tracked.raw_count = raw
                
                # If decayed to near-zero, mark for removal
                if tracked.decayed_count < 0.5 and raw == 0:
                    items_to_remove.append(item_str)
            
            # Remove dead items
            for item_str in items_to_remove:
                del self._candidates[item_str]
    
    def get_trending(self, n: Optional[int] = None) -> List[Tuple[str, int, float]]:
        """
        Get top N trending items.
        
        Args:
            n: Number of items to return (default: self.top_n)
            
        Returns:
            List of (item, raw_count, decayed_count) tuples, sorted by decayed_count
        """
        with self._lock:
            n = n or self.top_n
            
            # Sort by decayed count
            sorted_items = sorted(
                self._candidates.items(),
                key=lambda x: (-x[1].decayed_count, -x[1].raw_count)
            )
            
            return [
                (item_str, tracked.raw_count, tracked.decayed_count)
                for item_str, tracked in sorted_items[:n]
            ]
    
    def stats(self) -> dict:
        """Get statistics about the filter."""
        with self._lock:
            nonzero = np.count_nonzero(self.counters)
            return {
                'top_n': self.top_n,
                'decay_factor': self.decay_factor,
                'decay_interval': self.decay_interval,
                'bloom_slots': self.m,
                'hash_functions': self.k,
                'nonzero_slots': int(nonzero),
                'fill_rate': float(nonzero / self.m),
                'max_count': int(np.max(self.counters)),
                'tracked_items': len(self._candidates),
                'memory_bytes': self.counters.nbytes + len(self._candidates) * 100,
            }
    
    def reset(self) -> None:
        """Clear all data."""
        with self._lock:
            self.counters.fill(0)
            self._candidates.clear()


class SlidingWindowTrendingFilter:
    """
    Alternative implementation using explicit sliding windows.
    
    Maintains multiple time buckets and rotates them.
    More memory but exact time boundaries.
    """
    
    def __init__(
        self,
        top_n: int = 10,
        num_windows: int = 6,
        window_seconds: float = 10.0,
        error_rate: float = 0.01,
        expected_items: int = 100_000,
        seed: int = 42,
        **kwargs  # Accept extra kwargs for compatibility
    ):
        """
        Initialize sliding window filter.
        
        Args:
            top_n: Number of trending items to track
            num_windows: Number of time windows
            window_seconds: Duration of each window
            error_rate: Bloom filter false positive rate
            expected_items: Expected unique items
            seed: Random seed
        """
        self.top_n = top_n
        self.num_windows = num_windows
        self.window_seconds = window_seconds
        self.error_rate = error_rate
        self.seed = seed
        
        # Create windows
        self._windows: List[TrendingFilter] = []
        for i in range(num_windows):
            tf = TrendingFilter(
                top_n=top_n * 3,  # Track more per window
                decay_factor=1.0,  # No decay within window
                decay_interval_seconds=0,  # Manual decay only
                error_rate=error_rate,
                expected_items=expected_items,
                seed=seed + i
            )
            self._windows.append(tf)
        
        self._current_window = 0
        self._last_rotation = time.time()
        self._lock = threading.RLock()
        
        # Start rotation thread
        self._running = True
        self._rotation_thread = threading.Thread(target=self._rotation_loop, daemon=True)
        self._rotation_thread.start()
    
    def _rotation_loop(self):
        """Background thread to rotate windows."""
        while self._running:
            time.sleep(self.window_seconds)
            if self._running:
                self._rotate_window()
    
    def _rotate_window(self):
        """Rotate to next window, clearing the oldest."""
        with self._lock:
            self._current_window = (self._current_window + 1) % self.num_windows
            self._windows[self._current_window].reset()
            self._last_rotation = time.time()
    
    def stop(self):
        """Stop background threads."""
        self._running = False
        if hasattr(self, '_windows'):
            for w in self._windows:
                w.stop()
    
    def __del__(self):
        self.stop()
    
    def add(self, item, count: int = 1) -> None:
        """Add item to current window."""
        with self._lock:
            self._windows[self._current_window].add(item, count)
    
    def add_many(self, items: List, count: int = 1) -> None:
        """Add multiple items to current window."""
        with self._lock:
            self._windows[self._current_window].add_many(items, count)
    
    def check(self, item) -> Tuple[int, float]:
        """
        Check item across all windows.
        
        Returns:
            Tuple of (sum_raw_count, weighted_decay_count)
        """
        with self._lock:
            total_raw = 0
            total_decayed = 0.0
            
            for i, window in enumerate(self._windows):
                raw, decayed = window.check(item)
                # Weight more recent windows higher
                weight = 1.0 - (i / self.num_windows) * 0.5
                total_raw += raw
                total_decayed += decayed * weight
            
            return (total_raw, total_decayed)
    
    def get_trending(self, n: Optional[int] = None) -> List[Tuple[str, int, float]]:
        """
        Get trending items aggregated across windows.
        
        Returns:
            List of (item, raw_count, weighted_count) tuples
        """
        with self._lock:
            n = n or self.top_n
            aggregated: Dict[str, Tuple[int, float]] = {}
            
            for window in self._windows:
                for item, raw, decayed in window.get_trending(self.top_n * 3):
                    if item in aggregated:
                        old_raw, old_decayed = aggregated[item]
                        aggregated[item] = (old_raw + raw, old_decayed + decayed)
                    else:
                        aggregated[item] = (raw, decayed)
            
            # Sort by weighted decayed count
            sorted_items = sorted(
                aggregated.items(),
                key=lambda x: -x[1][1]
            )
            
            return [
                (item, raw, decayed)
                for item, (raw, decayed) in sorted_items[:n]
            ]
    
    def stats(self) -> dict:
        """Get combined statistics."""
        with self._lock:
            window_stats = [w.stats() for w in self._windows]
            return {
                'num_windows': self.num_windows,
                'window_seconds': self.window_seconds,
                'current_window': self._current_window,
                'total_tracked': sum(s['tracked_items'] for s in window_stats),
                'windows': window_stats
            }
