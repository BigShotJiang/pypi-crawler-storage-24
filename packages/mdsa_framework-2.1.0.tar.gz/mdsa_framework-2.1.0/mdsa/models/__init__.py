"""
MDSA model package API.

Use lazy exports so importing lightweight config types does not load the full
transformers/torch stack.
"""

from importlib import import_module
from typing import Dict, Tuple

__all__ = [
    "ModelConfig",
    "QuantizationType",
    "ModelTier",
    "ModelLoader",
    "ModelRegistry",
    "ModelInfo",
    "ModelManager",
]

_LAZY_IMPORTS: Dict[str, Tuple[str, str]] = {
    "ModelConfig": ("mdsa.models.config", "ModelConfig"),
    "QuantizationType": ("mdsa.models.config", "QuantizationType"),
    "ModelTier": ("mdsa.models.config", "ModelTier"),
    "ModelLoader": ("mdsa.models.loader", "ModelLoader"),
    "ModelRegistry": ("mdsa.models.registry", "ModelRegistry"),
    "ModelInfo": ("mdsa.models.registry", "ModelInfo"),
    "ModelManager": ("mdsa.models.manager", "ModelManager"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'mdsa.models' has no attribute '{name}'")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value

