"""
MDSA RAG (Retrieval-Augmented Generation) Module

Contains local and global RAG systems, vector stores, and embedding management.

v2.1.0: Added UnifiedRAG for shared document storage across all apps.
"""

# Import RAG components from memory module (legacy)
try:
    from mdsa.memory.dual_rag import (
        DualRAG,
        LocalRAG,
        GlobalRAG,
        RAGDocument,
        RAGResult,
    )
    RAG_AVAILABLE = True
except ImportError as e:
    # RAG requires chromadb and sentence-transformers
    RAG_AVAILABLE = False
    DualRAG = None
    LocalRAG = None
    GlobalRAG = None
    RAGDocument = None
    RAGResult = None

# v2.1.0: Unified RAG system (replaces Dual RAG)
try:
    from mdsa.rag.unified_rag import (
        UnifiedRAG,
        get_unified_rag,
    )
    UNIFIED_RAG_AVAILABLE = True
except ImportError:
    UNIFIED_RAG_AVAILABLE = False
    UnifiedRAG = None
    get_unified_rag = None

__all__ = [
    # Legacy (backward compatible)
    "DualRAG",
    "LocalRAG",
    "GlobalRAG",
    "RAGDocument",
    "RAGResult",
    "RAG_AVAILABLE",
    # v2.1.0 Unified RAG
    "UnifiedRAG",
    "get_unified_rag",
    "UNIFIED_RAG_AVAILABLE",
]
