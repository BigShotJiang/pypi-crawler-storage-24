"""
MDSA utilities package API.

Avoid eager hardware detection on import by exposing utilities lazily.
"""

from importlib import import_module
from typing import Dict, Tuple

__all__ = [
    "HardwareDetector",
    "get_hardware_info",
    "ConfigLoader",
    "load_config",
    "setup_logger",
    "get_logger",
    "init_framework_logger",
    "timer",
    "measure_latency",
    "safe_import",
    "format_size",
    "truncate_string",
    "flatten_dict",
    "chunk_list",
    "retry",
    "Timer",
]

_LAZY_IMPORTS: Dict[str, Tuple[str, str]] = {
    "HardwareDetector": ("mdsa.utils.hardware", "HardwareDetector"),
    "get_hardware_info": ("mdsa.utils.hardware", "get_hardware_info"),
    "ConfigLoader": ("mdsa.utils.config_loader", "ConfigLoader"),
    "load_config": ("mdsa.utils.config_loader", "load_config"),
    "setup_logger": ("mdsa.utils.logger", "setup_logger"),
    "get_logger": ("mdsa.utils.logger", "get_logger"),
    "init_framework_logger": ("mdsa.utils.logger", "init_framework_logger"),
    "timer": ("mdsa.utils.helpers", "timer"),
    "measure_latency": ("mdsa.utils.helpers", "measure_latency"),
    "safe_import": ("mdsa.utils.helpers", "safe_import"),
    "format_size": ("mdsa.utils.helpers", "format_size"),
    "truncate_string": ("mdsa.utils.helpers", "truncate_string"),
    "flatten_dict": ("mdsa.utils.helpers", "flatten_dict"),
    "chunk_list": ("mdsa.utils.helpers", "chunk_list"),
    "retry": ("mdsa.utils.helpers", "retry"),
    "Timer": ("mdsa.utils.helpers", "Timer"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'mdsa.utils' has no attribute '{name}'")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value

