"""
Validation pipeline for MDSA orchestration.

Provides lightweight, deterministic validation checks for pre- and post-
execution workflow stages.
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple


BlockingSeverity = "blocking"
WarningSeverity = "warning"
InfoSeverity = "info"


@dataclass
class ValidationIssue:
    """A single validation finding."""

    code: str
    message: str
    severity: str = WarningSeverity
    validator: str = ""
    stage: str = "pre"
    location: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_blocking(self) -> bool:
        return self.severity == BlockingSeverity

    def to_dict(self) -> Dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "severity": self.severity,
            "validator": self.validator,
            "stage": self.stage,
            "location": self.location,
            "details": self.details,
            "blocking": self.is_blocking,
        }


@dataclass
class ValidationResult:
    """Aggregate validation result for a stage."""

    stage: str
    valid: bool = True
    issues: List[ValidationIssue] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def blocking_issues(self) -> List[ValidationIssue]:
        return [issue for issue in self.issues if issue.is_blocking]

    @property
    def warnings(self) -> List[ValidationIssue]:
        return [issue for issue in self.issues if issue.severity == WarningSeverity]

    @property
    def has_blocking_issues(self) -> bool:
        return bool(self.blocking_issues)

    @property
    def has_warnings(self) -> bool:
        return bool(self.warnings)

    def add_issue(self, issue: ValidationIssue) -> None:
        self.issues.append(issue)
        if issue.is_blocking:
            self.valid = False

    def extend(self, issues: Iterable[ValidationIssue]) -> None:
        for issue in issues:
            self.add_issue(issue)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "stage": self.stage,
            "valid": self.valid,
            "blocking": self.has_blocking_issues,
            "issue_count": len(self.issues),
            "blocking_issue_count": len(self.blocking_issues),
            "warning_count": len(self.warnings),
            "issues": [issue.to_dict() for issue in self.issues],
            "metadata": self.metadata,
        }


class BaseValidator(ABC):
    """Base class for deterministic validators."""

    name = "BaseValidator"
    stages: Tuple[str, ...] = ("pre", "post")

    @abstractmethod
    def validate(
        self,
        *,
        stage: str,
        query: Optional[str] = None,
        domain: Optional[str] = None,
        response: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> ValidationResult:
        raise NotImplementedError

    def supports(self, stage: str) -> bool:
        return stage in self.stages


class QuerySafetyValidator(BaseValidator):
    """Pre-validation for prompt and input safety."""

    name = "QuerySafetyValidator"
    stages = ("pre",)

    def __init__(
        self,
        max_length: int = 4000,
        banned_patterns: Optional[Sequence[str]] = None,
    ) -> None:
        self.max_length = max_length
        self.banned_patterns = [
            r"ignore (?:all |previous |any )instructions",
            r"disregard (?:all |previous )instructions",
            r"system prompt",
            r"developer message",
            r"reveal (?:the )?(?:system|developer) prompt",
            r"bypass (?:safety|guardrails)",
            r"you are now",
        ]
        if banned_patterns:
            self.banned_patterns.extend(banned_patterns)
        self._compiled_patterns = [re.compile(pattern, re.IGNORECASE) for pattern in self.banned_patterns]

    def validate(
        self,
        *,
        stage: str,
        query: Optional[str] = None,
        domain: Optional[str] = None,
        response: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> ValidationResult:
        result = ValidationResult(stage=stage)
        context = context or {}
        query_text = (query or "").strip()

        if not query_text:
            result.add_issue(
                ValidationIssue(
                    code="empty_query",
                    message="Query is empty.",
                    severity=BlockingSeverity,
                    validator=self.name,
                    stage=stage,
                )
            )
            return result

        if len(query_text) > self.max_length:
            result.add_issue(
                ValidationIssue(
                    code="query_too_long",
                    message=f"Query exceeds maximum length of {self.max_length} characters.",
                    severity=BlockingSeverity,
                    validator=self.name,
                    stage=stage,
                    details={"length": len(query_text), "max_length": self.max_length},
                )
            )

        matches = []
        for pattern in self._compiled_patterns:
            if pattern.search(query_text):
                matches.append(pattern.pattern)

        if matches:
            result.add_issue(
                ValidationIssue(
                    code="prompt_injection_suspected",
                    message="Query contains prompt-injection style instructions.",
                    severity=BlockingSeverity,
                    validator=self.name,
                    stage=stage,
                    details={"matched_patterns": matches},
                )
            )

        if result.valid:
            result.metadata.update(
                {
                    "query_length": len(query_text),
                    "contains_suspicious_patterns": bool(matches),
                }
            )

        return result


class DomainPolicyValidator(BaseValidator):
    """Validate that the domain is known and allowed."""

    name = "DomainPolicyValidator"
    stages = ("pre", "post")

    def __init__(
        self,
        known_domains_provider: Optional[Callable[[], Iterable[str]]] = None,
        allow_unknown_domain: bool = False,
    ) -> None:
        self.known_domains_provider = known_domains_provider
        self.allow_unknown_domain = allow_unknown_domain

    def _known_domains(self, context: Optional[Dict[str, Any]] = None) -> List[str]:
        context = context or {}
        if "known_domains" in context and context["known_domains"] is not None:
            return sorted({str(domain) for domain in context["known_domains"]})
        if self.known_domains_provider is not None:
            return sorted({str(domain) for domain in self.known_domains_provider()})
        return []

    def validate(
        self,
        *,
        stage: str,
        query: Optional[str] = None,
        domain: Optional[str] = None,
        response: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> ValidationResult:
        result = ValidationResult(stage=stage)
        context = context or {}
        known_domains = self._known_domains(context)
        candidate_domain = domain or context.get("planned_domain") or context.get("domain")

        planned_domains = context.get("planned_domains") or []
        if isinstance(planned_domains, str):
            planned_domains = [planned_domains]
        strict_planned_domains = bool(context.get("strict_planned_domains", False))

        if stage == "pre":
            if planned_domains and strict_planned_domains:
                unknown_planned = [item for item in planned_domains if known_domains and item not in known_domains]
                if unknown_planned:
                    result.add_issue(
                        ValidationIssue(
                            code="unknown_planned_domain",
                            message="One or more planned domains are not registered.",
                            severity=BlockingSeverity,
                            validator=self.name,
                            stage=stage,
                            details={
                                "planned_domains": list(planned_domains),
                                "unknown_domains": unknown_planned,
                                "known_domains": known_domains,
                            },
                        )
                    )
            elif candidate_domain is None:
                if not self.allow_unknown_domain:
                    result.add_issue(
                        ValidationIssue(
                            code="missing_domain",
                            message="No domain could be resolved for this request.",
                            severity=BlockingSeverity,
                            validator=self.name,
                            stage=stage,
                        )
                    )
            elif known_domains and candidate_domain not in known_domains and not self.allow_unknown_domain:
                result.add_issue(
                    ValidationIssue(
                        code="unknown_domain",
                        message="Resolved domain is not registered.",
                        severity=BlockingSeverity,
                        validator=self.name,
                        stage=stage,
                        details={
                            "domain": candidate_domain,
                            "known_domains": known_domains,
                        },
                    )
                )

        if stage == "post":
            response_domain = context.get("result_domain") or candidate_domain
            if known_domains and response_domain and response_domain not in known_domains and not self.allow_unknown_domain:
                result.add_issue(
                    ValidationIssue(
                        code="unknown_result_domain",
                        message="Result domain is not registered.",
                        severity=WarningSeverity,
                        validator=self.name,
                        stage=stage,
                        details={
                            "domain": response_domain,
                            "known_domains": known_domains,
                        },
                    )
                )

        if result.valid:
            result.metadata.update(
                {
                    "known_domains": known_domains,
                    "resolved_domain": candidate_domain,
                    "planned_domains": list(planned_domains),
                    "strict_planned_domains": strict_planned_domains,
                }
            )

        return result


class ResponseQualityValidator(BaseValidator):
    """Post-validation for generated responses."""

    name = "ResponseQualityValidator"
    stages = ("post",)

    def __init__(self, min_response_length: int = 20) -> None:
        self.min_response_length = min_response_length

    def validate(
        self,
        *,
        stage: str,
        query: Optional[str] = None,
        domain: Optional[str] = None,
        response: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> ValidationResult:
        result = ValidationResult(stage=stage)
        context = context or {}
        response_expected = bool(context.get("response_expected", True))
        response_text = (response or "").strip()

        if not response_expected:
            task_results = context.get("task_results")
            if task_results is not None and not task_results:
                result.add_issue(
                    ValidationIssue(
                        code="empty_task_results",
                        message="No task results were produced for a reasoning workflow.",
                        severity=WarningSeverity,
                        validator=self.name,
                        stage=stage,
                    )
                )
            result.metadata.update({"response_expected": False})
            return result

        if not response_text:
            result.add_issue(
                ValidationIssue(
                    code="missing_response",
                    message="No response text was produced.",
                    severity=BlockingSeverity,
                    validator=self.name,
                    stage=stage,
                )
            )
            return result

        if response_text.lower().startswith("error:"):
            result.add_issue(
                ValidationIssue(
                    code="response_error",
                    message="Model execution returned an error message instead of a usable response.",
                    severity=BlockingSeverity,
                    validator=self.name,
                    stage=stage,
                )
            )

        if len(response_text) < self.min_response_length:
            result.add_issue(
                ValidationIssue(
                    code="response_too_short",
                    message="Response is unusually short and should be reviewed.",
                    severity=WarningSeverity,
                    validator=self.name,
                    stage=stage,
                    details={"length": len(response_text), "min_length": self.min_response_length},
                )
            )

        query_text = (query or "").strip()
        if query_text and query_text[:80].lower() in response_text.lower():
            result.add_issue(
                ValidationIssue(
                    code="prompt_echo",
                    message="Response appears to echo the prompt.",
                    severity=WarningSeverity,
                    validator=self.name,
                    stage=stage,
                )
            )

        if result.valid:
            result.metadata.update(
                {
                    "response_length": len(response_text),
                    "response_expected": True,
                }
            )

        return result


class ValidationPipeline:
    """Execute validation stages with a pluggable validator set."""

    def __init__(
        self,
        validators: Optional[Sequence[BaseValidator]] = None,
        known_domains_provider: Optional[Callable[[], Iterable[str]]] = None,
    ) -> None:
        if validators is None:
            validators = (
                QuerySafetyValidator(),
                DomainPolicyValidator(known_domains_provider=known_domains_provider),
                ResponseQualityValidator(),
            )
        self.validators = list(validators)

    def _run_stage(
        self,
        stage: str,
        *,
        query: Optional[str] = None,
        domain: Optional[str] = None,
        response: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> ValidationResult:
        context = dict(context or {})
        result = ValidationResult(stage=stage)

        for validator in self.validators:
            if not validator.supports(stage):
                continue
            stage_result = validator.validate(
                stage=stage,
                query=query,
                domain=domain,
                response=response,
                context=context,
            )
            result.extend(stage_result.issues)
            if stage_result.metadata:
                result.metadata.setdefault(validator.name, stage_result.metadata)

        result.valid = not result.has_blocking_issues
        if not result.issues:
            result.metadata.setdefault("summary", f"{stage} validation passed")
        else:
            result.metadata.setdefault("summary", f"{stage} validation completed with findings")
        return result

    def validate_pre(
        self,
        query: str,
        domain: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> ValidationResult:
        return self._run_stage("pre", query=query, domain=domain, context=context)

    def validate_post(
        self,
        query: str,
        domain: Optional[str] = None,
        response: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> ValidationResult:
        return self._run_stage("post", query=query, domain=domain, response=response, context=context)
