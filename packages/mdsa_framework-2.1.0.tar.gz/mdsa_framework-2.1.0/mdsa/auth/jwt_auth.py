"""
JWT Authentication for MDSA Dashboard
Provides secure token-based authentication for admin features.
"""

import os
import sys
import jwt
import bcrypt
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from functools import wraps
from fastapi import HTTPException, Request, status
from fastapi.responses import RedirectResponse


# =================================================================
# ENVIRONMENT VALIDATION (Security Critical)
# =================================================================

REQUIRED_ENV_VARS = {
    'MDSA_ADMIN_PASSWORD': 'Admin password',
    'MDSA_JWT_SECRET': 'JWT signing secret',
}

_validation_done = False
_validation_warnings = []


def validate_environment(raise_on_error: bool = False) -> bool:
    """
    Ensure all required environment variables are set with non-default values.

    Args:
        raise_on_error: If True, raises RuntimeError instead of exiting

    Returns:
        True if validation passes, False otherwise
    """
    global _validation_done, _validation_warnings
    missing = []
    defaults = []

    # Check for missing vars
    for var, description in REQUIRED_ENV_VARS.items():
        value = os.getenv(var)
        if not value:
            missing.append(f"{var} ({description})")

    # Check for default/insecure values
    admin_password = os.getenv('MDSA_ADMIN_PASSWORD', '')
    if admin_password == 'mdsa_admin_2025':
        defaults.append('MDSA_ADMIN_PASSWORD is using default value "mdsa_admin_2025"')

    jwt_secret = os.getenv('MDSA_JWT_SECRET', '')
    if 'change-in-production' in jwt_secret:
        defaults.append('MDSA_JWT_SECRET is using default value')

    encryption_key = os.getenv('MDSA_ENCRYPTION_KEY', '')
    if 'change-in-production' in encryption_key:
        defaults.append('MDSA_ENCRYPTION_KEY is using default value')

    _validation_done = True
    _validation_warnings = defaults

    # Report errors only if there are missing vars
    if missing:
        error_msg = f"""
======================================================================
[SECURITY] MDSA SECURITY CONFIGURATION ERROR
======================================================================

[ERROR] Missing required environment variables:
{chr(10).join(f'   - {var}' for var in missing)}

[ACTION REQUIRED]
   1. Copy .env.example to .env in the project root
   2. Set secure values for all required variables
   3. Generate secrets with: openssl rand -hex 32
   4. Set a strong admin password (min 12 characters)
   5. Restart the MDSA dashboard

[EXAMPLE]
   export MDSA_ADMIN_PASSWORD='YourSecurePassword123!'
   export MDSA_JWT_SECRET=$(openssl rand -hex 32)
   export MDSA_ENCRYPTION_KEY=$(openssl rand -hex 32)
======================================================================
"""
        if raise_on_error:
            raise RuntimeError(error_msg)
        print(error_msg)
        return False

    return True


def ensure_environment():
    """
    Ensure environment is validated before using auth functions.
    Called lazily when auth functions are first used.
    """
    if not _validation_done:
        if not validate_environment():
            sys.exit(1)


# NOTE: Validation is NOT called on import to allow library usage and testing.
# It is called lazily when auth functions are actually used.
# For dashboard startup, call validate_environment() explicitly.

# =================================================================
# JWT CONFIGURATION
# =================================================================

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 480  # 8 hours


def _get_secret_key() -> str:
    """Get JWT secret key, ensuring environment is validated."""
    ensure_environment()
    key = os.getenv('MDSA_JWT_SECRET')
    if not key:
        raise RuntimeError("MDSA_JWT_SECRET not set")
    return key


def _get_admin_credentials() -> tuple:
    """Get admin username and password."""
    ensure_environment()
    username = os.getenv('MDSA_ADMIN_USERNAME', 'admin')
    password = os.getenv('MDSA_ADMIN_PASSWORD')
    return username, password


# For backward compatibility (lazy evaluation)
SECRET_KEY = None  # Will be set on first use
DEFAULT_ADMIN_USERNAME = None
DEFAULT_ADMIN_PASSWORD = None


def hash_password(password: str) -> str:
    """
    Hash a password using bcrypt (secure, with automatic salt).

    Args:
        password: Plain text password

    Returns:
        Bcrypt hash as string
    """
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify a password against a bcrypt hash.

    Args:
        plain_password: Plain text password to verify
        hashed_password: Bcrypt hash to verify against

    Returns:
        True if password matches, False otherwise
    """
    try:
        return bcrypt.checkpw(
            plain_password.encode('utf-8'),
            hashed_password.encode('utf-8')
        )
    except Exception:
        return False


def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    """
    Create a JWT access token.

    Args:
        data: Data to encode in the token
        expires_delta: Optional expiration time delta

    Returns:
        Encoded JWT token
    """
    to_encode = data.copy()

    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)

    to_encode.update({"exp": expire})
    secret_key = _get_secret_key()
    encoded_jwt = jwt.encode(to_encode, secret_key, algorithm=ALGORITHM)

    return encoded_jwt


def verify_token(token: str) -> Optional[Dict[str, Any]]:
    """
    Verify and decode a JWT token.

    Args:
        token: JWT token to verify

    Returns:
        Decoded token data if valid, None otherwise
    """
    try:
        secret_key = _get_secret_key()
        payload = jwt.decode(token, secret_key, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.JWTError:
        return None


def authenticate_user(username: str, password: str) -> Optional[Dict[str, str]]:
    """
    Authenticate a user with username and password.

    Args:
        username: Username
        password: Password

    Returns:
        User data if authenticated, None otherwise
    """
    # Check against admin credentials from environment
    admin_username, admin_password = _get_admin_credentials()

    if username == admin_username:
        # Simple comparison - for single admin user
        # In production, you would store bcrypt hashes in a database
        if password == admin_password:
            return {
                "username": username,
                "role": "admin",
                "name": "MDSA Administrator"
            }

    # TODO: Add database-based user authentication for production
    # Store users with bcrypt hashed passwords in database:
    # user = db.get_user(username)
    # if user and verify_password(password, user.password_hash):
    #     return user

    return None


def get_current_user_from_cookie(request: Request) -> Optional[Dict[str, Any]]:
    """
    Get the current user from the JWT cookie.

    Args:
        request: FastAPI request object

    Returns:
        User data if authenticated, None otherwise
    """
    token = request.cookies.get("access_token")

    if not token:
        return None

    # Remove "Bearer " prefix if present
    if token.startswith("Bearer "):
        token = token[7:]

    payload = verify_token(token)

    if payload is None:
        return None

    return payload


def require_auth(redirect_to_login: bool = True):
    """
    Decorator to require authentication for a route.

    Args:
        redirect_to_login: If True, redirect to login page. If False, raise 401.

    Usage:
        @app.get("/admin/rag")
        @require_auth()
        async def rag_admin(request: Request):
            ...
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(request: Request, *args, **kwargs):
            user = get_current_user_from_cookie(request)

            if user is None:
                if redirect_to_login:
                    return RedirectResponse(
                        url=f"/login?next={request.url.path}",
                        status_code=status.HTTP_302_FOUND
                    )
                else:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Not authenticated"
                    )

            # Add user to request state
            request.state.user = user

            return await func(request, *args, **kwargs)

        return wrapper
    return decorator


def require_admin():
    """
    Decorator to require admin role for a route.

    Usage:
        @app.delete("/admin/tools/{tool_id}")
        @require_admin()
        async def delete_tool(request: Request, tool_id: str):
            ...
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(request: Request, *args, **kwargs):
            user = get_current_user_from_cookie(request)

            if user is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Not authenticated"
                )

            if user.get("role") != "admin":
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Admin access required"
                )

            # Add user to request state
            request.state.user = user

            return await func(request, *args, **kwargs)

        return wrapper
    return decorator


# Session management
class SessionManager:
    """Manage user sessions."""

    def __init__(self):
        self.active_sessions: Dict[str, Dict[str, Any]] = {}

    def create_session(self, username: str, token: str) -> None:
        """Create a new session."""
        self.active_sessions[username] = {
            "token": token,
            "created_at": datetime.utcnow(),
            "last_active": datetime.utcnow()
        }

    def update_activity(self, username: str) -> None:
        """Update last activity time."""
        if username in self.active_sessions:
            self.active_sessions[username]["last_active"] = datetime.utcnow()

    def invalidate_session(self, username: str) -> None:
        """Invalidate a session."""
        if username in self.active_sessions:
            del self.active_sessions[username]

    def is_session_valid(self, username: str, token: str) -> bool:
        """Check if a session is valid."""
        if username not in self.active_sessions:
            return False

        session = self.active_sessions[username]

        # Check if token matches
        if session["token"] != token:
            return False

        # Check if session is expired (24 hours)
        if (datetime.utcnow() - session["created_at"]).total_seconds() > 86400:
            self.invalidate_session(username)
            return False

        return True


# Global session manager instance
session_manager = SessionManager()
