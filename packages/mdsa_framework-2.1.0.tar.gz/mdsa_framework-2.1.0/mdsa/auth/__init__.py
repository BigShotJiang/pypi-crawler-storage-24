"""
MDSA Authentication Module (secure-first).

This package exposes the database-backed auth system as the canonical runtime
path. Legacy helper names are retained as compatibility wrappers.
"""

from __future__ import annotations

from datetime import timedelta
from functools import wraps
from typing import Any, Dict, Optional

from .secure_auth import (
    SecureSecrets,
    get_secrets,
    hash_password,
    verify_password,
    create_access_token as secure_create_token,
    verify_token as secure_verify_token,
    authenticate_user as secure_authenticate_user,
    create_user,
    change_password,
    create_session,
    revoke_session,
    is_session_valid,
    cleanup_expired_sessions,
    get_current_user,
    normalize_role,
    is_valid_role,
    has_required_role,
    has_any_role,
)

secure_hash_password = hash_password
secure_verify_password = verify_password


def create_access_token(
    data: Dict[str, Any],
    expires_delta: Optional[timedelta] = None,
) -> str:
    """
    Backward-compatible token helper using secure auth internals.

    Expected keys in `data`: `user_id`, `username` (or `sub`), and `role`.
    """
    user_id = data.get("user_id")
    if user_id is None:
        raise ValueError("create_access_token requires 'user_id' in payload")

    username = str(data.get("username") or data.get("sub") or "")
    if not username:
        raise ValueError("create_access_token requires 'username' or 'sub' in payload")

    role = normalize_role(str(data.get("role") or "viewer"))

    return secure_create_token(
        user_id=int(user_id),
        username=username,
        role=role,
        expires_delta=expires_delta,
    )


def verify_token(token: str) -> Optional[Dict[str, Any]]:
    """Backward-compatible alias for secure token verification."""
    return secure_verify_token(token)


def authenticate_user(username: str, password: str, db) -> Optional[Dict[str, Any]]:
    """Backward-compatible alias for secure DB-backed authentication."""
    return secure_authenticate_user(username, password, db)


def get_current_user_from_cookie(request) -> Optional[Dict[str, Any]]:
    """
    Compatibility helper to resolve user from `access_token` cookie.
    """
    token = request.cookies.get("access_token")
    if not token:
        return None

    if token.startswith("Bearer "):
        token = token[7:]

    from mdsa.core.db.connection import get_session

    db = get_session()
    try:
        return get_current_user(token, db)
    finally:
        db.close()


def require_auth(redirect_to_login: bool = True):
    """
    Compatibility decorator that enforces authenticated session cookies.
    """
    from fastapi import HTTPException, status
    from fastapi.responses import RedirectResponse

    def decorator(func):
        @wraps(func)
        async def wrapper(request, *args, **kwargs):
            user = get_current_user_from_cookie(request)
            if user is None:
                if redirect_to_login:
                    return RedirectResponse(
                        url=f"/login?next={request.url.path}",
                        status_code=status.HTTP_302_FOUND,
                    )
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Not authenticated",
                )

            request.state.user = user
            return await func(request, *args, **kwargs)

        return wrapper

    return decorator


def require_admin():
    """
    Compatibility decorator for privileged routes.
    Accepts `admin` and `owner` roles.
    """
    from fastapi import HTTPException, status

    def decorator(func):
        @wraps(func)
        async def wrapper(request, *args, **kwargs):
            user = get_current_user_from_cookie(request)
            if user is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Not authenticated",
                )

            if not has_required_role(user.get("role", ""), "admin"):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Admin access required",
                )

            request.state.user = user
            return await func(request, *args, **kwargs)

        return wrapper

    return decorator


class _SessionManagerCompatibility:
    """
    Legacy in-memory session manager compatibility shim.

    Runtime authorization uses DB-backed sessions in secure_auth.
    """

    def __init__(self):
        self.active_sessions: Dict[str, Dict[str, Any]] = {}

    def create_session(self, username: str, token: str) -> None:
        self.active_sessions[username] = {"token": token}

    def update_activity(self, username: str) -> None:
        return None

    def invalidate_session(self, username: str) -> None:
        self.active_sessions.pop(username, None)

    def is_session_valid(self, username: str, token: str) -> bool:
        cached = self.active_sessions.get(username, {})
        return cached.get("token") == token


session_manager = _SessionManagerCompatibility()

__all__ = [
    "create_access_token",
    "verify_token",
    "authenticate_user",
    "get_current_user_from_cookie",
    "require_auth",
    "require_admin",
    "session_manager",
    "hash_password",
    "verify_password",
    "secure_hash_password",
    "secure_verify_password",
    "SecureSecrets",
    "get_secrets",
    "secure_create_token",
    "secure_verify_token",
    "secure_authenticate_user",
    "create_user",
    "change_password",
    "create_session",
    "revoke_session",
    "is_session_valid",
    "cleanup_expired_sessions",
    "get_current_user",
    "normalize_role",
    "is_valid_role",
    "has_required_role",
    "has_any_role",
]
