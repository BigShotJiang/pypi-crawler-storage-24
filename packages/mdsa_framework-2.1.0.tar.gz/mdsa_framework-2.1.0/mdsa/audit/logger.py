"""
Append-only audit log with hash-chain integrity markers.
"""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

from mdsa.core.config import get_data_dir


@dataclass
class AuditEvent:
    """Immutable audit event."""

    event_id: str
    timestamp: str
    actor: str
    action: str
    resource: str
    outcome: str
    details: Dict[str, Any] = field(default_factory=dict)
    previous_hash: str = ""
    event_hash: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class AuditLogger:
    """Append-only JSONL audit writer with hash chaining."""

    def __init__(self, log_path: Optional[Path] = None) -> None:
        base_dir = Path(log_path).parent if log_path else get_data_dir() / "audit"
        file_path = Path(log_path) if log_path else base_dir / "events.jsonl"
        base_dir.mkdir(parents=True, exist_ok=True)
        self.log_path = file_path

    def log(
        self,
        *,
        actor: str,
        action: str,
        resource: str,
        outcome: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> AuditEvent:
        previous_hash = self._last_hash()
        event = AuditEvent(
            event_id=str(uuid.uuid4()),
            timestamp=datetime.now(timezone.utc).isoformat(),
            actor=actor,
            action=action,
            resource=resource,
            outcome=outcome,
            details=details or {},
            previous_hash=previous_hash,
        )
        event.event_hash = self._compute_hash(event)
        self._append(event)
        return event

    def verify_chain(self) -> bool:
        previous_hash = ""
        for event in self.iter_events():
            if event.previous_hash != previous_hash:
                return False
            if self._compute_hash(event) != event.event_hash:
                return False
            previous_hash = event.event_hash
        return True

    def iter_events(self) -> Iterable[AuditEvent]:
        if not self.log_path.exists():
            return []
        events = []
        with self.log_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    # Keep audit stream readable even if a partial/corrupt line exists.
                    continue
                events.append(AuditEvent(**payload))
        return events

    def _append(self, event: AuditEvent) -> None:
        payload = event.to_dict()
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=True) + os.linesep)

    def _last_hash(self) -> str:
        events = list(self.iter_events())
        if not events:
            return ""
        return events[-1].event_hash

    @staticmethod
    def _compute_hash(event: AuditEvent) -> str:
        data = {
            "event_id": event.event_id,
            "timestamp": event.timestamp,
            "actor": event.actor,
            "action": event.action,
            "resource": event.resource,
            "outcome": event.outcome,
            "details": event.details,
            "previous_hash": event.previous_hash,
        }
        canonical = json.dumps(data, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()
