"""
MDSA core package API.

Uses lazy imports to avoid pulling optional heavyweight dependencies when only
config/schema utilities are needed.
"""

from importlib import import_module
from typing import Dict, Tuple

__all__ = [
    "MDSA",
    "TinyBERTOrchestrator",
    "IntentRouter",
    "StateMachine",
    "WorkflowState",
    "MessageBus",
    "Message",
    "MessageType",
    "MDSAConfig",
    "get_config",
    "reload_config",
    "is_production",
    "is_development",
    "get_database_url",
    "get_data_dir",
    "MDSAError",
    "AuthenticationError",
    "AuthorizationError",
    "AppError",
    "AppNotFoundError",
    "RAGError",
    "ConfigurationError",
    "RateLimitError",
    "setup_logging",
    "get_logger",
    "LogContext",
    "set_request_id",
    "RateLimiter",
    "rate_limit_sync",
    "rate_limit_async",
    "LoginRequest",
    "AppRegistration",
    "QueryRequest",
    "DocumentUpload",
]

_LAZY_IMPORTS: Dict[str, Tuple[str, str]] = {
    "MDSA": ("mdsa.core.orchestrator", "MDSA"),
    "TinyBERTOrchestrator": ("mdsa.core.orchestrator", "TinyBERTOrchestrator"),
    "IntentRouter": ("mdsa.core.router", "IntentRouter"),
    "StateMachine": ("mdsa.core.state_machine", "StateMachine"),
    "WorkflowState": ("mdsa.core.state_machine", "WorkflowState"),
    "MessageBus": ("mdsa.core.communication_bus", "MessageBus"),
    "Message": ("mdsa.core.communication_bus", "Message"),
    "MessageType": ("mdsa.core.communication_bus", "MessageType"),
    "MDSAConfig": ("mdsa.core.config", "MDSAConfig"),
    "get_config": ("mdsa.core.config", "get_config"),
    "reload_config": ("mdsa.core.config", "reload_config"),
    "is_production": ("mdsa.core.config", "is_production"),
    "is_development": ("mdsa.core.config", "is_development"),
    "get_database_url": ("mdsa.core.config", "get_database_url"),
    "get_data_dir": ("mdsa.core.config", "get_data_dir"),
    "MDSAError": ("mdsa.core.exceptions", "MDSAError"),
    "AuthenticationError": ("mdsa.core.exceptions", "AuthenticationError"),
    "AuthorizationError": ("mdsa.core.exceptions", "AuthorizationError"),
    "AppError": ("mdsa.core.exceptions", "AppError"),
    "AppNotFoundError": ("mdsa.core.exceptions", "AppNotFoundError"),
    "RAGError": ("mdsa.core.exceptions", "RAGError"),
    "ConfigurationError": ("mdsa.core.exceptions", "ConfigurationError"),
    "RateLimitError": ("mdsa.core.exceptions", "RateLimitError"),
    "setup_logging": ("mdsa.core.logging_config", "setup_logging"),
    "get_logger": ("mdsa.core.logging_config", "get_logger"),
    "LogContext": ("mdsa.core.logging_config", "LogContext"),
    "set_request_id": ("mdsa.core.logging_config", "set_request_id"),
    "RateLimiter": ("mdsa.core.rate_limit", "RateLimiter"),
    "rate_limit_sync": ("mdsa.core.rate_limit", "rate_limit_sync"),
    "rate_limit_async": ("mdsa.core.rate_limit", "rate_limit_async"),
    "LoginRequest": ("mdsa.core.validation", "LoginRequest"),
    "AppRegistration": ("mdsa.core.validation", "AppRegistration"),
    "QueryRequest": ("mdsa.core.validation", "QueryRequest"),
    "DocumentUpload": ("mdsa.core.validation", "DocumentUpload"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'mdsa.core' has no attribute '{name}'")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
