"""
MDSA Rate Limiting Module

Provides rate limiting to prevent brute force attacks and API abuse.

Features:
- Per-endpoint rate limits
- Per-IP and per-user limiting
- Configurable limits via environment variables
- In-memory and Redis backends

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.1.0
"""

import os
import time
import logging
from typing import Dict, Optional, Callable, Any
from functools import wraps
from collections import defaultdict
from datetime import datetime, timedelta
import threading

logger = logging.getLogger(__name__)

# Try to import slowapi for production use
try:
    from slowapi import Limiter
    from slowapi.util import get_remote_address
    from slowapi.errors import RateLimitExceeded
    SLOWAPI_AVAILABLE = True
except ImportError:
    SLOWAPI_AVAILABLE = False
    logger.info("slowapi not installed. Using built-in rate limiter.")


# ============================================
# CONFIGURATION
# ============================================

class RateLimitConfig:
    """Rate limiting configuration from environment variables"""

    # Default limits (requests per minute)
    LOGIN_LIMIT = int(os.getenv("MDSA_RATE_LIMIT_LOGIN", "5"))  # 5/min
    API_LIMIT = int(os.getenv("MDSA_RATE_LIMIT_API", "60"))  # 60/min
    UPLOAD_LIMIT = int(os.getenv("MDSA_RATE_LIMIT_UPLOAD", "10"))  # 10/min
    QUERY_LIMIT = int(os.getenv("MDSA_RATE_LIMIT_QUERY", "30"))  # 30/min

    # Time windows (in seconds)
    DEFAULT_WINDOW = 60  # 1 minute

    # Enable/disable
    ENABLED = os.getenv("MDSA_RATE_LIMIT_ENABLED", "true").lower() == "true"


# ============================================
# BUILT-IN RATE LIMITER (No Dependencies)
# ============================================

class InMemoryRateLimiter:
    """
    Simple in-memory rate limiter using sliding window.

    Thread-safe implementation for single-process deployments.
    For multi-process/distributed deployments, use Redis backend.
    """

    def __init__(self):
        self._requests: Dict[str, list] = defaultdict(list)
        self._lock = threading.Lock()
        self._cleanup_interval = 60  # Cleanup old entries every 60 seconds
        self._last_cleanup = time.time()

    def _cleanup_old_entries(self):
        """Remove expired entries to prevent memory growth"""
        current_time = time.time()
        if current_time - self._last_cleanup < self._cleanup_interval:
            return

        with self._lock:
            cutoff = current_time - 300  # Keep last 5 minutes
            for key in list(self._requests.keys()):
                self._requests[key] = [
                    ts for ts in self._requests[key] if ts > cutoff
                ]
                if not self._requests[key]:
                    del self._requests[key]
            self._last_cleanup = current_time

    def is_allowed(self, key: str, limit: int, window: int = 60) -> bool:
        """
        Check if request is allowed under rate limit.

        Args:
            key: Unique identifier (e.g., IP address, user ID)
            limit: Maximum requests allowed in window
            window: Time window in seconds

        Returns:
            True if allowed, False if rate limited
        """
        self._cleanup_old_entries()

        current_time = time.time()
        cutoff = current_time - window

        with self._lock:
            # Remove old requests outside window
            self._requests[key] = [
                ts for ts in self._requests[key] if ts > cutoff
            ]

            # Check if under limit
            if len(self._requests[key]) < limit:
                self._requests[key].append(current_time)
                return True

            return False

    def get_remaining(self, key: str, limit: int, window: int = 60) -> int:
        """Get remaining requests in current window"""
        current_time = time.time()
        cutoff = current_time - window

        with self._lock:
            recent = [ts for ts in self._requests[key] if ts > cutoff]
            return max(0, limit - len(recent))

    def get_reset_time(self, key: str, window: int = 60) -> int:
        """Get seconds until rate limit resets"""
        with self._lock:
            if not self._requests[key]:
                return 0
            oldest = min(self._requests[key])
            reset = oldest + window - time.time()
            return max(0, int(reset))


# Global rate limiter instance
_rate_limiter: Optional[InMemoryRateLimiter] = None


def get_rate_limiter() -> InMemoryRateLimiter:
    """Get or create the global rate limiter"""
    global _rate_limiter
    if _rate_limiter is None:
        _rate_limiter = InMemoryRateLimiter()
    return _rate_limiter


# ============================================
# RATE LIMIT DECORATORS
# ============================================

def rate_limit(
    limit: int = 60,
    window: int = 60,
    key_func: Optional[Callable] = None,
    error_message: str = "Rate limit exceeded. Please try again later."
):
    """
    Decorator to apply rate limiting to a function or endpoint.

    Args:
        limit: Maximum requests allowed in window
        window: Time window in seconds
        key_func: Function to extract rate limit key (default: uses first arg)
        error_message: Message to return when rate limited

    Usage:
        @rate_limit(limit=5, window=60)
        def login(request):
            ...
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not RateLimitConfig.ENABLED:
                return func(*args, **kwargs)

            # Get rate limit key
            if key_func:
                key = key_func(*args, **kwargs)
            elif args:
                # Try to get IP from first argument (usually request)
                request = args[0]
                if hasattr(request, 'client') and hasattr(request.client, 'host'):
                    key = request.client.host
                elif hasattr(request, 'remote_addr'):
                    key = request.remote_addr
                else:
                    key = str(id(request))
            else:
                key = "default"

            # Add function name to key for per-endpoint limiting
            full_key = f"{func.__name__}:{key}"

            limiter = get_rate_limiter()
            if not limiter.is_allowed(full_key, limit, window):
                remaining = limiter.get_remaining(full_key, limit, window)
                reset = limiter.get_reset_time(full_key, window)

                logger.warning(f"Rate limit exceeded for {full_key}")

                # Return rate limit response
                from fastapi import HTTPException
                raise HTTPException(
                    status_code=429,
                    detail={
                        "error": "rate_limit_exceeded",
                        "message": error_message,
                        "retry_after": reset,
                        "limit": limit,
                        "remaining": remaining
                    },
                    headers={
                        "Retry-After": str(reset),
                        "X-RateLimit-Limit": str(limit),
                        "X-RateLimit-Remaining": str(remaining),
                        "X-RateLimit-Reset": str(reset)
                    }
                )

            return func(*args, **kwargs)

        # Store rate limit info for documentation
        wrapper._rate_limit = {"limit": limit, "window": window}
        return wrapper

    return decorator


def rate_limit_async(
    limit: int = 60,
    window: int = 60,
    key_func: Optional[Callable] = None,
    error_message: str = "Rate limit exceeded. Please try again later."
):
    """
    Async version of rate_limit decorator.

    Usage:
        @rate_limit_async(limit=5, window=60)
        async def login(request):
            ...
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            if not RateLimitConfig.ENABLED:
                return await func(*args, **kwargs)

            # Get rate limit key
            if key_func:
                key = key_func(*args, **kwargs)
            elif args:
                request = args[0]
                if hasattr(request, 'client') and hasattr(request.client, 'host'):
                    key = request.client.host
                elif hasattr(request, 'remote_addr'):
                    key = request.remote_addr
                else:
                    key = str(id(request))
            else:
                key = "default"

            full_key = f"{func.__name__}:{key}"

            limiter = get_rate_limiter()
            if not limiter.is_allowed(full_key, limit, window):
                remaining = limiter.get_remaining(full_key, limit, window)
                reset = limiter.get_reset_time(full_key, window)

                logger.warning(f"Rate limit exceeded for {full_key}")

                from fastapi import HTTPException
                raise HTTPException(
                    status_code=429,
                    detail={
                        "error": "rate_limit_exceeded",
                        "message": error_message,
                        "retry_after": reset,
                        "limit": limit,
                        "remaining": remaining
                    },
                    headers={
                        "Retry-After": str(reset),
                        "X-RateLimit-Limit": str(limit),
                        "X-RateLimit-Remaining": str(remaining),
                        "X-RateLimit-Reset": str(reset)
                    }
                )

            return await func(*args, **kwargs)

        wrapper._rate_limit = {"limit": limit, "window": window}
        return wrapper

    return decorator


# ============================================
# PREDEFINED RATE LIMITERS
# ============================================

def login_rate_limit():
    """Rate limiter for login endpoints (5/min by default)"""
    return rate_limit_async(
        limit=RateLimitConfig.LOGIN_LIMIT,
        window=60,
        error_message="Too many login attempts. Please wait before trying again."
    )


def api_rate_limit():
    """Rate limiter for general API endpoints (60/min by default)"""
    return rate_limit_async(
        limit=RateLimitConfig.API_LIMIT,
        window=60,
        error_message="API rate limit exceeded. Please slow down."
    )


def upload_rate_limit():
    """Rate limiter for file uploads (10/min by default)"""
    return rate_limit_async(
        limit=RateLimitConfig.UPLOAD_LIMIT,
        window=60,
        error_message="Upload rate limit exceeded. Please wait before uploading more files."
    )


def query_rate_limit():
    """Rate limiter for query endpoints (30/min by default)"""
    return rate_limit_async(
        limit=RateLimitConfig.QUERY_LIMIT,
        window=60,
        error_message="Query rate limit exceeded. Please slow down."
    )


# ============================================
# FASTAPI MIDDLEWARE
# ============================================

def create_rate_limit_middleware(app):
    """
    Create rate limiting middleware for FastAPI.

    Args:
        app: FastAPI application instance

    Returns:
        Configured app with rate limiting
    """
    if SLOWAPI_AVAILABLE:
        # Use slowapi for production
        limiter = Limiter(key_func=get_remote_address)
        app.state.limiter = limiter

        @app.exception_handler(RateLimitExceeded)
        async def rate_limit_handler(request, exc):
            from fastapi.responses import JSONResponse
            return JSONResponse(
                status_code=429,
                content={
                    "error": "rate_limit_exceeded",
                    "message": str(exc.detail),
                    "retry_after": getattr(exc, 'retry_after', 60)
                }
            )

        logger.info("slowapi rate limiting enabled")
        return limiter
    else:
        # Use built-in rate limiter
        logger.info("Built-in rate limiting enabled")
        return get_rate_limiter()


# ============================================
# UTILITY FUNCTIONS
# ============================================

def get_client_ip(request) -> str:
    """
    Get client IP address from request.

    Handles X-Forwarded-For header for reverse proxies.

    Args:
        request: FastAPI/Starlette request object

    Returns:
        Client IP address string
    """
    # Check for forwarded header (reverse proxy)
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        # Take first IP in chain
        return forwarded.split(",")[0].strip()

    # Check for real IP header
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip

    # Fall back to direct client
    if hasattr(request, 'client') and request.client:
        return request.client.host

    return "unknown"


def check_rate_limit(
    key: str,
    limit: int = 60,
    window: int = 60
) -> Dict[str, Any]:
    """
    Check rate limit status without consuming a request.

    Args:
        key: Rate limit key
        limit: Maximum requests allowed
        window: Time window in seconds

    Returns:
        Dict with remaining, limit, and reset time
    """
    limiter = get_rate_limiter()
    return {
        "remaining": limiter.get_remaining(key, limit, window),
        "limit": limit,
        "reset": limiter.get_reset_time(key, window)
    }


# ============================================
# ALIASES FOR BACKWARD COMPATIBILITY
# ============================================

# Alias for the rate limiter class
RateLimiter = InMemoryRateLimiter

# Alias for sync decorator (same as rate_limit)
rate_limit_sync = rate_limit


# ============================================
# EXPORTS
# ============================================

__all__ = [
    # Configuration
    "RateLimitConfig",
    # Classes
    "InMemoryRateLimiter",
    "RateLimiter",  # Alias
    # Functions
    "get_rate_limiter",
    "get_client_ip",
    "check_rate_limit",
    # Decorators
    "rate_limit",
    "rate_limit_sync",  # Alias
    "rate_limit_async",
    # Predefined limiters
    "login_rate_limit",
    "api_rate_limit",
    "upload_rate_limit",
    "query_rate_limit",
    # Middleware
    "create_rate_limit_middleware",
    # Availability flags
    "SLOWAPI_AVAILABLE",
]
