"""
MDSA Structured Logging Configuration

Provides structured logging with JSON output for production.

Features:
- Structured JSON logging (for log aggregation)
- Console logging (for development)
- Request correlation IDs
- Context enrichment
- Log levels from environment

Replaces print() statements with proper logging.

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.1.0
"""

import os
import sys
import logging
import json
from datetime import datetime
from typing import Optional, Dict, Any
from contextvars import ContextVar
import traceback

# Try to import structlog for advanced structured logging
try:
    import structlog
    STRUCTLOG_AVAILABLE = True
except ImportError:
    STRUCTLOG_AVAILABLE = False


# ============================================
# CONFIGURATION
# ============================================

class LogConfig:
    """Logging configuration from environment"""

    # Log level
    LEVEL = os.getenv("MDSA_LOG_LEVEL", "INFO").upper()

    # Output format: "json" or "console"
    FORMAT = os.getenv("MDSA_LOG_FORMAT", "console")

    # Log file (optional)
    FILE = os.getenv("MDSA_LOG_FILE", None)

    # Include timestamps
    TIMESTAMPS = os.getenv("MDSA_LOG_TIMESTAMPS", "true").lower() == "true"

    # Include source location
    INCLUDE_SOURCE = os.getenv("MDSA_LOG_SOURCE", "false").lower() == "true"


# Context variable for request correlation
request_id_var: ContextVar[Optional[str]] = ContextVar('request_id', default=None)


# ============================================
# JSON FORMATTER
# ============================================

class JSONFormatter(logging.Formatter):
    """
    JSON log formatter for structured logging.

    Output format:
    {"timestamp": "...", "level": "INFO", "message": "...", "extra": {...}}
    """

    def format(self, record: logging.LogRecord) -> str:
        log_data = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage()
        }

        # Add request ID if available
        request_id = request_id_var.get()
        if request_id:
            log_data["request_id"] = request_id

        # Add source location
        if LogConfig.INCLUDE_SOURCE:
            log_data["source"] = {
                "file": record.filename,
                "line": record.lineno,
                "function": record.funcName
            }

        # Add exception info
        if record.exc_info:
            log_data["exception"] = {
                "type": record.exc_info[0].__name__ if record.exc_info[0] else None,
                "message": str(record.exc_info[1]) if record.exc_info[1] else None,
                "traceback": traceback.format_exception(*record.exc_info)
            }

        # Add extra fields
        extra_fields = {}
        for key, value in record.__dict__.items():
            if key not in (
                'name', 'msg', 'args', 'created', 'filename', 'funcName',
                'levelname', 'levelno', 'lineno', 'module', 'msecs',
                'pathname', 'process', 'processName', 'relativeCreated',
                'stack_info', 'exc_info', 'exc_text', 'thread', 'threadName',
                'message', 'taskName'
            ):
                extra_fields[key] = value

        if extra_fields:
            log_data["extra"] = extra_fields

        return json.dumps(log_data)


class ColoredConsoleFormatter(logging.Formatter):
    """
    Colored console formatter for development.
    """

    COLORS = {
        'DEBUG': '\033[36m',    # Cyan
        'INFO': '\033[32m',     # Green
        'WARNING': '\033[33m',  # Yellow
        'ERROR': '\033[31m',    # Red
        'CRITICAL': '\033[35m', # Magenta
    }
    RESET = '\033[0m'

    def format(self, record: logging.LogRecord) -> str:
        # Add color
        color = self.COLORS.get(record.levelname, '')

        # Format timestamp
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # Add request ID if available
        request_id = request_id_var.get()
        req_str = f"[{request_id[:8]}] " if request_id else ""

        # Format message
        msg = f"{timestamp} {color}{record.levelname:8}{self.RESET} {req_str}{record.name}: {record.getMessage()}"

        # Add exception
        if record.exc_info:
            msg += "\n" + "".join(traceback.format_exception(*record.exc_info))

        return msg


# ============================================
# LOGGER SETUP
# ============================================

def setup_logging(
    level: Optional[str] = None,
    format: Optional[str] = None,
    log_file: Optional[str] = None
) -> logging.Logger:
    """
    Configure MDSA logging.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        format: Output format ("json" or "console")
        log_file: Path to log file (optional)

    Returns:
        Configured root logger
    """
    level = level or LogConfig.LEVEL
    format = format or LogConfig.FORMAT
    log_file = log_file or LogConfig.FILE

    # Get numeric level
    numeric_level = getattr(logging, level, logging.INFO)

    # Create root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)

    # Remove existing handlers
    root_logger.handlers.clear()

    # Create console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)

    if format == "json":
        console_handler.setFormatter(JSONFormatter())
    else:
        console_handler.setFormatter(ColoredConsoleFormatter())

    root_logger.addHandler(console_handler)

    # Create file handler if specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(numeric_level)
        file_handler.setFormatter(JSONFormatter())  # Always JSON for files
        root_logger.addHandler(file_handler)

    # Set third-party loggers to WARNING
    for name in ['urllib3', 'httpcore', 'httpx', 'asyncio']:
        logging.getLogger(name).setLevel(logging.WARNING)

    return root_logger


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger with the given name.

    Args:
        name: Logger name (usually __name__)

    Returns:
        Configured logger
    """
    return logging.getLogger(name)


# ============================================
# CONTEXT MANAGEMENT
# ============================================

def set_request_id(request_id: str):
    """Set the request ID for the current context"""
    request_id_var.set(request_id)


def get_request_id() -> Optional[str]:
    """Get the request ID for the current context"""
    return request_id_var.get()


def clear_request_id():
    """Clear the request ID"""
    request_id_var.set(None)


# ============================================
# LOGGING UTILITIES
# ============================================

class LogContext:
    """
    Context manager for adding context to log messages.

    Usage:
        with LogContext(user_id=123, action="upload"):
            logger.info("Processing request")
    """

    def __init__(self, **context):
        self.context = context
        self.old_factory = None

    def __enter__(self):
        self.old_factory = logging.getLogRecordFactory()

        def factory(*args, **kwargs):
            record = self.old_factory(*args, **kwargs)
            for key, value in self.context.items():
                setattr(record, key, value)
            return record

        logging.setLogRecordFactory(factory)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        logging.setLogRecordFactory(self.old_factory)


def log_request(
    logger: logging.Logger,
    method: str,
    path: str,
    status_code: int,
    duration_ms: float,
    **extra
):
    """
    Log an HTTP request.

    Args:
        logger: Logger instance
        method: HTTP method
        path: Request path
        status_code: Response status code
        duration_ms: Request duration in milliseconds
        **extra: Additional fields to log
    """
    level = logging.INFO if status_code < 400 else logging.WARNING

    logger.log(
        level,
        f"{method} {path} {status_code} ({duration_ms:.1f}ms)",
        extra={
            "http_method": method,
            "http_path": path,
            "http_status": status_code,
            "duration_ms": duration_ms,
            **extra
        }
    )


def log_exception(
    logger: logging.Logger,
    exc: Exception,
    message: str = "An error occurred",
    **extra
):
    """
    Log an exception with full context.

    Args:
        logger: Logger instance
        exc: The exception
        message: Log message
        **extra: Additional fields to log
    """
    logger.error(
        message,
        exc_info=exc,
        extra={
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            **extra
        }
    )


def log_metric(
    logger: logging.Logger,
    metric_name: str,
    value: float,
    unit: str = None,
    **tags
):
    """
    Log a metric value.

    Args:
        logger: Logger instance
        metric_name: Name of the metric
        value: Metric value
        unit: Unit of measurement (optional)
        **tags: Metric tags/dimensions
    """
    logger.info(
        f"METRIC {metric_name}={value}{unit or ''}",
        extra={
            "metric_name": metric_name,
            "metric_value": value,
            "metric_unit": unit,
            **tags
        }
    )


# ============================================
# FASTAPI MIDDLEWARE
# ============================================

def create_logging_middleware():
    """
    Create logging middleware for FastAPI.

    Returns:
        Middleware function
    """
    import uuid
    from time import time

    async def logging_middleware(request, call_next):
        # Generate request ID
        request_id = str(uuid.uuid4())
        set_request_id(request_id)

        # Add to response headers
        start_time = time()

        try:
            response = await call_next(request)

            # Log request
            duration_ms = (time() - start_time) * 1000
            log_request(
                get_logger("mdsa.http"),
                request.method,
                str(request.url.path),
                response.status_code,
                duration_ms,
                client_ip=request.client.host if request.client else "unknown"
            )

            # Add request ID to response
            response.headers["X-Request-ID"] = request_id

            return response

        except Exception as e:
            duration_ms = (time() - start_time) * 1000
            log_exception(
                get_logger("mdsa.http"),
                e,
                f"Request failed: {request.method} {request.url.path}",
                duration_ms=duration_ms
            )
            raise

        finally:
            clear_request_id()

    return logging_middleware


# ============================================
# INITIALIZATION
# ============================================

# Auto-initialize on import
_initialized = False


def init_logging():
    """Initialize logging (called automatically on import)"""
    global _initialized
    if not _initialized:
        setup_logging()
        _initialized = True


# Initialize on module load
init_logging()
