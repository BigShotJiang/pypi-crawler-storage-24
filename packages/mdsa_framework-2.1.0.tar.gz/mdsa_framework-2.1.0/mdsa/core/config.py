"""
MDSA Unified Configuration

Centralized configuration management for all MDSA components.

Features:
- Environment variable support with defaults
- Type validation via Pydantic
- Hierarchical configuration structure
- Runtime config updates
- Configuration validation

Environment Variables:
    MDSA_ENV: Environment (development, staging, production)
    MDSA_DEBUG: Enable debug mode
    MDSA_LOG_LEVEL: Logging level
    MDSA_DATABASE_URL: Database connection URL
    MDSA_SECRET_KEY: JWT secret key
    MDSA_OLLAMA_URL: Ollama server URL
    ... (see MDSAConfig for all options)

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.1.0
"""

import os
import logging
from typing import Optional, Dict, Any, List
from pathlib import Path
from functools import lru_cache
from pydantic import BaseModel, Field, ConfigDict
from enum import Enum

logger = logging.getLogger(__name__)


# ============================================
# PATH HELPERS
# ============================================

def _path_is_writable(path: Path) -> bool:
    """Return True when the path can be created and written to."""
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".mdsa_write_test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def _resolve_data_dir(preferred: Optional[Path] = None) -> Path:
    """
    Resolve a writable data directory.

    Preference order:
    1. Explicit preferred path or MDSA_DATA_DIR
    2. User home ``~/.mdsa``
    3. Repository-local ``.mdsa`` in the current working directory
    """
    candidates: List[Path] = []

    if preferred is not None:
        candidates.append(Path(preferred))

    env_dir = os.getenv("MDSA_DATA_DIR")
    if env_dir:
        env_path = Path(env_dir)
        if env_path not in candidates:
            candidates.append(env_path)

    home_path = Path.home() / ".mdsa"
    if home_path not in candidates:
        candidates.append(home_path)

    cwd_path = Path.cwd() / ".mdsa"
    if cwd_path not in candidates:
        candidates.append(cwd_path)

    for candidate in candidates:
        if _path_is_writable(candidate):
            return candidate

    # Final fallback: current working directory subfolder, even if it is only
    # known to exist conceptually. The caller will attempt to create it again.
    return Path.cwd() / ".mdsa"


# ============================================
# ENUMS
# ============================================

class Environment(str, Enum):
    """Runtime environment."""
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


class DatabaseType(str, Enum):
    """Supported database types."""
    SQLITE = "sqlite"
    POSTGRESQL = "postgresql"


class LogLevel(str, Enum):
    """Log levels."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


# ============================================
# CONFIGURATION SECTIONS
# ============================================

class DatabaseConfig(BaseModel):
    """Database configuration."""

    type: DatabaseType = Field(
        default=DatabaseType.SQLITE,
        description="Database type"
    )
    url: Optional[str] = Field(
        default=None,
        description="Full database URL (overrides other settings)"
    )
    host: str = Field(default="localhost", description="Database host")
    port: int = Field(default=5432, description="Database port")
    name: str = Field(default="mdsa", description="Database name")
    user: str = Field(default="postgres", description="Database user")
    password: str = Field(default="", description="Database password")
    echo: bool = Field(default=False, description="Echo SQL statements")
    pool_size: int = Field(default=5, description="Connection pool size")
    max_overflow: int = Field(default=10, description="Max pool overflow")

    @classmethod
    def from_env(cls) -> "DatabaseConfig":
        """Load from environment variables."""
        db_type_str = os.getenv("MDSA_DATABASE_TYPE", "sqlite").lower()
        db_type = DatabaseType.POSTGRESQL if db_type_str == "postgresql" else DatabaseType.SQLITE

        return cls(
            type=db_type,
            url=os.getenv("MDSA_DATABASE_URL"),
            host=os.getenv("MDSA_DATABASE_HOST", "localhost"),
            port=int(os.getenv("MDSA_DATABASE_PORT", "5432")),
            name=os.getenv("MDSA_DATABASE_NAME", "mdsa"),
            user=os.getenv("MDSA_DATABASE_USER", "postgres"),
            password=os.getenv("MDSA_DATABASE_PASSWORD", ""),
            echo=os.getenv("MDSA_DATABASE_ECHO", "false").lower() == "true",
            pool_size=int(os.getenv("MDSA_DATABASE_POOL_SIZE", "5")),
            max_overflow=int(os.getenv("MDSA_DATABASE_MAX_OVERFLOW", "10"))
        )

    def get_url(self) -> str:
        """Get database connection URL."""
        if self.url:
            return self.url

        if self.type == DatabaseType.SQLITE:
            mdsa_dir = _resolve_data_dir()
            return f"sqlite:///{mdsa_dir / 'mdsa.db'}"

        # PostgreSQL
        if self.password:
            return f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.name}"
        return f"postgresql://{self.user}@{self.host}:{self.port}/{self.name}"


class AuthConfig(BaseModel):
    """Authentication configuration."""

    secret_key: Optional[str] = Field(
        default=None,
        description="JWT secret key (auto-generated if not set)"
    )
    algorithm: str = Field(default="HS256", description="JWT algorithm")
    access_token_expire_minutes: int = Field(
        default=60,
        description="Access token expiration in minutes"
    )
    refresh_token_expire_days: int = Field(
        default=7,
        description="Refresh token expiration in days"
    )
    bcrypt_rounds: int = Field(
        default=12,
        description="bcrypt hashing rounds"
    )
    session_tracking: bool = Field(
        default=True,
        description="Enable session tracking in database"
    )

    @classmethod
    def from_env(cls) -> "AuthConfig":
        """Load from environment variables."""
        return cls(
            secret_key=os.getenv("MDSA_SECRET_KEY"),
            algorithm=os.getenv("MDSA_JWT_ALGORITHM", "HS256"),
            access_token_expire_minutes=int(os.getenv("MDSA_TOKEN_EXPIRE_MINUTES", "60")),
            refresh_token_expire_days=int(os.getenv("MDSA_REFRESH_TOKEN_DAYS", "7")),
            bcrypt_rounds=int(os.getenv("MDSA_BCRYPT_ROUNDS", "12")),
            session_tracking=os.getenv("MDSA_SESSION_TRACKING", "true").lower() == "true"
        )


class OllamaConfig(BaseModel):
    """Ollama LLM configuration."""

    url: str = Field(
        default="http://localhost:11434",
        description="Ollama server URL"
    )
    default_model: str = Field(
        default="llama3.2:3b",
        description="Default model for inference"
    )
    timeout: int = Field(
        default=120,
        description="Request timeout in seconds"
    )
    max_retries: int = Field(
        default=3,
        description="Max retry attempts"
    )

    @classmethod
    def from_env(cls) -> "OllamaConfig":
        """Load from environment variables."""
        return cls(
            url=os.getenv("MDSA_OLLAMA_URL", "http://localhost:11434"),
            default_model=os.getenv("MDSA_OLLAMA_MODEL", "llama3.2:3b"),
            timeout=int(os.getenv("MDSA_OLLAMA_TIMEOUT", "120")),
            max_retries=int(os.getenv("MDSA_OLLAMA_RETRIES", "3"))
        )


class RAGConfig(BaseModel):
    """RAG (Retrieval Augmented Generation) configuration."""

    embedding_model: str = Field(
        default="all-MiniLM-L6-v2",
        description="Sentence transformer model for embeddings"
    )
    embedding_dimension: int = Field(
        default=384,
        description="Embedding vector dimension"
    )
    chunk_size: int = Field(
        default=512,
        description="Document chunk size in characters"
    )
    chunk_overlap: int = Field(
        default=50,
        description="Overlap between chunks"
    )
    top_k: int = Field(
        default=5,
        description="Number of documents to retrieve"
    )
    similarity_threshold: float = Field(
        default=0.3,
        description="Minimum similarity score"
    )
    persist_to_db: bool = Field(
        default=True,
        description="Persist documents to database"
    )

    @classmethod
    def from_env(cls) -> "RAGConfig":
        """Load from environment variables."""
        return cls(
            embedding_model=os.getenv("MDSA_EMBEDDING_MODEL", "all-MiniLM-L6-v2"),
            embedding_dimension=int(os.getenv("MDSA_EMBEDDING_DIM", "384")),
            chunk_size=int(os.getenv("MDSA_CHUNK_SIZE", "512")),
            chunk_overlap=int(os.getenv("MDSA_CHUNK_OVERLAP", "50")),
            top_k=int(os.getenv("MDSA_RAG_TOP_K", "5")),
            similarity_threshold=float(os.getenv("MDSA_RAG_THRESHOLD", "0.3")),
            persist_to_db=os.getenv("MDSA_RAG_PERSIST", "true").lower() == "true"
        )


class RateLimitConfig(BaseModel):
    """Rate limiting configuration."""

    enabled: bool = Field(default=True, description="Enable rate limiting")
    requests_per_minute: int = Field(
        default=60,
        description="Max requests per minute"
    )
    burst_size: int = Field(
        default=10,
        description="Burst allowance"
    )
    login_limit: int = Field(
        default=5,
        description="Login attempts per minute"
    )

    @classmethod
    def from_env(cls) -> "RateLimitConfig":
        """Load from environment variables."""
        return cls(
            enabled=os.getenv("MDSA_RATE_LIMIT_ENABLED", "true").lower() == "true",
            requests_per_minute=int(os.getenv("MDSA_RATE_LIMIT_RPM", "60")),
            burst_size=int(os.getenv("MDSA_RATE_LIMIT_BURST", "10")),
            login_limit=int(os.getenv("MDSA_RATE_LIMIT_LOGIN", "5"))
        )


class LoggingConfig(BaseModel):
    """Logging configuration."""

    level: LogLevel = Field(default=LogLevel.INFO, description="Log level")
    format: str = Field(
        default="console",
        description="Log format (console or json)"
    )
    file: Optional[str] = Field(
        default=None,
        description="Log file path"
    )
    include_timestamps: bool = Field(default=True, description="Include timestamps")
    include_source: bool = Field(default=False, description="Include source location")

    @classmethod
    def from_env(cls) -> "LoggingConfig":
        """Load from environment variables."""
        level_str = os.getenv("MDSA_LOG_LEVEL", "INFO").upper()
        level = LogLevel(level_str) if level_str in LogLevel.__members__ else LogLevel.INFO

        return cls(
            level=level,
            format=os.getenv("MDSA_LOG_FORMAT", "console"),
            file=os.getenv("MDSA_LOG_FILE"),
            include_timestamps=os.getenv("MDSA_LOG_TIMESTAMPS", "true").lower() == "true",
            include_source=os.getenv("MDSA_LOG_SOURCE", "false").lower() == "true"
        )


class DashboardConfig(BaseModel):
    """Dashboard configuration."""

    host: str = Field(default="127.0.0.1", description="Dashboard host")
    port: int = Field(default=5000, description="Dashboard port")
    debug: bool = Field(default=False, description="Enable debug mode")
    auto_open: bool = Field(default=True, description="Auto-open browser")
    session_timeout_minutes: int = Field(
        default=60,
        description="Session timeout in minutes"
    )
    cors_origins: List[str] = Field(
        default_factory=list,
        description="Allowed CORS origins"
    )
    cors_allow_all: bool = Field(
        default=False,
        description="Allow all origins (dev only)"
    )

    @classmethod
    def from_env(cls) -> "DashboardConfig":
        """Load from environment variables."""
        cors_env = os.getenv("MDSA_CORS_ORIGINS", "")
        cors_origins = [o.strip() for o in cors_env.split(",") if o.strip()]

        return cls(
            host=os.getenv("MDSA_DASHBOARD_HOST", "127.0.0.1"),
            port=int(os.getenv("MDSA_DASHBOARD_PORT", "5000")),
            debug=os.getenv("MDSA_DEBUG", "false").lower() == "true",
            auto_open=os.getenv("MDSA_DASHBOARD_AUTO_OPEN", "true").lower() == "true",
            session_timeout_minutes=int(os.getenv("MDSA_SESSION_TIMEOUT", "60")),
            cors_origins=cors_origins,
            cors_allow_all=os.getenv("MDSA_CORS_ALLOW_ALL", "false").lower() == "true"
        )


class OrchestratorConfig(BaseModel):
    """Orchestrator runtime configuration."""

    # Model names
    reasoning_model: str = Field(
        default="microsoft/phi-2",
        description="Reasoning model"
    )
    orchestrator_model: str = Field(
        default="google/bert_uncased_L-2_H-128_A-2",
        description="Orchestrator model"
    )

    # Thresholds
    complexity_threshold: float = Field(
        default=0.3,
        description="Complexity threshold for reasoning"
    )

    # Timeouts (seconds)
    request_timeout: int = Field(
        default=10,
        description="Request timeout in seconds"
    )
    health_check_timeout: int = Field(
        default=2,
        description="Health check timeout in seconds"
    )
    query_timeout: int = Field(
        default=30,
        description="Query timeout in seconds"
    )

    # Memory limits
    max_request_history: int = Field(
        default=1000,
        description="Maximum request history size"
    )
    max_cache_size: int = Field(
        default=100,
        description="Maximum cache size"
    )

    # Update intervals (seconds)
    metrics_update_interval: int = Field(
        default=2,
        description="Metrics update interval in seconds"
    )
    websocket_update_interval: int = Field(
        default=2,
        description="WebSocket update interval in seconds"
    )

    @classmethod
    def from_env(cls) -> "OrchestratorConfig":
        """Load from environment variables."""
        return cls(
            reasoning_model=os.getenv("MDSA_REASONING_MODEL", "microsoft/phi-2"),
            orchestrator_model=os.getenv(
                "MDSA_ORCHESTRATOR_MODEL",
                "google/bert_uncased_L-2_H-128_A-2"
            ),
            complexity_threshold=float(os.getenv("MDSA_COMPLEXITY_THRESHOLD", "0.3")),
            request_timeout=int(os.getenv("MDSA_REQUEST_TIMEOUT", "10")),
            health_check_timeout=int(os.getenv("MDSA_HEALTH_CHECK_TIMEOUT", "2")),
            query_timeout=int(os.getenv("MDSA_QUERY_TIMEOUT", "30")),
            max_request_history=int(os.getenv("MDSA_MAX_HISTORY", "1000")),
            max_cache_size=int(os.getenv("MDSA_CACHE_SIZE", "100")),
            metrics_update_interval=int(os.getenv("MDSA_METRICS_INTERVAL", "2")),
            websocket_update_interval=int(os.getenv("MDSA_WS_INTERVAL", "2"))
        )


# ============================================
# MAIN CONFIGURATION CLASS
# ============================================

class MDSAConfig(BaseModel):
    """
    Complete MDSA configuration.

    Loads all settings from environment variables with sensible defaults.
    """

    # Environment
    env: Environment = Field(
        default=Environment.DEVELOPMENT,
        description="Runtime environment"
    )
    debug: bool = Field(default=False, description="Debug mode")
    version: str = Field(default="2.1.0", description="MDSA version")

    # Component configs
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    auth: AuthConfig = Field(default_factory=AuthConfig)
    ollama: OllamaConfig = Field(default_factory=OllamaConfig)
    rag: RAGConfig = Field(default_factory=RAGConfig)
    rate_limit: RateLimitConfig = Field(default_factory=RateLimitConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    dashboard: DashboardConfig = Field(default_factory=DashboardConfig)
    orchestrator: OrchestratorConfig = Field(default_factory=OrchestratorConfig)

    # Additional settings
    data_dir: Path = Field(
        default_factory=lambda: _resolve_data_dir(),
        description="MDSA data directory"
    )

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @classmethod
    def from_env(cls) -> "MDSAConfig":
        """
        Load complete configuration from environment variables.

        Returns:
            MDSAConfig instance with all settings loaded
        """
        env_str = os.getenv("MDSA_ENV", "development").lower()
        env = Environment(env_str) if env_str in [e.value for e in Environment] else Environment.DEVELOPMENT

        data_dir_str = os.getenv("MDSA_DATA_DIR")
        data_dir = _resolve_data_dir(Path(data_dir_str)) if data_dir_str else _resolve_data_dir()

        return cls(
            env=env,
            debug=os.getenv("MDSA_DEBUG", "false").lower() == "true",
            database=DatabaseConfig.from_env(),
            auth=AuthConfig.from_env(),
            ollama=OllamaConfig.from_env(),
            rag=RAGConfig.from_env(),
            rate_limit=RateLimitConfig.from_env(),
            logging=LoggingConfig.from_env(),
            dashboard=DashboardConfig.from_env(),
            orchestrator=OrchestratorConfig.from_env(),
            data_dir=data_dir
        )

    @property
    def is_production(self) -> bool:
        """Check if running in production."""
        return self.env == Environment.PRODUCTION

    @property
    def is_development(self) -> bool:
        """Check if running in development."""
        return self.env == Environment.DEVELOPMENT

    def ensure_directories(self):
        """Create required directories."""
        self.data_dir = _resolve_data_dir(self.data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        (self.data_dir / "logs").mkdir(exist_ok=True)
        (self.data_dir / "cache").mkdir(exist_ok=True)
        (self.data_dir / "rag").mkdir(exist_ok=True)

    def to_dict(self, mask_secrets: bool = True) -> Dict[str, Any]:
        """
        Convert to dictionary.

        Args:
            mask_secrets: If True, mask sensitive values

        Returns:
            Configuration as dictionary
        """
        data = self.dict()

        if mask_secrets:
            if data.get("auth", {}).get("secret_key"):
                data["auth"]["secret_key"] = "****"
            if data.get("database", {}).get("password"):
                data["database"]["password"] = "****"

        return data


# ============================================
# GLOBAL CONFIGURATION INSTANCE
# ============================================

_config: Optional[MDSAConfig] = None


def get_config() -> MDSAConfig:
    """
    Get the global configuration instance.

    Creates configuration from environment on first call.

    Returns:
        MDSAConfig instance
    """
    global _config

    if _config is None:
        _config = MDSAConfig.from_env()
        _config.ensure_directories()
        logger.info(f"MDSA configuration loaded (env={_config.env.value})")

    return _config


def reload_config() -> MDSAConfig:
    """
    Reload configuration from environment.

    Use this after changing environment variables.

    Returns:
        Fresh MDSAConfig instance
    """
    global _config
    _config = None
    return get_config()


def override_config(**kwargs) -> MDSAConfig:
    """
    Override specific configuration values.

    Useful for testing.

    Args:
        **kwargs: Configuration overrides

    Returns:
        Updated MDSAConfig instance
    """
    global _config

    if _config is None:
        _config = MDSAConfig.from_env()

    # Update with overrides
    for key, value in kwargs.items():
        if hasattr(_config, key):
            setattr(_config, key, value)

    return _config


# ============================================
# ENVIRONMENT HELPERS
# ============================================

def is_production() -> bool:
    """Check if running in production environment."""
    return get_config().is_production


def is_development() -> bool:
    """Check if running in development environment."""
    return get_config().is_development


def get_database_url() -> str:
    """Get database connection URL."""
    return get_config().database.get_url()


def get_ollama_url() -> str:
    """Get Ollama server URL."""
    return get_config().ollama.url


def get_data_dir() -> Path:
    """Get MDSA data directory."""
    return get_config().data_dir


# ============================================
# EXPORTS
# ============================================

__all__ = [
    # Enums
    "Environment",
    "DatabaseType",
    "LogLevel",
    # Config sections
    "DatabaseConfig",
    "AuthConfig",
    "OllamaConfig",
    "RAGConfig",
    "RateLimitConfig",
    "LoggingConfig",
    "DashboardConfig",
    # Main config
    "MDSAConfig",
    # Functions
    "get_config",
    "reload_config",
    "override_config",
    "is_production",
    "is_development",
    "get_database_url",
    "get_ollama_url",
    "get_data_dir"
]
