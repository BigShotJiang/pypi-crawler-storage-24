"""
MDSA Exception Hierarchy

Defines custom exceptions for the MDSA Framework.

Replaces bare `except:` clauses with specific, catchable exceptions.

Exception hierarchy:
- MDSAError (base)
  - AuthenticationError
  - AuthorizationError
  - ValidationError
  - AppError
    - AppNotFoundError
    - AppUnreachableError
    - AppRegistrationError
  - RAGError
    - DocumentNotFoundError
    - EmbeddingError
  - ConfigurationError
  - DatabaseError
  - RateLimitError

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.1.0
"""

from typing import Optional, Any, Dict


class MDSAError(Exception):
    """
    Base exception for all MDSA errors.

    All MDSA-specific exceptions inherit from this class.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        detail: Optional[Any] = None
    ):
        self.message = message
        self.error_code = error_code or "MDSA_ERROR"
        self.detail = detail
        super().__init__(self.message)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API responses"""
        return {
            "error": self.error_code,
            "message": self.message,
            "detail": self.detail
        }


# ============================================
# AUTHENTICATION ERRORS
# ============================================

class AuthenticationError(MDSAError):
    """
    Authentication failed.

    Raised when:
    - Invalid credentials
    - Expired token
    - Invalid token format
    """

    def __init__(
        self,
        message: str = "Authentication failed",
        detail: Optional[Any] = None,
        code: Optional[str] = None
    ):
        super().__init__(
            message=message,
            error_code=code or "AUTH_FAILED",
            detail=detail
        )

    @property
    def code(self) -> str:
        """Alias for error_code for backward compatibility"""
        return self.error_code


class InvalidCredentialsError(AuthenticationError):
    """Invalid username or password"""

    def __init__(self, message: str = "Invalid username or password"):
        super().__init__(message=message)
        self.error_code = "INVALID_CREDENTIALS"


class TokenExpiredError(AuthenticationError):
    """JWT token has expired"""

    def __init__(self, message: str = "Token has expired"):
        super().__init__(message=message)
        self.error_code = "TOKEN_EXPIRED"


class TokenInvalidError(AuthenticationError):
    """JWT token is invalid"""

    def __init__(self, message: str = "Invalid token"):
        super().__init__(message=message)
        self.error_code = "TOKEN_INVALID"


class SessionRevokedError(AuthenticationError):
    """Session has been revoked (logged out)"""

    def __init__(self, message: str = "Session has been revoked"):
        super().__init__(message=message)
        self.error_code = "SESSION_REVOKED"


# ============================================
# AUTHORIZATION ERRORS
# ============================================

class AuthorizationError(MDSAError):
    """
    Authorization failed.

    Raised when user lacks required permissions.
    """

    def __init__(
        self,
        message: str = "Insufficient permissions",
        required_role: Optional[str] = None,
        detail: Optional[Any] = None
    ):
        super().__init__(
            message=message,
            error_code="UNAUTHORIZED",
            detail=detail or {"required_role": required_role}
        )
        self.required_role = required_role


class AdminRequiredError(AuthorizationError):
    """Admin role required"""

    def __init__(self, message: str = "Admin access required"):
        super().__init__(message=message, required_role="admin")
        self.error_code = "ADMIN_REQUIRED"


# ============================================
# VALIDATION ERRORS
# ============================================

class ValidationError(MDSAError):
    """
    Input validation failed.

    Raised when request data fails validation.
    """

    def __init__(
        self,
        message: str = "Validation failed",
        field: Optional[str] = None,
        errors: Optional[list] = None
    ):
        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            detail={"field": field, "errors": errors}
        )
        self.field = field
        self.errors = errors or []


class InvalidInputError(ValidationError):
    """Invalid input data"""

    def __init__(
        self,
        field: str,
        message: str = "Invalid input"
    ):
        super().__init__(
            message=f"{field}: {message}",
            field=field
        )
        self.error_code = "INVALID_INPUT"


# ============================================
# APP ERRORS
# ============================================

class AppError(MDSAError):
    """
    Base class for app-related errors.
    """

    def __init__(
        self,
        message: str,
        app_id: Optional[str] = None,
        error_code: str = "APP_ERROR",
        detail: Optional[Any] = None
    ):
        super().__init__(
            message=message,
            error_code=error_code,
            detail=detail or {"app_id": app_id}
        )
        self.app_id = app_id


class AppNotFoundError(AppError):
    """
    App not found in registry.

    Raised when requested app_id doesn't exist.
    """

    def __init__(self, app_id: str):
        super().__init__(
            message=f"App '{app_id}' not found in registry",
            app_id=app_id,
            error_code="APP_NOT_FOUND"
        )


class AppUnreachableError(AppError):
    """
    App is not responding.

    Raised when health check or API call fails.
    """

    def __init__(
        self,
        app_id: str,
        url: Optional[str] = None,
        reason: Optional[str] = None
    ):
        super().__init__(
            message=f"App '{app_id}' is not reachable" + (f": {reason}" if reason else ""),
            app_id=app_id,
            error_code="APP_UNREACHABLE",
            detail={"app_id": app_id, "url": url, "reason": reason}
        )
        self.url = url
        self.reason = reason


class AppRegistrationError(AppError):
    """
    App registration failed.

    Raised when app cannot be registered.
    """

    def __init__(
        self,
        app_id: str,
        reason: str = "Registration failed"
    ):
        super().__init__(
            message=f"Failed to register app '{app_id}': {reason}",
            app_id=app_id,
            error_code="APP_REGISTRATION_FAILED"
        )
        self.reason = reason


class AppAlreadyExistsError(AppError):
    """App with this ID already exists"""

    def __init__(self, app_id: str):
        super().__init__(
            message=f"App '{app_id}' already exists",
            app_id=app_id,
            error_code="APP_EXISTS"
        )


# ============================================
# RAG ERRORS
# ============================================

class RAGError(MDSAError):
    """
    Base class for RAG-related errors.
    """

    def __init__(
        self,
        message: str = "RAG operation failed",
        error_code: str = "RAG_ERROR",
        detail: Optional[Any] = None
    ):
        super().__init__(
            message=message,
            error_code=error_code,
            detail=detail
        )


class DocumentNotFoundError(RAGError):
    """Document not found in RAG"""

    def __init__(self, doc_id: int):
        super().__init__(
            message=f"Document {doc_id} not found",
            error_code="DOCUMENT_NOT_FOUND",
            detail={"doc_id": doc_id}
        )
        self.doc_id = doc_id


class EmbeddingError(RAGError):
    """Failed to generate embedding"""

    def __init__(self, reason: str = "Embedding generation failed"):
        super().__init__(
            message=reason,
            error_code="EMBEDDING_ERROR"
        )


class DocumentUploadError(RAGError):
    """Document upload failed"""

    def __init__(
        self,
        filename: str,
        reason: str = "Upload failed"
    ):
        super().__init__(
            message=f"Failed to upload '{filename}': {reason}",
            error_code="UPLOAD_ERROR",
            detail={"filename": filename, "reason": reason}
        )
        self.filename = filename


# ============================================
# CONFIGURATION ERRORS
# ============================================

class ConfigurationError(MDSAError):
    """
    Configuration error.

    Raised when configuration is invalid or missing.
    """

    def __init__(
        self,
        message: str = "Configuration error",
        config_key: Optional[str] = None
    ):
        super().__init__(
            message=message,
            error_code="CONFIG_ERROR",
            detail={"config_key": config_key}
        )
        self.config_key = config_key


class MissingConfigError(ConfigurationError):
    """Required configuration is missing"""

    def __init__(self, config_key: str):
        super().__init__(
            message=f"Required configuration '{config_key}' is missing",
            config_key=config_key
        )
        self.error_code = "CONFIG_MISSING"


# ============================================
# DATABASE ERRORS
# ============================================

class DatabaseError(MDSAError):
    """
    Database operation failed.
    """

    def __init__(
        self,
        message: str = "Database error",
        operation: Optional[str] = None
    ):
        super().__init__(
            message=message,
            error_code="DATABASE_ERROR",
            detail={"operation": operation}
        )
        self.operation = operation


class ConnectionError(DatabaseError):
    """Database connection failed"""

    def __init__(self, message: str = "Failed to connect to database"):
        super().__init__(message=message, operation="connect")
        self.error_code = "DB_CONNECTION_ERROR"


# ============================================
# RATE LIMIT ERRORS
# ============================================

class RateLimitError(MDSAError):
    """
    Rate limit exceeded.
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        limit: Optional[int] = None,
        reset_seconds: Optional[int] = None
    ):
        super().__init__(
            message=message,
            error_code="RATE_LIMIT_EXCEEDED",
            detail={
                "limit": limit,
                "retry_after": reset_seconds
            }
        )
        self.limit = limit
        self.reset_seconds = reset_seconds


# ============================================
# ORCHESTRATION ERRORS
# ============================================

class OrchestrationError(MDSAError):
    """
    Query orchestration failed.
    """

    def __init__(
        self,
        message: str = "Orchestration failed",
        domain: Optional[str] = None
    ):
        super().__init__(
            message=message,
            error_code="ORCHESTRATION_ERROR",
            detail={"domain": domain}
        )
        self.domain = domain


class DomainNotFoundError(OrchestrationError):
    """Domain not found"""

    def __init__(self, domain: str):
        super().__init__(
            message=f"Domain '{domain}' not found",
            domain=domain
        )
        self.error_code = "DOMAIN_NOT_FOUND"


class ModelNotAvailableError(OrchestrationError):
    """Model not available"""

    def __init__(self, model: str, domain: Optional[str] = None):
        super().__init__(
            message=f"Model '{model}' is not available",
            domain=domain
        )
        self.error_code = "MODEL_NOT_AVAILABLE"
        self.model = model


# ============================================
# UTILITY FUNCTIONS
# ============================================

def handle_exception(exc: Exception) -> Dict[str, Any]:
    """
    Convert any exception to a standardized error response.

    Args:
        exc: The exception to handle

    Returns:
        Dictionary suitable for API error response
    """
    if isinstance(exc, MDSAError):
        return exc.to_dict()

    # Convert standard exceptions
    return {
        "error": "INTERNAL_ERROR",
        "message": str(exc),
        "detail": None
    }


def get_http_status(exc: MDSAError) -> int:
    """
    Get appropriate HTTP status code for an exception.

    Args:
        exc: The MDSA exception

    Returns:
        HTTP status code
    """
    status_map = {
        "AUTH_FAILED": 401,
        "INVALID_CREDENTIALS": 401,
        "TOKEN_EXPIRED": 401,
        "TOKEN_INVALID": 401,
        "SESSION_REVOKED": 401,
        "UNAUTHORIZED": 403,
        "ADMIN_REQUIRED": 403,
        "VALIDATION_ERROR": 400,
        "INVALID_INPUT": 400,
        "APP_NOT_FOUND": 404,
        "DOCUMENT_NOT_FOUND": 404,
        "DOMAIN_NOT_FOUND": 404,
        "APP_EXISTS": 409,
        "RATE_LIMIT_EXCEEDED": 429,
        "APP_UNREACHABLE": 503,
        "DATABASE_ERROR": 503,
        "DB_CONNECTION_ERROR": 503,
    }

    return status_map.get(exc.error_code, 500)
