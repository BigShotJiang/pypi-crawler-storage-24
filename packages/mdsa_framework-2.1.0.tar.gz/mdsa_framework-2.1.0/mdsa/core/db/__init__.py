"""
MDSA Database Package

Provides database connection management and ORM models for MDSA Framework.

This module supports both PostgreSQL (production) and SQLite (development).
"""

from mdsa.core.db.connection import (
    get_engine,
    get_session,
    get_db,
    init_db,
    DatabaseSession
)

from mdsa.core.db.models import (
    Base,
    User,
    Session,
    App,
    Document,
    Query
)

__all__ = [
    # Connection management
    "get_engine",
    "get_session",
    "get_db",
    "init_db",
    "DatabaseSession",
    # Models
    "Base",
    "User",
    "Session",
    "App",
    "Document",
    "Query"
]
