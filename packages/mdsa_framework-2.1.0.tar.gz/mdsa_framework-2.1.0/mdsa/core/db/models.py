"""
MDSA Database Models

SQLAlchemy ORM models for MDSA Framework persistence.

Tables:
- users: User authentication and authorization
- sessions: JWT session tracking
- apps: Registered application registry
- documents: RAG document storage
- queries: Query history and analytics

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.1.0
"""

from datetime import datetime
from typing import Optional, Dict, Any
from mdsa.core.platform_compat import apply_windows_platform_patches

apply_windows_platform_patches()

from sqlalchemy import (
    Column, Integer, String, Text, Boolean, DateTime,
    ForeignKey, Index, JSON, Float
)
from sqlalchemy.orm import relationship, declarative_base

# Try to import pgvector for PostgreSQL vector storage
try:
    from pgvector.sqlalchemy import Vector
    PGVECTOR_AVAILABLE = True
except ImportError:
    PGVECTOR_AVAILABLE = False
    Vector = None

Base = declarative_base()


class User(Base):
    """
    User model for authentication and authorization.

    Replaces the hardcoded single-admin authentication.
    Passwords are stored as bcrypt hashes.
    """
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)  # bcrypt hash
    role = Column(String(20), default="analyst", nullable=False)  # owner, admin, analyst, viewer
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)

    # Relationships
    sessions = relationship("Session", back_populates="user", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="uploaded_by_user")
    queries = relationship("Query", back_populates="user")

    def __repr__(self):
        return f"<User(id={self.id}, username='{self.username}', role='{self.role}')>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary (excludes sensitive fields)"""
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "role": self.role,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_login": self.last_login.isoformat() if self.last_login else None
        }


class Session(Base):
    """
    Session model for JWT token tracking.

    Enables session revocation (logout) and tracking.
    """
    __tablename__ = "sessions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    token_hash = Column(String(255), unique=True, nullable=False, index=True)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    ip_address = Column(String(45), nullable=True)  # IPv6 max length
    user_agent = Column(String(500), nullable=True)
    is_revoked = Column(Boolean, default=False, nullable=False)

    # Relationships
    user = relationship("User", back_populates="sessions")

    def __repr__(self):
        return f"<Session(id={self.id}, user_id={self.user_id}, expires_at='{self.expires_at}')>"

    @property
    def is_expired(self) -> bool:
        """Check if session has expired"""
        return datetime.utcnow() > self.expires_at

    @property
    def is_valid(self) -> bool:
        """Check if session is valid (not expired and not revoked)"""
        return not self.is_expired and not self.is_revoked


class App(Base):
    """
    Registered application model.

    Replaces the JSON-based app registry with database persistence.
    """
    __tablename__ = "apps"

    id = Column(Integer, primary_key=True, autoincrement=True)
    app_id = Column(String(50), unique=True, nullable=False, index=True)
    app_name = Column(String(255), nullable=False)
    framework = Column(String(50), nullable=True)  # fastapi, flask, django, etc.
    api_endpoint = Column(Text, nullable=False)
    health_endpoint = Column(Text, nullable=True)
    metrics_endpoint = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    last_health_check = Column(DateTime, nullable=True)
    health_status = Column(String(20), default="unknown")  # healthy, unhealthy, unknown
    extra_data = Column(JSON, nullable=True)  # Additional app metadata
    registered_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<App(id={self.id}, app_id='{self.app_id}', name='{self.app_name}')>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API responses"""
        return {
            "app_id": self.app_id,
            "name": self.app_name,
            "framework": self.framework,
            "endpoint": self.api_endpoint,
            "health": self.health_endpoint,
            "metrics": self.metrics_endpoint,
            "is_active": self.is_active,
            "health_status": self.health_status,
            "last_health_check": self.last_health_check.isoformat() if self.last_health_check else None,
            "registered_at": self.registered_at.isoformat() if self.registered_at else None,
            "metadata": self.extra_data or {}
        }


class Document(Base):
    """
    RAG document model.

    Stores documents for the Unified RAG system with vector embeddings.
    Replaces the in-memory dual RAG with persistent storage.
    """
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, autoincrement=True)
    content = Column(Text, nullable=False)
    content_hash = Column(String(64), nullable=True, index=True)  # SHA256 for dedup
    title = Column(String(500), nullable=True)
    source = Column(String(255), nullable=True)  # file path, URL, etc.
    domain = Column(String(100), nullable=True, index=True)
    doc_type = Column(String(50), nullable=True)  # pdf, txt, md, etc.
    extra_data = Column(JSON, nullable=True)  # Document metadata
    chunk_index = Column(Integer, nullable=True)  # For chunked documents
    parent_doc_id = Column(Integer, ForeignKey("documents.id"), nullable=True)
    uploaded_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    app_id = Column(String(50), nullable=True, index=True)  # Which app uploaded
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # Vector embedding - only available with pgvector
    # embedding = Column(Vector(384), nullable=True)  # sentence-transformers dimension

    # Relationships
    uploaded_by_user = relationship("User", back_populates="documents")
    children = relationship("Document", backref="parent", remote_side=[id])

    # Indexes
    __table_args__ = (
        Index("idx_documents_domain_created", "domain", "created_at"),
    )

    def __repr__(self):
        return f"<Document(id={self.id}, title='{self.title[:30] if self.title else 'untitled'}...')>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "title": self.title,
            "source": self.source,
            "domain": self.domain,
            "doc_type": self.doc_type,
            "metadata": self.extra_data or {},
            "chunk_index": self.chunk_index,
            "app_id": self.app_id,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }


class Query(Base):
    """
    Query history model for analytics and debugging.

    Tracks all queries processed by MDSA for monitoring and improvement.
    """
    __tablename__ = "queries"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    query_text = Column(Text, nullable=False)
    domain = Column(String(100), nullable=True, index=True)
    app_id = Column(String(50), nullable=True, index=True)
    response = Column(Text, nullable=True)
    latency_ms = Column(Integer, nullable=True)
    status = Column(String(20), default="success")  # success, error, timeout
    error_message = Column(Text, nullable=True)
    context_docs = Column(JSON, nullable=True)  # RAG context used
    extra_data = Column(JSON, nullable=True)  # Additional query metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

    # Relationships
    user = relationship("User", back_populates="queries")

    # Indexes
    __table_args__ = (
        Index("idx_queries_created_domain", "created_at", "domain"),
        Index("idx_queries_user_created", "user_id", "created_at"),
    )

    def __repr__(self):
        return f"<Query(id={self.id}, domain='{self.domain}', status='{self.status}')>"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "query_text": self.query_text[:100] + "..." if len(self.query_text) > 100 else self.query_text,
            "domain": self.domain,
            "app_id": self.app_id,
            "latency_ms": self.latency_ms,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }


# Metrics table for time-series data (optional)
class Metric(Base):
    """
    Metrics model for time-series monitoring data.

    Stores aggregated metrics for dashboard visualization.
    """
    __tablename__ = "metrics"

    id = Column(Integer, primary_key=True, autoincrement=True)
    metric_name = Column(String(100), nullable=False, index=True)
    metric_value = Column(Float, nullable=False)
    app_id = Column(String(50), nullable=True, index=True)
    domain = Column(String(100), nullable=True)
    tags = Column(JSON, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

    # Indexes for time-series queries
    __table_args__ = (
        Index("idx_metrics_name_time", "metric_name", "timestamp"),
        Index("idx_metrics_app_time", "app_id", "timestamp"),
    )

    def __repr__(self):
        return f"<Metric(name='{self.metric_name}', value={self.metric_value}, ts='{self.timestamp}')>"
