"""
Platform compatibility shims for problematic Windows environments.
"""

from __future__ import annotations

import os
from collections import namedtuple

_PATCHED = False


def apply_windows_platform_patches() -> None:
    """
    Avoid blocking WMI calls triggered by stdlib `platform.*` helpers on Windows.

    Some environments hang inside `platform.machine()`/`platform.system()` when
    third-party libraries (for example SQLAlchemy) import these values at module
    import time. This shim replaces those functions with fast environment-based
    values. Set `MDSA_DISABLE_WIN_WMI_PATCH=1` to opt out.
    """
    global _PATCHED
    if _PATCHED:
        return

    if os.name != "nt":
        return

    if os.getenv("MDSA_DISABLE_WIN_WMI_PATCH", "").lower() in {"1", "true", "yes"}:
        return

    import platform

    arch = (
        os.environ.get("PROCESSOR_ARCHITECTURE")
        or os.environ.get("PROCESSOR_IDENTIFIER")
        or "AMD64"
    )
    uname_result = namedtuple(
        "uname_result",
        ["system", "node", "release", "version", "machine", "processor"],
    )

    platform.system = lambda: "Windows"
    platform.release = lambda: "10"
    platform.version = lambda: os.environ.get("PROCESSOR_REVISION", "")
    platform.win32_ver = lambda *args, **kwargs: ("Windows", "10", "", arch)
    platform.machine = lambda: arch
    platform.processor = lambda: arch
    platform.uname = lambda: uname_result(
        "Windows",
        os.environ.get("COMPUTERNAME", ""),
        os.environ.get("OS", ""),
        os.environ.get("PROCESSOR_REVISION", ""),
        arch,
        arch,
    )

    _PATCHED = True
