"""
MDSA App Validation Tool

Validates that an application correctly implements the MDSA API contract.

Usage:
    python -m mdsa.tools.validate_app http://localhost:8000
    python -m mdsa.tools.validate_app http://localhost:8000 --verbose
    python -m mdsa.tools.validate_app http://localhost:8000 --json

Author: VICKY (Vicky Vignesh) + Claude Opus 4.5
Version: 2.1.0
"""

import sys
import json
import argparse
from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass, field, asdict
from datetime import datetime

try:
    import requests
except ImportError:
    print("Error: 'requests' package is required. Install with: pip install requests")
    sys.exit(1)


@dataclass
class EndpointTest:
    """Result of testing a single endpoint"""
    path: str
    status: str  # "PASS", "FAIL", "SKIP"
    required: bool
    response_code: Optional[int] = None
    response_time_ms: Optional[float] = None
    error: Optional[str] = None
    missing_keys: List[str] = field(default_factory=list)
    response_sample: Optional[Dict] = None


@dataclass
class ValidationResult:
    """Complete validation result"""
    endpoint: str
    timestamp: str
    tests: List[EndpointTest] = field(default_factory=list)
    passed: int = 0
    failed: int = 0
    skipped: int = 0

    @property
    def success(self) -> bool:
        """Validation passes if all required endpoints pass"""
        return self.failed == 0


# MDSA API Contract Definition
REQUIRED_ENDPOINTS = [
    {
        "path": "/api/health",
        "required_keys": ["status"],
        "description": "Health check endpoint"
    },
    {
        "path": "/api/domains",
        "required_keys": ["domains"],
        "description": "Domains list endpoint"
    },
    {
        "path": "/api/metrics",
        "required_keys": [],  # Flexible format accepted
        "description": "Metrics endpoint"
    }
]

OPTIONAL_ENDPOINTS = [
    {
        "path": "/api/tools",
        "required_keys": ["tools"],
        "description": "Tools list endpoint"
    },
    {
        "path": "/api/models",
        "required_keys": ["models"],
        "description": "Models list endpoint"
    }
]


def test_endpoint(
    base_url: str,
    endpoint: Dict,
    timeout: int = 5,
    required: bool = True
) -> EndpointTest:
    """
    Test a single endpoint against the MDSA API contract.

    Args:
        base_url: Base URL of the app (e.g., http://localhost:8000)
        endpoint: Endpoint specification dict
        timeout: Request timeout in seconds
        required: Whether this endpoint is required

    Returns:
        EndpointTest with results
    """
    path = endpoint["path"]
    required_keys = endpoint.get("required_keys", [])
    url = f"{base_url.rstrip('/')}{path}"

    test = EndpointTest(
        path=path,
        status="UNKNOWN",
        required=required
    )

    try:
        start_time = datetime.now()
        response = requests.get(url, timeout=timeout)
        elapsed = (datetime.now() - start_time).total_seconds() * 1000

        test.response_code = response.status_code
        test.response_time_ms = round(elapsed, 2)

        if response.status_code == 200:
            try:
                data = response.json()
                test.response_sample = _truncate_response(data)

                # Check for required keys
                missing = [k for k in required_keys if k not in data]

                if missing:
                    test.status = "FAIL"
                    test.missing_keys = missing
                    test.error = f"Missing required keys: {missing}"
                else:
                    test.status = "PASS"

            except json.JSONDecodeError:
                test.status = "FAIL"
                test.error = "Response is not valid JSON"
        elif response.status_code == 404:
            if required:
                test.status = "FAIL"
                test.error = f"Endpoint not found (404)"
            else:
                test.status = "SKIP"
                test.error = "Optional endpoint not implemented"
        else:
            test.status = "FAIL"
            test.error = f"HTTP {response.status_code}"

    except requests.Timeout:
        test.status = "FAIL"
        test.error = f"Request timed out after {timeout}s"

    except requests.ConnectionError:
        test.status = "FAIL"
        test.error = "Connection refused - is the app running?"

    except Exception as e:
        test.status = "FAIL"
        test.error = str(e)

    return test


def _truncate_response(data: Any, max_items: int = 3) -> Any:
    """Truncate response for display purposes"""
    if isinstance(data, dict):
        return {k: _truncate_response(v, max_items) for k, v in list(data.items())[:10]}
    elif isinstance(data, list):
        if len(data) > max_items:
            return data[:max_items] + [f"... and {len(data) - max_items} more"]
        return data
    return data


def validate_app(
    endpoint: str,
    timeout: int = 5,
    include_optional: bool = True
) -> ValidationResult:
    """
    Validate an application against the MDSA API contract.

    Args:
        endpoint: Base URL of the app
        timeout: Request timeout in seconds
        include_optional: Whether to test optional endpoints

    Returns:
        ValidationResult with all test results
    """
    result = ValidationResult(
        endpoint=endpoint,
        timestamp=datetime.now().isoformat()
    )

    # Test required endpoints
    for ep in REQUIRED_ENDPOINTS:
        test = test_endpoint(endpoint, ep, timeout, required=True)
        result.tests.append(test)

        if test.status == "PASS":
            result.passed += 1
        elif test.status == "FAIL":
            result.failed += 1
        else:
            result.skipped += 1

    # Test optional endpoints
    if include_optional:
        for ep in OPTIONAL_ENDPOINTS:
            test = test_endpoint(endpoint, ep, timeout, required=False)
            result.tests.append(test)

            if test.status == "PASS":
                result.passed += 1
            elif test.status == "SKIP":
                result.skipped += 1
            else:
                # Optional endpoints failing is not critical
                result.skipped += 1

    return result


def print_result(result: ValidationResult, verbose: bool = False):
    """Print validation result in human-readable format"""
    print(f"\n{'='*60}")
    print(f"MDSA App Validation: {result.endpoint}")
    print(f"{'='*60}")
    print(f"Timestamp: {result.timestamp}")
    print()

    # Print each test
    for test in result.tests:
        if test.status == "PASS":
            icon = "\033[92m✓\033[0m"  # Green checkmark
        elif test.status == "FAIL":
            icon = "\033[91m✗\033[0m"  # Red X
        else:
            icon = "\033[93m○\033[0m"  # Yellow circle

        req_label = "(required)" if test.required else "(optional)"
        print(f"{icon} {test.path}: {test.status} {req_label}")

        if test.error and (test.status == "FAIL" or verbose):
            print(f"   Error: {test.error}")

        if verbose and test.response_time_ms:
            print(f"   Response time: {test.response_time_ms}ms")

        if verbose and test.response_sample:
            sample = json.dumps(test.response_sample, indent=2)
            for line in sample.split('\n')[:10]:
                print(f"   {line}")

    # Print summary
    print()
    print(f"{'─'*60}")
    total = result.passed + result.failed + result.skipped
    print(f"Results: {result.passed} passed, {result.failed} failed, {result.skipped} skipped (of {total})")

    if result.success:
        print("\033[92m✓ VALIDATION PASSED - App is MDSA compatible!\033[0m")
    else:
        print("\033[91m✗ VALIDATION FAILED - App does not meet MDSA requirements\033[0m")
        print()
        print("Fix the following issues:")
        for test in result.tests:
            if test.status == "FAIL" and test.required:
                print(f"  - {test.path}: {test.error}")

    print()


def print_json(result: ValidationResult):
    """Print validation result as JSON"""
    output = {
        "endpoint": result.endpoint,
        "timestamp": result.timestamp,
        "success": result.success,
        "summary": {
            "passed": result.passed,
            "failed": result.failed,
            "skipped": result.skipped
        },
        "tests": [asdict(t) for t in result.tests]
    }
    print(json.dumps(output, indent=2))


def main():
    """Main entry point for CLI"""
    parser = argparse.ArgumentParser(
        description="Validate an application against the MDSA API contract",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m mdsa.tools.validate_app http://localhost:8000
  python -m mdsa.tools.validate_app http://localhost:8000 --verbose
  python -m mdsa.tools.validate_app http://localhost:8000 --json

For more information, see: docs/APP_INTEGRATION.md
        """
    )

    parser.add_argument(
        "endpoint",
        nargs="?",
        default="http://localhost:8000",
        help="Base URL of the app to validate (default: http://localhost:8000)"
    )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Show detailed output including response samples"
    )

    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON"
    )

    parser.add_argument(
        "-t", "--timeout",
        type=int,
        default=5,
        help="Request timeout in seconds (default: 5)"
    )

    parser.add_argument(
        "--required-only",
        action="store_true",
        help="Only test required endpoints"
    )

    args = parser.parse_args()

    # Run validation
    result = validate_app(
        endpoint=args.endpoint,
        timeout=args.timeout,
        include_optional=not args.required_only
    )

    # Output results
    if args.json:
        print_json(result)
    else:
        print_result(result, verbose=args.verbose)

    # Exit with appropriate code
    sys.exit(0 if result.success else 1)


if __name__ == "__main__":
    main()
