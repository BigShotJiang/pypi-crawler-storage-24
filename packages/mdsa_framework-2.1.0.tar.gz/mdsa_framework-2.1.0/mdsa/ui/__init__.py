"""
MDSA UI Module.

Keep this package import-safe. Importing ``mdsa.ui`` should not eagerly load the
FastAPI app or touch runtime configuration paths.
"""

from pathlib import Path

DASHBOARD_DIR = Path(__file__).parent

__all__ = ["run_dashboard", "DASHBOARD_DIR", "dashboard_app"]


def __getattr__(name):
    """Lazily expose dashboard entry points without importing the app eagerly."""
    if name == "run_dashboard":
        from mdsa.ui.dashboard import run_dashboard

        return run_dashboard

    if name == "dashboard_app":
        from mdsa.ui.dashboard.app import app as dashboard_app

        return dashboard_app

    raise AttributeError(f"module 'mdsa.ui' has no attribute {name!r}")


def __dir__():
    return sorted(set(globals()) | {"run_dashboard", "dashboard_app", "DASHBOARD_DIR"})
