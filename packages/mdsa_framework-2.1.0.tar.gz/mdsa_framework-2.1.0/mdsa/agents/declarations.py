"""
Declarative agent schema and registry for MDSA.

Supports YAML/JSON declarations with strict required fields so orchestration
can be configured per domain without hardcoding runtime behavior.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import yaml


class AgentDeclarationError(ValueError):
    """Raised when an agent declaration is invalid."""


@dataclass(frozen=True)
class AgentDeclaration:
    """Normalized declaration for one agent."""

    name: str
    domain: str
    model: str
    tools: List[str] = field(default_factory=list)
    validators: List[str] = field(default_factory=list)
    memory: Dict[str, Any] = field(default_factory=dict)
    policy: Dict[str, Any] = field(default_factory=dict)
    mcp: List[str] = field(default_factory=list)
    workflow: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "AgentDeclaration":
        """Validate and normalize a declaration payload."""
        if not isinstance(raw, dict):
            raise AgentDeclarationError("Agent declaration must be a mapping")

        required = ("name", "domain", "model")
        missing = [field_name for field_name in required if not raw.get(field_name)]
        if missing:
            raise AgentDeclarationError(
                f"Missing required agent fields: {', '.join(missing)}"
            )

        def _ensure_str_list(value: Any, field_name: str) -> List[str]:
            if value is None:
                return []
            if not isinstance(value, list) or not all(isinstance(v, str) for v in value):
                raise AgentDeclarationError(
                    f"Agent field '{field_name}' must be a list of strings"
                )
            return value

        def _ensure_dict(value: Any, field_name: str) -> Dict[str, Any]:
            if value is None:
                return {}
            if not isinstance(value, dict):
                raise AgentDeclarationError(
                    f"Agent field '{field_name}' must be a mapping"
                )
            return value

        return cls(
            name=str(raw["name"]).strip(),
            domain=str(raw["domain"]).strip(),
            model=str(raw["model"]).strip(),
            tools=_ensure_str_list(raw.get("tools"), "tools"),
            validators=_ensure_str_list(raw.get("validators"), "validators"),
            memory=_ensure_dict(raw.get("memory"), "memory"),
            policy=_ensure_dict(raw.get("policy"), "policy"),
            mcp=_ensure_str_list(raw.get("mcp"), "mcp"),
            workflow=_ensure_dict(raw.get("workflow"), "workflow"),
        )


class AgentRegistry:
    """In-memory registry for schema-validated agent declarations."""

    def __init__(self) -> None:
        self._agents: Dict[str, AgentDeclaration] = {}

    def register(self, declaration: AgentDeclaration) -> None:
        self._agents[declaration.name] = declaration

    def register_many(self, declarations: Iterable[AgentDeclaration]) -> None:
        for declaration in declarations:
            self.register(declaration)

    def get(self, name: str) -> Optional[AgentDeclaration]:
        return self._agents.get(name)

    def list(self) -> List[AgentDeclaration]:
        return list(self._agents.values())

    def by_domain(self, domain: str) -> List[AgentDeclaration]:
        return [agent for agent in self._agents.values() if agent.domain == domain]

    def clear(self) -> None:
        self._agents.clear()

    def __len__(self) -> int:
        return len(self._agents)


def _parse_declaration_file(path: Path) -> Dict[str, Any]:
    if not path.exists():
        raise AgentDeclarationError(f"Agent declaration file not found: {path}")

    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in {".yaml", ".yml"}:
        payload = yaml.safe_load(text)
    elif path.suffix.lower() == ".json":
        payload = json.loads(text)
    else:
        raise AgentDeclarationError(
            "Unsupported declaration format. Use .yaml/.yml or .json"
        )

    if payload is None:
        return {}
    if not isinstance(payload, dict):
        raise AgentDeclarationError("Declaration file must contain a mapping root")
    return payload


def load_agent_declarations(path: str | Path) -> List[AgentDeclaration]:
    """
    Load and validate declarations from YAML/JSON.

    Accepted root shapes:
    - {"agents": [ ... ]}
    - {"agent_name": {...}, "other_agent": {...}}
    """
    file_path = Path(path)
    payload = _parse_declaration_file(file_path)

    raw_agents: List[Dict[str, Any]]
    if "agents" in payload:
        if not isinstance(payload["agents"], list):
            raise AgentDeclarationError("'agents' must be a list")
        raw_agents = payload["agents"]
    else:
        # Map-style declarations.
        raw_agents = []
        for maybe_name, maybe_payload in payload.items():
            if not isinstance(maybe_payload, dict):
                raise AgentDeclarationError(
                    f"Agent declaration '{maybe_name}' must be a mapping"
                )
            normalized = {"name": maybe_name, **maybe_payload}
            raw_agents.append(normalized)

    declarations = [AgentDeclaration.from_dict(agent) for agent in raw_agents]

    # Enforce unique names.
    seen = set()
    for declaration in declarations:
        if declaration.name in seen:
            raise AgentDeclarationError(
                f"Duplicate agent declaration name: {declaration.name}"
            )
        seen.add(declaration.name)

    return declarations

