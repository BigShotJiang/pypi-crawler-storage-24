"""
Agent declaration support for MDSA.

Provides schema-validated loading for declarative agent definitions.
"""

from .declarations import (
    AgentDeclaration,
    AgentDeclarationError,
    AgentRegistry,
    load_agent_declarations,
)

__all__ = [
    "AgentDeclaration",
    "AgentDeclarationError",
    "AgentRegistry",
    "load_agent_declarations",
]

