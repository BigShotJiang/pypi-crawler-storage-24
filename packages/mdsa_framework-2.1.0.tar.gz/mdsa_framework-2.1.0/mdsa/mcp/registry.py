"""
MCP connector registry and health checks.

This module provides a minimal runtime abstraction for registering MCP
connectors and validating basic connector health.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


@dataclass
class MCPConnector:
    """Metadata for one MCP connector."""

    name: str
    endpoint: str
    transport: str = "http"
    auth_type: str = "none"
    timeout_seconds: int = 3
    metadata: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True


class MCPRegistry:
    """In-memory MCP connector registry with heartbeat support."""

    def __init__(self) -> None:
        self._connectors: Dict[str, MCPConnector] = {}

    def register(self, connector: MCPConnector) -> None:
        self._connectors[connector.name] = connector

    def unregister(self, name: str) -> bool:
        return self._connectors.pop(name, None) is not None

    def get(self, name: str) -> Optional[MCPConnector]:
        return self._connectors.get(name)

    def list(self) -> List[MCPConnector]:
        return list(self._connectors.values())

    def heartbeat(self, name: str) -> Dict[str, Any]:
        connector = self.get(name)
        if connector is None:
            return {
                "name": name,
                "healthy": False,
                "error": "connector_not_found",
                "checked_at": datetime.now(timezone.utc).isoformat(),
            }
        return self._probe(connector)

    def heartbeat_all(self) -> List[Dict[str, Any]]:
        return [self._probe(connector) for connector in self.list()]

    def _probe(self, connector: MCPConnector) -> Dict[str, Any]:
        checked_at = datetime.now(timezone.utc).isoformat()
        if not connector.enabled:
            return {
                "name": connector.name,
                "healthy": False,
                "error": "connector_disabled",
                "checked_at": checked_at,
            }

        # HTTP connectors: GET /health first, then endpoint fallback.
        if connector.transport.lower() == "http":
            candidates = [
                connector.endpoint.rstrip("/") + "/health",
                connector.endpoint,
            ]
            for url in candidates:
                try:
                    response = requests.get(url, timeout=connector.timeout_seconds)
                    if response.status_code < 500:
                        return {
                            "name": connector.name,
                            "healthy": response.ok,
                            "status_code": response.status_code,
                            "endpoint": url,
                            "checked_at": checked_at,
                        }
                except requests.RequestException as exc:
                    logger.debug("MCP heartbeat failed for %s: %s", connector.name, exc)

            return {
                "name": connector.name,
                "healthy": False,
                "error": "endpoint_unreachable",
                "checked_at": checked_at,
            }

        # Unknown/non-http transport is registered but not actively probed yet.
        return {
            "name": connector.name,
            "healthy": True,
            "status": "registered",
            "transport": connector.transport,
            "checked_at": checked_at,
        }

