"""
MDSA Framework public package API.

This module intentionally avoids eager imports so `import mdsa` stays fast and
side-effect free in tests, CLIs, and constrained environments.
"""

from importlib import import_module
from typing import Dict, Tuple

__version__ = "2.1.0"
__author__ = "MDSA Team"
__license__ = "Apache 2.0"

__all__ = [
    "__version__",
    "__author__",
    "__license__",
    "MDSA",
    "IntentRouter",
    "StateMachine",
    "WorkflowState",
    "MessageBus",
    "HardwareDetector",
    "ConfigLoader",
    "setup_logger",
    "ModelManager",
    "ModelConfig",
    "QuantizationType",
    "ModelTier",
    "DomainConfig",
    "DomainRegistry",
    "DomainExecutor",
    "PromptBuilder",
    "ResponseValidator",
    "create_finance_domain",
    "create_medical_domain",
    "create_support_domain",
    "create_technical_domain",
    "MonitoringService",
    "RequestMetric",
    "DualRAG",
    "LocalRAG",
    "GlobalRAG",
    "RAG_AVAILABLE",
    "Tool",
    "ToolResult",
    "ToolRegistry",
    "ToolManager",
    "SmartToolExecutor",
    "AgentDeclaration",
    "AgentRegistry",
    "load_agent_declarations",
    "MCPConnector",
    "MCPRegistry",
    "AuditEvent",
    "AuditLogger",
]

_LAZY_IMPORTS: Dict[str, Tuple[str, str]] = {
    "MDSA": ("mdsa.core.orchestrator", "MDSA"),
    "IntentRouter": ("mdsa.core.router", "IntentRouter"),
    "StateMachine": ("mdsa.core.state_machine", "StateMachine"),
    "WorkflowState": ("mdsa.core.state_machine", "WorkflowState"),
    "MessageBus": ("mdsa.core.communication_bus", "MessageBus"),
    "HardwareDetector": ("mdsa.utils", "HardwareDetector"),
    "ConfigLoader": ("mdsa.utils", "ConfigLoader"),
    "setup_logger": ("mdsa.utils", "setup_logger"),
    "ModelManager": ("mdsa.models", "ModelManager"),
    "ModelConfig": ("mdsa.models", "ModelConfig"),
    "QuantizationType": ("mdsa.models", "QuantizationType"),
    "ModelTier": ("mdsa.models", "ModelTier"),
    "DomainConfig": ("mdsa.domains", "DomainConfig"),
    "DomainRegistry": ("mdsa.domains", "DomainRegistry"),
    "DomainExecutor": ("mdsa.domains", "DomainExecutor"),
    "PromptBuilder": ("mdsa.domains", "PromptBuilder"),
    "ResponseValidator": ("mdsa.domains", "ResponseValidator"),
    "create_finance_domain": ("mdsa.domains", "create_finance_domain"),
    "create_medical_domain": ("mdsa.domains", "create_medical_domain"),
    "create_support_domain": ("mdsa.domains", "create_support_domain"),
    "create_technical_domain": ("mdsa.domains", "create_technical_domain"),
    "MonitoringService": ("mdsa.monitoring", "MonitoringService"),
    "RequestMetric": ("mdsa.monitoring", "RequestMetric"),
    "DualRAG": ("mdsa.rag", "DualRAG"),
    "LocalRAG": ("mdsa.rag", "LocalRAG"),
    "GlobalRAG": ("mdsa.rag", "GlobalRAG"),
    "RAG_AVAILABLE": ("mdsa.rag", "RAG_AVAILABLE"),
    "Tool": ("mdsa.tools", "Tool"),
    "ToolResult": ("mdsa.tools", "ToolResult"),
    "ToolRegistry": ("mdsa.tools", "ToolRegistry"),
    "ToolManager": ("mdsa.tools", "ToolManager"),
    "SmartToolExecutor": ("mdsa.tools", "SmartToolExecutor"),
    "AgentDeclaration": ("mdsa.agents", "AgentDeclaration"),
    "AgentRegistry": ("mdsa.agents", "AgentRegistry"),
    "load_agent_declarations": ("mdsa.agents", "load_agent_declarations"),
    "MCPConnector": ("mdsa.mcp", "MCPConnector"),
    "MCPRegistry": ("mdsa.mcp", "MCPRegistry"),
    "AuditEvent": ("mdsa.audit", "AuditEvent"),
    "AuditLogger": ("mdsa.audit", "AuditLogger"),
}


def __getattr__(name: str):
    if name not in _LAZY_IMPORTS:
        raise AttributeError(f"module 'mdsa' has no attribute '{name}'")

    module_name, attr_name = _LAZY_IMPORTS[name]
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
