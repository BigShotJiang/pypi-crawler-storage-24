"""
Compatibility setup entrypoint.

Project metadata is defined in pyproject.toml.
"""

import os
from collections import namedtuple

# Some Windows/Python 3.13 environments hang in stdlib platform WMI helpers
# during setuptools import. Patch these early for setup/build compatibility.
if os.name == "nt" and os.getenv("MDSA_DISABLE_WIN_WMI_PATCH", "").lower() not in {"1", "true", "yes"}:
    import platform

    arch = os.environ.get("PROCESSOR_ARCHITECTURE") or os.environ.get("PROCESSOR_IDENTIFIER") or "AMD64"
    uname_result = namedtuple(
        "uname_result",
        ["system", "node", "release", "version", "machine", "processor"],
    )
    platform.win32_ver = lambda *args, **kwargs: ("Windows", "", "", "")
    platform.system = lambda: "Windows"
    platform.machine = lambda: arch
    platform.processor = lambda: arch
    platform.uname = lambda: uname_result(
        "Windows",
        os.environ.get("COMPUTERNAME", ""),
        os.environ.get("OS", ""),
        os.environ.get("PROCESSOR_REVISION", ""),
        arch,
        arch,
    )

from setuptools import setup

setup()
