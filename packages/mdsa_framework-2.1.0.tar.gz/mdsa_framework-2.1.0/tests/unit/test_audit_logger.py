from pathlib import Path

from mdsa.audit.logger import AuditLogger


def test_audit_logger_hash_chain(tmp_path: Path):
    log_file = tmp_path / "audit" / "events.jsonl"
    logger = AuditLogger(log_path=log_file)
    logger.log(
        actor="admin",
        action="login",
        resource="auth/session",
        outcome="success",
    )
    logger.log(
        actor="admin",
        action="query",
        resource="orchestrator/query",
        outcome="success",
        details={"domain": "support"},
    )

    assert log_file.exists()
    assert logger.verify_chain() is True

