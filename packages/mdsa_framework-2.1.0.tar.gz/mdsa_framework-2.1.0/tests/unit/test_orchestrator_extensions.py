from pathlib import Path

from mdsa.core.orchestrator import TinyBERTOrchestrator


def test_orchestrator_exposes_version_and_config_path():
    orchestrator = TinyBERTOrchestrator(config_path="custom.yaml", log_level="ERROR")
    assert orchestrator.config_path == "custom.yaml"
    assert orchestrator.version.startswith("2.")


def test_orchestrator_loads_agent_declarations(tmp_path: Path):
    declarations_file = tmp_path / "agents.yaml"
    declarations_file.write_text(
        """
agents:
  - name: support_agent
    domain: support
    model: ollama://llama3.2:3b
    tools: [ticket_lookup]
""",
        encoding="utf-8",
    )

    orchestrator = TinyBERTOrchestrator(log_level="ERROR")
    loaded = orchestrator.load_agent_declarations(str(declarations_file))
    assert loaded == 1
    agents = orchestrator.get_registered_agents()
    assert len(agents) == 1
    assert agents[0]["name"] == "support_agent"


def test_orchestrator_registers_mcp_connector():
    orchestrator = TinyBERTOrchestrator(log_level="ERROR")
    orchestrator.register_mcp_connector(
        name="test",
        endpoint="http://127.0.0.1:65535",
    )
    health = orchestrator.get_mcp_health()
    assert len(health) == 1
    assert health[0]["name"] == "test"

