from pathlib import Path

import pytest

from mdsa.agents.declarations import (
    AgentDeclarationError,
    AgentRegistry,
    load_agent_declarations,
)


def test_load_agent_declarations_from_yaml(tmp_path: Path):
    path = tmp_path / "agents.yaml"
    path.write_text(
        """
agents:
  - name: support_agent
    domain: support
    model: ollama://llama3.2:3b
    tools: [ticket_lookup]
    validators: [query_safety]
""",
        encoding="utf-8",
    )

    declarations = load_agent_declarations(path)
    assert len(declarations) == 1
    assert declarations[0].name == "support_agent"
    assert declarations[0].domain == "support"
    assert declarations[0].tools == ["ticket_lookup"]


def test_load_agent_declarations_rejects_missing_required(tmp_path: Path):
    path = tmp_path / "bad_agents.yaml"
    path.write_text(
        """
agents:
  - name: broken
    domain: support
""",
        encoding="utf-8",
    )

    with pytest.raises(AgentDeclarationError):
        load_agent_declarations(path)


def test_agent_registry_by_domain(tmp_path: Path):
    path = tmp_path / "agents.yaml"
    path.write_text(
        """
agents:
  - name: finance_agent
    domain: finance
    model: ollama://llama3.2:3b
  - name: support_agent
    domain: support
    model: ollama://llama3.2:3b
""",
        encoding="utf-8",
    )
    registry = AgentRegistry()
    registry.register_many(load_agent_declarations(path))

    finance = registry.by_domain("finance")
    assert len(finance) == 1
    assert finance[0].name == "finance_agent"

