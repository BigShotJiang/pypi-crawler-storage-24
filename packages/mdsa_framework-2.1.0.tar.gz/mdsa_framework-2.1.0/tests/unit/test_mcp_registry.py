from mdsa.mcp.registry import MCPConnector, MCPRegistry


def test_registry_register_and_get():
    registry = MCPRegistry()
    connector = MCPConnector(
        name="docs",
        endpoint="http://127.0.0.1:65535",
    )
    registry.register(connector)

    assert registry.get("docs") is connector
    assert len(registry.list()) == 1


def test_registry_heartbeat_missing_connector():
    registry = MCPRegistry()
    result = registry.heartbeat("missing")
    assert result["healthy"] is False
    assert result["error"] == "connector_not_found"

