"""
Tests for the FastAPI dashboard auth flow and query schema.
"""

import importlib
import sys

from fastapi.testclient import TestClient


def _load_dashboard_app(monkeypatch, tmp_path):
    """Load the dashboard app in a writable, isolated environment."""
    data_dir = tmp_path / "mdsa-data"
    monkeypatch.setenv("MDSA_DATA_DIR", str(data_dir))
    monkeypatch.setenv("MDSA_ENV", "development")
    monkeypatch.setenv("MDSA_ADMIN_USERNAME", "admin")
    monkeypatch.setenv("MDSA_ADMIN_PASSWORD", "TestPass123!")

    from mdsa.core.config import reload_config
    from mdsa.core.db import connection as db_connection
    from mdsa.core.db import init as db_init
    from mdsa.auth import secure_auth

    reload_config()
    db_connection._engine = None
    db_connection._SessionLocal = None
    db_init._engine = None
    secure_auth._secrets = None

    sys.modules.pop("mdsa.ui.dashboard.app", None)
    return importlib.import_module("mdsa.ui.dashboard.app")


def test_dashboard_login_and_auth_me(monkeypatch, tmp_path):
    """The dashboard should authenticate with DB-backed sessions."""
    dashboard_app = _load_dashboard_app(monkeypatch, tmp_path)

    with TestClient(dashboard_app.app) as client:
        login = client.post(
            "/api/auth/login",
            json={"username": "admin", "password": "TestPass123!"},
        )

        assert login.status_code == 200
        assert login.json()["username"] == "admin"
        assert login.json()["access_token"]

        me = client.get("/api/auth/me")
        assert me.status_code == 200
        assert me.json()["username"] == "admin"
        assert me.json()["role"] == "admin"


def test_api_query_returns_top_level_domain(monkeypatch, tmp_path):
    """/api/query should mirror metadata.domain at the top level."""
    dashboard_app = _load_dashboard_app(monkeypatch, tmp_path)

    class DummyOrchestrator:
        def process_request(self, query, context=None):
            return {
                "status": "success",
                "message": "ok",
                "response": "dummy response",
                "metadata": {
                    "domain": "finance",
                    "confidence": 0.99,
                },
            }

    with TestClient(dashboard_app.app) as client:
        dashboard_app.mdsa_orchestrator = DummyOrchestrator()
        dashboard_app.request_history.clear()
        dashboard_app.response_cache.clear()

        client.post(
            "/api/auth/login",
            json={"username": "admin", "password": "TestPass123!"},
        )

        response = client.post(
            "/api/query",
            json={"query": "Transfer funds", "context": {"priority": "high"}},
        )

        assert response.status_code == 200
        payload = response.json()
        assert payload["status"] == "success"
        assert payload["domain"] == "finance"
        assert payload["metadata"]["domain"] == "finance"
        assert payload["response"] == "dummy response"
