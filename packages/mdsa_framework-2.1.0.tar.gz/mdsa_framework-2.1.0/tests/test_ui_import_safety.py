"""
Tests for UI package import safety.
"""

import sys


def test_mdsa_ui_import_is_lazy():
    """Importing mdsa.ui should not eagerly load the FastAPI app."""
    sys.modules.pop("mdsa.ui.dashboard.app", None)
    sys.modules.pop("mdsa.ui.dashboard", None)

    import mdsa.ui as ui

    assert ui.DASHBOARD_DIR.name == "ui"
    assert "mdsa.ui.dashboard.app" not in sys.modules

    run_dashboard = ui.run_dashboard
    assert callable(run_dashboard)
    assert "mdsa.ui.dashboard.app" not in sys.modules
