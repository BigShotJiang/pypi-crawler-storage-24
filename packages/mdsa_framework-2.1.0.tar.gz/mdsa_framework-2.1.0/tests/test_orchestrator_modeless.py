"""Model-less orchestrator behavior tests."""

from __future__ import annotations

from mdsa import MDSA


def _set_modeless_env(monkeypatch) -> None:
    monkeypatch.setenv("MDSA_DISABLE_TINYBERT", "1")
    monkeypatch.setenv("MDSA_DISABLE_HF_MODELS", "1")
    monkeypatch.setenv("MDSA_DISABLE_CHROMADB", "1")
    monkeypatch.setenv("MDSA_DISABLE_EMBEDDINGS", "1")
    monkeypatch.setenv("MDSA_DISABLE_DOMAIN_MODELS", "1")


def test_modeless_auto_registers_fallback_domain(monkeypatch):
    _set_modeless_env(monkeypatch)
    orchestrator = MDSA(log_level="WARNING", enable_reasoning=False, enable_rag=False)
    assert "general" in orchestrator.domains


def test_modeless_query_returns_fallback_response(monkeypatch):
    _set_modeless_env(monkeypatch)
    orchestrator = MDSA(log_level="WARNING", enable_reasoning=False, enable_rag=False)

    result = orchestrator.query("How do I reset my account password?")

    assert result["status"] in {"success", "needs_review"}
    assert result.get("response")
    assert result["metadata"]["domain"] == "general"
    assert result["metadata"]["response_source"].startswith("fallback")
