# MDSA v2.1 Brutal Validation Report

Date: 2026-03-21  
Scope: runtime integration, auth/RBAC, model-less execution, packaging, testability, and release readiness.

## 1) Current Truth

1. Core runtime is stable for model-less operation and deterministic fallback responses.
2. Auth is now secure-first with RBAC expansion (`owner/admin/analyst/viewer`) and compatibility aliasing (`user -> analyst`).
3. End-to-end integration remains partial for deep MCP execution and full frontend unification.
4. Package identity is consistent at `2.1.0`, but external release surfaces still need synchronization.

## 2) Integration Matrix

| Capability | Status | Current Evidence | Remaining Gap |
|---|---|---|---|
| Core orchestration | Partially integrated | Classify -> validate -> execute -> post-validate path in `mdsa/core/orchestrator.py` with audit events | Reasoning task execution still uses placeholder-style routing for many steps |
| Authentication | Mostly integrated | `mdsa.auth` now routes through `secure_auth` as canonical path; DB-backed sessions active | `jwt_auth.py` still ships for compatibility and should be moved to explicit legacy extras |
| RBAC (2-5 users) | Partially integrated | Role contract now supports `owner/admin/analyst/viewer`; dashboard privileged checks accept owner/admin | Some app paths and docs still use old admin/user/viewer language |
| Audit logging | Partially integrated | Hash-chained audit writer (`mdsa/audit/logger.py`) + orchestrator/dashboard event hooks | Not all write paths are uniformly audited yet |
| Agent declarations | Partially integrated | Schema validation and loading are wired (`mdsa/agents/declarations.py`) | Enforcement depth per-request is still limited |
| Validator pipeline | Partially integrated | Deterministic pre/post validator chain in `mdsa/validation/pipeline.py` | Advanced repair/retry workflows are not fully implemented |
| MCP integration | Partially integrated | Connector registry + heartbeat (`mdsa/mcp/registry.py`) | No broad request-time MCP execution orchestration yet |
| Local + global RAG | Partially integrated | DualRAG integrated with fallback behavior in model-less mode | Environment/dependency sensitivity still applies on constrained setups |
| Unified frontend | Not integrated | FastAPI dashboard is the active runtime path | Legacy/alternate UI assets still exist in repo and package |

## 3) What Is Working Now

1. Model-less SDK flow: `from mdsa import MDSA` auto-registers fallback domain and returns deterministic responses.
2. Domain model loading guard: non-Ollama model strings no longer trigger invalid runtime model-loading attempts.
3. Secure auth-first export surface in `mdsa/auth/__init__.py`.
4. RBAC normalization and hierarchy checks in `mdsa/auth/secure_auth.py`.
5. Privileged dashboard routes now require privileged role checks (owner/admin).
6. Full local test suite passes with safe launcher.
7. Build and twine checks pass for `2.1.0`.

## 4) Planned But Not Fully Working

1. Full runtime MCP execution (beyond registration + health checks).
2. Complete physical removal of legacy auth/frontend modules from shipping package.
3. Single consolidated frontend artifact with all required features and no legacy duplication.
4. Reasoning executor with full task/tool dependency execution depth.

## 5) Test and Build Results (This Cycle)

1. `python scripts/run_pytest.py -q -o log_cli=false`: **358 passed, 1 skipped**.
2. `python -m compileall mdsa`: pass.
3. `python -m build --sdist --wheel`: pass.
4. `python -m twine check dist/*`: pass.
5. Version contract check:
   - `mdsa.__version__ == 2.1.0`
   - `importlib.metadata.version('mdsa-framework') == 2.1.0`

## 6) 2-5 User Operating Model (Current)

1. Roles available: `owner`, `admin`, `analyst`, `viewer`.
2. Backward compatibility: incoming `user` role is normalized to `analyst`.
3. Suggested operation:
   - 2 users: `owner` + `analyst`
   - 5 users: `owner`, `admin`, `admin`, `analyst`, `viewer`

## 7) High-Risk Remaining Issues

1. Frontend duplication still present in package contents (`mdsa/ui/dashboard/*` plus legacy UI files).
2. `jwt_auth.py` remains in distributable package for compatibility, increasing long-term confusion/risk.
3. MANIFEST/build output remains noisy with exclude warnings, though builds are successful.
4. External release surfaces (GitHub tags/releases, PyPI narrative, piwheels lag) still need coordinated final release sync.

## 8) Restructure Status

1. `MDSA-v02 final/` folder exists with main/sub structure (`mdsa`, `apps/web`, `tests`, `docs`, `examples`, `legacy-demos`).
2. Latest runtime/auth/model-less patches from `version_1/mdsa/...` have been mirrored into `MDSA-v02 final/mdsa/...`.
3. Legacy demos remain separated under `MDSA-v02 final/legacy-demos/`.
