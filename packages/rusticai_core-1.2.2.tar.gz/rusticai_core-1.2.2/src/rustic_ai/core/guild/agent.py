from __future__ import annotations

import asyncio
from copy import deepcopy
from enum import Enum
import inspect
import logging
from queue import Queue
import threading
from typing import Any, Callable, Dict, Generic, List, Optional, Type, TypeVar

from pydantic import BaseModel, Field

from rustic_ai.core.agents.commons.message_formats import ErrorMessage
from rustic_ai.core.guild.agent_ext.depends import DependencyResolver
from rustic_ai.core.guild.dsl import APT, AgentSpec, GuildSpec, GuildTopics
from rustic_ai.core.guild.metaprog import AgentAnnotations
from rustic_ai.core.guild.metaprog.agent_metaclass import (
    AgentMetaclass,
    FormatMessageHandlers,
    MessageHandler,
    RawMessageHandlers,
)
from rustic_ai.core.guild.metaprog.agent_registry import AgentDependency
from rustic_ai.core.guild.metaprog.constants import MetaclassConstants
from rustic_ai.core.messaging import MDT, AgentTag, Client, Message, Priority
from rustic_ai.core.messaging.core.message import (
    ForwardHeader,
    GuildStackEntry,
    MessageConstants,
    MessageRoutable,
    ProcessEntry,
    ProcessStatus,
    RoutingDestination,
    RoutingOrigin,
    RoutingRule,
    RoutingSlip,
    StateUpdate,
)
from rustic_ai.core.state.models import StateOwner, StateUpdateRequest
from rustic_ai.core.utils import GemstoneGenerator, GemstoneID, JsonDict
from rustic_ai.core.utils.basic_class_utils import get_qualified_class_name


class SelfReadyNotification(BaseModel):
    """
    Notification message to indicate that the agent is ready to process messages.
    This is sent to the agent itself.
    """

    message: str = Field(default="Agent is ready")


class AgentType(Enum):
    """
    Enum class to represent the type of agent.
    """

    HUMAN = "human"
    BOT = "bot"


class AgentMode(Enum):
    """
    Enum class to represent the mode of the agent.
    """

    LOCAL = "local"
    REMOTE = "remote"


class Agent(Generic[APT], metaclass=AgentMetaclass):  # type: ignore
    """
    Base class for all agents
    """

    def __init__(
        self,
        agent_spec: AgentSpec[APT],
        guild_spec: GuildSpec,
        dependency_resolvers: Dict[str, DependencyResolver],
        client_class: Type[Client],
        client_props: Dict[str, Any],
        id_generator: GemstoneGenerator,
        agent_type: AgentType = AgentType.BOT,
        agent_mode: AgentMode = AgentMode.LOCAL,
        handled_formats: list = [],
        organization_id: Optional[str] = None,
    ):
        """
        Initializes a new instance of the Agent class.

        Args:
            agent_spec (AgentSpec): The specification for the agent.
            guild_spec (GuildSpec): The specification for the guild.
            dependency_resolvers (Dict[str, DependencyResolver]): The dependency resolvers for the agent.
            client_class (Type[Client]): The class of the client to use for communication.
            client_props (Dict[str, Any]): The properties for the client.
            id_generator (GemstoneGenerator): The generator for unique IDs.
            agent_type (AgentType): The type of the agent.
            agent_mode (AgentMode): The mode of the agent.
            handled_formats (list): The formats of messages handled by the agent.
        """
        self.logger = logging.getLogger(f"Agent[{agent_spec.name}:{agent_spec.id}]")

        if getattr(self, "_initialized", False):
            self.logger.warning(f"Agent[{agent_spec.name}:{agent_spec.id}] is already initialized.")
            return

        self.agent_spec = agent_spec
        self.guild_spec = guild_spec

        self.config = agent_spec.props

        self.id = agent_spec.id
        self.name = agent_spec.name
        self.type = agent_type
        self.description = agent_spec.description
        self.mode = agent_mode
        self.handled_formats = handled_formats
        self._organization_id: Optional[str] = organization_id
        self._self_inbox: str = GuildTopics.get_self_agent_inbox(self.id)
        self._inbox: str = GuildTopics.get_agent_inbox(self.id)

        self.subscribed_topics = agent_spec.subscribed_topics
        self._dependency_resolvers: Dict[str, DependencyResolver] = {}
        self._agent_tag = AgentTag(id=self.id, name=self.name)
        self._dependency_resolvers = dependency_resolvers or {}

        self._state: JsonDict = {}
        self._guild_state: JsonDict = {}
        self._route_to_default_topic: bool = False

        self._client = self._init_client(client_class, client_props)
        self._id_generator = id_generator

        self._initialized = True

    def get_spec(self) -> AgentSpec[APT]:
        """
        Converts the agent to a specification.

        Returns:
            AgentSpec: The specification for the agent.
        """
        return self.agent_spec

    def _send_to_self(
        self,
        payload: BaseModel,
        new_thread: bool = True,
        origin_message: Optional[Message] = None,
        is_error_message: bool = False,
        reason: Optional[str] = None,
    ) -> GemstoneID:
        """
        Sends a message to the agent itself.

        Returns:
            GemstoneID: The ID of the message sent to the agent.
        """
        return self._send_dict_to_self(
            payload=payload.model_dump(),
            format=get_qualified_class_name(payload.__class__),
            new_thread=new_thread,
            origin_message=origin_message,
            is_error_message=is_error_message,
            reason=reason,
        )

    def _send_dict_to_self(
        self,
        payload: JsonDict,
        priority: Priority = Priority.NORMAL,
        format: str = MessageConstants.RAW_JSON_FORMAT,
        new_thread: bool = True,
        origin_message: Optional[Message] = None,
        is_error_message: bool = False,
        reason: Optional[str] = None,
    ) -> GemstoneID:
        """
        Sends a message to the agent itself.

        Args:
            payload (JsonDict): The payload of the message.
            priority (Priority): The priority of the message.
            format (str): The format of the message.
            new_thread (bool): Whether to create a new thread for the message.
            origin_message (Message): The message that is sending the message.
            is_error_message (bool): Whether the message is an error message.

        Returns:
            GemstoneID: The ID of the message sent to the agent.
        """

        topics = [self._self_inbox]
        msg_id = self._generate_id(priority)

        in_response_to: Optional[int] = None
        recipient_list: List[AgentTag] = []
        thread: List[int] = []
        ttl: Optional[int] = None
        message_history: List[ProcessEntry] = []
        traceparent: Optional[str] = None

        if origin_message:
            in_response_to = origin_message.id
            thread = origin_message.thread.copy()
            if new_thread:
                thread.append(msg_id.to_int())
            ttl = origin_message.ttl

            message_history = origin_message.message_history.copy()
            message_history.append(
                ProcessEntry(
                    agent=self._agent_tag,
                    origin=origin_message.id,
                    result=msg_id.to_int(),
                    processor=f"{self.__class__.__name__}:self",
                    from_topic=origin_message.topic_published_to,
                    to_topics=topics if isinstance(topics, list) else [topics],
                    reason=[reason] if reason else None,
                )
            )
            traceparent = origin_message.traceparent
        else:
            message_history.append(
                ProcessEntry(
                    agent=self._agent_tag,
                    origin=0,
                    result=msg_id.to_int(),
                    processor=f"{self.__class__.__name__}:self",
                    to_topics=topics if isinstance(topics, list) else [topics],
                    reason=[reason] if reason else None,
                )
            )

        routing_slip = self.guild_spec.routes

        msg = Message(
            id_obj=msg_id,
            topics=topics,
            sender=self.get_agent_tag(),
            payload=payload,
            format=format,
            in_response_to=in_response_to,
            recipient_list=recipient_list,
            thread=thread,
            ttl=ttl,
            message_history=message_history,
            routing_slip=routing_slip,
            is_error_message=is_error_message,
            traceparent=traceparent,
        )

        self._client.publish(msg)

        self.logger.debug(f"Sending to Self[{self.name}] {msg_id.to_int()}:")
        self.logger.debug(f"{msg.model_dump()}")

        return msg_id

    @classmethod
    def get_qualified_class_name(cls):
        return f"{cls.__module__}.{cls.__name__}"

    @classmethod
    def list_all_dependencies(cls) -> List[AgentDependency]:
        return list(cls.__annotations__[AgentAnnotations.DEPENDS_ON])

    def get_agent_tag(self) -> AgentTag:
        """
        Returns the tag for the agent.

        Returns:
            AgentTag: The tag for the agent.
        """
        return self._agent_tag

    def get_agent_state(self):
        """
        Get the state of the agent.
        """
        return self._state

    def get_guild_state(self):
        """
        Get the state of the guild.
        """
        return self._guild_state

    def _get_client(self) -> Client:
        return self._client

    def _notify_ready(self):
        """
        Notifies the agent is ready to itself.
        This is used to notify the agent that it is ready to process messages.
        """
        self._send_to_self(
            payload=SelfReadyNotification(),
            new_thread=True,
            origin_message=None,
            is_error_message=False,
        )

    @property
    def guild_id(self) -> str:
        return self.guild_spec.id

    def get_organization(self) -> str:
        if not self._organization_id:
            raise ValueError("No organization_id configured. Ensure the ExecutionEngine has organization_id set.")
        return self._organization_id

    def _generate_id(self, priority: Priority) -> GemstoneID:
        """
        Generates a unique identifier for the agent.

        Args:
            priority (Priority): The priority of the agent.

        Returns:
            str: A unique identifier for the agent.
        """
        return self._id_generator.get_id(priority)

    def _on_message(self, message: Message) -> None:
        """
        Handles a message received by the agent.

        Args:
            message (Message): The message received by the agent.
        """
        handlers = self._get_applicable_processors(message)

        for name, mh in handlers.items():
            mh.handler(self, message)

    def _init_client(self, client_class: Type[Client], client_properties: Dict[str, Any]) -> Client:
        """
        Initializes the client for the agent.

        Args:
            client_class (Type[Client]): The class of the client to initialize.
            client_properties (Dict[str, Any]): The properties for the client.
        """
        client_properties.update(
            {"id": f"{self.guild_id}${self.id}", "name": self.name, "message_handler": self._on_message}
        )
        return client_class(**client_properties)

    def _make_process_context(
        self,
        message: Message,
        method_name: str,
        payload_type: Type[MDT],
        on_send_fixtures: List[Callable],
        on_error_filters: List[Callable],
        outgoing_message_modifiers: List[Callable],
    ) -> ProcessContext:
        """
        Creates a process context for the agent.

        Args:
            message (Message): The message to be processed.

        Returns:
            ProcessContext: The process context for the agent.
        """
        return ProcessContext(
            agent=self,
            message=message,
            method_name=method_name,
            payload_type=payload_type,
            on_send_fixtures=on_send_fixtures,
            on_error_fixtures=on_error_filters,
            outgoing_message_modifiers=outgoing_message_modifiers,
        )

    def _get_applicable_processors(self, message: Message):
        fh: FormatMessageHandlers = self.__rustic_agent_message_handlers__  # type: ignore
        rh: RawMessageHandlers = self.__rustic_agent_raw_message_handlers__  # type: ignore

        format_handlers: Dict[str, MessageHandler] = {}
        raw_handlers: Dict[str, MessageHandler] = {}

        if (
            message.topic_published_to not in GuildTopics.ESSENTIAL_TOPICS
            and message.topic_published_to is not None
            and not message.topic_published_to.startswith(f"{GuildTopics.AGENT_SELF_INBOX_PREFIX}:")
        ):
            format_handlers = fh.get_handlers_for_format(message.format)
            raw_handlers = rh.get_handlers()
        elif message.topic_published_to in GuildTopics.ESSENTIAL_TOPICS or (
            message.topic_published_to is not None and message.topic_published_to == self._self_inbox
        ):
            format_handlers = fh.get_essential_handlers_for_format(message.format)
            raw_handlers = rh.get_essential_handlers()
        else:
            self.logger.info(
                f"[{self.name}:{self.id}] Agent skipped message from {message.sender.name}:{message.sender.id} - \n{message.model_dump()}"
            )

        handlers = {**format_handlers, **raw_handlers}
        return handlers


AT = TypeVar("AT", bound=Agent)

WRAPPER_ASSIGNMENTS = (
    "__module__",
    "__name__",
    "__qualname__",
    "__doc__",
)
WRAPPER_UPDATED = ("__dict__",)


def _update_wrapper(wrapper, func):
    for attr in WRAPPER_ASSIGNMENTS:
        try:
            value = getattr(func, attr)
        except AttributeError:  # pragma: no cover
            pass
        else:
            setattr(wrapper, attr, value)

    dict_attr = getattr(func, "__dict__", {}).copy()

    try:
        if "__annotations__" in dict_attr:  # pragma: no cover
            dict_attr.pop("__annotations__")

        if "__wrapped__" in dict_attr:  # pragma: no cover
            dict_attr.pop("__wrapped__")
        wrapper.__dict__.update(dict_attr)
    except KeyError:  # pragma: no cover
        pass

    # We do not use __wrapped__ to avoid modifying the wrappers signature
    # on inspection using inspect.signature(wrapper) so we store the
    # original function in a special attribute __wfn__
    setattr(wrapper, "__wfn__", func)

    return wrapper


class ProcessContext[MDT]:
    """
    Represents the context of the message to be processed by the agent. This is used within the method to send new messages in the system.
    """

    def __init__(
        self,
        agent: Agent,
        message: Message,
        method_name: str,
        payload_type: Type[MDT] = JsonDict,  # type: ignore
        on_send_fixtures: List[Callable] = [],
        on_error_fixtures: List[Callable] = [],
        outgoing_message_modifiers: List[Callable] = [],
    ):
        self._agent = agent
        self._origin_message = message
        self._method_name = method_name
        self._payload_type = payload_type
        self._sent_messages: List[Message] = []
        self._sent_errors: List[Message] = []

        self._on_send_fixtures = on_send_fixtures
        self._on_error_fixtures = on_error_fixtures
        self._outgoing_message_modifiers = outgoing_message_modifiers
        self._current_routing_step: Optional[RoutingRule] = None
        self._remaining_routing_steps = 0

        self._routing_origin = RoutingOrigin(
            origin_sender=self._origin_message.sender,
            origin_topic=self._origin_message.topic_published_to,
            origin_message_format=self._origin_message.format,
        )

        self._msg_context: JsonDict = deepcopy(message.session_state) if message.session_state else {}

    def _get_id(self, priority: Priority) -> GemstoneID:
        return self._agent._generate_id(priority)

    @property
    def _client(self) -> Client:
        return self.agent._client

    @property
    def payload(self) -> MDT:
        if self._payload_type == JsonDict:
            return self._origin_message.payload  # type: ignore
        else:
            return self._payload_type.model_validate(self._origin_message.payload)  # type: ignore

    @property
    def message(self) -> Message:
        return self._origin_message

    @property
    def agent(self) -> Agent:
        return self._agent

    @property
    def sent_messages(self) -> List[Message]:  # pragma: no cover
        return self._sent_messages

    @property
    def sent_errors(self) -> List[Message]:  # pragma: no cover
        return self._sent_errors

    @property
    def sent_message_count(self) -> int:  # pragma: no cover
        return len(self._sent_messages)

    @property
    def sent_error_count(self) -> int:  # pragma: no cover
        return len(self._sent_errors)

    @property
    def method_name(self) -> str:  # pragma: no cover
        return self._method_name

    @property
    def processor_message_type(self) -> str:  # pragma: no cover
        return self._payload_type.__name__

    @property
    def current_routing_step(self) -> Optional[RoutingRule]:  # pragma: no cover
        return self._current_routing_step

    @property
    def remaining_routing_steps(self) -> int:  # pragma: no cover
        return self._remaining_routing_steps

    @property
    def routing_origin(self) -> RoutingOrigin:
        return self._routing_origin

    def update_context(self, updates: JsonDict) -> None:
        self._msg_context |= updates

    def get_context(self) -> JsonDict:
        return deepcopy(self._msg_context)  # deepcopy to prevent modification of the original context

    def set_routing_slip(self, routing_slip: RoutingSlip) -> None:
        """
        Set the full routing slip for the origin message.

        This replaces any existing routing slip on the message with the
        provided one. Use this when you want to explicitly define or reset
        the complete routing path (e.g. when constructing a new message or
        re-routing an existing one).

        For adding a single routing step to the current routing slip, prefer
        :meth:`add_routing_step`, which appends a new :class:`RoutingRule`
        instead of replacing the entire slip.

        :param routing_slip: The full :class:`RoutingSlip` to associate with
            the origin message, defining its complete routing path.
        """
        self._origin_message.routing_slip = routing_slip

    def set_origin_stack(self, origin_stack: List[GuildStackEntry]) -> None:
        """
        Set the origin guild stack associated with the underlying origin message.

        Parameters
        ----------
        origin_stack : List[str]
            Ordered list of guild identifiers (from outermost to innermost) that
            represents the chain of guilds that have handled or originated the
            message so far. This is typically aligned with the
            ``origin_guild_stack`` / guild stack metadata used by the routing
            layer for cross-guild routing decisions.

        Notes
        -----
        This method is intended for routing components that perform cross-guild
        forwarding (e.g. gateways, bridges, or routers) and need to adjust the
        recorded origin chain before re-emitting the message into another guild.
        Regular agents that only process messages within a single guild usually
        do not need to modify the origin stack directly; they should rely on the
        routing slip and guild stack managed by the messaging infrastructure.
        """
        self._origin_message.origin_guild_stack = origin_stack

    def add_routing_step(self, routing_entry: RoutingRule) -> None:
        """
        Adds a new routing step to the routing slip of the message.
        """

        if not self._origin_message.routing_slip:
            self._origin_message.routing_slip = RoutingSlip()

        self._origin_message.routing_slip.add_step(routing_entry)

    def send_error(self, payload: BaseModel, reason: Optional[str] = None) -> List[GemstoneID]:
        """
        Sends an error message with the BaseModel payload using the routing rules from the routing slip of the origin message.
        If no routing rules are found, the message is sent using the default routing rule.
        """
        format = get_qualified_class_name(payload.__class__)
        data_dict = payload.model_dump()

        return self.send_dict(data_dict, format, error_message=True, reason=reason)

    def send(
        self,
        payload: BaseModel,
        new_thread: bool = False,
        forwarding: bool = False,
        reason: Optional[str] = None,
    ) -> List[GemstoneID]:
        """
        Sends a new message with the BaseModel payload using the routing rules from the routing slip of the origin message.
        If no routing rules are found, the message is sent using the default routing rule.
        """

        format = get_qualified_class_name(payload.__class__)
        data_dict = payload.model_dump()

        return self.send_dict(data_dict, format, new_thread, forwarding, reason=reason)

    def send_dict(
        self,
        payload: JsonDict,
        format: str = MessageConstants.RAW_JSON_FORMAT,
        new_thread: bool = False,
        forwarding: bool = False,
        error_message: bool = False,
        reason: Optional[str] = None,
        clear_origin_stack: bool = False,
    ) -> List[GemstoneID]:
        """
        Sends a new message with the JsonDict payload using the routing rules from the routing slip of the origin message.
        If no routing rules are found, the message is sent using the default routing rule.

        Args:
            payload: The message payload.
            format: The message format.
            new_thread: Whether to start a new thread.
            forwarding: Whether this is a forwarded message.
            error_message: Whether this is an error message.
            reason: Optional reason for the message.
            clear_origin_stack: If True, clears origin_guild_stack on the new message. Used when
                a cross-guild round-trip is complete and the message should be treated as local.
        """

        if error_message and self._on_error_fixtures:
            for fixture in self._on_error_fixtures:
                try:
                    fixture(self.agent, self)  # type: ignore
                except Exception as e:  # pragma: no cover
                    logging.exception(f"Error in on error fixture {fixture.__name__}: {e}")

        if not error_message and self._on_send_fixtures:
            for fixture in self._on_send_fixtures:
                try:
                    fixture(self.agent, self)  # type: ignore
                except Exception as e:  # pragma: no cover
                    logging.exception(f"Error in on send fixture {fixture.__name__}: {e}")

        next_steps: List[RoutingRule] = []
        if self._origin_message.routing_slip:
            next_steps = self._origin_message.routing_slip.get_next_steps(
                self._agent.get_agent_tag(),
                self._agent.get_qualified_class_name(),
                self._method_name,
                self.routing_origin,
                format,
            )

        if not next_steps and not error_message:
            next_steps = [
                RoutingRule(
                    agent=self._agent.get_agent_tag(),
                    method_name=self._method_name,
                    message_format=format,
                )
            ]

        if error_message:
            # Always route error messages to the error topic
            if not next_steps:
                next_steps = []

            next_steps.append(
                RoutingRule(
                    agent=self._agent.get_agent_tag(),
                    method_name=self._method_name,
                    message_format=format,
                    destination=RoutingDestination(
                        topics=[GuildTopics.ERROR_TOPIC],
                    ),
                    reason=reason,
                )
            )

        messages: List[GemstoneID] = []

        self._remaining_routing_steps = len(next_steps)

        logging.debug(f"Agent [{self.agent.name}] from method [{self.method_name}] with rules :\n{next_steps}\n")

        for step in next_steps:
            msgid = self._prepare_and_send_message(
                payload, format, new_thread, forwarding, error_message, step, reason, clear_origin_stack
            )
            if msgid:
                messages.append(msgid)
            self._remaining_routing_steps -= 1

        return messages

    def _prepare_and_send_message(
        self,
        payload: JsonDict,
        format: str,
        new_thread: bool,
        forwarding: bool,
        error_message: bool,
        step: RoutingRule,
        reason: Optional[str] = None,
        clear_origin_stack: bool = False,
    ) -> Optional[GemstoneID]:
        self._current_routing_step = step

        agent_state = self.agent.get_agent_state()
        guild_state = self.agent.get_guild_state()

        routable = MessageRoutable(
            topics=(
                GuildTopics.DEFAULT_TOPICS[0] if self._agent._route_to_default_topic else self._origin_message.topics
            ),
            priority=self._origin_message.priority,
            payload=payload,
            format=format,
            forward_header=None,  # Don't carry forward - only set if forwarding=True or mark_forwarded=True
            context=self.get_context(),
            process_status=step.process_status if step.process_status else self._origin_message.process_status,
        )

        routed = step.apply(self._origin_message, agent_state, guild_state, routable, forwarding)

        if routed is None:
            return None

        guild_state_update: Optional[StateUpdate] = step.get_updated_guild_state(
            self._origin_message,
            agent_state,
            guild_state,
            routed,
            routable,
        )

        if guild_state_update:

            gsu = StateUpdateRequest(
                state_owner=StateOwner.GUILD,
                guild_id=self._agent.guild_id,
                update_format=guild_state_update.update_format,
                state_update=guild_state_update.state_update,
            )

            self._direct_send(
                priority=Priority.HIGH,
                topics=[GuildTopics.STATE_TOPIC],
                payload=gsu.model_dump(),
                format=get_qualified_class_name(StateUpdateRequest),
                in_response_to=self._origin_message.id,
                reason=reason,
            )

        agent_state_update: Optional[StateUpdate] = step.get_updated_state(
            self._origin_message,
            agent_state,
            guild_state,
            routed,
            routable,
        )

        if agent_state_update:

            asu = StateUpdateRequest(
                state_owner=StateOwner.AGENT,
                guild_id=self._agent.guild_id,
                agent_id=self._agent.id,
                update_format=agent_state_update.update_format,
                state_update=agent_state_update.state_update,
            )

            self._direct_send(
                priority=Priority.HIGH,
                topics=[GuildTopics.STATE_TOPIC],
                payload=asu.model_dump(),
                format=get_qualified_class_name(StateUpdateRequest),
                in_response_to=self._origin_message.id,
                reason=reason,
            )

        msg_id = self._get_id(routed.priority)
        msg_thread = self._origin_message.thread.copy()
        if new_thread:
            msg_thread.append(msg_id.to_int())

        message_history = self._origin_message.message_history.copy()
        reasons = [reason] if reason else []
        if self._current_routing_step.reason:
            reasons.append(self._current_routing_step.reason)
        message_history.append(
            ProcessEntry(
                agent=self._agent.get_agent_tag(),
                origin=self._origin_message.id,
                result=msg_id.to_int(),
                processor=self.method_name,
                from_topic=self._origin_message.topic_published_to,
                to_topics=routed.topics if isinstance(routed.topics, list) else [routed.topics],
                reason=reasons if len(reasons) else None,
            )
        )

        routing_slip = (
            self._origin_message.routing_slip.model_copy(deep=True) if self._origin_message.routing_slip else None
        )

        routed_context = routed.context if routed.context else {}

        # Determine origin_guild_stack for the new message
        # If clear_origin_stack is True, the cross-guild round-trip is complete
        new_origin_stack = [] if clear_origin_stack else list(self._origin_message.origin_guild_stack)

        new_message = Message(
            id_obj=msg_id,
            topics=routed.topics,
            sender=self._agent.get_agent_tag(),
            payload=routed.payload,
            format=routed.format,
            in_response_to=self._origin_message.id,
            recipient_list=routed.recipient_list,
            thread=msg_thread,
            ttl=self._origin_message.ttl,
            message_history=message_history,
            forward_header=routed.forward_header,
            routing_slip=routing_slip,
            is_error_message=error_message,
            traceparent=self._origin_message.traceparent,
            session_state=self.get_context() | routed_context,
            enrich_with_history=routed.enrich_with_history,
            process_status=routed.process_status,
            origin_guild_stack=new_origin_stack,
        )

        for modifier in self._outgoing_message_modifiers:
            try:
                modifier(self.agent, self, new_message)
            except Exception as e:  # pragma: no cover
                logging.exception(f"Error in outgoing message modifier {modifier.__name__}: {e}")

        self._client.publish(new_message)

        logging.debug(
            f"Agent [{self.agent.name}] from method [{self.method_name}] sent message for rule [{step}]:\n{new_message.model_dump_json()}\n"
        )

        if not error_message:
            self._sent_messages.append(new_message)
        else:
            self._sent_errors.append(new_message)

        self._current_routing_step = None

        return msg_id

    def _direct_send(
        self,
        priority: Priority,
        topics: List[str],
        payload: JsonDict,
        format: str,
        in_response_to: Optional[int] = None,
        recipient_list: List[AgentTag] = [],
        ttl: Optional[int] = None,
        message_history: List[ProcessEntry] = [],
        forward_header: Optional[ForwardHeader] = None,
        routing_slip: Optional[RoutingSlip] = None,
        is_error_message: bool = False,
        traceparent: Optional[str] = None,
        session_state: Optional[JsonDict] = None,
        enrich_with_history: Optional[int] = 0,
        process_status: Optional[ProcessStatus] = None,
        attach_guild_routes: bool = True,
        reset_history: bool = False,
        carry_session_state: bool = False,
        reason: Optional[str] = None,
    ) -> None:
        msg_id = self._get_id(priority)
        thread = self._origin_message.thread.copy()

        logging.debug(
            f"Sending message to topics: {topics} from {self._agent.get_agent_tag()} in response to {in_response_to}"
        )

        if not in_response_to:
            in_response_to = self._origin_message.id

        if not message_history and not reset_history:
            message_history = self._origin_message.message_history.copy()

        message_history.append(
            ProcessEntry(
                agent=self._agent.get_agent_tag(),
                processor=self.method_name,
                origin=self._origin_message.id,
                result=msg_id.to_int(),
                reason=[reason] if reason else None,
            )
        )

        if carry_session_state:
            session_state = self._origin_message.session_state or {}

        if not traceparent:
            traceparent = self._origin_message.traceparent

        if not routing_slip and attach_guild_routes:
            routing_slip = self.agent.guild_spec.routes
        elif not routing_slip and not attach_guild_routes:
            routing_slip = self._origin_message.routing_slip

        self._client.publish(
            Message(
                id_obj=msg_id,
                topics=topics,
                sender=self._agent.get_agent_tag(),
                payload=payload,
                format=format,
                in_response_to=in_response_to,
                recipient_list=recipient_list,
                thread=thread,
                ttl=ttl,
                message_history=message_history,
                forward_header=forward_header,
                routing_slip=routing_slip,
                is_error_message=is_error_message,
                traceparent=traceparent,
                session_state=session_state,
                enrich_with_history=enrich_with_history,
                process_status=process_status,
                origin_guild_stack=list(self._origin_message.origin_guild_stack),
            )
        )


class ProcessorHelper:
    @staticmethod
    def get_before_fixtures(cls: Type[AT]) -> List[Callable]:
        return getattr(cls, MetaclassConstants.BEFORE_FIXTURES, [])

    @staticmethod
    def get_after_fixtures(cls: Type[AT]) -> List[Callable]:
        return getattr(cls, MetaclassConstants.AFTER_FIXTURES, [])

    @staticmethod
    def get_on_send_fixtures(cls: Type[AT]) -> List[Callable]:
        return getattr(cls, MetaclassConstants.ON_SEND_FIXTURES, [])

    @staticmethod
    def get_on_error_fixtures(cls: Type[AT]) -> List[Callable]:
        return getattr(cls, MetaclassConstants.ON_ERROR_FIXTURES, [])

    @staticmethod
    def get_message_mod_fixtures(cls: Type[AT]) -> List[Callable]:
        return getattr(cls, MetaclassConstants.MESSAGE_MOD_FIXTURES, [])

    @staticmethod
    def resolve_dependency(
        resolver: DependencyResolver,
        dep: AgentDependency,
        org_id: str,
        guild_id: str,
        agent_id: str,
    ):
        if dep.org_level:
            return resolver.get_or_resolve(org_id=org_id)
        elif dep.guild_level:
            return resolver.get_or_resolve(org_id=org_id, guild_id=guild_id)
        else:
            return resolver.get_or_resolve(org_id=org_id, guild_id=guild_id, agent_id=agent_id)

    @staticmethod
    def run_coroutine_blocking(self, func, dependencies, context):
        async def _runner():
            return await func(self, context, **dependencies)

        # Are we already inside an event loop in this thread?
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # Run in a private loop on a worker thread, block current thread
            q: Queue = Queue(maxsize=1)

            def worker():
                new_loop = asyncio.new_event_loop()
                asyncio.set_event_loop(new_loop)
                try:
                    new_loop.run_until_complete(_runner())
                    q.put(None)  # success
                except Exception as e:
                    q.put(e)  # propagate error
                finally:
                    new_loop.close()

            t = threading.Thread(target=worker, daemon=True)
            t.start()
            exc = q.get()  # block until done
            if exc is not None:
                raise exc
        else:
            # No running loop here; this blocks and will re-raise exceptions
            return asyncio.run(_runner())

    @staticmethod
    def execute_before_fixtures(processor, context):
        before_fixtures = ProcessorHelper.get_before_fixtures(processor.__class__)
        for bf in before_fixtures:
            try:
                bf(processor, context)
            except Exception as e:  # pragma: no cover
                logging.exception(f"Error in before fixture {bf.__name__}: {e}")

    @staticmethod
    def execute_after_fixtures(processor, context):
        after_fixtures = ProcessorHelper.get_after_fixtures(processor.__class__)
        for af in after_fixtures:
            try:
                af(processor, context)
            except Exception as e:  # pragma: no cover
                logging.exception(f"Error in after fixture {af.__name__}: {e}")


ALWAYS_HANDLE_FORMATS = [
    "rustic_ai.core.guild.agent.SelfReadyNotification",
    "rustic_ai.core.guild.agent_ext.mixins.health.HealthCheckRequest",
    "rustic_ai.core.state.models.StateUpdateResponse",
    "rustic_ai.core.state.models.StateFetchResponse",
]


def processor(
    clz: Type[MDT],
    predicate: Optional[Callable[[AT, Message], bool]] = None,
    handle_essential: bool = False,
    depends_on: List[str | AgentDependency] = [],
):
    def decorator(func: Callable[[AT, ProcessContext[MDT]], None]):

        deps: List[AgentDependency] = [
            dep if isinstance(dep, AgentDependency) else AgentDependency.from_string(dep) for dep in depends_on
        ]

        def wrapper(self: AT, msg: Message) -> None:

            logging.debug(f"Processing message {msg.id} for {self.get_agent_tag()}")

            predicate_result = predicate(self, msg) if predicate else True

            logging.debug(
                f"Predicate result for {self.get_agent_tag()} on {func.__name__} with MessageFormat: {msg.format} "
                f"and Predicate: {predicate}: {predicate_result}"
            )

            act_only_when_tagged = self.agent_spec.act_only_when_tagged
            is_tagged_for_agent = msg.is_tagged(self.get_agent_tag())
            is_always_handle_format = msg.format in ALWAYS_HANDLE_FORMATS

            if (predicate_result) and (not act_only_when_tagged or (is_tagged_for_agent or is_always_handle_format)):
                runtime_predicate = self.agent_spec.predicates.get(func.__name__)

                should_process = True

                if runtime_predicate:
                    try:
                        should_process = runtime_predicate.evaluate(
                            msg.model_dump(), self.get_agent_state(), self.get_guild_state()
                        )
                    except Exception as e:  # pragma: no cover
                        logging.exception(
                            f"Error in predicate for method [func.__name__]: {runtime_predicate.expression}: {e}"
                        )
                        # TODO: SEND ERROR MESSAGE
                        should_process = False

                if not should_process:
                    logging.debug(
                        f"Predicate {predicate} on method [{func.__name__}] failed for message:\n {msg.model_dump()}\n"
                    )
                    return

                dependencies = {
                    dep.variable_name: ProcessorHelper.resolve_dependency(
                        self._dependency_resolvers[dep.dependency_key],
                        dep,
                        self.get_organization(),
                        self.guild_id,
                        self.id,
                    )
                    for dep in deps
                }

                logging.debug(f"Processor [{func.__name__}] running for message:\n {msg.model_dump_json()}\n")

                send_fixtures = ProcessorHelper.get_on_send_fixtures(self.__class__)
                error_fixtures = ProcessorHelper.get_on_error_fixtures(self.__class__)
                mod_fixtures = ProcessorHelper.get_message_mod_fixtures(self.__class__)
                context = self._make_process_context(
                    msg, func.__name__, clz, send_fixtures, error_fixtures, mod_fixtures
                )

                ProcessorHelper.execute_before_fixtures(self, context)

                try:
                    if inspect.iscoroutinefunction(func):
                        # Blocks until completion, exceptions bubble up
                        ProcessorHelper.run_coroutine_blocking(self, func, dependencies, context)
                    else:
                        func(self, context, **dependencies)
                except Exception as e:
                    logging.exception(f"Error in processor {func.__name__}: {e}")
                    context.send_error(
                        ErrorMessage(
                            agent_type=self.get_qualified_class_name(),
                            error_type="UNHANDLED_EXCEPTION",
                            error_message=str(e),
                        )
                    )
                finally:
                    # Runs exactly once for both sync and async paths
                    ProcessorHelper.execute_after_fixtures(self, context)
            else:
                logging.debug(
                    f"Predicate {predicate} on method [{func.__name__}] failed for message:\n {msg.model_dump()}\n"
                )
                return

        wrapper.__annotations__ = {
            AgentAnnotations.ISHANDLER: True,
            AgentAnnotations.MESSAGE_FORMAT: clz,
            AgentAnnotations.HANDLE_ESSENTIAL: handle_essential,
            AgentAnnotations.HANDLES_RAW: clz == JsonDict,
            AgentAnnotations.DEPENDS_ON: deps,
        }

        return _update_wrapper(wrapper, func)

    return decorator


class AgentFixtures:
    """
    A class to hold before, after, wrap, and on_send fixtures for agents. These are annotations that can be used
    to decorate methods in the agent class that would be called before, after, or around the processing of messages.
    """

    @staticmethod
    def before_process(func: Callable[[Any, ProcessContext[MDT]], None]) -> Callable[[Any, ProcessContext[MDT]], None]:
        """
        Decorator for a method that should be called before the processing of a message.

        Args:
            func (Callable[[AT, ProcessContext[MDT]], None]): The method to be called before the processing of a message.

        Returns:
            Callable[[AT, ProcessContext[MDT]], None]: The decorated method.
        """
        func.__annotations__[AgentAnnotations.IS_BEFORE_PROCESS_FIXTURE] = True
        return func

    @staticmethod
    def after_process(func: Callable[[Any, ProcessContext[MDT]], None]) -> Callable[[Any, ProcessContext[MDT]], None]:
        """
        Decorator for a method that should be called after the processing of a message.

        Args:
            func (Callable[[AT, ProcessContext[MDT]], None]): The method to be called after the processing of a message.

        Returns:
            Callable[[AT, ProcessContext[MDT]], None]: The decorated method.
        """
        func.__annotations__[AgentAnnotations.IS_AFTER_PROCESS_FIXTURE] = True
        return func

    @staticmethod
    def on_send(func: Callable[[Any, ProcessContext[MDT]], None]) -> Callable[[Any, ProcessContext[MDT]], None]:
        """
        Decorator for a method that should be called when a message is sent.

        Args:
            func (Callable[[AT, ProcessContext[MDT]], None]): The method to be called when a message is sent.

        Returns:
            Callable[[AT, ProcessContext[MDT]], None]: The decorated method.
        """
        func.__annotations__[AgentAnnotations.IS_ON_SEND_FIXTURE] = True
        return func

    @staticmethod
    def on_send_error(func: Callable[[Any, ProcessContext[MDT]], None]) -> Callable[[Any, ProcessContext[MDT]], None]:
        """
        Decorator for a method that should be called when an error message is sent.

        Args:
            func (Callable[[AT, ProcessContext[MDT]], None]): The method to be called when an error message is sent.

        Returns:
            Callable[[AT, ProcessContext[MDT]], None]: The decorated method.
        """
        func.__annotations__[AgentAnnotations.IS_ON_SEND_ERROR_FIXTURE] = True
        return func

    @staticmethod
    def outgoing_message_modifier(
        func: Callable[[Any, ProcessContext[MDT], Message], None],
    ) -> Callable[[Any, ProcessContext[MDT], Message], None]:
        """
        Decorator for a method that should be called when a message is sent.

        Args:
            func (Callable[[AT, ProcessContext[MDT]], None]): The method to be called when a message is sent.

        Returns:
            Callable[[AT, ProcessContext[MDT]], None]: The decorated method.
        """
        func.__annotations__[AgentAnnotations.IS_MESSAGE_MOD_FIXTURE] = True
        return func
