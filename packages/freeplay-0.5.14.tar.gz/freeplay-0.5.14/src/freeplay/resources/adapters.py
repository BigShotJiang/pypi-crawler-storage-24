import copy
from dataclasses import dataclass
from typing import Any, ClassVar, Dict, FrozenSet, List, Protocol, Set, Union

from freeplay.errors import FreeplayConfigurationError, log_freeplay_client_warning
from freeplay.support import MediaType


@dataclass
class TextContent:
    text: str


@dataclass
class MediaContentUrl:
    slot_name: str
    type: MediaType
    url: str


@dataclass
class MediaContentBase64:
    slot_name: str
    type: MediaType
    content_type: str
    data: str


class MissingFlavorError(FreeplayConfigurationError):
    def __init__(self, flavor_name: str):
        super().__init__(
            f"Configured flavor ({flavor_name}) not found in SDK. Please update your SDK version or configure "
            "a different model in the Freeplay UI."
        )


@dataclass
class RoleSupport:
    supported: FrozenSet[str]
    coerce_map: Dict[str, str]

    def __post_init__(self) -> None:
        for source, target in self.coerce_map.items():
            if target not in self.supported:
                raise ValueError(
                    "coerce_map target '%s' (from '%s') is not in supported roles"
                    % (target, source)
                )


_DEFAULT_ROLE_SUPPORT = RoleSupport(
    supported=frozenset({"system", "user", "assistant"}),
    coerce_map={"developer": "system"},
)


def prepare_messages(
    flavor_name: str,
    role_support: RoleSupport,
    messages: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Coerce or reject message roles based on adapter's RoleSupport declaration."""
    result: List[Dict[str, Any]] = []
    coerced_roles: Set[str] = set()
    for m in messages:
        role = m.get("role", "")
        if role in role_support.supported:
            result.append(m)
        elif role in role_support.coerce_map:
            coerced_roles.add(role)
            result.append({**m, "role": role_support.coerce_map[role]})
        else:
            raise ValueError("role '%s' is not supported by %s" % (role, flavor_name))
    for role in sorted(coerced_roles):
        log_freeplay_client_warning(
            "%s role is not supported by %s; coercing to %s"
            % (role, flavor_name, role_support.coerce_map[role])
        )
    return result


class LLMAdapter(Protocol):
    role_support: ClassVar[RoleSupport]

    # This method must handle BOTH prompt template messages and provider specific messages.
    def to_llm_syntax(
        self, messages: List[Dict[str, Any]]
    ) -> Union[str, List[Dict[str, Any]]]:
        pass


class PassthroughAdapter(LLMAdapter):
    role_support = _DEFAULT_ROLE_SUPPORT

    def to_llm_syntax(
        self, messages: List[Dict[str, Any]]
    ) -> Union[str, List[Dict[str, Any]]]:
        # We need a deepcopy here to avoid referential equality with the llm_prompt
        return copy.deepcopy(messages)


class AnthropicAdapter(LLMAdapter):
    role_support = _DEFAULT_ROLE_SUPPORT

    def to_llm_syntax(
        self, messages: List[Dict[str, Any]]
    ) -> Union[str, List[Dict[str, Any]]]:
        anthropic_messages = []

        for message in messages:
            if message["role"] == "system":
                continue
            if "has_media" in message and message["has_media"]:
                anthropic_messages.append(
                    {
                        "role": message["role"],
                        "content": [
                            self.__map_content(content)
                            for content in message["content"]
                        ],
                    }
                )
            else:
                anthropic_messages.append(copy.deepcopy(message))

        return anthropic_messages

    @staticmethod
    def __map_content(
        content: Union[TextContent, MediaContentBase64, MediaContentUrl],
    ) -> Dict[str, Any]:
        if isinstance(content, TextContent):
            return {"type": "text", "text": content.text}
        if content.type == "audio" or content.type == "video":
            raise ValueError("Anthropic does not support audio or video content")

        media_type = "image" if content.type == "image" else "document"
        if isinstance(content, MediaContentBase64):
            return {
                "type": media_type,
                "source": {
                    "type": "base64",
                    "media_type": content.content_type,
                    "data": content.data,
                },
            }
        elif isinstance(content, MediaContentUrl):
            return {
                "type": media_type,
                "source": {
                    "type": "url",
                    "url": content.url,
                },
            }
        else:
            raise ValueError(f"Unexpected content type {type(content)}")


_OPENAI_ROLE_SUPPORT = RoleSupport(
    supported=frozenset({"system", "user", "assistant", "tool"}),
    coerce_map={"developer": "system"},
)


class OpenAIAdapter(LLMAdapter):
    role_support = _OPENAI_ROLE_SUPPORT

    def to_llm_syntax(
        self, messages: List[Dict[str, Any]]
    ) -> Union[str, List[Dict[str, Any]]]:
        openai_messages = []

        for message in messages:
            if "has_media" in message and message["has_media"]:
                openai_messages.append(
                    {
                        "role": message["role"],
                        "content": [
                            self.__map_content(content)
                            for content in message["content"]
                        ],
                    }
                )
            else:
                openai_messages.append(copy.deepcopy(message))

        return openai_messages

    @staticmethod
    def __map_content(
        content: Union[TextContent, MediaContentBase64, MediaContentUrl],
    ) -> Dict[str, Any]:
        if isinstance(content, TextContent):
            return {"type": "text", "text": content.text}
        elif isinstance(content, MediaContentBase64):
            return OpenAIAdapter.__format_base64_content(content)
        elif isinstance(content, MediaContentUrl):
            if content.type != "image":
                raise ValueError(
                    "Message contains a non-image URL, but OpenAI only supports image URLs."
                )

            return {"type": "image_url", "image_url": {"url": content.url}}
        else:
            raise ValueError(f"Unexpected content type {type(content)}")

    @staticmethod
    def __format_base64_content(content: MediaContentBase64) -> Dict[str, Any]:
        if content.type == "audio":
            return {
                "type": "input_audio",
                "input_audio": {
                    "data": content.data,
                    "format": content.content_type.split("/")[-1].replace(
                        "mpeg", "mp3"
                    ),
                },
            }
        elif content.type == "file":
            return {
                "type": "file",
                "file": {
                    "filename": f"{content.slot_name}.{content.content_type.split('/')[-1]}",
                    "file_data": f"data:{content.content_type};base64,{content.data}",
                },
            }
        else:
            return {
                "type": "image_url",
                "image_url": {
                    "url": f"data:{content.content_type};base64,{content.data}"
                },
            }


class Llama3Adapter(LLMAdapter):
    role_support = _DEFAULT_ROLE_SUPPORT

    def to_llm_syntax(
        self, messages: List[Dict[str, Any]]
    ) -> Union[str, List[Dict[str, Any]]]:
        if len(messages) < 1:
            raise ValueError("Must have at least one message to format")

        formatted = "<|begin_of_text|>"
        for message in messages:
            formatted += f"<|start_header_id|>{message['role']}<|end_header_id|>\n{message['content']}<|eot_id|>"
        formatted += "<|start_header_id|>assistant<|end_header_id|>"

        return formatted


class GeminiAdapter(LLMAdapter):
    role_support = RoleSupport(
        supported=frozenset({"system", "user", "assistant", "model"}),
        coerce_map={"developer": "system"},
    )

    def to_llm_syntax(
        self, messages: List[Dict[str, Any]]
    ) -> Union[str, List[Dict[str, Any]]]:
        if len(messages) < 1:
            raise ValueError("Must have at least one message to format")

        gemini_messages: List[Dict[str, Any]] = []

        for message in messages:
            if message["role"] == "system":
                continue

            # Already in Gemini format (e.g., history from previous turns
            # with function calls, function responses, or multi-part content)
            if "parts" in message:
                msg_copy: Dict[str, Any] = copy.deepcopy(message)
                if msg_copy.get("role") == "assistant":
                    msg_copy["role"] = "model"
                gemini_messages.append(msg_copy)
            elif "has_media" in message and message["has_media"]:
                gemini_messages.append(
                    {
                        "role": self.__translate_role(message["role"]),
                        "parts": [
                            self.__map_content(content)
                            for content in message["content"]
                        ],
                    }
                )
            elif "content" in message:
                gemini_messages.append(
                    {
                        "role": self.__translate_role(message["role"]),
                        "parts": [{"text": message["content"]}],
                    }
                )
            else:
                fallback: Dict[str, Any] = copy.deepcopy(message)
                gemini_messages.append(fallback)

        return gemini_messages

    @staticmethod
    def __map_content(
        content: Union[TextContent, MediaContentBase64, MediaContentUrl],
    ) -> Dict[str, Any]:
        if isinstance(content, TextContent):
            return {"text": content.text}
        elif isinstance(content, MediaContentBase64):
            return {
                "inline_data": {
                    "data": content.data,
                    "mime_type": content.content_type,
                }
            }
        else:
            # MediaContentUrl -- Gemini does not support image URLs
            raise ValueError(
                "Message contains an image URL, but image URLs are not supported by Gemini"
            )

    @staticmethod
    def __translate_role(role: str) -> str:
        if role == "user":
            return "user"
        elif role == "assistant":
            return "model"
        else:
            raise ValueError(f"Gemini formatting found unexpected role {role}")


class OpenAIResponsesAdapter(LLMAdapter):
    role_support = RoleSupport(
        supported=frozenset({"system", "user", "assistant", "developer", "tool"}),
        coerce_map={},
    )

    def to_llm_syntax(
        self, messages: List[Dict[str, Any]]
    ) -> Union[str, List[Dict[str, Any]]]:
        result: List[Dict[str, Any]] = []
        for message in messages:
            if message["role"] == "system":
                continue
            if "has_media" in message and message["has_media"]:
                result.append(
                    {
                        "type": "message",
                        "role": message["role"],
                        "content": [
                            OpenAIResponsesAdapter._map_responses_content(content)
                            for content in message["content"]
                        ],
                    }
                )
            else:
                msg = copy.deepcopy(message)
                result.append({"type": "message", **msg})
        return result

    @staticmethod
    def _map_responses_content(
        content: Union[TextContent, MediaContentBase64, MediaContentUrl],
    ) -> Dict[str, Any]:
        if isinstance(content, TextContent):
            return {"type": "input_text", "text": content.text}
        if content.type == "audio":
            raise ValueError("Audio content is not yet supported by the Responses API")
        if isinstance(content, MediaContentUrl):
            if content.type != "image":
                raise ValueError(
                    "Message contains a non-image URL, but the Responses API only supports image URLs."
                )
            return {"type": "input_image", "image_url": content.url}
        # Must be MediaContentBase64 at this point
        if content.type == "file":
            return {
                "type": "input_file",
                "filename": f"{content.slot_name}.{content.content_type.split('/')[-1]}",
                "file_data": f"data:{content.content_type};base64,{content.data}",
            }
        return {
            "type": "input_image",
            "image_url": f"data:{content.content_type};base64,{content.data}",
        }


class BedrockConverseAdapter(LLMAdapter):
    role_support = _DEFAULT_ROLE_SUPPORT

    def to_llm_syntax(self, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        converse_messages: List[Dict[str, Any]] = []
        for message in messages:
            if message["role"] == "system":
                continue

            role = message["role"]
            if role not in ["user", "assistant"]:
                raise ValueError(f"Unexpected role for Bedrock Converse flavor: {role}")

            if "has_media" in message and message["has_media"]:
                converse_messages.append(
                    {
                        "role": role,
                        "content": [
                            self.__map_content(content)
                            for content in message["content"]
                        ],
                    }
                )
            else:
                content = message["content"]
                if isinstance(content, str):
                    content = [{"text": content}]
                converse_messages.append({"role": role, "content": content})
        return converse_messages

    @staticmethod
    def __map_content(
        content: Union[TextContent, MediaContentBase64, MediaContentUrl],
    ) -> Dict[str, Any]:
        if isinstance(content, TextContent):
            return {"text": content.text}
        elif isinstance(content, MediaContentBase64):
            import base64

            # Extract format from content_type (e.g., "image/png" -> "png")
            format_str = content.content_type.split("/")[-1]

            if content.type == "image":
                return {
                    "image": {
                        "format": format_str,
                        "source": {
                            # Bedrock Converse expects actual bytes
                            "bytes": base64.b64decode(content.data)
                        },
                    }
                }
            elif content.type == "file":
                return {
                    "document": {
                        "format": format_str,
                        "name": content.slot_name,
                        "source": {
                            # Bedrock Converse expects actual bytes
                            "bytes": base64.b64decode(content.data)
                        },
                    }
                }
            else:
                raise ValueError(
                    f"Bedrock Converse does not support {content.type} content"
                )
        elif isinstance(content, MediaContentUrl):  # pyright: ignore[reportUnnecessaryIsInstance]
            raise ValueError(
                "Bedrock Converse does not support URL-based media content"
            )
        else:
            raise ValueError(f"Unexpected content type {type(content)}")


def adaptor_for_flavor(flavor_name: str) -> LLMAdapter:
    if flavor_name in ["baseten_mistral_chat", "mistral_chat", "perplexity_chat"]:
        return PassthroughAdapter()
    elif flavor_name in ["azure_openai_chat", "openai_chat"]:
        return OpenAIAdapter()
    elif flavor_name == "openai_responses":
        return OpenAIResponsesAdapter()
    elif flavor_name == "anthropic_chat":
        return AnthropicAdapter()
    elif flavor_name == "llama_3_chat":
        return Llama3Adapter()
    elif flavor_name in ["gemini_chat", "gemini_api_chat"]:
        return GeminiAdapter()
    elif flavor_name == "amazon_bedrock_converse":
        return BedrockConverseAdapter()
    else:
        raise MissingFlavorError(flavor_name)
