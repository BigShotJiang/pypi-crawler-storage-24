from __future__ import annotations

from collections import defaultdict

from codegen.models import DeferredVar, PredefinedFn, Program, expr, stmt

from sera.make.py_backend.misc import get_python_property_name
from sera.misc import assert_not_null
from sera.models import DataCollection, Package
from sera.models._class import Class
from sera.models._property import DataProperty
from sera.models._schema import Schema


def make_python_update_logic(
    collection: DataCollection,
    target_pkg: Package,
    schema: Schema,
):
    """Generate an update logic module for a collection.

    This generates an async update function that:
    - Takes NodeInput[Model] and LitestarContext as parameters
    - Returns tuple[NodeOutput[Model], UpdateSummary]
    - Validates weakref constraints if the collection has weakref properties (source side)
    - Handles cascade/restrict/set_null if other collections have weakrefs to this class (target side)
    - Handles IntegrityError from database operations
    """
    app = target_pkg.app

    outmod = target_pkg.pkg(collection.get_pymodule_name()).module("update")

    # assuming the collection has only one class
    cls = collection.cls

    # Source-side: does this collection have weakref properties?
    weakref_props = cls.get_weakref_props()
    has_source_weakrefs = len(weakref_props) > 0

    # Target-side: do other collections have weakrefs pointing to this class?
    incoming_weakrefs = schema.get_incoming_weakrefs(cls)
    has_target_weakrefs = len(incoming_weakrefs) > 0

    program = Program()
    program.import_("__future__.annotations", True)
    program.import_("litestar.exceptions.HTTPException", True)
    program.import_(
        "sera.libs.digraph.LitestarContext",
        True,
    )
    program.import_(
        "sera.libs.digraph.NodeInput",
        True,
    )
    program.import_(
        "sera.libs.digraph.NodeOutput",
        True,
    )
    program.import_(
        "sera.libs.digraph.UpdateSummary",
        True,
    )
    program.import_("litestar.status_codes", True)
    program.import_("sqlalchemy.exc.IntegrityError", True)
    program.import_(
        app.models.db.path + f".{collection.get_pymodule_name()}.{cls.name}",
        True,
    )

    target_fetch_old_record = []
    if has_target_weakrefs:
        program.import_("sqlalchemy.select", True)
        target_fetch_old_record = _target_fetch_old_record(cls, incoming_weakrefs)

    source_validate_weakref = []
    if has_source_weakrefs:
        source_validate_weakref = _source_validate_weakref(
            app, collection, weakref_props, program.import_
        )

    target_propagate_changes = []
    if has_target_weakrefs:
        target_propagate_changes = _target_propagate_changes(
            app, collection, incoming_weakrefs, program.import_
        )

    program.root(
        stmt.LineBreak(),
        lambda ast00: ast00.func(
            "update",
            [
                DeferredVar.simple("input", expr.ExprIdent(f"NodeInput[{cls.name}]")),
                DeferredVar.simple("context", expr.ExprIdent("LitestarContext")),
            ],
            return_type=expr.ExprIdent(f"tuple[NodeOutput[{cls.name}], UpdateSummary]"),
            is_async=True,
        )(
            # record = input.args
            lambda ast01: ast01.assign(
                DeferredVar.simple("record"), expr.ExprIdent("input.args")
            ),
            # session = context.session
            lambda ast02: ast02.assign(
                DeferredVar.simple("session"), expr.ExprIdent("context.session")
            ),
            stmt.LineBreak(),
            *target_fetch_old_record,
            *source_validate_weakref,
            # try block
            lambda ast04: ast04.try_()(
                # await session.execute(record.get_update_query())
                stmt.SingleExprStatement(
                    expr.ExprAwait(
                        expr.ExprMethodCall(
                            expr.ExprIdent("session"),
                            "execute",
                            [
                                expr.ExprMethodCall(
                                    expr.ExprIdent("record"),
                                    "get_update_query",
                                    [],
                                )
                            ],
                        )
                    )
                ),
            ),
            # except IntegrityError
            lambda ast04: ast04.catch(expr.ExprIdent("IntegrityError"))(
                stmt.PythonStatement(
                    'raise HTTPException(detail="Invalid request", status_code=status_codes.HTTP_409_CONFLICT)'
                ),
            ),
            stmt.LineBreak(),
            *target_propagate_changes,
            # return NodeOutput(id=input.id, value=record), UpdateSummary()
            lambda ast06: ast06.return_(
                PredefinedFn.tuple(
                    [
                        expr.ExprFuncCall(
                            expr.ExprIdent("NodeOutput"),
                            [
                                PredefinedFn.keyword_assignment(
                                    "id", expr.ExprIdent("input.id")
                                ),
                                PredefinedFn.keyword_assignment(
                                    "value", expr.ExprIdent("record")
                                ),
                            ],
                        ),
                        expr.ExprFuncCall(expr.ExprIdent("UpdateSummary"), []),
                    ]
                )
            ),
        ),
    )

    outmod.write(program)


def _source_validate_weakref(
    app, collection: DataCollection, weakref_props: list[DataProperty], import_fn
) -> list:
    """Build validation statements for source-side weakrefs."""
    grouped = defaultdict(list)
    for p in weakref_props:
        wr = assert_not_null(p.weakref)
        grouped[wr.target_class.name].append(p)

    stmts_out: list = [
        stmt.Comment("Ensure referenced values exist in the referenced record."),
        stmt.Comment(
            "This also acquires a FOR UPDATE lock on the referenced row to prevent concurrent updates."
        ),
    ]

    for target_cls_name, props in grouped.items():
        wr = assert_not_null(props[0].weakref)
        target_var = wr.target_class.get_pymodule_name()
        
        import_fn(
            f"{app.logic.path}.{collection.get_pymodule_name()}.data_consistency.validate_weakrefs_for_{target_var}",
            True,
        )

        fk_col = get_python_property_name(wr.foreign_key_prop)

        args = ["session", f"record.{fk_col}"]
        for p in props:
            args.append(f"record.{p.name}")

        func_name = f"validate_weakrefs_for_{target_var}"
        stmts_out.append(stmt.PythonStatement(f"await {func_name}({', '.join(args)})"))

    stmts_out.append(stmt.LineBreak())
    return stmts_out


def _target_fetch_old_record(
    cls: Class, incoming_weakrefs: dict[str, list[DataProperty]]
) -> list:
    id_prop = cls.get_id_property()
    id_prop_name = id_prop.name if id_prop else "id"

    return [
        stmt.Comment(
            "Load existing record to get old embedded values for cascade comparison"
        ),
        stmt.PythonStatement(
            f"stmt = select({cls.name}).where({cls.name}.{id_prop_name} == record.{id_prop_name}).with_for_update()"
        ),
        stmt.PythonStatement("result = await session.execute(stmt)"),
        stmt.PythonStatement("old_record = result.scalar_one_or_none()"),
        stmt.LineBreak(),
        lambda ast03: ast03.if_(expr.ExprIdent("old_record is None"))(
            stmt.PythonStatement(
                f'raise HTTPException(detail="{cls.name} not found", status_code=status_codes.HTTP_409_CONFLICT)'
            ),
        ),
        stmt.LineBreak(),
        stmt.Comment("Expunge old record to prevent SQLAlchemy from synchronizing"),
        stmt.Comment("in-memory attributes during the update."),
        stmt.PythonStatement("session.expunge(old_record)"),
        stmt.LineBreak(),
    ]


def _target_propagate_changes(
    app, collection: DataCollection, incoming_weakrefs: dict[str, list[DataProperty]], import_fn
) -> list:
    cascade_stmts = []
    cascade_stmts.append(stmt.Comment("Propagate weakref changes"))

    for source_module_name, props_list in incoming_weakrefs.items():
        target_module_name = collection.get_pymodule_name()
        func_name = f"propagate_changes_{target_module_name}_to_{source_module_name}"

        import_fn(
            f"{app.logic.path}.{source_module_name}.data_consistency.{func_name}",
            True,
        )

        cascade_stmts.append(
            stmt.PythonStatement(f"await {func_name}(session, old_record, record)")
        )
    cascade_stmts.append(stmt.LineBreak())
    return cascade_stmts
