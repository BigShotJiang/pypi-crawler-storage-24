# mcparmory-customer-io

MCP server for Customer.io.

Full version coming soon. See [mcparmory.com](https://mcparmory.com)
