"""MCP server for Customer.io — placeholder, full version coming soon."""

def main() -> None:
    print("mcparmory-customer-io: full server coming soon. See https://mcparmory.com")

if __name__ == "__main__":
    main()
