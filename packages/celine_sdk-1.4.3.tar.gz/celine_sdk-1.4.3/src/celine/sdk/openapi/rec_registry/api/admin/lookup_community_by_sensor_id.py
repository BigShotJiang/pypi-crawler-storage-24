from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.lookup_by_sensor_id_response import LookupBySensorIdResponse
from ...types import Response


def _get_kwargs(
    sensor_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/admin/lookup/community-by-sensor-id/{sensor_id}".format(
            sensor_id=quote(str(sensor_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | LookupBySensorIdResponse | None:
    if response.status_code == 200:
        response_200 = LookupBySensorIdResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | LookupBySensorIdResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    sensor_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | LookupBySensorIdResponse]:
    """Lookup Community By Sensor Id

     Find which community a meter belongs to.

    Args:
        sensor_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LookupBySensorIdResponse]
    """

    kwargs = _get_kwargs(
        sensor_id=sensor_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    sensor_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | LookupBySensorIdResponse | None:
    """Lookup Community By Sensor Id

     Find which community a meter belongs to.

    Args:
        sensor_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LookupBySensorIdResponse
    """

    return sync_detailed(
        sensor_id=sensor_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    sensor_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | LookupBySensorIdResponse]:
    """Lookup Community By Sensor Id

     Find which community a meter belongs to.

    Args:
        sensor_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LookupBySensorIdResponse]
    """

    kwargs = _get_kwargs(
        sensor_id=sensor_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    sensor_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | LookupBySensorIdResponse | None:
    """Lookup Community By Sensor Id

     Find which community a meter belongs to.

    Args:
        sensor_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LookupBySensorIdResponse
    """

    return (
        await asyncio_detailed(
            sensor_id=sensor_id,
            client=client,
        )
    ).parsed
