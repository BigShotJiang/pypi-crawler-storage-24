from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UserPreferenceUpdateIn")


@_attrs_define
class UserPreferenceUpdateIn:
    """
    Attributes:
        max_per_day (int):
        channel_email (bool | None | Unset):
        email (None | str | Unset):
    """

    max_per_day: int
    channel_email: bool | None | Unset = UNSET
    email: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        max_per_day = self.max_per_day

        channel_email: bool | None | Unset
        if isinstance(self.channel_email, Unset):
            channel_email = UNSET
        else:
            channel_email = self.channel_email

        email: None | str | Unset
        if isinstance(self.email, Unset):
            email = UNSET
        else:
            email = self.email

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "max_per_day": max_per_day,
            }
        )
        if channel_email is not UNSET:
            field_dict["channel_email"] = channel_email
        if email is not UNSET:
            field_dict["email"] = email

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        max_per_day = d.pop("max_per_day")

        def _parse_channel_email(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        channel_email = _parse_channel_email(d.pop("channel_email", UNSET))

        def _parse_email(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        email = _parse_email(d.pop("email", UNSET))

        user_preference_update_in = cls(
            max_per_day=max_per_day,
            channel_email=channel_email,
            email=email,
        )

        user_preference_update_in.additional_properties = d
        return user_preference_update_in

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
