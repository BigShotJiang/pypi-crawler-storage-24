# Influxion Python SDK

Instrument your agents with the Influxion SDK to capture sessions and artifacts for evaluation.

## Installation

Install from PyPI:

```bash
pip install -U influxion
```

Or, if installing from source:

```bash
pip install -e ".[dev]"
```

## Quickstart

```python
import influxion
from influxion import InfluxionClient

influxion.init(
    api_key="sk-...",           # or set INFLUXION_API_KEY
    project_id="my-project",
    agent_id="report-agent",
)

client = InfluxionClient()

# Define your unique session ID
session_id = "weekly-report-2026-03-11"

client.create_session(
    session_id=session_id,
    name="weekly-report-run",
    tags=["weekly"],
    metadata={"env": "prod"},
)

# Do your agent work...
report = run_my_agent()

# Record tool call for evaluation (optional)
client.create_session_tool_call(
    session_id=session_id,
    name="fetch_data",
    input={"source": "api", "query": "Q4 revenue"},
    output={"rows": 42, "status": "ok"},
)

# Record artifact for evaluation (optional)
client.create_session_artifact(
    session_id=session_id,
    name="report",
    artifact=report,
    type="text",
)
```

## Async Usage

```python
import influxion
from influxion import AsyncInfluxionClient

influxion.init(
    api_key="sk-...",           # or set INFLUXION_API_KEY
    project_id="my-project",
    agent_id="my-agent",
)

client = AsyncInfluxionClient()

session_id = "my-session-123"
await client.create_session(
    session_id=session_id,
    name="My Session",
)
await client.create_session_tool_call(
    session_id=session_id,
    name="search",
    input={"query": "latest news"},
    output={"results": [...]},
)
await client.create_session_artifact(
    session_id=session_id,
    name="output",
    artifact="...",
)
```

## Configuration

| Parameter | Environment variable | Default |
|-----------|---------------------|---------|
| `api_key` | `INFLUXION_API_KEY` | — (required) |
| `base_url` | `INFLUXION_BASE_URL` | `https://api.influxion.io/v1` |
| `fail_silently` | — | `True` |

Set `api_key`, `project_id`, and `agent_id` once with `influxion.init(...)` so you don't pass them to client or method calls.

`fail_silently=True` (default): call-time errors are logged and methods return `None`
rather than raising. Set `fail_silently=False` during development to surface errors
immediately. `AuthenticationError` at construction always raises regardless.

## Running Tests

```bash
pip install -e ".[dev]"
pytest
```
