"""Shared fixtures for Influxion SDK tests."""

import pytest

from influxion import AsyncInfluxionClient, InfluxionClient


@pytest.fixture
def reset_global():
    """Clear global state before and after the test so init() tests don't leak."""
    from influxion._base import _global

    for key in _global:
        _global[key] = None
    yield
    for key in _global:
        _global[key] = None


BASE_URL = "https://api.influxion.io/v1"
TEST_API_KEY = "sk-test-key-1234"
TEST_PROJECT_ID = "00000000-0000-0000-0000-000000000001"
TEST_AGENT_ID = "test-agent"
TEST_SESSION_ID = "test-external-session"


@pytest.fixture
def client():
    """Sync client with fail_silently=False (errors raise in tests)."""
    c = InfluxionClient(api_key=TEST_API_KEY, fail_silently=False)
    yield c
    c.close()


@pytest.fixture
def silent_client():
    """Sync client with fail_silently=True."""
    c = InfluxionClient(api_key=TEST_API_KEY, fail_silently=True)
    yield c
    c.close()


@pytest.fixture
def async_client():
    """Async client with fail_silently=False."""
    return AsyncInfluxionClient(api_key=TEST_API_KEY, fail_silently=False)


@pytest.fixture
def silent_async_client():
    """Async client with fail_silently=True."""
    return AsyncInfluxionClient(api_key=TEST_API_KEY, fail_silently=True)
