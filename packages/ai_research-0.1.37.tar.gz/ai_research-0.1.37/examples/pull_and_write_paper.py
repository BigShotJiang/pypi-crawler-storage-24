#!/usr/bin/env python3
"""
End-to-end pipeline: idea -> literature -> methods -> results -> paper -> review.

The results step uses a WebSocket session with local code execution
(plots are generated on your machine, then uploaded to the server).

Usage:
    export AIR_API_KEY="air_k1_..."
    python examples/end_to_end.py

    # or point at a remote server:
    AIR_BASE_URL="http://localhost:8000" python examples/end_to_end.py

    or run the air-backend locally and point to AIR_BASE_URL="http://127.0.0.1:8000"
"""

import os
import sys
from dotenv import load_dotenv
import air

load_dotenv()

API_KEY = os.environ.get("AIR_API_KEY")
BASE_URL = os.environ.get("AIR_BASE_URL","http://localhost:8000")

if not API_KEY:
    sys.exit("Set AIR_API_KEY first:  export AIR_API_KEY='air_k1_...'")

PROJECT_NAME = "star_catalog"
print(f"Pull previously created project: {PROJECT_NAME}")
print(f"BASE_URL: {BASE_URL}")

with air.AIR(api_key=API_KEY, base_url=BASE_URL) as client:

    project = client.create_project(
        name=PROJECT_NAME,
        local_dir="air_local_dir"
    )
    print(f"Project created: {project}")

    # Pull all files produced to `local_dir`
    project.pull_files(key_only=True)

    print("\nWriting paper ...")
    tex = project.paper(journal=None, add_citations=False)

