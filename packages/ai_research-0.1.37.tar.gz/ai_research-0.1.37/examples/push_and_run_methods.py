#!/usr/bin/env python3
"""
Push a custom idea file and generate methods.

Usage:
    export AIR_API_KEY="air_k1_..."
    python examples/push_and_run_methods.py
"""

import os
from dotenv import load_dotenv
import air

load_dotenv()

API_KEY = os.environ.get("AIR_API_KEY")
BASE_URL = os.environ.get("AIR_BASE_URL", "http://localhost:8000")

# Path to the local idea file (relative to where you run the script)
IDEA_FILE = os.path.join(os.path.dirname(__file__), "example_idea.md")

with air.AIR(api_key=API_KEY, base_url=BASE_URL) as client:

    # 1. Create project
    project = client.create_project(
        name="custom-idea-methods",
        data_description="Drug discovery project.",
    )
    print(f"Created: {project}")

    # 2. Push local idea file to the backend
    uploaded = project.push_files(
        IDEA_FILE,
        remote_path="Iteration0/input_files/idea.md",
    )
    print(f"Uploaded: {uploaded}")

    # Verify
    idea_content = project.get_file("Iteration0/input_files/idea.md")
    print("\n--- Idea on backend ---")
    print(idea_content)

    # 3. Generate methods (reads idea.md from the backend)
    print("\n--- Running methods ---")
    methods = project.methods(mode="fast", timeout=600)
    print(methods)

    # 4. Pull and close client
    project.pull_files()

    client.close()
