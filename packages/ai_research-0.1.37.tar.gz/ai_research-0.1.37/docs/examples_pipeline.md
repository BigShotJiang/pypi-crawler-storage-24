# Research pipeline

Runnable scripts from the
[`examples/`](https://github.com/Denario-private/air-sdk/tree/main/examples)
directory demonstrating the full research pipeline. Set `AIR_API_KEY` and
optionally `AIR_BASE_URL` in your environment before running.

## Project management

```python
--8<-- "examples/00_manage_projects.py"
```

## Idea generation (quantum computing)

```python
--8<-- "examples/05a_idea_quantum.py"
```

## Idea generation (psychology)

```python
--8<-- "examples/05b_idea_psychology.py"
```

## Idea generation (chemical engineering)

```python
--8<-- "examples/05c_idea_chemeng.py"
```

## Idea generation (oncology)

```python
--8<-- "examples/05d_idea_oncology.py"
```

## Literature search (marine biology)

```python
--8<-- "examples/06_literature_coral.py"
```

## Methods development (quantum computing)

```python
--8<-- "examples/07a_methods_quantum.py"
```

## Methods development (zoology)

```python
--8<-- "examples/07b_methods_zoology.py"
```

## Full pipeline: idea &rarr; literature &rarr; methods &rarr; results

```python
--8<-- "examples/10_pipeline_oscillator.py"
```

## Paper writing (from existing project)

```python
--8<-- "examples/11_paper_oscillator.py"
```
