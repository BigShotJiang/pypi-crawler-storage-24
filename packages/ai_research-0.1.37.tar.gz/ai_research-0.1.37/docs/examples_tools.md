# Standalone tools

Runnable scripts from the
[`examples/`](https://github.com/Denario-private/air-sdk/tree/main/examples)
directory. Set `AIR_API_KEY` and optionally `AIR_BASE_URL` in your
environment before running.

## Keywords (UNESCO)

```python
--8<-- "examples/02a_keywords_unesco.py"
```

## Keywords (AAS)

```python
--8<-- "examples/02b_keywords_aas.py"
```

## Keywords (AAAI)

```python
--8<-- "examples/02c_keywords_aaai.py"
```

## OCR (arXiv paper)

```python
--8<-- "examples/03a_ocr_arxiv.py"
```

## Text enhancement

```python
--8<-- "examples/04_enhance.py"
```

## Text enhancement (extended)

Supports arXiv, bioRxiv, PubMed, PDF links, and loose bibliographic references:

```python
--8<-- "examples/04_enhance_extended.py"
```

## Paper review (Skepthical)

```python
--8<-- "examples/12_review.py"
```

## One-shot engineer

```python
--8<-- "examples/08a_one_shot_engineer.py"
```

## One-shot researcher

```python
--8<-- "examples/08b_one_shot_researcher.py"
```

## One-shot with VLM review

```python
--8<-- "examples/08c_one_shot_vlm.py"
```

## One-shot with self-hosted OSS model

```python
--8<-- "examples/08d_one_shot_researcher_oss.py"
```

## Deep research

```python
--8<-- "examples/09_deep_research_biostatistics.py"
```
