# Installation

## Requirements

- Python **3.10** or newer

## Install from PyPI

The standard way to work with the SDK is installing it with `pip`:

```bash
pip install ai-research
```

This pulls in the required dependencies (`httpx`, `python-dotenv`, `websockets`).

## Install from source

You can also install the SDK from source, following these commands:

```bash
git clone https://github.com/air-ai/air-sdk.git
cd air-sdk
pip install .
```

## Development extras

Install test and documentation dependencies with:

```bash
pip install ai-research[dev]   # pytest
pip install ai-research[docs]  # mkdocs + plugins
```

## Configuration

The SDK reads the following environment variables at runtime:

| Variable | Purpose | Default |
|---|---|---|
| `AIR_API_KEY` | API key (`air_k1_...`) | *none* -- required |
| `AIR_BASE_URL` | Backend URL | `http://localhost:8000` |
| `AIR_LOCAL_DIR` | Local root directory for `pull_files` and auto-pull after pipeline steps | `~/ai-scientist` |
| `AIR_WORK_DIR` | Local root directory for code execution in `results`, `one_shot`, `deep_research` | `~/ai-scientist` |

You can export them in your shell:

```bash
export AIR_API_KEY="air_k1_..."
export AIR_BASE_URL="https://api.example.com"
export AIR_LOCAL_DIR="~/my-research"
```

Or place them in a `.env` file -- the SDK uses `python-dotenv` so it will
pick them up automatically.

All values can also be passed directly when creating the client:

```python
import air

client = air.AIR(
    api_key="air_k1_...",
    base_url="https://api.example.com",
    local_dir="~/my-research",
)
```

## Verify the installation

```python
import air
print(air.__version__)
```
