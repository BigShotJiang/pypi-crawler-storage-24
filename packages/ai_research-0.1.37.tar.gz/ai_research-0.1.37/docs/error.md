# Error handling

The SDK raises typed exceptions you can catch:

```python
from air import AIRError, AuthError, TaskTimeoutError, WebSocketError

try:
    client = air.AIR(api_key="bad-key")
    client.keywords("test")
except AuthError:
    print("Invalid API key")
except TaskTimeoutError as e:
    print(f"Task {e.task_id} timed out after {e.timeout}s")
except AIRError as e:
    print(f"API error (HTTP {e.status_code}): {e}")
```

| Exception | When |
|---|---|
| `AuthError` | Invalid or missing API key (HTTP 401) |
| `TaskTimeoutError` | A pipeline step exceeds its timeout |
| `WebSocketError` | WebSocket connection failure during `one_shot` |
| `ExecutionError` | Local code execution failure |
| `AIRError` | Base class for all SDK errors |
