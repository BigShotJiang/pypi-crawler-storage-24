"""AIR SDK - Python client for the AIR Backend API."""

from .client import AIR
from .project import Project
from .exceptions import AIRError, AuthError, ExecutionError, TaskTimeoutError, WebSocketError
from .ws_session import OneShotResult
from .executor import FileInfo

from importlib.metadata import version as _v
__version__ = _v("ai-research")

__all__ = [
    "AIR",
    "Project",
    "AIRError",
    "AuthError",
    "ExecutionError",
    "TaskTimeoutError",
    "WebSocketError",
    "OneShotResult",
    "FileInfo",
]
