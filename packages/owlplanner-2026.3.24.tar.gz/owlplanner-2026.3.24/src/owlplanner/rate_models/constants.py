"""
Shared constants for rate models.

Copyright (C) 2025-2026 The Owlplanner Authors
"""

# Required column names for DataFrame rate input (order: Stocks, Bonds, Fixed, Inflation).
REQUIRED_RATE_COLUMNS = ("S&P 500", "Bonds Baa", "T-Notes", "Inflation")

# Display names for plotting (order: Stocks, Bonds Baa, T-Notes, Inflation).
RATE_DISPLAY_NAMES = ("S&P 500 (incl. div.)", "Bonds Baa", "T-Notes", "Inflation")
# Short form for subplot titles (e.g. histogram panels)
RATE_DISPLAY_NAMES_SHORT = ("S&P 500", "Bonds Baa", "T-Notes", "Inflation")

# Built-in method name sets. Must stay in sync with loader._RATE_MODEL_REGISTRY.

# Methods using canonical fixed preset rates (trailing-30, optimistic, conservative).
FIXED_PRESET_METHODS = (
    "trailing-30",
    "optimistic",
    "conservative",
)

# Methods that produce same rate every year; reverse/roll are no-ops.
CONSTANT_RATE_METHODS = (
    "trailing-30",
    "optimistic",
    "conservative",
    "user",
    "historical average",
)

# Methods that produce deterministic series; no regeneration needed.
RATE_METHODS_NO_REGEN = (
    "conservative",
    "optimistic",
    "trailing-30",
    "user",
    "historical average",
    "historical",
)

# Methods requiring frm/to year range.
HISTORICAL_RANGE_METHODS = (
    "historical",
    "historical average",
    "histogaussian",
    "histolognormal",
    "bootstrap_sor",
    "var",
    "garch_dcc",
)

# Methods using stochastic generation; need seed, support regenRates.
STOCHASTIC_METHODS = (
    "gaussian",
    "histogaussian",
    "lognormal",
    "histolognormal",
    "bootstrap_sor",
    "garch_dcc",
    "var",
)

# Methods that store user-provided values (for plan_to_config).
METHODS_WITH_VALUES = (
    "user",
    "gaussian",
    "lognormal",
)

# Methods the UI treats as "fixed" type (vs varying).
FIXED_TYPE_UI = (
    "conservative",
    "optimistic",
    "trailing-30",
    "user",
    "historical average",
)

# Methods the UI treats as "varying" type (alphabetically ordered for selector).
VARYING_TYPE_UI = (
    "bootstrap_sor",
    "garch_dcc",
    "gaussian",
    "histogaussian",
    "lognormal",
    "histolognormal",
    "historical",
    "var",
)
