# Case Morgan — ACA Marketplace (Pre-65) Example

## Overview

**Case_morgan** illustrates Owl's ACA (Affordable Care Act) marketplace modeling for retirees who are not yet eligible for Medicare. Morgan is a single 54-year-old who retired in 2026 and must obtain health insurance through the ACA marketplace for the 11 years until age 65.

## Case Parameters

| Parameter | Value |
|-----------|-------|
| Individual | Morgan |
| Date of birth | 1972-01-15 (54 at plan start) |
| Life expectancy | 92 |
| Plan start | 2026-01-01 |
| Savings | $85k taxable, $520k tax-deferred, $45k Roth, $8k HSA |
| Social Security | $2,100/mo PIA at 67 |
| **ACA SLCSP** | **$14k/year** (benchmark Silver plan) |
| ACA mode | `loop` (self-consistent; `optimize` also available) |
| Objective | Maximize net spending, $75k bequest target |

## What This Case Illustrates

1. **Pre-65 healthcare costs** — The optimizer accounts for ACA marketplace premiums in years before Medicare (2026–2036). Premium Tax Credits apply when MAGI falls between ~100% and 400% of the federal poverty level (FPL).

2. **MAGI vs. subsidy trade-off** — Higher Roth conversions or withdrawals raise MAGI, which can reduce or eliminate the Premium Tax Credit. The optimizer balances:
   - Tax-deferred withdrawals (lower MAGI, more subsidy, but more future RMDs and taxes)
   - Roth conversions (higher MAGI, less subsidy, but tax-free growth and withdrawals)

3. **SLCSP and ACA loop** — The annual benchmark Silver plan premium (SLCSP) is set to $14k. With `withACA = "loop"`, ACA costs are computed in the self-consistent loop each iteration. The optional `withACA = "optimize"` mode co-optimizes ACA bracket selection inside the LP (more accurate but slower).

## Verification

Run the case and confirm ACA parameters:

```bash
owlcli run examples/Case_morgan.toml
```

Expected: case solves; `slcsp_annual` = $14,000; `N_aca` = 11 (years 2026–2036); ACA costs appear in the solution and inflate over time.

## Assignment: Further Scenarios

Use Case Morgan as a baseline to explore these scenarios. Document your setup (TOML edits or UI settings) and compare results.

1. **SLCSP sensitivity** — Change `slcsp_annual` to 10, 18, and 22 ($k). How does optimal spending change? How does the Roth conversion strategy shift?

2. **Optimize vs. loop** — Set `withACA = "optimize"` in `[solver_options]`. Compare net spending and solve time with the `loop` default. When is the difference meaningful?

3. **Higher bequest target** — Increase the bequest target to $150k and $250k. How do ACA subsidy eligibility and Roth conversion timing change?

4. **Different income profile** — Add a small pension ($500/mo starting at 65) or increase Social Security. How does the ACA-to-Medicare transition (year Morgan turns 65) affect the strategy?

5. **No ACA** — Set `slcsp_annual = 0` to disable ACA. Compare optimal spending and Roth conversion pattern with the base case. Quantify the “cost” of pre-65 health insurance in this scenario.
