"""RFC 6891 — Extension Mechanisms for DNS (EDNS(0)).

8 compliance rules for OPT record usage and EDNS semantics.
"""

from typing import List
from rfc_lint.models import RuleMetadata, Severity, Violation, Verdict
from rfc_lint.engine import BaseRule


class SingleOPTRecord(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC6891-6.1.1-OPT-COUNT", rfc=6891, section="6.1.1",
            severity=Severity.MUST, title="At most one OPT record per message",
            description="A DNS message must contain at most one OPT record.")

    def check(self, p: dict) -> List[Violation]:
        if p["opt_count"] > 1:
            return [self.make_violation(p,
                f"Message contains {p['opt_count']} OPT records (max 1)")]
        return []


class OPTInAdditionalSection(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC6891-6.1.1-OPT-SECTION", rfc=6891, section="6.1.1",
            severity=Severity.MUST, title="OPT record must be in additional section",
            description="OPT pseudo-RR must only appear in the additional section.")

    def check(self, p: dict) -> List[Violation]:
        violations = []
        for rr in p["answers"]:
            if hasattr(rr, "type") and rr.type == 41:
                violations.append(self.make_violation(p,
                    "OPT record found in answer section (must be in additional)"))
        for rr in p["authority"]:
            if hasattr(rr, "type") and rr.type == 41:
                violations.append(self.make_violation(p,
                    "OPT record found in authority section (must be in additional)"))
        return violations


class OPTNameMustBeRoot(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC6891-6.1.1-OPT-NAME", rfc=6891, section="6.1.1",
            severity=Severity.MUST, title="OPT record NAME must be root ('.')",
            description="OPT pseudo-RR owner name must be root domain '.'.")

    def check(self, p: dict) -> List[Violation]:
        violations = []
        for opt in p["opt_records"]:
            if hasattr(opt, "rrname"):
                name = str(opt.rrname)
                # Scapy represents root as b'.' or '.'
                if name not in (".", "b'.'", "b'\\x00'", ""):
                    violations.append(self.make_violation(p,
                        f"OPT record has NAME='{name}' (must be root '.')"))
        return violations


class EDNSVersionCheck(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC6891-6.1.3-VERSION", rfc=6891, section="6.1.3",
            severity=Severity.MUST, title="EDNS version must be 0",
            description="Only EDNS version 0 is defined.")

    def check(self, p: dict) -> List[Violation]:
        if p["edns_version"] is not None and p["edns_version"] > 0:
            return [self.make_violation(p,
                f"EDNS version={p['edns_version']} (only version 0 is defined)")]
        return []


class EDNSUDPPayloadSize(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC6891-6.2.3-UDP-SIZE", rfc=6891, section="6.2.3",
            severity=Severity.SHOULD, title="EDNS UDP payload size >= 512",
            description="EDNS UDP payload size should be >= 512. Zero is invalid.")

    def check(self, p: dict) -> List[Violation]:
        if not p["has_edns"]:
            return []
        size = p["edns_udp_size"]
        if size is None:
            return []
        if size == 0:
            return [self.make_violation(p,
                "EDNS UDP payload size is 0 (invalid)", verdict=Verdict.FAIL)]
        elif size < 512:
            return [self.make_violation(p,
                f"EDNS UDP payload size={size} (should be >= 512)")]
        elif size > 4096:
            return [self.make_violation(p,
                f"EDNS UDP payload size={size} is unusually large (> 4096)",
                verdict=Verdict.WARN)]
        return []


class EDNSReservedZBits(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC6891-6.1.1-EDNS-Z", rfc=6891, section="6.1.1",
            severity=Severity.MUST, title="EDNS Z bits (reserved) must be zero",
            description="In OPT TTL, bits 1-15 (Z field, excluding DO bit) must be zero.")

    def check(self, p: dict) -> List[Violation]:
        if not p["has_edns"]:
            return []
        if p["edns_z"] is not None and p["edns_z"] != 0:
            return [self.make_violation(p,
                f"EDNS Z field = {p['edns_z']:#06x} (reserved bits must be zero)")]
        return []


class EDNSResponseRequiresQuery(BaseRule):
    """Placeholder — full check is in transaction.py."""
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC6891-7-EDNS-RESP", rfc=6891, section="7",
            severity=Severity.MUST, title="EDNS response requires EDNS query (informational)",
            description="Server must not include OPT unless query contained one. "
                        "Requires transaction pairing.")

    def check(self, p: dict) -> List[Violation]:
        return []  # Handled in TransactionAnalyzer


class FORMERRNoOPT(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC6891-7-FORMERR-OPT", rfc=6891, section="7",
            severity=Severity.MUST, title="FORMERR response must not contain OPT",
            description="FORMERR response (OPT processing) must not contain OPT record.")

    def check(self, p: dict) -> List[Violation]:
        if p["is_response"] and p["rcode"] == 1 and p["has_edns"]:
            return [self.make_violation(p,
                "FORMERR response contains an OPT record (must not)")]
        return []


def get_all_rules() -> list:
    return [
        SingleOPTRecord(), OPTInAdditionalSection(), OPTNameMustBeRoot(),
        EDNSVersionCheck(), EDNSUDPPayloadSize(), EDNSReservedZBits(),
        EDNSResponseRequiresQuery(), FORMERRNoOPT(),
    ]
