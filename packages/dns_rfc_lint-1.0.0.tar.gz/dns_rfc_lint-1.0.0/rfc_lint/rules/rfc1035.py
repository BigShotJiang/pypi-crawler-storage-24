"""RFC 1035 — Domain Names: Implementation and Specification.

17 compliance rules covering header fields, question section,
name syntax, message size, and response semantics.
"""

from typing import List
from rfc_lint.models import RuleMetadata, Severity, Violation, Verdict
from rfc_lint.engine import BaseRule
from rfc_lint.parser import VALID_OPCODES, VALID_RCODES_BASIC, VALID_CLASSES


class OpcodeRange(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.1-OPCODE", rfc=1035, section="4.1.1",
            severity=Severity.MUST, title="OPCODE in valid range",
            description="OPCODE must be a defined value (0, 1, 2, 4, 5).")

    def check(self, p: dict) -> List[Violation]:
        if p["opcode"] not in VALID_OPCODES:
            return [self.make_violation(p,
                f"OPCODE={p['opcode']} is reserved/undefined (valid: {sorted(VALID_OPCODES)})")]
        return []


class RcodeRange(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.1-RCODE", rfc=1035, section="4.1.1",
            severity=Severity.MUST, title="RCODE in valid range",
            description="Response RCODE must be a defined value. RFC 1035 defines 0-5.")

    def check(self, p: dict) -> List[Violation]:
        if not p["is_response"]:
            return []
        if p["rcode"] not in VALID_RCODES_BASIC:
            if p["rcode"] <= 15:
                return [self.make_violation(p,
                    f"RCODE={p['rcode']} not defined in RFC 1035 (0-5). May be valid under later RFCs.",
                    verdict=Verdict.WARN)]
            return [self.make_violation(p,
                f"RCODE={p['rcode']} exceeds 4-bit field range (0-15)")]
        return []


class ZBitsMustBeZero(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.1-ZBITS", rfc=1035, section="4.1.1",
            severity=Severity.MUST, title="Z bits must be zero",
            description="Z field (3 bits) is reserved and must be zero in non-EDNS messages.")

    def check(self, p: dict) -> List[Violation]:
        if not p["has_edns"] and p["z"] != 0:
            return [self.make_violation(p,
                f"Z bits = {p['z']} (must be 0 in non-EDNS messages)")]
        return []


class QRConsistency(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.1-QR", rfc=1035, section="4.1.1",
            severity=Severity.MUST, title="QR bit consistency",
            description="QR must be 0 for queries and 1 for responses.")

    def check(self, p: dict) -> List[Violation]:
        if p["qr"] not in (0, 1):
            return [self.make_violation(p, f"QR={p['qr']} (must be 0 or 1)")]
        return []


class ResponseMustHaveQuestion(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1-QDCOUNT-RESP", rfc=1035, section="4.1",
            severity=Severity.SHOULD, title="Response should echo question section",
            description="Standard query response should contain the original question (qdcount >= 1).")

    def check(self, p: dict) -> List[Violation]:
        if p["is_response"] and p["opcode"] == 0 and p["qdcount"] == 0:
            return [self.make_violation(p,
                "Response to standard query has QDCOUNT=0 (should echo question)")]
        return []


class QueryQDCount(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.2-QDCOUNT", rfc=1035, section="4.1.2",
            severity=Severity.MUST, title="Standard query must have QDCOUNT=1",
            description="A standard query (OPCODE=0) must contain exactly one question.")

    def check(self, p: dict) -> List[Violation]:
        if p["is_query"] and p["opcode"] == 0:
            if p["qdcount"] != 1:
                return [self.make_violation(p,
                    f"Standard query has QDCOUNT={p['qdcount']} (must be 1)")]
        return []


class QClassValidity(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.2-QCLASS", rfc=1035, section="4.1.2",
            severity=Severity.SHOULD, title="QCLASS should be a recognized value",
            description="QCLASS should be IN(1), CH(3), HS(4), or ANY(255).")

    def check(self, p: dict) -> List[Violation]:
        violations = []
        for q in p["questions"]:
            if q["qclass"] not in VALID_CLASSES:
                violations.append(self.make_violation(p,
                    f"QCLASS={q['qclass']} for {q['qname']} is not a recognized class"))
        return violations


class LabelLengthLimit(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-2.3.4-LABEL-LEN", rfc=1035, section="2.3.4",
            severity=Severity.MUST, title="Label length <= 63 octets",
            description="Each label in a domain name must not exceed 63 octets.")

    def check(self, p: dict) -> List[Violation]:
        violations = []
        for q in p["questions"]:
            for label in q["labels"]:
                encoded = label.encode("utf-8", errors="replace")
                if len(encoded) > 63:
                    violations.append(self.make_violation(p,
                        f"Label '{label[:20]}...' in {q['qname']} is {len(encoded)} octets (max 63)"))
        return violations


class NameLengthLimit(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-2.3.4-NAME-LEN", rfc=1035, section="2.3.4",
            severity=Severity.MUST, title="Domain name <= 253 characters",
            description="Total domain name length must not exceed 253 characters.")

    def check(self, p: dict) -> List[Violation]:
        violations = []
        for q in p["questions"]:
            name = q["qname"]
            if name and name.endswith("."):
                name = name[:-1]
            if name and len(name) > 253:
                violations.append(self.make_violation(p,
                    f"Domain name '{name[:30]}...' is {len(name)} chars (max 253)"))
        return violations


class LabelPreferredSyntax(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-2.3.1-LDH", rfc=1035, section="2.3.1",
            severity=Severity.SHOULD, title="Label preferred syntax (LDH rule)",
            description="Labels should contain only letters, digits, hyphens; "
                        "not start/end with hyphen.")

    def check(self, p: dict) -> List[Violation]:
        violations = []
        for q in p["questions"]:
            for label in q["labels"]:
                if not label:
                    continue
                # Skip underscore-prefixed service labels (_dmarc, _tcp, etc.)
                if label.startswith("_"):
                    continue
                if not all(c.isalnum() or c == "-" for c in label):
                    violations.append(self.make_violation(p,
                        f"Label '{label}' in {q['qname']} contains non-LDH characters"))
                elif label.startswith("-") or label.endswith("-"):
                    violations.append(self.make_violation(p,
                        f"Label '{label}' in {q['qname']} starts/ends with hyphen"))
        return violations


class UDPSizeLimit(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.2.1-UDP-SIZE", rfc=1035, section="4.2.1",
            severity=Severity.MUST, title="UDP message <= 512 bytes (without EDNS)",
            description="DNS over UDP must not exceed 512 bytes unless EDNS(0) is present.")

    def check(self, p: dict) -> List[Violation]:
        if p["transport"] != "udp":
            return []
        if p["has_edns"]:
            return []
        if p["dns_payload_size"] > 512:
            return [self.make_violation(p,
                f"UDP message is {p['dns_payload_size']} bytes without EDNS (max 512)")]
        return []


class TCBitSemantics(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.1-TC", rfc=1035, section="4.1.1",
            severity=Severity.MUST, title="TC bit semantics",
            description="TC bit should not be set in queries.")

    def check(self, p: dict) -> List[Violation]:
        if p["is_query"] and p["tc"] == 1:
            return [self.make_violation(p,
                "TC bit is set in a query (should only appear in responses)")]
        return []


class AABitOnlyInResponse(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.1-AA", rfc=1035, section="4.1.1",
            severity=Severity.SHOULD, title="AA bit only meaningful in responses",
            description="AA bit is only meaningful in responses; should be zero in queries.")

    def check(self, p: dict) -> List[Violation]:
        if p["is_query"] and p["aa"] == 1:
            return [self.make_violation(p,
                "AA bit is set in a query (only meaningful in responses)")]
        return []


class RABitOnlyInResponse(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.1-RA", rfc=1035, section="4.1.1",
            severity=Severity.SHOULD, title="RA bit only in responses",
            description="RA bit should only be set in responses.")

    def check(self, p: dict) -> List[Violation]:
        if p["is_query"] and p["ra"] == 1:
            return [self.make_violation(p,
                "RA bit is set in a query (should only be set in responses)")]
        return []


class CNAMEWithOtherData(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-3.6.2-CNAME-ONLY", rfc=1035, section="3.6.2",
            severity=Severity.MUST, title="CNAME must not coexist with other RR types",
            description="A name with CNAME must not have other data (except RRSIG/NSEC/NSEC3).")

    def check(self, p: dict) -> List[Violation]:
        if not p["is_response"]:
            return []
        names_types = {}
        for rr in p["answers"]:
            if not hasattr(rr, "rrname") or not hasattr(rr, "type"):
                continue
            name = str(rr.rrname).lower()
            rtype = rr.type
            if name not in names_types:
                names_types[name] = set()
            names_types[name].add(rtype)

        violations = []
        DNSSEC_TYPES = {46, 47, 50}  # RRSIG, NSEC, NSEC3
        CNAME_TYPE = 5

        for name, types in names_types.items():
            if CNAME_TYPE in types:
                other_types = types - {CNAME_TYPE} - DNSSEC_TYPES
                if other_types:
                    violations.append(self.make_violation(p,
                        f"CNAME at '{name}' coexists with types {sorted(other_types)}"))
        return violations


class CountFieldAccuracy(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1-COUNTS", rfc=1035, section="4.1",
            severity=Severity.MUST, title="Header counts match actual records",
            description="ANCOUNT/NSCOUNT/ARCOUNT must reflect actual record counts.")

    def check(self, p: dict) -> List[Violation]:
        violations = []
        actual_an = len(p["answers"])
        if p["ancount"] != actual_an and p["ancount"] > 0:
            if actual_an < p["ancount"]:
                violations.append(self.make_violation(p,
                    f"ANCOUNT={p['ancount']} but only {actual_an} answer records parsed"))
        return violations


class SuccessResponseHasAnswers(BaseRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1-NOERROR-ANS", rfc=1035, section="4.1",
            severity=Severity.SHOULD, title="NOERROR with no answers (NODATA, informational)",
            description="NOERROR with ANCOUNT=0 and NSCOUNT=0 is NODATA — valid but flagged.")

    def check(self, p: dict) -> List[Violation]:
        if (p["is_response"] and p["opcode"] == 0 and
                p["rcode"] == 0 and p["ancount"] == 0 and p["nscount"] == 0):
            return [self.make_violation(p,
                "NOERROR response with ANCOUNT=0 and NSCOUNT=0 (NODATA with no authority)",
                verdict=Verdict.WARN)]
        return []


class TTLRange(BaseRule):
    """TTL values in RRs MUST be in range 0 to 2^31-1 (RFC 1035 §3.2.1)."""
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-3.2.1-TTL-RANGE", rfc=1035, section="3.2.1",
            severity=Severity.MUST, title="TTL in valid range (0 to 2^31-1)",
            description="TTL is a 32-bit signed integer; values must be 0 to 2147483647.")

    def check(self, p: dict) -> List[Violation]:
        if not p["is_response"]:
            return []
        violations = []
        MAX_TTL = 2147483647  # 2^31 - 1
        for section_name, rrs in [("answer", p["answers"]), ("authority", p["authority"]),
                                   ("additional", p.get("non_opt_additional", []))]:
            for rr in rrs:
                if not hasattr(rr, "ttl"):
                    continue
                ttl = rr.ttl
                if ttl < 0 or ttl > MAX_TTL:
                    name = getattr(rr, "rrname", b"?")
                    violations.append(self.make_violation(p,
                        f"TTL={ttl} in {section_name} RR '{name}' exceeds valid range (0-{MAX_TTL})"))
        return violations


class DuplicateQuestion(BaseRule):
    """A query SHOULD NOT contain duplicate questions."""
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.2-DUP-QUESTION", rfc=1035, section="4.1.2",
            severity=Severity.SHOULD, title="No duplicate questions",
            description="A DNS message should not contain duplicate question entries.")

    def check(self, p: dict) -> List[Violation]:
        if len(p["questions"]) <= 1:
            return []
        seen = set()
        violations = []
        for q in p["questions"]:
            key = (q["qname"].lower().rstrip(".") if q["qname"] else "", q["qtype"], q["qclass"])
            if key in seen:
                violations.append(self.make_violation(p,
                    f"Duplicate question: {q['qname']} type={q['qtype']} class={q['qclass']}"))
            seen.add(key)
        return violations


class NXDOMAINWithAnswers(BaseRule):
    """NXDOMAIN (RCODE=3) responses SHOULD NOT contain answer records."""
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1-NXDOMAIN-ANS", rfc=1035, section="4.1",
            severity=Severity.SHOULD, title="NXDOMAIN should not have answer records",
            description="A response with RCODE=3 (NXDOMAIN) should not contain answer RRs.")

    def check(self, p: dict) -> List[Violation]:
        if p["is_response"] and p["rcode"] == 3 and p["ancount"] > 0:
            return [self.make_violation(p,
                f"NXDOMAIN response has ANCOUNT={p['ancount']} (should be 0)")]
        return []


class RefusedWithAnswers(BaseRule):
    """REFUSED (RCODE=5) responses MUST NOT contain answer records."""
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1-REFUSED-ANS", rfc=1035, section="4.1",
            severity=Severity.MUST, title="REFUSED must not have answer records",
            description="A REFUSED response must not contain answer RRs.")

    def check(self, p: dict) -> List[Violation]:
        if p["is_response"] and p["rcode"] == 5 and p["ancount"] > 0:
            return [self.make_violation(p,
                f"REFUSED response has ANCOUNT={p['ancount']} (must be 0)")]
        return []


def get_all_rules() -> list:
    return [
        OpcodeRange(), RcodeRange(), ZBitsMustBeZero(), QRConsistency(),
        ResponseMustHaveQuestion(), QueryQDCount(), QClassValidity(),
        LabelLengthLimit(), NameLengthLimit(), LabelPreferredSyntax(),
        UDPSizeLimit(), TCBitSemantics(), AABitOnlyInResponse(),
        RABitOnlyInResponse(), CNAMEWithOtherData(), CountFieldAccuracy(),
        SuccessResponseHasAnswers(), TTLRange(), DuplicateQuestion(),
        NXDOMAINWithAnswers(), RefusedWithAnswers(),
    ]
