"""DNS packet parser — extracts structured fields from Scapy DNS packets."""

from typing import Optional, List
from rfc_lint._scapy import DNS, DNSQR, DNSRR, Raw, IP, IPv6, UDP, TCP

# Valid OPCODE values per RFC 1035 + updates
VALID_OPCODES = {0, 1, 2, 4, 5}  # QUERY, IQUERY, STATUS, NOTIFY, UPDATE

# Valid RCODE values per RFC 1035 §4.1.1
VALID_RCODES_BASIC = set(range(0, 6))  # 0-5

# DNS class values
VALID_CLASSES = {1, 3, 4, 255}  # IN, CH, HS, ANY

# EDNS0 OPT type
EDNS_TYPE = 41


def parse_dns_name(name_bytes) -> Optional[str]:
    """Decode a DNS name from bytes, handling Scapy's format."""
    if name_bytes is None:
        return None
    if isinstance(name_bytes, str):
        return name_bytes
    try:
        return name_bytes.decode("utf-8", errors="replace")
    except (AttributeError, UnicodeDecodeError):
        return str(name_bytes)


def extract_labels(name: str) -> List[str]:
    """Extract individual labels from a DNS name."""
    if not name:
        return []
    if name.endswith("."):
        name = name[:-1]
    if not name:
        return []
    return name.split(".")


def _to_list(field) -> list:
    """Convert a Scapy DNS section field to a plain list.
    
    Scapy 2.7 uses PacketListField (iterable), older versions use
    chained payloads. Handle both.
    """
    if field is None:
        return []
    if hasattr(field, "__iter__"):
        return list(field)
    # Legacy chain-walking for older Scapy
    records = []
    rr = field
    for _ in range(500):  # safety limit
        if rr is None or isinstance(rr, Raw):
            break
        records.append(rr)
        if hasattr(rr, "payload") and rr.payload and not isinstance(rr.payload, Raw):
            rr = rr.payload
        else:
            break
    return records


def _get_opt_fields(opt) -> dict:
    """Extract EDNS fields from an OPT record, handling both Scapy 2.7
    (DNSRROPT with .version, .z, .rclass) and older versions (raw .ttl).
    """
    result = {"version": 0, "do_bit": False, "udp_size": 512, "z": 0}

    # Scapy 2.7+: DNSRROPT has explicit fields
    if hasattr(opt, "version"):
        result["version"] = opt.version
        result["z"] = opt.z if hasattr(opt, "z") else 0
        result["udp_size"] = opt.rclass if hasattr(opt, "rclass") else 512
        # DO bit: Scapy 2.7 stores it in the 'z' field's high bit
        # But Scapy may also have extrcode. Check raw TTL if available.
        # In DNSRROPT, z field is the lower 15 bits (DO excluded in some versions)
        # The DO bit is actually at bit 15 of the flags portion
        # Scapy 2.7 DNSRROPT: z is a FlagsField that may include DO
        # Let's check the raw bytes to be safe
        try:
            raw_opt = bytes(opt)
            if len(raw_opt) >= 7:
                # OPT wire: NAME(1) TYPE(2) CLASS(2) TTL(4) RDLEN(2)
                # TTL bytes are at offset 5-8 (0-indexed after name+type+class)
                # But in the RR itself: rrname(var) type(2) class(2) ttl(4) rdlen(2)
                # For root name: rrname=1byte, type=2, class=2, ttl bytes at [5:9]
                ttl_bytes = raw_opt[5:9]
                if len(ttl_bytes) == 4:
                    import struct
                    ttl_val = struct.unpack("!I", ttl_bytes)[0]
                    result["do_bit"] = bool(ttl_val & 0x8000)
                    result["z"] = ttl_val & 0x7FFF
        except Exception:
            pass
        return result

    # Older Scapy: raw TTL field
    if hasattr(opt, "ttl"):
        ttl = opt.ttl
        result["version"] = (ttl >> 16) & 0xFF
        result["do_bit"] = bool(ttl & 0x8000)
        result["udp_size"] = opt.rclass if hasattr(opt, "rclass") else 512
        result["z"] = ttl & 0x7FFF

    return result


def parse_packet(pkt, index: int) -> Optional[dict]:
    """
    Parse a Scapy packet into a structured dict for rule evaluation.
    Returns None if packet has no DNS layer or is too malformed to parse.
    """
    try:
        return _parse_packet_inner(pkt, index)
    except Exception:
        # Malformed packet that Scapy partially decoded but we can't fully parse
        return None


def _parse_packet_inner(pkt, index: int) -> Optional[dict]:
    if not pkt.haslayer(DNS):
        return None

    dns = pkt[DNS]

    info = {
        "index": index,
        "is_query": dns.qr == 0,
        "is_response": dns.qr == 1,
        "qr": dns.qr,
        "opcode": dns.opcode,
        "aa": dns.aa,
        "tc": dns.tc,
        "rd": dns.rd,
        "ra": dns.ra,
        "z": dns.z,
        "rcode": dns.rcode,
        "id": dns.id,
        "qdcount": dns.qdcount or 0,
        "ancount": dns.ancount or 0,
        "nscount": dns.nscount or 0,
        "arcount": dns.arcount or 0,
        "transport": "tcp" if pkt.haslayer(TCP) else "udp",
    }

    # Source / dest IPs
    if pkt.haslayer(IP):
        info["src_ip"] = pkt[IP].src
        info["dst_ip"] = pkt[IP].dst
    elif pkt.haslayer(IPv6):
        info["src_ip"] = pkt[IPv6].src
        info["dst_ip"] = pkt[IPv6].dst
    else:
        info["src_ip"] = None
        info["dst_ip"] = None

    # Questions section
    questions = []
    qd_list = _to_list(dns.qd)
    for qd in qd_list[:info["qdcount"]]:
        qname = parse_dns_name(qd.qname)
        questions.append({
            "qname": qname,
            "labels": extract_labels(qname),
            "qtype": qd.qtype,
            "qclass": qd.qclass,
        })
    info["questions"] = questions

    # Answer, Authority, Additional sections (Scapy 2.7 list-style)
    info["answers"] = _to_list(dns.an)
    info["authority"] = _to_list(dns.ns)
    additional_rrs = _to_list(dns.ar)
    info["additional"] = additional_rrs

    # EDNS/OPT analysis
    opt_records = []
    non_opt_additional = []
    for rr in additional_rrs:
        if hasattr(rr, "type") and rr.type == EDNS_TYPE:
            opt_records.append(rr)
        else:
            non_opt_additional.append(rr)

    info["opt_records"] = opt_records
    info["non_opt_additional"] = non_opt_additional
    info["has_edns"] = len(opt_records) > 0
    info["opt_count"] = len(opt_records)

    if opt_records:
        of = _get_opt_fields(opt_records[0])
        info["edns_version"] = of["version"]
        info["edns_do_bit"] = of["do_bit"]
        info["edns_udp_size"] = of["udp_size"]
        info["edns_z"] = of["z"]
    else:
        info["edns_version"] = None
        info["edns_do_bit"] = False
        info["edns_udp_size"] = None
        info["edns_z"] = None

    # Raw DNS payload size
    raw = bytes(dns)
    info["dns_payload_size"] = len(raw) if raw else 0

    # mDNS detection: destination 224.0.0.251 (IPv4) or ff02::fb (IPv6), port 5353
    # or .local. TLD in question names
    is_mdns = False
    dst_ip = info.get("dst_ip", "")
    if dst_ip in ("224.0.0.251", "ff02::fb"):
        is_mdns = True
    elif pkt.haslayer(UDP) and pkt[UDP].dport == 5353:
        is_mdns = True
    elif any(q["qname"] and q["qname"].lower().rstrip(".").endswith(".local")
             for q in questions):
        is_mdns = True
    info["is_mdns"] = is_mdns

    # Packet summary for reporting
    qnames = ", ".join(q["qname"] for q in questions if q["qname"]) if questions else "N/A"
    direction = "Q" if info["is_query"] else "R"
    info["summary"] = f"[{direction}] ID={info['id']:#06x} {qnames} RCODE={info['rcode']}"

    return info
