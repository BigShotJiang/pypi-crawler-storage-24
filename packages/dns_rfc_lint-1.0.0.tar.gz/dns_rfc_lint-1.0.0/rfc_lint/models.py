"""Core data models for rfc-lint."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List


class Severity(Enum):
    """RFC 2119 requirement levels."""
    MUST = "MUST"
    MUST_NOT = "MUST NOT"
    SHOULD = "SHOULD"
    SHOULD_NOT = "SHOULD NOT"
    MAY = "MAY"


class Verdict(Enum):
    """Result of a compliance check."""
    PASS = "PASS"
    FAIL = "FAIL"
    WARN = "WARN"
    SKIP = "SKIP"
    ERROR = "ERROR"


@dataclass
class RuleMetadata:
    """Metadata for a single RFC compliance rule."""
    rule_id: str
    rfc: int
    section: str
    severity: Severity
    title: str
    description: str


@dataclass
class Violation:
    """A single RFC compliance violation found in a packet."""
    rule: RuleMetadata
    verdict: Verdict
    packet_index: int
    detail: str
    packet_summary: str = ""


@dataclass
class LintReport:
    """Aggregated compliance report."""
    total_packets: int = 0
    dns_packets: int = 0
    violations: List[Violation] = field(default_factory=list)
    passes: int = 0
    skips: int = 0
    errors: List[str] = field(default_factory=list)

    @property
    def fail_count(self) -> int:
        return sum(1 for v in self.violations if v.verdict == Verdict.FAIL)

    @property
    def warn_count(self) -> int:
        return sum(1 for v in self.violations if v.verdict == Verdict.WARN)

    def add_violation(self, v: Violation):
        self.violations.append(v)

    def add_pass(self):
        self.passes += 1

    def add_skip(self):
        self.skips += 1

    def add_error(self, msg: str):
        self.errors.append(msg)

    def summary(self) -> dict:
        by_rule = {}
        for v in self.violations:
            rid = v.rule.rule_id
            if rid not in by_rule:
                by_rule[rid] = {
                    "rule_id": rid, "title": v.rule.title,
                    "rfc": v.rule.rfc, "section": v.rule.section,
                    "severity": v.rule.severity.value,
                    "count": 0, "verdict": v.verdict.value,
                }
            by_rule[rid]["count"] += 1
        return {
            "total_packets": self.total_packets,
            "dns_packets": self.dns_packets,
            "checks_passed": self.passes,
            "checks_skipped": self.skips,
            "violations": self.fail_count,
            "warnings": self.warn_count,
            "errors": len(self.errors),
            "by_rule": by_rule,
        }
