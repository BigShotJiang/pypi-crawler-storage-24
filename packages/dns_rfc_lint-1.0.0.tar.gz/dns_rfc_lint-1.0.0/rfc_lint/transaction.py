"""Stateful transaction analysis — query/response pairing and cross-packet rules."""

from typing import Dict, List, Tuple
from rfc_lint.models import RuleMetadata, Severity, Violation, Verdict, LintReport
from rfc_lint.engine import BaseRule


class TransactionAnalyzer:
    """Pairs DNS queries with responses by (src_ip, dst_ip, txid)."""

    def __init__(self):
        self._pending_queries: Dict[Tuple, dict] = {}
        self._transactions: List[Tuple[dict, dict]] = []
        self._orphan_queries: List[dict] = []
        self._orphan_responses: List[dict] = []

    def ingest(self, parsed: dict):
        src = parsed.get("src_ip")
        dst = parsed.get("dst_ip")
        txid = parsed.get("id")
        if src is None or dst is None:
            return

        if parsed["is_query"]:
            key = (src, dst, txid)
            self._pending_queries[key] = parsed
        elif parsed["is_response"]:
            key = (dst, src, txid)  # flip to match query direction
            if key in self._pending_queries:
                query = self._pending_queries.pop(key)
                self._transactions.append((query, parsed))
            else:
                self._orphan_responses.append(parsed)

    def finalize(self):
        self._orphan_queries.extend(self._pending_queries.values())
        self._pending_queries.clear()

    def run_transaction_rules(self, report: LintReport):
        rules = get_transaction_rules()
        for query, response in self._transactions:
            for rule in rules:
                try:
                    violations = rule.check_transaction(query, response)
                    if violations:
                        for v in violations:
                            report.add_violation(v)
                    else:
                        report.add_pass()
                except Exception as e:
                    report.add_error(f"Transaction rule {rule.metadata.rule_id} error: {e}")

    @property
    def transaction_count(self) -> int:
        return len(self._transactions)

    @property
    def orphan_query_count(self) -> int:
        return len(self._orphan_queries)

    @property
    def orphan_response_count(self) -> int:
        return len(self._orphan_responses)


class TransactionRule(BaseRule):
    def check(self, parsed: dict) -> List[Violation]:
        return []

    def check_transaction(self, query: dict, response: dict) -> List[Violation]:
        raise NotImplementedError


class TXIDMatch(TransactionRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.1-TXID-MATCH", rfc=1035, section="4.1.1",
            severity=Severity.MUST, title="Response TXID matches query TXID",
            description="Response ID field must match query ID field.")

    def check_transaction(self, query: dict, response: dict) -> List[Violation]:
        if query["id"] != response["id"]:
            return [Violation(
                rule=self.metadata, verdict=Verdict.FAIL,
                packet_index=response["index"],
                detail=f"Response TXID={response['id']:#06x} != Query TXID={query['id']:#06x}",
                packet_summary=response.get("summary", ""))]
        return []


class QuestionEcho(TransactionRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1-QUESTION-ECHO", rfc=1035, section="4.1",
            severity=Severity.SHOULD, title="Response echoes query question",
            description="Response question section should match query question.")

    def check_transaction(self, query: dict, response: dict) -> List[Violation]:
        if not query["questions"] or not response["questions"]:
            return []
        q_q = query["questions"][0]
        r_q = response["questions"][0]
        q_name = (q_q["qname"] or "").lower().rstrip(".")
        r_name = (r_q["qname"] or "").lower().rstrip(".")
        if q_name != r_name or q_q["qtype"] != r_q["qtype"]:
            return [Violation(
                rule=self.metadata, verdict=Verdict.WARN,
                packet_index=response["index"],
                detail=f"Response question ({r_name}/{r_q['qtype']}) doesn't match "
                       f"query ({q_name}/{q_q['qtype']})",
                packet_summary=response.get("summary", ""))]
        return []


class EDNSTransactionConsistency(TransactionRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC6891-7-EDNS-PAIR", rfc=6891, section="7",
            severity=Severity.MUST, title="EDNS response only if EDNS query",
            description="Server must not include OPT in response unless query contained one.")

    def check_transaction(self, query: dict, response: dict) -> List[Violation]:
        if not query["has_edns"] and response["has_edns"]:
            return [Violation(
                rule=self.metadata, verdict=Verdict.FAIL,
                packet_index=response["index"],
                detail="Response contains OPT record but query did not include one",
                packet_summary=response.get("summary", ""))]
        return []


class TCBitTruncationCheck(TransactionRule):
    @property
    def metadata(self):
        return RuleMetadata(
            rule_id="RFC1035-4.1.1-TC-TRUNCATION", rfc=1035, section="4.1.1",
            severity=Severity.SHOULD, title="Truncated response flagged",
            description="Response with TC=1 over UDP — client should retry via TCP.")

    def check_transaction(self, query: dict, response: dict) -> List[Violation]:
        if response["tc"] == 1 and response["transport"] == "udp":
            return [Violation(
                rule=self.metadata, verdict=Verdict.WARN,
                packet_index=response["index"],
                detail="Response is truncated (TC=1) over UDP — client should retry via TCP",
                packet_summary=response.get("summary", ""))]
        return []


def get_transaction_rules() -> List[TransactionRule]:
    return [TXIDMatch(), QuestionEcho(), EDNSTransactionConsistency(), TCBitTruncationCheck()]
