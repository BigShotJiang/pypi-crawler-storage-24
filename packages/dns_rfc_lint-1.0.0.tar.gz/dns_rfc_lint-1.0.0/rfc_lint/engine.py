"""Rule engine — base class and registry for RFC compliance rules."""

from abc import ABC, abstractmethod
from typing import List, Optional
from rfc_lint.models import RuleMetadata, Violation, Verdict, Severity, LintReport


class BaseRule(ABC):
    """Base class for all RFC compliance rules."""

    @property
    @abstractmethod
    def metadata(self) -> RuleMetadata:
        ...

    @abstractmethod
    def check(self, parsed: dict) -> List[Violation]:
        ...

    def make_violation(self, parsed: dict, detail: str,
                       verdict: Optional[Verdict] = None) -> Violation:
        if verdict is None:
            sev = self.metadata.severity
            if sev in (Severity.MUST, Severity.MUST_NOT):
                verdict = Verdict.FAIL
            else:
                verdict = Verdict.WARN
        return Violation(
            rule=self.metadata,
            verdict=verdict,
            packet_index=parsed["index"],
            detail=detail,
            packet_summary=parsed.get("summary", ""),
        )


class RuleRegistry:
    """Registry of all loaded rules."""

    def __init__(self):
        self._rules: List[BaseRule] = []

    def register(self, rule: BaseRule):
        self._rules.append(rule)

    def register_all(self, rules: List[BaseRule]):
        self._rules.extend(rules)

    @property
    def rules(self) -> List[BaseRule]:
        return list(self._rules)

    def rules_for_rfc(self, rfc: int) -> List[BaseRule]:
        return [r for r in self._rules if r.metadata.rfc == rfc]

    def get_rule(self, rule_id: str) -> Optional[BaseRule]:
        for r in self._rules:
            if r.metadata.rule_id == rule_id:
                return r
        return None

    def run_all(self, parsed: dict, report: LintReport):
        for rule in self._rules:
            try:
                violations = rule.check(parsed)
                if violations:
                    for v in violations:
                        report.add_violation(v)
                else:
                    report.add_pass()
            except Exception as e:
                report.add_error(
                    f"Rule {rule.metadata.rule_id} error on pkt {parsed['index']}: {e}"
                )
