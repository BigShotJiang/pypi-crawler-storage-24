"""
Scapy compatibility shim for rfc-lint.

Patches a known bug in Scapy's route6 initialization on some Linux containers
(KeyError: 'scope' in rtnetlink.py) and re-exports all symbols needed by the project.

Import from here instead of scapy directly:
    from rfc_lint._scapy import IP, UDP, TCP, DNS, DNSQR, DNSRR, ...
"""

import logging

# Suppress noisy Scapy warnings
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)

# Patch the broken construct_source_candidate_set BEFORE any layer import
# triggers route6.Route6() instantiation at module level.
import scapy.utils6 as _u6

_orig_cscs = _u6.construct_source_candidate_set


def _safe_cscs(*args, **kwargs):
    try:
        return _orig_cscs(*args, **kwargs)
    except (KeyError, OSError, TypeError):
        return []


_u6.construct_source_candidate_set = _safe_cscs

# Now safe to import everything
from scapy.config import conf  # noqa: E402

conf.verb = 0

from scapy.utils import rdpcap, wrpcap  # noqa: E402, F401
from scapy.packet import Raw  # noqa: E402, F401
from scapy.layers.inet import IP, UDP, TCP  # noqa: E402, F401
from scapy.layers.inet6 import IPv6  # noqa: E402, F401
from scapy.layers.dns import DNS, DNSQR, DNSRR  # noqa: E402, F401

__all__ = [
    "conf", "rdpcap", "wrpcap", "Raw",
    "IP", "IPv6", "UDP", "TCP",
    "DNS", "DNSQR", "DNSRR",
]
