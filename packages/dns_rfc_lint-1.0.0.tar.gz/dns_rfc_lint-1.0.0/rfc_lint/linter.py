"""Main linter — reads pcaps and runs all checks."""

import json
from pathlib import Path
from typing import Optional, List

from rfc_lint._scapy import rdpcap, DNS
from rfc_lint.models import LintReport, Verdict
from rfc_lint.parser import parse_packet
from rfc_lint.engine import RuleRegistry
from rfc_lint.transaction import TransactionAnalyzer
from rfc_lint.rules import rfc1035, rfc6891


def create_default_registry() -> RuleRegistry:
    reg = RuleRegistry()
    reg.register_all(rfc1035.get_all_rules())
    reg.register_all(rfc6891.get_all_rules())
    return reg


def lint_pcap(pcap_path: str, registry: Optional[RuleRegistry] = None,
              rfc_filter: Optional[List[int]] = None,
              exclude_mdns: bool = False) -> LintReport:
    """
    Lint a pcap file against DNS RFC compliance rules.

    Args:
        pcap_path: Path to the pcap/pcapng file.
        registry: Optional custom RuleRegistry. Uses defaults if None.
        rfc_filter: Optional list of RFC numbers to check (e.g., [1035, 6891]).
        exclude_mdns: If True, skip mDNS packets (.local / multicast / port 5353).
    """
    path = Path(pcap_path)
    if not path.exists():
        report = LintReport()
        report.add_error(f"File not found: {pcap_path}")
        return report

    if registry is None:
        registry = create_default_registry()

    if rfc_filter:
        filtered_rules = []
        for rfc_num in rfc_filter:
            filtered_rules.extend(registry.rules_for_rfc(rfc_num))
        filtered_registry = RuleRegistry()
        filtered_registry.register_all(filtered_rules)
        registry = filtered_registry

    report = LintReport()
    txn = TransactionAnalyzer()

    try:
        packets = rdpcap(str(path))
    except Exception as e:
        report.add_error(f"Failed to read pcap: {e}")
        return report

    report.total_packets = len(packets)

    for idx, pkt in enumerate(packets):
        parsed = parse_packet(pkt, idx)
        if parsed is None:
            continue
        if exclude_mdns and parsed.get("is_mdns", False):
            report.skips += 1
            continue
        report.dns_packets += 1
        registry.run_all(parsed, report)
        txn.ingest(parsed)

    txn.finalize()
    txn.run_transaction_rules(report)

    # Add transaction stats to report metadata
    report.transaction_count = txn.transaction_count
    report.orphan_queries = txn.orphan_query_count
    report.orphan_responses = txn.orphan_response_count
    report.mdns_skipped = getattr(report, '_mdns_skipped', 0)

    return report


def format_report_text(report: LintReport) -> str:
    lines = []
    lines.append("=" * 72)
    lines.append("  rfc-lint — RFC Compliance Report")
    lines.append("=" * 72)
    lines.append("")

    summary = report.summary()
    lines.append(f"  Packets scanned:   {summary['total_packets']}")
    lines.append(f"  DNS packets:       {summary['dns_packets']}")
    lines.append(f"  Checks passed:     {summary['checks_passed']}")
    lines.append(f"  Violations (FAIL): {summary['violations']}")
    lines.append(f"  Warnings (WARN):   {summary['warnings']}")
    lines.append(f"  Errors:            {summary['errors']}")
    lines.append("")

    if report.violations:
        lines.append("-" * 72)
        lines.append("  VIOLATIONS & WARNINGS")
        lines.append("-" * 72)
        lines.append("")

        for v in report.violations:
            icon = "✗" if v.verdict == Verdict.FAIL else "⚠"
            lines.append(f"  {icon} [{v.verdict.value}] Packet #{v.packet_index}")
            lines.append(f"    Rule:    {v.rule.rule_id}")
            lines.append(f"    RFC:     {v.rule.rfc} §{v.rule.section}")
            lines.append(f"    Level:   {v.rule.severity.value}")
            lines.append(f"    Title:   {v.rule.title}")
            lines.append(f"    Detail:  {v.detail}")
            if v.packet_summary:
                lines.append(f"    Packet:  {v.packet_summary}")
            lines.append("")

    if summary["by_rule"]:
        lines.append("-" * 72)
        lines.append("  SUMMARY BY RULE")
        lines.append("-" * 72)
        lines.append("")
        for rid, info in sorted(summary["by_rule"].items()):
            lines.append(f"  {info['count']:>4}x  {rid}")
            lines.append(f"         {info['title']} [{info['severity']}]")
            lines.append("")

    if report.errors:
        lines.append("-" * 72)
        lines.append("  ERRORS")
        lines.append("-" * 72)
        for err in report.errors:
            lines.append(f"  ! {err}")
        lines.append("")

    lines.append("=" * 72)
    return "\n".join(lines)


def format_report_json(report: LintReport) -> str:
    data = report.summary()
    data["violation_details"] = []
    for v in report.violations:
        data["violation_details"].append({
            "rule_id": v.rule.rule_id,
            "rfc": v.rule.rfc,
            "section": v.rule.section,
            "severity": v.rule.severity.value,
            "verdict": v.verdict.value,
            "packet_index": v.packet_index,
            "detail": v.detail,
            "packet_summary": v.packet_summary,
        })
    data["errors"] = report.errors
    return json.dumps(data, indent=2)
