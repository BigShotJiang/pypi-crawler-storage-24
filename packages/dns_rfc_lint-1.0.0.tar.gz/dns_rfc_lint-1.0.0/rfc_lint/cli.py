#!/usr/bin/env python3
"""rfc-lint CLI — RFC Compliance Checker for DNS Protocol Implementations."""

import sys
import click
from rfc_lint.linter import lint_pcap, format_report_text, format_report_json


@click.command()
@click.argument("pcap", type=click.Path(exists=True))
@click.option("--rfc", multiple=True, type=int,
              help="Filter by RFC number (e.g., --rfc 1035 --rfc 6891). Default: all.")
@click.option("--format", "fmt", type=click.Choice(["text", "json"]), default="text",
              help="Output format (default: text).")
@click.option("--output", "-o", type=click.Path(), default=None,
              help="Write report to file instead of stdout.")
@click.option("--exclude-mdns", is_flag=True, default=False,
              help="Exclude mDNS (.local / 224.0.0.251 / port 5353) packets from analysis.")
@click.option("--strict", is_flag=True, default=False,
              help="Treat SHOULD violations (WARN) as FAIL for exit code.")
def main(pcap, rfc, fmt, output, exclude_mdns, strict):
    """Lint a pcap file for DNS RFC compliance violations.

    \b
    Examples:
        rfc-lint capture.pcap
        rfc-lint capture.pcap --exclude-mdns
        rfc-lint capture.pcap --rfc 1035 --format json -o report.json
        rfc-lint capture.pcap --strict
    """
    rfc_filter = list(rfc) if rfc else None
    click.echo(f"rfc-lint v1.0.0 — scanning {pcap}...", err=True)

    report = lint_pcap(pcap, rfc_filter=rfc_filter, exclude_mdns=exclude_mdns)

    if fmt == "json":
        result = format_report_json(report)
    else:
        result = format_report_text(report)

    if output:
        with open(output, "w") as f:
            f.write(result)
        click.echo(f"Report written to {output}", err=True)
    else:
        click.echo(result)

    if strict:
        sys.exit(1 if (report.fail_count > 0 or report.warn_count > 0) else 0)
    else:
        sys.exit(1 if report.fail_count > 0 else 0)


if __name__ == "__main__":
    main()
