"""rfc-lint: RFC Compliance Checker for DNS Protocol Implementations."""

__version__ = "1.0.0"
