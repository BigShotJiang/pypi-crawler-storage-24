"""Comprehensive test suite for rfc-lint — every rule, edge case, and robustness scenario."""

import pytest
import json
import sys
import os
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rfc_lint.linter import lint_pcap, format_report_text, format_report_json
from rfc_lint.models import Verdict, LintReport, Severity, RuleMetadata, Violation
from rfc_lint.engine import RuleRegistry
from rfc_lint.transaction import TransactionAnalyzer
from tests.fixtures import *


# ═══════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════

def get_violations_by_rule(report, rule_id):
    return [v for v in report.violations if v.rule.rule_id == rule_id]

def has_fail(report, rule_id):
    return any(v.verdict == Verdict.FAIL for v in get_violations_by_rule(report, rule_id))

def has_warn(report, rule_id):
    return any(v.verdict == Verdict.WARN for v in get_violations_by_rule(report, rule_id))

def no_violations_for(report, rule_id):
    return len(get_violations_by_rule(report, rule_id)) == 0


# ═══════════════════════════════════════════════════════════════════════
# 1. CLEAN PACKETS — zero false positives
# ═══════════════════════════════════════════════════════════════════════

class TestCleanPackets:
    def test_clean_query_response_no_fails(self):
        report = lint_pcap(pcap_clean())
        assert report.dns_packets == 2
        assert report.fail_count == 0
        assert report.passes > 0

    def test_clean_edns_no_fails(self):
        report = lint_pcap(pcap_clean_edns())
        assert report.dns_packets == 2
        assert report.fail_count == 0

    def test_non_dns_packets_skipped(self):
        report = lint_pcap(pcap_non_dns())
        assert report.total_packets == 2
        assert report.dns_packets == 0
        assert report.fail_count == 0

    def test_ipv6_clean(self):
        assert lint_pcap(pcap_ipv6()).fail_count == 0

    def test_tcp_dns_clean(self):
        assert lint_pcap(pcap_tcp_dns()).fail_count == 0

    def test_underscore_service_no_ldh_violation(self):
        assert no_violations_for(lint_pcap(pcap_underscore_service()), "RFC1035-2.3.1-LDH")

    def test_notify_opcode_valid(self):
        assert no_violations_for(lint_pcap(pcap_notify_opcode()), "RFC1035-4.1.1-OPCODE")

    def test_update_opcode_valid(self):
        assert no_violations_for(lint_pcap(pcap_update_opcode()), "RFC1035-4.1.1-OPCODE")

    def test_nxdomain_no_rcode_violation(self):
        assert no_violations_for(lint_pcap(pcap_nxdomain_response()), "RFC1035-4.1.1-RCODE")

    def test_servfail_no_rcode_violation(self):
        assert no_violations_for(lint_pcap(pcap_servfail_response()), "RFC1035-4.1.1-RCODE")

    def test_edns_do_bit_no_zbits_violation(self):
        assert no_violations_for(lint_pcap(pcap_edns_do_bit()), "RFC1035-4.1.1-ZBITS")

    def test_edns_do_bit_no_edns_z_violation(self):
        assert no_violations_for(lint_pcap(pcap_edns_do_bit()), "RFC6891-6.1.1-EDNS-Z")

    def test_mixed_dns_non_dns(self):
        """Only DNS packets should be analyzed, non-DNS ignored."""
        report = lint_pcap(pcap_mixed_dns_and_non_dns())
        assert report.total_packets == 5
        assert report.dns_packets == 2
        assert report.fail_count == 0


# ═══════════════════════════════════════════════════════════════════════
# 2. RFC 1035 VIOLATIONS — positive + negative for each rule
# ═══════════════════════════════════════════════════════════════════════

class TestRFC1035Opcode:
    def test_detected(self):
        assert has_fail(lint_pcap(pcap_bad_opcode()), "RFC1035-4.1.1-OPCODE")
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-4.1.1-OPCODE")

class TestRFC1035Rcode:
    def test_detected(self):
        assert len(get_violations_by_rule(lint_pcap(pcap_bad_rcode()), "RFC1035-4.1.1-RCODE")) > 0
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-4.1.1-RCODE")

class TestRFC1035ZBits:
    def test_detected(self):
        assert has_fail(lint_pcap(pcap_z_bits_nonzero()), "RFC1035-4.1.1-ZBITS")
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-4.1.1-ZBITS")
    def test_edns_exempt(self):
        assert no_violations_for(lint_pcap(pcap_clean_edns()), "RFC1035-4.1.1-ZBITS")

class TestRFC1035QDCount:
    def test_detected(self):
        assert has_fail(lint_pcap(pcap_qdcount_zero_query()), "RFC1035-4.1.2-QDCOUNT")
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-4.1.2-QDCOUNT")

class TestRFC1035QClass:
    def test_detected(self):
        assert len(get_violations_by_rule(lint_pcap(pcap_bad_qclass()), "RFC1035-4.1.2-QCLASS")) > 0
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-4.1.2-QCLASS")

class TestRFC1035LabelLength:
    def test_boundary_passes(self):
        assert no_violations_for(lint_pcap(pcap_label_too_long()), "RFC1035-2.3.4-LABEL-LEN")
    def test_over_limit_unit(self):
        from rfc_lint.rules.rfc1035 import LabelLengthLimit
        rule = LabelLengthLimit()
        parsed = {"index": 0, "summary": "test",
                  "questions": [{"qname": "a"*64+".com.", "labels": ["a"*64, "com"], "qtype": 1, "qclass": 1}]}
        assert len(rule.check(parsed)) > 0
    def test_normal(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-2.3.4-LABEL-LEN")

class TestRFC1035NameLength:
    def test_detected(self):
        assert has_fail(lint_pcap(pcap_name_too_long()), "RFC1035-2.3.4-NAME-LEN")
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-2.3.4-NAME-LEN")

class TestRFC1035LDH:
    def test_non_ldh(self):
        assert len(get_violations_by_rule(lint_pcap(pcap_non_ldh_label()), "RFC1035-2.3.1-LDH")) > 0
    def test_hyphen(self):
        assert len(get_violations_by_rule(lint_pcap(pcap_hyphen_label()), "RFC1035-2.3.1-LDH")) > 0
    def test_underscore_exempt(self):
        assert no_violations_for(lint_pcap(pcap_underscore_service()), "RFC1035-2.3.1-LDH")

class TestRFC1035TCBit:
    def test_detected(self):
        assert has_fail(lint_pcap(pcap_tc_in_query()), "RFC1035-4.1.1-TC")
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-4.1.1-TC")

class TestRFC1035AABit:
    def test_detected(self):
        assert len(get_violations_by_rule(lint_pcap(pcap_aa_in_query()), "RFC1035-4.1.1-AA")) > 0
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-4.1.1-AA")

class TestRFC1035RABit:
    def test_detected(self):
        assert len(get_violations_by_rule(lint_pcap(pcap_ra_in_query()), "RFC1035-4.1.1-RA")) > 0
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-4.1.1-RA")

class TestRFC1035CNAME:
    def test_detected(self):
        assert has_fail(lint_pcap(pcap_cname_with_other()), "RFC1035-3.6.2-CNAME-ONLY")
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-3.6.2-CNAME-ONLY")

class TestRFC1035ResponseQuestion:
    def test_detected(self):
        assert len(get_violations_by_rule(lint_pcap(pcap_response_no_question()), "RFC1035-4.1-QDCOUNT-RESP")) > 0
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-4.1-QDCOUNT-RESP")

class TestRFC1035NODATA:
    def test_flagged(self):
        assert has_warn(lint_pcap(pcap_nodata_response()), "RFC1035-4.1-NOERROR-ANS")

class TestRFC1035NXDOMAINAnswers:
    def test_detected(self):
        assert has_warn(lint_pcap(pcap_nxdomain_with_answers()), "RFC1035-4.1-NXDOMAIN-ANS")
    def test_clean_nxdomain(self):
        assert no_violations_for(lint_pcap(pcap_nxdomain_response()), "RFC1035-4.1-NXDOMAIN-ANS")

class TestRFC1035RefusedAnswers:
    def test_detected(self):
        assert has_fail(lint_pcap(pcap_refused_with_answers()), "RFC1035-4.1-REFUSED-ANS")

class TestRFC1035DuplicateQuestion:
    def test_detected(self):
        assert has_warn(lint_pcap(pcap_duplicate_question()), "RFC1035-4.1.2-DUP-QUESTION")
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-4.1.2-DUP-QUESTION")

class TestRFC1035TTLRange:
    def test_clean_ttl(self):
        """Normal TTL=300 should pass."""
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-3.2.1-TTL-RANGE")
    def test_ttl_zero_valid(self):
        """TTL=0 is valid (no caching)."""
        from rfc_lint.rules.rfc1035 import TTLRange
        rule = TTLRange()
        # Simulate: response with a TTL=0 RR
        from unittest.mock import MagicMock
        rr = MagicMock()
        rr.ttl = 0
        rr.rrname = b"example.com."
        parsed = {"index": 0, "summary": "test", "is_response": True,
                  "answers": [rr], "authority": [], "non_opt_additional": []}
        assert len(rule.check(parsed)) == 0
    def test_ttl_max_valid(self):
        from rfc_lint.rules.rfc1035 import TTLRange
        from unittest.mock import MagicMock
        rule = TTLRange()
        rr = MagicMock()
        rr.ttl = 2147483647
        rr.rrname = b"example.com."
        parsed = {"index": 0, "summary": "test", "is_response": True,
                  "answers": [rr], "authority": [], "non_opt_additional": []}
        assert len(rule.check(parsed)) == 0
    def test_ttl_over_max(self):
        from rfc_lint.rules.rfc1035 import TTLRange
        from unittest.mock import MagicMock
        rule = TTLRange()
        rr = MagicMock()
        rr.ttl = 2147483648  # 2^31, one over
        rr.rrname = b"example.com."
        parsed = {"index": 0, "summary": "test", "is_response": True,
                  "answers": [rr], "authority": [], "non_opt_additional": []}
        violations = rule.check(parsed)
        assert len(violations) == 1
        assert violations[0].verdict == Verdict.FAIL


# ═══════════════════════════════════════════════════════════════════════
# 3. RFC 6891 VIOLATIONS
# ═══════════════════════════════════════════════════════════════════════

class TestRFC6891OPTCount:
    def test_detected(self):
        assert has_fail(lint_pcap(pcap_multiple_opt()), "RFC6891-6.1.1-OPT-COUNT")
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean_edns()), "RFC6891-6.1.1-OPT-COUNT")

class TestRFC6891EDNSVersion:
    def test_detected(self):
        assert has_fail(lint_pcap(pcap_edns_version_1()), "RFC6891-6.1.3-VERSION")
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean_edns()), "RFC6891-6.1.3-VERSION")

class TestRFC6891UDPSize:
    def test_zero(self):
        assert has_fail(lint_pcap(pcap_edns_udp_zero()), "RFC6891-6.2.3-UDP-SIZE")
    def test_small(self):
        assert len(get_violations_by_rule(lint_pcap(pcap_edns_udp_small()), "RFC6891-6.2.3-UDP-SIZE")) > 0
    def test_huge(self):
        assert has_warn(lint_pcap(pcap_edns_udp_huge()), "RFC6891-6.2.3-UDP-SIZE")
    def test_normal(self):
        assert no_violations_for(lint_pcap(pcap_clean_edns()), "RFC6891-6.2.3-UDP-SIZE")

class TestRFC6891FORMERRWithOPT:
    def test_detected(self):
        assert has_fail(lint_pcap(pcap_formerr_with_opt()), "RFC6891-7-FORMERR-OPT")
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean_edns()), "RFC6891-7-FORMERR-OPT")


# ═══════════════════════════════════════════════════════════════════════
# 4. TRANSACTION-LEVEL TESTS
# ═══════════════════════════════════════════════════════════════════════

class TestTransactionQuestionEcho:
    def test_detected(self):
        assert len(get_violations_by_rule(lint_pcap(pcap_mismatched_question()), "RFC1035-4.1-QUESTION-ECHO")) > 0
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean()), "RFC1035-4.1-QUESTION-ECHO")

class TestTransactionEDNS:
    def test_detected(self):
        assert has_fail(lint_pcap(pcap_edns_response_no_query()), "RFC6891-7-EDNS-PAIR")
    def test_clean(self):
        assert no_violations_for(lint_pcap(pcap_clean_edns()), "RFC6891-7-EDNS-PAIR")

class TestTransactionTruncation:
    def test_detected(self):
        assert has_warn(lint_pcap(pcap_truncated_response()), "RFC1035-4.1.1-TC-TRUNCATION")

class TestTransactionAnalyzerUnit:
    """Direct unit tests for TransactionAnalyzer."""
    def test_pairing(self):
        txn = TransactionAnalyzer()
        query = {"is_query": True, "is_response": False, "src_ip": "10.0.0.1",
                 "dst_ip": "10.0.0.2", "id": 0x1234, "index": 0}
        response = {"is_query": False, "is_response": True, "src_ip": "10.0.0.2",
                    "dst_ip": "10.0.0.1", "id": 0x1234, "index": 1}
        txn.ingest(query)
        txn.ingest(response)
        txn.finalize()
        assert txn.transaction_count == 1
        assert txn.orphan_query_count == 0
        assert txn.orphan_response_count == 0

    def test_orphan_query(self):
        txn = TransactionAnalyzer()
        query = {"is_query": True, "is_response": False, "src_ip": "10.0.0.1",
                 "dst_ip": "10.0.0.2", "id": 0x5555, "index": 0}
        txn.ingest(query)
        txn.finalize()
        assert txn.transaction_count == 0
        assert txn.orphan_query_count == 1

    def test_orphan_response(self):
        txn = TransactionAnalyzer()
        response = {"is_query": False, "is_response": True, "src_ip": "10.0.0.2",
                    "dst_ip": "10.0.0.1", "id": 0x6666, "index": 0}
        txn.ingest(response)
        txn.finalize()
        assert txn.orphan_response_count == 1

    def test_no_ip_skipped(self):
        txn = TransactionAnalyzer()
        parsed = {"is_query": True, "is_response": False, "src_ip": None,
                  "dst_ip": None, "id": 0x7777, "index": 0}
        txn.ingest(parsed)
        txn.finalize()
        assert txn.transaction_count == 0
        assert txn.orphan_query_count == 0


# ═══════════════════════════════════════════════════════════════════════
# 5. mDNS HANDLING
# ═══════════════════════════════════════════════════════════════════════

class TestMDNS:
    def test_mdns_detected_by_parser(self):
        from rfc_lint._scapy import rdpcap
        from rfc_lint.parser import parse_packet
        packets = rdpcap(pcap_mdns_query())
        parsed = parse_packet(packets[0], 0)
        assert parsed["is_mdns"] is True

    def test_mdns_ipv6_detected(self):
        from rfc_lint._scapy import rdpcap
        from rfc_lint.parser import parse_packet
        packets = rdpcap(pcap_mdns_ipv6())
        parsed = parse_packet(packets[0], 0)
        assert parsed["is_mdns"] is True

    def test_unicast_dns_not_mdns(self):
        from rfc_lint._scapy import rdpcap
        from rfc_lint.parser import parse_packet
        packets = rdpcap(pcap_clean())
        parsed = parse_packet(packets[0], 0)
        assert parsed["is_mdns"] is False

    def test_exclude_mdns_flag(self):
        """With --exclude-mdns, mDNS packets should be skipped."""
        report = lint_pcap(pcap_mdns_query(), exclude_mdns=True)
        assert report.dns_packets == 0
        assert report.fail_count == 0

    def test_mdns_included_by_default(self):
        """Without --exclude-mdns, mDNS is analyzed (and may trigger violations)."""
        report = lint_pcap(pcap_mdns_query(), exclude_mdns=False)
        assert report.dns_packets == 1


# ═══════════════════════════════════════════════════════════════════════
# 6. MULTI-VIOLATION AND RFC FILTER
# ═══════════════════════════════════════════════════════════════════════

class TestMultiViolation:
    def test_multiple_violations_single_packet(self):
        report = lint_pcap(pcap_multiple_violations())
        assert has_fail(report, "RFC1035-4.1.1-OPCODE")
        assert has_fail(report, "RFC1035-4.1.1-ZBITS")
        assert len(get_violations_by_rule(report, "RFC1035-4.1.2-QCLASS")) > 0

class TestRFCFilter:
    def test_filter_rfc_1035_only(self):
        report = lint_pcap(pcap_formerr_with_opt(), rfc_filter=[1035])
        assert no_violations_for(report, "RFC6891-7-FORMERR-OPT")
    def test_filter_rfc_6891_only(self):
        report = lint_pcap(pcap_bad_opcode(), rfc_filter=[6891])
        assert no_violations_for(report, "RFC1035-4.1.1-OPCODE")
    def test_filter_both(self):
        report = lint_pcap(pcap_multiple_violations(), rfc_filter=[1035, 6891])
        assert has_fail(report, "RFC1035-4.1.1-OPCODE")
    def test_filter_nonexistent_rfc(self):
        report = lint_pcap(pcap_clean(), rfc_filter=[9999])
        assert report.fail_count == 0  # No per-packet rules to run


# ═══════════════════════════════════════════════════════════════════════
# 7. REPORT FORMATTING
# ═══════════════════════════════════════════════════════════════════════

class TestReporting:
    def test_text_contains_rule_id(self):
        text = format_report_text(lint_pcap(pcap_bad_opcode()))
        assert "RFC1035-4.1.1-OPCODE" in text
        assert "FAIL" in text
        assert "rfc-lint" in text

    def test_json_valid(self):
        data = json.loads(format_report_json(lint_pcap(pcap_bad_opcode())))
        assert "total_packets" in data
        assert "violation_details" in data
        assert len(data["violation_details"]) > 0

    def test_json_clean(self):
        data = json.loads(format_report_json(lint_pcap(pcap_clean())))
        assert data["violations"] == 0

    def test_summary_by_rule(self):
        assert len(lint_pcap(pcap_multiple_violations()).summary()["by_rule"]) >= 2

    def test_text_summary_section(self):
        assert "SUMMARY BY RULE" in format_report_text(lint_pcap(pcap_multiple_violations()))

    def test_json_fields_complete(self):
        detail = json.loads(format_report_json(lint_pcap(pcap_bad_opcode())))["violation_details"][0]
        for key in ("rule_id", "rfc", "section", "severity", "verdict", "packet_index", "detail", "packet_summary"):
            assert key in detail

    def test_text_clean_no_violations_section(self):
        """Clean report should not have VIOLATIONS section."""
        text = format_report_text(lint_pcap(pcap_clean()))
        assert "VIOLATIONS & WARNINGS" not in text

    def test_json_errors_field(self):
        data = json.loads(format_report_json(lint_pcap("/nonexistent/path.pcap")))
        assert len(data["errors"]) > 0


# ═══════════════════════════════════════════════════════════════════════
# 8. ERROR HANDLING & ROBUSTNESS
# ═══════════════════════════════════════════════════════════════════════

class TestErrorHandling:
    def test_nonexistent_file(self):
        report = lint_pcap("/nonexistent/path.pcap")
        assert len(report.errors) > 0

    def test_corrupt_pcap(self):
        """Corrupt file should return report with error, not crash."""
        report = lint_pcap(pcap_corrupt())
        assert len(report.errors) > 0 or report.dns_packets == 0

    def test_empty_pcap(self):
        """Empty pcap should produce empty report."""
        report = lint_pcap(pcap_empty())
        assert report.total_packets == 0
        assert report.dns_packets == 0
        assert report.fail_count == 0

    def test_malformed_dns_no_crash(self):
        """Malformed DNS payload should be handled gracefully."""
        report = lint_pcap(pcap_malformed_dns())
        # Should not raise — either parsed or skipped
        assert report.total_packets == 1

    def test_empty_report_summary(self):
        summary = lint_pcap(pcap_non_dns()).summary()
        assert summary["dns_packets"] == 0
        assert summary["violations"] == 0


# ═══════════════════════════════════════════════════════════════════════
# 9. LARGE PCAP STRESS TEST
# ═══════════════════════════════════════════════════════════════════════

class TestStress:
    def test_large_pcap_no_crash(self):
        """500 query/response pairs (1000 packets) should complete without error."""
        report = lint_pcap(pcap_large(500))
        assert report.total_packets == 1000
        assert report.dns_packets == 1000
        assert report.fail_count == 0
        assert len(report.errors) == 0

    def test_large_pcap_all_rules_ran(self):
        """Every rule should have run on every packet."""
        report = lint_pcap(pcap_large(10))
        # 20 packets × 21 per-packet rules = 420 minimum passes (some rules skip)
        assert report.passes > 200


# ═══════════════════════════════════════════════════════════════════════
# 10. MODEL UNIT TESTS
# ═══════════════════════════════════════════════════════════════════════

class TestModels:
    def test_lint_report_defaults(self):
        r = LintReport()
        assert r.total_packets == 0
        assert r.fail_count == 0
        assert r.warn_count == 0
        assert r.passes == 0

    def test_lint_report_add_violation(self):
        r = LintReport()
        meta = RuleMetadata("TEST-1", 1035, "1.1", Severity.MUST, "test", "test")
        v = Violation(meta, Verdict.FAIL, 0, "test detail")
        r.add_violation(v)
        assert r.fail_count == 1
        assert r.warn_count == 0

    def test_lint_report_add_warn(self):
        r = LintReport()
        meta = RuleMetadata("TEST-2", 1035, "1.1", Severity.SHOULD, "test", "test")
        v = Violation(meta, Verdict.WARN, 0, "test detail")
        r.add_violation(v)
        assert r.fail_count == 0
        assert r.warn_count == 1

    def test_lint_report_summary_structure(self):
        r = LintReport(total_packets=10, dns_packets=5)
        r.add_pass()
        r.add_pass()
        s = r.summary()
        assert s["total_packets"] == 10
        assert s["dns_packets"] == 5
        assert s["checks_passed"] == 2

    def test_severity_enum_values(self):
        assert Severity.MUST.value == "MUST"
        assert Severity.SHOULD.value == "SHOULD"
        assert Severity.MAY.value == "MAY"

    def test_verdict_enum_values(self):
        assert Verdict.PASS.value == "PASS"
        assert Verdict.FAIL.value == "FAIL"
        assert Verdict.WARN.value == "WARN"


# ═══════════════════════════════════════════════════════════════════════
# 11. RULE REGISTRY TESTS
# ═══════════════════════════════════════════════════════════════════════

class TestRuleRegistry:
    def test_register_and_get(self):
        from rfc_lint.rules.rfc1035 import OpcodeRange
        reg = RuleRegistry()
        rule = OpcodeRange()
        reg.register(rule)
        assert reg.get_rule("RFC1035-4.1.1-OPCODE") is rule
        assert reg.get_rule("NONEXISTENT") is None

    def test_rules_for_rfc(self):
        from rfc_lint.linter import create_default_registry
        reg = create_default_registry()
        r1035 = reg.rules_for_rfc(1035)
        r6891 = reg.rules_for_rfc(6891)
        assert len(r1035) >= 17
        assert len(r6891) >= 8
        assert len(reg.rules_for_rfc(9999)) == 0

    def test_total_rule_count(self):
        from rfc_lint.linter import create_default_registry
        reg = create_default_registry()
        assert len(reg.rules) >= 29  # 21 RFC1035 + 8 RFC6891


# ═══════════════════════════════════════════════════════════════════════
# 12. PARSER EDGE CASES
# ═══════════════════════════════════════════════════════════════════════

class TestParser:
    def test_ipv6_src_dst(self):
        from rfc_lint._scapy import rdpcap
        from rfc_lint.parser import parse_packet
        parsed = parse_packet(rdpcap(pcap_ipv6())[0], 0)
        assert parsed["src_ip"] == "2001:db8::1"
        assert parsed["dst_ip"] == "2001:db8::2"

    def test_tcp_transport(self):
        from rfc_lint._scapy import rdpcap
        from rfc_lint.parser import parse_packet
        assert parse_packet(rdpcap(pcap_tcp_dns())[0], 0)["transport"] == "tcp"

    def test_udp_transport(self):
        from rfc_lint._scapy import rdpcap
        from rfc_lint.parser import parse_packet
        assert parse_packet(rdpcap(pcap_clean())[0], 0)["transport"] == "udp"

    def test_edns_version_extraction(self):
        from rfc_lint._scapy import rdpcap
        from rfc_lint.parser import parse_packet
        assert parse_packet(rdpcap(pcap_edns_version_1())[0], 0)["edns_version"] == 1

    def test_edns_udp_size_extraction(self):
        from rfc_lint._scapy import rdpcap
        from rfc_lint.parser import parse_packet
        assert parse_packet(rdpcap(pcap_clean_edns())[0], 0)["edns_udp_size"] == 4096

    def test_summary_format(self):
        from rfc_lint._scapy import rdpcap
        from rfc_lint.parser import parse_packet
        parsed = parse_packet(rdpcap(pcap_clean())[0], 0)
        assert "[Q]" in parsed["summary"]
        assert "example.com" in parsed["summary"]

    def test_non_dns_returns_none(self):
        from rfc_lint._scapy import rdpcap
        from rfc_lint.parser import parse_packet
        packets = rdpcap(pcap_non_dns())
        assert parse_packet(packets[0], 0) is None

    def test_parse_dns_name_none(self):
        from rfc_lint.parser import parse_dns_name
        assert parse_dns_name(None) is None

    def test_parse_dns_name_string(self):
        from rfc_lint.parser import parse_dns_name
        assert parse_dns_name("example.com.") == "example.com."

    def test_parse_dns_name_bytes(self):
        from rfc_lint.parser import parse_dns_name
        assert parse_dns_name(b"example.com.") == "example.com."

    def test_extract_labels_empty(self):
        from rfc_lint.parser import extract_labels
        assert extract_labels("") == []
        assert extract_labels(".") == []
        assert extract_labels(None) == []


# ═══════════════════════════════════════════════════════════════════════
# 13. CLI INTEGRATION (via Click test runner)
# ═══════════════════════════════════════════════════════════════════════

class TestCLI:
    def test_cli_text_output(self):
        from click.testing import CliRunner
        from rfc_lint.cli import main
        runner = CliRunner()
        result = runner.invoke(main, [pcap_clean()])
        assert result.exit_code == 0
        assert "rfc-lint" in result.output

    def test_cli_json_output(self):
        from click.testing import CliRunner
        from rfc_lint.cli import main
        runner = CliRunner()
        result = runner.invoke(main, [pcap_clean(), "--format", "json"])
        assert result.exit_code == 0
        # Strip the stderr status line that CliRunner mixes in
        lines = result.output.strip().split("\n")
        json_text = "\n".join(l for l in lines if not l.startswith("rfc-lint"))
        data = json.loads(json_text)
        assert data["violations"] == 0

    def test_cli_exit_code_1_on_fail(self):
        from click.testing import CliRunner
        from rfc_lint.cli import main
        runner = CliRunner()
        result = runner.invoke(main, [pcap_bad_opcode()])
        assert result.exit_code == 1

    def test_cli_exit_code_0_on_clean(self):
        from click.testing import CliRunner
        from rfc_lint.cli import main
        runner = CliRunner()
        result = runner.invoke(main, [pcap_clean()])
        assert result.exit_code == 0

    def test_cli_strict_warns_as_fail(self):
        from click.testing import CliRunner
        from rfc_lint.cli import main
        runner = CliRunner()
        result = runner.invoke(main, [pcap_nodata_response(), "--strict"])
        assert result.exit_code == 1  # WARN treated as FAIL

    def test_cli_output_file(self):
        from click.testing import CliRunner
        from rfc_lint.cli import main
        runner = CliRunner()
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as f:
            outpath = f.name
        try:
            result = runner.invoke(main, [pcap_clean(), "-o", outpath])
            assert result.exit_code == 0
            with open(outpath) as f:
                content = f.read()
            assert "rfc-lint" in content
        finally:
            os.unlink(outpath)

    def test_cli_exclude_mdns(self):
        from click.testing import CliRunner
        from rfc_lint.cli import main
        runner = CliRunner()
        result = runner.invoke(main, [pcap_mdns_query(), "--exclude-mdns", "--format", "json"])
        assert result.exit_code == 0
        lines = result.output.strip().split("\n")
        json_text = "\n".join(l for l in lines if not l.startswith("rfc-lint"))
        data = json.loads(json_text)
        assert data["dns_packets"] == 0

    def test_cli_rfc_filter(self):
        from click.testing import CliRunner
        from rfc_lint.cli import main
        runner = CliRunner()
        result = runner.invoke(main, [pcap_bad_opcode(), "--rfc", "6891", "--format", "json"])
        assert result.exit_code == 0  # 6891 filter excludes the 1035 violation
