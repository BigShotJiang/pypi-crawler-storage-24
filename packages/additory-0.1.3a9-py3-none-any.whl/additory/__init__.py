"""
Additory - Data augmentation and transformation library

Public API:
- to() - Data operations (lookup, merge, sort, summarize)
- transform() - Transform data within DataFrame
- synthetic() - Synthetic data generation

Example:
    >>> import additory as add
    >>> import polars as pl
    >>> 
    >>> df = pl.DataFrame({'weight': [70, 80], 'height': [1.75, 1.80]})
    >>> 
    >>> # Use builtin expression
    >>> result = add.transform('@calc', df, expression='inbuilt:bmi', as='bmi')
    >>> 
    >>> # Use @knn imputation
    >>> result = add.transform('@knn', df, fetch=['age'], strategy={'k': 5})
    >>> 
    >>> # Generate synthetic data
    >>> result = add.synthetic('@new', n=100, strategy={'id': 'increment', 'value': 'normal'})
"""

import sys
import os
from typing import Union, List, Dict, Any, Optional

# Add parent directory to path to import from python-specific
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Try to import Rust bindings
try:
    import _additory
    RUST_AVAILABLE = True
except ImportError:
    try:
        from . import _additory
        RUST_AVAILABLE = True
    except ImportError:
        RUST_AVAILABLE = False
        _additory = None
    _additory = None

from expressions import loader
from games import games as games_module

# Import core parsing modules
from additory.core.param_handler import (
    normalize_column_input,
    normalize_key_input,
    normalize_by_input,
    normalize_expression_input,
    normalize_as_input,
    validate_expression_as_match,
)
from additory.core.mode_parser import parse_strategy_value

# Import scanner module
from additory.scanner import scan

# Version
__version__ = "0.1.3a9"

def to(
    bring_to: Optional[Union['pd.DataFrame', 'pl.DataFrame']] = None,
    bring_from: Optional[Union['pd.DataFrame', 'pl.DataFrame']] = None,
    bring: Optional[Union[str, List[str]]] = None,
    against: Optional[Union[str, List[str]]] = None,
    position: Optional[Union[str, int]] = None,
    *,
    strategy: Optional[Dict[str, Any]] = None,
    join_type: str = 'lookup',
    logging: Union[bool, str] = 'default',
    as_type: Optional[str] = None,
    lineage: bool = False
) -> Union['pd.DataFrame', 'pl.DataFrame']:
    """
    Bring columns from one DataFrame to another based on matching keys.
    
    This function performs a join operation to add columns from a reference DataFrame
    to a target DataFrame. It supports multiple join types, aggregation strategies,
    and flexible column positioning.
    
    Args:
        bring_to (DataFrame): Target DataFrame to bring columns to (pandas or polars)
        bring_from (DataFrame): Reference DataFrame to bring columns from (pandas or polars)
        bring (str or list): Column(s) to bring from reference DataFrame
                            - Single column: 'age' or ['age']
                            - Multiple columns: ['age', 'salary'] (list required, not tuple)
        against (str or list): Key column(s) for matching rows
                              - Single key: 'id' or ['id']
                              - Multiple keys: ['customer_id', 'date'] (list required, not tuple)
        position (str or int, optional): Where to place the brought columns
                                        - String: 'start', 'end', 'after:col', 'before:col'
                                        - Integer: 0, 1, -1, -2 (Python indexing)
                                        - Default: 'end'
        strategy (dict, optional): Advanced column-level control
                                  Simple form: {'col': 'mode'}
                                  Complex form: {'col': {'mode': 'sum', 'rename': 'new_name', 'position': 'after:id'}}
                                  Available aggregation modes:
                                  - first, last: Take first/last value
                                  - sum, count, average, min, max: Numeric aggregations
                                  - concat, concat[sep]: Concatenate values (with separator)
                                  - most_common, least_common: Most/least frequent value
                                  - median, std, variance: Statistical measures
                                  - unique_count: Count unique values
        join_type (str, optional): Type of join operation
                                  - 'lookup': Default join (left join)
                                  - 'left': Left join
                                  - 'inner': Inner join
                                  - 'outer': Outer join
        logging (bool or str, optional): Logging level (default: 'default')
                                        - False: No output
                                        - 'default': Log magic operations only (Phase 2)
                                        - True: Log all operations (Phase 2)
                                        Note: Phase 1 always uses False
        as_type (str, optional): Output DataFrame type
                                - None: Return same type as bring_to (default)
                                - 'pandas': Convert to pandas DataFrame
                                - 'polars': Convert to polars DataFrame
        lineage (bool, optional): Enable lineage tracking (default: False)
                                 When True, records operation metadata for later inspection
                                 with add.scan('@lineage'). Adds <10% execution overhead.
        
    Returns:
        DataFrame: Result DataFrame with brought columns (same type as bring_to unless as_type specified)
        
    Raises:
        ImportError: If Rust bindings are not available
        TypeError: If parameters have invalid types or tuples used instead of lists
        ValueError: If required parameters are missing or have invalid values
        RuntimeError: If join operation fails
        
    Examples:
        >>> import additory as add
        >>> import polars as pl
        
        >>> # Basic usage - bring single column
        >>> customers = pl.DataFrame({'id': [1, 2, 3], 'name': ['Alice', 'Bob', 'Charlie']})
        >>> orders = pl.DataFrame({'customer_id': [1, 2, 1], 'amount': [100, 200, 150]})
        >>> result = add.to(customers, orders, 'amount', 'id')
        
        >>> # Bring multiple columns
        >>> result = add.to(customers, orders, ['amount', 'date'], 'id')
        
        >>> # Multiple keys for matching
        >>> sales = pl.DataFrame({'customer_id': [1, 2], 'date': ['2024-01-01', '2024-01-02']})
        >>> result = add.to(customers, sales, 'amount', ['customer_id', 'date'])
        
        >>> # Position columns after specific column
        >>> result = add.to(customers, orders, 'amount', 'id', position='after:name')
        
        >>> # Position at start of DataFrame
        >>> result = add.to(customers, orders, 'amount', 'id', position='start')
        
        >>> # Simple strategy - aggregate with sum
        >>> result = add.to(customers, orders, 'amount', 'id', strategy={'amount': 'sum'})
        
        >>> # Complex strategy - aggregate, rename, and position
        >>> result = add.to(customers, orders, 'amount', 'id',
        ...                 strategy={'amount': {'mode': 'sum', 
        ...                                     'rename': 'total_spent',
        ...                                     'position': 'after:name'}})
        
        >>> # Multiple aggregations
        >>> result = add.to(customers, orders, ['amount', 'quantity'], 'id',
        ...                 strategy={'amount': 'sum', 'quantity': 'average'})
        
        >>> # Concatenate text values
        >>> result = add.to(customers, orders, 'product', 'id',
        ...                 strategy={'product': 'concat[, ]'})
        
        >>> # Different join types
        >>> result = add.to(customers, orders, 'amount', 'id', join_type='inner')
        >>> result = add.to(customers, orders, 'amount', 'id', join_type='outer')
        
        >>> # Convert output type
        >>> result = add.to(customers, orders, 'amount', 'id', as_type='pandas')
    
    Notes:
        - Lists are required for multiple values, tuples will raise TypeError
        - Backend (pandas/polars) is auto-detected and preserved by default
        - When multiple rows match, use strategy parameter to specify aggregation
        - Column-level strategy settings override DataFrame-level position
        - All numerical operations use float64 precision for consistency
    """
    import polars as pl
    import pandas as pd
    from additory.validation import (
        validate_required_params_to,
        validate_to_types,
        validate_to_values
    )
    
    # VALIDATION ORDER (before any data operations):
    # 1. Validate required parameters
    # 2. Validate parameter types
    # 3. Validate parameter values
    
    # Step 1: Validate required parameters
    validate_required_params_to(bring_to, bring_from, bring, against)
    
    # Step 2: Validate parameter types
    validate_to_types(bring_to, bring_from, bring, against, position, 
                     strategy, join_type, logging, as_type)
    
    # Step 3: Validate parameter values
    validate_to_values(join_type, logging, as_type)
    
    # Now proceed with data operations
    
    if not RUST_AVAILABLE:
        raise ImportError(
            "add.to() requires Rust bindings. "
            "Install with: pip install additory[rust]"
        )
    
    # Normalize inputs using new parsing
    # Convert string to list for bring parameter
    if isinstance(bring, str):
        bring = [bring]
    bring = normalize_column_input(bring)
    against = normalize_key_input(against)
    
    # Parse strategy if provided
    if strategy is not None:
        if isinstance(strategy, str):
            # Simple mode string
            strategy = parse_strategy_value(strategy)
        elif isinstance(strategy, dict):
            # Dict with mode and other options
            if 'mode' in strategy:
                strategy = parse_strategy_value(strategy)
            # else: keep as-is (might be other options without mode)
    
    # Detect DataFrame types
    target_is_pandas = isinstance(bring_to, pd.DataFrame)
    target_is_polars = isinstance(bring_to, pl.DataFrame)
    
    ref_is_pandas = isinstance(bring_from, pd.DataFrame)
    ref_is_polars = isinstance(bring_from, pl.DataFrame)
    
    # Convert to polars if needed
    target_pl = pl.from_pandas(bring_to) if target_is_pandas else bring_to
    
    bring_from_pl = pl.from_pandas(bring_from) if ref_is_pandas else bring_from
    
    # Convert target to Arrow IPC bytes
    import io
    
    target_buffer = io.BytesIO()
    target_pl.write_ipc(target_buffer)
    target_bytes = target_buffer.getvalue()
    
    # Convert fetch_from to Arrow IPC bytes
    ref_buffer = io.BytesIO()
    bring_from_pl.write_ipc(ref_buffer)
    ref_bytes = ref_buffer.getvalue()
    
    # Prepare parameters
    params = {
        'bring_from': ref_bytes,
        'bring': bring,
        'against': against,
        'position': position,
        'strategy': strategy,
        'join_type': join_type,
        'logging': False,
    }
    
    # Call Rust to function
    try:
        result_bytes = _additory.to(target_bytes, params)
    except Exception as e:
        raise RuntimeError(f"add.to() failed: {e}") from e
    
    # Convert back to DataFrame
    result_buffer = io.BytesIO(result_bytes)
    result_df = pl.read_ipc(result_buffer)
    
    # Record lineage if enabled
    if lineage:
        from additory.lineage_tracker import Lineage_Tracker, OperationRecorder
        
        tracker = Lineage_Tracker()
        recorder = OperationRecorder()
        
        # Prepare operation parameters
        operation_params = recorder.record_to_operation({
            'bring_from': id(bring_from),  # Use id for source table identifier
            'bring': bring,
            'against': against,
            'join_type': join_type,
            'position': position,
            'strategy': strategy
        })
        
        # Record the operation
        result_df = tracker.record_operation(
            df=result_df,
            operation_type='add.to',
            params=operation_params,
            rows_before=len(target_pl),
            rows_after=len(result_df),
            columns_added=bring if isinstance(bring, list) else [bring],
            columns_modified=[]
        )
    
    # Convert to requested output type
    if as_type == 'pandas':
        return result_df.to_pandas()
    elif as_type == 'polars':
        return result_df
    elif target_is_pandas:
        return result_df.to_pandas()
    else:
        return result_df


def transform(
    mode: str,
    df: Union['pd.DataFrame', 'pl.DataFrame'],
    columns: Optional[Union[str, List[str]]] = None,
    *,
    where: Optional[str] = None,
    by: Optional[Union[str, List[str]]] = None,
    position: Union[str, int] = 'end',
    strategy: Optional[Union[str, Dict[str, Any]]] = None,
    logging: Union[bool, str] = 'default',
    as_type: Optional[str] = None,
    lineage: bool = False
) -> Union['pd.DataFrame', 'pl.DataFrame']:
    """
    Transform data within a DataFrame using one of 10 transformation modes.
    
    This function provides a unified interface for common DataFrame transformations
    including calculations, filtering, sorting, aggregation, harmonization, rounding,
    transposition, pattern extraction, one-hot encoding, and missing value imputation.
    
    Available Modes:
        @calc: Calculate new columns using expressions
        @filter: Filter rows based on conditions
        @sort: Sort rows by column(s)
        @aggregate: Group and aggregate data
        @harmonize: Harmonize units (10 sub-modes: weight, temperature, length, volume, 
                   speed, glucose, pressure, torque, concentration, frequency)
        @round: Round numbers creating new columns (4 sub-modes: round, roundup, 
               rounddown, round:banker)
        @transpose: Transpose DataFrame
        @extract: Extract patterns from text (includes datetime parsing)
        @onehotencode: One-hot encode categorical columns
        @deduce: Fill missing values (7 methods: auto, mean, median, mode, forward, 
                backward, knn)
    
    Args:
        mode (str): Transform mode (e.g., '@calc', '@filter', '@sort', '@deduce')
        df (DataFrame): Input DataFrame (pandas or polars)
        columns (str or list, optional): Column(s) to transform/select
                                        - Single column: 'age' or ['age']
                                        - Multiple columns: ['age', 'salary'] (list required, not tuple)
        where (str, optional): Filter condition for @filter mode
                              SQL-like syntax: 'age > 18 AND status == "active"'
        by (str or list, optional): Grouping/sort column(s)
                                   - Single column: 'date' or ['date']
                                   - Multiple columns: ['date', 'name'] (list required, not tuple)
        position (str or int, optional): Position for new columns (default: 'end')
                                        - String: 'start', 'end', 'after:col', 'before:col'
                                        - Integer: 0, 1, -1, -2 (Python indexing)
        strategy (dict, optional): Advanced mode-specific options
                                  - @calc: {'new_col': 'expression', ...}
                                  - @sort: {'order': 'asc' | 'desc'}
                                  - @aggregate: {'col': 'aggregation_function', ...}
                                  - @round: {'col': {'name': 'new_name', 'position': 'after:id'}, ...}
                                  - @deduce: {'method': 'mean'|'median'|'mode'|'forward'|'backward'|'knn'|'auto', 
                                            'k': 5, 'weights': 'distance'}
        logging (bool or str, optional): Logging level (default: 'default')
                                        - False: No output
                                        - 'default': Log magic operations only (Phase 2)
                                        - True: Log all operations (Phase 2)
                                        Note: Phase 1 always uses False
        as_type (str, optional): Output DataFrame type
                                - None: Return same type as input (default)
                                - 'pandas': Convert to pandas DataFrame
                                - 'polars': Convert to polars DataFrame
        lineage (bool, optional): Enable lineage tracking (default: False)
                                 When True, records operation metadata for later inspection
                                 with add.scan('@lineage'). Adds <15% execution overhead.
        
    Returns:
        DataFrame: Transformed DataFrame (same type as input unless as_type specified)
        
    Raises:
        TypeError: If parameters have invalid types or tuples used instead of lists
        ValueError: If parameters have invalid values or mode is not recognized
        RuntimeError: If transformation fails
        
    Examples:
        >>> import additory as add
        >>> import polars as pl
        
        >>> df = pl.DataFrame({
        ...     'name': ['Alice', 'Bob', 'Charlie'],
        ...     'age': [25, 30, 35],
        ...     'salary': [50000, 60000, 70000],
        ...     'weight': [65.5, 80.2, 75.8]
        ... })
        
        # @calc - Calculate new columns
        >>> result = add.transform('@calc', df, 
        ...     strategy={'age_squared': 'age * age', 'salary_k': 'salary / 1000'})
        
        >>> # @calc with built-in expressions
        >>> df_bmi = pl.DataFrame({'weight': [70, 80], 'height': [1.75, 1.80]})
        >>> result = add.transform('@calc', df_bmi, strategy={'bmi': 'inbuilt:bmi'})
        
        # @filter - Filter rows
        >>> result = add.transform('@filter', df, where='age > 25')
        >>> result = add.transform('@filter', df, where='age > 25 AND salary < 65000')
        
        # @sort - Sort rows ascending
        >>> result = add.transform('@sort', df, by='age', strategy={'order': 'asc'})
        
        >>> # @sort descending by multiple columns
        >>> result = add.transform('@sort', df, by=['salary', 'age'], strategy={'order': 'desc'})
        
        # @aggregate - Group and aggregate
        >>> sales = pl.DataFrame({
        ...     'product': ['A', 'B', 'A', 'B'],
        ...     'amount': [100, 200, 150, 250],
        ...     'quantity': [1, 2, 1, 3]
        ... })
        >>> result = add.transform('@aggregate', sales, by='product',
        ...     strategy={'amount': 'sum', 'quantity': 'average'})
        
        # @harmonize - Harmonize units (weight example)
        >>> df_weight = pl.DataFrame({'weight': [70, 150], 'unit': ['kg', 'lbs']})
        >>> result = add.transform('@harmonize:weight', df_weight, columns='weight')
        
        >>> # @harmonize temperature
        >>> df_temp = pl.DataFrame({'temp': [32, 100], 'unit': ['F', 'C']})
        >>> result = add.transform('@harmonize:temperature', df_temp, columns='temp')
        
        # @round - Round creating new columns (preserves originals)
        >>> result = add.transform('@round:2', df, columns=['weight'])
        >>> # Creates 'weight_round' column with 2 decimal places
        
        >>> # @round with custom naming
        >>> result = add.transform('@round:2', df, columns='weight',
        ...     strategy={'weight': {'name': 'weight_rounded', 'position': 'after:weight'}})
        
        >>> # @round multiple columns
        >>> result = add.transform('@round:1', df, columns=['weight', 'salary'])
        
        >>> # @round sub-modes
        >>> result = add.transform('@roundup', df, columns='weight')
        >>> result = add.transform('@rounddown', df, columns='weight')
        >>> result = add.transform('@round:banker', df, columns='weight')
        
        # @transpose - Transpose DataFrame
        >>> result = add.transform('@transpose', df)
        
        # @extract - Extract patterns from text
        >>> df_text = pl.DataFrame({'email': ['alice@example.com', 'bob@test.org']})
        >>> result = add.transform('@extract', df_text, columns='email',
        ...     strategy={'domain': r'@(.+)'})
        
        >>> # @extract datetime parsing (merged from @datetime)
        >>> df_dates = pl.DataFrame({'date_str': ['01-12-2024', '15-06-2023']})
        >>> result = add.transform('@extract', df_dates, columns='date_str',
        ...     strategy={'date': 'dd-MM-yyyy'})
        
        >>> # @extract with Excel dates
        >>> df_excel = pl.DataFrame({'excel_date': [44927, 44928]})
        >>> result = add.transform('@extract', df_excel, columns='excel_date',
        ...     strategy={'date': 'excel'})
        
        # @onehotencode - One-hot encode categorical columns
        >>> df_cat = pl.DataFrame({'color': ['red', 'blue', 'red', 'green']})
        >>> result = add.transform('@onehotencode', df_cat, columns='color')
        
        >>> # @onehotencode multiple columns
        >>> result = add.transform('@onehotencode', df_cat, columns=['color', 'size'])
        
        # @deduce - Fill missing values with mean
        >>> df_missing = pl.DataFrame({'age': [25, None, 35, None, 45]})
        >>> result = add.transform('@deduce', df_missing, columns='age',
        ...     strategy={'method': 'mean'})
        
        >>> # @deduce with median
        >>> result = add.transform('@deduce', df_missing, columns='age',
        ...     strategy={'method': 'median'})
        
        >>> # @deduce with mode
        >>> result = add.transform('@deduce', df_missing, columns='age',
        ...     strategy={'method': 'mode'})
        
        >>> # @deduce with forward fill
        >>> result = add.transform('@deduce', df_missing, columns='age',
        ...     strategy={'method': 'forward'})
        
        >>> # @deduce with backward fill
        >>> result = add.transform('@deduce', df_missing, columns='age',
        ...     strategy={'method': 'backward'})
        
        >>> # @deduce with KNN (k-nearest neighbors)
        >>> result = add.transform('@deduce', df_missing, columns='age',
        ...     strategy={'method': 'knn', 'k': 5, 'weights': 'distance'})
        
        >>> # @deduce with auto method (chooses based on data type)
        >>> result = add.transform('@deduce', df_missing, columns=['age', 'name'],
        ...     strategy={'method': 'auto'})
        
        >>> # @deduce multiple columns simultaneously
        >>> df_multi = pl.DataFrame({
        ...     'age': [25, None, 35],
        ...     'salary': [50000, 60000, None]
        ... })
        >>> result = add.transform('@deduce', df_multi, columns=['age', 'salary'],
        ...     strategy={'method': 'mean'})
        
        # Position control
        >>> result = add.transform('@calc', df, position='start',
        ...     strategy={'age_doubled': 'age * 2'})
        
        >>> result = add.transform('@calc', df, position='after:name',
        ...     strategy={'age_doubled': 'age * 2'})
        
        # Output type conversion
        >>> result = add.transform('@filter', df, where='age > 25', as_type='pandas')
    
    Notes:
        - Lists are required for multiple values, tuples will raise TypeError
        - Backend (pandas/polars) is auto-detected and preserved by default
        - @round creates NEW columns and preserves originals (no in-place modification)
        - @extract merged @datetime functionality for unified pattern extraction
        - @deduce replaces standalone add.deduce() function
        - @deduce only fills null values, preserves all existing non-null values
        - All numerical operations use float64 precision for consistency
        - Phase 1: logging is always False (full logging in Phase 2)
    """
    import polars as pl
    import pandas as pd
    from additory.validation import (
        validate_required_params_transform,
        validate_transform_types,
        validate_transform_values
    )
    
    # VALIDATION ORDER (before any data operations):
    # 1. Validate required parameters
    # 2. Validate parameter types
    # 3. Validate parameter values
    
    # Step 1: Validate required parameters
    validate_required_params_transform(mode, df)
    
    # Step 2: Validate parameter types
    validate_transform_types(mode, df, columns, by, position, strategy, logging, as_type)
    
    # Step 3: Validate parameter values
    validate_transform_values(mode, logging, as_type)
    
    # Now proceed with data operations
    
    # Phase 1: Force logging to False
    logging = False
    
    # Normalize inputs using new parsing
    if columns is not None:
        columns = normalize_column_input(columns)
    if by is not None:
        by = normalize_by_input(by)
    
    # Parse strategy if provided
    if strategy is not None:
        if isinstance(strategy, str):
            # Simple mode string
            strategy = parse_strategy_value(strategy)
        elif isinstance(strategy, dict):
            # Dict with mode and other options
            if 'mode' in strategy:
                strategy = parse_strategy_value(strategy)
            # else: keep as-is (might be other options without mode)
    
    # Detect backend
    is_pandas = isinstance(df, pd.DataFrame)
    is_polars = isinstance(df, pl.DataFrame)
    
    if not is_pandas and not is_polars:
        raise TypeError(
            f"DataFrame must be pandas or polars, got {type(df).__name__}"
        )
    
    # Convert to polars if needed
    if is_pandas:
        df_pl = pl.from_pandas(df)
    else:
        df_pl = df
    
    # Mode routing - handle all 10 modes plus 2 easter eggs
    valid_modes = [
        '@calc', '@filter', '@sort', '@aggregate', '@harmonize', 
        '@round', '@transpose', '@extract', '@onehotencode', '@deduce',
        '@tictactoe', '@ttt', '@sudoku'  # Easter eggs (hidden)
    ]
    
    # Extract base mode (handle sub-modes like @round:2, @harmonize:weight)
    base_mode = mode.split(':')[0] if ':' in mode else mode
    
    # Check if mode is valid (including sub-modes)
    if base_mode not in valid_modes:
        # Check for common variations
        if base_mode == '@onehot':
            base_mode = '@onehotencode'
            mode = '@onehotencode' if ':' not in mode else '@onehotencode:' + mode.split(':', 1)[1]
        elif base_mode == '@knn':
            # @knn is now @deduce
            raise ValueError(
                f"Mode '@knn' has been renamed to '@deduce'. "
                f"Use add.transform('@deduce', ...) instead"
            )
        elif base_mode == '@datetime':
            # @datetime is now merged into @extract
            raise ValueError(
                f"Mode '@datetime' has been merged into '@extract'. "
                f"Use add.transform('@extract', ...) instead"
            )
        else:
            raise ValueError(
                f"Invalid mode '{mode}'. Valid modes: {', '.join([m for m in valid_modes if not m.startswith('@tictactoe') and not m.startswith('@ttt') and m != '@sudoku'])}"
            )
    
    # Easter egg modes - return DataFrame unchanged
    if base_mode in ['@tictactoe', '@ttt', '@sudoku']:
        # Return original DataFrame unchanged
        if as_type == 'pandas' and is_polars:
            return df_pl.to_pandas()
        elif as_type == 'polars' and is_pandas:
            return df_pl
        else:
            return df
    
    # Call Rust implementation if available
    if RUST_AVAILABLE:
        # Convert to Arrow IPC bytes
        import io
        buffer = io.BytesIO()
        df_pl.write_ipc(buffer)
        df_bytes = buffer.getvalue()
        
        # Prepare parameters with new names
        params = {
            'mode': mode,
            'columns': columns,
            'by': by,
            'where': where,
            'position': position,
            'strategy': strategy,
            'logging': logging,
        }
        
        # Call Rust transform
        try:
            result_bytes = _additory.transform(df_bytes, params)
        except Exception as e:
            raise RuntimeError(f"Transform failed: {e}") from e
        
        # Convert back to DataFrame
        result_buffer = io.BytesIO(result_bytes)
        result_df = pl.read_ipc(result_buffer)
    else:
        # Rust bindings are required for all transform modes
        raise NotImplementedError(
            f"Transform mode {mode} requires Rust bindings. "
            f"Install with: pip install additory"
        )
    
    # Record lineage if enabled
    if lineage:
        from additory.lineage_tracker import Lineage_Tracker, OperationRecorder
        
        tracker = Lineage_Tracker()
        recorder = OperationRecorder()
        
        # Prepare operation parameters
        operation_params = recorder.record_transform_operation(base_mode, {
            'mode': mode,
            'columns': columns,
            'by': by,
            'where': where,
            'position': position,
            'strategy': strategy
        })
        
        # Determine columns added/modified based on mode
        columns_added = []
        columns_modified = []
        
        if base_mode == '@calc' and strategy:
            # New columns created by calculations
            columns_added = list(strategy.keys()) if isinstance(strategy, dict) else []
        elif base_mode == '@filter':
            # No columns added/modified, just rows removed
            pass
        elif base_mode == '@aggregate':
            # Columns created by aggregation
            if strategy and isinstance(strategy, dict):
                columns_added = list(strategy.keys())
        elif base_mode in ['@round', '@extract', '@onehotencode']:
            # These modes create new columns
            # Column names depend on the operation, we'll track what's new
            original_cols = set(df_pl.columns)
            new_cols = set(result_df.columns)
            columns_added = list(new_cols - original_cols)
        elif base_mode == '@deduce':
            # Modifies existing columns by filling nulls
            columns_modified = columns if columns else []
        
        # Record the operation
        result_df = tracker.record_operation(
            df=result_df,
            operation_type='add.transform',
            params=operation_params,
            rows_before=len(df_pl),
            rows_after=len(result_df),
            columns_added=columns_added,
            columns_modified=columns_modified
        )
    
    # Handle as_type conversion
    if as_type == 'pandas':
        return result_df.to_pandas()
    elif as_type == 'polars':
        return result_df
    elif as_type is not None:
        raise ValueError(
            f"Parameter 'as_type' must be None, 'pandas', or 'polars', got '{as_type}'"
        )
    
    # Convert back to original type if as_type not specified
    if is_pandas:
        return result_df.to_pandas()
    else:
        return result_df


def synthetic(
    mode: str,
    df: Optional[Union['pd.DataFrame', 'pl.DataFrame']] = None,
    n: Optional[int] = None,
    *,
    strategy: Optional[Dict[str, Any]] = None,
    seed: Optional[int] = 42,
    logging: Union[bool, str] = 'default',
    as_type: Optional[str] = None,
    lineage: bool = False
) -> Union['pd.DataFrame', 'pl.DataFrame']:
    """
    Generate or augment synthetic data using Rust backend for high performance.
    
    Modes:
    - @new: Create new synthetic DataFrame from scratch
    - @augment: Add synthetic rows to existing DataFrame
    
    Note: For data analysis, use add.analyze() or add.analyse() instead.
    
    Args:
        mode (str): '@new' or '@augment'
        df: Optional DataFrame (required for '@augment')
            Accepts both pandas and polars DataFrames
        n (int): Number of rows to generate (required for '@new' and '@augment')
        strategy (dict): Dictionary mapping column names to generation strategies
                        Available strategies:
                        - increment: Sequential integers (e.g., 1, 2, 3, ...)
                        - increment:start: Start from specific number
                        - increment:start:step: Custom start and step
                        - pattern:text{increment:padding}: Pattern with leading zeros
                        - range: Range of values with start, stop, step
                        - choice: Random choice from a list of values
                        - linked_list: Traverse a linked list structure
                        - normal: Normal (Gaussian) distribution
                        - uniform: Uniform distribution
                        - lognormal: Log-normal distribution
                        - exponential: Exponential distribution
                        - poisson: Poisson distribution
                        - categorical: Categorical distribution with probabilities
        seed (int): Random seed for reproducibility (default: 42, ensures deterministic results)
        logging (Union[bool, str]): Logging level (default: 'default')
                                   - False: No output
                                   - 'default': Log magic operations only (Phase 2)
                                   - True: Log all operations (Phase 2)
                                   Note: Phase 1 implementation always uses False
        as_type (str): Output format override ('pandas' or 'polars')
                      If None, returns same type as input
        lineage (bool, optional): Enable lineage tracking (default: False)
                                 When True, records operation metadata for later inspection
                                 with add.scan('@lineage'). Adds <10% execution overhead.
    
    Returns:
        DataFrame: Result DataFrame with synthetic data
                  - For '@new': New DataFrame with n rows
                  - For '@augment': Original DataFrame + n new rows
    
    Raises:
        ImportError: If Rust bindings are not available
        ValueError: If parameters are invalid or incompatible
        RuntimeError: If synthetic data generation fails
    
    Examples:
        >>> import additory as add
        >>> import polars as pl
        
        >>> # Mode: @new - Create new synthetic DataFrame
        >>> df = add.synthetic('@new', n=100, 
        ...                    strategy={'id': 'increment', 'value': 'normal'})
        
        >>> # Mode: @augment - Add synthetic rows to existing DataFrame
        >>> df = pl.DataFrame({'id': [1, 2, 3]})
        >>> result = add.synthetic('@augment', df=df, n=10, 
        ...                        strategy={'id': 'increment'})
        
        >>> # For data analysis, use add.analyze() or add.analyse()
        >>> analysis = add.analyze(df)
        
        >>> # Strategy: increment - Sequential integers
        >>> df = add.synthetic('@new', n=100, strategy={'id': 'increment'})
        >>> # Generates: id = 1, 2, 3, ..., 100
        
        >>> # Strategy: increment with custom start
        >>> df = add.synthetic('@new', n=50, 
        ...                    strategy={'id': 'increment:100'})
        >>> # Generates: id = 100, 101, 102, ..., 149
        
        >>> # Strategy: increment with custom start and step
        >>> df = add.synthetic('@new', n=10, 
        ...                    strategy={'id': 'increment:100:5'})
        >>> # Generates: id = 100, 105, 110, 115, ..., 145
        
        >>> # Strategy: pattern with leading zeros
        >>> df = add.synthetic('@new', n=10,
        ...                    strategy={'subject_id': 'pattern:subj{increment:3}'})
        >>> # Generates: subject_id = subj001, subj002, subj003, ..., subj010
        
        >>> # Strategy: pattern with custom padding
        >>> df = add.synthetic('@new', n=100,
        ...                    strategy={'id': 'pattern:ID{increment:4}'})
        >>> # Generates: id = ID0001, ID0002, ..., ID0100
        
        >>> # Strategy: range - Range with start, stop, step
        >>> df = add.synthetic('@new', n=50, 
        ...                    strategy={'value': 'range:0:100:2'})
        >>> # Generates: value = 0, 2, 4, 6, ..., 98
        
        >>> # Strategy: choice - Random choice from list
        >>> df = add.synthetic('@new', n=100,
        ...                    strategy={'color': 'choice:red,blue,green'})
        >>> # Generates: random selection from ['red', 'blue', 'green']
        
        >>> # Strategy: linked_list - Traverse linked structure
        >>> df = add.synthetic('@new', n=100,
        ...                    strategy={'next_id': 'linked_list:id'})
        >>> # Generates: linked list traversal pattern
        
        >>> # Strategy: normal - Normal distribution
        >>> df = add.synthetic('@new', n=1000,
        ...                    strategy={'height': 'normal:170:10'})
        >>> # Generates: mean=170, std=10 (e.g., heights in cm)
        
        >>> # Strategy: uniform - Uniform distribution
        >>> df = add.synthetic('@new', n=1000,
        ...                    strategy={'score': 'uniform:0:100'})
        >>> # Generates: uniform values between 0 and 100
        
        >>> # Strategy: lognormal - Log-normal distribution
        >>> df = add.synthetic('@new', n=1000,
        ...                    strategy={'income': 'lognormal:10:0.5'})
        >>> # Generates: log-normal distribution (e.g., income data)
        
        >>> # Strategy: exponential - Exponential distribution
        >>> df = add.synthetic('@new', n=1000,
        ...                    strategy={'wait_time': 'exponential:0.5'})
        >>> # Generates: exponential with lambda=0.5 (e.g., wait times)
        
        >>> # Strategy: poisson - Poisson distribution
        >>> df = add.synthetic('@new', n=1000,
        ...                    strategy={'events': 'poisson:3'})
        >>> # Generates: Poisson with lambda=3 (e.g., event counts)
        
        >>> # Strategy: categorical - Categorical with probabilities
        >>> df = add.synthetic('@new', n=1000,
        ...                    strategy={'status': 'categorical:active:0.7,inactive:0.3'})
        >>> # Generates: 70% 'active', 30% 'inactive'
        
        >>> # Multiple strategies combined
        >>> df = add.synthetic('@new', n=1000, strategy={
        ...     'id': 'increment',
        ...     'age': 'normal:35:10',
        ...     'salary': 'lognormal:10.5:0.5',
        ...     'department': 'choice:Engineering,Sales,Marketing',
        ...     'status': 'categorical:active:0.8,inactive:0.2'
        ... })
        
        >>> # With seed for reproducibility (default is 42)
        >>> df1 = add.synthetic('@new', n=100, strategy={'id': 'increment'}, seed=42)
        >>> df2 = add.synthetic('@new', n=100, strategy={'id': 'increment'}, seed=42)
        >>> # df1 and df2 are identical
        
        >>> # With different seed for different results
        >>> df3 = add.synthetic('@new', n=100, strategy={'id': 'increment'}, seed=123)
        >>> # df3 will be different from df1 and df2
        
        >>> # Output type control
        >>> df_pandas = add.synthetic('@new', n=100, 
        ...                           strategy={'id': 'increment'}, 
        ...                           as_type='pandas')
        >>> df_polars = add.synthetic('@new', n=100,
        ...                           strategy={'id': 'increment'},
        ...                           as_type='polars')
    
    Notes:
        - The Rust backend provides 2-4x performance improvement over Python
        - All strategies support deterministic generation with seed parameter (default: 42)
        - DataFrame type (pandas/polars) is preserved unless as_type is specified
        - For '@augment' mode, new rows are appended to the end of the DataFrame
        - Both '@analyze' and '@analyse' spellings are supported (international)
        - Phase 1 implementation: logging is always False (full logging in Phase 2)
    """
    import polars as pl
    import pandas as pd
    from additory.validation import (
        validate_required_params_synthetic,
        validate_synthetic_types,
        validate_synthetic_values
    )
    
    # VALIDATION ORDER (before any data operations):
    # 1. Validate required parameters
    # 2. Validate parameter types
    # 3. Validate parameter values
    
    # Step 1: Validate required parameters
    validate_required_params_synthetic(mode)
    
    # Step 2: Validate parameter types
    validate_synthetic_types(mode, df, n, strategy, seed, logging, as_type)
    
    # Step 3: Validate parameter values
    validate_synthetic_values(mode, logging, as_type)
    
    # Now proceed with data operations
    
    # DEPRECATION: Check for @analyze mode
    if mode == '@analyze':
        import warnings
        warnings.warn(
            "add.synthetic('@analyze', ...) is deprecated and will be removed in v0.2.0. "
            "Use add.scan('@analyze', ...) instead. "
            "Example: add.scan('@analyze', df) "
            "See documentation for migration guide.",
            DeprecationWarning,
            stacklevel=2
        )
        # For now, continue to support @analyze mode for backward compatibility
    
    if not RUST_AVAILABLE:
        raise ImportError(
            "add.synthetic() requires Rust bindings. "
            "Install with: pip install additory[rust]"
        )
    
    # Phase 1: Always set logging to False (full logging implementation in Phase 2)
    logging = False
    
    # Detect DataFrame type
    input_is_pandas = isinstance(df, pd.DataFrame) if df is not None else False
    input_is_polars = isinstance(df, pl.DataFrame) if df is not None else False
    
    # Validate DataFrame type
    if df is not None and not input_is_pandas and not input_is_polars:
        raise TypeError(
            f"df must be pandas or polars DataFrame, got {type(df).__name__}"
        )
    
    # Convert to polars if needed
    if df is not None:
        df_pl = pl.from_pandas(df) if input_is_pandas else df
    else:
        df_pl = None
    
    # Serialize DataFrame to Arrow IPC
    import io
    df_bytes = None
    if df_pl is not None:
        buffer = io.BytesIO()
        df_pl.write_ipc(buffer)
        df_bytes = buffer.getvalue()
    
    # Build parameters dict
    params = {
        'mode': mode,
        'n': n,
        'strategy': strategy,
        'seed': seed,
        'logging': logging,
    }
    
    # Call Rust function
    try:
        result_bytes = _additory.synthetic(df_bytes, params)
    except Exception as e:
        raise RuntimeError(f"add.synthetic() failed: {e}") from e
    
    # Deserialize result
    result_buffer = io.BytesIO(result_bytes)
    result_df = pl.read_ipc(result_buffer)
    
    # Record lineage if enabled
    if lineage:
        from additory.lineage_tracker import Lineage_Tracker, OperationRecorder
        
        tracker = Lineage_Tracker()
        recorder = OperationRecorder()
        
        # Prepare operation parameters
        operation_params = recorder.record_synthetic_operation(mode, {
            'mode': mode,
            'n': n,
            'strategy': strategy,
            'seed': seed
        })
        
        # Determine columns added based on mode
        columns_added = []
        if mode == '@new':
            # All columns are new
            columns_added = list(result_df.columns)
        elif mode == '@augment':
            # No new columns, just new rows
            pass
        
        # Record the operation
        result_df = tracker.record_operation(
            df=result_df,
            operation_type='add.synthetic',
            params=operation_params,
            rows_before=len(df_pl) if df_pl is not None else 0,
            rows_after=len(result_df),
            columns_added=columns_added,
            columns_modified=[]
        )
    
    # Convert to requested output type
    if as_type == 'pandas':
        return result_df.to_pandas()
    elif as_type == 'polars':
        return result_df
    elif input_is_pandas:
        return result_df.to_pandas()
    else:
        return result_df




# Expose key functions
__all__ = [
    'to',
    'transform',
    'synthetic',
    'scan',
    '__version__',
    'RUST_AVAILABLE',
]


# Print warning if Rust bindings not available
if not RUST_AVAILABLE:
    import warnings
    warnings.warn(
        "Rust bindings not available. Only Python-only modes (@knn) will work. "
        "Install Rust bindings with: pip install additory[rust]",
        ImportWarning
    )
