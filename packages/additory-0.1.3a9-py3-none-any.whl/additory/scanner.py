"""
Scanner module for add.scan() function

Provides data inspection, analysis, and lineage tracking capabilities.

Modes:
- @analyze: Statistical profiling and data quality assessment
- @lineage: Transformation tracking and explainability
"""

from typing import Union, List, Dict, Any, Optional, Tuple
import pandas as pd
import polars as pl


def scan(
    mode: str,
    df: Union[pd.DataFrame, pl.DataFrame],
    *,
    columns: Optional[Union[str, List[str]]] = None,
    where: Optional[str] = None,
    rows: Optional[Union[str, List[str]]] = None,
    trace: Optional[List[int]] = None,
    focus: Optional[str] = None,
    as_type: Optional[str] = None
) -> Union[pd.DataFrame, pl.DataFrame, Dict, str]:
    """
    Inspect, analyze, and explain DataFrames.
    
    This function provides two primary capabilities:
    1. Data profiling and statistical analysis (@analyze mode)
    2. Lineage tracking and transformation explainability (@lineage mode)
    
    Args:
        mode (str): Scan mode
                   - '@analyze': Statistical profiling and data quality assessment
                   - '@lineage': Transformation tracking and explainability
        df (DataFrame): DataFrame to inspect (pandas or polars)
        columns (str or list, optional): Specific columns to focus on
                                        - Single: 'age'
                                        - Multiple: ['age', 'salary']
        where (str, optional): Filter condition for focused analysis
                              - Example: 'region == "West"'
                              - Example: 'age > 30 AND salary < 100000'
        rows (str or list, optional): Specific rows to analyze
                                     - Ranges: 'first:10', 'last:5', '25-50'
                                     - Individual: '61', '72'
                                     - Multiple: ['first:10', '25-50', '61', 'last']
        trace (list of 2 ints, optional): Trace specific cell [column_index, row_index]
                                         - Example: [2, 5] for Column 2, Row 5
        focus (str, optional): Specialized focus mode
                              For @analyze:
                              - 'outliers': Detect outliers using IQR method
                              - 'correlations': Compute correlation matrix
                              - 'distributions': Test against common distributions
                              For @lineage:
                              - 'nulls': Analyze null value root causes
                              - 'excluded': Analyze filtered out rows
                              - 'source:name': Analyze data from specific source
        as_type (str, optional): Output format
                                - 'dataframe': Return as DataFrame (default for @analyze)
                                - 'dict': Return as dictionary
                                - 'text': Return as formatted text (default for @lineage)
    
    Returns:
        Union[DataFrame, Dict, str]: Analysis results in specified format
        
    Raises:
        ValueError: If mode is not '@analyze' or '@lineage'
        TypeError: If DataFrame is not pandas or polars
        ValueError: If parameters have invalid values
        RuntimeError: If scan operation fails
        
    Examples:
        >>> import additory as add
        >>> import polars as pl
        
        >>> df = pl.DataFrame({
        ...     'age': [25, 30, 35, None, 45, 200],
        ...     'salary': [50000, 60000, 70000, 80000, 90000, 100000],
        ...     'region': ['West', 'East', 'West', 'South', 'East', 'West']
        ... })
        
        # Basic analysis
        >>> result = add.scan('@analyze', df)
        
        # Analyze specific columns
        >>> result = add.scan('@analyze', df, columns=['age', 'salary'])
        
        # Analyze with filter
        >>> result = add.scan('@analyze', df, where='region == "West"')
        
        # Find outliers
        >>> result = add.scan('@analyze', df, focus='outliers')
        
        # Get correlations
        >>> result = add.scan('@analyze', df, columns=['age', 'salary'], focus='correlations')
        
        # Lineage tracking (requires lineage=True in operations)
        >>> df1 = add.to(orders, bring_from=customers, bring=['name'], 
        ...              against='customer_id', lineage=True)
        >>> df2 = add.transform('@calc', df1, strategy={'total': 'price * quantity'}, 
        ...                     lineage=True)
        >>> result = add.scan('@lineage', df2)
        
        # Trace specific cell
        >>> result = add.scan('@lineage', df2, trace=[2, 5])
        
        # Analyze null values
        >>> result = add.scan('@lineage', df2, focus='nulls')
    
    Notes:
        - @analyze mode works on any DataFrame
        - @lineage mode requires lineage tracking to be enabled (lineage=True in operations)
        - Default output format: DataFrame for @analyze, text for @lineage
        - Lists are required for multiple values, tuples will raise TypeError
    """
    # Validate parameters
    validator = ParameterValidator()
    validator.validate_mode(mode)
    validator.validate_dataframe(df)
    
    if columns is not None:
        columns = validator.validate_columns(df, columns)
    if rows is not None:
        rows = validator.validate_rows(df, rows)
    if trace is not None:
        trace = validator.validate_trace(df, trace)
    if focus is not None:
        validator.validate_focus(mode, focus)
    if as_type is not None:
        validator.validate_as_type(as_type)
    if where is not None:
        validator.validate_where(where)
    
    # Route to appropriate mode handler
    if mode == '@analyze':
        analyzer = AnalyzeMode()
        result = analyzer.execute(df, columns, where, rows, focus)
        
        # Format output
        formatter = OutputFormatter()
        default_type = 'dataframe'
        output_type = as_type if as_type is not None else default_type
        return formatter.format(result, output_type)
        
    elif mode == '@lineage':
        lineage_mode = LineageMode()
        result = lineage_mode.execute(df, columns, where, rows, trace, focus)
        
        # Format output
        formatter = OutputFormatter()
        default_type = 'text'
        output_type = as_type if as_type is not None else default_type
        return formatter.format(result, output_type)
    
    else:
        raise ValueError(f"Invalid mode '{mode}'. Valid modes: '@analyze', '@lineage'")


class ParameterValidator:
    """Validates scan() parameters."""
    
    def validate_mode(self, mode: str) -> None:
        """Ensure mode is '@analyze' or '@lineage'."""
        if not isinstance(mode, str):
            raise TypeError(f"Parameter 'mode' must be str, got {type(mode).__name__}")
        
        if mode not in ['@analyze', '@lineage']:
            raise ValueError(
                f"Invalid mode '{mode}'. Valid modes: '@analyze', '@lineage'"
            )
    
    def validate_dataframe(self, df) -> None:
        """Ensure df is pandas or polars DataFrame."""
        if not isinstance(df, (pd.DataFrame, pl.DataFrame)):
            raise TypeError(
                f"Parameter 'df' must be pandas or polars DataFrame, "
                f"got {type(df).__name__}"
            )
    
    def validate_columns(self, df, columns: Union[str, List[str]]) -> List[str]:
        """Validate and normalize column selection."""
        # Convert string to list
        if isinstance(columns, str):
            columns = [columns]
        
        # Check type
        if not isinstance(columns, list):
            raise TypeError(
                f"Parameter 'columns' must be str or list, got {type(columns).__name__}"
            )
        
        # Check all elements are strings
        if not all(isinstance(col, str) for col in columns):
            raise TypeError("All elements in 'columns' must be strings")
        
        # Check columns exist in DataFrame
        df_columns = df.columns if isinstance(df, pd.DataFrame) else df.columns
        invalid_cols = [col for col in columns if col not in df_columns]
        if invalid_cols:
            raise ValueError(
                f"Columns not found in DataFrame: {invalid_cols}"
            )
        
        return columns
    
    def validate_rows(self, df, rows: Union[str, List[str]]) -> List[str]:
        """Parse and validate row selection."""
        # Convert string to list
        if isinstance(rows, str):
            rows = [rows]
        
        # Check type
        if not isinstance(rows, list):
            raise TypeError(
                f"Parameter 'rows' must be str or list, got {type(rows).__name__}"
            )
        
        # Check all elements are strings
        if not all(isinstance(row, str) for row in rows):
            raise TypeError("All elements in 'rows' must be strings")
        
        # Validate row syntax (first:N, last:N, M-N, or individual index)
        import re
        for row_spec in rows:
            if not (
                re.match(r'^first:\d+$', row_spec) or
                re.match(r'^last:\d+$', row_spec) or
                re.match(r'^\d+-\d+$', row_spec) or
                re.match(r'^\d+$', row_spec) or
                row_spec == 'last'
            ):
                raise ValueError(
                    f"Invalid row specification '{row_spec}'. "
                    f"Valid formats: 'first:N', 'last:N', 'M-N', 'N', 'last'"
                )
        
        return rows
    
    def validate_trace(self, df, trace: List[int]) -> Tuple[int, int]:
        """Validate trace parameter."""
        if not isinstance(trace, list):
            raise TypeError(
                f"Parameter 'trace' must be list of 2 integers, got {type(trace).__name__}"
            )
        
        if len(trace) != 2:
            raise ValueError(
                f"Parameter 'trace' must have exactly 2 elements [column_index, row_index], "
                f"got {len(trace)} elements"
            )
        
        if not all(isinstance(idx, int) for idx in trace):
            raise TypeError(
                "Both elements in 'trace' must be integers"
            )
        
        col_idx, row_idx = trace
        
        # Validate column index
        num_cols = len(df.columns)
        if col_idx < 0 or col_idx >= num_cols:
            raise ValueError(
                f"Column index {col_idx} out of bounds. "
                f"DataFrame has {num_cols} columns (valid range: 0-{num_cols-1})"
            )
        
        # Validate row index
        num_rows = len(df)
        if row_idx < 0 or row_idx >= num_rows:
            raise ValueError(
                f"Row index {row_idx} out of bounds. "
                f"DataFrame has {num_rows} rows (valid range: 0-{num_rows-1})"
            )
        
        return tuple(trace)
    
    def validate_focus(self, mode: str, focus: str) -> None:
        """Validate focus mode for given scan mode."""
        if not isinstance(focus, str):
            raise TypeError(f"Parameter 'focus' must be str, got {type(focus).__name__}")
        
        if mode == '@analyze':
            valid_focus = ['outliers', 'correlations', 'distributions']
            if focus not in valid_focus:
                raise ValueError(
                    f"Invalid focus '{focus}' for @analyze mode. "
                    f"Valid focus modes: {', '.join(valid_focus)}"
                )
        elif mode == '@lineage':
            valid_focus = ['nulls', 'excluded']
            # Also allow 'source:name' pattern
            if focus not in valid_focus and not focus.startswith('source:'):
                raise ValueError(
                    f"Invalid focus '{focus}' for @lineage mode. "
                    f"Valid focus modes: {', '.join(valid_focus)}, 'source:name'"
                )
    
    def validate_as_type(self, as_type: str) -> None:
        """Validate as_type parameter."""
        if not isinstance(as_type, str):
            raise TypeError(f"Parameter 'as_type' must be str, got {type(as_type).__name__}")
        
        valid_types = ['dataframe', 'dict', 'text']
        if as_type not in valid_types:
            raise ValueError(
                f"Invalid as_type '{as_type}'. "
                f"Valid types: {', '.join(valid_types)}"
            )
    
    def validate_where(self, where: str) -> None:
        """Validate where parameter."""
        if not isinstance(where, str):
            raise TypeError(f"Parameter 'where' must be str, got {type(where).__name__}")


class AnalyzeMode:
    """Implements @analyze mode for statistical profiling."""
    
    def execute(self, df, columns, where, rows, focus):
        """Execute analysis based on parameters."""
        # Apply filtering first
        df_filtered = self._apply_filters(df, columns, where, rows)
        
        # Route to appropriate analysis based on focus
        if focus is None:
            return self.profile_dataframe(df_filtered)
        elif focus == 'outliers':
            return self.detect_outliers(df_filtered, columns)
        elif focus == 'correlations':
            return self.compute_correlations(df_filtered, columns)
        elif focus == 'distributions':
            return self.detect_distributions(df_filtered, columns)
        else:
            raise ValueError(f"Invalid focus '{focus}' for @analyze mode")
    
    def _apply_filters(self, df, columns, where, rows):
        """Apply column, where, and row filtering to DataFrame."""
        # Convert to polars for consistent filtering
        is_pandas = isinstance(df, pd.DataFrame)
        if is_pandas:
            df_pl = pl.from_pandas(df)
        else:
            df_pl = df
        
        # Apply column filter
        if columns is not None:
            df_pl = df_pl.select(columns)
        
        # Apply where filter
        if where is not None:
            df_pl = df_pl.filter(pl.Expr.eval(where))
        
        # Apply row filter
        if rows is not None:
            indices = self._parse_row_ranges(rows, len(df_pl))
            df_pl = df_pl[indices]
        
        # Convert back to original type
        if is_pandas:
            return df_pl.to_pandas()
        else:
            return df_pl
    
    def _parse_row_ranges(self, rows: List[str], total_rows: int) -> List[int]:
        """Parse row range specifications into list of indices."""
        indices = []
        
        for row_spec in rows:
            if row_spec.startswith('first:'):
                n = int(row_spec.split(':')[1])
                indices.extend(range(min(n, total_rows)))
            elif row_spec.startswith('last:'):
                n = int(row_spec.split(':')[1])
                start = max(0, total_rows - n)
                indices.extend(range(start, total_rows))
            elif row_spec == 'last':
                indices.append(total_rows - 1)
            elif '-' in row_spec:
                start, end = map(int, row_spec.split('-'))
                indices.extend(range(start, min(end + 1, total_rows)))
            else:
                idx = int(row_spec)
                if idx < total_rows:
                    indices.append(idx)
        
        # Remove duplicates and sort
        return sorted(set(indices))
    
    def profile_dataframe(self, df) -> pd.DataFrame:
        """Compute statistical profiles for all columns."""
        # Convert to pandas for easier stats computation
        if isinstance(df, pl.DataFrame):
            df_pd = df.to_pandas()
        else:
            df_pd = df
        
        profiles = []
        
        for col in df_pd.columns:
            profile = {
                'column': col,
                'dtype': str(df_pd[col].dtype),
                'count': int(df_pd[col].count()),
                'missing': int(df_pd[col].isna().sum()),
                'missing_pct': round(df_pd[col].isna().sum() / len(df_pd) * 100, 1),
                'unique': int(df_pd[col].nunique()),
            }
            
            # Numeric columns
            if pd.api.types.is_numeric_dtype(df_pd[col]):
                profile['mean'] = float(df_pd[col].mean()) if not df_pd[col].isna().all() else None
                profile['std'] = float(df_pd[col].std()) if not df_pd[col].isna().all() else None
                profile['min'] = float(df_pd[col].min()) if not df_pd[col].isna().all() else None
                profile['max'] = float(df_pd[col].max()) if not df_pd[col].isna().all() else None
                profile['q25'] = float(df_pd[col].quantile(0.25)) if not df_pd[col].isna().all() else None
                profile['median'] = float(df_pd[col].median()) if not df_pd[col].isna().all() else None
                profile['q75'] = float(df_pd[col].quantile(0.75)) if not df_pd[col].isna().all() else None
                
                # Detect outliers using IQR method
                if not df_pd[col].isna().all():
                    q1 = df_pd[col].quantile(0.25)
                    q3 = df_pd[col].quantile(0.75)
                    iqr = q3 - q1
                    lower_bound = q1 - 1.5 * iqr
                    upper_bound = q3 + 1.5 * iqr
                    outliers = df_pd[col][(df_pd[col] < lower_bound) | (df_pd[col] > upper_bound)]
                    profile['outliers'] = int(len(outliers))
                else:
                    profile['outliers'] = 0
            else:
                profile['mean'] = None
                profile['std'] = None
                profile['min'] = None
                profile['max'] = None
                profile['q25'] = None
                profile['median'] = None
                profile['q75'] = None
                profile['outliers'] = None
            
            # Mode (most common value)
            if not df_pd[col].isna().all():
                mode_val = df_pd[col].mode()
                profile['mode'] = mode_val.iloc[0] if len(mode_val) > 0 else None
            else:
                profile['mode'] = None
            
            profiles.append(profile)
        
        return pd.DataFrame(profiles)
    
    def detect_outliers(self, df, columns) -> pd.DataFrame:
        """Detect outliers using IQR method."""
        # Convert to pandas
        if isinstance(df, pl.DataFrame):
            df_pd = df.to_pandas()
        else:
            df_pd = df
        
        # If columns not specified, use all numeric columns
        if columns is None:
            columns = df_pd.select_dtypes(include=['number']).columns.tolist()
        
        outlier_results = []
        
        for col in columns:
            if not pd.api.types.is_numeric_dtype(df_pd[col]):
                continue  # Skip non-numeric columns
            
            if df_pd[col].isna().all():
                continue  # Skip columns with all nulls
            
            # Calculate IQR
            q1 = df_pd[col].quantile(0.25)
            q3 = df_pd[col].quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            
            # Find outliers
            outlier_mask = (df_pd[col] < lower_bound) | (df_pd[col] > upper_bound)
            outliers = df_pd[col][outlier_mask]
            outlier_indices = outliers.index.tolist()
            outlier_values = outliers.tolist()
            
            if len(outliers) > 0:
                outlier_results.append({
                    'column': col,
                    'outlier_count': len(outliers),
                    'outlier_values': outlier_values[:10],  # Limit to first 10
                    'outlier_rows': outlier_indices[:10],  # Limit to first 10
                    'iqr': float(iqr),
                    'lower_bound': float(lower_bound),
                    'upper_bound': float(upper_bound)
                })
        
        return pd.DataFrame(outlier_results)
    
    def compute_correlations(self, df, columns) -> pd.DataFrame:
        """Compute correlation matrix using Pearson correlation coefficient."""
        # Convert to pandas
        if isinstance(df, pl.DataFrame):
            df_pd = df.to_pandas()
        else:
            df_pd = df
        
        # If columns not specified, use all numeric columns
        if columns is None:
            columns = df_pd.select_dtypes(include=['number']).columns.tolist()
        else:
            # Filter to only numeric columns
            columns = [col for col in columns if pd.api.types.is_numeric_dtype(df_pd[col])]
        
        if len(columns) == 0:
            raise ValueError("No numeric columns found for correlation analysis")
        
        # Compute correlation matrix
        corr_matrix = df_pd[columns].corr(method='pearson')
        
        return corr_matrix
    
    def detect_distributions(self, df, columns) -> pd.DataFrame:
        """Test columns against common distributions."""
        # Convert to pandas
        if isinstance(df, pl.DataFrame):
            df_pd = df.to_pandas()
        else:
            df_pd = df
        
        # If columns not specified, use all numeric columns
        if columns is None:
            columns = df_pd.select_dtypes(include=['number']).columns.tolist()
        
        try:
            from scipy import stats
        except ImportError:
            raise ImportError(
                "scipy is required for distribution detection. "
                "Install with: pip install scipy"
            )
        
        distribution_results = []
        
        for col in columns:
            if not pd.api.types.is_numeric_dtype(df_pd[col]):
                continue  # Skip non-numeric columns
            
            # Remove nulls
            data = df_pd[col].dropna()
            
            if len(data) < 3:
                continue  # Need at least 3 points for distribution testing
            
            # Test against common distributions
            distributions = {
                'normal': stats.norm,
                'uniform': stats.uniform,
                'exponential': stats.expon,
                'lognormal': stats.lognorm
            }
            
            best_fit = None
            best_p_value = 0
            
            for dist_name, dist_func in distributions.items():
                try:
                    # Fit distribution
                    params = dist_func.fit(data)
                    
                    # Kolmogorov-Smirnov test
                    ks_stat, p_value = stats.kstest(data, dist_name, args=params)
                    
                    if p_value > best_p_value:
                        best_p_value = p_value
                        best_fit = {
                            'column': col,
                            'distribution': dist_name,
                            'goodness_of_fit': float(1 - ks_stat),  # Higher is better
                            'p_value': float(p_value),
                            'parameters': {f'param_{i}': float(p) for i, p in enumerate(params)},
                            'rank': 0  # Will be set later
                        }
                except Exception:
                    continue  # Skip if fitting fails
            
            if best_fit is not None:
                distribution_results.append(best_fit)
        
        # Rank by goodness of fit
        distribution_results.sort(key=lambda x: x['goodness_of_fit'], reverse=True)
        for i, result in enumerate(distribution_results):
            result['rank'] = i + 1
        
        return pd.DataFrame(distribution_results)


class LineageMode:
    """Implements @lineage mode for transformation explanation."""
    
    def execute(self, df, columns, where, rows, trace, focus):
        """Execute lineage analysis based on parameters."""
        # Load lineage metadata
        lineage = self.load_lineage_metadata(df)
        
        # Route to appropriate analysis based on parameters
        if trace is not None:
            # Cell tracing (Task 7.3)
            return self.cell_trace(df, lineage, trace)
        elif focus == 'nulls':
            # Null analysis (Task 9.1)
            return self.analyze_nulls(df, lineage)
        elif focus == 'excluded':
            # Excluded rows analysis (Task 9.3)
            return self.analyze_excluded(df, lineage)
        elif focus and focus.startswith('source:'):
            # Source analysis (Task 9.5)
            source_name = focus.split(':', 1)[1]
            return self.analyze_source(df, lineage, source_name)
        else:
            # Global explanation (Task 5.2)
            return self.global_explanation(df, lineage, columns, where, rows)
    
    def load_lineage_metadata(self, df: Union[pd.DataFrame, pl.DataFrame]) -> Dict:
        """
        Load lineage metadata from DataFrame.
        
        For pandas: extracts from DataFrame.attrs['lineage']
        For Polars: extracts from global registry
        
        Args:
            df: DataFrame to extract lineage from
            
        Returns:
            Dict: Lineage metadata structure
            
        Raises:
            ValueError: If lineage metadata is not found
        """
        from .lineage_tracker import _get_lineage
        
        lineage = _get_lineage(df)
        
        if lineage is None:
            raise ValueError(
                "No lineage metadata found. Lineage tracking must be enabled by adding "
                "lineage=True to add.to(), add.transform(), or add.synthetic() calls.\n\n"
                "Example:\n"
                "  df = add.transform('@calc', df, strategy={'total': 'price * qty'}, lineage=True)\n"
                "  result = add.scan('@lineage', df)"
            )
        
        return lineage
    
    def global_explanation(
        self, 
        df: Union[pd.DataFrame, pl.DataFrame],
        lineage: Dict,
        columns: Optional[List[str]],
        where: Optional[str],
        rows: Optional[List[str]]
    ) -> str:
        """
        Generate overview of all transformations applied to DataFrame.
        
        Task 5.2 implementation - displays operation sequence with:
        - Step numbers
        - Operation type and timestamp
        - Row count changes
        - Columns added or modified
        - Data quality warnings (nulls, excluded rows)
        
        Applies column, where, and rows filtering.
        
        Args:
            df: DataFrame being analyzed
            lineage: Lineage metadata
            columns: Optional column filter
            where: Optional condition filter
            rows: Optional row range filter
            
        Returns:
            str: Formatted lineage report
        """
        # Apply filters if specified
        filtered_df = self._apply_filters(df, columns, where, rows)
        
        # Extract lineage components
        operations = lineage.get('operations', [])
        column_sources = lineage.get('column_sources', {})
        metadata = lineage.get('metadata', {})
        
        # Build report using PrettyPrinter (Task 5.3)
        printer = PrettyPrinter()
        
        # Header section
        report = printer.header("LINEAGE REPORT")
        report += "\n"
        
        # DataFrame info
        row_count = len(filtered_df)
        col_count = len(filtered_df.columns)
        report += printer.info(f"DataFrame: {row_count} rows × {col_count} columns")
        report += printer.info(f"Operations: {len(operations)} transformation{'s' if len(operations) != 1 else ''} applied")
        
        if metadata.get('fresh_start'):
            report += printer.info("Lineage started mid-pipeline (earlier operations not tracked)")
        
        report += "\n"
        
        # Filter operations by columns if specified
        relevant_operations = self._filter_operations_by_columns(operations, columns) if columns else operations
        
        # Operation sequence
        for idx, operation in enumerate(relevant_operations, 1):
            report += self._format_operation(printer, idx, operation, columns)
            report += "\n"
        
        # Dependency graph section (Task 8.3)
        report += self._format_dependency_graph(printer, column_sources, columns)
        
        # Summary section
        if operations:
            first_op = operations[0]
            last_op = operations[-1]
            rows_before = first_op.get('rows_before', 0)
            rows_after = last_op.get('rows_after', 0)
            
            report += printer.separator()
            report += printer.info(f"Data Flow: {rows_before} rows → {rows_after} rows")
            
            if rows_after < rows_before:
                excluded = rows_before - rows_after
                pct = (excluded / rows_before * 100) if rows_before > 0 else 0
                report += printer.warning(f"{excluded} rows ({pct:.1f}%) removed during transformations")
                report += printer.info("Use focus='excluded' to see why rows were removed")
        
        report += printer.footer()
        
        return report
    
    def cell_trace(
        self,
        df: Union[pd.DataFrame, pl.DataFrame],
        lineage: Dict,
        trace: List[int]
    ) -> str:
        """
        Trace complete transformation history for a specific cell.
        
        Task 7.3 implementation - traces a cell value back through all transformations
        to its original source, showing:
        - Original source value
        - Each transformation step
        - Formulas or operations used
        - Source tables that contributed
        - Exclusion information if applicable
        
        For aggregated rows, returns the GROUP of source rows that contributed.
        
        Args:
            df: DataFrame being analyzed
            lineage: Lineage metadata
            trace: [column_index, row_index] to trace
            
        Returns:
            str: Formatted cell trace report
            
        Raises:
            ValueError: If trace format is invalid or indices are out of bounds
        """
        # Validate trace parameter
        if not isinstance(trace, (list, tuple)) or len(trace) != 2:
            raise ValueError(
                f"trace parameter must be a list or tuple of exactly 2 integers [column_index, row_index], "
                f"got {trace}"
            )
        
        column_index, row_index = trace
        
        # Validate indices
        if isinstance(df, pd.DataFrame):
            columns = df.columns.tolist()
        else:  # Polars
            columns = df.columns
        
        if not (0 <= column_index < len(columns)):
            raise ValueError(
                f"column_index {column_index} is out of bounds. "
                f"Valid range: 0-{len(columns)-1}"
            )
        
        if not (0 <= row_index < len(df)):
            raise ValueError(
                f"row_index {row_index} is out of bounds. "
                f"Valid range: 0-{len(df)-1}"
            )
        
        column_name = columns[column_index]
        
        # Get current cell value
        if isinstance(df, pd.DataFrame):
            current_value = df.iloc[row_index, column_index]
        else:  # Polars
            current_value = df[row_index, column_index]
        
        # Trace row back to origin using row_mapping
        from .lineage_tracker import RowMapper
        
        mapper = RowMapper()
        row_mapping = lineage.get('row_mapping', {})
        
        try:
            original_rows = mapper.trace_row_origin(row_index, row_mapping)
        except KeyError as e:
            raise ValueError(f"Failed to trace row: {e}")
        
        # Build trace report
        printer = PrettyPrinter()
        
        report = printer.header("CELL TRACE")
        report += "\n"
        
        # Cell identification
        report += printer.info(f"Cell: [{column_name}][row {row_index}]")
        report += printer.info(f"Current value: {current_value}")
        report += "\n"
        
        # Original source information
        if len(original_rows) == 1:
            report += printer.section_header("ORIGINAL SOURCE")
            report += printer.item(f"Original row index: {original_rows[0]}")
        else:
            # Aggregated row - multiple source rows
            report += printer.section_header(f"ORIGINAL SOURCE (AGGREGATED FROM {len(original_rows)} ROWS)")
            if len(original_rows) <= 10:
                report += printer.item(f"Original row indices: {', '.join(map(str, original_rows))}")
            else:
                sample = original_rows[:10]
                report += printer.item(f"Original row indices (sample): {', '.join(map(str, sample))}...")
                report += printer.info(f"Total: {len(original_rows)} rows (showing first 10)")
        
        report += "\n"
        
        # Trace through operations
        operations = lineage.get('operations', [])
        column_sources = lineage.get('column_sources', {})
        
        # Check if column exists in sources
        if column_name not in column_sources:
            report += printer.warning(f"Column '{column_name}' not found in lineage metadata")
            report += printer.footer()
            return report
        
        col_source = column_sources[column_name]
        source_type = col_source.get('source', 'unknown')
        
        # Show column source
        report += printer.section_header("COLUMN LINEAGE")
        
        if source_type == 'original':
            report += printer.item(f"Source: Original column (present before lineage tracking)")
        
        elif source_type == 'brought':
            source_table = col_source.get('source_table', 'unknown')
            source_column = col_source.get('source_column', column_name)
            operation_idx = col_source.get('operation', -1)
            
            report += printer.item(f"Source: Brought from {source_table}")
            report += printer.item(f"Source column: {source_column}")
            
            if operation_idx >= 0 and operation_idx < len(operations):
                op = operations[operation_idx]
                report += printer.item(f"Brought in: Operation {operation_idx + 1} ({op.get('type', 'unknown')})")
        
        elif source_type == 'calculated':
            formula = col_source.get('formula', 'unknown')
            dependencies = col_source.get('dependencies', [])
            operation_idx = col_source.get('operation', -1)
            
            report += printer.item(f"Source: Calculated column")
            report += printer.item(f"Formula: {column_name} = {formula}")
            
            if dependencies:
                report += printer.item(f"Depends on: {', '.join(dependencies)}")
            
            if operation_idx >= 0 and operation_idx < len(operations):
                op = operations[operation_idx]
                report += printer.item(f"Created in: Operation {operation_idx + 1} ({op.get('type', 'unknown')})")
        
        elif source_type == 'aggregated':
            aggregation = col_source.get('aggregation', 'unknown')
            source_column = col_source.get('source_column', None)
            operation_idx = col_source.get('operation', -1)
            
            report += printer.item(f"Source: Aggregated column")
            report += printer.item(f"Aggregation: {aggregation}")
            
            if source_column:
                report += printer.item(f"Source column: {source_column}")
            
            if operation_idx >= 0 and operation_idx < len(operations):
                op = operations[operation_idx]
                report += printer.item(f"Created in: Operation {operation_idx + 1} ({op.get('type', 'unknown')})")
        
        else:
            report += printer.item(f"Source: {source_type}")
        
        report += "\n"
        
        # Show transformation steps
        if operations:
            report += printer.section_header("TRANSFORMATION HISTORY")
            
            for idx, operation in enumerate(operations, 1):
                op_type = operation.get('type', 'unknown')
                params = operation.get('params', {})
                mode = params.get('mode', '')
                
                # Check if this operation affected the column
                columns_added = operation.get('columns_added', [])
                columns_modified = operation.get('columns_modified', [])
                
                if column_name in columns_added or column_name in columns_modified:
                    if mode:
                        report += printer.item(f"Step {idx}: {op_type} {mode}")
                    else:
                        report += printer.item(f"Step {idx}: {op_type}")
                    
                    # Show operation details
                    if mode == '@calc' and column_name in columns_added:
                        strategy = params.get('strategy', {})
                        if column_name in strategy:
                            report += printer.item(f"  Formula: {column_name} = {strategy[column_name]}")
                    
                    elif mode == '@filter':
                        condition = params.get('where', 'unknown')
                        report += printer.item(f"  Condition: {condition}")
                        
                        # Check if current row was excluded
                        excluded_rows = lineage.get('excluded_rows', [])
                        for excluded in excluded_rows:
                            if excluded.get('excluded_in_operation') == idx - 1:
                                if excluded.get('original_index') in original_rows:
                                    reason = excluded.get('reason', 'unknown')
                                    report += printer.warning(f"  Row excluded: {reason}")
                    
                    elif mode == '@aggregate':
                        by = params.get('by', 'unknown')
                        strategy = params.get('strategy', {})
                        report += printer.item(f"  Grouped by: {by}")
                        if column_name in strategy:
                            report += printer.item(f"  Aggregation: {strategy[column_name]}")
        
        report += "\n"
        report += printer.footer()
        
        return report
    def analyze_nulls(
        self,
        df: Union[pd.DataFrame, pl.DataFrame],
        lineage: Dict
    ) -> str:
        """
        Analyze null value root causes.

        Task 9.1 implementation - identifies and explains null values:
        - Identifies all columns containing null values
        - Calculates null count and percentage for each column
        - Traces nulls back to root cause (missing source data vs. calculations)
        - Identifies source table and column for missing source data
        - Identifies which input values were null for calculation nulls

        Args:
            df: DataFrame being analyzed
            lineage: Lineage metadata

        Returns:
            str: Formatted null analysis report
        """
        printer = PrettyPrinter()

        # Convert to pandas for easier null analysis
        if isinstance(df, pl.DataFrame):
            df_pd = df.to_pandas()
        else:
            df_pd = df

        # Build report
        report = printer.header("NULL VALUE ANALYSIS")
        report += "\n"

        # Find columns with nulls
        null_columns = []
        for col in df_pd.columns:
            null_count = df_pd[col].isna().sum()
            if null_count > 0:
                null_pct = (null_count / len(df_pd) * 100)
                null_columns.append({
                    'column': col,
                    'null_count': null_count,
                    'null_pct': null_pct
                })

        if not null_columns:
            report += printer.info("No null values found in DataFrame")
            report += printer.footer()
            return report

        # Summary
        total_nulls = sum(col['null_count'] for col in null_columns)
        total_cells = len(df_pd) * len(df_pd.columns)
        overall_pct = (total_nulls / total_cells * 100)

        report += printer.info(f"Found {len(null_columns)} column{'s' if len(null_columns) != 1 else ''} with null values")
        report += printer.info(f"Total nulls: {total_nulls} ({overall_pct:.1f}% of all cells)")
        report += "\n"

        # Analyze each column with nulls
        column_sources = lineage.get('column_sources', {})

        for col_info in null_columns:
            col_name = col_info['column']
            null_count = col_info['null_count']
            null_pct = col_info['null_pct']

            report += printer.section_header(f"COLUMN: {col_name}")
            report += printer.item(f"Null count: {null_count} ({null_pct:.1f}%)")

            # Get column source information
            if col_name not in column_sources:
                report += printer.warning("Column not found in lineage metadata")
                report += "\n"
                continue

            col_source = column_sources[col_name]
            source_type = col_source.get('source', 'unknown')

            # Analyze based on source type
            if source_type == 'original':
                # Original column - nulls were present before lineage tracking
                report += printer.item("Root cause: Missing data in original source")
                source_table = col_source.get('source_table', 'unknown')
                if source_table != 'unknown':
                    report += printer.item(f"Source table: {source_table}")
                else:
                    report += printer.info("Lineage started mid-pipeline - original source unknown")

            elif source_type == 'brought':
                # Brought from another table
                source_table = col_source.get('source_table', 'unknown')
                source_column = col_source.get('source_column', col_name)
                report += printer.item(f"Root cause: Missing data in source table '{source_table}'")
                report += printer.item(f"Source column: {source_column}")

                # Check if nulls came from unmatched rows
                operation_idx = col_source.get('operation', -1)
                if operation_idx >= 0:
                    operations = lineage.get('operations', [])
                    if operation_idx < len(operations):
                        op = operations[operation_idx]
                        params = op.get('params', {})
                        unmatched = params.get('unmatched_rows', 0)
                        if unmatched > 0:
                            report += printer.warning(f"{unmatched} rows had no match in source table")
                            report += printer.info("These unmatched rows will have null values")

            elif source_type == 'calculated':
                # Calculated column - nulls propagated from dependencies
                formula = col_source.get('formula', 'unknown')
                dependencies = col_source.get('dependencies', [])

                report += printer.item("Root cause: Null propagation through calculation")
                report += printer.item(f"Formula: {col_name} = {formula}")

                if dependencies:
                    report += printer.item(f"Depends on: {', '.join(dependencies)}")

                    # Check which dependencies have nulls
                    null_deps = []
                    for dep in dependencies:
                        if dep in df_pd.columns:
                            dep_nulls = df_pd[dep].isna().sum()
                            if dep_nulls > 0:
                                null_deps.append(f"{dep} ({dep_nulls} nulls)")

                    if null_deps:
                        report += printer.warning(f"Input columns with nulls: {', '.join(null_deps)}")
                        report += printer.info("Nulls in input columns propagate to calculated result")

                    # Trace dependencies to source
                    from .lineage_tracker import DependencyTracker
                    tracker = DependencyTracker()
                    graph = tracker.build_dependency_graph(column_sources)
                    try:
                        sources = tracker.trace_dependencies(col_name, graph)
                        report += printer.item(f"Traces to source columns: {', '.join(sources)}")
                    except ValueError:
                        pass  # Circular dependency - already handled elsewhere

            elif source_type == 'aggregated':
                # Aggregated column
                aggregation = col_source.get('aggregation', 'unknown')
                source_column = col_source.get('source_column', None)

                report += printer.item(f"Root cause: Aggregation of column with nulls")
                report += printer.item(f"Aggregation: {aggregation}")

                if source_column:
                    report += printer.item(f"Source column: {source_column}")

                    # Note: We can't check the pre-aggregation DataFrame for nulls
                    # because we only have the aggregated result
                    report += printer.info("Nulls in source column affect aggregation result")

            else:
                report += printer.item(f"Source type: {source_type}")

            report += "\n"

        # Recommendations section
        report += printer.separator()
        report += printer.section_header("RECOMMENDATIONS")
        report += printer.item("Use add.transform('@deduce', ...) to fill missing values")
        report += printer.item("Use add.transform('@filter', where='column.is_not_null()') to remove rows with nulls")
        report += printer.item("Check source data quality to prevent nulls at the source")

        report += printer.footer()

        return report
    def analyze_excluded(
        self,
        df: Union[pd.DataFrame, pl.DataFrame],
        lineage: Dict
    ) -> str:
        """
        Analyze rows that were filtered out.

        Task 9.3 implementation - identifies and explains excluded rows:
        - Identifies all rows removed by filter operations
        - Calculates total excluded count and percentage
        - Groups excluded rows by the operation that removed them
        - Shows filter condition that caused exclusion
        - Breaks down exclusions by categorical variables when present

        Args:
            df: DataFrame being analyzed
            lineage: Lineage metadata

        Returns:
            str: Formatted exclusion analysis report
        """
        printer = PrettyPrinter()

        # Build report
        report = printer.header("EXCLUDED ROWS ANALYSIS")
        report += "\n"

        # Get operations and excluded rows
        operations = lineage.get('operations', [])
        excluded_rows = lineage.get('excluded_rows', [])

        if not excluded_rows:
            report += printer.info("No rows were excluded by filter operations")
            report += printer.footer()
            return report

        # Calculate totals
        total_excluded = len(excluded_rows)

        # Get original row count from first operation
        original_rows = operations[0].get('rows_before', 0) if operations else 0
        current_rows = len(df)

        if original_rows > 0:
            excluded_pct = (total_excluded / original_rows * 100)
            kept_pct = (current_rows / original_rows * 100)
        else:
            excluded_pct = 0
            kept_pct = 100

        # Summary
        report += printer.info(f"Original rows: {original_rows}")
        report += printer.info(f"Current rows: {current_rows} ({kept_pct:.1f}% kept)")
        report += printer.warning(f"Excluded rows: {total_excluded} ({excluded_pct:.1f}% removed)")
        report += "\n"

        # Group exclusions by operation
        exclusions_by_op = {}
        for excluded in excluded_rows:
            op_idx = excluded.get('excluded_in_operation', -1)
            if op_idx not in exclusions_by_op:
                exclusions_by_op[op_idx] = []
            exclusions_by_op[op_idx].append(excluded)

        # Analyze each operation that excluded rows
        for op_idx in sorted(exclusions_by_op.keys()):
            if op_idx < 0 or op_idx >= len(operations):
                continue

            operation = operations[op_idx]
            op_type = operation.get('type', 'unknown')
            params = operation.get('params', {})
            mode = params.get('mode', '')
            timestamp = operation.get('timestamp', 'unknown')

            # Format timestamp
            if 'T' in timestamp:
                timestamp = timestamp.split('T')[1].split('.')[0]

            excluded_in_op = exclusions_by_op[op_idx]
            excluded_count = len(excluded_in_op)

            report += printer.section_header(f"OPERATION {op_idx + 1}: {op_type} {mode} ({timestamp})")
            report += printer.warning(f"Excluded {excluded_count} row{'s' if excluded_count != 1 else ''}")

            # Show filter condition
            if mode == '@filter':
                condition = params.get('where', 'unknown')
                report += printer.item(f"Filter condition: {condition}")

                # Show sample of excluded row indices
                sample_size = min(10, excluded_count)
                sample_indices = [exc.get('original_index', -1) for exc in excluded_in_op[:sample_size]]
                if sample_size < excluded_count:
                    report += printer.item(f"Sample excluded rows: {', '.join(map(str, sample_indices))}... ({excluded_count} total)")
                else:
                    report += printer.item(f"Excluded rows: {', '.join(map(str, sample_indices))}")

                # Show exclusion reasons if available
                reasons = {}
                for exc in excluded_in_op:
                    reason = exc.get('reason', 'unknown')
                    reasons[reason] = reasons.get(reason, 0) + 1

                if len(reasons) > 1 or (len(reasons) == 1 and 'unknown' not in reasons):
                    report += printer.item("Exclusion breakdown:")
                    for reason, count in sorted(reasons.items(), key=lambda x: x[1], reverse=True):
                        pct = (count / excluded_count * 100)
                        report += printer.item(f"  {reason}: {count} rows ({pct:.1f}%)")

            report += "\n"

        # Recommendations section
        report += printer.separator()
        report += printer.section_header("RECOMMENDATIONS")
        report += printer.item("Review filter conditions to ensure they're not too restrictive")
        report += printer.item("Check if excluded rows contain important data")
        report += printer.item("Consider using add.transform('@deduce', ...) before filtering to reduce exclusions")
        report += printer.item("Use add.scan('@lineage', trace=[col, row]) to trace specific excluded rows")

        report += printer.footer()

        return report
    def analyze_source(
        self,
        df: Union[pd.DataFrame, pl.DataFrame],
        lineage: Dict,
        source_name: str
    ) -> str:
        """
        Analyze data from a specific source table.

        Task 9.5 implementation - analyzes columns from a specific source:
        - Lists all columns brought from the specified source
        - Shows matching statistics (matched rows, unmatched rows)
        - Shows data quality metrics for columns from that source

        Args:
            df: DataFrame being analyzed
            lineage: Lineage metadata
            source_name: Name of the source table to analyze

        Returns:
            str: Formatted source analysis report
        """
        printer = PrettyPrinter()

        # Convert to pandas for easier analysis
        if isinstance(df, pl.DataFrame):
            df_pd = df.to_pandas()
        else:
            df_pd = df

        # Build report
        report = printer.header(f"SOURCE ANALYSIS: {source_name}")
        report += "\n"

        # Find columns from this source
        column_sources = lineage.get('column_sources', {})
        source_columns = []

        for col_name, col_info in column_sources.items():
            source_type = col_info.get('source', '')
            source_table = col_info.get('source_table', '')

            if source_type == 'brought' and source_table == source_name:
                source_columns.append({
                    'name': col_name,
                    'source_column': col_info.get('source_column', col_name),
                    'operation': col_info.get('operation', -1)
                })

        if not source_columns:
            report += printer.warning(f"No columns found from source '{source_name}'")
            report += printer.info("Available sources:")

            # List available sources
            sources = set()
            for col_info in column_sources.values():
                if col_info.get('source') == 'brought':
                    source_table = col_info.get('source_table', '')
                    if source_table:
                        sources.add(source_table)

            if sources:
                for source in sorted(sources):
                    report += printer.item(f"  {source}")
            else:
                report += printer.item("  (none - no columns brought from other tables)")

            report += printer.footer()
            return report

        # Summary
        report += printer.info(f"Found {len(source_columns)} column{'s' if len(source_columns) != 1 else ''} from '{source_name}'")
        report += "\n"

        # Find the operation that brought these columns
        operations = lineage.get('operations', [])
        operation_idx = source_columns[0]['operation']

        if operation_idx >= 0 and operation_idx < len(operations):
            operation = operations[operation_idx]
            params = operation.get('params', {})
            timestamp = operation.get('timestamp', 'unknown')

            # Format timestamp
            if 'T' in timestamp:
                timestamp = timestamp.split('T')[1].split('.')[0]

            report += printer.section_header(f"JOIN OPERATION (Operation {operation_idx + 1}, {timestamp})")

            # Show join details
            matching_key = params.get('against', 'unknown')
            join_type = params.get('join_type', 'lookup')
            matched_rows = params.get('matched_rows', 0)
            unmatched_rows = params.get('unmatched_rows', 0)
            total_rows = matched_rows + unmatched_rows

            report += printer.item(f"Join type: {join_type}")
            report += printer.item(f"Matching key: {matching_key}")

            if total_rows > 0:
                matched_pct = (matched_rows / total_rows * 100)
                unmatched_pct = (unmatched_rows / total_rows * 100)
                report += printer.item(f"Matched rows: {matched_rows} ({matched_pct:.1f}%)")

                if unmatched_rows > 0:
                    report += printer.warning(f"Unmatched rows: {unmatched_rows} ({unmatched_pct:.1f}%)")
                    report += printer.info("Unmatched rows will have null values for brought columns")
                else:
                    report += printer.info("All rows matched successfully")

            report += "\n"

        # List columns
        report += printer.section_header("COLUMNS FROM SOURCE")
        for col_info in source_columns:
            col_name = col_info['name']
            source_col = col_info['source_column']

            if col_name == source_col:
                report += printer.item(f"{col_name}")
            else:
                report += printer.item(f"{col_name} (from {source_col})")

        report += "\n"

        # Data quality metrics for each column
        report += printer.section_header("DATA QUALITY METRICS")

        for col_info in source_columns:
            col_name = col_info['name']

            if col_name not in df_pd.columns:
                continue

            col_data = df_pd[col_name]

            # Calculate metrics
            total_count = len(col_data)
            null_count = col_data.isna().sum()
            non_null_count = total_count - null_count
            null_pct = (null_count / total_count * 100) if total_count > 0 else 0
            unique_count = col_data.nunique()

            report += printer.item(f"{col_name}:")
            report += printer.item(f"  Total values: {total_count}")
            report += printer.item(f"  Non-null: {non_null_count} ({100 - null_pct:.1f}%)")

            if null_count > 0:
                report += printer.warning(f"  Null values: {null_count} ({null_pct:.1f}%)")

            report += printer.item(f"  Unique values: {unique_count}")

            # Type-specific metrics
            if pd.api.types.is_numeric_dtype(col_data):
                if not col_data.isna().all():
                    mean_val = col_data.mean()
                    std_val = col_data.std()
                    min_val = col_data.min()
                    max_val = col_data.max()

                    report += printer.item(f"  Range: {min_val:.2f} to {max_val:.2f}")
                    report += printer.item(f"  Mean: {mean_val:.2f} (±{std_val:.2f})")

            report += "\n"

        # Recommendations
        report += printer.separator()
        report += printer.section_header("RECOMMENDATIONS")

        if any(df_pd[col['name']].isna().sum() > 0 for col in source_columns if col['name'] in df_pd.columns):
            report += printer.item("Consider using add.transform('@deduce', ...) to fill null values")

        report += printer.item(f"Verify data quality in source table '{source_name}'")
        report += printer.item("Check join conditions if unmatched rows are unexpected")

        report += printer.footer()

        return report



    
    def _apply_filters(
        self,
        df: Union[pd.DataFrame, pl.DataFrame],
        columns: Optional[List[str]],
        where: Optional[str],
        rows: Optional[List[str]]
    ) -> Union[pd.DataFrame, pl.DataFrame]:
        """
        Apply column, where, and rows filters to DataFrame.
        
        Args:
            df: DataFrame to filter
            columns: Column names to select
            where: Filter condition
            rows: Row ranges to select
            
        Returns:
            Filtered DataFrame
        """
        result = df
        
        # Apply column filter
        if columns:
            if isinstance(result, pd.DataFrame):
                result = result[columns]
            else:  # Polars
                result = result.select(columns)
        
        # Apply where filter
        if where:
            # Use the same filter logic as AnalyzeMode
            if isinstance(result, pd.DataFrame):
                result = result.query(where)
            else:  # Polars
                # Convert pandas-style query to Polars expression
                # For now, use simple eval (TODO: improve in future)
                result = result.filter(pl.sql_expr(where))
        
        # Apply rows filter
        if rows:
            indices = self._parse_row_ranges(rows, len(result))
            if isinstance(result, pd.DataFrame):
                result = result.iloc[indices]
            else:  # Polars
                result = result[indices]
        
        return result
    
    def _parse_row_ranges(self, rows: List[str], total_rows: int) -> List[int]:
        """
        Parse row range specifications into list of indices.
        
        Supports:
        - 'first:N' - first N rows
        - 'last:N' - last N rows
        - 'M-N' - rows M through N inclusive
        - 'N' - single row N
        
        Args:
            rows: List of row range specifications
            total_rows: Total number of rows in DataFrame
            
        Returns:
            List of row indices
        """
        indices = []
        
        for spec in rows:
            if spec.startswith('first:'):
                n = int(spec.split(':')[1])
                indices.extend(range(min(n, total_rows)))
            elif spec.startswith('last:'):
                n = int(spec.split(':')[1])
                start = max(0, total_rows - n)
                indices.extend(range(start, total_rows))
            elif '-' in spec:
                start, end = map(int, spec.split('-'))
                indices.extend(range(start, min(end + 1, total_rows)))
            else:
                # Single row
                idx = int(spec)
                if 0 <= idx < total_rows:
                    indices.append(idx)
        
        # Remove duplicates and sort
        return sorted(set(indices))
    
    def _filter_operations_by_columns(self, operations: List[Dict], columns: List[str]) -> List[Dict]:
        """
        Filter operations to only those that affected specified columns.
        
        Args:
            operations: List of operation metadata
            columns: Column names to filter by
            
        Returns:
            List of operations that affected the specified columns
        """
        relevant_ops = []
        
        for op in operations:
            # Check if operation affected any of the specified columns
            columns_added = op.get('columns_added', [])
            columns_modified = op.get('columns_modified', [])
            
            if any(col in columns for col in columns_added + columns_modified):
                relevant_ops.append(op)
            # Also include operations that brought columns (add.to)
            elif op.get('type') == 'add.to':
                bring = op.get('params', {}).get('bring', [])
                if any(col in columns for col in bring):
                    relevant_ops.append(op)
        
        return relevant_ops if relevant_ops else operations
    def _format_dependency_graph(
        self,
        printer: 'PrettyPrinter',
        column_sources: Dict[str, Dict],
        columns: Optional[List[str]]
    ) -> str:
        """
        Format dependency graph section showing column dependencies.

        Task 8.3 implementation - displays:
        - Which columns depend on which other columns
        - Dependency chains traced to source columns
        - Circular dependency warnings if detected

        Args:
            printer: PrettyPrinter instance
            column_sources: Column source metadata
            columns: Optional column filter

        Returns:
            Formatted dependency graph string
        """
        from .lineage_tracker import DependencyTracker

        tracker = DependencyTracker()

        # Build dependency graph
        graph = tracker.build_dependency_graph(column_sources)

        # Filter to specified columns if provided
        if columns:
            graph = {col: deps for col, deps in graph.items() if col in columns}

        # Check if there are any calculated columns with dependencies
        has_dependencies = any(deps for deps in graph.values())

        if not has_dependencies:
            # No dependencies to show
            return ""

        report = printer.separator()
        report += printer.section_header("COLUMN DEPENDENCIES")

        # Detect circular dependencies first
        circular_deps = tracker.detect_circular_dependencies(graph)
        if circular_deps:
            report += printer.warning("Circular dependencies detected!")
            for cycle in circular_deps:
                cycle_str = ' → '.join(cycle)
                report += printer.warning(f"  {cycle_str}")
            report += "\n"

        # Show dependencies for each column
        for col_name in sorted(graph.keys()):
            dependencies = graph[col_name]

            if not dependencies:
                # Source column - no dependencies
                continue

            # Get column source info
            col_info = column_sources.get(col_name, {})
            source_type = col_info.get('source', 'unknown')

            # Format based on source type
            if source_type == 'calculated':
                formula = col_info.get('formula', 'unknown')
                report += printer.item(f"{col_name} = {formula}")
                report += printer.item(f"  Depends on: {', '.join(dependencies)}")

                # Trace to source columns
                try:
                    sources = tracker.trace_dependencies(col_name, graph)
                    if sources != dependencies:
                        # Show ultimate sources if different from direct dependencies
                        report += printer.item(f"  Traces to: {', '.join(sources)}")
                except ValueError as e:
                    # Circular dependency
                    report += printer.warning(f"  {str(e)}")

            elif source_type == 'aggregated':
                aggregation = col_info.get('aggregation', 'unknown')
                source_column = col_info.get('source_column', None)

                if source_column:
                    report += printer.item(f"{col_name} = {aggregation}({source_column})")
                else:
                    report += printer.item(f"{col_name} = {aggregation}()")

            else:
                # Other types with dependencies
                report += printer.item(f"{col_name} depends on: {', '.join(dependencies)}")

        return report

    
    def _format_operation(self, printer: 'PrettyPrinter', idx: int, operation: Dict, columns: Optional[List[str]]) -> str:
        """
        Format a single operation for display.
        
        Args:
            printer: PrettyPrinter instance
            idx: Operation number (1-indexed)
            operation: Operation metadata
            columns: Optional column filter
            
        Returns:
            Formatted operation string
        """
        op_type = operation.get('type', 'unknown')
        timestamp = operation.get('timestamp', 'unknown')
        params = operation.get('params', {})
        rows_before = operation.get('rows_before', 0)
        rows_after = operation.get('rows_after', 0)
        columns_added = operation.get('columns_added', [])
        columns_modified = operation.get('columns_modified', [])
        warnings = operation.get('warnings', [])
        
        # Format timestamp (remove microseconds for readability)
        if 'T' in timestamp:
            timestamp = timestamp.split('T')[1].split('.')[0]
        
        # Operation header
        mode = params.get('mode', '')
        if mode:
            title = f"OPERATION {idx}: {op_type} {mode} ({timestamp})"
        else:
            title = f"OPERATION {idx}: {op_type} ({timestamp})"
        
        result = printer.section_header(title)
        
        # Operation-specific details
        if op_type == 'add.to':
            bring = params.get('bring', [])
            bring_from = params.get('bring_from', 'unknown')
            against = params.get('against', 'unknown')
            matched = operation.get('matched_rows', 0)
            unmatched = operation.get('unmatched_rows', 0)
            total = matched + unmatched
            
            # Filter columns if specified
            if columns:
                bring = [col for col in bring if col in columns]
            
            if bring:
                result += printer.item(f"Brought: {', '.join(bring)} from {bring_from}")
            result += printer.item(f"Matched: {matched} rows ({matched/total*100:.1f}%)" if total > 0 else "Matched: 0 rows")
            if unmatched > 0:
                result += printer.warning(f"Unmatched: {unmatched} rows ({unmatched/total*100:.1f}%)")
        
        elif op_type == 'add.transform':
            if mode == '@calc':
                strategy = params.get('strategy', {})
                # Filter columns if specified
                if columns:
                    strategy = {k: v for k, v in strategy.items() if k in columns}
                
                if strategy:
                    for col, formula in strategy.items():
                        result += printer.item(f"Formula: {col} = {formula}")
            
            elif mode == '@filter':
                condition = params.get('where', 'unknown')
                excluded = rows_before - rows_after
                kept_pct = (rows_after / rows_before * 100) if rows_before > 0 else 0
                excluded_pct = (excluded / rows_before * 100) if rows_before > 0 else 0
                
                result += printer.item(f"Condition: {condition}")
                result += printer.item(f"Kept: {rows_after} rows ({kept_pct:.1f}%)")
                if excluded > 0:
                    result += printer.warning(f"Excluded: {excluded} rows ({excluded_pct:.1f}%)")
            
            elif mode == '@aggregate':
                by = params.get('by', 'unknown')
                strategy = params.get('strategy', {})
                groups = rows_after
                
                result += printer.item(f"Grouped by: {by}")
                # Filter columns if specified
                if columns:
                    strategy = {k: v for k, v in strategy.items() if k in columns}
                
                if strategy:
                    for col, agg_func in strategy.items():
                        result += printer.item(f"Aggregated: {col} ({agg_func})")
                result += printer.item(f"Result: {groups} group{'s' if groups != 1 else ''}")
            
            elif mode == '@sort':
                by = params.get('by', 'unknown')
                descending = params.get('descending', False)
                order = 'descending' if descending else 'ascending'
                result += printer.item(f"Sorted by: {by} ({order})")
            
            elif mode == '@deduce':
                method = params.get('method', 'unknown')
                filled = operation.get('filled_count', 0)
                result += printer.item(f"Imputation method: {method}")
                if filled > 0:
                    result += printer.info(f"Filled {filled} missing values")
        
        elif op_type == 'add.synthetic':
            if mode == '@new':
                row_count = params.get('row_count', 0)
                result += printer.item(f"Generated: {row_count} synthetic rows")
            elif mode == '@augment':
                synthetic_count = rows_after - rows_before
                result += printer.item(f"Augmented: {synthetic_count} synthetic rows added")
        
        # Show columns added/modified
        if columns_added:
            # Filter if specified
            if columns:
                columns_added = [col for col in columns_added if col in columns]
            if columns_added:
                result += printer.item(f"Created: {', '.join(columns_added)}")
        
        if columns_modified:
            # Filter if specified
            if columns:
                columns_modified = [col for col in columns_modified if col in columns]
            if columns_modified:
                result += printer.item(f"Modified: {', '.join(columns_modified)}")
        
        # Show warnings
        for warning in warnings:
            result += printer.warning(warning)
        
        return result


class PrettyPrinter:
    """
    Formats lineage reports with consistent styling.
    
    Task 5.3 implementation - provides methods for:
    - Clear section headers
    - Consistent indentation and spacing
    - Warning highlighting with ⚠️ prefix
    - Info highlighting with ℹ️ prefix
    - Number formatting with appropriate precision
    - Percentage formatting with one decimal place
    """
    
    def __init__(self):
        """Initialize PrettyPrinter with formatting constants."""
        self.separator_char = '═'
        self.separator_length = 63
        self.indent = '├─ '
        self.last_indent = '└─ '
        self.warning_prefix = '⚠️  '
        self.info_prefix = 'ℹ️  '
    
    def header(self, title: str) -> str:
        """
        Format a report header with separator lines.
        
        Args:
            title: Header title text
            
        Returns:
            Formatted header string
        """
        separator = self.separator_char * self.separator_length
        return f"{separator}\n{title}\n{separator}\n"
    
    def footer(self) -> str:
        """
        Format a report footer with separator line.
        
        Returns:
            Formatted footer string
        """
        return self.separator_char * self.separator_length + "\n"
    
    def separator(self) -> str:
        """
        Format a section separator.
        
        Returns:
            Formatted separator string
        """
        return "\n"
    
    def section_header(self, title: str) -> str:
        """
        Format a section header.
        
        Args:
            title: Section title
            
        Returns:
            Formatted section header
        """
        return f"\n{title}\n"
    
    def item(self, text: str) -> str:
        """
        Format a regular item with tree-style indentation.
        
        Args:
            text: Item text
            
        Returns:
            Formatted item string
        """
        return f"{self.indent}{text}\n"
    
    def last_item(self, text: str) -> str:
        """
        Format the last item in a list with tree-style indentation.
        
        Args:
            text: Item text
            
        Returns:
            Formatted item string
        """
        return f"{self.last_indent}{text}\n"
    
    def warning(self, text: str) -> str:
        """
        Format a warning message with ⚠️ prefix.
        
        Args:
            text: Warning text
            
        Returns:
            Formatted warning string
        """
        return f"{self.indent}{self.warning_prefix}{text}\n"
    
    def info(self, text: str) -> str:
        """
        Format an informational message with ℹ️ prefix.
        
        Args:
            text: Info text
            
        Returns:
            Formatted info string
        """
        return f"{self.info_prefix}{text}\n"
    
    def format_number(self, value: float, precision: int = 2) -> str:
        """
        Format a number with appropriate precision.
        
        Args:
            value: Number to format
            precision: Decimal places (default: 2)
            
        Returns:
            Formatted number string
        """
        return f"{value:.{precision}f}"
    
    def format_percentage(self, value: float) -> str:
        """
        Format a percentage with one decimal place.
        
        Args:
            value: Percentage value (0-100)
            
        Returns:
            Formatted percentage string
        """
        return f"{value:.1f}%"


class OutputFormatter:
    """Formats scan results in different output types."""
    
    def format(self, data, output_type: str):
        """Format data according to output_type."""
        if output_type == 'dataframe':
            return self.to_dataframe(data)
        elif output_type == 'dict':
            return self.to_dict(data)
        elif output_type == 'text':
            return self.to_text(data)
        else:
            raise ValueError(f"Invalid output_type '{output_type}'")
    
    def to_dataframe(self, data) -> pd.DataFrame:
        """Format as DataFrame."""
        if isinstance(data, pd.DataFrame):
            return data
        elif isinstance(data, pl.DataFrame):
            return data.to_pandas()
        elif isinstance(data, dict):
            # Convert dict to DataFrame
            return pd.DataFrame([data])
        elif isinstance(data, list):
            # Convert list of dicts to DataFrame
            return pd.DataFrame(data)
        else:
            raise TypeError(f"Cannot convert {type(data).__name__} to DataFrame")
    
    def to_dict(self, data) -> Dict:
        """Format as dictionary."""
        if isinstance(data, dict):
            return data
        elif isinstance(data, (pd.DataFrame, pl.DataFrame)):
            # Convert DataFrame to dict (records format)
            if isinstance(data, pl.DataFrame):
                data = data.to_pandas()
            return data.to_dict('records')
        elif isinstance(data, str):
            # Return text as dict with 'result' key
            return {'result': data}
        else:
            raise TypeError(f"Cannot convert {type(data).__name__} to dict")
    
    def to_text(self, data) -> str:
        """Format as human-readable text."""
        if isinstance(data, str):
            return data
        elif isinstance(data, dict):
            # Format dict as text
            lines = []
            for key, value in data.items():
                lines.append(f"{key}: {value}")
            return '\n'.join(lines)
        elif isinstance(data, (pd.DataFrame, pl.DataFrame)):
            # Format DataFrame as text
            if isinstance(data, pl.DataFrame):
                data = data.to_pandas()
            return data.to_string()
        else:
            return str(data)
