//
// Created by Howard Henson on 27/12/2024.
//

#ifndef TIME_SERIES_SIGNAL_INPUT_BUILDER_H
#define TIME_SERIES_SIGNAL_INPUT_BUILDER_H

#include <hgraph/builders/input_builder.h>

namespace hgraph {
    struct TimeSeriesSignalInput;

    struct HGRAPH_EXPORT TimeSeriesSignalInputBuilder : InputBuilder {
        using ptr = nb::ref<TimeSeriesSignalInputBuilder>;

        // Constructor for signal without impl (basic signal)
        TimeSeriesSignalInputBuilder() = default;

        // Constructor for signal with impl (signal bound to a dereferenced type)
        explicit TimeSeriesSignalInputBuilder(InputBuilder::ptr impl_builder);

        time_series_input_s_ptr make_instance(node_ptr owning_node) const override;

        time_series_input_s_ptr make_instance(time_series_input_ptr owning_input) const override;

        void release_instance(time_series_input_ptr item) const override;

        void release_instance(TimeSeriesSignalInput *item) const;

        [[nodiscard]] size_t memory_size() const override;

        [[nodiscard]] size_t type_alignment() const override;

        static void register_with_nanobind(nb::module_ &m);

    private:
        InputBuilder::ptr impl_builder_{nullptr};
    };
} // namespace hgraph

#endif  // TIME_SERIES_SIGNAL_INPUT_BUILDER_H
