import click
from rich import print
from rich.console import Console

console = Console()


@click.group()
def light():
    print("[bold green]LIGHT CLI[/bold green]")


@light.command()
def hello():
    Panel(
        "Hello! See help for more.",
        title="Light CLI",
        subtitle="v0.0.1"
    )
