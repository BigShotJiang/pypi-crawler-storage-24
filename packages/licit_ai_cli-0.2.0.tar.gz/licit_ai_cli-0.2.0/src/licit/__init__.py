"""licit — Regulatory compliance for AI-powered development teams."""

__version__ = "0.2.0"
