"""
Integration tests for the CLI.
"""

import unittest
import subprocess
import os
import json


class TestCLICommands(unittest.TestCase):
    """Test CLI commands with mock environment."""

    def setUp(self):
        """Set up test environment."""
        self.env = os.environ.copy()
        self.env['FB_ACCESS_TOKEN'] = 'test_token'
        self.env['FB_PIXEL_ID'] = '123456789'
        self.env['FB_PAGE_ID'] = '987654321'
        # Use module execution for relative imports to work
        self.project_root = os.path.join(os.path.dirname(__file__), '..')

    def test_help_command(self):
        """Test that help command works."""
        result = subprocess.run(
            ['python3', '-m', 'fb_cli.fb', '--help'],
            capture_output=True,
            text=True,
            cwd=self.project_root
        )

        self.assertEqual(result.returncode, 0)
        self.assertIn('Facebook CLI', result.stdout)

    def test_whoami_missing_token(self):
        """Test whoami fails without token."""
        env = self.env.copy()
        env['FB_ACCESS_TOKEN'] = ''

        result = subprocess.run(
            ['python3', '-m', 'fb_cli.fb', 'whoami'],
            capture_output=True,
            text=True,
            env=env,
            cwd=self.project_root
        )

        self.assertNotEqual(result.returncode, 0)
        self.assertIn('AUTH_FAILED', result.stderr or result.stdout)

    def test_error_output_goes_to_stderr(self):
        """Test that error messages go to stderr, not stdout."""
        env = self.env.copy()
        env['FB_ACCESS_TOKEN'] = ''

        result = subprocess.run(
            ['python3', '-m', 'fb_cli.fb', 'whoami'],
            capture_output=True,
            text=True,
            env=env,
            cwd=self.project_root
        )

        # Error message should be in stderr, not stdout
        self.assertIn('AUTH_FAILED', result.stderr)
        self.assertNotIn('AUTH_FAILED', result.stdout)

    def test_help_output_stays_on_stdout(self):
        """Test that help text goes to stdout."""
        result = subprocess.run(
            ['python3', '-m', 'fb_cli.fb', '--help'],
            capture_output=True,
            text=True,
            cwd=self.project_root
        )

        # Help text is the primary output, should be on stdout
        self.assertIn('Facebook CLI', result.stdout)
        # No errors expected
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, '')  # Nothing on stderr for help


class TestConversionsFileLoading(unittest.TestCase):
    """Test file-based conversion sending."""

    def test_load_events_from_json_array(self):
        """Test loading events from JSON array file."""
        from fb_cli.conversions import load_events_from_file

        # Create temp file with JSON array
        events = [
            {'event_name': 'Purchase', 'event_time': 1234567890},
            {'event_name': 'Lead', 'event_time': 1234567891}
        ]

        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(events, f)
            temp_path = f.name

        try:
            loaded = load_events_from_file(temp_path)
            self.assertEqual(len(loaded), 2)
            self.assertEqual(loaded[0]['event_name'], 'Purchase')
        finally:
            os.unlink(temp_path)


if __name__ == '__main__':
    unittest.main()