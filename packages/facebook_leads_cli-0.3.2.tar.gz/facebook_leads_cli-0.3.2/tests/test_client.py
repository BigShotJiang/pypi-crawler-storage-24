"""
Unit tests for the Facebook client.
"""

import unittest
from unittest.mock import patch, MagicMock

from fb_cli.client import FacebookClient
from fb_cli.conversions import normalize_and_hash, clean_phone_number, prepare_user_data, normalize_country_code


class TestFacebookClient(unittest.TestCase):
    """Test cases for FacebookClient."""

    def setUp(self):
        """Set up test fixtures."""
        self.access_token = 'test_token'
        self.pixel_id = '123456789'
        self.page_id = '987654321'

    @patch('fb_cli.client.FacebookAdsApi')
    def test_init(self, mock_api):
        """Test client initialization."""
        client = FacebookClient(
            access_token=self.access_token,
            pixel_id=self.pixel_id,
            page_id=self.page_id
        )

        mock_api.init.assert_called_once_with(access_token=self.access_token)
        self.assertEqual(client.access_token, self.access_token)
        self.assertEqual(client.pixel_id, self.pixel_id)
        self.assertEqual(client.page_id, self.page_id)

    @patch('fb_cli.client.FacebookAdsApi')
    @patch('fb_cli.client.Page')
    def test_whoami_success(self, mock_page, mock_api):
        """Test whoami with successful authentication."""
        mock_page_instance = MagicMock()
        mock_page_instance.get.return_value = 'Test Page'
        mock_page.return_value = mock_page_instance

        client = FacebookClient(self.access_token, page_id=self.page_id)
        result = client.whoami()

        self.assertTrue(result['success'])
        self.assertEqual(result['page_id'], self.page_id)

    @patch('fb_cli.client.FacebookAdsApi')
    @patch('fb_cli.client.Page')
    def test_whoami_auth_failure(self, mock_page, mock_api):
        """Test whoami with authentication failure."""
        # Use a generic exception to simulate API failure
        mock_page.side_effect = Exception('Invalid access token')

        client = FacebookClient(self.access_token, page_id=self.page_id)
        result = client.whoami()

        self.assertFalse(result['success'])
        self.assertEqual(result['code'], 'NETWORK_ERROR')


class TestConversionsHelpers(unittest.TestCase):
    """Test cases for conversion helpers."""

    def test_normalize_and_hash(self):
        """Test value normalization and hashing."""
        # Test basic hashing
        result = normalize_and_hash('test@example.com')
        self.assertEqual(len(result), 64)  # SHA256 hex length

        # Test normalization (whitespace trimming, lowercase)
        result1 = normalize_and_hash('Test@Example.COM')
        result2 = normalize_and_hash('  test@example.com  ')
        self.assertEqual(result1, result2)

        # Test empty input
        self.assertIsNone(normalize_and_hash(''))
        self.assertIsNone(normalize_and_hash(None))

    def test_clean_phone_number(self):
        """Test phone number cleaning."""
        # Test basic cleaning
        self.assertEqual(clean_phone_number('123-456-7890'), '1234567890')
        self.assertEqual(clean_phone_number('+1 (555) 123-4567'), '5551234567')

        # Test empty input
        self.assertIsNone(clean_phone_number(''))
        self.assertIsNone(clean_phone_number(None))

    def test_prepare_user_data(self):
        """Test user data preparation."""
        lead = {
            'email': 'Test@Example.com',
            'phone': '123-456-7890',
            'first_name': 'John',
            'last_name': 'Doe'
        }

        user_data = prepare_user_data(lead)

        # Check that fields are hashed
        self.assertIn('em', user_data)
        self.assertIn('ph', user_data)
        self.assertIn('fn', user_data)
        self.assertIn('ln', user_data)

        # Verify email was normalized before hashing
        expected_email_hash = normalize_and_hash('test@example.com')
        self.assertEqual(user_data['em'], expected_email_hash)

    def test_normalize_country_code(self):
        """Test country code normalization."""
        # Test 2-letter codes pass through
        self.assertEqual(normalize_country_code('US'), 'us')
        self.assertEqual(normalize_country_code('gb'), 'gb')

        # Test common country names
        self.assertEqual(normalize_country_code('USA'), 'us')
        self.assertEqual(normalize_country_code('United States'), 'us')
        self.assertEqual(normalize_country_code('United Kingdom'), 'gb')
        self.assertEqual(normalize_country_code('England'), 'gb')
        self.assertEqual(normalize_country_code('Canada'), 'ca')

        # Test whitespace handling
        self.assertEqual(normalize_country_code('  USA  '), 'us')

        # Test empty/invalid input
        self.assertIsNone(normalize_country_code(''))
        self.assertIsNone(normalize_country_code(None))
        self.assertIsNone(normalize_country_code('   '))

    def test_prepare_user_data_with_country(self):
        """Test user data preparation with country normalization."""
        lead = {
            'email': 'test@example.com',
            'country': 'USA'
        }

        user_data = prepare_user_data(lead)

        # Country should be normalized to 'us' before hashing
        self.assertIn('country', user_data)
        expected_country_hash = normalize_and_hash('us')
        self.assertEqual(user_data['country'], expected_country_hash)


if __name__ == '__main__':
    unittest.main()