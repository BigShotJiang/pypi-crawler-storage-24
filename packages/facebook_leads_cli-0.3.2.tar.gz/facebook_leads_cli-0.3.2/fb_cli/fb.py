#!/usr/bin/env python3
"""
Facebook CLI - Main entry point.
Thin wrapper around the Facebook client with environment-based configuration.
"""

import os
import sys
import json
import argparse
import logging
from typing import Optional

from .client import FacebookClient
from .conversions import create_batch_events, load_events_from_file

# Environment variables
ACCESS_TOKEN = os.environ.get('FB_ACCESS_TOKEN', '')
PIXEL_ID = os.environ.get('FB_PIXEL_ID', '')
PAGE_ID = os.environ.get('FB_PAGE_ID', '')
PAGE_ACCESS_TOKEN = os.environ.get('FB_PAGE_ACCESS_TOKEN', '')
APP_ID = os.environ.get('FB_APP_ID', '')
TEST_EVENT_CODE = os.environ.get('FB_TEST_EVENT_CODE', '')


def create_client() -> FacebookClient:
    """Create a Facebook client instance from environment variables."""
    # Validate access token
    if not ACCESS_TOKEN or not ACCESS_TOKEN.strip():
        print_error(
            'AUTH_FAILED',
            'FB_ACCESS_TOKEN environment variable must be set and non-empty',
            [
                'export FB_ACCESS_TOKEN="your_access_token"',
                '',
                'Get your access token from Facebook App Dashboard.'
            ]
        )
        sys.exit(1)

    if not PIXEL_ID and not PAGE_ID:
        print_error(
            'CONFIG_ERROR',
            'Either FB_PIXEL_ID or FB_PAGE_ID must be set',
            [
                'export FB_PIXEL_ID="your_pixel_id"  # For Conversions API',
                'export FB_PAGE_ID="your_page_id"    # For Lead Gen API',
            ]
        )
        sys.exit(1)

    # Validate that configured IDs are not whitespace-only
    if PIXEL_ID and not PIXEL_ID.strip():
        print_error(
            'CONFIG_ERROR',
            'FB_PIXEL_ID is set but contains only whitespace',
            ['export FB_PIXEL_ID="your_pixel_id"']
        )
        sys.exit(1)

    if PAGE_ID and not PAGE_ID.strip():
        print_error(
            'CONFIG_ERROR',
            'FB_PAGE_ID is set but contains only whitespace',
            ['export FB_PAGE_ID="your_page_id"']
        )
        sys.exit(1)

    return FacebookClient(
        access_token=ACCESS_TOKEN.strip(),
        pixel_id=PIXEL_ID.strip() if PIXEL_ID else None,
        page_id=PAGE_ID.strip() if PAGE_ID else None,
        page_access_token=PAGE_ACCESS_TOKEN.strip() if PAGE_ACCESS_TOKEN else None
    )


def print_error(code: str, message: str, hints: list = None):
    """Print an error message with optional hints."""
    print(f"\nError: {code}\n", file=sys.stderr)
    print(message, file=sys.stderr)
    if hints:
        print(file=sys.stderr)
        for hint in hints:
            print(hint, file=sys.stderr)
    print(file=sys.stderr)


def print_success(message: str):
    """Print a success message."""
    print(f"✓ {message}", file=sys.stderr)


def cmd_whoami(args):
    """Verify authentication and show account info."""
    client = create_client()
    result = client.whoami()

    if not result.get('success'):
        print_error(
            result.get('code', 'ERROR'),
            result.get('error', 'Unknown error')
        )
        sys.exit(1)

    print_success("Authentication successful!")
    print(file=sys.stderr)
    if result.get('page_name'):
        print(f"Page: {result['page_name']} (ID: {result['page_id']})", file=sys.stderr)
    if result.get('pixel_id'):
        print(f"Pixel ID: {result['pixel_id']}", file=sys.stderr)


def cmd_status(args):
    """Check system health and API connectivity."""
    client = create_client()

    print("Checking Facebook API connectivity...\n", file=sys.stderr)

    # Check authentication
    result = client.whoami()
    if result.get('success'):
        print_success("Authentication: OK")
        if result.get('page_name'):
            print(f"  Page: {result['page_name']}", file=sys.stderr)
    else:
        print_error(
            result.get('code', 'ERROR'),
            result.get('error', 'Authentication failed')
        )
        sys.exit(1)

    # Check Lead Gen API access (if page_id is set)
    if PAGE_ID:
        forms = client.get_lead_forms()
        if forms is not None:
            print_success("Lead Gen API: OK")
            print(f"  Forms found: {len(forms)}", file=sys.stderr)
        else:
            print("⚠ Lead Gen API: Limited access", file=sys.stderr)

    # Check Conversions API access (if pixel_id is set)
    if PIXEL_ID:
        print_success("Conversions API: Configured")
        print(f"  Pixel ID: {PIXEL_ID}", file=sys.stderr)

    print("\n✓ System health check complete", file=sys.stderr)


def cmd_forms_list(args):
    """List all lead forms on the page."""
    client = create_client()

    if not PAGE_ID:
        print_error(
            'CONFIG_ERROR',
            'FB_PAGE_ID must be set to list forms',
            ['export FB_PAGE_ID="your_page_id"']
        )
        sys.exit(1)

    forms = client.get_lead_forms()

    if not forms:
        print("No lead forms found on this page.", file=sys.stderr)
        return

    print(f"Found {len(forms)} lead form(s):\n", file=sys.stderr)
    print(f"{'ID':<20} {'Name':<30} {'Status':<10} {'Leads':<10}", file=sys.stderr)
    print("-" * 70, file=sys.stderr)

    for form in forms:
        print(f"{form['id']:<20} {form['name']:<30} {form['status']:<10} {form.get('leads_count', 0):<10}", file=sys.stderr)


def cmd_forms_show(args):
    """Show details of a specific form."""
    client = create_client()

    form_id = args.form_id
    details = client.get_form_details(form_id)

    if not details or 'error' in details:
        print_error(
            details.get('code', 'NOT_FOUND'),
            details.get('error', f'Form {form_id} not found')
        )
        sys.exit(1)

    print(f"Form: {details['name']}", file=sys.stderr)
    print(f"ID: {details['id']}", file=sys.stderr)
    print(f"Status: {details['status']}", file=sys.stderr)
    print(f"Created: {details['created_time']}", file=sys.stderr)

    if details.get('questions'):
        print("\nQuestions:", file=sys.stderr)
        for q in details['questions']:
            print(f"  - {q}", file=sys.stderr)


def cmd_leads_fetch(args):
    """Fetch leads from all forms."""
    client = create_client()
    days = args.days or 7
    limit = args.limit or 1000

    print(f"Fetching leads from the past {days} days (limit: {limit} per form)...\n", file=sys.stderr)

    leads = client.get_leads(days=days, limit=limit)

    if not leads:
        print("No leads found.", file=sys.stderr)
        return

    print(f"✓ Fetched {len(leads)} lead(s)\n", file=sys.stderr)

    # Output format
    if args.json:
        print(json.dumps(leads, indent=2))
    else:
        print(f"{'ID':<20} {'Created':<20} {'Form':<25}")
        print("-" * 65)
        for lead in leads:
            created = lead.get('created_time', '')[:19] if lead.get('created_time') else ''
            form_name = lead.get('form_name', 'N/A')[:24]
            print(f"{lead['id']:<20} {created:<20} {form_name:<25}")


def cmd_leads_list(args):
    """List leads from a specific form."""
    client = create_client()

    if not args.form:
        print_error(
            'INVALID_INPUT',
            '--form is required',
            ['fb-cli leads list --form=<form_id>']
        )
        sys.exit(1)

    days = args.days or 7
    limit = args.limit or 1000

    print(f"Fetching leads from form {args.form}...\n", file=sys.stderr)

    leads = client.get_leads(form_id=args.form, days=days, limit=limit)

    if not leads:
        print("No leads found.", file=sys.stderr)
        return

    print(f"✓ Fetched {len(leads)} lead(s)\n", file=sys.stderr)

    if args.json:
        print(json.dumps(leads, indent=2))
    else:
        print(f"{'ID':<20} {'Created':<20} {'Email':<30}")
        print("-" * 70)
        for lead in leads:
            created = lead.get('created_time', '')[:19] if lead.get('created_time') else ''
            email = lead.get('email', 'N/A')[:29]
            print(f"{lead['id']:<20} {created:<20} {email:<30}")


def cmd_conversions_send(args):
    """Send conversion events from a file."""
    client = create_client()

    if not args.file:
        print_error(
            'INVALID_INPUT',
            '--file is required',
            ['fb-cli conversions send --file=data.json']
        )
        sys.exit(1)

    try:
        events = load_events_from_file(args.file)
        print(f"Loaded {len(events)} event(s) from {args.file}", file=sys.stderr)

        result = client.send_conversion_events(
            events,
            test_event_code=TEST_EVENT_CODE
        )

        if result.get('success'):
            print_success(f"Sent {len(events)} event(s)")
            print(f"Response: {result.get('response')}", file=sys.stderr)
        else:
            print_error(
                result.get('code', 'API_ERROR'),
                result.get('error', 'Failed to send events')
            )
            sys.exit(1)

    except FileNotFoundError:
        print_error('FILE_NOT_FOUND', f"File not found: {args.file}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print_error('INVALID_JSON', f"Invalid JSON in file: {e}")
        sys.exit(1)


def cmd_conversions_test(args):
    """Send a test conversion event."""
    client = create_client()

    print("Sending test conversion event...\n", file=sys.stderr)

    result = client.send_test_conversion()

    if result.get('success'):
        print_success("Test event sent successfully!")
        print(f"Response: {result.get('response')}", file=sys.stderr)
    else:
        print_error(
            result.get('code', 'API_ERROR'),
            result.get('error', 'Failed to send test event')
        )
        sys.exit(1)


def main():
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(
        prog='fb-cli',
        description='Facebook CLI - Lead Gen and Conversions API wrapper'
    )

    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # whoami command
    whoami_parser = subparsers.add_parser('whoami', help='Show connected account info')
    whoami_parser.set_defaults(func=cmd_whoami)

    # status command
    status_parser = subparsers.add_parser('status', help='System health check')
    status_parser.set_defaults(func=cmd_status)

    # forms commands
    forms_parser = subparsers.add_parser('forms', help='Lead form operations')
    forms_subparsers = forms_parser.add_subparsers(dest='subcommand')

    forms_list_parser = forms_subparsers.add_parser('list', help='List all lead forms')
    forms_list_parser.set_defaults(func=cmd_forms_list)

    forms_show_parser = forms_subparsers.add_parser('show', help='Show form details')
    forms_show_parser.add_argument('form_id', help='Form ID')
    forms_show_parser.set_defaults(func=cmd_forms_show)

    # leads commands
    leads_parser = subparsers.add_parser('leads', help='Lead operations')
    leads_subparsers = leads_parser.add_subparsers(dest='subcommand')

    leads_fetch_parser = leads_subparsers.add_parser('fetch', help='Fetch leads from all forms')
    leads_fetch_parser.add_argument('--days', type=int, help='Days to look back')
    leads_fetch_parser.add_argument('--limit', type=int, help='Max leads per form')
    leads_fetch_parser.add_argument('--json', action='store_true', help='JSON output')
    leads_fetch_parser.set_defaults(func=cmd_leads_fetch)

    leads_list_parser = leads_subparsers.add_parser('list', help='List leads from a form')
    leads_list_parser.add_argument('--form', required=True, help='Form ID')
    leads_list_parser.add_argument('--days', type=int, help='Days to look back')
    leads_list_parser.add_argument('--limit', type=int, help='Max leads')
    leads_list_parser.add_argument('--json', action='store_true', help='JSON output')
    leads_list_parser.set_defaults(func=cmd_leads_list)

    # conversions commands
    conversions_parser = subparsers.add_parser('conversions', help='Conversions API operations')
    conversions_subparsers = conversions_parser.add_subparsers(dest='subcommand')

    conversions_send_parser = conversions_subparsers.add_parser('send', help='Send events from file')
    conversions_send_parser.add_argument('--file', required=True, help='JSON file with events')
    conversions_send_parser.set_defaults(func=cmd_conversions_send)

    conversions_test_parser = conversions_subparsers.add_parser('test', help='Send test event')
    conversions_test_parser.set_defaults(func=cmd_conversions_test)

    # Parse arguments
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        print("\nCommands:", file=sys.stderr)
        print("  fb-cli whoami                 - Show connected account info", file=sys.stderr)
        print("  fb-cli status                 - System health check", file=sys.stderr)
        print("  fb-cli forms list             - List all lead forms", file=sys.stderr)
        print("  fb-cli forms show <form_id>   - Show form details", file=sys.stderr)
        print("  fb-cli leads fetch --days=7   - Fetch leads from all forms", file=sys.stderr)
        print("  fb-cli leads list --form=X    - List leads from specific form", file=sys.stderr)
        print("  fb-cli conversions send       - Send conversion events from file", file=sys.stderr)
        print("  fb-cli conversions test       - Send test conversion event", file=sys.stderr)
        sys.exit(0)

    # Handle nested subcommands
    if args.command in ['forms', 'leads', 'conversions'] and not hasattr(args, 'func'):
        if args.command == 'forms':
            print("Usage: fb-cli forms <subcommand>", file=sys.stderr)
            print("Subcommands: list, show", file=sys.stderr)
        elif args.command == 'leads':
            print("Usage: fb-cli leads <subcommand>", file=sys.stderr)
            print("Subcommands: fetch, list", file=sys.stderr)
        elif args.command == 'conversions':
            print("Usage: fb-cli conversions <subcommand>", file=sys.stderr)
            print("Subcommands: send, test", file=sys.stderr)
        sys.exit(1)

    # Execute command
    try:
        args.func(args)
    except KeyboardInterrupt:
        print("\nInterrupted", file=sys.stderr)
        sys.exit(130)
    except Exception as e:
        print_error('ERROR', str(e))
        sys.exit(1)


if __name__ == '__main__':
    main()
