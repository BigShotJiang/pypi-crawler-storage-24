"""
Helpers for creating Facebook Conversions API event payloads.
"""

import hashlib
import json
import re
import time
from typing import Dict, List, Any, Optional
from datetime import datetime

# Common country code mappings to ISO 2-letter codes
COUNTRY_CODE_MAP = {
    # USA variants
    'usa': 'us',
    'united states': 'us',
    'united states of america': 'us',
    'america': 'us',
    # UK variants
    'uk': 'gb',
    'united kingdom': 'gb',
    'great britain': 'gb',
    'england': 'gb',
    'scotland': 'gb',
    'wales': 'gb',
    # Canada
    'canada': 'ca',
    # Australia
    'australia': 'au',
    # Germany
    'germany': 'de',
    'deutschland': 'de',
    # France
    'france': 'fr',
    # Spain
    'spain': 'es',
    'españa': 'es',
    # Italy
    'italy': 'it',
    'italia': 'it',
    # Mexico
    'mexico': 'mx',
    'méxico': 'mx',
    # Brazil
    'brazil': 'br',
    'brasil': 'br',
    # India
    'india': 'in',
    # Japan
    'japan': 'jp',
    # China
    'china': 'cn',
    # Netherlands
    'netherlands': 'nl',
    'holland': 'nl',
    # Belgium
    'belgium': 'be',
    # Switzerland
    'switzerland': 'ch',
    # Sweden
    'sweden': 'se',
    # Norway
    'norway': 'no',
    # Denmark
    'denmark': 'dk',
    # Finland
    'finland': 'fi',
    # Poland
    'poland': 'pl',
    # Portugal
    'portugal': 'pt',
    # Russia
    'russia': 'ru',
    # South Korea
    'south korea': 'kr',
    'korea': 'kr',
    # New Zealand
    'new zealand': 'nz',
    # Ireland
    'ireland': 'ie',
    # Austria
    'austria': 'at',
    # Greece
    'greece': 'gr',
    # Argentina
    'argentina': 'ar',
    # Chile
    'chile': 'cl',
    # Colombia
    'colombia': 'co',
    # Peru
    'peru': 'pe',
    # Philippines
    'philippines': 'ph',
    # Singapore
    'singapore': 'sg',
    # Thailand
    'thailand': 'th',
    # Vietnam
    'vietnam': 'vn',
    # Malaysia
    'malaysia': 'my',
    # Indonesia
    'indonesia': 'id',
    # South Africa
    'south africa': 'za',
    # Israel
    'israel': 'il',
    # Turkey
    'turkey': 'tr',
    # Saudi Arabia
    'saudi arabia': 'sa',
    # UAE
    'united arab emirates': 'ae',
    'uae': 'ae',
}


def normalize_country_code(country: str) -> Optional[str]:
    """
    Normalize a country name or code to ISO 2-letter lowercase code.

    Args:
        country: Country name or code (e.g., "USA", "United States", "US")

    Returns:
        Lowercase 2-letter ISO country code (e.g., "us"), or None if invalid
    """
    if not country or not isinstance(country, str):
        return None

    # Normalize input: lowercase and strip whitespace
    normalized = country.strip().lower()

    if not normalized:
        return None

    # Already a valid 2-letter ISO code
    if len(normalized) == 2 and normalized.isalpha():
        return normalized

    # Check if it's a known country name/variant
    if normalized in COUNTRY_CODE_MAP:
        return COUNTRY_CODE_MAP[normalized]

    # Return as-is if it's a 3-letter code that might be valid
    # (Facebook may accept some 3-letter ISO codes)
    if len(normalized) == 3 and normalized.isalpha():
        return normalized

    # Unknown format - return as lowercase (may not match, but let it through)
    return normalized


def normalize_and_hash(value: str, hash_method: str = 'sha256') -> Optional[str]:
    """
    Normalize and hash a string value according to Facebook's requirements.

    Args:
        value: String to normalize and hash
        hash_method: Hashing algorithm (default: sha256)

    Returns:
        Normalized and hashed string, or None if input is invalid
    """
    if not value or not isinstance(value, str):
        return None

    # Normalize by trimming whitespace and converting to lowercase
    normalized = value.strip().lower()

    if not normalized:
        return None

    if hash_method == 'sha256':
        return hashlib.sha256(normalized.encode('utf-8')).hexdigest()
    else:
        raise ValueError(f"Unsupported hash method: {hash_method}")


def clean_phone_number(phone: str) -> Optional[str]:
    """
    Clean a phone number by removing non-numeric characters.

    Args:
        phone: Phone number string

    Returns:
        Cleaned phone number (digits only)
    """
    if not phone or not isinstance(phone, str):
        return None

    # Remove all non-numeric characters
    phone_digits = re.sub(r'[^0-9]', '', phone)

    if not phone_digits:
        return None

    # Remove leading zeros
    if phone_digits.startswith('00'):
        phone_digits = phone_digits[2:]
    elif phone_digits.startswith('0'):
        phone_digits = phone_digits[1:]

    # Remove country code '1' if 11 digits
    if phone_digits.startswith('1') and len(phone_digits) == 11:
        phone_digits = phone_digits[1:]

    return phone_digits


def prepare_user_data(lead: Dict[str, Any]) -> Dict[str, str]:
    """
    Prepare user data for a Facebook conversion event.

    Args:
        lead: Dictionary containing lead data

    Returns:
        Prepared user data dictionary
    """
    user_data = {}

    # Extract fields
    email = lead.get('email', lead.get('Email', ''))
    phone = lead.get('phone', lead.get('Phone', lead.get('phone_number', '')))
    first_name = lead.get('first_name', lead.get('First Name', ''))
    last_name = lead.get('last_name', lead.get('Last Name', ''))
    country = lead.get('country', lead.get('Country', ''))

    # Hash and add user data fields
    if email:
        user_data['em'] = normalize_and_hash(email)

    if phone:
        cleaned_phone = clean_phone_number(phone)
        if cleaned_phone:
            user_data['ph'] = normalize_and_hash(cleaned_phone)

    if first_name:
        user_data['fn'] = normalize_and_hash(first_name)

    if last_name:
        user_data['ln'] = normalize_and_hash(last_name)

    if country:
        normalized_country = normalize_country_code(country)
        if normalized_country:
            user_data['country'] = normalize_and_hash(normalized_country)

    # Add external ID if available
    lead_id = lead.get('id', lead.get('lead_id', ''))
    if lead_id:
        user_data['external_id'] = str(lead_id)

    return user_data


def create_event_payload(
    lead: Dict[str, Any],
    event_name: str = 'Purchase',
    event_time: Optional[int] = None,
    action_source: str = 'website',
    value: float = 10.0,
    currency: str = 'EUR'
) -> Dict[str, Any]:
    """
    Create an event payload for Facebook Conversions API.

    Args:
        lead: Dictionary containing lead data
        event_name: Event name (e.g., 'Purchase', 'Lead', 'CompleteRegistration')
        event_time: Unix timestamp for the event
        action_source: Source of the event
        value: Value of the conversion
        currency: Currency of the value

    Returns:
        Event payload dictionary
    """
    user_data = prepare_user_data(lead)

    # Use current time if not provided
    if not event_time:
        event_time = int(time.time())
    elif isinstance(event_time, datetime):
        event_time = int(event_time.timestamp())

    # Get event_id from lead id
    lead_id = lead.get('id', lead.get('lead_id', ''))
    event_id = str(lead_id) if lead_id else f"{int(time.time())}-{int(time.time() * 1000) % 10000}"

    # Create event payload
    event = {
        'event_name': event_name,
        'event_time': event_time,
        'action_source': action_source,
        'user_data': user_data,
        'event_id': event_id,
    }

    # Add custom_data if value is provided
    if value:
        event['custom_data'] = {
            'value': value,
            'currency': currency
        }

    return event


def create_batch_events(
    leads: List[Dict[str, Any]],
    event_name: str = 'Purchase',
    action_source: str = 'website',
    value: float = 10.0,
    currency: str = 'EUR'
) -> List[Dict[str, Any]]:
    """
    Create a batch of events from a list of leads.

    Args:
        leads: List of lead dictionaries
        event_name: Name of the event
        action_source: Source of the event
        value: Value of the conversion
        currency: Currency of the value

    Returns:
        List of event payloads
    """
    events = []

    for lead in leads:
        try:
            event = create_event_payload(
                lead,
                event_name=event_name,
                action_source=action_source,
                value=value,
                currency=currency
            )
            events.append(event)
        except Exception as e:
            print(f"Error creating event for lead: {e}")

    print(f"Created {len(events)} events from {len(leads)} leads")
    return events


def load_events_from_file(file_path: str) -> List[Dict[str, Any]]:
    """
    Load events from a JSON file.

    Args:
        file_path: Path to the JSON file

    Returns:
        List of event dictionaries
    """
    with open(file_path, 'r') as f:
        data = json.load(f)

    # Handle both array and object with 'events' key
    if isinstance(data, list):
        return data
    elif isinstance(data, dict) and 'events' in data:
        return data['events']
    elif isinstance(data, dict) and 'data' in data:
        return data['data']
    else:
        return [data]
