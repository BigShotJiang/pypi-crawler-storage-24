"""
Facebook Business SDK wrapper client.
Provides high-level methods for Lead Gen API and Conversions API operations.
"""

import hashlib
import logging
from contextlib import contextmanager
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Generator

from facebook_business.api import FacebookAdsApi
from facebook_business.adobjects.adspixel import AdsPixel
from facebook_business.adobjects.leadgenform import LeadgenForm
from facebook_business.adobjects.page import Page
from facebook_business.exceptions import FacebookRequestError

logger = logging.getLogger('fb_client')


class FacebookClient:
    """Facebook Business SDK wrapper client."""

    def __init__(self, access_token: str, pixel_id: str = None, page_id: str = None, page_access_token: str = None):
        """
        Initialize the Facebook client.

        Args:
            access_token: Facebook API access token (system token)
            pixel_id: Facebook Pixel ID (for Conversions API)
            page_id: Facebook Page ID (for Lead Gen API)
            page_access_token: Page access token (for lead forms - optional but recommended)
        """
        self.access_token = access_token
        self.pixel_id = pixel_id
        self.page_id = page_id
        self.page_access_token = page_access_token

        # Initialize the Facebook API with system token
        FacebookAdsApi.init(access_token=access_token)

    @contextmanager
    def _use_page_token(self) -> Generator[None, None, None]:
        """Context manager to temporarily use page token and restore system token."""
        if self.page_access_token:
            FacebookAdsApi.init(access_token=self.page_access_token)
        try:
            yield
        finally:
            FacebookAdsApi.init(access_token=self.access_token)

    def whoami(self) -> Dict[str, Any]:
        """
        Verify authentication and get current user info.

        Returns:
            Dict with user info or error details
        """
        try:
            with self._use_page_token():
                page = Page(self.page_id)
                page.api_get(fields=['id', 'name'])

            return {
                'success': True,
                'page_id': self.page_id,
                'page_name': page.get('name'),
                'pixel_id': self.pixel_id
            }
        except FacebookRequestError as e:
            return {
                'success': False,
                'error': str(e),
                'code': 'AUTH_FAILED'
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'code': 'NETWORK_ERROR'
            }

    def get_lead_forms(self, page_id: str = None) -> List[Dict[str, Any]]:
        """
        Get all lead forms for a page.

        Args:
            page_id: Optional page ID (uses configured page_id if not provided)

        Returns:
            List of form dictionaries
        """
        page_id = page_id or self.page_id
        if not page_id:
            raise ValueError("page_id is required")

        try:
            with self._use_page_token():
                page = Page(page_id)
                forms = page.get_lead_gen_forms(fields=['id', 'name', 'status', 'leads_count'])

            return [
                {
                    'id': form.get('id'),
                    'name': form.get('name'),
                    'status': form.get('status'),
                    'leads_count': form.get('leads_count')
                }
                for form in forms
            ]
        except FacebookRequestError as e:
            logger.error(f"Error fetching forms: {e}")
            return []

    def get_form_details(self, form_id: str) -> Dict[str, Any]:
        """
        Get details of a specific lead form.

        Args:
            form_id: Lead form ID

        Returns:
            Form details dictionary
        """
        try:
            form = LeadgenForm(form_id)
            form.api_get(fields=['id', 'name', 'status', 'created_time', 'lead_gen_form_name', 'questions', 'thank_you_page'])

            return {
                'id': form.get('id'),
                'name': form.get('name'),
                'status': form.get('status'),
                'created_time': form.get('created_time'),
                'questions': form.get('questions'),
                'thank_you_page': form.get('thank_you_page')
            }
        except FacebookRequestError as e:
            return {
                'success': False,
                'error': str(e),
                'code': 'NOT_FOUND'
            }

    def get_leads(
        self,
        form_id: str = None,
        days: int = 7,
        limit: int = 1000
    ) -> List[Dict[str, Any]]:
        """
        Fetch leads from forms.

        Args:
            form_id: Optional form ID (fetches from all forms if not provided)
            days: Number of days to look back
            limit: Maximum leads per form

        Returns:
            List of lead dictionaries
        """
        leads = []

        if form_id:
            # Fetch from specific form
            form_leads = self._fetch_form_leads(form_id, days, limit)
            leads.extend(form_leads)
        else:
            # Fetch from all forms on the page
            forms = self.get_lead_forms()
            for form in forms:
                if form.get('status') == 'ACTIVE':
                    form_leads = self._fetch_form_leads(form['id'], days, limit)
                    for lead in form_leads:
                        lead['form_id'] = form['id']
                        lead['form_name'] = form['name']
                    leads.extend(form_leads)

        return leads

    def _fetch_form_leads(
        self,
        form_id: str,
        days: int,
        limit: int
    ) -> List[Dict[str, Any]]:
        """Fetch leads from a specific form."""
        try:
            with self._use_page_token():
                form = LeadgenForm(form_id)
                params = {
                    'limit': limit
                }

                leads_data = form.get_leads(
                    fields=['id', 'created_time', 'field_data'],
                    params=params
                )

            # Filter leads by date in Python (Facebook filtering can be unreliable)
            cutoff_date = datetime.now() - timedelta(days=days)
            filtered_leads = []
            for lead in leads_data:
                created_time_str = lead.get('created_time')
                if created_time_str:
                    try:
                        # Parse Facebook's ISO format: 2025-08-15T03:33:19+0000
                        # Handle timezone properly
                        created_time_str_clean = created_time_str.replace('Z', '+00:00')
                        # Handle +0000 format (missing colon)
                        if '+' in created_time_str_clean and ':' not in created_time_str_clean[-5:]:
                            created_time_str_clean = created_time_str_clean[:-2] + ':' + created_time_str_clean[-2:]
                        created_time = datetime.fromisoformat(created_time_str_clean)
                        # Make cutoff_date timezone-aware for comparison
                        if created_time.tzinfo is not None and cutoff_date.tzinfo is None:
                            cutoff_date = cutoff_date.replace(tzinfo=created_time.tzinfo)
                        if created_time >= cutoff_date:
                            filtered_leads.append(lead)
                    except ValueError as e:
                        logger.warning(f"Could not parse created_time '{created_time_str}': {e}")
                        # Include leads with unparseable dates to be safe
                        filtered_leads.append(lead)

            return [self._process_lead(lead) for lead in filtered_leads]
        except FacebookRequestError as e:
            logger.error(f"Error fetching leads from form {form_id}: {e}")
            return []

    def _process_lead(self, lead: Dict) -> Dict[str, Any]:
        """Process a lead into a consistent format."""
        processed = {
            'id': lead.get('id'),
            'created_time': lead.get('created_time'),
        }

        # Process field data
        field_data = lead.get('field_data', [])
        for field in field_data:
            name = field.get('name', '')
            values = field.get('values', [])
            if values:
                # Use simplified field names
                field_key = name.replace(' ', '_').lower()
                processed[field_key] = values[0]

        return processed

    def send_conversion_events(
        self,
        events: List[Dict[str, Any]],
        test_event_code: str = None
    ) -> Dict[str, Any]:
        """
        Send conversion events to Facebook Conversions API.

        Args:
            events: List of event dictionaries
            test_event_code: Optional test event code

        Returns:
            API response dictionary
        """
        if not self.pixel_id:
            return {
                'success': False,
                'error': 'Pixel ID not configured',
                'code': 'CONFIG_ERROR'
            }

        try:
            pixel = AdsPixel(self.pixel_id)

            # Build the payload for each event
            formatted_events = []
            for event in events:
                formatted_event = {
                    'event_name': event.get('event_name', 'Purchase'),
                    'event_time': event.get('event_time', int(datetime.now().timestamp())),
                    'action_source': event.get('action_source', 'website'),
                }

                # Add user_data if present
                if 'user_data' in event:
                    formatted_event['user_data'] = event['user_data']

                # Add custom_data if present
                if 'custom_data' in event:
                    formatted_event['custom_data'] = event['custom_data']

                # Add event_id if present
                if 'event_id' in event:
                    formatted_event['event_id'] = event['event_id']

                formatted_events.append(formatted_event)

            # Send via SDK
            params = {'data': formatted_events}
            if test_event_code:
                params['test_event_code'] = test_event_code

            response = pixel.create_event(params=params)

            return {
                'success': True,
                'response': response
            }
        except FacebookRequestError as e:
            return {
                'success': False,
                'error': str(e),
                'code': 'API_ERROR'
            }

    def send_test_conversion(self) -> Dict[str, Any]:
        """Send a test conversion event to verify setup."""
        test_event = {
            'event_name': 'Purchase',
            'event_time': int(datetime.now().timestamp()),
            'user_data': {
                'em': self._hash_value('test@example.com'),
            },
            'custom_data': {
                'value': 1.0,
                'currency': 'USD'
            },
            'action_source': 'website'
        }

        return self.send_conversion_events([test_event])

    @staticmethod
    def _hash_value(value: str) -> str:
        """Hash a value using SHA256 (Facebook's required format)."""
        if not value:
            return None
        normalized = value.strip().lower()
        return hashlib.sha256(normalized.encode('utf-8')).hexdigest()
