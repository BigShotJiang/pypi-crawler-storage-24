# gldrelu

Golden Ratio ReLU activation for TensorFlow.

Formula:
GldReLU(x) = max(0,(φ−1)x)

Install:

pip install gldrelu
