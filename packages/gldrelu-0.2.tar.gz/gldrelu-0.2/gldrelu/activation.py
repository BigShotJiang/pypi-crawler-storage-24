import tensorflow as tf
from tensorflow.keras.utils import get_custom_objects

def gldrelu(x):
    phi = (1 + tf.sqrt(5.0)) / 2
    scale = phi - 1
    return tf.maximum(0.0, x * scale)

get_custom_objects().update({"gldrelu": gldrelu})
