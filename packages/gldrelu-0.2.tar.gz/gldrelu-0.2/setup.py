from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="gldrelu",
    version="0.2",
    author="Pankaja Lakshmi",
    description="Golden Ratio ReLU activation for TensorFlow",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["tensorflow"],
)
