from decimal import Decimal

import mm_clikit

from mm_okx.api.account import AccountClient
from mm_okx.cli.commands.account_commands import BaseAccountParams
from mm_okx.cli.utils import print_debug_or_error


async def run(params: BaseAccountParams, inst_id: str, sz: Decimal) -> None:
    client = AccountClient(params.account)
    res = await client.sell_market(inst_id, sz)
    print_debug_or_error(res, params.debug)

    mm_clikit.print_json(res)
