"""CLDR plural rule helpers and variable interpolation."""

from babel import Locale
from babel.plural import PluralRule


def get_plural_category(lang: str, count: int | float) -> str:
    """Get the CLDR plural category for a count in the given language."""
    locale = Locale.parse(lang.lower())
    rule = locale.plural_form
    return rule(count)


def get_plural_categories(lang: str) -> set[str]:
    """Get all CLDR plural categories used by a language."""
    locale = Locale.parse(lang.lower())
    # Babel's PluralRule.tags gives the set of categories (excluding 'other')
    tags = set(locale.plural_form.tags)
    tags.add("other")  # 'other' is always present
    return tags


def interpolate_vars(text: str, vars: dict | None) -> str:
    """Safely interpolate variables into a translated string."""
    if not vars:
        return text
    result = text
    for key, value in vars.items():
        result = result.replace(f"{{{key}}}", str(value))
    return result
