"""Transduck — AI-native translation tool."""

import hashlib
import logging
import os
import threading

from transduck import backend
from transduck.config import TransduckConfig, load_config
from transduck.plural import get_plural_category, get_plural_categories, interpolate_vars
from transduck.storage import TranslationStore
from transduck.validation import validate_translation, extract_placeholders

logger = logging.getLogger("transduck")


class _State:
    def __init__(self):
        self.config: TransduckConfig | None = None
        self.store: TranslationStore | None = None
        self.target_lang: str | None = None
        self._locks: dict[tuple, threading.Lock] = {}
        self._locks_lock = threading.Lock()


_state = _State()


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def initialize(config: TransduckConfig | None = None):
    if config is None:
        config = load_config()
    _state.config = config
    _state.store = TranslationStore(config.storage_path)
    _state.store.initialize()


def set_language(lang: str):
    _state.target_lang = lang.upper()


def ait(source_text: str, context: str | None = None, vars: dict | None = None) -> str:
    if _state.config is None or _state.store is None:
        raise RuntimeError("transduck not initialized. Call transduck.initialize() first.")
    if _state.target_lang is None:
        raise RuntimeError("Target language not set. Call transduck.set_language() first.")

    cfg = _state.config

    if _state.target_lang == cfg.source_lang:
        return interpolate_vars(source_text, vars)

    project_context_hash = _hash(cfg.project_context)
    string_context_hash = _hash(context or "")

    # Cache lookup
    cached = _state.store.lookup(
        source_text=source_text,
        source_lang=cfg.source_lang,
        target_lang=_state.target_lang,
        project_context_hash=project_context_hash,
        string_context_hash=string_context_hash,
    )
    if cached is not None:
        return interpolate_vars(cached, vars)

    # In-process dedup lock
    lock_key = (source_text, cfg.source_lang, _state.target_lang, project_context_hash, string_context_hash)
    with _state._locks_lock:
        if lock_key not in _state._locks:
            _state._locks[lock_key] = threading.Lock()
        lock = _state._locks[lock_key]

    with lock:
        # Double-check after acquiring lock
        cached = _state.store.lookup(
            source_text=source_text,
            source_lang=cfg.source_lang,
            target_lang=_state.target_lang,
            project_context_hash=project_context_hash,
            string_context_hash=string_context_hash,
        )
        if cached is not None:
            return interpolate_vars(cached, vars)

        # Call backend
        api_key = os.environ.get(cfg.api_key_env)
        try:
            translated = backend.translate(
                source_text=source_text,
                source_lang=cfg.source_lang,
                target_lang=_state.target_lang,
                project_context=cfg.project_context,
                string_context=context,
                api_key=api_key,
                model=cfg.backend_model,
                timeout=cfg.backend_timeout,
                max_retries=cfg.backend_max_retries,
            )
        except Exception:
            logger.warning("Backend failed for: %s", source_text, exc_info=True)
            return interpolate_vars(source_text, vars)

        # Validate
        if not validate_translation(source_text, translated):
            logger.warning("Validation failed for: %s -> %s", source_text, translated)
            _state.store.insert(
                source_text=source_text,
                source_lang=cfg.source_lang,
                target_lang=_state.target_lang,
                project_context_hash=project_context_hash,
                string_context_hash=string_context_hash,
                translated_text=translated,
                model=cfg.backend_model,
                status="failed",
            )
            return interpolate_vars(source_text, vars)

        # Store and return
        _state.store.insert(
            source_text=source_text,
            source_lang=cfg.source_lang,
            target_lang=_state.target_lang,
            project_context_hash=project_context_hash,
            string_context_hash=string_context_hash,
            translated_text=translated,
            model=cfg.backend_model,
        )
        return interpolate_vars(translated, vars)


def ait_plural(
    one: str,
    other: str,
    count: int | float,
    context: str | None = None,
    vars: dict | None = None,
) -> str:
    if _state.config is None or _state.store is None:
        raise RuntimeError("transduck not initialized. Call transduck.initialize() first.")
    if _state.target_lang is None:
        raise RuntimeError("Target language not set. Call transduck.set_language() first.")

    cfg = _state.config

    # Build vars with count
    if vars is None:
        vars = {"count": count}
    elif "count" not in vars:
        vars = {**vars, "count": count}

    # Same language, 2-form language: select directly from provided forms
    if _state.target_lang == cfg.source_lang:
        categories = get_plural_categories(cfg.source_lang)
        if categories <= {"one", "other"}:
            category = get_plural_category(cfg.source_lang, count)
            form = one if category == "one" else other
            return interpolate_vars(form, vars)

    # Build cache key
    source_key = one + "\x00" + other
    project_context_hash = _hash(cfg.project_context)
    string_context_hash = _hash(context or "")

    # Cache lookup
    cached = _state.store.lookup_plural(
        source_text=source_key,
        source_lang=cfg.source_lang,
        target_lang=_state.target_lang,
        project_context_hash=project_context_hash,
        string_context_hash=string_context_hash,
    )

    category = get_plural_category(_state.target_lang, count)
    if category in cached:
        return interpolate_vars(cached[category], vars)

    # Cache miss — call backend
    api_key = os.environ.get(cfg.api_key_env)
    try:
        forms = backend.translate_plural(
            one=one,
            other=other,
            source_lang=cfg.source_lang,
            target_lang=_state.target_lang,
            project_context=cfg.project_context,
            string_context=context,
            api_key=api_key,
            model=cfg.backend_model,
            timeout=cfg.backend_timeout,
            max_retries=cfg.backend_max_retries,
        )
    except Exception:
        logger.warning("Backend failed for plural: %s / %s", one, other, exc_info=True)
        fallback_category = get_plural_category(cfg.source_lang, count)
        fallback = one if fallback_category == "one" else other
        return interpolate_vars(fallback, vars)

    # Validate and store each form
    valid_categories = {"zero", "one", "two", "few", "many", "other"}
    source_placeholders = extract_placeholders(one) | extract_placeholders(other)

    if not isinstance(forms, dict) or "other" not in forms:
        logger.warning("Invalid plural response for: %s / %s", one, other)
        fallback_category = get_plural_category(cfg.source_lang, count)
        fallback = one if fallback_category == "one" else other
        return interpolate_vars(fallback, vars)

    for cat, text in forms.items():
        if cat not in valid_categories or not text:
            continue
        # Validate placeholders
        translated_placeholders = extract_placeholders(text)
        status = "translated" if source_placeholders.issubset(translated_placeholders) else "failed"
        _state.store.insert_plural(
            source_text=source_key,
            source_lang=cfg.source_lang,
            target_lang=_state.target_lang,
            project_context_hash=project_context_hash,
            string_context_hash=string_context_hash,
            plural_category=cat,
            translated_text=text,
            model=cfg.backend_model,
            status=status,
        )

    # Select the right form
    if category in forms:
        text = forms[category]
        tp = extract_placeholders(text)
        if source_placeholders.issubset(tp):
            return interpolate_vars(text, vars)

    # Fallback
    fallback_category = get_plural_category(cfg.source_lang, count)
    fallback = one if fallback_category == "one" else other
    return interpolate_vars(fallback, vars)
