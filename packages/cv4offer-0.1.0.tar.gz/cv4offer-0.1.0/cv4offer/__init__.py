"""cv4offer — AI-powered CV tailor for job postings."""

__version__ = "0.1.0"
