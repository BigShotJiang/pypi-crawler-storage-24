# cv4offer-tailor

**AI-powered CV tailor.** Give it your master CV and a job posting. Get a perfectly matched, ATS-optimized PDF.

No more manually tweaking your CV for every application. Write your experience once (with variants), and let AI pick the best combination for each job.

## How it works

1. **You create a master CV** in LaTeX with tagged content pools (skill variants, bullet variants, multiple summaries)
2. **You paste a job posting** into a text file
3. **cv4offer analyzes the posting** and selects the optimal content: which skills to highlight, which bullet variants to use, which achievements match the industry
4. **Out comes a compiled PDF** tailored to that specific job

```
cv4offer generate posting.md --master my_cv.tex
```

## The tag system

Your master CV uses simple comment tags that cv4offer reads:

```latex
% Skills pool (cv4offer picks 12-18 that match the job)
% %%SKILL:eng_python :: \item Python (Django, FastAPI)
% %%SKILL:eng_docker :: \item Docker, CI/CD pipelines

% Bullet variants (v1=standard, v2=expanded, v3=short)
% %%BULLET:acme_1_v1 :: \item Led migration, reducing deploy time by \textbf{70\%}
% %%BULLET:acme_1_v2 :: \item Architected migration from monolith to 12 microservices...
% %%BULLET:acme_1_v3 :: \item Monolith to microservices: deploy time \textbf{-70\%}

% Achievement variants (AI picks the best for the industry)
% %%ACHIEVEMENT_3:A_infra :: \item CI/CD pipeline: releases from 2 weeks to \textbf{2 hours}
% %%ACHIEVEMENT_3:B_ml :: \item Recommendation engine: engagement \textbf{+35\%}

% Frozen sections (never changed, copied verbatim)
% %%FROZEN_SECTION:start:education
\textbf{B.Sc. Computer Science} \\ MIT, 2018--2022
% %%FROZEN_SECTION:end:education
```

## Features

- **ATS optimization** — keywords from the job posting appear naturally in your CV (never copied verbatim)
- **Visual quality checker** — detects orphan lines, overfull text, page fill issues
- **2-page enforcement** — automatically trims or expands content to fit exactly 2 pages
- **Frozen sections** — education, references, achievements that must never change
- **Multiple bullet variants** — same achievement in 3 lengths (standard, expanded, short)

## Install

```bash
pip install cv4offer
```

**Requirements:**
- Python 3.10+
- pdflatex (TeX Live or MiKTeX)
- Anthropic API key (`ANTHROPIC_API_KEY` env var)

## Quick start

```bash
# 1. Copy the example template
cp $(python -c "import cv4offer; print(cv4offer.__file__.replace('__init__.py', 'templates/example_master.tex'))") my_cv.tex

# 2. Edit my_cv.tex with YOUR data (follow the tag system)

# 3. Save a job posting as text
cat > posting.md << 'EOF'
Senior Python Developer at TechCorp
Requirements: Python, Django, PostgreSQL, Docker, CI/CD...
EOF

# 4. Generate tailored CV
export ANTHROPIC_API_KEY=sk-ant-...
cv4offer generate posting.md --master my_cv.tex

# 5. Check visual quality of compiled PDF
cv4offer check cv_techcorp.tex
```

## Commands

| Command | What it does |
|---------|-------------|
| `cv4offer generate posting.md -m master.tex` | Analyze posting, select content, generate CV |
| `cv4offer check cv_output.tex` | Visual quality check (orphans, overfull, page fill) |
| `cv4offer parse master.tex` | Show all content pools in your master CV |
| `cv4offer parse master.tex -v` | Same, but list every item |

## Quality checker

The built-in checker catches issues that pdflatex won't tell you about:

```bash
$ cv4offer check cv_techcorp.tex
{
  "pages": 2,
  "page_fill": [98.3, 91.7],
  "issues": [
    {"type": "orphan_line", "page": 1, "text": "month", "width_pct": 12.3, "severity": "WARNING"},
    {"type": "overfull_hbox", "page": 2, "excess_pt": 3.41, "severity": "WARNING"}
  ],
  "summary": {"critical": 0, "warning": 2, "info": 0}
}
```

## Why not just use ChatGPT to rewrite my CV?

Because rewriting from scratch every time is slow, inconsistent, and loses your best formulations. cv4offer keeps your proven content (metrics, achievements, bullet variants you've refined over months) and just selects the right combination. The AI picks. You wrote the content.

## License

MIT
