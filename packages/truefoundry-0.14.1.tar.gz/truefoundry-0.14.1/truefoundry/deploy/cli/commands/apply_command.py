from typing import List, Optional, Tuple

import rich_click as click

from truefoundry.cli.console import console
from truefoundry.cli.const import GROUP_CLS
from truefoundry.cli.util import handle_exception_wrapper
from truefoundry.deploy.lib.clients.servicefoundry_client import (
    ServiceFoundryServiceClient,
)
from truefoundry.deploy.lib.dao import apply as apply_lib
from truefoundry.deploy.lib.messages import PROMPT_APPLYING_MANIFEST
from truefoundry.deploy.lib.model.entity import ApplyResult


def _validate_options(
    files: Tuple[str, ...],
    directory: Optional[str],
    diffs_only: bool,
    ref: Optional[str],
    show_diff: bool,
    dry_run: bool,
) -> None:
    if show_diff and not dry_run:
        raise click.ClickException("--show-diff requires --dry-run")

    if ref is not None and not diffs_only:
        raise click.ClickException("--ref requires --diffs-only")

    if diffs_only and not directory:
        raise click.ClickException("--diffs-only requires -d/--directory")

    if files and directory:
        raise click.ClickException(
            "-f/--file and -d/--directory are mutually exclusive"
        )

    if not files and not directory:
        raise click.ClickException("Either -f/--file or -d/--directory is required")


def _resolve_directory_files(
    directory: str, diffs_only: bool, ref: Optional[str]
) -> Optional[List[str]]:
    if diffs_only:
        resolved_files = apply_lib.get_git_changed_yaml_files(directory, ref)
        ref_label = ref or "HEAD"
        if not resolved_files:
            console.print(
                f"[yellow]No changed yaml files found compared to {ref_label}[/]"
            )
            return None
        console.print(
            f"[cyan]Found {len(resolved_files)} changed yaml file(s) compared to {ref_label}[/]"
        )
    else:
        resolved_files = apply_lib.collect_yaml_files(directory)
        if not resolved_files:
            console.print("[yellow]No yaml files found in the directory[/]")
            return None
        console.print(f"[cyan]Found {len(resolved_files)} yaml file(s) in directory[/]")

    resolved_files = apply_lib.sort_files_by_manifest_type(resolved_files)
    console.print("[cyan]Applying in dependency order:[/]")
    for f in resolved_files:
        type_str = apply_lib.read_manifest_type(f) or "unknown"
        console.print(f"  [dim]{f}[/] [cyan]({type_str})[/]")
    console.print()
    return resolved_files


@click.group(
    name="apply",
    cls=GROUP_CLS,
    invoke_without_command=True,
    help="""Create resources by applying manifest locally from TrueFoundry spec.

\b
Examples:
  tfy apply -f manifest.yaml                        Apply a single manifest file
  tfy apply -f team.yaml -f cluster.yaml            Apply multiple files
  tfy apply -d ./manifests                          Apply all yamls in a directory (sorted by dependency order)
  tfy apply -d ./manifests --diffs-only             Apply only git-changed yamls compared to HEAD
  tfy apply -d ./manifests --diffs-only --ref main  Apply only git-changed yamls compared to a branch/tag/commit
  tfy apply -d ./manifests --dry-run                Dry run (simulate without applying)
  tfy apply -d ./manifests --dry-run --show-diff    Dry run with diff output
""",
    context_settings={"ignore_unknown_options": True, "allow_interspersed_args": True},
)
@click.option(
    "-f",
    "--file",
    "files",
    type=click.Path(exists=True, dir_okay=False, resolve_path=True),
    help="Path to yaml manifest file (You can apply multiple files at once by providing multiple -f options)",
    show_default=True,
    multiple=True,
)
@click.option(
    "-d",
    "--directory",
    "directory",
    type=click.Path(exists=True, file_okay=False, resolve_path=True),
    help="Path to a directory containing yaml manifest files. All yamls will be collected and applied in dependency order.",
)
@click.option(
    "--diffs-only",
    "--diffs_only",
    is_flag=True,
    show_default=True,
    help="Only apply yaml files that have changed in git (requires -d)",
)
@click.option(
    "--ref",
    type=str,
    default=None,
    help="Git ref (branch, tag, or commit) to compare against when using --diffs-only (default: HEAD)",
)
@click.option(
    "--dry-run",
    "--dry_run",
    is_flag=True,
    show_default=True,
    help="Simulate the process without actually applying the manifest",
)
@click.option(
    "--show-diff",
    "--show_diff",
    is_flag=True,
    show_default=True,
    help="Print manifest differences when using --dry-run",
)
@handle_exception_wrapper
def apply_command(
    files: Tuple[str, ...] = (),
    directory: Optional[str] = None,
    diffs_only: bool = False,
    ref: Optional[str] = None,
    dry_run: bool = False,
    show_diff: bool = False,
):
    _validate_options(files, directory, diffs_only, ref, show_diff, dry_run)

    if directory:
        resolved_files = _resolve_directory_files(directory, diffs_only, ref)
        if resolved_files is None:
            return
    else:
        resolved_files = list(files)

    apply_results: List[ApplyResult] = []
    client = ServiceFoundryServiceClient()
    for file in resolved_files:
        with console.status(PROMPT_APPLYING_MANIFEST.format(file), spinner="dots"):
            for apply_result in apply_lib.apply_manifest_file(
                file, client, dry_run, show_diff
            ):
                if apply_result.success:
                    console.print(f"[green]\u2714 {apply_result.message}[/]")
                else:
                    console.print(f"[red]\u2718 {apply_result.message}[/]")

                apply_results.append(apply_result)

    if not all(apply_result.success for apply_result in apply_results):
        raise Exception("Failed to apply one or more manifests")


def get_apply_command():
    return apply_command
