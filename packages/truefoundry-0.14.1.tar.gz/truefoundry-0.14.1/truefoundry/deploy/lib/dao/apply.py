from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Set, Tuple

import git as gitpython
import yaml

from truefoundry.cli.console import console
from truefoundry.deploy.lib.clients.servicefoundry_client import (
    ServiceFoundryServiceClient,
)
from truefoundry.deploy.lib.diff_utils import print_manifest_diff
from truefoundry.deploy.lib.model.entity import ApplyResult, ManifestLike
from truefoundry.pydantic_v1 import ValidationError

MANIFEST_TYPE_ORDER = [
    "team",
    "provider-account",
    "environment",
    "cluster",
    "ml-repo",
    "workspace",
    "service",
    "job",
    "helm",
    "notebook",
    "rstudio",
    "volume",
    "workflow",
    "async-service",
    "application-set",
    "ssh-server",
    "spark-job",
    "secret-group",
    "tracing-project",
    "mcp-server",
    "agent",
    "policy",
    "role",
    "virtual-account",
    "gateway-guardrails-config",
    "gateway-rate-limiting-config",
    "gateway-global-settings",
    "gateway-fallback-config",
    "gateway-load-balancing-config",
    "gateway-budget-config",
    "gateway-data-access-config",
    "gateway-otel-config",
    "gateway-data-routing-config",
    "gateway-installation",
    "settings",
    "alert-config",
]

_UNKNOWN_TYPE_PRIORITY = len(MANIFEST_TYPE_ORDER)


def _get_base_type(type_str: str) -> str:
    """Extract base type, e.g. 'provider-account/gcp' -> 'provider-account'."""
    return type_str.split("/")[0]


def _get_type_priority(type_str: str) -> int:
    base_type = _get_base_type(type_str)
    try:
        return MANIFEST_TYPE_ORDER.index(base_type)
    except ValueError:
        return _UNKNOWN_TYPE_PRIORITY


def read_manifest_type(filepath: str) -> Optional[str]:
    """Read the type field from the first YAML document in a file."""
    try:
        with open(filepath) as f:
            doc = yaml.safe_load(f)
            if isinstance(doc, dict):
                return doc.get("type")
    except Exception:
        pass
    return None


def collect_yaml_files(directory: str) -> List[str]:
    """Collect all .yaml and .yml files from a directory recursively."""
    dir_path = Path(directory).resolve()
    yaml_files: List[str] = []
    for ext in ("*.yaml", "*.yml"):
        yaml_files.extend(str(p) for p in dir_path.rglob(ext))
    return yaml_files


def sort_files_by_manifest_type(files: List[str]) -> List[str]:
    """Sort files by their manifest type according to dependency order."""

    def sort_key(filepath: str) -> Tuple[int, str]:
        manifest_type = read_manifest_type(filepath)
        if manifest_type is None:
            return (_UNKNOWN_TYPE_PRIORITY + 1, filepath)
        return (_get_type_priority(manifest_type), filepath)

    return sorted(files, key=sort_key)


def _open_git_repo(directory: str) -> gitpython.Repo:
    """Open a git repository, raising clear errors for common failure cases."""
    try:
        repo = gitpython.Repo(directory, search_parent_directories=True)
    except gitpython.InvalidGitRepositoryError:
        raise Exception(f"{directory} is not inside a git repository") from None
    except gitpython.NoSuchPathError:
        raise Exception(f"Directory {directory} does not exist") from None
    except gitpython.GitCommandNotFound:
        raise Exception("git is not installed or not found in PATH") from None

    if repo.working_tree_dir is None:
        raise Exception("Bare git repositories are not supported")
    return repo


def _get_changed_files(repo: gitpython.Repo, ref: str) -> Set[str]:
    """Get all changed file paths (tracked + untracked) compared to a ref."""
    changed_files: Set[str] = set()

    try:
        for diff_item in repo.commit(ref).diff(None):
            changed_files.add(diff_item.a_path or diff_item.b_path)
    except Exception as e:
        raise Exception(f"Failed to compute diff against '{ref}': {e}") from None

    changed_files.update(repo.untracked_files)
    return changed_files


def get_git_changed_yaml_files(directory: str, ref: Optional[str] = None) -> List[str]:
    """Get YAML files changed in git compared to ref (default: HEAD).

    Includes both tracked changes and untracked (new) files, filtered to
    only those within the given directory.
    """
    dir_path = Path(directory).resolve()
    ref = ref or "HEAD"

    repo = _open_git_repo(str(dir_path))
    repo_root = Path(repo.working_tree_dir)
    changed_files = _get_changed_files(repo, ref)

    yaml_files: List[str] = []
    for f in changed_files:
        if not f.endswith((".yaml", ".yml")):
            continue
        abs_path = (repo_root / f).resolve()
        try:
            abs_path.relative_to(dir_path)
        except ValueError:
            continue
        if abs_path.is_file():
            yaml_files.append(str(abs_path))

    return yaml_files


def _apply_manifest(
    manifest: Dict[str, Any],
    client: Optional[ServiceFoundryServiceClient] = None,
    filename: Optional[str] = None,
    index: Optional[int] = None,
    dry_run: bool = False,
    show_diff: bool = False,
) -> ApplyResult:
    client = client or ServiceFoundryServiceClient()

    file_metadata = ""
    if index is not None:
        file_metadata += f" at index {index}"
    if filename:
        file_metadata += f" from file {filename}"

    try:
        parsed_manifest = ManifestLike.parse_obj(manifest)
    except ValidationError as ex:
        return ApplyResult(
            success=False,
            message=f"Failed to apply manifest{file_metadata}. Error: {ex}",
        )

    prefix = "[Dry Run] " if dry_run else ""
    suffix = " (No changes were applied)" if dry_run else ""

    manifest_name = ""
    if parsed_manifest.name:
        manifest_name = f" {parsed_manifest.name}"

    try:
        api_response = client.apply(
            parsed_manifest.dict(exclude_unset=True, exclude_none=True), dry_run
        )

        # Show diff for dry runs only when show_diff is enabled
        if dry_run and show_diff and api_response.existing_manifest:
            if parsed_manifest.name:
                diff_manifest_name = f"{parsed_manifest.name} ({parsed_manifest.type})"
            else:
                diff_manifest_name = f"manifest ({parsed_manifest.type})"
            print_manifest_diff(
                existing_manifest=api_response.existing_manifest,
                new_manifest=parsed_manifest.dict(
                    exclude_unset=True, exclude_none=True
                ),
                manifest_name=diff_manifest_name,
                console=console,
            )

        return ApplyResult(
            success=True,
            message=(
                f"{prefix}Successfully configured manifest{manifest_name} of type {parsed_manifest.type}.{suffix}"
            ),
        )
    except Exception as ex:
        return ApplyResult(
            success=False,
            message=(
                f"{prefix}Failed to apply manifest{manifest_name} of type {parsed_manifest.type}. Error: {ex}.{suffix}"
            ),
        )


def apply_manifest(
    manifest: Dict[str, Any],
    client: Optional[ServiceFoundryServiceClient] = None,
    dry_run: bool = False,
    show_diff: bool = False,
) -> ApplyResult:
    return _apply_manifest(
        manifest=manifest, client=client, dry_run=dry_run, show_diff=show_diff
    )


def apply_manifest_file(
    filepath: str,
    client: Optional[ServiceFoundryServiceClient] = None,
    dry_run: bool = False,
    show_diff: bool = False,
) -> Iterator[ApplyResult]:
    client = client or ServiceFoundryServiceClient()
    filename = Path(filepath).name
    try:
        with open(filepath, "r") as f:
            manifests_it = list(yaml.safe_load_all(f))
    except Exception as ex:
        yield ApplyResult(
            success=False,
            message=f"Failed to read file {filepath} as a valid YAML file. Error: {ex}",
        )
    else:
        prefix = "[Dry Run] " if dry_run else ""
        for index, manifest in enumerate(manifests_it):
            if not isinstance(manifest, dict):
                yield ApplyResult(
                    success=False,
                    message=f"{prefix}Failed to apply manifest at index {index} from file {filename}. Error: A manifest must be a dict, got type {type(manifest)}",
                )
                continue

            yield _apply_manifest(
                manifest=manifest,
                client=client,
                filename=filename,
                index=index,
                dry_run=dry_run,
                show_diff=show_diff,
            )
