# Copyright 2025 Xanadu Quantum Technologies Inc.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
r"""This module contains resource operators for PennyLane Operators"""

from .identity import GlobalPhase, Identity

from .qubit import (
    Hadamard,
    S,
    SWAP,
    T,
    X,
    Y,
    Z,
    PhaseShift,
    RX,
    RY,
    RZ,
    Rot,
    PauliRot,
    MultiRZ,
    SingleExcitation,
    QubitUnitary,
    PCPhase,
)

from .op_math import (
    CCZ,
    CH,
    CNOT,
    ControlledPhaseShift,
    CRot,
    CRX,
    CRY,
    CRZ,
    CSWAP,
    CY,
    CZ,
    MultiControlledX,
    TemporaryAND,
    Toffoli,
    Adjoint,
    Controlled,
    Pow,
    Prod,
    ChangeOpBasis,
)
