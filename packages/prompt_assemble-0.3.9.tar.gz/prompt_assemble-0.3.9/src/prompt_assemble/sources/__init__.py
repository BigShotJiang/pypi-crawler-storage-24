"""Prompt sources - pluggable backends for retrieving prompts."""

import logging
import os
from typing import Optional
from .base import PromptSource
from .filesystem import FileSystemSource
from .database import DatabaseSource

logger = logging.getLogger(__name__)

__all__ = [
    "PromptSource",
    "FileSystemSource",
    "DatabaseSource",
    "create_database_source_from_env",
]


def create_database_source_from_env(table_prefix: Optional[str] = None) -> DatabaseSource:
    """
    Create a DatabaseSource from PostgreSQL environment variables.

    Reads the following environment variables:
    - DB_HOSTNAME: PostgreSQL server hostname (default: localhost)
    - DB_PORT: PostgreSQL server port (default: 5432)
    - DB_USERNAME: PostgreSQL username (default: postgres)
    - DB_PASSWORD: PostgreSQL password (required)
    - DB_DATABASE: PostgreSQL database name (default: prompts)
    - PROMPT_ASSEMBLE_TABLE_PREFIX: Table prefix (optional)

    Args:
        table_prefix: Optional override for table prefix. If provided, takes
                     precedence over PROMPT_ASSEMBLE_TABLE_PREFIX env var.

    Returns:
        DatabaseSource instance configured for PostgreSQL

    Raises:
        ImportError: If psycopg2 is not installed
        SourceConnectionError: If database connection fails
    """
    try:
        import psycopg2
        from psycopg2 import pool
    except ImportError:
        raise ImportError(
            "psycopg2 is required for PostgreSQL support. "
            "Install with: pip install psycopg2-binary"
        )

    # Read environment variables with defaults
    hostname = os.getenv("DB_HOSTNAME", "localhost")
    port = int(os.getenv("DB_PORT", "5432"))
    username = os.getenv("DB_USERNAME", "postgres")
    password = os.getenv("DB_PASSWORD")
    database = os.getenv("DB_DATABASE", "prompts")

    if not password:
        raise ValueError(
            "DB_PASSWORD environment variable is required for PostgreSQL connection"
        )

    # Create connection pool for resilience and performance
    # minconn=1: maintain at least 1 connection
    # maxconn=10: allow up to 10 connections for concurrency
    connection_pool = pool.SimpleConnectionPool(
        minconn=1,
        maxconn=10,
        host=hostname,
        port=port,
        user=username,
        password=password,
        database=database,
        options="-c statement_timeout=30000"  # 30 second timeout
    )

    logger.info(
        f"Created PostgreSQL connection pool: {username}@{hostname}:{port}/{database} (1-10 connections)"
    )

    # Use provided table_prefix or read from environment
    if table_prefix is None:
        table_prefix = os.getenv("PROMPT_ASSEMBLE_TABLE_PREFIX", "pambl_")

    # Create and return DatabaseSource with connection pool
    return DatabaseSource(connection_pool=connection_pool, table_prefix=table_prefix)
