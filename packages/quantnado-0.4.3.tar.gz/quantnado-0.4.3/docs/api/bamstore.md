::: quantnado.dataset.store_bam.BamStore
    options:
      show_source: true
      show_root_heading: true
