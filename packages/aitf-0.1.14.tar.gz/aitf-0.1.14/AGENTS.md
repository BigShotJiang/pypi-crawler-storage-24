## Skills

### Available skills

#### translation-assistant
专业翻译助手，帮助配置翻译流程、优化翻译质量、管理术语表、排查翻译问题。

**触发条件**:
- 用户提到翻译相关任务
- 涉及语言设置、源语言/目标语言配置
- Prompt 定制或优化
- 术语表管理
- 翻译质量优化
- 翻译问题排查
- 涉及 `aitf` 命令的使用

**加载方式**:
1. 先读 `SKILL.md` 理解整体结构
2. 根据具体问题加载对应的 references 文档:
   - `translation-workflow.md` - 翻译流程详解
   - `quality-optimization.md` - 质量优化
   - `troubleshooting.md` - 问题排查
   - `prompt-customization.md` - Prompt 定制
   - `configuration.md` - 配置指南

**文件**: `.claude/skills/translation-assistant/SKILL.md`

---

## 使用示例

### 翻译任务示例
```
用户: 我想翻译一个日文EPUB小说到中文

助手会:
1. 自动加载 translation-assistant skill
2. 从 SKILL.md 获取命令模板
3. 返回:
   uv run aitf translate input.epub -s Japanese -t Chinese --type Epub -r -y
```

### 配置优化示例
```
用户: 翻译质量不好，怎么优化？

助手会:
1. 自动加载 translation-assistant skill
2. 读取 quality-optimization.md
3. 提供参数优化建议：temperature、batch size、context lines 等
```

### 问题排查示例
```
用户: API 连接失败怎么排查？

助手会:
1. 自动加载 translation-assistant skill
2. 读取 troubleshooting.md
3. 提供诊断步骤：
   - 检查 API 配置
   - 测试连接性
   - 查看日志
```
