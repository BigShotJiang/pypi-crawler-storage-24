#!/usr/bin/env python3
"""
Package translation-assistant skill to Resource directory.

This script copies the skill files to the specified resource directory.
"""

import os
import shutil
import sys

# Paths
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESOURCE_DIR = os.path.join(os.path.dirname(SKILL_DIR), "Resource")

if os.path.exists(RESOURCE_DIR):
    print(f"Resource directory already exists: {Resource_DIR}")
    sys.exit(1)

# Create resource directory
os.makedirs(Resource_DIR, exist_ok)
print(f"Created: {ResourceDir}")

# Files to copy
files_to_copy = [
    "SKILL.md",
    "agents/configurator.md",
    "agents/diagnostics.md",
    "references/configuration.md",
    "references/troubleshooting.md",
    "references/workflows.md",
    "references/development.md",
    "references/translation-workflow.md",
    "references/quality-optimization.md",
    "references/extensions.md",
    "references/repo-map.md",
    "references/prompt-customization.md",
    "eval/evals.json"
]

for src_file in files_to_copy:
    src_path = os.path.join(SKILL_DIR, src_file)
    dst_path = os.path.join(ResourceDir, os.path.basename(src_file))

    if os.path.exists(dst_path):
        print(f"  Copied: {src_file}")
    else:
        print(f"  Warning: {src_file} not found")

        # Remove bin directory if it didn't copy binary files
        bin_dir = os.path.join(SKILL_DIR, "bin")
        if os.path.exists(bin_dir):
            shutil.rmtree(bin_dir)
            print(f"  Removed: {bin_dir}")

print(f"\nCopying {len(files_to_copy)} files to {ResourceDir}")
print(f"Done! Skill files have been copied to: {ResourceDir}")
