# 命令对比分析

## 命令 1 (带 --type)
```bash
uv run aitf translate "/Users/louloulin/lobsterai/project/.cowork-temp/attachments/manual/1DR7615-1773736817029-affd2y.pdf" -y --profile default --rules-profile default -s English -t Chinese --platform deepseek --type BabeldocPdf
```

## 命令 2 (不带 --type)
```bash
uv run aitf translate "/Users/louloulin/lobsterai/project/.cowork-temp/attachments/manual/1DR7615-1773726362822-wxevym.pdf" -y --profile "default" --rules-profile "default" -s "English" -t "Chinese" --platform "deepseek"
```

## 差异对比

| 差异项 | 命令 1 | 命令 2 |
|--------|--------|--------|
| 文件路径 | `1DR7615-1773736817029-affd2y.pdf` | `1DR7615-1773726362822-wxevym.pdf` |
| `--type` 参数 | ✅ 有 `BabeldocPdf` | ❌ 无 |
| 参数引号 | 无引号 | 有引号 |
| Profile | `default` | `"default"` |
| 源语言 | `English` | `"English"` |
| 目标语言 | `Chinese` | `"Chinese"` |
| 平台 | `deepseek` | `"deepseek"` |

## 主要差异

1. **`--type BabeldocPdf`**：命令 1 明确指定了 PDF 类型为 BabeldocPdf，命令 2 没有指定
2. **参数引号**：命令 2 使用了引号包裹参数值，命令 1 没有使用引号

## 建议

使用命令 1 的格式（带 `--type`）来明确指定 PDF 处理方式，确保翻译效果一致。
