# 配置指南

## 配置文件位置

```
Resource/
├── config.json              # 全局配置
├── profiles/
│   ├── default.json        # 默认配置
│   └── {profile}.json     # 用户配置
└── rules_profiles/         # 规则配置
```

## 常用配置项

### 翻译参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `lines_limit` | 每批翻译行数 | 20 |
| `pre_line_counts` | 上下文行数 | 3 |
| `retry_count` | 重试次数 | 3 |
| `round_limit` | 最大轮次 | 3 |
| `enable_smart_round_limit` | 智能轮次限制 | true |

### API 参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `target_platform` | API 平台 | sakura |
| `base_url` | API 地址 | http://127.0.0.1:8080 |
| `request_timeout` | 请求超时(秒) | 60 |
| `api_key` | API 密钥 | - |
| `model` | 模型名称 | - |
| `enable_api_failover` | 启用故障转移 | false |
| `backup_apis` | 备用 API 列表 | [] |

### 响应检查

```json
{
  "response_check_switch": {
    "newline_character_count_check": true,
    "return_to_original_text_check": true,
    "residual_original_text_check": true,
    "reply_format_check": true
  }
}
```

### 模型参数

| 参数 | 说明 | 范围 |
|------|------|------|
| `temperature` | 创造性 | 0.0-2.0 |
| `top_p` | 采样阈值 | 0.0-1.0 |
| `presence_penalty` | 存在惩罚 | -2.0-2.0 |
| `frequency_penalty` | 频率惩罚 | -2.0-2.0 |

### 输出格式

```json
{
  "enable_bilingual_output": false,
  "bilingual_text_order": "translation_first",
  "opencc_preset": "",
  "keep_original_encoding": false
}
```

## 命令行覆盖

所有配置都可以通过命令行参数覆盖：

```bash
# 覆盖单个参数
uv run aitf translate input.txt --lines 30

# 覆盖多个参数
uv run aitf translate input.txt --lines 20 --threads 4 --timeout 120

# 临时指定 API
uv run aitf translate input.txt --platform openai --api-key sk-xxx
```

## Profile 管理

### 创建新 Profile

1. 复制默认配置：
```bash
cp Resource/profiles/default.json Resource/profiles/my_profile.json
```

2. 编辑配置：
```bash
vim Resource/profiles/my_profile.json
```

3. 使用新 profile：
```bash
uv run aitf translate input.txt -p my_profile
```

### 切换默认 Profile

编辑 `Resource/config.json`：
```json
{
  "active_profile": "my_profile"
}
```

## 调试配置

```json
{
  "show_detailed_logs": true,
  "enable_dry_run": false,
  "log_level": "INFO"
}
```
