# Extensions

## Plugin System

- Derive plugins from `PluginScripts/PluginBase.py`.
- Register interest with `add_event(event_name, priority)`.
- Expect plugins to be loaded recursively from `PluginScripts/` by `ModuleFolders/Base/PluginManager.py`.
- Preserve canonical event names exactly. The repo uses `preproces_text` without the second `s`.

## Common Plugin Events

- `text_filter`: Run after source files are read and before deeper preprocessing.
- `preproces_text`: Run before requests are assembled.
- `normalize_text`: Run on each outbound request payload.
- `postprocess_text`: Run after translation and before file output.
- `manual_export`: Run before manual export writes files.
- `translation_completed`: Run after translated files are written.
- `build_rag_context`: Used by the RAG plugin path.
- `polish_completed`: Completion hook for polishing flow.

Inspect `ModuleFolders/Service/TaskExecutor/TaskExecutor.py` and `ModuleFolders/Service/TaskExecutor/TranslatorTask.py` to find actual broadcast points before introducing new behavior.

## Reader And Writer System

- Add built-in readers in `ModuleFolders/Domain/FileReader/FileReader.py`.
- Add built-in writers in `ModuleFolders/Domain/FileOutputer/FileOutputer.py`.
- Use `ModuleFolders/Domain/FileAccessor/` when the format needs structured document access beyond a simple text split.
- Use `ModuleFolders/Domain/FileConverter/` when a format must be converted to an intermediate form before translation.
- Use `PluginScripts/IOPlugins/CustomRegistry.py` for plugin-style custom readers and writers.
- Keep AutoType behavior in mind when adding new format support.

Read `ModuleFolders/Domain/FileAccessor/README.md` for the detailed reader/writer/accessor/converter design before implementing a non-trivial format.

## Config And Profiles

- Treat `Resource/config.json` as the global state file that stores active profile pointers and shared settings.
- Treat `Resource/profiles/` as the main per-profile config store.
- Treat `Resource/rules_profiles/` as the rule-focused profile store.
- Add new config defaults in `ModuleFolders/Infrastructure/TaskConfig/TaskConfig.py`.
- Add metadata, visibility level, and category definitions in `ModuleFolders/Infrastructure/TaskConfig/ConfigRegistry.py`.
- If a config is user-visible, check whether the relevant localization JSON also needs a label or description entry.

## WebServer-Specific Notes

- `Tools/WebServer/web_server.py` is not only an API layer; it also launches CLI worker subprocesses with `--web-mode`.
- Queue execution in the WebServer path is host-integration dependent. Avoid changing queue behavior in the API layer without checking how the CLI host wires it.
- Internal comparison updates rely on `AINIEE_INTERNAL_API_URL`; preserve that path when refactoring task execution or monitor flows.

## Existing In-Repo Docs Worth Loading On Demand

- `PluginScripts/README.md`: Plugin authoring details and event payload examples.
- `ModuleFolders/Domain/FileAccessor/README.md`: Detailed format I/O architecture.
- `ModuleFolders/Service/HttpService/README.md`: Legacy HTTP service behavior; useful only when working on that subsystem, not as the primary WebServer reference.
