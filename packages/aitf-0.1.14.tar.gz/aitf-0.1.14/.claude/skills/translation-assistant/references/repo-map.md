# Repo Map

## Entry Surfaces

- `aitf`: Main shell around the original AITF logic. Owns startup, argparse, profile migration/loading, TUI menus, crash handling, and WebServer launch.
- `Launch.sh` and `prepare.sh`: End-user bootstrap for the CLI path.
- `LaunchGUI.sh` and `Tools/TauriShell/`: Desktop shell bootstrap around the WebServer.

## Python Runtime Layers

- `ModuleFolders/Base/`: Shared base class, event bus, and low-level config read/write helpers.
- `ModuleFolders/Infrastructure/TaskConfig/`: Config defaults, schema metadata, rendering metadata, and task-type enums.
- `ModuleFolders/Infrastructure/LLMRequester/`: Provider-specific requesters and async request path.
- `ModuleFolders/Infrastructure/Cache/`: Translation cache/project/file/item models.
- `ModuleFolders/Service/TaskExecutor/`: Main translation and polishing orchestration.
- `ModuleFolders/Service/Proofreader/`, `TranslationChecker/`, `GlossaryAnalysis/`, `NERProcessor/`: Secondary service layers.
- `ModuleFolders/Domain/`: File readers, writers, accessors, converters, prompt builders, response extraction, and response checks.
- `ModuleFolders/UserInterface/`: TUI menus and editors.

## Web And Desktop

- `Tools/WebServer/web_server.py`: FastAPI app plus host-side orchestration. Starts `uv run aitf_cli.py ... --web-mode` subprocesses for task execution.
- `Tools/WebServer/*.tsx`: React UI, pages, contexts, theme components, and frontend services.
- `Tools/TauriShell/tauri_web_host.py`: Python host that imports `Tools.WebServer.web_server.run_server`.
- `Tools/TauriShell/src-tauri/`: Rust/Tauri shell.

## Extension Points

- `PluginScripts/`: Runtime plugins loaded recursively by `PluginManager`.
- `PluginScripts/IOPlugins/CustomRegistry.py`: Custom reader/writer registry for plugin-style file-format support.
- `ModuleFolders/Domain/FileReader/` and `ModuleFolders/Domain/FileOutputer/`: Built-in format registration.
- `ModuleFolders/Domain/FileAccessor/` and `ModuleFolders/Domain/FileConverter/`: Complex format access and conversion helpers.

## Data And Config

- `Resource/config.json`: Global config plus active profile pointers.
- `Resource/profiles/*.json`: User profile payloads.
- `Resource/rules_profiles/*.json`: Glossary, characterization, examples, and other rule-oriented profile data.
- `Resource/Localization/*.json` and `I18N/*.json`: UI/config localization sources.
- `Resource/Prompt/`: Prompt templates by mode/provider.

## Good First Files By Task

- Runtime bug or task flow regression: `aitf_cli.py`, `ModuleFolders/Service/TaskExecutor/TaskExecutor.py`
- Config/profile issue: `aitf_cli.py`, `ModuleFolders/Infrastructure/TaskConfig/TaskConfig.py`, `ModuleFolders/Infrastructure/TaskConfig/ConfigRegistry.py`
- New file format: `ModuleFolders/Domain/FileReader/FileReader.py`, `ModuleFolders/Domain/FileOutputer/FileOutputer.py`, then the relevant reader/writer/accessor/converter modules
- Plugin behavior: `PluginScripts/PluginBase.py`, `ModuleFolders/Base/PluginManager.py`, then the target plugin
- Web UI or API bug: `Tools/WebServer/web_server.py`, `Tools/WebServer/services/`, `Tools/WebServer/pages/`
- Desktop shell issue: `LaunchGUI.sh`, `Tools/TauriShell/README.md`, `Tools/TauriShell/tauri_web_host.py`, `Tools/TauriShell/src-tauri/src/main.rs`
