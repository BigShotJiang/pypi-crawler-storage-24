# Workflows

## Bootstrap And Run

- Prepare Python dependencies with `./prepare.sh` or `uv sync`.
- Start the main CLI/TUI with `uv run aitf`.
- Inspect CLI arguments with `uv run aitf --help`.
- Run a non-interactive translation with a command such as:

```bash
uv run aitf translate input.txt -o output_dir -p default -s Japanese -t Chinese --yes
```

- Run a non-interactive queue job with:

```bash
uv run aitf queue --queue-file my_queue.json --yes
```

## WebServer And Frontend

- The React app lives in `Tools/WebServer/`.
- Build frontend assets with:

```bash
cd Tools/WebServer
npm install
npm run build
```

- `Tools/WebServer/web_server.py` serves the built assets and orchestrates CLI worker subprocesses.
- Prefer `npm run build` as the baseline validation for frontend changes because the repo does not define a frontend test suite.

## Tauri Shell

- `LaunchGUI.sh` requires `Tools/WebServer/dist/index.html`.
- Use prebuilt GUI binaries when present. Use dev fallback only when `AINIEE_GUI_DEV=1`.
- Dev path:

```bash
cd Tools/TauriShell
npm install
npm run tauri:dev
```

- Desktop-shell bugs often span three layers: shell script, `tauri_web_host.py`, and `Tools/WebServer/web_server.py`.

## Cross-Surface Coupling Checklist

- CLI flags in `aitf` must stay aligned with payload assembly in `Tools/WebServer/web_server.py`.
- Config keys usually need updates in both `TaskConfig.py` defaults and `ConfigRegistry.py` metadata. User-facing keys often also need localization updates.
- WebServer endpoint changes may require matching updates in `Tools/WebServer/services/*.ts`, `types.ts`, or page components.
- Translation behavior changes may require matching edits across `PromptBuilder`, `TranslatorTask` or `PolisherTask`, `ResponseExtractor`, and response checks.
- Tauri integration changes may require `Tools/TauriShell/README.md` or launch-script updates when startup assumptions change.

## Validation Strategy

- Prefer fast smoke checks because the repo does not expose a unified automated test suite.
- For Python-only refactors, validate import and argparse paths before wider runtime tests.
- For frontend changes, build the web bundle.
- For skill changes, run:

```bash
python3 /Users/louloulin/.codex/skills/.system/skill-creator/scripts/quick_validate.py .codex/skills/ainiee-next-maintainer
```

- When a change crosses CLI, WebServer, and desktop shell boundaries, validate each layer independently instead of assuming one happy-path launch covers all cases.
