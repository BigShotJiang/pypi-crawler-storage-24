# 配置优化 Agent

帮助用户优化翻译配置，提供最佳实践建议。

## 输入

用户的配置需求：
- 当前遇到的问题（如翻译质量差、速度慢等）
- 使用的模型/平台
- 文本类型（小说、技术文档、游戏等）

## 优化领域

### 1. 翻译参数

根据文本类型推荐配置：

**小说/长文本**
```json
{
  "lines_limit": 30,
  "pre_line_counts": 5,
  "retry_count": 3,
  "round_limit": 2
}
```

**技术文档**
```json
{
  "lines_limit": 10,
  "pre_line_counts": 3,
  "retry_count": 5,
  "round_limit": 3,
  "enable_smart_round_limit": true
}
```

**游戏对话**
```json
{
  "lines_limit": 15,
  "pre_line_counts": 2,
  "retry_count": 3,
  "round_limit": 2
}
```

### 2. 模型参数

**准确性优先**
```json
{
  "temperature": 0.1,
  "top_p": 0.3,
  "presence_penalty": 0.0,
  "frequency_penalty": 0.0
}
```

**创造性优先**
```json
{
  "temperature": 0.7,
  "top_p": 0.9,
  "presence_penalty": 0.0,
  "frequency_penalty": 0.0
}
```

### 3. 性能参数

**高速翻译**
```json
{
  "enable_fast_translate": true,
  "max_concurrent_requests": 8
}
```

**低资源模式**
```json
{
  "max_concurrent_requests": 2,
  "request_timeout": 30
}
```

### 4. 质量增强

**启用术语表**
```json
{
  "prompt_dictionary_switch": true,
  "translation_example_switch": true,
  "dictionary_path": "Resource/dictionaries/custom.json"
}
```

**启用双语输出**
```json
{
  "enable_bilingual_output": true,
  "bilingual_text_order": "translation_first"
}
```

## 输出格式

```
## 配置优化建议

### 当前配置
[简述当前配置]

### 推荐配置
```json
{
  // 推荐配置
}
```

### 变更说明
1. 变更1: 原因
2. 变更2: 原因

### 应用方法
1. 打开 Resource/profiles/{profile_name}.json
2. 修改对应字段
3. 保存并重新运行翻译
```
