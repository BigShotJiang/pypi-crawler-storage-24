# 翻译问题诊断 Agent

当用户遇到翻译问题时，使用此 agent 进行自动诊断和排查。

## 输入

用户提供的问题描述，包括：
- 错误信息（如果有）
- 使用的命令
- 期望的结果
- 实际发生的情况

## 诊断流程

### 1. 信息收集

首先收集必要信息：

```bash
# 检查项目配置
cat Resource/config.json

# 检查当前 profile
ls Resource/profiles/

# 查看最近日志
ls -la Resource/logs/
```

### 2. 问题分类

根据症状判断问题类型：

| 症状 | 可能原因 |
|------|----------|
| API 连接失败 | 服务未启动、网络问题、配置错误 |
| 翻译结果为空 | 文本格式问题、API 返回异常 |
| 翻译质量差 | 参数配置不当、模型选择错误 |
| 断点续传失败 | 缓存损坏、文件路径变更 |
| 格式丢失 | 文件格式不支持、编码问题 |

### 3. 针对性检查

#### API 问题

```bash
# 测试 API 连接
curl http://127.0.0.1:8080/v1/models

# 检查 profile 中的 API 配置
cat Resource/profiles/{profile}.json | grep -A 10 "target_platform"
```

#### 配置问题

```bash
# 验证配置文件语法
python -c "import json; json.load(open('Resource/profiles/lin.json'))"

# 检查必需字段
cat Resource/profiles/{profile}.json | grep -E "(lines_limit|pre_line_counts|target_platform)"
```

#### 缓存问题

```bash
# 查看缓存状态
ls Resource/cache/{project_name}/

# 检查缓存文件完整性
cat Resource/cache/{project_name}/metadata.json
```

### 4. 生成诊断报告

完成检查后，生成诊断报告：

```
## 诊断报告

### 问题类型
[API/配置/缓存/质量/其他]

### 可能原因
1. 原因1
2. 原因2

### 建议操作
1. 操作1
2. 操作2

### 验证命令
[用于验证修复是否成功的命令]
```

## 输出格式

必须输出以下内容：
1. 问题分类
2. 根本原因分析
3. 建议的解决方案
4. 验证步骤

如果无法确定问题，输出：
```
## 需要更多信息

请提供：
1. 完整的错误信息
2. 使用的命令
3. 配置文件内容（敏感信息可隐藏）
```
