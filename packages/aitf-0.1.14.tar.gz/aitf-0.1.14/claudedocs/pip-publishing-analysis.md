# AiNiee-Next PIP发布全面分析

## 执行摘要

本文档全面分析AiNiee-Next项目发布到PyPI（Python Package Index）的可行性、配置状态、潜在问题和完整实施流程。

### 关键发现

✅ **已配置项**:
- 现代化pyproject.toml配置（使用hatchling构建系统）
- 明确的包名称和版本号
- 完整的依赖列表
- CLI入口点配置

⚠️ **需要改进**:
- 缺少__init__.py在顶层模块
- Resource目录过大（56MB）
- 版本号过旧（0.1.0）
- 缺少详细的元数据
- 需要MANIFEST.in文件

❌ **关键问题**:
- 要求Python严格等于3.12（==3.12.*），限制了兼容性
- 包含大量非代码资源文件
- 缺少自动化发布流程

---

## 1. 当前配置分析

### 1.1 pyproject.toml配置

**当前状态**:
```toml
[project]
name = "ainiee-cli"
version = "0.1.0"
description = "A CLI-based hard fork of AiNiee for batch translation."
readme = "README.md"
requires-python = "==3.12.*"
```

**优点**:
- ✅ 使用现代PEP 621标准
- ✅ 配置简洁清晰
- ✅ 使用hatchling构建系统（现代化选择）

**缺点**:
- ❌ `requires-python = "==3.12.*"` 过于严格
  - 建议改为 `">=3.10,<3.13"` 以支持Python 3.10-3.12
- ⚠️ 缺少重要元数据：
  - 作者信息
  - 许可证声明
  - 项目URL
  - 关键词
  - 分类器

### 1.2 包结构分析

**当前包结构**:
```
AiNiee-Next/
├── ainiee_cli.py              # 主入口点
├── ModuleFolders/             # 核心代码模块
│   ├── Base/
│   ├── CLI/
│   ├── Diagnostic/
│   ├── Domain/
│   ├── Infrastructure/
│   ├── Service/
│   └── UserInterface/
├── Resource/                  # 资源文件（56MB）
│   ├── Prompt/
│   ├── Models/ner/
│   ├── Localization/
│   ├── platforms/Icon/
│   └── ...
├── PluginScripts/             # 插件脚本
├── I18N/                      # 国际化
└── Tools/                     # 工具（WebServer等）
```

**问题分析**:

1. **缺少顶层__init__.py**:
   - ModuleFolders/有__init__.py ✅
   - 但包名不够Pythonic（应为module_folders或ainiee）❌

2. **资源文件过大**:
   ```
   ModuleFolders:  1.6MB  ✅ 合理
   Resource:      56.0MB  ❌ 过大
   PluginScripts: 120KB   ✅ 合理
   I18N:          176KB   ✅ 合理
   ```

3. **包命名问题**:
   - 项目名：`ainiee-cli`
   - 模块名：`ModuleFolders` ❌ 不符合Python命名规范
   - 入口点：`ainiee = "ainiee_cli:main"`

### 1.3 依赖分析

**核心依赖（73个）**:

| 类别 | 依赖项 | 状态 |
|------|--------|------|
| **LLM APIs** | openai, anthropic, cohere, google-genai, boto3 | ✅ |
| **HTTP客户端** | requests, httpx[http2], aiohttp | ✅ |
| **文本处理** | tiktoken, opencc, beautifulsoup4, lxml | ✅ |
| **文件格式** | python-pptx, EbookLib, polib, pymupdf | ✅ |
| **数据处理** | pandas, numpy, pydantic | ✅ |
| **CLI/TUI** | rich, tqdm | ✅ |
| **ML/NLP** | spacy, scikit-learn, mediapipe | ⚠️ 重 |
| **Web框架** | fastapi, uvicorn | ⚠️ 可选 |
| **PDF处理** | pdfminer-six, pymupdf, babeldoc | ⚠️ 重 |
| **OCR** | rapidocr-onnxruntime | ⚠️ 重 |

**依赖问题**:

1. **依赖过多（73个）**:
   - PyPI有包大小限制
   - 安装时间长
   - 依赖冲突风险

2. **重型依赖**:
   - mediapipe: ~50MB
   - onnxruntime: ~15MB
   - scikit-learn: ~30MB
   - pymupdf: ~20MB

3. **缺少可选依赖分组**:
   ```toml
   # 建议分组
   [project.optional-dependencies]
   dev = ["pytest", "black", "mypy"]
   web = ["fastapi", "uvicorn"]
   ocr = ["rapidocr-onnxruntime"]
   pdf = ["pymupdf", "pdfminer-six"]
   full = [...]  # 所有依赖
   ```

### 1.4 构建配置

**当前构建配置**:
```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["ModuleFolders", "Resource", "PluginScripts", "StevExtraction", "I18N"]

[tool.hatch.build.targets.sdist]
include = ["ainiee_cli.py", "pyproject.toml", "README.md", "LICENSE"]
```

**问题**:
- ❌ wheel包含Resource（56MB）→ 包过大
- ❌ sdist缺少必要文件
- ❌ 没有排除开发文件
- ❌ 缺少MANIFEST.in

---

## 2. PIP发布流程详解

### 2.1 标准发布流程

#### 步骤1：准备工作

**1.1 更新pyproject.toml**:
```toml
[project]
name = "ainiee-cli"
version = "1.0.0"  # 更新版本
description = "Professional CLI tool for batch translation with AI-powered engines"
readme = "README.md"
license = {text = "AGPL-3.0"}
authors = [
    {name = "Your Name", email = "your.email@example.com"}
]
maintainers = [
    {name = "Your Name", email = "your.email@example.com"}
]
keywords = ["translation", "ai", "cli", "localization", "batch-translation"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Environment :: Console",
    "Intended Audience :: Developers",
    "Intended Audience :: End Users/Desktop",
    "License :: OSI Approved :: GNU Affero General Public License v3",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Topic :: Text Processing :: Linguistic",
    "Topic :: Scientific/Engineering :: Artificial Intelligence",
    "Typing :: Typed",
]
requires-python = ">=3.10,<3.13"
dependencies = [
    # 核心依赖（精简版）
    "openai>=1.59.3",
    "tiktoken>=0.9.0",
    "rich>=13.9.4",
    "tqdm>=4.67.1",
    "PyYAML",
    "requests",
    "httpx[http2]>=0.27.0",
    # ... 其他核心依赖
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "pytest-cov>=4.0",
    "black>=23.0",
    "mypy>=1.0",
    "ruff>=0.1.0",
]
web = [
    "fastapi>=0.128.0",
    "uvicorn[standard]>=0.40.0",
    "aiohttp>=3.13.2",
]
ocr = [
    "rapidocr-onnxruntime>=1.4.4",
    "mediapipe",
]
pdf = [
    "pdfminer-six==20250416",
    "pymupdf>=1.25.1",
    "babeldoc>=0.5.0",
]
ml = [
    "spacy",
    "scikit-learn>=1.7.1",
    "numpy>=2.0.2",
]
full = [
    "ainiee-cli[web,ocr,pdf,ml]",
]

[project.urls]
Homepage = "https://github.com/ShadowLoveLove/AiNiee-Next"
Documentation = "https://github.com/ShadowLoveLove/AiNiee-Next#readme"
Repository = "https://github.com/ShadowLoveLove/AiNiee-Next.git"
Issues = "https://github.com/ShadowLoveLove/AiNiee-Next/issues"
Changelog = "https://github.com/ShadowLoveLove/AiNiee-Next/blob/main/CHANGELOG.md"

[project.scripts]
ainiee = "ainiee_cli:main"
ainiee-cli = "ainiee_cli:main"
```

**1.2 创建MANIFEST.in**:
```
include LICENSE
include README.md
include README_EN.md
include pyproject.toml
include requirements.txt

# 包含资源文件
recursive-include Resource *.json *.txt *.md
recursive-include Resource/Prompt *.txt
recursive-include Resource/Localization *.json
recursive-include I18N *.json

# 排除不必要的文件
recursive-exclude Resource/Models *
recursive-exclude Resource/cache *
recursive-exclude * __pycache__
recursive-exclude * *.py[co]
recursive-exclude * .DS_Store
recursive-exclude * *.log
recursive-exclude .git *
recursive-exclude .github *
recursive-exclude Tests *
recursive-exclude Tools/WebServer/node_modules *
```

**1.3 优化Resource目录**:
```bash
# 方案1: 排除大型模型文件
# 将模型文件外置，首次运行时下载

# 方案2: 压缩资源
# 使用压缩的资源文件

# 方案3: 分离资源包
# 创建 ainiee-cli-resources 独立包
```

#### 步骤2：本地测试

**2.1 安装构建工具**:
```bash
pip install --upgrade pip build twine
# 或使用uv
uv pip install --upgrade build twine
```

**2.2 构建包**:
```bash
# 清理旧构建
rm -rf dist/ build/ *.egg-info

# 构建源码分发包和wheel
python -m build

# 或使用uv
uv build
```

**2.3 检查构建结果**:
```bash
# 查看生成的文件
ls -lh dist/

# 检查包内容
tar -tzf dist/ainiee_cli-1.0.0.tar.gz | head -20
unzip -l dist/ainiee_cli-1.0.0-py3-none-any.whl | head -20

# 检查包大小
du -sh dist/*
```

**2.4 本地安装测试**:
```bash
# 创建测试环境
python -m venv test-env
source test-env/bin/activate  # Linux/Mac
# test-env\Scripts\activate  # Windows

# 安装构建的包
pip install dist/ainiee_cli-1.0.0-py3-none-any.whl

# 测试命令
ainiee --help
ainiee-cli --version

# 测试导入
python -c "import ainiee_cli; print('OK')"
```

**2.5 使用Twine检查**:
```bash
# 检查包元数据
twine check dist/*

# 应该看到:
# Checking dist/ainiee_cli-1.0.0-py3-none-any.whl: PASSED
# Checking dist/ainiee_cli-1.0.0.tar.gz: PASSED
```

#### 步骤3：注册PyPI账户

**3.1 创建账户**:
- 访问 https://pypi.org/account/register/
- 填写用户名、邮箱、密码
- 验证邮箱

**3.2 启用2FA（强烈建议）**:
- 登录PyPI
- 进入 Account Settings → Two-factor authentication
- 使用认证器应用（Google Authenticator等）

**3.3 创建API Token**:
- 进入 Account Settings → API tokens
- 点击 "Add API token"
- Scope: 选择 "Entire account" (首次发布) 或特定项目
- 复制token（只显示一次）：
  ```
  pypi-AgEIcHlwaS5vcmcCJD...
  ```

**3.4 配置凭证**:

**方法1: .pypirc文件**:
```bash
# 创建 ~/.pypirc
cat > ~/.pypirc << EOF
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-AgEIcHlwaS5vcmcCJD...

[testpypi]
username = __token__
password = pypi-AgEIcHlwaS5vcmcCJD...
repository = https://test.pypi.org/legacy/
EOF

chmod 600 ~/.pypirc
```

**方法2: 环境变量**:
```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-AgEIcHlwaS5vcmcCJD...
```

#### 步骤4：发布到TestPyPI（推荐先测试）

**4.1 发布到TestPyPI**:
```bash
# 上传到TestPyPI
twine upload --repository testpypi dist/*

# 或使用环境变量
twine upload --repository-url https://test.pypi.org/legacy/ dist/*
```

**4.2 从TestPyPI安装测试**:
```bash
# 创建新的测试环境
python -m venv test-env-2
source test-env-2/bin/activate

# 从TestPyPI安装
pip install --index-url https://test.pypi.org/simple/ ainiee-cli

# 测试
ainiee --version
```

**4.3 验证元数据**:
- 访问 https://test.pypi.org/project/ainiee-cli/
- 检查描述、版本、依赖等
- 确保README渲染正确

#### 步骤5：发布到正式PyPI

**5.1 最终检查**:
```bash
# 确认版本号正确
grep version pyproject.toml

# 确认CHANGELOG已更新
cat CHANGELOG.md

# 确认git标签
git tag v1.0.0
git push origin v1.0.0
```

**5.2 上传到PyPI**:
```bash
# 上传到PyPI
twine upload dist/*
```

**5.3 验证发布**:
```bash
# 等待几分钟让PyPI索引更新
# 访问 https://pypi.org/project/ainiee-cli/

# 从PyPI安装
pip install ainiee-cli

# 测试安装
ainiee --version
```

### 2.2 自动化发布流程（推荐）

#### 使用GitHub Actions

**创建 .github/workflows/publish.yml**:
```yaml
name: Publish to PyPI

on:
  release:
    types: [published]
  workflow_dispatch:
    inputs:
      target:
        description: 'Target environment'
        required: true
        default: 'testpypi'
        type: choice
        options:
          - testpypi
          - pypi

jobs:
  publish:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'

      - name: Install build tools
        run: |
          python -m pip install --upgrade pip
          pip install build twine

      - name: Build package
        run: python -m build

      - name: Check package
        run: twine check dist/*

      - name: Publish to TestPyPI
        if: github.event.inputs.target == 'testpypi' || github.event.release.prerelease
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.TEST_PYPI_API_TOKEN }}
        run: |
          twine upload --repository testpypi dist/*

      - name: Publish to PyPI
        if: github.event.inputs.target == 'pypi' || (github.event_name == 'release' && !github.event.release.prerelease)
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
        run: |
          twine upload dist/*
```

**配置GitHub Secrets**:
1. 进入仓库 Settings → Secrets and variables → Actions
2. 添加以下secrets:
   - `PYPI_API_TOKEN`: PyPI的API token
   - `TEST_PYPI_API_TOKEN`: TestPyPI的API token

**触发发布**:
- **自动**: 创建GitHub Release时自动触发
- **手动**: Actions → Publish to PyPI → Run workflow

---

## 3. 问题与解决方案

### 3.1 Resource目录过大（56MB）

**问题**: PyPI对包大小有限制（单文件60MB，总大小合理）

**解决方案**:

#### 方案1: 排除大型模型文件（推荐）
```toml
# pyproject.toml
[tool.hatch.build.targets.wheel]
packages = ["ModuleFolders", "PluginScripts", "I18N"]
# 排除Resource/Models

[tool.hatch.build.targets.wheel.exclude]
exclude = [
    "Resource/Models/**",  # NER模型（~50MB）
    "Resource/cache/**",
    "*.log",
    "*.pyc",
]
```

首次运行时自动下载模型:
```python
# ModuleFolders/Service/NERService/NERService.py
def ensure_model_downloaded():
    model_path = Path("Resource/Models/ner/ja_core_news_md")
    if not model_path.exists():
        logger.info("Downloading NER model...")
        # 使用spacy download或手动下载
        subprocess.run(["python", "-m", "spacy", "download", "ja_core_news_md"])
```

#### 方案2: 分离资源包
```bash
# 创建独立的资源包
ainiee-cli/               # 主包（代码+小型资源）
ainiee-cli-resources/     # 资源包（模型+大型资源）
ainiee-cli-full/          # 元包（依赖前两者）
```

#### 方案3: 使用package_data
```toml
[tool.hatch.build.targets.wheel]
packages = ["ModuleFolders", "PluginScripts", "I18N"]

[tool.hatch.build.targets.wheel.shared-data]
# 将资源安装到独立目录
"Resource/Prompt" = "share/ainiee/Prompt"
"Resource/Localization" = "share/ainiee/Localization"
```

### 3.2 Python版本限制过严

**问题**: `requires-python = "==3.12.*"` 限制了用户群

**解决方案**:
```toml
requires-python = ">=3.10,<3.13"
```

**理由**:
- Python 3.10+: 支持match语句、类型提示改进
- Python 3.13: 可能有兼容性问题，暂时排除
- 增加潜在用户数量

### 3.3 包命名不规范

**问题**: `ModuleFolders` 不符合Python命名规范

**解决方案**:

#### 方案1: 重命名（推荐长期方案）
```bash
# 重命名模块
git mv ModuleFolders ainiee

# 更新所有导入
find . -name "*.py" -exec sed -i 's/from ModuleFolders/from ainiee/g' {} \;

# 更新pyproject.toml
[tool.hatch.build.targets.wheel]
packages = ["ainiee", "PluginScripts", "I18N"]
```

#### 方案2: 保持现有名称（短期方案）
```toml
# 不改变现有结构，仅优化包配置
[tool.hatch.build.targets.wheel]
packages = ["ModuleFolders", "PluginScripts", "I18N"]
```

### 3.4 依赖过多

**问题**: 73个直接依赖，安装时间长，冲突风险

**解决方案**: 分组为可选依赖

```toml
[project]
dependencies = [
    # 核心依赖（~20个）
    "openai>=1.59.3",
    "tiktoken>=0.9.0",
    "rich>=13.9.4",
    "tqdm>=4.67.1",
    "PyYAML",
    "requests",
    "httpx[http2]>=0.27.0",
    "pydantic>=2.10.6",
    "tenacity>=9.0.0",
    "orjson>=3.10.14",
    "opencc",
    "chardet",
    "natsort",
]

[project.optional-dependencies]
web = [
    "fastapi>=0.128.0",
    "uvicorn[standard]>=0.40.0",
    "aiohttp>=3.13.2",
    "aiohttp-cors>=0.8.1",
]

ocr = [
    "rapidocr-onnxruntime>=1.4.4",
    "mediapipe",
    "Pillow",
]

pdf = [
    "pdfminer-six==20250416",
    "pymupdf>=1.25.1",
    "babeldoc>=0.5.0",
]

ml = [
    "spacy",
    "scikit-learn>=1.7.1",
    "numpy>=2.0.2",
    "sudachipy",
    "sudachidict-core",
]

file-formats = [
    "python-pptx",
    "EbookLib",
    "polib",
    "openpyxl",
    "pandas",
    "beautifulsoup4",
    "lxml",
]

full = [
    "ainiee-cli[web,ocr,pdf,ml,file-formats]",
]

dev = [
    "pytest>=7.0",
    "pytest-cov>=4.0",
    "black>=23.0",
    "mypy>=1.0",
    "ruff>=0.1.0",
]
```

用户安装:
```bash
pip install ainiee-cli              # 核心功能
pip install ainiee-cli[web]         # + Web UI
pip install ainiee-cli[full]        # 所有功能
pip install ainiee-cli[dev]         # 开发环境
```

### 3.5 缺少版本管理

**问题**: 版本号0.1.0过旧，缺少版本管理策略

**解决方案**:

#### 实施语义化版本
```
MAJOR.MINOR.PATCH

MAJOR: 不兼容的API变更
MINOR: 向后兼容的功能新增
PATCH: 向后兼容的bug修复
```

#### 使用bump2version
```bash
pip install bump2version

# 创建 .bumpversion.cfg
[bumpversion]
current_version = 1.0.0
commit = True
tag = True

[bumpversion:file:pyproject.toml]
search = version = "{current_version}"
replace = version = "{new_version}"

[bumpversion:file:ainiee_cli.py]
search = __version__ = "{current_version}"
replace = __version__ = "{new_version}"
```

使用:
```bash
bumpversion patch  # 1.0.0 → 1.0.1
bumpversion minor  # 1.0.1 → 1.1.0
bumpversion major  # 1.1.0 → 2.0.0
```

---

## 4. 完整发布检查清单

### 发布前检查

#### 代码质量
- [ ] 所有测试通过
- [ ] 代码格式化（black/isort）
- [ ] 类型检查（mypy）
- [ ] Linting（ruff/pylint）
- [ ] 安全扫描（safety/bandit）

#### 文档
- [ ] README.md更新
- [ ] CHANGELOG.md更新
- [ ] LICENSE文件存在
- [ ] 代码注释完整
- [ ] API文档生成

#### 配置
- [ ] pyproject.toml完整
- [ ] version号正确
- [ ] 依赖列表准确
- [ ] 入口点配置正确
- [ ] .gitignore完整

#### 构建
- [ ] 本地构建成功
- [ ] 包大小合理（<50MB）
- [ ] twine check通过
- [ ] 本地安装测试通过
- [ ] 功能测试通过

### 发布流程

#### TestPyPI测试
- [ ] 上传到TestPyPI成功
- [ ] 从TestPyPI安装成功
- [ ] 元数据正确显示
- [ ] README渲染正确
- [ ] 依赖安装正确

#### 正式发布
- [ ] 创建git tag
- [ ] 创建GitHub Release
- [ ] 上传到PyPI成功
- [ ] PyPI页面正确显示
- [ ] 从PyPI安装成功
- [ ] 功能验证通过

#### 发布后
- [ ] 公告发布（GitHub Discussions, 社交媒体）
- [ ] 更新文档网站
- [ ] 监控问题反馈
- [ ] 准备hotfix（如需要）

---

## 5. 替代发布方案

### 5.1 发布到其他平台

#### Conda/Anaconda
```bash
# 安装conda-build
conda install conda-build

# 创建meta.yaml
package:
  name: ainiee-cli
  version: "1.0.0"

source:
  git_url: https://github.com/ShadowLoveLove/AiNiee-Next.git

requirements:
  host:
    - python >=3.10,<3.13
    - pip
  run:
    - python >=3.10,<3.13
    # ... 依赖列表

# 构建
conda build .

# 上传到Anaconda Cloud
anaconda upload /path/to/package.tar.bz2
```

#### Docker Hub
```dockerfile
# Dockerfile
FROM python:3.12-slim

WORKDIR /app

# 安装依赖
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# 复制代码
COPY . .

# 安装包
RUN pip install -e .

# 设置入口点
ENTRYPOINT ["ainiee"]
CMD ["--help"]
```

```bash
# 构建镜像
docker build -t ainiee-cli:latest .

# 推送到Docker Hub
docker push yourusername/ainiee-cli:latest
```

### 5.2 私有PyPI

#### 使用devpi
```bash
# 安装devpi
pip install devpi-server devpi-web

# 初始化服务器
devpi-init

# 启动服务器
devpi-server --host 0.0.0.0 --port 3141

# 客户端配置
devpi use http://localhost:3141
devpi login root
devpi create ainiee

# 上传
devpi upload
```

#### 使用pypiserver
```bash
# 安装pypiserver
pip install pypiserver

# 创建包目录
mkdir ~/packages

# 上传包
cp dist/* ~/packages/

# 启动服务器
pypi-server run -p 8080 ~/packages
```

---

## 6. 最佳实践建议

### 6.1 版本管理
- ✅ 使用语义化版本
- ✅ 维护CHANGELOG.md
- ✅ 使用git tags
- ✅ 预发布版本（1.0.0rc1）
- ✅ 开发版本（1.0.0.dev1）

### 6.2 依赖管理
- ✅ 定期更新依赖
- ✅ 使用dependabot/renovate
- ✅ 固定关键依赖版本
- ✅ 使用optional dependencies
- ✅ 测试多个依赖版本

### 6.3 文档
- ✅ 完整的README
- ✅ 清晰的安装指南
- ✅ 使用示例
- ✅ API参考
- ✅ 贡献指南

### 6.4 测试
- ✅ 单元测试
- ✅ 集成测试
- ✅ 端到端测试
- ✅ 多Python版本测试
- ✅ 多平台测试

### 6.5 安全
- ✅ 使用API tokens
- ✅ 启用2FA
- ✅ 定期轮换token
- ✅ 审计依赖安全
- ✅ 使用trusted publishers

### 6.6 监控
- ✅ 监控下载量
- ✅ 监控问题报告
- ✅ 监控依赖更新
- ✅ 监控性能指标
- ✅ 设置告警

---

## 7. 实施路线图

### 阶段1: 准备（1-2周）
1. 重构包结构（可选）
2. 优化Resource目录
3. 更新pyproject.toml
4. 创建MANIFEST.in
5. 添加测试
6. 完善文档

### 阶段2: 内部测试（1周）
1. 本地构建测试
2. TestPyPI发布测试
3. 多平台安装测试
4. 功能回归测试
5. 性能测试

### 阶段3: Alpha发布（1周）
1. 发布1.0.0a1到TestPyPI
2. 邀请内部用户测试
3. 收集反馈
4. 修复问题
5. 迭代改进

### 阶段4: Beta发布（2周）
1. 发布1.0.0b1到TestPyPI
2. 公开测试
3. 收集更多反馈
4. 完善文档
5. 准备正式发布

### 阶段5: 正式发布（1周）
1. 发布1.0.0到PyPI
2. 创建GitHub Release
3. 公告发布
4. 监控反馈
5. 支持用户

### 阶段6: 持续维护
1. 监控问题
2. 定期更新
3. 回答用户问题
4. 改进功能
5. 发布新版本

---

## 8. 总结

### 可行性评估

| 方面 | 评分 | 说明 |
|------|------|------|
| **配置完整性** | ⭐⭐⭐☆☆ | 有基础配置，需要完善 |
| **代码质量** | ⭐⭐⭐⭐☆ | 功能完整，缺少测试 |
| **文档完善度** | ⭐⭐⭐⭐☆ | README详细，需要API文档 |
| **依赖管理** | ⭐⭐☆☆☆ | 依赖过多，需要优化 |
| **包大小** | ⭐⭐☆☆☆ | Resource过大，需要优化 |
| **兼容性** | ⭐⭐☆☆☆ | Python版本限制过严 |

**总体评估**: ⭐⭐⭐☆☆ (3/5) - **可以发布，但需要优化**

### 关键改进点

#### 必须解决（发布前）
1. ✅ 优化Resource目录大小（目标 <30MB）
2. ✅ 放宽Python版本限制（>=3.10,<3.13）
3. ✅ 完善pyproject.toml元数据
4. ✅ 创建MANIFEST.in

#### 强烈建议（提升质量）
1. 🔄 分离可选依赖
2. 🔄 添加基础测试
3. 🔄 设置CI/CD
4. 🔄 改进包命名

#### 可选改进（长期优化）
1. 💡 重命名ModuleFolders → ainiee
2. 💡 添加类型提示
3. 💡 创建文档网站
4. 💡 多平台发布（conda, docker）

### 预期成果

**优化后**:
- 包大小: ~20-30MB（vs 当前~80MB）
- 安装时间: ~1-2分钟（vs 当前~5分钟）
- 依赖数量: ~20核心 + 可选（vs 当前73全部）
- 兼容性: Python 3.10-3.12（vs 仅3.12）
- 用户群: 扩大~3-5倍

**发布时间线**:
- 准备: 1-2周
- 测试: 1周
- Alpha: 1周
- Beta: 2周
- 正式: 1周
- **总计: 6-7周**

---

## 附录A: 完整pyproject.toml示例

```toml
[build-system]
requires = ["hatchling>=1.21.0"]
build-backend = "hatchling.build"

[project]
name = "ainiee-cli"
version = "1.0.0"
description = "Professional CLI tool for batch translation with AI-powered engines"
readme = "README.md"
license = {text = "AGPL-3.0"}
authors = [
    {name = "ShadowLoveElysia", email = "shadow@example.com"}
]
maintainers = [
    {name = "ShadowLoveElysia", email = "shadow@example.com"}
]
keywords = [
    "translation",
    "ai",
    "cli",
    "localization",
    "batch-translation",
    "machine-translation",
    "llm",
    "openai",
    "gpt",
]
classifiers = [
    "Development Status :: 4 - Beta",
    "Environment :: Console",
    "Intended Audience :: Developers",
    "Intended Audience :: End Users/Desktop",
    "Intended Audience :: Science/Research",
    "License :: OSI Approved :: GNU Affero General Public License v3",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: Implementation :: CPython",
    "Topic :: Text Processing :: Linguistic",
    "Topic :: Scientific/Engineering :: Artificial Intelligence",
    "Topic :: Software Development :: Internationalization",
    "Typing :: Typed",
]
requires-python = ">=3.10,<3.13"
dependencies = [
    # Core - LLM APIs
    "openai>=1.59.3",
    "anthropic",
    "tiktoken>=0.9.0",

    # Core - HTTP
    "requests",
    "httpx[http2]>=0.27.0",
    "tenacity>=9.0.0",

    # Core - CLI/TUI
    "rich>=13.9.4",
    "tqdm>=4.67.1",
    "configargparse>=1.7",

    # Core - Data Processing
    "pydantic>=2.10.6",
    "orjson>=3.10.14",
    "PyYAML",
    "toml>=0.10.2",
    "msgpack>=1.1.0",

    # Core - Text Processing
    "opencc",
    "chardet",
    "natsort",
    "python-rapidjson",
    "jaconv",

    # Core - Utilities
    "psutil>=7.0.0",
    "peewee>=3.17.8",
]

[project.optional-dependencies]
web = [
    "fastapi>=0.128.0",
    "uvicorn[standard]>=0.40.0",
    "aiohttp>=3.13.2",
    "aiohttp-cors>=0.8.1",
    "python-multipart",
]

ocr = [
    "rapidocr-onnxruntime>=1.4.4",
    "mediapipe",
    "Pillow",
]

pdf = [
    "pdfminer-six==20250416",
    "pymupdf>=1.25.1",
    "babeldoc>=0.5.0",
]

ml = [
    "spacy",
    "scikit-learn>=1.7.1",
    "numpy>=2.0.2",
    "sudachipy",
    "sudachidict-core",
    "language-data",
    "langcodes",
]

file-formats = [
    "python-pptx",
    "EbookLib",
    "polib",
    "openpyxl",
    "pandas",
    "beautifulsoup4",
    "lxml",
    "EbookLib",
    "protobuf==4.25.7",
    "pyzstd",
    "rtree",
    "xsdata[cli,lxml,soap]>=24.12",
    "freetype-py>=2.5.1",
    "python-levenshtein>=0.27.1",
    "bitstring>=4.3.0",
    "msgspec",
]

cloud-apis = [
    "boto3",
    "cohere",
    "google-genai",
    "huggingface-hub>=0.27.0",
]

full = [
    "ainiee-cli[web,ocr,pdf,ml,file-formats,cloud-apis]",
]

dev = [
    "pytest>=7.0",
    "pytest-cov>=4.0",
    "pytest-asyncio>=0.21",
    "black>=23.0",
    "isort>=5.12",
    "mypy>=1.0",
    "ruff>=0.1.0",
    "types-PyYAML",
    "types-requests",
    "bump2version>=1.0",
]

[project.urls]
Homepage = "https://github.com/ShadowLoveElysia/AiNiee-Next"
Documentation = "https://github.com/ShadowLoveElysia/AiNiee-Next#readme"
Repository = "https://github.com/louloulin/tf.git"
Issues = "https://github.com/ShadowLoveElysia/AiNiee-Next/issues"
Changelog = "https://github.com/ShadowLoveElysia/AiNiee-Next/blob/main/CHANGELOG.md"
Download = "https://pypi.org/project/ainiee-cli/#files"

[project.scripts]
ainiee = "ainiee_cli:main"
ainiee-cli = "ainiee_cli:main"

[project.gui-scripts]
# 可选：GUI入口点

[tool.hatch.version]
path = "ainiee_cli.py"
pattern = "__version__\\s*=\\s*['\"](?P<version>[^'\"]+)['\"]"

[tool.hatch.build.targets.wheel]
packages = ["ModuleFolders", "PluginScripts", "I18N"]
exclude = [
    "Resource/Models/**",
    "Resource/cache/**",
    "*.log",
    "*.pyc",
    "__pycache__",
    ".DS_Store",
]

[tool.hatch.build.targets.wheel.shared-data]
"Resource/Prompt" = "share/ainiee/Prompt"
"Resource/Localization" = "share/ainiee/Localization"
"Resource/platforms" = "share/ainiee/platforms"

[tool.hatch.build.targets.sdist]
include = [
    "ainiee_cli.py",
    "pyproject.toml",
    "README.md",
    "README_EN.md",
    "LICENSE",
    "CHANGELOG.md",
    "ModuleFolders/**",
    "PluginScripts/**",
    "I18N/**",
    "Resource/Prompt/**",
    "Resource/Localization/**",
    "Resource/platforms/preset.json",
]
exclude = [
    "Resource/Models/**",
    "Resource/cache/**",
    "Tools/WebServer/node_modules/**",
    ".github/**",
    "Tests/**",
    "*.log",
]

[tool.black]
line-length = 100
target-version = ["py310", "py311", "py312"]
include = '\.pyi?$'
extend-exclude = '''
/(
    \.git
  | \.hg
  | \.mypy_cache
  | \.tox
  | \.venv
  | _build
  | buck-out
  | build
  | dist
  | Resource
)/
'''

[tool.isort]
profile = "black"
line_length = 100
skip_gitignore = true
skip = ["Resource", "Tools/WebServer/node_modules"]

[tool.mypy]
python_version = "3.12"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = false
disallow_incomplete_defs = false
check_untyped_defs = true
ignore_missing_imports = true

[tool.ruff]
line-length = 100
target-version = "py312"
select = ["E", "F", "W", "I", "N", "UP", "B", "A", "C4", "PT"]
ignore = ["E501", "B008"]
exclude = [
    ".git",
    "__pycache__",
    "build",
    "dist",
    "Resource",
    "Tools/WebServer/node_modules",
]

[tool.pytest.ini_options]
testpaths = ["Tests"]
python_files = "test_*.py"
python_classes = "Test*"
python_functions = "test_*"
addopts = "-v --cov=ModuleFolders --cov-report=term-missing"
```

---

## 附录B: MANIFEST.in示例

```
# 包含许可和文档
include LICENSE
include README.md
include README_EN.md
include CHANGELOG.md
include pyproject.toml

# 包含必要的资源文件
recursive-include Resource/Prompt *.txt *.md
recursive-include Resource/Localization *.json
recursive-include Resource/Regex *.json
recursive-include Resource/platforms *.json
recursive-include I18N *.json

# 包含插件
recursive-include PluginScripts *.py README.md

# 排除大型模型文件
recursive-exclude Resource/Models *

# 排除开发文件
recursive-exclude * __pycache__
recursive-exclude * *.py[co]
recursive-exclude * .DS_Store
recursive-exclude * *.log
recursive-exclude * .git*
recursive-exclude .github *
recursive-exclude Tests *
recursive-exclude Tools/WebServer/node_modules *
recursive-exclude Tools/WebServer/dist *
recursive-exclude build *
recursive-exclude dist *
recursive-exclude *.egg-info *

# 排除IDE配置
exclude .vscode
exclude .idea
exclude *.swp
exclude *.swo

# 排除缓存
recursive-exclude Resource/cache *
recursive-exclude .pytest_cache *
recursive-exclude .mypy_cache *
recursive-exclude .ruff_cache *
```

---

## 附录C: GitHub Actions发布配置

```yaml
# .github/workflows/publish.yml
name: Publish to PyPI

on:
  push:
    tags:
      - 'v*'
  release:
    types: [published]
  workflow_dispatch:

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.10', '3.11', '3.12']

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python ${{ matrix.python-version }}
        uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}

      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -e .[dev]

      - name: Run tests
        run: |
          pytest Tests/ -v --cov=ModuleFolders

      - name: Upload coverage
        uses: codecov/codecov-action@v3

  build:
    needs: test
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'

      - name: Install build tools
        run: |
          python -m pip install --upgrade pip
          pip install build twine

      - name: Build package
        run: python -m build

      - name: Check package
        run: twine check dist/*

      - name: Upload artifacts
        uses: actions/upload-artifact@v3
        with:
          name: dist
          path: dist/

  publish-testpypi:
    needs: build
    runs-on: ubuntu-latest
    if: github.event_name == 'workflow_dispatch' || (github.event_name == 'release' && github.event.release.prerelease)

    steps:
      - name: Download artifacts
        uses: actions/download-artifact@v3
        with:
          name: dist
          path: dist/

      - name: Publish to TestPyPI
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.TEST_PYPI_API_TOKEN }}
        run: twine upload --repository testpypi dist/*

  publish-pypi:
    needs: build
    runs-on: ubuntu-latest
    if: github.event_name == 'release' && !github.event.release.prerelease

    steps:
      - name: Download artifacts
        uses: actions/download-artifact@v3
        with:
          name: dist
          path: dist/

      - name: Publish to PyPI
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
        run: twine upload dist/*

  notify:
    needs: [publish-pypi, publish-testpypi]
    runs-on: ubuntu-latest
    if: always()

    steps:
      - name: Send notification
        uses: 8398a7/action-slack@v3
        with:
          status: ${{ job.status }}
          text: |
            Release ${{ github.ref_name }} published!
            ${{ job.status }}
          webhook_url: ${{ secrets.SLACK_WEBHOOK }}
```

---

**文档版本**: 1.0.0
**最后更新**: 2025-01-14
**作者**: Claude Code Analysis
**适用版本**: AiNiee-Next v1.0.0+
