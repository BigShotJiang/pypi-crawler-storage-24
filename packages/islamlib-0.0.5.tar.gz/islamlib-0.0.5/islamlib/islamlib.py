import json
import os

# ── تحميل الملفات مرة واحدة ──────────────────────────────────────────
_BASE = os.path.join(os.path.dirname(__file__), "data", "quran")

def _load(filename):
    with open(os.path.join(_BASE, filename), encoding="utf-8") as f:
        return json.load(f)

_SOAR           = _load("soar_names.json")
_QURAN_TASHKEEL = _load("whole_quran_tashkeel.json")
_QURAN_NO_TASH  = _load("whole_quran_no_tashkeel.json")
_PAGES          = _load("pages.json")

# ── دوال القرآن ───────────────────────────────────────────────────────
def list_surahs():
    """يرجع قائمة بأسماء كل السور"""
    return _SOAR.copy()

def get_surah(name, tashkeel=True):
    """
    يرجع سورة كاملة كـ list من الآيات
    
    مثال:
        get_surah("الفاتحة")
        get_surah("البقرة", tashkeel=False)
    """
    quran = _QURAN_TASHKEEL if tashkeel else _QURAN_NO_TASH
    if name not in quran:
        raise ValueError(f"السورة '{name}' مش موجودة. استخدم list_surahs() تشوف الأسماء الصح.")
    return quran[name].copy()

def get_ayah(surah, number, tashkeel=True):
    """
    يرجع آية معينة
    الرقم يبدأ من 1
    
    مثال:
        get_ayah("الفاتحة", 1)
        get_ayah("البقرة", 255, tashkeel=False)
    """
    ayahs = get_surah(surah, tashkeel)
    if number < 1 or number > len(ayahs):
        raise ValueError(f"رقم الآية {number} مش موجود في سورة {surah}. عدد الآيات: {len(ayahs)}")
    return ayahs[number - 1]

def get_surah_info(name):
    """
    يرجع معلومات عن السورة
    
    مثال:
        get_surah_info("البقرة")
        # {'name': 'البقرة', 'number': 2, 'total_ayahs': 286}
    """
    if name not in _SOAR:
        raise ValueError(f"السورة '{name}' مش موجودة.")
    return {
        "name": name,
        "number": _SOAR.index(name) + 1,
        "total_ayahs": len(_QURAN_TASHKEEL[name])
    }

def get_page(number, tashkeel=True):
    """
    يرجع محتوى صفحة معينة كـ list من الآيات
    الرقم يبدأ من 1
    
    مثال:
        get_page(1)
        get_page(50, tashkeel=False)
    """
    if number < 1 or number > len(_PAGES):
        raise ValueError(f"رقم الصفحة {number} مش موجود. عدد الصفحات: {len(_PAGES)}")
    
    page = _PAGES[number - 1]
    quran = _QURAN_TASHKEEL if tashkeel else _QURAN_NO_TASH

    result = []
    surahs = _SOAR

    from_idx = surahs.index(page["from_sura"])
    to_idx   = surahs.index(page["to_sura"])

    for i in range(from_idx, to_idx + 1):
        surah_name = surahs[i]
        ayahs = quran[surah_name]

        start = page["from_ayah"] - 1 if i == from_idx else 0
        end   = page["to_ayah"]       if i == to_idx   else len(ayahs)

        for j in range(start, end):
            result.append({
                "surah": surah_name,
                "number": j + 1,
                "text": ayahs[j]
            })

    return result

def total_pages():
    """يرجع عدد الصفحات الكلي"""
    return len(_PAGES)

def surah_pages(name):
    """
    يرجع أرقام الصفحات اللي فيها السورة دي
    
    مثال:
        surah_pages("البقرة")
        # [2, 3, 4, ..., 49]
    """
    if name not in _SOAR:
        raise ValueError(f"السورة '{name}' مش موجودة.")
    
    pages = []
    for i, page in enumerate(_PAGES):
        surahs_in_page = set()
        from_idx = _SOAR.index(page["from_sura"])
        to_idx   = _SOAR.index(page["to_sura"])
        for j in range(from_idx, to_idx + 1):
            surahs_in_page.add(_SOAR[j])
        if name in surahs_in_page:
            pages.append(i + 1)
    return pages

def search(text, tashkeel=True):
    """
    يبحث عن نص في القرآن ويرجع الآيات اللي فيها النص ده
    
    مثال:
        search("بسم الله")
        search("الرحمن", tashkeel=False)
    """
    quran = _QURAN_TASHKEEL if tashkeel else _QURAN_NO_TASH
    results = []
    for surah_name, ayahs in quran.items():
        for i, ayah in enumerate(ayahs):
            if text in ayah:
                results.append({
                    "surah": surah_name,
                    "number": i + 1,
                    "text": ayah
                })
    return results