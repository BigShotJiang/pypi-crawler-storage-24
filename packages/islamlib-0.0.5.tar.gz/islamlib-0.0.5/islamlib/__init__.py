"""
مكتبة islamlib
-----------------


دليل لدوال المكتبة
يمكنك الدخول على كل دالة لمعرفة تفاصيلها

استدعاء المكتبة:
-----------------
```
import islamlib
```

دوال القرآن:
-----------------
```
list_surahs()
get_surah()
get_ayah()
get_surah_info()
get_page()
total_pages()
surah_pages()
search()
```


أمثلة:
-----------------
```
islamlib.list_surahs()
islamlib.get_surah("الفاتحة")
islamlib.get_surah("البقرة", tashkeel=False)
islamlib.get_ayah("البقرة", 255)
islamlib.get_ayah("البقرة", 255, tashkeel=False)
islamlib.get_surah_info("البقرة")
islamlib.get_page(1)
islamlib.total_pages()
islamlib.surah_pages("البقرة")
islamlib.search("بسم الله", tashkeel=False)
```
"""

from .islamlib import *