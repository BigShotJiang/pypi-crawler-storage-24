"""Backend interfaces and implementations."""
