"""Visualization helpers."""
