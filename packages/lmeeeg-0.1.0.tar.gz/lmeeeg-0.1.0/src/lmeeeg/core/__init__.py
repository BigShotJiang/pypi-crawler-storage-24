"""Core package components."""
