#!/usr/bin/env bash
#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

set -euo pipefail

# Build and publish the Veculo Python SDK to PyPI
#
# Usage:
#   ./publish.sh              # Auto-bump patch, build + upload to PyPI
#   ./publish.sh --minor      # Bump minor version (new features)
#   ./publish.sh --major      # Bump major version (breaking changes)
#   ./publish.sh --test       # Auto-bump patch, upload to TestPyPI
#   ./publish.sh --build-only # Auto-bump patch, build only
#   ./publish.sh --no-bump    # Build + upload without version bump

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="/tmp/veculo-publish-venv"
PYPROJECT="$SCRIPT_DIR/pyproject.toml"
INIT_FILE="$SCRIPT_DIR/src/veculo/__init__.py"

BUMP="patch"
TARGET="pypi"
UPLOAD=true

# Parse args
for arg in "$@"; do
  case "$arg" in
    --major)     BUMP="major" ;;
    --minor)     BUMP="minor" ;;
    --patch)     BUMP="patch" ;;
    --no-bump)   BUMP="none" ;;
    --test)      TARGET="testpypi" ;;
    --build-only) UPLOAD=false ;;
  esac
done

echo "=== Veculo Python SDK Publisher ==="

# --- Read current version ---
CURRENT=$(grep '^version = ' "$PYPROJECT" | sed 's/version = "\(.*\)"/\1/')
IFS='.' read -r MAJOR MINOR PATCH <<< "$CURRENT"

echo "Current version: $CURRENT"

# --- Bump version ---
if [ "$BUMP" != "none" ]; then
  case "$BUMP" in
    major) MAJOR=$((MAJOR + 1)); MINOR=0; PATCH=0 ;;
    minor) MINOR=$((MINOR + 1)); PATCH=0 ;;
    patch) PATCH=$((PATCH + 1)) ;;
  esac
  NEW_VERSION="${MAJOR}.${MINOR}.${PATCH}"

  # Update pyproject.toml
  sed -i "s/^version = \".*\"/version = \"${NEW_VERSION}\"/" "$PYPROJECT"

  # Update __init__.py
  if [ -f "$INIT_FILE" ]; then
    sed -i "s/__version__ = \".*\"/__version__ = \"${NEW_VERSION}\"/" "$INIT_FILE"
  fi

  echo "Bumped: $CURRENT → $NEW_VERSION ($BUMP)"
else
  NEW_VERSION="$CURRENT"
  echo "No version bump"
fi

# --- Clean ---
rm -rf "$SCRIPT_DIR/dist" "$SCRIPT_DIR/build" "$SCRIPT_DIR/src"/*.egg-info

# --- Create clean venv ---
echo "Creating clean build environment..."
rm -rf "$VENV_DIR"
python3 -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"
pip install --quiet --upgrade pip build twine

# --- Build ---
echo "Building v${NEW_VERSION}..."
cd "$SCRIPT_DIR"
python -m build --quiet

echo ""
echo "Built:"
ls -lh dist/

# --- Validate ---
twine check dist/* --strict

# --- Upload ---
if [ "$UPLOAD" = true ]; then
  echo ""
  if [ "$TARGET" = "testpypi" ]; then
    echo "Uploading v${NEW_VERSION} to TestPyPI..."
    twine upload --repository testpypi dist/*
    echo ""
    echo "Test install:"
    echo "  pip install --index-url https://test.pypi.org/simple/ veculo==${NEW_VERSION}"
  else
    echo "Uploading v${NEW_VERSION} to PyPI..."
    twine upload dist/*
    echo ""
    echo "Install:"
    echo "  pip install veculo==${NEW_VERSION}"
  fi
else
  echo ""
  echo "Build complete (v${NEW_VERSION}). Skipping upload."
fi

# --- Cleanup ---
deactivate
rm -rf "$VENV_DIR"

echo ""
echo "Done. Version: ${NEW_VERSION}"
