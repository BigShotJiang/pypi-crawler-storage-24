from datetime import datetime

from yslow.models import CheckResult, Issue, ProbeResult, Severity

T0 = datetime(2026, 3, 21, 12, 0, 0)


def make_check(healthy=True, timestamp=None, issues=None):
    """Build a CheckResult for testing."""
    return CheckResult(
        timestamp=timestamp or T0,
        gateway=ProbeResult("192.168.1.1", "Gateway (192.168.1.1)", 5, 0, [1.0]),
        internet=[ProbeResult("1.1.1.1", "Cloudflare DNS", 5, 0, [20.0])],
        dns=[],
        issues=issues
        if issues is not None
        else (
            []
            if healthy
            else [
                Issue(
                    Severity.ERROR,
                    "test-problem",
                    source="LAN",
                    name="test problem",
                    cause="test cause",
                )
            ]
        ),
    )


def pytest_addoption(parser):
    parser.addoption(
        "--snapshot-update",
        action="store_true",
        default=False,
        help="Regenerate UI snapshot files",
    )
