# Claude context

## Quick reference

- `./check.sh` — run all checks (format, lint, typecheck, tests)
- `uv run yslow` — run the tool
- `uv run pytest` — tests only
- `uv run ty check` — type check only
- `uv run ruff check --fix` — lint
- `uv run ruff format` — format
- `uv run pytest tests/test_snapshots.py --snapshot-update` — regenerate UI snapshots after output changes

## Key files

- `TODO.md` — feature backlog and progress tracking
- `docs/` — design and reference documentation (metrics, etc.)
- `logs/` — session logs recording what was changed and why

## Guidelines

- Update or add docs in `docs/` when changing metrics, thresholds, or diagnostic logic
- At the end of a session, write a log entry in `logs/` (format: `YYYY-MM-DD-short-description.md`) summarizing what changed and any open questions
