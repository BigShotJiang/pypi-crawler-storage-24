from __future__ import annotations

from datetime import datetime

from .checks import dns, gateway, internet
from .diagnosis import analyze
from .models import CheckResult


def run_once() -> CheckResult:
    """Run all checks once and return a CheckResult."""
    now = datetime.now()
    gateway_result = gateway.run()
    internet_results = internet.run()
    dns_results = dns.run()
    issues, alerts = analyze(gateway_result, internet_results, dns_results)
    return CheckResult(
        timestamp=now,
        gateway=gateway_result,
        internet=internet_results,
        dns=dns_results,
        issues=issues,
        alerts=alerts,
    )
