# Remove session summary & reorganize tests — 2026-03-22

## What we did

### Removed redundant session summary
- Deleted `print_summary()` from `ui/watch.py` — it duplicated the dashboard's issue history display.
- Removed `format_duration()` from `ui/common.py` (sole caller was `print_summary`).
- Removed `started_at` and `elapsed` from `WatchState` (only used by `print_summary`).
- Updated `docs/dataflow.md` to remove the "on exit" line.

### Reorganized tests to match module structure
- Deleted `test_monitor.py` — was a grab bag testing `models`, `ui/common`, and `ui/watch`.
- Created `test_watch.py` — `WatchState`, `notify`, `_render` tests.
- Created `test_common.py` — `format_ago` tests.
- Moved `TestCheckResultHealthy` and `TestIssueHistory` into `test_models.py`.
- Added shared `make_check` helper and `T0` constant to `conftest.py`.

## Context

Continues the display redundancy cleanup noted in the 2026-03-21 session and the data model work from earlier today. The dashboard is now the single place issues are displayed in watch mode.
