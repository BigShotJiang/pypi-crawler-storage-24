# Rename project to yslow — 2026-03-22

## Why

The name "whyslow" was already taken on PyPI. Renamed the project to "yslow" so it can be published.

## What changed

### Package rename
- Renamed `whyslow/` package directory to `yslow/`
- Updated `pyproject.toml`: package name, entry point (`yslow = "yslow:main"`), Codeberg URLs (`tahnok/whyslow` → `tahnok/yslow`)
- Updated all imports and `unittest.mock.patch` strings across 8 test files
- Updated notification string in `yslow/ui/watch.py`

### Banner
- Regenerated ASCII art banner for "yslow?" using `toilet -f future "yslow?"`
- Added a comment in `yslow/ui/common.py` documenting the generation command

### Docs
- Updated all references in README.md, CLAUDE.md, docs/metrics.md, and log files

### PyPI metadata
- Added `readme`, `license`, `authors`, `classifiers`, `keywords`, and `[project.urls]` to `pyproject.toml`

### Housekeeping
- Regenerated `uv.lock` and UI snapshots
- Removed old `dist/` build artifacts

## Still needed

- Rename the Codeberg repo from `whyslow` to `yslow`
- Create PyPI account / API token and run `uv publish`
- Add a LICENSE file (MIT)
