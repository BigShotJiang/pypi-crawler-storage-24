# Anusara

**Deterministic execution runtime for agent workflows.**

[![CI](https://github.com/Nataraj-Narayana/anusara/actions/workflows/ci.yml/badge.svg)](https://github.com/Nataraj-Narayana/anusara/actions/workflows/ci.yml)
[![PyPI](https://img.shields.io/pypi/v/anusara?label=PyPI&color=blue&cacheSeconds=60)](https://pypi.org/project/anusara/)
[![Python Versions](https://img.shields.io/pypi/pyversions/anusara.svg)](https://pypi.org/project/anusara/)
[![License](https://img.shields.io/github/license/Nataraj-Narayana/anusara.svg)](LICENSE)
![Architecture](https://img.shields.io/badge/architecture-event--sourced%20runtime-blue)

---

## What is Anusara?

**Anusara is a deterministic runtime for executing agent workflows.**

It executes graphs of agents using:

- deterministic scheduling  
- event-sourced execution history  
- replay-driven state reconstruction  

Every execution becomes:

- replayable  
- inspectable  
- debuggable  
- reproducible  

Anusara treats workflow execution as a **runtime system problem**, not a
collection of loosely connected function calls.

---

## The Mental Model

```text
Agent Graph
     ↓
Deterministic Execution Engine
     ↓
Event Log (source of truth)
     ↓
Replay • Debug • Observability
```

Execution is not hidden state.

It is a **recorded, replayable system**.

---

## Why Anusara?

Most agent orchestration systems rely on implicit runtime behavior.

This leads to:

- nondeterministic execution  
- difficult debugging  
- hidden state transitions  
- unreliable retries  
- poor reproducibility  

Anusara solves this by enforcing:

- deterministic execution  
- event log authority  
- replay-based debugging  
- explicit lifecycle guarantees  

---

## Design Philosophy

```text
Anusara = Deterministic Event-Sourced Execution Runtime
```

Not just orchestration.  
Not just workflows.

A **runtime system for reliable execution**.

---

## Architecture Overview

```mermaid
flowchart LR

Client[Client / API / CLI]
Client --> Runtime

Runtime[Execution Runtime]

Runtime --> Graph[Graph Compiler]
Runtime --> Registry[Agent Registry]
Runtime --> Router[Router]
Runtime --> Mutation[Mutation Engine]

Runtime --> EventLog[(Event Log)]

EventLog --> Replay[Replay Engine]
EventLog --> Debugger[Debugger / Analysis]

Runtime --> Observability[Observability]
```

---

## Core Responsibilities

| Layer | Responsibility |
|------|------|
| Runtime | deterministic execution of workflows |
| Event Log | authoritative execution history |
| Router | execution decision logic |
| Mutation Engine | controlled graph evolution |
| Registry | agent discovery and lifecycle |
| Observability | debugging, metrics, visualization |

---

## Quick Start

Install:

```bash
pip install anusara
```

Minimal example:

```python
from anusara import ExecutionEngine, GraphDefinition

graph = GraphDefinition(
    nodes=[
        {"id": "A", "agent": agent_a},
        {"id": "B", "agent": agent_b},
    ],
    edges=[("A", "B")]
)

engine = ExecutionEngine()
result = engine.run(graph, input_data)
```

The runtime handles:

- scheduling  
- retries  
- event logging  
- replay  
- observability  

---

## Execution Graph

Workflows are defined as directed graphs.

```mermaid
graph LR
    A --> B
    A --> C

    subgraph Wave_0
        A
    end

    subgraph Wave_1
        B
        C
    end
```

Execution proceeds in deterministic waves.

---

## Key Features

- deterministic execution  
- event-sourced execution history  
- replayable workflows  
- graph-based orchestration  
- built-in observability  
- runtime debugging tools  
- controlled workflow mutation  

---

## Documentation

Documentation is available in the `docs/` directory.

### Concepts

- deterministic execution  
- event sourcing  
- execution waves  
- replay  

### Guides

- building workflows  
- running executions  
- debugging with replay  

### Architecture

- execution model  
- routing model  
- state machine  
- replay model  
- mutation model  

### Roadmap

See: `docs/roadmap.md`

---

## Project Status

Anusara is under active development.

Current focus:

- developer experience (API & usability)  
- onboarding workflows  
- improved tooling  

---

## Contributing

Contributions and discussions are welcome.

- CONTRIBUTING.md  
- CODE_OF_CONDUCT.md  
- SECURITY.md  

---

## License

MIT License