from __future__ import annotations

import asyncio
import uuid
from typing import Any, cast

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.encoders import jsonable_encoder

from anusara._core.execution_engine import ExecutionEngine
from anusara._core.execution_status import ExecutionStatus
from anusara._introspection.serialization import (
    ExecutionSnapshotSerializer,
)
from anusara._registry.agents_registry import AgentRegistry
from anusara.adapters.http.runtime import (
    get_engine,
    get_registry,
    initialize_runtime,
)
from anusara.adapters.http.schemas import (
    ExecuteRequest,
    HealthResponse,
)
from anusara.adapters.http.utils import default_root
from anusara.api.helper import JSONValue


def create_app(
    *,
    event_log_path: str = "events.jsonl",
    async_mode: bool = True,
    title: str = "Anusara Service",
    version: str = "1.0.5",
) -> FastAPI:
    """
    Create and configure the HTTP application.
    """

    initialize_runtime(event_log_path)

    app = FastAPI(title=title, version=version)
    app.state.async_mode = async_mode

    # ---------------------------------------------------------
    # Root
    # ---------------------------------------------------------
    @app.get("/")
    async def root() -> dict[str, str]:
        return default_root(
            service="anusara",
            version=version,
            architecture="event-driven-mesh",
        )

    # ---------------------------------------------------------
    # Health
    # ---------------------------------------------------------
    @app.get("/health", response_model=HealthResponse)
    async def health() -> HealthResponse:
        return HealthResponse(
            status="ok",
            service="anusara",
            architecture="event-driven-mesh",
            version=version,
        )

    # ---------------------------------------------------------
    # Execute
    # ---------------------------------------------------------
    @app.post("/executions", status_code=status.HTTP_202_ACCEPTED)
    async def execute(
        request: ExecuteRequest,
        http_request: Request,
        engine: ExecutionEngine = Depends(get_engine),
        registry: AgentRegistry = Depends(get_registry),
    ) -> dict[str, str]:

        request_id = str(uuid.uuid4())
        execution_request = request.to_execution_request(request_id)

        try:
            graph = engine.compile(execution_request)

            for node in graph.nodes.values():
                if node.agent and not registry.exists(node.agent):
                    raise HTTPException(
                        status_code=400,
                        detail=f"Agent '{node.agent}' is not registered",
                    )

        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e)) from e

        if http_request.app.state.async_mode:
            asyncio.create_task(engine.execute(execution_request, registry))
        else:
            await engine.execute(execution_request, registry)

        return {
            "request_id": request_id,
            "status": "ACCEPTED",
        }

    # ---------------------------------------------------------
    # Architecture
    # ---------------------------------------------------------
    @app.get("/architecture")
    async def architecture() -> dict[str, JSONValue]:
        return {
            "architecture": "event-driven-mesh",
            "components": [
                "execution-engine",
                "event-log",
                "graph-compiler",
                "agent-registry",
                "mutation-engine",
            ],
        }

    # ---------------------------------------------------------
    # Status
    # ---------------------------------------------------------
    @app.get("/executions/{request_id}")
    async def get_status(
        request_id: str,
        engine: ExecutionEngine = Depends(get_engine),
    ) -> dict[str, str]:

        status_value = engine.get_execution_status(request_id)

        if status_value == ExecutionStatus.NOT_FOUND:
            raise HTTPException(status_code=404, detail="Execution not found")

        return {
            "request_id": request_id,
            "status": status_value.name,
        }

    # ---------------------------------------------------------
    # Snapshot
    # ---------------------------------------------------------
    @app.get("/executions/{request_id}/snapshot")
    async def get_snapshot(
        request_id: str,
        engine: ExecutionEngine = Depends(get_engine),
    ) -> dict[str, Any]:

        try:
            snapshot = engine.get_snapshot(request_id)
        except Exception as e:
            raise HTTPException(status_code=404, detail="Execution not found") from e

        data = ExecutionSnapshotSerializer.snapshot_to_dict(snapshot)

        # ✅ No cast needed, safe boundary
        return cast(dict[str, Any], jsonable_encoder(data))

    return app
