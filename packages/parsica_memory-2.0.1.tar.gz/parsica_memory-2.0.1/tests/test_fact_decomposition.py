"""
Tests for v5.3 fact decomposition and provenance tracking.

Tests the ability to automatically extract atomic facts from complex memories
and store them as separate searchable entries with provenance tracking.
"""

import json
import tempfile
import unittest
from pathlib import Path

# Import the system under test
try:
    from parsica_memory.core_v4 import MemorySystemV4 as MemorySystem
    from parsica_memory.entry import MemoryEntry
    from parsica_memory.manager import MemoryManager
except ImportError:
    from parsica_memory import MemorySystem, MemoryEntry, MemoryManager


class MockEnricher:
    """Mock enricher that returns facts for testing."""
    
    def __init__(self, facts_to_return=None):
        self.facts_to_return = facts_to_return or []
        
    def __call__(self, text):
        return {
            "tags": ["test", "mock"],
            "summary": "Mock enrichment summary",
            "keywords": ["test", "mock", "enrichment"],
            "search_queries": ["What is this test?", "How does mock work?"],
            "facts": self.facts_to_return,
        }


class TestFactDecomposition(unittest.TestCase):
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        # Create system with mock enricher
        self.enricher = MockEnricher()
        self.mem = MemorySystem(
            workspace=self.temp_dir,
            agent_name="test-agent",
            enricher=self.enricher
        )
        self.mem.load()

    def test_ingest_with_facts_creates_fact_entries(self):
        """Test that ingesting content with facts creates separate fact entries."""
        self.enricher.facts_to_return = [
            "User prefers dark mode in the IDE",
            "Password length should be minimum 8 characters",
            "API rate limit is 1000 requests per hour"
        ]
        
        # Ingest a complex memory
        count = self.mem.ingest(
            "Had a discussion about user preferences and security settings. "
            "The user wants dark mode enabled by default, and we decided on "
            "password policies and API rate limits.",
            source="meeting",
            category="decisions"
        )
        
        # Should create 1 original + 3 fact entries = 4 total
        self.assertEqual(count, 4)
        self.assertEqual(len(self.mem.memories), 4)
        
        # Check that fact entries were created
        fact_entries = [m for m in self.mem.memories if m.memory_type == "fact"]
        self.assertEqual(len(fact_entries), 3)
        
        # Check fact properties
        for fact in fact_entries:
            self.assertEqual(fact.provenance, "decomposed")
            self.assertNotEqual(fact.parent_hash, "")
            self.assertEqual(fact.confidence, 0.8)
            self.assertEqual(fact.memory_type, "fact")
            
    def test_fact_entries_inherit_parent_tags(self):
        """Test that fact entries inherit tags from their parent."""
        self.enricher.facts_to_return = ["Important configuration setting"]
        
        self.mem.ingest(
            "Configuration discussion",
            source="config",
            tags=["important", "settings"]
        )
        
        fact_entries = [m for m in self.mem.memories if m.memory_type == "fact"]
        self.assertEqual(len(fact_entries), 1)
        
        # Should inherit both explicit tags and enricher tags
        fact_tags = set(fact_entries[0].tags)
        self.assertIn("important", fact_tags)
        self.assertIn("settings", fact_tags)
        self.assertIn("test", fact_tags)  # from mock enricher
        
    def test_parent_hash_links_to_original_entry(self):
        """Test that parent_hash correctly links fact to original entry."""
        self.enricher.facts_to_return = ["Specific fact from parent"]
        
        self.mem.ingest("Parent memory content", source="test")
        
        # Find original and fact entries
        original_entry = next(m for m in self.mem.memories if m.memory_type == "episodic")
        fact_entry = next(m for m in self.mem.memories if m.memory_type == "fact")
        
        self.assertEqual(fact_entry.parent_hash, original_entry.hash)
        self.assertNotEqual(original_entry.hash, fact_entry.hash)
        
    def test_fact_entries_are_searchable_independently(self):
        """Test that fact entries can be found independently in search."""
        self.enricher.facts_to_return = [
            "Database connection timeout is 30 seconds",
            "Cache expiry is set to 24 hours"
        ]
        
        self.mem.ingest(
            "System configuration review covering database and cache settings",
            source="config"
        )
        
        # Search for database-specific fact
        db_results = self.mem.search("database timeout")
        self.assertTrue(any("Database connection timeout" in r.content for r in db_results))
        
        # Search for cache-specific fact
        cache_results = self.mem.search("cache expiry")
        self.assertTrue(any("Cache expiry" in r.content for r in cache_results))
        
    def test_provenance_field_serialization(self):
        """Test that provenance field serializes/deserializes correctly."""
        self.enricher.facts_to_return = ["Test fact for serialization"]
        
        self.mem.ingest("Test content for serialization", source="test")
        
        # Get a fact entry
        fact_entry = next(m for m in self.mem.memories if m.memory_type == "fact")
        
        # Test serialization
        entry_dict = fact_entry.to_dict()
        self.assertEqual(entry_dict["provenance"], "decomposed")
        self.assertIn("parent_hash", entry_dict)
        
        # Test deserialization
        restored_entry = MemoryEntry.from_dict(entry_dict)
        self.assertEqual(restored_entry.provenance, "decomposed")
        self.assertEqual(restored_entry.parent_hash, fact_entry.parent_hash)
        
    def test_enrichment_without_facts_still_works(self):
        """Test backward compatibility when enrichment returns no facts."""
        # Mock enricher with no facts
        self.enricher.facts_to_return = []
        
        count = self.mem.ingest("Content without extractable facts", source="test")
        
        # Should only create the original entry
        self.assertEqual(count, 1)
        self.assertEqual(len(self.mem.memories), 1)
        
        entry = self.mem.memories[0]
        self.assertEqual(entry.memory_type, "episodic")  # default type
        self.assertEqual(entry.provenance, "self")  # default provenance
        
    def test_duplicate_facts_not_stored_twice(self):
        """Test that duplicate facts are not stored multiple times."""
        # Same fact returned multiple times
        self.enricher.facts_to_return = [
            "Duplicate fact content",
            "Duplicate fact content",  # exact duplicate
            "Different fact content"
        ]
        
        count = self.mem.ingest("Test content for duplicate checking", source="test")
        
        # Should create 1 original + 2 unique facts = 3 total
        self.assertEqual(count, 3)
        
        fact_contents = [m.content for m in self.mem.memories if m.memory_type == "fact"]
        self.assertEqual(len(fact_contents), 2)
        self.assertIn("Duplicate fact content", fact_contents)
        self.assertIn("Different fact content", fact_contents)
        
    def test_short_facts_filtered_out(self):
        """Test that very short facts are filtered out."""
        self.enricher.facts_to_return = [
            "Short",  # too short (< 10 chars)
            "This is a proper length fact statement that should be kept",
            "Too small"  # too short (< 10 chars)
        ]
        
        count = self.mem.ingest("Test content for short fact filtering", source="test")
        
        # Should create 1 original + 1 valid fact = 2 total
        self.assertEqual(count, 2)
        
        fact_entries = [m for m in self.mem.memories if m.memory_type == "fact"]
        self.assertEqual(len(fact_entries), 1)
        self.assertIn("proper length fact statement", fact_entries[0].content)
        
    def test_non_string_facts_filtered_out(self):
        """Test that non-string facts are filtered out."""
        self.enricher.facts_to_return = [
            123,  # number
            None,  # null
            "Valid fact statement here",
            {"key": "value"},  # dict
            []  # list
        ]
        
        count = self.mem.ingest("Test content for non-string filtering", source="test")
        
        # Should create 1 original + 1 valid fact = 2 total
        self.assertEqual(count, 2)
        
        fact_entries = [m for m in self.mem.memories if m.memory_type == "fact"]
        self.assertEqual(len(fact_entries), 1)
        self.assertEqual(fact_entries[0].content, "Valid fact statement here")


class TestRecallStructured(unittest.TestCase):
    """Test the new recall_structured() method in MemoryManager."""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.enricher = MockEnricher(facts_to_return=["Test fact for structured recall"])
        self.manager = MemoryManager(self.temp_dir)
        # Manually set enricher since MemoryManager doesn't expose it in constructor
        self.manager._enricher = self.enricher
        
        # Add some test data
        self.manager.ingest(
            "user123", 
            "Test memory content for structured recall testing",
            "Test response content",
            source="test"
        )
        
    def test_recall_structured_returns_provenance_data(self):
        """Test that recall_structured returns full provenance data."""
        results = self.manager.recall_structured("user123", "test memory")
        
        self.assertGreater(len(results), 0)
        
        for result in results:
            # Check required fields are present
            self.assertIn("content", result)
            self.assertIn("provenance", result)
            self.assertIn("confidence", result)
            self.assertIn("source", result)
            self.assertIn("memory_type", result)
            self.assertIn("parent_hash", result)
            self.assertIn("hash", result)
            
            # Check data types
            self.assertIsInstance(result["content"], str)
            self.assertIsInstance(result["provenance"], str)
            self.assertIsInstance(result["confidence"], (int, float))
            self.assertIsInstance(result["source"], str)
            self.assertIsInstance(result["memory_type"], str)
            self.assertIsInstance(result["parent_hash"], str)
            self.assertIsInstance(result["hash"], str)
            
    def test_recall_structured_includes_decomposed_facts(self):
        """Test that structured recall includes decomposed facts with correct provenance."""
        results = self.manager.recall_structured("user123", "fact")
        
        # Should find the decomposed fact
        decomposed_facts = [r for r in results if r["provenance"] == "decomposed"]
        self.assertGreater(len(decomposed_facts), 0)
        
        fact = decomposed_facts[0]
        self.assertEqual(fact["memory_type"], "fact")
        self.assertNotEqual(fact["parent_hash"], "")
        self.assertIn("Test fact for structured recall", fact["content"])


class TestProvenanceTypes(unittest.TestCase):
    """Test different provenance types work correctly."""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.mem = MemorySystem(workspace=self.temp_dir, agent_name="test-agent")
        self.mem.load()
        
    def test_default_provenance_is_self(self):
        """Test that entries created normally have 'self' provenance."""
        self.mem.ingest("Normal memory entry", source="test")
        
        entry = self.mem.memories[0]
        self.assertEqual(entry.provenance, "self")
        self.assertEqual(entry.parent_hash, "")
        
    def test_manual_provenance_setting(self):
        """Test that provenance can be set manually."""
        entry = MemoryEntry("Manual entry", source="test")
        entry.provenance = "manual"
        entry.parent_hash = "fake_parent_hash"
        
        # Test serialization only includes non-defaults
        entry_dict = entry.to_dict()
        self.assertEqual(entry_dict["provenance"], "manual")
        self.assertEqual(entry_dict["parent_hash"], "fake_parent_hash")
        
        # Test deserialization
        restored = MemoryEntry.from_dict(entry_dict)
        self.assertEqual(restored.provenance, "manual")
        self.assertEqual(restored.parent_hash, "fake_parent_hash")
        
    def test_default_provenance_not_serialized(self):
        """Test that default provenance 'self' is not serialized to save space."""
        entry = MemoryEntry("Default entry", source="test")
        entry_dict = entry.to_dict()
        
        # Should not include provenance field since it's the default
        self.assertNotIn("provenance", entry_dict)
        self.assertNotIn("parent_hash", entry_dict)
        
        # But deserialization should restore defaults
        restored = MemoryEntry.from_dict(entry_dict)
        self.assertEqual(restored.provenance, "self")
        self.assertEqual(restored.parent_hash, "")


if __name__ == "__main__":
    unittest.main()