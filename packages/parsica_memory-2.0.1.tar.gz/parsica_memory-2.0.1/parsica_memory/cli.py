"""
antaris-memory — CLI
====================

Entry point for `python -m parsica_memory` commands.

Commands:
  init            Scaffold a new workspace and generate agent config
  status          Show live stats for an existing workspace
  backfill        Enrich and decompose existing memories in batch
  rebuild-graph   Rebuild the memory graph from all loaded entries
  serve           Start the MCP server (stdio transport)

Usage:
  python -m parsica_memory init [--workspace PATH] [--agent-name NAME]
  python -m parsica_memory status [--workspace PATH]
  python -m parsica_memory backfill [--workspace PATH] [--agent NAME] [options]
  python -m parsica_memory rebuild-graph [--workspace PATH]
  python -m parsica_memory serve [--workspace PATH] [--agent-name NAME]
"""

import argparse
import json
import os
import sys
import time
import uuid
from datetime import datetime

from parsica_memory import __version__


# ── Helpers ──────────────────────────────────────────────────────────────────

def _print_header(title: str) -> None:
    print(f"\n⚡ antaris-memory — {title}")
    print("─" * 50)


def _print_stats(s: dict) -> None:
    """Pretty-print stats() output."""
    _print_header(f"v{s.get('version', '?')} status")
    print(f"  Workspace   : {s.get('workspace', '?')}")
    print(f"  Agent       : {s.get('agent_name') or '(unset)'}")
    print()
    print(f"  Entries     : {s.get('total_entries', 0):,} hot  "
          f"| {s.get('warm_entries', 0):,} warm "
          f"| {s.get('cold_entries', 0):,} cold")
    print(f"  WAL pending : {s.get('wal_size', 0):,}")
    print(f"  Enriched    : {s.get('enrichment_count', 0):,}  "
          f"(${s.get('enrichment_cost_usd', 0):.4f} lifetime)")
    print()
    if s.get('graph_enabled'):
        print(f"  Graph       : {s.get('graph_nodes', 0):,} nodes  "
              f"| {s.get('graph_edges', 0):,} edges")
    else:
        print("  Graph       : disabled")
    print(f"  Co-occ pairs: {s.get('cooccurrence_pairs', 0):,}")
    print(f"  Cache size  : {s.get('cache_size', 0):,}")
    print()


def _make_agent_name(provided: str = None) -> str:
    if provided:
        return provided
    # Derive from machine hostname
    import socket
    hostname = socket.gethostname().split('.')[0].lower()
    return f"agent-{hostname}"


# ── Commands ─────────────────────────────────────────────────────────────────

def cmd_init(args) -> int:
    """Scaffold a new antaris-memory workspace."""
    workspace = os.path.abspath(args.workspace)
    agent_name = _make_agent_name(args.agent_name)

    _print_header("init")
    print(f"  Workspace   : {workspace}")
    print(f"  Agent name  : {agent_name}")
    print()

    # Create workspace directory
    os.makedirs(workspace, exist_ok=True)

    # Write agent config
    config_path = os.path.join(workspace, "antaris_config.json")
    if os.path.exists(config_path) and not getattr(args, 'force', False):
        print(f"  Config already exists at {config_path}")
        print("  Use --force to overwrite.")
    else:
        config = {
            "agent_name": agent_name,
            "agent_id": str(uuid.uuid4()),
            "workspace": workspace,
            "version": __version__,
            "settings": {
                "half_life": 7.0,
                "tiered_storage": True,
                "graph_intelligence": True,
                "enricher": None,
            },
        }
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        print(f"  ✅ Config written  : {config_path}")

    # Touch memory directories
    for d in ['.consolidated', '.shared_pools']:
        os.makedirs(os.path.join(workspace, d), exist_ok=True)

    # Quick smoke test — import MemorySystem
    try:
        from parsica_memory.core_v4 import MemorySystemV4
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
        ms.save()
        total = len(ms.memories)
        print(f"  ✅ MemorySystem OK  : {total:,} entries loaded")
    except Exception as e:
        print(f"  ⚠️  MemorySystem warning: {e}")

    print()
    print("  Ready! Run `python -m parsica_memory status` to see live stats.")
    print()
    return 0


def cmd_status(args) -> int:
    """Show live stats for an existing workspace."""
    workspace = os.path.abspath(args.workspace)

    # Try to get agent_name from config file
    agent_name = None
    config_path = os.path.join(workspace, "antaris_config.json")
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                cfg = json.load(f)
            agent_name = cfg.get("agent_name")
        except Exception:
            pass

    try:
        from parsica_memory.core_v4 import MemorySystemV4
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
        ms.load()
        s = ms.stats()
        _print_stats(s)

        # Health check
        h = ms.get_health()
        status_icon = "✅" if h["status"] == "ok" else "⚠️"
        print(f"  {status_icon} Health: {h['status']}")
        for check, ok in h["checks"].items():
            icon = "✅" if ok else "❌"
            print(f"     {icon} {check}")
        print()
    except Exception as e:
        print(f"\n  ❌ Error loading workspace: {e}", file=sys.stderr)
        return 1

    return 0


def cmd_rebuild_graph(args) -> int:
    """Rebuild the memory graph from all loaded entries."""
    workspace = os.path.abspath(args.workspace)

    agent_name = None
    config_path = os.path.join(workspace, "antaris_config.json")
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                cfg = json.load(f)
            agent_name = cfg.get("agent_name")
        except Exception:
            pass

    _print_header("rebuild-graph")
    print(f"  Workspace: {workspace}")
    print()

    try:
        from parsica_memory.core_v4 import MemorySystemV4
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name,
                            graph_intelligence=True)
        ms.load()
        total = len(ms.memories)
        print(f"  Loaded {total:,} entries — rebuilding graph...")
        count = ms.rebuild_graph()
        print(f"  ✅ Graph rebuilt: {count:,} entries indexed")

        g = ms.get_graph_stats()
        print(f"  Nodes: {g.get('node_count', 0):,}  |  Edges: {g.get('edge_count', 0):,}")
        print()
    except Exception as e:
        print(f"\n  ❌ Error: {e}", file=sys.stderr)
        return 1

    return 0


def cmd_backfill(args) -> int:
    """Batch enrich and decompose existing memories."""
    workspace = os.path.abspath(args.workspace)
    agent_name = args.agent

    _print_header("backfill")
    print(f"  Workspace   : {workspace}")
    print(f"  Agent       : {agent_name}")
    print(f"  Model       : {args.model}")
    print(f"  Provider    : {args.provider}")
    print(f"  Batch size  : {args.batch_size}")
    
    # Determine what operations to run
    run_enrich = not args.decompose_only
    run_decompose = not args.enrich_only
    if args.enrich_only and args.decompose_only:
        print("  ❌ Cannot specify both --enrich-only and --decompose-only", file=sys.stderr)
        return 2
    
    print(f"  Operations  : ", end="")
    ops = []
    if run_enrich:
        ops.append("enrich")
    if run_decompose:
        ops.append("decompose")
    print(" + ".join(ops))
    
    if args.since:
        print(f"  Since       : {args.since}")
    if args.limit:
        print(f"  Limit       : {args.limit}")
    if args.overwrite:
        print(f"  Overwrite   : enabled")
    if args.dry_run:
        print(f"  Mode        : DRY RUN")
    print()

    # Auto-detect provider from api-key prefix if not specified
    provider = args.provider
    api_key = args.api_key
    if provider == "auto" and api_key:
        if api_key.startswith("sk-ant-"):
            provider = "anthropic"
        elif api_key.startswith("sk-"):
            provider = "openai"  
        elif api_key.startswith("AI"):
            provider = "gemini"
        else:
            provider = "anthropic"  # fallback

    # Get enricher function
    enricher_fn = None
    if run_enrich:
        try:
            from parsica_memory.enrichers import (
                anthropic_enricher, openai_enricher, gemini_enricher, 
                local_enricher, auto_enricher
            )
            
            if provider == "auto":
                enricher_fn = auto_enricher()
            elif provider == "anthropic":
                enricher_fn = anthropic_enricher(api_key, args.model)
            elif provider == "openai":
                enricher_fn = openai_enricher(api_key, args.model)
            elif provider == "gemini":
                enricher_fn = gemini_enricher(api_key, args.model)
            elif provider == "local":
                enricher_fn = local_enricher(args.model or "http://localhost:11434", args.model or "llama3.2")
            else:
                print(f"  ❌ Unknown provider: {provider}", file=sys.stderr)
                return 2
                
            if enricher_fn is None:
                if provider == "auto":
                    print("  ❌ No API key found in environment variables", file=sys.stderr)
                else:
                    print(f"  ❌ No API key provided for {provider}", file=sys.stderr)
                return 2
                
        except ImportError as e:
            print(f"  ❌ Import error: {e}", file=sys.stderr)
            return 2

    # Load memory system
    try:
        from parsica_memory.core_v4 import MemorySystemV4
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name, enricher=enricher_fn)
        ms.load()
        
        total_memories = len(ms.memories)
        print(f"  Loaded {total_memories:,} memories")
        
        # Apply filters
        memories_to_process = list(ms.memories)
        if args.since:
            try:
                since_dt = datetime.fromisoformat(args.since.replace('Z', '+00:00'))
                since_iso = since_dt.isoformat()
                memories_to_process = [m for m in memories_to_process if m.created >= since_iso]
                print(f"  Filtered to {len(memories_to_process):,} memories since {args.since}")
            except ValueError:
                print(f"  ❌ Invalid date format: {args.since}", file=sys.stderr)
                return 2
                
        if args.limit:
            memories_to_process = memories_to_process[:args.limit]
            print(f"  Limited to {len(memories_to_process):,} memories")
        
        print()
        
        # Handle dry run after we know the actual counts
        if args.dry_run:
            total_processed = len(memories_to_process)
            if args.json:
                print(json.dumps({
                    "enriched_count": 0,
                    "facts_created": 0, 
                    "failures": 0,
                    "total_time_seconds": 0,
                    "memories_per_second": 0,
                    "total_processed": total_processed,
                    "dry_run": True
                }))
            else:
                print(f"  ✅ Dry run complete - would process {total_processed:,} memories")
            return 0

    except Exception as e:
        print(f"  ❌ Error loading workspace: {e}", file=sys.stderr)
        return 1

    # Track results
    start_time = time.time()
    enriched_count = 0
    facts_created = 0
    failures = 0
    
    def progress_callback(processed, total):
        elapsed = time.time() - start_time
        rate = processed / elapsed if elapsed > 0 else 0
        print(f"    Progress: {processed:,}/{total:,} ({rate:.1f}/sec)")

    try:
        # Run enrichment
        if run_enrich:
            print("  🔍 Running enrichment...")
            enriched_count = ms.re_enrich(
                batch_size=args.batch_size,
                progress_fn=progress_callback,
                overwrite=args.overwrite
            )
            print(f"    ✅ Enriched {enriched_count:,} memories")

        # Run decomposition  
        if run_decompose:
            print("  📝 Running fact decomposition...")
            facts_created = ms.re_decompose(
                batch_size=args.batch_size,
                progress_fn=progress_callback,
                overwrite=args.overwrite
            )
            print(f"    ✅ Created {facts_created:,} facts")

    except Exception as e:
        print(f"  ❌ Processing error: {e}", file=sys.stderr)
        failures = 1

    # Final summary
    elapsed = time.time() - start_time
    total_processed = len(memories_to_process)
    rate = total_processed / elapsed if elapsed > 0 else 0
    
    print()
    summary = {
        "enriched_count": enriched_count,
        "facts_created": facts_created,
        "failures": failures,
        "total_time_seconds": elapsed,
        "memories_per_second": rate,
        "total_processed": total_processed
    }
    
    if args.json:
        print(json.dumps(summary))
    else:
        print(f"  📊 Summary:")
        print(f"    Enriched     : {enriched_count:,}")
        print(f"    Facts created: {facts_created:,}")
        print(f"    Failures     : {failures:,}")
        print(f"    Total time   : {elapsed:.1f}s")
        print(f"    Rate         : {rate:.1f} memories/sec")
    
    # Exit codes
    if failures > 0:
        return 1 if enriched_count > 0 or facts_created > 0 else 2
    return 0


def cmd_serve(args) -> int:
    """Start the MCP server (stdio transport)."""
    workspace = os.path.abspath(args.workspace)
    agent_name = _make_agent_name(getattr(args, 'agent_name', None))

    try:
        from parsica_memory.mcp_server import AntarisMCPServer
        server = AntarisMCPServer(workspace=workspace, agent_name=agent_name)
        server.run_stdio()
    except ImportError:
        print("MCP server module not found.", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        pass

    return 0


# ── Main ─────────────────────────────────────────────────────────────────────

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m parsica_memory",
        description="antaris-memory CLI",
    )
    subparsers = parser.add_subparsers(dest="command")

    # init
    p_init = subparsers.add_parser("init", help="Scaffold a new workspace")
    p_init.add_argument("--workspace", default=".", help="Workspace path (default: .)")
    p_init.add_argument("--agent-name", default=None, help="Agent name")
    p_init.add_argument("--force", action="store_true", help="Overwrite existing config")

    # status
    p_status = subparsers.add_parser("status", help="Show live stats")
    p_status.add_argument("--workspace", default=".", help="Workspace path")

    # backfill
    p_backfill = subparsers.add_parser("backfill", help="Batch enrich and decompose existing memories")
    p_backfill.add_argument("--workspace", required=True, help="Path to memory store directory")
    p_backfill.add_argument("--agent", required=True, help="Agent name for scoping")
    p_backfill.add_argument("--model", default="claude-sonnet-4-6", help="LLM model for enrichment")
    p_backfill.add_argument("--provider", default="auto", 
                           choices=["auto", "anthropic", "openai", "gemini", "local"],
                           help="LLM provider (auto-detect from api-key prefix)")
    p_backfill.add_argument("--api-key", help="API key (falls back to env vars)")
    p_backfill.add_argument("--enrich-only", action="store_true", 
                           help="Only run enrichment, skip fact decomposition")
    p_backfill.add_argument("--decompose-only", action="store_true",
                           help="Only run fact decomposition, skip enrichment")
    p_backfill.add_argument("--overwrite", action="store_true",
                           help="Re-process already-enriched entries")
    p_backfill.add_argument("--since", help="Only process memories created after this ISO date")
    p_backfill.add_argument("--limit", type=int, help="Max memories to process")
    p_backfill.add_argument("--batch-size", type=int, default=100,
                           help="Checkpoint save frequency")
    p_backfill.add_argument("--dry-run", action="store_true",
                           help="Show what would be done without doing it")
    p_backfill.add_argument("--json", action="store_true",
                           help="Output final results as JSON to stdout")

    # rebuild-graph
    p_rebuild = subparsers.add_parser("rebuild-graph", help="Rebuild memory graph")
    p_rebuild.add_argument("--workspace", default=".", help="Workspace path")

    # serve (MCP)
    p_serve = subparsers.add_parser("serve", help="Start MCP server (stdio)")
    p_serve.add_argument("--workspace", default=".", help="Workspace path")
    p_serve.add_argument("--agent-name", default=None, help="Agent name")

    args = parser.parse_args(argv)

    if args.command == "init":
        return cmd_init(args)
    elif args.command == "status":
        return cmd_status(args)
    elif args.command == "backfill":
        return cmd_backfill(args)
    elif args.command == "rebuild-graph":
        return cmd_rebuild_graph(args)
    elif args.command == "serve":
        return cmd_serve(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
