"""
Parsica-Memory v2.0.0 Benchmark Suite
======================================
Tests search quality, fact decomposition, fuzzy dedup, anti-adjacency,
and latency across the live memory store.

Run: python3 benchmarks/benchmark_v2.py [--store PATH]

Default store: /Users/moro/.openclaw/workspace/antaris_memory_store
"""
import os
import sys
import time
import json
import tempfile
import shutil
import statistics
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from parsica_memory import MemorySystem, MemoryManager
from parsica_memory.entry import MemoryEntry


# ── Configuration ─────────────────────────────────────────────────────────
DEFAULT_STORE = "/Users/moro/.openclaw/workspace/antaris_memory_store"
AGENT_NAME = "benchmark"


# ── Test Data ─────────────────────────────────────────────────────────────

# TopK recall: (query, expected_keyword_in_result)
TOPK_QUERIES = [
    ("What web framework did we choose?", "FastAPI"),
    ("What database are we using?", "PostgreSQL"),
    ("What is the deployment pipeline?", "GitHub Actions"),
    ("How many tests do we have?", "1,"),  # 1,508 or 1,182 etc
    ("What is the LOCOMO accuracy?", "78"),
    ("What is the memory decay half-life?", "7"),
    ("What model do we use for enrichment?", "Sonnet"),
    ("What is the zero dependency principle?", "dependency"),
    ("How does the guard work?", "guard"),
    ("What is cross-session recall?", "session"),
]

# Anti-adjacency: (query, good_answer_keyword, bad_meta_keyword)
ANTI_ADJACENCY_TESTS = [
    ("what was the test phrase?", "Peaches", "testing"),
    ("what is the project name?", "Antaris", "discussed"),
    ("what version are we on?", "v2.0", "version control"),
]

# Fact decomposition: content -> expected fact count
FACT_TESTS = [
    ("User prefers dark mode. Password minimum is 8 chars. API limit is 1000/hr.", 3),
    ("The sky is blue.", 1),
    ("ok thanks", 0),  # too short / noise
]


def run_topk_benchmark(mem, limit=1):
    """Run top-K recall benchmark. Returns (hits, total, accuracy)."""
    hits = 0
    total = len(TOPK_QUERIES)
    
    for query, expected in TOPK_QUERIES:
        results = mem.search(query, limit=limit)
        found = any(expected.lower() in r.content.lower() for r in results)
        if found:
            hits += 1
        else:
            top = results[0].content[:60] if results else "(no results)"
            print(f"  MISS: '{query}' -> expected '{expected}', got: {top}...")
    
    accuracy = hits / total * 100
    return hits, total, accuracy


def run_latency_benchmark(mem, n_queries=100):
    """Run search latency benchmark. Returns (p50, p95, p99) in ms."""
    queries = [
        "deployment", "database", "security", "memory", "agent",
        "Python", "FastAPI", "testing", "configuration", "production",
        "monitor setup", "API key", "enrichment", "search engine", "BM25",
        "cross session", "fact decomposition", "provenance", "confidence", "decay",
    ] * (n_queries // 20 + 1)
    queries = queries[:n_queries]
    
    latencies = []
    for q in queries:
        start = time.perf_counter()
        mem.search(q, limit=10)
        elapsed = (time.perf_counter() - start) * 1000  # ms
        latencies.append(elapsed)
    
    latencies.sort()
    p50 = latencies[len(latencies) // 2]
    p95 = latencies[int(len(latencies) * 0.95)]
    p99 = latencies[int(len(latencies) * 0.99)]
    
    return p50, p95, p99


def run_anti_adjacency_test(mem):
    """Test that specific answers outrank meta-discussion."""
    passed = 0
    total = 0
    
    for query, good_kw, bad_kw in ANTI_ADJACENCY_TESTS:
        results = mem.search(query, limit=5, explain=True)
        if not results:
            print(f"  SKIP: '{query}' returned no results")
            continue
        
        total += 1
        top = results[0].content.lower()
        if good_kw.lower() in top:
            passed += 1
        else:
            print(f"  FAIL: '{query}' -> top result doesn't contain '{good_kw}'")
            print(f"    Got: {results[0].content[:80]}...")
    
    return passed, total


def run_fact_decomposition_test():
    """Test fact decomposition with mock enricher."""
    with tempfile.TemporaryDirectory() as td:
        def mock_enricher(text):
            # Simple fact extraction: split on periods
            facts = [s.strip() for s in text.split(".") if len(s.strip()) > 15]
            return {
                "tags": ["test"],
                "summary": "test summary",
                "keywords": ["test"],
                "search_queries": ["test?"],
                "facts": facts,
            }
        
        mem = MemorySystem(workspace=td, agent_name="bench", enricher=mock_enricher)
        mem.load()
        
        passed = 0
        total = len(FACT_TESTS)
        
        for content, expected_facts in FACT_TESTS:
            mem.memories.clear()
            mem._hashes.clear()
            mem._content_norms.clear()
            
            count = mem.ingest(content, source="test")
            fact_entries = [m for m in mem.memories if m.memory_type == "fact"]
            
            if len(fact_entries) == expected_facts:
                passed += 1
            else:
                print(f"  FAIL: '{content[:40]}...' expected {expected_facts} facts, got {len(fact_entries)}")
                for f in fact_entries:
                    print(f"    fact: {f.content}")
        
        return passed, total


def run_fuzzy_dedup_test():
    """Test fuzzy dedup prevents near-duplicates."""
    with tempfile.TemporaryDirectory() as td:
        mem = MemorySystem(workspace=td, agent_name="bench")
        mem.load()
        
        # Ingest first fact
        mem.ingest("Python is a great programming language for AI", memory_type="fact")
        count_before = len(mem.memories)
        
        # Ingest near-duplicate (Jaccard ~0.86)
        mem.ingest("Python is a great programming language for ML", memory_type="fact")
        count_after = len(mem.memories)
        
        dedup_worked = count_after == count_before  # should NOT add duplicate
        
        # Verify sighting was bumped
        original = mem.memories[0]
        sighting_bumped = original.sighting_count > 0
        
        return dedup_worked, sighting_bumped


def run_confidence_floor_test(mem):
    """Test confidence floor filters low-confidence results."""
    # Search with no floor
    all_results = mem.search("test", limit=20, confidence_floor=0.0)
    
    # Search with high floor
    filtered = mem.search("test", limit=20, confidence_floor=0.8)
    
    return len(all_results), len(filtered), len(filtered) <= len(all_results)


def main():
    store_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_STORE
    
    if not os.path.exists(store_path):
        print(f"Store not found: {store_path}")
        print("Usage: python3 benchmarks/benchmark_v2.py [--store PATH]")
        sys.exit(1)
    
    print("=" * 60)
    print("Parsica-Memory v2.0.0 Benchmark Suite")
    print("=" * 60)
    
    # Load store
    print(f"\nLoading store: {store_path}")
    start = time.perf_counter()
    mem = MemorySystem(workspace=store_path, agent_name=AGENT_NAME)
    count = mem.load()
    load_time = (time.perf_counter() - start) * 1000
    stats = mem.stats()
    total = stats.get("total", 0)
    print(f"Loaded {total} memories in {load_time:.0f}ms")
    
    results = {}
    
    # 1. TopK Recall @ K=1
    print("\n--- TopK Recall @ K=1 ---")
    hits, total_q, acc = run_topk_benchmark(mem, limit=1)
    results["topk_r1"] = {"hits": hits, "total": total_q, "accuracy": acc}
    print(f"Result: {hits}/{total_q} = {acc:.1f}%")
    
    # 2. TopK Recall @ K=3
    print("\n--- TopK Recall @ K=3 ---")
    hits3, total_q3, acc3 = run_topk_benchmark(mem, limit=3)
    results["topk_r3"] = {"hits": hits3, "total": total_q3, "accuracy": acc3}
    print(f"Result: {hits3}/{total_q3} = {acc3:.1f}%")
    
    # 3. Search Latency
    print("\n--- Search Latency (100 queries) ---")
    p50, p95, p99 = run_latency_benchmark(mem, n_queries=100)
    results["latency"] = {"p50_ms": round(p50, 1), "p95_ms": round(p95, 1), "p99_ms": round(p99, 1)}
    print(f"p50: {p50:.1f}ms | p95: {p95:.1f}ms | p99: {p99:.1f}ms")
    
    # 4. Anti-Adjacency
    print("\n--- Anti-Adjacency Penalty ---")
    aa_passed, aa_total = run_anti_adjacency_test(mem)
    results["anti_adjacency"] = {"passed": aa_passed, "total": aa_total}
    if aa_total > 0:
        print(f"Result: {aa_passed}/{aa_total} = {aa_passed/aa_total*100:.0f}%")
    else:
        print("Result: No applicable test data in store")
    
    # 5. Fact Decomposition
    print("\n--- Fact Decomposition ---")
    fd_passed, fd_total = run_fact_decomposition_test()
    results["fact_decomposition"] = {"passed": fd_passed, "total": fd_total}
    print(f"Result: {fd_passed}/{fd_total} = {fd_passed/fd_total*100:.0f}%")
    
    # 6. Fuzzy Dedup
    print("\n--- Fuzzy Dedup ---")
    dedup_ok, sighting_ok = run_fuzzy_dedup_test()
    results["fuzzy_dedup"] = {"dedup_prevented": dedup_ok, "sighting_bumped": sighting_ok}
    print(f"Dedup prevented duplicate: {'PASS' if dedup_ok else 'FAIL'}")
    print(f"Sighting count bumped: {'PASS' if sighting_ok else 'FAIL'}")
    
    # 7. Confidence Floor
    print("\n--- Confidence Floor ---")
    all_count, filtered_count, floor_ok = run_confidence_floor_test(mem)
    results["confidence_floor"] = {"all_results": all_count, "filtered": filtered_count, "working": floor_ok}
    print(f"Without floor: {all_count} results | With floor (0.8): {filtered_count} | Working: {'PASS' if floor_ok else 'FAIL'}")
    
    # Summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"TopK R@1:          {results['topk_r1']['accuracy']:.1f}%")
    print(f"TopK R@3:          {results['topk_r3']['accuracy']:.1f}%")
    print(f"p50 Latency:       {results['latency']['p50_ms']:.1f}ms")
    print(f"p95 Latency:       {results['latency']['p95_ms']:.1f}ms")
    print(f"Fact Decomp:       {results['fact_decomposition']['passed']}/{results['fact_decomposition']['total']}")
    print(f"Fuzzy Dedup:       {'PASS' if results['fuzzy_dedup']['dedup_prevented'] else 'FAIL'}")
    print(f"Confidence Floor:  {'PASS' if results['confidence_floor']['working'] else 'FAIL'}")
    print("=" * 60)
    
    # Save results
    out_path = os.path.join(os.path.dirname(__file__), "benchmark_v2_results.json")
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nResults saved to: {out_path}")


if __name__ == "__main__":
    main()
