"""Parallel enrichment worker.
Usage: python3 parallel_enrich.py <worker_id> <total_workers> <store_path> <api_key>

Each worker processes memories where hash(content) % total_workers == worker_id.
Saves checkpoint after every batch. Crash-safe - skips already-enriched entries.
"""
import os, sys, time, json, hashlib

worker_id = int(sys.argv[1])
total_workers = int(sys.argv[2])
store_path = sys.argv[3]
api_key = sys.argv[4]

os.environ["ANTHROPIC_API_KEY"] = api_key

log_path = f"/tmp/enrich_worker_{worker_id}.log"
sys.stdout = open(log_path, "w", buffering=1)
sys.stderr = sys.stdout

from parsica_memory import MemorySystem
from parsica_memory.enrichers import anthropic_enricher

print(f"Worker {worker_id}/{total_workers} starting", flush=True)
enrich_fn = anthropic_enricher(model="claude-haiku-4-5-20251001")

# Test enricher
test = enrich_fn("Test memory for enrichment validation")
if not test:
    print("ENRICHER FAILED - aborting", flush=True)
    sys.exit(1)
print(f"Enricher OK, facts: {len(test.get('facts', []))}", flush=True)

ms = MemorySystem(workspace=store_path, agent_name="moro", enricher=enrich_fn)
ms.load()
print(f"Loaded {len(ms.memories)} memories", flush=True)

# Filter to this worker's slice (by content hash)
my_entries = []
for i, entry in enumerate(ms.memories):
    if not getattr(entry, "enriched_summary", ""):
        h = int(hashlib.md5(entry.content.encode()).hexdigest()[:8], 16)
        if h % total_workers == worker_id:
            my_entries.append((i, entry))

print(f"Assigned {len(my_entries)} unenriched memories", flush=True)

enriched = 0
failed = 0
batch_size = 50
start = time.time()

for batch_start in range(0, len(my_entries), batch_size):
    batch = my_entries[batch_start:batch_start + batch_size]
    for idx, entry in batch:
        try:
            result = enrich_fn(entry.content)
            if result and isinstance(result, dict):
                if result.get("tags"):
                    entry.tags = sorted(set(entry.tags) | {t.lower() for t in result["tags"]})
                if result.get("summary"):
                    entry.enriched_summary = str(result["summary"])
                if result.get("keywords"):
                    entry.search_keywords = [str(k).lower() for k in result["keywords"]]
                if result.get("search_queries"):
                    entry.search_queries = [str(q) for q in result["search_queries"]]
                enriched += 1
            else:
                failed += 1
        except Exception as e:
            failed += 1
            print(f"  Error: {e}", flush=True)

    # Checkpoint save after each batch
    try:
        ms.save()
    except Exception as e:
        print(f"  Save error: {e}", flush=True)

    elapsed = time.time() - start
    rate = enriched / elapsed if elapsed > 0 else 0
    remaining = len(my_entries) - (batch_start + len(batch))
    eta = remaining / rate if rate > 0 else 0
    print(f"  Progress: {enriched}/{len(my_entries)} enriched, {failed} failed, "
          f"{rate:.1f}/s, ETA: {eta/60:.0f}m", flush=True)

elapsed = time.time() - start
print(f"\nDone! Worker {worker_id}: {enriched} enriched, {failed} failed in {elapsed:.0f}s", flush=True)

# Final save
ms.save()
print("Saved.", flush=True)

# Write completion marker
with open(f"/tmp/enrich_worker_{worker_id}_done.json", "w") as f:
    json.dump({"worker": worker_id, "enriched": enriched, "failed": failed, "elapsed": elapsed}, f)
