#!/bin/bash
# Benchmark that exercises the slow path (callback mode) of the async bridge.
#
# The fast path (try_recv succeeds on first __next__) only works when Valkey
# responds before the event loop schedules another iteration. With any real
# network latency, operations hit the slow path where the watcher task must
# acquire the GIL to call call_soon_threadsafe.
#
# Prior to the spawn_blocking fix, watcher tasks blocked tokio worker threads
# on GIL contention, causing cascading starvation under load. This benchmark
# reproduces that failure: with 2ms RTT and moderate concurrency, the old code
# hangs while the fixed code works fine.
#
# Usage: docker compose run --rm --cap-add NET_ADMIN app bash bench_slowpath.sh
set -e

CONCURRENCY=${1:-20}
DURATION=${2:-10}
PORT=8787
LATENCY_MS=2

echo "============================================================"
echo "SLOW-PATH STRESS TEST"
echo "  Concurrency: ${CONCURRENCY}"
echo "  Duration:    ${DURATION}s"
echo "  Latency:     ${LATENCY_MS}ms RTT (via tc netem)"
echo "============================================================"

# Add network latency to Valkey to force slow-path (callback mode).
# With 0ms RTT, most operations complete before the second __next__ poll.
# With 2ms RTT, nearly all operations hit the slow path.
echo "Adding ${LATENCY_MS}ms latency to valkey..."
tc qdisc add dev eth0 root netem delay ${LATENCY_MS}ms 2>/dev/null || \
    tc qdisc change dev eth0 root netem delay ${LATENCY_MS}ms

# Start granian with uvloop (matches production)
echo "Starting granian (uvloop)..."
DJANGO_SETTINGS_MODULE=sample.settings granian \
    --interface asgi --host 127.0.0.1 --port ${PORT} \
    --loop uvloop --workers 1 \
    sample.asgi:application &>/dev/null &
PID=$!
sleep 2

# Seed cache
curl -sf http://127.0.0.1:${PORT}/bench/seed/ > /dev/null

# Warmup
hey -n 50 -c 5 http://127.0.0.1:${PORT}/bench/mixed/ > /dev/null 2>&1

# Run the actual stress test
echo ""
echo "Running: hey -c ${CONCURRENCY} -z ${DURATION}s ..."
echo ""
RESULT=$(hey -c ${CONCURRENCY} -z ${DURATION}s http://127.0.0.1:${PORT}/bench/mixed/ 2>&1)

# Extract key metrics
echo "$RESULT" | grep -E "Requests/sec|Average|Fastest|Slowest|Total:|Status code|responses"

# Check for errors (status != 200) — a sign of starvation/timeout
ERRORS=$(echo "$RESULT" | grep -c "Status code.*[^2][0-9][0-9]" || true)
TIMEOUTS=$(echo "$RESULT" | grep -c "timeout" || true)

echo ""
if [ "$ERRORS" -gt 0 ] || [ "$TIMEOUTS" -gt 0 ]; then
    echo "FAIL: Got errors/timeouts — likely tokio thread starvation"
else
    RPS=$(echo "$RESULT" | grep "Requests/sec" | awk '{print $2}')
    echo "PASS: ${RPS} req/s with ${LATENCY_MS}ms latency, ${CONCURRENCY} concurrent"
fi

# Cleanup
kill $PID 2>/dev/null
wait $PID 2>/dev/null
tc qdisc del dev eth0 root 2>/dev/null || true
