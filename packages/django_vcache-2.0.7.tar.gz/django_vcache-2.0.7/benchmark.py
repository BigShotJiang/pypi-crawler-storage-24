"""
django-vcache vs Django's built-in RedisCache — full-stack benchmark.

Tests real Django cache operations against a running Valkey/Redis instance.
Both sync and async paths are measured.

Usage: python benchmark.py [VALKEY_URL]
Default URL: redis://127.0.0.1:6379/1
"""

import asyncio
import os
import sys
import time

import django
from django.conf import settings

VALKEY_URL = (
    sys.argv[1]
    if len(sys.argv) > 1
    else os.environ.get("VALKEY_URL", "redis://127.0.0.1:6379/1")
)

settings.configure(
    CACHES={
        "vcache": {
            "BACKEND": "django_vcache.backend.ValkeyCache",
            "LOCATION": VALKEY_URL,
        },
        "django-redis": {
            "BACKEND": "django.core.cache.backends.redis.RedisCache",
            "LOCATION": VALKEY_URL,
        },
    },
)
django.setup()

from django.core.cache import caches  # noqa: E402

vcache = caches["vcache"]
django_redis = caches["django-redis"]

SMALL = {
    "hello": "world",
    "number": 42,
    "items": list(range(20)),
    "nested": {"a": "b"},
}
MEDIUM = {
    "user": {
        "id": 12345,
        "name": "Jane Doe",
        "email": "jane@example.com",
        "active": True,
    },
    "permissions": ["read", "write", "admin"],
    "settings": {"theme": "dark", "lang": "en", "notifications": True},
    "recent_ids": list(range(100)),
}
LARGE = {
    "description": "x" * 2000,
    "tags": [f"tag_{j}" for j in range(50)],
    "nested": {"key": "value" * 100, "count": 999},
}


def bench_sync(cache_backend, label, value, n):
    for i in range(min(100, n)):
        cache_backend.set(f"bench_{i}", value, 60)
        cache_backend.get(f"bench_{i}")

    start = time.perf_counter()
    for i in range(n):
        cache_backend.set(f"bench_{i}", value, 60)
    t_set = time.perf_counter() - start

    start = time.perf_counter()
    for i in range(n):
        result = cache_backend.get(f"bench_{i}")
    t_get = time.perf_counter() - start

    assert result == value, f"{label}: round-trip failed"
    return t_set, t_get


async def bench_async(cache_backend, label, value, n):
    for i in range(min(100, n)):
        await cache_backend.aset(f"abench_{i}", value, 60)
        await cache_backend.aget(f"abench_{i}")

    start = time.perf_counter()
    for i in range(n):
        await cache_backend.aset(f"abench_{i}", value, 60)
    t_set = time.perf_counter() - start

    start = time.perf_counter()
    for i in range(n):
        result = await cache_backend.aget(f"abench_{i}")
    t_get = time.perf_counter() - start

    assert result == value, f"{label}: async round-trip failed"
    return t_set, t_get


def print_comparison(n, vc_set, vc_get, dj_set, dj_get):
    vc_total = vc_set + vc_get
    dj_total = dj_set + dj_get
    vc_ops = n / vc_total
    dj_ops = n / dj_total

    hdr = f"  {'':20s} {'set':>8s} {'get':>8s} {'total':>8s} {'ops/s':>8s}"
    print(hdr)
    print(
        f"  {'Django RedisCache':20s}"
        f" {dj_set:8.3f}s {dj_get:8.3f}s"
        f" {dj_total:8.3f}s {dj_ops:8,.0f}"
    )
    print(
        f"  {'django-vcache':20s}"
        f" {vc_set:8.3f}s {vc_get:8.3f}s"
        f" {vc_total:8.3f}s {vc_ops:8,.0f}"
    )
    print()
    set_x = dj_set / vc_set
    get_x = dj_get / vc_get
    tot_x = dj_total / vc_total
    print(f"  Speedup:  set {set_x:.2f}x   get {get_x:.2f}x   total {tot_x:.2f}x")


async def main():
    print(f"Python {sys.version}")
    print(f"Server: {VALKEY_URL}")
    print()

    vcache.set("_ping", "pong", 10)
    assert vcache.get("_ping") == "pong", "vcache: connection failed"
    django_redis.set("_ping", "pong", 10)
    assert django_redis.get("_ping") == "pong", "django-redis: connection failed"
    print("Both backends connected OK\n")

    for payload_name, payload, n in [
        ("SMALL (typical cache hit)", SMALL, 5000),
        ("MEDIUM (user session)", MEDIUM, 5000),
        ("LARGE (triggers compression)", LARGE, 2000),
    ]:
        print("=" * 64)
        print(f"  {payload_name} — {n:,} iterations")
        print("=" * 64)

        print("\n  --- Sync ---")
        dj_set, dj_get = bench_sync(django_redis, "django", payload, n)
        vc_set, vc_get = bench_sync(vcache, "vcache", payload, n)
        print_comparison(n, vc_set, vc_get, dj_set, dj_get)

        print("\n  --- Async ---")
        dj_set, dj_get = await bench_async(django_redis, "django", payload, n)
        vc_set, vc_get = await bench_async(vcache, "vcache", payload, n)
        print_comparison(n, vc_set, vc_get, dj_set, dj_get)

        print()

    # --- Concurrent async benchmark ---
    print("=" * 64)
    print("  CONCURRENT ASYNC — 1,000 set+get pairs, 50 tasks")
    print("=" * 64)

    n_tasks = 50
    n_per_task = 20
    value = MEDIUM

    async def worker(cache_backend, prefix, count):
        for i in range(count):
            key = f"{prefix}_{i}"
            await cache_backend.aset(key, value, 60)
            await cache_backend.aget(key)

    await worker(vcache, "warmup_vc", 10)
    await worker(django_redis, "warmup_dj", 10)

    start = time.perf_counter()
    await asyncio.gather(
        *[worker(vcache, f"vc_{t}", n_per_task) for t in range(n_tasks)]
    )
    vc_concurrent = time.perf_counter() - start

    start = time.perf_counter()
    await asyncio.gather(
        *[worker(django_redis, f"dj_{t}", n_per_task) for t in range(n_tasks)]
    )
    dj_concurrent = time.perf_counter() - start

    total_ops = n_tasks * n_per_task * 2
    print(f"\n  {'':20s} {'time':>8s} {'ops/s':>8s}")
    print(
        f"  {'Django RedisCache':20s}"
        f" {dj_concurrent:8.3f}s {total_ops / dj_concurrent:8,.0f}"
    )
    print(
        f"  {'django-vcache':20s}"
        f" {vc_concurrent:8.3f}s {total_ops / vc_concurrent:8,.0f}"
    )
    print(f"\n  Speedup: {dj_concurrent / vc_concurrent:.2f}x")
    print()

    vcache.get_raw_client().flushdb()


asyncio.run(main())
