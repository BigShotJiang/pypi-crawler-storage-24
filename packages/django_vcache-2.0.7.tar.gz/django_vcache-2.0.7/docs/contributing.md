# Contributing

## Development environment

This project uses Docker for development. To get started:

1. Clone the repository.
2. Build and start the services:

```bash
docker compose up -d --build
```

This will start a Valkey container and an `app` container with the Django sample project running on `http://localhost:8000`. The development server uses `granian` with auto-reload.

## Running tests

```bash
docker compose run --rm app bash -c "python sample/manage.py test"
```

## Sentinel development

To run with Valkey Sentinel:

```bash
docker compose -f compose.yml -f compose.sentinel.yml up -d --build
```

Set the `VALKEY_URL` environment variable:

```bash
export VALKEY_URL="sentinel://localhost:26379/mymaster/1"
```

## Cluster development

To run with Valkey Cluster:

```bash
docker compose -f compose.yml -f compose.cluster.yml up -d --build \
    -e VALKEY_URL='valkey://valkey-1:6379/0' \
    -e VALKEY_CLUSTER_MODE='true'
```

## Building from source

The Rust extension is built with [maturin](https://www.maturin.rs/):

```bash
maturin build --release
```

Requires a Rust toolchain.
