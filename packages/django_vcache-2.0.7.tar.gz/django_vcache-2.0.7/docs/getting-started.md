# Getting Started

## Installation

```bash
pip install django-vcache
```

Pre-built wheels are available for common platforms. Building from source requires a Rust toolchain.

## Configuration

Update your `settings.py` to configure the cache backend:

```python
CACHES = {
    "default": {
        "BACKEND": "django_vcache.backend.ValkeyCache",
        "LOCATION": "valkey://your-valkey-host:6379/1",
    },
}
```

Both `valkey://` and `redis://` URL schemes are supported. For TLS, use `valkeys://` or `rediss://`.

## Usage

Use Django's cache framework as usual:

```python
from django.core.cache import cache

cache.set('my_key', 'my_value', 30)
value = cache.get('my_key')
```

## Async usage

You must use an ASGI server for async cache methods. For example, with `granian`:

```bash
granian --interface asgi --host 0.0.0.0 --port 8000 myproject.asgi:application
```

```python
from django.core.cache import cache

await cache.aset('my_key', 'my_value', 30)
value = await cache.aget('my_key')
```

Sync methods (`get`, `set`, etc.) work in any context (ASGI or WSGI).
