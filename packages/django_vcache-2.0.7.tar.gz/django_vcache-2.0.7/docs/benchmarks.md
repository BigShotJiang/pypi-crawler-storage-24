# Benchmarks

## vs valkey-py 1.x

Measured on Python 3.14 with granian ASGI server, 300 concurrent connections, 2ms simulated round-trip latency (tc netem on eth0, typical for managed Valkey / DigitalOcean / AWS ElastiCache). Each request performs 6 cache operations (get, get_many, set, set compressed, incr, get compressed).

| | django-vcache 2.x | valkey-py 1.x (+ libvalkey) | Change |
|---|---|---|---|
| **Requests/sec** | 698 | 551 | **+27%** |
| **Peak RSS** | 135 MB | 143 MB | **-6%** |
| **Valkey connections** | 2 | 301 | |

Under sustained load, the RSS gap widens — valkey-py memory keeps climbing while 2.x stays flat. In a 40-second test: 150 MB (2.x) vs 179 MB (valkey-py) and still rising.

## Why the difference?

valkey-py uses a connection pool — one TCP connection per concurrent operation. Under load with 300 concurrent requests, the pool opens 300 connections and keeps them alive. Each connection carries per-connection buffers and Python object overhead that accumulates over time.

django-vcache uses a single multiplexed connection via a Rust driver. No connection pool to tune, no per-connection overhead. The throughput advantage grows with network latency (multiplexing pipelines operations across the single connection).

## Reproduce

```bash
docker compose build
docker compose up -d valkey
docker compose run --rm app python bench_compare.py
```
