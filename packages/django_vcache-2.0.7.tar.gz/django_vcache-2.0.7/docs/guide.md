# Guide

## API

django-vcache implements the full [Django cache API](https://docs.djangoproject.com/en/stable/topics/cache/) with native async variants (`aget`, `aset`, etc.):

`get`, `set`, `add`, `delete`, `touch`, `incr`, `decr`, `has_key`, `get_many`, `set_many`, `delete_many`, `get_or_set`, `clear`

## Distributed locking

**`lock(key, timeout=None, blocking=True, ...)`** / **`alock(...)`** — Distributed locking via Valkey. Not available in cluster mode.

```python
with cache.lock("my-lock", timeout=10):
    # exclusive access
    ...

async with cache.alock("my-lock", timeout=10):
    ...
```

## Raw client access

**`get_raw_client()`** — Access the underlying Rust driver instance for operations not covered by the Django cache API. Reuses the existing connection.

```python
client = cache.get_raw_client()
```

## Atomic incr/decr

`incr` and `decr` use native Redis `INCRBY`/`DECRBY` commands. If the key does not exist, it is created with the delta value (Redis behavior). This is atomic and safe for concurrent counters.

## Serialization

Values are serialized with [msgpack](https://github.com/aviramha/ormsgpack) (via ormsgpack) by default. Large values (>1KB by default) are compressed with zstd. Integer values are stored as raw strings to support native `INCRBY`.

See [Configuration](configuration.md#serializer) for options.
