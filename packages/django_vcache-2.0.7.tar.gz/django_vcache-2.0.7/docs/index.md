# django-vcache

A fast, async-native Django cache backend for Valkey (and Redis). Opinionated and secure by default.

It powers the [GlitchTip](https://glitchtip.com) open-source error tracking platform.

## Why django-vcache?

- **Fast** — Rust I/O driver with msgpack serialization (via ormsgpack). 13x faster than Django's built-in RedisCache under concurrent ASGI load.
- **Async-native** — True async I/O, not `sync_to_async` thread-pool wrappers. Single multiplexed connection handles all concurrency.
- **Secure by default** — No pickle. Msgpack cannot execute arbitrary code on deserialization. No special configuration needed.
- **Efficient** — One multiplexed connection for both sync and async. No connection pool to tune. Automatic zstd compression for large values.
- **Python 3.14 ready** — Uses stdlib `compression.zstd` on 3.14+, no third-party compression dependency needed.

## Quick start

```bash
pip install django-vcache
```

```python
CACHES = {
    "default": {
        "BACKEND": "django_vcache.backend.ValkeyCache",
        "LOCATION": "valkey://your-valkey-host:6379/1",
    },
}
```

```python
from django.core.cache import cache

cache.set('my_key', 'my_value', 30)
value = cache.get('my_key')
```

Status: Stable and used in production.
