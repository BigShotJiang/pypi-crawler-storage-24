#!/bin/bash
# Real-world ASGI benchmark: django-vcache (Rust) vs Django RedisCache (hiredis)
# Run inside the app container with both backends available.
#
# PRODUCTION SETTINGS: Always uses granian + uvloop + 2ms network latency.
# These match GlitchTip production. Do NOT change these defaults.
#
# Usage: docker compose run --rm --cap-add NET_ADMIN app bash bench_asgi.sh
set -e

CONCURRENCY=${1:-50}
REQUESTS=${2:-5000}
PORT=8787
LATENCY_MS=2

echo "============================================================"
echo "ASGI BENCHMARK: ${REQUESTS} requests, ${CONCURRENCY} concurrent"
echo "  Server:  granian + uvloop"
echo "  Latency: ${LATENCY_MS}ms RTT (tc netem)"
echo "============================================================"

# Ensure C parsers are installed for fair comparison
pip install -q "valkey[libvalkey]" "redis[hiredis]" 2>/dev/null

python -c "import libvalkey; print('libvalkey:', libvalkey.__version__)"
python -c "import hiredis; print('hiredis:', hiredis.__version__)"
python -c "import uvloop; print('uvloop:', uvloop.__version__)"

# Install hey if not present
if ! command -v hey &>/dev/null; then
    echo "Installing hey..."
    GOBIN=/usr/local/bin go install github.com/rakyll/hey@latest 2>/dev/null || {
        echo "Downloading hey binary..."
        curl -sL https://hey-release.s3.us-east-2.amazonaws.com/hey_linux_amd64 -o /usr/local/bin/hey
        chmod +x /usr/local/bin/hey
    }
fi

# Add network latency to simulate production RTT to Valkey
echo "Adding ${LATENCY_MS}ms latency to valkey..."
tc qdisc add dev eth0 root netem delay ${LATENCY_MS}ms 2>/dev/null || \
    tc qdisc change dev eth0 root netem delay ${LATENCY_MS}ms

run_bench() {
    local label=$1
    local settings=$2

    echo ""
    echo "--- ${label} ---"

    # Start granian with uvloop (matches production)
    DJANGO_SETTINGS_MODULE=${settings} granian \
        --interface asgi --host 127.0.0.1 --port ${PORT} \
        --loop uvloop --workers 1 \
        sample.asgi:application &>/dev/null &
    local PID=$!
    sleep 2

    # Seed cache
    curl -s http://127.0.0.1:${PORT}/bench/seed/ > /dev/null

    # Warmup
    hey -n 200 -c 10 -q 0 http://127.0.0.1:${PORT}/bench/ > /dev/null 2>&1

    # Actual benchmark
    echo "  Running hey -n ${REQUESTS} -c ${CONCURRENCY}..."
    hey -n ${REQUESTS} -c ${CONCURRENCY} http://127.0.0.1:${PORT}/bench/ 2>&1 | \
        grep -E "Requests/sec|Average|Fastest|Slowest|Total:|Status code"

    kill $PID 2>/dev/null
    wait $PID 2>/dev/null
    sleep 1
}

# --- django-vcache v2 (Rust driver) ---
run_bench "django-vcache v2 (Rust driver)" "sample.settings"

# --- django-vcache v1 (valkey-py + libvalkey) ---
run_bench "django-vcache v1 (valkey-py + libvalkey)" "sample.settings_v1"

# --- Django built-in RedisCache (hiredis) ---
run_bench "Django RedisCache (redis-py + hiredis)" "sample.settings_django"

echo ""
echo "============================================================"
echo "DONE"
echo "============================================================"
