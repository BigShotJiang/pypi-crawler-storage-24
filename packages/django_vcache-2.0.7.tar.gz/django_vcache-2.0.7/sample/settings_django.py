"""Settings that use Django's built-in RedisCache (with hiredis) for benchmarking."""

import os

from sample.settings import *  # noqa: F401, F403

CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.redis.RedisCache",
        "LOCATION": os.environ.get("VALKEY_URL", "redis://valkey:6379/1"),
    },
}
