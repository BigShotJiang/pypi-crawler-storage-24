import re
import shutil
import socket
import subprocess
import time

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Memory stress test: sustained load, track RSS over time."

    def add_arguments(self, parser):
        parser.add_argument(
            "--duration",
            type=int,
            default=60,
            help="Test duration in seconds (default: 60)",
        )
        parser.add_argument(
            "-c", "--concurrency", type=int, default=100, help="Concurrent requests"
        )
        parser.add_argument(
            "--port", type=int, default=8787, help="Port for internal granian server"
        )
        parser.add_argument(
            "--endpoint",
            default="/bench/mixed/",
            help="Endpoint to hit (default: /bench/mixed/)",
        )

    def handle(self, *args, **options):
        duration = options["duration"]
        concurrency = options["concurrency"]
        port = options["port"]
        endpoint = options["endpoint"]

        if not shutil.which("hey"):
            self.stderr.write("Error: 'hey' not found. Run inside Docker.")
            return

        # Start granian
        self.stdout.write(f"Starting granian on :{port} (1 worker)...")
        granian = subprocess.Popen(
            [
                "granian",
                "--interface",
                "asgi",
                "--host",
                "127.0.0.1",
                "--port",
                str(port),
                "--workers",
                "1",
                "sample.asgi:application",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env={
                "DJANGO_SETTINGS_MODULE": "sample.settings_bench",
                "PATH": "/usr/local/bin:/usr/bin:/bin",
            },
        )

        base = f"http://127.0.0.1:{port}"
        self._wait_for_server(base)

        try:
            # Seed
            subprocess.run(
                ["curl", "-sf", f"{base}/bench/seed/"],
                stdout=subprocess.DEVNULL,
                check=True,
            )

            # Find granian worker PID
            time.sleep(0.5)
            worker_pid = self._find_worker_pid(granian.pid)
            if not worker_pid:
                self.stderr.write("Could not find granian worker process.")
                return

            self.stdout.write(
                f"Worker PID: {worker_pid}, duration: {duration}s, "
                f"concurrency: {concurrency}"
            )
            self.stdout.write("")
            self.stdout.write(f"{'Time (s)':>10}  {'RSS (MB)':>10}  {'Requests':>10}")
            self.stdout.write(f"{'-' * 10}  {'-' * 10}  {'-' * 10}")

            # Record initial RSS
            initial_rss = self._get_rss_mb(worker_pid)
            self.stdout.write(f"{'0':>10}  {initial_rss:>10.1f}  {'0':>10}")

            # Run hey in background for the full duration
            hey_proc = subprocess.Popen(
                [
                    "hey",
                    "-z",
                    f"{duration}s",
                    "-c",
                    str(concurrency),
                    f"{base}{endpoint}",
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )

            # Sample RSS every 5 seconds
            start = time.monotonic()
            interval = 5
            next_sample = start + interval
            while hey_proc.poll() is None:
                now = time.monotonic()
                if now >= next_sample:
                    elapsed = int(now - start)
                    rss = self._get_rss_mb(worker_pid)
                    self.stdout.write(f"{elapsed:>10}  {rss:>10.1f}  {'...':>10}")
                    next_sample = now + interval
                time.sleep(0.5)

            # Final results
            stdout, _ = hey_proc.communicate()
            final_rss = self._get_rss_mb(worker_pid)
            elapsed = int(time.monotonic() - start)

            rps = 0
            m = re.search(r"Requests/sec:\s+([\d.]+)", stdout)
            if m:
                rps = float(m.group(1))
            total = 0
            total_200 = 0
            for m in re.finditer(r"\[(\d+)\]\s+(\d+)\s+responses", stdout):
                total_200 += int(m.group(2))
            if total_200:
                total = total_200

            self.stdout.write(f"{elapsed:>10}  {final_rss:>10.1f}  {total:>10}")

            self.stdout.write("")
            self.stdout.write(f"Initial RSS:  {initial_rss:.1f} MB")
            self.stdout.write(f"Final RSS:    {final_rss:.1f} MB")
            self.stdout.write(f"RSS growth:   {final_rss - initial_rss:+.1f} MB")
            self.stdout.write(f"Requests/sec: {rps:,.0f}")
            self.stdout.write(f"Total:        {total:,}")

            growth = final_rss - initial_rss
            if growth > 50:
                self.stdout.write("\nWARNING: RSS grew >50 MB — possible memory leak")
            elif growth > 20:
                self.stdout.write(
                    "\nNOTE: RSS grew >20 MB — may be fragmentation or warm-up"
                )
            else:
                self.stdout.write("\nOK: RSS stable")

        finally:
            granian.terminate()
            granian.wait()

    def _find_worker_pid(self, parent_pid):
        """Find granian worker child process (largest RSS child)."""
        try:
            result = subprocess.run(
                ["ps", "--ppid", str(parent_pid), "-o", "pid=,rss="],
                capture_output=True,
                text=True,
            )
            best_pid, best_rss = None, 0
            for line in result.stdout.strip().splitlines():
                parts = line.split()
                if len(parts) == 2:
                    pid, rss = int(parts[0]), int(parts[1])
                    if rss > best_rss:
                        best_pid, best_rss = pid, rss
            if best_pid:
                self.stdout.write(
                    f"  Found worker PID {best_pid} "
                    f"(RSS {best_rss / 1024:.1f} MB, parent {parent_pid})"
                )
                return best_pid
        except Exception:
            pass
        return parent_pid

    def _get_rss_mb(self, pid):
        """Read RSS from /proc/<pid>/status."""
        try:
            with open(f"/proc/{pid}/status") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        kb = int(line.split()[1])
                        return kb / 1024.0
        except (FileNotFoundError, ProcessLookupError):
            pass
        return 0.0

    def _wait_for_server(self, base, timeout=10):
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                s = socket.socket()
                s.settimeout(1)
                port = int(base.rsplit(":", 1)[1].rstrip("/"))
                s.connect(("127.0.0.1", port))
                s.close()
                return
            except (ConnectionRefusedError, OSError):
                time.sleep(0.2)
        raise RuntimeError("granian did not start in time")
