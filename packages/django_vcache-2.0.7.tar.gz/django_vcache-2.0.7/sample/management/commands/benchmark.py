import re
import shutil
import socket
import subprocess
import time

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Benchmark cache backend under real ASGI HTTP load with simulated latency."

    def add_arguments(self, parser):
        parser.add_argument(
            "-n", "--requests", type=int, default=10000, help="Total requests"
        )
        parser.add_argument(
            "-c", "--concurrency", type=int, default=200, help="Concurrent requests"
        )
        parser.add_argument(
            "--latency", type=int, default=2, help="Simulated latency to Valkey (ms)"
        )
        parser.add_argument(
            "--port", type=int, default=8787, help="Port for internal granian server"
        )
        parser.add_argument(
            "--no-latency",
            action="store_true",
            help="Skip latency injection (for localhost testing)",
        )

    def handle(self, *args, **options):
        requests = options["requests"]
        concurrency = options["concurrency"]
        latency_ms = options["latency"]
        port = options["port"]
        add_latency = not options["no_latency"]

        if not shutil.which("hey"):
            self.stderr.write(
                "Error: 'hey' not found. Run inside the Docker container."
            )
            return

        # Resolve valkey IP for tc filter
        valkey_ip = None
        if add_latency:
            try:
                valkey_ip = socket.gethostbyname("valkey")
            except socket.gaierror:
                self.stderr.write(
                    "Cannot resolve 'valkey'. Use --no-latency or run inside Docker."
                )
                return
            self._add_latency(valkey_ip, latency_ms)
            self._verify_latency()

        # Start granian
        self.stdout.write(f"\nStarting granian on :{port}...")
        granian = subprocess.Popen(
            [
                "granian",
                "--interface",
                "asgi",
                "--host",
                "127.0.0.1",
                "--port",
                str(port),
                "--workers",
                "1",
                "sample.asgi:application",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env={
                "DJANGO_SETTINGS_MODULE": "sample.settings_bench",
                "PATH": "/usr/local/bin:/usr/bin:/bin",
            },
        )
        base = f"http://127.0.0.1:{port}"
        self._wait_for_server(base, timeout=10)

        try:
            # Seed
            subprocess.run(
                ["curl", "-sf", f"{base}/bench/seed/"],
                stdout=subprocess.DEVNULL,
                check=True,
            )

            # Run benchmark
            settings = []
            if add_latency:
                settings.append(f"{latency_ms}ms latency")
            else:
                settings.append("no latency")
            self.stdout.write(
                f"\nBenchmark: {requests} requests, "
                f"{concurrency} concurrent, {', '.join(settings)}"
            )
            self.stdout.write("Endpoint: /bench/mixed/ (6 cache ops per request)\n")

            result = subprocess.run(
                [
                    "hey",
                    "-n",
                    str(requests),
                    "-c",
                    str(concurrency),
                    f"{base}/bench/mixed/",
                ],
                capture_output=True,
                text=True,
            )

            # Parse hey output
            rps = self._parse_hey_rps(result.stdout)
            latency_avg = self._parse_hey_latency(result.stdout)
            errors = self._parse_hey_errors(result.stdout)

            if errors:
                self.stderr.write(f"  Errors: {errors}")

            # Print results
            self.stdout.write(f"  Requests/sec:  {rps:,.0f}")
            self.stdout.write(f"  Avg latency:   {latency_avg:.1f} ms")
            self.stdout.write(f"  Cache ops/sec: {rps * 6:,.0f} (6 ops/request)")

            self.stdout.write(f"\n{'=' * 40}")
            self.stdout.write(f"  SCORE: {rps:,.0f} req/s")
            self.stdout.write(f"{'=' * 40}\n")

        finally:
            granian.terminate()
            granian.wait()
            if add_latency and valkey_ip:
                self._remove_latency()

    def _add_latency(self, valkey_ip, latency_ms):
        self.stdout.write(f"Adding {latency_ms}ms latency to {valkey_ip}...")
        cmds = [
            "tc qdisc add dev eth0 root handle 1: prio",
            f"tc qdisc add dev eth0 parent 1:1 handle 10: netem delay {latency_ms}ms",
            f"tc filter add dev eth0 parent 1:0 protocol ip u32 "
            f"match ip dst {valkey_ip}/32 flowid 1:1",
        ]
        for cmd in cmds:
            subprocess.run(cmd.split(), capture_output=True)

    def _remove_latency(self):
        subprocess.run(
            "tc qdisc del dev eth0 root".split(),
            capture_output=True,
        )

    def _verify_latency(self):
        try:
            s = socket.socket()
            t0 = time.perf_counter()
            s.connect(("valkey", 6379))
            ms = (time.perf_counter() - t0) * 1000
            s.close()
            self.stdout.write(f"  Measured RTT: {ms:.1f}ms")
        except Exception as e:
            self.stderr.write(f"  Latency check failed: {e}")

    def _wait_for_server(self, base, timeout=10):
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                s = socket.socket()
                s.settimeout(1)
                port = int(base.rsplit(":", 1)[1].rstrip("/"))
                s.connect(("127.0.0.1", port))
                s.close()
                return
            except (ConnectionRefusedError, OSError):
                time.sleep(0.2)
        raise RuntimeError("granian did not start in time")

    def _parse_hey_rps(self, output):
        m = re.search(r"Requests/sec:\s+([\d.]+)", output)
        return float(m.group(1)) if m else 0

    def _parse_hey_latency(self, output):
        m = re.search(r"Average:\s+([\d.]+)\s+secs", output)
        return float(m.group(1)) * 1000 if m else 0

    def _parse_hey_errors(self, output):
        # hey reports non-200 in status code distribution
        errors = []
        for m in re.finditer(r"\[(\d+)\]\s+(\d+)\s+responses", output):
            code, count = int(m.group(1)), int(m.group(2))
            if code != 200:
                errors.append(f"{count}x HTTP {code}")
        return ", ".join(errors) if errors else None
