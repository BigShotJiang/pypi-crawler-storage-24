import os

SECRET_KEY = "django-insecure-dummy-key-for-testing"
DEBUG = False
ALLOWED_HOSTS = ["*"]

# Using a dummy database as Django requires one.
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": ":memory:",
    }
}

INSTALLED_APPS = [
    "sample",
]

ROOT_URLCONF = "sample.urls"

# Cache settings to use the custom backend.
CACHES = {
    "default": {
        "BACKEND": "django_vcache.backend.ValkeyCache",
        "LOCATION": os.environ.get("VALKEY_URL", "redis://valkey:6379/1"),
    },
}

if os.environ.get("VALKEY_CLUSTER_MODE") == "true":
    CACHES["default"]["OPTIONS"] = {
        "CLUSTER_MODE": True,
    }
