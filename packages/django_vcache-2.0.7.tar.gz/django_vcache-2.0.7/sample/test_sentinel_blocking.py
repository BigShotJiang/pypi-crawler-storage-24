import os
import unittest

from django_vcache.backend import ValkeyCache


class SentinelTests(unittest.TestCase):
    def setUp(self):
        self.sentinel_url = os.environ.get("VALKEY_URL")
        if not self.sentinel_url or not self.sentinel_url.startswith("sentinel://"):
            self.skipTest("VALKEY_URL is not set to a sentinel URL")

    def test_sentinel_connection(self):
        options = {"LOCATION": self.sentinel_url, "OPTIONS": {}}
        cache = ValkeyCache(self.sentinel_url, options)
        client = cache.get_raw_client()
        # Verify basic operations work through sentinel
        client.set_sync("sentinel_test", b"hello", 60)
        self.assertEqual(client.get_sync("sentinel_test"), b"hello")

    async def test_sentinel_async_connection(self):
        options = {"LOCATION": self.sentinel_url, "OPTIONS": {}}
        cache = ValkeyCache(self.sentinel_url, options)
        client = cache.get_raw_client()
        await client.set("sentinel_async_test", b"hello", 60)
        self.assertEqual(await client.get("sentinel_async_test"), b"hello")
