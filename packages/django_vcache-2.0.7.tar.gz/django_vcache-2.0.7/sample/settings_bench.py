from sample.settings import *  # noqa: F401, F403

# Rust driver uses a single multiplexed connection — no pool to configure.
