# django-vcache

Django cache backend for Valkey/Redis with a Rust I/O driver (PyO3 + maturin). Used by GlitchTip.

## Production stack (MUST match in all benchmarks)

- **ASGI server**: granian (never uvicorn)
- **Event loop**: uvloop (always `--loop uvloop`)
- **Network latency**: 2ms RTT via `tc netem` (never benchmark at 0ms — it hides real bugs)
- **Python**: 3.14
- **OS**: Debian (not Alpine/musl)

These are non-negotiable. Shipped regressions were caused by benchmarking
without production settings (missing uvloop, missing latency, missing libvalkey
C parser). If a benchmark script doesn't use all of the above, the results are
meaningless. libvalkey is already a dev dependency so it's always installed.

## Build and test

Tests require Docker (volume mount means the .so must be built in-container):

```sh
docker compose build && docker compose up -d valkey
docker compose run --rm app bash -c \
  "pip install maturin && rm -f target/wheels/*.whl && \
   maturin build --release --interpreter python && \
   pip install --force-reinstall --no-deps target/wheels/*.whl && \
   python manage.py test"
```

## Benchmarking

All benchmarks run inside Docker with `--cap-add NET_ADMIN` (for tc netem):

```sh
# Quick slow-path stress test (catches GIL/tokio starvation bugs)
docker compose run --rm --cap-add NET_ADMIN app bash bench_slowpath.sh

# Full comparison: v2 Rust vs v1 valkey-py
docker compose run --rm --cap-add NET_ADMIN app python bench_compare.py
```

## Linting

CI enforces ruff format + ruff check. Always verify:

```sh
uvx ruff format --check .
uvx ruff check .
```

Fix with: `uvx ruff format . && uvx ruff check --fix .`

## Architecture

- `src/` — Rust I/O driver (PyO3). Raw bytes only, no serialization.
  - `async_bridge.rs` — Deferred-callback awaitable bridge between tokio and asyncio.
  - `client.rs` — `RustValkeyDriver` PyO3 class, all Redis commands.
  - `connection.rs` — ConnectionManager setup (standalone, cluster, sentinel).
- `django_vcache/backend.py` — Python cache backend. Serialization (ormsgpack + zstd).
- `sample/` — Test Django app with benchmark endpoints.

## Key invariants

- Integers stored as raw strings for native Redis INCRBY — never GET+SET for incr/decr.
- Tokio worker threads must NEVER block on the Python GIL. Use `spawn_blocking` for any code that calls `Python::try_attach` or `Python::with_gil`.
- The oneshot channel fast path (`try_recv` in `__next__`) must remain zero-overhead.
