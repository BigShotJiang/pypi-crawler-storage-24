#!/usr/bin/env python3
"""
Benchmark: django-vcache (Rust) vs django-vcache 1.x (valkey-py).

Uses granian ASGI server with simulated network latency (tc netem)
to replicate managed Valkey conditions (e.g. DigitalOcean, AWS).

Each request does 6 cache operations (get, get_many, set, set large, incr,
get large) — see sample/views.py bench_mixed() for details.

Run inside Docker:
    docker compose run --rm app python bench_compare.py \
        [--duration 60] [-c 300] [--delay 1]
"""

import argparse
import os
import re
import socket
import subprocess
import sys
import time


def get_rss_mb(pid):
    try:
        with open(f"/proc/{pid}/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) / 1024.0
    except (FileNotFoundError, ProcessLookupError):
        pass
    return 0.0


def get_total_rss_mb(parent_pid):
    """Sum RSS of all worker processes (children of parent)."""
    try:
        result = subprocess.run(
            ["ps", "--ppid", str(parent_pid), "-o", "rss="],
            capture_output=True,
            text=True,
        )
        total = 0.0
        for line in result.stdout.strip().splitlines():
            line = line.strip()
            if line:
                total += int(line) / 1024.0
        return total or get_rss_mb(parent_pid)
    except Exception:
        return get_rss_mb(parent_pid)


def get_valkey_connections():
    try:
        import redis

        r = redis.Redis(host="valkey", port=6379, socket_timeout=1)
        count = r.info("clients").get("connected_clients", 0)
        r.close()
        return count
    except Exception:
        return -1


def flush_valkey():
    try:
        import redis

        r = redis.Redis(host="valkey", port=6379, socket_timeout=1)
        r.flushall()
        r.close()
    except Exception:
        pass


def wait_for_server(port, timeout=15):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            s = socket.socket()
            s.settimeout(1)
            s.connect(("127.0.0.1", port))
            s.close()
            return True
        except (ConnectionRefusedError, OSError):
            time.sleep(0.2)
    return False


def add_latency(delay_ms):
    """Add one-way delay to all eth0 traffic via tc netem.

    Only affects external traffic (Valkey). Localhost (hey → granian)
    goes through lo and is unaffected.
    """
    subprocess.run(
        [
            "tc",
            "qdisc",
            "add",
            "dev",
            "eth0",
            "root",
            "netem",
            "delay",
            f"{delay_ms}ms",
        ],
        capture_output=True,
    )
    print(f"  Network latency: {delay_ms}ms one-way on eth0")


def remove_latency():
    subprocess.run(["tc", "qdisc", "del", "dev", "eth0", "root"], capture_output=True)


def run_benchmark(name, settings_module, duration, concurrency, port, workers=1):
    print(f"\n{'=' * 70}")
    print(f"  {name}")
    print(f"{'=' * 70}")

    flush_valkey()
    time.sleep(0.5)

    env = {
        "DJANGO_SETTINGS_MODULE": settings_module,
        "PATH": os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"),
        "PYTHONPATH": "/app",
        "VALKEY_URL": "redis://valkey:6379/1",
    }

    proc = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "granian",
            "sample.asgi:application",
            "--interface",
            "asgi",
            "--host",
            "127.0.0.1",
            "--port",
            str(port),
            "--loop",
            "uvloop",
            "--workers",
            str(workers),
            "--no-ws",
        ],
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    base = f"http://127.0.0.1:{port}"
    if not wait_for_server(port):
        print("  ERROR: server did not start")
        proc.terminate()
        proc.wait()
        return None

    try:
        time.sleep(1)  # give workers time to spawn

        # Seed cache
        subprocess.run(
            ["curl", "-sf", f"{base}/bench/seed/"],
            stdout=subprocess.DEVNULL,
            timeout=5,
        )
        time.sleep(0.5)

        initial_rss = get_total_rss_mb(proc.pid)
        initial_conns = get_valkey_connections()

        print(f"  Workers: {workers}, Initial RSS: {initial_rss:.1f} MB")
        print(f"  Duration: {duration}s, Concurrency: {concurrency}")
        print()
        print(f"  {'Time':>6}  {'RSS MB':>8}  {'Conns':>6}")
        print(f"  {'─' * 6}  {'─' * 8}  {'─' * 6}")
        print(f"  {'0s':>6}  {initial_rss:>8.1f}  {initial_conns:>6}")

        # Start load
        hey_proc = subprocess.Popen(
            [
                "hey",
                "-z",
                f"{duration}s",
                "-c",
                str(concurrency),
                "-t",
                "10",
                f"{base}/bench/mixed/",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        # Sample every 5s
        samples = []
        start = time.monotonic()
        peak_conns = initial_conns
        peak_rss = initial_rss

        while hey_proc.poll() is None:
            now = time.monotonic()
            elapsed = now - start
            if elapsed >= len(samples) * 5 + 5:
                rss = get_total_rss_mb(proc.pid)
                conns = get_valkey_connections()
                peak_conns = max(peak_conns, conns)
                peak_rss = max(peak_rss, rss)
                samples.append((int(elapsed), rss, conns))
                print(f"  {int(elapsed):>5}s  {rss:>8.1f}  {conns:>6}")
            time.sleep(0.5)

        stdout, _ = hey_proc.communicate()
        final_rss = get_total_rss_mb(proc.pid)
        final_conns = get_valkey_connections()
        peak_conns = max(peak_conns, final_conns)
        peak_rss = max(peak_rss, final_rss)
        elapsed = int(time.monotonic() - start)

        # Parse hey output
        rps = 0.0
        avg_latency = 0.0
        p99_latency = 0.0
        total_requests = 0
        errors = 0

        m = re.search(r"Requests/sec:\s+([\d.]+)", stdout)
        if m:
            rps = float(m.group(1))

        m = re.search(r"Average:\s+([\d.]+)\s+secs", stdout)
        if m:
            avg_latency = float(m.group(1)) * 1000

        m = re.search(r"99%\s+in\s+([\d.]+)\s+secs", stdout)
        if m:
            p99_latency = float(m.group(1)) * 1000

        for m_line in re.finditer(r"\[(\d+)\]\s+(\d+)\s+responses", stdout):
            code, count = int(m_line.group(1)), int(m_line.group(2))
            total_requests += count
            if code >= 400:
                errors += count

        if not total_requests:
            m = re.search(r"Total:\s+(\d+)", stdout)
            if m:
                total_requests = int(m.group(1))

        print(f"  {elapsed:>5}s  {final_rss:>8.1f}  {final_conns:>6}  (final)")

        # Cooldown — let GC settle, connections close
        time.sleep(5)
        settled_rss = get_total_rss_mb(proc.pid)
        settled_conns = get_valkey_connections()
        print(f"  +5s cooldown  {settled_rss:>8.1f}  {settled_conns:>6}  (settled)")

        result = {
            "name": name,
            "rps": rps,
            "avg_latency_ms": avg_latency,
            "p99_latency_ms": p99_latency,
            "initial_rss": initial_rss,
            "final_rss": final_rss,
            "peak_rss": peak_rss,
            "rss_growth": final_rss - initial_rss,
            "peak_conns": peak_conns,
            "final_conns": final_conns,
            "settled_rss": settled_rss,
            "settled_conns": settled_conns,
            "total_requests": total_requests,
            "errors": errors,
        }

        print(f"\n  Requests/sec:  {rps:,.0f}")
        print(f"  Avg latency:   {avg_latency:.1f} ms")
        print(f"  P99 latency:   {p99_latency:.1f} ms")
        print(
            f"  RSS growth:    {initial_rss:.0f} → {final_rss:.0f} MB "
            f"(peak {peak_rss:.0f} MB)"
        )
        print(f"  Valkey conns:  peak {peak_conns}, final {final_conns}")
        if errors:
            print(f"  Errors:        {errors}")

        return result

    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        time.sleep(1)


def main():
    parser = argparse.ArgumentParser(
        description="django-vcache (Rust) vs v1.x (valkey-py) benchmark"
    )
    parser.add_argument(
        "--duration",
        type=int,
        default=60,
        help="Duration per test in seconds (default: 60)",
    )
    parser.add_argument(
        "-c",
        "--concurrency",
        type=int,
        default=300,
        help="Concurrent connections (default: 300)",
    )
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument(
        "--delay",
        type=int,
        default=1,
        help="One-way latency in ms added to Valkey traffic (default: 1, i.e. 2ms RTT)",
    )
    parser.add_argument(
        "--no-latency",
        action="store_true",
        help="Skip adding latency (use local Valkey speed)",
    )
    parser.add_argument(
        "-w",
        "--workers",
        type=int,
        default=4,
        help="Granian worker processes (default: 4)",
    )
    args = parser.parse_args()

    # Ensure valkey-py is installed for v1 backend
    try:
        import valkey  # noqa: F401
    except ImportError:
        print("Installing valkey-py for v1 benchmark...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "valkey[libvalkey]", "-q"],
            check=True,
        )

    if not args.no_latency:
        remove_latency()
        add_latency(args.delay)

    try:
        print(
            f"Benchmark: django-vcache vs valkey-py"
            f"\ngranian ASGI, {args.workers} workers, "
            f"{args.concurrency} concurrent, {args.duration}s each"
            f"{'' if args.no_latency else f', {args.delay * 2}ms simulated RTT'}"
        )

        tests = [
            ("django-vcache 2.x (Rust)", "sample.settings"),
            ("django-vcache 1.x (valkey-py)", "sample.settings_v1"),
        ]

        results = []
        for name, settings in tests:
            r = run_benchmark(
                name,
                settings,
                args.duration,
                args.concurrency,
                args.port,
                workers=args.workers,
            )
            if r:
                results.append(r)

        if len(results) >= 2:
            print(f"\n{'=' * 70}")
            print("  COMPARISON")
            print(f"{'=' * 70}")

            w = 20
            headers = [r["name"].split("(")[0].strip()[:12] for r in results]
            header_line = f"  {'':>{w}}"
            for h in headers:
                header_line += f"  {h:>12}"
            print(f"\n{header_line}")
            print(f"  {'─' * w}" + f"  {'─' * 12}" * len(results))

            for field, label, fmt in [
                ("rps", "Requests/sec", ",.0f"),
                ("avg_latency_ms", "Avg latency (ms)", ".1f"),
                ("p99_latency_ms", "P99 latency (ms)", ".1f"),
                ("peak_rss", "Peak RSS (MB)", ".0f"),
                ("settled_rss", "Settled RSS (MB)", ".0f"),
                ("peak_conns", "Peak Valkey conns", ""),
                ("settled_conns", "Settled conns", ""),
            ]:
                line = f"  {label:>{w}}"
                for r in results:
                    val = r[field]
                    if fmt:
                        line += f"  {val:>12{fmt}}"
                    else:
                        line += f"  {val:>12}"
                print(line)

            has_errors = any(r["errors"] for r in results)
            if has_errors:
                line = f"  {'Errors':>{w}}"
                for r in results:
                    line += f"  {r['errors']:>12}"
                print(line)

            print()

    finally:
        if not args.no_latency:
            remove_latency()


if __name__ == "__main__":
    main()
