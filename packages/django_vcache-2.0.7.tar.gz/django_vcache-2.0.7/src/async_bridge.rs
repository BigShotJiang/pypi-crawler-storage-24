use pyo3::prelude::*;
use pyo3::types::{PyBytes, PyList, PyString, PyTuple};
use std::sync::{Arc, Mutex, OnceLock};
use tokio::runtime::Runtime;
use tokio::sync::oneshot;

static RUNTIME: OnceLock<Runtime> = OnceLock::new();

pub fn get_runtime() -> &'static Runtime {
    RUNTIME.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .build()
            .expect("Failed to create tokio runtime")
    })
}

// =========================================================================
// Result types — Rust-native, no GIL needed to construct
// =========================================================================

pub enum RawResult {
    OptBytes(Option<Vec<u8>>),
    Bool(bool),
    Int(i64),
    OptBytesList(Vec<Option<Vec<u8>>>),
    BytesList(Vec<Vec<u8>>),
    StringList(Vec<String>),
    OptKeyAndBytesList(Option<(String, Vec<Vec<u8>>)>),
    /// Connection/IO error → PyConnectionError (swallowed by IGNORE_EXCEPTIONS)
    Error(String),
    /// Data/server error → PyRuntimeError (NOT swallowed, indicates real problems)
    ServerError(String),
}

impl RawResult {
    pub fn into_py(self, py: Python<'_>) -> Result<Py<PyAny>, PyErr> {
        match self {
            RawResult::OptBytes(Some(b)) => Ok(PyBytes::new(py, &b).into_any().unbind()),
            RawResult::OptBytes(None) => Ok(py.None()),
            RawResult::Bool(b) => {
                Ok(b.into_pyobject(py).unwrap().to_owned().into_any().unbind())
            }
            RawResult::Int(n) => Ok(n.into_pyobject(py).unwrap().into_any().unbind()),
            RawResult::OptBytesList(items) => {
                let py_items: Vec<Py<PyAny>> = items
                    .into_iter()
                    .map(|r| match r {
                        Some(bytes) => PyBytes::new(py, &bytes).into_any().unbind(),
                        None => py.None(),
                    })
                    .collect();
                Ok(PyList::new(py, py_items)?.into_any().unbind())
            }
            RawResult::BytesList(items) => {
                let py_items: Vec<Py<PyAny>> = items
                    .iter()
                    .map(|b| PyBytes::new(py, b).into_any().unbind())
                    .collect();
                Ok(PyList::new(py, py_items)?.into_any().unbind())
            }
            RawResult::StringList(items) => {
                let py_items: Vec<Py<PyAny>> = items
                    .iter()
                    .map(|s| PyString::new(py, s).into_any().unbind())
                    .collect();
                Ok(PyList::new(py, py_items)?.into_any().unbind())
            }
            RawResult::OptKeyAndBytesList(Some((key, values))) => {
                let py_values: Vec<Py<PyAny>> = values
                    .iter()
                    .map(|b| PyBytes::new(py, b).into_any().unbind())
                    .collect();
                let py_key = PyString::new(py, &key).into_any().unbind();
                let py_list = PyList::new(py, py_values)?.into_any().unbind();
                Ok(PyTuple::new(py, [py_key, py_list])?.into_any().unbind())
            }
            RawResult::OptKeyAndBytesList(None) => Ok(py.None()),
            RawResult::Error(e) => Err(pyo3::exceptions::PyConnectionError::new_err(e)),
            RawResult::ServerError(e) => Err(pyo3::exceptions::PyRuntimeError::new_err(e)),
        }
    }
}

// =========================================================================
// RustAwaitable — deferred-callback async bridge
//
// The tokio task sends its result via a oneshot channel — no GIL needed.
//
// __next__ polls try_recv(). For fast local operations, the result is
// usually ready on the first call → zero overhead, identical to the old
// busy-yield approach.
//
// If the result isn't ready on the first __next__, we yield None once
// (one busy-yield iteration). If still not ready on the second __next__,
// we switch to callback mode: get the event loop, spawn a lightweight
// watcher task, and yield self with _asyncio_future_blocking=True.
// The watcher awaits the oneshot and calls call_soon_threadsafe(_wake).
//
// This gives us the best of both worlds:
// - Fast path: zero GIL from tokio threads, minimal per-op overhead
// - Slow path: proper callback-based suspend (no CPU burn)
// - Idle: zero CPU (no busy-yield loops)
// =========================================================================

#[pyclass]
pub struct RustAwaitable {
    rx: Option<oneshot::Receiver<RawResult>>,
    /// Successful result value — stored for result() after StopIteration delivery.
    value: Option<Py<PyAny>>,
    /// Error exception object — raised by result() for the Task to propagate.
    error: Option<Py<PyAny>>,
    /// Whether we have a stored result (value or error).
    resolved: bool,
    /// Whether cancel() was called.
    cancelled: bool,
    callbacks: Vec<Py<PyAny>>,
    #[pyo3(get, set)]
    _asyncio_future_blocking: bool,
    /// Set lazily on first slow-path entry.
    #[pyo3(get)]
    _loop: Option<Py<PyAny>>,
    /// Number of times __next__ has been called without a result.
    polls: u8,
    /// Slot for the watcher task to store the raw result without acquiring the GIL.
    /// Avoids blocking tokio worker threads on GIL contention.
    result_slot: Option<Arc<Mutex<Option<Result<RawResult, ()>>>>>,
}

/// Helper: raise asyncio.CancelledError.
fn cancelled_error(py: Python<'_>) -> PyErr {
    if let Ok(asyncio) = py.import("asyncio") {
        if let Ok(cls) = asyncio.getattr("CancelledError") {
            if let Ok(exc) = cls.call0() {
                return PyErr::from_value(exc.into_any());
            }
        }
    }
    // Fallback if asyncio import fails (shouldn't happen in practice)
    pyo3::exceptions::PyRuntimeError::new_err("cancelled")
}

/// Helper: deliver a successful result via StopIteration and store in self.value.
fn deliver_value(
    this: &mut RustAwaitable,
    py: Python<'_>,
    val: Py<PyAny>,
) -> PyResult<Py<PyAny>> {
    this.resolved = true;
    this.value = Some(val.clone_ref(py));
    let stop = py
        .get_type::<pyo3::exceptions::PyStopIteration>()
        .call1((val,))?;
    Err(PyErr::from_value(stop.into_any()))
}

/// Helper: store an error and raise it.
fn deliver_error(this: &mut RustAwaitable, py: Python<'_>, err: PyErr) -> PyResult<Py<PyAny>> {
    this.resolved = true;
    this.error = Some(err.value(py).clone().into_any().unbind());
    Err(err)
}

#[pymethods]
impl RustAwaitable {
    fn __await__(slf: Py<Self>) -> Py<Self> {
        slf
    }

    fn __iter__(slf: Py<Self>) -> Py<Self> {
        slf
    }

    fn __next__(slf: Py<Self>, py: Python<'_>) -> PyResult<Py<PyAny>> {
        let mut this = slf.borrow_mut(py);

        // Cancelled — raise CancelledError.
        if this.cancelled {
            return Err(cancelled_error(py));
        }

        // Already resolved — re-deliver stored result.
        if this.resolved {
            if let Some(ref exc) = this.error {
                return Err(PyErr::from_value(exc.bind(py).clone()));
            }
            if let Some(ref value) = this.value {
                let stop = py
                    .get_type::<pyo3::exceptions::PyStopIteration>()
                    .call1((value,))?;
                return Err(PyErr::from_value(stop.into_any()));
            }
            return Err(pyo3::exceptions::PyRuntimeError::new_err(
                "awaitable already consumed",
            ));
        }

        // Check result_slot (set by watcher task via Rust mutex, no GIL needed).
        if let Some(slot) = this.result_slot.take() {
            if let Some(raw_result) = slot.lock().unwrap().take() {
                return match raw_result {
                    Ok(raw) => match raw.into_py(py) {
                        Ok(val) => deliver_value(&mut this, py, val),
                        Err(e) => deliver_error(&mut this, py, e),
                    },
                    Err(()) => deliver_error(
                        &mut this,
                        py,
                        pyo3::exceptions::PyRuntimeError::new_err("operation was dropped"),
                    ),
                };
            }
            // Result not yet available — put the slot back
            this.result_slot = Some(slot);
        }

        // Try to read result directly from the oneshot channel.
        if let Some(rx) = this.rx.as_mut() {
            match rx.try_recv() {
                Ok(raw) => {
                    this.rx = None;
                    return match raw.into_py(py) {
                        Ok(val) => deliver_value(&mut this, py, val),
                        Err(e) => deliver_error(&mut this, py, e),
                    };
                }
                Err(oneshot::error::TryRecvError::Closed) => {
                    this.rx = None;
                    return deliver_error(
                        &mut this,
                        py,
                        pyo3::exceptions::PyRuntimeError::new_err("operation was dropped"),
                    );
                }
                Err(oneshot::error::TryRecvError::Empty) => {
                    // Not ready yet
                }
            }
        } else if this.resolved {
            return Err(pyo3::exceptions::PyRuntimeError::new_err(
                "awaitable already consumed",
            ));
        }

        this.polls += 1;

        if this.polls <= 1 {
            // First poll miss: yield None (one busy-yield, like old approach).
            // This covers the case where the tokio task completes between
            // await-creation and the first __next__ scheduling.
            drop(this);
            return Ok(py.None());
        }

        // Second poll miss: switch to callback mode.
        // Get the event loop, spawn a watcher, and suspend properly.
        let rx = this.rx.take().ok_or_else(|| {
            pyo3::exceptions::PyRuntimeError::new_err("awaitable already consumed")
        })?;

        let asyncio = py.import("asyncio")?;
        let event_loop = asyncio.call_method0("get_running_loop")?;
        this._loop = Some(event_loop.clone().into_any().unbind());
        this._asyncio_future_blocking = true;

        // Spawn a lightweight watcher that awaits the result and wakes us.
        // CRITICAL: The watcher stores the result via a Rust mutex (no GIL needed)
        // and dispatches the wake call to spawn_blocking. This keeps tokio worker
        // threads free — blocking them on GIL contention causes cascading failure
        // under load (all workers stuck on GIL → no I/O progress → starvation).
        let event_loop_ref = event_loop.into_any().unbind();
        let awaitable_ref = slf.clone_ref(py).into_any();
        let result_slot = Arc::new(Mutex::new(None));
        this.result_slot = Some(result_slot.clone());
        get_runtime().spawn(async move {
            let raw = rx.await;
            // Store result via Rust mutex — NO GIL acquisition on tokio worker.
            let raw_result = match raw {
                Ok(r) => Ok(r),
                Err(_) => Err(()),
            };
            *result_slot.lock().unwrap() = Some(raw_result);
            // Wake the event loop from the blocking thread pool, not a tokio worker.
            tokio::task::spawn_blocking(move || {
                Python::try_attach(|py| {
                    if let Ok(wake) = awaitable_ref.getattr(py, "_wake") {
                        let _ =
                            event_loop_ref.call_method1(py, "call_soon_threadsafe", (wake,));
                    }
                });
            });
        });

        drop(this);
        Ok(slf.into_any())
    }

    /// Called on the event loop thread via call_soon_threadsafe.
    /// Fires done-callbacks so the Task can resume.
    fn _wake(slf: Py<Self>, py: Python<'_>) {
        let callbacks = {
            let mut this = slf.borrow_mut(py);
            std::mem::take(&mut this.callbacks)
        };
        for cb in callbacks {
            let _ = cb.call1(py, (&slf,));
        }
    }

    #[pyo3(signature = (fn_cb, *, context=None))]
    fn add_done_callback(&mut self, fn_cb: Py<PyAny>, context: Option<Py<PyAny>>) {
        let _ = context;
        if self.resolved || self.cancelled {
            // Already done — asyncio expects immediate callback scheduling.
            // Store it; _wake or the next __next__ won't fire, but the Task
            // protocol handles this by calling result()/exception() directly.
            // In practice, asyncio doesn't add callbacks after done.
        }
        self.callbacks.push(fn_cb);
    }

    fn result(&self, py: Python<'_>) -> PyResult<Py<PyAny>> {
        if self.cancelled {
            return Err(cancelled_error(py));
        }
        if let Some(ref exc) = self.error {
            return Err(PyErr::from_value(exc.bind(py).clone()));
        }
        // Return stored value if resolved, otherwise None.
        // NOTE: we intentionally do NOT raise "not ready" for pending futures.
        // asyncio's C Task implementation calls result() from the done callback
        // before __next__ has consumed the result. Raising here would break
        // the protocol. The actual value is delivered via StopIteration in __next__.
        match &self.value {
            Some(v) => Ok(v.clone_ref(py)),
            None => Ok(py.None()),
        }
    }

    fn exception(&self, py: Python<'_>) -> PyResult<Py<PyAny>> {
        if self.cancelled {
            let asyncio = py.import("asyncio")?;
            let exc = asyncio.getattr("CancelledError")?.call0()?;
            return Ok(exc.into_any().unbind());
        }
        match &self.error {
            Some(exc) => Ok(exc.clone_ref(py)),
            None => Ok(py.None()),
        }
    }

    /// Cancel the awaitable. Drops the oneshot receiver so the tokio task
    /// result is discarded. Returns True if successfully cancelled.
    /// asyncio's Task handles the actual wakeup via Task.__cancel_step,
    /// which throws CancelledError into the coroutine.
    #[pyo3(signature = (msg=None))]
    fn cancel(&mut self, msg: Option<Py<PyAny>>) -> bool {
        let _ = msg;
        if self.resolved || self.cancelled {
            return false;
        }
        self.cancelled = true;
        self.rx = None;
        self.result_slot = None;
        true
    }

    fn cancelled(&self) -> bool {
        self.cancelled
    }

    fn done(&self) -> bool {
        self.resolved || self.cancelled
    }
}

impl RustAwaitable {
    pub fn new(rx: oneshot::Receiver<RawResult>) -> Self {
        RustAwaitable {
            rx: Some(rx),
            value: None,
            error: None,
            resolved: false,
            cancelled: false,
            callbacks: Vec::new(),
            _asyncio_future_blocking: false,
            _loop: None,
            polls: 0,
            result_slot: None,
        }
    }
}
