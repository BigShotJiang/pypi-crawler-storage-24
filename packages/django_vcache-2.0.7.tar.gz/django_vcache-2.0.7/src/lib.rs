mod async_bridge;
mod client;
mod connection;

use pyo3::prelude::*;

#[pymodule]
fn _driver(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Install the rustls crypto provider for TLS support (rediss:// URLs).
    // Uses the ring backend. Ignore AlreadyInstalled if module is re-imported.
    let _ = rustls::crypto::ring::default_provider().install_default();

    m.add_class::<client::RustValkeyDriver>()?;
    m.add_class::<async_bridge::RustAwaitable>()?;
    Ok(())
}
