#!/bin/bash
# Generate self-signed certs for Valkey TLS testing
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"

# CA cert with proper key usage
cat > "$DIR/ca.cnf" <<EOF
[req]
distinguished_name = req_dn
x509_extensions = v3_ca
prompt = no

[req_dn]
CN = Test CA

[v3_ca]
basicConstraints = critical, CA:TRUE
keyUsage = critical, keyCertSign, cRLSign
subjectKeyIdentifier = hash
EOF

openssl genrsa -out "$DIR/ca.key" 2048
openssl req -x509 -new -nodes -key "$DIR/ca.key" -sha256 -days 365 \
  -out "$DIR/ca.crt" -config "$DIR/ca.cnf"

# Server cert
openssl genrsa -out "$DIR/server.key" 2048
openssl req -new -key "$DIR/server.key" -out "$DIR/server.csr" \
  -subj "/CN=valkey-tls"

cat > "$DIR/server.ext" <<EOF
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage=digitalSignature,keyEncipherment
extendedKeyUsage=serverAuth
subjectAltName=DNS:valkey-tls,DNS:localhost,IP:127.0.0.1
EOF

openssl x509 -req -in "$DIR/server.csr" -CA "$DIR/ca.crt" -CAkey "$DIR/ca.key" \
  -CAcreateserial -out "$DIR/server.crt" -days 365 -sha256 -extfile "$DIR/server.ext"

rm -f "$DIR/server.csr" "$DIR/server.ext" "$DIR/ca.cnf" "$DIR/ca.srl"
chmod 644 "$DIR/server.key"

echo "Certs generated in $DIR"
