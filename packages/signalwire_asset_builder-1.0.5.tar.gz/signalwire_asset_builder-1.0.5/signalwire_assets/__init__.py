"""
SignalWire Asset Builder — pip install signalwire-asset-builder

Subpackages:
    signalwire_assets.slides   — branded slide deck builder (30 layouts)
    signalwire_assets.landing  — branded landing page builder (17 section types)

CLI:
    signalwire-assets slides list|show|build|docs
    signalwire-assets landing build|batch
"""

__version__ = "1.0.4"
