from pydantic import BaseModel, ConfigDict
import datetime
import mcp.types as mt
from typing import Any, Optional


class LocalCapabilities(BaseModel):
    tools: dict[str, mt.Tool]
    resources: dict[str, mt.Resource]
    prompts: dict[str, mt.Prompt]
    synced_at: datetime.datetime


class PreRequest(BaseModel):
    method: str
    params: dict[str, Any] | None


class PostRequest(PreRequest):
    result: Optional[
        list[mt.ContentBlock]
        | tuple[list[mt.ContentBlock], dict[str, Any]]
        | list[mt.Tool]
        | list[mt.Resource]
        | mt.CallToolResult
        | None
    ]
    correlation_id: str
    inject_synthetic_tool_on_policy_block: bool | None = False


class ServerDetails(BaseModel):
    """Simplified server details model."""

    id: str
    name: str
    url: str
    transport_type: str
    transport_config: dict[str, Any] | None = None
    sync_required: bool = False

    model_config = ConfigDict(extra="ignore")
