from pathlib import Path

import anyio
import structlog
import typer

from runlayer_cli.api import RunlayerClient
from runlayer_cli.console import print_error
from runlayer_cli.config import resolve_credentials, set_credentials_in_context
from runlayer_cli.logging import setup_logging
from runlayer_cli.skills.installer import (
    SKILLS_DIR_MAP,
    InstallResult,
    UpdateResult,
    read_lockfile,
    install_skills,
    resolve_dirs,
    uninstall_skill,
    update_skills,
)
from runlayer_cli.skills.sync_engine import SyncResult, sync_skills

logger = structlog.get_logger(__name__)

app = typer.Typer(help="Manage skills")


def _resolve_client(client_name: str | None) -> str:
    if client_name:
        if client_name not in SKILLS_DIR_MAP:
            typer.secho(
                f"Unsupported client: {client_name}. "
                f"Supported: {', '.join(SKILLS_DIR_MAP)}",
                fg=typer.colors.RED,
                err=True,
            )
            raise typer.Exit(1)
        return client_name
    return "claude_code"


@app.command()
def push(
    ctx: typer.Context,
    path: str = typer.Argument(".", help="Root directory"),
    namespace: str = typer.Option(
        ..., "--namespace", "-N", help="Namespace for matching skills on the server"
    ),
    secret: str | None = typer.Option(
        None, "--secret", "-s", envvar="RUNLAYER_API_KEY"
    ),
    host: str | None = typer.Option(None, "--host", "-H", envvar="RUNLAYER_HOST"),
    dry_run: bool = typer.Option(False, "--dry-run", "-n"),
    prune: bool = typer.Option(
        False, "--prune", help="Remove skills from API whose directories were removed"
    ),
) -> None:
    """Push skills to Runlayer API."""
    root = Path(path).resolve()

    log_file_path = setup_logging(command="skills-push", quiet_console=False)

    set_credentials_in_context(ctx, secret, host)
    credentials = resolve_credentials(ctx, require_auth=True)

    try:
        client = RunlayerClient(
            hostname=credentials["host"], secret=credentials["secret"]
        )

        def on_progress(skill_path: str, status: str) -> None:
            typer.echo(f"  {skill_path}: {status}")

        async def _run() -> SyncResult:
            return await sync_skills(
                root,
                client,
                namespace=namespace,
                dry_run=dry_run,
                prune=prune,
                on_progress=on_progress,
            )

        result = anyio.run(_run)

        if dry_run:
            typer.secho("[dry run] ", fg=typer.colors.YELLOW, nl=False)

        typer.echo(
            f"Sync complete: {result.created} created, "
            f"{result.updated} updated, {result.unchanged} unchanged, "
            f"{result.deleted} deleted"
        )
        if result.errors:
            for err in result.errors:
                typer.secho(f"  Error: {err}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        logger.error("push_failed", error=str(e), exc_info=True)
        print_error(str(e), str(log_file_path))
        raise typer.Exit(1)


@app.command(name="list")
def list_skills(
    client_name: str | None = typer.Option(
        None, "--client", "-c", help="Target editor client"
    ),
    global_install: bool = typer.Option(
        False, "--global", "-g", help="List global skills"
    ),
) -> None:
    """List installed skills."""
    log_file_path = setup_logging(command="skills-list", quiet_console=False)
    resolved_client = _resolve_client(client_name)
    _, _, lockfile = resolve_dirs(resolved_client, global_install, Path.cwd())
    try:
        entries = [e for e in read_lockfile(lockfile) if e.client == resolved_client]

        if not entries:
            typer.echo("No skills installed.")
            raise typer.Exit(0)

        for e in entries:
            line = f"  {e.name}"
            if e.namespace:
                line += f"  ({e.namespace})"
            typer.echo(line)

        typer.echo(f"\n{len(entries)} skill(s) installed")
    except typer.Exit:
        raise
    except Exception as e:
        logger.error("list_failed", error=str(e), exc_info=True)
        print_error(str(e), str(log_file_path))
        raise typer.Exit(1)


@app.command()
def add(
    ctx: typer.Context,
    source: str | None = typer.Argument(
        None, help="Skill UUID or namespace (e.g. Org/Repo)"
    ),
    install_all: bool = typer.Option(
        False, "--all", help="Install all accessible skills across namespaces"
    ),
    skill: str | None = typer.Option(
        None, "--skill", help="Filter by skill name within namespace"
    ),
    client_name: str | None = typer.Option(
        None, "--client", "-c", help="Target editor client"
    ),
    global_install: bool = typer.Option(
        False, "--global", "-g", help="Install globally"
    ),
    dry_run: bool = typer.Option(False, "--dry-run", "-n"),
    secret: str | None = typer.Option(
        None, "--secret", "-s", envvar="RUNLAYER_API_KEY"
    ),
    host: str | None = typer.Option(None, "--host", "-H", envvar="RUNLAYER_HOST"),
) -> None:
    """Add skills from Runlayer API."""
    if install_all and source is not None:
        typer.secho(
            "Pass either SOURCE or --all, not both.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1)
    if not install_all and source is None:
        typer.secho(
            "Missing argument 'SOURCE'. Use SOURCE or --all.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1)

    log_file_path = setup_logging(command="skills-add", quiet_console=False)

    set_credentials_in_context(ctx, secret, host)
    credentials = resolve_credentials(ctx, require_auth=not dry_run)

    resolved_client = _resolve_client(client_name)
    canonical, editor, lockfile = resolve_dirs(
        resolved_client, global_install, Path.cwd()
    )

    try:
        api = RunlayerClient(hostname=credentials["host"], secret=credentials["secret"])

        def on_progress(name: str, status: str) -> None:
            typer.echo(f"  {name}: {status}")

        async def _run() -> InstallResult:
            return await install_skills(
                client=api,
                source=source,
                install_all=install_all,
                skill_name=skill,
                canonical_dir=canonical,
                editor_dir=editor,
                lockfile_path=lockfile,
                client_name=resolved_client,
                dry_run=dry_run,
                on_progress=on_progress,
            )

        result = anyio.run(_run)

        if dry_run:
            typer.secho("[dry run] ", fg=typer.colors.YELLOW, nl=False)

        parts = []
        if result.installed:
            parts.append(f"{len(result.installed)} installed")
        if result.skipped:
            parts.append(f"{len(result.skipped)} skipped")
        typer.echo(f"Done: {', '.join(parts) if parts else 'nothing to do'}")

        if result.errors:
            for err in result.errors:
                typer.secho(f"  Error: {err}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        logger.error("add_failed", error=str(e), exc_info=True)
        print_error(str(e), str(log_file_path))
        raise typer.Exit(1)


@app.command()
def remove(
    name: str | None = typer.Argument(None, help="Skill name to remove"),
    remove_all: bool = typer.Option(False, "--all", help="Remove all installed skills"),
    yes: bool = typer.Option(False, "--yes", help="Skip confirmation prompt"),
    client_name: str | None = typer.Option(
        None, "--client", "-c", help="Target editor client"
    ),
    global_install: bool = typer.Option(
        False, "--global", "-g", help="Uninstall from global skills"
    ),
) -> None:
    """Remove an installed skill."""
    log_file_path = setup_logging(command="skills-remove", quiet_console=False)
    if remove_all and name is not None:
        typer.secho(
            "Pass either SKILL_NAME or --all, not both.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1)
    if not remove_all and name is None:
        typer.secho(
            "Missing argument 'SKILL_NAME'. Use SKILL_NAME or --all.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1)

    try:
        resolved_client = _resolve_client(client_name)
        canonical, editor, lockfile = resolve_dirs(
            resolved_client, global_install, Path.cwd()
        )

        if remove_all:
            entries = [
                e for e in read_lockfile(lockfile) if e.client == resolved_client
            ]
            if not entries:
                typer.echo("No skills installed.")
                raise typer.Exit(0)

            names = list(dict.fromkeys(e.name for e in entries))
            if not yes:
                scope = "global" if global_install else "project"
                confirmed = typer.confirm(
                    f"Remove {len(names)} skill(s) from {scope} install?", default=False
                )
                if not confirmed:
                    typer.echo("Aborted.")
                    raise typer.Exit(0)

            async def _run_all() -> list[str]:
                errors: list[str] = []
                for target_name in names:
                    try:
                        await uninstall_skill(
                            target_name,
                            canonical,
                            editor,
                            lockfile,
                            resolved_client,
                        )
                    except Exception as e:
                        errors.append(f"{target_name}: {e}")
                return errors

            errors = anyio.run(_run_all)
            removed_count = len(names) - len(errors)
            typer.echo(f"Done: {removed_count} removed")
            if errors:
                for err in errors:
                    typer.secho(f"  Error: {err}", fg=typer.colors.RED, err=True)
                raise typer.Exit(1)
            return

        assert name is not None

        async def _run() -> None:
            await uninstall_skill(name, canonical, editor, lockfile, resolved_client)

        anyio.run(_run)
        typer.echo(f"Removed: {name}")

    except typer.Exit:
        raise
    except ValueError as e:
        if remove_all:
            logger.error("remove_failed", error=str(e), exc_info=True)
            print_error(str(e), str(log_file_path))
            raise typer.Exit(1)
        typer.secho(str(e), fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    except Exception as e:
        logger.error("remove_failed", error=str(e), exc_info=True)
        print_error(str(e), str(log_file_path))
        raise typer.Exit(1)


@app.command()
def update(
    ctx: typer.Context,
    skill: str | None = typer.Option(
        None, "--skill", help="Update specific skill only"
    ),
    client_name: str | None = typer.Option(
        None, "--client", "-c", help="Target editor client"
    ),
    global_install: bool = typer.Option(
        False, "--global", "-g", help="Update global skills"
    ),
    dry_run: bool = typer.Option(False, "--dry-run", "-n"),
    secret: str | None = typer.Option(
        None, "--secret", "-s", envvar="RUNLAYER_API_KEY"
    ),
    host: str | None = typer.Option(None, "--host", "-H", envvar="RUNLAYER_HOST"),
) -> None:
    """Update installed skills from Runlayer API."""
    log_file_path = setup_logging(command="skills-update", quiet_console=False)

    set_credentials_in_context(ctx, secret, host)
    credentials = resolve_credentials(ctx, require_auth=not dry_run)

    resolved_client = _resolve_client(client_name)
    canonical, editor, lockfile = resolve_dirs(
        resolved_client, global_install, Path.cwd()
    )

    try:
        api = RunlayerClient(hostname=credentials["host"], secret=credentials["secret"])

        def on_progress(name: str, status: str) -> None:
            typer.echo(f"  {name}: {status}")

        async def _run() -> UpdateResult:
            return await update_skills(
                client=api,
                skill_name=skill,
                canonical_dir=canonical,
                editor_dir=editor,
                lockfile_path=lockfile,
                client_name=resolved_client,
                dry_run=dry_run,
                on_progress=on_progress,
            )

        result = anyio.run(_run)

        if dry_run:
            typer.secho("[dry run] ", fg=typer.colors.YELLOW, nl=False)

        parts = []
        if result.updated:
            parts.append(f"{len(result.updated)} updated")
        if result.up_to_date:
            parts.append(f"{len(result.up_to_date)} up to date")
        if result.removed:
            parts.append(f"{len(result.removed)} removed")
        typer.echo(f"Done: {', '.join(parts) if parts else 'nothing to do'}")

        if result.errors:
            for err in result.errors:
                typer.secho(f"  Error: {err}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        logger.error("update_failed", error=str(e), exc_info=True)
        print_error(str(e), str(log_file_path))
        raise typer.Exit(1)
