# Skill Identifier Library (CLI)

Self-contained Merkle-tree skill fingerprinting for the Runlayer CLI.

## How It Works

Each skill is composed of one or more files. The identifier is the root of a binary Merkle tree built from those files:

1. **Leaf hashes**: Each file produces `sha256(normalize(name) ||| normalize(content))`
2. **Sort**: Leaves are sorted by normalized filename for deterministic ordering
3. **Tree**: A binary Merkle tree is built (odd leaves duplicate the last node)
4. **Root**: The tree root is the skill's identifier

## Quick Start

```python
from runlayer_cli.skill_identifier import compute_skill_identifier, SkillFileInput

result = compute_skill_identifier([
    SkillFileInput(name="SKILL.md", content="# My Skill\n..."),
    SkillFileInput(name="helper.py", content="def run(): ..."),
])

print(result.root)         # 64-char hex SHA256 — the skill identifier
print(result.file_hashes)  # {"SKILL.md": "abc...", "helper.py": "def..."}
```

## Testing

```bash
cd cli
uv run pytest tests/skill_identifier/ -v
```

## Sync Warning

This algorithm is duplicated from `backend/app/domains/skill_identifier/`. Any changes to hashing, normalization, or tree construction must be mirrored there.
