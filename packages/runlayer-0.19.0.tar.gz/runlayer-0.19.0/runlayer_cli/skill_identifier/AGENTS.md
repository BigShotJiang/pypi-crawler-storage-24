# Skill Identifier (CLI)

> **Location**: `cli/runlayer_cli/skill_identifier/`
> **Role**: Content-addressable Merkle-tree identifiers for skills (CLI-side)

**SYNC WARNING**: This algorithm is duplicated from `backend/app/domains/skill_identifier/`. Any changes here must be mirrored there.

## Public Entry Points

```python
from runlayer_cli.skill_identifier import (
    compute_skill_identifier,
    build_merkle_tree,
    SkillFileInput,
    SkillIdentifier,
    MerkleTree,
)
```

## Files

| File | Responsibility |
|------|---------------|
| `__init__.py` | Package public export surface |
| `skill_id.py` | Skill identifier computation |
| `merkle.py` | Binary Merkle tree construction |
| `hashing.py` | SHA256 + normalization (self-contained) |
| `types.py` | Dataclass input/output models |

## Tests

```bash
cd cli
uv run pytest tests/skill_identifier/ -v
```
