import shutil
from pathlib import Path
from unittest.mock import patch

from runlayer_cli.plugins.discovery import ROOT_SKILL_SUFFIX, discover_plugins


FIXTURE_ROOT = (
    Path(__file__).parent / "e2e" / "fixtures" / "full_plugin"
)


def _copy_fixture(tmp_path: Path) -> Path:
    plugin_root = tmp_path / "review-suite"
    shutil.copytree(FIXTURE_ROOT, plugin_root)
    mcp_path = plugin_root / ".mcp.json"
    mcp_path.write_text(
        mcp_path.read_text().replace(
            "__SERVER_ID__", "12345678-1234-1234-1234-123456789abc"
        )
    )
    return plugin_root


def test_discover_plugins_full_fixture(tmp_path: Path) -> None:
    _copy_fixture(tmp_path)

    plugins = discover_plugins(tmp_path)

    assert len(plugins) == 1
    plugin = plugins[0]
    assert plugin.path == "review-suite"
    assert plugin.name == "review-suite"
    assert plugin.description is not None
    assert plugin.version == "1.0.0"

    assert [(c.entry_name, c.server_id) for c in plugin.server_connectors] == [
        ("valid-runlayer", "12345678-1234-1234-1234-123456789abc"),
        ("missing-runlayer", "00000000-0000-0000-0000-000000000000"),
    ]

    assert [skill.path for skill in plugin.skills] == [
        "review-suite/code-review",
        "review-suite/ticket-triage",
        f"review-suite/{ROOT_SKILL_SUFFIX}",
    ]

    root_skill = next(
        skill for skill in plugin.skills if skill.path.endswith(f"/{ROOT_SKILL_SUFFIX}")
    )
    titles = {f.title for f in root_skill.files}
    assert {
        "agents/code-reviewer.md",
        "agents/README.md",
        "commands/review.md",
        "hooks/hooks.json",
        "hooks/validate.sh",
        "skillsets/reference.md",
        "skills-v2/notes.md",
        "scripts/deploy.sh",
        "notes.txt",
        "tool.ts",
        "config.json",
    } <= titles
    assert "README.md" not in titles
    assert ".lsp.json" not in titles
    assert "settings.json" not in titles
    assert ".claude-plugin/plugin.json" not in titles
    assert "skills/code-review/prompts.md" not in titles


def test_discover_plugins_truncates_long_description_and_warns(
    tmp_path: Path,
) -> None:
    plugin_root = tmp_path / "long-desc"
    manifest_dir = plugin_root / ".claude-plugin"
    manifest_dir.mkdir(parents=True)
    long_description = "x" * 300
    (manifest_dir / "plugin.json").write_text(
        f'{{"name":"long-desc","version":"1.0.0","description":"{long_description}"}}'
    )

    with patch("runlayer_cli.plugins.discovery.logger.warning") as warning_mock:
        plugins = discover_plugins(tmp_path)

    assert len(plugins) == 1
    assert plugins[0].description == long_description[:255]
    assert plugins[0].manifest_warnings == [
        "long-desc: truncated plugin description to 255 characters"
    ]
    warning_mock.assert_not_called()


def test_discover_plugins_warns_for_non_runlayer_mcp_url(tmp_path: Path) -> None:
    plugin_root = _copy_fixture(tmp_path)
    (plugin_root / ".mcp.json").write_text(
        """
{
  "mcpServers": {
    "external-http": {
      "type": "http",
      "url": "https://example.com/mcp"
    },
    "local-stdio": {
      "command": "npx",
      "args": ["some-local-server"]
    }
  }
}
""".strip()
    )

    plugins = discover_plugins(tmp_path)

    assert len(plugins) == 1
    assert plugins[0].server_connectors == []
    assert plugins[0].mcp_warnings == [
        "review-suite: skipped MCP server external-http with non-Runlayer URL https://example.com/mcp"
    ]


def test_discover_plugins_accepts_uppercase_runlayer_proxy_uuid(tmp_path: Path) -> None:
    plugin_root = _copy_fixture(tmp_path)
    (plugin_root / ".mcp.json").write_text(
        """
{
  "mcpServers": {
    "uppercase-runlayer": {
      "url": "https://app.runlayer.com/api/v1/proxy/12345678-1234-1234-1234-123456789ABC/mcp"
    },
    "uppercase-plugin-proxy": {
      "url": "https://app.runlayer.com/api/v1/proxy/plugins/AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA/mcp"
    }
  }
}
""".strip()
    )

    plugins = discover_plugins(tmp_path)

    assert len(plugins) == 1
    assert [(c.entry_name, c.server_id) for c in plugins[0].server_connectors] == [
        ("uppercase-runlayer", "12345678-1234-1234-1234-123456789abc"),
    ]
    assert plugins[0].mcp_warnings == []
