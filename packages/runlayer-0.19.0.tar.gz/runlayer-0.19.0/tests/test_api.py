"""Tests for RunlayerClient API methods."""

from unittest.mock import MagicMock, patch, call

import httpx

from runlayer_cli.api import RunlayerClient


def _mock_response(status_code: int, json_data: dict | None = None) -> MagicMock:
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    if json_data is not None:
        resp.json.return_value = json_data
    resp.raise_for_status = MagicMock()
    return resp


class TestSubmitMcpWatchScan:
    def _make_client(self) -> RunlayerClient:
        return RunlayerClient(hostname="https://example.com", secret="test-key")

    def test_returns_json_on_success(self):
        expected = {
            "servers_processed": 5,
            "shadow_servers_found": 2,
            "managed_servers_matched": 1,
        }
        mock_post = MagicMock(return_value=_mock_response(200, expected))

        with patch("httpx.Client") as mock_httpx:
            mock_httpx.return_value.__enter__ = MagicMock(
                return_value=MagicMock(post=mock_post)
            )
            mock_httpx.return_value.__exit__ = MagicMock(return_value=False)

            result = self._make_client().submit_mcp_watch_scan({"device_id": "test"})
            assert result == expected
            mock_post.assert_called_once()

    def test_falls_back_to_mcp_watch_on_404(self):
        expected = {
            "servers_processed": 3,
            "shadow_servers_found": 1,
            "managed_servers_matched": 0,
        }
        mock_post = MagicMock(
            side_effect=[_mock_response(404), _mock_response(200, expected)]
        )

        with patch("httpx.Client") as mock_httpx:
            mock_httpx.return_value.__enter__ = MagicMock(
                return_value=MagicMock(post=mock_post)
            )
            mock_httpx.return_value.__exit__ = MagicMock(return_value=False)

            result = self._make_client().submit_mcp_watch_scan({"device_id": "test"})
            assert result == expected
            assert mock_post.call_count == 2
            assert "/ai-watch/scan" in mock_post.call_args_list[0][0][0]
            assert "/mcp-watch/scan" in mock_post.call_args_list[1][0][0]

    def test_returns_unsupported_when_both_paths_404(self):
        mock_post = MagicMock(side_effect=[_mock_response(404), _mock_response(404)])

        with patch("httpx.Client") as mock_httpx:
            mock_httpx.return_value.__enter__ = MagicMock(
                return_value=MagicMock(post=mock_post)
            )
            mock_httpx.return_value.__exit__ = MagicMock(return_value=False)

            result = self._make_client().submit_mcp_watch_scan({"device_id": "test"})
            assert result == {"unsupported": True}
            assert mock_post.call_count == 2
