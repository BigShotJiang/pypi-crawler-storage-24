import shutil
from pathlib import Path

from tests.e2e.conftest import strip_ansi

from runlayer_cli.main import app


def _create_skill_dir(root: Path, name: str) -> None:
    """Create a minimal skill directory with SKILL.md."""
    skill_dir = root / name
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        f"---\nname: {name}\ndescription: E2E test skill\n---\n\n# {name}\n\nTest skill.\n"
    )


def test_skills_push_lifecycle(runner, cli_args, tmp_path, unique_id):
    """runlayer skills push → push (idempotent) → push --prune"""
    skills_root = tmp_path / "skills-source"
    skills_root.mkdir()
    skill_name = f"test-skill-{unique_id}"
    _create_skill_dir(skills_root, skill_name)

    namespace = f"e2e-test/{unique_id}"

    result = runner.invoke(
        app,
        [*cli_args, "skills", "push", str(skills_root), "--namespace", namespace],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"push failed: {output}"
    assert "1 created" in output

    result = runner.invoke(
        app,
        [*cli_args, "skills", "push", str(skills_root), "--namespace", namespace],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"push 2 failed: {output}"
    assert "1 unchanged" in output or "0 created" in output

    shutil.rmtree(skills_root / skill_name)
    result = runner.invoke(
        app,
        [
            *cli_args,
            "skills",
            "push",
            str(skills_root),
            "--namespace",
            namespace,
            "--prune",
        ],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"prune failed: {output}"
    assert "1 deleted" in output


def test_skills_add_list_remove(runner, cli_args, tmp_path, unique_id, monkeypatch):
    """runlayer skills add → list → remove"""
    skills_root = tmp_path / "skills-source"
    skills_root.mkdir()
    skill_name = f"test-skill-{unique_id}"
    _create_skill_dir(skills_root, skill_name)

    namespace = f"e2e-test/{unique_id}"

    result = runner.invoke(
        app,
        [*cli_args, "skills", "push", str(skills_root), "--namespace", namespace],
    )
    assert result.exit_code == 0, f"push failed: {strip_ansi(result.output)}"

    project_dir = tmp_path / "project"
    project_dir.mkdir()
    monkeypatch.chdir(project_dir)

    result = runner.invoke(
        app,
        [*cli_args, "skills", "add", namespace, "--client", "claude_code"],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"add failed: {output}"
    assert "1 installed" in output

    result = runner.invoke(app, ["skills", "list", "--client", "claude_code"])
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"list failed: {output}"
    assert skill_name in output

    result = runner.invoke(
        app, ["skills", "remove", skill_name, "--client", "claude_code"]
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"remove failed: {output}"
    assert "Removed" in output

    shutil.rmtree(skills_root / skill_name)
    runner.invoke(
        app,
        [
            *cli_args,
            "skills",
            "push",
            str(skills_root),
            "--namespace",
            namespace,
            "--prune",
        ],
    )


def test_skills_add_list_remove_vscode(
    runner, cli_args, tmp_path, unique_id, monkeypatch
):
    """runlayer skills add/list/remove works for VS Code native skills."""
    skills_root = tmp_path / "skills-source"
    skills_root.mkdir()
    skill_name = f"test-skill-{unique_id}"
    _create_skill_dir(skills_root, skill_name)

    namespace = f"e2e-test/{unique_id}"

    result = runner.invoke(
        app,
        [*cli_args, "skills", "push", str(skills_root), "--namespace", namespace],
    )
    assert result.exit_code == 0, f"push failed: {strip_ansi(result.output)}"

    project_dir = tmp_path / "project"
    project_dir.mkdir()
    monkeypatch.chdir(project_dir)

    result = runner.invoke(
        app,
        [*cli_args, "skills", "add", namespace, "--client", "vscode"],
    )
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"add failed: {output}"
    assert "1 installed" in output

    installed_skill = project_dir / ".agents" / "skills" / skill_name
    assert installed_skill.exists()
    assert not installed_skill.is_symlink()
    assert (installed_skill / "SKILL.md").exists()
    assert not (project_dir / ".vscode" / "skills" / skill_name).exists()

    lockfile = project_dir / ".runlayer" / "skill-lock.yml"
    assert lockfile.exists()
    lockfile_text = lockfile.read_text(encoding="utf-8")
    assert "client: vscode" in lockfile_text
    assert f"name: {skill_name}" in lockfile_text

    result = runner.invoke(app, ["skills", "list", "--client", "vscode"])
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"list failed: {output}"
    assert skill_name in output

    result = runner.invoke(app, ["skills", "remove", skill_name, "--client", "vscode"])
    output = strip_ansi(result.output)
    assert result.exit_code == 0, f"remove failed: {output}"
    assert "Removed" in output
    assert not installed_skill.exists()

    shutil.rmtree(skills_root / skill_name)
    runner.invoke(
        app,
        [
            *cli_args,
            "skills",
            "push",
            str(skills_root),
            "--namespace",
            namespace,
            "--prune",
        ],
    )
