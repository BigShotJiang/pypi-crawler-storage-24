---
name: ticket-triage
description: Triage inbound tickets
---
Use this skill when ticket details need structured triage.
