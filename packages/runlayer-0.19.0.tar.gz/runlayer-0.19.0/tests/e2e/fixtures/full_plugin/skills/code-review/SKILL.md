---
name: code-review
description: Review pull requests
---
Use this skill for code review tasks.
