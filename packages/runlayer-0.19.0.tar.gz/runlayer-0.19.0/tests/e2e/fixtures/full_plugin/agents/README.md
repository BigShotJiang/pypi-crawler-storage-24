Nested agent README that should be bundled into the root skill.
