Experimental notes that should still be bundled into the root skill.
