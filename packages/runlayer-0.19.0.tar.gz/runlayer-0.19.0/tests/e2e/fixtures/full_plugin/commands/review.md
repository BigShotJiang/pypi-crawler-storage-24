---
description: Review the current change set
allowed-tools: Bash(git:*), Read
---
Run a review and summarize the risks.
