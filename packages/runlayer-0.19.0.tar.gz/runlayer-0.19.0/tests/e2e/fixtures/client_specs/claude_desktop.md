# Claude Desktop MCP Client Spec

- **Config path (macOS):** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Config path (Windows):** `%APPDATA%/Claude/claude_desktop_config.json`
- **Format:** JSON
- **Servers key:** `mcpServers`
- **Project config:** None (global only)
- **Transport:** stdio only (no HTTP/SSE support)
- **Last verified:** 2026-03-17

## Editor docs

- **Skills:** No native SKILL.md support (uses Cowork skills, UI-based)
- **Plugins:** https://github.com/anthropics/dxt (DXT/MCPB desktop extensions)
- **MCP:** https://modelcontextprotocol.io/quickstart/user

## Runlayer support

### Skills: not supported
Claude Desktop does not support SKILL.md files.

### Plugins: unsupported
Cannot install plugins — stdio-only transport, cannot consume HTTP proxy URLs.

### MCP connectors (servers)
- Config: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Local only** — no remote/proxy support
- Local entry:
  ```json
  {"command": "uvx", "args": ["runlayer", "run", "<server-id>", "--host", "<host>"]}
  ```
