# Windsurf MCP Client Spec

- **Config path (macOS):** `~/.codeium/windsurf/mcp_config.json`
- **Config path (Windows):** `%USERPROFILE%/.codeium/windsurf/mcp_config.json`
- **Format:** JSON
- **Servers key:** `mcpServers`
- **Project config:** `.windsurf/mcp_config.json` (servers key: `mcpServers`)
- **Transport:** stdio, SSE, Streamable HTTP
- **Last verified:** 2026-03-17

## Editor docs

- **Skills:** https://docs.windsurf.com/windsurf/cascade/skills
- **Plugins:** No native plugin system
- **MCP:** https://docs.windsurf.com/windsurf/cascade/mcp

## Runlayer support

### Skills: not supported
Windsurf has native skills but Runlayer does not install them yet.

### Plugins: mcp_fallback
No native plugin support. Writes HTTP proxy entry to client config under `"mcpServers"`.
- Lockfile: `.runlayer/plugin-lock.yml` (`install_mode: mcp_fallback`)

### MCP connectors (servers)
- Config: `~/.codeium/windsurf/mcp_config.json` or `.windsurf/mcp_config.json`
- Local entry:
  ```json
  {"command": "uvx", "args": ["runlayer", "run", "<server-id>", "--host", "<host>"]}
  ```
- Remote entry (uses `serverUrl` not `url`):
  ```json
  {"serverUrl": "<proxy-url>"}
  ```
