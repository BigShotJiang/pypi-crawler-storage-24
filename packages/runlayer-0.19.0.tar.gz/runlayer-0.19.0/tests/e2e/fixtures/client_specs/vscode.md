# VS Code MCP Client Spec

- **Config path (macOS):** `~/Library/Application Support/Code/User/mcp.json`
- **Config path (Windows):** `%APPDATA%/Code/User/mcp.json`
- **Format:** JSON
- **Servers key:** `servers` (NOT `mcpServers`)
- **Project config:** `.vscode/mcp.json` (servers key: `servers`)
- **Transport:** stdio, HTTP
- **Last verified:** 2026-03-18

## Editor docs

- **Skills:** https://code.visualstudio.com/docs/copilot/customization/agent-skills
- **Plugins:** https://code.visualstudio.com/docs/copilot/customization/agent-plugins
- **MCP:** https://code.visualstudio.com/docs/copilot/chat/mcp-servers

## Runlayer support

### Skills: native
- Canonical: `.agents/skills/<name>/`
- Symlink: `.agents/skills/<name>` (same path, no separate editor dir)
- Lockfile: `.runlayer/skill-lock.yml`

### Plugins: native
- Manifest: `.agents/plugins/<name>/.vscode-plugin/plugin.json`
- MCP config: `.agents/plugins/<name>/.mcp.json` with `"servers"` key (NOT `"mcpServers"`)
- Skills: `.agents/plugins/<name>/skills/<skill>/`
- Symlink: `.vscode/plugins/<name>` → canonical
- Lockfile: `.runlayer/plugin-lock.yml` (`install_mode: native`)

### MCP connectors (servers)
- Config: `~/Library/Application Support/Code/User/mcp.json` or `.vscode/mcp.json`
- Local entry:
  ```json
  {"type": "stdio", "command": "uvx", "args": ["runlayer", "run", "<server-id>", "--host", "<host>"]}
  ```
- Remote entry:
  ```json
  {"type": "http", "url": "<proxy-url>"}
  ```
