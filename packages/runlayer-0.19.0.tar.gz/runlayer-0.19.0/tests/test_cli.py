"""Basic tests for the CLI."""

import re
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import typer
from typer.testing import CliRunner
import yaml

from runlayer_cli.config import Config
from runlayer_cli.main import app

runner = CliRunner()


def strip_ansi(text: str) -> str:
    """Strip ANSI escape codes from text."""
    ansi_escape = re.compile(r"\x1b\[[0-9;]*m")
    return ansi_escape.sub("", text)


def test_help_command():
    """Test that the help command shows usage information."""
    # Test top-level help
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    plain_output = strip_ansi(result.stdout)
    assert "Run MCP servers via HTTP transport" in plain_output
    assert "--version" in plain_output
    assert "--secret" in plain_output
    assert "--host" in plain_output

    # Test run command help
    result = runner.invoke(app, ["run", "--help"])
    assert result.exit_code == 0
    plain_output = strip_ansi(result.stdout)
    assert "Run an MCP server via HTTP transport" in plain_output
    assert "SERVER_UUID" in plain_output
    assert "--secret" in plain_output
    assert "--host" in plain_output


def test_version_command():
    """Test that the version command shows version information."""
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    plain_output = strip_ansi(result.stdout)
    assert "runlayer version" in plain_output

    # Test short version flag
    result = runner.invoke(app, ["-v"])
    assert result.exit_code == 0
    plain_output = strip_ansi(result.stdout)
    assert "runlayer version" in plain_output


def test_run_command_requires_arguments():
    """Test that run command requires server UUID and secret."""
    result = runner.invoke(app, ["run"])
    assert result.exit_code != 0
    # Should fail because required arguments are missing


def test_default_command_behavior():
    """Test that run command without secret triggers login or fails."""
    with patch("runlayer_cli.commands.auth.login") as mock_login:
        with patch("runlayer_cli.config.load_config") as mock_load:
            mock_config = type("Config", (), {"secret": None, "host": None})()
            mock_load.return_value = mock_config
            result = runner.invoke(app, ["run", "test-uuid"])
            assert result.exit_code != 0


def test_run_starts_login_when_host_has_no_stored_credentials(tmp_path: Path):
    """Run should start login when --secret is omitted for an unknown host."""
    existing_config = Config(
        default_host="https://saved.runlayer.com",
        hosts={
            "saved.runlayer.com": {
                "url": "https://saved.runlayer.com",
                "secret": "rl_saved_secret",
            }
        },
    )
    post_login_config = Config(
        default_host="https://target.runlayer.com",
        hosts={
            "saved.runlayer.com": {
                "url": "https://saved.runlayer.com",
                "secret": "rl_saved_secret",
            },
            "target.runlayer.com": {
                "url": "https://target.runlayer.com",
                "secret": "rl_target_secret",
            },
        },
    )
    server_details = SimpleNamespace(
        name="Test Server",
        transport_type="stdio",
        url="echo",
        transport_config={},
        sync_required=False,
    )

    with (
        patch(
            "runlayer_cli.config.load_config",
            side_effect=[existing_config, post_login_config],
        ),
        patch("runlayer_cli.commands.auth.login") as login_mock,
        patch("runlayer_cli.main.setup_logging", return_value=tmp_path / "run.log"),
        patch("runlayer_cli.main.RunlayerClient") as client_class,
        patch("runlayer_cli.main.StdioTransport"),
        patch("runlayer_cli.main.ProxyClient"),
        patch("runlayer_cli.main.FastMCPProxy") as proxy_class,
        patch("runlayer_cli.main.anyio.run"),
    ):
        client_class.return_value.get_server_details.return_value = server_details

        result = runner.invoke(
            app,
            ["run", "test-uuid", "--host", "https://target.runlayer.com"],
        )

    assert result.exit_code == 0
    login_mock.assert_called_once_with(host="https://target.runlayer.com")
    client_class.assert_called_once_with(
        hostname="https://target.runlayer.com",
        secret="rl_target_secret",
    )
    proxy_class.return_value.add_middleware.assert_called_once()


def test_run_uses_stored_credentials_without_login(tmp_path: Path):
    """Run should use host-matching config creds when --secret is omitted."""
    config = Config(
        default_host="https://target.runlayer.com",
        hosts={
            "target.runlayer.com": {
                "url": "https://target.runlayer.com",
                "secret": "rl_target_secret",
            }
        },
    )
    server_details = SimpleNamespace(
        name="Test Server",
        transport_type="stdio",
        url="echo",
        transport_config={},
        sync_required=False,
    )

    with (
        patch("runlayer_cli.config.load_config", return_value=config),
        patch("runlayer_cli.commands.auth.login") as login_mock,
        patch("runlayer_cli.main.setup_logging", return_value=tmp_path / "run.log"),
        patch("runlayer_cli.main.RunlayerClient") as client_class,
        patch("runlayer_cli.main.StdioTransport"),
        patch("runlayer_cli.main.ProxyClient"),
        patch("runlayer_cli.main.FastMCPProxy") as proxy_class,
        patch("runlayer_cli.main.anyio.run"),
    ):
        client_class.return_value.get_server_details.return_value = server_details

        result = runner.invoke(
            app,
            ["run", "test-uuid", "--host", "https://target.runlayer.com"],
        )

    assert result.exit_code == 0
    login_mock.assert_not_called()
    client_class.assert_called_once_with(
        hostname="https://target.runlayer.com",
        secret="rl_target_secret",
    )
    proxy_class.return_value.add_middleware.assert_called_once()


def test_run_skips_login_when_secret_is_passed(tmp_path: Path):
    """Run should never start login when --secret is provided explicitly."""
    server_details = SimpleNamespace(
        name="Test Server",
        transport_type="stdio",
        url="echo",
        transport_config={},
        sync_required=False,
    )

    with (
        patch("runlayer_cli.config.load_config", return_value=Config()),
        patch("runlayer_cli.commands.auth.login") as login_mock,
        patch("runlayer_cli.main.setup_logging", return_value=tmp_path / "run.log"),
        patch("runlayer_cli.main.RunlayerClient") as client_class,
        patch("runlayer_cli.main.StdioTransport"),
        patch("runlayer_cli.main.ProxyClient"),
        patch("runlayer_cli.main.FastMCPProxy") as proxy_class,
        patch("runlayer_cli.main.anyio.run"),
    ):
        client_class.return_value.get_server_details.return_value = server_details

        result = runner.invoke(
            app,
            [
                "run",
                "test-uuid",
                "--host",
                "https://target.runlayer.com",
                "--secret",
                "rl_direct_secret",
            ],
        )

    assert result.exit_code == 0
    login_mock.assert_not_called()
    client_class.assert_called_once_with(
        hostname="https://target.runlayer.com",
        secret="rl_direct_secret",
    )
    proxy_class.return_value.add_middleware.assert_called_once()


def test_run_command_with_secret_requires_host():
    """Test that run command with server UUID and secret still requires host."""
    result = runner.invoke(app, ["run", "test-uuid", "--secret", "test-secret"])
    assert result.exit_code != 0
    # Should fail because --host is missing (or connection fails)


def test_validate_command_requires_args():
    """Test that validate command requires secret and config."""
    with patch("runlayer_cli.commands.auth.login") as mock_login:
        with patch("runlayer_cli.config.load_config") as mock_load:
            mock_config = type("Config", (), {"secret": None, "host": None})()
            mock_load.return_value = mock_config
            result = runner.invoke(app, ["deploy", "validate", "--config", "test.yaml"])
            assert result.exit_code != 0

    # Missing config (should work with default)
    result = runner.invoke(app, ["deploy", "validate", "--secret", "test-secret"])
    # May fail due to missing file or connection, but should not fail due to missing args
    assert result.exit_code != 0  # Will fail on file not found or connection


def test_validate_command_success():
    """Test validate command with valid YAML."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        config = {
            "name": "test-service",
            "runtime": "docker",
            "service": {"port": 8000},
        }
        yaml.dump(config, f)
        config_path = f.name

    try:
        with patch("runlayer_cli.commands.deploy.validate_service") as mock_validate:
            runner.invoke(
                app,
                [
                    "deploy",
                    "validate",
                    "--config",
                    config_path,
                    "--secret",
                    "test-secret",
                    "--host",
                    "http://localhost:3000",
                ],
            )
            # Should call validate_service
            mock_validate.assert_called_once_with(
                config_path=config_path,
                secret="test-secret",
                host="http://localhost:3000",
                env_file=None,
            )
    finally:
        Path(config_path).unlink()


def test_validate_command_error():
    """Test validate command with invalid YAML."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write("invalid: yaml: content")
        config_path = f.name

    try:
        with patch("runlayer_cli.commands.deploy.validate_service") as mock_validate:
            mock_validate.side_effect = typer.Exit(1)

            result = runner.invoke(
                app,
                [
                    "deploy",
                    "validate",
                    "--config",
                    config_path,
                    "--secret",
                    "test-secret",
                    "--host",
                    "http://localhost:3000",
                ],
            )
            # Should have called validate_service and exited with error
            assert result.exit_code != 0
            mock_validate.assert_called_once()
    finally:
        Path(config_path).unlink()
