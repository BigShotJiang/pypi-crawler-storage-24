#!/bin/bash
# Runlayer Cursor Hook - MCP enforcement + raw event forwarding
#
# beforeMCPExecution: blocking call to /hooks/cursor + fire-and-forget to /hooks/events
# beforeReadFile: local pattern matching only
# All other events: fire-and-forget forwarding of raw payload to /hooks/events
#
# Security: beforeMCPExecution uses fail-closed behavior.

set -euo pipefail

deny_response() {
  local message="${1:-Hook failed - blocked for security}"
  echo "{\"permission\":\"deny\",\"user_message\":\"${message}\"}"
  exit 0
}

# --- Read hook input ---
input=$(cat) || deny_response "Failed to read hook input"
hook_type=$(echo "$input" | jq -r '.hook_event_name // empty') || deny_response "Failed to parse hook input"

# --- Read credentials (needed for API calls) ---
_load_credentials() {
  CONFIG_FILE="${HOME}/.runlayer/config.yaml"
  if [[ ! -f "$CONFIG_FILE" ]]; then
    return 1
  fi

  RUNLAYER_API_HOST=$(grep '^default_host:' "$CONFIG_FILE" \
    | sed 's/^default_host:[[:space:]]*//' | tr -d '[:space:]' \
    | sed "s/^['\"]//; s/['\"]$//") || return 1
  [[ -z "$RUNLAYER_API_HOST" ]] && return 1

  local local_host
  local_host=$(echo "$RUNLAYER_API_HOST" | tr '[:upper:]' '[:lower:]')
  host_key=$(echo "$local_host" | sed -E 's|^https?://||' | sed 's|/.*||')
  [[ "$local_host" == https://* ]] && host_key=$(echo "$host_key" | sed 's|:443$||')
  [[ "$local_host" == http://* ]] && host_key=$(echo "$host_key" | sed 's|:80$||')
  RUNLAYER_API_KEY=$(awk -v host="  ${host_key}:" '
    $0 == host { found=1; next }
    found && /^[[:space:]]*secret:/ { sub(/^[[:space:]]*secret:[[:space:]]*/, ""); gsub(/^[\x27"]|[\x27"]$/, ""); print; exit }
    found && /^  [^ ]/ { exit }
  ' "$CONFIG_FILE") || return 1
  [[ -z "$RUNLAYER_API_KEY" ]] && return 1
  return 0
}

# --- Read enforcement config ---
_config_file="$(dirname "$0")/runlayer-config.json"
_ENFORCEMENT=true
if [[ -f "$_config_file" ]]; then
  _val=$(jq -r '.enforcement' "$_config_file" 2>/dev/null) || true
  [[ "$_val" == "false" ]] && _ENFORCEMENT=false
fi

# Fire-and-forget: POST raw event wrapper to /hooks/events (background, best-effort)
_forward_event() {
  local event_name="$1"
  local payload="$2"
  local wrapper
  wrapper=$(jq -nc --arg c "cursor" --arg e "$event_name" --argjson p "$payload" \
    '{client: $c, event_name: $e, payload: $p}') || return 0
  curl -sf --max-time 5 -X POST "${RUNLAYER_API_HOST}/api/v1/hooks/events" \
    -H "Content-Type: application/json" \
    -H "x-runlayer-api-key: ${RUNLAYER_API_KEY}" \
    -d "$wrapper" >/dev/null 2>&1 || true
}

case "$hook_type" in
  beforeMCPExecution)
    raw_input="$input"

    if [[ "$_ENFORCEMENT" == "true" ]]; then
      _load_credentials || deny_response "Runlayer config not found. Run 'runlayer login' first."

      if echo "$input" | jq -e '.tool_input | type == "object"' > /dev/null 2>&1; then
        input=$(echo "$input" | jq '.tool_input = (.tool_input | tojson)') || deny_response "Failed to transform tool_input"
      fi

      # Blocking enforcement call
      response=$(curl -sf --max-time 30 -X POST "${RUNLAYER_API_HOST}/api/v1/hooks/cursor" \
        -H "Content-Type: application/json" \
        -H "x-runlayer-api-key: ${RUNLAYER_API_KEY}" \
        -d "$input" 2>/dev/null) || deny_response "Failed to contact Runlayer API"

      if ! echo "$response" | jq -e 'has("permission")' > /dev/null 2>&1; then
        deny_response "Invalid response from Runlayer API"
      fi

      _forward_event "$hook_type" "$raw_input" &
      echo "$response"
    else
      if _load_credentials 2>/dev/null; then
        _forward_event "$hook_type" "$raw_input" &
      fi
      echo '{"permission":"allow"}'
    fi
    ;;

  beforeReadFile)
    if [[ "$_ENFORCEMENT" == "true" ]]; then
      file_path=$(echo "$input" | jq -r '.file_path // empty') || deny_response "Failed to parse file path"
      basename=$(basename "$file_path")
      case "$basename" in
        .env|.env.*)
          deny_response "Runlayer: access to environment files is restricted"
          ;;
        mcp.json|mcp_config.json|.mcp.json)
          deny_response "Runlayer: access to MCP configuration files is restricted"
          ;;
      esac
    fi

    if _load_credentials 2>/dev/null; then
      _forward_event "$hook_type" "$input" &
    fi

    echo '{"permission":"allow"}'
    ;;

  beforeShellExecution|preToolUse|subagentStart|beforeSubmitPrompt)
    if _load_credentials 2>/dev/null; then
      _forward_event "$hook_type" "$input" &
    fi
    echo '{"permission":"allow"}'
    ;;

  *)
    # Observational hooks: forward raw event in background
    if _load_credentials 2>/dev/null; then
      _forward_event "$hook_type" "$input" &
    fi
    echo "{}"
    ;;
esac
