#!/bin/bash
# Runlayer Claude Code Hook - raw event forwarding to /hooks/events
#
# Thin forwarder: wraps raw event JSON and POSTs to the ingestion endpoint.
# On Stop events, reads the transcript file and includes raw content.
#
# All events are fire-and-forget (no enforcement).

set -euo pipefail

input=$(cat 2>/dev/null) || exit 0
hook_type="${HOOK_EVENT_NAME:-}"
[[ -z "$hook_type" ]] && hook_type=$(echo "$input" | jq -r '.hook_event_name // empty' 2>/dev/null) || true
[[ -z "$hook_type" ]] && exit 0

# --- Load credentials ---
CONFIG_FILE="${HOME}/.runlayer/config.yaml"
[[ ! -f "$CONFIG_FILE" ]] && exit 0

RUNLAYER_API_HOST=$(grep '^default_host:' "$CONFIG_FILE" \
  | sed 's/^default_host:[[:space:]]*//' | tr -d '[:space:]' \
  | sed "s/^['\"]//; s/['\"]$//") || exit 0
[[ -z "$RUNLAYER_API_HOST" ]] && exit 0

local_host=$(echo "$RUNLAYER_API_HOST" | tr '[:upper:]' '[:lower:]')
host_key=$(echo "$local_host" | sed -E 's|^https?://||' | sed 's|/.*||')
[[ "$local_host" == https://* ]] && host_key=$(echo "$host_key" | sed 's|:443$||')
[[ "$local_host" == http://* ]] && host_key=$(echo "$host_key" | sed 's|:80$||')
RUNLAYER_API_KEY=$(awk -v host="  ${host_key}:" '
  $0 == host { found=1; next }
  found && /^[[:space:]]*secret:/ { sub(/^[[:space:]]*secret:[[:space:]]*/, ""); gsub(/^[\x27"]|[\x27"]$/, ""); print; exit }
  found && /^  [^ ]/ { exit }
' "$CONFIG_FILE") || exit 0
[[ -z "$RUNLAYER_API_KEY" ]] && exit 0

# --- Build wrapper and POST (pipe to curl to avoid ARG_MAX on large transcripts) ---
_transcript_tmp=""
if [[ "$hook_type" == "Stop" ]]; then
  transcript_path=$(echo "$input" | jq -r '.transcript_path // empty' 2>/dev/null) || true
  if [[ -n "$transcript_path" ]]; then
    # Handle tilde expansion (Claude Code may return ~/... paths)
    transcript_path="${transcript_path/#\~/$HOME}"
    # Small delay to let the transcript file flush to disk (race condition workaround)
    sleep 1
    if [[ -f "$transcript_path" ]]; then
      _transcript_tmp=$(mktemp)
      tail -c 524288 "$transcript_path" > "$_transcript_tmp" 2>/dev/null || true
    fi
  fi
fi

if [[ -n "$_transcript_tmp" && -s "$_transcript_tmp" ]]; then
  jq -nc --arg c "claude_code" --arg e "$hook_type" --argjson p "$input" \
    --rawfile t "$_transcript_tmp" \
    '{client: $c, event_name: $e, payload: $p, transcript: $t}' \
  | curl -sf --max-time 10 -X POST "${RUNLAYER_API_HOST}/api/v1/hooks/events" \
      -H "Content-Type: application/json" \
      -H "x-runlayer-api-key: ${RUNLAYER_API_KEY}" \
      -d @- >/dev/null 2>&1 || true
  rm -f "$_transcript_tmp"
else
  [[ -n "$_transcript_tmp" ]] && rm -f "$_transcript_tmp"
  jq -nc --arg c "claude_code" --arg e "$hook_type" --argjson p "$input" \
    '{client: $c, event_name: $e, payload: $p}' \
  | curl -sf --max-time 10 -X POST "${RUNLAYER_API_HOST}/api/v1/hooks/events" \
      -H "Content-Type: application/json" \
      -H "x-runlayer-api-key: ${RUNLAYER_API_KEY}" \
      -d @- >/dev/null 2>&1 || true
fi
