"""
crawl4ai-client — Lightweight async client for Crawl4AI Docker server.

No browser or heavy dependencies required. Just httpx + pydantic.

Usage:
    from crawl4ai_client import Crawl4aiDockerClient

    async with Crawl4aiDockerClient(base_url="http://localhost:11235") as client:
        result = await client.crawl(["https://example.com"])
        print(result.markdown)
"""

from .client import (
    Crawl4aiDockerClient,
    Crawl4aiClientError,
    ConnectionError,
    RequestError,
)
from .models import CrawlResult, MarkdownResult
from .config import (
    BrowserConfig,
    CrawlerRunConfig,
    CacheMode,
    # Deep crawl
    BFSDeepCrawlStrategy,
    DFSDeepCrawlStrategy,
    BestFirstCrawlingStrategy,
    # Extraction
    JsonCssExtractionStrategy,
    LLMExtractionStrategy,
    # Content filters
    PruningContentFilter,
    BM25ContentFilter,
    # Scraping
    LXMLWebScrapingStrategy,
    PDFContentScrapingStrategy,
    # Table extraction
    DefaultTableExtraction,
    NoTableExtraction,
    # Other configs
    ProxyConfig,
    GeolocationConfig,
)

__version__ = "0.2.0"

__all__ = [
    # Client
    "Crawl4aiDockerClient",
    "Crawl4aiClientError",
    "ConnectionError",
    "RequestError",
    # Models
    "CrawlResult",
    "MarkdownResult",
    # Core config
    "BrowserConfig",
    "CrawlerRunConfig",
    "CacheMode",
    # Deep crawl strategies
    "BFSDeepCrawlStrategy",
    "DFSDeepCrawlStrategy",
    "BestFirstCrawlingStrategy",
    # Extraction strategies
    "JsonCssExtractionStrategy",
    "LLMExtractionStrategy",
    # Content filters
    "PruningContentFilter",
    "BM25ContentFilter",
    # Scraping strategies
    "LXMLWebScrapingStrategy",
    "PDFContentScrapingStrategy",
    # Table extraction
    "DefaultTableExtraction",
    "NoTableExtraction",
    # Other configs
    "ProxyConfig",
    "GeolocationConfig",
]
