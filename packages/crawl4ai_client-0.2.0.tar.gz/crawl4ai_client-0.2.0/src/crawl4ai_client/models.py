"""
Lightweight response models for crawl4ai Docker API responses.
"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel


class MarkdownResult(BaseModel):
    """Markdown generation result from a crawl."""
    raw_markdown: str = ""
    markdown_with_citations: str = ""
    references_markdown: str = ""
    fit_markdown: Optional[str] = None
    fit_html: Optional[str] = None

    def __str__(self) -> str:
        return self.raw_markdown


class CrawlResult(BaseModel):
    """Result of a single URL crawl from the Docker API."""
    url: str
    html: str = ""
    success: bool
    cleaned_html: Optional[str] = None
    fit_html: Optional[str] = None
    media: Dict[str, List[Dict]] = {}
    links: Dict[str, List[Dict]] = {}
    tables: Optional[List] = None
    downloaded_files: Optional[List[str]] = None
    screenshot: Optional[str] = None
    pdf: Optional[bytes] = None
    mhtml: Optional[str] = None
    extracted_content: Optional[str] = None
    metadata: Optional[dict] = None
    error_message: Optional[str] = None
    session_id: Optional[str] = None
    response_headers: Optional[dict] = None
    status_code: Optional[int] = None
    redirected_url: Optional[str] = None
    redirected_status_code: Optional[int] = None
    js_execution_result: Optional[Dict[str, Any]] = None
    network_requests: Optional[List[Dict[str, Any]]] = None
    console_messages: Optional[List[Dict[str, Any]]] = None
    ssl_certificate: Optional[Dict[str, Any]] = None
    dispatch_result: Optional[Dict[str, Any]] = None
    cache_status: Optional[str] = None
    cached_at: Optional[str] = None
    head_fingerprint: Optional[str] = None
    crawl_stats: Optional[Dict[str, Any]] = None
    markdown: Optional[Dict[str, Any]] = None

    model_config = {"extra": "allow"}

    @property
    def markdown_result(self) -> Optional[MarkdownResult]:
        """Parse the markdown dict into a MarkdownResult."""
        if self.markdown:
            return MarkdownResult(**self.markdown)
        return None

    @property
    def raw_markdown(self) -> str:
        """Shortcut to get raw markdown content."""
        mr = self.markdown_result
        return mr.raw_markdown if mr else ""

    @property
    def fit_markdown(self) -> Optional[str]:
        """Shortcut to get fit markdown content."""
        mr = self.markdown_result
        return mr.fit_markdown if mr else None
