import dataclasses
import xml.etree.ElementTree as ET

import gemmi

from ..contents import AsuContents
from ..job import Job
from ..reflections import DataItem, write_mtz
from ..sequence import DNA_CODES, PolymerType
from ..structure import read_structure, write_mmcif


@dataclasses.dataclass
class NautilusResult:
    structure: gemmi.Structure
    fragments_built: int
    residues_built: int
    residues_sequenced: int
    longest_fragment: int
    seconds: float

    def __init__(self, job: Job):
        job._check_files_exist("xmlout.xml", "xyzout.cif")
        xml = ET.parse(job._path("xmlout.xml")).getroot()
        structure = read_structure(job._path("xyzout.cif"))
        _deoxyfy(structure)
        self.structure = structure
        self.fragments_built = int(xml.find("Final/FragmentsBuilt").text)
        self.residues_built = int(xml.find("Final/ResiduesBuilt").text)
        self.residues_sequenced = int(xml.find("Final/ResiduesSequenced").text)
        self.longest_fragment = int(xml.find("Final/ResiduesLongestFragment").text)
        self.seconds = job._seconds


class Nautilus(Job):
    def __init__(
        self,
        contents: AsuContents,
        fsigf: DataItem,
        phases: DataItem,
        fphi: DataItem = None,
        freer: DataItem = None,
        structure: gemmi.Structure = None,
        cycles: int = 3,
    ):
        super().__init__("cnautilus")
        self.contents = contents
        self.fsigf = fsigf
        self.phases = phases
        self.fphi = fphi
        self.freer = freer
        self.structure = structure
        self.cycles = cycles

    def _setup(self) -> None:
        types = [PolymerType.RNA, PolymerType.DNA]
        self.contents.write_sequence_file(self._path("seqin.seq"), types)
        self._args += ["-seqin", "seqin.seq"]
        data_items = [self.fsigf, self.phases, self.fphi, self.freer]
        write_mtz(self._path("hklin.mtz"), data_items)
        self._args += ["-mtzin", "hklin.mtz"]
        self._args += ["-colin-fo", self.fsigf.label()]
        if self.phases.types == "AAAA":
            self._args += ["-colin-hl", self.phases.label()]
        else:
            self._args += ["-colin-phifom", self.phases.label()]
        if self.fphi is not None:
            self._args += ["-colin-fc", self.fphi.label()]
        if self.freer is not None:
            self._args += ["-colin-free", self.freer.label()]
        if self.structure is not None:
            write_mmcif(self._path("xyzin.cif"), self.structure)
            self._args += ["-pdbin", "xyzin.cif"]
        self._args += ["-cycles", str(self.cycles)]
        self._args += ["-anisotropy-correction"]
        self._args += ["-pdbout", "xyzout.cif"]
        self._args += ["-cif"]
        self._args += ["-xmlout", "xmlout.xml"]

    def _result(self) -> NautilusResult:
        return NautilusResult(self)


def _deoxyfy(structure: gemmi.Structure) -> None:
    dna_codes = set(DNA_CODES.values())
    for chain in structure[0]:
        has_t = False
        for residue in chain:
            if residue.name == "T":
                has_t = True
                break
        if has_t:
            for residue in chain:
                new_name = f"D{residue.name}"
                if new_name in dna_codes:
                    residue.name = new_name
        for residue in chain:
            if residue.name in dna_codes and "O2'" in residue:
                for i, atom in reversed(list(enumerate(residue))):
                    if atom.name == "O2'":
                        del residue[i]
