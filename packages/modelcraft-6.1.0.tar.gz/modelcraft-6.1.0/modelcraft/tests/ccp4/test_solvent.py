import gemmi
import pytest

from ...contents import AsuContents
from ...solvent import solvent_fraction


def test_1o6a():
    contents = AsuContents.from_pdbe("1o6a")
    cell = gemmi.UnitCell(61.481, 61.481, 113.148, 90, 90, 90)
    spacegroup = gemmi.SpaceGroup("P 41 21 2")
    fraction = solvent_fraction(contents, cell, spacegroup, resolution=1.85)
    assert fraction == pytest.approx(0.5, abs=0.1)
    contents.copies = None
    guessed = solvent_fraction(contents, cell, spacegroup, resolution=1.85)
    assert guessed == fraction
