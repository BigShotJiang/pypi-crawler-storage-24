"""Argument parser for the video-thumbnail-creator CLI."""

import argparse

from . import __version__


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="video-thumbnail-creator",
        description="Extract and select a thumbnail image from a video or image file.",
    )
    parser.add_argument(
        "--version", "-V",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    subparsers = parser.add_subparsers(dest="command")

    # ── extract subcommand ────────────────────────────────────────────────────
    extract = subparsers.add_parser(
        "extract",
        help="Extract a thumbnail from a video or image file.",
    )
    extract.add_argument("input_path", help="Path to the input video or image file.")
    extract.add_argument(
        "--mode",
        choices=["manual", "auto", "suggest"],
        default=None,
        help="Selection mode: manual (default), auto (AI), or suggest (AI + confirm).",
    )
    extract.add_argument(
        "--description",
        default=None,
        help="Optional description of the video for AI context (max 1000 chars).",
    )
    extract.add_argument(
        "--output-dir",
        default=None,
        dest="output_dir",
        help="Output directory (default: same directory as the video file).",
    )
    extract.add_argument(
        "--output-name-suffix",
        default=None,
        dest="output_name_suffix",
        help="Suffix appended to the video filename (without extension) to form the output name "
             "(default: -poster, e.g. video-poster.jpg).",
    )
    extract.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Emit machine-readable JSON to stdout.",
    )
    extract.add_argument(
        "--format",
        choices=["landscape", "poster"],
        default=None,
        dest="format",
        help="Output format: 'poster' (2:3, 1080×1620, default) or 'landscape' (16:9, 1920×1080).",
    )
    extract.add_argument(
        "--overlay-title",
        default=None,
        dest="overlay_title",
        help="Text to overlay on the output image.",
    )
    extract.add_argument(
        "--overlay-title-from-filename",
        action="store_true",
        default=False,
        dest="overlay_title_from_filename",
        help="Use the input filename stem as the overlay title.",
    )
    extract.add_argument(
        "--overlay-category",
        default=None,
        dest="overlay_category",
        help="Category label shown above the title in poster format.",
    )
    extract.add_argument(
        "--overlay-category-logo",
        default=None,
        dest="overlay_category_logo",
        metavar="PATH",
        help="PNG logo shown instead of category text in poster format. "
             "Wide logos are centered above the title; square/portrait logos appear left of it.",
    )
    extract.add_argument(
        "--overlay-note",
        default=None,
        dest="overlay_note",
        help="Small text shown at the bottom-right of the poster text area.",
    )
    extract.add_argument(
        "--style",
        default="internet",
        dest="style",
        metavar="NAME",
        help="Poster style to use (default: 'internet'). Run 'styles' to list available options.",
    )
    extract.add_argument(
        "--embedded-image",
        choices=["prefer", "ignore", "ask"],
        default=None,
        dest="embedded_image",
        help="How to handle embedded cover art and sidecar images: prefer (use if available), "
             "ignore (always extract frames), ask (prompt user). Default from config.",
    )
    extract.add_argument(
        "--crop-position",
        choices=["left", "center-left", "center", "center-right", "right"],
        default=None,
        dest="crop_position",
        help="Crop position for poster format. Skips interactive prompt and AI crop selection. "
             "One of: left, center-left, center, center-right, right.",
    )
    extract.add_argument(
        "--no-badges",
        action="store_true",
        default=False,
        dest="no_badges",
        help="Disable automatic technical badges (4K, HDR, FHD) on the poster.",
    )
    extract.add_argument(
        "--fanart",
        action="store_true",
        default=False,
        dest="fanart",
        help="Generate an additional clean 16:9 fanart image (for Infuse/Emby) with -fanart suffix.",
    )

    # ── styles subcommand ────────────────────────────────────────────────────
    subparsers.add_parser(
        "styles",
        help="List available poster styles.",
    )

    # ── config subcommand ─────────────────────────────────────────────────────
    config_parser = subparsers.add_parser(
        "config",
        help="Manage configuration settings.",
    )
    config_sub = config_parser.add_subparsers(dest="config_command")

    config_set = config_sub.add_parser("set", help="Set a configuration value.")
    config_set.add_argument("key", help="Config key in section.field format (e.g. claude.api_key).")
    config_set.add_argument("value", help="Value to store.")

    config_get = config_sub.add_parser("get", help="Get a configuration value.")
    config_get.add_argument("key", help="Config key in section.field format.")

    config_sub.add_parser("list", help="List all configured values.")

    # ── info subcommand ────────────────────────────────────────────────────
    info_parser = subparsers.add_parser(
        "info",
        help="Display embedded metadata from a generated poster image.",
    )
    info_parser.add_argument("image_path", help="Path to a poster image file.")
    info_parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Emit metadata as JSON to stdout.",
    )

    return parser
