"""Tests for the embedded_image module and related CLI behaviour."""

import argparse
import io
import json
import os
import tempfile
import unittest
from contextlib import redirect_stdout
from unittest.mock import MagicMock, patch

from video_thumbnail_creator.embedded_image import (
    detect_embedded_image,
    extract_embedded_image,
)


# ---------------------------------------------------------------------------
# detect_embedded_image tests
# ---------------------------------------------------------------------------

class TestDetectEmbeddedImageFound(unittest.TestCase):
    """detect_embedded_image returns True when attached_pic stream exists."""

    def _ffprobe_output(self):
        return json.dumps({
            "streams": [
                {
                    "codec_name": "h264",
                    "disposition": {"attached_pic": 0, "default": 1},
                },
                {
                    "codec_name": "mjpeg",
                    "disposition": {"attached_pic": 1, "default": 0},
                },
            ]
        })

    def test_returns_true(self):
        mock_result = MagicMock(returncode=0, stdout=self._ffprobe_output())
        with patch("video_thumbnail_creator.embedded_image.subprocess.run", return_value=mock_result):
            self.assertTrue(detect_embedded_image("/fake/video.mp4"))

    def test_ffprobe_called_with_video_path(self):
        mock_result = MagicMock(returncode=0, stdout=self._ffprobe_output())
        with patch("video_thumbnail_creator.embedded_image.subprocess.run", return_value=mock_result) as mock_run:
            detect_embedded_image("/fake/video.mp4")
        cmd = mock_run.call_args[0][0]
        self.assertIn("/fake/video.mp4", cmd)
        self.assertIn("ffprobe", cmd[0])


class TestDetectEmbeddedImageNotFound(unittest.TestCase):
    """detect_embedded_image returns False when no attached_pic stream exists."""

    def test_returns_false_when_no_attached_pic(self):
        output = json.dumps({
            "streams": [
                {
                    "codec_name": "h264",
                    "disposition": {"attached_pic": 0, "default": 1},
                },
            ]
        })
        mock_result = MagicMock(returncode=0, stdout=output)
        with patch("video_thumbnail_creator.embedded_image.subprocess.run", return_value=mock_result):
            self.assertFalse(detect_embedded_image("/fake/video.mp4"))

    def test_returns_false_when_no_streams(self):
        output = json.dumps({"streams": []})
        mock_result = MagicMock(returncode=0, stdout=output)
        with patch("video_thumbnail_creator.embedded_image.subprocess.run", return_value=mock_result):
            self.assertFalse(detect_embedded_image("/fake/video.mp4"))

    def test_returns_false_on_ffprobe_error(self):
        mock_result = MagicMock(returncode=1, stdout="")
        with patch("video_thumbnail_creator.embedded_image.subprocess.run", return_value=mock_result):
            self.assertFalse(detect_embedded_image("/fake/video.mp4"))

    def test_returns_false_on_invalid_json(self):
        mock_result = MagicMock(returncode=0, stdout="not json")
        with patch("video_thumbnail_creator.embedded_image.subprocess.run", return_value=mock_result):
            self.assertFalse(detect_embedded_image("/fake/video.mp4"))

    def test_uses_custom_ffprobe_binary(self):
        output = json.dumps({"streams": []})
        mock_result = MagicMock(returncode=0, stdout=output)
        with patch("video_thumbnail_creator.embedded_image.subprocess.run", return_value=mock_result) as mock_run:
            detect_embedded_image("/fake/video.mp4", ffprobe="/custom/ffprobe")
        # call_args_list[0] is the ffprobe call; [1] would be AtomicParsley fallback
        cmd = mock_run.call_args_list[0][0][0]
        self.assertEqual(cmd[0], "/custom/ffprobe")


# ---------------------------------------------------------------------------
# extract_embedded_image tests
# ---------------------------------------------------------------------------

class TestExtractEmbeddedImage(unittest.TestCase):
    """Tests for extract_embedded_image."""

    def _make_probe_output(self, stream_index: int = 1) -> str:
        return json.dumps({
            "streams": [
                {
                    "index": 0,
                    "codec_name": "h264",
                    "disposition": {"attached_pic": 0},
                },
                {
                    "index": stream_index,
                    "codec_name": "mjpeg",
                    "disposition": {"attached_pic": 1},
                },
            ]
        })

    def test_extracts_image_and_returns_abs_path(self):
        probe_result = MagicMock(returncode=0, stdout=self._make_probe_output())
        ffmpeg_result = MagicMock(returncode=0)
        with patch(
            "video_thumbnail_creator.embedded_image.subprocess.run",
            side_effect=[probe_result, ffmpeg_result],
        ):
            with tempfile.TemporaryDirectory() as tmpdir:
                out = os.path.join(tmpdir, "cover.jpg")
                result = extract_embedded_image("/fake/video.mp4", out)
            self.assertTrue(os.path.isabs(result))

    def test_raises_when_no_embedded_image(self):
        probe_result = MagicMock(
            returncode=0,
            stdout=json.dumps({"streams": [{"index": 0, "codec_name": "h264", "disposition": {"attached_pic": 0}}]}),
        )
        # Simulate AtomicParsley not installed so the fallback raises RuntimeError
        with patch(
            "video_thumbnail_creator.embedded_image.subprocess.run",
            side_effect=[probe_result, FileNotFoundError("AtomicParsley not found")],
        ):
            with self.assertRaises(RuntimeError):
                extract_embedded_image("/fake/video.mp4", "/tmp/out.jpg")

    def test_raises_on_ffprobe_failure(self):
        probe_result = MagicMock(returncode=1, stdout="", stderr="error")
        with patch("video_thumbnail_creator.embedded_image.subprocess.run", return_value=probe_result):
            with self.assertRaises(RuntimeError):
                extract_embedded_image("/fake/video.mp4", "/tmp/out.jpg")

    def test_ffmpeg_called_with_correct_stream_map(self):
        probe_result = MagicMock(returncode=0, stdout=self._make_probe_output(stream_index=2))
        ffmpeg_result = MagicMock(returncode=0)
        with patch(
            "video_thumbnail_creator.embedded_image.subprocess.run",
            side_effect=[probe_result, ffmpeg_result],
        ) as mock_run:
            extract_embedded_image("/fake/video.mp4", "/tmp/out.jpg")
        # Second call is ffmpeg
        ffmpeg_cmd = mock_run.call_args_list[1][0][0]
        self.assertIn("-map", ffmpeg_cmd)
        map_idx = ffmpeg_cmd.index("-map")
        self.assertEqual(ffmpeg_cmd[map_idx + 1], "0:2")


# ---------------------------------------------------------------------------
# CLI argument parsing tests
# ---------------------------------------------------------------------------

class TestEmbeddedImageCLIArgument(unittest.TestCase):
    """Test that --embedded-image is parsed correctly."""

    def _build_parser(self):
        from video_thumbnail_creator.cli import _build_parser
        return _build_parser()

    def test_prefer_choice(self):
        parser = self._build_parser()
        args = parser.parse_args(["extract", "video.mp4", "--embedded-image", "prefer"])
        self.assertEqual(args.embedded_image, "prefer")

    def test_ignore_choice(self):
        parser = self._build_parser()
        args = parser.parse_args(["extract", "video.mp4", "--embedded-image", "ignore"])
        self.assertEqual(args.embedded_image, "ignore")

    def test_ask_choice(self):
        parser = self._build_parser()
        args = parser.parse_args(["extract", "video.mp4", "--embedded-image", "ask"])
        self.assertEqual(args.embedded_image, "ask")

    def test_default_is_none(self):
        parser = self._build_parser()
        args = parser.parse_args(["extract", "video.mp4"])
        self.assertIsNone(args.embedded_image)

    def test_invalid_choice_raises(self):
        parser = self._build_parser()
        with self.assertRaises(SystemExit):
            parser.parse_args(["extract", "video.mp4", "--embedded-image", "always"])


# ---------------------------------------------------------------------------
# Config key tests
# ---------------------------------------------------------------------------

class TestEmbeddedImageConfig(unittest.TestCase):
    """Test that defaults.embedded_image is in ALLOWED_KEYS with correct default."""

    def test_key_in_allowed_keys(self):
        from video_thumbnail_creator.config import ALLOWED_KEYS
        self.assertIn("defaults.embedded_image", ALLOWED_KEYS)

    def test_default_value_is_ask(self):
        from video_thumbnail_creator.config import _BUILTIN_DEFAULTS
        self.assertEqual(_BUILTIN_DEFAULTS["defaults"]["embedded_image"], "ask")

    def test_effective_config_includes_embedded_image(self):
        from video_thumbnail_creator.config import get_effective_config
        with patch("video_thumbnail_creator.config.load_config", return_value={}):
            result = get_effective_config()
        self.assertEqual(result["defaults"]["embedded_image"], "ask")


# ---------------------------------------------------------------------------
# JSON output 'source' field tests
# ---------------------------------------------------------------------------

class TestEmitResultSource(unittest.TestCase):
    """Tests for the source field in JSON output."""

    def _emit(self, **kwargs):
        from video_thumbnail_creator.cli import _emit_result
        buf = io.StringIO()
        with redirect_stdout(buf):
            _emit_result(**kwargs)
        return json.loads(buf.getvalue())

    def test_source_frame_in_json(self):
        data = self._emit(
            poster_path="/tmp/p.jpg",
            frame_index=5,
            mode="auto",
            reasoning="ok",
            input_path="/tmp/v.mp4",
            use_json=True,
            source="frame",
        )
        self.assertEqual(data["source"], "frame")

    def test_source_embedded_in_json(self):
        data = self._emit(
            poster_path="/tmp/p.jpg",
            frame_index=-1,
            mode="auto",
            reasoning="Embedded cover art was used as source image.",
            input_path="/tmp/v.mp4",
            use_json=True,
            source="embedded",
        )
        self.assertEqual(data["source"], "embedded")
        self.assertEqual(data["frame_index"], -1)

    def test_source_defaults_to_frame(self):
        data = self._emit(
            poster_path="/tmp/p.jpg",
            frame_index=3,
            mode="manual",
            reasoning="",
            input_path="/tmp/v.mp4",
            use_json=True,
        )
        self.assertEqual(data["source"], "frame")


if __name__ == "__main__":
    unittest.main()


# ---------------------------------------------------------------------------
# _run_with_embedded_reframe tests
# ---------------------------------------------------------------------------

def _make_jpeg_test(path: str, width: int = 100, height: int = 100) -> None:
    """Create a minimal JPEG test image."""
    from PIL import Image
    img = Image.new("RGB", (width, height), color=(128, 128, 128))
    img.save(path, "JPEG")


class TestRunWithEmbeddedReframe(unittest.TestCase):
    """Tests for _run_with_embedded_reframe() in cli_image_handlers."""

    def _make_args(self, tmpdir: str, **kwargs) -> argparse.Namespace:
        args = argparse.Namespace(
            input_path=os.path.join(tmpdir, "video.mp4"),
            output_dir=tmpdir,
            output_name_suffix="-poster",
            format="poster",
            mode="auto",
            style="",
            template={},
            ffmpeg_bin="ffmpeg",
            ffprobe_bin="ffprobe",
            claude_api_key="",
            claude_model="claude-3-5-sonnet-20241022",
            json=False,
            overlay_title=None,
            overlay_title_from_filename=False,
            overlay_category=None,
            overlay_category_logo=None,
            overlay_note=None,
            crop_position=None,
            detected_badges=[],
            fanart=False,
            video_properties=None,
        )
        for k, v in kwargs.items():
            setattr(args, k, v)
        return args

    def test_reframe_extracts_correct_frame_index(self):
        """_run_with_embedded_reframe passes the correct frame_index to extract_single_frame_highres."""
        from video_thumbnail_creator.cli_image_handlers import _run_with_embedded_reframe
        from video_thumbnail_creator.cli_helpers import EXIT_SUCCESS

        with tempfile.TemporaryDirectory() as tmpdir:
            args = self._make_args(tmpdir)

            with patch(
                "video_thumbnail_creator.cli_image_handlers.extract_single_frame_highres",
            ) as mock_extract, patch(
                "video_thumbnail_creator.cli_image_handlers._finalize_frame",
                return_value=EXIT_SUCCESS,
            ) as mock_finalize:
                mock_extract.return_value = os.path.join(tmpdir, "highres_reframe.jpg")

                result = _run_with_embedded_reframe(
                    args,
                    frame_index=7,
                    meta_crop_position="center-left",
                    meta_reasoning="Sharp frame",
                    tmpdir=tmpdir,
                )

        self.assertEqual(result, EXIT_SUCCESS)
        mock_extract.assert_called_once_with(
            args.input_path, 7, os.path.join(tmpdir, "highres_reframe.jpg"),
            ffmpeg="ffmpeg", ffprobe="ffprobe",
        )
        # _finalize_frame must be called with the metadata frame_index and crop_position
        mock_finalize.assert_called_once()
        call_args = mock_finalize.call_args[0]
        self.assertEqual(call_args[1], 7)           # frame_index
        self.assertEqual(call_args[5], "center-left")  # crop_position

    def test_reframe_uses_cli_crop_over_metadata(self):
        """When --crop-position is set, it overrides the metadata crop_position."""
        from video_thumbnail_creator.cli_image_handlers import _run_with_embedded_reframe
        from video_thumbnail_creator.cli_helpers import EXIT_SUCCESS

        with tempfile.TemporaryDirectory() as tmpdir:
            args = self._make_args(tmpdir, crop_position="right")

            with patch(
                "video_thumbnail_creator.cli_image_handlers.extract_single_frame_highres",
            ) as mock_extract, patch(
                "video_thumbnail_creator.cli_image_handlers._finalize_frame",
                return_value=EXIT_SUCCESS,
            ) as mock_finalize:
                mock_extract.return_value = os.path.join(tmpdir, "highres_reframe.jpg")

                _run_with_embedded_reframe(
                    args,
                    frame_index=3,
                    meta_crop_position="left",
                    meta_reasoning="",
                    tmpdir=tmpdir,
                )

        call_args = mock_finalize.call_args[0]
        # crop_position should be the CLI override ("right"), not the metadata value ("left")
        self.assertEqual(call_args[5], "right")

    def test_reframe_uses_metadata_crop_in_auto_mode(self):
        """In auto mode without --crop-position, metadata crop_position is used directly."""
        from video_thumbnail_creator.cli_image_handlers import _run_with_embedded_reframe
        from video_thumbnail_creator.cli_helpers import EXIT_SUCCESS

        with tempfile.TemporaryDirectory() as tmpdir:
            args = self._make_args(tmpdir, mode="auto", crop_position=None)

            with patch(
                "video_thumbnail_creator.cli_image_handlers.extract_single_frame_highres",
            ) as mock_extract, patch(
                "video_thumbnail_creator.cli_image_handlers._finalize_frame",
                return_value=EXIT_SUCCESS,
            ) as mock_finalize:
                mock_extract.return_value = os.path.join(tmpdir, "highres_reframe.jpg")

                _run_with_embedded_reframe(
                    args,
                    frame_index=10,
                    meta_crop_position="center-right",
                    meta_reasoning="AI picked this",
                    tmpdir=tmpdir,
                )

        call_args = mock_finalize.call_args[0]
        self.assertEqual(call_args[5], "center-right")

    def test_reframe_returns_error_when_extraction_fails(self):
        """_run_with_embedded_reframe returns EXIT_ERROR when frame extraction raises."""
        from video_thumbnail_creator.cli_image_handlers import _run_with_embedded_reframe
        from video_thumbnail_creator.cli_helpers import EXIT_ERROR

        with tempfile.TemporaryDirectory() as tmpdir:
            args = self._make_args(tmpdir)

            with patch(
                "video_thumbnail_creator.cli_image_handlers.extract_single_frame_highres",
                side_effect=RuntimeError("ffmpeg failed"),
            ):
                result = _run_with_embedded_reframe(
                    args,
                    frame_index=5,
                    meta_crop_position="center",
                    meta_reasoning="",
                    tmpdir=tmpdir,
                )

        self.assertEqual(result, EXIT_ERROR)


class TestEmbeddedMetadataReframeDecision(unittest.TestCase):
    """Unit tests for the metadata-check decision logic used in cli.py."""

    def test_valid_frame_index_triggers_reframe(self):
        """Embedded image with frame_index >= 0 should lead to reframe path."""
        from video_thumbnail_creator.metadata import build_metadata, embed_metadata, read_metadata

        with tempfile.TemporaryDirectory() as tmpdir:
            img_path = os.path.join(tmpdir, "poster.jpg")
            _make_jpeg_test(img_path)
            meta = build_metadata(
                source="frame", frame_index=5, crop_position="center-left",
                fmt="poster", mode="auto", input_file="video.mp4",
                ai_reasoning="Sharp and well-lit frame.",
            )
            embed_metadata(img_path, meta)

            embedded_meta = read_metadata(img_path)
            embedded_frame_index = (embedded_meta or {}).get("frame_index", -1)

            self.assertEqual(embedded_frame_index, 5)
            self.assertTrue(isinstance(embedded_frame_index, int) and embedded_frame_index >= 0)
            self.assertEqual(embedded_meta.get("crop_position"), "center-left")
            self.assertEqual(embedded_meta.get("ai_reasoning"), "Sharp and well-lit frame.")

    def test_missing_vtc_metadata_falls_back_to_embedded_flow(self):
        """Plain JPEG without VTC metadata should use old embedded image flow."""
        from video_thumbnail_creator.metadata import read_metadata

        with tempfile.TemporaryDirectory() as tmpdir:
            img_path = os.path.join(tmpdir, "plain.jpg")
            _make_jpeg_test(img_path)

            embedded_meta = read_metadata(img_path)
            embedded_frame_index = (embedded_meta or {}).get("frame_index", -1)

            # No metadata → frame_index is -1 → old flow
            self.assertIsNone(embedded_meta)
            self.assertEqual(embedded_frame_index, -1)
            self.assertFalse(isinstance(embedded_frame_index, int) and embedded_frame_index >= 0)

    def test_frame_index_minus_one_falls_back_to_embedded_flow(self):
        """Embedded VTC image generated from non-video source (frame_index=-1) uses old flow."""
        from video_thumbnail_creator.metadata import build_metadata, embed_metadata, read_metadata

        with tempfile.TemporaryDirectory() as tmpdir:
            img_path = os.path.join(tmpdir, "poster.jpg")
            _make_jpeg_test(img_path)
            meta = build_metadata(
                source="embedded", frame_index=-1, crop_position="center",
                fmt="poster", mode="auto", input_file="video.mp4",
            )
            embed_metadata(img_path, meta)

            embedded_meta = read_metadata(img_path)
            embedded_frame_index = (embedded_meta or {}).get("frame_index", -1)

            # build_metadata omits frame_index when it is -1 (see metadata.py).
            # get() returns the -1 default, so the condition frame_index >= 0 is False
            # and the old embedded-image flow is used instead of reframe.
            self.assertNotIn("frame_index", embedded_meta)
            self.assertEqual(embedded_frame_index, -1)
            self.assertFalse(isinstance(embedded_frame_index, int) and embedded_frame_index >= 0)
