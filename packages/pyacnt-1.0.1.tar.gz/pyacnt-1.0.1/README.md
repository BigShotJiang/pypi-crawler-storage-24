# Pyaccount (or Pyacnt)

Pyaccount is a Python extension that allows you to manage profiles: easily create, connect, delete, add data, read data and greet users.

## Installation

```bash
pip install pyaccount
```

## Usage

```python
import pyaccount

# Create an account
pyaccount.enter("Alice", "password123")

# Log in
pyaccount.connect("Alice", "password123")

# Welcome message
pyaccount.welcome("Alice")

# Add data
pyaccount.set_data("Alice", "age", 20)

# Read data
print(pyaccount.get_data("Alice", "age"))

# Disconnect
pyaccount.exit("Alice")
```

## Commands

| Command | Description |
|---|---|
| `enter(name, password)` | Create an account |
| `connect(name, password)` | Log in |
| `exit(name)` | Disconnect |
| `welcome(name)` | Display welcome message |
| `set_data(name, key, value)` | Add data to account |
| `get_data(name, key)` | Read data from account |

> 💡 Passwords are secured using **SHA-256** hashing.

## License

MIT
