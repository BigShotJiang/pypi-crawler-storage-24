"""
ADO field mapper for extracting fields from Azure DevOps work items.

This mapper extracts fields from ADO work items which use separate fields
(e.g., System.Description, System.AcceptanceCriteria, Microsoft.VSTS.Common.StoryPoints)
with support for custom template field mappings.
"""

from __future__ import annotations

import html
import re
from pathlib import Path
from typing import Any

from beartype import beartype
from icontract import ensure, require

from specfact_cli.backlog.mappers.base import FieldMapper
from specfact_cli.backlog.mappers.template_config import FieldMappingConfig


class AdoFieldMapper(FieldMapper):
    """
    Field mapper for Azure DevOps work items.

    Extracts fields from separate ADO fields with support for:
    - Default mappings (Scrum, Agile, SAFe, Kanban)
    - Custom template mappings via YAML configuration
    - Framework-aware field extraction (work item types, value points, etc.)
    """

    # Default ADO field mappings (Scrum/Agile/SAFe)
    DEFAULT_FIELD_MAPPINGS = {
        "System.Description": "description",
        "System.AcceptanceCriteria": "acceptance_criteria",
        "Microsoft.VSTS.Common.AcceptanceCriteria": "acceptance_criteria",  # Alternative field name
        "Microsoft.VSTS.Common.StoryPoints": "story_points",
        "Microsoft.VSTS.Scheduling.StoryPoints": "story_points",  # Alternative field name
        "Microsoft.VSTS.Common.BusinessValue": "business_value",
        "Microsoft.VSTS.Common.Priority": "priority",
        "System.WorkItemType": "work_item_type",
    }

    def __init__(self, custom_mapping_file: str | Path | None = None) -> None:
        """
        Initialize ADO field mapper.

        Args:
            custom_mapping_file: Path to custom field mapping YAML file (optional).
                If None, checks for `.specfact/templates/backlog/field_mappings/ado_custom.yaml` in current directory.
        """
        self.custom_mapping: FieldMappingConfig | None = None

        # If custom_mapping_file not provided, check standard location
        if custom_mapping_file is None:
            current_dir = Path.cwd()
            standard_location = (
                current_dir / ".specfact" / "templates" / "backlog" / "field_mappings" / "ado_custom.yaml"
            )
            if standard_location.exists():
                custom_mapping_file = standard_location

        if custom_mapping_file:
            try:
                self.custom_mapping = FieldMappingConfig.from_file(custom_mapping_file)
            except (FileNotFoundError, ValueError) as e:
                # Log warning but continue with defaults
                import warnings

                warnings.warn(f"Failed to load custom field mapping: {e}. Using defaults.", UserWarning, stacklevel=2)

    def _extract_clamped_numeric_fields_ado(
        self,
        fields_dict: dict[str, Any],
        field_mappings: dict[str, Any],
        extracted_fields: dict[str, Any],
    ) -> None:
        story_points = self._extract_numeric_field(fields_dict, field_mappings, "story_points")
        extracted_fields["story_points"] = None if story_points is None else max(0, min(100, story_points))
        business_value = self._extract_numeric_field(fields_dict, field_mappings, "business_value")
        extracted_fields["business_value"] = None if business_value is None else max(0, min(100, business_value))
        priority = self._extract_numeric_field(fields_dict, field_mappings, "priority")
        extracted_fields["priority"] = None if priority is None else max(1, min(4, priority))

    def _ado_apply_value_points(self, extracted_fields: dict[str, Any]) -> None:
        business_value_val: int | None = extracted_fields.get("business_value")
        story_points_val: int | None = extracted_fields.get("story_points")
        if (
            business_value_val is None
            or story_points_val is None
            or story_points_val == 0
            or not isinstance(business_value_val, int)
            or not isinstance(story_points_val, int)
        ):
            extracted_fields["value_points"] = None
            return
        try:
            extracted_fields["value_points"] = int(business_value_val / story_points_val)
        except (ZeroDivisionError, TypeError):
            extracted_fields["value_points"] = None

    @beartype
    @require(lambda self, item_data: isinstance(item_data, dict), "Item data must be dict")
    @ensure(lambda result: isinstance(result, dict), "Must return dict")
    def extract_fields(self, item_data: dict[str, Any]) -> dict[str, Any]:
        """
        Extract fields from ADO work item data.

        Args:
            item_data: ADO work item data from API

        Returns:
            Dict mapping canonical field names to extracted values
        """
        fields_dict = item_data.get("fields", {})
        if not isinstance(fields_dict, dict):
            return {}

        # Use custom mapping if available, otherwise use defaults
        field_mappings = self._get_field_mappings()

        extracted_fields: dict[str, Any] = {}

        # Extract description
        description = self._extract_field(fields_dict, field_mappings, "description")
        extracted_fields["description"] = description if description else ""

        # Extract acceptance criteria
        acceptance_criteria = self._extract_field(fields_dict, field_mappings, "acceptance_criteria")
        extracted_fields["acceptance_criteria"] = acceptance_criteria if acceptance_criteria else None

        self._extract_clamped_numeric_fields_ado(fields_dict, field_mappings, extracted_fields)
        self._ado_apply_value_points(extracted_fields)

        # Extract work item type
        work_item_type = self._extract_work_item_type(fields_dict, field_mappings)
        extracted_fields["work_item_type"] = work_item_type

        return extracted_fields

    @beartype
    @require(lambda self, canonical_fields: isinstance(canonical_fields, dict), "Canonical fields must be dict")
    @ensure(lambda result: isinstance(result, dict), "Must return dict")
    def map_from_canonical(self, canonical_fields: dict[str, Any]) -> dict[str, Any]:
        """
        Map canonical fields back to ADO field format.

        When multiple ADO fields map to the same canonical field, prefers System.* fields
        over Microsoft.VSTS.Common.* fields for better compatibility with Scrum templates.

        Args:
            canonical_fields: Dict of canonical field names to values

        Returns:
            Dict mapping ADO field names to values
        """
        ado_fields: dict[str, Any] = {}

        # Map each canonical field to ADO field
        for canonical_field, value in canonical_fields.items():
            ado_field_name = self.resolve_write_target_field(canonical_field)
            if ado_field_name:
                ado_fields[ado_field_name] = value

        return ado_fields

    @beartype
    @require(lambda self, canonical_field: isinstance(canonical_field, str), "Canonical field must be str")
    @require(
        lambda self, provider_field_names: (
            provider_field_names is None or isinstance(provider_field_names, (set, frozenset))
        ),
        "provider_field_names must be set-like or None",
    )
    @ensure(lambda result: result is None or isinstance(result, str), "Must return str or None")
    def resolve_write_target_field(
        self,
        canonical_field: str,
        provider_field_names: set[str] | frozenset[str] | None = None,
    ) -> str | None:
        """
        Resolve deterministic ADO write-target field for a canonical field.

        Precedence:
        1. Explicit custom mapping candidates (in custom mapping file order)
        2. Provider-present candidates from mapped fields
        3. Mapper fallback candidate order
        """
        custom_candidates = self._get_custom_write_target_candidates(canonical_field)
        if custom_candidates:
            return custom_candidates[0]

        candidates = self._get_write_target_candidates(canonical_field)
        if not candidates:
            return None

        provider_fields = {f for f in (provider_field_names or set()) if isinstance(f, str)}
        for candidate in candidates:
            if candidate in provider_fields:
                return candidate

        return candidates[0]

    @beartype
    @ensure(lambda result: isinstance(result, dict), "Must return dict")
    def _get_field_mappings(self) -> dict[str, str]:
        """
        Get field mappings (custom or default).

        Returns:
            Dict mapping ADO field names to canonical field names
        """
        if self.custom_mapping and self.custom_mapping.field_mappings:
            # Merge custom mappings with defaults (custom overrides defaults)
            mappings = self.DEFAULT_FIELD_MAPPINGS.copy()
            mappings.update(self.custom_mapping.field_mappings)
            return mappings
        return self.DEFAULT_FIELD_MAPPINGS.copy()

    @beartype
    @require(lambda self, canonical_field: isinstance(canonical_field, str), "Canonical field must be str")
    @ensure(lambda result: isinstance(result, list), "Must return list")
    def _get_write_target_candidates(self, canonical_field: str) -> list[str]:
        """Return ordered write-target candidates for a canonical field."""
        ordered: list[str] = []
        seen: set[str] = set()

        def _add(ado_field: str) -> None:
            if ado_field not in seen:
                ordered.append(ado_field)
                seen.add(ado_field)

        for ado_field in self._get_custom_write_target_candidates(canonical_field):
            _add(ado_field)

        for ado_field, mapped_canonical in self._get_field_mappings().items():
            if mapped_canonical == canonical_field:
                _add(ado_field)

        return ordered

    @beartype
    @require(lambda self, canonical_field: isinstance(canonical_field, str), "Canonical field must be str")
    @ensure(lambda result: isinstance(result, list), "Must return list")
    def _get_custom_write_target_candidates(self, canonical_field: str) -> list[str]:
        """Return ordered candidates declared explicitly in custom mapping."""
        if not (self.custom_mapping and self.custom_mapping.field_mappings):
            return []
        return [
            ado_field
            for ado_field, mapped_canonical in self.custom_mapping.field_mappings.items()
            if mapped_canonical == canonical_field
        ]

    @beartype
    @require(lambda self, fields_dict: isinstance(fields_dict, dict), "Fields dict must be dict")
    @require(lambda self, field_mappings: isinstance(field_mappings, dict), "Field mappings must be dict")
    @require(lambda self, canonical_field: isinstance(canonical_field, str), "Canonical field must be str")
    @ensure(lambda result: result is None or isinstance(result, str), "Must return str or None")
    def _extract_field(
        self, fields_dict: dict[str, Any], field_mappings: dict[str, str], canonical_field: str
    ) -> str | None:
        """
        Extract field value from ADO fields dict using mapping.

        Supports multiple field name alternatives for the same canonical field.
        Checks all ADO fields that map to the canonical field and returns the first found value.
        Priority: custom mapping > default mapping (handled by _get_field_mappings merge order).

        Args:
            fields_dict: ADO fields dict
            field_mappings: Field mappings (ADO field name -> canonical field name)
            canonical_field: Canonical field name to extract

        Returns:
            Field value or None if not found
        """
        # Find all ADO field names that map to this canonical field
        # Check all alternatives and return the first found value
        for ado_field, canonical in field_mappings.items():
            if canonical == canonical_field:
                value = fields_dict.get(ado_field)
                if value is not None:
                    normalized_value = str(value).strip() if isinstance(value, str) else str(value)
                    return self._normalize_rich_text_to_markdown(normalized_value)
        return None

    @beartype
    @require(lambda self, fields_dict: isinstance(fields_dict, dict), "Fields dict must be dict")
    @require(lambda self, field_mappings: isinstance(field_mappings, dict), "Field mappings must be dict")
    @require(lambda self, canonical_field: isinstance(canonical_field, str), "Canonical field must be str")
    @ensure(lambda result: result is None or isinstance(result, int), "Must return int or None")
    def _extract_numeric_field(
        self, fields_dict: dict[str, Any], field_mappings: dict[str, str], canonical_field: str
    ) -> int | None:
        """
        Extract numeric field value from ADO fields dict using mapping.

        Args:
            fields_dict: ADO fields dict
            field_mappings: Field mappings (ADO field name -> canonical field name)
            canonical_field: Canonical field name to extract

        Returns:
            Numeric value or None if not found
        """
        # Find ADO field name for this canonical field
        for ado_field, canonical in field_mappings.items():
            if canonical == canonical_field:
                value = fields_dict.get(ado_field)
                if value is not None:
                    try:
                        # Handle both int and float (ADO may return float for story points)
                        return int(float(value))
                    except (ValueError, TypeError):
                        return None
        return None

    @beartype
    @require(lambda self, value: isinstance(value, str), "Value must be str")
    @ensure(lambda result: isinstance(result, str), "Must return str")
    def _normalize_rich_text_to_markdown(self, value: str) -> str:
        """Normalize ADO rich text content to markdown-like plain text."""
        if not value:
            return value

        value = html.unescape(value)

        rich_text_tag_pattern = re.compile(
            r"</?(?:p|br|strong|b|em|i|pre|code|a|li|ul|ol|h[1-6]|div|span|blockquote)(?:\s[^<>]*)?>",
            flags=re.IGNORECASE,
        )
        if not rich_text_tag_pattern.search(value):
            return value

        normalized = re.sub(r"<!--.*?-->", "", value, flags=re.DOTALL)
        normalized = re.sub(r"<h([1-6])[^>]*>(.*?)</h[1-6]>", self._replace_heading, normalized, flags=re.DOTALL)
        normalized = re.sub(r"<strong>(.*?)</strong>", r"**\1**", normalized, flags=re.DOTALL | re.IGNORECASE)
        normalized = re.sub(r"<b>(.*?)</b>", r"**\1**", normalized, flags=re.DOTALL | re.IGNORECASE)
        normalized = re.sub(r"<em>(.*?)</em>", r"*\1*", normalized, flags=re.DOTALL | re.IGNORECASE)
        normalized = re.sub(r"<i>(.*?)</i>", r"*\1*", normalized, flags=re.DOTALL | re.IGNORECASE)
        normalized = re.sub(r"<pre><code>(.*?)</code></pre>", r"```\n\1\n```", normalized, flags=re.DOTALL)
        normalized = re.sub(r"<code>(.*?)</code>", r"`\1`", normalized, flags=re.DOTALL)
        normalized = re.sub(r'<a href="([^"]+)">(.*?)</a>', r"[\2](\1)", normalized, flags=re.DOTALL)
        normalized = re.sub(r"<li>(.*?)</li>", r"- \1", normalized, flags=re.DOTALL | re.IGNORECASE)
        normalized = re.sub(r"<ul>|</ul>|<ol>|</ol>", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"<p>(.*?)</p>", r"\1\n\n", normalized, flags=re.DOTALL | re.IGNORECASE)
        normalized = re.sub(r"<br\s*/?>", "\n", normalized, flags=re.IGNORECASE)
        normalized = rich_text_tag_pattern.sub("", normalized)
        normalized = re.sub(r"\n{3,}", "\n\n", normalized)
        return normalized.strip()

    @staticmethod
    @beartype
    def _replace_heading(match: re.Match[str]) -> str:
        """Convert HTML heading match to markdown heading."""
        level = int(match.group(1))
        content = match.group(2)
        return f"\n{'#' * level} {content}\n"

    @beartype
    @require(lambda self, fields_dict: isinstance(fields_dict, dict), "Fields dict must be dict")
    @require(lambda self, field_mappings: isinstance(field_mappings, dict), "Field mappings must be dict")
    @ensure(lambda result: result is None or isinstance(result, str), "Must return str or None")
    def _extract_work_item_type(self, fields_dict: dict[str, Any], field_mappings: dict[str, str]) -> str | None:
        """
        Extract work item type from ADO fields dict.

        Args:
            fields_dict: ADO fields dict
            field_mappings: Field mappings (ADO field name -> canonical field name)

        Returns:
            Work item type or None if not found
        """
        # Find ADO field name for work_item_type
        for ado_field, canonical in field_mappings.items():
            if canonical == "work_item_type":
                work_item_type = fields_dict.get(ado_field)
                if work_item_type:
                    # Apply work item type mapping if custom mapping is available
                    if self.custom_mapping:
                        return self.custom_mapping.map_work_item_type(str(work_item_type))
                    return str(work_item_type)
        return None
