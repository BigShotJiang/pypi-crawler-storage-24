"""Module for managing ternary plot data from bifurcation analysis.

This module contains the TernaryData class which handles loading, storing, and processing
bifurcation analysis data for ternary plots across different branch types, parameter types,
and bifurcation types.
"""
import os
import zipfile

import pandas as pd

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.data.bifurcation_data import BifurcationTypesExtended
from food_web_bifurcation_explorer.data.shape_data import ShapeData
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


class TernaryData:
    """Branch data container for storing and processing bifurcation analysis data."""

    def __init__(self):
        # declare dataframe
        self.ternary_dataframe: dict[BranchTypes, dict[ParameterTypes, dict[BifurcationTypesExtended, dict[int, pd.DataFrame | None]]]] = {}

        # iterate over parameter types, branch types and bifurcation types to initialize nested dictionaries
        for branch_type in BranchTypes:
            self.ternary_dataframe[branch_type] = {}
            for parameter_type in ParameterTypes:
                self.ternary_dataframe[branch_type][parameter_type] = {}
                for bifurcation_type in BifurcationTypesExtended:
                    self.ternary_dataframe[branch_type][parameter_type][bifurcation_type] = {}
                    # get num of traces
                    numTraces = IntegerNumbers.MAX_NUM_TRACES
                    if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                        numTraces = IntegerNumbers.MAX_NUM_EXTINCTION_TRACES
                    for index in range(numTraces):
                        self.ternary_dataframe[branch_type][parameter_type][bifurcation_type][index] = None

        # declare shape data
        self.shape_data: ShapeData = ShapeData()

        # declare auxiliar dictionaries using for loading data (used to calculate bauting points)
        self.hops_bifurcations = {}
        self.temporal_frame = {}

        # declare empty result (used in get_current_values when dataframe is empty))
        self.empty_result = [
            [None] * IntegerNumbers.MAX_FIXED_PARAMETERS,
            [None] * IntegerNumbers.MAX_FIXED_PARAMETERS,
            [None] * IntegerNumbers.MAX_FIXED_PARAMETERS,
        ]

    def clear_data(self):
        """reset all dataframes"""

        # simply reset all dataframes to empty
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:
                for bifurcation_type in BifurcationTypesExtended:
                    # get num of traces
                    numTraces = IntegerNumbers.MAX_NUM_TRACES
                    if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                        numTraces = IntegerNumbers.MAX_NUM_EXTINCTION_TRACES
                    for index in range(numTraces):
                        self.ternary_dataframe[branch_type][parameter_type][bifurcation_type][index] = None

    def get_ternary_values(self, branch_type: BranchTypes, bifurcation_type: BifurcationTypesExtended, index: int):
        """Get the list of values for a given branch, parameter, bifurcation type and index."""

        # get dataframe for current branch, parameter, bifurcation type and index
        dataframe = self.ternary_dataframe[branch_type][glob.config.fixed_parameter_type][bifurcation_type][index]

        # if the dataframe is None (not loaded) or empty, return empty result
        if dataframe is None or dataframe.empty:
            return self.empty_result

        # declare values arrays filled with None
        sd_values = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        sr_values = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS
        sl_values = [None] * IntegerNumbers.MAX_FIXED_PARAMETERS

        # Populate the arrays using the fixed_value directly as the array index
        for sd_val, sr_val, sl_val, fixed_pos in zip(dataframe["sd"], dataframe["sr"], dataframe["sl"], dataframe["fixed_value"]):
            pos = int(fixed_pos)
            sd_values[pos] = sd_val
            sr_values[pos] = sr_val
            sl_values[pos] = sl_val
        return [sd_values, sr_values, sl_values]

    def get_ternary_indexes(self, branch_type: BranchTypes, bifurcation_type: BifurcationTypesExtended):
        """Get the list of index columns for a given branch, parameter and bifurcation type."""

        # declare empty index list
        indexes = []

        # check for every index if the dataframe is not None (loaded) and not empty, then add to the list of indexes
        numTraces = IntegerNumbers.MAX_NUM_TRACES
        if bifurcation_type == BifurcationTypesExtended.EXTINCT:
            numTraces = IntegerNumbers.MAX_NUM_EXTINCTION_TRACES
        for index in range(numTraces):
            if self.ternary_dataframe[branch_type][glob.config.fixed_parameter_type][bifurcation_type][index] is not None:
                indexes.append(index)
        return indexes

    def load_parquet_data(self, ternary_zip_file):
        """Load parquet data from a parquet file stream and set fixed parameter information."""

        # first clear data
        self.clear_data()

        # try to load branch parquet file from zip
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:
                for bifurcation_type in BifurcationTypesExtended:
                    # get num of traces
                    numTraces = IntegerNumbers.MAX_NUM_TRACES
                    if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                        numTraces = IntegerNumbers.MAX_NUM_EXTINCTION_TRACES
                    for index in range(numTraces):
                        try:
                            with ternary_zip_file.open(
                                glob.files.get_ternary_parquet_file(branch_type, parameter_type, bifurcation_type, index)
                            ) as f:
                                self.ternary_dataframe[branch_type][parameter_type][bifurcation_type][index] = pd.read_parquet(f)
                        except:
                            pass

    def load_continuation_files(self, fixed_parameter_values: list[str]):
        """Read ternary data from continuation files."""

        # first clear data
        self.clear_data()

        # init auxiliar containers (hopf and temporal_frame)
        self._init_auxiliar_containers()

        # now read data for every zip file
        for index, fixed_parameter_value in enumerate(fixed_parameter_values):

            # show current processed value
            print(fixed_parameter_value)

            # get continuation zip file path
            continuation_zip_file_path = glob.files.get_continuation_zip_file(fixed_parameter_value)

            # check if file exists
            if os.path.exists(continuation_zip_file_path):

                # open continuation zip file
                with zipfile.ZipFile(continuation_zip_file_path, "r") as continuation_zip_file:

                    # open CSV for every parameter and branch type
                    for branch_type in BranchTypes:
                        for parameter_type in ParameterTypes:

                            # parse CSV in temporal dataframe
                            file_name = f"bifurcations_{branch_type.value}_{parameter_type.value}_{fixed_parameter_value}.csv"
                            with continuation_zip_file.open(file_name) as file:
                                tmp_dataframe = pd.read_csv(file)

                            # iterate over bifurcation types
                            for bifurcation_type in BifurcationTypesExtended:

                                # filter rows for current bifurcation type
                                bifurcation_type_rows = tmp_dataframe[tmp_dataframe["type"] == bifurcation_type.value]

                                # get max num of traces
                                maxNumTraces = IntegerNumbers.MAX_NUM_TRACES
                                if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                                    maxNumTraces = IntegerNumbers.MAX_NUM_EXTINCTION_TRACES

                                # iterate using zip
                                for sd_val, sr_val, sl_val, idx_val in zip(
                                    bifurcation_type_rows["sd"],
                                    bifurcation_type_rows["sr"],
                                    bifurcation_type_rows["sl"],
                                    bifurcation_type_rows["index"],
                                ):
                                    # get index value as integer
                                    index_value = int(idx_val)

                                    # ensure that index value is less than max num of traces, otherwise skip (to avoid out of range errors)
                                    if index_value < maxNumTraces:

                                        # declare row to save in temporal frame
                                        row = {"sd": sd_val, "sr": sr_val, "sl": sl_val, "fixed_value": index}
                                        self.temporal_frame[branch_type][parameter_type][bifurcation_type][index_value].append(row)

                                        # save hopf bifurcation in special structure to process later the bauting points
                                        if bifurcation_type in (BifurcationTypesExtended.HOPF_SUBCRITICAL, BifurcationTypesExtended.HOPF_SUPERCRITICAL):
                                            self.hops_bifurcations[branch_type][parameter_type][index_value][bifurcation_type][index] = row

            # load shape data for current fixed parameter value
            self.shape_data.load_shape_data(index, fixed_parameter_value)

        # calculate bauting points
        self._calculate_bauting_points()

        # now that all files are processed, update the ternary_dataframe with the complete data from self.temporal_frame
        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:
                for bifurcation_type in BifurcationTypesExtended:
                    # get num of traces
                    numTraces = IntegerNumbers.MAX_NUM_TRACES
                    if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                        numTraces = IntegerNumbers.MAX_NUM_EXTINCTION_TRACES
                    for index_value in range(numTraces):
                        data_list = self.temporal_frame[branch_type][parameter_type][bifurcation_type][index_value]
                        if data_list:

                            # Create the dataframe for this specific index
                            dataframe = pd.DataFrame(data_list)

                            # Ensure columns are ordered correctly just in case
                            dataframe = dataframe.reindex(columns=["sd", "sr", "sl", "fixed_value"])

                            # Assign the fully built dataframe to the class attribute
                            self.ternary_dataframe[branch_type][parameter_type][bifurcation_type][index_value] = dataframe
                        else:
                            pass

        # reset bot auxiliar structures to free memory
        self.hops_bifurcations = {}
        self.temporal_frame = {}

        # process shape data
        self.shape_data.process_shape_data()

    def _init_auxiliar_containers(self):

        # create a temporary nested dictionary to hold rows as native Python lists
        for branch_type in BranchTypes:
            self.temporal_frame[branch_type] = {}
            for parameter_type in ParameterTypes:
                self.temporal_frame[branch_type][parameter_type] = {}
                for bifurcation_type in BifurcationTypesExtended:
                    self.temporal_frame[branch_type][parameter_type][bifurcation_type] = {}
                    # get num of traces
                    numTraces = IntegerNumbers.MAX_NUM_TRACES
                    if bifurcation_type == BifurcationTypesExtended.EXTINCT:
                        numTraces = IntegerNumbers.MAX_NUM_EXTINCTION_TRACES
                    for index in range(numTraces):
                        self.temporal_frame[branch_type][parameter_type][bifurcation_type][index] = []

        # init hopf bifurcations
        for branch_type in BranchTypes:
            self.hops_bifurcations[branch_type] = {}
            for parameter_type in ParameterTypes:
                self.hops_bifurcations[branch_type][parameter_type] = {}
                for trace in range(IntegerNumbers.MAX_NUM_TRACES):
                    self.hops_bifurcations[branch_type][parameter_type][trace] = {
                        BifurcationTypesExtended.HOPF_SUBCRITICAL: [None] * IntegerNumbers.MAX_FIXED_PARAMETERS,
                        BifurcationTypesExtended.HOPF_SUPERCRITICAL: [None] * IntegerNumbers.MAX_FIXED_PARAMETERS,
                    }

    def _calculate_bauting_points(self):

        for branch_type in BranchTypes:
            for parameter_type in ParameterTypes:
                for trace, trace_data in self.hops_bifurcations[branch_type][parameter_type].items():

                    # declare variables to save last seen bifurcation type and point (to detect transitions)
                    last_seen_type = None

                    # iterate over all fixed parameters
                    for i in range(IntegerNumbers.MAX_FIXED_PARAMETERS):

                        # get both hopf traces
                        subcritical_trace = trace_data[BifurcationTypesExtended.HOPF_SUBCRITICAL][i]
                        supercritical_trace = trace_data[BifurcationTypesExtended.HOPF_SUPERCRITICAL][i]

                        # check if we found a point subcritical in this step
                        if subcritical_trace is not None:

                            # check if we come from a supercritical
                            if last_seen_type == BifurcationTypesExtended.HOPF_SUPERCRITICAL:

                                # bauting point found. then save the middle point between the last seen supercritical and the current subcritical as a bauting point
                                bautin_pt = {
                                    "sd": subcritical_trace["sd"],
                                    "sr": subcritical_trace["sr"],
                                    "sl": subcritical_trace["sl"],
                                    "fixed_value": subcritical_trace["fixed_value"],
                                }

                                # save in temporal frame
                                self.temporal_frame[branch_type][parameter_type][BifurcationTypesExtended.HOPF_BAUTIN][trace].append(bautin_pt)

                                # update last seen type and point
                            last_seen_type = BifurcationTypesExtended.HOPF_SUBCRITICAL

                        # check if we found a point supercritical in this step
                        if supercritical_trace is not None:

                            # check if we come from a subcritical
                            if last_seen_type == BifurcationTypesExtended.HOPF_SUBCRITICAL:

                                # bauting point found. then save the middle point between the last seen supercritical and the current subcritical as a bauting point
                                bautin_pt = {
                                    "sd": supercritical_trace["sd"],
                                    "sr": supercritical_trace["sr"],
                                    "sl": supercritical_trace["sl"],
                                    "fixed_value": supercritical_trace["fixed_value"],
                                }

                                # save in temporal frame
                                self.temporal_frame[branch_type][parameter_type][BifurcationTypesExtended.HOPF_BAUTIN][trace].append(bautin_pt)

                            # update last seen type and point
                            last_seen_type = BifurcationTypesExtended.HOPF_SUPERCRITICAL
