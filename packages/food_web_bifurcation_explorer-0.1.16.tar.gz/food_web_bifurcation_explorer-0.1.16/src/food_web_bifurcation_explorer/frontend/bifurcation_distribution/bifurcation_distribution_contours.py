from dash import dcc, html

from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers


def build():
    # input number box
    return html.Div(
        dcc.Input(
            id=IDs.TEXTFIELD_BIFURCATION_DISTRIBUTION_CONTOURS,
            type="number",
            min=IntegerNumbers.BIFURCATION_DISTRIBUTIONS_CONTOURS_MIN,
            step=IntegerNumbers.BIFURCATION_DISTRIBUTIONS_CONTOURS_STEPS,
            style={
                "width": "100%",
                "boxSizing": "border-box",
                "height": "36px",
                "borderRadius": "5px",
                "border": "1px solid #ccc",
                "padding": "0 10px",
            },
            value=IntegerNumbers.BIFURCATION_DISTRIBUTIONS_CONTOURS,
        ),
        style={"flex": "1", "marginRight": "10px"},
    )
