﻿from dash import dcc, html

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.check_box import CheckBox
from food_web_bifurcation_explorer.enums.font import Font
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.enums.graph_palette import GraphPalette
from food_web_bifurcation_explorer.enums.symbols import Symbols


# build
def build() -> dcc.Checklist:
    return dcc.Checklist(
        id=IDs.CHECKBOX_BIFURCATION_DISTRIBUTION_LOGARITHMIC,
        options=[
            {
                "label": html.Span(
                    [
                        Labels.BIFURCATION_DISTRIBUTION,
                    ]
                ),
                "value": True,
            }
        ],
        value=[],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
