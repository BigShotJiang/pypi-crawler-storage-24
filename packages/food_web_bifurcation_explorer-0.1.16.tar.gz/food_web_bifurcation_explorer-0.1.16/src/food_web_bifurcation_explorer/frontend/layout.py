from dash import dcc, html

# project imports
from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.frontend.bifurcation_distribution import bifurcation_distribution_bins
from food_web_bifurcation_explorer.frontend.bifurcation_distribution import bifurcation_distribution_contours
from food_web_bifurcation_explorer.frontend.bifurcation_distribution import bifurcation_distribution_logarithmic
from food_web_bifurcation_explorer.frontend.bifurcations_heatmap.hopf.bautin import bautin_alternative_heatmap
from food_web_bifurcation_explorer.frontend.bifurcations_heatmap.hopf.bautin import bautin_empirical_heatmap
from food_web_bifurcation_explorer.frontend.bifurcations_heatmap.hopf.subcritical import subcritical_alternative_heatmap
from food_web_bifurcation_explorer.frontend.bifurcations_heatmap.hopf.subcritical import subcritical_empirical_heatmap
from food_web_bifurcation_explorer.frontend.bifurcations_heatmap.hopf.supercritical import supercritical_alternative_heatmap
from food_web_bifurcation_explorer.frontend.bifurcations_heatmap.hopf.supercritical import supercritical_empirical_heatmap
from food_web_bifurcation_explorer.frontend.bifurcations_heatmap.saddlenode import saddlenode_alternative_heatmap
from food_web_bifurcation_explorer.frontend.bifurcations_heatmap.saddlenode import saddlenode_empirical_heatmap
from food_web_bifurcation_explorer.frontend.bifurcations_heatmap.transcritical import transcritical_alternative_heatmap
from food_web_bifurcation_explorer.frontend.bifurcations_heatmap.transcritical import transcritical_empirical_heatmap
from food_web_bifurcation_explorer.frontend.bifurcations_single.hopf.bautin import bautin_alternative_single
from food_web_bifurcation_explorer.frontend.bifurcations_single.hopf.bautin import bautin_empirical_single
from food_web_bifurcation_explorer.frontend.bifurcations_single.hopf.envelope import envelope_alternative_single
from food_web_bifurcation_explorer.frontend.bifurcations_single.hopf.envelope import envelope_empirical_single
from food_web_bifurcation_explorer.frontend.bifurcations_single.hopf.subcritical import subcritical_alternative_single
from food_web_bifurcation_explorer.frontend.bifurcations_single.hopf.subcritical import subcritical_empirical_single
from food_web_bifurcation_explorer.frontend.bifurcations_single.hopf.supercritical import supercritical_alternative_single
from food_web_bifurcation_explorer.frontend.bifurcations_single.hopf.supercritical import supercritical_empirical_single
from food_web_bifurcation_explorer.frontend.bifurcations_single.saddlenode import saddlenode_alternative_single
from food_web_bifurcation_explorer.frontend.bifurcations_single.saddlenode import saddlenode_empirical_single
from food_web_bifurcation_explorer.frontend.bifurcations_single.transcritical import transcritical_alternative_single
from food_web_bifurcation_explorer.frontend.bifurcations_single.transcritical import transcritical_empirical_single
from food_web_bifurcation_explorer.frontend.biomass_compartment import biomass_compartment_first
from food_web_bifurcation_explorer.frontend.biomass_compartment import biomass_compartment_second
from food_web_bifurcation_explorer.frontend.draw import branch_alternative
from food_web_bifurcation_explorer.frontend.draw import branch_empirical
from food_web_bifurcation_explorer.frontend.draw import lines
from food_web_bifurcation_explorer.frontend.draw import points
from food_web_bifurcation_explorer.frontend.eigenvalue_spectrum import eigenvalue_spectrum_centered_alternative
from food_web_bifurcation_explorer.frontend.eigenvalue_spectrum import eigenvalue_spectrum_centered_empirical
from food_web_bifurcation_explorer.frontend.eigenvalue_spectrum import eigenvalue_spectrum_index_alternative
from food_web_bifurcation_explorer.frontend.eigenvalue_spectrum import eigenvalue_spectrum_index_empirical
from food_web_bifurcation_explorer.frontend.equilibria import area
from food_web_bifurcation_explorer.frontend.equilibria import over_information
from food_web_bifurcation_explorer.frontend.equilibria import stable
from food_web_bifurcation_explorer.frontend.equilibria import unstable
from food_web_bifurcation_explorer.frontend.general import network_selector
from food_web_bifurcation_explorer.frontend.general import resolution_selector
from food_web_bifurcation_explorer.frontend.heatmap_ternary import heatmap_logarithmic
from food_web_bifurcation_explorer.frontend.heatmap_ternary import min_heatmap_value
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.frontend.others import eigenvalue_spectrum_index
from food_web_bifurcation_explorer.frontend.others import extinct
from food_web_bifurcation_explorer.frontend.others import internal_error
from food_web_bifurcation_explorer.frontend.parameters import fixed_parameter_type
from food_web_bifurcation_explorer.frontend.parameters import fixed_parameter_value

# html layout
html_layout = html.Div(
    [
        # title
        html.H1(Labels.MAIN_TITLE, style=Styles.MAIN_TITLE),
        # DIV_CONTROL single
        html.Div(
            [
                # Group 1
                html.Div(
                    [
                        html.Label(Labels.NETWORK_SELECTOR, style=Styles.LABEL),
                        network_selector.build(),
                        html.Label(Labels.ZOOM_LEVEL, style=Styles.LABEL),
                        resolution_selector.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 2
                html.Div(
                    [
                        html.Label(Labels.BIOMASS_COMPARTMENT_FIRST, style=Styles.LABEL),
                        biomass_compartment_first.build(),
                        html.Label(Labels.BIOMASS_COMPARTMENT_SECOND, style=Styles.LABEL),
                        biomass_compartment_second.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 3
                html.Div(
                    [
                        html.Label(Labels.FIXED_PARAMETER_TYPE, style=Styles.LABEL),
                        fixed_parameter_type.build(),
                        html.Label(Labels.FIXED_PARAMETER_VALUE, style=Styles.LABEL),
                        fixed_parameter_value.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 4: Equilibria
                html.Div(
                    [
                        html.Label(Labels.EQUILIBRIA, style=Styles.LABEL),
                        area.build(),
                        stable.build(),
                        unstable.build(),
                        over_information.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 5: saddlenode & transcritical bifurcations
                html.Div(
                    [
                        # saddle node bifurcations
                        html.Label(Labels.SADDLENODE_BIFURCATIONS, style=Styles.LABEL),
                        saddlenode_empirical_single.build(),
                        saddlenode_alternative_single.build(),
                        # transcritical bifurcations
                        html.Label(
                            Labels.TRANSCRITICAL_BIFURCATIONS,
                            style=Styles.LABEL,
                        ),
                        transcritical_empirical_single.build(),
                        transcritical_alternative_single.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 6: hopf bifurcations
                html.Div(
                    [
                        # hopf subcritical bifurcations
                        html.Label(Labels.HOPF_SUBCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        subcritical_empirical_single.build(),
                        subcritical_alternative_single.build(),
                        # hopf supercritical bifurcations
                        html.Label(Labels.HOPF_SUPERCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        supercritical_empirical_single.build(),
                        supercritical_alternative_single.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 7: bautin & envelope
                html.Div(
                    [
                        html.Label(Labels.HOPF_BAUTIN_BIFURCATIONS, style=Styles.LABEL),
                        bautin_empirical_single.build(),
                        bautin_alternative_single.build(),
                        html.Label(Labels.HOPF_ENVELOPES, style=Styles.LABEL),
                        envelope_empirical_single.build(),
                        envelope_alternative_single.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 8 : others
                html.Div(
                    [
                        html.Label(Labels.OTHERS, style=Styles.LABEL),
                        extinct.build(),
                        internal_error.build(),
                        eigenvalue_spectrum_index.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 9: Drawing Options
                html.Div(
                    [
                        html.Label(Labels.DRAWING_OPTIONS, style=Styles.LABEL),
                        branch_empirical.build(),
                        branch_alternative.build(),
                        lines.build(),
                        points.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 10: eigen value spectrum indices
                html.Div(
                    [
                        eigenvalue_spectrum_index_empirical.title(),
                        # subgroup 10: empirical
                        html.Div(
                            [
                                eigenvalue_spectrum_index_empirical.build(),
                                eigenvalue_spectrum_centered_empirical.build(),
                            ],
                            style=Styles.SUBGROUP_EIGENVALUES,
                        ),
                        eigenvalue_spectrum_index_alternative.title(),
                        # subgroup 10: alternative
                        html.Div(
                            [
                                eigenvalue_spectrum_index_alternative.build(),
                                eigenvalue_spectrum_centered_alternative.build(),
                            ],
                            style=Styles.SUBGROUP_EIGENVALUES,
                        ),
                    ],
                    style=Styles.GROUP_EIGENVALUES,
                ),
            ],
            style=Styles.DIV_CONTROL,
        ),
        # DIV_GRAPHS
        html.Div(
            [
                # ternary graph
                html.Div(
                    [
                        dcc.Graph(
                            id=IDs.FIG_TERNARY_SCATTER,
                            figure=glob.figures.ternary_scatter,
                            style=Styles.TERNARY,
                            config={"doubleClick": False, "scrollZoom": False, "responsive": True, "displayModeBar": False},
                        )
                    ],
                    id=IDs.DIV_TERNARY_SCATTER,
                    style=Styles.DIV_GRAPH_TERNARY_SCATTER,
                ),
                # DIV_RIGHT_PANEL
                html.Div(
                    [
                        # DIV_SMALL_ROW
                        html.Div(
                            [
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # bifurcation diagram A
                                        dcc.Graph(
                                            id=IDs.FIG_BIFURCATION_DIAGRAMM_FIRST,
                                            figure=glob.figures.bifurcation_diagram_first,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_BIFURCATION_DIAGRAMM_FIRST,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # eigenvalue_spectrum empirical
                                        dcc.Graph(
                                            id=IDs.FIG_EIGENVALUE_SPECTRUM_EMPIRICAL,
                                            figure=glob.figures.eigenvalue_spectrum_empirical,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_EIGENVALUE_SPECTRUM_EMPIRICAL,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                            ],
                            id=IDs.DIV_ROW_BIFURCATION_DIAGRAMM_FIRST_EIGENVALUE_SPECTRUM_EMPIRICAL,
                            style=Styles.DIV_SMALL_ROW,
                        ),
                        # DIV_SMALL_ROW
                        html.Div(
                            [
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # bifurcation diagram B
                                        dcc.Graph(
                                            id=IDs.FIG_BIFURCATION_DIAGRAMM_SECOND,
                                            figure=glob.figures.bifurcation_diagram_second,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_BIFURCATION_DIAGRAMM_SECOND,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # eigenvalue_spectrum alternative
                                        dcc.Graph(
                                            id=IDs.FIG_EIGENVALUE_SPECTRUM_ALTERNATIVE,
                                            figure=glob.figures.eigenvalue_spectrum_alternative,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_EIGENVALUE_SPECTRUM_ALTERNATIVE,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                            ],
                            id=IDs.DIV_ROW_BIFURCATION_DIAGRAMM_SECOND_EIGENVALUE_SPECTRUM_ALTERNATIVE,
                            style=Styles.DIV_SMALL_ROW,
                        ),
                    ],
                    id=IDs.DIV_FOUR_PLOTS,
                    style=Styles.DIV_FOUR_PLOTS,
                ),
            ],
            id=IDs.DIV_MATRIX_01,
            style=Styles.DIV_GRAPHS,
        ),
        # DIV_CONTROL multiple
        html.Div(
            [
                # Group 1: heatmap ternary options
                html.Div(
                    [
                        html.Label(Labels.MIN_VALUE_CONSIDERED, style=Styles.LABEL),
                        min_heatmap_value.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 2: heatmap ternary options
                html.Div(
                    [
                        html.Label(Labels.BIFURCATION_DISTRIBUTION_BINS, style=Styles.LABEL),
                        bifurcation_distribution_bins.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 3: heatmap ternary options
                html.Div(
                    [
                        html.Label(Labels.BIFURCATION_DISTRIBUTIONS_CONTOURS, style=Styles.LABEL),
                        bifurcation_distribution_contours.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 4: bifurcation distribution options
                html.Div(
                    [
                        html.Label(Labels.LOGARITHMIC_SCALE, style=Styles.LABEL),
                        heatmap_logarithmic.build(),
                        bifurcation_distribution_logarithmic.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 5: saddlenode  bifurcations
                html.Div(
                    [
                        html.Label(Labels.SADDLENODE_BIFURCATIONS, style=Styles.LABEL),
                        saddlenode_empirical_heatmap.build(),
                        saddlenode_alternative_heatmap.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 6: transcritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.TRANSCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        transcritical_empirical_heatmap.build(),
                        transcritical_alternative_heatmap.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 7: hopf subcritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.HOPF_SUBCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        subcritical_empirical_heatmap.build(),
                        subcritical_alternative_heatmap.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 8: hopf supercritical bifurcations
                html.Div(
                    [
                        html.Label(Labels.HOPF_SUPERCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        supercritical_empirical_heatmap.build(),
                        supercritical_alternative_heatmap.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 9: bautin 
                html.Div(
                    [
                        html.Label(Labels.HOPF_BAUTIN_BIFURCATIONS, style=Styles.LABEL),
                        bautin_empirical_heatmap.build(),
                        bautin_alternative_heatmap.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
            ],
            style=Styles.DIV_CONTROL,
        ),
        # DIV_GRAPHS
        html.Div(
            [
                # ternary graph
                html.Div(
                    [
                        dcc.Graph(
                            id=IDs.FIG_TERNARY_HEATMAP,
                            figure=glob.figures.ternary_heatmap,
                            style=Styles.TERNARY,
                            config={"doubleClick": False, "scrollZoom": False, "responsive": True, "displayModeBar": False},
                        )
                    ],
                    id=IDs.DIV_TERNARY_HEATMAP,
                    style=Styles.DIV_GRAPH_TERNARY_HEATMAP,
                ),
                # DIV_GRAPH_PLOT
                html.Div(
                    [
                        # bifuraction distribution sdsr
                        dcc.Graph(
                            id=IDs.FIG_BIFURCATION_DISTRIBUTION_SDSR,
                            figure=glob.figures.bifurcation_distribution_sdsr,
                            style=Styles.PLOT,
                            config={"displayModeBar": False},
                        ),
                    ],
                    id=IDs.DIV_BIFURCATION_DISTRIBUTION_SDSR,
                    style=Styles.DIV_GRAPH_DISTRIBUTION,
                ),
            ],
            id=IDs.DIV_MATRIX_02,
            style=Styles.DIV_GRAPHS,
        ),
        # DIV_GRAPHS
        html.Div(
            [
                # DIV_GRAPH_PLOT
                html.Div(
                    [
                        # bifuraction distribution sdsr
                        dcc.Graph(
                            id=IDs.FIG_BIFURCATION_DISTRIBUTION_SRSL,
                            figure=glob.figures.bifurcation_distribution_srsl,
                            style=Styles.PLOT,
                            config={"displayModeBar": False},
                        ),
                    ],
                    id=IDs.DIV_BIFURCATION_DISTRIBUTION_SRSL,
                    style=Styles.DIV_GRAPH_DISTRIBUTION,
                ),
                # DIV_GRAPH_PLOT
                html.Div(
                    [
                        # bifuraction distribution sdsr
                        dcc.Graph(
                            id=IDs.FIG_BIFURCATION_DISTRIBUTION_SLSD,
                            figure=glob.figures.bifurcation_distribution_slsd,
                            style=Styles.PLOT,
                            config={"displayModeBar": False},
                        ),
                    ],
                    id=IDs.DIV_BIFURCATION_DISTRIBUTION_SLSD,
                    style=Styles.DIV_GRAPH_DISTRIBUTION,
                ),
            ],
            id=IDs.DIV_MATRIX_03,
            style=Styles.DIV_GRAPHS,
        ),
        # error messages
        html.Div(
            id=IDs.ERROR_MESSAGE,
            style={"color": "red", "fontWeight": "bold", "textAlign": "center", "padding": "10px"},
        ),
    ]
)
