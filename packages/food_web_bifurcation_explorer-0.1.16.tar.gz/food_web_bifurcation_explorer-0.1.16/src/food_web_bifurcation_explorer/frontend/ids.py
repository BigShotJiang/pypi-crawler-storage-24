from enum import Enum, unique


@unique
class IDs(str, Enum):
    """Enumeration for frontend IDs."""

    # control
    DROPDOWN_COMPARTMENT_FIRST = "dropdown-compartment-first"
    DROPDOWN_COMPARTMENT_SECOND = "dropdown-compartment-second"
    DROPDOWN_NETWORK = "dropdown-network"
    DROPDOWN_PARAMETER_TYPE = "parameter-type"
    DROPDOWN_SIZE = "dropdown-size"
    TEXTFIELD_FIXED_PARAMETER_VALUE = "textfield-fixed-parameter-value"
    # eigen values spectrum
    TEXTFIELD_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE = "textfield-checkbox-eigenvalue-spectrum-index-alternative-input"
    TEXTFIELD_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL = "textfield-eigenvalue-spectrum-index-empirical-input"
    # branches
    CHECKBOX_EQUILIBRIA_AREA = "checkbox-equilibria-area"
    CHECKBOX_EQUILIBRIA_OVERINFORMATION = "checkbox-equilibria-overinformation"
    CHECKBOX_EQUILIBRIA_STABLE = "checkbox-equilibria-stable"
    CHECKBOX_EQUILIBRIA_UNSTABLE = "checkbox-equilibria-unstable"
    # bifurcations for single ternaries
    CHECKBOX_SINGLE_BIFURCATIONS_HOPF_BAUTIN_ALTERNATIVE = "checkbox-single-bifurcations-hopf-bautin-alternative"
    CHECKBOX_SINGLE_BIFURCATIONS_HOPF_BAUTIN_EMPIRICAL = "checkbox-single-bifurcations-hopf-bautin-empirical"
    CHECKBOX_SINGLE_BIFURCATIONS_HOPF_ENVELOPE_ALTERNATIVE = "checkbox-single-bifurcations-hopf-envelope-alternative"
    CHECKBOX_SINGLE_BIFURCATIONS_HOPF_ENVELOPE_EMPIRICAL = "checkbox-single-bifurcations-hopf-envelope-empirical"
    CHECKBOX_SINGLE_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE = "checkbox-single-bifurcations-hopf-subcritical-alternative"
    CHECKBOX_SINGLE_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL = "checkbox-single-bifurcations-hopf-subcritical-empirical"
    CHECKBOX_SINGLE_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE = "checkbox-single-bifurcations-hopf-supercritical-alternative"
    CHECKBOX_SINGLE_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL = "checkbox-single-bifurcations-hopf-supercritical-empirical"
    CHECKBOX_SINGLE_BIFURCATIONS_SADDLENODE_ALTERNATIVE = "checkbox-single-bifurcations-saddlenode-alternative"
    CHECKBOX_SINGLE_BIFURCATIONS_SADDLENODE_EMPIRICAL = "checkbox-single-bifurcations-saddlenode-empirical"
    CHECKBOX_SINGLE_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE = "checkbox-single-bifurcations-transcritical-alternative"
    CHECKBOX_SINGLE_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL = "checkbox-single-bifurcations-transcritical-empirical"
    # bifurcations for multiple ternaries
    CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_BAUTIN_ALTERNATIVE = "checkbox-multiple-bifurcations-hopf-bautin-alternative"
    CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_BAUTIN_EMPIRICAL = "checkbox-multiple-bifurcations-hopf-bautin-empirical"
    CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE = "checkbox-multiple-bifurcations-hopf-subcritical-alternative"
    CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL = "checkbox-multiple-bifurcations-hopf-subcritical-empirical"
    CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE = "checkbox-multiple-bifurcations-hopf-supercritical-alternative"
    CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL = "checkbox-multiple-bifurcations-hopf-supercritical-empirical"
    CHECKBOX_MULTIPLE_BIFURCATIONS_SADDLENODE_ALTERNATIVE = "checkbox-multiple-bifurcations-saddlenode-alternative"
    CHECKBOX_MULTIPLE_BIFURCATIONS_SADDLENODE_EMPIRICAL = "checkbox-multiple-bifurcations-saddlenode-empirical"
    CHECKBOX_MULTIPLE_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE = "checkbox-multiple-bifurcations-transcritical-alternative"
    CHECKBOX_MULTIPLE_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL = "checkbox-multiple-bifurcations-transcritical-empirical"
    # others
    CHECKBOX_OTHERS_EIGENVALUE_SPECTRUM_INDEX = "checkbox-others-eigenvalue-spectrum-index"
    CHECKBOX_OTHERS_EXTINCT = "checkbox-others-extinct"
    CHECKBOX_OTHERS_INTERNALERROR = "checkbox-others-internalerror"
    # draw options
    CHECKBOX_DRAW_BRANCH_ALTERNATIVE = "checkbox-draw-branch-alternative"
    CHECKBOX_DRAW_BRANCH_EMPIRICAL = "checkbox-draw-branch-empirical"
    CHECKBOX_DRAW_LINES = "checkbox-draw-lines"
    CHECKBOX_DRAW_POINTS = "checkbox-draw-points"
    # eigen values centering
    CHECKBOX_EIGENVALUE_SPECTRUM_CENTERED_ALTERNATIVE = "eigenvalue-spectrum-centered-alternative"
    CHECKBOX_EIGENVALUE_SPECTRUM_CENTERED_EMPIRICAL = "eigenvalue-spectrum-centered-empirical"
    # graphs
    FIG_BIFURCATION_DIAGRAMM_FIRST = "figure-bifurcation-diagram-first"
    FIG_BIFURCATION_DIAGRAMM_SECOND = "figure-bifurcation-diagram-second"
    FIG_EIGENVALUE_SPECTRUM_ALTERNATIVE = "figure-eigenvalue-spectrum-alternative"
    FIG_EIGENVALUE_SPECTRUM_EMPIRICAL = "figure-eigenvalue-spectrum-empirical"
    FIG_TERNARY_SCATTER = "figure-ternary-scatter"
    FIG_TERNARY_HEATMAP = "figure-ternary-heatmap"
    FIG_BIFURCATION_DISTRIBUTION_SDSR = "figure-bifurcation-distribution-sdsr"
    FIG_BIFURCATION_DISTRIBUTION_SRSL = "figure-bifurcation-distribution-srsl"
    FIG_BIFURCATION_DISTRIBUTION_SLSD = "figure-bifurcation-distribution-slsd"
    FIG_BIFURCATION_DISTRIBUTION_3D = "figure-bifurcation-distribution-3d"
    # divs
    DIV_BIFURCATION_DIAGRAMM_FIRST = "div-bifurcation-diagramm-first"
    DIV_BIFURCATION_DIAGRAMM_SECOND = "div-bifuraction-diagramm-second"
    DIV_BIFURCATION_DISTRIBUTION_SDSR = "div-bifurcation-distribution-sdsr"
    DIV_BIFURCATION_DISTRIBUTION_SLSD = "div-bifurcation-distribution-slsd"
    DIV_BIFURCATION_DISTRIBUTION_SRSL = "div-bifurcation-distribution-srsl"
    DIV_EIGENVALUE_SPECTRUM_ALTERNATIVE = "div-eigenvalue-spectrum-alterantive"
    DIV_EIGENVALUE_SPECTRUM_EMPIRICAL = "div-eigenvalue-sepectrum-empirical"
    DIV_MATRIX_01 = "div-matrix-01"
    DIV_MATRIX_02 = "div-matrix-02"
    DIV_MATRIX_03 = "div-matrix-03"
    DIV_FOUR_PLOTS = "div-right-panel-01"
    DIV_ROW_BIFURCATION_DIAGRAMM_FIRST_EIGENVALUE_SPECTRUM_EMPIRICAL = "div-row-bifurcation-first-spectrum-empirical"
    DIV_ROW_BIFURCATION_DIAGRAMM_SECOND_EIGENVALUE_SPECTRUM_ALTERNATIVE = "div-row-bifurcation-second-spectrum-alternative"
    DIV_TERNARY_HEATMAP = "div-ternary-heatmap"
    DIV_TERNARY_SCATTER = "div-ternary-scatter"
    # heatmap
    TEXTFIELD_HEATMAP_MIN_VALUE = "textfield-heatmap-min-value"
    # bifurcation distributions
    TEXTFIELD_BIFURCATION_DISTRIBUTION_BINS = "textfield-bifurcation-distribution-bins"
    TEXTFIELD_BIFURCATION_DISTRIBUTION_CONTOURS = "textfield-bifurcation-distribution-contours"
    # logarithmic scales
    CHECKBOX_HEATMAP_LOGARITHMIC = "checkbox-heatmap-logarithmic"
    CHECKBOX_BIFURCATION_DISTRIBUTION_LOGARITHMIC = "checkbox-bifurcation-distribution-logarithmic"
    # other
    ERROR_MESSAGE = "error-message"
