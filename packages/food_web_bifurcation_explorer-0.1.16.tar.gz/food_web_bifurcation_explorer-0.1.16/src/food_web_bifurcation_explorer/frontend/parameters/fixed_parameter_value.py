"""Frontend component for fixed parameter value input."""

from dash import dcc, html

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.numbers.float_numbers import FloatNumbers
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.styles import Styles


def build():
    # input box
    return html.Div(
        dcc.Input(
            id=IDs.TEXTFIELD_FIXED_PARAMETER_VALUE,
            type="number",
            min=FloatNumbers.FIXED_PARAMETER_MIN,
            max=FloatNumbers.FIXED_PARAMETER_MAX,
            step=FloatNumbers.FIXED_PARAMETER_STEP,
            style={
                "width": "100%",
                "boxSizing": "border-box",
                "height": "36px",
                "borderRadius": "5px",
                "border": "1px solid #ccc",
                "padding": "0 10px",
            },
            value=0.4,  # default value
        ),
        style={"flex": "1", "marginRight": "10px"},
    )
