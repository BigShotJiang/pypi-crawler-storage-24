from dash import Input, Output, Patch, callback
import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.bifurcation_diagram_types import BifurcationDiagramTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.graph.bifurcation_diagram.update import update_bifurcation_diagram
from food_web_bifurcation_explorer.graph.eigenvalue_spectrum.update import update_eigenvalue_spectrum
from food_web_bifurcation_explorer.graph.ternary.update import update_ternary_data


# callback to update graphs
@callback(
    # outputs
    [
        Output(IDs.FIG_TERNARY_SCATTER, "figure"),
        Output(IDs.FIG_BIFURCATION_DIAGRAMM_FIRST, "figure"),
        Output(IDs.FIG_BIFURCATION_DIAGRAMM_SECOND, "figure"),
        Output(IDs.FIG_EIGENVALUE_SPECTRUM_EMPIRICAL, "figure"),
        Output(IDs.FIG_EIGENVALUE_SPECTRUM_ALTERNATIVE, "figure"),
        Output(IDs.ERROR_MESSAGE, "children"),
    ],
    # inputs
    [
        # general
        Input(IDs.DROPDOWN_NETWORK, "value"),
        Input(IDs.DROPDOWN_PARAMETER_TYPE, "value"),
        Input(IDs.DROPDOWN_COMPARTMENT_FIRST, "value"),
        Input(IDs.DROPDOWN_COMPARTMENT_SECOND, "value"),
        Input(IDs.TEXTFIELD_FIXED_PARAMETER_VALUE, "value"),
        # branches
        Input(IDs.CHECKBOX_EQUILIBRIA_AREA, "value"),
        Input(IDs.CHECKBOX_EQUILIBRIA_STABLE, "value"),
        Input(IDs.CHECKBOX_EQUILIBRIA_UNSTABLE, "value"),
        Input(IDs.CHECKBOX_EQUILIBRIA_OVERINFORMATION, "value"),
        # bifurcations
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_SADDLENODE_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_SADDLENODE_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_HOPF_BAUTIN_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_HOPF_BAUTIN_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_HOPF_ENVELOPE_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_SINGLE_BIFURCATIONS_HOPF_ENVELOPE_ALTERNATIVE, "value"),
        # others
        Input(IDs.CHECKBOX_OTHERS_EXTINCT, "value"),
        Input(IDs.CHECKBOX_OTHERS_INTERNALERROR, "value"),
        Input(IDs.CHECKBOX_OTHERS_EIGENVALUE_SPECTRUM_INDEX, "value"),
        # draw options
        Input(IDs.CHECKBOX_DRAW_BRANCH_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_DRAW_BRANCH_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_DRAW_LINES, "value"),
        Input(IDs.CHECKBOX_DRAW_POINTS, "value"),
        # eigen values spectrum
        Input(IDs.TEXTFIELD_EIGENVALUE_SPECTRUM_INDEX_EMPIRICAL, "value"),
        Input(IDs.TEXTFIELD_EIGENVALUE_SPECTRUM_INDEX_ALTERNATIVE, "value"),
        # eigen values centering
        Input(IDs.CHECKBOX_EIGENVALUE_SPECTRUM_CENTERED_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_EIGENVALUE_SPECTRUM_CENTERED_ALTERNATIVE, "value"),
    ],
)
# update scatter graph
def update_scatter_graphs(
    _network: str,
    _parameter_type: str,
    _compartment_a: str,
    _compartment_b: str,
    _fixed_parameter_value: float,
    # equilibria
    equilibria_area: bool,
    equilibria_stable: bool,
    equilibria_unstable: bool,
    equilibria_over_information: bool,
    # bifurcations
    bifurcations_saddlenode_empirical: bool,
    bifurcations_saddlenode_alternative: bool,
    bifurcations_transcritical_empirical: bool,
    bifurcations_transcritical_alternative: bool,
    bifurcations_hopf_subcritical_empirical: bool,
    bifurcations_hopf_subcritical_alternative: bool,
    bifurcations_hopf_supercritical_empirical: bool,
    bifurcations_hopf_supercritical_alternative: bool,
    bifurcations_hopf_bautin_empirical: bool,
    bifurcations_hopf_bautin_alternative: bool,
    bifurcations_hopf_envelope_empirical: bool,
    bifurcations_hopf_envelope_alternative: bool,
    # others
    others_extinct: bool,
    others_internal_error: bool,
    others_eigenvalue_spectrum_index: bool,
    # drawing options
    draw_branch_empirical: bool,
    draw_branch_alternative: bool,
    draw_lines: bool,
    draw_points: bool,
    # eigenvalue spectrum
    _eigenvalue_spectrum_index_empirical: float,
    _eigenvalue_spectrum_index_alternative: float,
    # eigenvalue spectrum (centering)
    eigenvalue_spectrum_centered_empirical: bool,
    eigenvalue_spectrum_centered_alternative: bool,
) -> tuple[Patch, go.Figure, go.Figure, go.Figure, go.Figure, str]:
    # update drawing config
    glob.config.drawing_options_scatter.update_flags(
        equilibria_area,
        equilibria_stable,
        equilibria_unstable,
        equilibria_over_information,
        bifurcations_saddlenode_empirical,
        bifurcations_saddlenode_alternative,
        bifurcations_transcritical_empirical,
        bifurcations_transcritical_alternative,
        bifurcations_hopf_subcritical_empirical,
        bifurcations_hopf_subcritical_alternative,
        bifurcations_hopf_supercritical_empirical,
        bifurcations_hopf_supercritical_alternative,
        bifurcations_hopf_bautin_empirical,
        bifurcations_hopf_bautin_alternative,
        bifurcations_hopf_envelope_empirical,
        bifurcations_hopf_envelope_alternative,
        others_extinct,
        others_internal_error,
        others_eigenvalue_spectrum_index,
        draw_branch_empirical,
        draw_branch_alternative,
        draw_lines,
        draw_points,
        eigenvalue_spectrum_centered_empirical,
        eigenvalue_spectrum_centered_alternative,
    )
    # update ternary
    glob.figures.ternary_scatter = update_ternary_data(glob.figures.ternary_scatter)
    # update both bifurcation diagrams
    glob.figures.bifurcation_diagram_first = update_bifurcation_diagram(glob.figures.bifurcation_diagram_first, BifurcationDiagramTypes.FIRST)
    glob.figures.bifurcation_diagram_second = update_bifurcation_diagram(glob.figures.bifurcation_diagram_second, BifurcationDiagramTypes.SECOND)
    # update both bifurcation diagrams
    glob.figures.eigenvalue_spectrum_empirical = update_eigenvalue_spectrum(glob.figures.eigenvalue_spectrum_empirical, BranchTypes.EMPIRICAL)
    glob.figures.eigenvalue_spectrum_alternative = update_eigenvalue_spectrum(glob.figures.eigenvalue_spectrum_alternative, BranchTypes.ALTERNATIVE)
    # return both figure and the empty error message
    return (
        glob.figures.ternary_scatter,
        glob.figures.bifurcation_diagram_first,
        glob.figures.bifurcation_diagram_second,
        glob.figures.eigenvalue_spectrum_empirical,
        glob.figures.eigenvalue_spectrum_alternative,
        "",
    )
