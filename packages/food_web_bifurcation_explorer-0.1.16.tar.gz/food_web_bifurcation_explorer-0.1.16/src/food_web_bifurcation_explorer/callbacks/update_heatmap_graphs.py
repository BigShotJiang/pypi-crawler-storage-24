from dash import Input, Output, Patch, callback
import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.bifurcation_distribution_types import BifurcationDistributionTypes
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.graph.ternary.update import update_ternary_data
from food_web_bifurcation_explorer.graph.bifurcation_distribution.update import update_bifurcation_distribution


# callback to update graphs
@callback(
    # outputs
    [
        Output(IDs.FIG_TERNARY_HEATMAP, "figure"),
        Output(IDs.FIG_BIFURCATION_DISTRIBUTION_SDSR, "figure"),
        Output(IDs.FIG_BIFURCATION_DISTRIBUTION_SRSL, "figure"),
        Output(IDs.FIG_BIFURCATION_DISTRIBUTION_SLSD, "figure"),
    ],
    # inputs
    [
        # general options
        Input(IDs.TEXTFIELD_HEATMAP_MIN_VALUE, "value"),
        Input(IDs.TEXTFIELD_BIFURCATION_DISTRIBUTION_BINS, "value"),
        Input(IDs.TEXTFIELD_BIFURCATION_DISTRIBUTION_CONTOURS, "value"),
        # logarithmic options
        Input(IDs.CHECKBOX_HEATMAP_LOGARITHMIC, "value"),
        Input(IDs.CHECKBOX_BIFURCATION_DISTRIBUTION_LOGARITHMIC, "value"),
        # bifurcations
        Input(IDs.CHECKBOX_MULTIPLE_BIFURCATIONS_SADDLENODE_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_MULTIPLE_BIFURCATIONS_SADDLENODE_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_MULTIPLE_BIFURCATIONS_TRANSCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_MULTIPLE_BIFURCATIONS_TRANSCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_SUBCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_SUBCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_SUPERCRITICAL_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_SUPERCRITICAL_ALTERNATIVE, "value"),
        Input(IDs.CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_BAUTIN_EMPIRICAL, "value"),
        Input(IDs.CHECKBOX_MULTIPLE_BIFURCATIONS_HOPF_BAUTIN_ALTERNATIVE, "value"),
    ],
)
# update heatmap graph
def update_heatmap_graphs(
    heatmap_min_value: int,
    bifurcation_distribution_bins: int,
    bifurcation_distribution_contours: int,
    heatmap_logarithmic: bool,
    bifurcation_distribution_logarithmic: bool,
    bifurcations_saddlenode_empirical: bool,
    bifurcations_saddlenode_alternative: bool,
    bifurcations_transcritical_empirical: bool,
    bifurcations_transcritical_alternative: bool,
    bifurcations_hopf_subcritical_empirical: bool,
    bifurcations_hopf_subcritical_alternative: bool,
    bifurcations_hopf_supercritical_empirical: bool,
    bifurcations_hopf_supercritical_alternative: bool,
    bifurcations_hopf_bautin_empirical: bool,
    bifurcations_hopf_bautin_alternative: bool,
) -> tuple[Patch, go.Figure, go.Figure, go.Figure, go.Figure, str]:
    # update hetmap options
    glob.config.heatmap_min_value = heatmap_min_value
    glob.config.bifurcation_distribution_bins = bifurcation_distribution_bins
    glob.config.bifurcation_distribution_contours = bifurcation_distribution_contours
    glob.config.heatmap_logarithmic = heatmap_logarithmic
    glob.config.bifurcation_distribution_logarithmic = bifurcation_distribution_logarithmic
    # update only bifurcation flags
    glob.config.drawing_options_heatmap.update_bifurcation_flags(
        bifurcations_saddlenode_empirical,
        bifurcations_saddlenode_alternative,
        bifurcations_transcritical_empirical,
        bifurcations_transcritical_alternative,
        bifurcations_hopf_subcritical_empirical,
        bifurcations_hopf_subcritical_alternative,
        bifurcations_hopf_supercritical_empirical,
        bifurcations_hopf_supercritical_alternative,
        bifurcations_hopf_bautin_empirical,
        bifurcations_hopf_bautin_alternative,
    )
    # update ternary
    glob.figures.ternary_scatter = update_ternary_data(glob.figures.ternary_heatmap)
    # update bifurcation distributinos
    glob.figures.bifurcation_distribution_sdsr = update_bifurcation_distribution(glob.figures.bifurcation_distribution_sdsr, BifurcationDistributionTypes.SD_SR)
    glob.figures.bifurcation_distribution_srsl = update_bifurcation_distribution(glob.figures.bifurcation_distribution_srsl, BifurcationDistributionTypes.SR_SL)
    glob.figures.bifurcation_distribution_slsd = update_bifurcation_distribution(glob.figures.bifurcation_distribution_slsd, BifurcationDistributionTypes.SL_SD)
    # return both figure and the empty error message
    return (
        glob.figures.ternary_heatmap,
        glob.figures.bifurcation_distribution_sdsr,
        glob.figures.bifurcation_distribution_srsl,
        glob.figures.bifurcation_distribution_slsd,
    )
