from dash import Input, Output, callback

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.ternary_types import TernaryTypes
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.graph.ternary.build import build_ternary


# callback to select network
@callback(
    # outputs
    Output(IDs.DROPDOWN_NETWORK, "value"),
    Output(IDs.DROPDOWN_COMPARTMENT_FIRST, "options"),
    Output(IDs.DROPDOWN_COMPARTMENT_FIRST, "value"),
    Output(IDs.DROPDOWN_COMPARTMENT_SECOND, "options"),
    Output(IDs.DROPDOWN_COMPARTMENT_SECOND, "value"),
    # inputs
    Input(IDs.DROPDOWN_NETWORK, "value"),
    Input(IDs.DROPDOWN_COMPARTMENT_FIRST, "value"),
    Input(IDs.DROPDOWN_COMPARTMENT_SECOND, "value"),
)

# select network and compartments
def select_network_compartments(network: str, compartment_value_a: str, compartment_value_b: str):
    # check if update network
    if glob.config.network != network:
        # update network
        glob.config.update_network(network)
        # reset ternary
        glob.figures.ternary_scatter = build_ternary(TernaryTypes.SCATTER)
        # load ternary data
        glob.plot_data.load_ternary_data()
        # mark ternary for redraw
        glob.config.drawing_options_scatter.redraw_ternary.redraw_all()
    # update compartments
    glob.config.update_comparment_first(compartment_value_a)
    glob.config.update_comparment_second(compartment_value_b)
    # get the list of new compartments
    new_compartments = glob.config.get_current_compartments()
    # update branch datas
    glob.plot_data.load_branch_datas()
    # redraw bifurcation diagrams
    glob.config.drawing_options_scatter.redraw_bifurcation_diagrams_first.redraw_all()
    glob.config.drawing_options_scatter.redraw_bifurcation_diagrams_second.redraw_all()
    # return network and new list of compartments
    return (
        network,
        new_compartments,
        glob.config.compartment_first,
        new_compartments,
        glob.config.compartment_second,
    )
