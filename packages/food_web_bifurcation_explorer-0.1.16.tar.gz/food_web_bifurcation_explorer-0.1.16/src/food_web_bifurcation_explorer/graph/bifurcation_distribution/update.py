import plotly.graph_objects as go
import pandas as pd

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.common.exceptions import BifurcationDistributionTypeError
from food_web_bifurcation_explorer.enums.types.bifurcation_distribution_types import BifurcationDistributionTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


def update_bifurcation_distribution(fig: go.Figure, plot_type: BifurcationDistributionTypes) -> go.Figure:
    # extract parameters depending of the plot type
    if plot_type == BifurcationDistributionTypes.SD_SR:
        paramA = ParameterTypes.DONOR
        paramB = ParameterTypes.RECIPIENT
    elif plot_type == BifurcationDistributionTypes.SR_SL:
        paramA = ParameterTypes.RECIPIENT
        paramB = ParameterTypes.LOTKAVOLTERRA
    elif plot_type == BifurcationDistributionTypes.SL_SD:
        paramA = ParameterTypes.LOTKAVOLTERRA
        paramB = ParameterTypes.DONOR
    else:
        raise BifurcationDistributionTypeError(f"Invalid bifurcation distribution type: {plot_type}")
    # clear previous data
    fig.data = []
    # get enabled bifurcations
    enabled_bifurcations = glob.config.drawing_options_heatmap.get_enabled_bifurcations()
    # merge frames
    dataframes = [
        glob.general_bifurcation_data.data[BranchTypes.EMPIRICAL][b]
        for b in enabled_bifurcations[0]
    ] + [
        glob.general_bifurcation_data.data[BranchTypes.ALTERNATIVE][b]
        for b in enabled_bifurcations[1]
    ]
    # concatenate frames 
    if dataframes:
        merged = pd.concat(dataframes, ignore_index=True)
        # save merged debug
        with pd.option_context('display.max_rows', None, 'display.max_columns', None):
            merged.to_csv("merged_debug.csv", index=False)
        # add corners
        corners = pd.DataFrame({
            paramA.value: [0, 1],
            paramB.value: [0, 1],
        })
        merged = pd.concat([merged, corners], ignore_index=True)
        #print(merged)
        fig.add_trace(go.Histogram2dContour(
            x=merged[paramA.value],
            y=merged[paramB.value],
            colorscale="Blues",
            contours_coloring="heatmap",
            nbinsx=glob.config.bifurcation_distribution_bins,
            nbinsy=glob.config.bifurcation_distribution_bins,
            ncontours=glob.config.bifurcation_distribution_contours,
            showscale=True,
        ))

    # declare axis ticks
    axis_ticks = [round(i * 0.1, 1) for i in range(11)]

    # set x axes
    fig.update_xaxes(
        title_text=f"Parameter {paramA.value}",
        tickvals=axis_ticks,
        range=[0, 1],
        constrain="domain"
    )
    # set y axes
    fig.update_yaxes(
        title_text=f"Parameter {paramB.value}",
        tickvals=axis_ticks,
        range=[0, 1],
        scaleanchor="x",
        scaleratio=1
    )
    # final layout
    fig.update_layout(
        title_text=f"Bifurcation density ({paramA.value} vs {paramB.value})",
        showlegend=False,
        template="plotly_white",
    )
    return fig