
import plotly.graph_objects as go

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.bifurcation_distribution_types import BifurcationDistributionTypes


def build_bifurcation_distribution(bifurcation_distribution_type: BifurcationDistributionTypes):

    # declare general figure
    fig = go.Figure()
    
    # update layout
    fig.update_layout(
        margin={"l": 0, "r": 0, "t": 50, "b": 0},
        showlegend=True,
        uirevision="bifurcation_distribution_" + bifurcation_distribution_type.value,
        # set sizes
        width=glob.config.resolution * 2,
        height=glob.config.resolution * 2,
    )
    return fig
