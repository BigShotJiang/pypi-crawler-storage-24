# vw-client

Python client for the North America myVW flow, including login, token/session caching, S-PIN challenge handling, and typed DTO responses for common vehicle endpoints.