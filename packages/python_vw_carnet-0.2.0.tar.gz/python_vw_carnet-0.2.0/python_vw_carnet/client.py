from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qs, urljoin, urlparse

import requests

from .models import (
    BatteryStatus,
    ChargingStatus,
    EVSummaryRequest,
    EVSummaryResponse,
    GarageRequest,
    GarageResponse,
    GarageUser,
    GarageVehicle,
    GarageVehicleRelationship,
    RefreshTokenRequest,
    SpinChallengeResponse,
    TokenExchangeRequest,
    TokenResponse,
    VehicleActivation,
    VehicleCoordinate,
    VehicleDoorStatus,
    VehicleLocationRequest,
    VehicleLocationResponse,
    VehicleRolesAndRights,
    VehicleSessionRequest,
    VehicleSessionResponse,
    VehicleStatusRequest,
    VehicleStatusResponse,
    serialize_for_json,
)


BASE_URL = "https://b-h-s.spr.us00.p.con-veh.net"
IDENTITY_URL = "https://identity.na.vwgroup.io"
ANDROID_CLIENT_ID = "59992128-69a9-42c3-8621-7942041ba824_MYVW_ANDROID"
REDIRECT_URI = "kombi:///login"
APP_VERSION = "2026.3.11-8768"
DEVICE_MODEL = "SM-G975U"
DEVICE_OS = "30"
DEFAULT_LOCALE = "en-US"
DEFAULT_COUNTRY = "US"
USER_AGENT_APP = "okhttp/5.3.2"
USER_AGENT_WEB = (
    "Mozilla/5.0 (Linux; Android 11; SM-G975U Build/RP1A.200720.012; wv) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 "
    "Chrome/83.0.4103.106 Mobile Safari/537.36"
)
WINDOW_IDK_PATTERN = re.compile(r"window\._IDK\s*=\s*\{", re.IGNORECASE)


class VWClientError(RuntimeError):
    pass


class AuthenticationError(VWClientError):
    pass


class VehicleSessionError(VWClientError):
    pass


def calc_spin_hash(challenge: str, pin: str) -> str:
    payload = f"{challenge}.{pin}".encode("utf-8")
    return hashlib.sha512(payload).hexdigest()


@dataclass
class SessionState:
    app_uuid: str = field(default_factory=lambda: str(uuid.uuid4()))
    mobile_session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    locale: str = DEFAULT_LOCALE
    country: str = DEFAULT_COUNTRY
    access_token: str | None = None
    access_token_expires_at: float = 0.0
    id_token: str | None = None
    id_token_expires_at: float = 0.0
    refresh_token: str | None = None
    refresh_token_expires_at: float = 0.0
    token_type: str = "Bearer"
    user_id: str | None = None
    email: str | None = None
    vehicle_id: str | None = None
    vin: str | None = None
    tsp: str | None = None
    vehicle_token: str | None = None
    vehicle_token_expires_at: float = 0.0
    vehicle_session_payload: VehicleSessionResponse | None = None
    garage: GarageResponse | None = None

    def to_json(self) -> dict[str, Any]:
        return serialize_for_json(self.__dict__.copy())

    @classmethod
    def from_json(cls, payload: dict[str, Any]) -> "SessionState":
        state = cls()
        for key, value in payload.items():
            if hasattr(state, key):
                if key == "garage" and isinstance(value, dict):
                    value = GarageResponse.from_dict(value)
                if key == "vehicle_session_payload" and isinstance(value, dict):
                    value = VehicleSessionResponse.from_dict(value)
                setattr(state, key, value)
        return state


class VWClient:
    def __init__(
        self,
        email: str,
        password: str,
        spin: str,
        *,
        session_path: str | os.PathLike[str] | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.email = email
        self.password = password
        self.spin = spin
        self.session_path = Path(session_path or Path.home() / ".vw_client" / "session.json")
        self.timeout = timeout
        self.session = requests.Session()
        self.state = self._load_state()

        if self.state.email and self.state.email != email:
            self.state = SessionState()
        self.state.email = email

    def login(self, *, force: bool = False, require_vehicle_token: bool = False) -> SessionState:
        if not force and self._token_valid(self.state.access_token, self.state.access_token_expires_at):
            if require_vehicle_token:
                self._ensure_vehicle_token()
            return self.state

        if not force and self._try_refresh_tokens():
            if require_vehicle_token:
                self._ensure_vehicle_token()
            return self.state

        self._perform_full_login()
        if require_vehicle_token:
            self._ensure_vehicle_token()
        return self.state

    def get_garage(self, request: GarageRequest | None = None, *, force: bool = False) -> GarageResponse:
        self.login(force=False, require_vehicle_token=False)
        if self.state.garage and not force:
            return self.state.garage

        request = request or GarageRequest(id_token=self._require(self.state.id_token, "Missing id token"))
        return self._fetch_garage(request)

    def get_vehicle_status(
        self,
        request: VehicleStatusRequest | None = None,
        *,
        vehicle_id: str | None = None,
        force: bool = False,
    ) -> VehicleStatusResponse:
        request = request or VehicleStatusRequest(vehicle_id=vehicle_id or self._resolve_vehicle_id())
        token = self._get_vehicle_token(force=force)
        response = self._request(
            "GET",
            f"{BASE_URL}/rvs/v1/vehicle/{request.vehicle_id}",
            token=token,
            user_id_header=self._require(self.state.user_id, "Missing user id"),
        )
        return self._parse_vehicle_status_response(self._decode_json(response))

    def get_vehicle_location(
        self,
        request: VehicleLocationRequest | None = None,
        *,
        vehicle_id: str | None = None,
        force: bool = False,
    ) -> VehicleLocationResponse:
        request = request or VehicleLocationRequest(vehicle_id=vehicle_id or self._resolve_vehicle_id())
        token = self._get_vehicle_token(force=force)
        response = self._request(
            "GET",
            f"{BASE_URL}/rvs/v1/location/vehicle/{request.vehicle_id}",
            token=token,
            user_id_header=self._require(self.state.user_id, "Missing user id"),
        )
        return self._parse_vehicle_location_response(self._decode_json(response))

    def get_ev_summary(
        self,
        request: EVSummaryRequest | None = None,
        vehicle_id: str | None = None,
        *,
        temp_unit: str = "f",
        force: bool = False,
    ) -> EVSummaryResponse:
        request = request or EVSummaryRequest(
            user_id=self._require(self.state.user_id, "Missing user id"),
            vehicle_id=vehicle_id or self._resolve_vehicle_id(),
            temp_unit=temp_unit,
        )
        token = self._get_vehicle_token(force=force)
        response = self._request(
            "GET",
            f"{BASE_URL}/ev/v1/user/{request.user_id}/vehicle/{request.vehicle_id}/summary",
            params={"tempUnit": request.temp_unit},
            token=token,
            user_id_header=self._require(self.state.user_id, "Missing user id"),
        )
        return self._parse_ev_summary_response(self._decode_json(response))

    def close(self) -> None:
        self.session.close()

    def _perform_full_login(self) -> None:
        self.state.mobile_session_id = str(uuid.uuid4())
        self.state.app_uuid = self.state.app_uuid or str(uuid.uuid4())

        code_verifier = secrets.token_hex(32)
        code_challenge = self._pkce_challenge(code_verifier)
        mobile_state = str(uuid.uuid4())

        start_response = self.session.get(
            f"{BASE_URL}/oidc/v1/authorize",
            params={
                "client_id": ANDROID_CLIENT_ID,
                "scope": "openid",
                "response_type": "code",
                "prompt": "login",
                "redirect_uri": REDIRECT_URI,
                "state": mobile_state,
                "code_challenge": code_challenge,
                "ui_locales": self.state.locale,
            },
            headers=self._web_headers(),
            allow_redirects=True,
            timeout=self.timeout,
        )
        start_response.raise_for_status()

        identifier_form = self._extract_form(start_response.text, expected_action_part="/login/identifier")
        identifier_form["email"] = self.email

        identifier_response = self.session.post(
            urljoin(IDENTITY_URL, identifier_form.pop("__action")),
            data=identifier_form,
            headers=self._web_headers(referer=start_response.url, origin=IDENTITY_URL),
            allow_redirects=True,
            timeout=self.timeout,
        )
        identifier_response.raise_for_status()

        password_form = self._extract_password_submission(identifier_response.text, identifier_response.url)
        password_form["password"] = self.password

        auth_response = self.session.post(
            password_form.pop("__action"),
            data=password_form,
            headers=self._web_headers(referer=identifier_response.url, origin=IDENTITY_URL),
            allow_redirects=False,
            timeout=self.timeout,
        )
        final_location = self._follow_redirects_for_custom_scheme(auth_response)
        if not final_location.startswith(f"{REDIRECT_URI}?"):
            raise AuthenticationError("Did not receive the expected kombi redirect with authorization code")

        query = parse_qs(urlparse(final_location).query)
        code = self._require(query.get("code", [None])[0], "Missing authorization code")

        token_request = TokenExchangeRequest(
            code=code,
            client_id=ANDROID_CLIENT_ID,
            redirect_uri=REDIRECT_URI,
            code_verifier=code_verifier,
        )
        token_response = self.session.post(
            f"{BASE_URL}/oidc/v1/token",
            data=token_request.to_dict(),
            headers=self._app_headers(content_type="application/x-www-form-urlencoded", include_auth=False),
            timeout=self.timeout,
        )
        token_response.raise_for_status()
        self._store_token_payload(TokenResponse.from_dict(self._decode_json(token_response)))
        self._fetch_garage(GarageRequest(id_token=self._require(self.state.id_token, "Missing id token")))

    def _try_refresh_tokens(self) -> bool:
        if not self._token_valid(self.state.refresh_token, self.state.refresh_token_expires_at):
            return False

        request = RefreshTokenRequest(
            refresh_token=self._require(self.state.refresh_token, "Missing refresh token"),
            client_id=ANDROID_CLIENT_ID,
        )
        response = self.session.post(
            f"{BASE_URL}/oidc/v1/token",
            data=request.to_dict(),
            headers=self._app_headers(content_type="application/x-www-form-urlencoded", include_auth=False),
            timeout=self.timeout,
        )
        if response.status_code >= 400:
            return False

        self._store_token_payload(TokenResponse.from_dict(self._decode_json(response)))
        self._fetch_garage(GarageRequest(id_token=self._require(self.state.id_token, "Missing id token")))
        return True

    def _ensure_vehicle_token(self) -> None:
        if self._token_valid(self.state.vehicle_token, self.state.vehicle_token_expires_at):
            return

        self.get_garage(force=not self._token_valid(self.state.access_token, self.state.access_token_expires_at))

        user_id = self._require(self.state.user_id, "Missing user id")
        vehicle_id = self._require(self.state.vehicle_id, "Missing vehicle id")
        access_token = self._require(self.state.access_token, "Missing access token")
        id_token = self._require(self.state.id_token, "Missing id token")
        tsp = self.state.tsp or self._resolve_tsp()
        spin_hash = self._resolve_spin_hash()

        request = VehicleSessionRequest(
            idToken=id_token,
            tsp=tsp,
            spinHash=spin_hash,
        )
        response = self._request(
            "POST",
            f"{BASE_URL}/ss/v1/user/{user_id}/vehicle/{vehicle_id}/session",
            json=request.to_dict(),
            token=access_token,
            user_id_header=user_id,
        )
        payload = self._parse_vehicle_session_response(self._decode_json(response))
        if not payload.carnet_vehicle_token:
            raise VehicleSessionError("Vehicle session response did not include a carnetVehicleToken")

        self.state.vehicle_session_payload = payload
        self.state.vehicle_token = payload.carnet_vehicle_token
        self.state.vehicle_token_expires_at = float(self._jwt_exp(payload.carnet_vehicle_token))
        self._save_state()

    def _resolve_spin_hash(self) -> str:
        if self.spin:
            challenge = self._get_spin_challenge()
            return calc_spin_hash(challenge, self.spin)

        raise VehicleSessionError(
            "A fresh vehicle token requires spin"
        )

    def _get_spin_challenge(self) -> str:
        response = self._request(
            "GET",
            f"{BASE_URL}/ss/v1/user/{self._require(self.state.user_id, 'Missing user id')}/challenge",
            token=self._require(self.state.access_token, "Missing access token"),
            user_id_header=self._require(self.state.user_id, "Missing user id"),
        )
        payload = self._parse_spin_challenge_response(self._decode_json(response))
        return self._require(payload.challenge, "Missing challenge in challenge response")

    def _get_vehicle_token(self, *, force: bool = False) -> str:
        if not force and self._token_valid(self.state.vehicle_token, self.state.vehicle_token_expires_at):
            return self._require(self.state.vehicle_token, "Missing vehicle token")
        self.login(force=False, require_vehicle_token=not force)
        if force:
            self.state.vehicle_token = None
            self.state.vehicle_token_expires_at = 0.0
            self._ensure_vehicle_token()
        return self._require(self.state.vehicle_token, "Missing vehicle token")

    def _resolve_vehicle_id(self) -> str:
        if not self.state.vehicle_id:
            self.get_garage()
        return self._require(self.state.vehicle_id, "No vehicle id available")

    def _resolve_tsp(self) -> str:
        if self.state.tsp:
            return self.state.tsp
        garage = self.get_garage()
        tsp = garage.preferred_vehicle.tspProvider or "WCT"
        self.state.tsp = tsp
        self._save_state()
        return tsp

    def _store_token_payload(self, payload: TokenResponse) -> None:
        now = time.time()
        self.state.access_token = payload.access_token
        self.state.id_token = payload.id_token
        self.state.refresh_token = payload.refresh_token or self.state.refresh_token
        self.state.token_type = payload.token_type or "Bearer"

        if self.state.access_token:
            self.state.access_token_expires_at = now + float(payload.expires_in)
            self.state.user_id = self._jwt_claim(self.state.access_token, "sub") or self.state.user_id
        if self.state.id_token:
            self.state.id_token_expires_at = now + float(payload.id_expires_in)
            self.state.email = self._jwt_claim(self.state.id_token, "email") or self.state.email
        if self.state.refresh_token:
            self.state.refresh_token_expires_at = now + float(payload.refresh_expires_in or 0)
        self._save_state()

    def _fetch_garage(self, request: GarageRequest) -> GarageResponse:
        response = self._request(
            "GET",
            f"{BASE_URL}/account/v1/garage",
            params={"idToken": request.id_token},
            token=self._require(self.state.access_token, "Missing access token"),
            user_id_header="",
        )
        garage = self._parse_garage_response(self._decode_json(response))
        self.state.garage = garage
        vehicle = garage.preferred_vehicle
        self.state.user_id = garage.user.userId or self.state.user_id
        self.state.vehicle_id = vehicle.vehicleId or self.state.vehicle_id
        self.state.vin = vehicle.vin or self.state.vin
        self._save_state()
        return garage

    def _parse_garage_response(self, payload: dict[str, Any]) -> GarageResponse:
        data = payload["data"]
        user_raw = data["user"]
        user = GarageUser(
            userId=user_raw["userId"],
            email=user_raw["email"],
            firstName=user_raw["firstName"],
            lastName=user_raw["lastName"],
            preferredLanguage=user_raw["preferredLanguage"],
            localeCode=user_raw["localeCode"],
            raw=user_raw,
        )
        vehicles: list[GarageVehicle] = []
        for item in data.get("vehicles", []):
            vehicles.append(
                GarageVehicle(
                    vehicleId=item["vehicleId"],
                    brand=item["brand"],
                    modelName=item["modelName"],
                    modelYear=item["modelYear"],
                    vin=item["vin"],
                    preferred=bool(item.get("preferred")),
                    tspProvider=item.get("tspProvider", ""),
                    status=item.get("status", ""),
                    activation=VehicleActivation(status=item.get("activation", {}).get("status", "")),
                    relationships=[
                        GarageVehicleRelationship.from_dict(relationship)
                        for relationship in item.get("relationships", [])
                    ],
                    raw=item,
                )
            )
        return GarageResponse(
            profile_status=data.get("profileStatus", ""),
            spin_status=data.get("spinStatus", ""),
            vehicles=vehicles,
            user=user,
            call_to_actions=data.get("callToActions", []),
            raw=data,
        )

    def _parse_spin_challenge_response(self, payload: dict[str, Any]) -> SpinChallengeResponse:
        data = payload["data"]
        return SpinChallengeResponse(
            challenge=data["challenge"],
            remaining_tries=int(data.get("remainingTries", 0)),
            raw=data,
        )

    def _parse_vehicle_session_response(self, payload: dict[str, Any]) -> VehicleSessionResponse:
        data = payload["data"]
        rights_raw = data["rolesAndRights"]
        rights = VehicleRolesAndRights(
            vehicleId=rights_raw["vehicleId"],
            userId=rights_raw["userId"],
            tsp=rights_raw.get("tsp", ""),
            roles=rights_raw.get("roles", []),
            privileges=rights_raw.get("privileges", []),
            raw=rights_raw,
        )
        return VehicleSessionResponse(
            roles_and_rights=rights,
            carnet_vehicle_token=data["carnetVehicleToken"],
            raw=data,
        )

    def _parse_vehicle_status_response(self, payload: dict[str, Any]) -> VehicleStatusResponse:
        data = payload["data"]
        exterior = data.get("exteriorStatus", {})
        door_status_raw = exterior.get("doorStatus")
        door_status = None
        if door_status_raw:
            door_status = VehicleDoorStatus(
                frontLeft=door_status_raw.get("frontLeft", ""),
                frontRight=door_status_raw.get("frontRight", ""),
                rearLeft=door_status_raw.get("rearLeft", ""),
                rearRight=door_status_raw.get("rearRight", ""),
                trunk=door_status_raw.get("trunk", ""),
                hood=door_status_raw.get("hood", ""),
                raw=door_status_raw,
            )
        last_location = data.get("lastParkedLocation", {})
        power = data.get("powerStatus", {})
        return VehicleStatusResponse(
            current_mileage=int(data.get("currentMileage", 0)),
            lock_status=data.get("lockStatus", ""),
            cruise_range=power.get("cruiseRange"),
            last_parked_latitude=last_location.get("latitude"),
            last_parked_longitude=last_location.get("longitude"),
            door_status=door_status,
            raw=data,
        )

    def _parse_vehicle_location_response(self, payload: dict[str, Any]) -> VehicleLocationResponse:
        data = payload["data"]
        location_raw = data["location"]
        return VehicleLocationResponse(
            vehicle_id=data["vehicleId"],
            event_timestamp=int(data["eventTimeStamp"]),
            location=VehicleCoordinate(
                latitude=float(location_raw["latitude"]),
                longitude=float(location_raw["longitude"]),
                headingDirection=location_raw.get("headingDirection"),
            ),
            source=data.get("source", ""),
            parked=bool(data.get("parked")),
            raw=data,
        )

    def _parse_ev_summary_response(self, payload: dict[str, Any]) -> EVSummaryResponse:
        data = payload["data"]
        status = data.get("batteryAndPlugStatus", {})
        battery_raw = status.get("batteryStatus", {})
        charging_raw = status.get("chargingStatus", {})
        return EVSummaryResponse(
            battery_status=BatteryStatus(
                current_soc_pct=battery_raw.get("currentSOCPct"),
                cruising_range_km=battery_raw.get("cruisingRange", {}).get("range"),
                raw=battery_raw,
            ),
            charging_status=ChargingStatus(
                current_charge_state=charging_raw.get("currentChargeState"),
                charge_power=charging_raw.get("chargePower"),
                charge_mode=charging_raw.get("chargeMode"),
                raw=charging_raw,
            ),
            raw=data,
        )

    def _request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        token: str | None,
        user_id_header: str,
    ) -> requests.Response:
        response = self.session.request(
            method,
            url,
            params=params,
            json=json,
            headers=self._app_headers(
                token=token,
                user_id=user_id_header,
                content_type="application/json;charset=UTF-8" if json is None else "application/json; charset=UTF-8",
            ),
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response

    def _app_headers(
        self,
        *,
        token: str | None = None,
        user_id: str | None = None,
        content_type: str = "application/json;charset=UTF-8",
        include_auth: bool = True,
    ) -> dict[str, str]:
        headers = {
            "X-Mobile-Session-Id": self.state.mobile_session_id,
            "X-User-Agent": "mobile-android",
            "X-App-Uuid": self.state.app_uuid,
            "X-User-Locale": self.state.locale,
            "X-User-Country": self.state.country,
            "X-App-Version": APP_VERSION,
            "X-App-Device-Model": DEVICE_MODEL,
            "X-App-Device-Os": DEVICE_OS,
            "User-Agent": USER_AGENT_APP,
            "Accept-Encoding": "gzip, deflate, br",
            "Content-Type": content_type,
        }
        if include_auth and token:
            headers["Authorization"] = f"Bearer {token}"
        if user_id is not None:
            headers["X-User-Id"] = user_id
        return headers

    def _web_headers(self, *, referer: str | None = None, origin: str | None = None) -> dict[str, str]:
        headers = {
            "User-Agent": USER_AGENT_WEB,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Upgrade-Insecure-Requests": "1",
            "X-Requested-With": "com.vw.carnet.release",
        }
        if referer:
            headers["Referer"] = referer
        if origin:
            headers["Origin"] = origin
        return headers

    def _follow_redirects_for_custom_scheme(self, response: requests.Response) -> str:
        current = response
        for _ in range(10):
            location = current.headers.get("Location")
            if not location:
                raise AuthenticationError("Expected redirect during login flow")
            if location.startswith(f"{REDIRECT_URI}?"):
                return location
            current = self.session.get(
                urljoin(current.url, location),
                headers=self._web_headers(referer=current.url),
                allow_redirects=False,
                timeout=self.timeout,
            )
        raise AuthenticationError("Too many redirects during login flow")

    def _extract_form(self, html: str, *, expected_action_part: str) -> dict[str, str]:
        form_pattern = re.compile(r"<form\b[^>]*action=\"([^\"]+)\"[^>]*>(.*?)</form>", re.DOTALL | re.IGNORECASE)
        input_pattern = re.compile(r"<input\b([^>]+)>", re.IGNORECASE)
        attr_pattern = re.compile(r"([a-zA-Z_:][\w:.-]*)=\"([^\"]*)\"")

        for action, body in form_pattern.findall(html):
            if expected_action_part not in action:
                continue
            payload = {"__action": action}
            for input_attrs in input_pattern.findall(body):
                attrs = {key.lower(): value for key, value in attr_pattern.findall(input_attrs)}
                name = attrs.get("name")
                if not name:
                    continue
                payload[name] = attrs.get("value", "")
            return payload
        raise AuthenticationError(f"Could not find form with action containing {expected_action_part!r}")

    def _extract_password_submission(self, html: str, page_url: str) -> dict[str, str]:
        form = self._extract_form_or_none(html, expected_action_part="/login/authenticate")
        if form is not None:
            form["email"] = self.email
            return form

        csrf_token = self._search_required(r"csrf_token:\s*'([^']+)'", html, "csrf_token")
        relay_state = self._search_required(r'relayState":"([^"]+)"', html, "relayState")
        hmac = self._search_required(r'"hmac":"([^"]+)"', html, "hmac")
        email = self._search_required(r'"email":"([^"]+)"', html, "email")
        post_action = self._search_required(r'"postAction":"([^"]+)"', html, "postAction")
        return {
            "__action": self._resolve_action_url(page_url, post_action),
            "_csrf": csrf_token,
            "relayState": relay_state,
            "email": email,
            "hmac": hmac,
        }

    def _extract_form_or_none(self, html: str, *, expected_action_part: str) -> dict[str, str] | None:
        form_pattern = re.compile(r"<form\b[^>]*action=\"([^\"]+)\"[^>]*>(.*?)</form>", re.DOTALL | re.IGNORECASE)
        input_pattern = re.compile(r"<input\b([^>]+)>", re.IGNORECASE)
        attr_pattern = re.compile(r"([a-zA-Z_:][\w:.-]*)=\"([^\"]*)\"")

        for action, body in form_pattern.findall(html):
            if expected_action_part not in action:
                continue
            payload = {"__action": urljoin(IDENTITY_URL, action)}
            for input_attrs in input_pattern.findall(body):
                attrs = {key.lower(): value for key, value in attr_pattern.findall(input_attrs)}
                name = attrs.get("name")
                if not name:
                    continue
                payload[name] = attrs.get("value", "")
            return payload
        return None

    def _decode_json(self, response: requests.Response) -> dict[str, Any]:
        try:
            return response.json()
        except ValueError as exc:
            raise VWClientError(f"Expected JSON response from {response.url}") from exc

    def _resolve_action_url(self, page_url: str, action: str) -> str:
        if action.startswith("http://") or action.startswith("https://"):
            return action
        if action.startswith("/"):
            return urljoin(IDENTITY_URL, action)

        current_no_query = page_url.split("?", 1)[0]
        if current_no_query.endswith(action):
            return current_no_query
        if action.startswith("login/"):
            base = current_no_query.rsplit("/", 1)[0]
            tail = action.split("/", 1)[1]
            return f"{base}/{tail}"
        return urljoin(f"{current_no_query.rsplit('/', 1)[0]}/", action)

    def _search_required(self, pattern: str, text: str, name: str) -> str:
        match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
        if not match:
            raise AuthenticationError(f"Could not find {name} in current identity page")
        return match.group(1)

    def _load_state(self) -> SessionState:
        if not self.session_path.exists():
            return SessionState()
        try:
            return SessionState.from_json(json.loads(self.session_path.read_text(encoding="utf-8")))
        except (OSError, json.JSONDecodeError):
            return SessionState()

    def _save_state(self) -> None:
        self.session_path.parent.mkdir(parents=True, exist_ok=True)
        self.session_path.write_text(json.dumps(self.state.to_json(), indent=2, sort_keys=True), encoding="utf-8")

    def _token_valid(self, token: str | None, expires_at: float | int | None) -> bool:
        return bool(token and expires_at and float(expires_at) > time.time() + 60)

    def _pkce_challenge(self, verifier: str) -> str:
        digest = hashlib.sha256(verifier.encode("utf-8")).digest()
        return base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")

    def _jwt_claim(self, token: str, claim: str) -> Any:
        payload = self._decode_jwt_payload(token)
        return payload.get(claim)

    def _jwt_exp(self, token: str) -> int:
        payload = self._decode_jwt_payload(token)
        exp = payload.get("exp")
        if not isinstance(exp, int):
            raise VWClientError("JWT did not contain an integer exp claim")
        return exp

    def _decode_jwt_payload(self, token: str) -> dict[str, Any]:
        try:
            payload_segment = token.split(".")[1]
            payload_segment += "=" * (-len(payload_segment) % 4)
            return json.loads(base64.urlsafe_b64decode(payload_segment.encode("ascii")).decode("utf-8"))
        except (IndexError, ValueError, json.JSONDecodeError) as exc:
            raise VWClientError("Failed to decode JWT payload") from exc

    def _require(self, value: Any, message: str) -> Any:
        if value in (None, ""):
            raise VWClientError(message)
        return value
