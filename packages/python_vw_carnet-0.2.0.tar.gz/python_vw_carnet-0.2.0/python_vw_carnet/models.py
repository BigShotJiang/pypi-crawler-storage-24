from __future__ import annotations

from dataclasses import asdict, dataclass, fields, is_dataclass
from typing import Any, TypeVar


T = TypeVar("T", bound="DTOModel")


class DTOModel:
    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls: type[T], payload: dict[str, Any]) -> T:
        allowed = {field.name for field in fields(cls)}
        data = {key: value for key, value in payload.items() if key in allowed}
        return cls(**data)  # type: ignore[arg-type]


def serialize_for_json(value: Any) -> Any:
    if isinstance(value, DTOModel):
        return {key: serialize_for_json(item) for key, item in value.to_dict().items()}
    if is_dataclass(value):
        return {key: serialize_for_json(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {key: serialize_for_json(item) for key, item in value.items()}
    if isinstance(value, list):
        return [serialize_for_json(item) for item in value]
    return value


@dataclass(slots=True)
class TokenExchangeRequest(DTOModel):
    code: str
    client_id: str
    redirect_uri: str
    code_verifier: str
    grant_type: str = "authorization_code"


@dataclass(slots=True)
class RefreshTokenRequest(DTOModel):
    refresh_token: str
    client_id: str
    grant_type: str = "refresh_token"


@dataclass(slots=True)
class TokenResponse(DTOModel):
    access_token: str
    expires_in: int
    id_token: str
    id_expires_in: int
    token_type: str
    refresh_token: str | None = None
    refresh_expires_in: int | None = None


@dataclass(slots=True)
class GarageRequest(DTOModel):
    id_token: str


@dataclass(slots=True)
class GarageVehicleRelationship(DTOModel):
    relationshipName: str
    relationshipStatus: str
    termsOfServiceStatus: str


@dataclass(slots=True)
class VehicleActivation(DTOModel):
    status: str


@dataclass(slots=True)
class GarageVehicle(DTOModel):
    vehicleId: str
    brand: str
    modelName: str
    modelYear: str
    vin: str
    preferred: bool
    tspProvider: str
    status: str
    activation: VehicleActivation
    relationships: list[GarageVehicleRelationship]
    raw: dict[str, Any]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "GarageVehicle":
        return cls(
            vehicleId=payload["vehicleId"],
            brand=payload["brand"],
            modelName=payload["modelName"],
            modelYear=payload["modelYear"],
            vin=payload["vin"],
            preferred=bool(payload.get("preferred")),
            tspProvider=payload.get("tspProvider", ""),
            status=payload.get("status", ""),
            activation=VehicleActivation.from_dict(payload.get("activation", {})),
            relationships=[
                GarageVehicleRelationship.from_dict(item)
                for item in payload.get("relationships", [])
            ],
            raw=payload.get("raw", payload),
        )


@dataclass(slots=True)
class GarageUser(DTOModel):
    userId: str
    email: str
    firstName: str
    lastName: str
    preferredLanguage: str
    localeCode: str
    raw: dict[str, Any]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "GarageUser":
        return cls(
            userId=payload["userId"],
            email=payload["email"],
            firstName=payload["firstName"],
            lastName=payload["lastName"],
            preferredLanguage=payload.get("preferredLanguage", ""),
            localeCode=payload.get("localeCode", ""),
            raw=payload.get("raw", payload),
        )


@dataclass(slots=True)
class GarageResponse(DTOModel):
    profile_status: str
    spin_status: str
    vehicles: list[GarageVehicle]
    user: GarageUser
    call_to_actions: list[str]
    raw: dict[str, Any]

    @property
    def preferred_vehicle(self) -> GarageVehicle:
        return next((vehicle for vehicle in self.vehicles if vehicle.preferred), self.vehicles[0])

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "GarageResponse":
        user_payload = payload.get("user", {})
        if "userId" in user_payload:
            user = GarageUser.from_dict(user_payload)
        else:
            user = GarageUser.from_dict(
                {
                    "userId": user_payload.get("userId", ""),
                    "email": user_payload.get("email", ""),
                    "firstName": user_payload.get("firstName", ""),
                    "lastName": user_payload.get("lastName", ""),
                    "preferredLanguage": user_payload.get("preferredLanguage", ""),
                    "localeCode": user_payload.get("localeCode", ""),
                    "raw": user_payload,
                }
            )
        return cls(
            profile_status=payload.get("profile_status", payload.get("profileStatus", "")),
            spin_status=payload.get("spin_status", payload.get("spinStatus", "")),
            vehicles=[GarageVehicle.from_dict(item) for item in payload.get("vehicles", [])],
            user=user,
            call_to_actions=list(payload.get("call_to_actions", payload.get("callToActions", []))),
            raw=payload.get("raw", payload),
        )


@dataclass(slots=True)
class SpinChallengeResponse(DTOModel):
    challenge: str
    remaining_tries: int
    raw: dict[str, Any]


@dataclass(slots=True)
class VehicleSessionRequest(DTOModel):
    idToken: str
    tsp: str
    spinHash: str


@dataclass(slots=True)
class VehicleRolesAndRights(DTOModel):
    vehicleId: str
    userId: str
    tsp: str
    roles: list[str]
    privileges: list[str]
    raw: dict[str, Any]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "VehicleRolesAndRights":
        return cls(
            vehicleId=payload["vehicleId"],
            userId=payload["userId"],
            tsp=payload.get("tsp", ""),
            roles=list(payload.get("roles", [])),
            privileges=list(payload.get("privileges", [])),
            raw=payload.get("raw", payload),
        )


@dataclass(slots=True)
class VehicleSessionResponse(DTOModel):
    roles_and_rights: VehicleRolesAndRights
    carnet_vehicle_token: str
    raw: dict[str, Any]

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "VehicleSessionResponse":
        rights_payload = payload.get("roles_and_rights", payload.get("rolesAndRights"))
        return cls(
            roles_and_rights=VehicleRolesAndRights.from_dict(rights_payload),
            carnet_vehicle_token=payload.get("carnet_vehicle_token", payload.get("carnetVehicleToken", "")),
            raw=payload.get("raw", payload),
        )


@dataclass(slots=True)
class VehicleStatusRequest(DTOModel):
    vehicle_id: str


@dataclass(slots=True)
class VehicleDoorStatus(DTOModel):
    frontLeft: str
    frontRight: str
    rearLeft: str
    rearRight: str
    trunk: str
    hood: str
    raw: dict[str, Any]


@dataclass(slots=True)
class VehicleStatusResponse(DTOModel):
    current_mileage: int
    lock_status: str
    cruise_range: int | None
    last_parked_latitude: float | None
    last_parked_longitude: float | None
    door_status: VehicleDoorStatus | None
    raw: dict[str, Any]


@dataclass(slots=True)
class VehicleLocationRequest(DTOModel):
    vehicle_id: str


@dataclass(slots=True)
class VehicleCoordinate(DTOModel):
    latitude: float
    longitude: float
    headingDirection: str | None


@dataclass(slots=True)
class VehicleLocationResponse(DTOModel):
    vehicle_id: str
    event_timestamp: int
    location: VehicleCoordinate
    source: str
    parked: bool
    raw: dict[str, Any]


@dataclass(slots=True)
class EVSummaryRequest(DTOModel):
    user_id: str
    vehicle_id: str
    temp_unit: str = "f"


@dataclass(slots=True)
class BatteryStatus(DTOModel):
    current_soc_pct: int | None
    cruising_range_km: int | None
    raw: dict[str, Any]


@dataclass(slots=True)
class ChargingStatus(DTOModel):
    current_charge_state: str | None
    charge_power: int | None
    charge_mode: str | None
    raw: dict[str, Any]


@dataclass(slots=True)
class EVSummaryResponse(DTOModel):
    battery_status: BatteryStatus
    charging_status: ChargingStatus
    raw: dict[str, Any]
