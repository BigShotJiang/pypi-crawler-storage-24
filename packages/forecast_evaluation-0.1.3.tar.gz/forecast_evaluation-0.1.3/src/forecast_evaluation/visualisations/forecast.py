from typing import Literal

import matplotlib.pyplot as plt
import pandas as pd

from forecast_evaluation.data import ForecastData
from forecast_evaluation.visualisations.theme import create_themed_figure


def plot_vintage(
    data: ForecastData,
    variable: str,
    vintage_date: str | pd.Timestamp,
    forecast_source: list[str] = None,
    outturn_start_date: str | pd.Timestamp = None,
    frequency: Literal["Q", "M"] = "Q",
    metric: Literal["levels", "pop", "yoy"] = "levels",
    k: int = 12,
    convert_to_percentage: bool = False,
    return_plot: bool = False,
) -> None:
    """Generate a plot comparing forecasts from different sources for a specific vintage.

    Parameters
    ----------
    data : ForecastData
        ForecastData object containing forecast and outturn data.
    variable : str
        Name of the variable to plot.
    forecast_source : list of str
        List of forecast sources to include in the plot.
    vintage_date : str or pd.Timestamp
        The vintage date to plot, either as string or pandas Timestamp.
    outturn_start_date : str or pd.Timestamp, optional
        Start date for outturn data to display (inclusive). If None, all available outturns are used.
    frequency : {"Q", "M"}, default "Q"
        Frequency of the data, either quarterly or monthly.
    metric : {"levels", "pop", "yoy"}, default "levels"
        Type of transformation to apply to the data.
    convert_to_percentage : bool, default False
        If True, multiplies values on the y-axis by 100.
    return_plot : bool, default False
        If True, returns the matplotlib figure and axis objects.

    Returns
    -------
    fig, ax : tuple or None
        If return_plot is True, returns a tuple (fig, ax) of the matplotlib figure and axis objects.
        Otherwise, returns None.
    """
    if data._forecasts is None:
        raise ValueError("ForecastData main table is not available. Please ensure data has been added and processed.")

    # add a check here
    vintage_date = pd.to_datetime(vintage_date)

    # filter forecasts
    filtered_data = data.copy()

    filtered_data.filter(
        variables=variable,
        metrics=metric,
        frequencies=frequency,
        sources=forecast_source,
        start_vintage=vintage_date,
        end_vintage=vintage_date,
    )
    forecasts_filtered = filtered_data.forecasts.copy()

    # filter outturns (they are not filtered with filter())(we select the last vintage only)
    outturns = data._outturns.copy()
    min_date = outturn_start_date if outturn_start_date is not None else outturns["date"].min()

    real_time_outturns = (
        outturns[
            (outturns["vintage_date"] == vintage_date)
            & (outturns["variable"].isin(forecasts_filtered["variable"].unique()))
            & (outturns["metric"] == metric)
            & (outturns["date"] <= forecasts_filtered["date"].max())
            & (outturns["date"] >= min_date)
        ]
        .copy()
        .sort_values("date")
    )

    # Use -(k+1) if it exists, otherwise use max(forecast_horizon)
    post_outturns = outturns.copy()

    post_outturns["max_feasible_horizon"] = post_outturns.groupby("date")["forecast_horizon"].transform(
        lambda x: -(k + 1) if -(k + 1) in x.values else x.min()
    )

    post_outturns = (
        outturns[
            (outturns["forecast_horizon"] == post_outturns["max_feasible_horizon"])
            & (outturns["variable"].isin(forecasts_filtered["variable"].unique()))
            & (outturns["metric"] == metric)
            & (outturns["date"] <= forecasts_filtered["date"].max())
            & (outturns["date"] >= min_date)
        ]
        .copy()
        .sort_values("date")
    )

    multiplier = 100 if convert_to_percentage else 1

    fig, ax = create_themed_figure()

    # Plot each source separately
    for forecast_id in forecasts_filtered["unique_id"].unique():
        source_df = forecasts_filtered[forecasts_filtered["unique_id"] == forecast_id].sort_values("date")
        ax.plot(source_df["date"], 
                multiplier * source_df["value"], 
                marker="o", markersize=3, 
                label=forecast_id, 
                alpha=0.7)

    # Overlay the outturns series (forecast_horizon == -1)
    if not real_time_outturns.empty:
        # Split outturns: solid before vintage_date, dashed from vintage_date onwards
        solid_outturns = real_time_outturns[real_time_outturns["date"] < vintage_date]
        dashed_outturns = post_outturns[post_outturns["date"] >= vintage_date]

        if not solid_outturns.empty:
            ax.plot(
                solid_outturns["date"],
                multiplier * solid_outturns["value"],
                color="darkblue",
                marker="o",
                markersize=3,
                label="Outturns (at the time of forecast)",
            )
        if not dashed_outturns.empty:
            ax.plot(
                dashed_outturns["date"],
                multiplier * dashed_outturns["value"],
                color="darkblue",
                marker="o",
                markersize=3,
                linestyle="--",
                label="Outturns (post forecast)",
            )

    ax.set_title(f"{variable} [{frequency}] - {metric} - Vintage: {vintage_date.date()}")
    y_label = f"{variable} ({metric}) (p.p.)" if convert_to_percentage else f"{variable} ({metric})"
    ax.set_ylabel(y_label)
    ax.legend(title="unique_id")

    # Return or show the plot
    if return_plot:
        return fig, ax
    else:
        plt.show()
        return None
