"""Skills layer — reusable capability packages with metadata and episodic tracking.

Skills are proven ephemeral code patterns that get promoted from one-time executions
into reusable templates. They carry rich metadata (tags, args, examples, stats)
that helps the LLM generate correct code on the first try.
"""
