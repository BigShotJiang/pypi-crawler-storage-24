"""Skill metadata models — Pydantic v2 models for skill definitions."""

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field


class SkillArg(BaseModel):
    """A single argument for a skill."""
    name: str
    type: str = "str"
    default: Any = None
    description: str = ""


class SkillExample(BaseModel):
    """A usage example mapping natural language to args."""
    prompt: str          # "check disk usage"
    args: dict[str, Any] # {"command": "df -h"}


class SkillMeta(BaseModel):
    """Full metadata for a skill.

    Stored as the YAML frontmatter in .skill.yaml files.
    """
    name: str
    technology: str
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    args: list[SkillArg] = Field(default_factory=list)
    examples: list[SkillExample] = Field(default_factory=list)
    client_type: str = ""
    success_count: int = 0
    fail_count: int = 0
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    last_used: str = ""
    version: int = 1

    def record_success(self) -> None:
        """Record a successful execution."""
        self.success_count += 1
        self.last_used = datetime.now(timezone.utc).isoformat()

    def record_failure(self) -> None:
        """Record a failed execution."""
        self.fail_count += 1
        self.last_used = datetime.now(timezone.utc).isoformat()

    @property
    def reliability(self) -> float:
        """Success rate as a float 0.0-1.0."""
        total = self.success_count + self.fail_count
        if total == 0:
            return 1.0
        return self.success_count / total
