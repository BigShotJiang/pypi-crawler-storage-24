"""Skill registry — discovers, indexes, and serves skills.

Skills are stored as pairs:
  skills/{technology}/{skill_name}.skill.yaml  — metadata (tags, args, examples, stats)
  skills/{technology}/{skill_name}.py          — code template

The registry auto-indexes on startup (mtime-cached) and provides
semantic search by technology, intent, and tags.
"""

import logging
import os
import re
import threading
from pathlib import Path
from typing import Any

import yaml

from skills.models import SkillArg, SkillExample, SkillMeta

logger = logging.getLogger(__name__)

from utils.paths import get_skills_dir

SKILLS_DIR = get_skills_dir()


class SkillRegistry:
    """Manages the skill library — discovery, search, CRUD, and stats tracking."""

    def __init__(self, skills_dir: Path | None = None):
        self._dir = skills_dir or SKILLS_DIR
        self._skills: dict[str, SkillMeta] = {}   # "tech/name" -> SkillMeta
        self._code: dict[str, str] = {}            # "tech/name" -> code
        self._lock = threading.Lock()
        self._index_mtime: float = 0
        self._reindex()

    # ── Discovery & Indexing ─────────────────────────

    def _reindex(self) -> None:
        """Scan skills directory and load all skill metadata + code."""
        with self._lock:
            self._skills.clear()
            self._code.clear()

            for tech_dir in self._dir.iterdir():
                if not tech_dir.is_dir() or tech_dir.name.startswith("_"):
                    continue

                for meta_file in tech_dir.glob("*.skill.yaml"):
                    skill_name = meta_file.name.replace(".skill.yaml", "")
                    key = f"{tech_dir.name}/{skill_name}"

                    try:
                        raw = yaml.safe_load(meta_file.read_text(encoding="utf-8"))
                        if not raw:
                            continue
                        meta = self._parse_meta(raw, skill_name, tech_dir.name)
                        self._skills[key] = meta

                        # Load code template if exists
                        code_file = tech_dir / f"{skill_name}.py"
                        if code_file.exists():
                            self._code[key] = code_file.read_text(encoding="utf-8")

                        logger.debug(f"[SKILLS] Loaded: {key}")
                    except Exception as e:
                        logger.warning(f"[SKILLS] Failed to load {meta_file}: {e}")

            self._index_mtime = self._dir_mtime()
            logger.info(f"[SKILLS] Indexed {len(self._skills)} skills")

    def _parse_meta(self, raw: dict, name: str, technology: str) -> SkillMeta:
        """Parse raw YAML dict into SkillMeta."""
        args = []
        for a in raw.get("args", []):
            if isinstance(a, dict):
                args.append(SkillArg(**a))

        examples = []
        for ex in raw.get("examples", []):
            if isinstance(ex, dict) and "prompt" in ex:
                examples.append(SkillExample(
                    prompt=ex["prompt"],
                    args=ex.get("args", {}),
                ))

        return SkillMeta(
            name=raw.get("name", name),
            technology=raw.get("technology", technology),
            description=raw.get("description", ""),
            tags=raw.get("tags", []),
            args=args,
            examples=examples,
            client_type=raw.get("client_type", ""),
            success_count=raw.get("success_count", 0),
            fail_count=raw.get("fail_count", 0),
            created_at=raw.get("created_at", ""),
            last_used=raw.get("last_used", ""),
            version=raw.get("version", 1),
        )

    def _dir_mtime(self) -> float:
        """Get the latest mtime across all skill files."""
        latest = 0.0
        try:
            for tech_dir in self._dir.iterdir():
                if not tech_dir.is_dir() or tech_dir.name.startswith("_"):
                    continue
                for f in tech_dir.iterdir():
                    try:
                        mt = f.stat().st_mtime
                        if mt > latest:
                            latest = mt
                    except OSError:
                        pass
        except OSError:
            pass
        return latest

    def _check_stale(self) -> None:
        """Re-index if any skill files changed."""
        current = self._dir_mtime()
        if current > self._index_mtime:
            self._reindex()

    # ── Search ───────────────────────────────────────

    def search(
        self,
        technology: str | None = None,
        intent: str | None = None,
        tags: list[str] | None = None,
        limit: int = 5,
    ) -> list[tuple[str, SkillMeta, float]]:
        """Search skills by technology, intent text, and/or tags.

        Returns list of (key, meta, score) tuples sorted by relevance.
        Score is 0.0-1.0.
        """
        self._check_stale()
        results: list[tuple[str, SkillMeta, float]] = []

        intent_words = set(intent.lower().split()) if intent else set()

        for key, meta in self._skills.items():
            score = 0.0

            # Technology match (strongest signal)
            if technology and meta.technology == technology:
                score += 0.4
            elif technology:
                continue  # Wrong technology, skip entirely

            # Tag match
            if tags:
                meta_tags = set(meta.tags)
                overlap = meta_tags & set(tags)
                if overlap:
                    score += 0.2 * (len(overlap) / len(tags))

            # Intent match (fuzzy text matching)
            if intent_words:
                # Match against name, description, tags, example prompts
                searchable = set()
                searchable.update(meta.name.lower().replace("_", " ").split())
                searchable.update(meta.description.lower().split())
                searchable.update(t.lower() for t in meta.tags)
                for ex in meta.examples:
                    searchable.update(ex.prompt.lower().split())

                overlap = intent_words & searchable
                if overlap:
                    score += 0.3 * (len(overlap) / len(intent_words))

            # Reliability bonus
            if meta.reliability >= 0.8 and (meta.success_count + meta.fail_count) >= 3:
                score += 0.1

            if score > 0:
                results.append((key, meta, score))

        results.sort(key=lambda x: x[2], reverse=True)
        return results[:limit]

    def get_skill(self, key: str) -> tuple[SkillMeta, str] | None:
        """Get a skill's metadata and code by key (tech/name).

        Returns (meta, code) or None if not found.
        """
        self._check_stale()
        meta = self._skills.get(key)
        if meta is None:
            return None
        code = self._code.get(key, "")
        return meta, code

    def get_skill_by_name(self, technology: str, name: str) -> tuple[SkillMeta, str] | None:
        """Get a skill by technology and name."""
        return self.get_skill(f"{technology}/{name}")

    # ── CRUD ─────────────────────────────────────────

    def register_skill(
        self,
        technology: str,
        name: str,
        code: str,
        description: str = "",
        tags: list[str] | None = None,
        args: list[dict] | None = None,
        examples: list[dict] | None = None,
        client_type: str = "",
    ) -> str:
        """Register a new skill (save metadata + code to disk).

        Args:
            technology: Technology name (e.g., 'ssh_server', 'kafka')
            name: Skill name (e.g., 'execute_command', 'list_topics')
            code: Python code with execute(client, connection_config, **kwargs) function
            description: What this skill does
            tags: Searchable tags
            args: Argument definitions [{"name": "cmd", "type": "str", "default": "echo hi"}]
            examples: Usage examples [{"prompt": "check disk", "args": {"cmd": "df -h"}}]
            client_type: Expected client type (e.g., 'SSHClient')
        Returns:
            Skill key (tech/name)
        """
        tech_dir = self._dir / technology
        tech_dir.mkdir(parents=True, exist_ok=True)

        # Build metadata
        meta = SkillMeta(
            name=name,
            technology=technology,
            description=description,
            tags=tags or [],
            args=[SkillArg(**a) for a in (args or [])],
            examples=[SkillExample(**e) for e in (examples or [])],
            client_type=client_type,
        )

        # Save metadata YAML
        meta_file = tech_dir / f"{name}.skill.yaml"
        meta_dict = meta.model_dump()
        # Convert nested models to plain dicts for YAML
        meta_dict["args"] = [a.model_dump() for a in meta.args]
        meta_dict["examples"] = [e.model_dump() for e in meta.examples]
        meta_file.write_text(
            yaml.dump(meta_dict, default_flow_style=False, sort_keys=False),
            encoding="utf-8",
        )

        # Save code
        code_file = tech_dir / f"{name}.py"
        code_file.write_text(code, encoding="utf-8")

        # Update in-memory index
        key = f"{technology}/{name}"
        with self._lock:
            self._skills[key] = meta
            self._code[key] = code

        logger.info(f"[SKILLS] Registered: {key}")
        return key

    def update_stats(self, key: str, success: bool) -> None:
        """Update success/fail stats for a skill.

        Persists changes to disk.
        """
        self._check_stale()
        meta = self._skills.get(key)
        if meta is None:
            return

        if success:
            meta.record_success()
        else:
            meta.record_failure()

        # Persist to disk
        parts = key.split("/", 1)
        if len(parts) != 2:
            return
        technology, name = parts
        meta_file = self._dir / technology / f"{name}.skill.yaml"
        if meta_file.exists():
            try:
                meta_dict = meta.model_dump()
                meta_dict["args"] = [a.model_dump() for a in meta.args]
                meta_dict["examples"] = [e.model_dump() for e in meta.examples]
                meta_file.write_text(
                    yaml.dump(meta_dict, default_flow_style=False, sort_keys=False),
                    encoding="utf-8",
                )
            except Exception as e:
                logger.warning(f"[SKILLS] Failed to persist stats for {key}: {e}")

    def delete_skill(self, key: str) -> bool:
        """Delete a skill from disk and memory."""
        parts = key.split("/", 1)
        if len(parts) != 2:
            return False
        technology, name = parts

        deleted = False
        meta_file = self._dir / technology / f"{name}.skill.yaml"
        code_file = self._dir / technology / f"{name}.py"

        if meta_file.exists():
            meta_file.unlink()
            deleted = True
        if code_file.exists():
            code_file.unlink()
            deleted = True

        with self._lock:
            self._skills.pop(key, None)
            self._code.pop(key, None)

        if deleted:
            logger.info(f"[SKILLS] Deleted: {key}")
        return deleted

    # ── Listing ──────────────────────────────────────

    def list_all(self) -> list[dict]:
        """List all skills with summary info."""
        self._check_stale()
        result = []
        for key, meta in sorted(self._skills.items()):
            result.append({
                "key": key,
                "name": meta.name,
                "technology": meta.technology,
                "description": meta.description,
                "tags": meta.tags,
                "success_count": meta.success_count,
                "fail_count": meta.fail_count,
                "reliability": round(meta.reliability, 2),
                "version": meta.version,
            })
        return result

    def list_by_technology(self, technology: str) -> list[dict]:
        """List skills for a specific technology."""
        return [s for s in self.list_all() if s["technology"] == technology]

    def count(self) -> int:
        """Total number of registered skills."""
        self._check_stale()
        return len(self._skills)

    # ── Prompt Context ───────────────────────────────

    def build_skill_context(
        self,
        technology: str,
        user_request: str,
        max_skills: int = 3,
    ) -> str:
        """Build a context string for the ephemeral code generation prompt.

        Searches for matching skills and formats them as examples
        the LLM can reference when generating new code.

        Returns empty string if no matching skills found.
        """
        matches = self.search(
            technology=technology,
            intent=user_request,
            limit=max_skills,
        )

        if not matches:
            return ""

        sections = []
        for key, meta, score in matches:
            code = self._code.get(key, "")

            # Build args description
            args_desc = ""
            if meta.args:
                arg_parts = []
                for a in meta.args:
                    default = f" = {a.default!r}" if a.default is not None else ""
                    arg_parts.append(f"  - {a.name} ({a.type}{default}): {a.description}")
                args_desc = "\nArgs:\n" + "\n".join(arg_parts)

            # Build examples
            examples_desc = ""
            if meta.examples:
                ex_parts = []
                for ex in meta.examples:
                    ex_parts.append(f"  - \"{ex.prompt}\" -> {ex.args}")
                examples_desc = "\nExamples:\n" + "\n".join(ex_parts)

            # Build stats
            total = meta.success_count + meta.fail_count
            stats = f"(used {total}x, {meta.reliability:.0%} success)" if total > 0 else "(new)"

            section = f"### Skill: {meta.name} {stats}\n{meta.description}{args_desc}{examples_desc}"
            if code:
                # Show just the function signature and first few lines
                code_preview = _truncate_code(code, max_lines=15)
                section += f"\n```python\n{code_preview}\n```"

            sections.append(section)

        return "## Similar Skills (use as reference)\n\n" + "\n\n".join(sections)


def _truncate_code(code: str, max_lines: int = 15) -> str:
    """Show code up to max_lines, truncating with '...' if longer."""
    lines = code.strip().splitlines()
    if len(lines) <= max_lines:
        return code.strip()
    return "\n".join(lines[:max_lines]) + "\n    # ... (truncated)"


# ── Singleton ────────────────────────────────────────

_registry: SkillRegistry | None = None


def get_registry() -> SkillRegistry:
    """Get the global SkillRegistry singleton."""
    global _registry
    if _registry is None:
        _registry = SkillRegistry()
    return _registry
