# CLAUDE.md -- DataClaw: Autonomous Data Reasoning Agent

## What This Is

DataClaw is an **autonomous reasoning agent** for data infrastructure. It connects to ANY technology (databases, APIs, filesystems, message queues, servers) using 3 smart bootstrap tools, and builds specialized tools from scratch when bootstrap isn't enough.

**Philosophy**: No static code. No per-technology hardcoding. The agent figures out HOW to connect from the connection config shape. It learns and grows — each tool it builds stays in its library forever.

**Architecture**: 3 bootstrap tools (run_query, call_api, read_files) handle common cases instantly. A redundancy gate prevents building tools that bootstrap already covers. For non-bootstrap technologies (messaging, servers, cloud), the connector layer auto-generates connection code, and ephemeral execution handles per-request operations. Successful ephemeral code can be promoted to reusable skills — proven patterns with metadata that help the LLM generate correct code on the first try.

## Quick Reference

```bash
# Install from pip
pip install dataclaw
dataclaw init          # scaffold ~/.dataclaw/ with config templates
dataclaw               # start the CLI

# Or run from source (dev mode)
python -m cli.main

# Start test infrastructure (postgres x2, airflow, dbt, kafka, ssh)
cd envi-test && docker compose up -d

# Run tests
python -m pytest test_agent.py -v      # 21 core tests
python -m pytest test_new_features.py  # connector/ephemeral/MCP tests
python -m pytest test_skills.py        # skills tests

# Check system status
python -m cli.main   # then type: /status or /connections or /skills
```

## Architecture (How Code Flows)

```
User prompt --> cli/main.py
  --> graphs/main_graph.py (LangGraph)
    --> agents/orchestrator/agent.py    # REASON: classify intent, create plan
      --> IF greeting/help → direct response → END
      --> IF clarify (ambiguous) → ask user → re-run with answer
      --> IF bootstrap can handle → execute bootstrap tool directly
      --> IF plan has multiple steps → CLI executes each step:
            --> bootstrap tool (run_query/call_api/read_files) → execute via gateway
            --> built tool exists → execute via gateway
            --> non-bootstrap tech (messaging/server/cloud):
                  --> connectors/manager.py: generate connector if missing (LLM)
                  --> get live client (cached, alive-pooled)
                  --> skills/registry.py: search matching skills → inject into prompt
                  --> connectors/executor.py: generate ephemeral code (LLM) → execute once
                  --> on success: offer skill promotion → save metadata + code
                  --> on connection failure: invalidate connector → regenerate next time
            --> bootstrap type but tool missing → redundancy gate check:
                  --> redundant → reject ("bootstrap handles this")
                  --> novel → agents/builder/agent.py (LLM generates code)
                      --> agents/tester/agent.py:
                            Phase 1: static validation (AST, imports, dangerous calls)
                            Phase 2a (read): direct execution in-process
                            Phase 2b (write/admin): Docker sandbox
                      --> IF pass → user approves → commit_tool() → execute
                      --> IF fail → retry with failure context
      --> IF question → synthesize answer from collected results
```

## File Map

### Entry Points
- `cli/main.py` -- REPL loop with trendy banner. `process_prompt()` is the reasoning pipeline. Shows agent thinking, handles approval for new tools, handles redundancy rejections, displays clarification questions.
- `cli/commands.py` -- Slash commands (`/schemas`, `/tools`, `/systems`, `/connections`, `/config`, etc.) that bypass the LLM. Database commands auto-detect which database to use. `/config` allows viewing and modifying runtime settings (timeouts, depth limits, etc.).
- `cli/init.py` -- `dataclaw init` command. Scaffolds `~/.dataclaw/` with config templates (connections.yaml, settings.yaml with local+API LLM options, .env for secrets) and required subdirectories.

### Graph (Orchestration)
- `graphs/main_graph.py` -- LangGraph StateGraph with 2 nodes (orchestrator, execute_tool). Has `_check_redundancy()` (redundancy gate), `build_tool_for_step()`, `commit_tool()` (thread-locked), `execute_plan_step()`. Gateway module is cached and reloaded only when tools are committed.
- `graphs/states.py` -- `DataClawState` TypedDict with `ReasoningStep` for the reasoning chain.

### Agents
- `agents/orchestrator/agent.py` -- **Reasoning agent**. `run(state)` classifies intent (greeting/help/clarify/action/question), creates reasoning plans via LLM, auto-resolves CLARIFY when only one technology matches. CLARIFY depth configurable via `max_clarify_depth`. No heuristic fallback — if LLM is unavailable, returns clear error with configuration hints. Key: `_llm_plan()`, `_normalize_plan()`.
- `agents/orchestrator/strategy.py` -- Technology inference utilities: `infer_technology()`, `infer_tool_name()`, `infer_params()`. Keyword patterns for postgres, airflow, dbt, kafka, ssh_server, snowflake, mysql, sqlite, mongodb, redis. `infer_technology()` validates results against actual connection keys and fuzzy-matches (e.g., "ssh" → "ssh_server"). Not used as fallback — LLM is required for planning.
- `agents/orchestrator/tool_finder.py` -- `find_tool()`, `search_tools_by_description()`. Scans `registry.json` for agent-built tools.
- `agents/orchestrator/prompts/planning_prompt.py` -- Reasoning prompt template with CLARIFY support. Shows available systems, bootstrap tools, built tools. Memory-aware.
- `agents/orchestrator/prompts/responses.py` -- Greeting/help responses. `get_help_response()` lists configured systems and built tools.
- `agents/builder/agent.py` -- `run(state)` builds a `ToolRequest`, calls LLM, validates. Returns `generated_code` + `manifest`.
- `agents/builder/prompts/generation_prompt.py` -- Generic prompt. Reads connection config shape to determine driver/library. Supports any technology (Kafka, SSH, MongoDB, etc.).
- `agents/builder/validator.py` -- `validate_tool()` checks: AST syntax, blocked imports (subprocess, ctypes, etc.), dangerous calls (eval, exec, compile, os.system, os.popen, __import__), function signature `(connection_config, **kwargs)`.
- `agents/tester/agent.py` -- **Two-phase tester**. Phase 1: `_static_validate()` via builder.validator. Phase 2: if `access_level == "read"` → `_direct_execute()` (in-process with threading timeout), else → Docker sandbox. `_detect_missing_imports()` pre-checks third-party libraries before execution — returns `MISSING_LIBRARIES` with pip package names if not installed. Redacts credentials in logs via `_redact_config()`.
- `agents/tester/test_generator.py` -- `generate_test_script()`. `_discover_real_entities()` probes live APIs/filesystems for real test data. `_build_test_kwargs()` filters out connection config keys to avoid garbage params.
- `agents/tester/reporter.py` -- `build_report()` classifies failures, checks stdout for hidden errors even when exit_code==0. `compute_score()` rates quality/safety/reusability.

### Contracts (Pydantic v2)
- `contracts/tool_request.py` -- `ToolRequest`: Orchestrator → Builder.
- `contracts/generated_tool.py` -- `GeneratedTool` + `ToolManifest`: Builder → Tester.
- `contracts/test_report.py` -- `TestReport` with `TestVerdict` and `FailureReason`: Tester → Orchestrator.

### MCP Tools
- `mcp-tools/gateway.py` -- Routes to bootstrap tools (`_bootstrap.py`) or technology-specific tools. Bootstrap tools are checked first. Returns `{"error": ...}` instead of raising on missing tools.
- `mcp-tools/registry.json` -- Index of **agent-built** tools only. Bootstrap tools are always available without registry.
- `mcp-tools/technologies/_bootstrap.py` -- **3 smart bootstrap tools**:
  - `run_query` -- Execute SQL against any database (auto-detects psycopg2/pymysql/sqlite from config). Tiered security: `_READ_BLOCKED_SQL` (all DML+DDL), `_WRITE_BLOCKED_SQL` (DDL/admin only), `_STACKED_QUERY` (blocks semicolons). DML statements return `{"affected_rows": N}` instead of crashing.
  - `call_api` -- HTTP requests to any REST API (auto-detects auth: basic/bearer/API key). Blocks write methods on read-only, allows GraphQL POST.
  - `read_files` -- Read/list/search/tree files on disk (path traversal protection, size guard).
- `mcp-tools/technologies/_template.py` -- Skeleton for new technology files created by the Builder.

**Tool interface**: Every tool is `def name(connection_config: dict, **kwargs) -> dict`. Every technology file has a `TOOLS` dict.

### Connectors (Non-Bootstrap Technologies)
- `connectors/manager.py` -- `ConnectionManager`: generates, caches, and serves live client connections. Singleton via `get_manager()`. Key: `get_client()` (alive-pooled), `save_connector()`, `invalidate()`, `invalidate_connector()`.
- `connectors/executor.py` -- Ephemeral code executor. `execute_ephemeral(code, client, config)` validates (AST, imports, dangerous calls) and runs LLM-generated code once in-process with timeout.
- `connectors/prompts.py` -- LLM prompts for connector and ephemeral code generation. `build_ephemeral_prompt()` auto-injects matching skills as context.
- `connectors/{tech}.py` -- Auto-generated connector files (e.g., `ssh_server.py`, `kafka.py`). Each has `def connect(connection_config) -> client`.

### Skills (Reusable Capability Patterns)
- `skills/models.py` -- `SkillMeta` (Pydantic v2): name, technology, description, tags, args, examples, success/fail counts, reliability. `SkillArg`, `SkillExample`.
- `skills/registry.py` -- `SkillRegistry`: discovers, indexes (mtime-cached), searches (by tech/intent/tags), CRUDs, and tracks stats for skills. Singleton via `get_registry()`. `build_skill_context()` generates prompt context for the LLM. `register_skill()` saves .skill.yaml + .py to disk.
- `skills/{technology}/{name}.skill.yaml` -- Skill metadata (YAML frontmatter: name, tags, args with defaults, examples, stats).
- `skills/{technology}/{name}.py` -- Code template with `def execute(client, connection_config, **kwargs) -> dict`.

**Skill lifecycle**: Ephemeral code runs successfully → user says "save as skill" → LLM extracts metadata (name, args, examples) → saved to `skills/{tech}/{name}.skill.yaml` + `.py` → next ephemeral prompt for same tech auto-injects matching skills as examples → LLM generates better code with correct kwargs and defaults.

### MCP Client
- `mcp_client/client.py` -- `MCPManager`: manages external MCP server processes via stdio transport. `MCPServer` handles individual servers. Tool discovery via JSON-RPC.

### Memory
- `memory/store.py` -- `MemoryStore` facade. `get_planning_context()` returns dict with conversation_history, known_entities, active_technology. `auto_catalog()` extracts entities from results.
- `memory/session.py` -- `SessionMemory`: in-memory, max `MAX_SESSION_TURNS` (20) turns. `add_turn(prompt, intent, technology, result_summary)`.
- `memory/catalog.py` -- `DataCatalog`: SQLite-backed. Tables: `entities`, `outcomes`. `store_entity(technology, entity_type, name, parent, metadata)`.
- `memory/episodic.py` -- Build/test outcome storage for pattern detection.
- `memory/short_term.py` -- Key-value store for current task state.
- `memory/long_term.py` -- ChromaDB-backed vector store (future).

### Sandbox
- `sandbox/executor/runner.py` -- Docker container execution. No subprocess fallback for untrusted code — returns hard failure if Docker unavailable.
- `sandbox/executor/container_manager.py` -- Docker SDK. `detect_dependencies()` auto-installs pip packages from imports. `PIP_NAME_MAP` handles special cases (kafka→kafka-python, confluent_kafka→confluent-kafka, etc.).
- `sandbox/security/network_policy.py` -- `_extract_all_network_targets()`: extracts ALL host:port pairs from connection config (direct, comma-separated lists like bootstrap_servers, URLs). Handles multi-endpoint configs.
- `sandbox/security/filesystem_policy.py` -- Read-only filesystem enforcement.

### Utils
- `utils/paths.py` -- **Centralized path resolution**. Resolves `~/.dataclaw/` (pip-installed mode) vs `PROJECT_ROOT/config/` (dev mode). All config/data directories go through this module. Key functions: `get_config_dir()`, `get_connections_path()`, `get_settings_path()`, `get_env_path()`, `get_mcp_tools_dir()`, `get_skills_dir()`, `get_connectors_dir()`, `get_catalog_path()`, `get_logs_dir()`.
- `utils/connections.py` -- **Unified connections loader**. Reads `config/connections.yaml`. Resolves `${VAR}` from `.env`. Key functions: `get_connection()`, `get_technology_type()`, `get_bootstrap_tool()`, `get_connection_summary()` (groups multi-instance technologies with CLARIFY hints), `get_connection_display_name()` (user-friendly: "analytics_db (localhost:5433, write)"), `resolve_user_reference()` (maps user text like "analytics_db", "port 5433", "analytics" back to connection key). `TYPE_TO_BOOTSTRAP` only maps database→run_query, api→call_api, filesystem→read_files (messaging/server/cloud have no bootstrap).
- `utils/constants.py` -- Runtime config reader. `get(key)` reads from `config/settings.yaml → runtime` with mtime caching. `get_all()`, `get_descriptions()`, `set_value()`. All values configurable via `/config` command. Keys: `llm_timeout_s`, `max_clarify_depth`, `max_build_attempts`, `builds_remaining`, `steps_remaining`, `max_observation_length`, `max_session_turns`, `default_query_limit`, `max_files_list`, `max_file_size_bytes`, `max_description_length`.
- `utils/llm_client.py` -- `call_llm()`. 3 providers: ollama, anthropic, openai. Per-agent config. SSL bypass for private endpoints.
- `utils/error_diagnoser.py` -- Pattern-matches errors to friendly messages.
- `utils/synthesizer.py` -- LLM-powered answer synthesis from multi-step results.

### Config
- `config/connections.yaml` -- **Single file for ALL technologies** (6 entries). Each entry has: type (database/api/filesystem/messaging/server/cloud), driver, access_level, connection params. `${VAR}` resolved from `.env`.
- `config/settings.yaml` -- LLM config (per-agent provider/model/base_url/api_key_env), sandbox config, general settings.
- `config/secrets/.env` -- Credentials. Gitignored.

### Test Environment
- `envi-test/` -- Docker-compose with 6 services: postgres (port 5432), postgres-analytics (port 5433), airflow (port 8080), dbt, kafka (KRaft mode, port 9092), ssh-server (port 2222). Each with init data/config.

### Tests
- `test_agent.py` -- 13 test functions across 13 sections: bootstrap tools, multi-DB disambiguation, orchestrator planning, tester static+direct, tool building, write actions, memory, redundancy gate, security, heuristic fallbacks, heuristic CLARIFY multi-DB, connection resolution helpers, missing library detection.

## Key Design Decisions

1. **Bootstrap-first** -- 3 generic tools handle most operations. Only build specialized tools when bootstrap can't do the job (messaging, server, cloud types).
2. **Single connections file** -- `config/connections.yaml` holds ALL technologies. No per-technology config files.
3. **Redundancy gate** -- Before building, check if bootstrap or existing tools already cover the request. Prevents tool sprawl.
4. **Two-phase testing** -- Static validation always runs. Execution mode depends on access_level: direct in-process for read-only (fast, same env), Docker sandbox for write/admin (isolated).
5. **CLARIFY, don't guess** -- When the request is ambiguous (e.g., "list tables" with 2 databases), the agent asks — both LLM and heuristic paths. Shows user-friendly display names ("analytics_db (localhost:5433, write)") not raw config keys. `resolve_user_reference()` maps user answers back to connection keys. Auto-resolves when only one option exists. Depth capped at 3 to prevent loops.
6. **Tiered SQL security** -- read blocks all DML+DDL, write allows DML but blocks DDL, admin allows everything. Stacked queries always blocked below admin.
7. **Generic builder** -- The generation prompt reads connection config shape to determine the driver. Supports any technology without hardcoded knowledge.
8. **Agents never import each other** -- only contracts. Communication is via `DataClawState` dict.
9. **No heuristic fallback** -- LLM is required for all data operations. If the LLM is unavailable or misconfigured, the agent returns a clear error message with configuration hints. Slash commands (`/schemas`, `/tables`, etc.) still work without LLM. All runtime parameters (timeouts, depth limits, etc.) are configurable via `/config`.
12. **Missing lib auto-install** -- Before direct execution, `_detect_missing_imports()` checks if third-party libraries exist via `importlib.util.find_spec()`. If missing, returns `MISSING_LIBRARIES` status. CLI asks user to approve `pip install`, then retries the build.
10. **Memory-aware planning** -- Orchestrator prompt includes conversation history, known entities, active technology.
11. **Credential redaction** -- Sensitive config values (password, secret, token, api_key) are masked in all log output.
13. **Connector + Ephemeral for non-bootstrap** -- Non-bootstrap technologies (messaging, server, cloud) use LLM-generated connectors (cached, alive-pooled) + ephemeral code (generated per-request, validated, executed once, discarded). No permanent tools needed.
14. **Skills as proven patterns** -- Successful ephemeral code can be promoted to skills. Skills carry metadata (args with defaults, examples, tags, stats). The ephemeral prompt auto-injects matching skills as context so the LLM generates correct code with proper kwargs and defaults on the first try.
15. **Skill promotion is opt-in** -- After successful ephemeral execution, user is asked "Save as reusable skill? [y/N]". LLM extracts metadata (name, args, examples) automatically. Skills are never auto-promoted.

## Common Patterns

### Adding a new technology
1. Add entry in `config/connections.yaml` with type, driver, access_level, connection params
2. That's it. Bootstrap tools, connectors, or the Builder handle everything else.

### Changing the LLM model
Edit `config/settings.yaml` under `model.orchestrator` and/or `model.builder`. Use `api_key_env` to reference env var from `config/secrets/.env`.

### Adding a new slash command
Add a `@command("name", "description", "usage")` decorated function in `cli/commands.py`.

## What NOT To Do

- Do NOT create per-technology connection files -- use single `config/connections.yaml`
- Do NOT create static tool files (like the old postgres.py with list_schemas) -- bootstrap handles it
- Do NOT hardcode technology knowledge in the builder -- the LLM figures it out from config shape
- Do NOT import agents from other agents -- use contracts only
- Do NOT run generated tools outside the sandbox (unless read-only via direct execution)
- Do NOT hardcode test data -- use `_discover_real_entities()` pattern
- Do NOT store API keys in settings.yaml -- use `api_key_env` referencing `.env`
- Do NOT write static workarounds for LLM quality -- if the LLM is the bottleneck, say so
- Do NOT build tools for things bootstrap already handles -- the redundancy gate will reject them
