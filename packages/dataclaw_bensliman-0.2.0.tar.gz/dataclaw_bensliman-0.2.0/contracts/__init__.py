"""DataClaw contracts — Pydantic v2 models for inter-agent communication."""
