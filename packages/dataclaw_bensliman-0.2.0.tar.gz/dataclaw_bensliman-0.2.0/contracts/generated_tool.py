"""Contract: Builder -> Tester.

The Builder sends a GeneratedTool to the Tester after generating
the Python source code for a new or refactored tool.
"""

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class ToolManifest(BaseModel):
    """Metadata about the generated tool for registry and execution."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        extra="forbid",
        validate_assignment=True,
    )

    name: str = Field(..., description="Tool function name")
    description: str = Field(..., description="One-line description of what the tool does")
    input_schema: dict = Field(
        default_factory=dict, description="Input parameters and their types"
    )
    output_schema: dict = Field(
        default_factory=dict, description="Output structure and types"
    )


class GeneratedTool(BaseModel):
    """Builder sends this to Tester with the generated tool code for validation."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        extra="forbid",
        validate_assignment=True,
    )

    task_id: str = Field(..., description="Unique identifier matching the original ToolRequest")
    tool_name: str = Field(..., description="Name of the generated tool function")
    tool_code: str = Field(..., description="The actual Python source code as a string")
    technology: str = Field(
        ..., description="Which technology file to save to: postgres, snowflake, etc."
    )
    version: int = Field(default=1, description="Version number, incremented on refactor")
    manifest: ToolManifest = Field(
        ..., description="Tool metadata for registry and execution"
    )
    test_hints: list[str] = Field(
        default_factory=list,
        description="Hints for the tester: 'needs postgres running', 'expects schema public', etc.",
    )
