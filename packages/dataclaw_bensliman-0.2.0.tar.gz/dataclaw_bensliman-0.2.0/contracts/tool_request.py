"""Contract: Orchestrator -> Builder.

The Orchestrator sends a ToolRequest to the Builder when it determines
that a new tool needs to be created or an existing tool needs refactoring.
"""

from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class TaskAction(str, Enum):
    """What the Builder should do with this request."""

    BUILD_NEW = "build_new"
    REFACTOR = "refactor"
    REUSE = "reuse"


class ToolRequest(BaseModel):
    """Orchestrator sends this to Builder to request tool creation or modification."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        extra="forbid",
        validate_assignment=True,
    )

    task_id: str = Field(..., description="Unique identifier for this task")
    action: TaskAction = Field(..., description="What to do: build_new, refactor, or reuse")
    tool_name: str = Field(..., description="Name of the tool to build or modify")
    tool_description: str = Field(..., description="What the tool should do")
    connection_type: str = Field(
        ..., description="Target technology: postgres, snowflake, mysql, etc."
    )
    input_schema: dict = Field(
        default_factory=dict, description="Expected input parameters for the tool"
    )
    output_schema: dict = Field(
        default_factory=dict, description="Expected output structure from the tool"
    )
    constraints: list[str] = Field(
        default_factory=list,
        description="Rules the tool must follow: read_only, timeout, etc.",
    )
    retry_context: Optional[str] = Field(
        default=None,
        description="Why the previous attempt failed — from TestReport",
    )
