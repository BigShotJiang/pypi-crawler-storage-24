"""Contract: Tester -> Orchestrator.

The Tester sends a TestReport back to the Orchestrator with the
results of running the generated tool in the sandbox.
"""

from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class TestVerdict(str, Enum):
    """Outcome of the test execution."""

    PASS = "pass"
    FAIL = "fail"
    ERROR = "error"


class FailureReason(str, Enum):
    """Structured failure categories for the Builder to act on."""

    CONNECTION_REFUSED = "connection_refused"
    SCHEMA_MISMATCH = "schema_mismatch"
    TIMEOUT = "timeout"
    SYNTAX_ERROR = "syntax_error"
    IMPORT_ERROR = "import_error"
    RUNTIME_ERROR = "runtime_error"
    OUTPUT_MISMATCH = "output_mismatch"


class TestReport(BaseModel):
    """Tester sends this to Orchestrator with sandbox execution results."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        extra="forbid",
        validate_assignment=True,
    )

    task_id: str = Field(..., description="Unique identifier matching the original ToolRequest")
    tool_name: str = Field(..., description="Name of the tool that was tested")
    verdict: TestVerdict = Field(..., description="Overall test result: pass, fail, or error")
    tests_run: int = Field(default=0, description="Total number of tests executed")
    tests_passed: int = Field(default=0, description="Number of tests that passed")
    execution_time_ms: int = Field(default=0, description="Total execution time in milliseconds")
    failure_reason: Optional[FailureReason] = Field(
        default=None,
        description="Structured failure category when verdict is fail or error",
    )
    failure_details: Optional[str] = Field(
        default=None, description="Full traceback or error details"
    )
    sandbox_logs: Optional[str] = Field(
        default=None, description="Raw stdout/stderr from sandbox execution"
    )
