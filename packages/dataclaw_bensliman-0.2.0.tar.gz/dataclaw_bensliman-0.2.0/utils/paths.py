"""Central path resolution — finds config, data, and tool directories.

Resolution order for config files:
  1. DATACLAW_CONFIG_DIR env var (if set — explicit override)
  2. PROJECT_ROOT/config/   (dev mode — running from source, if config exists)
  3. ~/.dataclaw/           (pip-installed mode)

This means:
  - `git clone` + `python -m cli.main`       → uses project root config/
  - `pip install dataclaw` + `dataclaw init` → uses ~/.dataclaw/
  - DATACLAW_CONFIG_DIR=/custom/path         → uses that path
"""

import os
from pathlib import Path

# Project root (where the source code lives)
PROJECT_ROOT = Path(__file__).parent.parent

# User home directory for dataclaw
USER_DATA_DIR = Path.home() / ".dataclaw"


def _is_dev_mode() -> bool:
    """Check if running from source (dev mode) with local config."""
    return (PROJECT_ROOT / "config" / "connections.yaml").exists()


def _user_dir_exists() -> bool:
    """Check if ~/.dataclaw/ exists (pip-installed mode)."""
    return USER_DATA_DIR.is_dir()


def get_config_dir() -> Path:
    """Get the config directory.

    Priority: env var > dev mode (project config/) > ~/.dataclaw/
    """
    # Explicit override
    env_dir = os.environ.get("DATACLAW_CONFIG_DIR")
    if env_dir:
        return Path(env_dir)
    # Dev mode: running from source with local config
    if _is_dev_mode():
        return PROJECT_ROOT / "config"
    # Pip-installed mode
    if _user_dir_exists() and (USER_DATA_DIR / "settings.yaml").exists():
        return USER_DATA_DIR
    return PROJECT_ROOT / "config"


def get_connections_path() -> Path:
    """Get the path to connections.yaml."""
    cfg = get_config_dir()
    return cfg / "connections.yaml"


def get_settings_path() -> Path:
    """Get the path to settings.yaml."""
    cfg = get_config_dir()
    return cfg / "settings.yaml"


def get_env_path() -> Path:
    """Get the path to .env secrets file."""
    cfg = get_config_dir()
    # In ~/.dataclaw/ mode, .env is at ~/.dataclaw/.env
    # In dev mode, it's at config/secrets/.env
    user_env = cfg / ".env"
    if user_env.exists():
        return user_env
    return cfg / "secrets" / ".env"


def get_mcp_tools_dir() -> Path:
    """Get the mcp-tools directory."""
    if _is_dev_mode():
        return PROJECT_ROOT / "mcp-tools"
    if _user_dir_exists() and (USER_DATA_DIR / "mcp-tools").is_dir():
        return USER_DATA_DIR / "mcp-tools"
    return PROJECT_ROOT / "mcp-tools"


def get_registry_path() -> Path:
    """Get the path to registry.json."""
    return get_mcp_tools_dir() / "registry.json"


def get_technologies_dir() -> Path:
    """Get the mcp-tools/technologies directory."""
    return get_mcp_tools_dir() / "technologies"


def get_skills_dir() -> Path:
    """Get the skills directory."""
    if _is_dev_mode():
        return PROJECT_ROOT / "skills"
    if _user_dir_exists() and (USER_DATA_DIR / "skills").is_dir():
        return USER_DATA_DIR / "skills"
    return PROJECT_ROOT / "skills"


def get_connectors_dir() -> Path:
    """Get the connectors directory."""
    if _is_dev_mode():
        return PROJECT_ROOT / "connectors"
    if _user_dir_exists() and (USER_DATA_DIR / "connectors").is_dir():
        return USER_DATA_DIR / "connectors"
    return PROJECT_ROOT / "connectors"


def get_catalog_path() -> Path:
    """Get the path to catalog.db."""
    if _is_dev_mode():
        return PROJECT_ROOT / "memory" / "catalog.db"
    if _user_dir_exists():
        return USER_DATA_DIR / "catalog.db"
    return PROJECT_ROOT / "memory" / "catalog.db"


def get_logs_dir() -> Path:
    """Get the logs directory."""
    if _is_dev_mode():
        d = PROJECT_ROOT / "logs"
        d.mkdir(exist_ok=True)
        return d
    if _user_dir_exists():
        d = USER_DATA_DIR / "logs"
        d.mkdir(exist_ok=True)
        return d
    d = PROJECT_ROOT / "logs"
    d.mkdir(exist_ok=True)
    return d
