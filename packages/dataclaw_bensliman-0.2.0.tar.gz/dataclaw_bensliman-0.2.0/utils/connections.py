"""Unified connections loader — reads config/connections.yaml.

Single source of truth for all technology connections.
Resolves ${VAR} placeholders from config/secrets/.env.
"""

import logging
import os
import re
from pathlib import Path
from typing import Optional

import yaml

logger = logging.getLogger(__name__)

# Connection config cache (invalidated when file changes on disk)
_connections_cache: dict[str, dict] | None = None
_connections_mtime: float = 0.0

from utils.paths import get_config_dir, get_connections_path, get_env_path

CONFIG_DIR = get_config_dir()
CONNECTIONS_PATH = get_connections_path()
LEGACY_CONNECTIONS_DIR = CONFIG_DIR / "connections"
ENV_PATH = get_env_path()

# Technology type → bootstrap tool mapping
TYPE_TO_BOOTSTRAP = {
    "database": "run_query",
    "api": "call_api",
    "filesystem": "read_files",
    # messaging/server/cloud have no bootstrap — agent builds tools from scratch
}


def _load_env_vars() -> dict[str, str]:
    """Load environment variables from config/secrets/.env."""
    env_vars: dict[str, str] = {}
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                env_vars[key.strip()] = value.strip()
    return env_vars


def _resolve_env(value: str, env_vars: dict[str, str]) -> str:
    """Resolve ${VAR_NAME} placeholders in a string."""
    if not isinstance(value, str) or "${" not in value:
        return value
    pattern = re.compile(r"\$\{(\w+)\}")
    def replacer(m: re.Match) -> str:
        var_name = m.group(1)
        return env_vars.get(var_name, os.environ.get(var_name, m.group(0)))
    return pattern.sub(replacer, value)


def _resolve_config(config: dict, env_vars: dict[str, str]) -> dict:
    """Recursively resolve all ${VAR} placeholders in a config dict."""
    resolved = {}
    for k, v in config.items():
        if isinstance(v, str):
            resolved[k] = _resolve_env(v, env_vars)
        elif isinstance(v, dict):
            resolved[k] = _resolve_config(v, env_vars)
        else:
            resolved[k] = v
    return resolved


def invalidate_connections_cache() -> None:
    """Invalidate the connections cache. Call after modifying connections.yaml."""
    global _connections_cache
    _connections_cache = None


def load_all_connections() -> dict[str, dict]:
    """Load all technology connections from connections.yaml.

    Results are cached and only re-read when the file changes on disk.

    Returns:
        Dict mapping technology name to its full config:
        {
            "postgres": {
                "type": "database",
                "driver": "psycopg2",
                "access_level": "read",
                "connection": {...resolved...}
            },
            ...
        }
    """
    global _connections_cache, _connections_mtime

    # Return cache if file hasn't changed
    if CONNECTIONS_PATH.exists():
        current_mtime = CONNECTIONS_PATH.stat().st_mtime
        if _connections_cache is not None and current_mtime == _connections_mtime:
            return _connections_cache
    elif _connections_cache is not None:
        return _connections_cache

    env_vars = _load_env_vars()

    # Try new unified format first
    if CONNECTIONS_PATH.exists():
        raw = yaml.safe_load(CONNECTIONS_PATH.read_text(encoding="utf-8"))
        technologies = raw.get("technologies") or {}
        result = {}
        for tech_name, tech_config in technologies.items():
            resolved = _resolve_config(tech_config, env_vars)
            result[tech_name] = resolved
        logger.info(f"Loaded {len(result)} technologies from connections.yaml")
        _connections_cache = result
        _connections_mtime = current_mtime
        return result

    # Fallback: legacy per-technology files
    if LEGACY_CONNECTIONS_DIR.exists():
        result = {}
        for f in LEGACY_CONNECTIONS_DIR.glob("*.yaml"):
            try:
                data = yaml.safe_load(f.read_text())
                tech = data.get("technology", f.stem)
                conn = _resolve_config(data.get("connection", {}), env_vars)
                result[tech] = {
                    "type": _infer_type(data, conn),
                    "driver": data.get("driver", ""),
                    "access_level": "read",
                    "connection": conn,
                }
            except Exception as e:
                logger.warning(f"Failed to load {f}: {e}")
        logger.info(f"Loaded {len(result)} technologies from legacy connections/")
        _connections_cache = result
        _connections_mtime = 0.0
        return result

    logger.warning("No connections config found")
    return {}


def get_connection(technology: str) -> dict:
    """Get the resolved connection config for a specific technology.

    Returns the 'connection' sub-dict with _access_level injected
    (used by bootstrap tools for security checks).

    Args:
        technology: Technology name (e.g., "postgres")
    Returns:
        Connection config dict, or empty dict if not found.
    """
    all_conns = load_all_connections()
    tech_config = all_conns.get(technology, {})
    if not tech_config:
        return {}

    connection = dict(tech_config.get("connection", {}))
    # Inject access level for bootstrap tool security checks
    connection["_access_level"] = tech_config.get("access_level", "read")
    return connection


def get_technology_type(technology: str) -> str:
    """Get the type of a technology (database, api, filesystem, etc.).

    Args:
        technology: Technology name
    Returns:
        Type string, or "unknown" if not found.
    """
    all_conns = load_all_connections()
    tech_config = all_conns.get(technology, {})
    return tech_config.get("type", "unknown")


def get_bootstrap_tool(technology: str) -> str:
    """Get the appropriate bootstrap tool for a technology.

    Args:
        technology: Technology name
    Returns:
        Bootstrap tool name (run_query, call_api, or read_files).
    """
    tech_type = get_technology_type(technology)
    return TYPE_TO_BOOTSTRAP.get(tech_type, "call_api")


def list_configured_technologies() -> list[dict]:
    """List all configured technologies with their types.

    Returns:
        List of dicts with name, type, driver, access_level.
    """
    all_conns = load_all_connections()
    result = []
    for name, config in all_conns.items():
        result.append({
            "name": name,
            "type": config.get("type", "unknown"),
            "driver": config.get("driver", ""),
            "access_level": config.get("access_level", "read"),
        })
    return result


def get_connection_summary() -> str:
    """Get a human-readable summary of all connections for LLM prompts.

    Groups connections by technology type (e.g., multiple PostgreSQL databases
    are shown together so the LLM understands the disambiguation needed).

    Returns:
        Formatted string describing each technology and how to access it.
    """
    all_conns = load_all_connections()
    if not all_conns:
        return "(no technologies configured)"

    # Group by driver/type for intelligent display
    groups: dict[str, list[dict]] = {}
    for name, config in all_conns.items():
        driver = config.get("driver", "")
        tech_type = config.get("type", "unknown")
        # Group key: driver name (e.g., "psycopg2") or type if no driver
        group_key = driver or tech_type
        if group_key not in groups:
            groups[group_key] = []
        groups[group_key].append({"name": name, **config})

    lines = []
    for group_key, entries in groups.items():
        tech_type = entries[0].get("type", "unknown")
        bootstrap = TYPE_TO_BOOTSTRAP.get(tech_type)

        if len(entries) > 1:
            # Multiple instances — highlight this for the LLM
            driver_label = entries[0].get("driver", tech_type).upper()
            lines.append(f"### {driver_label} — {len(entries)} instances (CLARIFY if user doesn't specify)")

        for entry in entries:
            name = entry["name"]
            access = entry.get("access_level", "read")
            conn = entry.get("connection", {})

            if tech_type == "database":
                host = conn.get("host", "?")
                port = conn.get("port", "")
                db = conn.get("database", "")
                desc = f"{host}:{port}/{db}" if port else f"{host}/{db}"
                instance_label = f"database={db}"
            elif tech_type == "api":
                desc = conn.get("base_url", "?")
                instance_label = desc
            elif tech_type == "filesystem":
                desc = conn.get("project_dir", conn.get("path", "?"))
                instance_label = desc
            else:
                desc = ", ".join(f"{k}" for k in conn.keys() if not k.startswith("_"))
                instance_label = desc

            bootstrap_str = f"bootstrap: {bootstrap}" if bootstrap else "no bootstrap — agent builds tools"
            lines.append(
                f"- **{name}** (type: {tech_type}, access: {access})\n"
                f"  Location: {desc}\n"
                f"  {bootstrap_str}"
            )

            # For grouped entries, add the user-friendly identifier
            if len(entries) > 1 and tech_type == "database":
                db_name = conn.get("database", "")
                port_val = conn.get("port", "")
                lines.append(
                    f"  → User might refer to this as: \"{db_name}\", \"{name}\", or \"port {port_val}\""
                )

    return "\n".join(lines)


def get_connection_display_name(tech_key: str) -> str:
    """Get a user-friendly display name for a connection key.

    Example: "postgres_analytics" → "analytics_db (localhost:5433, write)"
    """
    all_conns = load_all_connections()
    config = all_conns.get(tech_key, {})
    if not config:
        return tech_key

    tech_type = config.get("type", "unknown")
    access = config.get("access_level", "read")
    conn = config.get("connection", {})

    if tech_type == "database":
        db = conn.get("database", "?")
        host = conn.get("host", "localhost")
        port = conn.get("port", "")
        return f"{db} ({host}:{port}, {access})"
    elif tech_type == "api":
        return f"{conn.get('base_url', '?')} ({access})"
    elif tech_type == "filesystem":
        path = conn.get("project_dir", conn.get("path", "?"))
        return f"{path} ({access})"
    else:
        return f"{tech_key} ({tech_type}, {access})"


def resolve_user_reference(user_text: str) -> Optional[str]:
    """Resolve a user's natural-language reference to a connection key.

    Maps things like "analytics_db", "the analytics one", "port 5433"
    back to the connection key like "postgres_analytics".

    Prioritizes: exact key match > exact db name match > port match > partial name match.
    For partial matches, longer matches win to avoid "postgres" matching before "postgres_analytics".

    Returns connection key or None if no match.
    """
    all_conns = load_all_connections()
    user_lower = user_text.lower().strip()

    # Pass 1: Direct exact match on connection key
    for name in all_conns:
        if name.lower() == user_lower:
            return name

    # Pass 2: Exact match on database name
    for name, config in all_conns.items():
        conn = config.get("connection", {})
        db_name = conn.get("database", "").lower()
        if db_name and db_name == user_lower:
            return name

    # Pass 3: Database name contained in input (longer names first to avoid "postgres" < "postgres_analytics")
    db_matches = []
    for name, config in all_conns.items():
        conn = config.get("connection", {})
        db_name = conn.get("database", "").lower()
        if db_name and db_name in user_lower:
            db_matches.append((len(db_name), name))
    if db_matches:
        db_matches.sort(reverse=True)  # longest match first
        return db_matches[0][1]

    # Pass 4: Port match
    for name, config in all_conns.items():
        conn = config.get("connection", {})
        port = str(conn.get("port", ""))
        if port and f"port {port}" in user_lower:
            return name

    # Pass 5: Base URL match
    for name, config in all_conns.items():
        conn = config.get("connection", {})
        base_url = conn.get("base_url", "").lower()
        if base_url and base_url in user_lower:
            return name

    # Pass 6: Partial name match — but only on non-generic parts
    # "analytics" should match "postgres_analytics" but "postgres" alone shouldn't
    # when there are multiple postgres connections
    partial_matches = []
    for name, config in all_conns.items():
        name_parts = name.lower().replace("_", " ").split()
        # Skip generic technology-type words for partial matching
        generic = {"postgres", "mysql", "sqlite", "snowflake", "mongo", "redis", "api", "server"}
        specific_parts = [p for p in name_parts if p not in generic and len(p) > 3]
        for part in specific_parts:
            if part in user_lower:
                partial_matches.append((len(part), name))
    if partial_matches:
        partial_matches.sort(reverse=True)
        return partial_matches[0][1]

    # Pass 7: Connection key name appears as a word in user text
    # e.g., "show schemas on postgres" → matches key "postgres"
    # Longer key names win (postgres_analytics > postgres)
    import re as _re
    key_in_text = []
    for name in all_conns:
        # Check if the connection key appears as a whole word in the user text
        if _re.search(r'\b' + _re.escape(name.lower()) + r'\b', user_lower):
            key_in_text.append((len(name), name))
    if key_in_text:
        key_in_text.sort(reverse=True)  # longest match first
        return key_in_text[0][1]

    # Pass 8: Check if user_lower exactly equals a connection key (substring)
    # e.g., "postgres" when only one connection starts with it
    key_matches = [name for name in all_conns if user_lower in name.lower()]
    if len(key_matches) == 1:
        return key_matches[0]

    return None


def _infer_type(data: dict, conn: dict) -> str:
    """Infer technology type from legacy config."""
    driver = data.get("driver", "")
    if driver in ("psycopg2", "pymysql", "sqlite3"):
        return "database"
    if driver in ("requests", "httpx"):
        return "api"
    if driver in ("filesystem", "pathlib"):
        return "filesystem"
    if conn.get("base_url"):
        return "api"
    if conn.get("project_dir") or conn.get("path"):
        return "filesystem"
    if conn.get("host") and conn.get("port"):
        return "database"
    return "unknown"
