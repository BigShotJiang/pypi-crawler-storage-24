"""Shared LLM client — all agents call their configured LLM through this module.

Supports multiple providers:
  - ollama:    Local models via Ollama API
  - anthropic: Claude via Anthropic API
  - openai:    OpenAI-compatible APIs (OpenAI, Groq, Together, etc.)

Each agent (orchestrator, builder) can use a different provider and model.
Configuration lives in config/settings.yaml, secrets in config/secrets/.env.
"""

import logging
import os
import re
from pathlib import Path
from typing import Optional

import httpx
import yaml

logger = logging.getLogger(__name__)

from utils.paths import get_settings_path, get_env_path
SETTINGS_PATH = get_settings_path()
ENV_PATH = get_env_path()


def _get_timeout() -> float:
    """Get LLM timeout from runtime config."""
    from utils.constants import get
    return float(get("llm_timeout_s"))

# Cache for env vars (read once, reused across calls)
_env_cache: dict[str, str] | None = None
_env_mtime: float = 0.0


def _load_env_vars() -> dict[str, str]:
    """Load environment variables from config/secrets/.env (cached)."""
    global _env_cache, _env_mtime
    if ENV_PATH.exists():
        current_mtime = ENV_PATH.stat().st_mtime
        if _env_cache is not None and current_mtime == _env_mtime:
            return _env_cache
        env_vars: dict[str, str] = {}
        for line in ENV_PATH.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                env_vars[key.strip()] = value.strip()
        _env_cache = env_vars
        _env_mtime = current_mtime
        return env_vars
    return {}


def _resolve_env(value: str) -> str:
    """Resolve ${VAR_NAME} placeholders in a string."""
    if not isinstance(value, str) or "${" not in value:
        return value
    env_vars = _load_env_vars()
    pattern = re.compile(r"\$\{(\w+)\}")
    def replacer(m: re.Match) -> str:
        var_name = m.group(1)
        return env_vars.get(var_name, os.environ.get(var_name, m.group(0)))
    return pattern.sub(replacer, value)


def load_model_config() -> dict:
    """Load model configuration from config/settings.yaml.

    Returns:
        Dict with top-level model config and per-agent overrides.
    """
    if SETTINGS_PATH.exists():
        settings = yaml.safe_load(SETTINGS_PATH.read_text())
        return settings.get("model", {})
    return {}


def _get_agent_config(config: dict, agent: Optional[str] = None) -> dict:
    """Resolve the full config for a specific agent.

    Supports two config styles:

    Flat (legacy/simple):
        model:
          provider: ollama
          base_url: http://localhost:11434
          orchestrator: qwen2.5:7b
          builder: qwen2.5-coder:7b

    Per-agent (recommended):
        model:
          orchestrator:
            provider: anthropic
            model: claude-sonnet-4-20250514
            api_key: ${ANTHROPIC_API_KEY}
          builder:
            provider: anthropic
            model: claude-sonnet-4-20250514
            api_key: ${ANTHROPIC_API_KEY}

    Args:
        config: Full model config dict from settings.yaml.
        agent: Agent name ('orchestrator', 'builder') or None.
    Returns:
        Resolved config dict with provider, model, api_key, base_url, temperature.
    """
    # Check if per-agent config exists (nested dict)
    if agent and agent in config and isinstance(config[agent], dict):
        agent_cfg = dict(config[agent])
        # Resolve api_key: supports api_key_env (env var name) or api_key (direct/${VAR})
        if "api_key_env" in agent_cfg:
            env_vars = _load_env_vars()
            env_name = agent_cfg.pop("api_key_env")
            agent_cfg["api_key"] = env_vars.get(env_name, os.environ.get(env_name, ""))
        elif "api_key" in agent_cfg:
            agent_cfg["api_key"] = _resolve_env(agent_cfg["api_key"])
        if "base_url" in agent_cfg:
            agent_cfg["base_url"] = _resolve_env(agent_cfg["base_url"])
        return agent_cfg

    # Flat config style (legacy) — agent value is just the model name
    provider = config.get("provider", "ollama")
    base_url = config.get("base_url", "http://localhost:11434")
    temperature = config.get("temperature", 0.2)
    model_name = config.get(agent, config.get("model_name", "qwen2.5:7b")) if agent else config.get("model_name", "qwen2.5:7b")

    return {
        "provider": provider,
        "model": model_name,
        "base_url": base_url,
        "temperature": temperature,
    }


class LLMError(Exception):
    """Raised when the LLM call fails."""

    def __init__(self, reason: str, details: str = "") -> None:
        self.reason = reason
        self.details = details
        super().__init__(f"{reason}: {details}" if details else reason)


# ── Provider implementations ─────────────────────────


async def _call_ollama(
    system_prompt: str, user_prompt: str, agent_config: dict
) -> str:
    """Call Ollama's /api/chat endpoint."""
    base_url = agent_config.get("base_url", "http://localhost:11434")
    model = agent_config["model"]
    temperature = agent_config.get("temperature", 0.2)

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "stream": False,
        "options": {"temperature": temperature},
    }

    timeout = _get_timeout()
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(f"{base_url}/api/chat", json=payload)
            response.raise_for_status()
    except httpx.TimeoutException:
        raise LLMError("timeout", f"Ollama did not respond within {timeout:.0f}s at {base_url}")
    except httpx.ConnectError:
        raise LLMError("connection_refused", f"Cannot connect to Ollama at {base_url}. Is it running?")
    except httpx.HTTPStatusError as e:
        raise LLMError("http_error", f"Ollama returned {e.response.status_code}: {e.response.text[:500]}")
    except httpx.HTTPError as e:
        raise LLMError("http_error", str(e))

    try:
        result = response.json()
    except Exception:
        raise LLMError("invalid_response", "Ollama returned non-JSON response")

    content = result.get("message", {}).get("content", "")
    if not content:
        raise LLMError("empty_response", "Ollama returned an empty message")
    return content


async def _call_anthropic(
    system_prompt: str, user_prompt: str, agent_config: dict
) -> str:
    """Call Anthropic's Messages API (Claude)."""
    api_key = agent_config.get("api_key", "")
    if not api_key:
        raise LLMError("config_error", "Anthropic API key not set. Add api_key to model config or ANTHROPIC_API_KEY to secrets/.env")

    model = agent_config.get("model", "claude-sonnet-4-20250514")
    temperature = agent_config.get("temperature", 0.2)
    max_tokens = agent_config.get("max_tokens", 4096)
    base_url = agent_config.get("base_url", "https://api.anthropic.com")

    payload = {
        "model": model,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "system": system_prompt,
        "messages": [
            {"role": "user", "content": user_prompt},
        ],
    }

    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }

    timeout = _get_timeout()
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                f"{base_url}/v1/messages",
                json=payload,
                headers=headers,
            )
            response.raise_for_status()
    except httpx.TimeoutException:
        raise LLMError("timeout", f"Anthropic API did not respond within {timeout:.0f}s")
    except httpx.ConnectError:
        raise LLMError("connection_refused", f"Cannot connect to Anthropic API at {base_url}")
    except httpx.HTTPStatusError as e:
        raise LLMError("http_error", f"Anthropic returned {e.response.status_code}: {e.response.text[:500]}")
    except httpx.HTTPError as e:
        raise LLMError("http_error", str(e))

    try:
        result = response.json()
    except Exception:
        raise LLMError("invalid_response", "Anthropic returned non-JSON response")

    # Extract text from content blocks
    content_blocks = result.get("content", [])
    text_parts = [b.get("text", "") for b in content_blocks if b.get("type") == "text"]
    content = "\n".join(text_parts)

    if not content:
        raise LLMError("empty_response", "Anthropic returned an empty message")
    return content


async def _call_openai(
    system_prompt: str, user_prompt: str, agent_config: dict
) -> str:
    """Call OpenAI-compatible chat completions API.

    Works with: OpenAI, Groq, Together, Mistral, any OpenAI-compatible endpoint.
    Includes retry with exponential backoff for rate limiting (429).
    """
    import asyncio as _asyncio

    api_key = agent_config.get("api_key", "")
    if not api_key:
        raise LLMError("config_error", "API key not set for OpenAI-compatible provider")

    model = agent_config.get("model", "gpt-4o")
    temperature = agent_config.get("temperature", 0.2)
    max_tokens = agent_config.get("max_tokens", 4096)
    base_url = agent_config.get("base_url", "https://api.openai.com/v1").rstrip("/")

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    max_retries = 4
    last_error = None

    # Skip SSL verification for private/internal API endpoints
    verify_ssl = not any(h in base_url for h in ("dadispace.com", "localhost", "127.0.0.1"))

    timeout = _get_timeout()
    for attempt in range(max_retries):
        try:
            async with httpx.AsyncClient(timeout=timeout, verify=verify_ssl) as client:
                response = await client.post(
                    f"{base_url}/chat/completions",
                    json=payload,
                    headers=headers,
                )
                response.raise_for_status()
            break  # success
        except httpx.TimeoutException:
            raise LLMError("timeout", f"API did not respond within {timeout:.0f}s at {base_url}")
        except httpx.ConnectError:
            raise LLMError("connection_refused", f"Cannot connect to API at {base_url}")
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429 and attempt < max_retries - 1:
                # Rate limited -- back off and retry
                wait = (attempt + 1) * 2  # 2s, 4s, 6s
                retry_after = e.response.headers.get("retry-after")
                if retry_after:
                    try:
                        wait = max(float(retry_after), wait)
                    except ValueError:
                        pass
                logger.info(f"Rate limited (429), retrying in {wait}s (attempt {attempt + 1}/{max_retries})")
                await _asyncio.sleep(wait)
                last_error = e
                continue
            raise LLMError("http_error", f"API returned {e.response.status_code}: {e.response.text[:500]}")
        except httpx.HTTPError as e:
            raise LLMError("http_error", str(e))
    else:
        # All retries exhausted
        raise LLMError("rate_limited", f"Rate limited after {max_retries} retries. Last: {last_error}")

    try:
        result = response.json()
    except Exception:
        raise LLMError("invalid_response", "API returned non-JSON response")

    choices = result.get("choices", [])
    if not choices:
        raise LLMError("empty_response", "API returned no choices")
    content = choices[0].get("message", {}).get("content", "")
    if not content:
        raise LLMError("empty_response", "API returned an empty message")
    return content


# ── Provider dispatch ────────────────────────────────

_PROVIDERS = {
    "ollama": _call_ollama,
    "anthropic": _call_anthropic,
    "openai": _call_openai,
}


async def call_llm(
    system_prompt: str,
    user_prompt: str,
    config: Optional[dict] = None,
    agent: Optional[str] = None,
) -> str:
    """Call the configured LLM and return the raw text response.

    Args:
        system_prompt: The system message (agent identity + rules).
        user_prompt: The user message (task-specific context).
        config: Optional full model config override. If None, reads from settings.yaml.
        agent: Agent name for per-agent model selection ('orchestrator', 'builder').
    Returns:
        Raw text response from the LLM.
    Raises:
        LLMError: On timeout, connection refused, config error, or invalid response.
    """
    if config is None:
        config = load_model_config()

    agent_config = _get_agent_config(config, agent)
    provider = agent_config.get("provider", "ollama")
    model = agent_config.get("model", "unknown")

    logger.info(f"LLM call: provider={provider}, model={model}, agent={agent or 'default'}, prompt_len={len(user_prompt)}")

    call_fn = _PROVIDERS.get(provider)
    if call_fn is None:
        raise LLMError("config_error", f"Unknown provider '{provider}'. Supported: {', '.join(_PROVIDERS.keys())}")

    content = await call_fn(system_prompt, user_prompt, agent_config)
    logger.debug(f"LLM response: {len(content)} chars")
    return content
