"""DataClaw utilities — shared helpers used across agents."""
