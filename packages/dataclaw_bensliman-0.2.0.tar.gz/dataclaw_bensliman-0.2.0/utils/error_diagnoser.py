"""Smart error diagnosis — turns raw exceptions into user-friendly messages.

Pattern-matches common database, network, and service errors and returns
clear explanations with actionable fix suggestions.
"""

import logging
import re

logger = logging.getLogger(__name__)

# (pattern, technology_filter, friendly_message)
# technology_filter: None = any tech, "postgres" = postgres only, etc.
ERROR_PATTERNS: list[tuple[str, str | None, str]] = [
    # ── Connection errors ─────────────────────────
    (
        r"could not connect to server.*Connection refused|connection.*refused.*port\s*\d+|connection to server.*failed.*Connection refused",
        "postgres",
        "PostgreSQL is not running on {host}:{port}.\n"
        "  Try: cd envi-test && docker compose up -d postgres",
    ),
    (
        r"Connection refused|connection.*refused",
        None,
        "Cannot connect to {tech} on {host}:{port}. Is the service running?\n"
        "  Try: cd envi-test && docker compose up -d",
    ),
    (
        r"FATAL:\s+password authentication failed for user",
        "postgres",
        "Wrong password for PostgreSQL user. Check config/secrets/.env\n"
        "  Expected: POSTGRES_USER=dataclaw, POSTGRES_PASSWORD=dataclaw123",
    ),
    (
        r"FATAL:\s+database \"(.+?)\" does not exist",
        "postgres",
        "Database '{match1}' does not exist.\n"
        "  Check config/connections/postgres.yaml → database field.\n"
        "  Available databases can be checked with: docker exec envi-test-postgres-1 psql -U dataclaw -l",
    ),
    (
        r"FATAL:\s+role \"(.+?)\" does not exist",
        "postgres",
        "PostgreSQL user '{match1}' does not exist.\n"
        "  Check config/secrets/.env → POSTGRES_USER",
    ),

    # ── Schema / table not found ──────────────────
    (
        r"schema \"(.+?)\" does not exist",
        "postgres",
        "Schema '{match1}' not found in the database.\n"
        "  Run 'list all schemas' to see available schemas.",
    ),
    (
        r"relation \"(.+?)\" does not exist",
        "postgres",
        "Table '{match1}' does not exist.\n"
        "  Run 'show me tables in the <schema> schema' to see available tables.",
    ),
    (
        r"column \"(.+?)\" does not exist",
        "postgres",
        "Column '{match1}' does not exist in the table.\n"
        "  Run 'describe the <table> table' to see available columns.",
    ),

    # ── Airflow errors ────────────────────────────
    (
        r"403.*FORBIDDEN",
        "airflow",
        "Airflow API returned 403 (Forbidden).\n"
        "  Check that AIRFLOW__API__AUTH_BACKENDS is set to basic_auth in docker-compose.\n"
        "  Credentials: airflow / airflow",
    ),
    (
        r"401.*Unauthorized",
        "airflow",
        "Airflow API authentication failed.\n"
        "  Default credentials: airflow / airflow",
    ),
    (
        r"connection.*refused.*8080",
        "airflow",
        "Airflow webserver is not running on port 8080.\n"
        "  Try: cd envi-test && docker compose up -d airflow-webserver",
    ),

    # ── Timeout ───────────────────────────────────
    (
        r"timed?\s*out|timeout",
        None,
        "The request timed out. The service at {host}:{port} didn't respond in time.\n"
        "  Check if the service is running and not overloaded.",
    ),

    # ── Docker / sandbox ──────────────────────────
    (
        r"Cannot connect to the Docker daemon",
        None,
        "Docker is not running. Please start Docker Desktop.",
    ),
    (
        r"No such image.*python",
        None,
        "Docker image 'python:3.11-slim' not found. Pull it:\n"
        "  docker pull python:3.11-slim",
    ),
    (
        r"charmap.*codec can't encode",
        None,
        "Windows encoding error in sandbox. This is a known issue with Docker on Windows.\n"
        "  The tool will fall back to subprocess execution.",
    ),
]


def diagnose(
    error: str | Exception,
    technology: str = "",
    connection_config: dict | None = None,
) -> str:
    """Turn a raw error into a user-friendly message with fix suggestions.

    Args:
        error: Raw error string or Exception.
        technology: Technology name (e.g. 'postgres', 'airflow').
        connection_config: Connection config for context (host, port, etc.).
    Returns:
        User-friendly error message.
    """
    error_str = str(error)
    config = connection_config or {}
    host = config.get("host", "localhost")
    port = config.get("port", "?")

    for pattern, tech_filter, message in ERROR_PATTERNS:
        # Skip if pattern is for a different technology
        if tech_filter and tech_filter != technology:
            continue

        match = re.search(pattern, error_str, re.IGNORECASE)
        if match:
            # Extract capture groups for {match1}, {match2}, etc.
            fmt_args = {
                "tech": technology or "the service",
                "host": host,
                "port": port,
            }
            for i, group in enumerate(match.groups(), 1):
                fmt_args[f"match{i}"] = group

            # Also extract port from regex if available
            if "port" in fmt_args and fmt_args["port"] == "?":
                port_match = re.search(r"port\s*(\d+)", error_str)
                if port_match:
                    fmt_args["port"] = port_match.group(1)

            try:
                friendly = message.format(**fmt_args)
            except KeyError:
                friendly = message
            logger.info(f"Diagnosed error: {pattern} -> {friendly[:80]}")
            return friendly

    # Fallback: return a cleaned-up version of the raw error
    logger.debug(f"No diagnosis pattern matched for: {error_str[:200]}")
    return f"Unexpected error: {error_str[:500]}\n  Check logs/dataclaw.log for details."
