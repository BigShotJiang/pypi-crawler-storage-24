"""Named constants — reads from config/settings.yaml at runtime.

All values have sensible defaults if settings.yaml is missing or incomplete.
Use `get(key)` for single values or `get_all()` for the full runtime config.
"""

from pathlib import Path

import yaml

from utils.paths import get_settings_path
SETTINGS_PATH = get_settings_path()

# Cache
_cache: dict | None = None
_cache_mtime: float = 0.0

# Defaults (used when settings.yaml is missing or incomplete)
_DEFAULTS = {
    "llm_timeout_s": 120,
    "max_clarify_depth": 3,
    "max_build_attempts": 3,
    "builds_remaining": 3,
    "steps_remaining": 5,
    "max_observation_length": 3000,
    "max_session_turns": 20,
    "default_query_limit": 100,
    "max_files_list": 50,
    "max_file_size_bytes": 1_000_000,
    "max_description_length": 200,
}

# Human-readable descriptions for /config display
_DESCRIPTIONS = {
    "llm_timeout_s": "LLM request timeout (seconds)",
    "max_clarify_depth": "Max CLARIFY recursion depth before forcing action",
    "max_build_attempts": "Max build→test attempts per tool",
    "builds_remaining": "Tool builds allowed per request",
    "steps_remaining": "Plan steps allowed per request",
    "max_observation_length": "Observation truncation length (chars)",
    "max_session_turns": "Session memory max turns",
    "default_query_limit": "Default SQL query row limit",
    "max_files_list": "Max files returned by read_files list",
    "max_file_size_bytes": "Max file size for read_files (bytes)",
    "max_description_length": "Tool description truncation (chars)",
}


def _load_runtime() -> dict:
    """Load runtime config from settings.yaml with mtime caching."""
    global _cache, _cache_mtime

    if SETTINGS_PATH.exists():
        current_mtime = SETTINGS_PATH.stat().st_mtime
        if _cache is not None and current_mtime == _cache_mtime:
            return _cache

        try:
            settings = yaml.safe_load(SETTINGS_PATH.read_text(encoding="utf-8"))
            runtime = settings.get("runtime", {}) if settings else {}
        except Exception:
            runtime = {}

        merged = {**_DEFAULTS, **{k: v for k, v in runtime.items() if v is not None}}
        _cache = merged
        _cache_mtime = current_mtime
        return merged

    return dict(_DEFAULTS)


def get(key: str) -> int | float:
    """Get a single runtime config value."""
    return _load_runtime().get(key, _DEFAULTS.get(key))


def get_all() -> dict:
    """Get all runtime config values."""
    return _load_runtime()


def get_descriptions() -> dict:
    """Get human-readable descriptions for all config keys."""
    return dict(_DESCRIPTIONS)


def set_value(key: str, value) -> None:
    """Update a single runtime config value and write to settings.yaml."""
    global _cache, _cache_mtime

    if key not in _DEFAULTS:
        raise KeyError(f"Unknown config key: '{key}'")

    # Coerce type to match default
    default_val = _DEFAULTS[key]
    if isinstance(default_val, int):
        value = int(value)
    elif isinstance(default_val, float):
        value = float(value)

    # Load full settings
    if SETTINGS_PATH.exists():
        settings = yaml.safe_load(SETTINGS_PATH.read_text(encoding="utf-8")) or {}
    else:
        settings = {}

    if "runtime" not in settings:
        settings["runtime"] = {}

    settings["runtime"][key] = value
    SETTINGS_PATH.write_text(yaml.dump(settings, default_flow_style=False, sort_keys=False), encoding="utf-8")

    # Invalidate cache
    _cache = None
    _cache_mtime = 0.0


def invalidate_cache() -> None:
    """Force reload on next access."""
    global _cache, _cache_mtime
    _cache = None
    _cache_mtime = 0.0


# ── Legacy module-level constants (for backward compatibility) ──
# These are properties that read from config at import time.
# Code that imports these directly gets the value at import time.
# For truly dynamic reads, use get("key") instead.

MAX_FILES_LIST = _DEFAULTS["max_files_list"]
MAX_FILE_SIZE_BYTES = _DEFAULTS["max_file_size_bytes"]
MAX_SESSION_TURNS = _DEFAULTS["max_session_turns"]
MAX_DESCRIPTION_LENGTH = _DEFAULTS["max_description_length"]
DEFAULT_QUERY_LIMIT = _DEFAULTS["default_query_limit"]
MAX_OBSERVATION_LENGTH = _DEFAULTS["max_observation_length"]
