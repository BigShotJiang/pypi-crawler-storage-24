"""Synthesizer — takes collected results and generates a final answer.

Used when intent=QUESTION. The LLM reads all step results and produces
a clear, data-backed answer to the user's original question.
"""

import json
import logging
from typing import Optional

from utils.llm_client import LLMError, call_llm

logger = logging.getLogger(__name__)

SYNTHESIZE_PROMPT = """\
You collected these results from the user's data environment:

{results_text}

The user's original question was:
"{user_prompt}"

Your goal: {final_goal}

Using ONLY the actual data above (not assumptions), write a clear, helpful answer.
- Use the real numbers and names from the results.
- Format with bullet points for readability.
- Keep it concise — no more than 10-15 lines.
- If some steps failed or were skipped, mention what you couldn't check.
"""

SYSTEM_PROMPT = (
    "You are DataClaw's synthesizer. You take raw data results and produce "
    "clear, human-readable answers. Be specific — use actual table names, "
    "counts, and schema names from the data. Never make up data."
)


async def synthesize(
    user_prompt: str,
    final_goal: str,
    collected_results: dict,
    plan: list[dict],
) -> str:
    """Generate a final answer from collected step results.

    Args:
        user_prompt: The original user question.
        final_goal: One-sentence goal from the orchestrator plan.
        collected_results: Dict mapping step index -> result string.
        plan: The full plan (for step labels/reasons).
    Returns:
        Synthesized answer string.
    """
    # Build a readable summary of results
    results_lines = []
    for i, step in enumerate(plan):
        status = step.get("status", "unknown")
        reason = step.get("reason", step.get("tool", "?"))
        tool = step.get("tool", "?")

        if str(i) in collected_results or i in collected_results:
            result = collected_results.get(str(i), collected_results.get(i, ""))
            results_lines.append(f"Step {i + 1} ({tool} — {reason}): {result}")
        elif status == "skipped":
            results_lines.append(f"Step {i + 1} ({tool} — {reason}): SKIPPED by user")
        elif status == "failed":
            results_lines.append(f"Step {i + 1} ({tool} — {reason}): FAILED")
        else:
            results_lines.append(f"Step {i + 1} ({tool} — {reason}): No data")

    results_text = "\n".join(results_lines)

    prompt = SYNTHESIZE_PROMPT.format(
        results_text=results_text,
        user_prompt=user_prompt,
        final_goal=final_goal,
    )

    try:
        answer = await call_llm(SYSTEM_PROMPT, prompt, agent="orchestrator")
        # Strip any thinking tags from qwen models
        answer = _strip_thinking(answer)
        return answer.strip()
    except LLMError as e:
        logger.warning(f"LLM synthesis failed ({e.reason}), using fallback")
        return _fallback_synthesis(results_text, final_goal)


def _strip_thinking(text: str) -> str:
    """Remove <think>...</think> blocks from qwen model output."""
    import re
    return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()


def _fallback_synthesis(results_text: str, final_goal: str) -> str:
    """Simple fallback when LLM is unavailable.

    Args:
        results_text: Formatted step results.
        final_goal: The goal description.
    Returns:
        Basic formatted answer.
    """
    return f"Here's what I found ({final_goal}):\n\n{results_text}"
