"""Generates test scripts from tool manifest + connection config for sandbox execution."""

import json
import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)


def _extract_kwargs_from_code(code: str) -> list[str]:
    """Scan tool code for kwargs.get() calls to find expected parameters.

    Args:
        code: Python source code of the tool.
    Returns:
        List of parameter names extracted from kwargs.get("name", ...) patterns.
    """
    # Match kwargs.get("param_name") or kwargs.get('param_name')
    pattern = r'kwargs\.get\(["\'](\w+)["\']'
    return re.findall(pattern, code)


def _discover_real_entities(connection_config: dict) -> dict[str, str]:
    """Discover real entity names from connected services for test data.

    Generically probes the connection to find real entity names that can
    serve as test inputs. Works for any technology:
      - Filesystem: scans for real files
      - HTTP API: tries common listing endpoints
      - Database: uses schema/database from config

    Args:
        connection_config: The connection config for this technology.
    Returns:
        Dict mapping param-hint categories to real values found.
        E.g. {"file": "dim_customers", "dag": "raw_data_ingestion", "schema": "public"}
    """
    import os
    entities: dict[str, str] = {}

    # 1. Filesystem: find a real file
    for dir_key in ("models_dir", "project_dir", "path", "data_dir"):
        dir_path = connection_config.get(dir_key, "")
        if dir_path and os.path.isdir(dir_path):
            import glob as glob_mod
            for ext in ("**/*.sql", "**/*.yml", "**/*.yaml", "**/*.py", "**/*.json"):
                files = glob_mod.glob(os.path.join(dir_path, ext), recursive=True)
                if files:
                    entities["file"] = os.path.splitext(os.path.basename(files[0]))[0]
                    break
            if "file" in entities:
                break

    # 2. Database: use config values
    if connection_config.get("database"):
        entities["database"] = connection_config["database"]
    if connection_config.get("schema"):
        entities["schema"] = connection_config["schema"]

    # 3. HTTP API: try to discover entities from listing endpoints
    base_url = connection_config.get("base_url", "")
    if base_url:
        entities.update(_probe_api_for_entities(connection_config))

    return entities


def _probe_api_for_entities(connection_config: dict) -> dict[str, str]:
    """Probe an HTTP API for real entity names.

    Tries common REST patterns to find at least one real entity.
    Generic: doesn't hardcode technology-specific paths.

    Args:
        connection_config: Must contain base_url, optionally user/password/api_key.
    Returns:
        Dict of discovered entities.
    """
    import requests

    base_url = connection_config.get("base_url", "").rstrip("/")
    if not base_url:
        return {}

    # Build auth
    auth = None
    user = connection_config.get("user", "")
    password = connection_config.get("password", "")
    if user and password:
        auth = (user, password)

    headers = {}
    api_key = connection_config.get("api_key", "")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    # Try common REST listing patterns
    # Each entry: (endpoint_suffix, response_key_candidates, entity_name_field, category)
    probe_patterns = [
        ("/api/v1/dags", ["dags"], "dag_id", "dag"),
        ("/api/v1/pools", ["pools"], "name", "pool"),
        ("/api/v1/connections", ["connections"], "connection_id", "connection"),
        ("/api/v1/variables", ["variables"], "key", "variable"),
        ("/api/v2/dags", ["dags"], "dag_id", "dag"),
        ("/api/databases", ["databases", "data"], "name", "database"),
        ("/api/dashboards", ["dashboards", "data"], "name", "dashboard"),
    ]

    entities: dict[str, str] = {}

    for endpoint, keys, name_field, category in probe_patterns:
        if category in entities:
            continue
        try:
            resp = requests.get(f"{base_url}{endpoint}", auth=auth, headers=headers, timeout=5)
            if resp.status_code != 200:
                continue
            data = resp.json()

            # Try to extract from response — check each candidate key
            items = None
            for key in keys:
                if isinstance(data, dict) and key in data and isinstance(data[key], list):
                    items = data[key]
                    break
            if items is None and isinstance(data, list):
                items = data

            if items and len(items) > 0:
                first = items[0]
                if isinstance(first, dict):
                    # Try to get the name/id field
                    val = first.get(name_field, "")
                    if not val:
                        # Fallback: try common name fields
                        for f in ("name", "id", "key", "dag_id"):
                            val = first.get(f, "")
                            if val:
                                break
                    if val:
                        entities[category] = str(val)
                elif isinstance(first, str):
                    entities[category] = first

        except Exception:
            continue

    if entities:
        logger.info(f"Discovered real entities from API: {entities}")
    return entities


def _build_test_kwargs(param_names: list[str], connection_config: dict) -> dict:
    """Build test kwargs from detected parameter names using real discovered values.

    Discovers real entity names from the connected service (API, filesystem, database)
    and maps them to the tool's expected parameters. This ensures tests use real
    data that actually exists, avoiding 404/not-found errors.

    IMPORTANT: Skips params that are connection config keys — the tool should
    read those from connection_config, not from kwargs. Sending dummy 'test'
    values for connection params (like bootstrap_servers='test') causes failures.

    Args:
        param_names: Parameter names extracted from the tool code.
        connection_config: The connection config for this technology.
    Returns:
        Dict of parameter names to test values.
    """
    if not param_names:
        return {}

    # Skip params that are connection config keys — the tool reads those from
    # connection_config directly, not from kwargs. Also skip internal/auth params.
    connection_keys = set(connection_config.keys())
    skip_patterns = {
        "bootstrap_servers", "servers", "brokers", "host", "port", "base_url",
        "url", "uri", "endpoint", "user", "username", "password", "secret",
        "token", "api_key", "apikey", "access_key", "secret_key", "auth",
        "security_protocol", "sasl_mechanism", "sasl_plain_username",
        "sasl_plain_password", "ssl", "tls", "cert", "certificate",
        "connection_string", "driver", "type", "access_level",
    }

    # Discover real entities from the connected service
    real_entities = _discover_real_entities(connection_config)

    kwargs = {}
    for name in param_names:
        name_lower = name.lower()

        # Skip connection config keys — the tool should read them from connection_config
        if name in connection_keys or name_lower in skip_patterns:
            continue

        # Try to match param name to a discovered entity category
        matched = False
        for category, value in real_entities.items():
            if category in name_lower or name_lower in category:
                kwargs[name] = value
                matched = True
                break

        if matched:
            continue

        # Fallback heuristics for common param patterns
        if "schema" in name_lower:
            kwargs[name] = real_entities.get("schema", connection_config.get("schema", "public"))
        elif "query" in name_lower:
            kwargs[name] = "SELECT 1 AS test"
        elif "database" in name_lower or "db" == name_lower:
            kwargs[name] = real_entities.get("database", connection_config.get("database", "test"))
        elif "table" in name_lower:
            kwargs[name] = real_entities.get("table", "information_schema.tables")
        elif "file" in name_lower or "model" in name_lower or "name" in name_lower:
            kwargs[name] = real_entities.get("file", "test")
        elif "limit" in name_lower:
            kwargs[name] = 5
        elif "offset" in name_lower:
            kwargs[name] = 0
        elif "timeout" in name_lower:
            kwargs[name] = 10
        elif "include" in name_lower or "verbose" in name_lower:
            kwargs[name] = False
        else:
            # Last resort: use any first discovered entity, or skip entirely
            # Do NOT set to "test" — it causes garbage values for unknown params
            if real_entities:
                kwargs[name] = next(iter(real_entities.values()))

    if kwargs:
        logger.info(f"Auto-generated test kwargs: {kwargs}")
    return kwargs


def generate_test_script(
    tool_code: str,
    tool_name: str,
    connection_config: dict,
    test_hints: list[str] | None = None,
    host_connection_config: dict | None = None,
) -> str:
    """Generate a self-contained Python test script for sandbox execution.

    The script includes the tool code, injects the connection config,
    calls the tool, and validates the output is a dict.

    Args:
        tool_code: The generated tool's Python source code
        tool_name: Name of the tool function to test
        connection_config: Connection parameters to inject
        test_hints: Optional hints about test requirements
    Returns:
        Complete Python script as a string
    """
    # Sanitize connection config for embedding in script
    config_json = json.dumps(connection_config, indent=4)

    # Auto-detect kwargs the tool expects so we can generate test params.
    # If the tool uses kwargs.get("model_name", ...) we need to pass a value.
    expected_kwargs = _extract_kwargs_from_code(tool_code)
    # Use the HOST connection config for scanning real files (container paths don't exist on host)
    scan_config = host_connection_config or connection_config
    test_kwargs = _build_test_kwargs(expected_kwargs, scan_config)
    test_kwargs_json = json.dumps(test_kwargs, indent=4)

    script = f'''#!/usr/bin/env python3
"""Auto-generated test script for tool: {tool_name}"""

import json
import sys
import traceback

# ── Tool code under test ────────────────────────
{tool_code}

# ── Test execution ──────────────────────────────
def run_tests():
    """Execute the tool and validate the output."""
    connection_config = {config_json}
    test_kwargs = {test_kwargs_json}

    tests_run = 0
    tests_passed = 0
    errors = []

    # Test 1: Tool executes without exception (with test params if any)
    tests_run += 1
    try:
        result = {tool_name}(connection_config, **test_kwargs)
        tests_passed += 1
        print(f"PASS: {tool_name} executed successfully")
    except Exception as e:
        errors.append(f"Execution error: {{type(e).__name__}}: {{e}}")
        print(f"FAIL: {tool_name} raised {{type(e).__name__}}: {{e}}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        # Print summary and exit early
        print(json.dumps({{"tests_run": tests_run, "tests_passed": tests_passed, "errors": errors}}))
        sys.exit(1)

    # Test 2: Output is a dict
    tests_run += 1
    if isinstance(result, dict):
        tests_passed += 1
        print(f"PASS: output is a dict")
    else:
        errors.append(f"Output type mismatch: expected dict, got {{type(result).__name__}}")
        print(f"FAIL: output is {{type(result).__name__}}, expected dict", file=sys.stderr)

    # Test 3: Output is not empty
    tests_run += 1
    if result:
        tests_passed += 1
        print(f"PASS: output is non-empty")
    else:
        errors.append("Output is empty")
        print(f"FAIL: output is empty", file=sys.stderr)

    # Test 4: Output does not contain an error key
    tests_run += 1
    if isinstance(result, dict) and "error" in result:
        errors.append(f"Tool returned error: {{result['error']}}")
        print(f"FAIL: tool returned error: {{result['error']}}", file=sys.stderr)
    else:
        tests_passed += 1
        print(f"PASS: output has no error key")

    # Print results as JSON for structured parsing
    summary = {{
        "tests_run": tests_run,
        "tests_passed": tests_passed,
        "errors": errors,
        "result_keys": list(result.keys()) if isinstance(result, dict) else [],
    }}
    print(f"RESULT: {{json.dumps(summary)}}")

    if tests_passed < tests_run:
        sys.exit(1)

if __name__ == "__main__":
    run_tests()
'''
    return script


def generate_parameterized_test_script(
    tool_code: str,
    tool_name: str,
    connection_config: dict,
    test_cases: list[dict],
) -> str:
    """Generate a test script with multiple parameterized test cases.

    Args:
        tool_code: The generated tool's Python source code
        tool_name: Name of the tool function
        connection_config: Connection parameters
        test_cases: List of dicts with 'args' (extra kwargs) and 'description'
    Returns:
        Complete Python test script as a string
    """
    config_json = json.dumps(connection_config, indent=4)
    cases_json = json.dumps(test_cases, indent=4)

    script = f'''#!/usr/bin/env python3
"""Auto-generated parameterized test script for tool: {tool_name}"""

import json
import sys
import traceback

# ── Tool code under test ────────────────────────
{tool_code}

# ── Test execution ──────────────────────────────
def run_tests():
    """Execute the tool with multiple parameter sets."""
    connection_config = {config_json}
    test_cases = {cases_json}

    tests_run = 0
    tests_passed = 0
    errors = []

    for i, case in enumerate(test_cases):
        tests_run += 1
        desc = case.get("description", f"test case {{i+1}}")
        extra_args = case.get("args", {{}})

        try:
            result = {tool_name}(connection_config, **extra_args)
            if not isinstance(result, dict):
                errors.append(f"{{desc}}: output is {{type(result).__name__}}, expected dict")
                print(f"FAIL: {{desc}} - wrong output type", file=sys.stderr)
            elif "error" in result:
                errors.append(f"{{desc}}: tool returned error: {{result['error']}}")
                print(f"FAIL: {{desc}} - tool returned error: {{result['error']}}", file=sys.stderr)
            else:
                tests_passed += 1
                print(f"PASS: {{desc}}")
        except Exception as e:
            errors.append(f"{{desc}}: {{type(e).__name__}}: {{e}}")
            print(f"FAIL: {{desc}} - {{type(e).__name__}}: {{e}}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)

    summary = {{
        "tests_run": tests_run,
        "tests_passed": tests_passed,
        "errors": errors,
    }}
    print(f"RESULT: {{json.dumps(summary)}}")

    if tests_passed < tests_run:
        sys.exit(1)

if __name__ == "__main__":
    run_tests()
'''
    return script
