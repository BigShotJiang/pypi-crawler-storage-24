"""Tester agent — validates generated tool code before committing.

Two-phase approach:
  Phase 1: Static validation (always) — AST syntax, imports, signature, dangerous calls
  Phase 2: Execution — mode depends on access_level:
    - read-only  → direct execution in-process (same env, real infra, fast)
    - write/admin → Docker sandbox (isolated, safe for mutations)

Input: DataClawState (reads task_id, tool_name, technology, generated_code, manifest, connection_config)
Output: State updates (test_verdict, failure_reason, failure_details, sandbox_logs)
"""

import logging
import re
import sys
import time
import traceback
from pathlib import Path
from typing import Any

import yaml

from agents.builder.validator import validate_tool
from agents.tester.reporter import build_error_report, build_report, compute_score
from agents.tester.test_generator import _extract_kwargs_from_code, _build_test_kwargs
from contracts.test_report import TestReport, TestVerdict

logger = logging.getLogger(__name__)

_SENSITIVE_KEYS = re.compile(r"(password|secret|token|api_key|apikey)", re.IGNORECASE)


def _redact_config(config: dict) -> dict:
    """Return a copy of config with sensitive values masked."""
    redacted = {}
    for k, v in config.items():
        if isinstance(v, dict):
            redacted[k] = _redact_config(v)
        elif _SENSITIVE_KEYS.search(k):
            redacted[k] = "***"
        else:
            redacted[k] = v
    return redacted


# Load system prompt at module level
SYSTEM_PROMPT = (Path(__file__).parent / "prompts" / "system.md").read_text(encoding="utf-8")

# Config path
from utils.paths import get_settings_path
SETTINGS_PATH = get_settings_path()


def _load_sandbox_config() -> dict:
    """Load sandbox configuration from settings.yaml."""
    if SETTINGS_PATH.exists():
        settings = yaml.safe_load(SETTINGS_PATH.read_text())
        return settings.get("sandbox", {})
    return {}


# ── Phase 1: Static validation ──────────────────────


def _static_validate(code: str, tool_name: str, technology: str) -> dict | None:
    """Run static checks on generated code. Returns error dict or None if OK."""
    result = validate_tool(code, tool_name, technology)
    if not result["valid"]:
        return {
            "reason": "validation_error",
            "details": "; ".join(result["errors"]),
        }
    return None


# ── Phase 2a: Direct execution (read-only) ──────────


def _detect_missing_imports(code: str) -> list[dict]:
    """Detect third-party imports in code that are not installed locally.

    Returns list of dicts: [{"module": "kafka", "pip_package": "kafka-python"}, ...]
    """
    import importlib.util
    import re as _re

    # Reuse PIP_NAME_MAP and STDLIB from container_manager
    try:
        from sandbox.executor.container_manager import PIP_NAME_MAP, STDLIB_MODULES
    except ImportError:
        PIP_NAME_MAP = {"kafka": "kafka-python", "paramiko": "paramiko",
                        "confluent_kafka": "confluent-kafka", "psycopg2": "psycopg2-binary"}
        STDLIB_MODULES = {"os", "sys", "re", "json", "pathlib", "logging", "typing",
                          "time", "datetime", "collections", "functools", "itertools",
                          "math", "random", "io", "csv", "tempfile", "threading",
                          "asyncio", "socket", "http", "urllib", "uuid", "ssl",
                          "importlib", "traceback", "hashlib", "base64", "struct",
                          "sqlite3", "configparser", "argparse", "copy", "glob",
                          "contextlib", "warnings", "platform", "signal", "secrets",
                          "subprocess", "multiprocessing", "concurrent", "ctypes",
                          # Platform-specific stdlib (Unix-only)
                          "grp", "pwd", "fcntl", "termios", "resource", "posix", "pty", "tty"}

    import_pattern = _re.compile(r"^\s*(?:import|from)\s+(\w+)", _re.MULTILINE)
    imports = set(import_pattern.findall(code))
    third_party = imports - STDLIB_MODULES

    missing = []
    for mod in sorted(third_party):
        spec = importlib.util.find_spec(mod)
        if spec is None:
            pip_name = PIP_NAME_MAP.get(mod, mod)
            missing.append({"module": mod, "pip_package": pip_name})
    return missing


def _direct_execute(code: str, tool_name: str, connection_config: dict, timeout_s: int = 30) -> dict:
    """Execute the tool directly in-process. For read-only tools only.

    Loads the generated code into a temp module, calls the function with
    real connection_config, and validates the result.

    Returns dict with 'stdout', 'stderr', 'exit_code'.
    Special key 'missing_libraries' added when imports fail.
    """
    import io
    import types

    # ── Pre-check: detect missing third-party libraries ──
    missing = _detect_missing_imports(code)
    if missing:
        packages = [m["pip_package"] for m in missing]
        modules = [m["module"] for m in missing]
        return {
            "stdout": "",
            "stderr": f"MISSING_LIBRARIES: {', '.join(packages)}",
            "exit_code": 2,
            "missing_libraries": packages,
            "missing_modules": modules,
        }

    # Build test kwargs the same way the test script generator does
    expected_kwargs = _extract_kwargs_from_code(code)
    test_kwargs = _build_test_kwargs(expected_kwargs, connection_config)

    stdout_capture = io.StringIO()
    stderr_capture = io.StringIO()

    try:
        # Compile and load code into a temporary module
        module = types.ModuleType(f"_dataclaw_test_{tool_name}")
        module.__dict__["__builtins__"] = __builtins__
        exec(compile(code, f"<generated:{tool_name}>", "exec"), module.__dict__)

        # Get the function
        func = getattr(module, tool_name, None)
        if func is None:
            return {
                "stdout": "",
                "stderr": f"Function '{tool_name}' not found in generated code",
                "exit_code": 1,
            }

        # Execute with timeout via threading
        import threading
        result_holder = [None]
        error_holder = [None]

        def _run():
            try:
                result_holder[0] = func(connection_config, **test_kwargs)
            except Exception as e:
                error_holder[0] = e

        thread = threading.Thread(target=_run, daemon=True)
        thread.start()
        thread.join(timeout=timeout_s)

        if thread.is_alive():
            return {
                "stdout": "",
                "stderr": f"Execution timed out after {timeout_s}s",
                "exit_code": -1,
            }

        if error_holder[0]:
            e = error_holder[0]
            tb = "".join(traceback.format_exception(type(e), e, e.__traceback__))
            return {
                "stdout": "",
                "stderr": f"FAIL: {tool_name} raised {type(e).__name__}: {e}\n{tb}",
                "exit_code": 1,
            }

        result = result_holder[0]

        # Validate result
        lines = []
        tests_run = 0
        tests_passed = 0
        errors = []

        # Test 1: executes without error
        tests_run += 1
        tests_passed += 1
        lines.append(f"PASS: {tool_name} executed successfully")

        # Test 2: returns dict
        tests_run += 1
        if isinstance(result, dict):
            tests_passed += 1
            lines.append("PASS: output is a dict")
        else:
            errors.append(f"Output type mismatch: expected dict, got {type(result).__name__}")
            lines.append(f"FAIL: output is {type(result).__name__}, expected dict")

        # Test 3: non-empty
        tests_run += 1
        if result:
            tests_passed += 1
            lines.append("PASS: output is non-empty")
        else:
            errors.append("Output is empty")
            lines.append("FAIL: output is empty")

        # Test 4: no error key
        tests_run += 1
        if isinstance(result, dict) and "error" in result:
            errors.append(f"Tool returned error: {result['error']}")
            lines.append(f"FAIL: tool returned error: {result['error']}")
        else:
            tests_passed += 1
            lines.append("PASS: output has no error key")

        import json
        summary = {
            "tests_run": tests_run,
            "tests_passed": tests_passed,
            "errors": errors,
            "result_keys": list(result.keys()) if isinstance(result, dict) else [],
        }
        lines.append(f"RESULT: {json.dumps(summary)}")

        exit_code = 0 if tests_passed == tests_run else 1
        stderr_text = "\n".join(f"FAIL: {e}" for e in errors) if errors else ""

        return {
            "stdout": "\n".join(lines),
            "stderr": stderr_text,
            "exit_code": exit_code,
        }

    except Exception as e:
        tb = traceback.format_exc()
        return {
            "stdout": "",
            "stderr": f"Direct execution error: {type(e).__name__}: {e}\n{tb}",
            "exit_code": 1,
        }


# ── Phase 2b: Sandbox execution (write/admin) ───────


async def _run_in_sandbox(
    test_script: str,
    sandbox_config: dict,
    connection_config: dict | None = None,
    technology: str = "",
    runner: Any = None,
) -> dict:
    """Execute the test script in a Docker sandbox."""
    try:
        if runner is None:
            from sandbox.executor.runner import SandboxRunner
            runner = SandboxRunner(sandbox_config)

        return await runner.execute(
            test_script,
            connection_config or {},
            technology=technology,
        )
    except ImportError:
        logger.warning("Sandbox not available, using subprocess fallback")
        return await _subprocess_fallback(test_script, sandbox_config)


async def _subprocess_fallback(test_script: str, sandbox_config: dict) -> dict:
    """Execute the test script as a subprocess (fallback when Docker unavailable)."""
    import asyncio
    import tempfile

    timeout = sandbox_config.get("timeout_per_test_s", 30)

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False, encoding="utf-8"
    ) as f:
        f.write(test_script)
        script_path = f.name

    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable, script_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            return {
                "stdout": "",
                "stderr": f"Execution timed out after {timeout}s",
                "exit_code": -1,
            }

        return {
            "stdout": stdout.decode("utf-8", errors="replace"),
            "stderr": stderr.decode("utf-8", errors="replace"),
            "exit_code": proc.returncode,
        }
    finally:
        Path(script_path).unlink(missing_ok=True)


# ── Main entry point ────────────────────────────────


async def run(state: dict[str, Any]) -> dict[str, Any]:
    """Entry point for the Tester. Called by LangGraph node.

    Phase 1: Static validation (syntax, imports, signature, dangerous calls)
    Phase 2: Execution
      - read-only access → direct execution (in-process, real infra)
      - write/admin access → Docker sandbox (isolated)
    """
    task_id = state["task_id"]
    tool_name = state["tool_name"]
    technology = state.get("technology", "")
    generated_code = state.get("generated_code", "")
    connection_config = state.get("connection_config", {})

    logger.info(f"Tester received task {task_id}: testing '{tool_name}'")

    if not generated_code:
        report = build_error_report(task_id, tool_name, "No generated code provided")
        return _report_to_state(report)

    # ── Phase 1: Static validation ──────────────────
    static_error = _static_validate(generated_code, tool_name, technology)
    if static_error:
        logger.warning(f"[TESTER] Static validation failed for '{tool_name}': {static_error['details']}")
        report = build_error_report(task_id, tool_name, static_error["details"])
        return _report_to_state(report)

    logger.info(f"[TESTER] Static validation passed for '{tool_name}'")

    # ── Phase 2: Execution ──────────────────────────
    access_level = connection_config.get("_access_level", "read")
    sandbox_config = _load_sandbox_config()
    timeout_s = sandbox_config.get("timeout_per_test_s", 30)

    start_time = time.time()

    if access_level == "read":
        # Direct execution — same process, real infra, no Docker overhead
        logger.info(f"[TESTER] Direct execution for read-only tool '{tool_name}'")
        sandbox_result = _direct_execute(
            generated_code, tool_name, connection_config, timeout_s=timeout_s,
        )
    else:
        # Sandbox execution — Docker isolation for write/admin tools
        logger.info(f"[TESTER] Sandbox execution for {access_level} tool '{tool_name}'")
        sandbox_connection_config = connection_config
        sandbox_runner = None
        try:
            from sandbox.executor.runner import SandboxRunner
            sandbox_runner = SandboxRunner(sandbox_config)
            sandbox_connection_config = sandbox_runner.remap_paths(connection_config)
            logger.info(f"Remapped paths for sandbox: {_redact_config(sandbox_connection_config)}")
        except ImportError:
            logger.debug("Sandbox not available, using original paths")

        from agents.tester.test_generator import generate_test_script
        test_script = generate_test_script(
            tool_code=generated_code,
            tool_name=tool_name,
            connection_config=sandbox_connection_config,
            host_connection_config=connection_config,
        )

        try:
            sandbox_result = await _run_in_sandbox(
                test_script, sandbox_config,
                connection_config=connection_config,
                technology=technology,
                runner=sandbox_runner,
            )
        except Exception as e:
            logger.error(f"Sandbox execution failed: {e}")
            report = build_error_report(task_id, tool_name, str(e))
            return _report_to_state(report)

    execution_time_ms = int((time.time() - start_time) * 1000)

    # Build structured report
    report = build_report(
        task_id=task_id,
        tool_name=tool_name,
        sandbox_result=sandbox_result,
        execution_time_ms=execution_time_ms,
    )

    logger.info(
        f"Tester result for '{tool_name}': {report.verdict.value} "
        f"({report.tests_passed}/{report.tests_run} tests, {execution_time_ms}ms)"
    )

    # Compute quality score for passed tools
    score = None
    if report.verdict == TestVerdict.PASS:
        score = compute_score(generated_code, report)
        logger.info(f"Tool score: {score}")

    return _report_to_state(report, score)


def _report_to_state(report: TestReport, score: dict | None = None) -> dict[str, Any]:
    """Convert a TestReport to state update dict."""
    state = {
        "test_verdict": report.verdict.value,
        "failure_reason": report.failure_reason.value if report.failure_reason else None,
        "failure_details": report.failure_details,
        "sandbox_logs": report.sandbox_logs,
    }
    if score is not None:
        state["approval_score"] = score
        state["approval_status"] = "pending"
    return state
