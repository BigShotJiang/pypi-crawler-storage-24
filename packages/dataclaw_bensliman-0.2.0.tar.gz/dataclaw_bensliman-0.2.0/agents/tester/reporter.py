"""Builds structured TestReport from sandbox execution results."""

import logging
import time

from contracts.test_report import FailureReason, TestReport, TestVerdict

logger = logging.getLogger(__name__)

# Map error patterns to structured failure reasons.
# Patterns are checked in order — more specific patterns first.
# Use exact exception names or specific phrases to avoid false positives.
ERROR_PATTERNS = {
    "SyntaxError": FailureReason.SYNTAX_ERROR,
    "IndentationError": FailureReason.SYNTAX_ERROR,
    "ImportError": FailureReason.IMPORT_ERROR,
    "ModuleNotFoundError": FailureReason.IMPORT_ERROR,
    "No module named": FailureReason.IMPORT_ERROR,
    "ConnectionRefusedError": FailureReason.CONNECTION_REFUSED,
    "OperationalError": FailureReason.CONNECTION_REFUSED,
    "could not connect to server": FailureReason.CONNECTION_REFUSED,
    "Connection refused": FailureReason.CONNECTION_REFUSED,
    "TimeoutError": FailureReason.TIMEOUT,
    "timed out": FailureReason.TIMEOUT,
    "UndefinedTable": FailureReason.SCHEMA_MISMATCH,
    "UndefinedColumn": FailureReason.SCHEMA_MISMATCH,
    'relation "': FailureReason.SCHEMA_MISMATCH,
}


def classify_failure(stderr: str) -> FailureReason:
    """Classify a failure into a structured reason based on error output.

    Args:
        stderr: Standard error output from sandbox execution
    Returns:
        The most appropriate FailureReason enum value
    """
    stderr_lower = stderr.lower()
    for pattern, reason in ERROR_PATTERNS.items():
        if pattern.lower() in stderr_lower:
            return reason
    return FailureReason.RUNTIME_ERROR


def build_report(
    task_id: str,
    tool_name: str,
    sandbox_result: dict,
    execution_time_ms: int,
    tests_run: int = 1,
) -> TestReport:
    """Build a TestReport from sandbox execution results.

    Args:
        task_id: The task ID this report belongs to
        tool_name: Name of the tool that was tested
        sandbox_result: Dict with 'stdout', 'stderr', 'exit_code'
        execution_time_ms: How long the execution took
        tests_run: Number of tests that were run
    Returns:
        A validated TestReport contract
    """
    exit_code = sandbox_result.get("exit_code", -1)
    stdout = sandbox_result.get("stdout", "")
    stderr = sandbox_result.get("stderr", "")

    # Check stdout for error markers even when exit_code is 0
    _STDOUT_ERROR_MARKERS = ("traceback", "assertionerror", "assertion error", "error:", "failed")
    stdout_lower = stdout.lower()
    has_stdout_errors = any(marker in stdout_lower for marker in _STDOUT_ERROR_MARKERS)

    if exit_code == 0 and not stderr.strip() and not has_stdout_errors:
        # Success
        logger.info(f"Tool '{tool_name}' PASSED all tests")
        return TestReport(
            task_id=task_id,
            tool_name=tool_name,
            verdict=TestVerdict.PASS,
            tests_run=tests_run,
            tests_passed=tests_run,
            execution_time_ms=execution_time_ms,
            sandbox_logs=stdout,
        )

    if exit_code == 0 and has_stdout_errors:
        # Exit code was 0 but stdout contains error indicators
        logger.warning(f"Tool '{tool_name}' exited 0 but stdout contains error markers")
        return TestReport(
            task_id=task_id,
            tool_name=tool_name,
            verdict=TestVerdict.FAIL,
            tests_run=tests_run,
            tests_passed=0,
            execution_time_ms=execution_time_ms,
            failure_reason=FailureReason.RUNTIME_ERROR,
            failure_details=f"Exit code 0 but stdout contains errors:\n{stdout[:500]}",
            sandbox_logs=f"STDOUT:\n{stdout}\n\nSTDERR:\n{stderr}",
        )

    # Failure — classify the reason
    failure_reason = classify_failure(stderr)
    logger.warning(f"Tool '{tool_name}' FAILED: {failure_reason.value}")

    return TestReport(
        task_id=task_id,
        tool_name=tool_name,
        verdict=TestVerdict.FAIL,
        tests_run=tests_run,
        tests_passed=0,
        execution_time_ms=execution_time_ms,
        failure_reason=failure_reason,
        failure_details=stderr,
        sandbox_logs=f"STDOUT:\n{stdout}\n\nSTDERR:\n{stderr}",
    )


def compute_score(tool_code: str, report: TestReport) -> dict:
    """Compute a quality score for a generated tool.

    Scores 4 dimensions (0-100 each) plus an overall weighted average:
      - quality: test pass rate + code structure (docstring, type hints)
      - safety: parameterized queries, try/finally, no hardcoded creds
      - reusability: takes connection_config, returns structured data
      - overall: weighted average (quality=40%, safety=30%, reusability=30%)

    Args:
        tool_code: The generated Python source code
        report: TestReport from sandbox execution
    Returns:
        Dict with quality, safety, reusability, overall scores (0-100)
    """
    # Quality: test results + code structure
    quality = 0
    if report.verdict == TestVerdict.PASS:
        quality += 50
    if report.tests_run > 0:
        quality += int(30 * (report.tests_passed / report.tests_run))
    if '"""' in tool_code or "'''" in tool_code:
        quality += 10  # has docstring
    if "->" in tool_code or ": str" in tool_code or ": dict" in tool_code:
        quality += 10  # has type hints

    # Safety: SQL injection prevention, resource cleanup, no secrets
    safety = 40  # base score
    code_lower = tool_code.lower()
    if "%s" in tool_code or "paramstyle" in code_lower or "execute(" in tool_code:
        safety += 20  # parameterized queries
    if "finally" in tool_code:
        safety += 20  # resource cleanup
    if "password" not in tool_code.split("connection_config")[0]:
        safety += 20  # no hardcoded creds before config param

    # Reusability: proper interface
    reusability = 0
    if "connection_config" in tool_code:
        reusability += 40  # takes config param
    if "return" in tool_code:
        reusability += 30  # returns data
    if "def " in tool_code:
        reusability += 30  # is a function

    # Overall weighted average
    overall = int(quality * 0.4 + safety * 0.3 + reusability * 0.3)

    return {
        "quality": min(quality, 100),
        "safety": min(safety, 100),
        "reusability": min(reusability, 100),
        "overall": min(overall, 100),
    }


def build_error_report(
    task_id: str,
    tool_name: str,
    error: str,
) -> TestReport:
    """Build a TestReport for when the sandbox itself fails to run.

    Args:
        task_id: The task ID
        tool_name: Name of the tool
        error: Error message from the sandbox infrastructure
    Returns:
        A TestReport with ERROR verdict
    """
    logger.error(f"Tool '{tool_name}' ERROR: {error}")
    return TestReport(
        task_id=task_id,
        tool_name=tool_name,
        verdict=TestVerdict.ERROR,
        tests_run=0,
        tests_passed=0,
        execution_time_ms=0,
        failure_reason=FailureReason.RUNTIME_ERROR,
        failure_details=error,
    )
