"""Builder agent — generates tool code from a ToolRequest specification.

Input: DataClawState (reads task_id, tool_name, technology, user_prompt,
       failure_reason, connection_config)
Output: State updates (generated_code, manifest)

Fully generic — no per-technology knowledge. The LLM reads the connection
config and figures out the approach.
"""

import logging
import re
from pathlib import Path
from typing import Any

from agents.builder.prompts.generation_prompt import build_generation_prompt
from agents.builder.validator import validate_tool
from contracts.generated_tool import GeneratedTool, ToolManifest
from contracts.tool_request import TaskAction, ToolRequest
from utils.llm_client import LLMError, call_llm

logger = logging.getLogger(__name__)

# Load system prompt at module level
SYSTEM_PROMPT = (Path(__file__).parent / "prompts" / "system.md").read_text(encoding="utf-8")

# Path to technology files for loading existing tools context
TECHNOLOGIES_DIR = Path(__file__).parent.parent.parent / "mcp-tools" / "technologies"


def _load_existing_tools(technology: str) -> dict:
    """Load tool metadata from the registry for a given technology.

    Args:
        technology: Technology name (e.g., 'postgres')
    Returns:
        Dict mapping tool names to metadata.
    """
    import json

    registry_path = TECHNOLOGIES_DIR.parent / "registry.json"
    if not registry_path.exists():
        return {}

    registry = json.loads(registry_path.read_text())
    tools = {}
    for tool in registry.get("tools", []):
        if tool.get("technology") == technology:
            tools[tool["name"]] = {
                "description": tool.get("description", ""),
                "read_only": tool.get("read_only", True),
            }
    return tools


def _extract_code_blocks(text: str) -> list[str]:
    """Extract Python code blocks from LLM response.

    Also strips <think>...</think> blocks from qwen models.
    """
    # Strip thinking blocks
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()

    pattern = r"```python\s*\n(.*?)```"
    matches = re.findall(pattern, text, re.DOTALL)
    if matches:
        return [m.strip() for m in matches]

    # Fallback: treat the whole response as code
    lines = text.strip().split("\n")
    code_lines = [l for l in lines if not l.strip().startswith("```")]
    return ["\n".join(code_lines).strip()]


async def run(state: dict[str, Any]) -> dict[str, Any]:
    """Entry point for the Builder. Called by LangGraph node.

    Builds a ToolRequest from state, renders the generation prompt,
    calls the LLM, validates the output, and returns state updates.
    Does NOT create the technology file — that's handled by the CLI.
    """
    task_id = state["task_id"]
    tool_name = state["tool_name"]
    technology = state["technology"]
    user_prompt = state["user_prompt"]
    connection_config = state.get("connection_config", {})
    attempt = state.get("attempt", 0) + 1

    logger.info(f"Builder received task {task_id}: build '{tool_name}' for {technology}")

    # Build retry context
    retry_context = None
    if state.get("failure_reason"):
        retry_context = (
            f"Previous failure ({state['failure_reason']}): "
            f"{state.get('failure_details', 'no details')}"
        )

    # Construct a ToolRequest for the generation prompt
    tool_request = ToolRequest(
        task_id=task_id,
        action=TaskAction.REFACTOR if retry_context else TaskAction.BUILD_NEW,
        tool_name=tool_name,
        tool_description=user_prompt,
        connection_type=technology,
        retry_context=retry_context,
    )

    # Load existing tools context for the prompt
    existing_tools = _load_existing_tools(technology)

    # Build the generation prompt — pass actual connection config
    generation_prompt = build_generation_prompt(
        request=tool_request,
        existing_tools=existing_tools,
        connection_config=connection_config,
    )

    # Call LLM via shared client
    try:
        raw_response = await call_llm(SYSTEM_PROMPT, generation_prompt, agent="builder")
    except LLMError as e:
        logger.error(f"LLM call failed: {e}")
        return {
            "generated_code": "",
            "manifest": ToolManifest(
                name=tool_name,
                description=f"FAILED: LLM generation failed ({e.reason})",
                input_schema={},
                output_schema={},
            ).model_dump(),
            "attempt": attempt,
            "test_verdict": "fail",
            "failure_reason": "llm_unavailable",
            "failure_details": f"LLM generation failed: {e.reason}. {e.details}",
        }
    else:
        code_blocks = _extract_code_blocks(raw_response)
        tool_code = code_blocks[0] if code_blocks else ""

    # Validate the generated code
    validation = validate_tool(tool_code, tool_name, technology)
    if not validation["valid"]:
        logger.warning(f"Generated code failed validation: {validation['errors']}")

    # Build the manifest
    manifest = ToolManifest(
        name=tool_name,
        description=user_prompt,
        input_schema={"connection_config": {"type": "dict", "required": True}},
        output_schema={"type": "dict"},
    )

    generated_tool = GeneratedTool(
        task_id=task_id,
        tool_name=tool_name,
        tool_code=tool_code,
        technology=technology,
        version=attempt,
        manifest=manifest,
        test_hints=[f"needs {technology} connection"],
    )

    logger.info(f"Builder generated tool '{tool_name}' v{attempt} ({len(tool_code)} chars)")

    return {
        "generated_code": generated_tool.tool_code,
        "manifest": generated_tool.manifest.model_dump(),
        "attempt": attempt,
    }
