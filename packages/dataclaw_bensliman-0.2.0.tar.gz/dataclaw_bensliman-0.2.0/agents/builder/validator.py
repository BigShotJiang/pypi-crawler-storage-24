"""Validates generated tool code: syntax check via ast.parse + import validation."""

import ast
import logging
import re

logger = logging.getLogger(__name__)

# Standard library modules — always allowed for any technology
STDLIB_ALLOWED = {
    "json", "datetime", "typing", "re", "collections",
    "decimal", "uuid", "logging", "os", "sys", "pathlib",
    "io", "csv", "glob", "shutil", "tempfile",
    "hashlib", "base64", "urllib", "http", "traceback",
    "contextlib", "functools", "itertools", "math", "string",
    "textwrap", "time", "abc", "dataclasses", "enum",
}

# Module-level exports for use by ephemeral executor
BLOCKED_IMPORTS = {
    "ctypes", "multiprocessing", "signal",
    "webbrowser", "smtplib", "ftplib", "telnetlib",
    "pickle", "shelve", "marshal",
    "code", "codeop", "compile", "compileall",
    "subprocess",
}

DANGEROUS_CALLS = {"eval", "exec", "compile", "breakpoint", "__import__",
                   "system", "popen", "execl", "execle", "execlp",
                   "execlpe", "execv", "execve", "execvp", "execvpe"}


def validate_syntax(code: str) -> dict:
    """Check if the code is syntactically valid Python.

    Args:
        code: Python source code string
    Returns:
        Dict with 'valid' bool, and 'error' string if invalid
    """
    try:
        ast.parse(code)
        return {"valid": True, "error": None}
    except SyntaxError as e:
        return {
            "valid": False,
            "error": f"SyntaxError at line {e.lineno}: {e.msg}",
        }


def validate_imports(code: str, technology: str) -> dict:
    """Check that the code does not import dangerous modules.

    Generic approach: allow all stdlib + any third-party library EXCEPT
    known dangerous modules that could compromise the host system.
    The sandbox provides the real isolation — this is a first-pass filter.

    Args:
        code: Python source code string
        technology: Technology name (unused — kept for interface compatibility)
    Returns:
        Dict with 'valid' bool, and 'disallowed' list of bad imports
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return {"valid": False, "disallowed": ["<code has syntax errors>"]}

    disallowed = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root_module = alias.name.split(".")[0]
                if root_module in BLOCKED_IMPORTS:
                    disallowed.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                root_module = node.module.split(".")[0]
                if root_module in BLOCKED_IMPORTS:
                    disallowed.append(node.module)

    return {
        "valid": len(disallowed) == 0,
        "disallowed": disallowed,
    }


def _check_dangerous_calls(code: str) -> dict:
    """Detect dangerous function calls that bypass import checks.

    Looks for eval(), exec(), compile(), __import__(), breakpoint(),
    and os.system()/os.popen()/os.exec*() calls via AST inspection.

    Returns:
        Dict with 'valid' bool and 'dangerous_calls' list of descriptions.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return {"valid": False, "dangerous_calls": ["<code has syntax errors>"]}

    DANGEROUS_BUILTINS = {"eval", "exec", "compile", "breakpoint", "__import__"}
    DANGEROUS_OS_ATTRS = {"system", "popen", "execl", "execle", "execlp",
                          "execlpe", "execv", "execve", "execvp", "execvpe"}

    dangerous = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        # Direct calls: eval(...), exec(...), __import__(...)
        if isinstance(func, ast.Name) and func.id in DANGEROUS_BUILTINS:
            dangerous.append(f"Dangerous call: {func.id}()")
        # Attribute calls: os.system(...), os.popen(...)
        elif isinstance(func, ast.Attribute):
            if (isinstance(func.value, ast.Name)
                    and func.value.id == "os"
                    and func.attr in DANGEROUS_OS_ATTRS):
                dangerous.append(f"Dangerous call: os.{func.attr}()")

    return {"valid": len(dangerous) == 0, "dangerous_calls": dangerous}


def validate_function_signature(code: str, tool_name: str) -> dict:
    """Check that the code defines the expected function with connection_config as first param.

    Args:
        code: Python source code string
        tool_name: Expected function name
    Returns:
        Dict with 'valid' bool and 'error' string if invalid
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return {"valid": False, "error": "Code has syntax errors"}

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == tool_name:
            args = node.args
            if not args.args:
                return {"valid": False, "error": f"Function '{tool_name}' has no parameters"}
            first_arg = args.args[0].arg
            if first_arg != "connection_config":
                return {
                    "valid": False,
                    "error": f"First param must be 'connection_config', got '{first_arg}'",
                }
            return {"valid": True, "error": None}

    return {"valid": False, "error": f"Function '{tool_name}' not found in code"}


def validate_tool(code: str, tool_name: str, technology: str) -> dict:
    """Run all validations on generated tool code.

    Args:
        code: Python source code string
        tool_name: Expected function name
        technology: Technology for import whitelist
    Returns:
        Dict with 'valid' bool and list of 'errors'
    """
    errors = []

    syntax = validate_syntax(code)
    if not syntax["valid"]:
        errors.append(syntax["error"])
        return {"valid": False, "errors": errors}

    imports = validate_imports(code, technology)
    if not imports["valid"]:
        errors.append(f"Disallowed imports: {', '.join(imports['disallowed'])}")

    calls = _check_dangerous_calls(code)
    if not calls["valid"]:
        errors.extend(calls["dangerous_calls"])

    signature = validate_function_signature(code, tool_name)
    if not signature["valid"]:
        errors.append(signature["error"])

    return {"valid": len(errors) == 0, "errors": errors}
