"""Call-time prompt template for the Builder's LLM code generation.

Fully generic — no hardcoded per-technology knowledge.
The LLM figures out the approach from the connection config shape.
"""

import json
from typing import Optional

from contracts.tool_request import ToolRequest

GENERATION_PROMPT = """\
Generate a Python tool function for the DataClaw MCP tools library.

## Specification
- Tool name: `{tool_name}`
- Description: {tool_description}
- Technology: {technology}

## Connection Config
The function receives `connection_config: dict` as its first argument.
Here is the ACTUAL connection config for this technology:
```
{connection_config}
```

Look at the connection config to understand HOW to connect:
- If it has `host` + `port` → it's a network service (database, cache, etc.). Use the appropriate Python driver.
- If it has `base_url` → it's an HTTP API. Use `requests` library.
- If it has `project_dir` or `path` → it's local files on disk. Use `pathlib`/`os`/`json`/`yaml` to read them.
- If it has `bootstrap_servers` → it's Kafka. Use `confluent-kafka` or `kafka-python`.
- If it has `host` + `port: 22` → it's an SSH server. Use `paramiko`.
- If it has `container` → it's a Docker container. Use `subprocess` to exec into it, or read mounted files.
- If it has `repo_url` → it's a git repo. Use `requests` to fetch from the API, or clone it.
- If it has `connection_string` or `uri` → parse it and use the appropriate driver.
- YOU figure out which library to use from the config shape. Do NOT assume extra fields.
- You CAN use any third-party pip package — the sandbox auto-installs dependencies from your imports.

## Existing Tools in {technology}.py
{existing_tools}

## Constraints
{constraints}

## Retry Context
{retry_context}

## Rules (MUST follow all)
1. The function signature MUST be:
   `def {tool_name}(connection_config: dict, **kwargs) -> dict:`
   The function takes connection_config as the first param, plus any optional keyword arguments.
2. Extra parameters MUST be read from kwargs: `name = kwargs.get("name", "default")`.
   NEVER add extra positional arguments. The function must work when called with ONLY connection_config.
   If a parameter has no sensible default, return an error dict: `return {{"error": "Missing required parameter: name"}}`
3. ALWAYS close connections/cursors in a `finally` block if you open any.
4. ALWAYS return a `dict` with descriptive keys — never raw strings.
5. Only import what you need. Use standard library where possible.
6. Include a complete docstring with Args and Returns sections.
7. Use parameterized queries for SQL — NEVER use f-strings or .format() for query values.
8. Handle errors gracefully — return {{"error": "message"}} instead of raising.
9. The tool must do exactly what the description says.
10. When reading fields from API responses or dicts, ALWAYS use `.get("key", default)` — NEVER use `dict["key"]` directly. This prevents KeyError crashes.
11. When iterating over API results, filter safely: `[item for item in items if isinstance(item, dict)]`

## Required Response Format
Respond with EXACTLY one Python code block containing the complete function.
Do NOT include the TOOLS dict entry — that's handled automatically.

```python
def {tool_name}(connection_config: dict, **kwargs) -> dict:
    \"\"\"One-line description.

    Args:
        connection_config: Connection parameters
    Returns:
        Dict with descriptive keys
    \"\"\"
    # Your implementation here
    return {{"key": "value"}}
```
"""


def build_generation_prompt(
    request: ToolRequest,
    existing_tools: dict | None = None,
    connection_config: dict | None = None,
) -> str:
    """Fill the generation prompt template with ToolRequest data.

    Args:
        request: The ToolRequest contract from the Orchestrator.
        existing_tools: Current TOOLS dict from the technology file.
        connection_config: The actual connection config for this technology.
    Returns:
        The fully rendered prompt string.
    """
    technology = request.connection_type

    # Connection config — use actual config if provided, otherwise show placeholder
    if connection_config:
        conn_str = json.dumps(connection_config, indent=4, default=str)
    else:
        conn_str = '{"note": "No connection config available — infer from technology name"}'

    # Existing tools
    if existing_tools:
        tools_lines = []
        for name, meta in existing_tools.items():
            desc = meta.get("description", "no description") if isinstance(meta, dict) else str(meta)
            tools_lines.append(f"- `{name}`: {desc}")
        existing_tools_str = "\n".join(tools_lines)
    else:
        existing_tools_str = "(no existing tools — this will be the first for this technology)"

    # Constraints
    constraints = request.constraints if request.constraints else ["read_only"]
    constraints_str = "\n".join(f"- {c}" for c in constraints)

    # Retry context
    if request.retry_context:
        retry_str = (
            f"IMPORTANT — This is a RETRY. The previous attempt failed:\n"
            f"{request.retry_context}\n"
            f"You MUST fix the specific issue described above."
        )
    else:
        retry_str = "First attempt, no prior failures."

    return GENERATION_PROMPT.format(
        tool_name=request.tool_name,
        tool_description=request.tool_description,
        technology=technology,
        connection_config=conn_str,
        existing_tools=existing_tools_str,
        constraints=constraints_str,
        retry_context=retry_str,
    )
