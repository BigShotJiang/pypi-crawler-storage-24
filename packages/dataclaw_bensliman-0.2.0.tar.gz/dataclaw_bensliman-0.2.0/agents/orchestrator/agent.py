"""Orchestrator agent — autonomous reasoning agent with ReAct loop.

The agent THINKS about what it needs, ACTS using bootstrap or built tools,
OBSERVES the result, and THINKS again until it can answer.

Input: DataClawState (reads user_prompt, memory_context)
Output: State updates (intent, plan, reasoning_steps, etc.)

Three paths:
  1. GREETING/HELP  — direct response, no tools
  2. ACTION         — bootstrap/built tool execution
  3. QUESTION       — multi-step reasoning, then synthesize
"""

import json
import logging
import re
import uuid
from pathlib import Path
from typing import Any

import yaml

from agents.orchestrator.prompts.planning_prompt import build_planning_prompt, build_reasoning_prompt
from agents.orchestrator.prompts.responses import get_greeting, get_help_response
from agents.orchestrator.tool_finder import find_tool, get_tool_technology, search_tools_by_description
from utils.connections import (
    get_connection, get_bootstrap_tool, get_connection_display_name,
    get_technology_type, load_all_connections, resolve_user_reference,
)
from utils.constants import get as get_config
from utils.llm_client import LLMError, call_llm

logger = logging.getLogger(__name__)

# Load system prompt at module level
SYSTEM_PROMPT_PATH = Path(__file__).parent / "prompts" / "system.md"
if SYSTEM_PROMPT_PATH.exists():
    SYSTEM_PROMPT = SYSTEM_PROMPT_PATH.read_text(encoding="utf-8")
else:
    SYSTEM_PROMPT = "You are DataClaw, an autonomous data agent that reasons about data systems."

# Keywords for heuristic intent classification
GREETING_WORDS = {"hello", "hi", "hey", "thanks", "thank", "bye", "goodbye", "morning", "evening"}
HELP_WORDS = {"help", "what can you do", "commands", "capabilities"}

# Bootstrap tool names
BOOTSTRAP_TOOLS = {"run_query", "call_api", "read_files"}



def _classify_intent_heuristic(prompt: str) -> str | None:
    """Quick keyword-based intent classification.

    Returns intent string or None if unsure (let LLM decide).
    """
    # Strip punctuation from words for matching
    words = set(w.strip("!?.,;:") for w in prompt.lower().split())
    prompt_lower = prompt.lower().strip()

    if words & GREETING_WORDS and len(words) <= 3:
        return "greeting"

    if prompt_lower in ("help", "help me", "what can you do", "what can you do?"):
        return "help"

    # Infrastructure overview questions → help (shows configured systems dynamically)
    infra_patterns = ["what system", "what tech", "what do we have", "what do you have",
                      "overview", "what is configured", "what's connected", "infrastructure"]
    if any(p in prompt_lower for p in infra_patterns):
        return "help"

    data_words = {"table", "tables", "schema", "schemas", "database", "column",
                  "pipeline", "data", "orders", "customers", "products", "query",
                  "count", "rows", "understand", "explain", "describe", "show",
                  "list", "get", "dags", "airflow", "raw", "staging", "mart",
                  "models", "dbt", "files", "api", "endpoint", "sample", "compare"}
    if words & data_words:
        return None

    return None


def _parse_planning_response(raw: str) -> dict | None:
    """Parse the LLM's JSON planning response.

    Handles raw JSON, code-fenced JSON, thinking blocks.
    """
    text = re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL).strip()

    if "```" in text:
        lines = text.split("\n")
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines).strip()

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}") + 1
        if start >= 0 and end > start:
            try:
                data = json.loads(text[start:end])
            except json.JSONDecodeError:
                return None
        else:
            return None

    if "intent" not in data:
        return None

    return data


async def _llm_plan(user_prompt: str, memory_context: dict | None = None) -> dict | None:
    """Ask the LLM to classify intent and create a reasoning plan.

    Returns parsed plan dict, or None if LLM unavailable.
    """
    try:
        prompt = build_planning_prompt(user_prompt, memory_context=memory_context)
        logger.info("[THINKING] Sending prompt to LLM for reasoning...")
        raw = await call_llm(SYSTEM_PROMPT, prompt, agent="orchestrator")
        logger.info(f"[THINKING] LLM raw response ({len(raw)} chars)")
        logger.debug(f"[THINKING] Full response:\n{raw}")

        parsed = _parse_planning_response(raw)
        if parsed:
            reasoning = parsed.get("reasoning", "")
            intent = parsed.get("intent", "?").upper()
            plan_len = len(parsed.get("plan", []))
            logger.info(f"[REASONING] Intent: {intent} | Steps: {plan_len}")
            if reasoning:
                logger.info(f"[REASONING] Thought: {reasoning}")
        else:
            logger.warning("[REASONING] LLM returned unparseable response")
        return parsed
    except LLMError as e:
        logger.info(f"[REASONING] LLM unavailable ({e.reason}), falling back to heuristics")
        return {"_llm_error": e.reason}


async def continue_reasoning(
    user_prompt: str,
    final_goal: str,
    steps_so_far: list[dict],
    latest_observation: str,
) -> dict | None:
    """Ask the LLM whether it has enough info or needs more steps.

    This is the OBSERVE → THINK part of the ReAct loop.
    Called after each tool execution with the result.

    Returns:
        Dict with 'done' (bool), 'reasoning', 'answer' (if done), 'next_step' (if not done).
        None if LLM unavailable.
    """
    try:
        prompt = build_reasoning_prompt(
            user_prompt=user_prompt,
            final_goal=final_goal,
            steps_so_far=steps_so_far,
            latest_observation=latest_observation,
        )
        logger.info("[REASONING] Continuing reasoning — observing results...")
        raw = await call_llm(SYSTEM_PROMPT, prompt, agent="orchestrator")
        logger.info(f"[REASONING] Continuation response ({len(raw)} chars)")
        logger.debug(f"[REASONING] Full continuation:\n{raw}")

        parsed = _parse_json_response(raw)
        if parsed:
            done = parsed.get("done", False)
            reasoning = parsed.get("reasoning", "")
            logger.info(f"[REASONING] Continue: done={done} | {reasoning[:100]}")
            return parsed
        else:
            logger.warning("[REASONING] Continuation response unparseable")
            return None
    except LLMError as e:
        logger.info(f"[REASONING] LLM unavailable for continuation ({e.reason})")
        return None


def _parse_json_response(raw: str) -> dict | None:
    """Extract JSON from LLM response (handles markdown fences)."""
    text = raw.strip()
    # Strip markdown code fences
    if text.startswith("```"):
        lines = text.split("\n")
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Try to find JSON object in the text
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                return None
        return None


def _normalize_plan(plan: list[dict], technology_default: str = "postgres") -> list[dict]:
    """Normalize plan steps from LLM output to consistent format."""
    normalized = []
    for step in plan:
        tool_name = step.get("tool", "custom_tool")
        tech = step.get("technology", technology_default)
        is_bootstrap = step.get("is_bootstrap", tool_name in BOOTSTRAP_TOOLS)
        needs_building = step.get("needs_building", False)

        # Mark tool_exists based on whether it's bootstrap or in registry
        if is_bootstrap:
            tool_exists = True
        elif needs_building:
            tool_exists = False
        else:
            # Check if it's a known built tool
            found = find_tool(tool_name)
            tool_exists = found is not None

        normalized.append({
            "tool": tool_name,
            "params": step.get("params", {}),
            "reason": step.get("thought", step.get("reason", "")),
            "tool_exists": tool_exists,
            "tool_description": step.get("tool_description"),
            "technology": tech,
            "is_bootstrap": is_bootstrap,
            "status": "pending",
            "result": None,
        })
    return normalized


def _build_multi_tech_plan(all_conns: dict, tech_names: list[str] | None = None) -> list[dict]:
    """Build a plan that queries multiple technologies.

    Args:
        all_conns: All loaded connections.
        tech_names: Specific technologies to query. If None, queries all.
    Returns:
        List of plan step dicts.
    """
    targets = {n: all_conns[n] for n in tech_names if n in all_conns} if tech_names else all_conns
    plan = []
    for name, cfg in targets.items():
        t = cfg.get("type", "")
        if t == "database":
            plan.append({
                "tool": "run_query", "technology": name, "is_bootstrap": True,
                "params": {"query": "SELECT table_schema, table_name FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog', 'information_schema', 'pg_toast') ORDER BY table_schema, table_name"},
                "thought": f"List tables in {name}",
            })
        elif t == "api":
            plan.append({
                "tool": "call_api", "technology": name, "is_bootstrap": True,
                "params": {"endpoint": "/api/v1/dags", "extract_key": "dags"},
                "thought": f"List resources from {name}",
            })
        elif t == "filesystem":
            plan.append({
                "tool": "read_files", "technology": name, "is_bootstrap": True,
                "params": {"action": "list", "pattern": "**/*.sql"},
                "thought": f"List files in {name}",
            })
    return plan


def _build_multi_tech_state(task_id: str, plan: list[dict], final_goal: str) -> dict[str, Any]:
    """Build state dict for a multi-technology plan.

    Args:
        task_id: Task identifier.
        plan: Normalized plan steps.
        final_goal: Goal description.
    Returns:
        State dict.
    """
    technology = plan[0]["technology"] if plan else "postgres"
    return {
        "task_id": task_id,
        "intent": "question",
        "direct_response": None,
        "plan": plan,
        "reasoning_steps": [{"thought": s.get("reason", s.get("thought", "")), "action": "bootstrap_tool",
                             "tool": s["tool"], "technology": s["technology"],
                             "params": s["params"], "observation": None, "status": "pending"}
                            for s in plan],
        "current_step": 0,
        "collected_results": {},
        "final_goal": final_goal,
        "tool_name": plan[0]["tool"] if plan else None,
        "technology": technology,
        "tool_found": True,
        "connection_config": get_connection(technology),
        "exploration_budget": {"builds_remaining": get_config("builds_remaining"), "steps_remaining": get_config("steps_remaining")},
    }


async def run(state: dict[str, Any]) -> dict[str, Any]:
    """Entry point for the Orchestrator. Called by LangGraph node.

    Classifies intent, creates a reasoning plan, and returns state updates.
    """
    user_prompt = state["user_prompt"]
    memory_context = state.get("memory_context")
    clarify_depth = state.get("_clarify_depth", 0)

    logger.info(f"[ORCHESTRATOR] Received: {user_prompt}")
    if memory_context:
        logger.info(f"[ORCHESTRATOR] Memory: history={bool(memory_context.get('conversation_history'))}, "
                     f"entities={len(memory_context.get('entity_matches', []))}, "
                     f"active_tech={memory_context.get('active_technology')}")

    task_id = str(uuid.uuid4())[:8]

    # ── Quick check: greeting/help/infra (no LLM needed) ──
    quick_intent = _classify_intent_heuristic(user_prompt)
    if quick_intent == "greeting":
        response = get_greeting(user_prompt)
        logger.info("[ORCHESTRATOR] Intent: GREETING (heuristic)")
        return {
            "task_id": task_id,
            "intent": "greeting",
            "direct_response": response,
            "plan": [],
            "reasoning_steps": [],
            "current_step": 0,
            "collected_results": {},
            "final_goal": None,
            "tool_found": False,
        }
    if quick_intent == "help":
        response = get_help_response()
        logger.info("[ORCHESTRATOR] Intent: HELP (heuristic)")
        return {
            "task_id": task_id,
            "intent": "help",
            "direct_response": response,
            "plan": [],
            "reasoning_steps": [],
            "current_step": 0,
            "collected_results": {},
            "final_goal": None,
            "tool_found": False,
        }

    # ── LLM reasoning ──────────────────────────────
    llm_result = await _llm_plan(user_prompt, memory_context=memory_context)

    llm_error = llm_result.get("_llm_error") if llm_result else None

    if llm_result is not None and not llm_error:
        intent = llm_result.get("intent", "ACTION").lower()

        # Handle LLM-classified greetings/help
        if intent in ("greeting", "help"):
            direct = llm_result.get("direct_response", "")
            if not direct:
                direct = get_greeting(user_prompt) if intent == "greeting" else get_help_response()
            return {
                "task_id": task_id,
                "intent": intent,
                "direct_response": direct,
                "plan": [],
                "reasoning_steps": [],
                "current_step": 0,
                "collected_results": {},
                "final_goal": None,
                "tool_found": False,
            }

        # Handle CLARIFY — agent needs more info from user
        if intent == "clarify":
            question = llm_result.get("clarify_question", "Could you be more specific?")
            options = llm_result.get("clarify_options", [])
            reasoning = llm_result.get("reasoning", "")
            logger.info(f"[ORCHESTRATOR] CLARIFY: {question} | Options: {options} | depth={clarify_depth}")

            # Check for "use all:" pattern — user wants ALL technologies
            all_conns = load_all_connections()
            all_match = re.search(r"use all:\s*(.+?)(?:\)|$)", user_prompt)
            if all_match:
                tech_names = [t.strip() for t in all_match.group(1).split(",")]
                logger.info(f"[ORCHESTRATOR] 'use all' detected: {tech_names}")
                multi_plan = _build_multi_tech_plan(all_conns, tech_names)
                if multi_plan:
                    normalized = _normalize_plan(multi_plan)
                    return _build_multi_tech_state(
                        task_id, normalized,
                        f"Show data across: {', '.join(tech_names)}",
                    )

            # Check if the user's prompt already contains a reference we can resolve
            max_depth = get_config("max_clarify_depth")
            resolved_key = resolve_user_reference(user_prompt)
            if resolved_key and clarify_depth < max_depth:
                logger.info(f"[ORCHESTRATOR] Auto-resolved user reference to '{resolved_key}'")
                clarified_prompt = f"{user_prompt} — use {resolved_key}"
                return await run({**state, "user_prompt": clarified_prompt, "_clarify_depth": clarify_depth + 1})

            # Auto-resolve: if only 1 option, don't bother the user
            if len(options) == 1 and clarify_depth < max_depth:
                logger.info(f"[ORCHESTRATOR] Auto-resolving CLARIFY — only 1 option: {options[0]}")
                clarified_prompt = f"{user_prompt} — use {options[0]}"
                return await run({**state, "user_prompt": clarified_prompt, "_clarify_depth": clarify_depth + 1})

            # Also auto-resolve: check if there's only one tech of the needed type
            prompt_lower = user_prompt.lower()
            needed_type = None
            if any(w in prompt_lower for w in ("schema", "table", "query", "sql", "row", "column", "database")):
                needed_type = "database"
            elif any(w in prompt_lower for w in ("dag", "airflow", "api", "endpoint")):
                needed_type = "api"
            elif any(w in prompt_lower for w in ("file", "model", "dbt", "directory")):
                needed_type = "filesystem"

            if needed_type and clarify_depth < max_depth:
                matching_techs = [name for name, cfg in all_conns.items() if cfg.get("type") == needed_type]
                if len(matching_techs) == 1:
                    logger.info(f"[ORCHESTRATOR] Auto-resolving CLARIFY — only 1 {needed_type}: {matching_techs[0]}")
                    clarified_prompt = f"{user_prompt} — use {matching_techs[0]}"
                    return await run({**state, "user_prompt": clarified_prompt, "_clarify_depth": clarify_depth + 1})

                # Multiple of same type: build user-friendly options with display names
                if len(matching_techs) > 1:
                    options = [
                        f"{name} — {get_connection_display_name(name)}"
                        for name in matching_techs
                    ]
                    question = f"You have {len(matching_techs)} {needed_type}s configured. Which one?"

            # ── CLARIFY depth exceeded: stop asking, just act ──
            if clarify_depth >= 1:
                logger.info(f"[ORCHESTRATOR] CLARIFY depth {clarify_depth} — forcing action with defaults")
                default_plan = _build_multi_tech_plan(all_conns)
                if not default_plan:
                    default_plan = [{
                        "tool": "run_query", "technology": "postgres", "is_bootstrap": True,
                        "params": {"query": "SELECT 1"}, "thought": "Default test query",
                    }]
                normalized = _normalize_plan(default_plan)
                return _build_multi_tech_state(
                    task_id, normalized,
                    "Show data overview across all connected systems",
                )

            return {
                "task_id": task_id,
                "intent": "clarify",
                "direct_response": question,
                "clarify_options": options,
                "plan": [],
                "reasoning_steps": [{"thought": reasoning, "action": "clarify", "tool": None,
                                     "technology": "", "params": {}, "observation": None, "status": "done"}] if reasoning else [],
                "current_step": 0,
                "collected_results": {},
                "final_goal": None,
                "tool_found": False,
            }

        # ACTION or QUESTION — build the plan
        plan = llm_result.get("plan", [])
        final_goal = llm_result.get("final_goal", user_prompt)
        reasoning = llm_result.get("reasoning", "")

        # If LLM returned ACTION/QUESTION but with an empty plan
        if not plan:
            logger.info("[ORCHESTRATOR] LLM returned empty plan")
            # Check if LLM gave a direct_response even without a plan (e.g. for QUESTION/HELP)
            direct = llm_result.get("direct_response")
            if direct and intent in ("question", "help"):
                return {
                    "task_id": task_id,
                    "intent": "help",
                    "direct_response": direct,
                    "plan": [],
                    "reasoning_steps": [],
                    "current_step": 0,
                    "collected_results": {},
                    "final_goal": None,
                    "tool_found": False,
                }
            # No plan and no direct response — tell user
            return {
                "task_id": task_id,
                "intent": "help",
                "direct_response": "The LLM could not generate a plan for this request. Please try rephrasing or check your LLM configuration with /config.",
                "plan": [],
                "reasoning_steps": [],
                "current_step": 0,
                "collected_results": {},
                "final_goal": None,
                "tool_found": False,
            }

        # Normalize plan steps
        normalized_plan = _normalize_plan(plan)

        # Build reasoning steps from plan
        reasoning_steps = []
        for step in normalized_plan:
            reasoning_steps.append({
                "thought": step.get("reason", ""),
                "action": "bootstrap_tool" if step.get("is_bootstrap") else ("build_new" if not step.get("tool_exists") else "built_tool"),
                "tool": step["tool"],
                "technology": step["technology"],
                "params": step["params"],
                "observation": None,
                "status": "pending",
            })

        # Determine fast-path: single bootstrap/existing tool
        tool_found = False
        tool_name = None
        technology = None
        connection_config = {}

        if normalized_plan:
            first = normalized_plan[0]
            tool_name = first["tool"]
            technology = first.get("technology", "postgres")
            connection_config = get_connection(technology)

            if intent == "action" and len(normalized_plan) == 1 and first["tool_exists"]:
                tool_found = True

        logger.info(f"[ORCHESTRATOR] Plan: intent={intent}, steps={len(normalized_plan)}, "
                     f"tool_found={tool_found}, reasoning={reasoning[:100]}")

        return {
            "task_id": task_id,
            "intent": intent,
            "direct_response": None,
            "plan": normalized_plan,
            "reasoning_steps": reasoning_steps,
            "current_step": 0,
            "collected_results": {},
            "final_goal": final_goal,
            "tool_name": tool_name,
            "technology": technology,
            "tool_found": tool_found,
            "connection_config": connection_config,
            "exploration_budget": {"builds_remaining": get_config("builds_remaining"), "steps_remaining": get_config("steps_remaining")},
        }

    # ── No LLM available — tell user to configure ──
    logger.error(f"[ORCHESTRATOR] LLM unavailable: {llm_error}")

    # Build a helpful error message
    error_detail = str(llm_error) if llm_error else "Unknown error"
    if "timeout" in error_detail.lower():
        hint = "The LLM request timed out. Try increasing `llm_timeout_s` via /config."
    elif "connection_refused" in error_detail.lower() or "connect" in error_detail.lower():
        hint = "Cannot reach the LLM endpoint. Check `model.orchestrator.base_url` in config/settings.yaml."
    elif "config_error" in error_detail.lower() or "api_key" in error_detail.lower():
        hint = "API key is missing or invalid. Check `model.orchestrator.api_key_env` in config/settings.yaml and config/secrets/.env."
    else:
        hint = "Check your LLM configuration in config/settings.yaml."

    return {
        "task_id": task_id,
        "intent": "help",
        "direct_response": (
            f"⚠ No LLM detected — the reasoning engine is not available.\n\n"
            f"Error: {error_detail}\n\n"
            f"{hint}\n\n"
            f"Use /config to check runtime settings, or edit config/settings.yaml directly.\n"
            f"Slash commands (/schemas, /tables, /tools, etc.) still work without the LLM."
        ),
        "plan": [],
        "reasoning_steps": [],
        "current_step": 0,
        "collected_results": {},
        "final_goal": None,
        "tool_found": False,
        "llm_error": llm_error,
    }
