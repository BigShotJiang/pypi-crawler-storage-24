"""Prompt templates for the Orchestrator reasoning agent.

Two prompts:
  1. PLANNING_PROMPT — initial classification + first reasoning step
  2. REASONING_PROMPT — continuation of reasoning chain (Think → Act → Observe)
"""

import json
from pathlib import Path

from utils.connections import get_connection_summary, load_all_connections

REGISTRY_PATH = Path(__file__).parent.parent.parent.parent / "mcp-tools" / "registry.json"


# ── Initial planning prompt ──────────────────────────

PLANNING_PROMPT = """\
The user said:
"{user_prompt}"
{memory_section}
## Your Available Systems
{connection_summary}

## Your Tools

### Bootstrap Tools (fast path — work with common technology types)
- **run_query**: Execute SQL against any database. Params: query (required), limit (optional).
- **call_api**: Make HTTP requests to any REST API. Params: endpoint (required), method, params, body, extract_key.
- **read_files**: Read/list/search files on disk. Params: action ("list"|"read"|"search"|"tree"), path, pattern, query.

### Agent-Built Tools (specialized, previously learned)
{built_tools}

## Your Task

You are a **reasoning agent**. Classify the user's intent, then create a plan to answer their question.
**Be efficient**: prefer fewer steps. If you can answer from what you already know (e.g., configured systems, connection info), just answer — don't run queries to verify things you already know from the config.

### Step 1: Classify intent
- **GREETING** — casual chat ("hello", "hi", "thanks")
- **HELP** — asking about your capabilities
- **CLARIFY** — you need more information from the user before proceeding (e.g., which database? which schema? which DAG?)
- **ACTION** — wants data or wants you to do something
- **QUESTION** — wants an explanation or understanding

### IMPORTANT: When to CLARIFY (and when NOT to)
- If the user's request is AMBIGUOUS about which technology to use (e.g., "list schemas" but there are multiple databases configured), use CLARIFY.
- Include in your clarify_options a list of valid choices so the user can pick quickly.

**DO NOT CLARIFY when:**
- There is ONLY ONE technology of that type configured — just use it.
- The user already answered a previous clarification (look at conversation history / the prompt contains " — use "). Just act on their answer.
- The user gives an affirmative response like "yes", "all", "show it", "go ahead", "do it" — pick the most reasonable default and execute.
- The request is broad but still actionable (e.g., "show me the data" → list schemas + sample tables; "all data" → list tables across schemas). Broad requests should produce a multi-step plan, NOT another clarification.
- You already have enough context to do SOMETHING useful. Prefer showing partial results over asking more questions.

**Rule: NEVER clarify more than once per conversation.** If the conversation history shows you already asked a clarification, DO NOT ask another one. Just pick the best interpretation and act.
- If the prompt contains "use all:" followed by technology names, create a multi-step plan that queries EACH listed technology.
- If the prompt contains "(context: I was asked which system, and replied: ...)", the user already answered a clarification. Do NOT ask again — interpret their answer and act on it. If their answer is a new question, answer that new question using all available systems.

### Step 2: Think and plan

For ACTION/QUESTION, reason about:
1. Which technology has the data? (look at configured connections)
2. Is the request ambiguous? Could it apply to multiple systems? If yes → CLARIFY.
3. Can a bootstrap tool handle it? (database=run_query, api=call_api, filesystem=read_files)
4. Does a previously-built specialized tool do this better?
5. If bootstrap CAN'T do it — propose building a new tool. The Builder will figure out the connection logic from the config shape.

**Key decision rules:**
- **Bootstrap fast path**: If the technology type matches a bootstrap tool, USE IT. `run_query` for databases, `call_api` for REST APIs, `read_files` for filesystems.
- **Build from scratch**: If no bootstrap tool fits the technology (e.g., Kafka, SSH, custom protocols), propose building a NEW tool. The Builder reads the connection config and figures out what driver/library to use.
- **Build for complexity**: Even when bootstrap tools work, build a specialized tool if the task requires complex multi-step logic, pagination, transformations, or will be repeated often.
- **Previously-built tools first**: If you've already built a specialized tool that does exactly this, use it instead of bootstrap.
- **Don't split build and use**: When a step needs a new tool, use ONE step with `needs_building: true`. The system builds it AND executes it automatically. Do NOT create separate steps like "build_ssh_tool" then "use_ssh_tool" — that's wrong. You CAN have multiple steps that each need building (e.g., one Kafka tool + one SSH tool), just don't split a single tool's build and execution.

For databases: `run_query` with `SELECT * FROM information_schema.schemata` lists schemas. `SELECT table_name FROM information_schema.tables WHERE table_schema='raw'` lists tables. No need for separate tools.
For REST APIs: `call_api` with the right endpoint works for most simple requests.
For new/unknown technologies: Describe what the tool should do. The Builder is smart — given a connection config with `bootstrap_servers` it knows to use kafka-python. Given `host` + `port: 22` it knows to use paramiko for SSH.

### Step 3: Create the plan

Each step must specify:
- **tool**: which tool to use (bootstrap or built)
- **technology**: which configured technology to target
- **params**: exact parameters for the tool
- **thought**: WHY this step is needed (your reasoning)

### Response format

Respond with ONLY this JSON:
{{
  "intent": "GREETING" | "HELP" | "CLARIFY" | "ACTION" | "QUESTION",
  "direct_response": "for GREETING/HELP only, null otherwise",
  "clarify_question": "for CLARIFY only — the question to ask the user",
  "clarify_options": ["option1", "option2"],
  "final_goal": "one sentence: what we need to answer",
  "reasoning": "your thinking process — what systems to check, what data to get, why",
  "plan": [
    {{
      "tool": "run_query | call_api | read_files | <built_tool_name>",
      "technology": "<technology_name>",
      "params": {{}},
      "thought": "why this step is needed",
      "is_bootstrap": true,
      "needs_building": false
    }}
  ]
}}

For CLARIFY intent (when you need to ask the user):
{{
  "intent": "CLARIFY",
  "clarify_question": "Which database would you like to query? Here are the available databases:",
  "clarify_options": ["postgres (dataclaw_test on localhost:5432)"],
  "reasoning": "The user asked to list schemas but didn't specify which database.",
  "plan": []
}}

If a step needs a NEW tool built (bootstrap can't do it):
{{
  "tool": "proposed_tool_name",
  "technology": "target_tech",
  "params": {{}},
  "thought": "why bootstrap isn't enough",
  "is_bootstrap": false,
  "needs_building": true,
  "tool_description": "What the tool should do, in detail"
}}

## Examples

User: "list all tables in the raw schema"
{{
  "intent": "ACTION",
  "direct_response": null,
  "final_goal": "List tables in the raw schema",
  "reasoning": "The user wants table names from postgres. I can use run_query with information_schema.",
  "plan": [{{
    "tool": "run_query",
    "technology": "postgres",
    "params": {{"query": "SELECT table_name FROM information_schema.tables WHERE table_schema = 'raw' ORDER BY table_name"}},
    "thought": "Query information_schema to get all table names in raw schema",
    "is_bootstrap": true,
    "needs_building": false
  }}]
}}

User: "show me all Airflow DAGs"
{{
  "intent": "ACTION",
  "direct_response": null,
  "final_goal": "List all Airflow DAGs",
  "reasoning": "Airflow is an API technology. I can call the /api/v1/dags endpoint directly.",
  "plan": [{{
    "tool": "call_api",
    "technology": "airflow",
    "params": {{"endpoint": "/api/v1/dags", "extract_key": "dags"}},
    "thought": "Call Airflow REST API to list all DAGs",
    "is_bootstrap": true,
    "needs_building": false
  }}]
}}

User: "list dbt models"
{{
  "intent": "ACTION",
  "direct_response": null,
  "final_goal": "List all dbt models",
  "reasoning": "dbt is a filesystem technology. I can use read_files to list all .sql files in the models directory.",
  "plan": [{{
    "tool": "read_files",
    "technology": "dbt",
    "params": {{"action": "list", "pattern": "**/*.sql"}},
    "thought": "List all SQL model files in the dbt project",
    "is_bootstrap": true,
    "needs_building": false
  }}]
}}

User: "count rows in raw.orders"
{{
  "intent": "ACTION",
  "direct_response": null,
  "final_goal": "Count rows in raw.orders table",
  "reasoning": "Simple SQL count query against postgres.",
  "plan": [{{
    "tool": "run_query",
    "technology": "postgres",
    "params": {{"query": "SELECT COUNT(*) AS row_count FROM raw.orders"}},
    "thought": "Count rows using SQL COUNT",
    "is_bootstrap": true,
    "needs_building": false
  }}]
}}

User: "explain the data pipeline"
{{
  "intent": "QUESTION",
  "direct_response": null,
  "final_goal": "Explain the data pipeline structure and data flow",
  "reasoning": "To explain the pipeline, I need to see: what schemas exist in postgres, what tables are in each layer, what DAGs exist in Airflow, and what dbt models exist. Then I can synthesize an explanation.",
  "plan": [
    {{"tool": "run_query", "technology": "postgres", "params": {{"query": "SELECT schema_name FROM information_schema.schemata WHERE schema_name NOT IN ('pg_catalog', 'information_schema', 'pg_toast') ORDER BY schema_name"}}, "thought": "See what schemas exist", "is_bootstrap": true, "needs_building": false}},
    {{"tool": "run_query", "technology": "postgres", "params": {{"query": "SELECT table_schema, table_name FROM information_schema.tables WHERE table_schema IN ('raw', 'staging', 'mart') ORDER BY table_schema, table_name"}}, "thought": "Get all tables across data layers", "is_bootstrap": true, "needs_building": false}},
    {{"tool": "call_api", "technology": "airflow", "params": {{"endpoint": "/api/v1/dags", "extract_key": "dags"}}, "thought": "List DAGs that orchestrate the pipeline", "is_bootstrap": true, "needs_building": false}},
    {{"tool": "read_files", "technology": "dbt", "params": {{"action": "list", "pattern": "**/*.sql"}}, "thought": "List dbt models that transform data", "is_bootstrap": true, "needs_building": false}}
  ]
}}

User: "get tasks of the raw_data_ingestion DAG"
{{
  "intent": "ACTION",
  "direct_response": null,
  "final_goal": "Get all tasks of the raw_data_ingestion DAG",
  "reasoning": "Airflow has a REST API endpoint for DAG tasks at /api/v1/dags/{{dag_id}}/tasks.",
  "plan": [{{
    "tool": "call_api",
    "technology": "airflow",
    "params": {{"endpoint": "/api/v1/dags/raw_data_ingestion/tasks", "extract_key": "tasks"}},
    "thought": "Call Airflow API to get task list for this DAG",
    "is_bootstrap": true,
    "needs_building": false
  }}]
}}
"""


# ── Continuation reasoning prompt ──────────────────────

REASONING_PROMPT = """\
You are continuing to reason about the user's question.

User asked: "{user_prompt}"
Goal: {final_goal}

## What you've done so far
{steps_so_far}

## What you observed
{latest_observation}

## Available tools
- **run_query**: SQL against any database. Params: query, limit.
- **call_api**: HTTP to REST APIs. Params: endpoint, method, params, body, extract_key.
- **read_files**: Read/list/search files. Params: action, path, pattern, query.
- Any previously built tool by name.
- You can propose a NEW tool if none of the above can do what you need (set needs_building: true).

## Decision

Based on what you observed, decide:
1. **ENOUGH info** → set "done": true and write a clear, formatted answer.
2. **Need MORE** → set "done": false and specify the next step.
3. **Need a NEW tool** (bootstrap can't do it) → set needs_building: true in next_step.
4. **Step FAILED** → do NOT retry the same approach. Either try a different approach, or set "done": true and explain what you found and what couldn't be retrieved (and why).

**Style rules for answers:**
- Be CONCISE. Short paragraphs, bullet points, tables. No walls of text.
- Lead with the direct answer, then supporting details if needed.
- For data results: show the data clearly (table format or bullet list), then a 1-2 sentence summary.
- Do NOT repeat the queries you used or suggest follow-up queries unless the user asked for them.
- Do NOT give lengthy diagnostic instructions or suggest commands to run unless the user asked "why" or "how to fix".

Respond with ONLY this JSON:
{{
  "done": true | false,
  "reasoning": "what you learned, what's still needed",
  "answer": "final answer to the user (only if done=true, null otherwise)",
  "next_step": {{
    "tool": "tool_name",
    "technology": "tech_name",
    "params": {{}},
    "thought": "why this step is needed",
    "is_bootstrap": true | false,
    "needs_building": false,
    "tool_description": "what the tool should do (only if needs_building=true)"
  }} | null
}}
"""


def build_planning_prompt(
    user_prompt: str,
    registry: dict | None = None,
    connections: dict | None = None,
    memory_context: dict | None = None,
) -> str:
    """Build the initial planning prompt.

    Args:
        user_prompt: What the user typed.
        registry: Parsed registry.json dict. Loaded from disk if None.
        connections: Unused (kept for compat). Now reads from connections.yaml.
        memory_context: Memory context from MemoryStore.
    Returns:
        The fully rendered prompt string.
    """
    if registry is None:
        if REGISTRY_PATH.exists():
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
        else:
            registry = {"tools": []}

    # Connection summary from unified connections.yaml
    connection_summary = get_connection_summary()

    # Built tools (from registry — excludes bootstrap)
    built_tools = registry.get("tools", [])
    if built_tools:
        lines = []
        for t in built_tools:
            lines.append(f"- **{t['name']}** ({t.get('technology', '?')}): {t.get('description', '')}")
        built_tools_str = "\n".join(lines)
    else:
        built_tools_str = "(none yet — the agent hasn't built any specialized tools)"

    # Memory section
    memory_section = _build_memory_section(memory_context)

    # Use replace instead of .format() to avoid KeyError from user input
    # containing {curly} braces
    result = PLANNING_PROMPT
    result = result.replace("{user_prompt}", user_prompt)
    result = result.replace("{connection_summary}", connection_summary)
    result = result.replace("{built_tools}", built_tools_str)
    result = result.replace("{memory_section}", memory_section)
    return result


def build_reasoning_prompt(
    user_prompt: str,
    final_goal: str,
    steps_so_far: list[dict],
    latest_observation: str,
) -> str:
    """Build a continuation reasoning prompt.

    Args:
        user_prompt: Original user question.
        final_goal: What we're trying to answer.
        steps_so_far: List of completed reasoning steps.
        latest_observation: Result of the last action.
    Returns:
        The filled reasoning prompt.
    """
    # Format steps
    step_lines = []
    for i, step in enumerate(steps_so_far, 1):
        tool = step.get("tool", "?")
        thought = step.get("thought", "")
        status = step.get("status", "?")
        step_lines.append(f"  Step {i}: [{status}] {tool} — {thought}")
    steps_str = "\n".join(step_lines) if step_lines else "(no steps yet)"

    # Truncate observation if too long
    from utils.constants import get as get_config
    max_obs = get_config("max_observation_length")
    if len(latest_observation) > max_obs:
        latest_observation = latest_observation[:max_obs] + "\n... (truncated)"

    # Use replace instead of .format() to avoid KeyError from user input
    # containing {curly} braces
    result = REASONING_PROMPT
    result = result.replace("{user_prompt}", user_prompt)
    result = result.replace("{final_goal}", final_goal)
    result = result.replace("{steps_so_far}", steps_str)
    result = result.replace("{latest_observation}", latest_observation)
    return result


def _build_memory_section(memory_context: dict | None) -> str:
    """Build memory injection section for planning prompt."""
    if not memory_context:
        return ""

    sections = []

    history = memory_context.get("conversation_history", "")
    if history:
        sections.append(f"\n## Recent Conversation\n{history}")

    entity_matches = memory_context.get("entity_matches_formatted", "")
    if entity_matches:
        sections.append(
            f"\n## Entity References (from previous discoveries)\n"
            f"The user mentions entities seen before:\n{entity_matches}\n"
            f"USE the correct technology for these entities."
        )

    active_tech = memory_context.get("active_technology")
    if active_tech:
        sections.append(f"\n## Active Technology Context\nThe user has been working with: {active_tech}")

    if not entity_matches:
        catalog = memory_context.get("catalog_summary", "")
        if catalog:
            sections.append(f"\n## Known Data Entities (discovered previously)\n{catalog}")

    return "\n".join(sections)
