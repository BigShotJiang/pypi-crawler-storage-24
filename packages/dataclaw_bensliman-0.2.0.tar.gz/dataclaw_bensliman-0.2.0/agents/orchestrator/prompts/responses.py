"""Canned responses for GREETING and HELP intents.

These bypass the tool pipeline entirely — no LLM needed.
"""

import json
from pathlib import Path

from utils.connections import list_configured_technologies

REGISTRY_PATH = Path(__file__).parent.parent.parent.parent / "mcp-tools" / "registry.json"


GREETINGS = {
    "hello": "Hello! I'm DataClaw, your autonomous data agent. Ask me anything about your data systems.",
    "hi": "Hi there! I can query databases, call APIs, browse files — ask me anything.",
    "hey": "Hey! What data question can I help you with?",
    "thanks": "You're welcome! Let me know if you need anything else.",
    "thank you": "You're welcome! Happy to help.",
    "bye": "Goodbye! Everything I've learned is saved for next time.",
    "good morning": "Good morning! What data task can I help you with today?",
    "good evening": "Good evening! What data would you like to explore?",
}

DEFAULT_GREETING = "Hello! I'm DataClaw, your autonomous data agent. Ask me anything about your data systems."


def get_greeting(prompt: str) -> str:
    """Return a greeting response."""
    prompt_lower = prompt.lower().strip()
    for key, response in GREETINGS.items():
        if key in prompt_lower:
            return response
    return DEFAULT_GREETING


def get_help_response() -> str:
    """Return a help message listing capabilities and systems."""
    # Show configured technologies
    techs = list_configured_technologies()
    tech_section = ""
    if techs:
        lines = []
        for t in techs:
            lines.append(f"  {t['name']} ({t['type']}) — access: {t['access_level']}")
        tech_section = "\n".join(lines)

    # Show agent-built tools
    tools_section = ""
    if REGISTRY_PATH.exists():
        try:
            registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            tools = registry.get("tools", [])
            if tools:
                by_tech: dict[str, list[str]] = {}
                for t in tools:
                    tech = t.get("technology", "unknown")
                    by_tech.setdefault(tech, []).append(t["name"])
                lines = []
                for tech, names in sorted(by_tech.items()):
                    lines.append(f"  {tech}: {', '.join(names)}")
                tools_section = "\n".join(lines)
        except Exception:
            pass

    help_text = (
        "I'm DataClaw — an autonomous data agent that reasons about your data systems.\n\n"
        "How I work:\n"
        "  1. Bootstrap tools (run_query, call_api, read_files) handle common tasks instantly\n"
        "  2. For anything else, I BUILD a specialized tool from scratch\n"
        "  3. I learn and grow — each tool I build stays in my library forever\n\n"
        "I can connect to ANY technology — databases, APIs, message queues, servers —\n"
        "as long as it's configured in connections.yaml.\n\n"
        "Things you can ask me:\n"
        "  - \"list all tables in the raw schema\"\n"
        "  - \"count rows in raw.orders\"\n"
        "  - \"show me all Airflow DAGs\"\n"
        "  - \"get tasks of the raw_data_ingestion DAG\"\n"
        "  - \"list dbt models\"\n"
        "  - \"explain the data pipeline\"\n"
        "  - \"top 5 customers by order count\"\n"
    )

    if tech_section:
        help_text += f"\nConfigured systems:\n{tech_section}\n"

    if tools_section:
        help_text += f"\nSpecialized tools I've built:\n{tools_section}\n"
    else:
        help_text += "\nNo specialized tools built yet — I'll build them as needed.\n"

    help_text += (
        "\nFor new technologies (Kafka, SSH, MongoDB, etc.), just add the connection\n"
        "config and I'll figure out the right driver and build tools from scratch."
    )
    return help_text
