"""Scans mcp-tools/technologies/ and registry.json for existing tools."""

import importlib.util
import json
import sys
from pathlib import Path

MCP_TOOLS_DIR = Path(__file__).parent.parent.parent / "mcp-tools" / "technologies"
REGISTRY_PATH = MCP_TOOLS_DIR.parent / "registry.json"


def _load_technology_module(technology: str):
    """Load a technology module from file path.

    Args:
        technology: Technology name (e.g., 'postgres')
    Returns:
        The loaded module, or None if file doesn't exist
    """
    tech_file = MCP_TOOLS_DIR / f"{technology}.py"
    if not tech_file.exists():
        return None

    module_name = f"mcp_tools.technologies.{technology}"
    if module_name in sys.modules:
        return sys.modules[module_name]

    spec = importlib.util.spec_from_file_location(module_name, tech_file)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def find_tool(tool_name: str, technology: str | None = None) -> dict | None:
    """Search registry for an existing tool. Returns tool metadata or None.

    Args:
        tool_name: Exact tool name to search for
        technology: Optional technology filter for fuzzy matching
    Returns:
        Tool registry entry dict, or None if not found
    """
    if not REGISTRY_PATH.exists():
        return None

    registry = json.loads(REGISTRY_PATH.read_text())
    for tool in registry.get("tools", []):
        if tool["name"] == tool_name:
            return tool
    # Fuzzy match: search within a specific technology
    if technology:
        for tool in registry.get("tools", []):
            if tool.get("technology") == technology:
                if tool_name in tool.get("description", "").lower():
                    return tool
    return None


def search_tools_by_description(query: str, technology: str | None = None) -> list[dict]:
    """Search tools by matching query terms against descriptions.

    Requires at least half of the meaningful query terms to match.
    Filters out common stop words to improve match quality.

    Args:
        query: Search terms to match
        technology: Optional technology filter
    Returns:
        List of matching tool registry entries, sorted by match score descending
    """
    if not REGISTRY_PATH.exists():
        return []

    stop_words = {
        "the", "a", "an", "in", "on", "of", "for", "to", "from", "with",
        "and", "or", "is", "are", "my", "all", "get", "give", "me", "show",
    }

    registry = json.loads(REGISTRY_PATH.read_text())
    query_terms = [
        t for t in query.lower().split()
        if t not in stop_words and len(t) > 1
    ]
    if not query_terms:
        return []

    threshold = max(1, len(query_terms) // 2)
    scored = []

    for tool in registry.get("tools", []):
        if technology and tool.get("technology") != technology:
            continue
        desc = tool.get("description", "").lower()
        name = tool.get("name", "").lower()
        searchable = f"{name} {desc}"
        hits = sum(1 for term in query_terms if term in searchable)
        if hits >= threshold:
            scored.append((hits, tool))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [tool for _, tool in scored]


def get_tool_technology(tool_name: str) -> str | None:
    """Look up the registered technology for a tool.

    The registry is the source of truth for which technology a tool belongs to.
    This prevents mismatches where the LLM assigns technology="dbt" but the tool
    is actually a postgres tool.

    Args:
        tool_name: Exact tool name.
    Returns:
        Technology string, or None if not found.
    """
    if not REGISTRY_PATH.exists():
        return None

    registry = json.loads(REGISTRY_PATH.read_text())
    for tool in registry.get("tools", []):
        if tool["name"] == tool_name:
            return tool.get("technology")
    return None


def list_tools_for_technology(technology: str) -> list[dict]:
    """List all available tools for a given technology.

    Args:
        technology: Technology name (e.g., 'postgres')
    Returns:
        List of tool entries from the TOOLS dict in the technology file
    """
    module = _load_technology_module(technology)
    if module is None:
        return []
    return [
        {"name": name, **{k: v for k, v in meta.items() if k != "function"}}
        for name, meta in getattr(module, "TOOLS", {}).items()
    ]


def list_all_technologies() -> list[str]:
    """List all available technology files.

    Returns:
        List of technology names (file stems)
    """
    return [
        f.stem
        for f in MCP_TOOLS_DIR.glob("*.py")
        if f.stem != "_template" and f.stem != "__init__"
    ]
