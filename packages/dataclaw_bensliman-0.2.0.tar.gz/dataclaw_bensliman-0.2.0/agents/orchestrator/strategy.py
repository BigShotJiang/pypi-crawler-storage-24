"""Decides: reuse existing tool, build new tool, or retry with context."""

import logging
import uuid
from typing import Optional

from contracts.tool_request import TaskAction, ToolRequest

logger = logging.getLogger(__name__)


def decide(
    user_prompt: str,
    tool_name: str,
    technology: str,
    existing_tool: dict | None,
    failure_reason: Optional[str] = None,
    failure_details: Optional[str] = None,
) -> dict:
    """Determine the action to take based on tool finder results and context.

    Args:
        user_prompt: The original user request
        tool_name: Inferred tool name
        technology: Inferred technology
        existing_tool: Result from tool_finder, or None if no match
        failure_reason: Previous failure reason if retrying
        failure_details: Previous failure details if retrying
    Returns:
        Dict with 'action' (reuse/build_new/refactor) and 'tool_request' if building
    """
    task_id = str(uuid.uuid4())[:8]

    # Case 1: Tool exists and no previous failure → reuse it
    if existing_tool and not failure_reason:
        logger.info(f"Strategy: reuse existing tool '{existing_tool['name']}'")
        return {
            "action": "reuse",
            "task_id": task_id,
            "tool_name": existing_tool["name"],
            "technology": existing_tool.get("technology", technology),
            "tool_found": True,
        }

    # Case 2: Tool exists but previously failed → refactor it
    if existing_tool and failure_reason:
        logger.info(f"Strategy: refactor tool '{existing_tool['name']}' due to {failure_reason}")
        retry_context = f"Previous failure ({failure_reason}): {failure_details or 'no details'}"
        tool_request = ToolRequest(
            task_id=task_id,
            action=TaskAction.REFACTOR,
            tool_name=existing_tool["name"],
            tool_description=user_prompt,
            connection_type=technology,
            retry_context=retry_context,
        )
        return {
            "action": "refactor",
            "task_id": task_id,
            "tool_name": existing_tool["name"],
            "technology": technology,
            "tool_found": False,
            "tool_request": tool_request,
        }

    # Case 3: No existing tool → build new
    logger.info(f"Strategy: build new tool '{tool_name}' for {technology}")
    retry_context = None
    if failure_reason:
        retry_context = f"Previous failure ({failure_reason}): {failure_details or 'no details'}"

    tool_request = ToolRequest(
        task_id=task_id,
        action=TaskAction.BUILD_NEW,
        tool_name=tool_name,
        tool_description=user_prompt,
        connection_type=technology,
        retry_context=retry_context,
    )
    return {
        "action": "build_new",
        "task_id": task_id,
        "tool_name": tool_name,
        "technology": technology,
        "tool_found": False,
        "tool_request": tool_request,
    }


def infer_tool_name(user_prompt: str) -> str:
    """Infer a snake_case tool name from the user's prompt.

    Generic: scans for action patterns and maps to known tool names.
    Falls back to cleaning the prompt into a snake_case name for new tools.

    Args:
        user_prompt: The user's natural language request
    Returns:
        A reasonable snake_case tool name
    """
    prompt_lower = user_prompt.lower().strip()

    # Ordered patterns: first match wins. More specific patterns first.
    keyword_map = [
        # Postgres tools
        ("list schemas", "list_schemas"),
        ("show schemas", "list_schemas"),
        ("what schemas", "list_schemas"),
        ("list tables", "list_tables"),
        ("show tables", "list_tables"),
        ("what tables", "list_tables"),
        ("describe table", "describe_table"),
        ("describe the", "describe_table"),
        ("show columns", "describe_table"),
        ("table structure", "describe_table"),
        ("column", "describe_table"),
        ("how many rows", "run_query"),
        ("count rows", "run_query"),
        ("row count", "run_query"),
        ("count of", "run_query"),
        ("run query", "run_query"),
        ("execute query", "run_query"),
        ("select ", "run_query"),
        ("top 5", "run_query"),
        ("top 10", "run_query"),
        ("average", "run_query"),
        ("sum of", "run_query"),
        ("group by", "run_query"),
        # Airflow tools
        ("list dag", "list_dags"),
        ("show dag", "list_dags"),
        ("all dag", "list_dags"),
        ("task", "get_dag_tasks"),
        ("dag run", "get_dag_runs"),
        ("dag config", "get_dag_config"),
        ("dag detail", "get_dag_config"),
        # dbt tools
        ("list dbt", "list_dbt_models"),
        ("list model", "list_dbt_models"),
        ("dbt model", "list_dbt_models"),
        ("read model", "read_model_file"),
        ("read the sql", "read_model_file"),
        ("model file", "read_model_file"),
        ("explain", "read_model_file"),
        ("model sql", "read_model_file"),
    ]
    for pattern, name in keyword_map:
        if pattern in prompt_lower:
            return name

    # Fallback: clean up the prompt into a tool name
    words = prompt_lower.split()[:4]
    clean = "_".join(w for w in words if w.isalnum())
    return clean or "custom_tool"


def infer_technology(user_prompt: str, connection_config: dict | None = None) -> str:
    """Infer the target technology from the prompt or connection config.

    Generic: scans for technology keywords in the prompt.

    Args:
        user_prompt: The user's natural language request
        connection_config: Optional connection config dict
    Returns:
        Technology name (e.g., 'postgres')
    """
    prompt_lower = user_prompt.lower()

    # Check prompt for technology keywords (ordered: most specific first)
    tech_keywords = {
        "dbt": ["dbt", "dbt model", "staging model", "mart model", "stg_", "dim_", "fact_"],
        "airflow": ["airflow", "dag ", "dags"],
        "kafka": ["kafka", "topic", "broker", "consumer", "producer"],
        "postgres": ["postgres", "postgresql", "psql", "pg_", "schema", "table", "query", "rows", "sql"],
        "snowflake": ["snowflake", "snow"],
        "mysql": ["mysql", "mariadb"],
        "sqlite": ["sqlite"],
        "mongodb": ["mongo", "mongodb"],
        "redis": ["redis"],
        "ssh_server": ["ssh", "remote server", "remote file"],
    }
    for tech, keywords in tech_keywords.items():
        if any(kw in prompt_lower for kw in keywords):
            # Verify this key exists in connections; if not, try to find it
            from utils.connections import load_all_connections
            all_conns = load_all_connections()
            if tech in all_conns:
                return tech
            # Fuzzy match: find a connection whose name contains the inferred tech
            for name in all_conns:
                if tech in name or name in tech:
                    return name
            return tech

    # Check connection config
    if connection_config:
        driver = connection_config.get("driver", "")
        if "psycopg" in driver:
            return "postgres"
        if "snowflake" in driver:
            return "snowflake"
        if "mysql" in driver:
            return "mysql"

    # Default to postgres
    return "postgres"


def infer_params(user_prompt: str, tool_name: str) -> dict:
    """Infer tool params from the prompt.

    Generic: scans for common entity references and builds params accordingly.

    Args:
        user_prompt: The user's natural language request
        tool_name: The inferred tool name
    Returns:
        Dict of params to pass to the tool.
    """
    import re
    prompt_lower = user_prompt.lower()
    params: dict = {}

    if tool_name == "list_tables":
        # Extract schema name
        schema_match = re.search(r"(?:in|from|of)\s+(?:the\s+)?(\w+)\s+schema", prompt_lower)
        if schema_match:
            params["schema"] = schema_match.group(1)
        else:
            params["schema"] = "raw"

    elif tool_name == "describe_table":
        # Extract schema.table or just table
        qualified = re.search(r"(?:table\s+|describe\s+(?:the\s+)?)(\w+)\.(\w+)", prompt_lower)
        if qualified:
            params["schema"] = qualified.group(1)
            params["table"] = qualified.group(2)
        else:
            table_match = re.search(r"(?:table\s+|describe\s+(?:the\s+)?)(\w+)", prompt_lower)
            if table_match:
                name = table_match.group(1)
                if name not in ("the", "a", "table"):
                    params["table"] = name
            # Try to find schema
            schema_match = re.search(r"(?:in|from)\s+(?:the\s+)?(\w+)\s+schema", prompt_lower)
            if schema_match:
                params["schema"] = schema_match.group(1)
            elif "schema" not in params:
                params["schema"] = "public"

    elif tool_name == "run_query":
        # Try to build a simple SQL query from the prompt
        # Look for table references
        table_match = re.search(r"(?:in|from|of)\s+(?:the\s+)?(?:(\w+)\.)?(\w+?)(?:\s|$|\?)", prompt_lower)
        table_name = None
        schema_name = "public"
        if table_match:
            if table_match.group(1):
                schema_name = table_match.group(1)
            table_name = table_match.group(2)

        if "how many" in prompt_lower or "count" in prompt_lower:
            if table_name:
                params["query"] = f"SELECT COUNT(*) AS row_count FROM {schema_name}.{table_name}"
            else:
                params["query"] = "SELECT 1 AS test"
        else:
            params["query"] = "SELECT 1 AS test"

    elif tool_name == "read_model_file":
        # Extract model name (e.g., dim_customers, stg_orders)
        model_match = re.search(r"((?:dim|fact|stg|int|src)_\w+)", prompt_lower)
        if model_match:
            params["model_name"] = model_match.group(1)
        else:
            # Try to find any word after "model" or "explain"
            name_match = re.search(r"(?:model|explain|read)\s+(?:the\s+)?(?:sql\s+(?:of\s+)?(?:the\s+)?)?(\w+)", prompt_lower)
            if name_match and name_match.group(1) not in ("the", "a", "model", "sql", "of", "dbt", "file"):
                params["model_name"] = name_match.group(1)

    elif tool_name in ("get_dag_tasks", "get_dag_runs", "get_dag_config"):
        # Extract dag_id
        dag_match = re.search(r"(?:dag\s+(?:named?\s+)?|of\s+(?:the\s+)?)(\w+)", prompt_lower)
        if dag_match and dag_match.group(1) not in ("the", "a", "dag", "in", "from", "named"):
            params["dag_id"] = dag_match.group(1)

    return params
