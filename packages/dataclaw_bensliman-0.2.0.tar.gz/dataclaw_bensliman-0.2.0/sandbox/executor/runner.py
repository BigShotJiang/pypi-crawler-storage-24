"""Executes tool code in an isolated Docker container.

Returns stdout, stderr, exit_code.
"""

import asyncio
import logging
import sys
import tempfile
from pathlib import Path

from sandbox.executor.container_manager import ContainerManager
from sandbox.executor.timeout import TimeoutHandler, TimeoutError

logger = logging.getLogger(__name__)


class SandboxRunner:
    """Main interface for running tool code in isolated containers.

    Usage:
        runner = SandboxRunner(config)
        result = await runner.execute(code, connection_config)
        # result = {"stdout": ..., "stderr": ..., "exit_code": ...}
    """

    def __init__(self, config: dict) -> None:
        self.container_manager = ContainerManager(config)
        self.timeout_handler = TimeoutHandler(config.get("timeout_per_test_s", 30))

    def remap_paths(self, connection_config: dict) -> dict:
        """Remap host paths in connection_config for container use.

        Must be called BEFORE generating the test script so the script
        gets container paths baked in. Queues volume mounts for create().

        Args:
            connection_config: Original config with host paths.
        Returns:
            New config dict with container-friendly paths.
        """
        return self.container_manager.remap_paths(connection_config)

    async def execute(self, code: str, connection_config: dict, technology: str = "") -> dict:
        """Run tool code in isolation.

        Creates a throwaway Docker container, writes the code to the
        mounted script file, executes it, collects output, and destroys
        the container.

        Args:
            code: Python source code to execute
            connection_config: Connection params to inject (determines network policy)
            technology: Technology name for installing required packages
        Returns:
            {"stdout": str, "stderr": str, "exit_code": int}
        """
        container = await self.container_manager.create(connection_config, technology, code=code)
        try:
            # Write the actual code to the mounted script file
            self._write_script(container.script_path, code)

            # Execute with timeout
            result = await self.timeout_handler.run(
                container.exec(code)
            )
            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.exit_code,
            }
        except TimeoutError as e:
            logger.error(f"Sandbox timeout: {e}")
            return {
                "stdout": "",
                "stderr": str(e),
                "exit_code": -1,
            }
        except Exception as e:
            error_str = str(e)
            logger.error(f"Sandbox error: {error_str}")

            # On Windows charmap errors, refuse to fall back to unsandboxed execution
            if "charmap" in error_str or "codec can't encode" in error_str:
                logger.error("Docker encoding error on Windows. Refusing unsandboxed fallback.")
                return {
                    "stdout": "",
                    "stderr": f"Sandbox infrastructure error (Windows encoding): {error_str}. Cannot run unsandboxed for security reasons.",
                    "exit_code": -1,
                }

            return {
                "stdout": "",
                "stderr": f"Sandbox infrastructure error: {error_str}",
                "exit_code": -1,
            }
        finally:
            await self.container_manager.destroy(container)

    async def _subprocess_fallback(
        self, code: str, connection_config: dict, technology: str
    ) -> dict:
        """Fallback: run tool code as a local subprocess when Docker has issues.

        Args:
            code: Python source code to execute.
            connection_config: Connection params (unused in subprocess mode).
            technology: Technology name (unused in subprocess mode).
        Returns:
            {"stdout": str, "stderr": str, "exit_code": int}
        """
        import tempfile

        timeout_s = self.timeout_handler._timeout_seconds

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False,
            prefix="dataclaw_sub_", encoding="utf-8",
        ) as f:
            f.write(code)
            script_path = f.name

        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, script_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(), timeout=timeout_s
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                return {
                    "stdout": "",
                    "stderr": f"Execution timed out after {timeout_s}s",
                    "exit_code": -1,
                }
            return {
                "stdout": stdout.decode("utf-8", errors="replace"),
                "stderr": stderr.decode("utf-8", errors="replace"),
                "exit_code": proc.returncode,
            }
        finally:
            Path(script_path).unlink(missing_ok=True)

    def _write_script(self, script_path: str, code: str) -> None:
        """Write the test script to the mounted file.

        Args:
            script_path: Path to the temp file on the host
            code: Python source code to write
        """
        Path(script_path).write_text(code, encoding="utf-8")
        logger.debug(f"Wrote {len(code)} chars to {script_path}")
