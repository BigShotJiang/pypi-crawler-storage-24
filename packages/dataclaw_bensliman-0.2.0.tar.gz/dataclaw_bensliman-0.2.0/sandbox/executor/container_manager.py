"""Create and destroy Docker containers using the Docker SDK.

Dependencies are auto-detected by scanning import statements in the
generated code — no hardcoded per-technology mapping.
"""

import logging
import re
import tempfile
from pathlib import Path
from typing import Any, Optional

import docker
from docker.errors import DockerException, NotFound

from sandbox.security.filesystem_policy import FilesystemPolicy
from sandbox.security.network_policy import NetworkPolicy

logger = logging.getLogger(__name__)


# Python import name → pip package name (only for packages where they differ)
PIP_NAME_MAP = {
    "yaml": "pyyaml",
    "psycopg2": "psycopg2-binary",
    "cv2": "opencv-python",
    "sklearn": "scikit-learn",
    "bs4": "beautifulsoup4",
    "dotenv": "python-dotenv",
    "PIL": "Pillow",
    "git": "gitpython",
    "jose": "python-jose",
    "jwt": "pyjwt",
    "attr": "attrs",
    "dateutil": "python-dateutil",
    "lxml": "lxml",
    "bson": "pymongo",
    "kafka": "kafka-python",
    "confluent_kafka": "confluent-kafka",
    "paramiko": "paramiko",
    "pymongo": "pymongo",
    "redis": "redis",
    "boto3": "boto3",
    "minio": "minio",
    "elasticsearch": "elasticsearch",
    "cassandra": "cassandra-driver",
    "clickhouse_driver": "clickhouse-driver",
    "pika": "pika",
    "nats": "nats-py",
}

# Standard library modules — never try to pip install these
STDLIB_MODULES = {
    "os", "sys", "re", "json", "pathlib", "logging", "typing", "time",
    "datetime", "collections", "functools", "itertools", "math", "random",
    "hashlib", "hmac", "base64", "io", "csv", "tempfile", "shutil",
    "subprocess", "threading", "asyncio", "socket", "http", "urllib",
    "unittest", "dataclasses", "enum", "abc", "copy", "glob", "fnmatch",
    "textwrap", "string", "struct", "codecs", "unicodedata", "pprint",
    "contextlib", "traceback", "warnings", "weakref", "operator",
    "statistics", "decimal", "fractions", "numbers", "cmath",
    "xml", "html", "email", "mimetypes", "configparser", "argparse",
    "getpass", "platform", "signal", "secrets", "uuid", "zipfile",
    "tarfile", "gzip", "bz2", "lzma", "sqlite3", "dbm", "pickle",
    "shelve", "marshal", "array", "queue", "heapq", "bisect",
    "sched", "select", "selectors", "ssl", "ftplib", "smtplib",
    "imaplib", "poplib", "xmlrpc", "ipaddress", "multiprocessing",
    "concurrent", "ctypes", "importlib",
    # Platform-specific stdlib (Unix-only, but still stdlib)
    "grp", "pwd", "fcntl", "termios", "resource", "posix", "pty", "tty",
}


def detect_dependencies(code: str) -> list[str]:
    """Scan Python code for import statements and return pip packages to install.

    Args:
        code: Python source code to scan.
    Returns:
        List of pip package names to install.
    """
    # Extract import names (top-level and inside functions)
    import_pattern = re.compile(
        r"^\s*(?:import|from)\s+(\w+)", re.MULTILINE
    )
    imports = set(import_pattern.findall(code))

    # Filter out stdlib and builtins
    third_party = imports - STDLIB_MODULES

    # Map to pip names
    pip_packages = []
    for mod in sorted(third_party):
        pip_name = PIP_NAME_MAP.get(mod, mod)
        pip_packages.append(pip_name)

    return pip_packages


class ContainerHandle:
    """Handle to a running sandbox container."""

    def __init__(self, container: Any, script_path: str) -> None:
        self._container = container
        self._script_path = script_path

    @property
    def id(self) -> str:
        """Container ID."""
        return self._container.id

    @property
    def short_id(self) -> str:
        """Short container ID."""
        return self._container.short_id

    @property
    def script_path(self) -> str:
        """Path to the test script on the host."""
        return self._script_path

    async def exec(self, code: str) -> "ExecResult":
        """Execute Python code inside the container.

        Args:
            code: Ignored — code is already mounted via script_path.
        Returns:
            ExecResult with stdout, stderr, exit_code
        """
        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._exec_sync)

    def _exec_sync(self) -> "ExecResult":
        """Synchronous execution inside the container."""
        try:
            exit_code, output = self._container.exec_run(
                cmd=["python", "/workspace/test_script.py"],
                demux=True,
            )
            stdout = output[0].decode("utf-8", errors="replace") if output[0] else ""
            stderr = output[1].decode("utf-8", errors="replace") if output[1] else ""
            return ExecResult(stdout=stdout, stderr=stderr, exit_code=exit_code)
        except Exception as e:
            return ExecResult(stdout="", stderr=str(e), exit_code=-1)


class ExecResult:
    """Result of executing code in a container."""

    def __init__(self, stdout: str, stderr: str, exit_code: int) -> None:
        self.stdout = stdout
        self.stderr = stderr
        self.exit_code = exit_code


class ContainerManager:
    """Manages lifecycle of throwaway Docker containers for sandbox execution."""

    def __init__(self, config: dict) -> None:
        self._image = config.get("image", "python:3.11-slim")
        self._memory_limit = config.get("memory_limit", "512m")
        self._network_policy = NetworkPolicy(
            default_mode=config.get("network_mode", "none")
        )
        self._filesystem_policy = FilesystemPolicy()
        self._client: Optional[docker.DockerClient] = None
        self._pending_mounts: dict[str, str] = {}  # host_path -> container_path

    def remap_paths(self, connection_config: dict) -> dict:
        """Remap host filesystem paths in connection_config to container paths.

        Call this BEFORE generating the test script. The remapped config
        will have container-friendly paths (/mnt/dataclaw/0, etc.) that
        the sandbox can access. The corresponding volume mounts are queued
        and applied when create() is called.

        Args:
            connection_config: Original config with host paths.
        Returns:
            New config dict with paths rewritten for container use.
            If no paths found, returns a copy of the original.
        """
        path_keys = ("project_dir", "profiles_dir", "models_dir", "path",
                      "data_dir", "log_dir", "remote_dir", "config_dir")

        remapped = dict(connection_config)
        host_to_container: dict[str, str] = {}
        mount_index = 0

        for key in path_keys:
            host_path = remapped.get(key, "")
            if not host_path:
                continue
            host_resolved = str(Path(host_path).resolve())
            if not Path(host_resolved).exists():
                logger.warning(f"Path for '{key}' does not exist: {host_resolved}")
                continue

            # Check if this is a subdirectory of an already-mounted path
            container_path = None
            for mounted_host, mounted_container in host_to_container.items():
                if host_resolved.startswith(mounted_host):
                    relative = host_resolved[len(mounted_host):].replace("\\", "/").lstrip("/")
                    container_path = f"{mounted_container}/{relative}" if relative else mounted_container
                    break

            if container_path is None:
                container_path = f"/mnt/dataclaw/{mount_index}"
                host_to_container[host_resolved] = container_path
                mount_index += 1

            remapped[key] = container_path

        # Queue mounts for create()
        self._pending_mounts = host_to_container
        return remapped

    def _ensure_client(self) -> docker.DockerClient:
        """Lazily initialize the Docker client."""
        if self._client is None:
            self._client = docker.from_env()
            logger.info("Docker client connected")
        return self._client

    async def create(
        self,
        connection_config: dict,
        technology: str = "",
        code: str = "",
    ) -> ContainerHandle:
        """Create a throwaway container.

        Dependencies are auto-detected from the code's import statements.

        Args:
            connection_config: Connection parameters (determines network policy).
            technology: Technology name (for logging only).
            code: The Python code that will run — scanned for imports.
        Returns:
            ContainerHandle for executing code.
        """
        import asyncio
        import functools

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            functools.partial(self._create_sync, connection_config, technology, code),
        )

    def _create_sync(
        self,
        connection_config: dict,
        technology: str = "",
        code: str = "",
    ) -> ContainerHandle:
        """Synchronous container creation."""
        client = self._ensure_client()

        # Compute security policies
        net_config = self._network_policy.compute_network_config(connection_config)
        fs_config = self._filesystem_policy.compute_filesystem_config()

        # Auto-detect dependencies from code
        deps = detect_dependencies(code) if code else []

        # Create temp file for the test script
        script_file = tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, prefix="dataclaw_test_",
            encoding="utf-8",
        )
        script_file.write("# placeholder - replaced by runner before exec")
        script_file.close()
        script_path = str(Path(script_file.name).resolve())

        volumes = {
            script_path: {"bind": "/workspace/test_script.py", "mode": "ro"},
        }

        # Mount host paths from the remapping (computed by remap_paths)
        for host_path, container_path in self._pending_mounts.items():
            volumes[host_path] = {"bind": container_path, "mode": "ro"}
        self._pending_mounts = {}  # reset after use

        # When we need to install deps, filesystem can't be read-only
        needs_deps = bool(deps)

        container = client.containers.create(
            image=self._image,
            command=["sleep", "3600"],
            detach=True,
            mem_limit=self._memory_limit,
            network_mode=net_config["network_mode"],
            read_only=fs_config["read_only"] if not needs_deps else False,
            tmpfs=fs_config["tmpfs"],
            volumes=volumes,
            environment={"PYTHONIOENCODING": "utf-8"},
            labels={"dataclaw": "sandbox"},
        )
        container.start()
        logger.info(f"Container created: {container.short_id} (image={self._image})")

        # Install auto-detected dependencies
        if deps:
            pip_cmd = ["pip", "install", "--quiet", "--disable-pip-version-check"] + deps
            logger.info(f"Auto-installing sandbox deps: {deps}")
            exit_code, output = container.exec_run(cmd=pip_cmd, demux=True)
            if exit_code != 0:
                stderr = output[1].decode("utf-8", errors="replace") if output[1] else ""
                logger.error(f"pip install failed (exit {exit_code}): {stderr[:200]}")
                raise RuntimeError(
                    f"Failed to install dependencies {deps} in sandbox: {stderr[:200]}"
                )

        return ContainerHandle(container, script_path)

    async def destroy(self, handle: ContainerHandle) -> None:
        """Stop and remove a sandbox container."""
        import asyncio

        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._destroy_sync, handle)

    def _destroy_sync(self, handle: ContainerHandle) -> None:
        """Synchronous container destruction."""
        try:
            container = self._ensure_client().containers.get(handle.id)
            container.stop(timeout=5)
            container.remove(force=True)
            logger.info(f"Container destroyed: {handle.short_id}")
        except NotFound:
            logger.debug(f"Container already removed: {handle.short_id}")
        except Exception as e:
            logger.warning(f"Error destroying container {handle.short_id}: {e}")

        try:
            Path(handle.script_path).unlink(missing_ok=True)
        except Exception:
            pass
