"""Asyncio-based hard kill after N seconds."""

import asyncio
import logging
from typing import Any, Coroutine

logger = logging.getLogger(__name__)


class TimeoutError(Exception):
    """Raised when sandbox execution exceeds the time limit."""

    def __init__(self, seconds: int) -> None:
        self.seconds = seconds
        super().__init__(f"Execution timed out after {seconds}s")


class TimeoutHandler:
    """Wraps an async operation with a hard timeout."""

    def __init__(self, timeout_seconds: int = 30) -> None:
        self._timeout = timeout_seconds

    async def run(self, coro: Coroutine) -> Any:
        """Execute a coroutine with a hard timeout.

        Args:
            coro: The coroutine to execute
        Returns:
            The coroutine's return value
        Raises:
            TimeoutError: If execution exceeds the configured timeout
        """
        try:
            return await asyncio.wait_for(coro, timeout=self._timeout)
        except asyncio.TimeoutError:
            logger.error(f"Execution timed out after {self._timeout}s")
            raise TimeoutError(self._timeout)

    @property
    def timeout_seconds(self) -> int:
        """Return the configured timeout in seconds."""
        return self._timeout
