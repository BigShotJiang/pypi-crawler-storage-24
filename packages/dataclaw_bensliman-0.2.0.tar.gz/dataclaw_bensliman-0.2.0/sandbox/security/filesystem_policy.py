"""Filesystem policy — read-only except /tmp.

Configures Docker bind mounts and tmpfs so generated tool code
cannot write to persistent storage inside the container.
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)


class FilesystemPolicy:
    """Determines Docker filesystem mount settings for sandbox containers."""

    # Writable paths inside the container
    WRITABLE_PATHS = ["/tmp"]

    # Default tmpfs size limit
    DEFAULT_TMPFS_SIZE = "64m"

    def compute_filesystem_config(self) -> dict:
        """Compute Docker filesystem configuration for a sandbox container.

        The root filesystem is read-only. Only /tmp is writable via tmpfs.

        Returns:
            Dict with Docker filesystem settings:
              - read_only: True (root fs is read-only)
              - tmpfs: dict of path -> options for writable tmpfs mounts
        """
        tmpfs = {}
        for path in self.WRITABLE_PATHS:
            tmpfs[path] = f"size={self.DEFAULT_TMPFS_SIZE},noexec"

        logger.debug(f"Filesystem policy: read_only=True, tmpfs={list(tmpfs.keys())}")

        return {
            "read_only": True,
            "tmpfs": tmpfs,
        }

    def get_volume_mounts(self, script_path: str) -> list[dict]:
        """Compute volume mounts to inject the test script into the container.

        Args:
            script_path: Absolute path to the test script on the host
        Returns:
            List of Docker volume mount dicts
        """
        return [
            {
                "host_path": script_path,
                "container_path": "/workspace/test_script.py",
                "mode": "ro",
            }
        ]
