"""Network policy — restricts container network access to declared connections only.

By default containers run with network_mode=none (fully isolated).
When a tool needs database access, this module computes the minimal
network configuration that allows only the declared connection endpoints.
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)


class NetworkPolicy:
    """Determines Docker network settings for sandbox containers."""

    def __init__(self, default_mode: str = "none") -> None:
        self._default_mode = default_mode

    def compute_network_config(self, connection_config: dict) -> dict:
        """Compute Docker network configuration for a tool execution.

        Generically detects whether the connection needs network access by
        scanning for host/port fields OR URL-like values (base_url, endpoint, etc.).
        Works for databases (host+port), HTTP APIs (base_url), and any other
        network service without hardcoding technology-specific logic.

        Args:
            connection_config: Connection parameters (host, port, base_url, etc.)
        Returns:
            Dict with Docker network settings:
              - network_mode: "none" | "bridge" | "host"
              - allowed_hosts: list of host:port strings the container may reach
        """
        if not connection_config:
            logger.debug("No connection config -- network disabled")
            return {
                "network_mode": self._default_mode,
                "allowed_hosts": [],
            }

        targets = self._extract_all_network_targets(connection_config)

        if not targets:
            # No network target found -- filesystem-only tool
            logger.debug("No network target in connection config -- network disabled")
            return {
                "network_mode": self._default_mode,
                "allowed_hosts": [],
            }

        # If ANY service is on localhost, the container needs host networking
        localhost_aliases = ("localhost", "127.0.0.1", "0.0.0.0", "host.docker.internal")
        network_mode = "bridge"
        for host, port in targets:
            if host in localhost_aliases:
                network_mode = "host"
                break

        allowed_hosts = []
        for host, port in targets:
            entry = f"{host}:{port}" if port else host
            if entry not in allowed_hosts:
                allowed_hosts.append(entry)

        logger.info(
            f"Network policy: mode={network_mode}, allowed={allowed_hosts}"
        )

        return {
            "network_mode": network_mode,
            "allowed_hosts": allowed_hosts,
        }

    @staticmethod
    def _extract_all_network_targets(config: dict) -> list[tuple[str, str]]:
        """Extract ALL host:port pairs from any connection config shape.

        Supports:
          - Direct host+port fields (databases, Redis, etc.)
          - URL fields: base_url, url, endpoint, api_url, etc.
          - Comma-separated server lists: bootstrap_servers, nodes, seeds, etc.
          - Any string value that looks like a URL with a host

        Returns:
            List of (host, port) tuples.
        """
        from urllib.parse import urlparse

        targets = []
        seen = set()

        def _add(host: str, port: str) -> None:
            key = (host, port)
            if key not in seen and host:
                seen.add(key)
                targets.append(key)

        # 1. Direct host field
        host = config.get("host", "")
        port = str(config.get("port", ""))
        if host:
            _add(host, port)

        # 2. Comma-separated server lists (kafka bootstrap_servers, etc.)
        server_keys = ("bootstrap_servers", "servers", "nodes", "seeds", "brokers", "hosts")
        for key in server_keys:
            val = config.get(key, "")
            if val:
                for server in str(val).split(","):
                    server = server.strip()
                    if ":" in server:
                        h, p = server.rsplit(":", 1)
                        _add(h, p)
                    elif server:
                        _add(server, "")

        # 3. URL-like fields
        url_keys = ("base_url", "url", "endpoint", "api_url", "server_url", "uri")
        for key in url_keys:
            url_val = config.get(key, "")
            if url_val:
                parsed = urlparse(url_val)
                if parsed.hostname:
                    p = str(parsed.port) if parsed.port else ""
                    _add(parsed.hostname, p)

        # 4. Last resort: scan ALL string values for URLs
        for key, value in config.items():
            if isinstance(value, str) and value.startswith(("http://", "https://")):
                parsed = urlparse(value)
                if parsed.hostname:
                    p = str(parsed.port) if parsed.port else ""
                    _add(parsed.hostname, p)

        return targets

    def validate_connection_allowed(
        self, host: str, port: int, allowed_hosts: list[str]
    ) -> bool:
        """Check whether a connection target is in the allowed list.

        Args:
            host: Target hostname or IP
            port: Target port number
            allowed_hosts: List of "host:port" strings
        Returns:
            True if the connection is allowed
        """
        target = f"{host}:{port}"
        return target in allowed_hosts or not allowed_hosts
