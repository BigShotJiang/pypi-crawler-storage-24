"""
Gateway: single entry point for all MCP tools.

Routes requests to the correct technology file or bootstrap tools.
Supports two tool sources:
  1. Bootstrap tools (_bootstrap.py) — generic tools for any technology
  2. Technology-specific tools ({tech}.py) — agent-built specialized tools
"""

import importlib.util
import json
import logging
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

TECHNOLOGIES_DIR = Path(__file__).parent / "technologies"
REGISTRY_PATH = Path(__file__).parent / "registry.json"
BOOTSTRAP_MODULE_PATH = TECHNOLOGIES_DIR / "_bootstrap.py"

# Bootstrap tool names — always available, don't need registry lookup
BOOTSTRAP_TOOLS = {"run_query", "call_api", "read_files"}


def _load_module(name: str, path: Path):
    """Load a Python module from file path.

    Args:
        name: Module name for sys.modules
        path: Path to the .py file
    Returns:
        The loaded module
    """
    if not path.exists():
        raise FileNotFoundError(f"Module file not found: {path}")

    module_name = f"mcp_tools.technologies.{name}"
    if module_name in sys.modules:
        return sys.modules[module_name]

    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _load_technology_module(technology: str):
    """Load a technology module from technologies/ directory."""
    return _load_module(technology, TECHNOLOGIES_DIR / f"{technology}.py")


def _load_bootstrap_module():
    """Load the bootstrap tools module."""
    return _load_module("_bootstrap", BOOTSTRAP_MODULE_PATH)


def get_tool(tool_name: str) -> dict | None:
    """Look up a tool by name — checks bootstrap first, then registry.

    Args:
        tool_name: The tool to look up
    Returns:
        Tool metadata dict with 'function' key, or None if not found
    """
    # Check bootstrap tools first
    if tool_name in BOOTSTRAP_TOOLS:
        try:
            module = _load_bootstrap_module()
            return module.TOOLS.get(tool_name)
        except Exception as e:
            logger.error(f"Failed to load bootstrap tool '{tool_name}': {e}")
            return None

    # Check registry for technology-specific tools
    try:
        registry = json.loads(REGISTRY_PATH.read_text())
    except (json.JSONDecodeError, FileNotFoundError) as e:
        logger.warning(f"Failed to read registry.json: {e}")
        return None
    for tool in registry.get("tools", []):
        if tool["name"] == tool_name:
            tech = tool["technology"]
            try:
                module = _load_technology_module(tech)
                return module.TOOLS.get(tool_name)
            except Exception as e:
                logger.error(f"Failed to load technology module '{tech}': {e}")
                return None
    return None


def execute_tool(tool_name: str, **kwargs) -> dict:
    """Find and execute a tool by name.

    Args:
        tool_name: The tool to execute
        **kwargs: Arguments to pass to the tool function
    Returns:
        Tool execution result
    Raises:
        ValueError: If tool is not found
    """
    tool = get_tool(tool_name)
    if not tool:
        return {"error": f"Tool '{tool_name}' not found in registry or bootstrap"}
    return tool["function"](**kwargs)


def list_all_tools() -> list[dict]:
    """List all registered tools (bootstrap + technology-specific).

    Returns:
        List of tool metadata dicts
    """
    tools = []

    # Bootstrap tools
    for name in sorted(BOOTSTRAP_TOOLS):
        try:
            module = _load_bootstrap_module()
            meta = module.TOOLS.get(name, {})
            tools.append({
                "name": name,
                "technology": "_bootstrap",
                "description": meta.get("description", ""),
                "read_only": meta.get("read_only", True),
                "is_bootstrap": True,
            })
        except Exception:
            pass

    # Technology-specific tools from registry
    try:
        registry = json.loads(REGISTRY_PATH.read_text())
    except (json.JSONDecodeError, FileNotFoundError) as e:
        logger.warning(f"Failed to read registry.json: {e}")
        return tools
    for tool in registry.get("tools", []):
        tool["is_bootstrap"] = False
        tools.append(tool)

    return tools


def list_technologies() -> list[str]:
    """List all available technology files.

    Returns:
        List of technology names (file stems)
    """
    return [
        f.stem
        for f in TECHNOLOGIES_DIR.glob("*.py")
        if f.stem not in ("_template", "_bootstrap", "__init__")
    ]
