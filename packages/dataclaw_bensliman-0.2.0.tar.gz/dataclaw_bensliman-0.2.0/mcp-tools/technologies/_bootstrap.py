"""Bootstrap tools — 3 smart, generic tools that work with ANY technology.

These are the agent's hands. Instead of dozens of static tools per technology,
the agent uses these 3 to interact with any system:

  run_query   — execute SQL against any database (postgres, mysql, sqlite, etc.)
  call_api    — make HTTP requests to any REST/GraphQL API
  read_files  — read files from any local/mounted filesystem

Each tool auto-detects auth, pagination, and connection details from the
connection_config. The agent decides WHAT to ask; these tools handle HOW.
"""

import json
import logging
import os
import re
import sys
from pathlib import Path
from typing import Any

# Add project root to path for utils imports
_PROJECT_ROOT = Path(__file__).parent.parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from utils.constants import get as _get_config

# Read at call time for dynamic config
def _MAX_FILES_LIST(): return _get_config("max_files_list")
def _MAX_FILE_SIZE_BYTES(): return _get_config("max_file_size_bytes")
def _DEFAULT_QUERY_LIMIT(): return _get_config("default_query_limit")

logger = logging.getLogger(__name__)

# ── Dangerous SQL patterns (blocked in read-only mode) ──
# DML keywords: blocked on read-only, allowed on write
_READ_BLOCKED_SQL = re.compile(
    r"\b(DROP|DELETE|TRUNCATE|ALTER|CREATE|INSERT|UPDATE|GRANT|REVOKE|"
    r"EXEC|EXECUTE|COPY|CALL|MERGE|LOCK|COMMENT|SECURITY)\b",
    re.IGNORECASE,
)
# DDL/admin keywords: blocked even on write (need admin access_level)
_WRITE_BLOCKED_SQL = re.compile(
    r"\b(DROP|TRUNCATE|ALTER|CREATE|GRANT|REVOKE|"
    r"EXEC|EXECUTE|LOCK|COMMENT|SECURITY)\b",
    re.IGNORECASE,
)
# Block stacked queries (multiple statements separated by semicolons)
_STACKED_QUERY = re.compile(r";\s*\S")


# -- Tool: run_query -------------------------
def run_query(connection_config: dict, **kwargs) -> dict:
    """Execute a SQL query against any database.

    Smart: auto-detects the driver from connection_config and connects
    accordingly. Supports postgres (psycopg2), mysql, sqlite, and any
    DB-API 2.0 compatible driver.

    Args:
        connection_config: Connection parameters. Required keys depend on driver:
            - host, port, database, user, password (for network databases)
            - path or database (for sqlite)
            - driver_hint (optional): force a specific driver
        kwargs:
            - query (required): SQL SELECT statement to execute
            - limit (optional): max rows to return (default 100)

    Returns:
        Dict with columns, rows, row_count. On error: {"error": "message"}.
    """
    query = kwargs.get("query")
    if not query:
        return {"error": "Missing required parameter: query"}

    # Sanitize: LLMs sometimes emit literal \n instead of real newlines
    query = query.replace("\\n", " ").strip()

    limit = kwargs.get("limit", _DEFAULT_QUERY_LIMIT())

    # Security: block dangerous SQL based on access level
    access_level = connection_config.get("_access_level", "read")
    dry_run = kwargs.get("dry_run", False)
    if access_level == "read" and _READ_BLOCKED_SQL.search(query):
        return {"error": f"Blocked: query contains dangerous keywords. Access level is '{access_level}'."}
    if access_level == "write" and _WRITE_BLOCKED_SQL.search(query):
        return {"error": f"Blocked: query contains admin-level keywords. Access level is '{access_level}'. Need 'admin' access."}
    if access_level != "admin" and _STACKED_QUERY.search(query):
        return {"error": "Blocked: stacked queries (semicolons) not allowed."}

    # Dry-run: show what would be executed on write-enabled connections
    if dry_run and access_level in ("write", "admin"):
        is_dml = bool(re.search(r"\b(INSERT|UPDATE|DELETE|MERGE)\b", query, re.IGNORECASE))
        return {
            "dry_run": True,
            "query": query,
            "access_level": access_level,
            "is_dml": is_dml,
            "message": f"DRY RUN — this query would be executed against the database but was NOT sent.",
        }

    # Auto-detect driver
    driver = connection_config.get("driver_hint", "").lower()
    host = connection_config.get("host", "")
    port = connection_config.get("port", "")
    db_path = connection_config.get("path", "")

    if not driver:
        if db_path and (db_path.endswith(".db") or db_path.endswith(".sqlite")):
            driver = "sqlite"
        elif port == 5432 or "postgres" in str(host).lower():
            driver = "psycopg2"
        elif port == 3306 or "mysql" in str(host).lower():
            driver = "mysql"
        else:
            driver = "psycopg2"  # default

    conn = None
    cursor = None
    try:
        if driver == "sqlite":
            import sqlite3
            conn = sqlite3.connect(db_path or connection_config.get("database", ":memory:"))
            cursor = conn.cursor()
            cursor.execute(query)
            if cursor.description:
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchmany(limit)
                row_count = len(rows)
            else:
                columns = []
                rows = []
                row_count = cursor.rowcount if cursor.rowcount >= 0 else 0
                conn.commit()
        elif driver in ("psycopg2", "postgres", "postgresql"):
            import psycopg2
            conn_params = {
                "host": connection_config.get("host", "localhost"),
                "port": int(connection_config.get("port", 5432)),
                "dbname": connection_config.get("database", "postgres"),
                "user": connection_config.get("user", "postgres"),
                "password": connection_config.get("password", ""),
            }
            conn = psycopg2.connect(**conn_params)
            conn.autocommit = True
            cursor = conn.cursor()
            cursor.execute(query)
            if cursor.description:
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchmany(limit)
                row_count = len(rows)
            else:
                # DML statement (INSERT/UPDATE/DELETE) — no result set
                columns = []
                rows = []
                row_count = cursor.rowcount if cursor.rowcount >= 0 else 0
        elif driver in ("mysql", "pymysql"):
            import pymysql
            conn = pymysql.connect(
                host=connection_config.get("host", "localhost"),
                port=int(connection_config.get("port", 3306)),
                database=connection_config.get("database", ""),
                user=connection_config.get("user", "root"),
                password=connection_config.get("password", ""),
            )
            cursor = conn.cursor()
            cursor.execute(query)
            if cursor.description:
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchmany(limit)
                row_count = len(rows)
            else:
                columns = []
                rows = []
                row_count = cursor.rowcount if cursor.rowcount >= 0 else 0
                conn.commit()
        else:
            return {"error": f"Unsupported database driver: {driver}"}

        # Convert rows to list of dicts for consistent output
        if columns:
            row_dicts = [dict(zip(columns, row)) for row in rows]
            return {
                "columns": columns,
                "rows": row_dicts,
                "row_count": row_count,
                "query": query,
            }
        else:
            # DML statement — return affected row count
            return {
                "affected_rows": row_count,
                "query": query,
            }

    except Exception as e:
        return {"error": f"{type(e).__name__}: {e}"}
    finally:
        if cursor is not None:
            try:
                cursor.close()
            except Exception:
                pass
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


# -- Tool: call_api -------------------------
def call_api(connection_config: dict, **kwargs) -> dict:
    """Make an HTTP request to any REST API.

    Smart: auto-detects authentication (basic auth, bearer token, API key)
    from connection_config. Handles pagination hints.

    Args:
        connection_config: Connection parameters. Expected keys:
            - base_url: Base URL of the API
            - user + password (optional): for basic auth
            - api_key (optional): for bearer token auth
            - headers (optional): extra headers dict
        kwargs:
            - endpoint (required): API path relative to base_url (e.g., "/api/v1/dags")
            - method (optional): HTTP method, default "GET"
            - params (optional): query parameters dict
            - body (optional): request body dict (for POST/PUT)
            - extract_key (optional): key to extract from response JSON (e.g., "dags")

    Returns:
        Dict with response data. On error: {"error": "message"}.
    """
    import requests

    endpoint = kwargs.get("endpoint")
    if not endpoint:
        return {"error": "Missing required parameter: endpoint"}

    base_url = connection_config.get("base_url", "")
    if not base_url:
        return {"error": "Missing base_url in connection_config"}

    method = kwargs.get("method", "GET").upper()
    params = kwargs.get("params", {})
    body = kwargs.get("body")
    extract_key = kwargs.get("extract_key")

    # Security: block write methods in read-only mode
    access_level = connection_config.get("_access_level", "read")
    dry_run = kwargs.get("dry_run", False)
    if access_level == "read" and method in ("POST", "PUT", "DELETE", "PATCH"):
        # Allow POST for GraphQL queries and read-only APIs
        if method == "POST" and body and isinstance(body, dict) and "query" in body:
            pass  # GraphQL query — read-only intent
        elif method != "POST":
            return {"error": f"Blocked: {method} requests not allowed. Access level is '{access_level}'."}

    # Dry-run: show what would be sent on write-enabled connections
    if dry_run and access_level in ("write", "admin") and method in ("POST", "PUT", "DELETE", "PATCH"):
        return {
            "dry_run": True,
            "method": method,
            "url": base_url.rstrip("/") + "/" + endpoint.lstrip("/"),
            "body": body,
            "params": params,
            "access_level": access_level,
            "message": f"DRY RUN — this {method} request would be sent but was NOT executed.",
        }

    # Build URL
    url = base_url.rstrip("/") + "/" + endpoint.lstrip("/")

    # Auto-detect auth
    auth = None
    headers = dict(connection_config.get("headers", {}))
    headers["Accept"] = "application/json"

    user = connection_config.get("user", "")
    password = connection_config.get("password", "")
    api_key = connection_config.get("api_key", "")

    if user and password:
        auth = (user, password)
    elif api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    try:
        response = requests.request(
            method=method,
            url=url,
            auth=auth,
            headers=headers,
            params=params if params else None,
            json=body if body else None,
            timeout=30,
        )

        status_code = response.status_code
        if status_code >= 400:
            detail = ""
            try:
                err_json = response.json()
                detail = err_json.get("detail") or err_json.get("message") or err_json.get("error") or str(err_json)
            except Exception:
                detail = response.text[:500]
            return {
                "error": f"API returned {status_code}",
                "status_code": status_code,
                "detail": detail,
            }

        # Parse response
        try:
            data = response.json()
        except Exception:
            return {"data": response.text[:2000], "status_code": status_code}

        # Extract specific key if requested
        if extract_key and isinstance(data, dict) and extract_key in data:
            extracted = data[extract_key]
            result = {extract_key: extracted}
            # Include count if available
            if "total_entries" in data:
                result["total_entries"] = data["total_entries"]
            elif isinstance(extracted, list):
                result["count"] = len(extracted)
            return result

        # Auto-detect: if response is a dict with one main list key, add count
        if isinstance(data, dict):
            for k, v in data.items():
                if isinstance(v, list) and len(v) > 0:
                    data["count"] = data.get("total_entries", len(v))
                    break
            return data

        if isinstance(data, list):
            return {"items": data, "count": len(data)}

        return {"data": data, "status_code": status_code}

    except requests.ConnectionError as e:
        return {"error": f"Connection failed: {e}"}
    except requests.Timeout:
        return {"error": f"Request timed out (30s) to {url}"}
    except Exception as e:
        return {"error": f"{type(e).__name__}: {e}"}


# -- Tool: read_files -------------------------
def read_files(connection_config: dict, **kwargs) -> dict:
    """Read files from a local or mounted filesystem.

    Smart: auto-detects the base directory from connection_config keys
    (project_dir, path, data_dir, models_dir, etc.).

    Args:
        connection_config: Connection parameters. Expected keys (any of):
            - project_dir, path, data_dir, models_dir, config_dir
        kwargs:
            - action (optional): "list" (default), "read", "search", "tree"
            - path (optional): relative path within the base directory
            - pattern (optional): glob pattern for listing (default "**/*")
            - query (optional): text to search for in files
            - max_files (optional): max files to return in listing (default 50)

    Returns:
        Dict with files/content. On error: {"error": "message"}.
    """
    # Find the base directory from config
    base_dir = None
    for key in ("project_dir", "path", "data_dir", "models_dir", "config_dir"):
        candidate = connection_config.get(key, "")
        if candidate and os.path.isdir(candidate):
            base_dir = Path(candidate)
            break

    if base_dir is None:
        return {"error": "No valid directory found in connection_config. Expected one of: project_dir, path, data_dir, models_dir"}

    action = kwargs.get("action", "list")
    rel_path = kwargs.get("path", "")
    pattern = kwargs.get("pattern", "**/*")
    search_query = kwargs.get("query", "")
    max_files = kwargs.get("max_files", _MAX_FILES_LIST())

    # Security: prevent path traversal
    if rel_path:
        target = (base_dir / rel_path).resolve()
        if not str(target).startswith(str(base_dir.resolve())):
            return {"error": "Path traversal blocked: target is outside base directory"}
    else:
        target = base_dir

    try:
        if action == "list":
            # List files matching pattern
            files = []
            for f in sorted(base_dir.glob(pattern)):
                if f.is_file():
                    rel = f.relative_to(base_dir)
                    size = f.stat().st_size
                    files.append({
                        "path": str(rel).replace("\\", "/"),
                        "size": size,
                        "extension": f.suffix,
                    })
                    if len(files) >= max_files:
                        break
            return {
                "base_dir": str(base_dir),
                "files": files,
                "count": len(files),
                "pattern": pattern,
            }

        elif action == "read":
            # Read a specific file
            if not rel_path:
                return {"error": "Missing 'path' parameter for read action"}
            file_path = (base_dir / rel_path).resolve()
            if not file_path.is_file():
                return {"error": f"File not found: {rel_path}"}
            # Size guard
            if file_path.stat().st_size > _MAX_FILE_SIZE_BYTES():
                return {"error": f"File too large ({file_path.stat().st_size} bytes). Max 1MB."}
            content = file_path.read_text(encoding="utf-8", errors="replace")
            return {
                "path": str(rel_path),
                "content": content,
                "size": len(content),
                "extension": file_path.suffix,
            }

        elif action == "search":
            # Search for text in files
            if not search_query:
                return {"error": "Missing 'query' parameter for search action"}
            matches = []
            for f in base_dir.glob(pattern):
                if not f.is_file() or f.stat().st_size > 500_000:
                    continue
                try:
                    text = f.read_text(encoding="utf-8", errors="replace")
                    if search_query.lower() in text.lower():
                        # Find the matching lines
                        lines = []
                        for i, line in enumerate(text.splitlines(), 1):
                            if search_query.lower() in line.lower():
                                lines.append({"line_number": i, "text": line.strip()})
                        matches.append({
                            "path": str(f.relative_to(base_dir)).replace("\\", "/"),
                            "matches": lines[:10],  # max 10 matches per file
                        })
                except Exception:
                    continue
                if len(matches) >= max_files:
                    break
            return {
                "query": search_query,
                "matches": matches,
                "files_matched": len(matches),
            }

        elif action == "tree":
            # Show directory tree structure
            tree = []
            for f in sorted(base_dir.rglob("*")):
                if f.name.startswith("."):
                    continue
                rel = f.relative_to(base_dir)
                depth = len(rel.parts) - 1
                prefix = "  " * depth
                icon = "/" if f.is_dir() else ""
                tree.append(f"{prefix}{f.name}{icon}")
                if len(tree) >= max_files * 2:
                    tree.append("... (truncated)")
                    break
            return {
                "base_dir": str(base_dir),
                "tree": "\n".join(tree),
                "entries": len(tree),
            }

        else:
            return {"error": f"Unknown action: {action}. Use 'list', 'read', 'search', or 'tree'."}

    except PermissionError:
        return {"error": f"Permission denied: {target}"}
    except Exception as e:
        return {"error": f"{type(e).__name__}: {e}"}


# -- TOOLS REGISTRY ----------------------------------------
TOOLS = {
    "run_query": {
        "function": run_query,
        "description": "Execute SQL queries against any database (postgres, mysql, sqlite). Auto-detects driver from connection config.",
        "read_only": True,
    },
    "call_api": {
        "function": call_api,
        "description": "Make HTTP requests to any REST API. Auto-detects auth (basic, bearer, API key) from connection config.",
        "read_only": True,
    },
    "read_files": {
        "function": read_files,
        "description": "Read, list, search, or browse files from any local/mounted filesystem.",
        "read_only": True,
    },
}
