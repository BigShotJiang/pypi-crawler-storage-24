"""Prompts for connector and ephemeral code generation."""


CONNECTOR_PROMPT = """\
Generate a Python CONNECTOR function for DataClaw.

## What is a Connector?
A connector is a small function that establishes a connection to a technology
and returns a RAW CLIENT object. It does NOT perform any operations — it only connects.

## Technology: {technology}

## Connection Config
```json
{connection_config}
```

Look at the config to determine:
- If it has `bootstrap_servers` → Kafka. Use `kafka-python` (KafkaAdminClient or KafkaConsumer)
- If it has `host` + `port: 22` → SSH. Use `paramiko` (SSHClient)
- If it has `host` + `port: 27017` → MongoDB. Use `pymongo` (MongoClient)
- If it has `host` + `port: 6379` → Redis. Use `redis` (Redis)
- YOU figure out the library from the config shape

## Rules
1. Function signature MUST be: `def connect(connection_config: dict) -> object:`
2. Return the RAW client — do NOT wrap it
3. Handle connection errors — return None or raise with a clear message
4. Do NOT perform any operations (no list_topics, no queries, no file reads)
5. Just connect and return the client

## Response Format
Respond with EXACTLY one Python code block:

```python
def connect(connection_config: dict):
    \"\"\"Connect to {technology} and return a raw client.\"\"\"
    # import the library
    # read config values
    # connect
    # return client
```
"""


EPHEMERAL_CODE_PROMPT = """\
Generate a Python function to execute a user request using a live client connection.

## User Request
{user_request}

## Technology: {technology}
## Client Type: {client_type}

## Available Client
You receive a `client` object of type `{client_type}`.
This is an already-connected client — do NOT create a new connection.

## Connection Config (for reference only — do NOT reconnect)
```json
{connection_config}
```

{existing_tools_section}

{skill_context}

## Rules
1. Function signature MUST be: `def execute(client, connection_config: dict, **kwargs) -> dict:`
2. Use the `client` parameter — it's already connected
3. Do NOT create new connections or import connection libraries
4. ALWAYS return a dict with descriptive keys
5. Handle errors gracefully — return {{"error": "message"}} instead of raising
6. Use .get() for dict access — NEVER use dict["key"] directly
7. If calling bootstrap tools, use: `from mcp_tools.gateway import execute_tool`
8. Extract kwargs with sensible defaults from the user request — do NOT require kwargs to be passed externally
9. If a similar skill is shown above, follow its pattern for args and structure

## Response Format
Respond with EXACTLY one Python code block:

```python
def execute(client, connection_config: dict, **kwargs) -> dict:
    \"\"\"One-line description of what this does.\"\"\"
    # your implementation
    return {{"key": "value"}}
```
"""


EPHEMERAL_BOOTSTRAP_PROMPT = """\
Generate a Python function to execute a user request by calling existing tools.

## User Request
{user_request}

## Available Bootstrap Tools
You can call these tools via the gateway:
- `run_query(connection_config, query="SQL", limit=100)` — Execute SQL
- `call_api(connection_config, endpoint="/path", method="GET")` — HTTP requests
- `read_files(connection_config, action="list|read|search|tree")` — File access

## Available Built Tools
{built_tools}

## How to Call Tools
```python
from mcp_tools.gateway import execute_tool
result = execute_tool("run_query", connection_config=config, query="SELECT 1")
```

## Connection Configs Available
{connections_summary}

## Rules
1. Function signature MUST be: `def execute(client, connection_config: dict, **kwargs) -> dict:`
   (client will be None for bootstrap-only operations)
2. Call existing tools — do NOT write raw SQL drivers or HTTP clients
3. ALWAYS return a dict with descriptive keys
4. Handle errors gracefully

## Response Format
```python
def execute(client, connection_config: dict, **kwargs) -> dict:
    \"\"\"One-line description.\"\"\"
    from mcp_tools.gateway import execute_tool
    # your implementation
    return {{"key": "value"}}
```
"""


def build_connector_prompt(technology: str, connection_config: dict) -> str:
    """Build the connector generation prompt."""
    import json
    return CONNECTOR_PROMPT.replace("{technology}", technology).replace(
        "{connection_config}", json.dumps(connection_config, indent=4, default=str)
    )


def build_ephemeral_prompt(
    user_request: str,
    technology: str,
    client_type: str,
    connection_config: dict,
    existing_tools: list[str] | None = None,
) -> str:
    """Build the ephemeral code generation prompt for non-bootstrap tech.

    Automatically injects matching skills as context so the LLM
    can reference proven patterns (args, structure, defaults).
    """
    import json

    tools_section = ""
    if existing_tools:
        tools_section = "## Existing Tools You Can Call\n"
        tools_section += "\n".join(f"- `{t}`" for t in existing_tools)

    # Inject matching skills as context
    skill_context = ""
    try:
        from skills.registry import get_registry
        registry = get_registry()
        skill_context = registry.build_skill_context(technology, user_request)
    except Exception:
        pass  # Skills are optional — don't block code generation

    return EPHEMERAL_CODE_PROMPT.replace(
        "{user_request}", user_request
    ).replace(
        "{technology}", technology
    ).replace(
        "{client_type}", client_type
    ).replace(
        "{connection_config}", json.dumps(connection_config, indent=4, default=str)
    ).replace(
        "{existing_tools_section}", tools_section
    ).replace(
        "{skill_context}", skill_context
    )


def build_ephemeral_bootstrap_prompt(
    user_request: str,
    built_tools: str,
    connections_summary: str,
) -> str:
    """Build the ephemeral code prompt for complex multi-tool operations."""
    return EPHEMERAL_BOOTSTRAP_PROMPT.replace(
        "{user_request}", user_request
    ).replace(
        "{built_tools}", built_tools or "(none yet)"
    ).replace(
        "{connections_summary}", connections_summary
    )
