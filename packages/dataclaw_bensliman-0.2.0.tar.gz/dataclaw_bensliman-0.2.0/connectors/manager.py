"""Connection manager — generates, caches, and serves live client connections.

Flow:
  1. First request for a technology → LLM generates connector code
  2. Connector is tested (can it connect?) → saved to connectors/{tech}.py
  3. Client object cached in memory for reuse
  4. On connection failure → invalidate → regenerate on next request

Bootstrap technologies (database, api, filesystem) DON'T use connectors —
they handle connections internally via run_query/call_api/read_files.
Connectors are for non-bootstrap types: messaging, server, cloud, etc.
"""

import importlib.util
import logging
import sys
import threading
import types
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

from utils.paths import get_connectors_dir

CONNECTORS_DIR = get_connectors_dir()

# Types that bootstrap tools handle — no connector needed
BOOTSTRAP_TYPES = {"database", "api", "filesystem"}


class ConnectionManager:
    """Manages live connections to non-bootstrap technologies.

    - Generates connector code via LLM on first use
    - Caches live client objects for reuse across requests
    - Invalidates and regenerates on connection failure
    - Thread-safe
    """

    def __init__(self):
        self._clients: dict[str, Any] = {}          # tech -> live client
        self._connectors: dict[str, types.ModuleType] = {}  # tech -> loaded module
        self._lock = threading.Lock()

    def has_connector(self, technology: str) -> bool:
        """Check if a connector file exists for this technology."""
        internal = {"__init__", "manager", "executor", "prompts"}
        if technology in internal:
            return False
        return (CONNECTORS_DIR / f"{technology}.py").exists()

    def get_client(self, technology: str, connection_config: dict) -> Any | None:
        """Get a live client for a technology. Returns cached client or creates new one.

        Args:
            technology: Technology name (e.g., 'kafka', 'ssh_server')
            connection_config: Connection parameters from connections.yaml
        Returns:
            Live client object, or None if no connector exists.
        """
        with self._lock:
            # Return cached client if alive
            if technology in self._clients:
                client = self._clients[technology]
                if self._is_alive(client):
                    return client
                else:
                    logger.info(f"[CONNECTOR] Cached client for '{technology}' is dead, reconnecting")
                    self._clients.pop(technology, None)

            # Load connector module
            connector = self._load_connector(technology)
            if connector is None:
                return None

            # Connect
            try:
                connect_fn = getattr(connector, "connect", None)
                if connect_fn is None:
                    logger.error(f"[CONNECTOR] {technology}.py has no connect() function")
                    return None

                client = connect_fn(connection_config)
                self._clients[technology] = client
                logger.info(f"[CONNECTOR] Connected to '{technology}' — client: {type(client).__name__}")
                return client
            except Exception as e:
                logger.error(f"[CONNECTOR] Connection failed for '{technology}': {e}")
                return None

    def invalidate(self, technology: str) -> None:
        """Invalidate a cached client (call on connection failure).

        Does NOT delete the connector file — just drops the cached client.
        Next get_client() will reconnect using the same connector.
        """
        with self._lock:
            client = self._clients.pop(technology, None)
            if client is not None:
                self._safe_close(client)
                logger.info(f"[CONNECTOR] Invalidated client for '{technology}'")

    def invalidate_connector(self, technology: str) -> None:
        """Invalidate both the cached client AND the connector module.

        Forces a full regeneration on next use.
        """
        with self._lock:
            client = self._clients.pop(technology, None)
            if client is not None:
                self._safe_close(client)
            self._connectors.pop(technology, None)
            # Delete the connector file so it gets regenerated
            connector_file = CONNECTORS_DIR / f"{technology}.py"
            if connector_file.exists():
                connector_file.unlink()
                logger.info(f"[CONNECTOR] Deleted connector file for '{technology}'")

    def save_connector(self, technology: str, code: str) -> Path:
        """Save LLM-generated connector code to a file.

        Args:
            technology: Technology name
            code: Python code with a connect(connection_config) function
        Returns:
            Path to the saved connector file
        """
        connector_file = CONNECTORS_DIR / f"{technology}.py"
        connector_file.write_text(
            f'"""Auto-generated connector for {technology}.\n\n'
            f'Generated by DataClaw LLM. Regenerated on connection failure.\n'
            f'"""\n\n{code}\n',
            encoding="utf-8",
        )
        # Clear cached module so it reloads
        self._connectors.pop(technology, None)
        logger.info(f"[CONNECTOR] Saved connector: {connector_file}")
        return connector_file

    def test_connector(self, technology: str, connection_config: dict) -> dict:
        """Test a connector by attempting to connect.

        Returns:
            {"success": True, "client_type": "..."} or {"success": False, "error": "..."}
        """
        try:
            client = self.get_client(technology, connection_config)
            if client is None:
                return {"success": False, "error": "No connector or connect() returned None"}
            return {"success": True, "client_type": type(client).__name__}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def list_connectors(self) -> list[dict]:
        """List all saved connectors (technology files only, not internal modules)."""
        # Internal modules that are NOT connectors
        internal = {"__init__", "manager", "executor", "prompts"}
        connectors = []
        for f in CONNECTORS_DIR.glob("*.py"):
            if f.stem.startswith("_") or f.stem in internal:
                continue
            connectors.append({
                "technology": f.stem,
                "file": str(f),
                "has_client": f.stem in self._clients,
            })
        return connectors

    def close_all(self) -> None:
        """Close all cached clients. Call on shutdown."""
        with self._lock:
            for tech, client in list(self._clients.items()):
                self._safe_close(client)
                logger.info(f"[CONNECTOR] Closed client for '{tech}'")
            self._clients.clear()
            self._connectors.clear()

    # ── Internal helpers ──────────────────────────────

    def _load_connector(self, technology: str) -> types.ModuleType | None:
        """Load a connector module from file."""
        if technology in self._connectors:
            return self._connectors[technology]

        connector_file = CONNECTORS_DIR / f"{technology}.py"
        if not connector_file.exists():
            return None

        try:
            module_name = f"connectors.{technology}"
            # Force reload
            if module_name in sys.modules:
                del sys.modules[module_name]

            spec = importlib.util.spec_from_file_location(module_name, connector_file)
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)

            self._connectors[technology] = module
            return module
        except Exception as e:
            logger.error(f"[CONNECTOR] Failed to load connector for '{technology}': {e}")
            return None

    def _is_alive(self, client: Any) -> bool:
        """Check if a client is still alive. Best-effort."""
        # Try common patterns
        for method in ("is_connected", "ping", "is_alive"):
            fn = getattr(client, method, None)
            if fn is not None:
                try:
                    result = fn()
                    return bool(result) if result is not None else True
                except Exception:
                    return False

        # If no health check method, assume alive
        # (will fail on actual use and trigger invalidation)
        return True

    def _safe_close(self, client: Any) -> None:
        """Safely close a client connection."""
        for method in ("close", "disconnect", "shutdown"):
            fn = getattr(client, method, None)
            if fn is not None:
                try:
                    fn()
                except Exception:
                    pass
                return


# ── Singleton instance ────────────────────────────────
_manager: ConnectionManager | None = None


def get_manager() -> ConnectionManager:
    """Get the global ConnectionManager singleton."""
    global _manager
    if _manager is None:
        _manager = ConnectionManager()
    return _manager
