"""Connector layer — LLM-generated connection code, cached and reused.

Each technology gets a connector generated once by the LLM.
The connector returns a raw client object (KafkaAdminClient, SSHClient, etc.).
Connectors are saved as flat files and reused across requests.
Only regenerated on connection failure.
"""
