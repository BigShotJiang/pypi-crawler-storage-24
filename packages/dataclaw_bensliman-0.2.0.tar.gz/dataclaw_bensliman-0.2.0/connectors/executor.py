"""Ephemeral code executor — validates and runs LLM-generated code once.

Code is executed in-process, receives a live client from the connector,
and the code is discarded after execution. Nothing is saved permanently.

Security: same static validation as the builder (AST, imports, dangerous calls).
"""

import json
import logging
import re
import threading
import traceback
import types
from typing import Any

logger = logging.getLogger(__name__)


# ── Static validation (reuse builder's validator) ─────

def _validate_ephemeral(code: str) -> dict | None:
    """Validate ephemeral code. Returns error dict or None if OK."""
    from agents.builder.validator import BLOCKED_IMPORTS, DANGEROUS_CALLS
    import ast

    # Check syntax
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return {"error": f"Syntax error: {e}"}

    # Check imports
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in (node.names if isinstance(node, ast.Import) else node.names):
                module_name = node.module if isinstance(node, ast.ImportFrom) else alias.name
                if module_name and module_name.split(".")[0] in BLOCKED_IMPORTS:
                    return {"error": f"Blocked import: {module_name}"}

        # Check dangerous calls
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in DANGEROUS_CALLS:
                return {"error": f"Dangerous call: {node.func.id}"}
            if isinstance(node.func, ast.Attribute) and node.func.attr in DANGEROUS_CALLS:
                return {"error": f"Dangerous call: {node.func.attr}"}

    # Check that execute() function exists
    func_names = [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
    if "execute" not in func_names:
        return {"error": "Code must contain a function named 'execute'"}

    return None


def _extract_code_block(raw: str) -> str:
    """Extract Python code block from LLM response."""
    # Strip thinking blocks
    text = re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL).strip()

    # Extract from code fences
    pattern = r"```python\s*\n(.*?)```"
    matches = re.findall(pattern, text, re.DOTALL)
    if matches:
        return matches[0].strip()

    # Fallback: treat as raw code
    lines = text.strip().split("\n")
    code_lines = [l for l in lines if not l.strip().startswith("```")]
    return "\n".join(code_lines).strip()


def _detect_missing_imports(code: str) -> list[str]:
    """Detect missing third-party imports. Returns list of pip package names."""
    import importlib.util

    try:
        from sandbox.executor.container_manager import PIP_NAME_MAP, STDLIB_MODULES
    except ImportError:
        PIP_NAME_MAP = {"kafka": "kafka-python", "paramiko": "paramiko",
                        "confluent_kafka": "confluent-kafka", "psycopg2": "psycopg2-binary"}
        STDLIB_MODULES = {"os", "sys", "re", "json", "pathlib", "logging", "typing",
                          "time", "datetime", "collections", "functools", "itertools",
                          "math", "random", "io", "csv", "tempfile", "threading",
                          "asyncio", "socket", "http", "urllib", "uuid", "ssl",
                          "importlib", "traceback", "hashlib", "base64", "struct",
                          "sqlite3", "configparser", "argparse", "copy", "glob",
                          "contextlib", "warnings", "platform", "signal", "secrets",
                          "subprocess", "multiprocessing", "concurrent", "ctypes",
                          "grp", "pwd", "fcntl", "termios", "resource", "posix", "pty", "tty"}

    import_pattern = re.compile(r"^\s*(?:import|from)\s+(\w+)", re.MULTILINE)
    imports = set(import_pattern.findall(code))
    third_party = imports - STDLIB_MODULES

    missing = []
    for mod in sorted(third_party):
        spec = importlib.util.find_spec(mod)
        if spec is None:
            pip_name = PIP_NAME_MAP.get(mod, mod)
            missing.append(pip_name)
    return missing


def execute_ephemeral(
    code: str,
    client: Any | None,
    connection_config: dict,
    timeout_s: int = 30,
    **kwargs,
) -> dict:
    """Execute ephemeral code with a live client.

    Args:
        code: Python code containing an execute(client, connection_config, **kwargs) function
        client: Live client object from connector (or None for bootstrap-only ops)
        connection_config: Connection config dict
        timeout_s: Execution timeout in seconds
        **kwargs: Additional arguments to pass to execute()
    Returns:
        Result dict from the execute() function, or {"error": "..."} on failure
    """
    # Validate
    validation_error = _validate_ephemeral(code)
    if validation_error:
        return validation_error

    # Check missing imports
    missing = _detect_missing_imports(code)
    if missing:
        return {
            "error": f"Missing libraries: {', '.join(missing)}",
            "missing_libraries": missing,
        }

    # Load code into temp module
    try:
        module = types.ModuleType("_dataclaw_ephemeral")
        module.__dict__["__builtins__"] = __builtins__
        exec(compile(code, "<ephemeral>", "exec"), module.__dict__)
    except Exception as e:
        return {"error": f"Code compilation failed: {e}"}

    # Get execute function
    execute_fn = getattr(module, "execute", None)
    if execute_fn is None:
        return {"error": "No execute() function found in generated code"}

    # Execute with timeout
    result_holder = [None]
    error_holder = [None]

    def _run():
        try:
            result_holder[0] = execute_fn(client, connection_config, **kwargs)
        except Exception as e:
            error_holder[0] = e

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()
    thread.join(timeout=timeout_s)

    if thread.is_alive():
        return {"error": f"Execution timed out after {timeout_s}s"}

    if error_holder[0]:
        e = error_holder[0]
        tb = "".join(traceback.format_exception(type(e), e, e.__traceback__))
        logger.error(f"[EPHEMERAL] Execution error: {e}\n{tb}")
        return {"error": f"{type(e).__name__}: {e}"}

    result = result_holder[0]

    # Validate result
    if not isinstance(result, dict):
        return {"error": f"execute() returned {type(result).__name__}, expected dict", "raw_result": str(result)}

    return result
