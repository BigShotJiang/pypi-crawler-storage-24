"""LangGraph flow — wires the reasoning agent into the DataClaw pipeline.

Reasoning-based flow with connector + ephemeral execution:

  START → orchestrator
    ├─ greeting/help → direct_response → END
    ├─ action (bootstrap tool, 1 step) → execute_tool → END
    └─ action/question (plan) → plan_executor loop:
         for each step:
           ├─ bootstrap tool → execute via gateway
           ├─ MCP server tool → execute via MCP client
           ├─ has connector → generate ephemeral code → execute once → discard
           ├─ no connector → LLM generates connector → test → save → then ephemeral
           ├─ built tool exists → execute via gateway
           └─ tool missing + bootstrap type → build permanent tool (legacy)
         → synthesize (if question) → END
"""

import json
import logging
import importlib.util
import re as _re
import sys
import threading
from datetime import datetime
from pathlib import Path
from typing import Any

from agents.builder.agent import run as builder_run
from agents.orchestrator.agent import run as orchestrator_run
from agents.tester.agent import run as tester_run
from connectors.manager import get_manager as get_connector_manager
from connectors.executor import execute_ephemeral, _extract_code_block
from connectors.prompts import build_connector_prompt, build_ephemeral_prompt
from mcp_client.client import get_mcp_manager
from skills.registry import get_registry as get_skill_registry
from utils.connections import get_connection, get_technology_type
from utils.error_diagnoser import diagnose

logger = logging.getLogger(__name__)

from utils.paths import get_mcp_tools_dir, get_registry_path, get_technologies_dir

# Paths for tool commit operations
MCP_TOOLS_DIR = get_mcp_tools_dir()
REGISTRY_PATH = get_registry_path()
TECHNOLOGIES_DIR = get_technologies_dir()
ARCHIVE_DIR = MCP_TOOLS_DIR / "archive"

# Lock for file operations in commit_tool (prevents concurrent corruption)
_commit_lock = threading.Lock()

# Gateway module cache (avoids reloading from disk on every execution)
_gateway_module = None
_gateway_dirty = True  # Start dirty to force first load


# ── Tool execution helpers ──────────────────────────


def _load_gateway():
    """Load the gateway module, using cache unless a new tool was committed."""
    global _gateway_module, _gateway_dirty

    if _gateway_module is not None and not _gateway_dirty:
        return _gateway_module

    gateway_path = MCP_TOOLS_DIR / "gateway.py"
    module_name = "mcp_tools.gateway"

    stale = [k for k in sys.modules if k.startswith("mcp_tools")]
    for k in stale:
        del sys.modules[k]

    spec = importlib.util.spec_from_file_location(module_name, gateway_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    _gateway_module = module
    _gateway_dirty = False
    return module


def execute_single_tool(tool_name: str, connection_config: dict, params: dict | None = None) -> str:
    """Execute one tool via the gateway and return the result as a string.

    Args:
        tool_name: Name of the tool to execute.
        connection_config: Resolved connection config.
        params: Optional params to pass to the tool.
    Returns:
        JSON string of the result.
    """
    gateway = _load_gateway()
    logger.info(f"[EXECUTE] Tool: {tool_name} | Params: {json.dumps(params or {}, default=str)[:200]}")
    result = gateway.execute_tool(tool_name, connection_config=connection_config, **(params or {}))
    if isinstance(result, dict) and "error" in result:
        logger.warning(f"[EXECUTE] Tool returned error: {result['error']}")
    else:
        logger.info(f"[EXECUTE] Result keys: {list(result.keys()) if isinstance(result, dict) else type(result)}")
    return json.dumps(result, indent=2, default=str)


# ── Commit tool to library ──────────────────────────


async def commit_tool(state: dict[str, Any]) -> dict[str, Any]:
    """Commit a validated tool to the technology file and registry.

    Args:
        state: DataClawState with generated_code, tool_name, technology, manifest
    Returns:
        State updates.
    """
    global _gateway_dirty

    tool_name = state["tool_name"]
    technology = state["technology"]
    generated_code = state.get("generated_code", "")
    manifest = state.get("manifest", {})

    logger.info(f"[COMMIT] Tool '{tool_name}' → {technology}.py")

    with _commit_lock:
        tech_file = TECHNOLOGIES_DIR / f"{technology}.py"

        # ── Archive old tool code if it already exists ──
        if tech_file.exists():
            existing_code = tech_file.read_text(encoding="utf-8")
            # Check if this tool name already has a function in the file
            old_func_pattern = _re.compile(
                rf"(# -- Tool: {_re.escape(tool_name)} .*?\n)"
                rf"(.*?)(?=\n# -- Tool: |\n# -- TOOLS REGISTRY|\n# ── TOOLS REGISTRY|\Z)",
                _re.DOTALL,
            )
            old_match = old_func_pattern.search(existing_code)
            if old_match:
                ARCHIVE_DIR.mkdir(exist_ok=True)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                archive_file = ARCHIVE_DIR / f"{tool_name}_v{timestamp}.py"
                archive_file.write_text(
                    f"# Archived: {tool_name} from {technology}.py\n"
                    f"# Archived at: {timestamp}\n\n"
                    f"{old_match.group(0).strip()}\n",
                    encoding="utf-8",
                )
                logger.info(f"[COMMIT] Archived old '{tool_name}' → {archive_file.name}")

        # Create technology file from template if it doesn't exist
        if not tech_file.exists():
            template_file = TECHNOLOGIES_DIR / "_template.py"
            if template_file.exists():
                template = template_file.read_text(encoding="utf-8")
                content = template.replace("__TECHNOLOGY__", technology)
                tech_file.write_text(content, encoding="utf-8")
                logger.info(f"[COMMIT] Created new technology file: {tech_file}")
            else:
                tech_file.write_text(
                    f'"""{technology} tools — auto-generated by DataClaw."""\n\n'
                    f"# -- TOOLS REGISTRY ----------------------------------------\n"
                    f"TOOLS = {{\n}}\n",
                    encoding="utf-8",
                )

        if tech_file.exists():
            existing = tech_file.read_text(encoding="utf-8")

            # Insert the new function before the TOOLS dict marker
            tools_marker = "# -- TOOLS REGISTRY"
            if tools_marker not in existing:
                tools_marker = "# ── TOOLS REGISTRY"
            if tools_marker in existing:
                new_function = f"\n\n# -- Tool: {tool_name} -------------------------\n{generated_code}\n\n"
                existing = existing.replace(tools_marker, new_function + tools_marker)
            else:
                existing += f"\n\n# -- Tool: {tool_name} -------------------------\n{generated_code}\n"

            # Add to TOOLS dict
            description = manifest.get("description", f"Auto-generated: {tool_name}")
            safe_desc = description.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
            from utils.constants import get as get_config
            max_desc = get_config("max_description_length")
            if len(safe_desc) > max_desc:
                safe_desc = safe_desc[:max_desc] + "..."
            tools_entry = (
                f'    "{tool_name}": {{\n'
                f'        "function": {tool_name},\n'
                f'        "description": "{safe_desc}",\n'
                f'        "read_only": True,\n'
                f'    }},\n'
            )
            if "TOOLS = {" in existing:
                tools_start = existing.index("TOOLS = {")
                last_brace = existing.rindex("}", tools_start)
                existing = existing[:last_brace] + tools_entry + existing[last_brace:]

            tech_file.write_text(existing, encoding="utf-8")
            logger.info(f"[COMMIT] Appended tool code to {tech_file}")

        # Add to registry.json
        registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
        existing_names = {t["name"] for t in registry.get("tools", [])}
        if tool_name not in existing_names:
            registry["tools"].append({
                "name": tool_name,
                "technology": technology,
                "description": manifest.get("description", ""),
                "read_only": True,
            })
            REGISTRY_PATH.write_text(json.dumps(registry, indent=2), encoding="utf-8")
            logger.info(f"[COMMIT] Added '{tool_name}' to registry.json")

        # Mark gateway as dirty so it reloads with the new tool
        _gateway_dirty = True

    return {"result": f"Tool '{tool_name}' committed to {technology}.py and registry"}


# ── Connector + Ephemeral execution ─────────────────


async def generate_connector(technology: str, connection_config: dict) -> dict:
    """Generate a connector for a non-bootstrap technology via LLM.

    Returns:
        {"success": True, "connector_file": "..."} or {"success": False, "error": "..."}
    """
    from utils.llm_client import call_llm, LLMError

    prompt = build_connector_prompt(technology, connection_config)
    system = "You are a code generator. Generate ONLY the requested Python code. No explanations."

    try:
        raw = await call_llm(system, prompt, agent="builder")
    except LLMError as e:
        return {"success": False, "error": f"LLM failed: {e.reason}"}

    code = _extract_code_block(raw)
    if not code or "def connect" not in code:
        return {"success": False, "error": "LLM did not generate a valid connect() function"}

    # Save the connector
    manager = get_connector_manager()
    connector_file = manager.save_connector(technology, code)

    # Test it
    test_result = manager.test_connector(technology, connection_config)
    if test_result["success"]:
        logger.info(f"[CONNECTOR] Generated and tested connector for '{technology}': {test_result['client_type']}")
        return {"success": True, "connector_file": str(connector_file), "client_type": test_result["client_type"]}
    else:
        # Connector failed — delete it so it gets regenerated next time
        manager.invalidate_connector(technology)
        return {"success": False, "error": f"Connector test failed: {test_result['error']}"}


async def execute_ephemeral_step(
    user_request: str,
    technology: str,
    connection_config: dict,
    client=None,
) -> dict:
    """Generate and execute ephemeral code for a single operation.

    Args:
        user_request: What the user wants to do
        technology: Technology name
        connection_config: Connection config
        client: Live client from connector (or None for bootstrap ops)
    Returns:
        Result dict from the ephemeral code, or {"error": "..."}
    """
    from utils.llm_client import call_llm, LLMError

    client_type = type(client).__name__ if client else "None"
    prompt = build_ephemeral_prompt(
        user_request=user_request,
        technology=technology,
        client_type=client_type,
        connection_config=connection_config,
    )
    system = "You are a code generator. Generate ONLY the requested Python code. No explanations."

    try:
        raw = await call_llm(system, prompt, agent="builder")
    except LLMError as e:
        return {"error": f"LLM code generation failed: {e.reason}"}

    code = _extract_code_block(raw)
    if not code or "def execute" not in code:
        return {"error": "LLM did not generate a valid execute() function"}

    logger.info(f"[EPHEMERAL] Generated code for '{technology}': {len(code)} chars")

    # Execute
    result = execute_ephemeral(code, client, connection_config)

    # Track skill stats (best-effort)
    success = isinstance(result, dict) and "error" not in result
    track_skill_execution(technology, user_request, success)

    # If connection error, invalidate connector
    if isinstance(result, dict) and "error" in result:
        error_lower = str(result["error"]).lower()
        connection_errors = ("connection", "refused", "timeout", "unreachable", "not connected", "broken pipe")
        if any(ce in error_lower for ce in connection_errors):
            logger.info(f"[EPHEMERAL] Connection error detected, invalidating connector for '{technology}'")
            get_connector_manager().invalidate(technology)

    # Attach the generated code to result for potential skill promotion
    if isinstance(result, dict) and "error" not in result:
        result["_ephemeral_code"] = code

    return result


# ── Skill promotion & tracking ───────────────────────


async def promote_to_skill(
    technology: str,
    code: str,
    user_request: str,
    client_type: str = "",
) -> dict:
    """Promote ephemeral code to a reusable skill via LLM metadata extraction.

    The LLM analyzes the code and user request to generate:
    - A clean skill name
    - Description, tags, args, examples

    Returns:
        {"success": True, "key": "tech/name"} or {"success": False, "error": "..."}
    """
    from utils.llm_client import call_llm, LLMError

    prompt = (
        "Analyze this Python function and extract skill metadata.\n\n"
        f"## User Request\n{user_request}\n\n"
        f"## Technology: {technology}\n\n"
        f"## Code\n```python\n{code}\n```\n\n"
        "Return ONLY a JSON object with these fields:\n"
        '{\n'
        '  "name": "snake_case_skill_name",\n'
        '  "description": "One-line description",\n'
        '  "tags": ["tag1", "tag2"],\n'
        '  "args": [{"name": "arg_name", "type": "str", "default": "value", "description": "what it does"}],\n'
        '  "examples": [{"prompt": "natural language request", "args": {"arg_name": "value"}}]\n'
        '}\n\n'
        "Rules:\n"
        "- name should be descriptive and reusable (e.g., 'execute_command', 'list_topics')\n"
        "- Extract ALL kwargs from the code as args with their defaults\n"
        "- Generate 2-3 example prompts that would trigger this skill\n"
        "- Tags should be broad categories (e.g., 'shell', 'admin', 'monitoring')\n"
    )

    try:
        raw = await call_llm(
            "You are a code analyzer. Return ONLY valid JSON, no explanations.",
            prompt,
            agent="builder",
        )
    except LLMError as e:
        return {"success": False, "error": f"LLM failed: {e.reason}"}

    # Parse JSON from response
    try:
        # Strip markdown fences if present
        text = raw.strip()
        if text.startswith("```"):
            text = "\n".join(text.split("\n")[1:])
        if text.endswith("```"):
            text = text[: text.rfind("```")]
        meta = json.loads(text.strip())
    except (json.JSONDecodeError, ValueError) as e:
        return {"success": False, "error": f"Failed to parse LLM metadata: {e}"}

    name = meta.get("name", "").strip()
    if not name:
        return {"success": False, "error": "LLM did not generate a skill name"}

    # Register the skill
    registry = get_skill_registry()
    key = registry.register_skill(
        technology=technology,
        name=name,
        code=code,
        description=meta.get("description", ""),
        tags=meta.get("tags", []),
        args=meta.get("args", []),
        examples=meta.get("examples", []),
        client_type=client_type,
    )

    logger.info(f"[SKILLS] Promoted ephemeral code to skill: {key}")
    return {"success": True, "key": key, "name": name}


def track_skill_execution(technology: str, user_request: str, success: bool) -> None:
    """Track skill execution stats if a matching skill was used as context.

    Called after ephemeral execution to update the skill that was used as a template.
    """
    try:
        registry = get_skill_registry()
        matches = registry.search(technology=technology, intent=user_request, limit=1)
        if matches:
            key, _, score = matches[0]
            if score >= 0.3:  # Only track if it was a strong match
                registry.update_stats(key, success)
    except Exception:
        pass  # Stats are best-effort


# ── Plan execution (called from CLI) ────────────────


async def execute_plan_step(
    step: dict,
    connection_config: dict,
    technology: str,
) -> dict:
    """Execute a single plan step (existing tool or bootstrap).

    Args:
        step: Step dict with tool, params, etc.
        connection_config: Resolved connection config.
        technology: Technology name.
    Returns:
        Dict with 'result' or 'error'.
    """
    tool_name = step["tool"]
    params = step.get("params", {})

    try:
        result = execute_single_tool(tool_name, connection_config, params)
        return {"result": result}
    except Exception as e:
        friendly = diagnose(e, technology, connection_config)
        logger.error(f"[EXECUTE] Step '{tool_name}' failed: {e}")
        return {"error": friendly}


def _check_redundancy(tool_name: str, tool_description: str, technology: str) -> str | None:
    """Check if a proposed tool is redundant with bootstrap or existing tools.

    Returns a reason string if redundant, None if OK to build.
    """
    from utils.connections import get_bootstrap_tool, get_technology_type

    tech_type = get_technology_type(technology)
    bootstrap = get_bootstrap_tool(technology)
    desc_lower = (tool_description or "").lower()
    name_lower = tool_name.lower()

    # For database type: check if run_query can handle it
    if tech_type == "database":
        # These are things run_query already does — don't build a tool
        simple_sql_patterns = [
            "list_tables", "list_schemas", "count_rows", "show_tables",
            "get_columns", "describe_table", "table_count",
        ]
        if any(p in name_lower for p in simple_sql_patterns):
            return (
                f"Bootstrap tool '{bootstrap}' can already do this with SQL. "
                f"Use run_query with an appropriate SQL query instead of building a new tool."
            )

    # For api type: check if call_api can handle it
    if tech_type == "api":
        simple_api_patterns = [
            "list_dags", "get_dag", "list_pools", "list_connections",
        ]
        if any(p in name_lower for p in simple_api_patterns):
            return (
                f"Bootstrap tool '{bootstrap}' can already do this with HTTP. "
                f"Use call_api with the right endpoint instead of building a new tool."
            )

    # For filesystem type: check if read_files can handle it
    if tech_type == "filesystem":
        simple_file_patterns = [
            "list_files", "read_file", "search_files", "list_models",
            "get_model", "read_model",
        ]
        if any(p in name_lower for p in simple_file_patterns):
            return (
                f"Bootstrap tool '{bootstrap}' can already do this. "
                f"Use read_files with the right action instead of building a new tool."
            )

    # Check existing built tools in the registry
    try:
        registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
        for tool in registry.get("tools", []):
            if tool["name"] == tool_name:
                return f"Tool '{tool_name}' already exists in the registry."
    except Exception:
        pass

    return None


async def build_tool_for_step(
    step: dict,
    state: dict[str, Any],
) -> dict[str, Any]:
    """Run the build->test cycle for a missing tool.

    Includes a redundancy gate: rejects building tools that bootstrap
    tools or existing built tools can already handle.

    Args:
        step: PlanStep dict with tool, technology, tool_description.
        state: Current DataClawState.
    Returns:
        Updated state after build+test.
    """
    tool_name = step["tool"]
    technology = step.get("technology", "postgres")
    tool_description = step.get("tool_description") or step.get("reason") or ""

    # ── Redundancy gate ──────────────────────────────
    redundancy = _check_redundancy(tool_name, tool_description, technology)
    if redundancy:
        logger.info(f"[BUILD] SKIPPED '{tool_name}': {redundancy}")
        return {
            **state,
            "test_verdict": "rejected",
            "failure_reason": "redundant",
            "failure_details": redundancy,
        }

    logger.info(f"[BUILD] Starting build cycle for '{tool_name}' ({technology})")

    build_state = {
        **state,
        "tool_name": tool_name,
        "technology": technology,
        "user_prompt": step.get("tool_description") or step.get("reason") or state["user_prompt"],
        "attempt": 0,
        "failure_reason": None,
        "failure_details": None,
    }

    max_attempts = state.get("max_attempts", 3)

    for attempt in range(max_attempts):
        build_state["attempt"] = attempt
        logger.info(f"[BUILD] Attempt {attempt + 1}/{max_attempts} for '{tool_name}'")

        # Build
        build_result = await builder_run(build_state)
        build_state.update(build_result)

        # Test
        test_result = await tester_run(build_state)
        build_state.update(test_result)

        if build_state.get("test_verdict") == "pass":
            logger.info(f"[BUILD] '{tool_name}' PASSED on attempt {attempt + 1}")
            return build_state

        # ── Missing libraries: pause build and ask user to install ──
        sandbox_logs = test_result.get("sandbox_logs", "")
        if "MISSING_LIBRARIES" in str(sandbox_logs) or "MISSING_LIBRARIES" in str(test_result.get("failure_details", "")):
            # Extract library names from the tester output
            import re as _re
            match = _re.search(r"MISSING_LIBRARIES:\s*(.+)", str(test_result.get("failure_details", "")) or str(sandbox_logs))
            if match:
                libs = [lib.strip() for lib in match.group(1).split(",")]
                build_state["missing_libraries"] = libs
                build_state["test_verdict"] = "missing_libraries"
                logger.info(f"[BUILD] '{tool_name}' needs libraries: {libs}")
                return build_state

        # Prepare retry context
        build_state["failure_reason"] = test_result.get("failure_reason")
        build_state["failure_details"] = test_result.get("failure_details")
        logger.warning(f"[BUILD] '{tool_name}' FAILED attempt {attempt + 1}: {test_result.get('failure_reason')}")

    logger.error(f"[BUILD] '{tool_name}' failed after {max_attempts} attempts")
    return build_state


# ── LangGraph definition ────────────────────────────

from langgraph.graph import END, StateGraph
from graphs.states import DataClawState


async def _orchestrator_node(state: dict[str, Any]) -> dict[str, Any]:
    """Orchestrator node wrapper."""
    return await orchestrator_run(state)


async def _execute_tool_node(state: dict[str, Any]) -> dict[str, Any]:
    """Execute a single tool (fast path for bootstrap + existing tools)."""
    tool_name = state["tool_name"]
    technology = state.get("technology", "")
    connection_config = state.get("connection_config", {})

    # If connection_config is empty, load it
    if not connection_config and technology:
        connection_config = get_connection(technology)

    # Get params from the first plan step
    params = {}
    plan = state.get("plan", [])
    if plan:
        params = plan[0].get("params", {})

    logger.info(f"[FAST-PATH] Executing '{tool_name}' with params={json.dumps(params, default=str)[:200]}")

    try:
        result = execute_single_tool(tool_name, connection_config, params)
        return {"result": result}
    except Exception as e:
        friendly = diagnose(e, technology, connection_config)
        logger.error(f"[FAST-PATH] Failed: {e}")
        return {"error": friendly}


def _route_after_orchestrator(state: DataClawState) -> str:
    """Route after orchestrator based on intent and plan."""
    intent = state.get("intent", "action")

    if intent in ("greeting", "help", "clarify"):
        return "done"

    if state.get("tool_found"):
        return "execute"

    return "done"


graph = StateGraph(DataClawState)
graph.add_node("orchestrator", _orchestrator_node)
graph.add_node("execute_tool", _execute_tool_node)

graph.set_entry_point("orchestrator")

graph.add_conditional_edges("orchestrator", _route_after_orchestrator, {
    "execute": "execute_tool",
    "done": END,
})
graph.add_edge("execute_tool", END)

app = graph.compile()
