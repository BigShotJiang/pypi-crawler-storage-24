"""TypedDict states for the DataClaw reasoning agent."""

from typing import Optional, TypedDict


class ReasoningStep(TypedDict):
    """A single step in the agent's reasoning chain."""

    thought: str                       # what the agent is thinking
    action: str                        # "bootstrap_tool" | "built_tool" | "build_new" | "answer"
    tool: Optional[str]                # tool name to execute (or None for answer)
    technology: str                     # which technology this step targets
    params: dict                       # params to pass to the tool
    observation: Optional[str]         # result of executing the action
    status: str                        # "pending" | "executing" | "done" | "failed"


class PlanStep(TypedDict):
    """A single step in the orchestrator's plan (legacy compat)."""

    tool: str
    params: dict
    reason: str
    tool_exists: bool
    tool_description: Optional[str]
    technology: str
    status: str
    result: Optional[str]


class DataClawState(TypedDict):
    """State that flows through the reasoning agent.

    The agent operates in a ReAct loop:
      Think → Act → Observe → Think → ... → Answer
    """

    # User input
    user_prompt: str

    # Memory context (injected by CLI from MemoryStore)
    memory_context: Optional[dict]

    # Intent classification
    intent: str                        # "action" | "question" | "greeting" | "help" | "clarify"
    direct_response: Optional[str]
    clarify_options: list[str]         # Options to show user during CLARIFY

    # Reasoning chain (new: replaces flat plan)
    reasoning_steps: list[ReasoningStep]
    reasoning_complete: bool           # True when agent has enough info to answer

    # Plan (legacy compat — built from reasoning steps)
    plan: list[PlanStep]
    current_step: int
    collected_results: dict
    final_goal: str

    # Current step context
    task_id: str
    tool_name: Optional[str]
    technology: Optional[str]
    tool_found: bool
    connection_config: dict

    # Builder output
    generated_code: Optional[str]
    manifest: Optional[dict]

    # Tester output
    test_verdict: Optional[str]
    failure_reason: Optional[str]
    failure_details: Optional[str]
    sandbox_logs: Optional[str]

    # Flow control
    attempt: int
    max_attempts: int
    exploration_budget: dict           # {"builds_remaining": 3, "steps_remaining": 5}

    # Approval flow
    approval_status: Optional[str]
    approval_score: Optional[dict]
    needs_user_approval: bool

    # LLM status
    llm_error: Optional[str]           # Set when LLM is unavailable (e.g. "connection_refused")

    # Result
    result: Optional[str]
    error: Optional[str]
