"""Slash commands — fast shortcuts that bypass the LLM entirely.

When the user types '/' the CLI shows available commands.
Each command reads from config or executes tools directly.
"""

import json
import re
import sys
from pathlib import Path

import yaml

from utils.paths import get_config_dir, get_registry_path, get_mcp_tools_dir, PROJECT_ROOT

CONFIG_DIR = get_config_dir()
REGISTRY_PATH = get_registry_path()


# ── Colors ───────────────────────────────────────────

class C:
    """ANSI color codes."""
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    RED     = "\033[31m"
    GREEN   = "\033[32m"
    YELLOW  = "\033[33m"
    CYAN    = "\033[36m"
    BRED    = "\033[91m"
    BGREEN  = "\033[92m"
    BYELLOW = "\033[93m"
    BCYAN   = "\033[96m"
    MAGENTA = "\033[35m"


# ── Command registry ────────────────────────────────

COMMANDS: dict[str, dict] = {}


def command(name: str, description: str, usage: str = ""):
    """Decorator to register a slash command."""
    def decorator(func):
        COMMANDS[name] = {
            "function": func,
            "description": description,
            "usage": usage,
        }
        return func
    return decorator


# ── SQL identifier validation ────────────────────────

_VALID_IDENTIFIER = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def _validate_identifier(name: str) -> str:
    """Validate a SQL identifier (schema/table name) to prevent injection.

    Raises ValueError if the name contains anything other than
    letters, digits, and underscores.
    """
    name = name.strip()
    if not _VALID_IDENTIFIER.match(name):
        raise ValueError(f"Invalid SQL identifier: '{name}'. Only letters, digits, and underscores are allowed.")
    return name


# ── Helper: execute bootstrap tool ───────────────────

def _execute_tool(tool_name: str, **kwargs) -> dict:
    """Execute a tool via the gateway."""
    import importlib.util

    gateway_path = get_mcp_tools_dir() / "gateway.py"
    module_name = "mcp_tools.gateway_cmd"

    # Clear stale modules
    stale = [k for k in sys.modules if k.startswith("mcp_tools")]
    for k in stale:
        del sys.modules[k]

    spec = importlib.util.spec_from_file_location(module_name, gateway_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.execute_tool(tool_name, **kwargs)


def _get_connection(technology: str) -> dict:
    """Load connection config using the unified connections loader."""
    from utils.connections import get_connection
    return get_connection(technology)


def _get_database_connection(args: str = "") -> tuple[dict | None, str | None]:
    """Find a database connection — auto-detect or use the one specified in args.

    If multiple databases exist, lists them and asks the user to specify.
    Returns (connection_config, technology_key) or (None, None).
    """
    from utils.connections import load_all_connections, get_connection

    all_conns = load_all_connections()
    databases = {k: v for k, v in all_conns.items() if v.get("type") == "database"}

    if not databases:
        print(f"  {C.BRED}No database connections configured{C.RESET}")
        return None, None

    # If args specify a database name, use it
    parts = args.strip().split(None, 1)
    if parts:
        # Check if first arg is a database key
        for key in databases:
            if parts[0].lower() == key.lower():
                conn = get_connection(key)
                return conn, key

    # Single database — auto-select
    if len(databases) == 1:
        key = next(iter(databases))
        conn = get_connection(key)
        return conn, key

    # Multiple databases — show options
    print(f"\n  {C.BYELLOW}?{C.RESET} Multiple databases configured:")
    keys = list(databases.keys())
    for i, key in enumerate(keys, 1):
        db = databases[key]
        c = db.get("connection", {})
        label = f"{c.get('host', '?')}:{c.get('port', '?')}"
        access = db.get("access_level", "read")
        print(f"    {C.CYAN}{i}.{C.RESET} {key} {C.DIM}({label}, {access}){C.RESET}")
    print(f"  {C.DIM}Tip: use /schemas <db_name> to target a specific database{C.RESET}\n")
    return None, None


# ── Commands ─────────────────────────────────────────

@command("help", "Show available commands and example prompts")
def cmd_help(args: str) -> None:
    """Show help."""
    print(f"\n  {C.BOLD}Slash Commands{C.RESET}")
    print(f"  {C.DIM}{'─' * 50}{C.RESET}")
    for name, info in sorted(COMMANDS.items()):
        usage = f" {info['usage']}" if info["usage"] else ""
        print(f"  {C.BCYAN}/{name}{usage}{C.RESET}  {C.DIM}— {info['description']}{C.RESET}")

    print(f"\n  {C.BOLD}Example Prompts{C.RESET}")
    print(f"  {C.DIM}{'─' * 50}{C.RESET}")
    examples = [
        "list all tables in the raw schema",
        "count rows in raw.orders",
        "show me all Airflow DAGs",
        "check disk usage on the ssh server",
        "list kafka topics",
        "explain the data pipeline",
        "top 5 customers by order count",
    ]
    for ex in examples:
        print(f"  {C.DIM}>{C.RESET} {ex}")
    print()


@command("schemas", "List database schemas", "[database]")
def cmd_schemas(args: str) -> None:
    """List schemas — auto-detects database or asks if multiple."""
    conn, tech = _get_database_connection(args)
    if not conn:
        return
    try:
        result = _execute_tool(
            "run_query",
            connection_config=conn,
            query="SELECT schema_name FROM information_schema.schemata WHERE schema_name NOT IN ('pg_catalog', 'information_schema', 'pg_toast') ORDER BY schema_name",
        )
        if "error" in result:
            print(f"  {C.BRED}{result['error']}{C.RESET}")
            return
        rows = result.get("rows", [])
        print(f"\n  {C.BOLD}Schemas{C.RESET} on {C.CYAN}{tech}{C.RESET} ({len(rows)})")
        print(f"  {C.DIM}{'─' * 30}{C.RESET}")
        for row in rows:
            name = row.get("schema_name", row) if isinstance(row, dict) else row
            print(f"  {C.CYAN}•{C.RESET} {name}")
        print()
    except Exception as e:
        from utils.error_diagnoser import diagnose
        print(f"  {C.BRED}{diagnose(e, tech or 'database', conn)}{C.RESET}")


@command("tables", "List tables in a schema", "[schema] [database]")
def cmd_tables(args: str) -> None:
    """List tables — auto-detects database."""
    from utils.connections import load_all_connections
    all_conns = load_all_connections()
    databases = {k for k, v in all_conns.items() if v.get("type") == "database"}

    parts = args.strip().split()
    schema = "public"
    db_arg = ""

    if len(parts) == 1:
        # Single arg: is it a database name or a schema?
        if parts[0].lower() in {k.lower() for k in databases}:
            db_arg = parts[0]
        else:
            schema = parts[0]
    elif len(parts) >= 2:
        schema = parts[0]
        db_arg = " ".join(parts[1:])

    try:
        schema = _validate_identifier(schema)
    except ValueError as e:
        print(f"  {C.BRED}{e}{C.RESET}")
        return

    conn, tech = _get_database_connection(db_arg)
    if not conn:
        return
    try:
        result = _execute_tool(
            "run_query",
            connection_config=conn,
            query=f"SELECT table_name FROM information_schema.tables WHERE table_schema = '{schema}' ORDER BY table_name",
        )
        if "error" in result:
            print(f"  {C.BRED}{result['error']}{C.RESET}")
            return
        rows = result.get("rows", [])
        if not rows:
            print(f"\n  {C.BYELLOW}No tables found in schema '{schema}' on {tech}.{C.RESET}")
            print(f"  {C.DIM}Use /schemas to see available schemas.{C.RESET}\n")
            return
        print(f"\n  {C.BOLD}Tables in {schema}{C.RESET} on {C.CYAN}{tech}{C.RESET} ({len(rows)})")
        print(f"  {C.DIM}{'─' * 30}{C.RESET}")
        for row in rows:
            name = row.get("table_name", row) if isinstance(row, dict) else row
            print(f"  {C.CYAN}•{C.RESET} {name}")
        print()
    except Exception as e:
        from utils.error_diagnoser import diagnose
        print(f"  {C.BRED}{diagnose(e, tech or 'database', conn)}{C.RESET}")


@command("describe", "Describe a table's columns", "<schema.table> [database]")
def cmd_describe(args: str) -> None:
    """Describe table — auto-detects database."""
    parts = args.strip().split()
    if not parts:
        print(f"  {C.BRED}Usage: /describe <schema.table> or /describe <table>{C.RESET}")
        return

    table_ref = parts[0]
    db_arg = " ".join(parts[1:]) if len(parts) > 1 else ""

    tparts = table_ref.split(".")
    if len(tparts) == 2:
        schema, table = tparts
    else:
        schema, table = "public", tparts[0]

    try:
        schema = _validate_identifier(schema)
        table = _validate_identifier(table)
    except ValueError as e:
        print(f"  {C.BRED}{e}{C.RESET}")
        return

    conn, tech = _get_database_connection(db_arg)
    if not conn:
        return
    try:
        result = _execute_tool(
            "run_query",
            connection_config=conn,
            query=f"SELECT column_name, data_type, is_nullable FROM information_schema.columns WHERE table_schema = '{schema}' AND table_name = '{table}' ORDER BY ordinal_position",
        )
        if "error" in result:
            print(f"  {C.BRED}{result['error']}{C.RESET}")
            return
        rows = result.get("rows", [])
        if not rows:
            print(f"\n  {C.BYELLOW}Table '{schema}.{table}' not found on {tech}.{C.RESET}")
            print(f"  {C.DIM}Use /tables to see available tables.{C.RESET}\n")
            return
        print(f"\n  {C.BOLD}{schema}.{table}{C.RESET} on {C.CYAN}{tech}{C.RESET} ({len(rows)} columns)")
        print(f"  {C.DIM}{'─' * 50}{C.RESET}")
        for row in rows:
            if isinstance(row, dict):
                name = row.get("column_name", "?")
                dtype = row.get("data_type", "?")
                nullable = row.get("is_nullable", "YES")
                nullable_str = f"{C.DIM}nullable{C.RESET}" if nullable == "YES" else f"{C.BYELLOW}NOT NULL{C.RESET}"
                print(f"  {name:<25} {C.CYAN}{dtype:<15}{C.RESET} {nullable_str}")
        print()
    except Exception as e:
        from utils.error_diagnoser import diagnose
        print(f"  {C.BRED}{diagnose(e, tech or 'database', conn)}{C.RESET}")


@command("count", "Count rows in a table", "<schema.table> [database]")
def cmd_count(args: str) -> None:
    """Count rows — auto-detects database."""
    parts = args.strip().split()
    if not parts:
        print(f"  {C.BRED}Usage: /count <schema.table> or /count <table>{C.RESET}")
        return

    table_ref = parts[0]
    db_arg = " ".join(parts[1:]) if len(parts) > 1 else ""

    tparts = table_ref.split(".")
    if len(tparts) == 2:
        schema, table = tparts
    else:
        schema, table = "public", tparts[0]

    try:
        schema = _validate_identifier(schema)
        table = _validate_identifier(table)
    except ValueError as e:
        print(f"  {C.BRED}{e}{C.RESET}")
        return

    conn, tech = _get_database_connection(db_arg)
    if not conn:
        return
    try:
        result = _execute_tool(
            "run_query",
            connection_config=conn,
            query=f"SELECT COUNT(*) AS row_count FROM {schema}.{table}",
        )
        if "error" in result:
            print(f"  {C.BRED}{result['error']}{C.RESET}")
            return
        rows = result.get("rows", [])
        count = rows[0].get("row_count", "?") if rows else "?"
        print(f"\n  {C.BOLD}{schema}.{table}{C.RESET} on {C.CYAN}{tech}{C.RESET}  {C.CYAN}{count:,}{C.RESET} rows\n")
    except Exception as e:
        from utils.error_diagnoser import diagnose
        print(f"  {C.BRED}{diagnose(e, tech or 'database', conn)}{C.RESET}")


@command("sample", "Show first rows of a table", "<schema.table> [limit] [database]")
def cmd_sample(args: str) -> None:
    """Show sample rows — auto-detects database."""
    parts = args.strip().split()
    limit = 5

    if not parts:
        print(f"  {C.BRED}Usage: /sample <schema.table> [limit]{C.RESET}")
        return

    # Parse optional limit
    if len(parts) >= 2 and parts[1].isdigit():
        limit = int(parts[1])
        db_arg = " ".join(parts[2:]) if len(parts) > 2 else ""
    else:
        db_arg = " ".join(parts[1:]) if len(parts) > 1 else ""

    table_ref = parts[0]
    tparts = table_ref.split(".")
    if len(tparts) == 2:
        schema, table = tparts
    else:
        schema, table = "public", tparts[0]

    try:
        schema = _validate_identifier(schema)
        table = _validate_identifier(table)
    except ValueError as e:
        print(f"  {C.BRED}{e}{C.RESET}")
        return

    conn, tech = _get_database_connection(db_arg)
    if not conn:
        return
    try:
        result = _execute_tool(
            "run_query",
            connection_config=conn,
            query=f"SELECT * FROM {schema}.{table} LIMIT {limit}",
            limit=limit,
        )
        if "error" in result:
            print(f"  {C.BRED}{result['error']}{C.RESET}")
            return
        columns = result.get("columns", [])
        rows = result.get("rows", [])
        if not rows:
            print(f"\n  {C.BYELLOW}{schema}.{table} is empty.{C.RESET}\n")
            return

        # Calculate column widths
        col_widths = {}
        for col in columns:
            col_widths[col] = len(col)
            for row in rows:
                val = str(row.get(col, ""))
                if len(val) > 40:
                    val = val[:37] + "..."
                col_widths[col] = max(col_widths[col], len(val))

        # Print header
        header = "  ".join(f"{C.BOLD}{col:<{col_widths[col]}}{C.RESET}" for col in columns)
        sep = "  ".join("─" * col_widths[col] for col in columns)
        print(f"\n  {C.BOLD}{schema}.{table}{C.RESET} on {C.CYAN}{tech}{C.RESET} (first {len(rows)} rows)")
        print(f"  {header}")
        print(f"  {C.DIM}{sep}{C.RESET}")

        for row in rows:
            vals = []
            for col in columns:
                val = str(row.get(col, ""))
                if len(val) > 40:
                    val = val[:37] + "..."
                vals.append(f"{val:<{col_widths[col]}}")
            print(f"  {'  '.join(vals)}")
        print()
    except Exception as e:
        from utils.error_diagnoser import diagnose
        print(f"  {C.BRED}{diagnose(e, tech or 'database', conn)}{C.RESET}")


@command("tools", "List all registered tools (bootstrap + built)")
def cmd_tools(args: str) -> None:
    """List all tools."""
    print(f"\n  {C.BOLD}Bootstrap Tools{C.RESET} (always available)")
    print(f"  {C.DIM}{'─' * 50}{C.RESET}")
    bootstrap = [
        ("run_query", "Execute SQL against any database"),
        ("call_api", "Make HTTP requests to any REST API"),
        ("read_files", "Read, list, search files on disk"),
    ]
    for name, desc in bootstrap:
        print(f"  {C.BGREEN}•{C.RESET} {name:<25} {C.DIM}{desc}{C.RESET}")

    if REGISTRY_PATH.exists():
        registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
        tools = registry.get("tools", [])
        if tools:
            by_tech: dict[str, list[dict]] = {}
            for t in tools:
                tech = t.get("technology", "unknown")
                by_tech.setdefault(tech, []).append(t)

            print(f"\n  {C.BOLD}Agent-Built Tools{C.RESET} ({len(tools)} total)")
            print(f"  {C.DIM}{'─' * 50}{C.RESET}")
            for tech, tech_tools in sorted(by_tech.items()):
                print(f"  {C.BCYAN}{tech}{C.RESET}")
                for t in tech_tools:
                    print(f"    {C.CYAN}•{C.RESET} {t['name']:<25} {C.DIM}{t.get('description', '')[:60]}{C.RESET}")
        else:
            print(f"\n  {C.DIM}No agent-built tools yet — they'll be created as needed.{C.RESET}")
    print()


@command("systems", "List configured technology systems")
def cmd_systems(args: str) -> None:
    """List all configured technologies from connections.yaml."""
    from utils.connections import list_configured_technologies

    techs = list_configured_technologies()
    if not techs:
        print(f"  {C.BRED}No technologies configured{C.RESET}")
        return

    print(f"\n  {C.BOLD}Configured Systems{C.RESET} ({len(techs)})")
    print(f"  {C.DIM}{'─' * 50}{C.RESET}")
    for t in techs:
        type_color = {
            "database": C.CYAN,
            "api": C.GREEN,
            "filesystem": C.YELLOW,
        }.get(t["type"], C.DIM)
        print(f"  {C.BOLD}{t['name']}{C.RESET}  {type_color}{t['type']}{C.RESET}  "
              f"{C.DIM}driver: {t['driver']}, access: {t['access_level']}{C.RESET}")
    print()


@command("connections", "Show connection status for all systems")
def cmd_connections(args: str) -> None:
    """Show connections and test reachability."""
    from utils.connections import load_all_connections

    all_conns = load_all_connections()
    if not all_conns:
        print(f"  {C.BRED}No connections configured{C.RESET}")
        return

    print(f"\n  {C.BOLD}Connections{C.RESET}")
    print(f"  {C.DIM}{'─' * 50}{C.RESET}")

    for name, config in sorted(all_conns.items()):
        conn = config.get("connection", {})
        tech_type = config.get("type", "unknown")

        # Quick connectivity check
        status = _check_connection(conn)
        icon = f"{C.BGREEN}●{C.RESET}" if status else f"{C.BRED}●{C.RESET}"
        state = "reachable" if status else "unreachable"

        if "base_url" in conn:
            endpoint = conn["base_url"]
        elif "project_dir" in conn:
            endpoint = conn["project_dir"]
        elif "bootstrap_servers" in conn:
            endpoint = conn["bootstrap_servers"]
        else:
            endpoint = f"{conn.get('host', '?')}:{conn.get('port', '?')}"

        print(f"  {icon} {C.BOLD}{name}{C.RESET}  ({tech_type})  {endpoint}  {C.DIM}{state}{C.RESET}")
    print()


def _check_connection(conn: dict) -> bool:
    """Quick check if a service is reachable."""
    import socket
    import os

    try:
        if "base_url" in conn:
            from urllib.parse import urlparse
            parsed = urlparse(conn["base_url"])
            host = parsed.hostname or "localhost"
            port = parsed.port or 80
        elif "project_dir" in conn:
            return os.path.isdir(conn["project_dir"])
        elif "bootstrap_servers" in conn:
            # Kafka-style: "host1:port1,host2:port2"
            servers = conn["bootstrap_servers"]
            first = servers.split(",")[0].strip()
            if ":" in first:
                host, port_str = first.rsplit(":", 1)
                port = int(port_str)
            else:
                host, port = first, 9092
        else:
            host = conn.get("host", "localhost")
            port = int(conn.get("port", 5432))

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except Exception:
        return False


@command("status", "System overview: connections, tools, memory")
def cmd_status(args: str) -> None:
    """Show a compact system health dashboard."""
    from utils.connections import load_all_connections

    all_conns = load_all_connections()
    reachable = 0
    total = len(all_conns)
    for config in all_conns.values():
        conn = config.get("connection", {})
        if _check_connection(conn):
            reachable += 1

    # Tools count
    tool_count = 0
    if REGISTRY_PATH.exists():
        try:
            reg = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
            tool_count = len(reg.get("tools", []))
        except Exception:
            pass

    # Memory catalog stats
    catalog_entities = 0
    try:
        from memory.catalog import DataCatalog
        cat = DataCatalog()
        all_ents = cat._get_all_entities()
        catalog_entities = len(all_ents)
    except Exception:
        pass

    # Skill count
    skill_count = 0
    try:
        from skills.registry import get_registry
        skill_count = get_registry().count()
    except Exception:
        pass

    # Connector count
    connector_count = 0
    try:
        from connectors.manager import get_manager
        connector_count = len(get_manager().list_connectors())
    except Exception:
        pass

    health_icon = f"{C.BGREEN}●{C.RESET}" if reachable == total else f"{C.BYELLOW}●{C.RESET}"
    if reachable == 0:
        health_icon = f"{C.BRED}●{C.RESET}"

    print(f"\n  {C.BOLD}DataClaw Status{C.RESET}")
    print(f"  {C.DIM}{'─' * 40}{C.RESET}")
    print(f"  {health_icon} Connections   {C.BGREEN}{reachable}{C.RESET}/{total} reachable")
    print(f"  {C.CYAN}●{C.RESET} Bootstrap     3 tools (run_query, call_api, read_files)")
    print(f"  {C.CYAN}●{C.RESET} Built tools   {tool_count}")
    print(f"  {C.CYAN}●{C.RESET} Skills        {skill_count}")
    print(f"  {C.CYAN}●{C.RESET} Connectors    {connector_count}")
    print(f"  {C.CYAN}●{C.RESET} Catalog       {catalog_entities} known entities")
    print(f"\n  {C.DIM}Use /connections for details, /tools to see all tools, /skills to see skills{C.RESET}")
    print()


@command("config", "View or modify runtime settings", "[key] [value]")
def cmd_config(args: str) -> None:
    """View or modify runtime configuration.

    /config            — show all settings
    /config key        — show one setting
    /config key value  — change a setting
    """
    from utils.constants import get_all, get_descriptions, set_value, _DEFAULTS

    parts = args.strip().split(None, 1)

    # /config — show all
    if not parts:
        all_cfg = get_all()
        descs = get_descriptions()
        print(f"\n  {C.BOLD}Runtime Configuration{C.RESET}")
        print(f"  {C.DIM}{'─' * 55}{C.RESET}")
        print(f"  {C.DIM}Source: config/settings.yaml → runtime{C.RESET}\n")
        for key in sorted(all_cfg):
            val = all_cfg[key]
            default = _DEFAULTS.get(key)
            desc = descs.get(key, "")
            modified = f" {C.BYELLOW}(modified){C.RESET}" if val != default else ""
            print(f"  {C.BCYAN}{key}{C.RESET}  =  {C.BOLD}{val}{C.RESET}{modified}")
            if desc:
                print(f"  {C.DIM}  {desc}{C.RESET}")
        print(f"\n  {C.DIM}Usage: /config <key> <value> to change a setting{C.RESET}\n")
        return

    key = parts[0]

    # /config key — show one
    if len(parts) == 1:
        all_cfg = get_all()
        descs = get_descriptions()
        if key not in all_cfg:
            close = [k for k in all_cfg if key in k]
            if close:
                print(f"  {C.BYELLOW}Unknown key '{key}'. Did you mean: {', '.join(close)}?{C.RESET}")
            else:
                print(f"  {C.BRED}Unknown key '{key}'. Use /config to see all keys.{C.RESET}")
            return
        val = all_cfg[key]
        default = _DEFAULTS.get(key)
        desc = descs.get(key, "")
        print(f"\n  {C.BCYAN}{key}{C.RESET}  =  {C.BOLD}{val}{C.RESET}")
        if desc:
            print(f"  {C.DIM}{desc}{C.RESET}")
        print(f"  {C.DIM}Default: {default}{C.RESET}\n")
        return

    # /config key value — set
    value = parts[1]
    try:
        set_value(key, value)
        new_val = get_all()[key]
        print(f"  {C.BGREEN}✓{C.RESET} {C.BCYAN}{key}{C.RESET} = {C.BOLD}{new_val}{C.RESET}")
    except KeyError as e:
        print(f"  {C.BRED}{e}{C.RESET}")
    except ValueError:
        print(f"  {C.BRED}Invalid value '{value}' — expected a number.{C.RESET}")


@command("skills", "List saved reusable skills", "[technology]")
def cmd_skills(args: str) -> None:
    """List all saved skills, optionally filtered by technology."""
    from skills.registry import get_registry

    registry = get_registry()
    tech_filter = args.strip() if args.strip() else None

    if tech_filter:
        skills = registry.list_by_technology(tech_filter)
    else:
        skills = registry.list_all()

    if not skills:
        if tech_filter:
            print(f"\n  {C.DIM}No skills for '{tech_filter}' yet.{C.RESET}\n")
        else:
            print(f"\n  {C.DIM}No skills yet — they'll be promoted from successful ephemeral executions.{C.RESET}\n")
        return

    # Group by technology
    by_tech: dict[str, list[dict]] = {}
    for s in skills:
        by_tech.setdefault(s["technology"], []).append(s)

    print(f"\n  {C.BOLD}Skills{C.RESET} ({len(skills)} total)")
    print(f"  {C.DIM}{'─' * 50}{C.RESET}")

    for tech, tech_skills in sorted(by_tech.items()):
        print(f"  {C.BCYAN}{tech}{C.RESET}")
        for s in tech_skills:
            total = s["success_count"] + s["fail_count"]
            rel = s["reliability"]
            rel_color = C.BGREEN if rel >= 0.8 else C.BYELLOW if rel >= 0.5 else C.BRED
            stats = f"{rel_color}{rel:.0%}{C.RESET} ({total}x)" if total > 0 else f"{C.DIM}new{C.RESET}"
            tags = f" {C.DIM}[{', '.join(s['tags'][:3])}]{C.RESET}" if s["tags"] else ""
            print(f"    {C.CYAN}•{C.RESET} {s['name']:<25} {stats}{tags}")
            if s["description"]:
                print(f"      {C.DIM}{s['description'][:60]}{C.RESET}")

    print(f"\n  {C.DIM}Skills are promoted from successful ephemeral executions.{C.RESET}")
    print(f"  {C.DIM}They provide templates for the LLM to generate better code.{C.RESET}\n")


@command("connectors", "List generated connectors for non-bootstrap technologies")
def cmd_connectors(args: str) -> None:
    """List all LLM-generated connectors."""
    from connectors.manager import get_manager
    manager = get_manager()
    connectors = manager.list_connectors()

    if not connectors:
        print(f"\n  {C.DIM}No connectors yet — they'll be auto-generated when you query non-bootstrap technologies.{C.RESET}\n")
        return

    print(f"\n  {C.BOLD}Connectors{C.RESET} ({len(connectors)})")
    print(f"  {C.DIM}{'─' * 40}{C.RESET}")
    for c in connectors:
        icon = f"{C.BGREEN}●{C.RESET}" if c["has_client"] else f"{C.DIM}○{C.RESET}"
        state = "connected" if c["has_client"] else "idle"
        print(f"  {icon} {C.BOLD}{c['technology']}{C.RESET}  {C.DIM}{state}{C.RESET}")
    print(f"\n  {C.DIM}Connectors are auto-generated by the LLM on first use.{C.RESET}")
    print(f"  {C.DIM}Regenerated automatically on connection failure.{C.RESET}\n")


@command("learn", "Start a teaching session on a topic", "<topic>")
def cmd_learn(args: str) -> None:
    """Start interactive learning mode. Handled by main.py learn loop."""
    # This is a placeholder — actual implementation is in main.py
    # The command registry exposes it in /help
    if not args.strip():
        print(f"\n  {C.BRED}Usage: /learn <topic>{C.RESET}")
        print(f"  {C.DIM}Example: /learn sql, /learn kafka, /learn data modeling{C.RESET}\n")
        return
    # Signal to main.py that learning mode should start
    # This is handled specially in the main loop
    pass


@command("delearn", "Exit the current teaching session")
def cmd_delearn(args: str) -> None:
    """Exit learning mode. Handled by main.py."""
    # Placeholder — actual implementation in main.py
    pass


@command("clear", "Clear the terminal screen")
def cmd_clear(args: str) -> None:
    """Clear screen."""
    import os
    os.system("cls" if sys.platform == "win32" else "clear")


# ── Command dispatcher ───────────────────────────────

def handle_command(raw_input: str) -> bool:
    """Parse and execute a slash command."""
    text = raw_input.lstrip("/").strip()

    if not text:
        cmd_help("")
        return True

    parts = text.split(None, 1)
    cmd_name = parts[0].lower()
    cmd_args = parts[1] if len(parts) > 1 else ""

    if cmd_name in COMMANDS:
        COMMANDS[cmd_name]["function"](cmd_args)
        return True

    close = [name for name in COMMANDS if name.startswith(cmd_name)]
    if close:
        suggestions = ", ".join(f"/{c}" for c in close)
        print(f"  {C.BYELLOW}Unknown command '/{cmd_name}'. Did you mean: {suggestions}?{C.RESET}")
    else:
        print(f"  {C.BYELLOW}Unknown command '/{cmd_name}'. Type / to see available commands.{C.RESET}")

    return True
