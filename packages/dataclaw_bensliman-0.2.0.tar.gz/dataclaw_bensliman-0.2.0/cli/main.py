"""Terminal interface for DataClaw — autonomous reasoning agent.

The agent reasons step-by-step, showing its thinking process:
  Think → Act → Observe → Think → ... → Answer

Memory-aware: maintains session context and auto-populates the data catalog
so the agent has continuity between turns.
"""

import asyncio
import io
import json
import logging
import os
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import yaml

# Force UTF-8 on stdout/stderr so Unicode symbols work even when piped on Windows
if sys.platform == "win32" and not isinstance(sys.stdout, io.TextIOWrapper):
    pass  # already wrapped
elif hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# Ensure project root is on sys.path
PROJECT_ROOT = Path(__file__).parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from cli.commands import handle_command
from agents.orchestrator.agent import continue_reasoning
from graphs.main_graph import (
    app,
    build_tool_for_step,
    commit_tool,
    execute_plan_step,
    generate_connector,
    execute_ephemeral_step,
    promote_to_skill,
)
from connectors.manager import get_manager as get_connector_manager
from memory.store import MemoryStore
from utils.connections import get_connection, get_technology_type, resolve_user_reference
from utils.error_diagnoser import diagnose
from utils.synthesizer import synthesize


# ── Colors (ANSI) ────────────────────────────────────

class C:
    """ANSI color codes."""
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    RED     = "\033[31m"
    GREEN   = "\033[32m"
    YELLOW  = "\033[33m"
    BLUE    = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN    = "\033[36m"
    WHITE   = "\033[37m"
    BRED    = "\033[91m"
    BGREEN  = "\033[92m"
    BYELLOW = "\033[93m"
    BCYAN   = "\033[96m"
    CLEAR_LINE = "\033[2K\r"
    HIDE_CURSOR = "\033[?25l"
    SHOW_CURSOR = "\033[?25h"


# ── Spinner animation ────────────────────────────────

class Spinner:
    """Animated spinner that runs in a background thread.

    Usage:
        with Spinner("Thinking"):
            await long_operation()
    """

    # Braille dot animation frames — smooth rotation
    FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    # Pulsing dots for longer waits
    PHASES = [
        f"{C.CYAN}",
        f"{C.BCYAN}",
        f"{C.WHITE}",
        f"{C.BCYAN}",
        f"{C.CYAN}",
        f"{C.DIM}",
    ]

    def __init__(self, label: str = "Working", detail: str = ""):
        self._label = label
        self._detail = detail
        self._running = False
        self._thread = None
        self._start_time = 0

    def start(self):
        """Start the spinner animation."""
        self._running = True
        self._start_time = time.time()
        self._thread = threading.Thread(target=self._animate, daemon=True)
        self._thread.start()

    def stop(self):
        """Stop the spinner and clear the line."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=1)
        # Clear the spinner line
        sys.stdout.write(C.CLEAR_LINE)
        sys.stdout.flush()

    def update(self, label: str = "", detail: str = ""):
        """Update label/detail while spinning."""
        if label:
            self._label = label
        if detail:
            self._detail = detail

    def _animate(self):
        """Background animation loop."""
        frame_idx = 0
        phase_idx = 0
        try:
            sys.stdout.write(C.HIDE_CURSOR)
            while self._running:
                elapsed = time.time() - self._start_time
                frame = self.FRAMES[frame_idx % len(self.FRAMES)]
                color = self.PHASES[phase_idx % len(self.PHASES)]

                # Build the status line
                elapsed_str = f"{elapsed:.0f}s" if elapsed >= 2 else ""
                detail_part = f"  {C.DIM}{self._detail}{C.RESET}" if self._detail else ""
                time_part = f"  {C.DIM}({elapsed_str}){C.RESET}" if elapsed_str else ""

                line = f"  {color}{frame}{C.RESET} {C.BOLD}{self._label}{C.RESET}{detail_part}{time_part}"
                sys.stdout.write(f"{C.CLEAR_LINE}{line}")
                sys.stdout.flush()

                frame_idx += 1
                if frame_idx % 6 == 0:
                    phase_idx += 1

                time.sleep(0.08)
        finally:
            sys.stdout.write(C.SHOW_CURSOR)
            sys.stdout.flush()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.stop()


def _build_banner() -> str:
    """Build the startup banner with live system/tool info."""
    from utils.connections import load_all_connections
    import json

    # Count connected systems and built tools
    try:
        systems = list(load_all_connections().keys())
    except Exception:
        systems = []

    registry_path = PROJECT_ROOT / "mcp-tools" / "registry.json"
    tool_count = 0
    try:
        reg = json.loads(registry_path.read_text())
        tool_count = len(reg.get("tools", []))
    except Exception:
        pass

    G = C.BGREEN
    D = C.DIM
    R = C.RESET
    B = C.BOLD
    CY = C.CYAN

    # Big block ASCII art title + robotic octopus on the right
    YL = C.BYELLOW  # yellow for antenna/joints
    W = C.WHITE     # white for body structure

    logo_lines = f"""\
{G} ____   ___  ______  ___  {R}        {YL} _|_{R}
{G}|  _ \\ / _ \\|__  __|/ _ \\ {R}      {W}[____]{R}
{G}| | | | |_| |  | |  |_| |{R}     {W}/------\\{R}
{G}| | | |  _  |  | |  _  | {R}    {W}|{CY} []  [] {R}{W}|{R}
{G}| |_| | | | |  | | | | | {R}    {W}| {CY} ....  {R}{W}|{R}
{G}|____/|_| |_|  |_||_| |_|{R}    {W}|  {CY} []   {R}{W}|{R}
{B} ___  _     ___  _    _  {R}    {W} \\------/{R}
{B}/ __|| |   / _ \\| |  | | {R}   {W}/{YL}o{W}|{R}      {W}|{YL}o{W}\\{R}
{B}| |  | |  | |_| | |  | | {R}  {W}/{YL}o{W} |{R}      {W}| {YL}o{W}\\{R}
{B}| |  | |  |  _  | |/\\| | {R} {W}/  |{R}        {W}|  \\{R}
{B}| |__| |__| | | |  /\\  | {R} {W}\\__|{R}        {W}|__/{R}
{B}\\___||____|_| |_|_/  \\_| {R}     {W}\\________/{R}"""

    version = f"{D}v0.2{R}"
    # Add indent to each logo line
    combined_str = "\n".join(f"  {line}" for line in logo_lines.split("\n"))

    tech_str = f"{CY}{len(systems)} technologies{R}"
    tool_str = f"{G}{tool_count} built tools{R}" if tool_count else f"{D}no built tools yet{R}"

    lines = [
        "",
        combined_str,
        f"{'':>46}{version}",
        "",
        f"  {C.BGREEN}\u2713{R} {tech_str} connected",
        f"  {C.BGREEN}\u2713{R} {tool_str} loaded",
        f"  {G}Ready to explore!{R} What would you like to know?",
        f"  {D}Enter send \u2022 Ctrl+C quit \u2022 / commands{R}",
    ]

    return "\n".join(lines)

DIVIDER    = f"{C.DIM}{'~' * 56}{C.RESET}"
DIVIDER_SM = f"{C.DIM}{'~' * 40}{C.RESET}"


# ── Output helpers ───────────────────────────────────

def _step(icon: str, label: str, detail: str = "", done: bool = False, failed: bool = False) -> None:
    """Print a pipeline step."""
    if failed:
        status = f"{C.BRED}✗{C.RESET}"
    elif done:
        status = f"{C.BGREEN}✓{C.RESET}"
    else:
        status = f"{C.BYELLOW}⟳{C.RESET}"
    line = f"  {status} {C.BOLD}{label}{C.RESET}"
    if detail:
        line += f"  {C.DIM}{detail}{C.RESET}"
    print(line)
    sys.stdout.flush()


def _thought(msg: str) -> None:
    """Print a reasoning thought (agent's internal monologue)."""
    print(f"  {C.MAGENTA}💭{C.RESET} {C.DIM}{msg}{C.RESET}")
    sys.stdout.flush()


def _info(msg: str) -> None:
    """Print an info line."""
    print(f"  {C.DIM}{msg}{C.RESET}")
    sys.stdout.flush()


def _warn(msg: str) -> None:
    """Print a warning."""
    print(f"  {C.BYELLOW}⚠ {msg}{C.RESET}")
    sys.stdout.flush()


def _error(msg: str) -> None:
    """Print an error."""
    print(f"  {C.BRED}✗ {msg}{C.RESET}")
    sys.stdout.flush()


def _success(msg: str) -> None:
    """Print a success message."""
    print(f"  {C.BGREEN}✓ {msg}{C.RESET}")
    sys.stdout.flush()


def _score_bar(value: int, width: int = 20) -> str:
    """Render a score as a visual bar."""
    filled = int(width * value / 100)
    bar = "█" * filled + "░" * (width - filled)
    color = C.BGREEN if value >= 70 else C.BYELLOW if value >= 40 else C.BRED
    return f"{color}{bar}{C.RESET} {value}/100"


# ── Approval flow ────────────────────────────────────

def _print_approval_report(state: dict) -> None:
    """Print the tool approval report with scores."""
    tool_name = state.get("tool_name", "unknown")
    technology = state.get("technology", "unknown")
    score = state.get("approval_score", {})
    verdict = state.get("test_verdict", "unknown")
    attempt = state.get("attempt", 0)

    print()
    print(DIVIDER)
    print(f"  {C.BOLD}TOOL APPROVAL REPORT{C.RESET}")
    print(DIVIDER)
    print(f"  {C.DIM}Tool:{C.RESET}       {C.BOLD}{tool_name}{C.RESET}")
    print(f"  {C.DIM}Technology:{C.RESET} {technology}")
    v_color = C.BGREEN if verdict == "pass" else C.BRED
    print(f"  {C.DIM}Test:{C.RESET}       {v_color}{verdict.upper()}{C.RESET} {C.DIM}(attempt {attempt}){C.RESET}")
    print()

    if score:
        print(f"  {C.BOLD}Scores:{C.RESET}")
        print(f"    Quality:     {_score_bar(score.get('quality', 0))}")
        print(f"    Safety:      {_score_bar(score.get('safety', 0))}")
        print(f"    Reusability: {_score_bar(score.get('reusability', 0))}")
        print(f"    {C.DIM}{'─' * 42}{C.RESET}")
        overall = score.get("overall", 0)
        grade = "A" if overall >= 80 else "B" if overall >= 60 else "C" if overall >= 40 else "D"
        g_color = C.BGREEN if grade == "A" else C.BYELLOW if grade == "B" else C.BRED
        print(f"    Overall:     {_score_bar(overall)}  Grade: {g_color}{C.BOLD}{grade}{C.RESET}")
    print()
    print(DIVIDER_SM)
    print(f"  {C.BGREEN}[A]{C.RESET}pprove  — store and execute")
    print(f"  {C.BRED}[R]{C.RESET}eject   — discard (asks reason)")
    print(f"  {C.BCYAN}[V]{C.RESET}iew     — show generated code")
    print(f"  {C.BYELLOW}[E]{C.RESET}dit     — open in editor, re-test")
    print(DIVIDER_SM)


def _view_code(state: dict) -> None:
    """Display generated code."""
    code = state.get("generated_code", "No code available")
    print()
    print(DIVIDER)
    print(f"  {C.BOLD}GENERATED CODE{C.RESET}")
    print(DIVIDER)
    for i, line in enumerate(code.splitlines(), 1):
        print(f"  {C.DIM}{i:3d}{C.RESET} │ {line}")
    print(DIVIDER)
    print()


def _edit_code(state: dict) -> str | None:
    """Open generated code in $EDITOR and return edited version."""
    editor = os.environ.get("EDITOR", "notepad" if sys.platform == "win32" else "vi")
    code = state.get("generated_code", "")

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False, prefix="dataclaw_edit_", encoding="utf-8"
    ) as f:
        f.write(code)
        tmp_path = f.name

    try:
        subprocess.run([editor, tmp_path], check=True)
        edited = Path(tmp_path).read_text(encoding="utf-8")
        return edited
    except Exception as e:
        _error(f"Editor failed: {e}")
        return None
    finally:
        Path(tmp_path).unlink(missing_ok=True)


async def handle_approval(build_state: dict, memory: MemoryStore | None = None) -> bool:
    """Interactive approval loop. Returns True if approved, False if rejected."""
    _print_approval_report(build_state)

    while True:
        try:
            choice = input(f"\n  {C.BOLD}Your choice > {C.RESET}").strip().lower()
        except (EOFError, KeyboardInterrupt):
            _error("Rejected (interrupted)")
            return False

        if choice in ("a", "approve"):
            _step("⟳", "Committing", "Saving tool to library...")
            await commit_tool(build_state)
            _step("✓", "Committed", "Tool saved", done=True)

            if memory:
                memory.record_outcome(
                    task_id=build_state.get("task_id", ""),
                    tool_name=build_state.get("tool_name", ""),
                    technology=build_state.get("technology", ""),
                    action="build",
                    verdict="pass",
                    details={"attempt": build_state.get("attempt", 0)},
                )
            return True

        elif choice in ("r", "reject"):
            reason = input(f"  {C.DIM}Reason > {C.RESET}").strip()
            _error(f"Rejected: {reason or 'no reason'}")

            if memory:
                memory.record_outcome(
                    task_id=build_state.get("task_id", ""),
                    tool_name=build_state.get("tool_name", ""),
                    technology=build_state.get("technology", ""),
                    action="build",
                    verdict="rejected",
                    details={"reason": reason},
                )
            return False

        elif choice in ("v", "view"):
            _view_code(build_state)

        elif choice in ("e", "edit"):
            edited = _edit_code(build_state)
            if edited and edited != build_state.get("generated_code"):
                _step("⟳", "Re-testing", "Validating edited code...")
                build_state["generated_code"] = edited
                from agents.tester.agent import run as tester_run
                test_result = await tester_run(build_state)
                build_state.update(test_result)
                if build_state.get("test_verdict") == "pass":
                    _step("✓", "Re-test", "PASSED", done=True)
                    _print_approval_report(build_state)
                else:
                    _error(f"Re-test FAILED: {build_state.get('failure_reason', 'unknown')}")
                    _info(f"{(build_state.get('failure_details') or '')[:200]}")
                    _info(f"You can [E]dit again, [V]iew, or [R]eject.")
            else:
                _info("No changes detected.")

        else:
            _info("Use [A]pprove, [R]eject, [V]iew, or [E]dit.")


# ── Result formatting (human-friendly output) ────────

def _format_result(result_str: str) -> str:
    """Format a tool result for human-friendly display."""
    try:
        result = json.loads(result_str) if isinstance(result_str, str) else result_str
    except (json.JSONDecodeError, TypeError):
        return str(result_str)

    if not isinstance(result, dict):
        return str(result)

    if "error" in result:
        return f"{C.BRED}Error: {result['error']}{C.RESET}"

    # Unwrap nested dicts
    for key, value in list(result.items()):
        if isinstance(value, dict):
            for inner_key, inner_val in value.items():
                if isinstance(inner_val, list):
                    result = {key: inner_val}
                    break

    # Text content
    if "content" in result and isinstance(result["content"], str):
        content = result["content"]
        lines = content.strip().splitlines()
        formatted = []
        for i, line in enumerate(lines, 1):
            formatted.append(f"  {C.DIM}{i:3d}{C.RESET} │ {line}")
        return "\n".join(formatted)

    # Query results with rows
    if "rows" in result and isinstance(result["rows"], list):
        rows = result["rows"]
        cols = result.get("columns", [])
        count = result.get("row_count", len(rows))
        lines = [f"  {C.DIM}{count} row(s) returned{C.RESET}"]
        if cols:
            header = " │ ".join(f"{C.BOLD}{c}{C.RESET}" for c in cols)
            lines.append(f"  {header}")
            lines.append(f"  {C.DIM}{'─' * 50}{C.RESET}")
        for row in rows[:20]:
            if isinstance(row, dict):
                vals = " │ ".join(str(v) for v in row.values())
            else:
                vals = str(row)
            lines.append(f"  {vals}")
        if len(rows) > 20:
            lines.append(f"  {C.DIM}... and {len(rows) - 20} more rows{C.RESET}")
        return "\n".join(lines)

    # Directory tree
    if "tree" in result and isinstance(result["tree"], str):
        return f"  {C.DIM}Directory: {result.get('base_dir', '?')}{C.RESET}\n" + \
               "\n".join(f"  {line}" for line in result["tree"].splitlines())

    # File listing
    if "files" in result and isinstance(result["files"], list):
        files = result["files"]
        lines = [f"  {C.BOLD}{len(files)} files{C.RESET} {C.DIM}(in {result.get('base_dir', '?')}){C.RESET}"]
        for f in files[:30]:
            if isinstance(f, dict):
                path = f.get("path", "?")
                size = f.get("size", 0)
                lines.append(f"    {C.CYAN}•{C.RESET} {path} {C.DIM}({size} bytes){C.RESET}")
            else:
                lines.append(f"    {C.CYAN}•{C.RESET} {f}")
        if len(files) > 30:
            lines.append(f"    {C.DIM}... and {len(files) - 30} more{C.RESET}")
        return "\n".join(lines)

    # Search results
    if "matches" in result and isinstance(result["matches"], list):
        matches = result["matches"]
        lines = [f"  {C.BOLD}{result.get('files_matched', len(matches))} files matched{C.RESET} for '{result.get('query', '?')}'"]
        for m in matches[:10]:
            if isinstance(m, dict):
                path = m.get("path", "?")
                lines.append(f"    {C.CYAN}•{C.RESET} {path}")
                for hit in m.get("matches", [])[:3]:
                    if isinstance(hit, dict):
                        lines.append(f"      {C.DIM}L{hit.get('line_number', '?')}: {hit.get('text', '')[:80]}{C.RESET}")
        return "\n".join(lines)

    # Lists of entities
    skip_keys = {"query", "row_count", "error", "status", "message", "total_entries", "count"}
    for key, value in result.items():
        if key in skip_keys or not isinstance(value, list):
            continue
        items = value
        if not items:
            return f"  {C.DIM}No {key} found.{C.RESET}"

        lines = [f"  {C.BOLD}{len(items)} {key}{C.RESET}"]
        for item in items[:30]:
            if isinstance(item, dict):
                name = item.get("name") or item.get("dag_id") or item.get("dag_display_name") or item.get("table_name") or item.get("schema_name") or str(item)
                details = []
                for dk in ("description", "path", "schedule_interval", "type", "schema", "is_paused"):
                    dv = item.get(dk)
                    if dv is not None:
                        if isinstance(dv, dict):
                            dv = dv.get("value", str(dv))
                        details.append(f"{dk}: {dv}")
                detail_str = f" {C.DIM}({', '.join(details[:3])}){C.RESET}" if details else ""
                lines.append(f"    {C.CYAN}•{C.RESET} {name}{detail_str}")
            else:
                lines.append(f"    {C.CYAN}•{C.RESET} {item}")
        if len(items) > 30:
            lines.append(f"    {C.DIM}... and {len(items) - 30} more{C.RESET}")
        return "\n".join(lines)

    # Fallback: compact JSON
    compact = json.dumps(result, indent=2, default=str)
    if len(compact) > 500:
        return compact[:500] + f"\n{C.DIM}... (truncated){C.RESET}"
    return compact


# ── Result summary helpers ───────────────────────────

def _summarize_result(tool_name: str, result_str: str, max_len: int = 120) -> str:
    """Create a short summary of a tool result for session memory."""
    try:
        result = json.loads(result_str) if isinstance(result_str, str) else result_str
    except (json.JSONDecodeError, TypeError):
        return result_str[:max_len] if result_str else "No result"

    if not isinstance(result, dict):
        return str(result)[:max_len]

    if "error" in result:
        return f"Error: {result['error']}"

    if "rows" in result and "row_count" in result:
        return f"Query returned {result['row_count']} rows"

    if "files" in result:
        return f"Found {len(result['files'])} files"

    if "content" in result:
        return f"File content ({result.get('size', '?')} chars)"

    skip_keys = {"query", "row_count", "error", "status", "message", "count"}
    parts = []
    for key, value in result.items():
        if key in skip_keys:
            continue
        if isinstance(value, list):
            names = []
            for item in value[:10]:
                if isinstance(item, dict):
                    names.append(str(item.get("name", item.get("dag_id", item.get("table_name", "?")))))
                else:
                    names.append(str(item))
            summary = f"Found {len(value)} {key}: {', '.join(names)}"
            parts.append(summary)
        elif isinstance(value, (int, float)):
            parts.append(f"{key}={value}")

    if parts:
        return "; ".join(parts)[:max_len]

    return f"Result keys: {', '.join(result.keys())}"


def _extract_entity_names(tool_name: str, result_str: str) -> list[str]:
    """Extract entity names from a tool result for session memory."""
    try:
        result = json.loads(result_str) if isinstance(result_str, str) else result_str
    except (json.JSONDecodeError, TypeError):
        return []

    if not isinstance(result, dict) or "error" in result:
        return []

    skip_keys = {"query", "row_count", "error", "status", "message", "count", "rows"}
    names = []
    for key, value in result.items():
        if key in skip_keys or not isinstance(value, list):
            continue
        for item in value:
            if isinstance(item, dict):
                name = item.get("name", item.get("dag_id", item.get("table_name", item.get("schema_name", ""))))
                if name:
                    names.append(str(name))
            elif isinstance(item, str):
                names.append(item)
    return names


# ── Config ───────────────────────────────────────────

def load_config() -> dict:
    """Load settings from config/settings.yaml."""
    from utils.paths import get_settings_path
    config_path = get_settings_path()
    if not config_path.exists():
        print(f"\n  {C.BRED}Config not found:{C.RESET} {config_path}")
        print(f"  Run {C.BGREEN}dataclaw init{C.RESET} first to create config files.\n")
        sys.exit(1)
    return yaml.safe_load(config_path.read_text())


def setup_logging(level: str = "INFO") -> None:
    """Configure logging — file + optional terminal for reasoning steps."""
    from utils.paths import get_logs_dir
    log_dir = get_logs_dir()

    # File handler: everything
    file_handler = logging.FileHandler(log_dir / "dataclaw.log", encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter("%(asctime)s [%(name)s] %(levelname)s: %(message)s"))

    # Console handler: only reasoning tags (INFO+)
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(logging.WARNING)  # only warnings+ to stderr
    console_handler.setFormatter(logging.Formatter("  %(message)s"))

    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        handlers=[file_handler, console_handler],
    )


# ── Main loop ────────────────────────────────────────

async def process_prompt(user_input: str, config: dict, memory: MemoryStore, clarify_depth: int = 0) -> None:
    """Process a single user prompt through the reasoning pipeline."""
    start = time.time()
    print()

    # ── Get memory context for the orchestrator ──
    memory_context = memory.get_planning_context(user_input)

    # ── Step 1: Orchestrator (reasoning + plan) ──
    spinner = Spinner("Thinking", "Analyzing your request...")
    spinner.start()

    result = await app.ainvoke({
        "user_prompt": user_input,
        "memory_context": memory_context,
        "attempt": 0,
        "max_attempts": config["general"]["max_test_loops"],
        "_clarify_depth": clarify_depth,
    })

    spinner.stop()
    intent = result.get("intent", "action")
    elapsed = time.time() - start

    # Show LLM error clearly if the agent fell back to heuristics
    llm_error = result.get("llm_error")
    is_heuristic = bool(llm_error)
    if is_heuristic:
        print(f"  {C.BYELLOW}{'─' * 50}{C.RESET}")
        print(f"  {C.BYELLOW}⚠  LLM is DOWN{C.RESET} ({llm_error})")
        print(f"  {C.DIM}   Running in heuristic mode — keyword pattern matching only.{C.RESET}")
        print(f"  {C.DIM}   Results may be limited. Complex queries won't work.{C.RESET}")
        print(f"  {C.BYELLOW}{'─' * 50}{C.RESET}")

    # Show reasoning if available
    reasoning_steps = result.get("reasoning_steps", [])
    if reasoning_steps:
        for rs in reasoning_steps:
            thought = rs.get("thought", "")
            if thought:
                _thought(thought)

    # ── Greeting / Help → direct response ──
    if intent in ("greeting", "help"):
        _step("✓", "Thinking", f"Intent: {intent}", done=True)
        direct = result.get("direct_response", "")
        print(f"\n{direct}")
        _info(f"({elapsed:.1f}s)")
        memory.add_turn(user_input, intent, None, direct[:100])
        return

    # ── Clarify → ask user, then re-run with their answer ──
    if intent == "clarify":
        _step("✓", "Thinking", "Need more info", done=True)
        question = result.get("direct_response", "Could you be more specific?")
        options = result.get("clarify_options", [])

        print(f"\n  {C.BYELLOW}?{C.RESET} {question}")
        if options:
            for i, opt in enumerate(options, 1):
                print(f"    {C.CYAN}{i}.{C.RESET} {opt}")
        print()

        try:
            answer = input(f"  {C.BOLD}> {C.RESET}").strip()
        except (EOFError, KeyboardInterrupt):
            _error("Cancelled.")
            return

        if not answer:
            _info("No answer provided.")
            return

        # Detect "all/both/each/every" → user wants ALL options, not a specific one
        answer_lower = answer.lower().strip()
        all_keywords = {"all", "both", "each", "every", "all of them", "everything", "tous"}
        wants_all = any(kw in answer_lower for kw in all_keywords)

        if wants_all and options:
            # User wants all options — extract all connection keys and build multi-target prompt
            all_keys = []
            for opt in options:
                key_part = opt.split(" — ")[0].strip() if " — " in opt else opt
                all_keys.append(key_part)
            clarified_prompt = f"{user_input} — use all: {', '.join(all_keys)}"
        else:
            # Try to resolve the user's answer to a connection key
            # e.g., "analytics_db" or "the analytics one" → "postgres_analytics"
            resolved = resolve_user_reference(answer)
            if resolved:
                clarified_prompt = f"{user_input} — use {resolved}"
            elif answer.isdigit() and options and 1 <= int(answer) <= len(options):
                # User picked by number — extract the connection key from the option
                picked = options[int(answer) - 1]
                # Options are like "postgres_analytics — analytics_db (localhost:5433, write)"
                key_part = picked.split(" — ")[0].strip() if " — " in picked else picked
                clarified_prompt = f"{user_input} — use {key_part}"
            else:
                # User gave a follow-up question or additional context
                # Include the original CLARIFY context so the LLM knows not to re-ask
                clarified_prompt = f"{user_input} (context: I was asked which system, and replied: {answer})"
        _info(f"({elapsed:.1f}s for clarification)")
        memory.add_turn(user_input, "clarify", None, f"Clarified: {answer[:80]}")
        await process_prompt(clarified_prompt, config, memory, clarify_depth=clarify_depth + 1)
        return

    # ── Single action with existing tool → fast result ──
    if result.get("result"):
        tool = result.get("tool_name", "?")
        technology = result.get("technology", "?")
        is_bootstrap = tool in ("run_query", "call_api", "read_files")
        tool_label = f"bootstrap:{tool}" if is_bootstrap else tool
        mode_tag = f" {C.BYELLOW}[heuristic]{C.RESET}" if is_heuristic else ""
        _step("✓", "Thinking", f"Using {tool_label}{mode_tag}", done=True)
        _step("✓", "Executing", f"'{tool}' completed", done=True)

        params = {}
        plan = result.get("plan", [])
        if plan:
            params = plan[0].get("params", {})
        entities = memory.auto_catalog(tool, technology, params, result["result"])
        summary = _summarize_result(tool, result["result"])

        prompt_lower = user_input.lower()
        needs_synthesis = any(w in prompt_lower for w in ("explain", "understand", "what does", "what is", "how does", "describe", "tell me about"))
        if needs_synthesis:
            sp = Spinner("Synthesizing", "Generating explanation...")
            sp.start()
            final_goal = result.get("final_goal", user_input)
            answer = await synthesize(user_input, final_goal, {"0": result["result"]}, plan)
            sp.stop()
            _step("✓", "Synthesizing", "Done", done=True)
            print(f"\n{answer}")
            memory.add_turn(user_input, "question", technology, answer[:150], entities, f"1 step: {tool}")
        else:
            print(f"\n{_format_result(result['result'])}")
            memory.add_turn(user_input, intent, technology, summary, entities, f"1 step: {tool}")

        if is_heuristic:
            print(f"\n  {C.BYELLOW}⚠  Heuristic mode{C.RESET} {C.DIM}— LLM is down. This answer used keyword matching, not AI reasoning.{C.RESET}")
        _info(f"({elapsed:.1f}s)")
        return

    if result.get("error"):
        tool = result.get("tool_name", "?")
        _step("✓", "Thinking", f"Found '{tool}'", done=True)
        _error(result["error"])
        _info(f"({elapsed:.1f}s)")
        memory.add_turn(user_input, intent, result.get("technology"), f"Error: {result['error']}")
        return

    # ── Plan execution (multi-step or build needed) ──
    plan = result.get("plan", [])
    final_goal = result.get("final_goal", "")
    technology = result.get("technology", "postgres")
    connection_config = result.get("connection_config", {})
    collected_results = {}
    all_entities = []

    if not plan:
        _error("No plan generated. Try rephrasing your question.")
        memory.add_turn(user_input, intent, technology, "No plan generated")
        return

    # Show the plan with reasoning
    mode_tag = f" {C.BYELLOW}[heuristic]{C.RESET}" if is_heuristic else ""
    _step("✓", "Thinking", f"Plan: {len(plan)} steps{mode_tag}", done=True)
    print()
    _info(f"Goal: {final_goal}")
    for i, step in enumerate(plan):
        is_boot = step.get("is_bootstrap", step["tool"] in ("run_query", "call_api", "read_files"))
        exists_label = "bootstrap" if is_boot else ("exists" if step.get("tool_exists") else "needs building")
        reason = step.get("reason", "")
        print(f"    {C.DIM}{i + 1}.{C.RESET} {step['tool']} {C.DIM}({exists_label}){C.RESET}")
        if reason:
            print(f"       {C.MAGENTA}→{C.RESET} {C.DIM}{reason}{C.RESET}")

    # Check if any tools need building
    tools_to_build = [s for s in plan if not s.get("tool_exists") and not s.get("is_bootstrap")]
    if tools_to_build:
        new_techs = set()
        tech_dir = Path(PROJECT_ROOT / "mcp-tools" / "technologies")
        for s in tools_to_build:
            t = s.get("technology", technology)
            if not (tech_dir / f"{t}.py").exists():
                new_techs.add(t)

        if new_techs:
            for nt in sorted(new_techs):
                print(f"\n  {C.BYELLOW}⚠{C.RESET}  Technology {C.BOLD}'{nt}'{C.RESET} is {C.BCYAN}NEW{C.RESET}")
                print(f"    This will create {C.DIM}mcp-tools/technologies/{nt}.py{C.RESET}")
                try:
                    confirm = input(f"  {C.BOLD}Approve creating {nt} technology? [Y/n] > {C.RESET}").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    _error("Cancelled.")
                    return
                if confirm in ("n", "no"):
                    _error(f"Cancelled — '{nt}' technology not created.")
                    return
                _success(f"Technology '{nt}' approved")

        names = ", ".join(s["tool"] for s in tools_to_build)
        print(f"\n  {C.BYELLOW}⚠{C.RESET}  {len(tools_to_build)} tool(s) need building: {C.BOLD}{names}{C.RESET}")
        try:
            confirm = input(f"  {C.BOLD}Approve building? [Y/n] > {C.RESET}").strip().lower()
        except (EOFError, KeyboardInterrupt):
            _error("Cancelled.")
            return
        if confirm in ("n", "no"):
            _error("Cancelled — no tools built.")
            return

    print()

    # ── Execute steps with ReAct loop ──
    # Phase 1: Execute all initially planned steps
    # Phase 2: Observe results → orchestrator decides if more steps needed → loop

    step_counter = 0  # Global step counter across all iterations
    max_react_iterations = 5  # Safety cap on observe→act loops
    task_id = result.get("task_id", "")

    async def _run_step(step: dict, step_num: int, total: int) -> bool:
        """Execute a single step (existing tool or build new). Returns True if result collected."""
        nonlocal step_counter
        tool_name = step["tool"]
        step_tech = step.get("technology", technology)
        step_conn = connection_config

        if step_tech != technology or not step_conn:
            step_conn = get_connection(step_tech)

        if step.get("tool_exists") or step.get("is_bootstrap"):
            # ── Execute existing/bootstrap tool ──
            is_boot = step.get("is_bootstrap", tool_name in ("run_query", "call_api", "read_files"))
            label = f"bootstrap:{tool_name}" if is_boot else tool_name

            sp = Spinner(f"Step {step_num}/{total}", f"{label}")
            sp.start()
            step_result = await execute_plan_step(step, step_conn, step_tech)
            sp.stop()

            if step_result.get("result"):
                res_str = step_result["result"]
                # Check if the result is actually an error wrapped in JSON
                is_error = False
                try:
                    parsed = json.loads(res_str) if isinstance(res_str, str) else res_str
                    if isinstance(parsed, dict) and "error" in parsed and len(parsed) == 1:
                        is_error = True
                except (json.JSONDecodeError, TypeError):
                    pass

                if is_error:
                    step["status"] = "failed"
                    err_msg = parsed["error"] if isinstance(parsed, dict) else res_str
                    _step("✗", f"Step {step_num}/{total}", f"{label} ✗", done=True, failed=True)
                    _error(f"{err_msg}")
                    memory.record_outcome(task_id=task_id, tool_name=tool_name,
                                          technology=step_tech, action="execute", verdict="fail",
                                          details={"error": str(err_msg)})
                    step_counter += 1
                    return False

                collected_results[str(step_counter)] = res_str
                step["status"] = "done"
                step["result"] = res_str
                _step("✓", f"Step {step_num}/{total}", f"{label} ✓", done=True)

                step_entities = memory.auto_catalog(
                    tool_name, step_tech, step.get("params", {}), res_str
                )
                all_entities.extend(step_entities)
                memory.record_outcome(task_id=task_id, tool_name=tool_name,
                                      technology=step_tech, action="execute", verdict="pass")
                step_counter += 1
                return True
            else:
                step["status"] = "failed"
                err_msg = step_result.get('error', 'unknown error')
                _step("✗", f"Step {step_num}/{total}", f"{label} ✗", done=True, failed=True)
                _error(f"{err_msg}")
                memory.record_outcome(task_id=task_id, tool_name=tool_name,
                                      technology=step_tech, action="execute", verdict="fail",
                                      details={"error": err_msg})
                step_counter += 1
                return False
        else:
            # ── Non-bootstrap technology — use connector + ephemeral code ──
            tech_type = get_technology_type(step_tech)
            user_request = step.get("tool_description") or step.get("reason") or user_input

            # For non-bootstrap types (messaging, server, cloud): connector + ephemeral
            if tech_type not in ("database", "api", "filesystem"):
                _thought(f"Non-bootstrap technology '{step_tech}' — using connector + ephemeral code")

                # Step A: Ensure connector exists
                conn_mgr = get_connector_manager()
                if not conn_mgr.has_connector(step_tech):
                    _step("⟳", f"Step {step_num}/{total}", f"Generating connector for '{step_tech}'...")
                    sp = Spinner(f"Step {step_num}/{total}", f"Building connector for '{step_tech}'")
                    sp.start()
                    conn_result = await generate_connector(step_tech, step_conn)
                    sp.stop()

                    if not conn_result["success"]:
                        # Missing libraries?
                        error_msg = conn_result.get("error", "")
                        if "Missing libraries" in error_msg or "No module named" in error_msg:
                            # Try to extract lib names
                            import re as _re
                            lib_match = _re.search(r"Missing libraries: (.+)", error_msg)
                            if lib_match:
                                libs = [l.strip() for l in lib_match.group(1).split(",")]
                            else:
                                libs = [step_tech.replace("_", "-")]
                            print()
                            print(f"  {C.BYELLOW}⚠{C.RESET}  Missing libraries: {C.BOLD}{', '.join(libs)}{C.RESET}")
                            try:
                                confirm = input(f"  {C.BOLD}Install them? [Y/n] > {C.RESET}").strip().lower()
                            except (EOFError, KeyboardInterrupt):
                                step["status"] = "failed"
                                step_counter += 1
                                return False
                            if confirm not in ("n", "no"):
                                _step("⟳", "Installing", f"pip install {' '.join(libs)}...")
                                try:
                                    proc = subprocess.run(
                                        [sys.executable, "-m", "pip", "install", *libs],
                                        capture_output=True, text=True, timeout=120,
                                    )
                                    if proc.returncode == 0:
                                        _step("✓", "Installed", f"{', '.join(libs)}", done=True)
                                        # Retry connector generation
                                        sp = Spinner(f"Step {step_num}/{total}", "Retrying connector...")
                                        sp.start()
                                        conn_result = await generate_connector(step_tech, step_conn)
                                        sp.stop()
                                    else:
                                        _error(f"pip install failed: {proc.stderr[:200]}")
                                except Exception as e:
                                    _error(f"pip install error: {e}")

                        if not conn_result.get("success"):
                            step["status"] = "failed"
                            _step("✗", f"Step {step_num}/{total}", f"Connector failed ✗", done=True, failed=True)
                            _error(f"{conn_result.get('error', 'unknown')}")
                            step_counter += 1
                            return False

                    _step("✓", f"Step {step_num}/{total}", f"Connector ready for '{step_tech}'", done=True)

                # Step B: Get live client
                client = conn_mgr.get_client(step_tech, step_conn)
                if client is None:
                    step["status"] = "failed"
                    _error(f"Could not connect to '{step_tech}'")
                    step_counter += 1
                    return False

                # Step C: Generate and execute ephemeral code
                sp = Spinner(f"Step {step_num}/{total}", f"Executing on '{step_tech}'")
                sp.start()
                result = await execute_ephemeral_step(user_request, step_tech, step_conn, client)
                sp.stop()

                if "error" in result:
                    # Missing libraries in ephemeral code
                    if "missing_libraries" in result:
                        libs = result["missing_libraries"]
                        print()
                        print(f"  {C.BYELLOW}⚠{C.RESET}  Missing libraries: {C.BOLD}{', '.join(libs)}{C.RESET}")
                        try:
                            confirm = input(f"  {C.BOLD}Install them? [Y/n] > {C.RESET}").strip().lower()
                        except (EOFError, KeyboardInterrupt):
                            step["status"] = "failed"
                            step_counter += 1
                            return False
                        if confirm not in ("n", "no"):
                            proc = subprocess.run(
                                [sys.executable, "-m", "pip", "install", *libs],
                                capture_output=True, text=True, timeout=120,
                            )
                            if proc.returncode == 0:
                                _step("✓", "Installed", f"{', '.join(libs)}", done=True)
                                sp = Spinner(f"Step {step_num}/{total}", "Retrying...")
                                sp.start()
                                result = await execute_ephemeral_step(user_request, step_tech, step_conn, client)
                                sp.stop()

                    if "error" in result:
                        step["status"] = "failed"
                        _step("✗", f"Step {step_num}/{total}", f"ephemeral ✗", done=True, failed=True)
                        _error(f"{result['error']}")
                        step_counter += 1
                        return False

                # Success — offer skill promotion
                ephemeral_code = result.pop("_ephemeral_code", None)
                res_str = json.dumps(result, indent=2, default=str)
                collected_results[str(step_counter)] = res_str
                step["status"] = "done"
                step["result"] = res_str
                _step("✓", f"Step {step_num}/{total}", f"ephemeral:{step_tech} ✓", done=True)
                step_entities = memory.auto_catalog(tool_name, step_tech, step.get("params", {}), res_str)
                all_entities.extend(step_entities)

                # Skill promotion: ask user if they want to save this as a reusable skill
                if ephemeral_code:
                    try:
                        save = input(f"  {C.BCYAN}?{C.RESET} Save as reusable skill? {C.DIM}[y/N]{C.RESET} ").strip().lower()
                    except (EOFError, KeyboardInterrupt):
                        save = "n"
                    if save in ("y", "yes"):
                        sp = Spinner("Promoting", "Extracting skill metadata...")
                        sp.start()
                        promo = await promote_to_skill(
                            technology=step_tech,
                            code=ephemeral_code,
                            user_request=user_request,
                            client_type=type(client).__name__ if client else "",
                        )
                        sp.stop()
                        if promo.get("success"):
                            _success(f"Skill saved: {promo['key']}")
                        else:
                            _warn(f"Skill promotion failed: {promo.get('error', 'unknown')}")

                step_counter += 1
                return True

            # ── Bootstrap type but tool doesn't exist — build permanent tool (legacy) ──
            _thought(f"Bootstrap can't do this — building specialized tool '{tool_name}'")

            build_state = {
                "user_prompt": user_request,
                "task_id": task_id,
                "tool_name": tool_name,
                "technology": step_tech,
                "connection_config": step_conn,
                "attempt": 0,
                "max_attempts": config["general"]["max_test_loops"],
            }

            sp = Spinner(f"Step {step_num}/{total}", f"Building '{tool_name}'")
            sp.start()
            build_result = await build_tool_for_step(step, build_state)
            sp.stop()

            # ── Missing libraries: ask user to install ──
            if build_result.get("test_verdict") == "missing_libraries":
                libs = build_result.get("missing_libraries", [])
                print()
                print(f"  {C.BYELLOW}⚠{C.RESET}  Missing libraries: {C.BOLD}{', '.join(libs)}{C.RESET}")
                print(f"  {C.DIM}The generated tool needs these Python packages to run.{C.RESET}")
                try:
                    confirm = input(f"  {C.BOLD}Install them? [Y/n] > {C.RESET}").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    _error("Cancelled.")
                    step["status"] = "failed"
                    step_counter += 1
                    return False

                if confirm in ("n", "no"):
                    _error(f"Skipped — cannot test '{tool_name}' without {', '.join(libs)}")
                    step["status"] = "failed"
                    step_counter += 1
                    return False

                _step("⟳", "Installing", f"pip install {' '.join(libs)}...")
                try:
                    proc = subprocess.run(
                        [sys.executable, "-m", "pip", "install", *libs],
                        capture_output=True, text=True, timeout=120,
                    )
                    if proc.returncode == 0:
                        _step("✓", "Installed", f"{', '.join(libs)}", done=True)
                    else:
                        _error(f"pip install failed: {proc.stderr[:200]}")
                        step["status"] = "failed"
                        step_counter += 1
                        return False
                except Exception as e:
                    _error(f"pip install error: {e}")
                    step["status"] = "failed"
                    step_counter += 1
                    return False

                _step("⟳", f"Step {step_num}/{total}", f"Retrying '{tool_name}'...")
                build_state["attempt"] = 0
                build_state["failure_reason"] = None
                build_state["failure_details"] = None
                build_result = await build_tool_for_step(step, build_state)

            if build_result.get("test_verdict") == "pass":
                approved = await handle_approval(build_result, memory)
                if approved:
                    sp = Spinner(f"Step {step_num}/{total}", f"Executing '{tool_name}'")
                    sp.start()
                    exec_result = await execute_plan_step(step, step_conn, step_tech)
                    sp.stop()
                    if exec_result.get("result"):
                        res_str = exec_result["result"]
                        is_error = False
                        try:
                            parsed = json.loads(res_str) if isinstance(res_str, str) else res_str
                            if isinstance(parsed, dict) and "error" in parsed and len(parsed) == 1:
                                is_error = True
                        except (json.JSONDecodeError, TypeError):
                            pass

                        if is_error:
                            step["status"] = "failed"
                            _step("✗", f"Step {step_num}/{total}", f"{tool_name} ✗", done=True, failed=True)
                            _error(f"{parsed['error']}")
                            step_counter += 1
                            return False

                        collected_results[str(step_counter)] = res_str
                        step["status"] = "done"
                        step["result"] = res_str
                        _step("✓", f"Step {step_num}/{total}", f"{tool_name} ✓", done=True)
                        step_entities = memory.auto_catalog(tool_name, step_tech, step.get("params", {}), res_str)
                        all_entities.extend(step_entities)
                        step_counter += 1
                        return True
                    else:
                        step["status"] = "failed"
                        _step("✗", f"Step {step_num}/{total}", f"{tool_name} ✗", done=True, failed=True)
                        _error(f"{exec_result.get('error', 'unknown')}")
                        step_counter += 1
                        return False
                else:
                    step["status"] = "skipped"
                    _info(f"Step {step_num}: {tool_name} — skipped (rejected)")
                    step_counter += 1
                    return False
            elif build_result.get("test_verdict") == "rejected":
                step["status"] = "skipped"
                details = build_result.get("failure_details", "")
                _info(f"Step {step_num}: Skipped building '{tool_name}' — {details}")
                step_counter += 1
                return False
            else:
                step["status"] = "failed"
                reason = build_result.get("failure_reason", "unknown")
                details = build_result.get("failure_details", "")
                _error(f"Step {step_num}: Failed to build '{tool_name}' — {reason}: {details}")
                memory.record_outcome(task_id=task_id, tool_name=tool_name,
                                      technology=step_tech, action="build", verdict="fail",
                                      details={"reason": reason})
                step_counter += 1
                return False

    # Phase 1: Execute all initially planned steps
    total_display = len(plan)
    for i, step in enumerate(plan):
        await _run_step(step, i + 1, total_display)

    # Phase 2: ReAct continuation loop
    # After executing planned steps, ask the orchestrator: "is this enough, or do you need more?"
    # Only if LLM is available (not in heuristic-fallback mode) and we have results
    react_iteration = 0
    llm_available = not result.get("llm_error")

    last_react_error = None  # Track repeated errors to prevent loops

    while llm_available and react_iteration < max_react_iterations and collected_results:
        # Build observation from all collected results AND errors
        observation_parts = []
        for key, res_str in collected_results.items():
            truncated = res_str[:1500] if len(res_str) > 1500 else res_str
            observation_parts.append(f"[Step {key} — success] {truncated}")
        # Include failed steps so the LLM knows what didn't work
        for s in plan:
            if s.get("status") == "failed":
                observation_parts.append(f"[{s['tool']} — FAILED] This step failed. Do not retry the same approach.")
        observation = "\n\n".join(observation_parts)

        # Build steps_so_far for the reasoning prompt
        steps_done = [s for s in plan if s.get("status") in ("done", "failed")]

        sp = Spinner("Observing", "Analyzing results...")
        sp.start()
        continuation = await continue_reasoning(
            user_prompt=user_input,
            final_goal=final_goal,
            steps_so_far=steps_done,
            latest_observation=observation,
        )
        sp.stop()

        if continuation is None:
            # LLM unavailable for continuation — fall through to synthesis
            break

        reasoning = continuation.get("reasoning", "")
        if reasoning:
            _thought(reasoning)

        if continuation.get("done"):
            # Orchestrator says we have enough — use its answer directly
            answer = continuation.get("answer", "")
            if answer:
                _step("✓", "Observing", "Got enough info", done=True)
                print(f"\n{answer}")
                elapsed = time.time() - start
                memory.add_turn(
                    user_input, intent, technology, answer[:150],
                    entities=all_entities,
                    plan_summary=f"{len(plan)} steps (ReAct), goal: {final_goal}",
                )
                _info(f"({elapsed:.1f}s)")
                return
            break  # done=True but no answer — fall through to synthesis

        # Not done — orchestrator wants another step
        next_step = continuation.get("next_step")
        if not next_step or not next_step.get("tool"):
            break  # No valid next step — fall through

        _step("✓", "Observing", "Need more info", done=True)

        # Normalize the new step
        new_step = {
            "tool": next_step["tool"],
            "technology": next_step.get("technology", technology),
            "params": next_step.get("params", {}),
            "reason": next_step.get("thought", ""),
            "tool_description": next_step.get("tool_description", ""),
            "is_bootstrap": next_step.get("is_bootstrap", next_step["tool"] in ("run_query", "call_api", "read_files")),
            "needs_building": next_step.get("needs_building", False),
            "tool_exists": next_step.get("is_bootstrap", next_step["tool"] in ("run_query", "call_api", "read_files")),
            "status": "pending",
        }

        # If it's not bootstrap and not marked as needing building, check if it exists
        if not new_step["is_bootstrap"] and not new_step["needs_building"]:
            from agents.orchestrator.tool_finder import find_tool
            found = find_tool(new_step["tool"])
            new_step["tool_exists"] = found is not None
            if not found:
                new_step["needs_building"] = True

        # If needs building, get user approval
        if new_step.get("needs_building"):
            print(f"\n  {C.BYELLOW}⚠{C.RESET}  Agent wants to build: {C.BOLD}{new_step['tool']}{C.RESET}")
            if new_step.get("reason"):
                print(f"    {C.DIM}{new_step['reason']}{C.RESET}")
            try:
                confirm = input(f"  {C.BOLD}Approve? [Y/n] > {C.RESET}").strip().lower()
            except (EOFError, KeyboardInterrupt):
                break
            if confirm in ("n", "no"):
                _info("Skipped — continuing with what we have.")
                break

        plan.append(new_step)
        total_display = len(plan)
        step_num = len(plan)
        print(f"    {C.DIM}{step_num}.{C.RESET} {new_step['tool']} {C.DIM}(ReAct){C.RESET}")
        if new_step.get("reason"):
            print(f"       {C.MAGENTA}→{C.RESET} {C.DIM}{new_step['reason']}{C.RESET}")

        step_ok = await _run_step(new_step, step_num, total_display)
        react_iteration += 1

        # Guard: if the step failed with the same error as last time, stop looping
        if not step_ok:
            err_sig = f"{new_step['tool']}:{new_step.get('technology', '')}"
            if err_sig == last_react_error:
                _info("Same error repeated — stopping iteration.")
                break
            last_react_error = err_sig

    # ── Synthesize answer (for QUESTION intent or when ReAct didn't produce one) ──
    elapsed = time.time() - start

    prompt_lower = user_input.lower()
    needs_synthesis = intent == "question" or any(
        w in prompt_lower for w in ("explain", "understand", "what does", "what is", "how does", "tell me about")
    )

    if needs_synthesis and collected_results:
        sp = Spinner("Synthesizing", "Generating explanation...")
        sp.start()
        answer = await synthesize(user_input, final_goal, collected_results, plan)
        sp.stop()
        _step("✓", "Synthesizing", "Done", done=True)
        print(f"\n{answer}")

        memory.add_turn(
            user_input, "question", technology, answer[:150],
            entities=all_entities,
            plan_summary=f"{len(plan)} steps, goal: {final_goal}",
        )
    elif collected_results:
        for result_str in collected_results.values():
            print(f"\n{_format_result(result_str)}")

        first_result = next(iter(collected_results.values()), "")
        summary = _summarize_result(plan[0]["tool"], first_result)
        memory.add_turn(
            user_input, intent, technology, summary,
            entities=all_entities,
            plan_summary=f"{len(plan)} steps",
        )
    elif not collected_results:
        _error("No results collected. All steps failed or were skipped.")
        memory.add_turn(user_input, intent, technology, "All steps failed")

    if is_heuristic:
        print(f"\n  {C.BYELLOW}⚠  Heuristic mode{C.RESET} {C.DIM}— LLM is down. This answer used keyword matching, not AI reasoning.{C.RESET}")
    _info(f"({elapsed:.1f}s)")


# ── Learning mode ─────────────────────────────────────


TEACH_LOGO = f"""\
  {C.BCYAN}     _|_
    [____]  {C.BYELLOW}🎓{C.RESET}
  {C.BCYAN} /------\\
  | {C.WHITE}[]  []{C.RESET} {C.BCYAN}|
  |  {C.WHITE}....{C.RESET}  {C.BCYAN}|
   \\------/
  {C.DIM}  LEARN MODE{C.RESET}"""


async def _learn_session(topic: str) -> None:
    """Run an isolated teaching session. Separate from main memory."""
    from utils.llm_client import call_llm, LLMError

    print()
    print(TEACH_LOGO)
    print()
    print(f"  {C.BOLD}Teaching: {C.BCYAN}{topic}{C.RESET}")
    print(f"  {C.DIM}Ask questions about {topic}. Type /delearn to exit.{C.RESET}")
    print(f"  {C.DIM}{'─' * 50}{C.RESET}")
    print()

    system_prompt = (
        f"You are a patient, expert teacher. The student wants to learn about: {topic}.\n"
        f"Start by explaining the core principles of {topic} clearly and concisely.\n"
        f"Use simple language, real-world analogies, and practical examples.\n"
        f"Include best practices and common mistakes to avoid.\n"
        f"Format your responses with headers (##), bullet points, and code examples where relevant.\n"
        f"Keep each response focused — teach one concept at a time.\n"
        f"If the student asks to continue, teach the next logical concept."
    )

    # Initial lesson
    spinner = Spinner("Preparing lesson", f"Learning about {topic}...")
    spinner.start()
    try:
        intro = await call_llm(
            system_prompt,
            f"Please teach me the core fundamentals of {topic}. Start with the basics.",
            agent="orchestrator",
        )
        spinner.stop()
        print(f"\n{intro}\n")
    except LLMError as e:
        spinner.stop()
        _error(f"LLM unavailable: {e.reason}")
        return

    # Teaching conversation loop (separate from main memory)
    history = [
        {"role": "user", "content": f"Teach me about {topic}"},
        {"role": "assistant", "content": intro},
    ]

    while True:
        try:
            user_input = input(f"  {C.BCYAN}{C.BOLD}learn >{C.RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not user_input:
            continue

        if user_input.lower() in ("/delearn", "delearn", "/exit", "/quit", "quit"):
            break

        # Append to history
        history.append({"role": "user", "content": user_input})

        # Build context from history (last 10 turns)
        context = "\n\n".join(
            f"{'Student' if h['role'] == 'user' else 'Teacher'}: {h['content']}"
            for h in history[-10:]
        )

        spinner = Spinner("Thinking", "")
        spinner.start()
        try:
            response = await call_llm(
                system_prompt,
                f"Conversation so far:\n{context}\n\nStudent just asked: {user_input}\n\nTeach them:",
                agent="orchestrator",
            )
            spinner.stop()
            print(f"\n{response}\n")
            history.append({"role": "assistant", "content": response})
        except LLMError as e:
            spinner.stop()
            _error(f"LLM error: {e.reason}")

    # Exit learning mode
    print()
    print(f"  {C.BGREEN}✓{C.RESET} Learning session ended. Back to DataClaw.")
    print(f"  {C.DIM}Session had {len(history) // 2} exchanges about {topic}.{C.RESET}")
    print()


async def main() -> None:
    """Async main loop."""
    config = load_config()
    setup_logging(config["general"].get("log_level", "INFO"))

    memory = MemoryStore()

    print(_build_banner())
    print()

    while True:
        try:
            user_input = input(f"  {C.BGREEN}{C.BOLD}>{C.RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n  {C.DIM}see you.{C.RESET}")
            break

        if user_input.lower() in ("quit", "exit", "q", "/quit"):
            print(f"  {C.DIM}see you.{C.RESET}")
            break
        if not user_input:
            continue

        # Handle /learn specially — enters a separate session
        if user_input.lower().startswith("/learn "):
            topic = user_input[7:].strip()
            if topic:
                await _learn_session(topic)
                continue
        if user_input.lower() == "/learn":
            print(f"\n  {C.BRED}Usage: /learn <topic>{C.RESET}")
            print(f"  {C.DIM}Example: /learn sql, /learn kafka, /learn data modeling{C.RESET}\n")
            continue
        if user_input.lower() == "/delearn":
            print(f"  {C.DIM}Not in a learning session. Use /learn <topic> to start one.{C.RESET}")
            continue

        if user_input.startswith("/"):
            handle_command(user_input)
            continue

        try:
            await process_prompt(user_input, config, memory)
        except Exception as e:
            _error(f"Unexpected error: {e}")
            logging.getLogger(__name__).exception("Unhandled error in process_prompt")
        print()


def main_sync() -> None:
    """Synchronous entry point."""
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        # dataclaw init
        if arg == "init":
            from cli.init import run_init
            force = "--force" in sys.argv
            run_init(force=force)
            return
        # dataclaw --help / dataclaw -h
        if arg in ("--help", "-h"):
            print("\n  dataclaw — Autonomous Data Reasoning Agent\n")
            print("  Usage:")
            print("    dataclaw            Start the interactive agent")
            print("    dataclaw init       Create config files at ~/.dataclaw/")
            print("    dataclaw --help     Show this help\n")
            print("  First time? Run: dataclaw init\n")
            return
    asyncio.run(main())


if __name__ == "__main__":
    main_sync()
