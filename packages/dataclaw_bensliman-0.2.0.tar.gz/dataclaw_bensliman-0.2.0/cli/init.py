"""dataclaw init — scaffolds ~/.dataclaw/ with config templates.

Creates the user data directory with all required config files
and subdirectories so DataClaw works after `pip install dataclaw`.
"""

import shutil
import sys
from pathlib import Path

USER_DATA_DIR = Path.home() / ".dataclaw"

CONNECTIONS_TEMPLATE = """\
# DataClaw — Connections Configuration
#
# Define ALL your data sources here. The agent reads this file to understand
# what systems it can connect to and HOW to connect.
#
# Technology types:
#   database   → bootstrap: run_query (SQL via psycopg2, pymysql, sqlite3, etc.)
#   api        → bootstrap: call_api (HTTP requests to REST endpoints)
#   filesystem → bootstrap: read_files (local file access via pathlib)
#   messaging  → agent builds tools from scratch (e.g., kafka-python)
#   server     → agent builds tools from scratch (e.g., paramiko for SSH)
#   cloud      → agent builds tools from scratch or uses call_api
#
# Security: access_level controls what the agent can do
#   read       → read-only queries (default, safe)
#   write      → can modify data (INSERT, UPDATE, DELETE)
#   admin      → full access (DDL, dangerous — requires approval per action)
#
# Use ${VAR_NAME} to reference secrets from .env file (recommended for passwords)

technologies:

  # ── Example: PostgreSQL ──────────────────────────
  # my_postgres:
  #   type: database
  #   driver: psycopg2
  #   access_level: read
  #   connection:
  #     host: localhost
  #     port: 5432
  #     database: mydb
  #     user: ${POSTGRES_USER}
  #     password: ${POSTGRES_PASSWORD}

  # ── Example: MySQL ───────────────────────────────
  # my_mysql:
  #   type: database
  #   driver: pymysql
  #   access_level: read
  #   connection:
  #     host: localhost
  #     port: 3306
  #     database: mydb
  #     user: ${MYSQL_USER}
  #     password: ${MYSQL_PASSWORD}

  # ── Example: SQLite ──────────────────────────────
  # my_sqlite:
  #   type: database
  #   driver: sqlite3
  #   access_level: write
  #   connection:
  #     database: /path/to/my.db

  # ── Example: REST API ────────────────────────────
  # my_api:
  #   type: api
  #   driver: requests
  #   access_level: read
  #   connection:
  #     base_url: https://api.example.com
  #     api_key: ${MY_API_KEY}

  # ── Example: Local Files ─────────────────────────
  # my_files:
  #   type: filesystem
  #   driver: pathlib
  #   access_level: read
  #   connection:
  #     project_dir: /path/to/project

  # ── Example: Kafka ───────────────────────────────
  # my_kafka:
  #   type: messaging
  #   driver: kafka-python
  #   access_level: read
  #   connection:
  #     bootstrap_servers: localhost:9092

  # ── Example: SSH Server ──────────────────────────
  # my_server:
  #   type: server
  #   driver: paramiko
  #   access_level: read
  #   connection:
  #     host: 192.168.1.100
  #     port: 22
  #     user: ${SSH_USER}
  #     password: ${SSH_PASSWORD}
"""

SETTINGS_TEMPLATE = """\
# DataClaw — Settings Configuration
#
# Configure LLM providers, sandbox, and runtime parameters.
# Uncomment ONE of the LLM configurations below (local or API).

general:
  max_test_loops: 5
  timeout_per_test_s: 30
  auto_commit_on_pass: true
  log_level: INFO

# ─────────────────────────────────────────────────────────
# LLM Configuration — pick ONE option and uncomment it
# ─────────────────────────────────────────────────────────

# ── OPTION 1: Local LLM via Ollama ─────────────────────
# Install Ollama: https://ollama.com
# Then: ollama pull llama3.1  (or any model you prefer)
#
# model:
#   orchestrator:
#     provider: ollama
#     model: llama3.1
#     temperature: 0.2
#   builder:
#     provider: ollama
#     model: llama3.1
#     temperature: 0.2

# ── OPTION 2: API-based LLM (OpenAI, Anthropic, etc.) ──
# Set your API key in .env file, then reference it here.
# Works with any OpenAI-compatible endpoint (OpenAI, Azure, vLLM, LiteLLM, etc.)
#
# model:
#   orchestrator:
#     provider: openai          # or: anthropic
#     model: gpt-4o-mini        # or: claude-sonnet-4-20250514, etc.
#     base_url: https://api.openai.com/v1  # optional, for custom endpoints
#     api_key_env: OPENAI_API_KEY           # env var name from .env
#     temperature: 0.2
#   builder:
#     provider: openai
#     model: gpt-4o-mini
#     base_url: https://api.openai.com/v1
#     api_key_env: OPENAI_API_KEY
#     temperature: 0.2

# Runtime parameters (all configurable via /config command)
runtime:
  llm_timeout_s: 120
  max_clarify_depth: 3
  max_build_attempts: 3
  builds_remaining: 3
  steps_remaining: 5
  max_observation_length: 3000
  max_session_turns: 20
  default_query_limit: 100
  max_files_list: 50
  max_file_size_bytes: 1000000
  max_description_length: 200

# Docker sandbox for write/admin tools
sandbox:
  image: python:3.11-slim
  memory_limit: 512m
  network_mode: none
"""

ENV_TEMPLATE = """\
# DataClaw — Secrets
# Store credentials here. This file is NOT committed to git.
# Reference values in connections.yaml and settings.yaml with ${VAR_NAME}

# Database credentials
# POSTGRES_USER=myuser
# POSTGRES_PASSWORD=mypassword
# MYSQL_USER=myuser
# MYSQL_PASSWORD=mypassword

# API keys
# OPENAI_API_KEY=sk-...
# ANTHROPIC_API_KEY=sk-ant-...
# MY_API_KEY=...

# Server credentials
# SSH_USER=myuser
# SSH_PASSWORD=mypassword
"""


def run_init(force: bool = False) -> None:
    """Scaffold ~/.dataclaw/ with config templates."""
    if USER_DATA_DIR.exists() and not force:
        print(f"\n  ~/.dataclaw/ already exists at: {USER_DATA_DIR}")
        print("  Use --force to overwrite config templates.\n")
        # Still create missing subdirectories
        _ensure_subdirs()
        print("  Checked subdirectories — all present.")
        return

    print(f"\n  Initializing DataClaw at: {USER_DATA_DIR}\n")

    # Create main directory
    USER_DATA_DIR.mkdir(parents=True, exist_ok=True)

    # Write config templates
    _write_if_missing(USER_DATA_DIR / "connections.yaml", CONNECTIONS_TEMPLATE, force)
    _write_if_missing(USER_DATA_DIR / "settings.yaml", SETTINGS_TEMPLATE, force)
    _write_if_missing(USER_DATA_DIR / ".env", ENV_TEMPLATE, force)

    # Create subdirectories
    _ensure_subdirs()

    print("\n  Done! Next steps:")
    print("  1. Edit ~/.dataclaw/connections.yaml  — add your data sources")
    print("  2. Edit ~/.dataclaw/settings.yaml     — configure your LLM")
    print("  3. Edit ~/.dataclaw/.env              — add secrets/API keys")
    print("  4. Run: dataclaw")
    print()


def _write_if_missing(path: Path, content: str, force: bool = False) -> None:
    """Write a config file, skip if exists (unless force)."""
    if path.exists() and not force:
        print(f"  [skip] {path.name} (already exists)")
        return
    path.write_text(content, encoding="utf-8")
    action = "overwrote" if path.exists() else "created"
    print(f"  [{'overwrote' if force and path.exists() else 'created'}] {path.name}")


def _ensure_subdirs() -> None:
    """Create required subdirectories."""
    subdirs = [
        "mcp-tools/technologies",
        "skills",
        "connectors",
        "logs",
    ]
    for sub in subdirs:
        d = USER_DATA_DIR / sub
        d.mkdir(parents=True, exist_ok=True)

    # Ensure registry.json exists
    registry = USER_DATA_DIR / "mcp-tools" / "registry.json"
    if not registry.exists():
        registry.write_text("{}", encoding="utf-8")

    # Ensure _bootstrap.py is available in technologies dir
    tech_dir = USER_DATA_DIR / "mcp-tools" / "technologies"
    bootstrap_src = Path(__file__).parent.parent / "mcp-tools" / "technologies" / "_bootstrap.py"
    bootstrap_dst = tech_dir / "_bootstrap.py"
    if bootstrap_src.exists() and not bootstrap_dst.exists():
        shutil.copy2(bootstrap_src, bootstrap_dst)

    # Ensure __init__.py files
    for pkg_dir in [
        USER_DATA_DIR / "mcp-tools",
        USER_DATA_DIR / "mcp-tools" / "technologies",
    ]:
        init = pkg_dir / "__init__.py"
        if not init.exists():
            init.write_text("", encoding="utf-8")


def main() -> None:
    """CLI entry point for `dataclaw-init`."""
    force = "--force" in sys.argv
    run_init(force=force)


if __name__ == "__main__":
    main()
