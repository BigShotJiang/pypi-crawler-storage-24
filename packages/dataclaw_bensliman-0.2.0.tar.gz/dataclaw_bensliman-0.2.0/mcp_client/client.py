"""MCP Client — manages external MCP server processes and tool execution.

Supports stdio transport (subprocess) for local MCP servers.
MCP servers are configured in connections.yaml under mcp_server: key.

Each server is started as a subprocess, tools are discovered via JSON-RPC,
and tool calls are forwarded to the server.

Priority: MCP server tools > bootstrap tools > ephemeral code
"""

import json
import logging
import subprocess
import sys
import threading
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class MCPServer:
    """Represents a running MCP server process."""

    def __init__(self, technology: str, config: dict):
        self.technology = technology
        self.config = config
        self.process: subprocess.Popen | None = None
        self.tools: list[dict] = []
        self._lock = threading.Lock()
        self._request_id = 0

    def start(self) -> bool:
        """Start the MCP server process."""
        command = self.config.get("command", "")
        if not command:
            logger.error(f"[MCP] No command configured for {self.technology}")
            return False

        env = dict(self.config.get("env", {}))
        # Resolve env vars from os.environ
        import os
        resolved_env = {**os.environ}
        for k, v in env.items():
            if isinstance(v, str) and v.startswith("${") and v.endswith("}"):
                var_name = v[2:-1]
                resolved_env[k] = os.environ.get(var_name, "")
            else:
                resolved_env[k] = str(v)

        try:
            # Parse command into parts
            parts = command.split()
            self.process = subprocess.Popen(
                parts,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=resolved_env,
                text=True,
            )
            logger.info(f"[MCP] Started server for {self.technology}: PID {self.process.pid}")
            return True
        except Exception as e:
            logger.error(f"[MCP] Failed to start server for {self.technology}: {e}")
            return False

    def stop(self) -> None:
        """Stop the MCP server process."""
        if self.process:
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
            except Exception:
                self.process.kill()
            self.process = None
            logger.info(f"[MCP] Stopped server for {self.technology}")

    def discover_tools(self) -> list[dict]:
        """Discover available tools via JSON-RPC tools/list."""
        response = self._send_request("tools/list", {})
        if response and "result" in response:
            tools = response["result"].get("tools", [])
            self.tools = tools
            logger.info(f"[MCP] Discovered {len(tools)} tools from {self.technology}")
            return tools
        return []

    def call_tool(self, tool_name: str, arguments: dict) -> dict:
        """Call a tool on the MCP server."""
        response = self._send_request("tools/call", {
            "name": tool_name,
            "arguments": arguments,
        })
        if response is None:
            return {"error": f"MCP server for {self.technology} did not respond"}

        if "error" in response:
            return {"error": f"MCP error: {response['error']}"}

        result = response.get("result", {})
        # MCP returns content array — extract text
        content = result.get("content", [])
        texts = [c.get("text", "") for c in content if c.get("type") == "text"]
        if texts:
            # Try to parse as JSON
            for text in texts:
                try:
                    return json.loads(text)
                except json.JSONDecodeError:
                    pass
            return {"result": "\n".join(texts)}

        return result

    def is_alive(self) -> bool:
        """Check if the server process is still running."""
        return self.process is not None and self.process.poll() is None

    def _send_request(self, method: str, params: dict) -> dict | None:
        """Send a JSON-RPC request to the MCP server via stdio."""
        if not self.is_alive():
            return None

        with self._lock:
            self._request_id += 1
            request = {
                "jsonrpc": "2.0",
                "id": self._request_id,
                "method": method,
                "params": params,
            }

            try:
                request_str = json.dumps(request) + "\n"
                self.process.stdin.write(request_str)
                self.process.stdin.flush()

                # Read response line
                response_line = self.process.stdout.readline()
                if not response_line:
                    return None

                return json.loads(response_line.strip())
            except Exception as e:
                logger.error(f"[MCP] Communication error with {self.technology}: {e}")
                return None


class MCPManager:
    """Manages all MCP server connections."""

    def __init__(self):
        self._servers: dict[str, MCPServer] = {}
        self._lock = threading.Lock()

    def register_server(self, technology: str, mcp_config: dict) -> bool:
        """Register and start an MCP server for a technology.

        Args:
            technology: Technology name
            mcp_config: MCP server config (command, env, etc.)
        Returns:
            True if server started successfully
        """
        with self._lock:
            if technology in self._servers and self._servers[technology].is_alive():
                return True

            server = MCPServer(technology, mcp_config)
            if server.start():
                # Discover tools
                server.discover_tools()
                self._servers[technology] = server
                return True
            return False

    def get_server(self, technology: str) -> MCPServer | None:
        """Get a running MCP server for a technology."""
        server = self._servers.get(technology)
        if server and server.is_alive():
            return server
        return None

    def get_all_tools(self) -> dict[str, list[dict]]:
        """Get all discovered tools, grouped by technology.

        Returns:
            Dict mapping technology name to list of tool metadata
        """
        all_tools = {}
        for tech, server in self._servers.items():
            if server.is_alive() and server.tools:
                all_tools[tech] = [
                    {
                        "name": f"{tech}.{t.get('name', '?')}",
                        "description": t.get("description", ""),
                        "input_schema": t.get("inputSchema", {}),
                        "source": "mcp",
                        "technology": tech,
                    }
                    for t in server.tools
                ]
        return all_tools

    def call_tool(self, technology: str, tool_name: str, arguments: dict) -> dict:
        """Call a tool on a specific MCP server.

        Args:
            technology: Technology name
            tool_name: Tool name (without technology prefix)
            arguments: Tool arguments
        Returns:
            Tool result dict
        """
        server = self.get_server(technology)
        if server is None:
            return {"error": f"No MCP server running for {technology}"}
        return server.call_tool(tool_name, arguments)

    def has_server(self, technology: str) -> bool:
        """Check if a technology has an MCP server configured and running."""
        server = self._servers.get(technology)
        return server is not None and server.is_alive()

    def shutdown(self) -> None:
        """Stop all MCP servers."""
        with self._lock:
            for tech, server in self._servers.items():
                server.stop()
            self._servers.clear()
            logger.info("[MCP] All servers stopped")

    def auto_discover(self) -> int:
        """Auto-discover and start MCP servers from connections.yaml.

        Scans all connections for mcp_server: config and starts them.
        Returns number of servers started.
        """
        from utils.connections import load_all_connections

        all_conns = load_all_connections()
        started = 0
        for tech, config in all_conns.items():
            mcp_config = config.get("mcp_server")
            if mcp_config and isinstance(mcp_config, dict):
                if self.register_server(tech, mcp_config):
                    started += 1
                    logger.info(f"[MCP] Auto-started server for {tech}")
        return started


# ── Singleton ─────────────────────────────────────────

_mcp_manager: MCPManager | None = None


def get_mcp_manager() -> MCPManager:
    """Get the global MCPManager singleton."""
    global _mcp_manager
    if _mcp_manager is None:
        _mcp_manager = MCPManager()
    return _mcp_manager
