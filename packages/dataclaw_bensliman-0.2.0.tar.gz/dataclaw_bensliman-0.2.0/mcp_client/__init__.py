"""MCP client — discovers and calls tools from external MCP servers.

Supports stdio transport (subprocess) for local MCP servers.
MCP servers are configured in connections.yaml under mcp_server key.
"""
