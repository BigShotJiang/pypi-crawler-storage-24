"""Unified memory interface — single access point for all memory tiers.

Three tiers:
  1. Session (in-memory) — conversation turns within current CLI session
  2. Catalog (SQLite)   — persistent knowledge about discovered entities
  3. Episodic (SQLite)  — persistent build/test outcomes for learning

All agents and the CLI access memory through this class.
"""

import json
import logging
from typing import Optional

from memory.catalog import DataCatalog
from memory.session import SessionMemory

logger = logging.getLogger(__name__)


# ── Auto-cataloging: extract entities from tool results ──


def _extract_entities_from_result(
    tool_name: str, technology: str, params: dict, result_str: str
) -> list[tuple[str, str, list, str]]:
    """Parse a tool result and return entities to catalog.

    Fully generic: scans the result dict for any key whose value is a list
    of strings or dicts with a "name" key. The key name becomes the entity
    type (singularized). No hardcoded tool names — works for any technology.

    Returns list of (technology, entity_type, items, parent) tuples.
    """
    try:
        result = json.loads(result_str) if isinstance(result_str, str) else result_str
    except (json.JSONDecodeError, TypeError):
        return []

    if not isinstance(result, dict) or "error" in result:
        return []

    # Build parent from params context (schema, table, etc.)
    parent = _infer_parent(params)

    extractions = []
    # Skip keys that are metadata, not entity lists
    skip_keys = {"query", "row_count", "error", "status", "message", "count"}

    for key, value in result.items():
        if key in skip_keys:
            continue
        if not isinstance(value, list) or not value:
            continue

        # Check if list contains entity-like items (strings or dicts with "name")
        first = value[0]
        if isinstance(first, str):
            entity_type = _singularize(key)
            extractions.append((technology, entity_type, value, parent))
        elif isinstance(first, dict) and ("name" in first or len(first) <= 6):
            # Dicts with "name" key, or small dicts (likely entity records)
            entity_type = _singularize(key)
            extractions.append((technology, entity_type, value, parent))

    return extractions


def _singularize(key: str) -> str:
    """Best-effort singularization of a key name.

    'schemas' -> 'schema', 'tables' -> 'table', 'entries' -> 'entry', etc.
    """
    if key.endswith("ies"):
        return key[:-3] + "y"
    if key.endswith("ses"):
        return key[:-2]
    if key.endswith("s") and not key.endswith("ss"):
        return key[:-1]
    return key


def _infer_parent(params: dict) -> str:
    """Build a parent string from tool params.

    Looks for hierarchical keys like schema, table, database, etc.
    and chains them: 'schema.table' or just 'schema'.
    """
    parts = []
    for key in ("database", "schema", "table", "model", "dag"):
        val = params.get(key, "")
        if val:
            parts.append(str(val))
    return ".".join(parts)


class MemoryStore:
    """Single access point for all three memory tiers.

    Usage:
        memory = MemoryStore()

        # Session: track conversation
        memory.add_turn(prompt, intent, technology, summary, entities)

        # Catalog: auto-populate from tool results
        memory.auto_catalog(tool_name, technology, params, result_str)

        # Context: get everything the orchestrator needs
        context = memory.get_planning_context(user_prompt)

        # Outcomes: record build/test results
        memory.record_outcome(task_id, tool_name, technology, action, verdict)
    """

    def __init__(self) -> None:
        self.session = SessionMemory()
        self.catalog = DataCatalog()
        logger.info("MemoryStore initialized (session + catalog)")

    # ── Session tier ────────────────────────────────────

    def add_turn(
        self,
        prompt: str,
        intent: str,
        technology: str | None,
        result_summary: str,
        entities: list[str] | None = None,
        plan_summary: str | None = None,
    ) -> None:
        """Record a completed conversation turn in session memory.

        Args:
            prompt: What the user asked.
            intent: Classified intent.
            technology: Primary technology used.
            result_summary: Short summary of what happened.
            entities: Entity names discovered or referenced.
            plan_summary: Short plan description.
        """
        self.session.add_turn(prompt, intent, technology, result_summary, entities, plan_summary)

    # ── Catalog tier ────────────────────────────────────

    def auto_catalog(
        self,
        tool_name: str,
        technology: str,
        params: dict,
        result_str: str,
    ) -> list[str]:
        """Extract entities from a tool result and store in the catalog.

        Called by the CLI after each successful tool execution. Returns
        the list of entity names that were cataloged (useful for session tracking).

        Args:
            tool_name: Name of the tool that produced the result.
            technology: Technology the tool belongs to.
            params: Parameters passed to the tool.
            result_str: JSON string of the tool result.
        Returns:
            List of entity names that were stored.
        """
        extractions = _extract_entities_from_result(tool_name, technology, params, result_str)
        all_names = []

        for tech, entity_type, items, parent in extractions:
            self.catalog.store_entities_batch(tech, entity_type, items, parent)
            for item in items:
                if isinstance(item, dict):
                    all_names.append(item.get("name", str(item)))
                else:
                    all_names.append(str(item))
            logger.info(f"Cataloged {len(items)} {entity_type}(s) for {tech}")

        return all_names

    # ── Context for orchestrator ────────────────────────

    def get_planning_context(self, current_prompt: str) -> dict:
        """Build the complete memory context for the orchestrator.

        This is the main integration point. The orchestrator receives this
        dict and the planning prompt template injects it.

        Args:
            current_prompt: The user's current prompt.
        Returns:
            Dict with:
                conversation_history: formatted recent turns
                entity_matches: entities mentioned in current prompt
                entity_matches_formatted: formatted string for prompt
                catalog_summary: overview of all known entities
                active_technology: tech from last relevant turn
                recent_entities: entities from recent turns
                failure_patterns: recent failures for learning
        """
        # Session context
        conversation_history = self.session.get_recent_context()
        active_technology = self.session.get_active_technology()
        recent_entities = self.session.get_recent_entities()

        # Catalog: find entities mentioned in the current prompt
        entity_matches = self.catalog.find_mentioned_entities(current_prompt)
        entity_matches_formatted = self.catalog.format_entity_matches(entity_matches)

        # Catalog: summary of everything known
        catalog_summary = self.catalog.get_context_summary()

        # Episodic: recent failure patterns
        failure_patterns = ""
        if active_technology:
            failure_patterns = self.catalog.get_failure_patterns(active_technology)

        return {
            "conversation_history": conversation_history,
            "entity_matches": entity_matches,
            "entity_matches_formatted": entity_matches_formatted,
            "catalog_summary": catalog_summary,
            "active_technology": active_technology,
            "recent_entities": recent_entities,
            "failure_patterns": failure_patterns,
        }

    # ── Outcome tracking ────────────────────────────────

    def record_outcome(
        self,
        task_id: str,
        tool_name: str,
        technology: str,
        action: str,
        verdict: str,
        details: dict | None = None,
    ) -> None:
        """Record a build/test/execution outcome for episodic learning.

        Args:
            task_id: Task identifier.
            tool_name: Tool name.
            technology: Technology.
            action: "build", "test", or "execute".
            verdict: "pass", "fail", or "error".
            details: Optional extra context.
        """
        self.catalog.record_outcome(task_id, tool_name, technology, action, verdict, details)
