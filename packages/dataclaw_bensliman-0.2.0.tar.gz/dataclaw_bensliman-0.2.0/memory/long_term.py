"""Long-term memory — patterns and success rates via ChromaDB.

Stores vectorized patterns from past tool builds so the system can
learn from successful approaches and avoid repeating failures.
"""

import logging
from typing import Optional

logger = logging.getLogger(__name__)


class LongTermMemory:
    """ChromaDB-backed vector store for patterns and success rates."""

    def __init__(self, collection_name: str = "dataclaw_patterns") -> None:
        self._collection_name = collection_name
        self._client = None
        self._collection = None

    async def _ensure_connected(self) -> None:
        """Lazily connect to ChromaDB on first use."""
        if self._client is not None:
            return
        try:
            import chromadb

            self._client = chromadb.Client()
            self._collection = self._client.get_or_create_collection(
                name=self._collection_name
            )
            logger.info("Long-term: connected to ChromaDB")
        except ImportError:
            logger.warning("Long-term: chromadb not installed, operating in no-op mode")
        except Exception as e:
            logger.warning(f"Long-term: failed to connect to ChromaDB: {e}")

    async def store_pattern(
        self, technology: str, pattern: str, success: bool
    ) -> None:
        """Store a build/test pattern with its outcome.

        Args:
            technology: The technology this pattern applies to (e.g., postgres)
            pattern: Description of the approach used
            success: Whether the approach succeeded
        """
        await self._ensure_connected()
        if self._collection is None:
            return

        import uuid

        doc_id = str(uuid.uuid4())
        self._collection.add(
            documents=[pattern],
            metadatas=[{"technology": technology, "success": success}],
            ids=[doc_id],
        )
        logger.debug(f"Long-term: stored pattern for {technology} (success={success})")

    async def find_similar_patterns(
        self, query: str, n: int = 5, technology: Optional[str] = None
    ) -> list[dict]:
        """Find patterns similar to the query.

        Args:
            query: The search query to match against stored patterns
            n: Maximum number of results to return
            technology: Optional filter by technology
        Returns:
            List of matching patterns with metadata
        """
        await self._ensure_connected()
        if self._collection is None:
            return []

        where_filter = {"technology": technology} if technology else None
        results = self._collection.query(
            query_texts=[query],
            n_results=n,
            where=where_filter,
        )

        patterns = []
        if results and results["documents"]:
            for doc, metadata in zip(
                results["documents"][0], results["metadatas"][0]
            ):
                patterns.append({"pattern": doc, **metadata})
        return patterns
