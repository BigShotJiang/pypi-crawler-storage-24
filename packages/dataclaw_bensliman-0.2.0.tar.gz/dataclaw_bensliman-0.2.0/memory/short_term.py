"""Short-term memory — current task state.

Stores in-memory task data for the duration of a single run.
Uses a simple dict backend.
"""

import logging
from typing import Optional

logger = logging.getLogger(__name__)


class ShortTermMemory:
    """In-memory key-value store for current task state."""

    def __init__(self) -> None:
        self._store: dict[str, dict] = {}

    def set(self, task_id: str, data: dict) -> None:
        """Store or update task state."""
        self._store[task_id] = data
        logger.debug(f"Short-term: stored task {task_id}")

    def get(self, task_id: str) -> Optional[dict]:
        """Retrieve task state, or None if not found."""
        return self._store.get(task_id)

    def update(self, task_id: str, updates: dict) -> None:
        """Merge updates into existing task state."""
        if task_id in self._store:
            self._store[task_id].update(updates)
            logger.debug(f"Short-term: updated task {task_id}")
        else:
            self._store[task_id] = updates
            logger.debug(f"Short-term: created task {task_id} via update")

    def delete(self, task_id: str) -> None:
        """Remove a task from memory."""
        self._store.pop(task_id, None)
        logger.debug(f"Short-term: deleted task {task_id}")

    def clear(self) -> None:
        """Clear all task state."""
        self._store.clear()
        logger.debug("Short-term: cleared all tasks")
