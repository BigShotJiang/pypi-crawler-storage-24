"""Episodic memory — past build/test outcomes.

Stores structured records of each build/test cycle so agents
can reference what happened in previous attempts.
"""

import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class EpisodicMemory:
    """In-memory store for past build/test outcomes."""

    def __init__(self) -> None:
        self._outcomes: list[dict] = []

    def record_outcome(self, task_id: str, outcome: dict) -> None:
        """Record a build/test outcome.

        Args:
            task_id: The task this outcome belongs to
            outcome: Structured outcome data (verdict, failure_reason, etc.)
        """
        record = {
            "task_id": task_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **outcome,
        }
        self._outcomes.append(record)
        logger.debug(f"Episodic: recorded outcome for task {task_id}")

    def get_outcomes_for_task(self, task_id: str) -> list[dict]:
        """Get all outcomes for a specific task.

        Args:
            task_id: The task to look up
        Returns:
            List of outcomes in chronological order
        """
        return [o for o in self._outcomes if o["task_id"] == task_id]

    def get_outcomes_for_technology(
        self, technology: str, limit: int = 10
    ) -> list[dict]:
        """Get recent outcomes for a specific technology.

        Args:
            technology: The technology to filter by (e.g., postgres)
            limit: Maximum number of outcomes to return
        Returns:
            List of most recent outcomes
        """
        filtered = [
            o for o in self._outcomes if o.get("technology") == technology
        ]
        return filtered[-limit:]

    def get_recent(self, limit: int = 20) -> list[dict]:
        """Get the most recent outcomes across all technologies.

        Args:
            limit: Maximum number of outcomes to return
        Returns:
            List of most recent outcomes
        """
        return self._outcomes[-limit:]

    def clear(self) -> None:
        """Clear all recorded outcomes."""
        self._outcomes.clear()
        logger.debug("Episodic: cleared all outcomes")
