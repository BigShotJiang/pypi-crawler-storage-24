"""Session memory — conversation context within a single CLI session.

Tracks recent turns, active technology context, and entities discussed.
Dies when the CLI exits. This is what gives the agent continuity
between consecutive user prompts.
"""

import logging
from datetime import datetime
from typing import Optional

from utils.constants import MAX_SESSION_TURNS

logger = logging.getLogger(__name__)


class SessionMemory:
    """In-memory conversation history for the current session.

    Stores the last N turns with structured metadata so the orchestrator
    can understand what the user has been asking and what was discovered.
    """

    def __init__(self, max_turns: int = MAX_SESSION_TURNS) -> None:
        self.turns: list[dict] = []
        self.max_turns = max_turns

    def add_turn(
        self,
        prompt: str,
        intent: str,
        technology: str | None,
        result_summary: str,
        entities: list[str] | None = None,
        plan_summary: str | None = None,
    ) -> None:
        """Record a completed conversation turn.

        Args:
            prompt: What the user asked.
            intent: Classified intent (action, question, greeting, help).
            technology: Primary technology used in this turn.
            result_summary: Short human-readable summary of the result.
            entities: Entity names discovered or referenced in this turn.
            plan_summary: Short description of the plan executed.
        """
        turn = {
            "prompt": prompt,
            "intent": intent,
            "technology": technology,
            "summary": result_summary,
            "entities": entities or [],
            "plan_summary": plan_summary,
            "timestamp": datetime.now().isoformat(),
        }
        self.turns.append(turn)

        # Trim old turns
        if len(self.turns) > self.max_turns:
            self.turns = self.turns[-self.max_turns:]

        logger.debug(f"Session: recorded turn (total: {len(self.turns)})")

    def get_recent_context(self, n: int = 5) -> str:
        """Return formatted recent turns for injection into the planning prompt.

        Args:
            n: Number of recent turns to include.
        Returns:
            Multi-line string summarizing recent conversation, or empty string.
        """
        if not self.turns:
            return ""

        recent = self.turns[-n:]
        lines = []
        for i, t in enumerate(recent, 1):
            tech_tag = f" [technology: {t['technology']}]" if t.get("technology") else ""
            entities_tag = ""
            if t.get("entities"):
                entities_tag = f" (entities: {', '.join(t['entities'][:10])})"
            lines.append(
                f"- User: \"{t['prompt']}\" -> {t['summary']}{tech_tag}{entities_tag}"
            )
        return "\n".join(lines)

    def get_active_technology(self) -> str | None:
        """Return the technology from the most recent non-greeting turn.

        Returns:
            Technology string or None if no relevant turns exist.
        """
        for turn in reversed(self.turns):
            if turn.get("technology") and turn["intent"] not in ("greeting", "help"):
                return turn["technology"]
        return None

    def get_recent_entities(self, n: int = 5) -> list[str]:
        """Return all entity names from the last N turns.

        Args:
            n: Number of recent turns to scan.
        Returns:
            Deduplicated list of entity names.
        """
        seen = set()
        entities = []
        for turn in reversed(self.turns[-n:]):
            for e in turn.get("entities", []):
                if e not in seen:
                    seen.add(e)
                    entities.append(e)
        return entities

    def clear(self) -> None:
        """Clear all session memory."""
        self.turns.clear()
        logger.debug("Session: cleared")
