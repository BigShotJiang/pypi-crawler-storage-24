"""Data catalog — persistent knowledge about the data landscape.

SQLite-backed store for entities the agent has discovered: schemas, tables,
columns, dbt models, DAGs, etc. Auto-populated as the agent executes tools.
Shared across sessions — survives CLI restarts.

This is NOT "memory" in the traditional sense. It's the agent's understanding
of the world it operates in. Structured, queryable, and auto-growing.
"""

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

from utils.paths import get_catalog_path
DEFAULT_DB_PATH = get_catalog_path()


class DataCatalog:
    """Persistent SQLite-backed data catalog.

    Two tables:
    - entities: discovered data entities (schemas, tables, columns, dbt_models, dags)
    - outcomes: build/test outcomes for tools (episodic learning)
    """

    def __init__(self, db_path: Path | str | None = None) -> None:
        self.db_path = str(db_path or DEFAULT_DB_PATH)
        self._persistent_conn = None
        # For :memory: databases, keep a single persistent connection
        # (each sqlite3.connect(":memory:") creates a separate database)
        if self.db_path == ":memory:":
            self._persistent_conn = sqlite3.connect(":memory:")
        self._init_db()
        logger.info(f"DataCatalog initialized at {self.db_path}")

    def _connect(self):
        """Return a connection — reuses persistent conn for :memory: databases."""
        if self._persistent_conn is not None:
            return self._persistent_conn
        return sqlite3.connect(self.db_path)

    def _init_db(self) -> None:
        """Create tables if they don't exist."""
        with self._connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS entities (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    technology TEXT NOT NULL,
                    entity_type TEXT NOT NULL,
                    name TEXT NOT NULL,
                    parent TEXT DEFAULT '',
                    metadata TEXT,
                    discovered_at TEXT NOT NULL,
                    last_seen TEXT NOT NULL,
                    UNIQUE(technology, entity_type, name, parent)
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS outcomes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id TEXT,
                    tool_name TEXT NOT NULL,
                    technology TEXT NOT NULL,
                    action TEXT NOT NULL,
                    verdict TEXT,
                    details TEXT,
                    created_at TEXT NOT NULL
                )
            """)
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_entities_name ON entities(name)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_entities_tech ON entities(technology, entity_type)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_outcomes_tech ON outcomes(technology, created_at)"
            )

    # ── Entity storage ──────────────────────────────────

    def store_entity(
        self,
        technology: str,
        entity_type: str,
        name: str,
        parent: str = "",
        metadata: dict | None = None,
    ) -> None:
        """Store or update a single entity.

        Args:
            technology: e.g. "postgres", "dbt", "airflow"
            entity_type: e.g. "schema", "table", "column", "dbt_model", "dag"
            name: Entity name
            parent: Parent entity (e.g. schema name for a table)
            metadata: Extra info as a dict (stored as JSON)
        """
        now = datetime.now().isoformat()
        meta_json = json.dumps(metadata) if metadata else None
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO entities (technology, entity_type, name, parent, metadata, discovered_at, last_seen)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(technology, entity_type, name, parent)
                DO UPDATE SET metadata=excluded.metadata, last_seen=excluded.last_seen
            """, (technology, entity_type, name, parent or "", meta_json, now, now))

    def store_entities_batch(
        self,
        technology: str,
        entity_type: str,
        items: list,
        parent: str = "",
    ) -> None:
        """Store multiple entities at once.

        Args:
            technology: Technology name.
            entity_type: Entity type for all items.
            items: List of strings (names) or dicts (with "name" key + extra fields as metadata).
            parent: Parent entity for all items.
        """
        for item in items:
            if isinstance(item, dict):
                name = item.get("name", str(item))
                meta = {k: v for k, v in item.items() if k != "name"}
                self.store_entity(technology, entity_type, name, parent, meta if meta else None)
            else:
                self.store_entity(technology, entity_type, str(item), parent)

    # ── Entity lookup ───────────────────────────────────

    def lookup(self, name: str) -> list[dict]:
        """Search for entities matching a name (fuzzy, case-insensitive).

        Args:
            name: Entity name to search for.
        Returns:
            List of matching entity dicts, most recently seen first.
        """
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("""
                SELECT * FROM entities
                WHERE LOWER(name) = LOWER(?) OR LOWER(name) LIKE LOWER(?)
                ORDER BY last_seen DESC
                LIMIT 20
            """, (name, f"%{name}%")).fetchall()
            return [dict(r) for r in rows]

    def lookup_exact(self, name: str, technology: str | None = None) -> list[dict]:
        """Exact name match, optionally filtered by technology.

        Args:
            name: Exact entity name.
            technology: Optional technology filter.
        Returns:
            Matching entities.
        """
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            if technology:
                rows = conn.execute(
                    "SELECT * FROM entities WHERE name = ? AND technology = ?",
                    (name, technology)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM entities WHERE name = ?",
                    (name,)
                ).fetchall()
            return [dict(r) for r in rows]

    def get_entities_for_technology(
        self, technology: str, entity_type: str | None = None
    ) -> list[dict]:
        """Get all known entities for a technology.

        Args:
            technology: Technology name.
            entity_type: Optional type filter.
        Returns:
            List of entity dicts.
        """
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            if entity_type:
                rows = conn.execute(
                    "SELECT * FROM entities WHERE technology = ? AND entity_type = ?",
                    (technology, entity_type)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM entities WHERE technology = ?",
                    (technology,)
                ).fetchall()
            return [dict(r) for r in rows]

    def find_mentioned_entities(self, text: str) -> list[dict]:
        """Find catalog entities that are mentioned in a text string.

        Splits text into tokens and checks each against known entity names.
        This is what makes "explain dim_customers" resolve to a dbt model.

        Args:
            text: User prompt or any text to scan for entity references.
        Returns:
            List of matching entity dicts (deduplicated).
        """
        # Normalize: split on spaces, underscores stay as part of names
        tokens = set(text.lower().replace(",", " ").replace(".", " ").replace("'", " ").replace('"', " ").split())

        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            all_entities = conn.execute(
                "SELECT DISTINCT technology, entity_type, name, parent, metadata FROM entities"
            ).fetchall()

        matches = []
        seen = set()
        text_lower = text.lower()
        for entity in all_entities:
            name_lower = entity["name"].lower()
            # Match if entity name appears as a token (exact word match)
            # Skip very short names (<=2 chars) to avoid false positives
            if len(name_lower) <= 2:
                continue
            if name_lower in tokens:
                key = (entity["technology"], entity["entity_type"], entity["name"])
                if key not in seen:
                    seen.add(key)
                    matches.append(dict(entity))
            elif "_" in name_lower and name_lower in text_lower:
                # Multi-word entity names (e.g., "dim_customers") matched as substring
                # are OK — they're specific enough to avoid false positives
                key = (entity["technology"], entity["entity_type"], entity["name"])
                if key not in seen:
                    seen.add(key)
                    matches.append(dict(entity))

        return matches

    # ── Context for orchestrator ────────────────────────

    def get_context_summary(self, technology: str | None = None) -> str:
        """Build a human-readable summary of known entities for the planning prompt.

        Args:
            technology: If set, only summarize entities for this technology.
        Returns:
            Multi-line string, or empty string if no entities known.
        """
        if technology:
            entities = self.get_entities_for_technology(technology)
        else:
            entities = self._get_all_entities()

        if not entities:
            return ""

        # Group by technology + entity_type
        groups: dict[str, list[str]] = {}
        for e in entities:
            key = f"{e['technology']}/{e['entity_type']}"
            if key not in groups:
                groups[key] = []
            label = e["name"]
            if e.get("parent"):
                label += f" (in {e['parent']})"
            groups[key].append(label)

        lines = []
        for key, names in groups.items():
            tech, etype = key.split("/", 1)
            # Show first 15, indicate if more
            shown = names[:15]
            extra = f" (+{len(names) - 15} more)" if len(names) > 15 else ""
            lines.append(f"- {tech} {etype}s: {', '.join(shown)}{extra}")

        return "\n".join(lines)

    def format_entity_matches(self, matches: list[dict]) -> str:
        """Format entity matches for the planning prompt.

        Args:
            matches: Output from find_mentioned_entities().
        Returns:
            Formatted string describing what the user is referring to.
        """
        if not matches:
            return ""

        lines = []
        for m in matches:
            meta_str = ""
            if m.get("metadata"):
                try:
                    meta = json.loads(m["metadata"]) if isinstance(m["metadata"], str) else m["metadata"]
                    if isinstance(meta, dict):
                        meta_parts = [f"{k}={v}" for k, v in meta.items() if v]
                        if meta_parts:
                            meta_str = f" ({', '.join(meta_parts[:3])})"
                except (json.JSONDecodeError, TypeError):
                    pass

            parent_str = f" in {m['parent']}" if m.get("parent") else ""
            lines.append(
                f"- \"{m['name']}\" is a {m['entity_type']} in {m['technology']}{parent_str}{meta_str}"
            )

        return "\n".join(lines)

    # ── Outcome tracking (episodic) ─────────────────────

    def record_outcome(
        self,
        task_id: str,
        tool_name: str,
        technology: str,
        action: str,
        verdict: str,
        details: dict | None = None,
    ) -> None:
        """Record a build/test/execution outcome.

        Args:
            task_id: Task identifier.
            tool_name: Name of the tool.
            technology: Technology.
            action: "build", "test", or "execute".
            verdict: "pass", "fail", or "error".
            details: Optional extra details.
        """
        now = datetime.now().isoformat()
        details_json = json.dumps(details) if details else None
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO outcomes (task_id, tool_name, technology, action, verdict, details, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (task_id, tool_name, technology, action, verdict, details_json, now))

    def get_recent_outcomes(self, technology: str | None = None, limit: int = 10) -> list[dict]:
        """Get recent build/test outcomes.

        Args:
            technology: Optional technology filter.
            limit: Max results.
        Returns:
            List of outcome dicts, newest first.
        """
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            if technology:
                rows = conn.execute(
                    "SELECT * FROM outcomes WHERE technology = ? ORDER BY created_at DESC LIMIT ?",
                    (technology, limit)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM outcomes ORDER BY created_at DESC LIMIT ?",
                    (limit,)
                ).fetchall()
            return [dict(r) for r in rows]

    def get_failure_patterns(self, technology: str, limit: int = 5) -> str:
        """Get recent failure patterns for the builder to learn from.

        Args:
            technology: Technology to check.
            limit: Max failures to return.
        Returns:
            Formatted string of recent failures, or empty string.
        """
        outcomes = self.get_recent_outcomes(technology, limit * 2)
        failures = [o for o in outcomes if o.get("verdict") == "fail"][:limit]
        if not failures:
            return ""

        lines = []
        for f in failures:
            details = ""
            if f.get("details"):
                try:
                    d = json.loads(f["details"]) if isinstance(f["details"], str) else f["details"]
                    details = f" — {d.get('reason', '')}"
                except (json.JSONDecodeError, TypeError):
                    pass
            lines.append(f"- {f['tool_name']} ({f['action']}): FAIL{details}")

        return "\n".join(lines)

    def close(self) -> None:
        """Close the persistent connection (if any). Call before deleting temp DB files."""
        if self._persistent_conn is not None:
            self._persistent_conn.close()
            self._persistent_conn = None

    # ── Internal ────────────────────────────────────────

    def _get_all_entities(self) -> list[dict]:
        """Get all entities across all technologies."""
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM entities ORDER BY technology, entity_type, name"
            ).fetchall()
            return [dict(r) for r in rows]
