#!/usr/bin/env python3

# Description
###############################################################################
'''
Future DNN pipeline modules (multi-stage, multi-task).

Usage:

import OCDocker.OCScore.DNN.future as ocdnn_future

Modules
-------
- DNNOptimizer: Experimental DNN optimizer.
- datasets: Dataset helpers for experiments.
- losses: Experimental loss functions.
- metrics: Experimental metrics.
- models: Experimental model definitions.
'''

# Imports
###############################################################################

# License
###############################################################################
'''
OCDocker
Authors: Rossi, A.D.; Monachesi, M.C.E.; Spelta, G.I.; Torres, P.H.M.
Federal University of Rio de Janeiro
Carlos Chagas Filho Institute of Biophysics
Laboratory for Molecular Modeling and Dynamics

This program is proprietary software owned by the Federal University of Rio de Janeiro (UFRJ),
developed by Rossi, A.D.; Monachesi, M.C.E.; Spelta, G.I.; Torres, P.H.M., and protected under Brazilian Law No. 9,609/1998.
All rights reserved. Use, reproduction, modification, and distribution are allowed under this UFRJ license,
provided this copyright notice is preserved. See the LICENSE file for details.

Contact: Artur Duque Rossi - arturossi10@gmail.com
'''

# Classes
###############################################################################


# Functions
###############################################################################
## Private ##

## Public ##

__all__ = []
