#!/usr/lib/python3

# Description
###############################################################################
'''
Sets of classes and functions that are used to process all content related to
the ligand.

Usage:

import OCDocker.Ligand as ocl
'''

# Imports
###############################################################################
from __future__ import annotations

import json
import os
import rdkit

from openbabel import openbabel
from rdkit import Chem, DataStructs, RDLogger as _RDLogger
from rdkit.Chem import AllChem as _AllChem, Descriptors, Descriptors3D, MACCSkeys as _MACCSkeys
from rdkit.Chem.rdMolTransforms import ComputeCentroid
from rdkit.Geometry.rdGeometry import Point3D
from rdkit.Chem.SaltRemover import SaltRemover
from threading import Lock
from typing import Any, Callable, Dict, List, Optional, Tuple, Union, TYPE_CHECKING, overload, Literal, cast

import OCDocker.Error as ocerror

import OCDocker.Toolbox.Conversion as occonversion
import OCDocker.Toolbox.FilesFolders as ocff
import OCDocker.Toolbox.Printing as ocprint
import OCDocker.Toolbox.Validation as ocvalidation

# Type casts for incomplete rdkit stubs in mypy
RDLogger: Any = _RDLogger
AllChem: Any = _AllChem
MACCSkeys: Any = _MACCSkeys

if TYPE_CHECKING:
    from typing import Callable

# License
###############################################################################
'''
OCDocker
Authors: Rossi, A.D.; Monachesi, M.C.E.; Spelta, G.I.; Torres, P.H.M.
Federal University of Rio de Janeiro
Carlos Chagas Filho Institute of Biophysics
Laboratory for Molecular Modeling and Dynamics

This program is proprietary software owned by the Federal University of Rio de Janeiro (UFRJ),
developed by Rossi, A.D.; Monachesi, M.C.E.; Spelta, G.I.; Torres, P.H.M., and protected under Brazilian Law No. 9,609/1998.
All rights reserved. Use, reproduction, modification, and distribution are allowed under this UFRJ license,
provided this copyright notice is preserved. See the LICENSE file for details.

Contact: Artur Duque Rossi - arturossi10@gmail.com
'''

# Set output levels for openbabel
ob_log_handler = openbabel.OBMessageHandler()
ob_log_handler.SetOutputLevel(ocerror.Error.output_level)
if ocerror.Error.output_level == ocerror.ReportLevel.NONE:
    RDLogger.DisableLog("rdApp.*")

# Classes
###############################################################################
class Ligand:
    """Represents a ligand (small molecule) with computed molecular descriptors.

    This class loads ligand structures from various file formats (PDB, SDF, MOL,
    MOL2, SMILES) or accepts RDKit molecule objects, and computes a wide range
    of molecular descriptors including 2D descriptors (BalabanJ, BertzCT, etc.)
    and 3D descriptors (RadiusOfGyration, Asphericity, etc.).

    Parameters
    ----------
    molecule : str | rdkit.Chem.rdchem.Mol
        Path to a molecule file or an RDKit molecule object.
    name : str
        Name identifier for the ligand.
    sanitize : bool, optional
        Whether to sanitize the molecule after loading, by default True.
    normalize_smiles_with_openbabel : bool, optional
        If True, normalize problematic SMILES strings with Open Babel
        before retrying RDKit parsing, by default False.
    from_json_descriptors : str, optional
        Path to JSON file containing pre-computed descriptors, by default "".
    embed_max_attempts : int, optional
        Maximum number of RDKit embedding attempts (outer loop), by default 10.
    etkdg_max_attempts : int, optional
        RDKit ETKDG internal attempts (maxAttempts/maxIterations), by default 1000.
    """
    ## Private ##

    molecule: rdkit.Chem.rdchem.Mol
    path: str
    box_path: str
    name: str
    sanitize: bool
    normalize_smiles_with_openbabel: bool
    from_json_descriptors: str

    RadiusOfGyration: Optional[float]
    FpDensityMorgan1: Optional[float]
    FpDensityMorgan2: Optional[float]
    FpDensityMorgan3: Optional[float]

    def __init__(
            self,
            molecule: Union[str, rdkit.Chem.rdchem.Mol],
            name: str,
            sanitize: bool = True,
            normalize_smiles_with_openbabel: bool = False,
            from_json_descriptors: str = "",
            embed_max_attempts: int = 10,
            etkdg_max_attempts: int = 1000
        ) -> None:
        ''' Constructor for the Ligand class.

        Parameters
        ----------
        molecule : str | rdkit.Chem.rdchem.Mol
            The molecule to be processed. If a string is provided, it is assumed to be a path to a molecule file (pdb/sdf/mol/mol2). If a rdkit.Chem.rdchem.Mol object is provided, it is assumed to be a molecule object.
        name : str
            The name of the molecule.
        sanitize : bool
            If True, the molecule will be sanitized.
        normalize_smiles_with_openbabel : bool
            If True, normalize problematic SMILES strings with Open Babel
            before retrying RDKit parsing.
        from_json_descriptors : str
            If a path to a json file is provided, the descriptors will be read from the file instead of being computed.
        embed_max_attempts : int, optional
            Maximum number of RDKit embedding attempts (outer loop), by default 10.
        etkdg_max_attempts : int, optional
            RDKit ETKDG internal attempts (maxAttempts/maxIterations), by default 1000.

        Raises
        ------
        ValueError
            If the ligand name is invalid or the molecule cannot be loaded.
        '''

        # Set the path and structure (NEVER SHOUD BE NONE)
        path, mol = load_mol(
            molecule,
            sanitize,
            normalize_smiles_with_openbabel=normalize_smiles_with_openbabel,
            embed_max_attempts=embed_max_attempts,
            etkdg_max_attempts=etkdg_max_attempts
        )
        if mol is None:
            message = "The molecule could not be loaded."
            raise ValueError(message)
        self.path = path
        self.molecule = mol
        # Set the box_path (removing the file from the path)
        self.box_path = os.path.join(os.path.dirname(self.path), "boxes/box0.pdb")

        # Define everything as None, except for the name
        if "_split_" in name:
            message = "The name of the ligand cannot contain the string '_split_'"
            _ = ocerror.Error.invalid_molecule_name(message)
            raise ValueError(message)
        self.name = name

        # All attribute initializations
        for desc in Ligand.allDescriptors:
            setattr(self, desc, None)

        # Set the from_json_descriptors attribute
        self.from_json_descriptors = from_json_descriptors

        # Set the sanitize attribute
        self.sanitize = sanitize
        self.normalize_smiles_with_openbabel = normalize_smiles_with_openbabel

        # If user pass a json
        if from_json_descriptors:
            # Read the descriptors from it
            data = read_descriptors_from_json(from_json_descriptors, return_data = True)
            # If data is None or malformed, a problem occurred while reading the json file
            if data is None or not isinstance(data, dict):
                message = f"Problems while parsing json file: '{from_json_descriptors}'"
                ocprint.print_error(message)
                raise ValueError(message)

            #region assign
            # Handle both 'Name' and 'Ligand' keys (read_descriptors_from_json with return_data=True renames 'Name' to 'Ligand')
            self.name = str(data.get("Name") or data.get("Ligand") or name)

            # All attribute initializations
            for desc in Ligand.allDescriptors:
                setattr(self, desc, data[desc])
            #endregion

        else:
            # Check if the name is empty
            if not name:
                message = "The Ligand name should not be empty!"
                ocprint.print_error(message)
                raise ValueError(message)
            self.name = name.replace(" ", "_")

            # Single attribute initializations
            for desc in Ligand.allDescriptors:
                result = globals()[f"find{desc}"](self.molecule)

                setattr(self, f"{desc}", result)


    def __repr__(self) -> str:
        '''Return a string representation of the Ligand object.

        Returns
        -------
        str
            A string representation of the Ligand object.
        '''

        return (
            "Ligand("
            f"molecule={self.molecule}, "
            f"name={self.name}, "
            f"sanitize={self.sanitize}, "
            f"normalize_smiles_with_openbabel={self.normalize_smiles_with_openbabel}, "
            f"from_json_descriptors={'True' if self.from_json_descriptors else 'False'}"
            ")"
        )


    def __safe_to_dict(self) -> Dict[str, Union[str, int, float]]:
        '''Return all the properties (except the molecule object) for the Ligand object.

        Returns
        -------
        Dict[str, int | float]
            The properties of the Ligand object.
        '''

        # Create new dict
        properties: Dict[str, Union[str, float, int]] = {}

        # Set Name and Path
        properties["Name"] = self.name if self.name is not None else "-"
        properties["Path"] = self.path if self.path is not None else "-"

        # Combine both in one dict and return them

        return {**properties, **self.get_descriptors()}

    ## Public ##

    def create_box(self, centroid: Optional[Tuple[float, float, float]] = None, save_path: str = "", box_length: float = 2.9, overwrite: bool = False) -> Optional[int]:
        '''Create a box file to be used by docking software.

        Parameters
        ----------
        centroid : tuple | None, optional
            The centroid of the box. If not provided, the centroid of the molecule will be used. (default is None) [WARNING]: Since normally when creating the box the molecule is not yet docked, the centroid of the molecule might not be the best option. Preferably, provide the centroid of the receptor binding site which should be determined beforehand.
        save_path : str, optional
            The path to save the box file. If not provided, the box file will be saved in the same path as the molecule. (default is "", which turns into self.box_path)
        box_length : float, optional
            The length of the box. (default is 2.9)
        overwrite : bool, optional
            Flag to allow, or not, the overwrite of the box file. (default is False)

        Returns
        -------
        int | None
            If the box file was created, return None. If fails, return the exit code of the command (based on the Error.py code table).
        '''

        # If the save_path is not defined
        if not save_path:
            # Set it as the same dir as the ligand
            save_path = os.path.join(os.path.split(self.path)[0], 'boxes')
            # If the save_path does not exist
            if not os.path.exists(save_path):
                # Create it
                _ = ocff.safe_create_dir(save_path)
        else:
            # If the save_path does not exist, warn the user
            if not os.path.exists(save_path):
                _ =  ocerror.Error.dir_not_exist(f"The save_path '{save_path}' does not exist. Creating it.", level = ocerror.ReportLevel.WARNING)
                _ = ocff.safe_create_dir(save_path)

        # Check if the box file already exists
        if os.path.isfile(f"{save_path}/box0.pdb") and not overwrite:
            # If it exists and the overwrite flag is False, return an error
            return ocerror.Error.file_exists(f"The box file '{save_path}' already exists. If you want to overwrite it, set the 'overwrite' flag to True.")

        # If the centroid is not defined
        if centroid is None:
            try:
                # Compute it
                centroid = self.get_centroid()
            except Exception as e:
                identifier = self.name or self.path or "unknown"
                return ocerror.Error.parse_molecule(
                    f"Could not compute centroid for molecule '{identifier}'. Error: {e}",
                    level = ocerror.ReportLevel.WARNING
                )

        # Check if the centroid is the type rdkit.Geometry.rdGeometry.Point3D
        if isinstance(centroid, rdkit.Geometry.rdGeometry.Point3D):
            centroid = (centroid.x, centroid.y, centroid.z)
        try:
            centroid_vals = tuple(centroid)
        except Exception:
            identifier = self.name or self.path or "unknown"
            return ocerror.Error.wrong_type(
                f"Centroid for molecule '{identifier}' must be a 3-element sequence.",
                level = ocerror.ReportLevel.WARNING
            )
        if len(centroid_vals) != 3:
            identifier = self.name or self.path or "unknown"
            return ocerror.Error.value_error(
                f"Centroid for molecule '{identifier}' must have 3 elements.",
                level = ocerror.ReportLevel.WARNING
            )
        try:
            centroid = (float(centroid_vals[0]), float(centroid_vals[1]), float(centroid_vals[2]))
        except Exception:
            identifier = self.name or self.path or "unknown"
            return ocerror.Error.value_error(
                f"Centroid for molecule '{identifier}' must contain numeric values.",
                level = ocerror.ReportLevel.WARNING
            )

        # Get the partial size for each axis (to determine how much should be expanded in each direction)
        if self.RadiusOfGyration is None:
            identifier = self.name or self.path or "unknown"
            return ocerror.Error.not_set(
                f"RadiusOfGyration from molecule '{identifier}' is not set; cannot create box.",
                level = ocerror.ReportLevel.WARNING
            )
        partialSize = (box_length * self.RadiusOfGyration) / 2

        # Create the box using this Centroid
        box = {
            "min_x": centroid[0] - partialSize,
            "max_x": centroid[0] + partialSize,
            "min_y": centroid[1] - partialSize,
            "max_y": centroid[1] + partialSize,
            "min_z": centroid[2] - partialSize,
            "max_z": centroid[2] + partialSize
        }

        # Get dimensions for each axis and its center (round to 3 decimals)
        dim_x = abs(round(box["max_x"] - box["min_x"], 3))
        dim_y = abs(round(box["max_y"] - box["min_y"], 3))
        dim_z = abs(round(box["max_z"] - box["min_z"], 3))

        # Get the size of the center (starting from the origin) (not using dim because I want to round only once)
        center_x = abs((box["max_x"] - box["min_x"])/2)
        center_y = abs((box["max_y"] - box["min_y"])/2)
        center_z = abs((box["max_z"] - box["min_z"])/2)
        # Since the boxes might not have one corner at the origin, shift it in all directions X,Y,Z
        center_x = round(center_x + box["min_x"], 3)
        center_y = round(center_y + box["min_y"], 3)
        center_z = round(center_z + box["min_z"], 3)

        # Convert the values found above to string with 8 chars (complete with spaces to the left) as the .pdb file model
        min_x = " " * (8 - len(str(round(box["min_x"], 3)))) + str(round(box["min_x"], 3))
        max_x = " " * (8 - len(str(round(box["max_x"], 3)))) + str(round(box["max_x"], 3))
        min_y = " " * (8 - len(str(round(box["min_y"], 3)))) + str(round(box["min_y"], 3))
        max_y = " " * (8 - len(str(round(box["max_y"], 3)))) + str(round(box["max_y"], 3))
        min_z = " " * (8 - len(str(round(box["min_z"], 3)))) + str(round(box["min_z"], 3))
        max_z = " " * (8 - len(str(round(box["max_z"], 3)))) + str(round(box["max_z"], 3))

        dim_x_str = " " * (8 - len(str(round(dim_x, 3)))) + str(round(dim_x, 3))
        dim_y_str = " " * (8 - len(str(round(dim_y, 3)))) + str(round(dim_y, 3))
        dim_z_str = " " * (8 - len(str(round(dim_z, 3)))) + str(round(dim_z, 3))

        center_x_str = " " * (8 - len(str(round(center_x, 3)))) + str(round(center_x, 3))
        center_y_str = " " * (8 - len(str(round(center_y, 3)))) + str(round(center_y, 3))
        center_z_str = " " * (8 - len(str(round(center_z, 3)))) + str(round(center_z, 3))

        # Write out the box file (following the one given in the DUD-E database)
        with open(f"{save_path}/box0.pdb", 'w') as f:
            f.write(f"HEADER    CORNERS OF BOX      {min_x}{min_y}{min_z}{max_x}{max_y}{max_z}\n")
            f.write(f"REMARK    CENTER (X Y Z)      {center_x_str}{center_y_str}{center_z_str}\n")
            f.write(f"REMARK    DIMENSIONS (X Y Z)  {dim_x_str}{dim_y_str}{dim_z_str}\n")
            f.write(f"ATOM      1  DUA BOX     1    {min_x}{min_y}{min_z}\n")
            f.write(f"ATOM      2  DUB BOX     1    {max_x}{min_y}{min_z}\n")
            f.write(f"ATOM      3  DUC BOX     1    {max_x}{min_y}{max_z}\n")
            f.write(f"ATOM      4  DUD BOX     1    {min_x}{min_y}{max_z}\n")
            f.write(f"ATOM      5  DUE BOX     1    {min_x}{max_y}{min_z}\n")
            f.write(f"ATOM      6  DUF BOX     1    {max_x}{max_y}{min_z}\n")
            f.write(f"ATOM      7  DUG BOX     1    {max_x}{max_y}{max_z}\n")
            f.write(f"ATOM      8  DUH BOX     1    {min_x}{max_y}{max_z}\n")
            f.write("CONECT    1    2    4    5\n")
            f.write("CONECT    2    1    3    6\n")
            f.write("CONECT    3    2    4    7\n")
            f.write("CONECT    4    1    3    8\n")
            f.write("CONECT    5    1    6    8\n")
            f.write("CONECT    6    2    5    7\n")
            f.write("CONECT    7    3    6    8\n")
            f.write("CONECT    8    4    5    7\n")

        return None


    def get_centroid(self, sanitize: bool = True) -> rdkit.Geometry.rdGeometry.Point3D:
        '''Get the centroid of the molecule.

        Parameters
        ----------
        sanitize : bool, optional
            Flag to allow, or not, molecules sanitization. (default is True)

        Returns
        -------
        rdkit.Geometry.rdGeometry.Point3D
            The centroid of the molecule.
        '''

        # Compute the centroid of the molecule and return it
        return get_centroid(self.molecule, sanitize = sanitize)


    def get_descriptors(self) -> Dict[str, Union[int, float]]:
        '''Return the descriptors for the Ligand object.

        Returns
        -------
        Dict[str, Union[int, float]]
            A dictionary of the descriptors for the Ligand object.
        '''

        descriptors = {}

        # All attribute initializations
        for desc in Ligand.allDescriptors:
            attribute = getattr(self, desc)
            descriptors[desc] = attribute if attribute is not None else 0.0

        return descriptors


    def is_same_molecule(self, molecule: Union[rdkit.Chem.rdchem.Mol, Ligand], sanitize: bool = True) -> Union[bool, int]:
        '''Compare two molecules to check if they are the same using their MACCSkeys.

        Parameters
        ----------
        molecule : rdkit.Chem.rdchem.Mol | ocl.Ligand
            The molecule to compare with.
        sanitize : bool, optional
            Flag to allow, or not, molecules sanitization. (default is True)

        Returns
        -------
        bool | int
            If both molecules are the same, return True. If both molecules are not the same, return False. If fails, return an error code.
        '''

        # Get the MACCSKeys for the ligand object
        ligandMACCSSKeys = MACCSkeys.GenMACCSKeys(self.molecule)

        # Check if the type of the molecule is a Ligand
        if isinstance(molecule, Ligand):
            # If yes, get its MACCSKeys
            targetMACCSSKeys = MACCSkeys.GenMACCSKeys(molecule.molecule)
        # Otherwise check if it is a Chem.rdchem.Mol object
        elif isinstance(molecule, Chem.rdchem.Mol):
            # If it is, get its smiles using the Ligand public function, get_smiles()
            targetMACCSSKeys = MACCSkeys.GenMACCSKeys(molecule)
        # If is neither both types above
        else:
            # Return an error
            return ocerror.Error.wrong_type(f"The provided variable is a '{type(molecule)}' and was expected a 'rdkit.Chem.rdchem.Mol' or 'ocl.Ligand'.")

        # Check if the Fingerprints are the same using the Tanimoto similarity
        if DataStructs.FingerprintSimilarity(ligandMACCSSKeys, targetMACCSSKeys) == 1.0:
            # If they are the same, return True
            return True

        # Otherwise (they are not the same)
        return False


    def is_same_molecule_SMILES(self, molecule: Union[rdkit.Chem.rdchem.Mol, Ligand], sanitize: bool = True) -> Union[bool, int]:
        '''Compare two molecules to check if they are the same using their SMILES and FpDensityMorgan 1 2 and 3.

        Parameters
        ----------
        molecule : rdkit.Chem.rdchem.Mol | ocl.Ligand
            The molecule to compare with.
        sanitize : bool, optional
            Flag to allow, or not, molecules sanitization. (default is True)

        Returns
        -------
        bool | int
            If both molecules are the same, return True. If both molecules are not the same, return False. If fails, return an error code.
        '''

        try:
            # Check if the molecule is a Ligand and get the properties directly
            if isinstance(molecule, Ligand):
                target_molecule_smiles = molecule.to_smiles()
                target_mol_morgan_fps = (
                    molecule.FpDensityMorgan1,
                    molecule.FpDensityMorgan2,
                    molecule.FpDensityMorgan3,
                )
            # If it's an RDKit Mol, calculate the properties
            elif isinstance(molecule, Chem.rdchem.Mol):
                _, mol = load_mol(molecule, sanitize=sanitize)
                if mol is None:
                    _ = ocerror.Error.parse_molecule(
                        "The provided RDKit molecule could not be prepared for comparison.",
                        level = ocerror.ReportLevel.WARNING
                    )
                    return False
                target_molecule_smiles = get_smiles(mol)
                target_mol_morgan_fps = (
                    findFpDensityMorgan1(mol),
                    findFpDensityMorgan2(mol),
                    findFpDensityMorgan3(mol),
                )
            else:
                _ = ocerror.Error.wrong_type(f"The provided variable is of type '{type(molecule)}'; expected 'rdkit.Chem.rdchem.Mol' or 'ocl.Ligand'.")
                return False

            # Compare SMILES first to short-circuit if they are different
            if self.to_smiles() != target_molecule_smiles:
                return False

            # Compare fingerprints
            self_mol_morgan_fps = (
                self.FpDensityMorgan1,
                self.FpDensityMorgan2,
                self.FpDensityMorgan3,
            )

            return self_mol_morgan_fps == target_mol_morgan_fps
        except Exception as e:
            _ = ocerror.Error.unknown(f"Unknown error while checking smiles: {str(e)}")

        return False


    def is_valid(self) -> bool:
        '''Check if a Ligand object is valid.

        Returns
        -------
        bool
            True if the Ligand object is valid, False otherwise.
        '''

        #region if any attribute is None (will check for every attribute in the ligand object)
        if any(getattr(self, attr) is None for attr in Ligand.allDescriptors):
            return False
        #endregion

        return True


    def print_attributes(self) -> None:
        '''Print all attributes of the ligand to stdout.

        Displays the ligand's name, molecule object, and all computed
        molecular descriptors (BalabanJ, BertzCT, RadiusOfGyration, etc.)
        in a formatted, aligned table.
        '''

        #region prints

        # Initialize descriptors in each category
        # Calculate maximum length of descriptor names for both categories
        max_length = max(
            max(len(desc) for desc in Ligand.allDescriptors),
            len("Name"),
            len("Molecule")
        ) + 5

        print(f"{'Name'.ljust(max_length)}: '{self.name if self.name is not None else '-'}'")
        print(f"{'Molecule'.ljust(max_length)}: '{self.molecule if self.molecule is not None else '-'}'")

        # All attribute initializations
        for desc in Ligand.allDescriptors:
            attribute = getattr(self, desc)
            # Pad the attribute name to align
            print(f"{desc.ljust(max_length)}: '{attribute if attribute is not None else '-'}'")
        #endregion

        return None


    def to_dict(self) -> Dict[str, Union[int, float, str]]:
        '''Return all the properties for the Ligand object.

        Returns
        -------
        Dict[str, Union[int, float, str]]
            A dictionary of all the properties for the Ligand object.
        '''

        # Create new dict
        properties = dict()

        # Set Name, Path and molecule
        properties["Name"] = self.name if self.name is not None else "-"
        properties["Path"] = self.path if self.path is not None else "-"
        properties["Molecule"] = str(self.molecule) if self.molecule is not None else "-"

        # Combine both in one dict and return them

        return {**properties, **self.get_descriptors()}


    def to_json(self, overwrite: bool = False) -> int:
        '''Stores the descriptors as json to avoid the necessity of evaluate them many times.

        Parameters
        ----------
        overwrite : bool, optional
            If True, the json file will be overwritten, by default False.

        Returns
        -------
        int
            The exit code of the command (based on the Error.py code table).
        '''

        try:
            # Parameterize the path
            base_dir = os.path.dirname(self.path)
            if not base_dir:
                base_dir = os.getcwd()
                _ = ocerror.Error.dir_not_exist(
                    "Ligand path is empty; using current working directory for JSON output.",
                    level = ocerror.ReportLevel.WARNING
                )
            outputJson = f"{base_dir}/{self.name}_descriptors.json"
            # Check if the file exists
            if os.path.isfile(outputJson):
                # Check if the user wants to overwrite the file
                if not overwrite:
                    # If the file exists and overwrite is False, return the file exists error
                    return ocerror.Error.file_exists(f"The file {outputJson} already exists and the overwrite flag is set to False, no file will be generated or overwrited.", ocerror.ReportLevel.WARNING)
                # Warns the user that the file will be overwritten
                _ = ocerror.Error.file_exists(f"The file '{outputJson}' already exists. It will be OVERWRITED!!!")

            try:
                # Create a lock for multithreading
                lock = Lock()
                with lock:
                    # Open the file for writing
                    with open(outputJson, 'w') as outfile:
                        # Write the json file
                        json.dump(self.__safe_to_dict(), outfile)
                return ocerror.Error.ok()
            except Exception as e:
                return ocerror.Error.write_file(f"Problems while writing the file '{outputJson}' Error: {e}.")
        except Exception as e:

            return ocerror.Error.unknown(f"Unknown error while converting the ligand {self.name} to json.\nError: {e}", ocerror.ReportLevel.WARNING)


    def to_smiles(self) -> Union[str, int]:
        '''Return the smiles of the molecule.

        Returns
        -------
        str | int
            The smiles of the molecule, if fails the exit code of the command (based on the Error.py code table).
        '''

        return get_smiles(self.molecule)


    # Declare the descriptors names as class attributes
    descriptors_names = {
        'AUTOCORR2D_': range(1, 193),
        'BCUT2D_': ["CHGHI", "CHGLO", "LOGPHI", "LOGPLOW", "MRHI", "MRLOW", "MWHI", "MWLOW"],
        'fr_': ["Al_COO", "Al_OH", "Al_OH_noTert", "ArN", "Ar_COO", "Ar_N", "Ar_NH", "Ar_OH", "COO", "COO2", "C_O", "C_O_noCOO", "C_S", "HOCCN", "Imine", "NH0", "NH1", "NH2", "N_O", "Ndealkylation1", "Ndealkylation2", "Nhpyrrole", "SH", "aldehyde", "alkyl_carbamate", "alkyl_halide", "allylic_oxid", "amide", "amidine", "aniline", "aryl_methyl", "azide", "azo", "barbitur", "benzene", "benzodiazepine", "bicyclic", "diazo", "dihydropyridine", "epoxide", "ester", "ether", "furan", "guanido", "halogen", "hdrzine", "hdrzone", "imidazole", "imide", "isocyan", "isothiocyan", "ketone", "ketone_Topliss", "lactam", "lactone", "methoxy", "morpholine", "nitrile", "nitro", "nitro_arom", "nitro_arom_nonortho", "nitroso", "oxazole", "oxime", "para_hydroxylation", "phenol", "phenol_noOrthoHbond", "phos_acid", "phos_ester", "piperdine", "piperzine", "priamide", "prisulfonamd", "pyridine", "quatN", "sulfide", "sulfonamd", "sulfone", "term_acetylene", "tetrazole", "thiazole", "thiocyan", "thiophene", "unbrch_alkane", "urea"],
        'Chi': [str(j) + i if j < 2 else f"{j}{i}" for j in range(5) for i in ('', 'v', 'n') if not (j >= 2 and i == '')],
        'EState_VSA': range(1, 12),
        'FpDensityMorgan': range(1, 4),
        'Kappa': range(1, 4),
        'Mol': ["LogP", "MR", "Wt"],
        'Num': ["AliphaticCarbocycles", "AliphaticHeterocycles", "AliphaticRings", "AromaticCarbocycles", "AromaticHeterocycles", "AromaticRings", "HAcceptors", "HDonors", "Heteroatoms", "RadicalElectrons", "RotatableBonds", "SaturatedCarbocycles", "SaturatedHeterocycles", "SaturatedRings", "ValenceElectrons"],
        'NPR': range(1, 3),
        'PMI': range(1, 4),
        'PEOE_VSA': range(1, 15),
        'SMR_VSA': range(1, 11),
        'SlogP_VSA': range(1, 13),
        'VSA_EState': range(1, 11),
    }

    # Declare the single descriptors names as class attributes
    single_descriptors = [
        'BalabanJ', 'BertzCT', 'ExactMolWt', 'FractionCSP3', 'HallKierAlpha', 'HeavyAtomMolWt',
        'HeavyAtomCount', 'LabuteASA', 'TPSA', 'MaxAbsEStateIndex', 'MaxEStateIndex',
        'MinAbsEStateIndex', 'MinEStateIndex', 'MaxAbsPartialCharge', 'MaxPartialCharge',
        'MinAbsPartialCharge', 'MinPartialCharge', 'qed', 'RingCount', 'Asphericity', 'Eccentricity',
        'InertialShapeFactor', 'RadiusOfGyration', 'SpherocityIndex', 'NHOHCount', 'NOCount'
    ]

    # Create all the descriptors to be class attributes
    allDescriptors = [f'{desc_prefix}{i}' for desc_prefix, desc_indices in descriptors_names.items() for i in desc_indices] + single_descriptors















# Functions
###############################################################################
## Private ##

def __descriptor_function_factory(descriptor_name: str) -> Callable[[rdkit.Chem.rdchem.Mol], Optional[float]]:
    '''Factory function to create a function that computes a descriptor by its name.

    This function creates a descriptor computation function dynamically based on
    the descriptor name. It handles both 2D and 3D descriptors from RDKit.

    Parameters
    ----------
    descriptor_name : str
        The name of the descriptor to compute (e.g., "BalabanJ", "BertzCT",
        "RadiusOfGyration"). Must match a descriptor function name in either
        rdkit.Chem.Descriptors or rdkit.Chem.Descriptors3D.

    Returns
    -------
    Callable[[rdkit.Chem.rdchem.Mol], Optional[float]]
        A function that takes a molecule and returns the descriptor value,
        or None if computation fails.
    '''

    if descriptor_name in ["Asphericity", "Eccentricity", "InertialShapeFactor", "NPR1", "NPR2", "PMI1", "PMI2", "PMI3", "RadiusOfGyration", "SpherocityIndex"]:
        descriptor_func = getattr(Descriptors3D, descriptor_name)
    else:
        descriptor_func = getattr(Descriptors, descriptor_name)

    # TODO: Check how to avoid this function to spam print the same error multiple times
    def __compute_descriptor(molecule: rdkit.Chem.rdchem.Mol) -> Optional[float]:
        '''Compute a descriptor value for a molecule.

        This is a nested function created by the factory to compute a specific
        molecular descriptor using RDKit descriptor functions.

        Parameters
        ----------
        molecule : rdkit.Chem.rdchem.Mol
            The molecule object to compute the descriptor for.

        Returns
        -------
        Optional[float]
            The descriptor value, or None if computation fails or molecule is invalid.
        '''

        if molecule:
            if isinstance(molecule, rdkit.Chem.rdchem.Mol):
                try:
                    return float(descriptor_func(molecule))
                except Exception as e:
                    _ = ocerror.Error.unknown(f"Error while creating the function in factory: {str(e)}")
            else:
                _ = ocerror.Error.wrong_type(f"The molecule '{molecule}' has wrong type! Expected 'rdkit.Chem.rdchem.Mol' and got '{type(molecule)}'")
        else:
            pass
            # _ = ocerror.Error.not_set("The molecule is not set.")
        return None

    return __compute_descriptor


def __descriptor_function_factory_class(descriptor_name: str) -> Callable[[rdkit.Chem.rdchem.Mol], Optional[float]]:
    '''Factory function to create a class method that computes a descriptor.

    This function creates a descriptor computation method dynamically for the
    Ligand class. The created method uses self.molecule as the input molecule.

    Parameters
    ----------
    descriptor_name : str
        The name of the descriptor to compute (e.g., "BalabanJ", "BertzCT",
        "RadiusOfGyration"). Must match a descriptor function name in either
        rdkit.Chem.Descriptors or rdkit.Chem.Descriptors3D.

    Returns
    -------
    Callable[[rdkit.Chem.rdchem.Mol], Optional[float]]
        A method that can be bound to the Ligand class. When called, it computes
        the descriptor for self.molecule and returns the value, or None if
        computation fails.
    '''

    # Check if the descriptor is 3D (in this case use the Descriptors3D module)
    if descriptor_name in ["Asphericity", "Eccentricity", "InertialShapeFactor", "NPR1", "NPR2", "PMI1", "PMI2", "PMI3", "RadiusOfGyration", "SpherocityIndex"]:
        descriptor_func = getattr(Descriptors3D, descriptor_name)
    else:
        descriptor_func = getattr(Descriptors, descriptor_name)

    # TODO: Check how to avoid this function to spam print the same error multiple times

    # Create the nested function as a method of the Ligand class
    def __compute_descriptor_class(self) -> Optional[float]:
        '''Compute the descriptor for the Ligand object.

        This is a nested function created by the factory to compute a specific
        molecular descriptor for the Ligand instance using self.molecule.

        Returns
        -------
        Optional[float]
            The descriptor value for self.molecule, or None if computation fails
            or molecule is invalid.
        '''

        molecule = self.molecule  # Use self.molecule from the Ligand instance

        # Check if the molecule is set
        if molecule:
            # Check if the molecule is a rdkit.Chem.rdchem.Mol
            if isinstance(molecule, rdkit.Chem.rdchem.Mol):
                try:
                    # Return the function
                    return float(descriptor_func(molecule))
                except Exception as e:
                    _ = ocerror.Error.unknown(f"Error while creating the function in factory: {str(e)}")
            else:
                _ = ocerror.Error.wrong_type(f"The molecule '{molecule}' has wrong type! Expected 'rdkit.Chem.rdchem.Mol' and got '{type(molecule)}'")
        else:
            pass
            #_ = ocerror.Error.not_set("The molecule is not set.")
        return None

    return __compute_descriptor_class


_findFpDensityMorgan1 = __descriptor_function_factory("FpDensityMorgan1")
_findFpDensityMorgan2 = __descriptor_function_factory("FpDensityMorgan2")
_findFpDensityMorgan3 = __descriptor_function_factory("FpDensityMorgan3")


def findFpDensityMorgan1(mol: rdkit.Chem.rdchem.Mol) -> Optional[float]:
    '''Compute Morgan fingerprint density (radius=1).'''
    return _findFpDensityMorgan1(mol)


def findFpDensityMorgan2(mol: rdkit.Chem.rdchem.Mol) -> Optional[float]:
    '''Compute Morgan fingerprint density (radius=2).'''
    return _findFpDensityMorgan2(mol)


def findFpDensityMorgan3(mol: rdkit.Chem.rdchem.Mol) -> Optional[float]:
    '''Compute Morgan fingerprint density (radius=3).'''
    return _findFpDensityMorgan3(mol)


def _ensure_3d_conformer(
        mol: Chem.rdchem.Mol,
        sanitize: bool,
        smiles_source: str = "",
        add_hs: bool = True,
        max_attempts: int = 10,
        etkdg_max_attempts: int = 1000
    ) -> Optional[Chem.rdchem.Mol]:
    '''Ensure a molecule has a 3D conformer, using RDKit and OpenBabel fallbacks.

    Parameters
    ----------
    mol : rdkit.Chem.rdchem.Mol
        Molecule to ensure has a 3D conformer.
    sanitize : bool
        Whether to sanitize the molecule during conversion.
    smiles_source : str, optional
        Optional SMILES string to use for OpenBabel fallback, by default "".
    add_hs : bool, optional
        If True, adds hydrogens before embedding, by default True.
    max_attempts : int, optional
        Maximum number of RDKit embedding attempts, by default 10.
    etkdg_max_attempts : int, optional
        RDKit ETKDG internal attempts (maxAttempts/maxIterations), by default 1000.

    Returns
    -------
    rdkit.Chem.rdchem.Mol | None
        Molecule with 3D conformer if successful, otherwise None.
    '''

    if mol.GetNumConformers() > 0:
        try:
            if mol.GetConformer().Is3D():
                return mol
        except Exception:
            return mol
        mol.RemoveAllConformers()

    if add_hs:
        mol = Chem.AddHs(mol)

    if _try_embed_rdkit(
        mol,
        max_attempts=max_attempts,
        etkdg_max_attempts=etkdg_max_attempts
    ):
        return mol

    if not smiles_source:
        try:
            smiles_source = Chem.MolToSmiles(mol)
        except Exception:
            smiles_source = ""

    if smiles_source:
        ob_mol = _openbabel_3d_from_smiles(smiles_source, sanitize)
        if ob_mol and ob_mol.GetNumConformers() > 0:
            return ob_mol

    return None


def _get_etkdg_params(max_attempts: int = 1000) -> Any:
    '''Get RDKit ETKDG embedding parameters with safer defaults.

    Parameters
    ----------
    max_attempts : int, optional
        RDKit ETKDG internal attempts (maxAttempts/maxIterations), by default 1000.

    Returns
    -------
    rdkit.Chem.AllChem.EmbedParameters
        Configured ETKDG parameters object.
    '''

    if hasattr(AllChem, "ETKDGv3"):
        params = AllChem.ETKDGv3()
    else:
        params = AllChem.ETKDG()
    params.useRandomCoords = True
    return params


def _openbabel_3d_from_smiles(smiles: str, sanitize: bool) -> Optional[Chem.rdchem.Mol]:
    '''Generate a 3D RDKit molecule from SMILES via OpenBabel.

    Parameters
    ----------
    smiles : str
        SMILES string to build in 3D.
    sanitize : bool
        Whether to sanitize the RDKit molecule.

    Returns
    -------
    rdkit.Chem.rdchem.Mol | None
        RDKit molecule with 3D conformer if successful, otherwise None.
    '''

    ob_conversion = openbabel.OBConversion()
    if not ob_conversion.SetInFormat("smi"):
        return None
    if not ob_conversion.SetOutFormat("mol2"):
        return None

    ob_mol = openbabel.OBMol()
    if not ob_conversion.ReadString(ob_mol, smiles):
        return None

    ob_mol.AddHydrogens()
    builder = openbabel.OBBuilder()
    if not builder.Build(ob_mol):
        return None

    ff = openbabel.OBForceField.FindForceField("uff")
    if ff and ff.Setup(ob_mol):
        ff.ConjugateGradients(250)
        ff.GetCoordinates(ob_mol)

    mol2_block = ob_conversion.WriteString(ob_mol)
    return Chem.MolFromMol2Block(mol2_block, sanitize=sanitize, removeHs=False)


def _normalize_smiles_with_openbabel(smiles: str) -> Optional[str]:
    '''Normalize a SMILES string using Open Babel canonical output.

    Parameters
    ----------
    smiles : str
        Raw SMILES string.

    Returns
    -------
    str | None
        Canonicalized SMILES if conversion succeeds, otherwise None.
    '''

    ob_conversion = openbabel.OBConversion()
    if not ob_conversion.SetInFormat("smi"):
        return None
    if not ob_conversion.SetOutFormat("can"):
        return None

    ob_mol = openbabel.OBMol()
    if not ob_conversion.ReadString(ob_mol, smiles):
        return None

    normalized_raw = ob_conversion.WriteString(ob_mol)
    if not normalized_raw:
        return None

    normalized = cast(str, normalized_raw).strip()
    if not normalized:
        return None

    # Open Babel may append title/comment tokens after the SMILES.
    tokens = normalized.split()
    if not tokens:
        return None
    return tokens[0]


def _optimize_mol(mol: Chem.rdchem.Mol) -> bool:
    '''Optimize a molecule geometry using MMFF (preferred) or UFF.

    Parameters
    ----------
    mol : rdkit.Chem.rdchem.Mol
        Molecule with a 3D conformer to optimize.

    Returns
    -------
    bool
        True if optimization converged, False otherwise.
    '''

    if mol.GetNumConformers() == 0:
        return False
    try:
        mmff_props = AllChem.MMFFGetMoleculeProperties(mol)
        if mmff_props is not None:
            status = AllChem.MMFFOptimizeMolecule(mol, mmff_props)
            if status == 0:
                return True
    except Exception:
        pass
    try:
        status = AllChem.UFFOptimizeMolecule(mol)
        return bool(status == 0)
    except Exception:
        return False


def _try_embed_rdkit(
        mol: Chem.rdchem.Mol,
        max_attempts: int = 10,
        etkdg_max_attempts: int = 1000
    ) -> bool:
    '''Try embedding a molecule with RDKit using multiple seeds.

    Parameters
    ----------
    mol : rdkit.Chem.rdchem.Mol
        Molecule to embed (modified in place).
    max_attempts : int, optional
        Maximum number of embedding attempts, by default 10.
    etkdg_max_attempts : int, optional
        RDKit ETKDG internal attempts (maxAttempts/maxIterations), by default 1000.

    Returns
    -------
    bool
        True if embedding succeeded and a conformer exists, False otherwise.
    '''

    params = _get_etkdg_params(max_attempts=etkdg_max_attempts)
    for attempt in range(max_attempts):
        params.randomSeed = 0xC0FFEE + attempt
        if AllChem.EmbedMolecule(mol, params) == 0 and mol.GetNumConformers() > 0:
            return True
    return False


## Public ##

def get_centroid(molecule: Union[str, rdkit.Chem.rdchem.Mol], sanitize: bool = True) -> rdkit.Geometry.rdGeometry.Point3D:
    ''' Get the centroid of the molecule.

    Parameters
    ----------
    molecule : str | rdkit.Chem.rdchem.Mol
        The molecule to get the centroid or its path.
    sanitize : bool, optional
        If the molecule should be sanitized, by default True.

    Returns
    -------
    rdkit.Geometry.rdGeometry.Point3D
        The centroid of the molecule.

    Raises
    ------
    ValueError
        If the molecule cannot be loaded from the provided path.
    '''

    # Normalize to a concrete RDKit Mol before geometry operations.
    if isinstance(molecule, str):
        molecule_path = molecule
        _, loaded = load_mol(molecule, sanitize = sanitize)
        if loaded is None:
            ocerror.Error.parse_molecule(f"Could not load molecule from path: {molecule_path}")
            raise ValueError(f"Could not load molecule from path: {molecule_path}")
        mol = loaded
    elif isinstance(molecule, rdkit.Chem.rdchem.Mol):
        mol = molecule
    else:
        ocerror.Error.wrong_type(f"Expected RDKit Mol, got {type(molecule)}.")
        raise ValueError("Molecule is not an RDKit Mol.")

    mol = Chem.Mol(mol)
    needs_3d = mol.GetNumConformers() == 0
    if not needs_3d:
        try:
            needs_3d = not mol.GetConformer().Is3D()
        except Exception:
            needs_3d = False

    if needs_3d:
        maybe_mol = _ensure_3d_conformer(mol, sanitize=sanitize)
        if maybe_mol is None:
            message = "Could not generate a 3D conformer to compute centroid."
            ocerror.Error.parse_molecule(message, level = ocerror.ReportLevel.WARNING)
            raise ValueError(message)
        mol = maybe_mol

    # Get the molecule conformer
    conf = mol.GetConformer()

    # Compute the centroid of the molecule and return it
    return cast(Point3D, ComputeCentroid(conf))


def get_smiles(molecule: rdkit.Chem.rdchem.Mol) -> Union[str, int]:
    ''' Return the smiles of the molecule

    Parameters
    ----------
    molecule : rdkit.Chem.rdchem.Mol
        The molecule to get the smiles from.

    Returns
    -------
    str | int
        The smiles of the molecule or the error code or the exit code of the command (based on the Error.py code table).
    '''

    if molecule:
        if isinstance(molecule, rdkit.Chem.rdchem.Mol):
            return Chem.MolToSmiles(molecule)
        return ocerror.Error.wrong_type(f"The molecule '{molecule}' has wrong type! Expected 'rdkit.Chem.rdchem.Mol' and got '{type(molecule)}'")

    return ocerror.Error.not_set(f"The variable is not set.")


def load_mol(
        molecule: Union[str, Chem.rdchem.Mol],
        sanitize: bool = True,
        normalize_smiles_with_openbabel: bool = False,
        embed_max_attempts: int = 10,
        etkdg_max_attempts: int = 1000
    ) -> Tuple[str, Optional[Chem.rdchem.Mol]]:
    ''' Load a molecule pdb/sdf/mol/mol2 if a path is provided or just assign the Mol object to the molecule.

    Parameters
    ----------
    molecule : str/rdkit.Chem.rdchem.Mol
        The molecule path or the Mol object.
    sanitize : bool
        Whether to sanitize the molecule.
    normalize_smiles_with_openbabel : bool
        If True, normalize problematic SMILES strings with Open Babel
        before retrying RDKit parsing.
    embed_max_attempts : int, optional
        Maximum number of RDKit embedding attempts (outer loop), by default 10.
    etkdg_max_attempts : int, optional
        RDKit ETKDG internal attempts (maxAttempts/maxIterations), by default 1000.

    Returns
    -------
    Tuple[str, Chem.rdchem.Mol | None]
        The molecule object and the path to the molecule.
    '''

    mol: Any = None

    # Check if the type of the variable molecule is a string or a rdkit.Chem.rdchem.Mol
    if isinstance(molecule, Chem.rdchem.Mol):
        # Clone to avoid mutating the caller's molecule
        mol = Chem.Mol(molecule)
        needs_3d = mol.GetNumConformers() == 0

        if not needs_3d:
            try:
                needs_3d = not mol.GetConformer().Is3D()
            except Exception:
                needs_3d = False

        if needs_3d:
            maybe_mol = _ensure_3d_conformer(
                mol,
                sanitize=sanitize,
                max_attempts=embed_max_attempts,
                etkdg_max_attempts=etkdg_max_attempts
            )

            if maybe_mol is None:
                _ = ocerror.Error.parse_molecule(
                    "The provided RDKit molecule could not be embedded in 3D.",
                    level = ocerror.ReportLevel.ERROR
                )
                return "", None
            
            mol = maybe_mol
            if not _optimize_mol(mol):
                _ = ocerror.Error.parse_molecule(
                    "The provided RDKit molecule could not be optimized in 3D.",
                    level = ocerror.ReportLevel.WARNING
                )

        return "", mol

    if isinstance(molecule, str):
        # Check if file exists
        if not os.path.isfile(molecule):
            # File does not exist
            _ = ocerror.Error.file_not_exist(message=f"The file '{molecule}' does not exist!", level = ocerror.ReportLevel.WARNING)
            return "", None

        # Determine the extension and use appropriate RDKit functions
        extension = os.path.splitext(molecule)[1].lower()
        supported_extensions = ['.pdb', '.sdf', '.mol', '.mol2', '.smi', '.smiles']

        # The file extension is not supported, print data
        if extension not in supported_extensions:
            # This case the return code is suppressed because it is needed to return None in case of failure
            _ = ocerror.Error.unsupported_extension(message=f"The ligand {molecule} has a unsupported extension.\nCurrently the supported extensions are {', '.join(supported_extensions)}.", level = ocerror.ReportLevel.WARNING)
            return "", None

        # Function map for file extension to RDKit loading function
        load_functions: Dict[str, Callable[..., Any]] = {
            ".pdb": Chem.rdmolfiles.MolFromPDBFile,
            ".sdf": Chem.rdmolfiles.SDMolSupplier,
            ".mol": Chem.rdmolfiles.MolFromMolFile,
            ".mol2": Chem.rdmolfiles.MolFromMol2File,
        }

        # Load the molecule with appropriate loader
        if extension in load_functions:
            # Get the function to load the molecule
            load_func = load_functions[extension]
            # Load the molecule
            mol = load_func(molecule, sanitize = sanitize)
        elif extension in ['.smi', '.smiles']:
            # Read the smiles file into a string
            with open(molecule, 'r') as file:
                lines = [line.strip() for line in file if line.strip()]
            smiles_lines = [line for line in lines if not line.startswith("#")]
            if not smiles_lines:
                _ = ocerror.Error.parse_molecule(
                    f"The molecule '{molecule}' could not be parsed from smiles.",
                    level = ocerror.ReportLevel.WARNING
                )
                return "", None
            if len(smiles_lines) > 1:
                _ = ocerror.Error.parse_molecule(
                    f"Multiple SMILES entries found in '{molecule}'. Only the first will be used. "
                    "If you want to use multiple ligands, iterate them separately.",
                    level = ocerror.ReportLevel.WARNING
                )
            smiles = smiles_lines[0].split()[0]
            smiles_for_load = smiles

            # Load the molecule
            mol = Chem.MolFromSmiles(smiles_for_load, sanitize = sanitize)
            if mol is None and normalize_smiles_with_openbabel:
                normalized_smiles = _normalize_smiles_with_openbabel(smiles_for_load)
                if normalized_smiles:
                    if normalized_smiles != smiles_for_load:
                        _ = ocerror.Error.parse_molecule(
                            f"Normalized SMILES from '{smiles_for_load}' to '{normalized_smiles}' "
                            "using Open Babel before RDKit parsing.",
                            level = ocerror.ReportLevel.WARNING
                        )
                    smiles_for_load = normalized_smiles
                    mol = Chem.MolFromSmiles(smiles_for_load, sanitize = sanitize)

            # If the molecule was loaded
            if mol:
                # Find its name (without extension)
                name = os.path.splitext(os.path.basename(molecule))[0]

                # Set its name
                mol.SetProp("_Name", name)

                # Remove the salts
                if not sanitize:
                    try:
                        # StripMol requires implicit valence information.
                        mol.UpdatePropertyCache(strict=False)
                    except Exception:
                        pass
                remover = SaltRemover()
                mol = remover.StripMol(mol)

                # Add the hydrogens
                mol = Chem.AddHs(mol)

                maybe_mol = _ensure_3d_conformer(
                    mol,
                    sanitize=sanitize,
                    smiles_source=smiles_for_load,
                    add_hs=False,
                    max_attempts=embed_max_attempts,
                    etkdg_max_attempts=etkdg_max_attempts
                )
                if maybe_mol is None:
                    _ = ocerror.Error.parse_molecule(
                        f"The molecule '{molecule}' could not be embedded in 3D.",
                        level = ocerror.ReportLevel.WARNING
                    )
                    return "", None
                mol = maybe_mol
                mol.SetProp("_Name", name)

                # Ensure that the ring information is initialized
                _ = mol.GetRingInfo()

                # If sanitize is True, sanitize the molecule
                if sanitize:
                    # Sanitize the molecule
                    Chem.SanitizeMol(mol)

                # Optimize the molecule
                if not _optimize_mol(mol):
                    _ = ocerror.Error.parse_molecule(
                        f"The molecule '{molecule}' could not be optimized in 3D.",
                        level = ocerror.ReportLevel.WARNING
                    )
            else:
                # The molecule could not be loaded
                _ = ocerror.Error.parse_molecule(
                    f"The molecule '{molecule}' could not be parsed from smiles.", 
                    level = ocerror.ReportLevel.WARNING
                )
                return "", None

        # Handling of multiple molecules in a .sdf file
        if isinstance(mol, Chem.rdmolfiles.SDMolSupplier):
            mol_list = list(mol)
            if len(mol_list) > 1:
                _ = ocerror.Error.parse_molecule(
                    "Warning: The .sdf file contains more than one molecule. Only the first will be processed.",
                    level = ocerror.ReportLevel.WARNING
                )
            mol = mol_list[0] if mol_list else None

        # Check if the molecule was loaded
        if mol is None:
            _ = ocerror.Error.parse_molecule(
                f"The molecule '{molecule}' could not be parsed.", 
                level = ocerror.ReportLevel.WARNING
            )
            return "", None

        needs_3d = mol.GetNumConformers() == 0
        if not needs_3d:
            try:
                needs_3d = not mol.GetConformer().Is3D()
            except Exception:
                needs_3d = False

        if needs_3d:
            maybe_mol = _ensure_3d_conformer(
                mol,
                sanitize=sanitize,
                max_attempts=embed_max_attempts,
                etkdg_max_attempts=etkdg_max_attempts
            )
            if maybe_mol is None:
                _ = ocerror.Error.parse_molecule(
                    f"The molecule '{molecule}' could not be embedded in 3D.",
                    level = ocerror.ReportLevel.WARNING
                )
                return "", None
            mol = maybe_mol
            if not _optimize_mol(mol):
                _ = ocerror.Error.parse_molecule(
                    f"The molecule '{molecule}' could not be optimized in 3D.",
                    level = ocerror.ReportLevel.WARNING
                )

        # If sanitize is off
        if not sanitize:
            # Turn off the property cache
            mol.UpdatePropertyCache(strict=False)
            # Perform a partial sanitization (THIS IS VERY IMPORTANT!!!!)
            Chem.SanitizeMol(
                mol,
                Chem.SANITIZE_FINDRADICALS |
                Chem.SANITIZE_KEKULIZE |
                Chem.SANITIZE_SETAROMATICITY |
                Chem.SANITIZE_SETCONJUGATION |
                Chem.SANITIZE_SETHYBRIDIZATION |
                Chem.SANITIZE_SYMMRINGS,
                catchErrors=True
            )

        # If the molecule is not in mol2 format
        if extension != ".mol2":
            # Use input directory to keep derived files alongside ligand
            output_dir = os.path.dirname(molecule) or "."
            try:
                os.makedirs(output_dir, exist_ok=True)
            except (OSError, PermissionError):
                pass

            # Preserve the original basename; warn if it collides
            ligand_basename = os.path.splitext(os.path.basename(molecule))[0]
            outputMoleculePath = os.path.join(output_dir, f"{ligand_basename}.mol2")
            if os.path.isfile(outputMoleculePath):
                _ = ocerror.Error.file_exists(
                    f"The file '{outputMoleculePath}' already exists and will be overwritten.",
                    level = ocerror.ReportLevel.WARNING,
                )

            # Convert using the RDKit molecule to preserve 3D geometry
            occonversion.convert_mols_from_string("", outputMoleculePath, mol = mol)

            # Return the molecule
            return outputMoleculePath, mol

        # Return the molecule
        return molecule, mol

    # The variable is not in a supported data format
    _ = ocerror.Error.unsupported_extension(message = f"Unsupported molecule data. Please support either a molecule path (string) or a rdkit.Chem.rdchem.Mol object.", level = ocerror.ReportLevel.WARNING)

    return "", None


def multiple_molecules_sdf(molecule: Union[str, rdkit.Chem.rdchem.Mol]) -> List[Ligand]:
    ''' Parse a .sdf or .mol2 file with multiple molecules returning a list of ligands.

    Parameters
    ----------
    molecule : str | rdkit.Chem.rdchem.Mol
        Path to a molecule file or an RDKit molecule object

    Returns
    -------
    List[Ligand]
        A list of ligands.
    '''

    # List to hold multiple Ligand objects
    ligands = []
    # Check if the path is a string (it is assumed that the provided path is already a sdf)
    if isinstance(molecule, str):
        # Check if file exists
        if os.path.isfile(molecule):
            # Check if the extension of the file is .sdf
            extension = os.path.splitext(molecule)[1]
            if extension in [".sdf", ".mol2"]:
                # Split the mol file
                molsPaths = split_molecules(molecule)
                # For each molecule
                for index, molPath in enumerate(molsPaths, start=1):
                    # Get molecule name
                    base_name = os.path.splitext(os.path.basename(molecule))[0]
                    name = f"{base_name}_{index}"
                    # Append to the list
                    ligands.append(Ligand(molPath, name=name))
            else:
                # This case the return code is suppressed because it is needed to return None in case of failure
                _ = ocerror.Error.wrong_type(message=f"The molecule file MUST be the .sdf format!", level=ocerror.ReportLevel.WARNING)
        else:
            # File does not exist
            _ = ocerror.Error.wrong_type(message=f"The molecule MUST be either a file path or rdkit.Chem.rdchem.Mol!", level=ocerror.ReportLevel.WARNING)
    elif isinstance(molecule, Chem.rdchem.Mol):
        name = molecule.GetProp("_Name") if molecule.HasProp("_Name") else "ligand"
        ligands.append(Ligand(molecule, name=name))
    else:
        # This case the return code is suppressed because it is needed to return None in case of failure
        _ = ocerror.Error.wrong_type(message=f"The molecule file path MUST be a string!", level=ocerror.ReportLevel.WARNING)

    return ligands


@overload
def read_descriptors_from_json(path: str, return_data: Literal[True]) -> Optional[Dict[str, Union[str, float, int]]]:
    ...


@overload
def read_descriptors_from_json(path: str, return_data: Literal[False] = False) -> Optional[Tuple[Union[str, float, int], ...]]:
    ...


def read_descriptors_from_json(path: str, return_data: bool = False) -> Optional[Union[Dict[str, Union[str, float, int]], Tuple[Union[str, float, int], ...]]]:
    ''' Read the descriptors from a JSON file.

    Parameters
    ----------
    path : str
        The path to the JSON file.
    return_data : bool, optional
        If True, returns a dictionary with the descriptors. If False, returns a dictionary with the descriptors, by default False.

    Returns
    -------
    Dict[str, str | float | int]] | Tuple[str | float | int]] | None
        The descriptors or None if an error occurs.
    '''

    try:
        with open(path, 'r') as f:
            data = json.load(f)

        # Construct the list of expected keys
        keys = ["Name"] + Ligand.allDescriptors

        # Check for missing keys
        missing_keys = [key for key in keys if key not in data]
        if missing_keys:
            # User-facing error: missing required data in JSON file
            ocerror.Error.data_not_found(f"Missing keys in JSON file '{path}': {', '.join(missing_keys)}")
            return None

        if return_data:
            # Rename 'Name' to 'Ligand' and remove 'Path' if they exist
            if 'Name' in data:
                data['Ligand'] = data.pop('Name')
            data.pop('Path', None)  # Remove 'Path' if it exists

            return cast(Dict[str, Union[str, float, int]], data)

        # If not returning as data, return tuple of values
        return cast(Tuple[Union[str, float, int], ...], tuple(data[key] for key in keys))

    except KeyError as e:
        # This should rarely happen now since we check for missing keys above
        # But keep it as a fallback for other KeyError cases
        ocerror.Error.value_error(f"Error: {e}")
    except Exception as e:
        ocerror.Error.read_file(f"Could not read the file '{path}'. Error: {e}")

    return None


def split_molecules(molecule: str, output_dir: str = "", prefix: str = "ligand") -> List[str]:
    ''' Given a molecule file, checks if it has more than one ligand, if positive, splits the file into multiple single molecule files. Uses openbabel python library. TODO: Make this function work better with the new database structure.

    Parameters
    ----------
    molecule : str
        The path to the molecule file.
    output_dir : str, optional
        The path to the output directory, by default ""
    prefix : str, optional
        The prefix for the output files, by default "ligand"

    Returns
    -------
    List[str]
        A list of paths to the new files.
    '''

    # Initialise an empty list to hold all files paths
    ligand_files = []
    # Grab the extension and path
    extension = ocvalidation.validate_obabel_extension(molecule)

    # If the output_dir is not defined
    if not output_dir:
        # Set it as the same dir as the ligand
        output_dir = f"{os.path.split(os.path.abspath(molecule))[0]}/compounds"

    # Ensure output directory exists
    if not os.path.exists(output_dir):
        _ = ocff.safe_create_dir(output_dir)

    # Check if the extension is valid
    if type(extension) != str:
        ocprint.print_error(f"Problems while reading the ligand file '{molecule}'.")
    else:
        # Create the conversion object
        obConversion = openbabel.OBConversion()
        # Set the input/output format
        obConversion.SetInAndOutFormats(extension, "mol2")
        # Create the OBMol object
        mol = openbabel.OBMol()
        # Read the first molecule
        molecules = obConversion.ReadFile(mol, molecule)
        # Counter for files
        molNum = 1
        # For each molecule in the file
        while molecules:
            out_path = f"{output_dir}/{prefix}_{molNum}.mol2"
            # Write the mol object to the output performing the conversion
            wrote = obConversion.WriteFile(mol, out_path)
            if not wrote:
                _ = ocerror.Error.write_file(
                    f"Could not write split molecule file '{out_path}'.",
                    level = ocerror.ReportLevel.WARNING
                )
            # Recreate mol object
            mol = openbabel.OBMol()
            # Read it again
            molecules = obConversion.Read(mol)
            # Increase the counter
            molNum += 1
            # Add the path to the ligand_files list
            if wrote:
                ligand_files.append(out_path)

    return ligand_files


# Factory functions and dynamic methods
##############################################################################





# Using the factory function to create the descriptor functions add them to the global namespace and to the Ligand class
for desc in Ligand.allDescriptors:
    # Set the description
    func_description = f"Compute the {desc} descriptor for the Ligand object.\n\n    Parameters\n    ----------\n    molecule : rdkit.Chem.rdchem.Mol\n        The molecule to be evaluated.\n\n    Returns\n    -------\n    float | None\n        The {desc} value or None if parsing the descriptor fails."
    # Create the function using the factory
    func = __descriptor_function_factory(desc)
    # Set the docstring
    func.__doc__ = func_description
    # Add the function to the global namespace with the desired name
    globals()[f'find{desc}'] = func

    # Assemble the function name
    func_name = f'find{desc}'
    # Create the function using the factory
    class_func = __descriptor_function_factory_class(desc)
    # Set the docstring
    class_func.__doc__ = func_description
    # Add the function to the Ligand class
    setattr(Ligand, func_name, class_func)
