#!/usr/bin/env python3

# Description
###############################################################################
'''
Unified command-line interface for OCDocker tasks.

Usage:

import OCDocker.CLI as occli

Main commands
- version: prints library version.
- manifest: emits a reproducibility manifest with runtime/tool/package versions.
- init-config: creates a quick `OCDocker.cfg` or `OCDocker.yml` from the example file.
- vs: runs docking and optional rescoring for one receptor/ligand/box using Vina, Smina, or PLANTS.
- shap: delegates to existing OCScore SHAP CLI.
- pipeline: full multi-engine flow — run docking across engines, cluster poses by RMSD,
            pick the representative pose (medoid of the largest cluster), rescore and export results.

Global options
- --conf, --multiprocess, --update-databases, --output-level, --overwrite, --no-splash:
  compatible with OCDocker.Initialise and used to bootstrap the environment.

Modules
-------
- __init__: CLI entry points, command parsing, and dispatch.
'''

# Imports
###############################################################################
from __future__ import annotations

import argparse
import importlib
import json
import math
import numbers
import os
import platform
import shlex
import shutil
import subprocess
import sys
import time

from datetime import datetime, timezone
from glob import glob
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import OCDocker.Toolbox.Security as ocsec

# License
###############################################################################
'''
OCDocker
Authors: Rossi, A.D.; Monachesi, M.C.E.; Spelta, G.I.; Torres, P.H.M.
Federal University of Rio de Janeiro
Carlos Chagas Filho Institute of Biophysics
Laboratory for Molecular Modeling and Dynamics

This program is proprietary software owned by the Federal University of Rio de Janeiro (UFRJ),
developed by Rossi, A.D.; Monachesi, M.C.E.; Spelta, G.I.; Torres, P.H.M., and protected under Brazilian Law No. 9,609/1998.
All rights reserved. Use, reproduction, modification, and distribution are allowed under this UFRJ license,
provided this copyright notice is preserved. See the LICENSE file for details.

Contact: Artur Duque Rossi - arturossi10@gmail.com
'''

__all__ = ['main', 'generate_reproducibility_manifest']

# Classes
###############################################################################


# Functions
###############################################################################
## Private ##

def _bootstrap_ocdocker_env(ns: argparse.Namespace) -> None:
    '''Bootstrap OCDocker.Initialise explicitly (no import-time side effects).

    - Set `OCDOCKER_CONFIG` env var if provided
    - Call `OCDocker.Initialise.bootstrap(ns)`

    Parameters
    ----------
    ns : argparse.Namespace
        Parsed command-line arguments.
    '''

    if ns.config_file:
        os.environ["OCDOCKER_CONFIG"] = ns.config_file
    init_db = bool(getattr(ns, "_ocdocker_init_db", True))
    init_mod = importlib.import_module("OCDocker.Initialise")
    if hasattr(init_mod, "bootstrap"):
        try:
            init_mod.bootstrap(ns, init_db=init_db)
        except TypeError as exc:
            # Backward compatibility for bootstrap implementations that only
            # accept the legacy signature bootstrap(ns).
            if "init_db" in str(exc):
                init_mod.bootstrap(ns)
            else:
                raise
    else:
        raise RuntimeError("OCDocker.Initialise.bootstrap not found")


def _print_optional_dependency_hint(
    *,
    feature: str,
    extra: str,
    exc: ModuleNotFoundError,
) -> int:
    '''Print a concise optional dependency hint and return CLI error code.

    Parameters
    ----------
    feature : str
        User-facing feature name that failed.
    extra : str
        Extra name to suggest in pip install hint.
    exc : ModuleNotFoundError
        Original missing dependency exception.

    Returns
    -------
    int
        Exit code for CLI command failures caused by missing dependencies.
    '''

    missing = getattr(exc, "name", "") or "unknown"
    print(f"Error: missing optional dependency '{missing}' required for {feature}.")
    print(f"Install with: pip install \"ocdocker[{extra}]\"")
    return 2


def _suggest_extra_for_missing_module(module_name: str) -> str:
    '''Map missing module names to a recommended pip extra.'''

    mod = (module_name or "").strip()
    if (
        mod.startswith("optuna")
        or mod.startswith("torch")
        or mod.startswith("torchaudio")
        or mod.startswith("torchvision")
        or mod.startswith("xgboost")
        or mod.startswith("torchsummary")
        or mod.startswith("torchviz")
        or mod.startswith("visualtorch")
    ):
        return "ml"
    if mod.startswith("sqlalchemy") or mod.startswith("psycopg") or mod.startswith("pymysql"):
        return "db"
    if mod.startswith("rdkit") or mod.startswith("Bio") or mod.startswith("openbabel") or mod.startswith("spyrmsd"):
        return "docking"
    return "all"


def _db_dependencies_available() -> Tuple[bool, Optional[ModuleNotFoundError]]:
    '''Return whether required DB runtime dependencies are importable.'''

    required_modules = ("sqlalchemy", "sqlalchemy_utils")
    for module_name in required_modules:
        try:
            importlib.import_module(module_name)
        except ModuleNotFoundError as exc:
            return False, exc
    return True, None


def _box_sort_key(path: Path) -> Tuple[int, object]:
    '''Sorting key for box files.

    Boxes named boxN.pdb (N=number) come first, sorted by N. Other names come later, sorted alphabetically.

    Parameters
    ----------
    path : Path
        The box file path.

    Returns
    -------
    Tuple[int, object]
        Sorting key.
    '''

    stem = path.stem.lower()
    if stem.startswith("box"):
        suffix = stem[3:]
        if suffix.isdigit():
            return (0, int(suffix))
    return (1, stem)

def _ensure_mol2_poses(pose_paths: List[str], dest_dir: Path, pose_engine_map: Optional[Dict[str, str]] = None) -> Tuple[List[str], Dict[str, str]]:
    '''Ensure a list of poses in MOL2 format, converting when needed.

    Returns a list of .mol2 paths and a mapping mol2->original path.
    Uses unique filenames based on engine source to avoid overwriting.

    Parameters
    ----------
    pose_paths : List[str]
        List of pose file paths to ensure are in MOL2 format.
    dest_dir : Path
        Destination directory for converted MOL2 files.
    pose_engine_map : Dict[str, str], optional
        Mapping from pose path to engine name (vina, smina, plants) to create unique filenames.

    Returns
    -------
    Tuple[List[str], Dict[str, str]]
        A tuple containing a list of .mol2 paths and a mapping from mol2 paths to original paths.
    '''

    dest_dir.mkdir(parents=True, exist_ok=True)
    mol2_paths: List[str] = []
    mapping: Dict[str, str] = {}

    import OCDocker.Toolbox.Conversion as occonversion
    for p in pose_paths:
        src = Path(p)
        if src.suffix.lower() == ".mol2":
            # Already MOL2 - use as-is but track mapping
            mol2_paths.append(str(src))
            mapping[str(src)] = str(src)
            continue

        # Create unique filename based on engine and original filename
        engine = pose_engine_map.get(str(src), "unknown") if pose_engine_map else "unknown"
        # Include engine in filename to avoid collisions
        unique_name = f"{engine}_{src.stem}.mol2"
        out = dest_dir / unique_name
        _ = occonversion.convert_mols(str(src), str(out), overwrite=True)
        mol2_paths.append(str(out))
        mapping[str(out)] = str(src)
    return mol2_paths, mapping


def _list_boxes(ligand_dir: Path, box_path: Path, all_boxes: bool) -> List[Path]:
    '''List box files to use.

    Parameters
    ----------
    ligand_dir : Path
        Directory containing the ligand file.
    box_path : Path
        Path to the primary box file.
    all_boxes : bool
        Whether to use all box*.pdb files in ligand_dir and box_path.parent.

    Returns
    -------
    List[Path]
        List of box file paths.
    '''

    if not all_boxes:
        return [box_path]

    candidates: List[Path] = []
    for d in {ligand_dir, box_path.parent}:
        candidates.extend(Path(p) for p in glob(str(d / "box*.pdb")))
    if box_path.is_file():
        candidates.append(box_path)

    unique: Dict[str, Path] = {}
    for p in candidates:
        try:
            unique[str(p.resolve())] = p
        except OSError:
            unique[str(p)] = p

    boxes = list(unique.values())
    boxes.sort(key=_box_sort_key)
    return boxes


def _is_integer_descriptor_name(descriptor: str) -> bool:
    '''Return True when a descriptor is expected to be integer-like.'''

    name = descriptor.strip()
    return (
        name.startswith("fr_")
        or name.startswith("Num")
        or name.startswith("count")
        or name in {"HeavyAtomCount", "NHOHCount", "NOCount", "RingCount", "TotalAALength"}
    )


def _to_numeric(value: Any) -> Optional[float]:
    '''Convert numeric-like values to finite float, otherwise return None.'''

    if isinstance(value, bool):
        return float(int(value))
    if not isinstance(value, numbers.Real):
        return None
    numeric_value = float(value)
    if math.isnan(numeric_value) or math.isinf(numeric_value):
        return None
    return numeric_value


def _rescoring_data_has_numeric_scores(data: Dict[str, Any]) -> bool:
    '''Check whether rescoring payload has at least one finite numeric score.

    Parameters
    ----------
    data : Dict[str, Any]
        Parsed rescoring payload keyed by rescoring label.

    Returns
    -------
    bool
        True when at least one score is numeric and finite, otherwise False.
    '''

    for raw_value in data.values():
        if _to_numeric(raw_value) is not None:
            return True
        if isinstance(raw_value, (list, tuple)):
            for item in raw_value:
                if _to_numeric(item) is not None:
                    return True
    return False


def _collect_log_file_signatures(paths: List[str]) -> Tuple[Dict[str, Tuple[int, int]], bool]:
    '''Collect file signatures for rescoring logs.

    Parameters
    ----------
    paths : List[str]
        Candidate rescoring log paths.

    Returns
    -------
    Tuple[Dict[str, Tuple[int, int]], bool]
        Mapping ``path -> (size_bytes, mtime_ns)`` for files that could be
        stat-ed, plus a flag that indicates at least one unstable/missing path.
    '''

    signatures: Dict[str, Tuple[int, int]] = {}
    has_unstable_paths = False

    for raw_path in sorted(set(paths)):
        path = str(raw_path)
        try:
            stat_result = os.stat(path)
            mtime_ns = int(getattr(stat_result, "st_mtime_ns", int(stat_result.st_mtime * 1_000_000_000)))
            signatures[path] = (int(stat_result.st_size), mtime_ns)
        except (FileNotFoundError, PermissionError, OSError):
            has_unstable_paths = True

    return signatures, has_unstable_paths


def _wait_for_rescore_logs_ready(
    get_log_paths: Callable[[str], List[str]],
    read_log_data: Callable[..., Dict[str, Any]],
    out_dir: str,
    *,
    timeout_seconds: float = 2.0,
    poll_interval_seconds: float = 0.05,
) -> Tuple[List[str], Dict[str, Any], bool]:
    '''Wait for rescoring logs to become available and parse-ready.

    Polls log discovery and parsing helpers until either:
    1) at least one finite numeric score is parsed; or
    2) the timeout is reached.

    Parameters
    ----------
    get_log_paths : Callable[[str], List[str]]
        Function that returns rescoring log paths for an output directory.
    read_log_data : Callable[..., Dict[str, Any]]
        Function that parses rescoring logs and returns score data.
    out_dir : str
        Output directory where rescoring logs are expected.
    timeout_seconds : float, optional
        Maximum wait time before giving up. By default 2.0.
    poll_interval_seconds : float, optional
        Delay between polling attempts. By default 0.05.

    Returns
    -------
    Tuple[List[str], Dict[str, Any], bool]
        Tuple with the most recent log paths, parsed data snapshot, and a
        readiness flag indicating whether parse-ready numeric data was found.
    '''

    deadline = time.monotonic() + max(0.0, float(timeout_seconds))
    base_poll_interval = max(0.0, float(poll_interval_seconds))
    max_poll_interval = max(base_poll_interval, 0.5)
    last_paths: List[str] = []
    last_data: Dict[str, Any] = {}
    last_signatures: Dict[str, Tuple[int, int]] = {}
    stable_poll_count = 0

    while True:
        try:
            current_paths = sorted(str(path) for path in (get_log_paths(out_dir) or []))
        except Exception:
            current_paths = []

        if current_paths:
            current_signatures, has_unstable_paths = _collect_log_file_signatures(current_paths)
            paths_changed = current_paths != last_paths
            signatures_changed = current_signatures != last_signatures
            should_reparse = paths_changed or signatures_changed or has_unstable_paths or not last_data

            last_paths = list(current_paths)
            last_signatures = current_signatures

            if should_reparse:
                try:
                    current_data = read_log_data(current_paths, onlyBest=True) or {}
                except Exception:
                    current_data = {}

                if current_data:
                    last_data = current_data
                    if _rescoring_data_has_numeric_scores(current_data):
                        return last_paths, last_data, True
                stable_poll_count = 0
            else:
                stable_poll_count += 1
        else:
            stable_poll_count = 0
            last_signatures = {}

        if time.monotonic() >= deadline:
            return last_paths, last_data, False

        sleep_interval = base_poll_interval
        if base_poll_interval > 0.0 and stable_poll_count > 0:
            sleep_interval = min(max_poll_interval, base_poll_interval * (2 ** min(stable_poll_count, 4)))
        time.sleep(sleep_interval)


def _collect_numeric_descriptors(obj: Any, descriptor_names: List[str]) -> Dict[str, Union[int, float]]:
    '''Extract numeric descriptor values from an object into a payload dict.'''

    payload: Dict[str, Union[int, float]] = {}
    for descriptor in descriptor_names:
        if not hasattr(obj, descriptor):
            continue
        numeric_value = _to_numeric(getattr(obj, descriptor))
        if numeric_value is None:
            continue
        if _is_integer_descriptor_name(descriptor):
            payload[descriptor] = int(numeric_value)
        else:
            payload[descriptor] = numeric_value
    return payload


def _map_score_to_complex_column(raw_key: str) -> Optional[str]:
    '''Map raw rescoring keys to Complexes table descriptor columns.'''

    key = raw_key.strip().lower()
    key = key.replace("-", "_").replace(" ", "_").replace(".", "_")
    while "__" in key:
        key = key.replace("__", "_")

    direct_map = {
        "vina_vina": "VINA_VINA",
        "vina_vinardo": "VINA_VINARDO",
        "smina_vina": "SMINA_VINA",
        "smina_vinardo": "SMINA_VINARDO",
        "smina_scoring_dkoes": "SMINA_SCORING_DKOES",
        "smina_dkoes_scoring": "SMINA_SCORING_DKOES",
        "smina_old_scoring_dkoes": "SMINA_OLD_SCORING_DKOES",
        "smina_dkoes_scoring_old": "SMINA_OLD_SCORING_DKOES",
        "smina_fast_dkoes": "SMINA_FAST_DKOES",
        "smina_dkoes_fast": "SMINA_FAST_DKOES",
        "smina_scoring_ad4": "SMINA_SCORING_AD4",
        "smina_ad4_scoring": "SMINA_SCORING_AD4",
        # Keep Gnina mapping hardcoded like other engines, matching gnina_scoring_functions defaults.
        "gnina_ad4_scoring": "GNINA_AD4_SCORING",
        "gnina_scoring_ad4": "GNINA_AD4_SCORING",
        "gnina_ad4": "GNINA_AD4_SCORING",
        "gnina_default": "GNINA_DEFAULT",
        "gnina_dkoes_fast": "GNINA_DKOES_FAST",
        "gnina_fast_dkoes": "GNINA_DKOES_FAST",
        "gnina_dkoes_scoring": "GNINA_DKOES_SCORING",
        "gnina_scoring_dkoes": "GNINA_DKOES_SCORING",
        "gnina_dkoes": "GNINA_DKOES_SCORING",
        "gnina_dkoes_scoring_old": "GNINA_DKOES_SCORING_OLD",
        "gnina_old_scoring_dkoes": "GNINA_DKOES_SCORING_OLD",
        "gnina_vina": "GNINA_VINA",
        "gnina_vinardo": "GNINA_VINARDO",
        "plants_chemplp": "PLANTS_CHEMPLP",
        "plants_plp": "PLANTS_PLP",
        "plants_plp95": "PLANTS_PLP95",
        "oddt_plecrf_p5_l1_s65536": "ODDT_PLECRF_P5_L1_S65536",
        "oddt_nnscore": "ODDT_NNSCORE",
        "oddt_rfscore_v1": "ODDT_RFSCORE_V1",
        "oddt_rfscore_v2": "ODDT_RFSCORE_V2",
        "oddt_rfscore_v3": "ODDT_RFSCORE_V3",
    }
    if key in direct_map:
        return direct_map[key]

    # ODDT can emit several naming variants (e.g. rfscore_v1_pdbbind2016, plecrf_*).
    oddt_key = key[5:] if key.startswith("oddt_") else key
    if "rfscore_v1" in oddt_key or oddt_key.endswith("rfscore1"):
        return "ODDT_RFSCORE_V1"
    if "rfscore_v2" in oddt_key or oddt_key.endswith("rfscore2"):
        return "ODDT_RFSCORE_V2"
    if "rfscore_v3" in oddt_key or oddt_key.endswith("rfscore3"):
        return "ODDT_RFSCORE_V3"
    if "plec" in oddt_key:
        return "ODDT_PLECRF_P5_L1_S65536"
    if "nnscore" in oddt_key:
        return "ODDT_NNSCORE"

    return None


def _flatten_rescoring_to_complex_payload(rescoring: Dict[str, Dict[str, float]]) -> Tuple[Dict[str, float], List[str]]:
    '''Flatten nested rescoring output into Complexes column payload.'''

    payload: Dict[str, float] = {}
    ignored_keys: List[str] = []

    for engine_scores in rescoring.values():
        if not isinstance(engine_scores, dict):
            continue
        for raw_key, raw_value in engine_scores.items():
            numeric_value = _to_numeric(raw_value)
            if numeric_value is None:
                continue
            column = _map_score_to_complex_column(str(raw_key))
            if not column:
                ignored_keys.append(str(raw_key))
                continue
            payload[column] = numeric_value

    # Keep ignored keys stable and deduplicated for user-facing warnings.
    ignored_keys = sorted(set(ignored_keys))
    return payload, ignored_keys


def _store_pipeline_results_in_db(
    job_name: str,
    receptor: Any,
    ligand: Any,
    rescoring: Dict[str, Dict[str, float]],
    box_label: Optional[str] = None,
) -> Tuple[bool, str, List[str]]:
    '''Store pipeline run data into DB tables (Receptors, Ligands, Complexes).'''

    from OCDocker.DB.DB import create_tables
    from OCDocker.DB.Models.Complexes import Complexes
    from OCDocker.DB.Models.Ligands import Ligands
    from OCDocker.DB.Models.Receptors import Receptors

    create_tables()

    receptor_name = str(getattr(receptor, "name", "") or f"{job_name}_receptor")
    ligand_name = str(getattr(ligand, "name", "") or f"{job_name}_ligand")

    receptor_payload: Dict[str, Union[str, int, float]] = {"name": receptor_name}
    receptor_payload.update(_collect_numeric_descriptors(receptor, list(getattr(Receptors, "allDescriptors", []))))

    ligand_payload: Dict[str, Union[str, int, float]] = {"name": ligand_name}
    ligand_payload.update(_collect_numeric_descriptors(ligand, list(getattr(Ligands, "allDescriptors", []))))

    receptor_ok = Receptors.insert_or_update(receptor_payload)
    ligand_ok = Ligands.insert_or_update(ligand_payload)
    if not receptor_ok or not ligand_ok:
        return False, "", []

    receptor_row = Receptors.find_first(receptor_name)
    ligand_row = Ligands.find_first(ligand_name)
    receptor_id = getattr(receptor_row, "id", None)
    ligand_id = getattr(ligand_row, "id", None)

    complex_name = f"{job_name}_{box_label}" if box_label else job_name
    complex_payload: Dict[str, Union[str, int, float]] = {"name": complex_name}
    if isinstance(receptor_id, int):
        complex_payload["receptor_id"] = receptor_id
    if isinstance(ligand_id, int):
        complex_payload["ligand_id"] = ligand_id

    score_payload, ignored_keys = _flatten_rescoring_to_complex_payload(rescoring)
    complex_payload.update(score_payload)

    complex_ok = Complexes.insert_or_update(complex_payload)
    return bool(complex_ok), complex_name, ignored_keys


def _preparse_global_args(argv: list[str]) -> argparse.Namespace:
    '''Extract global flags from anywhere in argv.

    Works around argparse limitation when global options appear after the subcommand.

    Parameters
    ----------
    argv : list[str]
        Command-line arguments.

    Returns
    -------
    argparse.Namespace
        Parsed global arguments.
    '''

    ns = argparse.Namespace(
        version=False,
        multiprocess=True,
        update=False,
        config_file=None,
        output_level=1,
        overwrite=False,
        log_file=None,
        no_stdout_log=False,
        no_splash=False,
    )

    i = 0
    while i < len(argv):
        tok = argv[i]
        if tok == "--version":
            ns.version = True
            i += 1
            continue
        if tok == "--multiprocess":
            ns.multiprocess = True
            i += 1
            continue
        if tok == "--no-multiprocess":
            ns.multiprocess = False
            i += 1
            continue
        if tok in ("-u", "--update-databases"):
            ns.update = True
            i += 1
            continue
        if tok == "--conf" and i + 1 < len(argv):
            ns.config_file = argv[i + 1]
            i += 2
            continue
        if tok == "--output-level" and i + 1 < len(argv):
            try:
                ns.output_level = int(argv[i + 1])
            except (ValueError, TypeError):
                # Ignore invalid output level values
                pass
            i += 2
            continue
        if tok == "--overwrite":
            ns.overwrite = True
            i += 1
            continue
        if tok == "--log-file" and i + 1 < len(argv):
            ns.log_file = argv[i + 1]
            i += 2
            continue
        if tok == "--no-stdout-log":
            ns.no_stdout_log = True
            i += 1
            continue
        if tok == "--no-splash":
            ns.no_splash = True
            i += 1
            continue
        # skip token
        i += 1
    return ns


def _require_file(p: str, label: str) -> Path:
    '''Ensure a file path exists. Print a helpful message and exit if not.

    Also warns if the path seems to contain a Unicode ellipsis (…)
    which is often a placeholder, not a real path.

    Parameters
    ----------
    p : str
        The file path to check.
    label : str
        A label for the file path (used in error messages).

    Returns
    -------
    Path
        The resolved file path.

    Raises
    ------
    SystemExit
        If the file path is invalid or not found.
    '''

    if "…" in p:
        print(f"Error: {label} contains an ellipsis character (…). Replace it with a real path.")
        raise SystemExit(2)
    path = Path(p).resolve()
    if not path.is_file():
        print(f"Error: {label} file not found: {p}")
        raise SystemExit(2)
    return path


def _extract_executable_token(command: Optional[str]) -> Optional[str]:
    '''Extract the executable token from a command string.

    Parameters
    ----------
    command : Optional[str]
        Command string or executable path.

    Returns
    -------
    Optional[str]
        The executable token, or None when unavailable.
    '''

    if not command:
        return None
    expanded = os.path.expandvars(os.path.expanduser(str(command))).strip()
    if not expanded:
        return None
    try:
        parts = shlex.split(expanded)
    except ValueError:
        # Fallback for malformed quoted strings
        parts = [expanded]
    return parts[0] if parts else None


def _resolve_executable(command: Optional[str]) -> Optional[str]:
    '''Resolve an executable from a configured command string.

    Parameters
    ----------
    command : Optional[str]
        Command string or executable path.

    Returns
    -------
    Optional[str]
        Absolute path to executable when found, else None.
    '''

    token = _extract_executable_token(command)
    if not token:
        return None

    if os.path.isabs(token):
        return token if (os.path.isfile(token) and os.access(token, os.X_OK)) else None

    return shutil.which(token)


def _probe_executable_version(executable: Optional[str]) -> str:
    '''Probe an external executable version string.

    Parameters
    ----------
    executable : Optional[str]
        Absolute path or executable name.

    Returns
    -------
    str
        A short version string, or "unknown" when probing fails.
    '''

    if not executable:
        return "unknown"

    probe_args = (
        ("--version",),
        ("-version",),
        ("version",),
        ("-v",),
    )

    for arg_list in probe_args:
        try:
            completed = subprocess.run(
                [executable, *arg_list],
                capture_output=True,
                text=True,
                check=False,
                timeout=5,
            )
        except (OSError, ValueError, subprocess.SubprocessError):
            continue

        raw = "\n".join([completed.stdout or "", completed.stderr or ""]).strip()
        if not raw:
            continue
        first_line = next((line.strip() for line in raw.splitlines() if line.strip()), "")
        if first_line:
            return first_line[:240]

    return "unknown"


def _collect_tool_candidates() -> Dict[str, Optional[str]]:
    '''Collect configured command candidates for core external tools.

    Returns
    -------
    Dict[str, Optional[str]]
        Mapping tool name -> configured command/path candidate.
    '''

    candidates: Dict[str, Optional[str]] = {
        "vina": "vina",
        "smina": "smina",
        "plants": "plants",
        "gnina": "gnina",
        "pythonsh": "pythonsh",
        "dssp": "dssp",
        "obabel": "obabel",
        "spores": "spores",
    }

    try:
        from OCDocker.Config import get_config

        cfg = get_config()
        candidates["vina"] = getattr(cfg.vina, "executable", None) or candidates["vina"]
        candidates["smina"] = getattr(cfg.smina, "executable", None) or candidates["smina"]
        candidates["plants"] = getattr(cfg.plants, "executable", None) or candidates["plants"]
        candidates["gnina"] = getattr(cfg.gnina, "executable", None) or candidates["gnina"]
        candidates["pythonsh"] = getattr(cfg.tools, "pythonsh", None) or candidates["pythonsh"]
        candidates["dssp"] = getattr(cfg.tools, "dssp", None) or candidates["dssp"]
        candidates["obabel"] = getattr(cfg.tools, "obabel", None) or candidates["obabel"]
        candidates["spores"] = getattr(cfg.tools, "spores", None) or candidates["spores"]
    except (ImportError, AttributeError, RuntimeError, TypeError, ValueError, KeyError):
        # Fall back to common executable names
        pass

    return candidates


def _collect_external_tool_manifest() -> Dict[str, Dict[str, Union[str, bool, None]]]:
    '''Collect external tool availability and version details.

    Returns
    -------
    Dict[str, Dict[str, Union[str, bool, None]]]
        Per-tool metadata with configured command, resolved path, availability, and version.
    '''

    manifest: Dict[str, Dict[str, Union[str, bool, None]]] = {}
    for tool_name, configured in _collect_tool_candidates().items():
        resolved = _resolve_executable(configured)
        manifest[tool_name] = {
            "configured": configured,
            "resolved": resolved,
            "available": bool(resolved),
            "version": _probe_executable_version(resolved),
        }
    return manifest


def _collect_python_package_versions() -> Dict[str, str]:
    '''Collect installed Python distribution versions.

    Returns
    -------
    Dict[str, str]
        Mapping distribution name -> version.
    '''

    packages: Dict[str, str] = {}
    try:
        from importlib.metadata import distributions
    except (ImportError, AttributeError):
        return packages

    for dist in distributions():
        try:
            name: Optional[str]
            try:
                name = dist.metadata["Name"]
            except KeyError:
                name = getattr(dist, "name", None)
            version = str(dist.version)
            if not name:
                continue
            packages[str(name)] = version
        except (AttributeError, TypeError, ValueError):
            continue

    return dict(sorted(packages.items(), key=lambda item: item[0].lower()))


def _collect_ocdocker_version() -> str:
    '''Collect OCDocker package version from import or metadata fallback.

    Returns
    -------
    str
        OCDocker version string or "unknown".
    '''

    try:
        import OCDocker as _oc

        value = getattr(_oc, "__version__", None)
        if value:
            return str(value)
    except (ImportError, AttributeError):
        pass

    try:
        from importlib.metadata import version as _pkg_version

        return str(_pkg_version("OCDocker"))
    except Exception:
        return "unknown"


def _collect_git_manifest() -> Dict[str, Optional[Union[str, bool]]]:
    '''Collect source control metadata when available.

    Returns
    -------
    Dict[str, Optional[Union[str, bool]]]
        Git metadata (best-effort).
    '''

    repo_root = Path(__file__).resolve().parents[2]

    def _run_git(args: List[str]) -> Optional[str]:
        try:
            completed = subprocess.run(
                ["git", "-C", str(repo_root), *args],
                capture_output=True,
                text=True,
                check=False,
                timeout=3,
            )
        except (OSError, ValueError, subprocess.SubprocessError):
            return None
        if completed.returncode != 0:
            return None
        return completed.stdout.strip()

    commit = _run_git(["rev-parse", "HEAD"])
    branch = _run_git(["rev-parse", "--abbrev-ref", "HEAD"])
    status = _run_git(["status", "--porcelain"])

    return {
        "commit": commit,
        "branch": branch,
        "dirty": bool(status) if status is not None else None,
    }


## Public ##

def generate_reproducibility_manifest(include_python_packages: bool = True) -> Dict[str, Any]:
    '''Generate a reproducibility manifest with environment and version metadata.

    Parameters
    ----------
    include_python_packages : bool, optional
        Whether to include the full installed Python package list, by default True.

    Returns
    -------
    Dict[str, Any]
        Reproducibility manifest data.
    '''

    manifest: Dict[str, Any] = {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "ocdocker": {
            "version": _collect_ocdocker_version(),
        },
        "python": {
            "version": platform.python_version(),
            "implementation": platform.python_implementation(),
            "executable": sys.executable,
        },
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
        },
        "environment": {
            "OCDOCKER_CONFIG": os.getenv("OCDOCKER_CONFIG"),
            "OCDOCKER_DB_BACKEND": os.getenv("OCDOCKER_DB_BACKEND"),
            "DB_BACKEND": os.getenv("DB_BACKEND"),
            "OCDOCKER_SQLITE_PATH": os.getenv("OCDOCKER_SQLITE_PATH"),
            "OCDOCKER_TIMEOUT": os.getenv("OCDOCKER_TIMEOUT"),
        },
        "external_tools": _collect_external_tool_manifest(),
        "git": _collect_git_manifest(),
    }

    if include_python_packages:
        packages = _collect_python_package_versions()
        manifest["python_packages"] = packages
        manifest["python_package_count"] = len(packages)

    return manifest

def build_parser() -> argparse.ArgumentParser:
    '''Build the main argument parser with subcommands.

    Returns
    -------
    argparse.ArgumentParser
        The constructed argument parser.
    '''

    parser = argparse.ArgumentParser(
        prog="ocdocker",
        description=(
            "OCDocker CLI: Unified command-line interface for molecular docking, virtual screening, and analysis.\n\n"
            "Main commands:\n"
            "  vs        - Single-engine docking with rescoring of all poses\n"
            "  pipeline  - Multi-engine consensus docking with clustering and representative pose selection\n"
            "  shap      - SHAP analysis for model interpretability\n"
            "  console   - Interactive Python console with OCDocker pre-loaded\n"
            "  script    - Run a Python script with OCDocker libraries pre-loaded\n"
            "  doctor    - Environment diagnostics and setup verification\n"
            "  init-config - Create starter configuration file\n"
            "  manifest  - Generate reproducibility manifest with version metadata\n"
            "  version   - Print version information\n\n"
            "Use 'ocdocker <command> --help' for detailed information about each command."
        ),
        epilog=(
            "Note: SQLite backend is intended for development/tests. "
            "For production workloads (performance/concurrency), use PostgreSQL (default) or MySQL."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # Global options (mirrors OCDocker.Initialise)
    parser.add_argument(
        "--multiprocess",
        dest="multiprocess",
        action="store_true",
        default=True,
        help="Enable multiprocessing for supported tasks. Allows parallel execution when possible. Default: enabled"
    )
    parser.add_argument(
        "--no-multiprocess",
        dest="multiprocess",
        action="store_false",
        help="Disable multiprocessing for supported tasks. Useful for stability/debugging."
    )
    parser.add_argument(
        "-u",
        "--update-databases",
        dest="update",
        action="store_true",
        default=False,
        help="Update databases on startup. Runs database schema updates and migrations if needed."
    )
    parser.add_argument(
        "--conf",
        dest="config_file",
        type=str,
        help="Path to OCDocker configuration file (.cfg or .yml). If not specified, uses default locations or OCDOCKER_CONFIG environment variable."
    )
    parser.add_argument(
        "--output-level",
        dest="output_level",
        type=int,
        default=1,
        help="Logging verbosity level (0-5). Higher numbers provide more detailed output. 0=silent, 1=normal, 2-5=increasing verbosity. Default: 1"
    )
    parser.add_argument(
        "--overwrite",
        dest="overwrite",
        action="store_true",
        default=False,
        help="Allow overwriting existing output files. By default, existing files are preserved to prevent accidental data loss."
    )
    parser.add_argument(
        "--log-file",
        dest="log_file",
        type=str,
        default=None,
        help="Write log messages to this file in addition to stdout. Useful for saving detailed logs for later analysis."
    )
    parser.add_argument(
        "--no-stdout-log",
        dest="no_stdout_log",
        action="store_true",
        default=False,
        help="Disable logging to stdout. Only log to file if --log-file is specified. Useful for cleaner console output."
    )
    parser.add_argument(
        "--no-splash",
        dest="no_splash",
        action="store_true",
        default=False,
        help="Disable splash banner on startup."
    )

    # Parent parser to allow repeating global options after subcommand
    parent = argparse.ArgumentParser(add_help=False)
    parent.add_argument("--multiprocess", dest="multiprocess", action="store_true", default=True, help="Enable multiprocessing for supported tasks")
    parent.add_argument("--no-multiprocess", dest="multiprocess", action="store_false", help="Disable multiprocessing for supported tasks")
    parent.add_argument("-u", "--update-databases", dest="update", action="store_true", default=False, help="Update databases on startup")
    parent.add_argument("--conf", dest="config_file", type=str, help="Path to OCDocker configuration file (.cfg or .yml)")
    parent.add_argument("--output-level", dest="output_level", type=int, default=1, help="Logging verbosity level (0-5)")
    parent.add_argument("--overwrite", dest="overwrite", action="store_true", default=False, help="Allow overwriting existing output files")
    parent.add_argument("--log-file", dest="log_file", type=str, default=None, help="Write log messages to this file")
    parent.add_argument("--no-stdout-log", dest="no_stdout_log", action="store_true", default=False, help="Disable logging to stdout")
    parent.add_argument("--no-splash", dest="no_splash", action="store_true", default=False, help="Disable splash banner on startup")

    sub = parser.add_subparsers(dest="command", required=True)

    # init-config
    p_init = sub.add_parser(
        "init-config",
        description=(
            "Create a starter OCDocker.cfg or OCDocker.yml configuration file from the example template.\n"
            "This command copies the matching example template into the target config file,\n"
            "allowing you to customize paths to docking binaries, databases, and other settings."
        ),
        help="Create a starter OCDocker config file (.cfg or .yml)",
        parents=[parent]
    )
    p_init.set_defaults(func=cmd_init_config)

    # version
    p_ver = sub.add_parser(
        "version",
        description="Print the installed version of OCDocker without bootstrapping the full environment.",
        help="Print OCDocker version",
        parents=[parent]
    )
    p_ver.set_defaults(func=cmd_version)

    # manifest
    p_manifest = sub.add_parser(
        "manifest",
        description=(
            "Generate a reproducibility manifest with runtime, platform, and tool versions.\n\n"
            "This command captures OCDocker version, Python/runtime details, external tool paths\n"
            "and versions, git metadata (when available), and optionally all installed Python\n"
            "package versions. Output is JSON suitable for archiving with docking results."
        ),
        help="Generate reproducibility manifest as JSON",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        parents=[parent]
    )
    p_manifest.add_argument(
        "--output",
        default=None,
        help="Optional path to write the manifest JSON file."
    )
    p_manifest.add_argument(
        "--no-packages",
        action="store_true",
        help="Skip full Python package listing for faster/smaller output."
    )
    p_manifest.set_defaults(func=cmd_manifest)

    # vs (single-entry virtual screening)
    p_vs = sub.add_parser(
        "vs",
        description=(
            "Run docking with a single engine (Vina, Smina, Gnina, or PLANTS) and optionally rescore all poses.\n\n"
            "This command performs:\n"
            "  1. Receptor and ligand preparation\n"
            "  2. Docking with the selected engine\n"
            "  3. Pose splitting (for Vina/Smina/Gnina) into individual files\n"
            "  4. Rescoring of all generated poses (unless --skip-rescore is used)\n\n"
            "Use this mode for quick single-engine docking runs where you want all poses rescored.\n"
            "For multi-engine consensus docking with clustering, use the 'pipeline' command instead."
        ),
        help="Run docking with one engine and rescore all poses",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        parents=[parent]
    )
    p_vs.add_argument(
        "--engine",
        choices=["vina", "smina", "gnina", "plants"],
        default="vina",
        help="Docking engine to use. Options: 'vina' (AutoDock Vina), 'smina' (Vina with additional scoring functions), 'gnina' (CNN-enabled Vina-like docking), or 'plants' (PLANTS docking). Default: vina"
    )
    p_vs.add_argument(
        "--receptor",
        required=True,
        help="Path to the receptor structure file (e.g., PDB format). The receptor will be prepared automatically if needed."
    )
    p_vs.add_argument(
        "--ligand",
        required=True,
        help="Path to the ligand file. Supported formats: SMILES (.smi), SDF (.sdf), MOL2 (.mol2), or PDBQT (.pdbqt). The ligand will be prepared automatically if needed."
    )
    p_vs.add_argument(
        "--box",
        required=True,
        help="Path to the binding site box definition file (PDB format with REMARK records containing center coordinates and size). This defines the search space for docking."
    )
    p_vs.add_argument(
        "--all-boxes",
        action="store_true",
        help="Use all box*.pdb files found in the ligand directory (and the --box directory). Outputs are placed under <engine>Files/boxN/."
    )
    p_vs.add_argument(
        "--name",
        help="Job name identifier. If not provided, defaults to the ligand filename (without extension). Used for output file naming."
    )
    p_vs.add_argument(
        "--outdir",
        default="./ocdocker_out",
        help="Output directory where all results will be saved. Default: ./ocdocker_out"
    )
    p_vs.add_argument(
        "--skip-rescore",
        action="store_true",
        help="Skip the rescoring phase. Only perform docking without applying additional scoring functions. Useful for faster runs when rescoring is not needed."
    )
    p_vs.add_argument(
        "--skip-split",
        action="store_true",
        help="Skip pose splitting step (only applicable for Vina/Smina/Gnina). By default, poses are split into individual files. Use this to keep all poses in a single file."
    )
    p_vs.add_argument(
        "--timeout",
        type=int,
        default=None,
        help="Timeout in seconds for external docking tools. Overrides the OCDOCKER_TIMEOUT environment variable. If a tool exceeds this time, the process will be terminated."
    )
    p_vs.add_argument(
        "--store-db",
        action="store_true",
        help="Store run data in the database (Receptors, Ligands, Complexes) including available descriptors and supported program scores. Requires database to be configured and accessible, and optional DB deps installed (`pip install \"ocdocker[db]\"`)."
    )
    p_vs.set_defaults(func=cmd_vs)

    # shap passthrough (reuses existing module)
    p_shap = sub.add_parser(
        "shap",
        description=(
            "Run SHAP (SHapley Additive exPlanations) analysis for OCScore models.\n\n"
            "SHAP analysis provides interpretability for machine learning models by explaining\n"
            "the contribution of each feature to the model's predictions. This command delegates\n"
            "to the OCScore SHAP analysis module for detailed feature importance analysis.\n\n"
            "This is an advanced analysis tool for understanding model behavior and feature contributions."
        ),
        help="Run SHAP analysis for OCScore model interpretability",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        parents=[parent]
    )
    p_shap.add_argument(
        "--storage",
        required=True,
        help="Path to the storage directory containing study data and model files."
    )
    p_shap.add_argument(
        "--ao_study",
        required=True,
        help="Name or identifier of the atom order (AO) study to analyze."
    )
    p_shap.add_argument(
        "--nn_study",
        required=True,
        help="Name or identifier of the neural network (NN) study to analyze."
    )
    p_shap.add_argument(
        "--seed_study",
        required=True,
        help="Name or identifier of the seed study to analyze."
    )
    p_shap.add_argument(
        "--mask_study",
        required=True,
        help="Name or identifier of the mask study to analyze."
    )
    p_shap.add_argument(
        "--df_path",
        required=True,
        help="Path to the dataframe file (CSV or similar) containing the data to analyze."
    )
    p_shap.add_argument(
        "--base_models",
        required=True,
        help="Path or identifier for the base models to use for SHAP analysis."
    )
    p_shap.add_argument(
        "--study_number",
        type=int,
        required=True,
        help="Study number identifier for organizing the analysis results."
    )
    p_shap.add_argument(
        "--out_dir",
        required=True,
        help="Output directory where SHAP analysis results will be saved."
    )
    p_shap.add_argument(
        "--explainer",
        default="deep",
        choices=["deep", "kernel"],
        help="SHAP explainer type to use. 'deep' uses DeepExplainer for neural networks, 'kernel' uses KernelExplainer (more general but slower). Default: deep"
    )
    p_shap.add_argument(
        "--background_size",
        type=int,
        help="Size of the background dataset used for SHAP value computation. Larger values provide more stable estimates but take longer. If not specified, uses a default size."
    )
    p_shap.add_argument(
        "--eval_size",
        type=int,
        help="Number of samples to evaluate and compute SHAP values for. If not specified, evaluates all samples in the dataset."
    )
    p_shap.add_argument(
        "--stratify_by",
        nargs="*",
        help="Column names to stratify the dataset by when creating background/evaluation sets. Ensures balanced representation across groups."
    )
    p_shap.add_argument(
        "--seed",
        type=int,
        default=0,
        help="Random seed for reproducibility. Default: 0"
    )
    p_shap.add_argument(
        "--no_csv",
        action="store_true",
        help="Do not generate CSV output files. Only save other output formats."
    )
    p_shap.set_defaults(func=cmd_shap)

    # pipeline (multi‑engine + clustering + rescoring)
    p_pipe = sub.add_parser(
        "pipeline",
        description=(
            "Run multi-engine docking with RMSD clustering and representative pose selection.\n\n"
            "This command performs a complete workflow:\n"
            "  1. Runs docking with multiple engines (Vina, Smina, Gnina, PLANTS, or any combination)\n"
            "  2. Collects all poses from all engines\n"
            "  3. Converts poses to MOL2 format\n"
            "  4. Clusters poses by RMSD similarity\n"
            "  5. Selects the representative pose (medoid of the largest cluster)\n"
            "  6. Rescores only the representative pose (not all poses)\n"
            "  7. Saves representative.mol2 and summary.json with rescoring results\n\n"
            "Use this mode for consensus docking where you want to combine results from multiple\n"
            "engines and identify the most representative binding pose. This is more computationally\n"
            "intensive but provides better confidence in the final pose selection.\n\n"
            "Note: Only the representative pose is rescored, unlike 'vs' which rescores all poses."
        ),
        help="Multi-engine docking with clustering and representative pose selection",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        parents=[parent]
    )
    p_pipe.add_argument(
        "--receptor",
        required=True,
        help="Path to the receptor structure file (e.g., PDB format). The receptor will be prepared automatically if needed."
    )
    p_pipe.add_argument(
        "--ligand",
        required=True,
        help="Path to the ligand file. Supported formats: SMILES (.smi), SDF (.sdf), MOL2 (.mol2), or PDBQT (.pdbqt). The ligand will be prepared automatically if needed."
    )
    p_pipe.add_argument(
        "--box",
        required=True,
        help="Path to the binding site box definition file (PDB format with REMARK records containing center coordinates and size). This defines the search space for docking."
    )
    p_pipe.add_argument(
        "--all-boxes",
        action="store_true",
        help="Use all box*.pdb files found in the ligand directory (and the --box directory). Results are written under <outdir>/boxN/."
    )
    p_pipe.add_argument(
        "--engines",
        default="vina,smina,plants",
        help="Comma-separated list of docking engines to use. Options: 'vina', 'smina', 'gnina', 'plants', or any combination (e.g., 'vina,smina' or 'vina,gnina,plants'). Default: vina,smina,plants"
    )
    p_pipe.add_argument(
        "--rescoring-engines",
        "--rescore-engines",  # Alias for convenience
        dest="rescoring_engines",
        default=None,
        help="Comma-separated list of engines to use for rescoring. Options: 'vina', 'smina', 'gnina', 'plants', 'oddt', or any combination. If not specified, uses the same engines as --engines. Can be different from docking engines (e.g., dock with 'vina,plants' but rescore with 'vina,smina,gnina,oddt')."
    )
    p_pipe.add_argument(
        "--name",
        help="Job name identifier. If not provided, defaults to the ligand filename (without extension). Used for output file naming."
    )
    p_pipe.add_argument(
        "--outdir",
        default="./ocdocker_out",
        help="Output directory where all results will be saved. Default: ./ocdocker_out"
    )
    p_pipe.add_argument(
        "--cluster-min",
        type=float,
        default=10.0,
        help="Minimum RMSD threshold (in Angstroms) for clustering. The clustering algorithm searches between --cluster-min and --cluster-max to find optimal clusters. Default: 10.0"
    )
    p_pipe.add_argument(
        "--cluster-max",
        type=float,
        default=20.0,
        help="Maximum RMSD threshold (in Angstroms) for clustering. Poses within this distance are considered similar. Default: 20.0"
    )
    p_pipe.add_argument(
        "--cluster-step",
        type=float,
        default=0.1,
        help="Step size (in Angstroms) for searching the optimal clustering threshold between --cluster-min and --cluster-max. Smaller values provide finer search but take longer. Default: 0.1"
    )
    p_pipe.add_argument(
        "--store-db",
        action="store_true",
        help="Store run data in the database (Receptors, Ligands, Complexes) including available descriptors and supported program scores. Requires database to be configured and accessible, and optional DB deps installed (`pip install \"ocdocker[db]\"`)."
    )
    p_pipe.add_argument(
        "--timeout",
        type=int,
        default=None,
        help="Timeout in seconds for external docking tools. Overrides the OCDOCKER_TIMEOUT environment variable. If a tool exceeds this time, the process will be terminated."
    )
    p_pipe.set_defaults(func=cmd_pipeline)

    # console (interactive mode)
    p_console = sub.add_parser(
        "console",
        description=(
            "Launch an interactive Python console with OCDocker pre-loaded.\n\n"
            "This provides an interactive environment with tab-completion and command history,\n"
            "allowing you to use OCDocker programmatically. All OCDocker modules are imported\n"
            "and ready to use. Useful for exploratory work, debugging, or custom workflows\n"
            "that don't fit the standard CLI commands."
        ),
        help="Open interactive OCDocker Python console",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        parents=[parent]
    )
    p_console.set_defaults(func=cmd_console)

    # script (run Python script with OCDocker pre-loaded)
    p_script = sub.add_parser(
        "script",
        description=(
            "Run a Python script with OCDocker libraries pre-loaded.\n\n"
            "Security note: This executes the script directly in-process. Only run scripts you trust.\n"
            "You must pass --allow-unsafe-exec (or set OCDOCKER_ALLOW_SCRIPT_EXEC=1).\n\n"
            "This command bootstraps the OCDocker environment, loads all OCDocker modules,\n"
            "and executes your script file. All OCDocker classes and functions are available\n"
            "in the script's namespace, just like in the interactive console.\n\n"
            "For trusted workflows that need deserialization, call\n"
            "`allow_unsafe_runtime(deserialization=True)` inside the script.\n\n"
            "Useful for running custom workflows, batch processing, or automation scripts\n"
            "that use OCDocker functionality."
        ),
        help="Run a Python script with OCDocker libraries pre-loaded",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        parents=[parent]
    )
    p_script.add_argument(
        "script_file",
        help="Path to the Python script file to execute. The script will have access to all OCDocker modules."
    )
    p_script.add_argument(
        "script_args",
        nargs=argparse.REMAINDER,
        help="Additional arguments to pass to the script (accessible via sys.argv in the script)."
    )
    p_script.add_argument(
        "--allow-unsafe-exec",
        action="store_true",
        default=False,
        help=(
            "Required opt-in for in-process script execution. "
            "Alternatively set OCDOCKER_ALLOW_SCRIPT_EXEC=1."
        ),
    )
    p_script.set_defaults(func=cmd_script)

    # doctor (environment diagnostics)
    p_doc = sub.add_parser(
        "doctor",
        description=(
            "Run diagnostics to check your OCDocker environment setup.\n\n"
            "This command verifies:\n"
            "  - Availability and versions of external tools (Vina, Smina, PLANTS, Gnina, Open Babel, etc.)\n"
            "  - Python dependencies and package versions\n"
            "  - Database backend, driver/client version, server version (when reachable), and connectivity\n"
            "  - Configuration file validity\n\n"
            "Use this command to troubleshoot installation or configuration issues before\n"
            "running docking jobs. It provides detailed information about what's working\n"
            "and what needs to be fixed."
        ),
        help="Check environment setup and diagnose issues",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        parents=[parent]
    )
    p_doc.set_defaults(func=cmd_doctor)

    return parser


def cmd_console(args: argparse.Namespace) -> int:  # pragma: no cover - interactive console, unsuitable for automated coverage
    '''Open an interactive console with OCDockerConsole namespace.

    Respects global flags by bootstrapping environment first.

    Parameters
    ----------
    args : argparse.Namespace
        Command-line arguments.

    Returns
    -------
    int
        Exit code (0 for success, 1 for failure).
    '''

    # Bootstrap env to ensure Initialise is safe to import
    globals_ns = _preparse_global_args(sys.argv[1:])
    setattr(globals_ns, "_ocdocker_init_db", False)
    _bootstrap_ocdocker_env(globals_ns)

    # Configure logging according to CLI flags
    try:
        import OCDocker.Error as ocerror
        import OCDocker.Toolbox.Logging as oclogging
        oclogging.configure(
            level=ocerror.Error.get_output_level(),
            log_file=args.log_file,
            to_stdout=False,
            use_rich=True,
        )
    except (ImportError, AttributeError, OSError):
        # Ignore logging configuration errors (non-critical for core functionality)
        pass

    # Import console module and open interactive session with its namespace
    try:
        # OCDockerConsole.py is at project root, add it to path if needed
        import OCDockerConsole as occ
    except ImportError:
        # Try to find OCDockerConsole.py relative to the package
        try:
            ocdocker_pkg = Path(__file__).resolve().parent.parent  # OCDocker package dir
            project_root = ocdocker_pkg.parent  # Project root where OCDockerConsole.py lives
            if project_root not in sys.path:
                sys.path.insert(0, str(project_root))
            import OCDockerConsole as occ
        except ModuleNotFoundError as e:
            extra = _suggest_extra_for_missing_module(getattr(e, "name", ""))
            return _print_optional_dependency_hint(
                feature="interactive console",
                extra=extra,
                exc=e,
            )
        except Exception as e:
            print(f"Failed to import OCDockerConsole: {e}")
            return 1
    except ModuleNotFoundError as e:
        extra = _suggest_extra_for_missing_module(getattr(e, "name", ""))
        return _print_optional_dependency_hint(
            feature="interactive console",
            extra=extra,
            exc=e,
        )
    except Exception as e:
        print(f"Failed to import OCDockerConsole: {e}")
        return 1

    print("Launching OCDocker Console. Press Ctrl-D to exit.")
    try:
        # Expose console namespace without dunders
        local_ns = {k: v for k, v in vars(occ).items() if not k.startswith('__')}

        # Try to use IPython if available, otherwise fallback to standard Python console
        try:
            from IPython import embed
            # Determine if colors should be enabled (when called from a terminal like bash)
            colors = 'NoColor'
            if sys.stdout.isatty() and os.getenv('TERM') and 'dumb' not in os.getenv('TERM', ''):
                # Enable colors when running in a terminal (bash, etc.)
                # 'Linux' provides good color scheme for terminals
                colors = 'Linux'
            # Use IPython with the console namespace and colors enabled
            embed(user_ns=local_ns, banner1="", colors=colors, display_banner=False)
        except ImportError:
            # Fallback to standard Python console
            import code
            # Setup tab-completion with the console namespace, if readline is available
            try:
                import readline
                import rlcompleter
                completer = rlcompleter.Completer(local_ns)
                readline.set_completer(completer.complete)
                readline.parse_and_bind('tab: complete')
                # History file (optional)
                hist = os.path.expanduser('~/.ocdocker_console_history')
                try:
                    readline.read_history_file(hist)
                except (OSError, FileNotFoundError):
                    # Ignore if history file doesn't exist or can't be read
                    pass
            except (ImportError, AttributeError):
                # Ignore if readline is not available
                pass
            # Avoid printing the console banner twice: it's already printed on import
            code.interact(banner="", local=local_ns)
            # Save history (best-effort)
            try:
                if 'readline' in sys.modules:
                    sys.modules['readline'].write_history_file(os.path.expanduser('~/.ocdocker_console_history'))
            except (OSError, AttributeError):
                # Ignore if history file can't be written or readline not available
                pass
    except Exception as e:
        print(f"Interactive console exited with error: {e}")
        return 1
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:  # pragma: no cover - environment probing is platform-dependent
    '''Run diagnostics: config, binaries, Python deps, DB connectivity.

    Parameters
    ----------
    args : argparse.Namespace
        Command-line arguments.

    Returns
    -------
    int
        Exit code (0 for success, 1 for failure).
    '''

    # Bootstrap lightweight config/runtime context (no DB required for diagnostics)
    globals_ns = _preparse_global_args(sys.argv[1:])
    setattr(globals_ns, "_ocdocker_init_db", False)
    _bootstrap_ocdocker_env(globals_ns)

    # Configure logging according to CLI flags
    try:
        import OCDocker.Error as ocerror
        import OCDocker.Toolbox.Logging as oclogging
        oclogging.configure(level=ocerror.Error.get_output_level(), log_file=args.log_file, to_stdout=(not args.no_stdout_log))
    except (ImportError, AttributeError, OSError):
        # Ignore logging configuration errors (non-critical for core functionality)
        pass

    report: Dict[str, Any] = {}

    # Config source
    try:
        import OCDocker.Initialise as OCI
        cfg = getattr(OCI, 'config_file', None)
        report['config'] = {
            'path': str(cfg) if cfg else 'unknown',
        }
    except Exception as e:
        report['config'] = {'error': f'{e}'}

    # Engine binaries
    def _exists_exe(p: Optional[str]) -> bool:
        if not p:
            return False
        if os.path.isabs(p):
            return os.path.isfile(p) and os.access(p, os.X_OK)
        return shutil.which(p) is not None

    _vina_bin: Optional[str]
    _smina_bin: Optional[str]
    _plants_bin: Optional[str]
    config: Optional[Any] = None
    try:
        from OCDocker.Config import get_config
        config = get_config()
        v: Optional[str] = config.vina.executable
        s: Optional[str] = config.smina.executable
        p: Optional[str] = config.plants.executable
    except (ImportError, AttributeError, RuntimeError, TypeError, ValueError, KeyError) as exc:
        # Fallback if config is not available
        v = s = p = None
        report['binaries_error'] = f"CONFIG_UNAVAILABLE ({type(exc).__name__}: {exc})"
    report['binaries'] = {
        'vina': 'OK' if _exists_exe(v) else 'MISSING',
        'smina': 'OK' if _exists_exe(s) else 'MISSING',
        'plants': 'OK' if _exists_exe(p) else 'MISSING',
    }
    report['external_tools'] = _collect_external_tool_manifest()

    # Python dependencies
    # SECURITY NOTE: Dynamic import is used here to check for optional dependencies.
    # The module names are hardcoded in a whitelist ('rdkit', 'Bio', 'oddt', 'sqlalchemy')
    # and never come from user input, making this safer from injection attacks.
    pydeps = {}

    # Whitelist of allowed module names for dependency checking
    ALLOWED_DEPENDENCY_MODULES = ('rdkit', 'Bio', 'oddt', 'sqlalchemy')
    for mod in ALLOWED_DEPENDENCY_MODULES:
        # Validate module name contains only safe characters (alphanumeric and underscore)
        if not isinstance(mod, str) or not mod.replace('_', '').isalnum():
            pydeps[mod] = 'INVALID_MODULE_NAME'
            continue
        try:
            __import__(mod)
            pydeps[mod] = 'OK'
        except Exception as e:
            pydeps[mod] = f'MISSING ({e.__class__.__name__})'
    report['python_deps'] = pydeps

    # DB connectivity
    db_report: Dict[str, Any] = {}
    backend_cfg: Optional[str] = None
    try:
        if config is not None:
            backend_cfg = str(getattr(getattr(config, 'database', None), 'backend', '') or '').strip().lower() or None
    except Exception:
        backend_cfg = None

    try:
        import sqlalchemy
        db_report['sqlalchemy_version'] = str(getattr(sqlalchemy, '__version__', 'unknown'))
    except Exception:
        db_report['sqlalchemy_version'] = 'unknown'

    try:
        eng = getattr(OCI, 'engine', None)
        if eng is None:
            db_report['status'] = 'MISSING ENGINE'
            db_report['access'] = False
            db_report['backend'] = backend_cfg or 'unknown'
            report['database'] = db_report
        else:
            url_obj = getattr(eng, 'url', None)
            drivername = str(getattr(url_obj, 'drivername', '') or '')
            backend_from_driver = ''
            if drivername.startswith('postgresql'):
                backend_from_driver = 'postgresql'
            elif drivername.startswith('mysql'):
                backend_from_driver = 'mysql'
            elif drivername.startswith('sqlite'):
                backend_from_driver = 'sqlite'

            backend = backend_cfg or backend_from_driver or 'unknown'
            db_report['backend'] = backend
            db_report['driver'] = drivername or 'unknown'

            # Client/driver library version (best-effort)
            client_version = 'unknown'
            try:
                import importlib
                if backend == 'postgresql':
                    _psycopg = importlib.import_module('psycopg')
                    client_version = str(getattr(_psycopg, '__version__', 'unknown'))
                elif backend == 'mysql':
                    _pymysql = importlib.import_module('pymysql')
                    client_version = str(getattr(_pymysql, '__version__', 'unknown'))
                elif backend == 'sqlite':
                    import sqlite3 as _sqlite3
                    client_version = str(getattr(_sqlite3, 'sqlite_version', 'unknown'))
            except Exception:
                client_version = 'unknown'
            db_report['client_version'] = client_version

            conn = None
            try:
                conn = eng.connect()
                db_report['status'] = 'OK'
                db_report['access'] = True
                server_version: Optional[str] = None
                if hasattr(conn, 'exec_driver_sql'):
                    sql = None
                    if backend == 'postgresql':
                        sql = 'SHOW server_version'
                    elif backend == 'mysql':
                        sql = 'SELECT VERSION()'
                    elif backend == 'sqlite':
                        sql = 'SELECT sqlite_version()'

                    if sql:
                        try:
                            value = conn.exec_driver_sql(sql).scalar()
                            if value is not None:
                                server_version = str(value)
                        except Exception as exc:
                            server_version = f'ERROR ({type(exc).__name__})'
                db_report['server_version'] = server_version or 'unknown'

                # Connected identity / database checks (best-effort).
                expected_user = None
                expected_database = None
                try:
                    if config is not None:
                        expected_user = getattr(getattr(config, 'database', None), 'user', None)
                        expected_database = getattr(getattr(config, 'database', None), 'database', None)
                except Exception:
                    pass

                db_report['expected_user'] = expected_user
                db_report['expected_database'] = expected_database

                current_user: Optional[str] = None
                current_database: Optional[str] = None
                if hasattr(conn, 'exec_driver_sql'):
                    try:
                        if backend == 'postgresql':
                            current_user_val = conn.exec_driver_sql('SELECT current_user').scalar()
                            current_db_val = conn.exec_driver_sql('SELECT current_database()').scalar()
                            current_user = str(current_user_val) if current_user_val is not None else None
                            current_database = str(current_db_val) if current_db_val is not None else None
                        elif backend == 'mysql':
                            current_user_val = conn.exec_driver_sql('SELECT CURRENT_USER()').scalar()
                            current_db_val = conn.exec_driver_sql('SELECT DATABASE()').scalar()
                            current_user = str(current_user_val) if current_user_val is not None else None
                            current_database = str(current_db_val) if current_db_val is not None else None
                        elif backend == 'sqlite':
                            current_user = 'n/a (sqlite)'
                            db_name = getattr(url_obj, 'database', None)
                            current_database = str(db_name) if db_name else 'sqlite'
                    except Exception:
                        # Keep values as None when introspection queries fail.
                        pass

                db_report['current_user'] = current_user or 'unknown'
                db_report['current_database'] = current_database or 'unknown'

                user_check = 'unknown'
                if backend == 'sqlite':
                    user_check = 'n/a'
                elif expected_user:
                    effective_user = (current_user or '').strip()
                    # MySQL CURRENT_USER() often returns "user@host".
                    if backend == 'mysql' and '@' in effective_user:
                        effective_user = effective_user.split('@', 1)[0]
                    user_check = 'ok' if effective_user == str(expected_user).strip() else 'mismatch'
                db_report['user_check'] = user_check

                database_check = 'unknown'
                if expected_database and current_database and current_database != 'unknown':
                    database_check = (
                        'ok'
                        if str(current_database).strip() == str(expected_database).strip()
                        else 'mismatch'
                    )
                db_report['database_check'] = database_check
            finally:
                if conn is not None:
                    try:
                        conn.close()
                    except Exception:
                        pass
            report['database'] = db_report
    except Exception as e:
        db_report['status'] = f'ERROR ({e})'
        db_report['access'] = False
        if 'backend' not in db_report:
            db_report['backend'] = backend_cfg or 'unknown'
        report['database'] = db_report

    # Summary printout
    print(json.dumps(report, indent=2))

    return 0


def cmd_init_config(args: argparse.Namespace) -> int:
    '''Create a base OCDocker config file from an example template.

    This avoids importing Initialise (which expects a ready config).

    Parameters
    ----------
    args : argparse.Namespace
        Command-line arguments.

    Returns
    -------
    int
        Exit code (0 for success, 1 for failure).
    '''

    target = Path(args.config_file or "OCDocker.cfg")
    suffix = target.suffix.lower()
    if suffix == ".yml":
        example_names = ("OCDocker.yml.example", "OCDocker.cfg.example")
    else:
        # Default to legacy cfg template when extension is absent/unknown.
        example_names = ("OCDocker.cfg.example", "OCDocker.yml.example")

    def _find_example(base_dir: Path) -> Optional[Path]:
        for name in example_names:
            candidate = base_dir / name
            if candidate.exists():
                return candidate
        return None

    # Look for the example file in current directory first.
    example = _find_example(Path("."))
    if example is None:
        # Fallback to package directory.
        import OCDocker
        pkg_dir = Path(OCDocker.__file__).parent.parent
        example = _find_example(pkg_dir)
        if example is None:
            expected = " or ".join(example_names)
            print(f"{expected} not found in current directory or package directory.")
            return 1

    if target.exists():
        print(f"Config already exists: {target}")
        return 0

    target.write_text(example.read_text(encoding="utf-8"), encoding="utf-8")
    print(f"Config created at: {target}. Please review and adjust paths.")
    return 0


def cmd_pipeline(args: argparse.Namespace) -> int:  # pragma: no cover - heavy integration path assembling multiple engines
    '''Full multi-engine flow with clustering, rescoring and export.

    1) Run docking on selected engines.
    2) Convert poses to MOL2, cluster by RMSD and pick the medoid of the largest cluster.
    3) Rescore only the representative pose.
    4) Save representative.mol2 and summary.json (rescoring results).
    5) (Optional) Store minimal metadata to DB.

    Parameters
    ----------
    args : argparse.Namespace
        Command-line arguments.

    Returns
    -------
    int
        Exit code (0 for success, 1 for failure).
    '''

    if args.store_db:
        db_ok, db_exc = _db_dependencies_available()
        if not db_ok and db_exc is not None:
            return _print_optional_dependency_hint(
                feature="database storage (--store-db)",
                extra="db",
                exc=db_exc,
            )

    # Bootstrap env
    globals_ns = _preparse_global_args(sys.argv[1:])
    setattr(globals_ns, "_ocdocker_init_db", bool(getattr(args, "store_db", False)))
    _bootstrap_ocdocker_env(globals_ns)

    # Configure logging according to CLI flags
    try:
        import OCDocker.Error as ocerror
        import OCDocker.Toolbox.Logging as oclogging
        oclogging.configure(
            level=ocerror.Error.get_output_level(),
            log_file=args.log_file,
            to_stdout=(not args.no_stdout_log),
        )
    except (ImportError, AttributeError, OSError):
        # Ignore logging configuration errors (non-critical for core functionality)
        pass

    # Optionally set timeout for external processes
    if args.timeout:
        os.environ["OCDOCKER_TIMEOUT"] = str(args.timeout)

    # Domain imports
    try:
        import OCDocker.Ligand as ocl
        import OCDocker.Receptor as ocr
        import OCDocker.Docking.Vina as ocvina
        import OCDocker.Docking.Smina as ocsmina
        import OCDocker.Docking.Gnina as ocgnina
        import OCDocker.Docking.PLANTS as ocplants
        import OCDocker.Toolbox.MoleculeProcessing as ocmolproc
        import OCDocker.Toolbox.Printing as ocprint
        import OCDocker.Processing.Preprocessing.RmsdClustering as ocrmsd
        import pandas as pd
        import numpy as np
        import json
    except ModuleNotFoundError as exc:
        extra = _suggest_extra_for_missing_module(getattr(exc, "name", ""))
        return _print_optional_dependency_hint(
            feature="pipeline docking workflow",
            extra=extra,
            exc=exc,
        )

    base_outdir = Path(args.outdir).resolve()
    name = args.name or Path(args.ligand).stem

    # Validate input files
    receptor_path = _require_file(str(args.receptor), "--receptor")
    ligand_path = _require_file(str(args.ligand), "--ligand")
    box_path = _require_file(str(args.box), "--box")

    receptor = ocr.Receptor(str(receptor_path), name=f"{name}_receptor")
    # Use just the name for ligand to avoid "ligand_ligand" duplication when input file is already named "ligand"
    ligand_name = name if not name.endswith("_ligand") else name[:-7]  # Remove "_ligand" suffix if present
    ligand = ocl.Ligand(str(ligand_path), name=ligand_name)

    engines = [e.strip().lower() for e in args.engines.split(',') if e.strip()]
    engines = [e for e in engines if e in ("vina", "smina", "gnina", "plants")]
    if not engines:
        print("No valid engine provided. Use --engines vina,smina,gnina,plants")
        return 1

    # Get rescoring engines (default to same as docking engines if not specified)
    rescoring_engines = engines
    if args.rescoring_engines:
        rescoring_engines = [e.strip().lower() for e in args.rescoring_engines.split(",") if e.strip()]
        # Validate rescoring engines
        valid_rescoring = {"vina", "smina", "gnina", "plants", "oddt"}
        invalid_rescoring = [e for e in rescoring_engines if e not in valid_rescoring]
        if invalid_rescoring:
            print(f"Error: invalid rescoring engines: {', '.join(invalid_rescoring)}. Valid options: vina, smina, gnina, plants, oddt")
            return 2
        # Filter to only valid engines
        rescoring_engines = [e for e in rescoring_engines if e in valid_rescoring]
        if not rescoring_engines:
            print("Error: no valid rescoring engines specified. Valid options: vina, smina, gnina, plants, oddt")
            return 2

    # Validate required binaries are available
    _vina_bin: Optional[str] = None
    _smina_bin: Optional[str] = None
    _gnina_bin: Optional[str] = None
    _plants_bin: Optional[str] = None
    try:
        from OCDocker.Config import get_config
        config = get_config()
        _vina_bin = config.vina.executable
        _smina_bin = config.smina.executable
        _gnina_bin = config.gnina.executable
        _plants_bin = config.plants.executable
    except (ImportError, AttributeError):
        # Fallback if binaries are not configured
        pass

    def _exists_exe(p: Optional[str]) -> bool:
        if not p:
            return False
        if os.path.isabs(p):
            return os.path.isfile(p) and os.access(p, os.X_OK)
        return shutil.which(p) is not None

    missing = []
    for e in engines:
        if e == "vina" and not _exists_exe(_vina_bin):
            missing.append("vina")
        elif e == "smina" and not _exists_exe(_smina_bin):
            missing.append("smina")
        elif e == "gnina" and not _exists_exe(_gnina_bin):
            missing.append("gnina")
        elif e == "plants" and not _exists_exe(_plants_bin):
            missing.append("plants")
    if missing:
        print(f"Error: missing engine binaries: {', '.join(missing)}. Check paths in OCDocker.cfg or PATH.")
        return 2

    def _run_pipeline_for_box(box_path: Path, outdir: Path, box_label: Optional[str]) -> int:
        outdir.mkdir(parents=True, exist_ok=True)
        all_poses: List[str] = []
        pose_engine_map: Dict[str, str] = {}  # Map pose path to engine name
        ctx: Dict[str, Dict[str, str]] = {}
        engine_errors: Dict[str, str] = {}
        import os as _os

        for eng in engines:
            r: Any
            e_dir = outdir / f"{eng}Files"; e_dir.mkdir(parents=True, exist_ok=True)
            try:
                if eng == "vina":
                    conf = e_dir / "conf_vina.txt"; prep_r = outdir / "prepared_receptor.pdbqt"; prep_l = outdir / "prepared_ligand.pdbqt"
                    log = e_dir / f"{name}.log"; outp = e_dir / f"{name}.pdbqt"
                    r = ocvina.Vina(str(conf), str(box_path), receptor, str(prep_r), ligand, str(prep_l), str(log), str(outp), name=f"VINA {name}", overwrite_config=True)
                    # Only prepare receptor/ligand if they don't exist
                    if not (_os.path.isfile(str(prep_r)) and _os.path.getsize(str(prep_r)) > 0):
                        rc = r.run_prepare_receptor(); rc = rc[0] if isinstance(rc, tuple) else rc
                        if rc != 0:
                            engine_errors[eng] = f"Receptor preparation failed with code {rc}"
                            ocprint.print_warning(f"Vina receptor preparation failed. Continuing with other engines...")
                            continue
                    if not (_os.path.isfile(str(prep_l)) and _os.path.getsize(str(prep_l)) > 0):
                        rc = r.run_prepare_ligand(); rc = rc[0] if isinstance(rc, tuple) else rc
                        if rc != 0:
                            engine_errors[eng] = f"Ligand preparation failed with code {rc}"
                            ocprint.print_warning(f"Vina ligand preparation failed. Continuing with other engines...")
                            continue
                    rc = r.run_docking(); rc = rc[0] if isinstance(rc, tuple) else rc
                    if rc != 0:
                        engine_errors[eng] = f"Docking failed with code {rc}"
                        ocprint.print_warning(f"Vina docking failed. Continuing with other engines...")
                        continue
                    _ = r.split_poses(str(e_dir))
                    poses = r.get_docked_poses()
                    all_poses.extend(poses)
                    # Track which engine each pose came from
                    for pose in poses:
                        pose_engine_map[pose] = eng
                    ctx[eng] = {"conf": str(conf), "dir": str(e_dir)}
                elif eng == "smina":
                    conf = e_dir / "conf_smina.txt"; prep_r = outdir / "prepared_receptor.pdbqt"; prep_l = outdir / "prepared_ligand.pdbqt"
                    log = e_dir / f"{name}.log"; outp = e_dir / f"{name}.pdbqt"
                    r = ocsmina.Smina(str(conf), str(box_path), receptor, str(prep_r), ligand, str(prep_l), str(log), str(outp), name=f"SMINA {name}", overwrite_config=True)
                    # Only prepare receptor/ligand if they don't exist
                    if not (_os.path.isfile(str(prep_r)) and _os.path.getsize(str(prep_r)) > 0):
                        rc = r.run_prepare_receptor(); rc = rc[0] if isinstance(rc, tuple) else rc
                        if rc != 0:
                            engine_errors[eng] = f"Receptor preparation failed with code {rc}"
                            ocprint.print_warning(f"Smina receptor preparation failed. Continuing with other engines...")
                            continue
                    if not (_os.path.isfile(str(prep_l)) and _os.path.getsize(str(prep_l)) > 0):
                        rc = r.run_prepare_ligand(); rc = rc[0] if isinstance(rc, tuple) else rc
                        if rc != 0:
                            engine_errors[eng] = f"Ligand preparation failed with code {rc}"
                            ocprint.print_warning(f"Smina ligand preparation failed. Continuing with other engines...")
                            continue
                    rc = r.run_docking(); rc = rc[0] if isinstance(rc, tuple) else rc
                    if rc != 0:
                        engine_errors[eng] = f"Docking failed with code {rc}"
                        ocprint.print_warning(f"Smina docking failed. Continuing with other engines...")
                        continue
                    _ = r.split_poses(str(e_dir))
                    poses = r.get_docked_poses()
                    all_poses.extend(poses)
                    # Track which engine each pose came from
                    for pose in poses:
                        pose_engine_map[pose] = eng
                    ctx[eng] = {"conf": str(conf), "dir": str(e_dir)}
                elif eng == "gnina":
                    conf = e_dir / "conf_gnina.conf"; prep_r = outdir / "prepared_receptor.pdbqt"; prep_l = outdir / "prepared_ligand.pdbqt"
                    log = e_dir / f"{name}.log"; outp = e_dir / f"{name}.pdbqt"
                    r = ocgnina.Gnina(str(conf), str(box_path), receptor, str(prep_r), ligand, str(prep_l), str(log), str(outp), name=f"GNINA {name}", overwrite_config=True)
                    # Only prepare receptor/ligand if they don't exist
                    if not (_os.path.isfile(str(prep_r)) and _os.path.getsize(str(prep_r)) > 0):
                        rc = r.run_prepare_receptor(); rc = rc[0] if isinstance(rc, tuple) else rc
                        if rc != 0:
                            engine_errors[eng] = f"Receptor preparation failed with code {rc}"
                            ocprint.print_warning(f"Gnina receptor preparation failed. Continuing with other engines...")
                            continue
                    if not (_os.path.isfile(str(prep_l)) and _os.path.getsize(str(prep_l)) > 0):
                        rc = r.run_prepare_ligand(); rc = rc[0] if isinstance(rc, tuple) else rc
                        if rc != 0:
                            engine_errors[eng] = f"Ligand preparation failed with code {rc}"
                            ocprint.print_warning(f"Gnina ligand preparation failed. Continuing with other engines...")
                            continue
                    rc = r.run_docking(); rc = rc[0] if isinstance(rc, tuple) else rc
                    if rc != 0:
                        engine_errors[eng] = f"Docking failed with code {rc}"
                        ocprint.print_warning(f"Gnina docking failed. Continuing with other engines...")
                        continue
                    _ = r.split_poses(str(e_dir))
                    poses = r.get_docked_poses()
                    all_poses.extend(poses)
                    # Track which engine each pose came from
                    for pose in poses:
                        pose_engine_map[pose] = eng
                    ctx[eng] = {"conf": str(conf), "dir": str(e_dir)}
                else:
                    conf = e_dir / "conf_plants.txt"; prep_r = outdir / "prepared_receptor.mol2"; prep_l = outdir / "prepared_ligand.mol2"
                    log = e_dir / f"{name}.log"; outp = e_dir
                    r = ocplants.PLANTS(str(conf), str(box_path), receptor, str(prep_r), ligand, str(prep_l), str(log), str(outp), name=f"PLANTS {name}", overwrite_config=True)
                    # Only prepare receptor/ligand if they don't exist
                    if not (_os.path.isfile(str(prep_r)) and _os.path.getsize(str(prep_r)) > 0):
                        rc = r.run_prepare_receptor(); rc = rc[0] if isinstance(rc, tuple) else rc
                        if rc != 0:
                            engine_errors[eng] = f"Receptor preparation failed with code {rc}"
                            ocprint.print_warning(f"PLANTS receptor preparation failed. Continuing with other engines...")
                            continue
                    if not (_os.path.isfile(str(prep_l)) and _os.path.getsize(str(prep_l)) > 0):
                        rc = r.run_prepare_ligand(); rc = rc[0] if isinstance(rc, tuple) else rc
                        if rc != 0:
                            engine_errors[eng] = f"Ligand preparation failed with code {rc}"
                            ocprint.print_warning(f"PLANTS ligand preparation failed. Continuing with other engines...")
                            continue
                    rc = r.run_docking(); rc = rc[0] if isinstance(rc, tuple) else rc
                    if rc != 0:
                        engine_errors[eng] = f"Docking failed with code {rc}"
                        ocprint.print_warning(f"PLANTS docking failed. Continuing with other engines...")
                        continue
                    poses = r.get_docked_poses()
                    all_poses.extend(poses)
                    # Track which engine each pose came from
                    for pose in poses:
                        pose_engine_map[pose] = eng
                    ctx[eng] = {"conf": str(conf), "dir": str(e_dir), "prep_rec": str(prep_r)}
            except Exception as e:
                engine_errors[eng] = f"Exception: {str(e)}"
                ocprint.print_warning(f"{eng.capitalize()} failed with exception: {e}. Continuing with other engines...")
                continue

        # Report any engine errors
        if engine_errors:
            print("\n=== Engine Errors ===")
            for eng, error_msg in engine_errors.items():
                print(f"{eng.capitalize()}: {error_msg}")
            print("")

        if not all_poses:
            if engine_errors:
                print("No poses were generated from any engine. All engines failed.")
                return 2
            else:
                print("No poses were generated.")
                return 2

        # Convert to MOL2 and cluster by RMSD
        # Use unique filenames based on engine to avoid overwriting
        mol2_dir = outdir / "poses_mol2"
        mol2_list, mol2_map = _ensure_mol2_poses(all_poses, mol2_dir, pose_engine_map)
        rmsd = ocmolproc.get_rmsd_matrix(mol2_list)
        df = pd.DataFrame(rmsd).loc[mol2_list, mol2_list]

        # Save RMSD matrix for reference
        rmsd_matrix_file = outdir / "rmsd_matrix.csv"
        df.to_csv(rmsd_matrix_file)

        # Perform clustering with plot output
        cluster_plot = outdir / "clustering_dendrogram.png"
        clusters = ocrmsd.cluster_rmsd(
            df,
            min_distance_threshold=args.cluster_min,
            max_distance_threshold=args.cluster_max,
            threshold_step=args.cluster_step,
            outputPlot=str(cluster_plot),
            molecule_name=name,
        )

        # Determine representative pose and save clustering results
        clustering_info = {
            "method": "rmsd_based_clustering",
            "total_poses": len(mol2_list),
            "representative_selection": None,
            "clusters": None,
            "cluster_sizes": None,
            "medoids": None,
        }

        if isinstance(clusters, int) or getattr(clusters, "size", 0) == 0:
            ocprint.print_warning(
                "Clustering did not converge or returned no labels; using the first pose as representative."
            )
            rep_mol2 = mol2_list[0]
            clustering_info["representative_selection"] = "first_pose_fallback"
            clustering_info["reason"] = "clustering_failed_or_no_labels"
        else:
            # Save cluster assignments
            cluster_assignments = pd.DataFrame({
                "pose_path": mol2_list,
                "cluster_id": clusters
            })
            cluster_assignments_file = outdir / "cluster_assignments.csv"
            cluster_assignments.to_csv(cluster_assignments_file, index=False)

            # Calculate cluster sizes
            cluster_sizes = {}
            unique_clusters, counts = np.unique(clusters, return_counts=True)
            for cluster_id, size in zip(unique_clusters, counts):
                cluster_sizes[int(cluster_id)] = int(size)

            clustering_info["clusters"] = int(len(unique_clusters))
            clustering_info["cluster_sizes"] = cluster_sizes

            meds = ocrmsd.get_medoids(df, clusters, onlyBiggest=True)
            if not meds:
                ocprint.print_warning(
                    "No medoid found from clusters; using the first pose as representative."
                )
                rep_mol2 = mol2_list[0]
                clustering_info["representative_selection"] = "first_pose_fallback"
                clustering_info["reason"] = "no_medoid_found"
            else:
                rep_mol2 = meds[0]
                clustering_info["representative_selection"] = "medoid_of_largest_cluster"
                clustering_info["medoids"] = [str(m) for m in meds]
                clustering_info["representative_pose"] = str(rep_mol2)
                # Find which cluster the representative belongs to
                rep_idx = mol2_list.index(rep_mol2)
                rep_cluster_id = int(clusters[rep_idx])
                clustering_info["representative_cluster_id"] = rep_cluster_id
                clustering_info["representative_cluster_size"] = cluster_sizes.get(rep_cluster_id, 0)

        # Get the original pose path for the representative
        rep_original = mol2_map.get(rep_mol2, rep_mol2)
        rep_engine = pose_engine_map.get(rep_original, None)

        # Convert representative to appropriate format for each engine's rescoring
        # Vina/Smina need PDBQT, PLANTS needs MOL2
        rep_pdbqt: Optional[Union[str, Path]] = None
        rep_mol2_final: Optional[Union[str, Path]] = None

        import OCDocker.Toolbox.Conversion as occonversion
        import shutil

        if rep_original.endswith('.pdbqt'):
            # Already PDBQT - use for vina/smina
            rep_pdbqt = rep_original
            # Convert to MOL2 for PLANTS if needed
            rep_mol2_final = outdir / "representative_for_plants.mol2"
            occonversion.convert_mols(rep_original, str(rep_mol2_final), overwrite=True)
        elif rep_original.endswith('.mol2'):
            # Already MOL2 - use for PLANTS
            rep_mol2_final = rep_original
            # Convert to PDBQT for vina/smina if needed
            rep_pdbqt = outdir / "representative_for_vina_smina.pdbqt"
            occonversion.convert_mols(rep_original, str(rep_pdbqt), overwrite=True)
        else:
            # Fallback: use the mol2 version we have
            rep_mol2_final = rep_mol2
            rep_pdbqt = outdir / "representative_for_vina_smina.pdbqt"
            occonversion.convert_mols(rep_mol2, str(rep_pdbqt), overwrite=True)

        # Save representative in MOL2 format (for general use)
        rep_path = outdir / "representative.mol2"
        if rep_mol2_final and Path(rep_mol2_final).exists():
            shutil.copyfile(rep_mol2_final, rep_path)
        else:
            shutil.copyfile(rep_mol2, rep_path)

        # Save clustering information
        clustering_info_file = outdir / "clustering_info.json"
        clustering_info_file.write_text(json.dumps(clustering_info, indent=2))

        # Rescoring (representative only)
        # Only rescore with engines specified in --rescoring-engines (or same as docking engines if not specified)
        rescoring: Dict[str, Dict[str, float]] = {}
        # Get config for scoring functions
        from OCDocker.Config import get_config
        config = get_config()

        # VINA
        if "vina" in ctx and "vina" in rescoring_engines:
            from OCDocker.Docking.Vina import run_rescore as v_rescore, get_rescore_log_paths as v_logs, read_rescore_logs as v_read
            if rep_pdbqt and Path(rep_pdbqt).exists():
                # Get scoring functions from config
                vina_sfs = config.vina.scoring_functions if config.vina.scoring_functions else ["vina"]
                for sf in vina_sfs:
                    try:
                        v_rescore(ctx["vina"]["conf"], str(rep_pdbqt), ctx["vina"]["dir"], sf, splitLigand=False, overwrite=True)
                    except Exception as e:
                        ocprint.print_warning(f"Vina rescoring with {sf} failed: {e}. Continuing with other scoring functions...")
                try:
                    log_paths, data, logs_ready = _wait_for_rescore_logs_ready(
                        v_logs,
                        v_read,
                        ctx["vina"]["dir"],
                    )
                    if not log_paths:
                        ocprint.print_warning(f"No Vina rescoring log files found in {ctx['vina']['dir']}. Check if rescoring completed successfully.")
                        # Debug: list files in directory
                        if Path(ctx["vina"]["dir"]).exists():
                            files = list(Path(ctx["vina"]["dir"]).glob("*"))
                            ocprint.print_warning(f"Files in Vina directory: {[f.name for f in files]}")
                    else:
                        if not logs_ready:
                            ocprint.print_warning("Vina rescoring logs were not parse-ready within 2.0 seconds. Continuing with best available data.")
                        ocprint.printv(f"Found Vina rescoring log files: {log_paths}")
                        if not data:
                            data = v_read(log_paths, onlyBest=True)
                        if not data:
                            ocprint.print_warning(f"Vina rescoring log files found but no data extracted. Log paths: {log_paths}")
                        else:
                            vina_vals: Dict[str, float] = {}
                            # Data structure: Dict[str, List[Union[str, float]]] according to type hint, but actual return is Dict[str, float]
                            # Key format: "rescoring_{scoring_function}_{pose_number}" or "vina_{scoring_function}_rescoring"
                            for k, v in data.items():
                                try:
                                    # v can be a float or a list - handle both cases
                                    if isinstance(v, (int, float)):
                                        # Normalize key: extract scoring function and create clean key
                                        # Keys can be: "vina_vina_rescoring", "rescoring_vina_1", "rescoring_vinardo_1", etc.
                                        if k.startswith("vina_") and k.endswith("_rescoring"):
                                            # Format: "vina_{scoring_function}_rescoring"
                                            sf_name = k.replace("vina_", "").replace("_rescoring", "")
                                            clean_key = f"vina_{sf_name}"
                                        elif k.startswith("rescoring_"):
                                            # Format: "rescoring_{scoring_function}_{pose_number}"
                                            parts = k.replace("rescoring_", "").split("_")
                                            if len(parts) >= 1:
                                                sf_name = parts[0]
                                                clean_key = f"vina_{sf_name}"
                                            else:
                                                clean_key = k
                                        else:
                                            clean_key = k
                                        vina_vals[clean_key] = float(v)
                                    elif isinstance(v, list) and len(v) > 0:
                                        # Handle list case (type hint says List[Union[str, float]])
                                        # Extract the numeric value
                                        numeric_val = None
                                        for item in v:
                                            if isinstance(item, (int, float)):
                                                numeric_val = float(item)
                                                break
                                            elif isinstance(item, str):
                                                try:
                                                    numeric_val = float(item)
                                                    break
                                                except ValueError:
                                                    continue
                                        if numeric_val is not None:
                                            # Normalize key
                                            if k.startswith("vina_") and k.endswith("_rescoring"):
                                                sf_name = k.replace("vina_", "").replace("_rescoring", "")
                                                clean_key = f"vina_{sf_name}"
                                            elif k.startswith("rescoring_"):
                                                parts = k.replace("rescoring_", "").split("_")
                                                if len(parts) >= 1:
                                                    sf_name = parts[0]
                                                    clean_key = f"vina_{sf_name}"
                                                else:
                                                    clean_key = k
                                            else:
                                                clean_key = k
                                            vina_vals[clean_key] = numeric_val
                                except (ValueError, TypeError, KeyError) as e:
                                    ocprint.print_warning(f"Failed to parse Vina rescoring value for {k}: {e}. Value type: {type(v)}, value: {v}")
                            if vina_vals:
                                rescoring["vina"] = vina_vals
                            else:
                                ocprint.print_warning(f"Vina rescoring data found but no valid values extracted. Data structure: {data}")
                except Exception as e:
                    ocprint.print_warning(f"Failed to read Vina rescoring results: {e}")
                    import traceback
                    ocprint.print_warning(f"Traceback: {traceback.format_exc()}")
        # SMINA
        if "smina" in rescoring_engines:
            from OCDocker.Docking.Smina import run_rescore as s_rescore, get_rescore_log_paths as s_logs, read_rescore_logs as s_read
            if rep_pdbqt and Path(rep_pdbqt).exists():
                # If smina wasn't docked, we can still use vina's prepared files (they share PDBQT format)
                # Create smina context if it doesn't exist
                if "smina" not in ctx:
                    # Use vina's config if available, otherwise create a new smina config
                    if "vina" in ctx:
                        # Create smina directory and config
                        smina_dir = outdir / "sminaFiles"
                        smina_dir.mkdir(parents=True, exist_ok=True)
                        smina_conf = smina_dir / "conf_smina.txt"
                        # Create a Smina object just to generate the config file
                        import OCDocker.Docking.Smina as ocsmina
                        prep_r = outdir / "prepared_receptor.pdbqt"
                        prep_l = outdir / "prepared_ligand.pdbqt"
                        smina_obj = ocsmina.Smina(str(smina_conf), str(box_path), receptor, str(prep_r), ligand, str(prep_l), str(smina_dir / f"{name}.log"), str(smina_dir / f"{name}.pdbqt"), name=f"SMINA {name}", overwrite_config=True)
                        ctx["smina"] = {"conf": str(smina_conf), "dir": str(smina_dir)}
                    else:
                        ocprint.print_warning("Smina rescoring requested but neither Smina nor Vina was docked. Smina rescoring requires PDBQT format files.")
                        # Skip smina rescoring
                        pass
                if "smina" in ctx:
                    # Get scoring functions from config
                    smina_sfs = config.smina.scoring_functions if config.smina.scoring_functions else ["vinardo"]
                    for sf in smina_sfs:
                        try:
                            s_rescore(ctx["smina"]["conf"], str(rep_pdbqt), ctx["smina"]["dir"], sf, splitLigand=False, overwrite=True)
                        except Exception as e:
                            ocprint.print_warning(f"Smina rescoring with {sf} failed: {e}. Continuing with other scoring functions...")
                    try:
                        log_paths, data, logs_ready = _wait_for_rescore_logs_ready(
                            s_logs,
                            s_read,
                            ctx["smina"]["dir"],
                        )
                        if not log_paths:
                            ocprint.print_warning(f"No Smina rescoring log files found in {ctx['smina']['dir']}")
                            # Debug: list files in directory
                            if Path(ctx["smina"]["dir"]).exists():
                                files = list(Path(ctx["smina"]["dir"]).glob("*"))
                                ocprint.print_warning(f"Files in Smina directory: {[f.name for f in files]}")
                        else:
                            if not logs_ready:
                                ocprint.print_warning("Smina rescoring logs were not parse-ready within 2.0 seconds. Continuing with best available data.")
                            ocprint.printv(f"Found Smina rescoring log files: {log_paths}")
                            if not data:
                                data = s_read(log_paths, onlyBest=True)
                            smina_vals: Dict[str, float] = {}
                            # Data structure: Dict[str, float] (read_rescoring_log returns float, not list)
                            # Key format: "rescoring_{scoring_function}_{pose_number}" or "smina_{scoring_function}_rescoring"
                            for k, v in data.items():
                                try:
                                    # v is a float (from read_rescoring_log)
                                    if isinstance(v, (int, float)):
                                        # Normalize key: extract scoring function and create clean key
                                        # Keys can be: "smina_vinardo_rescoring", "rescoring_vina_1", "rescoring_dkoes_scoring_1", etc.
                                        smina_sf_name: Optional[str] = None
                                        if k.startswith("smina_") and k.endswith("_rescoring"):
                                            # Format: "smina_{scoring_function}_rescoring"
                                            smina_sf_name = k.replace("smina_", "").replace("_rescoring", "")
                                            clean_key = f"smina_{smina_sf_name}"
                                        elif k.startswith("rescoring_"):
                                            # Format: "rescoring_{scoring_function}_{pose_number}"
                                            parts = k.replace("rescoring_", "").split("_")
                                            if len(parts) >= 1:
                                                # Handle multi-part scoring function names like "dkoes_scoring"
                                                # Try to match against known scoring functions
                                                smina_sf_name = None
                                                for known_sf in smina_sfs:
                                                    # Check if the key starts with this scoring function
                                                    if "_".join(parts[:len(known_sf.split("_"))]) == known_sf:
                                                        smina_sf_name = known_sf
                                                        break
                                                if not smina_sf_name and parts:
                                                    # Fallback: use first part
                                                    smina_sf_name = parts[0]
                                                clean_key = f"smina_{smina_sf_name}" if smina_sf_name else k
                                            else:
                                                clean_key = k
                                        else:
                                            clean_key = k
                                        smina_vals[clean_key] = float(v)
                                    elif isinstance(v, list) and len(v) > 0:
                                        # Handle list case (shouldn't happen but just in case)
                                        smina_vals[k] = float(v[0] if not isinstance(v[0], (list, tuple)) else v[0][0])
                                except (ValueError, TypeError, KeyError) as e:
                                    ocprint.print_warning(f"Failed to parse Smina rescoring value for {k}: {e}")
                            if smina_vals:
                                rescoring["smina"] = smina_vals
                            else:
                                ocprint.print_warning(f"Smina rescoring data found but no valid values extracted. Data structure: {data}")
                    except Exception as e:
                        ocprint.print_warning(f"Failed to read Smina rescoring results: {e}")
        # GNINA
        if "gnina" in rescoring_engines:
            from OCDocker.Docking.Gnina import run_rescore as g_rescore, get_rescore_log_paths as g_logs, read_rescore_logs as g_read
            if rep_pdbqt and Path(rep_pdbqt).exists():
                # If gnina wasn't docked, we can still use the shared prepared artifacts
                if "gnina" not in ctx:
                    gnina_dir = outdir / "gninaFiles"
                    gnina_dir.mkdir(parents=True, exist_ok=True)
                    gnina_conf = gnina_dir / "conf_gnina.conf"
                    prep_r = outdir / "prepared_receptor.pdbqt"
                    prep_l = outdir / "prepared_ligand.pdbqt"
                    gnina_obj = ocgnina.Gnina(
                        str(gnina_conf),
                        str(box_path),
                        receptor,
                        str(prep_r),
                        ligand,
                        str(prep_l),
                        str(gnina_dir / f"{name}.log"),
                        str(gnina_dir / f"{name}.pdbqt"),
                        name=f"GNINA {name}",
                        overwrite_config=True,
                    )
                    _ = gnina_obj
                    ctx["gnina"] = {"conf": str(gnina_conf), "dir": str(gnina_dir)}

                gnina_default_scoring = str(getattr(config.gnina, "scoring", "default") or "default").strip() or "default"
                gnina_scoring_functions = getattr(config.gnina, "scoring_functions", None)
                if not isinstance(gnina_scoring_functions, list) or not gnina_scoring_functions:
                    gnina_scoring_functions = [gnina_default_scoring]
                gnina_scoring_functions = [str(sf).strip() for sf in gnina_scoring_functions if str(sf).strip()]

                gnina_cnn_models = getattr(config.gnina, "cnn_models", None)
                if not isinstance(gnina_cnn_models, list) or not gnina_cnn_models:
                    gnina_cnn_models = [str(getattr(config.gnina, "cnn", "default") or "default")]
                gnina_cnn_models = [str(model).strip() for model in gnina_cnn_models if str(model).strip()]

                for sf_txt in gnina_scoring_functions:
                    if not sf_txt:
                        continue
                    try:
                        g_rescore(
                            ctx["gnina"]["conf"],
                            str(rep_pdbqt),
                            ctx["gnina"]["dir"],
                            sf_txt,
                            splitLigand = False,
                            overwrite = True,
                            disable_cnn = True,
                        )
                    except Exception as e:
                        ocprint.print_warning(f"Gnina rescoring with empirical scoring function '{sf_txt}' failed: {e}. Continuing with other rescoring functions...")

                for cnn_model in gnina_cnn_models:
                    try:
                        g_rescore(
                            ctx["gnina"]["conf"],
                            str(rep_pdbqt),
                            ctx["gnina"]["dir"],
                            gnina_default_scoring,
                            splitLigand = False,
                            overwrite = True,
                            cnn_model = cnn_model,
                            disable_cnn = False,
                        )
                    except Exception as e:
                        ocprint.print_warning(f"Gnina rescoring with CNN model '{cnn_model}' failed: {e}. Continuing with other CNN models...")

                try:
                    log_paths, data, logs_ready = _wait_for_rescore_logs_ready(
                        g_logs,
                        g_read,
                        ctx["gnina"]["dir"],
                    )
                    if not log_paths:
                        ocprint.print_warning(f"No Gnina rescoring log files found in {ctx['gnina']['dir']}")
                        if Path(ctx["gnina"]["dir"]).exists():
                            files = list(Path(ctx["gnina"]["dir"]).glob("*"))
                            ocprint.print_warning(f"Files in Gnina directory: {[f.name for f in files]}")
                    else:
                        if not logs_ready:
                            ocprint.print_warning("Gnina rescoring logs were not parse-ready within 2.0 seconds. Continuing with best available data.")
                        ocprint.printv(f"Found Gnina rescoring log files: {log_paths}")
                        if not data:
                            data = g_read(log_paths, onlyBest=True)
                        gnina_vals: Dict[str, float] = {}
                        for k, v in data.items():
                            try:
                                if isinstance(v, (int, float)):
                                    gnina_sf_name: Optional[str] = None
                                    gnina_cnn_name: Optional[str] = None
                                    if k.startswith("gnina_cnn_") and k.endswith("_rescoring"):
                                        gnina_cnn_name = k.replace("gnina_cnn_", "").replace("_rescoring", "")
                                        clean_key = f"gnina_cnn_{gnina_cnn_name}"
                                    elif k.startswith("gnina_") and k.endswith("_rescoring"):
                                        gnina_sf_name = k.replace("gnina_", "").replace("_rescoring", "")
                                        clean_key = f"gnina_{gnina_sf_name}"
                                    elif k.startswith("rescoring_cnn_"):
                                        cnn_suffix = k.replace("rescoring_cnn_", "", 1)
                                        for known_cnn in sorted(gnina_cnn_models, key=len, reverse=True):
                                            known_prefix = f"{known_cnn}_"
                                            if cnn_suffix.startswith(known_prefix):
                                                gnina_cnn_name = known_cnn
                                                break
                                        if not gnina_cnn_name and "_" in cnn_suffix:
                                            gnina_cnn_name = cnn_suffix.rsplit("_", 1)[0]
                                        clean_key = f"gnina_cnn_{gnina_cnn_name}" if gnina_cnn_name else k
                                    elif k.startswith("rescoring_"):
                                        parts = k.replace("rescoring_", "").split("_")
                                        if len(parts) >= 1:
                                            gnina_sf_name = None
                                            for known_sf in gnina_scoring_functions:
                                                if "_".join(parts[:len(str(known_sf).split("_"))]) == str(known_sf):
                                                    gnina_sf_name = str(known_sf)
                                                    break
                                            if not gnina_sf_name and parts:
                                                gnina_sf_name = parts[0]
                                            clean_key = f"gnina_{gnina_sf_name}" if gnina_sf_name else k
                                        else:
                                            clean_key = k
                                    else:
                                        clean_key = k
                                    gnina_vals[clean_key] = float(v)
                                elif isinstance(v, list) and len(v) > 0:
                                    gnina_vals[k] = float(v[0] if not isinstance(v[0], (list, tuple)) else v[0][0])
                            except (ValueError, TypeError, KeyError) as e:
                                ocprint.print_warning(f"Failed to parse Gnina rescoring value for {k}: {e}")

                        if gnina_vals:
                            rescoring["gnina"] = gnina_vals
                        else:
                            ocprint.print_warning(f"Gnina rescoring data found but no valid values extracted. Data structure: {data}")
                except Exception as e:
                    ocprint.print_warning(f"Failed to read Gnina rescoring results: {e}")

        # PLANTS
        if "plants" in ctx and "plants" in rescoring_engines:
            from OCDocker.Docking.PLANTS import write_rescoring_config_file, run_rescore as p_rescore, get_binding_site
            pose_list = outdir / "pose_list_single.txt"
            # Use MOL2 format for PLANTS rescoring
            plants_rep = str(rep_mol2_final) if rep_mol2_final and Path(rep_mol2_final).exists() else str(rep_path)
            pose_list.write_text(plants_rep + "\n")
            # Extract center/radius from the box
            binding_site_result = get_binding_site(str(box_path))
            binding_site: Optional[tuple[tuple[float, float, float], float]] = None
            if isinstance(binding_site_result, int):
                ocprint.print_warning(f"Failed to read binding site from {box_path}. Skipping PLANTS rescoring.")
            else:
                binding_site = binding_site_result
            if binding_site is None:
                ocprint.print_warning(f"Skipping PLANTS rescoring for '{box_path}' due to missing binding site.")
            else:
                center, radius = binding_site
                # Get scoring functions from config
                plants_sfs = config.plants.scoring_functions if config.plants.scoring_functions else ["chemplp", "plp", "plp95"]
                for sf in plants_sfs:
                    try:
                        # Each scoring function must have its own output directory (PLANTS requirement)
                        outPath_sf = Path(ctx["plants"]["dir"]) / f"run_{sf}"
                        conf_sf = Path(ctx["plants"]["dir"]) / f"{name}_rescoring_{sf}.txt"
                        write_rescoring_config_file(str(conf_sf), ctx["plants"]["prep_rec"], str(pose_list), str(outPath_sf), center[0], center[1], center[2], radius, scoringFunction=sf)
                        p_rescore(str(conf_sf), str(pose_list), str(outPath_sf), ctx["plants"]["prep_rec"], sf, center[0], center[1], center[2], radius, overwrite=True)
                    except Exception as e:
                        ocprint.print_warning(f"PLANTS rescoring with {sf} failed: {e}. Continuing with other scoring functions...")
                # Read PLANTS rescoring results
                try:
                    from OCDocker.Docking.PLANTS import read_log as plants_read_log
                    plants_rescoring_data: Dict[str, float] = {}
                    for sf in plants_sfs:
                        # Each scoring function has its own directory: run_{scoring_function}
                        ranking_file = Path(ctx["plants"]["dir"]) / f"run_{sf}" / "bestranking.csv"
                        if ranking_file.exists():
                            try:
                                log_data = plants_read_log(str(ranking_file), onlyBest=True)
                                if log_data:
                                    # PLANTS returns Dict[int, Dict[str, float]] where first int is pose number
                                    for _, scores in log_data.items():
                                        # scores is Dict[str, float]
                                        for score_type_code, score_value in scores.items():
                                            key = f"plants_{sf}"
                                            if key not in plants_rescoring_data:
                                                try:
                                                    if isinstance(score_value, list):
                                                        if len(score_value) != 1:
                                                            continue
                                                        plants_rescoring_data[key] = float(score_value[0])
                                                    else:
                                                        plants_rescoring_data[key] = float(score_value)
                                                except (TypeError, ValueError):
                                                    continue
                                        break  # Only take first pose when onlyBest=True
                            except Exception as e:
                                ocprint.print_warning(f"Failed to read PLANTS rescoring results for {sf}: {e}")
                        else:
                            ocprint.print_warning(f"PLANTS rescoring ranking file not found: {ranking_file}")
                    if plants_rescoring_data:
                        rescoring["plants"] = plants_rescoring_data
                    else:
                        ocprint.print_warning("No PLANTS rescoring data found")
                except Exception as e:
                    ocprint.print_warning(f"Failed to read PLANTS rescoring results: {e}")

        # ODDT (can rescore independently, doesn't require docking)
        if "oddt" in rescoring_engines:
            try:
                from OCDocker.Rescoring.ODDT import run_oddt, df_to_dict
                # ODDT needs the prepared receptor - use from any available engine
                prepared_receptor = None
                if "vina" in ctx or "smina" in ctx:
                    # Use PDBQT receptor from vina/smina
                    prepared_receptor = str(outdir / "prepared_receptor.pdbqt")
                elif "plants" in ctx:
                    # Use MOL2 receptor from PLANTS
                    prepared_receptor = ctx["plants"]["prep_rec"]
                else:
                    # Fallback: try to find any prepared receptor
                    pdbqt_rec = outdir / "prepared_receptor.pdbqt"
                    mol2_rec = outdir / "prepared_receptor.mol2"
                    if pdbqt_rec.exists():
                        prepared_receptor = str(pdbqt_rec)
                    elif mol2_rec.exists():
                        prepared_receptor = str(mol2_rec)

                if prepared_receptor and Path(prepared_receptor).exists():
                    # ODDT needs MOL2 format for ligand
                    oddt_ligand = str(rep_mol2_final) if rep_mol2_final and Path(rep_mol2_final).exists() else str(rep_path)
                    oddt_output = outdir / "oddt_rescoring"
                    oddt_output.mkdir(parents=True, exist_ok=True)

                    # Run ODDT rescoring
                    try:
                        df = run_oddt(
                            prepared_receptor,
                            oddt_ligand,
                            name,
                            str(oddt_output),
                            overwrite=True,
                            returnData=True
                        )

                        # Check if run_oddt returned an error code (int) instead of DataFrame
                        if isinstance(df, int):
                            ocprint.print_warning(f"ODDT rescoring returned error code: {df}. Check ODDT configuration and logs.")
                        elif df is not None:
                            try:
                                oddt_dict = df_to_dict(df)
                                # Extract values from ODDT results
                                oddt_vals: Dict[str, float] = {}
                                if isinstance(oddt_dict, int):
                                    ocprint.print_warning(f"ODDT results conversion returned error code: {oddt_dict}")
                                elif oddt_dict:
                                    # Get the first (and typically only) entry (ligand name is the key)
                                    first_key = list(oddt_dict.keys())[0]
                                    for score_name, score_value in oddt_dict[first_key].items():
                                        try:
                                            # Skip non-numeric columns
                                            if score_name.lower() in ['ligand_name', 'name']:
                                                continue
                                            key = f"oddt_{score_name}"
                                            if isinstance(score_value, (int, float)):
                                                oddt_vals[key] = float(score_value)
                                            elif isinstance(score_value, (list, tuple)) and len(score_value) > 0:
                                                oddt_vals[key] = float(score_value[0])
                                            elif isinstance(score_value, str):
                                                # Try to convert string to float
                                                try:
                                                    oddt_vals[key] = float(score_value)
                                                except ValueError:
                                                    pass
                                        except (ValueError, TypeError) as e:
                                            ocprint.print_warning(f"Failed to parse ODDT score {score_name}: {e}")
                                if oddt_vals:
                                    rescoring["oddt"] = oddt_vals
                                else:
                                    ocprint.print_warning(
                                        f"ODDT rescoring completed but no valid scores extracted. Dict keys: "
                                        f"{list(oddt_dict.keys()) if isinstance(oddt_dict, dict) else 'None'}"
                                    )
                            except Exception as e:
                                ocprint.print_warning(f"Failed to convert ODDT results to dictionary: {e}")
                                import traceback
                                ocprint.print_warning(f"Traceback: {traceback.format_exc()}")
                        else:
                            ocprint.print_warning("ODDT rescoring returned None. Check ODDT configuration and logs.")
                    except Exception as e:
                        ocprint.print_warning(f"ODDT rescoring failed: {e}")
                        import traceback
                        ocprint.print_warning(f"Traceback: {traceback.format_exc()}")
                else:
                    ocprint.print_warning("ODDT rescoring skipped: no prepared receptor found")
            except ImportError as e:
                ocprint.print_warning(f"ODDT rescoring not available (import error): {e}")
            except Exception as e:
                ocprint.print_warning(f"ODDT rescoring failed: {e}")

        # Write summary
        # Track which engines were actually used for rescoring (those with results)
        rescoring_engines_used = list(rescoring.keys())
        summ = {
            "job": name,
            "engines": engines,
            "rescoring_engines": rescoring_engines_used,  # Engines that actually produced rescoring results
            "representative_pose": str(rep_path),
            "clustering": clustering_info,
            "rescoring": rescoring,
        }
        (outdir / "summary.json").write_text(json.dumps(summ, indent=2))

        if args.store_db:
            try:
                stored, stored_name, ignored_keys = _store_pipeline_results_in_db(
                    job_name = name,
                    receptor = receptor,
                    ligand = ligand,
                    rescoring = rescoring,
                    box_label = box_label,
                )
                if stored:
                    print(f"Stored pipeline data in database row '{stored_name}'.")
                    if ignored_keys:
                        print(
                            "Warning: some score keys could not be mapped to Complexes columns and were skipped: "
                            + ", ".join(ignored_keys)
                        )
                else:
                    print("Warning: failed to store pipeline data in DB (upsert returned False).")
            except Exception as e:
                print(f"Warning: failed to store to DB: {e}")

        print(f"Pipeline finished. Representative pose: {rep_path}")
        return 0


    boxes = _list_boxes(ligand_path.parent, box_path, args.all_boxes)
    if args.all_boxes and not boxes:
        print("Warning: no box*.pdb files found. Skipping pipeline.")
        return 2

    if args.all_boxes:
        overall_rc = 0
        use_multi_boxes = len(boxes) > 1
        for box in boxes:
            box_id = box.stem
            box_outdir = base_outdir / box_id if use_multi_boxes else base_outdir
            rc = _run_pipeline_for_box(box, box_outdir, box_id if use_multi_boxes else None)
            if rc != 0:
                overall_rc = rc
        return overall_rc

    return _run_pipeline_for_box(box_path, base_outdir, None)


def cmd_script(args: argparse.Namespace) -> int:  # pragma: no cover - script execution is user-provided code
    '''Run a Python script with OCDocker libraries pre-loaded.

    Bootstraps the environment, loads all OCDocker modules, and executes
    the provided script file with those modules available in the namespace.

    Parameters
    ----------
    args : argparse.Namespace
        Command-line arguments. Must contain 'script_file' and optionally
        'script_args'. Dynamic execution requires explicit trust via
        '--allow-unsafe-exec' or 'OCDOCKER_ALLOW_SCRIPT_EXEC=1'.

    Returns
    -------
    int
        Exit code (0 for success, 1 for failure, 2 for blocked unsafe execution).
    '''

    # Dynamic in-process execution is a trust boundary.
    try:
        ocsec.require_trusted_input(
            trusted=bool(getattr(args, "allow_unsafe_exec", False)),
            operation="dynamic script execution",
            env_var="OCDOCKER_ALLOW_SCRIPT_EXEC",
            source=str(getattr(args, "script_file", "")),
        )
    except PermissionError as e:
        print(f"Security check failed: {e}")
        return 2

    # Bootstrap env to ensure Initialise is safe to import
    globals_ns = _preparse_global_args(sys.argv[1:])
    setattr(globals_ns, "_ocdocker_init_db", False)
    _bootstrap_ocdocker_env(globals_ns)

    # Configure logging according to CLI flags
    try:
        import OCDocker.Error as ocerror
        import OCDocker.Toolbox.Logging as oclogging
        oclogging.configure(level=ocerror.Error.get_output_level(), log_file=args.log_file, to_stdout=(not args.no_stdout_log))
    except (ImportError, AttributeError, OSError):
        # Ignore logging configuration errors (non-critical for core functionality)
        pass

    # Validate script file exists
    script_path = Path(args.script_file)
    if not script_path.exists():
        print(f"Error: Script file not found: {script_path}")
        return 1

    if not script_path.is_file():
        print(f"Error: Path is not a file: {script_path}")
        return 1

    # Load OCDocker libraries into namespace (similar to OCDockerConsole)
    script_namespace = {}

    # Import all OCDocker modules
    try:
        # Import Initialise module and add all non-dunder symbols to namespace
        import OCDocker.Initialise as ocinit
        for k, v in vars(ocinit).items():
            if not k.startswith('__'):
                script_namespace[k] = v

        import OCDocker.Toolbox as octools
        script_namespace['octools'] = octools
        script_namespace['ocsec'] = ocsec
        script_namespace['allow_unsafe_runtime'] = ocsec.allow_unsafe_runtime

        import OCDocker.Ligand as ocl
        script_namespace['ocl'] = ocl

        import OCDocker.Receptor as ocr
        script_namespace['ocr'] = ocr

        import OCDocker.Docking.Vina as ocvina
        script_namespace['ocvina'] = ocvina

        import OCDocker.Docking.Smina as ocsmina
        script_namespace['ocsmina'] = ocsmina

        import OCDocker.Docking.PLANTS as ocplants
        script_namespace['ocplants'] = ocplants

        import OCDocker.Processing.Preprocessing.RmsdClustering as ocrmsdclust
        script_namespace['ocrmsdclust'] = ocrmsdclust

        try:
            import OCDocker.Rescoring.ODDT as ocoddt
            script_namespace['ocoddt'] = ocoddt
        except ModuleNotFoundError as exc:
            missing_mod = getattr(exc, 'name', '')
            if missing_mod == 'oddt' or missing_mod.startswith('oddt.'):
                print("Warning: optional dependency 'oddt' is not installed; 'ocoddt' is unavailable in script mode.")
            else:
                raise

        import OCDocker.Toolbox.Conversion as occonversion
        script_namespace['occonversion'] = occonversion

        import OCDocker.Toolbox.MoleculeProcessing as ocmolproc
        script_namespace['ocmolproc'] = ocmolproc

        # Add standard library modules that scripts commonly need
        from glob import glob
        from pprint import pprint
        script_namespace['os'] = os
        script_namespace['sys'] = sys
        script_namespace['Path'] = Path
        script_namespace['glob'] = glob
        script_namespace['pprint'] = pprint

    except ModuleNotFoundError as e:
        extra = _suggest_extra_for_missing_module(getattr(e, "name", ""))
        return _print_optional_dependency_hint(
            feature="script mode preloaded modules",
            extra=extra,
            exc=e,
        )
    except Exception as e:
        print(f"Error loading OCDocker libraries: {e}")
        import traceback
        traceback.print_exc()
        return 1

    # Update sys.argv to include script args for the script's use
    original_argv = sys.argv[:]
    try:
        # Set sys.argv to: [script_file, ...script_args]
        sys.argv = [str(script_path)] + (args.script_args or [])

        # Read and execute the script
        script_content = script_path.read_text(encoding='utf-8')

        # Compile the script for better error messages
        try:
            compiled_script = compile(script_content, str(script_path), 'exec')
        except SyntaxError as e:
            print(f"Syntax error in script {script_path}:")
            print(f"  Line {e.lineno}: {e.text}")
            print(f"  {e.msg}")
            return 1

        # Execute the script with the loaded namespace
        exec(compiled_script, script_namespace)

        return 0

    except SystemExit as e:
        # Script called sys.exit(), respect its exit code
        return int(e.code) if e.code is not None else 0
    except KeyboardInterrupt:
        print("\nScript execution interrupted by user.")
        return 130  # Standard exit code for SIGINT
    except Exception as e:
        print(f"Error executing script {script_path}:")
        import traceback
        traceback.print_exc()
        return 1
    finally:
        # Restore original sys.argv
        sys.argv = original_argv


def cmd_shap(args: argparse.Namespace) -> int:  # pragma: no cover - delegates to external OCScore CLI
    '''Run SHAP analysis.

    This function serves as a command-line interface for running SHAP analysis
    on the specified data.

    Parameters
    ----------
    args : argparse.Namespace
        Command-line arguments.

    Returns
    -------
    int
        Exit code (0 for success, 1 for failure).
    '''

    # No heavy OCDocker env needed for SHAP module, just dispatch
    try:
        from OCDocker.OCScore.Analysis.SHAP.Cli import main as shap_main
    except ModuleNotFoundError as exc:
        extra = _suggest_extra_for_missing_module(getattr(exc, "name", ""))
        return _print_optional_dependency_hint(
            feature="SHAP analysis",
            extra=extra,
            exc=exc,
        )
    return int(shap_main([
        "--storage", args.storage,
        "--ao_study", args.ao_study,
        "--nn_study", args.nn_study,
        "--seed_study", args.seed_study,
        "--mask_study", args.mask_study,
        "--df_path", args.df_path,
        "--base_models", args.base_models,
        "--study_number", str(args.study_number),
        "--out_dir", args.out_dir,
        "--explainer", args.explainer,
        *( ["--background_size", str(args.background_size)] if args.background_size is not None else [] ),
        *( ["--eval_size", str(args.eval_size)] if args.eval_size is not None else [] ),
        *( ["--stratify_by", *args.stratify_by] if args.stratify_by else [] ),
        "--seed", str(args.seed),
        *( ["--no_csv"] if args.no_csv else [] ),
    ]))


def cmd_manifest(args: argparse.Namespace) -> int:
    '''Generate and print a reproducibility manifest.

    Parameters
    ----------
    args : argparse.Namespace
        Command-line arguments.

    Returns
    -------
    int
        Exit code (0 for success, 1 for failure).
    '''

    bootstrap_status: Dict[str, Optional[str]] = {"status": "skipped", "error": None}
    globals_ns = _preparse_global_args(sys.argv[1:])
    setattr(globals_ns, "_ocdocker_init_db", False)
    try:
        _bootstrap_ocdocker_env(globals_ns)
        bootstrap_status["status"] = "ok"
    except Exception as exc:
        # Manifest generation should still succeed even if config bootstrap fails.
        bootstrap_status["status"] = "error"
        bootstrap_status["error"] = f"{type(exc).__name__}: {exc}"

    manifest = generate_reproducibility_manifest(include_python_packages=(not args.no_packages))
    manifest["bootstrap"] = bootstrap_status

    payload = json.dumps(manifest, indent=2, sort_keys=True)

    output_path = getattr(args, "output", None)
    if output_path:
        try:
            out = Path(output_path)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(payload + "\n", encoding="utf-8")
        except (OSError, ValueError) as exc:
            print(f"Error: failed to write manifest file '{output_path}': {exc}")
            return 1

    print(payload)
    return 0


def cmd_version(args: argparse.Namespace) -> int:
    '''Print package version without bootstrapping the full environment.

    Parameters
    ----------
    args : argparse.Namespace
        Command-line arguments.

    Returns
    -------
    int
        Exit code (0 for success, 1 for failure).
    '''

    _ = args
    print(_collect_ocdocker_version())
    return 0


def cmd_vs(args: argparse.Namespace) -> int:  # pragma: no cover - heavy integration path, exercised by engine-specific tests
    '''Run a simple docking with the selected engine.

    Flow: prepare receptor/ligand, run docking, split poses (when applicable),
    and optionally run rescoring.

    Parameters
    ----------
    args : argparse.Namespace
        Command-line arguments.

    Returns
    -------
    int
        Exit code (0 for success, 1 for failure).
    '''

    if args.store_db:
        db_ok, db_exc = _db_dependencies_available()
        if not db_ok and db_exc is not None:
            return _print_optional_dependency_hint(
                feature="database storage (--store-db)",
                extra="db",
                exc=db_exc,
            )

    # Bootstrap environment before importing engines
    globals_ns = _preparse_global_args(sys.argv[1:])
    setattr(globals_ns, "_ocdocker_init_db", bool(getattr(args, "store_db", False)))
    _bootstrap_ocdocker_env(globals_ns)

    # Configure logging according to CLI flags
    try:
        import OCDocker.Error as ocerror
        import OCDocker.Toolbox.Logging as oclogging
        oclogging.configure(
            level=ocerror.Error.get_output_level(),
            log_file=args.log_file,
            to_stdout=(not args.no_stdout_log),
        )
    except (ImportError, AttributeError, OSError):
        # Ignore logging configuration errors (non-critical for core functionality)
        pass

    # Optionally set timeout for external processes
    if args.timeout:
        os.environ["OCDOCKER_TIMEOUT"] = str(args.timeout)

    # Imports after env is ready
    try:
        import OCDocker.Ligand as ocl
        import OCDocker.Receptor as ocr
        import importlib
    except ModuleNotFoundError as exc:
        extra = _suggest_extra_for_missing_module(getattr(exc, "name", ""))
        return _print_optional_dependency_hint(
            feature="single-engine docking workflow",
            extra=extra,
            exc=exc,
        )
    engine_mod: Any
    if args.engine == "vina":
        engine_mod = importlib.import_module("OCDocker.Docking.Vina")
        eng = "vina"
    elif args.engine == "smina":
        engine_mod = importlib.import_module("OCDocker.Docking.Smina")
        eng = "smina"
    elif args.engine == "gnina":
        engine_mod = importlib.import_module("OCDocker.Docking.Gnina")
        eng = "gnina"
    else:
        engine_mod = importlib.import_module("OCDocker.Docking.PLANTS")
        eng = "plants"

    # Validate engine binary availability based on configuration
    _vina_bin: Optional[str] = None
    _smina_bin: Optional[str] = None
    _gnina_bin: Optional[str] = None
    _plants_bin: Optional[str] = None
    try:
        from OCDocker.Config import get_config
        config = get_config()
        _vina_bin = config.vina.executable
        _smina_bin = config.smina.executable
        _gnina_bin = config.gnina.executable
        _plants_bin = config.plants.executable
    except (ImportError, AttributeError):
        # Fallback if binaries are not configured
        pass

    def _exists_exe(p: Optional[str]) -> bool:
        if not p:
            return False
        if os.path.isabs(p):
            return os.path.isfile(p) and os.access(p, os.X_OK)
        return shutil.which(p) is not None

    if eng == "vina" and not _exists_exe(_vina_bin):
        print("Error: Vina binary not found. Check 'vina' in OCDocker.cfg or PATH.")
        return 2
    if eng == "smina" and not _exists_exe(_smina_bin):
        print("Error: Smina binary not found. Check 'smina' in OCDocker.cfg or PATH.")
        return 2
    if eng == "gnina" and not _exists_exe(_gnina_bin):
        print("Error: Gnina binary not found. Check 'gnina' in OCDocker.cfg or PATH.")
        return 2
    if eng == "plants" and not _exists_exe(_plants_bin):
        print("Error: PLANTS binary not found. Check 'plants' in OCDocker.cfg or PATH.")
        return 2

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    name = args.name or Path(args.ligand).stem

    # Validate inputs and derive default locations (mimic Console/tests)
    receptor_path = _require_file(str(args.receptor), "--receptor")
    ligand_path = _require_file(str(args.ligand), "--ligand")
    box_path = _require_file(str(args.box), "--box")

    ligand_dir = ligand_path.parent
    receptor_dir = receptor_path.parent
    boxes = _list_boxes(ligand_dir, box_path, args.all_boxes)
    if args.all_boxes and not boxes:
        print("Warning: no box*.pdb files found. Skipping docking.")
        return 2
    use_multi_boxes = args.all_boxes and len(boxes) > 1

    if eng == "vina":
        base_files_dir = ligand_dir / "vinaFiles"
        conf_name = "conf_vina.txt"
        prep_rec = receptor_dir / "prepared_receptor.pdbqt"
        prep_lig = ligand_dir / "prepared_ligand.pdbqt"
        log_name = f"{name}.log"
        out_name = f"{name}.pdbqt"
    elif eng == "smina":
        base_files_dir = ligand_dir / "sminaFiles"
        conf_name = "conf_smina.txt"
        prep_rec = receptor_dir / "prepared_receptor.pdbqt"
        prep_lig = ligand_dir / "prepared_ligand.pdbqt"
        log_name = f"{name}.log"
        out_name = f"{name}.pdbqt"
    elif eng == "gnina":
        base_files_dir = ligand_dir / "gninaFiles"
        conf_name = "conf_gnina.conf"
        prep_rec = receptor_dir / "prepared_receptor.pdbqt"
        prep_lig = ligand_dir / "prepared_ligand.pdbqt"
        log_name = f"{name}.log"
        out_name = f"{name}.pdbqt"
    else:  # plants
        base_files_dir = ligand_dir / "plantsFiles"
        conf_name = "conf_plants.txt"
        prep_rec = receptor_dir / "prepared_receptor.mol2"
        prep_lig = ligand_dir / "prepared_ligand.mol2"
        log_name = f"{name}.log"
        out_name = None  # PLANTS output directory
    base_files_dir.mkdir(parents=True, exist_ok=True)

    # Create domain objects
    receptor = ocr.Receptor(str(receptor_path), name=f"{name}_receptor")
    ligand = ocl.Ligand(str(ligand_path), name=f"{name}_ligand")

    # Prepare and run
    import os as _os
    prep_rec_path = str(prep_rec)
    prep_lig_path = str(prep_lig)
    # Overwrite handling: remove existing prepared files to force regeneration
    if args.overwrite:
        try:
            if _os.path.isfile(prep_rec_path):
                _os.remove(prep_rec_path)
        except (OSError, FileNotFoundError, PermissionError):
            # Ignore if file doesn't exist or can't be removed
            pass
        try:
            if _os.path.isfile(prep_lig_path):
                _os.remove(prep_lig_path)
        except (OSError, FileNotFoundError, PermissionError):
            # Ignore if file doesn't exist or can't be removed
            pass

    # Logs for preparation
    prep_rec_log = base_files_dir / "prepare_receptor.log"
    prep_lig_log = base_files_dir / "prepare_ligand.log"

    overall_rc = 0
    prep_done = False
    for box in boxes:
        box_id = box.stem
        box_files_dir = base_files_dir / box_id if use_multi_boxes else base_files_dir
        box_files_dir.mkdir(parents=True, exist_ok=True)
        conf_path = box_files_dir / conf_name
        log_path = box_files_dir / log_name
        out_pose = box_files_dir if out_name is None else box_files_dir / out_name

        if eng == "vina":
            dock = engine_mod.Vina
            runner = dock(
                str(conf_path), str(box), receptor, str(prep_rec), ligand,
                str(prep_lig), str(log_path), str(out_pose), name=f"VINA {name}", overwrite_config=True,
            )
        elif eng == "smina":
            dock = engine_mod.Smina
            runner = dock(
                str(conf_path), str(box), receptor, str(prep_rec), ligand,
                str(prep_lig), str(log_path), str(out_pose), name=f"SMINA {name}", overwrite_config=True,
            )
        elif eng == "gnina":
            dock = engine_mod.Gnina
            runner = dock(
                str(conf_path), str(box), receptor, str(prep_rec), ligand,
                str(prep_lig), str(log_path), str(out_pose), name=f"GNINA {name}", overwrite_config=True,
            )
        else:
            dock = engine_mod.PLANTS
            runner = dock(
                str(conf_path), str(box), receptor, str(prep_rec), ligand,
                str(prep_lig), str(log_path), str(out_pose), name=f"PLANTS {name}", overwrite_config=True,
            )

        if not prep_done:
            # Receptor preparation
            if not (_os.path.isfile(prep_rec_path) and _os.path.getsize(prep_rec_path) > 0):
                if eng in ("vina", "smina", "plants"):
                    rc = runner.run_prepare_receptor(logFile=str(prep_rec_log))
                else:
                    rc = runner.run_prepare_receptor(overwrite=args.overwrite)
                if isinstance(rc, tuple):
                    rc = rc[0]
                if rc != 0 and eng in ("vina", "smina"):
                    # Fallback via OpenBabel
                    rc_fb = runner.run_prepare_receptor(logFile=str(prep_rec_log), useOpenBabel=True)
                    if isinstance(rc_fb, tuple):
                        rc_fb = rc_fb[0]
                    if rc_fb != 0:
                        print(f"Error: receptor preparation failed. See {prep_rec_log}")
                        return int(rc)
                elif rc != 0:
                    print(f"Error: receptor preparation failed. See {prep_rec_log}")
                    return int(rc)

            # Ligand preparation
            if not (_os.path.isfile(prep_lig_path) and _os.path.getsize(prep_lig_path) > 0):
                if eng in ("vina", "smina", "plants"):
                    rc = runner.run_prepare_ligand(logFile=str(prep_lig_log))
                else:
                    rc = runner.run_prepare_ligand(overwrite=args.overwrite)
                if isinstance(rc, tuple):
                    rc = rc[0]
                if rc != 0 and eng in ("vina", "smina"):
                    # Fallback via OpenBabel
                    rc_fb = runner.run_prepare_ligand(logFile=str(prep_lig_log), useOpenBabel=True)
                    if isinstance(rc_fb, tuple):
                        rc_fb = rc_fb[0]
                    if rc_fb != 0:
                        print(f"Error: ligand preparation failed. See {prep_lig_log}")
                        return int(rc)
                elif rc != 0:
                    print(f"Error: ligand preparation failed. See {prep_lig_log}")
                    return int(rc)
            prep_done = True

        rc = runner.run_docking()
        if isinstance(rc, tuple):
            rc = rc[0]
        if rc != 0:
            overall_rc = int(rc)
            print(f"Warning: docking failed for box '{box_id}'.")
            continue

        if not args.skip_split and eng in ("vina", "smina", "gnina"):
            _ = runner.split_poses(str(box_files_dir))

        if not args.skip_rescore:
            if eng in ("vina", "smina", "gnina"):
                runner.run_rescore(str(box_files_dir), prep_lig_path, skipDefaultScoring=True)
            else:
                pose_list = runner.write_pose_list(overwrite=True)
                if pose_list:
                    runner.run_rescore(pose_list, overwrite=True)

        if use_multi_boxes:
            print(f"Completed {eng} for job '{name}' (box {box_id}). Outputs in: {box_files_dir}")
        else:
            print(f"Completed {eng} for job '{name}'. Outputs in: {box_files_dir}")
    # Optional DB store
    if args.store_db:
        try:
            stored, stored_name, _ = _store_pipeline_results_in_db(
                job_name = name,
                receptor = receptor,
                ligand = ligand,
                rescoring = {},
                box_label = None,
            )
            if stored:
                print(f"Stored docking data in database row '{stored_name}'.")
            else:
                print("Warning: failed to store docking data in DB (upsert returned False).")
        except Exception as e:
            print(f"Warning: failed to store to DB: {e}")
    return overall_rc


def main(argv: Optional[list[str]] = None) -> int:
    '''Main entry point for the CLI.

    Parameters
    ----------
    argv : Optional[list[str]]
        Command-line arguments.

    Returns
    -------
    int
        Exit code (0 for success, 1 for failure).
    '''

    argv = sys.argv[1:] if argv is None else argv
    parser = build_parser()
    args = parser.parse_args(argv)

    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
