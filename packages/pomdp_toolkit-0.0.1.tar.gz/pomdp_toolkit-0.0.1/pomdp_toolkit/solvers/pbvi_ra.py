from pomdp_toolkit import ValueFunction
from pomdp_toolkit import BeliefSet
from pomdp_toolkit.solvers.pbvi import PBVI

import numpy as np
gpu_support = False
try:
    import cupy as cp
    gpu_support = True
except:
    print('[Warning] Cupy could not be loaded: GPU support is not available.')


class PBVI_RA(PBVI):
    '''
    # TODO
    '''
    @staticmethod
    def expand(belief_set: BeliefSet,
               value_function: ValueFunction,
               max_generation: int,
               use_gpu: bool = False,
               rng: int | np.random.Generator = 12131415
               ) -> BeliefSet:
        '''
        This expansion technique relies only randomness and will generate at most 'max_generation' beliefs.

        Parameters
        ----------
        belief_set : BeliefSet
            List of beliefs to expand on.
        value_function : ValueFunction
            The current value function. (NOT USED)
        max_generation : int, default=10
            The max amount of beliefs that can be added to the belief set at once.
        use_gpu : bool, default=False
            Whether to use the GPU with cupy array to accelerate solving.
        rng : int or np.random.Generator, default=12131415
            A seed for random generation or directly a numpy random generator.

        Returns
        -------
        new_belief_set : BeliefSet
            Union of the belief_set and the expansions of the beliefs in the belief_set.
        '''
        # GPU support
        xp = np if not use_gpu else cp

        # Retrieve the POMDP from the value function
        pomdp = belief_set.pomdp

        # If rng is an integer, we use it as a seed for the random generator
        if isinstance(rng, int):
            rng = xp.random.default_rng(rng)

        # How many new beliefs to add
        generation_count = min(belief_set.belief_array.shape[0], max_generation)

        # Generation of the new beliefs at random
        new_beliefs = rng.random((generation_count, pomdp.state_count))
        new_beliefs /= xp.sum(new_beliefs, axis=1)[:,None]

        return BeliefSet(pomdp, new_beliefs)