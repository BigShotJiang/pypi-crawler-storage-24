from pomdp_toolkit import ValueFunction
from pomdp_toolkit import BeliefSet
from pomdp_toolkit.solvers.pbvi import PBVI

import numpy as np
gpu_support = False
try:
    import cupy as cp
    gpu_support = True
except:
    print('[Warning] Cupy could not be loaded: GPU support is not available.')


class HSVI(PBVI):
    '''
    # TODO: Do document of HSVI agent
    # TODO: FIX HSVI expand
    '''
    @classmethod
    def expand(cls,
               belief_set: BeliefSet,
               value_function: ValueFunction,
               max_generation: int,
               use_gpu: bool = False,
               rng: int | np.random.Generator = 12131415
               ) -> BeliefSet:
        '''
        The expand function of the  Heuristic Search Value Iteration (HSVI) technique.
        It is a redursive function attempting to minimize the bound between the upper and lower estimations of the value function.

        It is developped by Smith T. and Simmons R. and described in the paper "Heuristic Search Value Iteration for POMDPs".

        Parameters
        ----------
        belief_set : BeliefSet
            List of beliefs to expand on.
        value_function : ValueFunction
            The current value function. Used to compute the value at belief points.
        max_generation : int, default=10
            The max amount of beliefs that can be added to the belief set at once.
        use_gpu : bool, default=False
            Whether to use the GPU with cupy array to accelerate solving.
        rng : int or np.random.Generator, default=12131415 (NOT USED)
            A seed for random generation or directly a numpy random generator.

        Returns
        -------
        belief_set : BeliefSet
            A new sequence of beliefs.
        '''
        # GPU support
        xp = np if not use_gpu else cp

        # Retrieve the POMDP from the value function
        pomdp = belief_set.pomdp

        if conv_term is None:
            conv_term = self.eps

        # Update convergence term
        conv_term /= self.gamma

        # Find best a based on upper bound v
        max_qv = -xp.inf
        best_a = -1
        for a in pomdp.actions:
            b_probs = xp.einsum('sor,s->o', pomdp.reachable_transitional_observation_table[:,a,:,:], b.values)

            b_prob_val = 0
            for o in pomdp.observations:
                b_prob_val += (b_probs[o] * upper_bound_belief_value_map.evaluate(b.update(a,o)))

            qva = float(xp.dot(pomdp.expected_rewards_table[:,a], b.values) + (self.gamma * b_prob_val))

            # qva = upper_bound_belief_value_map.qva(b, a, gamma=self.gamma)
            if qva > max_qv:
                max_qv = qva
                best_a = a

        # Choose o that max gap between bounds
        b_probs = xp.einsum('sor,s->o', pomdp.reachable_transitional_observation_table[:,best_a,:,:], b.values)

        max_o_val = -xp.inf
        best_v_diff = -xp.inf
        next_b = b

        for o in pomdp.observations:
            bao = b.update(best_a, o)

            upper_v_bao = upper_bound_belief_value_map.evaluate(bao)
            lower_v_bao = xp.max(xp.dot(value_function.alpha_vector_array, bao.values))

            v_diff = (upper_v_bao - lower_v_bao)

            o_val = b_probs[o] * v_diff

            if o_val > max_o_val:
                max_o_val = o_val
                best_v_diff = v_diff
                next_b = bao

        # if bounds_split < conv_term or max_generation <= 0:
        if best_v_diff < conv_term or max_generation <= 1:
            return BeliefSet(pomdp, [next_b])

        # Add the belief point and associated value to the belief-value mapping
        upper_bound_belief_value_map.add(b, max_qv)

        # Go one step deeper in the recursion
        b_set = cls.expand(b=next_b,
                           value_function=value_function,
                           upper_bound_belief_value_map=upper_bound_belief_value_map,
                           conv_term=conv_term,
                           max_generation=max_generation-1)

        # Append the nex belief of this iteration to the deeper beliefs
        new_belief_list = b_set.belief_list
        new_belief_list.append(next_b)

        return BeliefSet(pomdp, new_belief_list)