from pomdp_toolkit import ValueFunction
from pomdp_toolkit import Belief, BeliefSet
from pomdp_toolkit.solvers.pbvi import PBVI

import numpy as np
gpu_support = False
try:
    import cupy as cp
    gpu_support = True
except:
    print('[Warning] Cupy could not be loaded: GPU support is not available.')


class PBVI_SSGA(PBVI):
    '''
    # TODO
    '''
    @staticmethod
    def expand(belief_set: BeliefSet,
               value_function: ValueFunction,
               max_generation: int,
               use_gpu: bool = False,
               rng: int | np.random.Generator = 12131415,
               epsilon: float = 0.99
               ) -> BeliefSet:
        '''
        Stochastic Simulation with Greedy Action.
        Simulates running a single-step forward from the beliefs in the "belief_set".
        The step forward is taking assuming we are in a random state s (weighted by the belief),
        then taking the best action a based on the belief with probability 'epsilon'.
        These lead to a new state s_p and a observation o.
        From this action a and observation o we can update our belief.

        Note
        ----
        The function will not check whether the value_functions and belief_set provided are on the gpu or not and whether this is consistent with the use_gpu parameter.

        Parameters
        ----------
        belief_set : BeliefSet
            List of beliefs to expand on.
        value_function : ValueFunction
            The current value function. (NOT USED)
        max_generation : int, default=10
            The max amount of beliefs that can be added to the belief set at once.
        use_gpu : bool, default=False
            Whether to use the GPU with cupy array to accelerate solving.
        rng : int or np.random.Generator, default=12131415
            A seed for random generation or directly a numpy random generator.
        epsilon : float, default=0.99
            The epsilon parameter that determines whether to choose an action greedily or randomly.

        Returns
        -------
        belief_set_new : BeliefSet
            Union of the belief_set and the expansions of the beliefs in the belief_set.
        '''
        # GPU support
        xp = np if not use_gpu else cp

        # Retrieve the POMDP from the value function
        pomdp = belief_set.pomdp

        # If rng is an integer, we use it as a seed for the random generator
        if isinstance(rng, int):
            rng = xp.random.default_rng(rng)

        old_shape = belief_set.belief_array.shape
        to_generate = min(max_generation, old_shape[0])

        new_belief_array = xp.empty((to_generate, old_shape[1]))

        # Random previous beliefs
        rand_ind = rng.choice(np.arange(old_shape[0]), to_generate, replace=False)

        for i, belief_vector in enumerate(belief_set.belief_array[rand_ind]):
            b = Belief(pomdp, belief_vector)
            s = b.random_state()

            if rng.random() < epsilon:
                a = rng.choice(pomdp.actions)
            else:
                best_alpha_index = xp.argmax(xp.dot(value_function.alpha_vector_array, b.values))
                a = value_function.actions[best_alpha_index]

            s_p = pomdp.transition(s, a)
            o = pomdp.observe(s_p, a)
            b_new = b.update(a, o)

            new_belief_array[i] = b_new.values

        return BeliefSet(pomdp, new_belief_array)