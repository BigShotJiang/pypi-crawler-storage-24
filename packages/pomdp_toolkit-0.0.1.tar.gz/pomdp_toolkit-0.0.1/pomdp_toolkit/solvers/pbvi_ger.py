from pomdp_toolkit import ValueFunction
from pomdp_toolkit import BeliefSet
from pomdp_toolkit.solvers.pbvi import PBVI

import numpy as np
gpu_support = False
try:
    import cupy as cp
    gpu_support = True
except:
    print('[Warning] Cupy could not be loaded: GPU support is not available.')


class PBVI_GER(PBVI):
    '''
    # TODO
    '''
    @staticmethod
    def expand(belief_set: BeliefSet,
               value_function: ValueFunction,
               max_generation: int,
               use_gpu: bool = False,
               rng: int | np.random.Generator = 12131415,
               gamma: float = 0.99
               ) -> BeliefSet:
        '''
        Greedy Error Reduction.
        It attempts to choose the believes that will maximize the improvement of the value function by minimizing the error.
        The error is computed by the sum of the change between two beliefs and their two corresponding alpha vectors.

        Note
        ----
        The function will not check whether the value_functions and belief_set provided are on the gpu or not and whether this is consistent with the use_gpu parameter.

        Parameters
        ----------
        belief_set : BeliefSet
            List of beliefs to expand on.
        value_function : ValueFunction
            The current value function. Used to compute the value at belief points.
        max_generation : int, default=10
            The max amount of beliefs that can be added to the belief set at once.
        use_gpu : bool, default=False
            Whether to use the GPU with cupy array to accelerate solving.
        rng : int or np.random.Generator, default=12131415
            A seed for random generation or directly a numpy random generator.
        gamma : float, default=0.99
            The discount factor to value immediate rewards more than long term rewards.
            The learning rate is 1/gamma.

        Returns
        -------
        belief_set_new : BeliefSet
            Union of the belief_set and the expansions of the beliefs in the belief_set.
        '''
        # GPU support
        xp = np if not use_gpu else cp

        # Retrieve the POMDP from the value function
        pomdp = belief_set.pomdp

        old_shape = belief_set.belief_array.shape
        to_generate = min(max_generation, old_shape[0])

        new_belief_array = xp.empty((old_shape[0] + to_generate, old_shape[1]))
        new_belief_array[:old_shape[0]] = belief_set.belief_array

        # Finding the min and max rewards for computation of the epsilon
        r_min = pomdp._min_reward / (1 - gamma)
        r_max = pomdp._max_reward / (1 - gamma)

        # Generation of all potential successor beliefs
        successor_beliefs = xp.array([[[b.update(a,o).values for o in pomdp.observations] for a in pomdp.actions] for b in belief_set.belief_list])

        # Finding the alphas associated with each previous beliefs
        best_alpha = xp.argmax(xp.dot(belief_set.belief_array, value_function.alpha_vector_array.T), axis = 1)
        b_alphas = value_function.alpha_vector_array[best_alpha]

        # Difference between beliefs and their successors
        b_diffs = successor_beliefs - belief_set.belief_array[:,None,None,:]

        # Computing a 'next' alpha vector made of the max and min
        alphas_p = xp.where(b_diffs >= 0, r_max, r_min)

        # Difference between alpha vectors and their successors alpha vector
        alphas_diffs = alphas_p - b_alphas[:,None,None,:]

        # Computing epsilon for all successor beliefs
        eps = xp.einsum('baos,baos->bao', alphas_diffs, b_diffs)

        # Computing the probability of the b and doing action a and receiving observation o
        bao_probs = xp.einsum('bs,saor->bao', belief_set.belief_array, pomdp.reachable_transitional_observation_table)

        # Taking the sumproduct of the probs with the epsilons
        res = xp.einsum('bao,bao->ba', bao_probs, eps)

        # Picking the correct amount of initial beliefs and ideal actions
        b_stars, a_stars = xp.unravel_index(xp.argsort(res, axis=None)[::-1][:to_generate], res.shape)

        # And picking the ideal observations
        o_star = xp.argmax(bao_probs[b_stars[:,None], a_stars[:,None], pomdp.observations[None,:]] * eps[b_stars[:,None], a_stars[:,None], pomdp.observations[None,:]], axis=1)

        # Selecting the successor beliefs
        new_belief_array = successor_beliefs[b_stars[:,None], a_stars[:,None], o_star[:,None], pomdp.states[None,:]]

        return BeliefSet(pomdp, new_belief_array)