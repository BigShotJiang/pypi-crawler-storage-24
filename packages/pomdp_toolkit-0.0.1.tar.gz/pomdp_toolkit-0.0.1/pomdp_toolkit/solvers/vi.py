from datetime import datetime
from tqdm.auto import trange

from pomdp_toolkit.solvers import MDPSolveHistory
from pomdp_toolkit import ValueFunction
from pomdp_toolkit import MDP

import numpy as np
gpu_support = False
try:
    import cupy as cp
    gpu_support = True
except:
    print('[Warning] Cupy could not be loaded: GPU support is not available.')


class VI:
    @staticmethod
    def solve(mdp: MDP,
            horizon: int = 100,
            initial_value_function: ValueFunction | None = None,
            gamma: float = 0.99,
            eps: float = 1e-6,
            use_gpu: bool = False,
            history_tracking_level: int = 1,
            print_progress: bool = True
            ) -> tuple[ValueFunction, MDPSolveHistory]:
        '''
        Function to solve an MDP using Value Iteration.
        If an initial value function is not provided, the value function will be initiated with the expected rewards.

        Parameters
        ----------
        mdp : mdp.MDP
            The MDP on which to run value iteration.
        horizon : int, default=100
            How many iterations to run the value iteration solver for.
        initial_value_function : ValueFunction, optional
            An optional initial value function to kick-start the value iteration process.
        gamma : float, default=0.99
            The discount factor to value immediate rewards more than long term rewards.
            The learning rate is 1/gamma.
        eps : float, default=1e-6
            The smallest allowed changed for the value function.
            Bellow the amound of change, the value function is considered converged and the value iteration process will end early.
        use_gpu : bool, default=False
            Whether to use the GPU with cupy array to accelerate solving.
        history_tracking_level : int, default=1
            How thorough the tracking of the solving process should be. (0: Nothing; 1: Times and sizes of belief sets and value function; 2: The actual value functions and beliefs sets)
        print_progress : bool, default=True
            Whether or not to print out the progress of the value iteration process.

        Returns
        -------
        value_function: ValueFunction
            The resulting value function solution to the mdp.
        history : solvers.MDPSolveHistory
            The tracking of the solution over time.
        '''
        # GPU support
        if use_gpu:
            assert gpu_support, "GPU support is not enabled, Cupy might need to be installed..."

        xp = np if not use_gpu else cp
        mdp = mdp if not use_gpu else mdp.gpu_model

        # Value function initialization
        if initial_value_function is None:
            V = ValueFunction(mdp, mdp.expected_rewards_table.T, mdp.actions)
        else:
            V = initial_value_function.to_gpu() if use_gpu else initial_value_function
        V_opt = xp.max(V.alpha_vector_array, axis=0)

        # History tracking setup
        solve_history = MDPSolveHistory(tracking_level=history_tracking_level,
                                    model=mdp,
                                    gamma=gamma,
                                    eps=eps,
                                    initial_value_function=V)

        # Computing max allowed change from epsilon and gamma parameters
        max_allowed_change = eps * (gamma / (1-gamma))

        iterator = trange(horizon) if print_progress else range(horizon)
        for _ in iterator:
            old_V_opt = V_opt

            start = datetime.now()

            # Computing the new alpha vectors
            alpha_vectors = mdp.expected_rewards_table.T + (gamma * xp.einsum('sar,sar->as', mdp.reachable_probabilities, V_opt[mdp.reachable_states]))
            V = ValueFunction(mdp, alpha_vectors, mdp.actions)

            V_opt = xp.max(V.alpha_vector_array, axis=0)

            # Change computation
            max_change = xp.max(xp.abs(V_opt - old_V_opt))

            # Tracking the history
            iteration_time = (datetime.now() - start).total_seconds()
            solve_history.add(iteration_time=iteration_time,
                                value_function_change=max_change,
                                value_function=V)

            # Convergence check
            if max_change < max_allowed_change:
                if print_progress:
                    iterator.close()
                break

        return V, solve_history