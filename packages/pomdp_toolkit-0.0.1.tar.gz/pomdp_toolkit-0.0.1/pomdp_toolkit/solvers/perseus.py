from pomdp_toolkit import ValueFunction
from pomdp_toolkit import BeliefSet
from pomdp_toolkit.solvers.pbvi import PBVI

import numpy as np
gpu_support = False
try:
    import cupy as cp
    gpu_support = True
except:
    print('[Warning] Cupy could not be loaded: GPU support is not available.')


class Perseus(PBVI):
    '''
    A flavor of the PBVI algorithm.

    # TODO: Do document of Perseus agent
    # TODO: FIX Perseus expand
    '''
    @staticmethod
    def expand(belief_set: BeliefSet,
               value_function: ValueFunction,
               max_generation: int,
               use_gpu: bool = False,
               rng: int | np.random.Generator = 12131415
               ) -> BeliefSet:
        '''
        # TODO

        Parameters
        ----------
        belief_set : BeliefSet
            List of beliefs to expand on.
        value_function : ValueFunction
            The current value function. (NOT USED)
        max_generation : int, default=10
            The max amount of beliefs that can be added to the belief set at once.
        use_gpu : bool, default=False
            Whether to use the GPU with cupy array to accelerate solving.
        rng : int or np.random.Generator, default=12131415
            A seed for random generation or directly a numpy random generator.

        Returns
        -------
        belief_set : BeliefSet
            A new sequence of beliefs.
        '''
        # GPU support
        xp = np if not use_gpu else cp

        # Retrieve the POMDP from the value function
        pomdp = belief_set.pomdp

        b = belief_set.belief_list[0]
        belief_sequence = []

        for i in range(max_generation):
            # Choose random action
            a = int(rng.choice(pomdp.actions, size=1)[0])

            # Choose random observation based on prob: P(o|b,a)
            obs_prob = xp.einsum('sor,s->o', pomdp.reachable_transitional_observation_table[:,a,:,:], b.values)
            o = int(rng.choice(pomdp.observations, size=1, p=obs_prob)[0])

            # Update belief
            bao = b.update(a,o)

            # Finalization
            belief_sequence.append(bao)
            b = bao

        return BeliefSet(pomdp, belief_sequence)