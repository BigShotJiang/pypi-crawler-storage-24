from pomdp_toolkit import ValueFunction
from pomdp_toolkit import BeliefSet
from pomdp_toolkit.solvers.pbvi import PBVI

import numpy as np
gpu_support = False
try:
    import cupy as cp
    gpu_support = True
except:
    print('[Warning] Cupy could not be loaded: GPU support is not available.')


class PBVI_SSEA(PBVI):
    '''
    # TODO
    '''
    @staticmethod
    def expand(belief_set: BeliefSet,
               value_function: ValueFunction,
               max_generation: int,
               use_gpu: bool = False,
               rng: int | np.random.Generator = 12131415
               ) -> BeliefSet:
        '''
        Stochastic Simulation with Exploratory Action.
        Simulates running steps forward for each possible action knowing we are a state s, chosen randomly with according to the belief probability.
        These lead to a new state s_p and a observation o for each action.
        From all these and observation o we can generate updated beliefs.
        Then it takes the belief that is furthest away from other beliefs, meaning it explores the most the belief space.

        Note
        ----
        The function will not check whether the value_functions and belief_set provided are on the gpu or not and whether this is consistent with the use_gpu parameter.

        Parameters
        ----------
        belief_set : BeliefSet
            List of beliefs to expand on.
        value_function : ValueFunction
            The current value function. (NOT USED)
        max_generation : int, default=10
            The max amount of beliefs that can be added to the belief set at once.
        use_gpu : bool, default=False
            Whether to use the GPU with cupy array to accelerate solving.
        rng : int or np.random.Generator, default=12131415 (NOT USED)
            A seed for random generation or directly a numpy random generator.

        Returns
        -------
        belief_set_new : BeliefSet
            Union of the belief_set and the expansions of the beliefs in the belief_set.
        '''
        # GPU support
        xp = np if not use_gpu else cp

        # Retrieve the POMDP from the value function
        pomdp = belief_set.pomdp

        old_shape = belief_set.belief_array.shape
        to_generate = min(max_generation, old_shape[0])

        # Generation of successors
        successor_beliefs = xp.array([[[b.update(a,o).values for o in pomdp.observations] for a in pomdp.actions] for b in belief_set.belief_list])

        # Compute the distances between each pair and of successor are source beliefs
        diff = (belief_set.belief_array[:, None,None,None, :] - successor_beliefs)
        dist = xp.sqrt(xp.einsum('bnaos,bnaos->bnao', diff, diff))

        # Taking the min distance for each belief
        belief_min_dists = xp.min(dist,axis=0)

        # Taking the max distanced successors
        b_star, a_star, o_star = xp.unravel_index(xp.argsort(belief_min_dists, axis=None)[::-1][:to_generate], successor_beliefs.shape[:-1])

        # Selecting successor beliefs
        new_belief_array = successor_beliefs[b_star[:,None], a_star[:,None], o_star[:,None], pomdp.states[None,:]]

        return BeliefSet(pomdp, new_belief_array)