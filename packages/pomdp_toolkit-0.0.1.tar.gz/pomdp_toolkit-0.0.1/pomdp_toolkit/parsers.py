import re
import numpy as np

from pomdp import POMDP


class POMDPParser:
    '''
    
    '''
    def _read_preamble(lines):
        # Read the preamble until the first non-comment line
        preamble = {}

        while lines:
            line = lines.pop(0)  # Remove and get the first line
            line_parts = line.split(':')
            line_start = line_parts[0].strip()

            # Discount value
            if line_start == 'discount':
                preamble['discount'] = float(line_parts[1].strip())

            # Type of the values (reward or cost)
            elif line_start == 'values':
                values = line_parts[1].strip()
                assert values in ['reward', 'cost'], f"Invalid input for 'values': {values} (expected 'reward' or 'cost')"
                preamble['values'] = values

            # States
            elif line_start == 'states':
                states = line_parts[1].strip()

                # Count of states
                if states.isdigit():
                    state_count = int(states)
                    preamble['states'] = [f's_{i}' for i in range(state_count)]
                else:
                    # List of states
                    preamble['states'] = [s for s in states.split() if s]

            # Actions
            elif line_start == 'actions':
                actions = line_parts[1].strip()

                # Count of actions
                if actions.isdigit():
                    action_count = int(actions)
                    preamble['actions'] = [f'a_{i}' for i in range(action_count)]
                else:
                    # List of actions
                    preamble['actions'] = [a for a in actions.split() if a]

            # Observations
            elif line_start == 'observations':
                observations = line_parts[1].strip()

                # Count of observations
                if observations.isdigit():
                    observation_count = int(observations)
                    preamble['observations'] = [f'o_{i}' for i in range(observation_count)]
                else:
                    # List of observations
                    preamble['observations'] = [o for o in observations.split() if o]

            # Invalid line
            else:
                raise ValueError(f"Invalid line in preamble: {line} (has to start by 'discount', 'values', 'states', 'actions', or 'observations')")

            # Check if we have read all the required preamble information
            if len(preamble) == 5:
                break

        # Check that all states, actions, and observations are unique
        assert len(preamble['states']) == len(set(preamble['states'])), "States provided contain duplicates"
        assert len(preamble['actions']) == len(set(preamble['actions'])), "Actions provided contain duplicates"
        assert len(preamble['observations']) == len(set(preamble['observations'])), "Observations provided contain duplicates"

        # Check that states, actions, and observations are not contain reserved keywords
        reserved_keywords = ['discount', 'values', 'states', 'actions', 'observations', 'T', 'O', 'R', 'uniform', 'identity', 'reward', 'cost', 'start', 'include', 'exclude', 'reset', ':', '*']
        for keyword in reserved_keywords:
            assert keyword not in preamble['states'], f"State '{keyword}' is a reserved keyword"
            assert keyword not in preamble['actions'], f"Action '{keyword}' is a reserved keyword"
            assert keyword not in preamble['observations'], f"Observation '{keyword}' is a reserved keyword"

        return lines, preamble


    def _read_start(lines, state_labels):
        start_belief = None

        include = False
        exclude = False

        # Read the start line until the first non-comment line
        while lines:
            line = lines.pop(0)  # Remove and get the first line
            line_parts = line.split(':')

            # Check if it's the part before the colon
            if line_parts[0].startswith('start'):
                line_start = line_parts.pop(0).strip()

                # Check if the line starts with 'include' or 'exclude'
                if 'include' in line_start:
                    include = True
                elif 'exclude' in line_start:
                    exclude = True

            if len(line_parts[0]) > 0:
                line_second_part = line_parts.pop(0).strip()

                # Check if uniform
                if line_second_part == 'uniform':
                    start_belief = np.ones(len(state_labels)) / len(state_labels)
                    break

                # Split the line into parts
                split_line = [p for p in line_second_part.split() if p]

                # Check if list of probabilities
                if len(split_line) == len(state_labels):
                    try:
                        start_belief = np.array(split_line).astype(float)
                    except ValueError:
                        pass
                    break

                # Check if list (or unique) of indices or state labels
                else:
                    indices = None

                    # Numeric indices provided
                    if all([state.isdigit() for state in split_line]):
                        indices = [int(state) for state in split_line]

                    # State labels provided
                    elif all([state in state_labels for state in split_line]):
                        indices = [state_labels.index(state) for state in split_line]

                    # Invalid line
                    else:
                        raise ValueError(f"Invalid start belief line: {line} (has to be 'uniform', a list of probabilities, or a list of indices as intergers or state labels)")

                    # Check if 'include' or 'exclude' tag is used if there are multiple indices to be valid according to the grammar
                    if len(indices) > 1:
                        assert include or exclude, f"Multiple states provided but no 'include' or 'exclude' tag found in the start belief line."

                    # Populate the start belief based on the indices
                    if exclude:
                        start_belief = np.ones(len(state_labels))
                        start_belief[indices] = 0.0
                        start_belief /= np.sum(start_belief)
                    else: # 'include' or nothing
                        start_belief = np.zeros(len(state_labels))
                        start_belief[indices] = 1.0 / len(indices)

                    break

        # Making sure the value of the start belief is a valid probability distribution
        belief_rounded_sum = start_belief.sum().round(8)
        assert belief_rounded_sum == 1.0, f"Invalid start belief: {start_belief} (the sum of the probabilities has to be 1.0, found {belief_rounded_sum})"

        return lines, start_belief


    def _read_matrix_entry(lines, matrix, entry_names, entry_labels):
        parameters = {param_name: None for param_name in entry_names}
        values = None
        param_count = -1

        # Read lines until break
        while lines:
            line = lines.pop(0)  # Remove and get the first line

            # If contains colon, it's the first line of the definition so we need to extract the parameters
            colon_count = line.count(':')
            if colon_count > 0:
                param_count = colon_count
                colon_parts = [part.strip() for part in line.split(':')][1:] # From 1 because entry 0 is either T, O, or R

                for part, param_name in zip(colon_parts, entry_names[:len(colon_parts)]):
                    part_split = [p for p in part.split() if p]

                    # Extract values if present in the first line
                    if len(part_split) == 2:
                        values = float(part_split[1])
                    elif len(part_split) > 2:
                        values = [float(v) for v in part_split[1:]]

                    # Set the parameter value
                    parameters[param_name] = part_split[0]

                if param_count == len(entry_names) - 2:
                    # If the number of parameters is equal to the number of entries - 2, we can assume we will receive a matrix
                    # So we initialize the values as a list of lists
                    values = []

            # If it doesn't contain a colon, we can assume it's a continuation of the previous line
            else:
                # Special values
                if (line.strip() == 'identity') and (param_count == (len(entry_names) - 2)):
                    assert ('state' in entry_names[-2]) and ('state' in entry_names[-1]), "'identity' keyword can only be used for state transitions."
                    values = np.eye(len(entry_labels[-2])) # state labels
                    break

                elif line.strip() == 'uniform':
                    uniform_values = np.ones(len(entry_labels[-1])) / len(entry_labels[-1])
                    if (param_count == (len(entry_names) - 2)):
                        values = [uniform_values for _ in range(len(entry_labels[-2]))]
                    else:
                        values = uniform_values
                    break

                # Numerical values
                try:
                    line_split = [float(v) for v in line.split() if v]
                except:
                    raise ValueError(f"Invalid line: {line} (has to be a list of numbers)")

                if param_count == len(entry_names):
                    # If the number of parameters is equal to the number of entries, we can assume it's a single value
                    values = line_split[0]
                elif values is None:
                    # If the values are not set yet, we can assume it's a single list of values
                    values = line_split
                else:
                    # Otherwise, we can assume it's a list of lists
                    values.append(line_split)

            # Break condition
            if values is not None:
                if (param_count == len(entry_names)) and isinstance(values, float):
                    # If the number of parameters is equal to the number of entries AND value is float, we can break
                    break
                elif (param_count == len(entry_names) - 1) and isinstance(values, list) and all([isinstance(v, float) for v in values]):
                    # If the number of parameters is equal to the number of entries - 1 AND all entries are float, we can break
                    break
                elif (param_count == len(entry_names) - 2) and isinstance(values, list) and all([isinstance(v, list) for v in values]) and (len(values) == len(entry_labels[-2])):
                    # If the number of parameters is equal to the number of entries - 2 AND all entries are sub-lists AND we have the correct amount of sublists, we can break
                    break

        # Process the parameters
        for param_name, labels in zip(entry_names, entry_labels):
            param = parameters[param_name]

            if param is not None:
                if param.isdigit():
                    param = int(param)
                elif param == '*':
                    param = None
                elif param in labels:
                    param = labels.index(param)
                else:
                    raise ValueError(f"Invalid {param_name}: {param} (has to be an integer, '*' or a valid label)")

            parameters[param_name] = param

        # Making sure the shape of the probabilities matches what the parameters expect
        values = np.array(values)
        n_none = sum([param is None for param in parameters.values()])

        # Reshape probabilities if the number of dimensions is less than the number of None parameters (ie "free parameters")
        if values.ndim > 0:
            dim_diff = n_none - values.ndim
            values = values[*([None] * dim_diff), :]

        # Setting the values in the matrix
        matrix[*[slice(None) if param is None else param for param in parameters.values()]] = values

        return lines, matrix


    @classmethod
    def parse(cls, file):
        '''
        WRITE THIS
        '''
        # Read the file
        with open(file, 'r') as f:
            raw_lines = f.readlines()

        # Processing the raw lines by removing comments and aggregating lines of the preamble
        lines = []
        for line in raw_lines:
            line = line.split('#')[0].strip()  # Remove comments

            # Aggregate lines part of the preamble
            if lines and (lines[-1].split(':')[0].split()[0] in ['values', 'states', 'actions', 'observations', 'start']) and (line.count(':') == 0):
                lines[-1] += ' ' + line

            # Else, if not empty, add the clean line the list
            elif line:
                lines.append(line)

        # Read the preamble
        lines, preamble = cls._read_preamble(lines)

        state_count = len(preamble['states'])
        action_count = len(preamble['actions'])
        observation_count = len(preamble['observations'])

        # Building objects based on the preamble
        start_belief = np.zeros(state_count)  # Initialize start belief vector
        transitions = np.zeros((action_count, state_count, state_count))  # Initialize transition matrix
        observations = np.zeros((action_count, state_count, observation_count))  # Initialize observation matrix
        rewards = np.zeros((action_count, state_count, state_count, observation_count))  # Initialize rewards matrix

        # Loop over the lines:
        while lines:
            # Read start_belief line or lines
            if lines[0].startswith('start'):
                if start_belief.sum() == 0:
                    lines, start_belief = cls._read_start(lines, preamble['states'])
                else:
                    raise ValueError("Multiple start beliefs found in the POMDP file.")

            # Read transition line or lines
            elif lines[0].startswith('T'):
                entry_names = ['action', 'prior_state', 'posterior_state']
                entry_labels = [preamble['actions'], preamble['states'], preamble['states']]
                lines, transitions = cls._read_matrix_entry(lines, transitions, entry_names, entry_labels)

            # Read observation line or lines
            elif lines[0].startswith('O'):
                entry_names = ['action', 'posterior_state', 'observation']
                entry_labels = [preamble['actions'], preamble['states'], preamble['observations']]
                lines, observations = cls._read_matrix_entry(lines, observations, entry_names, entry_labels)

            # Read reward line or lines
            elif lines[0].startswith('R'):
                entry_names = ['action', 'prior_state', 'posterior_state', 'observation']
                entry_labels = [preamble['actions'], preamble['states'], preamble['states'], preamble['observations']]
                lines, rewards = cls._read_matrix_entry(lines, rewards, entry_names, entry_labels)

            # Default state
            else:
                raise ValueError(f"Invalid line in POMDP file: {lines[0]} (has to start by 'start', 'T', 'O', or 'R')")

        # Make the initial belief uniform if not provided
        if start_belief.sum() == 0:
            start_belief = np.ones(state_count) / state_count  # Uniform distribution

        # Re-ordering the matrices to match what the POMDP class expects
        transitions = np.transpose(transitions, (1, 0, 2))  # S, A, S'
        observations = np.transpose(observations, (1, 0, 2))  # S', A, O
        rewards = np.transpose(rewards, (1, 0, 2, 3))  # S, A, S', O

        # Instantiate the POMDP object
        pomdp = POMDP(
            states = preamble['states'],
            actions = preamble['actions'],
            observations = preamble['observations'],
            transitions = transitions,
            observation_table = observations,
            rewards = rewards,
            start_probabilities = start_belief,
        )
        return pomdp


if __name__ == "__main__":
    pomdp = POMDPParser.parse("../pomdp-toolkit/tests/pomdp_example_problems/tiger.95.POMDP")
    print(pomdp.action_labels)