# Copyright (C) 2024 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Data version module."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class DataVersion:
    """Edits or creates a SysML element."""

    payload: dict = field(default_factory=dict)
    identity: str = field(default=None)

    def identify(self, element_id: str):
        """Set the identity with the given element ID of the data version."""
        self.identity = element_id

    def add_change(self, key: str, value: Any):
        """
        Add the change into the data version. Also serialize the data if it's needed.

        Parameters
        ----------
        key: str
            Key of the change.
        value: Any
            Value of the change.
        """
        from ansys.sam.sysml2.classes.sysml_element import SysMLElement
        from ansys.sam.sysml2.data_structures.observed_list import ObservedList
        from ansys.sam.sysml2.meta_model.element import Element
        from ansys.sam.sysml2.tools.name_utils import NameUtils

        if "_" in key:
            key = NameUtils.snake_to_camel(key)
        if isinstance(value, SysMLElement):
            self.payload[key] = {"@id": value._id}
        elif isinstance(value, Element):
            self.payload[key] = {"@id": value.id}
        elif isinstance(value, (ObservedList, list)):
            self.payload[key] = [
                (
                    {"@id": x._id}
                    if isinstance(x, SysMLElement)
                    else {"@id": x.id}
                    if isinstance(x, Element)
                    else x
                )
                for x in value
            ]
        else:
            self.payload[key] = value

    def to_json(self) -> dict:
        """Serialize the data into a JSON dict."""
        data = {
            "@type": "DataVersion",
        }
        if self.payload != {}:
            data["payload"] = self.payload
        if self.identity is not None:
            data["identity"] = {"@id": self.identity, "@type": "DataIdentity"}
        return data
