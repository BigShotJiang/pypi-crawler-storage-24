# Copyright (C) 2024 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
"""Python base class for SysML elements."""

from typing import Union

from ansys.sam.sysml2.classes.value_helper import ValueHelper
from ansys.sam.sysml2.observer.observer import ModificationObserver


class SysMLElement:
    """Provides the Python base class for all SysML elements."""

    _id: str
    _observer: ModificationObserver = None

    def __init__(self, id: str) -> None:
        """Construct a new SysML element instance with its ID specified."""
        self._id = id

    def __setattr__(self, name: str, value: object):
        """
        Blocker function the set function of each classes.

        Parameters
        ----------
        name : str
            Name of the key.
        value : object
            Value of the key.
        """
        if name != "_observer" and getattr(self, "_observer", None) is not None:
            self._observer.notify(self._id, name, value)
        super().__setattr__(name, value)

    def get_value(self):
        """Get the value of the feature."""
        return ValueHelper.get_value_for_scripting_element(self)

    def parse_and_set_value(self, value: str):
        """Parse the value and create the valuation part in the feature."""
        ValueHelper.set_or_update_value(self, "operator", value)

    def set_value(self, new_value: Union[str | int | float | bool]):
        """Update the feature value."""
        ValueHelper.set_or_update_value(self, type(new_value), new_value)

    def delete(self):
        """Delete the element from the model."""
        if self._observer is not None:
            self._observer.delete_element(self._id)
        del self
