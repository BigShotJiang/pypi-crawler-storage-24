use std::collections::HashMap;
use std::fs::File;
use std::io::{BufReader, Cursor, Read};
use std::path::PathBuf;

use calamine::{
    open_workbook_auto, open_workbook_auto_from_rs, Error as CalamineCrateError, Reader, Sheets,
    BorderStyle, FillPattern, FontWeight, FontStyle, StyleRange, UnderlineStyle, WorksheetLayout,
};
use chrono::Datelike;
use pyo3::exceptions::PyTypeError;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList, PyType};
use pyo3_file::PyFileLikeObject;

use crate::{CalamineSheet, CalamineTable, Error, SheetMetadata, WorksheetNotFound};
use crate::types::grid::{CellGrid, CellStyle, RawValue};

enum SheetsEnum {
    File(Sheets<BufReader<File>>),
    FileLike(Sheets<Cursor<Vec<u8>>>),
    None,
}

enum WorkbookType {
    Xls,
    Xlsx,
    Xlsb,
    Ods,
}

impl From<&SheetsEnum> for WorkbookType {
    fn from(sheets: &SheetsEnum) -> Self {
        match sheets {
            SheetsEnum::File(f) => match f {
                Sheets::Xls(_) => WorkbookType::Xls,
                Sheets::Xlsx(_) => WorkbookType::Xlsx,
                Sheets::Xlsb(_) => WorkbookType::Xlsb,
                Sheets::Ods(_) => WorkbookType::Ods,
            },
            SheetsEnum::FileLike(f) => match f {
                Sheets::Xls(_) => WorkbookType::Xls,
                Sheets::Xlsx(_) => WorkbookType::Xlsx,
                Sheets::Xlsb(_) => WorkbookType::Xlsb,
                Sheets::Ods(_) => WorkbookType::Ods,
            },
            SheetsEnum::None => unreachable!(),
        }
    }
}

impl SheetsEnum {
    fn sheets_metadata(&self) -> Vec<SheetMetadata> {
        match self {
            SheetsEnum::File(f) => f.sheets_metadata(),
            SheetsEnum::FileLike(f) => f.sheets_metadata(),
            SheetsEnum::None => unreachable!(),
        }
        .iter()
        .map(|s| SheetMetadata::new(s.name.clone(), s.typ, s.visible))
        .collect()
    }

    fn sheet_names(&self) -> Vec<String> {
        match self {
            SheetsEnum::File(f) => f.sheet_names(),
            SheetsEnum::FileLike(f) => f.sheet_names(),
            SheetsEnum::None => unreachable!(),
        }
    }

    fn worksheet_range(&mut self, name: &str) -> Result<calamine::Range<calamine::Data>, Error> {
        match self {
            SheetsEnum::File(f) => f.worksheet_range(name).map_err(Error::Calamine),
            SheetsEnum::FileLike(f) => f.worksheet_range(name).map_err(Error::Calamine),
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
    }

    fn worksheet_formula(
        &mut self,
        name: &str,
    ) -> Result<calamine::Range<String>, Error> {
        match self {
            SheetsEnum::File(f) => f.worksheet_formula(name).map_err(Error::Calamine),
            SheetsEnum::FileLike(f) => f.worksheet_formula(name).map_err(Error::Calamine),
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
    }

    fn worksheet_images(
        &mut self,
        name: &str,
    ) -> Result<Vec<calamine::WorksheetImage>, Error> {
        match self {
            SheetsEnum::File(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .worksheet_images(name)
                    .map_err(calamine::Error::Xlsx)
                    .map_err(Error::Calamine),
                _ => Ok(Vec::new()), // Only XLSX supports images
            },
            SheetsEnum::FileLike(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .worksheet_images(name)
                    .map_err(calamine::Error::Xlsx)
                    .map_err(Error::Calamine),
                _ => Ok(Vec::new()),
            },
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
    }

    fn worksheet_data_validations(
        &mut self,
        name: &str,
    ) -> Result<Vec<calamine::DataValidation>, Error> {
        match self {
            SheetsEnum::File(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .worksheet_data_validations(name)
                    .map_err(calamine::Error::Xlsx)
                    .map_err(Error::Calamine),
                _ => Ok(Vec::new()),
            },
            SheetsEnum::FileLike(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .worksheet_data_validations(name)
                    .map_err(calamine::Error::Xlsx)
                    .map_err(Error::Calamine),
                _ => Ok(Vec::new()),
            },
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
    }

    fn worksheet_freeze_panes(
        &mut self,
        name: &str,
    ) -> Result<calamine::FreezePanes, Error> {
        match self {
            SheetsEnum::File(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .worksheet_freeze_panes(name)
                    .map_err(calamine::Error::Xlsx)
                    .map_err(Error::Calamine),
                _ => Ok(calamine::FreezePanes::default()),
            },
            SheetsEnum::FileLike(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .worksheet_freeze_panes(name)
                    .map_err(calamine::Error::Xlsx)
                    .map_err(Error::Calamine),
                _ => Ok(calamine::FreezePanes::default()),
            },
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
    }

    fn worksheet_merge_cells(
        &mut self,
        name: &str,
    ) -> Result<Option<Vec<calamine::Dimensions>>, Error> {
        match self {
            SheetsEnum::File(f) => match f {
                Sheets::Xls(xls_f) => Ok(xls_f.worksheet_merge_cells(name)),
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .worksheet_merge_cells(name)
                    .transpose()
                    .map_err(CalamineCrateError::Xlsx)
                    .map_err(Error::Calamine)
                    .map(|inner| inner.or(Some(Vec::new()))),
                _ => Ok(None),
            },
            SheetsEnum::FileLike(f) => match f {
                Sheets::Xls(xls_f) => Ok(xls_f.worksheet_merge_cells(name)),
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .worksheet_merge_cells(name)
                    .transpose()
                    .map_err(CalamineCrateError::Xlsx)
                    .map_err(Error::Calamine)
                    .map(|inner| inner.or(Some(Vec::new()))),
                _ => Ok(None),
            },
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
    }

    fn worksheet_style(
        &mut self,
        name: &str,
    ) -> Result<StyleRange, Error> {
        match self {
            SheetsEnum::File(f) => f.worksheet_style(name).map_err(Error::Calamine),
            SheetsEnum::FileLike(f) => f.worksheet_style(name).map_err(Error::Calamine),
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
    }

    fn worksheet_layout(
        &mut self,
        name: &str,
    ) -> Result<WorksheetLayout, Error> {
        match self {
            SheetsEnum::File(f) => f.worksheet_layout(name).map_err(Error::Calamine),
            SheetsEnum::FileLike(f) => f.worksheet_layout(name).map_err(Error::Calamine),
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
    }

    fn load_tables(&mut self) -> Result<(), Error> {
        match self {
            SheetsEnum::File(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .load_tables()
                    .map_err(CalamineCrateError::Xlsx)
                    .map_err(Error::Calamine),
                _ => Err(Error::TablesNotSupported),
            },
            SheetsEnum::FileLike(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .load_tables()
                    .map_err(CalamineCrateError::Xlsx)
                    .map_err(Error::Calamine),
                _ => Err(Error::TablesNotSupported),
            },
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
    }

    fn table_names(&self) -> Result<Vec<String>, Error> {
        match self {
            SheetsEnum::File(f) => match f {
                Sheets::Xlsx(xlsx_f) => Ok(xlsx_f.table_names()),
                _ => Err(Error::TablesNotSupported),
            },
            SheetsEnum::FileLike(f) => match f {
                Sheets::Xlsx(xlsx_f) => Ok(xlsx_f.table_names()),
                _ => Err(Error::TablesNotSupported),
            },
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
        .map(|v| {
            v.iter()
                .map(|s| s.to_owned().to_owned())
                .collect::<Vec<String>>()
        })
    }

    fn all_tables_metadata(&self) -> Result<Vec<calamine::TableInfo>, Error> {
        match self {
            SheetsEnum::File(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .all_tables_metadata()
                    .map_err(calamine::Error::Xlsx)
                    .map_err(Error::Calamine),
                _ => Ok(Vec::new()),
            },
            SheetsEnum::FileLike(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .all_tables_metadata()
                    .map_err(calamine::Error::Xlsx)
                    .map_err(Error::Calamine),
                _ => Ok(Vec::new()),
            },
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
    }

    fn get_table_by_name(&mut self, name: &str) -> Result<CalamineTable, Error> {
        match self {
            SheetsEnum::File(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .table_by_name(name)
                    .map_err(CalamineCrateError::Xlsx)
                    .map_err(Error::Calamine)
                    .map(|t| {
                        CalamineTable::new(
                            t.name().to_owned(),
                            t.sheet_name().to_owned(),
                            t.columns().iter().map(|s| s.to_owned()).collect(),
                            t.data().to_owned(),
                        )
                    }),
                _ => Err(Error::TablesNotSupported),
            },
            SheetsEnum::FileLike(f) => match f {
                Sheets::Xlsx(xlsx_f) => xlsx_f
                    .table_by_name(name)
                    .map_err(CalamineCrateError::Xlsx)
                    .map_err(Error::Calamine)
                    .map(|t| {
                        CalamineTable::new(
                            t.name().to_owned(),
                            t.sheet_name().to_owned(),
                            t.columns().iter().map(|s| s.to_owned()).collect(),
                            t.data().to_owned(),
                        )
                    }),
                _ => Err(Error::TablesNotSupported),
            },
            SheetsEnum::None => Err(Error::WorkbookClosed),
        }
    }
}

#[pyclass]
pub struct CalamineWorkbook {
    #[pyo3(get)]
    path: Option<String>,
    workbook_type: WorkbookType,
    sheets: SheetsEnum,
    #[pyo3(get)]
    sheets_metadata: Vec<SheetMetadata>,
    #[pyo3(get)]
    sheet_names: Vec<String>,
    table_names: Option<Vec<String>>,
}

#[pymethods]
impl CalamineWorkbook {
    fn __repr__(&self) -> PyResult<String> {
        match &self.path {
            Some(path) => Ok(format!("CalamineWorkbook(path='{path}')")),
            None => Ok("CalamineWorkbook(path='bytes')".to_string()),
        }
    }

    #[classmethod]
    #[pyo3(name = "from_object", signature = (path_or_filelike, load_tables=false))]
    fn py_from_object(
        _cls: &Bound<'_, PyType>,
        py: Python<'_>,
        path_or_filelike: Py<PyAny>,
        load_tables: bool,
    ) -> PyResult<Self> {
        Self::from_object(py, path_or_filelike, load_tables)
    }

    #[classmethod]
    #[pyo3(name = "from_filelike", signature = (filelike, load_tables=false))]
    fn py_from_filelike(
        _cls: &Bound<'_, PyType>,
        py: Python<'_>,
        filelike: Py<PyAny>,
        load_tables: bool,
    ) -> PyResult<Self> {
        py.detach(|| Self::from_filelike(filelike, load_tables))
    }

    #[classmethod]
    #[pyo3(name = "from_path", signature = (path, load_tables=false))]
    fn py_from_path(
        _cls: &Bound<'_, PyType>,
        py: Python<'_>,
        path: Py<PyAny>,
        load_tables: bool,
    ) -> PyResult<Self> {
        if let Ok(string_ref) = path.extract::<PathBuf>(py) {
            let path = string_ref.to_string_lossy().to_string();
            return py.detach(|| Self::from_path(&path, load_tables));
        }

        Err(PyTypeError::new_err(""))
    }

    #[pyo3(name = "get_sheet_by_name")]
    fn py_get_sheet_by_name(&mut self, py: Python<'_>, name: &str) -> PyResult<CalamineSheet> {
        py.detach(|| self.get_sheet_by_name(name))
    }

    #[pyo3(name = "get_sheet_by_index")]
    fn py_get_sheet_by_index(&mut self, py: Python<'_>, index: usize) -> PyResult<CalamineSheet> {
        py.detach(|| self.get_sheet_by_index(index))
    }

    #[getter]
    fn table_names(&self) -> PyResult<Vec<String>> {
        match &self.workbook_type {
            WorkbookType::Xlsx => match &self.table_names {
                Some(v) => Ok(v.clone()),
                None => Err(Error::TablesNotLoaded.into()),
            },
            _ => Err(Error::TablesNotSupported.into()),
        }
    }

    #[pyo3(name = "get_table_by_name")]
    fn py_get_table_by_name(&mut self, py: Python<'_>, name: &str) -> PyResult<CalamineTable> {
        py.detach(|| self.get_table_by_name(name))
    }

    /// Get metadata for all tables without parsing sheet data.
    /// Returns list of dicts with: name, sheet, columns, start, end.
    #[pyo3(name = "get_all_tables_metadata")]
    fn py_get_all_tables_metadata(&self, py: Python<'_>) -> PyResult<Vec<Py<PyAny>>> {
        match &self.workbook_type {
            WorkbookType::Xlsx => {
                if self.table_names.is_none() {
                    return Err(Error::TablesNotLoaded.into());
                }
            }
            _ => return Err(Error::TablesNotSupported.into()),
        }
        let infos = self.sheets.all_tables_metadata()?;
        infos
            .into_iter()
            .map(|info| {
                let dict = pyo3::types::PyDict::new(py);
                dict.set_item("name", &info.name)?;
                dict.set_item("sheet", &info.sheet_name)?;
                dict.set_item("columns", &info.columns)?;
                dict.set_item("start", (info.dimensions.start.0, info.dimensions.start.1))?;
                dict.set_item("end", (info.dimensions.end.0, info.dimensions.end.1))?;
                Ok(dict.into_any().unbind())
            })
            .collect()
    }

    /// Get styles for all cells in a sheet as list of (row, col, style_dict).
    /// style_dict contains: font_bold, font_size, font_color, fill_fg_color,
    /// border_top, border_bottom, border_left, border_right, number_format, etc.
    #[pyo3(name = "get_sheet_styles")]
    fn py_get_sheet_styles<'py>(
        &mut self,
        py: Python<'py>,
        name: &str,
    ) -> PyResult<Bound<'py, PyList>> {
        let style_range = self.sheets.worksheet_style(name)?;
        let results = PyList::empty(py);

        for (row, col, style) in style_range.cells() {
            let dict = PyDict::new(py);

            // Font
            if let Some(font) = style.get_font() {
                dict.set_item("font_bold", font.weight == FontWeight::Bold)?;
                dict.set_item("font_italic", font.style == FontStyle::Italic)?;
                dict.set_item("font_size", font.size)?;
                dict.set_item("font_name", font.name.as_deref())?;
                dict.set_item("font_underline", match font.underline {
                    UnderlineStyle::None => "none",
                    UnderlineStyle::Single => "single",
                    UnderlineStyle::Double => "double",
                    UnderlineStyle::SingleAccounting => "singleAccounting",
                    UnderlineStyle::DoubleAccounting => "doubleAccounting",
                })?;
                dict.set_item("font_strikethrough", font.strikethrough)?;
                if let Some(color) = &font.color {
                    dict.set_item(
                        "font_color",
                        format!("#{:02X}{:02X}{:02X}", color.red, color.green, color.blue),
                    )?;
                } else {
                    dict.set_item("font_color", py.None())?;
                }
            }

            // Fill
            if let Some(fill) = style.get_fill() {
                dict.set_item("fill_pattern", match fill.pattern {
                    FillPattern::None => "none",
                    FillPattern::Solid => "solid",
                    _ => "pattern",
                })?;
                if let Some(color) = &fill.foreground_color {
                    dict.set_item(
                        "fill_fg_color",
                        format!("#{:02X}{:02X}{:02X}", color.red, color.green, color.blue),
                    )?;
                } else {
                    dict.set_item("fill_fg_color", py.None())?;
                }
                if let Some(color) = &fill.background_color {
                    dict.set_item(
                        "fill_bg_color",
                        format!("#{:02X}{:02X}{:02X}", color.red, color.green, color.blue),
                    )?;
                } else {
                    dict.set_item("fill_bg_color", py.None())?;
                }
            }

            // Borders
            if let Some(borders) = style.get_borders() {
                let border_style_str = |bs: &BorderStyle| -> &str {
                    match bs {
                        BorderStyle::None => "none",
                        BorderStyle::Thin => "thin",
                        BorderStyle::Medium => "medium",
                        BorderStyle::Thick => "thick",
                        BorderStyle::Double => "double",
                        BorderStyle::Hair => "hair",
                        BorderStyle::Dashed => "dashed",
                        BorderStyle::Dotted => "dotted",
                        BorderStyle::MediumDashed => "mediumDashed",
                        BorderStyle::DashDot => "dashDot",
                        BorderStyle::DashDotDot => "dashDotDot",
                        BorderStyle::SlantDashDot => "slantDashDot",
                    }
                };
                dict.set_item("border_top", border_style_str(&borders.top.style))?;
                dict.set_item("border_bottom", border_style_str(&borders.bottom.style))?;
                dict.set_item("border_left", border_style_str(&borders.left.style))?;
                dict.set_item("border_right", border_style_str(&borders.right.style))?;
            }

            // Number format
            if let Some(nf) = style.get_number_format() {
                dict.set_item("number_format", &nf.format_code)?;
            }

            results.append((row, col, dict))?;
        }

        Ok(results)
    }

    /// Get worksheet layout (row heights, column widths) as a dict.
    #[pyo3(name = "get_sheet_layout")]
    fn py_get_sheet_layout<'py>(
        &mut self,
        py: Python<'py>,
        name: &str,
    ) -> PyResult<Bound<'py, PyDict>> {
        let layout = self.sheets.worksheet_layout(name)?;
        let result = PyDict::new(py);

        // Column widths: list of (col_idx, width, hidden)
        let col_widths = PyList::empty(py);
        for (idx, cw) in &layout.column_widths {
            col_widths.append((*idx, cw.width, cw.hidden))?;
        }
        result.set_item("column_widths", col_widths)?;

        // Row heights: list of (row_idx, height, hidden)
        let row_heights = PyList::empty(py);
        for (idx, rh) in &layout.row_heights {
            row_heights.append((*idx, rh.height, rh.hidden))?;
        }
        result.set_item("row_heights", row_heights)?;

        result.set_item("default_column_width", layout.default_column_width)?;
        result.set_item("default_row_height", layout.default_row_height)?;

        Ok(result)
    }

    /// Build a CellGrid for a sheet entirely in Rust.
    /// This replaces get_sheet_styles() + Python populate loop.
    #[pyo3(name = "get_sheet_grid")]
    #[pyo3(signature = (name, max_filled_row, max_filled_col, include_styles=true))]
    fn py_get_sheet_grid(
        &mut self,
        py: Python<'_>,
        name: &str,
        max_filled_row: usize,
        max_filled_col: usize,
        include_styles: bool,
    ) -> PyResult<CellGrid> {
        py.detach(|| self.get_sheet_grid(name, max_filled_row, max_filled_col, include_styles))
    }

    /// Get formulas for a sheet as list of (row, col, formula_string).
    /// Only returns cells that contain formulas (prefixed with '=').
    #[pyo3(name = "get_sheet_formulas")]
    fn py_get_sheet_formulas(
        &mut self,
        py: Python<'_>,
        name: &str,
    ) -> PyResult<Vec<(usize, usize, String)>> {
        py.detach(|| self.get_sheet_formulas(name))
    }

    /// Get images for a sheet as list of (bytes, extension, anchor_row, anchor_col).
    #[pyo3(name = "get_sheet_images")]
    fn py_get_sheet_images<'py>(
        &mut self,
        py: Python<'py>,
        name: &str,
    ) -> PyResult<Vec<(Py<pyo3::types::PyBytes>, String, u32, u32)>> {
        let images = py.detach(|| -> PyResult<Vec<calamine::WorksheetImage>> {
            Ok(self.sheets.worksheet_images(name)?)
        })?;
        images
            .into_iter()
            .map(|img| {
                let bytes = pyo3::types::PyBytes::new(py, &img.data);
                Ok((bytes.into(), img.extension, img.anchor_row, img.anchor_col))
            })
            .collect()
    }

    /// Get data validations for a sheet as list of dicts.
    /// Each dict has: type, sqref, formula1, formula2, allow_blank.
    #[pyo3(name = "get_sheet_data_validations")]
    fn py_get_sheet_data_validations(
        &mut self,
        py: Python<'_>,
        name: &str,
    ) -> PyResult<Vec<Py<PyAny>>> {
        let validations = py.detach(|| -> PyResult<Vec<calamine::DataValidation>> {
            Ok(self.sheets.worksheet_data_validations(name)?)
        })?;
        validations
            .into_iter()
            .map(|dv| {
                let dict = pyo3::types::PyDict::new(py);
                dict.set_item("type", &dv.validation_type)?;
                dict.set_item("sqref", &dv.sqref)?;
                dict.set_item("formula1", dv.formula1.as_deref())?;
                dict.set_item("formula2", dv.formula2.as_deref())?;
                dict.set_item("allow_blank", dv.allow_blank)?;
                Ok(dict.into_any().unbind())
            })
            .collect()
    }

    /// Get freeze pane info for a sheet as (frozen_rows, frozen_cols).
    #[pyo3(name = "get_sheet_freeze_panes")]
    fn py_get_sheet_freeze_panes(
        &mut self,
        py: Python<'_>,
        name: &str,
    ) -> PyResult<(u32, u32)> {
        let fp = py.detach(|| -> PyResult<calamine::FreezePanes> {
            Ok(self.sheets.worksheet_freeze_panes(name)?)
        })?;
        Ok((fp.frozen_rows, fp.frozen_cols))
    }

    /// Compute filled bounds for a sheet entirely in Rust.
    #[pyo3(name = "get_sheet_bounds")]
    fn py_get_sheet_bounds(
        &mut self,
        py: Python<'_>,
        name: &str,
    ) -> PyResult<(usize, usize)> {
        py.detach(|| self.get_sheet_bounds(name))
    }

    fn close(&mut self) -> PyResult<()> {
        match self.sheets {
            SheetsEnum::None => Err(Error::WorkbookClosed.into()),
            _ => {
                self.sheets = SheetsEnum::None;
                Ok(())
            }
        }
    }

    fn __enter__(slf: Py<Self>) -> Py<Self> {
        slf
    }

    fn __exit__(
        &mut self,
        _exc_type: Py<PyAny>,
        _exc_value: Py<PyAny>,
        _traceback: Py<PyAny>,
    ) -> PyResult<()> {
        self.close()
    }
}

impl CalamineWorkbook {
    pub fn from_object(
        py: Python<'_>,
        path_or_filelike: Py<PyAny>,
        load_tables: bool,
    ) -> PyResult<Self> {
        if let Ok(string_ref) = path_or_filelike.extract::<PathBuf>(py) {
            let path = string_ref.to_string_lossy().to_string();
            return py.detach(|| Self::from_path(&path, load_tables));
        }

        py.detach(|| Self::from_filelike(path_or_filelike, load_tables))
    }

    pub fn from_filelike(filelike: Py<PyAny>, load_tables: bool) -> PyResult<Self> {
        let mut buf = vec![];
        PyFileLikeObject::with_requirements(filelike, true, false, true, false)?
            .read_to_end(&mut buf)?;
        let reader = Cursor::new(buf);
        let mut sheets =
            SheetsEnum::FileLike(open_workbook_auto_from_rs(reader).map_err(Error::Calamine)?);
        let sheet_names = sheets.sheet_names().to_owned();
        let sheets_metadata = sheets.sheets_metadata().to_owned();

        let mut table_names: Option<Vec<String>> = None;
        if load_tables {
            sheets.load_tables()?;
            table_names = Some(sheets.table_names()?);
        }

        Ok(Self {
            path: None,
            workbook_type: WorkbookType::from(&sheets),
            sheets,
            sheets_metadata,
            sheet_names,
            table_names,
        })
    }

    pub fn from_path(path: &str, load_tables: bool) -> PyResult<Self> {
        let mut sheets = SheetsEnum::File(open_workbook_auto(path).map_err(Error::Calamine)?);
        let sheet_names = sheets.sheet_names().to_owned();
        let sheets_metadata = sheets.sheets_metadata().to_owned();

        let mut table_names: Option<Vec<String>> = None;
        if load_tables {
            sheets.load_tables()?;
            table_names = Some(sheets.table_names()?);
        }
        Ok(Self {
            path: Some(path.to_string()),
            workbook_type: WorkbookType::from(&sheets),
            sheets,
            sheets_metadata,
            sheet_names,
            table_names,
        })
    }

    fn get_sheet_by_name(&mut self, name: &str) -> PyResult<CalamineSheet> {
        let range = self.sheets.worksheet_range(name)?;
        let merge_cells_range = self.sheets.worksheet_merge_cells(name)?;
        Ok(CalamineSheet::new(
            name.to_owned(),
            range,
            merge_cells_range,
        ))
    }

    fn get_sheet_by_index(&mut self, index: usize) -> PyResult<CalamineSheet> {
        let name = self
            .sheet_names
            .get(index)
            .ok_or_else(|| WorksheetNotFound::new_err(format!("Worksheet '{index}' not found")))?
            .to_string();
        self.get_sheet_by_name(&name)
    }

    fn get_table_by_name(&mut self, name: &str) -> PyResult<CalamineTable> {
        match &self.workbook_type {
            WorkbookType::Xlsx => match &self.table_names {
                Some(_) => Ok(self.sheets.get_table_by_name(name)?),
                None => Err(Error::TablesNotLoaded.into()),
            },
            _ => Err(Error::TablesNotSupported.into()),
        }
    }

    /// Get formulas as (row, col, formula_string) triples.
    fn get_sheet_formulas(&mut self, name: &str) -> PyResult<Vec<(usize, usize, String)>> {
        let range = self.sheets.worksheet_formula(name)?;
        let range_start = range.start().unwrap_or((0, 0));
        let row_start = range_start.0 as usize;
        let col_start = range_start.1 as usize;

        let mut results = Vec::new();
        for (rel_row_idx, row_data) in range.rows().enumerate() {
            let abs_row = rel_row_idx + row_start;
            for (rel_col_idx, cell) in row_data.iter().enumerate() {
                if !cell.is_empty() {
                    let abs_col = rel_col_idx + col_start;
                    // Calamine formula strings don't include the leading '=',
                    // but the downstream consumer expects it.
                    let formula = if cell.starts_with('=') {
                        cell.clone()
                    } else {
                        format!("={cell}")
                    };
                    results.push((abs_row, abs_col, formula));
                }
            }
        }
        Ok(results)
    }

    /// Compute (max_filled_row, max_filled_col) entirely in Rust.
    /// Returns the 1-based exclusive bounds of the last non-empty cell.
    fn get_sheet_bounds(&mut self, name: &str) -> PyResult<(usize, usize)> {
        use calamine::DataType;
        let range = self.sheets.worksheet_range(name)?;
        let range_start = range.start().unwrap_or((0, 0));
        let row_start = range_start.0 as usize;
        let col_start = range_start.1 as usize;

        let mut max_filled_row: usize = 0;
        let mut max_filled_col: usize = 0;

        for (rel_row_idx, row_data) in range.rows().enumerate() {
            let abs_row = rel_row_idx + row_start;
            for (rel_col_idx, cell) in row_data.iter().enumerate() {
                if !cell.is_empty() {
                    let abs_col = rel_col_idx + col_start;
                    if abs_row + 1 > max_filled_row {
                        max_filled_row = abs_row + 1;
                    }
                    if abs_col + 1 > max_filled_col {
                        max_filled_col = abs_col + 1;
                    }
                }
            }
        }

        Ok((max_filled_row, max_filled_col))
    }

    /// Build CellGrid, optionally computing bounds from data.
    /// If max_filled_row/max_filled_col are 0, auto-compute from the data
    /// in a single pass (no separate bounds scan needed).
    fn get_sheet_grid(
        &mut self,
        name: &str,
        max_filled_row: usize,
        max_filled_col: usize,
        include_styles: bool,
    ) -> PyResult<CellGrid> {
        use calamine::DataType;
        use std::sync::Arc;

        // --- 1. Read Range<Data> and populate raw_values ---
        let range = self.sheets.worksheet_range(name)?;
        let range_start = range.start().unwrap_or((0, 0));
        let row_start = range_start.0 as usize;
        let col_start = range_start.1 as usize;

        let auto_bounds = max_filled_row == 0 || max_filled_col == 0;

        // If auto-bounds: first pass to compute bounds, then populate.
        // We collect all row data to avoid parsing XML twice.
        let (max_filled_row, max_filled_col, raw_values) = if auto_bounds {
            // Collect rows (avoids re-parsing)
            let all_rows: Vec<&[calamine::Data]> = range.rows().collect();

            // Compute bounds
            let mut mfr: usize = 0;
            let mut mfc: usize = 0;
            for (rel_row_idx, row_data) in all_rows.iter().enumerate() {
                let abs_row = rel_row_idx + row_start;
                for (rel_col_idx, cell) in row_data.iter().enumerate() {
                    if !cell.is_empty() {
                        let abs_col = rel_col_idx + col_start;
                        if abs_row + 1 > mfr { mfr = abs_row + 1; }
                        if abs_col + 1 > mfc { mfc = abs_col + 1; }
                    }
                }
            }

            let total = mfr * mfc;
            if total == 0 {
                return Ok(CellGrid::new_empty(0, 0));
            }

            // Populate raw_values from collected rows
            let mut rv = vec![RawValue::Empty; total];
            for (rel_row_idx, row_data) in all_rows.iter().enumerate() {
                let abs_row = rel_row_idx + row_start;
                if abs_row >= mfr { break; }
                for (rel_col_idx, cell) in row_data.iter().enumerate() {
                    let abs_col = rel_col_idx + col_start;
                    if abs_col >= mfc { break; }
                    let idx = abs_row * mfc + abs_col;
                    rv[idx] = data_to_raw_value(cell);
                }
            }
            (mfr, mfc, rv)
        } else {
            let total = max_filled_row * max_filled_col;
            if total == 0 {
                return Ok(CellGrid::new_empty(0, 0));
            }
            let mut rv = vec![RawValue::Empty; total];
            let mut cell_count = 0usize;
            let mut non_empty_count = 0usize;
            for (rel_row_idx, row_data) in range.rows().enumerate() {
                let abs_row = rel_row_idx + row_start;
                if abs_row >= max_filled_row { break; }
                for (rel_col_idx, cell) in row_data.iter().enumerate() {
                    let abs_col = rel_col_idx + col_start;
                    if abs_col >= max_filled_col { break; }
                    let idx = abs_row * max_filled_col + abs_col;
                    rv[idx] = data_to_raw_value(cell);
                    cell_count += 1;
                    if !matches!(rv[idx], RawValue::Empty) {
                        non_empty_count += 1;
                    }
                }
            }
            (max_filled_row, max_filled_col, rv)
        };

        // Free the Range<Data> now — all cell data has been extracted into raw_values.
        // This halves peak memory for large sheets.
        drop(range);

        let total = max_filled_row * max_filled_col;
        let empty_str: Arc<str> = Arc::from("");

        // --- 2. Read styles ---
        let styles = if include_styles {
            let style_range = self.sheets.worksheet_style(name)?;
            let mut styles_vec = vec![CellStyle::default(); total];

            for (sr, sc, style) in style_range.cells() {
                // Style coordinates are relative to style_range.start
                let style_start = style_range.start().unwrap_or((0, 0));
                let abs_row = sr + style_start.0 as usize;
                let abs_col = sc + style_start.1 as usize;
                if abs_row >= max_filled_row || abs_col >= max_filled_col {
                    continue;
                }
                let idx = abs_row * max_filled_col + abs_col;

                if let Some(font) = style.get_font() {
                    styles_vec[idx].font_bold = font.weight == FontWeight::Bold;
                    styles_vec[idx].font_size = font.size.unwrap_or(11.0) as f32;
                    styles_vec[idx].font_underline = font.underline != UnderlineStyle::None;

                    if let Some(color) = &font.color {
                        styles_vec[idx].font_color = Some(Arc::from(
                            format!("#{:02X}{:02X}{:02X}", color.red, color.green, color.blue)
                                .as_str(),
                        ));
                    }
                }

                if let Some(fill) = style.get_fill() {
                    styles_vec[idx].fill_pattern_solid = fill.pattern == FillPattern::Solid;
                    if let Some(color) = &fill.foreground_color {
                        styles_vec[idx].fill_fg_color = Some(Arc::from(
                            format!("#{:02X}{:02X}{:02X}", color.red, color.green, color.blue)
                                .as_str(),
                        ));
                    }
                }

                if let Some(nf) = style.get_number_format() {
                    styles_vec[idx].number_format = Arc::from(nf.format_code.as_str());
                }
            }

            Some(styles_vec)
        } else {
            None
        };

        // --- 3. Read merged cell ranges ---
        let merge_ranges = self.sheets.worksheet_merge_cells(name)?;
        let mut merge_map = HashMap::new();
        if let Some(ranges) = merge_ranges {
            for dim in &ranges {
                let (start_r, start_c) = dim.start;
                let (end_r, end_c) = dim.end;
                for r in start_r..=end_r {
                    for c in start_c..=end_c {
                        let r_us = r as usize;
                        let c_us = c as usize;
                        if r_us < max_filled_row && c_us < max_filled_col {
                            merge_map.insert(
                                (r_us, c_us),
                                (start_r as i32, start_c as i32),
                            );
                        }
                    }
                }
            }
        }

        // --- 4. Compute header field ---
        let mut header = vec![false; total];
        for idx in 0..total {
            if let RawValue::String(ref s) = raw_values[idx] {
                let is_bold = styles.as_ref().map(|sv| sv[idx].font_bold).unwrap_or(false);
                let is_underline = styles.as_ref().map(|sv| sv[idx].font_underline).unwrap_or(false);
                let ends_colon = s.ends_with(':');
                if is_bold || is_underline || ends_colon {
                    header[idx] = true;
                }
            }
        }

        Ok(CellGrid {
            rows: max_filled_row,
            cols: max_filled_col,
            raw_values,
            formatted_values: vec![None; total],
            styles,
            merge_map,
            header,
            table_member: vec![false; total],
            cell_textcolor: vec![empty_str.clone(); total],
            cell_highlight: vec![empty_str.clone(); total],
            row_textcolor: vec![empty_str.clone(); total],
            row_highlight: vec![empty_str; total],
            cell_formula: HashMap::new(),
            merge_parent_default: (0, 0),
            coord_row_offset: 0,
            coord_col_offset: 0,
        })
    }
}

/// Convert a calamine Data cell to our RawValue enum.
fn data_to_raw_value(data: &calamine::Data) -> RawValue {
    use calamine::DataType;
    use std::sync::Arc;

    if data.is_empty() {
        return RawValue::Empty;
    }
    // Treat empty strings as empty (calamine may report Data::String("") for
    // cells that openpyxl considers empty; this matters for merge detection).
    if data.is_string() {
        if let Some(s) = data.as_string() {
            if s.is_empty() {
                return RawValue::Empty;
            }
        }
    }
    if data.is_int() {
        return data.get_int().map(RawValue::Int).unwrap_or(RawValue::Empty);
    }
    if data.is_float() {
        return data.get_float().map(RawValue::Float).unwrap_or(RawValue::Empty);
    }
    if data.is_string() {
        // as_string() handles both Data::String and Data::RichText (via plain_text())
        return data
            .as_string()
            .map(|s| RawValue::String(Arc::from(s.as_str())))
            .unwrap_or(RawValue::Empty);
    }
    if data.is_bool() {
        return data.get_bool().map(RawValue::Bool).unwrap_or(RawValue::Empty);
    }
    if data.is_datetime() {
        let dt = data.get_datetime().unwrap();
        let v = dt.as_f64();
        if dt.is_duration() {
            return data.as_duration().map(RawValue::Timedelta).unwrap_or(RawValue::Float(v));
        }
        if v < 1.0 {
            return data.as_time().map(RawValue::Time).unwrap_or(RawValue::Float(v));
        }
        if v == (v as u64) as f64 {
            return data
                .as_date()
                .filter(|d| d.year() >= 1 && d.year() <= 9999)
                .map(RawValue::Date)
                .unwrap_or(RawValue::Float(v));
        }
        return data
            .as_datetime()
            .filter(|d| d.year() >= 1 && d.year() <= 9999)
            .map(RawValue::DateTime)
            .unwrap_or(RawValue::Float(v));
    }
    if data.is_datetime_iso() {
        let v = data.get_datetime_iso().unwrap();
        if v.contains('T') {
            return data
                .as_datetime()
                .filter(|d| d.year() >= 1 && d.year() <= 9999)
                .map(RawValue::DateTime)
                .unwrap_or_else(|| RawValue::String(Arc::from(v)));
        }
        if v.contains(':') {
            return data
                .as_time()
                .map(RawValue::Time)
                .unwrap_or_else(|| RawValue::String(Arc::from(v)));
        }
        return data
            .as_date()
            .filter(|d| d.year() >= 1 && d.year() <= 9999)
            .map(RawValue::Date)
            .unwrap_or_else(|| RawValue::String(Arc::from(v)));
    }
    if data.is_duration_iso() {
        return data.as_time().map(RawValue::Time).unwrap_or_else(|| {
            data.get_duration_iso()
                .map(|s| RawValue::String(Arc::from(s)))
                .unwrap_or(RawValue::Empty)
        });
    }
    if data.is_error() {
        return data
            .get_error()
            .map(|e| RawValue::String(Arc::from(e.to_string().as_str())))
            .unwrap_or(RawValue::Empty);
    }
    RawValue::Empty
}
