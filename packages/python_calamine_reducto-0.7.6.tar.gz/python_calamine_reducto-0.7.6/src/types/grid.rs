//! CellGrid: Rust-backed 2D cell grid replacing numpy structured arrays.
//!
//! Stores cell values, styles, merge info, and boolean fields in flat Rust Vecs.
//! Exposes Python interface via CellProxy (single cell) and CellGridView (sub-grid).

use std::collections::HashMap;
use std::sync::Arc;

use chrono::{Datelike, Timelike};
use pyo3::exceptions::{PyIndexError, PyKeyError, PyTypeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::{PyAny, PyList, PySlice, PyTuple};

type PyObject = Py<PyAny>;

use crate::CellValue;

/// Compact representation of a raw cell value (stays in Rust, not Python).
#[derive(Clone, Debug)]
pub enum RawValue {
    Int(i64),
    Float(f64),
    String(Arc<str>),
    Bool(bool),
    DateTime(chrono::NaiveDateTime),
    Date(chrono::NaiveDate),
    Time(chrono::NaiveTime),
    Timedelta(chrono::Duration),
    Empty,
}

impl RawValue {
    /// Convert to a Python object (only when accessed via CellProxy).
    pub fn to_pyobject(&self, py: Python<'_>) -> PyObject {
        match self {
            RawValue::Int(v) => v.into_pyobject(py).unwrap().into_any().unbind(),
            RawValue::Float(v) => v.into_pyobject(py).unwrap().into_any().unbind(),
            RawValue::String(v) => v.as_ref().into_pyobject(py).unwrap().into_any().unbind(),
            RawValue::Bool(v) => v.into_pyobject(py).unwrap().to_owned().into_any().unbind(),
            RawValue::DateTime(v) => v.into_pyobject(py).unwrap().into_any().unbind(),
            RawValue::Date(v) => v.into_pyobject(py).unwrap().into_any().unbind(),
            RawValue::Time(v) => v.into_pyobject(py).unwrap().into_any().unbind(),
            RawValue::Timedelta(v) => v.into_pyobject(py).unwrap().into_any().unbind(),
            RawValue::Empty => py.None(),
        }
    }

    pub fn is_empty(&self) -> bool {
        matches!(self, RawValue::Empty)
    }

    pub fn is_string(&self) -> bool {
        matches!(self, RawValue::String(_))
    }

    pub fn as_str(&self) -> Option<&str> {
        match self {
            RawValue::String(s) => Some(s.as_ref()),
            _ => None,
        }
    }

    /// Convert to display string (for large sheets that skip SSF formatting).
    pub fn to_display_string(&self) -> Option<String> {
        match self {
            RawValue::Empty => None,
            RawValue::Int(v) => Some(v.to_string()),
            RawValue::Float(v) => Some(v.to_string()),
            RawValue::String(v) => Some(v.to_string()),
            RawValue::Bool(v) => Some(if *v { "TRUE".to_string() } else { "FALSE".to_string() }),
            RawValue::DateTime(v) => Some(v.to_string()),
            RawValue::Date(v) => Some(v.to_string()),
            RawValue::Time(v) => Some(v.to_string()),
            RawValue::Timedelta(v) => Some(format!("{}s", v.num_seconds())),
        }
    }
}

impl From<&CellValue> for RawValue {
    fn from(cv: &CellValue) -> Self {
        match cv {
            CellValue::Int(v) => RawValue::Int(*v),
            CellValue::Float(v) => RawValue::Float(*v),
            CellValue::String(v) => RawValue::String(Arc::from(v.as_str())),
            CellValue::Bool(v) => RawValue::Bool(*v),
            CellValue::DateTime(v) => RawValue::DateTime(*v),
            CellValue::Date(v) => RawValue::Date(*v),
            CellValue::Time(v) => RawValue::Time(*v),
            CellValue::Timedelta(v) => RawValue::Timedelta(*v),
            CellValue::Empty => RawValue::Empty,
        }
    }
}

/// Per-cell style data. Only fields actually read downstream are stored.
#[derive(Clone, Debug)]
pub struct CellStyle {
    pub font_bold: bool,
    pub font_size: f32,
    pub font_underline: bool,
    pub number_format: Arc<str>,
    pub font_color: Option<Arc<str>>, // hex e.g. "#FF0000"
    pub fill_pattern_solid: bool,
    pub fill_fg_color: Option<Arc<str>>,
}

impl Default for CellStyle {
    fn default() -> Self {
        CellStyle {
            font_bold: false,
            font_size: 11.0,
            font_underline: false,
            number_format: Arc::from("General"),
            font_color: None,
            fill_pattern_solid: false,
            fill_fg_color: None,
        }
    }
}

/// The main 2D cell grid. All data stored in flat Rust Vecs (row-major).
#[pyclass]
pub struct CellGrid {
    pub(crate) rows: usize,
    pub(crate) cols: usize,

    // Cell values
    pub(crate) raw_values: Vec<RawValue>,
    pub(crate) formatted_values: Vec<Option<Arc<str>>>,

    // Styles (None when styling skipped for large sheets)
    pub(crate) styles: Option<Vec<CellStyle>>,

    // Merge map: (row, col) -> (parent_row, parent_col), absolute 0-based
    pub(crate) merge_map: HashMap<(usize, usize), (i32, i32)>,

    // Mutable boolean fields
    pub(crate) header: Vec<bool>,
    pub(crate) table_member: Vec<bool>,

    // Color fields
    pub(crate) cell_textcolor: Vec<Arc<str>>,
    pub(crate) cell_highlight: Vec<Arc<str>>,
    pub(crate) row_textcolor: Vec<Arc<str>>,
    pub(crate) row_highlight: Vec<Arc<str>>,

    // Formula map: sparse
    pub(crate) cell_formula: HashMap<(usize, usize), Arc<str>>,

    // Default merge_parent for cells not in merge_map.
    // (0, 0) for normal grids (matches openpyxl numpy zero-init).
    // (-1, -1) for empty sheet placeholders (matches openpyxl explicit init).
    pub(crate) merge_parent_default: (i32, i32),

    // Coord offsets: when a grid is cropped/sliced from a larger grid,
    // these track the original position so that coord = (row + row_offset + 1, col + col_offset + 1).
    pub(crate) coord_row_offset: usize,
    pub(crate) coord_col_offset: usize,
}

impl CellGrid {
    /// Create an empty grid (non-Python constructor for use from Rust).
    pub(crate) fn new_empty(rows: usize, cols: usize) -> Self {
        let total = rows * cols;
        let empty_str: Arc<str> = Arc::from("");
        CellGrid {
            rows,
            cols,
            raw_values: vec![RawValue::Empty; total],
            formatted_values: vec![None; total],
            styles: None,
            merge_map: HashMap::new(),
            header: vec![false; total],
            table_member: vec![false; total],
            cell_textcolor: vec![empty_str.clone(); total],
            cell_highlight: vec![empty_str.clone(); total],
            row_textcolor: vec![empty_str.clone(); total],
            row_highlight: vec![empty_str; total],
            cell_formula: HashMap::new(),
            merge_parent_default: (0, 0),
            coord_row_offset: 0,
            coord_col_offset: 0,
        }
    }

    #[inline]
    fn idx(&self, row: usize, col: usize) -> usize {
        row * self.cols + col
    }

    fn get_formatted_value(&self, row: usize, col: usize) -> Option<&str> {
        self.formatted_values[self.idx(row, col)]
            .as_deref()
    }

    fn get_style(&self, row: usize, col: usize) -> Option<&CellStyle> {
        self.styles.as_ref().map(|s| &s[self.idx(row, col)])
    }

    fn is_merged(&self, row: usize, col: usize) -> bool {
        // Match openpyxl: is_merged=True for ANY cell in merge_map whose value is empty.
        // This includes both parent and child cells — openpyxl checks value emptiness,
        // not coordinate position. Parent cells with values get False.
        if self.merge_map.contains_key(&(row, col)) {
            let idx = self.idx(row, col);
            matches!(self.raw_values[idx], RawValue::Empty)
        } else {
            false
        }
    }

    fn merge_parent(&self, row: usize, col: usize) -> (i32, i32) {
        // Match openpyxl: merge_parent is set for cells in merge_map with empty value.
        // Both parent and child cells — openpyxl uses value emptiness, not coordinates.
        match self.merge_map.get(&(row, col)) {
            Some(&(pr, pc))
                if matches!(self.raw_values[self.idx(row, col)], RawValue::Empty) =>
            {
                (pr, pc)
            }
            _ => self.merge_parent_default,
        }
    }

    /// Build a cell dict for a single cell (for CellProxy.__getitem__).
    fn cell_field(&self, py: Python<'_>, row: usize, col: usize, field: &str) -> PyResult<PyObject> {
        let idx = self.idx(row, col);
        match field {
            "value" => {
                match &self.formatted_values[idx] {
                    Some(s) => Ok(s.as_ref().into_pyobject(py)?.into_any().unbind()),
                    None => Ok(py.None()),
                }
            }
            "number_format" => {
                let nf = self.styles.as_ref()
                    .map(|s| s[idx].number_format.as_ref())
                    .unwrap_or("General");
                Ok(nf.into_pyobject(py)?.into_any().unbind())
            }
            "is_merged" => {
                // A cell is "merged" if it's a child (has value None/empty and parent != self)
                let is_m = self.is_merged(row, col);
                Ok(is_m.into_pyobject(py)?.to_owned().into_any().unbind())
            }
            "merge_parent" => {
                let (pr, pc) = self.merge_parent(row, col);
                // Return as numpy-compatible i32 array for coord arithmetic
                let arr = [pr, pc];
                // Use a Python list that supports element-wise ops via numpy
                // For backward compat, we return a numpy array
                let numpy = py.import("numpy")?;
                let result = numpy.call_method1("array", (arr.to_vec(), "int32"))?;
                Ok(result.unbind())
            }
            "coord" => {
                let arr = [(row + self.coord_row_offset + 1) as i32, (col + self.coord_col_offset + 1) as i32];
                let numpy = py.import("numpy")?;
                let result = numpy.call_method1("array", (arr.to_vec(), "int32"))?;
                Ok(result.unbind())
            }
            "font_bold" => {
                let bold = self.styles.as_ref()
                    .map(|s| s[idx].font_bold)
                    .unwrap_or(false);
                Ok(bold.into_pyobject(py)?.to_owned().into_any().unbind())
            }
            "font_size" => {
                let size = self.styles.as_ref()
                    .map(|s| s[idx].font_size)
                    .unwrap_or(11.0);
                Ok(size.into_pyobject(py)?.into_any().unbind())
            }
            "header" => {
                Ok(self.header[idx].into_pyobject(py)?.to_owned().into_any().unbind())
            }
            "table_member" => {
                Ok(self.table_member[idx].into_pyobject(py)?.to_owned().into_any().unbind())
            }
            "cell_textcolor" => {
                let c = &self.cell_textcolor[idx];
                Ok(c.as_ref().into_pyobject(py)?.into_any().unbind())
            }
            "cell_highlight" => {
                let c = &self.cell_highlight[idx];
                Ok(c.as_ref().into_pyobject(py)?.into_any().unbind())
            }
            "row_textcolor" => {
                let c = &self.row_textcolor[idx];
                Ok(c.as_ref().into_pyobject(py)?.into_any().unbind())
            }
            "row_highlight" => {
                let c = &self.row_highlight[idx];
                Ok(c.as_ref().into_pyobject(py)?.into_any().unbind())
            }
            "cell_formula" => {
                match self.cell_formula.get(&(row, col)) {
                    Some(f) => Ok(f.as_ref().into_pyobject(py)?.into_any().unbind()),
                    None => Ok(py.None()),
                }
            }
            "bg_color" => {
                // Compute from fill_fg_color when solid
                let color = self.styles.as_ref().and_then(|s| {
                    let st = &s[idx];
                    if st.fill_pattern_solid {
                        st.fill_fg_color.as_ref().map(|c| c.as_ref())
                    } else {
                        None
                    }
                }).unwrap_or("#FFFFFF");
                Ok(color.into_pyobject(py)?.into_any().unbind())
            }
            "border" => {
                Ok(false.into_pyobject(py)?.to_owned().into_any().unbind())
            }
            "border_styles" => {
                Ok(py.None())
            }
            "col_textcolor" | "col_highlight" | "row_height" | "col_width" => {
                // Fields written but never read downstream
                Ok("".into_pyobject(py)?.into_any().unbind())
            }
            _ => Err(PyKeyError::new_err(format!("Unknown field: {field}"))),
        }
    }

    /// Return a 2D numpy array for a given field name.
    fn field_to_numpy(&self, py: Python<'_>, field: &str) -> PyResult<PyObject> {
        let numpy = py.import("numpy")?;

        match field {
            "value" => {
                // Object array of formatted strings / None
                let flat: Vec<PyObject> = self.formatted_values.iter()
                    .map(|v| match v {
                        Some(s) => s.as_ref().into_pyobject(py).unwrap().into_any().unbind(),
                        None => py.None(),
                    })
                    .collect();
                let arr = numpy.call_method1("array", (flat, "object"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            "header" => {
                let arr = numpy.call_method1("array", (&self.header, "bool"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            "table_member" => {
                let arr = numpy.call_method1("array", (&self.table_member, "bool"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            "is_merged" => {
                // Match openpyxl: is_merged=True for any cell in merge_map with empty value
                let mut flags = vec![false; self.rows * self.cols];
                for (&(r, c), _) in &self.merge_map {
                    if r < self.rows && c < self.cols {
                        let idx = r * self.cols + c;
                        if matches!(self.raw_values[idx], RawValue::Empty) {
                            flags[idx] = true;
                        }

                    }
                }
                let arr = numpy.call_method1("array", (flags, "bool"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            "merge_parent" => {
                // shape (rows, cols, 2) int32 array — only set for empty cells in merge ranges
                // Default from merge_parent_default: (0,0) for normal grids, (-1,-1) for empty sheets
                let (def_r, def_c) = self.merge_parent_default;
                let mut data = vec![0i32; self.rows * self.cols * 2];
                if def_r != 0 || def_c != 0 {
                    for i in 0..self.rows * self.cols {
                        data[i * 2] = def_r;
                        data[i * 2 + 1] = def_c;
                    }
                }
                for (&(r, c), &(pr, pc)) in &self.merge_map {
                    if r < self.rows && c < self.cols {
                        let idx = r * self.cols + c;
                        // Match openpyxl: set for any cell in merge_map with empty value
                        if matches!(self.raw_values[idx], RawValue::Empty) {
                            let base = idx * 2;
                            data[base] = pr;
                            data[base + 1] = pc;
                        }
                    }
                }
                let arr = numpy.call_method1("array", (data, "int32"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols, 2),))?;
                Ok(reshaped.unbind())
            }
            "coord" => {
                // shape (rows, cols, 2) int32 array, 1-based with offsets
                let mut data = vec![0i32; self.rows * self.cols * 2];
                for r in 0..self.rows {
                    for c in 0..self.cols {
                        let base = (r * self.cols + c) * 2;
                        data[base] = (r + self.coord_row_offset + 1) as i32;
                        data[base + 1] = (c + self.coord_col_offset + 1) as i32;
                    }
                }
                let arr = numpy.call_method1("array", (data, "int32"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols, 2),))?;
                Ok(reshaped.unbind())
            }
            "font_bold" => {
                let flags: Vec<bool> = if let Some(ref styles) = self.styles {
                    styles.iter().map(|s| s.font_bold).collect()
                } else {
                    vec![false; self.rows * self.cols]
                };
                let arr = numpy.call_method1("array", (flags, "bool"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            "font_size" => {
                let sizes: Vec<f32> = if let Some(ref styles) = self.styles {
                    styles.iter().map(|s| s.font_size).collect()
                } else {
                    vec![11.0f32; self.rows * self.cols]
                };
                let arr = numpy.call_method1("array", (sizes, "float32"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            "number_format" => {
                let fmts: Vec<&str> = if let Some(ref styles) = self.styles {
                    styles.iter().map(|s| s.number_format.as_ref()).collect()
                } else {
                    vec!["General"; self.rows * self.cols]
                };
                let arr = numpy.call_method1("array", (fmts, "object"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            "cell_textcolor" => {
                let vals: Vec<&str> = self.cell_textcolor.iter().map(|s| s.as_ref()).collect();
                let arr = numpy.call_method1("array", (vals, "object"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            "cell_highlight" => {
                let vals: Vec<&str> = self.cell_highlight.iter().map(|s| s.as_ref()).collect();
                let arr = numpy.call_method1("array", (vals, "object"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            "cell_formula" => {
                let mut vals: Vec<PyObject> = (0..self.rows * self.cols)
                    .map(|_| py.None())
                    .collect();
                for (&(r, c), f) in &self.cell_formula {
                    if r < self.rows && c < self.cols {
                        vals[r * self.cols + c] = f.as_ref().into_pyobject(py).unwrap().into_any().unbind();
                    }
                }
                let arr = numpy.call_method1("array", (vals, "object"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            "row_textcolor" => {
                let vals: Vec<&str> = self.row_textcolor.iter().map(|s| s.as_ref()).collect();
                let arr = numpy.call_method1("array", (vals, "object"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            "row_highlight" => {
                let vals: Vec<&str> = self.row_highlight.iter().map(|s| s.as_ref()).collect();
                let arr = numpy.call_method1("array", (vals, "object"))?;
                let reshaped = arr.call_method1("reshape", ((self.rows, self.cols),))?;
                Ok(reshaped.unbind())
            }
            _ => Err(PyKeyError::new_err(format!("Unknown field for numpy: {field}"))),
        }
    }

    /// Return a 2D numpy array for a field within a sub-region.
    fn field_to_numpy_view(
        &self, py: Python<'_>, field: &str,
        r_start: usize, r_end: usize, c_start: usize, c_end: usize,
    ) -> PyResult<PyObject> {
        // Get the full array, then slice it in numpy
        let full = self.field_to_numpy(py, field)?;
        let full_bound = full.bind(py);
        let sliced = full_bound.get_item((
            pyo3::types::PySlice::new(py, r_start as isize, r_end as isize, 1),
            pyo3::types::PySlice::new(py, c_start as isize, c_end as isize, 1),
        ))?;
        // Return a contiguous copy so downstream code can modify it
        let copy = sliced.call_method0("copy")?;
        Ok(copy.unbind())
    }
}

fn parse_slice(_py: Python<'_>, slice: &Bound<'_, PySlice>, max: usize) -> PyResult<(usize, usize)> {
    let indices = slice.indices(max as isize)?;
    let start = indices.start.max(0) as usize;
    let stop = indices.stop.max(0) as usize;
    Ok((start, stop))
}

/// Lazy row iterator for CellGrid — yields one CellGridView per row.
#[pyclass]
pub struct CellGridIterator {
    grid: Py<CellGrid>,
    current_row: usize,
    total_rows: usize,
    cols: usize,
}

#[pymethods]
impl CellGridIterator {
    fn __iter__(slf: PyRef<'_, Self>) -> PyRef<'_, Self> {
        slf
    }

    fn __next__(&mut self, py: Python<'_>) -> PyResult<Option<CellGridView>> {
        if self.current_row >= self.total_rows {
            return Ok(None);
        }
        let view = CellGridView {
            grid: self.grid.clone_ref(py),
            row_start: self.current_row,
            row_end: self.current_row + 1,
            col_start: 0,
            col_end: self.cols,
        };
        self.current_row += 1;
        Ok(Some(view))
    }
}

#[pymethods]
impl CellGrid {
    fn __len__(&self) -> usize {
        self.rows
    }

    /// Iterate over rows — yields 1-row CellGridViews lazily.
    fn __iter__(slf: Bound<'_, Self>, py: Python<'_>) -> PyResult<PyObject> {
        let grid = slf.borrow();
        let rows = grid.rows;
        let cols = grid.cols;
        drop(grid);

        let iter = CellGridIterator {
            grid: slf.unbind(),
            current_row: 0,
            total_rows: rows,
            cols,
        };
        Ok(iter.into_pyobject(py)?.into_any().unbind())
    }

    #[getter]
    fn shape(&self) -> (usize, usize) {
        (self.rows, self.cols)
    }

    #[getter]
    fn size(&self) -> usize {
        self.rows * self.cols
    }

    #[getter]
    fn field_names(&self) -> Vec<&str> {
        vec![
            "value", "number_format", "is_merged", "merge_parent", "font_bold",
            "font_size", "coord", "header", "table_member", "cell_textcolor",
            "cell_highlight", "cell_formula", "row_textcolor", "row_highlight",
            "bg_color", "border", "border_styles",
        ]
    }

    /// Create an empty grid with default values.
    /// Uses merge_parent_default=(-1,-1) to match openpyxl empty sheet init.
    #[classmethod]
    fn empty(_cls: &Bound<'_, pyo3::types::PyType>, rows: usize, cols: usize) -> Self {
        let total = rows * cols;
        let empty_str: Arc<str> = Arc::from("");
        CellGrid {
            rows,
            cols,
            raw_values: vec![RawValue::Empty; total],
            formatted_values: vec![None; total],
            styles: None,
            merge_map: HashMap::new(),
            header: vec![false; total],
            table_member: vec![false; total],
            cell_textcolor: vec![empty_str.clone(); total],
            cell_highlight: vec![empty_str.clone(); total],
            row_textcolor: vec![empty_str.clone(); total],
            row_highlight: vec![empty_str; total],
            cell_formula: HashMap::new(),
            merge_parent_default: (-1, -1),
            coord_row_offset: 0,
            coord_col_offset: 0,
        }
    }

    /// Dispatch __getitem__:
    ///  - grid[r, c] → CellProxy
    ///  - grid["field"] → numpy 2D array
    ///  - grid[r1:r2, c1:c2] → CellGridView
    ///  - grid[r1:r2] → CellGridView (all cols)
    fn __getitem__(slf: Py<Self>, py: Python<'_>, key: &Bound<'_, PyAny>) -> PyResult<PyObject> {
        // String key -> field array
        if let Ok(field) = key.extract::<String>() {
            let grid = slf.borrow(py);
            return grid.field_to_numpy(py, &field);
        }

        // Tuple key -> (row, col) or (slice, slice)
        if let Ok(tuple) = key.downcast::<PyTuple>() {
            if tuple.len() == 2 {
                let item0 = tuple.get_item(0)?;
                let item1 = tuple.get_item(1)?;

                // (int, int) -> CellProxy
                if let (Ok(r), Ok(c)) = (item0.extract::<usize>(), item1.extract::<usize>()) {
                    let grid = slf.borrow(py);
                    if r >= grid.rows || c >= grid.cols {
                        return Err(PyIndexError::new_err(format!(
                            "Index ({r}, {c}) out of bounds for grid of shape ({}, {})",
                            grid.rows, grid.cols
                        )));
                    }
                    drop(grid);
                    let proxy = CellProxy {
                        grid: slf.clone_ref(py),
                        row: r,
                        col: c,
                    };
                    return Ok(proxy.into_pyobject(py)?.into_any().unbind());
                }

                // (slice, slice) or (slice, int) etc -> CellGridView
                let grid = slf.borrow(py);
                let rows = grid.rows;
                let cols = grid.cols;
                drop(grid);

                let (r_start, r_end) = if let Ok(s) = item0.downcast::<PySlice>() {
                    parse_slice(py, s, rows)?
                } else if let Ok(r) = item0.extract::<usize>() {
                    (r, r + 1)
                } else {
                    return Err(PyTypeError::new_err("Invalid row index type"));
                };

                let (c_start, c_end) = if let Ok(s) = item1.downcast::<PySlice>() {
                    parse_slice(py, s, cols)?
                } else if let Ok(c) = item1.extract::<usize>() {
                    (c, c + 1)
                } else {
                    return Err(PyTypeError::new_err("Invalid column index type"));
                };

                let view = CellGridView {
                    grid: slf.clone_ref(py),
                    row_start: r_start,
                    row_end: r_end,
                    col_start: c_start,
                    col_end: c_end,
                };
                return Ok(view.into_pyobject(py)?.into_any().unbind());
            }
        }

        // Single slice -> row range, all cols
        if let Ok(s) = key.downcast::<PySlice>() {
            let grid = slf.borrow(py);
            let rows = grid.rows;
            let cols = grid.cols;
            drop(grid);

            let (r_start, r_end) = parse_slice(py, s, rows)?;
            let view = CellGridView {
                grid: slf.clone_ref(py),
                row_start: r_start,
                row_end: r_end,
                col_start: 0,
                col_end: cols,
            };
            return Ok(view.into_pyobject(py)?.into_any().unbind());
        }

        // Single int -> single row, all cols
        if let Ok(r) = key.extract::<usize>() {
            let grid = slf.borrow(py);
            let rows = grid.rows;
            let cols = grid.cols;
            drop(grid);

            if r >= rows {
                return Err(PyIndexError::new_err(format!(
                    "Row index {r} out of bounds for grid with {rows} rows"
                )));
            }
            let view = CellGridView {
                grid: slf.clone_ref(py),
                row_start: r,
                row_end: r + 1,
                col_start: 0,
                col_end: cols,
            };
            return Ok(view.into_pyobject(py)?.into_any().unbind());
        }

        Err(PyTypeError::new_err(format!(
            "CellGrid indices must be int, tuple, slice, or str, not {}",
            key.get_type().name()?
        )))
    }

    /// Dispatch __setitem__:
    ///  - grid["table_member"] = False  (broadcast)
    ///  - grid["table_member"] = numpy_array  (copy from numpy)
    fn __setitem__(&mut self, _py: Python<'_>, key: &Bound<'_, PyAny>, value: &Bound<'_, PyAny>) -> PyResult<()> {
        if let Ok(field) = key.extract::<String>() {
            match field.as_str() {
                "table_member" => {
                    if let Ok(val) = value.extract::<bool>() {
                        self.table_member.fill(val);
                    } else {
                        // Assume numpy array
                        let flat = value.call_method0("flatten")?;
                        let vals: Vec<bool> = flat.extract()?;
                        if vals.len() == self.table_member.len() {
                            self.table_member = vals;
                        } else {
                            return Err(PyValueError::new_err("Array size mismatch"));
                        }
                    }
                    Ok(())
                }
                "header" => {
                    if let Ok(val) = value.extract::<bool>() {
                        self.header.fill(val);
                    } else {
                        let flat = value.call_method0("flatten")?;
                        let vals: Vec<bool> = flat.extract()?;
                        if vals.len() == self.header.len() {
                            self.header = vals;
                        } else {
                            return Err(PyValueError::new_err("Array size mismatch"));
                        }
                    }
                    Ok(())
                }
                "value" => {
                    // Broadcast None to all cells
                    if value.is_none() {
                        self.formatted_values.fill(None);
                    }
                    Ok(())
                }
                _ => Err(PyKeyError::new_err(format!("Cannot set field: {field}"))),
            }
        } else {
            Err(PyTypeError::new_err("Key must be a string field name"))
        }
    }

    /// Set a cell's formula.
    fn set_cell_formula(&mut self, row: usize, col: usize, formula: &str) {
        self.cell_formula.insert((row, col), Arc::from(formula));
    }

    /// Set a cell's formatted (display) value.
    fn set_cell_value(&mut self, row: usize, col: usize, value: &str) -> PyResult<()> {
        if row >= self.rows || col >= self.cols {
            return Err(PyIndexError::new_err(format!(
                "Index ({row}, {col}) out of bounds for grid of shape ({}, {})",
                self.rows, self.cols
            )));
        }
        let idx = self.idx(row, col);
        self.formatted_values[idx] = Some(Arc::from(value));
        Ok(())
    }

    /// Set a boolean field for a rectangular range.
    fn set_field_range(
        &mut self,
        field: &str,
        r1: usize, r2: usize,
        c1: usize, c2: usize,
        value: bool,
    ) -> PyResult<()> {
        let target = match field {
            "table_member" => &mut self.table_member,
            "header" => &mut self.header,
            _ => return Err(PyKeyError::new_err(format!("Cannot range-set field: {field}"))),
        };
        for r in r1..r2.min(self.rows) {
            for c in c1..c2.min(self.cols) {
                target[r * self.cols + c] = value;
            }
        }
        Ok(())
    }

    /// Apply a Python formatting function to all cells.
    /// Callback signature: formatter(raw_value, number_format) -> str | None
    fn apply_formatting(&mut self, py: Python<'_>, formatter: &Bound<'_, PyAny>) -> PyResult<()> {
        for idx in 0..self.raw_values.len() {
            if self.raw_values[idx].is_empty() {
                self.formatted_values[idx] = None;
                continue;
            }
            let raw_py = self.raw_values[idx].to_pyobject(py);
            let nf = self.styles.as_ref()
                .map(|s| s[idx].number_format.as_ref())
                .unwrap_or("General");
            let result = formatter.call1((raw_py, nf))?;
            if result.is_none() {
                self.formatted_values[idx] = None;
            } else {
                let s: String = result.str()?.to_string();
                self.formatted_values[idx] = Some(Arc::from(s.as_str()));
            }
        }
        Ok(())
    }

    /// Apply SSF formatting in pure Rust (no Python callback).
    /// Uses the ssfmt crate for ECMA-376 number format compliance.
    fn apply_formatting_rust(&mut self) {
        use ssfmt::{NumberFormat, FormatOptions, date_serial};

        let opts = FormatOptions::default(); // 1900 date system, en-US

        // Cache parsed NumberFormat objects to avoid re-parsing the same format string
        let mut format_cache: HashMap<Arc<str>, Option<NumberFormat>> = HashMap::new();

        for idx in 0..self.raw_values.len() {
            if self.raw_values[idx].is_empty() {
                self.formatted_values[idx] = None;
                continue;
            }

            let nf: &str = self.styles.as_ref()
                .map(|s| s[idx].number_format.as_ref())
                .unwrap_or("General");

            // Large integer bypass: 12+ digit whole numbers with "General" format
            // get formatted as plain integers to prevent scientific notation.
            if nf == "General" {
                match &self.raw_values[idx] {
                    RawValue::Int(v) if v.unsigned_abs() >= 100_000_000_000 => {
                        self.formatted_values[idx] = Some(Arc::from(v.to_string().as_str()));
                        continue;
                    }
                    RawValue::Float(v) if v.abs() >= 100_000_000_000.0 && v.fract() == 0.0 && v.abs() < (i64::MAX as f64) => {
                        self.formatted_values[idx] = Some(Arc::from((*v as i64).to_string().as_str()));
                        continue;
                    }
                    _ => {}
                }
            }

            // String values pass through (SSF @-format just returns the string)
            if let RawValue::String(s) = &self.raw_values[idx] {
                if nf == "General" || nf == "@" {
                    self.formatted_values[idx] = Some(s.clone());
                    continue;
                }
            }

            // Bool values: "TRUE" / "FALSE" (SSF doesn't handle bools)
            if let RawValue::Bool(v) = &self.raw_values[idx] {
                self.formatted_values[idx] = Some(Arc::from(
                    if *v { "TRUE" } else { "FALSE" }
                ));
                continue;
            }

            // Convert RawValue to f64 for ssfmt
            let numeric_value: f64 = match &self.raw_values[idx] {
                RawValue::Int(v) => *v as f64,
                RawValue::Float(v) => *v,
                RawValue::String(s) => {
                    // Non-General/@ string with a format code — use format_text
                    let nf_arc: Arc<str> = self.styles.as_ref()
                        .map(|st| st[idx].number_format.clone())
                        .unwrap_or_else(|| Arc::from("General"));
                    let parsed = format_cache.entry(nf_arc.clone()).or_insert_with(|| {
                        NumberFormat::parse(nf_arc.as_ref()).ok()
                    });
                    if let Some(fmt) = parsed {
                        self.formatted_values[idx] = Some(Arc::from(
                            fmt.format_text(s.as_ref(), &opts).as_str()
                        ));
                    } else {
                        self.formatted_values[idx] = Some(s.clone());
                    }
                    continue;
                }
                RawValue::DateTime(dt) => {
                    let date_serial = date_serial::date_to_serial(
                        dt.date().year(), dt.date().month(), dt.date().day(),
                        opts.date_system,
                    );
                    let secs = dt.time().num_seconds_from_midnight() as f64;
                    let nanos = dt.time().nanosecond() as f64 / 1_000_000_000.0;
                    let time_frac = (secs + nanos) / 86400.0;
                    date_serial + time_frac
                }
                RawValue::Date(d) => {
                    date_serial::date_to_serial(
                        d.year(), d.month(), d.day(),
                        opts.date_system,
                    )
                }
                RawValue::Time(t) => {
                    let secs = t.num_seconds_from_midnight() as f64;
                    let nanos = t.nanosecond() as f64 / 1_000_000_000.0;
                    (secs + nanos) / 86400.0
                }
                RawValue::Timedelta(td) => {
                    let secs = td.num_seconds() as f64;
                    let nanos = td.subsec_nanos() as f64 / 1_000_000_000.0;
                    (secs + nanos) / 86400.0
                }
                RawValue::Bool(_) | RawValue::Empty => unreachable!(),
            };

            // Look up or parse the format code
            let nf_arc: Arc<str> = self.styles.as_ref()
                .map(|s| s[idx].number_format.clone())
                .unwrap_or_else(|| Arc::from("General"));

            let parsed = format_cache.entry(nf_arc.clone()).or_insert_with(|| {
                NumberFormat::parse(nf_arc.as_ref()).ok()
            });

            let formatted = match parsed {
                Some(fmt) => fmt.format(numeric_value, &opts),
                None => {
                    // Parse failed — fall back to display string
                    self.formatted_values[idx] = self.raw_values[idx]
                        .to_display_string()
                        .map(|s| Arc::from(s.as_str()));
                    continue;
                }
            };

            self.formatted_values[idx] = Some(Arc::from(formatted.as_str()));
        }
    }

    /// Reformat string cells with date format codes using a Python dateutil callback.
    ///
    /// Matches Python SSF behavior: when a string value has a date format,
    /// parse the string as a date via dateutil, convert to serial number,
    /// and reformat with ssfmt.
    ///
    /// Callback signature: date_parse(string) -> Optional[float]
    ///   Returns a date serial number or None if parsing fails.
    fn apply_dateutil_reformat(&mut self, _py: Python<'_>, date_parse: &Bound<'_, PyAny>) -> PyResult<()> {
        use ssfmt::{NumberFormat, FormatOptions};

        let opts = FormatOptions::default();
        let mut format_cache: HashMap<Arc<str>, Option<NumberFormat>> = HashMap::new();

        for idx in 0..self.raw_values.len() {
            // Only process string values
            let s = match &self.raw_values[idx] {
                RawValue::String(s) => s.clone(),
                _ => continue,
            };

            // Skip General and @ formats
            let nf: &str = match &self.styles {
                Some(styles) => styles[idx].number_format.as_ref(),
                None => continue,
            };
            if nf == "General" || nf == "@" {
                continue;
            }

            // Parse the format and check if it has date parts
            let nf_arc: Arc<str> = Arc::from(nf);
            let parsed = format_cache.entry(nf_arc.clone()).or_insert_with(|| {
                NumberFormat::parse(nf_arc.as_ref()).ok()
            });
            let fmt = match parsed {
                Some(f) => f,
                None => continue,
            };
            if !fmt.is_date_format() {
                continue;
            }

            // Call Python dateutil callback: date_parse(string) -> Optional[float]
            let result = date_parse.call1((s.as_ref(),))?;
            if result.is_none() {
                continue;
            }
            let serial: f64 = result.extract()?;

            // Reformat with ssfmt
            let formatted = fmt.format(serial, &opts);
            self.formatted_values[idx] = Some(Arc::from(formatted.as_str()));
        }

        Ok(())
    }

    /// For large sheets: store raw values directly as display strings (no SSF).
    fn apply_raw_as_formatted(&mut self) {
        for idx in 0..self.raw_values.len() {
            self.formatted_values[idx] = self.raw_values[idx]
                .to_display_string()
                .map(|s| Arc::from(s.as_str()));
        }
    }

    /// Apply hex-to-named-color conversion via Python callback.
    /// Callback: hex_to_name(hex_str) -> str | None
    fn apply_color_names(&mut self, _py: Python<'_>, converter: &Bound<'_, PyAny>) -> PyResult<()> {
        if let Some(ref styles) = self.styles {
            for idx in 0..styles.len() {
                // Skip empty cells
                if self.formatted_values[idx].is_none() {
                    continue;
                }
                if let Some(fv) = &self.formatted_values[idx] {
                    if fv.trim().is_empty() {
                        continue;
                    }
                }

                let style = &styles[idx];

                // For merged cells, use parent's style
                let row = idx / self.cols;
                let col = idx % self.cols;
                let effective_style = if let Some(&(pr, pc)) = self.merge_map.get(&(row, col)) {
                    if pr >= 0 && pc >= 0 {
                        let pidx = pr as usize * self.cols + pc as usize;
                        if pidx < styles.len() { &styles[pidx] } else { style }
                    } else {
                        style
                    }
                } else {
                    style
                };

                // Font color
                if let Some(ref hex) = effective_style.font_color {
                    let result = converter.call1((hex.as_ref(),))?;
                    if !result.is_none() {
                        let name: String = result.extract()?;
                        if name != "default" {
                            self.cell_textcolor[idx] = Arc::from(name.as_str());
                        }
                    }
                }

                // Background color
                if effective_style.fill_pattern_solid {
                    if let Some(ref hex) = effective_style.fill_fg_color {
                        let result = converter.call1((hex.as_ref(),))?;
                        if !result.is_none() {
                            let name: String = result.extract()?;
                            if name != "default" {
                                self.cell_highlight[idx] = Arc::from(name.as_str());
                            }
                        }
                    }
                }
            }
        }
        Ok(())
    }

    /// Propagate merged cell values: children get parent's formatted value.
    fn propagate_merged_values(&mut self) {
        let entries: Vec<((usize, usize), (i32, i32))> =
            self.merge_map.iter().map(|(&k, &v)| (k, v)).collect();
        for ((row, col), (pr, pc)) in entries {
            // Skip if this IS the parent
            if pr == row as i32 && pc == col as i32 {
                continue;
            }
            let idx = row * self.cols + col;
            // Only propagate if child has no value
            let child_empty = self.formatted_values[idx]
                .as_ref()
                .map(|s| s.is_empty())
                .unwrap_or(true);
            if child_empty && pr >= 0 && pc >= 0 {
                let parent_idx = pr as usize * self.cols + pc as usize;
                if parent_idx < self.formatted_values.len() {
                    self.formatted_values[idx] = self.formatted_values[parent_idx].clone();
                }
            }
        }
    }

    /// Deep copy of the grid.
    fn copy(&self) -> Self {
        CellGrid {
            rows: self.rows,
            cols: self.cols,
            raw_values: self.raw_values.clone(),
            formatted_values: self.formatted_values.clone(),
            styles: self.styles.clone(),
            merge_map: self.merge_map.clone(),
            header: self.header.clone(),
            table_member: self.table_member.clone(),
            cell_textcolor: self.cell_textcolor.clone(),
            cell_highlight: self.cell_highlight.clone(),
            row_textcolor: self.row_textcolor.clone(),
            row_highlight: self.row_highlight.clone(),
            cell_formula: self.cell_formula.clone(),
            merge_parent_default: self.merge_parent_default,
            coord_row_offset: self.coord_row_offset,
            coord_col_offset: self.coord_col_offset,
        }
    }

    /// Create a new independent CellGrid from a rectangular region.
    fn slice_copy(&self, r1: usize, r2: usize, c1: usize, c2: usize) -> PyResult<Self> {
        let r2 = r2.min(self.rows);
        let c2 = c2.min(self.cols);
        if r1 >= r2 || c1 >= c2 {
            return Err(PyValueError::new_err("Invalid slice bounds"));
        }
        let new_rows = r2 - r1;
        let new_cols = c2 - c1;
        let total = new_rows * new_cols;

        let mut raw_values = Vec::with_capacity(total);
        let mut formatted_values = Vec::with_capacity(total);
        let mut header = Vec::with_capacity(total);
        let mut table_member = Vec::with_capacity(total);
        let mut cell_textcolor = Vec::with_capacity(total);
        let mut cell_highlight = Vec::with_capacity(total);
        let mut row_textcolor = Vec::with_capacity(total);
        let mut row_highlight = Vec::with_capacity(total);
        let mut styles_vec = if self.styles.is_some() {
            Some(Vec::with_capacity(total))
        } else {
            None
        };

        for r in r1..r2 {
            for c in c1..c2 {
                let idx = r * self.cols + c;
                raw_values.push(self.raw_values[idx].clone());
                formatted_values.push(self.formatted_values[idx].clone());
                header.push(self.header[idx]);
                table_member.push(self.table_member[idx]);
                cell_textcolor.push(self.cell_textcolor[idx].clone());
                cell_highlight.push(self.cell_highlight[idx].clone());
                row_textcolor.push(self.row_textcolor[idx].clone());
                row_highlight.push(self.row_highlight[idx].clone());
                if let Some(ref mut sv) = styles_vec {
                    sv.push(self.styles.as_ref().unwrap()[idx].clone());
                }
            }
        }

        // Remap merge map — drop entries whose parent falls outside the slice
        let mut merge_map = HashMap::new();
        for (&(r, c), &(pr, pc)) in &self.merge_map {
            if r >= r1 && r < r2 && c >= c1 && c < c2 {
                let new_pr = pr - r1 as i32;
                let new_pc = pc - c1 as i32;
                // Only keep if parent is within the new grid bounds
                if new_pr >= 0 && new_pc >= 0
                    && (new_pr as usize) < new_rows && (new_pc as usize) < new_cols
                {
                    merge_map.insert((r - r1, c - c1), (new_pr, new_pc));
                }
            }
        }

        // Remap formula map
        let mut cell_formula = HashMap::new();
        for (&(r, c), f) in &self.cell_formula {
            if r >= r1 && r < r2 && c >= c1 && c < c2 {
                cell_formula.insert((r - r1, c - c1), f.clone());
            }
        }

        Ok(CellGrid {
            rows: new_rows,
            cols: new_cols,
            raw_values,
            formatted_values,
            styles: styles_vec,
            merge_map,
            header,
            table_member,
            cell_textcolor,
            cell_highlight,
            row_textcolor,
            row_highlight,
            cell_formula,
            merge_parent_default: self.merge_parent_default,
            coord_row_offset: self.coord_row_offset + r1,
            coord_col_offset: self.coord_col_offset + c1,
        })
    }

    /// Vertical concatenation: self on top, other on bottom.
    /// Accepts CellGrid or CellGridView.
    fn vstack(&self, py: Python<'_>, other: &Bound<'_, PyAny>) -> PyResult<Self> {
        if let Ok(cg) = other.extract::<PyRef<CellGrid>>() {
            return self.vstack_impl(&cg);
        }
        if let Ok(cv) = other.extract::<PyRef<CellGridView>>() {
            let other_grid = cv.to_grid(py)?;
            return self.vstack_impl(&other_grid);
        }
        Err(PyTypeError::new_err("vstack requires CellGrid or CellGridView"))
    }

    /// Horizontal concatenation: self on left, other on right.
    /// Accepts CellGrid or CellGridView.
    fn hstack(&self, py: Python<'_>, other: &Bound<'_, PyAny>) -> PyResult<Self> {
        if let Ok(cg) = other.extract::<PyRef<CellGrid>>() {
            return self.hstack_impl(&cg);
        }
        if let Ok(cv) = other.extract::<PyRef<CellGridView>>() {
            let other_grid = cv.to_grid(py)?;
            return self.hstack_impl(&other_grid);
        }
        Err(PyTypeError::new_err("hstack requires CellGrid or CellGridView"))
    }

    /// Copy cells from source into self using a boolean mask.
    /// mask is a 2D numpy bool array matching the dimensions of the copy region.
    fn masked_copy_from(
        &mut self, _py: Python<'_>,
        source: &CellGrid,
        mask: &Bound<'_, PyAny>,
        src_row_offset: usize,
        src_col_offset: usize,
    ) -> PyResult<()> {
        let mask_shape: (usize, usize) = mask.getattr("shape")?.extract()?;
        let (mask_rows, mask_cols) = mask_shape;

        // Set coord offsets after validation so we don't mutate on error
        self.coord_row_offset = source.coord_row_offset + src_row_offset;
        self.coord_col_offset = source.coord_col_offset + src_col_offset;

        for r in 0..mask_rows.min(self.rows) {
            for c in 0..mask_cols.min(self.cols) {
                let mask_val: bool = mask.get_item((r, c))?.extract()?;
                if !mask_val {
                    continue;
                }
                let src_r = r + src_row_offset;
                let src_c = c + src_col_offset;
                if src_r >= source.rows || src_c >= source.cols {
                    continue;
                }
                let dst_idx = r * self.cols + c;
                let src_idx = src_r * source.cols + src_c;

                self.raw_values[dst_idx] = source.raw_values[src_idx].clone();
                self.formatted_values[dst_idx] = source.formatted_values[src_idx].clone();
                self.header[dst_idx] = source.header[src_idx];
                self.table_member[dst_idx] = source.table_member[src_idx];
                self.cell_textcolor[dst_idx] = source.cell_textcolor[src_idx].clone();
                self.cell_highlight[dst_idx] = source.cell_highlight[src_idx].clone();
                self.row_textcolor[dst_idx] = source.row_textcolor[src_idx].clone();
                self.row_highlight[dst_idx] = source.row_highlight[src_idx].clone();

                if let Some(ref src_styles) = source.styles {
                    if let Some(ref mut dst_styles) = self.styles {
                        dst_styles[dst_idx] = src_styles[src_idx].clone();
                    }
                }

                // Copy merge info — only if parent maps to valid destination coordinates.
                // Always clear stale entries when source has no merge or parent is out-of-bounds.
                if let Some(&(pr, pc)) = source.merge_map.get(&(src_r, src_c)) {
                    let new_pr = pr - src_row_offset as i32;
                    let new_pc = pc - src_col_offset as i32;
                    if new_pr >= 0 && new_pc >= 0
                        && (new_pr as usize) < self.rows && (new_pc as usize) < self.cols
                    {
                        self.merge_map.insert((r, c), (new_pr, new_pc));
                    } else {
                        self.merge_map.remove(&(r, c));
                    }
                } else {
                    self.merge_map.remove(&(r, c));
                }

                // Copy formula — clear stale entries when source has no formula.
                if let Some(f) = source.cell_formula.get(&(src_r, src_c)) {
                    self.cell_formula.insert((r, c), f.clone());
                } else {
                    self.cell_formula.remove(&(r, c));
                }
            }
        }
        Ok(())
    }
}

// Internal (non-pymethod) implementations for vstack/hstack.
impl CellGrid {
    pub(crate) fn vstack_impl(&self, other: &CellGrid) -> PyResult<Self> {
        if self.cols != other.cols {
            return Err(PyValueError::new_err(format!(
                "Cannot vstack: column count mismatch ({} vs {})",
                self.cols, other.cols
            )));
        }
        let new_rows = self.rows + other.rows;

        let mut raw_values = Vec::with_capacity(new_rows * self.cols);
        let mut formatted_values = Vec::with_capacity(new_rows * self.cols);
        let mut header = Vec::with_capacity(new_rows * self.cols);
        let mut table_member = Vec::with_capacity(new_rows * self.cols);
        let mut cell_textcolor = Vec::with_capacity(new_rows * self.cols);
        let mut cell_highlight = Vec::with_capacity(new_rows * self.cols);
        let mut row_textcolor = Vec::with_capacity(new_rows * self.cols);
        let mut row_highlight = Vec::with_capacity(new_rows * self.cols);

        raw_values.extend_from_slice(&self.raw_values);
        formatted_values.extend_from_slice(&self.formatted_values);
        header.extend_from_slice(&self.header);
        table_member.extend_from_slice(&self.table_member);
        cell_textcolor.extend_from_slice(&self.cell_textcolor);
        cell_highlight.extend_from_slice(&self.cell_highlight);
        row_textcolor.extend_from_slice(&self.row_textcolor);
        row_highlight.extend_from_slice(&self.row_highlight);

        raw_values.extend_from_slice(&other.raw_values);
        formatted_values.extend_from_slice(&other.formatted_values);
        header.extend_from_slice(&other.header);
        table_member.extend_from_slice(&other.table_member);
        cell_textcolor.extend_from_slice(&other.cell_textcolor);
        cell_highlight.extend_from_slice(&other.cell_highlight);
        row_textcolor.extend_from_slice(&other.row_textcolor);
        row_highlight.extend_from_slice(&other.row_highlight);

        let mut merge_map = self.merge_map.clone();
        for (&(r, c), &(pr, pc)) in &other.merge_map {
            merge_map.insert((r + self.rows, c), (pr + self.rows as i32, pc));
        }

        let mut cell_formula = self.cell_formula.clone();
        for (&(r, c), f) in &other.cell_formula {
            cell_formula.insert((r + self.rows, c), f.clone());
        }

        let styles = match (&self.styles, &other.styles) {
            (Some(s1), Some(s2)) => {
                let mut combined = s1.clone();
                combined.extend_from_slice(s2);
                Some(combined)
            }
            _ => None,
        };

        Ok(CellGrid {
            rows: new_rows, cols: self.cols,
            raw_values, formatted_values, styles, merge_map,
            header, table_member, cell_textcolor, cell_highlight,
            row_textcolor, row_highlight, cell_formula,
            merge_parent_default: self.merge_parent_default,
            coord_row_offset: self.coord_row_offset,
            coord_col_offset: self.coord_col_offset,
        })
    }

    pub(crate) fn hstack_impl(&self, other: &CellGrid) -> PyResult<Self> {
        if self.rows != other.rows {
            return Err(PyValueError::new_err(format!(
                "Cannot hstack: row count mismatch ({} vs {})",
                self.rows, other.rows
            )));
        }
        let new_cols = self.cols + other.cols;
        let total = self.rows * new_cols;

        let mut raw_values = Vec::with_capacity(total);
        let mut formatted_values = Vec::with_capacity(total);
        let mut header = Vec::with_capacity(total);
        let mut table_member = Vec::with_capacity(total);
        let mut cell_textcolor = Vec::with_capacity(total);
        let mut cell_highlight = Vec::with_capacity(total);
        let mut row_textcolor = Vec::with_capacity(total);
        let mut row_highlight = Vec::with_capacity(total);

        for r in 0..self.rows {
            let self_start = r * self.cols;
            raw_values.extend_from_slice(&self.raw_values[self_start..self_start + self.cols]);
            formatted_values.extend_from_slice(&self.formatted_values[self_start..self_start + self.cols]);
            header.extend_from_slice(&self.header[self_start..self_start + self.cols]);
            table_member.extend_from_slice(&self.table_member[self_start..self_start + self.cols]);
            cell_textcolor.extend_from_slice(&self.cell_textcolor[self_start..self_start + self.cols]);
            cell_highlight.extend_from_slice(&self.cell_highlight[self_start..self_start + self.cols]);
            row_textcolor.extend_from_slice(&self.row_textcolor[self_start..self_start + self.cols]);
            row_highlight.extend_from_slice(&self.row_highlight[self_start..self_start + self.cols]);

            let other_start = r * other.cols;
            raw_values.extend_from_slice(&other.raw_values[other_start..other_start + other.cols]);
            formatted_values.extend_from_slice(&other.formatted_values[other_start..other_start + other.cols]);
            header.extend_from_slice(&other.header[other_start..other_start + other.cols]);
            table_member.extend_from_slice(&other.table_member[other_start..other_start + other.cols]);
            cell_textcolor.extend_from_slice(&other.cell_textcolor[other_start..other_start + other.cols]);
            cell_highlight.extend_from_slice(&other.cell_highlight[other_start..other_start + other.cols]);
            row_textcolor.extend_from_slice(&other.row_textcolor[other_start..other_start + other.cols]);
            row_highlight.extend_from_slice(&other.row_highlight[other_start..other_start + other.cols]);
        }

        let mut merge_map = self.merge_map.clone();
        for (&(r, c), &(pr, pc)) in &other.merge_map {
            merge_map.insert((r, c + self.cols), (pr, pc + self.cols as i32));
        }

        let mut cell_formula = self.cell_formula.clone();
        for (&(r, c), f) in &other.cell_formula {
            cell_formula.insert((r, c + self.cols), f.clone());
        }

        let styles = match (&self.styles, &other.styles) {
            (Some(s1), Some(s2)) => {
                let mut combined = Vec::with_capacity(total);
                for r in 0..self.rows {
                    let self_start = r * self.cols;
                    combined.extend_from_slice(&s1[self_start..self_start + self.cols]);
                    let other_start = r * other.cols;
                    combined.extend_from_slice(&s2[other_start..other_start + other.cols]);
                }
                Some(combined)
            }
            _ => None,
        };

        Ok(CellGrid {
            rows: self.rows, cols: new_cols,
            raw_values, formatted_values, styles, merge_map,
            header, table_member, cell_textcolor, cell_highlight,
            row_textcolor, row_highlight, cell_formula,
            merge_parent_default: self.merge_parent_default,
            coord_row_offset: self.coord_row_offset,
            coord_col_offset: self.coord_col_offset,
        })
    }
}

/// Lightweight proxy for accessing a single cell's fields.
/// Supports both cell.field and cell["field"] access.
#[pyclass]
pub struct CellProxy {
    grid: Py<CellGrid>,
    row: usize,
    col: usize,
}

#[pymethods]
impl CellProxy {
    fn __getitem__(&self, py: Python<'_>, key: &str) -> PyResult<PyObject> {
        let grid = self.grid.borrow(py);
        grid.cell_field(py, self.row, self.col, key)
    }

    #[getter]
    fn value(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "value")
    }

    #[getter]
    fn font_bold(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "font_bold")
    }

    #[getter]
    fn font_size(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "font_size")
    }

    #[getter]
    fn is_merged(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "is_merged")
    }

    #[getter]
    fn merge_parent(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "merge_parent")
    }

    #[getter]
    fn coord(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "coord")
    }

    #[getter]
    fn header(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "header")
    }

    #[getter]
    fn table_member(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "table_member")
    }

    #[getter]
    fn number_format(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "number_format")
    }

    #[getter]
    fn cell_textcolor(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "cell_textcolor")
    }

    #[getter]
    fn cell_highlight(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "cell_highlight")
    }

    #[getter]
    fn cell_formula(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "cell_formula")
    }

    #[getter]
    fn bg_color(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "bg_color")
    }

    #[getter]
    fn row_textcolor(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "row_textcolor")
    }

    #[getter]
    fn row_highlight(&self, py: Python<'_>) -> PyResult<PyObject> {
        self.__getitem__(py, "row_highlight")
    }
}

/// Sub-grid view into a CellGrid (for slicing operations).
#[pyclass]
pub struct CellGridView {
    grid: Py<CellGrid>,
    row_start: usize,
    row_end: usize,
    col_start: usize,
    col_end: usize,
}

#[pymethods]
impl CellGridView {
    #[getter]
    fn shape(&self) -> (usize, usize) {
        (self.row_end - self.row_start, self.col_end - self.col_start)
    }

    /// Iterate: if single row, yield CellProxy per column.
    /// Otherwise, yield 1-row CellGridView per row.
    fn __iter__(&self, py: Python<'_>) -> PyResult<PyObject> {
        let view_rows = self.row_end - self.row_start;
        let view_cols = self.col_end - self.col_start;
        let mut items: Vec<PyObject> = Vec::with_capacity(
            if view_rows == 1 { view_cols } else { view_rows }
        );
        if view_rows == 1 {
            // Single row: yield CellProxy per column
            for c in self.col_start..self.col_end {
                let proxy = CellProxy {
                    grid: self.grid.clone_ref(py),
                    row: self.row_start,
                    col: c,
                };
                items.push(proxy.into_pyobject(py)?.into_any().unbind());
            }
        } else {
            // Multiple rows: yield 1-row views
            for r in self.row_start..self.row_end {
                let view = CellGridView {
                    grid: self.grid.clone_ref(py),
                    row_start: r,
                    row_end: r + 1,
                    col_start: self.col_start,
                    col_end: self.col_end,
                };
                items.push(view.into_pyobject(py)?.into_any().unbind());
            }
        }
        Ok(PyList::new(py, &items)?.into_any().unbind().call_method0(py, "__iter__")?)
    }

    #[getter]
    fn size(&self) -> usize {
        (self.row_end - self.row_start) * (self.col_end - self.col_start)
    }

    fn __len__(&self) -> usize {
        self.row_end - self.row_start
    }

    /// Materialize this view into an independent CellGrid copy.
    fn to_grid(&self, py: Python<'_>) -> PyResult<CellGrid> {
        let grid = self.grid.borrow(py);
        grid.slice_copy(self.row_start, self.row_end, self.col_start, self.col_end)
    }

    /// Copy (alias for to_grid).
    fn copy(&self, py: Python<'_>) -> PyResult<CellGrid> {
        self.to_grid(py)
    }

    /// Vertical concatenation: materializes view, then vstacks.
    fn vstack(&self, py: Python<'_>, other: &Bound<'_, PyAny>) -> PyResult<CellGrid> {
        let self_grid = self.to_grid(py)?;
        if let Ok(cg) = other.extract::<PyRef<CellGrid>>() {
            return self_grid.vstack_impl(&cg);
        }
        if let Ok(cv) = other.extract::<PyRef<CellGridView>>() {
            let other_grid = cv.to_grid(py)?;
            return self_grid.vstack_impl(&other_grid);
        }
        Err(PyTypeError::new_err("vstack requires CellGrid or CellGridView"))
    }

    /// Horizontal concatenation: materializes view, then hstacks.
    fn hstack(&self, py: Python<'_>, other: &Bound<'_, PyAny>) -> PyResult<CellGrid> {
        let self_grid = self.to_grid(py)?;
        if let Ok(cg) = other.extract::<PyRef<CellGrid>>() {
            return self_grid.hstack_impl(&cg);
        }
        if let Ok(cv) = other.extract::<PyRef<CellGridView>>() {
            let other_grid = cv.to_grid(py)?;
            return self_grid.hstack_impl(&other_grid);
        }
        Err(PyTypeError::new_err("hstack requires CellGrid or CellGridView"))
    }

    /// Dispatch __getitem__:
    ///  - view[r, c] → CellProxy (offset into parent grid)
    ///  - view["field"] → numpy 2D array for this sub-region
    ///  - view[slice, slice] → nested CellGridView
    fn __getitem__(&self, py: Python<'_>, key: &Bound<'_, PyAny>) -> PyResult<PyObject> {
        // String key -> field array for this region
        if let Ok(field) = key.extract::<String>() {
            let grid = self.grid.borrow(py);
            return grid.field_to_numpy_view(
                py, &field,
                self.row_start, self.row_end,
                self.col_start, self.col_end,
            );
        }

        let view_rows = self.row_end - self.row_start;
        let view_cols = self.col_end - self.col_start;

        // Tuple key
        if let Ok(tuple) = key.downcast::<PyTuple>() {
            if tuple.len() == 2 {
                let item0 = tuple.get_item(0)?;
                let item1 = tuple.get_item(1)?;

                // (int, int) -> CellProxy
                if let (Ok(r), Ok(c)) = (item0.extract::<usize>(), item1.extract::<usize>()) {
                    let abs_r = self.row_start + r;
                    let abs_c = self.col_start + c;
                    if abs_r >= self.row_end || abs_c >= self.col_end {
                        return Err(PyIndexError::new_err("Index out of bounds"));
                    }
                    let proxy = CellProxy {
                        grid: self.grid.clone_ref(py),
                        row: abs_r,
                        col: abs_c,
                    };
                    return Ok(proxy.into_pyobject(py)?.into_any().unbind());
                }

                // (slice, slice) -> nested view
                let (r_start, r_end) = if let Ok(s) = item0.downcast::<PySlice>() {
                    parse_slice(py, s, view_rows)?
                } else if let Ok(r) = item0.extract::<usize>() {
                    (r, r + 1)
                } else {
                    return Err(PyTypeError::new_err("Invalid row index type"));
                };

                let (c_start, c_end) = if let Ok(s) = item1.downcast::<PySlice>() {
                    parse_slice(py, s, view_cols)?
                } else if let Ok(c) = item1.extract::<usize>() {
                    (c, c + 1)
                } else {
                    return Err(PyTypeError::new_err("Invalid column index type"));
                };

                let view = CellGridView {
                    grid: self.grid.clone_ref(py),
                    row_start: self.row_start + r_start,
                    row_end: self.row_start + r_end,
                    col_start: self.col_start + c_start,
                    col_end: self.col_start + c_end,
                };
                return Ok(view.into_pyobject(py)?.into_any().unbind());
            }
        }

        // Single slice -> row range
        if let Ok(s) = key.downcast::<PySlice>() {
            let (r_start, r_end) = parse_slice(py, s, view_rows)?;
            let view = CellGridView {
                grid: self.grid.clone_ref(py),
                row_start: self.row_start + r_start,
                row_end: self.row_start + r_end,
                col_start: self.col_start,
                col_end: self.col_end,
            };
            return Ok(view.into_pyobject(py)?.into_any().unbind());
        }

        // Single int -> single row view
        if let Ok(r) = key.extract::<usize>() {
            if r >= view_rows {
                return Err(PyIndexError::new_err("Row index out of bounds"));
            }
            let view = CellGridView {
                grid: self.grid.clone_ref(py),
                row_start: self.row_start + r,
                row_end: self.row_start + r + 1,
                col_start: self.col_start,
                col_end: self.col_end,
            };
            return Ok(view.into_pyobject(py)?.into_any().unbind());
        }

        Err(PyTypeError::new_err("Invalid index type for CellGridView"))
    }
}
