"""Generate test fixture: tests/data/grid_test.xlsx

Creates a small xlsx with known values, styles, merges, and formulas
for testing CellGrid, get_sheet_styles, get_sheet_layout, get_sheet_bounds.

Run once: python tests/create_test_fixture.py
"""

import openpyxl
from openpyxl.styles import Font, PatternFill, Border, Side, numbers
from pathlib import Path

wb = openpyxl.Workbook()

# ── Sheet1: "Values" — various cell types ──
ws = wb.active
ws.title = "Values"
ws["A1"] = "Hello"
ws["B1"] = 42
ws["C1"] = 3.14
ws["D1"] = True
ws["A2"] = "World"
ws["B2"] = -1
ws["C2"] = 0.0
ws["D2"] = False
ws["A3"] = ""  # empty string
# B3, C3, D3 left empty (truly empty)
ws["A4"] = "Last row"

# ── Sheet2: "Styles" — font, fill, number format ──
ws2 = wb.create_sheet("Styles")
ws2["A1"] = "Bold"
ws2["A1"].font = Font(bold=True, size=14, color="FF0000")
ws2["B1"] = "Normal"
ws2["B1"].font = Font(size=11)
ws2["A2"] = 1234.5678
ws2["A2"].number_format = "#,##0.00"
ws2["B2"] = 0.75
ws2["B2"].number_format = "0%"
ws2["A3"] = "Highlighted"
ws2["A3"].fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
ws2["B3"] = "Bordered"
thin = Side(style="thin")
ws2["B3"].border = Border(top=thin, bottom=thin, left=thin, right=thin)
ws2["A4"] = "Underline"
ws2["A4"].font = Font(underline="single")

# ── Sheet3: "Merges" — merged cell ranges ──
ws3 = wb.create_sheet("Merges")
ws3["A1"] = "Merged across"
ws3.merge_cells("A1:C1")  # A1 is parent, B1 and C1 are children
ws3["A2"] = "Merged down"
ws3.merge_cells("A2:A4")  # A2 is parent, A3 and A4 are children
ws3["B2"] = "Solo B2"
ws3["C2"] = "Solo C2"
ws3["D1"] = "Not merged"

# ── Sheet4: "Layout" — custom row heights and column widths ──
ws4 = wb.create_sheet("Layout")
ws4["A1"] = "Tall row"
ws4.row_dimensions[1].height = 40
ws4["A2"] = "Normal row"
ws4["B1"] = "Wide col"
ws4.column_dimensions["B"].width = 25
ws4.column_dimensions["A"].width = 15
ws4["A3"] = "Hidden row"
ws4.row_dimensions[3].hidden = True

# ── Sheet5: "Empty" — completely empty sheet ──
wb.create_sheet("Empty")

# Save
out = Path(__file__).parent / "data" / "grid_test.xlsx"
wb.save(out)

# Patch: openpyxl writes <b val="1"/> but calamine only recognizes <b/>.
# Both are equivalent per OOXML spec. Rewrite to <b/> for compatibility.
import zipfile, tempfile, shutil

tmp = out.with_suffix(".tmp")
with zipfile.ZipFile(out, "r") as zin, zipfile.ZipFile(tmp, "w") as zout:
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename == "xl/styles.xml":
            data = data.replace(b'<b val="1"/>', b"<b/>")
            data = data.replace(b'<b val="1" />', b"<b/>")
        zout.writestr(item, data)
shutil.move(str(tmp), str(out))

print(f"Created {out}")
