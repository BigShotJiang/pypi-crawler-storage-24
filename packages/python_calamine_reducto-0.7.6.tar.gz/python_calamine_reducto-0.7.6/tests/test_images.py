"""Tests for native image, formula, and data validation extraction via calamine bindings.

Uses pre-built xlsx fixtures in tests/data/ (created with openpyxl).
"""

from pathlib import Path

import pytest

from python_calamine import CalamineWorkbook

DATA = Path(__file__).parent / "data"
IMAGE_TEST = DATA / "image_test.xlsx"
MULTI_IMAGE_TEST = DATA / "multi_image_test.xlsx"
FORMULA_TEST = DATA / "formula_test.xlsx"
DROPDOWN_TEST = DATA / "dropdown_test.xlsx"


class TestGetSheetImages:
    def test_returns_image_data(self) -> None:
        """get_sheet_images should return image bytes, extension, and anchor."""
        wb = CalamineWorkbook.from_path(IMAGE_TEST)
        images = wb.get_sheet_images("Images")

        assert len(images) == 1
        img_bytes, ext, row, col = images[0]
        assert isinstance(img_bytes, bytes)
        assert len(img_bytes) > 0
        assert ext.lower() == "png"
        assert row == 0  # C1 -> row 0
        assert col == 2  # C1 -> col 2

    def test_image_bytes_are_valid_png(self) -> None:
        """Returned bytes should be a valid PNG image."""
        from io import BytesIO

        pytest.importorskip("PIL")
        from PIL import Image

        wb = CalamineWorkbook.from_path(IMAGE_TEST)
        images = wb.get_sheet_images("Images")

        img_bytes = images[0][0]
        img = Image.open(BytesIO(img_bytes))
        assert img.size == (40, 30)

    def test_multiple_images(self) -> None:
        """Should extract all images from a sheet."""
        wb = CalamineWorkbook.from_path(MULTI_IMAGE_TEST)
        images = wb.get_sheet_images("MultiImage")

        assert len(images) == 2
        anchors = {(img[2], img[3]) for img in images}
        assert (0, 0) in anchors  # A1
        assert (2, 1) in anchors  # B3

    def test_no_images_returns_empty(self) -> None:
        """Sheet without images should return empty list."""
        wb = CalamineWorkbook.from_path(FORMULA_TEST)
        images = wb.get_sheet_images("Formulas")
        assert images == []


class TestGetSheetFormulas:
    def test_returns_formulas(self) -> None:
        """get_sheet_formulas should return formula strings with positions."""
        wb = CalamineWorkbook.from_path(FORMULA_TEST)
        formulas = wb.get_sheet_formulas("Formulas")

        assert len(formulas) >= 2
        formula_map = {(r, c): f for r, c, f in formulas}
        assert (0, 1) in formula_map  # B1
        assert "SUM" in formula_map[(0, 1)]
        assert (1, 1) in formula_map  # B2
        assert "A1" in formula_map[(1, 1)]

    def test_no_formulas_returns_empty(self) -> None:
        """Sheet without formulas should return empty list."""
        wb = CalamineWorkbook.from_path(IMAGE_TEST)
        formulas = wb.get_sheet_formulas("Images")
        assert formulas == []


class TestGetSheetDataValidations:
    def test_returns_validations(self) -> None:
        """get_sheet_data_validations should return validation dicts."""
        wb = CalamineWorkbook.from_path(DROPDOWN_TEST)
        dvs = wb.get_sheet_data_validations("Dropdowns")

        assert len(dvs) == 2
        types = {dv["type"] for dv in dvs}
        assert types == {"list"}

    def test_validation_fields(self) -> None:
        """Each validation dict should have type, sqref, formula1, formula2, allow_blank."""
        wb = CalamineWorkbook.from_path(DROPDOWN_TEST)
        dvs = wb.get_sheet_data_validations("Dropdowns")

        dv = dvs[0]
        assert "type" in dv
        assert "sqref" in dv
        assert "formula1" in dv
        assert "formula2" in dv
        assert "allow_blank" in dv

    def test_dropdown_options_parsed(self) -> None:
        """formula1 should contain the quoted comma-separated options string."""
        wb = CalamineWorkbook.from_path(DROPDOWN_TEST)
        dvs = wb.get_sheet_data_validations("Dropdowns")

        formulas = {dv["formula1"] for dv in dvs}
        assert '"Active,Inactive,Pending"' in formulas
        assert '"High,Medium,Low"' in formulas

    def test_sqref_ranges(self) -> None:
        """sqref should contain cell range strings."""
        wb = CalamineWorkbook.from_path(DROPDOWN_TEST)
        dvs = wb.get_sheet_data_validations("Dropdowns")

        sqrefs = {dv["sqref"] for dv in dvs}
        assert "A2:A5" in sqrefs
        assert "B2:B3" in sqrefs

    def test_no_validations_returns_empty(self) -> None:
        """Sheet without validations should return empty list."""
        wb = CalamineWorkbook.from_path(IMAGE_TEST)
        dvs = wb.get_sheet_data_validations("Images")
        assert dvs == []
