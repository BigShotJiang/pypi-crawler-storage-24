"""Tests for CellGrid, CellProxy, CellGridView, and workbook style/layout/bounds bindings.

Tests our Reducto additions on top of upstream python-calamine:
  - CellGrid: creation, indexing, slicing, field access, vstack, hstack, copy, formatting
  - CellProxy: single-cell attribute and dict access
  - CellGridView: sub-grid slicing, iteration, to_grid materialization
  - CalamineWorkbook: get_sheet_grid, get_sheet_styles, get_sheet_layout, get_sheet_bounds

Uses tests/data/grid_test.xlsx as the fixture (created by create_test_fixture.py).
"""

from pathlib import Path

import numpy as np
import pytest

from python_calamine import CalamineWorkbook, CellGrid, CellGridView, CellProxy

DATA = Path(__file__).parent / "data"
GRID_TEST = DATA / "grid_test.xlsx"
RICHTEXT_TEST = DATA / "richtext_test.xlsx"
EMPTY_MERGE_TEST = DATA / "empty_merge_test.xlsx"


# ─── Fixtures ───


@pytest.fixture(scope="module")
def wb():
    return CalamineWorkbook.from_path(GRID_TEST)


@pytest.fixture(scope="module")
def wb_fresh():
    """A separate workbook instance for tests that mutate state."""
    return CalamineWorkbook.from_path(GRID_TEST)


# ─── get_sheet_bounds ───


class TestGetSheetBounds:
    def test_values_sheet_bounds(self, wb):
        rows, cols = wb.get_sheet_bounds("Values")
        # A1:D2 has data, A4 has "Last row" -> 4 rows, 4 cols
        assert rows == 4
        assert cols == 4

    def test_styles_sheet_bounds(self, wb):
        rows, cols = wb.get_sheet_bounds("Styles")
        assert rows == 4
        assert cols == 2

    def test_merges_sheet_bounds(self, wb):
        rows, cols = wb.get_sheet_bounds("Merges")
        # D1 has "Not merged", A2:A4 merge, B2/C2 have data
        assert rows >= 2
        assert cols == 4

    def test_empty_sheet_bounds(self, wb):
        rows, cols = wb.get_sheet_bounds("Empty")
        assert rows == 0
        assert cols == 0


# ─── get_sheet_grid ───


class TestGetSheetGrid:
    def test_grid_shape(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        assert grid.shape == (4, 4)
        assert grid.size == 16
        assert len(grid) == 4

    def test_grid_raw_values(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        # Apply raw as formatted to make values accessible
        grid.apply_raw_as_formatted()
        cell = grid[0, 0]
        assert cell.value == "Hello"

    def test_grid_numeric_values(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        cell = grid[0, 1]
        assert cell.value == "42"

    def test_grid_float_values(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        cell = grid[0, 2]
        assert cell.value == "3.14"

    def test_grid_bool_values(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        cell = grid[0, 3]
        assert cell.value == "TRUE"

    def test_grid_empty_cell(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        # B3 is empty
        cell = grid[2, 1]
        assert cell.value is None

    def test_grid_auto_bounds(self, wb):
        """get_sheet_grid with 0,0 should auto-compute bounds."""
        grid = wb.get_sheet_grid("Values", 0, 0)
        assert grid.shape[0] == 4
        assert grid.shape[1] == 4

    def test_grid_with_styles(self, wb):
        grid = wb.get_sheet_grid("Styles", 4, 2, include_styles=True)
        # A1 has size 14, red font color
        cell = grid[0, 0]
        assert cell.font_size == pytest.approx(14.0, abs=0.1)

    def test_grid_without_styles(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4, include_styles=False)
        # Without styles, font_bold defaults to False
        cell = grid[0, 0]
        assert cell.font_bold is False
        assert cell.font_size == pytest.approx(11.0, abs=0.1)

    def test_grid_number_format(self, wb):
        grid = wb.get_sheet_grid("Styles", 4, 2, include_styles=True)
        # A2 has "#,##0.00"
        cell = grid[1, 0]
        assert cell.number_format == "#,##0.00"

    def test_grid_percent_format(self, wb):
        grid = wb.get_sheet_grid("Styles", 4, 2, include_styles=True)
        # B2 has "0%"
        cell = grid[1, 1]
        assert cell.number_format == "0%"

    def test_grid_empty_sheet(self, wb):
        grid = wb.get_sheet_grid("Empty", 0, 0)
        assert grid.shape == (0, 0)
        assert grid.size == 0


# ─── get_sheet_styles ───


class TestGetSheetStyles:
    def test_returns_list(self, wb):
        styles = wb.get_sheet_styles("Styles")
        assert isinstance(styles, list)
        assert len(styles) > 0

    def test_style_tuple_format(self, wb):
        styles = wb.get_sheet_styles("Styles")
        # Each entry is (row, col, style_dict)
        entry = styles[0]
        assert len(entry) == 3
        row, col, style_dict = entry
        assert isinstance(row, int)
        assert isinstance(col, int)
        assert isinstance(style_dict, dict)

    def test_bold_font_detected(self, wb):
        styles = wb.get_sheet_styles("Styles")
        # Find A1 (row 0, col 0) — should be bold
        a1_styles = [s for s in styles if s[0] == 0 and s[1] == 0]
        assert len(a1_styles) > 0
        style_dict = a1_styles[0][2]
        assert style_dict.get("font_bold") is True

    def test_font_color(self, wb):
        styles = wb.get_sheet_styles("Styles")
        a1_styles = [s for s in styles if s[0] == 0 and s[1] == 0]
        assert len(a1_styles) > 0
        style_dict = a1_styles[0][2]
        assert style_dict.get("font_color") == "#FF0000"

    def test_fill_color(self, wb):
        styles = wb.get_sheet_styles("Styles")
        # A3 (row 2, col 0) has yellow fill
        a3_styles = [s for s in styles if s[0] == 2 and s[1] == 0]
        assert len(a3_styles) > 0
        style_dict = a3_styles[0][2]
        assert style_dict.get("fill_pattern") == "solid"
        assert style_dict.get("fill_fg_color") == "#FFFF00"

    def test_number_format(self, wb):
        styles = wb.get_sheet_styles("Styles")
        # A2 has "#,##0.00"
        a2_styles = [s for s in styles if s[0] == 1 and s[1] == 0]
        assert len(a2_styles) > 0
        style_dict = a2_styles[0][2]
        assert style_dict.get("number_format") == "#,##0.00"

    def test_border_styles(self, wb):
        styles = wb.get_sheet_styles("Styles")
        # B3 (row 2, col 1) has thin borders
        b3_styles = [s for s in styles if s[0] == 2 and s[1] == 1]
        assert len(b3_styles) > 0
        style_dict = b3_styles[0][2]
        assert style_dict.get("border_top") == "thin"
        assert style_dict.get("border_bottom") == "thin"


# ─── get_sheet_layout ───


class TestGetSheetLayout:
    def test_returns_dict(self, wb):
        layout = wb.get_sheet_layout("Layout")
        assert isinstance(layout, dict)
        assert "column_widths" in layout
        assert "row_heights" in layout
        assert "default_column_width" in layout
        assert "default_row_height" in layout

    def test_custom_row_height(self, wb):
        layout = wb.get_sheet_layout("Layout")
        # Row 1 (0-indexed: row 0) has height 40
        row_heights = {r[0]: r[1] for r in layout["row_heights"]}
        assert 0 in row_heights
        assert row_heights[0] == pytest.approx(40.0, abs=1.0)

    def test_custom_column_width(self, wb):
        layout = wb.get_sheet_layout("Layout")
        col_widths = {c[0]: c[1] for c in layout["column_widths"]}
        # Column B (index 1) has width 25
        assert 1 in col_widths
        assert col_widths[1] == pytest.approx(25.0, abs=1.0)

    def test_hidden_row(self, wb):
        layout = wb.get_sheet_layout("Layout")
        # Row 3 (0-indexed: row 2) is hidden
        hidden_rows = {r[0]: r[2] for r in layout["row_heights"]}
        assert 2 in hidden_rows
        assert hidden_rows[2] is True

    def test_default_values(self, wb):
        layout = wb.get_sheet_layout("Layout")
        assert layout["default_row_height"] is not None
        # default_column_width may be None if not explicitly set in the xlsx


# ─── CellGrid.empty() ───


class TestCellGridEmpty:
    def test_empty_creation(self):
        grid = CellGrid.empty(3, 4)
        assert grid.shape == (3, 4)
        assert grid.size == 12
        assert len(grid) == 3

    def test_empty_values_are_none(self):
        grid = CellGrid.empty(2, 2)
        cell = grid[0, 0]
        assert cell.value is None

    def test_empty_defaults(self):
        grid = CellGrid.empty(2, 2)
        cell = grid[0, 0]
        assert cell.font_bold is False
        assert cell.font_size == pytest.approx(11.0)
        assert cell.is_merged is False
        assert cell.header is False
        assert cell.table_member is False
        assert cell.number_format == "General"

    def test_empty_field_names(self):
        grid = CellGrid.empty(1, 1)
        names = grid.field_names
        assert "value" in names
        assert "font_bold" in names
        assert "is_merged" in names
        assert "header" in names


# ─── CellProxy ───


class TestCellProxy:
    def test_getitem_access(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        cell = grid[0, 0]
        assert isinstance(cell, CellProxy)
        assert cell["value"] == "Hello"

    def test_attribute_access(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        cell = grid[0, 0]
        assert cell.value == "Hello"

    def test_coord(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        cell = grid[1, 2]  # row 1, col 2 -> 1-based: (2, 3)
        coord = cell.coord
        assert coord[0] == 2
        assert coord[1] == 3

    def test_index_out_of_bounds(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        with pytest.raises(IndexError):
            grid[10, 10]

    def test_unknown_field(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        cell = grid[0, 0]
        with pytest.raises(KeyError):
            cell["nonexistent_field"]


# ─── CellGridView ───


class TestCellGridView:
    def test_slice_creates_view(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        view = grid[0:2, 0:2]
        assert isinstance(view, CellGridView)
        assert view.shape == (2, 2)

    def test_view_field_access(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        view = grid[0:2, 0:2]
        values = view["value"]
        assert values.shape == (2, 2)
        assert values[0, 0] == "Hello"

    def test_view_cell_proxy(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        view = grid[0:2, 0:2]
        cell = view[0, 0]
        assert isinstance(cell, CellProxy)
        assert cell.value == "Hello"

    def test_view_iteration_single_row(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        view = grid[0:1, 0:4]  # single row
        cells = list(view)
        assert len(cells) == 4
        assert all(isinstance(c, CellProxy) for c in cells)

    def test_view_iteration_multi_row(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        view = grid[0:2, 0:4]  # two rows
        rows = list(view)
        assert len(rows) == 2
        assert all(isinstance(r, CellGridView) for r in rows)

    def test_view_to_grid(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        view = grid[0:2, 0:2]
        materialized = view.to_grid()
        assert isinstance(materialized, CellGrid)
        assert materialized.shape == (2, 2)

    def test_view_copy(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        view = grid[0:2, 0:2]
        copied = view.copy()
        assert isinstance(copied, CellGrid)
        assert copied.shape == (2, 2)

    def test_row_slice(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        view = grid[0:2]  # row slice, all cols
        assert isinstance(view, CellGridView)
        assert view.shape == (2, 4)

    def test_single_row_index(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        view = grid[0]  # single row, all cols
        assert isinstance(view, CellGridView)
        assert view.shape == (1, 4)


# ─── Field arrays (numpy) ───


class TestFieldArrays:
    def test_value_array(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        values = grid["value"]
        assert isinstance(values, np.ndarray)
        assert values.shape == (4, 4)
        assert values[0, 0] == "Hello"

    def test_header_array(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        header = grid["header"]
        assert isinstance(header, np.ndarray)
        assert header.dtype == bool
        assert header.shape == (4, 4)

    def test_is_merged_array(self, wb):
        grid = wb.get_sheet_grid("Merges", 4, 4)
        merged = grid["is_merged"]
        assert isinstance(merged, np.ndarray)
        assert merged.dtype == bool
        # Match openpyxl: is_merged=True only for cells with empty value in merge range
        assert merged[0, 0] is np.False_   # parent with value "Merged across"
        assert merged[0, 1] is np.True_    # child (empty)
        assert merged[0, 2] is np.True_    # child (empty)

    def test_merge_parent_array(self, wb):
        grid = wb.get_sheet_grid("Merges", 4, 4)
        parents = grid["merge_parent"]
        assert parents.shape == (4, 4, 2)
        # A1 has value → merge_parent not set (default 0,0)
        assert parents[0, 0, 0] == 0
        assert parents[0, 0, 1] == 0
        # B1 is empty child → merge_parent = (0,0) which is A1's coords
        assert parents[0, 1, 0] == 0  # parent row
        assert parents[0, 1, 1] == 0  # parent col
        # D1 is not merged — default (0, 0) matching openpyxl numpy zero-init
        assert parents[0, 3, 0] == 0
        assert parents[0, 3, 1] == 0

    def test_coord_array(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        coords = grid["coord"]
        assert coords.shape == (4, 4, 2)
        # Cell at (0, 0) has 1-based coord (1, 1)
        assert coords[0, 0, 0] == 1
        assert coords[0, 0, 1] == 1
        # Cell at (2, 3) has 1-based coord (3, 4)
        assert coords[2, 3, 0] == 3
        assert coords[2, 3, 1] == 4

    def test_font_bold_array(self, wb):
        grid = wb.get_sheet_grid("Styles", 4, 2, include_styles=True)
        bold = grid["font_bold"]
        assert bold.shape == (4, 2)
        assert bold[0, 0] is np.True_   # A1 is bold
        assert bold[0, 1] is np.False_  # B1 is not bold

    def test_font_size_array(self, wb):
        grid = wb.get_sheet_grid("Styles", 4, 2, include_styles=True)
        sizes = grid["font_size"]
        assert sizes.shape == (4, 2)
        assert sizes[0, 0] == pytest.approx(14.0, abs=0.1)  # A1 is 14pt
        assert sizes[0, 1] == pytest.approx(11.0, abs=0.1)  # B1 is 11pt

    def test_number_format_array(self, wb):
        grid = wb.get_sheet_grid("Styles", 4, 2, include_styles=True)
        fmts = grid["number_format"]
        assert fmts.shape == (4, 2)
        assert fmts[1, 0] == "#,##0.00"
        assert fmts[1, 1] == "0%"

    def test_unknown_field_raises(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        with pytest.raises(KeyError):
            grid["not_a_field"]


# ─── Setitem ───


class TestSetItem:
    def test_set_table_member_broadcast(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid["table_member"] = True
        tm = grid["table_member"]
        assert tm.all()
        grid["table_member"] = False
        tm = grid["table_member"]
        assert not tm.any()

    def test_set_header_broadcast(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid["header"] = True
        h = grid["header"]
        assert h.all()

    def test_set_table_member_from_numpy(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        mask = np.zeros((4, 4), dtype=bool)
        mask[0, :] = True
        grid["table_member"] = mask
        tm = grid["table_member"]
        assert tm[0, 0] is np.True_
        assert tm[1, 0] is np.False_


# ─── set_field_range ───


class TestSetFieldRange:
    def test_set_header_range(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid.set_field_range("header", 0, 1, 0, 4, True)
        h = grid["header"]
        assert h[0, 0] is np.True_
        assert h[0, 3] is np.True_
        assert h[1, 0] is np.False_

    def test_set_table_member_range(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid.set_field_range("table_member", 1, 3, 1, 3, True)
        tm = grid["table_member"]
        assert tm[1, 1] is np.True_
        assert tm[2, 2] is np.True_
        assert tm[0, 0] is np.False_

    def test_set_invalid_field_range(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        with pytest.raises(KeyError):
            grid.set_field_range("value", 0, 1, 0, 1, True)


# ─── set_cell_formula ───


class TestSetCellFormula:
    def test_set_and_get_formula(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid.set_cell_formula(0, 0, "=SUM(A1:A4)")
        cell = grid[0, 0]
        assert cell.cell_formula == "=SUM(A1:A4)"

    def test_no_formula_returns_none(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        cell = grid[1, 1]
        assert cell.cell_formula is None


# ─── apply_formatting ───


class TestApplyFormatting:
    def test_apply_formatting_callback(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)

        def formatter(raw_value, number_format):
            if raw_value is None:
                return None
            return f"[{raw_value}]"

        grid.apply_formatting(formatter)
        cell = grid[0, 0]
        assert cell.value == "[Hello]"

    def test_apply_raw_as_formatted(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        cell = grid[0, 0]
        assert cell.value == "Hello"
        cell_num = grid[0, 1]
        assert cell_num.value == "42"


# ─── apply_formatting_rust ───


class TestApplyFormattingRust:
    """Tests for Rust-native SSF formatting (no Python callback)."""

    def test_number_format_comma(self, wb_fresh):
        """Styles sheet A2 = 1234.5678 with format '#,##0.00'."""
        grid = wb_fresh.get_sheet_grid("Styles", 4, 2, include_styles=True)
        grid.apply_formatting_rust()
        cell = grid[1, 0]  # A2
        assert cell.value == "1,234.57"

    def test_percentage_format(self, wb_fresh):
        """Styles sheet B2 = 0.75 with format '0%'."""
        grid = wb_fresh.get_sheet_grid("Styles", 4, 2, include_styles=True)
        grid.apply_formatting_rust()
        cell = grid[1, 1]  # B2
        assert cell.value == "75%"

    def test_string_passthrough(self, wb_fresh):
        """String values with General format pass through unchanged."""
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid.apply_formatting_rust()
        assert grid[0, 0].value == "Hello"
        assert grid[1, 0].value == "World"

    def test_integer_formatting(self, wb_fresh):
        """Integers with General format produce plain strings."""
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid.apply_formatting_rust()
        assert grid[0, 1].value == "42"
        assert grid[1, 1].value == "-1"

    def test_float_formatting(self, wb_fresh):
        """Floats with General format follow Excel display rules."""
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid.apply_formatting_rust()
        assert grid[0, 2].value == "3.14"

    def test_bool_formatting(self, wb_fresh):
        """Booleans produce TRUE/FALSE."""
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid.apply_formatting_rust()
        assert grid[0, 3].value == "TRUE"
        assert grid[1, 3].value == "FALSE"

    def test_empty_cells(self, wb_fresh):
        """Empty cells stay None."""
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid.apply_formatting_rust()
        # B3 is empty
        assert grid[2, 1].value is None

    def test_zero_formatting(self, wb_fresh):
        """Zero with General format produces '0'."""
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)
        grid.apply_formatting_rust()
        assert grid[1, 2].value == "0"

    def test_without_styles(self, wb_fresh):
        """When styles are not included, all cells use 'General' format."""
        grid = wb_fresh.get_sheet_grid("Values", 4, 4)  # no include_styles
        grid.apply_formatting_rust()
        # Should still work — falls back to General format
        assert grid[0, 0].value == "Hello"
        assert grid[0, 1].value == "42"


# ─── apply_color_names ───


class TestApplyColorNames:
    def test_apply_color_names(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Styles", 4, 2, include_styles=True)
        grid.apply_raw_as_formatted()

        def hex_to_name(hex_str):
            colors = {"#FF0000": "red", "#FFFF00": "yellow"}
            return colors.get(hex_str.upper())

        grid.apply_color_names(hex_to_name)
        # A1 has red font
        cell = grid[0, 0]
        assert cell.cell_textcolor == "red"
        # A3 has yellow fill
        cell3 = grid[2, 0]
        assert cell3.cell_highlight == "yellow"


# ─── propagate_merged_values ───


class TestPropagateMergedValues:
    def test_propagate(self, wb_fresh):
        grid = wb_fresh.get_sheet_grid("Merges", 4, 4)
        grid.apply_raw_as_formatted()
        # Before propagation, B1 (merged child) should be empty
        assert grid[0, 1].value is None or grid[0, 1].value == ""
        grid.propagate_merged_values()
        # After propagation, B1 should have parent's value
        assert grid[0, 1].value == "Merged across"


# ─── copy / slice_copy ───


class TestCopy:
    def test_deep_copy(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        copied = grid.copy()
        assert copied.shape == grid.shape
        assert copied[0, 0].value == grid[0, 0].value
        # Modifying copy shouldn't affect original
        copied["header"] = True
        assert grid["header"][0, 0] is np.False_

    def test_slice_copy(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        sliced = grid.slice_copy(0, 2, 0, 2)
        assert sliced.shape == (2, 2)
        assert sliced[0, 0].value == "Hello"

    def test_slice_copy_invalid(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        with pytest.raises(ValueError):
            grid.slice_copy(2, 1, 0, 2)  # r1 > r2


# ─── vstack / hstack ───


class TestStackOperations:
    def test_vstack(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        top = grid.slice_copy(0, 2, 0, 4)
        bottom = grid.slice_copy(2, 4, 0, 4)
        combined = top.vstack(bottom)
        assert combined.shape == (4, 4)

    def test_vstack_col_mismatch(self, wb):
        g1 = CellGrid.empty(2, 3)
        g2 = CellGrid.empty(2, 4)
        with pytest.raises(ValueError):
            g1.vstack(g2)

    def test_hstack(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        left = grid.slice_copy(0, 4, 0, 2)
        right = grid.slice_copy(0, 4, 2, 4)
        combined = left.hstack(right)
        assert combined.shape == (4, 4)

    def test_hstack_row_mismatch(self, wb):
        g1 = CellGrid.empty(2, 3)
        g2 = CellGrid.empty(3, 3)
        with pytest.raises(ValueError):
            g1.hstack(g2)

    def test_vstack_with_view(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        top = grid.slice_copy(0, 2, 0, 4)
        bottom_view = grid[2:4, 0:4]
        combined = top.vstack(bottom_view)
        assert combined.shape == (4, 4)

    def test_hstack_with_view(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        left = grid.slice_copy(0, 4, 0, 2)
        right_view = grid[0:4, 2:4]
        combined = left.hstack(right_view)
        assert combined.shape == (4, 4)


# ─── Merge behavior ───


class TestMergeBehavior:
    def test_all_merge_cells_marked(self, wb):
        grid = wb.get_sheet_grid("Merges", 4, 4)
        # Match openpyxl: is_merged=True only for empty cells in merge range
        assert grid[0, 0].is_merged is False  # parent with value
        assert grid[0, 1].is_merged is True   # child (empty)
        assert grid[0, 2].is_merged is True   # child (empty)

    def test_merge_parent_coords(self, wb):
        grid = wb.get_sheet_grid("Merges", 4, 4)
        # A1 has value → merge_parent default (0,0)
        parent_a1 = grid[0, 0].merge_parent
        assert parent_a1[0] == 0
        assert parent_a1[1] == 0
        # B1, C1 empty children → merge_parent = (0,0) = A1's coords
        for c in (1, 2):
            parent = grid[0, c].merge_parent
            assert parent[0] == 0
            assert parent[1] == 0

    def test_vertical_merge(self, wb):
        grid = wb.get_sheet_grid("Merges", 4, 4)
        # A2:A4 merge — parent A2 has value, children A3/A4 are empty
        assert grid[1, 0].is_merged is False  # parent with value
        assert grid[2, 0].is_merged is True   # child (empty)
        assert grid[3, 0].is_merged is True   # child (empty)
        # A2 has value → merge_parent default (0,0)
        parent_a2 = grid[1, 0].merge_parent
        assert parent_a2[0] == 0
        assert parent_a2[1] == 0
        # A3, A4 empty children → merge_parent = (1,0) = A2's coords
        for r in (2, 3):
            parent = grid[r, 0].merge_parent
            assert parent[0] == 1  # row 1 (A2)
            assert parent[1] == 0  # col 0

    def test_non_merged_cell(self, wb):
        grid = wb.get_sheet_grid("Merges", 4, 4)
        # D1 is not merged
        assert grid[0, 3].is_merged is False
        parent = grid[0, 3].merge_parent
        assert parent[0] == 0
        assert parent[1] == 0


# ─── Header detection ───


class TestHeaderDetection:
    def test_bold_detected_as_header(self, wb):
        grid = wb.get_sheet_grid("Styles", 4, 2, include_styles=True)
        # A1 is bold -> header = True
        assert grid[0, 0].header is True

    def test_non_bold_not_header(self, wb):
        grid = wb.get_sheet_grid("Styles", 4, 2, include_styles=True)
        # B1 is not bold -> header = False (it's numeric "Normal" string)
        assert grid[0, 1].header is False

    def test_underline_detected_as_header(self, wb):
        grid = wb.get_sheet_grid("Styles", 4, 2, include_styles=True)
        # A4 is underline -> header = True
        assert grid[3, 0].header is True


# ─── masked_copy_from ───


class TestMaskedCopyFrom:
    def test_masked_copy(self, wb_fresh):
        source = wb_fresh.get_sheet_grid("Values", 4, 4)
        source.apply_raw_as_formatted()
        dest = CellGrid.empty(4, 4)
        mask = np.zeros((4, 4), dtype=bool)
        mask[0, 0] = True
        mask[1, 1] = True
        dest.masked_copy_from(source, mask, 0, 0)
        assert dest[0, 0].value == "Hello"
        assert dest[1, 1].value is not None
        assert dest[0, 1].value is None  # not in mask


# ─── Iteration ───


class TestIteration:
    def test_grid_iteration(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        rows = list(grid)
        assert len(rows) == 4
        assert all(isinstance(r, CellGridView) for r in rows)

    def test_grid_len(self, wb):
        grid = wb.get_sheet_grid("Values", 4, 4)
        assert len(grid) == 4


# ─── Rich text shared strings ───


class TestRichTextSharedStrings:
    """Tests that shared strings with rich text formatting (<r> runs) are read correctly.

    Uses richtext_test.xlsx which has shared strings containing:
      0: "<b>Bold part</b> normal part"
      1: "<u>Underlined</u> text"
      2: "Insured <b><u>Name</u></b>"  (bold+underline in second run)
      3: "Plain string"  (no rich text)
      4: "<i>Italic</i> and normal"
      5: "<b>Merged</b> rich text"
    """

    @pytest.fixture(scope="class")
    def rt_wb(self):
        return CalamineWorkbook.from_path(RICHTEXT_TEST)

    def test_to_python_bold_mixed(self, rt_wb):
        """Shared string 0: bold + normal text reads as concatenated plain text."""
        ws = rt_wb.get_sheet_by_name("RichText")
        data = ws.to_python()
        assert data[0][0] == "Bold part normal part"

    def test_to_python_underline_mixed(self, rt_wb):
        """Shared string 1: underline + normal text."""
        ws = rt_wb.get_sheet_by_name("RichText")
        data = ws.to_python()
        assert data[0][1] == "Underlined text"

    def test_to_python_bold_underline_second_run(self, rt_wb):
        """Shared string 2: plain first run, bold+underline second run."""
        ws = rt_wb.get_sheet_by_name("RichText")
        data = ws.to_python()
        assert data[1][0] == "Insured Name"

    def test_to_python_plain_string(self, rt_wb):
        """Shared string 3: plain text (no <r> runs) should still work."""
        ws = rt_wb.get_sheet_by_name("RichText")
        data = ws.to_python()
        assert data[1][1] == "Plain string"

    def test_to_python_italic_mixed(self, rt_wb):
        """Shared string 4: italic + normal text."""
        ws = rt_wb.get_sheet_by_name("RichText")
        data = ws.to_python()
        assert data[2][0] == "Italic and normal"

    def test_grid_rich_text_values(self, rt_wb):
        """CellGrid reads rich text shared strings via apply_raw_as_formatted."""
        grid = rt_wb.get_sheet_grid("RichText", 3, 2)
        grid.apply_raw_as_formatted()
        assert grid[0, 0].value == "Bold part normal part"
        assert grid[0, 1].value == "Underlined text"
        assert grid[1, 0].value == "Insured Name"
        assert grid[1, 1].value == "Plain string"
        assert grid[2, 0].value == "Italic and normal"

    def test_grid_rich_text_formatting_rust(self, rt_wb):
        """CellGrid reads rich text shared strings via apply_formatting_rust."""
        grid = rt_wb.get_sheet_grid("RichText", 3, 2)
        grid.apply_formatting_rust()
        assert grid[0, 0].value == "Bold part normal part"
        assert grid[1, 0].value == "Insured Name"

    def test_rich_text_in_merge_range(self, rt_wb):
        """Rich text shared string as parent of a merge range."""
        grid = rt_wb.get_sheet_grid("RichTextMerge", 2, 3)
        grid.apply_raw_as_formatted()
        # A1 is merge parent with rich text value
        assert grid[0, 0].value == "Merged rich text"
        # A1 has value → is_merged should be False (openpyxl semantics)
        assert grid[0, 0].is_merged is False
        # B1, C1 are merge children (empty)
        assert grid[0, 1].is_merged is True
        assert grid[0, 2].is_merged is True

    def test_rich_text_merge_propagation(self, rt_wb):
        """After propagation, merge children get the rich text parent's value."""
        grid = rt_wb.get_sheet_grid("RichTextMerge", 2, 3)
        grid.apply_raw_as_formatted()
        grid.propagate_merged_values()
        assert grid[0, 1].value == "Merged rich text"
        assert grid[0, 2].value == "Merged rich text"


# ─── Empty parent merge edge case ───


class TestEmptyParentMerge:
    """Tests that merge parents with no value are handled correctly.

    openpyxl determines is_merged by value emptiness, not by coordinate
    position. Any cell in a merge range whose value is empty gets
    is_merged=True — including the parent cell. Parent cells with a
    value get is_merged=False.
    """

    @pytest.fixture(scope="class")
    def em_wb(self):
        return CalamineWorkbook.from_path(EMPTY_MERGE_TEST)

    def test_empty_parent_is_merged(self, em_wb):
        """Empty parent cell A1 (merge A1:C1) should have is_merged=True (openpyxl behavior)."""
        grid = em_wb.get_sheet_grid("EmptyParentMerge", 3, 5)
        assert grid[0, 0].is_merged is True

    def test_empty_parent_children_are_merged(self, em_wb):
        """Children B1, C1 (merge A1:C1) should have is_merged=True."""
        grid = em_wb.get_sheet_grid("EmptyParentMerge", 3, 5)
        assert grid[0, 1].is_merged is True
        assert grid[0, 2].is_merged is True

    def test_empty_parent_merge_parent_coords(self, em_wb):
        """Empty parent A1 should have merge_parent = (0,0) from merge_map (it maps to itself)."""
        grid = em_wb.get_sheet_grid("EmptyParentMerge", 3, 5)
        parent = grid[0, 0].merge_parent
        assert parent[0] == 0
        assert parent[1] == 0

    def test_empty_parent_children_merge_parent_coords(self, em_wb):
        """Children B1, C1 should have merge_parent pointing to A1 (0,0)."""
        grid = em_wb.get_sheet_grid("EmptyParentMerge", 3, 5)
        for c in (1, 2):
            parent = grid[0, c].merge_parent
            assert parent[0] == 0  # row 0
            assert parent[1] == 0  # col 0

    def test_valued_parent_not_merged(self, em_wb):
        """Parent A3 (merge A3:C3) with value should have is_merged=False."""
        grid = em_wb.get_sheet_grid("EmptyParentMerge", 3, 5)
        assert grid[2, 0].is_merged is False

    def test_vertical_empty_parent_is_merged(self, em_wb):
        """Empty parent E1 (vertical merge E1:E3) should have is_merged=True (openpyxl behavior)."""
        grid = em_wb.get_sheet_grid("EmptyParentMerge", 3, 5)
        assert grid[0, 4].is_merged is True

    def test_vertical_empty_parent_children_merged(self, em_wb):
        """Children E2, E3 (vertical merge E1:E3) should have is_merged=True."""
        grid = em_wb.get_sheet_grid("EmptyParentMerge", 3, 5)
        assert grid[1, 4].is_merged is True
        assert grid[2, 4].is_merged is True

    def test_numpy_is_merged_empty_parent(self, em_wb):
        """Numpy is_merged array should match scalar is_merged for empty parents."""
        grid = em_wb.get_sheet_grid("EmptyParentMerge", 3, 5)
        merged = grid["is_merged"]
        # A1: empty parent -> True (openpyxl: empty cells in merge ranges are merged)
        assert merged[0, 0] is np.True_
        # B1, C1: children -> True
        assert merged[0, 1] is np.True_
        assert merged[0, 2] is np.True_
        # E1: empty parent -> True
        assert merged[0, 4] is np.True_
        # E2, E3: children -> True
        assert merged[1, 4] is np.True_
        assert merged[2, 4] is np.True_

    def test_numpy_merge_parent_empty_parent(self, em_wb):
        """Numpy merge_parent array should return merge_map coords for empty parent cells."""
        grid = em_wb.get_sheet_grid("EmptyParentMerge", 3, 5)
        parents = grid["merge_parent"]
        # A1: empty parent -> (0,0) from merge_map (maps to itself)
        assert parents[0, 0, 0] == 0
        assert parents[0, 0, 1] == 0
        # B1: child -> parent coords (0,0) = A1
        assert parents[0, 1, 0] == 0
        assert parents[0, 1, 1] == 0
        # E1: empty parent -> (0,4) from merge_map (maps to itself)
        assert parents[0, 4, 0] == 0
        assert parents[0, 4, 1] == 4
        # E2: child -> parent coords (0,4) = E1
        assert parents[1, 4, 0] == 0
        assert parents[1, 4, 1] == 4


# ─── Coord offsets ───
# Verify coords are preserved through slice_copy, masked_copy_from, vstack, hstack, copy.


class TestCoordOffsets:
    """Coords must reflect absolute spreadsheet position after grid operations."""

    def test_full_grid_coords_start_at_1(self, wb):
        """Freshly loaded grid has coords (1,1) to (rows, cols)."""
        grid = wb.get_sheet_grid("Values", 4, 4)
        assert tuple(grid[0, 0]["coord"]) == (1, 1)
        assert tuple(grid[3, 3]["coord"]) == (4, 4)

    def test_slice_copy_preserves_coords(self, wb):
        """slice_copy(r1, r2, c1, c2) should produce coords offset by (r1, c1)."""
        grid = wb.get_sheet_grid("Values", 4, 4)
        sliced = grid.slice_copy(1, 3, 2, 4)  # rows 1-2, cols 2-3
        assert sliced.shape == (2, 2)
        assert tuple(sliced[0, 0]["coord"]) == (2, 3)  # row 1+1, col 2+1
        assert tuple(sliced[1, 1]["coord"]) == (3, 4)

    def test_slice_copy_array_coords(self, wb):
        """Array-level coord access should also have offsets."""
        grid = wb.get_sheet_grid("Values", 4, 4)
        sliced = grid.slice_copy(2, 4, 1, 3)
        coords = sliced["coord"]
        assert coords.shape == (2, 2, 2)
        assert tuple(coords[0, 0]) == (3, 2)
        assert tuple(coords[1, 1]) == (4, 3)

    def test_view_copy_preserves_coords(self, wb):
        """Materializing a CellGridView via .copy() should preserve coords."""
        grid = wb.get_sheet_grid("Values", 4, 4)
        view = grid[1:3, 2:4]
        copied = view.copy()
        assert tuple(copied[0, 0]["coord"]) == (2, 3)

    def test_masked_copy_from_sets_coords(self, wb):
        """masked_copy_from should set coord offsets from src_row/col_offset."""
        grid = wb.get_sheet_grid("Values", 4, 4)
        grid.apply_raw_as_formatted()
        mask = np.ones((2, 2), dtype=bool)
        dest = CellGrid.empty(2, 2)
        dest.masked_copy_from(grid, mask, src_row_offset=1, src_col_offset=2)
        assert tuple(dest[0, 0]["coord"]) == (2, 3)
        assert tuple(dest[1, 1]["coord"]) == (3, 4)

    def test_vstack_preserves_coords(self, wb):
        """vstack should preserve the coord offset of the first operand."""
        grid = wb.get_sheet_grid("Values", 4, 4)
        top = grid.slice_copy(1, 2, 0, 4)   # row 1
        bot = grid.slice_copy(2, 3, 0, 4)   # row 2
        stacked = top.vstack(bot)
        assert stacked.shape == (2, 4)
        assert tuple(stacked[0, 0]["coord"]) == (2, 1)  # from top's offset
        assert tuple(stacked[1, 0]["coord"]) == (3, 1)

    def test_hstack_preserves_coords(self, wb):
        """hstack should preserve the coord offset of the first operand."""
        grid = wb.get_sheet_grid("Values", 4, 4)
        left = grid.slice_copy(0, 4, 0, 2)   # cols 0-1
        right = grid.slice_copy(0, 4, 2, 4)  # cols 2-3
        stacked = left.hstack(right)
        assert stacked.shape == (4, 4)
        assert tuple(stacked[0, 0]["coord"]) == (1, 1)  # from left's offset
        assert tuple(stacked[0, 3]["coord"]) == (1, 4)

    def test_copy_preserves_coords(self, wb):
        """Deep copy should preserve coord offsets."""
        grid = wb.get_sheet_grid("Values", 4, 4)
        sliced = grid.slice_copy(2, 4, 1, 3)
        copied = sliced.copy()
        assert tuple(copied[0, 0]["coord"]) == (3, 2)

    def test_chained_slice_accumulates_offsets(self, wb):
        """Slicing a slice should accumulate offsets."""
        grid = wb.get_sheet_grid("Values", 4, 4)
        first = grid.slice_copy(1, 4, 1, 4)   # offset (1, 1)
        second = first.slice_copy(1, 2, 1, 2)  # offset (1+1, 1+1) = (2, 2)
        assert tuple(second[0, 0]["coord"]) == (3, 3)
