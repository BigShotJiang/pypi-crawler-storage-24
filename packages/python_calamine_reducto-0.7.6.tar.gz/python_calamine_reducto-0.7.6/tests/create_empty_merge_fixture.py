"""Generate test fixture: tests/data/empty_merge_test.xlsx

Creates an xlsx with merge ranges where the parent cell is empty,
to test that is_merged and merge_parent handle empty parents correctly.

Run once: python tests/create_empty_merge_fixture.py
"""

import openpyxl
from pathlib import Path

wb = openpyxl.Workbook()

ws = wb.active
ws.title = "EmptyParentMerge"

# A1:C1 merged, but A1 (parent) is left EMPTY
ws.merge_cells("A1:C1")
# A1 intentionally has no value

# A3:C3 merged with a value in parent for comparison
ws["A3"] = "Has value"
ws.merge_cells("A3:C3")

# D1 not merged, has a value
ws["D1"] = "Not merged"

# E1:E3 vertical merge with empty parent
ws.merge_cells("E1:E3")
# E1 intentionally has no value

out = Path(__file__).parent / "data" / "empty_merge_test.xlsx"
wb.save(out)
print(f"Created {out}")
