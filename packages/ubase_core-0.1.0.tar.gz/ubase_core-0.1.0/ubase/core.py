def emo():
    a = []
    s = set()
    r = [
        (0x1F300, 0x1F5FF),
        (0x1F600, 0x1F64F),
        (0x1F680, 0x1F6FF),
        (0x1F700, 0x1F77F),
        (0x1F780, 0x1F7FF),
        (0x1F800, 0x1F8FF),
        (0x1F900, 0x1F9FF),
        (0x1FA00, 0x1FAFF),
    ]
    for x, y in r:
        for i in range(x, y + 1):
            c = chr(i)
            if c in s:
                continue
            s.add(c)
            a.append(c)
    return ''.join(a)

def core():
    return "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.:;<>?@[]^&()*$%/\\`\"',_!#"

def bad():
    return {22, 23, 24, 25, 26, 27, 28, 29, 30, 15}

def nonChar(i):
    return 0xFDD0 <= i <= 0xFDEF or (i & 0xFFFF) in (0xFFFE, 0xFFFF)

def stop(i, e):
    if 22 in e and 0x0000 <= i <= 0x001F: return True
    if 23 in e and 0x007F <= i <= 0x009F: return True
    if 24 in e and 0x0300 <= i <= 0x036F: return True
    if 25 in e and ((0x200B <= i <= 0x200F) or (0x202A <= i <= 0x202E) or (0x2060 <= i <= 0x206F)): return True
    if 26 in e and (i == 0x00A0 or i == 0x1680 or 0x2000 <= i <= 0x200A or i == 0x2028 or i == 0x2029 or i == 0x202F or i == 0x205F or i == 0x3000): return True
    if 27 in e and ((0xFE00 <= i <= 0xFE0F) or (0xE0100 <= i <= 0xE01EF)): return True
    if 28 in e and 0xD800 <= i <= 0xDFFF: return True
    if 15 in e and 0xE000 <= i <= 0xF8FF: return True
    if 29 in e and ((0xF0000 <= i <= 0xFFFFD) or (0x100000 <= i <= 0x10FFFD)): return True
    if 30 in e and nonChar(i): return True
    return False

def cut(x):
    c = set()
    r = set()
    if x is None:
        return c, r
    if isinstance(x, str):
        c.update(x)
        return c, r
    if isinstance(x, (list, tuple, set)):
        for v in x:
            if isinstance(v, int):
                r.add(v)
            elif isinstance(v, str):
                c.update(v)
            else:
                raise ValueError("x items must be int or str")
        return c, r
    raise ValueError("x must be None, str, list, tuple, or set")

def abc(b, x=None, u=0, safe=1):
    if not isinstance(b, int):
        raise ValueError("b must be int")
    if u not in (0, 1):
        raise ValueError("u must be 0 or 1")
    if safe not in (0, 1):
        raise ValueError("safe must be 0 or 1")

    xc, xr = cut(x)
    if safe:
        xr |= bad()

    a = []
    s = set()

    def add(c):
        if c in s or c in xc:
            return
        s.add(c)
        a.append(c)

    if b == 1:
        for c in emo():
            add(c)
        if not a:
            raise ValueError("alphabet is empty")
        return ''.join(a)

    if b == 0:
        for c in "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ":
            add(c)
        if 21 not in xr:
            for c in emo():
                add(c)
        if not a:
            raise ValueError("alphabet is empty")
        return ''.join(a)

    if b < 2:
        raise ValueError("b must be 0, 1, or >= 2")

    if u:
        i = 0
        while i <= 0x10FFFF and len(a) < b:
            if not stop(i, xr):
                try:
                    add(chr(i))
                except ValueError:
                    pass
            i += 1
        if not a:
            raise ValueError("alphabet is empty")
        return ''.join(a[:b])

    if 0 not in xr:
        for c in core():
            add(c)
            if len(a) >= b:
                return ''.join(a[:b])

    rs = {
        1: [(0x00A1, 0x024F)],
        2: [(0x0370, 0x052F)],
        3: [(0x0531, 0x058F)],
        4: [(0x10A0, 0x10FF)],
        5: [(0x13A0, 0x13FF)],
        6: [(0x1E00, 0x20CF)],
        7: [(0x2100, 0x214F)],
        8: [(0x2460, 0x24FF)],
        9: [(0x2500, 0x257F)],
        10: [(0x2580, 0x259F)],
        11: [(0x25A0, 0x25FF)],
        12: [(0x2C60, 0x2C7F)],
        13: [(0x2E00, 0x2E7F)],
        14: [(0xA640, 0xA69F)],
        15: [(0xE000, 0xF8FF)],
        16: [(0xF900, 0xFAFF)],
        17: [(0xFB00, 0xFDFF)],
        18: [(0xFE20, 0xFE6F)],
        19: [(0xFF01, 0xFFEE)],
        20: [(0x10000, 0x10FFFF)],
        22: [(0x0000, 0x001F)],
        23: [(0x007F, 0x009F)],
        24: [(0x0300, 0x036F)],
        25: [(0x200B, 0x200F), (0x202A, 0x202E), (0x2060, 0x206F)],
        26: [(0x00A0, 0x00A0), (0x1680, 0x1680), (0x2000, 0x200A), (0x2028, 0x2029), (0x202F, 0x202F), (0x205F, 0x205F), (0x3000, 0x3000)],
        27: [(0xFE00, 0xFE0F), (0xE0100, 0xE01EF)],
        28: [(0xD800, 0xDFFF)],
        29: [(0xF0000, 0xFFFFD), (0x100000, 0x10FFFD)],
        30: [(0xFDD0, 0xFDEF)],
    }

    for k in sorted(rs):
        if k in xr:
            continue
        for p, q in rs[k]:
            i = p
            while i <= q and len(a) < b:
                if not stop(i, xr):
                    try:
                        add(chr(i))
                    except ValueError:
                        pass
                    i += 1
        if len(a) >= b:
            return ''.join(a[:b])

    if 21 not in xr and len(a) < b:
        for c in emo():
            add(c)
            if len(a) >= b:
                return ''.join(a[:b])

    if not a:
        raise ValueError("alphabet is empty")
    return ''.join(a[:b])

def h1(s):
    return ' '.join(format(ord(c), 'x') for c in s)

def h0(s):
    if not isinstance(s, str) or not s.strip():
        raise ValueError("hex input must be non-empty")
    return ''.join(chr(int(v, 16)) for v in s.split())

def toUBase(n, b, s, m=0, x=None, u=0, safe=1):
    if not isinstance(n, int) or n < 0:
        raise ValueError("n must be non-negative int")
    if s not in (0, 1):
        raise ValueError("s must be 0 or 1")
    if m not in (0, 1):
        raise ValueError("m must be 0 or 1")

    a = abc(b, x, u, safe)
    b = len(a)

    if b < 2:
        raise ValueError("alphabet must have at least 2 chars")

    v = n
    if s == 1:
        w = 1
        while v >= b ** w:
            v -= b ** w
            w += 1
        o = [''] * w
        for i in range(w - 1, -1, -1):
            v, r = divmod(v, b)
            o[i] = a[r]
        z = ''.join(o)
    else:
        if v == 0:
            z = a[0]
        else:
            o = []
            while v:
                v, r = divmod(v, b)
                o.append(a[r])
            z = ''.join(reversed(o))

    return z if m == 0 else h1(z)

def fromUBase(n, b, s, m=0, x=None, u=0, safe=1):
    if not isinstance(n, str) or not n:
        raise ValueError("n must be non-empty string")
    if s not in (0, 1):
        raise ValueError("s must be 0 or 1")
    if m not in (0, 1):
        raise ValueError("m must be 0 or 1")

    if m == 1:
        n = h0(n)

    a = abc(b, x, u, safe)
    t = {c: i for i, c in enumerate(a)}
    b = len(a)
    v = 0

    for c in n:
        if c not in t:
            raise ValueError(f"invalid digit: {repr(c)}")
        v = v * b + t[c]

    if s == 1 and len(n) > 1:
        v += (b ** len(n) - b) // (b - 1)

    return v

def uBase(n, b, s, m=0, x=None, u=0, safe=1):
    if isinstance(n, int):
        return toUBase(n, b, s, m, x, u, safe)
    if isinstance(n, str):
        return fromUBase(n, b, s, m, x, u, safe)
    raise ValueError("n must be int or str")