import argparse
from .core import uBase

VERSION = "0.1.0"

def main():
    p = argparse.ArgumentParser(
        prog="ubase-core",
        description="Universal base conversion"
    )

    g = p.add_mutually_exclusive_group(required=True)
    p.add_argument("--version", action="version", version=f"ubase-core {VERSION}")
    g.add_argument("-e", "--encode", action="store_true", help="encode integer input")
    g.add_argument("-d", "--decode", action="store_true", help="decode string input")
    
    p.add_argument("n", help="value")
    p.add_argument("b", type=int, help="base or selector")
    p.add_argument("s", type=int, choices=[0,1], help="significant 0s (1 on, 0 off)")

    p.add_argument("-m", type=int, choices=[0,1], default=0,
                   help="output mode (0 symbols, 1 hex codepoints)")
    p.add_argument("-u", type=int, choices=[0,1], default=0,
                   help="unicode mode (0 curated, 1 full)")
    p.add_argument("--safe", type=int, choices=[0,1], default=1,
                   help="filter problematic unicode")

    p.add_argument("-x", nargs="*", default=None,
                   help="exclusions (characters or range ids)")

    a = p.parse_args()

    x = None
    if a.x:
        x = []
        for v in a.x:
            try:
                x.append(int(v))
            except ValueError:
                x.append(v)

    if a.encode:
        n = int(a.n)
    else:
        n = a.n

    print(uBase(n, a.b, a.s, a.m, x, a.u, a.safe))


if __name__ == "__main__":
    main()