# ubase-core

```ubase-core -e 123456789 62 1```

Universal base conversion.

Install:

```bash
pip install ubase-core
```

Import:

```python
from ubase import uBase
```

---

# Function

```python
uBase(n, b, s, m=0, x=None, u=0, safe=1)
```

| parameter | meaning |
|-----------|--------|
| n | integer to encode or string to decode |
| b | base or selector |
| s | significant leading zeros (`1` on, `0` off) |
| m | output mode (`0` symbols, `1` hex codepoints) |
| x | exclusions (characters and/or unicode range ids) |
| u | unicode mode (`0` curated`, `1` full unicode order) |
| safe | filter problematic unicode |

---

# Base selectors

| value | meaning |
|------|--------|
| `b >= 2` | normal base |
| `b = 0` | base62 + emoji |
| `b = 1` | emoji alphabet |

---

# Example

```python
from ubase import uBase

x = 1111111110

encoded = uBase(x,10,1)
decoded = uBase(encoded,10,1)

print(encoded)
print(decoded)
```

---

# CLI

Encode:

```bash
ubase-core -e 1111111110 10 1
```

Decode:

```bash
ubase-core -d "000000000" 10 1
```

Hex output:

```bash
ubase-core -e 1111111110 10 1 -m 1
```

Unicode base:

```bash
ubase-core -e 1111111110 128 1 -u 1
```

Exclude characters:

```bash
ubase-core -e 1111111110 128 1 -x 21 0OIl
```

---

# Module execution

You can also run:

```bash
python -m ubase -e 1111111110 10 1
```

---

# License

MIT License