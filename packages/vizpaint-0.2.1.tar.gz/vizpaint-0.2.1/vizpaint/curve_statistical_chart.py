# paint/curve_statistical_chart.py
from matplotlib.pyplot import *
import numpy as np


def curve_statistical_chart(a, b, c, d):
    """
    绘制曲线统计图

    参数:
    a: 数据点数量
    b: 图表标题
    c: X轴标签
    d: Y轴标签
    """
    x = np.linspace(0, 3 * np.pi, a)
    y1, y2 = np.sin(x), np.cos(x)

    plot(x, y1, label='sin(x)')
    plot(x, y2, label='cos(x)')
    title(b)
    xlabel(c)
    ylabel(d)
    legend()
    grid(True)

    show()

    # 如果你想让函数返回图表对象以便进一步操作，可以改为：
    # return plt.gcf(), plt.gca()