from matplotlib.pyplot import *
from numpy import *
#Import required modules

def pie_chart(a,b,c,d,e,f,g,h,i,j,k,l):
    #Draw a pie chart
    labels = a,b,c,d,e,f
    sizes = [g,h,i,j,k,l]
    colors = ['green','blue','red','yellow','purple','orange']
    pie(sizes, labels=labels, colors= colors, autopct ='%1.1f%%', shadow=True, startangle=90)
    axis('equal')
    show()
def bar_chart(a,b,c,d,e,f):
    #Draw a bar chart
    n = 6
    y = [a,b,c,d,e]
    index = arange(n)
    bar(left = index, height= y, cocor = f, )
def curve_statistical_chart(a,b,c,d):
    # Draw a curve statistical chart
    x = linspace(0,3 * np.pi ,a )
    y1,y2 = sin(x),cos(x)
    plot(x, y1)
    plot(x, y2)
    title(b)
    xlabel(c)
    ylabel(d)
    show()
def scatter_plot(a,b,c,d,e,f,g,h):
    #Draw a scatter plot
    higth = [a,b,c,d]
    weiggt= [e,f,g,h]
    scatter(higth,weiggt)