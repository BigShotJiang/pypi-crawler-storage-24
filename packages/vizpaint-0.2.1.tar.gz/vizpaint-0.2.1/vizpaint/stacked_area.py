"""
堆叠面积图
"""

import matplotlib.pyplot as plt
from vizpaint.utils import set_chinese_font
import numpy as np


def create_stacked_area_chart(data, x_column, y_columns, title="堆叠面积图",
                              xlabel="X轴", ylabel="Y轴", figsize=(12, 8),
                              colors=None, legend_loc='upper left', alpha=0.7,
                              rotation=45):
    """
    创建堆叠面积图

    参数:
    ----------
    data : DataFrame
        包含数据的DataFrame
    x_column : str
        X轴列名
    y_columns : list
        要堆叠显示的Y轴列名列表
    title : str, optional
        图表标题
    xlabel : str, optional
        X轴标签
    ylabel : str, optional
        Y轴标签
    figsize : tuple, optional
        图表尺寸
    colors : list, optional
        颜色列表
    legend_loc : str, optional
        图例位置
    alpha : float, optional
        透明度
    rotation : int, optional
        X轴标签旋转角度

    返回:
    ----------
    fig, ax : 图表对象和坐标轴对象
    """
    set_chinese_font()
    fig, ax = plt.subplots(figsize=figsize)

    if colors is None:
        colors = plt.cm.Set3(np.linspace(0, 1, len(y_columns)))

    # 创建堆叠面积图
    ax.stackplot(data[x_column], [data[col] for col in y_columns],
                 labels=y_columns, colors=colors, alpha=alpha)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontsize=16, fontweight='bold')
    ax.legend(loc=legend_loc)
    ax.grid(True, alpha=0.3)

    # 旋转X轴标签
    if rotation != 0:
        plt.setp(ax.get_xticklabels(), rotation=rotation, ha='right')

    plt.tight_layout()
    return fig, ax