import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def surface_3d(x=None, y=None, z=None, title="3D Surface Plot"):
    """绘制3D曲面图"""
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    if x is None or y is None or z is None:
        # 生成示例数据
        x = np.linspace(-5, 5, 100)
        y = np.linspace(-5, 5, 100)
        x, y = np.meshgrid(x, y)
        z = np.sin(np.sqrt(x ** 2 + y ** 2))

    surf = ax.plot_surface(x, y, z, cmap='viridis', alpha=0.8)
    fig.colorbar(surf, ax=ax, shrink=0.5, aspect=5)
    ax.set_title(title, fontsize=14, pad=20)

    return fig, ax, surf