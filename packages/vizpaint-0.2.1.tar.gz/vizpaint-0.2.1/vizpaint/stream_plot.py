# paint/stream_plot.py
"""
流图和矢量场可视化
"""
import numpy as np
import matplotlib as plt


def stream_plot(x=None, y=None, u=None, v=None, density=1, title="Stream Plot"):
    """绘制流线图"""
    fig, ax = plt.subplots(figsize=(10, 8))

    if x is None:
        y, x = np.mgrid[-3:3:100j, -3:3:100j]
        u = -1 - x ** 2 + y
        v = 1 + x - y ** 2

    stream = ax.streamplot(x, y, u, v, density=density, color=u, cmap='coolwarm')
    ax.set_title(title, fontsize=14)

    return fig, ax, stream


