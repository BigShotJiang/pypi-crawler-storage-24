"""
散点矩阵图
"""

import matplotlib.pyplot as plt
import seaborn as sns
from vizpaint.utils import set_chinese_font


def create_scatter_matrix(data, columns, hue_column=None, title="散点矩阵图",
                          figsize=(15, 15), diag_kind='hist', markers='o',
                          alpha=0.7, palette='Set2'):
    """
    创建散点矩阵图

    参数:
    ----------
    data : DataFrame
        包含数据的DataFrame
    columns : list
        要包含在散点矩阵中的列名列表
    hue_column : str, optional
        用于分组的列名
    title : str, optional
        图表标题
    figsize : tuple, optional
        图表尺寸
    diag_kind : str, optional
        对角线图表类型 ('hist' 或 'kde')
    markers : str, optional
        标记样式
    alpha : float, optional
        透明度
    palette : str, optional
        调色板

    返回:
    ----------
    fig : 图表对象
    """
    set_chinese_font()

    # 创建散点矩阵图
    if hue_column is not None:
        pairplot = sns.pairplot(data[columns + [hue_column]],
                                hue=hue_column, diag_kind=diag_kind,
                                markers=markers, palette=palette,
                                plot_kws={'alpha': alpha})
    else:
        pairplot = sns.pairplot(data[columns], diag_kind=diag_kind,
                                plot_kws={'alpha': alpha})

    fig = pairplot.fig
    fig.set_size_inches(figsize)
    fig.suptitle(title, fontsize=16, fontweight='bold', y=1.02)

    plt.tight_layout()
    return fig