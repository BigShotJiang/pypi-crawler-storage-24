"""
分组柱状图（复式柱状图）
"""

import numpy as np
import matplotlib.pyplot as plt
from vizpaint.utils import set_chinese_font


def create_grouped_bar_chart(data, x_column, y_columns, group_column=None,
                             title="分组柱状图", xlabel="X轴", ylabel="Y轴",
                             figsize=(12, 8), colors=None, legend_loc='upper right',
                             bar_width=0.8, show_values=False, rotation=0):
    """
    创建分组柱状图

    参数:
    ----------
    data : DataFrame
        包含数据的DataFrame
    x_column : str
        X轴列名
    y_columns : list
        要显示的Y轴列名列表（当group_column为None时使用）
    group_column : str, optional
        分组列名，如果提供，则根据该列分组显示多个系列
    title : str, optional
        图表标题
    xlabel : str, optional
        X轴标签
    ylabel : str, optional
        Y轴标签
    figsize : tuple, optional
        图表尺寸
    colors : list, optional
        颜色列表
    legend_loc : str, optional
        图例位置
    bar_width : float, optional
        柱状图宽度
    show_values : bool, optional
        是否在柱状图上显示数值
    rotation : int, optional
        X轴标签旋转角度

    返回:
    ----------
    fig, ax : 图表对象和坐标轴对象
    """
    set_chinese_font()
    fig, ax = plt.subplots(figsize=figsize)

    if group_column is None:
        # 简单分组柱状图
        x = np.arange(len(data[x_column]))
        bar_width = bar_width / len(y_columns)

        if colors is None:
            colors = plt.cm.Set3(np.linspace(0, 1, len(y_columns)))

        for i, col in enumerate(y_columns):
            offset = (i - len(y_columns) / 2 + 0.5) * bar_width
            bars = ax.bar(x + offset, data[col], width=bar_width,
                          label=col, color=colors[i], edgecolor='black', alpha=0.8)

            if show_values:
                for bar in bars:
                    height = bar.get_height()
                    ax.text(bar.get_x() + bar.get_width() / 2., height + 0.01,
                            f'{height:.1f}', ha='center', va='bottom', fontsize=9)

        ax.set_xticks(x)
        ax.set_xticklabels(data[x_column], rotation=rotation)

    else:
        # 复杂分组柱状图（基于group_column分组）
        groups = data[group_column].unique()
        x_categories = data[x_column].unique()

        x = np.arange(len(x_categories))
        bar_width = bar_width / len(groups)

        if colors is None:
            colors = plt.cm.Set3(np.linspace(0, 1, len(groups)))

        for i, group in enumerate(groups):
            group_data = data[data[group_column] == group]
            values = []
            for cat in x_categories:
                subset = group_data[group_data[x_column] == cat]
                if len(subset) > 0:
                    values.append(subset[y_columns[0]].values[0])
                else:
                    values.append(0)

            offset = (i - len(groups) / 2 + 0.5) * bar_width
            bars = ax.bar(x + offset, values, width=bar_width,
                          label=group, color=colors[i], edgecolor='black', alpha=0.8)

            if show_values:
                for bar in bars:
                    height = bar.get_height()
                    if height > 0:
                        ax.text(bar.get_x() + bar.get_width() / 2., height + 0.01,
                                f'{height:.1f}', ha='center', va='bottom', fontsize=9)

        ax.set_xticks(x)
        ax.set_xticklabels(x_categories, rotation=rotation)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontsize=16, fontweight='bold')
    ax.legend(loc=legend_loc)
    ax.grid(axis='y', alpha=0.3)

    plt.tight_layout()
    return fig, ax