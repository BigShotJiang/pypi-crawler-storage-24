# paint/line_plot.py
import matplotlib.pyplot as plt
import numpy as np


def line_plot(x_data=None, y_data_list=None, labels=None,
              title="Line Plot", xlabel="X", ylabel="Y",
              line_styles=None, colors=None, marker_styles=None,
              grid=True, legend=True):
    """
    绘制折线图

    参数:
    x_data: X轴数据
    y_data_list: Y轴数据列表（多条线）
    labels: 图例标签
    title: 图表标题
    xlabel: X轴标签
    ylabel: Y轴标签
    line_styles: 线条样式列表
    colors: 颜色列表
    marker_styles: 标记样式列表
    grid: 是否显示网格
    legend: 是否显示图例
    """
    fig, ax = plt.subplots(figsize=(10, 6))

    # 默认数据
    if x_data is None:
        x_data = np.arange(1, 11)
    if y_data_list is None:
        y_data_list = [np.sin(x_data), np.cos(x_data), np.tan(x_data) / 10]
        labels = ['sin(x)', 'cos(x)', 'tan(x)/10']

    # 设置默认样式
    if colors is None:
        colors = plt.cm.Set1(np.linspace(0, 1, len(y_data_list)))
    if line_styles is None:
        line_styles = ['-', '--', '-.', ':'] * (len(y_data_list) // 4 + 1)
    if marker_styles is None:
        marker_styles = ['o', 's', '^', 'D', 'v'] * (len(y_data_list) // 5 + 1)
    if labels is None:
        labels = [f'Line {i + 1}' for i in range(len(y_data_list))]

    # 绘制每条线
    lines = []
    for i, y_data in enumerate(y_data_list):
        line, = ax.plot(x_data, y_data,
                        linestyle=line_styles[i % len(line_styles)],
                        color=colors[i % len(colors)],
                        marker=marker_styles[i % len(marker_styles)],
                        markersize=8,
                        linewidth=2,
                        label=labels[i],
                        alpha=0.8)
        lines.append(line)

    # 设置图表属性
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)

    if grid:
        ax.grid(True, linestyle='--', alpha=0.5)

    if legend and len(y_data_list) > 1:
        ax.legend(fontsize=10, loc='best')

    plt.tight_layout()
    return fig, ax, lines