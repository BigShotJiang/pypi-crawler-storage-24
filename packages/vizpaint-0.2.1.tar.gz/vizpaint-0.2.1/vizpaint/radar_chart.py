# paint/radar_chart.py
import matplotlib.pyplot as plt
import numpy as np


def radar_chart(categories=None, values_list=None, labels=None,
                title="Radar Chart", colors=None, fill=True):
    """
    绘制雷达图（蜘蛛图）

    参数:
    categories: 类别名称列表
    values_list: 数值列表（每个元素是一个数据系列）
    labels: 数据系列标签
    title: 图表标题
    colors: 颜色列表
    fill: 是否填充区域
    """
    # 设置极坐标
    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(projection='polar'))

    # 生成默认数据
    if categories is None:
        categories = ['Speed', 'Reliability', 'Comfort', 'Safety', 'Efficiency']
    if values_list is None:
        np.random.seed(42)
        values_list = [
            [4, 4, 5, 4, 3],
            [3, 5, 4, 5, 4],
            [5, 3, 3, 4, 5]
        ]
        labels = ['Car A', 'Car B', 'Car C']

    N = len(categories)

    # 计算角度
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    angles += angles[:1]  # 闭合图形

    # 设置默认颜色
    if colors is None:
        colors = plt.cm.tab10(np.linspace(0, 1, len(values_list)))

    # 绘制每个数据系列
    for i, values in enumerate(values_list):
        # 闭合数据
        values += values[:1]

        # 绘制雷达线
        ax.plot(angles, values, 'o-', linewidth=2,
                label=labels[i] if labels else f'Series {i + 1}',
                color=colors[i % len(colors)])

        # 填充区域
        if fill:
            ax.fill(angles, values, alpha=0.25, color=colors[i % len(colors)])

    # 设置类别标签
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, fontsize=12)

    # 设置标题
    plt.title(title, fontsize=14, fontweight='bold', pad=20)

    # 添加图例
    ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.0), fontsize=10)

    # 设置网格
    ax.grid(True, linestyle='--', alpha=0.5)

    plt.tight_layout()
    return fig, ax