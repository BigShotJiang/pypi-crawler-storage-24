from matplotlib.pyplot import *
# paint/scatter_plot.py
import matplotlib.pyplot as plt

def scatter_plot(a, b, c, d, e, f, g, h):
    """绘制散点图

    参数:
    a, b, c, d: 四个点的x坐标
    e, f, g, h: 四个点的y坐标
    """
    height = [a, b, c, d]
    weight = [e, f, g, h]
    plt.scatter(height, weight)
    plt.xlabel('Height')
    plt.ylabel('Weight')
    plt.title('Scatter Plot')
    plt.show()

