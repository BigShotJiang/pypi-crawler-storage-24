"""vizpaint - 专业数据可视化库"""

__version__ = "0.2.1"
__author__ = "zhouxinjun"

# ==================== 基础图表 ====================
from .pie_chart import pie_chart
from .bar_chart import bar_chart
from .curve_statistical_chart import curve_statistical_chart
from .scatter_plot import scatter_plot

# ==================== 2D 统计图 ====================
from .line_plot import line_plot
from .area_chart import area_chart
from .bubble_chart import bubble_chart
from .stacked_bar_chart import stacked_bar_chart
from .histogram import histogram
from .box_plot import box_plot
from .violin_plot import violin_plot
from .radar_chart import radar_chart

from .pair_plot import pair_plot

# ==================== 玫瑰图系列 ====================
from .rose_chart import rose_chart, stacked_rose_chart, wind_rose, create_sample_wind_data
from .rose_chart_enhanced import rose_chart_enhanced

# ==================== 3D 图表 ====================
from .surface_3d import surface_3d
from .scatter_3d import scatter_3d

# ==================== 场/矢量图 ====================
from .quiver_plot import quiver_plot
from .stream_plot import stream_plot

# ==================== 高级图表 ====================
from .sankey_diagram import sankey_diagram, create_simple_sankey, create_budget_sankey
from .treemap import treemap  # 需要安装 squarify

# ==================== 复合图表（来自 compound 目录）====================
from .combination_chart import create_combination_chart
from .grouped_bar import create_grouped_bar_chart
from .grouped_boxplot import create_grouped_boxplot
from .multiline import create_multiline_chart
from .scatter_matrix import create_scatter_matrix
from .stacked_area import create_stacked_area_chart
from .stacked_bar import create_stacked_bar_chart
from .heatmap import create_heatmap  # 注意：与上面 heatmap 同名，建议重命名或别名

# ==================== 工具函数 ====================
from .utils import set_chinese_font
import matplotlib.pyplot as plt

def set_style(style='default'):
    try:
        plt.style.use(style)
    except:
        plt.style.use('default')

def show_all():
    plt.show()

def clear_all():
    plt.close('all')

def get_version():
    return __version__

# ==================== 额外实用函数 ====================
from .core import CodeSubmitter, process_data, main_function
from .chicken import chicken  # 趣味函数

# ==================== 定义 __all__ ====================
__all__ = [
    # 基础
    'pie_chart', 'bar_chart', 'curve_statistical_chart', 'scatter_plot',
    # 2D统计
    'line_plot', 'area_chart', 'bubble_chart', 'stacked_bar_chart',
    'histogram', 'box_plot', 'violin_plot', 'radar_chart', 'heatmap', 'pair_plot',
    # 玫瑰图
    'rose_chart', 'stacked_rose_chart', 'wind_rose', 'create_sample_wind_data',
    'rose_chart_enhanced',
    # 3D
    'surface_3d', 'scatter_3d',
    # 场图
    'quiver_plot', 'stream_plot',
    # 高级
    'sankey_diagram', 'create_simple_sankey', 'create_budget_sankey', 'treemap',
    # 复合图表
    'create_combination_chart', 'create_grouped_bar_chart', 'create_grouped_boxplot',
    'create_multiline_chart', 'create_scatter_matrix', 'create_stacked_area_chart',
    'create_stacked_bar_chart', 'create_heatmap',
    # 工具
    'set_style', 'show_all', 'clear_all', 'get_version', 'set_chinese_font',
    # 核心工具
    'CodeSubmitter', 'process_data', 'main_function', 'chicken'
]

# 清理不需要在顶层暴露的模块名称（可选）
del plt