import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D


def scatter_3d(x=None, y=None, z=None, c=None, title="3D Scatter Plot"):
    """绘制3D散点图"""
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    if x is None:
        np.random.seed(42)
        n = 100
        x = np.random.randn(n)
        y = np.random.randn(n)
        z = np.random.randn(n)
        c = np.random.rand(n)

    scatter = ax.scatter(x, y, z, c=c, cmap='plasma', s=50, alpha=0.7)
    ax.set_title(title, fontsize=14, pad=20)

    return fig, ax, scatter