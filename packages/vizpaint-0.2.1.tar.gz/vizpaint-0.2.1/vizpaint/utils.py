"""
实用工具函数
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


def set_chinese_font():
    """设置中文字体支持"""
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    sns.set_style("whitegrid")


