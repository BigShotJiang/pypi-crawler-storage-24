"""
多线图（复式折线图）
"""

import matplotlib.pyplot as plt
from vizpaint.utils import set_chinese_font
import numpy as np

def create_multiline_chart(data, x_column, y_columns, title="多线图",
                           xlabel="X轴", ylabel="Y轴", figsize=(12, 8),
                           colors=None, legend_loc='upper right',
                           marker_style='o-', linewidth=2, markersize=8,
                           rotation=45):
    """
    创建多线图

    参数:
    ----------
    data : DataFrame
        包含数据的DataFrame
    x_column : str
        X轴列名
    y_columns : list
        要显示的Y轴列名列表
    title : str, optional
        图表标题
    xlabel : str, optional
        X轴标签
    ylabel : str, optional
        Y轴标签
    figsize : tuple, optional
        图表尺寸
    colors : list, optional
        颜色列表
    legend_loc : str, optional
        图例位置
    marker_style : str, optional
        标记样式
    linewidth : int, optional
        线宽
    markersize : int, optional
        标记大小
    rotation : int, optional
        X轴标签旋转角度

    返回:
    ----------
    fig, ax : 图表对象和坐标轴对象
    """
    set_chinese_font()
    fig, ax = plt.subplots(figsize=figsize)

    if colors is None:
        colors = plt.cm.Set3(np.linspace(0, 1, len(y_columns)))

    for i, col in enumerate(y_columns):
        ax.plot(data[x_column], data[col], marker_style,
                label=col, color=colors[i], linewidth=linewidth,
                markersize=markersize)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontsize=16, fontweight='bold')
    ax.legend(loc=legend_loc)
    ax.grid(True, alpha=0.3)

    # 旋转X轴标签
    if rotation != 0:
        plt.setp(ax.get_xticklabels(), rotation=rotation, ha='right')

    plt.tight_layout()
    return fig, ax