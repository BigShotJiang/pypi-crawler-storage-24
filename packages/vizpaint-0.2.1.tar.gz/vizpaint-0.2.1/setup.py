from setuptools import setup, find_packages

# 读取 README.md（如果不存在则用默认文本）
try:
    with open("README.md", "r", encoding="utf-8") as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = "A comprehensive Python data visualization library."

setup(
    name="vizpaint",
    version="0.2.1",
    author="zhouxinjun",
    author_email="369013027@qq.com",
    description="A comprehensive Python data visualization library.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://pypi.org/project/vizpaint/",
    packages=["vizpaint"],  # 只包含 vizpaint 包
    install_requires=["matplotlib>=3.3.0", "numpy>=1.19.0"],
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
