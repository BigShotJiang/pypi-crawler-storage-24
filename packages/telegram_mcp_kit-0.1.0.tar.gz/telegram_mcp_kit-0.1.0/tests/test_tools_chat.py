"""Tests for telegram_mcp.tools.chat."""

import json

from telegram_mcp.tools.chat import (
    ban_member,
    get_chat_admins,
    get_chat_info,
    get_chat_member_count,
    pin_message,
    set_chat_description,
    set_chat_title,
    unban_member,
    unpin_message,
)


async def test_get_chat_info(mock_client):
    mock_client.get_chat.return_value = {"id": 123, "type": "group"}
    result = await get_chat_info("123")
    assert json.loads(result)["type"] == "group"


async def test_get_chat_member_count(mock_client):
    mock_client.get_chat_member_count.return_value = 42
    result = await get_chat_member_count("123")
    assert "42" in result


async def test_get_chat_admins(mock_client):
    mock_client.get_chat_administrators.return_value = [{"user": {"id": 1}}]
    result = await get_chat_admins("123")
    assert len(json.loads(result)) == 1


async def test_ban_member(mock_client):
    mock_client.ban_chat_member.return_value = True
    result = await ban_member("123", 456)
    assert "banned" in result.lower()


async def test_unban_member(mock_client):
    mock_client.unban_chat_member.return_value = True
    result = await unban_member("123", 456)
    assert "unbanned" in result.lower()


async def test_set_chat_title(mock_client):
    mock_client.set_chat_title.return_value = True
    result = await set_chat_title("123", "New Title")
    assert "New Title" in result


async def test_set_chat_description(mock_client):
    mock_client.set_chat_description.return_value = True
    result = await set_chat_description("123", "desc")
    assert "updated" in result.lower()


async def test_pin_message(mock_client):
    mock_client.pin_chat_message.return_value = True
    result = await pin_message("123", 1)
    assert "pinned" in result.lower()


async def test_unpin_message(mock_client):
    mock_client.unpin_chat_message.return_value = True
    result = await unpin_message("123", 1)
    assert "unpinned" in result.lower()
