"""Tests for telegram_mcp.tools.messages."""

import json

from telegram_mcp.tools.messages import (
    delete_message,
    edit_message,
    forward_message,
    send_message,
)


async def test_send_message(mock_client):
    mock_client.send_message.return_value = {"message_id": 1, "text": "hi"}
    result = await send_message("123", "hi")
    parsed = json.loads(result)
    assert parsed["message_id"] == 1
    mock_client.send_message.assert_awaited_once_with("123", "hi", None, None)


async def test_send_message_with_options(mock_client):
    mock_client.send_message.return_value = {"message_id": 2}
    await send_message("123", "bold", parse_mode="HTML", reply_to_message_id=5)
    mock_client.send_message.assert_awaited_once_with("123", "bold", "HTML", 5)


async def test_edit_message(mock_client):
    mock_client.edit_message_text.return_value = {"message_id": 1, "text": "edited"}
    result = await edit_message("123", 1, "edited")
    parsed = json.loads(result)
    assert parsed["text"] == "edited"
    mock_client.edit_message_text.assert_awaited_once_with("123", 1, "edited", None)


async def test_delete_message(mock_client):
    mock_client.delete_message.return_value = True
    result = await delete_message("123", 1)
    assert "deleted" in result.lower()
    mock_client.delete_message.assert_awaited_once_with("123", 1)


async def test_forward_message(mock_client):
    mock_client.forward_message.return_value = {"message_id": 10}
    result = await forward_message("456", "123", 1)
    parsed = json.loads(result)
    assert parsed["message_id"] == 10
    mock_client.forward_message.assert_awaited_once_with("456", "123", 1)
