"""Chat management tools: info, members, admins, ban, pin, etc."""

import json

from telegram_mcp.tools._base import get_client, mcp


@mcp.tool()
async def get_chat_info(chat_id: str) -> str:
    """Get information about a chat (group, channel, or private chat).

    Args:
        chat_id: Chat ID or @channel_username
    """
    result = await get_client().get_chat(chat_id)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_chat_member_count(chat_id: str) -> str:
    """Get the number of members in a chat.

    Args:
        chat_id: Chat ID or @channel_username
    """
    count = await get_client().get_chat_member_count(chat_id)
    return f"Member count: {count}"


@mcp.tool()
async def get_chat_admins(chat_id: str) -> str:
    """Get list of administrators in a chat.

    Args:
        chat_id: Chat ID or @channel_username
    """
    result = await get_client().get_chat_administrators(chat_id)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def ban_member(chat_id: str, user_id: int) -> str:
    """Ban a user from a chat.

    Args:
        chat_id: Chat ID or @channel_username
        user_id: User ID to ban
    """
    await get_client().ban_chat_member(chat_id, user_id)
    return f"User {user_id} has been banned."


@mcp.tool()
async def unban_member(chat_id: str, user_id: int) -> str:
    """Unban a user from a chat.

    Args:
        chat_id: Chat ID or @channel_username
        user_id: User ID to unban
    """
    await get_client().unban_chat_member(chat_id, user_id)
    return f"User {user_id} has been unbanned."


@mcp.tool()
async def set_chat_title(chat_id: str, title: str) -> str:
    """Change the title of a chat (group/channel).

    Args:
        chat_id: Chat ID or @channel_username
        title: New chat title (1-128 characters)
    """
    await get_client().set_chat_title(chat_id, title)
    return f"Chat title changed to: {title}"


@mcp.tool()
async def set_chat_description(chat_id: str, description: str) -> str:
    """Change the description of a chat (group/channel).

    Args:
        chat_id: Chat ID or @channel_username
        description: New description (0-255 characters)
    """
    await get_client().set_chat_description(chat_id, description)
    return "Chat description updated."


@mcp.tool()
async def pin_message(
    chat_id: str, message_id: int, silent: bool = False
) -> str:
    """Pin a message in a chat.

    Args:
        chat_id: Chat ID or @channel_username
        message_id: ID of the message to pin
        silent: Pin without notification (default False)
    """
    await get_client().pin_chat_message(chat_id, message_id, silent)
    return "Message pinned."


@mcp.tool()
async def unpin_message(chat_id: str, message_id: int | None = None) -> str:
    """Unpin a message in a chat.

    Args:
        chat_id: Chat ID or @channel_username
        message_id: ID of message to unpin (optional, unpins most recent if not specified)
    """
    await get_client().unpin_chat_message(chat_id, message_id)
    return "Message unpinned."
