"""Message tools: send, edit, delete, forward."""

import json

from telegram_mcp.tools._base import get_client, mcp


@mcp.tool()
async def send_message(
    chat_id: str,
    text: str,
    parse_mode: str | None = None,
    reply_to_message_id: int | None = None,
) -> str:
    """Send a text message to a Telegram chat.

    Args:
        chat_id: Chat ID or @channel_username
        text: Message text (supports Markdown/HTML based on parse_mode)
        parse_mode: "Markdown", "MarkdownV2", or "HTML" (optional)
        reply_to_message_id: ID of message to reply to (optional)
    """
    result = await get_client().send_message(chat_id, text, parse_mode, reply_to_message_id)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def edit_message(
    chat_id: str,
    message_id: int,
    text: str,
    parse_mode: str | None = None,
) -> str:
    """Edit an existing message.

    Args:
        chat_id: Chat ID or @channel_username
        message_id: ID of the message to edit
        text: New text for the message
        parse_mode: "Markdown", "MarkdownV2", or "HTML" (optional)
    """
    result = await get_client().edit_message_text(chat_id, message_id, text, parse_mode)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def delete_message(chat_id: str, message_id: int) -> str:
    """Delete a message from a chat.

    Args:
        chat_id: Chat ID or @channel_username
        message_id: ID of the message to delete
    """
    await get_client().delete_message(chat_id, message_id)
    return "Message deleted successfully."


@mcp.tool()
async def forward_message(
    chat_id: str, from_chat_id: str, message_id: int
) -> str:
    """Forward a message from one chat to another.

    Args:
        chat_id: Target chat ID
        from_chat_id: Source chat ID
        message_id: ID of the message to forward
    """
    result = await get_client().forward_message(chat_id, from_chat_id, message_id)
    return json.dumps(result, ensure_ascii=False, indent=2)
