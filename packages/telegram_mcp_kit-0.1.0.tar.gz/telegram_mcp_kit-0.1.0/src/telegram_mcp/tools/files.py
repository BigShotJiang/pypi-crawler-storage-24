"""File and photo tools: send_photo, send_document, get_file_info."""

import json

from telegram_mcp.config import settings
from telegram_mcp.tools._base import get_client, mcp


@mcp.tool()
async def send_photo(
    chat_id: str,
    photo: str,
    caption: str | None = None,
    parse_mode: str | None = None,
) -> str:
    """Send a photo to a chat.

    Args:
        chat_id: Chat ID or @channel_username
        photo: Photo URL or file_id
        caption: Photo caption (optional)
        parse_mode: "Markdown", "MarkdownV2", or "HTML" for caption (optional)
    """
    result = await get_client().send_photo(chat_id, photo, caption, parse_mode)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def send_photo_file(
    chat_id: str,
    file_path: str,
    caption: str | None = None,
    parse_mode: str | None = None,
) -> str:
    """Send a local photo file to a chat.

    Args:
        chat_id: Chat ID or @channel_username
        file_path: Absolute path to the photo file on disk
        caption: Photo caption (optional)
        parse_mode: "Markdown", "MarkdownV2", or "HTML" for caption (optional)
    """
    result = await get_client().send_photo_file(chat_id, file_path, caption, parse_mode)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def send_document(
    chat_id: str,
    document: str,
    caption: str | None = None,
    parse_mode: str | None = None,
) -> str:
    """Send a document/file to a chat.

    Args:
        chat_id: Chat ID or @channel_username
        document: Document URL or file_id
        caption: Document caption (optional)
        parse_mode: "Markdown", "MarkdownV2", or "HTML" for caption (optional)
    """
    result = await get_client().send_document(chat_id, document, caption, parse_mode)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def send_document_file(
    chat_id: str,
    file_path: str,
    caption: str | None = None,
    parse_mode: str | None = None,
) -> str:
    """Send a local file as a document to a chat.

    Args:
        chat_id: Chat ID or @channel_username
        file_path: Absolute path to the file on disk
        caption: Document caption (optional)
        parse_mode: "Markdown", "MarkdownV2", or "HTML" for caption (optional)
    """
    result = await get_client().send_document_file(chat_id, file_path, caption, parse_mode)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_file_info(file_id: str) -> str:
    """Get file info and download link from Telegram.

    Args:
        file_id: Telegram file ID (from received messages)
    """
    result = await get_client().get_file(file_id)
    file_path = result.get("file_path", "")
    result["download_url"] = (
        f"https://api.telegram.org/file/bot{settings.telegram_bot_token}/{file_path}"
    )
    return json.dumps(result, ensure_ascii=False, indent=2)
