"""Telegram MCP Server - Entrypoint."""

from telegram_mcp.config import settings
from telegram_mcp.tools import discover_tools
from telegram_mcp.tools._base import mcp

discover_tools()


def main():
    mcp.run(transport=settings.mcp_transport)
