"""
Validation helper utilities for CIAF Core.

Provides utility functions to assist with data validation operations.
"""

from typing import Any, Type, TypeVar
from pydantic import BaseModel, ValidationError
from ..exceptions import CIAFValidationError

T = TypeVar("T", bound=BaseModel)


def validate_model(model_class: Type[T], data: dict[str, Any]) -> T:
    """
    Validate and instantiate a Pydantic model from a dictionary.

    Args:
        model_class: The Pydantic model class to instantiate
        data: Dictionary data to validate

    Returns:
        Validated model instance

    Raises:
        CIAFValidationError: If validation fails
    """
    try:
        return model_class(**data)
    except ValidationError as e:
        raise CIAFValidationError(f"Validation failed for {model_class.__name__}: {e}") from e
    except Exception as e:
        raise CIAFValidationError(f"Unexpected error validating {model_class.__name__}: {e}") from e


def validate_event_id(event_id: str) -> bool:
    """
    Validate that an event ID has the expected format.

    Args:
        event_id: Event ID to validate

    Returns:
        True if valid, False otherwise
    """
    if not event_id or not isinstance(event_id, str):
        return False

    # Basic validation: non-empty string
    # Can be extended with more specific format checks
    return len(event_id) > 0


def validate_hash(hash_str: str, expected_length: int = 64) -> bool:
    """
    Validate that a hash string has the expected format.

    Args:
        hash_str: Hash string to validate
        expected_length: Expected length of the hash (default: 64 for SHA-256)

    Returns:
        True if valid, False otherwise
    """
    if not hash_str or not isinstance(hash_str, str):
        return False

    # Check length
    if len(hash_str) != expected_length:
        return False

    # Check if hexadecimal
    try:
        int(hash_str, 16)
        return True
    except ValueError:
        return False


def validate_tenant_id(tenant_id: str) -> bool:
    """
    Validate that a tenant ID is well-formed.

    Args:
        tenant_id: Tenant ID to validate

    Returns:
        True if valid, False otherwise
    """
    if not tenant_id or not isinstance(tenant_id, str):
        return False

    # Basic validation: non-empty string with minimum length
    return len(tenant_id) >= 3


def is_valid_schema_version(version: str) -> bool:
    """
    Validate that a schema version follows semantic versioning.

    Args:
        version: Version string to validate

    Returns:
        True if valid semantic version, False otherwise
    """
    if not version or not isinstance(version, str):
        return False

    # Basic semantic version check (major.minor.patch)
    parts = version.split(".")
    if len(parts) != 3:
        return False

    try:
        # All parts should be non-negative integers
        return all(int(part) >= 0 for part in parts)
    except ValueError:
        return False


def validate_json_dict(data: Any) -> dict[str, Any]:
    """
    Validate that data is a dictionary suitable for JSON serialization.

    Args:
        data: Data to validate

    Returns:
        The validated dictionary

    Raises:
        CIAFValidationError: If data is not a valid dictionary
    """
    if not isinstance(data, dict):
        raise CIAFValidationError(f"Expected dict, got {type(data).__name__}")

    return data


def validate_required_fields(data: dict[str, Any], required_fields: list[str]) -> None:
    """
    Validate that all required fields are present in a dictionary.

    Args:
        data: Dictionary to validate
        required_fields: List of required field names

    Raises:
        CIAFValidationError: If any required field is missing
    """
    missing_fields = [field for field in required_fields if field not in data]

    if missing_fields:
        raise CIAFValidationError(f"Missing required fields: {', '.join(missing_fields)}")


def sanitize_string(value: str, max_length: int | None = None) -> str:
    """
    Sanitize a string value.

    Args:
        value: String to sanitize
        max_length: Optional maximum length

    Returns:
        Sanitized string

    Raises:
        CIAFValidationError: If value is not a string
    """
    if not isinstance(value, str):
        raise CIAFValidationError(f"Expected string, got {type(value).__name__}")

    # Strip whitespace
    sanitized = value.strip()

    # Truncate if needed
    if max_length and len(sanitized) > max_length:
        sanitized = sanitized[:max_length]

    return sanitized


def ensure_dict_keys_valid(data: dict[str, Any], allowed_keys: list[str] | None = None) -> None:
    """
    Validate that dictionary keys are in the allowed set.

    Args:
        data: Dictionary to validate
        allowed_keys: Optional list of allowed keys. If None, all keys are allowed.

    Raises:
        CIAFValidationError: If any key is not allowed
    """
    if allowed_keys is None:
        return

    invalid_keys = [key for key in data.keys() if key not in allowed_keys]

    if invalid_keys:
        raise CIAFValidationError(
            f"Invalid keys found: {', '.join(invalid_keys)}. "
            f"Allowed keys: {', '.join(allowed_keys)}"
        )


__all__ = [
    "validate_model",
    "validate_event_id",
    "validate_hash",
    "validate_tenant_id",
    "is_valid_schema_version",
    "validate_json_dict",
    "validate_required_fields",
    "sanitize_string",
    "ensure_dict_keys_valid",
]
