"""Utility functions for CIAF Core."""

__all__ = []
