# CIAF Core

[![Tests](https://github.com/DenzilGreenwood/ciaf_core/workflows/Tests/badge.svg)](https://github.com/DenzilGreenwood/ciaf_core/actions)
[![PyPI version](https://badge.fury.io/py/ciaf-core.svg)](https://badge.fury.io/py/ciaf-core)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: BUSL-1.1](https://img.shields.io/badge/License-BUSL--1.1-blue.svg)](LICENSE)

**Canonical schemas, validation, and cryptographic preparation utilities for CIAF processes.**

## Overview

`ciaf_core` is the canonical shared package that defines the common event, evidence, policy, lineage, and execution schemas used across all CIAF (Comprehensive Intelligence Audit Framework) processes, ensuring interoperability, deterministic validation, and cryptographic consistency across the CIAF ecosystem.

## Purpose

This package serves as the **shared contract layer** across the entire CIAF ecosystem, including:

- `ciaf_agents` - Agent instrumentation and governance
- `ciaf_web` - Web interfaces and dashboards
- `ciaf_vault` - Evidence storage and retrieval
- Model lifecycle pipelines
- Employee AI monitoring systems
- SDKs and APIs
- Evidence verification tools

## Key Features

- **Canonical Event Models** - Standardized schemas for all CIAF events
- **Deterministic Serialization** - Canonical JSON encoding for consistent hashing
- **Cryptographic Helpers** - SHA-256 hashing and payload preparation
- **ID Generation** - Unique identifier generation for events and entities
- **Validation Logic** - Pydantic-based validation for all schemas
- **Builder Functions** - Convenience constructors for common workflows
- **Extensible Design** - Support for custom extensions while maintaining core stability

## Installation

```bash
pip install ciaf-core
```

For development:

```bash
pip install ciaf-core[dev]
```

## Quick Start

```python
from ciaf_core import CIAFEvent, build_agent_tool_call_event, to_canonical_json, sha256_hex

# Build an event
event = build_agent_tool_call_event(
    tenant_id="tenant-123",
    source_system="ciaf_agents",
    actor_id="agent-456",
    actor_name="DataAnalysisAgent",
    subject_id="workflow-789",
    subject_name="Customer Data Analysis",
    tool_name="query_database",
    outcome="success",
)

# Canonicalize and hash
canonical = to_canonical_json(event)
content_hash = sha256_hex(canonical)

print(f"Event ID: {event.event_id}")
print(f"Content Hash: {content_hash}")
```

### Cryptographic Signing (Evidence Envelope)

Sign events for non-repudiation and authenticity:

```python
from ciaf_core import (
    CIAFEvent,
    SignedEvent,
    generate_ed25519_keypair,
    sign_payload,
    to_canonical_json,
    compute_payload_hash,
)

# Generate keypair (do this once, store private key securely)
private_key, public_key = generate_ed25519_keypair()

# Create an event
event = build_agent_tool_call_event(
    tenant_id="tenant-123",
    source_system="ciaf_agents",
    actor_id="agent-456",
    actor_name="DataAnalysisAgent",
    subject_id="workflow-789",
    subject_name="Customer Data Analysis",
    tool_name="query_database",
    outcome="success",
)

# Create signed envelope
payload_json = to_canonical_json(event)
signature = sign_payload(payload_json, private_key, "Ed25519")
payload_hash = compute_payload_hash(payload_json)

signed_event = SignedEvent(
    payload=event.model_dump(),
    payload_hash=payload_hash,
    signer_id="agent:data-analysis-v1",
    signature=signature,
    signature_algorithm="Ed25519",
    public_key_ref="key:vault:/agents/data-analysis.pub",
)

# Later: Verify the signature
is_valid = signed_event.verify(public_key)
if not is_valid:
    raise Exception("Invalid signature - event may have been tampered with!")

# Extract the original event
original_event = signed_event.get_event()
```

#### Supported Signature Algorithms

- **Ed25519** (recommended) - Fast, modern, secure elliptic curve signatures
- **RSA-PSS-SHA256** - Traditional RSA with PSS padding (2048, 3072, or 4096 bit keys)
- **ECDSA-P256-SHA256** - NIST P-256 elliptic curve signatures

#### Benefits of SignedEvent

1. **Non-repudiation** - Cryptographic proof of who created the event
2. **Integrity** - Detect any tampering with event data
3. **Authentication** - Verify the source before accepting events
4. **Chain of Custody** - Support for parent signatures and delegation
5. **Self-Contained Verification** - Optional inline public keys for portability

## Core Schemas

### Actor
Represents the entity performing an action (human, agent, service, model, system).

### Subject
Represents the target of an action (agent, model, dataset, workflow, policy, case, document).

### Action
Represents the operation performed and its outcome.

### CIAFEvent
The canonical event structure containing actor, subject, action, and metadata.

### PolicyDecision
Records policy evaluation results and enforcement decisions.

### RiskAssessment
Captures risk analysis and scoring information.

### ExecutionContext
Describes the runtime environment and execution parameters.

### EvidenceRecord
Links events to cryptographic evidence in the vault.

### SignedEvent
Cryptographically signed envelope wrapping a CIAFEvent with signature metadata, providing non-repudiation and tamper detection.


## Package Structure

```python
ciaf_core/
├── pyproject.toml
├── README.md
├── LICENSE
├── __init__.py
├── version.py
├── enums.py
├── exceptions.py
├── schemas/
│   ├── __init__.py
│   ├── event.py
│   ├── actor.py
│   ├── subject.py
│   ├── action.py
│   ├── policy.py
│   ├── risk.py
│   ├── execution.py
│   ├── evidence.py
│   ├── signed_event.py
│   └── ...
├── canonicalization/
│   └── __init__.py
├── hashing/
│   └── __init__.py
├── signing/
│   └── __init__.py
├── IDs/
│   └── __init__.py
├── validation_helpers/
│   └── __init__.py
└── builders/
    └── __init__.py

```

## Versioning

This package uses semantic versioning:
- **Package version**: `0.1.0` (this package)
- **Schema version**: `1.0.0` (embedded in event records)

### Compatibility Rules

- Minor version bumps: backward-compatible additions only
- Major version bumps: breaking field changes
- Patch version bumps: bug fixes, documentation

## Contributing

This is the foundational package for the CIAF ecosystem. Changes must be carefully reviewed to ensure:

1. Backward compatibility is maintained (or properly versioned)
2. Canonical serialization remains deterministic
3. All changes include tests
4. Documentation is updated

## License

Business Source License 1.1 (BUSL-1.1) - See [LICENSE](LICENSE) file for details.

**Key Points:**
- Free for non-commercial use, research, and evaluation
- Converts to Apache 2.0 on January 1, 2029
- Commercial use requires a license from Founder@CognitiveInsight.ai

For commercial licensing inquiries: **Founder@CognitiveInsight.ai**

## Contact & Support

- **Repository**: https://github.com/DenzilGreenwood/ciaf_core
- **Issues**: https://github.com/DenzilGreenwood/ciaf_core/issues
- **Commercial Licensing**: Founder@CognitiveInsight.ai
- **Website**: https://CognitiveInsight.ai

## Schema Version

Current schema version: **1.0.0**

## Author

**Denzil James Greenwood**  
Founder@CognitiveInsight.ai  
CognitiveInsight.ai
