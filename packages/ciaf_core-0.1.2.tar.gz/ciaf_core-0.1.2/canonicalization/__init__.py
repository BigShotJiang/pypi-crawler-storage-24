"""
Canonicalization utilities for CIAF Core.

Provides deterministic serialization of CIAF models to ensure consistent hashing.
"""

import json
from typing import Any
from pydantic import BaseModel
from ..exceptions import CIAFCanonializationError


def to_canonical_dict(model: BaseModel, exclude_none: bool = True) -> dict[str, Any]:
    """
    Convert a Pydantic model to a canonical dictionary representation.

    Args:
        model: The Pydantic model to convert
        exclude_none: Whether to exclude None values (default: True)

    Returns:
        Dictionary with canonical representation

    Raises:
        CIAFCanonializationError: If canonicalization fails
    """
    try:
        return model.model_dump(
            exclude_none=exclude_none,
            by_alias=True,
            mode="json",
        )
    except Exception as e:
        raise CIAFCanonializationError(f"Failed to convert model to canonical dict: {e}") from e


def to_canonical_json(
    model: BaseModel,
    exclude_none: bool = True,
    sort_keys: bool = True,
) -> str:
    """
    Convert a Pydantic model to canonical JSON string.

    This ensures deterministic serialization for cryptographic operations.

    Args:
        model: The Pydantic model to convert
        exclude_none: Whether to exclude None values (default: True)
        sort_keys: Whether to sort dictionary keys (default: True)

    Returns:
        Canonical JSON string representation

    Raises:
        CIAFCanonializationError: If canonicalization fails
    """
    try:
        canonical_dict = to_canonical_dict(model, exclude_none=exclude_none)
        return json.dumps(
            canonical_dict,
            sort_keys=sort_keys,
            separators=(",", ":"),
            ensure_ascii=False,
        )
    except Exception as e:
        raise CIAFCanonializationError(f"Failed to convert model to canonical JSON: {e}") from e


def dict_to_canonical_json(data: dict[str, Any], sort_keys: bool = True) -> str:
    """
    Convert a dictionary to canonical JSON string.

    Useful for hashing arbitrary dictionaries consistently.

    Args:
        data: Dictionary to convert
        sort_keys: Whether to sort dictionary keys (default: True)

    Returns:
        Canonical JSON string representation

    Raises:
        CIAFCanonializationError: If canonicalization fails
    """
    try:
        return json.dumps(
            data,
            sort_keys=sort_keys,
            separators=(",", ":"),
            ensure_ascii=False,
        )
    except Exception as e:
        raise CIAFCanonializationError(f"Failed to convert dict to canonical JSON: {e}") from e


__all__ = [
    "to_canonical_dict",
    "to_canonical_json",
    "dict_to_canonical_json",
]
