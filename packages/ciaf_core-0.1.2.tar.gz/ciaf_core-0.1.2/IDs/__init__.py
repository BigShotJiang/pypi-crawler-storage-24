"""
ID generation and management utilities for CIAF Core.

Provides functions for generating unique identifiers for events and entities.
"""

import uuid
import secrets
from datetime import datetime, timezone
from ..exceptions import CIAFIDGenerationError


def new_event_id(prefix: str = "evt") -> str:
    """
    Generate a new unique event ID.

    Format: {prefix}_{timestamp}_{random}
    Example: evt_20240321_abc123xyz

    Args:
        prefix: Prefix for the event ID (default: "evt")

    Returns:
        Unique event ID string

    Raises:
        CIAFIDGenerationError: If ID generation fails
    """
    try:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
        random_suffix = secrets.token_hex(8)  # 16 characters
        return f"{prefix}_{timestamp}_{random_suffix}"
    except Exception as e:
        raise CIAFIDGenerationError(f"Failed to generate event ID: {e}") from e


def new_entity_id(entity_type: str, prefix: str = "") -> str:
    """
    Generate a new unique entity ID.

    Format: {prefix}{entity_type}_{uuid}
    Example: agent_550e8400-e29b-41d4-a716-446655440000

    Args:
        entity_type: Type of entity (e.g., "agent", "model", "policy")
        prefix: Optional prefix (default: "")

    Returns:
        Unique entity ID string

    Raises:
        CIAFIDGenerationError: If ID generation fails
    """
    try:
        unique_id = str(uuid.uuid4())
        if prefix:
            return f"{prefix}{entity_type}_{unique_id}"
        return f"{entity_type}_{unique_id}"
    except Exception as e:
        raise CIAFIDGenerationError(f"Failed to generate entity ID: {e}") from e


def new_uuid() -> str:
    """
    Generate a new UUID v4.

    Returns:
        UUID string (e.g., "550e8400-e29b-41d4-a716-446655440000")

    Raises:
        CIAFIDGenerationError: If UUID generation fails
    """
    try:
        return str(uuid.uuid4())
    except Exception as e:
        raise CIAFIDGenerationError(f"Failed to generate UUID: {e}") from e


def new_ulid() -> str:
    """
    Generate a new ULID (Universally Unique Lexicographically Sortable Identifier).

    Note: This is a simplified implementation. For production use, consider
    installing the 'python-ulid' package for full ULID support.

    Returns:
        ULID-like string based on timestamp and randomness

    Raises:
        CIAFIDGenerationError: If ULID generation fails
    """
    try:
        # Simplified ULID: timestamp in milliseconds + random bytes
        timestamp_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
        random_part = secrets.token_hex(10)  # 20 characters
        return f"{timestamp_ms:013x}{random_part}"
    except Exception as e:
        raise CIAFIDGenerationError(f"Failed to generate ULID: {e}") from e


def new_short_id(length: int = 12) -> str:
    """
    Generate a short random ID.

    Useful for correlation IDs, request IDs, etc.

    Args:
        length: Length of the ID in characters (default: 12)

    Returns:
        Random hexadecimal ID string

    Raises:
        CIAFIDGenerationError: If ID generation fails
    """
    try:
        if length < 4:
            raise ValueError("Length must be at least 4 characters")
        byte_length = (length + 1) // 2
        return secrets.token_hex(byte_length)[:length]
    except Exception as e:
        raise CIAFIDGenerationError(f"Failed to generate short ID: {e}") from e


def new_correlation_id() -> str:
    """
    Generate a new correlation ID for tracing across systems.

    Returns:
        Correlation ID string

    Raises:
        CIAFIDGenerationError: If correlation ID generation fails
    """
    try:
        return f"corr_{new_short_id(16)}"
    except Exception as e:
        raise CIAFIDGenerationError(f"Failed to generate correlation ID: {e}") from e


def new_decision_id(prefix: str = "dec") -> str:
    """
    Generate a new unique decision ID.

    Args:
        prefix: Prefix for the decision ID (default: "dec")

    Returns:
        Unique decision ID string

    Raises:
        CIAFIDGenerationError: If decision ID generation fails
    """
    try:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
        random_suffix = secrets.token_hex(6)  # 12 characters
        return f"{prefix}_{timestamp}_{random_suffix}"
    except Exception as e:
        raise CIAFIDGenerationError(f"Failed to generate decision ID: {e}") from e


def new_assessment_id(prefix: str = "assess") -> str:
    """
    Generate a new unique assessment ID.

    Args:
        prefix: Prefix for the assessment ID (default: "assess")

    Returns:
        Unique assessment ID string

    Raises:
        CIAFIDGenerationError: If assessment ID generation fails
    """
    try:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
        random_suffix = secrets.token_hex(6)  # 12 characters
        return f"{prefix}_{timestamp}_{random_suffix}"
    except Exception as e:
        raise CIAFIDGenerationError(f"Failed to generate assessment ID: {e}") from e


__all__ = [
    "new_event_id",
    "new_entity_id",
    "new_uuid",
    "new_ulid",
    "new_short_id",
    "new_correlation_id",
    "new_decision_id",
    "new_assessment_id",
]
