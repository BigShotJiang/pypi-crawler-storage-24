"""Evidence record schema for CIAF Core."""

from datetime import datetime
from typing import Any
from pydantic import BaseModel, Field, ConfigDict
from ..enums import EvidenceType


class EvidenceRecord(BaseModel):
    """
    Evidence record linking events to cryptographic proof.

    Used by the vault to track immutable evidence.
    """

    evidence_id: str = Field(
        ...,
        description="Unique identifier for this evidence record",
        min_length=1,
    )
    evidence_type: EvidenceType = Field(
        ...,
        description="Type of evidence",
    )
    created_at_utc: datetime = Field(
        ...,
        description="When the evidence was created (UTC)",
    )

    # Source event
    source_event_id: str = Field(
        ...,
        description="ID of the event this evidence relates to",
    )
    source_event_type: str = Field(
        ...,
        description="Type of the source event",
    )

    # Cryptographic proof
    content_hash: str = Field(
        ...,
        description="SHA-256 hash of the evidence content",
        min_length=64,
        max_length=64,
    )
    signature: str | None = Field(
        default=None,
        description="Cryptographic signature of the evidence",
    )
    merkle_root: str | None = Field(
        default=None,
        description="Merkle tree root hash (for batched evidence)",
    )
    merkle_proof: list[str] = Field(
        default_factory=list,
        description="Merkle proof path for this evidence",
    )

    # Storage
    storage_location: str | None = Field(
        default=None,
        description="WORM storage location or URI",
    )
    vault_id: str | None = Field(
        default=None,
        description="Vault instance identifier",
    )

    # Verification
    verified: bool = Field(
        default=False,
        description="Whether the evidence has been verified",
    )
    verification_timestamp_utc: datetime | None = Field(
        default=None,
        description="When the evidence was verified (UTC)",
    )

    # Metadata
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional evidence metadata",
    )

    model_config = ConfigDict(use_enum_values=True)
