"""Subject schema for CIAF Core."""

from typing import Any
from pydantic import BaseModel, Field, ConfigDict
from ..enums import SubjectType


class Subject(BaseModel):
    """
    Represents the target of an action.

    Can be an agent, model, dataset, workflow, policy, case, document, etc.
    """

    subject_id: str = Field(
        ...,
        description="Unique identifier for the subject",
        min_length=1,
    )
    subject_type: SubjectType = Field(
        ...,
        description="Type of subject",
    )
    subject_name: str | None = Field(
        default=None,
        description="Human-readable name for the subject",
    )
    subject_version: str | None = Field(
        default=None,
        description="Version of the subject (e.g., model version, policy version)",
    )
    owner_id: str | None = Field(
        default=None,
        description="ID of the entity that owns this subject",
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Tags or labels associated with the subject",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional subject metadata",
    )

    model_config = ConfigDict(
        use_enum_values=True,
        json_schema_extra={
            "examples": [
                {
                    "subject_id": "model-gpt4-prod-001",
                    "subject_type": "model",
                    "subject_name": "GPT-4 Production Deployment",
                    "subject_version": "2024.03.21",
                    "owner_id": "team-ml-ops",
                    "tags": ["production", "llm", "approved"],
                }
            ]
        },
    )
