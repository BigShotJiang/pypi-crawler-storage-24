"""Signed event envelope for authenticated CIAF events.

The SignedEvent provides cryptographic proof of authenticity and integrity.
"""

from datetime import datetime, timezone
from typing import Any
from pydantic import BaseModel, Field, ConfigDict, field_validator

from .event import CIAFEvent
from ..signing import SignatureAlgorithm, verify_signature, compute_payload_hash
from ..canonicalization import to_canonical_json


class SignedEvent(BaseModel):
    """
    Evidence envelope wrapping a CIAF event with cryptographic signature.

    This wrapper provides:
    - Non-repudiation: Proof of who created the event
    - Integrity: Detection of tampering
    - Authentication: Verification of source

    The payload is stored as canonical JSON to ensure deterministic verification.

    Example:
        >>> from ciaf_core import CIAFEvent, SignedEvent, sign_payload, generate_ed25519_keypair
        >>>
        >>> # Generate keys
        >>> private_key, public_key = generate_ed25519_keypair()
        >>>
        >>> # Create and sign event
        >>> event = CIAFEvent(...)
        >>> payload_json = to_canonical_json(event)
        >>> signature = sign_payload(payload_json, private_key, "Ed25519")
        >>>
        >>> # Create signed envelope
        >>> signed = SignedEvent(
        ...     payload=event.model_dump(),
        ...     payload_hash=compute_payload_hash(payload_json),
        ...     signer_id="agent:model-deployer-v1",
        ...     signature=signature,
        ...     signature_algorithm="Ed25519",
        ...     public_key_ref="key:vault:/keys/agent-deployer.pub"
        ... )
        >>>
        >>> # Verify later
        >>> is_valid = signed.verify(public_key)
    """

    model_config = ConfigDict(
        extra="forbid",
        str_strip_whitespace=True,
        frozen=True,  # Immutable after creation
    )

    # Payload
    payload: dict[str, Any] = Field(
        ...,
        description="The CIAFEvent data as a dictionary",
    )
    payload_hash: str = Field(
        ...,
        description="SHA-256 hash of the canonical JSON payload",
        min_length=64,
        max_length=64,
    )

    # Signature metadata
    signer_id: str = Field(
        ...,
        description="Identifier of the entity that signed this event (e.g., 'agent:gpt4', 'user:alice')",
        min_length=1,
    )
    signature: str = Field(
        ...,
        description="Base64-encoded cryptographic signature of the canonical payload",
        min_length=1,
    )
    signature_algorithm: SignatureAlgorithm = Field(
        ...,
        description="Algorithm used to create the signature",
    )
    signed_at_utc: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="When the signature was created (UTC)",
    )

    # Public key reference
    public_key_ref: str = Field(
        ...,
        description="Reference to the public key for verification (URI, key ID, or inline key)",
        min_length=1,
    )
    public_key_inline: str | None = Field(
        default=None,
        description="Optional inline public key in PEM format for self-contained verification",
    )

    # Chain of trust
    parent_signature: str | None = Field(
        default=None,
        description="Optional signature of a parent/delegating entity for chain of custody",
    )

    @field_validator("payload")
    @classmethod
    def validate_payload_structure(cls, v: dict[str, Any]) -> dict[str, Any]:
        """Ensure payload can be parsed as a CIAFEvent."""
        try:
            # Validate it's a valid CIAFEvent
            CIAFEvent.model_validate(v)
            return v
        except Exception as e:
            raise ValueError(f"Payload is not a valid CIAFEvent: {e}") from e

    def get_event(self) -> CIAFEvent:
        """
        Parse and return the embedded CIAFEvent.

        Returns:
            The CIAFEvent from the payload

        Example:
            >>> signed_event = SignedEvent(...)
            >>> event = signed_event.get_event()
            >>> print(event.action.action_type)
        """
        return CIAFEvent.model_validate(self.payload)

    def get_canonical_payload(self) -> str:
        """
        Get the canonical JSON representation of the payload.

        Returns:
            Canonical JSON string (deterministic, sorted keys)
        """
        event = self.get_event()
        return to_canonical_json(event)

    def verify(self, public_key_pem: bytes) -> bool:
        """
        Verify the signature using the provided public key.

        Args:
            public_key_pem: Public key in PEM format

        Returns:
            True if signature is valid, False otherwise

        Raises:
            ValueError: If verification fails due to configuration errors

        Example:
            >>> signed_event = SignedEvent(...)
            >>> with open("public_key.pem", "rb") as f:
            ...     public_key = f.read()
            >>> if not signed_event.verify(public_key):
            ...     raise Exception("Invalid signature!")
        """
        canonical_payload = self.get_canonical_payload()

        # Verify payload hash matches
        computed_hash = compute_payload_hash(canonical_payload)
        if computed_hash != self.payload_hash:
            return False

        # Verify signature
        return verify_signature(
            canonical_payload, self.signature, public_key_pem, self.signature_algorithm
        )

    def verify_payload_integrity(self) -> bool:
        """
        Verify that the payload hash matches the canonical payload.

        This checks for tampering without needing the public key.

        Returns:
            True if payload hash is valid, False otherwise
        """
        canonical_payload = self.get_canonical_payload()
        computed_hash = compute_payload_hash(canonical_payload)
        return computed_hash == self.payload_hash


__all__ = ["SignedEvent"]
