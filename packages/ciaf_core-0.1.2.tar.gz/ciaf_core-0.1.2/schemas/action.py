"""Action schema for CIAF Core."""

from typing import Any
from pydantic import BaseModel, Field, ConfigDict
from ..enums import ActionType, ActionOutcome


class Action(BaseModel):
    """
    Represents an action performed and its outcome.

    Includes the action type, name, parameters, outcome, and reason.
    """

    action_type: ActionType = Field(
        ...,
        description="Type of action performed",
    )
    action_name: str = Field(
        ...,
        description="Specific name of the action",
        min_length=1,
    )
    intent: str | None = Field(
        default=None,
        description="Stated intent or purpose of the action",
    )
    outcome: ActionOutcome = Field(
        ...,
        description="Outcome of the action (success, blocked, failed, partial, pending)",
    )
    reason: str | None = Field(
        default=None,
        description="Explanation of the outcome (especially for blocks/failures)",
    )
    parameters: dict[str, Any] = Field(
        default_factory=dict,
        description="Parameters or arguments used in the action",
    )
    duration_ms: int | None = Field(
        default=None,
        description="Duration of the action in milliseconds",
        ge=0,
    )
    error_code: str | None = Field(
        default=None,
        description="Error code if the action failed",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional action metadata",
    )

    model_config = ConfigDict(
        use_enum_values=True,
        json_schema_extra={
            "examples": [
                {
                    "action_type": "execute",
                    "action_name": "query_customer_database",
                    "intent": "Retrieve customer demographics for analysis",
                    "outcome": "success",
                    "parameters": {
                        "query": "SELECT age, region FROM customers WHERE active=true",
                        "limit": 1000,
                    },
                    "duration_ms": 234,
                }
            ]
        },
    )
