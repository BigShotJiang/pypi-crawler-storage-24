"""Execution context schema for CIAF Core."""

from typing import Any
from pydantic import BaseModel, Field


class ExecutionContext(BaseModel):
    """
    Execution context information.

    Describes the runtime environment and execution parameters.
    """

    execution_id: str = Field(
        ...,
        description="Unique identifier for this execution instance",
        min_length=1,
    )

    # Environment
    environment: str = Field(
        ...,
        description="Execution environment (e.g., 'production', 'staging', 'development')",
    )
    region: str | None = Field(
        default=None,
        description="Geographic region or data center",
    )
    availability_zone: str | None = Field(
        default=None,
        description="Availability zone within region",
    )

    # Runtime
    runtime_type: str | None = Field(
        default=None,
        description="Type of runtime (e.g., 'kubernetes', 'lambda', 'vm')",
    )
    runtime_version: str | None = Field(
        default=None,
        description="Version of the runtime",
    )

    # Process information
    process_id: str | None = Field(
        default=None,
        description="Process or container ID",
    )
    thread_id: str | None = Field(
        default=None,
        description="Thread ID if applicable",
    )

    # Workflow context
    workflow_id: str | None = Field(
        default=None,
        description="Parent workflow ID",
    )
    step_id: str | None = Field(
        default=None,
        description="Workflow step ID",
    )
    correlation_id: str | None = Field(
        default=None,
        description="Correlation ID for tracing across systems",
    )
    request_id: str | None = Field(
        default=None,
        description="Original request ID",
    )

    # Resource usage
    resource_usage: dict[str, Any] = Field(
        default_factory=dict,
        description="Resource usage metrics (CPU, memory, etc.)",
    )

    # Additional context
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional execution context",
    )
