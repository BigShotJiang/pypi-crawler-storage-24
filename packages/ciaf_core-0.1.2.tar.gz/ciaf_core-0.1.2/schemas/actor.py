"""Actor schema for CIAF Core."""

from typing import Any
from pydantic import BaseModel, Field, ConfigDict
from ..enums import ActorType


class Actor(BaseModel):
    """
    Represents the entity performing an action.

    Can be a human, agent, service, model, or system.
    """

    actor_id: str = Field(
        ...,
        description="Unique identifier for the actor",
        min_length=1,
    )
    actor_type: ActorType = Field(
        ...,
        description="Type of actor (human, agent, service, model, system)",
    )
    display_name: str | None = Field(
        default=None,
        description="Human-readable name for the actor",
    )
    organization_role: str | None = Field(
        default=None,
        description="Role within the organization (e.g., 'analyst', 'admin')",
    )
    email: str | None = Field(
        default=None,
        description="Email address (for human actors)",
    )
    department: str | None = Field(
        default=None,
        description="Department or team",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional actor metadata",
    )

    model_config = ConfigDict(
        use_enum_values=True,
        json_schema_extra={
            "examples": [
                {
                    "actor_id": "user-123",
                    "actor_type": "human",
                    "display_name": "Jane Smith",
                    "organization_role": "data_analyst",
                    "email": "jane.smith@example.com",
                    "department": "analytics",
                }
            ]
        },
    )
