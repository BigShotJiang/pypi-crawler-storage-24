"""Risk assessment schema for CIAF Core."""

from datetime import datetime
from typing import Any
from pydantic import BaseModel, Field, ConfigDict
from ..enums import RiskLevel


class RiskFactor(BaseModel):
    """Individual risk factor contributing to overall assessment."""

    factor_id: str = Field(
        ...,
        description="Identifier for this risk factor",
    )
    factor_name: str = Field(
        ...,
        description="Name of the risk factor",
    )
    score: float = Field(
        ...,
        description="Risk score for this factor (0.0 to 1.0)",
        ge=0.0,
        le=1.0,
    )
    weight: float = Field(
        ...,
        description="Weight of this factor in overall risk (0.0 to 1.0)",
        ge=0.0,
        le=1.0,
    )
    description: str | None = Field(
        default=None,
        description="Description of why this factor contributes to risk",
    )


class RiskAssessment(BaseModel):
    """
    Risk assessment record.

    Captures risk analysis and scoring for an event or action.
    """

    assessment_id: str = Field(
        ...,
        description="Unique identifier for this assessment",
        min_length=1,
    )
    timestamp_utc: datetime = Field(
        ...,
        description="When the assessment was performed (UTC)",
    )
    assessed_entity_id: str = Field(
        ...,
        description="ID of the entity being assessed",
    )
    assessed_entity_type: str = Field(
        ...,
        description="Type of entity being assessed",
    )

    # Risk scoring
    risk_level: RiskLevel = Field(
        ...,
        description="Overall risk level classification",
    )
    risk_score: float = Field(
        ...,
        description="Numerical risk score (0.0 to 1.0)",
        ge=0.0,
        le=1.0,
    )
    confidence: float = Field(
        ...,
        description="Confidence in the assessment (0.0 to 1.0)",
        ge=0.0,
        le=1.0,
    )

    # Risk factors
    risk_factors: list[RiskFactor] = Field(
        default_factory=list,
        description="Individual risk factors analyzed",
    )

    # Recommendations
    mitigation_recommended: bool = Field(
        default=False,
        description="Whether mitigation is recommended",
    )
    mitigation_actions: list[str] = Field(
        default_factory=list,
        description="Recommended mitigation actions",
    )

    # Context
    assessment_methodology: str | None = Field(
        default=None,
        description="Methodology or model used for assessment",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional assessment metadata",
    )

    model_config = ConfigDict(use_enum_values=True)
