"""Resource schema for CIAF Core."""

from typing import Any
from pydantic import BaseModel, Field, ConfigDict
from ..enums import ResourceType


class Resource(BaseModel):
    """
    Represents a resource involved in an action.

    Can be a database, API, file, model, dataset, service, credential, etc.
    """

    resource_id: str = Field(
        ...,
        description="Unique identifier for the resource",
        min_length=1,
    )
    resource_type: ResourceType = Field(
        ...,
        description="Type of resource",
    )
    resource_name: str | None = Field(
        default=None,
        description="Human-readable name for the resource",
    )
    resource_uri: str | None = Field(
        default=None,
        description="URI or path to the resource",
    )
    classification: str | None = Field(
        default=None,
        description="Data classification level (e.g., 'public', 'confidential', 'restricted')",
    )
    owner_id: str | None = Field(
        default=None,
        description="ID of the entity that owns this resource",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional resource metadata",
    )

    model_config = ConfigDict(
        use_enum_values=True,
        json_schema_extra={
            "examples": [
                {
                    "resource_id": "db-customer-data-prod",
                    "resource_type": "database",
                    "resource_name": "Customer Database (Production)",
                    "resource_uri": "postgresql://prod.example.com/customers",
                    "classification": "confidential",
                    "owner_id": "team-data-engineering",
                }
            ]
        },
    )
