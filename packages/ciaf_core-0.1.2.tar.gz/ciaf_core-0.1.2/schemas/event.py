"""Main CIAF Event schema."""

from datetime import datetime
from typing import Any
from pydantic import BaseModel, Field, ConfigDict
from ..enums import EventCategory
from .actor import Actor
from .subject import Subject
from .resource import Resource
from .action import Action


class CIAFEvent(BaseModel):
    """
    Canonical CIAF event structure.

    This is the primary schema for all CIAF events across the ecosystem.
    """

    # Schema and identification
    schema_version: str = Field(
        default="1.0.0",
        description="Version of the CIAF schema",
    )
    event_id: str = Field(
        ...,
        description="Unique identifier for this event",
        min_length=1,
    )
    event_type: str = Field(
        ...,
        description="Specific type of event (e.g., 'agent.tool_call', 'model.deployment')",
        min_length=1,
    )
    event_category: EventCategory = Field(
        ...,
        description="High-level category of the event",
    )

    # Timestamps
    timestamp_utc: datetime = Field(
        ...,
        description="When the event occurred (UTC)",
    )
    recorded_at_utc: datetime = Field(
        ...,
        description="When the event was recorded in the system (UTC)",
    )

    # Tenant and source
    tenant_id: str = Field(
        ...,
        description="Tenant/organization identifier",
        min_length=1,
    )
    source_system: str = Field(
        ...,
        description="System that generated the event (e.g., 'ciaf_agents', 'ciaf_web')",
        min_length=1,
    )

    # Core entities
    actor: Actor = Field(
        ...,
        description="Entity performing the action",
    )
    subject: Subject = Field(
        ...,
        description="Target of the action",
    )
    action: Action = Field(
        ...,
        description="Action performed and its outcome",
    )

    # Optional entities
    resources: list[Resource] = Field(
        default_factory=list,
        description="Resources involved in the action",
    )

    # Context and extensions
    context: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional context for the event",
    )
    extensions: dict[str, Any] = Field(
        default_factory=dict,
        description="Product-specific extensions",
    )

    # Cryptographic fields (populated by vault)
    content_hash: str | None = Field(
        default=None,
        description="SHA-256 hash of the canonical event content",
    )
    signature: str | None = Field(
        default=None,
        description="Cryptographic signature of the event",
    )

    model_config = ConfigDict(
        use_enum_values=True,
        json_schema_extra={
            "examples": [
                {
                    "schema_version": "1.0.0",
                    "event_id": "evt_2024_03_21_abc123",
                    "event_type": "agent.tool_call",
                    "event_category": "execution",
                    "timestamp_utc": "2024-03-21T15:30:00Z",
                    "recorded_at_utc": "2024-03-21T15:30:01Z",
                    "tenant_id": "tenant-acme-corp",
                    "source_system": "ciaf_agents",
                    "actor": {
                        "actor_id": "agent-data-analyst-001",
                        "actor_type": "agent",
                        "display_name": "Data Analysis Agent",
                    },
                    "subject": {
                        "subject_id": "workflow-customer-insights",
                        "subject_type": "workflow",
                        "subject_name": "Customer Insights Workflow",
                    },
                    "action": {
                        "action_type": "execute",
                        "action_name": "query_database",
                        "outcome": "success",
                        "parameters": {"table": "customers", "limit": 1000},
                    },
                }
            ]
        },
    )
