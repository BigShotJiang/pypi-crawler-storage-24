"""Governance mapping schema for CIAF Core."""

from typing import Any
from pydantic import BaseModel, Field


class ComplianceFramework(BaseModel):
    """Reference to a compliance framework."""

    framework_id: str = Field(
        ...,
        description="Identifier for the compliance framework",
    )
    framework_name: str = Field(
        ...,
        description="Name of the framework (e.g., 'SOC2', 'GDPR', 'HIPAA')",
    )
    version: str | None = Field(
        default=None,
        description="Version of the framework",
    )
    control_ids: list[str] = Field(
        default_factory=list,
        description="Specific control IDs this maps to",
    )


class GovernanceMapping(BaseModel):
    """
    Governance and compliance mapping.

    Maps events to compliance frameworks and regulatory requirements.
    """

    entity_id: str = Field(
        ...,
        description="ID of the entity being mapped",
        min_length=1,
    )
    entity_type: str = Field(
        ...,
        description="Type of entity",
    )

    # Compliance frameworks
    frameworks: list[ComplianceFramework] = Field(
        default_factory=list,
        description="Compliance frameworks this entity relates to",
    )

    # Governance classification
    business_process: str | None = Field(
        default=None,
        description="Business process category",
    )
    risk_category: str | None = Field(
        default=None,
        description="Risk category classification",
    )
    data_classification: str | None = Field(
        default=None,
        description="Data classification level",
    )

    # Audit requirements
    audit_required: bool = Field(
        default=False,
        description="Whether this requires audit trail",
    )
    retention_period_days: int | None = Field(
        default=None,
        description="Required retention period in days",
        ge=0,
    )

    # Tags and labels
    governance_tags: list[str] = Field(
        default_factory=list,
        description="Governance-related tags",
    )

    # Metadata
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional governance metadata",
    )
