"""Policy decision schema for CIAF Core."""

from datetime import datetime
from typing import Any
from pydantic import BaseModel, Field, ConfigDict
from ..enums import PolicyEffect


class PolicyRule(BaseModel):
    """Individual policy rule evaluated in a decision."""

    rule_id: str = Field(
        ...,
        description="Unique identifier for the rule",
    )
    rule_name: str = Field(
        ...,
        description="Human-readable name of the rule",
    )
    rule_version: str | None = Field(
        default=None,
        description="Version of the rule",
    )
    matched: bool = Field(
        ...,
        description="Whether this rule matched the request",
    )
    effect: PolicyEffect = Field(
        ...,
        description="Effect of this rule (allow, deny, etc.)",
    )

    model_config = ConfigDict(use_enum_values=True)


class PolicyDecision(BaseModel):
    """
    Policy decision record.

    Captures the result of policy evaluation and enforcement.
    """

    decision_id: str = Field(
        ...,
        description="Unique identifier for this decision",
        min_length=1,
    )
    timestamp_utc: datetime = Field(
        ...,
        description="When the decision was made (UTC)",
    )
    policy_set_id: str = Field(
        ...,
        description="ID of the policy set evaluated",
    )
    policy_set_version: str | None = Field(
        default=None,
        description="Version of the policy set",
    )

    # Decision outcome
    effect: PolicyEffect = Field(
        ...,
        description="Final decision effect",
    )
    allowed: bool = Field(
        ...,
        description="Whether the action was allowed",
    )
    reason: str | None = Field(
        default=None,
        description="Explanation for the decision",
    )

    # Rules evaluated
    rules_evaluated: list[PolicyRule] = Field(
        default_factory=list,
        description="Policy rules that were evaluated",
    )
    matching_rules: list[str] = Field(
        default_factory=list,
        description="IDs of rules that matched",
    )

    # Context
    request_context: dict[str, Any] = Field(
        default_factory=dict,
        description="Context of the original request",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional decision metadata",
    )

    model_config = ConfigDict(use_enum_values=True)
