"""Relationship schema for CIAF Core."""

from typing import Any
from pydantic import BaseModel, Field, ConfigDict
from ..enums import RelationshipType


class Relationship(BaseModel):
    """
    Relationship between two entities.

    Describes how entities relate to each other in the CIAF ecosystem.
    """

    relationship_id: str = Field(
        ...,
        description="Unique identifier for this relationship",
        min_length=1,
    )
    relationship_type: RelationshipType = Field(
        ...,
        description="Type of relationship",
    )

    # Source entity
    source_entity_id: str = Field(
        ...,
        description="ID of the source entity",
    )
    source_entity_type: str = Field(
        ...,
        description="Type of the source entity",
    )

    # Target entity
    target_entity_id: str = Field(
        ...,
        description="ID of the target entity",
    )
    target_entity_type: str = Field(
        ...,
        description="Type of the target entity",
    )

    # Relationship properties
    strength: float | None = Field(
        default=None,
        description="Strength or weight of the relationship (0.0 to 1.0)",
        ge=0.0,
        le=1.0,
    )
    bidirectional: bool = Field(
        default=False,
        description="Whether the relationship is bidirectional",
    )

    # Metadata
    properties: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional relationship properties",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional relationship metadata",
    )

    model_config = ConfigDict(use_enum_values=True)
