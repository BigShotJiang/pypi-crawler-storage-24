"""Lineage information schema for CIAF Core."""

from typing import Any
from pydantic import BaseModel, Field, ConfigDict
from ..enums import LineageType


class LineageLink(BaseModel):
    """A single lineage link between entities."""

    entity_id: str = Field(
        ...,
        description="ID of the linked entity",
    )
    entity_type: str = Field(
        ...,
        description="Type of the linked entity",
    )
    relationship_type: LineageType = Field(
        ...,
        description="Type of lineage relationship",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional relationship metadata",
    )

    model_config = ConfigDict(use_enum_values=True)


class LineageInfo(BaseModel):
    """
    Lineage information for an event or entity.

    Tracks provenance and relationships.
    """

    entity_id: str = Field(
        ...,
        description="ID of the entity this lineage describes",
        min_length=1,
    )
    entity_type: str = Field(
        ...,
        description="Type of entity",
    )

    # Upstream lineage (what this came from)
    upstream: list[LineageLink] = Field(
        default_factory=list,
        description="Upstream lineage links (parents, sources)",
    )

    # Downstream lineage (what this led to)
    downstream: list[LineageLink] = Field(
        default_factory=list,
        description="Downstream lineage links (children, derivatives)",
    )

    # Graph information
    lineage_depth: int = Field(
        default=0,
        description="Depth in the lineage graph",
        ge=0,
    )
    root_entity_id: str | None = Field(
        default=None,
        description="ID of the root entity in the lineage chain",
    )

    # Metadata
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional lineage metadata",
    )
