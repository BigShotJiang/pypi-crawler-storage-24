"""Example demonstrating the SignedEvent "Evidence Envelope" pattern."""

from datetime import datetime, timezone
from ciaf_core import (
    # Core schemas
    CIAFEvent,
    SignedEvent,
    Actor,
    Subject,
    Action,
    # Enums
    ActorType,
    SubjectType,
    ActionType,
    ActionOutcome,
    EventCategory,
    # Signing utilities
    generate_ed25519_keypair,
    sign_payload,
    compute_payload_hash,
    # Utilities
    to_canonical_json,
    new_event_id,
)


def main():
    """Demonstrate the Evidence Envelope pattern with cryptographic signing."""

    print("=" * 80)
    print("CIAF Core: SignedEvent Evidence Envelope Example")
    print("=" * 80)
    print()

    # Step 1: Generate a keypair for the agent
    print("Step 1: Generating Ed25519 keypair for the agent...")
    private_key, public_key = generate_ed25519_keypair()
    print(f"✓ Private key: {len(private_key)} bytes")
    print(f"✓ Public key: {len(public_key)} bytes")
    print()

    # Step 2: Create a CIAF event
    print("Step 2: Creating a CIAF event...")
    now = datetime.now(timezone.utc)
    event = CIAFEvent(
        event_id=new_event_id(),
        event_type="agent.tool_call",
        event_category=EventCategory.EXECUTION,
        timestamp_utc=now,
        recorded_at_utc=now,
        tenant_id="tenant-demo-001",
        source_system="ciaf_agents",
        schema_version="1.0.0",
        actor=Actor(
            actor_id="agent:data-analyst-v2",
            actor_type=ActorType.AGENT,
            display_name="Data Analysis Agent",
        ),
        subject=Subject(
            subject_id="workflow:customer-segmentation",
            subject_type=SubjectType.WORKFLOW,
            subject_name="Customer Segmentation Workflow",
        ),
        action=Action(
            action_type=ActionType.EXECUTE,
            action_name="query_database",
            outcome=ActionOutcome.SUCCESS,
            parameters={
                "query": "SELECT * FROM customers WHERE segment = 'high_value'",
                "database": "analytics_db",
                "row_count": 1247,
            },
            duration_ms=342,
        ),
    )
    print(f"✓ Event ID: {event.event_id}")
    print(f"✓ Event Type: {event.event_type}")
    print(f"✓ Actor: {event.actor.display_name}")
    print()

    # Step 3: Create canonical payload and sign it
    print("Step 3: Creating signed envelope...")
    payload_json = to_canonical_json(event)
    print(f"✓ Canonical JSON: {len(payload_json)} bytes")

    payload_hash = compute_payload_hash(payload_json)
    print(f"✓ Payload hash: {payload_hash}")

    signature = sign_payload(payload_json, private_key, "Ed25519")
    print(f"✓ Signature: {signature[:50]}...")
    print()

    # Step 4: Create the SignedEvent envelope
    print("Step 4: Creating SignedEvent envelope...")
    signed_event = SignedEvent(
        payload=event.model_dump(),
        payload_hash=payload_hash,
        signer_id="agent:data-analyst-v2",
        signature=signature,
        signature_algorithm="Ed25519",
        public_key_ref="key:vault:/agents/data-analyst-v2.pub",
        public_key_inline=public_key.decode("ascii"),  # Optional: include inline for portability
    )
    print(f"✓ Signer ID: {signed_event.signer_id}")
    print(f"✓ Algorithm: {signed_event.signature_algorithm}")
    print(f"✓ Signed at: {signed_event.signed_at_utc}")
    print()

    # Step 5: Verify the signature
    print("Step 5: Verifying signature...")
    is_valid = signed_event.verify(public_key)
    if is_valid:
        print("✓ Signature is VALID - Event is authentic")
    else:
        print("✗ Signature is INVALID - Event may have been tampered with!")
    print()

    # Step 6: Verify payload integrity without the key
    print("Step 6: Verifying payload integrity (hash check only)...")
    integrity_ok = signed_event.verify_payload_integrity()
    if integrity_ok:
        print("✓ Payload integrity check PASSED")
    else:
        print("✗ Payload integrity check FAILED")
    print()

    # Step 7: Extract the original event
    print("Step 7: Extracting original event from envelope...")
    extracted_event = signed_event.get_event()
    print(f"✓ Extracted event ID: {extracted_event.event_id}")
    print(f"✓ Actor: {extracted_event.actor.display_name}")
    print(f"✓ Action: {extracted_event.action.action_name}")
    print(f"✓ Outcome: {extracted_event.action.outcome}")
    print()

    # Step 8: Demonstrate tampering detection
    print("Step 8: Demonstrating tampering detection...")
    print("Attempting to verify with a different public key...")
    _, wrong_public_key = generate_ed25519_keypair()
    is_valid_with_wrong_key = signed_event.verify(wrong_public_key)
    if not is_valid_with_wrong_key:
        print("✓ Correctly rejected signature with wrong public key")
    else:
        print("✗ Should have rejected wrong key!")
    print()

    # Step 9: Show different algorithms
    print("Step 9: Other supported algorithms...")
    print("✓ Ed25519 (recommended) - Fast, modern, secure")
    print("✓ RSA-PSS-SHA256 - Traditional RSA with PSS padding")
    print("✓ ECDSA-P256-SHA256 - NIST P-256 elliptic curve")
    print()

    print("=" * 80)
    print("Benefits of the Evidence Envelope:")
    print("=" * 80)
    print("1. Non-repudiation: Cryptographic proof of who created the event")
    print("2. Integrity: Detect any tampering with event data")
    print("3. Authentication: Verify the source before accepting events")
    print("4. Chain of Custody: Support for parent signatures and delegation")
    print("5. Self-Contained: Optional inline public keys for portability")
    print()
    print("Use cases:")
    print("- Cryptographic audit trails")
    print("- Event transmission across untrusted networks")
    print("- Compliance requirements (GDPR, SOX, HIPAA)")
    print("- Multi-party verification (regulators, auditors)")
    print("- Long-term archival with provenance")
    print()


if __name__ == "__main__":
    main()
