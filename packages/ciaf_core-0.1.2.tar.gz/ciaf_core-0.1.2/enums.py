"""Enums and controlled vocabularies for CIAF Core."""

from enum import Enum


class ActorType(str, Enum):
    """Type of actor performing an action."""

    HUMAN = "human"
    AGENT = "agent"
    SERVICE = "service"
    MODEL = "model"
    SYSTEM = "system"


class SubjectType(str, Enum):
    """Type of subject being acted upon."""

    AGENT = "agent"
    MODEL = "model"
    DATASET = "dataset"
    WORKFLOW = "workflow"
    POLICY = "policy"
    CASE = "case"
    DOCUMENT = "document"
    USER = "user"
    ORGANIZATION = "organization"


class ResourceType(str, Enum):
    """Type of resource involved in an action."""

    DATABASE = "database"
    API = "api"
    FILE = "file"
    MODEL = "model"
    DATASET = "dataset"
    SERVICE = "service"
    CREDENTIAL = "credential"
    POLICY = "policy"
    REPORT = "report"


class ActionType(str, Enum):
    """Type of action being performed."""

    READ = "read"
    WRITE = "write"
    EXECUTE = "execute"
    APPROVE = "approve"
    DENY = "deny"
    TRAIN = "train"
    DEPLOY = "deploy"
    INFER = "infer"
    DELETE = "delete"
    EXPORT = "export"
    ESCALATE = "escalate"
    CREATE = "create"
    UPDATE = "update"
    QUERY = "query"
    VALIDATE = "validate"


class ActionOutcome(str, Enum):
    """Outcome of an action."""

    SUCCESS = "success"
    BLOCKED = "blocked"
    FAILED = "failed"
    PARTIAL = "partial"
    PENDING = "pending"


class EventCategory(str, Enum):
    """Category of CIAF event."""

    EXECUTION = "execution"
    GOVERNANCE = "governance"
    DEPLOYMENT = "deployment"
    TRAINING = "training"
    INFERENCE = "inference"
    ACCESS = "access"
    PRIVILEGE = "privilege"
    ESCALATION = "escalation"
    APPROVAL = "approval"
    AUDIT = "audit"
    LIFECYCLE = "lifecycle"


class RiskLevel(str, Enum):
    """Risk level assessment."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    MINIMAL = "minimal"
    NONE = "none"


class PolicyEffect(str, Enum):
    """Policy decision effect."""

    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_APPROVAL = "require_approval"
    REQUIRE_ATTESTATION = "require_attestation"
    WARN = "warn"


class EvidenceType(str, Enum):
    """Type of evidence record."""

    EVENT = "event"
    DECISION = "decision"
    ATTESTATION = "attestation"
    AUDIT_LOG = "audit_log"
    TRACE = "trace"
    ARTIFACT = "artifact"


class LineageType(str, Enum):
    """Type of lineage relationship."""

    PARENT = "parent"
    CHILD = "child"
    DERIVES_FROM = "derives_from"
    GENERATES = "generates"
    USES = "uses"
    TRIGGERS = "triggers"
    CAUSED_BY = "caused_by"


class RelationshipType(str, Enum):
    """Type of relationship between entities."""

    OWNS = "owns"
    MANAGES = "manages"
    USES = "uses"
    DEPENDS_ON = "depends_on"
    IMPLEMENTS = "implements"
    ENFORCES = "enforces"
    VIOLATES = "violates"
    COMPLIES_WITH = "complies_with"
