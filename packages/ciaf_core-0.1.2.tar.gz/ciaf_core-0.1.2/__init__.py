"""
CIAF Core Package

Canonical schemas, validation, and cryptographic preparation utilities for CIAF processes.
"""

__version__ = "0.1.0"
__schema_version__ = "1.0.0"

# Import core schemas
from .schemas.actor import Actor
from .schemas.subject import Subject
from .schemas.resource import Resource
from .schemas.action import Action
from .schemas.event import CIAFEvent
from .schemas.policy import PolicyDecision
from .schemas.risk import RiskAssessment
from .schemas.execution import ExecutionContext
from .schemas.evidence import EvidenceRecord
from .schemas.lineage import LineageInfo
from .schemas.governance import GovernanceMapping
from .schemas.signed_event import SignedEvent

# Import enums
from .enums import (
    ActorType,
    SubjectType,
    ResourceType,
    ActionType,
    ActionOutcome,
    EventCategory,
    RiskLevel,
    PolicyEffect,
)

# Import utilities
from .canonicalization import to_canonical_dict, to_canonical_json
from .hashing import sha256_hex, sha256_bytes
from .IDs import new_event_id, new_entity_id
from .exceptions import CIAFValidationError, CIAFSchemaError
from .signing import (
    generate_rsa_keypair,
    generate_ed25519_keypair,
    generate_ecdsa_keypair,
    sign_payload,
    verify_signature,
    compute_payload_hash,
    SignatureAlgorithm,
    CIAFSigningError,
    CIAFVerificationError,
)

# Import builders
from .builders import (
    build_agent_tool_call_event,
    build_model_deployment_event,
    build_policy_decision_event,
    build_evidence_record,
)

__all__ = [
    # Version info
    "__version__",
    "__schema_version__",
    # Core schemas
    "Actor",
    "Subject",
    "Resource",
    "Action",
    "CIAFEvent",
    "PolicyDecision",
    "RiskAssessment",
    "ExecutionContext",
    "EvidenceRecord",
    "LineageInfo",
    "GovernanceMapping",
    "SignedEvent",
    # Enums
    "ActorType",
    "SubjectType",
    "ResourceType",
    "ActionType",
    "ActionOutcome",
    "EventCategory",
    "RiskLevel",
    "PolicyEffect",
    # Utilities
    "to_canonical_dict",
    "to_canonical_json",
    "sha256_hex",
    "sha256_bytes",
    "new_event_id",
    "new_entity_id",
    # Signing utilities
    "generate_rsa_keypair",
    "generate_ed25519_keypair",
    "generate_ecdsa_keypair",
    "sign_payload",
    "verify_signature",
    "compute_payload_hash",
    "SignatureAlgorithm",
    # Exceptions
    "CIAFValidationError",
    "CIAFSchemaError",
    "CIAFSigningError",
    "CIAFVerificationError",
    # Builders
    "build_agent_tool_call_event",
    "build_model_deployment_event",
    "build_policy_decision_event",
    "build_evidence_record",
]
