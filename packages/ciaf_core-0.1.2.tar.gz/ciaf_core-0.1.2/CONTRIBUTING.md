# Contributing to CIAF Core

Thank you for your interest in contributing to CIAF Core! This document provides guidelines for developers.

## Development Setup

### Prerequisites

- Python 3.11 or higher
- Git
- pip

### Initial Setup

1. **Clone the repository:**
   ```bash
   git clone https://github.com/DenzilGreenwood/ciaf_core.git
   cd ciaf_core
   ```

2. **Create a virtual environment:**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install development dependencies:**
   ```bash
   pip install -e .[dev]
   ```

## Development Workflow

### Running Tests

```bash
# Run all tests
pytest tests/ -p no:asyncio

# Run with coverage
pytest tests/ -p no:asyncio --cov=ciaf_core --cov-report=html

# Run specific test file
pytest tests/test_signing.py -p no:asyncio -v
```

### Code Quality

```bash
# Format code with black
black ciaf_core tests

# Lint with ruff
ruff check ciaf_core tests
```

### Building the Package

```bash
# Clean previous builds
Remove-Item -Recurse -Force dist, build, *.egg-info -ErrorAction SilentlyContinue

# Build distribution
python -m build

# Verify package
python -m twine check dist/*
```

## Code Guidelines

### Python Style

- Follow PEP 8 style guidelines
- Use type hints for all function parameters and return values
- Document all public APIs with docstrings
- Keep line length to 100 characters (configured in pyproject.toml)

### Schema Design

When adding or modifying schemas:

1. **Backward Compatibility**: Ensure changes don't break existing code
2. **Validation**: Use Pydantic validators for data integrity
3. **Documentation**: Add clear docstrings explaining the schema purpose
4. **Tests**: Include comprehensive tests for new schemas

Example:
```python
from pydantic import BaseModel, Field, ConfigDict

class MySchema(BaseModel):
    """
    Brief description of what this schema represents.
    
    Used for: Explain the use case
    """
    
    model_config = ConfigDict(
        extra="forbid",
        str_strip_whitespace=True,
    )
    
    field_name: str = Field(
        ...,
        description="Clear description of the field",
        min_length=1,
    )
```

### Utility Functions

- Keep functions focused on a single responsibility
- Add error handling with custom exceptions
- Include usage examples in docstrings
- Write tests covering both success and error cases

### Enumeration Guidelines

- Use descriptive names in UPPER_SNAKE_CASE
- Provide clear enum class docstrings
- String values should be lowercase with hyphens
- Add new enum values only at the end (for backward compatibility)

## Testing Guidelines

### Test Structure

```python
def test_feature_name():
    """Test description explaining what is being tested."""
    # Arrange: Set up test data
    input_data = {...}
    
    # Act: Execute the function
    result = function_under_test(input_data)
    
    # Assert: Verify the result
    assert result.field == expected_value
```

### Test Coverage

- Aim for 90%+ code coverage
- Test both success and failure paths
- Include edge cases and boundary conditions
- Test error handling and validation

### Test Fixtures

Use pytest fixtures for reusable test data:

```python
@pytest.fixture
def sample_event():
    """Fixture providing a sample CIAF event."""
    return CIAFEvent(...)
```

## Commit Guidelines

### Commit Messages

Follow conventional commit format:

```
type(scope): brief description

Longer explanation if needed

Fixes #issue-number
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `test`: Test additions or changes
- `refactor`: Code refactoring
- `chore`: Build/tooling changes

**Examples:**
```
feat(signing): add ECDSA P-256 signature support

Add support for ECDSA P-256 signatures alongside Ed25519 and RSA.
Includes key generation, signing, and verification functions.

Fixes #42
```

## Pull Request Process

1. **Create a branch:**
   ```bash
   git checkout -b feature/my-new-feature
   ```

2. **Make changes and commit:**
   ```bash
   git add .
   git commit -m "feat(scope): description"
   ```

3. **Run tests and ensure they pass:**
   ```bash
   pytest tests/ -p no:asyncio
   ```

4. **Push to GitHub:**
   ```bash
   git push origin feature/my-new-feature
   ```

5. **Create Pull Request:**
   - Provide clear description of changes
   - Reference any related issues
   - Ensure CI/CD checks pass
   - Wait for review

## Versioning

This package follows [Semantic Versioning](https://semver.org/):

- **MAJOR**: Breaking changes
- **MINOR**: New features (backward compatible)
- **PATCH**: Bug fixes

### Version Updates

When incrementing version:

1. Update `version` in `pyproject.toml`
2. Update `CHANGELOG.md` with changes
3. Create a git tag: `git tag v0.2.0`
4. Push tag: `git push origin v0.2.0`

## Documentation

### Docstring Format

Use Google-style docstrings:

```python
def my_function(param1: str, param2: int) -> bool:
    """
    Brief one-line description.
    
    Longer description explaining the function purpose,
    behavior, and usage.
    
    Args:
        param1: Description of param1
        param2: Description of param2
        
    Returns:
        Description of return value
        
    Raises:
        ValueError: When validation fails
        
    Example:
        >>> result = my_function("test", 42)
        >>> assert result is True
    """
```

### Updating Documentation

When adding features:

1. Update README.md with new capabilities
2. Add examples to QUICKSTART.md
3. Update CHANGELOG.md under "Unreleased"
4. Create or update example scripts

## License

By contributing to CIAF Core, you agree that your contributions will be licensed under the Business Source License 1.1 (BUSL-1.1).

## Questions?

- **Repository**: https://github.com/DenzilGreenwood/ciaf_core
- **Issues**: https://github.com/DenzilGreenwood/ciaf_core/issues
- **Email**: Founder@CognitiveInsight.ai

Thank you for contributing to CIAF Core!
