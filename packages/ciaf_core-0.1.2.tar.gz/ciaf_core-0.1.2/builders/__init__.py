"""
Builder functions for common CIAF events.

Provides convenience constructors for creating CIAF events and related structures.
"""

from datetime import datetime, timezone
from typing import Any
from ..schemas.event import CIAFEvent
from ..schemas.actor import Actor
from ..schemas.subject import Subject
from ..schemas.resource import Resource
from ..schemas.action import Action
from ..schemas.evidence import EvidenceRecord
from ..IDs import new_event_id
from ..enums import (
    ActorType,
    SubjectType,
    ActionType,
    ActionOutcome,
    EventCategory,
    EvidenceType,
)


def build_agent_tool_call_event(
    tenant_id: str,
    source_system: str,
    actor_id: str,
    actor_name: str,
    subject_id: str,
    subject_name: str,
    tool_name: str,
    outcome: str,
    reason: str | None = None,
    parameters: dict[str, Any] | None = None,
    duration_ms: int | None = None,
    event_id: str | None = None,
    timestamp_utc: datetime | None = None,
) -> CIAFEvent:
    """
    Build an agent tool call event.

    Args:
        tenant_id: Tenant/organization identifier
        source_system: System generating the event
        actor_id: ID of the agent actor
        actor_name: Display name of the agent
        subject_id: ID of the workflow or subject
        subject_name: Display name of the subject
        tool_name: Name of the tool being called
        outcome: Outcome of the tool call (success, blocked, failed, etc.)
        reason: Optional reason for the outcome
        parameters: Optional tool parameters
        duration_ms: Optional duration in milliseconds
        event_id: Optional custom event ID
        timestamp_utc: Optional custom timestamp

    Returns:
        CIAFEvent instance
    """
    now = timestamp_utc or datetime.now(timezone.utc)

    return CIAFEvent(
        event_id=event_id or new_event_id(),
        event_type="agent.tool_call",
        event_category=EventCategory.EXECUTION,
        timestamp_utc=now,
        recorded_at_utc=datetime.now(timezone.utc),
        tenant_id=tenant_id,
        source_system=source_system,
        actor=Actor(
            actor_id=actor_id,
            actor_type=ActorType.AGENT,
            display_name=actor_name,
        ),
        subject=Subject(
            subject_id=subject_id,
            subject_type=SubjectType.WORKFLOW,
            subject_name=subject_name,
        ),
        action=Action(
            action_type=ActionType.EXECUTE,
            action_name=tool_name,
            outcome=ActionOutcome(outcome),
            reason=reason,
            parameters=parameters or {},
            duration_ms=duration_ms,
        ),
    )


def build_model_deployment_event(
    tenant_id: str,
    source_system: str,
    actor_id: str,
    actor_name: str,
    model_id: str,
    model_name: str,
    model_version: str,
    outcome: str,
    environment: str = "production",
    reason: str | None = None,
    event_id: str | None = None,
) -> CIAFEvent:
    """
    Build a model deployment event.

    Args:
        tenant_id: Tenant/organization identifier
        source_system: System generating the event
        actor_id: ID of the deploying actor
        actor_name: Display name of the actor
        model_id: ID of the model
        model_name: Display name of the model
        model_version: Version of the model
        outcome: Outcome of the deployment
        environment: Deployment environment (default: "production")
        reason: Optional reason for the outcome
        event_id: Optional custom event ID

    Returns:
        CIAFEvent instance
    """
    now = datetime.now(timezone.utc)

    return CIAFEvent(
        event_id=event_id or new_event_id(),
        event_type="model.deployment",
        event_category=EventCategory.DEPLOYMENT,
        timestamp_utc=now,
        recorded_at_utc=now,
        tenant_id=tenant_id,
        source_system=source_system,
        actor=Actor(
            actor_id=actor_id,
            actor_type=ActorType.HUMAN,
            display_name=actor_name,
        ),
        subject=Subject(
            subject_id=model_id,
            subject_type=SubjectType.MODEL,
            subject_name=model_name,
            subject_version=model_version,
        ),
        action=Action(
            action_type=ActionType.DEPLOY,
            action_name="deploy_model",
            outcome=ActionOutcome(outcome),
            reason=reason,
            parameters={"environment": environment, "version": model_version},
        ),
    )


def build_policy_decision_event(
    tenant_id: str,
    source_system: str,
    actor_id: str,
    actor_type: str,
    subject_id: str,
    subject_type: str,
    action_name: str,
    decision_allowed: bool,
    policy_set_id: str,
    reason: str | None = None,
    event_id: str | None = None,
) -> CIAFEvent:
    """
    Build a policy decision event.

    Args:
        tenant_id: Tenant/organization identifier
        source_system: System generating the event
        actor_id: ID of the actor requesting access
        actor_type: Type of actor
        subject_id: ID of the subject being accessed
        subject_type: Type of subject
        action_name: Name of the action being evaluated
        decision_allowed: Whether the action was allowed
        policy_set_id: ID of the policy set evaluated
        reason: Optional reason for the decision
        event_id: Optional custom event ID

    Returns:
        CIAFEvent instance
    """
    now = datetime.now(timezone.utc)
    outcome = ActionOutcome.SUCCESS if decision_allowed else ActionOutcome.BLOCKED

    return CIAFEvent(
        event_id=event_id or new_event_id(),
        event_type="policy.decision",
        event_category=EventCategory.GOVERNANCE,
        timestamp_utc=now,
        recorded_at_utc=now,
        tenant_id=tenant_id,
        source_system=source_system,
        actor=Actor(
            actor_id=actor_id,
            actor_type=ActorType(actor_type),
        ),
        subject=Subject(
            subject_id=subject_id,
            subject_type=SubjectType(subject_type),
        ),
        action=Action(
            action_type=ActionType.VALIDATE,
            action_name=action_name,
            outcome=outcome,
            reason=reason,
            parameters={"policy_set_id": policy_set_id},
        ),
    )


def build_evidence_record(
    source_event_id: str,
    source_event_type: str,
    content_hash: str,
    evidence_type: str = "event",
    evidence_id: str | None = None,
    signature: str | None = None,
    storage_location: str | None = None,
) -> EvidenceRecord:
    """
    Build an evidence record.

    Args:
        source_event_id: ID of the source event
        source_event_type: Type of the source event
        content_hash: SHA-256 hash of the evidence content
        evidence_type: Type of evidence (default: "event")
        evidence_id: Optional custom evidence ID
        signature: Optional cryptographic signature
        storage_location: Optional storage location URI

    Returns:
        EvidenceRecord instance
    """
    now = datetime.now(timezone.utc)

    return EvidenceRecord(
        evidence_id=evidence_id or f"evd_{new_event_id()}",
        evidence_type=EvidenceType(evidence_type),
        created_at_utc=now,
        source_event_id=source_event_id,
        source_event_type=source_event_type,
        content_hash=content_hash,
        signature=signature,
        storage_location=storage_location,
    )


def build_access_event(
    tenant_id: str,
    source_system: str,
    actor_id: str,
    actor_type: str,
    actor_name: str,
    resource_id: str,
    resource_type: str,
    resource_name: str,
    action_type: str,
    action_name: str,
    outcome: str,
    reason: str | None = None,
    event_id: str | None = None,
) -> CIAFEvent:
    """
    Build a resource access event.

    Args:
        tenant_id: Tenant/organization identifier
        source_system: System generating the event
        actor_id: ID of the actor accessing the resource
        actor_type: Type of actor
        actor_name: Display name of the actor
        resource_id: ID of the resource
        resource_type: Type of resource
        resource_name: Display name of the resource
        action_type: Type of action (read, write, etc.)
        action_name: Specific name of the action
        outcome: Outcome of the access attempt
        reason: Optional reason for the outcome
        event_id: Optional custom event ID

    Returns:
        CIAFEvent instance
    """
    now = datetime.now(timezone.utc)

    return CIAFEvent(
        event_id=event_id or new_event_id(),
        event_type="resource.access",
        event_category=EventCategory.ACCESS,
        timestamp_utc=now,
        recorded_at_utc=now,
        tenant_id=tenant_id,
        source_system=source_system,
        actor=Actor(
            actor_id=actor_id,
            actor_type=ActorType(actor_type),
            display_name=actor_name,
        ),
        subject=Subject(
            subject_id=resource_id,
            subject_type=SubjectType.DOCUMENT,  # Using document as fallback
            subject_name=resource_name,
        ),
        action=Action(
            action_type=ActionType(action_type),
            action_name=action_name,
            outcome=ActionOutcome(outcome),
            reason=reason,
        ),
        resources=[
            Resource(
                resource_id=resource_id,
                resource_type=resource_type,  # type: ignore
                resource_name=resource_name,
            )
        ],
    )


__all__ = [
    "build_agent_tool_call_event",
    "build_model_deployment_event",
    "build_policy_decision_event",
    "build_evidence_record",
    "build_access_event",
]
