"""Version information for CIAF Core package."""

__version__ = "0.1.2"
__schema_version__ = "1.0.0"
