"""Exceptions for CIAF Core."""


class CIAFError(Exception):
    """Base exception for CIAF Core."""

    pass


class CIAFValidationError(CIAFError):
    """Exception raised when validation fails."""

    pass


class CIAFSchemaError(CIAFError):
    """Exception raised when schema operation fails."""

    pass


class CIAFHashError(CIAFError):
    """Exception raised when hashing operation fails."""

    pass


class CIAFCanonializationError(CIAFError):
    """Exception raised when canonicalization fails."""

    pass


class CIAFIDGenerationError(CIAFError):
    """Exception raised when ID generation fails."""

    pass
