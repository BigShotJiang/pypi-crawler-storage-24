# Changelog

All notable changes to the CIAF Core package will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-21

### Added

#### Core Package Structure
- Initial package structure with `ciaf_core` namespace
- Package configuration with `pyproject.toml`
- Business Source License 1.1 (converts to Apache 2.0 on January 1, 2029)
- Comprehensive README and QUICKSTART documentation

#### Schema Models
- `CIAFEvent` - Canonical event schema
- `Actor` - Entity performing actions
- `Subject` - Target of actions
- `Resource` - Resources involved in actions
- `Action` - Action performed and outcome
- `PolicyDecision` - Policy evaluation results
- `RiskAssessment` - Risk analysis records
- `ExecutionContext` - Runtime environment information
- `EvidenceRecord` - Cryptographic evidence tracking
- `LineageInfo` - Provenance and lineage tracking
- `GovernanceMapping` - Compliance framework mappings
- `Relationship` - Entity relationships
- `SignedEvent` - Cryptographically signed event envelope for authentication and integrity

#### Enumerations
- `ActorType` - Types of actors (human, agent, service, model, system)
- `SubjectType` - Types of subjects (agent, model, dataset, workflow, policy, etc.)
- `ResourceType` - Types of resources
- `ActionType` - Types of actions (read, write, execute, deploy, etc.)
- `ActionOutcome` - Action outcomes (success, blocked, failed, partial, pending)
- `EventCategory` - Event categories (execution, governance, deployment, etc.)
- `RiskLevel` - Risk levels (critical, high, medium, low, minimal, none)
- `PolicyEffect` - Policy effects (allow, deny, require_approval, etc.)
- `EvidenceType` - Evidence types
- `LineageType` - Lineage relationship types
- `RelationshipType` - Entity relationship types

#### Utilities

**Canonicalization** (`ciaf_core.canonicalization`)
- `to_canonical_dict()` - Convert models to canonical dictionaries
- `to_canonical_json()` - Deterministic JSON serialization
- `dict_to_canonical_json()` - Dictionary canonicalization

**Hashing** (`ciaf_core.hashing`)
- `sha256_hex()` - SHA-256 hashing (hex output)
- `sha256_bytes()` - SHA-256 hashing (bytes output)
- `sha512_hex()` - SHA-512 hashing
- `blake2b_hex()` - BLAKE2b hashing
- `compute_merkle_leaf()` - Merkle tree leaf hash
- `compute_merkle_node()` - Merkle tree node hash

**ID Generation** (`ciaf_core.IDs`)
- `new_event_id()` - Event ID generation
- `new_entity_id()` - Entity ID generation
- `new_uuid()` - UUID v4 generation
- `new_ulid()` - ULID-like ID generation
- `new_short_id()` - Short random IDs
- `new_correlation_id()` - Correlation IDs for tracing
- `new_decision_id()` - Policy decision IDs
- `new_assessment_id()` - Risk assessment IDs

**Validation Helpers** (`ciaf_core.validation_helpers`)
- `validate_model()` - Pydantic model validation
- `validate_event_id()` - Event ID format validation
- `validate_hash()` - Hash string validation
- `validate_tenant_id()` - Tenant ID validation
- `is_valid_schema_version()` - Semantic version validation
- `validate_json_dict()` - JSON dictionary validation
- `validate_required_fields()` - Required field checking
- `sanitize_string()` - String sanitization
- `ensure_dict_keys_valid()` - Dictionary key validation

**Signing** (`ciaf_core.signing`)
- `generate_rsa_keypair()` - Generate RSA key pairs (2048, 3072, or 4096 bit)
- `generate_ed25519_keypair()` - Generate Ed25519 key pairs (recommended)
- `generate_ecdsa_keypair()` - Generate ECDSA P-256 key pairs
- `sign_payload()` - Sign a payload with a private key
- `verify_signature()` - Verify a signature with a public key
- `compute_payload_hash()` - Compute SHA-256 hash of payload
- Support for Ed25519, RSA-PSS-SHA256, and ECDSA-P256-SHA256 algorithms

**Builders** (`ciaf_core.builders`)
- `build_agent_tool_call_event()` - Agent tool call events
- `build_model_deployment_event()` - Model deployment events
- `build_policy_decision_event()` - Policy decision events
- `build_evidence_record()` - Evidence records
- `build_access_event()` - Resource access events

#### Exceptions
- `CIAFError` - Base exception
- `CIAFValidationError` - Validation errors
- `CIAFSchemaError` - Schema errors
- `CIAFHashError` - Hashing errors
- `CIAFCanonializationError` - Canonicalization errors
- `CIAFIDGenerationError` - ID generation errors
- `CIAFSigningError` - Signing operation errors
- `CIAFVerificationError` - Signature verification errors

#### Testing
- Comprehensive test suite with pytest
- Tests for event models
- Tests for canonicalization
- Tests for hashing utilities
- Tests for ID generation
- Tests for builders
- Tests for validation helpers
- Test fixtures and utilities

#### Documentation
- README.md with overview and features
- QUICKSTART.md with usage examples
- CHANGELOG.md with release notes
- Example script (`example_signed_event.py`)
- Inline code documentation and type hints

### Technical Details
- Python 3.11+ support
- Pydantic v2 for data validation
- Deterministic JSON serialization for cryptographic consistency
- Schema version 1.0.0 embedded in all events

[0.1.0]: https://github.com/your-org/ciaf_core/releases/tag/v0.1.0
