"""Cryptographic signing utilities for CIAF events.

Provides tools for signing events with private keys and verifying signatures.
Supports RSA, Ed25519, and ECDSA signature schemes.
"""

import base64
import hashlib
from typing import Literal

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding, ed25519, ec
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidSignature

SignatureAlgorithm = Literal["RSA-PSS-SHA256", "Ed25519", "ECDSA-P256-SHA256"]


class CIAFSigningError(Exception):
    """Raised when signing operations fail."""

    pass


class CIAFVerificationError(Exception):
    """Raised when signature verification fails."""

    pass


def generate_rsa_keypair(key_size: int = 2048) -> tuple[bytes, bytes]:
    """
    Generate an RSA key pair for signing.

    Args:
        key_size: RSA key size in bits (2048, 3072, or 4096)

    Returns:
        Tuple of (private_key_pem, public_key_pem) as bytes

    Example:
        >>> private_pem, public_pem = generate_rsa_keypair(2048)
        >>> # Store private_pem securely, distribute public_pem
    """
    if key_size not in (2048, 3072, 4096):
        raise CIAFSigningError(f"Invalid RSA key size: {key_size}. Use 2048, 3072, or 4096.")

    private_key = rsa.generate_private_key(
        public_exponent=65537, key_size=key_size, backend=default_backend()
    )

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    public_key = private_key.public_key()
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    return private_pem, public_pem


def generate_ed25519_keypair() -> tuple[bytes, bytes]:
    """
    Generate an Ed25519 key pair for signing (modern, fast, secure).

    Returns:
        Tuple of (private_key_pem, public_key_pem) as bytes

    Example:
        >>> private_pem, public_pem = generate_ed25519_keypair()
    """
    private_key = ed25519.Ed25519PrivateKey.generate()

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    public_key = private_key.public_key()
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    return private_pem, public_pem


def generate_ecdsa_keypair() -> tuple[bytes, bytes]:
    """
    Generate an ECDSA P-256 key pair for signing.

    Returns:
        Tuple of (private_key_pem, public_key_pem) as bytes

    Example:
        >>> private_pem, public_pem = generate_ecdsa_keypair()
    """
    private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    public_key = private_key.public_key()
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    return private_pem, public_pem


def sign_payload(
    payload: str, private_key_pem: bytes, algorithm: SignatureAlgorithm = "Ed25519"
) -> str:
    """
    Sign a payload with a private key.

    Args:
        payload: The string payload to sign (typically canonical JSON)
        private_key_pem: Private key in PEM format
        algorithm: Signature algorithm to use

    Returns:
        Base64-encoded signature string

    Raises:
        CIAFSigningError: If signing fails

    Example:
        >>> from ciaf_core import CIAFEvent, to_canonical_json
        >>> event = CIAFEvent(...)
        >>> payload = to_canonical_json(event)
        >>> signature = sign_payload(payload, private_key_pem, "Ed25519")
    """
    try:
        payload_bytes = payload.encode("utf-8")

        if algorithm == "Ed25519":
            private_key = serialization.load_pem_private_key(
                private_key_pem, password=None, backend=default_backend()
            )
            if not isinstance(private_key, ed25519.Ed25519PrivateKey):
                raise CIAFSigningError("Private key is not Ed25519")
            signature_bytes = private_key.sign(payload_bytes)

        elif algorithm == "RSA-PSS-SHA256":
            private_key = serialization.load_pem_private_key(
                private_key_pem, password=None, backend=default_backend()
            )
            if not isinstance(private_key, rsa.RSAPrivateKey):
                raise CIAFSigningError("Private key is not RSA")
            signature_bytes = private_key.sign(
                payload_bytes,
                padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
                hashes.SHA256(),
            )

        elif algorithm == "ECDSA-P256-SHA256":
            private_key = serialization.load_pem_private_key(
                private_key_pem, password=None, backend=default_backend()
            )
            if not isinstance(private_key, ec.EllipticCurvePrivateKey):
                raise CIAFSigningError("Private key is not ECDSA")
            signature_bytes = private_key.sign(payload_bytes, ec.ECDSA(hashes.SHA256()))

        else:
            raise CIAFSigningError(f"Unsupported algorithm: {algorithm}")

        return base64.b64encode(signature_bytes).decode("ascii")

    except Exception as e:
        raise CIAFSigningError(f"Failed to sign payload: {e}") from e


def verify_signature(
    payload: str,
    signature_b64: str,
    public_key_pem: bytes,
    algorithm: SignatureAlgorithm = "Ed25519",
) -> bool:
    """
    Verify a signature against a payload.

    Args:
        payload: The string payload that was signed
        signature_b64: Base64-encoded signature
        public_key_pem: Public key in PEM format
        algorithm: Signature algorithm used

    Returns:
        True if signature is valid, False otherwise

    Example:
        >>> is_valid = verify_signature(payload, signature, public_key_pem, "Ed25519")
        >>> if not is_valid:
        ...     raise Exception("Invalid signature")
    """
    try:
        payload_bytes = payload.encode("utf-8")
        signature_bytes = base64.b64decode(signature_b64)

        if algorithm == "Ed25519":
            public_key = serialization.load_pem_public_key(
                public_key_pem, backend=default_backend()
            )
            if not isinstance(public_key, ed25519.Ed25519PublicKey):
                raise CIAFVerificationError("Public key is not Ed25519")
            public_key.verify(signature_bytes, payload_bytes)

        elif algorithm == "RSA-PSS-SHA256":
            public_key = serialization.load_pem_public_key(
                public_key_pem, backend=default_backend()
            )
            if not isinstance(public_key, rsa.RSAPublicKey):
                raise CIAFVerificationError("Public key is not RSA")
            public_key.verify(
                signature_bytes,
                payload_bytes,
                padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
                hashes.SHA256(),
            )

        elif algorithm == "ECDSA-P256-SHA256":
            public_key = serialization.load_pem_public_key(
                public_key_pem, backend=default_backend()
            )
            if not isinstance(public_key, ec.EllipticCurvePublicKey):
                raise CIAFVerificationError("Public key is not ECDSA")
            public_key.verify(signature_bytes, payload_bytes, ec.ECDSA(hashes.SHA256()))

        else:
            raise CIAFVerificationError(f"Unsupported algorithm: {algorithm}")

        return True

    except InvalidSignature:
        return False
    except Exception as e:
        raise CIAFVerificationError(f"Failed to verify signature: {e}") from e


def compute_payload_hash(payload: str) -> str:
    """
    Compute SHA-256 hash of a payload.

    Args:
        payload: String payload (typically canonical JSON)

    Returns:
        Hex-encoded SHA-256 hash
    """
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


__all__ = [
    "SignatureAlgorithm",
    "CIAFSigningError",
    "CIAFVerificationError",
    "generate_rsa_keypair",
    "generate_ed25519_keypair",
    "generate_ecdsa_keypair",
    "sign_payload",
    "verify_signature",
    "compute_payload_hash",
]
