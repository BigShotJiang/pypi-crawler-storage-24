# CIAF Core Quick Start Guide

This guide will help you get started with `ciaf_core` quickly.

## Installation

```bash
# Install from PyPI
pip install ciaf-core

# Or install with development dependencies
pip install ciaf-core[dev]
```

**For Development:**

```bash
# Clone the repository
git clone https://github.com/DenzilGreenwood/ciaf_core.git
cd ciaf_core

# Install in editable mode
pip install -e .[dev]
```

## Basic Usage

### 1. Creating Events with Builders

The easiest way to create CIAF events is using the builder functions:

```python
from ciaf_core import build_agent_tool_call_event, to_canonical_json, sha256_hex

# Build an agent tool call event
event = build_agent_tool_call_event(
    tenant_id="acme-corp",
    source_system="ciaf_agents",
    actor_id="agent-data-analyst-001",
    actor_name="Data Analysis Agent",
    subject_id="workflow-customer-insights",
    subject_name="Customer Insights Workflow",
    tool_name="query_database",
    outcome="success",
    parameters={"table": "customers", "limit": 1000},
    duration_ms=234,
)

print(f"Event ID: {event.event_id}")
print(f"Event Type: {event.event_type}")
```

### 2. Canonicalization and Hashing

Ensure deterministic serialization for cryptographic operations:

```python
from ciaf_core import to_canonical_json, sha256_hex

# Convert event to canonical JSON
canonical_json = to_canonical_json(event)

# Compute content hash
content_hash = sha256_hex(canonical_json)

print(f"Content Hash: {content_hash}")
```

### 3. Creating Events Manually

You can also create events manually for full control:

```python
from datetime import datetime, timezone
from ciaf_core import CIAFEvent, Actor, Subject, Action
from ciaf_core import ActorType, SubjectType, ActionType, ActionOutcome, EventCategory
from ciaf_core import new_event_id

event = CIAFEvent(
    event_id=new_event_id(),
    event_type="model.deployment",
    event_category=EventCategory.DEPLOYMENT,
    timestamp_utc=datetime.now(timezone.utc),
    recorded_at_utc=datetime.now(timezone.utc),
    tenant_id="acme-corp",
    source_system="ciaf_ml",
    actor=Actor(
        actor_id="user-jane-123",
        actor_type=ActorType.HUMAN,
        display_name="Jane Smith",
        email="jane.smith@acme.com",
    ),
    subject=Subject(
        subject_id="model-gpt4-prod",
        subject_type=SubjectType.MODEL,
        subject_name="GPT-4 Production",
        subject_version="2024.03.21",
    ),
    action=Action(
        action_type=ActionType.DEPLOY,
        action_name="deploy_model",
        outcome=ActionOutcome.SUCCESS,
        parameters={"environment": "production"},
    ),
)
```

### 4. Working with Evidence Records

Create evidence records for cryptographic proof:

```python
from ciaf_core import build_evidence_record

evidence = build_evidence_record(
    source_event_id=event.event_id,
    source_event_type=event.event_type,
    content_hash=content_hash,
    signature="<cryptographic_signature>",
    storage_location="worm://vault.acme.com/evidence/2024/03/21/...",
)

print(f"Evidence ID: {evidence.evidence_id}")
```

### 5. Validation

Use validation helpers to ensure data integrity:

```python
from ciaf_core.validation_helpers import validate_hash, validate_tenant_id

# Validate a hash
if validate_hash(content_hash):
    print("Valid SHA-256 hash")

# Validate a tenant ID
if validate_tenant_id("acme-corp"):
    print("Valid tenant ID")
```

### 6. ID Generation

Generate various types of IDs:

```python
from ciaf_core.IDs import (
    new_event_id,
    new_entity_id,
    new_correlation_id,
    new_uuid,
)

# Generate different ID types
event_id = new_event_id()
agent_id = new_entity_id("agent")
correlation_id = new_correlation_id()
uuid = new_uuid()

print(f"Event ID: {event_id}")
print(f"Agent ID: {agent_id}")
print(f"Correlation ID: {correlation_id}")
print(f"UUID: {uuid}")
```

## Running Tests

```bash
# Install development dependencies
pip install -e .[dev]

# Run tests
pytest

# Run with coverage
pytest --cov=ciaf_core --cov-report=html
```

## Common Patterns

### Pattern 1: Event Creation, Hashing, and Evidence

```python
from ciaf_core import (
    build_agent_tool_call_event,
    to_canonical_json,
    sha256_hex,
    build_evidence_record,
)

# 1. Create event
event = build_agent_tool_call_event(
    tenant_id="acme-corp",
    source_system="ciaf_agents",
    actor_id="agent-001",
    actor_name="Analysis Agent",
    subject_id="workflow-001",
    subject_name="Data Analysis",
    tool_name="query_database",
    outcome="success",
)

# 2. Canonicalize and hash
canonical = to_canonical_json(event)
content_hash = sha256_hex(canonical)

# 3. Update event with hash
event.content_hash = content_hash

# 4. Create evidence record
evidence = build_evidence_record(
    source_event_id=event.event_id,
    source_event_type=event.event_type,
    content_hash=content_hash,
)

print(f"Event created with hash: {content_hash[:16]}...")
print(f"Evidence record: {evidence.evidence_id}")
```

### Pattern 2: Policy Decision Flow

```python
from ciaf_core import build_policy_decision_event

# Record a policy decision
decision_event = build_policy_decision_event(
    tenant_id="acme-corp",
    source_system="ciaf_vault",
    actor_id="agent-001",
    actor_type="agent",
    subject_id="dataset-customers",
    subject_type="dataset",
    action_name="read_pii_data",
    decision_allowed=False,
    policy_set_id="policy-pii-protection-v1",
    reason="Actor lacks required PII access privilege",
)

print(f"Policy decision: {decision_event.action.outcome}")
print(f"Reason: {decision_event.action.reason}")
```

### Pattern 3: Cryptographic Signing (Evidence Envelope)

```python
from ciaf_core import (
    build_agent_tool_call_event,
    SignedEvent,
    generate_ed25519_keypair,
    sign_payload,
    to_canonical_json,
    compute_payload_hash,
)

# 1. Generate keypair (do this once, store securely)
private_key, public_key = generate_ed25519_keypair()

# 2. Create event
event = build_agent_tool_call_event(
    tenant_id="acme-corp",
    source_system="ciaf_agents",
    actor_id="agent-001",
    actor_name="Analysis Agent",
    subject_id="workflow-001",
    subject_name="Data Analysis",
    tool_name="query_database",
    outcome="success",
)

# 3. Create signed envelope
payload_json = to_canonical_json(event)
signature = sign_payload(payload_json, private_key, "Ed25519")
payload_hash = compute_payload_hash(payload_json)

signed_event = SignedEvent(
    payload=event.model_dump(),
    payload_hash=payload_hash,
    signer_id="agent:analysis-v1",
    signature=signature,
    signature_algorithm="Ed25519",
    public_key_ref="key:vault:/agents/analysis.pub",
)

# 4. Later: Verify signature
is_valid = signed_event.verify(public_key)
if not is_valid:
    raise Exception("Invalid signature - event tampered!")

print(f"Signed event: {signed_event.signer_id}")
print(f"Signature valid: {is_valid}")
```

## Next Steps

- Review the full [README.md](README.md) for detailed documentation
- Explore the [schema models](ciaf_core/schemas/) for all available types
- Check the [CHANGELOG.md](CHANGELOG.md) for version history
- See [example_signed_event.py](example_signed_event.py) for cryptographic signing examples
- Integrate `ciaf_core` into your CIAF applications

## Support & Contact

- **Repository**: https://github.com/DenzilGreenwood/ciaf_core
- **Issues**: https://github.com/DenzilGreenwood/ciaf_core/issues
- **Commercial Licensing**: Founder@CognitiveInsight.ai
- **Website**: https://CognitiveInsight.ai

## License

Business Source License 1.1 (BUSL-1.1)  
Free for non-commercial use | Converts to Apache 2.0 on January 1, 2029
