"""
Hashing utilities for CIAF Core.

Provides cryptographic hashing functions for data integrity and identification.
"""

import hashlib
from ..exceptions import CIAFHashError


def sha256_hex(data: str | bytes) -> str:
    """
    Compute SHA-256 hash and return as hexadecimal string.

    Args:
        data: String or bytes to hash

    Returns:
        64-character hexadecimal hash string

    Raises:
        CIAFHashError: If hashing fails
    """
    try:
        if isinstance(data, str):
            data = data.encode("utf-8")
        return hashlib.sha256(data).hexdigest()
    except Exception as e:
        raise CIAFHashError(f"Failed to compute SHA-256 hash: {e}") from e


def sha256_bytes(data: str | bytes) -> bytes:
    """
    Compute SHA-256 hash and return as bytes.

    Args:
        data: String or bytes to hash

    Returns:
        32-byte hash

    Raises:
        CIAFHashError: If hashing fails
    """
    try:
        if isinstance(data, str):
            data = data.encode("utf-8")
        return hashlib.sha256(data).digest()
    except Exception as e:
        raise CIAFHashError(f"Failed to compute SHA-256 hash: {e}") from e


def sha512_hex(data: str | bytes) -> str:
    """
    Compute SHA-512 hash and return as hexadecimal string.

    Args:
        data: String or bytes to hash

    Returns:
        128-character hexadecimal hash string

    Raises:
        CIAFHashError: If hashing fails
    """
    try:
        if isinstance(data, str):
            data = data.encode("utf-8")
        return hashlib.sha512(data).hexdigest()
    except Exception as e:
        raise CIAFHashError(f"Failed to compute SHA-512 hash: {e}") from e


def blake2b_hex(data: str | bytes, digest_size: int = 32) -> str:
    """
    Compute BLAKE2b hash and return as hexadecimal string.

    Args:
        data: String or bytes to hash
        digest_size: Size of the digest in bytes (default: 32)

    Returns:
        Hexadecimal hash string

    Raises:
        CIAFHashError: If hashing fails
    """
    try:
        if isinstance(data, str):
            data = data.encode("utf-8")
        return hashlib.blake2b(data, digest_size=digest_size).hexdigest()
    except Exception as e:
        raise CIAFHashError(f"Failed to compute BLAKE2b hash: {e}") from e


def compute_merkle_leaf(data: str | bytes) -> str:
    """
    Compute a Merkle tree leaf hash.

    Prepends a 0x00 byte to distinguish leaf hashes from internal node hashes.

    Args:
        data: String or bytes to hash

    Returns:
        64-character hexadecimal hash string

    Raises:
        CIAFHashError: If hashing fails
    """
    try:
        if isinstance(data, str):
            data = data.encode("utf-8")
        leaf_data = b"\x00" + data
        return sha256_hex(leaf_data)
    except Exception as e:
        raise CIAFHashError(f"Failed to compute Merkle leaf hash: {e}") from e


def compute_merkle_node(left_hash: str, right_hash: str) -> str:
    """
    Compute a Merkle tree internal node hash.

    Prepends a 0x01 byte to distinguish internal node hashes from leaf hashes.

    Args:
        left_hash: Hexadecimal hash of left child
        right_hash: Hexadecimal hash of right child

    Returns:
        64-character hexadecimal hash string

    Raises:
        CIAFHashError: If hashing fails
    """
    try:
        # Sort hashes to make the tree deterministic regardless of insertion order
        hashes = sorted([left_hash, right_hash])
        combined = hashes[0] + hashes[1]
        node_data = b"\x01" + combined.encode("utf-8")
        return sha256_hex(node_data)
    except Exception as e:
        raise CIAFHashError(f"Failed to compute Merkle node hash: {e}") from e


__all__ = [
    "sha256_hex",
    "sha256_bytes",
    "sha512_hex",
    "blake2b_hex",
    "compute_merkle_leaf",
    "compute_merkle_node",
]
