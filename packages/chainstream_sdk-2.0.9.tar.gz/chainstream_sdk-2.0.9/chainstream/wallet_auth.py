"""
Wallet signature authentication for x402 payment access.

Agents sign each API request with their wallet (EVM or Solana).
The server verifies the signature and checks the payment record.
"""

import secrets
import time
from abc import ABC, abstractmethod
from typing import Dict

SIGNATURE_PREFIX = "chainstream"


class WalletSigner(ABC):
    """Interface for wallet signers (EVM or Solana)."""

    @property
    @abstractmethod
    def chain(self) -> str:
        """Returns 'evm' or 'solana'."""
        ...

    @property
    @abstractmethod
    def address(self) -> str:
        """Returns the wallet address."""
        ...

    @abstractmethod
    async def sign_message(self, message: str) -> str:
        """Sign a message and return the signature string."""
        ...


def build_sign_message(chain: str, address: str, timestamp: str, nonce: str) -> str:
    """Build the message that must be signed for wallet auth."""
    return f"{SIGNATURE_PREFIX}:{chain}:{address}:{timestamp}:{nonce}"


async def create_wallet_auth_headers(signer: WalletSigner) -> Dict[str, str]:
    """Generate X-Wallet-* headers for a request."""
    timestamp = str(int(time.time()))
    nonce = secrets.token_hex(16)
    message = build_sign_message(signer.chain, signer.address, timestamp, nonce)
    signature = await signer.sign_message(message)

    return {
        "X-Wallet-Address": signer.address,
        "X-Wallet-Chain": signer.chain,
        "X-Wallet-Signature": signature,
        "X-Wallet-Timestamp": timestamp,
        "X-Wallet-Nonce": nonce,
    }
