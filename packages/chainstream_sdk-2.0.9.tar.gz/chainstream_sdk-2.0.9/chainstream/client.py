"""ChainStream SDK Client."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional, Protocol

from chainstream.stream.client import StreamApi
from chainstream.wallet_auth import WalletSigner

# Default URLs
CHAINSTREAM_BASE_URL = "https://api.chainstream.io"
CHAINSTREAM_STREAM_URL = "wss://realtime-dex.chainstream.io/connection/websocket"


class TokenProvider(Protocol):
    """Protocol for providing access tokens."""

    def get_token(self) -> str:
        """Get the current access token."""
        ...


@dataclass
class StaticTokenProvider:
    """A simple token provider that returns a static token."""

    token: str

    def get_token(self) -> str:
        """Get the static token."""
        return self.token


@dataclass
class ChainStreamClientOptions:
    """Options for ChainStreamClient configuration."""

    base_url: str = CHAINSTREAM_BASE_URL
    stream_url: str = CHAINSTREAM_STREAM_URL


class ChainStreamClient:
    """ChainStream SDK Client for accessing both REST API and WebSocket streams.

    Example:
        ```python
        import asyncio
        from chainstream import ChainStreamClient
        from chainstream.stream import Resolution, TokenCandle

        async def main():
            client = ChainStreamClient("your-access-token")

            # Subscribe to token candles
            unsub = await client.stream.subscribe_token_candles(
                chain="sol",
                token_address="So11111111111111111111111111111111111111112",
                resolution=Resolution.S1,
                callback=lambda candle: print(f"Candle: {candle}"),
            )

            # Wait for some data
            await asyncio.sleep(30)

            # Unsubscribe and close
            unsub.unsubscribe()
            await client.close()

        asyncio.run(main())
        ```
    """

    def __init__(
        self,
        access_token: str = "",
        options: Optional[ChainStreamClientOptions] = None,
        token_provider: Optional[TokenProvider] = None,
        wallet_signer: Optional[WalletSigner] = None,
    ) -> None:
        """Initialize the ChainStreamClient.

        Args:
            access_token: The access token for authentication (use this OR wallet_signer).
            options: Optional configuration options.
            token_provider: Optional custom token provider.
            wallet_signer: Optional wallet signer for x402 wallet signature auth.
                When provided, each request is signed with the wallet's private key.
        """
        self._options = options or ChainStreamClientOptions()
        self._token_provider = token_provider or (StaticTokenProvider(access_token) if access_token else None)
        self._access_token = access_token
        self._wallet_signer = wallet_signer

        # Initialize stream API
        self._stream = StreamApi(self._options.stream_url, access_token)

    @property
    def stream(self) -> StreamApi:
        """Get the stream API client."""
        return self._stream

    @property
    def wallet_signer(self) -> Optional[WalletSigner]:
        """Get the wallet signer, if configured."""
        return self._wallet_signer

    def get_access_token(self) -> str:
        """Get the current access token."""
        if self._token_provider is None:
            return ""
        return self._token_provider.get_token()

    async def close(self) -> None:
        """Close all connections."""
        await self._stream.disconnect()
