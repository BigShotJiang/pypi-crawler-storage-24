from __future__ import annotations

from collections import defaultdict
from typing import Sequence

from schore.schedule.exception import SchedulingFailureException

from .hybrid_flowshop_operation import HybridFlowshopOperation
from .hybrid_flowshop_stage import HybridFlowshopStage


class HybridFlowshopSchedule:
    def __init__(self) -> None:
        self._stages: dict[str, HybridFlowshopStage] = {}
        """Stage name -> HybridFlowshopStage instance."""
        self._stage_name_list: list[str] = []
        """Ordered stage names used to define the flow direction (prev/next stage).

        If empty, the insertion order of `self._stages` is used.
        """

        self._last_stage_name: str | None = None
        """The name of the last stage in the flowshop."""

        # Internal state

        self.job_2_last_oper_end_time_map: dict[str, int] = defaultdict(int)
        """Job name -> end time of the last operation scheduled for that job."""

    @classmethod
    def from_stage_name_2_mc_name_list_map(
        cls, stage_name_2_mc_name_list_map: dict[str, list[str]]
    ) -> HybridFlowshopSchedule:
        """
        Create a HybridFlowshopSchedule from a mapping of stage IDs to machine IDs.

        Args:
            stage_name_2_mc_name_list_map (dict[str, list[str]]): Mapping of stage IDs to lists of machine IDs.

        Returns:
            HybridFlowshopSchedule: A new instance of HybridFlowshopSchedule.
        """
        schedule = cls()
        schedule._stage_name_list = list(stage_name_2_mc_name_list_map.keys())
        for stage_name, mc_name_list in stage_name_2_mc_name_list_map.items():
            schedule._stages[stage_name] = HybridFlowshopStage.from_mc_name_list(
                stage_name, mc_name_list
            )
        return schedule

    def deepcopy(self) -> HybridFlowshopSchedule:
        """
        Returns a deep copy of this HybridFlowshopSchedule,
        including all stages and internal state.
        """
        from copy import deepcopy

        new_schedule = HybridFlowshopSchedule()
        # Deep copy stages
        new_schedule._stages = {k: v.deepcopy() for k, v in self._stages.items()}
        new_schedule._stage_name_list = self._stage_name_list.copy()
        new_schedule._last_stage_name = self._last_stage_name
        # Deep copy internal state
        new_schedule.job_2_last_oper_end_time_map = deepcopy(
            self.job_2_last_oper_end_time_map
        )
        return new_schedule

    def _get_stage_name_list(self) -> list[str]:
        return self._stage_name_list if self._stage_name_list else list(self._stages)

    def _get_prev_stage_name(self, stage_name: str) -> str | None:
        stage_name_list = self._get_stage_name_list()
        if stage_name not in stage_name_list:
            raise ValueError(f"Stage {stage_name} not found in schedule")
        stage_idx = stage_name_list.index(stage_name)
        if stage_idx == 0:
            return None
        return stage_name_list[stage_idx - 1]

    def _get_job_end_time_in_stage(
        self, stage_name: str, job_name: str, default_if_missing: int = 0
    ) -> int:
        stage = self.get_stage_by_name(stage_name)
        max_end_time: int | None = None
        for machine in stage.resources:
            for op in machine.operations:
                if op.job_name == job_name:
                    if max_end_time is None or op.end > max_end_time:
                        max_end_time = op.end
        return default_if_missing if max_end_time is None else max_end_time

    def _get_prev_stage_end_time(self, stage_name: str, job_name: str) -> int:
        prev_stage_name = self._get_prev_stage_name(stage_name)
        if prev_stage_name is None:
            return 0
        return self._get_job_end_time_in_stage(prev_stage_name, job_name, 0)

    def _recompute_job_last_oper_end_time(self, job_name: str) -> None:
        max_end_time = 0
        for stage in self._stages.values():
            for machine in stage.resources:
                for op in machine.operations:
                    if op.job_name == job_name and op.end > max_end_time:
                        max_end_time = op.end
        self.job_2_last_oper_end_time_map[job_name] = max_end_time

    # Start getters

    @property
    def makespan(self) -> int:
        """
        Calculate the makespan of the entire schedule.

        Returns:
            int: The latest completion time across all stages.
                If the last stage name is set, returns the latest completion time of that stage.
        """
        if self._last_stage_name:
            return self.get_stage_by_name(self._last_stage_name).makespan
        return max((stage.makespan for stage in self._stages.values()), default=0)

    def get_stage_by_name(self, stage_name: str) -> HybridFlowshopStage:
        """
        Get a stage by its name.

        Args:
            stage_name (str): The name of the stage to retrieve.

        Raises:
            ValueError: If the stage with the given name does not exist in the schedule.

        Returns:
            HybridFlowshopStage: The stage instance with the specified name.
        """
        if stage_name not in self._stages:
            raise ValueError(f"Stage {stage_name} not found in schedule")
        return self._stages[stage_name]

    def get_earliest_start_mc_name_and_time(
        self, stage_name: str, p: int, release_t: int = 0
    ) -> tuple[str, int]:
        """Get the earliest available machine name and start time for a given stage.

        Args:
            stage_name (str): The name of the stage to check.
            p (int): The processing time required for the operation.
            release_t (int, optional): The earliest time the operation can start.
                Defaults to 0.

        Returns:
            tuple[str, int]: A tuple containing the name of the earliest available machine
                and the time it can start processing the operation.
        """
        return self.get_stage_by_name(stage_name).get_earliest_start_mc_name_and_time(
            p, release_t
        )

    def get_start_time_map(self) -> dict[tuple[str, str, str], int]:
        """
        Get a map of (job_name, stage_name, mc_name) to start time for all operations in the schedule.

        Returns:
            dict[tuple[str, str, str], int]: A dictionary mapping (job_name, stage_name, mc_name) to start time.
        """
        return_dict: dict[tuple[str, str, str], int] = {}
        for stage in self._stages.values():
            stage_start_time_map = stage.get_start_time_map()
            for key, value in stage_start_time_map.items():
                if key in return_dict:
                    raise ValueError(
                        f"Duplicate start time entry for key {key} in stage {stage.name}."
                    )
                return_dict[key] = value
        return return_dict

    def get_end_time_map(self) -> dict[tuple[str, str, str], int]:
        """
        Get a map of (job_name, stage_name, mc_name) to end time for all operations in the schedule.

        Returns:
            dict[tuple[str, str, str], int]: A dictionary mapping (job_name, stage_name, mc_name) to end time.
        """
        return_dict: dict[tuple[str, str, str], int] = {}
        for stage in self._stages.values():
            stage_end_time_map = stage.get_end_time_map()
            for key, value in stage_end_time_map.items():
                if key in return_dict:
                    raise ValueError(
                        f"Duplicate end time entry for key {key} in stage {stage.name}."
                    )
                return_dict[key] = value
        return return_dict

    # End getters

    # Start setters

    def set_last_stage_name(self, stage_name: str) -> None:
        """Set the name of the last stage in the flowshop.

        Args:
            stage_name (str): The name of the last stage.

        Raises:
            ValueError: If the specified stage does not exist in the schedule.
        """
        if stage_name not in self._stages:
            raise ValueError(f"Stage {stage_name} not found in schedule")
        self._last_stage_name = stage_name

    def schedule_operation(
        self,
        operation: HybridFlowshopOperation,
        force_add: bool = False,
    ) -> HybridFlowshopOperation | None:
        return self.get_stage_by_name(operation.stage_name).add_operation(
            operation, force_add=force_add
        )

    def dispatch_operation_earliest(
        self, job_name: str, stage_name: str, p: int, release_t: int | None = None
    ) -> HybridFlowshopOperation:
        """Dispatch an operation to the earliest available machine in the specified stage.

        Args:
            job_name (str): The name of the job this operation belongs to.
            stage_name (str): The name of the stage this operation belongs to.
            p (int): The processing time required for this operation.
            release_t (int | None, optional): The earliest time the operation can start.
                Defaults to None.

        Raises:
            SchedulingFailureException: If the operation is not scheduled.

        Returns:
            HybridFlowshopOperation: The scheduled operation.
        """
        stage = self.get_stage_by_name(stage_name)
        prev_stage_end_time = self._get_prev_stage_end_time(stage_name, job_name)
        _release_t = (
            prev_stage_end_time
            if release_t is None
            else max(prev_stage_end_time, release_t)
        )
        mc_name, start_time = stage.select_machine_by_start_idle_idx(p, _release_t)
        # integer casting to ensure start_time is an integer
        # (not np.int64 for YAML compatibility)
        end_time = int(start_time + p)
        operation = stage.add_operation(
            HybridFlowshopOperation(
                job_name=job_name,
                stage_name=stage_name,
                mc_name=mc_name,
                start=start_time,
                end=end_time,
            )
        )
        if operation is None:
            raise SchedulingFailureException(
                f"{job_name}.{stage_name}", p, mc_name, start_time
            )

        # Update internal state
        if operation.end > self.job_2_last_oper_end_time_map[job_name]:
            self.job_2_last_oper_end_time_map[job_name] = operation.end

        return operation

    def dispatch_job_by_stages(
        self,
        job_name: str,
        stage_name_list: Sequence[str],
        stage_name_2_p_map: dict[str, int],
        release_t: int = 0,
    ) -> list[HybridFlowshopOperation]:
        """
        Dispatch a job across multiple stages, scheduling each stage's operation
        on the earliest available machine.

        Args:
            job_name (str): The name of the job to be dispatched.
            stage_name_list (Sequence[str]): List of stage names in the order they should be processed.
            stage_name_2_p_map (dict[str, int]): Stage name -> processing time.
            release_t (int, optional): The earliest time the job can start processing at the 1st stage.
                Defaults to 0.

        Returns:
            list[HybridFlowshopOperation]: A list of scheduled operations for the job across all stages.
        """
        operations = []
        last_end_time = max(self.job_2_last_oper_end_time_map[job_name], release_t)

        for stage_name in stage_name_list:
            operation = self.dispatch_operation_earliest(
                job_name,
                stage_name,
                stage_name_2_p_map[stage_name],
                release_t=last_end_time,
            )
            operations.append(operation)
            last_end_time = operation.end

        return operations

    def dispatch_stage_by_jobs(
        self,
        stage_name: str,
        job_name_list: Sequence[str],
        job_name_2_p_map: dict[str, int],
        release_t: int | None = None,
    ) -> list[HybridFlowshopOperation]:
        """
        Dispatch operations for a given stage, scheduling jobs in the order
        determined by job_priority_queue.

        The job_priority_queue is sorted by:
        1. Jobs with smaller last operation end time are scheduled earlier.
        2. If two jobs have the same last operation end time,
           jobs that come earlier in job_name_list are scheduled earlier.

        Args:
            stage_name (str): Target stage name.
            job_name_list (Sequence[str]): List of job names to be dispatched in this stage.
            job_name_2_p_map (dict[str, int]): Job name -> processing time.
            release_t (int | None, optional): The earliest time the stage can start.
                Defaults to None.

        Returns:
            list[HybridFlowshopOperation]: A list of scheduled operations for the jobs
                in the specified stage, in job_priority_queue order.
        """
        operations = []

        # Make a job priority queue.
        # 1. Jobs having smaller last operation end time are scheduled earlier.
        # 2. If two jobs have the same last operation end time,
        #    jobs that comes earlier in job_name_list are scheduled earlier.
        pos = {job: i for i, job in enumerate(job_name_list)}
        job_priority_queue = sorted(
            job_name_list,
            key=lambda job_name: (
                self.job_2_last_oper_end_time_map[job_name],
                pos[job_name],
            ),
        )
        # logging.info(f"Dispatching stage {stage_name} for jobs {job_priority_queue}")

        for job_name in job_priority_queue:
            operation = self.dispatch_operation_earliest(
                job_name, stage_name, job_name_2_p_map[job_name], release_t=release_t
            )
            operations.append(operation)

        return operations

    def remove_operation_from_machine_by_job_name(
        self, stage_name: str, mc_name: str, job_name: str, recompute: bool = True
    ) -> bool:
        """
        Remove an operation from a stage by job name.

        Args:
            stage_name (str): The name of the stage from which to remove the operation.
            job_name (str): The job name of the operation to remove.

        Returns:
            bool: True if the operation was removed, False if it was not found.
        """
        removed = (
            self.get_stage_by_name(stage_name)
            .get_machine_by_name(mc_name)
            .remove_operation_by_job_name(job_name)
        )

        if removed and recompute:
            self._recompute_job_last_oper_end_time(job_name)

        return removed

    def remove_operations_by_list_of_job_stage_mc_names(
        self, job_stage_mc_names: Sequence[tuple[str, str, str]]
    ) -> bool:
        """
        Remove a list of operations from stages by job name, stage name, and machine name.

        Args:
            job_stage_mc_names (Sequence[tuple[str, str, str]]): A list of tuples containing
                (job_name, stage_name, mc_name) for the operations to remove.

        Returns:
            bool: True if all operations were removed, False if any were not found.
        """
        all_removed = True
        removed_jobs: set[str] = set()
        for job_name, stage_name, mc_name in job_stage_mc_names:
            removed = self.remove_operation_from_machine_by_job_name(
                stage_name, mc_name, job_name, recompute=False
            )
            all_removed = all_removed and removed
            if removed:
                removed_jobs.add(job_name)

        # In case multiple operations of the same job are removed,
        # ensure the internal state matches the remaining schedule.
        for job_name in removed_jobs:
            self._recompute_job_last_oper_end_time(job_name)
        return all_removed

    # End setters
