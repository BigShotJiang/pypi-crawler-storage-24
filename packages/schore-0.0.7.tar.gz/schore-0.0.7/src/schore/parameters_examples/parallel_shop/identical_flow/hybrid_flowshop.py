from __future__ import annotations

from functools import cached_property
from typing import TextIO

import pandas as pd

from schore.parameters import JobStageProcessingTimeManager
from schore.util import TextDataParser


class HybridFlowshopParameters:
    """
    Represents parameters for a hybrid flowshop problem instance with multiple jobs and stages,
    where each stage may have multiple parallel machines.

    This class assumes all machines at a given stage are eligible for any operation at that stage.

    This class only encapsulates the input data/parameters for a hybrid flowshop problem instance;
    it does not include solution or scheduling logic.
    """  # noqa: E501

    name: str
    """Name of the problem instance."""

    _job_id_list: list[str]
    """A list of job IDs."""
    _stage_id_list: list[str]
    """A list of stage IDs."""
    _stage_2_machines_map: dict[str, list[str]]
    """Mapping from stage IDs to lists of machine IDs at that stage."""
    p_manager: JobStageProcessingTimeManager[int]
    """Manager for processing times of jobs at each stage."""

    def __init__(
        self,
        name: str,
        job_id_list: list[str],
        stage_id_list: list[str],
        stage_2_machines_map: dict[str, list[str]],
        p_manager: JobStageProcessingTimeManager,
    ):
        self.name = name
        self._job_id_list = job_id_list
        self._stage_id_list = stage_id_list
        self._stage_2_machines_map = stage_2_machines_map  # e.g., [2, 3, 2]
        self.p_manager = p_manager

    @property
    def job_id_list(self) -> list[str]:
        """Get list of job IDs."""
        return self._job_id_list.copy()

    @property
    def stage_id_list(self) -> list[str]:
        """Get list of stage IDs."""
        return self._stage_id_list.copy()

    @property
    def stage_2_machines_map(self) -> dict[str, list[str]]:
        """Get mapping from stage IDs to lists of machine IDs."""
        return self._stage_2_machines_map.copy()

    @cached_property
    def job_count(self) -> int:
        return len(self._job_id_list)

    @cached_property
    def stage_count(self) -> int:
        return len(self._stage_id_list)

    @cached_property
    def machine_count_per_stage(self) -> list[int]:
        """List of the number of parallel machines at each stage."""
        return [
            len(self._stage_2_machines_map[stage_id])
            for stage_id in self._stage_id_list
        ]

    @cached_property
    def operation_count(self) -> int:
        """Total number of operations (jobs x stages)."""
        return self.job_count * self.stage_count

    @cached_property
    def job_2_stage_2_p_map(self) -> dict[str, dict[str, int]]:
        return self.p_manager.job_2_stage_2_value_map(
            self.job_id_list, self.stage_id_list
        )

    @cached_property
    def stage_2_job_2_p_map(self) -> dict[str, dict[str, int]]:
        return self.p_manager.stage_2_job_2_value_map(
            self.stage_id_list, self.job_id_list
        )

    def __repr__(self):
        return (
            f"HybridFlowshopParameters(job_count={self.job_count},"
            f" stage_count={self.stage_count})"
        )

    @classmethod
    def from_pra_data(cls, name: str, stream: TextIO) -> HybridFlowshopParameters:
        """
        Parse hybrid flowshop parameters from a text stream in PRA-style format.

        Expected format:
            <job_count>
            <stage_count>
            <machine_count_per_stage>  # space-separated list
            <processing_time_row_0>
            <processing_time_row_1>
            ...
            <processing_time_row_n-1>

        Args:
            name (str): Name of the problem instance.
            stream (TextIO): Input stream (e.g., open file or StringIO) containing instance data.

        Returns:
            HybridFlowshopParameters: Parsed parameters instance.
        """  # noqa: E501
        job_count = TextDataParser.strip_a_typed_value(stream, int)
        stage_count = TextDataParser.strip_a_typed_value(stream, int)
        machine_count_per_stage = TextDataParser.strip_a_typed_list(stream, int)

        cls._validate_machine_count_per_stage(stage_count, machine_count_per_stage)

        # Generate a list of job IDs with zero-padded numbers.
        num_digits = len(str(job_count - 1))
        job_id_list = [f"j{str(j).zfill(num_digits)}" for j in range(job_count)]

        # Generate a list of stage IDs with zero-padded numbers.
        num_digits = len(str(stage_count - 1))
        stage_id_list = [f"i{str(s).zfill(num_digits)}" for s in range(stage_count)]

        # Generate a mapping from stage IDs to lists of machine IDs.
        stage_2_machines_map: dict[str, list[str]] = {}
        for stage_idx, stage_id in enumerate(stage_id_list):
            num_digits = len(str(machine_count_per_stage[stage_idx] - 1))
            machine_ids = [
                f"{stage_id}_{str(m).zfill(num_digits)}"
                for m in range(machine_count_per_stage[stage_idx])
            ]
            stage_2_machines_map[stage_id] = machine_ids

        processing_times = JobStageProcessingTimeManager.from_text_stream(
            stream, job_count, dtype=int
        )

        cls._validate_processing_times(job_count, stage_count, processing_times)

        return cls(
            name, job_id_list, stage_id_list, stage_2_machines_map, processing_times
        )

    @classmethod
    def from_ff2020_data(cls, name: str, stream: TextIO) -> HybridFlowshopParameters:
        """
        Parse hybrid flowshop parameters from a text stream in FF2020-style format.

        Expected format:
            <machine_count_stage_0> ... <machine_count_stage_(stage_count-1)>
            # Next stage_count lines: processing times, one line per stage
            <processing_time_stage_0_job_0> ... <processing_time_stage_0_job_(job_count-1)>
            ...
            <processing_time_stage_(stage_count-1)_job_0> ... <processing_time_stage_(stage_count-1)_job_(job_count-1)>

        Args:
            name (str): Name of the problem instance.
            stream (TextIO): Input stream (e.g., open file or StringIO) containing instance data.

        Returns:
            HybridFlowshopParameters: Parsed parameters instance.
        """
        job_cnt_and_stage_cnt_list: list[int] = TextDataParser.strip_a_typed_list(
            stream, int
        )
        if len(job_cnt_and_stage_cnt_list) != 2:
            raise ValueError(
                f"Expected exactly 2 integers for job and stage counts in header, "
                f"but parsed {len(job_cnt_and_stage_cnt_list)}: {job_cnt_and_stage_cnt_list}"
            )
        job_count = job_cnt_and_stage_cnt_list[0]
        stage_count = job_cnt_and_stage_cnt_list[1]
        machine_count_per_stage = TextDataParser.strip_a_typed_list(stream, int)

        cls._validate_machine_count_per_stage(stage_count, machine_count_per_stage)

        # Generate a list of job IDs with zero-padded numbers.
        num_digits = len(str(job_count - 1))
        job_id_list = [f"j{str(j).zfill(num_digits)}" for j in range(job_count)]

        # Generate a list of stage IDs with zero-padded numbers.
        num_digits = len(str(stage_count - 1))
        stage_id_list = [f"i{str(s).zfill(num_digits)}" for s in range(stage_count)]

        # Generate a mapping from stage IDs to lists of machine IDs.
        stage_2_machines_map: dict[str, list[str]] = {}
        for stage_idx, stage_id in enumerate(stage_id_list):
            num_digits = len(str(machine_count_per_stage[stage_idx] - 1))
            machine_ids = [
                f"{stage_id}_{str(m).zfill(num_digits)}"
                for m in range(machine_count_per_stage[stage_idx])
            ]
            stage_2_machines_map[stage_id] = machine_ids

        processing_times = JobStageProcessingTimeManager.from_text_stream(
            stream, stage_count, dtype=int, transpose=True
        )

        cls._validate_processing_times(job_count, stage_count, processing_times)

        return cls(
            name, job_id_list, stage_id_list, stage_2_machines_map, processing_times
        )

    @staticmethod
    def _validate_machine_count_per_stage(
        stage_count: int, machine_count_per_stage: list[int]
    ):
        if len(machine_count_per_stage) != stage_count:
            raise ValueError(
                f"Stage count mismatch; stage_count={stage_count};"
                f" by machine_count_per_stage={len(machine_count_per_stage)}"
            )

    @staticmethod
    def _validate_processing_times(
        job_count: int,
        stage_count: int,
        processing_times: JobStageProcessingTimeManager,
    ):
        if processing_times.df.isnull().values.any():
            raise ValueError("Null value exists in the processing time data.")
        if processing_times.row_count() != job_count:
            raise ValueError(
                f"Job count mismatch; expected {job_count},"
                f" got {processing_times.row_count()}."
            )
        if processing_times.col_count() != stage_count:
            raise ValueError(
                f"Stage count mismatch; expected {stage_count},"
                f" got {processing_times.col_count()}."
            )


def create_instance_of_job_subset(
    instance: HybridFlowshopParameters, job_id_sublist: list[str]
) -> HybridFlowshopParameters:
    """Create a new instance of HybridFlowshopParameters with a subset of jobs.

    Args:
        instance (HybridFlowshopParameters): Original parameters instance.
        job_id_sublist (list[str]): List of job IDs to include in the new instance.
            The order of job IDs in the list will be preserved in the filtered result.

    Raises:
        ValueError: If the job subset contains invalid or duplicate job IDs.

    Returns:
        HybridFlowshopParameters: New parameters instance with the specified job subset.
    """
    if not set(job_id_sublist).issubset(instance.job_id_list):
        raise ValueError("Job subset contains invalid job IDs.")
    # Check duplicate IDs
    if len(set(job_id_sublist)) != len(job_id_sublist):
        raise ValueError("Job subset contains duplicate job IDs.")

    job_id_2_index = {job_id: idx for idx, job_id in enumerate(instance.job_id_list)}
    job_index_list = [job_id_2_index[job_id] for job_id in job_id_sublist]
    new_processing_times = instance.p_manager.filter_by_job_indices(job_index_list)

    return HybridFlowshopParameters(
        instance.name,
        job_id_sublist,
        instance.stage_id_list,
        instance.stage_2_machines_map,
        new_processing_times,
    )


def create_instance_of_stage_subset(
    instance: HybridFlowshopParameters, stage_id_sublist: list[str]
) -> HybridFlowshopParameters:
    """Create a new instance of HybridFlowshopParameters with a subset of stages.

    Args:
        instance (HybridFlowshopParameters): Original parameters instance.
        stage_id_sublist (list[str]): List of stage IDs to include in the new instance.
            The order of stage IDs in the list will be preserved in the filtered result.

    Raises:
        ValueError: If the stage subset contains invalid or duplicate stage IDs.

    Returns:
        HybridFlowshopParameters: New parameters instance with the specified stage subset.
    """
    if not set(stage_id_sublist).issubset(instance.stage_id_list):
        raise ValueError("Stage subset contains invalid stage IDs.")
    # Check duplicate IDs
    if len(set(stage_id_sublist)) != len(stage_id_sublist):
        raise ValueError("Stage subset contains duplicate stage IDs.")

    stage_id_2_index = {
        stage_id: idx for idx, stage_id in enumerate(instance.stage_id_list)
    }
    stage_index_list = [stage_id_2_index[stage_id] for stage_id in stage_id_sublist]
    new_processing_times = instance.p_manager.filter_by_stage_indices(stage_index_list)

    new_stage_2_machines_map = {
        stage_id: instance.stage_2_machines_map[stage_id]
        for stage_id in stage_id_sublist
    }

    return HybridFlowshopParameters(
        instance.name,
        instance.job_id_list,
        stage_id_sublist,
        new_stage_2_machines_map,
        new_processing_times,
    )


def reverse_stages(
    instance: HybridFlowshopParameters,
) -> HybridFlowshopParameters:
    """Create a new instance of HybridFlowshopParameters with the order of stages reversed.

    Args:
        instance (HybridFlowshopParameters): Original parameters instance.

    Returns:
        HybridFlowshopParameters: New parameters instance with reversed stage order.
    """
    new_stage_ids = instance.stage_id_list[::-1]
    new_processing_times = instance.p_manager.as_stage_reversed()
    new_stage_2_machines_map = {
        stage_id: list(instance.stage_2_machines_map[stage_id])
        for stage_id in new_stage_ids
    }

    return HybridFlowshopParameters(
        instance.name + "_reversed",
        instance.job_id_list,
        new_stage_ids,
        new_stage_2_machines_map,
        new_processing_times,
    )


def create_instance_of_aggregated_stages(
    instance: HybridFlowshopParameters,
    stage_agg_count: int,
    head_stages_to_keep: int = 0,
    tail_stages_to_keep: int = 0,
    p_agg_method: str = "sum",
    mi_agg_method: str = "min",
) -> HybridFlowshopParameters:
    """Create a new instance of HybridFlowshopParameters with aggregated stages.

    Args:
        instance (HybridFlowshopParameters): Original parameters instance.
        stage_agg_count (int): Number of stages to aggregate into a single stage.
        head_stages_to_keep (int, optional): Number of stages in the beginning
            to be excluded from aggregation. Defaults to 0.
        tail_stages_to_keep (int, optional): Number of stages at the end to be excluded
            from aggregation. Defaults to 0.
        p_agg_method (str, optional): Processing time aggregation method (e.g., "sum", "mean").
            When "mean" is used, the mean is computed with pandas, rounded using
            ``Series.round`` (bankers rounding, e.g. ``2.5 -> 2``) and cast to ``int``,
            so aggregated processing times remain integral. Defaults to "sum".
        mi_agg_method (str, optional): Machine count aggregation method (e.g., "min", "max").
            Defaults to "min".
    Raises:
        ValueError:
            - If head_stages_to_keep or tail_stages_to_keep is negative.
            - If stage_agg_count is less than 2.
            - If head_stages_to_keep + tail_stages_to_keep exceeds the total number of stages.
            - If p_agg_method or mi_agg_method is not supported.

    Returns:
        HybridFlowshopParameters: New parameters instance with aggregated stages.
    """
    original_stage_ids = instance.stage_id_list
    original_p_manager = instance.p_manager

    # Validate inputs
    if head_stages_to_keep < 0:
        raise ValueError("head_stages_to_keep must be non-negative")
    if stage_agg_count <= 1:
        raise ValueError("stage_agg_count must be at least 2")
    if tail_stages_to_keep < 0:
        raise ValueError("tail_stages_to_keep must be non-negative")
    if head_stages_to_keep + tail_stages_to_keep > len(original_stage_ids):
        raise ValueError(
            "head_stages_to_keep + tail_stages_to_keep cannot exceed the number of stages"
        )

    # Precompute stage_id to index mapping for O(1) lookups
    stage_id_to_index = {
        stage_id: idx for idx, stage_id in enumerate(original_stage_ids)
    }

    # Head & tail stages stay unchanged
    head_stages = original_stage_ids[:head_stages_to_keep]
    tail_stages = original_stage_ids[len(original_stage_ids) - tail_stages_to_keep :]

    # Remaining stages to be aggregated
    remaining_stages = original_stage_ids[
        head_stages_to_keep : len(original_stage_ids) - tail_stages_to_keep
    ]
    remaining_count = len(remaining_stages)

    if remaining_count == 0:
        # All stages are head & tail stages, return a copy
        return HybridFlowshopParameters(
            instance.name,
            instance.job_id_list,
            original_stage_ids,
            {
                stage_id: instance.stage_2_machines_map[stage_id]
                for stage_id in original_stage_ids
            },
            original_p_manager,
        )

    # Calculate aggregated stages
    # Each aggregated stage combines stage_agg_count original stages
    num_aggregated = (remaining_count + stage_agg_count - 1) // stage_agg_count

    # Generate new stage IDs for aggregated stages
    aggregated_stage_ids = [
        f"sa{str(i).zfill(len(str(num_aggregated - 1)))}" for i in range(num_aggregated)
    ]

    # New stage list: head stages + aggregated stages + tail stages
    new_stage_ids = head_stages + aggregated_stage_ids + tail_stages

    # Aggregate processing times
    new_p_values = []

    # Head stages: copy as-is
    for stage_id in head_stages:
        stage_idx = stage_id_to_index[stage_id]
        new_p_values.append(original_p_manager.df.iloc[:, stage_idx].tolist())

    # Aggregated stages: aggregate using agg_method
    aggregation_end_idx = head_stages_to_keep + remaining_count
    for agg_idx in range(num_aggregated):
        start_idx = head_stages_to_keep + agg_idx * stage_agg_count
        end_idx = min(start_idx + stage_agg_count, aggregation_end_idx)
        stage_indices = list(range(start_idx, end_idx))

        # Get the subset of processing times for these stages
        agg_df = original_p_manager.df.iloc[:, stage_indices]

        if p_agg_method == "sum":
            agg_values = agg_df.sum(axis=1).tolist()
        elif p_agg_method == "mean":
            agg_values = agg_df.mean(axis=1).round().astype(int).tolist()
        else:
            raise ValueError(f"Unsupported p_agg_method: {p_agg_method}")

        new_p_values.append(agg_values)

    # Tail stages: copy as-is
    for stage_id in tail_stages:
        stage_idx = stage_id_to_index[stage_id]
        new_p_values.append(original_p_manager.df.iloc[:, stage_idx].tolist())

    # Build new processing time DataFrame with new_stage_ids as columns

    new_p_df = pd.DataFrame(
        {stage_id: new_p_values[i] for i, stage_id in enumerate(new_stage_ids)},
        index=original_p_manager.df.index,
    )

    new_p_manager = original_p_manager.__class__(original_p_manager.name, new_p_df)

    # Generate new stage_2_machines_map
    new_stage_2_machines_map: dict[str, list[str]] = {}
    for stage_id in head_stages:
        new_stage_2_machines_map[stage_id] = instance.stage_2_machines_map[stage_id]

    # For aggregated stages, aggregate machine counts based on mi_agg_method
    for agg_idx in range(num_aggregated):
        agg_stage_id = aggregated_stage_ids[agg_idx]
        start_idx = head_stages_to_keep + agg_idx * stage_agg_count
        end_idx = min(start_idx + stage_agg_count, aggregation_end_idx)
        original_stage_indices = list(range(start_idx, end_idx))

        if mi_agg_method == "min":
            mc_count_on_stage = min(
                len(instance.stage_2_machines_map[original_stage_ids[idx]])
                for idx in original_stage_indices
            )
        elif mi_agg_method == "max":
            mc_count_on_stage = max(
                len(instance.stage_2_machines_map[original_stage_ids[idx]])
                for idx in original_stage_indices
            )
        else:
            raise ValueError(f"Unsupported mi_agg_method: {mi_agg_method}")
        # Generate machine IDs for aggregated stage
        num_digits = len(str(mc_count_on_stage - 1)) if mc_count_on_stage > 0 else 1
        machine_ids = [
            f"{agg_stage_id}_{str(m).zfill(num_digits)}"
            for m in range(mc_count_on_stage)
        ]
        new_stage_2_machines_map[agg_stage_id] = machine_ids

    for stage_id in tail_stages:
        new_stage_2_machines_map[stage_id] = instance.stage_2_machines_map[stage_id]

    return HybridFlowshopParameters(
        instance.name,
        instance.job_id_list,
        new_stage_ids,
        new_stage_2_machines_map,
        new_p_manager,
    )
