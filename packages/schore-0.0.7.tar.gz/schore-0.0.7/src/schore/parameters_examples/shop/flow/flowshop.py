from __future__ import annotations

from schore.parameters import JobStageProcessingTimeManager


class FlowshopParameters:
    name: str

    _job_id_list: list[str]
    """A list of job IDs."""
    _stage_id_list: list[str]
    """A list of stage IDs."""
    p_manager: JobStageProcessingTimeManager[int]
    """Manager for processing times of jobs at each stage."""

    def __init__(
        self,
        name: str,
        job_id_list: list[str],
        stage_id_list: list[str],
        p_manager: JobStageProcessingTimeManager[int],
    ) -> None:
        self.name = name
        self._job_id_list = job_id_list
        self._stage_id_list = stage_id_list
        self.p_manager = p_manager

    @property
    def job_id_list(self) -> list[str]:
        """Get list of job IDs."""
        return self._job_id_list.copy()

    @property
    def stage_id_list(self) -> list[str]:
        """Get list of stage IDs."""
        return self._stage_id_list.copy()

    @property
    def job_count(self) -> int:
        return len(self._job_id_list)

    @property
    def stage_count(self) -> int:
        return len(self._stage_id_list)

    def __repr__(self):
        return (
            f"{self.__class__.__name__}(job_count={self.job_count},"
            f" stage_count={self.stage_count})"
        )

    @staticmethod
    def _validate_processing_times(
        job_count: int,
        stage_count: int,
        processing_times: JobStageProcessingTimeManager,
    ):
        if processing_times.df.isnull().values.any():
            raise ValueError("Null value exists in the processing time data.")
        if processing_times.row_count() != job_count:
            raise ValueError(
                f"Job count mismatch; expected {job_count},"
                f" got {processing_times.row_count()}."
            )
        if processing_times.col_count() != stage_count:
            raise ValueError(
                f"Stage count mismatch; expected {stage_count},"
                f" got {processing_times.col_count()}."
            )

    def get_subinstance(
        self,
        job_id_list: list[str] | None = None,
        stage_id_list: list[str] | None = None,
    ) -> FlowshopParameters:
        """Get a subinstance of the flowshop parameters.

        Args:
            job_id_list (list[str] | None): List of job IDs to include in the subinstance.
                If None, all jobs are included.
            stage_id_list (list[str] | None): List of stage IDs to include in the subinstance.
                If None, all stages are included.

        Returns:
            FlowshopParameters: A new FlowshopParameters instance representing the subinstance.
        """
        if job_id_list is None:
            job_id_list = self._job_id_list
        if stage_id_list is None:
            stage_id_list = self._stage_id_list
        sub_p_manager = self.p_manager.filter_by_job_indices(
            [self._job_id_list.index(j) for j in job_id_list]
        ).filter_by_stage_indices([self._stage_id_list.index(s) for s in stage_id_list])

        return FlowshopParameters(
            name=self.name + "_sub",
            job_id_list=job_id_list.copy(),
            stage_id_list=stage_id_list.copy(),
            p_manager=sub_p_manager,
        )

    def get_job_2_p_sum_except_last_stage(self) -> dict[str, int]:
        """Get mapping from job ID to sum of processing times except the last stage.

        Returns:
            dict[str, int]: A mapping from job ID to sum of processing times
            except the last stage.
        """
        j_2_i_2_p_map = self.p_manager.job_2_stage_2_value_map(
            self._job_id_list, self._stage_id_list
        )
        job_2_p_sum: dict[str, int] = {}
        for job_id in self._job_id_list:
            i_2_p_map = j_2_i_2_p_map[job_id]
            job_2_p_sum[job_id] = sum(
                i_2_p_map[stage_id] for stage_id in self._stage_id_list[:-1]
            )
        return job_2_p_sum

    def get_job_2_p_map(self, stage_id: str) -> dict[str, int]:
        """Get mapping from job ID to processing time at the specified stage.

        Args:
            stage_id (str): The stage ID.

        Returns:
            dict[str, int]: A mapping from job ID to processing time at the specified stage.
        """
        i_2_j_2_p_map = self.p_manager.stage_2_job_2_value_map(
            self._stage_id_list, self._job_id_list
        )
        return {key: int(value) for key, value in i_2_j_2_p_map[stage_id].items()}

    def get_stage_job_2_builtin_int_p_map(self) -> dict[tuple[str, str], int]:
        """Get a dictionary mapping (stage ID, job ID) to processing time.

        Returns:
            dict[tuple[str, str], int]: A dictionary where keys are (stage ID, job ID)
            tuples and values are processing times as builtin integers.
        """
        raw_dict = self.p_manager.stage_job_2_value_map(
            self.stage_id_list, self.job_id_list
        )
        return {(stage, job): int(p) for (stage, job), p in raw_dict.items()}

    def get_stage_2_job_2_builtin_int_p_map(self) -> dict[str, dict[str, int]]:
        """Get a nested dictionary mapping stage IDs to job IDs to processing times.

        Returns:
            dict[str, dict[str, int]]: A nested dictionary where the outer keys are stage IDs,
            the inner keys are job IDs, and the values are processing times as builtin integers.
        """
        raw_dict = self.p_manager.stage_2_job_2_value_map(
            self.stage_id_list, self.job_id_list
        )
        return {
            stage: {job: int(p) for job, p in job_map.items()}
            for stage, job_map in raw_dict.items()
        }

    def get_job_2_stage_2_builtin_int_p_map(self) -> dict[str, dict[str, int]]:
        """Get a nested dictionary mapping job IDs to stage IDs to processing times.

        Returns:
            dict[str, dict[str, int]]: A nested dictionary where the outer keys are job IDs,
            the inner keys are stage IDs, and the values are processing times as builtin integers.
        """
        raw_dict = self.p_manager.job_2_stage_2_value_map(
            self.job_id_list, self.stage_id_list
        )
        return {
            job: {stage: int(p) for stage, p in stage_map.items()}
            for job, stage_map in raw_dict.items()
        }
