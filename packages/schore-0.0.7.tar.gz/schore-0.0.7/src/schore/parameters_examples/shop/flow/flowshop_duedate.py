from __future__ import annotations

from typing import TextIO

from schore.parameters import JobStageProcessingTimeManager
from schore.util import TextDataParser

from .flowshop import FlowshopParameters


class FlowshopDuedateParameters(FlowshopParameters):
    _job_2_duedate_map: dict[str, int]
    """Mapping from job ID to due date."""

    def __init__(
        self,
        name: str,
        job_id_list: list[str],
        stage_id_list: list[str],
        p_manager: JobStageProcessingTimeManager[int],
        job_2_duedate_map: dict[str, int],
    ) -> None:
        super().__init__(name, job_id_list, stage_id_list, p_manager)
        self._job_2_duedate_map = job_2_duedate_map

    @property
    def job_2_duedate_map(self) -> dict[str, int]:
        """Get mapping from job ID to due date."""
        return self._job_2_duedate_map.copy()

    @classmethod
    def from_vrm_data(cls, name: str, stream: TextIO) -> FlowshopDuedateParameters:
        """Create FlowshopParameters from VRM benchmark instance data.

        Args:
            name (str): Name of the instance.
            stream (TextIO): A file-like object containing VRM formatted data.

        Returns:
            FlowshopDuedateParameters: An instance of FlowshopDuedateParameters.
        """
        job_count = TextDataParser.strip_a_typed_value(stream, int)
        stage_count = TextDataParser.strip_a_typed_value(stream, int)

        duedate_list: list[int] = TextDataParser.strip_a_typed_list(stream, int)
        cls._validate_duedate_list(job_count, duedate_list)

        processing_times = JobStageProcessingTimeManager.from_text_stream(
            stream, job_count, dtype=int
        )
        cls._validate_processing_times(job_count, stage_count, processing_times)

        # Generate a list of job IDs with zero-padded numbers.
        num_digits = len(str(job_count - 1))
        job_id_list = [f"j{str(j).zfill(num_digits)}" for j in range(job_count)]

        # Generate a list of stage IDs with zero-padded numbers.
        num_digits = len(str(stage_count - 1))
        stage_id_list = [f"i{str(s).zfill(num_digits)}" for s in range(stage_count)]
        job_2_duedate_map = {
            job_id: duedate for job_id, duedate in zip(job_id_list, duedate_list)
        }

        return cls(
            name, job_id_list, stage_id_list, processing_times, job_2_duedate_map
        )

    @staticmethod
    def _validate_duedate_list(job_count: int, duedate_list: list[int]):
        if len(duedate_list) != job_count:
            raise ValueError(
                f"Due date list length {len(duedate_list)} does not match job count {job_count}."
            )
        if any(d < 0 for d in duedate_list):
            raise ValueError("Due dates must be non-negative.")

    def get_subinstance(
        self,
        job_id_list: list[str] | None = None,
        stage_id_list: list[str] | None = None,
    ) -> FlowshopDuedateParameters:
        """Get a subinstance of the flowshop parameters.

        Args:
            job_id_list (list[str] | None): List of job IDs to include in the subinstance.
                If None, all jobs are included.
            stage_id_list (list[str] | None): List of stage IDs to include in the subinstance.
                If None, all stages are included.

        Returns:
            FlowshopDuedateParameters: A new FlowshopDuedateParameters instance representing the subinstance.
        """
        if job_id_list is None:
            job_id_list = self._job_id_list
        if stage_id_list is None:
            stage_id_list = self._stage_id_list

        super_ins = super().get_subinstance(job_id_list, stage_id_list)
        sub_job_2_duedate_map = {
            job_id: self._job_2_duedate_map[job_id] for job_id in job_id_list
        }

        return FlowshopDuedateParameters(
            name=super_ins.name,
            job_id_list=job_id_list.copy(),
            stage_id_list=stage_id_list.copy(),
            p_manager=super_ins.p_manager,
            job_2_duedate_map=sub_job_2_duedate_map,
        )
