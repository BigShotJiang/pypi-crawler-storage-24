from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import matplotlib.pyplot as plt

from .schedule.abstract import Activity, Resource, ResourceGroup


@dataclass(frozen=True)
class LaneId:
    """Identifier of a Gantt lane (group name, resource name)."""

    group: str
    resource: str

    def label(self) -> str:
        return f"{self.group}:{self.resource}"


class GanttPlotter:
    """
    General-purpose Gantt plotter that renders schedules organized as
    Activity -> Resource -> ResourceGroup hierarchy.

    Expected interfaces (duck-typed):
      - Activity: `.name: str`, `.start: int`, `.end: int`
      - Resource: `.name: str`, `.activity_list: list[Activity]`, `.makespan: int`
      - ResourceGroup: `.name: str`, `.resources: list[Resource]`, `.makespan: int`

    Example usage
    -------------
    >>> plotter = GeneralGanttPlotter(show_group_header=True, show_labels=True)
    >>> fig, ax = plotter.plot(groups=[machine_group, worker_group], return_fig=True)
    >>> fig.savefig("schedule.png", dpi=150)
    """

    def __init__(
        self,
        *,
        bar_height: float = 0.8,
        group_gap: float = 0.6,
        lane_padding: float = 0.05,
        show_group_header: bool = True,
        show_labels: bool = True,
        legend: bool = True,
        time_label: str = "Time",
        color_mode: str = "group",  # one of {"group", "resource", "activity"}
        cmap_name: str = "tab20",
        min_fig_height: float = 4.0,
        fig_width_per_100t: float = 1.2,  # width scaling by horizon
    ) -> None:
        self.bar_height = bar_height
        self.group_gap = group_gap
        self.lane_padding = lane_padding
        self.show_group_header = show_group_header
        self.show_labels = show_labels
        self.legend = legend
        self.time_label = time_label
        self.color_mode = color_mode
        self.cmap_name = cmap_name
        self.min_fig_height = min_fig_height
        self.fig_width_per_100t = fig_width_per_100t

    # ------------------------------- public API ---------------------------------

    def plot(
        self,
        groups: Sequence[ResourceGroup],
        *,
        resource_order: Optional[Iterable[Tuple[str, str]]] = None,
        xlim: Optional[Tuple[float, float]] = None,
        return_fig: bool = False,
    ):
        """
        Render a Gantt chart.

        Args:
            groups: Sequence of ResourceGroup objects.
            resource_order: Optional explicit order of lanes as iterable of
                            (group_name, resource_name). If omitted, the
                            order follows the group order and then resource order as given.
            xlim: Optional (xmin, xmax) for time axis. If None, inferred from data.
            return_fig: If True, returns (fig, ax).
        """
        lanes, y_of_lane, groups_dict = self._build_layout(groups, resource_order)
        horizon = self._infer_horizon(groups)

        # Figure size heuristics
        lane_count = len(lanes)
        fig_h = max(self.min_fig_height, lane_count * 0.4)
        fig_w = max(6.0, (horizon / 100.0) * self.fig_width_per_100t)
        fig, ax = plt.subplots(figsize=(fig_w, fig_h))

        # Colors
        cmap = plt.get_cmap(self.cmap_name)
        color_key_vals = self._collect_color_keys(groups, self.color_mode)
        color_map: Dict[str, tuple] = {
            key: cmap(i / max(1, len(color_key_vals)))
            for i, key in enumerate(sorted(color_key_vals))
        }

        # Draw bars
        for g in groups:
            for r in g.resources:
                lane_id = LaneId(g.name, r.name)
                y_center = y_of_lane[lane_id]
                for act in r.activity_list:
                    width = act.end - act.start
                    if width <= 0:
                        # Defensive: skip zero/negative; Activity.duration already guards normally
                        continue
                    color_key = self._color_key(self.color_mode, g, r, act)
                    rects = ax.barh(
                        y=y_center,
                        width=width,
                        left=act.start,
                        height=self.bar_height * (1.0 - self.lane_padding),
                        align="center",
                        edgecolor="black",
                        color=color_map.get(color_key, "C0"),
                    )
                    if self.show_labels:
                        ax.text(
                            act.start + width / 2.0,
                            y_center,
                            str(act.name),
                            ha="center",
                            va="center",
                            fontsize=9,
                        )

        # Y ticks and labels
        ax.set_yticks([y_of_lane[ln] for ln in lanes])
        ax.set_yticklabels([ln.label() for ln in lanes])
        ax.invert_yaxis()  # top lane first

        # Group headers and separators
        if self.show_group_header:
            for gname, rlist in groups_dict.items():
                if not rlist:
                    continue
                top = y_of_lane[LaneId(gname, rlist[0].name)] - (self.bar_height / 2.0)
                bottom = y_of_lane[LaneId(gname, rlist[-1].name)] + (
                    self.bar_height / 2.0
                )
                ax.axhline(top - self.group_gap * 0.5, lw=0.8, color="gray", alpha=0.8)
                ax.text(
                    xlim[0] if xlim else ax.get_xlim()[0],
                    (top + bottom) / 2.0,
                    gname,
                    ha="left",
                    va="center",
                    fontsize=10,
                    fontweight="bold",
                )

        # Grid, labels, limits
        ax.grid(axis="x", linestyle="--", alpha=0.3)
        ax.set_xlabel(self.time_label)
        ylim = (
            min(y_of_lane.values()) - self.bar_height,
            max(y_of_lane.values()) + self.bar_height + self.group_gap,
        )
        ax.set_ylim(*ylim)

        # X limits
        if xlim is None:
            ax.set_xlim(0, max(1, horizon))
        else:
            ax.set_xlim(*xlim)

        # Legend
        if self.legend:
            from matplotlib.patches import Patch

            handles = [
                Patch(
                    facecolor=color_map[k],
                    edgecolor="black",
                    label=self._legend_label(k),
                )
                for k in sorted(color_key_vals)
            ]
            ax.legend(
                handles=handles, title=self._legend_title(), ncol=min(4, len(handles))
            )

        fig.tight_layout()
        return (fig, ax) if return_fig else None

    # ------------------------------- internals ----------------------------------

    def _build_layout(
        self,
        groups: Sequence[ResourceGroup],
        resource_order: Optional[Iterable[Tuple[str, str]]],
    ) -> Tuple[List[LaneId], Dict[LaneId, float], Dict[str, List[Resource]]]:
        # Preserve incoming order by default
        lanes: List[LaneId] = []
        groups_dict: Dict[str, List[Resource]] = {}
        for g in groups:
            groups_dict[g.name] = list(g.resources)
            for r in g.resources:
                lanes.append(LaneId(g.name, r.name))

        if resource_order:
            order_map = {LaneId(g, r): i for i, (g, r) in enumerate(resource_order)}
            lanes.sort(key=lambda ln: order_map.get(ln, len(order_map)))

        # Assign y centers: pack by groups with a gap between groups
        y_of_lane: Dict[LaneId, float] = {}
        y = 0.0
        last_group: Optional[str] = None
        for ln in lanes:
            if last_group is not None and ln.group != last_group:
                y += self.group_gap
            y_of_lane[ln] = y + self.bar_height / 2.0
            y += self.bar_height
            last_group = ln.group

        if not lanes:
            # Ensure stable axes when no data
            y_of_lane[LaneId("_", "_")] = self.bar_height / 2.0

        return lanes, y_of_lane, groups_dict

    def _infer_horizon(self, groups: Sequence[ResourceGroup]) -> int:
        return max((g.makespan for g in groups), default=1)

    def _collect_color_keys(
        self, groups: Sequence[ResourceGroup], mode: str
    ) -> List[str]:
        keys: List[str] = []
        if mode == "group":
            keys = [g.name for g in groups]
        elif mode == "resource":
            for g in groups:
                keys.extend([f"{g.name}:{r.name}" for r in g.resources])
        elif mode == "activity":
            seen = set()
            for g in groups:
                for r in g.resources:
                    for a in r.activity_list:
                        if a.name not in seen:
                            seen.add(a.name)
                            keys.append(a.name)
        else:
            keys = [g.name for g in groups]
        return keys or ["_default_"]

    def _color_key(self, mode: str, g: ResourceGroup, r: Resource, a: Activity) -> str:
        if mode == "group":
            return g.name
        if mode == "resource":
            return f"{g.name}:{r.name}"
        if mode == "activity":
            return str(a.name)
        return g.name

    def _legend_title(self) -> str:
        return {
            "group": "Groups",
            "resource": "Resources",
            "activity": "Activities",
        }.get(self.color_mode, "Groups")

    def _legend_label(self, key: str) -> str:
        return key
