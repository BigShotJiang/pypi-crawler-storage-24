from __future__ import annotations

from typing import Generic, Self, TextIO, Type

import pandas as pd

from ...data import Table2DManager
from ...type_aliases import numeric_types
from ...type_defs import NumericT, ScalarT


class JobMachineProcessingTimeManager(Table2DManager, Generic[NumericT]):
    """rows for jobs, columns for machines"""

    def __init__(self, name: str, df: pd.DataFrame) -> None:
        super().__init__(name, df)
        self._on_df_updated()

    def _on_df_updated(self) -> None:
        super()._on_df_updated()
        self._values_cache = self.df.to_numpy()
        self._machine_2_job_2_value_map_cache: dict[
            tuple[tuple[str, ...], tuple[str, ...]], dict[str, dict[str, NumericT]]
        ] = {}
        self._machine_job_2_value_map_cache: dict[
            tuple[tuple[str, ...], tuple[str, ...]], dict[tuple[str, str], NumericT]
        ] = {}
        self._job_2_eligible_mc_list_map_cache: dict[
            tuple[tuple[str, ...], tuple[str, ...]], dict[str, list[str]]
        ] = {}

    def _validate_dimensions(
        self, mc_id_tuple: tuple[str, ...], job_id_tuple: tuple[str, ...]
    ) -> None:
        if len(mc_id_tuple) != self.col_count():
            raise ValueError("machine count mismatch")
        if len(job_id_tuple) != self.row_count():
            raise ValueError("job count mismatch")

    @classmethod
    def from_text_stream(
        cls,
        stream: TextIO,
        row_count: int,
        dtype: Type[ScalarT] | None = None,
        sep: str | None = None,
        name: str = "JobMachineProcessingTimeManager",
        transpose: bool = False,
    ) -> Self:
        if dtype is not None:
            if not isinstance(dtype, type):  # Ensure dtype is a type
                raise TypeError(f"Expected dtype to be a type, got {dtype}")
            if dtype is bool:
                raise TypeError("Boolean dtype is not supported for processing times.")
            if dtype not in numeric_types:
                raise TypeError(f"Expected dtype to be a numeric type, got '{dtype}'")
        return super().from_text_stream(
            stream, row_count, dtype, sep, name, transpose=transpose
        )

    def machine_2_job_2_value_map(
        self, mc_id_list: list[str], job_id_list: list[str]
    ) -> dict[str, dict[str, NumericT]]:
        """
        Cached version: If called with same arguments, return cached result.

        Args:
            mc_id_list (list[str]): List of machine IDs (columns).
            job_id_list (list[str]): List of job IDs (rows).

        Returns:
            dict[str, dict[str, Numeric]]: Machine ID -> Job ID -> Value.
        """
        mc_id_tuple = tuple(mc_id_list)
        job_id_tuple = tuple(job_id_list)
        self._validate_dimensions(mc_id_tuple, job_id_tuple)
        cache_key = (mc_id_tuple, job_id_tuple)
        if cache_key not in self._machine_2_job_2_value_map_cache:
            self._machine_2_job_2_value_map_cache[cache_key] = {
                mc_id: {
                    job_id: self._values_cache[row_idx, col_idx]
                    for row_idx, job_id in enumerate(job_id_tuple)
                }
                for col_idx, mc_id in enumerate(mc_id_tuple)
            }
        return self._machine_2_job_2_value_map_cache[cache_key]

    def machine_job_2_value_map(
        self, mc_id_list: list[str], job_id_list: list[str]
    ) -> dict[tuple[str, str], NumericT]:
        """
        Cached version: If called with same arguments, return cached result.

        Args:
            mc_id_list (list[str]): List of machine IDs (columns).
            job_id_list (list[str]): List of job IDs (rows).

        Returns:
            dict[tuple[str, str], Numeric]: (Machine ID, Job ID) -> Value.
        """
        mc_id_tuple = tuple(mc_id_list)
        job_id_tuple = tuple(job_id_list)
        self._validate_dimensions(mc_id_tuple, job_id_tuple)
        cache_key = (mc_id_tuple, job_id_tuple)
        if cache_key not in self._machine_job_2_value_map_cache:
            self._machine_job_2_value_map_cache[cache_key] = {
                (mc_id, job_id): self._values_cache[row_idx, col_idx]
                for row_idx, job_id in enumerate(job_id_tuple)
                for col_idx, mc_id in enumerate(mc_id_tuple)
            }
        return self._machine_job_2_value_map_cache[cache_key]

    def job_2_eligible_mc_list_map(
        self, job_id_list: list[str], mc_id_list: list[str]
    ) -> dict[str, list[str]]:
        """
        Cached version: If called with same arguments, return cached result.

        Args:
            job_id_list (list[str]): List of job IDs (rows).
            mc_id_list (list[str]): List of machine IDs (columns).

        Returns:
            dict[str, list[str]]: Job ID -> List of eligible machine IDs.
        """
        job_id_tuple = tuple(job_id_list)
        mc_id_tuple = tuple(mc_id_list)
        self._validate_dimensions(mc_id_tuple, job_id_tuple)
        cache_key = (job_id_tuple, mc_id_tuple)
        if cache_key not in self._job_2_eligible_mc_list_map_cache:
            self._job_2_eligible_mc_list_map_cache[cache_key] = {
                job_id: [
                    mc_id
                    for col_idx, mc_id in enumerate(mc_id_tuple)
                    if self._values_cache[row_idx, col_idx] > 0
                ]
                for row_idx, job_id in enumerate(job_id_tuple)
            }
        return self._job_2_eligible_mc_list_map_cache[cache_key]

    def filter_by_job_indices(
        self, job_index_list: list[int]
    ) -> JobMachineProcessingTimeManager:
        """
        Filter the DataFrame by job indices.

        Args:
            job_index_list (list[int]): List of job indices to filter.

        Returns:
            JobMachineProcessingTimeManager: New instance with filtered data.
        """
        filtered_df = self.df.iloc[job_index_list, :]
        return JobMachineProcessingTimeManager(name=self.name, df=filtered_df)
