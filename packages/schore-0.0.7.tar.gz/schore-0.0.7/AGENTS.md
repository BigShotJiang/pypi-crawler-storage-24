# AGENTS.md

This file provides guidance to AI coding agents (including Claude Code) when working with code in this repository.

## Dev environment

- **Install dependencies**: `uv sync`
- **Run tests**: `uv run pytest tests/`
- **Test single file**: `uv run pytest tests/manager/test_job_stage_processing_time_manager.py`

## Coding conventions

- **Python version**: >=3.11
- **Package manager**: [uv](https://github.com/astral-sh/uv)
- **Testing framework**: pytest
- **Type hints**: Use `from __future__ import annotations` for forward references
- **Imports**: Absolute imports from `schore.` package root

## Architecture

### Core Design Pattern: Abstract Base Classes

The library uses ABCs to define interfaces for scheduling problems:

```plaintext
Activity (ABC) → Resource (ABC) → ResourceGroup (ABC) → ParallelResourceGroup (ABC)
```

- **Activity**: `name` (str), `start` (int), `end` (int) properties; `duration` computed
- **Resource**: Manages activities; handles conflict detection, earliest start time
- **ResourceGroup**: Container for resources; exposes `.makespan`
- **ParallelResourceGroup**: Finds earliest available machine in parallel group

### Data Management Layer

- **DfManager**: Wraps pandas DataFrame; `_on_df_updated()` hook for cache invalidation
- **Table2DManager**: 2D tables with cached column-to-value mappings using `@cached_property`

### Parameter Management Layer

- **JobStageProcessingTimeManager**: Jobs as rows, stages as columns (flowshop)
- **JobMachineProcessingTimeManager**: Jobs as rows, machines as columns (machine assignment)

Both provide cached mapping methods like `job_2_stage_2_value_map()` for efficient access.

### Example Implementations

- **Flowshop**: Single machine per stage, jobs visit all stages in order
- **HybridFlowshop**: Multiple parallel machines per stage (see `HybridFlowshopSchedule`)
- **FlowshopDuedate**: Flowshop with due dates for tardiness calculations

### Gantt Chart Visualization

**GanttPlotter** expects duck-typed objects:

- `Activity`: `.name`, `.start`, `.end`
- `Resource`: `.name`, `.activity_list`, `.makespan`
- `ResourceGroup`: `.name`, `.resources`, `.makespan`

Color modes: `"group"`, `"resource"`, `"activity"`.

## Key concepts

- **Makespan**: Maximum completion time across all resources
- **Release time (release_t)**: Earliest time an operation can start
- **Force add**: Skip conflict checking (use sparingly, debug only)
- **Operation**: Synonymous with Activity in shop scheduling

## PR instructions

- Run tests before committing
- Ensure type hints are complete for new classes
- Add docstrings for public API methods
