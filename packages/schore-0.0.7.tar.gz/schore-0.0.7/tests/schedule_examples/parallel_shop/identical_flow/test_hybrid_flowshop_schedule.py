import pytest

from schore.schedule.exception import SchedulingFailureException
from schore.schedule_examples.parallel_shop.identical_flow.hybrid_flowshop_operation import (
    HybridFlowshopOperation,
)
from schore.schedule_examples.parallel_shop.identical_flow.hybrid_flowshop_schedule import (
    HybridFlowshopSchedule,
)


def test_from_stage_name_map_and_getters() -> None:
    schedule = HybridFlowshopSchedule.from_stage_name_2_mc_name_list_map(
        {
            "s1": ["m1", "m2"],
            "s2": ["m3"],
        }
    )

    assert schedule.get_stage_by_name("s1").name == "s1"
    assert [mc.name for mc in schedule.get_stage_by_name("s1").resources] == [
        "m1",
        "m2",
    ]

    with pytest.raises(ValueError, match="Stage unknown not found in schedule"):
        schedule.get_stage_by_name("unknown")


def test_schedule_operation_conflict_and_force_add() -> None:
    schedule = HybridFlowshopSchedule.from_stage_name_2_mc_name_list_map({"s1": ["m1"]})

    op1 = HybridFlowshopOperation("j1", "s1", "m1", start=0, end=5)
    op2 = HybridFlowshopOperation("j2", "s1", "m1", start=3, end=7)

    assert schedule.schedule_operation(op1) == op1
    assert schedule.schedule_operation(op2) is None
    assert schedule.schedule_operation(op2, force_add=True) == op2


def test_makespan_uses_last_stage_name_when_set() -> None:
    schedule = HybridFlowshopSchedule.from_stage_name_2_mc_name_list_map(
        {
            "s1": ["m1"],
            "s2": ["m2"],
        }
    )

    op1 = schedule.dispatch_operation_earliest("j1", "s1", p=3)
    op2 = schedule.dispatch_operation_earliest("j1", "s2", p=4)

    assert op1.start == 0 and op1.end == 3
    assert op2.start == 3 and op2.end == 7
    assert schedule.makespan == 7

    schedule.set_last_stage_name("s1")
    assert schedule.makespan == 3


def test_dispatch_operation_earliest_respects_prev_stage_and_release_time() -> None:
    schedule = HybridFlowshopSchedule.from_stage_name_2_mc_name_list_map(
        {
            "s1": ["m1"],
            "s2": ["m2"],
        }
    )

    schedule.dispatch_operation_earliest("j1", "s1", p=5)

    op = schedule.dispatch_operation_earliest("j1", "s2", p=2, release_t=1)

    assert op.start == 5
    assert op.end == 7
    assert schedule.job_2_last_oper_end_time_map["j1"] == 7


def test_dispatch_operation_earliest_raises_on_stage_add_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    schedule = HybridFlowshopSchedule.from_stage_name_2_mc_name_list_map({"s1": ["m1"]})
    stage = schedule.get_stage_by_name("s1")

    monkeypatch.setattr(stage, "add_operation", lambda _op: None)

    with pytest.raises(SchedulingFailureException, match="Failed to schedule j1.s1"):
        schedule.dispatch_operation_earliest("j1", "s1", p=2)


def test_dispatch_job_by_stages_chains_release_times() -> None:
    schedule = HybridFlowshopSchedule.from_stage_name_2_mc_name_list_map(
        {
            "s1": ["m1"],
            "s2": ["m2"],
        }
    )

    operations = schedule.dispatch_job_by_stages(
        job_name="j1",
        stage_name_list=["s1", "s2"],
        stage_name_2_p_map={"s1": 4, "s2": 3},
        release_t=2,
    )

    assert [(op.stage_name, op.start, op.end) for op in operations] == [
        ("s1", 2, 6),
        ("s2", 6, 9),
    ]


def test_dispatch_stage_by_jobs_priority_by_last_end_and_input_order() -> None:
    schedule = HybridFlowshopSchedule.from_stage_name_2_mc_name_list_map({"s1": ["m1"]})

    schedule.job_2_last_oper_end_time_map["j2"] = 1
    schedule.job_2_last_oper_end_time_map["j1"] = 1
    schedule.job_2_last_oper_end_time_map["j3"] = 0

    operations = schedule.dispatch_stage_by_jobs(
        stage_name="s1",
        job_name_list=["j1", "j2", "j3"],
        job_name_2_p_map={"j1": 1, "j2": 1, "j3": 1},
    )

    assert [op.job_name for op in operations] == ["j3", "j1", "j2"]


def test_dispatch_stage_by_jobs_prioritizes_prev_stage_end_time() -> None:
    schedule = HybridFlowshopSchedule.from_stage_name_2_mc_name_list_map(
        {"s0": ["m0"], "s1": ["m1"]}
    )

    # Stage s0 sets readiness: a ends at 1, b ends at 2.
    schedule.dispatch_operation_earliest("a", "s0", p=1, release_t=0)
    schedule.dispatch_operation_earliest("b", "s0", p=1, release_t=1)

    # Pre-fill s1 machine timeline to create a critical early gap [0, 8).
    schedule.schedule_operation(
        HybridFlowshopOperation(
            job_name="x1", stage_name="s1", mc_name="m1", start=8, end=10
        )
    )
    schedule.schedule_operation(
        HybridFlowshopOperation(
            job_name="x2", stage_name="s1", mc_name="m1", start=17, end=20
        )
    )

    # If 'b' were dispatched first, it would take [2, 7) and block
    # 'a' from fitting into [1, 8).
    operations = schedule.dispatch_stage_by_jobs(
        "s1",
        job_name_list=["b", "a"],
        job_name_2_p_map={"a": 7, "b": 5},
        release_t=0,
    )

    start_map = schedule.get_start_time_map()

    assert start_map[("a", "s1", "m1")] == 1
    assert start_map[("b", "s1", "m1")] == 10
    assert [op.job_name for op in operations] == ["a", "b"]


def test_remove_operation_from_machine_recomputes_job_last_end_time() -> None:
    schedule = HybridFlowshopSchedule.from_stage_name_2_mc_name_list_map(
        {
            "s1": ["m1"],
            "s2": ["m2"],
        }
    )

    schedule.dispatch_operation_earliest("j1", "s1", p=2)
    schedule.dispatch_operation_earliest("j1", "s2", p=3)
    assert schedule.job_2_last_oper_end_time_map["j1"] == 5

    assert schedule.remove_operation_from_machine_by_job_name("s2", "m2", "j1")
    assert schedule.job_2_last_oper_end_time_map["j1"] == 2

    assert schedule.remove_operation_from_machine_by_job_name("s1", "m1", "j1")
    assert schedule.job_2_last_oper_end_time_map["j1"] == 0


def test_remove_operations_by_list_recomputes_each_removed_job() -> None:
    schedule = HybridFlowshopSchedule.from_stage_name_2_mc_name_list_map({"s1": ["m1"]})

    schedule.dispatch_operation_earliest("j1", "s1", p=2)
    schedule.dispatch_operation_earliest("j2", "s1", p=4)
    assert schedule.job_2_last_oper_end_time_map["j1"] == 2
    assert schedule.job_2_last_oper_end_time_map["j2"] == 6

    removed = schedule.remove_operations_by_list_of_job_stage_mc_names(
        [("j1", "s1", "m1"), ("j2", "s1", "m1")]
    )

    assert removed is True
    assert schedule.job_2_last_oper_end_time_map["j1"] == 0
    assert schedule.job_2_last_oper_end_time_map["j2"] == 0


def test_get_start_and_end_time_map() -> None:
    schedule = HybridFlowshopSchedule.from_stage_name_2_mc_name_list_map(
        {
            "s1": ["m1"],
            "s2": ["m2"],
        }
    )

    schedule.dispatch_operation_earliest("j1", "s1", p=2)
    schedule.dispatch_operation_earliest("j1", "s2", p=3)

    assert schedule.get_start_time_map() == {
        ("j1", "s1", "m1"): 0,
        ("j1", "s2", "m2"): 2,
    }
    assert schedule.get_end_time_map() == {
        ("j1", "s1", "m1"): 2,
        ("j1", "s2", "m2"): 5,
    }
