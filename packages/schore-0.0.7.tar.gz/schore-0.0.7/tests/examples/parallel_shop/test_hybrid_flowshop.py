import io

import pytest

from schore.parameters_examples.parallel_shop.identical_flow import (
    HybridFlowshopParameters,
    create_instance_of_aggregated_stages,
    create_instance_of_job_subset,
    create_instance_of_stage_subset,
    reverse_stages,
)


@pytest.fixture
def pra_data_stream():
    """Fixture to provide a sample PRA data stream."""
    data = """\
6
3
2 3 2
2 3 4
6 4 8
9 1 5
4 6 3
1 5 10
4 8 12
"""
    return io.StringIO(data)


@pytest.fixture
def params(pra_data_stream) -> HybridFlowshopParameters:
    """Fixture to parse the PRA data into a HybridFlowshopParameters."""
    return HybridFlowshopParameters.from_pra_data("from_pra_data", pra_data_stream)


def test_params_structure(params: HybridFlowshopParameters):
    """Test the overall structure of the parsed params."""
    assert params.job_count == 6
    assert params.stage_count == 3
    assert params.machine_count_per_stage == [2, 3, 2]
    assert params.job_id_list == ["j0", "j1", "j2", "j3", "j4", "j5"]
    assert params.stage_id_list == ["i0", "i1", "i2"]
    assert params.stage_2_machines_map == {
        "i0": ["i0_0", "i0_1"],
        "i1": ["i1_0", "i1_1", "i1_2"],
        "i2": ["i2_0", "i2_1"],
    }


def test_create_instance_of_job_subset(params: HybridFlowshopParameters):
    """Test the creation of a new instance based on a subset of jobs."""
    job_subset = ["j0", "j2", "j4"]
    subset_params = create_instance_of_job_subset(params, job_subset)

    assert subset_params.job_count == len(job_subset)
    assert subset_params.stage_count == params.stage_count
    assert subset_params.machine_count_per_stage == params.machine_count_per_stage
    assert subset_params.job_id_list == job_subset

    expected_processing_times = [
        params.p_manager.df.iloc[0].tolist(),
        params.p_manager.df.iloc[2].tolist(),
        params.p_manager.df.iloc[4].tolist(),
    ]
    actual_processing_times = subset_params.p_manager.df.values.tolist()
    assert actual_processing_times == expected_processing_times

    assert subset_params.stage_2_machines_map == params.stage_2_machines_map


def test_create_instance_of_job_subset_invalid_job_id(params: HybridFlowshopParameters):
    """Test that create_instance_of_job_subset raises ValueError for invalid job IDs."""
    with pytest.raises(ValueError, match="Job subset contains invalid job IDs"):
        create_instance_of_job_subset(params, ["j0", "invalid"])


def test_create_instance_of_job_subset_duplicate_job_id(
    params: HybridFlowshopParameters,
):
    """Test that create_instance_of_job_subset raises ValueError for duplicate job IDs."""
    with pytest.raises(ValueError, match="Job subset contains duplicate job IDs"):
        create_instance_of_job_subset(params, ["j0", "j1", "j0"])


def test_create_instance_of_stage_subset(params: HybridFlowshopParameters):
    """Test the creation of a new instance based on a subset of stages."""
    stage_subset = ["i0", "i2"]
    subset_params = create_instance_of_stage_subset(params, stage_subset)

    assert subset_params.stage_count == len(stage_subset)
    assert subset_params.job_count == params.job_count
    # machine_count_per_stage should match the subset (i0=2, i2=2, skipping i1=3)
    assert subset_params.machine_count_per_stage == [2, 2]
    assert subset_params.stage_id_list == stage_subset

    expected_processing_times = [
        [params.p_manager.df.iloc[row, 0], params.p_manager.df.iloc[row, 2]]
        for row in range(params.job_count)
    ]
    actual_processing_times = subset_params.p_manager.df.values.tolist()
    assert actual_processing_times == expected_processing_times

    expected_stage_2_machines = {
        stage_id: params.stage_2_machines_map[stage_id] for stage_id in stage_subset
    }
    assert subset_params.stage_2_machines_map == expected_stage_2_machines


def test_create_instance_of_stage_subset_invalid_stage_id(
    params: HybridFlowshopParameters,
):
    """Test that create_instance_of_stage_subset raises ValueError for invalid stage IDs."""
    with pytest.raises(ValueError, match="Stage subset contains invalid stage IDs"):
        create_instance_of_stage_subset(params, ["i0", "invalid"])


def test_create_instance_of_stage_subset_duplicate_stage_id(
    params: HybridFlowshopParameters,
):
    """Test that create_instance_of_stage_subset raises ValueError for duplicate stage IDs."""
    with pytest.raises(ValueError, match="Stage subset contains duplicate stage IDs"):
        create_instance_of_stage_subset(params, ["i0", "i1", "i0"])


def test_create_instance_of_reversed_stages(params: HybridFlowshopParameters):
    """Test stage reversal for stage order, machine map, and processing time table."""
    reversed_params = reverse_stages(params)

    assert reversed_params.name == params.name + "_reversed"
    assert reversed_params.job_id_list == params.job_id_list
    assert reversed_params.stage_id_list == params.stage_id_list[::-1]

    expected_stage_2_machines = {
        stage_id: params.stage_2_machines_map[stage_id]
        for stage_id in params.stage_id_list[::-1]
    }
    assert reversed_params.stage_2_machines_map == expected_stage_2_machines
    assert reversed_params.p_manager.df.values.tolist() == [
        row[::-1] for row in params.p_manager.df.values.tolist()
    ]

    # Original instance should remain unchanged.
    assert params.stage_id_list == ["i0", "i1", "i2"]
    assert params.p_manager.df.values.tolist() == [
        [2, 3, 4],
        [6, 4, 8],
        [9, 1, 5],
        [4, 6, 3],
        [1, 5, 10],
        [4, 8, 12],
    ]


def test_invalid_job_count():
    """
    Test that from_pra_data raises EOFError for mismatched job count.
    If the number of jobs in the data is less than the specified job count,
    it should raise a EOFError indicating the mismatch.
    If the number of jobs in the data is more than the specified job count,
    it will truncate the data to match the specified job count.
    """
    bad_data = """\
5
3
2 3 2
2 3 4
6 4 8
9 1 5
"""
    with pytest.raises(
        EOFError,
        match="Unexpected end of file while reading 4-th row"
        " among 5 rows of list of type int.",
    ):
        HybridFlowshopParameters.from_pra_data("from_pra_data", io.StringIO(bad_data))


def test_invalid_stage_count():
    """Test that from_pra_data raises ValueError for mismatched stage count."""
    bad_data = """\
6
4
2 3 2
2 3 4
6 4 8
9 1 5
4 6 3
1 5 10
4 8 12
"""
    with pytest.raises(
        ValueError,
        match="Stage count mismatch; stage_count=4; by machine_count_per_stage=3",
    ):
        HybridFlowshopParameters.from_pra_data("from_pra_data", io.StringIO(bad_data))


def test_empty_input():
    """Test that from_pra_data raises EOFError for empty input."""
    data = ""
    with pytest.raises(EOFError, match="Unexpected end of file while reading data."):
        HybridFlowshopParameters.from_pra_data("from_pra_data", io.StringIO(data))


def test_null_processing_time():
    """Test that from_pra_data raises ValueError for null processing time."""
    bad_data = """\
6
3
2 3 2
2 3 4
6 4 8
9 1
4 6 3
1 5 10
4 8 12
"""
    with pytest.raises(
        ValueError, match="Null value exists in the processing time data"
    ):
        HybridFlowshopParameters.from_pra_data("from_pra_data", io.StringIO(bad_data))


def test_from_ff2020_data_valid_input():
    """Test that from_ff2020_data parses valid FF2020 format correctly."""
    data = """\
4 3
2 1 2
10 20 30 40
11 21 31 41
12 22 32 42
"""
    params = HybridFlowshopParameters.from_ff2020_data(
        "from_ff2020_data", io.StringIO(data)
    )

    assert params.job_count == 4
    assert params.stage_count == 3
    assert params.machine_count_per_stage == [2, 1, 2]
    assert params.job_id_list == ["j0", "j1", "j2", "j3"]
    assert params.stage_id_list == ["i0", "i1", "i2"]
    assert params.stage_2_machines_map == {
        "i0": ["i0_0", "i0_1"],
        "i1": ["i1_0"],
        "i2": ["i2_0", "i2_1"],
    }
    assert params.p_manager.df.values.tolist() == [
        [10, 11, 12],
        [20, 21, 22],
        [30, 31, 32],
        [40, 41, 42],
    ]


def test_from_ff2020_data_invalid_header_length():
    """Test that from_ff2020_data raises ValueError for invalid header length."""
    bad_data = """\
4 3 99
2 1 2
10 20 30 40
11 21 31 41
12 22 32 42
"""
    with pytest.raises(
        ValueError,
        match="Expected exactly 2 integers for job and stage counts in header",
    ):
        HybridFlowshopParameters.from_ff2020_data(
            "from_ff2020_data", io.StringIO(bad_data)
        )


def test_from_ff2020_data_invalid_header_format():
    """Test that from_ff2020_data raises ValueError for non-integer header values."""
    bad_data = """\
4 x
2 1 2
10 20 30 40
11 21 31 41
12 22 32 42
"""
    with pytest.raises(ValueError, match=r"invalid literal for int\(\)"):
        HybridFlowshopParameters.from_ff2020_data(
            "from_ff2020_data", io.StringIO(bad_data)
        )


def test_from_ff2020_data_processing_time_shape_mismatch():
    """Test that from_ff2020_data validates transposed processing-time shape."""
    bad_data = """\
4 3
2 1 2
10 20
11 21
12 22
"""
    with pytest.raises(ValueError, match="Job count mismatch; expected 4, got 2"):
        HybridFlowshopParameters.from_ff2020_data(
            "from_ff2020_data", io.StringIO(bad_data)
        )


@pytest.fixture
def five_stage_params():
    """Fixture to provide a 5-stage hybrid flowshop instance."""
    data = """\
6
5
2 3 2 1 2
2 3 4 5 6
6 4 8 1 2
9 1 5 3 4
4 6 3 2 1
1 5 10 4 3
4 8 12 5 2
"""
    stream = io.StringIO(data)
    return HybridFlowshopParameters.from_pra_data("five_stage", stream)


def test_create_instance_of_aggregated_stages_basic(five_stage_params):
    """Test basic stage aggregation with stage_agg_count=2, head_stages_to_keep=0."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params, 2, p_agg_method="sum", mi_agg_method="min"
    )

    # 5 stages with agg_count=2 -> 3 aggregated stages (s0+s1, s2+s3, s4)
    assert agg_params.stage_count == 3
    assert agg_params.stage_id_list == ["sa0", "sa1", "sa2"]
    assert agg_params.job_count == 6


def test_create_instance_of_aggregated_stages_with_head(five_stage_params):
    """Test stage aggregation with head_stages_to_keep=1."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params,
        2,
        head_stages_to_keep=1,
        p_agg_method="sum",
        mi_agg_method="min",
    )

    # s0 kept, s1+s2 -> sa0, s3+s4 -> sa1
    assert agg_params.stage_count == 3
    assert agg_params.stage_id_list == ["i0", "sa0", "sa1"]
    assert agg_params.job_count == 6


def test_create_instance_of_aggregated_stages_agg_count_3(five_stage_params):
    """Test stage aggregation with stage_agg_count=3, head_stages_to_keep=1."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params,
        3,
        head_stages_to_keep=1,
        p_agg_method="sum",
        mi_agg_method="min",
    )

    # s0 kept, s1+s2+s3 -> sa0, s4 -> sa1 (only one stage in this group)
    assert agg_params.stage_id_list == ["i0", "sa0", "sa1"]
    assert agg_params.stage_count == 3


def test_create_instance_of_aggregated_stages_processing_times(five_stage_params):
    """Test that processing times are correctly aggregated."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params, 2, p_agg_method="sum", mi_agg_method="min"
    )

    # sa0 = i0 + i1, sa1 = i2 + i3, sa2 = i4
    # Check job 0: i0=2, i1=3, i2=4, i3=5, i4=6
    # sa0 should be 2+3=5, sa1 should be 4+5=9, sa2 should be 6
    expected_sa0 = 5  # 2+3
    expected_sa1 = 9  # 4+5
    expected_sa2 = 6  # 6

    assert agg_params.p_manager.df.iloc[0, 0] == expected_sa0
    assert agg_params.p_manager.df.iloc[0, 1] == expected_sa1
    assert agg_params.p_manager.df.iloc[0, 2] == expected_sa2


def test_create_instance_of_aggregated_stages_mean(five_stage_params):
    """Test aggregation with mean method."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params, 2, p_agg_method="mean", mi_agg_method="min"
    )

    # sa0 = (i0 + i1) / 2 = (2 + 3) / 2 = 2.5, rounded to 2
    expected_sa0_mean = 2

    assert agg_params.p_manager.df.iloc[0, 0] == expected_sa0_mean


def test_create_instance_of_aggregated_stages_machine_count(five_stage_params):
    """Test that machine counts are correctly set for aggregated stages."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params, 2, p_agg_method="sum", mi_agg_method="max"
    )

    # Original: [2, 3, 2, 1, 2]
    # sa0: max(2, 3) = 3
    # sa1: max(2, 1) = 2
    # sa2: max(2) = 2
    assert agg_params.machine_count_per_stage == [3, 2, 2]


def test_create_instance_of_aggregated_stages_machine_count_min(five_stage_params):
    """Test that machine counts use min aggregation with mi_agg_method='min'."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params, 2, p_agg_method="sum", mi_agg_method="min"
    )

    # Original: [2, 3, 2, 1, 2]
    # sa0: min(2, 3) = 2
    # sa1: min(2, 1) = 1
    # sa2: min(2) = 2
    assert agg_params.machine_count_per_stage == [2, 1, 2]


def test_create_instance_of_aggregated_stages_all_head(five_stage_params):
    """Test when all stages are kept as head stages."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params, 2, 5, p_agg_method="sum", mi_agg_method="min"
    )

    assert agg_params.stage_count == 5
    assert agg_params.stage_id_list == five_stage_params.stage_id_list


def test_create_instance_of_aggregated_stages_invalid_stage_agg_count(
    five_stage_params,
):
    """Test that invalid stage_agg_count raises ValueError."""
    with pytest.raises(ValueError, match="stage_agg_count must be at least 2"):
        create_instance_of_aggregated_stages(
            five_stage_params, 1, p_agg_method="sum", mi_agg_method="min"
        )


def test_create_instance_of_aggregated_stages_invalid_head_negative(five_stage_params):
    """Test that negative head_stages_to_keep raises ValueError."""
    with pytest.raises(ValueError, match="head_stages_to_keep must be non-negative"):
        create_instance_of_aggregated_stages(
            five_stage_params,
            2,
            head_stages_to_keep=-1,
            p_agg_method="sum",
            mi_agg_method="min",
        )


def test_create_instance_of_aggregated_stages_invalid_head_too_large(five_stage_params):
    """Test that head_stages_to_keep > stage count raises ValueError."""
    with pytest.raises(
        ValueError,
        match=r"head_stages_to_keep \+ tail_stages_to_keep cannot exceed the number of stages",
    ):
        create_instance_of_aggregated_stages(
            five_stage_params,
            2,
            head_stages_to_keep=10,
            p_agg_method="sum",
            mi_agg_method="min",
        )


def test_create_instance_of_aggregated_stages_agg_methods(five_stage_params):
    """Test different combinations of p_agg_method and mi_agg_method."""
    # sum for processing time, min for machine count
    agg_params_sum_min = create_instance_of_aggregated_stages(
        five_stage_params, 2, p_agg_method="sum", mi_agg_method="min"
    )
    assert agg_params_sum_min.stage_count == 3
    assert agg_params_sum_min.machine_count_per_stage == [2, 1, 2]

    # mean for processing time, max for machine count
    agg_params_mean_max = create_instance_of_aggregated_stages(
        five_stage_params, 2, p_agg_method="mean", mi_agg_method="max"
    )
    assert agg_params_mean_max.stage_count == 3
    assert agg_params_mean_max.machine_count_per_stage == [3, 2, 2]

    # Check mean values for job 0: (2+3)/2=2.5->2, (4+5)/2=4.5->4, 6
    assert agg_params_mean_max.p_manager.df.iloc[0, 0] == 2
    assert agg_params_mean_max.p_manager.df.iloc[0, 1] == 4
    assert agg_params_mean_max.p_manager.df.iloc[0, 2] == 6


def test_create_instance_of_aggregated_stages_invalid_p_agg_method(five_stage_params):
    """Test that an invalid p_agg_method raises ValueError."""
    with pytest.raises(ValueError):
        create_instance_of_aggregated_stages(
            five_stage_params, 2, p_agg_method="invalid", mi_agg_method="min"
        )


def test_create_instance_of_aggregated_stages_invalid_mi_agg_method(five_stage_params):
    """Test that an invalid mi_agg_method raises ValueError."""
    with pytest.raises(ValueError):
        create_instance_of_aggregated_stages(
            five_stage_params, 2, p_agg_method="sum", mi_agg_method="invalid"
        )


def test_create_instance_of_aggregated_stages_with_tail(five_stage_params):
    """Test stage aggregation with tail_stages_to_keep=1."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params,
        2,
        head_stages_to_keep=0,
        tail_stages_to_keep=1,
        p_agg_method="sum",
        mi_agg_method="min",
    )

    # i4 kept as tail, i0+i1 -> sa0, i2+i3 -> sa1
    assert agg_params.stage_count == 3
    assert agg_params.stage_id_list == ["sa0", "sa1", "i4"]
    assert agg_params.job_count == 6


def test_create_instance_of_aggregated_stages_with_head_and_tail(five_stage_params):
    """Test stage aggregation with both head_stages_to_keep=1 and tail_stages_to_keep=1."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params,
        2,
        head_stages_to_keep=1,
        tail_stages_to_keep=1,
        p_agg_method="sum",
        mi_agg_method="min",
    )

    # i0 kept, i4 kept as tail, i1+i2 -> sa0, i3 -> sa1 (only one stage in this group)
    assert agg_params.stage_count == 4
    assert agg_params.stage_id_list == ["i0", "sa0", "sa1", "i4"]
    assert agg_params.job_count == 6


def test_create_instance_of_aggregated_stages_tail_processing_times(five_stage_params):
    """Test that processing times are correctly preserved for tail stages."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params,
        2,
        head_stages_to_keep=0,
        tail_stages_to_keep=1,
        p_agg_method="sum",
        mi_agg_method="min",
    )

    # sa0 = i0 + i1, sa1 = i2 + i3, i4 (tail) = original i4
    # Check job 0: i0=2, i1=3, i2=4, i3=5, i4=6
    # sa0 should be 2+3=5, sa1 should be 4+5=9, i4 (tail) should be 6
    expected_sa0 = 5  # 2+3
    expected_sa1 = 9  # 4+5
    expected_tail = 6  # i4

    assert agg_params.p_manager.df.iloc[0, 0] == expected_sa0
    assert agg_params.p_manager.df.iloc[0, 1] == expected_sa1
    assert agg_params.p_manager.df.iloc[0, 2] == expected_tail


def test_create_instance_of_aggregated_stages_tail_machine_count(five_stage_params):
    """Test that machine counts are correctly preserved for tail stages."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params,
        2,
        head_stages_to_keep=0,
        tail_stages_to_keep=1,
        p_agg_method="sum",
        mi_agg_method="max",
    )

    # Original: [2, 3, 2, 1, 2]
    # sa0: max(2, 3) = 3
    # sa1: max(2, 1) = 2
    # i4 (preserved tail): 2
    assert agg_params.machine_count_per_stage == [3, 2, 2]


def test_create_instance_of_aggregated_stages_all_tail(five_stage_params):
    """Test when all stages are kept as tail stages."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params,
        2,
        head_stages_to_keep=0,
        tail_stages_to_keep=5,
        p_agg_method="sum",
        mi_agg_method="min",
    )

    assert agg_params.stage_count == 5
    assert agg_params.stage_id_list == five_stage_params.stage_id_list


def test_create_instance_of_aggregated_stages_head_and_tail_only(five_stage_params):
    """Test when head + tail stages cover all stages, no aggregation needed."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params,
        2,
        head_stages_to_keep=2,
        tail_stages_to_keep=3,
        p_agg_method="sum",
        mi_agg_method="min",
    )

    assert agg_params.stage_count == 5
    assert agg_params.stage_id_list == five_stage_params.stage_id_list


def test_create_instance_of_aggregated_stages_invalid_tail_negative(five_stage_params):
    """Test that negative tail_stages_to_keep raises ValueError."""
    with pytest.raises(ValueError, match="tail_stages_to_keep must be non-negative"):
        create_instance_of_aggregated_stages(
            five_stage_params,
            2,
            head_stages_to_keep=0,
            tail_stages_to_keep=-1,
            p_agg_method="sum",
            mi_agg_method="min",
        )


def test_create_instance_of_aggregated_stages_invalid_head_tail_sum(five_stage_params):
    """Test that head + tail exceeding stage count raises ValueError."""
    with pytest.raises(
        ValueError,
        match="head_stages_to_keep \\+ tail_stages_to_keep cannot exceed",
    ):
        create_instance_of_aggregated_stages(
            five_stage_params,
            2,
            head_stages_to_keep=3,
            tail_stages_to_keep=3,
            p_agg_method="sum",
            mi_agg_method="min",
        )


def test_create_instance_of_aggregated_stages_tail_only_with_agg(five_stage_params):
    """Test aggregation with only tail stages kept and some aggregation."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params,
        2,
        head_stages_to_keep=0,
        tail_stages_to_keep=2,
        p_agg_method="sum",
        mi_agg_method="min",
    )

    # i3, i4 kept as tail, remaining: i0, i1, i2 (3 stages)
    # i0+i1 -> sa0, i2 -> sa1 (only one stage in this group)
    assert agg_params.stage_count == 4
    assert agg_params.stage_id_list == ["sa0", "sa1", "i3", "i4"]

    # Check processing times for job 0: i0=2, i1=3, i2=4, i3=5, i4=6
    # sa0 = 2+3 = 5, sa1 = 4 (only i2), i3 (tail) = 5, i4 (tail) = 6
    assert agg_params.p_manager.df.iloc[0, 0] == 5  # sa0 = i0+i1
    assert agg_params.p_manager.df.iloc[0, 1] == 4  # sa1 = i2
    assert agg_params.p_manager.df.iloc[0, 2] == 5  # i3 (tail)
    assert agg_params.p_manager.df.iloc[0, 3] == 6  # i4 (tail)


def test_create_instance_of_aggregated_stages_tail_machine_count_min(five_stage_params):
    """Test machine count aggregation with min method and tail stages."""
    agg_params = create_instance_of_aggregated_stages(
        five_stage_params,
        2,
        head_stages_to_keep=1,
        tail_stages_to_keep=1,
        p_agg_method="sum",
        mi_agg_method="min",
    )

    # Original: [2, 3, 2, 1, 2]
    # i0 (preserved head): 2
    # i1+i2 -> sa0: min(3, 2) = 2
    # i3 -> sa1: min(1) = 1
    # i4 (preserved tail): 2
    assert agg_params.machine_count_per_stage == [2, 2, 1, 2]
