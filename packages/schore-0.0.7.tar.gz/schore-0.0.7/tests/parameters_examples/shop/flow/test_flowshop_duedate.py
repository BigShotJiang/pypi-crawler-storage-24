import io

import pandas as pd
import pytest
from pathlib import Path

from schore.parameters import JobStageProcessingTimeManager
from schore.parameters_examples.shop.flow import FlowshopDuedateParameters


@pytest.fixture
def sample_processing_time_df():
    """Fixture to provide a sample processing time DataFrame."""
    return pd.DataFrame(
        [
            [10, 20, 15],  # Job j0: stages i0, i1, i2
            [12, 18, 22],  # Job j1: stages i0, i1, i2
            [8, 25, 16],  # Job j2: stages i0, i1, i2
        ]
    )


@pytest.fixture
def sample_processing_time_manager(sample_processing_time_df):
    """Fixture to provide a JobStageProcessingTimeManager instance."""
    return JobStageProcessingTimeManager(
        name="SampleProcessingTime", df=sample_processing_time_df
    )


@pytest.fixture
def sample_job_ids():
    """Fixture to provide sample job IDs."""
    return ["j0", "j1", "j2"]


@pytest.fixture
def sample_stage_ids():
    """Fixture to provide sample stage IDs."""
    return ["i0", "i1", "i2"]


@pytest.fixture
def sample_duedates():
    """Fixture to provide sample due dates."""
    return [50, 60, 45]


@pytest.fixture
def sample_job_2_duedate_map(sample_job_ids, sample_duedates):
    """Fixture to provide sample job to due date mapping."""
    return dict(zip(sample_job_ids, sample_duedates))


@pytest.fixture
def sample_flowshop_duedate_params(
    sample_job_ids,
    sample_stage_ids,
    sample_processing_time_manager,
    sample_job_2_duedate_map,
):
    """Fixture to provide a FlowshopDuedateParameters instance."""
    return FlowshopDuedateParameters(
        name="TestInstance",
        job_id_list=sample_job_ids,
        stage_id_list=sample_stage_ids,
        p_manager=sample_processing_time_manager,
        job_2_duedate_map=sample_job_2_duedate_map,
    )


class TestFlowshopDuedateParametersInitialization:
    """Test suite for FlowshopDuedateParameters initialization."""

    def test_initialization_success(self, sample_flowshop_duedate_params):
        """Test successful initialization of FlowshopDuedateParameters."""
        params = sample_flowshop_duedate_params
        assert params.name == "TestInstance"
        assert params.job_count == 3
        assert params.stage_count == 3
        assert len(params.job_2_duedate_map) == 3
        assert params.job_2_duedate_map["j0"] == 50

    def test_inheritance_from_flowshop_parameters(self, sample_flowshop_duedate_params):
        """Test that FlowshopDuedateParameters inherits FlowshopParameters properties."""
        params = sample_flowshop_duedate_params
        assert params.job_id_list == ["j0", "j1", "j2"]
        assert params.stage_id_list == ["i0", "i1", "i2"]
        assert params.p_manager.df.shape == (3, 3)

    def test_job_2_duedate_map_property_returns_copy(
        self, sample_flowshop_duedate_params
    ):
        """Test that job_2_duedate_map property returns a copy."""
        params = sample_flowshop_duedate_params
        duedate_map = params.job_2_duedate_map
        duedate_map["j0"] = 999  # Modify the returned map

        # Original should be unchanged
        assert params.job_2_duedate_map["j0"] == 50


class TestFlowshopDuedateParametersFromVrmData:
    """Test suite for from_vrm_data class method."""

    @pytest.fixture
    def valid_vrm_stream(self):
        """Fixture providing a valid VRM format stream."""
        data = """\
3
3
50 60 45
10 20 15
12 18 22
8 25 16
"""
        return io.StringIO(data)

    @pytest.fixture
    def vrm_stream_with_different_job_count(self):
        """Fixture with 2 jobs instead of 3."""
        data = """\
2
3
40 55
15 25 20
18 22 28
"""
        return io.StringIO(data)

    def test_from_vrm_data_success(self, valid_vrm_stream):
        """Test successful parsing of VRM format data."""
        params = FlowshopDuedateParameters.from_vrm_data("VRM_Test", valid_vrm_stream)

        assert params.name == "VRM_Test"
        assert params.job_count == 3
        assert params.stage_count == 3
        assert params.job_id_list == ["j0", "j1", "j2"]
        assert params.stage_id_list == ["i0", "i1", "i2"]
        assert params.job_2_duedate_map == {"j0": 50, "j1": 60, "j2": 45}

        # Check processing times matrix
        expected_df = pd.DataFrame([[10, 20, 15], [12, 18, 22], [8, 25, 16]])
        pd.testing.assert_frame_equal(params.p_manager.df, expected_df)

    def test_from_vrm_data_different_size(self, vrm_stream_with_different_job_count):
        """Test parsing with different job/stage counts."""
        params = FlowshopDuedateParameters.from_vrm_data(
            "VRM_2Jobs", vrm_stream_with_different_job_count
        )

        assert params.job_count == 2
        assert params.stage_count == 3
        assert params.job_id_list == ["j0", "j1"]
        assert params.stage_id_list == ["i0", "i1", "i2"]
        assert params.job_2_duedate_map == {"j0": 40, "j1": 55}

    def test_from_vrm_data_job_id_padding(self):
        """Test job ID padding for larger instances."""
        data = """\
12
2
10 20 30 40 50 60 70 80 90 100 110 120
5 10
8 12
15 18
20 25
12 16
18 22
25 30
14 19
22 28
16 21
19 24
21 26
"""
        stream = io.StringIO(data)
        params = FlowshopDuedateParameters.from_vrm_data("Large_VRM", stream)

        # Check that job IDs are properly zero-padded
        expected_job_ids = [f"j{str(i).zfill(2)}" for i in range(12)]
        assert params.job_id_list == expected_job_ids
        assert params.job_id_list[0] == "j00"
        assert params.job_id_list[11] == "j11"

    def test_from_vrm_data_stage_id_padding(self):
        """Test stage ID padding for larger instances."""
        data = """\
2
15
100 200
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
11 12 13 14 15 16 17 18 19 20 21 22 23 24 25
"""
        stream = io.StringIO(data)
        params = FlowshopDuedateParameters.from_vrm_data("Wide_VRM", stream)

        # Check that stage IDs are properly zero-padded
        expected_stage_ids = [f"i{str(i).zfill(2)}" for i in range(15)]
        assert params.stage_id_list == expected_stage_ids
        assert params.stage_id_list[0] == "i00"
        assert params.stage_id_list[14] == "i14"


class TestFlowshopDuedateParametersValidation:
    """Test suite for validation methods."""

    def test_validate_duedate_list_success(self):
        """Test successful due date list validation."""
        # Should not raise any exception
        FlowshopDuedateParameters._validate_duedate_list(3, [10, 20, 30])

    def test_validate_duedate_list_length_mismatch(self):
        """Test due date list validation with length mismatch."""
        with pytest.raises(
            ValueError, match="Due date list length 2 does not match job count 3"
        ):
            FlowshopDuedateParameters._validate_duedate_list(3, [10, 20])

    def test_validate_duedate_list_negative_values(self):
        """Test due date list validation with negative values."""
        with pytest.raises(ValueError, match="Due dates must be non-negative"):
            FlowshopDuedateParameters._validate_duedate_list(3, [10, -5, 30])

    def test_validate_duedate_list_zero_allowed(self):
        """Test that zero due dates are allowed."""
        # Should not raise any exception
        FlowshopDuedateParameters._validate_duedate_list(3, [0, 10, 0])

    def test_validate_processing_times_inherited(self, sample_processing_time_manager):
        """Test that processing times validation is inherited from parent class."""
        # Should not raise any exception
        FlowshopDuedateParameters._validate_processing_times(
            3, 3, sample_processing_time_manager
        )


class TestFlowshopDuedateParametersEdgeCases:
    """Test suite for edge cases and error conditions."""

    def test_from_vrm_data_empty_stream(self):
        """Test parsing from empty stream."""
        empty_stream = io.StringIO("")
        with pytest.raises(EOFError):
            FlowshopDuedateParameters.from_vrm_data("Empty", empty_stream)

    def test_from_vrm_data_incomplete_stream(self):
        """Test parsing from incomplete stream."""
        incomplete_stream = io.StringIO(
            "3\n3\n"
        )  # Missing due dates and processing times
        with pytest.raises(EOFError):
            FlowshopDuedateParameters.from_vrm_data("Incomplete", incomplete_stream)

    def test_from_vrm_data_invalid_job_count(self):
        """Test parsing with invalid job count."""
        invalid_stream = io.StringIO("not_a_number\n3\n10 20 30\n")
        with pytest.raises(ValueError):
            FlowshopDuedateParameters.from_vrm_data("Invalid", invalid_stream)

    def test_from_vrm_data_duedate_count_mismatch(self):
        """Test parsing when due date count doesn't match job count."""
        mismatch_stream = io.StringIO("""\
3
2
10 20
5 10
8 12
15 18
""")
        with pytest.raises(
            ValueError, match="Due date list length 2 does not match job count 3"
        ):
            FlowshopDuedateParameters.from_vrm_data("Mismatch", mismatch_stream)

    def test_single_job_single_stage(self):
        """Test with minimal instance (1 job, 1 stage)."""
        data = """\
1
1
42
15
"""
        stream = io.StringIO(data)
        params = FlowshopDuedateParameters.from_vrm_data("Minimal", stream)

        assert params.job_count == 1
        assert params.stage_count == 1
        assert params.job_id_list == ["j0"]
        assert params.stage_id_list == ["i0"]
        assert params.job_2_duedate_map == {"j0": 42}
        assert params.p_manager.df.iloc[0, 0] == 15


class TestFlowshopDuedateParametersIntegration:
    """Integration tests using FlowshopDuedateParameters with other components."""

    def test_repr_string(self, sample_flowshop_duedate_params):
        """Test string representation."""
        params = sample_flowshop_duedate_params
        repr_str = repr(params)
        assert "FlowshopDuedateParameters" in repr_str
        assert "job_count=3" in repr_str
        assert "stage_count=3" in repr_str

    def test_property_immutability(self, sample_flowshop_duedate_params):
        """Test that returned properties are immutable copies."""
        params = sample_flowshop_duedate_params

        # Test job_id_list immutability
        job_ids = params.job_id_list
        job_ids.append("extra_job")
        assert len(params.job_id_list) == 3  # Original unchanged

        # Test stage_id_list immutability
        stage_ids = params.stage_id_list
        stage_ids.append("extra_stage")
        assert len(params.stage_id_list) == 3  # Original unchanged

        # Test job_2_duedate_map immutability
        duedate_map = params.job_2_duedate_map
        duedate_map["extra_job"] = 999
        assert "extra_job" not in params.job_2_duedate_map  # Original unchanged

    def test_compatibility_with_parent_methods(self, sample_flowshop_duedate_params):
        """Test that parent class methods work correctly."""
        params = sample_flowshop_duedate_params

        # These are inherited from FlowshopParameters
        assert params.job_count == 3
        assert params.stage_count == 3
        assert isinstance(params.p_manager, JobStageProcessingTimeManager)


@pytest.mark.parametrize(
    "job_count,stage_count,expected_job_digits,expected_stage_digits",
    [
        (5, 3, 1, 1),  # j0-j4, i0-i2
        (10, 8, 1, 1),  # j0-j9, i0-i7
        (15, 12, 2, 2),  # j00-j14, i00-i11
        (100, 50, 2, 2),  # j00-j99, i00-i49
        (1000, 200, 3, 3),  # j000-j999, i000-i199
    ],
)
def test_id_padding_parametrized(
    job_count, stage_count, expected_job_digits, expected_stage_digits
):
    """Parametrized test for ID padding with different sizes."""
    # Create mock data stream
    duedates = " ".join(str(i * 10) for i in range(job_count))
    processing_lines = []
    for j in range(job_count):
        line = " ".join(str(j * stage_count + s + 1) for s in range(stage_count))
        processing_lines.append(line)

    data = f"{job_count}\n{stage_count}\n{duedates}\n" + "\n".join(processing_lines)
    stream = io.StringIO(data)

    params = FlowshopDuedateParameters.from_vrm_data("Param_Test", stream)

    # Check job ID padding
    expected_job_id = f"j{str(job_count - 1).zfill(expected_job_digits)}"
    assert params.job_id_list[-1] == expected_job_id

    # Check stage ID padding
    expected_stage_id = f"i{str(stage_count - 1).zfill(expected_stage_digits)}"
    assert params.stage_id_list[-1] == expected_stage_id


@pytest.mark.skipif(
    not (
        Path(__file__).resolve().parents[3]
        / "resources"
        / "shop"
        / "flowshop_duedate"
        / "0.txt"
    ).exists(),
    reason="Sample file not present in tests resources: tests/resources/flowshop_duedate/0.txt",
)
def test_from_vrm_data_from_external_file_stream():
    """Test parsing the provided repo-local sample 0.txt file as a stream."""
    path = (
        Path(__file__).resolve().parents[3]
        / "resources"
        / "shop"
        / "flowshop_duedate"
        / "0.txt"
    )
    with path.open("r") as f:
        params = FlowshopDuedateParameters.from_vrm_data("ExternalFile", f)

    # Expected values from the attached sample
    assert params.job_count == 6
    assert params.stage_count == 3
    # duedates line in file: 10 15 20 20 15 20
    assert params.job_2_duedate_map["j0"] == 10
    assert params.job_2_duedate_map["j5"] == 20

    # processing times matrix (first and last rows)
    assert list(params.p_manager.df.iloc[0]) == [2, 3, 4]
    assert list(params.p_manager.df.iloc[-1]) == [4, 8, 12]
