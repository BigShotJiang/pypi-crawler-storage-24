import io

import pandas as pd
import pytest

from schore import JobStageProcessingTimeManager


@pytest.fixture
def sample_text_stream():
    """Fixture to provide a sample text stream."""
    data = """\
1 2 3
4 5 6
7 8 9
"""
    return io.StringIO(data)


@pytest.fixture
def sample_processing_time_manager():
    """Fixture to provide a sample JobStageProcessingTimeManager instance."""
    df = pd.DataFrame([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    return JobStageProcessingTimeManager(name="SampleProcessingTime", df=df)


def test_initialization(sample_processing_time_manager: JobStageProcessingTimeManager):
    """Test the initialization of JobStageProcessingTimeManager."""
    assert sample_processing_time_manager.name == "SampleProcessingTime"
    assert sample_processing_time_manager.df.shape == (3, 3)


def test_from_text_stream(sample_text_stream):
    """Test the creation of JobStageProcessingTimeManager from a text stream."""
    manager = JobStageProcessingTimeManager.from_text_stream(
        sample_text_stream, row_count=3
    )
    assert manager.name == "JobStageProcessingTimeManager"
    assert manager.df.shape == (3, 3)
    assert manager.df.iloc[0, 0] == 1
    assert manager.df.iloc[2, 2] == 9


def test_from_text_stream_transpose_true():
    """Test from_text_stream with transpose=True swaps shape and values."""
    stream = io.StringIO("1 2 3\n4 5 6\n")
    manager = JobStageProcessingTimeManager.from_text_stream(
        stream, row_count=2, transpose=True
    )

    assert manager.name == "JobStageProcessingTimeManager"
    assert manager.df.shape == (3, 2)
    assert manager.df.values.tolist() == [[1, 4], [2, 5], [3, 6]]


def test_stage_and_job_count_mismatch(
    sample_processing_time_manager: JobStageProcessingTimeManager,
):
    """Test that mismatched stage or job counts raise ValueError."""
    with pytest.raises(ValueError, match="stage count mismatch"):
        sample_processing_time_manager.stage_2_job_2_value_map(
            ["S1", "S2"], ["J1", "J2", "J3"]
        )

    with pytest.raises(ValueError, match="job count mismatch"):
        sample_processing_time_manager.job_2_stage_2_value_map(
            ["J1", "J2"], ["S1", "S2", "S3"]
        )


def test_stage_map_cache_reuse(
    sample_processing_time_manager: JobStageProcessingTimeManager,
):
    stage_ids = ["S1", "S2", "S3"]
    job_ids = ["J1", "J2", "J3"]

    first = sample_processing_time_manager.stage_2_job_2_value_map(stage_ids, job_ids)
    second = sample_processing_time_manager.stage_2_job_2_value_map(stage_ids, job_ids)

    assert first is second


def test_stage_map_cache_invalidation_on_df_reassign(
    sample_processing_time_manager: JobStageProcessingTimeManager,
):
    stage_ids = ["S1", "S2", "S3"]
    job_ids = ["J1", "J2", "J3"]

    cached = sample_processing_time_manager.stage_2_job_2_value_map(stage_ids, job_ids)
    sample_processing_time_manager.df = pd.DataFrame([[9, 8, 7], [6, 5, 4], [3, 2, 1]])
    refreshed = sample_processing_time_manager.stage_2_job_2_value_map(
        stage_ids, job_ids
    )

    assert refreshed is not cached
    assert refreshed["S1"]["J1"] == 9
    assert refreshed["S3"]["J3"] == 1


def test_from_text_stream_with_float():
    """Test the creation of JobStageProcessingTimeManager with float values."""
    stream = io.StringIO("1.1 2.2 3.3\n4.4 5.5 6.6\n7.7 8.8 9.9\n")
    manager = JobStageProcessingTimeManager.from_text_stream(
        stream, row_count=3, dtype=float
    )
    assert manager.df.shape == (3, 3)
    assert manager.df.iloc[0, 0] == 1.1
    assert manager.df.iloc[2, 2] == 9.9


def test_from_text_stream_invalid_dtype():
    """Test that from_text_stream raises TypeError for invalid dtype."""
    stream = io.StringIO("1 2 3\n4 5 6\n7 8 9\n")
    with pytest.raises(TypeError, match="Expected dtype to be a numeric type"):
        JobStageProcessingTimeManager.from_text_stream(
            stream, row_count=3, dtype=complex
        )
    stream = io.StringIO("True False True\nFalse True False\nTrue True False\n")
    with pytest.raises(
        TypeError, match="Boolean dtype is not supported for processing times."
    ):
        JobStageProcessingTimeManager.from_text_stream(stream, row_count=3, dtype=bool)
    stream = io.StringIO("a b c\nx y z\n1 2 3\n")
    with pytest.raises(TypeError, match="Expected dtype to be a numeric type"):
        JobStageProcessingTimeManager.from_text_stream(stream, row_count=3, dtype=str)


def test_from_text_stream_dtype_not_a_type():
    stream = io.StringIO("1 2 3\n4 5 6\n7 8 9\n")
    with pytest.raises(TypeError, match="Expected dtype to be a type"):
        JobStageProcessingTimeManager.from_text_stream(stream, row_count=3, dtype="int")


def test_stage_job_2_value_map(
    sample_processing_time_manager: JobStageProcessingTimeManager,
):
    stage_ids = ["S1", "S2", "S3"]
    job_ids = ["J1", "J2", "J3"]
    expected = {
        ("S1", "J1"): 1,
        ("S2", "J1"): 2,
        ("S3", "J1"): 3,
        ("S1", "J2"): 4,
        ("S2", "J2"): 5,
        ("S3", "J2"): 6,
        ("S1", "J3"): 7,
        ("S2", "J3"): 8,
        ("S3", "J3"): 9,
    }
    assert (
        sample_processing_time_manager.stage_job_2_value_map(stage_ids, job_ids)
        == expected
    )


def test_stage_2_job_2_value_map(
    sample_processing_time_manager: JobStageProcessingTimeManager,
):
    """Test the stage_2_job_2_value_map method."""
    stage_ids = ["S1", "S2", "S3"]
    job_ids = ["J1", "J2", "J3"]
    expected_mapping = {
        "S1": {"J1": 1, "J2": 4, "J3": 7},
        "S2": {"J1": 2, "J2": 5, "J3": 8},
        "S3": {"J1": 3, "J2": 6, "J3": 9},
    }
    assert (
        sample_processing_time_manager.stage_2_job_2_value_map(stage_ids, job_ids)
        == expected_mapping
    )


def test_job_stage_2_value_map(
    sample_processing_time_manager: JobStageProcessingTimeManager,
):
    job_ids = ["J1", "J2", "J3"]
    stage_ids = ["S1", "S2", "S3"]
    expected = {
        ("J1", "S1"): 1,
        ("J2", "S1"): 4,
        ("J3", "S1"): 7,
        ("J1", "S2"): 2,
        ("J2", "S2"): 5,
        ("J3", "S2"): 8,
        ("J1", "S3"): 3,
        ("J2", "S3"): 6,
        ("J3", "S3"): 9,
    }
    assert (
        sample_processing_time_manager.job_stage_2_value_map(job_ids, stage_ids)
        == expected
    )


def test_job_2_stage_2_value_map(
    sample_processing_time_manager: JobStageProcessingTimeManager,
):
    """Test the job_2_stage_2_value_map method."""
    job_ids = ["J1", "J2", "J3"]
    stage_ids = ["S1", "S2", "S3"]
    expected_mapping = {
        "J1": {"S1": 1, "S2": 2, "S3": 3},
        "J2": {"S1": 4, "S2": 5, "S3": 6},
        "J3": {"S1": 7, "S2": 8, "S3": 9},
    }
    assert (
        sample_processing_time_manager.job_2_stage_2_value_map(job_ids, stage_ids)
        == expected_mapping
    )


def test_filter_by_job_indices(
    sample_processing_time_manager: JobStageProcessingTimeManager,
):
    filtered = sample_processing_time_manager.filter_by_job_indices([0, 2])
    assert isinstance(filtered, JobStageProcessingTimeManager)
    assert filtered.name == sample_processing_time_manager.name
    assert filtered.df.values.tolist() == [[1, 2, 3], [7, 8, 9]]


def test_filter_by_stage_indices(
    sample_processing_time_manager: JobStageProcessingTimeManager,
):
    filtered = sample_processing_time_manager.filter_by_stage_indices([0, 2])
    assert isinstance(filtered, JobStageProcessingTimeManager)
    assert filtered.name == sample_processing_time_manager.name
    assert filtered.df.values.tolist() == [[1, 3], [4, 6], [7, 9]]


def test_filter_by_job_and_stage_indices(
    sample_processing_time_manager: JobStageProcessingTimeManager,
):
    filtered = sample_processing_time_manager.filter_by_job_indices([0, 2])
    filtered = filtered.filter_by_stage_indices([1])
    assert isinstance(filtered, JobStageProcessingTimeManager)
    assert filtered.name == sample_processing_time_manager.name
    assert filtered.df.values.tolist() == [[2], [8]]


def test_as_stage_reversed_job_stage_processing_time_manager():
    source_df = pd.DataFrame(
        [[1, 2, 3], [4, 5, 6]],
        index=["J1", "J2"],
        columns=["S1", "S2", "S3"],
    )
    source = JobStageProcessingTimeManager(name="P", df=source_df)

    reversed_manager = source.as_stage_reversed()

    assert isinstance(reversed_manager, JobStageProcessingTimeManager)
    assert reversed_manager.name == "P_reversed"
    assert reversed_manager.df.columns.tolist() == ["S3", "S2", "S1"]
    assert reversed_manager.df.values.tolist() == [[3, 2, 1], [6, 5, 4]]

    # Ensure original manager is unchanged.
    assert source.name == "P"
    assert source.df.columns.tolist() == ["S1", "S2", "S3"]
    assert source.df.values.tolist() == [[1, 2, 3], [4, 5, 6]]
