import io

import pandas as pd
import pytest

from schore import JobMachineProcessingTimeManager


@pytest.fixture
def sample_job_machine_manager():
    df = pd.DataFrame([[1, 0, 3], [0, 5, 0], [7, 8, 9]])
    return JobMachineProcessingTimeManager(name="SampleJobMachine", df=df)


def test_initialization(sample_job_machine_manager: JobMachineProcessingTimeManager):
    assert sample_job_machine_manager.name == "SampleJobMachine"
    assert sample_job_machine_manager.df.shape == (3, 3)


def test_from_text_stream():
    stream = io.StringIO("1 0 3\n0 5 0\n7 8 9\n")
    manager = JobMachineProcessingTimeManager.from_text_stream(stream, row_count=3)
    assert manager.name == "JobMachineProcessingTimeManager"
    assert manager.df.values.tolist() == [[1, 0, 3], [0, 5, 0], [7, 8, 9]]


def test_from_text_stream_transpose_true():
    stream = io.StringIO("1 2 3\n4 5 6\n")
    manager = JobMachineProcessingTimeManager.from_text_stream(
        stream, row_count=2, transpose=True
    )

    assert manager.name == "JobMachineProcessingTimeManager"
    assert manager.df.shape == (3, 2)
    assert manager.df.values.tolist() == [[1, 4], [2, 5], [3, 6]]


def test_machine_2_job_2_value_map(
    sample_job_machine_manager: JobMachineProcessingTimeManager,
):
    mc_ids = ["M1", "M2", "M3"]
    job_ids = ["J1", "J2", "J3"]
    expected = {
        "M1": {"J1": 1, "J2": 0, "J3": 7},
        "M2": {"J1": 0, "J2": 5, "J3": 8},
        "M3": {"J1": 3, "J2": 0, "J3": 9},
    }
    assert (
        sample_job_machine_manager.machine_2_job_2_value_map(mc_ids, job_ids)
        == expected
    )


def test_machine_job_2_value_map(
    sample_job_machine_manager: JobMachineProcessingTimeManager,
):
    mc_ids = ["M1", "M2", "M3"]
    job_ids = ["J1", "J2", "J3"]
    expected = {
        ("M1", "J1"): 1,
        ("M2", "J1"): 0,
        ("M3", "J1"): 3,
        ("M1", "J2"): 0,
        ("M2", "J2"): 5,
        ("M3", "J2"): 0,
        ("M1", "J3"): 7,
        ("M2", "J3"): 8,
        ("M3", "J3"): 9,
    }
    assert (
        sample_job_machine_manager.machine_job_2_value_map(mc_ids, job_ids) == expected
    )


def test_job_2_eligible_mc_list_map(
    sample_job_machine_manager: JobMachineProcessingTimeManager,
):
    job_ids = ["J1", "J2", "J3"]
    mc_ids = ["M1", "M2", "M3"]
    expected = {
        "J1": ["M1", "M3"],
        "J2": ["M2"],
        "J3": ["M1", "M2", "M3"],
    }
    assert (
        sample_job_machine_manager.job_2_eligible_mc_list_map(job_ids, mc_ids)
        == expected
    )


def test_machine_map_cache_reuse(
    sample_job_machine_manager: JobMachineProcessingTimeManager,
):
    mc_ids = ["M1", "M2", "M3"]
    job_ids = ["J1", "J2", "J3"]

    first = sample_job_machine_manager.machine_2_job_2_value_map(mc_ids, job_ids)
    second = sample_job_machine_manager.machine_2_job_2_value_map(mc_ids, job_ids)

    assert first is second


def test_machine_map_cache_invalidation_on_df_reassign(
    sample_job_machine_manager: JobMachineProcessingTimeManager,
):
    mc_ids = ["M1", "M2", "M3"]
    job_ids = ["J1", "J2", "J3"]

    cached = sample_job_machine_manager.machine_2_job_2_value_map(mc_ids, job_ids)
    sample_job_machine_manager.df = pd.DataFrame([[9, 0, 1], [0, 2, 0], [3, 4, 5]])
    refreshed = sample_job_machine_manager.machine_2_job_2_value_map(mc_ids, job_ids)

    assert refreshed is not cached
    assert refreshed["M1"]["J1"] == 9
    assert refreshed["M3"]["J3"] == 5


def test_machine_and_job_count_mismatch_raises_value_error(
    sample_job_machine_manager: JobMachineProcessingTimeManager,
):
    with pytest.raises(ValueError, match="machine count mismatch"):
        sample_job_machine_manager.machine_2_job_2_value_map(
            ["M1", "M2"], ["J1", "J2", "J3"]
        )

    with pytest.raises(ValueError, match="job count mismatch"):
        sample_job_machine_manager.machine_job_2_value_map(
            ["M1", "M2", "M3"], ["J1", "J2"]
        )


def test_filter_by_job_indices(
    sample_job_machine_manager: JobMachineProcessingTimeManager,
):
    filtered = sample_job_machine_manager.filter_by_job_indices([1])
    assert isinstance(filtered, JobMachineProcessingTimeManager)
    assert filtered.name == sample_job_machine_manager.name
    assert filtered.df.values.tolist() == [[0, 5, 0]]


def test_from_text_stream_dtype_not_a_type():
    stream = io.StringIO("1 0 3\n0 5 0\n7 8 9\n")
    with pytest.raises(TypeError, match="Expected dtype to be a type"):
        JobMachineProcessingTimeManager.from_text_stream(
            stream, row_count=3, dtype="int"
        )


def test_from_text_stream_invalid_dtype():
    stream = io.StringIO("1 0 3\n0 5 0\n7 8 9\n")
    with pytest.raises(TypeError, match="Expected dtype to be a numeric type"):
        JobMachineProcessingTimeManager.from_text_stream(
            stream, row_count=3, dtype=complex
        )

    stream = io.StringIO("True False True\nFalse True False\nTrue True False\n")
    with pytest.raises(
        TypeError, match="Boolean dtype is not supported for processing times."
    ):
        JobMachineProcessingTimeManager.from_text_stream(
            stream, row_count=3, dtype=bool
        )

    stream = io.StringIO("a b c\nx y z\n1 2 3\n")
    with pytest.raises(TypeError, match="Expected dtype to be a numeric type"):
        JobMachineProcessingTimeManager.from_text_stream(stream, row_count=3, dtype=str)
