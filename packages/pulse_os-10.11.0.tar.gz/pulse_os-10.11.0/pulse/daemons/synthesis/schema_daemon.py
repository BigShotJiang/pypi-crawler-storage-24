#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""
Schema Daemon — Brain V6 Phase 2

Reads lessons + patterns from the brain, uses LLM (Ollama cloud → paid fallback)
to identify proven domain schemas (recurring, validated patterns).
Writes to Hippocampus/Patterns/schemas.json.

Usage: python -m pulse.daemons.synthesis.schema_daemon [--once] [--batch] [--verbose] [--dry-run]
  --batch: Sweep entire brain in chunks (multiple LLM calls). Use for initial population.
  --once:  Single chunk extraction then exit.
  Daemon mode (default): Sliding window — advances through brain each 6h cycle.
"""
from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path

from pulse.core.brain_utils import HIPPOCAMPUS_DIR, now_iso
from pulse.core.llm_router import dispatch, extract_json
from pulse.daemons.consolidation.consolidation_promotion import DOMAIN_TYPE_MAP, SOURCE_EVIDENCE_MAP

log = logging.getLogger("pulse.schema_daemon")

SCHEMAS_FILE = HIPPOCAMPUS_DIR / "Patterns" / "schemas.json"
LESSONS_FILE = HIPPOCAMPUS_DIR / "Lessons" / "auto_lessons.md"
PATTERNS_FILE = HIPPOCAMPUS_DIR / "Patterns" / "auto_patterns.md"
STATE_FILE = HIPPOCAMPUS_DIR / ".schema_daemon_state.json"
CYCLE_INTERVAL = 6 * 3600  # 6 hours
CHUNK_SIZE = 80  # titles per LLM call

EXTRACT_PROMPT = """You are analyzing a knowledge brain. Extract 5-15 DOMAIN SCHEMAS from these lessons and patterns.

A schema is a PROVEN, REUSABLE rule that applies across multiple scenarios. Examples:
- "Always validate inputs at system boundaries before processing"
- "Use atomic file operations (write-tmp + rename) to prevent corruption"
- "Cascade through free providers before paid ones to minimize cost"

LESSONS (batch {batch_label}):
{lessons}

PATTERNS (batch {batch_label}):
{patterns}

EXISTING SCHEMAS (do NOT duplicate these):
{existing}

Output ONLY valid JSON:
{{"schemas": [{{"name": "short title", "description": "1-2 sentence rule", "domain": "category", "confidence": 0.7}}]}}

Rules:
- Only extract schemas with strong evidence (mentioned 2+ times or clearly proven)
- Domain should be one of: architecture, testing, deployment, security, performance, brain, agents, general
- Confidence 0.5-1.0 based on how proven the pattern is
- Do NOT repeat existing schemas
- Output ONLY the JSON object, nothing else"""


def _get_all_titles(filepath: Path) -> list[str]:
    """Extract ALL section titles from a markdown brain file."""
    if not filepath.exists():
        return []
    text = filepath.read_text(encoding="utf-8", errors="replace")
    sections = text.split("\n## ")
    return [s.split("\n")[0].strip() for s in sections[1:] if s.strip()]


def _titles_to_text(titles: list[str]) -> str:
    return "\n".join(f"- {t}" for t in titles)


def _load_state() -> dict:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"lesson_offset": 0, "pattern_offset": 0}


def _save_state(state: dict):
    try:
        STATE_FILE.write_text(json.dumps(state), encoding="utf-8")
    except Exception:
        pass


def _load_schemas() -> dict:
    if not SCHEMAS_FILE.exists():
        return {"version": "1.0", "description": "Proven patterns", "schemas": [], "last_updated": now_iso()}
    try:
        return json.loads(SCHEMAS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"version": "1.0", "description": "Proven patterns", "schemas": [], "last_updated": now_iso()}


def _save_schemas(data: dict):
    data["last_updated"] = now_iso()
    SCHEMAS_FILE.parent.mkdir(parents=True, exist_ok=True)
    SCHEMAS_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _extract_one_chunk(lesson_titles: list[str], pattern_titles: list[str],
                       batch_label: str, current: dict, existing_names: set,
                       dry_run: bool, verbose: bool) -> int:
    """Run one LLM extraction on a chunk of titles. Returns count of items added."""
    if not lesson_titles and not pattern_titles:
        return 0

    existing_summary = "\n".join(
        f"- {s['name']}" for s in current.get("schemas", [])[-30:] if s.get("name")
    ) or "(none yet)"

    prompt = EXTRACT_PROMPT.format(
        lessons=_titles_to_text(lesson_titles) or "(none)",
        patterns=_titles_to_text(pattern_titles) or "(none)",
        existing=existing_summary, batch_label=batch_label,
    )

    if verbose:
        log.info("Chunk %s: %d lessons + %d patterns (%d chars prompt)",
                 batch_label, len(lesson_titles), len(pattern_titles), len(prompt))

    try:
        raw = dispatch(prompt, task_type="fast")
        result = extract_json(raw)
    except Exception as e:
        log.error("LLM dispatch failed on chunk %s: %s", batch_label, e)
        return 0

    added = 0
    for schema in result.get("schemas", []):
        name = schema.get("name", "").strip()
        if not name or name.lower() in existing_names:
            continue
        schema.setdefault("confidence", 0.7)
        schema.setdefault("domain", "general")
        schema["created"] = now_iso()
        schema["source"] = "schema_daemon"
        schema["type"] = DOMAIN_TYPE_MAP.get(schema["domain"], "heuristic")
        schema["evidence_links"] = SOURCE_EVIDENCE_MAP["schema_daemon"]
        current["schemas"].append(schema)
        existing_names.add(name.lower())
        added += 1
    return added


def run_schema_batch(dry_run: bool = False, verbose: bool = False) -> dict:
    """Batch mode: sweep entire brain in chunks with multiple LLM calls."""
    all_lessons = _get_all_titles(LESSONS_FILE)
    all_patterns = _get_all_titles(PATTERNS_FILE)
    total_sections = len(all_lessons) + len(all_patterns)
    log.info("Batch mode: %d lessons + %d patterns = %d total titles",
             len(all_lessons), len(all_patterns), total_sections)

    current = _load_schemas()
    existing_names = {s.get("name", "").lower() for s in current.get("schemas", [])}
    total_added = 0

    # Chunk lessons and patterns separately, pair them up
    lesson_chunks = [all_lessons[i:i + CHUNK_SIZE] for i in range(0, max(len(all_lessons), 1), CHUNK_SIZE)]
    pattern_chunks = [all_patterns[i:i + CHUNK_SIZE] for i in range(0, max(len(all_patterns), 1), CHUNK_SIZE)]
    n_chunks = max(len(lesson_chunks), len(pattern_chunks))

    for i in range(n_chunks):
        l_chunk = lesson_chunks[i] if i < len(lesson_chunks) else []
        p_chunk = pattern_chunks[i] if i < len(pattern_chunks) else []
        label = f"{i + 1}/{n_chunks}"
        added = _extract_one_chunk(l_chunk, p_chunk, label, current, existing_names, dry_run, verbose)
        total_added += added
        log.info("Chunk %s: +%d schemas (running total: %d)", label, added, total_added)

        # Save after each chunk to preserve progress
        if added > 0 and not dry_run:
            _save_schemas(current)

    log.info("Batch complete: %d new schemas (total: %d)", total_added, len(current["schemas"]))
    return {"status": "ok", "new": total_added, "total": len(current["schemas"]), "chunks": n_chunks}


def run_schema_extraction(dry_run: bool = False, verbose: bool = False) -> dict:
    """Single chunk extraction with sliding window for daemon mode."""
    all_lessons = _get_all_titles(LESSONS_FILE)
    all_patterns = _get_all_titles(PATTERNS_FILE)

    if not all_lessons and not all_patterns:
        log.info("No brain data to extract schemas from")
        return {"status": "empty", "new": 0}

    state = _load_state()
    l_off = state.get("lesson_offset", 0) % max(len(all_lessons), 1)
    p_off = state.get("pattern_offset", 0) % max(len(all_patterns), 1)

    l_chunk = all_lessons[l_off:l_off + CHUNK_SIZE]
    p_chunk = all_patterns[p_off:p_off + CHUNK_SIZE]

    current = _load_schemas()
    existing_names = {s.get("name", "").lower() for s in current.get("schemas", [])}

    label = f"offset L:{l_off} P:{p_off}"
    added = _extract_one_chunk(l_chunk, p_chunk, label, current, existing_names, dry_run, verbose)

    if added > 0 and not dry_run:
        _save_schemas(current)
        log.info("Added %d new schemas (total: %d)", added, len(current["schemas"]))

    # Advance window for next cycle
    new_l = l_off + CHUNK_SIZE
    new_p = p_off + CHUNK_SIZE
    if new_l >= len(all_lessons):
        new_l = 0
    if new_p >= len(all_patterns):
        new_p = 0
    _save_state({"lesson_offset": new_l, "pattern_offset": new_p})

    return {"status": "ok", "new": added, "total": len(current.get("schemas", [])),
            "window": {"lessons": f"{l_off}-{l_off + len(l_chunk)}/{len(all_lessons)}",
                       "patterns": f"{p_off}-{p_off + len(p_chunk)}/{len(all_patterns)}"}}


def run_daemon(verbose: bool = False, dry_run: bool = False):
    """Main daemon loop — sliding window extraction every CYCLE_INTERVAL."""
    log.info("Schema Daemon started (interval=%dh, chunk=%d)", CYCLE_INTERVAL // 3600, CHUNK_SIZE)
    while True:
        try:
            result = run_schema_extraction(dry_run=dry_run, verbose=verbose)
            log.info("Cycle complete: %s", result)
        except Exception as e:
            log.error("Cycle failed: %s", e)
        time.sleep(CYCLE_INTERVAL)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [SCHEMA] %(message)s")
    once = "--once" in sys.argv
    batch = "--batch" in sys.argv
    verbose = "--verbose" in sys.argv
    dry_run = "--dry-run" in sys.argv

    if batch:
        result = run_schema_batch(dry_run=dry_run, verbose=verbose)
        print(json.dumps(result, indent=2))
    elif once:
        result = run_schema_extraction(dry_run=dry_run, verbose=verbose)
        print(json.dumps(result, indent=2))
    else:
        run_daemon(verbose=verbose, dry_run=dry_run)
