# shieldauth

License key protection for Python apps — one line of code.

## Install

```bash
pip install shieldauth
```

## Usage

```python
import shieldauth
shieldauth.verify("sk_live_xxxx")

# Your app code here — only runs if license is valid
print("Welcome!")
```

On first run, the user is prompted for their license key. It's saved locally so they're never asked again.

## Links

- Dashboard: https://shieldauth.pages.dev
- Docs: https://shieldauth.pages.dev/docs
