import hashlib
import socket
import uuid


def get() -> str:
    raw = f"{uuid.getnode()}:{socket.gethostname()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]
