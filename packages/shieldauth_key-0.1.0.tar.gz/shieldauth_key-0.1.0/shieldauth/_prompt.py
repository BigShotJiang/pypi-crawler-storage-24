def ask_for_key(app_name: str) -> str:
    """Prompt the user for a license key.
    Uses a tkinter GUI dialog if available (works inside compiled EXEs),
    falls back to terminal input.
    """
    try:
        import tkinter as tk
        from tkinter import simpledialog

        root = tk.Tk()
        root.withdraw()
        root.lift()
        root.attributes("-topmost", True)

        key = simpledialog.askstring(
            title=f"{app_name} — License",
            prompt=f"Enter your {app_name} license key:",
            parent=root,
        )
        root.destroy()

        if key is None:
            # User closed the dialog
            print("License key required. Exiting.")
            raise SystemExit(1)

        return key.strip()

    except ImportError:
        # tkinter not available — use terminal
        pass

    key = input(f"Enter your {app_name} license key: ").strip()
    if not key:
        print("License key required. Exiting.")
        raise SystemExit(1)
    return key
