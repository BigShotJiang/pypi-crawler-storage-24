from datetime import datetime, timezone, timedelta
from typing import Optional

import requests

from . import _hwid, _store, _prompt

API_BASE = "https://shieldauth.pages.dev/api/v1"
OFFLINE_GRACE_DAYS = 7


def _post(endpoint: str, payload: dict, timeout: int = 8) -> Optional[dict]:
    try:
        r = requests.post(f"{API_BASE}/{endpoint}", json=payload, timeout=timeout)
        return r.json()
    except Exception:
        return None


def verify(app_secret: str) -> None:
    hwid = _hwid.get()
    stored = _store.load(app_secret)

    # ── Case 1: No saved key — need to prompt ────────────────────────────────
    if not stored:
        # Fetch app_name first (key=None)
        res = _post("validate", {"app_secret": app_secret, "hwid": hwid})
        if res is None:
            print("Unable to reach ShieldAuth servers and no cached key found. Exiting.")
            raise SystemExit(1)

        app_name = res.get("app_name", "ShieldAuth")

        if "error" in res and res["error"] == "invalid_app_secret":
            # Developer misconfigured — show a generic error
            print("Invalid application configuration. Exiting.")
            raise SystemExit(1)

        key = _prompt.ask_for_key(app_name)
        _activate(app_secret, key, hwid, app_name)
        return

    # ── Case 2: Saved key — validate silently ────────────────────────────────
    key = stored["key"]
    app_name = stored.get("app_name", "ShieldAuth")

    res = _post("validate", {"app_secret": app_secret, "key": key, "hwid": hwid})

    if res is None:
        # Network error — allow offline grace period
        last_seen_str = stored.get("last_seen")
        if last_seen_str:
            last_seen = datetime.fromisoformat(last_seen_str)
            if datetime.now(timezone.utc) - last_seen < timedelta(days=OFFLINE_GRACE_DAYS):
                return  # within grace period, allow through
        print("Unable to verify license. Check your internet connection. Exiting.")
        raise SystemExit(1)

    if res.get("valid"):
        # Update last_seen in local store
        _store.save(app_secret, {
            **stored,
            "last_seen": datetime.now(timezone.utc).isoformat(),
        })
        return

    error = res.get("error", "")

    if error == "hwid_mismatch":
        print(
            f"\n[{app_name}] This license key is registered to a different device.\n"
            "To transfer it, visit: https://shieldauth.pages.dev/reset\n"
        )
        raise SystemExit(1)

    if error in ("paused", "banned"):
        print(f"\n[{app_name}] Your license has been {error}. Contact support.")
        raise SystemExit(1)

    if error == "expired":
        print(f"\n[{app_name}] Your license has expired. Please renew.")
        raise SystemExit(1)

    # Key no longer valid — clear cache and re-prompt
    _store.clear(app_secret)
    print(f"\n[{app_name}] License key is no longer valid.")
    key = _prompt.ask_for_key(app_name)
    _activate(app_secret, key, hwid, app_name)


def _activate(app_secret: str, key: str, hwid: str, app_name: str) -> None:
    res = _post("validate", {"app_secret": app_secret, "key": key, "hwid": hwid})

    if res is None:
        print("Unable to reach ShieldAuth servers. Exiting.")
        raise SystemExit(1)

    if res.get("valid"):
        _store.save(app_secret, {
            "key": key,
            "app_name": res.get("app_name", app_name),
            "last_seen": datetime.now(timezone.utc).isoformat(),
        })
        return

    error = res.get("error", "")
    app_name = res.get("app_name", app_name)

    if error == "hwid_mismatch":
        print(
            f"\n[{app_name}] This key is already activated on another device.\n"
            "Visit https://shieldauth.pages.dev/reset to transfer it.\n"
        )
    elif error == "key_not_found":
        print(f"\n[{app_name}] Invalid license key. Please check and try again.")
    elif error in ("paused", "banned"):
        print(f"\n[{app_name}] This license key has been {error}.")
    elif error == "expired":
        print(f"\n[{app_name}] This license key has expired.")
    else:
        print(f"\n[{app_name}] License verification failed: {error}")

    raise SystemExit(1)
