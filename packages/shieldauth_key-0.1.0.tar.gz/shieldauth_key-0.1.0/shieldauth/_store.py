import json
import os
from pathlib import Path
from typing import Optional


def _path() -> Path:
    return Path.home() / ".shieldauth" / "keys.json"


def load(app_secret: str) -> Optional[dict]:
    p = _path()
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text())
        return data.get(app_secret)
    except Exception:
        return None


def save(app_secret: str, entry: dict) -> None:
    p = _path()
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        data = json.loads(p.read_text()) if p.exists() else {}
    except Exception:
        data = {}
    data[app_secret] = entry
    p.write_text(json.dumps(data, indent=2))


def clear(app_secret: str) -> None:
    p = _path()
    if not p.exists():
        return
    try:
        data = json.loads(p.read_text())
        data.pop(app_secret, None)
        p.write_text(json.dumps(data, indent=2))
    except Exception:
        pass
