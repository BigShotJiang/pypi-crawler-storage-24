"""Authentication configuration for jvspatial API.

This module provides authentication configuration models for the jvspatial API,
including JWT, API key, and session-based authentication settings.
"""

from typing import Dict, List

from pydantic import BaseModel, Field

_DEFAULT_ROLE_MAPPING: Dict[str, List[str]] = {"admin": ["*"], "user": []}


class AuthConfig(BaseModel):
    """Authentication configuration model.

    Attributes:
        enabled: Enable authentication middleware
        exempt_paths: List of paths exempt from authentication
        jwt_secret: JWT secret key
        jwt_algorithm: JWT algorithm
        jwt_expire_minutes: JWT expiration time in minutes
        api_key_header: Header name for API key authentication
        session_cookie_name: Cookie name for session authentication
        session_expire_minutes: Session expiration time in minutes
    """

    # General Authentication Settings
    enabled: bool = True
    exempt_paths: List[str] = Field(
        default_factory=lambda: [
            "/health",
            "/docs",
            "/redoc",
            "/openapi.json",
            "/favicon.ico",
            "/api/auth/register",
            "/api/auth/login",
            "/api/auth/refresh",
        ]
    )

    # JWT Configuration
    jwt_secret: str = Field(default="your-secret-key", description="JWT secret key")
    jwt_algorithm: str = Field(default="HS256", description="JWT algorithm")
    jwt_expire_minutes: int = Field(
        default=30, description="JWT expiration time in minutes"
    )
    refresh_expire_days: int = Field(
        default=7, description="Refresh token expiration time in days"
    )
    refresh_token_rotation: bool = Field(
        default=False, description="Enable refresh token rotation on refresh"
    )
    blacklist_cache_ttl_seconds: int = Field(
        default=3600, description="Cache TTL for blacklist checks in seconds"
    )

    # API Key Configuration
    api_key_header: str = Field(
        default="x-api-key", description="Header name for API key"
    )
    api_key_management_enabled: bool = Field(
        default=True,
        description="Enable API key management endpoints (/auth/api-keys). "
        "Does not affect API key authentication availability.",
    )

    # Session Configuration
    session_cookie_name: str = Field(
        default="session", description="Session cookie name"
    )
    session_expire_minutes: int = Field(
        default=60, description="Session expiration time in minutes"
    )

    # Rate Limiting Configuration
    rate_limit_enabled: bool = Field(default=False, description="Enable rate limiting")
    rate_limit_requests_per_minute: int = Field(
        default=60, description="Requests per minute limit"
    )

    # Brute Force Protection
    brute_force_protection_enabled: bool = Field(
        default=False, description="Enable brute force protection"
    )
    max_login_attempts: int = Field(
        default=5, description="Maximum login attempts before lockout"
    )
    lockout_duration_minutes: int = Field(
        default=15, description="Lockout duration in minutes"
    )

    # RBAC Configuration
    rbac_enabled: bool = Field(
        default=True,
        description="Enable role and permission enforcement",
    )
    default_role: str = Field(
        default="user",
        description="Role for new users (non-bootstrap)",
    )
    admin_role: str = Field(
        default="admin",
        description="Role name for bootstrap and admin-only checks",
    )
    registration_open: bool = Field(
        default=True,
        description="When False, disable public register even when no users",
    )
    role_permission_mapping: Dict[str, List[str]] = Field(
        default_factory=lambda: dict(_DEFAULT_ROLE_MAPPING),
        description="Maps each role to its permissions. Use '*' for admin-all.",
    )


__all__ = ["AuthConfig"]
