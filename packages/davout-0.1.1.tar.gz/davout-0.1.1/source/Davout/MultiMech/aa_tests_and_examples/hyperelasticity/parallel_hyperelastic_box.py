# Routine to test a hyperelastic disc

from .....Davout.PythonicUtilities.path_tools import get_parent_path_of_file

from .....Davout.MultiMech.constitutive_models.hyperelasticity import isotropic_hyperelasticity as constitutive_models

from .....Davout.MultiMech.physics import hyperelastic_cauchy_continuum as variational_framework

########################################################################
########################################################################
##                      User defined parameters                       ##
########################################################################
########################################################################

########################################################################
#                          Simulation results                          #
########################################################################

# Defines the path to the results directory 

results_path = get_parent_path_of_file() #os.getcwd()+"//aa_tests//hyperelasticity//results"

displacement_fileName = "displacement_parallel.xdmf"

post_processes = dict()

post_processes["SaveField"] = {"directory path": results_path, "file n"+
"ame": displacement_fileName}

post_processes["SaveMeshVolumeRatioToReferenceVolume"] = {"directory p"+
"ath": results_path, "file name": "volume_ratio.txt"}

post_processes["SaveCauchyStressField"] = {"directory path":results_path,
"file name": "cauchy_stress_field.xdmf", "polynomial degree":1}

post_processes["SaveFirstPiolaStressField"] = {"directory path":
results_path, "file name": "first_piola_stress_field.xdmf", "polynomial deg"+
"ree":1}

post_processes["SaveReferentialTractionField"] = {"directory path":
results_path, "file name": "referential_traction.xdmf", "polynomial deg"+
"ree":1}

post_processes["SavePressureAtPoint"] = {"directory path": results_path, 
"file name": "pressure_point", "polynomial degree":1, "poin"+
"t coordinates": [0.15, 0.1, 5.0]}

post_processes["HomogenizeField"] = {"directory path": results_path, 
"file name": "homogenized_displacement.txt", "subdomain": "volume 1"}

post_processes["HomogenizeFieldsGradient"] = {"directory path": results_path, 
"file name": "homogenized_displacement_gradient.txt", "subdomain": "volume 1"}

post_processes["HomogenizeFirstPiola"] = {"directory path": results_path, 
"file name": "homogenized_first_piola.txt", "subdomain": "volume 1"}

post_processes["HomogenizeCauchy"] = {"directory path": results_path, 
"file name": "homogenized_cauchy.txt", "subdomain": "volume 1"}

########################################################################
#                         Material properties                          #
########################################################################

# Sets the Young modulus and the Poisson ratio

E = 1E6

poisson = 0.3

# Sets a dictionary of properties

material_properties = dict()

material_properties["E"] = E

material_properties["nu"] = poisson

# Sets the material as a neo-hookean material using the corresponding
# class

constitutive_model = constitutive_models.NeoHookean(material_properties)

########################################################################
#                                 Mesh                                 #
########################################################################

# Defines the name of the file to save the mesh in. Do not write the fi-
# le termination, e.g. .msh or .xdmf; both options will be saved automa-
# tically

mesh_fileName = {"length x": 0.3, "length y": 0.2, "length z": 1.0, "n"+
"umber of divisions in x": 5, "number of divisions in y": 5, "number o"+
"f divisions in z": 25, "verbose": False, "mesh file name": "box_mesh", 
"mesh file directory": get_parent_path_of_file()}

########################################################################
#                            Function space                            #
########################################################################

# Defines the shape functions degree

polynomial_degree = 2

########################################################################
#                           Solver parameters                          #
########################################################################

# Sets the solver parameters in a dictionary

solver_parameters = dict()

solver_parameters["newton_relative_tolerance"] = 1e-4

solver_parameters["newton_absolute_tolerance"] = 1e-4

solver_parameters["newton_maximum_iterations"] = 15

# Sets the initial time

t = 0.0

# Sets the final pseudotime of the simulation

t_final = 1.0

# Sets the maximum number of steps of loading

maximum_loadingSteps = 5

########################################################################
#                          Boundary conditions                         #
########################################################################

# Defines a load expression

maximum_load = 5E5

# Assemble the traction vector using this load expression

traction_boundary = {"load case": "UniformReferentialTraction", "ampli"+
"tude_tractionX": 0.0, "amplitude_tractionY": 0.0, "amplitude_tractionZ": 
maximum_load, "parametric_load_curve": "square_root", "t": t, "t_final":
t_final}

# Defines a dictionary of tractions

traction_dictionary = dict()

traction_dictionary["top"] = traction_boundary

# Defines a dictionary of boundary conditions. Each key is a physical
# group and each value is another dictionary or a list of dictionaries 
# with the boundary conditions' information. Each of these dictionaries
# must have the key "BC case", which carries the name of the function 
# that builds this boundary condition

bcs_dictionary = dict()

bcs_dictionary["bottom"] = {"BC case": "FixedSupportDirichletBC"}

########################################################################
########################################################################
##                      Calculation and solution                      ##
########################################################################
########################################################################

# Solves the variational problem

variational_framework.hyperelasticity_displacementBased(
constitutive_model, traction_dictionary, maximum_loadingSteps, t_final, 
post_processes, mesh_fileName, solver_parameters, polynomial_degree=
polynomial_degree, t=t, dirichlet_boundaryConditions=bcs_dictionary, 
verbose=True, run_in_parallel=True)