# SSH MCP Server

一个带 GUI 配置面板的 SSH MCP Server，支持多服务器管理，一键安装到主流 AI IDE。

## 功能

- **多服务器管理** - 可配置多个 SSH 服务器连接
- **认证方式** - 支持密码认证和密钥对认证
- **GUI 配置面板** - `sshgui` 一键启动，可视化管理服务器
- **一键安装** - GUI 内置安装到 Windsurf / Cursor / Claude Code / Codex
- **MCP 协议** - 通过 stdio 提供 MCP 工具，供 AI 助手调用
- **并发更稳** - 长命令不会再阻塞其他 MCP 工具调用
- **真实超时** - `exec_command.timeout` 现在按命令执行总时长生效

## 安装

```bash
# pip 安装（推荐）
pip install sshmcp-r

# 或 uv 安装
uv pip install sshmcp-r
```

安装后即可使用 `sshmcp` 命令。

## 命令一览

| 命令 | 说明 |
|------|------|
| `sshmcp` | 以 MCP Server 模式运行（IDE 自动调用） |
| `sshgui` | 启动 GUI 配置面板 |
| `sshmcp-install` | 一键安装到所有 IDE |
| `sshmcp-install-windsurf` | 安装到 Windsurf |
| `sshmcp-install-cursor` | 安装到 Cursor |
| `sshmcp-install-claudecode` | 安装到 Claude Code |
| `sshmcp-install-codex` | 安装到 Codex |

## 快速开始

```bash
# 1. 安装
pip install sshmcp-r

# 2. 一键安装到你的 IDE（自动写入 MCP 配置）
sshmcp-install-windsurf   # 或 cursor / claudecode / codex
sshmcp-install            # 安装到全部 IDE

# 3. 打开 GUI 管理 SSH 服务器
sshgui

# 4. 重启 IDE，即可在 AI 对话中使用 SSH 工具
```

## 一键安装到 IDE

**命令行方式：**

```bash
sshmcp-install              # 安装到所有 IDE
sshmcp-install-windsurf     # 仅安装到 Windsurf
sshmcp-install-cursor       # 仅安装到 Cursor
sshmcp-install-claudecode   # 仅安装到 Claude Code
sshmcp-install-codex        # 仅安装到 Codex
```

**GUI 方式：** 运行 `sshgui`，点击工具栏 **「安装到 IDE ▾」** 按钮，选择目标 IDE。

安装会自动写入 MCP 配置到对应文件：

- **Windsurf** → `~/.codeium/windsurf/mcp_config.json`
- **Cursor** → `~/.cursor/mcp.json`
- **Claude Code** → `~/.claude.json`
- **Codex** → `~/.codex/config.toml`

## MCP Tools

| Tool | 说明 |
|------|------|
| `list_servers` | 列出所有已配置的服务器 |
| `connect` | 连接到指定服务器 |
| `disconnect` | 断开当前连接 |
| `get_status` | 获取当前连接状态 |
| `exec_command` | 在远程服务器执行命令 |
| `upload_file` | 上传文件到远程服务器 |
| `download_file` | 从远程服务器下载文件 |
| `write_remote_file` | 将文本内容写入远程文件 |
| `read_remote_file` | 读取远程文件内容 |
| `list_remote_dir` | 列出远程目录内容 |

## 手动配置

也可手动添加到 IDE 的 MCP 配置文件：

```json
{
  "mcpServers": {
    "ssh": {
      "command": "sshmcp"
    }
  }
}
```

## 打包为 exe

```bash
pip install pyinstaller
pyinstaller build.spec
```
