from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv


@dataclass(frozen=True)
class Settings:
    ollama_host: str
    model: str
    vlm_model: str
    enable_ocr: bool
    enable_vlm: bool
    max_preview_chars: int
    max_reasoning_steps: int = 3


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def load_settings() -> Settings:
    load_dotenv()

    host = os.getenv("OLLAMA_HOST", "http://localhost:11434").strip()
    model = os.getenv("OLLAMA_MODEL", "llama3.1").strip()
    vlm_model = os.getenv("OLLAMA_VLM_MODEL", "llava").strip()
    enable_ocr = _env_bool("ENABLE_OCR", True)
    enable_vlm = _env_bool("ENABLE_VLM", True)
    max_preview_chars = int(os.getenv("MAX_PREVIEW_CHARS", "1200"))

    if not model:
        raise RuntimeError("OLLAMA_MODEL is not set. Update your .env file.")

    return Settings(
        ollama_host=host,
        model=model,
        vlm_model=vlm_model,
        enable_ocr=enable_ocr,
        enable_vlm=enable_vlm,
        max_preview_chars=max_preview_chars,
    )
