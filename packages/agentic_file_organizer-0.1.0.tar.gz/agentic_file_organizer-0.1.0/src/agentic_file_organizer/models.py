from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class FileDescription:
    """Result of the DESCRIBE phase for a single file."""
    source_rel: str
    original_path: Path
    description: str
    suggested_category: str
    suggested_name: str


@dataclass(frozen=True)
class OrganizeDecision:
    original_path: Path
    category_folder: str
    new_name: str
