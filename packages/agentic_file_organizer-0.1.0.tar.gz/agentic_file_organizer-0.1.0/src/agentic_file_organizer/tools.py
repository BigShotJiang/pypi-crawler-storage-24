from __future__ import annotations

import re
from pathlib import Path


def _sanitize_segment(value: str, fallback: str) -> str:
    cleaned = re.sub(r"[\\/:*?\"<>|]+", "_", value).strip()
    return cleaned or fallback


def _ensure_within_root(path: Path, root_path: Path) -> None:
    try:
        path.resolve().relative_to(root_path.resolve())
    except ValueError as exc:
        raise ValueError(f"Path '{path}' is outside of allowed root '{root_path}'.") from exc


def _dedupe_target(target_path: Path) -> Path:
    if not target_path.exists():
        return target_path

    stem = target_path.stem
    suffix = target_path.suffix
    parent = target_path.parent

    idx = 1
    while True:
        candidate = parent / f"{stem}_{idx}{suffix}"
        if not candidate.exists():
            return candidate
        idx += 1


def organize_file(original_path: Path, root_path: Path, category_folder: str, new_name: str) -> Path:
    """Move a file into root/category_folder with a descriptive name.

    Safety constraints:
    - Move only (no delete).
    - Source and destination must stay under selected root_path.
    - Existing target names are not overwritten.
    """
    original_path = original_path.resolve()
    root_path = root_path.resolve()

    _ensure_within_root(original_path, root_path)

    safe_category = _sanitize_segment(category_folder, fallback="Uncategorized")
    safe_name = _sanitize_segment(new_name, fallback=original_path.stem)

    original_suffix = original_path.suffix
    proposed_name = Path(safe_name)
    if not proposed_name.suffix and original_suffix:
        safe_name = f"{safe_name}{original_suffix}"

    target_dir = root_path / safe_category
    target_dir.mkdir(parents=True, exist_ok=True)

    target_path = _dedupe_target(target_dir / safe_name)
    _ensure_within_root(target_path, root_path)

    # Move operation only.
    original_path.rename(target_path)
    return target_path
