from __future__ import annotations

import json
from pathlib import Path
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from ollama import Client  # pyright: ignore[reportMissingImports]

from .config import Settings
from .file_tools import build_file_analysis_context
from .models import FileDescription, OrganizeDecision
from .tools import organize_file


class FileAgent:
    def __init__(self, settings: Settings, user_preferences: str = ""):
        self.settings = settings
        self.user_preferences = user_preferences

        try:
            from ollama import Client as OllamaClient  # pyright: ignore[reportMissingImports]
        except ImportError as exc:
            raise RuntimeError(
                "The 'ollama' package is not installed. Run 'pip install -e .' first."
            ) from exc
        self.client = OllamaClient(host=settings.ollama_host)

        try:
            import chromadb  # pyright: ignore[reportMissingImports]
            self._chroma = chromadb.Client()
        except ImportError as exc:
            raise RuntimeError(
                "The 'chromadb' package is not installed. Run 'pip install -e .' first."
            ) from exc

    # ------------------------------------------------------------------ #
    #  Helpers                                                             #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _stage(stage: str, message: str) -> None:
        print(f"[AGENT:{stage}] {message}")

    def _as_dict(self, value: Any) -> dict[str, Any]:
        if isinstance(value, dict):
            return value
        if hasattr(value, "model_dump"):
            dumped = value.model_dump()
            if isinstance(dumped, dict):
                return dumped
        return {}

    def _parse_args(self, raw: Any) -> dict[str, Any]:
        if isinstance(raw, str):
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                pass
            return {}
        if isinstance(raw, dict):
            return raw
        return {}

    @staticmethod
    def _normalized_name(file_path: Path, suggested_name: str) -> str:
        """Keep original extension to avoid accidental type-changing renames."""
        original_suffix = file_path.suffix
        if not original_suffix:
            return suggested_name or file_path.name

        candidate = Path(suggested_name)
        if not candidate.suffix:
            return f"{suggested_name}{original_suffix}"
        if candidate.suffix.lower() != original_suffix.lower():
            return f"{candidate.stem}{original_suffix}"
        return suggested_name

    @staticmethod
    def _file_family(file_path: Path) -> str:
        suffix = file_path.suffix.lower()
        if suffix in {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff", ".gif", ".svg"}:
            return "image"
        if suffix in {".py", ".js", ".ts", ".java", ".cpp", ".c", ".h", ".hpp", ".go", ".rs", ".cs", ".php", ".rb", ".kt", ".swift"}:
            return "code"
        if suffix in {".pdf", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".txt", ".md", ".rtf"}:
            return "document"
        if suffix in {".json", ".csv", ".xml", ".yaml", ".yml", ".toml", ".ini", ".log"}:
            return "data"
        if suffix in {".zip", ".rar", ".7z", ".tar", ".gz"}:
            return "archive"
        if suffix in {".exe", ".elf", ".bin", ".out"}:
            return "binary"
        return "other"

    def _plan_folder_schema(self, descriptions: list[FileDescription], user_preferences: str = "") -> list[str]:
        """Ask the LLM to create a compact folder schema for the whole dataset."""
        if not descriptions:
            return ["Uncategorized"]

        catalog = [
            {
                "source_rel": d.source_rel,
                "file_name": d.original_path.name,
                "description": d.description,
                "suggested_category": d.suggested_category,
            }
            for d in descriptions
        ]

        preferences_instruction = (
            f"\n\nIMPORTANT – The user has specified the following requirement: \"{user_preferences}\". "
            "You MUST derive the exact folder names from this requirement and return ONLY those folders. "
            "Do NOT add any extra folders beyond what the user asked for."
            if user_preferences else ""
        )

        response = self.client.chat(
            model=self.settings.model,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a file-organization planner. "
                        "Given a file catalog, propose a compact and coherent folder schema. "
                        "Merge near-duplicate labels. Avoid too many folders. "
                        "If the user specifies exact folder names or a limited set, "
                        "return ONLY those folders and nothing else. "
                        "Return JSON only: {\"folders\": [\"...\"]}." 
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"File catalog JSON:\n{json.dumps(catalog, ensure_ascii=False)}\n\n"
                        f"Return the folder names in key 'folders'.{preferences_instruction}"
                    ),
                },
            ],
            options={"temperature": 0.0},
        )

        message = self._as_dict(self._as_dict(response).get("message", {}))
        content = message.get("content", "")
        if isinstance(content, list):
            content = "\n".join(str(part) for part in content)

        try:
            parsed = json.loads(str(content))
            folders_raw = parsed.get("folders", [])
            folders = [str(v).strip() for v in folders_raw if str(v).strip()]
            unique: list[str] = []
            for folder in folders:
                if folder not in unique:
                    unique.append(folder)
            if unique:
                return unique
        except Exception:
            pass

        # Fallback: top suggested categories by frequency.
        counts: dict[str, int] = {}
        for d in descriptions:
            cat = d.suggested_category.strip() or "Uncategorized"
            counts[cat] = counts.get(cat, 0) + 1
        ranked = sorted(counts.items(), key=lambda item: item[1], reverse=True)
        return [cat for cat, _ in ranked[:8]] or ["Uncategorized"]

    def _assign_files_to_schema(
        self,
        descriptions: list[FileDescription],
        folders: list[str],
        neighbour_hints: dict[str, list[str]],
        user_preferences: str = "",
    ) -> dict[str, str]:
        """Assign every file to one of the planned folders in one LLM call."""
        if not descriptions:
            return {}

        payload = [
            {
                "source_rel": d.source_rel,
                "file_name": d.original_path.name,
                "description": d.description,
                "suggested_category": d.suggested_category,
                "similar_files": neighbour_hints.get(d.source_rel, []),
            }
            for d in descriptions
        ]

        preferences_note = (
            f" The user requirement is: \"{user_preferences}\". Respect it strictly when assigning."
            if user_preferences else ""
        )

        response = self.client.chat(
            model=self.settings.model,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a file-organization planner. "
                        "Assign each file to exactly one folder from the provided schema. "
                        "You may ONLY use folders from the allowed list — never invent new ones. "
                        "Use file description and similar-file hints to keep similar files together. "
                        f"Return JSON only in this shape: "
                        "{\"assignments\": [{\"source_rel\": \"...\", \"folder\": \"...\"}]}"
                        f"{preferences_note}"
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Allowed folders: {json.dumps(folders, ensure_ascii=False)}\n\n"
                        f"Files JSON:\n{json.dumps(payload, ensure_ascii=False)}"
                    ),
                },
            ],
            options={"temperature": 0.0},
        )

        message = self._as_dict(self._as_dict(response).get("message", {}))
        content = message.get("content", "")
        if isinstance(content, list):
            content = "\n".join(str(part) for part in content)

        try:
            parsed = json.loads(str(content))
            rows = parsed.get("assignments", [])
            out: dict[str, str] = {}
            for row in rows:
                if not isinstance(row, dict):
                    continue
                source_rel = str(row.get("source_rel", "")).strip()
                folder = str(row.get("folder", "")).strip()
                if not source_rel:
                    continue
                if folder not in folders:
                    continue
                out[source_rel] = folder
            return out
        except Exception:
            return {}

    # ------------------------------------------------------------------ #
    #  Tool specs                                                          #
    # ------------------------------------------------------------------ #

    def _describe_tool_spec(self) -> list[dict[str, Any]]:
        return [
            {
                "type": "function",
                "function": {
                    "name": "describe_file",
                    "description": (
                        "Describe the file: what it is, what it contains, "
                        "and suggest an organisation category and a descriptive filename."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "description": {
                                "type": "string",
                                "description": (
                                    "1-2 sentence description of the file content and purpose."
                                ),
                            },
                            "suggested_category": {
                                "type": "string",
                                "description": (
                                    "Category folder name, e.g. 'Python Scripts', "
                                    "'Finance Documents', 'Config Files'."
                                ),
                            },
                            "suggested_name": {
                                "type": "string",
                                "description": "Descriptive filename including extension.",
                            },
                        },
                        "required": ["description", "suggested_category", "suggested_name"],
                        "additionalProperties": False,
                    },
                },
            }
        ]

    # ------------------------------------------------------------------ #
    #  Phase 1 - DESCRIBE                                                  #
    # ------------------------------------------------------------------ #

    def describe_file(self, file_path: Path, root_path: Path) -> FileDescription:
        """Use the LLM to produce a rich description of a single file."""
        self._stage("DESCRIBE", f"Analyzing '{file_path.name}'")

        source_rel = file_path.relative_to(root_path).as_posix()
        analysis = build_file_analysis_context(
            file_path=file_path,
            max_chars=self.settings.max_preview_chars,
            enable_ocr=self.settings.enable_ocr,
            enable_vlm=self.settings.enable_vlm,
            vlm_model=self.settings.vlm_model,
            client=self.client,
        )
        preview = analysis.get("content_preview", "")
        ocr_preview = analysis.get("ocr_preview", "")
        vlm_description = analysis.get("vlm_description", "")

        messages: list[dict[str, Any]] = [
            {
                "role": "system",
                "content": (
                    "You are a file-analysis agent. "
                    "Analyze the file and call describe_file with a short description, "
                    "a category folder name, and a descriptive new filename."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Analyze this file:\n"
                    f"filename: {file_path.name}\n"
                    f"suffix: {file_path.suffix or '(none)'}\n"
                    f"content_preview: {preview!r}\n"
                    f"ocr_preview: {ocr_preview!r}\n"
                    f"vlm_description: {vlm_description!r}\n"
                    + (f"\nUser preferences: {self.user_preferences}\n" if self.user_preferences else "")
                    + "\nCall describe_file(description, suggested_category, suggested_name)."
                ),
            },
        ]

        for attempt in range(1, self.settings.max_reasoning_steps + 1):
            response = self.client.chat(
                model=self.settings.model,
                messages=messages,
                tools=self._describe_tool_spec(),
                options={"temperature": 0.1},
            )
            msg = self._as_dict(self._as_dict(response).get("message", {}))
            tool_calls = msg.get("tool_calls") or []

            if not tool_calls:
                self._stage("DESCRIBE", f"  No tool call (attempt {attempt}), retrying...")
                messages.append({"role": "user", "content": "You must call describe_file."})
                continue

            call = self._as_dict(tool_calls[0])
            fn = self._as_dict(call.get("function", {}))
            if fn.get("name") != "describe_file":
                messages.append({"role": "user", "content": "Only call describe_file."})
                continue

            args = self._parse_args(fn.get("arguments", {}))
            description = str(args.get("description", "")).strip() or f"File: {file_path.name}"
            category = str(args.get("suggested_category", "")).strip() or "Uncategorized"

            suggested_name = str(args.get("suggested_name", "")).strip() or file_path.name
            name = self._normalized_name(file_path, suggested_name)

            self._stage("DESCRIBE", f"  -> category='{category}'  name='{name}'")
            self._stage("DESCRIBE", f"  -> description: {description}")
            return FileDescription(
                source_rel=source_rel,
                original_path=file_path,
                description=description,
                suggested_category=category,
                suggested_name=name,
            )

        # Graceful fallback - never skip a file
        self._stage("DESCRIBE", f"  Fallback: using filename as description for '{file_path.name}'")
        return FileDescription(
            source_rel=source_rel,
            original_path=file_path,
            description=f"File named {file_path.name}",
            suggested_category="Uncategorized",
            suggested_name=file_path.name,
        )

    # ------------------------------------------------------------------ #
    #  Phase 2 - INDEX                                                     #
    # ------------------------------------------------------------------ #

    def build_vector_index(self, descriptions: list[FileDescription]) -> Any:
        """Embed every file description into an in-memory ChromaDB collection."""
        self._stage(
            "INDEX",
            f"Embedding {len(descriptions)} description(s) into vector DB...",
        )

        # Start fresh each run
        try:
            self._chroma.delete_collection("files_session")
        except Exception:
            pass

        collection = self._chroma.create_collection("files_session")

        collection.add(
            documents=[d.description for d in descriptions],
            ids=[d.source_rel.replace("/", "__SEP__") for d in descriptions],
            metadatas=[
                {
                    "source_rel": d.source_rel,
                    "suggested_category": d.suggested_category,
                    "suggested_name": d.suggested_name,
                }
                for d in descriptions
            ],
        )

        self._stage("INDEX", "Vector index built - all descriptions are embedded and stored.")
        return collection

    # ------------------------------------------------------------------ #
    #  Phase 3 - PLAN                                                      #
    # ------------------------------------------------------------------ #

    def plan_from_index(
        self,
        descriptions: list[FileDescription],
        collection: Any,
    ) -> list[OrganizeDecision]:
        """
        Create a folder schema from all descriptions using the LLM, then assign
        each file into one schema folder using LLM + vector-neighbour hints.
        """
        self._stage(
            "PLAN",
            f"Planning folders and assignments for {len(descriptions)} file(s)",
        )
        by_source = {d.source_rel: d for d in descriptions}
        by_family: dict[str, list[FileDescription]] = {}
        for d in descriptions:
            fam = self._file_family(d.original_path)
            by_family.setdefault(fam, []).append(d)

        assignments: dict[str, str] = {}
        family_folders: dict[str, list[str]] = {}

        n_results = min(5, len(descriptions))
        all_neighbour_hints: dict[str, list[str]] = {}
        for desc in descriptions:
            results = collection.query(
                query_texts=[desc.description],
                n_results=n_results,
                include=["metadatas"],
            )
            similar_metas: list[dict[str, Any]] = results["metadatas"][0]
            current_family = self._file_family(desc.original_path)
            hint_sources: list[str] = []
            for meta in similar_metas:
                source_rel = str(meta.get("source_rel", "")).strip()
                if not source_rel or source_rel == desc.source_rel or source_rel not in by_source:
                    continue
                if self._file_family(by_source[source_rel].original_path) != current_family:
                    continue
                hint_sources.append(source_rel)
            all_neighbour_hints[desc.source_rel] = hint_sources[:3]

        for family, group in by_family.items():
            folders = self._plan_folder_schema(group, user_preferences=self.user_preferences)
            family_folders[family] = folders
            self._stage(
                "PLAN",
                f"Family '{family}' schema: {', '.join(repr(folder) for folder in folders)}",
            )
            group_hints = {d.source_rel: all_neighbour_hints.get(d.source_rel, []) for d in group}
            group_assignments = self._assign_files_to_schema(
                group, folders, group_hints, user_preferences=self.user_preferences
            )
            assignments.update(group_assignments)

        decisions: list[OrganizeDecision] = []
        for desc in descriptions:
            family = self._file_family(desc.original_path)
            allowed = family_folders.get(family, ["Uncategorized"])
            final_category = assignments.get(desc.source_rel, desc.suggested_category)
            if final_category not in allowed:
                final_category = allowed[0] if allowed else "Uncategorized"

            neighbours = ", ".join(repr(x) for x in all_neighbour_hints.get(desc.source_rel, []))
            self._stage(
                "PLAN",
                f"  '{desc.original_path.name}' -> folder='{final_category}' (similar: {neighbours})",
            )

            decisions.append(
                OrganizeDecision(
                    original_path=desc.original_path,
                    category_folder=final_category,
                    new_name=desc.suggested_name,
                )
            )

        return decisions

    # ------------------------------------------------------------------ #
    #  Phase 4 - EXECUTE                                                   #
    # ------------------------------------------------------------------ #

    def execute_decision(self, decision: OrganizeDecision, root_path: Path) -> Path:
        self._stage(
            "ACTION",
            f"Moving '{decision.original_path.name}'"
            f" -> {decision.category_folder}/{decision.new_name}",
        )
        new_path = organize_file(
            original_path=decision.original_path,
            root_path=root_path,
            category_folder=decision.category_folder,
            new_name=decision.new_name,
        )
        self._stage("RESULT", f"Moved to '{new_path.relative_to(root_path)}'")
        return new_path
