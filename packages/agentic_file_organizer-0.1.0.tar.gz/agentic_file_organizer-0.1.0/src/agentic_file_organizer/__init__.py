"""Agentic file organizer package."""
