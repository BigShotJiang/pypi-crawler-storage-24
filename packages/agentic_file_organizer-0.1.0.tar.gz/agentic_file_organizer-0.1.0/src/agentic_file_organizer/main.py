from __future__ import annotations

import argparse
import platform
import shutil
import sys
from pathlib import Path
from typing import TYPE_CHECKING

from .agent import FileAgent
from .config import load_settings
from .models import OrganizeDecision

if TYPE_CHECKING:
    from ollama import Client  # pyright: ignore[reportMissingImports]


def _list_files(root_path: Path) -> list[Path]:
    return [p for p in root_path.rglob("*") if p.is_file()]


def _create_ollama_client(host: str) -> "Client":
    try:
        from ollama import Client as OllamaClient  # pyright: ignore[reportMissingImports]
    except ImportError as exc:
        raise RuntimeError(
            "The 'ollama' package is not installed. Run 'pip install -e .' first."
        ) from exc

    return OllamaClient(host=host)


def _installed_models(client: "Client") -> set[str]:
    response = client.list()
    models = getattr(response, "models", [])
    out: set[str] = set()
    for item in models:
        model_name = str(getattr(item, "model", "") or "").strip()
        if model_name:
            out.add(model_name)
    return out


def _required_models() -> list[str]:
    settings = load_settings()
    required = [settings.model]
    if settings.enable_vlm:
        required.append(settings.vlm_model)
    return required


def _ollama_install_hint() -> str:
    system = platform.system().lower()
    if system == "linux":
        return "Install Ollama from https://ollama.com/download/linux, then start the service and rerun 'organize-files init'."
    if system == "darwin":
        return "Install Ollama from https://ollama.com/download/mac, launch the app once, then rerun 'organize-files init'."
    if system == "windows":
        return "Install Ollama from https://ollama.com/download/windows, start it, then rerun 'organize-files init'."
    return "Install Ollama from https://ollama.com/download and rerun 'organize-files init'."


def run_init(*, pull_models: bool) -> int:
    print("--- CLI Setup ---")
    settings = load_settings()

    ollama_path = shutil.which("ollama")
    if not ollama_path:
        print("[FAIL] Ollama executable was not found in PATH.")
        print(_ollama_install_hint())
        return 1

    print(f"[OK] Found Ollama executable: {ollama_path}")

    try:
        client = _create_ollama_client(settings.ollama_host)
        installed = _installed_models(client)
    except Exception as exc:
        print(f"[FAIL] Ollama is installed but not reachable at {settings.ollama_host}: {exc}")
        print("Start Ollama, then rerun 'organize-files init'.")
        return 1

    print(f"[OK] Ollama is reachable at {settings.ollama_host}")

    missing = [model for model in _required_models() if model not in installed]
    if not missing:
        print("[OK] Required model(s) are already installed.")
        print("You can now run 'organize-files' or 'organize-files organize <folder>'.")
        return 0

    print("[WARN] Missing required model(s):")
    for model in missing:
        print(f"  - {model}")

    if not pull_models:
        print("Run 'organize-files init --pull-models' or 'organize-files setup-models' to download them.")
        return 1

    print("Pulling missing model(s)...")
    for model in missing:
        print(f"  -> pulling '{model}'")
        try:
            client.pull(model=model, stream=False)
            print(f"     done: {model}")
        except Exception as exc:
            print(f"     failed: {model} ({exc})")
            return 1

    print("Setup complete. You can now run 'organize-files'.")
    return 0


def run_organize(
    *,
    root_path: Path,
    user_preferences: str,
    verify: bool,
    dry_run: bool,
    auto_confirm: bool,
) -> int:
    if not root_path.exists() or not root_path.is_dir():
        print("Invalid directory path. Exiting.")
        return 1

    settings = load_settings()
    agent = FileAgent(settings, user_preferences=user_preferences)

    files = _list_files(root_path)
    if not files:
        print("No files found in the selected folder.")
        return 0

    print(f"\nFound {len(files)} file(s).")

    print("\n--- Phase 1: Describing files (one by one) ---")
    descriptions = []
    for file_path in files:
        try:
            desc = agent.describe_file(file_path, root_path)
            descriptions.append(desc)
        except Exception as exc:
            print(f"  [WARN] Could not describe '{file_path.name}': {exc}")

    if not descriptions:
        print("No files could be described. Exiting.")
        return 1

    print("\n--- Phase 2: Building vector index ---")
    collection = agent.build_vector_index(descriptions)

    print("\n--- Phase 3: Planning organisation via vector similarity ---")
    decisions = agent.plan_from_index(descriptions, collection)

    print("\nPlanned moves:")
    for decision in decisions:
        src_rel = decision.original_path.relative_to(root_path)
        dst_rel = Path(decision.category_folder) / decision.new_name
        print(f"  {src_rel} -> {dst_rel}")

    if dry_run:
        print("\nDry-run mode enabled. No files were moved.")
        return 0

    if not auto_confirm:
        answer = input("\nApply these moves? [y/N]: ").strip().lower()
        if answer not in {"y", "yes"}:
            print("Cancelled. No files were moved.")
            return 0

    print(f"\n--- Phase 4: Executing {len(decisions)} move(s) ---")
    for decision in decisions:
        try:
            source_rel = decision.original_path.relative_to(root_path)
            new_path = agent.execute_decision(decision, root_path)
            print(f"  Moved: {source_rel} -> {new_path.relative_to(root_path)}")
        except Exception as exc:
            print(f"  Skipped: {decision.original_path.name} ({exc})")

    if not verify:
        print("\nDone.")
        return 0

    print("\n--- Phase 5: Verifying and rectifying organization ---")
    current_files = _list_files(root_path)
    if current_files:
        descriptions_2 = []
        for file_path in current_files:
            try:
                desc = agent.describe_file(file_path, root_path)
                descriptions_2.append(desc)
            except Exception as exc:
                print(f"  [WARN] Could not re-describe '{file_path.name}': {exc}")

        if descriptions_2:
            collection_2 = agent.build_vector_index(descriptions_2)
            decisions_2 = agent.plan_from_index(descriptions_2, collection_2)

            rectified = 0
            for decision in decisions_2:
                current_parent = decision.original_path.parent.name
                if current_parent == decision.category_folder:
                    continue
                try:
                    move_only_decision = OrganizeDecision(
                        original_path=decision.original_path,
                        category_folder=decision.category_folder,
                        new_name=decision.original_path.name,
                    )
                    source_rel = decision.original_path.relative_to(root_path)
                    new_path = agent.execute_decision(move_only_decision, root_path)
                    print(f"  Rectified: {source_rel} -> {new_path.relative_to(root_path)}")
                    rectified += 1
                except Exception as exc:
                    print(f"  [WARN] Rectify skipped: {decision.original_path.name} ({exc})")

            print(f"  Rectification moves: {rectified}")

    print("\nDone.")
    return 0


def run_doctor() -> int:
    print("--- CLI Doctor ---")
    settings = load_settings()

    print(f"OLLAMA_HOST: {settings.ollama_host}")
    print(f"OLLAMA_MODEL: {settings.model}")
    print(f"OLLAMA_VLM_MODEL: {settings.vlm_model}")
    print(f"ENABLE_OCR: {settings.enable_ocr}")
    print(f"ENABLE_VLM: {settings.enable_vlm}")

    try:
        client = _create_ollama_client(settings.ollama_host)
        installed = _installed_models(client)
    except Exception as exc:
        print(f"\n[FAIL] Cannot connect to Ollama: {exc}")
        return 1

    print("\n[OK] Ollama is reachable.")
    required = _required_models()

    missing = [model for model in required if model not in installed]
    if not missing:
        print("[OK] Required model(s) are installed.")
        return 0

    print("[WARN] Missing model(s):")
    for model in missing:
        print(f"  - {model}")
    print("Run 'organize-files setup-models' to pull missing model(s).")
    return 1


def run_setup_models() -> int:
    settings = load_settings()
    try:
        client = _create_ollama_client(settings.ollama_host)
        installed = _installed_models(client)
    except Exception as exc:
        print(f"Cannot connect to Ollama: {exc}")
        return 1

    required = _required_models()

    missing = [model for model in required if model not in installed]
    if not missing:
        print("All required model(s) are already installed.")
        return 0

    print("Pulling missing model(s)...")
    for model in missing:
        print(f"  -> pulling '{model}'")
        try:
            client.pull(model=model, stream=False)
            print(f"     done: {model}")
        except Exception as exc:
            print(f"     failed: {model} ({exc})")
            return 1

    print("Model setup complete.")
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="organize-files",
        description="LLM-powered CLI file organizer",
    )
    subparsers = parser.add_subparsers(dest="command")

    init = subparsers.add_parser("init", help="guide Ollama setup and optionally pull models")
    init.add_argument(
        "--pull-models",
        action="store_true",
        help="download missing required models during setup",
    )

    organize = subparsers.add_parser("organize", help="organize files in a folder")
    organize.add_argument("path", nargs="?", help="folder path to organize")
    organize.add_argument(
        "--preferences",
        default="",
        help="user organization preferences text",
    )
    organize.add_argument(
        "--no-verify",
        action="store_true",
        help="skip verification/rectification pass",
    )
    organize.add_argument(
        "--dry-run",
        action="store_true",
        help="show planned moves without changing files",
    )
    organize.add_argument(
        "--yes",
        action="store_true",
        help="apply moves without confirmation prompt",
    )

    subparsers.add_parser("doctor", help="check runtime and model setup")
    subparsers.add_parser("setup-models", help="pull missing required models")
    return parser


def _interactive_inputs() -> tuple[Path, str]:
    user_input = input("Enter the folder path to organize: ").strip()
    root_path = Path(user_input).expanduser().resolve()
    print("\n--- File Organization Preferences ---")
    user_preferences = input(
        "Do you have specific organization requirements? "
        "(e.g., 'group by date', 'prioritize Python files', 'keep archives separate') "
        "[press Enter to skip]: "
    ).strip()
    return root_path, user_preferences


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if args.command == "init":
        raise SystemExit(run_init(pull_models=args.pull_models))

    if args.command == "doctor":
        raise SystemExit(run_doctor())

    if args.command == "setup-models":
        raise SystemExit(run_setup_models())

    if args.command == "organize":
        if args.path:
            root_path = Path(args.path).expanduser().resolve()
            preferences = args.preferences
        else:
            root_path, preferences = _interactive_inputs()
        raise SystemExit(
            run_organize(
                root_path=root_path,
                user_preferences=preferences,
                verify=not args.no_verify,
                dry_run=args.dry_run,
                auto_confirm=args.yes,
            )
        )

    if len(sys.argv) > 1:
        root_path = Path(sys.argv[1]).expanduser().resolve()
        raise SystemExit(
            run_organize(
                root_path=root_path,
                user_preferences="",
                verify=True,
                dry_run=False,
                auto_confirm=False,
            )
        )

    root_path, preferences = _interactive_inputs()
    raise SystemExit(
        run_organize(
            root_path=root_path,
            user_preferences=preferences,
            verify=True,
            dry_run=False,
            auto_confirm=False,
        )
    )


if __name__ == "__main__":
    main()
