from __future__ import annotations

import base64
import importlib
from pathlib import Path
from typing import Any


_DOCTR_OCR_MODEL: Any | None = None


def _as_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if hasattr(value, "model_dump"):
        dumped = value.model_dump()
        if isinstance(dumped, dict):
            return dumped
    return {}


def _safe_read_text(file_path: Path, max_chars: int) -> str:
    try:
        return file_path.read_text(encoding="utf-8", errors="ignore")[:max_chars]
    except Exception:
        return ""


def _read_pdf_text(file_path: Path, max_chars: int) -> str:
    try:
        from pypdf import PdfReader  # pyright: ignore[reportMissingImports]
    except Exception:
        return ""

    try:
        reader = PdfReader(str(file_path))
        out: list[str] = []
        size = 0
        for page in reader.pages:
            text = page.extract_text() or ""
            if not text:
                continue
            remaining = max_chars - size
            if remaining <= 0:
                break
            chunk = text[:remaining]
            out.append(chunk)
            size += len(chunk)
        return "\n".join(out).strip()
    except Exception:
        return ""


def _read_docx_text(file_path: Path, max_chars: int) -> str:
    try:
        from docx import Document  # pyright: ignore[reportMissingImports]
    except Exception:
        return ""

    try:
        doc = Document(str(file_path))
        text = "\n".join(p.text for p in doc.paragraphs)
        return text[:max_chars].strip()
    except Exception:
        return ""


def _read_xlsx_text(file_path: Path, max_chars: int) -> str:
    try:
        openpyxl_module = importlib.import_module("openpyxl")
        load_workbook = getattr(openpyxl_module, "load_workbook")
    except Exception:
        return ""

    try:
        wb = load_workbook(str(file_path), read_only=True, data_only=True)
        out: list[str] = []
        size = 0
        for ws in wb.worksheets:
            out.append(f"[Sheet: {ws.title}]")
            size += len(out[-1])
            for row in ws.iter_rows(min_row=1, max_row=30, values_only=True):
                line = " | ".join("" if v is None else str(v) for v in row).strip()
                if not line:
                    continue
                remaining = max_chars - size
                if remaining <= 0:
                    break
                chunk = line[:remaining]
                out.append(chunk)
                size += len(chunk)
            if size >= max_chars:
                break
        wb.close()
        return "\n".join(out)[:max_chars].strip()
    except Exception:
        return ""


def _read_pptx_text(file_path: Path, max_chars: int) -> str:
    try:
        from pptx import Presentation  # pyright: ignore[reportMissingImports]
    except Exception:
        return ""

    try:
        pres = Presentation(str(file_path))
        out: list[str] = []
        for slide in pres.slides:
            for shape in slide.shapes:
                text = getattr(shape, "text", "")
                if text:
                    out.append(text)
            if sum(len(x) for x in out) >= max_chars:
                break
        return "\n".join(out)[:max_chars].strip()
    except Exception:
        return ""


def _ocr_image_text(file_path: Path, max_chars: int) -> str:
    try:
        from doctr.io import DocumentFile  # pyright: ignore[reportMissingImports]
        from doctr.models import ocr_predictor  # pyright: ignore[reportMissingImports]
    except Exception:
        return ""

    try:
        global _DOCTR_OCR_MODEL
        if _DOCTR_OCR_MODEL is None:
            _DOCTR_OCR_MODEL = ocr_predictor(pretrained=True)

        doc = DocumentFile.from_images(str(file_path))
        result = _DOCTR_OCR_MODEL(doc)
        text = result.render()
        return text[:max_chars].strip()
    except Exception:
        return ""


def _describe_image_with_vlm(
    *,
    file_path: Path,
    client: Any,
    model: str,
    max_chars: int,
) -> str:
    if not model:
        return ""
    try:
        image_b64 = base64.b64encode(file_path.read_bytes()).decode("utf-8")
        response = client.chat(
            model=model,
            messages=[
                {
                    "role": "user",
                    "content": (
                        "Describe this image for file organization. "
                        "Mention document type, key entities, and likely category in 2 sentences."
                    ),
                    "images": [image_b64],
                }
            ],
            options={"temperature": 0.0},
        )
        message = _as_dict(_as_dict(response).get("message", {}))
        content = message.get("content", "")
        if isinstance(content, str):
            return content[:max_chars].strip()
        return ""
    except Exception:
        return ""


def build_file_analysis_context(
    *,
    file_path: Path,
    max_chars: int,
    enable_ocr: bool,
    enable_vlm: bool,
    vlm_model: str,
    client: Any,
) -> dict[str, str]:
    suffix = file_path.suffix.lower()

    text_ext = {
        ".txt",
        ".md",
        ".py",
        ".js",
        ".ts",
        ".json",
        ".yaml",
        ".yml",
        ".toml",
        ".ini",
        ".cfg",
        ".csv",
        ".xml",
        ".html",
        ".css",
        ".cpp",
        ".c",
        ".h",
        ".hpp",
        ".java",
        ".go",
        ".rs",
        ".sh",
    }
    image_ext = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff", ".gif"}

    preview = ""
    ocr_preview = ""
    vlm_description = ""

    if suffix in text_ext:
        preview = _safe_read_text(file_path, max_chars)
    elif suffix == ".pdf":
        preview = _read_pdf_text(file_path, max_chars)
    elif suffix == ".docx":
        preview = _read_docx_text(file_path, max_chars)
    elif suffix in {".xlsx", ".xlsm"}:
        preview = _read_xlsx_text(file_path, max_chars)
    elif suffix == ".pptx":
        preview = _read_pptx_text(file_path, max_chars)

    # For images: first try OCR, then fall back to VLM if OCR is insufficient
    if suffix in image_ext:
        if enable_ocr:
            ocr_preview = _ocr_image_text(file_path, max_chars)
        
        # Use VLM only if OCR failed or returned insufficient results
        is_ocr_insufficient = not ocr_preview or len(ocr_preview.strip()) < 10
        if enable_vlm and is_ocr_insufficient:
            vlm_description = _describe_image_with_vlm(
                file_path=file_path,
                client=client,
                model=vlm_model,
                max_chars=max_chars,
            )

    if not preview:
        preview = _safe_read_text(file_path, max_chars)

    return {
        "content_preview": preview,
        "ocr_preview": ocr_preview,
        "vlm_description": vlm_description,
    }
