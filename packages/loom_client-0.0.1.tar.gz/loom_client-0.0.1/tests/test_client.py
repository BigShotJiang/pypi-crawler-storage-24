"""Unit tests for LoomClient logic (without a real WebSocket server)."""
from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock

import pytest

from loom_client.client import LoomClient
from loom_client.exceptions import CommandException
from loom_client.models import (
    AddTrackAction,
    ClearROIAction,
    GetBrowserStateArgs,
    ModifyTracksArgs,
    NavigateArgs,
    ProjectedState,
    ROI,
    ROISetConfig,
    RemoveTrackAction,
    RequestMessage,
    SetLayoutArgs,
    SubscribeEventsArgs,
    TrackSessionConfig,
    WireTrackSelector,
    ZoomLevel,
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_state_dict():
    return {
        "locus": {"chr": "chr1", "start": 1000, "end": 2000},
        "locusString": "chr1:1,000-2,000",
        "span": 1000,
        "zoomLevel": "gene",
        "tracks": [],
        "rois": [],
    }


# ── CommandException ──────────────────────────────────────────────────────────

class TestCommandException:
    def test_attributes(self):
        exc = CommandException("TRACK_NOT_FOUND", "no match")
        assert exc.code == "TRACK_NOT_FOUND"
        assert exc.message == "no match"

    def test_str(self):
        exc = CommandException("FOO", "bar")
        assert "[FOO] bar" in str(exc)


# ── RequestMessage serialization ──────────────────────────────────────────────

class TestRequestMessageSerialization:
    def test_no_args_serializes_null(self):
        msg = RequestMessage(id="x", command="get_browser_state")
        data = json.loads(msg.model_dump_json())
        assert data["args"] is None

    def test_with_args(self):
        msg = RequestMessage(id="y", command="navigate", args={"locus": "chr1:1-10"})
        data = json.loads(msg.model_dump_json())
        assert data["args"]["locus"] == "chr1:1-10"


# ── send() payload building ───────────────────────────────────────────────────

class TestSendPayload:
    """Test that send() builds the correct wire message."""

    def _build_payload(self, args) -> dict:
        """Reproduce the payload logic from LoomClient.send()."""
        req = RequestMessage(command=args.command)
        payload = args.model_dump(by_alias=True, exclude_none=True)
        payload.pop("command")
        if payload:
            req.args = payload
        return json.loads(req.model_dump_json())

    def test_get_browser_state_no_record(self):
        args = GetBrowserStateArgs()
        wire = self._build_payload(args)
        assert wire["command"] == "get_browser_state"
        assert wire["args"] is None

    def test_get_browser_state_with_record(self):
        args = GetBrowserStateArgs(record="snap1")
        wire = self._build_payload(args)
        assert wire["args"]["record"] == "snap1"

    def test_navigate_locus(self):
        args = NavigateArgs(locus="chr17:1-1000")
        wire = self._build_payload(args)
        assert wire["args"]["locus"] == "chr17:1-1000"
        assert "zoom" not in wire["args"]

    def test_navigate_zoom(self):
        args = NavigateArgs(zoom="in", factor=2.0)
        wire = self._build_payload(args)
        assert wire["args"]["zoom"] == "in"
        assert wire["args"]["factor"] == 2.0

    def test_subscribe_events(self):
        args = SubscribeEventsArgs(events=["locuschange"])
        wire = self._build_payload(args)
        assert wire["args"]["events"] == ["locuschange"]

    def test_query_features_uses_alias(self):
        from loom_client.models import QueryFeaturesArgs
        args = QueryFeaturesArgs(track_id="t1", summarize=True)
        wire = self._build_payload(args)
        assert wire["args"]["trackId"] == "t1"
        assert "track_id" not in wire["args"]

    def test_modify_tracks_add(self):
        action = AddTrackAction(config=TrackSessionConfig(type="wig", name="Sig"))
        args = ModifyTracksArgs(actions=[action])
        wire = self._build_payload(args)
        assert wire["args"]["actions"][0]["action"] == "add"
        assert wire["args"]["actions"][0]["config"]["name"] == "Sig"

    def test_set_layout(self):
        tracks = [TrackSessionConfig(type="ruler")]
        args = SetLayoutArgs(tracks=tracks, locus="chr1:1-1000")
        wire = self._build_payload(args)
        assert wire["args"]["locus"] == "chr1:1-1000"
        assert len(wire["args"]["tracks"]) == 1


# ── _listen() message routing ─────────────────────────────────────────────────

async def _async_iter(items):
    """Helper: yield items from a list as an async iterator."""
    for item in items:
        yield item


class TestListen:
    def _make_client(self, messages: list[str]) -> LoomClient:
        client = LoomClient("ws://fake")
        client._ws = _async_iter(messages)
        return client

    @pytest.mark.asyncio
    async def test_response_resolves_future(self):
        raw = json.dumps({"id": "req-1", "result": {"ok": True}})
        client = self._make_client([raw])
        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()
        client._pending["req-1"] = future

        await client._listen()
        assert future.done()
        assert future.result() == {"ok": True}

    @pytest.mark.asyncio
    async def test_error_sets_exception(self):
        raw = json.dumps({"id": "req-2", "error": {"code": "TRACK_NOT_FOUND", "message": "nope"}})
        client = self._make_client([raw])
        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()
        client._pending["req-2"] = future

        await client._listen()
        assert future.done()
        with pytest.raises(CommandException) as exc_info:
            future.result()
        assert exc_info.value.code == "TRACK_NOT_FOUND"

    @pytest.mark.asyncio
    async def test_event_dispatches_handler(self):
        raw = json.dumps({"event": "locuschange", "data": {"locus": {"chr": "chr1", "start": 0, "end": 1}}})
        client = self._make_client([raw])
        received = []
        client.on("locuschange", lambda data: received.append(data))

        await client._listen()
        assert len(received) == 1
        assert received[0]["locus"]["chr"] == "chr1"

    @pytest.mark.asyncio
    async def test_wildcard_handler(self):
        raw = json.dumps({"event": "trackadded", "data": {"trackId": "t1"}})
        client = self._make_client([raw])
        calls = []
        client.on("*", lambda name, data: calls.append((name, data)))

        await client._listen()
        assert calls == [("trackadded", {"trackId": "t1"})]

    @pytest.mark.asyncio
    async def test_unknown_id_ignored(self):
        raw = json.dumps({"id": "ghost", "result": None})
        client = self._make_client([raw])
        # Should not raise
        await client._listen()

    @pytest.mark.asyncio
    async def test_specific_and_wildcard_both_fire(self):
        raw = json.dumps({"event": "locuschange", "data": {}})
        client = self._make_client([raw])
        specific = []
        wildcard = []
        client.on("locuschange", lambda data: specific.append(data))
        client.on("*", lambda name, data: wildcard.append(name))

        await client._listen()
        assert len(specific) == 1
        assert wildcard == ["locuschange"]


# ── on() / off() ─────────────────────────────────────────────────────────────

class TestEventHandlers:
    def test_register_and_remove(self):
        client = LoomClient("ws://fake")
        handler = lambda d: d
        client.on("locuschange", handler)
        assert handler in client._event_handlers["locuschange"]
        client.off("locuschange", handler)
        assert handler not in client._event_handlers.get("locuschange", [])

    def test_multiple_handlers(self):
        client = LoomClient("ws://fake")
        h1 = lambda d: d
        h2 = lambda d: d
        client.on("trackadded", h1)
        client.on("trackadded", h2)
        assert len(client._event_handlers["trackadded"]) == 2

    def test_off_unregistered_handler_does_not_raise(self):
        client = LoomClient("ws://fake")
        handler = lambda d: d
        # Should not raise even if handler was never registered
        client.off("locuschange", handler)
        client.off("nonexistent_event", handler)


# ── High-level typed methods (mocked send) ────────────────────────────────────

class TestTypedMethods:
    def _make_client(self) -> LoomClient:
        client = LoomClient("ws://fake")
        return client

    @pytest.mark.asyncio
    async def test_get_browser_state(self):
        client = self._make_client()
        client.send = AsyncMock(return_value=_make_state_dict())

        state = await client.get_browser_state()
        assert isinstance(state, ProjectedState)
        assert state.zoom_level == ZoomLevel.GENE

    @pytest.mark.asyncio
    async def test_navigate_returns_result(self):
        client = self._make_client()
        client.send = AsyncMock(return_value=True)

        result = await client.navigate(locus="chr1:1-100")
        assert result is True
        client.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_modify_tracks(self):
        client = self._make_client()
        client.send = AsyncMock(return_value={
            "results": [{"action": "add", "success": True, "trackId": "t1"}]
        })
        from loom_client.models import ModifyTracksResult
        result = await client.modify_tracks([
            AddTrackAction(config=TrackSessionConfig(type="wig"))
        ])
        assert isinstance(result, ModifyTracksResult)

    @pytest.mark.asyncio
    async def test_query_features(self):
        client = self._make_client()
        client.send = AsyncMock(return_value={
            "trackId": "t1", "featureCount": 5
        })
        from loom_client.models import QueryFeaturesResult
        result = await client.query_features("t1")
        assert isinstance(result, QueryFeaturesResult)
        assert result.feature_count == 5

    @pytest.mark.asyncio
    async def test_set_layout(self):
        client = self._make_client()
        client.send = AsyncMock(return_value={
            "added": ["t1"], "removed": [], "unchanged": []
        })
        from loom_client.models import SetLayoutResult
        result = await client.set_layout([TrackSessionConfig(type="wig")])
        assert isinstance(result, SetLayoutResult)

    @pytest.mark.asyncio
    async def test_export_view_svg(self):
        client = self._make_client()
        svg = "<svg>...</svg>"
        client.send = AsyncMock(return_value=svg)

        result = await client.export_view("svg")
        assert result == svg

    @pytest.mark.asyncio
    async def test_export_view_session(self):
        client = self._make_client()
        session_dict = {
            "version": "1.0",
            "locus": {"chr": "chr1", "start": 0, "end": 1000},
            "tracks": [],
        }
        client.send = AsyncMock(return_value=session_dict)

        from loom_client.models import SessionConfig
        result = await client.export_view("session")
        assert isinstance(result, SessionConfig)

    @pytest.mark.asyncio
    async def test_manage_rois(self):
        client = self._make_client()
        client.send = AsyncMock(return_value={"action": "clear"})

        result = await client.manage_rois(ClearROIAction())
        assert result == {"action": "clear"}

    @pytest.mark.asyncio
    async def test_subscribe_events(self):
        client = self._make_client()
        client.send = AsyncMock(return_value={"subscribed": ["locuschange"]})

        from loom_client.models import SubscribeEventsResult
        result = await client.subscribe_events(["locuschange"])
        assert isinstance(result, SubscribeEventsResult)
        assert "locuschange" in result.subscribed

    @pytest.mark.asyncio
    async def test_command_exception_propagates(self):
        client = self._make_client()
        client.send = AsyncMock(side_effect=CommandException("INTERNAL_ERROR", "oops"))

        with pytest.raises(CommandException) as exc_info:
            await client.get_browser_state()
        assert exc_info.value.code == "INTERNAL_ERROR"
