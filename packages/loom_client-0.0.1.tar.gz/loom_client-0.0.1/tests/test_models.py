"""Unit tests for Pydantic models."""
from __future__ import annotations

import json

import pytest
from pydantic import ValidationError

from loom_client.models import (
    AddROIAction,
    AddTrackAction,
    AnnotationFeatureSummary,
    ClearROIAction,
    DataSourceConfig,
    ErrorDetail,
    ErrorMessage,
    EventMessage,
    ExportViewArgs,
    FindROIAtLocusAction,
    FindTrackAction,
    GetBrowserStateArgs,
    GetVisibleROIAction,
    InteractionFeatureSummary,
    ListROIAction,
    ListROISetsAction,
    Locus,
    LocusChangeData,
    ManageROIsArgs,
    ModifyTracksArgs,
    ModifyTracksResult,
    NavigateArgs,
    ProjectedState,
    QueryFeaturesArgs,
    QueryFeaturesResult,
    ROI,
    ROIEventData,
    ROIInteractionEventData,
    ROISetConfig,
    RemoveROIAction,
    RemoveTrackAction,
    RequestMessage,
    ResponseMessage,
    SessionConfig,
    SetLayoutArgs,
    SetLayoutResult,
    SignalRange,
    SingleTrackEventData,
    SubscribeEventsArgs,
    SubscribeEventsResult,
    TrackErrorData,
    TrackInteractionData,
    TrackOrderChangedData,
    TrackSessionConfig,
    TrackSummary,
    UpdateMetadataAction,
    UpdateROIAction,
    WigFeatureSummary,
    WireTrackSelector,
    ZoomLevel,
)


# ── Wire messages ─────────────────────────────────────────────────────────────

class TestRequestMessage:
    def test_auto_id(self):
        msg = RequestMessage(command="get_browser_state")
        assert msg.id  # auto-generated UUID
        assert msg.command == "get_browser_state"
        assert msg.args is None

    def test_explicit_id(self):
        msg = RequestMessage(id="my-id", command="navigate")
        assert msg.id == "my-id"

    def test_with_args(self):
        msg = RequestMessage(command="navigate", args={"locus": "chr1:1-100"})
        assert msg.args == {"locus": "chr1:1-100"}

    def test_serialization(self):
        msg = RequestMessage(id="abc", command="navigate")
        data = json.loads(msg.model_dump_json())
        assert data["id"] == "abc"
        assert data["command"] == "navigate"
        assert data["args"] is None

    def test_unique_ids(self):
        ids = {RequestMessage(command="x").id for _ in range(100)}
        assert len(ids) == 100


class TestResponseMessage:
    def test_parse(self):
        msg = ResponseMessage.model_validate({"id": "1", "result": {"key": "val"}})
        assert msg.id == "1"
        assert msg.result == {"key": "val"}


class TestErrorMessage:
    def test_parse(self):
        raw = {"id": "1", "error": {"code": "TRACK_NOT_FOUND", "message": "no match"}}
        msg = ErrorMessage.model_validate(raw)
        assert msg.error.code == "TRACK_NOT_FOUND"
        assert msg.error.message == "no match"


class TestEventMessage:
    def test_parse(self):
        raw = {"event": "locuschange", "data": {"locus": {"chr": "chr1", "start": 0, "end": 100}}}
        msg = EventMessage.model_validate(raw)
        assert msg.event == "locuschange"


# ── Core genomic types ────────────────────────────────────────────────────────

class TestLocus:
    def test_roundtrip(self):
        locus = Locus(chr="chr1", start=100, end=200)
        assert locus.chr == "chr1"
        assert locus.start == 100
        assert locus.end == 200


class TestROI:
    def test_required_fields(self):
        roi = ROI(id="r1", chr="chr1", start=0, end=1000)
        assert roi.name is None
        assert roi.color is None

    def test_optional_fields(self):
        roi = ROI(id="r1", chr="chr1", start=0, end=1000, name="MyROI", color="rgba(255,0,0,0.5)")
        assert roi.name == "MyROI"
        assert roi.color == "rgba(255,0,0,0.5)"


class TestROISetConfig:
    def test_alias(self):
        data = {"name": "MySet", "isUserDefined": True, "features": []}
        cfg = ROISetConfig.model_validate(data)
        assert cfg.is_user_defined is True

    def test_populate_by_name(self):
        cfg = ROISetConfig(name="S", is_user_defined=False, features=[])
        assert cfg.is_user_defined is False


# ── Track session configs ─────────────────────────────────────────────────────

class TestDataSourceConfig:
    def test_minimal(self):
        ds = DataSourceConfig(type="bigwig", url="https://example.com/a.bw")
        assert ds.type == "bigwig"
        assert ds.url == "https://example.com/a.bw"

    def test_aliases(self):
        data = {"type": "hic", "indexURL": "http://x.com/idx", "experimentId": "e1", "windowFunction": "mean"}
        ds = DataSourceConfig.model_validate(data)
        assert ds.index_url == "http://x.com/idx"
        assert ds.experiment_id == "e1"
        assert ds.window_function == "mean"

    def test_serialization_by_alias(self):
        ds = DataSourceConfig(type="bigwig", index_url="http://idx")
        out = ds.model_dump(by_alias=True, exclude_none=True)
        assert "indexURL" in out
        assert "index_url" not in out


class TestTrackSessionConfig:
    def test_minimal(self):
        t = TrackSessionConfig(type="wig")
        assert t.type == "wig"
        assert t.data_source is None

    def test_nested_datasource(self):
        data = {
            "type": "wig",
            "dataSource": {"type": "bigwig", "url": "http://x.com/a.bw"},
        }
        t = TrackSessionConfig.model_validate(data)
        assert t.data_source.type == "bigwig"


# ── State projection ──────────────────────────────────────────────────────────

class TestProjectedState:
    def _make_raw(self):
        return {
            "locus": {"chr": "chr1", "start": 1000, "end": 2000},
            "locusString": "chr1:1,000-2,000",
            "span": 1000,
            "zoomLevel": "gene",
            "tracks": [],
            "rois": [],
        }

    def test_parse(self):
        state = ProjectedState.model_validate(self._make_raw())
        assert state.zoom_level == ZoomLevel.GENE
        assert state.locus_string == "chr1:1,000-2,000"
        assert state.tracks == []

    def test_zoom_levels(self):
        for level in ZoomLevel:
            raw = self._make_raw()
            raw["zoomLevel"] = level.value
            state = ProjectedState.model_validate(raw)
            assert state.zoom_level == level


class TestTrackSummary:
    def test_aliases(self):
        data = {
            "id": "t1",
            "type": "wig",
            "featureSummary": {"featureCount": 10},
        }
        ts = TrackSummary.model_validate(data)
        assert ts.feature_summary == {"featureCount": 10}


# ── Track selector ────────────────────────────────────────────────────────────

class TestWireTrackSelector:
    def test_empty(self):
        sel = WireTrackSelector()
        assert sel.id is None

    def test_name_regex_alias(self):
        data = {"nameRegex": "signal.*"}
        sel = WireTrackSelector.model_validate(data)
        assert sel.name_regex == "signal.*"

    def test_where(self):
        sel = WireTrackSelector(where={"cell": "K562"})
        assert sel.where == {"cell": "K562"}


# ── Command arg models ────────────────────────────────────────────────────────

class TestGetBrowserStateArgs:
    def test_defaults(self):
        args = GetBrowserStateArgs()
        assert args.command == "get_browser_state"
        assert args.record is None

    def test_with_record(self):
        args = GetBrowserStateArgs(record="snap1")
        assert args.record == "snap1"


class TestNavigateArgs:
    def test_locus(self):
        args = NavigateArgs(locus="chr17:1-100")
        assert args.locus == "chr17:1-100"
        assert args.zoom is None

    def test_zoom(self):
        args = NavigateArgs(zoom="in", factor=2.0)
        assert args.zoom == "in"
        assert args.factor == 2.0

    def test_invalid_zoom(self):
        with pytest.raises(ValidationError):
            NavigateArgs(zoom="diagonal")


class TestModifyTracksArgs:
    def test_add_track(self):
        action = AddTrackAction(config=TrackSessionConfig(type="wig"))
        args = ModifyTracksArgs(actions=[action])
        assert args.command == "modify_tracks"
        assert len(args.actions) == 1

    def test_remove_track(self):
        action = RemoveTrackAction(selector=WireTrackSelector(id="t1"))
        args = ModifyTracksArgs(actions=[action])
        assert args.actions[0].action == "remove"

    def test_find_track(self):
        action = FindTrackAction(selector=WireTrackSelector(name="signal"))
        args = ModifyTracksArgs(actions=[action])
        assert args.actions[0].action == "find"

    def test_update_metadata(self):
        action = UpdateMetadataAction(
            selector=WireTrackSelector(id="t1"),
            metadata={"label": "new"},
        )
        args = ModifyTracksArgs(actions=[action])
        assert args.actions[0].action == "update_metadata"

    def test_serialization(self):
        action = AddTrackAction(config=TrackSessionConfig(type="wig", name="Test"))
        args = ModifyTracksArgs(actions=[action])
        payload = args.model_dump(by_alias=True, exclude_none=True)
        assert payload["actions"][0]["action"] == "add"
        assert payload["actions"][0]["config"]["type"] == "wig"


class TestQueryFeaturesArgs:
    def test_alias(self):
        args = QueryFeaturesArgs(trackId="t1")
        assert args.track_id == "t1"

    def test_populate_by_name(self):
        args = QueryFeaturesArgs(track_id="t2")
        assert args.track_id == "t2"

    def test_serialization(self):
        args = QueryFeaturesArgs(track_id="t1", summarize=True)
        payload = args.model_dump(by_alias=True, exclude_none=True)
        assert payload["trackId"] == "t1"
        assert payload["summarize"] is True
        assert "command" in payload


class TestSetLayoutArgs:
    def test_basic(self):
        tracks = [TrackSessionConfig(type="ruler")]
        args = SetLayoutArgs(tracks=tracks)
        assert args.locus is None


class TestExportViewArgs:
    def test_svg(self):
        args = ExportViewArgs(format="svg")
        assert args.format == "svg"

    def test_invalid_format(self):
        with pytest.raises(ValidationError):
            ExportViewArgs(format="pdf")


class TestManageROIsArgs:
    def test_add(self):
        roi = ROI(id="r1", chr="chr1", start=0, end=100)
        action = AddROIAction(roi=roi)
        args = ManageROIsArgs(action=action)
        assert args.command == "manage_rois"

    def test_remove(self):
        action = RemoveROIAction(roiId="r1")
        args = ManageROIsArgs(action=action)
        assert args.action.action == "remove"

    def test_update(self):
        action = UpdateROIAction(roiId="r1", changes={"color": "red"})
        args = ManageROIsArgs(action=action)
        assert args.action.action == "update"

    def test_clear(self):
        args = ManageROIsArgs(action=ClearROIAction())
        assert args.action.action == "clear"

    def test_list(self):
        args = ManageROIsArgs(action=ListROIAction())
        assert args.action.action == "list"

    def test_list_sets(self):
        args = ManageROIsArgs(action=ListROISetsAction())
        assert args.action.action == "list_sets"

    def test_find_at_locus(self):
        action = FindROIAtLocusAction(chr="chr1", start=0, end=1000)
        args = ManageROIsArgs(action=action)
        assert args.action.action == "find_at_locus"

    def test_get_visible(self):
        args = ManageROIsArgs(action=GetVisibleROIAction())
        assert args.action.action == "get_visible"

    def test_serialization(self):
        roi = ROI(id="r1", chr="chr1", start=0, end=100)
        action = AddROIAction(roi=roi, set_name="MySet")
        args = ManageROIsArgs(action=action)
        payload = args.model_dump(by_alias=True, exclude_none=True)
        assert payload["action"]["action"] == "add"
        assert payload["action"]["setName"] == "MySet"


class TestSubscribeEventsArgs:
    def test_all_events(self):
        args = SubscribeEventsArgs(events=["*"])
        assert args.events == ["*"]

    def test_empty_unsubscribe(self):
        args = SubscribeEventsArgs(events=[])
        assert args.events == []


# ── Command result models ─────────────────────────────────────────────────────

class TestModifyTracksResult:
    def test_parse(self):
        raw = {
            "results": [
                {"action": "add", "success": True, "trackId": "t1"},
            ]
        }
        result = ModifyTracksResult.model_validate(raw)
        assert result.results[0].track_id == "t1"
        assert result.results[0].success is True


class TestQueryFeaturesResult:
    def test_parse(self):
        raw = {"trackId": "t1", "featureCount": 42, "features": [{"name": "gene1"}]}
        result = QueryFeaturesResult.model_validate(raw)
        assert result.track_id == "t1"
        assert result.feature_count == 42


class TestSetLayoutResult:
    def test_parse(self):
        raw = {"added": ["t1"], "removed": ["t2"], "unchanged": ["t3"]}
        result = SetLayoutResult.model_validate(raw)
        assert result.added == ["t1"]
        assert result.removed == ["t2"]


class TestSubscribeEventsResult:
    def test_parse(self):
        raw = {"subscribed": ["locuschange", "dataloaded"]}
        result = SubscribeEventsResult.model_validate(raw)
        assert "locuschange" in result.subscribed


# ── Feature summaries ─────────────────────────────────────────────────────────

class TestWigFeatureSummary:
    def test_parse(self):
        raw = {"featureCount": 100, "signalRange": {"min": 0.0, "max": 5.5}}
        s = WigFeatureSummary.model_validate(raw)
        assert s.feature_count == 100
        assert s.signal_range.max == 5.5


class TestAnnotationFeatureSummary:
    def test_parse(self):
        raw = {"featureCount": 5, "featureNames": ["geneA"], "packingDepth": 3}
        s = AnnotationFeatureSummary.model_validate(raw)
        assert s.packing_depth == 3


class TestInteractionFeatureSummary:
    def test_parse(self):
        raw = {"featureCount": 10, "valueRange": {"min": 1.0, "max": 9.0}}
        s = InteractionFeatureSummary.model_validate(raw)
        assert s.value_range.min == 1.0


# ── Event data models ─────────────────────────────────────────────────────────

class TestLocusChangeData:
    def test_parse(self):
        raw = {"locus": {"chr": "chr1", "start": 100, "end": 200}}
        data = LocusChangeData.model_validate(raw)
        assert data.locus.chr == "chr1"


class TestSingleTrackEventData:
    def test_parse(self):
        raw = {"trackId": "t1", "trackType": "wig", "trackName": "Signal"}
        data = SingleTrackEventData.model_validate(raw)
        assert data.track_id == "t1"
        assert data.track_type == "wig"


class TestTrackOrderChangedData:
    def test_parse(self):
        raw = {"trackIds": ["t1", "t2"]}
        data = TrackOrderChangedData.model_validate(raw)
        assert data.track_ids == ["t1", "t2"]


class TestTrackErrorData:
    def test_parse(self):
        raw = {"trackId": "t1", "trackType": "wig", "error": "fetch failed"}
        data = TrackErrorData.model_validate(raw)
        assert data.error == "fetch failed"


class TestTrackInteractionData:
    def test_parse(self):
        raw = {"trackId": "t1", "trackType": "wig", "genomicLocation": 5000, "featureCount": 3}
        data = TrackInteractionData.model_validate(raw)
        assert data.genomic_location == 5000
        assert data.feature_count == 3


class TestROIEventData:
    def test_parse(self):
        raw = {
            "roi": {"id": "r1", "chr": "chr1", "start": 0, "end": 100},
            "setName": "setA",
        }
        data = ROIEventData.model_validate(raw)
        assert data.set_name == "setA"
        assert data.roi.id == "r1"


class TestROIInteractionEventData:
    def test_parse(self):
        raw = {
            "roi": {"id": "r1", "chr": "chr1", "start": 0, "end": 100},
            "genomicLocation": 50,
            "x": 100.0,
            "y": 200.0,
        }
        data = ROIInteractionEventData.model_validate(raw)
        assert data.genomic_location == 50
        assert data.x == 100.0
