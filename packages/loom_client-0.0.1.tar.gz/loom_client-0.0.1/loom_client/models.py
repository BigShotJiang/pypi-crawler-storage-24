from __future__ import annotations

import uuid
from enum import Enum
from typing import Annotated, Any, Literal, Union

from pydantic import BaseModel, Field


# ── Wire messages ─────────────────────────────────────────────────────────────

class RequestMessage(BaseModel):
    """Client → Server request."""

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    command: str
    args: dict[str, Any] | None = None


class ResponseMessage(BaseModel):
    """Server → Client success response."""

    id: str
    result: Any


class ErrorDetail(BaseModel):
    code: str
    message: str


class ErrorMessage(BaseModel):
    """Server → Client error response."""

    id: str
    error: ErrorDetail


class EventMessage(BaseModel):
    """Server → Client unsolicited event."""

    event: str
    data: Any


# Discriminated parsing of inbound server messages
OutboundMessage = Annotated[
    Union[ResponseMessage, ErrorMessage, EventMessage],
    Field(discriminator=None),  # manually discriminate on field presence
]


# ── Core genomic types ────────────────────────────────────────────────────────

class Locus(BaseModel):
    chr: str
    start: int
    end: int


class ROI(BaseModel):
    """Region of Interest."""

    id: str
    chr: str
    start: int  # 0-based
    end: int
    name: str | None = None
    description: str | None = None
    color: str | None = None  # CSS color with alpha


class ROISetConfig(BaseModel):
    name: str
    color: str | None = None
    is_user_defined: bool | None = Field(None, alias="isUserDefined")
    features: list[ROI]

    model_config = {"populate_by_name": True}


# ── Track session configs ─────────────────────────────────────────────────────

class DataSourceConfig(BaseModel):
    """Discriminated union — use the `type` field."""

    type: str
    url: str | None = None
    genome: str | None = None
    track: str | None = None
    experiment_id: str | None = Field(None, alias="experimentId")
    window_function: str | None = Field(None, alias="windowFunction")
    format: str | None = None
    index_url: str | None = Field(None, alias="indexURL")
    indexed: bool | None = None

    model_config = {"populate_by_name": True}


class TrackSessionConfig(BaseModel):
    """
    Discriminated union on ``type``. Valid types:
    ``'wig'``, ``'annotation'``, ``'ruler'``, ``'sequence'``, ``'interact'``
    """

    type: str
    id: str | None = None
    name: str | None = None
    order: int | None = None
    metadata: dict[str, str] | None = None
    data_source: DataSourceConfig | None = Field(None, alias="dataSource")
    config: dict[str, Any] | None = None

    model_config = {"populate_by_name": True}


class SessionConfig(BaseModel):
    version: str
    locus: Locus
    viewport_width: int | None = Field(None, alias="viewportWidth")
    theme: dict[str, Any] | None = None
    genome: dict[str, Any] | None = None
    tracks: list[TrackSessionConfig]
    rois: list[ROISetConfig] | None = None

    model_config = {"populate_by_name": True}


# ── State projection (get_browser_state response) ─────────────────────────────

class ZoomLevel(str, Enum):
    BASE = "base"
    ELEMENT = "element"
    GENE = "gene"
    REGION = "region"
    CHROMOSOME = "chromosome"
    GENOME = "genome"


class SignalRange(BaseModel):
    min: float
    max: float


class WigFeatureSummary(BaseModel):
    feature_count: int = Field(alias="featureCount")
    signal_range: SignalRange = Field(alias="signalRange")

    model_config = {"populate_by_name": True}


class AnnotationFeatureSummary(BaseModel):
    feature_count: int = Field(alias="featureCount")
    feature_names: list[str] = Field(alias="featureNames")
    packing_depth: int = Field(alias="packingDepth")

    model_config = {"populate_by_name": True}


class InteractionFeatureSummary(BaseModel):
    feature_count: int = Field(alias="featureCount")
    value_range: SignalRange = Field(alias="valueRange")

    model_config = {"populate_by_name": True}


TrackFeatureSummary = WigFeatureSummary | AnnotationFeatureSummary | InteractionFeatureSummary


class TrackSummary(BaseModel):
    id: str
    type: str
    name: str | None = None
    metadata: dict[str, str] | None = None
    loading: bool | None = None
    feature_summary: dict[str, Any] | None = Field(None, alias="featureSummary")

    model_config = {"populate_by_name": True}


class ProjectedState(BaseModel):
    locus: Locus
    locus_string: str = Field(alias="locusString")
    span: int
    zoom_level: ZoomLevel = Field(alias="zoomLevel")
    genome: str | None = None
    tracks: list[TrackSummary]
    rois: list[ROISetConfig]

    model_config = {"populate_by_name": True}


# ── Track selector ────────────────────────────────────────────────────────────

class WireTrackSelector(BaseModel):
    """
    JSON-safe track selector. Fields are AND-combined.

    - id: exact match on track ID
    - name: case-insensitive substring match
    - name_regex: regex pattern (takes precedence over name), matched case-insensitive
    - type: exact match on track type (``'wig'``, ``'annotation'``, etc.)
    - where: AND semantics on metadata key-value pairs
    """

    id: str | None = None
    name: str | None = None
    name_regex: str | None = Field(None, alias="nameRegex")
    type: str | None = None
    where: dict[str, str] | None = None

    model_config = {"populate_by_name": True}


# ── Command argument models ───────────────────────────────────────────────────

class GetBrowserStateArgs(BaseModel):
    command: Literal["get_browser_state"] = "get_browser_state"
    record: str | None = None


class NavigateArgs(BaseModel):
    command: Literal["navigate"] = "navigate"
    locus: str | None = None
    zoom: Literal["in", "out"] | None = None
    factor: float | None = None


# ── modify_tracks ─────────────────────────────────────────────────────────────

class AddTrackAction(BaseModel):
    action: Literal["add"] = "add"
    config: TrackSessionConfig


class RemoveTrackAction(BaseModel):
    action: Literal["remove"] = "remove"
    selector: WireTrackSelector


class FindTrackAction(BaseModel):
    action: Literal["find"] = "find"
    selector: WireTrackSelector


class UpdateMetadataAction(BaseModel):
    action: Literal["update_metadata"] = "update_metadata"
    selector: WireTrackSelector
    metadata: dict[str, str]


ModifyTrackAction = AddTrackAction | RemoveTrackAction | FindTrackAction | UpdateMetadataAction


class ModifyTracksArgs(BaseModel):
    command: Literal["modify_tracks"] = "modify_tracks"
    actions: list[ModifyTrackAction]


# ── query_features ────────────────────────────────────────────────────────────

class QueryFeaturesArgs(BaseModel):
    command: Literal["query_features"] = "query_features"
    track_id: str = Field(alias="trackId")
    summarize: bool | None = None

    model_config = {"populate_by_name": True}


# ── set_layout ────────────────────────────────────────────────────────────────

class SetLayoutArgs(BaseModel):
    command: Literal["set_layout"] = "set_layout"
    tracks: list[TrackSessionConfig]
    locus: str | None = None


# ── export_view ───────────────────────────────────────────────────────────────

class ExportViewArgs(BaseModel):
    command: Literal["export_view"] = "export_view"
    format: Literal["svg", "png", "session"]
    width: int | None = None


# ── manage_rois ───────────────────────────────────────────────────────────────

class AddROIAction(BaseModel):
    action: Literal["add"] = "add"
    roi: ROI
    set_name: str | None = Field(None, alias="setName")

    model_config = {"populate_by_name": True}


class RemoveROIAction(BaseModel):
    action: Literal["remove"] = "remove"
    roi_id: str = Field(alias="roiId")

    model_config = {"populate_by_name": True}


class UpdateROIAction(BaseModel):
    action: Literal["update"] = "update"
    roi_id: str = Field(alias="roiId")
    changes: dict[str, Any]

    model_config = {"populate_by_name": True}


class ClearROIAction(BaseModel):
    action: Literal["clear"] = "clear"


class ListROIAction(BaseModel):
    action: Literal["list"] = "list"


class ListROISetsAction(BaseModel):
    action: Literal["list_sets"] = "list_sets"


class FindROIAtLocusAction(BaseModel):
    action: Literal["find_at_locus"] = "find_at_locus"
    chr: str
    start: int
    end: int


class GetVisibleROIAction(BaseModel):
    action: Literal["get_visible"] = "get_visible"


ROIAction = (
    AddROIAction
    | RemoveROIAction
    | UpdateROIAction
    | ClearROIAction
    | ListROIAction
    | ListROISetsAction
    | FindROIAtLocusAction
    | GetVisibleROIAction
)


class ManageROIsArgs(BaseModel):
    command: Literal["manage_rois"] = "manage_rois"
    action: ROIAction


# ── subscribe_events ──────────────────────────────────────────────────────────

class SubscribeEventsArgs(BaseModel):
    """Subscribe to browser events. Use ``["*"]`` for all events, ``[]`` to unsubscribe."""

    command: Literal["subscribe_events"] = "subscribe_events"
    events: list[str]


# ── Union of all commands ─────────────────────────────────────────────────────

CommandArgs = (
    GetBrowserStateArgs
    | NavigateArgs
    | ModifyTracksArgs
    | QueryFeaturesArgs
    | SetLayoutArgs
    | ExportViewArgs
    | ManageROIsArgs
    | SubscribeEventsArgs
)


# ── Command result models ─────────────────────────────────────────────────────

class ModifyTrackActionResult(BaseModel):
    action: str
    success: bool
    track_id: str | None = Field(None, alias="trackId")
    tracks: list[TrackSummary] | None = None
    count: int | None = None
    error: str | None = None

    model_config = {"populate_by_name": True}


class ModifyTracksResult(BaseModel):
    results: list[ModifyTrackActionResult]


class QueryFeaturesResult(BaseModel):
    track_id: str = Field(alias="trackId")
    feature_count: int = Field(alias="featureCount")
    features: list[Any] | None = None
    summary: Any | None = None

    model_config = {"populate_by_name": True}


class SetLayoutResult(BaseModel):
    added: list[str]
    removed: list[str]
    unchanged: list[str]


# ManageROIs results — discriminated on ``action``

class AddROIResult(BaseModel):
    action: Literal["add"] = "add"
    roi: ROI


class RemoveROIResult(BaseModel):
    action: Literal["remove"] = "remove"
    success: bool


class UpdateROIResult(BaseModel):
    action: Literal["update"] = "update"
    roi: ROI | None = None


class ClearROIResult(BaseModel):
    action: Literal["clear"] = "clear"


class ListROIResult(BaseModel):
    action: Literal["list"] = "list"
    rois: list[ROI]


class ListROISetsResult(BaseModel):
    action: Literal["list_sets"] = "list_sets"
    sets: list[ROISetConfig]


class FindROIAtLocusResult(BaseModel):
    action: Literal["find_at_locus"] = "find_at_locus"
    rois: list[ROI]


class GetVisibleROIResult(BaseModel):
    action: Literal["get_visible"] = "get_visible"
    rois: list[ROI]


ManageROIsResult = (
    AddROIResult
    | RemoveROIResult
    | UpdateROIResult
    | ClearROIResult
    | ListROIResult
    | ListROISetsResult
    | FindROIAtLocusResult
    | GetVisibleROIResult
)


class SubscribeEventsResult(BaseModel):
    subscribed: list[str]


# ── Event data models ─────────────────────────────────────────────────────────

class LocusChangeData(BaseModel):
    locus: Locus


class SingleTrackEventData(BaseModel):
    """Used for: trackadded, trackremoved, dataloaded"""

    track_id: str = Field(alias="trackId")
    track_type: str = Field(alias="trackType")
    track_name: str | None = Field(None, alias="trackName")

    model_config = {"populate_by_name": True}


class TrackOrderChangedData(BaseModel):
    track_ids: list[str] = Field(alias="trackIds")

    model_config = {"populate_by_name": True}


class TrackErrorData(BaseModel):
    """Used for: dataerror, rendererror"""

    track_id: str = Field(alias="trackId")
    track_type: str = Field(alias="trackType")
    track_name: str | None = Field(None, alias="trackName")
    error: str

    model_config = {"populate_by_name": True}


class TrackInteractionData(BaseModel):
    """Used for: trackclick, trackhover, trackcontextmenu"""

    track_id: str = Field(alias="trackId")
    track_type: str = Field(alias="trackType")
    track_name: str | None = Field(None, alias="trackName")
    genomic_location: int = Field(alias="genomicLocation")
    feature_count: int = Field(alias="featureCount")

    model_config = {"populate_by_name": True}


class ROIEventData(BaseModel):
    """Used for: roiadded, roiremoved, roichanged"""

    roi: ROI
    set_name: str | None = Field(None, alias="setName")
    changes: dict[str, Any] | None = None

    model_config = {"populate_by_name": True}


class ROIInteractionEventData(BaseModel):
    """Used for: roiclick, roicontextmenu"""

    roi: ROI
    genomic_location: int = Field(alias="genomicLocation")
    x: float
    y: float

    model_config = {"populate_by_name": True}
