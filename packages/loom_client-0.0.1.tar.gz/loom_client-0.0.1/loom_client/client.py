from __future__ import annotations

import asyncio
import json
from collections.abc import Callable
from typing import Any, Literal

import websockets

from .exceptions import CommandException
from .models import (
    AddTrackAction,
    CommandArgs,
    ErrorDetail,
    ExportViewArgs,
    FindTrackAction,
    GetBrowserStateArgs,
    ManageROIsArgs,
    ModifyTrackAction,
    ModifyTracksArgs,
    ModifyTracksResult,
    NavigateArgs,
    ProjectedState,
    QueryFeaturesArgs,
    QueryFeaturesResult,
    ROIAction,
    RequestMessage,
    SessionConfig,
    SetLayoutArgs,
    SetLayoutResult,
    SubscribeEventsArgs,
    SubscribeEventsResult,
    TrackSessionConfig,
)


class LoomClient:
    """Async WebSocket client for the Loom Genome Browser."""

    def __init__(self, url: str) -> None:
        self._url = url
        self._ws = None
        self._pending: dict[str, asyncio.Future] = {}
        self._event_handlers: dict[str, list[Callable]] = {}
        self._listener_task: asyncio.Task | None = None

    # ── Connection management ─────────────────────────────────────────────────

    async def connect(self) -> None:
        """Open the WebSocket connection and start the background listener."""
        self._ws = await websockets.connect(self._url)
        self._listener_task = asyncio.create_task(self._listen())

    async def close(self) -> None:
        """Cancel the listener and close the WebSocket connection."""
        if self._listener_task:
            self._listener_task.cancel()
        if self._ws:
            await self._ws.close()

    # ── Message routing ───────────────────────────────────────────────────────

    async def _listen(self) -> None:
        async for raw in self._ws:
            msg = json.loads(raw)

            if "event" in msg:
                # Unsolicited server-pushed event
                event_name = msg["event"]
                for handler in self._event_handlers.get(event_name, []):
                    handler(msg["data"])
                for handler in self._event_handlers.get("*", []):
                    handler(event_name, msg["data"])

            elif "id" in msg:
                future = self._pending.pop(msg["id"], None)
                if future is None:
                    continue
                if "error" in msg:
                    err = ErrorDetail.model_validate(msg["error"])
                    future.set_exception(CommandException(err.code, err.message))
                else:
                    future.set_result(msg["result"])

    # ── Sending commands ──────────────────────────────────────────────────────

    async def send(self, args: CommandArgs) -> Any:
        """Send a command and await the correlated response."""
        req = RequestMessage(command=args.command)
        payload = args.model_dump(by_alias=True, exclude_none=True)
        payload.pop("command")
        if payload:
            req.args = payload

        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()
        self._pending[req.id] = future
        await self._ws.send(req.model_dump_json())
        return await future

    # ── Typed command methods ─────────────────────────────────────────────────

    async def get_browser_state(self, *, record: str | None = None) -> ProjectedState:
        """Return the current projected browser state."""
        result = await self.send(GetBrowserStateArgs(record=record))
        return ProjectedState.model_validate(result)

    async def navigate(
        self,
        *,
        locus: str | None = None,
        zoom: Literal["in", "out"] | None = None,
        factor: float | None = None,
    ) -> bool:
        """Navigate the viewport to a locus or zoom in/out."""
        return await self.send(NavigateArgs(locus=locus, zoom=zoom, factor=factor))

    async def modify_tracks(
        self, actions: list[ModifyTrackAction]
    ) -> ModifyTracksResult:
        """Apply one or more track modification actions."""
        result = await self.send(ModifyTracksArgs(actions=actions))
        return ModifyTracksResult.model_validate(result)

    async def query_features(
        self, track_id: str, *, summarize: bool | None = None
    ) -> QueryFeaturesResult:
        """Query features for a specific track."""
        result = await self.send(
            QueryFeaturesArgs(trackId=track_id, summarize=summarize)
        )
        return QueryFeaturesResult.model_validate(result)

    async def set_layout(
        self,
        tracks: list[TrackSessionConfig],
        *,
        locus: str | None = None,
    ) -> SetLayoutResult:
        """Replace the current track layout."""
        result = await self.send(SetLayoutArgs(tracks=tracks, locus=locus))
        return SetLayoutResult.model_validate(result)

    async def export_view(
        self,
        format: Literal["svg", "png", "session"],
        *,
        width: int | None = None,
    ) -> str | SessionConfig:
        """Export the current view as SVG, PNG, or a session config."""
        result = await self.send(ExportViewArgs(format=format, width=width))
        if format == "session":
            return SessionConfig.model_validate(result)
        return result  # SVG/PNG as string

    async def manage_rois(self, action: ROIAction) -> Any:
        """Perform a ROI management action."""
        result = await self.send(ManageROIsArgs(action=action))
        return result

    async def subscribe_events(self, events: list[str]) -> SubscribeEventsResult:
        """Subscribe to browser events. Use ``["*"]`` for all, ``[]`` to unsubscribe."""
        result = await self.send(SubscribeEventsArgs(events=events))
        return SubscribeEventsResult.model_validate(result)

    # ── Event subscription ────────────────────────────────────────────────────

    def on(self, event: str, handler: Callable) -> None:
        """Register an event handler. Use ``'*'`` for all events."""
        self._event_handlers.setdefault(event, []).append(handler)

    def off(self, event: str, handler: Callable) -> None:
        """Unregister a previously registered event handler."""
        handlers = self._event_handlers.get(event, [])
        if handler in handlers:
            handlers.remove(handler)
