from __future__ import annotations


class CommandException(Exception):
    """Raised when the server returns an error response."""

    def __init__(self, code: str, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")
