"""Test suite for TinyCTA."""
