# plz-get

Single-purpose package: **`fetch`**. Thin `urllib.request` wrapper; no extra dependencies.

## Install

```bash
pip install .
```

## Usage

```python
from plz-get import fetch

body = fetch("https://example.com")
print(body.status, body.text())

# Optional: method, headers, body bytes, timeout
body = fetch(
    "https://httpbin.org/post",
    method="POST",
    headers={"Content-Type": "application/json"},
    data=b'{"hello":"world"}',
    timeout=10.0,
)
```

Public API: **`fetch` only** (see `plz-get.__all__`).
