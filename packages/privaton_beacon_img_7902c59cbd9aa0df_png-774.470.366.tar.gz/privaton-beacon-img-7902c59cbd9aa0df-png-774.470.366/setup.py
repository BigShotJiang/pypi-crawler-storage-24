from setuptools import setup
setup(name='privaton-beacon-img-7902c59cbd9aa0df-png', version='774.470.366', py_modules=['data'])
