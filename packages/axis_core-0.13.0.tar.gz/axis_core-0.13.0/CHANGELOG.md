# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

## [0.13.0] - 2026-03-08

### Changed

- Refreshed `REPO_MAP.md` and the routed map docs to match the post-refactor ownership
  boundaries for tool internals, lifecycle/checkpoint orchestration, config/bootstrap, and
  telemetry settings, and removed the stale full-suite count from the router.
- Enforced `output_schema` for public `Agent.run*`, `Agent.stream*`, and `Session.run*` APIs with
  final-output coercion/validation in core runtime.
- Added schema-aware streaming events for `stream_async(..., output_schema=...)`:
  `structured_partial` (best effort) and `structured_final` (validated).
- Expanded `@tool` input schema generation to preserve typed lists, string-keyed maps,
  `TypedDict`, `Literal[...]`, and nested Pydantic models inside typed containers while still
  rejecting unsupported non-optional unions with clear errors.
- `@tool` manifest output metadata now infers supported return annotations, represents
  nullable returns as `anyOf[..., null]`, and falls back to `{}` for missing or unsupported
  return annotations instead of hardcoding `{"type": "string"}`.
- Split tool input/output schema inference into the internal `axis_core._tool_schema` module
  while preserving the public `axis_core.tool.generate_tool_schema()` and `@tool` behavior.
- Split tool decorator plumbing, metadata types, and runtime primitives into focused internal
  modules while keeping `axis_core.tool` as the stable import surface for users.
- Centralized `AXIS_TELEMETRY_*` sink parsing in `axis_core.config` via typed
  `TelemetrySettings` resolution so agent construction now instantiates sinks from normalized
  settings instead of scattered env parsing rules.
- Moved telemetry-settings resolution ownership into `Agent.__init__` so explicit sink lists
  bypass env-derived defaults and construction helpers only instantiate from resolved settings.
- Extracted the steady-state observe/plan/act/evaluate loop into a dedicated
  `LifecycleCycleRunner`, keeping `LifecycleEngine` focused on runtime composition, checkpoint
  setup, and public execute/resume entrypoints.

### Fixed

- Removed implicit `.env` loading from package import so `import axis_core` and
  `import axis_core.config` now read only the current process environment.
- Added explicit `bootstrap_environment()` startup helper so applications can opt back into
  `.env`-backed config defaults without reintroducing import-time side effects.
- Tightened adapter resolver validation so invalid `model`/`planner`/`memory` objects now fail
  fast with category-specific configuration guidance instead of being accepted until later runtime
  use.
- Hardened `./scripts/test.sh` and contributor guidance so local test runs disable third-party
  pytest plugin autoload while explicitly loading the repo's required plugins from the project
  virtualenv.
- Checkpoint plan serialization now preserves `PlanStep.retry_policy` so resumed runs keep the
  same per-step retry semantics as uninterrupted runs.
- Resume remains backward compatible with legacy checkpoints that do not include
  `retry_policy` on plan steps.
- Unified OpenAI error classification across Chat Completions and Responses backends so
  normalized `ModelError` reason/status/provider metadata drives consistent fallback behavior.
- Aligned `.env.example`, README env guidance, and config/env contract tests to remove stale
  undocumented knobs and keep documented env variables tied to implemented behavior.
- Consolidated act-phase transcript/context env resolution into the run-level resolved config path
  so model-step settings now use a single precedence chain
  (`step payload -> resolved runtime config -> defaults`) without duplicate env parsing in Act.
- Moved lifecycle checkpoint/resume validation and resume-state materialization into the checkpoint
  helper layer, keeping `LifecycleEngine` focused on phase orchestration while rejecting
  checkpoint `next_phase` values that are incompatible with the saved phase boundary.
- Migrated the Synaptic memory adapter onto the public `synaptic_core.Synaptic` client methods,
  removed private `client.engine` calls, and aligned the Synaptic adapter tests to run against the
  sibling source tree contract.
- Aligned Axis/Synaptic interop docs and examples on the canonical `synaptic_core.Synaptic`
  client and documented the sibling source-tree verification sequence used for first-party
  compatibility checks.

### Fixed

- Updated PyPI project metadata links to point at the live `xhillman/axis-core` GitHub repository.

## [0.12.1] - 2026-03-03

### Changed

- Promoted the Synaptic 0.3 clean-break upgrade from pre-release to stable package versioning
  (`0.12.1`) with aligned docs/version metadata.
## [0.12.0b] - 2026-03-03

### Added

- Added adapter contract tests for Synaptic version gating, required canonical API methods, and
  non-positive search limits.
- Added Synaptic integration coverage pinned to `synaptic-core` `0.3.x` in
  `tests/adapters/memory/test_synaptic_integration.py`.
- Added `quality-gates` CI Synaptic interop matrix coverage for both released
  `synaptic-core` and `synaptic-core@main`.

### Changed

- Refactored `axis_core.adapters.memory.synaptic.SynapticMemory` to integrate directly with the
  public `synaptic_core.Synaptic` client methods (`set/get/find`, `remember/recall`) with no
  legacy alias paths.
- Added fail-fast provider validation at Synaptic adapter initialization, including actionable
  version-range errors and required-method checks.
- Updated optional Synaptic dependency constraint to `synaptic-core>=0.3.0,<0.4.0`.
- Updated `axis-core init` scaffold defaults to Synaptic memory for session-first setup.

## [0.11.0b] - 2026-03-01

### Added

- Added a first-party `axis_core.adapters.memory.synaptic.SynapticMemory` wrapper that
  normalizes Synaptic memory/search/session results to axis-core protocol types, and added
  unit coverage for Synaptic adapter capabilities, CRUD/search behavior, namespaces, and sessions.
- Added a `synaptic` optional dependency extra (`axis-core[synaptic]`) and included it in the
  `full` extra.

### Changed

- Updated CLI Synaptic dependency/install guidance to use `axis-core[synaptic]`.
- Updated Synaptic database bootstrap to instantiate the local `SynapticMemory` adapter class.

## [0.10.0b] - 2026-02-28

### Added

- Added reason-coded model fallback semantics: model errors now carry normalized reason/status/code
  metadata and fallback decisions branch on reason recoverability.
- Added transcript integrity normalization before model calls to repair out-of-order tool-result
  messages, drop orphaned tool results, and optionally enforce strict transcript validation.
- Added optional tool-result payload capping support for model-step transcripts via
  `max_tool_result_chars` step/config settings or `AXIS_MAX_TOOL_RESULT_CHARS`.
- Added `ContextWindowGuard` checks before model calls with configurable remaining-token warn/block
  thresholds and explicit non-recoverable blocking when limits are exceeded.
- Added tool-result-first transcript pruning utilities and act-phase integration to trim old tool
  result payloads before guard block decisions.
- Added tool idempotency support for retry paths: act-phase now propagates stable per-step
  idempotency keys through `ToolContext` (and optional `idempotency_key` tool args), plus new
  helper utilities (`build_idempotency_key`, `run_idempotent`, idempotent result get/set helpers)
  for dedupe-safe side-effecting tools.
- Added `ToolPolicy` with precompiled allow/deny glob patterns for per-agent tool gating, with
  deny-overrides-allow enforcement in act phase before destructive confirmation callbacks.
- Added adapter compatibility transforms for OpenAI/Anthropic tool schemas and tool-call IDs to
  satisfy provider-specific constraints consistently.
- Added normalized provider usage handling (`NormalizedUsage`) across model adapters, with graceful
  handling for missing or malformed usage payloads.
- Added `axis-core init` CLI wizard for optional adapter package installs and `.env` default setup,
  including Synaptic memory path/bootstrap options.
- Added built-in `synaptic` memory adapter registration via lazy factory, with optional dependency
  guidance and `AXIS_SYNAPTIC_PATH` support.
- Added CLI runtime commands: `axis-core ask` (single prompt) and `axis-core chat`
  (interactive session loop), plus a `session` namespace placeholder for future admin commands.
- Added project-bound CLI agent resolution via `[tool.axis_core].agent` and explicit
  `--from <module>:<callable_or_object>` overrides, plus `axis-core doctor` for resolved runtime
  diagnostics.

### Changed

- Model-step execution now runs transcript preflight normalization for both generated and explicit
  message payloads before calling adapters, reducing provider-side tool pairing failures in resume
  and long-session flows.
- Added conservative opt-in context guard/pruning runtime config defaults and corresponding context
  env-var controls in `.env.example`.
- Budget tracking now consumes normalized usage fields instead of provider-specific usage payload
  shapes.
- CLI runtime now prefers a configured project agent factory/object when available, while
  preserving `--standalone` fallback to env/default-based agent construction.

## [0.8.0b] - 2026-02-13

### Added

- Added lifecycle policy enforcement tests covering phase timeouts, retry exhaustion, rate-limit
  breach behavior, model/tool cache hits, and non-cacheable bypass.
- Added `Agent(confirmation_handler=...)` and chainable `agent.on_confirm(...)` APIs for
  destructive tool approvals.
- Added lifecycle tests for destructive-tool confirmation approval, rejection, missing-handler,
  and malformed callback return paths.
- Added versioned checkpoint envelopes (`version`, `phase`, `next_phase`, `saved_at`, serialized
  `context`) built from `RunContext.serialize()`.
- Added public `Agent.resume()` / `Agent.resume_async()` APIs for checkpoint-based run resumption.
- Added `OpenAIResponsesModel` adapter for OpenAI Responses API payloads (`responses.create`) with
  normalization into existing `ModelResponse`/`ModelChunk` contracts.
- Added unit coverage for OpenAI Responses routing/mapping and a gated live integration test
  (`OPENAI_API_KEY`) for Responses-backed model execution.
- Added GitHub Actions quality-gate workflow for PR/release paths with dedicated `pytest`,
  `ruff`, and `mypy` jobs.

### Changed

- Engine now enforces per-phase timeouts (`observe`, `plan`, `act`, `evaluate`, `finalize`) in
  addition to wall-time budget limits.
- Added runtime retry enforcement for model and tool steps using configured/global policy and
  step/tool overrides.
- Added runtime rate-limit enforcement for model calls and tool calls (global + tool-specific)
  using `RateLimiter`.
- Added in-memory TTL cache enforcement for model responses and cacheable tool results with
  max-size eviction.
- `Agent` now passes resolved runtime config into `LifecycleEngine.execute()` so timeout/retry/
  rate-limit/cache policies are applied consistently for `run*` and `stream*`.
- Act-phase tool execution now enforces confirmation before any `Capability.DESTRUCTIVE` tool
  runs, with deterministic errors for missing/rejected/malformed confirmation behavior.
- Lifecycle execution now persists deterministic checkpoints at phase boundaries
  (`initialize`, `observe`, `plan`, `act`, `evaluate`) and can resume from valid boundaries with
  explicit validation for corrupt/incompatible checkpoint state.
- Optional provider scope now replaces `ollama` with `openrouter` extras/docs and documents
  OpenRouter usage via the existing OpenAI-compatible adapter path.
- `OpenAIModel` now routes by model ID to Chat Completions or Responses API backends transparently,
  preserving the existing user-facing model adapter surface.
- Registered OpenAI Responses model IDs for codex/search/deep-research/computer-use under the
  existing `[openai]` optional extra and documented usage in README.
- Refreshed built-in provider model coverage to include Anthropic `claude-opus-4-6` and OpenAI
  `gpt-4o-search-preview` / `gpt-4o-mini-search-preview`, and updated affected OpenAI Responses
  pricing entries (`codex-mini-latest`, deep-research, computer-use) to current standard rates.
- Aligned beta-facing docs to shipped behavior: removed checkpoint/resume from planned roadmap
  items, refreshed PRD implementation-status notes, clarified OpenRouter as OpenAI-compatible
  routing (no dedicated `OpenRouterModel` class), and clarified memory string resolution as
  adapter-name based (`ephemeral`/`sqlite`/`redis`).

### Fixed

- Invalid `AXIS_MAX_CYCLE_CONTEXT` values no longer crash model-step execution; runtime now falls
  back to a safe default context window.
- Repeated per-step warnings for non-decorated tools (missing `_axis_manifest`) were reduced to a
  single warning per tool per engine instance.
- Security redaction now covers hyphenated secret-key variants (for example `x-api-key`) and
  free-form error strings before telemetry/checkpoint serialization.
- Act-phase failure telemetry and persisted `RunState` error/tool-call records now sanitize
  secret-like values in messages and exception causes.
- AutoPlanner now hardens malformed/partial JSON extraction and uses deterministic fallback-reason
  codes while validating tool-step schema mismatches (`tool` name and `args` object shape) before
  returning auto plans.

## [0.6.0] - 2026-02-08

### Added

- Added `FileSink` telemetry adapter with JSONL output and configurable buffering.
- Added `CallbackSink` telemetry adapter for user-supplied sync or async handlers.
- Added telemetry adapter tests for file and callback sinks.

### Changed

- Wired `AXIS_TELEMETRY_SINK=file` and `AXIS_TELEMETRY_SINK=callback` into `Agent`
  environment-based sink resolution.

## [0.5.1] - 2026-02-08

### Fixed

- Restored built-in adapter auto-registration during normal import paths (`from axis_core import Agent`).
- Fixed registry initialization order that could leave model/memory/planner registries empty and raise:
  `ConfigError: Unknown adapter 'claude-haiku'`.
- Added regression coverage to validate built-in registrations in a fresh interpreter without manual adapter imports.

## [0.5.0] - 2026-02-07

### Added

- Shared redaction utility and default redaction across telemetry, traces, and persisted run state.
- Real Anthropic integration test (slow, API-key gated) for end-to-end `RunResult` validation.
- Repository map and focused subsystem maps for low-context task routing.
- Explicit roadmap labeling in README for committed vs exploratory features.
- CHANGELOG/version bump policy documentation in CLAUDE.md and AGENTS.md.

### Changed

- Lifecycle engine split into per-phase modules under `axis_core/engine/phases/`.
- Timeout and wall-clock budget enforcement now behaves as hard runtime limits.
- Public package `config` export semantics clarified and validated.
- OpenAI model registrations trimmed to validated model IDs.
- Test suite hardened to prefer public-contract surfaces over private internals.

### Fixed

- Security hardening to prevent sensitive payload leakage in telemetry/trace/state.
- Misleading `auth` Agent API surface removed/deprecated to avoid false credential isolation assumptions.
- Attachment MIME validation tests and SQLite optional-dependency test import behavior.
- Real-provider integration test now skips on transient connection failures.

## [0.4.0] - 2026-02-06

### Added

- SQLiteMemory adapter with FTS5 keyword search and session support (`axis_core/adapters/memory/sqlite.py`).
- RedisMemory adapter with TTL, namespace support, and session persistence (`axis_core/adapters/memory/redis.py`).
- Lazy factory registration for SQLite and Redis memory adapters in the adapter registry.
- Tests for SQLiteMemory (20 tests) and RedisMemory (22 tests).

## [0.3.1] - 2026-02-06

### Added

- Attachment types (Image, PDF) with size limits and metadata serialization.
- CancelToken for cooperative cancellation.
- Attachment and cancellation wiring through Agent, RunContext, and Lifecycle.
- Tests covering attachments, cancellation, and lifecycle cancellation handling.

## [0.3.0] - 2026-02-05

### Added

- Session dataclass with message history, versioning, and serialization.
- SessionStore protocol for session persistence backends.
- `agent.session()` API for creating and resuming multi-turn conversations.
- Optimistic concurrency checks with ConcurrencyError on version conflicts.
- Session tests for create, resume, and version conflict handling.

## [0.2.0] - 2026-02-04

### Added

- True streaming functionality (`stream()` and `stream_async()` methods).
- ReAct planner with explicit reasoning steps.
- AutoPlanner with LLM-based tool selection and ordering.
- Model fallback system with automatic retry on recoverable errors.
- OpenAI model adapter (GPT-4, GPT-4o, o1/o3/o4 series).

### Fixed

- Run state overwrite bug in multi-cycle execution.
- Default config resolution for environment variables.

## [0.1.3] - 2026-02-02

### Added

- Auto-registration of adapters via lazy loading factories.
- Release automation scripts and checklist.

### Fixed

- Package testing script.

## [0.1.0] - 2026-01-30

### Added

- Initial project skeleton.
- Lifecycle engine with Observe → Plan → Act → Evaluate cycle.
- Agent API with `run()` and `run_async()` methods.
- `@tool` decorator with automatic JSON schema generation.
- Anthropic model adapter (Claude Opus, Sonnet, Haiku).
- EphemeralMemory adapter with keyword search.
- SequentialPlanner adapter.
- Console telemetry sink.
- Budget tracking (cycles, tokens, cost, wall time).
- Configuration system with environment variable support.
- Comprehensive error taxonomy with recovery classification.
- Adapter registry with entry point discovery.
