"""E2E tests verifying the async client works against the real API."""

from __future__ import annotations

from http import HTTPStatus

import pytest

from corsa_sdk import AuthenticatedClient
from corsa_sdk.api.alerts.create_alert import _get_kwargs as create_alert_kwargs
from corsa_sdk.api.alerts.get_alert import _get_kwargs as get_alert_kwargs
from corsa_sdk.api.clients.create_individual_client import _get_kwargs as create_client_kwargs
from corsa_sdk.models.create_alert_dto import CreateAlertDto
from corsa_sdk.models.create_alert_dto_category import CreateAlertDtoCategory
from corsa_sdk.models.create_alert_dto_priority import CreateAlertDtoPriority
from corsa_sdk.models.create_alert_dto_status import CreateAlertDtoStatus
from corsa_sdk.models.create_individual_client_dto import CreateIndividualClientDto
from corsa_sdk.models.individual_client_general_information_dto import IndividualClientGeneralInformationDto


@pytest.fixture()
def _raw_client(api_url: str, api_token: str) -> AuthenticatedClient:
    return AuthenticatedClient(
        base_url=api_url,
        token=api_token,
        raise_on_unexpected_status=True,
    )


class TestAsyncAlerts:
    @pytest.mark.asyncio
    async def test_create_and_get_alert_async(self, _raw_client: AuthenticatedClient, unique_ref: str) -> None:
        httpx_client = _raw_client.get_async_httpx_client()

        body = CreateAlertDto(
            category=CreateAlertDtoCategory.FRAUD,
            description=f"Async e2e alert ({unique_ref})",
            priority=CreateAlertDtoPriority.HIGH,
            status=CreateAlertDtoStatus.NEW,
            reference_id=unique_ref,
        )

        resp = await httpx_client.request(**create_alert_kwargs(body=body))
        assert resp.status_code == HTTPStatus.CREATED
        alert_id = resp.json()["id"]

        get_resp = await httpx_client.request(**get_alert_kwargs(alert_id=alert_id))
        assert get_resp.status_code == HTTPStatus.OK

        await httpx_client.aclose()


class TestAsyncClients:
    @pytest.mark.asyncio
    async def test_create_individual_client_async(self, _raw_client: AuthenticatedClient, unique_ref: str) -> None:
        httpx_client = _raw_client.get_async_httpx_client()

        body = CreateIndividualClientDto(
            reference_id=unique_ref,
            general=IndividualClientGeneralInformationDto(
                first_name="AsyncPython",
                last_name="SDKTest",
            ),
        )

        resp = await httpx_client.request(**create_client_kwargs(body=body))
        assert resp.status_code == HTTPStatus.CREATED
        data = resp.json()
        assert data["id"]

        await httpx_client.aclose()
