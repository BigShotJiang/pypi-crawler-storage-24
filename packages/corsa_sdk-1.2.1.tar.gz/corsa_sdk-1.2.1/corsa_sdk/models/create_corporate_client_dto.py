from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_corporate_client_dto_account_status import CreateCorporateClientDtoAccountStatus
from ..models.create_corporate_client_dto_activity_status import CreateCorporateClientDtoActivityStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.corporate_client_address_dto import CorporateClientAddressDto
  from ..models.corporate_client_adverse_media_dto import CorporateClientAdverseMediaDto
  from ..models.corporate_client_application_dto import CorporateClientApplicationDto
  from ..models.corporate_client_business_dto import CorporateClientBusinessDto
  from ..models.corporate_client_general_dto import CorporateClientGeneralDto
  from ..models.corporate_client_integrations_dto import CorporateClientIntegrationsDto
  from ..models.corporate_client_pep_dto import CorporateClientPEPDto
  from ..models.corporate_client_sanctions_dto import CorporateClientSanctionsDto
  from ..models.corporate_client_screening_dto import CorporateClientScreeningDto
  from ..models.corporate_client_source_of_funds_dto import CorporateClientSourceOfFundsDto
  from ..models.create_corporate_client_dto_custom_fields import CreateCorporateClientDtoCustomFields
  from ..models.risk_dto import RiskDto





T = TypeVar("T", bound="CreateCorporateClientDto")



@_attrs_define
class CreateCorporateClientDto:
    """ 
        Attributes:
            reference_id (str | Unset): External reference ID for the corporate client Example: CORP123.
            account_status (CreateCorporateClientDtoAccountStatus | Unset): Current account status of the corporate client
                Example: APPROVED.
            activity_status (CreateCorporateClientDtoActivityStatus | Unset): Current activity status of the corporate
                client Example: ACTIVE.
            risk_history (list[RiskDto] | Unset): Historical risk assessments of the corporate client
            tags (list[str] | Unset): Tags associated with the corporate client (maximum 50) Example: ['high-value', 'tech-
                company'].
            controls (list[str] | Unset): Control measures applied to the corporate client (maximum 50) Example: ['enhanced-
                due-diligence', 'monthly-review'].
            declared_assets (list[str] | Unset): Array of asset symbols the client is expected to trade with (maximum 50)
                Example: ['BTC', 'ETH', 'USDT'].
            general (CorporateClientGeneralDto | Unset):
            address (CorporateClientAddressDto | Unset):
            application (CorporateClientApplicationDto | Unset):
            business (CorporateClientBusinessDto | Unset):
            source_of_funds_info (CorporateClientSourceOfFundsDto | Unset):
            adverse_media (CorporateClientAdverseMediaDto | Unset):
            political_exposure (CorporateClientPEPDto | Unset):
            sanctions (CorporateClientSanctionsDto | Unset):
            screening (CorporateClientScreeningDto | Unset):
            custom_fields (CreateCorporateClientDtoCustomFields | Unset): Custom fields data
            integrations (CorporateClientIntegrationsDto | Unset):
            partner_client_id (str | Unset): ID or referenceId of the partner corporate client Example:
                123e4567-e89b-12d3-a456-426614174000.
     """

    reference_id: str | Unset = UNSET
    account_status: CreateCorporateClientDtoAccountStatus | Unset = UNSET
    activity_status: CreateCorporateClientDtoActivityStatus | Unset = UNSET
    risk_history: list[RiskDto] | Unset = UNSET
    tags: list[str] | Unset = UNSET
    controls: list[str] | Unset = UNSET
    declared_assets: list[str] | Unset = UNSET
    general: CorporateClientGeneralDto | Unset = UNSET
    address: CorporateClientAddressDto | Unset = UNSET
    application: CorporateClientApplicationDto | Unset = UNSET
    business: CorporateClientBusinessDto | Unset = UNSET
    source_of_funds_info: CorporateClientSourceOfFundsDto | Unset = UNSET
    adverse_media: CorporateClientAdverseMediaDto | Unset = UNSET
    political_exposure: CorporateClientPEPDto | Unset = UNSET
    sanctions: CorporateClientSanctionsDto | Unset = UNSET
    screening: CorporateClientScreeningDto | Unset = UNSET
    custom_fields: CreateCorporateClientDtoCustomFields | Unset = UNSET
    integrations: CorporateClientIntegrationsDto | Unset = UNSET
    partner_client_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.corporate_client_address_dto import CorporateClientAddressDto
        from ..models.corporate_client_adverse_media_dto import CorporateClientAdverseMediaDto
        from ..models.corporate_client_application_dto import CorporateClientApplicationDto
        from ..models.corporate_client_business_dto import CorporateClientBusinessDto
        from ..models.corporate_client_general_dto import CorporateClientGeneralDto
        from ..models.corporate_client_integrations_dto import CorporateClientIntegrationsDto
        from ..models.corporate_client_pep_dto import CorporateClientPEPDto
        from ..models.corporate_client_sanctions_dto import CorporateClientSanctionsDto
        from ..models.corporate_client_screening_dto import CorporateClientScreeningDto
        from ..models.corporate_client_source_of_funds_dto import CorporateClientSourceOfFundsDto
        from ..models.create_corporate_client_dto_custom_fields import CreateCorporateClientDtoCustomFields
        from ..models.risk_dto import RiskDto
        reference_id = self.reference_id

        account_status: str | Unset = UNSET
        if not isinstance(self.account_status, Unset):
            account_status = self.account_status.value


        activity_status: str | Unset = UNSET
        if not isinstance(self.activity_status, Unset):
            activity_status = self.activity_status.value


        risk_history: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.risk_history, Unset):
            risk_history = []
            for risk_history_item_data in self.risk_history:
                risk_history_item = risk_history_item_data.to_dict()
                risk_history.append(risk_history_item)



        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags



        controls: list[str] | Unset = UNSET
        if not isinstance(self.controls, Unset):
            controls = self.controls



        declared_assets: list[str] | Unset = UNSET
        if not isinstance(self.declared_assets, Unset):
            declared_assets = self.declared_assets



        general: dict[str, Any] | Unset = UNSET
        if not isinstance(self.general, Unset):
            general = self.general.to_dict()

        address: dict[str, Any] | Unset = UNSET
        if not isinstance(self.address, Unset):
            address = self.address.to_dict()

        application: dict[str, Any] | Unset = UNSET
        if not isinstance(self.application, Unset):
            application = self.application.to_dict()

        business: dict[str, Any] | Unset = UNSET
        if not isinstance(self.business, Unset):
            business = self.business.to_dict()

        source_of_funds_info: dict[str, Any] | Unset = UNSET
        if not isinstance(self.source_of_funds_info, Unset):
            source_of_funds_info = self.source_of_funds_info.to_dict()

        adverse_media: dict[str, Any] | Unset = UNSET
        if not isinstance(self.adverse_media, Unset):
            adverse_media = self.adverse_media.to_dict()

        political_exposure: dict[str, Any] | Unset = UNSET
        if not isinstance(self.political_exposure, Unset):
            political_exposure = self.political_exposure.to_dict()

        sanctions: dict[str, Any] | Unset = UNSET
        if not isinstance(self.sanctions, Unset):
            sanctions = self.sanctions.to_dict()

        screening: dict[str, Any] | Unset = UNSET
        if not isinstance(self.screening, Unset):
            screening = self.screening.to_dict()

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        integrations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.integrations, Unset):
            integrations = self.integrations.to_dict()

        partner_client_id = self.partner_client_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if account_status is not UNSET:
            field_dict["accountStatus"] = account_status
        if activity_status is not UNSET:
            field_dict["activityStatus"] = activity_status
        if risk_history is not UNSET:
            field_dict["riskHistory"] = risk_history
        if tags is not UNSET:
            field_dict["tags"] = tags
        if controls is not UNSET:
            field_dict["controls"] = controls
        if declared_assets is not UNSET:
            field_dict["declaredAssets"] = declared_assets
        if general is not UNSET:
            field_dict["general"] = general
        if address is not UNSET:
            field_dict["address"] = address
        if application is not UNSET:
            field_dict["application"] = application
        if business is not UNSET:
            field_dict["business"] = business
        if source_of_funds_info is not UNSET:
            field_dict["sourceOfFundsInfo"] = source_of_funds_info
        if adverse_media is not UNSET:
            field_dict["adverseMedia"] = adverse_media
        if political_exposure is not UNSET:
            field_dict["politicalExposure"] = political_exposure
        if sanctions is not UNSET:
            field_dict["sanctions"] = sanctions
        if screening is not UNSET:
            field_dict["screening"] = screening
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if integrations is not UNSET:
            field_dict["integrations"] = integrations
        if partner_client_id is not UNSET:
            field_dict["partnerClientId"] = partner_client_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.corporate_client_address_dto import CorporateClientAddressDto
        from ..models.corporate_client_adverse_media_dto import CorporateClientAdverseMediaDto
        from ..models.corporate_client_application_dto import CorporateClientApplicationDto
        from ..models.corporate_client_business_dto import CorporateClientBusinessDto
        from ..models.corporate_client_general_dto import CorporateClientGeneralDto
        from ..models.corporate_client_integrations_dto import CorporateClientIntegrationsDto
        from ..models.corporate_client_pep_dto import CorporateClientPEPDto
        from ..models.corporate_client_sanctions_dto import CorporateClientSanctionsDto
        from ..models.corporate_client_screening_dto import CorporateClientScreeningDto
        from ..models.corporate_client_source_of_funds_dto import CorporateClientSourceOfFundsDto
        from ..models.create_corporate_client_dto_custom_fields import CreateCorporateClientDtoCustomFields
        from ..models.risk_dto import RiskDto
        d = dict(src_dict)
        reference_id = d.pop("referenceId", UNSET)

        _account_status = d.pop("accountStatus", UNSET)
        account_status: CreateCorporateClientDtoAccountStatus | Unset
        if isinstance(_account_status,  Unset):
            account_status = UNSET
        else:
            account_status = CreateCorporateClientDtoAccountStatus(_account_status)




        _activity_status = d.pop("activityStatus", UNSET)
        activity_status: CreateCorporateClientDtoActivityStatus | Unset
        if isinstance(_activity_status,  Unset):
            activity_status = UNSET
        else:
            activity_status = CreateCorporateClientDtoActivityStatus(_activity_status)




        _risk_history = d.pop("riskHistory", UNSET)
        risk_history: list[RiskDto] | Unset = UNSET
        if _risk_history is not UNSET:
            risk_history = []
            for risk_history_item_data in _risk_history:
                risk_history_item = RiskDto.from_dict(risk_history_item_data)



                risk_history.append(risk_history_item)


        tags = cast(list[str], d.pop("tags", UNSET))


        controls = cast(list[str], d.pop("controls", UNSET))


        declared_assets = cast(list[str], d.pop("declaredAssets", UNSET))


        _general = d.pop("general", UNSET)
        general: CorporateClientGeneralDto | Unset
        if isinstance(_general,  Unset):
            general = UNSET
        else:
            general = CorporateClientGeneralDto.from_dict(_general)




        _address = d.pop("address", UNSET)
        address: CorporateClientAddressDto | Unset
        if isinstance(_address,  Unset):
            address = UNSET
        else:
            address = CorporateClientAddressDto.from_dict(_address)




        _application = d.pop("application", UNSET)
        application: CorporateClientApplicationDto | Unset
        if isinstance(_application,  Unset):
            application = UNSET
        else:
            application = CorporateClientApplicationDto.from_dict(_application)




        _business = d.pop("business", UNSET)
        business: CorporateClientBusinessDto | Unset
        if isinstance(_business,  Unset):
            business = UNSET
        else:
            business = CorporateClientBusinessDto.from_dict(_business)




        _source_of_funds_info = d.pop("sourceOfFundsInfo", UNSET)
        source_of_funds_info: CorporateClientSourceOfFundsDto | Unset
        if isinstance(_source_of_funds_info,  Unset):
            source_of_funds_info = UNSET
        else:
            source_of_funds_info = CorporateClientSourceOfFundsDto.from_dict(_source_of_funds_info)




        _adverse_media = d.pop("adverseMedia", UNSET)
        adverse_media: CorporateClientAdverseMediaDto | Unset
        if isinstance(_adverse_media,  Unset):
            adverse_media = UNSET
        else:
            adverse_media = CorporateClientAdverseMediaDto.from_dict(_adverse_media)




        _political_exposure = d.pop("politicalExposure", UNSET)
        political_exposure: CorporateClientPEPDto | Unset
        if isinstance(_political_exposure,  Unset):
            political_exposure = UNSET
        else:
            political_exposure = CorporateClientPEPDto.from_dict(_political_exposure)




        _sanctions = d.pop("sanctions", UNSET)
        sanctions: CorporateClientSanctionsDto | Unset
        if isinstance(_sanctions,  Unset):
            sanctions = UNSET
        else:
            sanctions = CorporateClientSanctionsDto.from_dict(_sanctions)




        _screening = d.pop("screening", UNSET)
        screening: CorporateClientScreeningDto | Unset
        if isinstance(_screening,  Unset):
            screening = UNSET
        else:
            screening = CorporateClientScreeningDto.from_dict(_screening)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: CreateCorporateClientDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = CreateCorporateClientDtoCustomFields.from_dict(_custom_fields)




        _integrations = d.pop("integrations", UNSET)
        integrations: CorporateClientIntegrationsDto | Unset
        if isinstance(_integrations,  Unset):
            integrations = UNSET
        else:
            integrations = CorporateClientIntegrationsDto.from_dict(_integrations)




        partner_client_id = d.pop("partnerClientId", UNSET)

        create_corporate_client_dto = cls(
            reference_id=reference_id,
            account_status=account_status,
            activity_status=activity_status,
            risk_history=risk_history,
            tags=tags,
            controls=controls,
            declared_assets=declared_assets,
            general=general,
            address=address,
            application=application,
            business=business,
            source_of_funds_info=source_of_funds_info,
            adverse_media=adverse_media,
            political_exposure=political_exposure,
            sanctions=sanctions,
            screening=screening,
            custom_fields=custom_fields,
            integrations=integrations,
            partner_client_id=partner_client_id,
        )


        create_corporate_client_dto.additional_properties = d
        return create_corporate_client_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
