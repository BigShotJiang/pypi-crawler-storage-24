"""TaskingTech Desktop Agent — cross-platform native computer control."""
__version__ = "0.1.0"
