"""Clipboard operations — cross-platform using pyperclip."""

import pyperclip


def clipboard_get():
    """Read clipboard contents."""
    try:
        text = pyperclip.paste()
        return {"success": True, "text": text[:10000]}  # Cap at 10k chars
    except Exception as e:
        return {"success": False, "error": str(e)}


def clipboard_set(text):
    """Write text to clipboard."""
    try:
        pyperclip.copy(text)
        return {"success": True, "length": len(text)}
    except Exception as e:
        return {"success": False, "error": str(e)}
