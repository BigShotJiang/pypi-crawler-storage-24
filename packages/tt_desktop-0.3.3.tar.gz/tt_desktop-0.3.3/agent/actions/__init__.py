"""Desktop action handlers — cross-platform mouse, keyboard, screenshot, etc."""
