"""Keyboard control — cross-platform using pyautogui."""

import pyautogui


def keyboard_type(text):
    """Type text string."""
    try:
        # Use write() for ASCII, typewrite for special chars
        pyautogui.write(text, interval=0.02)
        return {"success": True, "typed": len(text)}
    except Exception as e:
        return {"success": False, "error": str(e)}


def keyboard_hotkey(keys):
    """Press key combination (e.g., ['ctrl', 'c'])."""
    try:
        pyautogui.hotkey(*keys)
        return {"success": True, "keys": keys}
    except Exception as e:
        return {"success": False, "error": str(e)}


def keyboard_press(key):
    """Press a single key (enter, tab, escape, etc.)."""
    try:
        pyautogui.press(key)
        return {"success": True, "key": key}
    except Exception as e:
        return {"success": False, "error": str(e)}
