"""Mouse control — cross-platform using pyautogui."""

import pyautogui

# Disable pyautogui fail-safe (move to corner to abort) — user can always Ctrl+C
pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.05  # Small delay between actions


def mouse_click(x, y, button="left", clicks=1):
    """Click at coordinates."""
    try:
        pyautogui.click(x=int(x), y=int(y), button=button, clicks=int(clicks))
        return {"success": True, "x": x, "y": y, "button": button, "clicks": clicks}
    except Exception as e:
        return {"success": False, "error": str(e)}


def mouse_move(x, y):
    """Move cursor to coordinates."""
    try:
        pyautogui.moveTo(int(x), int(y), duration=0.15)
        return {"success": True, "x": x, "y": y}
    except Exception as e:
        return {"success": False, "error": str(e)}


def mouse_drag(from_x, from_y, to_x, to_y, button="left"):
    """Drag from one point to another."""
    try:
        pyautogui.moveTo(int(from_x), int(from_y))
        pyautogui.drag(
            int(to_x) - int(from_x),
            int(to_y) - int(from_y),
            duration=0.3,
            button=button,
        )
        return {"success": True, "from": [from_x, from_y], "to": [to_x, to_y]}
    except Exception as e:
        return {"success": False, "error": str(e)}
