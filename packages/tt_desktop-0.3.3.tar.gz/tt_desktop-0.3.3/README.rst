tt-desktop
==========

TaskingTech Desktop Agent — cross-platform native computer control.

Connects to `tasking.tech <https://tasking.tech>`_ and lets TaskingBot
control your computer: mouse, keyboard, screenshots, apps, files, and more.

Quick Start
-----------

::

    pip install tt-desktop
    tt-desktop setup
    tt-desktop run

Setup will ask for your API key. Generate one from the **Desktop** tab
in the TaskingBot browser extension (tt-fab).

Commands
--------

- ``tt-desktop setup`` — Configure your API key (one-time)
- ``tt-desktop run`` — Start the agent (foreground)
- ``tt-desktop tray`` — Start with system tray icon
- ``tt-desktop status`` — Check connection status

Optional Extras
---------------

::

    pip install tt-desktop[tray]   # System tray icon
    pip install tt-desktop[ocr]    # OCR support
    pip install tt-desktop[all]    # Everything

Supported Platforms
-------------------

- Linux
- Windows
- macOS

Learn more at https://tasking.tech
