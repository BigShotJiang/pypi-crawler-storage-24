def main() -> None:
    print("Hello from graphserver!")
