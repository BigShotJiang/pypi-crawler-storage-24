"""Instagram-specific CRDT document parser.

This module provides parsing for CRDT documents containing Instagram
post data with instagrampost nodes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from marqetive.utils.crdt.exceptions import CRDTEmptyDocumentError, CRDTParseError
from marqetive.utils.crdt.models import (
    ContentType,
    InstagramCommentContent,
    InstagramPostContent,
    ParsedInstagramDocument,
)
from marqetive.utils.crdt.platforms.base import BaseCRDTParser

if TYPE_CHECKING:
    from pycrdt import Doc, XmlElement


class InstagramCRDTParser(BaseCRDTParser[ParsedInstagramDocument]):
    """Parser for Instagram CRDT documents.

    Handles parsing of instagrampost nodes. Supports feed posts, reels,
    stories, and carousels with location and music metadata.

    Validation rules:
        - Max 2200 characters for caption
        - Media is required (at least 1 item)
        - Carousel: 2-10 items
        - Reel: exactly 1 video
    """

    @property
    def platform_name(self) -> str:
        """Return the platform name."""
        return "instagram"

    @property
    def root_node_type(self) -> str:
        """Return the root node type for Instagram."""
        return "instagrampost"

    def parse_document(
        self,
        doc: Doc[Any],
        fragment_name: str = "default",
        *,
        include_auto_number: bool = False,  # noqa: ARG002
    ) -> ParsedInstagramDocument:
        """Parse an Instagram CRDT document.

        Args:
            doc: The pycrdt Doc object to parse
            fragment_name: Name of the XML fragment to parse

        Returns:
            ParsedInstagramDocument with parsed post

        Raises:
            CRDTEmptyDocumentError: If no post found
            CRDTParseError: If parsing fails
        """
        fragment = self._get_fragment(doc, fragment_name)
        raw_attributes = self._get_node_attributes(fragment)

        # Find the instagrampost node
        post_nodes = self._find_nodes_by_type(fragment, self.root_node_type)

        if not post_nodes:
            raise CRDTEmptyDocumentError(
                "No Instagram post found in document",
                fragment_name=fragment_name,
            )

        # Parse the post
        try:
            post = self._parse_post(post_nodes[0])
        except Exception as e:
            raise CRDTParseError(
                f"Failed to parse Instagram post: {e}",
                platform=self.platform_name,
                node_type=self.root_node_type,
            ) from e

        # Find and parse optional comment
        comment: InstagramCommentContent | None = None
        comment_nodes = self._find_nodes_by_type(fragment, "instagramcomment")
        if comment_nodes:
            try:
                comment = self._parse_comment(comment_nodes[0])
            except Exception as e:
                raise CRDTParseError(
                    f"Failed to parse Instagram comment: {e}",
                    platform=self.platform_name,
                    node_type="instagramcomment",
                ) from e

        return ParsedInstagramDocument(
            post=post,
            comment=comment,
            raw_attributes=raw_attributes,
            parsed_at=datetime.now(UTC),
        )

    def _parse_post(self, node: XmlElement) -> InstagramPostContent:
        """Parse an instagrampost node.

        Matches production instagram_parser.py:93-129 behavior.

        Args:
            node: The instagrampost XML node

        Returns:
            InstagramPostContent with parsed data
        """
        attrs = self._get_node_attributes(node)

        # Read post ID from attrs
        post_id = attrs.get("id")
        if post_id is not None:
            post_id = str(post_id)

        # Extract caption text
        caption = self._extract_text(node)

        # Parse media via space-separated URL strings
        media = self._parse_media_urls(node, "media")

        # Parse content type from "content_type" attr (production uses this name)
        content_type_str = attrs.get("content_type", "POST")
        content_type = self._parse_content_type(str(content_type_str))

        # Read location as simple string
        location = attrs.get("location")
        if location is not None:
            location = str(location)

        # Read music as simple string
        music = attrs.get("music")
        if music is not None:
            music = str(music)

        # Parse share_to_feed bool (defaults to True when attr is absent)
        share_to_feed_val = attrs.get("share_to_feed")
        share_to_feed = True
        if share_to_feed_val is not None:
            if isinstance(share_to_feed_val, bool):
                share_to_feed = share_to_feed_val
            else:
                share_to_feed = str(share_to_feed_val).strip().lower() != "false"

        # Read location_name as simple string
        location_name = attrs.get("location_name")
        if location_name is not None:
            location_name = str(location_name)

        # Read cover_url as simple string
        cover_url = attrs.get("cover_url")
        if cover_url is not None:
            cover_url = str(cover_url)

        return InstagramPostContent(
            id=post_id,
            caption=caption,
            media=media,
            content_type=content_type,
            location=location,
            music=music,
            share_to_feed=share_to_feed,
            location_name=location_name,
            cover_url=cover_url,
        )

    def _parse_content_type(self, content_type_str: str) -> ContentType:
        """Parse content type string to enum.

        Handles uppercase values matching production behavior.

        Args:
            content_type_str: Content type string

        Returns:
            ContentType enum value
        """
        content_type_map = {
            "POST": ContentType.POST,
            "REEL": ContentType.REEL,
            "STORY": ContentType.STORY,
            "CAROUSEL": ContentType.CAROUSEL,
            "FEED": ContentType.FEED,
        }

        return content_type_map.get(content_type_str.strip().upper(), ContentType.POST)

    def _parse_comment(self, node: XmlElement) -> InstagramCommentContent:
        """Parse an instagramcomment node.

        Args:
            node: The instagramcomment XML node

        Returns:
            InstagramCommentContent with parsed data
        """
        attrs = self._get_node_attributes(node)
        comment_id = attrs.get("id")
        if comment_id is not None:
            comment_id = str(comment_id)
        text = self._extract_text(node)

        return InstagramCommentContent(id=comment_id, text=text)
