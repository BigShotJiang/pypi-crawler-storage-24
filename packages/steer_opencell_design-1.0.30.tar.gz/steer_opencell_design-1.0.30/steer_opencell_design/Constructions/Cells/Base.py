"""Base class for complete battery cells."""

from steer_opencell_design.Constructions.ElectrodeAssemblies.Base import _ElectrodeAssembly
from steer_opencell_design.Components.Containers.Base import _Container
from steer_opencell_design.Utils.Decorators import calculate_electrochemical_properties
from steer_core.Utils import round_dict_recursive
from steer_opencell_design.Components.Electrodes import Cathode, Anode
from steer_opencell_design.Components.Separators import Separator

from steer_opencell_design.Materials.Electrolytes import Electrolyte

from steer_materials.Base import _Material

from steer_core.Mixins.Coordinates import CoordinateMixin
from steer_core.Mixins.TypeChecker import ValidationMixin
from steer_core.Mixins.Serializer import SerializerMixin
from steer_core.Mixins.Colors import ColorMixin
from steer_core.Mixins.Dunder import DunderMixin
from steer_core.Mixins.Plotter import PlotterMixin
from steer_core.Mixins.Data import DataMixin
from steer_core.Mixins.Propagation import PropagationMixin, propagating_setter

from steer_core.Decorators.General import calculate_all_properties

from steer_core.Constants.Units import *

from abc import ABC, abstractmethod
from copy import deepcopy
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from typing import Any, Dict, List, Tuple
import re
from scipy.optimize import brentq


# Module-level constants for calculations and formatting
VOLTAGE_GUIDE_MARGIN_LOWER = 0.95
VOLTAGE_GUIDE_MARGIN_UPPER = 1.05
CAPACITY_GUIDE_EXTENSION = 1.1

# Precision constants for different property types
MASS_PRECISION = 2
ENERGY_PRECISION = 2
CAPACITY_PRECISION = 2
VOLTAGE_PRECISION = 2
CURVE_PRECISION = 4
COST_PRECISION = 2


class _Cell(
    ABC,
    DunderMixin,
    ValidationMixin,
    ColorMixin,
    PlotterMixin,
    PropagationMixin,
    SerializerMixin,
    DataMixin,
    CoordinateMixin,
):
    """Abstract base class for complete battery cells. Provides common properties for energy, mass, cost, capacity curves, and voltage window management. Subclasses implement format-specific geometry (cylindrical, prismatic, pouch, flex-frame)."""

    def __init__(
        self,
        reference_electrode_assembly: _ElectrodeAssembly,
        encapsulation: _Container,
        n_electrode_assembly: int,
        electrolyte: Electrolyte,
        electrolyte_overfill: float,
        operating_voltage_window: Tuple[float, float] = (None, None),
        name: str = "Cell",
    ):
        self._update_properties = False

        self.reference_electrode_assembly = reference_electrode_assembly
        self.encapsulation = encapsulation
        self.n_electrode_assembly = n_electrode_assembly
        self.electrolyte = electrolyte
        self.electrolyte_overfill = electrolyte_overfill
        self.operating_voltage_window = operating_voltage_window
        self.name = name
    
    @abstractmethod
    def _calculate_all_properties(self) -> None:
        self._calculate_bulk_properties()
        self._calculate_electrochemical_properties()
        self._calculate_capacity_ranges()  # Cache ranges to avoid recalculation on property access

    def _convert_to_cell_type(self, new_encapsulation: _Container) -> None:
        """Convert cell to appropriate type based on encapsulation type.
        
        When an encapsulation of a different type is set (e.g., setting a PouchEncapsulation
        on a PrismaticCell), this method converts the cell to the appropriate type while
        preserving all electrode assembly and electrolyte properties.
        
        Only conversions between PrismaticCell and PouchCell are supported, as both
        use compatible electrode assembly types (ZFoldStack, PunchedStack, FlatWoundJellyRoll).
        CylindricalCell uses WoundJellyRoll which is incompatible with the other cell types.
        
        Parameters
        ----------
        new_encapsulation : _Container
            The new encapsulation that requires a different cell type
            
        Notes
        -----
        This performs an in-place conversion by copying all attributes from a newly
        created cell of the appropriate type into self.
        """
        from steer_opencell_design.Components.Containers.Prismatic import PrismaticEncapsulation
        from steer_opencell_design.Components.Containers.Pouch import PouchEncapsulation
        
        # Determine target cell type based on encapsulation type
        if isinstance(new_encapsulation, PrismaticEncapsulation):
            from steer_opencell_design.Constructions.Cells.PrismaticCell import PrismaticCell
            target_cell_class = PrismaticCell
            extra_kwargs = {
                'clipped_tab_length': getattr(self, '_clipped_tab_length', None) and self._clipped_tab_length * M_TO_MM
            }
        elif isinstance(new_encapsulation, PouchEncapsulation):
            from steer_opencell_design.Constructions.Cells.PouchCell import PouchCell
            target_cell_class = PouchCell
            extra_kwargs = {
                'side_seal_thickness': getattr(self, '_side_seal_thickness', None) and self._side_seal_thickness * M_TO_MM or 5.0,
                'top_seal_thickness': getattr(self, '_top_seal_thickness', None) and self._top_seal_thickness * M_TO_MM or 5.0,
                'bottom_seal_thickness': getattr(self, '_bottom_seal_thickness', None) and self._bottom_seal_thickness * M_TO_MM or 5.0,
                'clipped_tab_length': getattr(self, '_clipped_tab_length', None) and self._clipped_tab_length * M_TO_MM
            }
        else:
            raise TypeError(f"Unknown encapsulation type: {type(new_encapsulation).__name__}")
        
        # Create new cell of the appropriate type with current properties
        new_cell = target_cell_class(
            reference_electrode_assembly=self._reference_electrode_assembly,
            n_electrode_assembly=self._n_electrode_assembly,
            encapsulation=new_encapsulation,
            electrolyte=self._electrolyte,
            operating_voltage_window=self._operating_voltage_window,
            electrolyte_overfill=self._electrolyte_overfill,
            name=self._name,
            **extra_kwargs
        )
        
        # Copy all attributes from new cell to self (in-place conversion)
        self.__class__ = target_cell_class
        self.__dict__.update(new_cell.__dict__)
        
        # Restore parent references so children point to self, not new_cell
        self._restore_child_parent_refs()

    def _calculate_bulk_properties(self) -> None:
        self._calculate_electrolyte_properties()
        self._calculate_mass_properties()
        self._calculate_cost_properties()

    def _calculate_electrochemical_properties(self) -> None:
        self._calculate_curves()
        self._calculate_operating_voltage_window()
        self._calculate_upper_voltage_limit_range()
        self._calculate_lower_voltage_limit_range()
        self._calculate_reversible_capacity()
        self._calculate_irreversible_capacity()
        self._calculate_capacity_loss()
        self._calculate_energy_properties()

    def _calculate_curves(self) -> None:
        """Calculate all capacity curves for the cell."""
        self._calculate_capacity_curve()
        self._calculate_cathode_curve()
        self._calculate_anode_curve()

    def _calculate_operating_voltage_window(self) -> None:
        self._minimum_operating_voltage = self._reference_electrode_assembly._layup._minimum_operating_voltage
        self._maximum_operating_voltage = self._reference_electrode_assembly._layup._maximum_operating_voltage
        self._operating_voltage_window = (self._minimum_operating_voltage, self._maximum_operating_voltage)

    def _calculate_upper_voltage_limit_range(self) -> None:
        self._maximum_operating_voltage_range = self._reference_electrode_assembly._layup._maximum_operating_voltage_range
        return self._maximum_operating_voltage_range
    
    def _calculate_lower_voltage_limit_range(self) -> None:
        self._minimum_operating_voltage_range = self._reference_electrode_assembly._layup._minimum_operating_voltage_range
        return self._minimum_operating_voltage_range

    def _calculate_electrolyte_properties(self) -> None:
        """Calculate electrolyte volume based on pore volume and overfill."""
        # Calculate total pore volume from all electrode assemblies
        self._pore_volume = sum([ea._pore_volume for ea in self._electrode_assemblies])

        # Set electrolyte ranges based on pore volume
        self._electrolyte._set_ranges_from_pore_volume(self._pore_volume)

        # Calculate electrolyte volume with overfill
        _electrolyte_volume = self._pore_volume * (1 + self._electrolyte_overfill)

        # Set electrolyte volume
        electrolyte_volume = _electrolyte_volume * M_TO_CM ** 3

        # Assign volume to electrolyte
        self._electrolyte.volume = electrolyte_volume

    def _make_assemblies(self) -> list[_ElectrodeAssembly]:
        """Create electrode assemblies as deep copies of the reference assembly.
        
        Always performs deep copies to ensure cost and property propagation
        works correctly when the reference assembly's internal state changes.
        
        Returns
        -------
        list[_ElectrodeAssembly]
            List of electrode assembly instances
        """
        # Create the electrode assemblies based on the reference assembly and number of assemblies
        self._electrode_assemblies = [deepcopy(self._reference_electrode_assembly) for _ in range(self._n_electrode_assembly)]

        # Clear their cached data
        for assembly in self._electrode_assemblies:
            assembly._clear_cached_data()

        return self._electrode_assemblies
    
    def _position_encapsulation(self) -> None:
        """Position encapsulation centered around electrode assemblies.
        
        Uses the _get_center_point method from each assembly to calculate the
        geometric center, then positions the encapsulation accordingly.
        """
        # Get center point from reference assembly (x, y coordinates)
        reference_center = self._electrode_assemblies[0]._get_center_point()
        mid_x = reference_center[0] * M_TO_MM
        mid_y = reference_center[1] * M_TO_MM
        
        # Calculate z-position as midpoint between all assemblies
        assembly_z_datums = [assembly._datum[2] for assembly in self._electrode_assemblies]
        max_z = max(assembly_z_datums) + (self._reference_electrode_assembly._thickness) / 2
        min_z = min(assembly_z_datums) - (self._reference_electrode_assembly._thickness) / 2
        mid_z = (max_z + min_z) / 2 * M_TO_MM

        # Position the encapsulation centered around the electrode assembly stack
        self._encapsulation.datum = (
            mid_x,
            mid_y,
            mid_z
        )

    def _position_assemblies(self) -> None:

        # get center point of the reference assembly
        _center_x, _center_y, _ = self._electrode_assemblies[0]._get_center_point()

        # get x and y datum positions from the reference assembly
        _datum_x, _datum_y, _ = self._electrode_assemblies[0]._datum

        # get translation to center assemblies at origin
        translation_x = _center_x - _datum_x
        translation_y = _center_y - _datum_y

        # get new datum positions for x and y
        new_datum_x = _datum_x - translation_x
        new_datum_y = _datum_y - translation_y

        # get the z values
        if hasattr(self._reference_electrode_assembly, "_thickness"):
            thickness = self._reference_electrode_assembly._thickness
        elif hasattr(self._reference_electrode_assembly, "_radius"):
            thickness = self._reference_electrode_assembly._radius

        # make z-grid centered at 0 with self._n_electrode_assembly points spaced by self._reference_electrode_assembly._thickness
        z_positions = np.linspace(
            -((self.n_electrode_assembly - 1) / 2) * thickness,
            ((self.n_electrode_assembly - 1) / 2) * thickness,
            self.n_electrode_assembly,
        )

        # position each assembly at the corresponding z position
        for assembly, z in zip(self._electrode_assemblies, z_positions):

            assembly.datum = (
                new_datum_x * M_TO_MM,
                new_datum_y * M_TO_MM,
                z * M_TO_MM
            )

    def _format_curve_for_display(self, curve: np.ndarray, scale_factor: float = S_TO_H) -> pd.DataFrame:
        """Convert raw curve array to formatted DataFrame with spline interpolation point.
        
        Parameters
        ----------
        curve : np.ndarray
            Raw curve array with columns [capacity, voltage, direction]
        scale_factor : float, optional
            Scaling factor for capacity values (default: S_TO_H)
            
        Returns
        -------
        pd.DataFrame
            Formatted DataFrame with columns: Capacity (Ah), Voltage (V), Direction, direction
        """
        curve = curve.copy()
        curve[:, 0] *= scale_factor
        
        # Split into charge and discharge curves
        charge_curve = curve[curve[:, 2] == 1]
        discharge_curve = curve[curve[:, 2] == -1]
        
        # Add end point for spline interpolation
        charge_curve = np.vstack((charge_curve, charge_curve[-1, :]))
        combined_curve = np.vstack((charge_curve, discharge_curve))

        # round curves
        combined_curve = np.round(combined_curve, CURVE_PRECISION)
        
        # Create DataFrame with all columns at once (more efficient)
        return pd.DataFrame({
            "Capacity (Ah)": combined_curve[:, 0],
            "Voltage (V)": combined_curve[:, 1],
            "Direction": combined_curve[:, 2],
            "direction": np.where(combined_curve[:, 2] == 1, "charge", "discharge")
        })
    
    def _create_vertical_guide_trace(self, x_value: float, label: str, color: str) -> go.Scatter:
        """Create a vertical guide line at specified x-value.
        
        Parameters
        ----------
        x_value : float
            X-coordinate for the vertical line
        label : str
            Display name for the trace
        color : str
            Line color
            
        Returns
        -------
        go.Scatter
            Plotly scatter trace for the vertical guide line
        """
        voltage_values = self.capacity_curve["Voltage (V)"]
        min_voltage = voltage_values.min()
        max_voltage = voltage_values.max()

        y_range = [
            min(min_voltage * VOLTAGE_GUIDE_MARGIN_LOWER, 0),
            max_voltage * VOLTAGE_GUIDE_MARGIN_UPPER
        ]

        return go.Scatter(
            x=[x_value, x_value],
            y=y_range,
            mode="lines",
            name=label,
            line=dict(color=color, width=2, dash="dash"),
            legendgroup="guides",
            showlegend=True,
        )
    
    def _create_horizontal_guide_trace(self, y_value: float, label: str, color: str) -> go.Scatter:
        """Create a horizontal guide line at specified y-value.
        
        Parameters
        ----------
        y_value : float
            Y-coordinate for the horizontal line
        label : str
            Display name for the trace
        color : str
            Line color
            
        Returns
        -------
        go.Scatter
            Plotly scatter trace for the horizontal guide line
        """
        capacity_values = self.capacity_curve["Capacity (Ah)"]
        max_capacity = capacity_values.max()
        min_capacity = capacity_values.min()

        x_range = [
            min_capacity * CAPACITY_GUIDE_EXTENSION, 
            max_capacity * CAPACITY_GUIDE_EXTENSION
        ]

        return go.Scatter(
            x=x_range,
            y=[y_value, y_value],
            mode="lines",
            name=label,
            line=dict(color=color, width=2, dash="dash"),
            legendgroup="guides",
            showlegend=True,
        )

    def _calculate_capacity_curve(self) -> np.ndarray:
        
        # get the full cell curve from the reference electrode assembly and scale it by the number of assemblies
        _capacity_curve = self._reference_electrode_assembly._capacity_curve.copy()
        _capacity_curve[:, 0] = _capacity_curve[:, 0] * self._n_electrode_assembly
        
        # cut the discharge curve off at the self._minimum_operating_voltage
        _charge_curve = _capacity_curve[_capacity_curve[:, 2] == 1]
        _discharge_curve = _capacity_curve[_capacity_curve[:, 2] == -1]
        
        # add a point in the discharge curve where voltage equals self._minimum_operating_voltage
        _min_op_voltage = self._reference_electrode_assembly._layup._minimum_operating_voltage

        # find the indices surrounding the min operating voltage
        above_indices = np.where(_discharge_curve[:, 1] >= _min_op_voltage)[0]
        below_indices = np.where(_discharge_curve[:, 1] <= _min_op_voltage)[0]
        
        # Check if min voltage is exactly on an existing point
        exact_match = np.where(np.isclose(_discharge_curve[:, 1], _min_op_voltage))[0]
        
        if len(exact_match) > 0:
            # Min voltage is exactly on a point, truncate points below this index
            match_idx = exact_match[0]
            _discharge_curve = _discharge_curve[:match_idx + 1]
        elif len(above_indices) > 0 and len(below_indices) > 0:
            # Need to interpolate between two points
            above_idx = above_indices[-1]
            below_idx = below_indices[0]
            
            # linear interpolation to find the capacity at min operating voltage
            v1, c1 = _discharge_curve[above_idx, 1], _discharge_curve[above_idx, 0]
            v2, c2 = _discharge_curve[below_idx, 1], _discharge_curve[below_idx, 0]

            slope = (c2 - c1) / (v2 - v1)
            c_min_op = c1 + slope * (_min_op_voltage - v1)

            # create new point
            new_point = np.array([[c_min_op, _min_op_voltage, -1]])

            # truncate the discharge curve up to above_idx and append the new point
            _discharge_curve = np.vstack((_discharge_curve[:above_idx + 1], new_point))
        # else: min voltage is outside the discharge curve range, keep full discharge curve

        # recombine the charge and discharge curves
        _capacity_curve = np.vstack((_charge_curve, _discharge_curve))

        self._capacity_curve = _capacity_curve

        return self._capacity_curve

    def _calculate_cathode_curve(self) -> np.ndarray:
        """Calculate scaled cathode capacity curve for the cell.
        
        Returns
        -------
        np.ndarray
            Cathode capacity curve scaled by number of electrode assemblies
        """
        _cathode_capacity_curve = self._reference_electrode_assembly._cathode_capacity_curve.copy()
        _cathode_capacity_curve[:, 0] = _cathode_capacity_curve[:, 0] * self._n_electrode_assembly
        self._cathode_capacity_curve = _cathode_capacity_curve
        return self._cathode_capacity_curve

    def _calculate_anode_curve(self) -> np.ndarray:
        """Calculate scaled anode capacity curve for the cell.
        
        Returns
        -------
        np.ndarray
            Anode capacity curve scaled by number of electrode assemblies
        """
        _anode_capacity_curve = self._reference_electrode_assembly._anode_capacity_curve.copy()
        _anode_capacity_curve[:, 0] = _anode_capacity_curve[:, 0] * self._n_electrode_assembly
        self._anode_capacity_curve = _anode_capacity_curve
        return self._anode_capacity_curve

    def _calculate_reversible_capacity(self) -> float:
        _discharge_mask = self._capacity_curve[:, 2] == -1
        _discharge_curve = self._capacity_curve[_discharge_mask]
        _max_cap = (_discharge_curve[:, 0]).max()
        _min_cap = (_discharge_curve[:, 0]).min()
        self._reversible_capacity = _max_cap - _min_cap

    def _calculate_irreversible_capacity(self) -> float:
        """Calculate irreversible (total) capacity - the max capacity reached at full charge."""
        _discharge_mask = self._capacity_curve[:, 2] == -1
        _discharge_curve = self._capacity_curve[_discharge_mask]
        self._irreversible_capacity = _discharge_curve[:, 0].max()

    def _calculate_capacity_loss(self) -> float:
        """Calculate capacity loss - the capacity remaining at minimum voltage."""
        _discharge_mask = self._capacity_curve[:, 2] == -1
        _discharge_curve = self._capacity_curve[_discharge_mask]
        self._capacity_loss = _discharge_curve[:, 0].min()

    def _calculate_capacity_ranges(self) -> None:
        """Calculate and cache reversible and irreversible capacity ranges.
        
        Uses targeted temporary state mutation instead of full deepcopy.
        Only the electrochemical state (voltage cutoffs, capacity curves) is
        saved and restored, avoiding the cost of copying the entire cell
        hierarchy (encapsulation, coordinate arrays, etc.).
        """
        max_v_lower, max_v_upper = self._maximum_operating_voltage_range
        min_v_lower, min_v_upper = self._minimum_operating_voltage_range

        layup = self._reference_electrode_assembly._layup
        assembly = self._reference_electrode_assembly

        # Save electrochemical state that will be modified during probing
        saved = self._snapshot_electrochemical_state()

        # Break parent chain at layup level so Brent's method
        # does not propagate recalculations up to assembly/cell
        old_layup_parent = layup._parent
        old_layup_parent_attr = layup._parent_attr_name
        layup._parent = None
        layup._parent_attr_name = None

        try:
            # --- Probe irreversible capacity at max voltage boundaries ---
            # The max voltage setter runs Brent's method to find the
            # cathode cutoff, then recomputes layup areal curves.
            layup.maximum_operating_voltage = max_v_upper
            assembly._calculate_capacity_curves()
            self._calculate_capacity_curve()
            self._calculate_irreversible_capacity()
            irr_at_high_voltage = self.irreversible_capacity

            layup.maximum_operating_voltage = max_v_lower
            assembly._calculate_capacity_curves()
            self._calculate_capacity_curve()
            self._calculate_irreversible_capacity()
            irr_at_low_voltage = self.irreversible_capacity

            # Restore before min-voltage probing (needs original curves)
            self._restore_electrochemical_state(saved)

            # --- Probe reversible capacity / capacity loss at min voltage boundaries ---
            # Minimum voltage only controls where the discharge curve is
            # truncated in the cell curve — no Brent's or curve recomputation.
            layup._minimum_operating_voltage = min_v_upper
            self._calculate_capacity_curve()
            self._calculate_reversible_capacity()
            self._calculate_capacity_loss()
            rev_at_high_min_voltage = self.reversible_capacity
            loss_at_high_min_voltage = self.capacity_loss

            layup._minimum_operating_voltage = min_v_lower
            self._calculate_capacity_curve()
            self._calculate_reversible_capacity()
            self._calculate_capacity_loss()
            rev_at_low_min_voltage = self.reversible_capacity
            loss_at_low_min_voltage = self.capacity_loss

        finally:
            # Always restore original state + parent chain
            self._restore_electrochemical_state(saved)
            layup._parent = old_layup_parent
            layup._parent_attr_name = old_layup_parent_attr

        # Cache ranges
        self._irreversible_capacity_range_cache = (
            np.round(min(irr_at_low_voltage, irr_at_high_voltage), CAPACITY_PRECISION),
            np.round(max(irr_at_low_voltage, irr_at_high_voltage), CAPACITY_PRECISION)
        )
        self._reversible_capacity_range_cache = (
            np.round(min(rev_at_high_min_voltage, rev_at_low_min_voltage), CAPACITY_PRECISION),
            np.round(max(rev_at_high_min_voltage, rev_at_low_min_voltage), CAPACITY_PRECISION)
        )
        self._capacity_loss_range_cache = (
            np.round(min(loss_at_high_min_voltage, loss_at_low_min_voltage), CAPACITY_PRECISION),
            np.round(max(loss_at_high_min_voltage, loss_at_low_min_voltage), CAPACITY_PRECISION)
        )

    def _snapshot_electrochemical_state(self) -> dict:
        """Save the minimal electrochemical state needed to restore after probing."""
        layup = self._reference_electrode_assembly._layup
        assembly = self._reference_electrode_assembly
        cathode = layup._cathode
        formulation = cathode._formulation

        return {
            # Layup scalars
            'layup_max_v': layup._maximum_operating_voltage,
            'layup_min_v': layup._minimum_operating_voltage,
            'layup_op_window': layup._operating_voltage_window,
            'layup_np_ratio': getattr(layup, '_np_ratio', None),
            # Formulation state (modified by Brent's method)
            'formulation_cutoff': formulation._voltage_cutoff,
            'formulation_spec_curve': formulation._specific_capacity_curve.copy()
                if getattr(formulation, '_specific_capacity_curve', None) is not None else None,
            'formulation_cap_curve': formulation._capacity_curve.copy()
                if getattr(formulation, '_capacity_curve', None) is not None else None,
            # Areal curves
            'cathode_areal': cathode._areal_capacity_curve.copy()
                if getattr(cathode, '_areal_capacity_curve', None) is not None else None,
            'layup_areal': layup._areal_capacity_curve.copy()
                if getattr(layup, '_areal_capacity_curve', None) is not None else None,
            # Assembly curves
            'assembly_curve': assembly._capacity_curve.copy()
                if getattr(assembly, '_capacity_curve', None) is not None else None,
            'assembly_cathode_curve': assembly._cathode_capacity_curve.copy()
                if getattr(assembly, '_cathode_capacity_curve', None) is not None else None,
            # Cell curves & scalars
            'cell_curve': self._capacity_curve.copy()
                if getattr(self, '_capacity_curve', None) is not None else None,
            'cell_max_v': self._maximum_operating_voltage,
            'cell_min_v': self._minimum_operating_voltage,
            'cell_op_window': self._operating_voltage_window,
            # Derived scalars (modified during probing)
            'cell_reversible_cap': self._reversible_capacity,
            'cell_irreversible_cap': self._irreversible_capacity,
            'cell_capacity_loss': self._capacity_loss,
        }

    def _restore_electrochemical_state(self, s: dict) -> None:
        """Restore electrochemical state from a snapshot."""
        layup = self._reference_electrode_assembly._layup
        assembly = self._reference_electrode_assembly
        cathode = layup._cathode
        formulation = cathode._formulation

        # Restore in reverse order of dependencies
        formulation._voltage_cutoff = s['formulation_cutoff']
        if s['formulation_spec_curve'] is not None:
            formulation._specific_capacity_curve = s['formulation_spec_curve']
        if s['formulation_cap_curve'] is not None:
            formulation._capacity_curve = s['formulation_cap_curve']
        if s['cathode_areal'] is not None:
            cathode._areal_capacity_curve = s['cathode_areal']

        layup._maximum_operating_voltage = s['layup_max_v']
        layup._minimum_operating_voltage = s['layup_min_v']
        layup._operating_voltage_window = s['layup_op_window']
        if s['layup_np_ratio'] is not None:
            layup._np_ratio = s['layup_np_ratio']
        if s['layup_areal'] is not None:
            layup._areal_capacity_curve = s['layup_areal']

        if s['assembly_curve'] is not None:
            assembly._capacity_curve = s['assembly_curve']
        if s['assembly_cathode_curve'] is not None:
            assembly._cathode_capacity_curve = s['assembly_cathode_curve']

        if s['cell_curve'] is not None:
            self._capacity_curve = s['cell_curve']
        self._maximum_operating_voltage = s['cell_max_v']
        self._minimum_operating_voltage = s['cell_min_v']
        self._operating_voltage_window = s['cell_op_window']
        self._reversible_capacity = s['cell_reversible_cap']
        self._irreversible_capacity = s['cell_irreversible_cap']
        self._capacity_loss = s['cell_capacity_loss']

    def _calculate_mass_properties(self) -> tuple[float, Dict]:
        
        _assembly_mass = sum([assembly._mass for assembly in self._electrode_assemblies])
        _electrolyte_mass = self._electrolyte._mass
        _encapsulation_mass = self._encapsulation._mass

        self._mass = _assembly_mass + _electrolyte_mass + _encapsulation_mass

        self._mass_breakdown = {
            "Electrode Assemblies": self.sum_breakdowns(self._electrode_assemblies, "mass"),
            "Electrolyte": _electrolyte_mass,
            "Encapsulation": self._encapsulation._mass_breakdown,
        }

        return self._mass, self._mass_breakdown

    def _calculate_cost_properties(self) -> tuple[float, Dict]:
        
        _assembly_cost = sum([assembly._cost for assembly in self._electrode_assemblies])
        _electrolyte_cost = self._electrolyte._cost
        _encapsulation_cost = self._encapsulation._cost

        self._cost = _assembly_cost + _electrolyte_cost + _encapsulation_cost

        self._cost_breakdown = {
            "Electrode Assemblies": self.sum_breakdowns(self._electrode_assemblies, "cost"),
            "Electrolyte": _electrolyte_cost,
            "Encapsulation": self._encapsulation._cost_breakdown,
        }

        return self._cost, self._cost_breakdown

    def _calculate_energy_properties(self) -> tuple[float, Dict]:
        
        # calculate energyin W * s
        _discharge_curve = self._capacity_curve[self._capacity_curve[:, 2] == -1]
        _discharge_curve = _discharge_curve[np.argsort(_discharge_curve[:, 0])]
        _area_under_curve = np.trapezoid(_discharge_curve[:, 1], _discharge_curve[:, 0])
        self._energy = _area_under_curve

        # get gravimetric energy
        self._specific_energy = self._energy / self._mass

        # get volumetric energy
        self._volumetric_energy = self._energy / self._encapsulation._volume

        # get normalised cost
        self._cost_per_energy = self._cost / self._energy
     
    def get_capacity_plot(
        self,
        include_guides: bool = True,
        show_operating_window: bool = True,
        show_capacity_markers: bool = True,
        **kwargs,
    ) -> go.Figure:
        """Return a styled capacity vs. voltage plot for the cell.

        The plot overlays full-cell, cathode half-cell, and anode half-cell
        capacity curves and optionally annotates key electrochemical guide
        markers (reversible/irreversible capacities and operating voltage
        window limits).

        Parameters
        ----------
        include_guides : bool, optional
            If True, draw all guide lines / annotations (default True).
        show_operating_window : bool, optional
            If True, annotate min/max operating voltages (default True).
        show_capacity_markers : bool, optional
            If True, annotate irreversible & reversible capacities (default True).
        **kwargs : Any
            Additional layout overrides (e.g. title, colors, backgrounds).

        Returns
        -------
        go.Figure
            Plotly figure containing the capacity curves.
        """
        # Basic validation – ensure curves are computed
        if not hasattr(self, "_capacity_curve"):
            raise ValueError("Capacity curve data not available. Ensure properties are calculated.")

        fig = go.Figure()

        # Collect all traces to add at once
        traces = [
            self.cathode_capacity_curve_trace,
            self.anode_capacity_curve_trace,
            self.capacity_curve_trace,
            self.integrated_capacity_area_trace,
        ]

        # Add guide traces conditionally
        if include_guides:
            if show_capacity_markers:
                traces.extend([
                    self.capacity_loss_guide_trace,
                    self.irreversible_capacity_guide_trace,
                    self.reversible_capacity_guide_trace,
                ])
            
            if show_operating_window:
                traces.extend([
                    self.minimum_voltage_guide_trace,
                    self.maximum_voltage_guide_trace,
                ])

        # Add all traces at once for better performance
        fig.add_traces(traces)

        # get maximum voltage for y axis
        x_max = max(self._reference_electrode_assembly._layup._cathode._formulation._voltage_operation_window)

        # Layout styling
        fig.update_layout(
            paper_bgcolor=kwargs.get("paper_bgcolor", "white"),
            plot_bgcolor=kwargs.get("plot_bgcolor", "white"),
            xaxis={**self.SCATTER_X_AXIS, "title": "Capacity (Ah)"},
            yaxis={**self.SCATTER_Y_AXIS, "title": "Voltage (V)", "range": [0, x_max]},
            hovermode="closest",
            **kwargs
        )

        return fig
        
    def plot_mass_breakdown(self, title: str = None, **kwargs) -> go.Figure:
        """Generate a sunburst mass breakdown chart."""

        fig = self.plot_breakdown_sunburst(
            self.mass_breakdown,
            title=title or f"{self.name} Mass Breakdown",
            unit="g",
            **kwargs,
        )

        return fig

    def plot_cost_breakdown(self, title: str = None, **kwargs) -> go.Figure:
        """Generate a sunburst cost breakdown chart."""

        fig = self.plot_breakdown_sunburst(
            self.cost_breakdown,
            title=title or f"{self.name} Cost Breakdown",
            unit="$",
            **kwargs,
        )

        return fig

    def get_materials(self) -> Dict[_Material, List[str]]:
        """Return all materials in the cell with their paths.

        Recursively traverses the cell structure to find all instances of
        `_Material` (from steer_materials). Returns a dictionary mapping each
        material instance to a list of dot-notation paths where it appears.

        Returns
        -------
        Dict[_Material, List[str]]
            Dictionary mapping material instances to lists of paths.
            Example: {<Electrolyte>: ["electrolyte"], <NMC811>: ["reference_electrode_assembly.layup.cathode.formulation.active_materials.NMC811"]}
        """
        results: Dict[_Material, List[str]] = {}
        visited: set = set()

        def _collect(obj: Any, path: str) -> None:
            """Recursively collect materials from an object."""
            obj_id = id(obj)
            if obj_id in visited:
                return
            visited.add(obj_id)

            # Check if this object is a material
            if isinstance(obj, _Material):
                if obj not in results:
                    results[obj] = []
                results[obj].append(path)
                # Continue traversing - materials may contain other materials

            # Handle dictionaries (e.g., formulation._active_materials)
            if isinstance(obj, dict):
                for key, value in obj.items():
                    # Use material name or key repr for path
                    key_name = getattr(key, "name", None) or getattr(key, "_name", None) or repr(key)
                    _collect(key, f"{path}.{key_name}")
                    # Also check values if they might be materials
                    if not isinstance(value, (int, float, str, bool, type(None))):
                        _collect(value, f"{path}.{key_name}._value")
                return

            # Handle lists/tuples
            if isinstance(obj, (list, tuple)):
                for i, item in enumerate(obj):
                    _collect(item, f"{path}[{i}]")
                return

            # Skip primitives and None
            if obj is None or isinstance(obj, (int, float, str, bool, np.ndarray, pd.DataFrame, pd.Series)):
                return

            # Traverse object attributes
            for attr_name in dir(obj):
                # Skip dunder, private methods, and known non-material attributes
                if attr_name.startswith("__"):
                    continue
                if not attr_name.startswith("_"):
                    continue  # Only check private attributes (where data is stored)

                try:
                    attr_value = getattr(obj, attr_name)
                except Exception:
                    continue

                # Skip callables
                if callable(attr_value) and not isinstance(attr_value, _Material):
                    continue

                # Build clean path name (strip leading underscore)
                clean_name = attr_name[1:] if attr_name.startswith("_") else attr_name
                _collect(attr_value, f"{path}.{clean_name}" if path else clean_name)

        # Start traversal from key cell components
        _collect(self._electrolyte, "electrolyte")
        _collect(self._encapsulation, "encapsulation")
        _collect(self._reference_electrode_assembly, "reference_electrode_assembly")

        return results

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def volume(self) -> float:
        """Cell volume in liters."""
        return np.round(self._encapsulation._volume * M_TO_DM**3, MASS_PRECISION)

    @property
    def reference_chemistry(self) -> str:
        """Get the reference chemistry string."""

        # get the reference chemistries from the cathode materials
        cathode_reference_chemistries = []
        for am in self._reference_electrode_assembly._layup._cathode._formulation._active_materials.keys():
            cathode_reference_chemistries.append(am._reference)

        # get the reference chemistries from the anode materials
        anode_reference_chemistries = []
        for am in self._reference_electrode_assembly._layup._anode._formulation._active_materials.keys():
            anode_reference_chemistries.append(am._reference)

        # check if all the cathode materials have the same reference chemistry
        if len(set(cathode_reference_chemistries)) != 1:
            raise ValueError(f"All cathode active materials must have the same reference chemistry. Currently: {cathode_reference_chemistries}")

        # check if all the anode materials have the same reference chemistry
        if len(set(anode_reference_chemistries)) != 1:
            raise ValueError(f"All anode active materials must have the same reference chemistry. Currently: {anode_reference_chemistries}")
        
        cathode_reference_chemistry = cathode_reference_chemistries[0]
        anode_reference_chemistry = anode_reference_chemistries[0]

        # check if the cathode and anode reference chemistries are compatible
        if cathode_reference_chemistry != anode_reference_chemistry:
            raise ValueError(f"Cathode and anode reference chemistries are not compatible. Cathode: {cathode_reference_chemistry}, Anode: {anode_reference_chemistry}")

        return cathode_reference_chemistry

    @property
    def form_factor(self) -> str:
        """Get the cell form factor string."""
        form_factor = self.__class__.__name__
        form_factor = re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', form_factor)
        return form_factor

    @property
    def internal_construction(self) -> str:
        """Get the internal construction type string."""
        internal = self._reference_electrode_assembly.__class__.__name__
        internal = re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', internal)
        return internal

    @property
    def encapsulation(self) -> _Container:
        """Get the cell encapsulation."""
        return self._encapsulation

    @property
    def n_electrode_assembly(self) -> int:
        """Get the number of electrode assemblies in the cell."""
        return self._n_electrode_assembly

    @property
    def electrolyte(self) -> Electrolyte:
        """Get the cell electrolyte."""
        return self._electrolyte

    @property
    def n_electrode_assembly_range(self) -> Tuple[int, int]:
        """Get the suggested range for number of electrode assemblies."""
        return (1, 6)
    
    @property
    def n_electrode_assembly_hard_range(self) -> Tuple[int, int]:
        """Get the hard limit range for number of electrode assemblies."""
        return (1, 20)

    @property
    def electrolyte_overfill(self) -> float:
        """Get the electrolyte overfill percentage."""
        return np.round(self._electrolyte_overfill * FRACTION_TO_PERCENT, MASS_PRECISION)
    
    @property
    def electrolyte_overfill_range(self) -> Tuple[float, float]:
        """Get the valid range for electrolyte overfill percentage."""
        return (0.0, 100.0)

    @property
    def name(self) -> str:
        """Cell name."""
        return self._name
    
    @property
    def electrode_assemblies(self) -> list[_ElectrodeAssembly]:
        """List of electrode assemblies in the cell."""
        return self._electrode_assemblies
    
    @property
    def cost(self) -> float:
        """Cell cost in dollars."""
        return np.round(self._cost, COST_PRECISION)

    @property
    def mass(self) -> float:
        """Cell mass in grams."""
        return np.round(self._mass * KG_TO_G, MASS_PRECISION)

    @property
    def energy(self) -> float:
        """Cell energy in kWh."""
        return np.round(self._energy * ENERGY_CONVERSION_FACTOR, ENERGY_PRECISION)
    
    @property
    def specific_energy(self) -> float:
        """Cell specific energy in kWh/kg."""
        return np.round(self._specific_energy * ENERGY_CONVERSION_FACTOR, ENERGY_PRECISION)
    
    @property
    def volumetric_energy(self) -> float:
        """Cell volumetric energy in kWh/L."""
        return np.round(self._volumetric_energy * VOLUMETRIC_ENERGY_CONVERSION, ENERGY_PRECISION)

    @property
    def cost_per_energy(self) -> float:
        """Cell cost per energy in $/kWh."""
        return np.round(self._cost_per_energy * NORMALISED_COST_CONVERSION, MASS_PRECISION)

    @property
    def cost_breakdown(self) -> Dict[str, Any]:
        """Cost breakdown of the cell in dollars.

        Returns
        -------
        Dict[str, Any]
            Nested dictionary containing cost breakdown by component
        """
        return round_dict_recursive(self._cost_breakdown, MASS_PRECISION)

    @property
    def mass_breakdown(self) -> Dict[str, Any]:
        """Mass breakdown of the cell in grams.

        Returns
        -------
        Dict[str, Any]
            Nested dictionary containing mass breakdown by component
        """
        return round_dict_recursive(self._mass_breakdown, MASS_PRECISION, KG_TO_G)

    @property
    def reversible_capacity(self) -> float:
        """Reversible capacity in Ah."""
        return np.round(self._reversible_capacity * S_TO_H, CAPACITY_PRECISION)

    @property
    def irreversible_capacity(self) -> float:
        """Irreversible (total) capacity in Ah - max capacity reached at full charge."""
        return np.round(self._irreversible_capacity * S_TO_H, CAPACITY_PRECISION)

    @property
    def capacity_loss(self) -> float:
        """Capacity loss in Ah - capacity remaining at minimum voltage."""
        return np.round(self._capacity_loss * S_TO_H, CAPACITY_PRECISION)

    @property
    def capacity_loss_range(self) -> Tuple[float, float]:
        """Range of achievable capacity loss in Ah.
        
        Returns cached values computed during _calculate_electrochemical_properties().
        
        Returns
        -------
        Tuple[float, float]
            (min_capacity_loss, max_capacity_loss) in Ah
        """
        return self._capacity_loss_range_cache

    @property
    def irreversible_capacity_range(self) -> Tuple[float, float]:
        """Range of achievable irreversible capacities in Ah.
        
        Returns cached values computed during _calculate_electrochemical_properties().
        
        Returns
        -------
        Tuple[float, float]
            (min_irreversible_capacity, max_irreversible_capacity) in Ah
        """
        return self._irreversible_capacity_range_cache

    @property
    def reversible_capacity_range(self) -> Tuple[float, float]:
        """Range of achievable reversible capacities in Ah.
        
        Returns cached values computed during _calculate_electrochemical_properties().
        
        Returns
        -------
        Tuple[float, float]
            (min_reversible_capacity, max_reversible_capacity) in Ah
        """
        return self._reversible_capacity_range_cache

    @property
    def capacity_curve(self) -> pd.DataFrame:
        """Full-cell capacity curve as DataFrame.
        
        Returns
        -------
        pd.DataFrame
            DataFrame with columns: Capacity (Ah), Voltage (V), Direction, direction
        """
        return self._format_curve_for_display(self._capacity_curve)

    @property
    def anode_capacity_curve(self) -> pd.DataFrame:
        """Anode half-cell capacity curve as DataFrame.
        
        Returns
        -------
        pd.DataFrame
            DataFrame with columns: Capacity (Ah), Voltage (V), Direction, direction
        """
        return self._format_curve_for_display(self._anode_capacity_curve)

    @property
    def cathode_capacity_curve(self) -> pd.DataFrame:
        """Cathode half-cell capacity curve as DataFrame.
        
        Returns
        -------
        pd.DataFrame
            DataFrame with columns: Capacity (Ah), Voltage (V), Direction, direction
        """
        return self._format_curve_for_display(self._cathode_capacity_curve)
    
    @property
    def capacity_curve_trace(self) -> go.Scatter:
        """Plotly trace for the full-cell capacity curve."""

        color = "#ff8c00"

        return go.Scatter(
            x=self.capacity_curve["Capacity (Ah)"],
            y=self.capacity_curve["Voltage (V)"],
            mode="lines",
            name=f"Full-Cell",
            line=dict(color=color, width=3, shape='spline'),  # Slightly thicker for emphasis
            customdata=self.capacity_curve["Direction"],
            hovertemplate="<b>Full-Cell</b><br>" + "Capacity: %{x:.2f} mAh<br>" + "Voltage: %{y:.3f} V<br>" + "Direction: %{customdata}<extra></extra>",
        )
    
    @property
    def anode_capacity_curve_trace(self) -> go.Scatter:
        """Plotly trace for the anode half-cell capacity curve."""

        return go.Scatter(
            x=self.anode_capacity_curve["Capacity (Ah)"],
            y=self.anode_capacity_curve["Voltage (V)"],
            mode="lines",
            name=f"{self._reference_electrode_assembly._layup._anode.name} Half-Cell",
            line=dict(color=self._reference_electrode_assembly._layup._anode.formulation.color, width=2, shape='spline'),
            customdata=self.anode_capacity_curve["Direction"],
            hovertemplate="<b>Anode</b><br>" + "Capacity: %{x:.2f} mAh<br>" + "Voltage: %{y:.3f} V<br>" + "Direction: %{customdata}<extra></extra>",
        )
    
    @property
    def cathode_capacity_curve_trace(self) -> go.Scatter:
        """Plotly trace for the cathode half-cell capacity curve."""

        return go.Scatter(
            x=self.cathode_capacity_curve["Capacity (Ah)"],
            y=self.cathode_capacity_curve["Voltage (V)"],
            mode="lines",
            name=f"{self._reference_electrode_assembly._layup._cathode.name} Half-Cell",
            line=dict(color=self._reference_electrode_assembly._layup._cathode.formulation.color, width=2, shape='spline'),
            customdata=self.cathode_capacity_curve["Direction"],
            hovertemplate="<b>Cathode</b><br>" + "Capacity: %{x:.2f} mAh<br>" + "Voltage: %{y:.3f} V<br>" + "Direction: %{customdata}<extra></extra>",
        )

    @property
    def integrated_capacity_area_trace(self) -> go.Scatter:
        """Plotly trace for the integrated discharge capacity area fill."""

        color = "#ff8c00"

        curve = self.capacity_curve.query("direction == 'discharge'")

        return go.Scatter(
            x=curve["Capacity (Ah)"],
            y=curve["Voltage (V)"],
            mode="lines",
            name=f"Integrated Capacity",
            line=dict(color=color, width=1),
            fillcolor='rgba(255, 140, 0, 0.2)',
            fill='tozeroy',
            hovertemplate="<b>Integrated Capacity Area</b><br>" + "Capacity: %{x:.2f} mAh<br>" + "Voltage: %{y:.3f} V<extra></extra>",
        )

    @property
    def capacity_loss_guide_trace(self) -> go.Scatter:
        """Vertical line marking capacity loss (capacity at minimum voltage)."""
        return self._create_vertical_guide_trace(
            self.capacity_loss,
            f"Capacity Loss: {self.capacity_loss:.2f} Ah",
            "#d62728"
        )

    @property
    def irreversible_capacity_guide_trace(self) -> go.Scatter:
        """Vertical line marking irreversible (total) capacity at max voltage."""
        return self._create_vertical_guide_trace(
            self.irreversible_capacity,
            f"Irreversible Cap: {self.irreversible_capacity:.2f} Ah",
            "#9467bd"
        )

    @property
    def reversible_capacity_guide_trace(self) -> go.Scatter:
        """Vertical line marking end of reversible capacity range."""
        return self._create_vertical_guide_trace(
            self.reversible_capacity + self.capacity_loss,
            f"Reversible Cap: {self.reversible_capacity:.2f} Ah",
            "#2ca02c"
        )

    @property
    def minimum_voltage_guide_trace(self) -> go.Scatter:
        """Horizontal line marking minimum operating voltage."""
        return self._create_horizontal_guide_trace(
            self.minimum_operating_voltage,
            f"Min Voltage: {self.minimum_operating_voltage:.2f} V",
            "#1f77b4"
        )

    @property
    def maximum_voltage_guide_trace(self) -> go.Scatter:
        """Horizontal line marking maximum operating voltage."""
        return self._create_horizontal_guide_trace(
            self.maximum_operating_voltage,
            f"Max Voltage: {self.maximum_operating_voltage:.2f} V",
            "#ff7f0e"
        )

    @property
    def operating_voltage_window(self) -> Tuple[float, float]:
        """Operating voltage window (min, max) in volts."""
        return (
            np.round(self._operating_voltage_window[0], VOLTAGE_PRECISION),
            np.round(self._operating_voltage_window[1], VOLTAGE_PRECISION),
        )
    
    @property
    def maximum_operating_voltage_range(self) -> Tuple[float, float]:
        """Maximum operating voltage range in volts."""
        return (
            np.round(self._maximum_operating_voltage_range[0], VOLTAGE_PRECISION),
            np.round(self._maximum_operating_voltage_range[1], VOLTAGE_PRECISION),
        )
    
    @property
    def maximum_operating_voltage(self) -> float:
        """Maximum operating voltage in volts."""
        return np.round(self._maximum_operating_voltage, VOLTAGE_PRECISION)
    
    @property
    def minimum_operating_voltage_range(self) -> Tuple[float, float]:
        """Minimum operating voltage range in volts."""
        return (
            np.round(self._minimum_operating_voltage_range[0], VOLTAGE_PRECISION),
            np.round(self._minimum_operating_voltage_range[1], VOLTAGE_PRECISION),
        )
    
    @property
    def minimum_operating_voltage(self) -> float:
        """Minimum operating voltage in volts."""
        return np.round(self._minimum_operating_voltage, VOLTAGE_PRECISION)
    
    @property
    def reference_electrode_assembly(self) -> _ElectrodeAssembly:
        """Get the reference electrode assembly used to construct the cell."""
        return self._reference_electrode_assembly

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    @reference_electrode_assembly.setter
    @calculate_all_properties
    @propagating_setter()
    def reference_electrode_assembly(self, value: _ElectrodeAssembly) -> None:
        self.validate_type(value, _ElectrodeAssembly, "reference_electrode_assembly")
        self._reference_electrode_assembly = value

    @reversible_capacity.setter
    @calculate_electrochemical_properties
    def reversible_capacity(self, value: float) -> None:
        """Set reversible capacity by solving for minimum operating voltage.
        
        Parameters
        ----------
        value : float
            Desired reversible capacity in Ah
        
        Raises
        ------
        ValueError
            If desired capacity is outside achievable range
        """
        self.validate_positive_float(value, "Reversible Capacity")
        
        # Convert to internal units
        target_capacity = value * H_TO_S
        
        # Define function that computes reversible capacity for given voltage
        def compute_reversible_capacity(voltage: float) -> float:
            # Temporarily set the voltage
            self._reference_electrode_assembly._layup.minimum_operating_voltage = voltage
            self._reference_electrode_assembly._calculate_capacity_curves()
            
            # Recompute cell curves and reversible capacity
            self._calculate_curves()
            self._calculate_reversible_capacity()
            self._calculate_irreversible_capacity()
            
            return self._reversible_capacity - target_capacity
        
        # Get voltage range
        v_min, v_max = self._minimum_operating_voltage_range
        
        # Check if target is achievable
        rev_at_min = compute_reversible_capacity(v_min)
        rev_at_max = compute_reversible_capacity(v_max)
        
        # Tolerance for boundary checks - 0.01 Ah converted to internal units (A·s)
        tolerance = 0.005 * H_TO_S
        
        # Check if we're at the boundary (within tolerance)
        if abs(rev_at_min) < tolerance:
            # Target exactly at minimum boundary
            solved_voltage = v_min
        elif abs(rev_at_max) < tolerance:
            # Target exactly at maximum boundary
            solved_voltage = v_max
        elif rev_at_min * rev_at_max > 0:
            # Both have same sign and not at boundary - target not in range
            actual_at_v_min = (rev_at_min + target_capacity) * S_TO_H
            actual_at_v_max = (rev_at_max + target_capacity) * S_TO_H
            # Sort to ensure min < max
            actual_min = min(actual_at_v_min, actual_at_v_max)
            actual_max = max(actual_at_v_min, actual_at_v_max)
            raise ValueError(
                f"Cannot achieve reversible capacity of {value:.2f} Ah. "
                f"Achievable range is [{actual_min:.2f}, {actual_max:.2f}] Ah"
            )
        else:
            # Use Brent's method to find the voltage that gives target capacity
            solved_voltage = brentq(compute_reversible_capacity, v_min, v_max, xtol=1e-6)
        
        # Set the final voltage
        try:
            self._reference_electrode_assembly._layup.minimum_operating_voltage = solved_voltage
            self._reference_electrode_assembly._calculate_capacity_curves()
            self._minimum_operating_voltage = solved_voltage
            self._operating_voltage_window = (solved_voltage, self._maximum_operating_voltage)
        except ValueError as e:
            raise ValueError(f"Failed to solve for minimum operating voltage: {e}")

    @irreversible_capacity.setter
    @calculate_electrochemical_properties
    def irreversible_capacity(self, value: float) -> None:
        """Set irreversible capacity by solving for maximum operating voltage.
        
        Parameters
        ----------
        value : float
            Desired irreversible (total) capacity in Ah
        
        Raises
        ------
        ValueError
            If desired capacity is outside achievable range
        """
        self.validate_positive_float(value, "Irreversible Capacity")
        
        # Convert to internal units
        target_capacity = value * H_TO_S
        
        # Define function that computes irreversible capacity for given voltage
        def compute_irreversible_capacity(voltage: float) -> float:
            # Temporarily set the voltage
            self._reference_electrode_assembly._layup.maximum_operating_voltage = voltage
            self._reference_electrode_assembly._calculate_capacity_curves()
            
            # Recompute cell curves and irreversible capacity
            self._calculate_curves()
            self._calculate_reversible_capacity()
            self._calculate_irreversible_capacity()
            
            return self._irreversible_capacity - target_capacity
        
        # Get voltage range
        v_min, v_max = self._maximum_operating_voltage_range
        
        # Check if target is achievable
        irr_at_min = compute_irreversible_capacity(v_min)
        irr_at_max = compute_irreversible_capacity(v_max)
        
        # Tolerance for boundary checks - 0.01 Ah converted to internal units (A·s)
        # Since we display with 2 decimal places, tolerance should be half of that precision
        tolerance = 0.005 * H_TO_S  # 0.005 Ah = 18 A·s
        
        # Check if we're at the boundary (within tolerance)
        if abs(irr_at_min) < tolerance:
            # Target exactly at minimum boundary
            solved_voltage = v_min
        elif abs(irr_at_max) < tolerance:
            # Target exactly at maximum boundary
            solved_voltage = v_max
        elif irr_at_min * irr_at_max > 0:
            # Both have same sign and not at boundary - target not in range
            actual_at_v_min = (irr_at_min + target_capacity) * S_TO_H
            actual_at_v_max = (irr_at_max + target_capacity) * S_TO_H
            # Sort to ensure min < max
            actual_min = min(actual_at_v_min, actual_at_v_max)
            actual_max = max(actual_at_v_min, actual_at_v_max)
            raise ValueError(
                f"Cannot achieve irreversible capacity of {value:.2f} Ah. "
                f"Achievable range is [{actual_min:.2f}, {actual_max:.2f}] Ah"
            )
        else:
            # Use Brent's method to find the voltage that gives target capacity
            solved_voltage = brentq(compute_irreversible_capacity, v_min, v_max, xtol=1e-6)
        
        # Set the final voltage
        try:
            self._reference_electrode_assembly._layup.maximum_operating_voltage = solved_voltage
            self._reference_electrode_assembly._calculate_capacity_curves()
            self._maximum_operating_voltage = solved_voltage
            self._operating_voltage_window = (self._minimum_operating_voltage, solved_voltage)
        except ValueError as e:
            raise ValueError(f"Failed to solve for maximum operating voltage: {e}")

    @encapsulation.setter
    @calculate_all_properties
    @propagating_setter()
    def encapsulation(self, value: _Container) -> None:
        self.validate_type(value, _Container, "encapsulation")
        self._encapsulation = value

    @n_electrode_assembly.setter
    @calculate_all_properties
    def n_electrode_assembly(self, value: int) -> None:
        value = int(np.round(value))
        self._n_electrode_assembly = value

    @electrolyte.setter
    @calculate_all_properties
    @propagating_setter()
    def electrolyte(self, value: Electrolyte) -> None:

        # validate type
        self.validate_type(value, Electrolyte, "electrolyte")

        # check if it has a volume
        if self._update_properties and hasattr(value, "_volume") and value._volume is not None and value._volume > 0:
            self._electrolyte_overfill = (value._volume / self._pore_volume) - 1

        # assign
        self._electrolyte = value

    @electrolyte_overfill.setter
    @calculate_all_properties
    def electrolyte_overfill(self, value: float) -> None:
        self.validate_percentage(value, "electrolyte_overfill")
        self._electrolyte_overfill = value * PERCENT_TO_FRACTION

    @name.setter
    def name(self, value: str) -> None:
        self.validate_string(value, "name")
        self._name = value

    @operating_voltage_window.setter
    @calculate_electrochemical_properties
    def operating_voltage_window(self, value: Tuple[float, float]) -> None:

        # Ensure value is a list for mutability
        value = list(value)

        # Fill in None values with layup limits
        if value[0] is None:
            value[0] = min(self._reference_electrode_assembly._layup._minimum_operating_voltage_range)
        if value[1] is None:
            value[1] = max(self._reference_electrode_assembly._layup._maximum_operating_voltage_range)

        # clip values
        if self._update_properties:
            value[0] = np.clip(value[0], self._minimum_operating_voltage_range[0], self._minimum_operating_voltage_range[1])
            value[1] = np.clip(value[1], self._maximum_operating_voltage_range[0], self._maximum_operating_voltage_range[1])

        # Validate tuple structure
        self.validate_positive_float(value[0], "operating_voltage_window minimum")
        self.validate_positive_float(value[1], "operating_voltage_window maximum")

        # Validate logical consistency
        if value[0] >= value[1]:
            raise ValueError("operating_voltage_window minimum must be less than maximum.")

        # set the voltage window to the layup
        self._reference_electrode_assembly._layup.operating_voltage_window = value
        self._reference_electrode_assembly._calculate_capacity_curves()

        # assign
        self._operating_voltage_window = value
        self._maximum_operating_voltage = max(value)
        self._minimum_operating_voltage = min(value)

    @maximum_operating_voltage.setter
    def maximum_operating_voltage(self, value: float) -> None:

        if value is None:
            value = max(self._reference_electrode_assembly._layup._maximum_operating_voltage_range)

        self.validate_positive_float(value, "maximum_operating_voltage")
        value = np.clip(value, self._maximum_operating_voltage_range[0], self._maximum_operating_voltage_range[1])

        self._reference_electrode_assembly._layup.maximum_operating_voltage = value
        self._reference_electrode_assembly._calculate_capacity_curves()

        self._maximum_operating_voltage = value
        self.operating_voltage_window = (self._minimum_operating_voltage, value)

    @minimum_operating_voltage.setter
    @calculate_electrochemical_properties
    def minimum_operating_voltage(self, value: float) -> None:
            
        if value is None:
            value = min(self._reference_electrode_assembly._layup._minimum_operating_voltage_range)

        self.validate_positive_float(value, "minimum_operating_voltage")
        value = np.clip(value, self._minimum_operating_voltage_range[0], self._minimum_operating_voltage_range[1])

        self._reference_electrode_assembly._layup.minimum_operating_voltage = value
        self._reference_electrode_assembly._calculate_capacity_curves()

        self._minimum_operating_voltage = value
        self._operating_voltage_window = (value, self._maximum_operating_voltage)















