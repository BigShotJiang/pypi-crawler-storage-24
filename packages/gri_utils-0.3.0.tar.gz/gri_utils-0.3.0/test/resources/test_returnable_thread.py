from gri_utils.resources.returnable_thread import ReturnableThread


def thread_worker_noarg() -> tuple[int, int]:
    return (11, 12)


def thread_worker_arg(i: int) -> tuple[int, int]:
    return (i + 1, i + 2)


def thread_worker_kwarg(*, i: int = 0) -> tuple[int, int]:
    return (i + 1, i + 2)


def test_returnable():
    rt = ReturnableThread[tuple[int, int]](target=thread_worker_noarg)
    rt.start()
    a, b = rt.join()
    assert a == 11
    assert b == 12

    rt = ReturnableThread[tuple[int, int]](target=thread_worker_arg, args=(12,))
    rt.start()
    a, b = rt.join()
    assert a == 13
    assert b == 14

    rt = ReturnableThread[tuple[int, int]](target=thread_worker_kwarg, kwargs={"i": 15})
    rt.start()
    a, b = rt.join()
    assert a == 16
    assert b == 17
