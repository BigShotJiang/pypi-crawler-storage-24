"""Tests for terrain module."""
