import numpy as np
import pytest

from gri_utils.constants import ER_M
from gri_utils.conversion import (
    enu_to_xyz,
    enu_to_xyz_cov,
    get_enu,
    translate_enu,
    xyz_to_enu,
    xyz_to_enu_cov,
)

# Type aliases for readability
XYZ = tuple[float, float, float]
ENU = tuple[float, float, float]


@pytest.mark.parametrize(
    ("xyz_pos", "xyz_pos2", "expected"),
    [
        # in m - along each axis
        ((6378000, 0, 0), (6378100, 0, 0), (0, 0, 100)),
        ((6378000, 0, 0), (6378000, 100, 0), (100, 0, 0)),
        ((6378000, 0, 0), (6378000, 0, 100), (0, 100, 0)),
        # in km - verifies unitless behavior
        ((6378, 0, 0), (6378.1, 0, 0), (0, 0, 0.1)),
        ((6378, 0, 0), (6378, 0.1, 0), (0.1, 0, 0)),
        ((6378, 0, 0), (6378, 0, 0.1), (0, 0.1, 0)),
    ],
)
def test_get_enu(xyz_pos: XYZ, xyz_pos2: XYZ, expected: ENU) -> None:
    """Test get_enu with array and sequence inputs."""
    # Array input
    enu = get_enu(np.array(xyz_pos), np.array(xyz_pos2))
    assert np.allclose(np.array(expected), enu), f"{enu}"

    # Sequence input
    enu_seq = get_enu(xyz_pos, xyz_pos2)
    assert enu_seq == pytest.approx(expected), f"{enu_seq}"


@pytest.mark.parametrize(
    ("xyz_pos", "enu_vec", "expected"),
    [
        # in m - along each axis
        ((6378000, 0, 0), (0, 0, 100), (6378100, 0, 0)),
        ((6378000, 0, 0), (0, 100, 0), (6378000, 0, 100)),
        ((6378000, 0, 0), (100, 0, 0), (6378000, 100, 0)),
        # in km - verifies unitless behavior
        ((6378, 0, 0), (0, 0, 0.1), (6378.1, 0, 0)),
        ((6378, 0, 0), (0, 0.1, 0), (6378, 0, 0.1)),
        ((6378, 0, 0), (0.1, 0, 0), (6378, 0.1, 0)),
    ],
)
def test_translate_enu(xyz_pos: XYZ, enu_vec: ENU, expected: XYZ) -> None:
    """Test translate_enu with array and sequence inputs."""
    # Array input
    xyz = translate_enu(np.array(xyz_pos), np.array(enu_vec))
    assert np.allclose(np.array(expected), xyz), f"{xyz}"

    # Sequence input
    xyz_seq = translate_enu(xyz_pos, enu_vec)
    assert xyz_seq == pytest.approx(expected), f"{xyz_seq}"


@pytest.mark.parametrize(
    ("xyz_pos", "xyz_vec", "expected"),
    [
        # in m - along each axis
        ((6378000, 0, 0), (0, 100, 0), (100, 0, 0)),
        ((6378000, 0, 0), (0, 0, 100), (0, 100, 0)),
        ((6378000, 0, 0), (100, 0, 0), (0, 0, 100)),
        # in km - verifies unitless behavior
        ((6378, 0, 0), (0, 0.1, 0), (0.1, 0, 0)),
        ((6378, 0, 0), (0, 0, 0.1), (0, 0.1, 0)),
        ((6378, 0, 0), (0.1, 0, 0), (0, 0, 0.1)),
    ],
)
def test_xyz_to_enu(xyz_pos: XYZ, xyz_vec: XYZ, expected: ENU) -> None:
    """Test xyz_to_enu with array and sequence inputs."""
    # Array input
    enu = xyz_to_enu(np.array(xyz_pos), np.array(xyz_vec))
    assert np.allclose(np.array(expected), enu), f"{enu}"

    # Sequence input
    enu_seq = xyz_to_enu(xyz_pos, xyz_vec)
    assert enu_seq == pytest.approx(expected), f"{enu_seq}"


def test_xyz_to_enu_cov() -> None:
    """Test xyz_to_enu_cov with 3x3 matrix input (covariance transformation)."""
    xyz = np.array(((100, 0, 0), (0, 25, 0), (0, 0, 1)))
    enu = np.array(((25, 0, 0), (0, 1, 0), (0, 0, 100)))
    ans = xyz_to_enu_cov((ER_M, 0, 0), xyz)
    assert np.allclose(enu, ans)


@pytest.mark.parametrize(
    ("xyz_pos", "enu_vec", "expected"),
    [
        # in m - along each axis
        ((6378000, 0, 0), (100, 0, 0), (0, 100, 0)),
        ((6378000, 0, 0), (0, 100, 0), (0, 0, 100)),
        ((6378000, 0, 0), (0, 0, 100), (100, 0, 0)),
        # in km - verifies unitless behavior
        ((6378, 0, 0), (0.1, 0, 0), (0, 0.1, 0)),
        ((6378, 0, 0), (0, 0.1, 0), (0, 0, 0.1)),
        ((6378, 0, 0), (0, 0, 0.1), (0.1, 0, 0)),
    ],
)
def test_enu_to_xyz(xyz_pos: XYZ, enu_vec: ENU, expected: XYZ) -> None:
    """Test enu_to_xyz with array and sequence inputs."""
    # Array input
    xyz = enu_to_xyz(np.array(xyz_pos), np.array(enu_vec))
    assert np.allclose(np.array(expected), xyz), f"{xyz}"

    # Sequence input
    xyz_seq = enu_to_xyz(xyz_pos, enu_vec)
    assert xyz_seq == pytest.approx(expected), f"{xyz_seq}"


def test_enu_to_xyz_cov() -> None:
    """Test enu_to_xyz_cov with 3x3 matrix input (covariance transformation)."""
    xyz = np.array(((100, 0, 0), (0, 25, 0), (0, 0, 1)))
    enu = np.array(((25, 0, 0), (0, 1, 0), (0, 0, 100)))
    ans = enu_to_xyz_cov((ER_M, 0, 0), enu)
    assert np.allclose(xyz, ans)


# Vectorized tests


def test_get_enu_vectorized() -> None:
    """Test get_enu with multiple target positions."""
    # Reference position on equator at prime meridian
    xyz_ref: XYZ = (6378000, 0, 0)

    # Multiple target positions: +100m in each direction
    xyz_targets = np.array(
        [
            (6378100, 0, 0),  # +100m radially out (Up)
            (6378000, 100, 0),  # +100m in Y (East)
            (6378000, 0, 100),  # +100m in Z (North)
        ],
    )
    expected = np.array(
        [
            (0, 0, 100),  # Up
            (100, 0, 0),  # East
            (0, 100, 0),  # North
        ],
    )

    enu_vecs = get_enu(xyz_ref, xyz_targets)

    assert enu_vecs.shape == (3, 3)
    assert np.allclose(enu_vecs, expected)


def test_translate_enu_vectorized() -> None:
    """Test translate_enu with multiple ENU vectors."""
    xyz_ref: XYZ = (6378000, 0, 0)

    # Multiple ENU vectors
    enu_vecs = np.array(
        [
            (0, 0, 100),  # Up
            (100, 0, 0),  # East
            (0, 100, 0),  # North
        ],
    )
    expected = np.array(
        [
            (6378100, 0, 0),
            (6378000, 100, 0),
            (6378000, 0, 100),
        ],
    )

    xyzs = translate_enu(xyz_ref, enu_vecs)

    assert xyzs.shape == (3, 3)
    assert np.allclose(xyzs, expected)


def test_xyz_to_enu_vectorized() -> None:
    """Test xyz_to_enu with multiple XYZ vectors."""
    xyz_ref: XYZ = (6378000, 0, 0)

    # Use 4 vectors to avoid (3,3) matrix interpretation
    xyz_vecs = np.array(
        [
            (100, 0, 0),  # Radial out -> Up
            (0, 100, 0),  # Y -> East
            (0, 0, 100),  # Z -> North
            (50, 50, 50),  # Mixed
        ],
    )
    expected = np.array(
        [
            (0, 0, 100),
            (100, 0, 0),
            (0, 100, 0),
            (50, 50, 50),  # E=Y, N=Z, U=X
        ],
    )

    enu_vecs = xyz_to_enu(xyz_ref, xyz_vecs)

    assert enu_vecs.shape == (4, 3)
    assert np.allclose(enu_vecs, expected)


def test_enu_to_xyz_vectorized() -> None:
    """Test enu_to_xyz with multiple ENU vectors."""
    xyz_ref: XYZ = (6378000, 0, 0)

    # Use 4 vectors to avoid (3,3) matrix interpretation
    enu_vecs = np.array(
        [
            (100, 0, 0),  # East -> Y
            (0, 100, 0),  # North -> Z
            (0, 0, 100),  # Up -> X (radial)
            (50, 50, 50),  # Mixed
        ],
    )
    expected = np.array(
        [
            (0, 100, 0),
            (0, 0, 100),
            (100, 0, 0),
            (50, 50, 50),  # X=U, Y=E, Z=N
        ],
    )

    xyz_vecs = enu_to_xyz(xyz_ref, enu_vecs)

    assert xyz_vecs.shape == (4, 3)
    assert np.allclose(xyz_vecs, expected)


def test_enu_xyz_vectorized_round_trip() -> None:
    """Test round-trip ENU<->XYZ conversion with batched inputs."""
    xyz_ref: XYZ = (6378000, 0, 0)

    enu_vecs = np.array(
        [
            (50, 30, 20),
            (100, 0, 0),
            (0, 100, 0),
            (0, 0, 100),
            (-50, -30, -20),
        ],
    )

    xyz_vecs = enu_to_xyz(xyz_ref, enu_vecs)
    enu_back = xyz_to_enu(xyz_ref, xyz_vecs)

    assert enu_back.shape == enu_vecs.shape
    assert np.allclose(enu_back, enu_vecs)
