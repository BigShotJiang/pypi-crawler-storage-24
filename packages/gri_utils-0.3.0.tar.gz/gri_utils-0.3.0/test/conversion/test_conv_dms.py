import numpy as np
import pytest

from gri_utils.conversion import (
    deg_lat_to_dms_str,
    deg_lon_to_dms_str,
    deg_to_dms,
    dms_to_deg,
)


@pytest.mark.parametrize(
    ("deg", "expected"),
    [
        (0, (0, 0, 0)),
        (0.000, (0, 0, 0)),
        (1, (1, 0, 0)),
        (89, (89, 0, 0)),
        (-1, (-1, 0, 0)),
        (10.5, (10, 30, 0)),
        (-10.5, (-10, -30, 0)),
        (10 + 30 / 60 + 30.5 / 3600, (10, 30, 30.5)),
    ],
)
def test_deg_to_dms(deg: float, expected: tuple[int, int, float]) -> None:
    assert np.allclose(deg_to_dms(deg), expected)


@pytest.mark.parametrize(
    ("deg", "expected"),
    [
        (0, "0:00'00.0\"N"),
        (0.000, "0:00'00.0\"N"),
        (1, "1:00'00.0\"N"),
        (89, "89:00'00.0\"N"),
        (-1, "1:00'00.0\"S"),
        (10.5, "10:30'00.0\"N"),
        (-10.5, "10:30'00.0\"S"),
        (10 + 30 / 60 + 30.5 / 3600, "10:30'30.5\"N"),
    ],
)
def test_deg_lat_to_dms_str(deg: float, expected: str) -> None:
    assert deg_lat_to_dms_str(deg) == expected


@pytest.mark.parametrize(
    ("deg", "expected"),
    [
        (0, "0:00'00.0\"E"),
        (0.000, "0:00'00.0\"E"),
        (1, "1:00'00.0\"E"),
        (89, "89:00'00.0\"E"),
        (-1, "1:00'00.0\"W"),
        (10.5, "10:30'00.0\"E"),
        (-10.5, "10:30'00.0\"W"),
        (10 + 30 / 60 + 30.5 / 3600, "10:30'30.5\"E"),
    ],
)
def test_deg_lon_to_dms_str(deg: float, expected: str) -> None:
    assert deg_lon_to_dms_str(deg) == expected


@pytest.mark.parametrize(
    ("dms_str", "expected"),
    [
        ("0:00'00.0\"N", 0),
        ("1:00'00.0\"N", 1),
        ("89:00'00.0\"N", 89),
        ("1:00'00.0\"S", -1),
        ("10:30'00.0\"N", 10.5),
        ("10:30'00.0\"S", -10.5),
        ("10:30'30.5\"N", 10 + 30 / 60 + 30.5 / 3600),
        ("0:00'00.0\"E", 0),
        ("1:00'00.0\"E", 1),
        ("89:00'00.0\"E", 89),
        ("1:00'00.0\"W", -1),
        ("10:30'00.0\"E", 10.5),
        ("10:30'00.0\"W", -10.5),
        ("10:30'30.5\"E", 10 + 30 / 60 + 30.5 / 3600),
    ],
)
def test_dms_to_deg(dms_str: str, expected: float) -> None:
    assert dms_to_deg(dms_str) == pytest.approx(expected)


def test_dms_error() -> None:
    with pytest.raises(ValueError):
        dms_to_deg("00'00.0\"N")
