"""Orbit simulation module for Keplerian (two-body) orbit mechanics.

This module provides functions for:
- Defining orbits using classical Keplerian elements
- Creating orbits from state vectors, TLE data, or geometric constraints
- Propagating orbits to compute position, velocity, and acceleration at any time
- Hermite interpolation of discrete ephemeris state vectors
- Computing derived orbital properties (period, apogee/perigee, energy, etc.)

The module uses a pure functional design with two core types:
- OrbitalElements: Defines an orbit (semi-major axis, eccentricity, etc.)
- OrbitState: Position, velocity, acceleration at a specific time

Key Functions:
    from_elements: Create OrbitalElements from individual parameters
    from_state: Create OrbitalElements from position/velocity vectors
    from_circular: Create circular orbit through an ECEF point
    from_perigee_apogee: Create elliptical orbit from perigee location and apogee radius
    from_tle: Parse Two-Line Element data
    from_states: Fit orbit to multiple observations
    elements_to_state: Propagate elements to state at a time
    hermite_interpolate: Interpolate state from discrete ephemeris data
    state_to_elements: Convert state vector to elements
    orbital_properties: Compute derived properties (period, apogee, etc.)

Example:
    >>> import math
    >>> from gri_utils import orbit
    >>> # Create an ISS-like orbit
    >>> elements = orbit.from_elements(
    ...     semi_major_axis_m=6_778_000,
    ...     eccentricity=0.0001,
    ...     inclination_rad=math.radians(51.6),
    ...     raan_rad=0.0,
    ...     arg_periapsis_rad=0.0,
    ...     mean_anomaly_rad=0.0,
    ...     epoch_unix_s=1704067200.0,
    ... )
    >>> # Propagate to a later time
    >>> state = orbit.elements_to_state(elements, unix_s=1704070800.0)
    >>> print(f"Position: {state.position_eci_m}")
    >>> # Get orbital properties
    >>> props = orbit.orbital_properties(elements)
    >>> print(f"Period: {props.period_s / 60:.1f} minutes")

Note:
    This module implements two-body Keplerian mechanics only. It does not
    account for perturbations (J2, drag, solar radiation pressure, etc.).
    For high-fidelity propagation, especially of TLE data, use a dedicated
    SGP4 library like python-sgp4.

References:
    - Vallado, D. "Fundamentals of Astrodynamics and Applications", 4th ed.
    - Bate, Mueller, White "Fundamentals of Astrodynamics"
"""

from .elements_to_state import elements_to_state
from .from_circular import from_circular
from .from_elements import from_elements, from_elements_deg
from .from_perigee_apogee import from_perigee_apogee
from .from_state import from_position_velocity, from_state
from .from_states import from_states
from .from_tle import from_tle
from .hermite_interpolator import hermite_interpolate
from .orbit_state import OrbitState
from .orbital_elements import OrbitalElements
from .orbital_properties import OrbitalProperties, orbital_properties
from .state_to_elements import position_velocity_to_elements, state_to_elements

__all__ = [
    "OrbitState",
    "OrbitalElements",
    "OrbitalProperties",
    "elements_to_state",
    "from_circular",
    "from_elements",
    "from_elements_deg",
    "from_perigee_apogee",
    "from_position_velocity",
    "from_state",
    "from_states",
    "from_tle",
    "hermite_interpolate",
    "orbital_properties",
    "position_velocity_to_elements",
    "state_to_elements",
]
