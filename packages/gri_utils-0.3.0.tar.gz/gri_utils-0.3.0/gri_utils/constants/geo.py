"""General constants."""

from __future__ import annotations

# TODO others besides WGS84?
ER_M = 6378137
"""Equatorial radius of the Earth in meters: 6378137"""
PR_M = 6356752.314245
"""Polar radius of the Earth in meters: 6356752.3142"""
FLATTENING = (ER_M - PR_M) / ER_M
"""Earth flattening factor, approximately 1/298.25722356"""
ECCENTRICITY_SQUARED = 1 - (PR_M / ER_M) ** 2
"""Eccentricity squared of the ellipsoid : 1-(P/E)**2, approximately 6.69438e-3"""
ECCENTRICITY = ECCENTRICITY_SQUARED**0.5
"""Eccentricity of the ellipsoid, approximately 0.081819191"""
C = 299792458
"""Speed of light in m/s: 299,792,458"""
ACC_SEA_LEVEL = 9.80665
"""Acceleration due to gravity at sea level in m/s**2"""
GM_EARTH = 3.986004418e14
"""Earth gravitational parameter (GM) in m**3/s**2 - WGS84 value: 3.986004418e14"""
OMEGA_EARTH = 7.2921150e-5
"""Earth rotation rate in rad/s - WGS84 value: 7.2921150e-5"""
