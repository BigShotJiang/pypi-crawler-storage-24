"""General constants.

For namespace simplicity, import constants as a whole, then use (eg) constants.ER_M
"""

from .geo import (
    ACC_SEA_LEVEL,
    ECCENTRICITY,
    ECCENTRICITY_SQUARED,
    ER_M,
    FLATTENING,
    GM_EARTH,
    OMEGA_EARTH,
    PR_M,
    C,
)
from .stats import SIG_TO_95_1D, SIG_TO_95_2D, SIG_TO_95_3D

__all__ = [
    "ACC_SEA_LEVEL",
    "ECCENTRICITY",
    "ECCENTRICITY_SQUARED",
    "ER_M",
    "FLATTENING",
    "GM_EARTH",
    "OMEGA_EARTH",
    "PR_M",
    "SIG_TO_95_1D",
    "SIG_TO_95_2D",
    "SIG_TO_95_3D",
    "C",
]
