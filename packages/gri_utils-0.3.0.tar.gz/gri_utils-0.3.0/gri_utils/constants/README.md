# Utils/Constants

Physical and statistical constants used throughout the GRI ecosystem.

## Import and Use

```python
from gri_utils import constants

equatorial_radius_meters = constants.ER_M
```

Or with a unique name:

```python
from gri_utils import constants as gri_constants

equatorial_radius_meters = gri_constants.ER_M
```

## Earth Parameters

WGS84 ellipsoid and gravitational constants:

| Constant | Value | Description |
|----------|-------|-------------|
| `ER_M` | 6,378,137.0 m | Equatorial radius (semi-major axis) |
| `PR_M` | 6,356,752.3 m | Polar radius (semi-minor axis) |
| `FLATTENING` | ~1/298.257 | WGS84 flattening |
| `ECCENTRICITY` | ~0.0818 | First eccentricity |
| `ECCENTRICITY_SQUARED` | ~0.00669 | First eccentricity squared |
| `GM_EARTH` | 3.986e14 m^3/s^2 | Gravitational parameter |
| `OMEGA_EARTH` | 7.292e-5 rad/s | Earth rotation rate |
| `ACC_SEA_LEVEL` | 9.80665 m/s^2 | Standard gravitational acceleration |
| `C` | 299,792,458.0 m/s | Speed of light in vacuum |

## Statistical Scaling Factors

Scaling factors to convert 1-sigma values to 95% confidence:

| Constant | Value | Description |
|----------|-------|-------------|
| `SIG_TO_95_1D` | 1.96 | 1D (scalar) sigma to 95% |
| `SIG_TO_95_2D` | 2.4477 | 2D (ellipse) sigma to 95% |
| `SIG_TO_95_3D` | 2.7955 | 3D (ellipsoid) sigma to 95% |

## Examples

```python
from gri_utils import constants
import numpy as np

# Convert TDOA (seconds) to range difference (meters)
tdoa_s = 1.5e-6
range_diff_m = tdoa_s * constants.C

# Scale a 1-sigma position error to 95% confidence
sigma_m = 50.0
error_95_m = sigma_m * constants.SIG_TO_95_1D

# Scale a 2D covariance matrix to 95%
cov_1sig = np.array([[100, 10], [10, 200]])
cov_95 = cov_1sig * constants.SIG_TO_95_2D**2
```
