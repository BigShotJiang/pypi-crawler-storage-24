"""Statistical utilities for confidence intervals and scale factor analysis.

This module provides functions for computing confidence intervals and
scale factors commonly used in geospatial accuracy assessment.

Functions implemented here:
    - asf: Average/Median Scale Factor (ASF/MSF) for ellipse calibration
    - poisson_ci: CI for Poisson counts (Garwood method)
    - quantile_ci: CI for sample quantiles (normal approximation to binomial)
    - ratio_ci: CI for ratio of counts (Walters logarithm method)

Functions available in scipy (not reimplemented):
    - Mean CI: Use scipy.stats.t.interval() with scipy.stats.sem()
    - Quantile CI (robust): Use scipy.stats.quantile_test().confidence_interval()
"""

from .asf import asf
from .poisson_ci import poisson_ci
from .quantile_ci import quantile_ci
from .ratio_ci import ratio_ci

__all__ = [
    "asf",
    "poisson_ci",
    "quantile_ci",
    "ratio_ci",
]
