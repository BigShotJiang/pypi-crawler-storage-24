"""Terrain sheet operations for XYZ surface grids.

This module provides functions for working with terrain represented as 2D grids
of XYZ points (sheets) in ECEF coordinates.

Example::

    from gri_utils import terrain
    import numpy as np

    # Create a terrain sheet from LLA heightmap
    lats = np.linspace(39.0, 39.1, 100)
    lons = np.linspace(-105.0, -104.9, 100)
    alts = np.random.randn(100, 100) * 100  # Random terrain

    sheet = terrain.lla_to_xyz_sheet(lats, lons, alts)

    # Get sheet properties
    row_res, col_res = terrain.get_sheet_resolution(sheet)
    bounds = terrain.get_sheet_bounds(sheet)

    # Fast pre-filtering for ray intersection
    could_hit, approx = terrain.ray_intersects_bounds(origin, direction, bounds)

    # Interpolate a point
    point = terrain.interpolate_sheet(sheet, 50.5, 50.5)

    # Adaptive intersection with terrain source (requires gri-terrain or similar)
    # source = SomeTerrainSource(...)
    # contours = terrain.intersect_source_with_tdoa(source, lats, lons, c1, c2, tdoa)
"""

from .adaptive import (
    intersect_adaptive,
    intersect_source_with_aoa,
    intersect_source_with_fdoa,
    intersect_source_with_range,
    intersect_source_with_tdoa,
)
from .marching_squares import contours_to_xyz, find_contours
from .ray import ray_intersects_sheet_bounds, ray_sheet_intersect
from .shadow_boundary import get_shadow_boundary
from .shadow_depth import get_shadow_depth
from .sheet import (
    get_sheet_resolution,
    interpolate_sheet,
    interpolate_sheet_batch,
    lla_to_xyz_sheet,
    xyz_to_lla_sheet,
)
from .sheet_bounds import (
    SheetBounds,
    bounds_overlap,
    get_sheet_bounds,
    point_within_bounds,
    ray_intersects_bounds,
)
from .sheet_intersect import intersect_sheet, intersect_sheet_scalar
from .source import TerrainBounds, TerrainSource
from .stitch import get_stitch_resolution, stitch_sheets
from .visibility_mask import get_visibility_mask

__all__ = [
    "SheetBounds",
    "TerrainBounds",
    "TerrainSource",
    "bounds_overlap",
    "contours_to_xyz",
    "find_contours",
    "get_shadow_boundary",
    "get_shadow_depth",
    "get_sheet_bounds",
    "get_sheet_resolution",
    "get_stitch_resolution",
    "get_visibility_mask",
    "interpolate_sheet",
    "interpolate_sheet_batch",
    "intersect_adaptive",
    "intersect_sheet",
    "intersect_sheet_scalar",
    "intersect_source_with_aoa",
    "intersect_source_with_fdoa",
    "intersect_source_with_range",
    "intersect_source_with_tdoa",
    "lla_to_xyz_sheet",
    "point_within_bounds",
    "ray_intersects_bounds",
    "ray_intersects_sheet_bounds",
    "ray_sheet_intersect",
    "stitch_sheets",
    "xyz_to_lla_sheet",
]
