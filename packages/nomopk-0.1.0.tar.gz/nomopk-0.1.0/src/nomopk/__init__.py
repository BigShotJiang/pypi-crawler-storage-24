[tool.hatch.build.targets.wheel]
packages = ["src/nomopk"]