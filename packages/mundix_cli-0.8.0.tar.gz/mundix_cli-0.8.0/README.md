# MundiX CLI

**AI-Powered Cybersecurity Copilot for Kali Linux**

MundiX CLI is an intelligent terminal assistant designed for penetration testers, red teamers, and security researchers. It connects to specialized cybersecurity AI models (DeepHat, WhiteRabbitNeo) via HuggingFace, and features a collective memory system that learns from all users.

Think of it as **Claude Code or GitHub Copilot, but built specifically for hackers.**

---

## Features

| Feature | Description |
| :--- | :--- |
| **AI Chat** | Interactive conversation with uncensored cybersecurity AI models |
| **Command Execution** | Extract and execute commands directly from AI responses |
| **Collective Memory** | Local + shared memory that improves with every user interaction |
| **Multi-Model** | Switch between DeepHat, WhiteRabbitNeo, and other models |
| **System Awareness** | AI knows your OS, tools, and current directory |
| **Safety Checks** | Dangerous commands are flagged before execution |
| **Streaming** | Real-time token streaming for fast responses |
| **One-Shot Mode** | Quick queries without entering interactive mode |

---

## Quick Install (Kali Linux)

```bash
curl -sSL https://raw.githubusercontent.com/k0k4/mundix-cli/main/install.sh | bash
```

### Manual Install

```bash
git clone https://github.com/k0k4/mundix-cli.git
cd mundix-cli
pip3 install -r requirements.txt
export HF_TOKEN="your_huggingface_token"
python3 mundix_cli.py
```

### Install via pip

```bash
pip3 install -e .
mundix
```

Get your free HuggingFace token at: https://huggingface.co/settings/tokens

---

## Usage

### Interactive Mode
```bash
mundix
```

### One-Shot Query
```bash
mundix "how to scan for open ports on 10.0.0.1"
```

### Execute and Analyze
```bash
mundix --exec "nmap -sV 10.0.0.1"
```

### Choose a Model
```bash
mundix --model wrn-qwen-7b
```

---

## Available Models

| Key | Model | Description |
| :--- | :--- | :--- |
| `deephat-7b` | DeepHat V1 7B | Cybersecurity & DevOps specialist (default) |
| `wrn-qwen-7b` | WhiteRabbitNeo 2.5 Qwen 7B | Offensive/Defensive cybersecurity |
| `wrn-llama-8b` | WhiteRabbitNeo Llama 8B v2 | General cybersecurity assistant |

---

## CLI Commands

Inside the interactive shell, use these slash commands:

| Command | Description |
| :--- | :--- |
| `/help` | Show help message |
| `/models` | List available AI models |
| `/model <name>` | Switch to a different model |
| `/memory` | Show memory statistics |
| `/sync` | Sync collective memory |
| `/clear` | Clear conversation history |
| `/system` | Show system information |
| `/history` | Show command execution history |
| `/exec <cmd>` | Execute a command directly |
| `/analyze` | Send last command output to AI |
| `/exit` | Exit MundiX CLI |

---

## Collective Memory

MundiX CLI features a unique **collective memory** system:

**How it works:** Every useful interaction (questions, commands, solutions) is saved locally. High-quality entries (upvoted by the user) are anonymized and shared with the MundiX collective memory. When you ask a question, the CLI first searches the collective memory for similar past solutions before querying the AI model, saving tokens and leveraging community knowledge.

**Privacy:** Only anonymized command patterns and solutions are shared. No personal data, IPs, or target information is ever transmitted.

---

## Project Structure

```
mundix-cli/
  mundix_cli.py          # Main CLI application (REPL, UI, slash commands)
  ai_provider.py         # HuggingFace API integration (OpenAI-compatible)
  memory.py              # Collective memory system (local + sync)
  system_integrator.py   # Command execution and system interaction
  install.sh             # Quick installer for Kali Linux
  requirements.txt       # Python dependencies
  setup.py               # pip install support
  test_modules.py        # Module test suite
  LICENSE                # MIT License
```

---

## Requirements

- Python 3.8+
- Linux (optimized for Kali Linux)
- HuggingFace API token (free tier works)

---

## Roadmap

- [ ] TUI dashboard with Rich panels (scan results, AI chat side by side)
- [ ] Plugin system for custom tools integration
- [ ] Collective memory API server for real-time community sync
- [ ] Voice input/output for hands-free operation
- [ ] Auto-reconnaissance mode (full automated recon pipeline)
- [ ] Integration with Metasploit RPC and Burp Suite API

---

## License

MIT License - [MundiX](https://mundix.com.br)

---

**Built with purpose by MundiX. Happy Hacking.**
