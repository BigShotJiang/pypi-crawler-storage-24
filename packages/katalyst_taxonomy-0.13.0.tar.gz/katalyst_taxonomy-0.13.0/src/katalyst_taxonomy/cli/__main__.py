"""Main entry point for the Katalyst CLI."""

from __future__ import annotations

import sys
from typing import cast

from katalyst_taxonomy.cli.parser import FORMAT_JSON, FORMAT_LIST, FORMAT_TREE, create_parser


def main(args: list[str] | None = None) -> int:
    """Main entry point."""
    parser = create_parser()
    parsed = parser.parse_args(args)

    # Top-level command dispatch
    if not parsed.command:
        parser.print_help()
        return 0

    # TUI stays at top level
    if parsed.command == "tui":
        from katalyst_taxonomy.tui import run as run_tui

        run_tui(path=parsed.path)
        return 0

    # Everything else is under 'tax'
    if parsed.command == "tax":
        return _dispatch_tax(parsed)

    parser.print_help()
    return 1


def _dispatch_tax(parsed: object) -> int:
    """Dispatch taxonomy subcommands."""
    tax_command = getattr(parsed, "tax_command", None)

    if not tax_command:
        sys.stderr.write("Usage: kata tax <command> ...\n")
        sys.stderr.write("\nRun 'kata tax --help' for available taxonomy commands.\n")
        return 1

    # Handle format aliases (tree, list, json -> show with format)
    if tax_command in ("tree", "list", "json"):
        format_map = {"tree": FORMAT_TREE, "list": FORMAT_LIST, "json": FORMAT_JSON}
        parsed.format = format_map[tax_command]  # type: ignore[attr-defined]
        tax_command = "show"

    if tax_command == "server":
        from katalyst_taxonomy.cli.commands.server import run_server

        server_action = getattr(parsed, "server_action", None)
        if server_action is None:
            sys.stderr.write("Usage: kata tax server {start|stop|status|restart}\n")
            sys.stderr.write("\nSubcommands:\n")
            sys.stderr.write("  start    Start the server\n")
            sys.stderr.write("  stop     Stop the running server\n")
            sys.stderr.write("  status   Show server status\n")
            sys.stderr.write("  restart  Restart the server\n")
            return 1

        return run_server(
            action=server_action,
            path=parsed.path,  # type: ignore[attr-defined]
            port=getattr(parsed, "port", None),
            idle_timeout=getattr(parsed, "idle_timeout", 300),
        )

    if tax_command == "show":
        from katalyst_taxonomy.cli.commands.show import run_show

        return run_show(
            path=parsed.path,  # type: ignore[attr-defined]
            name=getattr(parsed, "name", None),
            output_format=parsed.format,  # type: ignore[attr-defined]
        )

    if tax_command == "get":
        from katalyst_taxonomy.cli.commands.get import run_get

        return run_get(
            path=parsed.path,  # type: ignore[attr-defined]
            name=cast(str, parsed.name),  # type: ignore[attr-defined]
            output_format=parsed.format,  # type: ignore[attr-defined]
        )

    if tax_command == "lint":
        from katalyst_taxonomy.cli.commands.lint import run_lint

        return run_lint(
            path=parsed.path,  # type: ignore[attr-defined]
        )

    if tax_command == "create":
        from katalyst_taxonomy.cli.commands.create import run_create

        # Convert list arguments to tuples
        owners: tuple[str, ...] | None = tuple(parsed.owners) if parsed.owners else None  # type: ignore[attr-defined]
        environments: tuple[str, ...] | None = (
            tuple(parsed.environments) if parsed.environments else None  # type: ignore[attr-defined]
        )

        return run_create(
            path=parsed.path,  # type: ignore[attr-defined]
            node_type=parsed.type,  # type: ignore[attr-defined]
            name=cast(str, parsed.name),  # type: ignore[attr-defined]
            description=parsed.description,  # type: ignore[attr-defined]
            owners=owners,
            environments=environments,
            parent=parsed.parent,  # type: ignore[attr-defined]
            parent_subsystem=getattr(parsed, "parent_subsystem", None),
            parent_system=getattr(parsed, "parent_system", None),
            layer_type=getattr(parsed, "layer_type", None),
            archetype=getattr(parsed, "archetype", None),
        )

    if tax_command == "deps":
        from katalyst_taxonomy.cli.commands.deps import run_deps

        return run_deps(
            path=parsed.path,  # type: ignore[attr-defined]
            output_format=getattr(parsed, "output_format", "tree"),
            node=getattr(parsed, "node", None),
            reverse=getattr(parsed, "reverse", False),
        )

    if tax_command == "action":
        from katalyst_taxonomy.cli.commands.action import (
            run_action_list,
            run_action_run,
            run_action_show,
        )

        action_cmd = getattr(parsed, "action_command", None)
        if action_cmd == "run":
            return run_action_run(
                path=parsed.path,  # type: ignore[attr-defined]
                action_name=parsed.action_name,  # type: ignore[attr-defined]
                layer_fqtn=parsed.layer,  # type: ignore[attr-defined]
                environment=getattr(parsed, "environment", None),
                dry_run=getattr(parsed, "dry_run", False),
                quiet=getattr(parsed, "quiet", False),
                timeout=getattr(parsed, "timeout", None),
            )
        if action_cmd == "list":
            return run_action_list(
                path=parsed.path,  # type: ignore[attr-defined]
                layer_type=getattr(parsed, "layer_type", None),
                layer_fqtn=getattr(parsed, "layer_fqtn", None),
                output_format=getattr(parsed, "output_format", "table"),
            )
        if action_cmd == "show":
            return run_action_show(
                path=parsed.path,  # type: ignore[attr-defined]
                action_name=parsed.action_name,  # type: ignore[attr-defined]
                output_format=getattr(parsed, "output_format", "table"),
            )
        sys.stderr.write("Usage: kata tax action {run|list|show} ...\n")
        sys.stderr.write("\nSubcommands:\n")
        sys.stderr.write("  run   Run a layer action\n")
        sys.stderr.write("  list  List available actions\n")
        sys.stderr.write("  show  Show action details\n")
        return 1

    if tax_command == "cicd":
        from katalyst_taxonomy.cli.commands.cicd import (
            run_cicd_job_show,
            run_cicd_jobs,
            run_cicd_render,
            run_cicd_stages,
            run_cicd_validate,
            run_cicd_workflow_show,
            run_cicd_workflows,
        )

        cicd_cmd = getattr(parsed, "cicd_command", None)
        if cicd_cmd == "workflows":
            return run_cicd_workflows(
                path=parsed.path,  # type: ignore[attr-defined]
                output_format=getattr(parsed, "output_format", "table"),
            )
        if cicd_cmd == "workflow":
            return run_cicd_workflow_show(
                path=parsed.path,  # type: ignore[attr-defined]
                workflow_name=parsed.workflow_name,  # type: ignore[attr-defined]
                output_format=getattr(parsed, "output_format", "table"),
            )
        if cicd_cmd == "jobs":
            return run_cicd_jobs(
                path=parsed.path,  # type: ignore[attr-defined]
                output_format=getattr(parsed, "output_format", "table"),
            )
        if cicd_cmd == "job":
            return run_cicd_job_show(
                path=parsed.path,  # type: ignore[attr-defined]
                job_name=parsed.job_name,  # type: ignore[attr-defined]
                output_format=getattr(parsed, "output_format", "table"),
            )
        if cicd_cmd == "stages":
            return run_cicd_stages(
                path=parsed.path,  # type: ignore[attr-defined]
                output_format=getattr(parsed, "output_format", "table"),
            )
        if cicd_cmd == "validate":
            return run_cicd_validate(path=parsed.path)  # type: ignore[attr-defined]
        if cicd_cmd == "render":
            params: tuple[str, ...] | None = tuple(parsed.params) if parsed.params else None  # type: ignore[attr-defined]
            return run_cicd_render(
                path=parsed.path,  # type: ignore[attr-defined]
                workflow_name=parsed.workflow_name,  # type: ignore[attr-defined]
                params=params,
                output_file=getattr(parsed, "output_file", None),
            )
        sys.stderr.write(
            "Usage: kata tax cicd {workflows|workflow|jobs|job|stages|validate|render} ...\n",
        )
        sys.stderr.write("\nSubcommands:\n")
        sys.stderr.write("  workflows  List workflow templates\n")
        sys.stderr.write("  workflow   Show workflow details\n")
        sys.stderr.write("  jobs       List job templates\n")
        sys.stderr.write("  job        Show job template details\n")
        sys.stderr.write("  stages     List CICD stages\n")
        sys.stderr.write("  validate   Validate CICD templates\n")
        sys.stderr.write("  render     Render a workflow template\n")
        return 1

    if tax_command == "status":
        from katalyst_taxonomy.cli.commands.status import run_status

        return run_status(path=parsed.path)  # type: ignore[attr-defined]

    if tax_command == "init":
        from katalyst_taxonomy.cli.commands.init import run_init

        # Convert list arguments to tuples
        plugins: tuple[str, ...] | None = tuple(parsed.plugins) if parsed.plugins else None  # type: ignore[attr-defined]
        layer_types: tuple[str, ...] | None = (
            tuple(parsed.layer_types) if parsed.layer_types else None  # type: ignore[attr-defined]
        )

        return run_init(
            path=parsed.path,  # type: ignore[attr-defined]
            source=parsed.source,  # type: ignore[attr-defined]
            plugins=plugins,
            layer_types=layer_types,
            interactive=not parsed.yes,  # type: ignore[attr-defined]
        )

    if tax_command == "upgrade":
        from katalyst_taxonomy.cli.commands.upgrade import run_upgrade

        # Convert list arguments to tuples
        components: tuple[str, ...] | None = (
            tuple(parsed.components) if parsed.components else None  # type: ignore[attr-defined]
        )

        return run_upgrade(
            path=parsed.path,  # type: ignore[attr-defined]
            source=parsed.source,  # type: ignore[attr-defined]
            components=components,
            dry_run=parsed.dry_run,  # type: ignore[attr-defined]
            check_only=parsed.check,  # type: ignore[attr-defined]
            yes=parsed.yes,  # type: ignore[attr-defined]
            no_backup=parsed.no_backup,  # type: ignore[attr-defined]
            show_diff=parsed.diff,  # type: ignore[attr-defined]
        )

    if tax_command == "rollback":
        from katalyst_taxonomy.cli.commands.rollback import run_rollback

        return run_rollback(
            path=parsed.path,  # type: ignore[attr-defined]
            list_backups=parsed.list_backups,  # type: ignore[attr-defined]
            backup_name=parsed.backup_name,  # type: ignore[attr-defined]
            yes=parsed.yes,  # type: ignore[attr-defined]
        )

    if tax_command == "add":
        from katalyst_taxonomy.cli.commands.add import run_add

        # Convert list arguments to tuples
        plugins: tuple[str, ...] | None = tuple(parsed.plugins) if parsed.plugins else None  # type: ignore[attr-defined]
        layer_types: tuple[str, ...] | None = (
            tuple(parsed.layer_types) if parsed.layer_types else None  # type: ignore[attr-defined]
        )

        return run_add(
            path=parsed.path,  # type: ignore[attr-defined]
            plugins=plugins,
            layer_types=layer_types,
            source=parsed.source,  # type: ignore[attr-defined]
            force=parsed.force,  # type: ignore[attr-defined]
            yes=parsed.yes,  # type: ignore[attr-defined]
        )

    if tax_command == "remove":
        from katalyst_taxonomy.cli.commands.remove import run_remove

        # Convert list arguments to tuples
        plugins: tuple[str, ...] | None = tuple(parsed.plugins) if parsed.plugins else None  # type: ignore[attr-defined]
        layer_types: tuple[str, ...] | None = (
            tuple(parsed.layer_types) if parsed.layer_types else None  # type: ignore[attr-defined]
        )

        return run_remove(
            path=parsed.path,  # type: ignore[attr-defined]
            plugins=plugins,
            layer_types=layer_types,
            force=parsed.force,  # type: ignore[attr-defined]
            yes=parsed.yes,  # type: ignore[attr-defined]
        )

    if tax_command == "clone":
        from katalyst_taxonomy.cli.commands.clone import run_clone

        # Convert list arguments to tuples
        owners: tuple[str, ...] | None = tuple(parsed.owners) if parsed.owners else None  # type: ignore[attr-defined]
        environments: tuple[str, ...] | None = (
            tuple(parsed.environments) if parsed.environments else None  # type: ignore[attr-defined]
        )

        return run_clone(
            path=parsed.path,  # type: ignore[attr-defined]
            node_type=parsed.type,  # type: ignore[attr-defined]
            source_name=parsed.source,  # type: ignore[attr-defined]
            target_name=parsed.target,  # type: ignore[attr-defined]
            source_system=getattr(parsed, "source_system", None),
            source_subsystem=getattr(parsed, "source_subsystem", None),
            source_stack=getattr(parsed, "source_stack", None),
            target_system=getattr(parsed, "target_system", None),
            target_subsystem=getattr(parsed, "target_subsystem", None),
            target_stack=getattr(parsed, "target_stack", None),
            description=parsed.description,  # type: ignore[attr-defined]
            owners=owners,
            environments=environments,
            layer_type=getattr(parsed, "layer_type", None),
            scaffold=parsed.scaffold,  # type: ignore[attr-defined]
            yes=parsed.yes,  # type: ignore[attr-defined]
        )

    if tax_command == "agents":
        from katalyst_taxonomy.cli.commands.agents import (
            run_agents_create,
            run_agents_generate,
            run_agents_init,
            run_agents_list,
            run_agents_show,
            run_agents_sync,
            run_agents_validate,
        )

        agents_cmd = getattr(parsed, "agents_command", None)
        if agents_cmd == "init":
            return run_agents_init(
                path=parsed.path,  # type: ignore[attr-defined]
                force=getattr(parsed, "force", False),
                no_seed=getattr(parsed, "no_seed", False),
            )
        if agents_cmd == "list":
            return run_agents_list(
                path=parsed.path,  # type: ignore[attr-defined]
                format=getattr(parsed, "output_format", "table"),
                verbose=getattr(parsed, "verbose", False),
                layer_type=getattr(parsed, "layer_type", None),
            )
        if agents_cmd == "show":
            return run_agents_show(
                path=parsed.path,  # type: ignore[attr-defined]
                name=cast(str, parsed.name),  # type: ignore[attr-defined]
                format=getattr(parsed, "output_format", "table"),
            )
        if agents_cmd == "validate":
            return run_agents_validate(path=parsed.path)  # type: ignore[attr-defined]
        if agents_cmd == "sync":
            return run_agents_sync(
                path=parsed.path,  # type: ignore[attr-defined]
                force=getattr(parsed, "force", False),
                dry_run=getattr(parsed, "dry_run", False),
            )
        if agents_cmd == "create":
            # Parse tools from --tool args (format: tool:true/false)
            tools: dict[str, bool] | None = None
            raw_tools = getattr(parsed, "tools", None)
            if raw_tools:
                tools = {}
                for tool_spec in raw_tools:
                    if ":" in tool_spec:
                        tool_name, enabled = tool_spec.split(":", 1)
                        tools[tool_name] = enabled.lower() in ("true", "1", "yes")
                    else:
                        tools[tool_spec] = True

            return run_agents_create(
                path=parsed.path,  # type: ignore[attr-defined]
                name=cast(str, parsed.name),  # type: ignore[attr-defined]
                description=cast(str, parsed.description),  # type: ignore[attr-defined]
                mode=getattr(parsed, "mode", "all"),
                tools=tools,
                scope_layers=getattr(parsed, "scope_layers", None),
                scope_systems=getattr(parsed, "scope_systems", None),
                scope_stacks=getattr(parsed, "scope_stacks", None),
                scope_layer_types=getattr(parsed, "scope_layer_types", None),
            )
        if agents_cmd == "generate":
            return run_agents_generate(
                path=parsed.path,  # type: ignore[attr-defined]
                template=getattr(parsed, "template", None),
                layer_type=getattr(parsed, "layer_type", None),
                all_layer_types=getattr(parsed, "all_layer_types", False),
                list_templates=getattr(parsed, "list_templates", False),
                force=getattr(parsed, "force", False),
            )
        sys.stderr.write(
            "Usage: kata tax agents {init|list|show|validate|sync|create|generate} ...\n"
        )
        sys.stderr.write("\nSubcommands:\n")
        sys.stderr.write("  init      Initialize .agents/ directory and create symlinks\n")
        sys.stderr.write("  list      List all agents and skills\n")
        sys.stderr.write("  show      Show details of an agent or skill\n")
        sys.stderr.write("  validate  Validate all agent definitions\n")
        sys.stderr.write("  sync      Sync bundled agents/skills into local .agents/\n")
        sys.stderr.write("  create    Create a new agent definition\n")
        sys.stderr.write("  generate  Generate agents from templates for layer types\n")
        return 1

    if tax_command == "archetype":
        from katalyst_taxonomy.cli.commands.archetype import (
            run_archetype_list,
            run_archetype_show,
        )

        archetype_cmd = getattr(parsed, "archetype_command", None)
        if archetype_cmd == "list":
            return run_archetype_list(path=parsed.path)  # type: ignore[attr-defined]
        if archetype_cmd == "show":
            return run_archetype_show(
                path=parsed.path,  # type: ignore[attr-defined]
                name=cast(str, parsed.name),  # type: ignore[attr-defined]
            )
        sys.stderr.write("Usage: kata tax archetype {list|show} ...\n")
        sys.stderr.write("\nSubcommands:\n")
        sys.stderr.write("  list    List installed archetypes\n")
        sys.stderr.write("  show    Show archetype details and tree structure\n")
        return 1

    sys.stderr.write(f"Unknown tax command: {tax_command}\n")
    sys.stderr.write("Run 'kata tax --help' for available commands.\n")
    return 1


if __name__ == "__main__":
    sys.exit(main())
