"""Shared taxonomy loading utilities for CLI commands."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from katalyst_taxonomy.server.manager import ServerError, ensure_server
from katalyst_taxonomy.services.taxonomy import TaxonomyService


def load_from_filesystem(path: Path) -> TaxonomyService:
    """Load taxonomy data from the filesystem.

    This is used internally by the server and for testing.
    CLI commands should use load_taxonomy() instead.
    """
    from katalyst_taxonomy.adapters.filesystem import FilesystemTaxonomyRepository

    repo = FilesystemTaxonomyRepository(base_path=path)
    documents = repo.load_documents(path)
    environments = repo.load_environments(path)
    errors = repo.errors()

    return TaxonomyService(
        documents=documents,
        environments=environments,
        errors=errors,
    )


def load_from_server(server_url: str) -> TaxonomyService:
    """Load taxonomy data from the server."""
    import asyncio

    from katalyst_taxonomy.client import KatalystClient
    from katalyst_taxonomy.client.models import ErrorResponse, NodeResponse
    from katalyst_taxonomy.domain.errors import DocumentError
    from katalyst_taxonomy.taxonomy.documents import (
        TaxonomyDependencies,
        TaxonomyDocument,
        TaxonomyMetadata,
        TaxonomyParents,
        TaxonomySpec,
    )
    from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

    def _convert_node(node: NodeResponse) -> TaxonomyDocument:
        """Convert a NodeResponse to a TaxonomyDocument."""
        parents: TaxonomyParents | None = None
        if node.spec.parents:
            parent_node = node.spec.parents.get("node")
            if parent_node:
                parents = TaxonomyParents(node=str(parent_node))

        depends_on: TaxonomyDependencies | None = None
        if node.spec.depends_on:
            nodes_data: Any = node.spec.depends_on.get("nodes")
            if isinstance(nodes_data, list):
                depends_on = TaxonomyDependencies(
                    nodes=tuple(str(n) for n in nodes_data),  # type: ignore[misc]
                )

        annotations: Mapping[str, str] = node.spec.annotations or {}
        owners: tuple[str, ...] = node.spec.owners or ()
        environments: tuple[str, ...] = node.spec.environments or ()

        metadata = TaxonomyMetadata(
            name=node.metadata.name,
            labels=dict(node.metadata.labels) if node.metadata.labels else {},
        )
        spec = TaxonomySpec(
            description=node.spec.description,
            owners=owners,
            annotations=annotations,
            depends_on=depends_on,
            parents=parents,
            environments=environments,
        )
        return TaxonomyDocument(
            api_version=node.api_version,
            kind=node.kind,
            metadata=metadata,
            taxonomy_node_type=node.taxonomy_node_type,
            spec=spec,
            source_path=Path(node.source_path) if node.source_path else None,
        )

    def _convert_error(err: ErrorResponse) -> DocumentError:
        """Convert an ErrorResponse to a DocumentError."""
        return DocumentError(
            message=err.message,
            path=Path(err.path) if err.path else Path("<unknown>"),
            document_index=err.document_index or 0,
        )

    async def fetch() -> TaxonomyService:
        async with KatalystClient(base_url=server_url) as client:
            response = await client.get_taxonomy()

        # Convert response models to domain objects
        documents: list[TaxonomyDocument] = [_convert_node(node) for node in response.documents]

        # Convert environment responses
        env_documents: list[EnvironmentDocument] = []
        for env in response.environments:
            env_doc = EnvironmentDocument(
                name=env.name,
                description=env.description,
                template_replacements=dict(env.template_replacements),
                layer_templates={k: dict(v) for k, v in env.layer_templates.items()},
                source_path=Path(env.source_path) if env.source_path else None,
            )
            env_documents.append(env_doc)

        # Convert errors
        errors: list[DocumentError] = [_convert_error(e) for e in response.errors]

        return TaxonomyService(
            documents=tuple(documents),
            environments=tuple(env_documents),
            errors=tuple(errors),
        )

    return asyncio.run(fetch())


def load_taxonomy(path: Path) -> TaxonomyService:
    """Load taxonomy data, ensuring the server is running.

    This is the primary entry point for CLI commands. It:
    1. Ensures the server is running for the given path
    2. Loads taxonomy data via HTTP from the server

    Args:
        path: Path to the taxonomy directory.

    Returns:
        TaxonomyService with loaded taxonomy data.

    Raises:
        ServerError: If the server fails to start.
    """
    state = ensure_server(path)
    return load_from_server(state.url)


def get_base_path_from_server(path: Path) -> Path | None:
    """Get the base path that the server is using.

    Args:
        path: Path to ensure server is running for.

    Returns:
        The resolved base path the server is using, or None if server isn't running.
    """
    try:
        state = ensure_server(path)
        return Path(state.path)
    except ServerError:
        return None
