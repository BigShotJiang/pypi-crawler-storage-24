"""Serialization helpers for taxonomy documents."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from katalyst_taxonomy.services.taxonomy import TaxonomyService
from katalyst_taxonomy.taxonomy.documents import TaxonomyDocument


def serialize_document(
    doc: TaxonomyDocument,
    service: TaxonomyService,
    base_path: Path | None = None,
) -> dict[str, Any]:
    """Serialize a TaxonomyDocument to a JSON-compatible dict.

    Args:
        doc: The taxonomy document to serialize.
        service: The taxonomy service for resolving qualified names.
        base_path: Optional base path to make source paths relative.

    Returns:
        A dictionary suitable for JSON serialization.
    """
    result: dict[str, Any] = {
        "apiVersion": doc.api_version,
        "kind": doc.kind,
        "taxonomyNodeType": doc.taxonomy_node_type,
        "metadata": {
            "name": doc.metadata.name,
            "labels": dict(doc.metadata.labels) if doc.metadata.labels else {},
        },
        "spec": {
            "description": doc.spec.description,
            "owners": list(doc.spec.owners),
            "annotations": dict(doc.spec.annotations) if doc.spec.annotations else {},
            "environments": list(doc.spec.environments),
        },
        "qualifiedName": service.get_qualified_name(doc),
    }

    if doc.spec.parents:
        result["spec"]["parents"] = {"node": doc.spec.parents.node}

    if doc.spec.depends_on:
        result["spec"]["dependsOn"] = {"nodes": list(doc.spec.depends_on.nodes)}

    if doc.spec.extensions:
        result["spec"]["extensions"] = dict(doc.spec.extensions)

    if doc.source_path:
        if base_path:
            try:
                result["sourcePath"] = str(doc.source_path.relative_to(base_path))
            except ValueError:
                result["sourcePath"] = str(doc.source_path)
        else:
            result["sourcePath"] = str(doc.source_path)

    return result
