"""Console output formatting helpers."""

from __future__ import annotations

import sys
from typing import TextIO

# ANSI color codes
ANSI_RESET = "\033[0m"
HEADING_COLOR = "\033[96m"  # Cyan
ERROR_COLOR = "\033[91m"  # Red
WARNING_COLOR = "\033[93m"  # Yellow
SUCCESS_COLOR = "\033[92m"  # Green
PATH_COLOR = "\033[94m"  # Blue
DIM_COLOR = "\033[2m"  # Dim


def supports_color(stream: TextIO | None = None) -> bool:
    """Check if the given stream supports ANSI colors."""
    target: TextIO = stream if stream is not None else sys.stdout
    if not hasattr(target, "isatty"):
        return False
    try:
        return bool(target.isatty())
    except Exception:
        return False


def colorize(text: str, color: str, stream: TextIO | None = None) -> str:
    """Apply ANSI color to text if the stream supports it."""
    if not color or not supports_color(stream):
        return text
    return f"{color}{text}{ANSI_RESET}"


def write_heading(
    title: str,
    stream: TextIO | None = None,
    *,
    color: str = HEADING_COLOR,
) -> None:
    """Write a formatted heading to the stream."""
    target: TextIO = stream if stream is not None else sys.stdout
    line = f"{'=' * 6} {title.upper()} {'=' * 6}"
    target.write(colorize(line, color, target) + "\n")


def write_error(message: str, stream: TextIO | None = None) -> None:
    """Write an error message to stderr."""
    target: TextIO = stream if stream is not None else sys.stderr
    target.write(colorize(f"Error: {message}", ERROR_COLOR, target) + "\n")


def write_warning(message: str, stream: TextIO | None = None) -> None:
    """Write a warning message to stderr."""
    target: TextIO = stream if stream is not None else sys.stderr
    target.write(colorize(f"Warning: {message}", WARNING_COLOR, target) + "\n")


def write_success(message: str, stream: TextIO | None = None) -> None:
    """Write a success message to stdout."""
    target: TextIO = stream if stream is not None else sys.stdout
    target.write(colorize(message, SUCCESS_COLOR, target) + "\n")


# Node type ordering for display (matches legacy CLI)
KIND_ORDER: tuple[str, ...] = (
    "organization",
    "program",
    "project",
    "team",
    "team_member",
    "user",
    "system",
    "subsystem",
    "stack",
    "layer",
)

KIND_SECTION_TITLES: dict[str, str] = {
    "organization": "Organizations",
    "program": "Programs",
    "project": "Projects",
    "team": "Teams",
    "team_member": "Team Members",
    "user": "Users",
    "system": "Systems",
    "subsystem": "Subsystems",
    "stack": "Stacks",
    "layer": "Layers",
}
