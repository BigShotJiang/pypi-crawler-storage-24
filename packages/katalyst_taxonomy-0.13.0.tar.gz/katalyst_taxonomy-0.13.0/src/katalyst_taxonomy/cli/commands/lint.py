"""lint command - validate taxonomy against schema."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.cli.loaders import load_taxonomy
from katalyst_taxonomy.cli.output import write_error, write_success, write_warning
from katalyst_taxonomy.linting.environment_contract_linter import lint_environment_contracts


def run_lint(
    path: Path,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Execute the lint command."""
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    try:
        service = load_taxonomy(path)
    except FileNotFoundError as exc:
        write_error(str(exc), err)
        return 1
    except Exception as exc:
        write_error(f"Failed to load taxonomy: {exc}", err)
        return 1

    # Report errors
    if service.errors:
        for error in service.errors:
            rel_path = error.path.name if error.path else "<unknown>"
            write_warning(f"[{rel_path}] {error.message}", err)

        err.write(f"\nFound {len(service.errors)} error(s) in taxonomy.\n")
        return 1

    # Environment contract warnings
    contract_result = lint_environment_contracts(path)
    for warning in contract_result.warnings:
        write_warning(
            f"Environment '{warning.environment_name}' is missing "
            f"{warning.section} key '{warning.key}' "
            f"required by {warning.declared_by} "
            f"(layer: {warning.layer_qualified_name})",
            err,
        )
    if contract_result.has_warnings:
        err.write(
            f"\n{len(contract_result.warnings)} environment contract warning(s) "
            f"across {contract_result.checked_layers} layer(s) and "
            f"{contract_result.checked_environments} environment(s).\n",
        )

    # Success
    doc_count = len(service.documents)
    env_count = len(service.environments)
    write_success(
        f"Validated {doc_count} document(s) and {env_count} environment(s). No errors found.",
        out,
    )
    return 0
