"""status command - show installed Katalyst components and versions."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.adapters.filesystem.lock import LOCK_FILE_PATH, LockFileRepository
from katalyst_taxonomy.domain.lock import KatalystLock

# Try to get the CLI version
_cli_version: str
try:
    from katalyst_taxonomy.cli import __version__ as _imported_version

    _cli_version = _imported_version
except ImportError:
    _cli_version = "unknown"

CLI_VERSION: str = _cli_version


def _format_date(lock: KatalystLock) -> str:
    """Format the installation date for display."""
    return lock.installed.core.installed_at.strftime("%Y-%m-%d")


def _format_plugin_summary(plugin_name: str, lock: KatalystLock) -> str:
    """Format a single plugin line for display."""
    plugin = lock.get_plugin(plugin_name)
    if not plugin:
        return f"  {plugin_name:<16} (not installed)"

    parts = [f"  {plugin_name:<16} {plugin.version:<8} {plugin.source:<10}"]

    # Add canonical/custom counts for layer_types
    if plugin.canonical or plugin.custom:
        counts: list[str] = []
        if plugin.canonical:
            counts.append(f"{len(plugin.canonical)} canonical")
        if plugin.custom:
            counts.append(f"{len(plugin.custom)} custom")
        parts.append(", ".join(counts))

    return " ".join(parts)


def _print_status(lock: KatalystLock, stream: TextIO) -> None:
    """Print the status output."""
    stream.write("\n")
    stream.write("Katalyst Taxonomy Status\n")
    stream.write("=" * 40 + "\n\n")

    # Core section
    stream.write("Core:\n")
    stream.write(f"  Version:     {lock.installed.core.version}\n")
    stream.write(f"  Schema:      {lock.installed.core.schema_version}\n")
    stream.write(f"  Installed:   {_format_date(lock)}\n")
    stream.write(f"  Source:      {lock.installed.core.source}\n")
    stream.write("\n")

    # Plugins section
    stream.write("Plugins:\n")
    if lock.installed.plugins:
        # Sort plugins for consistent output
        for plugin_name in sorted(lock.installed.plugins.keys()):
            stream.write(_format_plugin_summary(plugin_name, lock) + "\n")
    else:
        stream.write("  (no plugins installed)\n")
    stream.write("\n")

    # Lock file location
    if lock.source_path:
        stream.write(f"Lock file: {lock.source_path}\n")
    else:
        stream.write(f"Lock file: {LOCK_FILE_PATH}\n")
    stream.write("\n")


def _print_no_lock(path: Path, stream: TextIO) -> None:
    """Print message when no lock file exists."""
    stream.write("\n")
    stream.write("No Katalyst lock file found.\n")
    stream.write("\n")
    stream.write(f"Expected location: {path / LOCK_FILE_PATH}\n")
    stream.write("\n")
    stream.write("This directory has not been initialized with Katalyst.\n")
    stream.write("Run 'kata tax init' to initialize a new taxonomy repository.\n")
    stream.write("\n")


def run_status(
    path: Path,
    *,
    stream: TextIO | None = None,
) -> int:
    """Run the status command.

    Args:
        path: Path to the repository root.
        stream: Output stream (defaults to stdout).

    Returns:
        Exit code (0 for success, 1 for no lock file).
    """
    out: TextIO = stream if stream is not None else sys.stdout

    repo = LockFileRepository(base_path=path)

    if not repo.exists():
        _print_no_lock(path, out)
        return 1

    try:
        lock = repo.load()
    except ValueError as e:
        sys.stderr.write(f"Error reading lock file: {e}\n")
        return 1

    if lock is None:
        _print_no_lock(path, out)
        return 1

    _print_status(lock, out)
    return 0
