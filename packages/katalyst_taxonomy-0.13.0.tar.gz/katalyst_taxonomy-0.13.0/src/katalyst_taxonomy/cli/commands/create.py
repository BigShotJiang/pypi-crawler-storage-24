"""create command - create new taxonomy nodes."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.cli.output import write_error, write_success


def prompt_missing_contract_keys(
    path: Path,
    layer_type: str,
    environments: tuple[str, ...],
    out: TextIO,
    inp: TextIO,
) -> None:
    """Check the environment contract and interactively prompt for missing values.

    If ``stdin`` is not a TTY (non-interactive / piped), missing keys are
    reported as warnings but no prompts are displayed.

    Args:
        path: Repository root.
        layer_type: The layer type that was just created.
        environments: Environments the layer was created with.
        out: Output stream for messages.
        inp: Input stream for interactive prompts.
    """
    from katalyst_taxonomy.services.environment import (
        check_environment_contract,
        get_configured_environments,
        update_environments_yaml,
    )

    # Check all configured environments, not just the ones passed to create.
    # The user may have dev/staging/prod in environments.yaml but only created
    # the layer with --env dev --env staging.  We still want to fill in values
    # for all envs so actions work correctly.
    all_envs = get_configured_environments(path)
    if not all_envs:
        all_envs = environments

    missing = check_environment_contract(
        base_path=path,
        layer_type=layer_type,
        environments=all_envs,
    )
    if not missing:
        return

    # Non-interactive: just warn
    is_tty = hasattr(inp, "isatty") and inp.isatty()
    if not is_tty:
        out.write(
            f"\nWarning: {layer_type} requires environment configuration "
            f"that is not yet set in environments.yaml.\n"
        )
        out.write("  Missing keys:\n")
        for m in missing:
            out.write(f"    [{m.environment}] {m.layer_type}.{m.key} - {m.description}\n")
        out.write(
            "\n  Run 'kata tax create' interactively or manually edit "
            ".global/taxonomy/environments.yaml\n"
        )
        return

    # Interactive: prompt for each missing key.
    # Group by key to allow "same value for all environments" shortcut.
    out.write(f"\n{layer_type} requires additional environment configuration.\n")
    out.write("Press Enter to skip a value (you can set it later in environments.yaml).\n\n")

    # Collect: env -> layer_type -> key -> value
    updates: dict[str, dict[str, dict[str, str]]] = {}

    # Deduplicate: group missing keys so we can offer "apply to all envs"
    keys_seen: dict[str, str] = {}  # key -> first value entered (for reuse)

    for m in missing:
        # If user already gave a value for this key in a previous env,
        # offer to reuse it
        default_hint = ""
        if m.key in keys_seen and keys_seen[m.key]:
            default_hint = keys_seen[m.key]

        prompt_text = f"  [{m.environment}] {m.description}"
        if default_hint:
            prompt_text += f" [{default_hint}]"
        prompt_text += ": "

        try:
            out.write(prompt_text)
            out.flush()
            value = inp.readline().strip()
        except (EOFError, KeyboardInterrupt):
            out.write("\n")
            return

        # Use default if empty and we have one
        if not value and default_hint:
            value = default_hint

        if not value:
            continue

        # Remember for reuse
        keys_seen[m.key] = value

        updates.setdefault(m.environment, {}).setdefault(m.layer_type, {})[m.key] = value

    if updates:
        update_environments_yaml(path, updates)
        out.write("\n  Updated environments.yaml with new values.\n")


def run_create(
    path: Path,
    node_type: str,
    name: str,
    description: str | None = None,
    owners: tuple[str, ...] | None = None,
    environments: tuple[str, ...] | None = None,
    parent: str | None = None,
    parent_subsystem: str | None = None,
    parent_system: str | None = None,
    layer_type: str | None = None,
    archetype: str | None = None,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Execute the create command.

    Args:
        path: Path to the repository root.
        node_type: Type of node to create (system, subsystem, stack, layer).
        name: Name of the new node.
        description: Optional description for the node.
        owners: Optional tuple of owner emails.
        environments: Optional tuple of environment names.
        parent: Direct parent name (required for subsystem/stack/layer).
        parent_subsystem: Parent subsystem name (for stack/layer).
        parent_system: Parent system name (for subsystem/stack/layer).
        layer_type: Layer type (for layer nodes).
        archetype: Archetype name to scaffold from.
        output: Optional output stream (defaults to stdout).
        err_output: Optional error stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # --- Archetype path ---------------------------------------------------
    if archetype:
        return _run_create_from_archetype(
            path=path,
            node_type=node_type,
            name=name,
            archetype_name=archetype,
            description=description,
            owners=owners,
            environments=environments,
            parent=parent,
            parent_subsystem=parent_subsystem,
            parent_system=parent_system,
            out=out,
            err=err,
        )

    # --- Normal (single-node) path ----------------------------------------
    # Import here to avoid circular imports and allow lazy loading
    from katalyst_taxonomy.adapters.filesystem import FilesystemWriter
    from katalyst_taxonomy.ports.filesystem import RealFilesystem
    from katalyst_taxonomy.ports.taxonomy import CreationRequest
    from katalyst_taxonomy.services.creation import CreationService

    # Build the creation request
    request = CreationRequest(
        node_type=node_type,
        name=name,
        description=description,
        owners=owners if owners else (),
        environments=environments if environments else (),
        parent=parent,
        parent_subsystem=parent_subsystem,
        parent_system=parent_system,
        layer_type=layer_type,
    )

    # Create the service with a filesystem writer and filesystem adapter
    writer = FilesystemWriter()
    filesystem = RealFilesystem()
    service = CreationService(writer=writer, filesystem=filesystem)

    # Execute creation
    result = service.create(path, request)

    if result.success:
        rel_path = result.path
        if result.path:
            try:
                rel_path = result.path.relative_to(path)
            except ValueError:
                rel_path = result.path

        write_success(f"Created {node_type} '{name}' at {rel_path}", out)

        # Check environment contract for layer types
        if node_type == "layer" and layer_type:
            envs = environments if environments else ("dev",)
            prompt_missing_contract_keys(path, layer_type, envs, out, sys.stdin)

        return 0
    write_error(result.error or "Unknown error during creation", err)
    return 1


def _run_create_from_archetype(
    path: Path,
    node_type: str,
    name: str,
    archetype_name: str,
    description: str | None,
    owners: tuple[str, ...] | None,
    environments: tuple[str, ...] | None,
    parent: str | None,
    parent_subsystem: str | None,
    parent_system: str | None,
    out: TextIO,
    err: TextIO,
) -> int:
    """Create a taxonomy subtree from an archetype definition.

    Args:
        path: Repository root.
        node_type: Root node type (system, subsystem, stack).
        name: Name for the root node.
        archetype_name: Name of the archetype to use.
        description: Optional description override for the root node.
        owners: Owner emails to propagate to all nodes.
        environments: Environment names to propagate to all nodes.
        parent: Direct parent name.
        parent_subsystem: Parent subsystem name.
        parent_system: Parent system name.
        out: Output stream.
        err: Error stream.

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    from katalyst_taxonomy.adapters.filesystem import FilesystemWriter
    from katalyst_taxonomy.ports.filesystem import RealFilesystem
    from katalyst_taxonomy.services.archetype import ArchetypeService, resolve_archetype

    if node_type == "layer":
        write_error("Archetypes cannot be used with layer nodes. Use --layer-type instead.", err)
        return 1

    # Resolve the archetype
    archetype = resolve_archetype(path, archetype_name)
    if archetype is None:
        write_error(
            f"Archetype '{archetype_name}' not found. "
            f"Run 'kata tax archetype list' to see available archetypes.",
            err,
        )
        return 1

    # Use archetype description as fallback
    writer = FilesystemWriter()
    filesystem = RealFilesystem()
    service = ArchetypeService(writer=writer, filesystem=filesystem)

    result = service.create_from_archetype(
        base_path=path,
        archetype=archetype,
        root_name=name,
        root_node_type=node_type,
        environments=tuple(environments) if environments else ("dev",),
        owners=tuple(owners) if owners else (),
        parent=parent,
        parent_subsystem=parent_subsystem,
        parent_system=parent_system,
        description_override=description,
    )

    if result.success:
        out.write(f"\nCreated {node_type} '{name}' from archetype '{archetype_name}':\n")
        for node in result.created_nodes:
            marker = f" ({node.layer_type})" if node.layer_type else ""
            try:
                rel = node.path.relative_to(path)
            except ValueError:
                rel = node.path
            out.write(f"  [{node.node_type}] {node.name}{marker} -> {rel}\n")
        out.write(f"\n  Total: {len(result.created_nodes)} nodes created.\n")
        return 0

    write_error(result.error or "Unknown error during archetype creation", err)
    return 1
