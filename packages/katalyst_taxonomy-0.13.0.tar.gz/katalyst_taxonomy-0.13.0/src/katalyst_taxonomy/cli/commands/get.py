"""get command - retrieve a single taxonomy node."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.cli.loaders import load_taxonomy
from katalyst_taxonomy.cli.output import write_error
from katalyst_taxonomy.cli.serializers import serialize_document
from katalyst_taxonomy.services.taxonomy import TaxonomyService
from katalyst_taxonomy.taxonomy.documents import TaxonomyDocument

# Format constants
FORMAT_JSON = "json"
FORMAT_LIST = "list"


def _output_json(
    doc: TaxonomyDocument,
    service: TaxonomyService,
    out: TextIO,
    base_path: Path | None = None,
) -> None:
    """Output document as JSON."""
    payload = serialize_document(doc, service, base_path)
    json.dump(payload, out, indent=2)
    out.write("\n")


def _output_list(
    doc: TaxonomyDocument,
    service: TaxonomyService,
    out: TextIO,
) -> None:
    """Output document in human-readable format."""
    fqtn = service.get_qualified_name(doc)

    out.write(f"Name:        {doc.metadata.name}\n")
    out.write(f"Type:        {doc.taxonomy_node_type}\n")
    out.write(f"Qualified:   {fqtn}\n")

    if doc.spec.description:
        out.write(f"Description: {doc.spec.description}\n")

    if doc.spec.owners:
        out.write(f"Owners:      {', '.join(doc.spec.owners)}\n")

    if doc.spec.environments:
        out.write(f"Environments: {', '.join(doc.spec.environments)}\n")

    if doc.spec.parents:
        out.write(f"Parent:      {doc.spec.parents.node}\n")

    if doc.spec.depends_on and doc.spec.depends_on.nodes:
        out.write(f"Depends On:  {', '.join(doc.spec.depends_on.nodes)}\n")

    if doc.metadata.labels:
        labels_str = ", ".join(f"{k}={v}" for k, v in doc.metadata.labels.items())
        out.write(f"Labels:      {labels_str}\n")

    if doc.source_path:
        out.write(f"Source:      {doc.source_path}\n")


def run_get(
    path: Path,
    name: str,
    output_format: str = FORMAT_JSON,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Execute the get command."""
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    try:
        service = load_taxonomy(path)
        base_path = path
    except FileNotFoundError as exc:
        write_error(str(exc), err)
        return 1
    except Exception as exc:
        write_error(f"Failed to load taxonomy: {exc}", err)
        return 1

    # Find the document by name
    doc = service.get_document_by_name(name)
    if doc is None:
        write_error(f"Node '{name}' not found", err)
        return 1

    # Output in requested format
    if output_format == FORMAT_JSON:
        _output_json(doc, service, out, base_path)
    elif output_format == FORMAT_LIST:
        _output_list(doc, service, out)
    else:
        write_error(f"Unknown format: {output_format}", err)
        return 1

    return 0
