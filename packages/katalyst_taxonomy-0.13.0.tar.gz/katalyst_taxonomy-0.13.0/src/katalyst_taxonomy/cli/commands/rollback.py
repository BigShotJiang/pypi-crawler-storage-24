"""rollback command - restore from backup."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.adapters.filesystem.lock import LockFileRepository
from katalyst_taxonomy.services.rollback import (
    ListBackupsResult,
    RollbackConfig,
    RollbackResult,
    RollbackService,
    RollbackStatus,
)


def _print_not_initialized(stream: TextIO) -> None:
    """Print message when not initialized."""
    stream.write("Error: Repository not initialized.\n")
    stream.write("\n")
    stream.write("Run 'kata tax init' first to initialize a taxonomy repository.\n")


def _print_no_backups(stream: TextIO) -> None:
    """Print message when no backups exist."""
    stream.write("\n")
    stream.write("No backups available.\n")
    stream.write("\n")
    stream.write("Backups are created automatically when running 'kata tax upgrade'.\n")
    stream.write("Use 'kata tax upgrade --no-backup' to skip backup creation.\n")
    stream.write("\n")


def _print_backup_list(result: ListBackupsResult, stream: TextIO) -> None:
    """Print list of available backups."""
    stream.write("\n")
    stream.write("Available Backups\n")
    stream.write("=" * 40 + "\n\n")

    for i, backup in enumerate(result.backups):
        marker = " (latest)" if i == 0 else ""
        timestamp_str = backup.timestamp.strftime("%Y-%m-%d %H:%M:%S UTC")
        lock_status = "has lock file" if backup.has_lock else "no lock file"
        stream.write(f"  {backup.name}{marker}\n")
        stream.write(f"    Created: {timestamp_str}\n")
        stream.write(f"    Status: {lock_status}\n")
        stream.write("\n")

    stream.write(f"Total: {len(result.backups)} backup(s)\n")
    stream.write("\n")
    stream.write("To restore from a backup:\n")
    stream.write("  kata tax rollback                          # Restore latest\n")
    stream.write("  kata tax rollback --backup <backup_name>   # Restore specific\n")
    stream.write("\n")


def _print_rollback_success(result: RollbackResult, stream: TextIO) -> None:
    """Print success message after rollback."""
    stream.write("\n")
    stream.write("Rollback Complete\n")
    stream.write("=" * 40 + "\n\n")

    if result.backup:
        stream.write(f"Restored from: {result.backup.name}\n")
        timestamp_str = result.backup.timestamp.strftime("%Y-%m-%d %H:%M:%S UTC")
        stream.write(f"Backup created: {timestamp_str}\n")

    stream.write("\n")
    stream.write("Run 'kata tax status' to see the current configuration.\n")
    stream.write("\n")


def _print_rollback_failed(result: RollbackResult, stream: TextIO) -> None:
    """Print failure message."""
    stream.write("Error: Rollback failed.\n")
    if result.error:
        stream.write(f"Reason: {result.error}\n")


def _confirm_rollback(backup_name: str, stream: TextIO, in_stream: TextIO) -> bool:
    """Prompt user to confirm rollback.

    Args:
        backup_name: Name of the backup to restore.
        stream: Output stream.
        in_stream: Input stream for reading confirmation.

    Returns:
        True if user confirms, False otherwise.
    """
    stream.write(f"\nThis will restore from backup: {backup_name}\n")
    stream.write("Current state will be overwritten.\n")
    stream.write("\n")
    stream.write("Proceed with rollback? [y/N] ")
    stream.flush()

    response = in_stream.readline().strip().lower()
    return response in ("y", "yes")


def run_rollback(
    path: Path,
    *,
    list_backups: bool = False,
    backup_name: str | None = None,
    yes: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
    in_stream: TextIO | None = None,
) -> int:
    """Run the rollback command.

    Args:
        path: Path to the repository root.
        list_backups: If True, only list available backups.
        backup_name: Specific backup to restore (None for latest).
        yes: If True, skip confirmation prompt.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).
        in_stream: Input stream for interactive prompts.

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr
    inp: TextIO = in_stream if in_stream is not None else sys.stdin

    # Create adapters
    lock_repo = LockFileRepository(base_path=path)

    # Create service
    service = RollbackService(lock_repository=lock_repo)

    # Build config
    config = RollbackConfig(target_path=path, backup_name=backup_name)

    # List backups mode
    if list_backups:
        result = service.list_backups(config)

        if result.status == RollbackStatus.NOT_INITIALIZED:
            _print_not_initialized(err)
            return 1

        if result.status == RollbackStatus.NO_BACKUPS:
            _print_no_backups(out)
            return 0

        _print_backup_list(result, out)
        return 0

    # Rollback mode - first check what backup we'll use
    list_result = service.list_backups(config)

    if list_result.status == RollbackStatus.NOT_INITIALIZED:
        _print_not_initialized(err)
        return 1

    if list_result.status == RollbackStatus.NO_BACKUPS:
        _print_no_backups(out)
        return 1

    # Determine which backup to use
    target_backup_name = backup_name
    if target_backup_name is None:
        target_backup_name = list_result.backups[0].name

    # Confirm if interactive
    if not yes and sys.stdin.isatty():
        if not _confirm_rollback(target_backup_name, out, inp):
            out.write("\nRollback cancelled.\n")
            return 0

    # Perform rollback
    result = service.rollback(config)

    # Handle result
    if result.status == RollbackStatus.NOT_INITIALIZED:
        _print_not_initialized(err)
        return 1

    if result.status == RollbackStatus.NO_BACKUPS:
        _print_no_backups(err)
        return 1

    if result.status == RollbackStatus.BACKUP_NOT_FOUND:
        err.write(f"Error: Backup '{backup_name}' not found.\n")
        err.write("\nRun 'kata tax rollback --list' to see available backups.\n")
        return 1

    if result.status == RollbackStatus.SUCCESS:
        _print_rollback_success(result, out)
        return 0

    if result.status == RollbackStatus.FAILED:
        _print_rollback_failed(result, err)
        return 1

    # Should not reach here
    err.write(f"Unexpected status: {result.status}\n")
    return 1
