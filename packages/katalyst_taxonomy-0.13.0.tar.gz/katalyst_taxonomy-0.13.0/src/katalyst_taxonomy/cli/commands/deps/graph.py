"""Dependency graph building logic."""

from __future__ import annotations

from katalyst_taxonomy.services.taxonomy import TaxonomyService
from katalyst_taxonomy.taxonomy.documents import TaxonomyDocument

from .models import DependencyGraph, DependencyNode


def build_dependency_graph(service: TaxonomyService) -> DependencyGraph:
    """Build a dependency graph from the taxonomy service.

    Args:
        service: The taxonomy service with loaded documents.

    Returns:
        A DependencyGraph containing nodes, cycles, and unresolved dependencies.
    """
    graph = DependencyGraph()

    # Build lookup maps
    fqtn_to_doc: dict[str, TaxonomyDocument] = {}
    name_to_fqtns: dict[str, list[str]] = {}

    for doc in service.documents:
        fqtn = service.get_qualified_name(doc)
        fqtn_to_doc[fqtn] = doc
        name_to_fqtns.setdefault(doc.metadata.name, []).append(fqtn)

        # Create node in graph
        graph.nodes[fqtn] = DependencyNode(
            fqtn=fqtn,
            name=doc.metadata.name,
            node_type=doc.taxonomy_node_type,
        )

    # Process dependencies
    for doc in service.documents:
        fqtn = service.get_qualified_name(doc)
        if not doc.spec.depends_on or not doc.spec.depends_on.nodes:
            continue

        for dep_ref in doc.spec.depends_on.nodes:
            resolved_fqtn = _resolve_dependency(dep_ref, fqtn, fqtn_to_doc, name_to_fqtns)

            if resolved_fqtn:
                graph.nodes[fqtn].dependencies.append(resolved_fqtn)
                graph.nodes[resolved_fqtn].dependents.append(fqtn)
            else:
                # Track unresolved dependency
                graph.unresolved.setdefault(fqtn, []).append(dep_ref)

    # Detect cycles
    graph.cycles = _detect_cycles(graph)

    return graph


def _resolve_dependency(
    dep_ref: str,
    source_fqtn: str,
    fqtn_to_doc: dict[str, TaxonomyDocument],
    name_to_fqtns: dict[str, list[str]],
) -> str | None:
    """Resolve a dependency reference to an FQTN.

    Resolution order:
    1. Exact FQTN match
    2. Simple name within same system (prefer closer hierarchy)
    3. Simple name globally (if unique)

    Args:
        dep_ref: The dependency reference (name or FQTN).
        source_fqtn: The FQTN of the node declaring the dependency.
        fqtn_to_doc: Map of FQTNs to documents.
        name_to_fqtns: Map of simple names to FQTNs.

    Returns:
        The resolved FQTN, or None if unresolved.
    """
    # Direct FQTN match
    if dep_ref in fqtn_to_doc:
        return dep_ref

    # Try to resolve by simple name
    candidates = name_to_fqtns.get(dep_ref, [])

    if not candidates:
        return None

    if len(candidates) == 1:
        return candidates[0]

    # Multiple candidates - prefer one in the same system
    source_system = source_fqtn.split(".")[0] if "." in source_fqtn else source_fqtn
    same_system = [c for c in candidates if c.startswith(f"{source_system}.")]

    if len(same_system) == 1:
        return same_system[0]

    # Prefer closest in hierarchy (most path overlap)
    source_parts = source_fqtn.split(".")
    best_match: str | None = None
    best_overlap = -1

    for candidate in candidates:
        cand_parts = candidate.split(".")
        overlap = sum(1 for a, b in zip(source_parts, cand_parts, strict=False) if a == b)
        if overlap > best_overlap:
            best_overlap = overlap
            best_match = candidate

    return best_match


def _detect_cycles(graph: DependencyGraph) -> list[list[str]]:
    """Detect cycles in the dependency graph using DFS.

    Args:
        graph: The dependency graph to analyze.

    Returns:
        A list of cycles, where each cycle is a list of FQTNs.
    """
    cycles: list[list[str]] = []
    visited: set[str] = set()
    rec_stack: set[str] = set()
    path: list[str] = []

    def dfs(node: str) -> None:
        visited.add(node)
        rec_stack.add(node)
        path.append(node)

        for dep in graph.nodes.get(
            node,
            DependencyNode(fqtn="", name="", node_type=""),
        ).dependencies:
            if dep not in visited:
                dfs(dep)
            elif dep in rec_stack:
                # Found a cycle - extract it from the path
                cycle_start = path.index(dep)
                cycle = path[cycle_start:] + [dep]
                # Normalize cycle to avoid duplicates (start from smallest)
                min_idx = cycle.index(min(cycle[:-1]))
                normalized = cycle[min_idx:-1] + cycle[:min_idx] + [cycle[min_idx]]
                if normalized not in cycles:
                    cycles.append(normalized)

        path.pop()
        rec_stack.remove(node)

    for node in graph.nodes:
        if node not in visited:
            dfs(node)

    return cycles
