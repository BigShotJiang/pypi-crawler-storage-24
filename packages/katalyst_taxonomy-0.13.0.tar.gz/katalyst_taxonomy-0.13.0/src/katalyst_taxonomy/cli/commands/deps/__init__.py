"""deps command - show dependency graph for taxonomy nodes."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.cli.loaders import load_taxonomy
from katalyst_taxonomy.cli.output import write_error, write_warning

from .formatters import output_json, output_list, output_mermaid, output_tree
from .graph import build_dependency_graph
from .models import DependencyGraph, DependencyNode

# Format constants
FORMAT_TREE = "tree"
FORMAT_LIST = "list"
FORMAT_JSON = "json"
FORMAT_MERMAID = "mermaid"

# Re-export for backwards compatibility
__all__ = [
    "DependencyGraph",
    "DependencyNode",
    "FORMAT_JSON",
    "FORMAT_LIST",
    "FORMAT_MERMAID",
    "FORMAT_TREE",
    "build_dependency_graph",
    "run_deps",
]


def run_deps(
    path: Path,
    output_format: str = FORMAT_TREE,
    node: str | None = None,
    reverse: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Execute the deps command.

    Args:
        path: Path to the taxonomy directory.
        output_format: Output format (tree, list, json, mermaid).
        node: Optional node name or FQTN to filter to.
        reverse: If True, show dependents instead of dependencies.
        output: Output stream (defaults to stdout).
        err_output: Error stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 1 for error).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    try:
        service = load_taxonomy(path)
    except FileNotFoundError as exc:
        write_error(str(exc), err)
        return 1
    except Exception as exc:
        write_error(f"Failed to load taxonomy: {exc}", err)
        return 1

    # Build dependency graph
    graph = build_dependency_graph(service)

    # Report warnings
    if graph.cycles:
        for cycle in graph.cycles:
            cycle_str = " → ".join(cycle)
            write_warning(f"Circular dependency detected: {cycle_str}", err)

    if graph.unresolved:
        for fqtn, deps in graph.unresolved.items():
            for dep in deps:
                write_warning(f"Unresolved dependency: {fqtn} → {dep}", err)

    # Output in requested format
    if output_format == FORMAT_TREE:
        output_tree(graph, service, node, reverse, out)
    elif output_format == FORMAT_LIST:
        output_list(graph, service, out)
    elif output_format == FORMAT_JSON:
        output_json(graph, service, out)
    elif output_format == FORMAT_MERMAID:
        output_mermaid(graph, service, node, out)
    else:
        write_error(f"Unknown format: {output_format}", err)
        return 1

    return 0
