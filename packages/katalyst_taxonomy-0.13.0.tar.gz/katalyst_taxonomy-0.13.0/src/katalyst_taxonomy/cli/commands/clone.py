"""clone command - clone taxonomy nodes (layers, stacks, subsystems)."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, TextIO

from katalyst_taxonomy.services.clone import (
    CloneConfig,
    CloneResult,
    CloneService,
    CloneStatus,
    RealCloneFilesystem,
)

# Type alias for document dicts
DocumentDict = dict[str, Any]
TaxonomyData = dict[str, Any]


class SimpleTaxonomyLoader:
    """Simple taxonomy loader using the taxonomy service."""

    def __init__(self, path: Path) -> None:
        """Initialize with repository path."""
        self._path = path

    def load(self, path: Path) -> TaxonomyData:
        """Load taxonomy and return documents."""
        from katalyst_taxonomy.taxonomy.service import load_taxonomy
        from katalyst_taxonomy.taxonomy.utils import extract_layer_type

        result = load_taxonomy(path)
        # Convert TaxonomyDocument objects to dicts for compatibility
        documents: list[DocumentDict] = []
        for doc in result.documents:
            spec_dict: dict[str, Any] = {}
            # Copy spec fields
            if doc.spec:
                if doc.spec.description:
                    spec_dict["description"] = doc.spec.description
                if doc.spec.owners:
                    spec_dict["owners"] = list(doc.spec.owners)
                if doc.spec.environments:
                    spec_dict["environments"] = list(doc.spec.environments)
                if doc.spec.parents:
                    spec_dict["parents"] = {"node": doc.spec.parents.node}

            doc_dict: DocumentDict = {
                "apiVersion": doc.api_version,
                "kind": doc.kind,
                "metadata": {"name": doc.metadata.name},
                "taxonomyNodeType": doc.taxonomy_node_type,
                "spec": spec_dict,
                "sourcePath": str(doc.source_path) if doc.source_path else None,
            }

            # Extract layer type using the helper
            layer_type = extract_layer_type(doc)
            if layer_type:
                spec_dict["layerType"] = layer_type
            documents.append(doc_dict)

        return {
            "documents": documents,
            "errors": [str(e) for e in result.errors],
        }

    def find_by_name(self, name: str, node_type: str | None = None) -> list[DocumentDict]:
        """Find documents by name and optional type."""
        result = self.load(self._path)
        documents: list[DocumentDict] = result.get("documents", [])
        matches: list[DocumentDict] = []
        for doc in documents:
            metadata: dict[str, Any] | None = doc.get("metadata")
            if isinstance(metadata, dict) and metadata.get("name") == name:
                if node_type is None or doc.get("taxonomyNodeType") == node_type:
                    matches.append(doc)
        return matches


def _print_not_initialized(stream: TextIO) -> None:
    """Print message when not initialized."""
    stream.write("Error: Repository not initialized.\n")
    stream.write("\n")
    stream.write("Run 'kata tax init' first to initialize a taxonomy repository.\n")


def _print_source_not_found(result: CloneResult, node_type: str, stream: TextIO) -> None:
    """Print message when source node not found."""
    stream.write(f"Error: {node_type.title()} not found.\n")
    if result.error:
        stream.write(f"Details: {result.error}\n")
    stream.write("\n")
    stream.write(f"Use 'kata tax show' to view available {node_type}s.\n")


def _print_target_exists(result: CloneResult, stream: TextIO) -> None:
    """Print message when target already exists."""
    stream.write("Error: Target already exists.\n")
    if result.error:
        stream.write(f"Details: {result.error}\n")
    stream.write("\n")
    stream.write("Choose a different name or remove the existing node first.\n")


def _print_ambiguous(result: CloneResult, stream: TextIO) -> None:
    """Print message when source is ambiguous."""
    stream.write("Error: Ambiguous source name.\n")
    stream.write("\n")
    if result.matches:
        stream.write("Multiple matches found:\n\n")
        for match in result.matches:
            stream.write(f"  - {match}\n")
        stream.write("\n")
    stream.write("Use --source-system, --source-subsystem, or --source-stack ")
    stream.write("to disambiguate.\n")


def _print_success(result: CloneResult, stream: TextIO) -> None:
    """Print success message."""
    stream.write("\n")
    stream.write("Clone Complete\n")
    stream.write("=" * 40 + "\n\n")

    if result.cloned:
        stream.write(f"Created {result.cloned.node_type}: {result.cloned.name}\n")
        stream.write(f"Location: {result.cloned.target_path}\n")

    if result.created_parents:
        stream.write("\nAlso created parent structures:\n")
        for parent in result.created_parents:
            stream.write(f"  - {parent}\n")

    stream.write("\n")
    stream.write("Run 'kata tax show' to view the updated taxonomy.\n")
    stream.write("\n")


def _print_failed(result: CloneResult, stream: TextIO) -> None:
    """Print failure message."""
    stream.write("Error: Clone failed.\n")
    if result.error:
        stream.write(f"Reason: {result.error}\n")


def _confirm_clone(
    node_type: str,
    source_name: str,
    target_name: str,
    scaffold: bool,
    stream: TextIO,
    in_stream: TextIO,
) -> bool:
    """Prompt user to confirm clone operation.

    Returns:
        True if user confirms, False otherwise.
    """
    stream.write("\nClone operation:\n\n")
    stream.write(f"  Type:   {node_type}\n")
    stream.write(f"  Source: {source_name}\n")
    stream.write(f"  Target: {target_name}\n")
    if scaffold:
        stream.write("  Mode:   Re-scaffold from layer type template\n")
    stream.write("\n")
    stream.write("Proceed? [Y/n] ")
    stream.flush()

    response = in_stream.readline().strip().lower()
    return response in ("", "y", "yes")


def run_clone(
    path: Path,
    *,
    node_type: str,
    source_name: str,
    target_name: str,
    # Source hierarchy hints for disambiguation
    source_system: str | None = None,
    source_subsystem: str | None = None,
    source_stack: str | None = None,
    # Target hierarchy (defaults to source if not specified)
    target_system: str | None = None,
    target_subsystem: str | None = None,
    target_stack: str | None = None,
    # Overrides
    description: str | None = None,
    owners: tuple[str, ...] | None = None,
    environments: tuple[str, ...] | None = None,
    layer_type: str | None = None,
    # Behavior flags
    scaffold: bool = False,
    yes: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
    in_stream: TextIO | None = None,
) -> int:
    """Run the clone command.

    Args:
        path: Path to the repository root.
        node_type: Type of node to clone (layer, stack, subsystem).
        source_name: Name of the source node.
        target_name: Name for the cloned node.
        source_system: Source system for disambiguation.
        source_subsystem: Source subsystem for disambiguation.
        source_stack: Source stack for disambiguation.
        target_system: Target system (defaults to source).
        target_subsystem: Target subsystem (defaults to source).
        target_stack: Target stack (defaults to source).
        description: Description override for cloned node.
        owners: Owner overrides for cloned node.
        environments: Environment overrides for cloned node.
        layer_type: Layer type override (for layers).
        scaffold: If True, re-scaffold from layer type template instead of copying.
        yes: If True, skip confirmation prompts.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).
        in_stream: Input stream for interactive prompts.

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr
    inp: TextIO = in_stream if in_stream is not None else sys.stdin

    # Check if initialized
    lock_path = path / ".global" / "taxonomy" / "taxonomy.lock"
    if not lock_path.exists():
        _print_not_initialized(err)
        return 1

    # Ask for confirmation if interactive
    if not yes and sys.stdin.isatty():
        if not _confirm_clone(node_type, source_name, target_name, scaffold, out, inp):
            out.write("\nClone cancelled.\n")
            return 0

    # Create adapters
    filesystem = RealCloneFilesystem()
    taxonomy_loader = SimpleTaxonomyLoader(path)

    # Create service
    service = CloneService(filesystem=filesystem, taxonomy_loader=taxonomy_loader)

    # Build config
    config = CloneConfig(
        target_path=path,
        node_type=node_type,
        source_name=source_name,
        target_name=target_name,
        source_system=source_system,
        source_subsystem=source_subsystem,
        source_stack=source_stack,
        target_system=target_system,
        target_subsystem=target_subsystem,
        target_stack=target_stack,
        description=description,
        owners=owners or (),
        environments=environments or (),
        layer_type=layer_type,
        scaffold=scaffold,
        interactive=not yes,
    )

    # Run clone
    result = service.clone(config)

    # Handle result
    if result.status == CloneStatus.SOURCE_NOT_FOUND:
        _print_source_not_found(result, node_type, err)
        return 1

    if result.status == CloneStatus.TARGET_EXISTS:
        _print_target_exists(result, err)
        return 1

    if result.status == CloneStatus.AMBIGUOUS:
        _print_ambiguous(result, err)
        return 1

    if result.status == CloneStatus.INVALID_HIERARCHY:
        err.write("Error: Invalid hierarchy specified.\n")
        if result.error:
            err.write(f"Details: {result.error}\n")
        return 1

    if result.status == CloneStatus.CANCELLED:
        out.write("Clone cancelled.\n")
        return 0

    if result.status == CloneStatus.SUCCESS:
        _print_success(result, out)
        return 0

    if result.status == CloneStatus.FAILED:
        _print_failed(result, err)
        return 1

    # Should not reach here
    err.write(f"Unexpected status: {result.status}\n")
    return 1
