"""init command - initialize a new taxonomy repository."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.adapters.init import (
    NonInteractivePrompt,
    SimpleInteractivePrompt,
)
from katalyst_taxonomy.ports.filesystem import RealFilesystem
from katalyst_taxonomy.services.init import (
    InitConfig,
    InitResult,
    InitService,
    InitStatus,
)
from katalyst_taxonomy.templates.sources import create_source


def _print_success(result: InitResult, stream: TextIO) -> None:
    """Print success message."""
    stream.write("\n")
    stream.write("Katalyst Taxonomy Initialized\n")
    stream.write("=" * 40 + "\n\n")

    if result.taxonomy_root:
        stream.write(f"Taxonomy root: {result.taxonomy_root}\n")
    if result.lock_file:
        stream.write(f"Lock file:     {result.lock_file}\n")
    stream.write("\n")

    if result.installed_plugins:
        stream.write("Installed plugins:\n")
        for plugin in result.installed_plugins:
            stream.write(f"  - {plugin}\n")
        stream.write("\n")

    if result.installed_layer_types:
        stream.write("Installed layer types:\n")
        for lt in result.installed_layer_types:
            stream.write(f"  - {lt}\n")
        stream.write("\n")

    stream.write("Run 'kata tax status' to see the full configuration.\n")
    stream.write("\n")


def _print_already_initialized(result: InitResult, stream: TextIO) -> None:
    """Print message when already initialized."""
    stream.write("Error: Taxonomy already initialized.\n")
    if result.lock_file:
        stream.write(f"Lock file exists at: {result.lock_file}\n")
    stream.write("\n")
    stream.write("Run 'kata tax status' to see the current configuration.\n")


def _print_cancelled(stream: TextIO) -> None:
    """Print message when cancelled."""
    stream.write("Initialization cancelled.\n")


def _print_failed(result: InitResult, stream: TextIO) -> None:
    """Print failure message."""
    stream.write("Error: Initialization failed.\n")
    if result.error:
        stream.write(f"Reason: {result.error}\n")


def run_init(
    path: Path,
    *,
    source: str = "bundled",
    plugins: tuple[str, ...] | None = None,
    layer_types: tuple[str, ...] | None = None,
    interactive: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Run the init command.

    Args:
        path: Path to the repository root.
        source: Template source URI (default: "bundled").
        plugins: Plugins to install.
        layer_types: Layer types to install.
        interactive: Whether to prompt for user input.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # Create adapters
    filesystem = RealFilesystem()

    # Choose prompt adapter based on interactive mode and TTY
    if interactive and sys.stdin.isatty():
        prompt = SimpleInteractivePrompt()
    else:
        prompt = NonInteractivePrompt(
            select_all_plugins=not plugins,  # Select all if none specified
            select_all_layer_types=not layer_types,  # Select all if none specified
        )

    # Create template source from URI
    try:
        template_source = create_source(source)
    except ValueError as e:
        err.write(f"Error: Invalid source URI: {e}\n")
        return 1
    except (ConnectionError, PermissionError) as e:
        err.write(f"Error: Failed to connect to source: {e}\n")
        return 1

    # Create service
    service = InitService(prompt=prompt, filesystem=filesystem, template_source=template_source)

    # Build config
    config = InitConfig(
        target_path=path,
        source=source,
        plugins=plugins or (),
        layer_types=layer_types or (),
        interactive=interactive,
    )

    # Run initialization
    result = service.initialize(config)

    # Handle result
    if result.status == InitStatus.SUCCESS:
        _print_success(result, out)
        return 0

    if result.status == InitStatus.ALREADY_INITIALIZED:
        _print_already_initialized(result, err)
        return 1

    if result.status == InitStatus.CANCELLED:
        _print_cancelled(out)
        return 0

    if result.status == InitStatus.FAILED:
        _print_failed(result, err)
        return 1

    # Should not reach here
    err.write(f"Unexpected status: {result.status}\n")
    return 1
