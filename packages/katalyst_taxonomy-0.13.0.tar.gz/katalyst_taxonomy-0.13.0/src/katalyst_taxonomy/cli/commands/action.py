"""action command - run, list, and show layer actions."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.cli.output import (
    HEADING_COLOR,
    SUCCESS_COLOR,
    colorize,
    write_error,
    write_warning,
)
from katalyst_taxonomy.plugins.layer_actions import LayerAction, load_layer_actions
from katalyst_taxonomy.taxonomy.documents import TaxonomyDocument
from katalyst_taxonomy.taxonomy.service import (
    TaxonomyResult,
    load_taxonomy,
    qualified_name_for,
)
from katalyst_taxonomy.taxonomy.utils import extract_layer_type


@dataclass(frozen=True)
class ActionRunResult:
    """Result of running a layer action."""

    success: bool
    stdout: str
    stderr: str
    exit_code: int


def _find_layer_by_fqtn(
    fqtn: str,
    taxonomy: TaxonomyResult,
) -> TaxonomyDocument | None:
    """Find a layer document by its fully qualified taxonomy name."""
    for doc in taxonomy.documents:
        if doc.taxonomy_node_type != "layer":
            continue
        doc_fqtn = qualified_name_for(doc, taxonomy.qualified_names)
        if doc_fqtn == fqtn:
            return doc
    return None


def _get_available_actions(
    layer: TaxonomyDocument,
    base_path: Path,
) -> tuple[LayerAction, ...]:
    """Get actions available for a layer based on its layer type."""
    layer_type = extract_layer_type(layer)
    if not layer_type:
        return ()

    actions_result = load_layer_actions(base_path)
    typed_actions = actions_result.actions_for_layer_type(layer_type)
    unscoped = actions_result.unscoped_actions()

    return typed_actions + unscoped


def _run_action(
    action: LayerAction,
    workdir: Path,
    environment: str | None,
    timeout: int | None = None,
) -> ActionRunResult:
    """Execute an action and return the result."""
    env = os.environ.copy()
    if environment:
        env["ENV"] = environment
    env["LAYER_DIR"] = str(workdir)
    env["STACK_DIR"] = str(workdir.parent)

    effective_timeout = timeout or action.timeout_seconds

    try:
        process = subprocess.run(
            action.run,
            cwd=workdir,
            shell=True,
            capture_output=True,
            text=False,
            env=env,
            timeout=effective_timeout,
        )
        return ActionRunResult(
            success=process.returncode == 0,
            stdout=process.stdout.decode("utf-8", errors="replace"),
            stderr=process.stderr.decode("utf-8", errors="replace"),
            exit_code=process.returncode,
        )
    except subprocess.TimeoutExpired as exc:
        return ActionRunResult(
            success=False,
            stdout=exc.stdout.decode("utf-8", errors="replace") if exc.stdout else "",
            stderr=exc.stderr.decode("utf-8", errors="replace")
            if exc.stderr
            else f"Timeout after {effective_timeout}s",
            exit_code=-1,
        )


def run_action_run(
    path: Path,
    *,
    action_name: str,
    layer_fqtn: str,
    environment: str | None = None,
    dry_run: bool = False,
    quiet: bool = False,
    timeout: int | None = None,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Run a layer action.

    Args:
        path: Path to the repository root.
        action_name: Name of the action to run.
        layer_fqtn: Fully qualified taxonomy name of the layer.
        environment: Environment value to inject as ENV variable.
        dry_run: If True, show command without executing.
        quiet: If True, only show command output.
        timeout: Optional timeout override in seconds.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code: 0 for success, 1 for action failure, 2 for not found/invalid.
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # Load taxonomy
    taxonomy = load_taxonomy(path)

    # Find the layer by FQTN
    layer = _find_layer_by_fqtn(layer_fqtn, taxonomy)
    if layer is None:
        write_error(f"Layer not found: {layer_fqtn}", err)
        err.write("\nUse 'kata tax show' to view available layers and their FQTNs.\n")
        return 2

    # Get layer type
    layer_type = extract_layer_type(layer)
    if not layer_type:
        write_error(f"Layer '{layer_fqtn}' has no layer type defined", err)
        err.write("\nLayer actions require a layer type to be set.\n")
        return 2

    # Get available actions
    available_actions = _get_available_actions(layer, path)
    if not available_actions:
        write_error(f"No actions available for layer type '{layer_type}'", err)
        return 2

    # Find the requested action
    action = next((a for a in available_actions if a.name == action_name), None)
    if action is None:
        write_error(f"Action '{action_name}' not found for layer type '{layer_type}'", err)
        err.write("\nAvailable actions:\n")
        for a in available_actions:
            err.write(f"  - {a.name}\n")
        return 2

    # Determine working directory
    if layer.source_path is None:
        write_error("Layer has no source path", err)
        return 2
    workdir = layer.source_path.parent

    # Check if environment is required but not provided
    layer_environments = layer.spec.environments
    if layer_environments and environment is None:
        write_error("This layer has environments defined but --env was not specified", err)
        err.write(f"\nAvailable environments: {', '.join(layer_environments)}\n")
        err.write("Use --env <environment> to specify which environment to use.\n")
        return 2

    # Dry run mode
    if dry_run:
        out.write(f"Would run action '{action_name}' on layer '{layer_fqtn}'\n")
        out.write(f"  Command: {action.run}\n")
        out.write(f"  Working directory: {workdir}\n")
        if environment:
            out.write(f"  Environment: {environment}\n")
        if action.timeout_seconds:
            out.write(f"  Timeout: {timeout or action.timeout_seconds}s\n")
        return 0

    # Print header (unless quiet)
    if not quiet:
        out.write(
            colorize(
                f"Running action '{action_name}' on layer '{layer_fqtn}'\n",
                HEADING_COLOR,
                out,
            ),
        )
        if environment:
            out.write(f"  Environment: {environment}\n")
        out.write(f"  Command: {action.run}\n")
        out.write(f"  Working directory: {workdir}\n")
        out.write("\n")

    # Run the action
    result = _run_action(action, workdir, environment, timeout)

    # Print output
    if quiet:
        if result.stdout:
            out.write(result.stdout)
        if result.stderr:
            err.write(result.stderr)
    else:
        if result.stdout:
            out.write("--- stdout ---\n")
            out.write(result.stdout)
            if not result.stdout.endswith("\n"):
                out.write("\n")
            out.write("\n")

        if result.stderr:
            out.write("--- stderr ---\n")
            out.write(result.stderr)
            if not result.stderr.endswith("\n"):
                out.write("\n")
            out.write("\n")

        if result.success:
            out.write(colorize(f"Exit code: {result.exit_code}\n", SUCCESS_COLOR, out))
        else:
            out.write(f"Exit code: {result.exit_code}\n")

    return 0 if result.success else 1


def run_action_list(
    path: Path,
    *,
    layer_type: str | None = None,
    layer_fqtn: str | None = None,
    output_format: str = "table",
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """List available layer actions.

    Args:
        path: Path to the repository root.
        layer_type: Filter actions by layer type.
        layer_fqtn: Show actions available for a specific layer.
        output_format: Output format (table or json).
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # If layer_fqtn is specified, determine its layer type
    effective_layer_type = layer_type
    if layer_fqtn:
        taxonomy = load_taxonomy(path)
        layer = _find_layer_by_fqtn(layer_fqtn, taxonomy)
        if layer is None:
            write_error(f"Layer not found: {layer_fqtn}", err)
            return 2
        effective_layer_type = extract_layer_type(layer)
        if not effective_layer_type:
            write_error(f"Layer '{layer_fqtn}' has no layer type defined", err)
            return 2

    # Load actions
    actions_result = load_layer_actions(path)

    if actions_result.errors:
        for error in actions_result.errors:
            write_warning(f"{error.path}:{error.document_index}: {error.message}", err)

    # Filter and organize actions
    if effective_layer_type:
        # Show only actions for this layer type (plus unscoped)
        typed_actions = actions_result.actions_for_layer_type(effective_layer_type)
        unscoped = actions_result.unscoped_actions()
        actions_by_type: dict[str, tuple[LayerAction, ...]] = {}
        if typed_actions:
            actions_by_type[effective_layer_type] = typed_actions
        if unscoped:
            actions_by_type["(unscoped)"] = unscoped
    else:
        # Show all actions grouped by layer type
        actions_by_type = {}
        for lt in actions_result.layer_types():
            if lt:  # Skip empty string (unscoped)
                actions_by_type[lt] = actions_result.actions_for_layer_type(lt)
        unscoped = actions_result.unscoped_actions()
        if unscoped:
            actions_by_type["(unscoped)"] = unscoped

    # Output
    if output_format == "json":
        data: dict[str, list[dict[str, object]]] = {}
        for lt, actions in actions_by_type.items():
            data[lt] = [
                {
                    "name": a.name,
                    "stage": a.when,
                    "command": a.run,
                    "description": a.description,
                    "timeout": a.timeout_seconds,
                    "tags": list(a.tags),
                    "environment": dict(a.environment),
                    "path": str(a.path),
                }
                for a in actions
            ]
        out.write(json.dumps(data, indent=2) + "\n")
    else:
        # Table format
        if not actions_by_type:
            out.write("No actions found.\n")
            return 0

        for lt, actions in sorted(actions_by_type.items()):
            out.write(colorize(f"Layer Type: {lt}\n", HEADING_COLOR, out))
            out.write(f"  {'ACTION':<20} {'STAGE':<10} {'COMMAND':<30} DESCRIPTION\n")
            for a in sorted(actions, key=lambda x: (x.when or "", x.name)):
                desc = (a.description or "")[:40]
                cmd = a.run[:28] + ".." if len(a.run) > 30 else a.run
                out.write(f"  {a.name:<20} {a.when:<10} {cmd:<30} {desc}\n")
            out.write("\n")

    return 0


def run_action_show(
    path: Path,
    *,
    action_name: str,
    output_format: str = "table",
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Show details of a specific action.

    Args:
        path: Path to the repository root.
        action_name: Name of the action to show.
        output_format: Output format (table or json).
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 2 for not found).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # Load actions
    actions_result = load_layer_actions(path)
    action = actions_result.action(action_name)

    if action is None:
        write_error(f"Action '{action_name}' not found", err)
        err.write("\nUse 'kata tax action list' to see available actions.\n")
        return 2

    if output_format == "json":
        data = {
            "name": action.name,
            "layerType": action.layer_type,
            "stage": action.when,
            "type": action.action_type,
            "command": action.run,
            "description": action.description,
            "timeout": action.timeout_seconds,
            "tags": list(action.tags),
            "environment": dict(action.environment),
            "path": str(action.path),
            "documentIndex": action.document_index,
        }
        out.write(json.dumps(data, indent=2) + "\n")
    else:
        out.write(colorize(f"Action: {action.name}\n\n", HEADING_COLOR, out))
        out.write(f"  Layer Type:  {action.layer_type or '(unscoped)'}\n")
        out.write(f"  Stage:       {action.when}\n")
        out.write(f"  Type:        {action.action_type}\n")
        out.write(f"  Command:     {action.run}\n")
        if action.timeout_seconds:
            out.write(f"  Timeout:     {action.timeout_seconds}s\n")
        if action.tags:
            out.write(f"  Tags:        {', '.join(action.tags)}\n")
        out.write(f"  Source:      {action.path}\n")

        if action.environment:
            out.write("\n  Environment Variables:\n")
            for key, value in action.environment:
                out.write(f"    {key}={value}\n")

        if action.description:
            out.write(f"\n  Description:\n    {action.description}\n")

    return 0
