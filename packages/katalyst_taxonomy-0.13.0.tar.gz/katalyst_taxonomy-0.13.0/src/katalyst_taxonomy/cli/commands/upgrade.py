"""upgrade command - upgrade taxonomy components."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.adapters.filesystem.lock import LockFileRepository
from katalyst_taxonomy.ports.filesystem import RealFilesystem
from katalyst_taxonomy.services.upgrade import (
    ComponentUpdate,
    UpgradeConfig,
    UpgradeResult,
    UpgradeService,
    UpgradeStatus,
)
from katalyst_taxonomy.templates.sources import create_source


def _print_not_initialized(stream: TextIO) -> None:
    """Print message when not initialized."""
    stream.write("Error: Repository not initialized.\n")
    stream.write("\n")
    stream.write("Run 'kata tax init' first to initialize a taxonomy repository.\n")


def _print_up_to_date(stream: TextIO) -> None:
    """Print message when up to date."""
    stream.write("\n")
    stream.write("Katalyst Upgrade Check\n")
    stream.write("=" * 40 + "\n\n")
    stream.write("All components are up to date.\n")
    stream.write("\n")


def _print_updates_available(
    result: UpgradeResult,
    dry_run: bool,
    show_diff: bool,
    stream: TextIO,
) -> None:
    """Print available updates."""
    stream.write("\n")
    stream.write("Katalyst Upgrade Check\n")
    stream.write("=" * 40 + "\n\n")

    if dry_run:
        stream.write("Available updates (dry run):\n\n")
    else:
        stream.write("Available updates:\n\n")

    for update in result.updates:
        stream.write(f"  {update.name}: {update.from_version} -> {update.to_version}\n")

    stream.write("\n")

    # Print diffs if available and requested
    if show_diff and result.has_diffs:
        stream.write("File changes:\n")
        stream.write("-" * 40 + "\n\n")
        for diff_summary in result.diffs:
            stream.write(diff_summary.format_full_diff())
            stream.write("\n")

    if dry_run:
        stream.write("Run 'kata tax upgrade' without --dry-run to apply updates.\n")
    stream.write("\n")


def _print_success(result: UpgradeResult, stream: TextIO) -> None:
    """Print success message."""
    stream.write("\n")
    stream.write("Katalyst Upgrade Complete\n")
    stream.write("=" * 40 + "\n\n")

    stream.write("Updated components:\n\n")
    for update in result.updates:
        stream.write(f"  {update.name}: {update.from_version} -> {update.to_version}\n")

    stream.write("\n")

    if result.backup_path:
        stream.write(f"Backup created: {result.backup_path}\n")
        stream.write("\n")

    stream.write("Run 'kata tax status' to see the current configuration.\n")
    stream.write("\n")


def _print_failed(result: UpgradeResult, stream: TextIO) -> None:
    """Print failure message."""
    stream.write("Error: Upgrade failed.\n")
    if result.error:
        stream.write(f"Reason: {result.error}\n")


def _confirm_upgrade(
    updates: tuple[ComponentUpdate, ...],
    stream: TextIO,
    in_stream: TextIO,
) -> bool:
    """Prompt user to confirm upgrade.

    Args:
        updates: Updates to be applied.
        stream: Output stream.
        in_stream: Input stream for reading confirmation.

    Returns:
        True if user confirms, False otherwise.
    """
    stream.write("\nThe following updates will be applied:\n\n")
    for update in updates:
        stream.write(f"  {update.name}: {update.from_version} -> {update.to_version}\n")
    stream.write("\n")
    stream.write("Proceed with upgrade? [y/N] ")
    stream.flush()

    response = in_stream.readline().strip().lower()
    return response in ("y", "yes")


def run_upgrade(
    path: Path,
    *,
    source: str = "bundled",
    components: tuple[str, ...] | None = None,
    dry_run: bool = False,
    check_only: bool = False,
    yes: bool = False,
    no_backup: bool = False,
    show_diff: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
    in_stream: TextIO | None = None,
) -> int:
    """Run the upgrade command.

    Args:
        path: Path to the repository root.
        source: Template source URI (default: "bundled").
        components: Specific components to upgrade.
        dry_run: If True, only show what would be upgraded.
        check_only: If True, only check for updates (alias for dry_run).
        yes: If True, skip confirmation prompts.
        no_backup: If True, skip creating backup.
        show_diff: If True, show file diffs for updates.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).
        in_stream: Input stream for interactive prompts.

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr
    inp: TextIO = in_stream if in_stream is not None else sys.stdin

    # Create adapters
    lock_repo = LockFileRepository(base_path=path)

    # Create template source from URI
    try:
        template_source = create_source(source)
    except ValueError as e:
        err.write(f"Error: Invalid source URI: {e}\n")
        return 1
    except (ConnectionError, PermissionError) as e:
        err.write(f"Error: Failed to connect to source: {e}\n")
        return 1

    # Create service
    service = UpgradeService(
        lock_repository=lock_repo,
        template_source=template_source,
        filesystem=RealFilesystem(),
    )

    # Build config
    config = UpgradeConfig(
        target_path=path,
        source=source,
        components=components or (),
        dry_run=dry_run or check_only,
        create_backup=not no_backup,
        interactive=not yes,
        show_diff=show_diff,
    )

    # Check for updates or upgrade
    if dry_run or check_only:
        result = service.check_updates(config)
    else:
        # First check what updates are available
        check_result = service.check_updates(config)

        # If updates available and not auto-confirmed, ask for confirmation
        if (
            check_result.status == UpgradeStatus.UPDATES_AVAILABLE
            and not yes
            and sys.stdin.isatty()
        ):
            if not _confirm_upgrade(check_result.updates, out, inp):
                out.write("\nUpgrade cancelled.\n")
                return 0

        result = service.upgrade(config)

    # Handle result
    if result.status == UpgradeStatus.NOT_INITIALIZED:
        _print_not_initialized(err)
        return 1

    if result.status == UpgradeStatus.UP_TO_DATE:
        _print_up_to_date(out)
        return 0

    if result.status == UpgradeStatus.UPDATES_AVAILABLE:
        _print_updates_available(result, dry_run or check_only, show_diff, out)
        return 0

    if result.status == UpgradeStatus.SUCCESS:
        _print_success(result, out)
        return 0

    if result.status == UpgradeStatus.FAILED:
        _print_failed(result, err)
        return 1

    # Should not reach here
    err.write(f"Unexpected status: {result.status}\n")
    return 1
