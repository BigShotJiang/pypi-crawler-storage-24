"""archetype command - list and inspect stack archetypes."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.cli.output import write_error
from katalyst_taxonomy.plugins.archetypes import ArchetypeChildNode


def run_archetype_list(
    path: Path,
    output: TextIO | None = None,
) -> int:
    """List all installed archetypes.

    Args:
        path: Repository root.
        output: Output stream (defaults to stdout).

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out = output if output is not None else sys.stdout

    from katalyst_taxonomy.plugins.archetypes import load_archetypes

    archetypes_path = path / ".global" / "taxonomy" / "archetypes"
    if not archetypes_path.exists():
        out.write("No archetypes installed.\n")
        out.write("  Install archetypes with: kata tax add --plugin archetypes\n")
        return 0

    result = load_archetypes(archetypes_path)

    if not result.definitions:
        out.write("No archetypes found.\n")
        return 0

    out.write("Installed archetypes:\n\n")
    for defn in result.definitions:
        scope_label = f"[{defn.scope}]" if defn.scope else ""
        children_count = _count_descendants(defn.children)
        out.write(f"  {defn.name} {scope_label}\n")
        out.write(f"    {defn.description}\n")
        out.write(f"    Children: {children_count} nodes")
        if defn.requirements:
            req_names = [r.name for r in defn.requirements]
            out.write(f"  |  Requires: {', '.join(req_names)}")
        out.write("\n\n")

    return 0


def run_archetype_show(
    path: Path,
    name: str,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Show details of a specific archetype with a tree preview.

    Args:
        path: Repository root.
        name: Archetype name to show.
        output: Output stream (defaults to stdout).
        err_output: Error stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out = output if output is not None else sys.stdout
    err = err_output if err_output is not None else sys.stderr

    from katalyst_taxonomy.services.archetype import resolve_archetype

    archetype = resolve_archetype(path, name)
    if archetype is None:
        write_error(
            f"Archetype '{name}' not found. Run 'kata tax archetype list' to see available archetypes.",
            err,
        )
        return 1

    # Header
    out.write(f"{archetype.name} ({archetype.scope})\n")
    out.write(f"  {archetype.description}\n\n")

    if archetype.requirements:
        req_names = [r.name for r in archetype.requirements]
        out.write(f"  Requires: {', '.join(req_names)}\n\n")

    # Tree structure
    out.write("  Structure:\n")
    _print_tree(out, archetype.children, prefix="  ", is_root=True, root_name="{name}")

    return 0


def _print_tree(
    out: TextIO,
    children: tuple[ArchetypeChildNode, ...],
    prefix: str = "",
    is_root: bool = False,
    root_name: str = "",
) -> None:
    """Print a tree representation of archetype children."""
    for i, child in enumerate(children):
        is_last = i == len(children) - 1
        connector = "└── " if is_last else "├── "
        child_prefix = "    " if is_last else "│   "

        label = f"[{child.node_type}] {child.name}"
        if child.layer_type:
            label += f"  ({child.layer_type})"
        if child.template_path:
            label += "  + template files"

        out.write(f"{prefix}{connector}{label}\n")

        if child.children:
            _print_tree(
                out,
                child.children,
                prefix=prefix + child_prefix,
            )


def _count_descendants(children: tuple[ArchetypeChildNode, ...]) -> int:
    """Count total descendant nodes recursively."""
    count = len(children)
    for child in children:
        if child.children:
            count += _count_descendants(child.children)
    return count
