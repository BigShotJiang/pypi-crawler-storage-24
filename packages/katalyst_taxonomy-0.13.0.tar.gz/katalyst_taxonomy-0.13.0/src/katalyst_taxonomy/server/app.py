"""FastAPI application factory."""

from __future__ import annotations

import asyncio
import os
import signal
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncGenerator, Callable

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger

from katalyst_taxonomy.adapters.filesystem import FilesystemTaxonomyRepository
from katalyst_taxonomy.domain.events import EventBus
from katalyst_taxonomy.server.routes import events, taxonomy
from katalyst_taxonomy.server.state import clear_server_state

__version__ = "0.1.0"

# Global state for activity tracking
_last_activity_time: float = 0.0
_idle_timeout: int = 300  # Default 5 minutes
_idle_check_task: asyncio.Task[None] | None = None


def update_activity() -> None:
    """Update the last activity timestamp."""
    global _last_activity_time
    _last_activity_time = time.time()


def set_idle_timeout(timeout: int) -> None:
    """Set the idle timeout in seconds."""
    global _idle_timeout
    _idle_timeout = timeout


def get_idle_timeout() -> int:
    """Get the current idle timeout in seconds."""
    return _idle_timeout


async def _idle_shutdown_checker() -> None:
    """Background task to check for idle timeout and shutdown if exceeded."""
    check_interval = 30  # Check every 30 seconds

    while True:
        await asyncio.sleep(check_interval)

        if _last_activity_time == 0:
            # No activity yet, skip
            continue

        idle_duration = time.time() - _last_activity_time
        if idle_duration >= _idle_timeout:
            logger.info(
                f"Server idle for {idle_duration:.0f}s (timeout: {_idle_timeout}s), shutting down",
            )
            # Clear state file before exiting
            clear_server_state()
            # Send SIGTERM to self for graceful shutdown
            os.kill(os.getpid(), signal.SIGTERM)
            break


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan handler."""
    global _idle_check_task

    # Startup
    update_activity()  # Initialize activity time

    # Start idle shutdown checker if timeout is set
    if _idle_timeout > 0:
        _idle_check_task = asyncio.create_task(_idle_shutdown_checker())
        logger.debug(f"Idle shutdown checker started (timeout: {_idle_timeout}s)")

    yield

    # Shutdown
    if _idle_check_task is not None:
        _idle_check_task.cancel()
        try:
            await _idle_check_task
        except asyncio.CancelledError:
            pass

    # Clear state file on shutdown
    clear_server_state()
    logger.info("Server shutdown complete")


def create_app(base_path: Path, idle_timeout: int = 300) -> FastAPI:
    """Create and configure the FastAPI application.

    Args:
        base_path: Path to the taxonomy directory.
        idle_timeout: Idle timeout in seconds. Set to 0 to disable auto-shutdown.
    """
    # Set the idle timeout
    set_idle_timeout(idle_timeout)

    app = FastAPI(
        title="Katalyst Taxonomy API",
        description="HTTP API for managing Katalyst taxonomy",
        version=__version__,
        lifespan=lifespan,
    )

    # Store configuration in app state
    app.state.base_path = base_path
    app.state.event_bus = EventBus()
    app.state.repository = FilesystemTaxonomyRepository(base_path=base_path)
    app.state.idle_timeout = idle_timeout

    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Activity tracking middleware
    @app.middleware("http")
    async def activity_middleware(
        request: Request,
        call_next: Callable[[Request], Any],
    ) -> Response:
        """Track activity on each request."""
        update_activity()
        response: Response = await call_next(request)
        return response

    # Include routers
    app.include_router(taxonomy.router, prefix="/taxonomy", tags=["taxonomy"])
    app.include_router(events.router, tags=["events"])

    @app.get("/health")
    async def health() -> dict[str, Any]:
        """Health check endpoint."""
        return {"healthy": True, "version": __version__}

    @app.get("/status")
    async def status() -> dict[str, Any]:
        """Server status endpoint with detailed information."""
        idle_duration = time.time() - _last_activity_time if _last_activity_time > 0 else 0
        return {
            "healthy": True,
            "version": __version__,
            "base_path": str(base_path),
            "idle_timeout": _idle_timeout,
            "idle_duration": round(idle_duration, 1),
            "pid": os.getpid(),
        }

    @app.post("/shutdown")
    async def shutdown() -> dict[str, str]:
        """Trigger server shutdown."""
        logger.info("Shutdown requested via API")
        # Clear state file
        clear_server_state()
        # Schedule shutdown after response is sent
        asyncio.get_event_loop().call_later(0.5, lambda: os.kill(os.getpid(), signal.SIGTERM))
        return {"status": "shutting_down"}

    _ = health  # Silence pyright unused function warning
    _ = status
    _ = shutdown
    _ = activity_middleware

    return app
