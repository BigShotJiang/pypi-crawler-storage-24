"""Server lifecycle manager for auto-start/stop functionality."""

from __future__ import annotations

import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx
from loguru import logger

from katalyst_taxonomy.server.state import (
    ServerState,
    clear_server_state,
    is_process_running,
    load_server_state,
    save_server_state,
)

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8000
DEFAULT_IDLE_TIMEOUT = 300  # 5 minutes
HEALTH_CHECK_TIMEOUT = 2.0  # seconds
STARTUP_TIMEOUT = 10.0  # seconds
STARTUP_POLL_INTERVAL = 0.2  # seconds


class ServerError(Exception):
    """Error related to server management."""


def find_available_port(start_port: int = DEFAULT_PORT, max_attempts: int = 100) -> int:
    """Find an available port starting from start_port."""
    for port in range(start_port, start_port + max_attempts):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind((DEFAULT_HOST, port))
                return port
        except OSError:
            continue
    raise ServerError(
        f"Could not find available port in range {start_port}-{start_port + max_attempts}",
    )


def check_server_health(host: str, port: int) -> bool:
    """Check if the server is responding to health checks."""
    try:
        response = httpx.get(
            f"http://{host}:{port}/health",
            timeout=HEALTH_CHECK_TIMEOUT,
        )
        return response.status_code == 200
    except (httpx.RequestError, httpx.TimeoutException):
        return False


def get_running_server() -> ServerState | None:
    """Get the currently running server state, or None if not running."""
    state = load_server_state()
    if state is None:
        return None

    # Check if process is still running
    if not is_process_running(state.pid):
        clear_server_state()
        return None

    # Verify server is actually responding
    if not check_server_health(state.host, state.port):
        # Process exists but not responding - might be starting or hung
        # Give it the benefit of the doubt for now
        return state

    return state


def stop_server(force: bool = True) -> bool:
    """Stop the running server.

    Args:
        force: If True, send SIGKILL. If False, send SIGTERM for graceful shutdown.

    Returns:
        True if server was stopped, False if no server was running.
    """
    state = load_server_state()
    if state is None:
        return False

    if not is_process_running(state.pid):
        clear_server_state()
        return False

    try:
        sig = signal.SIGKILL if force else signal.SIGTERM
        os.kill(state.pid, sig)
        logger.info(f"Stopped server (PID {state.pid})")
    except (OSError, ProcessLookupError):
        pass

    clear_server_state()
    return True


def start_server(
    path: Path,
    host: str = DEFAULT_HOST,
    port: int | None = None,
    idle_timeout: int = DEFAULT_IDLE_TIMEOUT,
) -> ServerState:
    """Start the server as a background process.

    Args:
        path: Path to the taxonomy directory.
        host: Host to bind to.
        port: Port to bind to. If None, finds an available port.
        idle_timeout: Idle timeout in seconds before auto-shutdown.

    Returns:
        ServerState with the running server information.

    Raises:
        ServerError: If the server fails to start.
    """
    if port is None:
        port = find_available_port()

    # Build the command to run the server
    cmd = [
        sys.executable,
        "-m",
        "katalyst_taxonomy.server",
        "--path",
        str(path.resolve()),
        "--host",
        host,
        "--port",
        str(port),
        "--idle-timeout",
        str(idle_timeout),
        "--background",
    ]

    logger.debug(f"Starting server: {' '.join(cmd)}")

    # Start the server as a detached process
    # Use subprocess.Popen with appropriate flags for backgrounding
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        start_new_session=True,  # Detach from parent process group
    )

    state = ServerState.create(
        pid=process.pid,
        port=port,
        host=host,
        path=path,
    )

    # Wait for server to become healthy
    start_time = time.time()
    while time.time() - start_time < STARTUP_TIMEOUT:
        if check_server_health(host, port):
            save_server_state(state)
            logger.info(f"Server started on {state.url} (PID {state.pid})")
            return state
        time.sleep(STARTUP_POLL_INTERVAL)

    # Server didn't start in time - kill it
    try:
        os.kill(process.pid, signal.SIGKILL)
    except (OSError, ProcessLookupError):
        pass

    raise ServerError(f"Server failed to start within {STARTUP_TIMEOUT} seconds")


def ensure_server(
    path: Path,
    host: str = DEFAULT_HOST,
    port: int | None = None,
    idle_timeout: int = DEFAULT_IDLE_TIMEOUT,
) -> ServerState:
    """Ensure a server is running for the given path.

    If a server is already running:
    - If it's for the same path, return its state.
    - If it's for a different path, restart it with the new path.

    If no server is running, start one.

    Args:
        path: Path to the taxonomy directory.
        host: Host to bind to.
        port: Port to bind to. If None, uses existing port or finds available.
        idle_timeout: Idle timeout in seconds before auto-shutdown.

    Returns:
        ServerState with the running server information.
    """
    resolved_path = str(path.resolve())
    state = get_running_server()

    if state is not None:
        # Server is running - check if it's for the same path
        if state.path == resolved_path:
            logger.debug(f"Server already running for {resolved_path}")
            return state
        # Different path - restart server
        logger.info(f"Restarting server for new path: {resolved_path}")
        stop_server(force=True)
        # Use the same port if not specified
        if port is None:
            port = state.port

    return start_server(path, host, port, idle_timeout)


def get_server_url(path: Path | None = None) -> str | None:
    """Get the URL of the running server.

    Args:
        path: If provided, only return URL if server is running for this path.

    Returns:
        Server URL or None if not running.
    """
    state = get_running_server()
    if state is None:
        return None

    if path is not None:
        resolved_path = str(path.resolve())
        if state.path != resolved_path:
            return None

    return state.url
