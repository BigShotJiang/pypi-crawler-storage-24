"""Katalyst Server - FastAPI HTTP server for taxonomy operations."""

from katalyst_taxonomy.server.app import create_app

__all__ = ["create_app"]
