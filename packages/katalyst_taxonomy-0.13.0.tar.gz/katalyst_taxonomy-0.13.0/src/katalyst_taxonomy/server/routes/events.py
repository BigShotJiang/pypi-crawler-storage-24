"""Server-Sent Events (SSE) route handlers."""

from __future__ import annotations

import asyncio
import json
from typing import AsyncGenerator

from fastapi import APIRouter, Request
from sse_starlette.sse import EventSourceResponse

from katalyst_taxonomy.domain.events import Event, EventBus, EventType

router = APIRouter()


@router.get("/events")
async def event_stream(request: Request) -> EventSourceResponse:
    """Server-Sent Events endpoint for real-time updates."""

    async def generate() -> AsyncGenerator[dict[str, str], None]:
        bus: EventBus = request.app.state.event_bus
        queue: asyncio.Queue[Event] = asyncio.Queue()

        def handler(event: Event) -> None:
            # Use call_soon_threadsafe in case events come from another thread
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                pass  # Drop events if queue is full

        unsubscribe = bus.subscribe(handler)

        # Send connected event
        yield {
            "event": EventType.SERVER_CONNECTED.value,
            "data": json.dumps({"status": "connected"}),
        }

        try:
            while True:
                # Check if client disconnected
                if await request.is_disconnected():
                    break

                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30.0)
                    yield {
                        "event": event.type.value,
                        "data": json.dumps(event.properties),
                    }
                except TimeoutError:
                    # Send heartbeat
                    yield {
                        "event": EventType.SERVER_HEARTBEAT.value,
                        "data": json.dumps({"status": "alive"}),
                    }
        finally:
            unsubscribe()

    return EventSourceResponse(generate())
