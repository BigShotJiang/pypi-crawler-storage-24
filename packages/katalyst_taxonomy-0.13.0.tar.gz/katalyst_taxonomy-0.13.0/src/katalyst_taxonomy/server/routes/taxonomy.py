"""Taxonomy route handlers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from katalyst_taxonomy.adapters.filesystem import FilesystemTaxonomyRepository
from katalyst_taxonomy.taxonomy.documents import TaxonomyDocument
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

router = APIRouter()


class CreateNodeRequest(BaseModel):
    """Request body for creating a new taxonomy node."""

    node_type: str
    name: str
    description: str = ""
    owners: list[str] = ["team@example.com"]
    environments: list[str] = ["dev"]
    parent: str | None = None
    parent_subsystem: str | None = None
    parent_system: str | None = None
    layer_type: str | None = None


class CreateNodeResponse(BaseModel):
    """Response for node creation."""

    success: bool
    path: str | None = None
    error: str | None = None


def _serialize_document(doc: TaxonomyDocument) -> dict[str, Any]:
    """Serialize a TaxonomyDocument to a dict."""
    result: dict[str, Any] = {
        "apiVersion": doc.api_version,
        "kind": doc.kind,
        "taxonomyNodeType": doc.taxonomy_node_type,
        "metadata": {
            "name": doc.metadata.name,
            "labels": dict(doc.metadata.labels) if doc.metadata.labels else {},
        },
        "spec": {
            "description": doc.spec.description,
            "owners": list(doc.spec.owners),
            "annotations": dict(doc.spec.annotations) if doc.spec.annotations else {},
            "environments": list(doc.spec.environments),
        },
    }
    if doc.spec.parents:
        result["spec"]["parents"] = {"node": doc.spec.parents.node}
    if doc.spec.depends_on:
        result["spec"]["dependsOn"] = {"nodes": list(doc.spec.depends_on.nodes)}
    if doc.spec.extensions:
        result["spec"]["extensions"] = dict(doc.spec.extensions)
    if doc.source_path:
        result["sourcePath"] = str(doc.source_path)
    return result


def _serialize_environment(env: EnvironmentDocument) -> dict[str, Any]:
    """Serialize an EnvironmentDocument to a dict."""
    result: dict[str, Any] = {
        "name": env.name,
        "description": env.description,
        "templateReplacements": dict(env.template_replacements),
        "layerTemplates": {k: dict(v) for k, v in env.layer_templates.items()},
    }
    if env.source_path:
        result["sourcePath"] = str(env.source_path)
    return result


def _serialize_error(error: Any) -> dict[str, Any]:
    """Serialize a DocumentError to a dict."""
    result: dict[str, Any] = {
        "message": error.message,
    }
    if error.path:
        result["path"] = str(error.path)
    if error.document_index:
        result["documentIndex"] = error.document_index
    return result


@router.get("")
async def get_taxonomy(request: Request) -> dict[str, Any]:
    """Load and return the full taxonomy."""
    repo: FilesystemTaxonomyRepository = request.app.state.repository
    base_path: Path = request.app.state.base_path

    documents = repo.load_documents(base_path)
    environments = repo.load_environments(base_path)
    errors = repo.errors()

    # Build qualified names (simple version - just use node names)
    qualified_names: dict[str, str] = {}
    for doc in documents:
        qualified_names[doc.metadata.name] = doc.metadata.name

    return {
        "documents": [_serialize_document(d) for d in documents],
        "environments": [_serialize_environment(e) for e in environments],
        "qualified_names": qualified_names,
        "errors": [_serialize_error(e) for e in errors],
        "error_count": len(errors),
    }


@router.get("/nodes/{name}")
async def get_node(name: str, request: Request) -> dict[str, Any]:
    """Get a single taxonomy node by name."""
    repo: FilesystemTaxonomyRepository = request.app.state.repository
    base_path: Path = request.app.state.base_path

    doc = repo.get_document(base_path, name)
    if doc is None:
        raise HTTPException(status_code=404, detail=f"Node '{name}' not found")

    return _serialize_document(doc)


@router.post("/nodes", response_model=CreateNodeResponse)
async def create_node(
    request_body: CreateNodeRequest,
    request: Request,
) -> CreateNodeResponse:
    """Create a new taxonomy node."""
    from katalyst_taxonomy.adapters.filesystem import FilesystemWriter
    from katalyst_taxonomy.ports.taxonomy import CreationRequest
    from katalyst_taxonomy.services.creation import CreationService

    base_path: Path = request.app.state.base_path

    # Build the creation request
    creation_request = CreationRequest(
        node_type=request_body.node_type,
        name=request_body.name,
        description=request_body.description or None,
        owners=tuple(request_body.owners) if request_body.owners else (),
        environments=tuple(request_body.environments) if request_body.environments else (),
        parent=request_body.parent,
        parent_subsystem=request_body.parent_subsystem,
        parent_system=request_body.parent_system,
        layer_type=request_body.layer_type,
    )

    # Create the service with filesystem writer
    writer = FilesystemWriter()
    service = CreationService(writer=writer)

    # Execute creation
    result = service.create(base_path, creation_request)

    if result.success:
        rel_path = str(result.path)
        if result.path:
            try:
                rel_path = str(result.path.relative_to(base_path))
            except ValueError:
                pass
        return CreateNodeResponse(success=True, path=rel_path)
    return CreateNodeResponse(success=False, error=result.error)
