"""Filesystem-backed loader for the capabilities plugin."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, cast

import yaml
from loguru import logger

from ..taxonomy.discovery.filesystem import (
    ByKindStrategy,
    CompositeDiscoveryStrategy,
    DiscoveryStrategy,
    RecursiveStrategy,
    SingleFileStrategy,
)
from ..taxonomy.ignore import IGNOREFILE_NAME, load_ignore
from ._helpers import collect_strings, ensure_mapping, require_string
from .models import PluginDocumentError

CAPABILITIES_API_VERSION = "katalyst.taxonomy.plugins.capabilities/v1alpha"
CAPABILITY_KIND = "Capability"
RELATIONSHIP_KIND = "CapabilityRelationship"


@dataclass(frozen=True, slots=True)
class Capability:
    """Parsed capability document."""

    name: str
    description: str
    categories: tuple[str, ...]
    depends_on_capabilities: tuple[str, ...]
    path: Path
    document_index: int


@dataclass(frozen=True, slots=True)
class CapabilityRelationship:
    """Associates capabilities with a taxonomy node."""

    name: str
    node: str
    relationship_type: str
    capabilities: tuple[str, ...]
    path: Path
    document_index: int


@dataclass(frozen=True, slots=True)
class CapabilityPluginResult:
    """Aggregated view of capabilities and relationships."""

    capabilities: tuple[Capability, ...]
    relationships: tuple[CapabilityRelationship, ...]
    errors: tuple[PluginDocumentError, ...]
    _relationships_by_node: dict[str, tuple[CapabilityRelationship, ...]]

    def relationships_for_node(self, node: str) -> tuple[CapabilityRelationship, ...]:
        return self._relationships_by_node.get(node, tuple())


def load_capabilities(
    base_path: Path,
    *,
    strategy: DiscoveryStrategy | None = None,
) -> CapabilityPluginResult:
    """Load capabilities plugin documents from ``base_path``."""

    discovery = strategy or CompositeDiscoveryStrategy(
        strategies=(SingleFileStrategy(), ByKindStrategy(), RecursiveStrategy()),
    )
    candidates = _discover_candidate_files(base_path, discovery)
    ignore = load_ignore(base_path)

    capabilities: list[Capability] = []
    relationships: list[CapabilityRelationship] = []
    errors: list[PluginDocumentError] = []

    for path in candidates:
        if ignore and ignore.should_ignore(path, is_dir=path.is_dir()):
            logger.debug("Skipping ignored plugin path {}", path)
            continue

        if not path.is_file():
            continue

        errors.extend(_parse_capability_documents(path, capabilities, relationships))

    relationship_index: dict[str, tuple[CapabilityRelationship, ...]] = {}
    for relationship in relationships:
        existing = relationship_index.setdefault(relationship.node, tuple())
        relationship_index[relationship.node] = existing + (relationship,)

    logger.info(
        "Loaded capabilities plugin data: {} capabilities, {} relationships",
        len(capabilities),
        len(relationships),
    )

    return CapabilityPluginResult(
        capabilities=tuple(capabilities),
        relationships=tuple(relationships),
        errors=tuple(errors),
        _relationships_by_node=relationship_index,
    )


def _discover_candidate_files(base_path: Path, strategy: DiscoveryStrategy) -> tuple[Path, ...]:
    if not base_path.exists():
        return tuple()

    seen: set[Path] = set()
    discovered: list[Path] = []
    for path in strategy.discover(base_path):
        if path.name == IGNOREFILE_NAME:
            continue
        absolute = path.resolve()
        if absolute in seen:
            continue
        seen.add(absolute)
        discovered.append(path)

    discovered.sort(key=lambda item: (len(item.parts), str(item)))
    return tuple(discovered)


def _parse_capability_documents(
    path: Path,
    capabilities: list[Capability],
    relationships: list[CapabilityRelationship],
) -> tuple[PluginDocumentError, ...]:
    errors: list[PluginDocumentError] = []
    try:
        with path.open("r", encoding="utf-8") as stream:
            for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                if not document:
                    continue
                if not isinstance(document, Mapping):
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message="Plugin document must be a mapping",
                        ),
                    )
                    continue
                document_mapping = cast(Mapping[str, object], document)
                api_version = document_mapping.get("apiVersion")
                if not isinstance(api_version, str) or api_version != CAPABILITIES_API_VERSION:
                    continue
                kind = document_mapping.get("kind")
                if not isinstance(kind, str):
                    continue
                try:
                    if kind == CAPABILITY_KIND:
                        capabilities.append(_build_capability(document_mapping, path, index))
                    elif kind == RELATIONSHIP_KIND:
                        relationships.append(_build_relationship(document_mapping, path, index))
                    else:
                        errors.append(
                            PluginDocumentError(
                                path=path,
                                document_index=index,
                                message=f"Unsupported capability plugin kind: {kind}",
                            ),
                        )
                except ValueError as exc:
                    logger.warning("Capability plugin parse error in {}: {}", path, exc)
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message=str(exc),
                        ),
                    )
    except yaml.YAMLError as exc:
        logger.warning("Capability plugin YAML error in {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))
    except OSError as exc:
        logger.warning("Failed to open capability plugin file {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))

    return tuple(errors)


def _build_capability(document: Mapping[str, object], path: Path, index: int) -> Capability:
    metadata = ensure_mapping(document.get("metadata"), "metadata", path, index)
    spec = ensure_mapping(document.get("spec"), "spec", path, index)

    name = require_string(metadata.get("name"), "metadata.name", path, index)
    description = require_string(spec.get("description"), "spec.description", path, index)

    categories_value = spec.get("categories")
    categories = collect_strings(categories_value, "spec.categories", path, index)

    depends_on: tuple[str, ...] = tuple()
    depends_section = spec.get("dependsOn")
    if isinstance(depends_section, Mapping):
        depends_mapping = cast(Mapping[str, object], depends_section)
        capabilities_value = depends_mapping.get("capabilities")
        depends_on = collect_strings(
            capabilities_value,
            "spec.dependsOn.capabilities",
            path,
            index,
        )

    return Capability(
        name=name,
        description=description,
        categories=categories,
        depends_on_capabilities=depends_on,
        path=path,
        document_index=index,
    )


def _build_relationship(
    document: Mapping[str, object],
    path: Path,
    index: int,
) -> CapabilityRelationship:
    metadata = ensure_mapping(document.get("metadata"), "metadata", path, index)
    spec = ensure_mapping(document.get("spec"), "spec", path, index)

    name = require_string(metadata.get("name"), "metadata.name", path, index)
    node = require_string(spec.get("node"), "spec.node", path, index)
    relationship_type = require_string(
        spec.get("relationshipType"),
        "spec.relationshipType",
        path,
        index,
    )

    capabilities_value = spec.get("capabilities")
    capability_names = collect_strings(
        capabilities_value,
        "spec.capabilities",
        path,
        index,
        minimum_items=1,
    )

    return CapabilityRelationship(
        name=name,
        node=node,
        relationship_type=relationship_type,
        capabilities=capability_names,
        path=path,
        document_index=index,
    )
