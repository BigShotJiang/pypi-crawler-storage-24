"""Plugin index for fast lookups and dependency resolution.

This module provides a two-phase loading approach:
1. Index phase: Scan all plugin files and extract apiVersion/kind/name headers
2. Resolution phase: Use the index to resolve dependencies efficiently

The index enables O(1) lookups for plugin dependencies and supports
early detection of duplicate plugin definitions.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence, cast

import yaml
from loguru import logger

from .models import PluginDocumentError

__all__ = [
    "DuplicatePluginError",
    "PluginIndex",
    "PluginIndexEntry",
    "build_plugin_index",
]

# Known plugin apiVersion prefixes
PLUGIN_API_PREFIX = "katalyst.taxonomy.plugins."


@dataclass(frozen=True, slots=True)
class PluginIndexEntry:
    """An entry in the plugin index representing a single plugin document.

    Attributes:
        api_version: The apiVersion of the plugin
        kind: The kind of the plugin
        name: The name from metadata.name
        path: The file path containing this plugin
        document_index: The 1-based document index within the file
    """

    api_version: str
    kind: str
    name: str
    path: Path
    document_index: int

    @property
    def key(self) -> tuple[str, str, str]:
        """Return the unique key tuple (apiVersion, kind, name) for index lookups."""
        return (self.api_version, self.kind, self.name)


@dataclass(frozen=True, slots=True)
class DuplicatePluginError:
    """Error indicating a plugin with the same key was found in multiple locations.

    Attributes:
        api_version: The apiVersion of the duplicate plugin
        kind: The kind of the duplicate plugin
        name: The name of the duplicate plugin
        first_path: Path to the first occurrence
        duplicate_path: Path to the duplicate occurrence
        message: Human-readable error message
    """

    api_version: str
    kind: str
    name: str
    first_path: Path
    duplicate_path: Path
    message: str


@dataclass(frozen=True, slots=True)
class PluginIndex:
    """An index of all discovered plugins for fast lookups.

    The index is immutable and provides O(1) lookups by (apiVersion, kind, name) key.

    Attributes:
        entries: All indexed plugin entries
        _by_key: Internal lookup dictionary (apiVersion, kind, name) -> entry
    """

    entries: tuple[PluginIndexEntry, ...]
    _by_key: dict[tuple[str, str, str], PluginIndexEntry]

    def lookup(
        self,
        api_version: str,
        kind: str,
        name: str,
    ) -> PluginIndexEntry | None:
        """Look up a plugin by its key.

        Args:
            api_version: The apiVersion to look up
            kind: The kind to look up
            name: The name to look up

        Returns:
            The PluginIndexEntry if found, None otherwise
        """
        return self._by_key.get((api_version, kind, name))

    def has(self, api_version: str, kind: str, name: str) -> bool:
        """Check if a plugin exists in the index.

        Args:
            api_version: The apiVersion to check
            kind: The kind to check
            name: The name to check

        Returns:
            True if the plugin exists, False otherwise
        """
        return (api_version, kind, name) in self._by_key


def build_plugin_index(
    paths: Sequence[Path],
) -> tuple[PluginIndex, tuple[PluginDocumentError | DuplicatePluginError, ...]]:
    """Build a plugin index from a list of file paths.

    This function performs a lightweight scan of all provided paths,
    extracting only the apiVersion, kind, and metadata.name fields.
    Documents that are not plugins (don't have a katalyst.taxonomy.plugins.* apiVersion)
    are skipped.

    Args:
        paths: Sequence of file paths to scan

    Returns:
        A tuple of (PluginIndex, errors) where errors includes both
        parsing errors and duplicate plugin errors
    """
    entries: list[PluginIndexEntry] = []
    errors: list[PluginDocumentError | DuplicatePluginError] = []
    seen: dict[tuple[str, str, str], PluginIndexEntry] = {}

    for path in paths:
        file_entries, file_errors = _scan_file(path)
        errors.extend(file_errors)

        for entry in file_entries:
            if entry.key in seen:
                first = seen[entry.key]
                errors.append(
                    DuplicatePluginError(
                        api_version=entry.api_version,
                        kind=entry.kind,
                        name=entry.name,
                        first_path=first.path,
                        duplicate_path=entry.path,
                        message=(
                            f"Duplicate plugin {entry.kind} '{entry.name}' found: "
                            f"first in {first.path}, duplicate in {entry.path}"
                        ),
                    )
                )
            else:
                seen[entry.key] = entry
                entries.append(entry)

    logger.info("Built plugin index with {} entries from {} files", len(entries), len(paths))

    return PluginIndex(entries=tuple(entries), _by_key=seen), tuple(errors)


def _scan_file(
    path: Path,
) -> tuple[list[PluginIndexEntry], list[PluginDocumentError]]:
    """Scan a single file for plugin documents.

    This performs a lightweight parse, only extracting header fields.

    Args:
        path: The file path to scan

    Returns:
        A tuple of (entries, errors) for this file
    """
    entries: list[PluginIndexEntry] = []
    errors: list[PluginDocumentError] = []

    try:
        with path.open("r", encoding="utf-8") as stream:
            for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                if not document:
                    continue

                if not isinstance(document, Mapping):
                    # Skip non-mapping documents silently (could be taxonomy docs)
                    continue

                document_mapping = cast(Mapping[str, object], document)
                api_version = document_mapping.get("apiVersion")

                # Skip if not a plugin document
                if not isinstance(api_version, str) or not api_version.startswith(
                    PLUGIN_API_PREFIX
                ):
                    continue

                kind = document_mapping.get("kind")
                if not isinstance(kind, str) or not kind:
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message="Plugin document missing 'kind' field",
                        )
                    )
                    continue

                metadata = document_mapping.get("metadata")
                if not isinstance(metadata, Mapping):
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message="Plugin document missing 'metadata' mapping",
                        )
                    )
                    continue

                metadata_mapping = cast(Mapping[str, object], metadata)
                name = metadata_mapping.get("name")
                if not isinstance(name, str) or not name:
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message="Plugin document missing 'metadata.name' field",
                        )
                    )
                    continue

                entries.append(
                    PluginIndexEntry(
                        api_version=api_version,
                        kind=kind,
                        name=name,
                        path=path,
                        document_index=index,
                    )
                )

    except yaml.YAMLError as exc:
        logger.warning("YAML error scanning {}: {}", path, exc)
        errors.append(
            PluginDocumentError(
                path=path,
                document_index=0,
                message=f"YAML parse error: {exc}",
            )
        )
    except OSError as exc:
        logger.warning("Failed to read {}: {}", path, exc)
        errors.append(
            PluginDocumentError(
                path=path,
                document_index=0,
                message=f"File read error: {exc}",
            )
        )

    return entries, errors
