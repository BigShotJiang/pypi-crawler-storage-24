"""Filesystem-backed loader for StackArchetype plugin documents."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence, cast

import yaml
from loguru import logger

from ..taxonomy.discovery.filesystem import (
    DiscoveryStrategy,
    SingleFileStrategy,
)
from ..taxonomy.ignore import IGNOREFILE_NAME, load_ignore
from ._helpers import (
    ensure_mapping,
    require_string,
)
from .models import PluginDocumentError, PluginRequirement, parse_requirements

ARCHETYPES_API_VERSION = "katalyst.taxonomy.plugins.archetypes/v1alpha"
ARCHETYPE_KIND = "StackArchetype"

# Expected child nodeType at each scope depth.
# scope -> allowed direct child nodeTypes
_SCOPE_CHILD_TYPES: dict[str, str] = {
    "system": "subsystem",
    "subsystem": "stack",
    "stack": "layer",
}

# Reverse mapping: child nodeType -> inferred parent scope
_CHILD_TYPE_TO_SCOPE: dict[str, str] = {
    "subsystem": "system",
    "stack": "subsystem",
    "layer": "stack",
}

# Valid nodeType -> allowed child nodeType (None = leaf)
_NODE_TYPE_CHILDREN: dict[str, str | None] = {
    "subsystem": "stack",
    "stack": "layer",
    "layer": None,
}


@dataclass(frozen=True, slots=True)
class ArchetypeChildNode:
    """A node within an archetype's child tree."""

    name: str
    node_type: str  # "subsystem" | "stack" | "layer"
    description: str
    template_path: Path | None  # resolved absolute path to template dir
    layer_type: str | None  # required when node_type == "layer"
    children: tuple[ArchetypeChildNode, ...] = ()


@dataclass(frozen=True, slots=True)
class ArchetypeDefinition:
    """A fully-loaded archetype definition."""

    name: str
    scope: str  # "system" | "subsystem" | "stack"
    description: str
    template_path: Path | None  # root-level template directory
    children: tuple[ArchetypeChildNode, ...]
    requirements: tuple[PluginRequirement, ...]
    path: Path  # source YAML file
    document_index: int


@dataclass(frozen=True, slots=True)
class ArchetypesPluginResult:
    """Aggregated archetype definitions with indexed lookups."""

    definitions: tuple[ArchetypeDefinition, ...]
    errors: tuple[PluginDocumentError, ...]
    _by_name: dict[str, ArchetypeDefinition]

    def definition(self, name: str) -> ArchetypeDefinition | None:
        """Look up an archetype by name."""
        return self._by_name.get(name)


def load_archetypes(
    base_path: Path,
    *,
    strategy: DiscoveryStrategy | None = None,
) -> ArchetypesPluginResult:
    """Load archetype plugin definitions from ``base_path``."""
    discovery = strategy or SingleFileStrategy()
    candidates = _discover_candidate_files(base_path, discovery)
    ignore = load_ignore(base_path)

    definitions: list[ArchetypeDefinition] = []
    errors: list[PluginDocumentError] = []

    for path in candidates:
        if ignore and ignore.should_ignore(path, is_dir=path.is_dir()):
            logger.debug("Archetypes plugin ignoring path {} due to .taxignore rules", path)
            continue
        if not path.is_file():
            continue

        errors.extend(_parse_archetype_documents(path, definitions, base_path))

    definition_index: dict[str, ArchetypeDefinition] = {}
    for defn in definitions:
        definition_index[defn.name] = defn

    logger.info(
        "Loaded archetypes plugin data: {} definitions, {} errors",
        len(definitions),
        len(errors),
    )

    return ArchetypesPluginResult(
        definitions=tuple(definitions),
        errors=tuple(errors),
        _by_name=definition_index,
    )


# ------------------------------------------------------------------
# Discovery
# ------------------------------------------------------------------


def _discover_candidate_files(
    base_path: Path,
    strategy: DiscoveryStrategy,
) -> tuple[Path, ...]:
    if not base_path.exists():
        return ()

    seen: set[Path] = set()
    discovered: list[Path] = []
    for path in strategy.discover(base_path):
        if path.name == IGNOREFILE_NAME:
            continue
        absolute = path.resolve()
        if absolute in seen:
            continue
        seen.add(absolute)
        discovered.append(path)

    discovered.sort(key=lambda item: (len(item.parts), str(item)))
    return tuple(discovered)


# ------------------------------------------------------------------
# Parsing
# ------------------------------------------------------------------


def _parse_archetype_documents(
    path: Path,
    definitions: list[ArchetypeDefinition],
    base_path: Path,
) -> tuple[PluginDocumentError, ...]:
    errors: list[PluginDocumentError] = []
    try:
        with path.open("r", encoding="utf-8") as stream:
            for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                if not document:
                    continue
                if not isinstance(document, Mapping):
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message="Plugin document must be a mapping",
                        ),
                    )
                    continue

                document_mapping = cast(Mapping[str, object], document)
                api_version = document_mapping.get("apiVersion")
                kind = document_mapping.get("kind")
                if (
                    not isinstance(api_version, str)
                    or not isinstance(kind, str)
                    or api_version != ARCHETYPES_API_VERSION
                    or kind != ARCHETYPE_KIND
                ):
                    continue

                try:
                    definitions.append(_build_definition(document_mapping, path, index, base_path))
                except ValueError as exc:
                    logger.warning("Archetypes plugin parse error in {}: {}", path, exc)
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message=str(exc),
                        ),
                    )
    except yaml.YAMLError as exc:
        logger.warning("Archetypes plugin YAML error in {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))
    except OSError as exc:
        logger.warning("Failed to open archetypes plugin file {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))

    return tuple(errors)


# ------------------------------------------------------------------
# Building definitions
# ------------------------------------------------------------------


def _build_definition(
    document: Mapping[str, object],
    path: Path,
    index: int,
    base_path: Path,
) -> ArchetypeDefinition:
    metadata = ensure_mapping(document.get("metadata"), "metadata", path, index)
    spec = ensure_mapping(document.get("spec"), "spec", path, index)

    name = require_string(metadata.get("name"), "metadata.name", path, index)
    description = require_string(spec.get("description"), "spec.description", path, index)

    # Parse requirements
    requirements = parse_requirements(metadata.get("requires"), path, index)

    # Parse children
    raw_children = spec.get("children")
    if not isinstance(raw_children, Sequence) or isinstance(raw_children, (str, bytes, bytearray)):
        raise ValueError(f"spec.children must be a non-empty array (path={path}, document={index})")
    children_seq = cast(Sequence[object], raw_children)
    if len(children_seq) == 0:
        raise ValueError(
            f"spec.children must contain at least one entry (path={path}, document={index})"
        )

    # Determine scope
    scope = _determine_scope(metadata, children_seq, path, index)

    # Validate and build child nodes
    expected_child_type = _SCOPE_CHILD_TYPES.get(scope)
    if not expected_child_type:
        raise ValueError(f"Invalid scope '{scope}' (path={path}, document={index})")

    children = _build_children(
        children_seq,
        expected_child_type,
        path,
        index,
        base_path,
    )

    # Resolve root template path
    template_path = _resolve_template_path(spec.get("template"), path, base_path)

    return ArchetypeDefinition(
        name=name,
        scope=scope,
        description=description,
        template_path=template_path,
        children=children,
        requirements=requirements,
        path=path,
        document_index=index,
    )


def _determine_scope(
    metadata: Mapping[str, object],
    raw_children: Sequence[object],
    path: Path,
    index: int,
) -> str:
    """Determine the archetype scope from labels or by inference from children."""
    labels = metadata.get("labels")
    if isinstance(labels, Mapping):
        labels_map = cast(Mapping[str, object], labels)
        scope_value = labels_map.get("scope")
        if isinstance(scope_value, str) and scope_value:
            if scope_value not in ("system", "subsystem", "stack"):
                raise ValueError(
                    f"metadata.labels.scope must be one of system, subsystem, stack "
                    f"(path={path}, document={index})"
                )
            return scope_value

    # Infer from first child's nodeType
    if raw_children:
        first_child = raw_children[0]
        if isinstance(first_child, Mapping):
            child_mapping = cast(Mapping[str, object], first_child)
            child_type = child_mapping.get("nodeType")
            if isinstance(child_type, str) and child_type in _CHILD_TYPE_TO_SCOPE:
                return _CHILD_TYPE_TO_SCOPE[child_type]

    raise ValueError(
        f"Cannot determine archetype scope: provide metadata.labels.scope or "
        f"ensure children have a valid nodeType (path={path}, document={index})"
    )


def _build_children(
    raw_children: Sequence[object],
    expected_type: str,
    path: Path,
    index: int,
    base_path: Path,
) -> tuple[ArchetypeChildNode, ...]:
    """Build child node tree recursively, validating hierarchy constraints."""
    children: list[ArchetypeChildNode] = []

    for raw_child in raw_children:
        if not isinstance(raw_child, Mapping):
            raise ValueError(
                f"spec.children entries must be mappings (path={path}, document={index})"
            )
        child_mapping = cast(Mapping[str, object], raw_child)
        children.append(_build_child_node(child_mapping, expected_type, path, index, base_path))

    return tuple(children)


def _build_child_node(
    child: Mapping[str, object],
    expected_type: str,
    path: Path,
    index: int,
    base_path: Path,
) -> ArchetypeChildNode:
    """Build a single child node, validating its type and recursing into children."""
    name = require_string(child.get("name"), "child.name", path, index)
    node_type = require_string(child.get("nodeType"), "child.nodeType", path, index)
    description = require_string(child.get("description"), "child.description", path, index)

    # Validate nodeType matches expected type for this depth
    if node_type != expected_type:
        raise ValueError(
            f"Child '{name}' has nodeType '{node_type}' but expected '{expected_type}' "
            f"at this depth (path={path}, document={index})"
        )

    # Layer-specific validation
    layer_type: str | None = None
    if node_type == "layer":
        raw_layer_type = child.get("layerType")
        if not isinstance(raw_layer_type, str) or not raw_layer_type:
            raise ValueError(
                f"Layer child '{name}' requires a non-empty layerType "
                f"(path={path}, document={index})"
            )
        layer_type = raw_layer_type

        # Layers must not have children
        if child.get("children") is not None:
            raise ValueError(
                f"Layer child '{name}' must not have children (path={path}, document={index})"
            )

        template_path = _resolve_template_path(child.get("template"), path, base_path)

        return ArchetypeChildNode(
            name=name,
            node_type=node_type,
            description=description,
            template_path=template_path,
            layer_type=layer_type,
            children=(),
        )

    # Non-layer nodes: must have children
    raw_sub_children = child.get("children")
    if not isinstance(raw_sub_children, Sequence) or isinstance(
        raw_sub_children, (str, bytes, bytearray)
    ):
        raise ValueError(
            f"Non-layer child '{name}' must have a children array (path={path}, document={index})"
        )
    sub_children_seq = cast(Sequence[object], raw_sub_children)
    if len(sub_children_seq) == 0:
        raise ValueError(
            f"Non-layer child '{name}' must have at least one child (path={path}, document={index})"
        )

    # Determine expected child type for next depth
    next_expected = _NODE_TYPE_CHILDREN.get(node_type)
    if not next_expected:
        raise ValueError(
            f"Invalid nodeType '{node_type}' for child '{name}' (path={path}, document={index})"
        )

    sub_children = _build_children(
        sub_children_seq,
        next_expected,
        path,
        index,
        base_path,
    )

    template_path = _resolve_template_path(child.get("template"), path, base_path)

    return ArchetypeChildNode(
        name=name,
        node_type=node_type,
        description=description,
        template_path=template_path,
        layer_type=None,
        children=sub_children,
    )


def _resolve_template_path(
    value: object,
    document_path: Path,
    base_path: Path,
) -> Path | None:
    """Resolve an optional template path relative to the YAML file or base path.

    Returns None if the field is absent or the directory does not exist.
    """
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        return None

    candidates = [
        document_path.parent / value,
        base_path / value,
    ]
    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            return candidate

    return None
