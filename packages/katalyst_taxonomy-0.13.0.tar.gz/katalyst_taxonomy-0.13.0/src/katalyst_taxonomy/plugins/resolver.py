"""Plugin dependency resolver with cycle detection.

This module provides dependency resolution for plugins that declare
requirements on other plugins. It uses topological sorting to determine
a valid load order and detects circular dependencies.

The resolver supports:
- Required dependencies (missing = error)
- Optional dependencies (missing = warning)
- Conditional dependencies (missing = silently skip, mark inactive)
- Source hints for direct path resolution
- Cycle detection with full path reporting
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, cast

import yaml
from loguru import logger

from .index import PluginIndex, PluginIndexEntry
from .models import PluginRequirement

__all__ = [
    "CircularDependencyError",
    "MissingDependencyError",
    "ResolutionResult",
    "resolve_dependencies",
]


@dataclass(frozen=True, slots=True)
class CircularDependencyError:
    """Error indicating a circular dependency was detected.

    Attributes:
        cycle: The cycle path as a tuple of plugin identifiers
        message: Human-readable error message showing the cycle
    """

    cycle: tuple[str, ...]
    message: str


@dataclass(frozen=True, slots=True)
class MissingDependencyError:
    """Error indicating a required dependency was not found.

    Attributes:
        plugin_path: Path to the plugin that has the missing dependency
        plugin_name: Name of the plugin that has the missing dependency
        missing_requirement: The requirement that could not be resolved
        optional: Whether this was an optional dependency
        message: Human-readable error message
    """

    plugin_path: Path
    plugin_name: str
    missing_requirement: PluginRequirement
    optional: bool
    message: str


@dataclass(frozen=True, slots=True)
class ResolutionResult:
    """Result of dependency resolution.

    Attributes:
        load_order: Plugins in topological order (dependencies first)
        errors: Hard errors that prevent loading (missing required deps, cycles)
        warnings: Soft warnings (missing optional deps)
        inactive: Plugins that are inactive due to missing conditional dependencies
    """

    load_order: tuple[PluginIndexEntry, ...]
    errors: tuple[CircularDependencyError | MissingDependencyError, ...]
    warnings: tuple[MissingDependencyError, ...]
    inactive: tuple[PluginIndexEntry, ...] = ()

    @property
    def is_success(self) -> bool:
        """Return True if resolution succeeded without errors."""
        return len(self.errors) == 0


def resolve_dependencies(
    index: PluginIndex,
    requirements_map: Mapping[tuple[str, str, str], tuple[PluginRequirement, ...]],
    *,
    base_path: Path | None = None,
) -> ResolutionResult:
    """Resolve plugin dependencies and return a valid load order.

    This function builds a dependency graph from the requirements map,
    performs topological sorting, and detects cycles.

    Dependency modes:
    - required: Error if missing
    - optional: Warning if missing, plugin still loads
    - conditional: Silently skip if missing, plugin marked as inactive

    Args:
        index: The plugin index for lookups
        requirements_map: Map from plugin key to its requirements
        base_path: Optional base path for resolving source hints

    Returns:
        ResolutionResult with load order, errors, warnings, and inactive plugins
    """
    errors: list[CircularDependencyError | MissingDependencyError] = []
    warnings: list[MissingDependencyError] = []
    inactive_keys: set[tuple[str, str, str]] = set()

    # Build adjacency list for dependency graph
    # Key depends on values (edges point from dependent to dependency)
    graph: dict[tuple[str, str, str], list[tuple[str, str, str]]] = defaultdict(list)
    in_degree: dict[tuple[str, str, str], int] = {}

    # Initialize all entries with in_degree 0
    for entry in index.entries:
        in_degree[entry.key] = 0

    # Track dynamically resolved entries (from source hints)
    dynamic_entries: dict[tuple[str, str, str], PluginIndexEntry] = {}

    # Process requirements and build graph
    for plugin_key, requirements in requirements_map.items():
        if plugin_key not in in_degree:
            # Plugin not in index, skip
            continue

        plugin_entry = index.lookup(*plugin_key)
        plugin_path = plugin_entry.path if plugin_entry else Path("unknown")
        plugin_name = plugin_key[2]  # name is third element

        for req in requirements:
            dep_key = req.key

            # Try to resolve the dependency
            resolved_entry = _resolve_requirement(req, index, dynamic_entries, base_path)

            if resolved_entry is None:
                # Dependency not found - behavior depends on mode
                if req.mode == "conditional":
                    # Conditional: silently mark as inactive
                    inactive_keys.add(plugin_key)
                    logger.debug(
                        "Plugin '{}' marked inactive: conditional dependency '{}' not found",
                        plugin_name,
                        req.name,
                    )
                    continue
                elif req.mode == "optional" or req.optional:
                    # Optional: warn but continue
                    warnings.append(
                        MissingDependencyError(
                            plugin_path=plugin_path,
                            plugin_name=plugin_name,
                            missing_requirement=req,
                            optional=True,
                            message=(
                                f"Missing optional dependency: "
                                f"{req.kind} '{req.name}' required by '{plugin_name}' "
                                f"was not found in plugin index"
                            ),
                        )
                    )
                    continue
                else:
                    # Required: error
                    errors.append(
                        MissingDependencyError(
                            plugin_path=plugin_path,
                            plugin_name=plugin_name,
                            missing_requirement=req,
                            optional=False,
                            message=(
                                f"Missing dependency: "
                                f"{req.kind} '{req.name}' required by '{plugin_name}' "
                                f"was not found in plugin index"
                            ),
                        )
                    )
                    continue

            # Add edge: plugin_key depends on dep_key
            graph[plugin_key].append(dep_key)

            # Ensure dependency is in in_degree map
            if dep_key not in in_degree:
                in_degree[dep_key] = 0
                dynamic_entries[dep_key] = resolved_entry

            in_degree[dep_key] += 1

    # If we have errors already (missing required deps), return early
    if errors:
        inactive_entries = tuple(
            entry for k in inactive_keys if (entry := index.lookup(*k)) is not None
        )
        return ResolutionResult(
            load_order=(),
            errors=tuple(errors),
            warnings=tuple(warnings),
            inactive=inactive_entries,
        )

    # Topological sort using Kahn's algorithm with cycle detection
    load_order, cycle = _topological_sort(graph, in_degree, index, dynamic_entries)

    if cycle:
        cycle_str = " -> ".join(cycle)
        errors.append(
            CircularDependencyError(
                cycle=tuple(cycle),
                message=f"Circular dependency detected: {cycle_str}",
            )
        )
        inactive_entries = tuple(
            entry for k in inactive_keys if (entry := index.lookup(*k)) is not None
        )
        return ResolutionResult(
            load_order=(),
            errors=tuple(errors),
            warnings=tuple(warnings),
            inactive=inactive_entries,
        )

    # Filter out inactive plugins from load order
    active_load_order = [e for e in load_order if e.key not in inactive_keys]
    inactive_entries = tuple(
        entry for k in inactive_keys if (entry := index.lookup(*k)) is not None
    )

    logger.info(
        "Resolved plugin dependencies: {} active, {} inactive",
        len(active_load_order),
        len(inactive_entries),
    )

    return ResolutionResult(
        load_order=tuple(active_load_order),
        errors=tuple(errors),
        warnings=tuple(warnings),
        inactive=inactive_entries,
    )


def _resolve_requirement(
    req: PluginRequirement,
    index: PluginIndex,
    dynamic_entries: dict[tuple[str, str, str], PluginIndexEntry],
    base_path: Path | None,
) -> PluginIndexEntry | None:
    """Resolve a requirement to a PluginIndexEntry.

    Resolution order:
    1. If source hint provided, try direct path resolution
    2. Otherwise, look up in index

    Args:
        req: The requirement to resolve
        index: The plugin index
        dynamic_entries: Already resolved dynamic entries
        base_path: Base path for resolving source hints

    Returns:
        PluginIndexEntry if found, None otherwise
    """
    # Check if already resolved dynamically
    if req.key in dynamic_entries:
        return dynamic_entries[req.key]

    # Check index first (even with source hint, prefer indexed version)
    indexed = index.lookup(*req.key)
    if indexed is not None:
        return indexed

    # Try source hint if provided
    if req.source and base_path:
        source_path = base_path / req.source
        if source_path.exists():
            # Parse the file to find the matching entry
            entry = _find_entry_in_file(source_path, req)
            if entry:
                return entry

    return None


def _find_entry_in_file(
    path: Path,
    req: PluginRequirement,
) -> PluginIndexEntry | None:
    """Find a plugin entry matching the requirement in a file.

    Args:
        path: Path to the file to search
        req: The requirement to match

    Returns:
        PluginIndexEntry if found, None otherwise
    """
    try:
        with path.open("r", encoding="utf-8") as stream:
            for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                if not document or not isinstance(document, Mapping):
                    continue

                doc = cast(Mapping[str, object], document)
                api_version = doc.get("apiVersion")
                kind = doc.get("kind")
                metadata = doc.get("metadata")

                if not isinstance(metadata, Mapping):
                    continue

                meta = cast(Mapping[str, object], metadata)
                name = meta.get("name")

                if api_version == req.api_version and kind == req.kind and name == req.name:
                    return PluginIndexEntry(
                        api_version=str(api_version),
                        kind=str(kind),
                        name=str(name),
                        path=path,
                        document_index=index,
                    )
    except (yaml.YAMLError, OSError):
        pass

    return None


def _topological_sort(
    graph: dict[tuple[str, str, str], list[tuple[str, str, str]]],
    in_degree: dict[tuple[str, str, str], int],
    index: PluginIndex,
    dynamic_entries: dict[tuple[str, str, str], PluginIndexEntry],
) -> tuple[list[PluginIndexEntry], list[str] | None]:
    """Perform topological sort with cycle detection.

    Uses Kahn's algorithm. If a cycle is detected, returns the cycle path.

    Args:
        graph: Adjacency list (node -> list of nodes it depends on)
        in_degree: In-degree count for each node
        index: Plugin index for looking up entries
        dynamic_entries: Dynamically resolved entries

    Returns:
        Tuple of (sorted_entries, cycle_path).
        If successful, cycle_path is None.
        If cycle detected, sorted_entries is empty and cycle_path contains the cycle.
    """
    # Note: We need to reverse the logic here
    # graph[A] = [B] means A depends on B, so B should come before A
    # We need to build the reverse graph for in_degree calculation

    # Rebuild with correct edge direction for topological sort
    # An edge A -> B means "A must come after B" (A depends on B)
    # So in_degree should count how many things depend on each node

    reverse_in_degree: dict[tuple[str, str, str], int] = {k: 0 for k in in_degree}
    reverse_graph: dict[tuple[str, str, str], list[tuple[str, str, str]]] = defaultdict(list)

    for node, dependencies in graph.items():
        for dep in dependencies:
            # node depends on dep, so node must come after dep
            # In reverse: dep -> node (dep must be processed first)
            reverse_graph[dep].append(node)
            reverse_in_degree[node] = reverse_in_degree.get(node, 0) + 1
            if dep not in reverse_in_degree:
                reverse_in_degree[dep] = 0

    # Start with nodes that have no dependencies (in_degree = 0)
    queue = [k for k, v in reverse_in_degree.items() if v == 0]
    result: list[PluginIndexEntry] = []
    processed = 0

    while queue:
        # Sort for deterministic order
        queue.sort()
        current = queue.pop(0)
        processed += 1

        # Get the entry
        entry = index.lookup(*current) or dynamic_entries.get(current)
        if entry:
            result.append(entry)

        # Process dependents
        for dependent in reverse_graph[current]:
            reverse_in_degree[dependent] -= 1
            if reverse_in_degree[dependent] == 0:
                queue.append(dependent)

    # Check for cycle
    if processed < len(reverse_in_degree):
        # Find the cycle using DFS
        cycle = _find_cycle(graph, reverse_in_degree)
        return [], cycle

    return result, None


def _find_cycle(
    graph: dict[tuple[str, str, str], list[tuple[str, str, str]]],
    in_degree: dict[tuple[str, str, str], int],
) -> list[str]:
    """Find a cycle in the graph using DFS.

    Args:
        graph: Adjacency list
        in_degree: In-degree counts (nodes with non-zero remaining are in cycle)

    Returns:
        List of node names forming the cycle
    """
    # Find nodes that are part of a cycle (in_degree > 0 after topo sort)
    remaining = {k for k, v in in_degree.items() if v > 0}

    if not remaining:
        return []

    # DFS to find cycle
    visited: set[tuple[str, str, str]] = set()
    path: list[tuple[str, str, str]] = []
    path_set: set[tuple[str, str, str]] = set()

    def dfs(node: tuple[str, str, str]) -> list[str] | None:
        if node in path_set:
            # Found cycle - extract it
            cycle_start = path.index(node)
            cycle_nodes = path[cycle_start:] + [node]
            return [f"{k}:{n}" for _, k, n in cycle_nodes]

        if node in visited:
            return None

        visited.add(node)
        path.append(node)
        path_set.add(node)

        for dep in graph.get(node, []):
            cycle = dfs(dep)
            if cycle:
                return cycle

        path.pop()
        path_set.remove(node)
        return None

    # Start DFS from remaining nodes
    for start in remaining:
        cycle = dfs(start)
        if cycle:
            return cycle

    # Fallback: return all remaining nodes
    return [f"{k}:{n}" for _, k, n in remaining]
