"""Extension plugin loader.

Extensions are plugins that augment other plugins with additional
templates, files, or configuration. They support conditional activation
based on prerequisites (other plugins that must exist).

Example Extension:

```yaml
apiVersion: katalyst.taxonomy.plugins.extensions/v1alpha
kind: Extension
metadata:
  name: agentic-layer-support
  requires:
    - apiVersion: katalyst.taxonomy.plugins.capabilities/v1alpha
      kind: Capability
      name: agentic-coding
      mode: conditional
spec:
  description: Adds agent configuration to layers
  extends:
    apiVersion: katalyst.taxonomy.plugins.layer_types/v1alpha
    kind: LayerType
    names: ["*"]  # or specific: ["app-docker", "app-fastapi"]
  provides:
    template: templates/agentic-addon
    # or explicit files:
    files:
      - source: AGENTS.md.j2
        destination: AGENTS.md
```
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence, cast

import yaml
from loguru import logger

from ..taxonomy.discovery.filesystem import (
    ByKindStrategy,
    CompositeDiscoveryStrategy,
    DiscoveryStrategy,
    RecursiveStrategy,
    SingleFileStrategy,
)
from ..taxonomy.ignore import IGNOREFILE_NAME, load_ignore
from ._helpers import ensure_mapping, require_string
from .models import PluginDocumentError, PluginRequirement, parse_requirements

EXTENSIONS_API_VERSION = "katalyst.taxonomy.plugins.extensions/v1alpha"
EXTENSION_KIND = "Extension"

__all__ = [
    "Extension",
    "ExtensionProvides",
    "ExtensionTarget",
    "ExtensionsPluginResult",
    "load_extensions",
]


@dataclass(frozen=True, slots=True)
class ExtensionTarget:
    """Specifies what plugin(s) an extension targets.

    Attributes:
        api_version: The apiVersion of target plugins
        kind: The kind of target plugins
        names: Tuple of target names, or ("*",) for all
    """

    api_version: str
    kind: str
    names: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ExtensionProvides:
    """Specifies what an extension provides when activated.

    Attributes:
        template: Path to template directory to merge (optional)
        files: Tuple of (source, destination) file mappings (optional)
    """

    template: str | None
    files: tuple[tuple[str, str], ...]


@dataclass(frozen=True, slots=True)
class Extension:
    """An extension plugin definition.

    Extensions augment other plugins with additional templates or files.
    They can have conditional dependencies that determine whether they
    are activated.

    Attributes:
        name: Unique identifier for this extension
        description: Human-readable description
        extends: What this extension targets
        provides: What this extension adds when activated
        requirements: Dependencies (from metadata.requires)
        path: Source file path
        document_index: 1-based document index in source file
    """

    name: str
    description: str | None
    extends: ExtensionTarget
    provides: ExtensionProvides
    requirements: tuple[PluginRequirement, ...] = ()
    path: Path = Path("unknown")
    document_index: int = 0

    def targets_plugin(self, api_version: str, kind: str, name: str) -> bool:
        """Check if this extension targets a specific plugin.

        Args:
            api_version: The plugin's apiVersion
            kind: The plugin's kind
            name: The plugin's name

        Returns:
            True if this extension applies to the specified plugin
        """
        if self.extends.api_version != api_version:
            return False
        if self.extends.kind != kind:
            return False
        if "*" in self.extends.names:
            return True
        return name in self.extends.names


@dataclass(frozen=True, slots=True)
class ExtensionsPluginResult:
    """Result of loading extension plugins.

    Attributes:
        extensions: All loaded extensions
        errors: Parsing errors encountered
        _by_name: Internal index for name lookup
    """

    extensions: tuple[Extension, ...]
    errors: tuple[PluginDocumentError, ...]
    _by_name: dict[str, Extension]

    def extension(self, name: str) -> Extension | None:
        """Look up an extension by name."""
        return self._by_name.get(name)

    def extensions_for_target(
        self,
        api_version: str,
        kind: str,
        name: str,
    ) -> tuple[Extension, ...]:
        """Get all extensions that target a specific plugin.

        Args:
            api_version: The target plugin's apiVersion
            kind: The target plugin's kind
            name: The target plugin's name

        Returns:
            Tuple of extensions that apply to the target
        """
        return tuple(ext for ext in self.extensions if ext.targets_plugin(api_version, kind, name))


def load_extensions(
    base_path: Path,
    *,
    strategy: DiscoveryStrategy | None = None,
) -> ExtensionsPluginResult:
    """Load extension plugins from the filesystem.

    Args:
        base_path: Root path to search for extension files
        strategy: Optional custom discovery strategy

    Returns:
        ExtensionsPluginResult containing extensions and any errors
    """
    discovery = strategy or CompositeDiscoveryStrategy(
        strategies=(SingleFileStrategy(), ByKindStrategy(), RecursiveStrategy()),
    )

    candidates = _discover_candidate_files(base_path, discovery)
    ignore = load_ignore(base_path)

    extensions: list[Extension] = []
    errors: list[PluginDocumentError] = []

    for path in candidates:
        if ignore and ignore.should_ignore(path, is_dir=path.is_dir()):
            logger.debug("Extensions plugin ignoring path {} due to .taxignore rules", path)
            continue
        if not path.is_file():
            continue
        errors.extend(_parse_extension_documents(path, extensions))

    by_name = {ext.name: ext for ext in extensions}

    logger.info("Loaded {} extensions from {} files", len(extensions), len(candidates))

    return ExtensionsPluginResult(
        extensions=tuple(extensions),
        errors=tuple(errors),
        _by_name=by_name,
    )


def _discover_candidate_files(
    base_path: Path,
    strategy: DiscoveryStrategy,
) -> tuple[Path, ...]:
    """Discover candidate files for extension loading."""
    if not base_path.exists():
        return ()

    seen: set[Path] = set()
    discovered: list[Path] = []
    for path in strategy.discover(base_path):
        if path.name == IGNOREFILE_NAME:
            continue
        absolute = path.resolve()
        if absolute in seen:
            continue
        seen.add(absolute)
        discovered.append(path)

    discovered.sort(key=lambda item: (len(item.parts), str(item)))
    return tuple(discovered)


def _parse_extension_documents(
    path: Path,
    extensions: list[Extension],
) -> tuple[PluginDocumentError, ...]:
    """Parse extension documents from a YAML file."""
    errors: list[PluginDocumentError] = []

    try:
        with path.open("r", encoding="utf-8") as stream:
            for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                if not document:
                    continue
                if not isinstance(document, Mapping):
                    continue

                document_mapping = cast(Mapping[str, object], document)
                api_version = document_mapping.get("apiVersion")
                kind = document_mapping.get("kind")

                if api_version != EXTENSIONS_API_VERSION or kind != EXTENSION_KIND:
                    continue

                try:
                    extensions.append(_build_extension(document_mapping, path, index))
                except ValueError as exc:
                    logger.warning("Extension plugin parse error in {}: {}", path, exc)
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message=str(exc),
                        )
                    )

    except yaml.YAMLError as exc:
        logger.warning("Extension plugin YAML error in {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))
    except OSError as exc:
        logger.warning("Failed to open extension plugin file {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))

    return tuple(errors)


def _build_extension(
    document: Mapping[str, object],
    path: Path,
    index: int,
) -> Extension:
    """Build an Extension from a parsed document."""
    metadata = ensure_mapping(document.get("metadata"), "metadata", path, index)
    spec = ensure_mapping(document.get("spec"), "spec", path, index)

    name = require_string(metadata.get("name"), "metadata.name", path, index)

    # Parse requirements from metadata
    requirements = parse_requirements(metadata.get("requires"), path, index)

    # Parse description (optional)
    description_value = spec.get("description")
    description: str | None = None
    if description_value is not None:
        if not isinstance(description_value, str):
            raise ValueError(f"spec.description must be a string (path={path}, document={index})")
        description = description_value

    # Parse extends (required)
    extends_raw = spec.get("extends")
    if extends_raw is None:
        raise ValueError(f"spec.extends is required (path={path}, document={index})")
    extends = _parse_extends(extends_raw, path, index)

    # Parse provides (required)
    provides_raw = spec.get("provides")
    if provides_raw is None:
        raise ValueError(f"spec.provides is required (path={path}, document={index})")
    provides = _parse_provides(provides_raw, path, index)

    return Extension(
        name=name,
        description=description,
        extends=extends,
        provides=provides,
        requirements=requirements,
        path=path,
        document_index=index,
    )


def _parse_extends(
    value: object,
    path: Path,
    index: int,
) -> ExtensionTarget:
    """Parse the extends field."""
    if not isinstance(value, Mapping):
        raise ValueError(f"spec.extends must be a mapping (path={path}, document={index})")

    extends_map = cast(Mapping[str, Any], value)

    api_version = extends_map.get("apiVersion")
    if not isinstance(api_version, str) or not api_version:
        raise ValueError(
            f"spec.extends.apiVersion must be a non-empty string (path={path}, document={index})"
        )

    kind = extends_map.get("kind")
    if not isinstance(kind, str) or not kind:
        raise ValueError(
            f"spec.extends.kind must be a non-empty string (path={path}, document={index})"
        )

    names_raw = extends_map.get("names")
    if names_raw is None:
        raise ValueError(f"spec.extends.names is required (path={path}, document={index})")
    if not isinstance(names_raw, Sequence) or isinstance(names_raw, (str, bytes)):
        raise ValueError(f"spec.extends.names must be a list (path={path}, document={index})")

    names: list[str] = []
    for name in cast(Sequence[object], names_raw):
        if not isinstance(name, str) or not name:
            raise ValueError(
                f"spec.extends.names entries must be non-empty strings (path={path}, document={index})"
            )
        names.append(name)

    if not names:
        raise ValueError(
            f"spec.extends.names must contain at least one entry (path={path}, document={index})"
        )

    return ExtensionTarget(
        api_version=api_version,
        kind=kind,
        names=tuple(names),
    )


def _parse_provides(
    value: object,
    path: Path,
    index: int,
) -> ExtensionProvides:
    """Parse the provides field."""
    if not isinstance(value, Mapping):
        raise ValueError(f"spec.provides must be a mapping (path={path}, document={index})")

    provides_map = cast(Mapping[str, Any], value)

    # Parse template (optional)
    template_raw = provides_map.get("template")
    template: str | None = None
    if template_raw is not None:
        if not isinstance(template_raw, str) or not template_raw:
            raise ValueError(
                f"spec.provides.template must be a non-empty string (path={path}, document={index})"
            )
        template = template_raw

    # Parse files (optional)
    files_raw = provides_map.get("files")
    files: list[tuple[str, str]] = []
    if files_raw is not None:
        if not isinstance(files_raw, Sequence) or isinstance(files_raw, (str, bytes)):
            raise ValueError(f"spec.provides.files must be a list (path={path}, document={index})")

        for file_index, file_entry in enumerate(cast(Sequence[object], files_raw), start=1):
            if not isinstance(file_entry, Mapping):
                raise ValueError(
                    f"spec.provides.files[{file_index}] must be a mapping (path={path}, document={index})"
                )

            file_map = cast(Mapping[str, Any], file_entry)
            source = file_map.get("source")
            destination = file_map.get("destination")

            if not isinstance(source, str) or not source:
                raise ValueError(
                    f"spec.provides.files[{file_index}].source must be a non-empty string "
                    f"(path={path}, document={index})"
                )
            if not isinstance(destination, str) or not destination:
                raise ValueError(
                    f"spec.provides.files[{file_index}].destination must be a non-empty string "
                    f"(path={path}, document={index})"
                )

            files.append((source, destination))

    # At least one of template or files must be provided
    if template is None and not files:
        raise ValueError(
            f"spec.provides must have either 'template' or 'files' (path={path}, document={index})"
        )

    return ExtensionProvides(
        template=template,
        files=tuple(files),
    )
