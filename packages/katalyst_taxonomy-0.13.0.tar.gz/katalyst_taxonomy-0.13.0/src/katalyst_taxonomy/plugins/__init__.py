"""Plugin utilities for the katalyst toolkit."""

from ._helpers import (
    EnvironmentContract,
)
from .activation import (
    ActivationResult,
    resolve_active_extensions,
)
from .archetypes import (
    ArchetypeChildNode,
    ArchetypeDefinition,
    ArchetypesPluginResult,
    load_archetypes,
)
from .capabilities import (
    Capability,
    CapabilityPluginResult,
    CapabilityRelationship,
    load_capabilities,
)
from .cicd import (
    CICDPluginResult,
    JobTemplateDefinition,
    StageDefinition,
    TemplateReference,
    TemplateRenderer,
    WorkflowJob,
    WorkflowParameter,
    WorkflowTemplateDefinition,
    load_cicd_templates,
)
from .extensions import (
    Extension,
    ExtensionProvides,
    ExtensionsPluginResult,
    ExtensionTarget,
    load_extensions,
)
from .index import (
    DuplicatePluginError,
    PluginIndex,
    PluginIndexEntry,
    build_plugin_index,
)
from .layer_actions import LayerAction, LayerActionsPluginResult, load_layer_actions
from .layer_types import (
    LayerTypeDefinition,
    LayerTypesPluginResult,
    load_layer_types,
)
from .models import (
    REQUIREMENT_MODES,
    PluginDocumentError,
    PluginRequirement,
    RequirementMode,
    parse_requirements,
)
from .resolver import (
    CircularDependencyError,
    MissingDependencyError,
    ResolutionResult,
    resolve_dependencies,
)
from .scaffolding import (
    ExtensionContribution,
    ScaffoldingPlan,
    resolve_scaffolding_plan,
)

__all__ = [
    "ActivationResult",
    "ArchetypeChildNode",
    "ArchetypeDefinition",
    "ArchetypesPluginResult",
    "CICDPluginResult",
    "Capability",
    "CapabilityPluginResult",
    "CapabilityRelationship",
    "CircularDependencyError",
    "DuplicatePluginError",
    "EnvironmentContract",
    "Extension",
    "ExtensionContribution",
    "ExtensionProvides",
    "ExtensionTarget",
    "ExtensionsPluginResult",
    "JobTemplateDefinition",
    "LayerAction",
    "LayerActionsPluginResult",
    "LayerTypeDefinition",
    "LayerTypesPluginResult",
    "MissingDependencyError",
    "PluginDocumentError",
    "PluginIndex",
    "PluginIndexEntry",
    "PluginRequirement",
    "REQUIREMENT_MODES",
    "RequirementMode",
    "ResolutionResult",
    "ScaffoldingPlan",
    "StageDefinition",
    "TemplateReference",
    "TemplateRenderer",
    "WorkflowJob",
    "WorkflowParameter",
    "WorkflowTemplateDefinition",
    "build_plugin_index",
    "load_archetypes",
    "load_capabilities",
    "load_cicd_templates",
    "load_extensions",
    "load_layer_actions",
    "load_layer_types",
    "parse_requirements",
    "resolve_active_extensions",
    "resolve_dependencies",
    "resolve_scaffolding_plan",
]
