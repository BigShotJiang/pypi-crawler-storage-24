"""Filesystem-backed loader for the layer actions plugin."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, cast

import yaml
from loguru import logger

from ..taxonomy.discovery.filesystem import (
    ByKindStrategy,
    CompositeDiscoveryStrategy,
    DiscoveryStrategy,
    RecursiveStrategy,
    SingleFileStrategy,
)
from ..taxonomy.ignore import IGNOREFILE_NAME, load_ignore
from ._helpers import (
    EnvironmentContract,
    collect_string_mapping,
    collect_strings,
    ensure_mapping,
    parse_environment_contract,
    require_string,
)
from .models import PluginDocumentError

LAYER_ACTIONS_API_VERSION = "katalyst.taxonomy.plugins.actions/v1alpha"
ACTION_KIND = "Action"


@dataclass(frozen=True, slots=True)
class LayerAction:
    """Concrete action definition parsed from plugin manifests."""

    name: str
    description: str | None
    action_type: str
    when: str
    run: str
    timeout_seconds: int | None
    environment: tuple[tuple[str, str], ...]
    tags: tuple[str, ...]
    layer_type: str | None
    path: Path
    document_index: int
    environment_contract: EnvironmentContract


@dataclass(frozen=True, slots=True)
class LayerActionsPluginResult:
    """Aggregated view of layer actions grouped by layer type."""

    actions: tuple[LayerAction, ...]
    errors: tuple[PluginDocumentError, ...]
    _actions_by_name: dict[str, LayerAction]
    _actions_by_layer_type: dict[str, tuple[LayerAction, ...]]

    def action(self, name: str) -> LayerAction | None:
        return self._actions_by_name.get(name)

    def actions_for_layer_type(self, layer_type: str) -> tuple[LayerAction, ...]:
        return self._actions_by_layer_type.get(layer_type, tuple())

    def layer_types(self) -> tuple[str, ...]:
        return tuple(sorted(self._actions_by_layer_type.keys()))

    def unscoped_actions(self) -> tuple[LayerAction, ...]:
        return self._actions_by_layer_type.get("", tuple())


def load_layer_actions(
    base_path: Path,
    *,
    strategy: DiscoveryStrategy | None = None,
) -> LayerActionsPluginResult:
    """Load layer action plugin documents from ``base_path``."""

    discovery = strategy or CompositeDiscoveryStrategy(
        strategies=(SingleFileStrategy(), ByKindStrategy(), RecursiveStrategy()),
    )

    candidates = _discover_candidate_files(base_path, discovery)
    ignore = load_ignore(base_path)

    actions: list[LayerAction] = []
    errors: list[PluginDocumentError] = []

    for path in candidates:
        if ignore and ignore.should_ignore(path, is_dir=path.is_dir()):
            logger.debug("Layer actions plugin ignoring path {} due to .taxignore rules", path)
            continue
        if not path.is_file():
            continue
        errors.extend(_parse_action_documents(path, actions))

    action_index: dict[str, LayerAction] = {}
    layer_type_index: dict[str, tuple[LayerAction, ...]] = {}
    for action in actions:
        action_index[action.name] = action
        layer_type = action.layer_type or ""
        existing = layer_type_index.setdefault(layer_type, tuple())
        layer_type_index[layer_type] = existing + (action,)

    logger.info(
        "Loaded layer actions plugin data: {} actions",
        len(actions),
    )

    return LayerActionsPluginResult(
        actions=tuple(actions),
        errors=tuple(errors),
        _actions_by_name=action_index,
        _actions_by_layer_type=layer_type_index,
    )


def _discover_candidate_files(base_path: Path, strategy: DiscoveryStrategy) -> tuple[Path, ...]:
    if not base_path.exists():
        return tuple()

    seen: set[Path] = set()
    discovered: list[Path] = []
    for path in strategy.discover(base_path):
        if path.name == IGNOREFILE_NAME:
            continue
        absolute = path.resolve()
        if absolute in seen:
            continue
        seen.add(absolute)
        discovered.append(path)

    discovered.sort(key=lambda item: (len(item.parts), str(item)))
    return tuple(discovered)


def _parse_action_documents(
    path: Path,
    actions: list[LayerAction],
) -> tuple[PluginDocumentError, ...]:
    errors: list[PluginDocumentError] = []
    try:
        with path.open("r", encoding="utf-8") as stream:
            for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                if not document:
                    continue
                if not isinstance(document, Mapping):
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message="Plugin document must be a mapping",
                        ),
                    )
                    continue

                document_mapping = cast(Mapping[str, object], document)
                api_version = document_mapping.get("apiVersion")
                kind = document_mapping.get("kind")
                if api_version != LAYER_ACTIONS_API_VERSION or kind != ACTION_KIND:
                    continue

                try:
                    actions.append(_build_action(document_mapping, path, index))
                except ValueError as exc:
                    logger.warning("Layer actions plugin parse error in {}: {}", path, exc)
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message=str(exc),
                        ),
                    )
    except yaml.YAMLError as exc:
        logger.warning("Layer actions plugin YAML error in {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))
    except OSError as exc:
        logger.warning("Failed to open layer actions plugin file {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))

    return tuple(errors)


def _build_action(
    document: Mapping[str, object],
    path: Path,
    index: int,
) -> LayerAction:
    metadata = ensure_mapping(document.get("metadata"), "metadata", path, index)
    spec = ensure_mapping(document.get("spec"), "spec", path, index)
    raw_labels = metadata.get("labels")
    labels: Mapping[str, object] = (
        ensure_mapping(raw_labels, "metadata.labels", path, index) if raw_labels is not None else {}
    )
    layer_type = None
    if labels:
        layer_type_value = labels.get("layerType")
        if isinstance(layer_type_value, str) and layer_type_value:
            layer_type = layer_type_value

    name = require_string(metadata.get("name"), "metadata.name", path, index)
    description_value = metadata.get("description")
    if description_value is not None and not isinstance(description_value, str):
        raise ValueError(
            f"metadata.description must be a string (path={path}, document={index})",
        )

    action_type = require_string(spec.get("type"), "spec.type", path, index)
    when = require_string(spec.get("when"), "spec.when", path, index)
    run = require_string(spec.get("run"), "spec.run", path, index)

    timeout_value = spec.get("timeoutSeconds")
    timeout_seconds = None
    if timeout_value is not None:
        if not isinstance(timeout_value, int) or timeout_value <= 0:
            raise ValueError(
                f"spec.timeoutSeconds must be a positive integer (path={path}, document={index})",
            )
        timeout_seconds = timeout_value

    environment = collect_string_mapping(spec.get("environment"), "spec.environment", path, index)
    tags = collect_strings(spec.get("tags"), "spec.tags", path, index)
    environment_contract = parse_environment_contract(
        spec.get("environmentContract"),
        path,
        index,
    )

    return LayerAction(
        name=name,
        description=description_value if isinstance(description_value, str) else None,
        action_type=action_type,
        when=when,
        run=run,
        timeout_seconds=timeout_seconds,
        environment=environment,
        tags=tuple(tags),
        layer_type=layer_type,
        path=path,
        document_index=index,
        environment_contract=environment_contract,
    )
