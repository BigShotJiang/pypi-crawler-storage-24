"""Extension activation logic.

This module determines which extensions are active for a given target plugin
based on the plugin index and extension requirements.

An extension is active for a target if:
1. It targets the specified plugin (via extends.names, including wildcard "*")
2. All its conditional requirements are satisfied (exist in the plugin index)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from .extensions import Extension
from .index import PluginIndex

__all__ = [
    "ActivationResult",
    "resolve_active_extensions",
]


@dataclass(frozen=True, slots=True)
class ActivationResult:
    """Result of resolving active extensions for a target plugin.

    Attributes:
        active: Extensions that are active (requirements met, targets plugin)
        inactive: Extensions that target the plugin but have unmet requirements
    """

    active: tuple[Extension, ...]
    inactive: tuple[Extension, ...]

    @property
    def active_names(self) -> tuple[str, ...]:
        """Return names of all active extensions."""
        return tuple(ext.name for ext in self.active)

    @property
    def inactive_names(self) -> tuple[str, ...]:
        """Return names of all inactive extensions."""
        return tuple(ext.name for ext in self.inactive)

    @property
    def is_empty(self) -> bool:
        """Return True if there are no active or inactive extensions."""
        return len(self.active) == 0 and len(self.inactive) == 0

    @property
    def has_active(self) -> bool:
        """Return True if there is at least one active extension."""
        return len(self.active) > 0


def resolve_active_extensions(
    extensions: Sequence[Extension],
    index: PluginIndex,
    target_api_version: str,
    target_kind: str,
    target_name: str,
) -> ActivationResult:
    """Determine which extensions are active for a target plugin.

    An extension is active if:
    1. It targets the specified plugin (via extends.names)
    2. All its conditional requirements are satisfied (exist in index)

    Extensions that don't target the plugin are excluded entirely (not in active
    or inactive lists).

    Args:
        extensions: All available extensions to evaluate
        index: Plugin index for requirement lookups
        target_api_version: The apiVersion of the target plugin
        target_kind: The kind of the target plugin
        target_name: The name of the target plugin

    Returns:
        ActivationResult with active and inactive extensions
    """
    active: list[Extension] = []
    inactive: list[Extension] = []

    for ext in extensions:
        # Check if this extension targets the specified plugin
        if not ext.targets_plugin(target_api_version, target_kind, target_name):
            # Not applicable to this target - skip entirely
            continue

        # Check if all requirements are satisfied
        if _requirements_satisfied(ext, index):
            active.append(ext)
        else:
            inactive.append(ext)

    return ActivationResult(
        active=tuple(active),
        inactive=tuple(inactive),
    )


def _requirements_satisfied(ext: Extension, index: PluginIndex) -> bool:
    """Check if all requirements for an extension are satisfied.

    For conditional mode requirements, the extension is inactive if the
    requirement is not met (but no error is raised).

    Args:
        ext: The extension to check
        index: Plugin index for lookups

    Returns:
        True if all requirements are satisfied, False otherwise
    """
    for req in ext.requirements:
        # Check if the required plugin exists in the index
        exists = index.has(req.api_version, req.kind, req.name)

        if not exists:
            # For conditional requirements, missing dependency means inactive
            # For required/optional, they would have been caught during resolution
            # but for activation purposes, we treat all missing as "not activated"
            return False

    return True
