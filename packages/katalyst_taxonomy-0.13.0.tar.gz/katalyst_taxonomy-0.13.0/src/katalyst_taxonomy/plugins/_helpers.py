"""Shared helpers for plugin parsers."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence, cast

__all__ = [
    "EnvironmentContract",
    "collect_string_mapping",
    "collect_strings",
    "ensure_mapping",
    "parse_environment_contract",
    "require_string",
]


@dataclass(frozen=True, slots=True)
class EnvironmentContract:
    """Declares environment keys that a plugin requires.

    ``template_replacements`` lists keys expected in
    ``Environment.spec.templateReplacements``.

    ``layer_templates`` lists keys expected in
    ``Environment.spec.layerTemplates.<layerType>``.
    """

    template_replacements: tuple[str, ...]
    layer_templates: tuple[str, ...]

    @property
    def is_empty(self) -> bool:
        return not self.template_replacements and not self.layer_templates


EMPTY_CONTRACT = EnvironmentContract(template_replacements=(), layer_templates=())


def ensure_mapping(value: object, field: str, path: Path, index: int) -> Mapping[str, object]:
    if isinstance(value, Mapping):
        generic_mapping = cast(Mapping[Any, object], value)
        for key in generic_mapping.keys():
            if not isinstance(key, str):
                raise ValueError(
                    f"{field} keys must be strings (path={path}, document={index}, key={key})",
                )
        return cast(Mapping[str, object], generic_mapping)
    raise ValueError(f"{field} must be a mapping (path={path}, document={index})")


def require_string(value: object, field: str, path: Path, index: int) -> str:
    if isinstance(value, str) and value:
        return value
    raise ValueError(f"{field} must be a non-empty string (path={path}, document={index})")


def collect_strings(
    value: object,
    field: str,
    path: Path,
    index: int,
    *,
    minimum_items: int | None = None,
) -> tuple[str, ...]:
    if value is None:
        if minimum_items:
            raise ValueError(
                f"{field} must contain at least {minimum_items} entries (path={path}, document={index})",
            )
        return tuple()
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        raise ValueError(f"{field} must be an array of strings (path={path}, document={index})")

    items: list[str] = []
    for raw in cast(Sequence[object], value):
        if isinstance(raw, str) and raw:
            items.append(raw)
        else:
            raise ValueError(
                f"{field} entries must be non-empty strings (path={path}, document={index})",
            )
    if minimum_items and len(items) < minimum_items:
        raise ValueError(
            f"{field} must contain at least {minimum_items} entries (path={path}, document={index})",
        )
    return tuple(items)


def collect_string_mapping(
    value: object,
    field: str,
    path: Path,
    index: int,
) -> tuple[tuple[str, str], ...]:
    if value is None:
        return tuple()
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping (path={path}, document={index})")
    typed_value = cast(Mapping[Any, object], value)
    items: list[tuple[str, str]] = []
    for key, raw in typed_value.items():
        if not isinstance(key, str) or not key:
            raise ValueError(
                f"{field} keys must be non-empty strings (path={path}, document={index})",
            )
        if not isinstance(raw, str):
            raise ValueError(f"{field} values must be strings (path={path}, document={index})")
        items.append((key, raw))
    items.sort(key=lambda pair: pair[0])
    return tuple(items)


def parse_environment_contract(
    value: object,
    path: Path,
    index: int,
) -> EnvironmentContract:
    """Parse an ``environmentContract`` block from a plugin spec.

    Returns :data:`EMPTY_CONTRACT` when *value* is ``None``.
    """
    if value is None:
        return EMPTY_CONTRACT

    mapping = ensure_mapping(value, "spec.environmentContract", path, index)

    template_replacements = collect_strings(
        mapping.get("templateReplacements"),
        "spec.environmentContract.templateReplacements",
        path,
        index,
    )
    layer_templates = collect_strings(
        mapping.get("layerTemplates"),
        "spec.environmentContract.layerTemplates",
        path,
        index,
    )

    return EnvironmentContract(
        template_replacements=template_replacements,
        layer_templates=layer_templates,
    )
