"""Filesystem-backed loader for CICD workflow and job templates."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Sequence, cast

import yaml
from loguru import logger

from ...taxonomy.discovery.filesystem import (
    ByKindStrategy,
    CompositeDiscoveryStrategy,
    DiscoveryStrategy,
    RecursiveStrategy,
    SingleFileStrategy,
)
from ...taxonomy.ignore import IGNOREFILE_NAME, load_ignore
from .._helpers import collect_strings, ensure_mapping, parse_environment_contract, require_string
from ..models import PluginDocumentError
from .models import (
    CICD_API_VERSION,
    JOB_KIND,
    STAGE_KIND,
    WORKFLOW_KIND,
    CICDPluginResult,
    JobTemplateDefinition,
    StageDefinition,
    TemplateReference,
    TemplateRenderer,
    WorkflowJob,
    WorkflowParameter,
    WorkflowTemplateDefinition,
)

_DEFAULT_SENTINEL: object = object()


def load_cicd_templates(
    base_path: Path,
    *,
    strategy: DiscoveryStrategy | None = None,
) -> CICDPluginResult:
    """Load CICD workflow and job templates from ``base_path``."""

    discovery = strategy or CompositeDiscoveryStrategy(
        strategies=(SingleFileStrategy(), ByKindStrategy(), RecursiveStrategy()),
    )
    candidates = _discover_candidate_files(base_path, discovery)
    ignore = load_ignore(base_path)

    workflows: list[WorkflowTemplateDefinition] = []
    jobs: list[JobTemplateDefinition] = []
    stages: list[StageDefinition] = []
    errors: list[PluginDocumentError] = []

    for path in candidates:
        if ignore and ignore.should_ignore(path, is_dir=path.is_dir()):
            logger.debug("Skipping ignored CICD plugin path {}", path)
            continue
        if not path.is_file():
            continue
        errors.extend(_parse_documents(path, workflows, jobs, stages, base_path))

    stage_names = {stage.name for stage in stages}
    for stage in stages:
        for dependency in stage.depends_on:
            if dependency not in stage_names:
                errors.append(
                    PluginDocumentError(
                        path=stage.path,
                        document_index=stage.document_index,
                        message=f"Stage '{stage.name}' depends on undefined stage '{dependency}'.",
                    ),
                )

    jobs_by_layer_stage: dict[tuple[str, str], JobTemplateDefinition] = {}
    for job in jobs:
        if stage_names and job.stage not in stage_names:
            errors.append(
                PluginDocumentError(
                    path=job.path,
                    document_index=job.document_index,
                    message=f"JobTemplate '{job.name}' references unknown stage '{job.stage}'.",
                ),
            )
        key = (job.layer_type, job.stage)
        if key in jobs_by_layer_stage:
            errors.append(
                PluginDocumentError(
                    path=job.path,
                    document_index=job.document_index,
                    message=(
                        f"Duplicate JobTemplate for layerType '{job.layer_type}' "
                        f"and stage '{job.stage}' (existing={jobs_by_layer_stage[key].name})."
                    ),
                ),
            )
        else:
            jobs_by_layer_stage[key] = job

    workflows_by_name: dict[str, WorkflowTemplateDefinition] = {
        workflow.name: workflow for workflow in workflows
    }
    jobs_by_name: dict[str, JobTemplateDefinition] = {job.name: job for job in jobs}
    stages_by_name: dict[str, StageDefinition] = {stage.name: stage for stage in stages}

    logger.info(
        "Loaded CICD plugin data: {} workflows, {} jobs, {} stages",
        len(workflows),
        len(jobs),
        len(stages),
    )

    return CICDPluginResult(
        workflows=tuple(workflows),
        jobs=tuple(jobs),
        stages=tuple(stages),
        errors=tuple(errors),
        _workflows_by_name=workflows_by_name,
        _jobs_by_name=jobs_by_name,
        _stages_by_name=stages_by_name,
        _jobs_by_layer_stage=jobs_by_layer_stage,
    )


def _discover_candidate_files(base_path: Path, strategy: DiscoveryStrategy) -> tuple[Path, ...]:
    if not base_path.exists():
        return tuple()

    seen: set[Path] = set()
    discovered: list[Path] = []
    for path in strategy.discover(base_path):
        if path.name == IGNOREFILE_NAME:
            continue
        absolute = path.resolve()
        if absolute in seen:
            continue
        seen.add(absolute)
        discovered.append(path)
    discovered.sort(key=lambda item: (len(item.parts), str(item)))
    return tuple(discovered)


def _parse_documents(
    path: Path,
    workflows: list[WorkflowTemplateDefinition],
    jobs: list[JobTemplateDefinition],
    stages: list[StageDefinition],
    base_path: Path,
) -> tuple[PluginDocumentError, ...]:
    errors: list[PluginDocumentError] = []
    try:
        with path.open("r", encoding="utf-8") as stream:
            for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                if not document:
                    continue
                if not isinstance(document, Mapping):
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message="Plugin document must be a mapping",
                        ),
                    )
                    continue
                document_mapping = cast(Mapping[str, object], document)
                api_version = document_mapping.get("apiVersion")
                if not isinstance(api_version, str) or api_version != CICD_API_VERSION:
                    continue
                kind = document_mapping.get("kind")
                if not isinstance(kind, str):
                    continue
                try:
                    if kind == WORKFLOW_KIND:
                        workflows.append(
                            _build_workflow_definition(document_mapping, path, index, base_path),
                        )
                    elif kind == JOB_KIND:
                        jobs.append(_build_job_definition(document_mapping, path, index, base_path))
                    elif kind == STAGE_KIND:
                        stages.append(_build_stage_definition(document_mapping, path, index))
                    else:
                        errors.append(
                            PluginDocumentError(
                                path=path,
                                document_index=index,
                                message=f"Unsupported CICD plugin kind: {kind}",
                            ),
                        )
                except ValueError as exc:
                    logger.warning("CICD plugin parse error in {}: {}", path, exc)
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message=str(exc),
                        ),
                    )
    except yaml.YAMLError as exc:
        logger.warning("CICD plugin YAML error in {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))
    except OSError as exc:
        logger.warning("Failed to open CICD plugin file {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))
    return tuple(errors)


def _build_stage_definition(
    document: Mapping[str, object],
    path: Path,
    index: int,
) -> StageDefinition:
    metadata = ensure_mapping(document.get("metadata"), "metadata", path, index)
    spec = ensure_mapping(document.get("spec"), "spec", path, index)

    name = require_string(metadata.get("name"), "metadata.name", path, index)
    description = _coerce_optional_string(spec.get("description"), "spec.description", path, index)
    depends_on = collect_strings(
        spec.get("dependsOn"),
        "spec.dependsOn",
        path,
        index,
    )

    return StageDefinition(
        name=name,
        description=description,
        depends_on=depends_on,
        path=path,
        document_index=index,
    )


def _build_workflow_definition(
    document: Mapping[str, object],
    path: Path,
    index: int,
    base_path: Path,
) -> WorkflowTemplateDefinition:
    metadata = ensure_mapping(document.get("metadata"), "metadata", path, index)
    spec = ensure_mapping(document.get("spec"), "spec", path, index)

    name = require_string(metadata.get("name"), "metadata.name", path, index)
    description = _coerce_optional_string(spec.get("description"), "spec.description", path, index)

    template = _build_template_reference(
        spec.get("template"),
        "spec.template",
        path,
        index,
        base_path,
    )

    parameters = _parse_parameters(spec.get("parameters"), path, index)
    jobs = _parse_workflow_jobs(spec.get("jobs"), path, index)

    return WorkflowTemplateDefinition(
        name=name,
        description=description,
        template=template,
        parameters=parameters,
        jobs=jobs,
        path=path,
        document_index=index,
    )


def _build_job_definition(
    document: Mapping[str, object],
    path: Path,
    index: int,
    base_path: Path,
) -> JobTemplateDefinition:
    metadata = ensure_mapping(document.get("metadata"), "metadata", path, index)
    spec = ensure_mapping(document.get("spec"), "spec", path, index)

    name = require_string(metadata.get("name"), "metadata.name", path, index)
    description = _coerce_optional_string(spec.get("description"), "spec.description", path, index)
    stage = require_string(spec.get("stage"), "spec.stage", path, index)
    layer_type = require_string(spec.get("layerType"), "spec.layerType", path, index)

    template = _build_template_reference(
        spec.get("template"),
        "spec.template",
        path,
        index,
        base_path,
    )

    inputs_section = spec.get("inputs")
    required_inputs: tuple[str, ...] = tuple()
    default_inputs: tuple[tuple[str, Any], ...] = tuple()
    if inputs_section is not None:
        inputs = ensure_mapping(inputs_section, "spec.inputs", path, index)
        required_inputs = collect_strings(
            inputs.get("required"),
            "spec.inputs.required",
            path,
            index,
        )
        default_inputs = _collect_value_mapping(
            inputs.get("defaults"),
            "spec.inputs.defaults",
            path,
            index,
        )

    artifacts_section = spec.get("artifacts")
    produces: tuple[str, ...] = tuple()
    consumes: tuple[str, ...] = tuple()
    if artifacts_section is not None:
        artifacts = ensure_mapping(artifacts_section, "spec.artifacts", path, index)
        produces = collect_strings(
            artifacts.get("produces"),
            "spec.artifacts.produces",
            path,
            index,
        )
        consumes = collect_strings(
            artifacts.get("consumes"),
            "spec.artifacts.consumes",
            path,
            index,
        )

    environment_contract = parse_environment_contract(
        spec.get("environmentContract"),
        path,
        index,
    )

    return JobTemplateDefinition(
        name=name,
        description=description,
        stage=stage,
        layer_type=layer_type,
        template=template,
        required_inputs=required_inputs,
        default_inputs=default_inputs,
        produces=produces,
        consumes=consumes,
        path=path,
        document_index=index,
        environment_contract=environment_contract,
    )


def _build_template_reference(
    config: object,
    field: str,
    path: Path,
    index: int,
    base_path: Path,
) -> TemplateReference:
    config_mapping = ensure_mapping(config, field, path, index)
    template_path_value = require_string(config_mapping.get("path"), f"{field}.path", path, index)
    renderer = ensure_mapping(config_mapping.get("renderer"), f"{field}.renderer", path, index)

    renderer_type = require_string(renderer.get("type"), f"{field}.renderer.type", path, index)
    strict_raw = renderer.get("strictUndefined")
    if strict_raw is None:
        strict = False
    elif isinstance(strict_raw, bool):
        strict = strict_raw
    else:
        raise ValueError(
            f"{field}.renderer.strictUndefined must be a boolean (path={path}, document={index})",
        )

    template_path = _resolve_template_path(
        template_path_value,
        document_path=path,
        base_path=base_path,
        index=index,
        field=field,
    )

    return TemplateReference(
        path=template_path,
        renderer=TemplateRenderer(type=renderer_type, strict_undefined=strict),
    )


def _parse_parameters(
    raw_parameters: object,
    path: Path,
    index: int,
) -> tuple[WorkflowParameter, ...]:
    if raw_parameters is None:
        return tuple()
    mapping = ensure_mapping(raw_parameters, "spec.parameters", path, index)
    parameters: list[WorkflowParameter] = []
    for name, raw in mapping.items():
        if not name:
            raise ValueError(
                f"spec.parameters keys must be non-empty strings (path={path}, document={index})",
            )
        config = ensure_mapping(raw, f"spec.parameters.{name}", path, index)
        description = _coerce_optional_string(
            config.get("description"),
            f"spec.parameters.{name}.description",
            path,
            index,
        )
        value_type = _coerce_optional_string(
            config.get("type"),
            f"spec.parameters.{name}.type",
            path,
            index,
        )
        required_raw = config.get("required")
        if required_raw is None:
            required = True
        elif isinstance(required_raw, bool):
            required = required_raw
        else:
            raise ValueError(
                f"spec.parameters.{name}.required must be a boolean (path={path}, document={index})",
            )
        default_token = config.get("default", _DEFAULT_SENTINEL)
        if default_token is _DEFAULT_SENTINEL:
            default_value = None
            has_default = False
        else:
            default_value = default_token
            has_default = True
        parameters.append(
            WorkflowParameter(
                name=name,
                description=description,
                value_type=value_type,
                required=required,
                default=default_value,
                has_default=has_default,
            ),
        )
    parameters.sort(key=lambda param: param.name)
    return tuple(parameters)


def _parse_workflow_jobs(
    raw_jobs: object,
    path: Path,
    index: int,
) -> tuple[WorkflowJob, ...]:
    if raw_jobs is None:
        raise ValueError(f"spec.jobs is required (path={path}, document={index})")
    if not isinstance(raw_jobs, Sequence) or isinstance(raw_jobs, (str, bytes, bytearray)):
        raise ValueError(f"spec.jobs must be an array (path={path}, document={index})")

    job_entries = cast(Sequence[object], raw_jobs)
    jobs: list[WorkflowJob] = []
    for position, raw in enumerate(job_entries, start=1):
        job = ensure_mapping(raw, f"spec.jobs[{position}]", path, index)
        name = require_string(job.get("name"), f"spec.jobs[{position}].name", path, index)
        template_ref = require_string(
            job.get("templateRef"),
            f"spec.jobs[{position}].templateRef",
            path,
            index,
        )
        with_arguments = _collect_value_mapping(
            job.get("with"),
            f"spec.jobs[{position}].with",
            path,
            index,
        )
        needs = collect_strings(
            job.get("needs"),
            f"spec.jobs[{position}].needs",
            path,
            index,
        )
        jobs.append(
            WorkflowJob(
                name=name,
                template_ref=template_ref,
                with_arguments=with_arguments,
                needs=needs,
            ),
        )
    return tuple(jobs)


def _collect_value_mapping(
    value: object,
    field: str,
    path: Path,
    index: int,
) -> tuple[tuple[str, Any], ...]:
    if value is None:
        return tuple()
    mapping = ensure_mapping(value, field, path, index)
    entries: list[tuple[str, Any]] = []
    for key, item in mapping.items():
        if not key:
            raise ValueError(
                f"{field} keys must be non-empty strings (path={path}, document={index})",
            )
        entries.append((key, item))
    return tuple(entries)


def _resolve_template_path(
    template_value: str,
    *,
    document_path: Path,
    base_path: Path,
    index: int,
    field: str,
) -> Path:
    template_path = Path(template_value)
    candidates: list[Path] = []
    if template_path.is_absolute():
        candidates.append(template_path)
    else:
        candidates.extend(
            [
                (document_path.parent / template_path),
                (base_path / template_path),
                (base_path / ".global" / "taxonomy" / "cicd" / template_path),
            ],
        )

    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate.resolve()

    raise ValueError(
        f"{field}.path references '{template_value}' which does not exist "
        f"(path={document_path}, document={index})",
    )


def _coerce_optional_string(
    value: object,
    field: str,
    path: Path,
    index: int,
) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    raise ValueError(f"{field} must be a string if provided (path={path}, document={index})")
