"""Data models for CICD workflow and job templates."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .._helpers import EnvironmentContract
from ..models import PluginDocumentError

CICD_API_VERSION = "katalyst.taxonomy.plugins.cicd/v1alpha"
WORKFLOW_KIND = "WorkflowTemplate"
JOB_KIND = "JobTemplate"
STAGE_KIND = "Stage"


@dataclass(frozen=True, slots=True)
class TemplateRenderer:
    """Renderer configuration for a CICD template."""

    type: str
    strict_undefined: bool


@dataclass(frozen=True, slots=True)
class TemplateReference:
    """Concrete template location and renderer metadata."""

    path: Path
    renderer: TemplateRenderer


@dataclass(frozen=True, slots=True)
class WorkflowParameter:
    """Declarative description of workflow parameters."""

    name: str
    description: str | None
    value_type: str | None
    required: bool
    default: Any
    has_default: bool


@dataclass(frozen=True, slots=True)
class WorkflowJob:
    """Workflow job definition referencing a job template."""

    name: str
    template_ref: str
    with_arguments: tuple[tuple[str, Any], ...]
    needs: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class WorkflowTemplateDefinition:
    """Parsed workflow template manifest."""

    name: str
    description: str | None
    template: TemplateReference
    parameters: tuple[WorkflowParameter, ...]
    jobs: tuple[WorkflowJob, ...]
    path: Path
    document_index: int


@dataclass(frozen=True, slots=True)
class JobTemplateDefinition:
    """Parsed job template manifest."""

    name: str
    description: str | None
    stage: str
    layer_type: str
    template: TemplateReference
    required_inputs: tuple[str, ...]
    default_inputs: tuple[tuple[str, Any], ...]
    produces: tuple[str, ...]
    consumes: tuple[str, ...]
    path: Path
    document_index: int
    environment_contract: EnvironmentContract


@dataclass(frozen=True, slots=True)
class StageDefinition:
    """Declared CICD stage with optional dependencies."""

    name: str
    description: str | None
    depends_on: tuple[str, ...]
    path: Path
    document_index: int


@dataclass(frozen=True, slots=True)
class CICDPluginResult:
    """Aggregated view of workflow and job templates."""

    workflows: tuple[WorkflowTemplateDefinition, ...]
    jobs: tuple[JobTemplateDefinition, ...]
    stages: tuple[StageDefinition, ...]
    errors: tuple[PluginDocumentError, ...]
    _workflows_by_name: dict[str, WorkflowTemplateDefinition]
    _jobs_by_name: dict[str, JobTemplateDefinition]
    _stages_by_name: dict[str, StageDefinition]
    _jobs_by_layer_stage: dict[tuple[str, str], JobTemplateDefinition]

    def workflow(self, name: str) -> WorkflowTemplateDefinition | None:
        return self._workflows_by_name.get(name)

    def job(self, name: str) -> JobTemplateDefinition | None:
        return self._jobs_by_name.get(name)

    def stage(self, name: str) -> StageDefinition | None:
        return self._stages_by_name.get(name)

    def job_for_stage(self, *, layer_type: str, stage: str) -> JobTemplateDefinition | None:
        return self._jobs_by_layer_stage.get((layer_type, stage))
