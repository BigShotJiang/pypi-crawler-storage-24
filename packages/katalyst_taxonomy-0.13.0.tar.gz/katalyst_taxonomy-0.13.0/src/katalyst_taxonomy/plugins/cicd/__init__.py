"""CICD plugin for workflow and job template management.

This package provides the CICD plugin functionality for loading and managing
workflow and job templates in the katalyst taxonomy.
"""

from .loader import load_cicd_templates
from .models import (
    CICD_API_VERSION,
    JOB_KIND,
    STAGE_KIND,
    WORKFLOW_KIND,
    CICDPluginResult,
    JobTemplateDefinition,
    StageDefinition,
    TemplateReference,
    TemplateRenderer,
    WorkflowJob,
    WorkflowParameter,
    WorkflowTemplateDefinition,
)

__all__ = [
    # Constants
    "CICD_API_VERSION",
    "JOB_KIND",
    "STAGE_KIND",
    "WORKFLOW_KIND",
    # Models
    "CICDPluginResult",
    "JobTemplateDefinition",
    "StageDefinition",
    "TemplateReference",
    "TemplateRenderer",
    "WorkflowJob",
    "WorkflowParameter",
    "WorkflowTemplateDefinition",
    # Loader
    "load_cicd_templates",
]
