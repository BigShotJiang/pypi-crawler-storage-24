"""Common plugin models."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, Mapping, Sequence, cast

__all__ = [
    "REQUIREMENT_MODES",
    "PluginDocumentError",
    "PluginRequirement",
    "RequirementMode",
    "parse_requirements",
]

# Valid modes for plugin requirements
RequirementMode = Literal["required", "optional", "conditional"]
REQUIREMENT_MODES: tuple[str, ...] = ("required", "optional", "conditional")


@dataclass(frozen=True, slots=True)
class PluginDocumentError:
    """Represents a failure encountered while parsing a plugin document."""

    path: Path
    document_index: int
    message: str


@dataclass(frozen=True, slots=True)
class PluginRequirement:
    """Represents a dependency on another plugin.

    Plugins can declare requirements on other plugins using the `requires` field
    in their metadata. This dataclass captures a single such requirement.

    Attributes:
        api_version: The apiVersion of the required plugin (e.g., "katalyst.taxonomy.plugins.capabilities/v1alpha")
        kind: The kind of the required plugin (e.g., "Capability")
        name: The name of the required plugin (from metadata.name)
        optional: If True, a missing dependency produces a warning rather than an error (legacy field)
        source: Optional path hint for direct resolution (bypasses index lookup)
        mode: Dependency mode - "required" (error if missing), "optional" (warn if missing),
              or "conditional" (silently skip if missing)
    """

    api_version: str
    kind: str
    name: str
    optional: bool
    source: str | None
    mode: RequirementMode

    @property
    def key(self) -> tuple[str, str, str]:
        """Return the unique key tuple (apiVersion, kind, name) for index lookups."""
        return (self.api_version, self.kind, self.name)

    @property
    def is_conditional(self) -> bool:
        """Return True if this is a conditional dependency."""
        return self.mode == "conditional"


def parse_requirements(
    value: object,
    path: Path,
    index: int,
) -> tuple[PluginRequirement, ...]:
    """Parse the `requires` field from plugin metadata.

    Args:
        value: The raw value from metadata.requires (expected to be a list of mappings)
        path: The path to the plugin file (for error messages)
        index: The document index within the file (for error messages)

    Returns:
        A tuple of PluginRequirement instances

    Raises:
        ValueError: If the value is malformed
    """
    if value is None:
        return ()

    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        raise ValueError(f"metadata.requires must be a list (path={path}, document={index})")

    requirements: list[PluginRequirement] = []
    raw_list = cast(Sequence[object], value)

    for req_index, raw_req in enumerate(raw_list, start=1):
        if not isinstance(raw_req, Mapping):
            raise ValueError(
                f"metadata.requires[{req_index}] must be a mapping (path={path}, document={index})"
            )

        req_mapping = cast(Mapping[str, Any], raw_req)

        # Required fields
        api_version = req_mapping.get("apiVersion")
        if not isinstance(api_version, str) or not api_version:
            raise ValueError(
                f"metadata.requires[{req_index}].apiVersion must be a non-empty string "
                f"(path={path}, document={index})"
            )

        kind = req_mapping.get("kind")
        if not isinstance(kind, str) or not kind:
            raise ValueError(
                f"metadata.requires[{req_index}].kind must be a non-empty string "
                f"(path={path}, document={index})"
            )

        name = req_mapping.get("name")
        if not isinstance(name, str) or not name:
            raise ValueError(
                f"metadata.requires[{req_index}].name must be a non-empty string "
                f"(path={path}, document={index})"
            )

        # Optional fields
        optional_raw = req_mapping.get("optional", False)
        if not isinstance(optional_raw, bool):
            raise ValueError(
                f"metadata.requires[{req_index}].optional must be a boolean "
                f"(path={path}, document={index})"
            )

        source_raw = req_mapping.get("source")
        source: str | None = None
        if source_raw is not None:
            if not isinstance(source_raw, str) or not source_raw:
                raise ValueError(
                    f"metadata.requires[{req_index}].source must be a non-empty string "
                    f"(path={path}, document={index})"
                )
            source = source_raw

        # Mode field - determines behavior when dependency is missing
        mode_raw = req_mapping.get("mode")
        mode: RequirementMode

        if mode_raw is not None:
            if not isinstance(mode_raw, str) or mode_raw not in REQUIREMENT_MODES:
                raise ValueError(
                    f"metadata.requires[{req_index}].mode must be one of {REQUIREMENT_MODES} "
                    f"(path={path}, document={index})"
                )
            mode = cast(RequirementMode, mode_raw)
            # Sync optional field for backwards compatibility
            if mode == "optional":
                optional_raw = True
        elif optional_raw:
            # Legacy: if optional=True but no mode, default to "optional"
            mode = "optional"
        else:
            # Default mode
            mode = "required"

        requirements.append(
            PluginRequirement(
                api_version=api_version,
                kind=kind,
                name=name,
                optional=optional_raw,
                source=source,
                mode=mode,
            )
        )

    return tuple(requirements)
