"""Scaffolding support with extension merging.

This module provides functionality to create scaffolding plans that merge
base layer type templates with active extension templates.

The scaffolding plan describes:
1. The base layer type template to copy
2. Active extensions with their file contributions
3. The order in which files should be copied/merged
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .activation import resolve_active_extensions
from .extensions import Extension, ExtensionsPluginResult, load_extensions
from .index import PluginIndex, build_plugin_index
from .layer_types import LAYER_TYPE_KIND, LAYER_TYPES_API_VERSION

__all__ = [
    "ExtensionContribution",
    "ScaffoldingPlan",
    "resolve_scaffolding_plan",
]


@dataclass(frozen=True, slots=True)
class ExtensionContribution:
    """Describes files contributed by an extension.

    Attributes:
        extension_name: Name of the contributing extension
        extension_path: Path to the extension definition file
        template_path: Path to template directory (if using template mode)
        files: Explicit file mappings (source, destination) if specified
    """

    extension_name: str
    extension_path: Path
    template_path: Path | None
    files: tuple[tuple[str, str], ...]


@dataclass(frozen=True, slots=True)
class ScaffoldingPlan:
    """A plan for scaffolding a layer with extensions.

    The plan specifies the base template and any active extension
    contributions to be merged.

    Attributes:
        layer_type_name: Name of the layer type being scaffolded
        base_template_path: Path to the base layer type template
        extensions: Active extension contributions in order
        inactive_extensions: Names of extensions that were not activated
    """

    layer_type_name: str
    base_template_path: Path
    extensions: tuple[ExtensionContribution, ...]
    inactive_extensions: tuple[str, ...]

    @property
    def has_extensions(self) -> bool:
        """Return True if there are active extensions."""
        return len(self.extensions) > 0

    @property
    def extension_names(self) -> tuple[str, ...]:
        """Return names of all active extensions."""
        return tuple(ext.extension_name for ext in self.extensions)


def resolve_scaffolding_plan(
    layer_type_name: str,
    base_template_path: Path,
    plugins_path: Path,
    *,
    index: PluginIndex | None = None,
    extensions_result: ExtensionsPluginResult | None = None,
) -> ScaffoldingPlan:
    """Resolve a scaffolding plan for a layer type.

    This function determines which extensions should be activated for the
    given layer type and builds a plan describing all template sources.

    Args:
        layer_type_name: Name of the layer type being scaffolded
        base_template_path: Path to the base layer type template directory
        plugins_path: Path to the plugins directory (for loading index/extensions)
        index: Optional pre-built plugin index (for testing)
        extensions_result: Optional pre-loaded extensions (for testing)

    Returns:
        ScaffoldingPlan with base template and active extension contributions
    """
    # Build or use provided plugin index
    if index is None:
        index = _build_index_from_path(plugins_path)

    # Load or use provided extensions
    if extensions_result is None:
        extensions_result = load_extensions(plugins_path)

    # Resolve active extensions for this layer type
    activation_result = resolve_active_extensions(
        extensions=extensions_result.extensions,
        index=index,
        target_api_version=LAYER_TYPES_API_VERSION,
        target_kind=LAYER_TYPE_KIND,
        target_name=layer_type_name,
    )

    # Build extension contributions
    contributions = tuple(
        _build_contribution(ext, plugins_path) for ext in activation_result.active
    )

    return ScaffoldingPlan(
        layer_type_name=layer_type_name,
        base_template_path=base_template_path,
        extensions=contributions,
        inactive_extensions=activation_result.inactive_names,
    )


def _build_index_from_path(plugins_path: Path) -> PluginIndex:
    """Build a plugin index from a plugins directory.

    Files nested inside ``layer_types/<name>/`` subdirectories are skipped
    because they are Jinja2 templates containing placeholders such as
    ``{{ layer_name }}`` which are not valid YAML.
    """
    if not plugins_path.exists():
        return PluginIndex(entries=(), _by_key={})

    # Directories whose *subdirectories* contain Jinja2 templates, not
    # plugin documents.  Files directly inside these directories (depth 1)
    # are still scanned.
    _TEMPLATE_PARENTS = {"layer_types"}

    yaml_files: list[Path] = []
    for pattern in ("**/*.yaml", "**/*.yml"):
        for path in plugins_path.glob(pattern):
            try:
                rel = path.relative_to(plugins_path)
            except ValueError:
                continue
            parts = rel.parts
            # Skip files at depth >=3 under a template parent directory,
            # e.g. layer_types/app-docker/layer.yaml (depth 3).
            if len(parts) >= 3 and parts[0] in _TEMPLATE_PARENTS:
                continue
            yaml_files.append(path)

    index, _ = build_plugin_index(yaml_files)
    return index


def _build_contribution(ext: Extension, plugins_path: Path) -> ExtensionContribution:
    """Build an ExtensionContribution from an Extension."""
    # Resolve template path relative to extension file location
    template_path: Path | None = None
    if ext.provides.template:
        # Template path is relative to the extension file's directory
        template_path = ext.path.parent / ext.provides.template
        # If not found there, try relative to plugins_path
        if not template_path.exists():
            template_path = plugins_path / ext.provides.template

    return ExtensionContribution(
        extension_name=ext.name,
        extension_path=ext.path,
        template_path=template_path,
        files=ext.provides.files,
    )
