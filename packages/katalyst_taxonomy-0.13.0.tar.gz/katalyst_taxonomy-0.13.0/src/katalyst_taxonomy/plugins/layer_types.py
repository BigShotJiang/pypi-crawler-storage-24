"""Filesystem-backed loader for layer type plugin documents."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence, cast

import yaml
from loguru import logger

from ..taxonomy.discovery.filesystem import (
    DiscoveryStrategy,
    SingleFileStrategy,
)
from ..taxonomy.ignore import IGNOREFILE_NAME, load_ignore
from ._helpers import (
    EnvironmentContract,
    ensure_mapping,
    parse_environment_contract,
    require_string,
)
from .models import PluginDocumentError

LAYER_TYPES_API_VERSION = "katalyst.taxonomy.plugins.layer_types/v1alpha"
LAYER_TYPE_KIND = "LayerType"


@dataclass(frozen=True, slots=True)
class LayerTypeDefinition:
    """Concrete definition of a layer type template."""

    name: str
    description: str | None
    template_path: Path
    default_layer_dir: str
    path: Path
    document_index: int
    optional_paths: tuple[str, ...]
    environment_contract: EnvironmentContract
    global_template_path: Path | None = None


@dataclass(frozen=True, slots=True)
class LayerTypesPluginResult:
    """Aggregated view of available layer types."""

    definitions: tuple[LayerTypeDefinition, ...]
    errors: tuple[PluginDocumentError, ...]
    _definitions_by_name: dict[str, LayerTypeDefinition]

    def definition(self, name: str) -> LayerTypeDefinition | None:
        return self._definitions_by_name.get(name)


def load_layer_types(
    base_path: Path,
    *,
    strategy: DiscoveryStrategy | None = None,
) -> LayerTypesPluginResult:
    """Load layer type plugin definitions from ``base_path``."""

    # Use SingleFileStrategy by default – layer type plugin definitions
    # live as top-level YAML files in the base path, **not** inside the
    # template subdirectories which contain Jinja2 placeholders that are
    # not valid YAML (e.g. ``{{ layer_name }}``).  RecursiveStrategy would
    # descend into those template directories and trigger YAML parse errors.
    discovery = strategy or SingleFileStrategy()

    candidates = _discover_candidate_files(base_path, discovery)
    ignore = load_ignore(base_path)

    definitions: list[LayerTypeDefinition] = []
    errors: list[PluginDocumentError] = []

    for path in candidates:
        if ignore and ignore.should_ignore(path, is_dir=path.is_dir()):
            logger.debug("Layer types plugin ignoring path {} due to .taxignore rules", path)
            continue
        if not path.is_file():
            continue

        errors.extend(_parse_layer_type_documents(path, definitions, base_path))

    definition_index: dict[str, LayerTypeDefinition] = {}
    for definition in definitions:
        definition_index[definition.name] = definition

    logger.info(
        "Loaded layer types plugin data: {} definitions, {} errors",
        len(definitions),
        len(errors),
    )

    return LayerTypesPluginResult(
        definitions=tuple(definitions),
        errors=tuple(errors),
        _definitions_by_name=definition_index,
    )


def _discover_candidate_files(base_path: Path, strategy: DiscoveryStrategy) -> tuple[Path, ...]:
    if not base_path.exists():
        return tuple()

    seen: set[Path] = set()
    discovered: list[Path] = []
    for path in strategy.discover(base_path):
        if path.name == IGNOREFILE_NAME:
            continue
        absolute = path.resolve()
        if absolute in seen:
            continue
        seen.add(absolute)
        discovered.append(path)

    discovered.sort(key=lambda item: (len(item.parts), str(item)))
    return tuple(discovered)


def _parse_layer_type_documents(
    path: Path,
    definitions: list[LayerTypeDefinition],
    base_path: Path,
) -> tuple[PluginDocumentError, ...]:
    errors: list[PluginDocumentError] = []
    try:
        with path.open("r", encoding="utf-8") as stream:
            for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                if not document:
                    continue
                if not isinstance(document, Mapping):
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message="Plugin document must be a mapping",
                        ),
                    )
                    continue

                document_mapping = cast(Mapping[str, object], document)
                api_version = document_mapping.get("apiVersion")
                kind = document_mapping.get("kind")
                if (
                    not isinstance(api_version, str)
                    or not isinstance(kind, str)
                    or api_version != LAYER_TYPES_API_VERSION
                    or kind != LAYER_TYPE_KIND
                ):
                    continue

                try:
                    definitions.append(_build_definition(document_mapping, path, index, base_path))
                except ValueError as exc:
                    logger.warning("Layer types plugin parse error in {}: {}", path, exc)
                    errors.append(
                        PluginDocumentError(
                            path=path,
                            document_index=index,
                            message=str(exc),
                        ),
                    )
    except yaml.YAMLError as exc:
        logger.warning("Layer types plugin YAML error in {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))
    except OSError as exc:
        logger.warning("Failed to open layer types plugin file {}: {}", path, exc)
        errors.append(PluginDocumentError(path=path, document_index=0, message=str(exc)))

    return tuple(errors)


def _build_definition(
    document: Mapping[str, object],
    path: Path,
    index: int,
    base_path: Path,
) -> LayerTypeDefinition:
    metadata = ensure_mapping(document.get("metadata"), "metadata", path, index)
    spec = ensure_mapping(document.get("spec"), "spec", path, index)

    name = require_string(metadata.get("name"), "metadata.name", path, index)
    description_value = spec.get("description")
    if description_value is not None and not isinstance(description_value, str):
        raise ValueError(
            f"spec.description must be a string (path={path}, document={index})",
        )

    template_value = require_string(spec.get("template"), "spec.template", path, index)
    template_path = _resolve_template_path(template_value, path, base_path, index)
    optional_paths = _parse_optional_paths(spec.get("optionalPaths"), path, index)
    default_layer_dir = _parse_default_layer_dir(spec.get("defaultLayerDir"), path, index)
    environment_contract = parse_environment_contract(
        spec.get("environmentContract"),
        path,
        index,
    )

    # Optional: resolve globalTemplate path
    global_template_path = _resolve_global_template_path(
        spec.get("globalTemplate"),
        path,
        base_path,
        index,
    )

    return LayerTypeDefinition(
        name=name,
        description=description_value if isinstance(description_value, str) else None,
        template_path=template_path,
        default_layer_dir=default_layer_dir,
        path=path,
        document_index=index,
        optional_paths=optional_paths,
        environment_contract=environment_contract,
        global_template_path=global_template_path,
    )


def _parse_optional_paths(value: object, path: Path, index: int) -> tuple[str, ...]:
    if value is None:
        return tuple()
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        raise ValueError(
            f"spec.optionalPaths must be an array of strings (path={path}, document={index})",
        )
    paths: list[str] = []
    for item in value:  # type: ignore[union-attr]
        if not isinstance(item, str) or not item.strip():
            raise ValueError(
                f"spec.optionalPaths entries must be non-empty strings (path={path}, document={index})",
            )
        paths.append(item)
    return tuple(dict.fromkeys(paths))


def _parse_default_layer_dir(value: object, path: Path, index: int) -> str:
    directory = require_string(value, "spec.defaultLayerDir", path, index).strip()
    if not directory:
        raise ValueError(
            f"spec.defaultLayerDir must be a non-empty string (path={path}, document={index})",
        )
    if "/" in directory or "\\" in directory:
        raise ValueError(
            f"spec.defaultLayerDir must be a single directory segment (path={path}, document={index})",
        )
    return directory


def _resolve_template_path(
    template_value: str,
    document_path: Path,
    base_path: Path,
    index: int,
) -> Path:
    candidates = [
        (document_path.parent / template_value),
        (base_path / template_value),
    ]

    taxonomy_dir = base_path / ".global" / "taxonomy" / "layerTypes"
    if taxonomy_dir.exists():
        candidates.append(taxonomy_dir / template_value)

    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            return candidate

    raise ValueError(
        f"spec.template references '{template_value}' which does not exist "
        f"(path={document_path}, document={index})",
    )


def _resolve_global_template_path(
    value: object,
    document_path: Path,
    base_path: Path,
    index: int,
) -> Path | None:
    """Resolve the optional ``spec.globalTemplate`` path.

    Returns ``None`` if the field is absent or the directory does not
    exist (non-fatal -- global templates are best-effort).
    """
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        return None

    candidates = [
        document_path.parent / value,
        base_path / value,
    ]
    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            return candidate

    return None
