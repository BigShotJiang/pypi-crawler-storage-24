"""Katalyst Taxonomy - A taxonomy management system for software architecture."""

from katalyst_taxonomy.domain.errors import (
    DocumentError,
    KatalystError,
    ValidationError,
)
from katalyst_taxonomy.domain.events import Event, EventBus, EventType
from katalyst_taxonomy.ports.linting import (
    LintingService,
    LintResult,
    LintViolation,
)
from katalyst_taxonomy.ports.taxonomy import (
    CreationRequest,
    CreationResult,
    TaxonomyRepository,
    TaxonomyResult,
    TaxonomyWriter,
)
from katalyst_taxonomy.services.creation import CreationService
from katalyst_taxonomy.services.taxonomy import (
    TaxonomyService,
    build_qualified_names,
    document_lookup_key,
    qualified_name_for,
)
from katalyst_taxonomy.taxonomy.documents import (
    API_VERSION,
    KIND,
    TaxonomyDependencies,
    TaxonomyDocument,
    TaxonomyMetadata,
    TaxonomyParents,
    TaxonomySpec,
)
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

__version__ = "0.1.0"

__all__ = [
    # Version
    "__version__",
    # Constants
    "API_VERSION",
    "KIND",
    # Domain models
    "TaxonomyDocument",
    "TaxonomyMetadata",
    "TaxonomySpec",
    "TaxonomyParents",
    "TaxonomyDependencies",
    "EnvironmentDocument",
    # Events
    "Event",
    "EventType",
    "EventBus",
    # Errors
    "KatalystError",
    "ValidationError",
    "DocumentError",
    # Ports
    "TaxonomyRepository",
    "TaxonomyWriter",
    "TaxonomyResult",
    "CreationRequest",
    "CreationResult",
    "LintViolation",
    "LintResult",
    "LintingService",
    # Services
    "CreationService",
    "TaxonomyService",
    "build_qualified_names",
    "document_lookup_key",
    "qualified_name_for",
]
