"""Ports (interfaces) for linting operations."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol


@dataclass(frozen=True, slots=True)
class LintViolation:
    """Represents a single lint violation found in a taxonomy document."""

    path: Path
    document_index: int
    node_name: str
    node_type: str
    qualified_name: str
    message: str
    group_key: str
    group_label: str
    hint: str | None = None


@dataclass(frozen=True, slots=True)
class LintResult:
    """Result of linting taxonomy documents."""

    checked_documents: int
    violations: tuple[LintViolation, ...]
    schema_path: Path


class LintingService(Protocol):
    """Port for linting taxonomy documents."""

    def lint_taxonomy(self, path: Path) -> LintResult:
        """Lint taxonomy documents against schema."""
        ...
