"""Ports (interfaces) for Katalyst taxonomy operations."""

from katalyst_taxonomy.ports.linting import (
    LintingService,
    LintResult,
    LintViolation,
)
from katalyst_taxonomy.ports.taxonomy import (
    CreationRequest,
    CreationResult,
    TaxonomyRepository,
    TaxonomyResult,
    TaxonomyWriter,
)

__all__ = [
    # Taxonomy ports
    "TaxonomyRepository",
    "TaxonomyWriter",
    "TaxonomyResult",
    "CreationRequest",
    "CreationResult",
    # Linting ports
    "LintViolation",
    "LintResult",
    "LintingService",
]
