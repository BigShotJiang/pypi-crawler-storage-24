"""Unified filesystem port for service operations.

This module provides a protocol that unifies filesystem operations across
add, remove, clone, init, creation, and upgrade services.
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Mapping, Protocol, Sequence, runtime_checkable

from katalyst_taxonomy.templates.rendering import render_tokens


@runtime_checkable
class FilesystemPort(Protocol):
    """Protocol for filesystem operations used by services.

    This unified protocol combines methods needed by AddService, RemoveService,
    and CloneService, allowing a single adapter implementation.
    """

    def exists(self, path: Path) -> bool:
        """Check if a path exists."""
        ...

    def is_directory(self, path: Path) -> bool:
        """Check if a path is a directory."""
        ...

    def read_file(self, path: Path) -> str:
        """Read content from a file."""
        ...

    def write_file(self, path: Path, content: str) -> None:
        """Write content to a file, creating parent directories if needed."""
        ...

    def create_directory(self, path: Path) -> None:
        """Create a directory and any parent directories."""
        ...

    def copy_tree(self, src: Path, dest: Path) -> None:
        """Copy a directory tree, replacing destination if it exists."""
        ...

    def copy_tree_with_replacements(
        self,
        src: Path,
        dest: Path,
        replacements: list[tuple[str, str]],
    ) -> None:
        """Copy a directory tree with text replacements applied to paths and content."""
        ...

    def copy_tree_no_overwrite(
        self,
        src: Path,
        dest: Path,
    ) -> None:
        """Copy a directory tree, skipping files that already exist at the destination."""
        ...

    def remove_directory(self, path: Path) -> None:
        """Remove a directory and all its contents."""
        ...

    def list_directory(self, path: Path) -> list[Path]:
        """List contents of a directory."""
        ...

    def copy_file(self, src: Path, dest: Path) -> None:
        """Copy a single file verbatim (no rendering). Creates parent dirs."""
        ...

    def copy_tree_rendered(
        self,
        src: Path,
        dest: Path,
        context: Mapping[str, str],
        *,
        skip_names: frozenset[str] = frozenset(),
        skip_root_file: str | None = None,
    ) -> None:
        """Copy *src* into *dest*, rendering ``{{ key }}`` tokens in file content.

        Args:
            src: Source directory.
            dest: Destination directory (created if absent).
            context: Token → value mapping for ``{{ key }}`` substitution.
            skip_names: Top-level directory names to exclude entirely.
            skip_root_file: A single root-level filename to skip.
        """
        ...

    def copy_tree_rendered_per_env(
        self,
        src: Path,
        dest: Path,
        context: Mapping[str, str],
        environments: Sequence[str],
    ) -> None:
        """Copy *src* once per environment under ``dest/<env_name>/``.

        For each environment, the context is augmented with
        ``{"environment": env_name}`` before rendering ``{{ key }}`` tokens.

        Args:
            src: Source environment-template directory.
            dest: Parent layer directory. Each env gets ``dest/<env_name>/``.
            context: Base token → value mapping.
            environments: Ordered sequence of environment names.
        """
        ...


class RealFilesystem:
    """Real filesystem adapter implementing FilesystemPort.

    This adapter provides actual filesystem operations for production use.
    """

    def exists(self, path: Path) -> bool:
        """Check if a path exists."""
        return path.exists()

    def is_directory(self, path: Path) -> bool:
        """Check if a path is a directory."""
        return path.is_dir()

    def read_file(self, path: Path) -> str:
        """Read content from a file."""
        return path.read_text()

    def write_file(self, path: Path, content: str) -> None:
        """Write content to a file, creating parent directories if needed."""
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)

    def create_directory(self, path: Path) -> None:
        """Create a directory and any parent directories."""
        path.mkdir(parents=True, exist_ok=True)

    def copy_tree(self, src: Path, dest: Path) -> None:
        """Copy a directory tree, replacing destination if it exists."""
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(src, dest)

    def copy_tree_with_replacements(
        self,
        src: Path,
        dest: Path,
        replacements: list[tuple[str, str]],
    ) -> None:
        """Copy a directory tree with text replacements applied to paths and content."""
        for src_path in src.rglob("*"):
            # Compute relative path
            rel_path = src_path.relative_to(src)

            # Apply replacements to path parts
            rel_str = str(rel_path)
            for old, new in replacements:
                rel_str = rel_str.replace(old, new)

            dest_path = dest / rel_str

            if src_path.is_dir():
                dest_path.mkdir(parents=True, exist_ok=True)
            else:
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                try:
                    # Try to read as text and apply replacements
                    content = src_path.read_text()
                    for old, new in replacements:
                        content = content.replace(old, new)
                    dest_path.write_text(content)
                except UnicodeDecodeError:
                    # Binary file - copy as-is
                    shutil.copy2(src_path, dest_path)

    def copy_tree_no_overwrite(
        self,
        src: Path,
        dest: Path,
    ) -> None:
        """Copy a directory tree, skipping files that already exist at the destination."""
        for src_path in src.rglob("*"):
            rel_path = src_path.relative_to(src)
            dest_path = dest / rel_path

            if src_path.is_dir():
                dest_path.mkdir(parents=True, exist_ok=True)
            elif not dest_path.exists():
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_path, dest_path)

    def remove_directory(self, path: Path) -> None:
        """Remove a directory and all its contents."""
        if path.exists():
            shutil.rmtree(path)

    def list_directory(self, path: Path) -> list[Path]:
        """List contents of a directory."""
        if not path.exists():
            return []
        return list(path.iterdir())

    def copy_file(self, src: Path, dest: Path) -> None:
        """Copy a single file verbatim (no rendering). Creates parent dirs."""
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)

    def copy_tree_rendered(
        self,
        src: Path,
        dest: Path,
        context: Mapping[str, str],
        *,
        skip_names: frozenset[str] = frozenset(),
        skip_root_file: str | None = None,
    ) -> None:
        """Copy *src* into *dest*, rendering ``{{ key }}`` tokens in file content."""
        for src_path in src.rglob("*"):
            rel = src_path.relative_to(src)

            # Skip top-level directories in skip_names
            if rel.parts and rel.parts[0] in skip_names:
                continue

            # Skip a specific root-level file
            if skip_root_file and rel == Path(skip_root_file):
                continue

            dest_path = dest / rel

            if src_path.is_dir():
                dest_path.mkdir(parents=True, exist_ok=True)
            else:
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                try:
                    content = src_path.read_text()
                    dest_path.write_text(render_tokens(content, context))
                except UnicodeDecodeError:
                    shutil.copy2(src_path, dest_path)

    def copy_tree_rendered_per_env(
        self,
        src: Path,
        dest: Path,
        context: Mapping[str, str],
        environments: Sequence[str],
    ) -> None:
        """Copy *src* once per environment under ``dest/<env_name>/``."""
        for env_name in environments:
            env_context = {**context, "environment": env_name}
            env_dir = dest / env_name

            for src_path in src.rglob("*"):
                rel = src_path.relative_to(src)
                dest_path = env_dir / rel

                if src_path.is_dir():
                    dest_path.mkdir(parents=True, exist_ok=True)
                else:
                    dest_path.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        content = src_path.read_text()
                        dest_path.write_text(render_tokens(content, env_context))
                    except UnicodeDecodeError:
                        shutil.copy2(src_path, dest_path)
