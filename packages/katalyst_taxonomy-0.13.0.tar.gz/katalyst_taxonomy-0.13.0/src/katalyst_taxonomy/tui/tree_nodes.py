"""Data structures for taxonomy tree representation in the TUI."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from katalyst_taxonomy.taxonomy.documents import TaxonomyDocument

KIND_ORDER = (
    "organization",
    "program",
    "project",
    "team",
    "team_member",
    "user",
    "system",
    "subsystem",
    "stack",
    "layer",
)


@dataclass(frozen=True)
class TreeNode:
    """Represents a node within the taxonomy tree view."""

    label: str
    node_type: str
    document: TaxonomyDocument | None
    extra: Mapping[str, object]
    children: tuple[TreeNode, ...] = ()


@dataclass(frozen=True)
class NodeView(TreeNode):
    """Specialised tree node that always references a document."""

    document: TaxonomyDocument  # type: ignore[assignment]
    children: tuple[NodeView, ...] = ()
