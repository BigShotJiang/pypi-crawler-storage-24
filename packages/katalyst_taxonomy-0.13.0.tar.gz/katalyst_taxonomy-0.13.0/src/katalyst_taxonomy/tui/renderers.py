"""Detail panel rendering functions for the taxonomy TUI."""

# pyright: reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false
# pyright: reportArgumentType=false
# pyright: reportAttributeAccessIssue=false
# pyright: reportGeneralTypeIssues=false
# pyright: reportCallIssue=false

from __future__ import annotations

from typing import Sequence

from rich.text import Text

from katalyst_taxonomy.plugins.layer_actions import LayerAction

from .services import ActionRunOutcome
from .tree_nodes import NodeView, TreeNode


def render_taxonomy_details(node: NodeView) -> str:
    """Render details for a taxonomy document node."""
    render_lines = [
        f"[b]Name:[/b] {node.label}",
        f"[b]Type:[/b] {node.node_type}",
    ]
    if node.extra.get("fqtn"):
        render_lines.append(f"[b]FQTN:[/b] {node.extra['fqtn']}")
    path = node.extra.get("path")
    if path:
        render_lines.append(f"[b]Path:[/b] {path}")
    owners = ", ".join(node.document.spec.owners) or "-"
    render_lines.append(f"[b]Owners:[/b] {owners}")
    environments = ", ".join(node.document.spec.environments) or "-"
    render_lines.append(f"[b]Environments:[/b] {environments}")
    render_lines.append("")
    render_lines.append(node.document.spec.description or "No description provided.")
    if node.node_type in {"layer", "stack", "subsystem"}:
        render_lines.append("")
        render_lines.append(f"[dim]Press c to clone this {node.node_type}.[/dim]")
    if node.node_type == "layer":
        render_lines.append("[dim]Press a to run a layer action.[/dim]")

    return "\n".join(render_lines)


def render_segment_details(node: TreeNode) -> str:
    """Render details for a segment node."""
    count = node.extra.get("count", len(node.children))
    return f"{node.label}: {count} item{'s' if count != 1 else ''}."


def render_installed_plugin_details(node: TreeNode) -> str:
    """Render details for an installed plugin from the lock file."""
    extra = node.extra
    lines = [
        f"[b]Plugin:[/b] {extra.get('plugin_name', node.label)}",
        f"[b]Version:[/b] {extra.get('version', '-')}",
        f"[b]Installed:[/b] {extra.get('installed_at', '-')}",
        f"[b]Source:[/b] {extra.get('source', '-')}",
    ]

    canonical = extra.get("canonical", ())
    custom = extra.get("custom", ())

    if canonical:
        lines.append("")
        lines.append(f"[b]Canonical ({len(canonical)}):[/b]")
        # Show as comma-separated list, wrapped if needed
        lines.append(f"  {', '.join(canonical)}")

    if custom:
        lines.append("")
        lines.append(f"[b]Custom ({len(custom)}):[/b]")
        lines.append(f"  {', '.join(custom)}")

    if not canonical and not custom:
        lines.append("")
        lines.append("[dim]No items installed.[/dim]")

    return "\n".join(lines)


def render_layer_type_details(node: TreeNode) -> str:
    """Render details for a layer type definition."""
    extra = node.extra
    is_custom = extra.get("is_custom", False)
    type_label = "[cyan](custom)[/cyan]" if is_custom else "[dim](canonical)[/dim]"

    lines = [
        f"[b]Layer Type:[/b] {node.label} {type_label}",
    ]

    description = extra.get("description")
    if description:
        lines.append(f"[b]Description:[/b] {description}")

    template_path = extra.get("template_path")
    if template_path:
        lines.append(f"[b]Template Path:[/b] {template_path}")

    default_dir = extra.get("default_layer_dir")
    if default_dir:
        lines.append(f"[b]Default Dir:[/b] {default_dir}")

    optional_paths = extra.get("optional_paths", ())
    if optional_paths:
        lines.append(f"[b]Optional Paths:[/b] {', '.join(optional_paths)}")

    path = extra.get("path")
    if path:
        lines.append(f"[b]Source:[/b] {path}")

    return "\n".join(lines)


def render_action_details(node: TreeNode) -> str:
    """Render details for an action definition."""
    extra = node.extra
    tags = extra.get("tags") or ()
    run_command = extra.get("run", "-")
    timeout = extra.get("timeout")
    environment = extra.get("environment") or {}
    lines = [
        f"[b]Action:[/b] {node.label}",
        f"[b]Type:[/b] {extra.get('type', '-')}",
        f"[b]Default Stage:[/b] {extra.get('when', '-')}",
        f"[b]Run:[/b] {run_command}",
    ]
    path = extra.get("path")
    if path:
        lines.append(f"[b]Path:[/b] {path}")
    if timeout:
        lines.append(f"[b]Timeout:[/b] {timeout}s")
    if tags:
        lines.append(f"[b]Tags:[/b] {', '.join(tags)}")
    if environment:
        lines.append("[b]Environment:[/b]")
        for key, value in environment.items():
            lines.append(f"  • {key}={value}")
    description = extra.get("description") or "No description provided."
    lines.append("")
    lines.append(description)
    return "\n".join(lines)


def render_action_binding_details(node: TreeNode) -> str:
    """Render details for an action binding."""
    extra = node.extra
    tags = extra.get("tags") or ()
    environment = extra.get("environment") or {}
    lines = [
        f"[b]Layer:[/b] {extra.get('layer', '-')}",
        f"[b]Action Ref:[/b] {extra.get('action_ref', '-')}",
        f"[b]Stage:[/b] {extra.get('when', '-')}",
    ]
    if tags:
        lines.append(f"[b]Tags:[/b] {', '.join(tags)}")
    if environment:
        lines.append("[b]Environment Overrides:[/b]")
        for key, value in environment.items():
            lines.append(f"  • {key}={value}")
    description = extra.get("description") or ""
    if description:
        lines.append("")
        lines.append(description)
    return "\n".join(lines)


def render_workflow_details(node: TreeNode) -> str:
    """Render details for an action workflow."""
    extra = node.extra
    tags = extra.get("tags") or ()
    lines = [
        f"[b]Workflow:[/b] {extra.get('name', node.label)}",
        f"[b]Layer:[/b] {extra.get('layer', '-')}",
        f"[b]Template:[/b] {extra.get('template', '-')}",
    ]
    if tags:
        lines.append(f"[b]Tags:[/b] {', '.join(tags)}")
    description = extra.get("description") or ""
    if description:
        lines.append("")
        lines.append(description)
    return "\n".join(lines)


def render_cicd_workflow_details(node: TreeNode) -> str:
    """Render details for a CICD workflow definition."""
    extra = node.extra
    lines = [
        f"[b]Workflow:[/b] {node.label}",
        f"[b]Template:[/b] {extra.get('template_path', '-')}",
        f"[b]Renderer:[/b] {extra.get('renderer', '-')}",
        f"[b]Strict Undefined:[/b] {'yes' if extra.get('strict_renderer') else 'no'}",
        f"[b]Jobs:[/b] {extra.get('job_count', 0)}",
    ]
    path = extra.get("path")
    if path:
        lines.append(f"[b]Path:[/b] {path}")
    parameters = extra.get("parameters") or []
    if parameters:
        lines.append("[b]Parameters:[/b]")
        for parameter in parameters:
            name = parameter.get("name", "-")
            param_type = parameter.get("type") or "string"
            requirement = "required" if parameter.get("required", True) else "optional"
            line = f"  • {name} ({param_type}, {requirement})"
            if parameter.get("has_default"):
                line += f" default={parameter.get('default')}"
            lines.append(line)
            description = parameter.get("description")
            if description:
                lines.append(f"      {description}")
    description = extra.get("description") or ""
    if description:
        lines.append("")
        lines.append(description)
    return "\n".join(lines)


def render_cicd_workflow_job_details(node: TreeNode) -> str:
    """Render details for a CICD workflow job."""
    extra = node.extra
    with_arguments = extra.get("with") or {}
    needs = extra.get("needs") or []
    lines = [
        f"[b]Job:[/b] {node.label}",
        f"[b]Workflow:[/b] {extra.get('workflow', '-')}",
        f"[b]Template Ref:[/b] {extra.get('template_ref', '-')}",
    ]
    if with_arguments:
        lines.append("[b]Inputs:[/b]")
        for key, value in with_arguments.items():
            lines.append(f"  • {key}={value}")
    if needs:
        lines.append(f"[b]Needs:[/b] {', '.join(needs)}")
    return "\n".join(lines)


def render_cicd_job_template_details(node: TreeNode) -> str:
    """Render details for a CICD job template."""
    extra = node.extra
    lines = [
        f"[b]Job Template:[/b] {node.label}",
        f"[b]Template:[/b] {extra.get('template_path', '-')}",
        f"[b]Renderer:[/b] {extra.get('renderer', '-')}",
        f"[b]Strict Undefined:[/b] {'yes' if extra.get('strict_renderer') else 'no'}",
    ]
    path = extra.get("path")
    if path:
        lines.append(f"[b]Path:[/b] {path}")
    required_inputs = extra.get("required_inputs") or ()
    if required_inputs:
        lines.append(f"[b]Required Inputs:[/b] {', '.join(required_inputs)}")
    default_inputs = extra.get("default_inputs") or {}
    if default_inputs:
        lines.append("[b]Default Inputs:[/b]")
        for key, value in default_inputs.items():
            lines.append(f"  • {key}={value}")
    produces = extra.get("produces") or ()
    consumes = extra.get("consumes") or ()
    if produces:
        lines.append(f"[b]Produces:[/b] {', '.join(produces)}")
    if consumes:
        lines.append(f"[b]Consumes:[/b] {', '.join(consumes)}")
    description = extra.get("description") or ""
    if description:
        lines.append("")
        lines.append(description)
    return "\n".join(lines)


def render_warnings(errors: Sequence[object]) -> str:
    """Render warning messages from taxonomy loading."""
    if not errors:
        return ""
    lines = ["[b]Warnings:[/b]"]
    for error in errors:
        message = getattr(error, "message", "")
        path = getattr(error, "path", "")
        index = getattr(error, "document_index", 0)
        lines.append(f"• {path}#{index}: {message}")
    return "\n".join(lines)


def render_action_result(
    *,
    layer_name: str,
    stack_name: str,
    action: LayerAction,
    environment: str | None,
    outcome: ActionRunOutcome,
) -> Text:
    """Build rich text representation of an action execution result."""
    from .modals import build_action_result_text

    return build_action_result_text(
        layer_name=layer_name,
        stack_name=stack_name,
        action=action,
        environment=environment,
        outcome=outcome,
    )


def render_agent_details(node: TreeNode) -> str:
    """Render details for an agent definition."""
    extra = node.extra
    lines = [
        f"[b]Agent:[/b] {node.label}",
        f"[b]Mode:[/b] {extra.get('mode', 'all')}",
    ]

    # Temperature and model
    temperature = extra.get("temperature")
    if temperature is not None:
        lines.append(f"[b]Temperature:[/b] {temperature}")
    model = extra.get("model")
    if model:
        lines.append(f"[b]Model:[/b] {model}")
    max_steps = extra.get("max_steps")
    if max_steps:
        lines.append(f"[b]Max Steps:[/b] {max_steps}")

    # Flags
    flags = []
    if extra.get("hidden"):
        flags.append("hidden")
    if extra.get("disabled"):
        flags.append("disabled")
    if flags:
        lines.append(f"[b]Flags:[/b] {', '.join(flags)}")

    # Tools
    tools = extra.get("tools") or {}
    if tools:
        enabled = [k for k, v in tools.items() if v]
        disabled = [k for k, v in tools.items() if not v]
        if enabled:
            lines.append(f"[b]Tools Enabled:[/b] {', '.join(enabled)}")
        if disabled:
            lines.append(f"[b]Tools Disabled:[/b] {', '.join(disabled)}")

    # Scope
    lines.append("")
    lines.append("[b]Scope:[/b]")
    if extra.get("scope_global"):
        lines.append("  Global: yes")
    else:
        lines.append("  Global: no")
    scope_layer_types = extra.get("scope_layer_types") or []
    if scope_layer_types:
        lines.append(f"  Layer Types: {', '.join(scope_layer_types)}")
    scope_systems = extra.get("scope_systems") or []
    if scope_systems:
        lines.append(f"  Systems: {', '.join(scope_systems)}")
    scope_layers = extra.get("scope_layers") or []
    if scope_layers:
        lines.append(f"  Layers: {', '.join(scope_layers)}")

    # Path
    path = extra.get("path")
    if path:
        lines.append("")
        lines.append(f"[b]Path:[/b] {path}")

    # Description
    description = extra.get("description") or ""
    if description:
        lines.append("")
        lines.append("[b]Trigger:[/b]")
        lines.append(f"  {description}")

    return "\n".join(lines)


def render_skill_details(node: TreeNode) -> str:
    """Render details for a skill definition."""
    extra = node.extra
    lines = [
        f"[b]Skill:[/b] {node.label}",
    ]

    # License
    license_info = extra.get("license")
    if license_info:
        lines.append(f"[b]License:[/b] {license_info}")

    # Compatibility
    compatibility = extra.get("compatibility") or []
    if compatibility:
        lines.append(f"[b]Compatibility:[/b] {', '.join(compatibility)}")

    # Scope
    lines.append("")
    lines.append("[b]Scope:[/b]")
    if extra.get("scope_global"):
        lines.append("  Global: yes")
    else:
        lines.append("  Global: no")
    scope_layer_types = extra.get("scope_layer_types") or []
    if scope_layer_types:
        lines.append(f"  Layer Types: {', '.join(scope_layer_types)}")

    # Path
    path = extra.get("path")
    if path:
        lines.append("")
        lines.append(f"[b]Path:[/b] {path}")

    # Description
    description = extra.get("description") or ""
    if description:
        lines.append("")
        lines.append(description)

    return "\n".join(lines)
