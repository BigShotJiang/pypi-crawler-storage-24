"""Modal screen components for the taxonomy TUI."""

# pyright: reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false
# pyright: reportUnknownParameterType=false
# pyright: reportMissingTypeArgument=false
# pyright: reportAttributeAccessIssue=false
# pyright: reportInvalidTypeArguments=false
# pyright: reportArgumentType=false

from __future__ import annotations

from pathlib import Path
from typing import Sequence

from rich.text import Text
from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.message import Message
from textual.screen import ModalScreen
from textual.widgets import Button, Select, Static

from katalyst_taxonomy.plugins.layer_actions import LayerAction

from .services import ActionRunOutcome, LintOutcome


def build_action_result_text(
    *,
    layer_name: str,
    stack_name: str,
    action: LayerAction,
    environment: str | None,
    outcome: ActionRunOutcome,
) -> Text:
    """Build rich text representation of an action execution result."""
    env_value = environment or "(not set)"
    stdout = outcome.stdout.rstrip()
    stderr = outcome.stderr.rstrip()
    text = Text()

    def add_line(content: str = "") -> None:
        text.append(content)
        text.append("\n")

    add_line("Action Result")
    add_line(f"Layer: {layer_name}")
    add_line(f"Stack: {stack_name}")
    add_line(f"Action: {action.name}")
    add_line(f"Command: {action.run}")
    add_line(f"ENV: {env_value}")
    add_line(f"Exit Code: {outcome.exit_code}")
    add_line()

    text.append("stdout:\n", style="bold")
    if stdout:
        text.append_text(Text.from_ansi(stdout))
    else:
        text.append("(empty)")
    add_line()
    add_line()

    text.append("stderr:\n", style="bold")
    if stderr:
        text.append_text(Text.from_ansi(stderr))
    else:
        text.append("(empty)")
    return text


class ActionRunForm(ModalScreen[None]):
    """Modal dialog for selecting and running a layer action."""

    class RunRequested(Message):
        """Message emitted when the user wants to execute an action."""

        def __init__(
            self,
            *,
            form: ActionRunForm,
            action_name: str,
            environment: str | None,
        ) -> None:
            super().__init__()
            self.form = form
            self.action_name = action_name
            self.environment = environment

    def __init__(
        self,
        *,
        layer_name: str,
        stack_name: str,
        actions: Sequence[LayerAction],
        environments: Sequence[str],
        default_action: str,
        default_environment: str | None,
    ) -> None:
        super().__init__()
        self._layer_name = layer_name
        self._stack_name = stack_name
        self._actions = tuple(actions)
        self._action_map = {action.name: action for action in actions}
        self._environment_options = tuple(environments)
        self._default_action = default_action
        self._default_environment = default_environment
        self._description_widget: Static | None = None
        self._environment_select: Select[str] | None = None  # type: ignore[type-arg]
        self._output_panel: Static | None = None
        self._run_button: Button | None = None

    def compose(self) -> ComposeResult:
        with Vertical(id="action-run-form"):
            with Horizontal(id="action-form-header"):
                yield Static(
                    f"Run Action for {self._stack_name}/{self._layer_name}",
                    id="form-title",
                )
                yield Button("✕", id="dismiss-action", variant="error")
            yield Select(
                id="field-action-select",
                value=self._default_action,
                options=[
                    (self._format_action_label(action), action.name) for action in self._actions
                ],
            )
            description = Static("", id="action-description")
            self._description_widget = description
            yield description
            with Vertical(id="row-action-environment"):
                if self._environment_options:
                    env_select = Select(
                        id="field-action-environment-select",
                        value=(
                            self._default_environment
                            if self._default_environment in self._environment_options
                            else Select.BLANK
                        ),
                        options=[(env, env) for env in self._environment_options],
                        prompt="Select environment",
                        allow_blank=True,
                    )
                    self._environment_select = env_select
                    yield env_select
                else:
                    yield Static("No environments detected for this taxonomy.", classes="dim")
            with Horizontal(id="action-form-buttons"):
                yield Button("Cancel", id="cancel-action")
                run_button = Button("Run", id="run-action", variant="success")
                self._run_button = run_button
                yield run_button
            output_panel = Static("", id="action-output-panel", classes="action-output")
            self._output_panel = output_panel
            yield output_panel

    async def on_mount(self) -> None:
        self._update_description(self._default_action)

    @on(Select.Changed, "#field-action-select")
    def _handle_action_change(self, event: Select.Changed[str]) -> None:
        if event.value:
            self._update_description(event.value)

    @on(Select.Changed, "#field-action-environment-select")
    def _handle_environment_select(self, event: Select.Changed[str]) -> None:
        return

    @on(Button.Pressed, "#cancel-action")
    def _cancel_action(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#dismiss-action")
    def _dismiss_action(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#run-action")
    def _submit_action(self) -> None:
        action_widget = self.query_one("#field-action-select")
        action_value = getattr(action_widget, "value", None)
        if not action_value or action_value == Select.BLANK:
            return
        environment_value = None
        if self._environment_select is not None:
            selected = self._environment_select.value
            if selected not in (None, Select.BLANK):
                environment_value = selected
        self.display_message("Running action...")
        self.set_running(True)
        self.post_message(
            self.RunRequested(
                form=self,
                action_name=action_value,
                environment=environment_value,
            ),
        )

    def _update_description(self, action_name: str | None) -> None:
        if self._description_widget is None or not action_name:
            return
        action = self._action_map.get(action_name)
        if action is None:
            self._description_widget.update("")
            return
        lines = [
            f"[b]{action.name}[/b]",
            f"Stage: {action.when}",
            f"Run: {action.run}",
        ]
        if action.description:
            lines.extend(["", action.description])
        self._description_widget.update("\n".join(lines))

    @staticmethod
    def _format_action_label(action: LayerAction) -> str:
        stage = action.when or "-"
        return f"{action.name} ({stage})"

    def set_running(self, running: bool) -> None:
        if self._run_button is not None:
            self._run_button.disabled = running
            self._run_button.label = "Running..." if running else "Run"

    def display_message(self, message: str) -> None:
        if self._output_panel is not None:
            self._output_panel.update(message)

    def display_result(
        self,
        *,
        layer_name: str,
        stack_name: str,
        action: LayerAction,
        environment: str | None,
        outcome: ActionRunOutcome,
    ) -> None:
        if self._output_panel is None:
            return
        text = build_action_result_text(
            layer_name=layer_name,
            stack_name=stack_name,
            action=action,
            environment=environment,
            outcome=outcome,
        )
        self._output_panel.update(text)


class InitDialog(ModalScreen[bool]):
    """Modal dialog prompting the user to initialize a taxonomy repository."""

    def __init__(self, *, path: Path) -> None:
        super().__init__()
        self._path = path

    def compose(self) -> ComposeResult:
        with Vertical(id="init-dialog"):
            yield Static("Initialize Taxonomy", id="init-title")
            yield Static(
                f"No taxonomy found at:\n[b]{self._path}[/b]\n\n"
                "Would you like to initialize a new taxonomy repository?",
                id="init-message",
            )
            with Horizontal(id="init-actions"):
                yield Button("Cancel", id="init-cancel")
                yield Button("Initialize", id="init-confirm", variant="success")

    @on(Button.Pressed, "#init-cancel")
    def _cancel(self) -> None:
        self.dismiss(False)

    @on(Button.Pressed, "#init-confirm")
    def _confirm(self) -> None:
        self.dismiss(True)


class LintResultsModal(ModalScreen[None]):
    """Modal dialog displaying taxonomy lint results."""

    def __init__(self, *, outcome: LintOutcome, path: Path) -> None:
        super().__init__()
        self._outcome = outcome
        self._path = path

    def compose(self) -> ComposeResult:
        with Vertical(id="lint-results-dialog"):
            yield Static("Taxonomy Lint Results", id="lint-title")
            with VerticalScroll(id="lint-content"):
                yield Static(self._build_content(), id="lint-details")
            with Horizontal(id="lint-actions"):
                yield Button("Close", id="lint-close", variant="primary")

    def _build_content(self) -> str:
        outcome = self._outcome
        lines: list[str] = []

        # Summary
        if outcome.errors:
            lines.append(f"[bold red]Found {len(outcome.errors)} error(s)[/bold red]")
        else:
            lines.append("[bold green]No errors found[/bold green]")

        lines.append("")
        lines.append(f"[b]Path:[/b] {self._path}")
        lines.append(f"[b]Documents checked:[/b] {outcome.checked_documents}")
        lines.append(
            f"[b]Environment documents checked:[/b] {outcome.checked_environment_documents}",
        )
        lines.append(f"[b]Schema:[/b] {outcome.schema_path}")
        lines.append(f"[b]Environment schema:[/b] {outcome.environment_schema_path}")

        # Errors
        if outcome.errors:
            lines.append("")
            lines.append("[b]Errors:[/b]")
            for error in outcome.errors:
                lines.append(f"  [red]•[/red] {error}")

        return "\n".join(lines)

    @on(Button.Pressed, "#lint-close")
    def _close(self) -> None:
        self.dismiss(None)
