"""Form modals for taxonomy creation and cloning."""

# pyright: reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false
# pyright: reportUnknownParameterType=false
# pyright: reportInvalidTypeArguments=false
# pyright: reportGeneralTypeIssues=false
# pyright: reportArgumentType=false
# pyright: reportAttributeAccessIssue=false
# pyright: reportMissingTypeArgument=false
# pyright: reportUnusedVariable=false

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from textual import on
from textual.containers import Horizontal, Vertical
from textual.css.query import NoMatches
from textual.screen import ModalScreen
from textual.suggester import Suggester, SuggestFromList
from textual.widgets import Button, Input, Select, Static

from .viewmodels import CloneDefaults, CreationDefaults


class CommaSeparatedSuggester(Suggester):
    """Completion helper for comma-separated inputs that preserves free-form text."""

    def __init__(
        self,
        suggestions: Iterable[str],
        *,
        separator: str = ",",
        case_sensitive: bool = False,
    ) -> None:
        super().__init__(case_sensitive=case_sensitive)
        unique = tuple(dict.fromkeys(suggestions))
        self._suggestions = unique
        self._separator = separator
        self._case_sensitive = case_sensitive
        self._comparisons = tuple(
            item if case_sensitive else item.casefold() for item in self._suggestions
        )

    async def get_suggestion(self, value: str) -> str | None:
        if not self._suggestions:
            return None

        prefix, stub, whitespace = self._split_value(value)
        needle = stub if self._case_sensitive else stub.casefold()
        for suggestion, comparison in zip(self._suggestions, self._comparisons, strict=False):
            if comparison.startswith(needle):
                return prefix + whitespace + suggestion
        return None

    def _split_value(self, value: str) -> tuple[str, str, str]:
        """Split value into prefix (with separator), stub and leading whitespace."""

        base, sep, tail = value.rpartition(self._separator)
        if sep:
            prefix = value[: len(value) - len(tail)]
            fragment = tail
        else:
            prefix = ""
            fragment = value
        stripped = fragment.lstrip()
        leading = fragment[: len(fragment) - len(stripped)]
        return prefix, stripped, leading


class CreationForm(ModalScreen["CreationForm.Result | None"]):
    """Simple modal form used to collect taxonomy creation inputs."""

    @dataclass
    class Result:
        node_type: str
        name: str
        description: str
        owners: tuple[str, ...]
        environments: tuple[str, ...]
        parent: str | None
        parent_subsystem: str | None
        parent_system: str | None
        layer_type: str | None
        annotations: tuple[str, ...]
        depends_on: tuple[str, ...]
        subsystem_description: str | None
        stack_description: str | None

    @dataclass(frozen=True)
    class _FieldConfig:
        parent: bool
        parent_placeholder: str
        parent_subsystem: bool
        parent_subsystem_placeholder: str
        parent_system: bool
        parent_system_placeholder: str
        layer_type: bool
        layer_type_placeholder: str
        subsystem_description: bool
        subsystem_description_placeholder: str
        stack_description: bool
        stack_description_placeholder: str

    _NODE_TYPE_OPTIONS: tuple[tuple[str, str], ...] = (
        ("Organization", "organization"),
        ("Program", "program"),
        ("Project", "project"),
        ("Team", "team"),
        ("Team Member", "team_member"),
        ("System", "system"),
        ("Subsystem", "subsystem"),
        ("Stack", "stack"),
        ("Layer", "layer"),
    )

    _FIELD_CONFIGS: dict[str, _FieldConfig] = {
        "organization": _FieldConfig(
            parent=False,
            parent_placeholder="Parent",
            parent_subsystem=False,
            parent_subsystem_placeholder="Parent subsystem",
            parent_system=False,
            parent_system_placeholder="Parent system",
            layer_type=False,
            layer_type_placeholder="Layer type (app-docker, k8s-argocd, ...)",
            subsystem_description=False,
            subsystem_description_placeholder="Subsystem description",
            stack_description=False,
            stack_description_placeholder="Stack description",
        ),
        "program": _FieldConfig(
            parent=True,
            parent_placeholder="Parent organization",
            parent_subsystem=False,
            parent_subsystem_placeholder="Parent subsystem",
            parent_system=False,
            parent_system_placeholder="Parent system",
            layer_type=False,
            layer_type_placeholder="Layer type (app-docker, k8s-argocd, ...)",
            subsystem_description=False,
            subsystem_description_placeholder="Subsystem description",
            stack_description=False,
            stack_description_placeholder="Stack description",
        ),
        "project": _FieldConfig(
            parent=True,
            parent_placeholder="Parent program or organization",
            parent_subsystem=False,
            parent_subsystem_placeholder="Parent subsystem",
            parent_system=False,
            parent_system_placeholder="Parent system",
            layer_type=False,
            layer_type_placeholder="Layer type (app-docker, k8s-argocd, ...)",
            subsystem_description=False,
            subsystem_description_placeholder="Subsystem description",
            stack_description=False,
            stack_description_placeholder="Stack description",
        ),
        "team": _FieldConfig(
            parent=True,
            parent_placeholder="Parent organization or team",
            parent_subsystem=False,
            parent_subsystem_placeholder="Parent subsystem",
            parent_system=False,
            parent_system_placeholder="Parent system",
            layer_type=False,
            layer_type_placeholder="Layer type (app-docker, k8s-argocd, ...)",
            subsystem_description=False,
            subsystem_description_placeholder="Subsystem description",
            stack_description=False,
            stack_description_placeholder="Stack description",
        ),
        "team_member": _FieldConfig(
            parent=True,
            parent_placeholder="Parent team",
            parent_subsystem=False,
            parent_subsystem_placeholder="Parent subsystem",
            parent_system=False,
            parent_system_placeholder="Parent system",
            layer_type=False,
            layer_type_placeholder="Layer type (app-docker, k8s-argocd, ...)",
            subsystem_description=False,
            subsystem_description_placeholder="Subsystem description",
            stack_description=False,
            stack_description_placeholder="Stack description",
        ),
        "system": _FieldConfig(
            parent=False,
            parent_placeholder="Parent",
            parent_subsystem=False,
            parent_subsystem_placeholder="Parent subsystem",
            parent_system=False,
            parent_system_placeholder="Parent system",
            layer_type=False,
            layer_type_placeholder="Layer type (app-docker, k8s-argocd, ...)",
            subsystem_description=False,
            subsystem_description_placeholder="Subsystem description",
            stack_description=False,
            stack_description_placeholder="Stack description",
        ),
        "subsystem": _FieldConfig(
            parent=True,
            parent_placeholder="Parent system",
            parent_subsystem=False,
            parent_subsystem_placeholder="Parent subsystem",
            parent_system=False,
            parent_system_placeholder="Parent system",
            layer_type=False,
            layer_type_placeholder="Layer type (app-docker, k8s-argocd, ...)",
            subsystem_description=False,
            subsystem_description_placeholder="Subsystem description",
            stack_description=False,
            stack_description_placeholder="Stack description",
        ),
        "stack": _FieldConfig(
            parent=True,
            parent_placeholder="Parent subsystem",
            parent_subsystem=False,
            parent_subsystem_placeholder="Parent subsystem",
            parent_system=False,
            parent_system_placeholder="Parent system",
            layer_type=False,
            layer_type_placeholder="Layer type (app-docker, k8s-argocd, ...)",
            subsystem_description=False,
            subsystem_description_placeholder="Subsystem description",
            stack_description=False,
            stack_description_placeholder="Stack description",
        ),
        "layer": _FieldConfig(
            parent=True,
            parent_placeholder="Parent stack",
            parent_subsystem=True,
            parent_subsystem_placeholder="Parent subsystem",
            parent_system=True,
            parent_system_placeholder="Parent system",
            layer_type=True,
            layer_type_placeholder="Layer type (app-docker, k8s-argocd, ...)",
            subsystem_description=True,
            subsystem_description_placeholder="Subsystem description (auto-create)",
            stack_description=True,
            stack_description_placeholder="Stack description (auto-create)",
        ),
    }

    def __init__(self, *, defaults: CreationDefaults) -> None:
        super().__init__()
        self._defaults = defaults
        self._current_node_type = defaults.node_type
        self._system_options = defaults.system_options
        self._subsystem_options = defaults.subsystem_options
        self._stack_options = defaults.stack_options
        self._environment_options = defaults.environment_options
        self._layer_type_options = defaults.layer_type_options

    def compose(self):
        with Vertical(id="creation-form"):
            yield Static("Create Taxonomy Node", id="form-title")
            yield Select(
                id="field-node-type",
                value=self._defaults.node_type,
                options=[(label, value) for label, value in self._NODE_TYPE_OPTIONS],
            )
            yield Input(value="", id="field-name", placeholder="Name")
            yield Input(value="", id="field-description", placeholder="Description")
            yield Input(
                value=self._defaults.owner or "",
                id="field-owners",
                placeholder="Owners (comma separated)",
            )
            with Horizontal(id="row-environments"):
                yield Input(
                    value=self._defaults.environment or "",
                    id="field-environments",
                    placeholder="Environments (comma separated)",
                    suggester=self._create_environment_suggester(),
                )
                environment_select = self._build_select(
                    select_id="field-environments-select",
                    options=self._environment_options,
                    prompt="Add environment",
                    value=None,
                )
                if environment_select is not None:
                    yield environment_select
            with Vertical(id="row-parent"):
                with Horizontal():
                    yield Input(
                        value=self._defaults.parent or "",
                        id="field-parent",
                        placeholder="Parent",
                        suggester=self._make_parent_suggester(self._defaults.node_type),
                    )
                    parent_select = self._build_select(
                        select_id="field-parent-select",
                        options=self._parent_options_for(self._defaults.node_type),
                        prompt="Select parent",
                        value=self._defaults.parent,
                    )
                    if parent_select is not None:
                        yield parent_select
            with Vertical(id="row-parent-subsystem"):
                with Horizontal():
                    yield Input(
                        value=self._defaults.parent_subsystem or "",
                        id="field-parent-subsystem",
                        placeholder="Parent subsystem",
                        suggester=self._make_subsystem_suggester(),
                    )
                    parent_subsystem_select = self._build_select(
                        select_id="field-parent-subsystem-select",
                        options=self._subsystem_options,
                        prompt="Select subsystem",
                        value=self._defaults.parent_subsystem,
                    )
                    if parent_subsystem_select is not None:
                        yield parent_subsystem_select
            with Vertical(id="row-parent-system"):
                with Horizontal():
                    yield Input(
                        value=self._defaults.parent_system or "",
                        id="field-parent-system",
                        placeholder="Parent system",
                        suggester=self._make_system_suggester(),
                    )
                    parent_system_select = self._build_select(
                        select_id="field-parent-system-select",
                        options=self._system_options,
                        prompt="Select system",
                        value=self._defaults.parent_system,
                    )
                    if parent_system_select is not None:
                        yield parent_system_select
            with Vertical(id="row-subsystem-description"):
                yield Input(
                    value=self._defaults.subsystem_description or "",
                    id="field-subsystem-description",
                    placeholder="Subsystem description (auto-create)",
                )
            with Vertical(id="row-stack-description"):
                yield Input(
                    value=self._defaults.stack_description or "",
                    id="field-stack-description",
                    placeholder="Stack description (auto-create)",
                )
            with Vertical(id="row-layer-type"):
                with Horizontal():
                    if self._defaults.node_type == "layer":
                        default_layer_type = self._defaults.layer_type or "app-docker"
                    else:
                        default_layer_type = ""
                    yield Input(
                        value=default_layer_type,
                        id="field-layer-type",
                        placeholder="Layer type (app-docker, k8s-argocd, ...)",
                    )
                    layer_type_select = self._build_select(
                        select_id="field-layer-type-select",
                        options=self._layer_type_options,
                        prompt="Select layer type",
                        value=default_layer_type or None,
                    )
                    if layer_type_select is not None:
                        yield layer_type_select
            with Horizontal(id="form-actions"):
                yield Button("Cancel", id="cancel")
                yield Button("Create", id="create", variant="success")

    async def on_mount(self) -> None:
        self._apply_node_type(self._defaults.node_type)

    @on(Button.Pressed, "#cancel")
    def _cancel(self) -> None:
        self.dismiss(None)

    @on(Select.Changed, "#field-node-type")
    def _handle_node_type_change(self, event: Select.Changed[str]) -> None:
        if event.value:
            self._apply_node_type(event.value)

    @on(Select.Changed, "#field-parent-select")
    def _handle_parent_select_choice(self, event: Select.Changed[str]) -> None:
        self._apply_select_value(event.value, "field-parent")

    @on(Select.Changed, "#field-parent-subsystem-select")
    def _handle_parent_subsystem_select(self, event: Select.Changed[str]) -> None:
        self._apply_select_value(event.value, "field-parent-subsystem")

    @on(Select.Changed, "#field-parent-system-select")
    def _handle_parent_system_select(self, event: Select.Changed[str]) -> None:
        self._apply_select_value(event.value, "field-parent-system")

    @on(Select.Changed, "#field-layer-type-select")
    def _handle_layer_type_select(self, event: Select.Changed[str]) -> None:
        self._apply_select_value(event.value, "field-layer-type")

    @on(Select.Changed, "#field-environments-select")
    def _handle_environment_select(self, event: Select.Changed[str]) -> None:
        value = event.value
        if value in (None, Select.BLANK):
            return
        if not isinstance(value, str):
            return
        current = list(self._split_field("field-environments"))
        if value not in current:
            current.append(value)
            self._get_input("field-environments").value = ", ".join(current)
        event.select.value = Select.BLANK

    @on(Input.Changed, "#field-parent")
    def _handle_parent_input_change(self, event: Input.Changed) -> None:
        self._sync_select_with_input(
            select_id="field-parent-select",
            options=self._parent_options_for(self._current_node_type),
            value=event.value,
        )

    @on(Input.Changed, "#field-parent-subsystem")
    def _handle_parent_subsystem_input_change(self, event: Input.Changed) -> None:
        self._sync_select_with_input(
            select_id="field-parent-subsystem-select",
            options=self._subsystem_options,
            value=event.value,
        )

    @on(Input.Changed, "#field-parent-system")
    def _handle_parent_system_input_change(self, event: Input.Changed) -> None:
        self._sync_select_with_input(
            select_id="field-parent-system-select",
            options=self._system_options,
            value=event.value,
        )

    @on(Input.Changed, "#field-layer-type")
    def _handle_layer_type_input_change(self, event: Input.Changed) -> None:
        self._sync_select_with_input(
            select_id="field-layer-type-select",
            options=self._layer_type_options,
            value=event.value,
        )

    @on(Button.Pressed, "#create")
    def _submit(self) -> None:
        node_type = self._get_node_type()
        owners = self._split_field("field-owners")
        if not owners and self._defaults.owner:
            owners = (self._defaults.owner,)
        environments = self._split_field("field-environments")
        if not environments and self._defaults.environment:
            environments = (self._defaults.environment,)

        parent_value = self._read_optional("field-parent", self._defaults.parent)
        parent_subsystem_value = self._read_optional(
            "field-parent-subsystem",
            self._defaults.parent_subsystem,
        )
        parent_system_value = self._read_optional(
            "field-parent-system",
            self._defaults.parent_system,
        )
        layer_type_value = self._read_optional("field-layer-type", None)
        subsystem_description_value = self._read_optional(
            "field-subsystem-description",
            self._defaults.subsystem_description,
        )
        stack_description_value = self._read_optional(
            "field-stack-description",
            self._defaults.stack_description,
        )

        try:
            (
                parent_value,
                parent_subsystem_value,
                parent_system_value,
                layer_type_value,
            ) = self._normalize_parent_inputs(
                node_type,
                parent_value,
                parent_subsystem_value,
                parent_system_value,
                layer_type_value,
            )
        except ValueError as exc:
            self.app.notify(str(exc), severity="error")
            return

        result = CreationForm.Result(
            node_type=node_type,
            name=self._read_value("field-name"),
            description=self._read_value("field-description"),
            owners=owners,
            environments=environments,
            parent=parent_value,
            parent_subsystem=parent_subsystem_value,
            parent_system=parent_system_value,
            layer_type=layer_type_value,
            annotations=(),
            depends_on=(),
            subsystem_description=subsystem_description_value if node_type == "layer" else None,
            stack_description=stack_description_value if node_type == "layer" else None,
        )
        if not result.name:
            self.app.notify("Name is required.", severity="error")
            return
        self.dismiss(result)

    def _get_node_type(self) -> str:
        select = self.query_one("#field-node-type", Select)
        value = select.value
        if value == Select.BLANK:
            return self._defaults.node_type
        return str(value) if value else self._defaults.node_type

    def _read_value(self, element_id: str, fallback: str = "") -> str:
        widget = self.query_one(f"#{element_id}", Input)
        value = widget.value.strip()
        return value or fallback

    def _read_optional(self, element_id: str, fallback: str | None) -> str | None:
        value = self._read_value(element_id)
        return value or fallback

    def _split_field(self, element_id: str) -> tuple[str, ...]:
        value = self._read_value(element_id)
        if not value:
            return ()
        parts = [part.strip() for part in value.split(",")]
        return tuple(part for part in parts if part)

    def _apply_node_type(self, node_type: str) -> None:
        config = self._FIELD_CONFIGS.get(node_type, self._FIELD_CONFIGS["layer"])
        self._current_node_type = node_type
        self._set_row_visible("row-parent", config.parent)
        self._set_placeholder("field-parent", config.parent_placeholder)
        if not config.parent:
            self._get_input("field-parent").value = ""

        self._set_row_visible("row-parent-subsystem", config.parent_subsystem)
        self._set_placeholder("field-parent-subsystem", config.parent_subsystem_placeholder)
        if not config.parent_subsystem:
            self._get_input("field-parent-subsystem").value = ""

        self._set_row_visible("row-parent-system", config.parent_system)
        self._set_placeholder("field-parent-system", config.parent_system_placeholder)
        if not config.parent_system:
            self._get_input("field-parent-system").value = ""

        self._set_row_visible("row-layer-type", config.layer_type)
        self._set_placeholder("field-layer-type", config.layer_type_placeholder)
        layer_field = self._get_input("field-layer-type")
        if config.layer_type:
            if not layer_field.value:
                layer_field.value = self._defaults.layer_type or "app-docker"
        else:
            layer_field.value = ""

        self._set_row_visible("row-subsystem-description", config.subsystem_description)
        self._set_placeholder(
            "field-subsystem-description",
            config.subsystem_description_placeholder,
        )
        if not config.subsystem_description:
            self._get_input("field-subsystem-description").value = ""

        self._set_row_visible("row-stack-description", config.stack_description)
        self._set_placeholder("field-stack-description", config.stack_description_placeholder)
        if not config.stack_description:
            self._get_input("field-stack-description").value = ""

        self._set_select_options(
            select_id="field-parent-select",
            options=self._parent_options_for(node_type),
            visible=config.parent,
            input_id="field-parent",
        )
        self._set_select_options(
            select_id="field-parent-subsystem-select",
            options=self._subsystem_options,
            visible=config.parent_subsystem,
            input_id="field-parent-subsystem",
        )
        self._set_select_options(
            select_id="field-parent-system-select",
            options=self._system_options,
            visible=config.parent_system,
            input_id="field-parent-system",
        )
        self._set_select_options(
            select_id="field-layer-type-select",
            options=self._layer_type_options,
            visible=config.layer_type,
            input_id="field-layer-type",
        )
        self._set_parent_suggester(node_type)

    def _set_row_visible(self, row_id: str, visible: bool) -> None:
        row = self.query_one(f"#{row_id}")
        if visible:
            row.remove_class("hidden")
        else:
            row.add_class("hidden")

    def _set_placeholder(self, field_id: str, placeholder: str) -> None:
        input_field = self._get_input(field_id)
        input_field.placeholder = placeholder

    def _get_input(self, field_id: str) -> Input:
        return self.query_one(f"#{field_id}", Input)

    def _build_select(
        self,
        *,
        select_id: str,
        options: tuple[str, ...],
        prompt: str,
        value: str | None,
    ) -> Select | None:
        if not options:
            return None
        select_value = value if value and value in options else Select.BLANK
        return Select(
            options=[(option, option) for option in options],
            prompt=prompt,
            allow_blank=True,
            value=select_value,  # type: ignore[arg-type]
            id=select_id,
        )

    def _get_select(self, select_id: str) -> Select | None:
        try:
            return self.query_one(f"#{select_id}", Select)
        except NoMatches:
            return None

    def _set_select_options(
        self,
        *,
        select_id: str,
        options: tuple[str, ...],
        visible: bool,
        input_id: str,
    ) -> None:
        select = self._get_select(select_id)
        if select is None:
            return
        select.set_options([(option, option) for option in options])
        input_value = self._get_input(input_id).value.strip()
        if input_value and input_value in options:
            select.value = input_value
        else:
            select.value = Select.BLANK
        if visible and options:
            select.remove_class("hidden")
        else:
            select.add_class("hidden")

    def _clear_select(self, select_id: str) -> None:
        select = self._get_select(select_id)
        if select is not None:
            select.value = Select.BLANK

    def _sync_select_with_input(
        self,
        *,
        select_id: str,
        options: tuple[str, ...],
        value: str,
    ) -> None:
        select = self._get_select(select_id)
        if select is None:
            return
        normalized = value.strip()
        if normalized and normalized in options:
            select.value = normalized
        else:
            select.value = Select.BLANK

    def _apply_select_value(self, value: str | object, input_id: str) -> None:
        if value in (None, Select.BLANK):
            return
        if not isinstance(value, str):
            return
        input_widget = self._get_input(input_id)
        input_widget.value = value
        input_widget.cursor_position = len(value)

    def _create_environment_suggester(self) -> Suggester | None:
        if not self._environment_options:
            return None
        return CommaSeparatedSuggester(self._environment_options, case_sensitive=False)

    def _make_parent_suggester(self, node_type: str) -> Suggester | None:
        options = self._parent_options_for(node_type)
        if not options:
            return None
        return SuggestFromList(options, case_sensitive=False)

    def _make_subsystem_suggester(self) -> Suggester | None:
        if not self._subsystem_options:
            return None
        return SuggestFromList(self._subsystem_options, case_sensitive=False)

    def _make_system_suggester(self) -> Suggester | None:
        if not self._system_options:
            return None
        return SuggestFromList(self._system_options, case_sensitive=False)

    def _parent_options_for(self, node_type: str) -> tuple[str, ...]:
        if node_type == "subsystem":
            return self._system_options
        if node_type == "stack":
            return self._subsystem_options
        if node_type == "layer":
            return self._stack_options
        return ()

    def _set_parent_suggester(self, node_type: str) -> None:
        parent_input = self._get_input("field-parent")
        parent_input.suggester = self._make_parent_suggester(node_type)

    @staticmethod
    def _normalize_parent_inputs(
        node_type: str,
        parent: str | None,
        parent_subsystem: str | None,
        parent_system: str | None,
        layer_type: str | None,
    ) -> tuple[str | None, str | None, str | None, str | None]:
        if node_type == "system":
            return None, None, None, None

        if node_type == "subsystem":
            if not parent:
                raise ValueError("Parent system is required for a subsystem.")
            return parent, None, None, None

        if node_type == "stack":
            if not parent:
                raise ValueError("Parent subsystem is required for a stack.")
            return parent, None, None, None

        if node_type == "layer":
            if not parent:
                raise ValueError("Parent stack is required for a layer.")
            if not parent_subsystem:
                raise ValueError("Parent subsystem is required for a layer.")
            if not parent_system:
                raise ValueError("Parent system is required for a layer.")
            return parent, parent_subsystem, parent_system, layer_type or "app-docker"

        return parent, parent_subsystem, parent_system, layer_type


class CloneForm(ModalScreen["CloneForm.Result | None"]):
    """Modal form for cloning taxonomy nodes."""

    @dataclass
    class Result:
        name: str
        description: str | None
        owners: tuple[str, ...]
        environments: tuple[str, ...]
        parent: str | None
        parent_subsystem: str | None
        parent_system: str | None
        layer_type: str | None
        subsystem_description: str | None
        stack_description: str | None

    @dataclass(frozen=True)
    class _FieldConfig:
        title: str
        parent: bool
        parent_placeholder: str
        parent_required: bool
        parent_subsystem: bool
        parent_subsystem_placeholder: str
        parent_subsystem_required: bool
        parent_system: bool
        parent_system_placeholder: str
        parent_system_required: bool
        layer_type: bool
        layer_type_placeholder: str
        subsystem_description: bool
        subsystem_description_placeholder: str
        stack_description: bool
        stack_description_placeholder: str

    _FIELD_CONFIGS: dict[str, _FieldConfig] = {
        "layer": _FieldConfig(
            title="Clone Layer",
            parent=True,
            parent_placeholder="Target stack",
            parent_required=True,
            parent_subsystem=True,
            parent_subsystem_placeholder="Target subsystem",
            parent_subsystem_required=True,
            parent_system=True,
            parent_system_placeholder="Target system",
            parent_system_required=True,
            layer_type=True,
            layer_type_placeholder="Layer type",
            subsystem_description=True,
            subsystem_description_placeholder="Subsystem description (auto-create)",
            stack_description=True,
            stack_description_placeholder="Stack description (auto-create)",
        ),
        "stack": _FieldConfig(
            title="Clone Stack",
            parent=True,
            parent_placeholder="Target subsystem",
            parent_required=True,
            parent_subsystem=False,
            parent_subsystem_placeholder="Target subsystem",
            parent_subsystem_required=False,
            parent_system=True,
            parent_system_placeholder="Target system",
            parent_system_required=False,
            layer_type=False,
            layer_type_placeholder="Layer type",
            subsystem_description=True,
            subsystem_description_placeholder="Subsystem description (auto-create)",
            stack_description=False,
            stack_description_placeholder="Stack description (auto-create)",
        ),
        "subsystem": _FieldConfig(
            title="Clone Subsystem",
            parent=True,
            parent_placeholder="Target system",
            parent_required=True,
            parent_subsystem=False,
            parent_subsystem_placeholder="Target subsystem",
            parent_subsystem_required=False,
            parent_system=False,
            parent_system_placeholder="Target system",
            parent_system_required=False,
            layer_type=False,
            layer_type_placeholder="Layer type",
            subsystem_description=False,
            subsystem_description_placeholder="Subsystem description (auto-create)",
            stack_description=False,
            stack_description_placeholder="Stack description (auto-create)",
        ),
    }

    def __init__(self, *, defaults: CloneDefaults, source_label: str) -> None:
        super().__init__()
        self._defaults = defaults
        self._source_label = source_label
        try:
            self._config = self._FIELD_CONFIGS[defaults.node_type]
        except KeyError as exc:  # pragma: no cover - defensive guard
            raise ValueError(f"Unsupported clone node type: {defaults.node_type}") from exc
        self._system_options = defaults.system_options
        self._subsystem_options = defaults.subsystem_options
        self._stack_options = defaults.stack_options
        self._environment_options = defaults.environment_options
        self._layer_type_options = defaults.layer_type_options

    def compose(self):
        owners_value = ", ".join(self._defaults.owners)
        env_value = ", ".join(self._defaults.environments)
        parent_options = self._parent_options()
        subsystem_placeholder = self._config.parent_subsystem_placeholder
        parent_system_placeholder = self._config.parent_system_placeholder
        with Vertical(id="clone-form"):
            yield Static(f"{self._config.title} '{self._source_label}'", id="form-title")
            yield Input(value=self._defaults.name, id="clone-name", placeholder="New name")
            yield Input(
                value=self._defaults.description or "",
                id="clone-description",
                placeholder="Description (optional)",
            )
            yield Input(
                value=owners_value,
                id="clone-owners",
                placeholder="Owners (comma separated)",
            )
            yield Input(
                value=env_value,
                id="clone-environments",
                placeholder="Environments (comma separated)",
                suggester=CommaSeparatedSuggester(self._environment_options, case_sensitive=False)
                if self._environment_options
                else None,
            )
            yield Input(
                value=self._defaults.parent or "",
                id="clone-parent",
                placeholder=self._config.parent_placeholder,
                suggester=SuggestFromList(parent_options, case_sensitive=False)
                if self._config.parent and parent_options
                else None,
                classes="" if self._config.parent else "hidden",
            )
            yield Input(
                value=self._defaults.parent_subsystem or "",
                id="clone-parent-subsystem",
                placeholder=subsystem_placeholder,
                suggester=SuggestFromList(self._subsystem_options, case_sensitive=False)
                if self._config.parent_subsystem and self._subsystem_options
                else None,
                classes="" if self._config.parent_subsystem else "hidden",
            )
            yield Input(
                value=self._defaults.parent_system or "",
                id="clone-parent-system",
                placeholder=parent_system_placeholder,
                suggester=SuggestFromList(self._system_options, case_sensitive=False)
                if self._config.parent_system and self._system_options
                else None,
                classes="" if self._config.parent_system else "hidden",
            )
            yield Input(
                value=self._defaults.subsystem_description or "",
                id="clone-subsystem-description",
                placeholder=self._config.subsystem_description_placeholder,
                classes="" if self._config.subsystem_description else "hidden",
            )
            yield Input(
                value=self._defaults.stack_description or "",
                id="clone-stack-description",
                placeholder=self._config.stack_description_placeholder,
                classes="" if self._config.stack_description else "hidden",
            )
            yield Input(
                value=self._defaults.layer_type or "",
                id="clone-layer-type",
                placeholder=self._config.layer_type_placeholder,
                suggester=SuggestFromList(self._layer_type_options, case_sensitive=False)
                if self._config.layer_type and self._layer_type_options
                else None,
                classes="" if self._config.layer_type else "hidden",
            )
            with Horizontal(id="clone-actions"):
                yield Button("Cancel", id="clone-cancel")
                yield Button("Clone", id="clone-confirm", variant="success")

    @on(Button.Pressed, "#clone-cancel")
    def _cancel(self) -> None:
        self.dismiss(None)

    @on(Button.Pressed, "#clone-confirm")
    def _submit(self) -> None:
        name = self._read_value("clone-name", None)
        if not name:
            self.app.notify("Name is required.", severity="error")
            return

        parent = self._resolve_parent()
        if self._config.parent and self._config.parent_required and not parent:
            self._notify_missing("Target parent is required.")
            return

        parent_subsystem = self._resolve_parent_subsystem()
        if (
            self._config.parent_subsystem
            and self._config.parent_subsystem_required
            and not parent_subsystem
        ):
            self._notify_missing("Target subsystem is required.")
            return

        parent_system = self._resolve_parent_system()
        if self._config.parent_system and self._config.parent_system_required and not parent_system:
            self._notify_missing("Target system is required.")
            return

        owners = self._split_field("clone-owners") or self._defaults.owners
        environments = self._split_field("clone-environments") or self._defaults.environments

        result = CloneForm.Result(
            name=name,
            description=self._read_optional("clone-description", self._defaults.description),
            owners=owners,
            environments=environments,
            parent=parent,
            parent_subsystem=parent_subsystem,
            parent_system=parent_system,
            layer_type=(
                self._read_optional("clone-layer-type", self._defaults.layer_type)
                if self._config.layer_type
                else None
            ),
            subsystem_description=(
                self._read_optional(
                    "clone-subsystem-description",
                    self._defaults.subsystem_description,
                )
                if self._config.subsystem_description
                else None
            ),
            stack_description=(
                self._read_optional("clone-stack-description", self._defaults.stack_description)
                if self._config.stack_description
                else None
            ),
        )
        self.dismiss(result)

    def _notify_missing(self, message: str) -> None:
        self.app.notify(message, severity="error")

    def _parent_options(self) -> tuple[str, ...]:
        node_type = self._defaults.node_type
        if node_type == "layer":
            return self._stack_options
        if node_type == "stack":
            return self._subsystem_options
        if node_type == "subsystem":
            return self._system_options
        return ()

    def _resolve_parent(self) -> str | None:
        if not self._config.parent:
            return None
        return self._read_value("clone-parent", self._defaults.parent)

    def _resolve_parent_subsystem(self) -> str | None:
        if not self._config.parent_subsystem:
            return None
        return self._read_value("clone-parent-subsystem", self._defaults.parent_subsystem)

    def _resolve_parent_system(self) -> str | None:
        if not self._config.parent_system:
            return None
        return self._read_value("clone-parent-system", self._defaults.parent_system)

    def _read_value(self, element_id: str, fallback: str | None) -> str | None:
        widget = self.query_one(f"#{element_id}", Input)
        value = widget.value.strip()
        if value:
            return value
        return fallback

    def _read_optional(self, element_id: str, fallback: str | None) -> str | None:
        value = self._read_value(element_id, fallback)
        return value or None

    def _split_field(self, element_id: str) -> tuple[str, ...]:
        value = self._read_value(element_id, None)
        if not value:
            return ()
        return tuple(part.strip() for part in value.split(",") if part.strip())
