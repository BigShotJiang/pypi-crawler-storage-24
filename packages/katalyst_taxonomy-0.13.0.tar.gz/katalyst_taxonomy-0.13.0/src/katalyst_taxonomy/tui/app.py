"""Textual application for exploring and managing taxonomy nodes."""

# pyright: reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false
# pyright: reportUnknownParameterType=false
# pyright: reportMissingTypeArgument=false
# pyright: reportUnnecessaryComparison=false
# pyright: reportInvalidTypeArguments=false
# pyright: reportAttributeAccessIssue=false
# pyright: reportArgumentType=false
# pyright: reportCallIssue=false
# pyright: reportGeneralTypeIssues=false
# pyright: reportUnusedVariable=false

from __future__ import annotations

import asyncio
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from loguru import logger
from textual import on
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Footer, Header, Static, Tree

from katalyst_taxonomy.plugins.layer_actions import LayerAction
from katalyst_taxonomy.taxonomy.documents import TaxonomyDocument
from katalyst_taxonomy.taxonomy.utils import extract_layer_type

from .forms import CloneForm, CreationForm
from .init_wizard import InitWizard, InitWizardResult
from .modals import ActionRunForm, InitDialog, LintResultsModal
from .renderers import (
    render_action_binding_details,
    render_action_details,
    render_action_result,
    render_agent_details,
    render_cicd_job_template_details,
    render_cicd_workflow_details,
    render_cicd_workflow_job_details,
    render_installed_plugin_details,
    render_layer_type_details,
    render_segment_details,
    render_skill_details,
    render_taxonomy_details,
    render_warnings,
    render_workflow_details,
)
from .services import (
    ActionRunOutcome,
    ActionRunRequest,
    CloneRequest,
    CreationRequest,
    FilesystemTaxonomyService,
    TaxonomyLoadResult,
)
from .viewmodels import (
    CloneDefaults,
    CreationContext,
    NodeView,
    TreeNode,
    build_clone_defaults,
    build_creation_defaults,
    build_taxonomy_tree,
)

_logger_configured = False


def _configure_logger() -> None:
    global _logger_configured
    if _logger_configured:
        return
    logger.remove()
    logger.add(sys.stderr, level="WARNING")
    _logger_configured = True


@dataclass(frozen=True)
class _ActionRunContext:
    stack_path: Path
    layer_path: Path
    stack_name: str
    layer_name: str
    actions: tuple[LayerAction, ...]
    environments: tuple[str, ...]
    default_environment: str | None
    discovered_environments: tuple[str, ...]


class TaxonomyApp(App[None]):
    """Primary Textual application for the katalyst taxonomy."""

    CSS_PATH = Path(__file__).with_name("tui.css")
    BINDINGS = [
        ("q", "quit", "Quit"),
        ("r", "refresh", "Refresh"),
        ("n", "create_node", "Create Node"),
        ("c", "clone_node", "Clone Node"),
        ("w", "toggle_warnings", "Warnings"),
        ("a", "run_action", "Run Action"),
        ("i", "init", "Init"),
        ("l", "lint", "Lint"),
    ]

    def __init__(
        self,
        *,
        base_path: Path,
        service: FilesystemTaxonomyService | None = None,
    ) -> None:
        _configure_logger()
        super().__init__()
        self._base_path = base_path
        self._service = service or FilesystemTaxonomyService()
        self._load_result: TaxonomyLoadResult | None = None
        self._tree_root: TreeNode | None = None
        self._selected: NodeView | None = None
        self._layer_actions = None
        self._warnings_visible = False
        self._warning_text = ""
        self._pending_clone_defaults: CloneDefaults | None = None
        self._pending_action_context: _ActionRunContext | None = None
        self._is_initialized: bool | None = None

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Horizontal(id="layout"):
            yield Tree("Taxonomy", id="taxonomy-tree")
            with Vertical(id="detail-column"):
                with VerticalScroll(id="detail-panel-container"):
                    yield Static("Select a node to view details.", id="detail-panel")
                yield Static("", id="warnings-panel", classes="hidden")
        yield Footer()

    async def on_mount(self) -> None:  # pragma: no cover - exercised via integration
        self._is_initialized = self._service.is_taxonomy_initialized(self._base_path)
        if not self._is_initialized:
            await self._show_init_wizard()
        else:
            await self._refresh_taxonomy()

    async def action_refresh(self) -> None:
        await self._refresh_taxonomy()

    async def action_toggle_warnings(self) -> None:
        self._warnings_visible = not self._warnings_visible
        panel = self.query_one("#warnings-panel", Static)
        if self._warnings_visible and self._warning_text:
            panel.update(self._warning_text)
            panel.remove_class("hidden")
        else:
            panel.add_class("hidden")

    async def action_init(self) -> None:
        """Show the initialization wizard."""
        await self._show_init_wizard()

    async def action_lint(self) -> None:
        """Run taxonomy linting and display results."""
        self.notify("Running lint...", severity="information")
        outcome = await asyncio.to_thread(self._service.lint, self._base_path)

        if outcome.errors:
            self.notify(
                f"Lint found {len(outcome.errors)} error(s)",
                severity="error",
            )
        else:
            self.notify(
                f"Lint passed: {outcome.checked_documents} document(s) validated",
                severity="information",
            )

        modal = LintResultsModal(outcome=outcome, path=self._base_path)
        await self.push_screen(modal)

    async def _show_init_dialog(self) -> None:
        """Display the simple init dialog for quick confirmation."""
        modal = InitDialog(path=self._base_path)
        await self.push_screen(modal, self._handle_simple_init_result)

    async def _show_init_wizard(self) -> None:
        """Display the full init wizard with all options."""
        modal = InitWizard(path=self._base_path)
        await self.push_screen(modal, self._handle_wizard_result)

    async def _handle_simple_init_result(self, confirmed: bool) -> None:
        """Handle the result of the simple init dialog."""
        if not confirmed:
            if not self._is_initialized:
                self.notify("Initialization cancelled. Exiting.", severity="warning")
                self.exit()
            return

        # Run basic initialization
        self.notify("Initializing taxonomy...", severity="information")
        outcome = await asyncio.to_thread(self._service.init_taxonomy, self._base_path)

        if outcome.success:
            self._is_initialized = True
            self.notify("Taxonomy initialized successfully!", severity="information")
            await self._refresh_taxonomy()
        else:
            message = outcome.stderr or "Unknown error during initialization."
            self.notify(f"Initialization failed: {message}", severity="error")
            if not self._is_initialized:
                self.exit()

    async def _handle_wizard_result(self, result: InitWizardResult) -> None:
        """Handle the result of the init wizard."""
        if result.cancelled:
            if not self._is_initialized:
                self.notify("Initialization cancelled. Exiting.", severity="warning")
                self.exit()
            return

        # Run initialization with selected options
        self.notify("Initializing taxonomy...", severity="information")
        outcome = await asyncio.to_thread(
            self._service.init_taxonomy,
            self._base_path,
            plugins=result.plugins or None,
            layer_types=result.layer_types or None,
        )

        if not outcome.success:
            message = outcome.stderr or "Unknown error during initialization."
            self.notify(f"Initialization failed: {message}", severity="error")
            if not self._is_initialized:
                self.exit()
            return

        self._is_initialized = True
        self.notify("Taxonomy initialized!", severity="information")

        # Create initial system if specified
        if result.system_name:
            self.notify(f"Creating system '{result.system_name}'...", severity="information")
            system_request = CreationRequest(
                path=self._base_path,
                node_type="system",
                name=result.system_name,
                description=result.system_description or f"{result.system_name} system",
                owners=(result.system_owner,) if result.system_owner else ("team@example.com",),
                environments=result.environments or ("dev",),
                parent=None,
                parent_subsystem=None,
                parent_system=None,
                annotations=(),
                depends_on=(),
            )
            system_outcome = await asyncio.to_thread(self._service.create, system_request)
            if system_outcome.success:
                self.notify(
                    f"System '{result.system_name}' created successfully!",
                    severity="information",
                )

                # Create subsystem if specified
                if result.subsystem_name:
                    self.notify(
                        f"Creating subsystem '{result.subsystem_name}'...",
                        severity="information",
                    )
                    subsystem_request = CreationRequest(
                        path=self._base_path,
                        node_type="subsystem",
                        name=result.subsystem_name,
                        description=result.subsystem_description
                        or f"{result.subsystem_name} subsystem",
                        owners=(result.system_owner,)
                        if result.system_owner
                        else ("team@example.com",),
                        environments=result.environments or ("dev",),
                        parent=result.system_name,
                        parent_subsystem=None,
                        parent_system=None,
                        annotations=(),
                        depends_on=(),
                    )
                    subsystem_outcome = await asyncio.to_thread(
                        self._service.create,
                        subsystem_request,
                    )
                    if subsystem_outcome.success:
                        self.notify(
                            f"Subsystem '{result.subsystem_name}' created successfully!",
                            severity="information",
                        )

                        # Create stack if specified
                        if result.stack_name:
                            self.notify(
                                f"Creating stack '{result.stack_name}'...",
                                severity="information",
                            )
                            stack_request = CreationRequest(
                                path=self._base_path,
                                node_type="stack",
                                name=result.stack_name,
                                description=result.stack_description
                                or f"{result.stack_name} stack",
                                owners=(result.system_owner,)
                                if result.system_owner
                                else ("team@example.com",),
                                environments=result.environments or ("dev",),
                                parent=result.subsystem_name,
                                parent_subsystem=None,
                                parent_system=result.system_name,
                                annotations=(),
                                depends_on=(),
                            )
                            stack_outcome = await asyncio.to_thread(
                                self._service.create,
                                stack_request,
                            )
                            if stack_outcome.success:
                                self.notify(
                                    f"Stack '{result.stack_name}' created successfully!",
                                    severity="information",
                                )
                            else:
                                message = stack_outcome.stderr or "Unknown error creating stack."
                                self.notify(f"Failed to create stack: {message}", severity="error")
                    else:
                        message = subsystem_outcome.stderr or "Unknown error creating subsystem."
                        self.notify(f"Failed to create subsystem: {message}", severity="error")
            else:
                message = system_outcome.stderr or "Unknown error creating system."
                self.notify(f"Failed to create system: {message}", severity="error")

        await self._refresh_taxonomy()

    async def action_create_node(self) -> None:
        if self._load_result is None:
            return

        defaults = build_creation_defaults(
            CreationContext(
                selected=self._selected,
                available_systems=self._filter_documents("system"),
                available_subsystems=self._filter_documents("subsystem"),
                available_stacks=self._filter_documents("stack"),
                available_layers=self._filter_documents("layer"),
                layer_types=self._load_result.layer_types,
            ),
        )

        modal = CreationForm(defaults=defaults)
        await self.push_screen(modal, self._handle_creation_request)

    async def action_clone_node(self) -> None:
        if self._load_result is None:
            return
        if self._selected is None or self._selected.node_type not in {
            "layer",
            "stack",
            "subsystem",
        }:
            self.notify("Select a layer, stack, or subsystem to clone.", severity="warning")
            return

        context = CreationContext(
            selected=self._selected,
            available_systems=self._filter_documents("system"),
            available_subsystems=self._filter_documents("subsystem"),
            available_stacks=self._filter_documents("stack"),
            available_layers=self._filter_documents("layer"),
            layer_types=self._load_result.layer_types,
        )
        try:
            defaults = build_clone_defaults(context)
        except ValueError as exc:
            self.notify(str(exc), severity="error")
            return

        self._pending_clone_defaults = defaults
        source_name = self._selected.document.metadata.name
        source_label = self._selected.extra.get("fqtn") or source_name
        modal = CloneForm(defaults=defaults, source_label=source_label)
        await self.push_screen(modal, self._handle_clone_request)

    async def action_run_action(self) -> None:
        if self._load_result is None:
            self.notify("Load a taxonomy tree before running actions.", severity="warning")
            return
        if self._selected is None or self._selected.node_type != "layer":
            self.notify(
                "Layer actions are only available when a layer is selected.",
                severity="warning",
            )
            return

        layer_doc = self._selected.document
        layer_type = extract_layer_type(layer_doc)
        if layer_type is None:
            self.notify("Selected layer does not declare a layerType.", severity="warning")
            return

        layer_actions = self._load_result.layer_actions
        if layer_actions is None:
            self.notify("Layer actions plugin data is not available.", severity="warning")
            return

        actions = layer_actions.actions_for_layer_type(layer_type)
        if not actions:
            self.notify(
                f"No actions registered for layer type '{layer_type}'.",
                severity="warning",
            )
            return

        stack_context = self._resolve_stack_context(layer_doc)
        if stack_context is None:
            self.notify("Unable to determine the stack directory for this layer.", severity="error")
            return

        stack_name, stack_path = stack_context
        stack_path = self._base_path / stack_path
        layer_path = (
            self._base_path / layer_doc.source_path.parent if layer_doc.source_path else stack_path
        )
        environments = tuple(layer_doc.spec.environments) or ()
        default_env = environments[0] if environments else None
        discovered_envs = self._collect_all_environments()
        context = _ActionRunContext(
            stack_path=stack_path,
            layer_path=layer_path,
            stack_name=stack_name,
            layer_name=layer_doc.metadata.name,
            actions=actions,
            environments=environments,
            default_environment=default_env,
            discovered_environments=discovered_envs,
        )
        self._pending_action_context = context
        modal = ActionRunForm(
            layer_name=context.layer_name,
            stack_name=context.stack_name,
            actions=context.actions,
            environments=context.discovered_environments,
            default_action=context.actions[0].name,
            default_environment=context.default_environment,
        )
        await self.push_screen(modal, self._handle_action_run_request)

    @on(Tree.NodeSelected, "#taxonomy-tree")
    def handle_tree_selection(self, event: Tree.NodeSelected[TreeNode]) -> None:
        data = event.node.data
        panel = self.query_one("#detail-panel", Static)
        if isinstance(data, NodeView):
            self._selected = data
            panel.update(render_taxonomy_details(data))
        elif isinstance(data, TreeNode):
            self._selected = None
            self._render_tree_node_details(data)
        else:
            self._selected = None
            panel.update("Select a node to view details.")

    def _filter_documents(self, node_type: str) -> tuple[TaxonomyDocument, ...]:
        if self._load_result is None:
            return ()
        return tuple(
            doc for doc in self._load_result.documents if doc.taxonomy_node_type == node_type
        )

    def _collect_all_environments(self) -> tuple[str, ...]:
        if self._load_result is None:
            return ()
        seen: dict[str, None] = {}
        for document in self._load_result.documents:
            for environment in document.spec.environments:
                if environment not in seen:
                    seen[environment] = None
        return tuple(seen.keys())

    def _resolve_stack_context(self, layer_doc: TaxonomyDocument) -> tuple[str, Path] | None:
        if self._load_result is None:
            return None
        parent_name = layer_doc.spec.parents.node if layer_doc.spec.parents else None
        if not parent_name:
            return None
        for candidate in self._load_result.documents:
            if (
                candidate.taxonomy_node_type == "stack"
                and candidate.metadata.name == parent_name
                and candidate.source_path is not None
            ):
                return candidate.metadata.name, candidate.source_path.parent
        return None

    async def _refresh_taxonomy(self) -> None:
        try:
            result = self._service.load(self._base_path)
        except FileNotFoundError as exc:
            logger.error("Failed to load taxonomy: {}", exc)
            self.notify(str(exc), severity="error")
            return

        self._load_result = result
        tree_view = build_taxonomy_tree(
            documents=result.documents,
            qualified_names=result.qualified_names,
            layer_actions=result.layer_actions,
            layer_types=result.layer_types,
            cicd=result.cicd,
            lock=result.lock,
            agents=result.agents,
        )
        self._tree_root = tree_view
        self._populate_tree(tree_view)
        warnings: list[object] = list(result.errors)
        if result.layer_actions is not None:
            warnings.extend(result.layer_actions.errors)
        if result.layer_types is not None:
            warnings.extend(result.layer_types.errors)
        if result.cicd is not None:
            warnings.extend(result.cicd.errors)
        if result.agents is not None:
            warnings.extend(result.agents.errors)
        self._update_warnings_panel(warnings)
        self._selected = None
        self.query_one("#detail-panel", Static).update("Select a node to view details.")

    def _populate_tree(self, tree_view: TreeNode) -> None:
        tree = self.query_one("#taxonomy-tree", Tree)
        tree.clear()
        root = tree.root
        if root is None:
            root = tree.add(tree_view.label)
        root.set_label(tree_view.label)
        root.data = None
        for child in tree_view.children:
            self._add_tree_node(root, child)
        root.expand()

    def _add_tree_node(self, parent: Tree.Node, child: TreeNode) -> Tree.Node:
        node = parent.add(child.label, data=child)
        node.allow_expand = bool(child.children)
        for grandchild in child.children:
            self._add_tree_node(node, grandchild)
        return node

    def _render_tree_node_details(self, node: TreeNode) -> None:
        """Dispatch rendering for non-document tree nodes."""
        panel = self.query_one("#detail-panel", Static)
        node_type = node.node_type

        if node_type == "segment":
            panel.update(render_segment_details(node))
        elif node_type == "installed_plugin":
            panel.update(render_installed_plugin_details(node))
        elif node_type == "layer_type":
            panel.update(render_layer_type_details(node))
        elif node_type == "action":
            panel.update(render_action_details(node))
        elif node_type == "action_binding":
            panel.update(render_action_binding_details(node))
        elif node_type == "action_workflow":
            panel.update(render_workflow_details(node))
        elif node_type == "cicd_workflow":
            panel.update(render_cicd_workflow_details(node))
        elif node_type == "cicd_workflow_job":
            panel.update(render_cicd_workflow_job_details(node))
        elif node_type == "cicd_job_template":
            panel.update(render_cicd_job_template_details(node))
        elif node_type == "agent":
            panel.update(render_agent_details(node))
        elif node_type == "skill":
            panel.update(render_skill_details(node))
        else:
            panel.update(node.label)

    def _update_warnings_panel(self, errors: Sequence[object]) -> None:
        """Update the warnings panel with error messages."""
        panel = self.query_one("#warnings-panel", Static)
        if not errors:
            self._warning_text = ""
            panel.update("")
            panel.add_class("hidden")
            return
        self._warning_text = render_warnings(errors)
        if self._warnings_visible:
            panel.update(self._warning_text)
            panel.remove_class("hidden")
        else:
            panel.add_class("hidden")

    def _render_action_result(
        self,
        *,
        layer_name: str,
        stack_name: str,
        action: LayerAction,
        environment: str | None,
        outcome: ActionRunOutcome,
    ) -> None:
        """Render action execution result to the detail panel."""
        text = render_action_result(
            layer_name=layer_name,
            stack_name=stack_name,
            action=action,
            environment=environment,
            outcome=outcome,
        )
        self.query_one("#detail-panel", Static).update(text)

    async def _handle_creation_request(self, payload: CreationForm.Result | None) -> None:
        if payload is None or self._load_result is None:
            return

        request = CreationRequest(
            path=self._base_path,
            node_type=payload.node_type,
            name=payload.name,
            description=payload.description,
            owners=payload.owners or ("team@example.com",),
            environments=payload.environments or ("dev",),
            parent=payload.parent,
            parent_subsystem=payload.parent_subsystem,
            parent_system=payload.parent_system,
            layer_type=payload.layer_type,
            annotations=payload.annotations,
            depends_on=payload.depends_on,
            subsystem_description=payload.subsystem_description,
            stack_description=payload.stack_description,
        )
        outcome = self._service.create(request)
        if outcome.success:
            self.notify("Node created successfully.", severity="information")
            await self._refresh_taxonomy()
        else:
            message = outcome.stderr or "Unknown error occurred during creation."
            self.notify(message, severity="error")

    async def _handle_clone_request(self, payload: CloneForm.Result | None) -> None:
        defaults = self._pending_clone_defaults
        self._pending_clone_defaults = None
        if payload is None or defaults is None:
            return

        owners = payload.owners or defaults.owners or ("team@example.com",)
        environments = payload.environments or defaults.environments or ("dev",)
        request = CloneRequest(
            path=self._base_path,
            node_type=defaults.node_type,
            source_system=defaults.source_system,
            source_subsystem=defaults.source_subsystem,
            source_stack=defaults.source_stack,
            source_layer=defaults.source_layer,
            name=payload.name,
            description=payload.description or defaults.description,
            owners=owners,
            environments=environments,
            parent=payload.parent if payload.parent is not None else defaults.parent,
            parent_subsystem=(
                payload.parent_subsystem
                if payload.parent_subsystem is not None
                else defaults.parent_subsystem
            ),
            parent_system=payload.parent_system
            if payload.parent_system is not None
            else defaults.parent_system,
            layer_type=payload.layer_type or defaults.layer_type,
            subsystem_description=payload.subsystem_description or defaults.subsystem_description,
            stack_description=payload.stack_description or defaults.stack_description,
        )
        outcome = self._service.clone(request)
        if outcome.success:
            node_label = defaults.node_type.capitalize()
            self.notify(f"{node_label} cloned successfully.", severity="information")
            await self._refresh_taxonomy()
        else:
            message = outcome.stderr or "Unknown error occurred during clone."
            self.notify(message, severity="error")

    @on(ActionRunForm.RunRequested)
    async def _handle_action_run_requested(self, event: ActionRunForm.RunRequested) -> None:
        form_attr = getattr(event, "form", None)
        form = form_attr if isinstance(form_attr, ActionRunForm) else None
        if form is None:
            logger.warning("RunRequested sender is not an ActionRunForm; ignoring event.")
            event.stop()
            return

        context = self._pending_action_context
        if context is None:
            form.display_message("Layer context is no longer available; close and retry.")
            event.stop()
            return

        action = next((item for item in context.actions if item.name == event.action_name), None)
        if action is None:
            form.display_message("Selected action is no longer available; close and retry.")
            event.stop()
            return

        environment = event.environment or context.default_environment
        request = ActionRunRequest(
            workdir=context.layer_path,
            action_name=action.name,
            command=action.run,
            environment=environment,
        )

        form.set_running(True)
        try:
            outcome = await asyncio.to_thread(self._service.run_action, request)
        except Exception as exc:  # pragma: no cover - defensive guard
            logger.exception("Failed to run action %s: %s", action.name, exc)
            outcome = ActionRunOutcome(
                success=False,
                stdout="",
                stderr=str(exc),
                exit_code=-1,
            )
        finally:
            form.set_running(False)

        form.display_result(
            layer_name=context.layer_name,
            stack_name=context.stack_name,
            action=action,
            environment=environment,
            outcome=outcome,
        )

        self._render_action_result(
            layer_name=context.layer_name,
            stack_name=context.stack_name,
            action=action,
            environment=environment,
            outcome=outcome,
        )
        event.stop()

    async def _handle_action_run_request(self, payload: ActionRunForm.Result | None) -> None:
        # Screen dismissed; clear context so future runs require a new selection.
        self._pending_action_context = None


def run(path: Path | None = None) -> None:
    """Run the Textual app."""

    base_path = path or Path(".")
    app = TaxonomyApp(base_path=base_path.resolve())
    app.run()
