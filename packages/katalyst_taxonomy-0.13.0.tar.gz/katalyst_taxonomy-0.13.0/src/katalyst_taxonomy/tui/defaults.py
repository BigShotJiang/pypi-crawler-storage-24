"""Default value computation for taxonomy creation and cloning forms."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from katalyst_taxonomy.plugins.layer_types import LayerTypesPluginResult
from katalyst_taxonomy.taxonomy.documents import TaxonomyDocument
from katalyst_taxonomy.taxonomy.utils import extract_layer_type

from .tree_nodes import NodeView

DEFAULT_LAYER_TYPES: tuple[str, ...] = (
    "app-docker",
    "iac-terragrunt",
    "k8s-argocd",
    "k8s-kustomize",
)


@dataclass(frozen=True)
class CreationDefaults:
    """Default values suggested when creating a taxonomy node."""

    node_type: str
    parent: str | None
    parent_subsystem: str | None
    parent_system: str | None
    environment: str | None
    owner: str | None
    layer_type: str | None
    subsystem_description: str | None
    stack_description: str | None
    system_options: tuple[str, ...]
    subsystem_options: tuple[str, ...]
    stack_options: tuple[str, ...]
    environment_options: tuple[str, ...]
    layer_type_options: tuple[str, ...]


@dataclass(frozen=True)
class CloneDefaults:
    """Default values suggested when cloning a taxonomy node."""

    node_type: str
    name: str
    description: str | None
    owners: tuple[str, ...]
    environments: tuple[str, ...]
    parent: str | None
    parent_subsystem: str | None
    parent_system: str | None
    layer_type: str | None
    subsystem_description: str | None
    stack_description: str | None
    system_options: tuple[str, ...]
    subsystem_options: tuple[str, ...]
    stack_options: tuple[str, ...]
    environment_options: tuple[str, ...]
    layer_type_options: tuple[str, ...]
    source_system: str
    source_subsystem: str | None
    source_stack: str | None
    source_layer: str | None


@dataclass(frozen=True)
class CreationContext:
    """Context required to infer sensible creation defaults."""

    selected: NodeView | None
    available_systems: Sequence[TaxonomyDocument]
    available_subsystems: Sequence[TaxonomyDocument]
    available_stacks: Sequence[TaxonomyDocument]
    available_layers: Sequence[TaxonomyDocument]
    layer_types: LayerTypesPluginResult | None


def build_creation_defaults(context: CreationContext) -> CreationDefaults:
    """Infer default creation values from the current selection."""

    selected = context.selected
    system_options = _collect_document_names(context.available_systems)
    subsystem_options = _collect_document_names(context.available_subsystems)
    stack_options = _collect_document_names(context.available_stacks)
    environment_options = _collect_environment_options(context, selected)
    layer_type_options = _collect_layer_type_options(context, selected)
    layer_type_default = layer_type_options[0] if layer_type_options else "app-docker"
    default_kwargs = dict(
        system_options=system_options,
        subsystem_options=subsystem_options,
        stack_options=stack_options,
        environment_options=environment_options,
        layer_type_options=layer_type_options,
    )

    if selected is None:
        return CreationDefaults(
            node_type="system",
            parent=None,
            parent_subsystem=None,
            parent_system=None,
            environment=None,
            owner=None,
            layer_type=None,
            subsystem_description=None,
            stack_description=None,
            **default_kwargs,
        )

    doc = selected.document
    base_owner = doc.spec.owners[0] if doc.spec.owners else "team@example.com"
    base_environment = doc.spec.environments[0] if doc.spec.environments else "dev"

    if selected.node_type == "stack":
        parent_subsystem = _resolve_parent_name(
            doc.spec.parents.node if doc.spec.parents else None,
            context.available_subsystems,
            expected_type="subsystem",
        )
        parent_system = _resolve_parent_name(
            _parent_of(parent_subsystem, context.available_subsystems),
            context.available_systems,
            expected_type="system",
        )
        return CreationDefaults(
            node_type="layer",
            parent=doc.metadata.name,
            parent_subsystem=parent_subsystem,
            parent_system=parent_system,
            environment=base_environment,
            owner=base_owner,
            layer_type=layer_type_default,
            subsystem_description=None,
            stack_description=None,
            **default_kwargs,
        )

    if selected.node_type == "subsystem":
        parent_system = _resolve_parent_name(
            doc.spec.parents.node if doc.spec.parents else None,
            context.available_systems,
            expected_type="system",
        )
        return CreationDefaults(
            node_type="stack",
            parent=doc.metadata.name,
            parent_subsystem=doc.metadata.name,
            parent_system=parent_system,
            environment=base_environment,
            owner=base_owner,
            layer_type=None,
            subsystem_description=None,
            stack_description=None,
            **default_kwargs,
        )

    if selected.node_type == "system":
        return CreationDefaults(
            node_type="subsystem",
            parent=doc.metadata.name,
            parent_subsystem=None,
            parent_system=None,
            environment=base_environment,
            owner=base_owner,
            layer_type=None,
            subsystem_description=None,
            stack_description=None,
            **default_kwargs,
        )

    # Default fallback for layer selection or unknown types.
    return CreationDefaults(
        node_type="layer",
        parent=doc.metadata.name if selected.node_type == "layer" else None,
        parent_subsystem=_resolve_parent_name(
            doc.spec.parents.node if doc.spec.parents else None,
            context.available_stacks if selected.node_type == "layer" else (),
            expected_type="stack",
        ),
        parent_system=None,
        environment=base_environment,
        owner=base_owner,
        layer_type=_extract_layer_type(doc) or layer_type_default,
        subsystem_description=None,
        stack_description=None,
        **default_kwargs,
    )


def build_clone_defaults(context: CreationContext) -> CloneDefaults:
    """Infer default clone values from the currently selected node."""

    selected = context.selected
    if selected is None:
        raise ValueError("Clone defaults require a selected node.")

    doc = selected.document
    system_options = _collect_document_names(context.available_systems)
    subsystem_options = _collect_document_names(context.available_subsystems)
    stack_options = _collect_document_names(context.available_stacks)
    environment_options = _collect_environment_options(context, selected)
    layer_type_options = _collect_layer_type_options(context, selected)
    node_type = selected.node_type

    if node_type == "layer":
        stack_name = doc.spec.parents.node if doc.spec.parents else None
        if not stack_name:
            raise ValueError("Layer is missing a parent stack.")
        subsystem_name = _parent_of(stack_name, context.available_stacks)
        system_name = _parent_of(subsystem_name, context.available_subsystems)
        if subsystem_name is None or system_name is None:
            raise ValueError("Unable to determine parent hierarchy for the selected layer.")

        owners = tuple(doc.spec.owners) or ("team@example.com",)
        environments = tuple(doc.spec.environments) or ("dev",)
        return CloneDefaults(
            node_type="layer",
            name=doc.metadata.name,
            description=doc.spec.description,
            owners=owners,
            environments=environments,
            parent=stack_name,
            parent_subsystem=subsystem_name,
            parent_system=system_name,
            layer_type=_extract_layer_type(doc),
            subsystem_description=None,
            stack_description=None,
            system_options=system_options,
            subsystem_options=subsystem_options,
            stack_options=stack_options,
            environment_options=environment_options,
            layer_type_options=layer_type_options,
            source_system=system_name,
            source_subsystem=subsystem_name,
            source_stack=stack_name,
            source_layer=doc.metadata.name,
        )

    if node_type == "stack":
        subsystem_name = doc.spec.parents.node if doc.spec.parents else None
        if not subsystem_name:
            raise ValueError("Stack is missing a parent subsystem.")
        system_name = _parent_of(subsystem_name, context.available_subsystems)
        if system_name is None:
            raise ValueError("Unable to determine parent system for the selected stack.")

        owners = tuple(doc.spec.owners) or ("team@example.com",)
        environments = tuple(doc.spec.environments) or ("dev",)
        return CloneDefaults(
            node_type="stack",
            name=doc.metadata.name,
            description=doc.spec.description,
            owners=owners,
            environments=environments,
            parent=subsystem_name,
            parent_subsystem=None,
            parent_system=system_name,
            layer_type=None,
            subsystem_description=None,
            stack_description=None,
            system_options=system_options,
            subsystem_options=subsystem_options,
            stack_options=stack_options,
            environment_options=environment_options,
            layer_type_options=layer_type_options,
            source_system=system_name,
            source_subsystem=subsystem_name,
            source_stack=doc.metadata.name,
            source_layer=None,
        )

    if node_type == "subsystem":
        system_name = doc.spec.parents.node if doc.spec.parents else None
        if system_name is None:
            raise ValueError("Subsystem is missing a parent system.")
        owners = tuple(doc.spec.owners) or ("team@example.com",)
        environments = tuple(doc.spec.environments) or ("dev",)
        return CloneDefaults(
            node_type="subsystem",
            name=doc.metadata.name,
            description=doc.spec.description,
            owners=owners,
            environments=environments,
            parent=system_name,
            parent_subsystem=None,
            parent_system=system_name,
            layer_type=None,
            subsystem_description=None,
            stack_description=None,
            system_options=system_options,
            subsystem_options=subsystem_options,
            stack_options=stack_options,
            environment_options=environment_options,
            layer_type_options=layer_type_options,
            source_system=system_name,
            source_subsystem=doc.metadata.name,
            source_stack=None,
            source_layer=None,
        )

    raise ValueError("Unsupported node type for cloning.")


def _collect_document_names(documents: Sequence[TaxonomyDocument]) -> tuple[str, ...]:
    """Return an ordered tuple of document names without duplicates."""

    seen: dict[str, None] = {}
    for document in documents:
        if document.metadata.name not in seen:
            seen[document.metadata.name] = None
    return tuple(seen.keys())


def _collect_environment_options(
    context: CreationContext,
    selected: NodeView | None,
) -> tuple[str, ...]:
    """Gather unique environment names from available documents."""

    sources: list[TaxonomyDocument] = [
        *context.available_systems,
        *context.available_subsystems,
        *context.available_stacks,
    ]
    if selected is not None:
        sources.append(selected.document)

    seen: dict[str, None] = {}
    for document in sources:
        for environment in document.spec.environments:
            if environment not in seen:
                seen[environment] = None

    for default_environment in ("dev", "prod"):
        if default_environment not in seen:
            seen[default_environment] = None

    return tuple(seen.keys())


def _collect_layer_type_options(
    context: CreationContext,
    selected: NodeView | None,
) -> tuple[str, ...]:
    """Gather unique layer types from the available documents with sensible defaults."""

    seen: dict[str, None] = {}

    def _record(value: str | None) -> None:
        if value:
            seen.setdefault(value, None)

    for document in context.available_layers:
        _record(_extract_layer_type(document))

    if selected is not None and selected.node_type == "layer":
        _record(_extract_layer_type(selected.document))

    if context.layer_types is not None:
        for definition in context.layer_types.definitions:
            _record(definition.name)

    for default in DEFAULT_LAYER_TYPES:
        seen.setdefault(default, None)

    return tuple(seen.keys())


def _extract_layer_type(document: TaxonomyDocument) -> str | None:
    """Best-effort extraction of layer type metadata."""

    return extract_layer_type(document)


def _resolve_parent_name(
    name: str | None,
    documents: Sequence[TaxonomyDocument],
    *,
    expected_type: str,
) -> str | None:
    if not name:
        return None
    for candidate in documents:
        if candidate.metadata.name == name and candidate.taxonomy_node_type == expected_type:
            return candidate.metadata.name
    return name


def _parent_of(
    node_name: str | None,
    documents: Sequence[TaxonomyDocument],
) -> str | None:
    if node_name is None:
        return None
    for doc in documents:
        if doc.metadata.name == node_name and doc.spec.parents:
            return doc.spec.parents.node
    return None
