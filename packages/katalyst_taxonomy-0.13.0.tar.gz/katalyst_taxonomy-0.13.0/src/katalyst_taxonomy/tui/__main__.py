"""Console entrypoint for the taxonomy Textual UI."""

from __future__ import annotations

import argparse
from pathlib import Path

from .app import run


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the katalyst taxonomy Textual UI.")
    parser.add_argument(
        "--path",
        "-p",
        type=Path,
        default=Path("."),
        help="Base path containing taxonomy files (default: current directory).",
    )
    args = parser.parse_args()
    run(args.path)


if __name__ == "__main__":
    main()
