"""Domain models and utilities for file diffs.

This module provides models for representing file changes and utilities
for generating unified diff output.
"""

from __future__ import annotations

import difflib
from dataclasses import dataclass
from enum import Enum
from pathlib import Path


class ChangeType(Enum):
    """Type of change in a file diff."""

    ADDED = "added"
    MODIFIED = "modified"
    DELETED = "deleted"
    UNCHANGED = "unchanged"


@dataclass(frozen=True)
class FileDiff:
    """Represents a diff between two versions of a file.

    Attributes:
        path: Relative path to the file.
        change_type: Type of change (added, modified, deleted, unchanged).
        old_content: Previous content (None for added files).
        new_content: New content (None for deleted files).
    """

    path: str
    change_type: ChangeType
    old_content: str | None = None
    new_content: str | None = None

    @property
    def has_changes(self) -> bool:
        """Check if there are actual changes."""
        return self.change_type != ChangeType.UNCHANGED

    def unified_diff(self, context_lines: int = 3) -> str:
        """Generate unified diff output.

        Args:
            context_lines: Number of context lines around changes.

        Returns:
            Unified diff string, empty if no changes.
        """
        if not self.has_changes:
            return ""

        old_lines = (self.old_content or "").splitlines(keepends=True)
        new_lines = (self.new_content or "").splitlines(keepends=True)

        # Add newline to last line if missing for proper diff output
        if old_lines and not old_lines[-1].endswith("\n"):
            old_lines[-1] += "\n"
        if new_lines and not new_lines[-1].endswith("\n"):
            new_lines[-1] += "\n"

        diff = difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{self.path}",
            tofile=f"b/{self.path}",
            n=context_lines,
        )
        return "".join(diff)

    @classmethod
    def from_files(
        cls,
        path: str,
        old_path: Path | None,
        new_path: Path | None,
    ) -> FileDiff:
        """Create a FileDiff by comparing two files.

        Args:
            path: Relative path for display.
            old_path: Path to old file (None if new file).
            new_path: Path to new file (None if deleted).

        Returns:
            FileDiff instance.
        """
        old_content: str | None = None
        new_content: str | None = None

        if old_path and old_path.exists():
            try:
                old_content = old_path.read_text()
            except (OSError, UnicodeDecodeError):
                old_content = None  # Binary or unreadable

        if new_path and new_path.exists():
            try:
                new_content = new_path.read_text()
            except (OSError, UnicodeDecodeError):
                new_content = None  # Binary or unreadable

        # Determine change type
        if old_content is None and new_content is not None:
            change_type = ChangeType.ADDED
        elif old_content is not None and new_content is None:
            change_type = ChangeType.DELETED
        elif old_content == new_content:
            change_type = ChangeType.UNCHANGED
        else:
            change_type = ChangeType.MODIFIED

        return cls(
            path=path,
            change_type=change_type,
            old_content=old_content,
            new_content=new_content,
        )

    @classmethod
    def from_content(
        cls,
        path: str,
        old_content: str | None,
        new_content: str | None,
    ) -> FileDiff:
        """Create a FileDiff from content strings.

        Args:
            path: Relative path for display.
            old_content: Previous content (None if new file).
            new_content: New content (None if deleted).

        Returns:
            FileDiff instance.
        """
        # Determine change type
        if old_content is None and new_content is not None:
            change_type = ChangeType.ADDED
        elif old_content is not None and new_content is None:
            change_type = ChangeType.DELETED
        elif old_content == new_content:
            change_type = ChangeType.UNCHANGED
        else:
            change_type = ChangeType.MODIFIED

        return cls(
            path=path,
            change_type=change_type,
            old_content=old_content,
            new_content=new_content,
        )


@dataclass(frozen=True)
class DiffSummary:
    """Summary of multiple file diffs.

    Attributes:
        diffs: Tuple of individual file diffs.
        component: Name of the component being diffed.
        from_version: Previous version.
        to_version: New version.
    """

    diffs: tuple[FileDiff, ...]
    component: str
    from_version: str
    to_version: str

    @property
    def added_count(self) -> int:
        """Count of added files."""
        return sum(1 for d in self.diffs if d.change_type == ChangeType.ADDED)

    @property
    def modified_count(self) -> int:
        """Count of modified files."""
        return sum(1 for d in self.diffs if d.change_type == ChangeType.MODIFIED)

    @property
    def deleted_count(self) -> int:
        """Count of deleted files."""
        return sum(1 for d in self.diffs if d.change_type == ChangeType.DELETED)

    @property
    def unchanged_count(self) -> int:
        """Count of unchanged files."""
        return sum(1 for d in self.diffs if d.change_type == ChangeType.UNCHANGED)

    @property
    def has_changes(self) -> bool:
        """Check if there are any changes."""
        return any(d.has_changes for d in self.diffs)

    @property
    def changed_files(self) -> tuple[FileDiff, ...]:
        """Get only the files with changes."""
        return tuple(d for d in self.diffs if d.has_changes)

    def format_summary(self) -> str:
        """Format a text summary of changes.

        Returns:
            Human-readable summary string.
        """
        lines = [
            f"{self.component}: {self.from_version} -> {self.to_version}",
        ]

        if not self.has_changes:
            lines.append("  No file changes")
            return "\n".join(lines)

        if self.added_count:
            lines.append(f"  {self.added_count} file(s) added")
        if self.modified_count:
            lines.append(f"  {self.modified_count} file(s) modified")
        if self.deleted_count:
            lines.append(f"  {self.deleted_count} file(s) deleted")

        return "\n".join(lines)

    def format_full_diff(self, context_lines: int = 3) -> str:
        """Format the full unified diff output.

        Args:
            context_lines: Number of context lines around changes.

        Returns:
            Complete unified diff for all changed files.
        """
        parts = [self.format_summary(), ""]

        for diff in self.changed_files:
            parts.append(diff.unified_diff(context_lines))

        return "\n".join(parts)


def compare_directories(
    old_dir: Path | None,
    new_dir: Path,
    component: str,
    from_version: str,
    to_version: str,
) -> DiffSummary:
    """Compare two directories and generate a diff summary.

    Args:
        old_dir: Path to old directory (None for new component).
        new_dir: Path to new directory.
        component: Component name.
        from_version: Old version string.
        to_version: New version string.

    Returns:
        DiffSummary with all file diffs.
    """
    diffs: list[FileDiff] = []

    # Collect all files from both directories
    old_files: set[str] = set()
    new_files: set[str] = set()

    if old_dir and old_dir.exists():
        for f in old_dir.rglob("*"):
            if f.is_file():
                old_files.add(str(f.relative_to(old_dir)))

    if new_dir.exists():
        for f in new_dir.rglob("*"):
            if f.is_file():
                new_files.add(str(f.relative_to(new_dir)))

    # All files to compare
    all_files = old_files | new_files

    for rel_path in sorted(all_files):
        old_path = old_dir / rel_path if old_dir else None
        new_path = new_dir / rel_path

        diff = FileDiff.from_files(
            path=rel_path,
            old_path=old_path,
            new_path=new_path if rel_path in new_files else None,
        )
        diffs.append(diff)

    return DiffSummary(
        diffs=tuple(diffs),
        component=component,
        from_version=from_version,
        to_version=to_version,
    )
