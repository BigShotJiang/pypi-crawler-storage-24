"""Domain models for Katalyst taxonomy."""

from katalyst_taxonomy.domain.errors import DocumentError, KatalystError, ValidationError
from katalyst_taxonomy.domain.events import Event, EventBus, EventType
from katalyst_taxonomy.domain.lock import (
    InstalledComponents,
    InstalledCore,
    InstalledPlugin,
    KatalystLock,
    LockMetadata,
)
from katalyst_taxonomy.taxonomy.documents import (
    TaxonomyDependencies,
    TaxonomyDocument,
    TaxonomyMetadata,
    TaxonomyParents,
    TaxonomySpec,
)
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

__all__ = [
    # Taxonomy
    "TaxonomyDocument",
    "TaxonomyMetadata",
    "TaxonomySpec",
    "TaxonomyParents",
    "TaxonomyDependencies",
    "EnvironmentDocument",
    # Lock file
    "KatalystLock",
    "LockMetadata",
    "InstalledCore",
    "InstalledPlugin",
    "InstalledComponents",
    # Events
    "Event",
    "EventType",
    "EventBus",
    # Errors
    "KatalystError",
    "ValidationError",
    "DocumentError",
]
