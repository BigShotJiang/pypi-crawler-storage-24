"""HTTP client for Katalyst taxonomy server."""

from __future__ import annotations

from types import TracebackType
from typing import Any

import httpx

from katalyst_taxonomy.client.models import (
    CreateNodeRequest,
    CreateNodeResponse,
    NodeResponse,
    TaxonomyResponse,
)


class KatalystClient:
    """Async HTTP client for Katalyst taxonomy server."""

    def __init__(
        self,
        base_url: str,
        timeout: float = 30.0,
    ) -> None:
        """Initialize the client.

        Args:
            base_url: Base URL of the Katalyst server (e.g., "http://localhost:8000")
            timeout: Request timeout in seconds
        """
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None

    @property
    def base_url(self) -> str:
        """Get the base URL."""
        return self._base_url

    async def __aenter__(self) -> KatalystClient:
        """Enter async context."""
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=self._timeout,
        )
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit async context."""
        if self._client:
            await self._client.aclose()
            self._client = None

    def _get_client(self) -> httpx.AsyncClient:
        """Get the HTTP client, raising if not in context."""
        if self._client is None:
            raise RuntimeError(
                "Client not initialized. Use 'async with KatalystClient(...) as client:'",
            )
        return self._client

    async def health(self) -> dict[str, Any]:
        """Check server health.

        Returns:
            Health check response with 'healthy' and 'version' fields.
        """
        client = self._get_client()
        response = await client.get("/health")
        response.raise_for_status()
        return response.json()  # type: ignore[no-any-return]

    async def get_taxonomy(self) -> TaxonomyResponse:
        """Get the full taxonomy.

        Returns:
            TaxonomyResponse with documents, environments, and qualified names.
        """
        client = self._get_client()
        response = await client.get("/taxonomy")
        response.raise_for_status()
        return TaxonomyResponse.from_dict(response.json())

    async def get_node(self, name: str) -> NodeResponse:
        """Get a single taxonomy node by name.

        Args:
            name: Name of the node to retrieve.

        Returns:
            NodeResponse with the node details.

        Raises:
            httpx.HTTPStatusError: If node not found (404) or other HTTP error.
        """
        client = self._get_client()
        response = await client.get(f"/taxonomy/nodes/{name}")
        response.raise_for_status()
        return NodeResponse.from_dict(response.json())

    async def create_node(self, request: CreateNodeRequest) -> CreateNodeResponse:
        """Create a new taxonomy node.

        Args:
            request: CreateNodeRequest with node details.

        Returns:
            CreateNodeResponse indicating success or failure.
        """
        client = self._get_client()
        response = await client.post("/taxonomy/nodes", json=request.to_dict())
        response.raise_for_status()
        return CreateNodeResponse.from_dict(response.json())
