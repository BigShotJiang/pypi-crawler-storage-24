"""Ignore file support for taxonomy discovery."""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

IGNOREFILE_NAME = ".taxignore"


@dataclass(frozen=True, slots=True)
class IgnoreRule:
    """Represents a single ignore rule from .taxignore."""

    pattern: str
    negate: bool
    directory_only: bool


class TaxonomyIgnore:
    """Evaluator for .taxignore-style rules."""

    def __init__(self, *, base_path: Path, rules: Sequence[IgnoreRule]) -> None:
        self._base_path = base_path
        self._rules: Sequence[IgnoreRule] = rules

    def should_ignore(self, path: Path, *, is_dir: bool) -> bool:
        """Check if a path should be ignored based on rules."""
        try:
            relative = path.relative_to(self._base_path)
        except ValueError:
            relative = path
        if str(relative) == ".":
            relative = Path("")

        rel_str = relative.as_posix()
        matched = False
        for rule in self._rules:
            if self._matches_rule(rule, relative, rel_str, is_dir):
                matched = not rule.negate
        return matched

    def _matches_rule(
        self,
        rule: IgnoreRule,
        relative_path: Path,
        rel_str: str,
        is_dir: bool,
    ) -> bool:
        """Check if a path matches a single rule."""
        candidates: list[tuple[str, bool]] = [(rel_str, is_dir)]
        if is_dir:
            candidates.append((f"{rel_str}/", True))

        # Parent directories should be considered directories.
        parent = relative_path.parent
        while str(parent) not in {"", "."}:
            parent_str = parent.as_posix()
            candidates.append((parent_str, True))
            candidates.append((f"{parent_str}/", True))
            parent = parent.parent

        if "/" not in rule.pattern:
            candidates.append((relative_path.name, False))

        pattern = rule.pattern
        for value, candidate_is_dir in candidates:
            if not value:
                continue
            if rule.directory_only and not candidate_is_dir:
                continue
            if fnmatch.fnmatchcase(value, pattern):
                return True
        return False


def parse_rule(raw_pattern: str) -> IgnoreRule | None:
    """Parse a single line from .taxignore into an IgnoreRule."""
    pattern = raw_pattern.strip()
    if not pattern or pattern.startswith("#"):
        return None

    negate = pattern.startswith("!")
    if negate:
        pattern = pattern[1:]

    directory_only = pattern.endswith("/")
    if directory_only:
        pattern = pattern[:-1]

    pattern = pattern.lstrip("/")
    if not pattern:
        return None

    return IgnoreRule(pattern=pattern, negate=negate, directory_only=directory_only)


def load_ignore(base_path: Path) -> TaxonomyIgnore | None:
    """Load ignore rules from ``.taxignore`` under ``base_path``."""
    base_dir = base_path.parent if base_path.is_file() else base_path
    ignore_file = base_dir / IGNOREFILE_NAME
    if not ignore_file.exists():
        return None

    rules: list[IgnoreRule] = []
    try:
        with ignore_file.open("r", encoding="utf-8") as handle:
            for line in handle:
                rule = parse_rule(line)
                if rule is not None:
                    rules.append(rule)
    except OSError:
        return None

    # Always ignore the ignore file itself.
    rules.append(IgnoreRule(pattern=IGNOREFILE_NAME, negate=False, directory_only=False))

    if not rules:
        return None
    return TaxonomyIgnore(base_path=base_dir, rules=rules)
