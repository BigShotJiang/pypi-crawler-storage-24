"""Discovery strategies for finding taxonomy YAML files."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

LAYER_FILENAMES: tuple[str, ...] = ("layer.yaml", "layer.yml")


class DiscoveryStrategy(Protocol):
    """Strategy for discovering taxonomy YAML files within a filesystem layout."""

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        """Return the YAML file paths relative to the base directory."""
        ...


@dataclass(frozen=True, slots=True)
class SingleFileStrategy:
    """Treat the provided base path as a single YAML file or directory with YAML files."""

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        if base_path.is_file():
            return (base_path,)

        if base_path.is_dir():
            candidates = tuple(
                path
                for path in base_path.iterdir()
                if path.is_file() and path.suffix.lower() in (".yaml", ".yml")
            )
            if candidates:
                return tuple(sorted(candidates))

        for candidate in (base_path / "taxonomy.yaml", base_path / "taxonomy.yml"):
            if candidate.exists():
                return (candidate,)

        return ()


@dataclass(frozen=True, slots=True)
class RecursiveStrategy:
    """Search all YAML files recursively beneath the base path."""

    extensions: tuple[str, ...] = (".yaml", ".yml")
    ignore_dirs: tuple[str, ...] = (
        ".git",
        ".venv",
        "node_modules",
        "__pycache__",
        ".tox",
        ".mypy_cache",
        ".ruff_cache",
        "charts",
        "templates",
        "tests",
        "layer_types",  # Katalyst layer type templates (contain Jinja2 placeholders)
    )

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        if not base_path.exists():
            return ()

        matched: list[Path] = []
        stack: list[Path] = [base_path]

        while stack:
            current = stack.pop()

            if current.is_dir():
                if current != base_path and current.name in self.ignore_dirs:
                    continue

                layer_document = _find_layer_document(current)
                if layer_document is not None:
                    matched.append(layer_document)
                    continue

                try:
                    children = list(current.iterdir())
                except OSError:
                    continue

                for child in children:
                    stack.append(child)
                continue

            if current.is_file() and current.suffix.lower() in self.extensions:
                matched.append(current)

        return tuple(matched)


def _find_layer_document(directory: Path) -> Path | None:
    """Find layer document in a directory."""
    for candidate_name in LAYER_FILENAMES:
        candidate = directory / candidate_name
        if candidate.is_file():
            return candidate
    return None
