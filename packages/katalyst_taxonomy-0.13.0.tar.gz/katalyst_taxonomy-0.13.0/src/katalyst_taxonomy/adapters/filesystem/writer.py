"""Filesystem writer for taxonomy nodes."""

from __future__ import annotations

from pathlib import Path
from typing import Sequence, cast

from katalyst_taxonomy.taxonomy.documents import TaxonomyDocument
from katalyst_taxonomy.templates.rendering import render_tokens

# File names for each node type
NODE_TYPE_FILES: dict[str, str] = {
    "system": "system.yaml",
    "subsystem": "sub_system.yaml",
    "stack": "stack.yaml",
    "layer": "layer.yaml",
    "organization": "organization.yaml",
    "program": "program.yaml",
    "project": "project.yaml",
    "team": "team.yaml",
    "team_member": "team_member.yaml",
}

# Default templates embedded in the adapter
DEFAULT_TEMPLATES: dict[str, str] = {
    "system": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: system
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    layout: root
  environments:
    - "{{ primary_environment }}"
  dependsOn:
    nodes: []
""",
    "subsystem": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: subsystem
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    layout: root
  parents:
    node: "{{ parent_system }}"
  environments:
    - "{{ primary_environment }}"
  dependsOn:
    nodes:
      - "{{ parent_system }}"
""",
    "stack": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: stack
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    layout: root
  parents:
    node: "{{ parent_subsystem }}"
  environments:
    - "{{ primary_environment }}"
  dependsOn:
    nodes:
      - "{{ parent_subsystem }}"
""",
    "layer": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: layer
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    layout: root
    layerType: "{{ layer_type }}"
  parents:
    node: "{{ parent_stack }}"
  environments:
    - "{{ primary_environment }}"
  dependsOn:
    nodes:
      - "{{ parent_stack }}"
  extensions: {}
""",
    "organization": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: organization
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  environments:
    - "{{ primary_environment }}"
""",
    "program": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: program
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  parents:
    node: "{{ parent }}"
  environments:
    - "{{ primary_environment }}"
""",
    "project": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: project
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  parents:
    node: "{{ parent }}"
  environments:
    - "{{ primary_environment }}"
  project:
    status: active
""",
    "team": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: team
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  parents:
    node: "{{ parent }}"
  environments:
    - "{{ primary_environment }}"
  team:
    unitType: squad
""",
    "team_member": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: team_member
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  parents:
    node: "{{ parent }}"
  environments:
    - "{{ primary_environment }}"
  teamMember:
    role: engineer
    email: "{{ primary_owner }}"
""",
}


class FilesystemWriter:
    """Adapter for writing taxonomy nodes to the filesystem.

    Implements the TaxonomyWriter protocol from katalyst-core.
    """

    def __init__(self, template_dir: Path | None = None) -> None:
        """Initialize the writer.

        Args:
            template_dir: Optional directory containing custom templates.
                If not provided, uses built-in default templates.
        """
        self._template_dir = template_dir

    def write_document(self, document: TaxonomyDocument, path: Path) -> None:
        """Write a taxonomy document to the specified path.

        This writes the document directly as YAML without template processing.
        """
        from typing import Any

        import yaml

        path.parent.mkdir(parents=True, exist_ok=True)

        spec: dict[str, Any] = {
            "description": document.spec.description or "",
            "owners": list(document.spec.owners) if document.spec.owners else [],
            "environments": (
                list(document.spec.environments) if document.spec.environments else []
            ),
        }

        # Add optional spec fields
        if document.spec.parents:
            spec["parents"] = {"node": document.spec.parents.node}
        if document.spec.annotations:
            spec["annotations"] = dict(document.spec.annotations)
        if document.spec.depends_on:
            spec["dependsOn"] = {"nodes": list(document.spec.depends_on.nodes or [])}

        data: dict[str, Any] = {
            "apiVersion": document.api_version,
            "kind": document.kind,
            "metadata": {"name": document.metadata.name},
            "taxonomyNodeType": document.taxonomy_node_type,
            "spec": spec,
        }

        with path.open("w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, sort_keys=False)

    def create_node(
        self,
        path: Path,
        node_type: str,
        name: str,
        **kwargs: object,
    ) -> Path:
        """Create a new taxonomy node from a template.

        Args:
            path: Base path for the taxonomy (repo root).
            node_type: Type of node (system, subsystem, stack, layer).
            name: Name of the node.
            **kwargs: Additional fields (description, owners, environments,
                parent, parent_subsystem, parent_system, layer_type).

        Returns:
            Path to the created file.

        Raises:
            FileExistsError: If the target file already exists.
            ValueError: If the node_type is invalid.
        """
        if node_type not in NODE_TYPE_FILES:
            raise ValueError(f"Invalid node type: {node_type}")

        # Determine the target directory and file
        target_dir = self._compute_target_dir(path, node_type, name, kwargs)
        target_file = target_dir / NODE_TYPE_FILES[node_type]

        if target_file.exists():
            raise FileExistsError(f"Node already exists at: {target_file}")

        # Build the context for template rendering
        context = self._build_context(name, node_type, kwargs)

        # Get and render the template
        template = self._get_template(node_type)
        rendered = render_tokens(template, context)

        # Write the file
        target_dir.mkdir(parents=True, exist_ok=True)
        target_file.write_text(rendered, encoding="utf-8")

        return target_file

    def _compute_target_dir(
        self,
        base_path: Path,
        node_type: str,
        name: str,
        kwargs: dict[str, object],
    ) -> Path:
        """Compute the target directory for a node.

        Directory structure:
        - system: {base}/
        - subsystem: {base}/{subsystem_name}/
        - stack: {base}/{subsystem_name}/{stack_name}/
        - layer: {base}/{subsystem_name}/{stack_name}/{layer_name}/
        - organization: {base}/
        - program: {base}/{program_name}/
        - project: {base}/{project_name}/
        - team: {base}/{team_name}/
        - team_member: {base}/{parent_team}/{member_name}/
        """
        if node_type in ("system", "organization"):
            return base_path

        if node_type == "subsystem":
            return base_path / name

        if node_type == "stack":
            parent_subsystem = kwargs.get("parent_subsystem") or kwargs.get("parent")
            if parent_subsystem:
                return base_path / str(parent_subsystem) / name
            return base_path / name

        if node_type == "layer":
            parent_subsystem = kwargs.get("parent_subsystem")
            parent_stack = kwargs.get("parent")
            if parent_subsystem and parent_stack:
                return base_path / str(parent_subsystem) / str(parent_stack) / name
            if parent_stack:
                return base_path / str(parent_stack) / name
            return base_path / name

        # Portfolio/organizational types with a parent
        if node_type in ("program", "project", "team", "team_member"):
            parent = kwargs.get("parent")
            if parent:
                return base_path / str(parent) / name
            return base_path / name

        return base_path / name

    def _build_context(
        self,
        name: str,
        node_type: str,
        kwargs: dict[str, object],
    ) -> dict[str, str]:
        """Build the template context from creation parameters."""
        # Extract values from kwargs
        description = kwargs.get("description")
        owners = kwargs.get("owners", ())
        environments = kwargs.get("environments", ())
        parent = kwargs.get("parent")
        parent_subsystem = kwargs.get("parent_subsystem")
        parent_system = kwargs.get("parent_system")
        layer_type = kwargs.get("layer_type")

        # Determine primary values
        if isinstance(owners, (list, tuple)) and owners:
            owners_seq = cast(Sequence[object], owners)
            primary_owner = str(owners_seq[0])
        else:
            primary_owner = "team@example.com"

        if isinstance(environments, (list, tuple)) and environments:
            envs_seq = cast(Sequence[object], environments)
            primary_environment = str(envs_seq[0])
        else:
            primary_environment = "dev"

        context: dict[str, str] = {
            "name": name,
            "description": str(description) if description else f"{node_type.title()} {name}",
            "primary_owner": primary_owner,
            "primary_environment": primary_environment,
        }

        # Add parent references based on node type
        if node_type == "subsystem":
            context["parent_system"] = str(parent or parent_system or "")

        if node_type == "stack":
            context["parent_subsystem"] = str(parent or "")
            if parent_system:
                context["parent_system"] = str(parent_system)

        if node_type == "layer":
            context["parent_stack"] = str(parent or "")
            context["layer_type"] = str(layer_type) if layer_type else "app-docker"
            if parent_subsystem:
                context["parent_subsystem"] = str(parent_subsystem)
            if parent_system:
                context["parent_system"] = str(parent_system)

        # Portfolio/organizational types use generic parent reference
        if node_type in ("program", "project", "team", "team_member"):
            context["parent"] = str(parent or "")

        return context

    def _get_template(self, node_type: str) -> str:
        """Get the template content for a node type."""
        # If a template directory is configured, try to load from there
        if self._template_dir:
            template_file = self._template_dir / f"{node_type}.yaml"
            if template_file.exists():
                return template_file.read_text(encoding="utf-8")

        # Fall back to default embedded templates
        if node_type in DEFAULT_TEMPLATES:
            return DEFAULT_TEMPLATES[node_type]

        raise ValueError(f"No template found for node type: {node_type}")
