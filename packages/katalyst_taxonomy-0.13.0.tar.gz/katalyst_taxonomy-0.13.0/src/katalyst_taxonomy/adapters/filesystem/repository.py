"""Filesystem-backed taxonomy repository implementation."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Sequence, cast

import yaml

from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.taxonomy.documents import (
    API_VERSION,
    KIND,
    TaxonomyDependencies,
    TaxonomyDocument,
    TaxonomyMetadata,
    TaxonomyParents,
    TaxonomySpec,
)
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

from .discovery import DiscoveryStrategy, RecursiveStrategy
from .ignore import IGNOREFILE_NAME, load_ignore

ENVIRONMENT_KIND = "Environment"


def _as_mapping(value: object) -> dict[str, Any]:
    """Convert a value to a string-keyed mapping."""
    if isinstance(value, Mapping):
        mapping_value = cast(Mapping[Any, Any], value)
        result: dict[str, Any] = {}
        for raw_key, raw_value in mapping_value.items():
            result[str(raw_key)] = raw_value
        return result
    return {}


def _document_from_mapping(mapping: Mapping[str, Any], *, source_path: Path) -> TaxonomyDocument:
    """Convert a raw mapping to a TaxonomyDocument."""
    metadata_raw = _as_mapping(mapping.get("metadata"))
    spec_raw = _as_mapping(mapping.get("spec"))

    labels_raw = _as_mapping(metadata_raw.get("labels"))
    labels: dict[str, str] = {}
    for key, value in labels_raw.items():
        labels[str(key)] = str(value)
    metadata = TaxonomyMetadata(
        name=str(metadata_raw.get("name", "")),
        labels=labels,
    )

    depends_on = None
    depends_section = _as_mapping(spec_raw.get("dependsOn"))
    nodes_value = depends_section.get("nodes")
    if isinstance(nodes_value, Sequence) and not isinstance(nodes_value, (str, bytes, bytearray)):
        node_iter = cast(Sequence[object], nodes_value)
        node_names: list[str] = []
        for raw_node in node_iter:
            if raw_node:
                node_names.append(str(raw_node))
        if node_names:
            depends_on = TaxonomyDependencies(nodes=tuple(node_names))

    parents = None
    parents_section = _as_mapping(spec_raw.get("parents"))
    parent_node = parents_section.get("node")
    if isinstance(parent_node, str) and parent_node:
        parents = TaxonomyParents(node=parent_node)

    owners_value = spec_raw.get("owners")
    owners_list: list[str] = []
    if isinstance(owners_value, Sequence) and not isinstance(owners_value, (str, bytes, bytearray)):
        owner_iter = cast(Sequence[object], owners_value)
        for raw_owner in owner_iter:
            if raw_owner:
                owners_list.append(str(raw_owner))
    owners = tuple(owners_list)
    annotations_raw = _as_mapping(spec_raw.get("annotations"))
    extensions_raw = _as_mapping(spec_raw.get("extensions"))
    annotations: dict[str, str] = {}
    for key, value in annotations_raw.items():
        annotations[str(key)] = str(value)
    extensions: dict[str, Any] | None = None
    if extensions_raw:
        extensions = dict(extensions_raw)

    description_value = spec_raw.get("description")
    if description_value is None:
        description: str | None = None
    else:
        description = str(description_value)

    environments_value = spec_raw.get("environments")
    environments_list: list[str] = []
    if isinstance(environments_value, Sequence) and not isinstance(
        environments_value,
        (str, bytes, bytearray),
    ):
        environments_list = [str(env) for env in cast(Sequence[object], environments_value) if env]
    environments = tuple(environments_list)

    spec = TaxonomySpec(
        description=description,
        owners=owners,
        annotations=annotations,
        depends_on=depends_on,
        parents=parents,
        extensions=extensions,
        environments=environments,
    )

    return TaxonomyDocument(
        api_version=str(mapping.get("apiVersion", "")),
        kind=str(mapping.get("kind", "")),
        metadata=metadata,
        taxonomy_node_type=str(mapping.get("taxonomyNodeType", "")),
        spec=spec,
        source_path=source_path,
    )


def _environment_from_mapping(
    payload: Mapping[str, object],
    *,
    source_path: Path,
) -> EnvironmentDocument:
    """Create an EnvironmentDocument from a raw mapping."""
    api_version = str(payload.get("apiVersion", ""))
    kind = str(payload.get("kind", ""))
    if api_version != API_VERSION or kind != ENVIRONMENT_KIND:
        raise ValueError(
            f"Unsupported environment document (apiVersion={api_version!r}, kind={kind!r})",
        )

    metadata_raw = payload.get("metadata")
    if not isinstance(metadata_raw, Mapping):
        raise ValueError("Environment metadata must be a mapping.")
    metadata_mapping = cast(Mapping[str, object], metadata_raw)

    name_value = metadata_mapping.get("name")
    name = str(name_value if name_value is not None else "").strip()
    if not name:
        raise ValueError("Environment metadata.name cannot be blank.")

    spec_raw = payload.get("spec")
    if not isinstance(spec_raw, Mapping):
        raise ValueError("Environment spec must be a mapping.")
    spec_mapping = cast(Mapping[str, object], spec_raw)

    description_value = spec_mapping.get("description")
    description = str(description_value) if description_value is not None else None

    replacements_raw: object = spec_mapping.get("templateReplacements") or {}
    if not isinstance(replacements_raw, Mapping):
        raise ValueError("spec.templateReplacements must be an object.")
    replacements_mapping = cast(Mapping[str, object], replacements_raw)

    replacements: dict[str, str] = {}
    for raw_key, raw_value in replacements_mapping.items():
        key = str(raw_key).strip()
        if not key:
            continue
        replacements[key] = "" if raw_value is None else str(raw_value)

    layer_templates_raw: object = spec_mapping.get("layerTemplates") or {}
    if not isinstance(layer_templates_raw, Mapping):
        raise ValueError("spec.layerTemplates must be an object when provided.")
    layer_templates_mapping = cast(Mapping[str, object], layer_templates_raw)
    layer_templates: dict[str, dict[str, object]] = {}
    for raw_key, raw_value in layer_templates_mapping.items():
        if not raw_key:
            continue
        template_key = str(raw_key).strip()
        if not template_key:
            continue
        if not isinstance(raw_value, Mapping):
            raise ValueError(
                f"spec.layerTemplates.{template_key} must be an object "
                f"(environment={name}, path={source_path})",
            )
        layer_templates[template_key] = dict(cast(Mapping[str, object], raw_value))

    return EnvironmentDocument(
        name=name,
        description=description,
        template_replacements=replacements,
        layer_templates=layer_templates,
        source_path=source_path,
    )


def _document_error_list() -> list[DocumentError]:
    return []


def _environment_document_list() -> list[EnvironmentDocument]:
    return []


@dataclass
class FilesystemTaxonomyRepository:
    """Filesystem-backed repository that implements TaxonomyRepository protocol."""

    base_path: Path
    strategy: DiscoveryStrategy = field(default_factory=RecursiveStrategy)

    _documents: tuple[TaxonomyDocument, ...] | None = field(init=False, repr=False, default=None)
    _environment_documents: list[EnvironmentDocument] = field(
        init=False,
        repr=False,
        default_factory=_environment_document_list,
    )
    _errors: list[DocumentError] = field(
        init=False,
        repr=False,
        default_factory=_document_error_list,
    )

    def _parse_documents(self, path: Path) -> tuple[TaxonomyDocument, ...]:
        """Parse all documents from a single YAML file."""
        documents: list[TaxonomyDocument] = []
        index = 0
        try:
            with path.open("r", encoding="utf-8") as stream:
                try:
                    for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                        if not document:
                            continue
                        try:
                            mapping = _as_mapping(document)
                            api_version = str(mapping.get("apiVersion"))
                            kind = str(mapping.get("kind"))
                            if api_version != API_VERSION:
                                continue
                            if kind == KIND:
                                documents.append(_document_from_mapping(mapping, source_path=path))
                                continue
                            if kind == ENVIRONMENT_KIND:
                                self._environment_documents.append(
                                    _environment_from_mapping(mapping, source_path=path),
                                )
                                continue
                        except Exception as exc:
                            self._errors.append(
                                DocumentError(path=path, document_index=index, message=str(exc)),
                            )
                except yaml.YAMLError as exc:
                    self._errors.append(
                        DocumentError(path=path, document_index=index, message=str(exc)),
                    )
        except OSError as exc:
            self._errors.append(DocumentError(path=path, document_index=0, message=str(exc)))

        return tuple(documents)

    def _load_all(self) -> tuple[TaxonomyDocument, ...]:
        """Load all documents from the filesystem."""
        base = self.base_path
        if not base.exists():
            raise FileNotFoundError(f"Taxonomy path does not exist: {base}")

        documents: list[TaxonomyDocument] = []
        self._errors = []
        self._environment_documents = []

        layer_directories: set[Path] = set()
        candidates = [path for path in self.strategy.discover(base) if path.name != IGNOREFILE_NAME]
        candidates.sort(key=lambda p: (len(p.parts), str(p)))

        ignore = load_ignore(base)

        for path in candidates:
            if any(
                layer_dir in path.parents and path.parent != layer_dir
                for layer_dir in layer_directories
            ):
                continue

            if ignore and ignore.should_ignore(path, is_dir=path.is_dir()):
                continue

            parsed = self._parse_documents(path)
            documents.extend(parsed)

            if any(doc.taxonomy_node_type == "layer" for doc in parsed):
                layer_directories.add(path.parent)

        return tuple(documents)

    def load_documents(self, path: Path) -> tuple[TaxonomyDocument, ...]:
        """Load all taxonomy documents from path (implements TaxonomyRepository)."""
        self.base_path = path
        self._documents = self._load_all()
        return self._documents

    def load_environments(self, path: Path) -> tuple[EnvironmentDocument, ...]:
        """Load environment documents from path (implements TaxonomyRepository)."""
        if self._documents is None:
            self.load_documents(path)
        return tuple(self._environment_documents)

    def get_document(self, path: Path, name: str) -> TaxonomyDocument | None:
        """Get a single document by name (implements TaxonomyRepository)."""
        if self._documents is None:
            self.load_documents(path)
        if self._documents is None:
            return None
        return next((doc for doc in self._documents if doc.metadata.name == name), None)

    def errors(self) -> tuple[DocumentError, ...]:
        """Get all errors encountered during loading."""
        return tuple(self._errors)
