"""Filesystem adapter for Katalyst taxonomy."""

from katalyst_taxonomy.adapters.filesystem.discovery import (
    DiscoveryStrategy,
    RecursiveStrategy,
    SingleFileStrategy,
)
from katalyst_taxonomy.adapters.filesystem.ignore import TaxonomyIgnore, load_ignore
from katalyst_taxonomy.adapters.filesystem.lock import LOCK_FILE_PATH, LockFileRepository
from katalyst_taxonomy.adapters.filesystem.repository import FilesystemTaxonomyRepository
from katalyst_taxonomy.adapters.filesystem.writer import FilesystemWriter

__all__ = [
    "LOCK_FILE_PATH",
    "DiscoveryStrategy",
    "FilesystemTaxonomyRepository",
    "FilesystemWriter",
    "LockFileRepository",
    "RecursiveStrategy",
    "SingleFileStrategy",
    "TaxonomyIgnore",
    "load_ignore",
]
