"""Filesystem adapter for reading and writing Katalyst lock files."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence, cast

import yaml

from katalyst_taxonomy.domain.lock import (
    InstalledComponents,
    InstalledCore,
    InstalledPlugin,
    KatalystLock,
    LockMetadata,
)

# Default lock file location relative to repo root
LOCK_FILE_PATH = Path(".global/taxonomy/taxonomy.lock")


def parse_datetime(value: object) -> datetime:
    """Parse a datetime value from YAML."""
    if isinstance(value, datetime):
        # PyYAML may already parse datetime
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value
    if isinstance(value, str):
        # Parse ISO format string
        try:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError as e:
            raise ValueError(f"Invalid datetime format: {value}") from e
    raise ValueError(f"Cannot parse datetime from: {type(value).__name__}")


def _as_mapping(value: object) -> dict[str, Any]:
    """Convert a value to a string-keyed mapping."""
    if isinstance(value, Mapping):
        mapping_value = cast(Mapping[Any, Any], value)
        result: dict[str, Any] = {}
        for raw_key, raw_value in mapping_value.items():
            result[str(raw_key)] = raw_value
        return result
    return {}


def _as_string_list(value: object) -> list[str]:
    """Convert a value to a list of strings."""
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [str(item) for item in cast(Sequence[object], value) if item]
    return []


def lock_from_mapping(mapping: Mapping[str, Any], *, source_path: Path) -> KatalystLock:
    """Convert a raw mapping to a KatalystLock."""
    # Parse metadata
    metadata_raw = _as_mapping(mapping.get("metadata"))
    metadata = LockMetadata(
        generated_at=parse_datetime(metadata_raw.get("generatedAt")),
        generated_by=str(metadata_raw.get("generatedBy", "")),
        katalyst_version=str(metadata_raw.get("katalystVersion", "")),
    )

    # Parse installed section
    installed_raw = _as_mapping(mapping.get("installed"))

    # Parse core
    core_raw = _as_mapping(installed_raw.get("core"))
    core = InstalledCore(
        version=str(core_raw.get("version", "")),
        schema_version=str(core_raw.get("schemaVersion", "")),
        installed_at=parse_datetime(core_raw.get("installedAt")),
        source=str(core_raw.get("source", "bundled")),
    )

    # Parse plugins
    plugins_raw = _as_mapping(installed_raw.get("plugins"))
    plugins: dict[str, InstalledPlugin] = {}
    for plugin_name, plugin_value in plugins_raw.items():
        plugin_raw = _as_mapping(plugin_value)
        plugins[plugin_name] = InstalledPlugin(
            version=str(plugin_raw.get("version", "")),
            installed_at=parse_datetime(plugin_raw.get("installedAt")),
            source=str(plugin_raw.get("source", "bundled")),
            canonical=tuple(_as_string_list(plugin_raw.get("canonical"))),
            custom=tuple(_as_string_list(plugin_raw.get("custom"))),
        )

    installed = InstalledComponents(core=core, plugins=plugins)

    return KatalystLock(
        api_version=str(mapping.get("apiVersion", "")),
        kind=str(mapping.get("kind", "")),
        metadata=metadata,
        installed=installed,
        source_path=source_path,
    )


def format_datetime(dt: datetime) -> str:
    """Format a datetime for YAML output."""
    # Ensure UTC and format as ISO string with Z suffix
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def lock_to_mapping(lock: KatalystLock) -> dict[str, Any]:
    """Convert a KatalystLock to a mapping suitable for YAML output."""
    # Build plugins section
    plugins_data: dict[str, Any] = {}
    for name, plugin in lock.installed.plugins.items():
        plugin_data: dict[str, Any] = {
            "version": plugin.version,
            "installedAt": format_datetime(plugin.installed_at),
            "source": plugin.source,
        }
        if plugin.canonical:
            plugin_data["canonical"] = list(plugin.canonical)
        if plugin.custom:
            plugin_data["custom"] = list(plugin.custom)
        plugins_data[name] = plugin_data

    return {
        "apiVersion": lock.api_version,
        "kind": lock.kind,
        "metadata": {
            "generatedAt": format_datetime(lock.metadata.generated_at),
            "generatedBy": lock.metadata.generated_by,
            "katalystVersion": lock.metadata.katalyst_version,
        },
        "installed": {
            "core": {
                "version": lock.installed.core.version,
                "schemaVersion": lock.installed.core.schema_version,
                "installedAt": format_datetime(lock.installed.core.installed_at),
                "source": lock.installed.core.source,
            },
            "plugins": plugins_data,
        },
    }


@dataclass
class LockFileRepository:
    """Filesystem adapter for Katalyst lock files.

    This adapter handles reading and writing the taxonomy.lock file
    which tracks installed components and their versions.
    """

    base_path: Path

    @property
    def lock_file_path(self) -> Path:
        """Get the full path to the lock file."""
        return self.base_path / LOCK_FILE_PATH

    def exists(self) -> bool:
        """Check if a lock file exists."""
        return self.lock_file_path.exists()

    def load(self) -> KatalystLock | None:
        """Load the lock file if it exists.

        Returns:
            The parsed KatalystLock, or None if the file doesn't exist.

        Raises:
            ValueError: If the lock file exists but is invalid.
        """
        lock_path = self.lock_file_path
        if not lock_path.exists():
            return None

        try:
            with lock_path.open("r", encoding="utf-8") as f:
                content = yaml.safe_load(f)

            if not content:
                return None

            mapping = _as_mapping(content)
            return lock_from_mapping(mapping, source_path=lock_path)

        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in lock file: {e}") from e

    def save(self, lock: KatalystLock) -> Path:
        """Save a lock file to the filesystem.

        Args:
            lock: The lock file to save.

        Returns:
            The path where the lock file was written.
        """
        lock_path = self.lock_file_path

        # Ensure parent directory exists
        lock_path.parent.mkdir(parents=True, exist_ok=True)

        # Convert to mapping and write
        data = lock_to_mapping(lock)

        # Add header comment
        header = "# Auto-generated by Katalyst - do not edit manually\n"

        with lock_path.open("w", encoding="utf-8") as f:
            f.write(header)
            yaml.safe_dump(data, f, sort_keys=False, default_flow_style=False)

        return lock_path

    def delete(self) -> bool:
        """Delete the lock file if it exists.

        Returns:
            True if the file was deleted, False if it didn't exist.
        """
        lock_path = self.lock_file_path
        if lock_path.exists():
            lock_path.unlink()
            return True
        return False

    def backup(self) -> Path | None:
        """Create a backup of the lock file.

        Returns:
            Path to the backup file, or None if no lock file exists.
        """
        lock_path = self.lock_file_path
        if not lock_path.exists():
            return None

        # Generate backup filename with timestamp
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        backup_path = lock_path.with_suffix(f".{timestamp}.backup")

        # Copy content
        content = lock_path.read_text(encoding="utf-8")
        backup_path.write_text(content, encoding="utf-8")

        return backup_path
