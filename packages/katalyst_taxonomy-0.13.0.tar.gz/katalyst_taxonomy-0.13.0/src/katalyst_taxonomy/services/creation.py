"""Node creation service - handles taxonomy node creation logic."""

from __future__ import annotations

from pathlib import Path

import katalyst_taxonomy
from katalyst_taxonomy.ports.filesystem import FilesystemPort
from katalyst_taxonomy.ports.taxonomy import (
    CreationRequest,
    CreationResult,
    TaxonomyWriter,
)
from katalyst_taxonomy.taxonomy.documents import TaxonomyDocument

# Directory names recognised as per-environment template sources.
_ENV_TEMPLATE_DIRS = frozenset({"environment-template", "env-template"})

# Directories in the layer type template that should not be copied into the layer.
_SKIP_DIRS = _ENV_TEMPLATE_DIRS | {"global"}

# Marker directory whose presence signals that the Just action plugin is installed.
_JUST_GLOBAL_MARKER = Path(".global") / "taxonomy" / "actions" / "just"

# Shared layer-level Justfile template shipped with the package.
_JUST_TEMPLATE_PATH = (
    Path(katalyst_taxonomy.__file__).parent
    / "templates"
    / "bundled"
    / "plugins"
    / "just"
    / "Justfile"
)


class CreationService:
    """Service for creating taxonomy nodes.

    This service validates creation requests, builds TaxonomyDocument
    instances, and delegates actual writing to a TaxonomyWriter.

    When creating a **layer** whose ``layer_type`` matches an installed
    layer-type template (under ``.global/taxonomy/layer_types/``), the
    service also scaffolds base files, per-environment directories, and
    active extension templates into the new layer directory.
    """

    def __init__(
        self,
        writer: TaxonomyWriter,
        existing_documents: tuple[TaxonomyDocument, ...] = (),
        filesystem: FilesystemPort | None = None,
    ) -> None:
        """Initialize the creation service.

        Args:
            writer: The writer to use for persisting nodes.
            existing_documents: Existing documents for validation.
            filesystem: Optional filesystem adapter for scaffolding.
                When omitted, scaffolding is skipped (backward-compatible).
        """
        self._writer = writer
        self._filesystem = filesystem
        self._docs_by_name: dict[str, list[TaxonomyDocument]] = {}
        for doc in existing_documents:
            self._docs_by_name.setdefault(doc.metadata.name, []).append(doc)

    def create(self, base_path: Path, request: CreationRequest) -> CreationResult:
        """Create a new taxonomy node.

        Args:
            base_path: The base path for the taxonomy.
            request: The creation request with node details.

        Returns:
            CreationResult indicating success or failure.
        """
        # Validate the request
        validation_error = self._validate_request(request)
        if validation_error:
            return CreationResult(success=False, error=validation_error)

        # Write the node using the writer
        try:
            path = self._writer.create_node(
                path=base_path,
                node_type=request.node_type,
                name=request.name,
                description=request.description,
                owners=request.owners,
                environments=request.environments,
                parent=request.parent,
                parent_subsystem=request.parent_subsystem,
                parent_system=request.parent_system,
                layer_type=request.layer_type,
            )
        except FileExistsError as exc:
            return CreationResult(success=False, error=str(exc))
        except ValueError as exc:
            return CreationResult(success=False, error=str(exc))

        # --- Scaffolding (layers only) ------------------------------------
        if request.node_type == "layer" and request.layer_type and self._filesystem is not None:
            self._scaffold_layer(
                base_path=base_path,
                layer_dir=path.parent,
                request=request,
            )

        return CreationResult(success=True, path=path)

    # ------------------------------------------------------------------
    # Scaffolding helpers
    # ------------------------------------------------------------------

    def _scaffold_layer(
        self,
        base_path: Path,
        layer_dir: Path,
        request: CreationRequest,
    ) -> None:
        """Copy layer-type template files into *layer_dir*.

        Steps:
        1. Copy non-env-template files with placeholder resolution.
        2. Expand env-template directories once per environment.
        3. Apply active extension templates.
        4. Install shared .global/ dependencies (skip-existing).
        5. Scaffold a layer-local Justfile when the Just plugin is installed.

        If the layer type is not installed the method returns silently,
        leaving only the ``layer.yaml`` that was already written.
        """
        assert self._filesystem is not None  # noqa: S101 – guarded by caller
        layer_type = request.layer_type or "app-docker"

        layer_type_path = base_path / ".global" / "taxonomy" / "layer_types" / layer_type
        if not self._filesystem.exists(layer_type_path):
            return

        context = self._build_scaffold_context(request)
        environments = request.environments or ("dev",)

        # 1. Copy base template tree (skip env-template dirs and layer.yaml)
        self._filesystem.copy_tree_rendered(
            layer_type_path,
            layer_dir,
            context,
            skip_names=_SKIP_DIRS,
            skip_root_file="layer.yaml",
        )

        # 2. Expand environment-template directories
        for env_dir_name in _ENV_TEMPLATE_DIRS:
            env_template_path = layer_type_path / env_dir_name
            if self._filesystem.exists(env_template_path):
                self._filesystem.copy_tree_rendered_per_env(
                    env_template_path,
                    layer_dir,
                    context,
                    environments,
                )

        # 3. Apply active extension templates (from plugin system)
        self._apply_extensions(base_path, layer_type_path, layer_dir, context, request)

        # 4. Install shared .global/ dependencies (skip-existing semantics)
        self._install_global_template(base_path, layer_type_path)

        # 5. Scaffold a layer-local Justfile (only when the Just plugin is installed)
        if self._filesystem.exists(base_path / _JUST_GLOBAL_MARKER):
            dest = layer_dir / "Justfile"
            if not self._filesystem.exists(dest) and _JUST_TEMPLATE_PATH.exists():
                self._filesystem.copy_file(_JUST_TEMPLATE_PATH, dest)

    def _build_scaffold_context(self, request: CreationRequest) -> dict[str, str]:
        """Build the placeholder context for template rendering."""
        primary_owner = request.owners[0] if request.owners else "team@example.com"
        primary_env = request.environments[0] if request.environments else "dev"

        return {
            "layer_name": request.name,
            "name": request.name,
            "description": request.description or f"Layer {request.name}",
            "owner_email": primary_owner,
            "primary_owner": primary_owner,
            "primary_environment": primary_env,
            "parent_stack": request.parent or "",
            "stack_name": request.parent or "",
            "parent_subsystem": request.parent_subsystem or "",
            "subsystem_name": request.parent_subsystem or "",
            "parent_system": request.parent_system or "",
            "system_name": request.parent_system or "",
            "layer_type": request.layer_type or "app-docker",
        }

    def _apply_extensions(
        self,
        base_path: Path,
        layer_type_path: Path,
        layer_dir: Path,
        context: dict[str, str],
        request: CreationRequest,
    ) -> None:
        """Resolve and apply active extension templates."""
        assert self._filesystem is not None  # noqa: S101

        plugins_path = base_path / ".global" / "taxonomy"
        if not self._filesystem.exists(plugins_path):
            return

        try:
            from katalyst_taxonomy.plugins.scaffolding import resolve_scaffolding_plan

            plan = resolve_scaffolding_plan(
                layer_type_name=request.layer_type or "app-docker",
                base_template_path=layer_type_path,
                plugins_path=plugins_path,
            )
        except Exception:  # noqa: BLE001 – best-effort; don't fail creation
            return

        for contribution in plan.extensions:
            if contribution.template_path and self._filesystem.exists(contribution.template_path):
                self._filesystem.copy_tree_rendered(
                    contribution.template_path,
                    layer_dir,
                    context,
                )

    def _install_global_template(
        self,
        base_path: Path,
        layer_type_path: Path,
    ) -> None:
        """Install shared ``.global/`` files from the layer type template.

        Files are copied with skip-existing semantics so user
        customisations are never overwritten.
        """
        assert self._filesystem is not None  # noqa: S101

        global_src = layer_type_path / "global"
        if not self._filesystem.exists(global_src):
            return

        global_dest = base_path / ".global"
        self._filesystem.copy_tree_no_overwrite(global_src, global_dest)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def _validate_request(self, request: CreationRequest) -> str | None:
        """Validate creation request, returning error message if invalid."""
        if not request.name:
            return "Node name is required"

        if request.node_type not in (
            "system",
            "subsystem",
            "stack",
            "layer",
            "organization",
            "program",
            "project",
            "team",
            "team_member",
        ):
            return f"Invalid node type: {request.node_type}"

        # Validate parent requirements based on node type
        if request.node_type == "subsystem":
            if not request.parent and not request.parent_system:
                return "Parent system is required when creating a subsystem"

        if request.node_type == "stack":
            if not request.parent:
                return "Parent subsystem is required when creating a stack"

        if request.node_type == "layer":
            if not request.parent:
                return "Parent stack is required when creating a layer"

        # Portfolio / organizational wing parent requirements
        if request.node_type == "program":
            if not request.parent:
                return "Parent organization is required when creating a program"

        if request.node_type == "project":
            if not request.parent:
                return "Parent program or organization is required when creating a project"

        if request.node_type == "team":
            if not request.parent:
                return "Parent organization or team is required when creating a team"

        if request.node_type == "team_member":
            if not request.parent:
                return "Parent team is required when creating a team member"

        return None
