"""Environment contract checking and updating for layer types.

When a layer type declares an ``environmentContract`` (via ``KNOWN_CONTRACTS``
in :mod:`katalyst_taxonomy.services.init`), this module provides helpers to:

1. **Check** whether the current ``environments.yaml`` satisfies the contract
   for a given layer type and set of environments.
2. **Update** ``environments.yaml`` with user-supplied values for missing keys.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

import yaml


@dataclass(frozen=True)
class MissingContractKey:
    """A single environment contract key that is not yet configured.

    Attributes:
        key: The missing configuration key (e.g. ``imageRegistry``).
        layer_type: Layer type that requires this key.
        environment: Environment in which the key is missing.
        description: Human-readable hint for the user.
    """

    key: str
    layer_type: str
    environment: str
    description: str = ""


def _get_known_contract(layer_type: str) -> tuple[str, ...]:
    """Return the ``layer_templates`` keys required by *layer_type*.

    Imports ``_KNOWN_CONTRACTS`` lazily to avoid circular imports.
    """
    from katalyst_taxonomy.services.init import KNOWN_CONTRACTS

    contract = KNOWN_CONTRACTS.get(layer_type)
    if contract is None:
        return ()
    return contract.layer_templates


def _get_key_description(key: str) -> str:
    """Return a human-readable description for a contract key."""
    from katalyst_taxonomy.services.init import ENV_KEY_DESCRIPTIONS

    return ENV_KEY_DESCRIPTIONS.get(key, key)


def _load_environments(base_path: Path) -> list[dict[str, Any]]:
    """Load and return all environment documents from ``environments.yaml``."""
    env_file = base_path / ".global" / "taxonomy" / "environments.yaml"
    if not env_file.exists():
        return []
    text = env_file.read_text(encoding="utf-8")
    docs: list[dict[str, Any]] = []
    for doc in yaml.safe_load_all(text):
        if isinstance(doc, dict):
            docs.append(cast(dict[str, Any], doc))
    return docs


def _get_env_name(doc: dict[str, Any]) -> str:
    """Extract the environment name from a document's metadata."""
    metadata: dict[str, Any] = doc.get("metadata") or {}
    name: str = metadata.get("name", "")
    return name


def _env_has_key(doc: dict[str, Any], layer_type: str, key: str) -> bool:
    """Check whether an environment document has a specific layerTemplates key."""
    spec: dict[str, Any] = doc.get("spec") or {}
    layer_templates: dict[str, Any] = spec.get("layerTemplates") or {}
    lt_block: dict[str, Any] = layer_templates.get(layer_type) or {}
    value: object = lt_block.get(key)
    return value is not None and value != ""


def get_configured_environments(base_path: Path) -> tuple[str, ...]:
    """Return the names of all environments defined in ``environments.yaml``.

    Args:
        base_path: Repository root containing ``.global/taxonomy/environments.yaml``.

    Returns:
        Tuple of environment names (e.g. ``("dev", "staging", "prod")``).
    """
    docs = _load_environments(base_path)
    names: list[str] = []
    for doc in docs:
        name = _get_env_name(doc)
        if name:
            names.append(name)
    return tuple(names)


def check_environment_contract(
    base_path: Path,
    layer_type: str,
    environments: tuple[str, ...],
) -> list[MissingContractKey]:
    """Check which contract keys are missing for *layer_type* in *environments*.

    Args:
        base_path: Repository root containing ``.global/taxonomy/environments.yaml``.
        layer_type: The layer type to check (e.g. ``app-docker``).
        environments: Environment names to check (e.g. ``("dev", "staging")``).

    Returns:
        List of :class:`MissingContractKey` for each missing key/environment pair.
        Empty list when the contract is fully satisfied.
    """
    required_keys = _get_known_contract(layer_type)
    if not required_keys:
        return []

    docs = _load_environments(base_path)

    # Index documents by environment name
    docs_by_env: dict[str, dict[str, Any]] = {}
    for doc in docs:
        name = _get_env_name(doc)
        if name:
            docs_by_env[name] = doc

    missing: list[MissingContractKey] = []
    for env_name in environments:
        doc = docs_by_env.get(env_name)
        for key in required_keys:
            if doc is None or not _env_has_key(doc, layer_type, key):
                missing.append(
                    MissingContractKey(
                        key=key,
                        layer_type=layer_type,
                        environment=env_name,
                        description=_get_key_description(key),
                    )
                )

    return missing


def update_environments_yaml(
    base_path: Path,
    updates: dict[str, dict[str, dict[str, str]]],
) -> None:
    """Write new layerTemplates values into ``environments.yaml``.

    *updates* is structured as::

        {
            "<env_name>": {
                "<layer_type>": {
                    "<key>": "<value>",
                    ...
                },
            },
        }

    Existing keys in the file are preserved; only the supplied keys are
    added or overwritten.

    Args:
        base_path: Repository root containing ``.global/taxonomy/environments.yaml``.
        updates: Nested dict of environment → layer_type → key → value.
    """
    env_file = base_path / ".global" / "taxonomy" / "environments.yaml"
    if not env_file.exists():
        return

    docs = _load_environments(base_path)
    if not docs:
        return

    for doc in docs:
        name = _get_env_name(doc)
        if name not in updates:
            continue

        env_updates = updates[name]
        spec = doc.setdefault("spec", {})
        layer_templates = spec.setdefault("layerTemplates", {})

        for lt_name, kv_pairs in env_updates.items():
            lt_block = layer_templates.setdefault(lt_name, {})
            lt_block.update(kv_pairs)

    # Write back as multi-document YAML
    parts: list[str] = []
    for doc in docs:
        parts.append(yaml.safe_dump(doc, sort_keys=False, default_flow_style=False))
    env_file.write_text("---\n".join(parts), encoding="utf-8")
