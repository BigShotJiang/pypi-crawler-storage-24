"""Rollback service for restoring from backups.

This module contains domain models and service logic for the `kata tax rollback` command.
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Protocol, runtime_checkable


class RollbackStatus(Enum):
    """Status of a rollback operation."""

    SUCCESS = "success"
    FAILED = "failed"
    NO_BACKUPS = "no_backups"
    BACKUP_NOT_FOUND = "backup_not_found"
    NOT_INITIALIZED = "not_initialized"
    CANCELLED = "cancelled"


@dataclass(frozen=True)
class BackupEntry:
    """Information about an available backup.

    Attributes:
        name: Backup directory name (e.g., "backup_20240115_143022").
        path: Full path to the backup directory.
        timestamp: When the backup was created.
        has_lock: Whether the backup contains a lock file.
    """

    name: str
    path: Path
    timestamp: datetime
    has_lock: bool = False

    @classmethod
    def from_path(cls, path: Path) -> BackupEntry | None:
        """Create a BackupEntry from a backup directory path.

        Args:
            path: Path to a backup directory.

        Returns:
            BackupEntry if valid, None otherwise.
        """
        if not path.is_dir():
            return None

        name = path.name
        if not name.startswith("backup_"):
            return None

        # Parse timestamp from name: backup_YYYYMMDD_HHMMSS
        try:
            timestamp_str = name[7:]  # Remove "backup_" prefix
            timestamp = datetime.strptime(timestamp_str, "%Y%m%d_%H%M%S")
            timestamp = timestamp.replace(tzinfo=timezone.utc)
        except ValueError:
            # Invalid timestamp format, use file mtime
            stat = path.stat()
            timestamp = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)

        has_lock = (path / "taxonomy.lock").exists()

        return cls(
            name=name,
            path=path,
            timestamp=timestamp,
            has_lock=has_lock,
        )


@dataclass(frozen=True)
class RollbackConfig:
    """Configuration for a rollback operation.

    Attributes:
        target_path: Root directory of the taxonomy repository.
        backup_name: Specific backup to restore (None for latest).
    """

    target_path: Path
    backup_name: str | None = None

    @property
    def taxonomy_root(self) -> Path:
        """Get the path to the taxonomy root directory."""
        return self.target_path / ".global" / "taxonomy"

    @property
    def backup_dir(self) -> Path:
        """Get the path to the backup directory."""
        return self.taxonomy_root / ".backups"


@dataclass(frozen=True)
class RollbackResult:
    """Result of a rollback operation.

    Attributes:
        status: The status of the operation.
        backup: The backup that was restored (if successful).
        error: Error message if the operation failed.
    """

    status: RollbackStatus
    backup: BackupEntry | None = None
    error: str | None = None

    @property
    def is_success(self) -> bool:
        """Check if the operation was successful."""
        return self.status == RollbackStatus.SUCCESS


@dataclass(frozen=True)
class ListBackupsResult:
    """Result of listing backups.

    Attributes:
        backups: Tuple of available backups (newest first).
        status: Status of the operation.
        error: Error message if the operation failed.
    """

    backups: tuple[BackupEntry, ...]
    status: RollbackStatus
    error: str | None = None


@runtime_checkable
class LockRepository(Protocol):
    """Protocol for lock file repository operations."""

    def exists(self) -> bool:
        """Check if a lock file exists."""
        ...


class RollbackService:
    """Service for managing backups and rollbacks.

    This service lists available backups and restores from them.
    """

    def __init__(self, lock_repository: LockRepository) -> None:
        """Initialize the service.

        Args:
            lock_repository: Repository for lock file operations.
        """
        self._lock_repo = lock_repository

    def list_backups(self, config: RollbackConfig) -> ListBackupsResult:
        """List available backups.

        Args:
            config: Configuration for the operation.

        Returns:
            ListBackupsResult with available backups sorted by timestamp (newest first).
        """
        # Check if initialized
        if not self._lock_repo.exists():
            return ListBackupsResult(
                backups=(),
                status=RollbackStatus.NOT_INITIALIZED,
            )

        backup_dir = config.backup_dir
        if not backup_dir.exists():
            return ListBackupsResult(
                backups=(),
                status=RollbackStatus.NO_BACKUPS,
            )

        # Find all backup directories
        backups: list[BackupEntry] = []
        for item in backup_dir.iterdir():
            entry = BackupEntry.from_path(item)
            if entry:
                backups.append(entry)

        if not backups:
            return ListBackupsResult(
                backups=(),
                status=RollbackStatus.NO_BACKUPS,
            )

        # Sort by timestamp (newest first)
        backups.sort(key=lambda b: b.timestamp, reverse=True)

        return ListBackupsResult(
            backups=tuple(backups),
            status=RollbackStatus.SUCCESS,
        )

    def rollback(self, config: RollbackConfig) -> RollbackResult:
        """Perform rollback to a backup.

        Args:
            config: Configuration for the rollback.

        Returns:
            RollbackResult with status and restored backup info.
        """
        # List available backups
        list_result = self.list_backups(config)

        if list_result.status == RollbackStatus.NOT_INITIALIZED:
            return RollbackResult(status=RollbackStatus.NOT_INITIALIZED)

        if list_result.status == RollbackStatus.NO_BACKUPS:
            return RollbackResult(status=RollbackStatus.NO_BACKUPS)

        # Find the target backup
        backup: BackupEntry | None = None

        if config.backup_name:
            # Find specific backup by name
            for entry in list_result.backups:
                if entry.name == config.backup_name:
                    backup = entry
                    break

            if backup is None:
                return RollbackResult(
                    status=RollbackStatus.BACKUP_NOT_FOUND,
                    error=f"Backup '{config.backup_name}' not found",
                )
        else:
            # Use latest backup
            backup = list_result.backups[0]

        # Perform the rollback
        try:
            self._restore_backup(config, backup)
            return RollbackResult(
                status=RollbackStatus.SUCCESS,
                backup=backup,
            )
        except Exception as e:
            return RollbackResult(
                status=RollbackStatus.FAILED,
                error=str(e),
            )

    def _restore_backup(self, config: RollbackConfig, backup: BackupEntry) -> None:
        """Restore files from a backup.

        Args:
            config: Rollback configuration.
            backup: Backup to restore.
        """
        # Restore lock file
        lock_backup = backup.path / "taxonomy.lock"
        if lock_backup.exists():
            lock_file = config.taxonomy_root / "taxonomy.lock"
            shutil.copy2(lock_backup, lock_file)

        # Future: Restore other backed up files (templates, configs, etc.)
        # For now, we only backup/restore the lock file

    def delete_backup(self, config: RollbackConfig, backup_name: str) -> RollbackResult:
        """Delete a specific backup.

        Args:
            config: Rollback configuration.
            backup_name: Name of the backup to delete.

        Returns:
            RollbackResult indicating success or failure.
        """
        backup_path = config.backup_dir / backup_name

        if not backup_path.exists():
            return RollbackResult(
                status=RollbackStatus.BACKUP_NOT_FOUND,
                error=f"Backup '{backup_name}' not found",
            )

        try:
            shutil.rmtree(backup_path)
            return RollbackResult(status=RollbackStatus.SUCCESS)
        except Exception as e:
            return RollbackResult(
                status=RollbackStatus.FAILED,
                error=str(e),
            )

    def cleanup_old_backups(
        self,
        config: RollbackConfig,
        keep_count: int = 5,
    ) -> tuple[int, list[str]]:
        """Remove old backups, keeping only the most recent ones.

        Args:
            config: Rollback configuration.
            keep_count: Number of recent backups to keep.

        Returns:
            Tuple of (number deleted, list of deleted backup names).
        """
        list_result = self.list_backups(config)

        if list_result.status != RollbackStatus.SUCCESS:
            return (0, [])

        if len(list_result.backups) <= keep_count:
            return (0, [])

        # Delete older backups (list is already sorted newest first)
        to_delete = list_result.backups[keep_count:]
        deleted: list[str] = []

        for backup in to_delete:
            result = self.delete_backup(config, backup.name)
            if result.is_success:
                deleted.append(backup.name)

        return (len(deleted), deleted)
