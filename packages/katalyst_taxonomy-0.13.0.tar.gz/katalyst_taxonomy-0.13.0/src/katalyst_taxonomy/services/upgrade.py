"""Upgrade service for updating taxonomy components.

This module contains domain models and service logic for the `kata tax upgrade` command.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Protocol, Sequence, runtime_checkable

from katalyst_taxonomy.domain.diff import DiffSummary, compare_directories
from katalyst_taxonomy.domain.version import is_upgrade as version_is_upgrade
from katalyst_taxonomy.ports.filesystem import FilesystemPort


class UpgradeStatus(Enum):
    """Status of an upgrade operation."""

    SUCCESS = "success"
    FAILED = "failed"
    UP_TO_DATE = "up_to_date"
    UPDATES_AVAILABLE = "updates_available"
    NOT_INITIALIZED = "not_initialized"
    CANCELLED = "cancelled"


def _to_tuple(value: Sequence[str] | None) -> tuple[str, ...]:
    """Convert a sequence to a tuple, or return empty tuple if None."""
    if value is None:
        return ()
    return tuple(value)


@dataclass(frozen=True)
class UpgradeConfig:
    """Configuration for upgrading taxonomy components.

    Attributes:
        target_path: Root directory of the taxonomy repository.
        source: Template source URI (default: "bundled").
        components: Specific components to upgrade, or empty for all.
        dry_run: If True, only check for updates without applying them.
        create_backup: If True, create a backup before upgrading.
        interactive: If True, prompt for confirmation before upgrading.
        show_diff: If True, generate file diffs for updates.
    """

    target_path: Path
    source: str = "bundled"
    components: tuple[str, ...] = ()
    dry_run: bool = False
    create_backup: bool = True
    interactive: bool = False
    show_diff: bool = False

    def __post_init__(self) -> None:
        """Convert sequences to tuples for immutability."""
        if type(self.components) is not tuple:
            object.__setattr__(self, "components", _to_tuple(self.components))  # type: ignore[arg-type]

    @property
    def taxonomy_root(self) -> Path:
        """Get the path to the taxonomy root directory."""
        return self.target_path / ".global" / "taxonomy"

    @property
    def backup_dir(self) -> Path:
        """Get the path to the backup directory."""
        return self.taxonomy_root / ".backups"


@dataclass(frozen=True)
class ComponentUpdate:
    """Represents an available update for a component.

    Attributes:
        name: Component name (e.g., "core", "layer_types").
        from_version: Currently installed version.
        to_version: Available version to upgrade to.
        changelog: Optional changelog/release notes.
    """

    name: str
    from_version: str
    to_version: str
    changelog: str | None = None


@dataclass(frozen=True)
class UpgradeResult:
    """Result of an upgrade operation.

    Attributes:
        status: The status of the operation.
        updates: Tuple of component updates (available or applied).
        backup_path: Path to the backup (if created).
        error: Error message if the operation failed.
        diffs: Tuple of diff summaries for each component (if requested).
    """

    status: UpgradeStatus
    updates: tuple[ComponentUpdate, ...] = ()
    backup_path: Path | None = None
    error: str | None = None
    diffs: tuple[DiffSummary, ...] = ()

    @property
    def is_success(self) -> bool:
        """Check if the operation was successful."""
        return self.status == UpgradeStatus.SUCCESS

    @property
    def has_diffs(self) -> bool:
        """Check if there are diff summaries available."""
        return len(self.diffs) > 0


@dataclass
class BackupInfo:
    """Information about a backup."""

    path: Path
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    lock_backup: Path | None = None


@runtime_checkable
class LockRepository(Protocol):
    """Protocol for lock file repository operations."""

    def exists(self) -> bool:
        """Check if a lock file exists."""
        ...

    def load(self) -> object | None:
        """Load the lock file."""
        ...


@runtime_checkable
class TemplateSourceProtocol(Protocol):
    """Protocol for template source operations needed by upgrade."""

    def get_latest_version(self, name: str) -> str:
        """Get the latest version of a package."""
        ...

    def fetch_package(self, name: str, version: str | None = None) -> object:
        """Fetch a package from this source."""
        ...


class UpgradeService:
    """Service for upgrading taxonomy components.

    This service checks for available updates and applies them.
    """

    def __init__(
        self,
        lock_repository: LockRepository,
        template_source: TemplateSourceProtocol,
        filesystem: FilesystemPort | None = None,
    ) -> None:
        """Initialize the service.

        Args:
            lock_repository: Repository for lock file operations.
            template_source: Source for fetching templates.
            filesystem: Filesystem port for file operations.  When *None*
                a :class:`~katalyst_taxonomy.adapters.filesystem.real.RealFilesystem`
                is created automatically so existing callers keep working.
        """
        self._lock_repo = lock_repository
        self._template_source = template_source

        if filesystem is None:
            from katalyst_taxonomy.ports.filesystem import RealFilesystem

            filesystem = RealFilesystem()
        self._fs = filesystem

    def check_updates(self, config: UpgradeConfig) -> UpgradeResult:
        """Check for available updates.

        Args:
            config: Configuration for the upgrade check.

        Returns:
            UpgradeResult with available updates.
        """
        # Check if initialized
        if not self._lock_repo.exists():
            return UpgradeResult(status=UpgradeStatus.NOT_INITIALIZED)

        # Load current lock
        lock = self._lock_repo.load()
        if lock is None:
            return UpgradeResult(status=UpgradeStatus.NOT_INITIALIZED)

        # Get available updates
        updates = self._find_updates(lock, config)

        if not updates:
            return UpgradeResult(status=UpgradeStatus.UP_TO_DATE, updates=())

        # Generate diffs if requested
        diffs: tuple[DiffSummary, ...] = ()
        if config.show_diff:
            diffs = self._generate_diffs(config, tuple(updates))

        return UpgradeResult(
            status=UpgradeStatus.UPDATES_AVAILABLE,
            updates=tuple(updates),
            diffs=diffs,
        )

    def upgrade(self, config: UpgradeConfig) -> UpgradeResult:
        """Perform upgrade operation.

        Args:
            config: Configuration for the upgrade.

        Returns:
            UpgradeResult with applied updates.
        """
        # First check for updates
        check_result = self.check_updates(config)

        # If no updates or not initialized, return as-is
        if check_result.status in (
            UpgradeStatus.UP_TO_DATE,
            UpgradeStatus.NOT_INITIALIZED,
        ):
            return check_result

        # Dry run - just return available updates
        if config.dry_run:
            return check_result

        # Create backup if requested
        backup_path: Path | None = None
        if config.create_backup:
            backup_info = self._create_backup(config)
            if backup_info:
                backup_path = backup_info.path

        try:
            # Apply updates
            applied_updates = self._apply_updates(config, check_result.updates)

            return UpgradeResult(
                status=UpgradeStatus.SUCCESS,
                updates=applied_updates,
                backup_path=backup_path,
            )
        except Exception as e:
            # Rollback on failure
            if backup_path and self._fs.exists(backup_path):
                self._rollback(config, backup_path)

            return UpgradeResult(
                status=UpgradeStatus.FAILED,
                updates=(),
                backup_path=backup_path,
                error=str(e),
            )

    def _create_backup(self, config: UpgradeConfig) -> BackupInfo | None:
        """Create a backup of the current taxonomy.

        Args:
            config: Upgrade configuration.

        Returns:
            BackupInfo if backup was created, None otherwise.
        """
        taxonomy_root = config.taxonomy_root
        if not self._fs.exists(taxonomy_root):
            return None

        # Create backup directory
        backup_dir = config.backup_dir
        self._fs.create_directory(backup_dir)

        # Generate backup name with timestamp
        timestamp = datetime.now(timezone.utc)
        backup_name = f"backup_{timestamp.strftime('%Y%m%d_%H%M%S')}"
        backup_path = backup_dir / backup_name

        # Copy lock file to backup
        lock_file = taxonomy_root / "taxonomy.lock"
        lock_backup: Path | None = None
        if self._fs.exists(lock_file):
            lock_backup = backup_path / "taxonomy.lock"
            self._fs.create_directory(backup_path)
            self._fs.copy_file(lock_file, lock_backup)

        return BackupInfo(
            path=backup_path,
            timestamp=timestamp,
            lock_backup=lock_backup,
        )

    def _rollback(self, config: UpgradeConfig, backup_path: Path) -> None:
        """Rollback to a previous backup.

        Args:
            config: Upgrade configuration.
            backup_path: Path to the backup to restore.
        """
        # Restore lock file
        lock_backup = backup_path / "taxonomy.lock"
        if self._fs.exists(lock_backup):
            lock_file = config.taxonomy_root / "taxonomy.lock"
            self._fs.copy_file(lock_backup, lock_file)

    def _apply_updates(
        self,
        config: UpgradeConfig,
        updates: tuple[ComponentUpdate, ...],
    ) -> tuple[ComponentUpdate, ...]:
        """Apply updates to installed components.

        Args:
            config: Upgrade configuration.
            updates: Updates to apply.

        Returns:
            Tuple of applied updates.
        """
        applied: list[ComponentUpdate] = []

        for update in updates:
            try:
                # Fetch the new package
                fetch_result = self._template_source.fetch_package(update.name, update.to_version)
                package_path = getattr(fetch_result, "path", None)

                if package_path is None:
                    continue

                # Copy templates to the taxonomy directory
                if update.name == "core":
                    self._copy_core_templates(config, package_path)
                else:
                    self._copy_plugin_templates(config, update.name, package_path)

                applied.append(update)

            except (KeyError, ValueError, OSError):
                # Skip failed updates
                continue

        return tuple(applied)

    def _copy_core_templates(self, config: UpgradeConfig, package_path: Path) -> None:
        """Copy core template files to taxonomy root.

        Args:
            config: Upgrade configuration.
            package_path: Path to the fetched core package.
        """
        taxonomy_root = config.taxonomy_root
        self._fs.create_directory(taxonomy_root)

        for item in package_path.iterdir():
            if item.is_file() and item.suffix in (".yaml", ".yml"):
                dest = taxonomy_root / item.name
                self._fs.copy_file(item, dest)

    def _copy_plugin_templates(
        self,
        config: UpgradeConfig,
        plugin_name: str,
        package_path: Path,
    ) -> None:
        """Copy plugin template files to taxonomy plugins directory.

        Args:
            config: Upgrade configuration.
            plugin_name: Name of the plugin.
            package_path: Path to the fetched plugin package.
        """
        if plugin_name == "layer_types":
            # For layer_types, copy to layer_types directory
            dest_dir = config.taxonomy_root / "layer_types"
        elif plugin_name == "cicd":
            # cicd lives directly at cicd/ (not plugins/cicd/)
            dest_dir = config.taxonomy_root / "cicd"
        else:
            dest_dir = config.taxonomy_root / "plugins" / plugin_name

        # Remove existing and copy new
        if self._fs.exists(dest_dir):
            self._fs.remove_directory(dest_dir)

        self._fs.copy_tree(package_path, dest_dir)

    def _find_updates(
        self,
        lock: object,
        config: UpgradeConfig,
    ) -> list[ComponentUpdate]:
        """Find available updates for installed components.

        Args:
            lock: Current lock file.
            config: Upgrade configuration.

        Returns:
            List of available updates.
        """
        updates: list[ComponentUpdate] = []

        # Access lock attributes dynamically since we use a protocol
        # In practice, this will be a KatalystLock
        installed = getattr(lock, "installed", None)
        if installed is None:
            return updates

        core = getattr(installed, "core", None)
        plugins = getattr(installed, "plugins", {})

        # Check which components to upgrade
        check_all = not config.components
        check_core = check_all or "core" in config.components

        # Check core version
        if check_core and core is not None:
            core_version = getattr(core, "version", "0.0.0")
            try:
                latest_core = self._template_source.get_latest_version("core")
                # Use semantic version comparison
                if self._is_newer_version(core_version, latest_core):
                    updates.append(
                        ComponentUpdate(
                            name="core",
                            from_version=core_version,
                            to_version=latest_core,
                        ),
                    )
            except (KeyError, ValueError):
                pass  # Source doesn't have core package

        # Check plugin versions
        if plugins:
            for plugin_name, plugin in plugins.items():
                check_plugin = check_all or plugin_name in config.components
                if not check_plugin:
                    continue

                plugin_version = getattr(plugin, "version", "0.0.0")
                try:
                    latest_plugin = self._template_source.get_latest_version(plugin_name)
                    # Use semantic version comparison
                    if self._is_newer_version(plugin_version, latest_plugin):
                        updates.append(
                            ComponentUpdate(
                                name=plugin_name,
                                from_version=plugin_version,
                                to_version=latest_plugin,
                            ),
                        )
                except (KeyError, ValueError):
                    pass  # Source doesn't have this plugin

        return updates

    def _is_newer_version(self, current: str, available: str) -> bool:
        """Check if available version is newer than current.

        Uses semantic version comparison.

        Args:
            current: Currently installed version.
            available: Available version.

        Returns:
            True if available is newer than current.
        """
        try:
            return version_is_upgrade(current, available)
        except ValueError:
            # Fall back to string comparison if version parsing fails
            return available != current

    def _generate_diffs(
        self,
        config: UpgradeConfig,
        updates: tuple[ComponentUpdate, ...],
    ) -> tuple[DiffSummary, ...]:
        """Generate file diffs for each update.

        Args:
            config: Upgrade configuration.
            updates: Updates to generate diffs for.

        Returns:
            Tuple of DiffSummary for each update.
        """
        diffs: list[DiffSummary] = []

        for update in updates:
            try:
                # Fetch the new package from source
                fetch_result = self._template_source.fetch_package(update.name, update.to_version)

                # Get path from fetch result
                new_path = getattr(fetch_result, "path", None)
                if new_path is None:
                    continue

                # Get current installed path
                old_path = self._get_installed_path(config, update.name)

                # Generate diff
                diff = compare_directories(
                    old_dir=old_path,
                    new_dir=new_path,
                    component=update.name,
                    from_version=update.from_version,
                    to_version=update.to_version,
                )
                diffs.append(diff)

            except (KeyError, ValueError, OSError):
                # Skip if we can't generate diff for this component
                continue

        return tuple(diffs)

    def _get_installed_path(self, config: UpgradeConfig, component: str) -> Path | None:
        """Get the path where a component is currently installed.

        Args:
            config: Upgrade configuration.
            component: Component name.

        Returns:
            Path to the installed component, or None if not installed.
        """
        taxonomy_root = config.taxonomy_root

        if component == "core":
            # Core templates are in the root taxonomy directory
            return taxonomy_root if self._fs.exists(taxonomy_root) else None

        # Plugins are in subdirectories
        plugin_path = taxonomy_root / "plugins" / component
        return plugin_path if self._fs.exists(plugin_path) else None
