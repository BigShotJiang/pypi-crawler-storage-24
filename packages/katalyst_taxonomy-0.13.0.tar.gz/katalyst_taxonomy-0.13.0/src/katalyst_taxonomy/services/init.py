"""Init service for initializing taxonomy repositories.

This module contains domain models and service logic for the `kata tax init` command.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Protocol, Sequence, runtime_checkable

import yaml

from katalyst_taxonomy.domain.lock import (
    InstalledComponents,
    InstalledCore,
    InstalledPlugin,
    KatalystLock,
    LockMetadata,
)
from katalyst_taxonomy.plugins._helpers import EMPTY_CONTRACT, EnvironmentContract
from katalyst_taxonomy.ports.filesystem import FilesystemPort
from katalyst_taxonomy.ports.init import (
    CollectedEnvironmentValues,
    EnvironmentChoice,
    EnvironmentValuePrompt,
    InitPrompt,
    LayerTypeChoice,
    PluginChoice,
)


@runtime_checkable
class TemplateSourceProtocol(Protocol):
    """Protocol for template source operations needed by init."""

    def fetch_package(self, name: str, version: str | None = None) -> object:
        """Fetch a package from this source."""
        ...

    def get_latest_version(self, name: str) -> str:
        """Get the latest version of a package."""
        ...


# Default paths
TAXONOMY_DIR = ".global/taxonomy"
LOCK_FILE_NAME = "taxonomy.lock"
ENVIRONMENTS_FILE_NAME = "environments.yaml"

# Available environments with descriptions and template replacements
AVAILABLE_ENVIRONMENTS: dict[str, dict[str, object]] = {
    "dev": {
        "description": "Development environment",
        "templateReplacements": {"ENV": "dev", "ENVIRONMENT": "development"},
    },
    "staging": {
        "description": "Staging environment for pre-production testing",
        "templateReplacements": {"ENV": "staging", "ENVIRONMENT": "staging"},
    },
    "prod": {
        "description": "Production environment",
        "templateReplacements": {"ENV": "prod", "ENVIRONMENT": "production"},
    },
}

# Available plugins with descriptions
AVAILABLE_PLUGINS: dict[str, str] = {
    "layer_types": "Layer type templates (app-docker, iac-terragrunt, k8s-argocd, etc.)",
    "cicd": "CICD workflow and job templates for GitHub Actions",
    "just": "Just command runner recipes for layer types and tools",
    "layer_actions": "Canonical action definitions for layer types and tools",
}

# Available layer types per plugin (fallback descriptions when source doesn't provide them)
_LAYER_TYPE_DESCRIPTIONS: dict[str, str] = {
    "app-docker": "Docker-based application scaffolding",
    "iac-terragrunt": "Terraform/Terragrunt infrastructure as code",
    "k8s-argocd": "Kubernetes with ArgoCD GitOps",
    "k8s-kustomize": "Kubernetes with Kustomize overlays",
}

# Backward-compatible export for TUI and tests.  The nested structure is
# retained so that code iterating ``AVAILABLE_LAYER_TYPES.values()`` still
# works.  This is populated from ``_LAYER_TYPE_DESCRIPTIONS`` above and
# will be superseded by source-driven discovery in the service layer.
AVAILABLE_LAYER_TYPES: dict[str, dict[str, str]] = {
    "layer_types": dict(_LAYER_TYPE_DESCRIPTIONS),
}

# Known environment contracts for bundled layer types.  These are used as a
# fallback when the template source does not provide LayerTypeDefinition
# objects (e.g. the "bundled" source in non-interactive mode).
KNOWN_CONTRACTS: dict[str, EnvironmentContract] = {
    "app-docker": EnvironmentContract(
        template_replacements=("environment_name",),
        layer_templates=("imageRegistry",),
    ),
    "app-bun": EnvironmentContract(
        template_replacements=("environment_name",),
        layer_templates=("imageRegistry",),
    ),
    "k8s-argocd": EnvironmentContract(
        template_replacements=("environment",),
        layer_templates=("environment_namespace", "argocd_project_environment"),
    ),
    "iac-terragrunt": EnvironmentContract(
        template_replacements=("environment",),
        layer_templates=("remote_state_bucket", "remote_state_region"),
    ),
    "k8s-kustomize": EnvironmentContract(
        template_replacements=("environment",),
        layer_templates=("namespace",),
    ),
}

# Human-readable descriptions for environment contract keys.
ENV_KEY_DESCRIPTIONS: dict[str, str] = {
    "environment": "Environment identifier",
    "environment_name": "Environment name",
    "environment_namespace": "Kubernetes namespace for this environment",
    "argocd_project_environment": "ArgoCD project name for this environment",
    "namespace": "Kubernetes namespace",
    "remote_state_bucket": "Terraform remote state S3 bucket name",
    "remote_state_region": "AWS region for remote state bucket",
    "imageRegistry": "Container image registry (e.g. 123456789.dkr.ecr.us-east-1.amazonaws.com)",
}

# Keys whose default can be derived from the environment name.
_AUTO_DERIVABLE_KEYS: frozenset[str] = frozenset(
    {
        "environment",
        "environment_name",
        "environment_namespace",
        "argocd_project_environment",
        "namespace",
    }
)


class InitStatus(Enum):
    """Status of an initialization operation."""

    SUCCESS = "success"
    FAILED = "failed"
    ALREADY_INITIALIZED = "already_initialized"
    CANCELLED = "cancelled"


def _to_tuple(value: Sequence[str] | None) -> tuple[str, ...]:
    """Convert a sequence to a tuple, or return empty tuple if None."""
    if value is None:
        return ()
    return tuple(value)


@dataclass(frozen=True)
class InitConfig:
    """Configuration for initializing a taxonomy repository.

    Attributes:
        target_path: Root directory where taxonomy will be initialized.
        source: Template source URI (default: "bundled").
        plugins: Tuple of plugin names to install.
        layer_types: Tuple of layer type names to install.
        environments: Tuple of environment names to create.
        interactive: Whether to prompt for user input.
        generate_agents_md: Whether to generate/append AGENTS.md file.
    """

    target_path: Path
    source: str = "bundled"
    plugins: tuple[str, ...] = ()
    layer_types: tuple[str, ...] = ()
    environments: tuple[str, ...] = ()
    interactive: bool = True
    generate_agents_md: bool = False

    def __post_init__(self) -> None:
        """Convert sequences to tuples for immutability."""
        # Use object.__setattr__ since dataclass is frozen
        # Type ignore needed because we accept Sequence but store tuple
        if type(self.plugins) is not tuple:
            object.__setattr__(self, "plugins", _to_tuple(self.plugins))  # type: ignore[arg-type]
        if type(self.layer_types) is not tuple:
            object.__setattr__(self, "layer_types", _to_tuple(self.layer_types))  # type: ignore[arg-type]
        if type(self.environments) is not tuple:
            object.__setattr__(self, "environments", _to_tuple(self.environments))  # type: ignore[arg-type]

    @property
    def taxonomy_root(self) -> Path:
        """Get the path to the taxonomy root directory."""
        return self.target_path / TAXONOMY_DIR

    @property
    def lock_file_path(self) -> Path:
        """Get the path to the lock file."""
        return self.taxonomy_root / LOCK_FILE_NAME

    @property
    def environments_file_path(self) -> Path:
        """Get the path to the environments file."""
        return self.taxonomy_root / ENVIRONMENTS_FILE_NAME


@dataclass(frozen=True)
class InitResult:
    """Result of an initialization operation.

    Attributes:
        status: The status of the operation.
        taxonomy_root: Path to the created taxonomy root (if successful).
        lock_file: Path to the created lock file (if successful).
        installed_plugins: Tuple of installed plugin names.
        installed_layer_types: Tuple of installed layer type names.
        error: Error message if the operation failed.
    """

    status: InitStatus
    taxonomy_root: Path | None = None
    lock_file: Path | None = None
    installed_plugins: tuple[str, ...] = ()
    installed_layer_types: tuple[str, ...] = ()
    error: str | None = None

    @property
    def is_success(self) -> bool:
        """Check if the operation was successful."""
        return self.status == InitStatus.SUCCESS


class InitService:
    """Service for initializing taxonomy repositories.

    This service orchestrates the initialization process using the provided
    ports (adapters) for user interaction and filesystem operations.

    Attributes:
        prompt: Adapter for user prompts and interaction.
        filesystem: Adapter for filesystem operations.
        template_source: Optional template source for fetching packages.
    """

    def __init__(
        self,
        prompt: InitPrompt,
        filesystem: FilesystemPort,
        template_source: TemplateSourceProtocol | None = None,
    ) -> None:
        """Initialize the service with required adapters.

        Args:
            prompt: Adapter for user prompts.
            filesystem: Adapter for filesystem operations.
            template_source: Optional source for fetching template packages.
        """
        self._prompt = prompt
        self._filesystem = filesystem
        self._template_source = template_source

    def initialize(self, config: InitConfig) -> InitResult:
        """Initialize a taxonomy repository.

        Args:
            config: Configuration for the initialization.

        Returns:
            Result of the initialization operation.
        """
        # Check if already initialized
        if self._filesystem.exists(config.lock_file_path):
            return InitResult(
                status=InitStatus.ALREADY_INITIALIZED,
                taxonomy_root=config.taxonomy_root,
                lock_file=config.lock_file_path,
            )

        # Determine plugins, layer types, and environments to install
        collected_env_values: list[CollectedEnvironmentValues] = []
        if config.interactive:
            plugins, layer_types, environments, collected_env_values = self._prompt_for_selections(
                config
            )

            # Create updated config with user selections for summary display
            summary_config = replace(
                config,
                plugins=tuple(plugins),
                layer_types=tuple(layer_types),
                environments=tuple(environments),
            )

            # Display summary and confirm
            self._prompt.display_summary(summary_config)
            if not self._prompt.confirm("Proceed with initialization?"):
                return InitResult(status=InitStatus.CANCELLED)
        else:
            plugins = list(config.plugins) if config.plugins else []
            layer_types = list(config.layer_types) if config.layer_types else []
            # Default to all environments if none specified in non-interactive mode
            environments = (
                list(config.environments)
                if config.environments
                else list(AVAILABLE_ENVIRONMENTS.keys())
            )
            # In non-interactive mode, build default environment values
            if layer_types and environments:
                contracts = self._get_contracts_for_layer_types(layer_types)
                prompts = self._build_environment_value_prompts(
                    environments, layer_types, contracts
                )
                collected_env_values = self._prompt.collect_environment_values(
                    prompts, environments, layer_types
                )

        # Create taxonomy directory
        self._filesystem.create_directory(config.taxonomy_root)

        # Install core templates
        core_version = self._install_core_templates(config)

        # Install plugins and layer types
        installed_plugins = tuple(plugins)
        installed_layer_types = tuple(layer_types)
        plugin_version = self._install_plugin_templates(
            config,
            installed_plugins,
            installed_layer_types,
        )

        # Create lock file
        lock = self._create_lock(
            source=config.source,
            plugins=installed_plugins,
            layer_types=installed_layer_types,
            core_version=core_version,
            plugin_version=plugin_version,
        )
        lock_yaml = self._lock_to_yaml(lock)
        self._filesystem.write_file(config.lock_file_path, lock_yaml)

        # Create environments manifest (only if environments were selected)
        if environments:
            environments_yaml = self._create_environments_yaml(
                tuple(environments), collected_env_values
            )
            self._filesystem.write_file(config.environments_file_path, environments_yaml)

        return InitResult(
            status=InitStatus.SUCCESS,
            taxonomy_root=config.taxonomy_root,
            lock_file=config.lock_file_path,
            installed_plugins=installed_plugins,
            installed_layer_types=installed_layer_types,
        )

    def _prompt_for_selections(
        self, config: InitConfig
    ) -> tuple[list[str], list[str], list[str], list[CollectedEnvironmentValues]]:
        """Prompt user for plugin, layer type, environment, and env value selections.

        Args:
            config: Configuration with any pre-selected values.

        Returns:
            Tuple of (selected_plugins, selected_layer_types, selected_environments,
            collected_environment_values).
        """
        # Build plugin choices
        plugin_choices = [
            PluginChoice(
                name=name,
                description=desc,
                selected=name in config.plugins,
            )
            for name, desc in AVAILABLE_PLUGINS.items()
        ]

        # Get user selections
        selected_plugin_choices = self._prompt.select_plugins(plugin_choices)
        selected_plugins = [c.name for c in selected_plugin_choices if c.selected]

        # Build layer type choices for selected plugins
        layer_type_choices: list[LayerTypeChoice] = []
        if "layer_types" in selected_plugins:
            discovered = self._discover_layer_type_choices(config)
            for name, desc in discovered.items():
                layer_type_choices.append(
                    LayerTypeChoice(
                        name=name,
                        description=desc,
                        plugin="layer_types",
                        selected=name in config.layer_types,
                    ),
                )

        # Get user selections
        selected_lt_choices = self._prompt.select_layer_types(layer_type_choices)
        selected_layer_types = [c.name for c in selected_lt_choices if c.selected]

        # Build environment choices (all selected by default)
        env_choices = [
            EnvironmentChoice(
                name=name,
                description=str(details["description"]),
                selected=name in config.environments if config.environments else True,
            )
            for name, details in AVAILABLE_ENVIRONMENTS.items()
        ]

        # Get user selections
        selected_env_choices = self._prompt.select_environments(env_choices)
        selected_environments = [c.name for c in selected_env_choices if c.selected]

        # Collect environment values from layer type contracts
        collected_env_values: list[CollectedEnvironmentValues] = []
        if selected_layer_types and selected_environments:
            contracts = self._get_contracts_for_layer_types(selected_layer_types)
            prompts = self._build_environment_value_prompts(
                selected_environments, selected_layer_types, contracts
            )
            if prompts:
                collected_env_values = self._prompt.collect_environment_values(
                    prompts, selected_environments, selected_layer_types
                )

        return selected_plugins, selected_layer_types, selected_environments, collected_env_values

    def _get_contracts_for_layer_types(
        self,
        layer_types: list[str],
    ) -> dict[str, EnvironmentContract]:
        """Resolve environment contracts for the given layer types.

        Attempts to load contracts from the template source first (via
        ``LayerTypeDefinition`` objects), falling back to the built-in
        ``KNOWN_CONTRACTS`` dict for bundled layer types.

        Args:
            layer_types: Names of the selected layer types.

        Returns:
            Mapping of layer type name to its EnvironmentContract.
        """
        contracts: dict[str, EnvironmentContract] = {}

        # Try to get contracts from template source
        if self._template_source is not None:
            try:
                fetch_result = self._template_source.fetch_package("layer_types")
                path = getattr(fetch_result, "path", None)
                if path is not None:
                    from katalyst_taxonomy.plugins.layer_types import load_layer_types

                    result = load_layer_types(path)
                    for lt_name in layer_types:
                        definition = result.definition(lt_name)
                        if definition is not None:
                            contracts[lt_name] = definition.environment_contract
            except (KeyError, ValueError, OSError):
                pass

        # Fill in missing contracts from known defaults
        for lt_name in layer_types:
            if lt_name not in contracts:
                contracts[lt_name] = KNOWN_CONTRACTS.get(lt_name, EMPTY_CONTRACT)

        return contracts

    @staticmethod
    def _build_environment_value_prompts(
        environments: list[str],
        layer_types: list[str],
        contracts: dict[str, EnvironmentContract],
    ) -> list[EnvironmentValuePrompt]:
        """Build the flat list of value prompts from contracts.

        For each environment × layer type × contract key, creates an
        :class:`EnvironmentValuePrompt` with a smart default when the key
        is auto-derivable (e.g. ``environment`` → the env name).

        Args:
            environments: Selected environment names.
            layer_types: Selected layer type names.
            contracts: Mapping of layer type name → EnvironmentContract.

        Returns:
            Ordered list of prompts grouped by environment, then layer type.
        """
        prompts: list[EnvironmentValuePrompt] = []

        for env_name in environments:
            # Shared templateReplacements keys (deduplicated across layer types)
            seen_shared: set[str] = set()
            for lt_name in layer_types:
                contract = contracts.get(lt_name, EMPTY_CONTRACT)
                for key in contract.template_replacements:
                    if key in seen_shared:
                        continue
                    seen_shared.add(key)
                    default = env_name if key in _AUTO_DERIVABLE_KEYS else ""
                    prompts.append(
                        EnvironmentValuePrompt(
                            key=key,
                            layer_type="",
                            environment=env_name,
                            description=ENV_KEY_DESCRIPTIONS.get(key, key),
                            default=default,
                        )
                    )

            # Per-layer-type layerTemplates keys
            for lt_name in layer_types:
                contract = contracts.get(lt_name, EMPTY_CONTRACT)
                for key in contract.layer_templates:
                    default = env_name if key in _AUTO_DERIVABLE_KEYS else ""
                    prompts.append(
                        EnvironmentValuePrompt(
                            key=key,
                            layer_type=lt_name,
                            environment=env_name,
                            description=ENV_KEY_DESCRIPTIONS.get(key, key),
                            default=default,
                        )
                    )

        return prompts

    def _discover_layer_type_choices(self, config: InitConfig) -> dict[str, str]:
        """Query the template source for available layer types.

        Returns a dict mapping layer type name → description. Falls back
        to the built-in ``_LAYER_TYPE_DESCRIPTIONS`` when the source
        cannot provide a manifest.
        """
        if self._template_source is not None:
            try:
                fetch_result = self._template_source.fetch_package("layer_types")
                manifest = getattr(fetch_result, "manifest", None)
                if manifest is not None:
                    canonical = getattr(manifest, "canonical_items", ())
                    if canonical:
                        return {
                            name: _LAYER_TYPE_DESCRIPTIONS.get(name, f"Layer type template: {name}")
                            for name in canonical
                        }
                # Fallback: scan subdirectories
                path = getattr(fetch_result, "path", None)
                if path is not None and path.is_dir():
                    return {
                        item.name: _LAYER_TYPE_DESCRIPTIONS.get(
                            item.name, f"Layer type template: {item.name}"
                        )
                        for item in sorted(path.iterdir(), key=lambda p: p.name)
                        if item.is_dir() and not item.name.startswith(".")
                    }
            except (KeyError, ValueError, OSError):
                pass

        return dict(_LAYER_TYPE_DESCRIPTIONS)

    def _install_core_templates(self, config: InitConfig) -> str:
        """Install core templates to the taxonomy directory.

        Args:
            config: Initialization configuration.

        Returns:
            Version of the installed core package.
        """
        if self._template_source is None:
            return "1.0.0"  # Default version when no source

        try:
            fetch_result = self._template_source.fetch_package("core")
            package_path = getattr(fetch_result, "path", None)
            package_info = getattr(fetch_result, "package", None)

            if package_path is not None:
                # Copy core template files to taxonomy root's templates/ subdirectory
                templates_src = package_path / "templates"
                if templates_src.is_dir():
                    templates_dest = config.taxonomy_root / "templates"
                    self._filesystem.create_directory(templates_dest)
                    for item in templates_src.iterdir():
                        if item.is_file() and item.suffix in (".yaml", ".yml"):
                            dest = templates_dest / item.name
                            self._filesystem.copy_file(item, dest)
                        elif item.is_file() and item.name == "Justfile":
                            # Install Justfile to repo root (parent of .global/)
                            repo_root = config.taxonomy_root.parent.parent
                            dest = repo_root / "Justfile"
                            if not dest.exists():
                                self._filesystem.copy_file(item, dest)

            return getattr(package_info, "version", "1.0.0") if package_info else "1.0.0"
        except (KeyError, ValueError):
            return "1.0.0"

    def _install_plugin_templates(
        self,
        config: InitConfig,
        plugins: tuple[str, ...],
        layer_types: tuple[str, ...],
    ) -> str:
        """Install plugin templates to the taxonomy directory.

        Args:
            config: Initialization configuration.
            plugins: Plugin names to install.
            layer_types: Layer type names to install.

        Returns:
            Version of the installed plugin package.
        """
        if self._template_source is None or not plugins:
            return "1.0.0"  # Default version when no source or no plugins

        version = "1.0.0"

        for plugin in plugins:
            try:
                fetch_result = self._template_source.fetch_package(plugin)
                package_path = getattr(fetch_result, "path", None)
                package_info = getattr(fetch_result, "package", None)

                if package_info:
                    version = getattr(package_info, "version", "1.0.0")

                if package_path is not None:
                    # For layer_types, copy only selected layer types
                    if plugin == "layer_types":
                        self._install_layer_types(config, package_path, layer_types)
                    elif plugin == "layer_actions":
                        # Action YAMLs go to actions/ under taxonomy root
                        self._install_layer_actions(config, package_path)
                    elif plugin == "just":
                        # Just recipes go to actions/just/ under taxonomy root
                        just_dest = config.taxonomy_root / "actions" / "just"
                        self._filesystem.copy_tree(package_path, just_dest)
                    elif plugin == "cicd":
                        # cicd goes directly to cicd/ (not plugins/cicd/)
                        cicd_dest = config.taxonomy_root / "cicd"
                        self._filesystem.copy_tree(package_path, cicd_dest)
                    else:
                        # Copy entire plugin directory
                        plugin_dest = config.taxonomy_root / "plugins" / plugin
                        self._filesystem.copy_tree(package_path, plugin_dest)

            except (KeyError, ValueError):
                continue

        return version

    def _install_layer_types(
        self,
        config: InitConfig,
        package_path: Path,
        layer_types: tuple[str, ...],
    ) -> None:
        """Install selected layer types from the layer_types plugin.

        Args:
            config: Initialization configuration.
            package_path: Path to the layer_types package.
            layer_types: Layer type names to install.
        """
        layer_types_dest = config.taxonomy_root / "layer_types"
        self._filesystem.create_directory(layer_types_dest)

        for layer_type in layer_types:
            src = package_path / layer_type
            if src.exists() and src.is_dir():
                dest = layer_types_dest / layer_type
                self._filesystem.copy_tree(src, dest)

    def _install_layer_actions(
        self,
        config: InitConfig,
        package_path: Path,
    ) -> None:
        """Install bundled action YAML files to the actions directory.

        Copies all YAML files and subdirectories (e.g. tools/) from the
        bundled layer_actions package into ``.global/taxonomy/actions/``.

        Args:
            config: Initialization configuration.
            package_path: Path to the layer_actions package.
        """
        actions_dest = config.taxonomy_root / "actions"
        self._filesystem.create_directory(actions_dest)

        for item in package_path.iterdir():
            if item.name == "manifest.json":
                continue
            if item.is_file() and item.suffix in (".yaml", ".yml"):
                dest = actions_dest / item.name
                self._filesystem.copy_file(item, dest)
            elif item.is_dir():
                dest = actions_dest / item.name
                self._filesystem.copy_tree(item, dest)

    def _create_lock(
        self,
        source: str,
        plugins: tuple[str, ...],
        layer_types: tuple[str, ...],
        core_version: str = "1.0.0",
        plugin_version: str = "1.0.0",
    ) -> KatalystLock:
        """Create a new lock file for the initialized repository.

        Args:
            source: Template source URI.
            plugins: Installed plugin names.
            layer_types: Installed layer type names.
            core_version: Version of installed core package.
            plugin_version: Version of installed plugins.

        Returns:
            A new KatalystLock instance.
        """
        now = datetime.now(timezone.utc)

        # Build plugins dict
        plugin_dict: dict[str, InstalledPlugin] = {}
        if "layer_types" in plugins:
            plugin_dict["layer_types"] = InstalledPlugin(
                version=plugin_version,
                installed_at=now,
                source=source,
                canonical=layer_types,
                custom=(),
            )

        # Record other installed plugins (just, layer_actions, cicd, etc.)
        for plugin_name in plugins:
            if plugin_name != "layer_types" and plugin_name not in plugin_dict:
                plugin_dict[plugin_name] = InstalledPlugin(
                    version=plugin_version,
                    installed_at=now,
                    source=source,
                )

        return KatalystLock(
            api_version="katalyst.taxonomy/v1alpha",
            kind="KatalystLock",
            metadata=LockMetadata(
                generated_at=now,
                generated_by="kata tax init",
                katalyst_version="1.0.0",
            ),
            installed=InstalledComponents(
                core=InstalledCore(
                    version=core_version,
                    schema_version="v1alpha",
                    installed_at=now,
                    source=source,
                ),
                plugins=plugin_dict,
            ),
        )

    def _lock_to_yaml(self, lock: KatalystLock) -> str:
        """Convert a lock to YAML string.

        Args:
            lock: The lock to convert.

        Returns:
            YAML string representation.
        """

        def format_datetime(dt: datetime) -> str:
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        # Build plugins section
        plugins_data: dict[str, object] = {}
        for name, plugin in lock.installed.plugins.items():
            plugin_data: dict[str, object] = {
                "version": plugin.version,
                "installedAt": format_datetime(plugin.installed_at),
                "source": plugin.source,
            }
            if plugin.canonical:
                plugin_data["canonical"] = list(plugin.canonical)
            if plugin.custom:
                plugin_data["custom"] = list(plugin.custom)
            plugins_data[name] = plugin_data

        data = {
            "apiVersion": lock.api_version,
            "kind": lock.kind,
            "metadata": {
                "generatedAt": format_datetime(lock.metadata.generated_at),
                "generatedBy": lock.metadata.generated_by,
                "katalystVersion": lock.metadata.katalyst_version,
            },
            "installed": {
                "core": {
                    "version": lock.installed.core.version,
                    "schemaVersion": lock.installed.core.schema_version,
                    "installedAt": format_datetime(lock.installed.core.installed_at),
                    "source": lock.installed.core.source,
                },
                "plugins": plugins_data,
            },
        }

        header = "# Auto-generated by Katalyst - do not edit manually\n"
        return header + yaml.safe_dump(data, sort_keys=False, default_flow_style=False)

    def _create_environments_yaml(
        self,
        environments: tuple[str, ...],
        collected_values: list[CollectedEnvironmentValues] | None = None,
    ) -> str:
        """Create YAML content for the environments manifest.

        Args:
            environments: Tuple of environment names to include.
            collected_values: Optional per-environment values collected from
                the user (or defaults).  When provided, these are merged into
                the generated ``templateReplacements`` and ``layerTemplates``
                blocks.

        Returns:
            YAML string with multi-document format containing selected environments.
        """
        # Index collected values by environment name for quick lookup
        values_by_env: dict[str, CollectedEnvironmentValues] = {}
        if collected_values:
            for cv in collected_values:
                values_by_env[cv.environment] = cv

        documents: list[str] = []

        for env_name in environments:
            if env_name not in AVAILABLE_ENVIRONMENTS:
                continue
            env_details = AVAILABLE_ENVIRONMENTS[env_name]

            # Start with the base template replacements
            base_replacements: dict[str, object] = dict(env_details["templateReplacements"])  # type: ignore[arg-type]

            # Merge in collected shared template replacements
            cv = values_by_env.get(env_name)
            if cv:
                for key, value in cv.template_replacements.items():
                    if value:  # Only include non-empty values
                        base_replacements[key] = value

            spec: dict[str, object] = {
                "description": env_details["description"],
                "templateReplacements": base_replacements,
            }

            # Add layerTemplates if collected values include per-layer-type keys
            if cv and cv.layer_templates:
                layer_templates: dict[str, dict[str, str]] = {}
                for lt_name, lt_values in cv.layer_templates.items():
                    # Only include entries with at least one non-empty value
                    filtered = {k: v for k, v in lt_values.items() if v}
                    if filtered:
                        layer_templates[lt_name] = filtered
                if layer_templates:
                    spec["layerTemplates"] = layer_templates

            doc: dict[str, object] = {
                "apiVersion": "katalyst.taxonomy/v1alpha",
                "kind": "Environment",
                "metadata": {"name": env_name},
                "spec": spec,
            }
            documents.append(yaml.safe_dump(doc, sort_keys=False, default_flow_style=False))

        return "---\n".join(documents)
