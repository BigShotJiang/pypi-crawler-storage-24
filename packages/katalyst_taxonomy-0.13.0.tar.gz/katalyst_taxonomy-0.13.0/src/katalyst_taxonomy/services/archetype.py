"""Archetype service — orchestrates multi-node creation from archetypes."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from katalyst_taxonomy.plugins.archetypes import (
    ArchetypeChildNode,
    ArchetypeDefinition,
    load_archetypes,
)
from katalyst_taxonomy.ports.filesystem import FilesystemPort
from katalyst_taxonomy.ports.taxonomy import (
    CreationRequest,
    TaxonomyWriter,
)
from katalyst_taxonomy.services.creation import CreationService


@dataclass(frozen=True, slots=True)
class CreatedNode:
    """A single node created during archetype scaffolding."""

    node_type: str
    name: str
    path: Path
    layer_type: str | None = None


@dataclass(frozen=True, slots=True)
class ArchetypeCreationResult:
    """Result of archetype-based multi-node creation."""

    success: bool
    created_nodes: tuple[CreatedNode, ...]
    error: str | None = None


class ArchetypeService:
    """Orchestrates multi-node creation from an archetype definition.

    The service validates archetype requirements, walks the child tree
    depth-first, and delegates individual node creation to
    :class:`CreationService`.
    """

    def __init__(
        self,
        writer: TaxonomyWriter,
        filesystem: FilesystemPort,
    ) -> None:
        self._writer = writer
        self._filesystem = filesystem

    def create_from_archetype(
        self,
        base_path: Path,
        archetype: ArchetypeDefinition,
        root_name: str,
        root_node_type: str,
        environments: tuple[str, ...],
        owners: tuple[str, ...],
        parent: str | None = None,
        parent_subsystem: str | None = None,
        parent_system: str | None = None,
        description_override: str | None = None,
    ) -> ArchetypeCreationResult:
        """Create a full taxonomy subtree from an archetype.

        Args:
            base_path: Repository root path.
            archetype: The loaded archetype definition.
            root_name: Name for the root node (user-provided).
            root_node_type: The taxonomy node type for the root (system/subsystem/stack).
            environments: Environments to apply to all created nodes.
            owners: Owners to apply to all created nodes.
            parent: Direct parent name (for subsystem/stack/layer).
            parent_subsystem: Parent subsystem (for stack/layer).
            parent_system: Parent system (for subsystem/stack/layer).

        Returns:
            ArchetypeCreationResult with all created nodes or an error.
        """
        # 1. Validate scope match
        if archetype.scope != root_node_type:
            return ArchetypeCreationResult(
                success=False,
                created_nodes=(),
                error=(
                    f"Archetype '{archetype.name}' has scope '{archetype.scope}' "
                    f"but was used with 'kata tax create {root_node_type}'"
                ),
            )

        # 2. Validate requirements
        req_error = self._validate_requirements(base_path, archetype)
        if req_error:
            return ArchetypeCreationResult(
                success=False,
                created_nodes=(),
                error=req_error,
            )

        # 3. Build the creation service
        creation_service = CreationService(
            writer=self._writer,
            filesystem=self._filesystem,
        )

        # 4. Create the root node
        root_request = CreationRequest(
            node_type=root_node_type,
            name=root_name,
            description=archetype.description,
            owners=owners,
            environments=environments,
            parent=parent,
            parent_subsystem=parent_subsystem,
            parent_system=parent_system,
        )

        root_result = creation_service.create(base_path, root_request)
        if not root_result.success:
            return ArchetypeCreationResult(
                success=False,
                created_nodes=(),
                error=root_result.error,
            )

        created: list[CreatedNode] = [
            CreatedNode(
                node_type=root_node_type,
                name=root_name,
                path=root_result.path or base_path,
            ),
        ]

        # 5. Scaffold root-level template files
        if archetype.template_path and root_result.path:
            root_dir = root_result.path.parent
            context = self._build_template_context(
                name=root_name,
                description=description_override or archetype.description,
                owners=owners,
                environments=environments,
                parent_system=parent_system or "",
                parent_subsystem=parent_subsystem or "",
                parent_stack="",
                archetype_name=archetype.name,
                archetype_root_name=root_name,
            )
            self._filesystem.copy_tree_rendered(
                archetype.template_path,
                root_dir,
                context,
            )

        # 6. Recursively create children
        child_error = self._create_children(
            base_path=base_path,
            creation_service=creation_service,
            children=archetype.children,
            environments=environments,
            owners=owners,
            parent_system=self._resolve_parent_system(root_node_type, root_name, parent_system),
            parent_subsystem=self._resolve_parent_subsystem(
                root_node_type, root_name, parent_subsystem
            ),
            parent_stack=self._resolve_parent_stack(root_node_type, root_name),
            archetype_name=archetype.name,
            archetype_root_name=root_name,
            created=created,
        )

        if child_error:
            return ArchetypeCreationResult(
                success=False,
                created_nodes=tuple(created),
                error=child_error,
            )

        logger.info(
            "Archetype '{}' created {} nodes for '{}'",
            archetype.name,
            len(created),
            root_name,
        )

        return ArchetypeCreationResult(
            success=True,
            created_nodes=tuple(created),
        )

    # ------------------------------------------------------------------
    # Requirement validation
    # ------------------------------------------------------------------

    def _validate_requirements(
        self,
        base_path: Path,
        archetype: ArchetypeDefinition,
    ) -> str | None:
        """Validate that all required plugins are installed.

        Returns an error message if validation fails, None otherwise.
        """
        if not archetype.requirements:
            return None

        try:
            from katalyst_taxonomy.plugins.index import build_plugin_index

            plugins_path = base_path / ".global" / "taxonomy"
            if not self._filesystem.exists(plugins_path):
                missing_names = [r.name for r in archetype.requirements]
                return (
                    f"Archetype '{archetype.name}' requires plugins that are not installed: "
                    f"{', '.join(missing_names)}. Run 'kata tax init' or 'kata tax add' first."
                )

            # Scan for YAML files in the plugins directory
            yaml_files: list[Path] = []
            for item in plugins_path.rglob("*.yaml"):
                yaml_files.append(item)
            for item in plugins_path.rglob("*.yml"):
                yaml_files.append(item)

            index, _errors = build_plugin_index(yaml_files)

            missing: list[str] = []
            for req in archetype.requirements:
                if req.mode == "required" and not index.has(req.api_version, req.kind, req.name):
                    missing.append(f"{req.kind}/{req.name}")

            if missing:
                return (
                    f"Archetype '{archetype.name}' requires plugins that are not installed: "
                    f"{', '.join(missing)}"
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to validate archetype requirements: {}", exc)
            # Non-fatal — proceed with creation

        return None

    # ------------------------------------------------------------------
    # Recursive child creation
    # ------------------------------------------------------------------

    def _create_children(
        self,
        base_path: Path,
        creation_service: CreationService,
        children: tuple[ArchetypeChildNode, ...],
        environments: tuple[str, ...],
        owners: tuple[str, ...],
        parent_system: str,
        parent_subsystem: str,
        parent_stack: str,
        archetype_name: str,
        archetype_root_name: str,
        created: list[CreatedNode],
    ) -> str | None:
        """Create child nodes recursively. Returns error message or None."""
        for child in children:
            # Determine parent references for this child
            direct_parent, p_subsystem, p_system = self._child_parent_refs(
                child.node_type,
                parent_system=parent_system,
                parent_subsystem=parent_subsystem,
                parent_stack=parent_stack,
            )

            request = CreationRequest(
                node_type=child.node_type,
                name=child.name,
                description=child.description,
                owners=owners,
                environments=environments,
                parent=direct_parent,
                parent_subsystem=p_subsystem,
                parent_system=p_system,
                layer_type=child.layer_type,
            )

            result = creation_service.create(base_path, request)
            if not result.success:
                return f"Failed to create {child.node_type} '{child.name}': {result.error}"

            created.append(
                CreatedNode(
                    node_type=child.node_type,
                    name=child.name,
                    path=result.path or base_path,
                    layer_type=child.layer_type,
                ),
            )

            # Scaffold non-layer template files
            if child.template_path and child.node_type != "layer" and result.path:
                child_dir = result.path.parent
                context = self._build_template_context(
                    name=child.name,
                    description=child.description,
                    owners=owners,
                    environments=environments,
                    parent_system=p_system or parent_system,
                    parent_subsystem=p_subsystem or parent_subsystem,
                    parent_stack=parent_stack,
                    archetype_name=archetype_name,
                    archetype_root_name=archetype_root_name,
                )
                self._filesystem.copy_tree_rendered(
                    child.template_path,
                    child_dir,
                    context,
                )

            # Recurse into grandchildren
            if child.children:
                next_system = parent_system
                next_subsystem = parent_subsystem
                next_stack = parent_stack

                if child.node_type == "subsystem":
                    next_subsystem = child.name
                elif child.node_type == "stack":
                    next_stack = child.name

                error = self._create_children(
                    base_path=base_path,
                    creation_service=creation_service,
                    children=child.children,
                    environments=environments,
                    owners=owners,
                    parent_system=next_system,
                    parent_subsystem=next_subsystem,
                    parent_stack=next_stack,
                    archetype_name=archetype_name,
                    archetype_root_name=archetype_root_name,
                    created=created,
                )
                if error:
                    return error

        return None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _child_parent_refs(
        child_node_type: str,
        parent_system: str,
        parent_subsystem: str,
        parent_stack: str,
    ) -> tuple[str | None, str | None, str | None]:
        """Determine parent, parent_subsystem, parent_system for a child node."""
        if child_node_type == "subsystem":
            return parent_system or None, None, parent_system or None
        if child_node_type == "stack":
            return parent_subsystem or None, parent_subsystem or None, parent_system or None
        if child_node_type == "layer":
            return parent_stack or None, parent_subsystem or None, parent_system or None
        return None, None, None

    @staticmethod
    def _resolve_parent_system(
        root_node_type: str,
        root_name: str,
        parent_system: str | None,
    ) -> str:
        """Resolve the system name for children based on root node type."""
        if root_node_type == "system":
            return root_name
        return parent_system or ""

    @staticmethod
    def _resolve_parent_subsystem(
        root_node_type: str,
        root_name: str,
        parent_subsystem: str | None,
    ) -> str:
        """Resolve the subsystem name for children based on root node type."""
        if root_node_type == "subsystem":
            return root_name
        return parent_subsystem or ""

    @staticmethod
    def _resolve_parent_stack(
        root_node_type: str,
        root_name: str,
    ) -> str:
        """Resolve the stack name for children based on root node type."""
        if root_node_type == "stack":
            return root_name
        return ""

    @staticmethod
    def _build_template_context(
        name: str,
        description: str,
        owners: tuple[str, ...],
        environments: tuple[str, ...],
        parent_system: str,
        parent_subsystem: str,
        parent_stack: str,
        archetype_name: str,
        archetype_root_name: str,
    ) -> dict[str, str]:
        """Build the token context for archetype template rendering."""
        primary_owner = owners[0] if owners else "team@example.com"
        primary_env = environments[0] if environments else "dev"

        return {
            "name": name,
            "description": description,
            "primary_owner": primary_owner,
            "owner_email": primary_owner,
            "primary_environment": primary_env,
            "parent_system": parent_system,
            "system_name": parent_system,
            "parent_subsystem": parent_subsystem,
            "subsystem_name": parent_subsystem,
            "parent_stack": parent_stack,
            "stack_name": parent_stack,
            "archetype_name": archetype_name,
            "archetype_root_name": archetype_root_name,
        }


def resolve_archetype(
    base_path: Path,
    archetype_name: str,
) -> ArchetypeDefinition | None:
    """Look up an installed archetype by name.

    Searches ``base_path/.global/taxonomy/archetypes/`` for archetype
    definitions and returns the first match, or ``None``.
    """
    archetypes_path = base_path / ".global" / "taxonomy" / "archetypes"
    if not archetypes_path.exists():
        return None

    result = load_archetypes(archetypes_path)
    return result.definition(archetype_name)
