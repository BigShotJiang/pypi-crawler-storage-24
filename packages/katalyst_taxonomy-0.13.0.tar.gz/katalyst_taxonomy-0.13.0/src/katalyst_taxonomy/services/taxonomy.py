"""Taxonomy service - computes fully qualified names and provides taxonomy operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Sequence

from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.taxonomy.documents import TaxonomyDocument
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

# Parent type hierarchy for FQTN resolution.
# Values are tuples of allowed parent types, or None for root nodes.
PARENT_NODE_TYPES: dict[str, tuple[str, ...] | None] = {
    # Portfolio wing
    "organization": None,
    "program": ("organization",),
    "project": ("program", "organization"),
    # Organizational wing
    "team": ("organization", "team"),
    "team_member": ("team",),
    "user": None,
    # Technical wing
    "system": None,
    "subsystem": ("system",),
    "stack": ("subsystem",),
    "layer": ("stack",),
}


def document_lookup_key(document: TaxonomyDocument) -> str:
    """Generate a stable lookup key for ``document`` within qualified-name caches."""
    parent = document.spec.parents.node if document.spec.parents else ""
    source = str(document.source_path) if document.source_path else ""
    return f"{document.taxonomy_node_type}:{parent}:{document.metadata.name}:{source}"


def qualified_name_for(document: TaxonomyDocument, qualified_names: Mapping[str, str]) -> str:
    """Return the fully qualified taxonomy name for ``document`` if known."""
    return qualified_names.get(document_lookup_key(document), document.metadata.name)


def build_qualified_names(documents: Sequence[TaxonomyDocument]) -> dict[str, str]:
    """Build a mapping of document lookup keys to fully qualified names."""
    index: dict[tuple[str, str], list[TaxonomyDocument]] = {}
    for document in documents:
        key = (document.taxonomy_node_type, document.metadata.name)
        index.setdefault(key, []).append(document)

    cache: dict[str, str] = {}
    in_progress: set[str] = set()

    def resolve(document: TaxonomyDocument) -> str:
        key = document_lookup_key(document)
        if key in cache:
            return cache[key]
        if key in in_progress:
            cache[key] = document.metadata.name
            return cache[key]
        in_progress.add(key)

        parent_fq = ""
        parent_types = PARENT_NODE_TYPES.get(document.taxonomy_node_type)
        parent_ref = document.spec.parents.node if document.spec.parents else None
        if parent_types and parent_ref:
            # Collect candidates across all allowed parent types
            candidates: list[TaxonomyDocument] = []
            for pt in parent_types:
                candidates.extend(index.get((pt, parent_ref), []))
            selected = _select_parent(document, candidates)
            if selected:
                parent_fq = resolve(selected)
            elif candidates:
                parent_fq = resolve(candidates[0])
            else:
                parent_fq = parent_ref

        fqtn = f"{parent_fq}.{document.metadata.name}" if parent_fq else document.metadata.name
        cache[key] = fqtn
        in_progress.remove(key)
        return fqtn

    for document in documents:
        resolve(document)

    return cache


def _select_parent(
    document: TaxonomyDocument,
    candidates: list[TaxonomyDocument],
) -> TaxonomyDocument | None:
    """Select the best parent candidate based on filesystem proximity."""
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]

    best: TaxonomyDocument | None = None
    best_score: tuple[int, int] | None = None

    for candidate in candidates:
        score = _parent_match_score(document, candidate)
        if score is None:
            continue
        if best_score is None or score < best_score:
            best = candidate
            best_score = score
        elif score == best_score:
            # tie: fall back to consistent ordering by path/name
            if best is not None and candidate.source_path and best.source_path:
                if str(candidate.source_path) < str(best.source_path):
                    best = candidate

    return best


def _parent_match_score(
    document: TaxonomyDocument,
    candidate: TaxonomyDocument,
) -> tuple[int, int] | None:
    """Calculate proximity score between document and potential parent."""
    if document.source_path is None or candidate.source_path is None:
        return None

    doc_parent = document.source_path.parent
    candidate_dir = candidate.source_path.parent

    try:
        relative = doc_parent.relative_to(candidate_dir)
    except ValueError:
        return None

    distance = len(relative.parts)
    depth = len(candidate_dir.parts)
    return (distance, depth)


@dataclass
class TaxonomyService:
    """Service for taxonomy operations including FQTN computation."""

    documents: tuple[TaxonomyDocument, ...] = ()
    environments: tuple[EnvironmentDocument, ...] = ()
    errors: tuple[DocumentError, ...] = ()
    _qualified_names: dict[str, str] = field(default_factory=lambda: {}, init=False)

    def __post_init__(self) -> None:
        """Compute qualified names after initialization."""
        self._qualified_names = build_qualified_names(self.documents)

    @property
    def qualified_names(self) -> dict[str, str]:
        """Return the computed qualified names mapping."""
        return self._qualified_names

    def get_qualified_name(self, document: TaxonomyDocument) -> str:
        """Get the fully qualified name for a document."""
        return qualified_name_for(document, self._qualified_names)

    def get_document_by_name(self, name: str) -> TaxonomyDocument | None:
        """Find a document by its simple name."""
        return next(
            (doc for doc in self.documents if doc.metadata.name == name),
            None,
        )

    def get_documents_by_type(self, node_type: str) -> tuple[TaxonomyDocument, ...]:
        """Get all documents of a specific type."""
        return tuple(doc for doc in self.documents if doc.taxonomy_node_type == node_type)

    def sorted_documents(self) -> list[TaxonomyDocument]:
        """Return documents sorted by type order and name."""
        type_order = {
            "organization": 0,
            "program": 1,
            "project": 2,
            "team": 3,
            "team_member": 4,
            "user": 5,
            "system": 6,
            "subsystem": 7,
            "stack": 8,
            "layer": 9,
        }
        return sorted(
            self.documents,
            key=lambda d: (
                type_order.get(d.taxonomy_node_type, 999),
                d.metadata.name,
            ),
        )

    def group_documents_by_type(self) -> dict[str, list[TaxonomyDocument]]:
        """Group documents by their taxonomy node type."""
        grouped: dict[str, list[TaxonomyDocument]] = {}
        for doc in self.documents:
            grouped.setdefault(doc.taxonomy_node_type, []).append(doc)
        # Sort each group by name
        for docs in grouped.values():
            docs.sort(key=lambda d: d.metadata.name)
        return grouped
