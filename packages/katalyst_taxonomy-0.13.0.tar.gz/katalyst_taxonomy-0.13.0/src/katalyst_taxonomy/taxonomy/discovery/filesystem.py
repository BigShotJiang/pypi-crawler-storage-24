"""Filesystem-backed discovery for taxonomy documents."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence, cast

import yaml
from loguru import logger

from ..documents import (
    API_VERSION,
    KIND,
    TaxonomyDependencies,
    TaxonomyDocument,
    TaxonomyMetadata,
    TaxonomyParents,
    TaxonomySpec,
)
from ..environments import (
    ENVIRONMENT_KIND,
    EnvironmentDocument,
    environment_from_mapping,
)
from ..ignore import IGNOREFILE_NAME, load_ignore

LAYER_FILENAMES: tuple[str, ...] = ("layer.yaml", "layer.yml")


class DiscoveryStrategy(Protocol):
    """Strategy for discovering taxonomy YAML files within a filesystem layout."""

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        """Return the YAML file paths relative to the base directory."""
        ...


@dataclass(frozen=True)
class SingleFileStrategy:
    """Treat the provided base path as a single YAML file."""

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        if base_path.is_file():
            return (base_path,)

        if base_path.is_dir():
            candidates = tuple(
                path
                for path in base_path.iterdir()
                if path.is_file() and path.suffix.lower() in (".yaml", ".yml")
            )
            if candidates:
                return tuple(sorted(candidates))

        for candidate in (base_path / "taxonomy.yaml", base_path / "taxonomy.yml"):
            if candidate.exists():
                return (candidate,)

        return ()


@dataclass(frozen=True)
class ByKindStrategy:
    """Expect directories organised by taxonomy node type."""

    extensions: tuple[str, ...] = (".yaml", ".yml")

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        if not base_path.is_dir():
            return ()

        paths: list[Path] = []
        for node_type in (
            "organizations",
            "programs",
            "projects",
            "teams",
            "team_members",
            "systems",
            "subsystems",
            "stacks",
            "layers",
        ):
            directory = base_path / node_type
            if not directory.is_dir():
                continue
            for path in directory.iterdir():
                if path.is_file() and path.suffix.lower() in self.extensions:
                    paths.append(path)
        return tuple(paths)


@dataclass(frozen=True)
class RecursiveStrategy:
    """Search all YAML files recursively beneath the base path."""

    extensions: tuple[str, ...] = (".yaml", ".yml")
    ignore_dirs: tuple[str, ...] = (
        ".git",
        ".venv",
        "node_modules",
        "__pycache__",
        ".tox",
        ".mypy_cache",
        ".ruff_cache",
        "charts",
        "templates",
        "tests",
        "layer_types",  # Katalyst layer type templates (contain Jinja2 placeholders)
    )

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        if not base_path.exists():
            return ()

        matched: list[Path] = []
        stack: list[Path] = [base_path]

        while stack:
            current = stack.pop()

            if current.is_dir():
                if current != base_path and current.name in self.ignore_dirs:
                    continue

                layer_document = _find_layer_document(current)
                if layer_document is not None:
                    matched.append(layer_document)
                    continue

                try:
                    children = list(current.iterdir())
                except OSError:
                    continue

                for child in children:
                    stack.append(child)
                continue

            if current.is_file() and current.suffix.lower() in self.extensions:
                matched.append(current)

        return tuple(matched)


def _find_layer_document(directory: Path) -> Path | None:
    for candidate_name in LAYER_FILENAMES:
        candidate = directory / candidate_name
        if candidate.is_file():
            return candidate
    return None


@dataclass(frozen=True)
class CompositeDiscoveryStrategy:
    """Combine multiple strategies, deduplicating discovered paths."""

    strategies: Sequence[DiscoveryStrategy]

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        seen: set[Path] = set()
        discovered: list[Path] = []
        for strategy in self.strategies:
            for path in strategy.discover(base_path):
                absolute = path.resolve()
                if absolute not in seen:
                    seen.add(absolute)
                    discovered.append(path)
        return tuple(discovered)


@dataclass(frozen=True)
class DocumentError:
    """Represents an error encountered while loading a taxonomy document."""

    path: Path
    document_index: int
    message: str


def _as_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        mapping_value = cast(Mapping[Any, Any], value)
        result: dict[str, Any] = {}
        for raw_key, raw_value in mapping_value.items():
            result[str(raw_key)] = raw_value
        return result
    return {}


def _document_from_mapping(mapping: Mapping[str, Any], *, source_path: Path) -> TaxonomyDocument:
    metadata_raw = _as_mapping(mapping.get("metadata"))
    spec_raw = _as_mapping(mapping.get("spec"))

    labels_raw = _as_mapping(metadata_raw.get("labels"))
    labels: dict[str, str] = {}
    for key, value in labels_raw.items():
        labels[str(key)] = str(value)
    metadata = TaxonomyMetadata(
        name=str(metadata_raw.get("name", "")),
        labels=labels,
    )

    depends_on = None
    depends_section = _as_mapping(spec_raw.get("dependsOn"))
    nodes_value = depends_section.get("nodes")
    if isinstance(nodes_value, Sequence) and not isinstance(nodes_value, (str, bytes, bytearray)):
        node_iter = cast(Sequence[object], nodes_value)
        node_names: list[str] = []
        for raw_node in node_iter:
            if raw_node:
                node_names.append(str(raw_node))
        if node_names:
            depends_on = TaxonomyDependencies(nodes=tuple(node_names))

    parents = None
    parents_section = _as_mapping(spec_raw.get("parents"))
    parent_node = parents_section.get("node")
    if isinstance(parent_node, str) and parent_node:
        parents = TaxonomyParents(node=parent_node)

    owners_value = spec_raw.get("owners")
    owners_list: list[str] = []
    if isinstance(owners_value, Sequence) and not isinstance(owners_value, (str, bytes, bytearray)):
        owner_iter = cast(Sequence[object], owners_value)
        for raw_owner in owner_iter:
            if raw_owner:
                owners_list.append(str(raw_owner))
    owners = tuple(owners_list)
    annotations_raw = _as_mapping(spec_raw.get("annotations"))
    extensions_raw = _as_mapping(spec_raw.get("extensions"))
    annotations: dict[str, str] = {}
    for key, value in annotations_raw.items():
        annotations[str(key)] = str(value)
    extensions: dict[str, Any] | None = None
    if extensions_raw:
        extensions = dict(extensions_raw)

    description_value = spec_raw.get("description")
    if description_value is None:
        description: str | None = None
    else:
        description = str(description_value)

    environments_value = spec_raw.get("environments")
    environments_list: list[str] = []
    if isinstance(environments_value, Sequence) and not isinstance(
        environments_value,
        (str, bytes, bytearray),
    ):
        environments_list = [str(env) for env in cast(Sequence[object], environments_value) if env]
    environments = tuple(environments_list)

    spec = TaxonomySpec(
        description=description,
        owners=owners,
        annotations=annotations,
        depends_on=depends_on,
        parents=parents,
        extensions=extensions,
        environments=environments,
    )

    return TaxonomyDocument(
        api_version=str(mapping.get("apiVersion", "")),
        kind=str(mapping.get("kind", "")),
        metadata=metadata,
        taxonomy_node_type=str(mapping.get("taxonomyNodeType", "")),
        spec=spec,
        source_path=source_path,
    )


def _document_error_list() -> list[DocumentError]:
    return []


def _environment_document_list() -> list[EnvironmentDocument]:
    return []


@dataclass
class FilesystemTaxonomyLoader:
    """Filesystem-backed loader that implements taxonomy sources."""

    base_path: Path
    strategy: DiscoveryStrategy

    _documents: tuple[TaxonomyDocument, ...] | None = None
    _environment_documents: list[EnvironmentDocument] = field(
        init=False,
        repr=False,
        default_factory=_environment_document_list,
    )
    _errors: list[DocumentError] = field(
        init=False,
        repr=False,
        default_factory=_document_error_list,
    )

    def _parse_documents(self, path: Path) -> tuple[TaxonomyDocument, ...]:
        documents: list[TaxonomyDocument] = []
        index = 0
        try:
            with path.open("r", encoding="utf-8") as stream:
                try:
                    for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                        if not document:
                            continue
                        try:
                            mapping = _as_mapping(document)
                            api_version = str(mapping.get("apiVersion"))
                            kind = str(mapping.get("kind"))
                            if api_version != API_VERSION:
                                logger.debug(
                                    "Skipping non-taxonomy document in {} due to apiVersion mismatch ({}).",
                                    path,
                                    api_version,
                                )
                                continue
                            if kind == KIND:
                                documents.append(_document_from_mapping(mapping, source_path=path))
                                continue
                            if kind == ENVIRONMENT_KIND:
                                self._environment_documents.append(
                                    environment_from_mapping(mapping, source_path=path),
                                )
                                continue
                            logger.debug(
                                "Skipping unsupported document in {} (kind={})",
                                path,
                                kind,
                            )
                            continue
                        except Exception as exc:  # pragma: no cover - converted to diagnostics
                            self._errors.append(
                                DocumentError(path=path, document_index=index, message=str(exc)),
                            )
                except yaml.YAMLError as exc:
                    self._errors.append(
                        DocumentError(path=path, document_index=index, message=str(exc)),
                    )
                    logger.warning(
                        "YAML parse error in {} (document {}): {}",
                        path,
                        index,
                        exc,
                    )
        except OSError as exc:
            self._errors.append(DocumentError(path=path, document_index=0, message=str(exc)))
            logger.warning("Failed to open {}: {}", path, exc)

        return tuple(documents)

    def _load_documents(self) -> tuple[TaxonomyDocument, ...]:
        base = self.base_path
        if not base.exists():
            raise FileNotFoundError(f"Taxonomy path does not exist: {base}")

        documents: list[TaxonomyDocument] = []
        self._errors = []
        self._environment_documents = []

        layer_directories: set[Path] = set()
        candidates = [path for path in self.strategy.discover(base) if path.name != IGNOREFILE_NAME]
        candidates.sort(key=lambda p: (len(p.parts), str(p)))

        ignore = load_ignore(base)

        for path in candidates:
            if any(
                layer_dir in path.parents and path.parent != layer_dir
                for layer_dir in layer_directories
            ):
                continue

            if ignore and ignore.should_ignore(path, is_dir=path.is_dir()):
                logger.debug("Skipping ignored path {}", path)
                continue

            parsed = self._parse_documents(path)
            documents.extend(parsed)

            if any(doc.taxonomy_node_type == "layer" for doc in parsed):
                layer_directories.add(path.parent)

        return tuple(documents)

    def load_graph(self) -> tuple[TaxonomyDocument, ...]:
        if self._documents is None:
            self._documents = self._load_documents()
        return self._documents

    def environments(self) -> tuple[EnvironmentDocument, ...]:
        if self._documents is None:
            self._documents = self._load_documents()
        return tuple(self._environment_documents)

    def get_node(self, name: str) -> TaxonomyDocument | None:
        graph = self.load_graph()
        return next((doc for doc in graph if doc.metadata.name == name), None)

    def errors(self) -> tuple[DocumentError, ...]:
        return tuple(self._errors)
