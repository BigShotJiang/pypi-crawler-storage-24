"""Builder abstractions for constructing taxonomy hierarchies."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Protocol, Sequence, runtime_checkable

from .nodes import Layer, Stack, Subsystem, System


@dataclass(frozen=True, slots=True)
class LayerDefinition:
    """Definition data for constructing a Layer node."""

    name: str
    description: str | None = None
    layer_type: str | None = None
    template: str | None = None


@dataclass(frozen=True, slots=True)
class StackDefinition:
    """Definition data for a Stack node and its child Layers."""

    name: str
    layers: Sequence[LayerDefinition] = field(default_factory=tuple)
    description: str | None = None
    template: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "layers", tuple(self.layers))


@dataclass(frozen=True, slots=True)
class SubsystemDefinition:
    """Definition data for a Subsystem node and child Stacks."""

    name: str
    stacks: Sequence[StackDefinition] = field(default_factory=tuple)
    description: str | None = None
    template: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "stacks", tuple(self.stacks))


@dataclass(frozen=True, slots=True)
class SystemDefinition:
    """Definition data for a System node and child Subsystems."""

    name: str
    subsystems: Sequence[SubsystemDefinition] = field(default_factory=tuple)
    description: str | None = None
    template: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "subsystems", tuple(self.subsystems))


@dataclass(frozen=True, slots=True)
class BuiltTaxonomy:
    """Concrete taxonomy produced by a builder."""

    systems: tuple[System, ...]
    subsystems: tuple[Subsystem, ...]
    stacks: tuple[Stack, ...]
    layers: tuple[Layer, ...]

    def __iter__(self) -> Iterable[System]:
        return iter(self.systems)


@runtime_checkable
class TaxonomyBuilder(Protocol):
    """Port that produces a fully-hydrated taxonomy."""

    def build(self) -> BuiltTaxonomy:
        """Construct and return the taxonomy."""
        ...


@dataclass(frozen=True, slots=True)
class InMemoryTaxonomyBuilder:
    """Build a taxonomy from in-memory definition objects."""

    systems: Sequence[SystemDefinition] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        object.__setattr__(self, "systems", tuple(self.systems))

    def build(self) -> BuiltTaxonomy:
        systems: list[System] = []
        subsystems: list[Subsystem] = []
        stacks: list[Stack] = []
        layers: list[Layer] = []

        for system_def in self.systems:
            system = System(name=system_def.name, description=system_def.description)
            systems.append(system)

            for subsystem_def in system_def.subsystems:
                subsystem = Subsystem(
                    name=subsystem_def.name,
                    description=subsystem_def.description,
                    parent=system,
                )
                subsystems.append(subsystem)

                for stack_def in subsystem_def.stacks:
                    stack = Stack(
                        name=stack_def.name,
                        description=stack_def.description,
                        parent=subsystem,
                    )
                    stacks.append(stack)

                    for layer_def in stack_def.layers:
                        layer = Layer(
                            name=layer_def.name,
                            description=layer_def.description,
                            parent=stack,
                        )
                        layers.append(layer)

        return BuiltTaxonomy(
            systems=tuple(systems),
            subsystems=tuple(subsystems),
            stacks=tuple(stacks),
            layers=tuple(layers),
        )
