"""Domain models for representing the Prima taxonomy hierarchy."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import ClassVar, cast

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slugify(value: str) -> str:
    slug = _SLUG_RE.sub("-", value.lower()).strip("-")
    return slug or "_"


@dataclass(frozen=True, slots=True)
class TaxonomyContext:
    """Resolved taxonomy coordinates for a node."""

    system: System | None
    subsystem: Subsystem | None
    stack: Stack | None
    layer: Layer | None

    def as_tuple(self) -> tuple[TaxonomyNode, ...]:
        nodes: list[TaxonomyNode] = []
        for node in (self.system, self.subsystem, self.stack, self.layer):
            if node is not None:
                nodes.append(node)
        return tuple(nodes)

    @property
    def path(self) -> tuple[str, ...]:
        return tuple(node.slug for node in self.as_tuple())

    @property
    def qualified_name(self) -> str:
        return ".".join(node.slug for node in self.as_tuple())


@dataclass(frozen=True, slots=True, kw_only=True)
class TaxonomyNode:
    """Base taxonomy element with shared behaviours."""

    name: str
    description: str | None = None
    parent: TaxonomyNode | None = field(default=None, repr=False)
    _taxonomy_context: TaxonomyContext | None = field(
        init=False,
        default=None,
        repr=False,
        compare=False,
    )

    kind: ClassVar[str] = "taxonomy"

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("name cannot be blank")

    @property
    def slug(self) -> str:
        return _slugify(self.name)

    @property
    def hierarchy(self) -> tuple[TaxonomyNode, ...]:
        if self.parent is None:
            return (self,)
        return (*self.parent.hierarchy, self)

    @property
    def depth(self) -> int:
        return len(self.hierarchy) - 1

    @property
    def path(self) -> tuple[str, ...]:
        return tuple(node.slug for node in self.hierarchy)

    @property
    def qualified_name(self) -> str:
        return ".".join(self.path)

    @property
    def root(self) -> TaxonomyNode:
        return self.hierarchy[0]

    def ancestors(self) -> tuple[TaxonomyNode, ...]:
        return self.hierarchy[:-1]

    def is_root(self) -> bool:
        return self.parent is None

    @property
    def lineage(self) -> TaxonomyContext:
        """Resolved taxonomy context for this node."""

        context = self._taxonomy_context
        if context is None:
            context = _build_taxonomy_context(self)
            object.__setattr__(self, "_taxonomy_context", context)
        return context


@dataclass(frozen=True, slots=True, kw_only=True)
class System(TaxonomyNode):
    kind: ClassVar[str] = "system"

    def __post_init__(self) -> None:
        if self.parent is not None:
            raise ValueError("System nodes cannot have a parent")
        TaxonomyNode.__post_init__(self)

    @property
    def system(self) -> System:
        return self


@dataclass(frozen=True, slots=True, kw_only=True)
class Subsystem(TaxonomyNode):
    kind: ClassVar[str] = "subsystem"

    def __post_init__(self) -> None:
        if not isinstance(self.parent, System):
            raise ValueError("Subsystem nodes require a System parent")
        TaxonomyNode.__post_init__(self)

    @property
    def system(self) -> System:
        return cast(System, self.parent)


@dataclass(frozen=True, slots=True, kw_only=True)
class Stack(TaxonomyNode):
    kind: ClassVar[str] = "stack"

    def __post_init__(self) -> None:
        if not isinstance(self.parent, Subsystem):
            raise ValueError("Stack nodes require a Subsystem parent")
        TaxonomyNode.__post_init__(self)

    @property
    def subsystem(self) -> Subsystem:
        return cast(Subsystem, self.parent)

    @property
    def system(self) -> System:
        return self.subsystem.system


@dataclass(frozen=True, slots=True, kw_only=True)
class Layer(TaxonomyNode):
    kind: ClassVar[str] = "layer"

    def __post_init__(self) -> None:
        if not isinstance(self.parent, Stack):
            raise ValueError("Layer nodes require a Stack parent")
        TaxonomyNode.__post_init__(self)

    @property
    def stack(self) -> Stack:
        stack = self.lineage.stack
        if stack is None:
            raise RuntimeError("Layer nodes require a Stack ancestor")
        return stack

    @property
    def subsystem(self) -> Subsystem:
        subsystem = self.lineage.subsystem
        if subsystem is None:
            raise RuntimeError("Layer nodes require a Subsystem ancestor")
        return subsystem

    @property
    def system(self) -> System:
        system = self.lineage.system
        if system is None:
            raise RuntimeError("Layer nodes require a System ancestor")
        return system


def _build_taxonomy_context(node: TaxonomyNode) -> TaxonomyContext:
    system: System | None = None
    subsystem: Subsystem | None = None
    stack: Stack | None = None
    layer: Layer | None = None

    for entry in node.hierarchy:
        if entry.kind == "system":
            system = cast(System, entry)
        elif entry.kind == "subsystem":
            subsystem = cast(Subsystem, entry)
        elif entry.kind == "stack":
            stack = cast(Stack, entry)
        elif entry.kind == "layer":
            layer = cast(Layer, entry)

    return TaxonomyContext(system=system, subsystem=subsystem, stack=stack, layer=layer)
