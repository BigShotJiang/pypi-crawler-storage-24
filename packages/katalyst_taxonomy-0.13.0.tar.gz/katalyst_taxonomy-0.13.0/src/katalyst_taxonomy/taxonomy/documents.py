"""Taxonomy document model and ports aligned with YAML resources."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Protocol, runtime_checkable

API_VERSION = "katalyst.taxonomy/v1alpha"
KIND = "TaxonomyNode"


@dataclass(frozen=True, slots=True)
class TaxonomyMetadata:
    """Metadata associated with a taxonomy document."""

    name: str
    labels: Mapping[str, str] | None = None

    def __post_init__(self) -> None:
        name = self.name.strip() if self.name else ""
        if not name:
            raise ValueError("name cannot be blank")
        # Create immutable copy of labels
        labels: dict[str, str] = (
            {} if self.labels is None else {k: v for k, v in self.labels.items()}
        )
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "labels", labels)


@dataclass(frozen=True, slots=True)
class TaxonomyDependencies:
    """Dependencies defined for a taxonomy node."""

    nodes: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "nodes", tuple(self.nodes))


@dataclass(frozen=True, slots=True)
class TaxonomyParents:
    """Parent relationships for a taxonomy node."""

    node: str

    def __post_init__(self) -> None:
        if not self.node:
            raise ValueError("node cannot be blank")


@dataclass(frozen=True, slots=True)
class TaxonomySpec:
    """Specification payload of a taxonomy node."""

    description: str | None = None
    owners: tuple[str, ...] = ()
    annotations: Mapping[str, str] | None = None
    depends_on: TaxonomyDependencies | None = None
    parents: TaxonomyParents | None = None
    extensions: Mapping[str, object] | None = None
    environments: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        owners = tuple(self.owners)
        annotations: dict[str, str] = (
            {} if self.annotations is None else {k: v for k, v in self.annotations.items()}
        )
        object.__setattr__(self, "owners", owners)
        object.__setattr__(self, "annotations", annotations)
        extensions = None
        if self.extensions is not None:
            extensions = dict(self.extensions)
        object.__setattr__(self, "extensions", extensions)
        object.__setattr__(self, "environments", tuple(self.environments))


@dataclass(frozen=True, slots=True)
class TaxonomyDocument:
    """Top-level taxonomy document mirroring the YAML layout."""

    api_version: str
    kind: str
    metadata: TaxonomyMetadata
    taxonomy_node_type: str
    spec: TaxonomySpec
    source_path: Path | None = None

    def __post_init__(self) -> None:
        if self.api_version != API_VERSION:
            raise ValueError(f"Unsupported apiVersion: {self.api_version}")
        if self.kind != KIND:
            raise ValueError(f"Unsupported kind: {self.kind}")
        if not self.taxonomy_node_type:
            raise ValueError("taxonomy_node_type cannot be blank")
        # Convert string paths to Path objects at runtime
        if self.source_path is not None and not isinstance(self.source_path, Path):  # type: ignore[redundant-expr]
            object.__setattr__(self, "source_path", Path(self.source_path))  # type: ignore[arg-type]


@runtime_checkable
class TaxonomyNodeSource(Protocol):
    """Port for retrieving individual taxonomy documents."""

    def get_node(self, name: str) -> TaxonomyDocument | None:
        """Return the document identified by metadata.name, if present."""
        ...


@runtime_checkable
class TaxonomyGraphSource(Protocol):
    """Port for retrieving the full taxonomy document set."""

    def load_graph(self) -> tuple[TaxonomyDocument, ...]:
        """Return all known taxonomy documents."""
        ...


class InMemoryTaxonomyDocumentStore(TaxonomyNodeSource, TaxonomyGraphSource):
    """Simple in-memory adapter suitable for testing."""

    def __init__(self, *, documents: tuple[TaxonomyDocument, ...] | None = None) -> None:
        ordered = tuple(documents or ())
        lookup = {doc.metadata.name: doc for doc in ordered}
        if len(lookup) != len(ordered):
            raise ValueError("Duplicate taxonomy document names detected")
        self._documents: tuple[TaxonomyDocument, ...] = ordered
        self._lookup: dict[str, TaxonomyDocument] = lookup

    def get_node(self, name: str) -> TaxonomyDocument | None:
        return self._lookup.get(name)

    def load_graph(self) -> tuple[TaxonomyDocument, ...]:
        return self._documents
