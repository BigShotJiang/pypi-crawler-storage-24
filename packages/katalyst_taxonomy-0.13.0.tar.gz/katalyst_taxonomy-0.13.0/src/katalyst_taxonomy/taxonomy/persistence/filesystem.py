"""Filesystem-based adapter for creating taxonomy documents."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import yaml

from ..documents import TaxonomyDocument
from ..management import TaxonomyWriter

KIND_DIRECTORIES: dict[str, str] = {
    "system": "systems",
    "subsystem": "subsystems",
    "stack": "stacks",
    "layer": "layers",
    "organization": "organizations",
    "program": "programs",
    "project": "projects",
    "team": "teams",
    "team_member": "team_members",
}


@dataclass(slots=True)
class FilesystemTaxonomyWriter(TaxonomyWriter):
    """Persist taxonomy documents to the filesystem."""

    base_path: Path
    default_filename: str = "taxonomy.yaml"

    def create(self, document: TaxonomyDocument) -> None:
        layout = self._determine_layout()
        if layout == "single-file":
            target = self._single_file_path()
            self._append_to_file(target, document)
            return
        if layout == "by-kind":
            target = self._target_path_for_kind(document)
            self._write_new_file(target, document)
            return

        target = self._single_file_path()
        self._append_to_file(target, document)

    # layout helpers -----------------------------------------------------

    def _determine_layout(self) -> str:
        if self.base_path.is_file():
            return "single-file"

        directory = self.base_path.resolve()
        if (directory / self.default_filename).exists():
            return "single-file"

        if any((directory / child).is_dir() for child in KIND_DIRECTORIES.values()):
            return "by-kind"

        return "single-file"

    def _single_file_path(self) -> Path:
        if self.base_path.is_file():
            return self.base_path
        directory = self.base_path
        directory.mkdir(parents=True, exist_ok=True)
        return directory / self.default_filename

    def _target_path_for_kind(self, document: TaxonomyDocument) -> Path:
        directory_name = KIND_DIRECTORIES.get(document.taxonomy_node_type)
        if directory_name is None:
            raise ValueError(f"Unsupported taxonomy node type: {document.taxonomy_node_type}")
        directory = self.base_path / directory_name
        directory.mkdir(parents=True, exist_ok=True)
        filename = f"{document.metadata.name}.yaml"
        return directory / filename

    # file writing -------------------------------------------------------

    def _append_to_file(self, path: Path, document: TaxonomyDocument) -> None:
        existing: list[Mapping[str, Any]] = []
        if path.exists():
            with path.open("r", encoding="utf-8") as handle:
                existing = [doc for doc in yaml.safe_load_all(handle) if doc]

        existing.append(_document_to_mapping(document))
        with path.open("w", encoding="utf-8") as handle:
            yaml.safe_dump_all(existing, handle, sort_keys=False)

    def _write_new_file(self, path: Path, document: TaxonomyDocument) -> None:
        if path.exists():
            raise FileExistsError(f"Taxonomy document already exists: {path}")
        with path.open("w", encoding="utf-8") as handle:
            yaml.safe_dump(_document_to_mapping(document), handle, sort_keys=False)


def _document_to_mapping(document: TaxonomyDocument) -> dict[str, Any]:
    spec_mapping: dict[str, Any] = {}
    if document.spec.description is not None:
        spec_mapping["description"] = document.spec.description
    if document.spec.owners:
        spec_mapping["owners"] = list(document.spec.owners)
    if document.spec.annotations:
        spec_mapping["annotations"] = dict(document.spec.annotations)
    if document.spec.environments:
        spec_mapping["environments"] = list(document.spec.environments)

    if document.spec.depends_on is not None and document.spec.depends_on.nodes:
        spec_mapping["dependsOn"] = {
            "nodes": list(document.spec.depends_on.nodes),
        }
    if document.spec.parents is not None and document.spec.parents.node:
        spec_mapping["parents"] = {"node": document.spec.parents.node}
    if document.spec.extensions:
        spec_mapping["extensions"] = dict(document.spec.extensions)

    return {
        "apiVersion": document.api_version,
        "kind": document.kind,
        "taxonomyNodeType": document.taxonomy_node_type,
        "metadata": {
            "name": document.metadata.name,
            "labels": dict(document.metadata.labels or {}),
        },
        "spec": spec_mapping,
    }
