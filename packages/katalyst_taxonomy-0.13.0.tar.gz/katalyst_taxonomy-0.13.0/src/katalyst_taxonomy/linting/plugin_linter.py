"""Linting helpers for plugin documents."""

from __future__ import annotations

import json
from collections.abc import Mapping as MappingABC
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence, cast

import yaml
from jsonschema import Draft202012Validator

from ..taxonomy.ignore import TaxonomyIgnore, load_ignore
from ._shared import classify_validation_error, hint_for_group
from .models import LintViolation, PluginLintResult

YAML_EXTENSIONS = (".yaml", ".yml")


@dataclass(frozen=True, slots=True)
class PluginSchemaDescriptor:
    kind: str
    schema_relative_path: str
    label: str | None = None


@dataclass(frozen=True, slots=True)
class PluginConfig:
    name: str
    relative_directories: tuple[str, ...]
    api_version: str
    schemas: tuple[PluginSchemaDescriptor, ...]


_PLUGIN_CONFIGS: dict[str, PluginConfig] = {
    "cicd": PluginConfig(
        name="cicd",
        relative_directories=(".global/taxonomy/cicd",),
        api_version="katalyst.taxonomy.plugins.cicd/v1alpha",
        schemas=(
            PluginSchemaDescriptor(
                "WorkflowTemplate",
                "schemas/plugins/cicd/workflow-template.schema.json",
                label="workflows",
            ),
            PluginSchemaDescriptor(
                "JobTemplate",
                "schemas/plugins/cicd/job-template.schema.json",
                label="jobs",
            ),
            PluginSchemaDescriptor(
                "Stage",
                "schemas/plugins/cicd/stage.schema.json",
                label="stages",
            ),
        ),
    ),
    "capabilities": PluginConfig(
        name="capabilities",
        relative_directories=(".global/taxonomy/capabilities",),
        api_version="katalyst.taxonomy.plugins.capabilities/v1alpha",
        schemas=(
            PluginSchemaDescriptor(
                "Capability",
                "schemas/plugins/capabilities/capability.schema.json",
                label="capabilities",
            ),
            PluginSchemaDescriptor(
                "CapabilityRelationship",
                "schemas/plugins/capabilities/capability-relationship.schema.json",
                label="relationships",
            ),
        ),
    ),
    "actions": PluginConfig(
        name="actions",
        relative_directories=(".global/taxonomy/actions", ".global/taxonomy/layer_actions"),
        api_version="katalyst.taxonomy.plugins.actions/v1alpha",
        schemas=(
            PluginSchemaDescriptor(
                "Action",
                "schemas/plugins/layer-actions/action.schema.json",
                label="actions",
            ),
        ),
    ),
    "layer_types": PluginConfig(
        name="layer_types",
        relative_directories=(".global/taxonomy/layerTypes", ".global/taxonomy/layer_types"),
        api_version="katalyst.taxonomy.plugins.layer_types/v1alpha",
        schemas=(
            PluginSchemaDescriptor(
                "LayerType",
                "schemas/plugins/layer-types/layer-type.schema.json",
                label="layerTypes",
            ),
        ),
    ),
    "tools": PluginConfig(
        name="tools",
        relative_directories=(".global/taxonomy/tools",),
        api_version="katalyst.taxonomy.plugins.tools/v1alpha",
        schemas=(
            PluginSchemaDescriptor(
                "Tool",
                "schemas/plugins/tools/tool.schema.json",
                label="tools",
            ),
        ),
    ),
}


def lint_cicd_plugins(path: Path) -> PluginLintResult:
    return _lint_plugin(path, _PLUGIN_CONFIGS["cicd"])


def lint_capabilities(path: Path) -> PluginLintResult:
    return _lint_plugin(path, _PLUGIN_CONFIGS["capabilities"])


def lint_actions(path: Path) -> PluginLintResult:
    return _lint_plugin(path, _PLUGIN_CONFIGS["actions"])


def lint_layer_types(path: Path) -> PluginLintResult:
    return _lint_plugin(path, _PLUGIN_CONFIGS["layer_types"])


def lint_tools(path: Path) -> PluginLintResult:
    return _lint_plugin(path, _PLUGIN_CONFIGS["tools"])


def _lint_plugin(base_path: Path, config: PluginConfig) -> PluginLintResult:
    base = base_path.resolve()
    ignore = load_ignore(base)
    files = _collect_plugin_documents(base, config.relative_directories, ignore)
    validators: dict[str, Draft202012Validator] = {}
    schema_paths: dict[str, Path] = {}
    labels: dict[str, str] = {}
    for descriptor in config.schemas:
        schema, schema_path = _load_schema(descriptor.schema_relative_path)
        validators[descriptor.kind] = Draft202012Validator(schema)
        schema_paths[descriptor.kind] = schema_path
        labels[descriptor.kind] = descriptor.label or descriptor.kind

    counts: dict[str, int] = {descriptor.kind: 0 for descriptor in config.schemas}
    errors: list[LintViolation] = []

    for candidate in files:
        try:
            with candidate.open("r", encoding="utf-8") as stream:
                for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                    mapping = _as_mapping(document)
                    if not mapping:
                        continue
                    if mapping.get("apiVersion") != config.api_version:
                        continue
                    kind_value = mapping.get("kind")
                    if not isinstance(kind_value, str):
                        continue
                    validator = validators.get(kind_value)
                    if not validator:
                        continue

                    counts[kind_value] += 1
                    node_name = _extract_name(mapping)
                    json_instance = cast(dict[str, Any], mapping)
                    for violation in validator.iter_errors(json_instance):  # type: ignore[reportUnknownMemberType]
                        group_key, group_label = classify_validation_error(violation)
                        hint = hint_for_group(group_key)
                        errors.append(
                            LintViolation(
                                path=candidate,
                                document_index=index,
                                node_name=node_name,
                                node_type=kind_value,
                                qualified_name=node_name,
                                message=str(violation.message),
                                group_key=group_key,
                                group_label=group_label,
                                hint=hint,
                            ),
                        )
        except yaml.YAMLError as exc:
            errors.append(
                LintViolation(
                    path=candidate,
                    document_index=0,
                    node_name="",
                    node_type=config.name,
                    qualified_name="",
                    message=f"YAML error: {exc}",
                    group_key="yaml",
                    group_label="YAML parse error",
                    hint=None,
                ),
            )
        except OSError as exc:
            errors.append(
                LintViolation(
                    path=candidate,
                    document_index=0,
                    node_name="",
                    node_type=config.name,
                    qualified_name="",
                    message=str(exc),
                    group_key="io",
                    group_label="Filesystem error",
                    hint=None,
                ),
            )

    return PluginLintResult(
        name=config.name,
        counts=counts,
        schema_paths=schema_paths,
        labels=labels,
        errors=tuple(errors),
    )


def _collect_plugin_documents(
    base_path: Path,
    relative_dirs: Sequence[str],
    ignore: TaxonomyIgnore | None,
) -> tuple[Path, ...]:
    files: list[Path] = []
    seen: set[Path] = set()
    for entry in relative_dirs:
        root = (base_path / entry).resolve()
        if not root.exists():
            continue
        stack: list[Path] = [root]
        while stack:
            current = stack.pop()
            is_dir = current.is_dir()
            if ignore and ignore.should_ignore(current, is_dir=is_dir):
                continue
            if is_dir:
                try:
                    for child in current.iterdir():
                        stack.append(child)
                except OSError:
                    continue
                continue
            if current.suffix.lower() in YAML_EXTENSIONS and current not in seen:
                seen.add(current)
                files.append(current)
    files.sort(key=lambda item: (len(item.parts), str(item)))
    return tuple(files)


def _load_schema(relative_path: str) -> tuple[dict[str, object], Path]:
    for directory in _candidate_roots(Path(__file__).resolve()):
        schema_path = directory / relative_path
        if schema_path.exists():
            try:
                raw = schema_path.read_text(encoding="utf-8")
            except OSError as exc:  # pragma: no cover - surfaced to caller
                raise FileNotFoundError(f"Failed to read schema file: {schema_path}") from exc
            return json.loads(raw), schema_path
    raise FileNotFoundError(f"Unable to locate schema file: {relative_path}")


def _candidate_roots(start: Path) -> Iterable[Path]:
    current = start.parent
    while True:
        yield current
        if current.parent == current:
            break
        current = current.parent


def _as_mapping(value: object) -> Mapping[str, object] | None:
    if isinstance(value, MappingABC):
        return cast(Mapping[str, object], value)
    return None


def _extract_name(mapping: Mapping[str, object]) -> str:
    metadata = mapping.get("metadata")
    if isinstance(metadata, MappingABC):
        metadata_map = cast(Mapping[str, object], metadata)
        raw_name: object = metadata_map.get("name")
        if raw_name:
            return str(raw_name)
    return ""
