"""Utilities for working with layer types.

This module is intentionally minimal.  Layer type names are no longer
validated against a hardcoded set — the template source is the single
source of truth for which types are available.
"""

from __future__ import annotations

__all__: list[str] = []
