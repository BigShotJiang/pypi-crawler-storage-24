"""Bundled agent and skill definitions.

This package contains the default agents and skills that ship with the
katalyst-taxonomy package.  The content is kept in sync with the
``.agents/`` directory at the repository root via::

    just agents-bundle

At runtime the ``bundled`` module (``agents/bundled.py``) uses
``importlib.resources`` to locate these files so they are accessible
even after ``pip install``.
"""
