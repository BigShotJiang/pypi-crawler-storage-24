"""Resolution service for matching agents and skills to taxonomy contexts.

This module provides the core resolution logic that answers:
"Given a layer type (or other taxonomy scope), which agents and skills apply?"

Resolution uses two sources:
1. **Scope-based**: Each agent/skill declares its own ``scope.layer_types``
2. **Bindings-based**: Central ``agents.yaml`` can map names to layer types
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from katalyst_taxonomy.agents.models import Agent, Bindings, Scope, Skill

__all__ = [
    "ResolvedContext",
    "resolve_for_layer_type",
]


@dataclass(frozen=True, slots=True)
class ResolvedContext:
    """Agents and skills resolved for a specific taxonomy context.

    Attributes:
        agents: Agents matching the context.
        skills: Skills matching the context.
        layer_type: The layer type used for resolution (if any).
    """

    agents: tuple[Agent, ...]
    skills: tuple[Skill, ...]
    layer_type: str | None = None

    @property
    def agent_names(self) -> tuple[str, ...]:
        """Names of resolved agents, preserving order."""
        return tuple(a.name for a in self.agents)

    @property
    def skill_names(self) -> tuple[str, ...]:
        """Names of resolved skills, preserving order."""
        return tuple(s.name for s in self.skills)


def _scope_matches_layer_type(scope: Scope, layer_type: str) -> bool:
    """Check whether a scope includes the given layer type.

    A scope matches if:
    - ``global_`` is True (available everywhere), OR
    - ``layer_types`` contains the target layer type.
    """
    if scope.global_:
        return True
    return layer_type in scope.layer_types


def resolve_for_layer_type(
    layer_type: str,
    agents: Sequence[Agent],
    skills: Sequence[Skill],
    bindings: Bindings | None = None,
) -> ResolvedContext:
    """Return agents and skills applicable to the given layer type.

    Resolution rules (applied in order, deduplicated):

    1. Include if ``scope.layer_types`` contains the layer type.
    2. Include if ``scope.global_`` is ``True``.
    3. Include if referenced in ``bindings.layer_types[layer_type]``.

    Args:
        layer_type: The canonical layer type name (e.g. ``"app-docker"``).
        agents: All available agents to filter.
        skills: All available skills to filter.
        bindings: Optional central bindings from ``agents.yaml``.

    Returns:
        A ResolvedContext with the matching agents and skills.
    """
    # Build lookup dicts for bindings-based resolution
    bound_names: set[str] = set()
    if bindings is not None:
        bound_names = set(bindings.layer_types.get(layer_type, ()))

    # Build name-keyed lookups for binding resolution
    agents_by_name: dict[str, Agent] = {a.name: a for a in agents}
    skills_by_name: dict[str, Skill] = {s.name: s for s in skills}

    # ── Resolve agents ───────────────────────────────────────────────
    resolved_agents: list[Agent] = []
    seen_agent_names: set[str] = set()

    # Pass 1: scope-based
    for agent in agents:
        if _scope_matches_layer_type(agent.scope, layer_type):
            resolved_agents.append(agent)
            seen_agent_names.add(agent.name)

    # Pass 2: bindings-based (add those not already included)
    for name in bound_names:
        if name not in seen_agent_names and name in agents_by_name:
            resolved_agents.append(agents_by_name[name])
            seen_agent_names.add(name)

    # ── Resolve skills ───────────────────────────────────────────────
    resolved_skills: list[Skill] = []
    seen_skill_names: set[str] = set()

    # Pass 1: scope-based
    for skill in skills:
        if _scope_matches_layer_type(skill.scope, layer_type):
            resolved_skills.append(skill)
            seen_skill_names.add(skill.name)

    # Pass 2: bindings-based (add those not already included)
    for name in bound_names:
        if name not in seen_skill_names and name in skills_by_name:
            resolved_skills.append(skills_by_name[name])
            seen_skill_names.add(name)

    return ResolvedContext(
        agents=tuple(resolved_agents),
        skills=tuple(resolved_skills),
        layer_type=layer_type,
    )
