"""Directory discovery for .agents/ directories.

This module provides functionality to locate and scan .agents/ directories,
walking up from the current working directory to the git root (or filesystem root).

When ``include_bundled=True`` (the default), agents and skills shipped inside
the ``katalyst-taxonomy`` Python package are merged in as defaults.  Local
definitions (found on the filesystem) always take precedence over bundled ones.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator

from loguru import logger

from katalyst_taxonomy.agents.models import Agent, AgentsConfig, Skill
from katalyst_taxonomy.agents.parser import (
    ParseError,
    parse_agent_file,
    parse_config_file,
    parse_skill_file,
)

__all__ = [
    "AgentsDirectory",
    "DiscoveryError",
    "discover_agents_directory",
    "find_git_root",
    "scan_agents_directory",
]


class DiscoveryError(Exception):
    """Error during directory discovery."""

    pass


def find_git_root(start_path: Path | None = None) -> Path | None:
    """Find the git repository root from a starting path.

    Args:
        start_path: Starting directory. Defaults to current working directory.

    Returns:
        Path to git root, or None if not in a git repository.
    """
    if start_path is None:
        start_path = Path.cwd()

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=start_path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return Path(result.stdout.strip())
    except (subprocess.SubprocessError, FileNotFoundError):
        pass

    return None


def discover_agents_directory(
    start_path: Path | None = None,
    stop_at_git_root: bool = True,
) -> Path | None:
    """Discover the nearest .agents/ directory.

    Walks up from start_path looking for a .agents/ directory. Stops at the
    git root by default, or filesystem root if not in a git repo.

    Args:
        start_path: Starting directory. Defaults to current working directory.
        stop_at_git_root: If True, stop searching at git root.

    Returns:
        Path to the .agents/ directory, or None if not found.
    """
    if start_path is None:
        start_path = Path.cwd()

    start_path = start_path.resolve()

    # Determine where to stop searching
    if stop_at_git_root:
        git_root = find_git_root(start_path)
        stop_path = git_root.parent if git_root else None
    else:
        stop_path = None

    current = start_path
    while True:
        agents_dir = current / ".agents"
        if agents_dir.is_dir():
            logger.debug(f"Found .agents/ directory at {agents_dir}")
            return agents_dir

        # Check if we've reached the stop point
        if stop_path and current == stop_path:
            break

        # Move up
        parent = current.parent
        if parent == current:
            # Reached filesystem root
            break
        current = parent

    logger.debug(f"No .agents/ directory found starting from {start_path}")
    return None


@dataclass
class AgentsDirectory:
    """Represents a scanned .agents/ directory.

    Attributes:
        path: Path to the .agents/ directory.
        config: Parsed configuration (agents.yaml), or None if not present.
        agents: List of parsed agents.
        skills: List of parsed skills.
        errors: List of parse errors encountered.
    """

    path: Path
    config: AgentsConfig | None = None
    agents: list[Agent] = field(default_factory=lambda: list[Agent]())
    skills: list[Skill] = field(default_factory=lambda: list[Skill]())
    errors: list[ParseError] = field(default_factory=lambda: list[ParseError]())

    @property
    def agents_dir(self) -> Path:
        """Path to the agents/ subdirectory."""
        return self.path / "agents"

    @property
    def skills_dir(self) -> Path:
        """Path to the skills/ subdirectory."""
        return self.path / "skills"

    @property
    def context_dir(self) -> Path:
        """Path to the context/ subdirectory."""
        return self.path / "context"

    def get_agent(self, name: str) -> Agent | None:
        """Get an agent by name."""
        for agent in self.agents:
            if agent.name == name:
                return agent
        return None

    def get_skill(self, name: str) -> Skill | None:
        """Get a skill by name."""
        for skill in self.skills:
            if skill.name == name:
                return skill
        return None


def _iter_agent_files(agents_dir: Path) -> Iterator[Path]:
    """Iterate over agent markdown files in a directory.

    Finds all .md files, including nested directories for agent systems.
    """
    if not agents_dir.is_dir():
        return

    for path in agents_dir.rglob("*.md"):
        if path.is_file():
            yield path


def _iter_skill_dirs(skills_dir: Path) -> Iterator[Path]:
    """Iterate over skill directories (containing SKILL.md).

    Skills are organized as:
        skills/<name>/SKILL.md
    """
    if not skills_dir.is_dir():
        return

    for skill_dir in skills_dir.iterdir():
        if skill_dir.is_dir():
            skill_file = skill_dir / "SKILL.md"
            if skill_file.is_file():
                yield skill_file


def scan_agents_directory(
    path: Path,
    *,
    include_bundled: bool = True,
) -> AgentsDirectory:
    """Scan a .agents/ directory and parse all contents.

    When *include_bundled* is ``True`` (the default), agents and skills that
    ship inside the ``katalyst-taxonomy`` package are merged in.  Local
    definitions always take precedence — bundled items only appear when there
    is no local file with the same name.

    Args:
        path: Path to the .agents/ directory.
        include_bundled: Merge bundled defaults into the result.

    Returns:
        An AgentsDirectory with all parsed agents, skills, and config.
    """
    result = AgentsDirectory(path=path)

    # Parse config file (agents.yaml or agents.json)
    for config_name in ("agents.yaml", "agents.yml", "agents.json"):
        config_path = path / config_name
        if config_path.is_file():
            try:
                result.config = parse_config_file(config_path)
                logger.debug(f"Loaded config from {config_path}")
            except ParseError as e:
                logger.warning(f"Failed to parse config: {e}")
                result.errors.append(e)
            break

    # Parse agent files
    agents_dir = path / "agents"
    for agent_path in _iter_agent_files(agents_dir):
        try:
            agent = parse_agent_file(agent_path)
            agent.source = "local"
            result.agents.append(agent)
            logger.debug(f"Loaded agent '{agent.name}' from {agent_path}")
        except ParseError as e:
            logger.warning(f"Failed to parse agent: {e}")
            result.errors.append(e)

    # Parse skill files
    skills_dir = path / "skills"
    for skill_path in _iter_skill_dirs(skills_dir):
        try:
            skill = parse_skill_file(skill_path)
            skill.source = "local"
            result.skills.append(skill)
            logger.debug(f"Loaded skill '{skill.name}' from {skill_path}")
        except ParseError as e:
            logger.warning(f"Failed to parse skill: {e}")
            result.errors.append(e)

    # ── Merge bundled defaults ──────────────────────────────────────────
    if include_bundled:
        _merge_bundled(result)

    # Sort by name for consistent ordering
    result.agents.sort(key=lambda a: a.name)
    result.skills.sort(key=lambda s: s.name)

    logger.info(
        f"Scanned {path}: {len(result.agents)} agents, {len(result.skills)} skills, "
        f"{len(result.errors)} errors"
    )

    return result


def _merge_bundled(directory: AgentsDirectory) -> None:
    """Merge bundled agents/skills into *directory*.

    Only items whose name does **not** already exist in the directory are added.
    Bundled items are tagged with ``source="bundled"``.
    """
    from katalyst_taxonomy.agents.bundled import get_bundled_path

    bundled_path = get_bundled_path()
    if bundled_path is None:
        logger.debug("No bundled agents/skills found in package")
        return

    local_agent_names = {a.name for a in directory.agents}
    local_skill_names = {s.name for s in directory.skills}

    # Merge bundled agents
    bundled_agents_dir = bundled_path / "agents"
    for agent_path in _iter_agent_files(bundled_agents_dir):
        try:
            agent = parse_agent_file(agent_path)
            if agent.name in local_agent_names:
                logger.debug(f"Bundled agent '{agent.name}' overridden by local")
                continue
            agent.source = "bundled"
            directory.agents.append(agent)
            logger.debug(f"Merged bundled agent '{agent.name}'")
        except ParseError as e:
            logger.debug(f"Skipped invalid bundled agent: {e}")

    # Merge bundled skills
    bundled_skills_dir = bundled_path / "skills"
    for skill_path in _iter_skill_dirs(bundled_skills_dir):
        try:
            skill = parse_skill_file(skill_path)
            if skill.name in local_skill_names:
                logger.debug(f"Bundled skill '{skill.name}' overridden by local")
                continue
            skill.source = "bundled"
            directory.skills.append(skill)
            logger.debug(f"Merged bundled skill '{skill.name}'")
        except ParseError as e:
            logger.debug(f"Skipped invalid bundled skill: {e}")
