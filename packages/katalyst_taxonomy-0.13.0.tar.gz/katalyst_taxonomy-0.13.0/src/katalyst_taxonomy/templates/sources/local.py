"""Local filesystem template source adapter."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from katalyst_taxonomy.templates.sources.protocol import (
    FetchResult,
    PackageInfo,
    PackageManifest,
    SourceManifest,
)

# Default version for bundled templates
BUNDLED_VERSION = "0.1.0"

# Package names
CORE_PACKAGE = "core"
KNOWN_PLUGINS = (
    "layer_types",
    "cicd",
    "capabilities",
    "layer_actions",
    "tools",
    "just",
    "archetypes",
)


def _get_bundled_templates_path() -> Path:
    """Get the path to bundled templates within the package."""
    # Templates are in the same package, under templates/
    import katalyst_taxonomy

    package_dir = Path(katalyst_taxonomy.__file__).parent
    return package_dir / "templates" / "bundled"


def _load_manifest_file(path: Path) -> dict[str, Any]:
    """Load a manifest file (JSON or YAML)."""
    if not path.exists():
        return {}

    content = path.read_text(encoding="utf-8")

    if path.suffix == ".json":
        return json.loads(content)  # type: ignore[no-any-return]
    result = yaml.safe_load(content)
    if isinstance(result, dict):
        return result  # type: ignore[return-value]
    return {}


@dataclass
class LocalFilesystemSource:
    """Template source adapter for local filesystem.

    This handles both bundled templates (shipped with the package)
    and custom local templates from a specified path.

    URI patterns:
    - "bundled": Use templates bundled with the package
    - "file:///path/to/templates": Use templates from a local path
    - "/path/to/templates": Also treated as a local path
    """

    path: Path
    _manifest: SourceManifest | None = field(init=False, repr=False, default=None)

    @classmethod
    def bundled(cls) -> LocalFilesystemSource:
        """Create a source for bundled templates."""
        return cls(path=_get_bundled_templates_path())

    @classmethod
    def from_path(cls, path: Path | str) -> LocalFilesystemSource:
        """Create a source from a local path."""
        return cls(path=Path(path))

    @property
    def source_uri(self) -> str:
        """Get the URI identifying this source."""
        bundled_path = _get_bundled_templates_path()
        if self.path == bundled_path:
            return "bundled"
        return f"file://{self.path}"

    def _discover_packages(self) -> list[PackageInfo]:
        """Discover available packages in the templates directory."""
        packages: list[PackageInfo] = []

        if not self.path.exists():
            return packages

        # Check for core templates
        core_path = self.path / "core"
        if core_path.exists() and core_path.is_dir():
            packages.append(
                PackageInfo(
                    name=CORE_PACKAGE,
                    version=BUNDLED_VERSION,
                    description="Core taxonomy templates (system, subsystem, stack, layer)",
                    source=self.source_uri,
                ),
            )

        # Check for top-level packages (non-plugin packages like just)
        for name in KNOWN_PLUGINS:
            top_path = self.path / name
            if top_path.exists() and top_path.is_dir():
                packages.append(
                    PackageInfo(
                        name=name,
                        version=BUNDLED_VERSION,
                        description=f"{name} templates",
                        source=self.source_uri,
                    ),
                )

        # Check for plugin templates
        plugins_path = self.path / "plugins"
        if plugins_path.exists() and plugins_path.is_dir():
            for plugin_dir in plugins_path.iterdir():
                if (
                    plugin_dir.is_dir()
                    and plugin_dir.name in KNOWN_PLUGINS
                    and not any(p.name == plugin_dir.name for p in packages)
                ):
                    packages.append(
                        PackageInfo(
                            name=plugin_dir.name,
                            version=BUNDLED_VERSION,
                            description=f"{plugin_dir.name} plugin templates",
                            source=self.source_uri,
                        ),
                    )

        # Try to load manifest for additional metadata
        manifest_path = self.path / "manifest.json"
        if manifest_path.exists():
            manifest_data = _load_manifest_file(manifest_path)
            version = manifest_data.get("version", BUNDLED_VERSION)
            # Update package versions from manifest
            packages = [
                PackageInfo(
                    name=p.name,
                    version=version,
                    description=p.description,
                    source=p.source,
                )
                for p in packages
            ]

        return packages

    def get_manifest(self) -> SourceManifest:
        """Get the manifest describing available packages."""
        if self._manifest is not None:
            return self._manifest

        packages = self._discover_packages()

        # Try to load source manifest
        manifest_path = self.path / "manifest.json"
        manifest_data = _load_manifest_file(manifest_path)

        self._manifest = SourceManifest(
            name=manifest_data.get("name", "local-templates"),
            version=manifest_data.get("version", BUNDLED_VERSION),
            description=manifest_data.get("description", "Local filesystem templates"),
            packages=tuple(packages),
        )

        return self._manifest

    def list_packages(self) -> tuple[PackageInfo, ...]:
        """List all available packages from this source."""
        return self.get_manifest().packages

    def fetch_package(self, name: str, version: str | None = None) -> FetchResult:
        """Fetch a package from this source.

        For local filesystem, this just returns the path to the package directory.
        No actual fetching/copying is needed.
        """
        manifest = self.get_manifest()
        package_info = manifest.get_package(name)

        if package_info is None:
            raise KeyError(f"Package not found: {name}")

        if version is not None and version != package_info.version:
            raise ValueError(
                f"Version mismatch: requested {version}, available {package_info.version}",
            )

        # Determine package path
        if name == CORE_PACKAGE:
            package_path = self.path / "core"
        elif (self.path / name).exists() and (self.path / name).is_dir():
            # Top-level packages (e.g., just)
            package_path = self.path / name
        else:
            package_path = self.path / "plugins" / name

        if not package_path.exists():
            raise KeyError(f"Package directory not found: {package_path}")

        # Try to load package manifest
        package_manifest = self._load_package_manifest(name, package_path)

        return FetchResult(
            package=package_info,
            path=package_path,
            manifest=package_manifest,
            cached=True,  # Local files are always "cached"
        )

    def _load_package_manifest(self, name: str, package_path: Path) -> PackageManifest | None:
        """Load the manifest for a specific package."""
        manifest_path = package_path / "manifest.json"
        if not manifest_path.exists():
            manifest_path = package_path / "manifest.yaml"

        if not manifest_path.exists():
            # Generate a basic manifest from directory contents
            return self._generate_package_manifest(name, package_path)

        manifest_data = _load_manifest_file(manifest_path)

        templates = manifest_data.get("templates", [])
        canonical_items = manifest_data.get("canonical", [])

        return PackageManifest(
            name=name,
            version=manifest_data.get("version", BUNDLED_VERSION),
            description=manifest_data.get("description", ""),
            templates=tuple(templates),
            canonical_items=tuple(canonical_items),
        )

    def _generate_package_manifest(self, name: str, package_path: Path) -> PackageManifest:
        """Generate a manifest by scanning directory contents."""
        templates: list[str] = []
        canonical_items: list[str] = []

        # Scan for template files
        for item in package_path.iterdir():
            if item.is_dir():
                # For layer_types, subdirectories are canonical types
                if name == "layer_types":
                    canonical_items.append(item.name)
                templates.append(item.name)
            elif item.suffix in (".yaml", ".yml", ".json", ".j2"):
                templates.append(item.name)

        return PackageManifest(
            name=name,
            version=BUNDLED_VERSION,
            description=f"Auto-discovered manifest for {name}",
            templates=tuple(templates),
            canonical_items=tuple(canonical_items),
        )

    def get_latest_version(self, name: str) -> str:
        """Get the latest version of a package."""
        manifest = self.get_manifest()
        package_info = manifest.get_package(name)

        if package_info is None:
            raise KeyError(f"Package not found: {name}")

        return package_info.version
