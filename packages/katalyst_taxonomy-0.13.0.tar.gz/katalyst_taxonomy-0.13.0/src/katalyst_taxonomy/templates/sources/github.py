"""GitHub template source adapter for fetching from releases or GitHub Pages."""

from __future__ import annotations

import json
import os
import shutil
import tarfile
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from katalyst_taxonomy.templates.sources.protocol import (
    FetchResult,
    PackageInfo,
    PackageManifest,
    SourceManifest,
)

# Cache directory for downloaded templates
CACHE_DIR = Path.home() / ".cache" / "katalyst" / "templates"

# GitHub API base URL
GITHUB_API = "https://api.github.com"


def _empty_releases_cache() -> dict[str, Any]:
    """Create empty releases cache."""
    return {}


def _get_github_token() -> str | None:
    """Get GitHub token from environment."""
    return os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")


def _make_request(url: str, token: str | None = None) -> bytes:
    """Make an HTTP request with optional auth."""
    headers = {
        "Accept": "application/vnd.github+json",
        "User-Agent": "katalyst-taxonomy",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"

    request = Request(url, headers=headers)

    try:
        with urlopen(request, timeout=30) as response:
            return response.read()  # type: ignore[no-any-return]
    except HTTPError as e:
        if e.code == 404:
            raise KeyError(f"Resource not found: {url}") from e
        if e.code == 401 or e.code == 403:
            raise PermissionError(f"Authentication required or forbidden: {url}") from e
        raise ConnectionError(f"HTTP error {e.code}: {url}") from e
    except URLError as e:
        raise ConnectionError(f"Failed to connect: {url} - {e}") from e


def _download_file(url: str, dest: Path, token: str | None = None) -> None:
    """Download a file to a local path."""
    headers = {"User-Agent": "katalyst-taxonomy"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    request = Request(url, headers=headers)

    with urlopen(request, timeout=60) as response:
        dest.parent.mkdir(parents=True, exist_ok=True)
        with dest.open("wb") as f:
            shutil.copyfileobj(response, f)


def _extract_archive(archive_path: Path, dest_dir: Path) -> Path:
    """Extract an archive and return the path to extracted content."""
    dest_dir.mkdir(parents=True, exist_ok=True)

    if archive_path.suffix == ".zip" or archive_path.name.endswith(".zip"):
        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(dest_dir)
    elif archive_path.suffix in (".gz", ".tgz") or ".tar" in archive_path.name:
        with tarfile.open(archive_path, "r:*") as tf:
            tf.extractall(dest_dir)
    else:
        raise ValueError(f"Unknown archive format: {archive_path}")

    # Remove macOS resource fork files (._*) that pollute archives
    _remove_macos_resource_forks(dest_dir)

    # If there's a single top-level directory, return that
    contents = list(dest_dir.iterdir())
    if len(contents) == 1 and contents[0].is_dir():
        return contents[0]
    return dest_dir


def _remove_macos_resource_forks(directory: Path) -> None:
    """Remove macOS ``._*`` resource fork files from *directory* recursively.

    These files are created by macOS when archives are built and
    confuse downstream tools (e.g. ``biome`` tries to read them as
    source code and fails on invalid UTF-8).
    """
    for path in list(directory.rglob("._*")):
        if path.is_file():
            path.unlink()


@dataclass
class GitHubSource:
    """Template source adapter for GitHub.

    Supports fetching templates from:
    - GitHub release assets
    - GitHub Pages static files

    URI patterns:
    - github:org/repo@version: Fetch from release with tag 'version'
    - github:org/repo: Fetch latest release
    - https://org.github.io/repo/: Fetch from GitHub Pages
    """

    owner: str
    repo: str
    version: str | None = None
    token: str | None = field(default_factory=_get_github_token)
    _manifest: SourceManifest | None = field(init=False, repr=False, default=None)
    _releases_cache: dict[str, Any] = field(
        init=False,
        repr=False,
        default_factory=_empty_releases_cache,
    )

    @classmethod
    def from_uri(cls, uri: str) -> GitHubSource:
        """Create a source from a GitHub URI.

        Args:
            uri: URI in format "github:owner/repo[@version]"
        """
        if not uri.startswith("github:"):
            raise ValueError(f"Invalid GitHub URI: {uri}")

        rest = uri[7:]  # Remove "github:" prefix

        if "@" in rest:
            repo_part, version = rest.rsplit("@", 1)
        else:
            repo_part, version = rest, None

        if "/" not in repo_part:
            raise ValueError(f"Invalid GitHub repo format: {repo_part}")

        owner, repo = repo_part.split("/", 1)

        return cls(owner=owner, repo=repo, version=version)

    @property
    def source_uri(self) -> str:
        """Get the URI identifying this source."""
        uri = f"github:{self.owner}/{self.repo}"
        if self.version:
            uri += f"@{self.version}"
        return uri

    def _get_release(self, tag: str | None = None) -> dict[str, Any]:
        """Get release info from GitHub API."""
        cache_key = tag or "latest"
        if cache_key in self._releases_cache:
            return self._releases_cache[cache_key]  # type: ignore[no-any-return]

        if tag:
            url = f"{GITHUB_API}/repos/{self.owner}/{self.repo}/releases/tags/{tag}"
        else:
            url = f"{GITHUB_API}/repos/{self.owner}/{self.repo}/releases/latest"

        try:
            data = _make_request(url, self.token)
            release = json.loads(data)
            self._releases_cache[cache_key] = release
            return release  # type: ignore[no-any-return]
        except KeyError as e:
            raise KeyError(f"Release not found: {tag or 'latest'}") from e

    def _get_latest_release_tag(self) -> str:
        """Get the tag name of the latest release."""
        release = self._get_release()
        return str(release.get("tag_name", ""))

    def _find_asset(self, release: dict[str, Any], name_pattern: str) -> dict[str, Any]:
        """Find an asset in a release by name pattern."""
        assets = release.get("assets", [])
        for asset in assets:
            asset_name = asset.get("name", "")
            if name_pattern in asset_name:
                return asset  # type: ignore[no-any-return]

        raise KeyError(f"Asset not found matching: {name_pattern}")

    def _get_cache_path(self, version: str) -> Path:
        """Get the cache path for a specific version."""
        return CACHE_DIR / self.owner / self.repo / version

    def get_manifest(self) -> SourceManifest:
        """Get the manifest describing available packages."""
        if self._manifest is not None:
            return self._manifest

        # Determine version
        version = self.version or self._get_latest_release_tag()

        # Try to fetch manifest from release
        try:
            result = self.fetch_package("manifest", version)
            manifest_path = result.path / "manifest.json"
            if manifest_path.exists():
                with manifest_path.open() as f:
                    data = json.load(f)
                    packages = [
                        PackageInfo(
                            name=p.get("name", ""),
                            version=version.lstrip("v"),
                            description=p.get("description", ""),
                            source=self.source_uri,
                        )
                        for p in data.get("packages", [])
                    ]
                    self._manifest = SourceManifest(
                        name=data.get("name", f"{self.owner}/{self.repo}"),
                        version=version.lstrip("v"),
                        description=data.get("description", ""),
                        packages=tuple(packages),
                    )
                    return self._manifest
        except (KeyError, FileNotFoundError):
            pass

        # Fall back to default packages
        self._manifest = SourceManifest(
            name=f"{self.owner}/{self.repo}",
            version=version.lstrip("v"),
            description=f"Templates from {self.owner}/{self.repo}",
            packages=(
                PackageInfo(
                    name="templates",
                    version=version.lstrip("v"),
                    description="Templates bundle",
                    source=self.source_uri,
                ),
            ),
        )
        return self._manifest

    def list_packages(self) -> tuple[PackageInfo, ...]:
        """List all available packages from this source."""
        return self.get_manifest().packages

    def fetch_package(self, name: str, version: str | None = None) -> FetchResult:
        """Fetch a package from GitHub release assets."""
        # Determine version
        fetch_version = version or self.version or self._get_latest_release_tag()

        # Check cache first
        cache_path = self._get_cache_path(fetch_version) / name
        if cache_path.exists():
            return FetchResult(
                package=PackageInfo(
                    name=name,
                    version=fetch_version.lstrip("v"),
                    source=self.source_uri,
                ),
                path=cache_path,
                manifest=self._load_package_manifest(name, cache_path),
                cached=True,
            )

        # Get release
        release = self._get_release(fetch_version)

        # Look for asset with package name
        asset_patterns = [
            f"{name}.tar.gz",
            f"{name}.zip",
            f"templates-{name}.tar.gz",
            f"templates-{name}.zip",
            "templates.tar.gz",
            "templates.zip",
        ]

        asset = None
        for pattern in asset_patterns:
            try:
                asset = self._find_asset(release, pattern)
                break
            except KeyError:
                continue

        if asset is None:
            raise KeyError(f"No asset found for package: {name}")

        # Download and extract
        download_url = asset.get("browser_download_url", "")
        if not download_url:
            raise ValueError(f"No download URL for asset: {asset.get('name')}")

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            archive_name = asset.get("name", "download.tar.gz")
            archive_path = tmp_path / archive_name

            _download_file(download_url, archive_path, self.token)

            # Extract to cache
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            extracted = _extract_archive(archive_path, cache_path)

            # If extracted to a subdirectory, move contents up
            if extracted != cache_path:
                for item in extracted.iterdir():
                    shutil.move(str(item), str(cache_path / item.name))
                extracted.rmdir()

        return FetchResult(
            package=PackageInfo(
                name=name,
                version=fetch_version.lstrip("v"),
                source=self.source_uri,
            ),
            path=cache_path,
            manifest=self._load_package_manifest(name, cache_path),
            cached=False,
        )

    @staticmethod
    def _load_package_manifest(name: str, package_path: Path) -> PackageManifest | None:
        """Load a ``PackageManifest`` from an extracted package directory."""
        for manifest_name in ("manifest.json", "manifest.yaml"):
            manifest_path = package_path / manifest_name
            if not manifest_path.exists():
                continue
            try:
                with manifest_path.open() as fh:
                    data: dict[str, Any] = json.load(fh) if manifest_name.endswith(".json") else {}
                return PackageManifest(
                    name=str(data.get("name", name)),
                    version=str(data.get("version", "0.0.0")),
                    description=str(data.get("description", "")),
                    templates=tuple(data.get("templates", [])),
                    canonical_items=tuple(data.get("canonical", [])),
                )
            except (json.JSONDecodeError, OSError):
                return None

        # Fallback: auto-discover canonical items from subdirectories
        if package_path.is_dir():
            subdirs = sorted(
                item.name
                for item in package_path.iterdir()
                if item.is_dir() and not item.name.startswith(".")
            )
            if subdirs:
                return PackageManifest(
                    name=name,
                    version="0.0.0",
                    description=f"Auto-discovered manifest for {name}",
                    templates=tuple(subdirs),
                    canonical_items=tuple(subdirs) if name == "layer_types" else (),
                )

        return None

    def get_latest_version(self, name: str) -> str:
        """Get the latest version of a package."""
        tag = self._get_latest_release_tag()
        return tag.lstrip("v")


@dataclass
class GitHubPagesSource:
    """Template source adapter for GitHub Pages static files.

    Fetches templates from a GitHub Pages URL.

    URI pattern:
    - https://org.github.io/repo/[path/]
    """

    base_url: str
    _manifest: SourceManifest | None = field(init=False, repr=False, default=None)

    @classmethod
    def from_url(cls, url: str) -> GitHubPagesSource:
        """Create a source from a GitHub Pages URL."""
        # Ensure trailing slash
        if not url.endswith("/"):
            url += "/"
        return cls(base_url=url)

    @property
    def source_uri(self) -> str:
        """Get the URI identifying this source."""
        return self.base_url

    def _fetch_json(self, path: str) -> dict[str, Any]:
        """Fetch a JSON file from the source."""
        url = self.base_url + path.lstrip("/")
        data = _make_request(url)
        return json.loads(data)  # type: ignore[no-any-return]

    def get_manifest(self) -> SourceManifest:
        """Get the manifest describing available packages."""
        if self._manifest is not None:
            return self._manifest

        try:
            data = self._fetch_json("manifest.json")
            packages = [
                PackageInfo(
                    name=p.get("name", ""),
                    version=data.get("version", "0.0.0"),
                    description=p.get("description", ""),
                    source=self.source_uri,
                )
                for p in data.get("packages", [])
            ]

            self._manifest = SourceManifest(
                name=data.get("name", "github-pages-templates"),
                version=data.get("version", "0.0.0"),
                description=data.get("description", ""),
                packages=tuple(packages),
            )
        except (KeyError, json.JSONDecodeError) as e:
            raise ValueError(f"Failed to load manifest from {self.base_url}: {e}") from e

        return self._manifest

    def list_packages(self) -> tuple[PackageInfo, ...]:
        """List all available packages from this source."""
        return self.get_manifest().packages

    def fetch_package(self, name: str, version: str | None = None) -> FetchResult:
        """Fetch a package from GitHub Pages.

        For GitHub Pages, we download the entire templates directory
        as it's served as static files.
        """
        manifest = self.get_manifest()
        package_info = manifest.get_package(name)

        if package_info is None:
            raise KeyError(f"Package not found: {name}")

        # Download to cache
        cache_path = CACHE_DIR / "pages" / name / manifest.version
        if cache_path.exists():
            return FetchResult(
                package=package_info,
                path=cache_path,
                cached=True,
            )

        # For GitHub Pages, we need to know the file structure
        # Try to fetch an index file that lists contents
        try:
            index_data = self._fetch_json(f"{name}/index.json")
            files = index_data.get("files", [])

            cache_path.mkdir(parents=True, exist_ok=True)

            for file_path in files:
                url = f"{self.base_url}{name}/{file_path}"
                dest = cache_path / file_path
                dest.parent.mkdir(parents=True, exist_ok=True)

                data = _make_request(url)
                dest.write_bytes(data)

        except (KeyError, json.JSONDecodeError) as e:
            # Fall back to downloading known files
            raise NotImplementedError(f"Package {name} requires an index.json listing files") from e

        return FetchResult(
            package=package_info,
            path=cache_path,
            cached=False,
        )

    def get_latest_version(self, name: str) -> str:
        """Get the latest version of a package."""
        return self.get_manifest().version
