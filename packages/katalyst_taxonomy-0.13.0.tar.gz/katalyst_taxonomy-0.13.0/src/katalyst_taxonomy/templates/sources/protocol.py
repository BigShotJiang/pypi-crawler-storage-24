"""Protocol (port) for template sources."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class PackageInfo:
    """Information about an available package.

    A package can be:
    - core: The base taxonomy templates (system, subsystem, stack, layer)
    - A plugin: layer_types, cicd, capabilities, etc.
    """

    name: str
    version: str
    description: str = ""
    source: str = "bundled"

    def __post_init__(self) -> None:
        if not self.name or not self.name.strip():
            raise ValueError("Package name cannot be blank")
        if not self.version or not self.version.strip():
            raise ValueError("Package version cannot be blank")


@dataclass(frozen=True, slots=True)
class PackageManifest:
    """Manifest for a single package with its contents.

    This describes what files/templates are included in a package.
    """

    name: str
    version: str
    description: str = ""
    templates: tuple[str, ...] = ()  # Relative paths to template files/dirs
    canonical_items: tuple[str, ...] = ()  # For layer_types: canonical type names

    def __post_init__(self) -> None:
        if not self.name or not self.name.strip():
            raise ValueError("Package name cannot be blank")
        if not self.version or not self.version.strip():
            raise ValueError("Package version cannot be blank")
        # Ensure tuples (for when lists are passed at runtime)
        object.__setattr__(self, "templates", tuple(self.templates))
        object.__setattr__(self, "canonical_items", tuple(self.canonical_items))


@dataclass(frozen=True, slots=True)
class SourceManifest:
    """Manifest describing all packages available from a source.

    This is loaded from a source to discover what packages are available.
    """

    name: str
    version: str
    description: str = ""
    packages: tuple[PackageInfo, ...] = ()

    def __post_init__(self) -> None:
        if not self.name or not self.name.strip():
            raise ValueError("Source name cannot be blank")
        if not self.version or not self.version.strip():
            raise ValueError("Source version cannot be blank")
        # Ensure tuple (for when list is passed at runtime)
        object.__setattr__(self, "packages", tuple(self.packages))

    def get_package(self, name: str) -> PackageInfo | None:
        """Get a package by name."""
        return next((p for p in self.packages if p.name == name), None)

    def package_names(self) -> frozenset[str]:
        """Get all package names."""
        return frozenset(p.name for p in self.packages)


@dataclass
class FetchResult:
    """Result of fetching a package.

    Contains the path to the fetched content and metadata.
    """

    package: PackageInfo
    path: Path  # Path to the fetched templates (local directory)
    manifest: PackageManifest | None = None  # Detailed manifest if available
    cached: bool = False  # Whether this was served from cache


@runtime_checkable
class TemplateSource(Protocol):
    """Protocol (port) for fetching templates from various sources.

    Implementations:
    - LocalFilesystemSource: Bundled templates or local directories
    - GitHubSource: GitHub releases or GitHub Pages
    - GitRepoSource: Clone from git repository

    Source URI patterns:
    - bundled: Built-in templates from the package
    - file:///path/to/templates: Local filesystem
    - github:org/repo@version: GitHub release assets
    - https://org.github.io/repo/: GitHub Pages static files
    - git:https://github.com/org/repo.git@ref: Clone git repo
    """

    @property
    def source_uri(self) -> str:
        """Get the URI identifying this source."""
        ...

    def get_manifest(self) -> SourceManifest:
        """Get the manifest describing available packages.

        Returns:
            SourceManifest with available packages.

        Raises:
            ConnectionError: If the source cannot be reached.
            ValueError: If the manifest is invalid.
        """
        ...

    def list_packages(self) -> tuple[PackageInfo, ...]:
        """List all available packages from this source.

        Returns:
            Tuple of PackageInfo objects.
        """
        ...

    def fetch_package(self, name: str, version: str | None = None) -> FetchResult:
        """Fetch a package from this source.

        Args:
            name: Package name (e.g., "core", "layer_types", "cicd").
            version: Specific version to fetch, or None for latest.

        Returns:
            FetchResult with path to fetched templates.

        Raises:
            KeyError: If the package doesn't exist.
            ValueError: If the version doesn't exist.
        """
        ...

    def get_latest_version(self, name: str) -> str:
        """Get the latest version of a package.

        Args:
            name: Package name.

        Returns:
            Version string (e.g., "0.1.0").

        Raises:
            KeyError: If the package doesn't exist.
        """
        ...


def parse_source_uri(uri: str) -> tuple[str, str, str | None]:
    """Parse a source URI into (scheme, location, version).

    Args:
        uri: Source URI string.

    Returns:
        Tuple of (scheme, location, version).

    Examples:
        >>> parse_source_uri("bundled")
        ("bundled", "", None)
        >>> parse_source_uri("github:org/repo@v1.0.0")
        ("github", "org/repo", "v1.0.0")
        >>> parse_source_uri("git:https://github.com/org/repo.git@main")
        ("git", "https://github.com/org/repo.git", "main")
        >>> parse_source_uri("file:///path/to/templates")
        ("file", "/path/to/templates", None)
    """
    if uri == "bundled":
        return ("bundled", "", None)

    if uri.startswith("file://"):
        return ("file", uri[7:], None)

    if uri.startswith("github:"):
        rest = uri[7:]
        if "@" in rest:
            location, version = rest.rsplit("@", 1)
            return ("github", location, version)
        return ("github", rest, None)

    if uri.startswith("git:"):
        rest = uri[4:]
        if "@" in rest:
            # Handle git URLs which may contain @ in the URL itself
            # Split from the right to get the ref
            location, ref = rest.rsplit("@", 1)
            return ("git", location, ref)
        return ("git", rest, None)

    if uri.startswith("https://") or uri.startswith("http://"):
        return ("https", uri, None)

    # Default: treat as local path
    return ("file", uri, None)


def create_source(uri: str) -> TemplateSource:
    """Create a template source from a URI.

    This is the main factory function for creating template sources.
    It parses the URI and returns the appropriate source adapter.

    Args:
        uri: Source URI string.

    Returns:
        TemplateSource adapter instance.

    Raises:
        ValueError: If the URI scheme is not supported.

    Examples:
        >>> source = create_source("bundled")
        >>> source = create_source("github:katalyst/templates@v1.0.0")
        >>> source = create_source("git:https://github.com/org/repo.git@main")
        >>> source = create_source("file:///path/to/templates")
    """
    # Import here to avoid circular imports
    from katalyst_taxonomy.templates.sources.git import GitRepoSource
    from katalyst_taxonomy.templates.sources.github import GitHubPagesSource, GitHubSource
    from katalyst_taxonomy.templates.sources.local import LocalFilesystemSource

    scheme, location, _version = parse_source_uri(uri)

    if scheme == "bundled":
        return LocalFilesystemSource.bundled()

    if scheme == "file":
        return LocalFilesystemSource.from_path(location)

    if scheme == "github":
        return GitHubSource.from_uri(uri)

    if scheme == "git":
        return GitRepoSource.from_uri(uri)

    if scheme == "https":
        # Assume GitHub Pages for HTTPS URLs with github.io
        if "github.io" in location:
            return GitHubPagesSource.from_url(location)
        raise ValueError(f"Unsupported HTTPS source: {uri}")

    raise ValueError(f"Unsupported source URI scheme: {scheme}")
