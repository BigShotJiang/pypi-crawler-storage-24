"""Git repository template source adapter."""

from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from katalyst_taxonomy.templates.sources.protocol import (
    FetchResult,
    PackageInfo,
    PackageManifest,
    SourceManifest,
)

# Cache directory for cloned repos
CACHE_DIR = Path.home() / ".cache" / "katalyst" / "git-templates"


def _run_git(args: list[str], cwd: Path | None = None) -> str:
    """Run a git command and return output."""
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=cwd,
            capture_output=True,
            text=True,
            check=True,
            timeout=120,
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Git command failed: git {' '.join(args)}\n{e.stderr}") from e
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(f"Git command timed out: git {' '.join(args)}") from e
    except FileNotFoundError as e:
        raise RuntimeError("Git is not installed or not in PATH") from e


def _get_repo_name(url: str) -> str:
    """Extract repo name from URL."""
    # Handle various URL formats
    # https://github.com/owner/repo.git -> repo
    # git@github.com:owner/repo.git -> repo
    name = url.rstrip("/")
    if name.endswith(".git"):
        name = name[:-4]
    name = name.split("/")[-1]
    name = name.split(":")[-1]
    return name


def _get_cache_key(url: str, ref: str | None) -> str:
    """Generate a cache key for a repo+ref combination."""
    import hashlib

    key = url + (ref or "HEAD")
    return hashlib.sha256(key.encode()).hexdigest()[:16]


@dataclass
class GitRepoSource:
    """Template source adapter for git repositories.

    Clones a git repository and uses it as a template source.
    Supports any git URL (https, ssh, file).

    URI patterns:
    - git:https://github.com/org/repo.git@ref
    - git:git@github.com:org/repo.git@ref
    - git:file:///path/to/repo@ref
    """

    url: str
    ref: str | None = None  # branch, tag, or commit
    templates_path: str = "templates"  # Path within repo to templates
    _clone_path: Path | None = field(init=False, repr=False, default=None)
    _manifest: SourceManifest | None = field(init=False, repr=False, default=None)

    @classmethod
    def from_uri(cls, uri: str) -> GitRepoSource:
        """Create a source from a git URI.

        Args:
            uri: URI in format "git:url[@ref]"
        """
        if not uri.startswith("git:"):
            raise ValueError(f"Invalid git URI: {uri}")

        rest = uri[4:]  # Remove "git:" prefix

        # Split ref from URL
        # Be careful with @ in URLs (e.g., git@github.com)
        if rest.startswith("git@") or rest.startswith("ssh://"):
            # SSH URL - @ is part of the URL format
            # Look for @ after the hostname
            if "@" in rest and rest.count("@") > 1:
                url, ref = rest.rsplit("@", 1)
            else:
                url, ref = rest, None
        else:
            # HTTPS or file URL
            if "@" in rest:
                url, ref = rest.rsplit("@", 1)
            else:
                url, ref = rest, None

        return cls(url=url, ref=ref)

    @property
    def source_uri(self) -> str:
        """Get the URI identifying this source."""
        uri = f"git:{self.url}"
        if self.ref:
            uri += f"@{self.ref}"
        return uri

    def _ensure_cloned(self) -> Path:
        """Ensure the repo is cloned and return the path."""
        if self._clone_path and self._clone_path.exists():
            return self._clone_path

        # Check cache
        cache_key = _get_cache_key(self.url, self.ref)
        cache_path = CACHE_DIR / cache_key

        if cache_path.exists():
            # Update existing clone
            try:
                _run_git(["fetch", "--all"], cwd=cache_path)
                if self.ref:
                    _run_git(["checkout", self.ref], cwd=cache_path)
                    # If it's a branch, pull latest
                    try:
                        _run_git(["pull", "--ff-only"], cwd=cache_path)
                    except RuntimeError:
                        pass  # Not a tracking branch, that's fine
                self._clone_path = cache_path
                return cache_path
            except RuntimeError:
                # Cache corrupted, remove and re-clone
                shutil.rmtree(cache_path)

        # Clone fresh
        cache_path.parent.mkdir(parents=True, exist_ok=True)

        clone_args = ["clone", "--depth", "1"]
        if self.ref:
            clone_args.extend(["--branch", self.ref])
        clone_args.extend([self.url, str(cache_path)])

        try:
            _run_git(clone_args)
        except RuntimeError:
            # --branch might not work for commits, try full clone
            if cache_path.exists():
                shutil.rmtree(cache_path)
            _run_git(["clone", self.url, str(cache_path)])
            if self.ref:
                _run_git(["checkout", self.ref], cwd=cache_path)

        self._clone_path = cache_path
        return cache_path

    def _get_templates_root(self) -> Path:
        """Get the path to the templates directory in the repo."""
        clone_path = self._ensure_cloned()
        templates_root = clone_path / self.templates_path
        if not templates_root.exists():
            # Fall back to repo root
            return clone_path
        return templates_root

    def _load_manifest_file(self, path: Path) -> dict[str, Any]:
        """Load a manifest file."""
        if not path.exists():
            return {}

        content = path.read_text(encoding="utf-8")
        if path.suffix == ".json":
            return json.loads(content)  # type: ignore[no-any-return]
        result = yaml.safe_load(content)
        if isinstance(result, dict):
            return result  # type: ignore[return-value]
        return {}

    def _discover_packages(self) -> list[PackageInfo]:
        """Discover available packages in the repo."""
        templates_root = self._get_templates_root()
        packages: list[PackageInfo] = []

        # Try to load version from manifest
        manifest_data = self._load_manifest_file(templates_root / "manifest.json")
        if not manifest_data:
            manifest_data = self._load_manifest_file(templates_root / "manifest.yaml")

        version = manifest_data.get("version", self.ref or "0.0.0")
        if version.startswith("v"):
            version = version[1:]

        # Check for core templates
        core_path = templates_root / "core"
        if core_path.exists() and core_path.is_dir():
            packages.append(
                PackageInfo(
                    name="core",
                    version=version,
                    description="Core taxonomy templates",
                    source=self.source_uri,
                ),
            )

        # Check for plugins
        plugins_path = templates_root / "plugins"
        if plugins_path.exists() and plugins_path.is_dir():
            for plugin_dir in plugins_path.iterdir():
                if plugin_dir.is_dir():
                    packages.append(
                        PackageInfo(
                            name=plugin_dir.name,
                            version=version,
                            description=f"{plugin_dir.name} plugin templates",
                            source=self.source_uri,
                        ),
                    )

        return packages

    def get_manifest(self) -> SourceManifest:
        """Get the manifest describing available packages."""
        if self._manifest is not None:
            return self._manifest

        templates_root = self._get_templates_root()
        packages = self._discover_packages()

        # Try to load source manifest
        manifest_data = self._load_manifest_file(templates_root / "manifest.json")
        if not manifest_data:
            manifest_data = self._load_manifest_file(templates_root / "manifest.yaml")

        version = manifest_data.get("version", self.ref or "0.0.0")
        if version.startswith("v"):
            version = version[1:]

        self._manifest = SourceManifest(
            name=manifest_data.get("name", _get_repo_name(self.url)),
            version=version,
            description=manifest_data.get("description", f"Templates from {self.url}"),
            packages=tuple(packages),
        )

        return self._manifest

    def list_packages(self) -> tuple[PackageInfo, ...]:
        """List all available packages from this source."""
        return self.get_manifest().packages

    def fetch_package(self, name: str, version: str | None = None) -> FetchResult:
        """Fetch a package from the git repository."""
        manifest = self.get_manifest()
        package_info = manifest.get_package(name)

        if package_info is None:
            raise KeyError(f"Package not found: {name}")

        templates_root = self._get_templates_root()

        # Determine package path
        if name == "core":
            package_path = templates_root / "core"
        else:
            package_path = templates_root / "plugins" / name

        if not package_path.exists():
            raise KeyError(f"Package directory not found: {package_path}")

        # Load package manifest if available
        package_manifest = self._load_package_manifest(name, package_path)

        return FetchResult(
            package=package_info,
            path=package_path,
            manifest=package_manifest,
            cached=True,  # From local clone
        )

    def _load_package_manifest(self, name: str, package_path: Path) -> PackageManifest | None:
        """Load the manifest for a specific package."""
        manifest_data = self._load_manifest_file(package_path / "manifest.json")
        if not manifest_data:
            manifest_data = self._load_manifest_file(package_path / "manifest.yaml")

        if manifest_data:
            return PackageManifest(
                name=name,
                version=manifest_data.get("version", "0.0.0"),
                description=manifest_data.get("description", ""),
                templates=tuple(manifest_data.get("templates", [])),
                canonical_items=tuple(manifest_data.get("canonical", [])),
            )

        # Fallback: auto-discover from subdirectories
        if package_path.is_dir():
            subdirs = sorted(
                item.name
                for item in package_path.iterdir()
                if item.is_dir() and not item.name.startswith(".")
            )
            if subdirs:
                return PackageManifest(
                    name=name,
                    version="0.0.0",
                    description=f"Auto-discovered manifest for {name}",
                    templates=tuple(subdirs),
                    canonical_items=tuple(subdirs) if name == "layer_types" else (),
                )

        return None

    def get_latest_version(self, name: str) -> str:
        """Get the latest version of a package.

        For git repos, this returns the version from the manifest
        or the ref if no manifest is available.
        """
        manifest = self.get_manifest()
        package_info = manifest.get_package(name)

        if package_info is None:
            raise KeyError(f"Package not found: {name}")

        return package_info.version

    def clear_cache(self) -> None:
        """Clear the cached clone of this repository."""
        cache_key = _get_cache_key(self.url, self.ref)
        cache_path = CACHE_DIR / cache_key
        if cache_path.exists():
            shutil.rmtree(cache_path)
        self._clone_path = None
        self._manifest = None
