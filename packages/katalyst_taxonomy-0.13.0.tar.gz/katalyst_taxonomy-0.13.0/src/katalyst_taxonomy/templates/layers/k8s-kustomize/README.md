# {{ system_name }}/{{ stack_name }}/{{ layer_name }} layer

Layer type: kustomize

This scaffold creates a plain Kustomize hierarchy:

- `layer.yaml` – taxonomy node descriptor.
- `base/` – shared manifests (namespace, deployment, service, etc.).
- `<environment>/` – overlays that patch the base via Kustomize.

Copy `environment-template/` for each environment and adjust the placeholders in
`patch-deployment.yaml`.

<!-- BEGIN AUTO-LAYER -->
<!-- This section is managed by scripts. Manual edits inside may be overwritten. -->
<!-- END AUTO-LAYER -->
