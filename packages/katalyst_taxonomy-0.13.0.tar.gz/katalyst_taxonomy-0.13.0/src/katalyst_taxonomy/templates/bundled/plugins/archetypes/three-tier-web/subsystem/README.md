# {{ name }}

{{ description }}

## Architecture

This is a standard 3-tier web application with:
- **Frontend** — web application served to users
- **Backend** — API service handling business logic
- **Database** — persistence layer

## Stacks

| Stack | Description |
|-------|-------------|
| frontend | Frontend web application |
| backend | Backend API service |
| database | Database tier |

## Getting Started

```bash
# View the taxonomy structure
kata tax tree --path .

# Run actions on a specific layer
kata tax action run build --layer {{ name }}/frontend/app
```
