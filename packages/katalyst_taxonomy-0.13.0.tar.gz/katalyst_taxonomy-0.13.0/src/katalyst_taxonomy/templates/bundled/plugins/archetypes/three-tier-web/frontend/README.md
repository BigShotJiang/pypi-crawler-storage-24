# {{ name }} — Frontend

Frontend web application stack.
