"""Token rendering for ``{{ key }}`` template substitution.

This module provides the single canonical implementation of the ``{{ key }}``
placeholder rendering used throughout the scaffolding system.
"""

from __future__ import annotations

import re
from typing import Mapping

_TOKEN_RE = re.compile(r"\{\{\s*(\w+)\s*\}\}")


def render_tokens(text: str, context: Mapping[str, str]) -> str:
    """Replace ``{{ key }}`` tokens in *text* using *context*.

    Tokens not found in *context* are left as-is.

    >>> render_tokens("Hello {{ name }}", {"name": "world"})
    'Hello world'
    >>> render_tokens("{{ missing }}", {})
    '{{ missing }}'
    """

    def _replace(match: re.Match[str]) -> str:
        return context.get(match.group(1), match.group(0))

    return _TOKEN_RE.sub(_replace, text)
