"""Template management for Katalyst taxonomy."""

from katalyst_taxonomy.templates.sources import (
    FetchResult,
    GitHubPagesSource,
    GitHubSource,
    GitRepoSource,
    LocalFilesystemSource,
    PackageInfo,
    PackageManifest,
    SourceManifest,
    TemplateSource,
    parse_source_uri,
)

__all__ = [
    # Protocol and data classes
    "TemplateSource",
    "SourceManifest",
    "PackageInfo",
    "PackageManifest",
    "FetchResult",
    "parse_source_uri",
    # Adapters
    "LocalFilesystemSource",
    "GitHubSource",
    "GitHubPagesSource",
    "GitRepoSource",
]
