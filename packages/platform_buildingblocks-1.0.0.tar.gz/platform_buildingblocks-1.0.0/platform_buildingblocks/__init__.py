"""
TimeChamp Platform Building Blocks for Python.

Provides authentication, multi-tenancy, and shared contracts
for Python-based products on the TimeChamp Platform.

Mirrors the .NET Platform.BuildingBlocks NuGet packages:
- platform_buildingblocks.contracts   → Platform.BuildingBlocks.Contracts
- platform_buildingblocks.authentication → Platform.BuildingBlocks.Authentication
- platform_buildingblocks.multitenancy  → Platform.BuildingBlocks.MultiTenancy
"""

__version__ = "1.0.0"
