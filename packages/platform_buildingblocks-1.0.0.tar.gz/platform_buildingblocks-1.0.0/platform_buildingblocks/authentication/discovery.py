"""
Keycloak OIDC discovery service with caching.

Mirrors: Platform.BuildingBlocks.Authentication.Services.KeycloakDiscoveryService

Fetches and caches JWKS (JSON Web Key Sets) and OIDC configuration
from Keycloak for each realm. Configuration is cached for 24 hours
to avoid hitting Keycloak on every request.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field

import jwt
import requests

logger = logging.getLogger(__name__)

# Cache TTL: 24 hours (matching .NET KeycloakDiscoveryService)
_CACHE_TTL_SECONDS = 24 * 60 * 60


@dataclass
class OIDCConfiguration:
	"""Cached OIDC configuration for a Keycloak realm."""

	issuer: str
	jwks_uri: str
	token_endpoint: str
	authorization_endpoint: str
	signing_keys: dict = field(default_factory=dict)  # kid -> public key
	fetched_at: float = 0.0

	@property
	def is_expired(self) -> bool:
		return (time.time() - self.fetched_at) > _CACHE_TTL_SECONDS


class KeycloakDiscoveryService:
	"""
	Fetches and caches OIDC configuration from Keycloak.

	Thread-safe. Caches per-realm configurations for 24 hours.

	Equivalent to IKeycloakDiscoveryService in .NET.

	Usage:
	    discovery = KeycloakDiscoveryService("http://localhost:8080")
	    config = discovery.get_configuration("tools")
	    signing_key = config.signing_keys["key-id-here"]
	"""

	def __init__(self, keycloak_base_url: str, timeout: int = 30):
		self._base_url = keycloak_base_url.rstrip("/")
		self._timeout = timeout
		self._cache: dict[str, OIDCConfiguration] = {}
		self._lock = threading.Lock()

	def get_configuration(self, realm: str) -> OIDCConfiguration:
		"""
		Get OIDC configuration for a realm, using cache if available.

		Args:
		    realm: Keycloak realm name (e.g., "tools")

		Returns:
		    OIDCConfiguration with signing keys, endpoints, etc.

		Raises:
		    ConnectionError: If Keycloak is unreachable
		    ValueError: If response is invalid
		"""
		cached = self._cache.get(realm)
		if cached and not cached.is_expired:
			return cached

		with self._lock:
			# Double-check after acquiring lock
			cached = self._cache.get(realm)
			if cached and not cached.is_expired:
				return cached

			config = self._fetch_configuration(realm)
			self._cache[realm] = config
			return config

	def refresh_configuration(self, realm: str) -> OIDCConfiguration:
		"""Force refresh the configuration for a realm."""
		with self._lock:
			config = self._fetch_configuration(realm)
			self._cache[realm] = config
			return config

	def get_signing_key(self, realm: str, kid: str):
		"""
		Get the signing key for a specific key ID.

		Args:
		    realm: Keycloak realm name
		    kid: Key ID from the JWT header

		Returns:
		    RSA public key object for signature verification

		Raises:
		    ValueError: If key ID not found in JWKS
		"""
		config = self.get_configuration(realm)

		if kid not in config.signing_keys:
			# Key not found — might have rotated. Refresh once.
			logger.info("Key ID %s not found in cache for realm %s, refreshing JWKS", kid, realm)
			config = self.refresh_configuration(realm)

		if kid not in config.signing_keys:
			raise ValueError(f"Signing key with kid '{kid}' not found in JWKS for realm '{realm}'")

		return config.signing_keys[kid]

	def _fetch_configuration(self, realm: str) -> OIDCConfiguration:
		"""Fetch OIDC configuration and JWKS from Keycloak."""
		well_known_url = f"{self._base_url}/realms/{realm}/.well-known/openid-configuration"

		logger.debug("Fetching OIDC configuration from %s", well_known_url)

		try:
			response = requests.get(well_known_url, timeout=self._timeout)
			response.raise_for_status()
			oidc_data = response.json()
		except requests.RequestException as e:
			raise ConnectionError(f"Cannot fetch OIDC configuration from {well_known_url}: {e}") from e

		jwks_uri = oidc_data.get("jwks_uri", "")
		if not jwks_uri:
			raise ValueError(f"OIDC configuration for realm '{realm}' has no jwks_uri")

		# Fetch JWKS
		try:
			jwks_response = requests.get(jwks_uri, timeout=self._timeout)
			jwks_response.raise_for_status()
			jwks_data = jwks_response.json()
		except requests.RequestException as e:
			raise ConnectionError(f"Cannot fetch JWKS from {jwks_uri}: {e}") from e

		# Parse signing keys
		signing_keys = {}
		for key_data in jwks_data.get("keys", []):
			kid = key_data.get("kid")
			if kid and key_data.get("use", "sig") == "sig":
				try:
					public_key = jwt.algorithms.RSAAlgorithm.from_jwk(key_data)
					signing_keys[kid] = public_key
				except Exception as e:
					logger.warning("Failed to parse JWKS key %s: %s", kid, e)

		config = OIDCConfiguration(
			issuer=oidc_data.get("issuer", ""),
			jwks_uri=jwks_uri,
			token_endpoint=oidc_data.get("token_endpoint", ""),
			authorization_endpoint=oidc_data.get("authorization_endpoint", ""),
			signing_keys=signing_keys,
			fetched_at=time.time(),
		)

		logger.info(
			"Fetched OIDC configuration for realm '%s': %d signing keys",
			realm,
			len(signing_keys),
		)

		return config
