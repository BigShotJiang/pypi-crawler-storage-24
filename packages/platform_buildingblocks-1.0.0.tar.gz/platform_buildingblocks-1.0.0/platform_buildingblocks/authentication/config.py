"""
Keycloak configuration options.

Mirrors:
- Platform.BuildingBlocks.Authentication.Configuration.KeycloakOptions
- Platform.BuildingBlocks.Authentication.Configuration.TokenValidationOptions
- Platform.BuildingBlocks.Authentication.Configuration.ClaimMappingOptions

Configuration can come from:
- Frappe site_config.json
- Django settings
- FastAPI config / .env
- Plain dict
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class TokenValidationOptions:
	"""Controls how strictly JWT tokens are validated."""

	validate_issuer: bool = True
	validate_audience: bool = True
	validate_lifetime: bool = True
	validate_issuer_signing_key: bool = True
	clock_skew_seconds: int = 30


@dataclass
class ClaimMappingOptions:
	"""Maps custom claim names used by the Platform."""

	tenant_id: str = "tenant_id"
	tenant_slug: str = "tenant_slug"
	user_type: str = "user_type"


@dataclass
class KeycloakOptions:
	"""
	Keycloak connection and validation configuration.

	Equivalent to the "Keycloak" section in appsettings.json for .NET.

	For Frappe, these come from site_config.json keys:
		keycloak_base_url, expected_audiences, etc.

	For FastAPI/Django, these come from settings or environment variables.
	"""

	base_url: str = "http://localhost:8080"
	admin_realm: str = "master"
	service_client_id: str | None = None
	service_client_secret: str | None = None
	expected_audience: str | None = None
	expected_audiences: list[str] = field(default_factory=lambda: ["platform", "account"])
	token_validation: TokenValidationOptions = field(default_factory=TokenValidationOptions)
	claim_mappings: ClaimMappingOptions = field(default_factory=ClaimMappingOptions)

	def get_realm_authority(self, realm: str) -> str:
		"""Get the issuer URL for a realm (e.g., http://localhost:8080/realms/tools)."""
		return f"{self.base_url.rstrip('/')}/realms/{realm}"

	def get_well_known_url(self, realm: str) -> str:
		"""Get the OIDC discovery URL for a realm."""
		return f"{self.get_realm_authority(realm)}/.well-known/openid-configuration"

	def get_effective_audiences(self) -> list[str]:
		"""Get the list of audiences to validate against."""
		if self.expected_audiences:
			return self.expected_audiences
		if self.expected_audience:
			return [self.expected_audience]
		return []

	@classmethod
	def from_dict(cls, config: dict) -> KeycloakOptions:
		"""
		Create KeycloakOptions from a flat config dict.

		Supports keys from Frappe site_config.json:
			keycloak_base_url, keycloak_admin_realm, keycloak_service_client_id,
			keycloak_service_client_secret, expected_audience, expected_audiences,
			keycloak_validate_issuer, keycloak_validate_audience, etc.

		Also supports nested "Keycloak" dict (matching .NET appsettings.json):
			{ "Keycloak": { "BaseUrl": "...", "ExpectedAudiences": [...] } }
		"""
		# Support nested "Keycloak" key (like .NET appsettings.json)
		if "Keycloak" in config:
			kc = config["Keycloak"]
			tv = kc.get("TokenValidation", {})
			cm = kc.get("ClaimMappings", {})
			return cls(
				base_url=kc.get("BaseUrl", "http://localhost:8080"),
				admin_realm=kc.get("AdminRealm", "master"),
				service_client_id=kc.get("ServiceClientId"),
				service_client_secret=kc.get("ServiceClientSecret"),
				expected_audience=kc.get("ExpectedAudience"),
				expected_audiences=kc.get("ExpectedAudiences", ["platform", "account"]),
				token_validation=TokenValidationOptions(
					validate_issuer=tv.get("ValidateIssuer", True),
					validate_audience=tv.get("ValidateAudience", True),
					validate_lifetime=tv.get("ValidateLifetime", True),
					validate_issuer_signing_key=tv.get("ValidateIssuerSigningKey", True),
					clock_skew_seconds=tv.get("ClockSkew", 30),
				),
				claim_mappings=ClaimMappingOptions(
					tenant_id=cm.get("TenantId", "tenant_id"),
					tenant_slug=cm.get("TenantSlug", "tenant_slug"),
					user_type=cm.get("UserType", "user_type"),
				),
			)

		# Support flat keys (Frappe site_config.json style)
		tv_config = config.get("keycloak_validation", {})
		return cls(
			base_url=config.get("keycloak_base_url", config.get("keycloak_url", "http://localhost:8080")),
			admin_realm=config.get("keycloak_admin_realm", "master"),
			service_client_id=config.get("keycloak_service_client_id"),
			service_client_secret=config.get("keycloak_service_client_secret"),
			expected_audience=config.get("expected_audience"),
			expected_audiences=config.get("expected_audiences", ["platform", "account"]),
			token_validation=TokenValidationOptions(
				validate_issuer=tv_config.get("validate_issuer", True),
				validate_audience=tv_config.get("validate_audience", True),
				validate_lifetime=tv_config.get("validate_lifetime", True),
				validate_issuer_signing_key=tv_config.get("validate_issuer_signing_key", True),
				clock_skew_seconds=tv_config.get("clock_skew_seconds", 30),
			),
			claim_mappings=ClaimMappingOptions(
				tenant_id=config.get("claim_mapping_tenant_id", "tenant_id"),
				tenant_slug=config.get("claim_mapping_tenant_slug", "tenant_slug"),
				user_type=config.get("claim_mapping_user_type", "user_type"),
			),
		)
