"""
Service account token provider for service-to-service authentication.

Mirrors: Platform.BuildingBlocks.Authentication.Services.ServiceAccountTokenProvider

Provides client_credentials flow tokens for backend-to-backend API calls.
Tokens are cached and automatically refreshed before expiration.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass

import requests

from platform_buildingblocks.authentication.config import KeycloakOptions

logger = logging.getLogger(__name__)


@dataclass
class ServiceAccountToken:
	"""
	A cached service account token.

	Mirrors: Platform.BuildingBlocks.Authentication.Services.ServiceAccountToken
	"""

	access_token: str
	expires_at: float  # Unix timestamp
	token_type: str = "Bearer"

	@property
	def is_expired(self) -> bool:
		"""Check if token is expired (with 30s buffer)."""
		return time.time() >= (self.expires_at - 30)


class ServiceAccountTokenProvider:
	"""
	Provides service-to-service JWT tokens via client_credentials grant.

	Mirrors: IServiceAccountTokenProvider / ServiceAccountTokenProvider in .NET.

	Usage:
	    provider = ServiceAccountTokenProvider(keycloak_options)
	    token = provider.get_token("tools")
	    headers = {"Authorization": f"Bearer {token.access_token}"}
	"""

	def __init__(self, options: KeycloakOptions):
		if not options.service_client_id or not options.service_client_secret:
			raise ValueError(
				"ServiceClientId and ServiceClientSecret must be configured "
				"in KeycloakOptions to use ServiceAccountTokenProvider"
			)
		self._options = options
		self._cache: dict[str, ServiceAccountToken] = {}
		self._lock = threading.Lock()

	def get_token(self, realm: str, scopes: list[str] | None = None) -> ServiceAccountToken:
		"""
		Get a service account token for the given realm.

		Cached tokens are returned if still valid. New tokens are fetched
		via client_credentials grant when cache is empty or expired.

		Args:
		    realm: Keycloak realm (e.g., "tools" or "master")
		    scopes: Optional list of scopes to request

		Returns:
		    ServiceAccountToken with access_token and expiry info

		Raises:
		    ConnectionError: If Keycloak is unreachable
		    ValueError: If token request fails
		"""
		cache_key = f"{realm}:{','.join(scopes or [])}"

		cached = self._cache.get(cache_key)
		if cached and not cached.is_expired:
			return cached

		with self._lock:
			# Double-check after lock
			cached = self._cache.get(cache_key)
			if cached and not cached.is_expired:
				return cached

			token = self._fetch_token(realm, scopes)
			self._cache[cache_key] = token
			return token

	def _fetch_token(self, realm: str, scopes: list[str] | None = None) -> ServiceAccountToken:
		"""Fetch a new token from Keycloak using client_credentials grant."""
		token_url = f"{self._options.base_url.rstrip('/')}/realms/{realm}/protocol/openid-connect/token"

		data = {
			"grant_type": "client_credentials",
			"client_id": self._options.service_client_id,
			"client_secret": self._options.service_client_secret,
		}

		if scopes:
			data["scope"] = " ".join(scopes)

		try:
			response = requests.post(token_url, data=data, timeout=30)
			response.raise_for_status()
			token_data = response.json()
		except requests.RequestException as e:
			raise ConnectionError(f"Failed to get service account token from {token_url}: {e}") from e

		access_token = token_data.get("access_token")
		expires_in = token_data.get("expires_in", 300)

		if not access_token:
			raise ValueError("Token response missing access_token")

		token = ServiceAccountToken(
			access_token=access_token,
			expires_at=time.time() + expires_in,
			token_type=token_data.get("token_type", "Bearer"),
		)

		logger.info("Fetched service account token for realm '%s' (expires in %ds)", realm, expires_in)

		return token
