"""
Multi-tenant JWT validation handler — the main entry point.

Mirrors: Platform.BuildingBlocks.Authentication.Handlers.MultiTenantJwtBearerHandler

This is the primary class product developers interact with.
It validates JWT tokens against tenant-specific Keycloak realms,
discovers signing keys automatically, and extracts user claims.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import jwt as pyjwt

from platform_buildingblocks.authentication.config import KeycloakOptions
from platform_buildingblocks.authentication.discovery import KeycloakDiscoveryService
from platform_buildingblocks.authentication.extensions import (
	get_email,
	get_name,
	get_tenant_id,
	get_tenant_slug,
	get_user_id,
	get_user_type,
	is_tenant_admin,
	is_tenant_owner,
)

logger = logging.getLogger(__name__)


class AuthenticationError(Exception):
	"""Raised when JWT validation fails."""

	pass


@dataclass(frozen=True)
class PlatformUser:
	"""
	Authenticated user extracted from a validated JWT token.

	Equivalent to the ClaimsPrincipal with extension methods in .NET.
	"""

	user_id: str
	email: str | None
	first_name: str | None
	last_name: str | None
	name: str | None
	tenant_id: str | None
	tenant_slug: str | None
	user_type: str | None
	roles: list[str] = field(default_factory=list)
	claims: dict = field(default_factory=dict)

	@property
	def is_admin(self) -> bool:
		"""Check if user is TenantAdmin or TenantOwner."""
		return is_tenant_admin(self.claims)

	@property
	def is_owner(self) -> bool:
		"""Check if user is TenantOwner."""
		return is_tenant_owner(self.claims)


class PlatformAuth:
	"""
	Multi-tenant Keycloak JWT authentication handler.

	This is the main entry point for product developers.
	Equivalent to AddPlatformAuthentication() + MultiTenantJwtBearerHandler in .NET.

	Usage:
	    # From Frappe site_config
	    auth = PlatformAuth.from_config(frappe.conf)

	    # From a dict
	    auth = PlatformAuth(KeycloakOptions(
	        base_url="http://localhost:8080",
	        expected_audiences=["platform", "account"],
	    ))

	    # Validate a token
	    claims = auth.validate_token(token_string)

	    # Get user info from claims
	    user = auth.get_user_from_claims(claims)

	    # Or do both in one step from a request object
	    user = auth.get_current_user(request)
	"""

	def __init__(self, options: KeycloakOptions | None = None):
		self._options = options or KeycloakOptions()
		self._discovery = KeycloakDiscoveryService(
			keycloak_base_url=self._options.base_url
		)

	@classmethod
	def from_config(cls, config: dict) -> PlatformAuth:
		"""
		Create PlatformAuth from a config dict.

		Works with:
		- Frappe site_config.json (frappe.conf as dict)
		- Django settings dict
		- Plain dict with Keycloak settings

		Supports both flat keys (keycloak_base_url) and
		nested keys ({"Keycloak": {"BaseUrl": "..."}}).
		"""
		options = KeycloakOptions.from_dict(config)
		return cls(options)

	@property
	def options(self) -> KeycloakOptions:
		"""Access the current configuration."""
		return self._options

	@property
	def discovery(self) -> KeycloakDiscoveryService:
		"""Access the OIDC discovery service (for advanced use)."""
		return self._discovery

	def validate_token(self, token: str) -> dict:
		"""
		Validate a JWT token and return decoded claims.

		Mirrors MultiTenantJwtBearerHandler.HandleAuthenticateAsync() in .NET.

		This method:
		1. Decodes the token header to get the key ID (kid)
		2. Extracts the realm from the token's issuer claim
		3. Fetches JWKS from Keycloak for that realm
		4. Validates signature, expiry, and audience
		5. Returns the decoded claims dict

		Args:
		    token: JWT token string (without "Bearer " prefix)

		Returns:
		    dict: Decoded token claims (sub, email, tenant_id, etc.)

		Raises:
		    AuthenticationError: If token is invalid, expired, or wrong audience
		"""
		if not token:
			raise AuthenticationError("Token is required")

		# Strip "Bearer " prefix if accidentally included
		if token.startswith("Bearer "):
			token = token[7:]

		try:
			# Step 1: Decode header to get key ID
			unverified_header = pyjwt.get_unverified_header(token)
			kid = unverified_header.get("kid")

			# Step 2: Decode payload (unverified) to extract realm from issuer
			unverified_payload = pyjwt.decode(
				token, options={"verify_signature": False}
			)
			issuer = unverified_payload.get("iss", "")
			realm = issuer.rstrip("/").split("/")[-1]

			if not realm:
				raise AuthenticationError("Cannot determine realm from token issuer")

			if not kid:
				raise AuthenticationError("Token header missing key ID (kid)")

			# Step 3: Get signing key from OIDC discovery
			try:
				signing_key = self._discovery.get_signing_key(realm, kid)
			except (ConnectionError, ValueError) as e:
				raise AuthenticationError(str(e)) from e

			# Step 4: Build validation options
			decode_options = {
				"verify_exp": self._options.token_validation.validate_lifetime,
				"verify_iss": self._options.token_validation.validate_issuer,
				"verify_aud": self._options.token_validation.validate_audience,
			}

			decode_kwargs = {
				"key": signing_key,
				"algorithms": ["RS256"],
				"options": decode_options,
				"leeway": self._options.token_validation.clock_skew_seconds,
			}

			# Set expected issuer
			if self._options.token_validation.validate_issuer:
				decode_kwargs["issuer"] = self._options.get_realm_authority(realm)

			# Set expected audiences
			if self._options.token_validation.validate_audience:
				audiences = self._options.get_effective_audiences()
				if audiences:
					decode_kwargs["audience"] = audiences
				else:
					# No audiences configured but validation enabled — this is a config error
					raise AuthenticationError(
						"Audience validation is enabled but no ExpectedAudiences configured. "
						"Set expected_audiences in your config or disable audience validation."
					)

			# Step 5: Validate and decode
			decoded = pyjwt.decode(token, **decode_kwargs)

			if not decoded.get("sub"):
				# Fallback: use email or preferred_username as subject
				sub = decoded.get("email") or decoded.get("preferred_username")
				if sub:
					decoded["sub"] = sub
					logger.warning("Token missing 'sub' claim, using fallback: %s", sub)

			return decoded

		except pyjwt.ExpiredSignatureError:
			raise AuthenticationError("Token has expired")
		except pyjwt.InvalidAudienceError:
			raise AuthenticationError("Invalid token audience")
		except pyjwt.InvalidIssuerError:
			raise AuthenticationError("Invalid token issuer")
		except pyjwt.InvalidTokenError as e:
			raise AuthenticationError(f"Invalid token: {e}")
		except AuthenticationError:
			raise
		except Exception as e:
			raise AuthenticationError(f"Token validation failed: {e}") from e

	def get_user_from_claims(self, claims: dict) -> PlatformUser:
		"""
		Extract a PlatformUser from decoded JWT claims.

		Args:
		    claims: Decoded JWT claims dict (from validate_token)

		Returns:
		    PlatformUser with user info extracted from claims
		"""
		realm_access = claims.get("realm_access", {})
		roles = realm_access.get("roles", [])

		return PlatformUser(
			user_id=get_user_id(claims) or "",
			email=get_email(claims),
			first_name=claims.get("given_name"),
			last_name=claims.get("family_name"),
			name=get_name(claims),
			tenant_id=get_tenant_id(claims),
			tenant_slug=get_tenant_slug(claims),
			user_type=get_user_type(claims),
			roles=roles,
			claims=claims,
		)

	def get_current_user(self, request) -> PlatformUser:
		"""
		Validate the token from a request and return the authenticated user.

		Accepts any request object that has:
		- .headers dict/mapping with "Authorization" key, OR
		- .META dict with "HTTP_AUTHORIZATION" key (Django), OR
		- A Frappe request (uses frappe.request.headers)

		Args:
		    request: HTTP request object (Frappe, Flask, Django, FastAPI, etc.)

		Returns:
		    PlatformUser with validated user info

		Raises:
		    AuthenticationError: If no token present or token is invalid
		"""
		token = self._extract_token(request)
		claims = self.validate_token(token)
		return self.get_user_from_claims(claims)

	def get_current_user_from_frappe(self) -> PlatformUser:
		"""
		Validate the token from the current Frappe request context.

		Convenience method for Frappe apps — reads from frappe.request.headers.

		Returns:
		    PlatformUser with validated user info

		Raises:
		    AuthenticationError: If no token or invalid token
		    ImportError: If frappe is not installed
		"""
		try:
			import frappe
		except ImportError:
			raise ImportError("frappe is not installed. Use get_current_user(request) instead.")

		if not frappe.request:
			raise AuthenticationError("No active Frappe request context")

		return self.get_current_user(frappe.request)

	def _extract_token(self, request) -> str:
		"""Extract Bearer token from a request object."""
		auth_header = None

		# Try standard headers dict (Flask, FastAPI, Frappe)
		if hasattr(request, "headers"):
			headers = request.headers
			if hasattr(headers, "get"):
				auth_header = headers.get("Authorization") or headers.get("authorization")

		# Try Django META
		if not auth_header and hasattr(request, "META"):
			auth_header = request.META.get("HTTP_AUTHORIZATION")

		if not auth_header:
			raise AuthenticationError("Authorization header is required")

		if not auth_header.startswith("Bearer "):
			raise AuthenticationError("Authorization header must use Bearer scheme")

		token = auth_header[7:].strip()
		if not token:
			raise AuthenticationError("Bearer token is empty")

		return token
