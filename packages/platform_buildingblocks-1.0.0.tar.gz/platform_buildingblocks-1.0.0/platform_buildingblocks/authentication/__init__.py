"""
Platform Building Blocks - Authentication

Multi-tenant Keycloak JWT authentication for Python products.
Python equivalent of Platform.BuildingBlocks.Authentication (NuGet).

Usage:
    from platform_buildingblocks.authentication import PlatformAuth

    # Initialize from config dict (e.g., frappe.conf, settings, etc.)
    auth = PlatformAuth({
        "keycloak_base_url": "http://localhost:8080",
        "expected_audiences": ["platform", "account", "myproduct-bff"],
    })

    # Validate a token and get claims
    claims = auth.validate_token(token_string)

    # Extract user info from claims
    user = auth.get_user_from_claims(claims)

    # Or do it all in one step from a request
    user = auth.get_current_user(request)
"""

from platform_buildingblocks.authentication.config import (
	ClaimMappingOptions,
	KeycloakOptions,
	TokenValidationOptions,
)
from platform_buildingblocks.authentication.discovery import KeycloakDiscoveryService
from platform_buildingblocks.authentication.extensions import (
	get_email,
	get_name,
	get_product_id_from_token,
	get_tenant_id,
	get_tenant_slug,
	get_user_id,
	get_user_type,
	is_tenant_admin,
	is_tenant_owner,
)
from platform_buildingblocks.authentication.handler import PlatformAuth
from platform_buildingblocks.authentication.token_provider import (
	ServiceAccountToken,
	ServiceAccountTokenProvider,
)

__all__ = [
	# Main entry point
	"PlatformAuth",
	# Configuration
	"KeycloakOptions",
	"TokenValidationOptions",
	"ClaimMappingOptions",
	# Services
	"KeycloakDiscoveryService",
	"ServiceAccountTokenProvider",
	"ServiceAccountToken",
	# Claim extraction functions
	"get_tenant_id",
	"get_tenant_slug",
	"get_user_type",
	"get_user_id",
	"get_email",
	"get_name",
	"is_tenant_admin",
	"is_tenant_owner",
	"get_product_id_from_token",
]
