"""
Claim extraction helper functions.

Mirrors: Platform.BuildingBlocks.Authentication.Extensions.ClaimsPrincipalExtensions

These functions extract typed values from decoded JWT claim dicts.
They use the same claim names as the .NET ClaimsPrincipalExtensions.
"""

from __future__ import annotations

from platform_buildingblocks.contracts.constants import PlatformClaimTypes, UserTypes


def get_tenant_id(claims: dict) -> str | None:
	"""
	Get tenant ID from JWT claims.

	Equivalent to ClaimsPrincipal.GetTenantId() in .NET.
	"""
	return claims.get(PlatformClaimTypes.TENANT_ID)


def get_required_tenant_id(claims: dict) -> str:
	"""
	Get tenant ID from JWT claims, raising if not present.

	Equivalent to ClaimsPrincipal.GetRequiredTenantId() in .NET.
	"""
	tenant_id = get_tenant_id(claims)
	if not tenant_id:
		raise ValueError("Tenant ID claim not found in token")
	return tenant_id


def get_tenant_slug(claims: dict) -> str | None:
	"""
	Get tenant slug from JWT claims.

	Equivalent to ClaimsPrincipal.GetTenantSlug() in .NET.
	"""
	return claims.get(PlatformClaimTypes.TENANT_SLUG)


def get_user_type(claims: dict) -> str | None:
	"""
	Get user type (TenantOwner, TenantAdmin, TenantUser) from JWT claims.

	Equivalent to ClaimsPrincipal.GetUserType() in .NET.
	"""
	return claims.get(PlatformClaimTypes.USER_TYPE)


def get_user_id(claims: dict) -> str | None:
	"""
	Get user ID (Keycloak subject) from JWT claims.

	Equivalent to ClaimsPrincipal.GetUserId() in .NET.
	"""
	return claims.get("sub")


def get_required_user_id(claims: dict) -> str:
	"""
	Get user ID from JWT claims, raising if not present.

	Equivalent to ClaimsPrincipal.GetRequiredUserId() in .NET.
	"""
	user_id = get_user_id(claims)
	if not user_id:
		raise ValueError("User ID (sub) claim not found in token")
	return user_id


def get_email(claims: dict) -> str | None:
	"""
	Get email from JWT claims.

	Equivalent to ClaimsPrincipal.GetEmail() in .NET.
	"""
	return claims.get("email")


def get_name(claims: dict) -> str | None:
	"""
	Get display name from JWT claims.

	Equivalent to ClaimsPrincipal.GetName() in .NET.
	Falls back to email or preferred_username if name is not present.
	"""
	name = claims.get("name")
	if name:
		return name

	given = claims.get("given_name", "")
	family = claims.get("family_name", "")
	if given or family:
		return f"{given} {family}".strip()

	return claims.get("preferred_username") or claims.get("email")


def is_tenant_admin(claims: dict) -> bool:
	"""
	Check if user is a TenantAdmin or TenantOwner.

	Equivalent to ClaimsPrincipal.IsTenantAdmin() in .NET.
	Checks both the user_type claim and realm_access.roles.
	"""
	user_type = get_user_type(claims)
	if user_type and UserTypes.is_admin(user_type):
		return True

	# Also check realm_access roles
	realm_access = claims.get("realm_access", {})
	roles = realm_access.get("roles", [])
	return UserTypes.TENANT_ADMIN in roles or UserTypes.TENANT_OWNER in roles


def is_tenant_owner(claims: dict) -> bool:
	"""
	Check if user is a TenantOwner.

	Equivalent to ClaimsPrincipal.IsTenantOwner() in .NET.
	"""
	user_type = get_user_type(claims)
	if user_type == UserTypes.TENANT_OWNER:
		return True

	realm_access = claims.get("realm_access", {})
	roles = realm_access.get("roles", [])
	return UserTypes.TENANT_OWNER in roles


def get_product_id_from_token(claims: dict) -> str | None:
	"""
	Extract product ID from the azp (authorized party) claim.

	Equivalent to ClaimsPrincipal.GetProductIdFromToken() in .NET.
	Removes "-bff" and "-ui" suffixes to get the product ID.
	Example: "ticketbox-bff" → "ticketbox", "snovacrm-ui" → "snovacrm"
	"""
	azp = claims.get("azp", "")
	if not azp:
		return None

	for suffix in ("-bff", "-ui"):
		if azp.endswith(suffix):
			return azp[: -len(suffix)]

	return azp
