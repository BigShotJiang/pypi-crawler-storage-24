"""
Multi-tenancy configuration options.

Mirrors: Platform.BuildingBlocks.MultiTenancy.Configuration.MultiTenancyOptions
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class MultiTenancyOptions:
	"""
	Configuration for multi-tenant resolution.

	Equivalent to the "MultiTenancy" section in appsettings.json for .NET.
	"""

	host_patterns: list[str] = field(default_factory=lambda: [
		"{tenant}.{product}.localhost",
		"{tenant}.localhost",
	])
	enforce_token_match: bool = True
	tenant_registry_base_url: str | None = None
	excluded_paths: list[str] = field(default_factory=lambda: [
		"/health", "/ready", "/metrics", "/swagger", "/.well-known",
	])
	cache_duration_seconds: int = 300  # 5 minutes

	@classmethod
	def from_dict(cls, config: dict) -> MultiTenancyOptions:
		"""Create from a config dict."""
		# Support nested "MultiTenancy" key
		if "MultiTenancy" in config:
			mt = config["MultiTenancy"]
			return cls(
				host_patterns=mt.get("HostPatterns", []),
				enforce_token_match=mt.get("EnforceTokenMatch", True),
				tenant_registry_base_url=mt.get("TenantRegistryBaseUrl"),
				excluded_paths=mt.get("ExcludedPaths", cls.excluded_paths),
				cache_duration_seconds=mt.get("CacheDuration", 300),
			)

		# Support flat keys
		return cls(
			host_patterns=config.get("host_patterns", []),
			enforce_token_match=config.get("enforce_token_match", True),
			tenant_registry_base_url=config.get("tenant_registry_base_url"),
			excluded_paths=config.get("excluded_paths", cls.excluded_paths),
			cache_duration_seconds=config.get("cache_duration_seconds", 300),
		)
