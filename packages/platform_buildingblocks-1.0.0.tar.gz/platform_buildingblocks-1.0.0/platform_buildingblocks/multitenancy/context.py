"""
Tenant context — holds the resolved tenant for the current request.

Mirrors:
- Platform.BuildingBlocks.MultiTenancy.TenantContext
- Platform.BuildingBlocks.MultiTenancy.ITenantContext
- Platform.BuildingBlocks.MultiTenancy.TenantContextAccessor (AsyncLocal-based)

In Python, we use contextvars (equivalent to .NET AsyncLocal) to make
the tenant context flow across async operations without explicit passing.
"""

from __future__ import annotations

import contextvars
from dataclasses import dataclass, field

# AsyncLocal equivalent — flows across async/await boundaries
_current_tenant: contextvars.ContextVar[TenantContext | None] = contextvars.ContextVar(
	"current_tenant", default=None
)


@dataclass
class TenantContext:
	"""
	Holds resolved tenant information for the current request.

	Equivalent to ITenantContext / TenantContext in .NET.
	"""

	tenant_id: str = ""
	tenant_slug: str = ""
	realm_name: str = ""
	status: str = ""
	product_id: str | None = None
	is_resolved: bool = False

	@staticmethod
	def empty() -> TenantContext:
		"""Create an empty (unresolved) tenant context."""
		return TenantContext()

	@staticmethod
	def get_current() -> TenantContext | None:
		"""Get the tenant context for the current request/async context."""
		return _current_tenant.get()

	@staticmethod
	def set_current(context: TenantContext | None) -> contextvars.Token:
		"""
		Set the tenant context for the current request/async context.

		Returns a token that can be used to restore the previous value.
		"""
		return _current_tenant.set(context)

	@staticmethod
	def clear() -> None:
		"""Clear the tenant context for the current request."""
		_current_tenant.set(None)

	def set_tenant(
		self,
		tenant_id: str,
		tenant_slug: str,
		realm_name: str,
		status: str,
		product_id: str | None = None,
	) -> None:
		"""Update this context with resolved tenant info."""
		self.tenant_id = tenant_id
		self.tenant_slug = tenant_slug
		self.realm_name = realm_name
		self.status = status
		self.product_id = product_id
		self.is_resolved = True
