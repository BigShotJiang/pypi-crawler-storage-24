"""
Platform Building Blocks - Multi-Tenancy

Tenant context resolution and management for Python products.
Python equivalent of Platform.BuildingBlocks.MultiTenancy (NuGet).
"""

from platform_buildingblocks.multitenancy.config import MultiTenancyOptions
from platform_buildingblocks.multitenancy.context import TenantContext
from platform_buildingblocks.multitenancy.resolver import (
	ClaimsBasedTenantResolver,
	HostBasedTenantResolver,
	TenantResolutionResult,
)

__all__ = [
	"MultiTenancyOptions",
	"TenantContext",
	"TenantResolutionResult",
	"HostBasedTenantResolver",
	"ClaimsBasedTenantResolver",
]
