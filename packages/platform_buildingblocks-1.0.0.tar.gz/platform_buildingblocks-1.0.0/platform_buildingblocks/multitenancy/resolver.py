"""
Tenant resolution from JWT claims and hostnames.

Mirrors:
- Platform.BuildingBlocks.MultiTenancy.Resolution.ClaimsBasedTenantResolver
- Platform.BuildingBlocks.MultiTenancy.Resolution.HostBasedTenantResolver
- Platform.BuildingBlocks.MultiTenancy.Resolution.ITenantResolver
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

from platform_buildingblocks.contracts.constants import PlatformClaimTypes
from platform_buildingblocks.multitenancy.config import MultiTenancyOptions

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TenantResolutionResult:
	"""Result of attempting to resolve a tenant."""

	success: bool
	tenant_id: str | None = None
	tenant_slug: str | None = None
	realm_name: str | None = None
	status: str | None = None
	product_id: str | None = None
	failure_reason: str | None = None

	@staticmethod
	def succeeded(
		tenant_id: str,
		tenant_slug: str,
		realm_name: str,
		status: str = "Active",
		product_id: str | None = None,
	) -> TenantResolutionResult:
		return TenantResolutionResult(
			success=True,
			tenant_id=tenant_id,
			tenant_slug=tenant_slug,
			realm_name=realm_name,
			status=status,
			product_id=product_id,
		)

	@staticmethod
	def failed(reason: str) -> TenantResolutionResult:
		return TenantResolutionResult(success=False, failure_reason=reason)


class ClaimsBasedTenantResolver:
	"""
	Resolves tenant from JWT token claims.

	Mirrors: Platform.BuildingBlocks.MultiTenancy.Resolution.ClaimsBasedTenantResolver
	"""

	def resolve(self, claims: dict) -> TenantResolutionResult:
		"""
		Resolve tenant from decoded JWT claims.

		Args:
		    claims: Decoded JWT claims dict

		Returns:
		    TenantResolutionResult
		"""
		tenant_id = claims.get(PlatformClaimTypes.TENANT_ID)
		tenant_slug = claims.get(PlatformClaimTypes.TENANT_SLUG)

		if not tenant_id:
			return TenantResolutionResult.failed("No tenant_id claim in token")

		# Extract realm from issuer if slug not in claims
		if not tenant_slug:
			issuer = claims.get("iss", "")
			tenant_slug = issuer.rstrip("/").split("/")[-1] if issuer else None

		realm_name = tenant_slug or ""

		return TenantResolutionResult.succeeded(
			tenant_id=tenant_id,
			tenant_slug=tenant_slug or "",
			realm_name=realm_name,
			status="Active",
		)


class HostBasedTenantResolver:
	"""
	Resolves tenant from the request hostname using configured patterns.

	Mirrors: Platform.BuildingBlocks.MultiTenancy.Resolution.HostBasedTenantResolver

	Patterns use {tenant} and {product} placeholders:
	    "{tenant}.{product}.platform.kb.snovasys.com"
	    "{tenant}.platform.kb.snovasys.com"
	    "{tenant}.{product}.localhost"
	    "{tenant}.localhost"
	"""

	def __init__(self, options: MultiTenancyOptions):
		self._options = options
		self._compiled_patterns = self._compile_patterns(options.host_patterns)

	def resolve(self, hostname: str) -> TenantResolutionResult:
		"""
		Resolve tenant from a hostname.

		Args:
		    hostname: Request hostname (e.g., "tools.ticketbox.localhost")

		Returns:
		    TenantResolutionResult with tenant_slug and product_id
		"""
		# Remove port if present
		hostname_clean = hostname.split(":")[0]

		for pattern, regex in self._compiled_patterns:
			match = regex.match(hostname_clean)
			if match:
				groups = match.groupdict()
				tenant_slug = groups.get("tenant", "")
				product_id = groups.get("product")

				if tenant_slug:
					logger.debug(
						"Host '%s' matched pattern '%s': tenant=%s, product=%s",
						hostname,
						pattern,
						tenant_slug,
						product_id,
					)
					return TenantResolutionResult.succeeded(
						tenant_id="",  # Will be resolved from token or registry
						tenant_slug=tenant_slug,
						realm_name=tenant_slug,
						product_id=product_id,
					)

		return TenantResolutionResult.failed(
			f"Hostname '{hostname}' did not match any configured patterns"
		)

	@staticmethod
	def _compile_patterns(patterns: list[str]) -> list[tuple[str, re.Pattern]]:
		"""Compile host patterns into regex patterns."""
		compiled = []
		for pattern in patterns:
			# Convert {tenant} and {product} to named regex groups
			regex_str = re.escape(pattern)
			regex_str = regex_str.replace(r"\{tenant\}", r"(?P<tenant>[^.]+)")
			regex_str = regex_str.replace(r"\{product\}", r"(?P<product>[^.]+)")
			regex_str = f"^{regex_str}$"

			try:
				compiled.append((pattern, re.compile(regex_str, re.IGNORECASE)))
			except re.error as e:
				logger.warning("Invalid host pattern '%s': %s", pattern, e)

		return compiled
