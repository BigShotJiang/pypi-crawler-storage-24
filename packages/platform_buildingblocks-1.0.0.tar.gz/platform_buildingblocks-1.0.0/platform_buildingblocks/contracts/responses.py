"""
Request/response models for Platform API communication.

Mirrors:
- Platform.BuildingBlocks.Contracts.Requests.Entitlements.AuthorizeRequest
- Platform.BuildingBlocks.Contracts.Responses.Entitlements.AuthorizeResponse
- Platform.BuildingBlocks.Contracts.Responses.Entitlements.Denial
- Platform.BuildingBlocks.Contracts.Responses.Entitlements.UserProductsResponse
- Platform.BuildingBlocks.Contracts.Responses.Registry.HostResolutionResponse
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Denial(Enum):
	"""Reason why product access was denied."""

	NO_SEAT_ALLOTED = "NoSeatAlloted"
	SUBSCRIPTION_EXPIRED = "SubscriptionExpired"
	TRIAL_EXPIRED = "TrialExpired"


@dataclass(frozen=True)
class AuthorizeRequest:
	"""Request to check if a user is authorized for a product action."""

	tenant_id: str
	user_id: str
	product_id: str
	action: str


@dataclass(frozen=True)
class AuthorizeResponse:
	"""Response from the authorization check."""

	allowed: bool
	role: str | None = None
	limits: dict[str, object] = field(default_factory=dict)
	denial_reason: Denial | None = None


@dataclass(frozen=True)
class UserProductsResponse:
	"""List of products a user has access to."""

	tenant_id: str
	user_id: str
	products: list = field(default_factory=list)  # list[UserProductAccess]


@dataclass(frozen=True)
class HostResolutionResponse:
	"""Result of resolving a hostname to tenant + product."""

	tenant_id: str
	tenant_slug: str
	realm_name: str
	product_id: str | None = None
