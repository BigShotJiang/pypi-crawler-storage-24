"""
Platform Building Blocks - Contracts

Shared constants, models, and types used across all Platform services.
Python equivalent of Platform.BuildingBlocks.Contracts (NuGet).
"""

from platform_buildingblocks.contracts.constants import (
	PlatformClaimTypes,
	ProductRoles,
	TenantStatus,
	UserTypes,
)
from platform_buildingblocks.contracts.models import (
	ProductInfo,
	TenantInfo,
	UserProductAccess,
)
from platform_buildingblocks.contracts.responses import (
	AuthorizeRequest,
	AuthorizeResponse,
	Denial,
	HostResolutionResponse,
	UserProductsResponse,
)

__all__ = [
	"PlatformClaimTypes",
	"UserTypes",
	"ProductRoles",
	"TenantStatus",
	"TenantInfo",
	"ProductInfo",
	"UserProductAccess",
	"AuthorizeRequest",
	"AuthorizeResponse",
	"Denial",
	"UserProductsResponse",
	"HostResolutionResponse",
]
