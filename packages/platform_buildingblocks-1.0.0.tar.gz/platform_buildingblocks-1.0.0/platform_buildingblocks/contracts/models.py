"""
Shared data models used across Platform services.

Mirrors:
- Platform.BuildingBlocks.Contracts.Models.TenantInfo
- Platform.BuildingBlocks.Contracts.Models.ProductInfo
- Platform.BuildingBlocks.Contracts.Models.UserProductAccess
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class TenantInfo:
	"""Information about a tenant."""

	tenant_id: str
	slug: str
	company_name: str
	status: str
	realm_name: str | None = None


@dataclass(frozen=True)
class ProductInfo:
	"""Information about a product."""

	product_id: str
	name: str
	subdomain_prefix: str
	icon_url: str | None = None
	is_active: bool = True


@dataclass(frozen=True)
class UserProductAccess:
	"""A user's access to a specific product."""

	product_id: str
	name: str
	url: str
	role: str
	features: dict[str, object] = field(default_factory=dict)
