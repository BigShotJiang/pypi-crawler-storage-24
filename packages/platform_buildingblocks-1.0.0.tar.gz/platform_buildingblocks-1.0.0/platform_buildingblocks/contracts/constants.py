"""
Platform claim types, user types, product roles, and tenant statuses.

Mirrors:
- Platform.BuildingBlocks.Contracts.Constants.ClaimTypes
- Platform.BuildingBlocks.Contracts.Constants.UserTypes
- Platform.BuildingBlocks.Contracts.Constants.ProductRoles
- Platform.BuildingBlocks.Contracts.Models.TenantStatus
"""


class PlatformClaimTypes:
	"""Custom JWT claim names used by the Platform."""

	TENANT_ID = "tenant_id"
	TENANT_SLUG = "tenant_slug"
	USER_TYPE = "user_type"
	REALM_NAME = "realm"


class UserTypes:
	"""Realm-level user roles assigned in Keycloak."""

	TENANT_OWNER = "TenantOwner"
	TENANT_ADMIN = "TenantAdmin"
	TENANT_USER = "TenantUser"

	ALL_TYPES = [TENANT_OWNER, TENANT_ADMIN, TENANT_USER]

	@staticmethod
	def is_admin(user_type: str) -> bool:
		return user_type in (UserTypes.TENANT_OWNER, UserTypes.TENANT_ADMIN)


class ProductRoles:
	"""Product-level roles for seat management."""

	PRODUCT_ADMIN = "ProductAdmin"
	MANAGER = "Manager"
	MEMBER = "Member"

	ALL_ROLES = [PRODUCT_ADMIN, MANAGER, MEMBER]

	_PRIORITY = {
		PRODUCT_ADMIN: 100,
		MANAGER: 50,
		MEMBER: 10,
	}

	@staticmethod
	def get_priority(role: str) -> int:
		return ProductRoles._PRIORITY.get(role, 0)

	@staticmethod
	def get_higher_role(role1: str, role2: str) -> str:
		return role1 if ProductRoles.get_priority(role1) >= ProductRoles.get_priority(role2) else role2


class TenantStatus:
	"""Possible tenant statuses."""

	TRIAL = "Trial"
	ACTIVE = "Active"
	SUSPENDED = "Suspended"
	CANCELLED = "Cancelled"

	ALL_STATUSES = [TRIAL, ACTIVE, SUSPENDED, CANCELLED]

	@staticmethod
	def is_valid(status: str) -> bool:
		return status in TenantStatus.ALL_STATUSES
