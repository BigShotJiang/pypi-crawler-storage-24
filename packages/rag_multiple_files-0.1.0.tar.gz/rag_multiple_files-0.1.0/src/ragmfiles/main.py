"""MCP server that answers queries against pre-built PDF indexes.

Indexes must already exist (run the indexer first for each PDF).
"""

import json
import os
from pathlib import Path
import faiss
import numpy as np
from mcp.server.fastmcp import FastMCP
from sentence_transformers import SentenceTransformer
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

MODEL_NAME = "all-MiniLM-L6-v2"

mcp = FastMCP("rag-multiple-files")

_model: SentenceTransformer | None = None
# Maps pdf filename (e.g. "doc.pdf") -> (faiss.Index, list[dict])
_indexes: dict[str, tuple[faiss.Index, list[dict]]] = {}


def get_model() -> SentenceTransformer:
    global _model
    if _model is None:
        _model = SentenceTransformer(MODEL_NAME)
    return _model


def get_pdf_folder() -> Path:
    folder = os.environ.get("PDF_FOLDER", "")
    if not folder:
        raise ValueError("PDF_FOLDER environment variable is not set")
    path = Path(folder)
    if not path.is_dir():
        raise FileNotFoundError(f"Folder not found: {path}")
    return path


def load_all_indexes() -> None:
    """Scan PDF_FOLDER for *.index subdirs and load each one."""
    folder = get_pdf_folder()
    for index_dir in sorted(folder.glob("*.index")):
        faiss_file = index_dir / "index.faiss"
        chunks_file = index_dir / "chunks.json"
        if not faiss_file.exists() or not chunks_file.exists():
            logger.warning(f"Skipping incomplete index at {index_dir}")
            continue
        # Reconstruct the original PDF filename from the index dir name
        pdf_name = index_dir.stem + ".pdf"
        if pdf_name in _indexes:
            continue
        logger.info(f"Loading index for {pdf_name}...")
        index = faiss.read_index(str(faiss_file))
        chunks = json.loads(chunks_file.read_text())
        _indexes[pdf_name] = (index, chunks)
    if not _indexes:
        logger.warning("No indexes found in PDF_FOLDER. Run the indexer first.")


@mcp.tool()
def list_indexed_files() -> str:
    """List all PDF files that have a loaded index available for querying."""
    if not _indexes:
        return "No indexes loaded."
    return "\n".join(sorted(_indexes.keys()))


@mcp.tool()
def query_pdf(query: str, file_name: str, top_k: int = 5) -> str:
    """Search the indexed PDF for chunks most relevant to the query.

    Args:
        query: The question or topic to search for.
        file_name: The PDF filename to query (e.g. "document.pdf").
        top_k: Number of chunks to return (default: 5).
    """
    logger.info(f"query_pdf file={file_name} query={query!r} top_k={top_k}")
    if file_name not in _indexes:
        available = ", ".join(sorted(_indexes.keys())) or "none"
        return f"No index loaded for '{file_name}'. Available: {available}"

    index, chunks = _indexes[file_name]
    model = get_model()
    query_vec = model.encode([query], normalize_embeddings=True)
    query_vec = np.array(query_vec, dtype=np.float32)
    scores, indices = index.search(query_vec, min(top_k, len(chunks)))
    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx == -1:
            continue
        chunk = chunks[idx]
        results.append(
            f"[Page {chunk['page']}] (score: {score:.3f})\n{chunk['text']}"
        )
    if not results:
        return "No matching chunks found."
    return (
        f"Found {len(results)} relevant chunks from: {file_name}\n\n"
        + "\n\n---\n\n".join(results)
    )


def main():
    """Entry point for the RAG MCP server."""
    logger.info("Starting MCP server...")
    load_all_indexes()
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
