# RAG Multiple Files MCP Server

A local MCP server that lets you semantically search multiple PDFs using natural language queries.

## Use from Claude Code

Configure the MCP server:

```json
"mcpServers": {
    ...
    "rag-multiple-files": {
        "type": "stdio",
        "command": "uvx",
        "args": [
            "rag-multiple-files"
        ],
        "env": {
            "PDF_FOLDER": "/path/to/your/folder"
        }
    }
}
```

### Sample Request

Query:

```
YYYYYYYYYYYYYYY.pdf: What is the chain slack
```

Response:

```
Based on the YYYYYYYYYYYYYYY owner's manual:
    Chain tension (slack): XX mm (ZZ in)
```

## How it works

1. **Querying** — The query is embedded with the same model and searched against the FAISS index. The top-k most similar chunks are returned with their page numbers and similarity scores.

Parameters:

- query (str) - required - no default - the question or topic to search for
- file_name (str) - required - no default - the name of the PDF file
- top_k (int) - not required - 5 default - number of chunks to return
