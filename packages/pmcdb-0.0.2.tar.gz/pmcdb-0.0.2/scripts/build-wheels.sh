#!/usr/bin/env bash
#
# Build maturin wheels for all supported platforms.
#
# Works from macOS (native + podman for Linux) or Linux (native + zig for arm).
#
# Requirements:
#   - Rust toolchain (rustup)
#   - maturin (uv tool install maturin)
#   - podman (brew install podman) for cross-OS wheels
#
# Usage:
#   ./scripts/build-wheels.sh          # all platforms
#   ./scripts/build-wheels.sh macos    # macOS only (from macOS)
#   ./scripts/build-wheels.sh linux    # Linux only (needs podman on macOS)
#   ./scripts/build-wheels.sh windows  # Windows cross-compile (best-effort)
#
# Output: target/wheels/*.whl + target/wheels/*.tar.gz

set -euo pipefail
cd "$(git rev-parse --show-toplevel)"

OUT=target/wheels
mkdir -p "$OUT"

filter="${1:-all}"

# ---------------------------------------------------------------------------
# macOS: native arm64 + cross x86_64
# ---------------------------------------------------------------------------
build_macos() {
    if [ "$(uname -s)" != "Darwin" ]; then
        echo "SKIP macOS wheels: not on macOS"
        return
    fi

    echo "=== macOS arm64 (native) ==="
    uv run maturin build --release --strip -o "$OUT"

    echo "=== macOS x86_64 (cross) ==="
    rustup target add x86_64-apple-darwin 2>/dev/null || true
    uv run maturin build --release --strip \
        --target x86_64-apple-darwin -o "$OUT"
}

# ---------------------------------------------------------------------------
# Linux: native or podman
# ---------------------------------------------------------------------------
build_linux() {
    if [ "$(uname -s)" = "Linux" ]; then
        echo "=== Linux $(uname -m) (native) ==="
        uv run maturin build --release --strip -o "$OUT"

        # Cross-compile other arch if on x86_64
        if [ "$(uname -m)" = "x86_64" ]; then
            echo "=== Linux aarch64 (zig cross) ==="
            rustup target add aarch64-unknown-linux-gnu 2>/dev/null || true
            uv run maturin build --release --strip --zig \
                --target aarch64-unknown-linux-gnu -o "$OUT"
        fi
        return
    fi

    # From macOS/other: use podman
    if ! command -v podman &>/dev/null; then
        echo "SKIP Linux wheels: podman not found (brew install podman)"
        return
    fi

    echo "=== Linux x86_64 (podman) ==="
    podman run --rm -v "$(pwd)":/io -w /io \
        ghcr.io/pyo3/maturin:latest \
        build --release --strip -o /io/"$OUT"

    echo "=== Linux aarch64 (podman + zig cross) ==="
    podman run --rm -v "$(pwd)":/io -w /io \
        --entrypoint sh \
        ghcr.io/pyo3/maturin:latest \
        -c 'pip install ziglang && \
            rustup target add aarch64-unknown-linux-gnu && \
            maturin build --release --strip --zig \
            --target aarch64-unknown-linux-gnu -o /io/'"$OUT"
}

# ---------------------------------------------------------------------------
# Windows: zig cross-compile (best-effort)
# ---------------------------------------------------------------------------
build_windows() {
    echo "=== Windows x86_64 (zig cross, best-effort) ==="
    rustup target add x86_64-pc-windows-gnu 2>/dev/null || true

    if uv run maturin build --release --strip --zig \
        --target x86_64-pc-windows-gnu -o "$OUT" 2>&1; then
        echo "Windows wheel built successfully"
    else
        echo "SKIP Windows: cross-compile failed (expected for some native deps)"
        echo "  Windows users will build from sdist (requires rustup)"
    fi
}

# ---------------------------------------------------------------------------
# sdist (always)
# ---------------------------------------------------------------------------
build_sdist() {
    echo "=== sdist ==="
    uv run maturin sdist -o "$OUT"
}

# ---------------------------------------------------------------------------

case "$filter" in
    macos)   build_macos ;;
    linux)   build_linux ;;
    windows) build_windows ;;
    sdist)   build_sdist ;;
    all)
        build_macos
        build_linux
        build_windows
        build_sdist
        ;;
    *)
        echo "Usage: $0 [all|macos|linux|windows|sdist]"
        exit 1
        ;;
esac

echo ""
echo "=== Wheels ==="
ls -lh "$OUT"/*.whl "$OUT"/*.tar.gz 2>/dev/null || true
