"""Tests for pmcdb Python layer.

Run: PYTHONPATH=python pytest python/tests -q
"""
import os
import sys
import tempfile
from pathlib import Path
from datetime import datetime, timezone

import pytest


# -- Import tests -------------------------------------------------------------

def test_import_build():
    from pmcdb._build import default_data_dir, flock, is_fresh, write_build_date
    assert callable(default_data_dir)

def test_import_tables():
    from pmcdb._tables import ALL_TABLES, ftp_fingerprint, compact_table
    assert len(ALL_TABLES) == 30  # 27 XML + 3 aux

def test_import_aux():
    from pmcdb._aux import build_aux_table, _BUILDERS
    assert set(_BUILDERS.keys()) == {"journal", "deleted_pmid_list", "computed_author"}

def test_import_pubmed():
    from pmcdb import PubMed, __version__
    assert __version__

#def test_import_rlm():
#    from pmcdb.rlm import gini
#    assert callable(gini)


# -- Table list ---------------------------------------------------------------

def test_xml_tables_count():
    from pmcdb._tables import _XML_TABLES, AUX_TABLES, ALL_TABLES
    assert len(_XML_TABLES) == 27
    assert len(AUX_TABLES) == 3
    assert len(ALL_TABLES) == 30

def test_no_duplicate_tables():
    from pmcdb._tables import ALL_TABLES
    assert len(ALL_TABLES) == len(set(ALL_TABLES))

def test_core_tables_subset():
    from pmcdb._tables import _CORE_TABLES, ALL_TABLES
    for t in _CORE_TABLES:
        assert t in ALL_TABLES

def test_table_has_data_missing():
    from pmcdb._tables import table_has_data
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        assert not table_has_data(Path(d), "citation")


# -- Gini coefficient ---------------------------------------------------------

#def test_gini_empty():
#    import numpy as np
#    from pmcdb.rlm import gini
#    assert gini(np.array([])) == 0.0

#def test_gini_uniform():
#    import numpy as np
#    from pmcdb.rlm import gini
#    # All equal -> gini = 0
#    assert gini(np.array([5, 5, 5, 5])) == 0.0
#
#def test_gini_single():
#    import numpy as np
#    from pmcdb.rlm import gini
#    assert gini(np.array([42])) == 0.0
#
#def test_gini_extreme():
#    import numpy as np
#    from pmcdb.rlm import gini
#    # One person has everything -> gini near 1
#    g = gini(np.array([0, 0, 0, 0, 100]))
#    assert g > 0.7
#
#def test_gini_known():
#    import numpy as np
#    from pmcdb.rlm import gini
#    # [1,2,3,4,5] has known gini = 0.2667
#    g = gini(np.array([1, 2, 3, 4, 5]))
#    assert abs(g - 0.2667) < 0.001


# -- flock --------------------------------------------------------------------

def test_flock_basic():
    from pmcdb._build import flock
    with tempfile.TemporaryDirectory() as d:
        lockfile = Path(d) / "test.lock"
        with flock(lockfile):
            assert lockfile.exists()

def test_flock_reentrant_different_files():
    from pmcdb._build import flock
    with tempfile.TemporaryDirectory() as d:
        with flock(Path(d) / "a.lock"):
            with flock(Path(d) / "b.lock"):
                pass  # should not deadlock


# -- Build freshness ----------------------------------------------------------

def test_write_and_check_freshness():
    from pmcdb._build import is_fresh, write_build_date
    with tempfile.TemporaryDirectory() as d:
        dd = Path(d)
        assert not is_fresh(dd)
        write_build_date(dd)
        assert is_fresh(dd)

def test_stale_build():
    from pmcdb._build import is_fresh
    with tempfile.TemporaryDirectory() as d:
        dd = Path(d)
        # Write a timestamp far in the past
        (dd / '.latest-build-date').write_text("2020-01-01T00:00:00+00:00")
        assert not is_fresh(dd)


# -- Binary finder -------------------------------------------------------------

def test_find_binary_does_not_crash():
    """_find_binary should either find it or raise RuntimeError, never crash."""
    from pmcdb._build import _find_binary
    try:
        path = _find_binary()
        assert os.path.isfile(path)
    except RuntimeError as e:
        assert "pmcdb-core not found" in str(e)


# -- PubMed class basics -------------------------------------------------------

def test_pubmed_init():
    from pmcdb import PubMed
    with tempfile.TemporaryDirectory() as d:
        db = PubMed(data_dir=d)
        assert db.data_dir == Path(d)
        assert db._through is None

def test_pubmed_through():
    from pmcdb import PubMed
    with tempfile.TemporaryDirectory() as d:
        db = PubMed(data_dir=d, through="2024")
        assert db._through == "2024"


# -- Sort orders ---------------------------------------------------------------

def test_citation_sort_order():
    from pmcdb._tables import _SORT_ORDERS, _DEFAULT_SORT
    assert "citation" in _SORT_ORDERS
    assert "pmid" in _SORT_ORDERS["citation"]
    assert _DEFAULT_SORT == "1"
