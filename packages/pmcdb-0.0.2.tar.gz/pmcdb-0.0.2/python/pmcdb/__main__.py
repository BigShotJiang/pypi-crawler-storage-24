from pmcdb import main
main()
