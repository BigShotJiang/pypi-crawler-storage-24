import requests
import pandas as pd
from bs4 import BeautifulSoup
from urllib.parse import urljoin


class PromOnePageTracker:
    def __init__(self, url: str):
        self.url = url
        self.headers = {
            "User-Agent": "Mozilla/5.0"
        }

    def fetch_html(self) -> str:
        response = requests.get(self.url, headers=self.headers, timeout=20)
        response.raise_for_status()
        return response.text

    def parse_page(self, html: str) -> pd.DataFrame:
        soup = BeautifulSoup(html, "html.parser")
        rows = []

        product_blocks = soup.select('div[data-qaid="product_block"]')

        for block in product_blocks:
            name_el = block.select_one('[data-qaid="product_name"]')
            price_el = block.select_one('[data-qaid="product_price"]')
            link_el = block.select_one('a[data-qaid="product_link"]')
            company_el = block.select_one('[data-qaid="company_name"]')
            rating_el = block.select_one('[data-qaid="product_rating"]')
            old_price_el = block.select_one('[data-qaid="old_price"]')
            presence_el = block.select_one('[data-qaid="product_presence"]')
            image_el = block.select_one('[data-qaid="image_link"]')

            title = name_el.get_text(" ", strip=True) if name_el else None
            url = urljoin(self.url, link_el["href"]) if link_el and link_el.get("href") else None
            company = company_el.get_text(" ", strip=True) if company_el else None
            presence = presence_el.get_text(" ", strip=True) if presence_el else None
            image_url = image_el.get("src") if image_el else None

            price_value = None
            price_text = None
            if price_el:
                price_text = price_el.get_text(" ", strip=True)
                raw_price = price_el.get("data-qaprice")
                if raw_price:
                    try:
                        price_value = float(raw_price)
                    except ValueError:
                        price_value = None

            old_price_value = None
            old_price_text = None
            if old_price_el:
                old_price_text = old_price_el.get_text(" ", strip=True)
                raw_old_price = old_price_el.get("data-qaprice")
                if raw_old_price:
                    try:
                        old_price_value = float(raw_old_price)
                    except ValueError:
                        old_price_value = None

            rating_value = None
            rating_count = None
            if rating_el:
                raw_rating = rating_el.get("data-qarating")
                raw_count = rating_el.get("data-qacount")

                if raw_rating:
                    try:
                        rating_value = float(raw_rating)
                    except ValueError:
                        rating_value = None

                if raw_count:
                    try:
                        rating_count = int(raw_count)
                    except ValueError:
                        rating_count = None

            rows.append({
                "title": title,
                "price_text": price_text,
                "price_value": price_value,
                "old_price_text": old_price_text,
                "old_price_value": old_price_value,
                "rating_value": rating_value,
                "rating_count": rating_count,
                "company": company,
                "presence": presence,
                "url": url,
                "image_url": image_url,
            })

        df = pd.DataFrame(rows)
        if not df.empty:
            df = df.drop_duplicates(subset=["title", "url"]).reset_index(drop=True)

        return df

    def run(self) -> pd.DataFrame:
        html = self.fetch_html()
        return self.parse_page(html)


if __name__ == "__main__":
    url = "https://prom.ua/ua/Tehnika-i-elektronika"

    tracker = PromOnePageTracker(url)
    df = tracker.run()

    print("Знайдено товарів:", len(df))
    print(df.head(10).to_string())

    df.to_csv("prom_page1_correct.csv", index=False, encoding="utf-8-sig")
    print("Збережено у prom_page1_correct.csv")