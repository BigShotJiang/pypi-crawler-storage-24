import json
import os
import time
import logging
import threading
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Dict, Any, Callable, List
from concurrent.futures import ThreadPoolExecutor, as_completed
from openai import OpenAI

# Attempt to import ForgeDatabase safely for cloud mode
try:
    from aegis_forge.cloud_db import ForgeDatabase
except ImportError:
    ForgeDatabase = None

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class UniversalAegisForge(ABC):
    """
    The Base Class for Execution-Guided Synthesis.
    Handles the LLM, the retry loop, context management, Cloud DB sync, and Parallel Execution.
    """
    def __init__(
        self,
        system_prompt: str,
        output_file: Optional[str] = None,
        max_retries: Optional[int] = None,
        base_url: Optional[str] = None,
        generation_kwargs: Optional[Dict[str, Any]] = None,
        llm_call: Optional[Callable[[List[Dict[str, str]], Dict[str, Any]], str]] = None,
        trajectory_formatter: Optional[Callable[[List[Dict[str, str]]], Dict]] = None,
        db_config: Optional[Dict[str, str]] = None,
        max_workers: Optional[int] = None
    ):
        self.system_prompt = system_prompt
        self.output_file = Path(output_file) if output_file else None
        
        # Thread safety locks
        self.file_lock = threading.Lock()
        self.db_lock = threading.Lock()

        # Database Initialization
        self.db_config = db_config
        self.db = None
        if self.db_config:
            if ForgeDatabase is None:
                raise ImportError("cloud_db.py module not found. Cannot initialize cloud mode.")
            logger.info("📡 Cloud Configuration detected. Initializing ForgeDatabase...")
            self.db = ForgeDatabase()
            
            # Validate required DB config keys
            if "read_table" not in self.db_config or "write_table" not in self.db_config:
                raise ValueError("db_config must contain 'read_table' and 'write_table' keys.")

        # Concurrency & Retry setup
        self.max_workers = max_workers or int(os.getenv("AEGIS_WORKERS", "3"))
        self.max_retries = max_retries if max_retries is not None else int(os.getenv("AEGIS_MAX_RETRIES", "4"))
        self.success_count = 0

        # Build generation kwargs with environment-aware defaults
        default_temp = float(os.getenv("AEGIS_TEMPERATURE", "0.2"))
        self.generation_kwargs = generation_kwargs or {}
        if "temperature" not in self.generation_kwargs:
            self.generation_kwargs["temperature"] = default_temp

        self.retry_delay = float(os.getenv("AEGIS_RETRY_DELAY", "2"))
        self.trajectory_formatter = trajectory_formatter or self._default_trajectory

        # Set up LLM call mechanism
        if llm_call is not None:
            self.llm_call = llm_call
        else:
            self.client = OpenAI(
                api_key=os.getenv("OPENAI_API_KEY", "dummy"),
                base_url=base_url
            )
            self.model = os.getenv("MODEL_NAME", "gpt-3.5-turbo")
            self.llm_call = self._openai_call

    def _openai_call(self, messages: List[Dict[str, str]], kwargs: Dict[str, Any]) -> str:
        # Provide a default timeout to prevent threads from hanging forever
        timeout = kwargs.get("timeout", 120.0)  # safe read, no modification
        
        call_kwargs = {
            "model": self.model,
            "messages": messages,
            "timeout": timeout,
            **kwargs
        }
        
        response = self.client.chat.completions.create(**call_kwargs)
        return response.choices[0].message.content

    @abstractmethod
    def generate_prompt(self) -> str:
        """Override this: Generate a random combinatorial problem."""
        pass

    @abstractmethod
    def parse_output(self, raw_llm_response: str) -> str:
        """Override this: Extract the code/JSON from the raw LLM response."""
        pass

    @abstractmethod
    def execute_critic(self, parsed_output: str) -> dict:
        """
        Override this: The Deterministic Validator.
        Must return: {"success": bool, "feedback": str}
        """
        pass

    def run_synthesis_loop(self, user_prompt: str, task_id: Optional[str] = None) -> bool:
        """Executes the LLM retry loop. Thread-safe."""
        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": user_prompt}
        ]

        final_error = "Unknown Error"
        last_exception = None

        for iteration in range(1, self.max_retries + 1):
            try:
                raw_output = self.llm_call(messages, self.generation_kwargs)
                last_exception = None # Reset on success
            except Exception as e:
                logger.warning(f"[Task {task_id or 'Local'}] ⚠️ LLM call failed on iteration {iteration}: {e}")
                last_exception = e
                time.sleep(self.retry_delay)
                continue

            parsed_code = self.parse_output(raw_output)
            
            # Wrap Critic in a try/except to prevent fatal thread crashes
            try:
                critic_result = self.execute_critic(parsed_code)
            except Exception as e:
                logger.error(f"[Task {task_id or 'Local'}] ⚠️ Critic execution crashed unexpectedly: {e}")
                critic_result = {"success": False, "feedback": f"Critic System Crash: {str(e)}"}

            if critic_result.get("success", False):
                logger.info(f"[Task {task_id or 'Local'}] ✅ SUCCESS on iteration {iteration}.")
                trajectory = messages + [{"role": "assistant", "content": raw_output}]
                
                # Save the Gold Data safely
                self._save_trajectory(trajectory, task_id, is_success=True)
                
                with self.file_lock:
                    self.success_count += 1
                return True
            else:
                logger.warning(f"[Task {task_id or 'Local'}] ❌ FAILED on iteration {iteration}. Retrying...")
                final_error = critic_result.get('feedback', 'Unknown error')
                messages.append({"role": "assistant", "content": raw_output})
                messages.append({
                    "role": "user",
                    "content": f"Execution failed with error:\n{final_error}\nFix the code."
                })

        logger.error(f"[Task {task_id or 'Local'}] 💀 ABORTED after {self.max_retries} retries.")
        
        if last_exception:
            final_error = f"LLM Call Failed repeatedly. Last exception: {str(last_exception)}"

        self._save_trajectory(messages, task_id, is_success=False, error_log=final_error)
        return False

    def _save_trajectory(self, trajectory_messages: list, task_id: Optional[str], is_success: bool, error_log: str = None):
        """Routes the saved data to Cloud DB or a Local File. Thread-safe."""
        record = self.trajectory_formatter(trajectory_messages)
        status = "success" if is_success else "failed"

        # 1. Cloud Save (Secured with DB Lock to prevent connection pooling issues)
        if self.db and self.db_config:
            write_table = self.db_config["write_table"]
            read_table = self.db_config["read_table"]

            db_payload = {
                "trajectory": record,
                "status": status,
                "prompt_id": task_id
            }
            if error_log:
                db_payload["error_log"] = error_log

            with self.db_lock:
                self.db.insert_trajectory(write_table, db_payload)
                if task_id:
                    self.db.update_task_status(read_table, task_id, status, error_log)

        # 2. Local File Save (Secured with File Lock)
        if self.output_file:
            with self.file_lock:
                with open(self.output_file, "a") as f:
                    f.write(json.dumps(record) + "\n")

    @staticmethod
    def _default_trajectory(messages):
        return {
            "conversations": [
                {
                    "from": "system" if m["role"] == "system" else "human" if m["role"] == "user" else "gpt",
                    "value": m["content"]
                }
                for m in messages
            ]
        }

    def start_factory(self, batch_size: int = 10, run_mode: str = "local"):
        """
        Ignites the Forge in Parallel using self.max_workers
        """
        logger.info(f"🚀 Igniting Forge in {run_mode.upper()} mode with {self.max_workers} PARALLEL WORKERS.")

        if run_mode == "cloud":
            if not self.db:
                raise ValueError("Cannot run in cloud mode without passing db_config during initialization.")
            
            read_table = self.db_config["read_table"]
            tasks = self.db.fetch_pending_tasks(read_table, limit=batch_size)
            
            if not tasks:
                logger.info("📭 No pending tasks found in the database. Exiting.")
                return

            logger.info(f"📥 Pulled {len(tasks)} tasks from cloud. Starting parallel processing...")
            
            # Mark all fetched tasks as processing safely
            with self.db_lock:
                for task in tasks:
                    self.db.update_task_status(read_table, task.get("id"), "processing")

            # Execute Cloud Tasks in Parallel with strict crash recovery mapping
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = {
                    executor.submit(self.run_synthesis_loop, task.get("prompt", "MISSING PROMPT"), task.get("id")): task.get("id") 
                    for task in tasks
                }
                
                for future in as_completed(futures):
                    task_id = futures[future]
                    try:
                        future.result() # Raises exception if the thread crashed
                    except Exception as e:
                        logger.error(f"⚠️ Thread crashed unexpectedly for Task {task_id}: {e}")
                        # Stranded Task Recovery: Revert stuck "processing" task to "failed"
                        with self.db_lock:
                            self.db.update_task_status(read_table, task_id, "failed", f"Thread Fatal Crash: {str(e)}")

        else:
            # Traditional Local Loop in Parallel
            logger.info(f"Generating {batch_size} local tasks...")
            local_prompts = [self.generate_prompt() for _ in range(batch_size)]
            
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = {
                    executor.submit(self.run_synthesis_loop, prompt, f"LOCAL-{i}"): f"LOCAL-{i}" 
                    for i, prompt in enumerate(local_prompts)
                }
                
                for future in as_completed(futures):
                    task_id = futures[future]
                    try:
                        future.result()
                    except Exception as e:
                        logger.error(f"⚠️ Local Thread {task_id} crashed unexpectedly: {e}")
                
        logger.info(f"\n🏁 Complete. Yield: {self.success_count} Gold Trajectories.")