from easy_binance import EasyBinance


def test_list_products_contains_usds_futures():
    client = EasyBinance()
    names = [product.name for product in client.list_products()]
    assert "usds-futures" in names


def test_list_methods_contains_exchange_information():
    client = EasyBinance()
    methods = client.list_methods("usds-futures", "rest")
    names = [method.name for method in methods]
    assert "exchange_information" in names
