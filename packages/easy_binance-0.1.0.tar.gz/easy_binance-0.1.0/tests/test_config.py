from pathlib import Path

from easy_binance.config import load_credentials


def test_load_credentials_prefers_local_dotenv(tmp_path, monkeypatch):
    env_file = tmp_path / ".env"
    env_file.write_text(
        'BINANCE_API_KEY="dotenv-key"\nBINANCE_API_SECRET="dotenv-secret"\n',
        encoding="utf-8",
    )
    monkeypatch.setenv("BINANCE_API_KEY", "env-key")
    monkeypatch.setenv("BINANCE_API_SECRET", "env-secret")

    loaded = load_credentials(cwd=tmp_path)

    assert loaded.api_key == "dotenv-key"
    assert loaded.api_secret == "dotenv-secret"
    assert loaded.source == "dotenv"
    assert loaded.env_file == Path(env_file)


def test_load_credentials_falls_back_to_environment(tmp_path, monkeypatch):
    monkeypatch.setenv("BINANCE_API_KEY", "env-key")
    monkeypatch.setenv("BINANCE_API_SECRET", "env-secret")

    loaded = load_credentials(cwd=tmp_path)

    assert loaded.api_key == "env-key"
    assert loaded.api_secret == "env-secret"
    assert loaded.source == "environment"
    assert loaded.env_file is None
