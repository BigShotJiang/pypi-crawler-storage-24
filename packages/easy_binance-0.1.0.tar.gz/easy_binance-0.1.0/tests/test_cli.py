from typer.testing import CliRunner

from easy_binance.cli import app

runner = CliRunner()


def test_help():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Unified CLI for Binance derivatives APIs" in result.output


def test_products_command_json():
    result = runner.invoke(app, ["products", "--output", "json"])
    assert result.exit_code == 0
    assert "usds-futures" in result.output
