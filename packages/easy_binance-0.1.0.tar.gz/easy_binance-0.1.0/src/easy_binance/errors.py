class EasyBinanceError(RuntimeError):
    """Base exception for easy-binance."""
