"""Public package API for easy-binance."""

from .config import EasyBinanceConfig, LoadedCredentials, load_credentials
from .core import EasyBinance
from .errors import EasyBinanceError
from .products import APIS, PRODUCTS, ProductSpec, get_product_spec, normalize_api_kind

__all__ = [
    "APIS",
    "PRODUCTS",
    "EasyBinance",
    "EasyBinanceConfig",
    "EasyBinanceError",
    "LoadedCredentials",
    "ProductSpec",
    "get_product_spec",
    "load_credentials",
    "normalize_api_kind",
]

__version__ = "0.1.0"
