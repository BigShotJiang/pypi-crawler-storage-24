# fxpyD365api

A modern Python wrapper for interacting with Microsoft Dynamics 365 Web API (both Customer Engagement and Finance & Operations).

Includes built-in support for token authentication, paging, CRUD operations, automatic retries, type hints, and both synchronous and asynchronous usage.

---

## ✨ Features

- ✅ **Sync & Async** - Choose between blocking or async operations
- ✅ **Type Hints** - Full type annotations for IDE support
- ✅ **OAuth2** - Automatic token management and refresh
- ✅ **Retries** - Built-in exponential backoff for reliability
- ✅ **Paging** - Simple pagination across large result sets
- ✅ **Error Context** - Structured errors with request/response details
- ✅ **Context Managers** - Proper resource cleanup with `async with`
- ✅ **Configuration** - Centralized config with env var support

---

## 📦 Installation

```bash
pip install fxpyD365api
```

---

## 🔧 Quick Start

### Configuration

Set environment variables:
```bash
export D365_ORG_URL=https://yourorg.crm4.dynamics.com
export D365_TENANT=your-tenant-id
export D365_CLIENT_ID=your-client-id
export D365_CLIENT_SECRET=your-client-secret
```

Or pass directly:
```python
api = get_wrapper(
    'accounts',
    org_url='https://yourorg.crm4.dynamics.com',
    tenant='tenant-id',
    client_id='client-id',
    client_secret='secret'
)
```

### Synchronous (Blocking)

```python
from fxpyD365api import get_wrapper

# Create wrapper
api = get_wrapper(entity_type='accounts')

# Read
accounts = api.get_top(qty=10, select='name,accountid')
account = api.retrieve(entity_id='account-id')

# Create
created = api.create({'name': 'Acme Corp', 'telephone1': '555-1234'})

# Update
updated = api.update('account-id', {'name': 'Updated Name'})

# Delete
status = api.delete('account-id')

# Pagination
page1 = api.get_page(page=1)
page2 = api.get_next_page()
page1 = api.get_previous_page()

# Cleanup
api.close()
```

### Asynchronous (Non-blocking)

```python
import asyncio
from fxpyD365api import get_wrapper

async def main():
    # Use context manager for automatic cleanup
    async with get_wrapper('contacts', async_mode=True) as api:
        contacts = await api.get_top(qty=10)
        contact = await api.retrieve('contact-id')
        created = await api.create({'firstname': 'John', 'lastname': 'Doe'})
        await api.update('contact-id', {'firstname': 'Jane'})
        await api.delete('contact-id')

asyncio.run(main())
```

---

## 🎛 Advanced Usage

### Configuration Object

```python
from fxpyD365api import Config, get_wrapper

config = Config(
    org_url='https://yourorg.crm4.dynamics.com',
    tenant='tenant-id',
    client_id='client-id',
    client_secret='secret',
    timeout=30,           # Request timeout
    page_size=500,        # Default pagination size
    impersonate_user='user-id'  # Impersonate a user
)

# Reuse config for multiple wrappers
accounts = get_wrapper('accounts', config=config)
contacts = get_wrapper('contacts', config=config)
```

### Customer Engagement (CE) vs Finance & Operations (FO)

The library supports both D365 deployment types via the `api_url_prefix` parameter:

```python
# Customer Engagement (CE) - default
api = get_wrapper('accounts', org_url='https://org.crm4.dynamics.com', ...)
# Uses: /api/data/v9.0 (default)

# Finance & Operations (FO)
api = get_wrapper(
    'accounts',
    org_url='https://org.dynamics.com',
    api_url_prefix='/data',  # FO API
    ...
)

# Or with Config
config_fo = Config(
    org_url='https://org.dynamics.com',
    api_url_prefix='/data',  # Use '/data' for FO
    ...
)
api = get_wrapper('accounts', config=config_fo)
```

### OData Filtering & Selection

```python
accounts = api.get_top(
    qty=10,
    select='name,accountid',
    request_filter='statecode eq 0',
    order_by='name asc'
)
```

### Error Handling

```python
from fxpyD365api import D365ApiError, D365ApiWrapperError

try:
    account = api.retrieve('invalid-id')
except D365ApiError as e:
    print(f"API Error: {e.error_message}")
    print(f"Status: {e.status_code}")
    print(f"URL: {e.url}")
except D365ApiWrapperError as e:
    print(f"Wrapper Error: {e.message}")
```

---

## 📚 API Methods

All wrappers (sync and async) implement:

| Method | Purpose | Returns |
|--------|---------|---------|
| `get_page(page, ...)` | Get paginated results | Dict with entities |
| `get_next_page()` | Get next page | Dict with entities |
| `get_previous_page()` | Get previous page | Dict with entities |
| `get_top(qty, ...)` | Get top N records | Dict with entities |
| `create(data, ...)` | Create entity | Created entity dict |
| `retrieve(id, ...)` | Get single entity | Entity dict |
| `update(id, data, ...)` | Update entity | Updated entity dict |
| `delete(id)` | Delete entity | HTTP status code |
| `close()` | Clean up resources | None |

**Async methods:** All methods are `async` - use `await`

---

## 🔒 Authentication Flow

Uses OAuth2 Client Credentials flow via `msal`:
- Token automatically acquired on first use
- Token cached and reused
- Automatically refreshed 5 minutes before expiry
- Configurable refresh buffer via `token_refresh_buffer` parameter

---

## 🚀 What's New in v2.3

### From v2.2
- ✨ **Type hints** - Full Python 3.8+ type annotations
- ✨ **Config dataclass** - Centralized configuration
- ✨ **Structured errors** - Rich error context with method, URL, status
- ✨ **Context managers** - `async with` support for proper cleanup
- ✨ **Better logging** - Debug-level logging throughout

### Backward Compatible
- All v2.2 code still works
- `GenericWrapper` still available (with deprecation warning)
- Same environment variables
- Same method signatures

See [MIGRATION_GUIDE.md](MIGRATION_GUIDE.md) for upgrading.

---

## 📖 Documentation

- [MIGRATION_GUIDE.md](MIGRATION_GUIDE.md) - Upgrading from v2.2
- [ARCHITECTURE.md](ARCHITECTURE.md) - Internal design overview

---

## 🔗 Requirements

- Python 3.8+
- requests >= 2.20.0
- aiohttp >= 3.0.0
- msal >= 1.21.0
- urllib3 >= 1.26.0, < 3.0.0

---

## 📄 License

BSD License

---

## 🌐 Repository

[https://github.com/flexitdev/fxpyD365api](https://github.com/flexitdev/fxpyD365api)
