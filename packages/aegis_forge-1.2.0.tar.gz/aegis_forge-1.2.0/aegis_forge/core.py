import json
import os
import time
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Dict, Any, Callable, List
from openai import OpenAI

# Attempt to import the cloud database connector.
# If cloud_db.py is missing, ForgeDatabase will be None – cloud mode will then raise an error.
try:
    from cloud_db import ForgeDatabase
except ImportError:
    ForgeDatabase = None

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class UniversalAegisForge(ABC):
    """
    A base class for building execution-guided synthesis pipelines.
    
    It manages:
    - LLM calls (with retries and error handling)
    - A critic loop that validates outputs and feeds errors back to the LLM
    - Saving successful/failed trajectories (locally and/or to a cloud database)
    
    Subclasses must implement the abstract methods to define:
    - How prompts are generated (or pulled from a cloud DB)
    - How to parse the LLM's raw response
    - How to validate the parsed output (the "critic")
    """

    def __init__(
        self,
        system_prompt: str,
        output_file: Optional[str] = None,
        max_retries: Optional[int] = None,
        base_url: Optional[str] = None,
        generation_kwargs: Optional[Dict[str, Any]] = None,
        llm_call: Optional[Callable[[List[Dict[str, str]], Dict[str, Any]], str]] = None,
        trajectory_formatter: Optional[Callable[[List[Dict[str, str]]], Dict]] = None,
        db_config: Optional[Dict[str, str]] = None
    ):
        """
        Args:
            system_prompt: The system instruction for the LLM.
            output_file: (Optional) Path to a local JSONL file where trajectories will be appended.
            max_retries: How many attempts per task. Overrides AEGIS_MAX_RETRIES env var.
            base_url: Custom OpenAI-compatible endpoint (e.g., for local models).
            generation_kwargs: Extra LLM parameters (temperature, max_tokens, etc.).
            llm_call: A custom function that takes messages and kwargs and returns a string.
                      If None, a default OpenAI client is used.
            trajectory_formatter: A function that converts a list of conversation messages
                                  into a dictionary suitable for saving. If None, a default
                                  format (ShareGPT style) is used.
            db_config: Dictionary with keys 'read_table' and 'write_table' for cloud DB.
                       If provided, cloud mode becomes available.
        """
        self.system_prompt = system_prompt
        self.output_file = Path(output_file) if output_file else None

        # --- Cloud database setup ---
        self.db_config = db_config
        self.db = None
        if self.db_config:
            if ForgeDatabase is None:
                raise ImportError("cloud_db.py module not found. Cannot initialize cloud mode.")
            logger.info("📡 Cloud Configuration detected. Initializing ForgeDatabase...")
            self.db = ForgeDatabase()
            if "read_table" not in self.db_config or "write_table" not in self.db_config:
                raise ValueError("db_config must contain 'read_table' and 'write_table' keys.")

        # --- Retry settings (can be overridden by environment variables) ---
        self.max_retries = max_retries if max_retries is not None else int(os.getenv("AEGIS_MAX_RETRIES", "4"))
        self.success_count = 0  # Counter for successful trajectories in this run

        # --- LLM generation parameters ---
        default_temp = float(os.getenv("AEGIS_TEMPERATURE", "0.2"))
        self.generation_kwargs = generation_kwargs or {}
        if "temperature" not in self.generation_kwargs:
            self.generation_kwargs["temperature"] = default_temp

        self.retry_delay = float(os.getenv("AEGIS_RETRY_DELAY", "2"))

        # --- Trajectory formatting ---
        self.trajectory_formatter = trajectory_formatter or self._default_trajectory

        # --- LLM call setup ---
        if llm_call is not None:
            self.llm_call = llm_call
        else:
            # Default: use OpenAI client with environment variables
            self.client = OpenAI(
                api_key=os.getenv("OPENAI_API_KEY", "dummy"),
                base_url=base_url
            )
            self.model = os.getenv("MODEL_NAME", "gpt-3.5-turbo")
            self.llm_call = self._openai_call

    def _openai_call(self, messages: List[Dict[str, str]], kwargs: Dict[str, Any]) -> str:
        """Default LLM call using OpenAI's Python client."""
        call_kwargs = {
            "model": self.model,
            "messages": messages,
            **kwargs
        }
        response = self.client.chat.completions.create(**call_kwargs)
        return response.choices[0].message.content

    # ----------------------------------------------------------------------
    # Abstract methods – must be implemented by subclasses
    # ----------------------------------------------------------------------

    @abstractmethod
    def generate_prompt(self) -> str:
        """
        Generate a single prompt/task. Used only in local mode.
        Example: randomly sample a math problem, a coding task, etc.
        """
        pass

    @abstractmethod
    def parse_output(self, raw_llm_response: str) -> str:
        """
        Extract the actual code/answer from the LLM's raw text.
        This might involve stripping markdown, extracting a JSON block, etc.
        """
        pass

    @abstractmethod
    def execute_critic(self, parsed_output: str) -> dict:
        """
        Validate the parsed output.
        Must return a dict with at least:
            - "success": bool (True if output is correct)
            - "feedback": str (error message or explanation, used in retry loop)
        """
        pass

    # ----------------------------------------------------------------------
    # Core synthesis loop
    # ----------------------------------------------------------------------

    def run_synthesis_loop(self, user_prompt: str, task_id: Optional[str] = None) -> bool:
        """
        Execute the retry loop for a single prompt.
        
        Args:
            user_prompt: The task description to send to the LLM.
            task_id: Optional identifier from the cloud DB (used for status updates).
        
        Returns:
            True if a valid output was produced within retry limit, False otherwise.
        """
        # Initial conversation messages
        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": user_prompt}
        ]

        final_error = "Unknown Error"
        last_exception = None  # Track the last LLM call exception

        for iteration in range(1, self.max_retries + 1):
            try:
                raw_output = self.llm_call(messages, self.generation_kwargs)
                last_exception = None  # Reset on success
            except Exception as e:
                logger.warning(f"⚠️ LLM call failed on iteration {iteration}: {e}")
                last_exception = e
                time.sleep(self.retry_delay)
                continue  # Try again

            # Parse and validate
            parsed_code = self.parse_output(raw_output)
            critic_result = self.execute_critic(parsed_code)

            if critic_result.get("success", False):
                logger.info(f"✅ SUCCESS on iteration {iteration}.")
                trajectory = messages + [{"role": "assistant", "content": raw_output}]
                self._save_trajectory(trajectory, task_id, is_success=True)
                self.success_count += 1
                return True
            else:
                logger.warning(f"❌ FAILED on iteration {iteration}. Retrying...")
                final_error = critic_result.get('feedback', 'Unknown error')
                # Append the failed attempt and error feedback so the LLM can try to fix it
                messages.append({"role": "assistant", "content": raw_output})
                messages.append({
                    "role": "user",
                    "content": f"Execution failed with error:\n{final_error}\nFix the code."
                })

        # If we exit the loop, all retries were exhausted
        logger.error(f"💀 ABORTED after {self.max_retries} retries.")
        if last_exception:
            final_error = f"LLM Call failed repeatedly. Last exception: {str(last_exception)}"

        # Save the failed trajectory (useful for DPO or debugging)
        self._save_trajectory(messages, task_id, is_success=False, error_log=final_error)
        return False

    def _save_trajectory(self, trajectory_messages: list, task_id: Optional[str],
                         is_success: bool, error_log: str = None):
        """
        Save the conversation trajectory either to cloud DB, local file, or both.
        
        Args:
            trajectory_messages: Full list of messages (system, user, assistant turns).
            task_id: ID of the original task (for linking back in the DB).
            is_success: Whether the final output was correct.
            error_log: Optional error message (for failed trajectories).
        """
        record = self.trajectory_formatter(trajectory_messages)
        status = "success" if is_success else "failed"

        # --- Cloud save ---
        if self.db and self.db_config:
            write_table = self.db_config["write_table"]
            read_table = self.db_config["read_table"]

            db_payload = {
                "trajectory": record,
                "status": status,
                "prompt_id": task_id
            }
            if error_log:
                db_payload["error_log"] = error_log

            # Insert into the trajectories table
            self.db.insert_trajectory(write_table, db_payload)

            # Update the original task's status in the read table
            if task_id:
                self.db.update_task_status(read_table, task_id, status, error_log)

        # --- Local file save (always happens if output_file is set) ---
        if self.output_file:
            with open(self.output_file, "a") as f:
                f.write(json.dumps(record) + "\n")

    @staticmethod
    def _default_trajectory(messages):
        """
        Default formatter: converts messages to a list of dicts with 'from' and 'value'.
        This is the format expected by many fine‑tuning libraries (e.g., ShareGPT).
        """
        return {
            "conversations": [
                {
                    "from": "system" if m["role"] == "system"
                            else "human" if m["role"] == "user"
                            else "gpt",
                    "value": m["content"]
                }
                for m in messages
            ]
        }

    # ----------------------------------------------------------------------
    # High‑level orchestration
    # ----------------------------------------------------------------------

    def start_factory(self, batch_size: int = 10, run_mode: str = "local"):
        """
        Start processing a batch of tasks.
        
        Args:
            batch_size: Number of tasks to process (if local) or maximum to fetch (if cloud).
            run_mode: Either "local" (uses generate_prompt()) or "cloud" (pulls from DB).
        """
        logger.info(f"🚀 Igniting Forge in {run_mode.upper()} mode.")

        if run_mode == "cloud":
            if not self.db:
                raise ValueError("Cannot run in cloud mode without passing db_config during initialization.")

            read_table = self.db_config["read_table"]
            tasks = self.db.fetch_pending_tasks(read_table, limit=batch_size)

            if not tasks:
                logger.info("📭 No pending tasks found in the database. Exiting.")
                return

            logger.info(f"📥 Pulled {len(tasks)} tasks from cloud.")

            for task in tasks:
                task_id = task.get("id")
                # Assume the table has a column named 'prompt' with the task text
                user_prompt = task.get("prompt", "MISSING PROMPT")

                logger.info(f"\n--- Processing Cloud Task: {task_id} ---")

                # Mark as processing so other workers don't pick it up
                self.db.update_task_status(read_table, task_id, "processing")

                # Wrap in try/except to catch any unexpected errors and mark as failed
                try:
                    self.run_synthesis_loop(user_prompt, task_id=task_id)
                except Exception as e:
                    logger.error(f"⚠️ Unhandled exception for task {task_id}: {e}")
                    self.db.update_task_status(read_table, task_id, "failed", str(e))

        else:  # local mode
            for i in range(batch_size):
                logger.info(f"\n--- Task {i+1}/{batch_size} ---")
                prompt = self.generate_prompt()
                self.run_synthesis_loop(prompt)

        logger.info(f"\n🏁 Complete. Yield: {self.success_count} Gold Trajectories.")