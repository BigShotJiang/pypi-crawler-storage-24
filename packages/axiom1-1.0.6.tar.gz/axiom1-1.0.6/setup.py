from setuptools import setup, find_packages

setup(
    name="axiom1",
    version="1.0.6",
    description="AXIOM-1: EGen Core LoopLLM",
    author="ErebusTN",
    packages=find_packages(),
    install_requires=[
        "torch>=2.0.0",
        "transformers",
        "pyyaml",
    ],
    python_requires=">=3.10",
)
