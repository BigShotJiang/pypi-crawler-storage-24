# src/paperclip_sdk/client.py

import logging
import os
import random
import time
import uuid
from typing import Any, Protocol

import httpx

from paperclip_sdk._exceptions import (PaperclipClientError,
                                       PaperclipInvalidResponseError,
                                       PaperclipTransportError)
from paperclip_sdk._shared import (API_KEY_ENV_VAR, DEFAULT_BASE_URL,
                                   RPC_RUN_PATH, RetryPolicy, build_payload,
                                   build_request_headers, compute_retry_delay,
                                   configure_default_client_debug_logger,
                                   extract_error_message,
                                   extract_result_from_response,
                                   extract_suppressed_error,
                                   map_http_status_error, parse_response_json,
                                   should_retry_connect_error,
                                   should_retry_response, to_ms)

_DEBUG_HANDLER_NAME = "paperclip-sdk-client-debug-handler"

logger = logging.getLogger(__name__)


class HttpClientProtocol(Protocol):
    def post(
        self,
        url: str,
        *,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        ...

    def close(self) -> None:
        ...


class RemoteFunction:
    def __init__(self, client: "PaperclipClient", name: str) -> None:
        self._client = client
        self.name = name

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self._client.call(self.name, *args, **kwargs)


class PaperclipClient:
    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
        http_client: HttpClientProtocol | None = None,
        retry_policy: RetryPolicy | None = None,
        client_logger: logging.Logger | None = None,
        log_server_meta: bool = False,
        debug: bool = False,
        suppress_errors: bool = True,
    ) -> None:
        self._owns_http_client = http_client is None
        self._retry_policy = retry_policy or RetryPolicy()
        self._retry_policy.validate()
        self._random = random.Random()
        self._sleep = time.sleep
        self._logger = client_logger or logger
        self._log_server_meta = log_server_meta
        self._suppress_errors = suppress_errors
        self.last_error: PaperclipClientError | None = None

        if debug:
            if client_logger is None:
                configure_default_client_debug_logger(
                    self._logger,
                    handler_name=_DEBUG_HANDLER_NAME,
                )
            else:
                self._logger.setLevel(logging.DEBUG)

        if http_client is not None:
            self._http_client = http_client
            return

        resolved_base_url = f"{(base_url or DEFAULT_BASE_URL).rstrip('/')}/"
        resolved_api_key = api_key if api_key is not None else os.getenv(API_KEY_ENV_VAR)

        headers = {"Content-Type": "application/json"}
        if resolved_api_key:
            headers["Authorization"] = f"Bearer {resolved_api_key}"

        self._http_client = httpx.Client(
            base_url=resolved_base_url,
            timeout=timeout,
            headers=headers,
        )

    def _post_rpc(
        self,
        payload: dict[str, Any],
        request_id: str,
    ) -> httpx.Response:
        return self._http_client.post(
            RPC_RUN_PATH,
            json=payload,
            headers=build_request_headers(request_id),
        )

    def _debug_log_server_meta(
        self,
        function_name: str,
        request_id: str,
        meta: Any,
    ) -> None:
        if not self._log_server_meta:
            return
        if not self._logger.isEnabledFor(logging.DEBUG):
            return
        if not isinstance(meta, dict):
            return

        self._logger.debug(
            "Paperclip RPC server meta function=%s request_id=%s server_request_id=%s handler_duration_ms=%s server_duration_ms=%s",
            function_name,
            request_id,
            meta.get("request_id"),
            meta.get("handler_duration_ms"),
            meta.get("server_duration_ms"),
        )

    def _suppress_error(
        self,
        error: PaperclipClientError,
        *,
        function_name: str,
        request_id: str,
        attempt: int,
        total_duration: float,
    ) -> None:
        self.last_error = error
        self._logger.warning(
            "Paperclip RPC error suppressed function=%s request_id=%s attempt=%d/%d total_duration_ms=%.2f error_type=%s error=%s",
            function_name,
            request_id,
            attempt,
            self._retry_policy.max_attempts,
            to_ms(total_duration),
            error.__class__.__name__,
            str(error),
        )

    def call(self, function_name: str, *args: Any, **kwargs: Any) -> Any:
        self.last_error = None

        request_id = uuid.uuid4().hex
        max_attempts = self._retry_policy.max_attempts
        started_at = time.perf_counter()
        payload = build_payload(
            function_name,
            request_id,
            args,
            kwargs,
            suppress_errors=self._suppress_errors,
        )

        self._logger.debug(
            "Paperclip RPC call started function=%s request_id=%s max_attempts=%d base_url=%s",
            function_name,
            request_id,
            max_attempts,
            getattr(self._http_client, "base_url", "custom-http-client"),
        )

        for attempt in range(1, max_attempts + 1):
            attempt_started_at = time.perf_counter()

            self._logger.debug(
                "Paperclip RPC attempt started function=%s request_id=%s attempt=%d/%d args_count=%d kwargs_keys=%s",
                function_name,
                request_id,
                attempt,
                max_attempts,
                len(args),
                sorted(kwargs.keys()),
            )

            try:
                response = self._post_rpc(payload, request_id)
                request_duration = time.perf_counter() - attempt_started_at

                self._logger.debug(
                    "Paperclip RPC response received function=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f",
                    function_name,
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    to_ms(request_duration),
                )

                response.raise_for_status()

                parse_started_at = time.perf_counter()
                data = parse_response_json(response)
                parse_duration = time.perf_counter() - parse_started_at

                self._debug_log_server_meta(
                    function_name=function_name,
                    request_id=request_id,
                    meta=data.get("meta"),
                )

                suppressed_error = extract_suppressed_error(
                    data,
                    function_name=function_name,
                )
                if suppressed_error is not None:
                    total_duration = time.perf_counter() - started_at
                    if self._suppress_errors:
                        self._suppress_error(
                            suppressed_error,
                            function_name=function_name,
                            request_id=request_id,
                            attempt=attempt,
                            total_duration=total_duration,
                        )
                        return None
                    self.last_error = suppressed_error
                    raise suppressed_error

                result = extract_result_from_response(
                    data,
                    function_name=function_name,
                )

                attempt_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at

                self._logger.debug(
                    "Paperclip RPC call succeeded function=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f parse_duration_ms=%.2f attempt_duration_ms=%.2f total_duration_ms=%.2f",  # NoQA
                    function_name,
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    to_ms(request_duration),
                    to_ms(parse_duration),
                    to_ms(attempt_duration),
                    to_ms(total_duration),
                )
                return result

            except PaperclipInvalidResponseError as exc:
                total_duration = time.perf_counter() - started_at
                if self._suppress_errors:
                    self._suppress_error(
                        exc,
                        function_name=function_name,
                        request_id=request_id,
                        attempt=attempt,
                        total_duration=total_duration,
                    )
                    return None

                self.last_error = exc
                self._logger.error(
                    "Paperclip RPC invalid response function=%s request_id=%s attempt=%d/%d total_duration_ms=%.2f",
                    function_name,
                    request_id,
                    attempt,
                    max_attempts,
                    to_ms(total_duration),
                )
                raise

            except httpx.HTTPStatusError as exc:
                response = exc.response
                request_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at
                error_message = extract_error_message(response)

                if not should_retry_response(
                    response.status_code,
                    attempt=attempt,
                    retry_policy=self._retry_policy,
                ):
                    mapped_error = map_http_status_error(
                        status_code=response.status_code,
                        message=error_message,
                    )

                    if self._suppress_errors:
                        self._suppress_error(
                            mapped_error,
                            function_name=function_name,
                            request_id=request_id,
                            attempt=attempt,
                            total_duration=total_duration,
                        )
                        return None

                    self.last_error = mapped_error
                    self._logger.error(
                        "Paperclip RPC HTTP failure function=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f total_duration_ms=%.2f detail=%s",
                        function_name,
                        request_id,
                        attempt,
                        max_attempts,
                        response.status_code,
                        to_ms(request_duration),
                        to_ms(total_duration),
                        error_message,
                    )
                    raise mapped_error from exc

                retry_delay = compute_retry_delay(
                    attempt,
                    retry_policy=self._retry_policy,
                    random_source=self._random,
                    response=response,
                )
                self._logger.warning(
                    "Paperclip RPC retry scheduled function=%s request_id=%s attempt=%d/%d status_code=%d request_duration_ms=%.2f total_duration_ms=%.2f retry_delay_ms=%.2f detail=%s",
                    function_name,
                    request_id,
                    attempt,
                    max_attempts,
                    response.status_code,
                    to_ms(request_duration),
                    to_ms(total_duration),
                    to_ms(retry_delay),
                    error_message,
                )
                if retry_delay > 0:
                    self._sleep(retry_delay)

            except (httpx.ConnectError, httpx.ConnectTimeout, httpx.PoolTimeout) as exc:
                request_duration = time.perf_counter() - attempt_started_at
                total_duration = time.perf_counter() - started_at

                if not should_retry_connect_error(
                    attempt=attempt,
                    retry_policy=self._retry_policy,
                ):
                    transport_error = PaperclipTransportError(str(exc))

                    if self._suppress_errors:
                        self._suppress_error(
                            transport_error,
                            function_name=function_name,
                            request_id=request_id,
                            attempt=attempt,
                            total_duration=total_duration,
                        )
                        return None

                    self.last_error = transport_error
                    self._logger.error(
                        "Paperclip RPC transport failure function=%s request_id=%s attempt=%d/%d error_type=%s request_duration_ms=%.2f total_duration_ms=%.2f error=%s",
                        function_name,
                        request_id,
                        attempt,
                        max_attempts,
                        exc.__class__.__name__,
                        to_ms(request_duration),
                        to_ms(total_duration),
                        str(exc),
                    )
                    raise transport_error from exc

                retry_delay = compute_retry_delay(
                    attempt,
                    retry_policy=self._retry_policy,
                    random_source=self._random,
                )
                self._logger.warning(
                    "Paperclip RPC transport retry scheduled function=%s request_id=%s attempt=%d/%d error_type=%s request_duration_ms=%.2f total_duration_ms=%.2f retry_delay_ms=%.2f error=%s",
                    function_name,
                    request_id,
                    attempt,
                    max_attempts,
                    exc.__class__.__name__,
                    to_ms(request_duration),
                    to_ms(total_duration),
                    to_ms(retry_delay),
                    str(exc),
                )
                if retry_delay > 0:
                    self._sleep(retry_delay)

            except httpx.RequestError as exc:
                total_duration = time.perf_counter() - started_at
                transport_error = PaperclipTransportError(str(exc))

                if self._suppress_errors:
                    self._suppress_error(
                        transport_error,
                        function_name=function_name,
                        request_id=request_id,
                        attempt=attempt,
                        total_duration=total_duration,
                    )
                    return None

                self.last_error = transport_error
                self._logger.error(
                    "Paperclip RPC non-retryable request failure function=%s request_id=%s attempt=%d/%d error_type=%s total_duration_ms=%.2f error=%s",
                    function_name,
                    request_id,
                    attempt,
                    max_attempts,
                    exc.__class__.__name__,
                    to_ms(total_duration),
                    str(exc),
                )
                raise transport_error from exc

            except PaperclipClientError as exc:
                total_duration = time.perf_counter() - started_at
                if self._suppress_errors:
                    self._suppress_error(
                        exc,
                        function_name=function_name,
                        request_id=request_id,
                        attempt=attempt,
                        total_duration=total_duration,
                    )
                    return None

                self.last_error = exc
                raise

        total_duration = time.perf_counter() - started_at
        error = PaperclipClientError(f"RPC call failed after retries: {function_name}")

        if self._suppress_errors:
            self._suppress_error(
                error,
                function_name=function_name,
                request_id=request_id,
                attempt=max_attempts,
                total_duration=total_duration,
            )
            return None

        self.last_error = error
        self._logger.error(
            "Paperclip RPC exhausted retries function=%s request_id=%s max_attempts=%d total_duration_ms=%.2f",
            function_name,
            request_id,
            max_attempts,
            to_ms(total_duration),
        )
        raise error

    def run(self, function_name: str, *args: Any, **kwargs: Any) -> Any:
        return self.call(function_name, *args, **kwargs)

    def function(self, name: str) -> RemoteFunction:
        return RemoteFunction(self, name)

    def close(self) -> None:
        if self._owns_http_client:
            self._http_client.close()

    def __enter__(self) -> "PaperclipClient":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()


__all__ = [
    "API_KEY_ENV_VAR",
    "DEFAULT_BASE_URL",
    "RPC_RUN_PATH",
    "RetryPolicy",
    "PaperclipClient",
    "PaperclipClientError",
    "RemoteFunction",
]
