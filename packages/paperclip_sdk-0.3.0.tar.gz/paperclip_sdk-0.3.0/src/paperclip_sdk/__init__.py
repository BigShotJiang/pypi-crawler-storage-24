# src/paperclip_sdk/__init__.py

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as package_version

from paperclip_sdk._exceptions import (PaperclipAuthenticationError,
                                       PaperclipClientError,
                                       PaperclipHTTPError,
                                       PaperclipInvalidResponseError,
                                       PaperclipNotFoundError,
                                       PaperclipPermissionError,
                                       PaperclipRateLimitError,
                                       PaperclipServerError,
                                       PaperclipTransportError)
from paperclip_sdk._shared import (API_KEY_ENV_VAR, DEFAULT_BASE_URL,
                                   RPC_RUN_PATH, RetryPolicy)
from paperclip_sdk.async_client import (AsyncPaperclipClient,
                                        AsyncRemoteFunction)
from paperclip_sdk.client import PaperclipClient, RemoteFunction

try:
    __version__ = package_version("paperclip-sdk")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "__version__",
    "API_KEY_ENV_VAR",
    "DEFAULT_BASE_URL",
    "RPC_RUN_PATH",
    "RetryPolicy",
    "PaperclipClient",
    "RemoteFunction",
    "AsyncPaperclipClient",
    "AsyncRemoteFunction",
    "PaperclipClientError",
    "PaperclipTransportError",
    "PaperclipHTTPError",
    "PaperclipAuthenticationError",
    "PaperclipPermissionError",
    "PaperclipNotFoundError",
    "PaperclipRateLimitError",
    "PaperclipServerError",
    "PaperclipInvalidResponseError",
]
