# src/paperclip_sdk/_exceptions.py

class PaperclipClientError(RuntimeError):
    pass


class PaperclipTransportError(PaperclipClientError):
    pass


class PaperclipHTTPError(PaperclipClientError):
    def __init__(self, message: str, *, status_code: int) -> None:
        if not message:
            message = f"HTTP {status_code}"
        super().__init__(message)
        self.status_code = status_code


class PaperclipAuthenticationError(PaperclipHTTPError):
    pass


class PaperclipPermissionError(PaperclipHTTPError):
    pass


class PaperclipNotFoundError(PaperclipHTTPError):
    pass


class PaperclipRateLimitError(PaperclipHTTPError):
    pass


class PaperclipServerError(PaperclipHTTPError):
    pass


class PaperclipInvalidResponseError(PaperclipClientError):
    pass


__all__ = [
    "PaperclipClientError",
    "PaperclipTransportError",
    "PaperclipHTTPError",
    "PaperclipAuthenticationError",
    "PaperclipPermissionError",
    "PaperclipNotFoundError",
    "PaperclipRateLimitError",
    "PaperclipServerError",
    "PaperclipInvalidResponseError",
]
