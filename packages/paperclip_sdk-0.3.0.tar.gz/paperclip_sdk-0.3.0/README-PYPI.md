# paperclip-sdk

Python SDK for calling remote Paperclip functions from scripts, workers, web apps, and async services.

Use it when you want to keep business logic, pricing rules, private workflows, or customer-specific functionality on the server while calling it from Python with a small client.

## Install

```bash
poetry add paperclip-sdk
```

or

```bash
pip install paperclip-sdk
```

## Configure authentication

```bash
export LEASEKEY_API_KEY="your-api-key"
```

## Quickstart

### Sync

```python
from paperclip_sdk import PaperclipClient

with PaperclipClient() as client:
    result = client.call("core.hello_world", name="Ada")
    print(result)
```

### Async

```python
import asyncio

from paperclip_sdk import AsyncPaperclipClient


async def main() -> None:
    async with AsyncPaperclipClient() as client:
        result = await client.call("core.hello_world", name="Ada")
        print(result)


asyncio.run(main())
```

## Real-world examples

The function names below are illustrative. Replace them with the functions your Paperclip server exposes.

### Keep pricing logic on the server

```python
from decimal import Decimal

from paperclip_sdk import PaperclipClient


def quote_total(customer_id: str, sku: str, quantity: int) -> Decimal:
    with PaperclipClient() as client:
        result = client.call(
            "pricing.compute_quote",
            customer_id=customer_id,
            sku=sku,
            quantity=quantity,
        )

    return Decimal(result["total"])
```

### Use it inside an async API

```python
from fastapi import FastAPI

from paperclip_sdk import AsyncPaperclipClient

app = FastAPI()


@app.post("/tickets/{ticket_id}/summarize")
async def summarize_ticket(ticket_id: str) -> dict:
    async with AsyncPaperclipClient() as client:
        return await client.call(
            "support.summarize_ticket",
            ticket_id=ticket_id,
        )
```

### Build a remote plugin system

```python
from paperclip_sdk import PaperclipClient

with PaperclipClient() as client:
    transform = client.function("plugins.transform_payload")
    result = transform(
        payload={
            "source": "stripe",
            "event": "invoice.paid",
        }
    )
    print(result)
```

### Run background enrichment jobs

```python
from paperclip_sdk import PaperclipClient


def enrich_contacts(emails: list[str]) -> list[dict]:
    rows: list[dict] = []

    with PaperclipClient() as client:
        enrich = client.function("crm.enrich_contact")

        for email in emails:
            rows.append(enrich(email=email))

    return rows
```

## Function handles

### Sync function handle

```python
from paperclip_sdk import PaperclipClient

with PaperclipClient() as client:
    hello_world = client.function("core.hello_world")
    print(hello_world("Ada"))
```

### Async function handle

```python
import asyncio

from paperclip_sdk import AsyncPaperclipClient


async def main() -> None:
    async with AsyncPaperclipClient() as client:
        hello_world = client.function("core.hello_world")
        print(await hello_world("Ada"))


asyncio.run(main())
```

## Notes

- The default base URL is `https://leasekey.org`, so passing `base_url` is optional.
- The SDK automatically sends `User-Agent: paperclip-sdk/<version>`.
- The SDK also sends `X-Leasekey-SDK-Version: <version>`.
- Built-in retry behavior covers retryable transport failures and these HTTP statuses: `408`, `425`, `429`, `502`, `503`, `504`.
