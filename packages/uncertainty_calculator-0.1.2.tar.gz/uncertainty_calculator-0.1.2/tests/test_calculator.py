"""Tests for calculator orchestration."""

from __future__ import annotations

from tests.conftest import RawCase
from tests.legacy_calculator import run_legacy_calculator
from uncertainty_calculator import Digits, Equation, UncertaintyCalculator, Variable


def _legacy_variables_from_dataclasses(variables: list[Variable]) -> list[tuple[str, str]]:
    """Convert numeric Variable inputs back to the legacy tuple shape for parity checks."""
    return [
        (f"{variable.name} = {variable.value} +- {variable.uncertainty}", variable.latex_name)
        for variable in variables
    ]


def test_calculator_output_matches_legacy(
    raw_case: RawCase,
    equation,
    variables,
    digits,
    last_unit,
    separate,
    insert,
    include_equation_number,
):
    """Refactored calculator should match float-normalized legacy rendering."""
    expected_output = run_legacy_calculator(
        equation=[equation.latex_name, equation.expression],
        variables=_legacy_variables_from_dataclasses(list(variables)),
        digits=digits,
        last_unit=last_unit,
        separate=separate,
        insert=insert,
        include_equation_number=include_equation_number,
    )

    calculator = UncertaintyCalculator(
        digits=digits,
        last_unit=last_unit,
        separate=separate,
        insert=insert,
        include_equation_number=include_equation_number,
    )
    actual_output = calculator.run(equation=equation, variables=variables)

    assert actual_output == expected_output


def test_run_can_be_called_multiple_times_with_new_inputs():
    """Calculator should not leak state between runs when inputs change."""
    digits = Digits(mu=2, sigma=2)
    calc = UncertaintyCalculator(
        digits=digits,
        last_unit=None,
        separate=False,
        insert=False,
        include_equation_number=False,
    )

    first_output = calc.run(
        equation=Equation(latex_name="y", expression="x"),
        variables=[Variable(name="x", value=1, uncertainty=0.1, latex_name="x")],
    )
    assert "\\sigma_{x}" in first_output

    second_output = calc.run(
        equation=Equation(latex_name="y", expression="m"),
        variables=[Variable(name="m", value=2, uncertainty=0.2, latex_name="m")],
    )

    assert "\\sigma_{m}" in second_output
    assert "\\sigma_{x}" not in second_output


def test_constructor_accepts_only_configuration_arguments():
    """Calculation inputs should be provided to run(), not the constructor."""
    calc = UncertaintyCalculator(
        digits=Digits(mu=2, sigma=2),
        last_unit=None,
        separate=False,
        insert=False,
        include_equation_number=False,
    )

    assert calc.digits == Digits(mu=2, sigma=2)


def test_variable_dataclass_input():
    """Calculator should accept dataclass inputs and return a string output."""
    equation_obj = Equation(latex_name=r"\zeta", expression=r"K*x")
    variables_obj = [
        Variable(name="K", value=2.0, uncertainty=0.1, latex_name="K"),
        Variable(name="x", value=3.0, uncertainty=0.2, latex_name="x"),
    ]
    digits = Digits(mu=2, sigma=2)

    calc_obj = UncertaintyCalculator(
        digits=digits,
        last_unit=None,
        separate=False,
        insert=False,
        include_equation_number=False,
    )

    assert isinstance(calc_obj.run(equation=equation_obj, variables=variables_obj), str)


def test_mixed_input_types():
    """Numeric values provided as float/int should be accepted."""
    equation = Equation(latex_name="y", expression="x")
    variables = [Variable(name="x", value=10.5, uncertainty=0.5, latex_name="x")]
    digits = Digits(mu=2, sigma=2)

    calc = UncertaintyCalculator(
        digits=digits,
        last_unit="",
        separate=False,
        insert=False,
        include_equation_number=False,
    )

    calc.run(equation=equation, variables=variables)
