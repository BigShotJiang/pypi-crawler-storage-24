from __future__ import annotations

from abc import abstractmethod
from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, NotRequired, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType


class MotionProperty(str, Enum):
    """Properties for motion sensors."""

    Detected = "detected"  # Whether motion is currently detected
    Detections = "detections"  # Array of detection results with bounding boxes
    Blocked = "blocked"  # When true, detection updates are suppressed


BASE_DETECTION_LABELS = ("motion", "person", "vehicle", "animal", "package", "face", "license_plate", "audio")

BaseDetectionLabel = Literal[
    "motion", "person", "vehicle", "animal", "package", "face", "license_plate", "audio"
]

DetectionLabel = BaseDetectionLabel | str


class BoundingBox(TypedDict):
    """Bounding box for a detection result. All coordinates are normalized to 0-1 (fraction of frame dimensions)."""

    x: float  # X coordinate of top-left corner (0-1)
    y: float  # Y coordinate of top-left corner (0-1)
    width: float  # Width as fraction of frame width (0-1)
    height: float  # Height as fraction of frame height (0-1)


class Detection(TypedDict):
    """A single detection result from any detection sensor."""

    label: DetectionLabel
    confidence: float
    box: BoundingBox
    sourcePluginId: NotRequired[str]  # ID of the plugin that produced this detection
    zone: NotRequired[str]  # Detection zone name, if within a user-defined zone


class MotionSensorProperties(TypedDict):
    detected: bool
    detections: list[Detection]
    blocked: bool


class MotionPropertyChangeData(TypedDict):
    """Emitted on MotionSensorLike.onPropertyChanged."""

    property: str  # MotionProperty value
    value: bool | list[Detection]


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class MotionSensorLike(SensorLike, Protocol):
    """Read-only proxy interface for a motion sensor."""

    @property
    def type(self) -> SensorType:
        return SensorType.Motion

    @overload
    def getPropertyValue(self, property: Literal[MotionProperty.Detected]) -> bool | None: ...
    @overload
    def getPropertyValue(self, property: Literal[MotionProperty.Detections]) -> list[Detection] | None: ...
    @overload
    def getPropertyValue(self, property: Literal[MotionProperty.Blocked]) -> bool | None: ...
    @overload
    def getPropertyValue(self, property: str) -> object | None: ...

    @property
    def onPropertyChanged(self) -> Observable[MotionPropertyChangeData]: ...


class MotionSensor(Sensor[MotionSensorProperties, TStorage, str], Generic[TStorage]):
    """Motion sensor that reports motion state and detection results."""

    _requires_frames = False

    def __init__(self, name: str = "Motion Sensor") -> None:
        super().__init__(name)
        self.props.detected = False
        self.props.detections = []
        self.props.blocked = False

    @property
    def type(self) -> SensorType:
        return SensorType.Motion

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    def detected(self) -> bool:
        return self.props.detected  # type: ignore[no-any-return]

    @detected.setter
    def detected(self, value: bool) -> None:
        if self.props.blocked:
            return
        self.props.detected = value

    @property
    def detections(self) -> list[Detection]:
        return self.props.detections  # type: ignore[no-any-return]

    @detections.setter
    def detections(self, value: list[Detection]) -> None:
        if self.props.blocked:
            return
        self.props.detections = value

    @property
    def blocked(self) -> bool:
        return self.props.blocked  # type: ignore[no-any-return]


class MotionResult(TypedDict):
    """Return type for MotionDetectorSensor.detectMotion()."""

    detected: bool
    detections: list[Detection]


class VideoFrameData(TypedDict):
    """Video frame data passed to detector sensors by the backend pipeline."""

    cameraId: NotRequired[str]
    data: bytes
    width: int
    height: int
    format: Literal[
        "nv12", "rgb", "rgba", "gray"
    ]  # Pixel format: rgb=3 bytes/pixel, gray=1 byte/pixel, nv12=YUV semi-planar
    timestamp: NotRequired[int]


class MotionDetectorSensor(MotionSensor[TStorage], Generic[TStorage]):
    """Motion detector that receives video frames from the backend pipeline. Extend this and implement detectMotion() to analyze frames for motion."""

    _requires_frames = True

    @abstractmethod
    async def detectMotion(self, frame: VideoFrameData) -> MotionResult:
        """Analyze a video frame for motion. Called by the backend at the configured interval."""
        ...
