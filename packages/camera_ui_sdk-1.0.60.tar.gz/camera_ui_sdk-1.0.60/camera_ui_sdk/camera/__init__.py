from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal, NotRequired, Protocol, TypeAlias, TypedDict, runtime_checkable

if TYPE_CHECKING:
    from PIL.Image import Image as PILImageType

    from ..observable import Observable
    from ..sensor.base import Sensor, SensorLike, SensorType
    from ..storage import DeviceStorage, JsonSchema
    from ..types import LoggerService

from ..sensor import BaseAudioLabel, BaseDetectionLabel, DetectionLabel
from ..sensor.motion import BoundingBox

CameraType = Literal["camera", "doorbell"]
"""
Camera device type.
- `camera`: Standard surveillance camera
- `doorbell`: Doorbell camera
"""

ZoneType = Literal["intersect", "contain"]
"""
Detection zone intersection type.
- `intersect`: Trigger when object touches the zone boundary
- `contain`: Trigger only when object is fully inside the zone
"""

ZoneFilter = Literal["include", "exclude"]
"""
Detection zone filter mode.
- `include`: Only consider detections inside this zone
- `exclude`: Only consider detections outside this zone
"""

CameraRole = Literal["high-resolution", "mid-resolution", "low-resolution", "snapshot"]
"""
Camera stream resolution role.
Used to identify different quality streams from the same camera.
"""

StreamingRole = Literal["high-resolution", "mid-resolution", "low-resolution"]
"""Streaming roles (excludes snapshot)."""

DecoderFormat = Literal["nv12"]
"""Internal decoder output format."""

ImageInputFormat = Literal["nv12", "rgb", "rgba", "gray"]
"""Supported image input formats for processing."""

ImageOutputFormat = Literal["rgb", "rgba", "gray"]
"""Supported image output formats after processing."""

CameraFrameWorkerDecoder = Literal["wasm", "rust"]
"""Frame worker decoder implementation."""

MotionResolution = Literal["low", "medium", "high"]
"""
Motion detection resolution setting.
Higher resolution = more accurate but slower.
"""

AudioCodec = Literal[
    "PCMU", "PCMA", "MPEG4-GENERIC", "opus", "G722", "G726", "MPA", "PCM", "FLAC", "ELD", "PCML", "L16"
]
"""Supported audio codecs (RTP/SDP format names)."""

AudioFFmpegCodec = Literal[
    "pcm_mulaw", "pcm_alaw", "aac", "libopus", "g722", "g726", "mp3", "pcm_s16be", "pcm_s16le", "flac"
]
"""FFmpeg audio codec names for transcoding."""

VideoCodec = Literal["H264", "H265", "VP8", "VP9", "AV1", "JPEG", "RAW"]
"""Supported video codecs (RTP/SDP format names)."""

VideoFFmpegCodec = Literal["h264", "hevc", "vp8", "vp9", "av1", "mjpeg", "rawvideo"]
"""FFmpeg video codec names for transcoding."""

RTSPAudioCodec = Literal["aac", "opus", "pcma"]
"""Audio codecs supported for RTSP streaming."""

ProbeAudioCodec = Literal["aac", "opus", "pcma"]
"""Audio codecs supported for stream probing."""

VideoStreamingMode = Literal["auto", "webrtc", "mse", "webrtc/tcp"]
"""
Video streaming mode for UI playback.
- `auto`: Automatically select best method
- `webrtc`: WebRTC with UDP (lowest latency)
- `webrtc/tcp`: WebRTC with TCP fallback
- `mse`: Media Source Extensions (browser native)
"""

CameraAspectRatio = Literal["16:9", "9:16", "8:3", "4:3", "auto"]
"""Camera aspect ratio for UI display."""

FrameType = Literal["stream", "motion"]
"""Frame type identifier for frame workers."""

Point = tuple[float, float]
"""Zone polygon coordinate as (x, y) tuple (0-100 percentage)."""


class FrameMetadata(TypedDict):
    """Decoded frame metadata from the video decoder."""

    format: DecoderFormat
    """Decoder format."""
    frameSize: int
    """Total frame data size in bytes."""
    width: int
    """Current frame width (may be scaled)."""
    height: int
    """Current frame height (may be scaled)."""
    origWidth: int
    """Original video width before scaling."""
    origHeight: int
    """Original video height before scaling."""


class ImageInformation(TypedDict):
    """Image dimension and format information."""

    width: int
    """Image width in pixels."""
    height: int
    """Image height in pixels."""
    channels: int
    """Number of color channels (1=gray, 3=RGB, 4=RGBA)."""
    format: ImageInputFormat
    """Pixel format."""


class ImageCrop(TypedDict):
    """Crop region for image processing."""

    top: int
    """Top offset in pixels."""
    left: int
    """Left offset in pixels."""
    width: int
    """Crop width in pixels."""
    height: int
    """Crop height in pixels."""


class ImageResize(TypedDict):
    """Resize dimensions for image processing."""

    width: int
    """Target width in pixels."""
    height: int
    """Target height in pixels."""


class ImageFormat(TypedDict):
    """Output format conversion option."""

    to: ImageOutputFormat
    """Target pixel format."""


class ImageOptions(TypedDict, total=False):
    """Combined image processing options."""

    format: ImageFormat
    """Output format conversion."""
    crop: ImageCrop
    """Crop region."""
    resize: ImageResize
    """Resize dimensions."""


class FrameImage(TypedDict):
    """Processed image with PIL Image instance."""

    image: PILImageType
    """PIL Image instance for further processing."""
    info: ImageInformation
    """Image information."""


class FrameBuffer(TypedDict):
    """Processed image as raw buffer."""

    image: bytes
    """Raw pixel data."""
    info: ImageInformation
    """Image information."""


class FrameData(TypedDict):
    """Raw frame data from decoder."""

    id: str
    """Unique frame identifier."""
    data: bytes
    """Raw frame pixel data."""
    timestamp: int
    """Frame capture timestamp."""
    metadata: FrameMetadata
    """Decoder metadata."""
    info: ImageInformation
    """Image information."""


class VideoFrame(Protocol):
    """
    Video frame with processing capabilities.
    Provides methods to convert raw decoder output to usable image formats.
    """

    @property
    def id(self) -> str:
        """Unique frame identifier."""
        ...

    @property
    def data(self) -> bytes:
        """Raw frame pixel data."""
        ...

    @property
    def metadata(self) -> FrameMetadata:
        """Decoder metadata."""
        ...

    @property
    def info(self) -> ImageInformation:
        """Image information."""
        ...

    @property
    def timestamp(self) -> int:
        """Frame capture timestamp."""
        ...

    @property
    def inputWidth(self) -> int:
        """Original video width."""
        ...

    @property
    def inputHeight(self) -> int:
        """Original video height."""
        ...

    @property
    def inputFormat(self) -> DecoderFormat:
        """Decoder output format."""
        ...

    async def toBuffer(self) -> FrameBuffer:
        """
        Convert frame to raw pixel buffer.

        Returns:
            Processed image buffer with metadata.
        """
        ...

    async def toImage(self) -> FrameImage:
        """
        Convert frame to PIL image instance.

        Returns:
            PIL image for further processing.
        """
        ...


class Go2RtcWSSource(TypedDict):
    """WebSocket streaming URLs from go2rtc."""

    webrtc: str
    """WebRTC signaling endpoint."""
    mse: str
    """MSE streaming endpoint."""


class Go2RtcRTSPSource(TypedDict):
    """RTSP streaming URLs from go2rtc."""

    base: str
    """Base RTSP URL."""
    default: str
    """Default stream (video + audio)."""
    muted: str
    """Video only (muted)."""
    audioOnly: str
    """Audio only (no video)."""
    aac: str
    """Stream with AAC audio URL."""
    opus: str
    """Stream with Opus audio URL."""
    pcma: str
    """Stream with PCMA audio URL."""
    onvif: str
    """ONVIF URL."""
    prebuffered: str
    """Prebuffered stream URL."""
    noGop: str
    """Stream URL with GOP cache disabled."""


class Go2RtcSnapshotSource(TypedDict):
    """Snapshot/image URLs from go2rtc."""

    mp4: str
    """MP4 single-frame video URL."""
    jpeg: str
    """JPEG snapshot URL."""
    mjpeg: str
    """MJPEG stream URL."""


class StreamUrls(TypedDict):
    """Collection of all streaming URLs for a camera source."""

    ws: Go2RtcWSSource
    """WebSocket URLs."""
    rtsp: Go2RtcRTSPSource
    """RTSP URLs."""
    snapshot: Go2RtcSnapshotSource
    """Snapshot URLs."""


class ProbeConfig(TypedDict, total=False):
    """Configuration for stream probing."""

    video: bool
    """Include video track info."""
    audio: bool | Literal["all"] | list[ProbeAudioCodec]
    """Include audio track info (true, 'all', or specific codecs)."""
    microphone: bool
    """Include microphone/backchannel info."""


class FMTPInfo(TypedDict):
    """Format parameters (fmtp) from SDP."""

    payload: int
    """RTP payload type number."""
    config: str
    """Codec-specific configuration string."""


class AudioCodecProperties(TypedDict):
    """Audio codec properties from stream probe."""

    sampleRate: int
    """Audio sample rate in Hz."""
    channels: int
    """Number of audio channels."""
    payloadType: int
    """RTP payload type."""
    fmtpInfo: NotRequired[FMTPInfo]
    """Optional format parameters."""


class VideoCodecProperties(TypedDict):
    """Video codec properties from stream probe."""

    clockRate: int
    """Video clock rate."""
    payloadType: int
    """RTP payload type."""
    fmtpInfo: NotRequired[FMTPInfo]
    """Optional format parameters."""


class AudioStreamInfo(TypedDict):
    """Audio stream information from probe."""

    codec: AudioCodec
    """Audio codec."""
    ffmpegCodec: AudioFFmpegCodec
    """FFmpeg codec name."""
    properties: AudioCodecProperties
    """Codec properties."""
    direction: Literal["sendonly", "recvonly", "sendrecv", "inactive"]
    """Stream direction."""


class VideoStreamInfo(TypedDict):
    """Video stream information from probe."""

    codec: VideoCodec
    """Video codec."""
    ffmpegCodec: VideoFFmpegCodec
    """FFmpeg codec name."""
    properties: VideoCodecProperties
    """Codec properties."""
    direction: Literal["sendonly", "recvonly", "sendrecv", "inactive"]
    """Stream direction."""


class ProbeStream(TypedDict):
    """Stream probe result containing SDP and track information."""

    sdp: str
    """Raw SDP string."""
    audio: list[AudioStreamInfo]
    """Available audio tracks."""
    video: list[VideoStreamInfo]
    """Available video tracks."""


class RTSPUrlOptions(TypedDict, total=False):
    """Options for generating RTSP URLs."""

    video: bool
    """Include video track."""
    audio: bool | RTSPAudioCodec | list[RTSPAudioCodec]
    """Include audio track(s)."""
    gop: bool
    """Request keyframe at start (GOP)."""
    prebuffer: bool
    """Use prebuffered stream."""
    audioSingleTrack: bool
    """Combine audio tracks into single track."""
    backchannel: bool
    """Enable backchannel (two-way audio)."""
    timeout: int
    """Connection timeout in ms."""


class IceServer(TypedDict):
    """WebRTC ICE server configuration."""

    urls: list[str]
    """STUN/TURN server URLs."""
    username: NotRequired[str]
    """Authentication username."""
    credential: NotRequired[str]
    """Authentication credential."""


class PluginLabels(TypedDict):
    """Plugin-provided detection labels."""

    sensorId: str
    """Sensor ID providing the labels."""
    sensorName: str
    """Sensor display name."""
    pluginId: str
    """Plugin ID."""
    sensorType: str
    """Sensor type (e.g. 'motion', 'audio')."""
    labels: list[str]
    """Available labels from this sensor."""


class AvailableLabels(TypedDict):
    """All available detection labels for a camera."""

    base: tuple[BaseDetectionLabel, ...]
    """Built-in base detection labels."""
    baseAudio: tuple[BaseAudioLabel, ...]
    """Built-in base audio labels."""
    plugins: list[PluginLabels]
    """Plugin-provided labels by sensor (detection + audio)."""
    all: list[str]
    """Combined list of all available detection labels."""
    allAudio: list[str]
    """Combined list of all available audio labels."""


class DetectionZone(TypedDict):
    """
    Detection zone configuration.
    Defines areas for detection filtering or privacy masking.
    """

    name: str
    """Zone display name."""
    points: list[Point]
    """Polygon points (0-100 percentage coordinates)."""
    type: ZoneType
    """Intersection detection type."""
    filter: ZoneFilter
    """Include/exclude filter mode."""
    labels: list[DetectionLabel]
    """Labels to filter (empty = all labels)."""
    isPrivacyMask: bool
    """Whether this is a privacy mask (blur/block area)."""
    color: str
    """Zone display color (hex)."""


class MotionDetectionSettings(TypedDict):
    """Motion detection settings."""

    resolution: MotionResolution
    """Detection resolution quality."""
    timeout: int
    """Motion dwell time in seconds."""


class ObjectDetectionSettings(TypedDict):
    """Object detection settings."""

    confidence: float
    """Minimum confidence threshold (0-1)."""


class AudioDetectionSettings(TypedDict):
    """Audio detection settings."""

    minDecibels: float
    """Minimum volume threshold in dBFS (-100 to 0). Audio below this level is skipped."""
    timeout: int
    """Audio dwell time in seconds."""


class SensorTriggerRef(TypedDict):
    """Stable reference to a sensor for cascade trigger configuration.
    Uses composite key (sensorType + sensorName + pluginId) instead of UUID
    so references survive plugin restarts."""

    sensorType: SensorType
    """Sensor type (e.g. 'contact', 'doorbell')."""
    sensorName: str
    """Sensor name (stable across restarts)."""
    pluginId: str
    """Plugin ID that provides this sensor."""


class CameraDetectionSettings(TypedDict):
    """Combined detection settings for a camera."""

    motion: MotionDetectionSettings
    """Motion detection settings."""
    object: ObjectDetectionSettings
    """Object detection settings."""
    audio: AudioDetectionSettings
    """Audio detection settings."""
    sensorTriggers: NotRequired[list[SensorTriggerRef]]
    """Sensors that also trigger the detection cascade (in addition to motion/audio)."""


DetectionEventState = Literal["active", "ended"]
"""Event lifecycle state."""

EventTriggerType = Literal[
    "motion", "audio", "contact", "doorbell", "switch", "light", "siren", "security_system"
]
"""Event trigger type."""

DetectionEventType = Literal["start", "update", "end"]
"""Detection event message type (lifecycle phase)."""


class EventDetection(TypedDict):
    """Aggregated object detection within a segment."""

    label: str
    """Detection label (e.g. "person", "car")."""
    score: float
    """Best confidence score."""
    maxCount: int
    """Maximum simultaneous count in a single frame."""
    box: NotRequired[BoundingBox]
    """Bounding box of the highest-confidence detection (normalized 0-1)."""
    thumbnail: NotRequired[bytes]
    """Best-selected JPEG thumbnail crop. Only present on 'end' events."""


class EventFace(TypedDict):
    """Recognized face identity within a segment."""

    label: str
    """Face identity label."""
    thumbnail: NotRequired[bytes]
    """Best-selected JPEG thumbnail crop. Only present on 'end' events."""


class EventPlate(TypedDict):
    """Recognized license plate within a segment."""

    label: str
    """License plate text."""
    thumbnail: NotRequired[bytes]
    """Best-selected JPEG thumbnail crop. Only present on 'end' events."""


class EventClassification(TypedDict):
    """Classifier result within a segment."""

    label: str
    """Classification label (e.g. bird species, vehicle type)."""
    thumbnail: NotRequired[bytes]
    """Best-selected JPEG thumbnail crop. Only present on 'end' events."""


class EventTrigger(TypedDict):
    """Event trigger (motion or audio)."""

    type: EventTriggerType
    """Trigger type."""
    label: NotRequired[str]
    """Audio label (e.g. "doorbell", "glass_break")."""
    score: NotRequired[float]
    """Best confidence score."""
    firstSeen: int
    """First detection time (Unix ms)."""
    lastSeen: int
    """Last detection time (Unix ms)."""


class EventSegment(TypedDict):
    """A contiguous object detection phase within an event."""

    firstSeen: int
    """Segment start time (Unix ms)."""
    lastSeen: int
    """Segment end time (Unix ms)."""
    thumbnail: NotRequired[bytes]
    """Best-selected JPEG scene thumbnail for this segment. Only present on 'end' events."""
    detections: list[EventDetection]
    """Object detections in this segment."""
    faces: list[EventFace]
    """Recognized face identities."""
    plates: list[EventPlate]
    """Recognized license plate texts."""
    classifications: list[EventClassification]
    """Classifier results (e.g. bird species)."""


class DetectionEvent(TypedDict):
    """Aggregated detection event with lifecycle (start -> update -> end)."""

    id: str
    """Unique event ID."""
    cameraId: str
    """Camera that produced this event."""
    state: DetectionEventState
    """Event lifecycle state."""
    startTime: int
    """Event start time (Unix ms)."""
    endTime: NotRequired[int]
    """Event end time (Unix ms, only when ended)."""
    lastUpdate: int
    """Last activity timestamp (Unix ms)."""
    types: list[str]
    """Detection types present in this event (for filtering)."""
    triggers: list[EventTrigger]
    """Event triggers (motion/audio)."""
    segments: list[EventSegment]
    """Detection segments (object detection phases)."""


class DetectionEventMessage(TypedDict):
    """Detection event message published via NATS."""

    type: DetectionEventType
    """Event lifecycle type."""
    data: DetectionEvent


class RecordingSegment(TypedDict):
    """A continuous recording time range."""

    startTime: int
    """Unix ms."""
    endTime: int
    """Unix ms."""


RecordingStatusType = Literal["recording", "stopped"]
"""Recording status type."""


class RecordingState(TypedDict):
    """Current recording status of a camera."""

    cameraId: str
    state: RecordingStatusType
    timestamp: int
    """Unix ms."""


class CameraStorageStats(TypedDict):
    """Storage usage for a single camera."""

    usedBytes: int
    segmentCount: int
    oldestDay: str
    newestDay: str
    daysCount: int
    bandwidthMBh: float
    recordingMode: str
    isRecording: bool


class StorageStats(TypedDict):
    """Overall storage and per-camera usage statistics."""

    diskTotalGB: float
    diskUsedGB: float
    diskFreeGB: float
    diskFreePercent: float
    nvrUsedGB: float
    nvrQuotaGB: float
    retentionDays: int
    cameras: dict[str, CameraStorageStats]


class GetEventsOptions(TypedDict, total=False):
    """Server-side filter options for get_events()."""

    types: list[str]
    """Filter events that have at least one matching detection type."""

    state: Literal["active", "ended"]
    """Filter by event lifecycle state."""

    search: str
    """Case-insensitive substring match across all detection labels."""

    hasDetections: bool
    """Only return events with detection types beyond just motion/audio."""


class EventThumbnails(TypedDict, total=False):
    """All thumbnails for a single event, grouped by category."""

    scene: bytes
    """Primary scene thumbnail (from first segment)."""

    detections: dict[str, bytes]
    """Detection thumbnails keyed by label."""

    faces: dict[str, bytes]
    """Face thumbnails keyed by name."""

    plates: dict[str, bytes]
    """License plate thumbnails keyed by plate text."""

    classifications: dict[str, bytes]
    """Classification thumbnails keyed by label."""


class NvrScrubFrame(TypedDict):
    """A single encoded frame within a fine-scrub response."""

    frame: bytes
    ts: int
    keyframe: bool


class NvrScrubResult(TypedDict):
    """Result of a scrub request — a single keyframe at a timestamp."""

    frame: NotRequired[bytes]
    """AVCC keyframe data (length-prefixed NALUs)."""
    description: NotRequired[bytes]
    """avcC/hvcC decoder configuration record."""
    ts: int
    """Actual keyframe timestamp (μs)."""
    videoCodec: str
    """Video codec name (e.g. 'H264', 'H265')."""
    noData: NotRequired[bool]
    """No recording at this timestamp."""
    codecString: NotRequired[str]
    """WebCodecs codec string (e.g. 'avc1.4d401e', 'hvc1.1.6.L120')."""
    frames: NotRequired[list[NvrScrubFrame]]
    """Fine scrub: keyframe + delta frames up to target timestamp."""


class NvrPreviewResult(TypedDict):
    """Result of a preview frames request — sampled keyframes for hover preview."""

    frames: list[NvrScrubFrame]
    videoCodec: str
    codecString: NotRequired[str]
    width: NotRequired[int]
    height: NotRequired[int]
    noData: NotRequired[bool]


NvrPlaybackMessageType = Literal["ready", "video", "audio", "noData", "position", "eof", "error"]
"""Playback message type."""


class NvrPlaybackMessage(TypedDict):
    """Message sent via callback during playback."""

    type: NvrPlaybackMessageType
    """Message type."""
    sessionId: NotRequired[str]
    """Session ID (set on 'ready')."""
    videoCodec: NotRequired[str]
    """Video codec (set on 'ready')."""
    audioCodec: NotRequired[str]
    """Audio codec (set on 'ready')."""
    codecString: NotRequired[str]
    """WebCodecs codec string (on 'ready')."""
    description: NotRequired[bytes]
    """avcC/hvcC decoder configuration record (on 'ready')."""
    frame: NotRequired[bytes]
    """AVCC video/audio frame data."""
    ts: NotRequired[int]
    """Frame timestamp (μs)."""
    keyframe: NotRequired[bool]
    """Video keyframe flag."""
    msg: NotRequired[str]
    """Error message."""


NvrPlaybackCommandType = Literal["pause", "resume", "seek", "speed"]
"""Playback command type."""


class NvrPlaybackCommand(TypedDict):
    """Command to control an active playback session."""

    cmd: NvrPlaybackCommandType
    """Command type."""
    tsUs: NotRequired[int]
    """Seek timestamp (μs)."""
    speed: NotRequired[float]
    """Playback speed."""
    """Full event data."""


class SnapshotSettings(TypedDict):
    """Snapshot settings for a camera."""

    autoRefresh: bool
    """Enable automatic snapshot refresh."""
    ttl: int
    """Cache TTL in seconds (how long a snapshot is valid)."""
    interval: int
    """Auto-refresh interval in seconds (min: 10, max: 60)."""


class CameraInformation(TypedDict, total=False):
    """Camera hardware/firmware information."""

    model: str
    """Camera model name."""
    manufacturer: str
    """Manufacturer name."""
    hardware: str
    """Hardware version/revision."""
    serialNumber: str
    """Device serial number."""
    firmwareVersion: str
    """Current firmware version."""
    supportUrl: str
    """Manufacturer support URL."""


class CameraFrameWorkerSettings(TypedDict):
    """Frame worker (decoder) settings."""

    fps: int
    """Target frames per second for detection."""


class CameraInput(TypedDict):
    """Camera video input/source with resolved URLs."""

    _id: str
    """Unique source ID."""
    name: str
    """Source display name."""
    role: CameraRole
    """Resolution role."""
    useForSnapshot: bool
    """Use this source for snapshots."""
    hotMode: bool
    """Keep connection always active."""
    preload: bool
    """Preload stream on startup."""
    prebuffer: bool
    """Enable stream prebuffering."""
    urls: StreamUrls
    """Generated streaming URLs."""
    childSourceId: NotRequired[str]
    """Child source ID (for snapshot fallback)."""


class CameraInputSettings(TypedDict):
    """Camera input settings (user configuration)."""

    _id: str
    """Unique source ID."""
    name: str
    """Source display name."""
    role: CameraRole
    """Resolution role."""
    useForSnapshot: bool
    """Use this source for snapshots."""
    hotMode: bool
    """Keep connection always active."""
    preload: bool
    """Preload stream on startup."""
    prebuffer: bool
    """Enable stream prebuffering."""
    urls: list[str]
    """User-provided stream URLs."""
    childSourceId: NotRequired[str]
    """Child source ID (for snapshot fallback)."""


class CameraConfigInputSettings(TypedDict):
    """Camera input settings for config."""

    name: str
    """Source display name."""
    role: CameraRole
    """Resolution role."""
    useForSnapshot: bool
    """Use this source for snapshots."""
    hotMode: bool
    """Keep connection always active."""
    preload: bool
    """Preload stream on startup."""
    prebuffer: bool
    """Enable stream prebuffering."""
    childSourceId: NotRequired[str]
    """Child source ID (for snapshot fallback)."""
    urls: NotRequired[list[str]]


class BaseCameraConfig(TypedDict):
    """Base camera configuration (shared fields)."""

    name: str
    """Camera display name."""
    nativeId: NotRequired[str]
    """Native device ID from plugin."""
    isCloud: NotRequired[bool]
    """Whether camera streams from cloud."""
    disabled: NotRequired[bool]
    """Disable this camera."""
    info: NotRequired[CameraInformation]
    """Camera hardware information."""


class CameraConfig(BaseCameraConfig):
    """Full camera configuration with sources."""

    sources: list[CameraConfigInputSettings]
    """Video input sources."""


class CameraConfigPartial(TypedDict, total=False):
    """Camera configuration subset for partial updates."""

    name: str
    """Camera display name."""
    nativeId: str
    """Native device ID from plugin."""
    isCloud: bool
    """Whether camera streams from cloud."""
    disabled: bool
    """Disable this camera."""
    info: CameraInformation
    """Camera hardware information."""
    sources: list[CameraConfigInputSettings]
    """Video input sources."""


class CameraUiSettings(TypedDict):
    """UI display settings for a camera."""

    streamingMode: VideoStreamingMode
    """Preferred streaming method."""
    streamingSource: StreamingRole | Literal["auto"]
    """Preferred stream quality."""
    aspectRatio: CameraAspectRatio
    """Display aspect ratio."""


class AssignedPlugin(TypedDict):
    """Plugin assignment info."""

    id: str
    """Plugin ID."""
    name: str
    """Plugin display name."""


class PluginAssignments(TypedDict, total=False):
    """
    Plugin assignments for camera sensors/features.
    Maps sensor types to their assigned plugin(s).
    """

    motion: AssignedPlugin
    """Motion detection plugin."""
    object: AssignedPlugin
    """Object detection plugin."""
    audio: AssignedPlugin
    """Audio detection plugin."""
    face: AssignedPlugin
    """Face detection plugin."""
    licensePlate: AssignedPlugin
    """License plate detection plugin."""
    ptz: AssignedPlugin
    """PTZ control plugin."""
    battery: AssignedPlugin
    """Battery info plugin."""
    cameraController: AssignedPlugin
    """Camera controller plugin."""
    light: list[AssignedPlugin]
    """Light control plugins."""
    siren: list[AssignedPlugin]
    """Siren control plugins."""
    contact: list[AssignedPlugin]
    """Contact sensor plugins."""
    doorbell: list[AssignedPlugin]
    """Doorbell trigger plugins."""
    hub: list[AssignedPlugin]
    """Hub/bridge plugins."""


class CameraPluginInfo(TypedDict):
    """Camera source plugin information."""

    id: str
    """Plugin ID."""
    name: str
    """Plugin display name."""


class BaseCamera(TypedDict):
    """Base camera data structure (stored in database)."""

    _id: str
    """Unique camera ID."""
    nativeId: str | None
    """Native device ID from plugin."""
    pluginInfo: CameraPluginInfo | None
    """Source plugin information."""
    name: str
    """Camera display name."""
    disabled: bool
    """Whether camera is disabled."""
    isCloud: bool
    """Whether camera streams from cloud."""
    info: CameraInformation
    """Camera hardware information."""
    type: CameraType
    """Camera type (camera/doorbell)."""
    snapshotSettings: SnapshotSettings
    """Snapshot settings."""
    detectionZones: list[DetectionZone]
    """Detection zone configurations."""
    detectionSettings: CameraDetectionSettings
    """Detection settings."""
    frameWorkerSettings: CameraFrameWorkerSettings
    """Frame worker settings."""
    interface: CameraUiSettings
    """UI display settings."""
    plugins: list[AssignedPlugin]
    """Installed plugins."""
    assignments: PluginAssignments
    """Sensor-to-plugin assignments."""


class Camera(BaseCamera):
    """Camera with resolved video sources."""

    sources: list[CameraInput]
    """Video input sources."""


CameraPublicProperties = Literal[
    "_id",
    "nativeId",
    "pluginInfo",
    "name",
    "disabled",
    "isCloud",
    "info",
    "type",
    "snapshotSettings",
    "detectionZones",
    "detectionSettings",
    "frameWorkerSettings",
    "interface",
    "recording",
    "plugins",
    "assignments",
    "sources",
]
"""Camera public property names for observation."""


class SensorEventData(TypedDict):
    """Emitted when a sensor is added or removed."""

    sensorId: str
    """Sensor ID."""
    sensorType: SensorType
    """Sensor type."""


class DetectionEventPayload(TypedDict):
    """Emitted for detection events (start/update/end)."""

    type: DetectionEventType
    """Event lifecycle type."""
    event: DetectionEvent
    """Full event data."""


class CameraPropertyObservableObject(TypedDict):
    """Camera property change event."""

    property: str
    """Property name that changed."""
    old_state: Any
    """Previous value."""
    new_state: Any
    """New value."""


@runtime_checkable
class CameraSource(Protocol):
    """Camera source with snapshot and probe capabilities."""

    _id: str
    """Unique source ID."""
    name: str
    """Source display name."""
    role: CameraRole
    """Resolution role."""
    useForSnapshot: bool
    """Use this source for snapshots."""
    hotMode: bool
    """Keep connection always active."""
    preload: bool
    """Preload stream on startup."""
    prebuffer: bool
    """Enable stream prebuffering."""
    urls: StreamUrls
    """Generated streaming URLs."""
    childSourceId: str | None
    """Child source ID (for snapshot fallback)."""

    async def snapshot(self, forceNew: bool = False) -> bytes | None:
        """
        Get camera snapshot image.

        Args:
            forceNew: Force fresh snapshot (ignore cache).

        Returns:
            JPEG image data or None if unavailable.
        """
        ...

    async def probeStream(
        self, probeConfig: ProbeConfig | None = None, refresh: bool = False
    ) -> ProbeStream | None:
        """
        Probe stream for codec and track information.

        Args:
            probeConfig: What to probe for.
            refresh: Force fresh probe (ignore cache).

        Returns:
            Stream information or None if unavailable.
        """
        ...


@runtime_checkable
class CameraDeviceSource(CameraSource, Protocol):
    """Camera source with full streaming capabilities."""

    def generateRTSPUrl(self, options: RTSPUrlOptions | None = None) -> str:
        """
        Generate RTSP URL with specified options.

        Args:
            options: URL generation options.

        Returns:
            RTSP URL string.
        """
        ...


@runtime_checkable
class CameraDevice(Protocol):
    """
    Main camera device interface.
    Provides access to camera streams, sensors, and services.
    """

    @property
    def id(self) -> str:
        """Unique camera ID."""
        ...

    @property
    def nativeId(self) -> str | None:
        """Native device ID from plugin."""
        ...

    @property
    def pluginInfo(self) -> CameraPluginInfo | None:
        """Source plugin information."""
        ...

    @property
    def disabled(self) -> bool:
        """Whether camera is disabled."""
        ...

    @property
    def name(self) -> str:
        """Camera display name."""
        ...

    @property
    def type(self) -> CameraType:
        """Camera type (camera/doorbell)."""
        ...

    @property
    def snapshotSettings(self) -> SnapshotSettings:
        """Snapshot settings."""
        ...

    @property
    def info(self) -> CameraInformation:
        """Camera hardware information."""
        ...

    @property
    def isCloud(self) -> bool:
        """Whether camera streams from cloud."""
        ...

    @property
    def detectionZones(self) -> list[DetectionZone]:
        """Detection zone configurations."""
        ...

    @property
    def detectionSettings(self) -> CameraDetectionSettings:
        """Detection settings."""
        ...

    @property
    def frameWorkerSettings(self) -> CameraFrameWorkerSettings:
        """Frame worker settings."""
        ...

    @property
    def sources(self) -> list[CameraDeviceSource]:
        """All video sources."""
        ...

    @property
    def streamSource(self) -> CameraDeviceSource:
        """Primary streaming source."""
        ...

    @property
    def highResolutionSource(self) -> CameraDeviceSource | None:
        """High resolution source (if available)."""
        ...

    @property
    def midResolutionSource(self) -> CameraDeviceSource | None:
        """Mid resolution source (if available)."""
        ...

    @property
    def lowResolutionSource(self) -> CameraDeviceSource | None:
        """Low resolution source (if available)."""
        ...

    @property
    def snapshotSource(self) -> CameraSource | None:
        """Snapshot source (if available)."""
        ...

    @property
    def connected(self) -> bool:
        """Whether camera is connected."""
        ...

    @property
    def frameWorkerConnected(self) -> bool:
        """Whether frame worker is connected."""
        ...

    @property
    def onConnected(self) -> Observable[bool]:
        """Observable for connection state changes."""
        ...

    @property
    def onFrameWorkerConnected(self) -> Observable[bool]:
        """Observable for frame worker state changes."""
        ...

    @property
    def logger(self) -> LoggerService:
        """Logger service for this camera."""
        ...

    async def connect(self) -> None:
        """Connect to the camera."""
        ...

    async def disconnect(self) -> None:
        """Disconnect from the camera."""
        ...

    def onPropertyChange(
        self, property: CameraPublicProperties | list[CameraPublicProperties]
    ) -> Observable[CameraPropertyObservableObject]:
        """
        Observe camera property changes.

        Args:
            property: Property name(s) to observe.

        Returns:
            Observable emitting old and new values.
        """
        ...

    def getSensors(self) -> list[SensorLike]:
        """Get all sensors attached to this camera."""
        ...

    def getSensor(self, sensorId: str) -> SensorLike | None:
        """Get sensor by ID."""
        ...

    def getSensorsByType(self, sensorType: SensorType) -> list[SensorLike]:
        """Get all sensors of a specific type."""
        ...

    def getMotionSensor(self) -> SensorLike | None:
        """Get motion detection sensor."""
        ...

    def getObjectSensor(self) -> SensorLike | None:
        """Get object detection sensor."""
        ...

    def getFaceSensor(self) -> SensorLike | None:
        """Get face detection sensor."""
        ...

    def getLicensePlateSensor(self) -> SensorLike | None:
        """Get license plate detection sensor."""
        ...

    def getAudioSensor(self) -> SensorLike | None:
        """Get audio detection sensor."""
        ...

    def getPTZControl(self) -> SensorLike | None:
        """Get PTZ control sensor."""
        ...

    async def addSensor(self, sensor: Sensor[Any, Any, Any]) -> None:
        """
        Add a sensor to this camera.

        Args:
            sensor: Sensor instance to add.
        """
        ...

    async def removeSensor(self, sensorId: str) -> None:
        """
        Remove a sensor from this camera.

        Args:
            sensorId: ID of sensor to remove.
        """
        ...

    @property
    def onSensorAdded(self) -> Observable[SensorEventData]:
        """Observable for sensor additions. Emits SensorEventData when a sensor from another plugin is added."""
        ...

    @property
    def onSensorRemoved(self) -> Observable[SensorEventData]:
        """Observable for sensor removals. Emits SensorEventData when a sensor from another plugin is removed."""
        ...

    @property
    def onDetectionEvent(self) -> Observable[DetectionEventPayload]:
        """Observable for detection events (start/update/end). Thumbnails in segments are only populated on 'end' events."""
        ...

    async def implement(self, impl: CameraImplementation) -> None:
        """
        Extend camera functionality with custom implementation.

        Args:
            impl: Object or class implementing camera interfaces
        """
        ...

    def createStorage(self, schemas: list[JsonSchema]) -> DeviceStorage:
        """
        Create storage for plugin-specific camera configuration.

        Args:
            schemas: Schema definitions for the storage

        Returns:
            Typed device storage instance
        """
        ...


@runtime_checkable
class StreamingInterface(Protocol):
    async def streamUrl(self, source_name: str) -> str:
        """
        Get the streaming URL for a source.

        Args:
            source_name: The name of the source

        Returns:
            The streaming URL (e.g., rtsp://, rtmp://, or custom protocol)
        """
        ...


@runtime_checkable
class SnapshotInterface(Protocol):
    async def snapshot(self, source_id: str, force_new: bool = False) -> bytes | None:
        """
        Get a snapshot image from the camera.

        Args:
            source_id: The source ID to get the snapshot from
            force_new: If True, bypass cache and get a fresh snapshot

        Returns:
            Image data as bytes, or None if unavailable
        """
        ...


CameraImplementation: TypeAlias = StreamingInterface | SnapshotInterface


@runtime_checkable
class NVRInterface(Protocol):
    """Interface for NVR plugins that persist and query detection events."""

    async def get_events(
        self, camera_id: str, start_ms: int, end_ms: int, opts: GetEventsOptions | None = None
    ) -> list[DetectionEvent]:
        """Query events WITHOUT thumbnails. Use get_event_thumbnails() for lazy loading."""
        ...

    async def get_event_thumbnails(self, camera_id: str, start_ms: int, event_id: str) -> EventThumbnails:
        """Get all thumbnails for a specific event.

        Args:
            camera_id: Camera ID.
            start_ms: The event's start_time in milliseconds (used to locate the DB).
            event_id: The event's UUID (DetectionEvent.id).
        """
        ...

    async def get_recording_segments(
        self, camera_id: str, start_ms: int, end_ms: int
    ) -> list[RecordingSegment]: ...
    async def get_recording_days(self, camera_id: str, year: int, month: int) -> list[str]: ...
    async def on_recording_state(self, camera_id: str, callback: Any) -> Any: ...
    async def get_managed_camera_ids(self) -> list[str]: ...
    async def get_storage_stats(self) -> StorageStats: ...
    async def nvr_scrub(
        self, camera_id: str, ts_us: int, fine: bool = False, source_role: str = ""
    ) -> NvrScrubResult: ...
    async def nvr_play(
        self, camera_id: str, ts_us: int, video_only: bool, source_role: str = "", callback: Any = None
    ) -> Any: ...
    async def nvr_playback_cmd(self, session_id: str, cmd: NvrPlaybackCommand) -> None: ...


__all__ = [
    # Types
    "CameraType",
    "ZoneType",
    "ZoneFilter",
    "CameraRole",
    "StreamingRole",
    "DecoderFormat",
    "ImageInputFormat",
    "ImageOutputFormat",
    "CameraFrameWorkerDecoder",
    "MotionResolution",
    "AudioCodec",
    "AudioFFmpegCodec",
    "VideoCodec",
    "VideoFFmpegCodec",
    "RTSPAudioCodec",
    "ProbeAudioCodec",
    "VideoStreamingMode",
    "CameraAspectRatio",
    "FrameType",
    "Point",
    # Frame/Image
    "FrameMetadata",
    "ImageInformation",
    "ImageCrop",
    "ImageResize",
    "ImageFormat",
    "ImageOptions",
    "FrameImage",
    "FrameBuffer",
    "FrameData",
    "VideoFrame",
    # Streaming URLs
    "Go2RtcWSSource",
    "Go2RtcRTSPSource",
    "Go2RtcSnapshotSource",
    "StreamUrls",
    # Probe
    "ProbeConfig",
    "FMTPInfo",
    "AudioCodecProperties",
    "VideoCodecProperties",
    "AudioStreamInfo",
    "VideoStreamInfo",
    "ProbeStream",
    "RTSPUrlOptions",
    "IceServer",
    # Detection Events
    "DetectionEventState",
    "EventTriggerType",
    "DetectionEventType",
    "EventDetection",
    "EventFace",
    "EventPlate",
    "EventClassification",
    "EventTrigger",
    "EventSegment",
    "DetectionEvent",
    "DetectionEventMessage",
    # Detection
    "PluginLabels",
    "AvailableLabels",
    "DetectionZone",
    "MotionDetectionSettings",
    "ObjectDetectionSettings",
    "AudioDetectionSettings",
    "SensorTriggerRef",
    "CameraDetectionSettings",
    "SnapshotSettings",
    # Config
    "CameraInformation",
    "CameraFrameWorkerSettings",
    "CameraInput",
    "CameraInputSettings",
    "CameraConfigInputSettings",
    "BaseCameraConfig",
    "CameraConfig",
    "CameraConfigPartial",
    "CameraUiSettings",
    # Plugin assignments
    "AssignedPlugin",
    "PluginAssignments",
    "CameraPluginInfo",
    # Camera
    "BaseCamera",
    "Camera",
    "CameraPublicProperties",
    "SensorEventData",
    "DetectionEventPayload",
    "CameraPropertyObservableObject",
    # Protocols
    "CameraSource",
    "CameraDeviceSource",
    "CameraDevice",
    # Camera Interfaces
    "StreamingInterface",
    "SnapshotInterface",
    "CameraImplementation",
    # NVR
    "RecordingSegment",
    "RecordingStatusType",
    "RecordingState",
    "CameraStorageStats",
    "StorageStats",
    "GetEventsOptions",
    "EventThumbnails",
    "NvrScrubFrame",
    "NvrScrubResult",
    "NvrPreviewResult",
    "NvrPlaybackMessageType",
    "NvrPlaybackMessage",
    "NvrPlaybackCommandType",
    "NvrPlaybackCommand",
    "NVRInterface",
]
