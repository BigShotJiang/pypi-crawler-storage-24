"""Text fixtures for Nublado client tests."""

from collections.abc import AsyncGenerator
from pathlib import Path

import pytest
import pytest_asyncio
import respx
import structlog
from rubin.gafaelfawr import (
    GafaelfawrUserInfo,
    MockGafaelfawr,
    register_mock_gafaelfawr,
)
from rubin.repertoire import (
    Discovery,
    DiscoveryClient,
    register_mock_discovery,
)
from safir.logging import LogLevel, Profile, configure_logging
from safir.testing.data import Data
from structlog.stdlib import BoundLogger

from rubin.nublado.client import (
    MockJupyter,
    NubladoClient,
    register_mock_jupyter,
)


def pytest_addoption(parser: pytest.Parser) -> None:
    parser.addoption(
        "--update-test-data",
        action="store_true",
        default=False,
        help="Overwrite expected test output with current results",
    )


@pytest.fixture
def client(
    logger: BoundLogger,
    username: str,
    token: str,
    mock_jupyter: MockJupyter,
) -> NubladoClient:
    return NubladoClient(username, token, logger=logger)


@pytest.fixture
def data(request: pytest.FixtureRequest) -> Data:
    update = request.config.getoption("--update-test-data")
    return Data(Path(__file__).parent / "data", update_test_data=update)


@pytest.fixture
def logger() -> BoundLogger:
    configure_logging(
        name="nublado", profile=Profile.development, log_level=LogLevel.DEBUG
    )
    return structlog.get_logger("nublado")


@pytest.fixture(params=["single", "subdomain"])
def mock_discovery(
    *,
    data: Data,
    respx_mock: respx.Router,
    monkeypatch: pytest.MonkeyPatch,
    request: pytest.FixtureRequest,
) -> Discovery:
    monkeypatch.setenv("REPERTOIRE_BASE_URL", "https://example.com/repertoire")
    path = data.path(f"discovery/{request.param}.json")
    return register_mock_discovery(respx_mock, path)


@pytest_asyncio.fixture
async def mock_gafaelfawr(
    mock_discovery: Discovery, respx_mock: respx.Router
) -> MockGafaelfawr:
    return await register_mock_gafaelfawr(respx_mock)


@pytest_asyncio.fixture
async def mock_jupyter(
    respx_mock: respx.Router, mock_discovery: Discovery
) -> AsyncGenerator[MockJupyter]:
    """Mock out JupyterHub and Jupyter labs.

    Sets subdomain mode in the mock based on whether the hostname of the
    Nublado URL in service discovery starts with ``nb.``. This allows
    switching to subdomain mode by parameterizing the ``mock_discovery``
    fixture.
    """
    discovery_client = DiscoveryClient()
    base_url = await discovery_client.url_for_ui("nublado")
    async with register_mock_jupyter(
        respx_mock, use_subdomains=bool(base_url and "//nb." in base_url)
    ) as mock:
        yield mock


@pytest.fixture
def token(username: str, mock_gafaelfawr: MockGafaelfawr) -> str:
    userinfo = GafaelfawrUserInfo(username=username)
    mock_gafaelfawr.set_user_info(username, userinfo)
    return mock_gafaelfawr.create_token(username)


@pytest.fixture
def username() -> str:
    return "rachel"
