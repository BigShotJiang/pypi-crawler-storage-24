"""Domain models for runner package"""

from __future__ import annotations

__all__: list[str] = []
