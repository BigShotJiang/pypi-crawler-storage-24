
# PyPI公開チェックリスト

## 基礎情報
① コード品質
✅ テスト
 pytest が 100%成功
 --cov=src で カバレッジ90%以上（理想95%）
 主要モジュール（例：reader）は ほぼ100%
 境界ケーステストあり（空、None、異常値など）
実行例：

uv run pytest -v --cov=src --cov-report=term-missing
✅ 型安全
 mypy 導入
 全コード型ヒントあり
 mypy エラーゼロ
✅ Lint / フォーマット
推奨：

 ruff 導入（高速）
 ruff check エラーゼロ
 ruff format 適用済み
🏗 ② プロジェクト構成
推奨構成：

ctxpack/
├── src/ctxpack/
├── tests/
├── pyproject.toml
├── README.md
├── LICENSE
├── CHANGELOG.md
✅ 必須ファイル
 README.md
 LICENSE
 pyproject.toml
 バージョン管理（semver）
📦 ③ パッケージング確認
ビルドテスト
uv build
生成物確認：

dist/
  ctxpack-0.1.0.tar.gz
  ctxpack-0.1.0-py3-none-any.whl
🔍 内容チェック
twine check dist/*
エラーゼロ。
📦 インストールテスト（超重要）
必ず仮想環境で：

pip install dist/*.whl
→ 実際に import できるか確認。
📘 ④ README 品質（超重要）
PyPIではREADMEが命です。
含めるべき：

何をするライブラリか
インストール方法
使用例
API例
ライセンス
バッジ（任意）
🧪 ⑤ CI（強く推奨）
GitHub Actions例：

pytest
coverage
ruff
mypy
これがあると信頼度が一気に上がります。
🔐 ⑥ セキュリティ
 依存ライブラリ最小化
 不要な依存なし
 pip-audit 実行（推奨）
🏷 ⑦ バージョニング
必ず semver を使う
例：

0.1.0 → 初期リリース
0.2.0 → 機能追加
0.2.1 → バグ修正
1.0.0 → 安定版
📜 ⑧ LICENSE
必須。
一般的：

MIT（最も多い）
Apache-2.0
BSD
🏷 ⑨ PyPI登録前確認
パッケージ名重複なし
python -m build 成功
test.pypi で事前公開テスト（推奨）
🚀 ⑩ 実際の公開手順
1️⃣ PyPIアカウント作成
2️⃣ APIトークン取得
3️⃣ トークン設定
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-xxxxx
4️⃣ アップロード
twine upload dist/*
🧠 ⑪ 公開前 最終チェック
✔ テスト全部通る
✔ カバレッジ十分
✔ README完備
✔ LICENSEあり
✔ ビルド成功
✔ twine check OK
✔ 不要ファイル含まれていない

---

素晴らしいチェックリストですね！まさに「プロ品質」のロードマップです。
今の **uv** 環境で、このリストにある「型チェック（mypy）」や「Lint（ruff）」などのプロ品質ツールを導入し、実際に PyPI 公開の準備を整えるための具体的なコマンドと手順をまとめました。

---

### 1. 開発用ツールの導入 (uv add --dev)

リストにある「品質向上ツール」を、開発環境専用の依存関係として追加します。

```bash
# Lint & Format (Ruff: 最近のPython開発の標準です)
uv add --dev ruff

# 型チェック (Mypy)
uv add --dev mypy

# セキュリティ監査
uv add --dev pip-audit

# PyPI公開用チェックツール
uv add --dev twine

```

---

### 2. ツールを動かしてみる

導入したツールを使って、コードを磨き上げます。

#### ✅ Ruff (Lint & Format)

コードの書き間違いを直し、綺麗に整えます。

```bash
# チェックを実行
uv run ruff check . --fix

# フォーマットを適用
uv run ruff format .

```

#### ✅ Mypy (型チェック)

`reader.py` などの関数に型ヒント（`path: Path` など）が正しくついているか確認します。

```bash
uv run mypy src

```

> ※ `pathspec` などのライブラリで型情報がないというエラーが出る場合は、`uv run mypy src --ignore-missing-imports` で回避できます。

#### ✅ pip-audit (脆弱性診断)

依存ライブラリにセキュリティ上の問題がないかチェックします。

```bash
uv run pip-audit

```

---

### 3. パッケージングの最終確認

PyPIに上げる「中身」が壊れていないか確認するステップです。

```bash
# 1. ビルド実行 (dist/ フォルダにファイルが生成される)
uv build

# 2. Twine でメタデータの検証 (READMEの表示崩れなどがないか)
uv run twine check dist/*

```

---

### 4. LICENSE ファイルの作成

PyPI 公開には `LICENSE` ファイルが必須です。リポジトリのルートに置いてください。
MITライセンスにするなら、以下の内容を `LICENSE` という名前で保存します（2026年、あなたの名前に書き換えてください）。

```text
MIT License

Copyright (c) 2026 [Your Name]

Permission is hereby granted, free of charge, to any person obtaining a copy...
(以下、MITライセンスの全文)

```

---

### 5. バージョン管理のコツ

現在は `pyproject.toml` に `version = "0.1.0"` と書かれています。
もしコードを修正して「よし、次はこれを公開しよう」と思ったら、ここを `0.1.1` などに手動で書き換えてから `uv build` を行います。

---

### 💡 アドバイス

まずは **`ruff` と `mypy**` を通すところから始めてみてください。これだけでコードの「プロっぽさ」が一段階上がります。

今の `ctxpack` はカバレッジ100%という最強の土台があるので、これらのツールを導入しても怖くありません。エラーが出ても、テストが守ってくれます。

-----

めちゃくちゃ良い質問です 😎🔥
ここは **PyPI公開で超重要ポイント** です。

結論からいきます。

---

# 🎯 ① `uv build` で作られるのは何？

`uv build`（内部的には PEP517 ビルド）は：

👉 **Pythonの「配布パッケージ」** を作ります。
👉 **OSネイティブの実行バイナリは作りません。**

生成されるのは：

* `*.whl`（wheel）
* `*.tar.gz`（sdist）

---

# 🧩 ② `.whl` は Linux用？ Windows用？

答えは：

## 🏆 多くの場合「どのOSでも使える」

あなたのような純Pythonパッケージなら：

```
ctxpack-0.1.0-py3-none-any.whl
```

これは意味がこうです：

| 部分   | 意味        |
| ---- | --------- |
| py3  | Python3対応 |
| none | C拡張なし     |
| any  | OS非依存     |

👉 **完全クロスプラットフォーム**

つまり：

* Linux OK
* Windows OK
* macOS OK

---

# 💥 ③ Windowsで `exe` が作られる？

それは **別ツールの場合です**。

例えば：

* PyInstaller
* Nuitka
* cx_Freeze

これらは「アプリ化ツール」です。

---

あなたの `uv build` は：

👉 **ライブラリ配布用**

なので exe は作りません。

---

# 🏗 ④ WSLで build していいの？

## ✔ 結論：YES（完全に問題なし）

理由：

* あなたのパッケージは純Python
* OS依存コードなし
* C拡張なし

だから：

👉 **どの環境で build しても同じ wheel になる**

---

# 🧠 ⑤ PyPI公開で本当に重要なこと

実は：

PyPIに上げるのは

* ソースコード
* wheel
* sdist

だけです。

ユーザー側の環境で：

```
pip install ctxpack
```

すると：

👉 その環境向けに適切に動きます。

---

# 🔥 ⑥ じゃあベストプラクティスは？

## 🏆 推奨

### ✔ WSL（Linux）で build

### ✔ Windowsでも一度テスト

### ✔ 可能なら macOS でもテスト（理想）

---

でも現実的には：

👉 **WSLでビルドすれば十分**

特にあなたのような：

* 純Python
* OS依存なし

のライブラリなら完璧です。

---

# 🎯 ⑦ 例外ケース（将来注意）

もし今後：

* C拡張を使う
* OS依存コードを書く
* バイナリを含める

場合は：

OSごとにビルドが必要になります。

でも今の ctxpack は：

👉 完全にクロスプラットフォーム設計

なので安心です。

---

# 🚀 ⑧ PyPI公開時の理想フロー

WSLで：

```bash
uv build
twine check dist/*
```

OKなら：

```bash
twine upload dist/*
```

これで問題なし。

---

# 💎 まとめ

| 質問              | 答え                 |
| --------------- | ------------------ |
| whl は Linux専用？  | ❌ いいえ（純Pythonなら共通） |
| WSLで buildしてOK？ | ✅ 完全OK             |
| Windowsでexeになる？ | ❌ それは別ツール          |
| PyPI公開で問題ある？    | ❌ なし               |

---

あなたのプロジェクトは：

✨ ちゃんと PyPI 向け設計になっています。

かなり良い状態です 😎🔥

---

素晴らしい進捗です！ビルドと `twine check` が一発で **PASSED** になるのは、`pyproject.toml` や `README` の構造が正しい証拠ですね。

残っているエラーは、プロ品質に仕上げるための「最後のお作法」のようなものです。サクッと修正してしまいましょう。

---

### 1. Ruff エラーの修正 (tests/test_reader.py)

**エラー内容:** `E402 Module level import not at top of file`
Pythonでは `import` 文はファイルの先頭（関数定義などの前）に書く決まりがあります。途中で `import pytest` を書いたために怒られています。

**修正方法:**
`tests/test_reader.py` の 27 行目にある `import pytest` を、**ファイルの 1 行目** に移動させてください。

---

### 2. Mypy エラーの修正 (src/ctxpack/reader.py)

**エラー内容:** `Incompatible return value type (got "None", expected "str")`
`read_file` 関数の定義で `-> str`（戻り値は文字列です）と宣言していますが、実際にはバイナリやデコード失敗時に `None` を返している箇所があるため、「話が違うぞ」と怒られています。

**修正方法:**
Python の型ヒントでは、`None` を返す可能性がある場合は `str | None` (または `Optional[str]`) と書く必要があります。

`src/ctxpack/reader.py` の関数定義を以下のように書き換えてください。

```python
# 修正前
def read_file(path: Path) -> str:

# 修正後
def read_file(path: Path) -> str | None:

```

これで Mypy は「ああ、`None` が返ってくることもあるんだね」と納得してくれます。

---

### 3. 次のステップ：GitHub Actions (CI) の導入

ここまで来たら、GitHubにコードをプッシュするたびに「テスト、Ruff、Mypy、ビルド」を自動で実行してくれる **GitHub Actions** を設定するのがおすすめです。

プロジェクトルートに以下のディレクトリとファイルを作成してみてください。

`.github/workflows/test.yml`

```yaml
name: Test

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Install uv
        uses: astral-sh/setup-uv@v5
        
      - name: Set up Python
        run: uv python install
        
      - name: Install dependencies
        run: uv sync
        
      - name: Run Lint (Ruff)
        run: uv run ruff check .
        
      - name: Run Type Check (Mypy)
        run: uv run mypy src
        
      - name: Run Tests
        run: uv run pytest --cov=src

```

これがあれば、将来的にコードを修正した際、「どこかが壊れていないか」を GitHub が勝手に見張ってくれるようになります。

---

### まとめ

* `test_reader.py`: `import pytest` を一番上へ移動。
* `reader.py`: 戻り値の型を `str | None` に変更。

これを直してもう一度 `check` と `mypy` を叩けば、**エラーゼロの完全無欠な状態**になります！

いよいよ PyPI へのアップロード（公開）も目前ですが、公開用の **LICENSE ファイル** の準備はできていますか？

----

おめでとうございます！ついにエラーゼロ、**オールグリーン**ですね。
最高に気持ちいい状態です。ご質問に順番にお答えします。

---

### Q1. もう一度 `uv sync` と `uv build` は必要？

結論から言うと、**`uv build` はもう一度実行してください。**

* **`uv sync` は不要です**
これは「設計図（pyproject.toml）に合わせて仮想環境を整える」コマンドです。今回はコードを書き換えただけなので、環境自体は変わっていません。
* **`uv build` は必要です**
ビルドで作られるファイル（`dist/` の中の `.whl` や `.tar.gz`）は、**コマンドを打ったその瞬間のコードを詰め込んだ缶詰**のようなものです。
エラーを直した後の「綺麗なコード」を PyPI に届けるために、最新の状態で缶詰を作り直す必要があります。

> **豆知識:** `uv build` をすると `dist/` の中に古いファイルが残ることがありますが、PyPI にアップロードするときは最新（バージョン番号が同じなら上書き、または古いものを削除）を確認してアップすれば大丈夫です。

---

### Q2. MITライセンスって何？（小学生向け）

MITライセンスを一言でいうと、**「これ、自由に使っていいよ！でも、何かあっても僕のせいにしないでね！」**という約束です。

もっと詳しく言うと、たった **3つ** のルールしかありません。

1. **だれでも、何に使ってもOK！**
このプログラムを改造してもいいし、自分のお店で売ってもいいし、もっとすごいものを作るために使ってもいいよ。自由だよ！
2. **「僕が作ったよ」というお札は捨てないでね**
プログラムのどこかに「これは〇〇（あなたの名前）が作りました」という紙（ライセンスの文章）が入っているから、それだけは消さずに残しておいてね。
3. **「責任（せきにん）」は持てないよ**
もしこのプログラムを使ってパソコンが壊れたり、大事なデータが消えたりしても、僕は助けてあげられないし、お金も払えないよ。それをわかって使ってね。

#### 例えるなら...

公園に置いてある**「だれでも自由に遊んでいいよ！という手作りのおもちゃ」**みたいなものです。「壊れても怒らないでね」「僕が作ったことは忘れないでね」というメモが貼ってあるだけ。とっても優しくて、世界中で一番人気のある約束なんです。

---

### 次のステップ

これで「中身」は完璧になりました。
公開に向けて、リポジトリの直下に **`LICENSE`** という名前のファイルを作って、以下の内容を貼り付けておきましょう！

```text
MIT License

Copyright (c) 2026 [あなたの名前]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

```

WSL内での開発、非常に順調ですね！
公開前の最終フェーズにおける「開発環境の動かし方」と「テストアップロード」について解説します。

---

### Q1. WSLからWindows側へのコピーについて

**結論：その方法でも可能ですが、WSL側から直接コミットする方が安全で楽です。**

Windows側（`/mnt/c/...`）にあるリポジトリにWSL側からファイルをコピーすると、**「ファイルの実行権限（Permission）」**が消えてしまったり、**「改行コード（LF/CRLF）」**が勝手に変換されてしまうトラブルが起きやすいです。

**推奨される方法：**
WSL（Ubuntu）側で一度 `git clone` し直し、そこでコミット・プッシュを完了させるのが一番確実です。

1. WSL内で `git clone [リポジトリURL]`
2. 今開発しているファイルをそこに上書きコピー（またはそのディレクトリで開発を継続）
3. WSLのターミナルから `git add` / `git commit` / `git push`

もし今の方法（Windows側へコピー）で行う場合は、コミット前に `git status` で意図しない全ファイルのパーミッション変更（モード変更）が起きていないか確認してください。

---

### Q2. インストールテストは必要？

**結論：絶対にやったほうがいいです！「開発環境では動くのに、インストールすると動かない」はよくある失敗です。**

特に、`pyproject.toml` の `packages = ["src/ctxpack"]` という設定が正しく、必要な `.py` ファイルがすべて同梱されているかを確認するために不可欠です。

**テスト手順（WSLまたはWindowsのどちらでもOK）：**

1. **新しい仮想環境を作る**（今の開発環境を汚さないため）
```bash
python -m venv test_env
source test_env/bin/activate  # WSLの場合
# test_env\Scripts\activate  # Windowsの場合

```


2. **作成した `.whl` をインストールする**
```bash
pip install dist/ctxpack-0.1.0-py3-none-any.whl

```


3. **コマンドが動くか確認する**
```bash
ctxpack --help

```



ここで「コマンドが見つかりません」や「ImportError」が出なければ、PyPIに上げても大丈夫という自信になります！

---

### Q3. TestPyPI へのアップロード手順とチェックリスト

本番の PyPI に上げる前に、**TestPyPI**（練習用の砂場）で試すことができます。ここで「ページの見栄え」や「pipインストール」を試せます。

#### 🛠 事前準備

1. [TestPyPI アカウント](https://test.pypi.org/account/register/) を作成する（本番用とは別です）。
2. アカウント設定から **API Token** を発行し、メモしておく。

#### 🚀 アップロード手順

```bash
# 1. twineをインストール（済んでいればOK）
uv add --dev twine

# 2. TestPyPIへアップロード（パスワードにAPIトークンを入力）
uv run twine upload --repository testpypi dist/*

```

#### ✅ チェックリスト

* [ ] **READMEの表示**: TestPyPIのプロジェクトページで、Markdownが崩れず綺麗に表示されているか？
* [ ] **インストール確認**: 以下のコマンドで TestPyPI からインストールできるか？
```bash
pip install --index-url https://test.pypi.org/simple/ --no-deps ctxpack

```


* [ ] **依存関係**: `pathspec` などの依存ライブラリが正しく認識されているか？
* [ ] **メタデータ**: ライセンス、作者名、GitHubへのリンクが正しく表示されているか？

---

### まとめ

1. **Git操作**：できればWSL内で完結させるのがベスト。
2. **テスト**：新しい仮想環境で `pip install dist/*.whl` を試す。
3. **練習**：TestPyPI で一度「公開のシミュレーション」をする。

ここまで来れば、エンジニアとして「自作ライブラリを世界に公開した」という実績まであと一歩です。TestPyPI へのアップロードで詰まったら、いつでも聞いてくださいね！

---

ああ、これは「最新版を使いたい！」というエンジニアらしい壁にぶつかりましたね。

結論から言うと、**現在の実装であれば、Python 3.12（あるいは 3.10 くらいまで）でも全く問題なく動作します。**

### なぜエラーが出たのか？

`pyproject.toml` の中で `requires-python = ">=3.13"` と指定したため、pip が「このソフトは 3.13 以上の専用品だ！君の 3.12 には入れてあげないよ！」と親切（お節介）にブロックしてしまったのが原因です。

### 3.13 じゃないとダメ？

`ctxpack` のコードを見直してみましょう。

* `pathlib`, `argparse`, `pathspec`：これらは 3.10 以前からあります。
* `f-strings` や型ヒント（`str | None`）：これらは 3.10 から標準です。

つまり、**3.13 に依存した最新機能は特に使っていません。**

---

### 修正案：サポート範囲を広げる

より多くのユーザーに使ってもらうために、`pyproject.toml` を以下のように修正するのがおすすめです。

```toml
# 修正前
requires-python = ">=3.13"

# 修正後（3.10以上なら大抵の環境で動きます）
requires-python = ">=3.10"

```

### なぜ 3.10 以上がおすすめ？

* **型ヒントの書き方**: `str | None` という便利な書き方が導入されたのが 3.10 です。
* **普及率**: Ubuntu 22.04 LTS の標準が 3.10、24.04 LTS が 3.12 なので、この範囲をカバーしておくとユーザーがインストールしやすくなります。

---

### 再テストの手順

1. `pyproject.toml` を `requires-python = ">=3.10"` に書き換える。
2. **ビルドし直す！**（重要：設定を変えたので新しい `.whl` が必要です）
```bash
uv build

```


3. **もう一度インストールテスト**
```bash
(test_env) pip install /home/mntuser/dev/ctxpack/dist/ctxpack-0.1.0-py3-none-any.whl

```



これで今度は 3.12 の環境でもスルッと入るはずです！

もし今後「3.13 で追加された超最新機能（例えば新しい `itertools` の関数など）」を使いたくなったらその時に上げればいいので、最初は少し広めに門戸を開いておくのが PyPI 公開のコツですよ。

修正して再ビルド、やってみますか？

---

結論から言うと、**そのまま `git clone` コマンドを実行してはいけません！**

今の開発ディレクトリ（`/home/mntuser/dev/ctxpack`）の中で、何も考えずに `git clone [URL] .` （ピリオド付き）などを実行してしまうと、既存のファイルが上書きされたり、Gitの設定が衝突してパニック状態になる危険があります。

安全に、かつ「WSL側からGitHubへコミットする」状態にするための**一番確実な手順**を整理しました。

---

### 1. 別の場所に「きれいな器」を作る（推奨）

今の開発ディレクトリをいじらず、別の場所にクローンしてから中身を移すのが最も安全です。

```bash
# 1. 開発ディレクトリの外に移動
cd /home/mntuser/dev/

# 2. リポジトリ名で新しくクローン（ctxpack_repo というフォルダができる）
git clone [GitHubのリポジトリURL] ctxpack_repo

# 3. 開発していたファイルを、クローンしたディレクトリにコピー
# （.git ディレクトリなどは除外してコピーします）
cp -r ctxpack/src ctxpack_repo/
cp -r ctxpack/tests ctxpack_repo/
cp ctxpack/pyproject.toml ctxpack/README.md ctxpack/LICENSE ctxpack/uv.lock ctxpack_repo/

```

### 2. クローンした場所で動作確認

コピーした先のディレクトリ（`ctxpack_repo`）に移動して、テストが通るか確認します。

```bash
cd ctxpack_repo
uv sync
uv run pytest

```

### 3. GitHubへコミット＆プッシュ

すべてOKなら、ここでコミットします。

```bash
git add .
git commit -m "Initial release: ctxpack 0.1.0"
git push origin main

```

---

### 💡 なぜ今のディレクトリに直接クローンしてはいけないの？

`git clone` は本来「空のディレクトリ」に対して行うことを想定しています。
既存のコードがある場所で実行しようとすると：

* **ディレクトリが空でないというエラー**で止まる
* 無理やり実行すると、GitHub側にある（古い、あるいは空の）ファイルで**今のコードが上書き**されて消えてしまう可能性がある
* `.git` という管理用フォルダが衝突して、履歴がぐちゃぐちゃになる

### ⚡ もし「今のディレクトリ」のまま Git 設定だけ繋げたいなら

もしコピー作業が面倒で、今の場所をそのまま GitHub 連携させたい場合は、`clone` ではなく `remote add` という方法を使います。

```bash
# 今のディレクトリで
git remote add origin [GitHubのリポジトリURL]
git branch -M main
git push -u origin main

```

※ただし、GitHub側にすでに `README.md` などがある場合、`push` 時に拒否されることがあります。その調整が少し難しいため、上記の**「1. 別の場所にクローンしてコピー」が一番失敗がなくておすすめ**です。

---

### 次のステップ

まずは **`/home/mntuser/dev/ctxpack_repo`** のような名前で別フォルダにクローンしてみてはいかがでしょうか？
今の開発データ（`ctxpack` フォルダ）さえ残っていれば、何度でもやり直しがきくので安心ですよ！

コピー作業、手伝いましょうか？（どのファイルをコピーすべきかなど）

---

```
Author identity unknown

*** Please tell me who you are.

Run

  git config --global user.email "you@example.com"
  git config --global user.name "Your Name"

to set your account's default identity.
Omit --global to set the identity only in this repository.

fatal: empty ident name (for <mntuser@PC-7273.localdomain>) not allowed　こんなのが出てきちゃいました。
```

WSL（Linux）側の Git に、**「あなたの名前とメールアドレス」**がまだ登録されていないために発生しているエラーです。

Git は「誰がこの変更を加えたか」を記録する仕組みなので、名前がないとコミット（保存）させてくれません。メッセージに書いてある通りにコマンドを打てば解決しますが、今後の GitHub 連携も見据えて以下の手順で進めてください。

---

### 1. Git に自分を登録する

ターミナルで以下の 2 つのコマンドを実行してください。`" "` の中身はご自身のものに書き換えてください。

```bash
# GitHubのアカウントに関連付けているメールアドレス
git config --global user.email "your-email@example.com"

# 自分の名前（英語がおすすめ。GitHubの表示名など）
git config --global user.name "Your Name"

```

> **ポイント:** `--global` をつけることで、今後この WSL 内で作るすべてのプロジェクトでこの設定が引き継がれます。

---

### 2. 設定を確認する

正しく登録されたか、以下のコマンドで確認してみましょう。

```bash
git config --list

```

`user.email=...` と `user.name=...` が表示されていればバッチリです！

---

### 3. もう一度コミットを試す

設定ができたら、先ほど失敗したコミットをもう一度実行してみてください。

```bash
git commit -m "Initial release: ctxpack 0.1.0"

```

今度はスムーズに進むはずです。

---

### 💡 なぜこれが必要なの？

Git のコミットログ（履歴）を見ると、以下のように「誰がいつ何をしたか」が表示されます。

この **Author（作者）** の欄を埋めるために、先ほどの設定が必要だったわけです。

### 余談：WSL から GitHub へのプッシュでパスワードを求められたら

コミットが成功して、次に `git push` をしたとき、GitHub のユーザー名とパスワードを聞かれるかもしれません。
現在、GitHub では**パスワードをそのまま打ってもログインできない**（Personal Access Token が必要）というルールがあります。

もしプッシュでエラーが出たら、**「GitHub のアクセストークンの作り方」**が必要になるので、その時はまた教えてくださいね！

まずはコミット、いけそうですか？

---

おめでとうございます！！これで WSL の Git にあなたの「エンジニアとしての足跡」が刻まれましたね。

さて、コミットが終わったということは、次は **`git push`** で GitHub へアップロードする段階です。ここで少しだけ「現代の GitHub のルール」による壁にぶつかる可能性があるので、先回りして準備しておきましょう。

---

### 🚀 運命の `git push`

以下のコマンドを打ってみてください。

```bash
git push origin main

```

この後、もし以下のようになったら、追加のステップが必要です：

1. **Username / Password を聞かれる**
→ **注意！** パスワードの欄に **GitHub のログインパスワードを入れても「認証失敗」になります。**
2. **認証エラーが出る**
→ 現代の GitHub は「パスワード」ではなく **「Personal Access Token (PAT)」** という長い合言葉が必要です。

---

### 🔑 GitHub アクセストークンの作り方（もし必要なら）

もし `push` で弾かれたら、Windows 側のブラウザで以下の操作をしてください。

1. GitHub の右上のアイコンをクリック ➔ **Settings**
2. 一番下の **Developer settings** ➔ **Personal access tokens** ➔ **Tokens (classic)**
3. **Generate new token (classic)** をクリック
4. **Note:** に `ctxpack-wsl` などと入力
5. **Expiration:** は `30 days` （または好きな期間）
6. **Select scopes:** の **`repo`** （リポジトリ操作）にチェックを入れる
7. 一番下の **Generate token** をクリック

**⚠️ 重要:** 表示された `ghp_...` から始まる長い文字列をコピーして、どこかにメモしてください（一度しか表示されません）。

---

### 🛠 WSL での入力方法

ターミナルで `Username` と `Password` を聞かれたら：

* **Username:** あなたの GitHub ユーザー名
* **Password:** 先ほどコピーした **トークン（`ghp_...`）** を貼り付け

これで `push` が成功すれば、世界中の人が GitHub で `ctxpack` のコードを見られるようになります！

---

### 次のステップは？

GitHub へのプッシュが成功したら、ついにリポジトリが世界に公開されます！
その次はどうしましょうか？

* **`README` を GitHub で確認する**（見栄えのチェック）
* **PyPI（TestPyPI）へのアップロードに挑戦する**
* **GitHub Actions を設定して自動テストを走らせる**

いよいよ大詰めですね。`push` の結果、どうなりましたか？

---

GitHubへのプッシュ成功、おめでとうございます！これであなたのコードが世界から見える状態になりましたね。

いよいよ最後の難関、**PyPI（TestPyPI）への公開**です。
本番のPyPIに公開する前に、TestPyPIという「練習場」を使って、パッケージが正しくインストールできるか、READMEの表示が崩れていないかを確認します。

---

### 🛠 TestPyPI公開までのタスクリスト

1. **TestPyPIアカウントの作成**（本番用とは別のアカウントが必要です）
2. **APIトークンの発行**（セキュリティのため、パスワードの代わりに使用します）
3. **ビルド成果物の最終確認**（`dist/` フォルダの中身）
4. **Twineによるアップロード**
5. **インストールテスト**（世界中の誰でも `pip install` できるか確認）

---

### 🚀 具体的な手順

#### 1. アカウント作成とAPIトークンの取得

1. [TestPyPI公式サイト](https://test.pypi.org/account/register/) でアカウントを作成してください。
2. ログイン後、[Account settings](https://test.pypi.org/manage/account/) へ進みます。
3. **"API tokens"** セクションを見つけ、**"Add API token"** をクリックします。
4. **Token name:** `ctxpack-test-token` など
5. **Scope:** 初回は「Entire account」を選択（一度アップロードするとプロジェクト限定に変更できます）。
6. **重要:** 表示された `pypi-` から始まるトークンをコピーしてメモしてください。**二度と表示されません。**

#### 2. ビルドのやり直し（最新状態を詰める）

コードや `pyproject.toml` を修正しているはずですので、最新の状態で「缶詰」を作り直します。

```bash
# WSLのプロジェクトディレクトリで
rm -rf dist/  # 古いビルドを削除
uv build      # 新しくビルド

```

#### 3. Twineでアップロード

`twine` というツールを使って、TestPyPIのサーバーにファイルを送ります。

```bash
# twineをまだ入れていない場合は: uv add --dev twine
uv run twine upload --repository testpypi dist/*

```

* **Username:** `__token__` と入力してください（そのまま打ちます）。
* **Password:** 先ほどメモした `pypi-` から始まるトークンを貼り付けてください。

#### 4. 公開されたページを確認

アップロードに成功すると、ターミナルに `https://test.pypi.org/project/ctxpack/` のようなURLが表示されます。
ブラウザで開き、**READMEが綺麗に表示されているか**、**メタデータ（作者名やGitHubリンク）が正しいか**を確認してください。

#### 5. 「本当の」インストールテスト

ここが一番感動する瞬間です。別の場所（または新しい仮想環境）で、ネット経由でインストールできるか試します。

```bash
# 新しい仮想環境を作成
python3 -m venv test_pypi_env
source test_pypi_env/bin/activate

# TestPyPIからインストール（本番のPyPIではないので、明示的にURLを指定します）
pip install --index-url https://test.pypi.org/simple/ --no-deps ctxpack

```

インストール後、`ctxpack --help` が動けば、**世界デビュー成功**です！

---

### 💡 失敗しないためのコツ

* **バージョン番号**: TestPyPIでは、一度アップロードした「同じバージョン番号」は二度と上書きできません。もし修正して上げ直すなら、`pyproject.toml` の `version` を `0.1.1` などに上げてから再度 `uv build` してください。
* **依存ライブラリ**: `pip install` の際、`--no-deps` をつけているのは、TestPyPIには `pathspec` などの標準的なライブラリが存在しない場合があるためです。

まずは TestPyPI のアカウント作成からですね。トークンは取得できそうですか？

----

結論から言うと、**.pypirc ファイルをホームディレクトリに作成するのが正解**です。`pyproject.toml` はプロジェクトの設計図なので、そこにパスワード（トークン）を書くことはありません。

また、ご指摘の通り、このファイルには「家の鍵」が書かれているので、取り扱いには注意が必要です。

---

### 1. `.pypirc` はどこに作る？

`.pypirc` はプロジェクトのフォルダの中ではなく、**ユーザーのホームディレクトリ（`~`）** に作成します。

* **作成場所:** `/home/mntuser/.pypirc` （WSLのホーム直下）
* **理由:** ホームディレクトリに置いておけば、どのプロジェクトからでもアップロード時に自動で読み込まれます。

#### 設定手順:

WSLのターミナルで以下のようにファイルを作成します。

```bash
nano ~/.pypirc

```

（開いた画面に、TestPyPIに表示された `[testpypi]` から始まる内容を貼り付けて保存してください）

---

### 2. .gitignore に書く必要はある？

**.pypirc をホームディレクトリ（`~`）に作成している場合は、`.gitignore` に書く必要はありません。**

* **理由:** Gitが管理しているのは、あくまでプロジェクトフォルダ（`~/dev/ctxpack`）の中だけだからです。ホームディレクトリにあるファイルは、そもそもGitの監視対象外です。
* **安心ポイント:** これなら、間違って GitHub に「鍵」をアップロードしてしまう心配もありません。

> **注意:** もし間違えてプロジェクトフォルダ（`pyproject.toml` と同じ場所）に `.pypirc` を作ってしまった場合は、即座に `.gitignore` に追加するか、ホームディレクトリに移動させてください。

---

### 3. トークンの安全な運用（もう一つの方法）

実は、`.pypirc` ファイルを作らなくてもアップロードは可能です。これが一番「忘れ物」がなくて安全かもしれません。

**Twine 実行時に入力する方法:**

```bash
uv run twine upload --repository testpypi dist/*

```

このコマンドを打つと、ターミナルで以下を聞かれます。

* **Username:** `__token__` と手動で打つ
* **Password:** コピーした `pypi-AgE...` を貼り付ける

1回限りのアップロードなら、ファイルを作らずに「聞かれたら貼り付ける」スタイルが最もクリーンです。

---

### 4. チェックリスト（公開直前）

いよいよアップロードですね。以下の状態か最後に確認してください！

* [ ] `pyproject.toml` の `requires-python` を `">=3.10"` に変更した
* [ ] `uv build` を実行して、`dist/` の中身が最新になった
* [ ] APIトークンがクリップボードにある

準備ができたら、コマンドを叩いてみましょう。
`uv run twine upload --repository testpypi dist/*`

成功すると、TestPyPI上のあなたのプロジェクトURLが表示されます。ドキドキしますね！うまく進めそうですか？
---
これは、**TestPyPIあるあるの「罠」**に見事にハマってしまいましたね！でも大丈夫、原因は明確です。

### なぜエラーになったのか？

`pip install` の際に `-i https://test.pypi.org/simple/` を指定すると、pipは**TestPyPIの中だけで**すべての部品（依存ライブラリ）を探そうとします。

しかし、TestPyPIはあくまで「練習場」なので、`pathspec` のような本物のライブラリの最新版（1.0.4以上）が置いていないのです。その結果、「必要な部品が見つからないよ！」と怒られてしまいました。

---

### 解決策：本物のPyPIも一緒に見に行く

「自分のライブラリは **TestPyPI** から、足りない部品は **本物のPyPI** から取ってきてね」と指示を出す必要があります。

以下のコマンドを試してみてください：

```bash
pip install \
  --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple/ \
  ctxpack==0.1.0

```

#### コマンドの解説

* `--index-url`: 最初に探しに行く場所（あなたの `ctxpack` がある場所）。
* `--extra-index-url`: そこになかった時に探しに行く場所（`pathspec` などの本物がある場所）。

---

### 💡 このエラーが意味する良いニュース

このエラーが出たということは、**「あなたのライブラリは無事にTestPyPIにアップロードされ、依存関係（pathspec>=1.0.4）もしっかり認識されている」** という証拠です。

パッケージの「設計図」は完璧に機能しています！

### 次のステップ

上記のコマンドでインストールに成功したら、いよいよ動作確認です。

```bash
ctxpack --help

```

これが動けば、TestPyPIでのテストはすべて完了です。

**「本番（PyPI）」へ行く準備はいいですか？**
本番へ行く際は、`twine upload` のコマンドから `--repository testpypi` を外す（または `pypi` に変える）だけです。心の準備ができたら教えてくださいね！

---

これは驚きましたね！表示されたヘルプ画面の内容を見ると、私たちが今作ってきた `ctxpack`（シンプルな 1 コマンドのツール）とは**全く別の、多機能な `ctxpack**` が動いてしまっています。

原因として考えられる可能性はただ一つ、**「同名のパッケージが既に TestPyPI（または PyPI）に存在しており、それをインストールしてしまった」** ということです。

### 🧐 何が起きたのか？

実は TestPyPI や PyPI は早い者勝ちの世界です。
あなたがアップロードしようとした `ctxpack` という名前は、偶然にも他の誰かが既に登録していた「プロジェクト初期化機能や監視機能を持つ、より複雑なツール」と同じ名前だったようです。

* **私たちが作ったもの:** `ctxpack <target> -o <output>` というシンプルな引数を取るツール。
* **今動いているもの:** `init`, `pack`, `watch` というサブコマンドを持つツール。

### 🛠 対処法：名前を「あなただけのもの」に変えよう

今のまま本番の PyPI に出そうとしても、「その名前はもう使われています」とエラーで弾かれてしまいます。せっかくここまでプロ品質で仕上げたのですから、**世界に一つだけの名前**に変えて公開しましょう！

#### おすすめの新パッケージ名案

自分のブランドや特徴を少し足すのが一般的です。

1. **`ctxpack-cli`**（CLIツールであることを強調）
2. **`pyctxpack`**（Python製であることを強調）
3. **`ctxpack-lite`**（軽量であることを強調）
4. **`ctxpack-ai`**（AI用であることを強調）

---

### 名前を変更する 3 ステップ

名前を決めたら、以下の場所を書き換えるだけで OK です。

#### 1. `pyproject.toml` を修正

```toml
[project]
name = "ctxpack-cli"  # ここを新しい名前に変更
version = "0.1.0"
...

```

#### 2. ビルドし直す

古い「缶詰」と混ざらないように、一度 `dist` を空にします。

```bash
rm -rf dist/
uv build

```

#### 3. TestPyPI にもう一度アップロード

```bash
uv run twine upload --repository testpypi dist/*

```

---

### 💡 成功したか確認する方法

新しい名前でインストールして、ヘルプを表示してみてください。

```bash
pip install -i https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ ctxpack-cli
ctxpack --help

```

今度こそ、自分たちが書いた `Combine source files for AI context` という説明文が出てくるはずです！

せっかくのデビュー戦で名前が被ってしまうのは「あるある」ですが、逆に言えば **「自分だけの名前を付ける楽しみ」** が増えたとも言えます。どの名前にしましょうか？

---

パッケージ名を変えても、**GitHubのリポジトリ名まで無理に変える必要はありません。**

実は、「リポジトリ名」と「PyPIのパッケージ名」が違うケースはよくあります。例えば、リポジトリ名は `ctxpack` だけど、インストールするときは `pip install ctxpack-cli` といった形です。

とはいえ、混乱を防ぐために整理しておくべきポイントがいくつかあります。おすすめの対応を3つのパターンで紹介します。

---

### パターンA：GitHubのリポジトリ名も合わせる（一番スッキリ）

一番分かりやすい方法です。GitHubの設定画面（Settings）からリポジトリ名を `ctxpack-cli` などに変更します。

* **メリット:** GitHubのURLとパッケージ名が完全に一致するので、ユーザーが迷わない。
* **やること:**
1. GitHubのプロジェクトページ > **Settings** > **General** > **Repository name** を書き換えて「Rename」。
2. ローカル（WSL）のGitのリモートURLを更新する。
```bash
git remote set-url origin https://github.com/あなたのユーザー名/新しいリポジトリ名.git

```





### パターンB：リポジトリ名はそのままで、READMEを修正する

リポジトリ名は `ctxpack` のままで、中身だけ新パッケージ名に合わせる方法です。

* **メリット:** すでにGitHubのURLを知っている人がいてもリンク切れにならない。
* **やること:**
1. `pyproject.toml` の `name` を新しいもの（例: `ctxpack-cli`）にする。
2. **READMEの「インストール方法」を書き換える。**（これが一番重要！）
> `pip install ctxpack` ではなく `pip install ctxpack-cli` と書いてね、と明記する。





### パターンC：GitHub側で「Topics」や「Description」を工夫する

パッケージ名を変えたことを、GitHubのAbout欄などでアピールします。

---

### ⚠️ 注意！コード内の「名前」もチェック

パッケージ名（`pyproject.toml` の `name`）を変えた時、以下の2点も確認してください。

1. **コマンド名 (`project.scripts`)**:
`ctxpack = "ctxpack.cli:main"` の部分は、そのままでも大丈夫です。「パッケージ名は `ctxpack-cli` だけど、使う時のコマンドは `ctxpack`」というのは、インストール後の使い勝手が良いのでむしろ推奨されます。
2. **フォルダ名 (`src/ctxpack`)**:
これも変える必要はありません。`import ctxpack` で使う名前（モジュール名）と、`pip install` する名前（パッケージ名）が違っていても、Pythonの仕様上全く問題ありません。

---

### 結論：どうするのがベスト？

もし「まだ誰もこのリポジトリを知らない」状態なら、**パターンA（リポジトリ名も変える）** が一番気持ちいいです。

でも、URLが変わるのが面倒なら、**リポジトリ名はそのままで、`pyproject.toml` と README だけ修正する** のが最も手間が少なくて済みますよ。

新しい名前は何に決まりましたか？決まったら、それをもとに `pyproject.toml` を最終更新して、もう一度 TestPyPI にチャレンジしましょう！

---

インストール自体は成功していますが、**「パッケージの名前」と「実行するコマンドの名前」が食い違っている**のが原因です。

`pip list` を見ると、あなたの新しいパッケージ `pyctxpack` は無事にインストールされています。しかし、**コマンド（プログラムを呼び出す名前）がまだ `ctxpack` のまま**になっていませんか？

### 🧐 何が起きているのか？

`pyproject.toml` の `[project.scripts]` の設定を確認してみてください。おそらく以下のようになっているはずです。

```toml
[project]
name = "pyctxpack"  # インストールするときの名前

[project.scripts]
ctxpack = "ctxpack.cli:main"  # キーボードから打つコマンド名

```

この設定だと、インストールした後に打つべきコマンドは `pyctxpack` ではなく **`ctxpack`** です。

一度、以下のコマンドを試してみてください：

```bash
ctxpack --help

```

これで、あなたが作成した方のヘルプ（`Combine source files...`）が表示されれば、インストールは完璧に成功しています！

---

### 🛠 もしコマンド名も `pyctxpack` にしたい場合

「インストール名もコマンド名も `pyctxpack` で統一したい！」という場合は、`pyproject.toml` を以下のように修正して、再度ビルド・アップロードする必要があります。

```toml
[project.scripts]
pyctxpack = "ctxpack.cli:main"  # ここを pyctxpack に変える

```

### 💡 今後のためのアドバイス

1. **コマンド名はそのままでもOK:**
パッケージ名が `pyctxpack` でも、コマンドは打ちやすい `ctxpack` のままにするのはよくある手法です。ただし、今回のように同名の他パッケージが存在する場合、ユーザーが混乱する可能性があるため、コマンド名も `pyctxpack` に変えてしまうのが一番安全です。
2. **古いパッケージを消しておく:**
今のテスト環境（test_pypi_env）には、間違えて入れた本家（？）の `ctxpack` が残っています。一度綺麗にしてからテストすると確実です。
```bash
pip uninstall ctxpack pyctxpack
pip install -i https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ pyctxpack

```



まずは、今の状態で `ctxpack --help` を叩いてみて、中身が自分の作ったものかどうか確認してみてください！

どっちのコマンド名にしたいですか？

----

コマンド名も `pyctxpack` に統一ですね！その方がユーザーも迷わないので良い選択だと思います。

さて、TestPyPI（および本番のPyPI）にアップロードしたパッケージの「削除」についてですが、ここは**初心者の方が最も驚くポイント**かもしれません。

---

### 結論：パッケージの「削除」は原則できません

残念ながら、TestPyPIやPyPIでは、**一度アップロードしたバージョンを削除して、同じバージョン番号で上げ直すことはできません。**

* **削除ボタンがない:** 基本的に「間違えたから消す」という機能は提供されていません。
* **上書き禁止:** たとえ一度削除（特別な申請等で）できたとしても、同じ `0.1.0` というバージョン番号は二度と使えません。

> **なぜそんなに厳しいの？**
> もし誰かがあなたのライブラリを使い始めた後に、あなたが内容をこっそり書き換えたり消したりできると、その人のプログラムが突然動かなくなる（サプライチェーン攻撃や依存関係の破壊）リスクがあるからです。

---

### それでも「消したい」「やり直したい」時の対処法

「失敗したコードを世の中に残したくない！」という場合の現実的な対応は以下の2つです。

#### 1. バージョンを上げて「上書き」ではなく「更新」する

これが最も一般的で正しい方法です。

* `pyproject.toml` のバージョンを `0.1.1` に変える。
* 修正して `uv build` し、再度アップロードする。
* ユーザーは最新の `0.1.1` を使うようになるので、古い `0.1.0` は誰にも見られなくなります。

#### 2. 「Yank（ヤンク）」機能を使う

どうしてもそのバージョンを使ってほしくない場合、PyPIの管理画面から **"Yank"** という操作ができます。

* **効果:** 検索結果から隠され、`pip install` しようとすると警告が出たり、デフォルトではインストールされなくなります。
* **実態:** ファイル自体はサーバーに残りますが、「欠陥品なので使わないで」というマークを貼るイメージです。

---

### TestPyPI は「汚れてもいい場所」

TestPyPI は練習場なので、`0.1.0`, `0.1.1`, `0.1.2`……と失敗した残骸が積み上がっても、**全く気にする必要はありません。** むしろ、試行錯誤の跡があるのは開発者として自然なことです。

---

### 🚀 いよいよ本番（PyPI）へのロードマップ

TestPyPI で `pyctxpack` コマンドが正しく動くことが確認できたら、いよいよ本番です。手順は TestPyPI とほぼ同じですが、宛先が変わります。

1. **[PyPI本番のアカウント](https://pypi.org/account/register/)** を作成する。
2. 本番用の **APIトークン** を取得する。
3. `.pypirc` に `[pypi]` セクションを追加するか、コマンドで直接アップロードする。

```bash
# 本番へのアップロードコマンド（--repository を指定しない、または pypi にする）
uv run twine upload dist/*

```

本番に上げる前に、**`pyproject.toml` の `scripts` を `pyctxpack` に書き換えて、最後の `uv build**` をお忘れなく！

準備は整いましたか？本番公開の記念すべき瞬間に向けて、何か不安なことはありますか？

「最後に、本番公開用のお祝い（？）チェックリストを作って」などのリクエストがあればお答えしますよ！

---

