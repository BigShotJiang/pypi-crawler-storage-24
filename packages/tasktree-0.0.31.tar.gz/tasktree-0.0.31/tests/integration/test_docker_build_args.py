"""Integration tests for Docker build args functionality."""

import os
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from typer.testing import CliRunner

from helpers.docker import is_docker_available
from tasktree.cli import app


class TestDockerBuildArgs(unittest.TestCase):
    """
    Test Docker build args are passed correctly to docker build.
    """

    def setUp(self):
        """
        Set up test fixtures.
        """
        self.runner = CliRunner()
        self.env = {"NO_COLOR": "1"}

    @unittest.skipUnless(is_docker_available(), "Docker not available")
    def test_build_args_passed_to_dockerfile(self):
        """
        Test that build args are passed to docker build and used in Dockerfile.
        """
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create output directory
            (project_root / "output").mkdir()

            # Create a Dockerfile that uses ARG statements
            dockerfile = project_root / "Dockerfile"
            dockerfile.write_text("""FROM alpine:latest
WORKDIR /workspace

ARG BUILD_VERSION
ARG BUILD_DATE
ARG PYTHON_VERSION=3.11

RUN echo "Build version: $BUILD_VERSION" > /build-info.txt && \\
    echo "Build date: $BUILD_DATE" >> /build-info.txt && \\
    echo "Python version: $PYTHON_VERSION" >> /build-info.txt
""")

            # Create recipe with Docker runner and build args
            recipe_file = project_root / "tasktree.yaml"
            recipe_file.write_text("""
runners:
  default: builder
  builder:
    dockerfile: ./Dockerfile
    context: .
    shell:
      cmd: sh
    volumes: ["./output:/workspace/output"]
    args:
      build:
        # Each build arg must be a single string in --build-arg=KEY=VALUE form,
        # or split into two separate list items ("--build-arg", "KEY=VALUE").
        # Strings with spaces are passed as a single opaque argument to docker build.
        - "--build-arg=BUILD_VERSION=1.2.3"
        - "--build-arg=BUILD_DATE=2024-01-01"
        - "--build-arg=PYTHON_VERSION=3.12"

tasks:
  build:
    run_in: builder
    outputs: [output/build-output.txt]
    cmd: cp /build-info.txt output/build-output.txt
""")

            original_cwd = os.getcwd()
            try:
                os.chdir(project_root)

                # Run the task - this will build the Docker image with build args
                # Note: This test will be skipped in CI if Docker is not available
                result = self.runner.invoke(app, ["build"], env=self.env)

                self.assertEqual(result.exit_code, 0, f"Task failed:\n{result.stdout}\n{result.stderr}")

                # Verify that the build args were actually used in the container
                build_output = project_root / "output" / "build-output.txt"
                self.assertTrue(build_output.exists(), "output/build-output.txt should be created")

                content = build_output.read_text()
                self.assertIn("Build version: 1.2.3", content, "BUILD_VERSION arg should be passed")
                self.assertIn("Build date: 2024-01-01", content, "BUILD_DATE arg should be passed")
                self.assertIn("Python version: 3.12", content, "PYTHON_VERSION arg should override default")

            finally:
                os.chdir(original_cwd)


if __name__ == "__main__":
    unittest.main()
