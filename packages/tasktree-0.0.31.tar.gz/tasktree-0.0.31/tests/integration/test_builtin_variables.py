"""Integration tests for built-in variables feature."""

import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock

from tasktree.executor import Executor
from tasktree.parser import parse_recipe
from tasktree.process_runner import TaskOutputTypes, make_process_runner, ProcessRunner
from tasktree.state import StateManager

from helpers.logging import logger_stub
from fixture_utils import copy_fixture_files


class TestBuiltinVariables(unittest.TestCase):
    """
    Test built-in variable substitution in task execution.
    """

    def setUp(self):
        """
        Create temporary directory for test recipes.
        """
        self.test_dir = tempfile.mkdtemp()
        self.recipe_file = Path(self.test_dir) / "tasktree.yaml"

    def tearDown(self):
        """
        Clean up temporary directory.
        """
        import shutil

        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_all_builtin_variables_in_command(self):
        """
        Test that all 8 built-in variables work in task commands.
        """
        copy_fixture_files("builtin_vars_all", Path(self.test_dir))

        # Parse recipe and execute task
        recipe = parse_recipe(self.recipe_file)
        state = StateManager(recipe.project_root)
        state.load()
        executor = Executor(recipe, state, logger_stub, make_process_runner)
        executor.execute_task("test-vars", TaskOutputTypes.ALL)

        # Read output and verify
        output_file = Path(self.test_dir) / "output.txt"
        output = output_file.read_text()
        lines = {
            line.split("=", 1)[0]: line.split("=", 1)[1]
            for line in output.strip().split("\n")
        }

        # Verify all variables were substituted
        self.assertIn("project_root", lines)
        self.assertEqual(lines["project_root"], str(recipe.project_root.resolve()))

        self.assertIn("recipe_dir", lines)
        self.assertEqual(lines["recipe_dir"], str(self.recipe_file.parent.resolve()))

        self.assertIn("task_name", lines)
        self.assertEqual(lines["task_name"], "test-vars")

        self.assertIn("working_dir", lines)
        self.assertEqual(lines["working_dir"], str(recipe.project_root.resolve()))

        self.assertIn("timestamp", lines)
        # Verify ISO8601 format
        self.assertRegex(lines["timestamp"], r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")

        self.assertIn("timestamp_unix", lines)
        # Verify Unix timestamp is numeric
        self.assertTrue(lines["timestamp_unix"].isdigit())

        self.assertIn("user_home", lines)
        # Verify it's a valid directory path
        self.assertTrue(Path(lines["user_home"]).is_absolute())

        self.assertIn("user_name", lines)
        # Verify we got some username (could be from os.getlogin() or env var)
        self.assertTrue(len(lines["user_name"]) > 0)

    def test_timestamp_consistency_within_task(self):
        """
        Test that timestamp is consistent throughout a single task execution.
        """
        copy_fixture_files("builtin_vars_timestamps", Path(self.test_dir))

        recipe = parse_recipe(self.recipe_file)
        state = StateManager(recipe.project_root)
        state.load()
        executor = Executor(recipe, state, logger_stub, make_process_runner)
        executor.execute_task("test-timestamp", TaskOutputTypes.ALL)

        output_file = Path(self.test_dir) / "timestamps.txt"
        output = output_file.read_text()
        lines = output.strip().split("\n")

        # All timestamps should be identical
        self.assertEqual(lines[0], lines[1], "ISO timestamps should be consistent")
        self.assertEqual(lines[2], lines[3], "Unix timestamps should be consistent")

    def test_builtin_vars_with_working_dir(self):
        """
        Test that tt.working_dir reflects the task's working_dir setting.
        """
        copy_fixture_files("builtin_vars_working_dir", Path(self.test_dir))

        # Create subdirectory (required by the task's working_dir setting)
        subdir = Path(self.test_dir) / "subdir"
        subdir.mkdir()

        recipe = parse_recipe(self.recipe_file)
        state = StateManager(recipe.project_root)
        state.load()
        executor = Executor(recipe, state, logger_stub, make_process_runner)
        executor.execute_task("test-workdir", TaskOutputTypes.ALL)

        output = (Path(self.test_dir) / "working_dir.txt").read_text().strip()
        # Should show the absolute path to subdir
        self.assertEqual(output, str(subdir.resolve()))

    def test_builtin_vars_in_multiline_command(self):
        """
        Test that built-in variables work in multi-line commands.
        """
        copy_fixture_files("builtin_vars_multiline", Path(self.test_dir))

        recipe = parse_recipe(self.recipe_file)
        state = StateManager(recipe.project_root)
        state.load()
        executor = Executor(recipe, state, logger_stub, make_process_runner)
        executor.execute_task("test-multiline", TaskOutputTypes.ALL)

        output = (Path(self.test_dir) / "multiline.txt").read_text().strip()
        expected = f"{recipe.project_root.resolve()}/test-multiline"
        self.assertEqual(output, expected)

    def test_recipe_dir_differs_from_project_root_when_recipe_in_subdir(self):
        """
        Test that recipe_dir points to recipe file location, not project root.
        """
        copy_fixture_files("builtin_vars_recipe_in_subdir", Path(self.test_dir))

        recipe_path = Path(self.test_dir) / "config" / "tasks.yaml"
        recipe_subdir = recipe_path.parent

        # Parse with explicit project_root (current directory)
        recipe = parse_recipe(recipe_path, project_root=Path(self.test_dir))
        state = StateManager(recipe.project_root)
        state.load()
        executor = Executor(recipe, state, logger_stub, make_process_runner)
        executor.execute_task("test-recipe-dir", TaskOutputTypes.ALL)

        output = (Path(self.test_dir) / "recipe_dir.txt").read_text()
        lines = {
            line.split("=", 1)[0]: line.split("=", 1)[1]
            for line in output.strip().split("\n")
        }

        # project_root should be test_dir
        self.assertEqual(lines["project"], str(Path(self.test_dir).resolve()))
        # recipe_dir should be the subdirectory
        self.assertEqual(lines["recipe"], str(recipe_subdir.resolve()))

    def test_builtin_vars_mixed_with_other_vars(self):
        """
        Test built-in variables work alongside regular variables and arguments.
        """
        copy_fixture_files("builtin_vars_mixed_vars", Path(self.test_dir))

        recipe = parse_recipe(self.recipe_file)
        state = StateManager(recipe.project_root)
        state.load()
        executor = Executor(recipe, state, logger_stub, make_process_runner)
        executor.execute_task(
            "deploy", TaskOutputTypes.ALL, args_dict={"region": "us-west-1"}
        )

        output = (Path(self.test_dir) / "mixed.txt").read_text()
        lines = [line for line in output.strip().split("\n")]

        self.assertIn(f"Deploying from {recipe.project_root.resolve()}", lines[0])
        self.assertIn("Task: deploy", lines[1])
        self.assertIn("Server: prod.example.com", lines[2])
        self.assertIn("Region: us-west-1", lines[3])
        # User should be present (from tt.user_name)
        self.assertTrue(lines[4].startswith("User: "))

    def test_builtin_vars_in_working_dir(self):
        """
        Test that non-circular builtin variables can be used in working_dir.
        """
        copy_fixture_files("builtin_vars_in_working_dir_field", Path(self.test_dir))

        # Create a directory that matches the task name
        task_dir = Path(self.test_dir) / "build-task"
        task_dir.mkdir()

        recipe = parse_recipe(self.recipe_file)
        state = StateManager(recipe.project_root)
        state.load()
        executor = Executor(recipe, state, logger_stub, make_process_runner)
        executor.execute_task("build-task", TaskOutputTypes.ALL)

        output = (Path(self.test_dir) / "result.txt").read_text()
        lines = {
            line.split("=", 1)[0]: line.split("=", 1)[1]
            for line in output.strip().split("\n")
        }

        # Verify task_name was substituted in working_dir
        self.assertEqual(lines["task"], "build-task")
        # Verify working_dir reflects the actual resolved path
        self.assertEqual(lines["wd"], str(task_dir.resolve()))

    def test_builtin_vars_in_runner_volumes(self):
        """
        Test that builtin variables are substituted in runner volume mounts.
        """

        from unittest.mock import patch, Mock

        copy_fixture_files("builtin_vars_runner_volumes", Path(self.test_dir))

        # Parse recipe
        recipe = parse_recipe(self.recipe_file)
        state = StateManager(recipe.project_root)
        state.load()

        # Mock the docker subprocess calls to capture the command
        docker_run_command = None

        def mock_run(*args, **kwargs):
            nonlocal docker_run_command
            cmd = args[0] if args else kwargs.get("args", [])
            if isinstance(cmd, list) and "run" in cmd:
                docker_run_command = cmd
            # Mock return values
            if isinstance(cmd, list) and "inspect" in cmd:
                result = Mock()
                result.stdout = "sha256:test123\\n"
                result.returncode = 0
                return result
            result = Mock()
            result.returncode = 0
            return result

        process_runner_spy = MagicMock(spec=ProcessRunner)
        process_runner_spy.run.side_effect = mock_run

        fake_proc_runner_factory = MagicMock()
        fake_proc_runner_factory.return_value = process_runner_spy

        executor = Executor(recipe, state, logger_stub, fake_proc_runner_factory)

        # Still need to mock subprocess.run because it's used to docker inspect
        with patch("tasktree.process_runner.subprocess.run", side_effect=mock_run):
            # Execute task
            executor.execute_task("docker-test", TaskOutputTypes.ALL)

        # Verify that volumes were substituted
        self.assertIsNotNone(
            docker_run_command, "Docker run command should have been captured"
        )

        # Find volume mounts in command
        volume_mounts = []
        for i, arg in enumerate(docker_run_command):
            if arg == "-v" and i + 1 < len(docker_run_command):
                volume_mounts.append(docker_run_command[i + 1])

        # Verify volumes contain absolute paths, not template strings
        self.assertTrue(
            len(volume_mounts) >= 2,
            f"Expected at least 2 volume mounts, got {len(volume_mounts)}",
        )

        # Check that tt.project_root was substituted
        project_root_str = str(recipe.project_root.resolve())
        self.assertTrue(
            any(project_root_str in vol for vol in volume_mounts),
            f"Expected project root '{project_root_str}' in volumes, got: {volume_mounts}",
        )

        # Verify no literal template strings remain
        for vol in volume_mounts:
            self.assertNotIn(
                "{{ tt.",
                vol,
                f"Volume mount should not contain template strings: {vol}",
            )

        # Find environment variables in command
        env_vars = {}
        for i, arg in enumerate(docker_run_command):
            if arg == "-e" and i + 1 < len(docker_run_command):
                env_pair = docker_run_command[i + 1]
                if "=" in env_pair:
                    key, value = env_pair.split("=", 1)
                    env_vars[key] = value

        # Verify environment variables were substituted
        self.assertIn(
            "PROJECT_PATH", env_vars, "PROJECT_PATH env var should be present"
        )
        self.assertEqual(
            env_vars["PROJECT_PATH"],
            project_root_str,
            "PROJECT_PATH should contain the resolved project root",
        )

        self.assertIn("TASK_NAME_VAR", env_vars, "TASK_NAME_VAR should be present")
        self.assertEqual(
            env_vars["TASK_NAME_VAR"],
            "docker-test",
            "TASK_NAME_VAR should contain the task name",
        )

    def test_env_vars_in_runner_fields(self):
        """
        Test that {{ env.* }} variables are substituted in runner fields.
        """

        from unittest.mock import patch, Mock

        # Set test environment variable
        os.environ["TEST_MOUNT_PATH"] = "/test/mount"
        os.environ["TEST_ENV_VALUE"] = "test-value"

        try:
            copy_fixture_files("builtin_vars_env_in_runner", Path(self.test_dir))

            # Parse recipe
            recipe = parse_recipe(self.recipe_file)
            state = StateManager(recipe.project_root)
            state.load()
            executor = Executor(recipe, state, logger_stub, make_process_runner)

            # Mock the docker subprocess calls to capture the command
            docker_run_command = None

            def mock_run(*args, **kwargs):
                nonlocal docker_run_command
                cmd = args[0] if args else kwargs.get("args", [])
                if isinstance(cmd, list) and "run" in cmd:
                    docker_run_command = cmd
                # Mock return values
                if isinstance(cmd, list) and "inspect" in cmd:
                    result = Mock()
                    result.stdout = "sha256:test123\\n"
                    result.returncode = 0
                    return result
                result = Mock()
                result.returncode = 0
                return result

            with patch("tasktree.docker.subprocess.run", side_effect=mock_run):
                # Execute task
                executor.execute_task("docker-test", TaskOutputTypes.ALL)

            # Verify that volumes were substituted
            self.assertIsNotNone(
                docker_run_command, "Docker run command should have been captured"
            )

            # Find volume mounts in command
            volume_mounts = []
            for i, arg in enumerate(docker_run_command):
                if arg == "-v" and i + 1 < len(docker_run_command):
                    volume_mounts.append(docker_run_command[i + 1])

            # Verify volumes contain the substituted env var, not template strings
            self.assertTrue(
                len(volume_mounts) >= 1,
                f"Expected at least 1 volume mount, got {len(volume_mounts)}",
            )
            self.assertTrue(
                any("/test/mount" in vol for vol in volume_mounts),
                f"Expected '/test/mount' in volumes, got: {volume_mounts}",
            )

            # Verify no literal template strings remain
            for vol in volume_mounts:
                self.assertNotIn(
                    "{{ env.",
                    vol,
                    f"Volume mount should not contain template strings: {vol}",
                )

            # Find environment variables in command
            env_vars = {}
            for i, arg in enumerate(docker_run_command):
                if arg == "-e" and i + 1 < len(docker_run_command):
                    env_pair = docker_run_command[i + 1]
                    if "=" in env_pair:
                        key, value = env_pair.split("=", 1)
                        env_vars[key] = value

            # Verify environment variables were substituted
            self.assertIn(
                "ENV_VAR_VALUE", env_vars, "ENV_VAR_VALUE env var should be present"
            )
            self.assertEqual(
                env_vars["ENV_VAR_VALUE"],
                "test-value",
                "ENV_VAR_VALUE should contain the substituted environment variable",
            )
        finally:
            # Clean up test environment variables
            os.environ.pop("TEST_MOUNT_PATH", None)
            os.environ.pop("TEST_ENV_VALUE", None)

    def test_var_vars_in_runner_fields(self):
        """
        Test that {{ var.* }} variables are substituted in runner fields.
        """

        from unittest.mock import patch, Mock

        copy_fixture_files("builtin_vars_var_in_runner", Path(self.test_dir))

        # Parse recipe
        recipe = parse_recipe(self.recipe_file)
        state = StateManager(recipe.project_root)
        state.load()
        executor = Executor(recipe, state, logger_stub, make_process_runner)

        # Mock the docker subprocess calls to capture the command
        docker_run_command = None

        def mock_run(*args, **kwargs):
            nonlocal docker_run_command
            cmd = args[0] if args else kwargs.get("args", [])
            if isinstance(cmd, list) and "run" in cmd:
                docker_run_command = cmd
            # Mock return values
            if isinstance(cmd, list) and "inspect" in cmd:
                result = Mock()
                result.stdout = "sha256:test123\\n"
                result.returncode = 0
                return result
            result = Mock()
            result.returncode = 0
            return result

        with patch("tasktree.docker.subprocess.run", side_effect=mock_run):
            # Execute task
            executor.execute_task("docker-test", TaskOutputTypes.ALL)

        # Verify that volumes were substituted
        self.assertIsNotNone(
            docker_run_command, "Docker run command should have been captured"
        )

        # Find volume mounts in command
        volume_mounts = []
        for i, arg in enumerate(docker_run_command):
            if arg == "-v" and i + 1 < len(docker_run_command):
                volume_mounts.append(docker_run_command[i + 1])

        # Verify volumes contain the substituted var, not template strings
        self.assertTrue(
            len(volume_mounts) >= 1,
            f"Expected at least 1 volume mount, got {len(volume_mounts)}",
        )
        self.assertTrue(
            any("/var/data" in vol for vol in volume_mounts),
            f"Expected '/var/data' in volumes, got: {volume_mounts}",
        )

        # Verify no literal template strings remain
        for vol in volume_mounts:
            self.assertNotIn(
                "{{ var.",
                vol,
                f"Volume mount should not contain template strings: {vol}",
            )

        # Find environment variables in command
        env_vars = {}
        for i, arg in enumerate(docker_run_command):
            if arg == "-e" and i + 1 < len(docker_run_command):
                env_pair = docker_run_command[i + 1]
                if "=" in env_pair:
                    key, value = env_pair.split("=", 1)
                    env_vars[key] = value

        # Verify environment variables were substituted
        self.assertIn("VAR_VALUE", env_vars, "VAR_VALUE env var should be present")
        self.assertEqual(
            env_vars["VAR_VALUE"],
            "config-value",
            "VAR_VALUE should contain the substituted variable",
        )


if __name__ == "__main__":
    unittest.main()
