"""Tests for executor module."""

import os
import platform
import tempfile
import time
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import MagicMock, patch, call

from helpers.logging import logger_stub
from tasktree.executor import Executor
from tasktree.parser import Recipe, Task, parse_recipe
from tasktree.process_runner import ProcessRunner, TaskOutputTypes, make_process_runner
from tasktree.state import StateManager, TaskState


class TestTaskStatus(unittest.TestCase):
    """
    """

    def test_check_never_run(self):
        """
        Test status for task that has never run.
        With new behavior: tasks with no inputs always run with reason "no_inputs".
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {
                "build": Task(name="build", cmd="cargo build", outputs=["target/bin"])
            }
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            status = executor.check_task_status(
                tasks["build"],
                {},
                make_process_runner(TaskOutputTypes.ALL, logger_stub),
                False,
            )
            self.assertTrue(status.will_run)
            self.assertEqual(status.reason, "no_inputs")  # Changed from "never_run"

    def test_check_no_inputs(self):
        """
        Test status for task with no inputs (always runs).
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {"test": Task(name="test", cmd="cargo test")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            process_runner = make_process_runner(TaskOutputTypes.ALL, logger_stub)

            status = executor.check_task_status(
                tasks["test"], {}, process_runner, False
            )
            self.assertTrue(status.will_run)
            self.assertEqual(status.reason, "no_inputs")

    def test_check_fresh(self):
        """
        Test status for task that is fresh.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create input file
            input_file = project_root / "input.txt"
            input_file.write_text("hello")

            # Create output file (task has run successfully before)
            output_file = project_root / "output.txt"
            output_file.write_text("output")

            # Create state with old mtime
            state_manager = StateManager(project_root)
            from tasktree.hasher import hash_task, make_cache_key

            task = Task(
                name="build",
                cmd="cat input.txt",
                inputs=["input.txt"],
                outputs=["output.txt"],
            )
            task_hash = hash_task(
                task.cmd, task.outputs, task.working_dir, task.args, "__platform_default__", task.deps
            )
            cache_key = make_cache_key(task_hash)

            # Set state with current mtime
            current_mtime = input_file.stat().st_mtime
            state_manager.set(
                cache_key,
                TaskState(
                    last_run=time.time(), input_state={"input.txt": current_mtime}
                ),
            )

            tasks = {"build": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            status = executor.check_task_status(
                task, {}, make_process_runner(TaskOutputTypes.ALL, logger_stub)
            )
            self.assertFalse(status.will_run)
            self.assertEqual(status.reason, "fresh")


class TestExecutor(unittest.TestCase):
    """
    """

    def test_execute_simple_task(self):
        """
        Test executing a simple task.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {"build": Task(name="build", cmd="cargo build")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            process_runner_spy = MagicMock(spec=ProcessRunner)
            fake_proc_runner_factory = MagicMock()
            fake_proc_runner_factory.return_value = process_runner_spy

            Executor(
                recipe, state_manager, logger_stub, fake_proc_runner_factory
            ).execute_task("build", TaskOutputTypes.ALL)

            # Verify subprocess was called with shell_cmd + [script_path]
            process_runner_spy.run.assert_called_once()
            call_args = process_runner_spy.run.call_args
            run_cmd = call_args[0][0]
            # Script path is the last element; shell is the first
            script_path = run_cmd[-1]
            self.assertTrue(script_path.endswith(".bat") or not script_path.endswith(".sh"))

    def test_execute_with_dependencies(self):
        """
        Test executing task with dependencies.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {
                "lint": Task(name="lint", cmd="cargo clippy"),
                "build": Task(name="build", cmd="cargo build", deps=["lint"]),
            }
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            process_runner_spy = MagicMock(spec=ProcessRunner)
            fake_proc_runner_factory = MagicMock()
            fake_proc_runner_factory.return_value = process_runner_spy

            Executor(
                recipe, state_manager, logger_stub, fake_proc_runner_factory
            ).execute_task("build", TaskOutputTypes.ALL)

            # Verify both tasks were executed
            self.assertEqual(process_runner_spy.run.call_count, 2)

    def test_execute_with_args(self):
        """
        Test executing task with arguments.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {
                "deploy": Task(
                    name="deploy",
                    cmd="echo Deploying to {{ arg.environment }}",
                    args=["environment"],
                )
            }
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            process_runner_spy = MagicMock(spec=ProcessRunner)
            fake_proc_runner_factory = MagicMock()
            fake_proc_runner_factory.return_value = process_runner_spy

            executor = Executor(
                recipe, state_manager, logger_stub, fake_proc_runner_factory
            )

            executor.execute_task(
                "deploy", TaskOutputTypes.ALL, {"environment": "production"}
            )

            # Verify command was invoked as shell_cmd + [script_path]
            call_args = process_runner_spy.run.call_args
            run_cmd = call_args[0][0]
            # Script path is the last element; check it's a valid file path, not a shell name
            self.assertGreater(len(run_cmd), 1, "Should have at least shell + script_path")

    @patch("tasktree.temp_script.os.unlink")
    def test_run_command_as_script_single_line(self, mock_unlink):
        """
        Test _run_command_as_script with single-line command.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {"test": Task(name="test", cmd="echo hello")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            process_runner_spy = MagicMock(spec=ProcessRunner)

            # Call the unified method directly
            executor._run_command_as_script(
                cmd="echo hello",
                working_dir=project_root,
                task_name="test",
                shell_cmd=["bash"],
                preamble="",
                process_runner=process_runner_spy,
            )

            # Verify subprocess.run was called with shell_cmd + [script_path]
            process_runner_spy.run.assert_called_once()
            call_args = process_runner_spy.run.call_args
            run_cmd = call_args[0][0]
            self.assertEqual(run_cmd[0], "bash")
            script_path = run_cmd[-1]
            # bash uses no platform-specific extension on any platform
            self.assertFalse(script_path.endswith(".bat"))
            self.assertFalse(script_path.endswith(".sh"))

            # No chmod needed — script is not run directly
            # Verify cleanup (unlink) was called
            mock_unlink.assert_called_once()

    @patch("tasktree.temp_script.os.unlink")
    def test_run_command_as_script_with_preamble(self, unlink_spy):
        """
        Test _run_command_as_script with preamble.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {"test": Task(name="test", cmd="echo hello")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            process_runner_spy = MagicMock(spec=ProcessRunner)

            # Call with preamble
            executor._run_command_as_script(
                cmd="echo hello",
                working_dir=project_root,
                task_name="test",
                shell_cmd=["bash"],
                preamble="set -e\n",
                process_runner=process_runner_spy,
            )

            process_runner_spy.run.assert_called_once()
            unlink_spy.assert_called_once()

    @patch("tasktree.temp_script.os.unlink")
    def test_run_command_as_script_multiline(self, unlink_spy):
        """
        Test _run_command_as_script with multi-line command.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {"test": Task(name="test", cmd="echo hello\necho world")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            process_runner_spy = MagicMock(spec=ProcessRunner)

            executor._run_command_as_script(
                cmd="echo hello\necho world",
                working_dir=project_root,
                task_name="test",
                shell_cmd=["bash"],
                preamble="",
                process_runner=process_runner_spy,
            )

            process_runner_spy.run.assert_called_once()
            unlink_spy.assert_called_once()

    def test_run_command_as_script_comprehensive_validation(self):
        """
        Comprehensive test validating script creation, content, and execution.

        This test validates:
        1. Script is created with no extension (on Unix)
        2. No shebang is written — interpreter is in shell_cmd, not script
        3. Script content has correct ordering (preamble -> command)
        4. ProcessRunner is called with shell_cmd + [script_path]
        5. Script exists when subprocess is called
        """

        # Skip on Windows (uses .bat extension, different behaviour)
        if platform.system() == "Windows":
            self.skipTest("Skipping on Windows - uses .bat extension")

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {"test": Task(name="test", cmd="echo hello\necho world")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            captured_script_path = None
            captured_script_content = None

            def mock_subprocess_run(*args, **kwargs):
                # Capture script path (last element of cmd list) and content
                nonlocal captured_script_path, captured_script_content
                script_path = args[0][-1]
                captured_script_path = script_path
                self.assertTrue(
                    Path(script_path).exists(),
                    "Script should exist when subprocess.run is called",
                )
                with open(script_path, "r") as f:
                    captured_script_content = f.read()
                return MagicMock(returncode=0)

            process_runner = make_process_runner(TaskOutputTypes.ALL, logger_stub)

            with patch("subprocess.run", side_effect=mock_subprocess_run):
                executor._run_command_as_script(
                    cmd="echo hello\necho world",
                    working_dir=project_root,
                    task_name="test",
                    shell_cmd=["bash"],
                    preamble="set -e\n",
                    process_runner=process_runner,
                )

            # Requirement 1: Script has no extension on Unix
            self.assertIsNotNone(captured_script_path, "Script path should be captured")
            self.assertFalse(
                captured_script_path.endswith(".sh"),
                f"Script should NOT have .sh suffix on Unix, got: {captured_script_path}",
            )

            # Requirement 2: No shebang in script content
            self.assertIsNotNone(captured_script_content, "Script content should be captured")
            self.assertFalse(
                captured_script_content.startswith("#!"),
                "Script should NOT have a shebang (interpreter is in shell_cmd)",
            )

            # Requirement 3: Preamble before command in script content
            self.assertIn("set -e", captured_script_content, "Preamble should be in script")
            self.assertIn("echo hello", captured_script_content, "Command should be in script")
            self.assertIn("echo world", captured_script_content, "Command should be in script")
            preamble_idx = captured_script_content.find("set -e")
            command_idx = captured_script_content.find("echo hello")
            self.assertLess(preamble_idx, command_idx, "Preamble should come before command")

            # Requirement 4: subprocess called with shell_cmd + [script_path]
            # (Verified implicitly by mock_subprocess_run receiving args[0][-1] as script)

    @patch("tasktree.temp_script.os.unlink")
    @unittest.skipUnless(platform.system() == "Windows", "Windows-only test")
    def test_run_command_as_script_uses_powershell_cmd_on_windows(self, mock_unlink):
        """
        Test _run_command_as_script passes shell_cmd + [script_path] to subprocess.

        On Windows with a PowerShell shell_cmd, the invocation should be
        [powershell, -ExecutionPolicy, Bypass, -File, script_path].
        """
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {"test": Task(name="test", cmd="Write-Output hello")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            process_runner_spy = MagicMock(spec=ProcessRunner)

            executor._run_command_as_script(
                cmd="Write-Output hello",
                working_dir=project_root,
                task_name="test",
                shell_cmd=["powershell", "-ExecutionPolicy", "Bypass", "-File"],
                preamble="",
                process_runner=process_runner_spy,
            )

            process_runner_spy.run.assert_called_once()
            run_cmd = process_runner_spy.run.call_args[0][0]
            self.assertEqual(run_cmd[0], "powershell")
            self.assertIn("-File", run_cmd)
            self.assertTrue(run_cmd[-1].endswith(".ps1"))


class TestMissingOutputs(unittest.TestCase):
    """
    """

    def test_fresh_task_with_all_outputs_present(self):
        """
        Test that fresh task with all outputs present should skip.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create output file
            output_file = project_root / "output.txt"
            output_file.write_text("output")

            # Create state
            state_manager = StateManager(project_root)
            from tasktree.hasher import hash_task, make_cache_key

            task = Task(
                name="build",
                cmd="echo test > output.txt",
                outputs=["output.txt"],
            )
            task_hash = hash_task(
                task.cmd, task.outputs, task.working_dir, task.args, "__platform_default__", task.deps
            )
            cache_key = make_cache_key(task_hash)

            # Set state with recent run
            state_manager.set(
                cache_key,
                TaskState(last_run=time.time(), input_state={}),
            )

            tasks = {"build": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            process_runner = make_process_runner(TaskOutputTypes.ALL, logger_stub)

            status = executor.check_task_status(task, {}, process_runner)
            # Task has no inputs, so it always runs (even with fresh outputs)
            self.assertTrue(status.will_run)
            self.assertEqual(status.reason, "no_inputs")

    def test_fresh_task_with_missing_output(self):
        """
        Test that task with no inputs always runs with reason "no_inputs".
        (Even when outputs are missing - "no_inputs" check happens first)
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Do NOT create output file - it's missing

            # Create state (task ran before)
            state_manager = StateManager(project_root)
            from tasktree.hasher import hash_task, make_cache_key

            task = Task(
                name="build",
                cmd="echo test > output.txt",
                outputs=["output.txt"],
            )
            task_hash = hash_task(
                task.cmd, task.outputs, task.working_dir, task.args, "__platform_default__", task.deps
            )
            cache_key = make_cache_key(task_hash)

            # Set state with recent run
            state_manager.set(
                cache_key,
                TaskState(last_run=time.time(), input_state={}),
            )

            tasks = {"build": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            process_runner = make_process_runner(TaskOutputTypes.ALL, logger_stub)

            status = executor.check_task_status(task, {}, process_runner)
            self.assertTrue(status.will_run)
            self.assertEqual(status.reason, "no_inputs")  # Changed from "outputs_missing"

    def test_fresh_task_with_partial_outputs(self):
        """
        Test that task with no inputs always runs with reason "no_inputs".
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create only one of two outputs
            output1 = project_root / "output1.txt"
            output1.write_text("output1")
            # output2.txt is missing

            state_manager = StateManager(project_root)
            from tasktree.hasher import hash_task, make_cache_key

            task = Task(
                name="build",
                cmd="echo test",
                outputs=["output1.txt", "output2.txt"],
            )
            task_hash = hash_task(
                task.cmd, task.outputs, task.working_dir, task.args, "__platform_default__", task.deps
            )
            cache_key = make_cache_key(task_hash)

            state_manager.set(
                cache_key,
                TaskState(last_run=time.time(), input_state={}),
            )

            tasks = {"build": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            process_runner = make_process_runner(TaskOutputTypes.ALL, logger_stub)

            status = executor.check_task_status(task, {}, process_runner)
            self.assertTrue(status.will_run)
            self.assertEqual(status.reason, "no_inputs")  # Changed from "outputs_missing"

    def test_task_with_no_state_should_not_warn_about_outputs(self):
        """
        Test that task with no inputs uses "no_inputs" reason.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            task = Task(
                name="build",
                cmd="echo test > output.txt",
                outputs=["output.txt"],
            )

            tasks = {"build": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            process_runner = make_process_runner(TaskOutputTypes.ALL, logger_stub)

            status = executor.check_task_status(task, {}, process_runner)
            self.assertTrue(status.will_run)
            self.assertEqual(status.reason, "no_inputs")  # Changed from "never_run"

    def test_task_with_no_inputs_always_runs(self):
        """
        Test that tasks with no inputs always run.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            task = Task(name="test", cmd="echo test")  # No inputs

            tasks = {"test": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            process_runner = make_process_runner(TaskOutputTypes.ALL, logger_stub)

            status = executor.check_task_status(task, {}, process_runner)
            self.assertTrue(status.will_run)
            self.assertEqual(status.reason, "no_inputs")  # Always runs

    def test_output_glob_pattern_with_working_dir(self):
        """
        Test that output patterns resolve correctly with working_dir.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create subdirectory
            subdir = project_root / "subdir"
            subdir.mkdir()

            # Create output in subdirectory
            output_file = subdir / "output.txt"
            output_file.write_text("output")

            state_manager = StateManager(project_root)
            from tasktree.hasher import hash_task, make_cache_key

            task = Task(
                name="build",
                cmd="echo test > output.txt",
                working_dir="subdir",
                outputs=["output.txt"],
            )
            task_hash = hash_task(
                task.cmd, task.outputs, task.working_dir, task.args, "__platform_default__", task.deps
            )
            cache_key = make_cache_key(task_hash)

            state_manager.set(
                cache_key,
                TaskState(last_run=time.time(), input_state={}),
            )

            tasks = {"build": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            process_runner = make_process_runner(TaskOutputTypes.ALL, logger_stub)

            status = executor.check_task_status(task, {}, process_runner)
            # Task has no inputs, so it always runs (even with fresh outputs)
            self.assertTrue(status.will_run)
            self.assertEqual(status.reason, "no_inputs")

    def test_output_glob_pattern_no_matches(self):
        """
        Test that task with no inputs always runs with reason "no_inputs".
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create dist directory but no .deb files
            dist_dir = project_root / "dist"
            dist_dir.mkdir()

            state_manager = StateManager(project_root)
            from tasktree.hasher import hash_task, make_cache_key

            task = Task(
                name="package",
                cmd="create-deb",
                outputs=["dist/*.deb"],
            )
            task_hash = hash_task(
                task.cmd, task.outputs, task.working_dir, task.args, "__platform_default__", task.deps
            )
            cache_key = make_cache_key(task_hash)

            state_manager.set(
                cache_key,
                TaskState(last_run=time.time(), input_state={}),
            )

            tasks = {"package": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            process_runner = make_process_runner(TaskOutputTypes.ALL, logger_stub)

            status = executor.check_task_status(task, {}, process_runner)
            self.assertTrue(status.will_run)
            self.assertEqual(status.reason, "no_inputs")  # Changed from "outputs_missing"


class TestExecutorErrors(unittest.TestCase):
    """
    Tests for executor error conditions.
    """

    def test_execute_subprocess_failure(self):
        """
        Test ExecutionError raised when subprocess fails.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            recipe_path = project_root / "tasktree.yaml"
            recipe_path.write_text("""
tasks:
  fail:
    cmd: exit 1
""")

            from tasktree.executor import ExecutionError, Executor
            from tasktree.parser import parse_recipe
            from tasktree.state import StateManager

            recipe = parse_recipe(recipe_path)
            state_manager = StateManager(project_root)
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            with self.assertRaises(ExecutionError) as cm:
                executor.execute_task("fail", TaskOutputTypes.ALL, {})
            self.assertIn("exit code", str(cm.exception).lower())

    def test_execute_working_dir_not_found(self):
        """
        Test error when working directory doesn't exist.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            recipe_path = project_root / "tasktree.yaml"
            recipe_path.write_text("""
tasks:
  test:
    working_dir: nonexistent_directory
    cmd: echo "test"
""")

            from tasktree.executor import ExecutionError, Executor
            from tasktree.parser import parse_recipe
            from tasktree.state import StateManager

            recipe = parse_recipe(recipe_path)
            state_manager = StateManager(project_root)
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            with self.assertRaises((ExecutionError, FileNotFoundError, OSError)):
                executor.execute_task("test", TaskOutputTypes.ALL, {})

    def test_execute_command_not_found(self):
        """
        Test error when command doesn't exist.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            recipe_path = project_root / "tasktree.yaml"
            recipe_path.write_text("""
tasks:
  test:
    cmd: nonexistent_command_12345
""")

            from tasktree.executor import ExecutionError, Executor
            from tasktree.parser import parse_recipe
            from tasktree.state import StateManager

            recipe = parse_recipe(recipe_path)
            state_manager = StateManager(project_root)
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            with self.assertRaises(ExecutionError):
                executor.execute_task("test", TaskOutputTypes.ALL, {})

    @unittest.skipUnless(platform.system() != "Windows", "Unix file permission enforcement not applicable on Windows")
    def test_execute_permission_denied(self):
        """
        Test error when command not executable.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create a script file without execute permissions
            script_path = project_root / "script.sh"
            script_path.write_text("#!/bin/bash\necho test")
            script_path.chmod(0o644)  # Read/write but not execute

            recipe_path = project_root / "tasktree.yaml"
            recipe_path.write_text(f"""
tasks:
  test:
    cmd: {script_path}
""")

            from tasktree.executor import ExecutionError, Executor
            from tasktree.parser import parse_recipe
            from tasktree.state import StateManager

            recipe = parse_recipe(recipe_path)
            state_manager = StateManager(project_root)
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            with self.assertRaises((ExecutionError, PermissionError, OSError)):
                executor.execute_task("test", TaskOutputTypes.ALL, {})

    def test_builtin_working_dir_in_working_dir_raises_error(self):
        """
        Test that using {{ tt.working_dir }} in working_dir raises clear error.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            recipe_path = project_root / "tasktree.yaml"
            recipe_path.write_text("""
tasks:
  test:
    working_dir: "{{ tt.working_dir }}/subdir"
    cmd: echo "test"
""")

            from tasktree.executor import ExecutionError, Executor
            from tasktree.parser import parse_recipe
            from tasktree.state import StateManager

            recipe = parse_recipe(recipe_path)
            state_manager = StateManager(project_root)
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            with self.assertRaises(ExecutionError) as cm:
                executor.execute_task("test", TaskOutputTypes.ALL, {})

            error_msg = str(cm.exception)
            self.assertIn("Cannot use {{ tt.working_dir }}", error_msg)
            self.assertIn("circular dependency", error_msg)

    def test_other_builtin_vars_in_working_dir_allowed(self):
        """
        Test that non-circular builtin vars like {{ tt.task_name }} work in working_dir.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create directory using task name
            task_subdir = project_root / "test-task"
            task_subdir.mkdir()

            recipe_path = project_root / "tasktree.yaml"
            recipe_path.write_text("""
tasks:
  test-task:
    working_dir: "{{ tt.task_name }}"
    cmd: pwd
""")

            from tasktree.executor import Executor
            from tasktree.parser import parse_recipe
            from tasktree.state import StateManager

            recipe = parse_recipe(recipe_path)
            state_manager = StateManager(project_root)
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Should not raise - tt.task_name is allowed in working_dir
            executor.execute_task("test-task", TaskOutputTypes.ALL, {})


class TestExecutorPrivateMethods(unittest.TestCase):
    """
    Tests for executor private methods.
    """

    def test_substitute_args_single(self):
        """
        Test substituting single argument.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {"deploy": Task(name="deploy", cmd="echo {{ arg.environment }}")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            result = executor._substitute_args(
                "echo {{ arg.environment }}", {"environment": "production"}
            )
            self.assertEqual(result, "echo production")

    def test_substitute_args_multiple(self):
        """
        Test substituting multiple arguments.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {
                "deploy": Task(
                    name="deploy", cmd="deploy {{ arg.app }} to {{ arg.region }}"
                )
            }
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            result = executor._substitute_args(
                "deploy {{ arg.app }} to {{ arg.region }}",
                {"app": "myapp", "region": "us-east-1"},
            )
            self.assertEqual(result, "deploy myapp to us-east-1")

    def test_substitute_args_missing_placeholder(self):
        """
        Test raises error when arg not provided.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {
                "deploy": Task(
                    name="deploy", cmd="echo {{ arg.environment }} {{ arg.missing }}"
                )
            }
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Missing argument should raise ValueError
            with self.assertRaises(ValueError) as cm:
                executor._substitute_args(
                    "echo {{ arg.environment }} {{ arg.missing }}",
                    {"environment": "production"},
                )
            self.assertIn("missing", str(cm.exception))
            self.assertIn("not defined", str(cm.exception))

    def test_check_inputs_changed_mtime(self):
        """
        Test detects changed file by mtime.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create input file
            input_file = project_root / "input.txt"
            input_file.write_text("original")
            original_mtime = input_file.stat().st_mtime

            # Create state with old mtime
            state_manager = StateManager(project_root)
            task = Task(name="build", cmd="cat input.txt", inputs=["input.txt"])

            # Create cached state with original mtime
            cached_state = TaskState(
                last_run=time.time(),
                input_state={"input.txt": original_mtime - 100},  # Older mtime
            )

            tasks = {"build": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Check if inputs changed
            changed = executor._check_inputs_changed(task, cached_state, ["input.txt"])

            # Should detect change because current mtime > cached mtime
            self.assertEqual(changed, ["input.txt"])

    def test_check_inputs_changed_detects_dep_output_changes_for_runner_task(self):
        """
        Test that changes to dependency output files are detected for tasks using a named runner.
        """
        from tasktree.parser import Runner, ShellConfig

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create the dependency output file
            dep_output = project_root / "dep-output.txt"
            dep_output.write_text("initial content")
            original_mtime = dep_output.stat().st_mtime

            runner = Runner(name="shell", shell=ShellConfig(cmd=["bash", "-c"]))
            task = Task(name="package", cmd="zip pkg.zip dep-output.txt", run_in="shell")
            tasks = {"package": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
                runners={"shell": runner},
            )
            state_manager = StateManager(project_root)
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Cached state records an older mtime, simulating dep output that changed since last run
            cached_state = TaskState(
                last_run=time.time(),
                input_state={"dep-output.txt": original_mtime - 100},
            )

            changed = executor._check_inputs_changed(task, cached_state, ["dep-output.txt"])

            self.assertIn("dep-output.txt", changed)

    def test_check_outputs_missing(self):
        """
        Test detects missing output files.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            # Task declares outputs but files don't exist
            task = Task(
                name="build", cmd="echo test > output.txt", outputs=["output.txt"]
            )

            tasks = {"build": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Check for missing outputs
            missing = executor._check_outputs_missing(task)

            # Should detect output.txt is missing
            self.assertEqual(missing, ["output.txt"])

    def test_expand_globs_multiple_patterns(self):
        """
        Test expanding multiple glob patterns.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create test files
            (project_root / "file1.txt").write_text("test1")
            (project_root / "file2.txt").write_text("test2")
            (project_root / "script.py").write_text("print('test')")

            state_manager = StateManager(project_root)
            tasks = {"test": Task(name="test", cmd="echo test")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Expand multiple patterns
            result = executor._expand_globs(["*.txt", "*.py"], ".")

            # Should find all matching files
            self.assertEqual(set(result), {"file1.txt", "file2.txt", "script.py"})


class TestOnlyMode(unittest.TestCase):
    """
    Test the --only mode that skips dependencies.
    """

    def test_only_mode_skips_dependencies(self):
        """
        Test that only=True executes only the target task, not dependencies.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {
                "lint": Task(name="lint", cmd="echo linting"),
                "build": Task(name="build", cmd="echo building", deps=["lint"]),
            }
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            process_runner_spy = MagicMock(spec=ProcessRunner)
            fake_proc_runner_factory = MagicMock()
            fake_proc_runner_factory.return_value = process_runner_spy

            # Execute with only=True
            statuses = Executor(
                recipe, state_manager, logger_stub, fake_proc_runner_factory
            ).execute_task("build", TaskOutputTypes.ALL, only=True)

            # Verify only build was executed, not lint
            self.assertEqual(process_runner_spy.run.call_count, 1)

            # Verify statuses only contains the target task
            self.assertEqual(len(statuses), 1)
            self.assertIn("build", statuses)
            self.assertNotIn("lint", statuses)

    def test_only_mode_with_multiple_dependencies(self):
        """
        Test that only=True skips all dependencies in a chain.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {
                "lint": Task(name="lint", cmd="echo linting"),
                "build": Task(name="build", cmd="echo building", deps=["lint"]),
                "test": Task(name="test", cmd="echo testing", deps=["build"]),
            }
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            process_runner_spy = MagicMock(spec=ProcessRunner)
            fake_proc_runner_factory = MagicMock()
            fake_proc_runner_factory.return_value = process_runner_spy

            # Execute test with only=True
            statuses = Executor(
                recipe, state_manager, logger_stub, fake_proc_runner_factory
            ).execute_task("test", TaskOutputTypes.ALL, only=True)

            # Verify only test was executed
            self.assertEqual(process_runner_spy.run.call_count, 1)

            # Verify statuses only contains test
            self.assertEqual(len(statuses), 1)
            self.assertIn("test", statuses)
            self.assertNotIn("build", statuses)
            self.assertNotIn("lint", statuses)

    def test_only_mode_forces_execution(self):
        """
        Test that only=True forces execution (ignores freshness).
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create output file
            output_file = project_root / "output.txt"
            output_file.write_text("output")

            # Create state
            state_manager = StateManager(project_root)
            from tasktree.hasher import hash_task, make_cache_key

            task = Task(
                name="build",
                cmd="echo test > output.txt",
                outputs=["output.txt"],
            )
            task_hash = hash_task(
                task.cmd, task.outputs, task.working_dir, task.args, "__platform_default__", task.deps
            )
            cache_key = make_cache_key(task_hash)

            # Set state with recent run
            state_manager.set(
                cache_key,
                TaskState(last_run=time.time(), input_state={}),
            )

            tasks = {"build": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            process_runner_spy = MagicMock(spec=ProcessRunner)
            fake_proc_runner_factory = MagicMock()
            fake_proc_runner_factory.return_value = process_runner_spy

            # Execute with only=True
            statuses = Executor(
                recipe, state_manager, logger_stub, fake_proc_runner_factory
            ).execute_task("build", TaskOutputTypes.ALL, only=True)

            # Verify task was executed despite being fresh (only implies force)
            self.assertEqual(process_runner_spy.run.call_count, 1)
            self.assertTrue(statuses["build"].will_run)
            self.assertEqual(statuses["build"].reason, "forced")


class TestMultilineExecution(unittest.TestCase):
    """
    Test multi-line command execution via temp files.
    """

    def test_multiline_command_content(self):
        """
        Test multi-line command content is written to temp file.
        """

        import platform

        # Skip on Windows (different shell syntax)
        if platform.system() == "Windows":
            self.skipTest("Skipping on Windows - different shell syntax")

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            # Use relative path for output
            multiline_cmd = """echo "line1" > output.txt
echo "line2" >> output.txt
echo "line3" >> output.txt"""

            tasks = {"build": Task(name="build", cmd=multiline_cmd)}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Let the command actually run (no mocking)
            executor.execute_task("build", TaskOutputTypes.ALL)

            # Verify output file was created with all three lines
            output_file = project_root / "output.txt"
            self.assertTrue(output_file.exists())
            content = output_file.read_text()
            self.assertIn("line1", content)
            self.assertIn("line2", content)
            self.assertIn("line3", content)


class TestRunnerResolution(unittest.TestCase):
    """
    Test runner resolution and usage.
    """

    def test_get_effective_runner_with_global_override(self):
        """
        Test that global_runner_override takes precedence.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            # Create runners
            from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP

            runners = {
                "prod": Runner(name="prod", shell=ShellConfig(cmd=SHELL_LOOKUP["sh"])),
                "dev": Runner(name="dev", shell=ShellConfig(cmd=SHELL_LOOKUP["bash"])),
            }

            # Create task with explicit run_in and recipe with default_runner
            tasks = {"build": Task(name="build", cmd="echo hello", run_in="dev")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
                runners=runners,
                default_runner="dev",
                global_runner_override="prod",  # Global override
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Global override should win
            runner_name = executor._get_effective_runner_name(tasks["build"])
            self.assertEqual(runner_name, "prod")

    def test_get_effective_runner_with_task_runner(self):
        """
        Test that task.run_in is used when no global override.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP

            runners = {
                "prod": Runner(name="prod", shell=ShellConfig(cmd=SHELL_LOOKUP["sh"])),
                "dev": Runner(name="dev", shell=ShellConfig(cmd=SHELL_LOOKUP["bash"])),
            }

            tasks = {"build": Task(name="build", cmd="echo hello", run_in="dev")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
                runners=runners,
                default_runner="prod",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Task runner should win over default_runner
            runner_name = executor._get_effective_runner_name(tasks["build"])
            self.assertEqual(runner_name, "dev")

    def test_get_effective_runner_with_default_runner(self):
        """
        Test that default_runner is used when task has no explicit run_in.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP

            runners = {"prod": Runner(name="prod", shell=ShellConfig(cmd=SHELL_LOOKUP["sh"]))}

            tasks = {"build": Task(name="build", cmd="echo hello")}  # No run_in
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
                runners=runners,
                default_runner="prod",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Default runner should be used
            runner_name = executor._get_effective_runner_name(tasks["build"])
            self.assertEqual(runner_name, "prod")

    def test_get_effective_runner_platform_default(self):
        """
        Test that session default runner name is returned for platform default.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            tasks = {"build": Task(name="build", cmd="echo hello")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # No runners defined, should return session default runner name
            runner_name = executor._get_effective_runner_name(tasks["build"])
            self.assertEqual(runner_name, "__platform_default__")

    def test_resolve_runner_with_custom_runner(self):
        """
        Test resolving runner with custom shell and preamble.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP

            runners = {
                "zsh_runner": Runner(
                    name="zsh_runner",
                    shell=ShellConfig(cmd=SHELL_LOOKUP["zsh"], preamble="set -e\n"),
                )
            }

            tasks = {"build": Task(name="build", cmd="echo hello", run_in="zsh_runner")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
                runners=runners,
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            shell_config = executor._resolve_runner(tasks["build"])
            self.assertEqual(shell_config.cmd, ["zsh"])
            self.assertEqual(shell_config.preamble, "set -e\n")

    @patch("platform.system")
    def test_resolve_runner_falls_back_to_platform_default(self, mock_system):
        """
        Test that _resolve_runner falls back to platform defaults when no runner is defined.
        """
        # Test Unix/Linux platform
        mock_system.return_value = "Linux"

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            # No runners defined, task has no run_in
            tasks = {"build": Task(name="build", cmd="echo hello")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
                runners={},  # No runners
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            shell_config = executor._resolve_runner(tasks["build"])
            self.assertEqual(shell_config.cmd, ["bash"])
            self.assertEqual(shell_config.preamble, "")

        # Test Windows platform
        mock_system.return_value = "Windows"

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            tasks = {"build": Task(name="build", cmd="echo hello")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
                runners={},
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            shell_config = executor._resolve_runner(tasks["build"])
            self.assertEqual(shell_config.cmd, ["cmd.exe", "/c"])
            self.assertEqual(shell_config.preamble, "")

    def test_task_execution_uses_custom_shell(self):
        """
        Test that custom shell from runner is used as the subprocess command.
        """

        captured_run_cmds = []

        def capture_run_cmd(*args, **kwargs):
            captured_run_cmds.append(args[0])
            return MagicMock(returncode=0)

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP

            runners = {"fish": Runner(name="fish", shell=ShellConfig(cmd=SHELL_LOOKUP["fish"]))}

            tasks = {"build": Task(name="build", cmd="echo hello", run_in="fish")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
                runners=runners,
            )

            process_runner_spy = MagicMock(spec=ProcessRunner)
            process_runner_spy.run.side_effect = capture_run_cmd

            fake_proc_runner_factory = MagicMock()
            fake_proc_runner_factory.return_value = process_runner_spy

            Executor(
                recipe, state_manager, logger_stub, fake_proc_runner_factory
            ).execute_task("build", TaskOutputTypes.ALL)

            # Verify the subprocess was invoked with "fish" as the first element
            self.assertEqual(len(captured_run_cmds), 1)
            run_cmd = captured_run_cmds[0]
            self.assertEqual(run_cmd[0], "fish")

    def test_hash_changes_with_runner(self):
        """
        Test that task hash changes when runner changes.
        """

        from tasktree.hasher import hash_task

        # Same task, different runners
        hash1 = hash_task("echo hello", [], ".", [], "prod")
        hash2 = hash_task("echo hello", [], ".", [], "dev")
        hash3 = hash_task("echo hello", [], ".", [], "")

        # All hashes should be different
        self.assertNotEqual(hash1, hash2)
        self.assertNotEqual(hash2, hash3)
        self.assertNotEqual(hash1, hash3)

    def test_run_task_substitutes_environment_variables(self):
        """
        Test that _run_task substitutes environment variables.
        """

        os.environ["TEST_ENV_VAR"] = "test_value"
        captured_script_content = []

        def capture_script_content(*args, **kwargs):
            # Script path is the last element of the run_cmd list
            script_path = args[0][-1]
            with open(script_path, "r") as f:
                captured_script_content.append(f.read())
            return MagicMock(returncode=0)

        try:
            with TemporaryDirectory() as tmpdir:
                project_root = Path(tmpdir)
                state_manager = StateManager(project_root)

                # Create task with env placeholder
                tasks = {
                    "test": Task(
                        name="test",
                        cmd="echo {{ env.TEST_ENV_VAR }}",
                        working_dir=".",
                    )
                }
                recipe = Recipe(
                    tasks=tasks,
                    project_root=project_root,
                    recipe_path=project_root / "tasktree.yaml",
                )
                executor = Executor(
                    recipe, state_manager, logger_stub, make_process_runner
                )

                process_runner_spy = MagicMock(spec=ProcessRunner)
                process_runner_spy.run.side_effect = capture_script_content

                executor._run_task(tasks["test"], {}, process_runner_spy)

                # Verify command has env var substituted in the script
                self.assertEqual(len(captured_script_content), 1)
                script_content = captured_script_content[0]
                self.assertIn("test_value", script_content)
                self.assertNotIn("{{ env.TEST_ENV_VAR }}", script_content)
        finally:
            del os.environ["TEST_ENV_VAR"]

    def test_run_task_env_substitution_in_working_dir(self):
        """
        Test environment variables work in working_dir.
        """

        os.environ["SUBDIR"] = "mydir"
        try:
            with TemporaryDirectory() as tmpdir:
                project_root = Path(tmpdir)
                state_manager = StateManager(project_root)

                # Create subdirectory
                (project_root / "mydir").mkdir()

                tasks = {
                    "test": Task(
                        name="test",
                        cmd="echo test",
                        working_dir="{{ env.SUBDIR }}",
                    )
                }
                recipe = Recipe(
                    tasks=tasks,
                    project_root=project_root,
                    recipe_path=project_root / "tasktree.yaml",
                )
                executor = Executor(
                    recipe, state_manager, logger_stub, make_process_runner
                )

                process_runner_spy = MagicMock(spec=ProcessRunner)
                executor._run_task(tasks["test"], {}, process_runner_spy)

                # Verify working_dir was substituted
                called_cwd = process_runner_spy.run.call_args[1]["cwd"]
                self.assertEqual(called_cwd, project_root / "mydir")
        finally:
            del os.environ["SUBDIR"]

    def test_run_task_undefined_env_var_raises(self):
        """
        Test undefined environment variable raises clear error.
        """

        # Ensure var is not set
        if "UNDEFINED_TEST_VAR" in os.environ:
            del os.environ["UNDEFINED_TEST_VAR"]

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            tasks = {
                "test": Task(
                    name="test",
                    cmd="echo {{ env.UNDEFINED_TEST_VAR }}",
                    working_dir=".",
                )
            }
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            with self.assertRaises(ValueError) as cm:
                executor._run_task(
                    tasks["test"],
                    {},
                    make_process_runner(TaskOutputTypes.ALL, logger_stub),
                )

            self.assertIn("UNDEFINED_TEST_VAR", str(cm.exception))
            self.assertIn("not set", str(cm.exception))


class TestTaskOutputParameter(unittest.TestCase):
    """
    Test task_output parameter handling in Executor.
    """

    def test_run_command_as_script_accesses_task_output_via_self(self):
        """
        Test that _run_command_as_script() can access task_output via self.
        """
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {"test": Task(name="test", cmd="echo test")}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            executor = Executor(
                recipe,
                state_manager,
                logger_stub,
                make_process_runner,
            )

            process_runner_spy = MagicMock(spec=ProcessRunner)
            process_runner_spy.run.return_value = MagicMock(returncode=0)

            executor._run_command_as_script(
                cmd="echo test",
                working_dir=project_root,
                task_name="test",
                shell_cmd=["bash"],
                preamble="",
                process_runner=process_runner_spy,
            )

            process_runner_spy.run.assert_called_once()

    def test_task_specific_task_output_types_is_respected(self):
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {
                "test": Task(
                    name="test", cmd="echo test", task_output=TaskOutputTypes.ERR
                )
            }
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            process_runner_stub = MagicMock(spec=ProcessRunner)
            process_runner_stub.run.return_value = MagicMock(returncode=0)
            process_runner_factory_spy = MagicMock()
            process_runner_factory_spy.side_effect = lambda _1, _2: process_runner_stub

            Executor(
                recipe,
                state_manager,
                logger_stub,
                process_runner_factory_spy,
            ).execute_task("test", None)

            process_runner_factory_spy.assert_has_calls(
                [call(TaskOutputTypes.ERR, logger_stub)]
            )

    def test_task_cli_task_output_types_overrides_specific_value_is_respected(self):
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            tasks = {
                "test": Task(
                    name="test", cmd="echo test", task_output=TaskOutputTypes.ERR
                )
            }
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            process_runner_stub = MagicMock(spec=ProcessRunner)
            process_runner_stub.run.return_value = MagicMock(returncode=0)
            process_runner_factory_spy = MagicMock()
            process_runner_factory_spy.side_effect = lambda _1, _2: process_runner_stub

            Executor(
                recipe,
                state_manager,
                logger_stub,
                process_runner_factory_spy,
            ).execute_task("test", TaskOutputTypes.ALL)

            process_runner_factory_spy.assert_has_calls(
                [call(TaskOutputTypes.ALL, logger_stub)]
            )


class TestExecutorProcessRunner(unittest.TestCase):
    """
    Tests for Executor's process_runner_factory parameter.
    """

    def test_executor_uses_process_runner_in_run_task(self):
        """
        Executor calls process_runner_factory in _run_task.
        """
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            task = Task(name="test", cmd="echo test")
            recipe = Recipe(
                tasks={"test": task},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            process_runner_spy = MagicMock(spec=ProcessRunner)
            process_runner_spy.run.return_value = MagicMock(returncode=0)

            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            executor._run_task(task, {}, process_runner_spy)

            process_runner_spy.run.assert_called_once()

    def test_substitute_runner_fields_includes_extra_args(self):
        """
        Test that _substitute_builtin_in_runner substitutes variables in docker run args.
        """
        from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP

        os.environ["MEMORY_LIMIT"] = "1024m"
        os.environ["CPU_LIMIT"] = "2"

        try:
            with TemporaryDirectory() as tmpdir:
                project_root = Path(tmpdir)
                state_manager = StateManager(project_root)

                recipe = Recipe(
                    tasks={},
                    project_root=project_root,
                    recipe_path=project_root / "tasktree.yaml",
                )
                executor = Executor(
                    recipe, state_manager, logger_stub, make_process_runner
                )

                # Create runner with variables in docker run args
                from tasktree.parser import DockerArgs
                runner = Runner(
                    name="test",
                    dockerfile="Dockerfile",
                    context=".",
                    args=DockerArgs(run=[
                        "--memory={{ env.MEMORY_LIMIT }}",
                        "--cpus={{ env.CPU_LIMIT }}",
                        "--network=host",
                    ]),
                )

                builtin_vars = {
                    "project_root": str(project_root),
                    "task_name": "test",
                }

                # Apply substitution
                substituted_runner = executor._substitute_builtin_in_runner(
                    runner, builtin_vars
                )

                # Verify substitution occurred
                self.assertEqual(
                    substituted_runner.args.run,
                    ["--memory=1024m", "--cpus=2", "--network=host"],
                )
        finally:
            del os.environ["MEMORY_LIMIT"]
            del os.environ["CPU_LIMIT"]

    def test_substitute_runner_fields_includes_preamble_shell_dockerfile_context(self):
        """
        Test that _substitute_builtin_in_runner substitutes variables in shell config, dockerfile, and context.
        """
        from tasktree.parser import Runner, ShellConfig

        os.environ["BUILD_DIR"] = "docker"
        os.environ["CUSTOM_SHELL"] = "/bin/bash"

        try:
            with TemporaryDirectory() as tmpdir:
                project_root = Path(tmpdir)
                state_manager = StateManager(project_root)

                recipe = Recipe(
                    tasks={},
                    project_root=project_root,
                    recipe_path=project_root / "tasktree.yaml",
                )
                executor = Executor(
                    recipe, state_manager, logger_stub, make_process_runner
                )

                # Create runner with variables in shell preamble, cmd, dockerfile, context
                runner = Runner(
                    name="test",
                    shell=ShellConfig(
                        cmd=["{{ env.CUSTOM_SHELL }}", "-c"],
                        preamble="set -e\nexport BUILD_DIR={{ env.BUILD_DIR }}\n",
                    ),
                    dockerfile="{{ env.BUILD_DIR }}/Dockerfile",
                    context="{{ tt.project_root }}/{{ env.BUILD_DIR }}",
                )

                builtin_vars = {
                    "project_root": str(project_root),
                    "task_name": "test",
                }

                # Apply substitution
                substituted_runner = executor._substitute_builtin_in_runner(
                    runner, builtin_vars
                )

                # Verify substitution occurred
                self.assertIsNotNone(substituted_runner.shell)
                self.assertEqual(
                    substituted_runner.shell.preamble, "set -e\nexport BUILD_DIR=docker\n"
                )
                self.assertEqual(substituted_runner.shell.cmd, ["/bin/bash", "-c"])
                self.assertEqual(substituted_runner.dockerfile, "docker/Dockerfile")
                self.assertEqual(substituted_runner.context, f"{project_root}/docker")
        finally:
            del os.environ["BUILD_DIR"]
            del os.environ["CUSTOM_SHELL"]


class TestGetSessionDefaultRunner(unittest.TestCase):
    """
    Tests for get_session_default_runner() function.
    """

    @patch("platform.system")
    def test_returns_bash_on_unix(self, mock_system):
        """
        Test that get_session_default_runner returns bash runner on Unix platforms.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner()

            self.assertEqual(runner.name, "__platform_default__")
            self.assertEqual(runner.shell.cmd, ["bash"])
            self.assertEqual(runner.shell.preamble, "")

    @patch("platform.system")
    def test_returns_bash_on_macos(self, mock_system):
        """
        Test that get_session_default_runner returns bash runner on macOS.
        """
        mock_system.return_value = "Darwin"

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner()

            self.assertEqual(runner.name, "__platform_default__")
            self.assertEqual(runner.shell.cmd, ["bash"])
            self.assertEqual(runner.shell.preamble, "")

    @patch("platform.system")
    def test_returns_cmd_on_windows(self, mock_system):
        """
        Test that get_session_default_runner returns cmd runner on Windows.
        """
        mock_system.return_value = "Windows"

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner()

            self.assertEqual(runner.name, "__platform_default__")
            self.assertEqual(runner.shell.cmd, ["cmd.exe", "/c"])
            self.assertEqual(runner.shell.preamble, "")

    @patch("platform.system")
    def test_returns_project_config_runner_when_found(self, mock_system):
        """
        Test that get_session_default_runner returns project config runner when available.
        """
        mock_system.return_value = "Linux"

        # Create a temporary directory with a project config file
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            config_path = project_root / ".tasktree-config.yml"
            config_path.write_text(
                """
runners:
  default:
    shell:
      cmd: [zsh]
      preamble: set -e
"""
            )

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            self.assertEqual(runner.name, "default")
            self.assertEqual(runner.shell.cmd, ["zsh"])
            self.assertEqual(runner.shell.preamble, "set -e")

    @patch("platform.system")
    def test_falls_back_to_platform_default_when_no_config(self, mock_system):
        """
        Test that get_session_default_runner falls back to platform default when no config.
        """
        mock_system.return_value = "Linux"

        # Create a temporary directory without a config file
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            self.assertEqual(runner.name, "__platform_default__")
            self.assertEqual(runner.shell.cmd, ["bash"])
            self.assertEqual(runner.shell.preamble, "")

    @patch("platform.system")
    def test_handles_config_parse_errors_gracefully(self, mock_system):
        """
        Test that get_session_default_runner falls back to platform default on parse errors.
        """
        mock_system.return_value = "Linux"

        # Create a temporary directory with an invalid config file
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            config_path = project_root / ".tasktree-config.yml"
            config_path.write_text("invalid: yaml: content:")

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            # Should fall back to platform default on parse error
            self.assertEqual(runner.name, "__platform_default__")
            self.assertEqual(runner.shell.cmd, ["bash"])
            self.assertEqual(runner.shell.preamble, "")

    @patch("platform.system")
    def test_searches_parent_directories_for_config(self, mock_system):
        """
        Test that get_session_default_runner searches parent directories for config.
        """
        mock_system.return_value = "Linux"

        # Create a nested directory structure with config in parent
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            config_path = project_root / ".tasktree-config.yml"
            config_path.write_text(
                """
runners:
  default:
    shell:
      cmd: fish
"""
            )

            # Create a subdirectory
            subdir = project_root / "subdir" / "nested"
            subdir.mkdir(parents=True)

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=subdir)

            # Should find config from parent directory
            self.assertEqual(runner.name, "default")
            self.assertEqual(runner.shell.cmd, ["fish"])

    @patch("platform.system")
    @patch("tasktree.config.get_user_config_path")
    def test_returns_user_config_runner_when_found(self, mock_get_user_config, mock_system):
        """
        Test that get_session_default_runner returns user config runner when available.
        """
        mock_system.return_value = "Linux"

        # Create a temporary directory with a user config file
        with tempfile.TemporaryDirectory() as tmpdir:
            user_config_path = Path(tmpdir) / "user-config.yml"
            user_config_path.write_text(
                """
runners:
  default:
    shell:
      cmd: [zsh]
      preamble: set -euo pipefail
"""
            )
            mock_get_user_config.return_value = user_config_path

            project_root = Path(tmpdir) / "project"
            project_root.mkdir()
            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            self.assertEqual(runner.name, "default")
            self.assertEqual(runner.shell.cmd, ["zsh"])
            self.assertEqual(runner.shell.preamble, "set -euo pipefail")

    @patch("platform.system")
    @patch("tasktree.config.get_user_config_path")
    def test_project_config_overrides_user_config(self, mock_get_user_config, mock_system):
        """
        Test that project config takes precedence over user config.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create user config
            user_config_path = Path(tmpdir) / "user-config.yml"
            user_config_path.write_text(
                """
runners:
  default:
    shell:
      cmd: zsh
"""
            )
            mock_get_user_config.return_value = user_config_path

            # Create project config
            project_root = Path(tmpdir) / "project"
            project_root.mkdir()
            project_config_path = project_root / ".tasktree-config.yml"
            project_config_path.write_text(
                """
runners:
  default:
    shell:
      cmd: fish
"""
            )

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            # Project config should win
            self.assertEqual(runner.name, "default")
            self.assertEqual(runner.shell.cmd, ["fish"])

    @patch("platform.system")
    @patch("tasktree.config.get_user_config_path")
    def test_user_config_overrides_platform_default(self, mock_get_user_config, mock_system):
        """
        Test that user config takes precedence over platform default.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create user config
            user_config_path = Path(tmpdir) / "user-config.yml"
            user_config_path.write_text(
                """
runners:
  default:
    shell:
      cmd: zsh
"""
            )
            mock_get_user_config.return_value = user_config_path

            # No project config
            project_root = Path(tmpdir) / "project"
            project_root.mkdir()

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            # User config should win over platform default
            self.assertEqual(runner.name, "default")
            self.assertEqual(runner.shell.cmd, ["zsh"])

    @patch("platform.system")
    @patch("tasktree.config.get_user_config_path")
    def test_handles_user_config_parse_errors_gracefully(
        self, mock_get_user_config, mock_system
    ):
        """
        Test that get_session_default_runner falls back when user config has parse errors.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create invalid user config
            user_config_path = Path(tmpdir) / "user-config.yml"
            user_config_path.write_text("invalid: yaml: content:")
            mock_get_user_config.return_value = user_config_path

            project_root = Path(tmpdir) / "project"
            project_root.mkdir()

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            # Should fall back to platform default
            self.assertEqual(runner.name, "__platform_default__")
            self.assertEqual(runner.shell.cmd, ["bash"])

    @patch("platform.system")
    @patch("tasktree.config.get_machine_config_path")
    def test_returns_machine_config_runner_when_found(
        self, mock_get_machine_config, mock_system
    ):
        """
        Test that get_session_default_runner returns machine config runner when available.
        """
        mock_system.return_value = "Linux"

        # Create a temporary directory with a machine config file
        with tempfile.TemporaryDirectory() as tmpdir:
            machine_config_path = Path(tmpdir) / "machine-config.yml"
            machine_config_path.write_text(
                """
runners:
  default:
    shell:
      cmd: [fish]
      preamble: set -eu
"""
            )
            mock_get_machine_config.return_value = machine_config_path

            project_root = Path(tmpdir) / "project"
            project_root.mkdir()
            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            self.assertEqual(runner.name, "default")
            self.assertEqual(runner.shell.cmd, ["fish"])
            self.assertEqual(runner.shell.preamble, "set -eu")

    @patch("platform.system")
    @patch("tasktree.config.get_machine_config_path")
    def test_machine_config_overrides_platform_default(
        self, mock_get_machine_config, mock_system
    ):
        """
        Test that machine config takes precedence over platform default.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create machine config
            machine_config_path = Path(tmpdir) / "machine-config.yml"
            machine_config_path.write_text(
                """
runners:
  default:
    shell:
      cmd: fish
"""
            )
            mock_get_machine_config.return_value = machine_config_path

            # No user or project config
            project_root = Path(tmpdir) / "project"
            project_root.mkdir()

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            # Machine config should win over platform default
            self.assertEqual(runner.name, "default")
            self.assertEqual(runner.shell.cmd, ["fish"])

    @patch("platform.system")
    @patch("tasktree.config.get_user_config_path")
    @patch("tasktree.config.get_machine_config_path")
    def test_user_config_overrides_machine_config(
        self, mock_get_machine_config, mock_get_user_config, mock_system
    ):
        """
        Test that user config takes precedence over machine config.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create machine config
            machine_config_path = Path(tmpdir) / "machine-config.yml"
            machine_config_path.write_text(
                """
runners:
  default:
    shell:
      cmd: fish
"""
            )
            mock_get_machine_config.return_value = machine_config_path

            # Create user config
            user_config_path = Path(tmpdir) / "user-config.yml"
            user_config_path.write_text(
                """
runners:
  default:
    shell:
      cmd: zsh
"""
            )
            mock_get_user_config.return_value = user_config_path

            # No project config
            project_root = Path(tmpdir) / "project"
            project_root.mkdir()

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            # User config should win
            self.assertEqual(runner.name, "default")
            self.assertEqual(runner.shell.cmd, ["zsh"])

    @patch("platform.system")
    @patch("tasktree.config.get_machine_config_path")
    def test_handles_machine_config_permission_errors_gracefully(
        self, mock_get_machine_config, mock_system
    ):
        """
        Test that get_session_default_runner falls back when machine config has permission errors.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create machine config path (doesn't need to exist)
            machine_config_path = Path(tmpdir) / "machine-config.yml"
            mock_get_machine_config.return_value = machine_config_path

            # Mock exists() to return True, then parse_config_file to raise PermissionError
            with patch.object(Path, "exists", return_value=True), patch(
                "tasktree.config.parse_config_file",
                side_effect=PermissionError("Permission denied"),
            ):
                project_root = Path(tmpdir) / "project"
                project_root.mkdir(exist_ok=True)

                state_manager = StateManager(project_root)
                recipe = Recipe(
                    tasks={},
                    project_root=project_root,
                    recipe_path=project_root / "tasktree.yaml",
                )
                executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
                runner = executor.get_session_default_runner(start_dir=project_root)

                # Should fall back to platform default
                self.assertEqual(runner.name, "__platform_default__")
                self.assertEqual(runner.shell.cmd, ["bash"])

    @patch("platform.system")
    @patch("tasktree.config.get_machine_config_path")
    def test_handles_empty_machine_config_file(
        self, mock_get_machine_config, mock_system
    ):
        """
        Test that get_session_default_runner handles empty machine config files gracefully.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create empty machine config
            machine_config_path = Path(tmpdir) / "machine-config.yml"
            machine_config_path.write_text("")  # Empty file
            mock_get_machine_config.return_value = machine_config_path

            project_root = Path(tmpdir) / "project"
            project_root.mkdir()

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            # Empty config should be treated as no config, fall back to platform default
            self.assertEqual(runner.name, "__platform_default__")
            self.assertEqual(runner.shell.cmd, ["bash"])

    @patch("platform.system")
    @patch("tasktree.config.get_machine_config_path")
    def test_handles_malformed_yaml_in_machine_config(
        self, mock_get_machine_config, mock_system
    ):
        """
        Test that get_session_default_runner handles malformed YAML in machine config gracefully.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create machine config with malformed YAML
            machine_config_path = Path(tmpdir) / "machine-config.yml"
            machine_config_path.write_text("invalid: yaml: content:")  # Malformed YAML
            mock_get_machine_config.return_value = machine_config_path

            project_root = Path(tmpdir) / "project"
            project_root.mkdir()

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            # Create a mock logger to capture log calls
            mock_logger = MagicMock()
            executor = Executor(recipe, state_manager, mock_logger, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            # Malformed YAML should log warning and fall back to platform default
            self.assertEqual(runner.name, "__platform_default__")
            self.assertEqual(runner.shell.cmd, ["bash"])

            # Verify warning was logged
            mock_logger.warn.assert_called()
            call_args = str(mock_logger.warn.call_args)
            self.assertIn("Failed to load machine config", call_args)

    @patch("platform.system")
    def test_logs_warning_when_config_parse_fails(self, mock_system):
        """
        Test that get_session_default_runner logs a warning when config parsing fails.
        """
        mock_system.return_value = "Linux"

        # Create a temporary directory with an invalid config file
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            config_path = project_root / ".tasktree-config.yml"
            config_path.write_text("invalid: yaml: content:")

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            # Create a mock logger to capture log calls
            mock_logger = MagicMock()
            executor = Executor(recipe, state_manager, mock_logger, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            # Should fall back to platform default
            self.assertEqual(runner.name, "__platform_default__")

            # Should have logged a warning
            mock_logger.warn.assert_called_once()
            call_args = mock_logger.warn.call_args[0][0]
            self.assertIn("Failed to load project config", call_args)

    @patch("platform.system")
    def test_project_root_passed_to_config_parser(self, mock_system):
        """
        Test that project_root is passed to parse_config_file for all config levels.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create a project config with relative dockerfile path
            config_path = project_root / ".tasktree-config.yml"
            config_path.write_text(
                """runners:
  default:
    dockerfile: docker/Dockerfile
    context: .
"""
            )

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            # Verify runner was loaded with dockerfile path stored as-is
            self.assertEqual(runner.dockerfile, "docker/Dockerfile")
            self.assertEqual(runner.context, ".")

    @patch("platform.system")
    def test_relative_paths_in_user_config(self, mock_system):
        """
        Test that relative paths in user config are accepted and stored.
        Path resolution happens at execution time in docker.py.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            user_config_dir = Path(tmpdir) / "user_config"
            user_config_dir.mkdir()
            user_config_path = user_config_dir / "config.yml"
            user_config_path.write_text(
                """runners:
  default:
    dockerfile: relative/path/Dockerfile
    context: build
"""
            )

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Mock get_user_config_path to return our test path
            with patch(
                "tasktree.config.get_user_config_path", return_value=user_config_path
            ):
                runner = executor.get_session_default_runner(start_dir=project_root)

            # Verify relative paths are stored as-is
            self.assertEqual(runner.dockerfile, "relative/path/Dockerfile")
            self.assertEqual(runner.context, "build")

    @patch("platform.system")
    def test_absolute_paths_in_config(self, mock_system):
        """
        Test that absolute paths in config files are accepted and stored.
        """
        mock_system.return_value = "Linux"

        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create a project config with absolute paths
            config_path = project_root / ".tasktree-config.yml"
            abs_dockerfile = str(Path(tmpdir) / "docker" / "Dockerfile")
            abs_context = str(Path(tmpdir) / "docker")
            config_path.write_text(
                f"""runners:
  default:
    dockerfile: {abs_dockerfile}
    context: {abs_context}
"""
            )

            state_manager = StateManager(project_root)
            recipe = Recipe(
                tasks={},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)
            runner = executor.get_session_default_runner(start_dir=project_root)

            # Verify absolute paths are stored correctly
            self.assertEqual(runner.dockerfile, abs_dockerfile)
            self.assertEqual(runner.context, abs_context)


class TestPlatformdirs(unittest.TestCase):
    """
    Test that platformdirs dependency is available.
    """

    def test_platformdirs_import(self):
        """
        Test that platformdirs can be imported successfully.
        """
        try:
            import platformdirs

            # Verify basic functions exist
            self.assertTrue(callable(platformdirs.user_config_dir))
            self.assertTrue(callable(platformdirs.site_config_dir))
        except ImportError as e:
            self.fail(f"platformdirs import failed: {e}")


class TestPinnedRunnerValidation(unittest.TestCase):
    """Tests for pinned runner validation."""

    def test_pinned_task_without_run_in_raises_error(self):
        """Test that pinned task without run_in raises ValueError."""
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            # Create task with pin_runner but no run_in
            task = Task(name="build", cmd="make", pin_runner=True, run_in="")

            recipe = Recipe(
                tasks={"build": task},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Should raise ValueError when trying to get effective runner
            with self.assertRaises(ValueError) as context:
                executor._get_effective_runner_name(task)

            self.assertIn("pin_runner=true", str(context.exception))
            self.assertIn("no run_in specified", str(context.exception))

    def test_pinned_task_with_run_in_succeeds(self):
        """Test that pinned task with run_in does not raise error."""
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            # Create task with both pin_runner and run_in
            task = Task(name="build", cmd="make", pin_runner=True, run_in="docker")

            recipe = Recipe(
                tasks={"build": task},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Should not raise error
            runner_name = executor._get_effective_runner_name(task)
            self.assertEqual(runner_name, "docker")

    def test_non_pinned_task_without_run_in_succeeds(self):
        """Test that non-pinned task without run_in uses default runner."""
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            state_manager = StateManager(project_root)

            # Create task without pin_runner or run_in
            task = Task(name="build", cmd="make", pin_runner=False, run_in="")

            recipe = Recipe(
                tasks={"build": task},
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )

            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # Should not raise error and return default runner
            runner_name = executor._get_effective_runner_name(task)
            # Default runner name is platform default
            self.assertEqual(runner_name, "__platform_default__")

    def test_pinned_task_with_nonexistent_runner_caught_at_parse_time(self):
        """Test that pinned task with non-existent runner is caught during parsing."""
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            recipe_path = project_root / "tasktree.yaml"

            # Create recipe file with pinned task referencing non-existent runner
            recipe_path.write_text("""
tasks:
  build:
    cmd: make
    run_in: nonexistent_runner
    pin_runner: true
""")

            # Should raise ValueError during parsing
            with self.assertRaises(ValueError) as context:
                parse_recipe(recipe_path)

            self.assertIn("nonexistent_runner", str(context.exception))
            self.assertIn("invalid runner", str(context.exception))


class TestDockerOnlyFieldValidation(unittest.TestCase):
    """
    Tests that docker-only runner fields are rejected when used without a dockerfile.
    Validation is performed before execution, once the reachable tasks are known.
    """

    def _make_executor(self, project_root, runner):
        from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP
        tasks = {"build": Task(name="build", cmd="echo hello", run_in=runner.name)}
        recipe = Recipe(
            tasks=tasks,
            project_root=project_root,
            recipe_path=project_root / "tasktree.yaml",
            runners={runner.name: runner},
        )
        return Executor(recipe, StateManager(project_root), logger_stub, make_process_runner)

    def test_volumes_on_shell_runner_raises(self):
        from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP
        with TemporaryDirectory() as tmpdir:
            runner = Runner(
                name="myrunner",
                shell=ShellConfig(cmd=SHELL_LOOKUP["bash"]),
                volumes=["/host:/container"],
            )
            executor = self._make_executor(Path(tmpdir), runner)
            with self.assertRaises(ValueError) as ctx:
                executor._validate_runners_for_reachable_tasks([("build", {})])
            self.assertIn("'volumes'", str(ctx.exception))
            self.assertIn("only valid for Docker runners", str(ctx.exception))

    def test_ports_on_shell_runner_raises(self):
        from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP
        with TemporaryDirectory() as tmpdir:
            runner = Runner(
                name="myrunner",
                shell=ShellConfig(cmd=SHELL_LOOKUP["bash"]),
                ports=["8080:80"],
            )
            executor = self._make_executor(Path(tmpdir), runner)
            with self.assertRaises(ValueError) as ctx:
                executor._validate_runners_for_reachable_tasks([("build", {})])
            self.assertIn("'ports'", str(ctx.exception))
            self.assertIn("only valid for Docker runners", str(ctx.exception))

    def test_env_vars_on_shell_runner_raises(self):
        from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP
        with TemporaryDirectory() as tmpdir:
            runner = Runner(
                name="myrunner",
                shell=ShellConfig(cmd=SHELL_LOOKUP["bash"]),
                env_vars={"MY_VAR": "value"},
            )
            executor = self._make_executor(Path(tmpdir), runner)
            with self.assertRaises(ValueError) as ctx:
                executor._validate_runners_for_reachable_tasks([("build", {})])
            self.assertIn("'env_vars'", str(ctx.exception))
            self.assertIn("only valid for Docker runners", str(ctx.exception))

    def test_run_as_root_on_shell_runner_raises(self):
        from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP
        with TemporaryDirectory() as tmpdir:
            runner = Runner(
                name="myrunner",
                shell=ShellConfig(cmd=SHELL_LOOKUP["bash"]),
                run_as_root=True,
            )
            executor = self._make_executor(Path(tmpdir), runner)
            with self.assertRaises(ValueError) as ctx:
                executor._validate_runners_for_reachable_tasks([("build", {})])
            self.assertIn("'run_as_root'", str(ctx.exception))
            self.assertIn("only valid for Docker runners", str(ctx.exception))

    def test_args_on_shell_runner_raises(self):
        from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP, DockerArgs
        with TemporaryDirectory() as tmpdir:
            runner = Runner(
                name="myrunner",
                shell=ShellConfig(cmd=SHELL_LOOKUP["bash"]),
                args=DockerArgs(build=["--no-cache"]),
            )
            executor = self._make_executor(Path(tmpdir), runner)
            with self.assertRaises(ValueError) as ctx:
                executor._validate_runners_for_reachable_tasks([("build", {})])
            self.assertIn("'args'", str(ctx.exception))
            self.assertIn("only valid for Docker runners", str(ctx.exception))

    def test_docker_only_fields_on_docker_runner_allowed(self):
        from tasktree.parser import Runner, ShellConfig, SHELL_LOOKUP
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            dockerfile = project_root / "Dockerfile"
            dockerfile.write_text("FROM ubuntu\n")
            runner = Runner(
                name="myrunner",
                dockerfile="Dockerfile",
                context=".",
                volumes=["/host:/container"],
                ports=["8080:80"],
                env_vars={"MY_VAR": "value"},
                run_as_root=True,
            )
            executor = self._make_executor(project_root, runner)
            # Should not raise
            executor._validate_runners_for_reachable_tasks([("build", {})])


if __name__ == "__main__":
    unittest.main()
