"""Task execution and staleness detection."""

from __future__ import annotations

import io
import os
import platform
import subprocess
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from tasktree import docker as docker_module
from tasktree.config import ConfigError
from tasktree.graph import (
    get_implicit_inputs,
    resolve_execution_order,
    resolve_dependency_output_references,
    resolve_self_references,
)
from tasktree.hasher import hash_args, hash_task, make_cache_key
from tasktree.logging import Logger, LogLevel
from tasktree.parser import DockerArgs, Recipe, Task, Runner, ShellConfig, SHELL_LOOKUP, _get_windows_script_extension
from tasktree.process_runner import ProcessRunner, TaskOutputTypes
from tasktree.state import StateManager, TaskState
from tasktree.hasher import hash_runner_definition
from tasktree.temp_script import TempScript


def _supports_fileno(stream) -> bool:
    """Check if a stream has a working fileno() method."""
    try:
        stream.fileno()
        return True
    except (AttributeError, OSError, io.UnsupportedOperation):
        return False


@dataclass
class TaskStatus:
    """
    Status of a task for execution planning.
    """

    task_name: str
    will_run: bool
    reason: str  # "fresh", "inputs_changed", "definition_changed",
    # "never_run", "no_inputs", "outputs_missing", "forced", "environment_changed"
    changed_files: list[str] = field(default_factory=list)
    last_run: datetime | None = None


class ExecutionError(Exception):
    """
    Raised when task execution fails.
    """

    pass


class Executor:
    """
    Executes tasks with incremental execution logic.
    """

    # Container state file path (mounted inside Docker containers)
    CONTAINER_STATE_FILE_PATH = "/tasktree-internal/.tasktree-state"

    # Environment variable for tracking task call chain (recursion detection)
    TT_CALL_CHAIN_ENV_VAR = "TT_CALL_CHAIN"

    # Protected environment variables that cannot be overridden by exported args
    PROTECTED_ENV_VARS = {
        "PATH",
        "LD_LIBRARY_PATH",
        "LD_PRELOAD",
        "PYTHONPATH",
        "HOME",
        "SHELL",
        "USER",
        "LOGNAME",
    }

    def __init__(
        self,
        recipe: Recipe,
        state_manager: StateManager,
        logger: Logger,
        process_runner_factory: Callable[[TaskOutputTypes, Logger], ProcessRunner],
    ):
        """
        Initialize executor.

        Args:
        recipe: Parsed recipe containing all tasks
        state_manager: State manager for tracking task execution
        logger_fn: Logger function for output (matches Console.print signature)
        process_runner_factory: Factory function for creating ProcessRunner instances
        """
        self.recipe = recipe
        self.state = state_manager
        self.logger = logger
        self._process_runner_factory = process_runner_factory
        self.docker_manager = docker_module.DockerManager(recipe.project_root, logger)

    @staticmethod
    def _has_regular_args(task: Task) -> bool:
        """
        Check if a task has any regular (non-exported) arguments.

        Args:
        task: Task to check

        Returns:
        True if task has at least one regular (non-exported) argument, False otherwise
        """
        if not task.args:
            return False

        # Check if any arg is not exported (doesn't start with $)
        for arg_spec in task.args:
            # Handle both string and dict arg specs
            if isinstance(arg_spec, str):
                # Remove default value part if present
                arg_name = arg_spec.split("=")[0].split(":")[0].strip()
                if not arg_name.startswith("$"):
                    return True
            elif isinstance(arg_spec, dict):
                # Dict format: { argname: { ... } } or { $argname: { ... } }
                for key in arg_spec.keys():
                    if not key.startswith("$"):
                        return True

        return False

    @staticmethod
    def _filter_regular_args(task: Task, task_args: dict[str, Any]) -> dict[str, Any]:
        """
        Filter task_args to only include regular (non-exported) arguments.

        Args:
        task: Task definition
        task_args: Dictionary of all task arguments

        Returns:
        Dictionary containing only regular (non-exported) arguments
        """
        if not task.args or not task_args:
            return {}

        # Build set of exported arg names (without the $ prefix)
        exported_names = set()
        for arg_spec in task.args:
            if isinstance(arg_spec, str):
                arg_name = arg_spec.split("=")[0].split(":")[0].strip()
                if arg_name.startswith("$"):
                    exported_names.add(arg_name[1:])  # Remove $ prefix
            elif isinstance(arg_spec, dict):
                for key in arg_spec.keys():
                    if key.startswith("$"):
                        exported_names.add(key[1:])  # Remove $ prefix

        # Filter out exported args
        return {k: v for k, v in task_args.items() if k not in exported_names}

    def _collect_early_builtin_variables(
        self, task: Task, timestamp: datetime
    ) -> dict[str, str]:
        """
        Collect built-in variables that don't depend on working_dir.

        These variables can be used in the working_dir field itself.

        Args:
        task: Task being executed
        timestamp: Timestamp when task started execution

        Returns:
        Dictionary mapping built-in variable names to their string values

        Raises:
        ExecutionError: If any built-in variable fails to resolve
        """
        import os

        builtin_vars = {
            # {{ tt.project_root }} - Absolute path to project root
            "project_root": str(self.recipe.project_root.resolve()),
            # {{ tt.recipe_dir }} - Absolute path to directory containing the recipe file
            "recipe_dir": str(self.recipe.recipe_path.parent.resolve()),
            # {{ tt.task_name }} - Name of currently executing task
            "task_name": task.name,
            # {{ tt.timestamp }} - ISO8601 timestamp when task started execution
            "timestamp": timestamp.strftime("%Y-%m-%dT%H:%M:%SZ"),
            # {{ tt.timestamp_unix }} - Unix epoch timestamp when task started
            "timestamp_unix": str(int(timestamp.timestamp())),
        }

        # {{ tt.user_home }} - Current user's home directory (cross-platform)
        try:
            user_home = Path.home()
            builtin_vars["user_home"] = str(user_home)
        except Exception as e:
            raise ExecutionError(
                f"Failed to get user home directory for {{ tt.user_home }}: {e}"
            )

        # {{ tt.user_name }} - Current username (with fallback)
        try:
            user_name = os.getlogin()
        except OSError:
            # Fallback to environment variables if os.getlogin() fails
            user_name = (
                os.environ.get("USER") or os.environ.get("USERNAME") or "unknown"
            )
        builtin_vars["user_name"] = user_name

        return builtin_vars

    def _collect_builtin_variables(
        self, task: Task, working_dir: Path, timestamp: datetime
    ) -> dict[str, str]:
        """
        Collect built-in variables for task execution.

        Args:
        task: Task being executed
        working_dir: Resolved working directory for the task
        timestamp: Timestamp when task started execution

        Returns:
        Dictionary mapping built-in variable names to their string values

        Raises:
        ExecutionError: If any built-in variable fails to resolve
        """
        # Get early builtin vars (those that don't depend on working_dir)
        builtin_vars = self._collect_early_builtin_variables(task, timestamp)

        # {{ tt.working_dir }} - Absolute path to task's effective working directory
        # This is added after working_dir is resolved to avoid circular dependency
        builtin_vars["working_dir"] = str(working_dir.resolve())

        return builtin_vars

    def _prepare_env_with_exports(
        self,
        exported_env_vars: dict[str, str] | None = None,
        call_chain: str | None = None,
    ) -> dict[str, str]:
        """
        Prepare environment with exported arguments and call chain.

        Args:
        exported_env_vars: Exported arguments to set as environment variables
        call_chain: TT_CALL_CHAIN value for recursion detection

        Returns:
        Environment dict with exported args and call chain merged

        Raises:
        ValueError: If an exported arg attempts to override a protected environment variable
        """
        env = os.environ.copy()
        if exported_env_vars:
            # Check for protected environment variable overrides
            for key in exported_env_vars:
                if key in self.PROTECTED_ENV_VARS:
                    raise ValueError(
                        f"Cannot override protected environment variable: {key}\n"
                        f"Protected variables are: {', '.join(sorted(self.PROTECTED_ENV_VARS))}"
                    )
            env.update(exported_env_vars)

        # Add call chain for recursion detection
        if call_chain is not None:
            env[self.TT_CALL_CHAIN_ENV_VAR] = call_chain

        return env

    def _try_load_config(
        self,
        config_path: Path,
        config_level: str,
        treat_permission_as_trace: bool = False,
    ) -> Runner | None:
        """
        Helper to load a config file with standardized error handling.

        Args:
            config_path: Path to the config file
            config_level: Description of config level (e.g., "machine", "user", "project")
            treat_permission_as_trace: If True, PermissionError logs at trace level instead of warn

        Returns:
            Runner if config exists and is valid, None otherwise

        Note:
            Relative paths in config files are stored as-is and resolved at task
            execution time. See parse_config_file() for details.
        """
        # Import here to avoid circular dependency
        from tasktree.config import parse_config_file

        try:
            if config_path.exists():
                runner = parse_config_file(config_path)
                if runner:
                    self.logger.debug(
                        f"Using runner from {config_level} config at '{config_path}' as session default runner"
                    )
                    return runner
            else:
                self.logger.trace(f"No {config_level} config found at '{config_path}'")
        except (ConfigError, OSError) as e:
            # PermissionError (subclass of OSError) may be expected for some configs
            # (e.g., machine-level on Unix) - log at trace level if requested
            # Other errors indicate real problems - log at warn level
            if treat_permission_as_trace and isinstance(e, PermissionError):
                self.logger.trace(f"Cannot read {config_level} config (permission denied): {e}")
            else:
                self.logger.warn(f"Failed to load {config_level} config: {e}")
        return None

    def get_session_default_runner(self, start_dir: Path = None) -> Runner:
        """
        Get the session default runner based on configuration hierarchy.

        Search (i.e. precedence) order (first encountered wins):
        1. Project-level config (checked here)
        2. User-level config (checked here)
        3. Machine-level config (checked here)
        4. Platform default (baseline)

        Args:
            start_dir: Directory to start searching for project config.
                      Defaults to current working directory.

        Returns:
            Runner: Session default runner configuration

        Note:
            Relative paths in config files (e.g., dockerfile paths) are resolved
            relative to project_root at task execution time. If a relative path
            cannot be resolved (e.g., dockerfile doesn't exist), the error will
            occur during task execution, not during config loading.

        """
        # Import here to avoid circular dependency
        from tasktree.config import (
            find_project_config,
            get_machine_config_path,
            get_user_config_path,
        )

        # Start with platform default
        is_windows = platform.system() == "Windows"
        if is_windows:
            platform_default = Runner(
                name="__platform_default__",
                shell=ShellConfig(cmd=list(SHELL_LOOKUP["cmd.exe"])),
            )
        else:
            platform_default = Runner(
                name="__platform_default__",
                shell=ShellConfig(cmd=list(SHELL_LOOKUP["bash"])),
            )

        session_default = platform_default

        # Get project root for path resolution
        project_root = self.recipe.project_root

        # Check for machine-level config (higher precedence than platform default)
        machine_config_path = get_machine_config_path()
        machine_runner = self._try_load_config(
            machine_config_path, "machine", treat_permission_as_trace=True
        )
        if machine_runner:
            session_default = machine_runner

        # Check for user-level config (higher precedence than machine config)
        user_config_path = get_user_config_path()
        user_runner = self._try_load_config(user_config_path, "user")
        if user_runner:
            session_default = user_runner

        # Determine starting directory for project config
        if start_dir is None:
            start_dir = Path.cwd()

        # Check for project-level config (highest precedence)
        project_config_path = find_project_config(start_dir)
        if project_config_path:
            project_runner = self._try_load_config(
                project_config_path, "project"
            )
            if project_runner:
                session_default = project_runner

        if session_default == platform_default:
            self.logger.debug("Using platform default runner for session")

        return session_default

    def _get_effective_runner_name(self, task: Task) -> str:
        """
        Get the effective runner name for a task.

        Resolution order:
        1. Recipe's global_runner_override (from CLI --runner)
        2. Task's explicit run_in field (includes blanket runner if applied)
        3. Recipe's default_runner
        4. Session default runner name (from get_session_default_runner)

        Note: Pinned tasks (pin_runner=true) must have run_in specified.

        Args:
        task: Task to get runner name for

        Returns:
        Runner name (session default runner name if no other override)
        """
        # Validate pinned tasks have a runner specified
        if task.pin_runner and not task.run_in:
            raise ValueError(
                f"Task '{task.name}' has pin_runner=true but no run_in specified. "
                f"Pinned tasks must explicitly declare their runner."
            )

        # Check for global override first
        if self.recipe.global_runner_override:
            return self.recipe.global_runner_override

        # Use task's runner
        if task.run_in:
            return task.run_in

        # Use recipe default
        if self.recipe.default_runner:
            return self.recipe.default_runner

        # Return session default runner name
        return self.get_session_default_runner().name

    def _validate_runner_for_task(self, task: Task) -> None:
        """Raise ValueError if a shell runner for this task has docker-only fields set."""
        runner_name = self._get_effective_runner_name(task)
        if not runner_name:
            return
        runner = self.recipe.get_runner(runner_name)
        if runner is None or runner.dockerfile:
            return
        docker_only_fields = {
            "volumes": runner.volumes,
            "ports": runner.ports,
            "env_vars": runner.env_vars,
        }
        for field_name, value in docker_only_fields.items():
            if value:
                raise ValueError(
                    f"Runner '{runner_name}': '{field_name}' is only valid for Docker runners "
                    f"(runners with a 'dockerfile' field)"
                )
        if runner.run_as_root:
            raise ValueError(
                f"Runner '{runner_name}': 'run_as_root' is only valid for Docker runners "
                f"(runners with a 'dockerfile' field)"
            )
        if runner.args.build or runner.args.run:
            raise ValueError(
                f"Runner '{runner_name}': 'args' is only valid for Docker runners "
                f"(runners with a 'dockerfile' field)"
            )

    def _validate_runners_for_reachable_tasks(
        self, execution_order: list[tuple[str, dict]]
    ) -> None:
        """Validate all runners required by the reachable tasks before execution begins."""
        for name, _ in execution_order:
            task = self.recipe.tasks[name]
            self._validate_runner_for_task(task)

    def _resolve_runner(self, task: Task) -> ShellConfig:
        """
        Resolve which runner to use for a task.

        Resolution order:
        1. Recipe's global_env_override (from CLI --env)
        2. Task's explicit env field
        3. Recipe's default_env
        4. Platform default (bash on Unix, cmd on Windows)

        Args:
        task: Task to resolve environment for

        Returns:
        ShellConfig for the resolved runner
        """
        # Check for global override first
        env_name = self.recipe.global_runner_override

        # If no global override, use task's runner
        if not env_name:
            env_name = task.run_in

        # If no explicit runner, try recipe default
        if not env_name and self.recipe.default_runner:
            env_name = self.recipe.default_runner

        # If we have a runner name, look it up
        if env_name:
            env = self.recipe.get_runner(env_name)
            if env and env.shell is not None:
                return env.shell
            # If runner not found or has no shell, fall through to platform default

        # Use platform default
        default_runner = self.get_session_default_runner()
        return default_runner.shell

    def check_task_status(
        self,
        task: Task,
        args_dict: dict[str, Any],
        process_runner: ProcessRunner,
        force: bool = False,
    ) -> TaskStatus:
        """
        Check if a task needs to run.

        A task executes if ANY of these conditions are met:
        1. Force flag is set (--force)
        2. Task definition hash differs from cached state
        3. Runner definition has changed
        4. Any explicit inputs have newer mtime than last_run
        5. Any implicit inputs (from deps) have changed
        6. No cached state exists for this task+args combination
        7. Task has no inputs (always runs)
        8. Different arguments than any cached execution

        Args:
        task: Task to check
        args_dict: Arguments for this task execution
        process_runner: ProcessRunner instance for subprocess execution
        force: If True, ignore freshness and force execution

        Returns:
        TaskStatus indicating whether task will run and why
        """
        # If force flag is set, always run
        if force:
            self.logger.debug(f"Task '{task.name}' will run: force flag specified")
            return TaskStatus(
                task_name=task.name,
                will_run=True,
                reason="forced",
            )

        # Compute hashes (include effective environment and dependencies)
        effective_env = self._get_effective_runner_name(task)
        task_hash = hash_task(
            task.cmd,
            task.outputs,
            task.working_dir,
            task.args,
            effective_env,
            task.deps,
        )
        self.logger.trace(f"Task hash for '{task.name}': {task_hash}")
        args_hash = hash_args(args_dict) if args_dict else None
        if args_hash:
            self.logger.trace(f"Args hash: {args_hash}")
        cache_key = make_cache_key(task_hash, args_hash)
        self.logger.trace(f"Cache key: {cache_key}")

        # Check if task has no inputs (always runs)
        # This check happens early to match original behavior
        all_inputs = self._get_all_inputs(task)
        if not all_inputs:
            cached_state = self.state.get(cache_key)
            self.logger.debug(f"Task '{task.name}' will run: task has no inputs (always runs)")
            return TaskStatus(
                task_name=task.name,
                will_run=True,
                reason="no_inputs",
                last_run=datetime.fromtimestamp(cached_state.last_run) if cached_state else None,
            )

        # Check cached state
        cached_state = self.state.get(cache_key)
        if cached_state is None:
            self.logger.trace(f"No cached state found for cache key: {cache_key}")
            self.logger.debug(f"Task '{task.name}' will run: no previous execution found")
            return TaskStatus(
                task_name=task.name,
                will_run=True,
                reason="never_run",
            )

        self.logger.trace(f"Found cached state for '{task.name}' (last run: {datetime.fromtimestamp(cached_state.last_run).isoformat()})")

        env_changed = self._check_runner_changed(
            task, cached_state, effective_env, process_runner
        )
        if env_changed:
            self.logger.debug(f"Task '{task.name}' will run: runner definition changed")
            return TaskStatus(
                task_name=task.name,
                will_run=True,
                reason="environment_changed",
                last_run=datetime.fromtimestamp(cached_state.last_run),
            )

        # Check if inputs have changed
        changed_files = self._check_inputs_changed(task, cached_state, all_inputs)
        if changed_files:
            files_list = ", ".join(changed_files)
            self.logger.debug(f"Task '{task.name}' will run: inputs changed: {files_list}")
            return TaskStatus(
                task_name=task.name,
                will_run=True,
                reason="inputs_changed",
                changed_files=changed_files,
                last_run=datetime.fromtimestamp(cached_state.last_run),
            )

        # Check if declared outputs are missing
        missing_outputs = self._check_outputs_missing(task)
        if missing_outputs:
            outputs_list = ", ".join(missing_outputs)
            self.logger.debug(f"Task '{task.name}' will run: outputs missing: {outputs_list}")
            return TaskStatus(
                task_name=task.name,
                will_run=True,
                reason="outputs_missing",
                changed_files=missing_outputs,
                last_run=datetime.fromtimestamp(cached_state.last_run),
            )

        # Task is fresh
        self.logger.debug(f"Task '{task.name}' is up-to-date, skipping")
        return TaskStatus(
            task_name=task.name,
            will_run=False,
            reason="fresh",
            last_run=datetime.fromtimestamp(cached_state.last_run),
        )

    @staticmethod
    def _get_task_output_type(
        user_inputted_value: TaskOutputTypes | None, task: Task
    ) -> TaskOutputTypes:
        if user_inputted_value is None:
            if task.task_output is not None:
                return task.task_output

            return TaskOutputTypes.ALL

        return user_inputted_value

    def execute_task(
        self,
        task_name: str,
        user_inputted_task_output_types: TaskOutputTypes | None,
        args_dict: dict[str, Any] | None = None,
        force: bool = False,
        only: bool = False,
    ) -> dict[str, TaskStatus]:
        """
        Execute a task and its dependencies.

        Args:
        task_name: Name of task to execute
        task_output_type: TaskOutputTypes enum value for controlling subprocess output
        args_dict: Arguments to pass to the task
        force: If True, ignore freshness and re-run all tasks
        only: If True, run only the specified task without dependencies (implies force=True)

        Returns:
        Dictionary of task names to their execution status

        Raises:
        ExecutionError: If task execution fails
        """
        if args_dict is None:
            args_dict = {}

        # When only=True, force execution (ignore freshness)
        if only:
            force = True

        # Resolve execution order
        if only:
            # Only execute the target task, skip dependencies
            execution_order = [(task_name, args_dict)]
            self.logger.debug(f"Skipping dependencies (--only mode)")
        else:
            # Execute task and all dependencies
            execution_order = resolve_execution_order(self.recipe, task_name, args_dict)
            task_names = [name for name, _ in execution_order]
            self.logger.debug(f"Execution order: {' -> '.join(task_names)}")

        # Validate runners for all reachable tasks before executing anything
        self._validate_runners_for_reachable_tasks(execution_order)

        # Resolve dependency output references in topological order
        # This substitutes {{ dep.*.outputs.* }} templates before execution
        resolve_dependency_output_references(self.recipe, execution_order)

        # Resolve self-references in topological order
        # This substitutes {{ self.inputs.* }} and {{ self.outputs.* }} templates
        resolve_self_references(self.recipe, execution_order)

        # Single phase: Check and execute incrementally
        statuses: dict[str, TaskStatus] = {}
        for name, task_args in execution_order:
            task = self.recipe.tasks[name]

            # Convert None to {} for internal use (None is used to distinguish simple deps in graph)
            args_dict_for_execution = task_args if task_args is not None else {}

            process_runner = self._process_runner_factory(
                self._get_task_output_type(user_inputted_task_output_types, task),
                self.logger,
            )

            # Check if task needs to run (based on CURRENT filesystem state)
            status = self.check_task_status(
                task, args_dict_for_execution, process_runner, force=force
            )

            # Use a key that includes args for status tracking
            # Only include regular (non-exported) args in status key for parameterized dependencies
            # For the root task (invoked from CLI), status key is always just the task name
            # For dependencies with parameterized invocations, include the regular args
            is_root_task = name == task_name
            if (
                not is_root_task
                and args_dict_for_execution
                and self._has_regular_args(task)
            ):
                import json

                # Filter to only include regular (non-exported) args
                regular_args = self._filter_regular_args(task, args_dict_for_execution)
                if regular_args:
                    args_str = json.dumps(
                        regular_args, sort_keys=True, separators=(",", ":")
                    )
                    status_key = f"{name}({args_str})"
                else:
                    status_key = name
            else:
                status_key = name
            statuses[status_key] = status

            # Execute immediately if needed
            if status.will_run:
                # Warn if re-running due to missing outputs
                if status.reason == "outputs_missing":
                    self.logger.log(
                        LogLevel.WARN,
                        f"Warning: Re-running task '{name}' because declared outputs are missing",
                    )

                self._run_task(task, args_dict_for_execution, process_runner)

        return statuses

    @staticmethod
    def _parse_call_chain(call_chain: str) -> list[tuple[str, str]]:
        """
        Parse TT_CALL_CHAIN environment variable into list of (cache_key, task_name) tuples.

        Args:
        call_chain: Comma-separated entries in 'cache_key:task_name' format

        Returns:
        List of (cache_key, task_name) tuples in the call chain (empty list if chain is empty)
        """
        if not call_chain.strip():
            return []

        entries = []
        for entry in call_chain.split(","):
            entry = entry.strip()
            if not entry:
                continue
            # Split on first ':' to separate cache_key from task_name
            parts = entry.split(":", 1)
            if len(parts) == 2:
                cache_key, task_name = parts
                entries.append((cache_key, task_name))
        return entries

    @staticmethod
    def _make_call_chain_entry(cache_key: str, task_name: str) -> str:
        """
        Create call chain entry in format 'cache_key:task_name'.

        Args:
            cache_key: Unique cache key for this task execution (hash of task + args)
            task_name: Human-readable task name for error messages

        Returns:
            Formatted call chain entry
        """
        return f"{cache_key}:{task_name}"

    @staticmethod
    def _resolve_container_path(host_path: Path, volumes: list[str]) -> Path:
        """
        Resolve the container path for a given host path based on volume mounts.

        Args:
            host_path: Host file system path
            volumes: List of volume mount specifications (e.g., ["./src:/app/src", ".:/workspace"])

        Returns:
            Container path if a matching volume mount is found, otherwise the host path
        """
        # Resolve host_path to absolute to handle relative paths like "."
        host_path = host_path.resolve()

        # Check each volume mount to see if it covers the host_path
        for volume in volumes:
            # Parse volume specification: "host:container[:mode]"
            parts = volume.split(":")
            if len(parts) < 2:
                continue

            mount_host = parts[0]
            mount_container = parts[1]

            # Resolve mount_host to absolute
            mount_host_path = Path(mount_host).resolve()

            # Check if host_path is within or equal to mount_host_path
            try:
                # Get the relative path from mount_host to host_path
                rel_path = host_path.relative_to(mount_host_path)
                # Return the corresponding container path
                if str(rel_path) == ".":
                    return Path(mount_container)
                else:
                    return Path(mount_container) / rel_path
            except ValueError:
                # host_path is not relative to mount_host_path, try next volume
                continue

        # No matching volume mount found, return host path
        return host_path

    def _validate_nested_docker_runner(
        self, task: Task, current_containerized_runner: str
    ) -> bool:
        """
        Validate runner compatibility when already inside a container.

        Args:
            task: Task to validate
            current_containerized_runner: Name of the current containerized runner

        Returns:
            bool: True if shell execution should be forced (compatible scenario)

        Raises:
            ExecutionError: If task requires incompatible Docker runner

        """
        task_runner_name = self._get_effective_runner_name(task)

        # Task specifies a runner - check if it's compatible
        if task_runner_name and task_runner_name != current_containerized_runner:
            task_runner = self.recipe.get_runner(task_runner_name)

            # REFINED REJECTION LOGIC:
            # Only reject if:
            # 1. Task has run_in specified (checked above via task_runner_name)
            # 2. The specified runner has a dockerfile field
            # 3. The dockerfile differs from current container's runner
            # 4. We're in the same project (cross-project invocations are allowed)
            if task_runner and task_runner.dockerfile:
                # Check if this is a cross-project invocation
                parent_project_root = os.environ.get("TT_PROJECT_ROOT", "").strip()
                current_project_root = str(self.recipe.project_root)

                # Allow Docker runner transition if we're in a different project
                if parent_project_root and parent_project_root != current_project_root:
                    # Different project - allow the Docker runner transition
                    return True

                raise ExecutionError(
                    f"Task '{task.name}' requires containerized runner '{task_runner_name}' "
                    f"but is currently executing inside runner '{current_containerized_runner}'. "
                    f"Nested Docker-in-Docker invocations across different containerized runners are not supported. "
                    f"Either remove the runner specification from '{task.name}', ensure it matches "
                    f"the parent task's runner, or use a shell-only runner."
                )

        # If we get here, either:
        # - Same containerized runner name → use it directly
        # - Different shell-only runner → allowed, use its shell/preamble
        # - No runner specified → use shell execution in current container
        return True

    def _run_task(
        self, task: Task, args_dict: dict[str, Any], process_runner: ProcessRunner
    ) -> None:
        """
        Execute a single task.

        Args:
        task: Task to execute
        args_dict: Arguments to substitute in command
        process_runner: ProcessRunner instance for subprocess execution

        Raises:
        ExecutionError: If task execution fails
        """
        # Capture timestamp at task start for consistency (in UTC)
        task_start_time = datetime.now(timezone.utc)

        # Check for recursion via TT_CALL_CHAIN
        current_chain = os.environ.get(self.TT_CALL_CHAIN_ENV_VAR, "")
        chain_list = self._parse_call_chain(current_chain)

        # Use fully-qualified task name (includes import prefix if any)
        task_fqn = task.name  # Already includes import prefix from parser

        # Generate cache key for this task execution (includes args hash)
        cache_key = self._cache_key(task, args_dict)

        # Check if this task execution (same task + args) is already in the call chain
        cache_keys_in_chain = [entry[0] for entry in chain_list]
        if cache_key in cache_keys_in_chain:
            # Recursion detected - build cycle path for error message
            cycle_start_idx = cache_keys_in_chain.index(cache_key)
            # Extract task names from tuples for display
            task_names_in_cycle = [entry[1] for entry in chain_list[cycle_start_idx:]]
            cycle_path = task_names_in_cycle + [task_fqn]
            cycle_str = " → ".join(cycle_path)

            raise ExecutionError(
                f"Recursion detected in task invocation chain:\n"
                f"{cycle_str}\n\n"
                f"Task '{task_fqn}' is already running in the call chain.\n"
                f"This would create an infinite loop."
            )

        # Add current task to chain for child processes
        current_entry = self._make_call_chain_entry(cache_key, task_fqn)
        # Build chain string from existing entries plus current
        chain_entries = [f"{k}:{n}" for k, n in chain_list] + [current_entry]
        updated_chain = ",".join(chain_entries) if chain_entries else current_entry

        # Check if we're already inside a containerized runner
        # Note: Only proceed if the variable is set AND non-empty
        # An empty string means we're not in a containerized environment
        current_containerized_runner = os.environ.get("TT_CONTAINERIZED_RUNNER", "").strip()
        force_shell_execution = False

        if current_containerized_runner:
            # We're inside a container - validate runner compatibility
            force_shell_execution = self._validate_nested_docker_runner(
                task, current_containerized_runner
            )

        # Record the state file's hash before execution
        # This allows us to skip re-reading if no nested tt calls modified it
        initial_state_hash = self.state.get_hash()

        # Parse task arguments to identify exported args
        # Note: args_dict already has defaults applied by CLI (cli.py:413-424)
        from tasktree.parser import parse_arg_spec

        exported_args = set()
        regular_args = {}
        exported_env_vars = {}

        for arg_spec in task.args:
            parsed = parse_arg_spec(arg_spec)
            if parsed.is_exported:
                exported_args.add(parsed.name)
                # Get value and convert to string for environment variable
                # Value should always be in args_dict (CLI applies defaults)
                if parsed.name in args_dict:
                    exported_env_vars[parsed.name] = str(args_dict[parsed.name])
            else:
                if parsed.name in args_dict:
                    regular_args[parsed.name] = args_dict[parsed.name]

        # Collect early built-in variables (those that don't depend on working_dir)
        # These can be used in the working_dir field itself
        early_builtin_vars = self._collect_early_builtin_variables(
            task, task_start_time
        )

        # Resolve working directory
        # Validate that working_dir doesn't contain {{ tt.working_dir }} (circular dependency)
        self._validate_no_working_dir_circular_ref(task.working_dir)
        working_dir_str = self._substitute_builtin(task.working_dir, early_builtin_vars)
        working_dir_str = self._substitute_args(
            working_dir_str, regular_args, exported_args
        )
        working_dir_str = self._substitute_env(working_dir_str)
        working_dir = self.recipe.project_root / working_dir_str

        # Collect all built-in variables (including tt.working_dir now that it's resolved)
        builtin_vars = self._collect_builtin_variables(
            task, working_dir, task_start_time
        )

        # Substitute built-in variables, arguments, and environment variables in command
        cmd = self._substitute_builtin(task.cmd, builtin_vars)
        cmd = self._substitute_args(cmd, regular_args, exported_args)
        cmd = self._substitute_env(cmd)

        # Check if task uses Docker environment
        env_name = self._get_effective_runner_name(task)
        env = None
        if env_name:
            env = self.recipe.get_runner(env_name)

        # Execute command
        self.logger.log(LogLevel.INFO, f"Running: {task.name}")

        # Route to Docker execution or regular execution
        if not force_shell_execution and env and env.dockerfile:
            # Docker execution path - launch container
            self._run_task_in_docker(
                task,
                env,
                cmd,
                working_dir,
                process_runner,
                exported_env_vars,
                updated_chain,
            )
        else:
            # Shell execution path - either local or inside existing container
            if current_containerized_runner and env:
                # Get shell config from task's runner definition
                # env_name was already validated at lines 715-733 above
                assert env is not None, "Runner should exist after validation"
                shell_config = env.shell or ShellConfig(cmd=SHELL_LOOKUP["sh"])
            else:
                # Normal shell resolution
                shell_config = self._resolve_runner(task)

            self._run_command_as_script(
                cmd,
                working_dir,
                task.name,
                shell_config.cmd,
                shell_config.preamble,
                process_runner,
                exported_env_vars,
                updated_chain,
            )

        # Reload state from disk to capture any updates from nested tt calls
        # Only reload if the state file contents have changed since we started
        current_state_hash = self.state.get_hash()
        if current_state_hash != initial_state_hash:
            self.state.load()

        # Update state
        self._update_state(task, args_dict)

    def _run_command_as_script(
        self,
        cmd: str,
        working_dir: Path,
        task_name: str,
        shell_cmd: list[str],
        preamble: str,
        process_runner: ProcessRunner,
        exported_env_vars: dict[str, str] | None = None,
        call_chain: str | None = None,
    ) -> None:
        """
        Execute a command via temporary script file (unified execution path).

        This method handles both single-line and multi-line commands by writing
        them to a temporary script file and executing the script. This provides
        consistent behavior and allows preamble to work with all commands.

        The shell_cmd list is prepended to the script path when invoking the
        subprocess, e.g. ["python"] + ["/tmp/script"] → ["python", "/tmp/script"].
        This is shell-agnostic and works for any interpreter on any platform.

        Args:
        cmd: Command string (single-line or multi-line)
        working_dir: Working directory
        task_name: Task name (for error messages)
        shell_cmd: Full shell invocation list (e.g. ["bash"] or ["python"])
        preamble: Preamble text to prepend to script
        process_runner: ProcessRunner instance to use for subprocess execution
        exported_env_vars: Exported arguments to set as environment variables
        call_chain: TT_CALL_CHAIN value for recursion detection

        Raises:
        ExecutionError: If command execution fails
        """
        # Prepare environment with exported args and call chain
        env = self._prepare_env_with_exports(exported_env_vars, call_chain)

        # Determine script extension: shell-aware on Windows (cmd.exe needs .bat,
        # PowerShell needs .ps1, bash/sh/python need no extension), empty elsewhere.
        script_ext = _get_windows_script_extension(shell_cmd) if platform.system() == "Windows" else ""

        # Create temporary script using context manager — no shebang needed since
        # the interpreter is passed explicitly as shell_cmd in the subprocess call.
        with TempScript(logger=self.logger, cmd=cmd, preamble=preamble, use_shebang=False, script_extension=script_ext) as script_path:
            run_cmd = shell_cmd + [str(script_path)]

            # Execute script file
            try:
                # If streams support fileno, pass them directly (most efficient).
                # CliRunner uses StringIO which has fileno() but raises on call,
                # so capture and write manually in that case.
                if not (_supports_fileno(sys.stdout) and _supports_fileno(sys.stderr)):
                    # CliRunner path: capture and write manually
                    result = process_runner.run(
                        run_cmd,
                        cwd=working_dir,
                        check=True,
                        capture_output=True,
                        text=True,
                        env=env,
                    )
                    if result.stdout:
                        sys.stdout.write(result.stdout)
                    if result.stderr:
                        sys.stderr.write(result.stderr)
                else:
                    process_runner.run(
                        run_cmd,
                        cwd=working_dir,
                        check=True,
                        stdout=sys.stdout,
                        stderr=sys.stderr,
                        env=env,
                    )
            except FileNotFoundError as e:
                # Check if this is a containerized environment
                # Note: Only proceed if the variable is set AND non-empty
                current_containerized_runner = os.environ.get("TT_CONTAINERIZED_RUNNER", "").strip()
                if current_containerized_runner and ("tt" in cmd or "tasktree" in cmd):
                    raise ExecutionError(
                        f"Task '{task_name}' failed: Command not found. "
                        f"When running nested tasks inside Docker container '{current_containerized_runner}', "
                        f"the 'tt' binary must be installed in the container image. "
                        f"Add 'RUN pip install tasktree' to your Dockerfile, or ensure the tasktree package "
                        f"is available in your container's Python environment."
                    ) from e
                else:
                    raise ExecutionError(
                        f"Task '{task_name}' failed: Command not found. {e}"
                    ) from e
            except subprocess.CalledProcessError as e:
                raise ExecutionError(
                    f"Task '{task_name}' failed with exit code {e.returncode}"
                )

    def _substitute_builtin_in_runner(
        self, env: Runner, builtin_vars: dict[str, str]
    ) -> Runner:
        """
        Substitute builtin and environment variables in runner fields.

        Args:
        env: Runner to process
        builtin_vars: Built-in variable values

        Returns:
        New Runner with builtin and environment variables substituted

        Raises:
        ValueError: If builtin variable or environment variable is not defined
        """
        from dataclasses import replace

        # Substitute in volumes (builtin vars first, then env vars)
        substituted_volumes = (
            [
                self._substitute_env(self._substitute_builtin(vol, builtin_vars))
                for vol in env.volumes
            ]
            if env.volumes
            else []
        )

        # Substitute in env_vars values (builtin vars first, then env vars)
        substituted_env_vars = (
            {
                key: self._substitute_env(self._substitute_builtin(value, builtin_vars))
                for key, value in env.env_vars.items()
            }
            if env.env_vars
            else {}
        )

        # Substitute in ports (builtin vars first, then env vars)
        substituted_ports = (
            [
                self._substitute_env(self._substitute_builtin(port, builtin_vars))
                for port in env.ports
            ]
            if env.ports
            else []
        )

        # Substitute in working_dir (builtin vars first, then env vars)
        substituted_working_dir = (
            self._substitute_env(
                self._substitute_builtin(env.working_dir, builtin_vars)
            )
            if env.working_dir
            else ""
        )

        def subst(s: str) -> str:
            return self._substitute_env(self._substitute_builtin(s, builtin_vars))

        # Substitute in docker build args
        substituted_build_args = [subst(arg) for arg in env.args.build]

        # Substitute in docker run args
        substituted_run_args = [subst(arg) for arg in env.args.run]

        # Substitute in shell config (cmd items and preamble)
        substituted_shell = None
        if env.shell is not None:
            substituted_cmd = [subst(item) for item in env.shell.cmd]
            substituted_preamble = subst(env.shell.preamble) if env.shell.preamble else ""
            substituted_shell = ShellConfig(cmd=substituted_cmd, preamble=substituted_preamble)

        # Substitute in dockerfile (builtin vars first, then env vars)
        substituted_dockerfile = subst(env.dockerfile) if env.dockerfile else ""

        # Substitute in context (builtin vars first, then env vars)
        substituted_context = subst(env.context) if env.context else ""

        # Create new environment with substituted values
        return replace(
            env,
            volumes=substituted_volumes,
            env_vars=substituted_env_vars,
            ports=substituted_ports,
            working_dir=substituted_working_dir,
            args=DockerArgs(build=substituted_build_args, run=substituted_run_args),
            shell=substituted_shell,
            dockerfile=substituted_dockerfile,
            context=substituted_context,
        )

    def _run_task_in_docker(
        self,
        task: Task,
        env: Any,
        cmd: str,
        working_dir: Path,
        process_runner: ProcessRunner,
        exported_env_vars: dict[str, str] | None = None,
        call_chain: str | None = None,
    ) -> None:
        """
        Execute task inside Docker container.

        Args:
        task: Task to execute
        env: Docker environment configuration
        cmd: Command to execute
        working_dir: Host working directory
        process_runner: ProcessRunner instance to use for subprocess execution
        exported_env_vars: Exported arguments to set as environment variables
        call_chain: TT_CALL_CHAIN value for recursion detection
        task_output: Control task subprocess output (all, out, err, on-err, none)

        Raises:
        ExecutionError: If Docker execution fails
        """
        # Get builtin variables for substitution in environment fields
        task_start_time = datetime.now(timezone.utc)
        builtin_vars = self._collect_builtin_variables(
            task, working_dir, task_start_time
        )

        # Substitute builtin variables in environment fields (volumes, env_vars, etc.)
        env = self._substitute_builtin_in_runner(env, builtin_vars)

        # Resolve container working directory
        # Treat "." as empty for Docker - it's the default but we want None
        # when neither env nor task explicitly sets working_dir, so Docker uses Dockerfile WORKDIR
        task_wd = "" if task.working_dir == "." else task.working_dir
        container_working_dir = docker_module.resolve_container_working_dir(
            env.working_dir, task_wd
        )

        # Validate and merge exported args with env vars (exported args take precedence)
        docker_env_vars = env.env_vars.copy() if env.env_vars else {}

        # Add nested invocation support environment variables
        docker_env_vars["TT_CONTAINERIZED_RUNNER"] = env.name
        docker_env_vars["TT_STATE_FILE_PATH"] = self.CONTAINER_STATE_FILE_PATH

        # Resolve container path for project root from volume mounts
        container_project_root = self._resolve_container_path(
            self.recipe.project_root, env.volumes or []
        )
        docker_env_vars["TT_PROJECT_ROOT"] = str(container_project_root)

        # Add call chain for recursion detection
        if call_chain:
            docker_env_vars[self.TT_CALL_CHAIN_ENV_VAR] = call_chain

        if exported_env_vars:
            # Check for protected environment variable overrides
            for key in exported_env_vars:
                if key in self.PROTECTED_ENV_VARS:
                    raise ValueError(
                        f"Cannot override protected environment variable: {key}\n"
                        f"Protected variables are: {', '.join(sorted(self.PROTECTED_ENV_VARS))}"
                    )
            docker_env_vars.update(exported_env_vars)

        # Mount state file into container
        # Ensure state file exists before mounting (Docker requires the file to exist)
        if not self.state.state_path.exists():
            self.state.state_path.touch()

        volumes_to_mount = env.volumes.copy() if env.volumes else []
        state_file_host_path = str(self.state.state_path.absolute())

        # Check for volume mount conflicts with state file path
        for volume in volumes_to_mount:
            # Parse volume mount (format: "host:container" or "host:container:ro")
            parts = volume.split(":")
            if len(parts) >= 2:
                container_path = parts[1]
                if container_path == self.CONTAINER_STATE_FILE_PATH:
                    raise ExecutionError(
                        f"Volume mount conflict: User-defined volume '{volume}' conflicts with "
                        f"automatic state file mount at '{self.CONTAINER_STATE_FILE_PATH}'. "
                        f"The state file must be mounted at this location for nested task invocations to work. "
                        f"Please use a different container path for your volume mount."
                    )

        volumes_to_mount.append(f"{state_file_host_path}:{self.CONTAINER_STATE_FILE_PATH}")

        # Create modified environment with merged env vars and volumes using dataclass replace
        from dataclasses import replace

        modified_env = replace(env, env_vars=docker_env_vars, volumes=volumes_to_mount)

        # Execute in container
        try:
            self.docker_manager.run_in_container(
                env=modified_env,
                cmd=cmd,
                working_dir=working_dir,
                container_working_dir=container_working_dir,
                process_runner=process_runner,
            )
        except docker_module.DockerError as e:
            raise ExecutionError(str(e)) from e

    @staticmethod
    def _validate_no_working_dir_circular_ref(text: str) -> None:
        """
        Validate that working_dir field does not contain {{ tt.working_dir }}.

        Using {{ tt.working_dir }} in the working_dir field creates a circular dependency.

        Args:
        text: The working_dir field value to validate

        Raises:
        ExecutionError: If {{ tt.working_dir }} placeholder is found
        """
        import re

        # Pattern to match {{ tt.working_dir }} specifically
        pattern = re.compile(r"\{\{\s*tt\s*\.\s*working_dir\s*}}")

        if pattern.search(text):
            raise ExecutionError(
                "Cannot use {{ tt.working_dir }} in the 'working_dir' field.\n\n"
                "This creates a circular dependency (working_dir cannot reference itself).\n"
                "Other built-in variables like {{ tt.task_name }} or {{ tt.timestamp }} are allowed."
            )

    @staticmethod
    def _substitute_builtin(text: str, builtin_vars: dict[str, str]) -> str:
        """
        Substitute {{ tt.name }} placeholders in text.

        Built-in variables are resolved at execution time.

        Args:
        text: Text with {{ tt.name }} placeholders
        builtin_vars: Built-in variable values

        Returns:
        Text with built-in variables substituted

        Raises:
        ValueError: If built-in variable is not defined
        """
        from tasktree.substitution import substitute_builtin_variables

        return substitute_builtin_variables(text, builtin_vars)

    @staticmethod
    def _substitute_args(
        cmd: str, args_dict: dict[str, Any], exported_args: set[str] | None = None
    ) -> str:
        """
        Substitute {{ arg.name }} placeholders in command string.

        Variables are already substituted at parse time by the parser.
        This only handles runtime argument substitution.

        Args:
        cmd: Command with {{ arg.name }} placeholders
        args_dict: Argument values to substitute (only regular args)
        exported_args: Set of argument names that are exported (not available for substitution)

        Returns:
        Command with arguments substituted

        Raises:
        ValueError: If an exported argument is used in template substitution
        """
        from tasktree.substitution import substitute_arguments

        return substitute_arguments(cmd, args_dict, exported_args)

    @staticmethod
    def _substitute_env(text: str) -> str:
        """
        Substitute {{ env.NAME }} placeholders in text.

        Environment variables are resolved at execution time from os.environ.

        Args:
        text: Text with {{ env.NAME }} placeholders

        Returns:
        Text with environment variables substituted

        Raises:
        ValueError: If environment variable is not set
        """
        from tasktree.substitution import substitute_environment

        return substitute_environment(text)

    def _get_all_inputs(self, task: Task) -> list[str]:
        """
        Get all inputs for a task (explicit + implicit from dependencies).

        Args:
        task: Task to get inputs for

        Returns:
        List of input glob patterns
        """
        # Extract paths from inputs (handle both anonymous strings and named dicts)
        all_inputs = []
        for inp in task.inputs:
            if isinstance(inp, str):
                all_inputs.append(inp)
            elif isinstance(inp, dict):
                # Named input - extract the path value(s)
                all_inputs.extend(inp.values())

        implicit_inputs = get_implicit_inputs(self.recipe, task)
        all_inputs.extend(implicit_inputs)
        return all_inputs

    # TODO: Understand why task isn't used
    def _check_runner_changed(
        self,
        task: Task,
        cached_state: TaskState,
        env_name: str,
        process_runner: ProcessRunner,
    ) -> bool:
        """
        Check if environment definition has changed since last run.

        For shell environments: checks YAML definition hash
        For Docker environments: checks YAML hash AND Docker image ID

        Args:
        task: Task to check
        cached_state: Cached state from previous run
        env_name: Effective runner name (from _get_effective_runner_name)
        process_runner: ProcessRunner instance for subprocess execution

        Returns:
        True if environment definition changed, False otherwise
        """
        # If using platform default (no environment), no definition to track
        if not env_name or env_name == "__platform_default__":
            return False

        # Get environment definition
        env = self.recipe.get_runner(env_name)
        if env is None:
            # Runner was deleted - treat as changed
            return True

        # Compute current environment hash (YAML definition)
        from tasktree.hasher import hash_runner_definition

        current_env_hash = hash_runner_definition(env)
        self.logger.trace(f"Runner '{env_name}' hash: {current_env_hash}")

        # Get cached runner hash
        marker_key = f"_runner_hash_{env_name}"
        cached_env_hash = cached_state.input_state.get(marker_key)

        # If no cached hash (old state file), treat as changed to establish baseline
        if cached_env_hash is None:
            self.logger.trace(f"No cached runner hash found for '{env_name}'")
            return True

        self.logger.trace(f"Cached runner hash for '{env_name}': {cached_env_hash}")

        # Check if YAML definition changed
        if current_env_hash != cached_env_hash:
            self.logger.trace(f"Runner '{env_name}' hash changed (cached: {cached_env_hash}, current: {current_env_hash})")
            return True  # YAML changed, no need to check image

        # For Docker environments, also check context files, base image digests, and image ID
        if env.dockerfile:
            if self._check_docker_context_changed(env_name, env, cached_state):
                return True
            if self._check_base_image_digests_changed(env_name, env, cached_state):
                return True
            return self._check_docker_image_changed(
                env, cached_state, env_name, process_runner
            )

        # Shell environment with unchanged hash
        return False

    def _check_docker_image_changed(
        self,
        env: Runner,
        cached_state: TaskState,
        env_name: str,
        process_runner: ProcessRunner,
    ) -> bool:
        """
        Check if Docker image ID has changed.

        Builds the image and compares the resulting image ID with the cached ID.
        This detects changes from unpinned base images, network-dependent builds, etc.

        Args:
        env: Docker runner definition
        cached_state: Cached state from previous run
        env_name: Runner name
        process_runner: ProcessRunner instance for subprocess execution

        Returns:
        True if image ID changed, False otherwise
        """
        # Build/ensure image is built and get its ID
        try:
            image_tag, current_image_id = self.docker_manager.ensure_image_built(
                env, process_runner
            )
            self.logger.trace(f"Docker image ID for '{env_name}': {current_image_id}")
        except Exception:
            # If we can't build, treat as changed (will fail later with better error)
            self.logger.trace(f"Failed to build Docker image for '{env_name}', treating as changed")
            return True

        # Get cached image ID
        image_id_key = f"_docker_image_id_{env_name}"
        cached_image_id = cached_state.input_state.get(image_id_key)

        # If no cached ID (first run or old state), treat as changed
        if cached_image_id is None:
            self.logger.trace(f"No cached Docker image ID found for '{env_name}'")
            return True

        self.logger.trace(f"Cached Docker image ID for '{env_name}': {cached_image_id}")

        # Compare image IDs
        if current_image_id != cached_image_id:
            self.logger.trace(f"Docker image ID changed for '{env_name}' (cached: {cached_image_id}, current: {current_image_id})")
            return True

        return False

    def _check_docker_context_changed(
        self,
        env_name: str,
        env: Runner,
        cached_state: TaskState,
    ) -> bool:
        """Check if any file in the Docker build context has changed.

        Compares current context file mtimes against values cached under
        ``_ctx_{env_name}_{relpath}`` keys.  Returns True if any file is
        new, modified, or deleted since the last run.

        Args:
            env_name: Runner name (used as part of cache-key prefix)
            env: Docker runner definition (provides ``context`` path)
            cached_state: Cached state from previous run

        Returns:
            True if the context directory contents have changed, False otherwise
        """
        if not env.context:
            return False

        prefix = f"_ctx_{env_name}_"
        cached_ctx: dict[str, float] = {
            k[len(prefix):]: v
            for k, v in cached_state.input_state.items()
            if k.startswith(prefix)
        }

        context_path = self.recipe.project_root / env.context
        dockerignore_path = context_path / ".dockerignore"
        dockerignore_spec = (
            docker_module.parse_dockerignore(dockerignore_path)
            if dockerignore_path.exists()
            else None
        )

        current_ctx = self._current_context_mtimes(context_path, dockerignore_path, dockerignore_spec)

        # New or modified files
        for rel_path, mtime in current_ctx.items():
            if rel_path not in cached_ctx:
                self.logger.trace(f"New context file detected for runner '{env_name}': {rel_path}")
                return True
            if mtime != cached_ctx[rel_path]:
                self.logger.trace(f"Modified context file detected for runner '{env_name}': {rel_path}")
                return True

        # Deleted files
        for rel_path in cached_ctx:
            if rel_path not in current_ctx:
                self.logger.trace(f"Deleted context file detected for runner '{env_name}': {rel_path}")
                return True

        if self._check_dockerignore_changed(env_name, dockerignore_path, cached_state):
            return True

        return False

    def _check_base_image_digests_changed(
        self,
        env_name: str,
        env: Runner,
        cached_state: TaskState,
    ) -> bool:
        """Check if any base image's local digest has changed since last run.

        Reads the Dockerfile, extracts FROM directives, and compares each
        image's current local digest (via ``docker inspect``) against the
        value stored in cached state.  Returns True if any digest differs or
        is newly present.

        Args:
            env_name: Runner name (used as part of cache-key prefix)
            env: Docker runner definition
            cached_state: Cached state from previous run

        Returns:
            True if any base image digest has changed, False otherwise
        """
        if not env.dockerfile:
            return False

        dockerfile_path = self.recipe.project_root / env.dockerfile
        try:
            dockerfile_content = dockerfile_path.read_text()
        except OSError:
            return False

        images = docker_module.extract_from_images(dockerfile_content)
        for image_name, _ in images:
            current_digest = docker_module.get_local_base_image_digest(image_name)
            cached_digest = cached_state.input_state.get(f"_base_img_{env_name}_{image_name}")
            if current_digest != cached_digest:
                self.logger.trace(
                    f"Base image digest changed for '{image_name}' in runner '{env_name}'"
                )
                return True

        return False

    def _check_dockerignore_changed(
        self,
        env_name: str,
        dockerignore_path: Path,
        cached_state: TaskState,
    ) -> bool:
        """Check if the .dockerignore file has been added, modified, or deleted."""
        dockerignore_key = dockerignore_path.relative_to(self.recipe.project_root).as_posix()
        cached_mtime = cached_state.input_state.get(dockerignore_key)
        if dockerignore_path.exists():
            current_mtime = dockerignore_path.stat().st_mtime
            if cached_mtime is None or current_mtime != cached_mtime:
                self.logger.trace(f".dockerignore changed for runner '{env_name}'")
                return True
        elif cached_mtime is not None:
            self.logger.trace(f".dockerignore deleted for runner '{env_name}'")
            return True
        return False

    def _current_context_mtimes(
        self,
        context_path: Path,
        dockerignore_path: Path,
        dockerignore_spec,
    ) -> dict[str, float]:
        """Return relative-path → mtime for every tracked file in the context directory."""
        current_ctx: dict[str, float] = {}
        if not context_path.is_dir():
            return current_ctx
        for file_path in context_path.rglob("*"):
            if not file_path.is_file():
                continue
            if file_path == dockerignore_path:
                continue
            if dockerignore_spec is not None:
                try:
                    relative_to_context = file_path.relative_to(context_path)
                    if dockerignore_spec.match_file(str(relative_to_context)):
                        continue
                except ValueError:
                    pass
            relative_path = file_path.relative_to(self.recipe.project_root).as_posix()
            current_ctx[relative_path] = file_path.stat().st_mtime
        return current_ctx

    def _check_inputs_changed(
        self, task: Task, cached_state: TaskState, all_inputs: list[str]
    ) -> list[str]:
        """
        Check if any input files have changed since last run.

        Args:
        task: Task to check
        cached_state: Cached state from previous run
        all_inputs: All input glob patterns

        Returns:
        List of changed file paths
        """
        changed_files = []

        # Expand glob patterns
        input_files = self._expand_globs(all_inputs, task.working_dir)
        self.logger.trace(f"Checking {len(input_files)} input file(s) for task '{task.name}'")

        for file_path in input_files:
            # Regular file check
            file_path_obj = self.recipe.project_root / task.working_dir / file_path
            if not file_path_obj.exists():
                self.logger.trace(f"Input file '{file_path}' does not exist, skipping")
                continue

            current_mtime = file_path_obj.stat().st_mtime

            # Check if file is in cached state
            cached_mtime = cached_state.input_state.get(file_path)
            if cached_mtime is None:
                self.logger.trace(f"Input file '{file_path}' has no cached mtime, treating as changed (current mtime: {current_mtime})")
                changed_files.append(file_path)
            elif current_mtime > cached_mtime:
                self.logger.trace(f"Input file '{file_path}' has changed (cached mtime: {cached_mtime}, current mtime: {current_mtime})")
                changed_files.append(file_path)
            else:
                self.logger.trace(f"Input file '{file_path}' is unchanged (mtime: {current_mtime})")

        return changed_files

    @staticmethod
    def _expand_output_paths(task: Task) -> list[str]:
        """
        Extract all output paths from task outputs (both named and anonymous).

        Args:
        task: Task with outputs to extract

        Returns:
        List of output path patterns (glob patterns as strings)
        """
        paths = []
        for output in task.outputs:
            if isinstance(output, str):
                # Anonymous output: just the path string
                paths.append(output)
            elif isinstance(output, dict):
                # Named output: extract the path value
                paths.extend(output.values())
        return paths

    def _check_outputs_missing(self, task: Task) -> list[str]:
        """
        Check if any declared outputs are missing.

        Args:
        task: Task to check

        Returns:
        List of output patterns that have no matching files
        """
        if not task.outputs:
            return []

        missing_patterns = []
        base_path = self.recipe.project_root / task.working_dir

        # Expand outputs to paths (handles both named and anonymous)
        output_paths = self._expand_output_paths(task)
        self.logger.trace(f"Checking {len(output_paths)} output pattern(s) for task '{task.name}'")

        for pattern in output_paths:
            # Check if pattern has any matches
            matches = list(base_path.glob(pattern))
            if not matches:
                self.logger.trace(f"Output pattern '{pattern}' has no matches (missing)")
                missing_patterns.append(pattern)
            else:
                self.logger.trace(f"Output pattern '{pattern}' has {len(matches)} match(es): {[str(m.relative_to(base_path)) for m in matches]}")

        return missing_patterns

    def _expand_globs(self, patterns: list[str], working_dir: str) -> list[str]:
        """
        Expand glob patterns to actual file paths.

        Args:
        patterns: List of glob patterns
        working_dir: Working directory to resolve patterns from

        Returns:
        List of file paths (relative to working_dir)
        """
        files = []
        base_path = self.recipe.project_root / working_dir

        for pattern in patterns:
            # Use pathlib's glob
            matches = base_path.glob(pattern)
            for match in matches:
                if match.is_file():
                    # Make relative to working_dir
                    rel_path = match.relative_to(base_path)
                    files.append(str(rel_path))

        return files

    def _update_state(self, task: Task, args_dict: dict[str, Any]) -> None:
        """
        Update state after task execution.
        """
        cache_key = self._cache_key(task, args_dict)
        input_state = self._input_files_to_modified_times(task)

        env_name = self._get_effective_runner_name(task)
        if env_name:
            env = self.recipe.get_runner(env_name)
            if env:
                input_state[f"_runner_hash_{env_name}"] = hash_runner_definition(env)
                if env.dockerfile:
                    input_state |= self._docker_inputs_to_modified_times(env_name, env)

        new_state = TaskState(last_run=time.time(), input_state=input_state)
        self.state.set(cache_key, new_state)
        self.state.save()

    def _cache_key(self, task: Task, args_dict: dict[str, Any]) -> str:
        """
        """
        effective_env = self._get_effective_runner_name(task)
        task_hash = hash_task(
            task.cmd,
            task.outputs,
            task.working_dir,
            task.args,
            effective_env,
            task.deps,
        )
        args_hash = hash_args(args_dict) if args_dict else None
        return make_cache_key(task_hash, args_hash)

    def _input_files_to_modified_times(self, task: Task) -> dict[str, float]:
        """
        """
        input_files = self._expand_globs(self._get_all_inputs(task), task.working_dir)

        input_state = {}
        for file_path in input_files:
            file_path_obj = self.recipe.project_root / task.working_dir / file_path
            if file_path_obj.exists():
                input_state[file_path] = file_path_obj.stat().st_mtime

        return input_state

    def _docker_inputs_to_modified_times(
        self, env_name: str, env: Runner
    ) -> dict[str, float]:
        """Record mtimes for all inputs that affect a Docker runner's build context.

        Tracks: Dockerfile mtime, .dockerignore mtime (explicit key), per-file
        mtimes for every non-ignored file in the context directory, and base
        image digests parsed from the Dockerfile.
        """
        input_state = dict()
        # Record Dockerfile mtime
        dockerfile_path = self.recipe.project_root / env.dockerfile
        if dockerfile_path.exists():
            input_state[env.dockerfile] = dockerfile_path.stat().st_mtime

        # Record .dockerignore mtime if exists
        context_path = self.recipe.project_root / env.context
        dockerignore_path = context_path / ".dockerignore"
        if dockerignore_path.exists():
            relative_dockerignore = dockerignore_path.relative_to(self.recipe.project_root).as_posix()
            input_state[relative_dockerignore] = dockerignore_path.stat().st_mtime

        # Record per-file mtimes for context directory (respecting .dockerignore)
        dockerignore_spec = docker_module.parse_dockerignore(dockerignore_path) if dockerignore_path.exists() else None
        for rel_path, mtime in self._current_context_mtimes(context_path, dockerignore_path, dockerignore_spec).items():
            input_state[f"_ctx_{env_name}_{rel_path}"] = mtime

        # Record local digests of base images from Dockerfile
        try:
            dockerfile_content = dockerfile_path.read_text()
            images = docker_module.extract_from_images(dockerfile_content)
            for image_name, _ in images:
                digest = docker_module.get_local_base_image_digest(image_name)
                if digest is not None:
                    input_state[f"_base_img_{env_name}_{image_name}"] = digest
        except OSError:
            pass

        # For Docker environments, also store the image ID
        # Image was already built during check phase or task execution
        if env_name in self.docker_manager._built_images:
            image_tag, image_id = self.docker_manager._built_images[env_name]
            input_state[f"_docker_image_id_{env_name}"] = image_id

        return input_state
