# argumentor

argumentor is a simple and lightweight library to build complex command-line tools.

## Features

- Differenciate commands from options
- Define aliases for commands and options
- Automatically generate help pages
- Set default values
- No external dependencies

## Installation

### Using pip

The argumentor library can be installed from the [Python Package Index (PyPI)](https://pypi.org/project/argumentor/):

```bash
$ pip install argumentor
```

### Installing from source

Using pip, it is also possible to install a package directly from source.

First clone the source code repository hosted on Codeberg:

```bash
$ git clone https://codeberg.org/camelia/python-argumentor argumentor
```

Then, enter the local repository and install argumentor (you may want to use a virtual environment):

```bash
$ cd argumentor
$ pip install .
```

## Usage

Below is a minimalist code snippet that aims to demonstrate some basic uses of argumentor:

```python
import sys
from argumentor import Argumentor
from argumentor.exc import ParsingError

argm = Argumentor("program-name")

argm.register_command(
    "cmd1",
    description="command 1",
)
argm.register_command(
    "cmd2",
    description="command 2",
)

argm.register_option(
    "--opt",
    "-o",
    description="global option 1",
)

try:
    cmd, opts = argm.parse()
except ParsingError as err:
    print(err)
    sys.exit(1)
```

More information about usage can be found in the [documentation](https://pyargumentor.camelia.dev).

## License

argumentor is free software! You are free to use, copy, modify, share and redistribute it under the terms of the [GNU Lesser General Public License, version 3 or later](https://codeberg.org/camelia/python-argumentor/src/branch/main/LICENSE).

![LGPLv3 badge](https://www.gnu.org/graphics/lgplv3-147x51.png)
