
import sys

try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup

# invalid email
# download url
# url
# project urls

setup(
    name ="raelabs",
    packages=[".",],
    version='0.0.0',
    description="responsible. autonomous. engineering.",
    long_description="""
## Overview
raelabs is a Python library for doing awesome things.
This name has been reserved using [Reserver](https://github.com/openscilab/reserver).
""",
    long_description_content_type='text/markdown',
    author="Kyle Smith",
    author_email="kyle@raelabs.dev",
    url="https://raelabs.dev",
    download_url="https://download_url.com",
    keywords="python3 python reserve reserver reserved",
    project_urls={
            'Source':"https://github.com/raelabs",
    },
    install_requires="",
    python_requires='>=3.6',
    classifiers=[
        'Development Status :: 1 - Planning',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
    license="LicenseRef-PolyForm-Free-Trial-1.0.0-RAE",
)

