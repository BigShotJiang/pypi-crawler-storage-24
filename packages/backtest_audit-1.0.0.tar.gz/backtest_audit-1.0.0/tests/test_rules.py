import ast
import pytest

from backtest_audit.parser.resolver import resolve_constants, resolve_method_assignments
from backtest_audit.parser.classifier import is_backtest_file
from backtest_audit.rules.look_ahead import NegativeShiftRule, NegativePctChangeRule
from backtest_audit.rules.leakage import FitBeforeSplitRule, FitTransformFullDataRule
from backtest_audit.rules.statistical import SharpeAnnualizationRule, NoTransactionCostRule


# ── Helpers ───────────────────────────────────────────────────────────────────

def parse(source: str):
    tree = ast.parse(source)
    lines = source.splitlines()
    return tree, lines


def parse_with_context(source: str):
    tree = ast.parse(source)
    lines = source.splitlines()
    constants = resolve_constants(tree)
    method_assignments = resolve_method_assignments(tree)
    is_bt = is_backtest_file(tree)
    return tree, lines, constants, method_assignments, is_bt


# ── LAB001 ────────────────────────────────────────────────────────────────────

def test_lab001_detects_negative_literal():
    tree, lines, c, m, bt = parse_with_context("df['x'] = df['close'].shift(-1)")
    rule = NegativeShiftRule(lines, constants=c)
    rule.visit(tree)
    assert len(rule.violations) == 1
    assert rule.violations[0].code == "LAB001"


def test_lab001_passes_positive_literal():
    tree, lines, c, m, bt = parse_with_context("df['x'] = df['close'].shift(1)")
    rule = NegativeShiftRule(lines, constants=c)
    rule.visit(tree)
    assert len(rule.violations) == 0


def test_lab001_detects_variable_with_negative_value():
    """shift(lookahead_window) where lookahead_window = -5 must be flagged."""
    source = """
lookahead_window = -5
df['x'] = df['close'].shift(lookahead_window)
"""
    tree, lines, c, m, bt = parse_with_context(source)
    rule = NegativeShiftRule(lines, constants=c)
    rule.visit(tree)
    assert len(rule.violations) == 1
    assert rule.violations[0].code == "LAB001"


def test_lab001_passes_negative_of_negative_variable():
    """shift(-n) where n = -1 resolves to shift(1) — must NOT be flagged."""
    source = """
n = -1
df['x'] = df['close'].shift(-n)
"""
    tree, lines, c, m, bt = parse_with_context(source)
    rule = NegativeShiftRule(lines, constants=c)
    rule.visit(tree)
    assert len(rule.violations) == 0


def test_lab001_passes_no_shift():
    tree, lines, c, m, bt = parse_with_context("df['x'] = df['close'].mean()")
    rule = NegativeShiftRule(lines, constants=c)
    rule.visit(tree)
    assert len(rule.violations) == 0


# ── LAB002 ────────────────────────────────────────────────────────────────────

def test_lab002_detects_negative_literal():
    tree, lines, c, m, bt = parse_with_context("df['r'] = df['close'].pct_change(-5)")
    rule = NegativePctChangeRule(lines, constants=c)
    rule.visit(tree)
    assert len(rule.violations) == 1
    assert rule.violations[0].code == "LAB002"


def test_lab002_passes_positive_literal():
    tree, lines, c, m, bt = parse_with_context("df['r'] = df['close'].pct_change(5)")
    rule = NegativePctChangeRule(lines, constants=c)
    rule.visit(tree)
    assert len(rule.violations) == 0


def test_lab002_detects_negative_variable():
    source = """
period = -5
df['r'] = df['close'].pct_change(period)
"""
    tree, lines, c, m, bt = parse_with_context(source)
    rule = NegativePctChangeRule(lines, constants=c)
    rule.visit(tree)
    assert len(rule.violations) == 1


# ── LEAK001 ───────────────────────────────────────────────────────────────────

def test_leak001_detects_fit_without_split():
    tree, lines = parse("scaler.fit(X)")
    rule = FitBeforeSplitRule(lines)
    rule.visit(tree)
    rule.finalize()
    assert len(rule.violations) == 1
    assert rule.violations[0].code == "LEAK001"


def test_leak001_passes_when_split_present():
    source = """
from sklearn.model_selection import train_test_split
X_train, X_test = train_test_split(X, shuffle=False)
scaler.fit(X_train)
"""
    tree, lines = parse(source)
    rule = FitBeforeSplitRule(lines)
    rule.visit(tree)
    rule.finalize()
    assert len(rule.violations) == 0


def test_leak001_passes_with_no_fit_calls():
    tree, lines = parse("x = 1 + 1")
    rule = FitBeforeSplitRule(lines)
    rule.visit(tree)
    rule.finalize()
    assert len(rule.violations) == 0


# ── LEAK002 ───────────────────────────────────────────────────────────────────

def test_leak002_detects_fit_transform():
    tree, lines = parse("X_scaled = scaler.fit_transform(X)")
    rule = FitTransformFullDataRule(lines)
    rule.visit(tree)
    assert len(rule.violations) == 1
    assert rule.violations[0].code == "LEAK002"


def test_leak002_detects_fit_transform_in_comprehension():
    """fit_transform inside a list comprehension must still be caught."""
    source = """
from sklearn.preprocessing import MinMaxScaler
scalers = [MinMaxScaler().fit_transform(df[[col]]) for col in ['open', 'high']]
"""
    tree, lines = parse(source)
    rule = FitTransformFullDataRule(lines)
    rule.visit(tree)
    assert len(rule.violations) == 1


def test_leak002_passes_transform_only():
    tree, lines = parse("X_scaled = scaler.transform(X_test)")
    rule = FitTransformFullDataRule(lines)
    rule.visit(tree)
    assert len(rule.violations) == 0


# ── STAT001 ───────────────────────────────────────────────────────────────────

def test_stat001_detects_named_sharpe_without_annualization():
    tree, lines, c, m, bt = parse_with_context(
        "sharpe = returns.mean() / returns.std()"
    )
    rule = SharpeAnnualizationRule(lines, method_assignments=m)
    rule.visit(tree)
    assert len(rule.violations) == 1
    assert rule.violations[0].code == "STAT001"


def test_stat001_passes_annualized_sharpe():
    tree, lines, c, m, bt = parse_with_context(
        "sharpe = (returns.mean() / returns.std()) * np.sqrt(252)"
    )
    rule = SharpeAnnualizationRule(lines, method_assignments=m)
    rule.visit(tree)
    assert len(rule.violations) == 0


def test_stat001_detects_direct_mean_over_std_any_name():
    """ratio_result = mean()/std() must be caught regardless of variable name."""
    source = """
mu = df['close'].pct_change().mean()
sigma = df['close'].pct_change().std()
ratio_result = mu / sigma
"""
    tree, lines, c, m, bt = parse_with_context(source)
    rule = SharpeAnnualizationRule(lines, method_assignments=m)
    rule.visit(tree)
    assert len(rule.violations) == 1
    assert rule.violations[0].code == "STAT001"


def test_stat001_passes_aliased_annualized_ratio():
    source = """
import numpy as np
mu = returns.mean()
sigma = returns.std()
ratio_result = (mu / sigma) * np.sqrt(252)
"""
    tree, lines, c, m, bt = parse_with_context(source)
    rule = SharpeAnnualizationRule(lines, method_assignments=m)
    rule.visit(tree)
    assert len(rule.violations) == 0


def test_stat001_passes_non_sharpe_assignment():
    tree, lines, c, m, bt = parse_with_context("x = some_value + other_value")
    rule = SharpeAnnualizationRule(lines, method_assignments=m)
    rule.visit(tree)
    assert len(rule.violations) == 0


# ── STAT002 ───────────────────────────────────────────────────────────────────

def test_stat002_detects_missing_costs_in_backtest_file():
    source = """
import yfinance as yf

def backtest(prices):
    returns = prices.pct_change()
    return returns.sum()
"""
    tree, lines, c, m, bt = parse_with_context(source)
    rule = NoTransactionCostRule(lines, is_backtest=bt)
    rule.visit(tree)
    rule.finalize()
    assert bt is True
    assert len(rule.violations) == 1
    assert rule.violations[0].code == "STAT002"


def test_stat002_does_not_fire_on_non_backtest_file():
    """STAT002 must not fire on test utilities or unrelated scripts."""
    source = """
import pandas as pd

def valid_strategy(df):
    df['signal'] = df['close'].shift(1)
    return df
"""
    tree, lines, c, m, bt = parse_with_context(source)
    rule = NoTransactionCostRule(lines, is_backtest=bt)
    rule.visit(tree)
    rule.finalize()
    assert bt is False
    assert len(rule.violations) == 0


def test_stat002_passes_when_commission_present():
    source = """
import yfinance as yf

commission = 0.001

def backtest(prices):
    returns = prices.pct_change() - commission
    return returns.sum()
"""
    tree, lines, c, m, bt = parse_with_context(source)
    rule = NoTransactionCostRule(lines, is_backtest=bt)
    rule.visit(tree)
    rule.finalize()
    assert len(rule.violations) == 0


# ── Classifier ────────────────────────────────────────────────────────────────

def test_classifier_detects_yfinance_import():
    source = "import yfinance as yf"
    tree, _ = parse(source)
    assert is_backtest_file(tree) is True


def test_classifier_detects_returns_variable():
    source = "returns = prices.pct_change()"
    tree, _ = parse(source)
    assert is_backtest_file(tree) is True


def test_classifier_rejects_plain_utility_file():
    source = """
import pandas as pd

def load_data(filepath):
    return pd.read_csv(filepath)
"""
    tree, _ = parse(source)
    assert is_backtest_file(tree) is False