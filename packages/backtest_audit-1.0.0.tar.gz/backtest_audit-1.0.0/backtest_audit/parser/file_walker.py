import ast
from pathlib import Path
from typing import List, Tuple


def collect_python_files(path: str) -> List[Path]:
    p = Path(path)
    if p.is_file() and p.suffix == ".py":
        return [p]
    elif p.is_dir():
        return sorted(p.rglob("*.py"))
    return []


def parse_file(filepath: Path) -> Tuple[ast.Module, List[str]]:
    with open(filepath, "r", encoding="utf-8") as f:
        source = f.read()
    tree = ast.parse(source, filename=str(filepath))
    lines = source.splitlines()
    return tree, lines


def relative_path(filepath: Path, root: Path) -> str:
    try:
        return str(filepath.relative_to(root))
    except ValueError:
        return str(filepath)