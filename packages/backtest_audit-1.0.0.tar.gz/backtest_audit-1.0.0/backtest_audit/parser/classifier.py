import ast

_FINANCE_IMPORTS = {
    "yfinance", "vectorbt", "backtrader", "zipline", "zipline_reloaded",
    "quantlib", "pyfolio", "alphalens", "empyrical", "ffn", "bt",
    "pandas_datareader", "ta", "talib", "finta",
    "alpaca_trade_api", "alpaca", "ib_insync", "ccxt",
}

_BACKTEST_VARNAMES = {
    "returns", "portfolio", "pnl", "equity_curve", "positions",
    "trades", "signals", "strategy", "weights", "backtest",
    "prices", "sharpe", "drawdown", "alpha", "beta",
}

_BACKTEST_ARG_NAMES = {
    "prices", "returns", "portfolio", "signals", "strategy",
}


def is_backtest_file(tree: ast.Module) -> bool:
    """
    Heuristic classifier. Returns True if the file looks like
    backtesting or quantitative trading code.

    Checks for:
    - Finance library imports
    - Backtest-related variable names
    - Backtest-related function argument names

    Used to gate STAT002 so it does not fire on test files,
    utility scripts, or unrelated Python modules.
    """
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.split(".")[0] in _FINANCE_IMPORTS:
                    return True

        if isinstance(node, ast.ImportFrom):
            if node.module and node.module.split(".")[0] in _FINANCE_IMPORTS:
                return True

        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    if any(kw in target.id.lower() for kw in _BACKTEST_VARNAMES):
                        return True

        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for arg in node.args.args:
                if any(kw in arg.arg.lower() for kw in _BACKTEST_ARG_NAMES):
                    return True

    return False