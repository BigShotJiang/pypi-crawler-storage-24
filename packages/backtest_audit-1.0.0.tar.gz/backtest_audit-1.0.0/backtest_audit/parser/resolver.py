import ast
from typing import Any, Dict


def resolve_constants(tree: ast.Module) -> Dict[str, Any]:
    """
    Collect simple numeric constant assignments from the AST.
    Handles:
      x = 5     → {'x': 5}
      x = -5    → {'x': -5}
    First assignment wins. Does not handle reassignment or augmented assignment.
    """
    constants: Dict[str, Any] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                name = node.targets[0].id
                if name not in constants:
                    value = _extract_numeric(node.value)
                    if value is not None:
                        constants[name] = value
    return constants


def resolve_method_assignments(tree: ast.Module) -> Dict[str, str]:
    """
    Track variables assigned from a single method call.
      mu    = df['close'].pct_change().mean()  →  {'mu': 'mean'}
      sigma = returns.std()                    →  {'sigma': 'std'}
    Used by STAT001 to detect aliased mean/std divisions.
    """
    assignments: Dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                name = node.targets[0].id
                if (
                    isinstance(node.value, ast.Call)
                    and isinstance(node.value.func, ast.Attribute)
                ):
                    assignments[name] = node.value.func.attr
    return assignments


def _extract_numeric(node: ast.expr):
    """Extract a numeric value from a constant or negated-constant node."""
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if (
        isinstance(node, ast.UnaryOp)
        and isinstance(node.op, ast.USub)
        and isinstance(node.operand, ast.Constant)
        and isinstance(node.operand.value, (int, float))
    ):
        return -node.operand.value
    return None