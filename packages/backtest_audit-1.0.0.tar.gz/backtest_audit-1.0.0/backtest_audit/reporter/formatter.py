import json
from typing import Dict, List
from ..rules.base import Violation, SEVERITY_ERROR

# ANSI escape codes
RESET  = "\033[0m"
BOLD   = "\033[1m"
DIM    = "\033[2m"
RED    = "\033[31m"
YELLOW = "\033[33m"
CYAN   = "\033[36m"
WHITE  = "\033[97m"


def _severity_color(severity: str) -> str:
    return RED if severity == SEVERITY_ERROR else YELLOW


def format_report(results: Dict[str, List[Violation]]) -> str:
    lines = []
    total_errors = 0
    total_warnings = 0

    for filepath, violations in results.items():
        if not violations:
            continue

        errors   = [v for v in violations if v.severity == SEVERITY_ERROR]
        warnings = [v for v in violations if v.severity != SEVERITY_ERROR]
        total_errors   += len(errors)
        total_warnings += len(warnings)

        count_str = f"{len(violations)} issue{'s' if len(violations) != 1 else ''}"
        bar_len   = max(0, 56 - len(filepath))

        lines.append(
            f"\n{BOLD}{CYAN}── {filepath} {'─' * bar_len} {count_str} ──{RESET}"
        )
        lines.append("")

        for v in sorted(violations, key=lambda x: x.line):
            color = _severity_color(v.severity)
            lines.append(
                f"  {BOLD}{color}[{v.code}]{RESET} "
                f"{WHITE}{v.message}{RESET}  "
                f"{DIM}line {v.line}{RESET}"
            )
            if v.source_line:
                lines.append(f"  {DIM}{v.source_line}{RESET}")
            lines.append(f"  {CYAN}↳ {v.suggestion}{RESET}")
            lines.append("")

    # Summary bar
    total = total_errors + total_warnings
    if total == 0:
        lines.append(f"\n{BOLD}✓  No issues found.{RESET}\n")
    else:
        parts = []
        if total_errors:
            parts.append(f"{RED}{BOLD}{total_errors} error{'s' if total_errors != 1 else ''}{RESET}")
        if total_warnings:
            parts.append(f"{YELLOW}{BOLD}{total_warnings} warning{'s' if total_warnings != 1 else ''}{RESET}")
        lines.append("─" * 70)
        lines.append(", ".join(parts) + "\n")

    return "\n".join(lines)


def format_json(results: Dict[str, List[Violation]]) -> str:
    output = {
        filepath: [
            {
                "code":        v.code,
                "message":     v.message,
                "suggestion":  v.suggestion,
                "line":        v.line,
                "col":         v.col,
                "source_line": v.source_line,
                "severity":    v.severity,
            }
            for v in violations
        ]
        for filepath, violations in results.items()
    }
    return json.dumps(output, indent=2)