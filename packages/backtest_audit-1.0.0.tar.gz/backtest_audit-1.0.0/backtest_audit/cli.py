import ast
import sys
from pathlib import Path
from typing import Dict, List

import click

from .parser.file_walker import collect_python_files, parse_file, relative_path
from .parser.resolver import resolve_constants, resolve_method_assignments
from .parser.classifier import is_backtest_file
from .rules import ALL_RULES, RULE_REGISTRY
from .rules.base import Violation
from .reporter.formatter import format_report, format_json


def run_rules(
    tree: ast.Module,
    lines: List[str],
    ignore: frozenset,
    constants: dict,
    method_assignments: dict,
    is_backtest: bool,
) -> List[Violation]:
    violations = []
    for RuleClass in ALL_RULES:
        rule = RuleClass(
            lines,
            constants=constants,
            method_assignments=method_assignments,
            is_backtest=is_backtest,
        )
        rule.visit(tree)
        if hasattr(rule, "finalize"):
            rule.finalize()
        for v in rule.violations:
            if v.code not in ignore:
                violations.append(v)
    return sorted(violations, key=lambda v: v.line)


@click.group()
@click.version_option()
def main():
    """backtest-audit: static analysis for Python backtesting code."""
    pass


@main.command()
@click.argument("path", default=".")
@click.option(
    "--format", "output_format",
    default="pretty",
    type=click.Choice(["pretty", "json"]),
    help="Output format.",
)
@click.option(
    "--ignore", default="",
    help="Comma-separated rule codes to ignore. Example: --ignore LAB002,STAT002",
)
def check(path: str, output_format: str, ignore: str):
    """Check a file or directory for backtest errors."""
    ignore_set = frozenset(c.strip() for c in ignore.split(",") if c.strip())
    root = Path(".").resolve()
    target = Path(path).resolve()

    files = collect_python_files(str(target))
    if not files:
        click.echo(f"No Python files found at: {path}")
        sys.exit(0)

    results: Dict[str, List[Violation]] = {}
    for f in files:
        try:
            tree, lines = parse_file(f)
            constants = resolve_constants(tree)
            method_assignments = resolve_method_assignments(tree)
            is_bt = is_backtest_file(tree)
            rel = relative_path(f, root)
            results[rel] = run_rules(
                tree, lines, ignore_set, constants, method_assignments, is_bt
            )
        except SyntaxError as e:
            click.echo(f"Syntax error parsing {f}: {e}", err=True)

    if output_format == "json":
        click.echo(format_json(results))
    else:
        click.echo(format_report(results))

    error_count = sum(
        1 for vs in results.values()
        for v in vs
        if v.severity == "error"
    )
    sys.exit(1 if error_count > 0 else 0)


@main.command(name="rules")
def list_rules():
    """List all available rules and their descriptions."""
    current_category = None
    for code, category, description in RULE_REGISTRY:
        if category != current_category:
            click.echo(f"\n{category}")
            click.echo("─" * 40)
            current_category = category
        click.echo(f"  {code}  {description}")
    click.echo("")


if __name__ == "__main__":
    main()