import ast
from typing import Any, Dict, List
from .base import BaseRule, SEVERITY_ERROR, SEVERITY_WARNING


class FitBeforeSplitRule(BaseRule):
    """LEAK001: fit() called with no train_test_split detected in file scope."""

    def __init__(self, lines, constants=None, method_assignments=None, is_backtest=True):
        super().__init__(lines, constants, method_assignments, is_backtest)
        self._fit_calls: List[tuple] = []
        self._split_seen = False

    def visit_Call(self, node: ast.Call):
        func = node.func
        name = None
        if isinstance(func, ast.Attribute):
            name = func.attr
        elif isinstance(func, ast.Name):
            name = func.id

        if name == "fit":
            self._fit_calls.append((node.lineno, node.col_offset))
        if name == "train_test_split":
            self._split_seen = True

        self.generic_visit(node)

    def finalize(self):
        if not self._split_seen:
            for lineno, col in self._fit_calls:
                self.add_violation(
                    code="LEAK001",
                    message="fit() called with no train_test_split detected — possible full-dataset leakage",
                    suggestion=(
                        "Split your data chronologically before fitting any scaler or model. "
                        "See docs/rules/LEAK001.md for the correct pattern."
                    ),
                    lineno=lineno,
                    col=col,
                )


class FitTransformFullDataRule(BaseRule):
    """LEAK002: fit_transform() detected — high risk of fitting on test-set data."""

    def visit_Call(self, node: ast.Call):
        if (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "fit_transform"
        ):
            self.add_violation(
                code="LEAK002",
                message="fit_transform() detected — ensure this is called only on training data",
                suggestion=(
                    "Replace fit_transform(X) with fit(X_train).transform(X_train), "
                    "then transform(X_test) separately. fit_transform on the full dataset "
                    "leaks test-set statistics."
                ),
                lineno=node.lineno,
                col=node.col_offset,
                severity=SEVERITY_WARNING,
            )
        self.generic_visit(node)


LEAK_RULES = [FitBeforeSplitRule, FitTransformFullDataRule]