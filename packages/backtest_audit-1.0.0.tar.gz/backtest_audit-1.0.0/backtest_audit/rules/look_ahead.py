import ast
from typing import Any, Dict, List
from .base import BaseRule


def _resolve_arg(arg: ast.expr, constants: Dict[str, Any]):
    """
    Resolve a shift/pct_change argument to a numeric value.
    Returns None if the value cannot be statically determined.

    Handles:
      shift(5)          →  5       (positive literal, safe)
      shift(-5)         → -5       (negative literal, flag)
      shift(n)          →  constants['n'] if present
      shift(-n)         → -constants['n'] if present
      shift(-(-1)) = 1  →  safe, not flagged
    """
    # Direct literal
    if isinstance(arg, ast.Constant) and isinstance(arg.value, (int, float)):
        return arg.value

    # UnaryOp: either shift(-5) or shift(-n)
    if isinstance(arg, ast.UnaryOp) and isinstance(arg.op, ast.USub):
        operand = arg.operand
        if isinstance(operand, ast.Constant) and isinstance(operand.value, (int, float)):
            return -operand.value
        if isinstance(operand, ast.Name):
            val = constants.get(operand.id)
            if val is not None:
                return -val

    # Name: shift(window) — look up variable
    if isinstance(arg, ast.Name):
        return constants.get(arg.id)

    return None


class NegativeShiftRule(BaseRule):
    """LAB001: shift() called with a negative argument — future data pulled into signal."""

    def visit_Call(self, node: ast.Call):
        if (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "shift"
            and node.args
        ):
            value = _resolve_arg(node.args[0], self.constants)
            if value is not None and value < 0:
                self.add_violation(
                    code="LAB001",
                    message="Negative shift — future data pulled into current timestep",
                    suggestion=(
                        "Replace shift(-n) with shift(n). Negative periods reference "
                        "future rows, invalidating the backtest."
                    ),
                    lineno=node.lineno,
                    col=node.col_offset,
                )
        self.generic_visit(node)


class NegativePctChangeRule(BaseRule):
    """LAB002: pct_change() called with a negative argument — forward return leak."""

    def visit_Call(self, node: ast.Call):
        if (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "pct_change"
            and node.args
        ):
            value = _resolve_arg(node.args[0], self.constants)
            if value is not None and value < 0:
                self.add_violation(
                    code="LAB002",
                    message="Negative pct_change period — return calculated relative to a future price",
                    suggestion=(
                        "Use pct_change(n) with a positive integer. "
                        "Negative periods look forward in time."
                    ),
                    lineno=node.lineno,
                    col=node.col_offset,
                )
        self.generic_visit(node)


LAB_RULES = [NegativeShiftRule, NegativePctChangeRule]