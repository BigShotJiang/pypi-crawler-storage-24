import ast
from typing import Any, Dict, List
from .base import BaseRule, SEVERITY_ERROR, SEVERITY_WARNING

_ANNUALIZATION_VALUES = {252, 365, 52, 12}

_COST_KEYWORDS = (
    "commission", "slippage", "transaction_cost",
    "trade_cost", "spread", "fee", "brokerage",
)


def _has_annualization(node: ast.expr) -> bool:
    """Check if an expression tree contains an annualization factor."""
    for child in ast.walk(node):
        if isinstance(child, ast.Constant) and child.value in _ANNUALIZATION_VALUES:
            return True
        if isinstance(child, ast.Attribute) and child.attr == "sqrt":
            return True
        if isinstance(child, ast.Name) and "sqrt" in child.id.lower():
            return True
    return False


def _is_method_call(node: ast.expr, method: str) -> bool:
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == method
    )


def _contains_mean_over_std(node: ast.expr, method_assignments: Dict[str, str]) -> bool:
    """
    Detect mean()/std() division pattern anywhere in an expression.
    Handles both direct calls and aliased variables.

    Direct:   returns.mean() / returns.std()
    Aliased:  mu / sigma  where mu ← .mean(), sigma ← .std()
    """
    for child in ast.walk(node):
        if not (isinstance(child, ast.BinOp) and isinstance(child.op, ast.Div)):
            continue

        left, right = child.left, child.right

        # Direct method calls
        if _is_method_call(left, "mean") and _is_method_call(right, "std"):
            return True

        # Aliased variables
        left_name = left.id if isinstance(left, ast.Name) else None
        right_name = right.id if isinstance(right, ast.Name) else None
        if (
            left_name
            and right_name
            and method_assignments.get(left_name) == "mean"
            and method_assignments.get(right_name) == "std"
        ):
            return True

    return False


class SharpeAnnualizationRule(BaseRule):
    """
    STAT001: Sharpe ratio (or equivalent mean/std ratio) without annualization.

    Detects two patterns:
    1. Variable named 'sharpe*' assigned without annualization factor.
    2. Any mean()/std() division (direct or aliased) without annualization factor.

    Pattern 2 fires as a WARNING since it may not always be a Sharpe ratio.
    Pattern 1 fires as an ERROR since the intent is unambiguous.
    """

    def visit_Assign(self, node: ast.Assign):
        for target in node.targets:
            if not isinstance(target, ast.Name):
                continue

            already_flagged = False

            # Pattern 1 — variable explicitly named "sharpe"
            if "sharpe" in target.id.lower():
                if not _has_annualization(node.value):
                    self.add_violation(
                        code="STAT001",
                        message="Sharpe ratio assigned without annualization factor",
                        suggestion=(
                            "Multiply by sqrt(252) for daily returns, sqrt(52) for weekly, "
                            "sqrt(12) for monthly. Raw Sharpe is not comparable across strategies."
                        ),
                        lineno=node.lineno,
                        col=node.col_offset,
                        severity=SEVERITY_ERROR,
                    )
                    already_flagged = True

            # Pattern 2 — structural mean()/std() detection
            if not already_flagged and _contains_mean_over_std(
                node.value, self.method_assignments
            ):
                if not _has_annualization(node.value):
                    self.add_violation(
                        code="STAT001",
                        message="mean()/std() ratio assigned without annualization — possible Sharpe-like metric",
                        suggestion=(
                            "If this is a performance metric, multiply by sqrt(252) for daily "
                            "returns. Use a name like 'sharpe_annualized' to make intent explicit."
                        ),
                        lineno=node.lineno,
                        col=node.col_offset,
                        severity=SEVERITY_WARNING,
                    )

        self.generic_visit(node)


class NoTransactionCostRule(BaseRule):
    """
    STAT002: No transaction cost or slippage variable detected.
    Only fires on files classified as backtest code.
    """

    def __init__(self, lines, constants=None, method_assignments=None, is_backtest=True):
        super().__init__(lines, constants, method_assignments, is_backtest)
        self._found_cost = False

    def visit_Assign(self, node: ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name):
                if any(kw in target.id.lower() for kw in _COST_KEYWORDS):
                    self._found_cost = True
        self.generic_visit(node)

    def finalize(self):
        if not self.is_backtest:
            return
        if not self._found_cost:
            self.add_violation(
                code="STAT002",
                message="No transaction cost or slippage variable detected",
                suggestion=(
                    "Add commission and slippage estimates. "
                    "Ignoring transaction costs systematically overstates backtest returns."
                ),
                lineno=1,
                col=0,
                severity=SEVERITY_WARNING,
            )


STAT_RULES = [SharpeAnnualizationRule, NoTransactionCostRule]