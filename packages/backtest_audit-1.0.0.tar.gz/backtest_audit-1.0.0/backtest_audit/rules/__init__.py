from .look_ahead import LAB_RULES
from .leakage import LEAK_RULES
from .statistical import STAT_RULES

ALL_RULES = LAB_RULES + LEAK_RULES + STAT_RULES

RULE_REGISTRY = [
    ("LAB001", "Look-Ahead Bias",         "shift(-n) pulls future prices into current signal"),
    ("LAB002", "Look-Ahead Bias",         "pct_change(-n) computes forward returns"),
    ("LEAK001", "Data Leakage",           "fit() called with no train_test_split detected"),
    ("LEAK002", "Data Leakage",           "fit_transform() may be called on unsplit data"),
    ("STAT001", "Statistical Malpractice","Sharpe ratio assigned without annualization factor"),
    ("STAT002", "Statistical Malpractice","No transaction cost or slippage variable detected"),
]