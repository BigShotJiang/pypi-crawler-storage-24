import ast
from dataclasses import dataclass
from typing import Any, Dict, List

SEVERITY_ERROR = "error"
SEVERITY_WARNING = "warning"


@dataclass
class Violation:
    code: str
    message: str
    suggestion: str
    line: int
    col: int
    source_line: str
    severity: str = SEVERITY_ERROR

    @property
    def category(self) -> str:
        return self.code[:3]


class BaseRule(ast.NodeVisitor):
    """Base class for all backtest-audit rules."""

    def __init__(
        self,
        lines: List[str],
        constants: Dict[str, Any] = None,
        method_assignments: Dict[str, str] = None,
        is_backtest: bool = True,
    ):
        self.lines = lines
        self.constants = constants or {}
        self.method_assignments = method_assignments or {}
        self.is_backtest = is_backtest
        self.violations: List[Violation] = []

    def get_source_line(self, lineno: int) -> str:
        if 1 <= lineno <= len(self.lines):
            return self.lines[lineno - 1].strip()
        return ""

    def add_violation(
        self,
        code: str,
        message: str,
        suggestion: str,
        lineno: int,
        col: int,
        severity: str = SEVERITY_ERROR,
    ):
        self.violations.append(
            Violation(
                code=code,
                message=message,
                suggestion=suggestion,
                line=lineno,
                col=col,
                source_line=self.get_source_line(lineno),
                severity=severity,
            )
        )