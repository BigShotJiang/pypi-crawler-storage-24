from .a3s_code import *

__doc__ = a3s_code.__doc__
if hasattr(a3s_code, "__all__"):
    __all__ = a3s_code.__all__