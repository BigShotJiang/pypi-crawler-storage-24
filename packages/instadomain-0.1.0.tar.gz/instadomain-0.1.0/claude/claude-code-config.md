# Adding Domain Checker to Claude Code

Claude Code supports MCP servers via the `claude mcp add` command. Choose the
transport that fits your setup.

---

## Option A: Local (stdio)

Runs `mcp_server.py` directly on your machine. No network dependency.

```bash
# Replace /path/to/domain-checker with the actual directory
claude mcp add domain-checker \
  --transport stdio \
  -- python3 mcp_server.py \
  --cwd /path/to/domain-checker
```

Verify the server registered:

```bash
claude mcp list
```

---

## Option B: Remote (streamable-HTTP)

Connects to the hosted server at https://domaincheckr.fly.dev/mcp/. Requires no
local clone.

```bash
claude mcp add domain-checker \
  --transport http \
  --url https://domaincheckr.fly.dev/mcp/
```

---

## Available tools after adding

| Tool | What it does |
|---|---|
| `check_domain` | Check a single domain for availability |
| `check_domains_bulk` | Check up to 50 domains in one call |
| `suggest_domains` | Generate and check 10–15 domain ideas from a keyword |

---

## Removing the server

```bash
claude mcp remove domain-checker
```
