# Connecting Domain Checker to claude.ai via Connectors

Claude.ai (web) supports remote MCP servers through the Connectors feature.
This lets you use Domain Checker tools directly in claude.ai conversations
without any local installation.

---

## Prerequisites

- A Claude.ai account with Connectors access (available on Pro, Team, and
  Enterprise plans)
- The remote MCP server must be running at https://domaincheckr.fly.dev/mcp/

---

## Setup steps

1. Go to **claude.ai** and sign in.
2. Click your profile avatar (top-right) and open **Settings**.
3. Navigate to **Integrations** > **Connectors** (or **Add Custom Connector**,
   depending on your plan).
4. Click **Add Custom Connector** (or the **+** button).
5. In the **Server URL** field, enter:
   ```
   https://domaincheckr.fly.dev/mcp/
   ```
6. Give the connector a name, e.g. `Domain Checker`.
7. Click **Save** / **Connect**.

Claude will handshake with the server and list the available tools.

---

## Tools that will appear

After connecting, Claude gains three new tools:

| Tool | Description |
|---|---|
| `check_domain` | Check whether a single domain name is available. Returns availability status, registrar if taken, and affiliate registration links if available. |
| `check_domains_bulk` | Check up to 50 domains in one call. Returns per-domain details and a summary of available vs. taken. |
| `suggest_domains` | Provide a keyword; Domain Checker generates 10–15 name ideas using common prefix/suffix patterns and checks each one. Returns available domains with registration links. |

---

## Example prompts to try

- "Is `taskflow.io` available?"
- "Check these domains for me: acme.com, acmehq.com, getacme.com"
- "Suggest domain names for a project called Lunar"

---

## Troubleshooting

- **Connector shows an error**: Confirm the URL ends with a trailing slash
  (`/mcp/`) and that the server is reachable.
- **Tools not showing up**: Try removing and re-adding the connector.
- **Rate limits**: Bulk checks are capped at 50 domains per call.
