#!/usr/bin/env python3
"""
stats.py - CLI analytics summary for domain checker.
Usage: python3 stats.py [--days 30]
"""
from __future__ import annotations

import argparse
import asyncio
import os
import sys
from datetime import datetime, timezone, timedelta
from typing import Any

import aiosqlite

# Default DB path (mirrors config.py default; override via DB_PATH env var)
DB_PATH = os.environ.get("DB_PATH", "./data/analytics.db")

CONV_RATE = 0.10
AVG_COMMISSION = 5.00


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

async def query_stats(days: int) -> dict[str, Any]:
    if not os.path.exists(DB_PATH):
        return _empty_stats(days)

    now = datetime.now(timezone.utc)

    def since(d: int) -> str:
        return (now - timedelta(days=d)).isoformat()

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        async def scalar(sql: str, params: tuple = ()) -> int:
            async with db.execute(sql, params) as cur:
                row = await cur.fetchone()
                return int(row[0] or 0) if row else 0

        async def fetchall(sql: str, params: tuple = ()):
            async with db.execute(sql, params) as cur:
                return await cur.fetchall()

        # --- domain_checks ---
        total_today    = await scalar("SELECT COUNT(*) FROM domain_checks WHERE ts >= ?", (since(1),))
        total_week     = await scalar("SELECT COUNT(*) FROM domain_checks WHERE ts >= ?", (since(7),))
        total_month    = await scalar("SELECT COUNT(*) FROM domain_checks WHERE ts >= ?", (since(30),))
        total_alltime  = await scalar("SELECT COUNT(*) FROM domain_checks")

        avail_period   = await scalar(
            "SELECT SUM(available) FROM domain_checks WHERE ts >= ?", (since(days),))
        total_period   = await scalar(
            "SELECT COUNT(*) FROM domain_checks WHERE ts >= ?", (since(days),))
        taken_period   = total_period - avail_period

        # source breakdown
        source_rows = await fetchall(
            "SELECT source, COUNT(*) as n FROM domain_checks WHERE ts >= ? GROUP BY source ORDER BY n DESC",
            (since(days),))

        # --- links_served ---
        links_total = await scalar("SELECT COUNT(*) FROM links_served WHERE ts >= ?", (since(days),))

        # --- clicks ---
        clicks_total = await scalar("SELECT COUNT(*) FROM clicks WHERE ts >= ?", (since(days),))
        click_rows = await fetchall(
            "SELECT registrar, COUNT(*) as n FROM clicks WHERE ts >= ? GROUP BY registrar ORDER BY n DESC",
            (since(days),))

        # --- top domains ---
        top_rows = await fetchall(
            "SELECT domain, COUNT(*) as n FROM domain_checks WHERE ts >= ? GROUP BY domain ORDER BY n DESC LIMIT 10",
            (since(days),))

    est_revenue = clicks_total * CONV_RATE * AVG_COMMISSION

    return {
        "days": days,
        "checks_today": total_today,
        "checks_week": total_week,
        "checks_month": total_month,
        "checks_alltime": total_alltime,
        "checks_period": total_period,
        "available_period": avail_period,
        "taken_period": taken_period,
        "sources": [{"source": r["source"], "count": r["n"]} for r in source_rows],
        "links_served": links_total,
        "clicks_total": clicks_total,
        "clicks_by_registrar": [{"registrar": r["registrar"], "clicks": r["n"]} for r in click_rows],
        "est_revenue": est_revenue,
        "top_domains": [{"domain": r["domain"], "checks": r["n"]} for r in top_rows],
    }


def _empty_stats(days: int) -> dict[str, Any]:
    return {
        "days": days, "checks_today": 0, "checks_week": 0,
        "checks_month": 0, "checks_alltime": 0, "checks_period": 0,
        "available_period": 0, "taken_period": 0, "sources": [],
        "links_served": 0, "clicks_total": 0, "clicks_by_registrar": [],
        "est_revenue": 0.0, "top_domains": [],
    }


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _hr(char: str = "-", width: int = 56) -> str:
    return char * width


def _row(label: str, value: Any, width: int = 56) -> str:
    label_w = 36
    return f"  {label:<{label_w}}{str(value):>16}"


def _header(title: str, width: int = 56) -> str:
    return f"\n{_hr('=', width)}\n  {title}\n{_hr('=', width)}"


def _section(title: str, width: int = 56) -> str:
    return f"\n{_hr('-', width)}\n  {title}\n{_hr('-', width)}"


def _table(headers: list[str], rows: list[list[str]], col_widths: list[int]) -> str:
    def fmt_row(cells: list[str]) -> str:
        return "  " + "  ".join(f"{c:<{w}}" for c, w in zip(cells, col_widths))

    sep = "  " + "  ".join("-" * w for w in col_widths)
    lines = [fmt_row(headers), sep]
    for r in rows:
        lines.append(fmt_row(r))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Print
# ---------------------------------------------------------------------------

def print_stats(s: dict[str, Any]) -> None:
    days = s["days"]

    print(_header(f"Domain Checker Analytics  (last {days} days)"))

    # Domain checks
    print(_section("Domain Checks"))
    print(_row("Today", f"{s['checks_today']:,}"))
    print(_row("This week", f"{s['checks_week']:,}"))
    print(_row("This month", f"{s['checks_month']:,}"))
    print(_row("All time", f"{s['checks_alltime']:,}"))

    # Available / taken
    print(_section(f"Availability  (last {days} days)"))
    total = s["checks_period"]
    avail = s["available_period"]
    taken = s["taken_period"]
    avail_pct = f"{avail / total * 100:.1f}%" if total else "n/a"
    taken_pct = f"{taken / total * 100:.1f}%" if total else "n/a"
    print(_row("Available", f"{avail:,}  ({avail_pct})"))
    print(_row("Taken", f"{taken:,}  ({taken_pct})"))
    print(_row("Total checked", f"{total:,}"))

    # Source breakdown
    if s["sources"]:
        print(_section("Source Breakdown"))
        for src in s["sources"]:
            print(_row(src["source"], f"{src['count']:,}"))

    # Affiliate
    print(_section("Affiliate Links & Clicks"))
    print(_row("Links served", f"{s['links_served']:,}"))
    print(_row("Total clicks", f"{s['clicks_total']:,}"))
    ctr = (s["clicks_total"] / s["links_served"] * 100) if s["links_served"] else 0
    print(_row("Click-through rate", f"{ctr:.1f}%"))
    print(_row("Est. revenue (10% conv, $5 avg)", f"${s['est_revenue']:.2f}"))

    if s["clicks_by_registrar"]:
        print()
        headers = ["Registrar", "Clicks"]
        rows = [[r["registrar"], str(r["clicks"])] for r in s["clicks_by_registrar"]]
        print(_table(headers, rows, [24, 10]))

    # Top domains
    if s["top_domains"]:
        print(_section("Top 10 Domains Checked"))
        headers = ["Domain", "Checks"]
        rows = [[d["domain"], str(d["checks"])] for d in s["top_domains"]]
        print(_table(headers, rows, [36, 8]))

    print(f"\n{_hr()}\n")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

async def main() -> None:
    parser = argparse.ArgumentParser(description="Domain checker analytics summary")
    parser.add_argument("--days", type=int, default=30, help="Lookback window in days (default: 30)")
    args = parser.parse_args()

    stats = await query_stats(args.days)
    print_stats(stats)


if __name__ == "__main__":
    asyncio.run(main())
