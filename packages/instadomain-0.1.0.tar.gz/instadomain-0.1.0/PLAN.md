# DomainCheck: Project Plan

## What This Is

A domain availability checker monetized through registrar affiliate links. Distributed through zero-friction channels where users never install anything: Claude Desktop Extensions directory and ChatGPT GPT Store.

When a user asks their AI assistant "is coolstartup.com available?", our tool checks via RDAP, returns the answer, and includes affiliate registration links. User clicks, buys the domain, we earn $3-$10. The user never visits our site or knows we exist.

---

## Why This Wins

Existing domain checker MCP servers (there are 6-7 on GitHub) all require manual installation: editing JSON config files, installing Python or Node.js, restarting Claude Desktop. That means their total addressable market is developers who know what MCP is. Maybe 50,000 people.

We skip all of that by targeting two distribution channels with zero installation friction:

**Claude Desktop Extensions directory.** Anthropic is actively building this. One-click install from inside Claude Desktop, like a browser extension. Anthropic reviews submissions. This is the equivalent of getting into the Chrome Web Store early. They are accepting submissions now via an interest form.

**ChatGPT GPT Store.** 200M+ monthly active users. User searches "domain checker", finds our Custom GPT, starts chatting. No installation. No config. No API keys.

Neither channel has a dominant domain availability tool with affiliate monetization today.

---

## Revenue Model

### How We Get Paid

Every major registrar runs an affiliate program. When our tool returns "this domain is available", it includes a registration link with our affiliate tracking code. User clicks, registers the domain, we get paid.

| Registrar | Commission | Cookie | How to Apply |
|-----------|-----------|--------|-------------|
| Namecheap | Up to $5 per .com registration | 30 days | namecheap.com/affiliates |
| GoDaddy | $5-$10 per registration | 45 days | Via CJ Affiliate (cj.com) |
| Porkbun | $2-$3 per registration | 30 days | porkbun.com/affiliates |
| Dynadot | $5 per new account + $0.50 per domain | 45 days | dynadot.com/affiliates |
| Spaceship | $1-$3 per registration | 30 days | spaceship.com/affiliates |

Primary partner: Namecheap (best balance of commission rate and conversion rate for developer audience). Secondary: Porkbun (growing fast, developer-friendly brand). Include both links in every response so users have a choice.

### Revenue Projections

| Monthly Checks | Available (30%) | Click Link (5%) | Convert (10%) | Commission ($5 avg) | Monthly Revenue |
|---------------|----------------|-----------------|---------------|---------------------|----------------|
| 1,000 | 300 | 15 | 1.5 | $5 | $7.50 |
| 10,000 | 3,000 | 150 | 15 | $5 | $75 |
| 100,000 | 30,000 | 1,500 | 150 | $5 | $750 |
| 1,000,000 | 300,000 | 15,000 | 1,500 | $5 | $7,500 |

The 5% click rate is conservative. Domain checking is a high-intent action. Someone who asks "is mycoolbrand.com available?" and learns it is available has strong purchase intent. The real click rate could be 15-25%, which would 3-5x these numbers.

At scale (1M checks/month, achievable if we become the default domain tool across Claude + ChatGPT), this is $7,500-$25,000/month with zero ongoing cost.

### Costs

| Item | Monthly Cost |
|------|-------------|
| VPS (existing) | $0 (already have one) |
| RDAP queries | $0 (free, no API key) |
| Domain for the API | ~$1 |
| Total | ~$1/month |

---

## Distribution Strategy

### Channel 1: Claude Desktop Extension

**What it is.** Anthropic's new extension system lets users install MCP tools with one click inside Claude Desktop. No config files. No terminal. Anthropic maintains a directory and reviews submissions.

**Steps:**

1. Build the MCP server using FastMCP (Python) with streamable HTTP transport
2. Package as a .mcpb desktop extension file following Anthropic's format
3. Submit to Anthropic's desktop extensions directory via their interest form
4. If accepted into the directory, Claude Desktop users can find and install it from Settings > Extensions

**What the user sees.** They browse the extensions directory, see "Domain Checker - instantly check if any domain is available", click Install. From that point on, whenever they ask Claude about domain availability, Claude automatically uses our tool. The response includes affiliate links formatted as helpful "Register here" suggestions.

**Backup plan if directory acceptance takes time.** Publish as a remote MCP server with a clean URL (e.g., https://domains.ourtool.com/mcp). Users on Pro/Max/Team/Enterprise plans can add it via Settings > Connectors > Add Custom Connector. Lower friction than local install but higher friction than the directory.

### Channel 2: ChatGPT GPT Store

**What it is.** OpenAI's marketplace for Custom GPTs. Users search, find, and use GPTs with zero setup. GPTs can have "Actions" that call external APIs.

**Steps:**

1. Build a FastAPI REST endpoint (same core lookup logic as the MCP server)
2. Deploy on VPS behind nginx with HTTPS
3. Create the Custom GPT on chatgpt.com/gpts/editor with our API as an Action
4. Configure the GPT's system prompt to use our tool for any domain-related query
5. Publish to GPT Store as public

**GPT Configuration:**

Name: Domain Checker
Description: Check if any domain name is available for registration. Instant results. Suggests creative alternatives if your first choice is taken.

System prompt (for the GPT):
```
You help users find and register domain names. When a user asks about domain availability, use the check_domain or check_domains action.

For available domains, always include the registration links from the response. Present them naturally, like: "It's available! You can register it here: [link]"

If a domain is taken, mention when it expires if that info is available. Then suggest 5-10 creative alternatives and check those too.

If the user describes a business idea or niche instead of a specific domain, generate 10-15 domain name ideas, check all of them, and present the available ones with registration links.

Never mention the API, the backend, or affiliate programs. Just present results naturally.
```

**Actions schema:** Import from our API's /openapi.json endpoint.

### Channel 3: Claude.ai Web (Bonus)

Remote MCP servers work on claude.ai for Pro/Max/Team/Enterprise users. Users add via Settings > Connectors. This is a middle-friction channel but captures the claude.ai web audience who don't use Claude Desktop.

### Channel 4: Cursor / Windsurf / Other MCP Clients (Bonus)

Developers using AI code editors frequently check domain availability for side projects. Publish config snippets for Cursor and Windsurf MCP integration. These users are comfortable with JSON config and are high-intent domain buyers.

---

## Technical Architecture

### Shared Core (domain_lookup.py)

One module that does the actual RDAP lookup. Used by both the MCP server and the API server.

- Async httpx client
- Queries Verisign RDAP for .com/.net, PIR for .org, rdap.org fallback for others
- 404 = available, 200 = taken
- Parses: registrar, created date, expiry date, nameservers
- Returns structured DomainResult pydantic model

### Affiliate Module (affiliate.py)

- Stores affiliate IDs and URL templates per registrar
- Generates registration links with tracking codes for available domains
- Rotates primary registrar or always leads with highest-commission partner
- Adds register_urls field to every "available" response

### MCP Server (mcp_server.py)

FastMCP Python server with three tools:

1. **check_domain** - Single domain lookup. Returns availability + affiliate links if available, registration details if taken.

2. **check_domains_bulk** - Up to 50 domains at once. Returns summary with counts, per-domain details, affiliate links for all available ones.

3. **suggest_domains** - Takes a keyword or business description, generates 10-15 domain name ideas (using simple prefix/suffix/combination logic, no LLM call needed), checks all of them, returns results. This is the conversion driver because it gives the AI a reason to call our tool even when the user hasn't asked for a specific domain name.

Transports:
- stdio for local Claude Desktop extension
- Streamable HTTP for remote server (claude.ai connectors, Cursor, etc.)

### API Server (api_server.py)

FastAPI with auto-generated OpenAPI spec for ChatGPT Actions.

Endpoints:
- GET /check/{domain} - Single domain
- POST /check - Bulk (JSON body with domains array)
- GET /suggest?keyword={keyword} - Generate + check domain ideas
- GET /health - Health check
- GET /openapi.json - Auto-served by FastAPI for ChatGPT Action import

All responses include affiliate links for available domains.

### Analytics (analytics.py)

Lightweight event logging to a local SQLite database.

Events to track:
- domain_checked: which domain, available or taken, timestamp, source (mcp or api)
- link_served: which affiliate link was included in the response
- (Click tracking requires a redirect, covered below)

### Click Tracking

To track affiliate link clicks (and therefore estimate conversion), route links through our own redirect:

https://domains.ourtool.com/go/{registrar}/{domain}

This endpoint logs the click, then 302 redirects to the actual registrar affiliate URL. This gives us click data without requiring anything from the registrar's reporting.

### Deployment

All on the existing VPS:

```
docker-compose.yml
  - api (FastAPI on port 8080)
  - mcp (FastMCP HTTP on port 8000)
  - nginx (reverse proxy, HTTPS via certbot)
```

Single domain needed: register something like domaincheckr.com or checkdomain.tools for the API endpoint.

---

## File Structure

```
domain-checker/
  domain_lookup.py         Core RDAP logic
  affiliate.py             Affiliate link generation
  analytics.py             Event logging (SQLite)
  mcp_server.py            MCP server (Claude)
  api_server.py            FastAPI server (ChatGPT)
  config.py                Affiliate IDs, feature flags
  requirements.txt         Python dependencies
  Dockerfile               Container build
  docker-compose.yml       Multi-service deployment
  nginx.conf               Reverse proxy + HTTPS
  manifest.json            Claude Desktop Extension manifest
  README.md                Setup docs
  tests/
    test_lookup.py
    test_affiliate.py
    test_api.py
    test_mcp.py
```

---

## Implementation Phases

### Phase 1: Core + Deploy (Day 1)

Build and deploy the working product.

- [ ] domain_lookup.py - RDAP checker with async httpx
- [ ] affiliate.py - Namecheap + Porkbun link generation (apply for affiliate programs same day)
- [ ] config.py - Affiliate IDs, registrar configs
- [ ] mcp_server.py - Three tools (check, bulk, suggest)
- [ ] api_server.py - Three endpoints matching the tools
- [ ] analytics.py - SQLite event logging
- [ ] Click redirect endpoint (/go/{registrar}/{domain})
- [ ] Dockerfile + docker-compose.yml + nginx.conf
- [ ] Deploy to VPS
- [ ] Register a domain for the API endpoint
- [ ] Test MCP locally via Claude Desktop stdio config
- [ ] Test API via curl and browser

### Phase 2: ChatGPT Distribution (Day 2)

Get into the GPT Store.

- [ ] Create Custom GPT on chatgpt.com/gpts/editor
- [ ] Import OpenAPI spec as Action
- [ ] Write system prompt (see above)
- [ ] Test end-to-end: ask GPT to check domains, verify affiliate links appear
- [ ] Publish to GPT Store (public)
- [ ] Write a clear title and description optimized for GPT Store search

### Phase 3: Claude Distribution (Day 2-3)

Get into Claude's ecosystem.

- [ ] Package as .mcpb desktop extension
- [ ] Submit to Anthropic's desktop extensions directory (interest form)
- [ ] Set up remote MCP server endpoint for claude.ai Connectors
- [ ] Test via Claude Desktop (both local and remote)
- [ ] Publish config snippets for Cursor, Windsurf, Claude Code

### Phase 4: Affiliate Program Activation (Week 1)

- [ ] Apply to Namecheap affiliate program
- [ ] Apply to Porkbun affiliate program
- [ ] Apply to GoDaddy via CJ Affiliate
- [ ] Apply to Dynadot affiliate program
- [ ] Once approved, update config.py with real affiliate IDs
- [ ] Verify tracking links work end-to-end (click > redirect > registrar > cookie set)

### Phase 5: Monitor + Optimize (Ongoing, automated)

- [ ] Build a daily analytics summary agent that checks SQLite, reports checks/clicks/estimated revenue
- [ ] Monitor GPT Store ranking for "domain checker" related queries
- [ ] Monitor Claude Desktop extension install count (if Anthropic provides this)
- [ ] A/B test affiliate link presentation (inline vs. end of response, one registrar vs. multiple)
- [ ] Add more TLD support as needed (.io, .ai, .dev, .co)

---

## Risks and Mitigations

**Risk: Anthropic rejects the extension because it contains affiliate links.**
Mitigation: Frame it as "helpful registration links" not advertising. If rejected, fall back to remote MCP server distribution via Connectors. Also ensure the tool is genuinely useful without the links.

**Risk: ChatGPT changes GPT Store policies around monetized Actions.**
Mitigation: Diversify across both Claude and ChatGPT. If one blocks affiliate links, the other likely still works.

**Risk: Low click-through on affiliate links because AI assistants don't present links prominently.**
Mitigation: Optimize the response format. Test whether "Register at Namecheap" vs "Register here: [link]" vs inline markdown links get higher click-through. The suggest_domains tool is key because it creates multiple available options, increasing the chance the user wants to register at least one.

**Risk: Registrar affiliate programs reject the application or change terms.**
Mitigation: Apply to 4-5 programs. Only need one to work. Namecheap and GoDaddy have the most established programs with the lowest rejection rates.

**Risk: RDAP rate limiting at very high volume.**
Mitigation: Add a simple cache layer (Redis or in-memory TTL cache). Domain availability doesn't change by the second. A 5-minute cache for "taken" results and 1-minute for "available" results would cut RDAP queries by 80%+ at scale.

---

## Success Metrics

| Timeframe | Metric | Target |
|-----------|--------|--------|
| Week 1 | Deployed and functional on both channels | Yes/no |
| Month 1 | Daily domain checks | 100+ |
| Month 3 | Daily domain checks | 1,000+ |
| Month 3 | Monthly affiliate revenue | $50+ |
| Month 6 | Daily domain checks | 10,000+ |
| Month 6 | Monthly affiliate revenue | $500+ |
| Month 12 | Daily domain checks | 100,000+ |
| Month 12 | Monthly affiliate revenue | $5,000+ |

The inflection point is getting into Claude's extension directory or reaching page 1 of GPT Store results for "domain" queries. Either one could 10-50x daily volume overnight.

---

## Agent Task Assignments

This plan is structured so each phase can be handed to a coding agent with clear inputs and outputs.

**Agent 1: Core Backend**
Input: This plan, specifically the Technical Architecture section.
Output: domain_lookup.py, affiliate.py, analytics.py, config.py, requirements.txt, tests/
Acceptance: All tests pass. Can check dinkhub.com and get a correct available/taken response with affiliate links.

**Agent 2: MCP Server**
Input: Agent 1's output + mcp_server.py spec from this plan.
Output: mcp_server.py, manifest.json for desktop extension packaging
Acceptance: Can run locally via stdio, Claude Desktop recognizes all 3 tools, responses include affiliate links.

**Agent 3: API Server + ChatGPT GPT**
Input: Agent 1's output + api_server.py spec from this plan.
Output: api_server.py, Dockerfile, docker-compose.yml, nginx.conf, ChatGPT GPT configuration (system prompt + action schema)
Acceptance: API responds correctly on all endpoints. OpenAPI spec importable as ChatGPT Action.

**Agent 4: Deploy**
Input: All of the above.
Output: Running on VPS, HTTPS working, MCP server accessible remotely, API accessible remotely.
Acceptance: curl https://domains.ourtool.com/check/dinkhub.com returns correct JSON with affiliate links.

**Agent 5: Distribution**
Input: Deployed product.
Tasks: Submit to Claude Desktop extension directory. Publish ChatGPT GPT to GPT Store. Create Cursor/Windsurf config snippets. Apply to all affiliate programs.
Output: Live on both distribution channels. Affiliate applications submitted.
