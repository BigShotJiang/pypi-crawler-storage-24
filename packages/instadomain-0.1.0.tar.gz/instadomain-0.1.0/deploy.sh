#!/usr/bin/env bash
set -e

# Usage: ./deploy.sh <VPS_IP> [SSH_USER]
VPS_IP="$1"
SSH_USER="${2:-root}"
REMOTE_DIR="/opt/domain-checker"
DOMAIN="domaincheckr.com"

if [ -z "$VPS_IP" ]; then
    echo "Error: VPS IP is required."
    echo "Usage: $0 <VPS_IP> [SSH_USER]"
    exit 1
fi

echo "Deploying to $SSH_USER@$VPS_IP ..."

# Sync project files to VPS
echo "Syncing files..."
rsync -az --delete \
    --exclude='.git' \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    --exclude='data/' \
    --exclude='.env' \
    --exclude='tests/' \
    --exclude='PLAN.md' \
    --exclude='*.md' \
    ./ "$SSH_USER@$VPS_IP:$REMOTE_DIR/"

# Build and start containers
echo "Building and starting containers..."
ssh "$SSH_USER@$VPS_IP" "
    set -e
    cd $REMOTE_DIR
    docker-compose build
    docker-compose up -d
    echo 'Containers running.'
"

# Set up SSL if certs don't exist yet
echo "Checking SSL certificates..."
CERT_CHECK=$(ssh "$SSH_USER@$VPS_IP" "
    if [ -d /etc/letsencrypt/live/$DOMAIN ]; then
        echo 'exists'
    else
        echo 'missing'
    fi
")

if [ "$CERT_CHECK" = "missing" ]; then
    echo "SSL certs not found. Running certbot..."
    ssh "$SSH_USER@$VPS_IP" "
        set -e
        cd $REMOTE_DIR
        # Stop nginx to free port 80 for certbot standalone
        docker-compose stop nginx || true
        docker run --rm \
            -p 80:80 \
            -v /etc/letsencrypt:/etc/letsencrypt \
            -v /var/lib/letsencrypt:/var/lib/letsencrypt \
            certbot/certbot certonly \
            --standalone \
            --non-interactive \
            --agree-tos \
            --email admin@$DOMAIN \
            -d $DOMAIN \
            -d www.$DOMAIN
        # Restart with SSL
        docker-compose up -d
        echo 'SSL setup complete.'
    "
else
    echo "SSL certs already exist, skipping certbot."
fi

# Print status
echo ""
echo "Deploy complete. Container status:"
ssh "$SSH_USER@$VPS_IP" "cd $REMOTE_DIR && docker-compose ps"
