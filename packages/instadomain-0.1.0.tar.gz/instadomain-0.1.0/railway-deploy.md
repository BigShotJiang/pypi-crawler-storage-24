# Railway Deployment Guide

Two services from this single repo: one for the API, one for the MCP server.
Railway handles HTTPS automatically — no certbot, no nginx needed.

---

## Prerequisites

```bash
npm i -g @railway/cli
# or
brew install railway
```

---

## Step 1 — Login and create project

```bash
railway login
railway init
# When prompted for project name, enter: domain-checker
```

---

## Step 2 — Deploy the API service

From the repo root:

```bash
railway up
```

Railway reads `railway.json` and deploys `api_server.py` via uvicorn on the dynamic `$PORT`.

After deploy, Railway prints a URL like:
```
https://domain-checker-production.up.railway.app
```

Set affiliate env vars:

```bash
railway variables set NAMECHEAP_AFFILIATE_ID=your_id_here
railway variables set PORKBUN_AFFILIATE_ID=your_id_here
```

Verify it's live:

```bash
curl https://domain-checker-production.up.railway.app/health
# {"status": "ok"}

curl https://domain-checker-production.up.railway.app/check/dinkhub.com
# JSON with available + affiliate links
```

---

## Step 3 — Add a custom domain (optional)

```bash
railway domain
# Prompts you to enter a domain, then shows the CNAME to set in your registrar DNS
```

Point your registrar's CNAME record at the Railway-provided hostname.
Railway auto-provisions a TLS certificate via Let's Encrypt — nothing else needed.

---

## Step 4 — Deploy the MCP service

The MCP server needs its own Railway service (separate URL, separate process).

1. Open the Railway dashboard: https://railway.app/dashboard
2. Select the `domain-checker` project
3. Click **+ New Service** → **GitHub Repo** → select the same repo
4. In the service settings, override the start command:
   ```
   python3 mcp_server.py --http
   ```
5. Set the same env vars on this service:
   ```bash
   # In service settings → Variables, or via CLI after switching services:
   railway variables set NAMECHEAP_AFFILIATE_ID=your_id_here
   railway variables set PORKBUN_AFFILIATE_ID=your_id_here
   ```
6. Railway assigns a second URL, e.g.:
   ```
   https://domain-checker-mcp-production.up.railway.app
   ```

Verify the MCP endpoint:

```bash
curl https://domain-checker-mcp-production.up.railway.app/mcp/
```

---

## Step 5 — Update config files with your Railway URLs

Once you have both URLs, update these files with the actual hostnames:

- `gpt/openapi.yaml` — replace `domaincheckr.com` with your API service URL
- `claude/claude-desktop-remote.json` — replace MCP URL with your MCP service URL
- `claude/cursor-config.json` — same MCP URL update
- `claude/windsurf-config.json` — same MCP URL update

If you added a custom domain, use that instead of the `.up.railway.app` URLs.

---

## Pricing

Railway Hobby plan: **$5/month** includes $5 in usage credit.

For this project's expected traffic (domain RDAP checks, no heavy compute):
- Each service uses ~0.5 vCPU and ~256 MB RAM when idle
- Two services: estimate **$5–10/month total** at low traffic
- Scales automatically if traffic spikes; you only pay for what you use

Usage calculator: https://railway.app/pricing

---

## Environment variables reference

| Variable | Description |
|---|---|
| `PORT` | Set automatically by Railway — do not override |
| `NAMECHEAP_AFFILIATE_ID` | Your Namecheap affiliate ID |
| `PORKBUN_AFFILIATE_ID` | Your Porkbun affiliate ID |
| `DB_PATH` | SQLite path (default: `analytics.db` in workdir) |

---

## Updating a deployment

```bash
# Push to GitHub (Railway auto-deploys on push if GitHub integration enabled)
git push

# Or trigger manually:
railway up
```

---

## VPS deployment still available

The original VPS files (`deploy.sh`, `setup-ssl.sh`, `docker-compose.yml`, `nginx.conf`) are preserved in the repo. If you prefer self-hosting, follow those instead.
