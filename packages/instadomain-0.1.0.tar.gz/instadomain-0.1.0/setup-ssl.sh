#!/usr/bin/env bash
set -e

# Run this script ON the VPS to set up SSL certificates.
# Usage: ./setup-ssl.sh [DOMAIN]
DOMAIN="${1:-domaincheckr.com}"
COMPOSE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Setting up SSL for domain: $DOMAIN"
echo "Working directory: $COMPOSE_DIR"

# Confirm certbot image is available (pull if needed)
docker pull certbot/certbot

# Stop nginx to free port 80
echo "Stopping nginx container..."
cd "$COMPOSE_DIR"
docker-compose stop nginx || true

# Request certificates using certbot standalone mode
echo "Requesting certificates from Let's Encrypt..."
docker run --rm \
    -p 80:80 \
    -v /etc/letsencrypt:/etc/letsencrypt \
    -v /var/lib/letsencrypt:/var/lib/letsencrypt \
    certbot/certbot certonly \
    --standalone \
    --non-interactive \
    --agree-tos \
    --email "admin@$DOMAIN" \
    -d "$DOMAIN" \
    -d "www.$DOMAIN"

echo "Certificates obtained. Restarting services..."
docker-compose up -d

echo ""
echo "SSL setup complete for $DOMAIN."
echo "Certificate location: /etc/letsencrypt/live/$DOMAIN/"
echo ""
echo "Container status:"
docker-compose ps
