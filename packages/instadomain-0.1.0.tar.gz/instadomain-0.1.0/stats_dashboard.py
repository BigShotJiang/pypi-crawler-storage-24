#!/usr/bin/env python3
"""
stats_dashboard.py - Analytics web dashboard for domain checker.
Runs on port 8085. Auto-refreshes every 60s.
"""
from __future__ import annotations

import asyncio
import os
from datetime import datetime, timezone, timedelta
from typing import Any

import aiosqlite
import uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse

DB_PATH = os.environ.get("DB_PATH", "./data/analytics.db")
CONV_RATE = 0.10
AVG_COMMISSION = 5.00

app = FastAPI(title="Domain Checker Stats")


# ---------------------------------------------------------------------------
# DB query
# ---------------------------------------------------------------------------

async def query_stats(days: int = 30) -> dict[str, Any]:
    if not os.path.exists(DB_PATH):
        return _empty(days)

    now = datetime.now(timezone.utc)

    def since(d: int) -> str:
        return (now - timedelta(days=d)).isoformat()

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        async def scalar(sql: str, params: tuple = ()) -> int:
            async with db.execute(sql, params) as cur:
                row = await cur.fetchone()
                return int(row[0] or 0) if row else 0

        async def fetchall(sql: str, params: tuple = ()):
            async with db.execute(sql, params) as cur:
                return await cur.fetchall()

        total_today   = await scalar("SELECT COUNT(*) FROM domain_checks WHERE ts >= ?", (since(1),))
        total_week    = await scalar("SELECT COUNT(*) FROM domain_checks WHERE ts >= ?", (since(7),))
        total_month   = await scalar("SELECT COUNT(*) FROM domain_checks WHERE ts >= ?", (since(30),))
        total_alltime = await scalar("SELECT COUNT(*) FROM domain_checks")
        total_period  = await scalar("SELECT COUNT(*) FROM domain_checks WHERE ts >= ?", (since(days),))
        avail_period  = await scalar("SELECT SUM(available) FROM domain_checks WHERE ts >= ?", (since(days),))
        taken_period  = total_period - avail_period
        source_rows   = await fetchall(
            "SELECT source, COUNT(*) n FROM domain_checks WHERE ts >= ? GROUP BY source ORDER BY n DESC",
            (since(days),))
        links_total   = await scalar("SELECT COUNT(*) FROM links_served WHERE ts >= ?", (since(days),))
        clicks_total  = await scalar("SELECT COUNT(*) FROM clicks WHERE ts >= ?", (since(days),))
        click_rows    = await fetchall(
            "SELECT registrar, COUNT(*) n FROM clicks WHERE ts >= ? GROUP BY registrar ORDER BY n DESC",
            (since(days),))
        top_rows      = await fetchall(
            "SELECT domain, COUNT(*) n FROM domain_checks WHERE ts >= ? GROUP BY domain ORDER BY n DESC LIMIT 10",
            (since(days),))

    ctr = round(clicks_total / links_total * 100, 1) if links_total else 0.0
    return {
        "days": days,
        "checks_today": total_today, "checks_week": total_week,
        "checks_month": total_month, "checks_alltime": total_alltime,
        "checks_period": total_period,
        "available_period": avail_period, "taken_period": taken_period,
        "sources": [{"source": r["source"], "count": r["n"]} for r in source_rows],
        "links_served": links_total,
        "clicks_total": clicks_total,
        "click_through_rate": ctr,
        "est_revenue": round(clicks_total * CONV_RATE * AVG_COMMISSION, 2),
        "clicks_by_registrar": [{"registrar": r["registrar"], "clicks": r["n"]} for r in click_rows],
        "top_domains": [{"domain": r["domain"], "checks": r["n"]} for r in top_rows],
    }


def _empty(days: int) -> dict[str, Any]:
    return {
        "days": days, "checks_today": 0, "checks_week": 0, "checks_month": 0,
        "checks_alltime": 0, "checks_period": 0, "available_period": 0, "taken_period": 0,
        "sources": [], "links_served": 0, "clicks_total": 0, "click_through_rate": 0.0,
        "est_revenue": 0.0, "clicks_by_registrar": [], "top_domains": [],
    }


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

@app.get("/api/stats")
async def api_stats(days: int = 30):
    return JSONResponse(await query_stats(days))


# ---------------------------------------------------------------------------
# HTML page (all data rendered server-side to avoid innerHTML XSS concerns)
# ---------------------------------------------------------------------------

def _build_html(s: dict[str, Any]) -> str:
    days = s["days"]
    total = s["checks_period"]
    avail = s["available_period"]
    taken = s["taken_period"]

    def pct(a, b):
        return f"{a/b*100:.1f}%" if b else "n/a"

    def card(label, val, sub="", cls=""):
        return (
            f'<div class="card">'
            f'<div class="label">{label}</div>'
            f'<div class="val {cls}">{val}</div>'
            + (f'<div class="sub2">{sub}</div>' if sub else "")
            + "</div>"
        )

    def table_html(headers, rows):
        ths = "".join(f"<th>{h}</th>" for h in headers)
        trs = "".join(
            "<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>"
            for r in rows
        )
        return f"<table><thead><tr>{ths}</tr></thead><tbody>{trs}</tbody></table>"

    cards = "".join([
        card("Today", f"{s['checks_today']:,}", "checks", "blue"),
        card("This Week", f"{s['checks_week']:,}", "checks", "blue"),
        card("This Month", f"{s['checks_month']:,}", "checks", "blue"),
        card("All Time", f"{s['checks_alltime']:,}", "checks"),
        card("Available", f"{avail:,}", pct(avail, total) + " of period", "green"),
        card("Taken", f"{taken:,}", pct(taken, total) + " of period"),
        card("Links Served", f"{s['links_served']:,}", f"last {days} days"),
        card("Clicks", f"{s['clicks_total']:,}", f"{s['click_through_rate']}% CTR", "yellow"),
        card("Est. Revenue", f"${s['est_revenue']:.2f}", "10% conv &middot; $5 avg", "green"),
    ])

    sections = ""

    if s["sources"]:
        rows = [[f'<span class="badge badge-blue">{r["source"]}</span>', f'{r["count"]:,}']
                for r in s["sources"]]
        sections += f'<section><h2>Source Breakdown</h2>{table_html(["Source","Checks"], rows)}</section>'

    if s["clicks_by_registrar"]:
        rows = [[r["registrar"], f'{r["clicks"]:,}'] for r in s["clicks_by_registrar"]]
        sections += f'<section><h2>Clicks by Registrar</h2>{table_html(["Registrar","Clicks"], rows)}</section>'

    if s["top_domains"]:
        rows = [[str(i+1), d["domain"], f'{d["checks"]:,}'] for i, d in enumerate(s["top_domains"])]
        sections += (f'<section><h2>Top 10 Domains Checked (last {days} days)</h2>'
                     f'{table_html(["#","Domain","Checks"], rows)}</section>')

    css = """
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d1117;color:#c9d1d9;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",monospace;font-size:14px;padding:24px}
h1{color:#e6edf3;font-size:20px;margin-bottom:4px}
.sub{color:#8b949e;font-size:12px;margin-bottom:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-bottom:24px}
.card{background:#161b22;border:1px solid #21262d;border-radius:8px;padding:14px}
.card .label{color:#8b949e;font-size:11px;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px}
.card .val{color:#e6edf3;font-size:22px;font-weight:600}
.card .sub2{color:#8b949e;font-size:11px;margin-top:2px}
.green{color:#3fb950}.yellow{color:#d29922}.blue{color:#58a6ff}
section{background:#161b22;border:1px solid #21262d;border-radius:8px;padding:16px;margin-bottom:16px}
section h2{color:#e6edf3;font-size:13px;font-weight:600;margin-bottom:12px;text-transform:uppercase;letter-spacing:.05em}
table{width:100%;border-collapse:collapse}
th{color:#8b949e;font-size:11px;text-transform:uppercase;letter-spacing:.05em;padding:6px 8px;text-align:left;border-bottom:1px solid #21262d}
td{padding:7px 8px;border-bottom:1px solid #21262d;color:#c9d1d9}
tr:last-child td{border-bottom:none}
tr:hover td{background:#1c2128}
.badge{display:inline-block;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:500}
.badge-blue{background:#1a2a3a;color:#58a6ff}
"""

    js = f"""
let countdown = 60;
setInterval(() => {{
  countdown--;
  const el = document.getElementById('cd');
  if(el) el.textContent = 'Refresh in ' + countdown + 's';
  if(countdown <= 0) location.reload();
}}, 1000);
"""

    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Domain Checker Stats</title>
<style>{css}</style>
</head>
<body>
<h1>Domain Checker Analytics</h1>
<div class="sub">Last updated {now_str} &mdash; <span id="cd">Refresh in 60s</span></div>
<div class="grid">{cards}</div>
{sections}
<script>{js}</script>
</body>
</html>"""


@app.get("/", response_class=HTMLResponse)
async def index(days: int = 30):
    s = await query_stats(days)
    return HTMLResponse(_build_html(s))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    uvicorn.run("stats_dashboard:app", host="0.0.0.0", port=8085, reload=False)
