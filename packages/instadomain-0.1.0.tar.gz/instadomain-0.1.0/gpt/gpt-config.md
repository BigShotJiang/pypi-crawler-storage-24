# Domain Checker GPT — Setup Guide

## GPT Identity

**Name:** Domain Checker

**Description (GPT Store listing):**
Check if any domain name is available for registration. Instant results with registration links. Suggests creative alternatives if your first choice is taken.

**Conversation starters:**
1. Is coolstartup.com available?
2. Find me a domain for a pet grooming business
3. Check these domains: mybrand.com, mybrand.io, mybrand.co
4. I'm launching a SaaS invoicing tool — what domains are available?

---

## Creating the GPT

### Step 1 — Open the GPT editor

1. Go to https://chatgpt.com/gpts/editor
2. Click **Create a GPT**
3. Switch to the **Configure** tab (not the guided builder)

### Step 2 — Fill in the basics

- **Name:** Domain Checker
- **Description:** Paste the description above
- **Instructions:** Paste the full contents of `system-prompt.txt`
- **Conversation starters:** Add all four starters above
- **Profile picture:** Upload a logo or generate one (suggested prompt: "minimalist domain globe icon, blue and white, clean")

### Step 3 — Add the Action (API connection)

1. Scroll down to the **Actions** section and click **Create new action**
2. In the **Schema** field, paste the full contents of `openapi.yaml`
3. ChatGPT will parse it and show three actions: `checkDomain`, `checkDomainsBulk`, `suggestDomains`
4. Under **Authentication**, select **None** (the API is public)
5. Click **Test** on any action to verify connectivity — you should get a real domain result back
6. Click **Save** to close the action editor

### Step 4 — Capabilities

Enable or disable as needed:
- Web browsing: **off** (not needed; the GPT uses its own domain data)
- Code interpreter: **off**
- Image generation: **off**

### Step 5 — Privacy policy

- **Privacy policy URL:** https://domaincheckr.com/privacy
  *(Replace with your actual privacy policy URL before publishing)*

---

## Publishing to the GPT Store

1. In the GPT editor, click **Save** (top right)
2. Under **Publish**, select **Everyone** (makes it publicly discoverable)
3. Choose a category: **Productivity** or **Research & Analysis**
4. Click **Confirm** to submit for review

GPT Store listings are reviewed by OpenAI before going live. Typical review time is 1-3 business days.

### Store listing tips

- The description field is the first thing users see in search — keep it action-oriented
- Conversation starters surface directly on the GPT page and drive first-use clicks
- After publishing, share your GPT link (https://chatgpt.com/g/g-XXXXXXXX) to drive traffic

---

## Testing checklist before publishing

- [ ] `checkDomain` returns availability + register_urls for an available domain
- [ ] `checkDomainsBulk` handles 3+ domains and returns correct counts
- [ ] `suggestDomains` returns 15 results for a keyword like "petcare"
- [ ] Taken domains show expiry date when available
- [ ] Registration links appear naturally in responses (not as raw JSON)
- [ ] GPT does not mention "API", "backend", or "affiliate" in any response
