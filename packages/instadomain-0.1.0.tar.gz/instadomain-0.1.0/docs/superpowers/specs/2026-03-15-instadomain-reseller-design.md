# InstaDomain -- Domain Reseller MCP Server

**Date:** 2026-03-15
**Status:** Approved
**Project root:** ~/domain-checker (extending existing domaincheckr codebase)

## Problem

Developers using Claude Code need domains constantly -- for new projects, landing pages, APIs. Currently they have to context-switch to a browser, search a registrar, create an account, enter payment info, and come back. This breaks flow and wastes 5-10 minutes per domain.

## Solution

An MCP server + backend that lets Claude Code users check availability and purchase domains without leaving the terminal. After purchase, the domain is configured on Cloudflare and a scoped API token is returned so Claude Code can set up DNS directly.

## Target User

Claude Code power users -- developers already in the terminal, building projects, who need domains fast. Technical audience, high purchase intent, low tolerance for friction.

## Business Model

- **Reseller model** via OpenSRS (Tucows)
- Wholesale .com: ~$8.90/yr
- Retail price: $10.99/yr
- Stripe fees: ~$0.62 (2.9% + $0.30)
- **Net margin: ~$1.47/domain**
- Payment via Stripe Checkout (browser link, 30 seconds)

Margins shown in the TLD table below are pre-Stripe-fees. Actual net margin is ~$0.60 lower per domain after payment processing.

## Architecture

### Components

```
┌─────────────┐     ┌──────────────────┐     ┌──────────┐
│  MCP Server │────▶│  Backend API     │────▶│ OpenSRS  │
│  (user CLI) │     │  (Fly.io)        │────▶│ Stripe   │
│             │◀────│                  │────▶│Cloudflare│
└─────────────┘     └──────────────────┘     └──────────┘
```

1. **MCP Server** -- installed locally by the user via `uvx instadomain`. Exposes 3 tools. Thin HTTP client that talks to the backend API over HTTPS. No domain logic locally -- all processing happens server-side. This is a different architecture from the existing domaincheckr MCP server (which runs RDAP in-process). Falls back gracefully with clear error messages when the backend is unreachable.

2. **Backend API** -- FastAPI on Fly.io (new app `instadomain`, separate from `domaincheckr`). Uses **Postgres** (Fly.io managed or Neon) for order data -- SQLite is too risky for financial records. Handles:
   - Domain availability checks (RDAP, reused from domaincheckr)
   - OpenSRS price lookup (actual wholesale price, not hardcoded)
   - Stripe checkout session creation
   - Stripe webhook processing (idempotent, with compensating transactions)
   - OpenSRS domain registration
   - Cloudflare zone creation + scoped API token generation
   - Order tracking

3. **External services:**
   - **OpenSRS** -- domain registration (XML API)
   - **Stripe** -- payment processing (checkout sessions + webhooks)
   - **Cloudflare** -- DNS hosting on our account (free tier, zone creation, API token scoping)

### DNS Hosting Model

We are both a domain reseller and a DNS host. All domains are registered via our OpenSRS reseller account and their DNS zones live on our Cloudflare account. We create per-zone scoped API tokens (DNS-edit-only) and hand them to the customer so Claude Code can manage DNS directly.

**Implications we accept:**
- If our Cloudflare account goes down, all customer DNS goes down
- We are responsible for DNS infrastructure upkeep
- Customers cannot transfer zones to their own Cloudflare account without our help
- At scale, we may need a Cloudflare paid plan (free tier zone limits)

This tradeoff is worth it for the zero-setup UX. The alternative (customer adds domain to their own Cloudflare) adds friction and defeats the value prop.

### MCP Tools

Three tools total:

| Tool | Input | Output |
|------|-------|--------|
| `check_domain` | `domain: str` | `{available: bool, domain: str, price_cents: int, price: str}` |
| `buy_domain` | `domain: str` | `{checkout_url: str, order_id: str}` |
| `get_domain_status` | `order_id: str` | `{status: str, domain: str, cloudflare_token?: str}` |

Note: the existing domaincheckr MCP server also has a `check_domain` tool. InstaDomain is a separate PyPI package with its own MCP server -- no naming conflict. The existing domaincheckr tool may be deprecated or kept as the free tier.

### User Flow

```
User: "buy getdogsondemand.com"

1. MCP → backend GET /check/getdogsondemand.com
   → RDAP lookup → available
   → OpenSRS price lookup → wholesale $8.90 → retail $10.99/yr

2. MCP → backend POST /buy
   {domain: "getdogsondemand.com"}
   → backend creates Stripe checkout session (24h expiry)
   ← {checkout_url: "https://checkout.stripe.com/xxx", order_id: "ord_abc123"}

3. User sees: "$10.99/yr. Pay here: https://checkout.stripe.com/xxx"
   User clicks, pays in browser (30 seconds)

4. Stripe webhook POST /webhooks/stripe → backend:
   a. Verifies webhook signature
   b. Checks idempotency (skip if order already past pending_payment)
   c. Registers domain via OpenSRS API (with WHOIS privacy)
   d. On OpenSRS failure → auto-refund via Stripe, mark order failed
   e. Sets nameservers to Cloudflare
   f. Creates Cloudflare zone for the domain
   g. Generates scoped Cloudflare API token (zone-specific, DNS edit only)
   h. Stores token (encrypted), marks order complete

5. MCP polls GET /status/ord_abc123 (every 3s, timeout 120s)
   ← {status: "complete", domain: "getdogsondemand.com", cloudflare_token: "cf_xxx"}

6. User sees: "getdogsondemand.com is yours. Cloudflare token: cf_xxx"

7. User: "point it at 143.55.23.1"
   Claude Code calls Cloudflare API directly with the token. Done.
```

### Order State Machine

```
pending_payment → registering → setting_dns → complete
       │               │               │
       ▼               ▼               ▼
    expired          failed          failed
                   (auto-refund)
```

- `pending_payment` -- Stripe session created, waiting for payment. Checkout sessions expire after 24 hours.
- `expired` -- Stripe session expired without payment. Cleanup cron archives these daily.
- `registering` -- payment received, OpenSRS registration in progress
- `setting_dns` -- domain registered, configuring Cloudflare zone + token
- `complete` -- everything done, Cloudflare token available
- `failed` -- any step after payment failed. If payment was collected, auto-refund is issued via `stripe_payment_intent`. Error message stored.

**Compensating transactions:**
- OpenSRS registration fails after payment → automatic Stripe refund
- Cloudflare zone creation fails after registration → order marked `failed` with error, can be retried (domain is registered, just needs DNS setup)
- Stripe webhook received twice → idempotent via `stripe_session_id` check (skip if order status is past `pending_payment`)

### Registrant Contact Data

OpenSRS requires WHOIS contact info for every registration. We use **WHOIS privacy** (OpenSRS provides this) with our business entity as the proxy registrant. The actual customer email comes from Stripe checkout.

For v1, all domains are registered with:
- Registrant: InstaDomain LLC (or our business entity)
- WHOIS privacy: enabled (hides registrant details publicly)
- Contact email: customer's email from Stripe (for ICANN-required correspondence)

This is standard practice for domain resellers. The customer is the beneficial owner; we are the registrant of record with privacy enabled.

### Data Model

**orders table (Postgres):**

| Column | Type | Notes |
|--------|------|-------|
| id | TEXT PK | UUID, prefixed `ord_` |
| email | TEXT | From Stripe checkout |
| domain | TEXT NOT NULL | e.g. `getdogsondemand.com` |
| tld | TEXT NOT NULL | e.g. `com` |
| registration_years | INTEGER DEFAULT 1 | Years registered |
| amount_cents | INTEGER | Retail price charged |
| wholesale_cents | INTEGER | Actual OpenSRS cost |
| currency | TEXT DEFAULT 'usd' | |
| stripe_session_id | TEXT UNIQUE | Idempotency key for webhooks |
| stripe_payment_intent | TEXT | For refunds |
| opensrs_order_id | TEXT | OpenSRS confirmation |
| cloudflare_zone_id | TEXT | CF zone for this domain |
| cloudflare_api_token | TEXT | Encrypted (Fernet) |
| cloudflare_token_retrieved | BOOLEAN DEFAULT false | True after first fetch |
| nameservers | TEXT | JSON array of assigned nameservers |
| status | TEXT NOT NULL | See state machine |
| error_msg | TEXT | If failed |
| retry_count | INTEGER DEFAULT 0 | Retry attempts for failed operations |
| domain_expires_at | TEXT | Domain expiration date from OpenSRS |
| created_at | TIMESTAMPTZ | |
| completed_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

### API Endpoints

**Backend (FastAPI on Fly.io):**

| Method | Path | Purpose | Rate Limit |
|--------|------|---------|------------|
| GET | `/check/{domain}` | Availability + price check | 30/min per IP |
| POST | `/buy` | Create Stripe checkout + order | 5/min per IP |
| GET | `/status/{order_id}` | Order status + CF token | 60/min per IP |
| POST | `/webhooks/stripe` | Stripe payment webhook | No limit (Stripe IPs) |
| GET | `/health` | Health check | No limit |

**Rate limiting** via `slowapi` or similar. Prevents abuse of `/check` as a free availability API and prevents `/buy` spam creating junk Stripe sessions.

**Token retrieval security:** `GET /status/{order_id}` returns the Cloudflare token only when `cloudflare_token_retrieved` is false. After first retrieval, the token is marked as retrieved and subsequent calls return `{token: "already_retrieved"}`. Order IDs are UUIDs (unguessable). If a user loses the token, they contact support.

### Security

- Stripe webhook signature verification (STRIPE_WEBHOOK_SECRET)
- Cloudflare API tokens scoped to single zone, DNS-edit-only permission
- Cloudflare tokens encrypted at rest in DB (Fernet symmetric encryption)
- ENCRYPTION_KEY must be backed up securely -- if lost, all stored tokens are unrecoverable
- ENCRYPTION_KEY must never be committed to version control
- Rate limiting on all public endpoints
- Cloudflare token returned only once per order (see token retrieval security above)
- HTTPS everywhere (Fly.io provides TLS, .dev requires it)

### Configuration

**Environment variables (backend):**

| Var | Purpose |
|-----|---------|
| OPENSRS_API_KEY | OpenSRS reseller API key |
| OPENSRS_RESELLER_USERNAME | OpenSRS reseller username |
| OPENSRS_API_URL | `https://rr-n1-tor.opensrs.net:55443` (prod) |
| STRIPE_SECRET_KEY | Stripe API key |
| STRIPE_WEBHOOK_SECRET | Webhook signature verification |
| CLOUDFLARE_API_TOKEN | Master token for zone + token creation |
| CLOUDFLARE_ACCOUNT_ID | Our Cloudflare account ID |
| ENCRYPTION_KEY | Fernet key for token encryption (back up!) |
| DATABASE_URL | Postgres connection string |

**MCP server config (user-side):**

```json
{
  "mcpServers": {
    "instadomain": {
      "command": "uvx",
      "args": ["instadomain"]
    }
  }
}
```

The MCP server talks to `https://instadomain.dev/api` (hardcoded backend URL). Timeout: 10s for check, 10s for buy, 120s polling for status.

### Pricing

Retail prices are calculated dynamically: `wholesale_price + markup + rounding`. The `/check` endpoint queries OpenSRS for the actual wholesale price (handles premium domains correctly) and applies our markup.

**Standard TLD pricing (non-premium):**

| TLD | Wholesale | Retail | Gross Margin | Net (after Stripe) |
|-----|-----------|--------|--------------|---------------------|
| .com | ~$8.90 | $10.99 | $2.09 | ~$1.47 |
| .dev | ~$12.00 | $14.99 | $2.99 | ~$2.37 |
| .io | ~$30.00 | $34.99 | $4.99 | ~$4.37 |
| .app | ~$12.00 | $14.99 | $2.99 | ~$2.37 |

**Premium domains:** If OpenSRS returns a wholesale price above the standard rate (registry premium), we apply a percentage markup (25%) instead of the flat markup. The user sees the actual price before paying.

### What We Reuse from domaincheckr

- `domain_lookup.py` -- RDAP availability checking (proven, deployed)
- `config.py` -- Pydantic settings pattern
- `Dockerfile` base -- deployment infrastructure

### What's New to Build

| Component | Estimated LOC | Description |
|-----------|---------------|-------------|
| `opensrs_client.py` | ~250 | OpenSRS XML API client (price check, register, set nameservers, MD5 auth) |
| `cloudflare_client.py` | ~100 | Create zone, create scoped API token, delete zone |
| `stripe_handler.py` | ~120 | Checkout session creation, webhook processing, refunds |
| `orders.py` | ~100 | Order model, state machine, DB operations, idempotency |
| `api.py` | ~120 | FastAPI endpoints (/buy, /status, /webhooks, rate limiting) |
| `encryption.py` | ~30 | Fernet encrypt/decrypt for CF tokens |
| `mcp_server.py` | ~60 | 3 MCP tools, thin HTTP client to backend |
| `db.py` | ~60 | Postgres connection, migrations |
| **Total** | **~840** | |

### What's NOT in v1

- User accounts / login
- DNS management tools (Claude Code handles this via Cloudflare API)
- Domain renewals (track `domain_expires_at`, email reminders later)
- Domain transfers
- Bulk purchase
- Non-core TLDs (just .com, .dev, .io, .app)
- Automated refunds UI (handle via Stripe dashboard)
- Custom nameservers (always Cloudflare)
- Order lookup by email/domain (support-only for now)

### Distribution

- **PyPI package** (`pip install instadomain` or `uvx instadomain`)
- **Claude Code MCP config** -- one-line add to settings
- Backend hosted at `instadomain.dev`

### Legal Requirements

- **ICANN Registrant Rights and Responsibilities** -- must be presented/linked during purchase
- **Terms of Service** -- required by OpenSRS for reseller approval. Hosted at `instadomain.dev/terms`
- **Privacy Policy** -- required. Hosted at `instadomain.dev/privacy`
- **WHOIS privacy disclosure** -- we register as proxy registrant with privacy enabled

These pages can be simple static HTML served by the backend.

### Success Criteria

1. User can check domain availability from Claude Code
2. User can purchase a domain without leaving the terminal (except 30s Stripe checkout)
3. Domain is registered and Cloudflare token returned within 120 seconds of payment
4. Claude Code can configure DNS using the returned token
5. End-to-end flow works reliably for .com domains
6. Failed registrations after payment trigger automatic refunds

### Accounts Needed Before Building

1. **OpenSRS reseller account** -- apply at opensrs.com, $100 minimum deposit
2. **Stripe account** -- standard account, no special approval needed
3. **Cloudflare account** -- free tier, API token with zone + token creation permissions
4. **instadomain.dev domain** -- buy for the backend + legal pages
5. **Fly.io app** -- new app `instadomain` with managed Postgres
