# InstaDomain Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a domain reseller MCP server + backend that lets Claude Code users check availability, buy domains via Stripe, and receive a Cloudflare DNS token -- all without leaving the terminal.

**Architecture:** Thin MCP client (PyPI package) talks to a FastAPI backend on Fly.io. Backend orchestrates OpenSRS (registration), Stripe (payments), and Cloudflare (DNS). Postgres for order storage. Extends the existing domaincheckr repo.

**Tech Stack:** Python 3.12, FastAPI, FastMCP, httpx, asyncpg, Stripe SDK, Fernet encryption, Fly.io + Postgres

**Spec:** `docs/superpowers/specs/2026-03-15-instadomain-reseller-design.md`

---

## File Structure

All new files live under `instadomain/` within the `~/domain-checker/` repo. The existing domaincheckr code stays untouched.

```
domain-checker/
├── instadomain/               # New package
│   ├── __init__.py
│   ├── config.py              # Pydantic settings (env vars)
│   ├── db.py                  # Postgres connection + migrations
│   ├── encryption.py          # Fernet encrypt/decrypt
│   ├── orders.py              # Order model, state machine, DB ops
│   ├── pricing.py             # Markup calculation, TLD pricing
│   ├── opensrs_client.py      # OpenSRS XML API (price, register, nameservers)
│   ├── cloudflare_client.py   # Create zone, create scoped token
│   ├── stripe_handler.py      # Checkout sessions, webhooks, refunds
│   ├── fulfillment.py         # Orchestrates register → DNS → complete
│   ├── api.py                 # FastAPI app (/check, /buy, /status, /webhooks)
│   └── mcp_server.py          # 3 MCP tools, thin HTTP client
├── tests/
│   ├── test_instadomain/
│   │   ├── test_encryption.py
│   │   ├── test_orders.py
│   │   ├── test_pricing.py
│   │   ├── test_opensrs_client.py
│   │   ├── test_cloudflare_client.py
│   │   ├── test_stripe_handler.py
│   │   ├── test_fulfillment.py
│   │   ├── test_api.py
│   │   └── conftest.py        # Shared fixtures (test DB, mock clients)
│   └── test_integration.py    # Existing domaincheckr tests (unchanged)
├── pyproject.toml             # New: instadomain package definition
├── fly-instadomain.toml       # Fly.io config for instadomain app
└── ... (existing domaincheckr files unchanged)
```

---

## Chunk 1: Foundation (config, DB, encryption, orders)

### Task 1: Project scaffolding and config

**Files:**
- Create: `instadomain/__init__.py`
- Create: `instadomain/config.py`
- Create: `pyproject.toml`

- [ ] **Step 1: Create package directory and __init__.py**

```python
# instadomain/__init__.py
__version__ = "0.1.0"
```

- [ ] **Step 2: Create config.py with Pydantic settings**

```python
# instadomain/config.py
from __future__ import annotations

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # OpenSRS
    opensrs_api_key: str = ""
    opensrs_reseller_username: str = ""
    opensrs_api_url: str = "https://rr-n1-tor.opensrs.net:55443"

    # Stripe
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""

    # Cloudflare
    cloudflare_api_token: str = ""
    cloudflare_account_id: str = ""

    # Database
    database_url: str = "postgresql://localhost/instadomain"

    # Encryption
    encryption_key: str = ""  # Fernet key, generate with: Fernet.generate_key()

    # Backend
    api_host: str = "0.0.0.0"
    api_port: int = 8080
    backend_url: str = "https://instadomain.dev/api"

    # Pricing
    standard_markup_cents: int = 210  # $2.10 markup on standard TLDs
    premium_markup_pct: float = 0.25  # 25% markup on premium domains

    model_config = {"env_file": ".env", "env_prefix": "INSTADOMAIN_"}


settings = Settings()
```

- [ ] **Step 3: Create pyproject.toml**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "instadomain"
version = "0.1.0"
description = "Buy domains from Claude Code"
requires-python = ">=3.11"
dependencies = [
    "httpx>=0.27",
    "pydantic>=2.0",
    "pydantic-settings>=2.0",
    "fastapi[standard]>=0.100",
    "uvicorn[standard]>=0.30",
    "fastmcp>=0.3",
    "asyncpg>=0.29",
    "stripe>=8.0",
    "cryptography>=42.0",
    "slowapi>=0.1",
]

[project.scripts]
instadomain = "instadomain.mcp_server:main"

[tool.pytest.ini_options]
asyncio_mode = "auto"
```

- [ ] **Step 4: Commit**

```bash
git add instadomain/__init__.py instadomain/config.py pyproject.toml
git commit -m "feat: scaffold instadomain package with config"
```

---

### Task 2: Encryption module

**Files:**
- Create: `instadomain/encryption.py`
- Create: `tests/test_instadomain/conftest.py`
- Create: `tests/test_instadomain/test_encryption.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_instadomain/conftest.py
import pytest
from cryptography.fernet import Fernet


@pytest.fixture
def fernet_key():
    return Fernet.generate_key().decode()
```

```python
# tests/test_instadomain/test_encryption.py
from instadomain.encryption import encrypt, decrypt


def test_encrypt_decrypt_roundtrip(fernet_key):
    plaintext = "cf_scoped_token_abc123"
    ciphertext = encrypt(plaintext, fernet_key)
    assert ciphertext != plaintext
    assert decrypt(ciphertext, fernet_key) == plaintext


def test_decrypt_wrong_key_raises(fernet_key):
    from cryptography.fernet import Fernet
    other_key = Fernet.generate_key().decode()
    ciphertext = encrypt("secret", fernet_key)
    with pytest.raises(Exception):
        decrypt(ciphertext, other_key)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_instadomain/test_encryption.py -v`
Expected: FAIL (module not found)

- [ ] **Step 3: Write implementation**

```python
# instadomain/encryption.py
from __future__ import annotations

from cryptography.fernet import Fernet


def encrypt(plaintext: str, key: str) -> str:
    f = Fernet(key.encode() if isinstance(key, str) else key)
    return f.encrypt(plaintext.encode()).decode()


def decrypt(ciphertext: str, key: str) -> str:
    f = Fernet(key.encode() if isinstance(key, str) else key)
    return f.decrypt(ciphertext.encode()).decode()
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_instadomain/test_encryption.py -v`
Expected: PASS (2 tests)

- [ ] **Step 5: Commit**

```bash
git add instadomain/encryption.py tests/test_instadomain/
git commit -m "feat: add Fernet encryption module for CF token storage"
```

---

### Task 3: Database module (Postgres + migrations)

**Files:**
- Create: `instadomain/db.py`
- Create: `tests/test_instadomain/test_orders.py` (partial -- DB fixture)

- [ ] **Step 1: Write db.py with connection pool and schema migration**

```python
# instadomain/db.py
from __future__ import annotations

import asyncpg

_pool: asyncpg.Pool | None = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    email TEXT,
    domain TEXT NOT NULL,
    tld TEXT NOT NULL,
    registration_years INTEGER NOT NULL DEFAULT 1,
    amount_cents INTEGER NOT NULL,
    wholesale_cents INTEGER,
    currency TEXT NOT NULL DEFAULT 'usd',
    stripe_session_id TEXT UNIQUE,
    stripe_payment_intent TEXT,
    opensrs_order_id TEXT,
    cloudflare_zone_id TEXT,
    cloudflare_api_token TEXT,
    cloudflare_token_retrieved BOOLEAN NOT NULL DEFAULT false,
    nameservers TEXT,
    status TEXT NOT NULL DEFAULT 'pending_payment',
    error_msg TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,
    domain_expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_stripe_session
    ON orders (stripe_session_id);
CREATE INDEX IF NOT EXISTS idx_orders_status
    ON orders (status);
CREATE INDEX IF NOT EXISTS idx_orders_domain
    ON orders (domain);
"""


async def init_pool(database_url: str) -> asyncpg.Pool:
    global _pool
    _pool = await asyncpg.create_pool(database_url, min_size=2, max_size=10)
    async with _pool.acquire() as conn:
        await conn.execute(SCHEMA)
    return _pool


async def get_pool() -> asyncpg.Pool:
    if _pool is None:
        raise RuntimeError("Database pool not initialized. Call init_pool() first.")
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool:
        await _pool.close()
        _pool = None
```

- [ ] **Step 2: Add test DB fixture to conftest.py**

Append to `tests/test_instadomain/conftest.py`:

```python
import asyncio
import asyncpg
from instadomain.db import SCHEMA

@pytest.fixture
async def test_db(tmp_path):
    """Create a test Postgres database. Requires local Postgres running.
    Falls back to SQLite-like in-memory approach if PG unavailable.
    """
    db_name = f"instadomain_test_{os.getpid()}"
    admin_url = "postgresql://localhost/postgres"

    # Create test database
    conn = await asyncpg.connect(admin_url)
    await conn.execute(f"DROP DATABASE IF EXISTS {db_name}")
    await conn.execute(f"CREATE DATABASE {db_name}")
    await conn.close()

    test_url = f"postgresql://localhost/{db_name}"
    pool = await asyncpg.create_pool(test_url, min_size=1, max_size=3)
    async with pool.acquire() as conn:
        await conn.execute(SCHEMA)

    yield pool

    await pool.close()
    # Cleanup
    conn = await asyncpg.connect(admin_url)
    await conn.execute(f"DROP DATABASE IF EXISTS {db_name}")
    await conn.close()
```

- [ ] **Step 3: Commit**

```bash
git add instadomain/db.py tests/test_instadomain/conftest.py
git commit -m "feat: add Postgres DB module with schema and connection pool"
```

---

### Task 4: Orders module (state machine + CRUD)

**Files:**
- Create: `instadomain/orders.py`
- Create: `tests/test_instadomain/test_orders.py`

- [ ] **Step 1: Write failing tests for order lifecycle**

```python
# tests/test_instadomain/test_orders.py
import pytest
from instadomain.orders import create_order, get_order, update_order_status


@pytest.mark.asyncio
async def test_create_order(test_db):
    order = await create_order(
        test_db, domain="example.com", tld="com",
        amount_cents=1099, stripe_session_id="cs_test_123",
    )
    assert order["id"].startswith("ord_")
    assert order["domain"] == "example.com"
    assert order["status"] == "pending_payment"


@pytest.mark.asyncio
async def test_get_order(test_db):
    order = await create_order(
        test_db, domain="example.com", tld="com",
        amount_cents=1099, stripe_session_id="cs_test_456",
    )
    fetched = await get_order(test_db, order["id"])
    assert fetched is not None
    assert fetched["domain"] == "example.com"


@pytest.mark.asyncio
async def test_get_order_not_found(test_db):
    fetched = await get_order(test_db, "ord_nonexistent")
    assert fetched is None


@pytest.mark.asyncio
async def test_update_status_valid_transition(test_db):
    order = await create_order(
        test_db, domain="example.com", tld="com",
        amount_cents=1099, stripe_session_id="cs_test_789",
    )
    updated = await update_order_status(test_db, order["id"], "registering")
    assert updated["status"] == "registering"


@pytest.mark.asyncio
async def test_update_status_invalid_transition(test_db):
    order = await create_order(
        test_db, domain="example.com", tld="com",
        amount_cents=1099, stripe_session_id="cs_test_101",
    )
    with pytest.raises(ValueError, match="Invalid transition"):
        await update_order_status(test_db, order["id"], "complete")


@pytest.mark.asyncio
async def test_idempotent_stripe_session(test_db):
    await create_order(
        test_db, domain="a.com", tld="com",
        amount_cents=1099, stripe_session_id="cs_dup",
    )
    with pytest.raises(Exception):  # unique constraint
        await create_order(
            test_db, domain="b.com", tld="com",
            amount_cents=1099, stripe_session_id="cs_dup",
        )
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_instadomain/test_orders.py -v`
Expected: FAIL (module not found)

- [ ] **Step 3: Write implementation**

```python
# instadomain/orders.py
from __future__ import annotations

import uuid
from typing import Any

import asyncpg

# Valid state transitions
_TRANSITIONS: dict[str, set[str]] = {
    "pending_payment": {"registering", "expired", "failed"},
    "registering": {"setting_dns", "failed"},
    "setting_dns": {"complete", "failed"},
    "complete": set(),
    "expired": set(),
    "failed": set(),
}


def _new_order_id() -> str:
    return f"ord_{uuid.uuid4().hex[:16]}"


async def create_order(
    pool: asyncpg.Pool,
    *,
    domain: str,
    tld: str,
    amount_cents: int,
    stripe_session_id: str,
    wholesale_cents: int | None = None,
) -> dict[str, Any]:
    order_id = _new_order_id()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            INSERT INTO orders (id, domain, tld, amount_cents, wholesale_cents,
                                stripe_session_id, status)
            VALUES ($1, $2, $3, $4, $5, $6, 'pending_payment')
            RETURNING *
            """,
            order_id, domain, tld, amount_cents, wholesale_cents,
            stripe_session_id,
        )
    return dict(row)


async def get_order(
    pool: asyncpg.Pool, order_id: str
) -> dict[str, Any] | None:
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT * FROM orders WHERE id = $1", order_id
        )
    return dict(row) if row else None


async def get_order_by_stripe_session(
    pool: asyncpg.Pool, stripe_session_id: str
) -> dict[str, Any] | None:
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT * FROM orders WHERE stripe_session_id = $1",
            stripe_session_id,
        )
    return dict(row) if row else None


async def update_order_status(
    pool: asyncpg.Pool,
    order_id: str,
    new_status: str,
    **fields: Any,
) -> dict[str, Any]:
    order = await get_order(pool, order_id)
    if order is None:
        raise ValueError(f"Order {order_id} not found")

    current = order["status"]
    if new_status not in _TRANSITIONS.get(current, set()):
        raise ValueError(
            f"Invalid transition: {current} → {new_status}"
        )

    set_parts = ["status = $2", "updated_at = now()"]
    params: list[Any] = [order_id, new_status]
    idx = 3

    if new_status == "complete":
        set_parts.append("completed_at = now()")

    for key, value in fields.items():
        set_parts.append(f"{key} = ${idx}")
        params.append(value)
        idx += 1

    sql = f"UPDATE orders SET {', '.join(set_parts)} WHERE id = $1 RETURNING *"

    async with pool.acquire() as conn:
        row = await conn.fetchrow(sql, *params)
    return dict(row)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/test_instadomain/test_orders.py -v`
Expected: PASS (6 tests)

- [ ] **Step 5: Commit**

```bash
git add instadomain/orders.py tests/test_instadomain/test_orders.py
git commit -m "feat: add orders module with state machine and CRUD"
```

---

### Task 5: Pricing module

**Files:**
- Create: `instadomain/pricing.py`
- Create: `tests/test_instadomain/test_pricing.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/test_instadomain/test_pricing.py
from instadomain.pricing import calculate_retail_cents, format_price


def test_standard_com_markup():
    # Wholesale 890 cents + 210 markup = 1099 ($10.99)
    assert calculate_retail_cents(890, "com") == 1099


def test_standard_dev_markup():
    assert calculate_retail_cents(1200, "dev") == 1499


def test_premium_domain_uses_percentage():
    # Wholesale $50 (5000 cents) is premium, 25% markup = $62.50 → 6250
    assert calculate_retail_cents(5000, "com") == 6250


def test_format_price():
    assert format_price(1099) == "$10.99"
    assert format_price(3499) == "$34.99"
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_instadomain/test_pricing.py -v`

- [ ] **Step 3: Write implementation**

```python
# instadomain/pricing.py
from __future__ import annotations

import math

# Standard wholesale thresholds (cents). Prices above this are "premium".
_STANDARD_WHOLESALE: dict[str, int] = {
    "com": 1000,
    "net": 1000,
    "org": 1000,
    "dev": 1400,
    "app": 1400,
    "io": 3500,
}

# Fixed markup for standard domains (cents)
_STANDARD_MARKUP: dict[str, int] = {
    "com": 209,
    "net": 209,
    "org": 209,
    "dev": 299,
    "app": 299,
    "io": 499,
}

_PREMIUM_MARKUP_PCT = 0.25
_DEFAULT_MARKUP = 299  # cents, for unknown TLDs


def calculate_retail_cents(wholesale_cents: int, tld: str) -> int:
    threshold = _STANDARD_WHOLESALE.get(tld, 2000)
    if wholesale_cents > threshold:
        # Premium domain: percentage markup, round to nearest cent
        return math.ceil(wholesale_cents * (1 + _PREMIUM_MARKUP_PCT))
    markup = _STANDARD_MARKUP.get(tld, _DEFAULT_MARKUP)
    return wholesale_cents + markup


def format_price(cents: int) -> str:
    return f"${cents / 100:.2f}"
```

- [ ] **Step 4: Run tests**

Run: `pytest tests/test_instadomain/test_pricing.py -v`
Expected: PASS (4 tests)

- [ ] **Step 5: Commit**

```bash
git add instadomain/pricing.py tests/test_instadomain/test_pricing.py
git commit -m "feat: add pricing module with standard/premium markup"
```

---

## Chunk 2: External Service Clients (OpenSRS, Cloudflare, Stripe)

### Task 6: OpenSRS client

**Files:**
- Create: `instadomain/opensrs_client.py`
- Create: `tests/test_instadomain/test_opensrs_client.py`

The OpenSRS XML API uses a custom envelope format with MD5 signature auth. We need: price lookup, domain registration, and nameserver update.

- [ ] **Step 1: Write tests with mocked HTTP (external API -- mock is appropriate)**

```python
# tests/test_instadomain/test_opensrs_client.py
import pytest
import httpx
from unittest.mock import AsyncMock, patch
from instadomain.opensrs_client import OpenSRSClient


@pytest.fixture
def client():
    return OpenSRSClient(
        api_key="test_key",
        reseller_username="test_user",
        api_url="https://test.opensrs.net:55443",
    )


@pytest.fixture
def _price_response_xml():
    return """<?xml version='1.0' encoding='UTF-8' standalone='no'?>
    <!DOCTYPE OPS_envelope SYSTEM 'ops.dtd'>
    <OPS_envelope>
      <body>
        <data_block>
          <dt_assoc>
            <item key="is_success">1</item>
            <item key="response_code">200</item>
            <item key="attributes">
              <dt_assoc>
                <item key="price">8.90</item>
              </dt_assoc>
            </item>
          </dt_assoc>
        </data_block>
      </body>
    </OPS_envelope>"""


@pytest.mark.asyncio
async def test_get_price(client, _price_response_xml):
    mock_resp = AsyncMock()
    mock_resp.status_code = 200
    mock_resp.text = _price_response_xml

    with patch.object(client, "_post", return_value=mock_resp):
        price_cents = await client.get_price("example.com")
    assert price_cents == 890


@pytest.fixture
def _register_response_xml():
    return """<?xml version='1.0' encoding='UTF-8' standalone='no'?>
    <!DOCTYPE OPS_envelope SYSTEM 'ops.dtd'>
    <OPS_envelope>
      <body>
        <data_block>
          <dt_assoc>
            <item key="is_success">1</item>
            <item key="response_code">200</item>
            <item key="attributes">
              <dt_assoc>
                <item key="id">12345</item>
                <item key="registration_expiredate">2027-03-15 00:00:00</item>
              </dt_assoc>
            </item>
          </dt_assoc>
        </data_block>
      </body>
    </OPS_envelope>"""


@pytest.mark.asyncio
async def test_register_domain(client, _register_response_xml):
    mock_resp = AsyncMock()
    mock_resp.status_code = 200
    mock_resp.text = _register_response_xml

    with patch.object(client, "_post", return_value=mock_resp):
        result = await client.register(
            domain="example.com",
            years=1,
            registrant_email="user@example.com",
        )
    assert result["order_id"] == "12345"
    assert "expiry" in result


@pytest.mark.asyncio
async def test_register_failure_raises(client):
    fail_xml = """<?xml version='1.0' encoding='UTF-8' standalone='no'?>
    <!DOCTYPE OPS_envelope SYSTEM 'ops.dtd'>
    <OPS_envelope>
      <body>
        <data_block>
          <dt_assoc>
            <item key="is_success">0</item>
            <item key="response_code">485</item>
            <item key="response_text">Domain already registered</item>
          </dt_assoc>
        </data_block>
      </body>
    </OPS_envelope>"""
    mock_resp = AsyncMock()
    mock_resp.status_code = 200
    mock_resp.text = fail_xml

    with patch.object(client, "_post", return_value=mock_resp):
        with pytest.raises(Exception, match="Domain already registered"):
            await client.register(
                domain="example.com", years=1,
                registrant_email="user@example.com",
            )
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_instadomain/test_opensrs_client.py -v`

- [ ] **Step 3: Write OpenSRS client**

```python
# instadomain/opensrs_client.py
from __future__ import annotations

import hashlib
import xml.etree.ElementTree as ET
from typing import Any

import httpx

# Default registrant contact for WHOIS privacy
_DEFAULT_CONTACT = {
    "first_name": "InstaDomain",
    "last_name": "Privacy",
    "org_name": "InstaDomain",
    "address1": "PO Box 0000",
    "city": "San Francisco",
    "state": "CA",
    "postal_code": "94102",
    "country": "US",
    "phone": "+1.0000000000",
    "email": "",  # filled per-order with customer email
}


class OpenSRSError(Exception):
    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message
        super().__init__(f"OpenSRS error {code}: {message}")


class OpenSRSClient:
    def __init__(
        self, *, api_key: str, reseller_username: str, api_url: str
    ) -> None:
        self._api_key = api_key
        self._username = reseller_username
        self._api_url = api_url

    def _sign(self, xml_body: str) -> str:
        """MD5 signature: md5(md5(xml + key) + key)"""
        inner = hashlib.md5(
            (xml_body + self._api_key).encode()
        ).hexdigest()
        return hashlib.md5(
            (inner + self._api_key).encode()
        ).hexdigest()

    def _build_envelope(
        self, action: str, obj: str, attrs: dict[str, Any]
    ) -> str:
        """Build OpenSRS XML envelope."""
        attr_xml = self._dict_to_xml(attrs)
        body = f"""<?xml version='1.0' encoding='UTF-8' standalone='no'?>
<!DOCTYPE OPS_envelope SYSTEM 'ops.dtd'>
<OPS_envelope>
  <header>
    <version>0.9</version>
  </header>
  <body>
    <data_block>
      <dt_assoc>
        <item key="protocol">XCP</item>
        <item key="action">{action}</item>
        <item key="object">{obj}</item>
        <item key="attributes">
          <dt_assoc>
            {attr_xml}
          </dt_assoc>
        </item>
      </dt_assoc>
    </data_block>
  </body>
</OPS_envelope>"""
        return body

    def _dict_to_xml(self, d: dict[str, Any]) -> str:
        parts = []
        for k, v in d.items():
            if isinstance(v, dict):
                inner = self._dict_to_xml(v)
                parts.append(
                    f'<item key="{k}"><dt_assoc>{inner}</dt_assoc></item>'
                )
            elif isinstance(v, list):
                inner = "".join(
                    f'<item key="{i}">{x}</item>' for i, x in enumerate(v)
                )
                parts.append(
                    f'<item key="{k}"><dt_array>{inner}</dt_array></item>'
                )
            else:
                parts.append(f'<item key="{k}">{v}</item>')
        return "\n".join(parts)

    def _parse_response(self, xml_text: str) -> dict[str, Any]:
        """Parse OpenSRS response, raise on failure."""
        root = ET.fromstring(xml_text)
        body = root.find(".//body/data_block/dt_assoc")
        if body is None:
            raise OpenSRSError(0, "Malformed response")

        result = self._parse_assoc(body)
        if str(result.get("is_success")) != "1":
            raise OpenSRSError(
                int(result.get("response_code", 0)),
                str(result.get("response_text", "Unknown error")),
            )
        return result.get("attributes", {})

    def _parse_assoc(self, elem: ET.Element) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for item in elem.findall("item"):
            key = item.get("key", "")
            child_assoc = item.find("dt_assoc")
            child_array = item.find("dt_array")
            if child_assoc is not None:
                result[key] = self._parse_assoc(child_assoc)
            elif child_array is not None:
                result[key] = self._parse_array(child_array)
            else:
                result[key] = item.text or ""
        return result

    def _parse_array(self, elem: ET.Element) -> list[Any]:
        items = []
        for item in elem.findall("item"):
            child_assoc = item.find("dt_assoc")
            if child_assoc is not None:
                items.append(self._parse_assoc(child_assoc))
            else:
                items.append(item.text or "")
        return items

    async def _post(self, xml_body: str) -> httpx.Response:
        signature = self._sign(xml_body)
        headers = {
            "Content-Type": "text/xml",
            "X-Username": self._username,
            "X-Signature": signature,
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            return await client.post(
                self._api_url, content=xml_body, headers=headers
            )

    async def get_price(self, domain: str) -> int:
        """Get wholesale price in cents for a domain."""
        name, tld = domain.rsplit(".", 1)
        xml = self._build_envelope(
            action="GET_PRICE",
            obj="DOMAIN",
            attrs={"domain": domain, "period": "1"},
        )
        resp = await self._post(xml)
        attrs = self._parse_response(resp.text)
        price_usd = float(attrs.get("price", 0))
        return round(price_usd * 100)

    async def register(
        self,
        *,
        domain: str,
        years: int = 1,
        registrant_email: str,
        nameservers: list[str] | None = None,
    ) -> dict[str, str]:
        """Register a domain. Returns {order_id, expiry}."""
        contact = {**_DEFAULT_CONTACT, "email": registrant_email}
        ns = nameservers or []

        attrs: dict[str, Any] = {
            "domain": domain,
            "period": str(years),
            "reg_username": self._username,
            "reg_password": hashlib.md5(domain.encode()).hexdigest()[:16],
            "custom_nameservers": "1" if ns else "0",
            "auto_renew": "0",
            "whois_privacy": "1",
            "contact_set": {
                "owner": contact,
                "admin": contact,
                "billing": contact,
                "tech": contact,
            },
        }
        if ns:
            attrs["nameserver_list"] = {
                str(i): {"name": n, "sortorder": str(i + 1)}
                for i, n in enumerate(ns)
            }

        xml = self._build_envelope(
            action="SW_REGISTER", obj="DOMAIN", attrs=attrs
        )
        resp = await self._post(xml)
        result = self._parse_response(resp.text)
        return {
            "order_id": str(result.get("id", "")),
            "expiry": str(result.get("registration_expiredate", "")),
        }

    async def update_nameservers(
        self, domain: str, nameservers: list[str]
    ) -> None:
        """Update nameservers for a registered domain."""
        ns_attrs = {
            str(i): {"name": n, "sortorder": str(i + 1)}
            for i, n in enumerate(nameservers)
        }
        xml = self._build_envelope(
            action="ADVANCED_UPDATE_NAMESERVERS",
            obj="DOMAIN",
            attrs={
                "domain": domain,
                "op_type": "assign",
                "assign_ns": ns_attrs,
            },
        )
        resp = await self._post(xml)
        self._parse_response(resp.text)
```

- [ ] **Step 4: Run tests**

Run: `pytest tests/test_instadomain/test_opensrs_client.py -v`
Expected: PASS (3 tests)

- [ ] **Step 5: Commit**

```bash
git add instadomain/opensrs_client.py tests/test_instadomain/test_opensrs_client.py
git commit -m "feat: add OpenSRS XML API client (price, register, nameservers)"
```

---

### Task 7: Cloudflare client

**Files:**
- Create: `instadomain/cloudflare_client.py`
- Create: `tests/test_instadomain/test_cloudflare_client.py`

- [ ] **Step 1: Write tests with mocked HTTP**

```python
# tests/test_instadomain/test_cloudflare_client.py
import pytest
from unittest.mock import AsyncMock, patch
from instadomain.cloudflare_client import CloudflareClient


@pytest.fixture
def client():
    return CloudflareClient(
        api_token="cf_test_token",
        account_id="test_account_id",
    )


@pytest.mark.asyncio
async def test_create_zone(client):
    mock_resp = AsyncMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "success": True,
        "result": {
            "id": "zone_123",
            "name_servers": ["ns1.cloudflare.com", "ns2.cloudflare.com"],
        },
    }
    with patch.object(client._http, "post", return_value=mock_resp):
        result = await client.create_zone("example.com")
    assert result["zone_id"] == "zone_123"
    assert len(result["nameservers"]) == 2


@pytest.mark.asyncio
async def test_create_scoped_token(client):
    mock_resp = AsyncMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "success": True,
        "result": {"id": "token_id", "value": "scoped_token_value"},
    }
    with patch.object(client._http, "post", return_value=mock_resp):
        token = await client.create_dns_token("zone_123", "example.com")
    assert token == "scoped_token_value"
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_instadomain/test_cloudflare_client.py -v`

- [ ] **Step 3: Write implementation**

```python
# instadomain/cloudflare_client.py
from __future__ import annotations

import httpx

_CF_API = "https://api.cloudflare.com/client/v4"


class CloudflareError(Exception):
    pass


class CloudflareClient:
    def __init__(self, *, api_token: str, account_id: str) -> None:
        self._account_id = account_id
        self._http = httpx.AsyncClient(
            base_url=_CF_API,
            headers={"Authorization": f"Bearer {api_token}"},
            timeout=30.0,
        )

    async def close(self) -> None:
        await self._http.aclose()

    async def create_zone(self, domain: str) -> dict[str, str | list[str]]:
        """Create a DNS zone. Returns {zone_id, nameservers}."""
        resp = await self._http.post(
            "/zones",
            json={"name": domain, "account": {"id": self._account_id}},
        )
        data = resp.json()
        if not data.get("success"):
            errors = data.get("errors", [])
            msg = errors[0].get("message", "Unknown") if errors else "Unknown"
            raise CloudflareError(f"Zone creation failed: {msg}")

        result = data["result"]
        return {
            "zone_id": result["id"],
            "nameservers": result.get("name_servers", []),
        }

    async def create_dns_token(
        self, zone_id: str, domain: str
    ) -> str:
        """Create a scoped API token for DNS editing on one zone."""
        resp = await self._http.post(
            "/user/tokens",
            json={
                "name": f"instadomain-dns-{domain}",
                "policies": [
                    {
                        "effect": "allow",
                        "resources": {
                            f"com.cloudflare.api.account.zone.{zone_id}": "*"
                        },
                        "permission_groups": [
                            {"id": "4755a26eedb94da69e631f73b0e9f6b6",
                             "name": "Zone DNS Write"},
                            {"id": "82e64a83756745bbbb1c9c2701bf816b",
                             "name": "Zone DNS Read"},
                        ],
                    }
                ],
            },
        )
        data = resp.json()
        if not data.get("success"):
            errors = data.get("errors", [])
            msg = errors[0].get("message", "Unknown") if errors else "Unknown"
            raise CloudflareError(f"Token creation failed: {msg}")

        return data["result"]["value"]

    async def delete_zone(self, zone_id: str) -> None:
        """Delete a DNS zone (for cleanup on failed orders)."""
        resp = await self._http.delete(f"/zones/{zone_id}")
        data = resp.json()
        if not data.get("success"):
            errors = data.get("errors", [])
            msg = errors[0].get("message", "Unknown") if errors else "Unknown"
            raise CloudflareError(f"Zone deletion failed: {msg}")
```

Note: The Cloudflare permission group IDs above are placeholders. The actual IDs need to be looked up from the Cloudflare API at build time (`GET /user/tokens/permission_groups`). Add a TODO comment in the code for this.

- [ ] **Step 4: Run tests**

Run: `pytest tests/test_instadomain/test_cloudflare_client.py -v`
Expected: PASS (2 tests)

- [ ] **Step 5: Commit**

```bash
git add instadomain/cloudflare_client.py tests/test_instadomain/test_cloudflare_client.py
git commit -m "feat: add Cloudflare client (zone creation, scoped DNS tokens)"
```

---

### Task 8: Stripe handler

**Files:**
- Create: `instadomain/stripe_handler.py`
- Create: `tests/test_instadomain/test_stripe_handler.py`

- [ ] **Step 1: Write tests with mocked Stripe SDK**

```python
# tests/test_instadomain/test_stripe_handler.py
import pytest
from unittest.mock import patch, MagicMock
from instadomain.stripe_handler import (
    create_checkout_session, process_webhook_event, issue_refund,
)


@pytest.mark.asyncio
async def test_create_checkout_session():
    mock_session = MagicMock()
    mock_session.id = "cs_test_abc"
    mock_session.url = "https://checkout.stripe.com/abc"
    mock_session.payment_intent = "pi_test_123"

    with patch("stripe.checkout.Session.create", return_value=mock_session):
        result = await create_checkout_session(
            domain="example.com",
            amount_cents=1099,
            order_id="ord_abc",
        )
    assert result["session_id"] == "cs_test_abc"
    assert result["checkout_url"] == "https://checkout.stripe.com/abc"


@pytest.mark.asyncio
async def test_process_completed_checkout():
    event = {
        "type": "checkout.session.completed",
        "data": {
            "object": {
                "id": "cs_test_abc",
                "payment_intent": "pi_test_123",
                "customer_details": {"email": "user@example.com"},
            }
        },
    }
    result = process_webhook_event(event)
    assert result["session_id"] == "cs_test_abc"
    assert result["email"] == "user@example.com"
    assert result["payment_intent"] == "pi_test_123"


@pytest.mark.asyncio
async def test_issue_refund():
    mock_refund = MagicMock()
    mock_refund.id = "re_test_123"
    mock_refund.status = "succeeded"

    with patch("stripe.Refund.create", return_value=mock_refund):
        result = await issue_refund("pi_test_123")
    assert result["refund_id"] == "re_test_123"
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_instadomain/test_stripe_handler.py -v`

- [ ] **Step 3: Write implementation**

```python
# instadomain/stripe_handler.py
from __future__ import annotations

from typing import Any

import stripe

from .config import settings


def _init_stripe() -> None:
    stripe.api_key = settings.stripe_secret_key


async def create_checkout_session(
    *, domain: str, amount_cents: int, order_id: str
) -> dict[str, str]:
    _init_stripe()
    session = stripe.checkout.Session.create(
        payment_method_types=["card"],
        line_items=[
            {
                "price_data": {
                    "currency": "usd",
                    "unit_amount": amount_cents,
                    "product_data": {
                        "name": f"Domain: {domain}",
                        "description": f"1 year registration for {domain}",
                    },
                },
                "quantity": 1,
            }
        ],
        mode="payment",
        success_url=f"https://instadomain.dev/success?order={order_id}",
        cancel_url=f"https://instadomain.dev/cancel?order={order_id}",
        expires_after=86400,  # 24 hours
        metadata={"order_id": order_id, "domain": domain},
    )
    return {
        "session_id": session.id,
        "checkout_url": session.url,
        "payment_intent": session.payment_intent or "",
    }


def verify_webhook(payload: bytes, sig_header: str) -> dict[str, Any]:
    """Verify and parse a Stripe webhook event."""
    _init_stripe()
    event = stripe.Webhook.construct_event(
        payload, sig_header, settings.stripe_webhook_secret
    )
    return dict(event)


def process_webhook_event(event: dict[str, Any]) -> dict[str, str] | None:
    """Extract relevant data from a webhook event.

    Returns None for event types we don't care about.
    """
    if event.get("type") != "checkout.session.completed":
        return None

    session = event["data"]["object"]
    customer = session.get("customer_details") or {}
    return {
        "session_id": session["id"],
        "payment_intent": session.get("payment_intent", ""),
        "email": customer.get("email", ""),
    }


async def issue_refund(payment_intent_id: str) -> dict[str, str]:
    """Issue a full refund for a payment."""
    _init_stripe()
    refund = stripe.Refund.create(payment_intent=payment_intent_id)
    return {
        "refund_id": refund.id,
        "status": refund.status,
    }
```

- [ ] **Step 4: Run tests**

Run: `pytest tests/test_instadomain/test_stripe_handler.py -v`
Expected: PASS (3 tests)

- [ ] **Step 5: Commit**

```bash
git add instadomain/stripe_handler.py tests/test_instadomain/test_stripe_handler.py
git commit -m "feat: add Stripe handler (checkout, webhooks, refunds)"
```

---

## Chunk 3: Fulfillment, API, and MCP Server

### Task 9: Fulfillment orchestrator

**Files:**
- Create: `instadomain/fulfillment.py`
- Create: `tests/test_instadomain/test_fulfillment.py`

This module orchestrates the post-payment flow: register domain → set nameservers → create Cloudflare zone → create scoped token → mark complete. Handles compensating transactions (auto-refund on failure).

- [ ] **Step 1: Write tests with mocked service clients**

```python
# tests/test_instadomain/test_fulfillment.py
import pytest
from unittest.mock import AsyncMock, patch
from instadomain.fulfillment import fulfill_order


@pytest.mark.asyncio
async def test_fulfill_order_happy_path(test_db):
    from instadomain.orders import create_order

    order = await create_order(
        test_db, domain="test.com", tld="com",
        amount_cents=1099, stripe_session_id="cs_test",
    )
    # Move to registering (simulating webhook receipt)
    from instadomain.orders import update_order_status
    await update_order_status(
        test_db, order["id"], "registering",
        email="user@test.com", stripe_payment_intent="pi_test",
    )

    mock_opensrs = AsyncMock()
    mock_opensrs.register.return_value = {
        "order_id": "opensrs_123", "expiry": "2027-03-15",
    }
    mock_opensrs.update_nameservers = AsyncMock()

    mock_cf = AsyncMock()
    mock_cf.create_zone.return_value = {
        "zone_id": "zone_abc",
        "nameservers": ["ns1.cf.com", "ns2.cf.com"],
    }
    mock_cf.create_dns_token.return_value = "cf_scoped_token"

    result = await fulfill_order(
        pool=test_db,
        order_id=order["id"],
        opensrs=mock_opensrs,
        cloudflare=mock_cf,
        encryption_key="test_key_" + "0" * 24,  # 32 bytes for Fernet
    )

    assert result["status"] == "complete"
    mock_opensrs.register.assert_called_once()
    mock_cf.create_zone.assert_called_once_with("test.com")


@pytest.mark.asyncio
async def test_fulfill_order_opensrs_failure_triggers_refund(test_db):
    from instadomain.orders import create_order, update_order_status

    order = await create_order(
        test_db, domain="fail.com", tld="com",
        amount_cents=1099, stripe_session_id="cs_fail",
    )
    await update_order_status(
        test_db, order["id"], "registering",
        email="user@test.com", stripe_payment_intent="pi_fail",
    )

    mock_opensrs = AsyncMock()
    mock_opensrs.register.side_effect = Exception("Domain taken")

    mock_cf = AsyncMock()

    with patch(
        "instadomain.fulfillment.issue_refund",
        new_callable=AsyncMock,
        return_value={"refund_id": "re_123", "status": "succeeded"},
    ) as mock_refund:
        result = await fulfill_order(
            pool=test_db,
            order_id=order["id"],
            opensrs=mock_opensrs,
            cloudflare=mock_cf,
            encryption_key="test_key_" + "0" * 24,
        )

    assert result["status"] == "failed"
    assert "Domain taken" in result["error_msg"]
    mock_refund.assert_called_once_with("pi_fail")
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_instadomain/test_fulfillment.py -v`

- [ ] **Step 3: Write implementation**

```python
# instadomain/fulfillment.py
from __future__ import annotations

import json
import logging
from typing import Any

import asyncpg

from .cloudflare_client import CloudflareClient
from .encryption import encrypt
from .opensrs_client import OpenSRSClient
from .orders import get_order, update_order_status
from .stripe_handler import issue_refund

logger = logging.getLogger(__name__)


async def fulfill_order(
    *,
    pool: asyncpg.Pool,
    order_id: str,
    opensrs: OpenSRSClient,
    cloudflare: CloudflareClient,
    encryption_key: str,
) -> dict[str, Any]:
    """Execute the post-payment fulfillment pipeline.

    Steps: register domain → create CF zone → set nameservers → create token.
    Auto-refunds on registration failure.
    """
    order = await get_order(pool, order_id)
    if order is None:
        raise ValueError(f"Order {order_id} not found")

    if order["status"] != "registering":
        raise ValueError(
            f"Order {order_id} status is {order['status']}, expected registering"
        )

    # Step 1: Register domain with OpenSRS
    try:
        reg_result = await opensrs.register(
            domain=order["domain"],
            years=order.get("registration_years", 1),
            registrant_email=order.get("email", ""),
        )
    except Exception as exc:
        logger.error("OpenSRS registration failed for %s: %s", order["domain"], exc)
        # Compensating transaction: refund payment
        pi = order.get("stripe_payment_intent")
        if pi:
            try:
                await issue_refund(pi)
                logger.info("Refund issued for order %s", order_id)
            except Exception as refund_exc:
                logger.error("Refund also failed for %s: %s", order_id, refund_exc)

        updated = await update_order_status(
            pool, order_id, "failed",
            error_msg=f"Registration failed: {exc}",
        )
        return dict(updated)

    # Step 2: Create Cloudflare zone
    await update_order_status(
        pool, order_id, "setting_dns",
        opensrs_order_id=reg_result["order_id"],
        domain_expires_at=reg_result.get("expiry"),
    )

    try:
        zone_result = await cloudflare.create_zone(order["domain"])
        zone_id = zone_result["zone_id"]
        nameservers = zone_result["nameservers"]

        # Step 3: Update nameservers at OpenSRS
        if nameservers:
            try:
                await opensrs.update_nameservers(order["domain"], nameservers)
            except Exception as ns_exc:
                logger.warning(
                    "Nameserver update failed for %s (non-fatal): %s",
                    order["domain"], ns_exc,
                )

        # Step 4: Create scoped DNS token
        token = await cloudflare.create_dns_token(zone_id, order["domain"])
        encrypted_token = encrypt(token, encryption_key)

        # Step 5: Mark complete
        updated = await update_order_status(
            pool, order_id, "complete",
            cloudflare_zone_id=zone_id,
            cloudflare_api_token=encrypted_token,
            nameservers=json.dumps(nameservers),
        )
        logger.info("Order %s fulfilled: %s", order_id, order["domain"])
        return dict(updated)

    except Exception as exc:
        logger.error("DNS setup failed for %s: %s", order["domain"], exc)
        # Domain is registered but DNS failed -- don't refund (they have the domain)
        updated = await update_order_status(
            pool, order_id, "failed",
            error_msg=f"DNS setup failed (domain registered): {exc}",
            opensrs_order_id=reg_result.get("order_id"),
        )
        return dict(updated)
```

- [ ] **Step 4: Run tests**

Run: `pytest tests/test_instadomain/test_fulfillment.py -v`
Expected: PASS (2 tests)

- [ ] **Step 5: Commit**

```bash
git add instadomain/fulfillment.py tests/test_instadomain/test_fulfillment.py
git commit -m "feat: add fulfillment orchestrator with compensating transactions"
```

---

### Task 10: FastAPI backend

**Files:**
- Create: `instadomain/api.py`
- Create: `tests/test_instadomain/test_api.py`

- [ ] **Step 1: Write tests using FastAPI TestClient**

```python
# tests/test_instadomain/test_api.py
import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from httpx import AsyncClient, ASGITransport
from instadomain.api import create_app


@pytest.fixture
def app(test_db, fernet_key):
    """Create app with test DB pool."""
    application = create_app()
    # Override dependencies
    application.state.pool = test_db
    application.state.encryption_key = fernet_key
    application.state.opensrs = AsyncMock()
    application.state.cloudflare = AsyncMock()
    return application


@pytest.fixture
async def client(app):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest.mark.asyncio
async def test_health(client):
    resp = await client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


@pytest.mark.asyncio
async def test_check_domain_available(client):
    with patch(
        "instadomain.api._check_availability",
        return_value={"available": True, "domain": "test123xyz.com"},
    ), patch(
        "instadomain.api._get_price",
        return_value=890,
    ):
        resp = await client.get("/check/test123xyz.com")
    assert resp.status_code == 200
    data = resp.json()
    assert data["available"] is True
    assert "price_cents" in data


@pytest.mark.asyncio
async def test_buy_creates_order(client):
    with patch(
        "instadomain.api._check_availability",
        return_value={"available": True, "domain": "test123xyz.com"},
    ), patch(
        "instadomain.api._get_price",
        return_value=890,
    ), patch(
        "instadomain.stripe_handler.create_checkout_session",
        new_callable=AsyncMock,
        return_value={
            "session_id": "cs_test",
            "checkout_url": "https://checkout.stripe.com/test",
            "payment_intent": "pi_test",
        },
    ):
        resp = await client.post("/buy", json={"domain": "test123xyz.com"})
    assert resp.status_code == 200
    data = resp.json()
    assert "checkout_url" in data
    assert "order_id" in data


@pytest.mark.asyncio
async def test_buy_taken_domain_returns_400(client):
    with patch(
        "instadomain.api._check_availability",
        return_value={"available": False, "domain": "google.com"},
    ):
        resp = await client.post("/buy", json={"domain": "google.com"})
    assert resp.status_code == 400


@pytest.mark.asyncio
async def test_status_not_found(client):
    resp = await client.get("/status/ord_nonexistent")
    assert resp.status_code == 404
```

- [ ] **Step 2: Run to verify failure**

Run: `pytest tests/test_instadomain/test_api.py -v`

- [ ] **Step 3: Write API implementation**

```python
# instadomain/api.py
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from slowapi import Limiter
from slowapi.util import get_remote_address

from . import domain_lookup
from .cloudflare_client import CloudflareClient
from .config import settings
from .db import close_pool, init_pool
from .encryption import decrypt
from .fulfillment import fulfill_order
from .opensrs_client import OpenSRSClient
from .orders import (
    create_order,
    get_order,
    get_order_by_stripe_session,
    update_order_status,
)
from .pricing import calculate_retail_cents, format_price
from .stripe_handler import (
    create_checkout_session,
    process_webhook_event,
    verify_webhook,
)

logger = logging.getLogger(__name__)
limiter = Limiter(key_func=get_remote_address)


@asynccontextmanager
async def lifespan(app: FastAPI):
    pool = await init_pool(settings.database_url)
    app.state.pool = pool
    app.state.encryption_key = settings.encryption_key
    app.state.opensrs = OpenSRSClient(
        api_key=settings.opensrs_api_key,
        reseller_username=settings.opensrs_reseller_username,
        api_url=settings.opensrs_api_url,
    )
    app.state.cloudflare = CloudflareClient(
        api_token=settings.cloudflare_api_token,
        account_id=settings.cloudflare_account_id,
    )
    yield
    await app.state.cloudflare.close()
    await close_pool()


def create_app() -> FastAPI:
    app = FastAPI(title="InstaDomain", lifespan=lifespan)
    app.state.limiter = limiter

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/check/{domain}")
    @limiter.limit("30/minute")
    async def check_domain(domain: str, request: Request):
        result = await _check_availability(domain)
        if not result["available"]:
            return JSONResponse({"available": False, "domain": domain})

        tld = domain.rsplit(".", 1)[-1]
        try:
            wholesale = await _get_price(domain, request.app)
        except Exception:
            wholesale = None

        if wholesale is not None:
            retail = calculate_retail_cents(wholesale, tld)
            return JSONResponse({
                "available": True,
                "domain": domain,
                "price_cents": retail,
                "price": format_price(retail),
                "price_yearly": format_price(retail) + "/yr",
            })
        return JSONResponse({
            "available": True,
            "domain": domain,
            "price_cents": None,
            "price": "Contact for pricing",
        })

    @app.post("/buy")
    @limiter.limit("5/minute")
    async def buy_domain(request: Request):
        body = await request.json()
        domain = body.get("domain", "").strip().lower()
        if not domain:
            return JSONResponse({"error": "domain required"}, status_code=400)

        # Check availability
        result = await _check_availability(domain)
        if not result["available"]:
            return JSONResponse(
                {"error": f"{domain} is not available"}, status_code=400
            )

        tld = domain.rsplit(".", 1)[-1]
        try:
            wholesale = await _get_price(domain, request.app)
        except Exception:
            return JSONResponse(
                {"error": "Could not determine price"}, status_code=500
            )

        retail = calculate_retail_cents(wholesale, tld)

        # Create Stripe checkout session
        checkout = await create_checkout_session(
            domain=domain, amount_cents=retail, order_id="pending",
        )

        # Create order in DB
        pool = request.app.state.pool
        order = await create_order(
            pool, domain=domain, tld=tld,
            amount_cents=retail, wholesale_cents=wholesale,
            stripe_session_id=checkout["session_id"],
        )

        return JSONResponse({
            "order_id": order["id"],
            "domain": domain,
            "price": format_price(retail),
            "checkout_url": checkout["checkout_url"],
        })

    @app.get("/status/{order_id}")
    @limiter.limit("60/minute")
    async def order_status(order_id: str, request: Request):
        pool = request.app.state.pool
        order = await get_order(pool, order_id)
        if order is None:
            return JSONResponse({"error": "Order not found"}, status_code=404)

        response: dict[str, Any] = {
            "order_id": order["id"],
            "domain": order["domain"],
            "status": order["status"],
        }

        if order["status"] == "complete" and not order["cloudflare_token_retrieved"]:
            # Decrypt and return token, mark as retrieved
            key = request.app.state.encryption_key
            token = decrypt(order["cloudflare_api_token"], key)
            response["cloudflare_token"] = token
            response["nameservers"] = order.get("nameservers")

            await update_order_status(
                pool, order["id"], "complete",  # no-op status change
                cloudflare_token_retrieved=True,
            )
        elif order["status"] == "complete":
            response["cloudflare_token"] = "already_retrieved"

        if order["status"] == "failed":
            response["error_msg"] = order.get("error_msg")

        return JSONResponse(response)

    @app.post("/webhooks/stripe")
    async def stripe_webhook(request: Request):
        payload = await request.body()
        sig = request.headers.get("stripe-signature", "")

        try:
            event = verify_webhook(payload, sig)
        except Exception as exc:
            logger.warning("Webhook verification failed: %s", exc)
            return JSONResponse({"error": "Invalid signature"}, status_code=400)

        result = process_webhook_event(event)
        if result is None:
            return JSONResponse({"received": True})

        pool = request.app.state.pool
        order = await get_order_by_stripe_session(pool, result["session_id"])
        if order is None:
            logger.warning("No order for session %s", result["session_id"])
            return JSONResponse({"received": True})

        # Idempotency: skip if already past pending_payment
        if order["status"] != "pending_payment":
            logger.info("Order %s already %s, skipping", order["id"], order["status"])
            return JSONResponse({"received": True})

        # Transition to registering
        await update_order_status(
            pool, order["id"], "registering",
            email=result["email"],
            stripe_payment_intent=result["payment_intent"],
        )

        # Kick off fulfillment (async, non-blocking)
        import asyncio
        asyncio.create_task(
            fulfill_order(
                pool=pool,
                order_id=order["id"],
                opensrs=request.app.state.opensrs,
                cloudflare=request.app.state.cloudflare,
                encryption_key=request.app.state.encryption_key,
            )
        )

        return JSONResponse({"received": True, "order_id": order["id"]})

    return app


async def _check_availability(domain: str) -> dict[str, Any]:
    """Check domain availability via RDAP (reuse existing domaincheckr logic)."""
    from domain_lookup import check_domain as rdap_check
    result = await rdap_check(domain)
    return {"available": result.available, "domain": result.domain}


async def _get_price(domain: str, app: FastAPI | None = None) -> int:
    """Get wholesale price from OpenSRS. Returns cents."""
    if app and hasattr(app.state, "opensrs"):
        return await app.state.opensrs.get_price(domain)
    raise RuntimeError("OpenSRS client not available")
```

- [ ] **Step 4: Run tests**

Run: `pytest tests/test_instadomain/test_api.py -v`
Expected: PASS (5 tests)

- [ ] **Step 5: Commit**

```bash
git add instadomain/api.py tests/test_instadomain/test_api.py
git commit -m "feat: add FastAPI backend with /check, /buy, /status, /webhooks"
```

---

### Task 11: MCP Server (thin client)

**Files:**
- Create: `instadomain/mcp_server.py`

- [ ] **Step 1: Write MCP server**

```python
# instadomain/mcp_server.py
from __future__ import annotations

import asyncio
import sys

import httpx
from mcp.server.fastmcp import FastMCP

_BACKEND = "https://instadomain.dev/api"
_TIMEOUT_CHECK = 10.0
_TIMEOUT_BUY = 10.0
_POLL_INTERVAL = 3.0
_POLL_TIMEOUT = 120.0

mcp = FastMCP("instadomain", instructions="Buy domains without leaving your terminal.")


@mcp.tool()
async def check_domain(domain: str) -> dict:
    """Check if a domain is available and get the price.

    Args:
        domain: The domain to check (e.g. "example.com")

    Returns:
        Availability status, price if available.
    """
    async with httpx.AsyncClient(timeout=_TIMEOUT_CHECK) as client:
        resp = await client.get(f"{_BACKEND}/check/{domain}")
        resp.raise_for_status()
        return resp.json()


@mcp.tool()
async def buy_domain(domain: str) -> dict:
    """Purchase a domain. Returns a Stripe checkout URL to complete payment.

    After payment, use get_domain_status with the order_id to get your
    Cloudflare DNS API token.

    Args:
        domain: The domain to purchase (e.g. "example.com")

    Returns:
        order_id and checkout_url for payment.
    """
    async with httpx.AsyncClient(timeout=_TIMEOUT_BUY) as client:
        resp = await client.post(
            f"{_BACKEND}/buy", json={"domain": domain}
        )
        if resp.status_code == 400:
            return resp.json()
        resp.raise_for_status()
        data = resp.json()

    # Poll for completion after user pays
    order_id = data["order_id"]
    print(f"\nDomain: {data['domain']}")
    print(f"Price: {data['price']}")
    print(f"Pay here: {data['checkout_url']}")
    print(f"\nAfter paying, I'll check for confirmation automatically.")
    print(f"Order ID: {order_id}")

    return data


@mcp.tool()
async def get_domain_status(order_id: str) -> dict:
    """Check the status of a domain purchase order.

    Poll this after completing Stripe payment to get your Cloudflare DNS token.

    Args:
        order_id: The order ID from buy_domain (e.g. "ord_abc123")

    Returns:
        Order status. When complete, includes cloudflare_token for DNS management.
    """
    elapsed = 0.0
    async with httpx.AsyncClient(timeout=10.0) as client:
        while elapsed < _POLL_TIMEOUT:
            resp = await client.get(f"{_BACKEND}/status/{order_id}")
            resp.raise_for_status()
            data = resp.json()

            if data["status"] in ("complete", "failed", "expired"):
                return data

            await asyncio.sleep(_POLL_INTERVAL)
            elapsed += _POLL_INTERVAL

    return {"status": "timeout", "order_id": order_id,
            "message": "Order still processing. Try again in a minute."}


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
```

- [ ] **Step 2: Verify it imports cleanly**

Run: `python3 -c "from instadomain.mcp_server import mcp; print('OK')"`
Expected: `OK`

- [ ] **Step 3: Commit**

```bash
git add instadomain/mcp_server.py
git commit -m "feat: add MCP server with check_domain, buy_domain, get_domain_status"
```

---

### Task 12: Fly.io deployment config

**Files:**
- Create: `fly-instadomain.toml`

- [ ] **Step 1: Write Fly.io config**

```toml
# fly-instadomain.toml
app = "instadomain"
primary_region = "sjc"

[build]
  dockerfile = "Dockerfile.instadomain"

[env]
  PORT = "8080"

[http_service]
  internal_port = 8080
  force_https = true
  auto_stop_machines = "stop"
  auto_start_machines = true
  min_machines_running = 1

  [http_service.concurrency]
    type = "requests"
    soft_limit = 200
    hard_limit = 250

[[http_service.checks]]
  grace_period = "10s"
  interval = "30s"
  method = "GET"
  path = "/health"
  timeout = "5s"

[[vm]]
  memory = "512mb"
  cpu_kind = "shared"
  cpus = 1
```

- [ ] **Step 2: Create Dockerfile**

```dockerfile
# Dockerfile.instadomain
FROM python:3.12-slim

WORKDIR /app
COPY requirements-instadomain.txt .
RUN pip install --no-cache-dir -r requirements-instadomain.txt

COPY domain_lookup.py .
COPY instadomain/ instadomain/

CMD ["uvicorn", "instadomain.api:create_app", "--factory", "--host", "0.0.0.0", "--port", "8080"]
```

- [ ] **Step 3: Create requirements-instadomain.txt**

```
httpx>=0.27
pydantic>=2.0
pydantic-settings>=2.0
fastapi[standard]>=0.100
uvicorn[standard]>=0.30
asyncpg>=0.29
stripe>=8.0
cryptography>=42.0
slowapi>=0.1
```

- [ ] **Step 4: Commit**

```bash
git add fly-instadomain.toml Dockerfile.instadomain requirements-instadomain.txt
git commit -m "feat: add Fly.io deployment config for instadomain"
```

---

### Task 13: Run full test suite

- [ ] **Step 1: Run all instadomain tests**

Run: `pytest tests/test_instadomain/ -v`
Expected: All tests pass

- [ ] **Step 2: Run existing domaincheckr tests (regression check)**

Run: `pytest tests/test_integration.py -v`
Expected: All existing tests still pass (we didn't touch domaincheckr code)

- [ ] **Step 3: Commit any fixes if needed**

---

## Pre-Deployment Checklist

Before deploying, the following accounts and secrets are needed (not part of code tasks):

1. [ ] Buy `instadomain.dev` domain
2. [ ] Apply for OpenSRS reseller account ($100 deposit)
3. [ ] Create Stripe account, get API keys
4. [ ] Create Cloudflare account, get API token + account ID
5. [ ] Look up Cloudflare DNS permission group IDs (replace placeholders in `cloudflare_client.py`)
6. [ ] Create Fly.io Postgres database: `fly postgres create --name instadomain-db`
7. [ ] Set all env vars on Fly.io: `fly secrets set --app instadomain ...`
8. [ ] Deploy: `fly deploy --config fly-instadomain.toml`
9. [ ] Add static pages (ToS, Privacy Policy) to the API
10. [ ] Publish to PyPI: `python -m build && twine upload dist/*`
