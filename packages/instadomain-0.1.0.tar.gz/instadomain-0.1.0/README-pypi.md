# InstaDomain

Buy domains without leaving the terminal. An MCP server for Claude Code that lets you check availability, purchase domains, and get DNS management credentials -- all through natural conversation.

## What It Does

1. **Check domain availability** -- see if a domain is available and get instant pricing
2. **Buy domains** -- purchase via Stripe checkout (opens in browser)
3. **Get DNS access** -- receive Cloudflare nameservers and a scoped API token for DNS management

## Setup

### Install

```bash
pip install instadomain
```

### Add to Claude Code

Add to your Claude Code MCP config (`~/.claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "instadomain": {
      "command": "instadomain"
    }
  }
}
```

### Or run directly

```bash
instadomain
```

## Usage

Once configured, just ask Claude:

- "Is coolstartup.com available?"
- "Buy mycoolproject.dev"
- "What's the status of my domain order?"

## How It Works

InstaDomain registers domains through OpenSRS, sets up DNS on Cloudflare, and gives you a scoped API token so you can manage DNS records programmatically. Payments are handled securely through Stripe.

## Pricing

Domains are priced at wholesale cost + a small markup. Prices vary by TLD. You'll see the exact price before confirming any purchase.
