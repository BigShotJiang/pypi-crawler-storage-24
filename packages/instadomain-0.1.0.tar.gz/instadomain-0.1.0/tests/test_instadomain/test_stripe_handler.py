from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from instadomain import stripe_handler


@pytest.fixture(autouse=True)
def _mock_settings(monkeypatch):
    """Inject test settings so the module doesn't need real env vars."""
    monkeypatch.setattr(
        stripe_handler,
        "settings",
        SimpleNamespace(
            stripe_secret_key="sk_test_fake",
            stripe_webhook_secret="whsec_test_fake",
        ),
    )


def test_create_checkout_session_returns_expected_fields():
    """create_checkout_session should return session_id, checkout_url, and payment_intent."""
    mock_session = SimpleNamespace(
        id="cs_test_session_123",
        url="https://checkout.stripe.com/pay/cs_test_session_123",
        payment_intent="pi_test_intent_456",
    )
    mock_client = MagicMock()
    mock_client.v1.checkout.sessions.create.return_value = mock_session

    with patch("stripe.StripeClient", return_value=mock_client):
        result = stripe_handler.create_checkout_session(
            domain="example.com",
            amount_cents=1099,
            order_id="ord_abc123",
        )

    assert result["session_id"] == "cs_test_session_123"
    assert result["checkout_url"] == "https://checkout.stripe.com/pay/cs_test_session_123"
    assert result["payment_intent"] == "pi_test_intent_456"

    # Verify the Stripe API was called with correct params
    call_kwargs = mock_client.v1.checkout.sessions.create.call_args
    params = call_kwargs.kwargs["params"]
    assert params["metadata"]["order_id"] == "ord_abc123"
    assert params["metadata"]["domain"] == "example.com"
    assert params["line_items"][0]["price_data"]["unit_amount"] == 1099


def test_process_webhook_event_extracts_checkout_data():
    """process_webhook_event should extract session_id, payment_intent, email."""
    event = {
        "type": "checkout.session.completed",
        "data": {
            "object": {
                "id": "cs_test_completed_789",
                "payment_intent": "pi_test_completed_101",
                "customer_details": {"email": "buyer@example.com"},
            }
        },
    }
    result = stripe_handler.process_webhook_event(event)
    assert result is not None
    assert result["session_id"] == "cs_test_completed_789"
    assert result["payment_intent"] == "pi_test_completed_101"
    assert result["email"] == "buyer@example.com"


def test_process_webhook_event_returns_none_for_other_types():
    """process_webhook_event should return None for non-checkout events."""
    event = {
        "type": "payment_intent.succeeded",
        "data": {"object": {"id": "pi_test_xxx"}},
    }
    assert stripe_handler.process_webhook_event(event) is None


def test_issue_refund_returns_refund_info():
    """issue_refund should return refund_id and status."""
    mock_refund = SimpleNamespace(id="re_test_refund_202", status="succeeded")
    mock_client = MagicMock()
    mock_client.v1.refunds.create.return_value = mock_refund

    with patch("stripe.StripeClient", return_value=mock_client):
        result = stripe_handler.issue_refund("pi_test_intent_456")

    assert result["refund_id"] == "re_test_refund_202"
    assert result["status"] == "succeeded"

    call_kwargs = mock_client.v1.refunds.create.call_args
    assert call_kwargs.kwargs["params"]["payment_intent"] == "pi_test_intent_456"


def test_verify_webhook_calls_construct_event():
    """verify_webhook should call stripe.Webhook.construct_event with correct args."""
    fake_event = {"type": "checkout.session.completed", "id": "evt_test"}

    with patch("stripe.Webhook.construct_event", return_value=fake_event) as mock_construct:
        result = stripe_handler.verify_webhook(b"raw-payload", "sig-header-value")

    mock_construct.assert_called_once_with(
        b"raw-payload",
        "sig-header-value",
        "whsec_test_fake",
    )
    assert result == fake_event
