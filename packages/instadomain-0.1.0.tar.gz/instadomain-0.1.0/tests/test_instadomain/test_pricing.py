from instadomain.pricing import calculate_retail_cents, format_price


def test_standard_com_markup():
    """Standard .com: 890 wholesale + 209 markup = 1099."""
    assert calculate_retail_cents(890, "com") == 1099


def test_standard_dev_markup():
    """Standard .dev: 1200 wholesale + 299 markup = 1499."""
    assert calculate_retail_cents(1200, "dev") == 1499


def test_premium_domain_uses_percentage():
    """Premium domain above threshold: 5000 * 1.25 = 6250."""
    assert calculate_retail_cents(5000, "com") == 6250


def test_format_price():
    """1099 cents should format as '$10.99'."""
    assert format_price(1099) == "$10.99"
