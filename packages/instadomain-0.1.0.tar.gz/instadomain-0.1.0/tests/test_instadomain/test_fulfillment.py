from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from cryptography.fernet import Fernet

from instadomain.fulfillment import fulfill_order
from instadomain.orders import create_order, get_order, update_order_status


pytestmark = pytest.mark.asyncio


async def _create_registering_order(pool, **overrides):
    """Helper: create an order and advance it to 'registering' status."""
    defaults = dict(
        domain="example.com",
        tld="com",
        amount_cents=1299,
        stripe_session_id="cs_test_fulfill",
        wholesale_cents=890,
    )
    defaults.update(overrides)
    order = await create_order(pool, **defaults)
    order = await update_order_status(
        pool, order["id"], "registering",
        stripe_payment_intent="pi_test_123",
        email="buyer@example.com",
    )
    return order


async def test_fulfill_happy_path(test_db, fernet_key):
    """Full happy path: register -> CF zone -> update NS -> DNS token -> complete."""
    order = await _create_registering_order(test_db)

    # Mock OpenSRS (sync)
    opensrs = MagicMock()
    opensrs.register.return_value = {"order_id": "opensrs_123", "expiry": "2027-03-15"}
    opensrs.update_nameservers.return_value = None

    # Mock Cloudflare (async)
    cloudflare = AsyncMock()
    cloudflare.create_zone.return_value = {
        "zone_id": "zone_abc",
        "nameservers": ["ns1.cloudflare.com", "ns2.cloudflare.com"],
    }
    cloudflare.create_dns_token.return_value = "cf_token_secret_value"

    result = await fulfill_order(
        pool=test_db,
        order_id=order["id"],
        opensrs=opensrs,
        cloudflare=cloudflare,
        encryption_key=fernet_key,
    )

    # Verify result
    assert result["status"] == "complete"
    assert result["cloudflare_zone_id"] == "zone_abc"
    assert result["nameservers"] == ["ns1.cloudflare.com", "ns2.cloudflare.com"]
    assert result["opensrs_order_id"] == "opensrs_123"

    # Verify the token was encrypted (not stored in plain text)
    final_order = await get_order(test_db, order["id"])
    assert final_order["status"] == "complete"
    assert final_order["cloudflare_api_token"] is not None
    assert final_order["cloudflare_api_token"] != "cf_token_secret_value"

    # Verify the encrypted token decrypts correctly
    f = Fernet(fernet_key.encode())
    decrypted = f.decrypt(final_order["cloudflare_api_token"].encode()).decode()
    assert decrypted == "cf_token_secret_value"

    # Verify OpenSRS was called with placeholder NS first, then updated
    opensrs.register.assert_called_once()
    call_kwargs = opensrs.register.call_args
    assert call_kwargs[1]["domain"] == "example.com" or call_kwargs[0][0] == "example.com"

    opensrs.update_nameservers.assert_called_once_with(
        "example.com", ["ns1.cloudflare.com", "ns2.cloudflare.com"]
    )

    # Verify Cloudflare calls
    cloudflare.create_zone.assert_called_once_with("example.com")
    cloudflare.create_dns_token.assert_called_once_with("zone_abc", "example.com")


async def test_fulfill_opensrs_failure_triggers_refund(test_db, fernet_key):
    """When OpenSRS registration fails, a Stripe refund should be issued and order marked failed."""
    order = await _create_registering_order(
        test_db,
        stripe_session_id="cs_test_refund",
    )

    # Mock OpenSRS to fail
    opensrs = MagicMock()
    opensrs.register.side_effect = Exception("OpenSRS registration failed")

    # Mock Cloudflare (should NOT be called)
    cloudflare = AsyncMock()

    with patch(
        "instadomain.fulfillment.issue_refund",
        return_value={"refund_id": "re_123", "status": "succeeded"},
    ) as mock_refund:
        result = await fulfill_order(
            pool=test_db,
            order_id=order["id"],
            opensrs=opensrs,
            cloudflare=cloudflare,
            encryption_key=fernet_key,
        )

    # Order should be failed
    assert result["status"] == "failed"
    assert "OpenSRS registration failed" in (result.get("error_msg") or "")

    # Refund should have been issued
    mock_refund.assert_called_once_with("pi_test_123")

    # Cloudflare should NOT have been called
    cloudflare.create_zone.assert_not_called()

    # Verify in DB
    final_order = await get_order(test_db, order["id"])
    assert final_order["status"] == "failed"
