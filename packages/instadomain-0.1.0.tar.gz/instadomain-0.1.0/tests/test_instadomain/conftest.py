import asyncio

import pytest
from cryptography.fernet import Fernet


@pytest.fixture
def fernet_key() -> str:
    """Generate a fresh Fernet encryption key for testing."""
    return Fernet.generate_key().decode()


@pytest.fixture
async def test_db():
    """Provide a temporary Postgres database for integration tests.

    Connects to the default 'postgres' database, creates a temporary test
    database, initializes the instadomain schema, yields the pool, then
    cleans up.

    Skips if Postgres is not available at localhost.
    """
    import asyncpg

    admin_dsn = "postgresql://localhost/postgres"
    test_db_name = "instadomain_test"

    # Check if Postgres is reachable
    try:
        conn = await asyncpg.connect(admin_dsn)
    except (OSError, asyncpg.PostgresError):
        pytest.skip("Postgres not available at localhost")
        return

    # Drop and recreate the test database
    try:
        await conn.execute(f"DROP DATABASE IF EXISTS {test_db_name}")
        await conn.execute(f"CREATE DATABASE {test_db_name}")
    finally:
        await conn.close()

    # Initialize schema and yield pool
    from instadomain.db import init_pool, close_pool

    test_dsn = f"postgresql://localhost/{test_db_name}"
    pool = await init_pool(test_dsn)
    try:
        yield pool
    finally:
        await close_pool()
        # Drop the test database
        conn = await asyncpg.connect(admin_dsn)
        try:
            await conn.execute(f"DROP DATABASE IF EXISTS {test_db_name}")
        finally:
            await conn.close()
