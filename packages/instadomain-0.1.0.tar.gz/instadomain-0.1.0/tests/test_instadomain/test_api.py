from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from instadomain.api import create_app


pytestmark = pytest.mark.asyncio


def _make_app(pool, fernet_key):
    """Create a fresh FastAPI app with mocked external dependencies."""
    app = create_app()
    app.state.pool = pool
    app.state.opensrs = MagicMock()
    app.state.cloudflare = AsyncMock()
    app.state.encryption_key = fernet_key
    return app


@pytest.fixture
async def fresh_client(test_db, fernet_key):
    """Async HTTP client with a fresh app instance (avoids rate limit leaks)."""
    app = _make_app(test_db, fernet_key)
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


async def test_health_returns_200(fresh_client):
    """GET /health should return 200 with status ok."""
    resp = await fresh_client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"


async def test_check_available_domain(fresh_client):
    """GET /check/{domain} for an available domain should return availability and price."""
    with patch(
        "instadomain.api._check_availability",
        new_callable=AsyncMock,
        return_value={"available": True, "domain": "coolstartup.com"},
    ), patch(
        "instadomain.api._get_price",
        new_callable=AsyncMock,
        return_value=890,
    ):
        resp = await fresh_client.get("/check/coolstartup.com")

    assert resp.status_code == 200
    data = resp.json()
    assert data["available"] is True
    assert data["domain"] == "coolstartup.com"
    assert "price_cents" in data
    assert "price_display" in data


async def test_buy_available_domain(test_db, fernet_key):
    """POST /buy with an available domain should create checkout + order."""
    app = _make_app(test_db, fernet_key)
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        with patch(
            "instadomain.api._check_availability",
            new_callable=AsyncMock,
            return_value={"available": True, "domain": "buyme.com"},
        ), patch(
            "instadomain.api._get_price",
            return_value=890,
        ), patch(
            "instadomain.api.create_checkout_session",
            return_value={
                "session_id": "cs_test_buy",
                "checkout_url": "https://checkout.stripe.com/test",
                "payment_intent": "pi_test_buy",
            },
        ):
            resp = await client.post("/buy", json={"domain": "buyme.com"})

    assert resp.status_code == 200
    data = resp.json()
    assert data["checkout_url"] == "https://checkout.stripe.com/test"
    assert "order_id" in data
    assert data["order_id"].startswith("ord_")


async def test_buy_taken_domain(test_db, fernet_key):
    """POST /buy with a taken domain should return 400."""
    app = _make_app(test_db, fernet_key)
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        with patch(
            "instadomain.api._check_availability",
            new_callable=AsyncMock,
            return_value={"available": False, "domain": "google.com"},
        ):
            resp = await client.post("/buy", json={"domain": "google.com"})

    assert resp.status_code == 400
    data = resp.json()
    assert "not available" in data["detail"].lower() or "unavailable" in data["detail"].lower()


async def test_status_nonexistent_order(fresh_client):
    """GET /status/{order_id} for a nonexistent order should return 404."""
    resp = await fresh_client.get("/status/ord_nonexistent_123")
    assert resp.status_code == 404
