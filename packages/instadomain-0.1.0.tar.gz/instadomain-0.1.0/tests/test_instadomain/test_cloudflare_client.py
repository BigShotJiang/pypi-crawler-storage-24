from unittest.mock import AsyncMock, patch

import httpx
import pytest

from instadomain.cloudflare_client import CloudflareClient, CloudflareError


@pytest.fixture
def client():
    return CloudflareClient(api_token="test-token", account_id="test-account-id")


def _mock_response(json_data: dict, status_code: int = 200) -> httpx.Response:
    """Build a fake httpx.Response with JSON body."""
    return httpx.Response(status_code=status_code, json=json_data)


async def test_create_zone_returns_zone_id_and_nameservers(client):
    """create_zone should return zone_id and nameservers from the API response."""
    mock_resp = _mock_response(
        {
            "success": True,
            "result": {
                "id": "zone-abc-123",
                "name_servers": ["ns1.cloudflare.com", "ns2.cloudflare.com"],
                "name": "example.com",
                "status": "pending",
            },
        }
    )
    with patch.object(client._client, "post", new_callable=AsyncMock, return_value=mock_resp):
        result = await client.create_zone("example.com")

    assert result["zone_id"] == "zone-abc-123"
    assert result["nameservers"] == ["ns1.cloudflare.com", "ns2.cloudflare.com"]


async def test_create_zone_raises_on_error(client):
    """create_zone should raise CloudflareError when API returns success=false."""
    mock_resp = _mock_response(
        {
            "success": False,
            "errors": [{"code": 1061, "message": "Zone already exists"}],
        }
    )
    with patch.object(client._client, "post", new_callable=AsyncMock, return_value=mock_resp):
        with pytest.raises(CloudflareError, match="already exists"):
            await client.create_zone("example.com")


async def test_create_dns_token_returns_token_string(client):
    """create_dns_token should return the token value string."""
    mock_resp = _mock_response(
        {
            "success": True,
            "result": {
                "id": "token-id-456",
                "value": "cf-dns-token-secret-value",
                "name": "InstaDomain DNS - example.com",
            },
        }
    )
    with patch.object(client._client, "post", new_callable=AsyncMock, return_value=mock_resp):
        token = await client.create_dns_token("zone-abc-123", "example.com")

    assert token == "cf-dns-token-secret-value"


async def test_delete_zone_succeeds(client):
    """delete_zone should not raise on a successful response."""
    mock_resp = _mock_response({"success": True, "result": {"id": "zone-abc-123"}})
    with patch.object(client._client, "delete", new_callable=AsyncMock, return_value=mock_resp):
        await client.delete_zone("zone-abc-123")


async def test_delete_zone_raises_on_error(client):
    """delete_zone should raise CloudflareError on failure."""
    mock_resp = _mock_response(
        {
            "success": False,
            "errors": [{"code": 7003, "message": "Could not route to /zones/bad-id"}],
        }
    )
    with patch.object(client._client, "delete", new_callable=AsyncMock, return_value=mock_resp):
        with pytest.raises(CloudflareError):
            await client.delete_zone("bad-id")
