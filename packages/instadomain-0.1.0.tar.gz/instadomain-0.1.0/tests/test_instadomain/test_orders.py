import pytest

from instadomain.orders import (
    create_order,
    get_order,
    get_order_by_stripe_session,
    update_order_status,
)


pytestmark = pytest.mark.asyncio


async def test_create_order_returns_pending(test_db):
    """create_order should return an order with ord_ prefix and pending_payment status."""
    order = await create_order(
        test_db,
        domain="example",
        tld="com",
        amount_cents=1099,
        stripe_session_id="cs_test_abc",
    )
    assert order["id"].startswith("ord_")
    assert order["status"] == "pending_payment"
    assert order["domain"] == "example"
    assert order["tld"] == "com"
    assert order["amount_cents"] == 1099


async def test_get_order_returns_created(test_db):
    """get_order should return the order that was created."""
    created = await create_order(
        test_db,
        domain="test",
        tld="dev",
        amount_cents=1499,
        stripe_session_id="cs_test_get",
    )
    fetched = await get_order(test_db, created["id"])
    assert fetched is not None
    assert fetched["id"] == created["id"]
    assert fetched["domain"] == "test"


async def test_get_order_not_found(test_db):
    """get_order should return None for a nonexistent order."""
    result = await get_order(test_db, "ord_nonexistent")
    assert result is None


async def test_valid_transition(test_db):
    """pending_payment -> registering should succeed."""
    order = await create_order(
        test_db,
        domain="transition",
        tld="com",
        amount_cents=1099,
        stripe_session_id="cs_test_transition",
    )
    updated = await update_order_status(test_db, order["id"], "registering")
    assert updated["status"] == "registering"
    assert updated["updated_at"] is not None


async def test_invalid_transition_raises(test_db):
    """pending_payment -> complete should raise ValueError."""
    order = await create_order(
        test_db,
        domain="invalid",
        tld="com",
        amount_cents=1099,
        stripe_session_id="cs_test_invalid",
    )
    with pytest.raises(ValueError, match="Invalid transition"):
        await update_order_status(test_db, order["id"], "complete")


async def test_duplicate_stripe_session_raises(test_db):
    """Creating two orders with the same stripe_session_id should raise."""
    await create_order(
        test_db,
        domain="dup1",
        tld="com",
        amount_cents=1099,
        stripe_session_id="cs_test_dup",
    )
    with pytest.raises(Exception):
        await create_order(
            test_db,
            domain="dup2",
            tld="com",
            amount_cents=1099,
            stripe_session_id="cs_test_dup",
        )
