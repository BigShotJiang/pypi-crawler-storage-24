import pytest
from cryptography.fernet import Fernet, InvalidToken

from instadomain.encryption import decrypt, encrypt


def test_roundtrip(fernet_key):
    """Encrypting then decrypting should return the original plaintext."""
    original = "hello-instadomain-secret-data"
    ciphertext = encrypt(original, fernet_key)
    assert ciphertext != original
    assert decrypt(ciphertext, fernet_key) == original


def test_wrong_key_raises(fernet_key):
    """Decrypting with a different key should raise InvalidToken."""
    ciphertext = encrypt("sensitive", fernet_key)
    wrong_key = Fernet.generate_key().decode()
    with pytest.raises(InvalidToken):
        decrypt(ciphertext, wrong_key)
