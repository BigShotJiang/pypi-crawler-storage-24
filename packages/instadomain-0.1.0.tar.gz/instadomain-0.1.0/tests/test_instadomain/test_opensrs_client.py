from unittest.mock import patch

import httpx
import pytest

from instadomain.opensrs_client import OpenSRSClient, OpenSRSError


@pytest.fixture
def client():
    return OpenSRSClient(
        api_key="test-key",
        reseller_username="test-reseller",
        api_url="https://test.opensrs.net:55443",
    )


def _make_response(xml_text: str) -> httpx.Response:
    """Build a fake httpx.Response with the given XML body."""
    return httpx.Response(status_code=200, text=xml_text)


PRICE_RESPONSE_XML = """\
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!DOCTYPE OPS_envelope SYSTEM "ops.dtd">
<OPS_envelope>
<header><version>0.9</version></header>
<body>
<data_block>
<dt_assoc>
<item key="protocol">XCP</item>
<item key="action">REPLY</item>
<item key="response_code">200</item>
<item key="is_success">1</item>
<item key="response_text">Command Successful</item>
<item key="attributes">
<dt_assoc>
<item key="price">8.90</item>
</dt_assoc>
</item>
</dt_assoc>
</data_block>
</body>
</OPS_envelope>
"""

REGISTER_SUCCESS_XML = """\
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!DOCTYPE OPS_envelope SYSTEM "ops.dtd">
<OPS_envelope>
<header><version>0.9</version></header>
<body>
<data_block>
<dt_assoc>
<item key="protocol">XCP</item>
<item key="action">REPLY</item>
<item key="response_code">200</item>
<item key="is_success">1</item>
<item key="response_text">Registration Successful</item>
<item key="attributes">
<dt_assoc>
<item key="id">12345678</item>
<item key="registration_expiration_date">2027-03-15 00:00:00</item>
</dt_assoc>
</item>
</dt_assoc>
</data_block>
</body>
</OPS_envelope>
"""

REGISTER_FAILURE_XML = """\
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!DOCTYPE OPS_envelope SYSTEM "ops.dtd">
<OPS_envelope>
<header><version>0.9</version></header>
<body>
<data_block>
<dt_assoc>
<item key="protocol">XCP</item>
<item key="action">REPLY</item>
<item key="response_code">485</item>
<item key="is_success">0</item>
<item key="response_text">Domain already registered</item>
</dt_assoc>
</data_block>
</body>
</OPS_envelope>
"""


def test_get_price_parses_response(client):
    """get_price should parse the XML price and return cents."""
    with patch.object(client, "_post", return_value=_make_response(PRICE_RESPONSE_XML)):
        price = client.get_price("example.com")
    assert price == 890


def test_register_parses_success(client):
    """register should parse order_id and expiry from a success response."""
    with patch.object(
        client, "_post", return_value=_make_response(REGISTER_SUCCESS_XML)
    ):
        result = client.register(
            domain="example.com",
            years=1,
            registrant_email="user@example.com",
            nameservers=["ns1.cloudflare.com", "ns2.cloudflare.com"],
        )
    assert result["order_id"] == "12345678"
    assert result["expiry"] == "2027-03-15 00:00:00"


def test_register_failure_raises(client):
    """register should raise OpenSRSError on API failure."""
    with patch.object(
        client, "_post", return_value=_make_response(REGISTER_FAILURE_XML)
    ):
        with pytest.raises(OpenSRSError) as exc_info:
            client.register(
                domain="taken.com",
                years=1,
                registrant_email="user@example.com",
                nameservers=["ns1.cloudflare.com"],
            )
    assert exc_info.value.code == 485
    assert "already registered" in exc_info.value.message


def test_sign_produces_double_md5(client):
    """_sign should produce md5(md5(body + key) + key)."""
    import hashlib

    body = "<test>xml</test>"
    inner = hashlib.md5((body + "test-key").encode()).hexdigest()
    expected = hashlib.md5((inner + "test-key").encode()).hexdigest()
    assert client._sign(body) == expected
