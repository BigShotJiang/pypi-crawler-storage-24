"""
tests/test_integration.py

Integration tests that hit live RDAP endpoints.
Run with: python -m pytest tests/test_integration.py -v

Requires internet access. No mocks. Uses:
  - google.com        -> known-taken .com domain
  - cloudflare.com    -> taken, well-known registrar info
  - python.org        -> taken .org domain (PIR RDAP)
  - xyzrandomtest12345.com -> very likely available
"""
from __future__ import annotations

import asyncio
import os
import tempfile

import pytest

# Make sure we can import from the project root
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from domain_lookup import check_domain, check_domains, DomainResult
from affiliate import add_affiliate_links, build_register_urls
from analytics import log_check, log_link_served, log_click, get_stats
from config import settings


# ---------------------------------------------------------------------------
# domain_lookup tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_google_com_is_taken():
    result = await check_domain("google.com")
    assert isinstance(result, DomainResult)
    assert result.domain == "google.com"
    assert result.available is False
    assert result.checked_at  # non-empty ISO timestamp


@pytest.mark.asyncio
async def test_google_com_has_registrar():
    result = await check_domain("google.com")
    assert result.registrar is None or "RDAP error" not in str(result.registrar)


@pytest.mark.asyncio
async def test_google_com_has_dates():
    result = await check_domain("google.com")
    assert result.created is not None
    assert result.expires is not None


@pytest.mark.asyncio
async def test_cloudflare_com_is_taken():
    result = await check_domain("cloudflare.com")
    assert result.available is False
    assert result.domain == "cloudflare.com"


@pytest.mark.asyncio
async def test_random_domain_is_available():
    result = await check_domain("xyzrandomtest12345.com")
    assert isinstance(result, DomainResult)
    assert result.domain == "xyzrandomtest12345.com"
    assert result.available is True


@pytest.mark.asyncio
async def test_available_domain_has_no_registrar():
    result = await check_domain("xyzrandomtest12345.com")
    assert result.registrar is None


@pytest.mark.asyncio
async def test_available_domain_has_no_dates():
    result = await check_domain("xyzrandomtest12345.com")
    assert result.created is None
    assert result.expires is None


@pytest.mark.asyncio
async def test_available_domain_has_no_nameservers():
    result = await check_domain("xyzrandomtest12345.com")
    assert result.nameservers is None


@pytest.mark.asyncio
async def test_python_org_is_taken():
    """Uses PIR RDAP (org TLD)."""
    result = await check_domain("python.org")
    assert result.available is False
    assert result.domain == "python.org"


@pytest.mark.asyncio
async def test_pir_rdap_returns_dates():
    result = await check_domain("python.org")
    assert result.created is not None


@pytest.mark.asyncio
async def test_example_net_is_taken():
    """Regression test: .net domains must use /net/v1/ on Verisign RDAP, not /com/v1/."""
    result = await check_domain("example.net")
    assert result.available is False
    assert result.domain == "example.net"
    assert result.created is not None


@pytest.mark.asyncio
async def test_bulk_returns_correct_count():
    domains = ["google.com", "xyzrandomtest12345.com", "cloudflare.com"]
    results = await check_domains(domains)
    assert len(results) == 3


@pytest.mark.asyncio
async def test_bulk_identifies_taken_and_available():
    domains = ["google.com", "xyzrandomtest12345.com"]
    results = await check_domains(domains)
    by_domain = {r.domain: r for r in results}
    assert by_domain["google.com"].available is False
    assert by_domain["xyzrandomtest12345.com"].available is True


@pytest.mark.asyncio
async def test_bulk_concurrency_does_not_corrupt_results():
    """Run 15 domains to exercise the semaphore (limit=10)."""
    domains = [f"testdomain{i}9999xyzabc.com" for i in range(15)]
    results = await check_domains(domains)
    assert len(results) == 15
    for r in results:
        assert isinstance(r, DomainResult)
        assert r.domain in domains


# ---------------------------------------------------------------------------
# affiliate tests
# ---------------------------------------------------------------------------


def test_build_register_urls_dynadot():
    urls = build_register_urls("coolbrand.com")
    assert "dynadot" in urls
    assert "coolbrand.com" in urls["dynadot"]
    assert "dynadot.com" in urls["dynadot"]


@pytest.mark.asyncio
async def test_add_affiliate_links_available_domain():
    result = await check_domain("xyzrandomtest12345.com")
    enriched = add_affiliate_links(result)
    assert enriched.register_urls is not None
    assert "dynadot" in enriched.register_urls


@pytest.mark.asyncio
async def test_add_affiliate_links_taken_domain():
    result = await check_domain("google.com")
    enriched = add_affiliate_links(result)
    assert enriched.register_urls is None


def test_affiliate_ids_in_url():
    urls = build_register_urls("test.com")
    dy_id = settings.dynadot_affiliate_id
    assert dy_id in urls["dynadot"]


# ---------------------------------------------------------------------------
# analytics tests
# ---------------------------------------------------------------------------


@pytest.fixture
def tmp_db(tmp_path, monkeypatch):
    """Redirect analytics to a temp DB for each test."""
    db = str(tmp_path / "test_analytics.db")
    monkeypatch.setattr(settings, "db_path", db)
    return db


@pytest.mark.asyncio
async def test_log_check_and_get_stats(tmp_db):
    await log_check("example.com", available=False, source="api")
    await log_check("xyzavail.com", available=True, source="mcp")
    stats = await get_stats(days=1)
    assert stats["total_checks"] == 2
    assert stats["available_checks"] == 1
    assert stats["taken_checks"] == 1


@pytest.mark.asyncio
async def test_log_link_served(tmp_db):
    await log_link_served("xyzavail.com", "dynadot", source="api")
    stats = await get_stats(days=1)
    assert stats["links_served"] == 1


@pytest.mark.asyncio
async def test_log_click(tmp_db):
    await log_click("xyzavail.com", "dynadot")
    await log_click("xyzavail.com", "dynadot")
    stats = await get_stats(days=1)
    assert stats["clicks"] == 2


@pytest.mark.asyncio
async def test_click_through_rate(tmp_db):
    await log_link_served("d.com", "dynadot", "api")
    await log_link_served("d.com", "dynadot", "api")
    await log_click("d.com", "dynadot")
    stats = await get_stats(days=1)
    assert stats["click_through_rate"] == 0.5


@pytest.mark.asyncio
async def test_stats_empty_db(tmp_db):
    stats = await get_stats(days=30)
    assert stats["total_checks"] == 0
    assert stats["click_through_rate"] == 0.0


@pytest.mark.asyncio
async def test_top_domains_appear_in_stats(tmp_db):
    await log_check("popular.com", available=False, source="api")
    await log_check("popular.com", available=False, source="mcp")
    stats = await get_stats(days=1)
    domains = [entry["domain"] for entry in stats["top_domains"]]
    assert "popular.com" in domains
