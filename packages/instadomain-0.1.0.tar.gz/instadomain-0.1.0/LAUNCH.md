# Launch Checklist

Step-by-step playbook for going live. Work top to bottom.

---

## Pre-Launch (Technical)

### 1. Register the domain

- [ ] Check availability: https://www.namecheap.com/domains/registration/results/?domain=domaincheckr
- [ ] Alternatives if taken: `checkdomain.tools`, `domaincheckr.io`, `domainavail.com`, `rdapcheck.com`
- Recommended registrar: **Porkbun** (https://porkbun.com) — cheapest .com (~$9/year), developer-friendly
- Fallback: **Namecheap** (https://namecheap.com) — ~$10/year

### 2. Deploy to Railway

Full instructions: see `railway-deploy.md`. Quick version:

```bash
npm i -g @railway/cli
railway login
railway init   # name: domain-checker
railway up     # deploys API service
```

Railway generates a URL like `https://domain-checker-production.up.railway.app`. HTTPS is automatic — no certbot needed.

- [ ] `curl https://<railway-url>/health` returns `{"status": "ok"}`
- [ ] `curl https://<railway-url>/check/dinkhub.com` returns JSON with `available: true` and affiliate links

### 3. Deploy MCP service on Railway

In the Railway dashboard, add a second service from the same repo with start command override:

```
python3 mcp_server.py --http
```

- [ ] `curl https://<mcp-railway-url>/mcp/` returns 200

### 4. Set affiliate IDs

```bash
railway variables set NAMECHEAP_AFFILIATE_ID=YOUR_ID
railway variables set PORKBUN_AFFILIATE_ID=YOUR_ID
```

Set these on both the API service and the MCP service after affiliate approvals (see section below).

### 5. Point custom domain to Railway (optional)

```bash
railway domain
# Follow prompts; set CNAME in your registrar DNS panel
```

- [ ] Wait for propagation (5–30 min). Verify: `dig +short domaincheckr.com`

### 6. Update config files with live URLs

Replace `domaincheckr.com` placeholders in these files with your actual Railway URLs (or custom domain if set):

- `gpt/openapi.yaml` — API service URL
- `claude/claude-desktop-remote.json` — MCP service URL
- `claude/cursor-config.json` — MCP service URL
- `claude/windsurf-config.json` — MCP service URL

Fill in affiliate IDs after approvals (see section below).

---

## Affiliate Programs (Apply Day 1 — don't wait for deploy)

Apply to all four simultaneously. Approvals take 1–7 days. You need at least one live before the tool has real value.

### Namecheap Affiliates (Primary)

- [ ] Apply: https://www.namecheap.com/affiliates/
- Commission: up to $5 per .com registration, 30-day cookie
- Approval time: 1–3 business days (manual review)
- **"How will you promote" field — paste this:**
  > I'm running a domain availability checker tool integrated as a ChatGPT GPT and a Claude Desktop Extension. When users check domain availability via AI assistants, the tool returns results with Namecheap registration links. The tool is used inside ChatGPT (GPT Store) and Claude Desktop, with no separate website — clicks come directly from AI assistant sessions with high purchase intent.
- After approval: add ID to `.env` as `NAMECHEAP_AFFILIATE_ID`

### Porkbun Affiliates (Secondary)

- [ ] Apply: https://porkbun.com/affiliates
- Commission: $2–3 per registration, 30-day cookie
- Approval time: 2–5 business days
- **"How will you promote" field — paste this:**
  > I operate a domain availability checker integrated as a Claude Desktop Extension and ChatGPT GPT Store tool. When a user asks an AI assistant about domain availability, the tool queries RDAP in real time and returns results with Porkbun registration links. No website — all distribution is through AI assistant integrations.
- After approval: add ID to `.env` as `PORKBUN_AFFILIATE_ID`

### GoDaddy via CJ Affiliate

- [ ] Create CJ account: https://www.cj.com (click "Publisher Sign Up")
- [ ] Search for GoDaddy program inside CJ dashboard and apply
- Commission: $5–10 per registration, 45-day cookie
- Approval time: 3–7 business days (GoDaddy reviews separately inside CJ)
- **Application notes field:**
  > AI assistant integration — domain availability checker tool running as a ChatGPT GPT and Claude MCP extension. High-intent traffic: users are actively searching for available domains to register.
- After approval: grab affiliate link template from CJ and add to `affiliate.py`

### Dynadot Affiliates

- [ ] Apply: https://www.dynadot.com/affiliates.html
- Commission: $5 per new account + $0.50 per domain transfer, 45-day cookie
- Approval time: 2–5 business days
- **"How will you promote" field:**
  > Domain availability checker integrated into ChatGPT and Claude AI assistants. Users ask about domain availability, get real-time results with registration links. Traffic is high-intent — users are actively looking to register domains.
- After approval: add link template to `affiliate.py`

### After Any Approval

- [ ] Set the new affiliate ID on Railway: `railway variables set <VAR>=<value>` (Railway auto-restarts)
- [ ] Test end-to-end: check an available domain via `curl https://<your-url>/check/sometestdomain123456.com` — confirm affiliate links appear in response with correct tracking parameters
- [ ] Click a link, verify it 302-redirects to the registrar and sets a cookie

---

## ChatGPT GPT Store (Phase 2)

- [ ] Go to https://chatgpt.com/gpts/editor (requires ChatGPT Plus or higher)
- [ ] **Name:** `Domain Checker`
- [ ] **Description** (shown in GPT Store search results):
  > Check if any domain name is available for registration. Instant results with registration links. Suggests creative alternatives if your first choice is taken.
- [ ] **System prompt:** copy from `gpt/system-prompt.txt`
- [ ] **Add Action:**
  - Click "Add actions"
  - Import from URL: `https://domaincheckr.com/openapi.json`
  - Or manually upload `gpt/openapi.yaml`
  - Authentication: None
- [ ] **Conversation starters** (add all four):
  - `Is mycoolstartup.com available?`
  - `Check these 5 domains for me: ...`
  - `I'm building a fitness app. Find me available domain names.`
  - `What domains are available for a SaaS called Taskly?`
- [ ] **Privacy policy URL:** `https://domaincheckr.com/privacy` (create a simple static page or add a `/privacy` route returning plain text)
- [ ] **Test before publishing:**
  - Ask: "Is dinkhub.com available?" — verify it calls the action and returns affiliate links
  - Ask: "Find domain names for a recipe app" — verify bulk suggestions work
- [ ] Set visibility to **Public**
- [ ] Publish
- [ ] Copy GPT URL (format: `https://chatgpt.com/g/g-XXXXX-domain-checker`) — save it for sharing

---

## Claude Distribution (Phase 3)

### Test local MCP (stdio)

- [ ] Edit `claude/claude-desktop-local.json`: replace `/path/to/domain-checker` with actual path
- [ ] Merge into `~/Library/Application Support/Claude/claude_desktop_config.json`
- [ ] Restart Claude Desktop
- [ ] Ask Claude: "Is dinkhub.com available?" — confirm it calls the tool and returns affiliate links

### Test remote MCP (streamable-HTTP)

- [ ] Merge `claude/claude-desktop-remote.json` into Claude Desktop config (points to `https://domaincheckr.com/mcp/`)
- [ ] Restart Claude Desktop, repeat the same domain check test

### Submit to Anthropic Extensions Directory

- [ ] Fill out interest form: https://www.anthropic.com/extensions (check for current form URL — Anthropic updates this)
- **What to include in the submission:**
  - Name: Domain Checker
  - Description: Real-time domain availability checker via RDAP. Checks single domains, bulk lists, and generates domain ideas from keywords. Returns affiliate registration links for available domains.
  - MCP server URL: `https://domaincheckr.com/mcp/`
  - Tools exposed: `check_domain`, `check_domains_bulk`, `suggest_domains`
  - Transport: Streamable HTTP
  - Auth: None (public)
  - Use case: Any user who wants to find and register a domain name
- [ ] Monitor email for acceptance confirmation (can take 1–4 weeks)

### Add as Connector on claude.ai

- [ ] Go to https://claude.ai → Settings → Connectors → Add Custom Connector
- [ ] URL: `https://domaincheckr.com/mcp/`
- [ ] Name: Domain Checker
- [ ] Test via the claude.ai web interface

### Publish config snippets for other MCP clients

- [ ] Post `claude/cursor-config.json` and `claude/windsurf-config.json` to the GitHub repo README
- [ ] Share on Reddit: r/cursor_ai, r/windsurf
- Message to use:
  > Added a zero-config domain availability checker MCP server. Works in Cursor, Windsurf, Claude Desktop. Checks via RDAP (no API key). Config: [link to repo]

---

## Post-Launch Monitoring

### Daily stats check

```bash
# Run locally (SQLite lives in the Railway service's ephemeral filesystem; for persistence
# consider mounting a Railway Volume or pulling the DB via railway run):
railway run python3 stats.py
```

### Stats dashboard

```bash
python3 stats_dashboard.py
# Opens at http://localhost:8085
```

Watch:
- [ ] Total checks per day (target: 100+ by end of week 1)
- [ ] Available vs taken ratio (expect ~30% available)
- [ ] Affiliate link click count
- [ ] Source breakdown (mcp vs api)

### External dashboards

- [ ] GPT Store analytics: https://chatgpt.com/gpts/editor → select your GPT → Analytics tab
  - Track: conversations started, messages sent
- [ ] Namecheap affiliate dashboard: https://affiliate.namecheap.com
- [ ] CJ Affiliate (GoDaddy): https://members.cj.com
- [ ] Porkbun affiliate: https://porkbun.com/affiliates/dashboard

### First-week targets

| Metric | Target |
|--------|--------|
| Daily checks | 100+ |
| GPT Store conversations | 50+ |
| Affiliate link clicks | 5+ |
| Uptime | 100% |

---

## Growth (Month 2+)

- **SEO landing page:** Add a `/` route or static `index.html` at `domaincheckr.com` explaining the tool. Target keywords: "domain availability checker", "check domain name free"
- **Product Hunt:** Launch when daily checks hit 1,000+. Category: Developer Tools
- **Reddit posts:**
  - r/ChatGPT: "I built a domain checker GPT that actually suggests alternatives"
  - r/ClaudeAI: "Free domain availability MCP server — works in Claude Desktop, Cursor, Windsurf"
  - r/EntrepreneurRideAlong: "Side project update: domain checker affiliate tool"
- **More TLDs:** Add `.io`, `.ai`, `.dev`, `.co` RDAP endpoints to `domain_lookup.py` — high-demand TLDs worth checking
- **More registrars:** Add Spaceship (https://spaceship.com/affiliates, $1–3/reg) once the others are live
- **RDAP cache:** Add 5-minute TTL cache in `domain_lookup.py` once daily volume exceeds 10,000 checks
- **A/B test link format:** Try "Register at Namecheap →" vs inline markdown vs end-of-message summary to find highest click-through format
