"""
agentsflow — Production Loader
===============================
Minimal PROD API: load agents from a directory and get ready-to-use Agent objects.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from dotenv import load_dotenv

if TYPE_CHECKING:
    from agentsflow.agent import Agent
    from agentsflow.config import AgentsFlowConfig

logger = logging.getLogger(__name__)


def load_agents(
    agents_dir: str,
    env_path: Optional[str] = None,
    config: Optional["AgentsFlowConfig"] = None,
) -> dict[str, "Agent"]:
    """
    Load all agents from a directory and return a dict of Agent instances.

    This is the **single entry point** for production use.

    Args:
        agents_dir:  Path to the agents root directory (contains ``config/agents.yaml``
                     and ``agents/`` subdirectory with per-agent configs).
        env_path:    Optional path to a ``.env`` file. If provided, environment
                     variables are loaded from it before resolving API keys.
        config:      Optional SDK-wide config for log level, network logger silencing,
                     and log format. If provided, applies log_level and optionally
                     silence_network_loggers.

    Returns:
        Dict mapping agent name → ``Agent`` instance, ready to call ``.run()``.

    Example::

        from agentsflow import load_agents

        agents = load_agents("/home/user/my_project/DEV")
        result = agents["analyzer"].run("Analyze this data")

        # With custom .env
        agents = load_agents("/path/to/project", env_path="/path/to/.env")
    """
    # Load .env file if provided
    if env_path:
        _load_env_file(env_path)

    # Apply SDK-wide config if provided
    if config is not None:
        from agentsflow.config import _apply_config
        _apply_config(config)

    from agentsflow.builder import build_agents
    return build_agents(Path(agents_dir))


def _load_env_file(env_path: str) -> None:
    """Load environment variables from a .env file using python-dotenv."""
    path = Path(env_path)
    if not path.exists():
        raise FileNotFoundError(f".env file not found: {path}")
    load_dotenv(env_path)
