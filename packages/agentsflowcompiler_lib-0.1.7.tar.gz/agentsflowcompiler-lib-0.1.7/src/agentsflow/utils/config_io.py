from __future__ import annotations

from pathlib import Path

import yaml

from agentsflow.errors import AgentsFlowConfigError
from agentsflow.utils.manifest_io import AGENT_CONFIG_FILE
from agentsflow.schema.agent_config_schema import AgentConfig
from agentsflow.utils.paths import normalize_agent_relative_path
from agentsflow.utils.audit import write_audit_entry


def _write_agent_config(agent_dir: Path, agent_config: AgentConfig) -> None:
    config_path = agent_dir / AGENT_CONFIG_FILE
    old_data = None
    if config_path.exists():
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                old_data = yaml.safe_load(f)
        except (OSError, yaml.YAMLError):
            old_data = None

    new_data = agent_config.model_dump(mode="json")
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            yaml.safe_dump(
                new_data,
                f,
                default_flow_style=False,
                allow_unicode=True,
                sort_keys=False,
            )
    except Exception as e:
        raise AgentsFlowConfigError(f"Failed to write agent config: {e}") from e

    if old_data is not None:
        write_audit_entry(agent_dir, agent_config, old_data, new_data)


def _read_agent_config(config_file: Path) -> AgentConfig:
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            config_data = yaml.safe_load(f)
    except Exception as e:
        raise AgentsFlowConfigError(
            f"Failed to read agent config at {config_file}: {e}"
        ) from e
    cfg = AgentConfig(**config_data)
    return cfg

