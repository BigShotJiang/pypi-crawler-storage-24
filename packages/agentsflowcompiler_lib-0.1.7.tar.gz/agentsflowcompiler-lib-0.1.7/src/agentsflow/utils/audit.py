"""
Audit log utilities for config-change tracking.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from agentsflow.constants import DEFAULT_AUDIT_LOGS_FILE
from agentsflow.schema.agent_config_schema import AgentConfig

logger = logging.getLogger(__name__)


def diff_dicts(old: Any, new: Any, path: str = "") -> List[Dict[str, Any]]:
    """Recursively diff two JSON-serializable values."""
    changes: List[Dict[str, Any]] = []

    if isinstance(old, dict) and isinstance(new, dict):
        all_keys = set(old) | set(new)
        for key in sorted(all_keys):
            child_path = f"{path}.{key}" if path else key
            if key not in old:
                changes.append({"field": child_path, "old": None, "new": new[key]})
            elif key not in new:
                changes.append({"field": child_path, "old": old[key], "new": None})
            else:
                changes.extend(diff_dicts(old[key], new[key], child_path))
    elif isinstance(old, list) and isinstance(new, list):
        if old != new:
            changes.append({"field": path, "old": old, "new": new})
    elif old != new:
        changes.append({"field": path or "<root>", "old": old, "new": new})

    return changes


def write_audit_entry(
    agent_dir: Path,
    agent_config: AgentConfig,
    old_data: Dict[str, Any],
    new_data: Dict[str, Any],
) -> None:
    """Append a config-change audit entry to the agent's audit-log store."""
    changes = diff_dicts(old_data, new_data)
    if not changes:
        return

    audit_dir = agent_dir / agent_config.logs_config.audit_logs_dir
    audit_path = audit_dir / DEFAULT_AUDIT_LOGS_FILE
    audit_dir.mkdir(parents=True, exist_ok=True)

    entries: List[Dict[str, Any]] = []
    if audit_path.exists():
        try:
            with open(audit_path, "r", encoding="utf-8") as f:
                entries = json.load(f)
        except (json.JSONDecodeError, Exception):
            entries = []

    entries.append(
        {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "agent_name": agent_config.identity.name,
            "agent_id": str(agent_config.identity.agent_id),
            "changes": changes,
        }
    )

    try:
        with open(audit_path, "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.warning("Failed to write audit log entry: %s", e)
