"""
Path utility helpers.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from agentsflow.constants import AGENTS_DIR


def to_relative(path: Optional[Path], agent_dir: Path) -> Optional[Path]:
    """
    Convert *path* to a path relative to *agent_dir*.

    - If *path* is already relative -> return as-is.
    - If *path* is absolute and inside *agent_dir* -> make relative.
    - If *path* is absolute but outside *agent_dir* -> keep absolute.
    - If *path* is None -> return None.
    """
    if path is None:
        return None
    path = Path(path)
    if path.is_absolute():
        try:
            return path.relative_to(agent_dir)
        except ValueError:
            return path
    return path


def resolve(path: Optional[Path], agent_dir: Path) -> Optional[Path]:
    """Return the absolute path for a (possibly relative) config path."""
    if path is None:
        return None
    path = Path(path)
    if path.is_absolute():
        return path
    return (agent_dir / path).resolve()


def normalize_agent_relative_path(path: Optional[Path], agent_dir: Path) -> Optional[Path]:
    """
    Normalize a config path to be relative to *agent_dir*.

    Rules:
    - Absolute paths inside *agent_dir* become relative.
    - Relative paths that start with the agent folder name are stripped.
    - Relative paths that start with ``agents/<agent_name>/`` are stripped.
    - Paths outside the agent directory are returned as-is.
    """
    if path is None:
        return None

    p = Path(path)
    agent_name = agent_dir.name
    parts = p.parts

    if p.is_absolute():
        try:
            return p.relative_to(agent_dir)
        except ValueError:
            return p

    if len(parts) >= 2 and parts[0] == AGENTS_DIR and parts[1] == agent_name:
        return Path(*parts[2:]) if len(parts) > 2 else Path(".")
    if len(parts) >= 1 and parts[0] == agent_name:
        return Path(*parts[1:]) if len(parts) > 1 else Path(".")
    return p
