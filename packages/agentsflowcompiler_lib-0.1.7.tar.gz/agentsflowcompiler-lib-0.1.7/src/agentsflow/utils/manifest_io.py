"""
Manifest helpers
================
Low-level read/write operations for the agents.yaml manifest file.

The manifest is a simple YAML file that maps agent UUIDs to their config
paths (relative to the project base directory).  All higher-level agent
CRUD operations delegate here for persistence.
"""
from __future__ import annotations

import yaml
from pathlib import Path
from uuid import UUID
from typing import Optional

from agentsflow.constants import AGENTS_DIR, AGENT_CONFIG_FILE, AGENT_MANIFEST_FILE, CONFIG_DIR
from agentsflow.errors import AgentsFlowConfigError
from agentsflow.schema.manifest_schema import AgentEntry, AgentsConfig
from pydantic import ValidationError


# ── Public helpers ────────────────────────────────────────────────────────────


def register_agent(base_dir: Path, agent_name: str, agent_id: UUID) -> None:
    """Append a new entry to the manifest."""
    manifest_path = base_dir / CONFIG_DIR / AGENT_MANIFEST_FILE
    manifest_path.parent.mkdir(parents=True, exist_ok=True)

    if manifest_path.exists():
        try:
            manifest = read_manifest(manifest_path)
        except (ValidationError, yaml.YAMLError):
            manifest = AgentsConfig(agents=[])
    else:
        manifest = AgentsConfig(agents=[])

    config_path = Path(AGENTS_DIR) / agent_name / AGENT_CONFIG_FILE
    manifest.agents.append(AgentEntry(id=agent_id, config_path=config_path))
    write_manifest(manifest_path, manifest)


def unregister_agent(base_dir: Path, agent_id: UUID) -> None:
    """Remove an entry from the manifest by agent UUID."""
    manifest_path = base_dir / CONFIG_DIR / AGENT_MANIFEST_FILE
    manifest = read_manifest(manifest_path)
    manifest.agents = [a for a in manifest.agents if a.id != agent_id]
    write_manifest(manifest_path, manifest)


def update_agent_path(base_dir: Path, old_path: Path, new_path: Path) -> bool:
    """
    Update the config_path for a manifest entry.

    Returns:
        ``True`` if the entry was found and updated, ``False`` otherwise.
    """
    manifest_path = base_dir / CONFIG_DIR / AGENT_MANIFEST_FILE
    manifest = read_manifest(manifest_path)
    for agent in manifest.agents:
        if agent.config_path == old_path:
            agent.config_path = new_path
            write_manifest(manifest_path, manifest)
            return True
    return False


def get_config_path_by_id(base_dir: Path, target_id: UUID) -> Optional[Path]:
    """Return the config_path for *target_id*, or ``None`` if not found."""
    manifest_path = base_dir / CONFIG_DIR / AGENT_MANIFEST_FILE
    manifest = read_manifest(manifest_path)
    for agent in manifest.agents:
        if agent.id == target_id:
            return agent.config_path
    return None


def read_manifest(manifest_path: Path) -> AgentsConfig:
    """Parse and return the manifest YAML."""
    try:
        with open(manifest_path, "r", encoding="utf-8") as f:
            return AgentsConfig(**yaml.safe_load(f))
    except Exception as e:
        raise AgentsFlowConfigError(
            f"Failed to read manifest at {manifest_path}: {e}"
        ) from e


def write_manifest(manifest_path: Path, manifest: AgentsConfig) -> None:
    """Serialise *manifest* to YAML."""
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with open(manifest_path, "w", encoding="utf-8") as f:
        yaml.dump(manifest.model_dump(mode="json"), f, sort_keys=False)

def _load_all_agents_from_manifest(base_dir: Path) -> list:
    from agentsflow.utils.config_io import _read_agent_config

    manifest_path = base_dir / CONFIG_DIR / AGENT_MANIFEST_FILE
    if not manifest_path.exists():
        raise FileNotFoundError(f"Agent manifest not found at {manifest_path}")
    manifest = read_manifest(manifest_path)
    agents = []
    for agent in manifest.agents:
        try:
            agents.append(_read_agent_config((base_dir / agent.config_path).resolve()))
        except Exception as e:
            raise AgentsFlowConfigError(
                f"Failed to read agent config at {(base_dir / agent.config_path).resolve()}: {e}"
            ) from e
    return agents
