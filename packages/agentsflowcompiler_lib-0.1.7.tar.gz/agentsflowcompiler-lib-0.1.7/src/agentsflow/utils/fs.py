"""
Filesystem helpers for agent directories and structured log storage.
"""

from __future__ import annotations

import shutil
from pathlib import Path

from agentsflow.constants import (
    DEFAULT_AUDIT_LOGS_FILE,
    DEFAULT_PROMPT_HISTORY_FILE,
    DEFAULT_RUN_HISTORY_FILE,
    DEFAULT_TOKEN_USAGE_FILE,
)
from agentsflow.errors import AgentsFlowConfigError
from agentsflow.schema.agent_config_schema import LogsConfig


def create_agent_dir(agent_dir: Path, logs_config: LogsConfig) -> None:
    """Create agent directory and seed the log storage structure."""
    try:
        agent_dir.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        raise FileExistsError(f"Agent directory already exists: {agent_dir}")
    except Exception as e:
        raise AgentsFlowConfigError(f"Failed to create agent directory: {e}") from e

    _ensure_log_storage(agent_dir, logs_config)


def reset_log_files(agent_dir: Path, logs_config: LogsConfig) -> None:
    """Reset all seeded structured log files to empty arrays."""
    _ensure_log_storage(agent_dir, logs_config, overwrite=True)


def delete_agent_dir(agent_dir: Path) -> None:
    try:
        shutil.rmtree(agent_dir)
    except Exception as e:
        raise AgentsFlowConfigError(f"Failed to delete agent directory: {e}") from e


def duplicate_agent_dir(base_dir: Path, source_dir: Path, new_dir_name: str, agents_dir: Path) -> None:
    new_dir = base_dir / agents_dir / new_dir_name
    if new_dir.exists():
        raise FileExistsError(f"Agent directory already exists: {new_dir}")
    try:
        shutil.copytree(source_dir, new_dir)
    except Exception as e:
        raise AgentsFlowConfigError(
            f"Failed to duplicate agent directory: {e}"
        ) from e


def rename_agent_dir(base_dir: Path, old_name: str, new_name: str, agents_dir: Path) -> None:
    old_dir = base_dir / agents_dir / old_name
    new_dir = base_dir / agents_dir / new_name
    if new_dir.exists():
        raise FileExistsError(f"Agent directory already exists: {new_dir}")
    try:
        old_dir.rename(new_dir)
    except Exception as e:
        raise AgentsFlowConfigError(f"Failed to rename agent directory: {e}") from e


def _ensure_log_storage(agent_dir: Path, logs_config: LogsConfig, overwrite: bool = False) -> None:
    try:
        file_map = {
            logs_config.run_history_dir: [DEFAULT_RUN_HISTORY_FILE],
            logs_config.audit_logs_dir: [DEFAULT_AUDIT_LOGS_FILE],
            logs_config.prompt_history_dir: [DEFAULT_PROMPT_HISTORY_FILE],
            logs_config.token_usage_dir: [DEFAULT_TOKEN_USAGE_FILE],
        }
        for log_dir_rel, filenames in file_map.items():
            if not log_dir_rel:
                continue
            log_dir = agent_dir / log_dir_rel
            log_dir.mkdir(parents=True, exist_ok=True)
            for filename in filenames:
                log_file = log_dir / filename
                if overwrite or not log_file.exists():
                    log_file.write_text("[]", encoding="utf-8")
    except Exception as e:
        raise AgentsFlowConfigError(f"Failed to seed log storage: {e}") from e
