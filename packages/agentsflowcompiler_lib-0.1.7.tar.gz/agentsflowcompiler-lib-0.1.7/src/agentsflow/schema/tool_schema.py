"""
Tool Parameter Schema
=====================
Single Responsibility: defines the structure of a tool's input parameters.
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, ConfigDict

class ToolParameterConfig(BaseModel):
    """Single parameter definition for a tool."""

    model_config = ConfigDict(extra="ignore")

    type: Literal["string", "number", "boolean", "array", "object", "integer", "any"] = Field(..., description="Parameter type")
    description: str = Field("", description="What this parameter does")
    required: bool = Field(False)
    default: Optional[Any] = None
    enum: Optional[List[Any]] = Field(None, description="Allowed values")

ToolParametersConfig = Dict[str, ToolParameterConfig]
"""Input parameters schema mapping parameter names to their definitions."""