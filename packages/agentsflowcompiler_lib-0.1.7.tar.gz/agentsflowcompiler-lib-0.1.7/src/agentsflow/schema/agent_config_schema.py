from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Optional, Literal, Union, TypedDict
from uuid import UUID, uuid4

from agentsflow.constants import (
    DEFAULT_PREPROCESS_FUNCTION_NAME,
    DEFAULT_POSTPROCESS_FUNCTION_NAME,
    DEFAULT_RUN_HISTORY_DIR,
    DEFAULT_PROMPT_HISTORY_DIR,
    DEFAULT_AUDIT_LOGS_DIR,
    DEFAULT_TOKEN_USAGE_DIR,
    DEFAULT_AGENT_TIMEOUT,
    DEFAULT_RETRY_MAX_ATTEMPTS,
    DEFAULT_RETRY_BASE_DELAY,
    DEFAULT_RETRY_MAX_DELAY,
)
from agentsflow.schema.tool_config_schema import Tool
from pydantic import BaseModel, Field, ConfigDict, field_validator, model_validator, SecretStr
from enum import Enum

# ALLOWED_CODE_EXTENSIONS FOR PRE AND POST PROCESSING
ALLOWED_CODE_EXTENSIONS = {
    ".py"
}
# --- Agent Models ---
class AgentIdentity(BaseModel):
    name: str = Field(
        ..., 
        min_length=1,
        max_length=50,
        pattern=r"^[a-zA-Z0-9_-]+$",
        description="Agent name (safe characters only, max 50 chars, at least one character)"
    )
    agent_id: UUID = Field(default_factory=uuid4, description="Unique node ID")
    description: str = Field("", description="Human-readable description")

class ApiKeyMethod(Enum):
    ENV_VAR = "env_var"
    FILE = "file"
    ENV_FILE = "env_file"


class RetryConfig(BaseModel):
    """Retry policy for LLM API calls. Only LLMRateLimitError and LLMServerError are retried."""
    max_attempts: int = Field(
        DEFAULT_RETRY_MAX_ATTEMPTS, ge=1, le=20, description="Maximum retry attempts"
    )
    base_delay: float = Field(
        DEFAULT_RETRY_BASE_DELAY, ge=0.1, le=120, description="Base delay in seconds for exponential backoff"
    )
    max_delay: float = Field(
        DEFAULT_RETRY_MAX_DELAY, ge=1, le=300, description="Maximum delay between retries in seconds"
    )


class ApiKeyConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    api_key: Optional[SecretStr] = Field(None, description="API key for the model")
    api_key_method: Optional[ApiKeyMethod] = Field(default=ApiKeyMethod.ENV_VAR, description="Method to get the API key")
    api_key_path: Optional[Path] = Field(None, description="Path to the API key file")
    api_key_variable: Optional[str] = Field(None, description="Variable to get the API key from the environment / file")


class AgentModelConfig(BaseModel):
    api_key_config: ApiKeyConfig = Field(default_factory=ApiKeyConfig, description="API key configuration")
    model: str = Field("gpt-4o", description="Model identifier")
    provider: Optional[str] = Field(None, description="openai, anthropic, google, ollama")
    temperature: float = Field(0.0, ge=0.0, le=2.0)
    max_tokens: Optional[int] = Field(None, gt=0)
    timeout: Optional[float] = Field(DEFAULT_AGENT_TIMEOUT, description="Timeout in seconds")
    retry_config: RetryConfig = Field(default_factory=RetryConfig, description="Retry policy for LLM API calls")
    @model_validator(mode='after')
    def auto_detect_provider(self) -> 'AgentModelConfig':
        """Auto-detect provider from model name via llm.factory if not set."""
        if self.provider:
            return self
        try:
            from agentsflow.llm.factory import detect_provider
            self.provider = detect_provider(self.model)
        except (ValueError, ImportError):
            raise ValueError(f"Could not auto-detect provider for model {self.model}")
        return self

class PromptConfig(BaseModel):
    instruction_path: Optional[Path] = None
    think_path: Optional[Path] = None
    return_path: Optional[Path] = None
    example_path: Optional[Path] = None
    next_model_rule_path: Optional[Path] = None

class Prompt(BaseModel):
    instruction: Optional[str] = None
    think: Optional[str] = None
    example: Optional[str] = None
    next_model_rule: Optional[str] = None
    return_prompt: Optional[str] = None

class ProcessingConfig(BaseModel):
    path: Path
    function_name: str = Field(..., pattern=r"^\S+$")

    @field_validator("path")
    @classmethod
    def validate_extension(cls, v: Path) -> Path:
        """
        Validates that the file extension is supported.
        Note: File existence is NOT checked here to allow for dynamic or deferred creation.
        It must be verified later at runtime before the file is actually used.
        """
        if v.suffix.lower() not in ALLOWED_CODE_EXTENSIONS:
            raise ValueError(
                f"File extension {v.suffix} is not supported. "
                f"Allowed extensions: {', '.join(ALLOWED_CODE_EXTENSIONS)}"
            )
        return v

class ReturnFormat(str, Enum):
    TEXT = "text"
    JSON = "json"
    JSON_OBJECT = "json_object"
    MARKDOWN = "markdown"

class OutputFormatConfig(BaseModel):
    return_format: ReturnFormat = Field(..., description="'json' / 'text' / 'markdown' / 'json_object'")
    json_schema_path: Optional[Path] = None

# --- Agent Config ---


class AgentConfigYaml(TypedDict, total=False):
    """Expected shape of flat YAML config dict for AgentConfig.from_yaml()."""
    agent_id: UUID
    description: str
    model: str
    provider: Optional[str]
    temperature: float
    max_tokens: Optional[int]
    timeout: Optional[float]
    instruction_path: str
    think_path: str
    return_path: str
    example_path: str
    next_model_rule_path: str
    preprocess_path: str
    preprocess_function_name: str
    postprocess_path: str
    postprocess_function_name: str
    return_format: ReturnFormat
    json_schema_path: str
    run_history_dir: str
    audit_logs_dir: str
    prompt_history_dir: str
    token_usage_dir: str
    last_system_prompt_hash: Optional[str]
    api_key: Optional[str]
    api_key_method: Optional[str]
    api_key_path: Optional[str]
    api_key_variable: Optional[str]
    retry_config: Optional[Dict[str, Any]]
    tools: Optional[List[Any]]


class LogsConfig(BaseModel):
    run_history_dir: Path = Field(default=DEFAULT_RUN_HISTORY_DIR, description="Directory to store run history")
    audit_logs_dir: Path = Field(default=DEFAULT_AUDIT_LOGS_DIR, description="Directory to store audit logs")
    prompt_history_dir: Path = Field(default=DEFAULT_PROMPT_HISTORY_DIR, description="Directory to store prompt history")
    token_usage_dir: Path = Field(default=DEFAULT_TOKEN_USAGE_DIR, description="Directory to store token usage")
    last_system_prompt_hash: Optional[str] = None
class AgentConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")

    identity: AgentIdentity
    model_settings: AgentModelConfig
    prompt_config: PromptConfig
    preprocess_config: Optional[ProcessingConfig] = None
    postprocess_config: Optional[ProcessingConfig] = None
    output_format_config: Optional[OutputFormatConfig] = None
    tools: Optional[List[Tool]] = None
    logs_config: LogsConfig

    @classmethod
    def from_yaml(cls, name: str, data: AgentConfigYaml) -> AgentConfig:
        """
        Build an AgentConfig from a flat YAML dictionary.
        
        This handles the mapping from the flat structure expected in YAML files
        to the nested Pydantic models used internally.
        """
        identity = AgentIdentity(
            name=name,
            agent_id=data.get("agent_id") or uuid4(),
            description=data.get("description", ""),
        )

        model_registry_config = AgentModelConfig(
            model=data.get("model", "gpt-4o"),
            provider=data.get("provider"),
            temperature=data.get("temperature", 0.0),
            max_tokens=data.get("max_tokens"),
            timeout=data.get("timeout", DEFAULT_AGENT_TIMEOUT),
            api_key_config=ApiKeyConfig(
                api_key=data.get("api_key"),
                api_key_method=data.get("api_key_method") or ApiKeyMethod.ENV_VAR,
                api_key_path=Path(data["api_key_path"]) if data.get("api_key_path") else None,
                api_key_variable=data.get("api_key_variable"),
            ),
            retry_config=RetryConfig(**data["retry_config"]) if data.get("retry_config") else RetryConfig(),
        )

        prompt_config = PromptConfig(
            instruction_path=Path(data["instruction_path"]) if data.get("instruction_path") else None,
            think_path=Path(data["think_path"]) if data.get("think_path") else None,
            return_path=Path(data["return_path"]) if data.get("return_path") else None,
            example_path=Path(data["example_path"]) if data.get("example_path") else None,
            next_model_rule_path=Path(data["next_model_rule_path"]) if data.get("next_model_rule_path") else None,
        )

        preprocess = None
        if data.get("preprocess_path"):
            preprocess = ProcessingConfig(
                path=Path(data["preprocess_path"]),
                function_name=data.get("preprocess_function_name") or DEFAULT_PREPROCESS_FUNCTION_NAME,
            )

        postprocess = None
        if data.get("postprocess_path"):
            postprocess = ProcessingConfig(
                path=Path(data["postprocess_path"]),
                function_name=data.get("postprocess_function_name") or DEFAULT_POSTPROCESS_FUNCTION_NAME,
            )

        output_format = OutputFormatConfig(
            return_format=data.get("return_format") or ReturnFormat.TEXT,
            json_schema_path=Path(data["json_schema_path"]) if data.get("json_schema_path") else None,
        )

        logs_config = LogsConfig(
            run_history_dir=Path(data["run_history_dir"]) if data.get("run_history_dir") else DEFAULT_RUN_HISTORY_DIR,
            audit_logs_dir=Path(data["audit_logs_dir"]) if data.get("audit_logs_dir") else DEFAULT_AUDIT_LOGS_DIR,
            prompt_history_dir=Path(data["prompt_history_dir"]) if data.get("prompt_history_dir") else DEFAULT_PROMPT_HISTORY_DIR,
            token_usage_dir=Path(data["token_usage_dir"]) if data.get("token_usage_dir") else DEFAULT_TOKEN_USAGE_DIR,
            last_system_prompt_hash=data.get("last_system_prompt_hash"),
        )

        # Tools are handled by the loader/builder, but we can pass them if present
        tools = data.get("tools")

        return cls(
            identity=identity,
            model_settings=model_registry_config,
            prompt_config=prompt_config,
            preprocess_config=preprocess,
            postprocess_config=postprocess,
            output_format_config=output_format,
            logs_config=logs_config,
            tools=tools,
        )