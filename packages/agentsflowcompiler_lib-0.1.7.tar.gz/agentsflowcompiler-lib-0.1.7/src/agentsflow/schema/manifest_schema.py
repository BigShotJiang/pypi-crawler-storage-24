from pathlib import Path
from typing import List
from uuid import UUID
from pydantic import BaseModel

class AgentEntry(BaseModel):
    id: UUID
    config_path: Path

class AgentsConfig(BaseModel):
    agents: List[AgentEntry]