"""
Tool Config Schema
==================
Single Responsibility: defines a tool's full configuration and schema conversion.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, field_validator, ConfigDict

from agentsflow.types import AnthropicToolSchema, OpenAIToolSchema
from .tool_schema import ToolParameterConfig, ToolParametersConfig

class ToolReturnConfig(BaseModel):
    """
    Configuration for a tool's return value.
    """
    type: str = Field(..., description="Return value type")
    description: str = Field(..., description="Return value description")
    
class ToolIdentityConfig(BaseModel):
    """
    Configuration for a tool's identity.
    """
    tool_id: UUID = Field(default_factory=uuid4, description="Unique tool identifier")
    name: str = Field(..., description="Tool name, e.g. 'web_search', 'calculator'")
    description: str = Field(..., description="What this tool does")
    category: str = Field(..., description="Tool category, e.g. 'search', 'math'")


class ToolConfig(BaseModel):
    """
    Configuration for a tool that an agent can use.

    Two modes:
        - **built-in**: only ``name`` is needed; implementation lives in tools/{name}/
        - **custom**:   full definition with path, function_name, parameters, etc.
    """

    path: Optional[Path] = Field(None, description="Path to the Python module (.py)")
    function_name: Optional[str] = Field(None, description="Callable name in that module")
    parameters: Optional[ToolParametersConfig] = Field(None, description="Input parameters schema")
    returns: Optional[ToolReturnConfig] = Field(None, description="Return value description")

    @field_validator("path", mode="before")
    @classmethod
    def _coerce_path(cls, v: Any) -> Optional[Path]:
        if v is None or v == "" or v == "null":
            return None
        return Path(v)


class Tool(BaseModel):
    """
    Configuration for a tool that an agent can use.

    Two modes:
        - **built-in**: only ``name`` is needed; implementation lives in tools/{name}/
        - **custom**:   full definition with path, function_name, parameters, etc.
    """

    model_config = ConfigDict(extra="ignore")
    identity: ToolIdentityConfig = Field(..., description="Tool identity")
    custom: bool = Field(False, description="True = user-defined tool, False = built-in tool")

    config: Optional[ToolConfig] = Field(None, description="Tool config")

    def _build_params(self) -> tuple[Dict[str, Any], list[str]]:
        """Extract properties and required fields from tool parameters."""
        properties: Dict[str, Any] = {}
        required: list[str] = []
        params = (self.config.parameters if self.config else None) or {}
        for param_name, param in params.items():
            prop: Dict[str, Any] = {
                "type": param.type,
                "description": param.description,
            }
            if param.enum:
                prop["enum"] = param.enum
            properties[param_name] = prop
            if param.required:
                required.append(param_name)
        return properties, required

    def to_openai_schema(self) -> OpenAIToolSchema:
        """Convert to OpenAI function-calling format."""
        properties, required = self._build_params()
        return {
            "type": "function",
            "function": {
                "name": self.identity.name,
                "description": self.identity.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        }

    def to_anthropic_schema(self) -> AnthropicToolSchema:
        """Convert to Anthropic tool format."""
        properties, required = self._build_params()
        return {
            "name": self.identity.name,
            "description": self.identity.description,
            "input_schema": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        }
