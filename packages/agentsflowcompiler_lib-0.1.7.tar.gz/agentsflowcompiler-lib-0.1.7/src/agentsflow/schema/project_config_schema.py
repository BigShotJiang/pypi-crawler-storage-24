from typing import Optional, Literal, Union, Any, Dict
from pydantic import BaseModel, Field, ConfigDict, model_validator
from pathlib import Path


class IgnoreNoneBaseModel(BaseModel):
    @model_validator(mode='before')
    @classmethod
    def ignore_nones(cls, data: Any) -> Any:
        if isinstance(data, dict):
            return {k: v for k, v in data.items() if v is not None}
        return data

SecretStrategy = Union[Literal["project_local", "os_env", "custom"]]

class DirectoryConfig(IgnoreNoneBaseModel):
    dev: Path = Field(..., description="Absolute path to the DEV agents directory")
    prod: Optional[Path] = Field(default=None, description="Absolute path to the PROD agents directory")
    def update(self, dev: Optional[Path], prod: Optional[Path]) -> "DirectoryConfig":
        """
        Updates the class instance with the given values.
        """

        if dev is not None:
            self.dev = dev
        if prod is not None:
            self.prod = prod
        return self

class SecretEnvironmentConfig(IgnoreNoneBaseModel):
    strategy: str = Field(default="project_local", description="How to load secrets")
    custom_path: Optional[Path] = Field(default=None, description="Custom .env path")

    @model_validator(mode='after')
    def validate_custom_path(self):
        if self.strategy == "custom" and self.custom_path is None:
            raise ValueError("custom_path is required when strategy is 'custom'")
        return self
    def update(self, strategy: Optional[str], custom_path: Optional[Path]) -> "SecretEnvironmentConfig":
        """
        Updates the class instance with the given values.
        """

        if strategy is not None:
            self.strategy = strategy
        if custom_path is not None:
            self.custom_path = custom_path
        return self
class SecretsConfig(IgnoreNoneBaseModel):
    dev: SecretEnvironmentConfig = Field(..., description="DEV environment secrets configuration")
    prod: Optional[SecretEnvironmentConfig] = Field(default=None, description="PROD environment secrets configuration")
    def update(self, dev: Optional[SecretEnvironmentConfig], prod: Optional[SecretEnvironmentConfig]) -> "SecretsConfig":
        """
        Updates the class instance with the given values.
        """

        if dev is not None:
            self.dev = dev
        if prod is not None:
            self.prod = prod
        return self

class ProjectConfigSchema(IgnoreNoneBaseModel):
    model_config = ConfigDict(extra="ignore")

    project_name: str = Field(..., description="Human-readable project name")
    directories: DirectoryConfig = Field(..., description="Directory paths")
    secrets: SecretsConfig = Field(..., description="Secret management configuration")
    def update(self, project_name: Optional[str], directories: Optional[DirectoryConfig], secrets: Optional[SecretsConfig]) -> "ProjectConfigSchema":
        """
        Updates the class instance with the given values.
        """

        if project_name is not None:
            self.project_name = project_name
        if directories is not None:
            self.directories = directories
        if secrets is not None:
            self.secrets = secrets
        return self
class ProjectConfigEditSchema(IgnoreNoneBaseModel):
    model_config = ConfigDict(extra="ignore")

    project_name: Optional[str] = Field(default=None, description="Human-readable project name")
    directories: Optional[DirectoryConfig] = Field(default=None, description="Directory paths")
    secrets: Optional[SecretsConfig] = Field(default=None, description="Secret management configuration")
    