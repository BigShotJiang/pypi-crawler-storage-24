"""
Agent Utilities
===============
Shared helper functions used across the agent package:
file loading, dynamic function import, and token counting.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from typing import Any, Callable, Optional, Union

from tiktoken import encoding_for_model, get_encoding


# ── File Loading ─────────────────────────────────────────────


def load_file(path: Optional[Path]) -> Any:
    """
    Load a file and return its contents.

    Supports:
        .json  → parsed dict / list
        .md / .txt / .text → raw string

    Returns None if path is None.
    Raises FileNotFoundError / ValueError for missing / unsupported files.
    """
    if path is None:
        return None
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    suffix = path.suffix.lower()
    if suffix == ".json":
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    elif suffix in (".md", ".txt", ".text"):
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    else:
        raise ValueError(f"Unsupported file type: {suffix}")


def load_prompt(base_dir: Path, relative_path: Optional[Path]) -> Any:
    """Load a prompt file relative to a base directory."""
    if not relative_path:
        return None
    full_path = (base_dir / relative_path).resolve()
    if not full_path.is_relative_to(base_dir.resolve()):
        raise ValueError(f"Path traversal detected: '{relative_path}' escapes base directory.")
    return load_file(full_path)


# ── Dynamic Function Loading ────────────────────────────────


def _load_function(
    module_path: Union[str, Path],
    func_name: Optional[str],
) -> Callable[..., Any]:
    """
    Dynamically import a callable from a Python module.

    Args:
        module_path: Absolute path to a .py file, or a dotted module name.
        func_name:   Name of the callable inside the module.

    Returns:
        The callable object.
    """
    if not func_name:
        raise ValueError("func_name is required")
    if isinstance(module_path, Path):
        module_path = module_path.resolve()
        spec = importlib.util.spec_from_file_location(module_path.stem, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load module from file '{module_path}'")

        module = importlib.util.module_from_spec(spec)
        module_key = str(module_path)
        sys.modules[module_key] = module
        spec.loader.exec_module(module)
    else:
        module = importlib.import_module(module_path)

    func = getattr(module, func_name, None)
    if func is None:
        raise AttributeError(
            f"Module '{module.__name__}' has no attribute '{func_name}'"
        )
    if not callable(func):
        raise TypeError(
            f"Attribute '{func_name}' in module '{module.__name__}' is not callable"
        )
    return func


# ── Token Counting ───────────────────────────────────────────


def count_tokens(text: Optional[str], model: str = "o200k_base") -> int:
    """
    Count the number of tokens in *text* for the given *model*.

    NOTE: This uses tiktoken (OpenAI's tokenizer). For non-OpenAI models (Claude, Llama, Gemini),
    this is a pragmatic surrogate and may not be 100% accurate.
    For maximum accuracy, use the count_tokens() method on the respective LLMClient instance.

    Falls back to the ``o200k_base`` encoding when the model is unknown.
    """
    if text is None:
        return 0
    try:
        encoding = encoding_for_model(model)
    except KeyError:
        encoding = get_encoding("o200k_base")
    return len(encoding.encode(text))
