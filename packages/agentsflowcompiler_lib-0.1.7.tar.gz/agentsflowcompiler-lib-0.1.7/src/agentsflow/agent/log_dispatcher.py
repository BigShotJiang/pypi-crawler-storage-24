"""
Async Log Dispatcher
====================
Non-blocking, background-threaded file logger using the Producer-Consumer pattern.

Usage::

    dispatcher = AsyncLogDispatcher()
    dispatcher.enqueue(Path("/logs/run.jsonl"), {"key": "value"})
    ...
    dispatcher.shutdown()   # flush & join before process exit

Design notes:
  - One dispatcher per AgentStats instance (simple, no shared mutable state).
  - 100+ daemon threads are fine: they all sleep on queue.get() consuming ~0 CPU.
  - A failed write is *logged then skipped* — the worker never crashes or drops
    future entries due to one bad write.
  - Files are always opened in append mode ('a') — log lines are never overwritten.
  - Directories are created lazily inside the worker; __init__ touches no filesystem.
"""

from __future__ import annotations

import json
import logging
import queue
import threading
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Sentinel object used to signal the worker to stop.
_STOP = object()


class AsyncLogDispatcher:
    """
    Owns a single background thread that drains a queue and writes JSONL entries
    to disk in strict append mode.

    SRP: Responsible only for the mechanics of background file I/O.
    DIP: Callers depend on the `enqueue` / `shutdown` interface, not raw I/O.
    """

    def __init__(self) -> None:
        self._queue: queue.Queue[Any] = queue.Queue()
        self._thread = threading.Thread(
            target=self._worker,
            name="AsyncLogDispatcher",
            daemon=True,  # won't prevent process exit on its own
        )
        self._thread.start()

    # ── Public interface ──────────────────────────────────────

    def enqueue(self, path: Path, entry: Any) -> None:
        """
        Non-blocking; returns immediately.
        Pushes *(path, entry)* onto the queue for the background thread to write.
        """
        self._queue.put_nowait((path, entry))

    def shutdown(self, timeout: Optional[float] = 30.0) -> None:
        """
        Flush all pending log entries and stop the background thread.

        Call this on process exit or when the owning AgentStats is done.
        Blocks the calling thread for at most *timeout* seconds.
        """
        self._queue.put_nowait(_STOP)
        self._thread.join(timeout=timeout)
        if self._thread.is_alive():
            logger.warning("AsyncLogDispatcher: worker thread did not stop in time.")

    # ── Worker loop ───────────────────────────────────────────

    def _worker(self) -> None:
        """Drain the queue and write to disk, one entry at a time."""
        while True:
            item = self._queue.get()
            try:
                if item is _STOP:
                    return
                path, entry = item
                self._write(path, entry)
            except Exception as exc:  # noqa: BLE001 — never crash the worker
                logger.warning("AsyncLogDispatcher: unexpected error — %s", exc)
            finally:
                self._queue.task_done()

    @staticmethod
    def _write(path: Path, entry: Any) -> None:
        """Lazy mkdir + strict append-only write."""
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
