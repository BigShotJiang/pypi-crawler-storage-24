"""
Agent Tools
===========
Thin wrapper around ``ToolRegistry`` that encapsulates
tool loading and execution for a single agent.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from agentsflow.errors import AgentsFlowToolError
from agentsflow.logging_utils import log_structured
from agentsflow.tools import ToolRegistry, DEFAULT_BUILTINS_DIR
from agentsflow.schema.tool_config_schema import Tool
from agentsflow.types import (
    AnthropicToolSchema,
    OpenAIToolSchema,
    ToolCallLogEntry,
)

logger = logging.getLogger(__name__)


class AgentTools:
    """
    Manages the tool lifecycle for a single agent.

    Responsibilities:
        - Load built-in and custom tools via ``ToolRegistry``.
        - Provide OpenAI-compatible tool schemas for the LLM call.
        - Execute a tool by name and return the result.
        - Keep a per-run log of all tool calls made.
    """

    MAX_TOOL_ROUNDS = 10  # Safety limit for tool-calling loops

    def __init__(
        self,
        agent_dir: Path,
        tool_configs: List[Tool],
        tools_base_dir: Optional[Path] = None,
        ) -> None:
        """
        Args:
            agent_dir:       Resolved directory for this agent.
            tool_configs:    List of ``Tool`` objects (built-in and custom) from the agent's config.
            tools_base_dir:  Override for the built-in tools directory.
        """
        self._agent_dir = agent_dir
        self._registry = ToolRegistry(builtins_dir=tools_base_dir)

        if len(tool_configs) > 0:
            self._registry.load_agent_tools(tool_configs=tool_configs, agent_dir=agent_dir)

        # Per-run tool call log (reset on each run)
        self._call_log: list[ToolCallLogEntry] = []

    # ── Schemas ───────────────────────────────────────────────

    @property
    def has_tools(self) -> bool:
        return self._registry.has_tools()

    def get_schemas(
        self, provider: Optional[str] = None
    ) -> list[OpenAIToolSchema] | list[AnthropicToolSchema] | None:
        """Return provider-specific tool schemas, or None if no tools."""
        if not self.has_tools:
            return None
        if provider == "anthropic":
            return self._registry.get_anthropic_schemas()
        return self._registry.get_openai_schemas()

    # ── Execution ─────────────────────────────────────────────

    def execute(self, name: str, arguments: Dict[str, Any]) -> str:
        """
        Execute a tool and return the result as a string.

        The call is also appended to the internal call log.
        """
        try:
            result = self._registry.execute(name, arguments)
            result_str = (
                json.dumps(result, ensure_ascii=False)
                if not isinstance(result, str)
                else result
            )
        except Exception as e:
            result_str = f"Error executing {name}: {e}"
            log_structured(
                logging.ERROR,
                "tool_error",
                agent_name=self._agent_dir.name,
                tool_name=name,
                error=str(e),
            )
            self._call_log.append({
                "name": name,
                "arguments": arguments,
                "result": result_str,
            })
            raise AgentsFlowToolError(result_str) from e

        self._call_log.append({
            "name": name,
            "arguments": arguments,
            "result": result_str,
        })

        return result_str

    # ── Log Management ────────────────────────────────────────

    def reset_log(self) -> None:
        """Clear the tool call log (call at the start of each ``Agent.run``)."""
        self._call_log = []

    @property
    def call_log(self) -> list[ToolCallLogEntry]:
        """Return the current run's tool call log."""
        return self._call_log