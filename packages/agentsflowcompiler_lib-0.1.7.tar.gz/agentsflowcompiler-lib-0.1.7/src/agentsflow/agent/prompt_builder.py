"""
Prompt Builder
==============
Builds the final system prompt from prompt config files.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from agentsflow.schema import PromptConfig

from ._utils import load_prompt


def build_system_prompt(agent_dir: Path, prompt_config: Optional[PromptConfig]) -> Optional[str]:
    """Assemble the full system prompt from the configured prompt files."""
    parts: list[str] = []
    if prompt_config is None:
        return None

    if prompt_config.instruction_path:
        parts.append(
            "### SYSTEM INSTRUCTION\n" + str(load_prompt(agent_dir, prompt_config.instruction_path))
        )
    if prompt_config.think_path:
        parts.append(
            "### THINKING GUIDELINES\n" + str(load_prompt(agent_dir, prompt_config.think_path))
        )
    if prompt_config.example_path:
        parts.append(
            "### EXAMPLE\n" + str(load_prompt(agent_dir, prompt_config.example_path))
        )
    if prompt_config.next_model_rule_path:
        parts.append(
            "### NEXT MODEL HANDOFF RULES\n"
            + str(load_prompt(agent_dir, prompt_config.next_model_rule_path))
        )
    if prompt_config.return_path:
        parts.append(
            "### OUTPUT FORMAT\n" + str(load_prompt(agent_dir, prompt_config.return_path))
        )

    if parts:
        parts.insert(0, "### SYSTEM PROMPT\n")
        return "\n\n".join(parts)
    return None
