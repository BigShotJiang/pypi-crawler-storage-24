"""
Run Context
===========
Per-run state container for a single Agent.run() execution.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from agentsflow.types import ChatMessage, ToolCallLogEntry


@dataclass
class RunContext:
    rid: str
    user_prompt: str
    llm_input: str
    # User-defined preprocess output; type varies by user code
    preprocess_output: Any = None
    messages: list[ChatMessage] = field(default_factory=list)
    llm_raw_output: Optional[str] = None
    # Parsed JSON (dict) or raw str from LLM
    llm_output: str | dict[str, Any] | None = None
    # User-defined postprocess output; type varies by user code
    postprocess_output: Any = None
    # Canonical run result; often str but may be structured (user-defined)
    final_output: Any = None


@dataclass
class RunResult:
    """Result from Agent.run()."""
    output: str | dict[str, Any]
    rid: str
    token_input: int
    token_output: int
    tool_calls: list[ToolCallLogEntry]
