"""
Agent Stats & Logging
=====================
Handles all logging concerns for an agent:
    - Run history        (input, preprocess, tool calls, LLM output, postprocess)
    - Config audit logs  (config-change audit trail)
    - Prompt history     (tracks system-prompt changes via SHA-256 hash)
    - Token usage        (per-run token usage summary)

All disk I/O is delegated to an ``AsyncLogDispatcher`` that runs on a daemon
background thread.  Every call to ``log_io`` / ``log_system_prompt`` is
non-blocking and returns in microseconds.

Call ``stats.shutdown()`` (or let the process exit — the thread is a daemon)
when you need to guarantee that every queued line has been written before exit.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

import yaml

if TYPE_CHECKING:
    from agentsflow.llm import LLMClient

from agentsflow.types import TokensSummary
from agentsflow.constants import (
    AGENT_CONFIG_FILE,
    DEFAULT_AUDIT_LOGS_FILE,
    DEFAULT_PROMPT_HISTORY_FILE,
    DEFAULT_RUN_HISTORY_FILE,
    DEFAULT_TOKEN_USAGE_FILE,
)
from agentsflow.errors import AgentsFlowLogError
from agentsflow.schema import LogsConfig
from .log_dispatcher import AsyncLogDispatcher

logger = logging.getLogger(__name__)


class AgentStats:
    """
    Encapsulates all logging and token-tracking for a single agent.

    SOLID — SRP:
        Responsible only for *formatting* log entries, not physical I/O.
        Physical I/O is owned by ``AsyncLogDispatcher``.

    Usage::

        stats = AgentStats(agent_dir, client, logs_config)
        stats.log_system_prompt(system_prompt)   # non-blocking

        # After each run:
        stats.log_io(input_text=..., llm_output=..., ...)  # non-blocking

        # On graceful shutdown:
        stats.shutdown()
    """

    def __init__(self, agent_dir: Path, client: "LLMClient", logs_config: LogsConfig) -> None:
        self._agent_dir = agent_dir
        self._agent_name = agent_dir.name
        self._client = client
        self._model = client.model
        self._logs_config = logs_config
        self._last_prompt_hash: Optional[str] = logs_config.last_system_prompt_hash

        # ── Path constants (no I/O; directories created lazily by dispatcher) ──
        run_history_dir    = agent_dir / logs_config.run_history_dir
        audit_logs_dir     = agent_dir / logs_config.audit_logs_dir
        prompt_history_dir = agent_dir / logs_config.prompt_history_dir
        token_usage_dir    = agent_dir / logs_config.token_usage_dir

        self._run_history_file    = run_history_dir    / DEFAULT_RUN_HISTORY_FILE
        self._audit_log_file      = audit_logs_dir     / DEFAULT_AUDIT_LOGS_FILE
        self._prompt_history_file = prompt_history_dir / DEFAULT_PROMPT_HISTORY_FILE
        self._token_usage_file    = token_usage_dir    / DEFAULT_TOKEN_USAGE_FILE
        self._prompt_history_dir  = prompt_history_dir

        # ── Background I/O dispatcher (one per agent, daemon thread) ──────────
        self._dispatcher = AsyncLogDispatcher()

    # ── Lifecycle ─────────────────────────────────────────────

    def shutdown(self, timeout: Optional[float] = 30.0) -> None:
        """
        Flush all pending log entries and stop the background thread.
        Call this on graceful process exit to guarantee nothing is lost.
        """
        self._dispatcher.shutdown(timeout=timeout)

    # ── System Prompt Tracking ────────────────────────────────

    def log_system_prompt(self, system_prompt: Optional[str]) -> None:
        """
        Track system-prompt changes.

        Compares the SHA-256 hash of *system_prompt* against the cached
        ``last_system_prompt_hash``.  When the prompt has changed:

        1. Writes the full prompt text to ``prompt_history_dir/{hash}.md``
           (synchronous — small, rare write; must complete before we update state).
        2. Updates ``last_system_prompt_hash`` in ``config.yaml`` (locked write).
        3. Enqueues a metadata entry to ``prompt_history.jsonl`` (async).
        """
        if not system_prompt:
            return
        try:
            current_hash = hashlib.sha256(system_prompt.encode("utf-8")).hexdigest()

            if self._last_prompt_hash == current_hash:
                return

            # 1 — Write the prompt file synchronously (tiny, rare, needs
            #     guaranteed ordering before the hash update below).
            prompt_file = self._prompt_history_dir / f"{current_hash}.md"
            prompt_file.parent.mkdir(parents=True, exist_ok=True)
            prompt_file.write_text(system_prompt, encoding="utf-8")

            # 2 — Persist hash to config.yaml (atomic, locked).
            self._last_prompt_hash = current_hash
            self._logs_config.last_system_prompt_hash = current_hash
            self._persist_config()

            # 3 — Async append to prompt history JSONL.
            self._dispatcher.enqueue(self._prompt_history_file, {
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "system_prompt_hash": current_hash,
            })
        except (OSError, yaml.YAMLError) as exc:
            logger.warning("Failed to log system prompt: %s", exc)
            raise AgentsFlowLogError(f"Failed to log system prompt: {exc}") from exc

    def _persist_config(self) -> None:
        """Write the updated config back to config.yaml (synchronous + locked)."""
        try:
            from agentsflow.utils.config_io import _write_agent_config, _read_agent_config
            from filelock import FileLock

            config_path = self._agent_dir / AGENT_CONFIG_FILE
            lock_path   = config_path.with_suffix(".lock")
            with FileLock(str(lock_path)):
                if config_path.exists():
                    cfg = _read_agent_config(config_path)
                    if not cfg.logs_config:
                        from agentsflow.schema.agent_config_schema import LogsConfig as _LC
                        cfg.logs_config = _LC()
                    cfg.logs_config.last_system_prompt_hash = self._last_prompt_hash
                    _write_agent_config(self._agent_dir, cfg)
        except (OSError, yaml.YAMLError) as exc:
            logger.warning("Failed to persist config: %s", exc)
            raise AgentsFlowLogError(f"Failed to persist config: {exc}") from exc

    # ── I/O Logging ───────────────────────────────────────────

    def log_io(
        self,
        rid: str,
        input_text: str,
        llm_input: str,
        llm_output: Any,
        system_prompt: str,
        preprocess_output: Any = None,
        postprocess_output: Any = None,
        tool_calls: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        """Log a full pipeline run — non-blocking."""
        try:
            log_entry: Dict[str, Any] = {
                "rid": rid,
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "system_prompt_hash": self._last_prompt_hash,
                "input": input_text,
            }

            if preprocess_output is not None:
                log_entry["preprocess_output"] = _serialize(preprocess_output)

            if tool_calls:
                log_entry["tool_calls"] = tool_calls

            log_entry["llm_output"] = _serialize(llm_output)

            if postprocess_output is not None:
                log_entry["postprocess_output"] = _serialize(postprocess_output)

            log_entry["token_input"]  = self._client.count_tokens(llm_input)
            log_entry["token_output"] = self._client.count_tokens(
                str(llm_output) if llm_output else ""
            )

            self._dispatcher.enqueue(self._run_history_file, log_entry)
            self._dispatcher.enqueue(self._token_usage_file, {
                "rid":          log_entry["rid"],
                "date":         log_entry["date"],
                "token_input":  log_entry["token_input"],
                "token_output": log_entry["token_output"],
            })
        except (OSError, TypeError, ValueError) as exc:
            logger.warning("Failed to log IO: %s", exc)
            raise AgentsFlowLogError(f"Failed to log IO: {exc}") from exc

    # ── Token Summary ─────────────────────────────────────────

    def get_tokens_summary(
        self,
        system_prompt: str,
        user_prompt: Optional[str],
        rag_context: Optional[str],
        answer: Any,
    ) -> TokensSummary:
        """Build a token usage summary dict (synchronous, returns immediately)."""
        return {
            "agent_name": self._agent_name,
            "model":      self._model,
            "prompt_system_tokens":  self._client.count_tokens(system_prompt),
            "last_user_prompt":      self._client.count_tokens(user_prompt or ""),
            "last_rag_tokens":       self._client.count_tokens(rag_context or ""),
            "last_full_prompt_tokens": self._client.count_tokens(
                (system_prompt or "") + (user_prompt or "") + (rag_context or "")
            ),
            "last_answer_tokens":    self._client.count_tokens(
                str(answer) if answer else ""
            ),
        }


# ── Module-level helpers ──────────────────────────────────────

def _serialize(val: Any) -> Any:
    """Ensure *val* is JSON-friendly."""
    if val is None:
        return None
    return val if isinstance(val, (dict, list, str, int, float, bool)) else str(val)
