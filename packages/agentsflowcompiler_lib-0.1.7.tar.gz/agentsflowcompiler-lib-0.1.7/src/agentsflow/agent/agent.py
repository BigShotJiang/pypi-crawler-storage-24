"""
Agent — Core Runtime
====================
Slim orchestrator that wires together the modular components
(prompts, tools, stats) and runs the LLM interaction loop.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Optional, Callable
from uuid import uuid4

from agentsflow.constants import AGENTS_DIR, DEFAULT_AGENT_TIMEOUT
from agentsflow.schema import AgentConfig
from agentsflow.llm import create_llm_client, LLMClient
from agentsflow.types import ChatMessage, TokensSummary

from .run_context import RunContext, RunResult
from .llm_loop import run_llm_loop
from .prompt_builder import build_system_prompt
from .tools import AgentTools
from .stats import AgentStats
from ._utils import load_prompt, _load_function
from agentsflow.logging_utils import log_structured

logger = logging.getLogger(__name__)


class Agent:
    """
    A single AI agent that can be run with ``agent.run(user_prompt)``.

    Internally delegates to:
        - ``AgentTools``   — tool schemas & execution
        - ``AgentStats``   — logging & token tracking
    """

    def __init__(
        self,
        base_agents_dir: Path,
        config: AgentConfig,
        api_key: str,
        base_url: Optional[str] = None,
        tools_base_dir: Optional[Path] = None,
        ) -> None:
        self._agent_name = config.identity.name
        # ── Paths ────────────────────────────────────────────
        self._agent_dir = base_agents_dir / AGENTS_DIR / self._agent_name
        # ── LLM Client ──────────────────────────────────────
        self.client: LLMClient = create_llm_client(
            model=config.model_settings.model,
            api_key=api_key,
            base_url=base_url,
            provider=config.model_settings.provider,
        )

        # ── Prompts ─────────────────────────────
        self._system_prompt = build_system_prompt(self._agent_dir, config.prompt_config)

        # ── Output Format ────────────────────────────────────────────
        self._json_schema = load_prompt(self._agent_dir, config.output_format_config.json_schema_path if config.output_format_config else None)
        # ── Processing ────────────────────────────────────────────
        self._preprocess_fn: Optional[Callable] = None
        if config.preprocess_config:
            self._preprocess_fn = _load_function(
                (self._agent_dir / config.preprocess_config.path).resolve(),
                config.preprocess_config.function_name,
            )
        self._postprocess_fn: Optional[Callable] = None
        if config.postprocess_config:
            self._postprocess_fn = _load_function(
                self._agent_dir / config.postprocess_config.path,
                config.postprocess_config.function_name,
            )
        # ── Tools ────────────────────────────────────────────

        self._tools = AgentTools(
            agent_dir=self._agent_dir,
            tool_configs=config.tools if config.tools else [],
            tools_base_dir=tools_base_dir,
        )
        # ── Stats / Logging ──────────────────────────────────
        self._stats = AgentStats(
            agent_dir=self._agent_dir,
            client=self.client,
            logs_config=config.logs_config,
        )

        # ── Config Shortcuts ─────────────────────────────────
        self._temperature = config.model_settings.temperature
        self._max_tokens = config.model_settings.max_tokens
        self._timeout = config.model_settings.timeout
        self._retry_config = config.model_settings.retry_config
        self._return_format = config.output_format_config.return_format if config.output_format_config else "text"

 
        # Log system prompt on init (hash-based dedup)
        self._stats.log_system_prompt(self._system_prompt)


    @property
    def name(self) -> str:
        return self._agent_name

    @property
    def model(self) -> str:
        return self.client.model

    @property
    def provider(self) -> str:
        return self.client.provider_name

    # ── Run ──────────────────────────────────────────────────

    def build_messages(self, user_prompt: str) -> list[ChatMessage]:
        messages: list[ChatMessage] = []
        if self._system_prompt:
            messages.append({"role": "system", "content": self._system_prompt})
        messages.append({"role": "user", "content": user_prompt})
        return messages

    def run(self, user_prompt: str, timeout: Optional[float] = None) -> RunResult:
        ctx = self._create_run_context(user_prompt)
        self._tools.reset_log()

        log_structured(
            logging.INFO,
            "run_start",
            rid=ctx.rid,
            agent_name=getattr(self, "_agent_name", None),
        )

        try:
            self._apply_preprocess(ctx)
            ctx.messages = self.build_messages(ctx.llm_input)
            ctx.llm_raw_output = run_llm_loop(
                client=self.client,
                messages=ctx.messages,
                tools=self._tools,
                temperature=self._temperature,
                max_tokens=self._max_tokens,
                response_format=self._build_response_format(),
                timeout=timeout if timeout is not None else self._timeout,
                retry_config=self._retry_config,
                rid=ctx.rid,
            )
            ctx.llm_output = self._default_output_fn(ctx.llm_raw_output)
            self._apply_postprocess(ctx)
            self._finalize_run_state(ctx)
            self._log_run(ctx)

            log_structured(
                logging.INFO,
                "run_end",
                rid=ctx.rid,
                agent_name=getattr(self, "_agent_name", None),
            )
            return RunResult(
                output=ctx.final_output,
                rid=ctx.rid,
                token_input=self.client.count_tokens(ctx.llm_input),
                token_output=self.client.count_tokens(str(ctx.llm_output) if ctx.llm_output else ""),
                tool_calls=self._tools.call_log,
            )
        except Exception as e:
            log_structured(
                logging.ERROR,
                "run_error",
                rid=ctx.rid,
                agent_name=getattr(self, "_agent_name", None),
                error=str(e),
            )
            raise

    def get_tokens_summary(self, ctx: RunContext) -> TokensSummary:
        return self._stats.get_tokens_summary(
            system_prompt=self._system_prompt,
            user_prompt=ctx.user_prompt,
            rag_context=getattr(ctx, "rag_context", None),
            answer=ctx.final_output,
        )

    # ── Private ──────────────────────────────────────────────

    def _build_response_format(self) -> Optional[dict]:
        if self._json_schema:
            return {
                "type": "json_schema",
                "json_schema": {
                    "name": self._agent_name,
                    "schema": self._json_schema,
                    "strict": True,
                },
            }
        elif self._return_format == "json_object":
            return {"type": "json_object"}
        return None

    def _create_run_context(self, user_prompt: str) -> RunContext:
        return RunContext(rid=str(uuid4()), user_prompt=user_prompt, llm_input=user_prompt)

    def _apply_preprocess(self, ctx: RunContext) -> None:
        if self._preprocess_fn:
            ctx.preprocess_output = self._preprocess_fn(ctx.user_prompt)
            ctx.llm_input = str(ctx.preprocess_output)

    def _apply_postprocess(self, ctx: RunContext) -> None:
        if self._postprocess_fn:
            ctx.postprocess_output = self._postprocess_fn(ctx.llm_output)
            ctx.final_output = ctx.postprocess_output
        else:
            ctx.final_output = ctx.llm_output

    def _finalize_run_state(self, ctx: RunContext) -> None:
        pass

    def _log_run(self, ctx: RunContext) -> None:
        self._stats.log_io(
            rid=ctx.rid,
            input_text=ctx.user_prompt,
            llm_input=ctx.llm_input,
            llm_output=ctx.llm_output,
            system_prompt=self._system_prompt,
            preprocess_output=ctx.preprocess_output,
            postprocess_output=ctx.postprocess_output,
            tool_calls=self._tools.call_log if self._tools.call_log else None,
        )

    def _default_output_fn(self, output: str) -> Any:
        """Try to parse output as JSON; fall back to raw string."""
        try:
            return json.loads(output)
        except json.JSONDecodeError:
            return output