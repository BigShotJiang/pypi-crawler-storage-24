"""JWT decoder tool — decodes JWT tokens without signature verification."""

import base64
import json
import time


def run(token: str) -> dict:
    """Decode a JWT token and return its header, payload, and expiry status.

    This does NOT verify the signature — it only decodes for inspection.

    Args:
        token: The JWT string (three dot-separated base64url segments).

    Returns:
        A dictionary with header, payload, signature, and expiry info.

    Raises:
        ValueError: If the token format is invalid.
    """
    if not token or not token.strip():
        raise ValueError("token must not be empty.")

    parts = token.strip().split(".")
    if len(parts) != 3:
        raise ValueError(
            f"Invalid JWT format: expected 3 dot-separated parts, got {len(parts)}."
        )

    header = _decode_segment(parts[0], "header")
    payload = _decode_segment(parts[1], "payload")
    signature = parts[2]

    # Check expiry
    is_expired = None
    if "exp" in payload:
        try:
            exp = int(payload["exp"])
            is_expired = time.time() > exp
        except (ValueError, TypeError):
            is_expired = None

    return {
        "header": header,
        "payload": payload,
        "signature": signature,
        "is_expired": is_expired,
    }


def _decode_segment(segment: str, label: str) -> dict:
    """Base64url-decode a JWT segment and parse as JSON."""
    # Add padding if needed
    padded = segment + "=" * (4 - len(segment) % 4)
    try:
        decoded_bytes = base64.urlsafe_b64decode(padded)
    except Exception as exc:
        raise ValueError(f"Failed to base64url-decode JWT {label}: {exc}") from exc

    try:
        return json.loads(decoded_bytes)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Failed to parse JWT {label} as JSON: {exc}") from exc
