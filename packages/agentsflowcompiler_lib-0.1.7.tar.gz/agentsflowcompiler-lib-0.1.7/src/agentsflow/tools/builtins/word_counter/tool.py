"""Word counter tool — counts words, characters, sentences, and paragraphs."""

import re


def run(text: str) -> dict:
    """Count words, characters, sentences, and paragraphs in the given text.

    Args:
        text: The text to analyze.

    Returns:
        A dictionary with word, character, sentence, and paragraph counts.

    Raises:
        ValueError: If text is None.
    """
    if text is None:
        raise ValueError("Input text must not be None.")

    words = len(text.split()) if text.strip() else 0
    characters = len(text)
    characters_no_spaces = len(text.replace(" ", ""))
    sentences = len(re.findall(r'[^.!?]*[.!?]', text)) if text.strip() else 0
    paragraphs = len([p for p in text.split("\n\n") if p.strip()]) if text.strip() else 0

    return {
        "words": words,
        "characters": characters,
        "characters_no_spaces": characters_no_spaces,
        "sentences": sentences,
        "paragraphs": paragraphs,
    }
