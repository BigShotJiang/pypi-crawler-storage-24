"""IP lookup tool — analyzes IP addresses for type, version, and reverse DNS."""

import ipaddress
import socket


def run(ip_address: str) -> dict:
    """Analyze an IP address and return its properties.

    Args:
        ip_address: The IP address string (IPv4 or IPv6).

    Returns:
        A dictionary with IP version, type classification, reverse DNS, and network info.

    Raises:
        ValueError: If the IP address is invalid.
    """
    if not ip_address or not ip_address.strip():
        raise ValueError("ip_address must not be empty.")

    ip_str = ip_address.strip()

    try:
        ip_obj = ipaddress.ip_address(ip_str)
    except ValueError as exc:
        raise ValueError(f"Invalid IP address '{ip_str}': {exc}") from exc

    # Reverse DNS lookup (best-effort, no external API)
    reverse_dns = None
    try:
        reverse_dns = socket.gethostbyaddr(str(ip_obj))[0]
    except (socket.herror, socket.gaierror, OSError):
        reverse_dns = None

    # Determine network (standard blocks)
    if ip_obj.version == 4:
        interface = ipaddress.IPv4Interface(f"{ip_obj}/24")
    else:
        interface = ipaddress.IPv6Interface(f"{ip_obj}/64")

    return {
        "ip": str(ip_obj),
        "version": ip_obj.version,
        "is_private": ip_obj.is_private,
        "is_loopback": ip_obj.is_loopback,
        "is_multicast": ip_obj.is_multicast,
        "is_reserved": ip_obj.is_reserved,
        "is_global": ip_obj.is_global,
        "reverse_dns": reverse_dns,
        "network": str(interface.network),
    }
