"""Slug generator tool — converts text into URL-friendly slugs."""

import re
import unicodedata


def run(text: str, separator: str = "-", max_length: int = 200) -> dict:
    """Convert text into a URL-friendly slug.

    Args:
        text: The input text.
        separator: Word separator (default '-').
        max_length: Maximum slug length (default 200).

    Returns:
        A dictionary with the generated slug.

    Raises:
        ValueError: If text is empty.
    """
    if not text or not text.strip():
        raise ValueError("text must not be empty.")

    max_length = max(1, int(max_length))
    sep = separator if separator else "-"

    # Normalize unicode characters to ASCII
    slug = unicodedata.normalize("NFKD", text)
    slug = slug.encode("ascii", "ignore").decode("ascii")

    # Lowercase
    slug = slug.lower()

    # Replace non-alphanumeric characters with separator
    slug = re.sub(r'[^a-z0-9]+', sep, slug)

    # Strip leading/trailing separators
    slug = slug.strip(sep)

    # Collapse repeated separators
    slug = re.sub(re.escape(sep) + r'+', sep, slug)

    # Truncate to max_length without cutting mid-word
    if len(slug) > max_length:
        slug = slug[:max_length].rsplit(sep, 1)[0]

    return {"slug": slug}
