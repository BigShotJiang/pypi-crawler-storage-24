"""JSON validator tool — validates and optionally pretty-prints JSON strings."""

import json


def run(json_string: str, pretty_print: bool = False) -> dict:
    """Validate a JSON string and optionally pretty-print it.

    Args:
        json_string: The string to validate as JSON.
        pretty_print: If True, include a formatted version of the JSON.

    Returns:
        A dictionary indicating validity, any error message, and optionally
        the pretty-printed JSON.

    Raises:
        ValueError: If json_string is None.
    """
    if json_string is None:
        raise ValueError("Input json_string must not be None.")

    try:
        parsed = json.loads(json_string)
    except (json.JSONDecodeError, TypeError) as exc:
        return {
            "valid": False,
            "error": str(exc),
            "formatted": None,
        }

    result = {
        "valid": True,
        "error": None,
        "formatted": None,
    }

    if pretty_print:
        result["formatted"] = json.dumps(parsed, indent=2, ensure_ascii=False)

    return result
