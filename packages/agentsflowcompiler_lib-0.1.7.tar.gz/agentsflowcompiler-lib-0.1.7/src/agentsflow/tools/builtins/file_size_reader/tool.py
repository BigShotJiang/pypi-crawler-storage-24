"""File size reader tool — returns file size in bytes and human-readable format."""

import os


def run(file_path: str) -> dict:
    """Return the size of a file in bytes and a human-readable string.

    Args:
        file_path: The path to the file.

    Returns:
        A dictionary with the file size in bytes, a human-readable string,
        and whether the file exists.

    Raises:
        ValueError: If file_path is empty.
    """
    if not file_path or not file_path.strip():
        raise ValueError("file_path must not be empty.")

    file_path = file_path.strip()

    if not os.path.exists(file_path):
        return {
            "size_bytes": 0,
            "size_human": "0 B",
            "exists": False,
        }

    if not os.path.isfile(file_path):
        raise ValueError(f"'{file_path}' is not a regular file.")

    size_bytes = os.path.getsize(file_path)
    size_human = _human_readable_size(size_bytes)

    return {
        "size_bytes": size_bytes,
        "size_human": size_human,
        "exists": True,
    }


def _human_readable_size(size_bytes: int) -> str:
    """Convert bytes to a human-readable string (e.g. '1.5 MB')."""
    if size_bytes == 0:
        return "0 B"

    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    size = float(size_bytes)
    unit_index = 0

    while size >= 1024.0 and unit_index < len(units) - 1:
        size /= 1024.0
        unit_index += 1

    if unit_index == 0:
        return f"{int(size)} B"
    return f"{size:.2f} {units[unit_index]}"
