"""Base32 / Base58 codec tool — encodes and decodes with Base32 or Base58."""

import base64


# Base58 alphabet (Bitcoin-style, no 0/O/I/l)
BASE58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"


def run(action: str, data: str, encoding: str = "base32") -> dict:
    """Encode or decode data using Base32 or Base58.

    Args:
        action: 'encode' or 'decode'.
        data: Input text (for encode) or encoded string (for decode).
        encoding: 'base32' or 'base58' (default 'base32').

    Returns:
        A dictionary with the result string.

    Raises:
        ValueError: If action or encoding is invalid, or decoding fails.
    """
    if data is None:
        raise ValueError("data must not be None.")

    action = action.lower().strip()
    encoding = encoding.lower().strip()

    if encoding == "base32":
        return {"result": _base32(action, data)}
    elif encoding == "base58":
        return {"result": _base58(action, data)}
    else:
        raise ValueError(f"Unknown encoding '{encoding}'. Use 'base32' or 'base58'.")


def _base32(action: str, data: str) -> str:
    """Base32 encode or decode."""
    if action == "encode":
        return base64.b32encode(data.encode("utf-8")).decode("ascii")
    elif action == "decode":
        try:
            # Add padding if needed
            padded = data + "=" * ((8 - len(data) % 8) % 8)
            return base64.b32decode(padded, casefold=True).decode("utf-8")
        except Exception as exc:
            raise ValueError(f"Base32 decode failed: {exc}") from exc
    else:
        raise ValueError(f"Unknown action '{action}'. Use 'encode' or 'decode'.")


def _base58(action: str, data: str) -> str:
    """Base58 encode or decode (Bitcoin alphabet)."""
    if action == "encode":
        return _base58_encode(data.encode("utf-8"))
    elif action == "decode":
        try:
            return _base58_decode(data).decode("utf-8")
        except Exception as exc:
            raise ValueError(f"Base58 decode failed: {exc}") from exc
    else:
        raise ValueError(f"Unknown action '{action}'. Use 'encode' or 'decode'.")


def _base58_encode(data: bytes) -> str:
    """Encode bytes to a Base58 string."""
    num = int.from_bytes(data, "big")
    result = []
    while num > 0:
        num, remainder = divmod(num, 58)
        result.append(BASE58_ALPHABET[remainder])

    # Preserve leading zero bytes
    for byte in data:
        if byte == 0:
            result.append(BASE58_ALPHABET[0])
        else:
            break

    return "".join(reversed(result))


def _base58_decode(encoded: str) -> bytes:
    """Decode a Base58 string to bytes."""
    num = 0
    for char in encoded:
        idx = BASE58_ALPHABET.index(char)
        if idx < 0:
            raise ValueError(f"Invalid Base58 character: '{char}'")
        num = num * 58 + idx

    # Calculate byte length
    num_bytes = (num.bit_length() + 7) // 8
    result = num.to_bytes(num_bytes, "big") if num_bytes > 0 else b""

    # Restore leading zero bytes
    leading_ones = 0
    for char in encoded:
        if char == BASE58_ALPHABET[0]:
            leading_ones += 1
        else:
            break

    return b"\x00" * leading_ones + result
