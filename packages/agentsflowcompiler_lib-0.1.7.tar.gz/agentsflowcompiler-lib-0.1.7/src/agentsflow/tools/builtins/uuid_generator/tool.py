"""UUID generator tool — generates UUID4 identifiers."""

import uuid


def run(count: int = 1, uppercase: bool = False) -> dict:
    """Generate one or more UUID4 identifiers.

    Args:
        count: Number of UUIDs to generate (default 1, max 1000).
        uppercase: If True, return UUIDs in uppercase.

    Returns:
        A dictionary with a list of generated UUID strings.

    Raises:
        ValueError: If count is less than 1 or greater than 1000.
    """
    count = int(count)
    if count < 1:
        raise ValueError("Count must be at least 1.")
    if count > 1000:
        raise ValueError("Count must not exceed 1000.")

    uuids = []
    for _ in range(count):
        uid = str(uuid.uuid4())
        if uppercase:
            uid = uid.upper()
        uuids.append(uid)

    return {"uuids": uuids}
