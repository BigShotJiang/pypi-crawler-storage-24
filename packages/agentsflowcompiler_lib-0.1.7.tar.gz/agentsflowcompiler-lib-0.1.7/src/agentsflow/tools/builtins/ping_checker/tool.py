"""Ping / latency checker tool — tests network latency using system ping command."""

import platform
import re
import subprocess


def run(host: str, count: int = 4, timeout: int = 5) -> dict:
    """Ping a host and measure network latency.

    Args:
        host: Hostname or IP address to ping.
        count: Number of ping packets (default 4, max 20).
        timeout: Per-packet timeout in seconds (default 5).

    Returns:
        A dictionary with latency statistics and reachability.

    Raises:
        ValueError: If host is empty.
    """
    if not host or not host.strip():
        raise ValueError("host must not be empty.")

    host = host.strip()
    count = max(1, min(int(count), 20))
    timeout = max(1, min(int(timeout), 30))

    cmd = _build_ping_command(host, count, timeout)

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=count * timeout + 5,
        )
        output = result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return _unreachable_result(host, count)
    except FileNotFoundError:
        return {
            "host": host,
            "error": "ping command not found on this system",
            "reachable": False,
        }

    return _parse_output(output, host, count)


def _build_ping_command(host: str, count: int, timeout: int) -> list[str]:
    """Build the ping command for the current OS."""
    system = platform.system().lower()
    if system == "windows":
        return ["ping", "-n", str(count), "-w", str(timeout * 1000), host]
    else:
        return ["ping", "-c", str(count), "-W", str(timeout), host]


def _parse_output(output: str, host: str, count: int) -> dict:
    """Parse ping output to extract latency statistics."""
    # Parse packet loss
    loss_match = re.search(r'(\d+(?:\.\d+)?)%\s*(?:packet\s*)?loss', output, re.IGNORECASE)
    packet_loss = float(loss_match.group(1)) if loss_match else 100.0

    # Parse received packets
    recv_match = re.search(r'(\d+)\s*(?:packets?\s*)?received', output, re.IGNORECASE)
    if recv_match:
        received = int(recv_match.group(1))
    else:
        received = round(count * (1 - packet_loss / 100))

    # Parse RTT statistics (Linux: min/avg/max/mdev, macOS similar, Windows: Minimum/Maximum/Average)
    rtt_match = re.search(
        r'(?:rtt|round-trip)\s*(?:min/avg/max/(?:mdev|stddev))?\s*=\s*'
        r'([\d.]+)/([\d.]+)/([\d.]+)',
        output, re.IGNORECASE,
    )

    if not rtt_match:
        # Windows format
        rtt_match = re.search(
            r'Minimum\s*=\s*(\d+)ms.*Maximum\s*=\s*(\d+)ms.*Average\s*=\s*(\d+)ms',
            output, re.IGNORECASE,
        )
        if rtt_match:
            min_ms = float(rtt_match.group(1))
            max_ms = float(rtt_match.group(2))
            avg_ms = float(rtt_match.group(3))
        else:
            # Try individual time= values
            times = re.findall(r'time[=<]([\d.]+)\s*ms', output, re.IGNORECASE)
            if times:
                latencies = [float(t) for t in times]
                min_ms = min(latencies)
                max_ms = max(latencies)
                avg_ms = sum(latencies) / len(latencies)
            else:
                min_ms = avg_ms = max_ms = None
    else:
        min_ms = float(rtt_match.group(1))
        avg_ms = float(rtt_match.group(2))
        max_ms = float(rtt_match.group(3))

    return {
        "host": host,
        "packets_sent": count,
        "packets_received": received,
        "packet_loss_percent": packet_loss,
        "avg_latency_ms": round(avg_ms, 3) if avg_ms is not None else None,
        "min_latency_ms": round(min_ms, 3) if min_ms is not None else None,
        "max_latency_ms": round(max_ms, 3) if max_ms is not None else None,
        "reachable": received > 0,
    }


def _unreachable_result(host: str, count: int) -> dict:
    """Return a result dict for an unreachable host."""
    return {
        "host": host,
        "packets_sent": count,
        "packets_received": 0,
        "packet_loss_percent": 100.0,
        "avg_latency_ms": None,
        "min_latency_ms": None,
        "max_latency_ms": None,
        "reachable": False,
    }
