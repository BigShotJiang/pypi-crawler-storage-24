"""Port scanner tool — checks TCP port availability on a host."""

import socket


MAX_PORTS = 1024  # Safety limit


def run(host: str, ports: str, timeout: float = 1.0) -> dict:
    """Check TCP port availability on the given host.

    Args:
        host: Hostname or IP address.
        ports: Comma-separated ports or a range like '80-100'.
        timeout: Connection timeout per port in seconds (default 1.0).

    Returns:
        A dictionary with per-port results and lists of open/closed ports.

    Raises:
        ValueError: If host or ports are invalid.
    """
    if not host or not host.strip():
        raise ValueError("host must not be empty.")
    if not ports or not ports.strip():
        raise ValueError("ports must not be empty.")

    host = host.strip()
    timeout = max(0.1, min(float(timeout), 10.0))
    port_list = _parse_ports(ports.strip())

    if len(port_list) > MAX_PORTS:
        raise ValueError(f"Too many ports ({len(port_list)}). Maximum is {MAX_PORTS}.")

    results = {}
    open_ports = []
    closed_ports = []

    for port in port_list:
        is_open = _check_port(host, port, timeout)
        results[port] = "open" if is_open else "closed"
        if is_open:
            open_ports.append(port)
        else:
            closed_ports.append(port)

    return {
        "results": results,
        "open_ports": open_ports,
        "closed_ports": closed_ports,
    }


def _parse_ports(ports_str: str) -> list[int]:
    """Parse a port specification string into a sorted list of integers."""
    port_set = set()

    for part in ports_str.split(","):
        part = part.strip()
        if "-" in part:
            bounds = part.split("-", 1)
            try:
                start, end = int(bounds[0].strip()), int(bounds[1].strip())
            except ValueError:
                raise ValueError(f"Invalid port range: '{part}'")
            if start > end:
                start, end = end, start
            for p in range(start, end + 1):
                _validate_port(p)
                port_set.add(p)
        else:
            try:
                p = int(part)
            except ValueError:
                raise ValueError(f"Invalid port number: '{part}'")
            _validate_port(p)
            port_set.add(p)

    return sorted(port_set)


def _validate_port(port: int) -> None:
    """Ensure port is in valid range."""
    if port < 1 or port > 65535:
        raise ValueError(f"Port {port} is out of valid range (1-65535).")


def _check_port(host: str, port: int, timeout: float) -> bool:
    """Attempt a TCP connection to host:port."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        result = sock.connect_ex((host, port))
        return result == 0
    except (socket.timeout, socket.error, OSError):
        return False
    finally:
        sock.close()
