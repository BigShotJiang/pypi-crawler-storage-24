"""Environment variables reader tool — reads and filters environment variables."""

import os


def run(
    filter_prefix: str = "",
    names: str = "",
    mask_values: bool = False,
) -> dict:
    """Read environment variables with optional filtering.

    Args:
        filter_prefix: Only return variables starting with this prefix.
        names: Comma-separated specific variable names to retrieve.
        mask_values: If True, mask values showing only the first 4 characters.

    Returns:
        A dictionary with the filtered variables and count.
    """
    env = dict(os.environ)

    if names and names.strip():
        name_list = [n.strip() for n in names.split(",") if n.strip()]
        env = {k: v for k, v in env.items() if k in name_list}
    elif filter_prefix and filter_prefix.strip():
        prefix = filter_prefix.strip()
        env = {k: v for k, v in env.items() if k.startswith(prefix)}

    if mask_values:
        env = {k: _mask(v) for k, v in env.items()}

    # Sort by key for consistent output
    sorted_env = dict(sorted(env.items()))

    return {
        "variables": sorted_env,
        "count": len(sorted_env),
    }


def _mask(value: str) -> str:
    """Mask a value, showing only the first 4 characters."""
    if len(value) <= 4:
        return "*" * len(value)
    return value[:4] + "*" * (len(value) - 4)
