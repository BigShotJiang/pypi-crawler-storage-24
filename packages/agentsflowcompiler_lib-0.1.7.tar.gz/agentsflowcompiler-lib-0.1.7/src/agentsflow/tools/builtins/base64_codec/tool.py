"""Base64 codec tool — encodes and decodes Base64 strings."""

import base64


def run(action: str, data: str, url_safe: bool = False) -> dict:
    """Encode or decode a string using Base64.

    Args:
        action: 'encode' or 'decode'.
        data: The input text (for encode) or Base64 string (for decode).
        url_safe: If True, use URL-safe Base64 alphabet.

    Returns:
        A dictionary with the resulting string.

    Raises:
        ValueError: If action is invalid or decoding fails.
    """
    if not data and data != "":
        raise ValueError("data must not be None.")

    action = action.lower().strip()

    if action == "encode":
        raw = data.encode("utf-8")
        if url_safe:
            encoded = base64.urlsafe_b64encode(raw).decode("ascii")
        else:
            encoded = base64.b64encode(raw).decode("ascii")
        return {"result": encoded}

    elif action == "decode":
        try:
            if url_safe:
                decoded = base64.urlsafe_b64decode(data).decode("utf-8")
            else:
                decoded = base64.b64decode(data).decode("utf-8")
        except Exception as exc:
            raise ValueError(f"Failed to decode Base64: {exc}") from exc
        return {"result": decoded}

    else:
        raise ValueError(f"Unknown action '{action}'. Use 'encode' or 'decode'.")
