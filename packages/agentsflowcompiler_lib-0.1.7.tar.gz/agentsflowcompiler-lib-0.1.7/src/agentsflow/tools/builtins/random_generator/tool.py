"""Random generator tool — generates random numbers or strings."""

import random
import string


def run(
    mode: str,
    min_value: float = 0,
    max_value: float = 100,
    length: int = 16,
    charset: str = "alphanumeric",
    count: int = 1,
) -> dict:
    """Generate random numbers or strings.

    Args:
        mode: 'number' for random integers or 'string' for random strings.
        min_value: Minimum value for number mode (inclusive).
        max_value: Maximum value for number mode (inclusive).
        length: Length of each generated string (string mode).
        charset: Character set for string mode. One of 'alphanumeric',
                 'alpha', 'digits', 'hex'.
        count: Number of random values to generate (max 1000).

    Returns:
        A dictionary with a list of generated values.

    Raises:
        ValueError: If mode is invalid, or parameters are out of range.
    """
    mode = mode.lower().strip()
    count = int(count)

    if count < 1:
        raise ValueError("Count must be at least 1.")
    if count > 1000:
        raise ValueError("Count must not exceed 1000.")

    if mode == "number":
        values = _generate_numbers(float(min_value), float(max_value), count)
    elif mode == "string":
        values = _generate_strings(int(length), charset.lower().strip(), count)
    else:
        raise ValueError(f"Unknown mode '{mode}'. Use 'number' or 'string'.")

    return {"values": values}


def _generate_numbers(min_val: float, max_val: float, count: int) -> list:
    """Generate a list of random integers between min_val and max_val."""
    if min_val > max_val:
        raise ValueError(
            f"min_value ({min_val}) must not be greater than max_value ({max_val})."
        )
    lo = int(min_val)
    hi = int(max_val)
    return [random.randint(lo, hi) for _ in range(count)]


def _generate_strings(length: int, charset: str, count: int) -> list:
    """Generate a list of random strings from the chosen character set."""
    if length < 1:
        raise ValueError("String length must be at least 1.")
    if length > 10000:
        raise ValueError("String length must not exceed 10000.")

    charsets = {
        "alphanumeric": string.ascii_letters + string.digits,
        "alpha": string.ascii_letters,
        "digits": string.digits,
        "hex": string.hexdigits[:16],  # 0-9 a-f
    }
    chars = charsets.get(charset)
    if chars is None:
        raise ValueError(
            f"Unknown charset '{charset}'. "
            f"Supported: {', '.join(charsets.keys())}"
        )
    return ["".join(random.choices(chars, k=length)) for _ in range(count)]
