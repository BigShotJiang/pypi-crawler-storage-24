"""HTTP headers analyzer tool — parses and inspects HTTP headers for security and content info."""


RECOMMENDED_SECURITY_HEADERS = [
    "strict-transport-security",
    "content-security-policy",
    "x-content-type-options",
    "x-frame-options",
    "x-xss-protection",
    "referrer-policy",
    "permissions-policy",
]


def run(headers_text: str) -> dict:
    """Parse raw HTTP headers and analyze them.

    Args:
        headers_text: Multi-line string of HTTP headers
                      (e.g. 'Content-Type: text/html\\nCache-Control: no-cache').

    Returns:
        A dictionary with parsed headers, security analysis, and content type.

    Raises:
        ValueError: If headers_text is empty.
    """
    if not headers_text or not headers_text.strip():
        raise ValueError("headers_text must not be empty.")

    parsed = _parse_headers(headers_text)
    lower_keys = {k.lower(): k for k in parsed}

    # Identify security-related headers present
    security_found = []
    for sec_header in RECOMMENDED_SECURITY_HEADERS:
        if sec_header in lower_keys:
            security_found.append(lower_keys[sec_header])

    # Identify missing recommended security headers
    missing = [
        h for h in RECOMMENDED_SECURITY_HEADERS if h not in lower_keys
    ]

    content_type = parsed.get("Content-Type", parsed.get("content-type", None))

    return {
        "parsed": parsed,
        "security_headers": security_found,
        "missing_security": missing,
        "content_type": content_type,
    }


def _parse_headers(text: str) -> dict:
    """Parse header lines into a dictionary."""
    headers = {}
    for line in text.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        # Skip HTTP status line (e.g. "HTTP/1.1 200 OK")
        if line.upper().startswith("HTTP/"):
            continue
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        headers[key.strip()] = value.strip()
    return headers
