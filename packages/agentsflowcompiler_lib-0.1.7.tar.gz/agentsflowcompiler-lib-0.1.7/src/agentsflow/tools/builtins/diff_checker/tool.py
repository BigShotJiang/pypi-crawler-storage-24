"""Diff checker tool — compares two texts and produces a unified diff."""

import difflib


def run(text_a: str, text_b: str, context_lines: int = 3) -> dict:
    """Compare two texts and return a unified diff.

    Args:
        text_a: The original text.
        text_b: The modified text.
        context_lines: Number of surrounding context lines (default 3).

    Returns:
        A dictionary with the diff string, whether differences exist,
        and counts of added/deleted lines.

    Raises:
        ValueError: If either text is None.
    """
    if text_a is None or text_b is None:
        raise ValueError("Both text_a and text_b must be provided.")

    context_lines = max(0, int(context_lines))

    lines_a = text_a.splitlines(keepends=True)
    lines_b = text_b.splitlines(keepends=True)

    diff_lines = list(difflib.unified_diff(
        lines_a,
        lines_b,
        fromfile="original",
        tofile="modified",
        n=context_lines,
    ))

    diff_text = "".join(diff_lines)
    additions = sum(1 for line in diff_lines if line.startswith("+") and not line.startswith("+++"))
    deletions = sum(1 for line in diff_lines if line.startswith("-") and not line.startswith("---"))

    return {
        "diff": diff_text,
        "has_differences": len(diff_lines) > 0,
        "additions": additions,
        "deletions": deletions,
    }
