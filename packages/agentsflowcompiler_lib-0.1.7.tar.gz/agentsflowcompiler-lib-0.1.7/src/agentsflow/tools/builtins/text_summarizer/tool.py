"""Text summarizer tool — extracts the most important sentences using word-frequency scoring."""

import re
from collections import Counter


def run(text: str, num_sentences: int = 3) -> dict:
    """Summarize text by selecting the highest-scoring sentences based on word frequency.

    Args:
        text: The text to summarize.
        num_sentences: How many sentences to keep in the summary (default 3).

    Returns:
        A dictionary with the summary and length statistics.

    Raises:
        ValueError: If the input text is empty or blank.
    """
    if not text or not text.strip():
        raise ValueError("Input text must not be empty.")

    num_sentences = max(1, int(num_sentences))

    sentences = _split_sentences(text)
    if len(sentences) <= num_sentences:
        summary = " ".join(sentences)
        return {
            "summary": summary,
            "original_length": len(text),
            "summary_length": len(summary),
        }

    word_freq = _word_frequencies(text)
    scored = _score_sentences(sentences, word_freq)

    # Pick top-N sentences but preserve original order
    top_indices = sorted(
        sorted(range(len(scored)), key=lambda i: scored[i], reverse=True)[:num_sentences]
    )
    summary = " ".join(sentences[i] for i in top_indices)

    return {
        "summary": summary,
        "original_length": len(text),
        "summary_length": len(summary),
    }


def _split_sentences(text: str) -> list[str]:
    """Split text into sentences using punctuation boundaries."""
    raw = re.split(r'(?<=[.!?])\s+', text.strip())
    return [s.strip() for s in raw if s.strip()]


def _word_frequencies(text: str) -> Counter:
    """Count word frequencies, ignoring common stop-words."""
    stop_words = {
        "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did", "will", "would", "shall",
        "should", "may", "might", "must", "can", "could", "to", "of", "in",
        "for", "on", "with", "at", "by", "from", "as", "into", "through",
        "during", "before", "after", "above", "below", "between", "out",
        "off", "over", "under", "again", "further", "then", "once", "and",
        "but", "or", "nor", "not", "so", "yet", "both", "either", "neither",
        "each", "every", "all", "any", "few", "more", "most", "other",
        "some", "such", "no", "only", "own", "same", "than", "too", "very",
        "it", "its", "this", "that", "these", "those", "i", "me", "my",
        "we", "our", "you", "your", "he", "him", "his", "she", "her",
        "they", "them", "their", "what", "which", "who", "whom",
    }
    words = re.findall(r'[a-zA-Z]+', text.lower())
    return Counter(w for w in words if w not in stop_words and len(w) > 1)


def _score_sentences(sentences: list[str], freq: Counter) -> list[float]:
    """Score each sentence by the sum of its word frequencies."""
    scores = []
    for sentence in sentences:
        words = re.findall(r'[a-zA-Z]+', sentence.lower())
        score = sum(freq.get(w, 0) for w in words)
        scores.append(score)
    return scores
