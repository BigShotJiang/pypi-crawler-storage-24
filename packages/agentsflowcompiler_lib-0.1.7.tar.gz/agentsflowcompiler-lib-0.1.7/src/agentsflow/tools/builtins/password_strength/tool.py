"""Password strength tool — evaluates password strength with scoring and feedback."""

import re
import string


def run(password: str) -> dict:
    """Evaluate the strength of a password.

    Scoring criteria:
        - Length contribution (up to 30 points)
        - Character diversity (up to 40 points)
        - Bonus for mixing and avoiding common patterns (up to 30 points)

    Args:
        password: The password string to evaluate.

    Returns:
        A dictionary with a numeric score (0-100), a strength label, and feedback.

    Raises:
        ValueError: If password is None or empty.
    """
    if not password:
        raise ValueError("Password must not be empty.")

    score = 0
    feedback = []

    # --- Length scoring (max 30) ---
    length = len(password)
    if length >= 16:
        score += 30
    elif length >= 12:
        score += 25
    elif length >= 8:
        score += 15
    elif length >= 6:
        score += 10
    else:
        score += 5
        feedback.append("Use at least 8 characters.")

    if length < 8:
        feedback.append("Password is too short.")

    # --- Character diversity (max 40) ---
    has_lower = bool(re.search(r'[a-z]', password))
    has_upper = bool(re.search(r'[A-Z]', password))
    has_digit = bool(re.search(r'[0-9]', password))
    has_special = bool(re.search(r'[^a-zA-Z0-9]', password))

    diversity_count = sum([has_lower, has_upper, has_digit, has_special])
    score += diversity_count * 10

    if not has_upper:
        feedback.append("Add uppercase letters.")
    if not has_lower:
        feedback.append("Add lowercase letters.")
    if not has_digit:
        feedback.append("Add digits.")
    if not has_special:
        feedback.append("Add special characters (!@#$%^&* etc.).")

    # --- Bonus / penalty (max 30) ---
    # Bonus for length beyond 12
    if length > 12:
        score += min(10, (length - 12) * 2)

    # Penalty for repeated characters
    if re.search(r'(.)\1{2,}', password):
        score -= 10
        feedback.append("Avoid repeating characters (e.g. 'aaa').")

    # Penalty for common sequences
    common_patterns = [
        "123456", "password", "qwerty", "abc123", "letmein",
        "admin", "welcome", "monkey", "dragon", "master",
        "1234", "abcd", "asdf",
    ]
    lower_pw = password.lower()
    for pattern in common_patterns:
        if pattern in lower_pw:
            score -= 15
            feedback.append(f"Avoid common patterns like '{pattern}'.")
            break

    # Bonus for no dictionary words (simple heuristic: high entropy mix)
    if diversity_count == 4 and length >= 12:
        score += 10

    # Clamp score
    score = max(0, min(100, score))

    # Map to label
    if score >= 80:
        strength = "very_strong"
    elif score >= 60:
        strength = "strong"
    elif score >= 40:
        strength = "fair"
    elif score >= 20:
        strength = "weak"
    else:
        strength = "very_weak"

    if not feedback:
        feedback.append("Great password!")

    return {
        "score": score,
        "strength": strength,
        "feedback": feedback,
    }
