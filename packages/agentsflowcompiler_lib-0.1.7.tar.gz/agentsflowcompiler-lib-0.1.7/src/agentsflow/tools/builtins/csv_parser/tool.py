"""CSV parser tool — parses and explores CSV data from strings or files."""

import csv
import io
import os


def run(
    source: str,
    delimiter: str = ",",
    has_header: bool = True,
    max_rows: int = 100,
) -> dict:
    """Parse CSV data and return structured rows with metadata.

    Args:
        source: CSV content as a string, or a file path to a .csv file.
        delimiter: Column delimiter (default ',').
        has_header: Whether the first row contains headers (default True).
        max_rows: Maximum data rows to return (default 100).

    Returns:
        A dictionary with headers, rows, row_count, and column_count.

    Raises:
        ValueError: If source is empty.
        FileNotFoundError: If source looks like a path but the file doesn't exist.
    """
    if not source or not source.strip():
        raise ValueError("source must not be empty.")

    max_rows = max(1, int(max_rows))
    text = _read_source(source.strip())

    reader = csv.reader(io.StringIO(text), delimiter=delimiter)
    all_rows = list(reader)

    if not all_rows:
        return {"headers": [], "rows": [], "row_count": 0, "column_count": 0}

    if has_header:
        headers = all_rows[0]
        data_rows = all_rows[1:]
    else:
        headers = [f"col_{i}" for i in range(len(all_rows[0]))]
        data_rows = all_rows

    total = len(data_rows)
    limited = data_rows[:max_rows]

    rows_as_dicts = [
        {headers[i]: (row[i] if i < len(row) else "") for i in range(len(headers))}
        for row in limited
    ]

    return {
        "headers": headers,
        "rows": rows_as_dicts,
        "row_count": total,
        "column_count": len(headers),
    }


def _read_source(source: str) -> str:
    """Return CSV text — reads from file if source is a valid file path."""
    if os.path.isfile(source):
        with open(source, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read()
    return source
