"""URL parser tool — parses and validates URLs into their components."""

from urllib.parse import urlparse, parse_qs


def run(url: str) -> dict:
    """Parse a URL and extract its components.

    Args:
        url: The URL string to parse.

    Returns:
        A dictionary with validity flag and all URL components.

    Raises:
        ValueError: If url is empty.
    """
    if not url or not url.strip():
        raise ValueError("url must not be empty.")

    url = url.strip()

    try:
        parsed = urlparse(url)
    except Exception as exc:
        return {
            "valid": False,
            "error": str(exc),
            "scheme": None,
            "host": None,
            "port": None,
            "path": None,
            "query_params": {},
            "fragment": None,
        }

    # A URL is considered valid if it has at least a scheme and a netloc (host)
    is_valid = bool(parsed.scheme) and bool(parsed.netloc)

    query_params = {}
    if parsed.query:
        raw = parse_qs(parsed.query, keep_blank_values=True)
        # Flatten single-value lists
        query_params = {
            k: v[0] if len(v) == 1 else v for k, v in raw.items()
        }

    return {
        "valid": is_valid,
        "scheme": parsed.scheme or None,
        "host": parsed.hostname,
        "port": parsed.port,
        "path": parsed.path or None,
        "query_params": query_params,
        "fragment": parsed.fragment or None,
    }
