"""Path normalizer tool — normalizes, resolves, and analyzes filesystem paths."""

import os


def run(path: str, resolve_symlinks: bool = True) -> dict:
    """Normalize a filesystem path and extract its components.

    Args:
        path: The path string to normalize.
        resolve_symlinks: If True, resolve symlinks to their real path.

    Returns:
        A dictionary with normalized, absolute, dirname, basename, extension, and existence.

    Raises:
        ValueError: If path is empty.
    """
    if not path or not path.strip():
        raise ValueError("path must not be empty.")

    raw = path.strip()
    normalized = os.path.normpath(raw)

    if resolve_symlinks:
        absolute = os.path.realpath(normalized)
    else:
        absolute = os.path.abspath(normalized)

    dirname = os.path.dirname(absolute)
    basename = os.path.basename(absolute)
    _, extension = os.path.splitext(basename)

    return {
        "normalized": normalized,
        "absolute": absolute,
        "dirname": dirname,
        "basename": basename,
        "extension": extension,
        "exists": os.path.exists(absolute),
    }
