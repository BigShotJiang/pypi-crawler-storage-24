"""Regex tester tool — tests regular expressions against text and returns detailed match info."""

import re


FLAG_MAP = {
    "i": re.IGNORECASE,
    "m": re.MULTILINE,
    "s": re.DOTALL,
    "x": re.VERBOSE,
}


def run(pattern: str, text: str, flags: str = "") -> dict:
    """Test a regex pattern against text and return all matches.

    Args:
        pattern: The regular expression pattern.
        text: The text to search.
        flags: Optional flag characters ('i', 'm', 's', 'x').

    Returns:
        A dictionary with match details, count, and pattern validity.

    Raises:
        ValueError: If pattern or text is None.
    """
    if pattern is None:
        raise ValueError("Pattern must not be None.")
    if text is None:
        raise ValueError("Text must not be None.")

    combined_flags = 0
    for ch in (flags or ""):
        flag = FLAG_MAP.get(ch.lower())
        if flag:
            combined_flags |= flag

    try:
        compiled = re.compile(pattern, combined_flags)
    except re.error as exc:
        return {
            "matches": [],
            "match_count": 0,
            "is_valid_pattern": False,
            "error": str(exc),
        }

    matches = []
    for m in compiled.finditer(text):
        match_info = {
            "full_match": m.group(0),
            "start": m.start(),
            "end": m.end(),
            "groups": list(m.groups()),
        }
        if m.groupdict():
            match_info["named_groups"] = m.groupdict()
        matches.append(match_info)

    return {
        "matches": matches,
        "match_count": len(matches),
        "is_valid_pattern": True,
    }
