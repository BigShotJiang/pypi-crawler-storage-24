"""Date formatter tool — converts date strings between formats."""

from datetime import datetime


def run(date_string: str, input_format: str, output_format: str) -> dict:
    """Convert a date string from one format to another.

    Args:
        date_string: The date string to convert.
        input_format: The strftime format describing the input (e.g. '%Y-%m-%d').
        output_format: The desired strftime output format (e.g. '%d/%m/%Y').

    Returns:
        A dictionary with the formatted date and its ISO 8601 representation.

    Raises:
        ValueError: If the date_string cannot be parsed with the given input_format.
    """
    if not date_string or not date_string.strip():
        raise ValueError("date_string must not be empty.")
    if not input_format:
        raise ValueError("input_format must not be empty.")
    if not output_format:
        raise ValueError("output_format must not be empty.")

    try:
        dt = datetime.strptime(date_string.strip(), input_format)
    except ValueError as exc:
        raise ValueError(
            f"Cannot parse '{date_string}' with format '{input_format}': {exc}"
        ) from exc

    return {
        "formatted_date": dt.strftime(output_format),
        "iso_format": dt.isoformat(),
    }
