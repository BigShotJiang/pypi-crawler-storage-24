"""Markdown converter tool — converts Markdown to HTML or plain text without external deps."""

import re
import html as html_module


def run(markdown: str, output_format: str = "html") -> dict:
    """Convert Markdown text to HTML or plain text.

    Args:
        markdown: The Markdown source text.
        output_format: 'html' or 'plain' (default 'html').

    Returns:
        A dictionary with the converted result.

    Raises:
        ValueError: If markdown is empty or output_format is invalid.
    """
    if markdown is None:
        raise ValueError("markdown must not be None.")

    fmt = output_format.lower().strip()
    if fmt not in ("html", "plain"):
        raise ValueError(f"Unknown output_format '{output_format}'. Use 'html' or 'plain'.")

    if fmt == "html":
        result = _md_to_html(markdown)
    else:
        result = _md_to_plain(markdown)

    return {"result": result}


def _md_to_html(md: str) -> str:
    """Convert Markdown to HTML using regex-based transformation."""
    text = md

    # Code blocks (fenced)
    text = re.sub(
        r'```(\w*)\n(.*?)```',
        lambda m: f'<pre><code class="language-{m.group(1)}">{html_module.escape(m.group(2))}</code></pre>',
        text, flags=re.DOTALL,
    )

    # Inline code
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)

    # Headers (h1-h6)
    for level in range(6, 0, -1):
        pattern = r'^' + ('#' * level) + r'\s+(.+)$'
        text = re.sub(pattern, rf'<h{level}>\1</h{level}>', text, flags=re.MULTILINE)

    # Bold and italic
    text = re.sub(r'\*\*\*(.+?)\*\*\*', r'<strong><em>\1</em></strong>', text)
    text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', text)

    # Links
    text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)

    # Images
    text = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', r'<img src="\2" alt="\1" />', text)

    # Horizontal rules
    text = re.sub(r'^---+$', '<hr />', text, flags=re.MULTILINE)

    # Unordered lists
    text = re.sub(r'^[\*\-]\s+(.+)$', r'<li>\1</li>', text, flags=re.MULTILINE)

    # Blockquotes
    text = re.sub(r'^>\s+(.+)$', r'<blockquote>\1</blockquote>', text, flags=re.MULTILINE)

    # Paragraphs — wrap remaining loose lines
    lines = text.split('\n')
    result_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped and not re.match(r'^<(h[1-6]|li|pre|code|blockquote|hr|img|ul|ol)', stripped):
            result_lines.append(f'<p>{stripped}</p>')
        else:
            result_lines.append(line)

    return '\n'.join(result_lines)


def _md_to_plain(md: str) -> str:
    """Strip Markdown formatting to produce clean plain text."""
    text = md

    # Remove fenced code block markers
    text = re.sub(r'```\w*\n?', '', text)

    # Remove inline code backticks
    text = re.sub(r'`([^`]+)`', r'\1', text)

    # Remove headers markers
    text = re.sub(r'^#{1,6}\s+', '', text, flags=re.MULTILINE)

    # Remove bold/italic markers
    text = re.sub(r'\*{1,3}(.+?)\*{1,3}', r'\1', text)

    # Extract link text
    text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)

    # Remove image syntax
    text = re.sub(r'!\[([^\]]*)\]\([^)]+\)', r'\1', text)

    # Remove blockquote markers
    text = re.sub(r'^>\s+', '', text, flags=re.MULTILINE)

    # Remove horizontal rules
    text = re.sub(r'^---+$', '', text, flags=re.MULTILINE)

    # Remove list markers
    text = re.sub(r'^[\*\-]\s+', '', text, flags=re.MULTILINE)

    # Collapse multiple blank lines
    text = re.sub(r'\n{3,}', '\n\n', text)

    return text.strip()
