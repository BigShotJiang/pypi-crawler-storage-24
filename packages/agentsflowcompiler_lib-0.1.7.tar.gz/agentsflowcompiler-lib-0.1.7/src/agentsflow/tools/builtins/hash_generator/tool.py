"""Hash generator tool — generates cryptographic hash digests of input strings."""

import hashlib


SUPPORTED_ALGORITHMS = {"sha256", "sha512", "md5", "sha1"}


def run(text: str, algorithm: str = "sha256") -> dict:
    """Generate a cryptographic hash of the given text.

    Args:
        text: The input string to hash.
        algorithm: The hash algorithm to use (default 'sha256').
                   Supported: sha256, sha512, md5, sha1.

    Returns:
        A dictionary with the hex-encoded hash digest and the algorithm used.

    Raises:
        ValueError: If text is None or algorithm is not supported.
    """
    if text is None:
        raise ValueError("Input text must not be None.")

    algo = algorithm.lower().strip()
    if algo not in SUPPORTED_ALGORITHMS:
        raise ValueError(
            f"Unsupported algorithm '{algorithm}'. "
            f"Supported: {', '.join(sorted(SUPPORTED_ALGORITHMS))}"
        )

    hasher = hashlib.new(algo)
    hasher.update(text.encode("utf-8"))
    digest = hasher.hexdigest()

    return {
        "hash": digest,
        "algorithm": algo,
    }
