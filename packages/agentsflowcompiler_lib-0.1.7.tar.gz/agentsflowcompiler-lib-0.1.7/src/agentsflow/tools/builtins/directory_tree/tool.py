"""Directory tree explorer tool — displays directory structure as a formatted tree."""

import os


def run(
    path: str,
    max_depth: int = 3,
    show_files: bool = True,
    show_hidden: bool = False,
) -> dict:
    """Generate a formatted directory tree.

    Args:
        path: Root directory to explore.
        max_depth: Maximum traversal depth (default 3).
        show_files: Include files in the tree (default True).
        show_hidden: Include hidden entries starting with '.' (default False).

    Returns:
        A dictionary with the tree string and entry counts.

    Raises:
        ValueError: If path is empty or does not exist.
    """
    if not path or not path.strip():
        raise ValueError("path must not be empty.")

    path = path.strip()
    if not os.path.isdir(path):
        raise ValueError(f"'{path}' is not a directory or does not exist.")

    max_depth = max(1, int(max_depth))
    stats = {"dirs": 0, "files": 0}
    lines = [os.path.basename(os.path.abspath(path)) + "/"]

    _build_tree(path, "", max_depth, 0, show_files, show_hidden, lines, stats)

    return {
        "tree": "\n".join(lines),
        "total_dirs": stats["dirs"],
        "total_files": stats["files"],
    }


def _build_tree(
    dir_path: str,
    prefix: str,
    max_depth: int,
    current_depth: int,
    show_files: bool,
    show_hidden: bool,
    lines: list,
    stats: dict,
) -> None:
    """Recursively build the tree lines."""
    if current_depth >= max_depth:
        return

    try:
        entries = sorted(os.listdir(dir_path))
    except PermissionError:
        lines.append(prefix + "└── [permission denied]")
        return

    if not show_hidden:
        entries = [e for e in entries if not e.startswith(".")]

    if not show_files:
        entries = [
            e for e in entries if os.path.isdir(os.path.join(dir_path, e))
        ]

    for i, entry in enumerate(entries):
        full_path = os.path.join(dir_path, entry)
        is_last = i == len(entries) - 1
        connector = "└── " if is_last else "├── "
        extension = "    " if is_last else "│   "

        if os.path.isdir(full_path):
            stats["dirs"] += 1
            lines.append(f"{prefix}{connector}{entry}/")
            _build_tree(
                full_path,
                prefix + extension,
                max_depth,
                current_depth + 1,
                show_files,
                show_hidden,
                lines,
                stats,
            )
        else:
            stats["files"] += 1
            lines.append(f"{prefix}{connector}{entry}")
