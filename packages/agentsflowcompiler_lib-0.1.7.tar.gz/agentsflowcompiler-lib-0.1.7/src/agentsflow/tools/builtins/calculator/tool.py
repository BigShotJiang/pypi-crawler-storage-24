"""Calculator tool — performs basic arithmetic operations."""


def run(operation: str, a: float, b: float) -> dict:
    """Perform a basic arithmetic operation on two numbers.

    Args:
        operation: The operation to perform. One of 'add', 'subtract', 'multiply', 'divide'.
        a: The first operand.
        b: The second operand.

    Returns:
        A dictionary with the 'result' key containing the computed value.

    Raises:
        ValueError: If the operation is not recognized.
        ZeroDivisionError: If dividing by zero.
    """
    operations = {
        "add": lambda x, y: x + y,
        "subtract": lambda x, y: x - y,
        "multiply": lambda x, y: x * y,
        "divide": lambda x, y: _safe_divide(x, y),
    }

    op = operation.lower().strip()
    if op not in operations:
        raise ValueError(
            f"Unknown operation '{operation}'. "
            f"Supported operations: {', '.join(operations.keys())}"
        )

    result = operations[op](float(a), float(b))
    return {"result": result}


def _safe_divide(a: float, b: float) -> float:
    """Divide a by b with a zero-division guard."""
    if b == 0:
        raise ZeroDivisionError("Cannot divide by zero.")
    return a / b
