"""Temporary file generator tool — creates temp files with optional content."""

import os
import tempfile


def run(content: str = "", suffix: str = ".tmp", prefix: str = "tool_") -> dict:
    """Create a temporary file with optional content.

    The file persists after this function returns (it is NOT auto-deleted).
    The caller is responsible for cleanup when appropriate.

    Args:
        content: Text to write into the file (default empty).
        suffix: File extension/suffix (default '.tmp').
        prefix: File name prefix (default 'tool_').

    Returns:
        A dictionary with the absolute path and file size.
    """
    suffix = suffix or ".tmp"
    prefix = prefix or "tool_"

    fd, path = tempfile.mkstemp(suffix=suffix, prefix=prefix, text=True)
    try:
        if content:
            os.write(fd, content.encode("utf-8"))
    finally:
        os.close(fd)

    size = os.path.getsize(path)

    return {
        "path": path,
        "size_bytes": size,
    }
