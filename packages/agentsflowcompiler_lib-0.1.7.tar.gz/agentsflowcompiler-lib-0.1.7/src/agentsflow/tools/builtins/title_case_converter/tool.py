"""Title case converter tool — converts text between casing styles."""

import re


def run(text: str, style: str = "title") -> dict:
    """Convert text to the requested casing style.

    Args:
        text: The input text.
        style: One of 'title', 'upper', 'lower', 'sentence', 'camel', 'snake', 'kebab'.

    Returns:
        A dictionary with the converted text.

    Raises:
        ValueError: If text is None or style is unrecognised.
    """
    if text is None:
        raise ValueError("text must not be None.")

    style = style.lower().strip()

    converters = {
        "title": _to_title,
        "upper": lambda t: t.upper(),
        "lower": lambda t: t.lower(),
        "sentence": _to_sentence,
        "camel": _to_camel,
        "snake": _to_snake,
        "kebab": _to_kebab,
    }

    converter = converters.get(style)
    if converter is None:
        raise ValueError(
            f"Unknown style '{style}'. "
            f"Supported: {', '.join(converters.keys())}"
        )

    return {"result": converter(text)}


def _words(text: str) -> list[str]:
    """Split text into words, handling camelCase, snake_case, kebab-case, and spaces."""
    # Insert space before uppercase letters (camelCase splitting)
    spaced = re.sub(r'([a-z])([A-Z])', r'\1 \2', text)
    # Replace non-alphanumeric with space
    spaced = re.sub(r'[^a-zA-Z0-9]+', ' ', spaced)
    return [w for w in spaced.split() if w]


def _to_title(text: str) -> str:
    return text.title()


def _to_sentence(text: str) -> str:
    sentences = re.split(r'([.!?]\s*)', text)
    result = []
    for i, part in enumerate(sentences):
        if i % 2 == 0 and part:
            result.append(part[0].upper() + part[1:].lower())
        else:
            result.append(part)
    return "".join(result)


def _to_camel(text: str) -> str:
    parts = _words(text)
    if not parts:
        return ""
    return parts[0].lower() + "".join(w.capitalize() for w in parts[1:])


def _to_snake(text: str) -> str:
    return "_".join(w.lower() for w in _words(text))


def _to_kebab(text: str) -> str:
    return "-".join(w.lower() for w in _words(text))
