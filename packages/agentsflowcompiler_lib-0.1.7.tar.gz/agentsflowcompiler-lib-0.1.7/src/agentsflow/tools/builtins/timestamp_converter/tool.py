"""Timestamp converter tool — converts between Unix timestamps and human-readable dates."""

from datetime import datetime, timezone


def run(
    value: str,
    direction: str = "auto",
    date_format: str = "%Y-%m-%d %H:%M:%S",
) -> dict:
    """Convert between Unix timestamps and human-readable date strings.

    Args:
        value: A Unix timestamp (number) or a date string.
        direction: 'to_unix', 'to_human', or 'auto' (default auto-detect).
        date_format: strftime format for parsing/formatting (default '%Y-%m-%d %H:%M:%S').

    Returns:
        A dictionary with both Unix timestamp and human-readable representations.

    Raises:
        ValueError: If the value cannot be parsed.
    """
    if not value or not str(value).strip():
        raise ValueError("value must not be empty.")

    value_str = str(value).strip()
    direction = direction.lower().strip()

    if direction == "auto":
        direction = _detect_direction(value_str)

    if direction == "to_human":
        return _timestamp_to_human(value_str, date_format)
    elif direction == "to_unix":
        return _human_to_timestamp(value_str, date_format)
    else:
        raise ValueError(f"Unknown direction '{direction}'. Use 'to_unix', 'to_human', or 'auto'.")


def _detect_direction(value: str) -> str:
    """Guess whether the value is a timestamp or a date string."""
    try:
        num = float(value)
        # Reasonable Unix timestamp range (1970-01-01 to ~2100)
        if 0 <= num <= 4_102_444_800:
            return "to_human"
    except ValueError:
        pass
    return "to_unix"


def _timestamp_to_human(value: str, date_format: str) -> dict:
    """Convert a Unix timestamp to a human-readable date."""
    try:
        ts = float(value)
    except ValueError as exc:
        raise ValueError(f"Cannot parse '{value}' as a Unix timestamp: {exc}") from exc

    dt = datetime.fromtimestamp(ts, tz=timezone.utc)
    return {
        "unix_timestamp": ts,
        "human_date": dt.strftime(date_format),
        "iso_format": dt.isoformat(),
    }


def _human_to_timestamp(value: str, date_format: str) -> dict:
    """Convert a human-readable date string to a Unix timestamp."""
    try:
        dt = datetime.strptime(value, date_format).replace(tzinfo=timezone.utc)
    except ValueError as exc:
        raise ValueError(
            f"Cannot parse '{value}' with format '{date_format}': {exc}"
        ) from exc

    ts = dt.timestamp()
    return {
        "unix_timestamp": ts,
        "human_date": value,
        "iso_format": dt.isoformat(),
    }
