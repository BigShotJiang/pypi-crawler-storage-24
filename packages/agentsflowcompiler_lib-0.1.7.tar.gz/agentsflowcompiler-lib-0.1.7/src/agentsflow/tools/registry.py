"""
Tool Registry
==============
Loads, registers, and executes tools for agents.

SOLID: Single Responsibility — only manages tool lifecycle.
SOLID: Dependency Inversion — depends on ToolConfig abstraction, not concrete implementations.

Built-in tools live in  tools/builtins/{tool_name}/tool.yaml + tool.py
Custom tools are fully defined in the agent's YAML config.
"""

from __future__ import annotations
from agentsflow.agent._utils import _load_function
import logging
import yaml
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from agentsflow.constants import DEFAULT_BUILTINS_DIR, DEFAULT_TOOL_YAML_NAME, DEFAULT_TOOL_PYTHON_NAME
from agentsflow.schema.tool_config_schema import Tool, ToolConfig, ToolIdentityConfig, ToolReturnConfig
from agentsflow.schema.tool_schema import ToolParameterConfig
from agentsflow.types import AnthropicToolSchema, OpenAIToolSchema

logger = logging.getLogger(__name__)


class ToolRegistry:
    """
    Manages both built-in and custom tools for an agent.
    """

    def __init__(self, builtins_dir: Optional[Path] = None) -> None:
        self._builtins_dir = builtins_dir or DEFAULT_BUILTINS_DIR
        self._tools: Dict[str, Tool] = {}
        self._executors: Dict[str, Callable] = {}

    # ── Loading ───────────────────────────────────────────────

    def load_agent_tools(
        self,
        tool_configs: List[Tool],
        agent_dir: Path,
    ) -> None:
        """Load all tools declared in an agent's config."""
        for tool in tool_configs:
            self._load_tool(tool, agent_dir)
    def _load_builtin_tool(self, tool_name: str) -> ToolConfig:
        tool_dir = self._builtins_dir / tool_name
        return _load_tool_config_from_yaml(tool_dir)

    def _load_tool(self, tool: Tool, agent_dir: Optional[Path] = None) -> None:
        if tool.custom:
            tool_path = agent_dir / tool.config.path
            self._tools[tool.identity.name] = tool
            self._executors[tool.identity.name] = _load_function(tool_path, tool.config.function_name)
            logger.info(f"Loaded custom tool: {tool.identity.name}")
        else:
            tool = self._load_builtin_tool(tool.identity.name)
            self._tools[tool.identity.name] = tool
            tool_path = self._builtins_dir / tool.identity.name / DEFAULT_TOOL_PYTHON_NAME
            self._executors[tool.identity.name] = _load_function(tool_path, tool.config.function_name)
            logger.info(f"Loaded built-in tool: {tool.identity.name}")

    # ── Execution ─────────────────────────────────────────────

    def execute(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        if tool_name not in self._executors:
            raise KeyError(f"Tool '{tool_name}' not registered. Available: {list(self._executors.keys())}")
        return self._executors[tool_name](**arguments)

    # ── Queries ───────────────────────────────────────────────

    def has_tools(self) -> bool:
        return len(self._tools) > 0

    def get_tool_names(self) -> List[str]:
        return list(self._tools.keys())

    def get_openai_schemas(self) -> list[OpenAIToolSchema]:
        return [t.to_openai_schema() for t in self._tools.values()]

    def get_anthropic_schemas(self) -> list[AnthropicToolSchema]:
        return [t.to_anthropic_schema() for t in self._tools.values()]

    # ── Discovery ─────────────────────────────────────────────

   

# ── Module-level helper ──────────────────────────────────────

def _load_tool_config_from_yaml(tool_dir: Path) -> Tool:
    tool_config_file = tool_dir / DEFAULT_TOOL_YAML_NAME
    tool_config = yaml.safe_load(tool_config_file.read_text(encoding="utf-8"))
    tool = Tool(**tool_config)
    return tool