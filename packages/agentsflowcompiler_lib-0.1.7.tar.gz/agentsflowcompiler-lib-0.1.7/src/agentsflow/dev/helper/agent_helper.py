from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING
from uuid import UUID
from uuid import uuid4
from agentsflow.constants import AGENT_CONFIG_FILE, AGENTS_DIR
from agentsflow.errors import AgentsFlowConfigError
from agentsflow.utils.manifest_io import (
    get_config_path_by_id as _get_agent_config_path_by_uid,
    update_agent_path as _update_manifest_agent_path,
)
from agentsflow.utils.config_io import _read_agent_config
from agentsflow.schema.agent_config_schema import (
    AgentConfig,
    AgentIdentity,
    AgentModelConfig,
    ApiKeyConfig,
    ApiKeyMethod,
    LogsConfig,
    PromptConfig,
    RetryConfig,
)
from agentsflow.constants import (
    DEFAULT_RETRY_MAX_ATTEMPTS,
    DEFAULT_RETRY_BASE_DELAY,
    DEFAULT_RETRY_MAX_DELAY,
)
from agentsflow.utils.fs import rename_agent_dir
from agentsflow.constants import (
    DEFAULT_AUDIT_LOGS_FILE,
    DEFAULT_PROMPT_HISTORY_FILE,
    DEFAULT_RUN_HISTORY_FILE,
    DEFAULT_TOKEN_USAGE_FILE,
)
# DEFAULT_PROMPT_FILES
DEFAULT_PROMPTS_DIR = "prompts"
DEFAULT_INSTRUCTION_FILE = "instruction.md"
DEFAULT_THINK_FILE = "think.md"
DEFAULT_RETURN_FILE = "return.md"
DEFAULT_EXAMPLE_FILE = "example.md"
DEFAULT_NEXT_MODEL_RULE_FILE = "next_model_rule.md"


def _get_agent_config_by_id(base_dir: Path, agent_id: UUID) -> AgentConfig:
    config_path = _get_agent_config_path_by_uid(base_dir, agent_id)
    if config_path is None:
        raise FileNotFoundError(f"Agent with ID {agent_id} not found in manifest")
    return _read_agent_config(base_dir / config_path)


def _get_agent_config_by_name(base_dir: Path, agent_name: str) -> AgentConfig:
    config_path = base_dir / AGENTS_DIR / agent_name / AGENT_CONFIG_FILE
    if not config_path.exists():
        raise FileNotFoundError(f"Agent '{agent_name}' not found at {config_path}")
    return _read_agent_config(config_path)


def _build_agent_identity(agent_name: str, description: Optional[str] = None, agent_id: Optional[UUID] = None) -> AgentIdentity:
    return AgentIdentity(name=agent_name, description=description or "", agent_id=agent_id or uuid4())
def _build_api_key_config(api_key: Optional[str], api_key_method: Optional[ApiKeyMethod], api_key_path: Optional[Path], api_key_variable: Optional[str]) -> ApiKeyConfig:
    return ApiKeyConfig(api_key=api_key, api_key_method=api_key_method, api_key_path=api_key_path, api_key_variable=api_key_variable)
def _build_logs_config(run_history_dir: Optional[Path] = None, audit_logs_dir: Optional[Path] = None, prompt_history_dir: Optional[Path] = None, token_usage_dir: Optional[Path] = None) -> LogsConfig:
    return LogsConfig(
        run_history_dir=run_history_dir,
        audit_logs_dir=audit_logs_dir,
        prompt_history_dir=prompt_history_dir,
        token_usage_dir=token_usage_dir,
    )
def _build_agent_model_config(
    api_key_config: ApiKeyConfig,
    model: str,
    temperature: float,
    max_tokens: Optional[int],
    timeout: Optional[float],
    retry_config: Optional[Dict[str, Any]] = None,
) -> AgentModelConfig:
    if retry_config is not None:
        rc = RetryConfig(
            max_attempts=retry_config.get("max_attempts", DEFAULT_RETRY_MAX_ATTEMPTS),
            base_delay=retry_config.get("base_delay", DEFAULT_RETRY_BASE_DELAY),
            max_delay=retry_config.get("max_delay", DEFAULT_RETRY_MAX_DELAY),
        )
    else:
        rc = RetryConfig()
    return AgentModelConfig(
        api_key_config=api_key_config,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        timeout=timeout,
        retry_config=rc,
    )

def _write_prompt_file(prompt: Optional[str], agent_dir: Path,prompt_rel_path: Path)  -> Optional[Path]:
    if prompt is None:
        return None
    path = agent_dir / prompt_rel_path
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)  
    path.write_text(prompt, encoding="utf-8")
    return prompt_rel_path
def _build_prompt_config(
    agent_dir: Path,
    instruction: Optional[str] = None,
    think: Optional[str] = None,
    ret: Optional[str] = None,
    example: Optional[str] = None,
    next_rule: Optional[str] = None,
) -> PromptConfig:
    
    return PromptConfig(
        instruction_path = _write_prompt_file(instruction, agent_dir ,Path(DEFAULT_PROMPTS_DIR) / DEFAULT_INSTRUCTION_FILE),
        think_path= _write_prompt_file(think, agent_dir ,Path(DEFAULT_PROMPTS_DIR) / DEFAULT_THINK_FILE),
        return_path= _write_prompt_file(ret, agent_dir ,Path(DEFAULT_PROMPTS_DIR) / DEFAULT_RETURN_FILE),
        example_path= _write_prompt_file(example, agent_dir ,Path(DEFAULT_PROMPTS_DIR) / DEFAULT_EXAMPLE_FILE),
        next_model_rule_path= _write_prompt_file(next_rule, agent_dir ,Path(DEFAULT_PROMPTS_DIR) / DEFAULT_NEXT_MODEL_RULE_FILE),
    )


def _update_agent_identity(
    base_dir: Path,
    identity: AgentIdentity,
    new_name: Optional[str],
    description: Optional[str],
) -> AgentIdentity:
    if new_name and new_name != identity.name:
        old_config_path = Path(AGENTS_DIR) / identity.name / AGENT_CONFIG_FILE
        new_config_path = Path(AGENTS_DIR) / new_name / AGENT_CONFIG_FILE
        rename_agent_dir(base_dir, identity.name, new_name, AGENTS_DIR)
        if not _update_manifest_agent_path(base_dir, old_config_path, new_config_path):
            raise AgentsFlowConfigError(
                f"Renamed directory but failed to update manifest "
                f"({old_config_path} -> {new_config_path})"
            )
        identity.name = new_name
    if description is not None:
        identity.description = description
    return identity


def _update_api_key_config(
    api_key_config: ApiKeyConfig,
    api_key: Optional[str],
    api_key_method: Optional[ApiKeyMethod],
    api_key_path: Optional[Path],
    api_key_variable: Optional[str],
) -> ApiKeyConfig:
    if api_key is not None:
        api_key_config.api_key = api_key
    if api_key_method is not None:
        api_key_config.api_key_method = api_key_method
    if api_key_path is not None:
        api_key_config.api_key_path = api_key_path
    if api_key_variable is not None:
        api_key_config.api_key_variable = api_key_variable
    return api_key_config
def _update_agent_model_config(
    model_config: AgentModelConfig,
    model: Optional[str],
    temperature: Optional[float],
    max_tokens: Optional[int],
    timeout: Optional[float],
    retry_config: Optional[RetryConfig] = None,
) -> AgentModelConfig:
    if model is not None:
        model_config.model = model
    if temperature is not None:
        model_config.temperature = temperature
    if max_tokens is not None:
        model_config.max_tokens = max_tokens
    if timeout is not None:
        model_config.timeout = timeout
    if retry_config is not None:
        model_config.retry_config = retry_config
    return model_config


def _update_agent_prompt_config(
    prompt_config: PromptConfig,
    agent_dir: Path,
    instruction: Optional[str],
    think: Optional[str],
    ret: Optional[str],
    example: Optional[str],
    next_rule: Optional[str],
) -> PromptConfig:
    if instruction is not None:
        prompt_config.instruction_path = _write_prompt_file(instruction, agent_dir, Path(DEFAULT_PROMPTS_DIR) / DEFAULT_INSTRUCTION_FILE)
    if think is not None:
        prompt_config.think_path = _write_prompt_file(think, agent_dir, Path(DEFAULT_PROMPTS_DIR) / DEFAULT_THINK_FILE)
    if ret is not None:
        prompt_config.return_path = _write_prompt_file(ret, agent_dir, Path(DEFAULT_PROMPTS_DIR) / DEFAULT_RETURN_FILE)
    if example is not None:
        prompt_config.example_path = _write_prompt_file(example, agent_dir, Path(DEFAULT_PROMPTS_DIR) / DEFAULT_EXAMPLE_FILE)
    if next_rule is not None:
        prompt_config.next_model_rule_path = _write_prompt_file(next_rule, agent_dir, Path(DEFAULT_PROMPTS_DIR) / DEFAULT_NEXT_MODEL_RULE_FILE)
    return prompt_config


def _update_logs_config(
    agent_dir: Path,
    logs_config: LogsConfig,
    run_history_dir: Optional[Path],
    audit_logs_dir: Optional[Path],
    prompt_history_dir: Optional[Path],
    token_usage_dir: Optional[Path],
) -> LogsConfig:
    if run_history_dir is not None:
        logs_config.run_history_dir = run_history_dir
    if audit_logs_dir is not None:
        logs_config.audit_logs_dir = audit_logs_dir
    if prompt_history_dir is not None:
        logs_config.prompt_history_dir = prompt_history_dir
    if token_usage_dir is not None:
        logs_config.token_usage_dir = token_usage_dir

    file_map = {
        logs_config.run_history_dir: [DEFAULT_RUN_HISTORY_FILE],
        logs_config.audit_logs_dir: [DEFAULT_AUDIT_LOGS_FILE],
        logs_config.prompt_history_dir: [DEFAULT_PROMPT_HISTORY_FILE],
        logs_config.token_usage_dir: [DEFAULT_TOKEN_USAGE_FILE],
    }
    for log_rel, filenames in file_map.items():
        if log_rel:
            log_dir = agent_dir / log_rel
            log_dir.mkdir(parents=True, exist_ok=True)
            for filename in filenames:
                log_file = log_dir / filename
                if not log_file.exists():
                    log_file.write_text("[]", encoding="utf-8")
    return logs_config


