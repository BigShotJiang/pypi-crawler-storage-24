from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import UUID

import yaml

from agentsflow.constants import DEFAULT_CUSTOM_TOOL_DIR, DEFAULT_TOOL_PYTHON_NAME
from agentsflow.schema.agent_config_schema import AgentConfig
from agentsflow.schema.tool_config_schema import Tool, ToolConfig, ToolIdentityConfig, ToolReturnConfig
from agentsflow.schema.tool_schema import ToolParametersConfig
from agentsflow.validate.processing import check_script_content_valid


def _get_yaml_tool_from_file(yaml_file: Path) -> Dict[str, Any]:
    return yaml.safe_load(yaml_file.read_text(encoding="utf-8"))


def _get_yamls_tools_from_dir(dir_path: Path, default_tool_yaml_name: str) -> List[Dict[str, Any]]:
    yaml_list = []
    for yaml_file in Path(dir_path).rglob(default_tool_yaml_name):
        if yaml_file.is_file():
            tool_dict = _get_yaml_tool_from_file(yaml_file)
            if tool_dict:
                yaml_list.append(tool_dict)
    return yaml_list


def _get_tool_from_yaml(yaml_dict: Dict[str, Any]) -> Tool:
    return Tool(**yaml_dict)


def _find_tool_ref(
    tools: Optional[List[Tool]],
    tool_name: Optional[str] = None,
    tool_id: Optional[UUID] = None,
) -> Tool:
    if tool_id is None and not tool_name:
        raise ValueError("Either tool_id or tool_name must be provided")
    if not tools:
        raise KeyError("Tool not found")
    if tool_id is not None:
        for tool in tools:
            if tool.identity.tool_id == tool_id:
                return tool
        raise KeyError(f"Tool with id {tool_id} not found")
    for tool in tools:
        if tool.identity.name == tool_name:
            return tool
    raise KeyError(f"Tool {tool_name} not found")


def _set_tool(
    agent_config: AgentConfig,
    tool_identity: ToolIdentityConfig,
    tool_config: Optional[ToolConfig],
    custom: bool,
) -> AgentConfig:
    if agent_config.tools is None:
        agent_config.tools = []
    if custom:
        agent_config.tools.append(
            Tool(
                identity=tool_identity,
                custom=custom,
                config=tool_config,
            )
        )
    else :
        agent_config.tools.append(
            Tool(
                identity=tool_identity,
                custom=custom
            )
        )
    return agent_config


def _search_builtin_tool(
    all_tools: List[Tool], tool_name: str, tool_id: Optional[UUID] = None
) -> Tool:
    if tool_id is None and not tool_name:
        raise ValueError("Either tool_id or tool_name must be provided")
    for tool in all_tools:
        if tool.identity.name == tool_name:
            return tool
    if tool_id is not None:
        for tool in all_tools:
            if tool.identity.tool_id == tool_id:
                return tool
    raise KeyError(f"Tool {tool_name} not found")


def _apply_tool_rename_if_needed(
    agent_dir: Path,
    tool: Tool,
    new_tool_name: Optional[str],
) -> Optional[Path]:
    """
    If the tool is being renamed and lives under the default structure
    (tools/custom_tools/<name>/tool.py), rename the directory and return
    the new relative path. Otherwise return None.
    """
    if new_tool_name is None or new_tool_name == tool.identity.name:
        return None
    if not tool.config or not tool.config.path:
        return None
    current_path = Path(tool.config.path)
    default_parent = Path(DEFAULT_CUSTOM_TOOL_DIR) / tool.identity.name
    if current_path.parent != default_parent:
        return None
    old_dir = agent_dir / current_path.parent
    new_dir = agent_dir / Path(DEFAULT_CUSTOM_TOOL_DIR) / new_tool_name
    if old_dir.exists():
        if new_dir.exists():
            shutil.rmtree(new_dir)
        shutil.move(str(old_dir), str(new_dir))
    return Path(DEFAULT_CUSTOM_TOOL_DIR) / new_tool_name / DEFAULT_TOOL_PYTHON_NAME


def _write_tool_script_if_provided(
    script: Optional[str],
    script_file_path: Optional[Path],
    function_name: Optional[str],
) -> None:
    """
    If script is provided, validate it and overwrite the script file at
    script_file_path. Raises if script_file_path or function_name is missing
    when script is provided.
    """
    if script is None:
        return
    if script_file_path is None:
        raise ValueError("Cannot overwrite script: tool has no path (config.path missing)")
    if not function_name:
        raise ValueError("Cannot validate script: function_name is required")
    check_script_content_valid(script, function_name)
    script_file_path.parent.mkdir(parents=True, exist_ok=True)
    script_file_path.write_text(script, encoding="utf-8")


def _update_tool(
    tools: List[Tool],
    tool: Tool,
    new_tool_name: Optional[str] = None,
    tool_path: Optional[Path] = None,
    function_name: Optional[str] = None,
    description: Optional[str] = None,
    category: Optional[str] = None,
    parameters: Optional[ToolParametersConfig] = None,
    returns: Optional[ToolReturnConfig] = None,
) -> Tool:
    tool = _update_tool_identity(tools, tool, new_tool_name, description, category)
    tool = _update_tool_config(tool, tool_path, function_name, parameters, returns)
    return tool


def _update_tool_identity(
    tools: List[Tool],
    tool: Tool,
    new_tool_name: Optional[str] = None,
    description: Optional[str] = None,
    category: Optional[str] = None,
) -> Tool:
    if new_tool_name is not None:
        if any(
            t.identity.name == new_tool_name and t.identity.tool_id != tool.identity.tool_id
            for t in (tools or [])
        ):
            raise ValueError(
                f"cannot update tool identity because tool {new_tool_name} already exists"
            )
        tool.identity.name = new_tool_name
    if description is not None:
        tool.identity.description = description
    if category is not None:
        tool.identity.category = category
    return tool


def _update_tool_config(
    tool: Tool,
    tool_path: Optional[Path] = None,
    function_name: Optional[str] = None,
    parameters: Optional[ToolParametersConfig] = None,
    returns: Optional[ToolReturnConfig] = None,
) -> Tool:
    if tool.config:
        if tool_path is not None:
            tool.config.path = tool_path
        if function_name is not None:
            tool.config.function_name = function_name
            tool = _update_parameters(tool, parameters)
            tool = _update_returns(tool, returns)
        return tool
    else:
        tool.config = ToolConfig(
            path=tool_path,
            function_name=function_name,
            parameters=parameters,
            returns=returns,
        )
        return tool


def _update_parameters(tool: Tool, parameters: Optional[ToolParametersConfig] = None) -> Tool:
    if parameters is not None and parameters.parameters is not None:
        for param_name, param in parameters.parameters.items():
            if param.type is not None:
                tool.config.parameters.parameters[param_name].type = param.type
            if param.description is not None:
                tool.config.parameters.parameters[param_name].description = param.description
            if param.required is not None:
                tool.config.parameters.parameters[param_name].required = param.required
            if param.default is not None:
                tool.config.parameters.parameters[param_name].default = param.default
            if param.enum is not None:
                tool.config.parameters.parameters[param_name].enum = param.enum
    return tool


def _update_returns(tool: Tool, returns: Optional[ToolReturnConfig] = None) -> Tool:
    if returns is not None:
        if returns.type is not None:
            tool.config.returns.type = returns.type
        if returns.description is not None:
            tool.config.returns.description = returns.description
    return tool

