from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from agentsflow.schema.project_config_schema import (
    DirectoryConfig,
    ProjectConfigEditSchema,
    ProjectConfigSchema,
    SecretEnvironmentConfig,
    SecretsConfig,
    SecretStrategy,
)


def _build_dir_config(dev_path: Path, prod_path: Optional[Path]) -> DirectoryConfig:
    return DirectoryConfig(dev=dev_path, prod=prod_path)


def _build_secret_config(
    env_strategy: Optional[SecretStrategy], custom_path: Optional[Path]
) -> SecretEnvironmentConfig:
    return SecretEnvironmentConfig(strategy=env_strategy, custom_path=custom_path)


def _build_secrets_config(
    dev_secrets: SecretEnvironmentConfig, prod_secrets: SecretEnvironmentConfig
) -> SecretsConfig:
    return SecretsConfig(dev=dev_secrets, prod=prod_secrets)


def _build_config(
    project_name: str, directories: DirectoryConfig, secrets: SecretsConfig
) -> ProjectConfigSchema:
    return ProjectConfigSchema(
        project_name=project_name, directories=directories, secrets=secrets
    )


def _build_dir_update(
    old_dir_config: DirectoryConfig,
    dev_path: Optional[Path],
    prod_path: Optional[Path],
) -> Optional[DirectoryConfig]:
    if dev_path is None and prod_path is None:
        return None
    return old_dir_config.update(dev=dev_path, prod=prod_path)


def _build_secret_update(
    old_secret_config: SecretEnvironmentConfig,
    strategy: Optional[SecretStrategy],
    custom_path: Optional[Path],
) -> SecretEnvironmentConfig:
    return old_secret_config.update(strategy=strategy, custom_path=custom_path)


def _build_secrets_update(
    old_secrets_config: SecretsConfig,
    dev_secrets: Optional[SecretEnvironmentConfig],
    prod_secrets: Optional[SecretEnvironmentConfig],
) -> SecretsConfig:
    return old_secrets_config.update(dev=dev_secrets, prod=prod_secrets)


def _build_config_update(
    old_config: ProjectConfigSchema,
    project_name: Optional[str],
    directories: Optional[DirectoryConfig],
    secrets: Optional[SecretsConfig],
) -> ProjectConfigSchema:
    return old_config.update(
        project_name=project_name, directories=directories, secrets=secrets
    )


def _resolve_project_path(output_dir: Optional[str], dev_path: str, project_name: str) -> Path:
    save_dir = Path(output_dir) if output_dir else Path(dev_path)
    save_dir.mkdir(parents=True, exist_ok=True)
    return save_dir / f"{project_name}.afproj"


def _read_config(path: Path) -> ProjectConfigSchema:
    if not path.exists():
        raise FileNotFoundError(f"Project config not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        return ProjectConfigSchema(**json.load(f))


def _write_config(config: ProjectConfigSchema, path: Path) -> None:
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(config.model_dump(mode="json"), f, ensure_ascii=False, indent=2)
    except Exception as e:
        raise Exception(f"Failed to write config to {path}: {str(e)}")


def _deep_merge(base: ProjectConfigSchema, updates: ProjectConfigEditSchema) -> ProjectConfigSchema:
    if updates.project_name is not None:
        base.project_name = updates.project_name
    if updates.directories is not None:
        if updates.directories.dev is not None:
            base.directories.dev = updates.directories.dev
        if updates.directories.prod is not None:
            base.directories.prod = updates.directories.prod
    if updates.secrets is not None:
        if updates.secrets.dev is not None:
            if updates.secrets.dev.strategy is not None:
                base.secrets.dev.strategy = updates.secrets.dev.strategy
            if updates.secrets.dev.custom_path is not None:
                base.secrets.dev.custom_path = updates.secrets.dev.custom_path
        if updates.secrets.prod is not None:
            if updates.secrets.prod.strategy is not None:
                base.secrets.prod.strategy = updates.secrets.prod.strategy
            if updates.secrets.prod.custom_path is not None:
                base.secrets.prod.custom_path = updates.secrets.prod.custom_path
    return base

