"""
Monitoring API type definitions.

TypedDicts for structured return types from monitoring functions.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, TypedDict


class PromptHistoryEntry(TypedDict):
    """Single prompt history entry."""
    date: str
    system_prompt_hash: str


class _RunHistoryEntryRequired(TypedDict):
    rid: str
    date: str
    system_prompt_hash: str | None
    input: str
    llm_output: Any
    token_input: int
    token_output: int


class RunHistoryEntry(_RunHistoryEntryRequired, total=False):
    """Single run history entry. preprocess_output and tool_calls are optional."""
    preprocess_output: Any
    tool_calls: list[dict[str, Any]]


class TokenUsageRunEntry(TypedDict):
    """Single run in token usage breakdown."""
    date: str
    token_input: int
    token_output: int


class TokenUsageResponse(TypedDict):
    """Token usage statistics response."""
    agent_name: str | None
    total_runs: int
    total_input_tokens: int
    total_output_tokens: int
    runs: list[TokenUsageRunEntry]


class AuditLogChangeEntry(TypedDict, total=False):
    """Single change in an audit log entry."""
    field: str
    old: Any
    new: Any


class AuditLogEntry(TypedDict):
    """Single audit log entry."""
    timestamp: str
    agent_name: str
    agent_id: str
    changes: list[dict[str, Any]]
@dataclass
class AgentContext:
    """Structured context for an agent's directories."""
    agent_dir: Path
    run_history_dir: Path
    audit_logs_dir: Path
    prompt_history_dir: Path
    token_usage_dir: Path
