"""
Project API
===========
Public functions for creating and managing AgentsFlow projects.
"""

from __future__ import annotations
from agentsflow.dev.helper.project_helper import (
    _build_dir_config,
    _build_secret_config,
    _build_secrets_config,
    _build_config,
    _build_config_update,
    _build_dir_update,
    _build_secret_update,
    _build_secrets_update,
    _read_config,
    _resolve_project_path,
    _write_config,
)
from agentsflow.schema.project_config_schema import ProjectConfigSchema, DirectoryConfig, SecretEnvironmentConfig, SecretsConfig, ProjectConfigEditSchema
from agentsflow.schema.project_config_schema import SecretStrategy
from pathlib import Path
from typing import Any, Dict, Optional


# ── Public API ────────────────────────────────────────────────


def create_project(
    project_name: str,
    dev_path: Path,
    dev_env_strategy: SecretStrategy,
    prod_path: Optional[Path] = None,
    prod_env_strategy: Optional[SecretStrategy] = None,
    dev_custom_path: Optional[Path] = None,
    prod_custom_path: Optional[Path] = None,
    output_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Create a new project configuration file.

    Args:
        project_name:       Human-readable project name.
        dev_path:           Absolute path to the DEV agents directory.
        prod_path:          Absolute path to the PROD agents directory (optional).
        dev_env_strategy:   How to load secrets in DEV ('project_local', 'os_env', 'custom').
        prod_env_strategy:  How to load secrets in PROD ('project_local', 'os_env', 'custom').
        dev_custom_path:    Custom .env path for DEV (when strategy='custom').
        prod_custom_path:   Custom .env path for PROD (when strategy='custom').
        output_dir:         Where to save the optional .afproj metadata file (defaults to dev_path).

    Returns:
        The project config dict that was saved.
    """

    directories=_build_dir_config(dev_path, prod_path)
    dev_secrets=_build_secret_config(dev_env_strategy, dev_custom_path)
    prod_secrets=_build_secret_config(prod_env_strategy, prod_custom_path)
    secrets=_build_secrets_config(dev_secrets,prod_secrets)
    config = _build_config(project_name,directories,secrets)
    project_path = _resolve_project_path(output_dir, dev_path, project_name)
    _write_config(config, project_path)

    return {'project_settings_path':str(project_path),'project_config':config.model_dump()}


def edit_project(project_config_path: Path,   
    project_name: Optional[str] = None,
    dev_path: Optional[Path] = None,
    prod_path: Optional[Path] = None,
    dev_env_strategy: Optional[SecretStrategy] = None,
    prod_env_strategy: Optional[SecretStrategy] = None,
    dev_custom_path: Optional[Path] = None,
    prod_custom_path: Optional[Path] = None
    ) -> Dict[str, Any]:
    """
    Edit fields in an existing project config file.

    Args:
        project_name:       Human-readable project name.
        project_config_path: Absolute path to the project .afproj file.
        dev_path:           Absolute path to the DEV agents directory.
        prod_path:          Absolute path to the PROD agents directory (optional).
        dev_env_strategy:   How to load secrets in DEV ('project_local', 'os_env', 'custom').
        prod_env_strategy:  How to load secrets in PROD ('project_local', 'os_env', 'custom').
        dev_custom_path:    Custom .env path for DEV (when strategy='custom').
        prod_custom_path:   Custom .env path for PROD (when strategy='custom').

    Returns:
        The updated project config dict.
    """
    path = Path(project_config_path)
    if not project_exists(path):
        raise FileNotFoundError(f"Project config not found: {path}")
    #read old config
    old_config = _read_config(path)

    directories = _build_dir_update(old_config.directories, dev_path, prod_path)
    dev_secret_update = _build_secret_update(old_config.secrets.dev, dev_env_strategy, dev_custom_path)
    prod_secret_update = _build_secret_update(old_config.secrets.prod, prod_env_strategy, prod_custom_path)
    secrets_update = _build_secrets_update(old_config.secrets, dev_secret_update, prod_secret_update)
    config = _build_config_update(old_config, project_name, directories, secrets_update)
    _write_config(config, path)
    return config.model_dump(mode="json")


def get_project(project_config_path: Path) -> Dict[str, Any]:
    """
    Read and return a project configuration.

    Args:
        project_config_path: Absolute path to the project .afproj file.

    Returns:
        The project config dict.
    """
    return _read_config(Path(project_config_path)).model_dump(mode="json")


def project_exists(project_config_path: Path) -> bool:
    """Check if a project config file exists."""
    return project_config_path.exists()