"""
agentsflow.dev — Development API
=================================
Flat development API grouped by concern::

    from agentsflow.dev import create_project, create_agent, add_tool, ...

The DEV API operates directly on a DEV ``base_dir`` for agent/tool/processing/
monitoring operations. Project functions manage optional ``.afproj`` metadata.
"""

# ── Project ──────────────────────────────────────────────────
from .project_api import (
    create_project,
    edit_project,
    get_project,
)

# ── Agent CRUD ───────────────────────────────────────────────
from .agent_api import (
    create_agent,
    edit_agent,
    delete_agent,
    duplicate_agent,
    validate_agent,
    get_agent_config,   
    get_all_agents,
    push_agent_to_prod,
)

# ── Tools ────────────────────────────────────────────────────
from .tool_api import (
    add_tool,
    add_builtin_tool,
    edit_tool,
    remove_tool,
    get_custom_tools,
    get_agent_builtin_tools,
    get_all_builtin_tools,
    get_tool,
    get_full_script_tool
)

# ── Processing ───────────────────────────────────────────────
from .processing_api import (
    add_preprocess,
    edit_preprocess,
    remove_preprocess,
    add_postprocess,
    edit_postprocess,
    remove_postprocess,
    get_preprocess_script,
    get_postprocess_script,
)

# ── Monitoring ───────────────────────────────────────────────
from .monitoring_api import (
    get_prompt_history,
    get_prompt_from_hash,
    get_run_history,
    get_run_details,
    get_token_usage,
    get_audit_logs,
    get_audit_log_from_timestamp,
)

# ── Models / Providers ───────────────────────────────────────
from .model_api import (
    get_model_info,
    get_supported_providers,
    get_supported_models,
    get_supported_models_by_provider,
)
from agentsflow.errors import (
    AgentsFlowError,
    AgentsFlowConfigError,
    AgentsFlowLogError,
    AgentsFlowToolError,
    MaxToolRoundsError,
    LLMProviderError,
    LLMAuthenticationError,
    LLMInvalidRequestError,
    LLMRateLimitError,
    LLMServerError,
)

__all__ = [
    # Project
    "create_project", "edit_project", "get_project",
    # Agent
    "create_agent", "edit_agent", "delete_agent",
    "duplicate_agent", "validate_agent", "get_agent_config", "get_all_agents", "push_agent_to_prod",
    # Tools
    "add_tool", "edit_tool", "remove_tool",
    "get_custom_tools", "get_agent_builtin_tools", "get_all_builtin_tools",
    "get_tool", "add_builtin_tool","get_full_script_tool"

    # Processing
    "add_preprocess", "edit_preprocess", "remove_preprocess",
    "add_postprocess", "edit_postprocess", "remove_postprocess",
    "get_preprocess_script", "get_postprocess_script",
    # Monitoring
    "get_prompt_history", "get_run_history", "get_run_details", "get_token_usage",
    "get_audit_logs", "get_audit_log_from_timestamp", "get_prompt_from_hash",
    # Models / Providers
    "get_model_info", "get_supported_providers", "get_supported_models", "get_supported_models_by_provider",
    # Errors
    "AgentsFlowError", "AgentsFlowConfigError", "AgentsFlowLogError",
    "AgentsFlowToolError", "MaxToolRoundsError",
    "LLMProviderError", "LLMAuthenticationError", "LLMInvalidRequestError",
    "LLMRateLimitError", "LLMServerError",
]