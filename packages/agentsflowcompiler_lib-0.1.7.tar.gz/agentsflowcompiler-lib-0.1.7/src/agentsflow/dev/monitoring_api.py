"""
Monitoring API
==============
Public functions for tracking agent history: prompt changes, run logs, token usage.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
import logging
from uuid import UUID

logger = logging.getLogger(__name__)

from agentsflow.constants import (
    AGENTS_DIR,
    DEFAULT_AUDIT_LOGS_DIR,
    DEFAULT_AUDIT_LOGS_FILE,
    DEFAULT_PROMPT_HISTORY_DIR,
    DEFAULT_PROMPT_HISTORY_FILE,
    DEFAULT_RUN_HISTORY_DIR,
    DEFAULT_RUN_HISTORY_FILE,
    DEFAULT_TOKEN_USAGE_DIR,
    DEFAULT_TOKEN_USAGE_FILE,
)
from agentsflow.errors import AgentsFlowLogError
from agentsflow.dev.agent_api import _resolve_agent_context as _resolve_loaded_agent_context
from agentsflow.dev.helper.monitoring_helper import _parse_date
from agentsflow.dev.monitoring_types import (
    AgentContext,
    AuditLogEntry,
    PromptHistoryEntry,
    RunHistoryEntry,
    TokenUsageResponse,
)

def get_prompt_history(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> list[PromptHistoryEntry]:
    """
    Get prompt history entries for an agent.
    """
    ctx = _resolve_agent_context(base_dir, agent_name, agent_id)
    history_file_hash_file = ctx.prompt_history_dir / DEFAULT_PROMPT_HISTORY_FILE
    return _safe_read_json_list(history_file_hash_file)


def get_prompt_from_hash(
    base_dir: Path,
    hash: str,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> Optional[str]:
    """
    Get prompt from hash for an agent.
    """
    ctx = _resolve_agent_context(base_dir, agent_name, agent_id)
    for file in ctx.prompt_history_dir.glob("*.md"):
        if file.stem == hash or file.name == hash:
            with open(file, "r", encoding="utf-8") as f:
                return f.read()
    return None


def get_run_history(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
) -> list[RunHistoryEntry]:
    """
    Get run-history entries for an agent, optionally filtered by date range.

    Args:
        base_dir:    Base agents directory.
        agent_id:    Agent ID.
        agent_name:  Agent name.
        from_date:   Start date filter (inclusive, format: ``YYYY-MM-DD``).
        to_date:     End date filter (inclusive, format: ``YYYY-MM-DD``).

    Returns:
        List of run log entries across all matching dates.
    """
    ctx = _resolve_agent_context(base_dir, agent_name, agent_id)
    run_history_file = ctx.run_history_dir / DEFAULT_RUN_HISTORY_FILE
    # Parse date bounds
    date_from = _parse_date(from_date) if from_date else None
    date_to = _parse_date(to_date) if to_date else None

    all_entries: list[RunHistoryEntry] = []
    entries = _safe_read_json_list(run_history_file)
    for entry in entries:
        if not isinstance(entry, dict):
            continue

        entry_dt = _parse_entry_date(entry.get("date"))
        if date_from and (entry_dt is None or entry_dt.date() < date_from.date()):
            continue
        if date_to and (entry_dt is None or entry_dt.date() > date_to.date()):
            continue
        all_entries.append(entry)

    return all_entries


def get_run_details(
    base_dir: Path,
    rid: str,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> RunHistoryEntry | None:
    """
    Get a specific run-history entry by its unique run ID.

    Searches the agent's run-history log for an entry matching the given ``rid``.

    Args:
        base_dir:    Base agents directory.
        rid:         Unique run ID (UUID string assigned during ``Agent.run()``).
        agent_name:  Agent name.
        agent_id:    Agent ID.

    Returns:
        The matching run entry dict, or ``None`` if not found.
    """
    ctx = _resolve_agent_context(base_dir, agent_name, agent_id)
    run_history_file = ctx.run_history_dir / DEFAULT_RUN_HISTORY_FILE
    entries = _safe_read_json_list(run_history_file)
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        if entry.get("rid") == rid:
            return entry
    return None

def get_token_usage(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
) -> TokenUsageResponse:
    """
    Get token usage statistics for an agent.

    Args:
        base_dir:    Base agents directory.
        agent_name:  Agent name.
        from_date:   Start date filter (inclusive, ``YYYY-MM-DD``).
        to_date:     End date filter (inclusive, ``YYYY-MM-DD``).

    Returns:
        Dict with total tokens in/out, run count, and per-run breakdown::

            {
                "agent_name": "...",
                "total_runs": 5,
                "total_input_tokens": 1234,
                "total_output_tokens": 567,
                "runs": [
                    {"date": "...", "token_input": 100, "token_output": 50},
                    ...
                ]
            }
    """
    runs = get_run_history(
        base_dir=base_dir,
        agent_name=agent_name,
        agent_id=agent_id,
        from_date=from_date,
        to_date=to_date,
    )

    total_input = 0
    total_output = 0
    run_details = []

    for run in runs:
        t_in = run.get("token_input", 0)
        t_out = run.get("token_output", 0)
        total_input += t_in
        total_output += t_out
        run_details.append({
            "date": run.get("date", ""),
            "token_input": t_in,
            "token_output": t_out,
        })

    return {
        "agent_name": agent_name,
        "total_runs": len(runs),
        "total_input_tokens": total_input,
        "total_output_tokens": total_output,
        "runs": run_details,
    }



def get_audit_logs(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> list[AuditLogEntry]:
    """
    Get audit logs for an agent.
    """
    ctx = _resolve_agent_context(base_dir, agent_name, agent_id)
    audit_logs_file = ctx.audit_logs_dir / DEFAULT_AUDIT_LOGS_FILE
    return _safe_read_json_list(audit_logs_file)

def get_audit_log_from_timestamp(
    base_dir: Path,
    timestamp: str,
    agent_name: str,
    agent_id: Optional[UUID] = None,
) -> AuditLogEntry | None:
    """
    Get audit log from timestamp for an agent.
    """
    for entry in get_audit_logs(base_dir, agent_name=agent_name, agent_id=agent_id):
        if isinstance(entry, dict) and entry.get("timestamp") == timestamp:
            return entry
    return None
def _safe_read_json_list(path: Path) -> List[Any]:
    if not path.exists():
        return []
    try:
        raw = path.read_text(encoding="utf-8").strip()
        if not raw:
            return []
        # Support fallback to old JSON array if file starts with [
        if raw.startswith("["):
            data = json.loads(raw)
            return data if isinstance(data, list) else []
        
        # Parse as JSONL
        entries = []
        for line in raw.splitlines():
            line = line.strip()
            if line:
                entries.append(json.loads(line))
        return entries
    except FileNotFoundError:
        return []
    except json.JSONDecodeError as e:
        raise AgentsFlowLogError(f"Failed to decode JSON/JSONL from {path}: {e}") from e
    except Exception as e:
        raise AgentsFlowLogError(f"Unexpected error reading {path}: {e}") from e


def _parse_entry_date(raw: Any) -> Optional[datetime]:
    if not isinstance(raw, str):
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(raw, fmt)
        except ValueError:
            continue
    return None


def _resolve_agent_context(
    base_dir: Path,
    agent_name: Optional[str],
    agent_id: Optional[UUID],
) -> AgentContext:
    base_dir = Path(base_dir)
    try:
        _, agent_config, agent_dir = _resolve_loaded_agent_context(
            base_dir, agent_id, agent_name
        )
        return AgentContext(
            agent_dir=agent_dir,
            run_history_dir=agent_dir / agent_config.logs_config.run_history_dir,
            audit_logs_dir=agent_dir / agent_config.logs_config.audit_logs_dir,
            prompt_history_dir=agent_dir / agent_config.logs_config.prompt_history_dir,
            token_usage_dir=agent_dir / agent_config.logs_config.token_usage_dir,
        )
    except FileNotFoundError:
        if agent_name is None:
            raise
        agent_dir = base_dir / AGENTS_DIR / agent_name
        return AgentContext(
            agent_dir=agent_dir,
            run_history_dir=agent_dir / DEFAULT_RUN_HISTORY_DIR,
            audit_logs_dir=agent_dir / DEFAULT_AUDIT_LOGS_DIR,
            prompt_history_dir=agent_dir / DEFAULT_PROMPT_HISTORY_DIR,
            token_usage_dir=agent_dir / DEFAULT_TOKEN_USAGE_DIR,
        )


