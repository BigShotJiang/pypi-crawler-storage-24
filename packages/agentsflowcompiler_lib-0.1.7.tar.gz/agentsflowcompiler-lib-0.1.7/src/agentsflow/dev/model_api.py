"""
Model API
=========
Public development helpers for querying supported providers and models.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from agentsflow.llm.provider_registry import (
    get_supported_models as _get_supported_models,
    get_supported_providers as _get_supported_providers,
)

_MODELS_DIR = Path(__file__).resolve().parent.parent / "llm" / "models"


def get_model_info(model_id: str) -> dict[str, Any] | None:
    """
    Return the full JSON for a model by its model_id.

    Searches provider folders under ``llm/models/`` for a JSON file whose
    ``model.model_id`` matches the given name.

    Args:
        model_id: Model identifier (e.g. ``gpt-5-mini``, ``claude-opus-4-6``,
            ``amazon.nova-premier-v1:0``).

    Returns:
        The model JSON (metadata + provider + model) if found, else ``None``.
    """
    if not _MODELS_DIR.exists():
        return None
    for provider_dir in _MODELS_DIR.iterdir():
        if not provider_dir.is_dir():
            continue
        for json_path in provider_dir.glob("*.json"):
            try:
                data = json.loads(json_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            m = data.get("model") or {}
            if m.get("model_id") == model_id:
                return data
    return None


def get_supported_providers() -> list[str]:
    """Return the list of supported LLM providers."""
    return _get_supported_providers()


def get_supported_models(provider: Optional[str] = None) -> list[str]:
    """
    Return supported models, optionally filtered by provider.

    Args:
        provider: Provider name (e.g. ``openai``, ``anthropic``).

    Raises:
        ValueError: If *provider* is unknown.
    """
    return _get_supported_models(provider)


def get_supported_models_by_provider() -> dict[str, list[str]]:
    """Return all supported models grouped by provider."""
    return {
        provider: get_supported_models(provider)
        for provider in get_supported_providers()
    }
