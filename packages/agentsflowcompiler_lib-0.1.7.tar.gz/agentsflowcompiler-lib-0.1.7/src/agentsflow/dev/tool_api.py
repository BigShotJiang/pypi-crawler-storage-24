"""
Tool API
========
Public functions for managing agent tools (custom and built-in).

This module provides a complete interface for adding, editing, removing,
and querying tools for AgentsFlow agents.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

from agentsflow.constants import (
    AGENTS_DIR,
    DEFAULT_BUILTINS_DIR,
    DEFAULT_CUSTOM_TOOL_DIR,
    DEFAULT_TOOL_PYTHON_NAME,
    DEFAULT_TOOL_YAML_NAME,
)
from agentsflow.dev.agent_api import _resolve_agent_context
from agentsflow.utils.config_io import _write_agent_config
from agentsflow.dev.helper.tool_helper import (
    _apply_tool_rename_if_needed,
    _find_tool_ref,
    _get_tool_from_yaml,
    _get_yamls_tools_from_dir,
    _search_builtin_tool,
    _set_tool,
    _update_tool,
    _write_tool_script_if_provided,
)
from agentsflow.schema.tool_config_schema import (
    Tool,
    ToolConfig,
    ToolIdentityConfig,
    ToolReturnConfig,
)
from agentsflow.schema.tool_schema import (
    ToolParameterConfig,
    ToolParametersConfig,
)
from agentsflow.schema.agent_config_schema import AgentConfig
from agentsflow.utils.paths import normalize_agent_relative_path, resolve
from agentsflow.validate.agent import validate_agent
from agentsflow.validate.processing import check_process_valid, check_script_content_valid

# ══════════════════════════════════════════════════════════════════════════════
# Add / Edit / Remove
# ══════════════════════════════════════════════════════════════════════════════


def add_tool(
    base_dir: Path,
    script: str,
    identity: ToolIdentityConfig,
    config: ToolConfig,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> AgentConfig:
    """
    Add a custom tool to an agent.

    The script is stored at ``tools/custom_tools/<name>/tool.py`` (relative to
    the agent directory) unless ``config.path`` is explicitly set.
    Script content is validated (syntax and function presence) before writing.

    Args:
        base_dir:   Base agents directory.
        script:     Python source (must define ``config.function_name`` at top level).
        identity:   Tool name, description, and category (:class:`ToolIdentityConfig`).
        config:     Function name, parameters, and return spec (:class:`ToolConfig`).
                    ``config.path`` is auto-generated from ``identity.name`` when None.
        agent_name: Agent to add the tool to (alternative to agent_id).
        agent_id:   Agent's unique identifier (alternative to agent_name).

    Returns:
        The updated agent config.

    Raises:
        ValueError: If a tool with the same name already exists or the script is invalid.
        FileNotFoundError: If the agent config is not found.
    """
    _, agent_config, agent_dir = _resolve_agent_context(
        base_dir=base_dir, agent_id=agent_id, agent_name=agent_name
    )
    if tool_exists(tool_name=identity.name, agent_tools=agent_config.tools):
        raise ValueError(f"Tool {identity.name} already exists on agent {agent_config.identity.name}")

    rel_tool_path = config.path or Path(DEFAULT_CUSTOM_TOOL_DIR) / identity.name / DEFAULT_TOOL_PYTHON_NAME
    check_script_content_valid(script, config.function_name)
    tool_full_path = agent_dir / rel_tool_path
    tool_full_path.parent.mkdir(parents=True, exist_ok=True)
    tool_full_path.write_text(script, encoding="utf-8")

    effective_config = set_tool_config(
        path=rel_tool_path,
        function_name=config.function_name,
        parameters=config.parameters,
        returns=config.returns,
    )
    agent_config = _set_tool(agent_config, identity, effective_config, True)
    validate_agent(agent_dir=agent_dir, agent_config=agent_config)
    _write_agent_config(agent_dir=agent_dir, agent_config=agent_config)
    return agent_config
# ══════════════════════════════════════════════════════════════════════════════
# Add Built-in Tool
# ══════════════════════════════════════════════════════════════════════════════
def add_builtin_tool(
    base_dir: Path,
    tool_name: Optional[str] = None,
    tool_id: Optional[UUID] = None,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> AgentConfig:
    """
    Add a built-in tool to an agent.
    """
    _, agent_config, agent_dir = _resolve_agent_context(
        base_dir=base_dir, agent_id=agent_id, agent_name=agent_name
    )
    tool = _search_builtin_tool(
        all_tools=get_all_builtin_tools(DEFAULT_BUILTINS_DIR),
        tool_name=tool_name,
        tool_id=tool_id,
    )
    agent_config = _set_tool(agent_config, tool.identity, tool_config=None, custom=False)
    validate_agent(agent_dir=agent_dir, agent_config=agent_config)
    _write_agent_config(agent_dir=agent_dir, agent_config=agent_config)
    return agent_config

# ══════════════════════════════════════════════════════════════════════════════
# Edit Tool
# ══════════════════════════════════════════════════════════════════════════════
def edit_tool(
    base_dir: Path,
    tool_name: Optional[str] = None,
    tool_id: Optional[UUID] = None,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
    new_tool_name: Optional[str] = None,
    description: Optional[str] = None,
    category: Optional[str] = None,
    script: Optional[str] = None,
    config: Optional[ToolConfig] = None,
) -> AgentConfig:
    """
    Edit fields of an existing custom tool on an agent.

    Pass only the arguments you want to change; everything else is preserved.

    If ``script`` is provided it is validated then written to disk.
    If ``new_tool_name`` differs from the current name the tool directory is
    renamed and ``config.path`` is updated accordingly.

    Args:
        base_dir:      Base agents directory.
        tool_name:     Name of the tool to edit (alternative to tool_id).
        tool_id:       Tool UUID (alternative to tool_name).
        agent_name:    Agent that owns the tool (alternative to agent_id).
        agent_id:      Agent UUID (alternative to agent_name).
        new_tool_name: Rename the tool (renames directory when under default layout).
        description:   New description.
        category:      New category.
        script:        New script content (validated then overwrites file).
        config:        New function_name / path / parameters / returns (:class:`ToolConfig`).
                       Only non-None fields inside the object are applied.

    Returns:
        The updated agent config.

    Raises:
        KeyError: If the tool is not found.
        ValueError: If the script is invalid or the tool is built-in.
        FileNotFoundError: If the agent config is not found.
    """
    _, agent_config, agent_dir = _resolve_agent_context(
        base_dir=base_dir, agent_id=agent_id, agent_name=agent_name
    )

    tool = _find_tool_ref(tools=agent_config.tools, tool_name=tool_name, tool_id=tool_id)
    if not tool.custom:
        raise ValueError(f"Cannot edit built-in tool {tool.identity.name}")

    path_after_rename = _apply_tool_rename_if_needed(agent_dir, tool, new_tool_name)

    # Resolve the effective script file path
    tool_path = config.path if config else None
    effective_path = path_after_rename if path_after_rename is not None else (
        normalize_agent_relative_path(tool_path, agent_dir) if tool_path is not None else None
    )
    script_file_path: Optional[Path] = None
    if effective_path is not None:
        script_file_path = agent_dir / effective_path
    elif tool.config and tool.config.path:
        script_file_path = agent_dir / tool.config.path

    function_name = config.function_name if config else None
    function_name_to_use = function_name if function_name is not None else (tool.config.function_name if tool.config else None)
    _write_tool_script_if_provided(script, script_file_path, function_name_to_use)

    normalized_tool_path = path_after_rename if path_after_rename is not None else (
        normalize_agent_relative_path(tool_path, agent_dir) if tool_path is not None else None
    )
    updated_tool = _update_tool(
        tools=agent_config.tools,
        tool=tool,
        new_tool_name=new_tool_name,
        tool_path=normalized_tool_path,
        function_name=function_name,
        description=description,
        category=category,
        parameters=config.parameters if config else None,
        returns=config.returns if config else None,
    )

    agent_config.tools.remove(tool)
    agent_config = _set_tool(agent_config, updated_tool.identity, updated_tool.config, updated_tool.custom)

    validate_agent(agent_dir=agent_dir, agent_config=agent_config)
    _write_agent_config(agent_dir=agent_dir, agent_config=agent_config)
    return agent_config

# ══════════════════════════════════════════════════════════════════════════════
# Remove Tool
# ══════════════════════════════════════════════════════════════════════════════
def remove_tool(
    base_dir: Path, 
    tool_name: Optional[str] = None,
    tool_id: Optional[UUID] = None,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> AgentConfig:
    """
    Remove a tool from an agent.

    Args:
        base_dir:    Base agents directory.
        agent_name:  Agent that owns the tool.
        tool_name:   Name of the tool to remove.
        agent_id:    Agent id.

    Returns:
        Updated agent config.

    Example:
        >>> agent = remove_tool(
        ...     base_dir="/path/to/DEV",
        ...     agent_name="research_agent",
        ...     tool_name="old_search_tool"
        ... )
        >>> print(agent.model_dump_json())
    """
    _, agent_config, agent_dir = _resolve_agent_context(
        base_dir=base_dir, agent_id=agent_id, agent_name=agent_name
    )
    tool = _find_tool_ref(tools=agent_config.tools, tool_name=tool_name, tool_id=tool_id)
    agent_config.tools.remove(tool)
    validate_agent(agent_dir=agent_dir, agent_config=agent_config)
    _write_agent_config(agent_dir=agent_dir, agent_config=agent_config)
    return agent_config

# ══════════════════════════════════════════════════════════════════════════════
# Queries
# ══════════════════════════════════════════════════════════════════════════════


# ══════════════════════════════════════════════════════════════════════════════
# Get Custom Tools
# ══════════════════════════════════════════════════════════════════════════════
def get_custom_tools(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> List[Tool]:
    """
    Get all custom tools configured on an agent.

    Args:
        base_dir:   Base agents directory.
        agent_name: Agent name.
        agent_id: Agent id.
    Returns:
        List of custom tools.

    Example:
        >>> tools = get_custom_tools(base_dir=Path("/path/to/DEV"), agent_name="research_agent")
        >>> for tool in tools:
        ...     print(f"{tool.identity.name}: {tool.identity.description}")
        web_search: Search the web using DuckDuckGo
        analyze_data: Analyze dataset with statistics
    """
    _, agent_config, _ = _resolve_agent_context(
        base_dir=base_dir, agent_id=agent_id, agent_name=agent_name
    )
    return [t for t in (agent_config.tools or []) if t.custom]


# ══════════════════════════════════════════════════════════════════════════════
# Get Agent Builtin Tools
# ══════════════════════════════════════════════════════════════════════════════
def get_agent_builtin_tools(
    base_dir: Path,
    agent_id: Optional[UUID] = None,
    agent_name: Optional[str] = None,
) -> List[Tool]:
    """
    Get all built-in tools that an agent is using.

    Args:
        base_dir:   Base agents directory.
        agent_name: Agent name.
        agent_id: Agent id.
    Returns:
        List of built-in tools.

    Example:
        >>> tools = get_agent_builtin_tools(base_dir=Path("/path/to/DEV"), agent_id=agent_id)
        >>> for tool in tools:
        ...     print(f"{tool.identity.name}: {tool.identity.description}")
        calculator: Perform mathematical calculations
        file_reader: Read file contents
    """
    _, agent_config, _ = _resolve_agent_context(
        base_dir=base_dir, agent_id=agent_id, agent_name=agent_name
    )
    return [t for t in (agent_config.tools or []) if not t.custom]


# ══════════════════════════════════════════════════════════════════════════════
# Get All Builtin Tools
# ══════════════════════════════════════════════════════════════════════════════
def get_all_builtin_tools(
    tools_dir: Optional[Path] = DEFAULT_BUILTINS_DIR,
) -> List[Tool]:
    """
    Get all available built-in tools in the system.

    Args:
        tools_dir: Path to built-in tools directory (auto-detected if None).

    Returns:
        List of tool info dicts with name, description, parameters, etc.

    """
    tools_yaml_list = _get_yamls_tools_from_dir(Path(tools_dir), DEFAULT_TOOL_YAML_NAME)
    return [_get_tool_from_yaml(yaml_dict) for yaml_dict in tools_yaml_list]

# ══════════════════════════════════════════════════════════════════════════════
# Get Tool
# ══════════════════════════════════════════════════════════════════════════════
def get_tool(
    base_dir: Path,
    tool_name: Optional[str] = None,
    tool_id: Optional[UUID] = None,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
) -> Tool:
    """
    Get a tool by name or tool_id.
    """
    _, agent_config, _ = _resolve_agent_context(
        base_dir=base_dir, agent_id=agent_id, agent_name=agent_name
    )
    return _find_tool_ref(agent_config.tools, tool_name=tool_name, tool_id=tool_id)
    
def get_full_script_tool(
    base_dir: Path,
    agent_name: Optional[str] = None,
    agent_id: Optional[UUID] = None,
    tool_name: Optional[str] = None,
    tool_id: Optional[UUID] = None,
) -> str:
    """
    Get the full script content of a tool (custom or built-in).
    """
    _, agent_config, agent_dir = _resolve_agent_context(
        base_dir=base_dir, agent_id=agent_id, agent_name=agent_name
    )
    tool = _find_tool_ref(agent_config.tools, tool_name=tool_name, tool_id=tool_id)

    if tool.custom:
        if not tool.config or not tool.config.path:
            raise ValueError(f"Custom tool '{tool.identity.name}' has no script path configured.")
        script_path = agent_dir / tool.config.path
    else:
        script_path = DEFAULT_BUILTINS_DIR / tool.identity.name / DEFAULT_TOOL_PYTHON_NAME

    if not script_path.exists():
        raise FileNotFoundError(f"Tool script not found for '{tool.identity.name}': {script_path}")

    return script_path.read_text(encoding="utf-8")

# ══════════════════════════════════════════════════════════════════════════════
# Set Tool Identity
# ══════════════════════════════════════════════════════════════════════════════
def set_tool_identity(
    name: str,
    description: str,
    category: str,
    tool_id: Optional[UUID] = None,
) -> ToolIdentityConfig:
    """
    Create a ToolIdentityConfig object.

    Args:
        name:        Tool name (e.g., 'web_search').
        description: What this tool does.
        category:    Tool category (e.g., 'search', 'math').

    Returns:
        ToolIdentityConfig object.

    Example:
        >>> identity = set_tool_identity(
        ...     name="calculator",
        ...     description="Perform calculations",
        ...     category="math"
        ... )
        >>> print(identity.name)
        calculator
    """
    return ToolIdentityConfig(
        tool_id=tool_id or uuid4(),
        name=name,
        description=description,
        category=category,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Set Tool Parameter
# ══════════════════════════════════════════════════════════════════════════════
def set_tool_param(
    type: str,
    description: str,
    required: bool,
    default: Optional[Any] = None,
    enum: Optional[List[Any]] = None,
) -> ToolParameterConfig:
    """
    Create a ToolParameterConfig object.

    Args:
        type:        Parameter type ('string', 'integer', 'boolean', etc.).
        description: What this parameter does.
        required:    Whether this parameter is required.
        default:     Default value if not provided.
        enum:        List of allowed values.

    Returns:
        ToolParameterConfig object.

    Example:
        >>> param = set_tool_param(
        ...     type="string",
        ...     description="Search query",
        ...     required=True
        ... )
        >>>
        >>> param_with_enum = set_tool_param(
        ...     type="string",
        ...     description="Output format",
        ...     required=False,
        ...     enum=["json", "csv", "xml"],
        ...     default="json"
        ... )
    """
    return ToolParameterConfig(
        type=type,
        description=description,
        required=required,
        default=default,
        enum=enum,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Set Tool Config
# ══════════════════════════════════════════════════════════════════════════════
def set_tool_config(
    path: Path,
    function_name: str,
    parameters: Optional[ToolParametersConfig] = None,
    returns: Optional[ToolReturnConfig] = None,
) -> ToolConfig:
    """
    Create a ToolConfig object.

    Args:
        path:          Path to Python module containing tool function.
        function_name: Name of the callable in that module.
        parameters:    Input parameters schema.
        returns:       Return value description.

    Returns:
        ToolConfig object.

    Example:
        >>> from agentsflow.schema.tool_schema import ToolParametersConfig
        >>> config = set_tool_config(
        ...     path="search_tools.py",
        ...     function_name="search_web",
        ...     parameters=params,
        ...     returns=ToolReturnConfig(
        ...         type="array",
        ...         description="Search results"
        ...     )
        ... )
    """
    return ToolConfig(
        path=path,
        function_name=function_name,
        parameters=parameters,
        returns=returns,
    )
# ══════════════════════════════════════════════════════════════════════════════
# Convenience Functions
# ══════════════════════════════════════════════════════════════════════════════


# ══════════════════════════════════════════════════════════════════════════════
# Create Tool Parameters
# ══════════════════════════════════════════════════════════════════════════════
def create_tool_parameters(
    **params: Dict[str, Any],
) -> ToolParametersConfig:
    """
    Convenience function to create ToolParametersConfig from dict.

    Args:
        **params: Parameter definitions. Each key is the parameter name,
                  and value is a dict with 'type', 'description', 'required', etc.

    Returns:
        ToolParametersConfig object.

    Example:
        >>> params = create_tool_parameters(
        ...     query={
        ...         "type": "string",
        ...         "description": "Search query",
        ...         "required": True
        ...     },
        ...     max_results={
        ...         "type": "integer",
        ...         "description": "Max results",
        ...         "required": False,
        ...         "default": 10
        ...     }
        ... )
    """
    parameters = {}
    for param_name, param_spec in params.items():
        parameters[param_name] = ToolParameterConfig(
            type=param_spec["type"],
            description=param_spec.get("description", ""),
            required=param_spec.get("required", False),
            default=param_spec.get("default"),
            enum=param_spec.get("enum"),
        )

    return ToolParametersConfig(parameters=parameters)


def validate_tool_implementation(
    base_dir: Path,
    agent_name: str,
    tool_name: str,
) -> Dict[str, Any]:
    """
    Validate that a tool's implementation matches its schema.

    Args:
        base_dir:   Base agents directory.
        agent_name: Agent name.
        tool_name:  Tool name to validate.

    Returns:
        Dict with validation results:
        {
            "valid": bool,
            "errors": List[str],
            "warnings": List[str]
        }

    Example:
        >>> result = validate_tool_implementation(
        ...     base_dir="/path/to/DEV",
        ...     agent_name="research_agent",
        ...     tool_name="web_search"
        ... )
        >>> if result["valid"]:
        ...     print("Tool is valid")
        >>> else:
        ...     print("Errors:", result["errors"])
    """
    import importlib.util
    import inspect

    errors = []
    warnings = []

    try:
        # Get tool config
        tools = get_custom_tools(base_dir=Path(base_dir), agent_name=agent_name)
        tool = next((t for t in tools if t.identity.name == tool_name), None)

        if tool is None:
            return {"valid": False, "errors": [f"Tool '{tool_name}' not found"], "warnings": []}

        # Check if it's a custom tool
        if not tool.custom:
            warnings.append("Tool is built-in, skipping implementation validation")
            return {"valid": True, "errors": [], "warnings": warnings}

        if tool.config is None:
            return {"valid": False, "errors": ["Tool config missing"], "warnings": []}

        # Load implementation file
        agent_dir = Path(base_dir) / AGENTS_DIR / agent_name
        tool_path = Path(tool.config.path)

        if not tool_path.exists():
            errors.append(f"Tool file not found: {tool_path}")
            return {"valid": False, "errors": errors, "warnings": warnings}

        # Import module
        spec = importlib.util.spec_from_file_location("tool_module", tool_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        # Get function
        func_name = tool.config.function_name
        func = getattr(module, func_name, None)

        if not func:
            errors.append(
                f"Function '{func_name}' not found in {tool_path.name}"
            )
            return {"valid": False, "errors": errors, "warnings": warnings}

        # Check if callable
        if not callable(func):
            errors.append(f"'{func_name}' is not callable")
            return {"valid": False, "errors": errors, "warnings": warnings}

        # Check signature
        sig = inspect.signature(func)
        schema_params = set((tool.config.parameters or {}).keys())
        func_params = set(sig.parameters.keys())

        if schema_params != func_params:
            errors.append("Parameter mismatch between schema and implementation")
            errors.append(f"  Schema has: {sorted(schema_params)}")
            errors.append(f"  Function has: {sorted(func_params)}")
            return {"valid": False, "errors": errors, "warnings": warnings}

        # Check parameter types match (if type hints available)
        for param_name, param_config in (tool.config.parameters or {}).items():
            func_param = sig.parameters[param_name]

            # Check if parameter has default when not required
            if not param_config.required:
                if func_param.default == inspect.Parameter.empty:
                    warnings.append(
                        f"Parameter '{param_name}' is optional in schema "
                        f"but has no default in function"
                    )

        return {"valid": True, "errors": [], "warnings": warnings}

    except Exception as e:
        errors.append(f"Validation error: {str(e)}")
        return {"valid": False, "errors": errors, "warnings": warnings}


def tool_exists(tool_name: str, agent_tools:Optional[List[Tool]] = None) -> bool:
    if agent_tools is None or len(agent_tools) == 0:
        return False
    for tool in agent_tools:
        if tool.identity.name == tool_name:
            return True
    return False
