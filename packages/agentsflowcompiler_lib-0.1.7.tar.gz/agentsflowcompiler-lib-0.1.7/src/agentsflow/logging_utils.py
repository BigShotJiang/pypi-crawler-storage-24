"""
Structured Logging Utilities
=============================
Emit structured log events with rid, agent_name, event, and custom fields.
When AgentsFlowConfig.log_format is "json" (or env AGENTSFLOW_LOG_FORMAT=json),
messages are emitted as JSON strings.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any, Optional

logger = logging.getLogger("agentsflow")

# Set by config._apply_config when load_agents is called with config
_current_config: Optional[Any] = None


def _get_log_format() -> str:
    """Return current log format (text or json)."""
    if _current_config is not None:
        return getattr(_current_config, "log_format", "text")
    return os.environ.get("AGENTSFLOW_LOG_FORMAT", "text").lower()


def log_structured(
    level: int,
    event: str,
    rid: Optional[str] = None,
    agent_name: Optional[str] = None,
    **kwargs: Any,
) -> None:
    """
    Emit a structured log event with optional rid, agent_name, and extra fields.

    When log_format is "json", the message is a JSON string for handlers/formatters
    that can emit structured output. When "text", a human-readable message is used.
    """
    extra = {"event": event, "rid": rid, "agent_name": agent_name, **kwargs}
    extra = {k: v for k, v in extra.items() if v is not None}

    if _get_log_format() == "json":
        msg = json.dumps({"event": event, **extra}, default=str)
    else:
        parts = [f"event={event}"]
        if rid:
            parts.append(f"rid={rid}")
        if agent_name:
            parts.append(f"agent={agent_name}")
        for k, v in kwargs.items():
            if v is not None:
                parts.append(f"{k}={v}")
        msg = " ".join(parts)

    logger.log(level, msg, extra=extra)
