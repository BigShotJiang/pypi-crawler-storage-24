"""
Processing function validation helpers.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path


def check_process_exists(process_full_path: Path) -> bool:
    if not process_full_path.exists():
        raise ValueError(f"Process path '{process_full_path}' does not exist.")
    return True


def check_function_exists(
    process_full_path: Path, process_function_name: str
) -> bool:
    try:
        content = process_full_path.read_text(encoding="utf-8")
        pattern = rf"(?:def|async\s+def)\s+{re.escape(process_function_name)}\b"
        if not re.search(pattern, content):
            raise ValueError(
                f"Function '{process_function_name}' not found in {process_full_path.name}."
            )
    except (UnicodeDecodeError, IOError) as e:
        raise ValueError(f"Could not read file to check function: {e}")
    return True


def check_process_valid(
    process_full_path: Path, process_function_name: str
) -> bool:
    check_process_exists(process_full_path=process_full_path)
    check_function_exists(process_full_path=process_full_path, process_function_name=process_function_name)
    return True


def check_script_content_valid(script_content: str, function_name: str) -> bool:
    """
    Validate script content in-memory: syntax and presence of the given function.
    Raises ValueError on syntax error or if function_name is not defined at top level.
    """
    try:
        compile(script_content, "<script>", "exec")
    except SyntaxError as e:
        raise ValueError(f"Invalid Python syntax in script: {e}") from e
    try:
        tree = ast.parse(script_content)
    except SyntaxError as e:
        raise ValueError(f"Invalid Python syntax in script: {e}") from e
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == function_name:
            return True
    raise ValueError(
        f"Function '{function_name}' not found in script. "
        "Define it at module top level (e.g. def or async def)."
    )
