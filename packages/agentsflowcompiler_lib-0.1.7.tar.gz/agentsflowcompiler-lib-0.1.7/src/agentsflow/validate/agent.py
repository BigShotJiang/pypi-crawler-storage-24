"""
Agent configuration validation helpers.
"""

from __future__ import annotations

from pathlib import Path

from agentsflow.constants import (
    DEFAULT_AUDIT_LOGS_FILE,
    DEFAULT_PROMPT_HISTORY_FILE,
    DEFAULT_RUN_HISTORY_FILE,
    DEFAULT_TOKEN_USAGE_FILE,
)
from agentsflow.schema.agent_config_schema import AgentConfig, ProcessingConfig
from agentsflow.schema.tool_config_schema import Tool
from agentsflow.utils.paths import resolve
from agentsflow.validate.processing import check_process_valid


def validate_agent(agent_config: AgentConfig, agent_dir: Path) -> None:
    validate_agent_config(agent_config)
    validate_agent_dir(agent_dir)
    validate_agent_prompts(agent_config, agent_dir)
    validate_agent_logs(agent_config, agent_dir)
    validate_agent_tools(agent_config, agent_dir)
    validate_agent_pre_post_process(agent_config, agent_dir)


def validate_agent_tools(agent_config: AgentConfig, agent_dir: Path) -> None:
    if agent_config.tools is None or len(agent_config.tools) == 0:
        return
    for tool in agent_config.tools:
        if tool.custom:
            validate_agent_custom_tool(tool, agent_dir)
def validate_agent_custom_tool(tool: Tool, agent_dir: Path) -> None:
    if tool.config is None:
        raise ValueError("Custom tool config is required")
    if not tool.config.path:
        raise ValueError("Custom tool path is required")
    if not tool.config.function_name:
        raise ValueError("Custom tool function name is required")
    if not tool.config.parameters:
        raise ValueError("Custom tool parameters are required")
    if not tool.config.returns:
        raise ValueError("Custom tool returns are required")
    if not tool.identity.name:
        raise ValueError("Custom tool name is required")
    if not tool.identity.description:
        raise ValueError("Custom tool description is required")
    if not tool.identity.category:
        raise ValueError("Custom tool category is required")
    if not (agent_dir / tool.config.path).exists():
        raise FileNotFoundError(f"Custom tool path does not exist: {tool.config.path}")
    tool_full_path = agent_dir / tool.config.path
    if not check_process_valid(process_full_path=tool_full_path, process_function_name=tool.config.function_name):
        raise ValueError(f"Custom tool {tool.identity.name} is invalid: {tool.config.path} {tool.config.function_name}")
def validate_agent_pre_process(pre_process: ProcessingConfig, _agent_dir: Path) -> None:
    if not pre_process.path:
        raise ValueError("Pre-process path is required")
    if not pre_process.function_name:
        raise ValueError("Pre-process function name is required")


def validate_agent_post_process(post_process: ProcessingConfig, _agent_dir: Path) -> None:
    if not post_process.path:
        raise ValueError("Post-process path is required")
    if not post_process.function_name:
        raise ValueError("Post-process function name is required")


def validate_agent_config(agent_config: AgentConfig) -> None:
    if not agent_config.identity.name:
        raise ValueError("Agent name is required")
    if not agent_config.model_settings.model:
        raise ValueError("Agent model is required")


def validate_agent_dir(agent_dir: Path) -> None:
    if not agent_dir.exists():
        raise FileNotFoundError(f"Agent directory does not exist: {agent_dir}")
    if not agent_dir.is_dir():
        raise NotADirectoryError(f"Expected a directory: {agent_dir}")


def validate_agent_prompts(agent_config: AgentConfig, agent_dir: Path) -> None:
    prompt_fields = {
        "instruction_path": agent_config.prompt_config.instruction_path,
        "think_path": agent_config.prompt_config.think_path,
        "return_path": agent_config.prompt_config.return_path,
        "example_path": agent_config.prompt_config.example_path,
        "next_model_rule_path": agent_config.prompt_config.next_model_rule_path,
    }
    for field, path in prompt_fields.items():
        if path is not None:
            resolved = resolve(path, agent_dir)
            if not resolved.exists():
                raise FileNotFoundError(
                    f"Prompt file for '{field}' not found: {resolved}"
                )


def validate_agent_logs(agent_config: AgentConfig, agent_dir: Path) -> None:
    checks = (
        ("run_history_dir", agent_config.logs_config.run_history_dir, DEFAULT_RUN_HISTORY_FILE),
        ("audit_logs_dir", agent_config.logs_config.audit_logs_dir, DEFAULT_AUDIT_LOGS_FILE),
        ("prompt_history_dir", agent_config.logs_config.prompt_history_dir, DEFAULT_PROMPT_HISTORY_FILE),
        ("token_usage_dir", agent_config.logs_config.token_usage_dir, DEFAULT_TOKEN_USAGE_FILE),
    )
    for field, path, filename in checks:
        if path is None:
            continue
        resolved_dir = resolve(path, agent_dir)
        if not resolved_dir.exists():
            raise FileNotFoundError(f"Log directory for '{field}' not found: {resolved_dir}")
        if not resolved_dir.is_dir():
            raise NotADirectoryError(f"Expected log directory for '{field}': {resolved_dir}")
        resolved_file = resolved_dir / filename
        if not resolved_file.exists():
            raise FileNotFoundError(f"Log file for '{field}' not found: {resolved_file}")


def validate_agent_pre_post_process(agent_config: AgentConfig, agent_dir: Path) -> None:
    configs = [
        ("pre_process_path", agent_config.preprocess_config if agent_config.preprocess_config else None),
        ("post_process_path", agent_config.postprocess_config if agent_config.postprocess_config else None),
    ]
    for field, cfg in configs:
        if cfg is None:
            continue
        if field == "pre_process_path":
            validate_agent_pre_process(cfg, agent_dir)
        else:
            validate_agent_post_process(cfg, agent_dir)
        resolved = resolve(cfg.path, agent_dir)
        if not resolved.exists():
            raise FileNotFoundError(
                f"Processing file for '{field}' not found: {resolved}"
            )
