"""
AgentsFlowConfig — SDK-Wide Settings
=====================================
Central configuration for logging level, network logger silencing, and log format.
Per-agent settings (timeout, retry, base_url) remain in AgentConfig.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Literal

_NOISY_LOGGERS = ("chromadb", "posthog", "urllib3", "backoff", "httpx")


@dataclass
class AgentsFlowConfig:
    """
    SDK-wide configuration for logging and observability.

    Pass to ``load_agents(..., config=...)`` to apply.
    """

    log_level: str = "WARNING"
    """Log level for the agentsflow logger (e.g. DEBUG, INFO, WARNING)."""

    silence_network_loggers: bool = False
    """When True, set chromadb, posthog, urllib3, backoff, httpx to CRITICAL."""

    log_format: Literal["text", "json"] = "text"
    """Output format for structured logs. Use 'json' for machine-readable logs."""


def _apply_config(config: AgentsFlowConfig) -> None:
    """Apply config to SDK loggers. Called by load_agents when config is provided."""
    import agentsflow.logging_utils as _logging_mod
    _logging_mod._current_config = config  # type: ignore[attr-defined]

    sdk_logger = logging.getLogger("agentsflow")
    level = getattr(logging, config.log_level.upper(), logging.WARNING)
    sdk_logger.setLevel(level)

    if config.silence_network_loggers:
        for name in _NOISY_LOGGERS:
            logging.getLogger(name).setLevel(logging.CRITICAL)
