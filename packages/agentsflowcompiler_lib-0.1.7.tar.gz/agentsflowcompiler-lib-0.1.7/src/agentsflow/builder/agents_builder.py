"""
Agent Builder
=============
Single Responsibility: reads YAML configs and constructs Agent instances.

SOLID: Dependency Inversion — depends on AgentConfig and Agent abstractions,
       not on specific file structure details.
"""

from __future__ import annotations
from dotenv import dotenv_values    
import os
import logging
from pathlib import Path
from typing import Dict, Optional

import yaml

from agentsflow.constants import CONFIG_DIR, AGENT_MANIFEST_FILE
from agentsflow.errors import AgentsFlowConfigError
from agentsflow.schema import AgentConfig, ApiKeyConfig, ApiKeyMethod
from agentsflow.llm.provider_registry import (
    get_default_api_key_env,
    provider_requires_api_key,
)
from agentsflow.agent import Agent
from agentsflow.utils.manifest_io import _load_all_agents_from_manifest

logger = logging.getLogger(__name__)




# ── API Key Resolution ───────────────────────────────────────


def resolve_api_key(api_key_config: ApiKeyConfig, provider: str) -> str:
    """Resolve the API key for an agent based on its model provider."""
    # Set the API key variable name for the provider or from the config
    api_key_var = api_key_config.api_key_variable or get_default_api_key_env(provider)
    if not api_key_var and not provider_requires_api_key(provider):
        return ""
    if not api_key_var:
        raise AgentsFlowConfigError(
            f"No API key variable name found for provider: {provider}"
        )

    # Environment Variables
    if api_key_config.api_key_method == ApiKeyMethod.ENV_VAR:
        value = os.environ.get(api_key_var)
        if not value:
            raise AgentsFlowConfigError(
                f"Environment variable '{api_key_var}' not set."
            )
        return value

    # Raw text file (file content is the key)
    if api_key_config.api_key_method == ApiKeyMethod.FILE:
        if not api_key_config.api_key_path:
            raise AgentsFlowConfigError("api_key_path is required for FILE method")
        path = Path(api_key_config.api_key_path).resolve()
        if not path.exists():
            raise FileNotFoundError(f"API key file not found: {path}")
        value = path.read_text(encoding="utf-8").strip()
        if not value:
            raise AgentsFlowConfigError(f"API key file is empty: {path}")
        return value

    # .env file (KEY=VALUE format; does not pollute os.environ)
    if api_key_config.api_key_method == ApiKeyMethod.ENV_FILE:
        if not api_key_config.api_key_path:
            raise AgentsFlowConfigError("api_key_path is required for ENV_FILE method")
        secrets = dotenv_values(dotenv_path=str(api_key_config.api_key_path))
        value = secrets.get(api_key_var)
        if not value:
            raise AgentsFlowConfigError(
                f"Variable '{api_key_var}' not found in file {api_key_config.api_key_path}"
            )
        return value.strip() if isinstance(value, str) else str(value)
# ── Build Agents ─────────────────────────────────────────────


def build_agents(agents_dir: Path) -> Dict[str, Agent]:
    """Build all Agent instances from the agents directory."""
    agents_dir = Path(agents_dir)
    agents_configs = _load_all_agents_from_manifest(agents_dir)
    if not agents_configs:
        raise AgentsFlowConfigError("No agents configs found")

    agents: Dict[str, Agent] = {}
    errors: Dict[str, str] = {}
    for agent_config in agents_configs:
        try:
            api_key = resolve_api_key(agent_config.model_settings.api_key_config, agent_config.model_settings.provider)
            agents[agent_config.identity.name] = Agent(
                base_agents_dir=agents_dir,
                config=agent_config,
                api_key=api_key,
            )
        except Exception as e:
            errors[agent_config.identity.name] = str(e)
            logger.error(f"Failed to build agent '{agent_config.identity.name}': {e}")
            
    if errors:
        raise AgentsFlowConfigError(
            f"Failed to build {len(errors)} agent(s): "
            + "; ".join(f"{name}: {err}" for name, err in errors.items())
        )

    return agents
