"""
builder package
===============
Public API::

    from builder import build_agents
"""

from .agents_builder import build_agents

__all__ = ["build_agents"]
