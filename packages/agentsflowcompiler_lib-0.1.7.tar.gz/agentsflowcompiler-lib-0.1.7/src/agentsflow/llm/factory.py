"""
LLM Client Factory
==================
Provider detection and client instantiation.

SOLID: Open/Closed Principle
    → Adding a new provider = add one file + register here.
    → No existing code needs to change.

SOLID: Dependency Inversion
    → Returns the abstract ``LLMClient``, consumers never touch concrete classes.
"""

from __future__ import annotations

import logging
from typing import Optional

from .base import LLMClient
from .openai_client import OpenAIClient
from .anthropic_client import AnthropicClient
from .google_client import GoogleClient
from .amazon_client import AmazonClient
from .mistral_client import MistralClient
from .cohere_client import CohereClient
from .ai21_client import AI21Client
from .provider_registry import (
    get_provider_prefix_map,
    get_provider_model_map,
    get_supported_providers,
)


from .openai_compatible_client import OpenAICompatibleClient

# ── Provider Registry ────────────────────────────────────────
# To add a new provider:
#   1. Create  llm/new_provider_client.py  implementing LLMClient
#   2. Add prefix → provider mapping below
#   3. Add provider → class mapping below
#   That's it — Open/Closed Principle in action.

_PROVIDER_MAP: dict[str, str] = get_provider_prefix_map()
_MODEL_MAP: dict[str, str] = get_provider_model_map()

_CLIENT_CLASSES: dict[str, type[LLMClient]] = {
    "openai":       OpenAIClient,         # keep — has special o1/o3 logic if any
    "anthropic":    AnthropicClient,      # keep — different API
    "google":       GoogleClient,         # keep — different API
    "mistral":      MistralClient,        # keep — uses mistral SDK
    "cohere":       CohereClient,         # keep — uses cohere SDK
    "ai21":         AI21Client,           # keep — uses ai21 SDK
    "microsoft":    OpenAICompatibleClient,
    "amazon":       AmazonClient,         # keep — verify if truly OpenAI-compatible
    "xai":          OpenAICompatibleClient,
    "deepseek":     OpenAICompatibleClient,
    "perplexity":   OpenAICompatibleClient,
    "meta":         OpenAICompatibleClient,
    "ollama":       OpenAICompatibleClient,
}


def detect_provider(model: str) -> str:
    """Auto-detect the provider from exact model name or prefix."""
    model_lower = model.lower()
    
    # 1. Exact match first
    if model_lower in _MODEL_MAP:
        return _MODEL_MAP[model_lower]
        
    # 2. Prefix fallback
    for prefix, provider in sorted(
        _PROVIDER_MAP.items(), key=lambda item: len(item[0]), reverse=True
    ):
        if model_lower.startswith(prefix):
            return provider
            
    raise ValueError(
        f"Unknown model '{model}'. Cannot detect provider.\n"
        f"Supported prefixes: {list(_PROVIDER_MAP.keys())}"
    )


def create_llm_client(
    model: str,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    provider: Optional[str] = None,
) -> LLMClient:
    """
    Factory that returns the right ``LLMClient`` for *model*.

    Provider is auto-detected from the model name unless *provider*
    is explicitly given.
    """
    if provider is None:
        provider = detect_provider(model)

    client_cls = _CLIENT_CLASSES.get(provider)
    if client_cls is None:
        raise ValueError(
            f"Unknown provider '{provider}'. Supported: {get_supported_providers()}"
        )

    return client_cls(model=model, api_key=api_key, base_url=base_url)
