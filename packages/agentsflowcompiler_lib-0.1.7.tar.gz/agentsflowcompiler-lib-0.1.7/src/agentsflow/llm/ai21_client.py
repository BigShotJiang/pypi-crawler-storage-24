"""
AI21 Provider
=============
Uses the official AI21 SDK.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from .openai_compatible_client import BaseOpenAICompatibleClient


class AI21Client(BaseOpenAICompatibleClient):
    def __init__(self, model: str, api_key: Optional[str], base_url: Optional[str] = None):
        super().__init__(model, api_key, base_url)
        try:
            from ai21 import AI21Client as _AI21Client
        except ImportError as e:
            raise RuntimeError(
                "AI21 SDK is not installed. Install with: pip install ai21"
            ) from e

        kwargs: Dict[str, Any] = {"api_key": api_key}
        if base_url:
            kwargs["base_url"] = base_url
        self._client = _AI21Client(**kwargs)

    @property
    def provider_name(self) -> str:
        return "ai21"

    def _invoke_chat(self, kwargs: Dict[str, Any]) -> Any:
        try:
            return self._client.chat.completions.create(**kwargs)
        except Exception as e:
            raise RuntimeError(f"AI21 call failed: {e}") from e
