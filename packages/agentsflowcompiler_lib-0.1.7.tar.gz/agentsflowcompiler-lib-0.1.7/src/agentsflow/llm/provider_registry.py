"""
Provider Registry
=================
Single source of truth for provider metadata shared across the LLM layer.
"""

from __future__ import annotations

from typing import Any, Optional, TypedDict


class ProviderMetadata(TypedDict, total=False):
    prefixes: list[str]
    api_key_env: str | None
    requires_api_key: bool
    models: list[str]
    base_url_env: str
    default_base_url: str


_PROVIDER_METADATA: dict[str, ProviderMetadata] = {
    "openai": {
        "prefixes": ["gpt-", "o1-", "o3-", "chatgpt-"],
        "api_key_env": "OPENAI_API_KEY",
        "requires_api_key": True,
        "models": [
            "gpt-4",
            "gpt-4o",
            "gpt-4o-mini",
            "o1-preview",
            "o3-mini",
            "chatgpt-4o-latest",
        ],
    },
    "anthropic": {
        "prefixes": ["claude-"],
        "api_key_env": "ANTHROPIC_API_KEY",
        "requires_api_key": True,
        "models": [
            "claude-3-5-sonnet-20241022",
            "claude-3-7-sonnet-20250219",
        ],
    },
    "google": {
        "prefixes": ["gemini-"],
        "api_key_env": "GOOGLE_API_KEY",
        "requires_api_key": True,
        "models": [
            "gemini-1.5-pro",
            "gemini-1.5-flash",
            "gemini-2.0-flash",
        ],
    },
    "microsoft": {
        "prefixes": ["azure-"],
        "api_key_env": "AZURE_OPENAI_API_KEY",
        "requires_api_key": True,
        "base_url_env": "AZURE_OPENAI_ENDPOINT",
        "models": [
            "gpt-4o",
            "o3-mini",
        ],
    },
    "amazon": {
        "prefixes": ["amazon.nova"],
        "api_key_env": None,
        "requires_api_key": False,
        "models": [
            "amazon.nova-micro-v1:0",
            "amazon.nova-lite-v1:0",
            "amazon.nova-pro-v1:0",
        ],
    },
    "xai": {
        "prefixes": ["grok-"],
        "api_key_env": "XAI_API_KEY",
        "requires_api_key": True,
        "base_url_env": "XAI_BASE_URL",
        "default_base_url": "https://api.x.ai/v1",
        "models": [
            "grok-2",
            "grok-2-mini",
        ],
    },
    "mistral": {
        "prefixes": ["mistral-", "mixtral-", "codestral-", "ministral-", "pixtral-"],
        "api_key_env": "MISTRAL_API_KEY",
        "requires_api_key": True,
        "models": [
            "mistral-large-latest",
            "mistral-small-latest",
            "codestral-latest",
        ],
    },
    "cohere": {
        "prefixes": ["command", "embed"],
        "api_key_env": "COHERE_API_KEY",
        "requires_api_key": True,
        "models": [
            "command-r",
            "command-r-plus",
        ],
    },
    "deepseek": {
        "prefixes": ["deepseek-"],
        "api_key_env": "DEEPSEEK_API_KEY",
        "requires_api_key": True,
        "base_url_env": "DEEPSEEK_BASE_URL",
        "default_base_url": "https://api.deepseek.com/v1",
        "models": [
            "deepseek-chat",
            "deepseek-reasoner",
        ],
    },
    "ai21": {
        "prefixes": ["jamba", "j2-", "jurassic"],
        "api_key_env": "AI21_API_KEY",
        "requires_api_key": True,
        "models": [
            "jamba-1.5-large",
            "jamba-1.5-mini",
        ],
    },
    "perplexity": {
        "prefixes": ["sonar"],
        "api_key_env": "PERPLEXITY_API_KEY",
        "requires_api_key": True,
        "base_url_env": "PERPLEXITY_BASE_URL",
        "default_base_url": "https://api.perplexity.ai",
        "models": [
            "sonar",
            "sonar-pro",
        ],
    },
    "meta": {
        "prefixes": ["llama-"],
        "api_key_env": "META_API_KEY",
        "requires_api_key": True,
        "base_url_env": "META_API_BASE_URL",
        "default_base_url": "https://api.llama.com/compat/v1",
        "models": [
            "llama-3.1-8b-instruct",
            "llama-3.1-70b-instruct",
            "llama-3.3-70b-instruct",
        ],
    },
    "ollama": {
        "prefixes": ["llama", "mistral", "codellama", "phi-", "qwen", "deepseek"],
        "api_key_env": None,
        "requires_api_key": False,
        "default_base_url": "http://localhost:11434/v1",
        "models": [
            "llama3",
            "llama3.1",
            "llama3.2",
            "llama3.3",
        ],
    },
}


def get_supported_providers() -> list[str]:
    """Return all registered provider names."""
    return list(_PROVIDER_METADATA.keys())


def get_provider_prefix_map() -> dict[str, str]:
    """Return a flattened prefix -> provider mapping."""
    prefix_map: dict[str, str] = {}
    for provider, metadata in _PROVIDER_METADATA.items():
        for prefix in metadata.get("prefixes", []):
            prefix_map[str(prefix)] = provider
    return prefix_map


def get_provider_model_map() -> dict[str, str]:
    """Return a flattened exact model -> provider mapping."""
    model_map: dict[str, str] = {}
    for provider, metadata in _PROVIDER_METADATA.items():
        for model in metadata.get("models", []):
            # Only add if not already mapped, so primary provider (OpenAI) takes precedence over secondary (Azure)
            if str(model) not in model_map:
                model_map[str(model)] = provider
    return model_map


def get_provider_metadata(provider: str) -> ProviderMetadata:
    """Return the metadata dict for a provider."""
    metadata = _PROVIDER_METADATA.get(provider)
    if metadata is None:
        raise ValueError(
            f"Unknown provider '{provider}'. Supported: {get_supported_providers()}"
        )
    return metadata


def get_supported_models(provider: Optional[str] = None) -> list[str]:
    """Return supported models, optionally filtered by provider."""
    if provider is None:
        models: list[str] = []
        seen: set[str] = set()
        for provider_name in get_supported_providers():
            for model in get_supported_models(provider_name):
                if model not in seen:
                    seen.add(model)
                    models.append(model)
        return models
    return list(get_provider_metadata(provider).get("models", []))


def get_default_api_key_env(provider: str) -> Optional[str]:
    """Return the default environment variable for a provider's API key."""
    return get_provider_metadata(provider)["api_key_env"]  # type: ignore[return-value]


def provider_requires_api_key(provider: str) -> bool:
    """Return whether the provider requires an explicit API key value."""
    return bool(get_provider_metadata(provider).get("requires_api_key", True))


def get_default_base_url(provider: str) -> Optional[str]:
    """Return the provider's default base URL, if defined."""
    return get_provider_metadata(provider).get("default_base_url")  # type: ignore[return-value]


def get_base_url_env(provider: str) -> Optional[str]:
    """Return the provider's base URL env var, if defined."""
    return get_provider_metadata(provider).get("base_url_env")  # type: ignore[return-value]
