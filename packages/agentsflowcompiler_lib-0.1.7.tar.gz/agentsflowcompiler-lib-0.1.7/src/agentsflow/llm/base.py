"""
LLM Client — Abstract Base
===========================
Defines the ``LLMClient`` interface that every provider must implement.

SOLID: Interface Segregation + Dependency Inversion
    → All consumers depend on this abstraction, never on a concrete provider.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional

from agentsflow.types import (
    ChatMessage,
    LLMChatResponse,
    OpenAIToolSchema,
    AnthropicToolSchema,
)


class LLMClient(ABC):
    """
    Unified interface that all provider clients implement.

    Returns:
        ``str``  — for a plain text response.
        ``dict`` — ``{"tool_calls": [...]}`` when the model wants to call tools.
    """

    def __init__(
        self,
        model: str,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> None:
        self.model = model
        self._api_key = api_key
        self.base_url = base_url

    @property
    def api_key(self) -> Optional[str]:
        return self._api_key

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(model={self.model!r}, base_url={self.base_url!r}, api_key='***')"

    @abstractmethod
    def chat(
        self,
        messages: list[ChatMessage],
        temperature: float = 0.0,
        max_tokens: Optional[int] = None,
        response_format: Optional[dict[str, Any]] = None,
        tools: Optional[list[OpenAIToolSchema] | list[AnthropicToolSchema]] = None,
        timeout: Optional[float] = None,
    ) -> LLMChatResponse:
        """Send a list of messages and return the model's response."""
        ...

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Human-readable provider identifier, e.g. 'openai'."""
        ...
    @abstractmethod
    def count_tokens(self, text: str) -> int:
        """Count the number of tokens in the given text for this provider's model."""
        ...
