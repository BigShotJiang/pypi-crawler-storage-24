"""
Anthropic Provider
==================
Single Responsibility: handles only Anthropic (Claude) API communication.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from agentsflow.errors import (
    LLMAuthenticationError,
    LLMInvalidRequestError,
    LLMRateLimitError,
    LLMServerError,
)
from agentsflow.llm._error_utils import _extract_provider_request_id
from agentsflow.types import (
    AnthropicToolSchema,
    ChatMessage,
    LLMChatResponse,
    OpenAIToolSchema,
)

from .base import LLMClient


def _reraise_anthropic_error(e: Exception) -> None:
    """Map Anthropic SDK errors to agentsflow custom errors."""
    try:
        from anthropic import (
            APIConnectionError,
            APITimeoutError,
            AuthenticationError,
            BadRequestError,
            ConflictError,
            InternalServerError,
            NotFoundError,
            PermissionDeniedError,
            RateLimitError,
            UnprocessableEntityError,
        )
    except ImportError:
        raise LLMServerError(f"Anthropic call failed: {e}", cause=e) from e

    req_id = _extract_provider_request_id(e)
    if isinstance(e, (AuthenticationError, PermissionDeniedError)):
        raise LLMAuthenticationError(
            f"Anthropic auth failed: {e}", cause=e, provider_request_id=req_id
        ) from e
    if isinstance(e, (BadRequestError, NotFoundError, ConflictError, UnprocessableEntityError)):
        raise LLMInvalidRequestError(
            f"Anthropic invalid request: {e}", cause=e, provider_request_id=req_id
        ) from e
    if isinstance(e, RateLimitError):
        raise LLMRateLimitError(
            f"Anthropic rate limit: {e}", cause=e, provider_request_id=req_id
        ) from e
    if isinstance(e, (InternalServerError, APITimeoutError, APIConnectionError)):
        raise LLMServerError(
            f"Anthropic server error: {e}", cause=e, provider_request_id=req_id
        ) from e
    status = getattr(e, "status_code", None)
    if status in (401, 403):
        raise LLMAuthenticationError(
            f"Anthropic auth failed: {e}", cause=e, provider_request_id=req_id
        ) from e
    if status == 400:
        raise LLMInvalidRequestError(
            f"Anthropic invalid request: {e}", cause=e, provider_request_id=req_id
        ) from e
    if status == 429:
        raise LLMRateLimitError(
            f"Anthropic rate limit: {e}", cause=e, provider_request_id=req_id
        ) from e
    if status and 500 <= status < 600:
        raise LLMServerError(
            f"Anthropic server error: {e}", cause=e, provider_request_id=req_id
        ) from e
    raise LLMServerError(
        f"Anthropic call failed: {e}", cause=e, provider_request_id=req_id
    ) from e


class AnthropicClient(LLMClient):
    def __init__(self, model: str, api_key: str, base_url: Optional[str] = None):
        super().__init__(model, api_key, base_url)
        try:
            import anthropic
        except ImportError as e:
            raise RuntimeError(
                "Anthropic SDK is not installed. Install with: pip install anthropic"
            ) from e
        kwargs: Dict[str, Any] = {"api_key": api_key}
        if base_url:
            kwargs["base_url"] = base_url
        self._client = anthropic.Anthropic(**kwargs)

    @property
    def provider_name(self) -> str:
        return "anthropic"

    def count_tokens(self, text: str) -> int:
        """Count tokens using Anthropic SDK."""
        # Use a simple text block to count tokens
        return self._client.beta.messages.count_tokens(
            model=self.model,
            messages=[{"role": "user", "content": text}]
        ).input_tokens

    def chat(
        self,
        messages: list[ChatMessage],
        temperature: float = 0.0,
        max_tokens: Optional[int] = None,
        response_format: Optional[dict[str, Any]] = None,
        tools: Optional[list[OpenAIToolSchema] | list[AnthropicToolSchema]] = None,
        timeout: Optional[float] = None,
    ) -> LLMChatResponse:
        # Anthropic separates system from user messages
        system_prompt = None
        chat_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_prompt = msg["content"]
            else:
                chat_messages.append(msg)

        kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": chat_messages,
            "max_tokens": max_tokens or 4096,
            "temperature": temperature,
        }

        if system_prompt:
            kwargs["system"] = system_prompt

        # Accept both:
        # - OpenAI-style tools ({type: "function", function: {...}})
        # - Anthropic-style tools ({name, description, input_schema})
        if tools:
            if all(isinstance(t, dict) and "function" in t for t in tools):
                kwargs["tools"] = [
                    {
                        "name": t["function"]["name"],
                        "description": t["function"].get("description", ""),
                        "input_schema": t["function"].get(
                            "parameters", {"type": "object", "properties": {}}
                        ),
                    }
                    for t in tools
                ]
            else:
                kwargs["tools"] = tools

        if timeout is not None:
            kwargs["timeout"] = timeout

        try:
            response = self._client.messages.create(**kwargs)
        except Exception as e:
            _reraise_anthropic_error(e)

        tool_calls = []
        text_content = ""
        for block in response.content:
            if block.type == "tool_use":
                tool_calls.append({
                    "id": block.id,
                    "name": block.name,
                    "arguments": block.input,
                })
            elif block.type == "text":
                text_content += block.text

        if tool_calls:
            return {"tool_calls": tool_calls}
        return text_content
