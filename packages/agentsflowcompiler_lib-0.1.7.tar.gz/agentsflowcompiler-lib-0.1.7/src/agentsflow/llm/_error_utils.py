"""
LLM Error Utilities
===================
Helpers for extracting provider request IDs from SDK exceptions.
"""

from __future__ import annotations

from typing import Optional


def _extract_provider_request_id(e: Exception) -> Optional[str]:
    """
    Best-effort extraction of provider request ID from SDK exceptions.
    OpenAI and some other providers expose request_id or x-request-id.
    """
    # OpenAI SDK: request_id on error objects
    rid = getattr(e, "request_id", None) or getattr(e, "_request_id", None)
    if rid:
        return str(rid)
    # Try response headers (e.g. httpx/requests)
    response = getattr(e, "response", None)
    if response is not None:
        headers = getattr(response, "headers", None)
        if headers is not None and hasattr(headers, "get"):
            return headers.get("x-request-id") or headers.get("X-Request-Id")
    return None
