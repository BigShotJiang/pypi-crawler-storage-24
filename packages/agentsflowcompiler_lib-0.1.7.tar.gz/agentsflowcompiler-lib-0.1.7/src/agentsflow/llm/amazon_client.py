"""
Amazon Provider
===============
Uses Amazon Bedrock Converse API via boto3.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from agentsflow.errors import (
    LLMAuthenticationError,
    LLMInvalidRequestError,
    LLMRateLimitError,
    LLMServerError,
)
from agentsflow.llm._error_utils import _extract_provider_request_id
from agentsflow.types import (
    AnthropicToolSchema,
    ChatMessage,
    LLMChatResponse,
    OpenAIToolSchema,
)

from .base import LLMClient


def _reraise_amazon_error(e: Exception) -> None:
    """Map Amazon Bedrock/boto3 errors to agentsflow custom errors."""
    try:
        from botocore.exceptions import ClientError
    except ImportError:
        raise LLMServerError(f"Amazon Bedrock call failed: {e}", cause=e) from e

    req_id = _extract_provider_request_id(e)
    if isinstance(e, ClientError):
        response = getattr(e, "response", {}) or {}
        code = response.get("Error", {}).get("Code", "")
        status = response.get("ResponseMetadata", {}).get("HTTPStatusCode")
        if status in (401, 403) or "UnrecognizedClientException" in code or "AccessDenied" in code:
            raise LLMAuthenticationError(
                f"Amazon Bedrock auth failed: {e}", cause=e, provider_request_id=req_id
            ) from e
        if status == 400 or "ValidationException" in code:
            raise LLMInvalidRequestError(
                f"Amazon Bedrock invalid request: {e}", cause=e, provider_request_id=req_id
            ) from e
        if status == 429 or "ThrottlingException" in code or "ServiceQuotaExceeded" in code:
            raise LLMRateLimitError(
                f"Amazon Bedrock rate limit: {e}", cause=e, provider_request_id=req_id
            ) from e
        if status and 500 <= status < 600 or "ServiceException" in code or "InternalServer" in code:
            raise LLMServerError(
                f"Amazon Bedrock server error: {e}", cause=e, provider_request_id=req_id
            ) from e
    raise LLMServerError(
        f"Amazon Bedrock call failed: {e}", cause=e, provider_request_id=req_id
    ) from e


class AmazonClient(LLMClient):
    def __init__(self, model: str, api_key: Optional[str] = None, base_url: Optional[str] = None):
        super().__init__(model, api_key, base_url)
        try:
            import boto3
        except ImportError as e:
            raise RuntimeError(
                "boto3 is not installed. Install with: pip install boto3"
            ) from e

        region_name = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION")
        self._client = boto3.client("bedrock-runtime", region_name=region_name)

    @property
    def provider_name(self) -> str:
        return "amazon"

    def count_tokens(self, text: str) -> int:
        """
        Count tokens for Amazon Bedrock.
        Note: Bedrock doesn't provide a direct pre-flight counting API in Converse.
        Falls back to tiktoken (OpenAI-style) as a pragmatic surrogate.
        """
        from agentsflow.agent._utils import count_tokens
        return count_tokens(text, model=self.model)

    def chat(
        self,
        messages: list[ChatMessage],
        temperature: float = 0.0,
        max_tokens: Optional[int] = None,
        response_format: Optional[dict[str, Any]] = None,
        tools: Optional[list[OpenAIToolSchema] | list[AnthropicToolSchema]] = None,
        timeout: Optional[float] = None,
    ) -> LLMChatResponse:
        kwargs: Dict[str, Any] = {
            "modelId": self.model,
            "messages": self._to_bedrock_messages(messages),
            "inferenceConfig": {
                "temperature": temperature,
            },
        }
        if max_tokens:
            kwargs["inferenceConfig"]["maxTokens"] = max_tokens

        system_messages = self._extract_system_messages(messages)
        if system_messages:
            kwargs["system"] = system_messages
        if tools:
            kwargs["toolConfig"] = {"tools": self._to_bedrock_tools(tools)}

        try:
            response = self._client.converse(**kwargs)
        except Exception as e:
            _reraise_amazon_error(e)

        content_blocks = response.get("output", {}).get("message", {}).get("content", [])
        tool_calls = []
        text_parts = []
        for block in content_blocks:
            if "toolUse" in block:
                tool_use = block["toolUse"]
                tool_calls.append({
                    "id": tool_use["toolUseId"],
                    "name": tool_use["name"],
                    "arguments": tool_use.get("input", {}),
                })
            elif "text" in block:
                text_parts.append(block["text"])

        if tool_calls:
            return {"tool_calls": tool_calls}
        return "".join(text_parts)

    @staticmethod
    def _extract_system_messages(messages: list[ChatMessage]) -> List[Dict[str, str]]:
        return [{"text": msg["content"]} for msg in messages if msg["role"] == "system"]

    @staticmethod
    def _to_bedrock_tools(
        tools: list[OpenAIToolSchema] | list[AnthropicToolSchema],
    ) -> List[Dict[str, Any]]:
        return [
            {
                "toolSpec": {
                    "name": tool["function"]["name"],
                    "description": tool["function"].get("description", ""),
                    "inputSchema": {
                        "json": tool["function"].get("parameters", {"type": "object", "properties": {}})
                    },
                }
            }
            for tool in tools
        ]

    def _to_bedrock_messages(self, messages: list[ChatMessage]) -> List[Dict[str, Any]]:
        converted: List[Dict[str, Any]] = []
        for msg in messages:
            role = msg["role"]
            if role == "system":
                continue
            if role == "assistant" and msg.get("tool_calls"):
                bedrock_tool_calls = []
                for tc in msg["tool_calls"]:
                    args = tc["function"].get("arguments", {})
                    if isinstance(args, str):
                        import json
                        try:
                            args = json.loads(args)
                        except json.JSONDecodeError:
                            args = {}
                    
                    bedrock_tool_calls.append({
                        "toolUse": {
                            "toolUseId": tc["id"],
                            "name": tc["function"]["name"],
                            "input": args,
                        }
                    })
                
                converted.append({
                    "role": "assistant",
                    "content": bedrock_tool_calls,
                })
                continue
            if role == "tool":
                converted.append({
                    "role": "user",
                    "content": [
                        {
                            "toolResult": {
                                "toolUseId": msg["tool_call_id"],
                                "content": [{"text": str(msg["content"])}],
                            }
                        }
                    ],
                })
                continue
            converted.append({
                "role": "assistant" if role == "assistant" else "user",
                "content": [{"text": str(msg["content"] or "")}],
            })
        return converted
