"""
Mistral Provider
================
Uses the official Mistral SDK.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from .openai_compatible_client import BaseOpenAICompatibleClient


class MistralClient(BaseOpenAICompatibleClient):
    def __init__(self, model: str, api_key: Optional[str], base_url: Optional[str] = None):
        super().__init__(model, api_key, base_url)
        try:
            from mistralai import Mistral
        except ImportError as e:
            raise RuntimeError(
                "Mistral SDK is not installed. Install with: pip install mistralai"
            ) from e

        kwargs: Dict[str, Any] = {"api_key": api_key}
        if base_url:
            kwargs["server_url"] = base_url
        self._client = Mistral(**kwargs)

    @property
    def provider_name(self) -> str:
        return "mistral"

    def _invoke_chat(self, kwargs: Dict[str, Any]) -> Any:
        try:
            return self._client.chat.complete(**kwargs)
        except Exception as e:
            raise RuntimeError(f"Mistral call failed: {e}") from e
