"""
OpenAI-Compatible Provider Base
===============================
Shared implementation for providers exposing an OpenAI-compatible API.
"""

from __future__ import annotations

import json
import os
from abc import abstractmethod
from typing import Any, Dict, List, Optional

from agentsflow.errors import (
    LLMAuthenticationError,
    LLMInvalidRequestError,
    LLMRateLimitError,
    LLMServerError,
)
from agentsflow.llm._error_utils import _extract_provider_request_id
from agentsflow.types import (
    AnthropicToolSchema,
    ChatMessage,
    LLMChatResponse,
    OpenAIToolSchema,
)

from .base import LLMClient
from .provider_registry import get_base_url_env, get_default_base_url


class BaseOpenAICompatibleClient(LLMClient):
    @abstractmethod
    def _invoke_chat(self, kwargs: Dict[str, Any]) -> Any:
        """Subclasses implement this to call their specific API and return the response."""
        ...

    def count_tokens(self, text: str) -> int:
        """Count tokens using tiktoken (OpenAI-standard)."""
        from agentsflow.agent._utils import count_tokens
        return count_tokens(text, model=self.model)

    def chat(
        self,
        messages: list[ChatMessage],
        temperature: float = 0.0,
        max_tokens: Optional[int] = None,
        response_format: Optional[dict[str, Any]] = None,
        tools: Optional[list[OpenAIToolSchema] | list[AnthropicToolSchema]] = None,
        timeout: Optional[float] = None,
    ) -> LLMChatResponse:
        kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
        }
        if not self.model.startswith(("o1", "o3")):
            kwargs["temperature"] = temperature
            if max_tokens:
                kwargs["max_tokens"] = max_tokens
        if response_format:
            kwargs["response_format"] = response_format
        if tools:
            kwargs["tools"] = tools
        if timeout is not None:
            kwargs["timeout"] = timeout

        response = self._invoke_chat(kwargs)
        if not response.choices:
            raise LLMServerError(f"{self.provider_name} returned an empty choices list.")
        message = response.choices[0].message
        
        # Some clients use a dict-like message or object-like message
        # We can handle both cleanly or just assume object attribute access
        if getattr(message, "tool_calls", None):
            return {
                "tool_calls": [
                    {
                        "id": getattr(tc, "id", None) or f"{self.provider_name}_{tc.function.name}",
                        "name": tc.function.name,
                        "arguments": json.loads(tc.function.arguments),
                    }
                    for tc in message.tool_calls
                ]
            }
        return message.content


class OpenAICompatibleClient(BaseOpenAICompatibleClient):
    PROVIDER_NAME = ""

    def __init__(self, model: str, api_key: Optional[str], base_url: Optional[str] = None):
        super().__init__(model, api_key, base_url)
        try:
            import openai
        except ImportError as e:
            raise RuntimeError(
                "OpenAI SDK is not installed. Install with: pip install openai"
            ) from e

        resolved_base_url = base_url
        if not resolved_base_url:
            base_url_env = get_base_url_env(self.provider_name)
            if base_url_env:
                resolved_base_url = os.environ.get(base_url_env)
        if not resolved_base_url:
            resolved_base_url = get_default_base_url(self.provider_name)

        from .provider_registry import provider_requires_api_key
        if not api_key and provider_requires_api_key(self.provider_name):
            raise ValueError(
                f"API key is required for provider '{self.provider_name}' but was not provided."
            )

        kwargs: Dict[str, Any] = {"api_key": api_key or "placeholder"}
        if resolved_base_url:
            kwargs["base_url"] = resolved_base_url
        self._client = openai.OpenAI(**kwargs)

    @property
    def provider_name(self) -> str:
        if self.PROVIDER_NAME:
            return self.PROVIDER_NAME
        
        # Determine provider dynamically based on the model name
        from .provider_registry import get_provider_prefix_map, get_provider_model_map
        model_lower = self.model.lower()
        
        # 1. Exact match first
        model_map = get_provider_model_map()
        if model_lower in model_map:
            return model_map[model_lower]
            
        # 2. Prefix fallback
        for prefix, provider in sorted(
            get_provider_prefix_map().items(), key=lambda item: len(item[0]), reverse=True
        ):
            if model_lower.startswith(prefix):
                return provider
        return ""

    def _invoke_chat(self, kwargs: Dict[str, Any]) -> Any:
        try:
            from openai import (
                APIConnectionError,
                APITimeoutError,
                AuthenticationError,
                BadRequestError,
                ConflictError,
                InternalServerError,
                NotFoundError,
                OpenAIError,
                PermissionDeniedError,
                RateLimitError,
                UnprocessableEntityError,
            )
        except ImportError:
            raise LLMServerError(
                f"{self.provider_name} SDK is not installed. Install with: pip install openai"
            ) from None

        try:
            return self._client.chat.completions.create(**kwargs)
        except (AuthenticationError, PermissionDeniedError) as e:
            req_id = _extract_provider_request_id(e)
            raise LLMAuthenticationError(
                f"{self.provider_name} auth failed: {e}", cause=e, provider_request_id=req_id
            ) from e
        except (BadRequestError, NotFoundError, ConflictError, UnprocessableEntityError) as e:
            req_id = _extract_provider_request_id(e)
            raise LLMInvalidRequestError(
                f"{self.provider_name} invalid request: {e}", cause=e, provider_request_id=req_id
            ) from e
        except RateLimitError as e:
            req_id = _extract_provider_request_id(e)
            raise LLMRateLimitError(
                f"{self.provider_name} rate limit: {e}", cause=e, provider_request_id=req_id
            ) from e
        except (InternalServerError, APITimeoutError, APIConnectionError) as e:
            req_id = _extract_provider_request_id(e)
            raise LLMServerError(
                f"{self.provider_name} server error: {e}", cause=e, provider_request_id=req_id
            ) from e
        except OpenAIError as e:
            req_id = _extract_provider_request_id(e)
            status = getattr(e, "status_code", None)
            if status in (401, 403):
                raise LLMAuthenticationError(
                    f"{self.provider_name} auth failed: {e}", cause=e, provider_request_id=req_id
                ) from e
            if status == 400:
                raise LLMInvalidRequestError(
                    f"{self.provider_name} invalid request: {e}", cause=e, provider_request_id=req_id
                ) from e
            if status == 429:
                raise LLMRateLimitError(
                    f"{self.provider_name} rate limit: {e}", cause=e, provider_request_id=req_id
                ) from e
            if status and 500 <= status < 600:
                raise LLMServerError(
                    f"{self.provider_name} server error: {e}", cause=e, provider_request_id=req_id
                ) from e
            raise LLMServerError(
                f"{self.provider_name} call failed: {e}", cause=e, provider_request_id=req_id
            ) from e
