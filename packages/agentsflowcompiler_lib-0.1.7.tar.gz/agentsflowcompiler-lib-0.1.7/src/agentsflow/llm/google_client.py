"""
Google Gemini Provider
======================
Single Responsibility: handles only Google Gemini API communication.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from agentsflow.constants import DEFAULT_AGENT_TIMEOUT
from agentsflow.errors import (
    LLMAuthenticationError,
    LLMInvalidRequestError,
    LLMRateLimitError,
    LLMServerError,
)
from agentsflow.llm._error_utils import _extract_provider_request_id
from agentsflow.types import (
    AnthropicToolSchema,
    ChatMessage,
    LLMChatResponse,
    OpenAIToolSchema,
)

from .base import LLMClient


def _reraise_google_error(e: Exception) -> None:
    """Map Google GenAI SDK errors to agentsflow custom errors."""
    msg = str(e).lower()
    status = getattr(e, "status_code", None) or getattr(e, "code", None)
    req_id = _extract_provider_request_id(e)
    if status in (401, 403) or "401" in msg or "403" in msg or "permission" in msg or "authentication" in msg:
        raise LLMAuthenticationError(
            f"Google Gemini auth failed: {e}", cause=e, provider_request_id=req_id
        ) from e
    if status == 400 or "400" in msg or "invalid" in msg:
        raise LLMInvalidRequestError(
            f"Google Gemini invalid request: {e}", cause=e, provider_request_id=req_id
        ) from e
    if status == 429 or "429" in msg or "rate" in msg or "resource_exhausted" in msg or "quota" in msg:
        raise LLMRateLimitError(
            f"Google Gemini rate limit: {e}", cause=e, provider_request_id=req_id
        ) from e
    if status and 500 <= status < 600 or "500" in msg or "502" in msg or "503" in msg:
        raise LLMServerError(
            f"Google Gemini server error: {e}", cause=e, provider_request_id=req_id
        ) from e
    raise LLMServerError(
        f"Google Gemini call failed: {e}", cause=e, provider_request_id=req_id
    ) from e


class GoogleClient(LLMClient):
    def __init__(self, model: str, api_key: str, base_url: Optional[str] = None):
        super().__init__(model, api_key, base_url)
        try:
            from google import genai
            from google.genai import types as genai_types
        except ImportError as e:
            raise RuntimeError(
                "Google GenAI SDK is not installed. Install with: pip install google-genai"
            ) from e

        self._genai_client = genai.Client(
            api_key=api_key,
            http_options=genai_types.HttpOptions(timeout=int(DEFAULT_AGENT_TIMEOUT * 1000)),
        )

    @property
    def provider_name(self) -> str:
        return "google"

    def count_tokens(self, text: str) -> int:
        """Count tokens using Google GenAI SDK."""
        response = self._genai_client.models.count_tokens(
            model=self.model,
            contents=[text]
        )
        return response.total_tokens

    def chat(
        self,
        messages: list[ChatMessage],
        temperature: float = 0.0,
        max_tokens: Optional[int] = None,
        response_format: Optional[dict[str, Any]] = None,
        tools: Optional[list[OpenAIToolSchema] | list[AnthropicToolSchema]] = None,
        timeout: Optional[float] = None,
    ) -> LLMChatResponse:
        try:
            from google.genai import types
        except ImportError as e:
            raise RuntimeError(
                "Google GenAI SDK is not installed. Install with: pip install google-genai"
            ) from e

        system_instruction = None
        contents = []
        for msg in messages:
            if msg["role"] == "system":
                system_instruction = msg["content"]
            elif msg["role"] == "user":
                contents.append(
                    types.Content(role="user", parts=[types.Part(text=msg["content"])])
                )
            elif msg["role"] == "assistant":
                contents.append(
                    types.Content(role="model", parts=[types.Part(text=msg["content"])])
                )

        timeout_ms = int((timeout or DEFAULT_AGENT_TIMEOUT) * 1000)
        http_options = types.HttpOptions(timeout=timeout_ms) if hasattr(types, "HttpOptions") else None

        config = types.GenerateContentConfig(temperature=temperature)
        if max_tokens:
            config.max_output_tokens = max_tokens
        if system_instruction:
            config.system_instruction = system_instruction
        if http_options:
            config.http_options = http_options

        # Convert OpenAI tool format → Gemini format
        if tools:
            declarations = [
                types.FunctionDeclaration(
                    name=t["function"]["name"],
                    description=t["function"].get("description", ""),
                    parameters=t["function"].get("parameters"),
                )
                for t in tools
            ]
            config.tools = [types.Tool(function_declarations=declarations)]

        try:
            response = self._genai_client.models.generate_content(
                model=self.model,
                contents=contents,
                config=config,
            )
        except Exception as e:
            _reraise_google_error(e)

        if response.candidates and response.candidates[0].content.parts:
            tool_calls = []
            text_parts = []
            for part in response.candidates[0].content.parts:
                if part.function_call:
                    tool_calls.append({
                        "id": f"gemini_{part.function_call.name}",
                        "name": part.function_call.name,
                        "arguments": dict(part.function_call.args)
                        if part.function_call.args
                        else {},
                    })
                elif part.text:
                    text_parts.append(part.text)

            if tool_calls:
                return {"tool_calls": tool_calls}
            return "".join(text_parts)

        return response.text
