"""
OpenAI Provider
===============
Single Responsibility: handles only OpenAI API communication.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from .openai_compatible_client import BaseOpenAICompatibleClient


class OpenAIClient(BaseOpenAICompatibleClient):
    def __init__(self, model: str, api_key: str, base_url: Optional[str] = None):
        super().__init__(model, api_key, base_url)
        from openai import OpenAI

        kwargs: Dict[str, Any] = {"api_key": api_key}
        if base_url:
            kwargs["base_url"] = base_url
        self._client = OpenAI(**kwargs)

    @property
    def provider_name(self) -> str:
        return "openai"

    def _invoke_chat(self, kwargs: Dict[str, Any]) -> Any:
        from openai import OpenAIError

        try:
            return self._client.chat.completions.create(**kwargs)
        except OpenAIError as e:
            raise RuntimeError(f"OpenAI call failed: {e}") from e
