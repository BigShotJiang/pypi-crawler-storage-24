"""
llm package
===========
Public API::

    from llm import LLMClient, create_llm_client, detect_provider, get_supported_providers
"""

from .base import LLMClient
from .factory import create_llm_client, detect_provider, get_supported_providers
from .provider_registry import get_default_api_key_env

__all__ = ["LLMClient", "create_llm_client", "detect_provider", "get_supported_providers", "get_default_api_key_env"]
