"""
Cohere Provider
===============
Uses the official Cohere SDK.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from agentsflow.errors import (
    LLMAuthenticationError,
    LLMInvalidRequestError,
    LLMRateLimitError,
    LLMServerError,
)
from agentsflow.llm._error_utils import _extract_provider_request_id
from agentsflow.types import (
    AnthropicToolSchema,
    ChatMessage,
    LLMChatResponse,
    OpenAIToolSchema,
)

from .base import LLMClient


def _reraise_cohere_error(e: Exception) -> None:
    """Map Cohere SDK errors to agentsflow custom errors."""
    msg = str(e).lower()
    status = getattr(e, "status_code", None) or getattr(e, "http_status", None)
    req_id = _extract_provider_request_id(e)
    if status in (401, 403) or "401" in msg or "403" in msg or "authentication" in msg:
        raise LLMAuthenticationError(
            f"Cohere auth failed: {e}", cause=e, provider_request_id=req_id
        ) from e
    if status == 400 or "400" in msg or "invalid" in msg or "bad request" in msg:
        raise LLMInvalidRequestError(
            f"Cohere invalid request: {e}", cause=e, provider_request_id=req_id
        ) from e
    if status == 429 or "429" in msg or "rate" in msg or "too many" in msg:
        raise LLMRateLimitError(
            f"Cohere rate limit: {e}", cause=e, provider_request_id=req_id
        ) from e
    if status and 500 <= status < 600 or "500" in msg or "502" in msg or "503" in msg:
        raise LLMServerError(
            f"Cohere server error: {e}", cause=e, provider_request_id=req_id
        ) from e
    raise LLMServerError(
        f"Cohere call failed: {e}", cause=e, provider_request_id=req_id
    ) from e


class CohereClient(LLMClient):
    def __init__(self, model: str, api_key: Optional[str], base_url: Optional[str] = None):
        super().__init__(model, api_key, base_url)
        try:
            import cohere
        except ImportError as e:
            raise RuntimeError(
                "Cohere SDK is not installed. Install with: pip install cohere"
            ) from e

        kwargs: Dict[str, Any] = {"api_key": api_key}
        if base_url:
            kwargs["base_url"] = base_url
        self._client = cohere.ClientV2(**kwargs)

    @property
    def provider_name(self) -> str:
        return "cohere"

    def chat(
        self,
        messages: list[ChatMessage],
        temperature: float = 0.0,
        max_tokens: Optional[int] = None,
        response_format: Optional[dict[str, Any]] = None,
        tools: Optional[list[OpenAIToolSchema] | list[AnthropicToolSchema]] = None,
        timeout: Optional[float] = None,
    ) -> LLMChatResponse:
        kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens:
            kwargs["max_tokens"] = max_tokens
        if tools:
            kwargs["tools"] = tools

        try:
            response = self._client.chat(**kwargs)
        except Exception as e:
            _reraise_cohere_error(e)

        message = getattr(response, "message", None)
        if message and getattr(message, "tool_calls", None):
            return {
                "tool_calls": [
                    {
                        "id": getattr(tc, "id", f"cohere_{tc.name}"),
                        "name": tc.name,
                        "arguments": getattr(tc, "parameters", {}) or {},
                    }
                    for tc in message.tool_calls
                ]
            }

        if message and getattr(message, "content", None):
            parts = []
            for part in message.content:
                text = getattr(part, "text", None)
                if text:
                    parts.append(text)
            if parts:
                return "".join(parts)
        return getattr(response, "text", "")
