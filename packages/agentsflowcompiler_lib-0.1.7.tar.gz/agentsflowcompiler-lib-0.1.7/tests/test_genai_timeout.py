from google import genai
from google.genai import types

try:
    config = types.GenerateContentConfig(http_options={"timeout": 60})
    print("Success: http_options accepted in GenerateContentConfig")
except Exception as e:
    print(f"Error: {e}")

try:
    http_opts = types.HttpOptions(timeout=60)
    config2 = types.GenerateContentConfig(http_options=http_opts)
    print("Success: HttpOptions object accepted in GenerateContentConfig")
except Exception as e:
    print(f"Error: {e}")
