import datetime
import os
import inspect

# Colors
class Colors:
    RESET = "\033[0m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    PURPLE = "\033[95m"

# File logging
LOG_DIR = "logs"
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

LOG_FILE = os.path.join(LOG_DIR, "bot.log")

def _write_file(message: str):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {message}\n")

def _log(color, level, message):
    frame = inspect.stack()[2]
    filename = os.path.basename(frame.filename)
    time = datetime.datetime.now().strftime("%H:%M:%S")

    print(f"{color}[{time}] [{level}] [{filename}] {message}{Colors.RESET}")
    _write_file(f"[{level}] [{filename}] {message}")

# Logging functions
def info(message):    
    _log(Colors.BLUE, "INFO", message)

def success(message): 
    _log(Colors.GREEN, "SUCCESS", message)

def warn(message):    
    _log(Colors.YELLOW, "WARN", message)

def error(message):   
    _log(Colors.RED, "ERROR", message)

def debug(message):   
    _log(Colors.CYAN, "DEBUG", message)

def critical(message):
    _log(Colors.PURPLE, "CRITICAL", message)

# Helper
def format_exception(e):
    return f"{type(e).__name__}: {e}"