<div align="center">

# 🥝 KiwiLog

### A **beautiful, colorful logging utility** for Python

![Python](https://img.shields.io/badge/Python-3.x-blue?style=for-the-badge&logo=python)
![Status](https://img.shields.io/badge/status-active-success?style=for-the-badge)
![License](https://img.shields.io/badge/license-MIT-green?style=for-the-badge)

Elegant • Minimal • Readable • Colorful

</div>

---

# Overview

**KiwiLog** is a lightweight Python logging utility designed to make terminal output **clean, colorful, and easy to read**.

Instead of dealing with complex logging frameworks, KiwiLog provides **simple functions** for common log types.

Perfect for:

- CLI tools
- scripts
- debugging
- automation
- bots
- development utilities

---

<div align="center">
Available Commands / How to Use

KiwiLog provides simple, color-coded logging functions:

Command	Description	Example
info(msg)	General information	kiwilog.info("Server started")
debug(msg)	Debugging details	kiwilog.debug("Loading configuration")
warn(msg)	Warnings	kiwilog.warn("Low disk space")
error(msg)	Errors	kiwilog.error("Failed to connect")
success(msg)	Success messages	kiwilog.success("Build completed")
critical(msg)	Fatal or critical errors	kiwilog.critical("Database unavailable")
</div>

# 📦 Installation

```bash
pip install kiwilog