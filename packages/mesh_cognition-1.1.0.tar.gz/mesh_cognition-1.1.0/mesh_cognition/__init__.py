"""
MeshCognition SDK — Distributed intelligence through coupled neural networks.

Two coupling modes:
- SemanticCoupler: cosine drift, shared memory, LLM agents (default)
- NeuralCoupler: per-neuron τ, real Kuramoto r(t), CfC models

Usage:
    from mesh_cognition import MeshNode

    # Semantic mode (default)
    node = MeshNode(hidden_dim=64)

    # Neural mode (with tau from trained CfC model)
    from mesh_cognition import NeuralCouplingConfig
    node = MeshNode(hidden_dim=64, config=NeuralCouplingConfig(tau=model_tau))

Copyright (c) 2026 SYM.BOT Ltd. Apache 2.0 License.
"""

from .coupler import (
    CfCMeshCoupler,
    CouplingConfig,
    CouplingDecision,
    MeshCoupler,
    NeuralCouplingConfig,
    SemanticCoupler,
)
from .neural_coupler import NeuralCoupler
from .node import MeshNode
from .metrics import KuramotoMetricsLogger

__version__ = "1.1.0"
__all__ = [
    "MeshNode",
    "MeshCoupler",
    "SemanticCoupler",
    "NeuralCoupler",
    "CfCMeshCoupler",  # deprecated alias
    "CouplingConfig",
    "NeuralCouplingConfig",
    "CouplingDecision",
    "KuramotoMetricsLogger",
]
