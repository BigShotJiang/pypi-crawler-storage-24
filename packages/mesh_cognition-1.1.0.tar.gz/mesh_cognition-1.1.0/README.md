# mesh-cognition

**Autonomous Drift-Bounded Coupling for CfC Neural Networks**

Turn any AI agent into a mesh cognition node. The coupling is autonomous — the agent evaluates each peer's hidden state and decides for itself whether, how much, and which neurons to couple.

## Install

```bash
pip install mesh-cognition
```

## Quick Start

```python
from mesh_cognition import MeshNode

# Create a node matching your CfC model's hidden dimension
node = MeshNode(hidden_dim=64)

# After each CfC inference step — update local state
node.update_local_state(new_h1, new_h2, confidence=0.8)

# Add peer state (from network, another agent, etc.)
node.add_peer("peer-1", peer_h1, peer_h2, confidence=0.9)

# Before next inference — get coupled state
h1, h2 = node.coupled_state()
# Feed h1, h2 into your CfC model as hidden state inputs

# Check what the agent decided
print(node.kuramoto_order_parameter)  # r(t): 0=desync, 1=in sync
print(node.coupling_decisions)        # per-peer: aligned/guarded/rejected
```

## How It Works

The agent evaluates each peer's hidden state via cosine similarity drift:

- **Aligned** (drift ≤ 0.25): Strong coupling — agent trusts peer
- **Guarded** (0.25 < drift ≤ 0.5): Cautious coupling — reduced influence
- **Rejected** (drift > 0.5): Agent rejects peer state entirely

Each hidden dimension is coupled independently. Zero external dependencies.

## Links

- [Whitepaper](https://sym.bot/research/mesh-cognition)
- [GitHub](https://github.com/sym-bot/mesh-cognition-sdk)
- [SYM.BOT](https://sym.bot)

Apache 2.0 — © 2026 SYM.BOT Ltd
