from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any


@dataclass(slots=True)
class OrderBookLevel:
    price: Decimal
    amount: Decimal


@dataclass(slots=True)
class OrderBook:
    exchange: str
    symbol: str
    timestamp_ms: int
    nonce: int | None
    sequence: int | None
    bids: list[OrderBookLevel]
    asks: list[OrderBookLevel]


@dataclass(slots=True)
class StreamDescriptor:
    id: str
    exchange: str
    channel: str
    symbol: str
    depth: int
    category: str
    market_type: str | None
    testnet: bool


@dataclass(slots=True)
class SequenceWindow:
    last_applied: int | None
    buffered_from: int | None
    buffered_to: int | None


@dataclass(slots=True)
class BookSyncState:
    status: str
    window: SequenceWindow


@dataclass(slots=True)
class EngineHealth:
    phase: str
    consecutive_failures: int
    successful_reconnects: int
    resync_count: int
    last_error: str | None


@dataclass(slots=True)
class OrderBookEnvelope:
    schema_version: str
    event: str
    recovery_mode: str
    emitted_at_ms: int
    stream: StreamDescriptor
    decision: str
    sync: BookSyncState
    engine: EngineHealth
    book: OrderBook


@dataclass(slots=True)
class StreamHealthResponse:
    schema_version: str
    ready: bool
    stream: StreamDescriptor
    engine: EngineHealth
    latest_sync: BookSyncState | None
    latest_sequence: int | None
    latest_nonce: int | None


@dataclass(slots=True)
class StreamListResponse:
    schema_version: str
    streams: list[StreamDescriptor]


@dataclass(slots=True)
class StreamHealthSummary:
    ready: bool
    stream: StreamDescriptor
    engine: EngineHealth
    latest_sync: BookSyncState | None
    latest_sequence: int | None
    latest_nonce: int | None


@dataclass(slots=True)
class ServiceHealthResponse:
    schema_version: str
    service: str
    total_streams: int
    ready_streams: int
    streams: list[StreamHealthSummary]


def parse_service_health(payload: dict[str, Any]) -> ServiceHealthResponse:
    return ServiceHealthResponse(
        schema_version=str(payload["schema_version"]),
        service=str(payload["service"]),
        total_streams=int(payload["total_streams"]),
        ready_streams=int(payload["ready_streams"]),
        streams=[parse_stream_health_summary(item) for item in payload["streams"]],
    )


def parse_stream_list(payload: dict[str, Any]) -> StreamListResponse:
    return StreamListResponse(
        schema_version=str(payload["schema_version"]),
        streams=[parse_stream_descriptor(item) for item in payload["streams"]],
    )


def parse_stream_health(payload: dict[str, Any]) -> StreamHealthResponse:
    return StreamHealthResponse(
        schema_version=str(payload["schema_version"]),
        ready=bool(payload["ready"]),
        stream=parse_stream_descriptor(payload["stream"]),
        engine=parse_engine_health(payload["engine"]),
        latest_sync=_parse_optional_sync(payload.get("latest_sync")),
        latest_sequence=_parse_optional_int(payload.get("latest_sequence")),
        latest_nonce=_parse_optional_int(payload.get("latest_nonce")),
    )


def parse_orderbook_envelope(payload: dict[str, Any]) -> OrderBookEnvelope:
    return OrderBookEnvelope(
        schema_version=str(payload["schema_version"]),
        event=str(payload["event"]),
        recovery_mode=str(payload["recovery_mode"]),
        emitted_at_ms=int(payload["emitted_at_ms"]),
        stream=parse_stream_descriptor(payload["stream"]),
        decision=str(payload["decision"]),
        sync=parse_sync_state(payload["sync"]),
        engine=parse_engine_health(payload["engine"]),
        book=parse_orderbook(payload["book"]),
    )


def parse_stream_descriptor(payload: dict[str, Any]) -> StreamDescriptor:
    return StreamDescriptor(
        id=str(payload["id"]),
        exchange=str(payload["exchange"]),
        channel=str(payload["channel"]),
        symbol=str(payload["symbol"]),
        depth=int(payload["depth"]),
        category=str(payload["category"]),
        market_type=payload.get("market_type"),
        testnet=bool(payload["testnet"]),
    )


def parse_sync_state(payload: dict[str, Any]) -> BookSyncState:
    return BookSyncState(
        status=str(payload["status"]),
        window=SequenceWindow(
            last_applied=_parse_optional_int(payload["window"].get("last_applied")),
            buffered_from=_parse_optional_int(payload["window"].get("buffered_from")),
            buffered_to=_parse_optional_int(payload["window"].get("buffered_to")),
        ),
    )


def parse_engine_health(payload: dict[str, Any]) -> EngineHealth:
    return EngineHealth(
        phase=str(payload["phase"]),
        consecutive_failures=int(payload["consecutive_failures"]),
        successful_reconnects=int(payload["successful_reconnects"]),
        resync_count=int(payload["resync_count"]),
        last_error=payload.get("last_error"),
    )


def parse_orderbook(payload: dict[str, Any]) -> OrderBook:
    return OrderBook(
        exchange=str(payload["exchange"]),
        symbol=str(payload["symbol"]),
        timestamp_ms=int(payload["timestamp_ms"]),
        nonce=_parse_optional_int(payload.get("nonce")),
        sequence=_parse_optional_int(payload.get("sequence")),
        bids=[parse_orderbook_level(level) for level in payload["bids"]],
        asks=[parse_orderbook_level(level) for level in payload["asks"]],
    )


def parse_orderbook_level(payload: dict[str, Any]) -> OrderBookLevel:
    return OrderBookLevel(
        price=Decimal(str(payload["price"])),
        amount=Decimal(str(payload["amount"])),
    )


def parse_stream_health_summary(payload: dict[str, Any]) -> StreamHealthSummary:
    return StreamHealthSummary(
        ready=bool(payload["ready"]),
        stream=parse_stream_descriptor(payload["stream"]),
        engine=parse_engine_health(payload["engine"]),
        latest_sync=_parse_optional_sync(payload.get("latest_sync")),
        latest_sequence=_parse_optional_int(payload.get("latest_sequence")),
        latest_nonce=_parse_optional_int(payload.get("latest_nonce")),
    )


def _parse_optional_sync(payload: dict[str, Any] | None) -> BookSyncState | None:
    if payload is None:
        return None
    return parse_sync_state(payload)


def _parse_optional_int(value: Any) -> int | None:
    if value is None:
        return None
    return int(value)
