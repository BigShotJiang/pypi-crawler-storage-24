from __future__ import annotations

import json
from typing import AsyncIterator

import aiohttp
from .models import (
    OrderBookEnvelope,
    ServiceHealthResponse,
    StreamHealthResponse,
    StreamListResponse,
    parse_orderbook_envelope,
    parse_service_health,
    parse_stream_health,
    parse_stream_list,
)


class SidecarClient:
    def __init__(self, base_url: str = "http://127.0.0.1:9001") -> None:
        self.base_url = base_url.rstrip("/")

    async def service_health(self) -> ServiceHealthResponse:
        return parse_service_health(await self._get_json("/health"))

    async def list_streams(self) -> StreamListResponse:
        return parse_stream_list(await self._get_json("/v1alpha1/streams"))

    async def stream_health(self, stream_id: str) -> StreamHealthResponse:
        return parse_stream_health(
            await self._get_json(f"/v1alpha1/streams/{stream_id}/health")
        )

    async def current_orderbook(self, stream_id: str) -> OrderBookEnvelope:
        return parse_orderbook_envelope(
            await self._get_json(f"/v1alpha1/streams/{stream_id}/current")
        )

    async def stream_orderbooks(
        self, stream_id: str
    ) -> AsyncIterator[OrderBookEnvelope]:
        url = f"{self.base_url}/v1alpha1/streams/{stream_id}/sse"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                response.raise_for_status()
                async for raw_line in response.content:
                    line = raw_line.decode("utf-8").strip()
                    if not line.startswith("data: "):
                        continue
                    yield parse_orderbook_envelope(json.loads(line[6:]))

    async def _get_json(self, path: str) -> dict:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{self.base_url}{path}") as response:
                response.raise_for_status()
                return await response.json()
