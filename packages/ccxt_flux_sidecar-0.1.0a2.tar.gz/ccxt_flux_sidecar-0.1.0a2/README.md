# Python Client

Thin Python client for the versioned `ccxt-flux-sidecar` HTTP/SSE surface.

For the full Bybit integration flow, see [docs/exchanges/BYBIT.md](/Users/rishirandhawa/projects/ccxt-flux-rs/docs/exchanges/BYBIT.md).

This package metadata is prepared for future PyPI publication, but it is not published yet.

Current assumptions:

- sidecar schema version: `v1alpha1`
- local sidecar base URL: `http://127.0.0.1:9001`
- stream ids come from `GET /v1alpha1/streams`

Example:

```python
import asyncio
from ccxt_flux_sidecar import SidecarClient

async def main():
    client = SidecarClient("http://127.0.0.1:9001")
    streams = await client.list_streams()
    stream_id = streams.streams[0].id
    health = await client.stream_health(stream_id)
    print(health)

    async for event in client.stream_orderbooks(stream_id):
        print(event.book.symbol, event.book.sequence)

asyncio.run(main())
```
