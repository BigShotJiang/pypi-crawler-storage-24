import yaml
from pydantic import BaseModel


class BaseConfig(BaseModel):

    def __str__(self):
        return yaml.dump({self.__class__.__name__: self.model_dump()}, indent=2)
