import unittest

from airec.protocol import (
    BatteryStatus,
    CharacteristicInfo,
    DescriptorInfo,
    KnownUuid,
    LiveRecordingStatus,
    StorageStatus,
    normalize_uuid,
)


class ProtocolTests(unittest.TestCase):
    def test_normalize_uuid_uppercases(self) -> None:
        self.assertEqual(normalize_uuid("e49a25e0-f69a-11e8-8eb2-f2801f1b9fd1"), KnownUuid.AUXILIARY_RW)

    def test_characteristic_normalizes_properties(self) -> None:
        characteristic = CharacteristicInfo(
            uuid="0011201a-2233-4455-6677-8899dfdeddDC",
            properties=("Notify", "write", "notify"),
            descriptors=(DescriptorInfo(uuid="2902"),),
        )
        self.assertEqual(characteristic.uuid, KnownUuid.PRIMARY_NOTIFY)
        self.assertEqual(characteristic.properties, ("notify", "write"))
        self.assertEqual(characteristic.descriptors[0].uuid, "2902")

    def test_live_recording_status_formats_timestamp(self) -> None:
        status = LiveRecordingStatus(status_code=0, recording_id="20260312061422")
        self.assertEqual(status.recorded_at, "2026-03-12 06:14:22")
        self.assertEqual(status.to_dict()["status_code"], 0)
        self.assertEqual(status.to_dict()["status_name"], "active")

    def test_live_recording_status_exposes_observed_state_names(self) -> None:
        paused = LiveRecordingStatus(status_code=1)
        inactive = LiveRecordingStatus(status_code=2)
        self.assertEqual(paused.status_name, "paused")
        self.assertEqual(inactive.status_name, "inactive_or_archive")
        self.assertIsNone(paused.recorded_at)
        self.assertIsNone(inactive.recorded_at)

    def test_battery_status_serializes(self) -> None:
        self.assertEqual(BatteryStatus(percent=100, raw_hex="64").to_dict()["percent"], 100)

    def test_storage_status_serializes(self) -> None:
        payload = StorageStatus(value_0c=14648, value_0d=14784).to_dict()
        self.assertEqual(payload["value_0c"], 14648)
        self.assertEqual(payload["value_0d"], 14784)


if __name__ == "__main__":
    unittest.main()
