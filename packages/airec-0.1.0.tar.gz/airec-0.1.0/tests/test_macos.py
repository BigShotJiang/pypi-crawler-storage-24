from pathlib import Path
import plistlib
import tempfile
import unittest
from unittest import mock

from airec.macos import (
    USAGE_KEY,
    ensure_bluetooth_usage_description,
    find_python_app_info_plist,
    get_bluetooth_usage_description,
)


class MacOsTests(unittest.TestCase):
    def test_find_python_app_info_plist_from_framework_layout(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "Python.framework" / "Versions" / "3.12"
            executable = root / "bin" / "python3.12"
            plist_path = root / "Resources" / "Python.app" / "Contents" / "Info.plist"
            plist_path.parent.mkdir(parents=True, exist_ok=True)
            executable.parent.mkdir(parents=True, exist_ok=True)
            executable.write_text("", encoding="utf-8")
            plist_path.write_bytes(plistlib.dumps({}))
            self.assertEqual(find_python_app_info_plist(executable), plist_path.resolve())

    def test_get_bluetooth_usage_description_reads_plist(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "Python.framework" / "Versions" / "3.12"
            executable = root / "bin" / "python3.12"
            plist_path = root / "Resources" / "Python.app" / "Contents" / "Info.plist"
            plist_path.parent.mkdir(parents=True, exist_ok=True)
            executable.parent.mkdir(parents=True, exist_ok=True)
            executable.write_text("", encoding="utf-8")
            plist_path.write_bytes(plistlib.dumps({USAGE_KEY: "test"}))
            self.assertEqual(get_bluetooth_usage_description(executable), "test")

    def test_ensure_bluetooth_usage_description_raises_on_missing_key(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "Python.framework" / "Versions" / "3.12"
            executable = root / "bin" / "python3.12"
            plist_path = root / "Resources" / "Python.app" / "Contents" / "Info.plist"
            plist_path.parent.mkdir(parents=True, exist_ok=True)
            executable.parent.mkdir(parents=True, exist_ok=True)
            executable.write_text("", encoding="utf-8")
            plist_path.write_bytes(plistlib.dumps({}))
            with mock.patch("sys.platform", "darwin"):
                with self.assertRaises(RuntimeError) as ctx:
                    ensure_bluetooth_usage_description(executable)
            self.assertIn(USAGE_KEY, str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
