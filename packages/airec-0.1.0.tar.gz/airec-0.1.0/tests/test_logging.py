import json
from pathlib import Path
import tempfile
import unittest

from airec.logging import SessionLogger


class LoggingTests(unittest.TestCase):
    def test_session_logger_writes_jsonl(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "session.jsonl"
            logger = SessionLogger(path)
            logger.record_event(
                "notification",
                device="AA:BB",
                characteristic_uuid="0011201A-2233-4455-6677-8899DFDEDDDC",
                payload=b"\x01\x02",
                metadata={"source": "test"},
            )
            lines = path.read_text(encoding="utf-8").splitlines()
            self.assertEqual(len(lines), 1)
            entry = json.loads(lines[0])
            self.assertEqual(entry["event_type"], "notification")
            self.assertEqual(entry["payload_hex"], "0102")


if __name__ == "__main__":
    unittest.main()

