import asyncio
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from airec.analysis import analyze_session_log
from airec.cli import run_async
from airec.decode import decode_recording_download, decode_session_log


def _make_sample_session_log(path: Path) -> None:
    stream = bytearray(b"\x00" * 1024)
    headers = [
        bytes.fromhex("5b504b41"),
        bytes.fromhex("5b504b01"),
        bytes.fromhex("5b504815"),
        bytes.fromhex("5b504b41"),
        bytes.fromhex("5b504b01"),
        bytes.fromhex("5b504818"),
        bytes.fromhex("5b504b41"),
        bytes.fromhex("5b504b01"),
        bytes.fromhex("5b504886"),
        bytes.fromhex("5b504b41"),
        bytes.fromhex("5b504b01"),
    ]
    for record_index, header in enumerate(headers):
        offset = 68 + (record_index * 82)
        payload = header + bytes([record_index]) * (82 - len(header))
        stream[offset : offset + 82] = payload

    events = []
    chunks = (244, 244, 24)
    cursor = 0
    sender = "0011201A-2233-4455-6677-8899DFDEDDDC"
    for group_index in range(2):
        for chunk_size in chunks:
            payload = bytes(stream[cursor : cursor + chunk_size])
            events.append(
                {
                    "timestamp": f"2026-03-11T21:41:{13 + len(events):02d}.000000+00:00",
                    "event_type": "notification",
                    "device": "AA:BB",
                    "characteristic_uuid": sender,
                    "payload_hex": payload.hex(),
                    "metadata": {},
                }
            )
            cursor += chunk_size
    path.write_text("\n".join(json.dumps(event) for event in events) + "\n", encoding="utf-8")


def _make_sample_decode_session_log(path: Path) -> None:
    stream = bytearray(b"\x00" * 1024)
    for record_index in range(11):
        offset = 68 + (record_index * 82)
        payload = b"[P" + bytes([record_index]) * 80
        stream[offset : offset + 82] = payload

    events = []
    chunks = (244, 244, 24)
    cursor = 0
    sender = "0011201A-2233-4455-6677-8899DFDEDDDC"
    for _group_index in range(2):
        for chunk_size in chunks:
            payload = bytes(stream[cursor : cursor + chunk_size])
            events.append(
                {
                    "timestamp": f"2026-03-11T21:41:{13 + len(events):02d}.000000+00:00",
                    "event_type": "notification",
                    "device": "AA:BB",
                    "characteristic_uuid": sender,
                    "payload_hex": payload.hex(),
                    "metadata": {},
                }
            )
            cursor += chunk_size
    path.write_text("\n".join(json.dumps(event) for event in events) + "\n", encoding="utf-8")


def _make_sample_download_file(path: Path) -> None:
    payload = b"".join(b"[P" + bytes([record_index]) * 80 for record_index in range(6))
    path.write_bytes(payload)


class AnalysisTests(unittest.TestCase):
    def test_analyze_session_log_reconstructs_blocks_and_records(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            session_log = Path(tmpdir) / "session.jsonl"
            output_dir = Path(tmpdir) / "analysis"
            _make_sample_session_log(session_log)

            summary = analyze_session_log(session_log, output_dir=output_dir)

            self.assertEqual(summary["block_count"], 2)
            self.assertEqual(summary["record_alignment_offset"], 68)
            self.assertEqual(summary["full_record_count"], 11)
            self.assertEqual(summary["record_header_counts"]["5b504b41"], 4)
            self.assertEqual(summary["record_header_counts"]["5b504b01"], 4)
            self.assertTrue((output_dir / "summary.json").exists())
            self.assertTrue((output_dir / "blocks.jsonl").exists())
            self.assertTrue((output_dir / "records.jsonl").exists())

    def test_cli_analyze_outputs_summary_json(self) -> None:
        stdout = io.StringIO()
        with tempfile.TemporaryDirectory() as tmpdir:
            session_log = Path(tmpdir) / "session.jsonl"
            output_dir = Path(tmpdir) / "analysis"
            _make_sample_session_log(session_log)

            result = asyncio.run(
                run_async(
                    [
                        "analyze",
                        str(session_log),
                        "--output-dir",
                        str(output_dir),
                        "--json",
                    ],
                    stdout=stdout,
                )
            )

            self.assertEqual(result, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["block_count"], 2)
            self.assertEqual(payload["record_alignment_offset"], 68)
            self.assertEqual(payload["output_dir"], str(output_dir))

    def test_decode_session_log_writes_decoded_wav(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            session_log = Path(tmpdir) / "session.jsonl"
            output_dir = Path(tmpdir) / "decode"
            _make_sample_decode_session_log(session_log)

            def fake_decode(packets: list[bytes], *, sample_rate: int, channels: int) -> list[int]:
                self.assertEqual(sample_rate, 48_000)
                self.assertEqual(channels, 1)
                self.assertEqual(len(packets), 11)
                self.assertTrue(all(len(packet) == 80 for packet in packets))
                return [0, 1000, -1000, 0] * 50

            with mock.patch("airec.decode._decode_opus_packets", side_effect=fake_decode):
                summary = decode_session_log(session_log, output_dir=output_dir)

            self.assertEqual(summary["wrapped_record_count"], 11)
            self.assertEqual(summary["opus_packet_count"], 11)
            self.assertTrue((output_dir / "summary.json").exists())
            self.assertTrue((output_dir / "decoded_opus.wav").exists())

    def test_cli_decode_outputs_summary_json(self) -> None:
        stdout = io.StringIO()
        with tempfile.TemporaryDirectory() as tmpdir:
            session_log = Path(tmpdir) / "session.jsonl"
            output_dir = Path(tmpdir) / "decode"
            _make_sample_decode_session_log(session_log)

            with mock.patch("airec.decode._decode_opus_packets", return_value=[0, 1000, -1000, 0] * 50):
                result = asyncio.run(
                    run_async(
                        [
                            "decode",
                            str(session_log),
                            "--output-dir",
                            str(output_dir),
                            "--json",
                        ],
                        stdout=stdout,
                    )
                )

            self.assertEqual(result, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["opus_packet_count"], 11)
            self.assertEqual(payload["output_dir"], str(output_dir))
            self.assertTrue(payload["wav_path"].endswith("decoded_opus.wav"))

    def test_decode_recording_download_writes_decoded_wav(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            recording_file = Path(tmpdir) / "20260311180305.bin"
            output_dir = Path(tmpdir) / "decode-recording"
            _make_sample_download_file(recording_file)

            def fake_decode(packets: list[bytes], *, sample_rate: int, channels: int) -> list[int]:
                self.assertEqual(sample_rate, 16_000)
                self.assertEqual(channels, 1)
                self.assertEqual(len(packets), 6)
                self.assertTrue(all(len(packet) == 80 for packet in packets))
                return [0, 1000, -1000, 0] * 25

            with mock.patch("airec.decode._decode_opus_packets", side_effect=fake_decode):
                summary = decode_recording_download(recording_file, output_dir=output_dir)

            self.assertEqual(summary["record_count"], 6)
            self.assertEqual(summary["wrapped_record_count"], 6)
            self.assertEqual(summary["opus_packet_count"], 6)
            self.assertTrue((output_dir / "summary.json").exists())
            self.assertTrue((output_dir / "20260311180305.wav").exists())

    def test_cli_decode_recording_outputs_summary_json(self) -> None:
        stdout = io.StringIO()
        with tempfile.TemporaryDirectory() as tmpdir:
            recording_file = Path(tmpdir) / "20260311180305.bin"
            output_dir = Path(tmpdir) / "decode-recording"
            _make_sample_download_file(recording_file)

            with mock.patch("airec.decode._decode_opus_packets", return_value=[0, 1000, -1000, 0] * 25):
                result = asyncio.run(
                    run_async(
                        [
                            "decode-recording",
                            str(recording_file),
                            "--output-dir",
                            str(output_dir),
                            "--json",
                        ],
                        stdout=stdout,
                    )
                )

            self.assertEqual(result, 0)
            payload = json.loads(stdout.getvalue())
            self.assertEqual(payload["record_count"], 6)
            self.assertEqual(payload["output_dir"], str(output_dir))
            self.assertTrue(payload["wav_path"].endswith("20260311180305.wav"))


if __name__ == "__main__":
    unittest.main()
