import asyncio
import io
import json
from pathlib import Path
import tempfile
import unittest

from airec.cli import run_async
from airec.pklg import summarize_pklg_trace


CONNECTION_HANDLE = 70


def _make_pklg_record(type_code: int, payload: bytes, *, seconds: int, microseconds: int) -> bytes:
    record_length = 9 + len(payload)
    return (
        record_length.to_bytes(4, "big")
        + seconds.to_bytes(4, "big")
        + microseconds.to_bytes(4, "big")
        + bytes([type_code])
        + payload
    )


def _make_att_acl_record(type_code: int, att: bytes, *, seconds: int, microseconds: int) -> bytes:
    pb_flag = 0 if type_code == 2 else 2
    handle_pb_bc = (pb_flag << 12) | CONNECTION_HANDLE
    l2cap_length = len(att)
    acl_length = l2cap_length + 4
    payload = (
        handle_pb_bc.to_bytes(2, "little")
        + acl_length.to_bytes(2, "little")
        + l2cap_length.to_bytes(2, "little")
        + (0x0004).to_bytes(2, "little")
        + att
    )
    return _make_pklg_record(type_code, payload, seconds=seconds, microseconds=microseconds)


def _make_sample_pklg(path: Path) -> None:
    records = [
        _make_pklg_record(0, b"\x01\x02\x03", seconds=1_773_248_400, microseconds=0),
        _make_att_acl_record(2, bytes.fromhex("52060055aa0105"), seconds=1_773_248_400, microseconds=10_000),
        _make_att_acl_record(
            3,
            bytes.fromhex("1b0800aa55130532303236303331323036313432320007082c"),
            seconds=1_773_248_400,
            microseconds=20_000,
        ),
        _make_att_acl_record(3, bytes.fromhex("1b0800aa550106"), seconds=1_773_248_400, microseconds=21_000),
        _make_att_acl_record(
            2,
            bytes.fromhex("52060055aa1307323032363033313230363134323200000000"),
            seconds=1_773_248_400,
            microseconds=100_000,
        ),
        _make_att_acl_record(
            3,
            bytes.fromhex("1b0800aa55130732303236303331323036313432320000e6a0"),
            seconds=1_773_248_400,
            microseconds=110_000,
        ),
        _make_att_acl_record(3, bytes.fromhex("1b0b005b504b41460be455"), seconds=1_773_248_400, microseconds=111_000),
        _make_att_acl_record(3, bytes.fromhex("1b0b00010203"), seconds=1_773_248_400, microseconds=112_000),
        _make_att_acl_record(3, bytes.fromhex("1b0800aa550109"), seconds=1_773_248_400, microseconds=113_000),
    ]
    path.write_bytes(b"".join(records))


class PacketLoggerTests(unittest.TestCase):
    def test_summarize_pklg_trace_extracts_writes_and_downloads(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "trace.pklg"
            _make_sample_pklg(path)

            summary = summarize_pklg_trace(path)

        self.assertEqual(summary["record_count"], 9)
        self.assertEqual(summary["packetlogger_type_counts"]["2"], 2)
        self.assertEqual(summary["notify_counts_by_handle"]["0x0008"], 4)
        self.assertEqual(summary["notify_counts_by_handle"]["0x000b"], 2)
        self.assertEqual(len(summary["writes"]), 2)
        self.assertEqual(summary["writes"][0]["app_frame"]["command_id"], 0x05)
        self.assertEqual(summary["writes"][1]["app_frame"]["command_id"], 0x07)
        self.assertEqual(summary["downloads"][0]["timestamp_id"], "20260312061422")
        self.assertEqual(summary["downloads"][0]["size_bytes"], 59040)
        self.assertEqual(summary["downloads"][0]["data_notifications"], 2)

    def test_cli_trace_pklg_outputs_summary_json(self) -> None:
        stdout = io.StringIO()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "trace.pklg"
            _make_sample_pklg(path)

            result = asyncio.run(run_async(["trace-pklg", str(path), "--json"], stdout=stdout))

        self.assertEqual(result, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["downloads"][0]["timestamp_id"], "20260312061422")
        self.assertEqual(payload["downloads"][0]["size_bytes"], 59040)


if __name__ == "__main__":
    unittest.main()
