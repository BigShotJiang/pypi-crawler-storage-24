import importlib.metadata
import unittest

import airec


class PackageTests(unittest.TestCase):
    def test_package_exposes_version(self) -> None:
        self.assertEqual(airec.__version__, importlib.metadata.version("airec"))

    def test_package_exports_documented_api(self) -> None:
        self.assertTrue(callable(airec.scan_devices))
        self.assertTrue(callable(airec.analyze_session_log))
        self.assertTrue(callable(airec.decode_session_log))
        self.assertTrue(callable(airec.summarize_pklg_trace))
        self.assertTrue(hasattr(airec, "AirecClient"))


if __name__ == "__main__":
    unittest.main()
