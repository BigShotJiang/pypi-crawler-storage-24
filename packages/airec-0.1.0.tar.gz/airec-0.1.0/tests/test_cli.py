import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from airec.cli import run_async
from airec.protocol import CharacteristicInfo, DeviceProfile, ServiceInfo
from airec.transport import BleTransport


class FakeTransport(BleTransport):
    def __init__(self) -> None:
        archive_mode_payload = bytes.fromhex("55aa0110")
        live_status_payload = bytes.fromhex("55aa010f")
        battery_status_payload = bytes.fromhex("55aa010e")
        storage_status_payload = bytes.fromhex("55aa010b")
        current_info_payload = bytes.fromhex("55aa0104")
        list_payload = bytes.fromhex("55aa0105")
        cancel_payload = bytes.fromhex("55aa0108")
        delete_payload = bytes.fromhex("55aa0f0a3230323630333132303631343232")
        select_payload = bytes.fromhex("55aa0f023230323630333132303631343232")
        download_payload = bytes.fromhex("55aa1307323032363033313230363134323200000000")
        self.writes: list[tuple[str, str, bytes, bool | None]] = []
        self.subscriptions: list[str] = []
        self.unsubscriptions: list[str] = []
        self.callbacks: dict[str, object] = {}
        self.connected = False
        self.reads: list[str] = []
        self.read_results = {
            "E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1": b"\xaa\x55",
            "E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1": b"\x10\x00",
        }
        self.write_notifications = {
            ("E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1", b"\x01\x00"): [
                ("E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1", b"\x33\x44"),
                ("0011203A-2233-4455-6677-8899DFDEDDDC", b"\x55\x66"),
            ],
            ("0011202A-2233-4455-6677-8899DFDEDDDC", archive_mode_payload): [
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa550110")),
            ],
            ("0011202A-2233-4455-6677-8899DFDEDDDC", live_status_payload): [
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55100f003230323630333132303631343232")),
            ],
            ("0011202A-2233-4455-6677-8899DFDEDDDC", battery_status_payload): [
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55020e64")),
            ],
            ("0011202A-2233-4455-6677-8899DFDEDDDC", storage_status_payload): [
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55050c00003938")),
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55050d000039c0")),
            ],
            ("0011202A-2233-4455-6677-8899DFDEDDDC", current_info_payload): [
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55130432303236303331323036313432320007082c")),
            ],
            ("0011202A-2233-4455-6677-8899DFDEDDDC", list_payload): [
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55130532303236303331323036313432320007082c")),
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa551305323032363033313230363130303400040264")),
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa550106")),
            ],
            ("0011202A-2233-4455-6677-8899DFDEDDDC", cancel_payload): [
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa550108")),
            ],
            ("0011202A-2233-4455-6677-8899DFDEDDDC", delete_payload): [
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55010a")),
            ],
            ("0011202A-2233-4455-6677-8899DFDEDDDC", select_payload): [
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa550102")),
            ],
            ("0011202A-2233-4455-6677-8899DFDEDDDC", download_payload): [
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa551307323032363033313230363134323200000006")),
                ("0011204A-2233-4455-6677-8899DFDEDDDC", b"\x5b\x50\x01"),
                ("0011204A-2233-4455-6677-8899DFDEDDDC", b"\x02\x03\x04"),
                ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa550109")),
            ],
        }
        self.profile = DeviceProfile(
            address="AA:BB",
            name="AIREC",
            rssi=-40,
            appearance=833,
            services=(
                ServiceInfo(
                    uuid="0011200A-2233-4455-6677-8899DFDEDDDC",
                    characteristics=(
                        CharacteristicInfo(
                            uuid="0011201A-2233-4455-6677-8899DFDEDDDC",
                            properties=("notify",),
                        ),
                        CharacteristicInfo(
                            uuid="0011202A-2233-4455-6677-8899DFDEDDDC",
                            properties=("write",),
                        ),
                        CharacteristicInfo(
                            uuid="0011203A-2233-4455-6677-8899DFDEDDDC",
                            properties=("notify",),
                        ),
                    ),
                ),
                ServiceInfo(
                    uuid="E49A25F8-F69A-11E8-8EB2-F2801F1B9FD1",
                    characteristics=(
                        CharacteristicInfo(
                            uuid="E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1",
                            properties=("read", "write-without-response"),
                        ),
                        CharacteristicInfo(
                            uuid="E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1",
                            properties=("notify", "read"),
                        ),
                    ),
                ),
            ),
            manufacturer_data={},
            service_data={},
            notes=(),
        )

    async def scan(self, timeout: float):
        from airec.protocol import AdvertisementRecord

        return [AdvertisementRecord(address="AA:BB", name="AIREC", rssi=-40, appearance=833)]

    async def connect(self, address: str) -> None:
        self.connected = True

    async def disconnect(self, address: str) -> None:
        self.connected = False

    async def is_connected(self, address: str) -> bool:
        return self.connected

    async def get_services(self, address: str):
        return self.profile.services

    async def get_device_details(self, address: str):
        return {
            "address": self.profile.address,
            "name": self.profile.name,
            "rssi": self.profile.rssi,
            "manufacturer_data": {},
            "service_data": {},
            "appearance": self.profile.appearance,
        }

    async def read(self, address: str, characteristic_uuid: str) -> bytes:
        self.reads.append(characteristic_uuid)
        return self.read_results[characteristic_uuid]

    async def write(self, address: str, characteristic_uuid: str, payload: bytes, *, response: bool | None = None) -> None:
        self.writes.append((address, characteristic_uuid, payload, response))
        for sender, notify_payload in self.write_notifications.get((characteristic_uuid, payload), []):
            callback = self.callbacks.get(sender)
            if callback is None:
                continue
            maybe = callback(sender, notify_payload)
            if maybe is not None:
                await maybe

    async def subscribe(self, address: str, characteristic_uuid: str, callback) -> None:
        self.subscriptions.append(characteristic_uuid)
        self.callbacks[characteristic_uuid] = callback
        maybe = callback(characteristic_uuid, self.read_results.get(characteristic_uuid, b"\x10\x20"))
        if maybe is not None:
            await maybe

    async def unsubscribe(self, address: str, characteristic_uuid: str) -> None:
        self.unsubscriptions.append(characteristic_uuid)
        self.callbacks.pop(characteristic_uuid, None)
        return None


class NoResponseControlTransport(FakeTransport):
    def __init__(self) -> None:
        super().__init__()
        self.profile = DeviceProfile(
            address=self.profile.address,
            name=self.profile.name,
            rssi=self.profile.rssi,
            appearance=self.profile.appearance,
            services=(
                ServiceInfo(
                    uuid="0011200A-2233-4455-6677-8899DFDEDDDC",
                    characteristics=(
                        CharacteristicInfo(
                            uuid="0011201A-2233-4455-6677-8899DFDEDDDC",
                            properties=("notify",),
                        ),
                        CharacteristicInfo(
                            uuid="0011202A-2233-4455-6677-8899DFDEDDDC",
                            properties=("write-without-response",),
                        ),
                        CharacteristicInfo(
                            uuid="0011203A-2233-4455-6677-8899DFDEDDDC",
                            properties=("notify",),
                        ),
                    ),
                ),
                self.profile.services[1],
            ),
            manufacturer_data=self.profile.manufacturer_data,
            service_data=self.profile.service_data,
            notes=self.profile.notes,
        )

    async def write(self, address: str, characteristic_uuid: str, payload: bytes, *, response: bool | None = None) -> None:
        if characteristic_uuid == "0011202A-2233-4455-6677-8899DFDEDDDC" and response is True:
            raise RuntimeError("Writing is not permitted.")
        await super().write(address, characteristic_uuid, payload, response=response)


class RetryControlTransport(FakeTransport):
    async def write(self, address: str, characteristic_uuid: str, payload: bytes, *, response: bool | None = None) -> None:
        if characteristic_uuid == "0011202A-2233-4455-6677-8899DFDEDDDC" and response is False:
            self.writes.append((address, characteristic_uuid, payload, response))
            raise RuntimeError("Writing is not permitted.")
        await super().write(address, characteristic_uuid, payload, response=response)


class AuxiliaryRecordingTransport(FakeTransport):
    def __init__(self) -> None:
        super().__init__()
        archive_mode_payload = bytes.fromhex("55aa0110")
        current_info_payload = bytes.fromhex("55aa0104")
        list_payload = bytes.fromhex("55aa0105")
        self.write_notifications[("0011202A-2233-4455-6677-8899DFDEDDDC", list_payload)] = []
        self.write_notifications[("0011202A-2233-4455-6677-8899DFDEDDDC", archive_mode_payload)] = [
            ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa550110")),
        ]
        self.write_notifications[("0011202A-2233-4455-6677-8899DFDEDDDC", current_info_payload)] = [
            ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55130432303236303331323036313432320007082c")),
        ]
        self.write_notifications[("E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1", list_payload)] = [
            ("0011204A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55130532303236303331323036313432320007082c")),
            ("0011204A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa550106")),
        ]


class LiveToggleExperimentTransport(FakeTransport):
    def __init__(self) -> None:
        super().__init__()
        self.disconnect_count = 0
        self.live_status_request_count = 0
        self.toggle_request_count = 0
        self.live_status_payloads = [
            bytes.fromhex("aa55100f003230323630333133313431393236"),
            bytes.fromhex("aa55100f003230323630333133313432303035"),
            bytes.fromhex("aa55100f003230323630333133313432303432"),
        ]
        self.write_notifications[("0011202A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("55aa0104"))] = [
            ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55130432303236303331333134323034320007082c")),
        ]
        self.write_notifications[("0011202A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("55aa0105"))] = [
            ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55130532303236303331333134313932360007082c")),
            ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa55130532303236303331333134323030350007082c")),
            ("0011203A-2233-4455-6677-8899DFDEDDDC", bytes.fromhex("aa550106")),
        ]

    async def write(self, address: str, characteristic_uuid: str, payload: bytes, *, response: bool | None = None) -> None:
        if characteristic_uuid == "0011202A-2233-4455-6677-8899DFDEDDDC" and payload in {
            bytes.fromhex("55aa010f"),
            bytes.fromhex("55aa0110"),
        }:
            self.writes.append((address, characteristic_uuid, payload, response))
            callback = self.callbacks.get("0011203A-2233-4455-6677-8899DFDEDDDC")
            if payload == bytes.fromhex("55aa010f"):
                notify_payload = self.live_status_payloads[self.live_status_request_count]
                self.live_status_request_count += 1
            else:
                self.toggle_request_count += 1
                notify_payload = bytes.fromhex("aa550110")
            if callback is not None:
                maybe = callback("0011203A-2233-4455-6677-8899DFDEDDDC", notify_payload)
                if maybe is not None:
                    await maybe
            return

        await super().write(address, characteristic_uuid, payload, response=response)

    async def disconnect(self, address: str) -> None:
        self.disconnect_count += 1
        await super().disconnect(address)


class BaselineDiffLiveToggleExperimentTransport(LiveToggleExperimentTransport):
    def __init__(self) -> None:
        super().__init__()
        self.current_info_request_count = 0
        self.list_request_count = 0

    async def write(self, address: str, characteristic_uuid: str, payload: bytes, *, response: bool | None = None) -> None:
        if characteristic_uuid == "0011202A-2233-4455-6677-8899DFDEDDDC" and payload in {
            bytes.fromhex("55aa0104"),
            bytes.fromhex("55aa0105"),
        }:
            self.writes.append((address, characteristic_uuid, payload, response))
            callback = self.callbacks.get("0011203A-2233-4455-6677-8899DFDEDDDC")
            if callback is None:
                return
            if payload == bytes.fromhex("55aa0104"):
                notify_payload = (
                    bytes.fromhex("aa55130432303236303331333231313530380003062c")
                    if self.current_info_request_count == 0
                    else bytes.fromhex("aa55130432303236303331333231323233310000532c")
                )
                self.current_info_request_count += 1
                maybe = callback("0011203A-2233-4455-6677-8899DFDEDDDC", notify_payload)
                if maybe is not None:
                    await maybe
                return
            payloads = (
                [
                    bytes.fromhex("aa55130532303236303331333231313530380003062c"),
                    bytes.fromhex("aa550106"),
                ]
                if self.list_request_count == 0
                else [
                    bytes.fromhex("aa55130532303236303331333231313530380003062c"),
                    bytes.fromhex("aa551305323032363033313332313232313900048000"),
                    bytes.fromhex("aa55130532303236303331333231323233310000532c"),
                    bytes.fromhex("aa550106"),
                ]
            )
            self.list_request_count += 1
            for notify_payload in payloads:
                maybe = callback("0011203A-2233-4455-6677-8899DFDEDDDC", notify_payload)
                if maybe is not None:
                    await maybe
            return

        await super().write(address, characteristic_uuid, payload, response=response)


class CliTests(unittest.IsolatedAsyncioTestCase):
    async def test_scan_json_output(self) -> None:
        stdout = io.StringIO()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                ["scan", "--json", "--log-file", str(Path(tmpdir) / "scan.jsonl")],
                adapter=FakeTransport(),
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload[0]["address"], "AA:BB")

    async def test_probe_uses_write_response_for_write_characteristic(self) -> None:
        stdout = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "probe",
                    "AA:BB",
                    "--char",
                    "0011202A-2233-4455-6677-8899DFDEDDDC",
                    "--hex",
                    "0102",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "probe.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        self.assertEqual(len(transport.writes), 1)
        _, uuid, payload, response = transport.writes[0]
        self.assertEqual(uuid, "0011202A-2233-4455-6677-8899DFDEDDDC")
        self.assertEqual(payload, b"\x01\x02")
        self.assertTrue(response)

    async def test_list_recordings_returns_catalog_entries(self) -> None:
        stdout = io.StringIO()
        stderr = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "list-recordings",
                    "AA:BB",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "list-recordings.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
                stderr=stderr,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["count"], 2)
        self.assertTrue(payload["stateful_archive_path"])
        self.assertEqual(payload["recordings"][0]["recording_id"], "20260312061422")
        self.assertEqual(payload["recordings"][0]["recorded_at"], "2026-03-12 06:14:22")
        self.assertEqual(payload["recordings"][1]["metadata_hex"], "00040264")
        self.assertEqual(
            [item[2].hex() for item in transport.writes[:3]],
            ["55aa0110", "55aa0104", "55aa0105"],
        )
        self.assertTrue(all(item[3] is False for item in transport.writes[:3]))
        self.assertIn("0011203A-2233-4455-6677-8899DFDEDDDC", transport.unsubscriptions)

    async def test_list_recordings_uses_write_without_response_when_required(self) -> None:
        stdout = io.StringIO()
        transport = NoResponseControlTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "list-recordings",
                    "AA:BB",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "list-recordings.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        _, uuid, payload, response = transport.writes[-1]
        self.assertEqual(uuid, "0011202A-2233-4455-6677-8899DFDEDDDC")
        self.assertEqual(payload, bytes.fromhex("55aa0105"))
        self.assertFalse(response)

    async def test_list_recordings_retries_with_response_after_without_response_error(self) -> None:
        stdout = io.StringIO()
        transport = RetryControlTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "list-recordings",
                    "AA:BB",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "list-recordings.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        self.assertEqual(
            [item[3] for item in transport.writes if item[1] == "0011202A-2233-4455-6677-8899DFDEDDDC"],
            [False, True, False, True, False, True],
        )

    async def test_list_recordings_falls_back_to_auxiliary_write_path(self) -> None:
        stdout = io.StringIO()
        transport = AuxiliaryRecordingTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "list-recordings",
                    "AA:BB",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "list-recordings.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["count"], 1)
        self.assertEqual(
            [item[1] for item in transport.writes if item[0] == "AA:BB"],
            [
                "0011202A-2233-4455-6677-8899DFDEDDDC",
                "0011202A-2233-4455-6677-8899DFDEDDDC",
                "0011202A-2233-4455-6677-8899DFDEDDDC",
                "E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1",
            ],
        )

    async def test_live_status_returns_current_recording_context(self) -> None:
        stdout = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "live-status",
                    "AA:BB",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "live-status.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["status_code"], 0)
        self.assertEqual(payload["status_name"], "active")
        self.assertEqual(payload["recording_id"], "20260312061422")
        self.assertEqual(payload["recorded_at"], "2026-03-12 06:14:22")
        self.assertEqual(transport.writes[0][2].hex(), "55aa010f")

    async def test_battery_status_returns_percent(self) -> None:
        stdout = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "battery-status",
                    "AA:BB",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "battery-status.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["percent"], 100)
        self.assertEqual(payload["raw_hex"], "64")
        self.assertEqual(transport.writes[0][2].hex(), "55aa010e")

    async def test_storage_status_returns_paired_values(self) -> None:
        stdout = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "storage-status",
                    "AA:BB",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "storage-status.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["value_0c"], 14648)
        self.assertEqual(payload["value_0d"], 14784)
        self.assertEqual(transport.writes[0][2].hex(), "55aa010b")

    async def test_pause_resume_live_sends_transition_command(self) -> None:
        stdout = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "pause-resume-live",
                    "AA:BB",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "pause-resume-live.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertTrue(payload["acknowledged"])
        self.assertEqual(payload["command_hex"], "55aa0110")
        self.assertEqual(transport.writes[0][2].hex(), "55aa0110")

    async def test_live_toggle_experiment_runs_sequence_without_extra_preflight_toggle(self) -> None:
        stdout = io.StringIO()
        transport = LiveToggleExperimentTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "live-toggle-experiment",
                    "AA:BB",
                    "--wait-seconds",
                    "0",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "live-toggle-experiment.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["status_before"]["recording_id"], "20260313141926")
        self.assertEqual(payload["status_after_first_toggle"]["recording_id"], "20260313142005")
        self.assertEqual(payload["status_after_second_toggle"]["recording_id"], "20260313142042")
        self.assertEqual(payload["count"], 2)
        self.assertEqual(
            [item[2].hex() for item in transport.writes if item[1] == "0011202A-2233-4455-6677-8899DFDEDDDC"],
            [
                "55aa010f",
                "55aa0110",
                "55aa010f",
                "55aa0110",
                "55aa010f",
                "55aa0104",
                "55aa0105",
            ],
        )

    async def test_live_toggle_experiment_can_disconnect_before_listing(self) -> None:
        stdout = io.StringIO()
        transport = LiveToggleExperimentTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "live-toggle-experiment",
                    "AA:BB",
                    "--disconnect-before-list",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "live-toggle-disconnect.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertTrue(payload["disconnect_before_list"])
        self.assertIsNone(payload["second_toggle"])
        self.assertIsNone(payload["status_after_second_toggle"])
        self.assertEqual(payload["status_before"]["recording_id"], "20260313141926")
        self.assertEqual(payload["status_after_first_toggle"]["recording_id"], "20260313142005")
        self.assertEqual(payload["count"], 2)
        self.assertGreaterEqual(transport.disconnect_count, 1)
        self.assertEqual(
            [item[2].hex() for item in transport.writes if item[1] == "0011202A-2233-4455-6677-8899DFDEDDDC"],
            [
                "55aa010f",
                "55aa0110",
                "55aa010f",
                "55aa0110",
                "55aa0104",
                "55aa0105",
            ],
        )

    async def test_live_toggle_experiment_can_report_baseline_archive_diff(self) -> None:
        stdout = io.StringIO()
        transport = BaselineDiffLiveToggleExperimentTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "live-toggle-experiment",
                    "AA:BB",
                    "--baseline-list",
                    "--disconnect-before-list",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "live-toggle-baseline.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertTrue(payload["baseline_list"])
        self.assertEqual(payload["baseline_count"], 1)
        self.assertEqual(payload["count"], 3)
        self.assertEqual(
            [item["recording_id"] for item in payload["baseline_recordings"]],
            ["20260313211508"],
        )
        self.assertEqual(
            [item["recording_id"] for item in payload["added_recordings"]],
            ["20260313212219", "20260313212231"],
        )
        self.assertEqual(payload["removed_recordings"], [])
        self.assertEqual(
            [item[2].hex() for item in transport.writes if item[1] == "0011202A-2233-4455-6677-8899DFDEDDDC"],
            [
                "55aa0110",
                "55aa0104",
                "55aa0105",
                "55aa010f",
                "55aa0110",
                "55aa010f",
                "55aa0110",
                "55aa0104",
                "55aa0105",
            ],
        )

    async def test_download_recording_saves_output_file(self) -> None:
        stdout = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "recording.bin"
            with mock.patch(
                "airec.cli.decode_recording_download",
                return_value={
                    "wav_path": str(Path(tmpdir) / "decoded" / "recording.wav"),
                    "sample_rate": 16_000,
                    "duration_seconds": 0.12,
                },
            ) as decode_recording:
                rc = await run_async(
                    [
                    "download-recording",
                    "AA:BB",
                    "2026-03-12 06:14:22",
                    "--output",
                    str(output_path),
                    "--json",
                        "--log-file",
                        str(Path(tmpdir) / "download-recording.jsonl"),
                    ],
                    adapter=transport,
                    stdout=stdout,
                )
            file_bytes = output_path.read_bytes()
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["recording_id"], "20260312061422")
        self.assertEqual(payload["expected_size_bytes"], 6)
        self.assertEqual(payload["bytes_received"], 6)
        self.assertEqual(payload["data_notifications"], 2)
        self.assertTrue(payload["size_matches"])
        self.assertEqual(file_bytes, b"\x5b\x50\x01\x02\x03\x04")
        self.assertEqual(payload["wav_path"], str(Path(tmpdir) / "decoded" / "recording.wav"))
        self.assertEqual(payload["decoded_sample_rate"], 16_000)
        self.assertEqual(payload["decoded_duration_seconds"], 0.12)
        self.assertTrue(payload["stateful_archive_path"])
        decode_recording.assert_called_once_with(
            output_path,
            output_dir=Path("artifacts") / "decode" / output_path.stem,
        )
        self.assertEqual(
            [item[2].hex() for item in transport.writes if item[1] == "0011202A-2233-4455-6677-8899DFDEDDDC"],
            [
                "55aa0110",
                "55aa0104",
                "55aa0f023230323630333132303631343232",
                "55aa1307323032363033313230363134323200000000",
            ],
        )
        self.assertEqual(
            [item[3] for item in transport.writes if item[1] == "0011202A-2233-4455-6677-8899DFDEDDDC"],
            [False, False, False, False],
        )
        self.assertEqual(
            transport.unsubscriptions,
            [
                "0011201A-2233-4455-6677-8899DFDEDDDC",
                "0011203A-2233-4455-6677-8899DFDEDDDC",
                "E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1",
                "0011204A-2233-4455-6677-8899DFDEDDDC",
            ],
        )

    async def test_delete_recording_sends_delete_command(self) -> None:
        stdout = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "delete-recording",
                    "AA:BB",
                    "2026-03-12 06:14:22",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "delete-recording.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertTrue(payload["deleted"])
        self.assertTrue(payload["stateful_archive_path"])
        self.assertEqual(payload["recording_id"], "20260312061422")
        self.assertEqual(
            [item[2].hex() for item in transport.writes[:3]],
            ["55aa0110", "55aa0104", "55aa0f0a3230323630333132303631343232"],
        )

    async def test_cancel_download_sends_cancel_command(self) -> None:
        stdout = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "cancel-download",
                    "AA:BB",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "cancel-download.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertTrue(payload["cancelled"])
        self.assertEqual(transport.writes[0][2].hex(), "55aa0108")

    async def test_monitor_subscribes_and_captures_notification(self) -> None:
        stdout = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            rc = await run_async(
                [
                    "monitor",
                    "AA:BB",
                    "--duration",
                    "0",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "monitor.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(
            payload["subscribed"],
            [
                "0011201A-2233-4455-6677-8899DFDEDDDC",
                "0011203A-2233-4455-6677-8899DFDEDDDC",
                "E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1",
            ],
        )
        self.assertEqual(payload["notifications"][0]["payload_hex"], "1020")

    async def test_survey_reads_and_subscribes_all_observable_characteristics(self) -> None:
        stdout = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            log_path = Path(tmpdir) / "survey.jsonl"
            rc = await run_async(
                [
                    "survey",
                    "AA:BB",
                    "--duration",
                    "0",
                    "--json",
                    "--log-file",
                    str(log_path),
                ],
                adapter=transport,
                stdout=stdout,
            )
            log_lines = log_path.read_text(encoding="utf-8").splitlines()
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(
            [item["characteristic_uuid"] for item in payload["reads"]],
            [
                "E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1",
                "E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1",
            ],
        )
        self.assertEqual(payload["reads"][0]["payload_hex"], "aa55")
        self.assertEqual(
            [item["characteristic_uuid"] for item in payload["subscriptions"]],
            [
                "0011201A-2233-4455-6677-8899DFDEDDDC",
                "0011203A-2233-4455-6677-8899DFDEDDDC",
                "E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1",
            ],
        )
        self.assertEqual(len(payload["notifications"]), 3)
        self.assertEqual(
            transport.unsubscriptions,
            [
                "0011201A-2233-4455-6677-8899DFDEDDDC",
                "0011203A-2233-4455-6677-8899DFDEDDDC",
                "E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1",
            ],
        )
        self.assertTrue(any('"event_type": "read_result"' in line for line in log_lines))
        self.assertTrue(any('"event_type": "survey_completed"' in line for line in log_lines))

    async def test_explore_runs_multi_step_plan_and_groups_notifications(self) -> None:
        stdout = io.StringIO()
        transport = FakeTransport()
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            plan_path.write_text(
                json.dumps(
                    [
                        {
                            "label": "list-catalog",
                            "char": "E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1",
                            "hex": "0100",
                            "response": "false",
                            "wait_after": 0,
                        }
                    ]
                ),
                encoding="utf-8",
            )
            rc = await run_async(
                [
                    "explore",
                    "AA:BB",
                    "--plan",
                    str(plan_path),
                    "--baseline",
                    "0",
                    "--json",
                    "--log-file",
                    str(Path(tmpdir) / "explore.jsonl"),
                ],
                adapter=transport,
                stdout=stdout,
            )
        self.assertEqual(rc, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["baseline_reads"][0]["payload_hex"], "aa55")
        self.assertEqual(len(payload["steps"]), 1)
        step = payload["steps"][0]
        self.assertEqual(step["label"], "list-catalog")
        self.assertEqual(step["write_status"], "ok")
        self.assertEqual(step["response"], False)
        self.assertEqual(
            [item["payload_hex"] for item in step["notifications"]],
            ["3344", "5566"],
        )
        self.assertEqual(
            [item["characteristic_uuid"] for item in step["reads"]],
            [
                "E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1",
                "E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1",
            ],
        )
        self.assertEqual(len(transport.writes), 1)
        _, uuid, sent_payload, response = transport.writes[0]
        self.assertEqual(uuid, "E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1")
        self.assertEqual(sent_payload, b"\x01\x00")
        self.assertFalse(response)


if __name__ == "__main__":
    unittest.main()
