# AIREC Protocol Notes

Seeded from `AIREC.txt`, exported from nRF Connect on iOS on March 11, 2026.

## What The Log Confirms

- AIREC exposes two custom GATT services:
  - `0011200A-2233-4455-6677-8899DFDEDDDC`
  - `E49A25F8-F69A-11E8-8EB2-F2801F1B9FD1`
- The first service exposes four characteristics:
  - `0011201A-2233-4455-6677-8899DFDEDDDC`
  - `0011202A-2233-4455-6677-8899DFDEDDDC`
  - `0011203A-2233-4455-6677-8899DFDEDDDC`
  - `0011204A-2233-4455-6677-8899DFDEDDDC`
- The second service exposes two characteristics:
  - `E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1`
  - `E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1`
- The following characteristics have a client configuration descriptor (`2902`), which usually means notification or indication support:
  - `0011201A-2233-4455-6677-8899DFDEDDDC`
  - `0011203A-2233-4455-6677-8899DFDEDDDC`
  - `0011204A-2233-4455-6677-8899DFDEDDDC`
  - `E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1`
- `0011202A-2233-4455-6677-8899DFDEDDDC` and `E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1` did not report descriptors in the log and are good candidates for read/write control or request characteristics.

## What The Log Does Not Confirm

- No characteristic value reads are present.
- No write payloads are present.
- No notification payloads are present.
- No MTU, file transfer, or authentication flow is visible.

## What The Automated Survey Confirms

- On March 11, 2026, `survey-20260311T214112Z.jsonl` subscribed successfully to all four notify-capable characteristics:
  - `0011201A-2233-4455-6677-8899DFDEDDDC`
  - `0011203A-2233-4455-6677-8899DFDEDDDC`
  - `0011204A-2233-4455-6677-8899DFDEDDDC`
  - `E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1`
- During a 15 second idle capture, only `0011201A-2233-4455-6677-8899DFDEDDDC` emitted traffic.
- The capture produced 366 notifications from `0011201A-...`, with payload lengths following a strict repeating pattern of `244`, `244`, and `24` bytes.
- Those three notifications reconstruct into 122 exact `512` byte blocks. This strongly suggests the device is using a large ATT MTU and fragmenting a higher-level stream across BLE notifications.
- Both characteristics that advertised `read` in the GATT table rejected direct reads at runtime with `CBATTErrorDomain Code=2` (`Reading is not permitted`):
  - `E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1`
  - `E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1`
- Within the reconstructed stream, many records start on an 82 byte cadence. A recurring family of headers was observed at that alignment:
  - `5b504b41`
  - `5b504b01`
  - `5b5048xx`
- The `5b504b..` header appears at a single absolute alignment across the full capture (`offset % 82 == 68`), which makes accidental byte collisions unlikely.
- A second March 11, 2026 survey capture (`survey-20260311T220558Z.jsonl`) preserved the same `244 + 244 + 24` transport shape but shifted the strongest record alignment from `68` to `26`. The most likely explanation is that subscription begins in the middle of a continuous recorder stream, so alignment can vary across captures.

## Updated Working Hypotheses

- `0011201A-...` is an active streaming or event channel, not just a sparse status notifier.
- The application protocol likely has an internal record size of `82` bytes, which is then packed into `512` byte transport blocks and fragmented into `244 + 244 + 24` BLE notifications.
- Those `82` byte records appear to be a tiny BLE transport wrapper: a `5b50` (`[P`) prefix plus an `80` byte Opus packet payload.
- Decoding the `80` byte payloads as mono Opus at `48 kHz` yields roughly one `20 ms` frame per record, which matches the observed capture duration closely.
- The `5b504b41`, `5b504b01`, and `5b5048xx` prefixes are most likely wrapper subtypes rather than codec-specific framing.
- Record alignment is probably capture-relative rather than session-stable. Analysis tools should detect the best alignment per capture instead of assuming a fixed offset.
- The `read` property reported by CoreBluetooth is not sufficient to infer runtime accessibility on this device. Future tooling should treat read support as provisional until verified.
- `0011203A-...`, `0011204A-...`, and `E49A28E1-...` may still be valid notify paths, but they did not emit traffic during the idle capture and may require a device state change or host command first.

## Recording Screen Clues

The March 12, 2026 app screenshots in [`documentation/IMG_8306.PNG`](/Users/mkerr/Projects/ariec-voice/documentation/IMG_8306.PNG) and [`documentation/IMG_8307.PNG`](/Users/mkerr/Projects/ariec-voice/documentation/IMG_8307.PNG) add several useful constraints:

- The file browser shows `File(0/12)`, which implies the app can fetch a catalog with at least a total item count and probably a current page or cursor.
- Each row already contains a timestamp and duration before transfer begins, so the list response must include recording metadata, not just opaque IDs.
- The "Click to transfer" affordance implies listing and download are separate commands. The app can enumerate metadata without immediately streaming the audio payload.
- The live-mode screen says the device streams audio "in real time" after linking, which fits the current `0011201A-...` stream findings. Archived recordings are therefore likely a second command path rather than the same passive stream.

## Recording Workflow

- `0011202A-...` is the primary archived-recording control write characteristic used by the vendor app.
- `0011203A-...` carries framed control replies (`aa55 ...`) for the archived-recording flow.
- `0011204A-...` carries bulk archived-audio transfer data after a download is acknowledged.
- `0011201A-...` remains the live-stream path. A direct `55aa0105` from a cold connection can leave the device on that stream instead of producing the catalog response, so the app appears to require an archive-mode preflight first.

## PacketLogger Trace Findings

The PacketLogger capture in [`documentation/BluetoothTraceFile.pklg`](/Users/mkerr/Projects/ariec-voice/documentation/BluetoothTraceFile.pklg) confirms the archived-recording path.

- All vendor-app control writes go to ATT handle `0x0006`, which matches the expected value-handle slot for `0011202A-...`.
- Control responses come back on ATT handle `0x0008`, which matches the expected value-handle slot for `0011203A-...`.
- Bulk download data comes back on ATT handle `0x000b`, which matches the expected value-handle slot for `0011204A-...`.
- The original live/current stream is still on ATT handle `0x0003`, matching `0011201A-...`.

## Observed Command Sequence

Every application-level command uses a `55aa <len> <cmd> ...` write on `0011202A-...`. Control replies use `aa55 <len> <cmd> ...` notifications on `0011203A-...`.

- `55aa0110` returns `aa550110`. The vendor app sends this before the first catalog request on a fresh archived-recordings session. In live testing, mirroring this step was required to stop the device from continuing to emit only `0011201A-...` stream traffic.
- `55aa0104` returns `aa551304 <14-byte timestamp> <3-byte metadata?> 2c`. The vendor app sends this immediately before `55aa0105`; it appears to query the currently highlighted or most recent archived recording.
- `55aa0105` returns repeated `aa551305 <14-byte timestamp> <3-byte metadata?> 2c` records, followed by `aa550106`. This is the recording list command.
- `55aa0f02 <14-byte timestamp>` returns `aa550102`. This appears to select or arm a specific recording by timestamp.
- `55aa0130` returns `aa550f30 <14-byte timestamp>`. This appears to confirm the selected timestamp back from the device.
- `55aa1307 <14-byte timestamp> 00000000` returns `aa551307 <14-byte timestamp> <4-byte big-endian size>`, then streams the file on `0011204A-...`, and finally sends `aa550109`. This is the download command.

## PacketLogger Trace 2 Findings

The second capture in [`documentation/BluetoothTraceFile 2.pklg`](/Users/mkerr/Projects/ariec-voice/documentation/BluetoothTraceFile%202.pklg) adds several previously unseen opcodes and helps separate live-status actions from archive browsing.

- `55aa010f` returns `aa55100f 00 <14-byte timestamp>`. This appears to query the current live-recording timestamp or active recording context.
- Two isolated `55aa0110` writes were observed around the app's pause/resume interaction. After the first, `0011201A-...` live traffic stopped for several seconds; after the second, live traffic resumed. `0x10` is therefore likely a live-recording pause/resume toggle or closely related state-transition command, not just an archive-mode preflight.
- `55aa010e` returns `aa55020e64`. The `0x64` value aligns with the app showing `99%` battery, so `0x0e` is likely a battery-status query.
- `55aa010b` triggers paired `aa55050c 00003938` and `aa55050d 000039c0` responses. The first value (`14648`) closely matches the app's `14.64` GB storage figure, so `0x0b` appears to query storage status, with `0x0c` and `0x0d` carrying the two reported storage numbers.
- `55aa0f0a <14-byte timestamp>` returns `aa55010a`, after which a refreshed `0x05` catalog no longer contains that timestamp. This is strong evidence that `0x0a` deletes a recording by timestamp.
- `55aa0108` returns `aa550108` when sent during an in-progress `0x07` transfer. Only a few trailing `0011204A-...` packets arrived afterward, so `0x08` appears to cancel or stop the current download.
- `55aa0334 0001`, `55aa0120`, `55aa0101`, and `55aa0126` were also observed, but their semantics remain unclear.

## March 14 Live Toggle Experiments

Several March 14, 2026 live-hardware experiments were run with the new `airec live-toggle-experiment` helper and materially changed the working model for live control commands.

- The device appears to auto-start a live recording when powered on. This means a `0x0f` live-status timestamp may simply be the current power-on recording session, not evidence of a prior manual command.
- `55aa010f` does not always return the same payload shape:
  - `aa55100f 00 <14-byte timestamp>` appears to mean "active live recording" with a current live-session timestamp.
  - `aa55020f01` appears after a single `0x10` toggle and likely means "paused" or otherwise inactive live state, with no active timestamp.
  - `aa55020f02` appeared after using the archive-browsing path (`0x10 -> 0x04 -> 0x05`) before querying live status. The best current guess is that `status_code = 2` means "not in active live-recording mode", possibly because the device is in an archive-browsing or stopped state.
- A simple two-toggle experiment showed that `0x10` can return a session from `status_code = 0` to `status_code = 1`, then back to `status_code = 0` with the same live timestamp. That strongly suggests `0x10` is pause/resume, not a "finish current recording and immediately start a new one" command.
- A pause-plus-disconnect experiment showed that a new archived recording can appear only after disconnecting while paused. This is the strongest current evidence that disconnecting from the paused state finalizes or commits the current live segment into the archive.
- Because the current archive-list path itself sends `0x10`, any "baseline list before the live toggle" experiment is stateful and can perturb the live recorder before `0x0f` is queried. A live baseline list is therefore not a neutral baseline.

## Updated Best-Guess Command Semantics

These are now the most defensible protocol interpretations from the combined PacketLogger and hardware experiments.

- `0x0f` is a live-status query, not a state-changing command.
- `0x10` is most likely a live pause/resume transition. It should be treated as stateful and potentially destructive to the current recording session.
- Disconnecting while the device is in the paused state likely causes the current session to be finalized into an archived recording.
- `0x04` appears to return the current or most recent archived item in archive-browsing mode.
- `0x05` is still the archive list command.
- `0x02` is still required by the current download path, but its deeper semantics are now less clear than before. In traces and experiments, `0x02` has carried timestamps that do not always line up neatly with the currently listed archive rows. The safest wording is that it is a prerequisite selection/arming step for `0x07`, not that it has been fully understood as a generic archive-row selector.

## Working CLI Sequence

The current `airec list-recordings` implementation uses the following sequence, which has been verified against live hardware, but it now appears to have side effects on live recording state:

1. subscribe to all discovered notify/indicate characteristics, with explicit fallback attempts for `0011203A-...`, `0011204A-...`, and `E49A28E1-...`
2. send `55aa0110`
3. wait for `aa550110`
4. send `55aa0104`
5. wait for `aa551304 ...`
6. send `55aa0105`
7. collect each `aa551305 ...` catalog row until `aa550106`

`airec download-recording` reuses the same control path, then sends `0x02` and `0x07` to select and transfer the requested recording.

This sequence still works for archive access, but it should no longer be described as a harmless "archive-mode preflight". Based on the live-toggle experiments, step 2 likely pauses or otherwise transitions the live recorder. In practice, the archive path currently appears to depend on that state transition.

## Best-Guess Protocol Changes To Adopt

These are the protocol-level changes the reverse-engineering notes should assume until contradicted by better traces:

- Stop describing `0x10` as an archive-mode command. Describe it as a live-state transition that also happens to be used by the vendor app before archive browsing.
- Treat any archive flow that sends `0x10` as stateful and potentially capable of pausing or finalizing a live session.
- Treat `0x0f` response codes as a small live-state enum rather than a single fixed shape:
  - `0x00`: active live session, timestamp present
  - `0x01`: paused/inactive live session, no timestamp observed
  - `0x02`: non-live/archive-browsing or otherwise inactive mode, no timestamp observed
- Treat "pause" and "finalize" as separate concepts. The current best guess is:
  - `0x10` performs pause/resume
  - finalization happens on disconnect while paused, or on some still-unidentified explicit command
- Keep `0x02` in the download workflow, but downgrade confidence in the old "select or arm a specific recording by timestamp" interpretation.

## Best-Guess CLI Changes To Make

These are the CLI changes most strongly suggested by the current evidence:

- Rename or reframe `toggle-live-recording` to make it clear that it is probably a pause/resume control, not a generic "recording toggle" and not a safe archive preflight.
- Remove the assumption that `list-recordings`, `download-recording`, and `delete-recording` are safe to run while a live recording is in progress. At minimum, document the risk clearly; ideally, gate these commands behind an explicit flag or a warning once hardware access resumes.
- Stop silently treating `0x10` as part of a benign internal setup step. If the archive path still requires it, surface that fact in CLI help and docs.
- Keep the new `live-toggle-experiment` command because it is the first tool that directly exposed the `0x0f` status-code transitions and the pause-plus-disconnect behavior.
- If future work continues, prefer archive diffing against a saved baseline file instead of taking a live baseline list from the device, because the live baseline path itself changes device state.

## Confirmed Downloads

The trace includes two archived downloads:

- `55aa1307 3230323630333132303631343232 00000000` downloads recording `20260312061422` and the control ack reports `59040` bytes. The transfer produced `246` notifications on `0011204A-...`.
- `55aa1307 3230323630333132303631303034 00000000` downloads recording `20260312061004` and the control ack reports `32964` bytes. The transfer produced `138` notifications on `0011204A-...`.

These timestamps match the March 12, 2026 file-browser screenshot, which shows entries for `2026-03-12 06:14:22` and `2026-03-12 06:10:04`.

## Recommended Exploration Loop

Use the new `explore` harness instead of single blind writes:

1. Create a small JSON plan with one conservative candidate write at a time.
2. Run `uv run airec explore <device> --plan docs/recording-plan.example.json --baseline 1 --json`.
3. Check which notify characteristic reacts, whether readable values change, and whether any payload begins to look like catalog metadata instead of Opus transport.
4. Only after a stable catalog command is found, vary the payload to request a specific row or index and compare the response shape against the live-stream transport.

## Heart-Rate Mislabel

nRF Connect reported an appearance change from `Generic` to `Heart Monitor`, but the device does not expose the standard Heart Rate service (`0x180D`) or characteristic set. The most likely explanation is that the recorder advertises a GAP Appearance value that maps to a heart-monitor category, while the real protocol is entirely custom.

## Current Working Assumptions

- `0011202A-...` is the expected control path for archived recordings, but the CLI still keeps `E49A25E0-...` as a fallback write target because it is the only other writable custom characteristic and some firmware variants may differ.
- `0011203A-...` is the expected control reply path for archived recordings.
- `0011204A-...` is the expected bulk-data path for archived downloads.
- `0011201A-...` is the live-stream path and can continue to emit traffic even when a control reply is pending. Seeing that traffic around archive commands does not, by itself, prove the command was harmless to the live recorder.
- The archive-browsing flow currently appears to require a live-state transition before `0x04` and `0x05` succeed reliably.
- The current CLI archive commands likely work by relying on that live-state transition, not by entering a truly separate side-effect-free mode.

## Recommended Manual Experiment Order

1. Run `airec inspect <device>` and confirm the same service layout.
2. Run `airec survey <device> --duration 15` to capture baseline reads and any idle notifications.
3. Run `airec monitor <device> --duration 30` and press hardware buttons on the recorder to see whether `0011201A-...` changes rate, header mix, or framing.
4. Correlate whether one user action maps to one or more `512` byte blocks, or whether the stream is continuous regardless of user input.
5. If the vendor app can be made to connect again, repeat monitoring while changing a single app state at a time.
6. Only after correlating one notify path, try narrow writes to `0011202A-...`, `0011204A-...`, or `E49A25E0-...`.
