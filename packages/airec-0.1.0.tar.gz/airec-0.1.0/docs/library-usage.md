# Library Usage

`airec` exposes a small public Python API on top of the CLI toolkit. The supported surface is intentionally narrow and centered on device inspection, transport-independent client access, and offline analysis helpers.

## Public API

These imports are part of the documented package surface:

```python
from airec import (
    AirecClient,
    AdvertisementRecord,
    BatteryStatus,
    BleTransport,
    BleakTransport,
    DeviceProfile,
    KnownUuid,
    LiveRecordingStatus,
    RecordingDownload,
    RecordingInfo,
    StorageStatus,
    analyze_session_log,
    decode_recording_download,
    decode_session_log,
    scan_devices,
    summarize_pklg_trace,
)
```

The package also exposes `airec.__version__`.

## Common Workflows

### Scan for nearby AIREC devices

```python
import asyncio

from airec import scan_devices


async def main() -> None:
    devices = await scan_devices(timeout=5.0)
    for device in devices:
        print(device.to_dict())


asyncio.run(main())
```

### Inspect a single device profile

```python
import asyncio

from airec import AirecClient


async def main() -> None:
    client = AirecClient("AA:BB:CC:DD:EE:FF")
    profile = await client.inspect()
    print(profile.to_dict())
    await client.disconnect()


asyncio.run(main())
```

### Analyze a saved session log

```python
from pathlib import Path

from airec import analyze_session_log

summary = analyze_session_log(
    Path("artifacts/sessions/session.jsonl"),
    output_dir=Path("artifacts/analysis/session"),
)
print(summary["block_count"])
```

## Notes

- Live BLE operations depend on the local platform BLE stack through `bleak`.
- On macOS, patch the active `Python.app` bundle before the first BLE operation if Bluetooth permissions are missing.
- The project is experimental; exported helpers may grow as the reverse-engineering work matures, but the documented imports above are the intended stable entry points.

For deeper protocol findings and device-specific notes, see [protocol notes](protocol-notes.md).
