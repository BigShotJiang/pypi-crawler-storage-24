"""BLE transport abstraction plus a Bleak-backed implementation."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from typing import Any

from .macos import ensure_bluetooth_usage_description
from .protocol import AdvertisementRecord, CharacteristicInfo, DescriptorInfo, ServiceInfo

NotificationCallback = Callable[[str, bytes], Awaitable[None] | None]


class BleTransport(ABC):
    @abstractmethod
    async def scan(self, timeout: float) -> list[AdvertisementRecord]:
        raise NotImplementedError

    @abstractmethod
    async def connect(self, address: str) -> None:
        raise NotImplementedError

    @abstractmethod
    async def disconnect(self, address: str) -> None:
        raise NotImplementedError

    @abstractmethod
    async def is_connected(self, address: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def get_services(self, address: str) -> tuple[ServiceInfo, ...]:
        raise NotImplementedError

    @abstractmethod
    async def get_device_details(self, address: str) -> dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    async def read(self, address: str, characteristic_uuid: str) -> bytes:
        raise NotImplementedError

    @abstractmethod
    async def write(
        self,
        address: str,
        characteristic_uuid: str,
        payload: bytes,
        *,
        response: bool | None = None,
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    async def subscribe(
        self,
        address: str,
        characteristic_uuid: str,
        callback: NotificationCallback,
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    async def unsubscribe(self, address: str, characteristic_uuid: str) -> None:
        raise NotImplementedError


class BleakTransport(BleTransport):
    """Thin Bleak wrapper so the higher-level client stays testable."""

    def __init__(self) -> None:
        ensure_bluetooth_usage_description()
        try:
            from bleak import BleakClient, BleakScanner
        except ImportError as exc:
            raise RuntimeError(
                "bleak is not installed. Run `uv sync` before using the live BLE transport."
            ) from exc

        self._BleakClient = BleakClient
        self._BleakScanner = BleakScanner
        self._clients: dict[str, Any] = {}
        self._advertisements: dict[str, AdvertisementRecord] = {}

    async def scan(self, timeout: float) -> list[AdvertisementRecord]:
        discovered = await self._BleakScanner.discover(timeout=timeout, return_adv=True)
        records: list[AdvertisementRecord] = []
        for device, advertisement in discovered.values():
            manufacturer_data = {
                str(key): value.hex() for key, value in getattr(advertisement, "manufacturer_data", {}).items()
            }
            service_data = {
                str(key).upper(): value.hex()
                for key, value in getattr(advertisement, "service_data", {}).items()
            }
            service_uuids = tuple(str(value).upper() for value in getattr(advertisement, "service_uuids", []) or ())
            appearance = None
            platform_data = getattr(advertisement, "platform_data", ()) or ()
            for item in platform_data:
                if isinstance(item, dict) and "kCBAdvDataAppearance" in item:
                    appearance = int(item["kCBAdvDataAppearance"])
                    break

            record = AdvertisementRecord(
                address=device.address,
                name=device.name or getattr(advertisement, "local_name", None),
                rssi=getattr(advertisement, "rssi", None),
                manufacturer_data=manufacturer_data,
                service_data=service_data,
                service_uuids=service_uuids,
                appearance=appearance,
            )
            self._advertisements[record.address] = record
            records.append(record)
        return sorted(records, key=lambda record: (record.name or "", record.address))

    async def connect(self, address: str) -> None:
        client = self._clients.get(address)
        if client is None:
            client = self._BleakClient(address)
            self._clients[address] = client
        if not client.is_connected:
            await client.connect()

    async def disconnect(self, address: str) -> None:
        client = self._clients.get(address)
        if client is not None and client.is_connected:
            await client.disconnect()

    async def is_connected(self, address: str) -> bool:
        client = self._clients.get(address)
        return bool(client and client.is_connected)

    async def get_services(self, address: str) -> tuple[ServiceInfo, ...]:
        client = self._clients[address]
        services = getattr(client, "services", None)
        if not services:
            services = await client.get_services()

        service_infos: list[ServiceInfo] = []
        for service in services:
            characteristic_infos: list[CharacteristicInfo] = []
            for characteristic in service.characteristics:
                descriptors = tuple(DescriptorInfo(uuid=str(descriptor.uuid)) for descriptor in characteristic.descriptors)
                characteristic_infos.append(
                    CharacteristicInfo(
                        uuid=str(characteristic.uuid),
                        properties=tuple(characteristic.properties),
                        descriptors=descriptors,
                    )
                )
            service_infos.append(ServiceInfo(uuid=str(service.uuid), characteristics=tuple(characteristic_infos)))
        return tuple(service_infos)

    async def get_device_details(self, address: str) -> dict[str, Any]:
        advertisement = self._advertisements.get(address)
        if advertisement is None:
            return {
                "address": address,
                "name": None,
                "rssi": None,
                "manufacturer_data": {},
                "service_data": {},
                "appearance": None,
            }
        return {
            "address": advertisement.address,
            "name": advertisement.name,
            "rssi": advertisement.rssi,
            "manufacturer_data": dict(advertisement.manufacturer_data),
            "service_data": dict(advertisement.service_data),
            "appearance": advertisement.appearance,
        }

    async def read(self, address: str, characteristic_uuid: str) -> bytes:
        client = self._clients[address]
        return bytes(await client.read_gatt_char(characteristic_uuid))

    async def write(
        self,
        address: str,
        characteristic_uuid: str,
        payload: bytes,
        *,
        response: bool | None = None,
    ) -> None:
        client = self._clients[address]
        kwargs = {}
        if response is not None:
            kwargs["response"] = response
        await client.write_gatt_char(characteristic_uuid, payload, **kwargs)

    async def subscribe(
        self,
        address: str,
        characteristic_uuid: str,
        callback: NotificationCallback,
    ) -> None:
        client = self._clients[address]

        def handler(sender: Any, data: bytearray) -> None:
            maybe_awaitable = callback(str(sender), bytes(data))
            if maybe_awaitable is not None:
                import asyncio

                asyncio.create_task(maybe_awaitable)

        await client.start_notify(characteristic_uuid, handler)

    async def unsubscribe(self, address: str, characteristic_uuid: str) -> None:
        client = self._clients[address]
        await client.stop_notify(characteristic_uuid)
