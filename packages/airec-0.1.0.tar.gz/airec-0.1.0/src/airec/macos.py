"""macOS-specific runtime checks for CoreBluetooth access."""

from __future__ import annotations

import plistlib
from pathlib import Path
import sys


USAGE_KEY = "NSBluetoothAlwaysUsageDescription"
DEFAULT_USAGE_DESCRIPTION = "AIREC uses Bluetooth to discover and communicate with the AIREC voice recorder."


def find_python_app_info_plist(executable: str | Path | None = None) -> Path | None:
    executable_path = Path(executable or sys.executable).resolve()
    candidates = [
        executable_path.parent.parent / "Resources" / "Python.app" / "Contents" / "Info.plist",
        executable_path.parent / "Resources" / "Python.app" / "Contents" / "Info.plist",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def get_bluetooth_usage_description(executable: str | Path | None = None) -> str | None:
    plist_path = find_python_app_info_plist(executable)
    if plist_path is None:
        return None
    with plist_path.open("rb") as handle:
        plist = plistlib.load(handle)
    value = plist.get(USAGE_KEY)
    if isinstance(value, str) and value.strip():
        return value
    return None


def ensure_bluetooth_usage_description(executable: str | Path | None = None) -> None:
    if sys.platform != "darwin":
        return

    plist_path = find_python_app_info_plist(executable)
    if plist_path is None:
        raise RuntimeError(
            "macOS BLE preflight failed: could not locate the host Python.app Info.plist for "
            f"`{Path(executable or sys.executable).resolve()}`. "
            "Use a Python build with a bundle plist, or patch the bundle manually with "
            f"{USAGE_KEY}."
        )

    description = get_bluetooth_usage_description(executable)
    if description is not None:
        return

    raise RuntimeError(
        "macOS blocked Bluetooth access because the host Python.app is missing "
        f"`{USAGE_KEY}`.\n"
        f"Host plist: {plist_path}\n"
        "Before running `airec scan`, patch that plist with a Bluetooth usage description. "
        "This repo includes `scripts/patch_macos_python_app_bundle.py` to do that for the "
        "current interpreter."
    )

