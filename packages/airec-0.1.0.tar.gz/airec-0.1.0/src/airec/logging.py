"""Structured event logging for BLE reverse-engineering sessions."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
import json
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class CapturedEvent:
    event_type: str
    device: str | None = None
    characteristic_uuid: str | None = None
    payload_hex: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "event_type": self.event_type,
            "device": self.device,
            "characteristic_uuid": self.characteristic_uuid,
            "payload_hex": self.payload_hex,
            "metadata": self.metadata,
        }


class SessionLogger:
    """Writes newline-delimited JSON events for each experiment."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def record(self, event: CapturedEvent) -> None:
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event.to_dict(), sort_keys=True))
            handle.write("\n")

    def record_event(
        self,
        event_type: str,
        *,
        device: str | None = None,
        characteristic_uuid: str | None = None,
        payload: bytes | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> CapturedEvent:
        event = CapturedEvent(
            event_type=event_type,
            device=device,
            characteristic_uuid=characteristic_uuid,
            payload_hex=payload.hex() if payload is not None else None,
            metadata=metadata or {},
        )
        self.record(event)
        return event

