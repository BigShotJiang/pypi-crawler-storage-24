"""High-level AIREC client built on a replaceable BLE transport."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import Any

from .logging import SessionLogger
from .protocol import (
    BatteryStatus,
    DeviceProfile,
    HEART_RATE_MISLABEL_NOTE,
    KnownUuid,
    LiveRecordingStatus,
    RecordingDownload,
    RecordingInfo,
    ServiceInfo,
    StorageStatus,
    normalize_recording_id,
    normalize_uuid,
)
from .transport import BleTransport, BleakTransport


async def scan_devices(timeout: float = 5.0, adapter: BleTransport | None = None):
    transport = adapter or BleakTransport()
    return await transport.scan(timeout)


class AirecClient:
    def __init__(self, address: str, adapter: BleTransport | None = None) -> None:
        self.address = address
        self.adapter = adapter or BleakTransport()

    async def connect(self) -> None:
        await self.adapter.connect(self.address)

    async def disconnect(self) -> None:
        await self.adapter.disconnect(self.address)

    async def inspect(self) -> DeviceProfile:
        await self.connect()
        services = await self.adapter.get_services(self.address)
        details = await self.adapter.get_device_details(self.address)
        notes = [HEART_RATE_MISLABEL_NOTE] if details.get("appearance") == 833 else []
        return DeviceProfile(
            address=self.address,
            name=details.get("name"),
            rssi=details.get("rssi"),
            manufacturer_data=details.get("manufacturer_data", {}),
            service_data=details.get("service_data", {}),
            appearance=details.get("appearance"),
            services=services,
            notes=tuple(notes),
        )

    async def read(self, uuid: str) -> bytes:
        await self.connect()
        return await self.adapter.read(self.address, normalize_uuid(uuid))

    async def write(self, uuid: str, payload: bytes, response: bool | None = None) -> None:
        await self.connect()
        await self.adapter.write(self.address, normalize_uuid(uuid), payload, response=response)

    async def subscribe(
        self,
        uuid: str,
        callback: Callable[[str, bytes], Any],
    ) -> None:
        await self.connect()
        await self.adapter.subscribe(self.address, normalize_uuid(uuid), callback)

    async def unsubscribe(self, uuid: str) -> None:
        await self.adapter.unsubscribe(self.address, normalize_uuid(uuid))

    async def subscribe_all_notifiers(
        self,
        profile: DeviceProfile,
        callback: Callable[[str, bytes], Any],
    ) -> tuple[str, ...]:
        notify_uuids: list[str] = []
        for service in profile.services:
            for characteristic in service.characteristics:
                if _supports_notify(characteristic.properties):
                    await self.subscribe(characteristic.uuid, callback)
                    notify_uuids.append(characteristic.uuid)
        return tuple(notify_uuids)

    async def get_live_recording_status(
        self,
        *,
        timeout: float = 5.0,
        logger: SessionLogger | None = None,
    ) -> LiveRecordingStatus:
        profile = await self.inspect()
        candidate_uuids = _recording_write_candidates(profile.services)

        live_status: LiveRecordingStatus | None = None
        completed = asyncio.Event()

        async def control_callback(sender: str, payload: bytes) -> None:
            nonlocal live_status

            attach_logger(
                logger,
                event_type="recording_control_notification",
                device=self.address,
                characteristic_uuid=sender,
                payload=payload,
            )
            frame = _parse_command_frame(payload)
            if frame is None or frame["command_id"] != 0x0F:
                return
            live_status = _parse_live_recording_status(frame["payload"])
            completed.set()

        subscribed_uuids = await self._subscribe_recording_notifiers(profile, control_callback, logger=logger)
        try:
            await self._send_recording_command_until(
                services=profile.services,
                command_name="recording_live_status_request",
                completion_description="live recording status response",
                candidate_uuids=candidate_uuids,
                payload=_build_command_frame(0x0F),
                completion_event=completed,
                timeout=timeout,
                logger=logger,
            )
        finally:
            for characteristic_uuid in subscribed_uuids:
                await self.unsubscribe(characteristic_uuid)

        if live_status is None:
            raise ValueError("missing live recording status response")
        return live_status

    async def get_battery_status(
        self,
        *,
        timeout: float = 5.0,
        logger: SessionLogger | None = None,
    ) -> BatteryStatus:
        profile = await self.inspect()
        candidate_uuids = _recording_write_candidates(profile.services)

        battery_status: BatteryStatus | None = None
        completed = asyncio.Event()

        async def control_callback(sender: str, payload: bytes) -> None:
            nonlocal battery_status

            attach_logger(
                logger,
                event_type="recording_control_notification",
                device=self.address,
                characteristic_uuid=sender,
                payload=payload,
            )
            frame = _parse_command_frame(payload)
            if frame is None or frame["command_id"] != 0x0E:
                return
            battery_status = _parse_battery_status(frame["payload"])
            completed.set()

        subscribed_uuids = await self._subscribe_recording_notifiers(profile, control_callback, logger=logger)
        try:
            await self._send_recording_command_until(
                services=profile.services,
                command_name="recording_battery_status_request",
                completion_description="battery status response",
                candidate_uuids=candidate_uuids,
                payload=_build_command_frame(0x0E),
                completion_event=completed,
                timeout=timeout,
                logger=logger,
            )
        finally:
            for characteristic_uuid in subscribed_uuids:
                await self.unsubscribe(characteristic_uuid)

        if battery_status is None:
            raise ValueError("missing battery status response")
        return battery_status

    async def get_storage_status(
        self,
        *,
        timeout: float = 5.0,
        logger: SessionLogger | None = None,
    ) -> StorageStatus:
        profile = await self.inspect()
        candidate_uuids = _recording_write_candidates(profile.services)

        value_0c: int | None = None
        value_0d: int | None = None
        completed = asyncio.Event()

        async def control_callback(sender: str, payload: bytes) -> None:
            nonlocal value_0c, value_0d

            attach_logger(
                logger,
                event_type="recording_control_notification",
                device=self.address,
                characteristic_uuid=sender,
                payload=payload,
            )
            frame = _parse_command_frame(payload)
            if frame is None:
                return
            if frame["command_id"] == 0x0C:
                value_0c = _parse_storage_value(frame["payload"], command_id=0x0C)
            elif frame["command_id"] == 0x0D:
                value_0d = _parse_storage_value(frame["payload"], command_id=0x0D)
            else:
                return
            if value_0c is not None and value_0d is not None:
                completed.set()

        subscribed_uuids = await self._subscribe_recording_notifiers(profile, control_callback, logger=logger)
        try:
            await self._send_recording_command_until(
                services=profile.services,
                command_name="recording_storage_status_request",
                completion_description="storage status response",
                candidate_uuids=candidate_uuids,
                payload=_build_command_frame(0x0B),
                completion_event=completed,
                timeout=timeout,
                logger=logger,
            )
        finally:
            for characteristic_uuid in subscribed_uuids:
                await self.unsubscribe(characteristic_uuid)

        return StorageStatus(value_0c=value_0c, value_0d=value_0d)

    async def pause_resume_live_recording(
        self,
        *,
        timeout: float = 5.0,
        logger: SessionLogger | None = None,
    ) -> bool:
        profile = await self.inspect()
        candidate_uuids = _recording_write_candidates(profile.services)

        completed = asyncio.Event()

        async def control_callback(sender: str, payload: bytes) -> None:
            attach_logger(
                logger,
                event_type="recording_control_notification",
                device=self.address,
                characteristic_uuid=sender,
                payload=payload,
            )
            frame = _parse_command_frame(payload)
            if frame is None or frame["command_id"] != 0x10:
                return
            completed.set()

        subscribed_uuids = await self._subscribe_recording_notifiers(profile, control_callback, logger=logger)
        try:
            await self._send_recording_command_until(
                services=profile.services,
                command_name="recording_live_pause_resume_request",
                completion_description="live pause/resume acknowledgement",
                candidate_uuids=candidate_uuids,
                payload=_build_command_frame(0x10),
                completion_event=completed,
                timeout=timeout,
                logger=logger,
            )
        finally:
            for characteristic_uuid in subscribed_uuids:
                await self.unsubscribe(characteristic_uuid)

        return True

    async def toggle_live_recording(
        self,
        *,
        timeout: float = 5.0,
        logger: SessionLogger | None = None,
    ) -> bool:
        return await self.pause_resume_live_recording(timeout=timeout, logger=logger)

    async def list_recordings(
        self,
        *,
        timeout: float = 5.0,
        logger: SessionLogger | None = None,
        include_live_state_transition: bool = True,
    ) -> tuple[RecordingInfo, ...]:
        profile = await self.inspect()
        candidate_uuids = _recording_write_candidates(profile.services)

        recordings: list[RecordingInfo] = []
        completed = asyncio.Event()
        live_state_transition_ready = asyncio.Event()
        current_recording_info_ready = asyncio.Event()

        async def control_callback(sender: str, payload: bytes) -> None:
            attach_logger(
                logger,
                event_type="recording_control_notification",
                device=self.address,
                characteristic_uuid=sender,
                payload=payload,
            )
            frame = _parse_command_frame(payload)
            if frame is None:
                return
            if frame["command_id"] == 0x10:
                live_state_transition_ready.set()
                return
            if frame["command_id"] == 0x04:
                current_recording_info_ready.set()
                return
            if frame["command_id"] == 0x05:
                recording = _parse_recording_entry(frame["payload"])
                recordings.append(recording)
                if logger is not None:
                    logger.record_event(
                        "recording_catalog_item",
                        device=self.address,
                        characteristic_uuid=sender,
                        metadata=recording.to_dict(),
                    )
                return
            if frame["command_id"] == 0x06:
                completed.set()

        subscribed_uuids = await self._subscribe_recording_notifiers(profile, control_callback, logger=logger)
        try:
            await self._prepare_recording_catalog(
                profile.services,
                candidate_uuids=candidate_uuids,
                live_state_transition_ready=live_state_transition_ready,
                current_recording_info_ready=current_recording_info_ready,
                timeout=timeout,
                logger=logger,
                include_live_state_transition=include_live_state_transition,
            )
            await self._send_recording_command_until(
                services=profile.services,
                command_name="recording_list_request",
                completion_description="recording list response",
                candidate_uuids=candidate_uuids,
                payload=_build_command_frame(0x05),
                completion_event=completed,
                timeout=timeout,
                logger=logger,
            )
        finally:
            for characteristic_uuid in subscribed_uuids:
                await self.unsubscribe(characteristic_uuid)

        return tuple(recordings)

    async def delete_recording(
        self,
        recording_id: str,
        *,
        timeout: float = 5.0,
        logger: SessionLogger | None = None,
    ) -> str:
        profile = await self.inspect()
        candidate_uuids = _recording_write_candidates(profile.services)

        normalized_id = normalize_recording_id(recording_id)
        live_state_transition_ready = asyncio.Event()
        current_recording_info_ready = asyncio.Event()
        delete_ack = asyncio.Event()

        async def control_callback(sender: str, payload: bytes) -> None:
            attach_logger(
                logger,
                event_type="recording_control_notification",
                device=self.address,
                characteristic_uuid=sender,
                payload=payload,
            )
            frame = _parse_command_frame(payload)
            if frame is None:
                return
            command_id = frame["command_id"]
            if command_id == 0x10:
                live_state_transition_ready.set()
                return
            if command_id == 0x04:
                current_recording_info_ready.set()
                return
            if command_id == 0x0A:
                delete_ack.set()

        subscribed_uuids = await self._subscribe_recording_notifiers(profile, control_callback, logger=logger)
        try:
            await self._prepare_recording_catalog(
                profile.services,
                candidate_uuids=candidate_uuids,
                live_state_transition_ready=live_state_transition_ready,
                current_recording_info_ready=current_recording_info_ready,
                timeout=timeout,
                logger=logger,
            )
            await self._send_recording_command_until(
                services=profile.services,
                command_name="recording_delete_request",
                completion_description=f"delete acknowledgement for {normalized_id}",
                candidate_uuids=candidate_uuids,
                payload=_build_command_frame(0x0A, normalized_id.encode("ascii")),
                completion_event=delete_ack,
                timeout=timeout,
                logger=logger,
            )
        finally:
            for characteristic_uuid in subscribed_uuids:
                await self.unsubscribe(characteristic_uuid)

        return normalized_id

    async def download_recording(
        self,
        recording_id: str,
        *,
        timeout: float = 30.0,
        logger: SessionLogger | None = None,
    ) -> RecordingDownload:
        profile = await self.inspect()
        candidate_uuids = _recording_write_candidates(profile.services)

        normalized_id = normalize_recording_id(recording_id)
        live_state_transition_ready = asyncio.Event()
        current_recording_info_ready = asyncio.Event()
        select_ack = asyncio.Event()
        download_ack = asyncio.Event()
        transfer_complete = asyncio.Event()
        expected_size_bytes: int | None = None
        data_notifications = 0
        payload_buffer = bytearray()

        async def control_callback(sender: str, payload: bytes) -> None:
            nonlocal expected_size_bytes

            attach_logger(
                logger,
                event_type="recording_control_notification",
                device=self.address,
                characteristic_uuid=sender,
                payload=payload,
            )
            frame = _parse_command_frame(payload)
            if frame is None:
                await data_callback(sender, payload)
                return
            command_id = frame["command_id"]
            if command_id == 0x10:
                live_state_transition_ready.set()
                return
            if command_id == 0x04:
                current_recording_info_ready.set()
                return
            if command_id == 0x02:
                select_ack.set()
                return
            if command_id == 0x07:
                ack_recording_id, expected_size_bytes = _parse_download_ack(frame["payload"])
                if ack_recording_id == normalized_id:
                    download_ack.set()
                return
            if command_id == 0x09:
                transfer_complete.set()

        async def data_callback(sender: str, payload: bytes) -> None:
            nonlocal data_notifications

            if not download_ack.is_set():
                attach_logger(
                    logger,
                    event_type="recording_data_ignored",
                    device=self.address,
                    characteristic_uuid=sender,
                    payload=payload,
                    metadata={"reason": "download_not_acknowledged"},
                )
                return
            data_notifications += 1
            payload_buffer.extend(payload)
            attach_logger(
                logger,
                event_type="recording_data_notification",
                device=self.address,
                characteristic_uuid=sender,
                payload=payload,
                metadata={
                    "data_notifications": data_notifications,
                    "bytes_received": len(payload_buffer),
                },
            )

        subscribed_uuids = await self._subscribe_recording_notifiers(profile, control_callback, logger=logger)
        try:
            await self._prepare_recording_catalog(
                profile.services,
                candidate_uuids=candidate_uuids,
                live_state_transition_ready=live_state_transition_ready,
                current_recording_info_ready=current_recording_info_ready,
                timeout=timeout,
                logger=logger,
            )
            select_payload = _build_command_frame(0x02, normalized_id.encode("ascii"))
            selected_uuid = await self._send_recording_command_until(
                services=profile.services,
                command_name="recording_select_request",
                completion_description=f"recording selection for {normalized_id}",
                candidate_uuids=candidate_uuids,
                payload=select_payload,
                completion_event=select_ack,
                timeout=timeout,
                logger=logger,
            )

            download_payload = _build_command_frame(
                0x07,
                normalized_id.encode("ascii") + b"\x00\x00\x00\x00",
            )
            attach_logger(
                logger,
                event_type="recording_download_request",
                device=self.address,
                characteristic_uuid=selected_uuid,
                payload=download_payload,
                metadata={"response": choose_response_mode(profile.services, selected_uuid, False)},
            )
            await self._write_control_command(
                selected_uuid,
                download_payload,
                response=choose_response_mode(profile.services, selected_uuid, False),
                logger=logger,
            )
            try:
                await asyncio.wait_for(download_ack.wait(), timeout=timeout)
            except TimeoutError as exc:
                raise ValueError(f"timed out waiting for download acknowledgement for {normalized_id}") from exc
            try:
                await asyncio.wait_for(transfer_complete.wait(), timeout=timeout)
            except TimeoutError as exc:
                raise ValueError(f"timed out waiting for recording data for {normalized_id}") from exc
        finally:
            for characteristic_uuid in subscribed_uuids:
                await self.unsubscribe(characteristic_uuid)

        return RecordingDownload(
            recording_id=normalized_id,
            data=bytes(payload_buffer),
            expected_size_bytes=expected_size_bytes,
            data_notifications=data_notifications,
        )

    async def cancel_download(
        self,
        *,
        timeout: float = 5.0,
        logger: SessionLogger | None = None,
    ) -> bool:
        profile = await self.inspect()
        candidate_uuids = _recording_write_candidates(profile.services)

        cancel_ack = asyncio.Event()

        async def control_callback(sender: str, payload: bytes) -> None:
            attach_logger(
                logger,
                event_type="recording_control_notification",
                device=self.address,
                characteristic_uuid=sender,
                payload=payload,
            )
            frame = _parse_command_frame(payload)
            if frame is None or frame["command_id"] != 0x08:
                return
            cancel_ack.set()

        subscribed_uuids = await self._subscribe_recording_notifiers(profile, control_callback, logger=logger)
        try:
            await self._send_recording_command_until(
                services=profile.services,
                command_name="recording_cancel_request",
                completion_description="download cancel acknowledgement",
                candidate_uuids=candidate_uuids,
                payload=_build_command_frame(0x08),
                completion_event=cancel_ack,
                timeout=timeout,
                logger=logger,
            )
        finally:
            for characteristic_uuid in subscribed_uuids:
                await self.unsubscribe(characteristic_uuid)

        return True

    async def _prepare_recording_catalog(
        self,
        services: tuple[ServiceInfo, ...],
        *,
        candidate_uuids: tuple[str, ...],
        live_state_transition_ready: asyncio.Event,
        current_recording_info_ready: asyncio.Event,
        timeout: float,
        logger: SessionLogger | None,
        include_live_state_transition: bool = True,
    ) -> None:
        preflight_timeout = min(1.0, max(timeout / 4, 0.25))
        if include_live_state_transition:
            await self._try_recording_command(
                services=services,
                command_name="recording_live_state_transition_request",
                completion_description="live state transition acknowledgement",
                candidate_uuids=candidate_uuids,
                payload=_build_command_frame(0x10),
                completion_event=live_state_transition_ready,
                timeout=preflight_timeout,
                logger=logger,
            )
        await self._try_recording_command(
            services=services,
            command_name="recording_current_info_request",
            completion_description="current recording info response",
            candidate_uuids=candidate_uuids,
            payload=_build_command_frame(0x04),
            completion_event=current_recording_info_ready,
            timeout=preflight_timeout,
            logger=logger,
        )

    async def _write_control_command(
        self,
        uuid: str,
        payload: bytes,
        *,
        response: bool | None,
        logger: SessionLogger | None,
    ) -> None:
        try:
            await self.write(uuid, payload, response=response)
            return
        except Exception as exc:
            fallback_response = _fallback_response_mode(response, exc)
            if fallback_response is None:
                raise
            attach_logger(
                logger,
                event_type="recording_write_retry",
                device=self.address,
                characteristic_uuid=uuid,
                payload=payload,
                metadata={
                    "from_response": response,
                    "to_response": fallback_response,
                    "error": str(exc),
                },
            )
        await self.write(uuid, payload, response=fallback_response)

    async def _send_recording_command_until(
        self,
        *,
        services: tuple[ServiceInfo, ...],
        command_name: str,
        completion_description: str,
        candidate_uuids: tuple[str, ...],
        payload: bytes,
        completion_event: asyncio.Event,
        timeout: float,
        logger: SessionLogger | None,
    ) -> str:
        if completion_event.is_set():
            return candidate_uuids[0]
        for index, characteristic_uuid in enumerate(candidate_uuids):
            response_mode = choose_response_mode(services, characteristic_uuid, False)
            attach_logger(
                logger,
                event_type=command_name,
                device=self.address,
                characteristic_uuid=characteristic_uuid,
                payload=payload,
                metadata={"response": response_mode, "attempt": index},
            )
            await self._write_control_command(
                characteristic_uuid,
                payload,
                response=response_mode,
                logger=logger,
            )
            remaining_attempts = len(candidate_uuids) - index
            wait_timeout = timeout / remaining_attempts
            try:
                await asyncio.wait_for(completion_event.wait(), timeout=wait_timeout)
                return characteristic_uuid
            except TimeoutError:
                if completion_event.is_set():
                    return characteristic_uuid
                continue
        raise ValueError(f"timed out waiting for {completion_description}")

    async def _try_recording_command(
        self,
        *,
        services: tuple[ServiceInfo, ...],
        command_name: str,
        completion_description: str,
        candidate_uuids: tuple[str, ...],
        payload: bytes,
        completion_event: asyncio.Event,
        timeout: float,
        logger: SessionLogger | None,
    ) -> None:
        try:
            await self._send_recording_command_until(
                services=services,
                command_name=command_name,
                completion_description=completion_description,
                candidate_uuids=candidate_uuids,
                payload=payload,
                completion_event=completion_event,
                timeout=timeout,
                logger=logger,
            )
        except ValueError as exc:
            attach_logger(
                logger,
                event_type="recording_preflight_timeout",
                device=self.address,
                metadata={
                    "command_name": command_name,
                    "completion_description": completion_description,
                    "error": str(exc),
                },
            )

    async def _subscribe_recording_notifiers(
        self,
        profile: DeviceProfile,
        callback: Callable[[str, bytes], Any],
        *,
        logger: SessionLogger | None,
    ) -> tuple[str, ...]:
        subscribed_uuids = list(await self.subscribe_all_notifiers(profile, callback))
        for characteristic_uuid in (
            KnownUuid.PRIMARY_NOTIFY_ALT,
            KnownUuid.PRIMARY_NOTIFY_ALT_2,
            KnownUuid.AUXILIARY_NOTIFY,
        ):
            if characteristic_uuid in subscribed_uuids:
                continue
            try:
                await self.subscribe(characteristic_uuid, callback)
            except Exception as exc:
                attach_logger(
                    logger,
                    event_type="recording_subscribe_optional_failed",
                    device=self.address,
                    characteristic_uuid=characteristic_uuid,
                    metadata={"error": str(exc)},
                )
                continue
            subscribed_uuids.append(characteristic_uuid)
        return tuple(subscribed_uuids)


def _supports_notify(properties: tuple[str, ...]) -> bool:
    supported = {"notify", "indicate"}
    return bool(supported.intersection(properties))


def _supports_write(properties: tuple[str, ...]) -> bool:
    supported = {"write", "write-without-response"}
    return bool(supported.intersection(properties))


def _recording_write_candidates(services: tuple[ServiceInfo, ...]) -> tuple[str, ...]:
    ordered_candidates = [KnownUuid.PRIMARY_RW, KnownUuid.AUXILIARY_RW]
    available: list[str] = []
    for candidate_uuid in ordered_candidates:
        for service in services:
            for characteristic in service.characteristics:
                if characteristic.uuid == candidate_uuid and _supports_write(characteristic.properties):
                    available.append(candidate_uuid)
                    break
            else:
                continue
            break
    return tuple(available or [KnownUuid.PRIMARY_RW])


def choose_response_mode(services: tuple[ServiceInfo, ...], characteristic_uuid: str, response: bool | None) -> bool | None:
    if response is not None:
        return response

    target_uuid = normalize_uuid(characteristic_uuid)
    for service in services:
        for characteristic in service.characteristics:
            if characteristic.uuid != target_uuid:
                continue
            if "write" in characteristic.properties:
                return True
            if "write-without-response" in characteristic.properties:
                return False
            return None
    return None


def attach_logger(logger: SessionLogger | None, *, event_type: str, device: str, characteristic_uuid: str | None = None, payload: bytes | None = None, metadata: dict[str, Any] | None = None) -> None:
    if logger is not None:
        logger.record_event(
            event_type,
            device=device,
            characteristic_uuid=characteristic_uuid,
            payload=payload,
            metadata=metadata,
        )


def _fallback_response_mode(response: bool | None, exc: Exception) -> bool | None:
    message = str(exc).lower()
    if "not permitted" not in message and "without response" not in message and "with response" not in message:
        return None
    if response is True:
        return False
    if response is False:
        return True
    return False


def _build_command_frame(command_id: int, payload: bytes = b"") -> bytes:
    if not 0 <= command_id <= 0xFF:
        raise ValueError(f"command ID must fit in one byte: {command_id}")
    total_length = 1 + len(payload)
    if total_length > 0xFF:
        raise ValueError(f"command payload is too large: {len(payload)} bytes")
    return b"\x55\xaa" + bytes([total_length, command_id]) + payload


def _parse_command_frame(payload: bytes) -> dict[str, Any] | None:
    if len(payload) < 4 or payload[:2] != b"\xaa\x55":
        return None
    total_length = payload[2]
    if total_length < 1:
        return None
    command_id = payload[3]
    frame_payload_length = total_length - 1
    if len(payload) < 4 + frame_payload_length:
        return None
    return {
        "command_id": command_id,
        "payload": payload[4 : 4 + frame_payload_length],
    }


def _parse_recording_entry(payload: bytes) -> RecordingInfo:
    if len(payload) < 18:
        raise ValueError(f"recording list payload is too short: {payload.hex()}")
    try:
        recording_id = payload[:14].decode("ascii")
    except UnicodeDecodeError as exc:
        raise ValueError(f"recording list entry contains a non-ASCII timestamp: {payload.hex()}") from exc
    return RecordingInfo(recording_id=recording_id, metadata_hex=payload[14:18].hex())


def _parse_download_ack(payload: bytes) -> tuple[str, int | None]:
    if len(payload) < 14:
        raise ValueError(f"download acknowledgement is too short: {payload.hex()}")
    try:
        recording_id = payload[:14].decode("ascii")
    except UnicodeDecodeError as exc:
        raise ValueError(f"download acknowledgement contains a non-ASCII timestamp: {payload.hex()}") from exc
    expected_size_bytes = None
    if len(payload) >= 18:
        expected_size_bytes = int.from_bytes(payload[14:18], "big")
    return normalize_recording_id(recording_id), expected_size_bytes


def _parse_live_recording_status(payload: bytes) -> LiveRecordingStatus:
    if not payload:
        raise ValueError("live recording status payload is empty")
    status_code = payload[0]
    recording_id = None
    extra_start = 1
    if len(payload) >= 15:
        try:
            recording_id = payload[1:15].decode("ascii")
            extra_start = 15
        except UnicodeDecodeError as exc:
            raise ValueError(
                f"live recording status contains a non-ASCII timestamp: {payload.hex()}"
            ) from exc
    return LiveRecordingStatus(
        status_code=status_code,
        recording_id=recording_id,
        extra_hex=payload[extra_start:].hex(),
    )


def _parse_battery_status(payload: bytes) -> BatteryStatus:
    if not payload:
        raise ValueError("battery status payload is empty")
    return BatteryStatus(percent=payload[0], raw_hex=payload.hex())


def _parse_storage_value(payload: bytes, *, command_id: int) -> int:
    if len(payload) < 4:
        raise ValueError(f"storage response 0x{command_id:02x} is too short: {payload.hex()}")
    return int.from_bytes(payload[:4], "big")
