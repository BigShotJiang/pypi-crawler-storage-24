"""Automated BLE probing routines for structured reverse-engineering passes."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any

from .client import AirecClient
from .logging import SessionLogger
from .protocol import CharacteristicInfo, DeviceProfile, ServiceInfo, normalize_uuid

NotificationHandler = Callable[[str, bytes], Awaitable[None] | None]


@dataclass(slots=True)
class ExploreStep:
    label: str
    characteristic_uuid: str
    payload: bytes
    response: bool | None
    wait_after: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "characteristic_uuid": self.characteristic_uuid,
            "payload_hex": self.payload.hex(),
            "response": self.response,
            "wait_after": self.wait_after,
        }


async def survey_device(
    client: AirecClient,
    logger: SessionLogger,
    *,
    notification_window: float,
    notification_handler: NotificationHandler | None = None,
) -> dict[str, Any]:
    profile = await client.inspect()
    logger.record_event("inspect", device=client.address, metadata=profile.to_dict())
    logger.record_event(
        "survey_started",
        device=client.address,
        metadata={"notification_window": notification_window},
    )

    notifications: list[dict[str, Any]] = []
    reads: list[dict[str, Any]] = []
    subscriptions: list[dict[str, Any]] = []
    subscribed_uuids: list[str] = []

    async def callback(sender: str, payload: bytes) -> None:
        event = {
            "sender": sender,
            "payload_hex": payload.hex(),
        }
        notifications.append(event)
        logger.record_event(
            "notification",
            device=client.address,
            characteristic_uuid=sender,
            payload=payload,
        )
        if notification_handler is not None:
            maybe_awaitable = notification_handler(sender, payload)
            if maybe_awaitable is not None:
                await maybe_awaitable

    for service, characteristic in iter_characteristics(profile):
        metadata = {
            "service_uuid": service.uuid,
            "properties": list(characteristic.properties),
            "descriptors": [descriptor.uuid for descriptor in characteristic.descriptors],
        }
        logger.record_event(
            "survey_characteristic",
            device=client.address,
            characteristic_uuid=characteristic.uuid,
            metadata=metadata,
        )

        if supports_read(characteristic):
            reads.append(await _read_characteristic(client, logger, service, characteristic))

        if supports_notify(characteristic):
            subscription = await _subscribe_characteristic(client, logger, service, characteristic, callback)
            subscriptions.append(subscription)
            if subscription["status"] == "subscribed":
                subscribed_uuids.append(characteristic.uuid)

    if subscribed_uuids and notification_window > 0:
        await asyncio.sleep(notification_window)

    for characteristic_uuid in subscribed_uuids:
        try:
            await client.unsubscribe(characteristic_uuid)
            logger.record_event(
                "unsubscribe_result",
                device=client.address,
                characteristic_uuid=characteristic_uuid,
                metadata={"status": "ok"},
            )
        except Exception as exc:
            logger.record_event(
                "unsubscribe_error",
                device=client.address,
                characteristic_uuid=characteristic_uuid,
                metadata={"error": str(exc)},
            )

    result = {
        "device": client.address,
        "profile": profile.to_dict(),
        "reads": reads,
        "subscriptions": subscriptions,
        "notifications": notifications,
        "log_file": str(logger.path),
    }
    logger.record_event(
        "survey_completed",
        device=client.address,
        metadata={
            "reads": len(reads),
            "subscriptions": len(subscriptions),
            "notifications": len(notifications),
        },
    )
    return result


def load_explore_steps(path: Path) -> tuple[ExploreStep, ...]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"explore plan does not exist: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON in explore plan: {path}") from exc

    if not isinstance(raw, list):
        raise ValueError("explore plan must be a JSON array of step objects")

    steps: list[ExploreStep] = []
    for index, item in enumerate(raw, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"explore step {index} must be an object")
        characteristic_uuid = item.get("char") or item.get("characteristic_uuid")
        payload_hex = item.get("hex") or item.get("payload_hex")
        if not isinstance(characteristic_uuid, str) or not characteristic_uuid.strip():
            raise ValueError(f"explore step {index} is missing a characteristic UUID")
        if not isinstance(payload_hex, str) or not payload_hex.strip():
            raise ValueError(f"explore step {index} is missing a payload hex string")
        label = item.get("label")
        if label is None:
            label = f"step-{index}"
        if not isinstance(label, str) or not label.strip():
            raise ValueError(f"explore step {index} has an invalid label")
        wait_after = item.get("wait_after", item.get("wait", 1.0))
        if not isinstance(wait_after, int | float) or wait_after < 0:
            raise ValueError(f"explore step {index} has an invalid wait_after value")
        response = _coerce_response_mode(item.get("response"))
        try:
            payload = bytes.fromhex(payload_hex)
        except ValueError as exc:
            raise ValueError(f"explore step {index} has invalid hex payload") from exc
        steps.append(
            ExploreStep(
                label=label.strip(),
                characteristic_uuid=normalize_uuid(characteristic_uuid),
                payload=payload,
                response=response,
                wait_after=float(wait_after),
            )
        )
    return tuple(steps)


async def explore_recording_services(
    client: AirecClient,
    logger: SessionLogger,
    *,
    steps: tuple[ExploreStep, ...],
    baseline_window: float,
    read_after_each: bool = True,
) -> dict[str, Any]:
    profile = await client.inspect()
    logger.record_event("inspect", device=client.address, metadata=profile.to_dict())
    logger.record_event(
        "explore_started",
        device=client.address,
        metadata={
            "baseline_window": baseline_window,
            "read_after_each": read_after_each,
            "step_count": len(steps),
            "steps": [step.to_dict() for step in steps],
        },
    )

    subscriptions: list[dict[str, Any]] = []
    subscribed_uuids: list[str] = []
    baseline_notifications: list[dict[str, Any]] = []
    all_notifications: list[dict[str, Any]] = []
    phase = {"type": "baseline", "step_index": None, "step_label": "baseline"}
    step_results: list[dict[str, Any]] = []

    async def callback(sender: str, payload: bytes) -> None:
        event = {
            "sender": sender,
            "payload_hex": payload.hex(),
            "phase": phase["type"],
            "step_index": phase["step_index"],
            "step_label": phase["step_label"],
        }
        all_notifications.append(event)
        logger.record_event(
            "notification",
            device=client.address,
            characteristic_uuid=sender,
            payload=payload,
            metadata={
                "phase": phase["type"],
                "step_index": phase["step_index"],
                "step_label": phase["step_label"],
            },
        )
        if phase["step_index"] is None:
            baseline_notifications.append(event)
            return
        step_results[phase["step_index"]]["notifications"].append(event)

    for service, characteristic in iter_characteristics(profile):
        if not supports_notify(characteristic):
            continue
        subscription = await _subscribe_characteristic(client, logger, service, characteristic, callback)
        subscriptions.append(subscription)
        if subscription["status"] == "subscribed":
            subscribed_uuids.append(characteristic.uuid)

    baseline_reads = await snapshot_readable_characteristics(
        client,
        logger,
        profile,
        phase_type="baseline",
        step_index=None,
        step_label="baseline",
    )
    if baseline_window > 0:
        await asyncio.sleep(baseline_window)

    for step_index, step in enumerate(steps):
        result = {
            "index": step_index,
            "label": step.label,
            "characteristic_uuid": step.characteristic_uuid,
            "payload_hex": step.payload.hex(),
            "response": step.response,
            "wait_after": step.wait_after,
            "write_status": "pending",
            "reads": [],
            "notifications": [],
        }
        step_results.append(result)
        phase.update({"type": "step", "step_index": step_index, "step_label": step.label})
        logger.record_event(
            "explore_step_started",
            device=client.address,
            characteristic_uuid=step.characteristic_uuid,
            payload=step.payload,
            metadata={
                "step_index": step_index,
                "step_label": step.label,
                "response": step.response,
                "wait_after": step.wait_after,
            },
        )
        try:
            await client.write(step.characteristic_uuid, step.payload, response=step.response)
        except Exception as exc:
            result["write_status"] = "error"
            result["error"] = str(exc)
            logger.record_event(
                "explore_step_error",
                device=client.address,
                characteristic_uuid=step.characteristic_uuid,
                payload=step.payload,
                metadata={
                    "step_index": step_index,
                    "step_label": step.label,
                    "error": str(exc),
                },
            )
        else:
            result["write_status"] = "ok"
            logger.record_event(
                "explore_step_write",
                device=client.address,
                characteristic_uuid=step.characteristic_uuid,
                payload=step.payload,
                metadata={
                    "step_index": step_index,
                    "step_label": step.label,
                    "response": step.response,
                },
            )
        if step.wait_after > 0:
            await asyncio.sleep(step.wait_after)
        if read_after_each:
            result["reads"] = await snapshot_readable_characteristics(
                client,
                logger,
                profile,
                phase_type="step",
                step_index=step_index,
                step_label=step.label,
            )

    phase.update({"type": "complete", "step_index": None, "step_label": "complete"})
    for characteristic_uuid in subscribed_uuids:
        try:
            await client.unsubscribe(characteristic_uuid)
            logger.record_event(
                "unsubscribe_result",
                device=client.address,
                characteristic_uuid=characteristic_uuid,
                metadata={"status": "ok"},
            )
        except Exception as exc:
            logger.record_event(
                "unsubscribe_error",
                device=client.address,
                characteristic_uuid=characteristic_uuid,
                metadata={"error": str(exc)},
            )

    result = {
        "device": client.address,
        "profile": profile.to_dict(),
        "subscriptions": subscriptions,
        "baseline_reads": baseline_reads,
        "baseline_notifications": baseline_notifications,
        "steps": step_results,
        "notifications": all_notifications,
        "log_file": str(logger.path),
    }
    logger.record_event(
        "explore_completed",
        device=client.address,
        metadata={
            "subscription_count": len(subscriptions),
            "baseline_read_count": len(baseline_reads),
            "notification_count": len(all_notifications),
            "step_count": len(step_results),
        },
    )
    return result


def iter_characteristics(profile: DeviceProfile) -> tuple[tuple[ServiceInfo, CharacteristicInfo], ...]:
    pairs: list[tuple[ServiceInfo, CharacteristicInfo]] = []
    for service in profile.services:
        for characteristic in service.characteristics:
            pairs.append((service, characteristic))
    return tuple(pairs)


def supports_notify(characteristic: CharacteristicInfo) -> bool:
    return bool({"notify", "indicate"}.intersection(characteristic.properties))


def supports_read(characteristic: CharacteristicInfo) -> bool:
    return "read" in characteristic.properties


async def _read_characteristic(
    client: AirecClient,
    logger: SessionLogger,
    service: ServiceInfo,
    characteristic: CharacteristicInfo,
    *,
    phase_type: str | None = None,
    step_index: int | None = None,
    step_label: str | None = None,
) -> dict[str, Any]:
    try:
        payload = await client.read(characteristic.uuid)
    except Exception as exc:
        result = {
            "service_uuid": service.uuid,
            "characteristic_uuid": characteristic.uuid,
            "status": "error",
            "error": str(exc),
        }
        logger.record_event(
            "read_error",
            device=client.address,
            characteristic_uuid=characteristic.uuid,
            metadata={
                **result,
                "phase": phase_type,
                "step_index": step_index,
                "step_label": step_label,
            },
        )
        return result

    result = {
        "service_uuid": service.uuid,
        "characteristic_uuid": characteristic.uuid,
        "status": "ok",
        "payload_hex": payload.hex(),
    }
    logger.record_event(
        "read_result",
        device=client.address,
        characteristic_uuid=characteristic.uuid,
        payload=payload,
        metadata={
            "service_uuid": service.uuid,
            "status": "ok",
            "phase": phase_type,
            "step_index": step_index,
            "step_label": step_label,
        },
    )
    return result


async def _subscribe_characteristic(
    client: AirecClient,
    logger: SessionLogger,
    service: ServiceInfo,
    characteristic: CharacteristicInfo,
    callback: NotificationHandler,
) -> dict[str, Any]:
    try:
        await client.subscribe(characteristic.uuid, callback)
    except Exception as exc:
        result = {
            "service_uuid": service.uuid,
            "characteristic_uuid": characteristic.uuid,
            "status": "error",
            "error": str(exc),
        }
        logger.record_event(
            "subscribe_error",
            device=client.address,
            characteristic_uuid=characteristic.uuid,
            metadata=result,
        )
        return result

    result = {
        "service_uuid": service.uuid,
        "characteristic_uuid": characteristic.uuid,
        "status": "subscribed",
    }
    logger.record_event(
        "subscribe_result",
        device=client.address,
        characteristic_uuid=characteristic.uuid,
        metadata={
            "service_uuid": service.uuid,
            "status": "subscribed",
        },
    )
    return result


async def snapshot_readable_characteristics(
    client: AirecClient,
    logger: SessionLogger,
    profile: DeviceProfile,
    *,
    phase_type: str | None,
    step_index: int | None,
    step_label: str | None,
) -> list[dict[str, Any]]:
    reads: list[dict[str, Any]] = []
    for service, characteristic in iter_characteristics(profile):
        if not supports_read(characteristic):
            continue
        reads.append(
            await _read_characteristic(
                client,
                logger,
                service,
                characteristic,
                phase_type=phase_type,
                step_index=step_index,
                step_label=step_label,
            )
        )
    return reads


def _coerce_response_mode(value: Any) -> bool | None:
    if value is None or value == "auto":
        return None
    if value is True or value == "true":
        return True
    if value is False or value == "false":
        return False
    raise ValueError(f"invalid response mode: {value!r}")
