"""Command line interface for the experimental AIREC toolkit."""

from __future__ import annotations

import argparse
import asyncio
from datetime import UTC, datetime
import json
from pathlib import Path
import sys
from typing import Any, TextIO

from .analysis import analyze_session_log
from .client import AirecClient, attach_logger, choose_response_mode, scan_devices
from .decode import decode_recording_download, decode_session_log
from .experiments import explore_recording_services, load_explore_steps, survey_device
from .logging import SessionLogger
from .pklg import summarize_pklg_trace
from .protocol import AdvertisementRecord, DeviceProfile, format_recording_id, normalize_recording_id
from .transport import BleTransport


ARTIFACT_ROOT = Path("artifacts")
SESSIONS_DIR = ARTIFACT_ROOT / "sessions"
ANALYSIS_DIR = ARTIFACT_ROOT / "analysis"
DECODE_DIR = ARTIFACT_ROOT / "decode"
DOWNLOADS_DIR = ARTIFACT_ROOT / "downloads"
LIVE_STATE_TRANSITION_COMMAND_HEX = "55aa0110"
LIVE_STATE_TRANSITION_WARNING = (
    "Archive access currently sends the stateful 0x10 live pause/resume transition and may "
    "pause, finalize, or otherwise perturb an in-progress live recording."
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="airec",
        description="Experimental toolkit for inspecting and reverse engineering AIREC devices over BLE",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan_parser = subparsers.add_parser("scan", help="Scan for nearby BLE devices")
    scan_parser.add_argument("--timeout", type=float, default=5.0)
    scan_parser.add_argument("--json", action="store_true")
    scan_parser.add_argument("--log-file", type=Path, default=None)

    inspect_parser = subparsers.add_parser("inspect", help="Inspect services and characteristics")
    inspect_parser.add_argument("device")
    inspect_parser.add_argument("--json", action="store_true")
    inspect_parser.add_argument("--log-file", type=Path, default=None)

    monitor_parser = subparsers.add_parser("monitor", help="Monitor notify/indicate characteristics")
    monitor_parser.add_argument("device")
    monitor_parser.add_argument("--duration", type=float, default=30.0)
    monitor_parser.add_argument("--json", action="store_true")
    monitor_parser.add_argument("--log-file", type=Path, default=None)

    survey_parser = subparsers.add_parser("survey", help="Read and subscribe across all observable characteristics")
    survey_parser.add_argument("device")
    survey_parser.add_argument("--duration", type=float, default=10.0)
    survey_parser.add_argument("--json", action="store_true")
    survey_parser.add_argument("--log-file", type=Path, default=None)

    explore_parser = subparsers.add_parser("explore", help="Run a scripted multi-step exploration plan")
    explore_parser.add_argument("device")
    explore_parser.add_argument("--plan", type=Path, required=True)
    explore_parser.add_argument("--baseline", type=float, default=1.0)
    explore_parser.add_argument("--no-read-after-each", action="store_true")
    explore_parser.add_argument("--json", action="store_true")
    explore_parser.add_argument("--log-file", type=Path, default=None)

    analyze_parser = subparsers.add_parser("analyze", help="Analyze a saved session log offline")
    analyze_parser.add_argument("session_log", type=Path)
    analyze_parser.add_argument("--block-chunks", default="244,244,24")
    analyze_parser.add_argument("--record-size", type=int, default=82)
    analyze_parser.add_argument("--marker", default="5b504b")
    analyze_parser.add_argument("--output-dir", type=Path, default=None)
    analyze_parser.add_argument("--json", action="store_true")

    decode_parser = subparsers.add_parser("decode", help="Decode a saved session log into a WAV file")
    decode_parser.add_argument("session_log", type=Path)
    decode_parser.add_argument("--block-chunks", default="244,244,24")
    decode_parser.add_argument("--record-size", type=int, default=82)
    decode_parser.add_argument("--marker", default="5b50")
    decode_parser.add_argument("--sample-rate", type=int, default=48000)
    decode_parser.add_argument("--output-dir", type=Path, default=None)
    decode_parser.add_argument("--json", action="store_true")

    decode_recording_parser = subparsers.add_parser(
        "decode-recording",
        help="Decode a downloaded archived recording .bin into a WAV file",
    )
    decode_recording_parser.add_argument("recording_file", type=Path)
    decode_recording_parser.add_argument("--record-size", type=int, default=82)
    decode_recording_parser.add_argument("--marker", default="5b50")
    decode_recording_parser.add_argument("--sample-rate", type=int, default=16000)
    decode_recording_parser.add_argument("--output-dir", type=Path, default=None)
    decode_recording_parser.add_argument("--json", action="store_true")

    trace_parser = subparsers.add_parser("trace-pklg", help="Summarize a PacketLogger Bluetooth trace")
    trace_parser.add_argument("trace_file", type=Path)
    trace_parser.add_argument("--json", action="store_true")

    list_recordings_parser = subparsers.add_parser(
        "list-recordings",
        help="List archived recordings; warning: this path mutates live state on current hardware",
    )
    list_recordings_parser.add_argument("device")
    list_recordings_parser.add_argument("--timeout", type=float, default=5.0)
    list_recordings_parser.add_argument("--json", action="store_true")
    list_recordings_parser.add_argument("--log-file", type=Path, default=None)

    live_status_parser = subparsers.add_parser(
        "live-status",
        help="Query the current live-recording context reported by the device",
    )
    live_status_parser.add_argument("device")
    live_status_parser.add_argument("--timeout", type=float, default=5.0)
    live_status_parser.add_argument("--json", action="store_true")
    live_status_parser.add_argument("--log-file", type=Path, default=None)

    battery_status_parser = subparsers.add_parser(
        "battery-status",
        help="Query the device battery percentage",
    )
    battery_status_parser.add_argument("device")
    battery_status_parser.add_argument("--timeout", type=float, default=5.0)
    battery_status_parser.add_argument("--json", action="store_true")
    battery_status_parser.add_argument("--log-file", type=Path, default=None)

    storage_status_parser = subparsers.add_parser(
        "storage-status",
        help="Query the paired storage status values exposed by the device",
    )
    storage_status_parser.add_argument("device")
    storage_status_parser.add_argument("--timeout", type=float, default=5.0)
    storage_status_parser.add_argument("--json", action="store_true")
    storage_status_parser.add_argument("--log-file", type=Path, default=None)

    toggle_live_parser = subparsers.add_parser(
        "pause-resume-live",
        aliases=["toggle-live-recording"],
        help="Send the observed 0x10 live pause/resume transition",
    )
    toggle_live_parser.add_argument("device")
    toggle_live_parser.add_argument("--timeout", type=float, default=5.0)
    toggle_live_parser.add_argument("--json", action="store_true")
    toggle_live_parser.add_argument("--log-file", type=Path, default=None)

    live_toggle_experiment_parser = subparsers.add_parser(
        "live-toggle-experiment",
        help="Run the live-status/pause-resume/wait/pause-resume/list experiment without an extra archive transition",
    )
    live_toggle_experiment_parser.add_argument("device")
    live_toggle_experiment_parser.add_argument("--timeout", type=float, default=5.0)
    live_toggle_experiment_parser.add_argument("--wait-seconds", type=float, default=2.5)
    live_toggle_experiment_parser.add_argument(
        "--baseline-list",
        action="store_true",
        help="Capture a stateful archive baseline before the pause/resume experiment and report the diff",
    )
    live_toggle_experiment_parser.add_argument(
        "--disconnect-before-list",
        action="store_true",
        help="Pause once, disconnect, then reconnect and run the archive list to test paused-finalization",
    )
    live_toggle_experiment_parser.add_argument("--json", action="store_true")
    live_toggle_experiment_parser.add_argument("--log-file", type=Path, default=None)

    download_recording_parser = subparsers.add_parser(
        "download-recording",
        help="Download an archived recording; warning: this path mutates live state on current hardware",
    )
    download_recording_parser.add_argument("device")
    download_recording_parser.add_argument("recording_id")
    download_recording_parser.add_argument("--timeout", type=float, default=30.0)
    download_recording_parser.add_argument("--output", type=Path, default=None)
    download_recording_parser.add_argument("--json", action="store_true")
    download_recording_parser.add_argument("--log-file", type=Path, default=None)

    delete_recording_parser = subparsers.add_parser(
        "delete-recording",
        help="Delete an archived recording; warning: this path mutates live state on current hardware",
    )
    delete_recording_parser.add_argument("device")
    delete_recording_parser.add_argument("recording_id")
    delete_recording_parser.add_argument("--timeout", type=float, default=5.0)
    delete_recording_parser.add_argument("--json", action="store_true")
    delete_recording_parser.add_argument("--log-file", type=Path, default=None)

    cancel_download_parser = subparsers.add_parser(
        "cancel-download",
        help="Send the control command that cancels an in-progress archived download",
    )
    cancel_download_parser.add_argument("device")
    cancel_download_parser.add_argument("--timeout", type=float, default=5.0)
    cancel_download_parser.add_argument("--json", action="store_true")
    cancel_download_parser.add_argument("--log-file", type=Path, default=None)

    probe_parser = subparsers.add_parser("probe", help="Write a controlled payload to a characteristic")
    probe_parser.add_argument("device")
    probe_parser.add_argument("--char", required=True, dest="characteristic_uuid")
    probe_parser.add_argument("--hex", required=True, dest="payload_hex")
    probe_parser.add_argument("--response", choices=("auto", "true", "false"), default="auto")
    probe_parser.add_argument("--json", action="store_true")
    probe_parser.add_argument("--log-file", type=Path, default=None)

    return parser


def main(argv: list[str] | None = None) -> int:
    return asyncio.run(run_async(argv))


async def run_async(
    argv: list[str] | None = None,
    *,
    adapter: BleTransport | None = None,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    stdout = stdout or sys.stdout
    stderr = stderr or sys.stderr
    logger = SessionLogger(args.log_file or default_log_path(args.command)) if hasattr(args, "log_file") else None

    try:
        if args.command == "scan":
            records = await scan_devices(timeout=args.timeout, adapter=adapter)
            for record in records:
                logger.record_event(
                    "scan_result",
                    device=record.address,
                    metadata=record.to_dict(),
                )
            _emit(_scan_to_output(records), as_json=args.json, stdout=stdout)
            return 0

        if args.command == "analyze":
            block_chunks = _parse_block_chunks(args.block_chunks)
            result = analyze_session_log(
                args.session_log,
                output_dir=args.output_dir or default_analysis_dir(args.session_log),
                block_chunk_sizes=block_chunks,
                record_size=args.record_size,
                marker_hex=args.marker,
            )
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_analysis_result)
            return 0

        if args.command == "decode":
            block_chunks = _parse_block_chunks(args.block_chunks)
            result = decode_session_log(
                args.session_log,
                output_dir=args.output_dir or default_decode_dir(args.session_log),
                block_chunk_sizes=block_chunks,
                record_size=args.record_size,
                marker_hex=args.marker,
                sample_rate=args.sample_rate,
            )
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_decode_result)
            return 0

        if args.command == "decode-recording":
            result = decode_recording_download(
                args.recording_file,
                output_dir=args.output_dir or default_decode_dir(args.recording_file),
                record_size=args.record_size,
                marker_hex=args.marker,
                sample_rate=args.sample_rate,
            )
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_decode_recording_result)
            return 0

        if args.command == "trace-pklg":
            result = summarize_pklg_trace(args.trace_file)
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_trace_result)
            return 0

        client = AirecClient(args.device, adapter=adapter)
        if args.command == "list-recordings":
            recordings = await client.list_recordings(timeout=args.timeout, logger=logger)
            result = {
                "device": client.address,
                "recordings": [recording.to_dict() for recording in recordings],
                "count": len(recordings),
                "stateful_archive_path": True,
                "live_state_transition_command_hex": LIVE_STATE_TRANSITION_COMMAND_HEX,
                "live_state_warning": LIVE_STATE_TRANSITION_WARNING,
                "log_file": str(logger.path),
            }
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_list_recordings_result)
            return 0

        if args.command == "live-status":
            status = await client.get_live_recording_status(timeout=args.timeout, logger=logger)
            result = {
                "device": client.address,
                **status.to_dict(),
                "log_file": str(logger.path),
            }
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_live_status_result)
            return 0

        if args.command == "battery-status":
            status = await client.get_battery_status(timeout=args.timeout, logger=logger)
            result = {
                "device": client.address,
                **status.to_dict(),
                "log_file": str(logger.path),
            }
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_battery_status_result)
            return 0

        if args.command == "storage-status":
            status = await client.get_storage_status(timeout=args.timeout, logger=logger)
            result = {
                "device": client.address,
                **status.to_dict(),
                "log_file": str(logger.path),
            }
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_storage_status_result)
            return 0

        if args.command in {"pause-resume-live", "toggle-live-recording"}:
            acknowledged = await client.pause_resume_live_recording(timeout=args.timeout, logger=logger)
            result = {
                "device": client.address,
                "acknowledged": acknowledged,
                "toggled": acknowledged,
                "command_hex": LIVE_STATE_TRANSITION_COMMAND_HEX,
                "live_state_warning": "0x10 is treated as a live pause/resume transition.",
                "log_file": str(logger.path),
            }
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_toggle_live_recording_result)
            return 0

        if args.command == "live-toggle-experiment":
            baseline_recordings: tuple[Any, ...] = ()
            if args.baseline_list:
                baseline_recordings = await client.list_recordings(timeout=args.timeout, logger=logger)
            status_before = await client.get_live_recording_status(timeout=args.timeout, logger=logger)
            first_toggle = await client.pause_resume_live_recording(timeout=args.timeout, logger=logger)
            status_after_first_toggle = await client.get_live_recording_status(
                timeout=args.timeout,
                logger=logger,
            )
            second_toggle: bool | None = None
            status_after_second_toggle: dict[str, Any] | None = None
            include_live_state_transition = False
            if args.disconnect_before_list:
                await client.disconnect()
                include_live_state_transition = True
            else:
                await asyncio.sleep(args.wait_seconds)
                second_toggle = await client.pause_resume_live_recording(timeout=args.timeout, logger=logger)
                status_after_second_toggle_obj = await client.get_live_recording_status(
                    timeout=args.timeout,
                    logger=logger,
                )
                status_after_second_toggle = status_after_second_toggle_obj.to_dict()
            recordings = await client.list_recordings(
                timeout=args.timeout,
                logger=logger,
                include_live_state_transition=include_live_state_transition,
            )
            baseline_by_id = {recording.recording_id: recording.to_dict() for recording in baseline_recordings}
            recordings_by_id = {recording.recording_id: recording.to_dict() for recording in recordings}
            result = {
                "device": client.address,
                "wait_seconds": args.wait_seconds,
                "baseline_list": args.baseline_list,
                "disconnect_before_list": args.disconnect_before_list,
                "command_hex": LIVE_STATE_TRANSITION_COMMAND_HEX,
                "first_toggle": first_toggle,
                "second_toggle": second_toggle,
                "live_state_warning": LIVE_STATE_TRANSITION_WARNING,
                "status_before": status_before.to_dict(),
                "status_after_first_toggle": status_after_first_toggle.to_dict(),
                "status_after_second_toggle": status_after_second_toggle,
                "baseline_recordings": [recording.to_dict() for recording in baseline_recordings],
                "baseline_count": len(baseline_recordings),
                "recordings": [recording.to_dict() for recording in recordings],
                "count": len(recordings),
                "added_recordings": [
                    recordings_by_id[recording_id]
                    for recording_id in sorted(recordings_by_id.keys() - baseline_by_id.keys())
                ],
                "removed_recordings": [
                    baseline_by_id[recording_id]
                    for recording_id in sorted(baseline_by_id.keys() - recordings_by_id.keys())
                ],
                "log_file": str(logger.path),
            }
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_live_toggle_experiment_result)
            return 0

        if args.command == "download-recording":
            download = await client.download_recording(
                args.recording_id,
                timeout=args.timeout,
                logger=logger,
            )
            output_path = args.output or default_download_path(download.recording_id)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_bytes(download.data)
            decode_summary = decode_recording_download(
                output_path,
                output_dir=default_decode_dir(output_path),
            )
            result = {
                "device": client.address,
                **download.to_dict(),
                "size_matches": download.expected_size_bytes in {None, download.bytes_received},
                "output_path": str(output_path),
                "wav_path": decode_summary["wav_path"],
                "decoded_sample_rate": decode_summary["sample_rate"],
                "decoded_duration_seconds": decode_summary["duration_seconds"],
                "stateful_archive_path": True,
                "live_state_transition_command_hex": LIVE_STATE_TRANSITION_COMMAND_HEX,
                "live_state_warning": LIVE_STATE_TRANSITION_WARNING,
                "log_file": str(logger.path),
            }
            logger.record_event(
                "recording_download_saved",
                device=client.address,
                metadata={
                    "recording_id": download.recording_id,
                    "bytes_received": download.bytes_received,
                    "expected_size_bytes": download.expected_size_bytes,
                    "output_path": str(output_path),
                },
            )
            logger.record_event(
                "recording_download_decoded",
                device=client.address,
                metadata={
                    "recording_id": download.recording_id,
                    "sample_rate": decode_summary["sample_rate"],
                    "duration_seconds": decode_summary["duration_seconds"],
                    "wav_path": decode_summary["wav_path"],
                },
            )
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_download_recording_result)
            return 0

        if args.command == "delete-recording":
            recording_id = await client.delete_recording(
                args.recording_id,
                timeout=args.timeout,
                logger=logger,
            )
            result = {
                "device": client.address,
                "recording_id": recording_id,
                "recorded_at": format_recording_id(recording_id),
                "deleted": True,
                "stateful_archive_path": True,
                "live_state_transition_command_hex": LIVE_STATE_TRANSITION_COMMAND_HEX,
                "live_state_warning": LIVE_STATE_TRANSITION_WARNING,
                "log_file": str(logger.path),
            }
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_delete_recording_result)
            return 0

        if args.command == "cancel-download":
            cancelled = await client.cancel_download(timeout=args.timeout, logger=logger)
            result = {
                "device": client.address,
                "cancelled": cancelled,
                "log_file": str(logger.path),
            }
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_cancel_download_result)
            return 0

        if args.command == "inspect":
            profile = await client.inspect()
            logger.record_event("inspect", device=client.address, metadata=profile.to_dict())
            _emit(profile.to_dict(), as_json=args.json, stdout=stdout, formatter=_format_profile)
            return 0

        if args.command == "monitor":
            profile = await client.inspect()
            logger.record_event("inspect", device=client.address, metadata=profile.to_dict())
            notifications: list[dict[str, Any]] = []

            async def callback(sender: str, payload: bytes) -> None:
                event = {
                    "sender": sender,
                    "payload_hex": payload.hex(),
                }
                notifications.append(event)
                logger.record_event(
                    "notification",
                    device=client.address,
                    characteristic_uuid=sender,
                    payload=payload,
                )

            subscribed = await client.subscribe_all_notifiers(profile, callback)
            logger.record_event(
                "monitor_started",
                device=client.address,
                metadata={"subscribed": list(subscribed), "duration": args.duration},
            )
            if args.duration > 0:
                await asyncio.sleep(args.duration)
            result = {
                "device": client.address,
                "subscribed": list(subscribed),
                "notifications": notifications,
                "log_file": str(logger.path),
            }
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_monitor_result)
            return 0

        if args.command == "survey":
            result = await survey_device(
                client,
                logger,
                notification_window=args.duration,
            )
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_survey_result)
            return 0

        if args.command == "explore":
            steps = load_explore_steps(args.plan)
            result = await explore_recording_services(
                client,
                logger,
                steps=steps,
                baseline_window=args.baseline,
                read_after_each=not args.no_read_after_each,
            )
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_explore_result)
            return 0

        if args.command == "probe":
            profile = await client.inspect()
            logger.record_event("inspect", device=client.address, metadata=profile.to_dict())
            payload = bytes.fromhex(args.payload_hex)
            response_mode = _parse_response_mode(args.response)
            chosen_response = choose_response_mode(profile.services, args.characteristic_uuid, response_mode)
            attach_logger(
                logger,
                event_type="probe_write",
                device=client.address,
                characteristic_uuid=args.characteristic_uuid,
                payload=payload,
                metadata={"response": chosen_response},
            )
            await client.write(args.characteristic_uuid, payload, response=chosen_response)
            result = {
                "device": client.address,
                "characteristic_uuid": args.characteristic_uuid.upper(),
                "payload_hex": payload.hex(),
                "response": chosen_response,
                "log_file": str(logger.path),
            }
            _emit(result, as_json=args.json, stdout=stdout, formatter=_format_probe_result)
            return 0

        parser.error(f"unknown command: {args.command}")
    except ValueError as exc:
        print(str(exc), file=stderr)
        return 2
    finally:
        if args.command in {
            "inspect",
            "monitor",
            "survey",
            "explore",
            "list-recordings",
            "live-status",
            "battery-status",
            "storage-status",
            "pause-resume-live",
            "toggle-live-recording",
            "live-toggle-experiment",
            "download-recording",
            "delete-recording",
            "cancel-download",
            "probe",
        }:
            try:
                client = AirecClient(getattr(args, "device", ""), adapter=adapter)
                await client.disconnect()
            except Exception:
                pass

    return 1


def default_log_path(command: str) -> Path:
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    return SESSIONS_DIR / f"{command}-{stamp}.jsonl"


def default_analysis_dir(session_log: Path) -> Path:
    return ANALYSIS_DIR / session_log.stem


def default_decode_dir(session_log: Path) -> Path:
    return DECODE_DIR / session_log.stem


def default_download_path(recording_id: str) -> Path:
    return DOWNLOADS_DIR / f"{normalize_recording_id(recording_id)}.bin"


def _parse_response_mode(value: str) -> bool | None:
    if value == "auto":
        return None
    return value == "true"


def _parse_block_chunks(value: str) -> tuple[int, ...]:
    chunks = tuple(int(item.strip()) for item in value.split(",") if item.strip())
    if not chunks:
        raise ValueError("block chunk sizes must not be empty")
    if any(item <= 0 for item in chunks):
        raise ValueError("block chunk sizes must be positive integers")
    return chunks


def _emit(payload: dict[str, Any] | list[dict[str, Any]], *, as_json: bool, stdout: TextIO, formatter=None) -> None:
    if as_json:
        json.dump(payload, stdout, indent=2, sort_keys=True)
        stdout.write("\n")
        return
    if formatter is None:
        stdout.write(f"{payload}\n")
        return
    stdout.write(formatter(payload))
    stdout.write("\n")


def _scan_to_output(records: list[AdvertisementRecord]) -> list[dict[str, Any]]:
    return [record.to_dict() for record in records]


def _format_profile(payload: dict[str, Any]) -> str:
    lines = [
        f"Device: {payload['address']}",
        f"Name: {payload.get('name') or 'unknown'}",
        f"RSSI: {payload.get('rssi')}",
        f"Appearance: {payload.get('appearance')}",
    ]
    for note in payload.get("notes", []):
        lines.append(f"Note: {note}")
    for service in payload["services"]:
        lines.append(f"Service {service['uuid']}")
        for characteristic in service["characteristics"]:
            props = ", ".join(characteristic["properties"]) or "none"
            lines.append(f"  Characteristic {characteristic['uuid']} [{props}]")
            for descriptor in characteristic["descriptors"]:
                lines.append(f"    Descriptor {descriptor['uuid']}")
    return "\n".join(lines)


def _format_monitor_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Monitoring {payload['device']}",
        f"Subscribed: {', '.join(payload['subscribed']) or 'none'}",
        f"Notifications captured: {len(payload['notifications'])}",
        f"Log file: {payload['log_file']}",
    ]
    for notification in payload["notifications"]:
        lines.append(f"  {notification['sender']}: {notification['payload_hex']}")
    return "\n".join(lines)


def _format_probe_result(payload: dict[str, Any]) -> str:
    return (
        f"Probed {payload['device']} characteristic {payload['characteristic_uuid']} "
        f"with {payload['payload_hex']} (response={payload['response']})\n"
        f"Log file: {payload['log_file']}"
    )


def _format_list_recordings_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Recordings on {payload['device']}: {payload['count']}",
        f"Warning: {payload['live_state_warning']}",
        f"Log file: {payload['log_file']}",
    ]
    for recording in payload["recordings"]:
        lines.append(
            f"  {recording['recording_id']} ({recording['recorded_at']}) metadata={recording['metadata_hex']}"
        )
    return "\n".join(lines)


def _format_live_status_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Live status for {payload['device']}",
        f"Status code: 0x{payload['status_code']:02x}",
        f"State: {payload['status_name']} ({payload['status_description']})",
        f"Recording ID: {payload['recording_id']}",
        f"Recorded at: {payload['recorded_at']}",
        f"Extra payload: {payload['extra_hex'] or 'none'}",
        f"Log file: {payload['log_file']}",
    ]
    return "\n".join(lines)


def _format_battery_status_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Battery status for {payload['device']}",
        f"Percent: {payload['percent']}",
        f"Raw payload: {payload['raw_hex']}",
        f"Log file: {payload['log_file']}",
    ]
    return "\n".join(lines)


def _format_storage_status_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Storage status for {payload['device']}",
        f"0x0c value: {payload['value_0c']}",
        f"0x0d value: {payload['value_0d']}",
        f"Log file: {payload['log_file']}",
    ]
    return "\n".join(lines)


def _format_toggle_live_recording_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Live pause/resume transition on {payload['device']}",
        f"Command: {payload['command_hex']}",
        f"Warning: {payload['live_state_warning']}",
        f"Acknowledged: {payload['acknowledged']}",
        f"Log file: {payload['log_file']}",
    ]
    return "\n".join(lines)


def _format_live_toggle_experiment_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Live pause/resume experiment on {payload['device']}",
        f"Command: {payload['command_hex']}",
        f"Warning: {payload['live_state_warning']}",
        (
            f"Baseline archive list: {payload['baseline_count']}"
            if payload["baseline_list"]
            else "Baseline archive list: skipped"
        ),
        (
            "Sequence: live-status -> pause/resume -> live-status -> disconnect -> list-recordings"
            if payload["disconnect_before_list"]
            else "Sequence: live-status -> pause/resume -> live-status -> wait -> pause/resume -> live-status -> list-recordings"
        ),
        f"Wait between transitions: {payload['wait_seconds']:.3f}s",
        (
            "Status before: "
            f"{payload['status_before']['recording_id']} "
            f"({payload['status_before']['status_name']}, 0x{payload['status_before']['status_code']:02x})"
        ),
        (
            "Status after first toggle: "
            f"{payload['status_after_first_toggle']['recording_id']} "
            f"({payload['status_after_first_toggle']['status_name']}, "
            f"0x{payload['status_after_first_toggle']['status_code']:02x})"
        ),
        f"Recordings listed: {payload['count']}",
        f"Log file: {payload['log_file']}",
    ]
    if payload["status_after_second_toggle"] is not None:
        lines.append(
            "Status after second toggle: "
            f"{payload['status_after_second_toggle']['recording_id']} "
            f"({payload['status_after_second_toggle']['status_name']}, "
            f"0x{payload['status_after_second_toggle']['status_code']:02x})"
        )
    if payload["baseline_list"]:
        lines.append(f"Added recordings: {len(payload['added_recordings'])}")
        lines.append(f"Removed recordings: {len(payload['removed_recordings'])}")
    for recording in payload["recordings"]:
        lines.append(f"  {recording['recording_id']} ({recording['recorded_at']}) metadata={recording['metadata_hex']}")
    return "\n".join(lines)


def _format_download_recording_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Downloaded recording {payload['recording_id']} from {payload['device']}",
        f"Warning: {payload['live_state_warning']}",
        f"Recorded at: {payload['recorded_at']}",
        f"Bytes received: {payload['bytes_received']}",
        f"Expected size: {payload['expected_size_bytes']}",
        f"Data notifications: {payload['data_notifications']}",
        f"Size match: {payload['size_matches']}",
        f"Output path: {payload['output_path']}",
        f"WAV path: {payload['wav_path']}",
        f"Decoded audio: {payload['decoded_duration_seconds']:.3f}s at {payload['decoded_sample_rate']} Hz",
        f"Log file: {payload['log_file']}",
    ]
    return "\n".join(lines)


def _format_delete_recording_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Deleted recording {payload['recording_id']} from {payload['device']}",
        f"Warning: {payload['live_state_warning']}",
        f"Recorded at: {payload['recorded_at']}",
        f"Deleted: {payload['deleted']}",
        f"Log file: {payload['log_file']}",
    ]
    return "\n".join(lines)


def _format_cancel_download_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Cancel download on {payload['device']}",
        f"Cancelled: {payload['cancelled']}",
        f"Log file: {payload['log_file']}",
    ]
    return "\n".join(lines)


def _format_survey_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Surveyed {payload['device']}",
        f"Readable characteristics: {len(payload['reads'])}",
        f"Notify subscriptions: {len(payload['subscriptions'])}",
        f"Notifications captured: {len(payload['notifications'])}",
        f"Log file: {payload['log_file']}",
    ]
    for read in payload["reads"]:
        if read["status"] == "ok":
            lines.append(f"  READ {read['characteristic_uuid']}: {read['payload_hex']}")
        else:
            lines.append(f"  READ {read['characteristic_uuid']}: error={read['error']}")
    for subscription in payload["subscriptions"]:
        if subscription["status"] == "subscribed":
            lines.append(f"  SUB {subscription['characteristic_uuid']}: ok")
        else:
            lines.append(f"  SUB {subscription['characteristic_uuid']}: error={subscription['error']}")
    return "\n".join(lines)


def _format_explore_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Explored {payload['device']}",
        f"Subscriptions: {len(payload['subscriptions'])}",
        f"Baseline reads: {len(payload['baseline_reads'])}",
        f"Baseline notifications: {len(payload['baseline_notifications'])}",
        f"Steps: {len(payload['steps'])}",
        f"Notifications captured: {len(payload['notifications'])}",
        f"Log file: {payload['log_file']}",
    ]
    for step in payload["steps"]:
        line = (
            f"  STEP {step['index']} {step['label']} {step['characteristic_uuid']} "
            f"{step['payload_hex']} -> {step['write_status']}"
        )
        if step["write_status"] == "error":
            line = f"{line} ({step['error']})"
        lines.append(line)
        lines.append(
            f"    reads={len(step['reads'])} notifications={len(step['notifications'])} wait={step['wait_after']}"
        )
    return "\n".join(lines)


def _format_analysis_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Analyzed {payload['session_log']}",
        f"Selected sender: {payload['selected_sender']}",
        f"Notifications: {payload['notification_count']}",
        f"Blocks: {payload['block_count']} using chunks {', '.join(str(value) for value in payload['block_chunk_sizes'])}",
        f"Records: {payload['full_record_count']} at size {payload['record_size']} (alignment={payload['record_alignment_offset']})",
        f"Marker {payload['marker_hex']}: {payload['marker_count']} hits",
        f"Output dir: {payload['output_dir']}",
    ]
    for sender, count in payload["notifications_by_sender"].items():
        lines.append(f"  Sender {sender}: {count}")
    top_headers = list(payload["record_header_counts"].items())[:8]
    for header, count in top_headers:
        lines.append(f"  Header {header}: {count}")
    return "\n".join(lines)


def _format_decode_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Decoded {payload['session_log']}",
        f"Selected sender: {payload['selected_sender']}",
        f"Capture duration: {payload['capture_duration_seconds']:.3f}s at {payload['sample_rate']} Hz",
        f"Records: {payload['full_record_count']} at size {payload['record_size']} (alignment={payload['record_alignment_offset']})",
        f"Wrapped records: {payload['wrapped_record_count']}",
        f"Opus packets: {payload['opus_packet_count']} x {payload['opus_packet_bytes']} bytes",
        f"Decoded samples: {payload['sample_count']} ({payload['duration_seconds']:.3f}s)",
        f"WAV: {payload['wav_path']}",
        f"Output dir: {payload['output_dir']}",
    ]
    return "\n".join(lines)


def _format_decode_recording_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Decoded recording {payload['recording_file']}",
        f"Input bytes: {payload['recording_size_bytes']}",
        f"Records: {payload['record_count']} at size {payload['record_size']}",
        f"Wrapped records: {payload['wrapped_record_count']}",
        f"Opus packets: {payload['opus_packet_count']} x {payload['opus_packet_bytes']} bytes",
        f"Decoded samples: {payload['sample_count']} ({payload['duration_seconds']:.3f}s) at {payload['sample_rate']} Hz",
        f"WAV: {payload['wav_path']}",
        f"Output dir: {payload['output_dir']}",
    ]
    return "\n".join(lines)


def _format_trace_result(payload: dict[str, Any]) -> str:
    lines = [
        f"Trace: {payload['trace_path']}",
        f"PacketLogger records: {payload['record_count']}",
        f"ATT packets: {payload['att_packet_count']}",
    ]
    for type_code, count in payload["packetlogger_type_counts"].items():
        lines.append(f"  Type {type_code}: {count}")
    for handle, count in payload["notify_counts_by_handle"].items():
        lines.append(f"  Notify {handle}: {count}")
    for write in payload["writes"]:
        frame = write.get("app_frame")
        if frame is None:
            lines.append(f"WRITE {write['handle']} {write['payload_hex']} -> {write['notification_count']} notifications")
            continue
        lines.append(
            f"WRITE {write['handle']} cmd=0x{frame['command_id']:02x} len={frame['length']} "
            f"payload={frame['payload_hex']} -> {write['notification_count']} notifications"
        )
        for handle, count in write["notification_counts_by_handle"].items():
            lines.append(f"  {handle}: {count}")
    for download in payload["downloads"]:
        lines.append(
            f"DOWNLOAD {download['timestamp_id']} size={download['size_bytes']} bytes "
            f"data_notifications={download['data_notifications']}"
        )
    return "\n".join(lines)
