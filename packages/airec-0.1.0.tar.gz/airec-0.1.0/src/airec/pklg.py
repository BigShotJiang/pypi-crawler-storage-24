"""PacketLogger (.pklg) parsing helpers for BLE ATT traces."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any


PKLG_HEADER_SIZE = 13
ATT_CID = 0x0004
HOST_TO_DEVICE_TYPE = 2
DEVICE_TO_HOST_TYPE = 3


@dataclass(slots=True)
class PacketLoggerRecord:
    timestamp_seconds: float
    type_code: int
    payload: bytes


@dataclass(slots=True)
class AttPacket:
    timestamp_seconds: float
    direction: str
    opcode: int
    attribute_handle: int | None
    payload: bytes

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp_seconds": self.timestamp_seconds,
            "direction": self.direction,
            "opcode": self.opcode,
            "attribute_handle": self.attribute_handle,
            "payload_hex": self.payload.hex(),
            "app_frame": parse_app_frame(self.payload).to_dict() if parse_app_frame(self.payload) is not None else None,
        }


@dataclass(slots=True)
class AppFrame:
    prefix_hex: str
    length: int
    command_id: int
    payload: bytes

    def to_dict(self) -> dict[str, Any]:
        payload_ascii = None
        if self.payload and all(32 <= byte < 127 for byte in self.payload):
            payload_ascii = self.payload.decode("ascii")
        return {
            "prefix_hex": self.prefix_hex,
            "length": self.length,
            "command_id": self.command_id,
            "payload_hex": self.payload.hex(),
            "payload_ascii": payload_ascii,
        }


def parse_pklg_records(path: Path) -> tuple[PacketLoggerRecord, ...]:
    try:
        data = path.read_bytes()
    except FileNotFoundError as exc:
        raise ValueError(f"trace file does not exist: {path}") from exc

    records: list[PacketLoggerRecord] = []
    offset = 0
    while offset < len(data):
        if offset + PKLG_HEADER_SIZE > len(data):
            raise ValueError(f"truncated PacketLogger header at offset {offset}")
        record_length = int.from_bytes(data[offset : offset + 4], "big")
        if record_length < 9:
            raise ValueError(f"invalid PacketLogger record length {record_length} at offset {offset}")
        record_end = offset + 4 + record_length
        if record_end > len(data):
            raise ValueError(f"truncated PacketLogger record at offset {offset}")
        seconds = int.from_bytes(data[offset + 4 : offset + 8], "big")
        microseconds = int.from_bytes(data[offset + 8 : offset + 12], "big")
        type_code = data[offset + 12]
        payload = data[offset + PKLG_HEADER_SIZE : record_end]
        records.append(
            PacketLoggerRecord(
                timestamp_seconds=seconds + (microseconds / 1_000_000),
                type_code=type_code,
                payload=payload,
            )
        )
        offset = record_end
    return tuple(records)


def extract_att_packets(records: tuple[PacketLoggerRecord, ...]) -> tuple[AttPacket, ...]:
    packets: list[AttPacket] = []
    for record in records:
        if record.type_code not in {HOST_TO_DEVICE_TYPE, DEVICE_TO_HOST_TYPE}:
            continue
        if len(record.payload) < 8:
            continue
        l2cap_cid = int.from_bytes(record.payload[6:8], "little")
        if l2cap_cid != ATT_CID or len(record.payload) < 9:
            continue
        att = record.payload[8:]
        opcode = att[0]
        attribute_handle = _extract_attribute_handle(opcode, att)
        packets.append(
            AttPacket(
                timestamp_seconds=record.timestamp_seconds,
                direction="host_to_device" if record.type_code == HOST_TO_DEVICE_TYPE else "device_to_host",
                opcode=opcode,
                attribute_handle=attribute_handle,
                payload=att[3:] if attribute_handle is not None and len(att) >= 3 else att[1:],
            )
        )
    return tuple(packets)


def parse_app_frame(payload: bytes) -> AppFrame | None:
    if len(payload) < 4:
        return None
    prefix = payload[:2]
    if prefix not in {b"\x55\xaa", b"\xaa\x55"}:
        return None
    length = payload[2]
    command_id = payload[3]
    frame_payload = payload[4 : 4 + length]
    return AppFrame(
        prefix_hex=prefix.hex(),
        length=length,
        command_id=command_id,
        payload=frame_payload,
    )


def summarize_pklg_trace(path: Path) -> dict[str, Any]:
    records = parse_pklg_records(path)
    att_packets = extract_att_packets(records)

    packetlogger_type_counts = Counter(record.type_code for record in records)
    notify_counts_by_handle = Counter(
        packet.attribute_handle
        for packet in att_packets
        if packet.direction == "device_to_host" and packet.opcode == 0x1B and packet.attribute_handle is not None
    )
    host_writes = [
        packet
        for packet in att_packets
        if packet.direction == "host_to_device" and packet.opcode in {0x12, 0x52} and packet.attribute_handle is not None
    ]
    windows = _build_write_windows(att_packets, host_writes)

    return {
        "trace_path": str(path),
        "record_count": len(records),
        "packetlogger_type_counts": {str(key): value for key, value in sorted(packetlogger_type_counts.items())},
        "att_packet_count": len(att_packets),
        "notify_counts_by_handle": {
            _format_handle(handle): count for handle, count in sorted(notify_counts_by_handle.items())
        },
        "writes": windows,
        "downloads": _extract_downloads(windows),
    }


def _build_write_windows(att_packets: tuple[AttPacket, ...], host_writes: list[AttPacket]) -> list[dict[str, Any]]:
    windows: list[dict[str, Any]] = []
    for index, write in enumerate(host_writes):
        next_timestamp = host_writes[index + 1].timestamp_seconds if index + 1 < len(host_writes) else float("inf")
        notifications = [
            packet
            for packet in att_packets
            if packet.direction == "device_to_host"
            and packet.opcode == 0x1B
            and write.timestamp_seconds <= packet.timestamp_seconds < next_timestamp
        ]
        notification_counts = Counter(
            packet.attribute_handle for packet in notifications if packet.attribute_handle is not None
        )
        control_responses = [
            packet.to_dict()
            for packet in notifications
            if packet.attribute_handle == 0x0008 and parse_app_frame(packet.payload) is not None
        ]
        windows.append(
            {
                "timestamp_seconds": write.timestamp_seconds,
                "handle": _format_handle(write.attribute_handle),
                "att_opcode": write.opcode,
                "payload_hex": write.payload.hex(),
                "app_frame": parse_app_frame(write.payload).to_dict() if parse_app_frame(write.payload) is not None else None,
                "notification_count": len(notifications),
                "notification_counts_by_handle": {
                    _format_handle(handle): count for handle, count in sorted(notification_counts.items())
                },
                "control_responses": control_responses,
            }
        )
    return windows


def _extract_downloads(windows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    downloads: list[dict[str, Any]] = []
    for window in windows:
        app_frame = window.get("app_frame")
        if app_frame is None or app_frame["command_id"] != 0x07:
            continue
        request_payload = bytes.fromhex(app_frame["payload_hex"])
        timestamp_bytes = request_payload[:14]
        if len(timestamp_bytes) < 14:
            continue
        try:
            timestamp_id = timestamp_bytes.decode("ascii")
        except UnicodeDecodeError:
            continue
        size_bytes = None
        for response in window["control_responses"]:
            response_frame = response.get("app_frame")
            if response_frame is None or response_frame["command_id"] != 0x07:
                continue
            response_payload = bytes.fromhex(response_frame["payload_hex"])
            if len(response_payload) >= 18:
                size_bytes = int.from_bytes(response_payload[14:18], "big")
                break
        downloads.append(
            {
                "timestamp_id": timestamp_id,
                "request_payload_hex": window["payload_hex"],
                "size_bytes": size_bytes,
                "data_notifications": window["notification_counts_by_handle"].get("0x000b", 0),
            }
        )
    return downloads


def _extract_attribute_handle(opcode: int, att: bytes) -> int | None:
    if opcode in {0x12, 0x52, 0x1B} and len(att) >= 3:
        return int.from_bytes(att[1:3], "little")
    return None


def _format_handle(handle: int | None) -> str:
    return "unknown" if handle is None else f"0x{handle:04x}"
