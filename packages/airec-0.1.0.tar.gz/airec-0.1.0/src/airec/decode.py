"""Offline Opus decoding for reconstructed AIREC session logs."""

from __future__ import annotations

from array import array
from collections import Counter, defaultdict
import ctypes
import ctypes.util
from dataclasses import dataclass
from datetime import datetime
import json
from pathlib import Path
import sys
import wave

from .analysis import _extract_notifications, _load_events, reconstruct_blocks, slice_records


DEFAULT_OPUS_SAMPLE_RATE = 48_000
DEFAULT_OPUS_CHANNELS = 1
DEFAULT_RECORD_PREFIX_SIZE = 2
DEFAULT_RECORDING_SAMPLE_RATE = 16_000
SUPPORTED_OPUS_SAMPLE_RATES = {8_000, 12_000, 16_000, 24_000, 48_000}


@dataclass(frozen=True, slots=True)
class _DecodedRecord:
    record_index: int
    header_hex: str
    payload: bytes


@dataclass(frozen=True, slots=True)
class _OpusDecoder:
    handle: object
    decoder: ctypes.c_void_p
    decode: object
    packet_get_nb_samples: object
    destroy: object


def decode_session_log(
    session_log: Path,
    *,
    output_dir: Path,
    block_chunk_sizes: tuple[int, ...] = (244, 244, 24),
    record_size: int = 82,
    marker_hex: str = "5b50",
    sample_rate: int = DEFAULT_OPUS_SAMPLE_RATE,
    channels: int = DEFAULT_OPUS_CHANNELS,
    record_prefix_size: int = DEFAULT_RECORD_PREFIX_SIZE,
) -> dict[str, object]:
    if sample_rate not in SUPPORTED_OPUS_SAMPLE_RATES:
        raise ValueError(
            "Opus sample rate must be one of 8000, 12000, 16000, 24000, or 48000 Hz"
        )
    if channels != 1:
        raise ValueError("only mono Opus decoding is supported")
    if record_prefix_size < 0 or record_prefix_size >= record_size:
        raise ValueError("record prefix size must be non-negative and smaller than the record size")

    events = _load_events(session_log)
    notifications = _extract_notifications(events)
    if not notifications:
        raise ValueError(f"no notification events found in {session_log}")

    notifications_by_sender: dict[str, list[object]] = defaultdict(list)
    for notification in notifications:
        notifications_by_sender[notification.sender].append(notification)

    selected_sender, sender_notifications = max(
        notifications_by_sender.items(),
        key=lambda item: (len(item[1]), item[0]),
    )
    marker_bytes = bytes.fromhex(marker_hex)

    block_result = reconstruct_blocks(sender_notifications, block_chunk_sizes)
    record_result = slice_records(
        block_result["stream"],
        record_size=record_size,
        marker=marker_bytes,
    )
    full_records = [
        _DecodedRecord(
            record_index=record["record_index"],
            header_hex=record["header_hex"],
            payload=bytes.fromhex(record["payload_hex"]),
        )
        for record in record_result["records"]
        if record["length"] == record_size
    ]
    wrapped_records = [record for record in full_records if record.payload.startswith(marker_bytes)]
    opus_packets = [record.payload[record_prefix_size:] for record in wrapped_records]
    if not opus_packets:
        raise ValueError(f"no {record_size}-byte records starting with marker {marker_hex.lower()} were found")

    output_dir.mkdir(parents=True, exist_ok=True)
    samples = _decode_opus_packets(opus_packets, sample_rate=sample_rate, channels=channels)
    wav_path = output_dir / "decoded_opus.wav"
    _write_wav(wav_path, samples, sample_rate)

    summary = {
        "session_log": str(session_log),
        "selected_sender": selected_sender,
        "notification_count": len(notifications),
        "notifications_by_sender": {
            sender: len(items) for sender, items in sorted(notifications_by_sender.items())
        },
        "notification_length_counts": {
            str(length): count
            for length, count in Counter(item.payload_len for item in sender_notifications).most_common()
        },
        "block_chunk_sizes": list(block_chunk_sizes),
        "block_count": len(block_result["blocks"]),
        "record_size": record_size,
        "record_alignment_offset": record_result["alignment_offset"],
        "full_record_count": len(full_records),
        "wrapped_record_count": len(wrapped_records),
        "record_header_counts": record_result["header_counts"],
        "marker_hex": marker_hex.lower(),
        "marker_count": record_result["marker_count"],
        "record_prefix_size": record_prefix_size,
        "opus_packet_bytes": record_size - record_prefix_size,
        "opus_packet_count": len(opus_packets),
        "sample_rate": sample_rate,
        "channels": channels,
        "sample_count": len(samples),
        "duration_seconds": round(len(samples) / sample_rate, 4),
        "capture_duration_seconds": _capture_duration_seconds(sender_notifications),
        "wav_path": str(wav_path),
        "output_dir": str(output_dir),
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    return summary


def decode_recording_download(
    recording_file: Path,
    *,
    output_dir: Path,
    record_size: int = 82,
    marker_hex: str = "5b50",
    sample_rate: int = DEFAULT_RECORDING_SAMPLE_RATE,
    channels: int = DEFAULT_OPUS_CHANNELS,
    record_prefix_size: int = DEFAULT_RECORD_PREFIX_SIZE,
) -> dict[str, object]:
    if sample_rate not in SUPPORTED_OPUS_SAMPLE_RATES:
        raise ValueError(
            "Opus sample rate must be one of 8000, 12000, 16000, 24000, or 48000 Hz"
        )
    if channels != 1:
        raise ValueError("only mono Opus decoding is supported")
    if record_size <= 0:
        raise ValueError("record_size must be positive")
    if record_prefix_size < 0 or record_prefix_size >= record_size:
        raise ValueError("record prefix size must be non-negative and smaller than the record size")

    try:
        payload = recording_file.read_bytes()
    except FileNotFoundError as exc:
        raise ValueError(f"recording download does not exist: {recording_file}") from exc

    if not payload:
        raise ValueError(f"recording download is empty: {recording_file}")
    if len(payload) % record_size != 0:
        raise ValueError(
            f"recording download size {len(payload)} is not divisible by record size {record_size}"
        )

    marker_bytes = bytes.fromhex(marker_hex)
    records = [payload[offset : offset + record_size] for offset in range(0, len(payload), record_size)]
    header_counts = Counter(record[:4].hex() for record in records if len(record) >= 4)
    wrapped_records = [record for record in records if record.startswith(marker_bytes)]
    opus_packets = [record[record_prefix_size:] for record in wrapped_records]
    if not opus_packets:
        raise ValueError(f"no {record_size}-byte records starting with marker {marker_hex.lower()} were found")

    output_dir.mkdir(parents=True, exist_ok=True)
    samples = _decode_opus_packets(opus_packets, sample_rate=sample_rate, channels=channels)
    wav_path = output_dir / f"{recording_file.stem}.wav"
    _write_wav(wav_path, samples, sample_rate)

    summary = {
        "recording_file": str(recording_file),
        "recording_size_bytes": len(payload),
        "record_size": record_size,
        "record_count": len(records),
        "wrapped_record_count": len(wrapped_records),
        "record_header_counts": dict(header_counts.most_common()),
        "marker_hex": marker_hex.lower(),
        "record_prefix_size": record_prefix_size,
        "opus_packet_bytes": record_size - record_prefix_size,
        "opus_packet_count": len(opus_packets),
        "sample_rate": sample_rate,
        "channels": channels,
        "sample_count": len(samples),
        "duration_seconds": round(len(samples) / sample_rate, 4),
        "wav_path": str(wav_path),
        "output_dir": str(output_dir),
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    return summary


def _decode_opus_packets(packets: list[bytes], *, sample_rate: int, channels: int) -> list[int]:
    decoder = _load_opus_decoder(sample_rate=sample_rate, channels=channels)
    try:
        samples = array("h")
        for packet_index, packet in enumerate(packets):
            packet_buffer = ctypes.create_string_buffer(packet)
            frame_size = decoder.packet_get_nb_samples(packet_buffer, len(packet), sample_rate)
            if frame_size < 0:
                raise RuntimeError(f"invalid Opus packet at index {packet_index}: opus error {frame_size}")
            pcm_buffer = (ctypes.c_int16 * (frame_size * channels))()
            decoded_samples = decoder.decode(
                decoder.decoder,
                packet_buffer,
                len(packet),
                pcm_buffer,
                frame_size,
                0,
            )
            if decoded_samples < 0:
                raise RuntimeError(f"failed to decode Opus packet at index {packet_index}: opus error {decoded_samples}")
            samples.extend(pcm_buffer[: decoded_samples * channels])
        return samples.tolist()
    finally:
        decoder.destroy(decoder.decoder)


def _load_opus_decoder(*, sample_rate: int, channels: int) -> _OpusDecoder:
    library_name = ctypes.util.find_library("opus")
    if not library_name:
        raise RuntimeError("libopus was not found on this system")

    handle = ctypes.CDLL(library_name)

    decoder_create = handle.opus_decoder_create
    decoder_create.argtypes = [ctypes.c_int32, ctypes.c_int, ctypes.POINTER(ctypes.c_int)]
    decoder_create.restype = ctypes.c_void_p

    decode = handle.opus_decode
    decode.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_int32,
        ctypes.POINTER(ctypes.c_int16),
        ctypes.c_int,
        ctypes.c_int,
    ]
    decode.restype = ctypes.c_int

    packet_get_nb_samples = handle.opus_packet_get_nb_samples
    packet_get_nb_samples.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32]
    packet_get_nb_samples.restype = ctypes.c_int

    destroy = handle.opus_decoder_destroy
    destroy.argtypes = [ctypes.c_void_p]
    destroy.restype = None

    error = ctypes.c_int()
    decoder = decoder_create(sample_rate, channels, ctypes.byref(error))
    if error.value != 0 or not decoder:
        raise RuntimeError(f"opus_decoder_create failed with error {error.value}")

    return _OpusDecoder(
        handle=handle,
        decoder=decoder,
        decode=decode,
        packet_get_nb_samples=packet_get_nb_samples,
        destroy=destroy,
    )


def _capture_duration_seconds(notifications: list[object]) -> float:
    if len(notifications) < 2:
        return 0.0
    start = datetime.fromisoformat(notifications[0].timestamp.replace("Z", "+00:00"))
    end = datetime.fromisoformat(notifications[-1].timestamp.replace("Z", "+00:00"))
    return max(0.0, (end - start).total_seconds())


def _write_wav(path: Path, samples: list[int], sample_rate: int) -> None:
    pcm = array("h", (max(-32768, min(32767, int(sample))) for sample in samples))
    if sys.byteorder != "little":
        pcm.byteswap()
    with wave.open(str(path), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(sample_rate)
        handle.writeframes(pcm.tobytes())
