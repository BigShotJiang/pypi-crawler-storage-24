"""Protocol metadata and serializable models for AIREC BLE sessions."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


def normalize_uuid(value: str) -> str:
    return value.upper()


class KnownUuid:
    """Observed UUIDs from the current AIREC discovery log."""

    PRIMARY_SERVICE = "0011200A-2233-4455-6677-8899DFDEDDDC"
    AUXILIARY_SERVICE = "E49A25F8-F69A-11E8-8EB2-F2801F1B9FD1"

    PRIMARY_NOTIFY = "0011201A-2233-4455-6677-8899DFDEDDDC"
    PRIMARY_RW = "0011202A-2233-4455-6677-8899DFDEDDDC"
    PRIMARY_NOTIFY_ALT = "0011203A-2233-4455-6677-8899DFDEDDDC"
    PRIMARY_NOTIFY_ALT_2 = "0011204A-2233-4455-6677-8899DFDEDDDC"

    AUXILIARY_RW = "E49A25E0-F69A-11E8-8EB2-F2801F1B9FD1"
    AUXILIARY_NOTIFY = "E49A28E1-F69A-11E8-8EB2-F2801F1B9FD1"

    ALL = {
        PRIMARY_SERVICE,
        AUXILIARY_SERVICE,
        PRIMARY_NOTIFY,
        PRIMARY_RW,
        PRIMARY_NOTIFY_ALT,
        PRIMARY_NOTIFY_ALT_2,
        AUXILIARY_RW,
        AUXILIARY_NOTIFY,
    }


@dataclass(slots=True)
class DescriptorInfo:
    uuid: str

    def __post_init__(self) -> None:
        self.uuid = normalize_uuid(self.uuid)

    def to_dict(self) -> dict[str, Any]:
        return {"uuid": self.uuid}


@dataclass(slots=True)
class CharacteristicInfo:
    uuid: str
    properties: tuple[str, ...] = ()
    descriptors: tuple[DescriptorInfo, ...] = ()

    def __post_init__(self) -> None:
        self.uuid = normalize_uuid(self.uuid)
        self.properties = tuple(sorted({prop.lower() for prop in self.properties}))
        self.descriptors = tuple(self.descriptors)

    def to_dict(self) -> dict[str, Any]:
        return {
            "uuid": self.uuid,
            "properties": list(self.properties),
            "descriptors": [descriptor.to_dict() for descriptor in self.descriptors],
        }


@dataclass(slots=True)
class ServiceInfo:
    uuid: str
    characteristics: tuple[CharacteristicInfo, ...] = ()

    def __post_init__(self) -> None:
        self.uuid = normalize_uuid(self.uuid)
        self.characteristics = tuple(self.characteristics)

    def to_dict(self) -> dict[str, Any]:
        return {
            "uuid": self.uuid,
            "characteristics": [characteristic.to_dict() for characteristic in self.characteristics],
        }


@dataclass(slots=True)
class DeviceProfile:
    address: str
    name: str | None
    rssi: int | None
    services: tuple[ServiceInfo, ...]
    manufacturer_data: dict[str, str] = field(default_factory=dict)
    service_data: dict[str, str] = field(default_factory=dict)
    appearance: int | None = None
    notes: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": self.address,
            "name": self.name,
            "rssi": self.rssi,
            "manufacturer_data": dict(self.manufacturer_data),
            "service_data": dict(self.service_data),
            "appearance": self.appearance,
            "notes": list(self.notes),
            "services": [service.to_dict() for service in self.services],
        }


@dataclass(slots=True)
class AdvertisementRecord:
    address: str
    name: str | None = None
    rssi: int | None = None
    manufacturer_data: dict[str, str] = field(default_factory=dict)
    service_data: dict[str, str] = field(default_factory=dict)
    service_uuids: tuple[str, ...] = ()
    appearance: int | None = None

    def __post_init__(self) -> None:
        self.service_uuids = tuple(normalize_uuid(value) for value in self.service_uuids)

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": self.address,
            "name": self.name,
            "rssi": self.rssi,
            "manufacturer_data": dict(self.manufacturer_data),
            "service_data": dict(self.service_data),
            "service_uuids": list(self.service_uuids),
            "appearance": self.appearance,
        }


def normalize_recording_id(value: str) -> str:
    digits = "".join(character for character in value if character.isdigit())
    if len(digits) != 14:
        raise ValueError(
            "recording ID must contain exactly 14 digits in YYYYMMDDHHMMSS format"
        )
    return digits


def format_recording_id(value: str) -> str:
    recording_id = normalize_recording_id(value)
    stamp = datetime.strptime(recording_id, "%Y%m%d%H%M%S")
    return stamp.strftime("%Y-%m-%d %H:%M:%S")


@dataclass(slots=True)
class RecordingInfo:
    recording_id: str
    metadata_hex: str = ""

    def __post_init__(self) -> None:
        self.recording_id = normalize_recording_id(self.recording_id)
        self.metadata_hex = self.metadata_hex.lower()

    @property
    def recorded_at(self) -> str:
        return format_recording_id(self.recording_id)

    def to_dict(self) -> dict[str, Any]:
        return {
            "recording_id": self.recording_id,
            "recorded_at": self.recorded_at,
            "metadata_hex": self.metadata_hex,
        }


@dataclass(slots=True)
class RecordingDownload:
    recording_id: str
    data: bytes
    expected_size_bytes: int | None = None
    data_notifications: int = 0

    def __post_init__(self) -> None:
        self.recording_id = normalize_recording_id(self.recording_id)
        self.data = bytes(self.data)

    @property
    def recorded_at(self) -> str:
        return format_recording_id(self.recording_id)

    @property
    def bytes_received(self) -> int:
        return len(self.data)

    def to_dict(self) -> dict[str, Any]:
        return {
            "recording_id": self.recording_id,
            "recorded_at": self.recorded_at,
            "expected_size_bytes": self.expected_size_bytes,
            "bytes_received": self.bytes_received,
            "data_notifications": self.data_notifications,
        }


@dataclass(slots=True)
class LiveRecordingStatus:
    status_code: int
    recording_id: str | None = None
    extra_hex: str = ""

    def __post_init__(self) -> None:
        if not 0 <= self.status_code <= 0xFF:
            raise ValueError(f"status_code must fit in one byte: {self.status_code}")
        if self.recording_id is not None:
            self.recording_id = normalize_recording_id(self.recording_id)
        self.extra_hex = self.extra_hex.lower()

    @property
    def recorded_at(self) -> str | None:
        if self.recording_id is None:
            return None
        return format_recording_id(self.recording_id)

    @property
    def status_name(self) -> str:
        return {
            0x00: "active",
            0x01: "paused",
            0x02: "inactive_or_archive",
        }.get(self.status_code, f"unknown_0x{self.status_code:02x}")

    @property
    def status_description(self) -> str:
        return {
            0x00: "active live session with timestamp",
            0x01: "paused or otherwise inactive live session",
            0x02: "non-live, archive-browsing, or otherwise inactive state",
        }.get(self.status_code, "unknown live status code")

    def to_dict(self) -> dict[str, Any]:
        return {
            "status_code": self.status_code,
            "status_name": self.status_name,
            "status_description": self.status_description,
            "recording_id": self.recording_id,
            "recorded_at": self.recorded_at,
            "extra_hex": self.extra_hex,
        }


@dataclass(slots=True)
class BatteryStatus:
    percent: int
    raw_hex: str = ""

    def __post_init__(self) -> None:
        if not 0 <= self.percent <= 0xFF:
            raise ValueError(f"percent must fit in one byte: {self.percent}")
        self.raw_hex = self.raw_hex.lower()

    def to_dict(self) -> dict[str, Any]:
        return {
            "percent": self.percent,
            "raw_hex": self.raw_hex,
        }


@dataclass(slots=True)
class StorageStatus:
    value_0c: int | None = None
    value_0d: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "value_0c": self.value_0c,
            "value_0d": self.value_0d,
        }


HEART_RATE_MISLABEL_NOTE = (
    "nRF Connect reported Appearance as Heart Monitor, but the observed GATT table contains only custom "
    "services. Treat the heart-rate label as an advertising metadata quirk, not a real Heart Rate profile."
)
