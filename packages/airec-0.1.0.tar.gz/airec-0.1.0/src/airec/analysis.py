"""Offline analysis helpers for BLE session logs."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class NotificationEvent:
    index: int
    timestamp: str
    sender: str
    payload: bytes

    @property
    def payload_len(self) -> int:
        return len(self.payload)


def analyze_session_log(
    session_log: Path,
    *,
    output_dir: Path,
    block_chunk_sizes: tuple[int, ...] = (244, 244, 24),
    record_size: int = 82,
    marker_hex: str = "5b504b",
) -> dict[str, Any]:
    events = _load_events(session_log)
    notifications = _extract_notifications(events)
    if not notifications:
        raise ValueError(f"no notification events found in {session_log}")

    notifications_by_sender: dict[str, list[NotificationEvent]] = defaultdict(list)
    for notification in notifications:
        notifications_by_sender[notification.sender].append(notification)

    selected_sender, sender_notifications = max(
        notifications_by_sender.items(),
        key=lambda item: (len(item[1]), item[0]),
    )
    marker = bytes.fromhex(marker_hex)

    block_result = reconstruct_blocks(sender_notifications, block_chunk_sizes)
    record_result = slice_records(
        block_result["stream"],
        record_size=record_size,
        marker=marker,
    )

    output_dir.mkdir(parents=True, exist_ok=True)
    _write_blocks(output_dir / "blocks.jsonl", block_result["blocks"])
    _write_records(output_dir / "records.jsonl", record_result["records"])

    summary = {
        "session_log": str(session_log),
        "selected_sender": selected_sender,
        "notification_count": len(notifications),
        "notifications_by_sender": {
            sender: len(items) for sender, items in sorted(notifications_by_sender.items())
        },
        "notification_length_counts": {
            str(length): count
            for length, count in Counter(item.payload_len for item in sender_notifications).most_common()
        },
        "block_chunk_sizes": list(block_chunk_sizes),
        "block_count": len(block_result["blocks"]),
        "record_size": record_size,
        "record_alignment_offset": record_result["alignment_offset"],
        "full_record_count": record_result["full_record_count"],
        "record_header_counts": record_result["header_counts"],
        "marker_hex": marker_hex.lower(),
        "marker_count": record_result["marker_count"],
        "output_dir": str(output_dir),
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    return summary


def reconstruct_blocks(
    notifications: list[NotificationEvent],
    block_chunk_sizes: tuple[int, ...],
) -> dict[str, Any]:
    if not block_chunk_sizes:
        raise ValueError("block_chunk_sizes must not be empty")
    block_size = sum(block_chunk_sizes)
    remainder = len(notifications) % len(block_chunk_sizes)
    if remainder:
        raise ValueError(
            f"notification count {len(notifications)} is not divisible by chunk group size {len(block_chunk_sizes)}"
        )

    blocks: list[dict[str, Any]] = []
    stream_parts: list[bytes] = []
    for block_index in range(0, len(notifications), len(block_chunk_sizes)):
        group = notifications[block_index : block_index + len(block_chunk_sizes)]
        observed_sizes = tuple(item.payload_len for item in group)
        if observed_sizes != block_chunk_sizes:
            raise ValueError(
                f"notification chunk sizes at group {block_index // len(block_chunk_sizes)} "
                f"do not match expected {block_chunk_sizes}: {observed_sizes}"
            )
        block = b"".join(item.payload for item in group)
        if len(block) != block_size:
            raise ValueError(f"reconstructed block has size {len(block)} instead of {block_size}")
        blocks.append(
            {
                "block_index": block_index // len(block_chunk_sizes),
                "payload_hex": block.hex(),
                "source_notification_indexes": [item.index for item in group],
                "source_timestamps": [item.timestamp for item in group],
            }
        )
        stream_parts.append(block)

    return {
        "block_size": block_size,
        "blocks": blocks,
        "stream": b"".join(stream_parts),
    }


def slice_records(stream: bytes, *, record_size: int, marker: bytes) -> dict[str, Any]:
    if record_size <= 0:
        raise ValueError("record_size must be positive")
    if not marker:
        raise ValueError("marker must not be empty")

    marker_offsets = _find_marker_offsets(stream, marker)
    if not marker_offsets:
        raise ValueError(f"marker {marker.hex()} not found in reconstructed stream")

    alignment_offset = _choose_alignment_offset(marker_offsets, record_size)
    records: list[dict[str, Any]] = []
    header_counts: Counter[str] = Counter()
    for record_index, offset in enumerate(range(alignment_offset, len(stream), record_size)):
        payload = stream[offset : offset + record_size]
        header_hex = payload[:4].hex() if len(payload) >= 4 else payload.hex()
        records.append(
            {
                "record_index": record_index,
                "offset": offset,
                "length": len(payload),
                "header_hex": header_hex,
                "starts_with_marker": payload.startswith(marker),
                "payload_hex": payload.hex(),
            }
        )
        if len(payload) == record_size:
            header_counts[header_hex] += 1

    return {
        "alignment_offset": alignment_offset,
        "records": records,
        "full_record_count": sum(1 for item in records if item["length"] == record_size),
        "marker_count": len(marker_offsets),
        "header_counts": dict(header_counts.most_common()),
    }


def _load_events(session_log: Path) -> list[dict[str, Any]]:
    try:
        text = session_log.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise ValueError(f"session log does not exist: {session_log}") from exc
    events: list[dict[str, Any]] = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid JSON on line {line_number} of {session_log}") from exc
    return events


def _extract_notifications(events: list[dict[str, Any]]) -> list[NotificationEvent]:
    notifications: list[NotificationEvent] = []
    for index, event in enumerate(events):
        if event.get("event_type") != "notification":
            continue
        payload_hex = event.get("payload_hex")
        if not isinstance(payload_hex, str):
            continue
        sender = str(event.get("characteristic_uuid") or "")
        notifications.append(
            NotificationEvent(
                index=index,
                timestamp=str(event.get("timestamp") or ""),
                sender=sender,
                payload=bytes.fromhex(payload_hex),
            )
        )
    return notifications


def _find_marker_offsets(stream: bytes, marker: bytes) -> list[int]:
    offsets: list[int] = []
    start = 0
    while True:
        index = stream.find(marker, start)
        if index < 0:
            return offsets
        offsets.append(index)
        start = index + 1


def _choose_alignment_offset(marker_offsets: list[int], record_size: int) -> int:
    counts = Counter(offset % record_size for offset in marker_offsets)
    alignment_offset, _ = max(counts.items(), key=lambda item: (item[1], -item[0]))
    return alignment_offset


def _write_blocks(path: Path, blocks: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for block in blocks:
            handle.write(json.dumps(block, sort_keys=True))
            handle.write("\n")


def _write_records(path: Path, records: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, sort_keys=True))
            handle.write("\n")
