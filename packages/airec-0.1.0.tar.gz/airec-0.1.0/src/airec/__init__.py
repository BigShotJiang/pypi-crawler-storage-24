"""Experimental Python toolkit for the AIREC smart voice recorder."""

from importlib.metadata import PackageNotFoundError, version

from .analysis import analyze_session_log, reconstruct_blocks, slice_records
from .client import AirecClient, scan_devices
from .decode import decode_recording_download, decode_session_log
from .experiments import survey_device
from .logging import CapturedEvent, SessionLogger
from .macos import ensure_bluetooth_usage_description
from .pklg import summarize_pklg_trace
from .protocol import (
    BatteryStatus,
    DeviceProfile,
    KnownUuid,
    LiveRecordingStatus,
    RecordingDownload,
    RecordingInfo,
    StorageStatus,
)
from .transport import BleTransport, BleakTransport

try:
    __version__ = version("airec")
except PackageNotFoundError:
    __version__ = "0.1.0"

__all__ = [
    "AirecClient",
    "BleTransport",
    "BleakTransport",
    "BatteryStatus",
    "CapturedEvent",
    "DeviceProfile",
    "KnownUuid",
    "LiveRecordingStatus",
    "RecordingDownload",
    "RecordingInfo",
    "SessionLogger",
    "StorageStatus",
    "__version__",
    "analyze_session_log",
    "decode_recording_download",
    "decode_session_log",
    "ensure_bluetooth_usage_description",
    "reconstruct_blocks",
    "scan_devices",
    "slice_records",
    "summarize_pklg_trace",
    "survey_device",
]
