#!/usr/bin/env python3
"""Patch the host Python.app Info.plist for CoreBluetooth access on macOS."""

from __future__ import annotations

import argparse
import plistlib
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from airec.macos import (  # noqa: E402
    DEFAULT_USAGE_DESCRIPTION,
    USAGE_KEY,
    find_python_app_info_plist,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--python-executable",
        default=sys.executable,
        help="Python executable whose bundle plist should be patched.",
    )
    parser.add_argument(
        "--usage-description",
        default=DEFAULT_USAGE_DESCRIPTION,
        help="Value to store in NSBluetoothAlwaysUsageDescription.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    plist_path = find_python_app_info_plist(args.python_executable)
    if plist_path is None:
        print("Could not locate a Python.app Info.plist for that interpreter.", file=sys.stderr)
        return 1

    with plist_path.open("rb") as handle:
        plist = plistlib.load(handle)

    plist[USAGE_KEY] = args.usage_description

    with plist_path.open("wb") as handle:
        plistlib.dump(plist, handle, sort_keys=True)

    print(f"Updated {plist_path}")
    print(f"Set {USAGE_KEY}={args.usage_description!r}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

