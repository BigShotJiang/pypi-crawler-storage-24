"""Tests for generated client classes."""

import pytest

import aho_sdk
from aho_sdk import Issuer, Holder, Verifier, Account


class TestSdkModule:
    """Tests for the main aho_sdk module."""

    def test_exports_issuer(self):
        assert hasattr(aho_sdk, "Issuer")

    def test_exports_holder(self):
        assert hasattr(aho_sdk, "Holder")

    def test_exports_verifier(self):
        assert hasattr(aho_sdk, "Verifier")

    def test_exports_account(self):
        assert hasattr(aho_sdk, "Account")

    def test_exports_page(self):
        assert hasattr(aho_sdk, "Page")

    def test_exports_api_error(self):
        assert hasattr(aho_sdk, "ApiError")

    def test_exports_version(self):
        assert hasattr(aho_sdk, "VERSION")


class TestIssuer:
    """Tests for Issuer client."""

    def test_init_creates_client(self):
        client = Issuer(api_key="test-key")

        assert client is not None

    def test_init_accepts_custom_base_url(self):
        client = Issuer(api_key="test-key", base_url="https://custom.com")

        assert client._client._base_url == "https://custom.com"

    def test_has_credentials_resource(self):
        client = Issuer(api_key="test-key")

        assert hasattr(client, "credentials")
        assert hasattr(client.credentials, "list")
        assert hasattr(client.credentials, "get")
        assert hasattr(client.credentials, "create")
        assert hasattr(client.credentials, "revoke")
        assert hasattr(client.credentials, "suspend")
        assert hasattr(client.credentials, "reinstate")

    def test_has_schemas_resource(self):
        client = Issuer(api_key="test-key")

        assert hasattr(client, "schemas")
        assert hasattr(client.schemas, "list")
        assert hasattr(client.schemas, "get")
        assert hasattr(client.schemas, "create")
        assert hasattr(client.schemas, "update")
        assert hasattr(client.schemas, "delete")
        assert hasattr(client.schemas, "activate")
        assert hasattr(client.schemas, "archive")

    def test_has_offers_resource(self):
        client = Issuer(api_key="test-key")

        assert hasattr(client, "offers")
        assert hasattr(client.offers, "list")
        assert hasattr(client.offers, "get")
        assert hasattr(client.offers, "create")
        assert hasattr(client.offers, "revoke")

    def test_has_automations_resource(self):
        client = Issuer(api_key="test-key")

        assert hasattr(client, "automations")
        assert hasattr(client.automations, "list")
        assert hasattr(client.automations, "get")
        assert hasattr(client.automations, "create")
        assert hasattr(client.automations, "update")
        assert hasattr(client.automations, "delete")
        assert hasattr(client.automations, "trigger")
        assert hasattr(client.automations, "pause")
        assert hasattr(client.automations, "resume")

    def test_has_data_sources_resource(self):
        client = Issuer(api_key="test-key")

        assert hasattr(client, "data_sources")
        assert hasattr(client.data_sources, "list")
        assert hasattr(client.data_sources, "get")
        assert hasattr(client.data_sources, "create")
        assert hasattr(client.data_sources, "update")
        assert hasattr(client.data_sources, "delete")
        assert hasattr(client.data_sources, "test")

    def test_has_data_source_mappings_resource(self):
        client = Issuer(api_key="test-key")

        assert hasattr(client, "data_source_mappings")
        assert hasattr(client.data_source_mappings, "list")
        assert hasattr(client.data_source_mappings, "get")
        assert hasattr(client.data_source_mappings, "create")
        assert hasattr(client.data_source_mappings, "update")
        assert hasattr(client.data_source_mappings, "delete")

    def test_has_render_templates_resource(self):
        client = Issuer(api_key="test-key")

        assert hasattr(client, "render_templates")
        assert hasattr(client.render_templates, "list")
        assert hasattr(client.render_templates, "get")
        assert hasattr(client.render_templates, "create")
        assert hasattr(client.render_templates, "update")
        assert hasattr(client.render_templates, "delete")
        assert hasattr(client.render_templates, "validate")

    def test_has_verify_methods(self):
        client = Issuer(api_key="test-key")

        assert hasattr(client, "verify")
        assert hasattr(client, "verify_by_uuid")


class TestHolder:
    """Tests for Holder client."""

    def test_init_creates_client(self):
        client = Holder(api_key="test-key")

        assert client is not None

    def test_has_credentials_resource(self):
        client = Holder(api_key="test-key")

        assert hasattr(client, "credentials")
        assert hasattr(client.credentials, "list")
        assert hasattr(client.credentials, "get")

    def test_has_presentations_resource(self):
        client = Holder(api_key="test-key")

        assert hasattr(client, "presentations")
        assert hasattr(client.presentations, "list")
        assert hasattr(client.presentations, "get")
        assert hasattr(client.presentations, "create")
        assert hasattr(client.presentations, "delete")


class TestVerifier:
    """Tests for Verifier client."""

    def test_init_creates_client(self):
        client = Verifier(api_key="test-key")

        assert client is not None

    def test_has_presentations_resource(self):
        client = Verifier(api_key="test-key")

        assert hasattr(client, "presentations")
        assert hasattr(client.presentations, "verify")

    def test_has_requests_resource(self):
        client = Verifier(api_key="test-key")

        assert hasattr(client, "requests")
        assert hasattr(client.requests, "list")
        assert hasattr(client.requests, "get")
        assert hasattr(client.requests, "create")
        assert hasattr(client.requests, "update")
        assert hasattr(client.requests, "delete")
        assert hasattr(client.requests, "activate")
        assert hasattr(client.requests, "close")
        assert hasattr(client.requests, "qr_code")

    def test_has_responses_resource(self):
        client = Verifier(api_key="test-key")

        assert hasattr(client, "responses")
        assert hasattr(client.responses, "list")
        assert hasattr(client.responses, "get")


class TestAccount:
    """Tests for Account client."""

    def test_init_creates_client(self):
        client = Account(api_key="test-key")

        assert client is not None

    def test_has_api_keys_resource(self):
        client = Account(api_key="test-key")

        assert hasattr(client, "api_keys")

    def test_has_domains_resource(self):
        client = Account(api_key="test-key")

        assert hasattr(client, "domains")

    def test_has_signing_keys_resource(self):
        client = Account(api_key="test-key")

        assert hasattr(client, "signing_keys")

    def test_has_webhooks_resource(self):
        client = Account(api_key="test-key")

        assert hasattr(client, "webhooks")
