"""Tests for exception classes and error details normalization."""

import json
import pytest

from aho_sdk.exceptions import (
    ApiError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    ForbiddenError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)


class TestApiError:
    """Tests for ApiError base class."""

    def test_extracts_message_from_error_object(self):
        body = json.dumps({"error": {"message": "Something went wrong"}})
        error = ApiError(body, 400)

        assert str(error) == "Something went wrong"

    def test_extracts_error_code(self):
        body = json.dumps({"error": {"message": "Bad request", "code": "invalid_params"}})
        error = ApiError(body, 400)

        assert error.error_code == "invalid_params"

    def test_preserves_request_id(self):
        body = json.dumps({"error": {"message": "Not found"}})
        error = ApiError(body, 404, "req-123-abc")

        assert error.request_id == "req-123-abc"

    def test_preserves_raw_body(self):
        body = json.dumps({"error": {"message": "Server error"}})
        error = ApiError(body, 500)

        assert error.raw_body == body

    def test_handles_non_json_body(self):
        body = "Internal Server Error"
        error = ApiError(body, 500)

        assert str(error) == "Internal Server Error"
        assert error.error_code == "unknown"
        assert error.details == []

    def test_handles_empty_json_body(self):
        body = "{}"
        error = ApiError(body, 400)

        assert error.details == []


class TestDetailsNormalization:
    """Tests for error details normalization."""

    def test_normalizes_none_to_empty_list(self):
        body = json.dumps({"error": {"message": "Error"}})
        error = ApiError(body, 400)

        assert error.details == []

    def test_normalizes_string_details(self):
        body = json.dumps({"error": {"message": "Error", "details": "Name is required"}})
        error = ApiError(body, 422)

        assert error.details == [{"field": "_base", "issue": "error", "hint": "Name is required"}]

    def test_normalizes_array_of_strings(self):
        body = json.dumps(
            {"error": {"message": "Errors", "details": ["Name required", "Email invalid"]}}
        )
        error = ApiError(body, 422)

        assert error.details == [
            {"field": "_base", "issue": "error", "hint": "Name required"},
            {"field": "_base", "issue": "error", "hint": "Email invalid"},
        ]

    def test_preserves_array_of_field_error_dicts(self):
        details = [
            {"field": "email", "issue": "invalid_format", "hint": "Must be valid email"},
            {"field": "name", "issue": "too_short", "hint": "Must be at least 2 characters"},
        ]
        body = json.dumps({"error": {"message": "Validation failed", "details": details}})
        error = ApiError(body, 422)

        assert error.details == details

    def test_normalizes_legacy_hash_format(self):
        body = json.dumps(
            {
                "error": {
                    "message": "Validation failed",
                    "details": {
                        "email": ["is invalid", "already taken"],
                        "name": ["is too short"],
                    },
                }
            }
        )
        error = ApiError(body, 422)

        assert len(error.details) == 3
        email_errors = [d for d in error.details if d["field"] == "email"]
        name_errors = [d for d in error.details if d["field"] == "name"]
        assert len(email_errors) == 2
        assert len(name_errors) == 1

    def test_normalizes_mixed_array(self):
        body = json.dumps(
            {
                "error": {
                    "message": "Errors",
                    "details": [
                        "General error",
                        {"field": "email", "issue": "invalid", "hint": "Bad format"},
                    ],
                }
            }
        )
        error = ApiError(body, 422)

        assert error.details == [
            {"field": "_base", "issue": "error", "hint": "General error"},
            {"field": "email", "issue": "invalid", "hint": "Bad format"},
        ]


class TestValidationError:
    """Tests for ValidationError."""

    def test_field_errors_returns_details(self):
        body = json.dumps(
            {
                "error": {
                    "message": "Validation failed",
                    "details": [
                        {"field": "email", "issue": "invalid_format", "hint": "Must be valid email"}
                    ],
                }
            }
        )
        error = ValidationError(body, 422)

        assert error.field_errors == [
            {"field": "email", "issue": "invalid_format", "hint": "Must be valid email"}
        ]

    def test_errors_by_field_groups_errors(self):
        body = json.dumps(
            {
                "error": {
                    "message": "Validation failed",
                    "details": [
                        {"field": "email", "issue": "invalid_format", "hint": "Must be valid email"},
                        {"field": "email", "issue": "already_taken", "hint": "Email already exists"},
                        {"field": "name", "issue": "too_short", "hint": "Must be at least 2 characters"},
                    ],
                }
            }
        )
        error = ValidationError(body, 422)

        grouped = error.errors_by_field
        assert set(grouped.keys()) == {"email", "name"}
        assert len(grouped["email"]) == 2
        assert len(grouped["name"]) == 1


class TestRateLimitError:
    """Tests for RateLimitError."""

    def test_stores_retry_after(self):
        body = json.dumps({"error": {"message": "Rate limited"}})
        error = RateLimitError(body, 429, "req-123", 60.0)

        assert error.retry_after == 60.0
        assert error.status_code == 429

    def test_handles_none_retry_after(self):
        body = json.dumps({"error": {"message": "Rate limited"}})
        error = RateLimitError(body, 429, None, None)

        assert error.retry_after is None


class TestNetworkError:
    """Tests for NetworkError."""

    def test_sets_status_code_to_zero(self):
        error = NetworkError("Connection refused")

        assert error.status_code == 0
        assert str(error) == "Connection refused"


class TestErrorHierarchy:
    """Tests for error class inheritance."""

    def test_bad_request_inherits_from_api_error(self):
        assert issubclass(BadRequestError, ApiError)

    def test_authentication_error_inherits_from_api_error(self):
        assert issubclass(AuthenticationError, ApiError)

    def test_forbidden_error_inherits_from_api_error(self):
        assert issubclass(ForbiddenError, ApiError)

    def test_not_found_error_inherits_from_api_error(self):
        assert issubclass(NotFoundError, ApiError)

    def test_conflict_error_inherits_from_api_error(self):
        assert issubclass(ConflictError, ApiError)

    def test_validation_error_inherits_from_api_error(self):
        assert issubclass(ValidationError, ApiError)

    def test_server_error_inherits_from_api_error(self):
        assert issubclass(ServerError, ApiError)

    def test_rate_limit_error_inherits_from_api_error(self):
        assert issubclass(RateLimitError, ApiError)

    def test_network_error_inherits_from_exception(self):
        assert issubclass(NetworkError, Exception)
