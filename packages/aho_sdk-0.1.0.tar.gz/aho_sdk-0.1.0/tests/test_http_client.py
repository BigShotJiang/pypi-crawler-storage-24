"""Tests for HttpClient."""

import json
from unittest.mock import MagicMock, patch

import pytest

from aho_sdk.http_client import HttpClient
from aho_sdk.exceptions import (
    AuthenticationError,
    BadRequestError,
    ConflictError,
    ForbiddenError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)


class TestHttpClientInit:
    """Tests for HttpClient initialization."""

    def test_sets_default_base_url(self):
        client = HttpClient(api_key="test-key")

        assert client._base_url == "https://aho.com"

    def test_allows_custom_base_url(self):
        client = HttpClient(api_key="test-key", base_url="https://custom.example.com/")

        assert client._base_url == "https://custom.example.com"

    def test_strips_trailing_slash(self):
        client = HttpClient(api_key="test-key", base_url="https://example.com/")

        assert client._base_url == "https://example.com"


class TestHttpClientHeaders:
    """Tests for request headers."""

    def test_includes_api_key_header(self):
        client = HttpClient(api_key="test-api-key")
        headers = client._build_headers()

        assert headers["X-API-Key"] == "test-api-key"

    def test_includes_content_type(self):
        client = HttpClient(api_key="test-key")
        headers = client._build_headers()

        assert headers["Content-Type"] == "application/json"

    def test_includes_accept_header(self):
        client = HttpClient(api_key="test-key")
        headers = client._build_headers()

        assert headers["Accept"] == "application/json"

    def test_includes_user_agent(self):
        client = HttpClient(api_key="test-key")
        headers = client._build_headers()

        assert "aho_sdk/" in headers["User-Agent"]
        assert "python/" in headers["User-Agent"]


class TestBuildUrl:
    """Tests for URL building."""

    def test_builds_simple_url(self):
        client = HttpClient(api_key="test-key")
        url = client._build_url("/api/v1/test", None)

        assert url == "https://aho.com/api/v1/test"

    def test_adds_query_params(self):
        client = HttpClient(api_key="test-key")
        url = client._build_url("/api/v1/test", {"page": 2, "status": "active"})

        assert "page=2" in url
        assert "status=active" in url

    def test_flattens_array_params(self):
        client = HttpClient(api_key="test-key")
        url = client._build_url("/api/v1/test", {"status": ["active", "pending"]})

        assert "status%5B%5D=active" in url or "status[]=active" in url
        assert "status%5B%5D=pending" in url or "status[]=pending" in url

    def test_excludes_none_params(self):
        client = HttpClient(api_key="test-key")
        url = client._build_url("/api/v1/test", {"page": 1, "status": None})

        assert "page=1" in url
        assert "status" not in url


class TestIdempotentMethods:
    """Tests for idempotent method classification."""

    def test_get_is_idempotent(self):
        assert "GET" in HttpClient.IDEMPOTENT_METHODS

    def test_delete_is_idempotent(self):
        assert "DELETE" in HttpClient.IDEMPOTENT_METHODS

    def test_put_is_idempotent(self):
        assert "PUT" in HttpClient.IDEMPOTENT_METHODS

    def test_head_is_idempotent(self):
        assert "HEAD" in HttpClient.IDEMPOTENT_METHODS

    def test_options_is_idempotent(self):
        assert "OPTIONS" in HttpClient.IDEMPOTENT_METHODS

    def test_post_is_not_idempotent(self):
        assert "POST" not in HttpClient.IDEMPOTENT_METHODS

    def test_patch_is_not_idempotent(self):
        assert "PATCH" not in HttpClient.IDEMPOTENT_METHODS


class MockResponse:
    """Mock HTTP response for testing."""

    def __init__(self, status, body, headers=None):
        self.status = status
        self._body = body.encode("utf-8") if isinstance(body, str) else body
        self.headers = headers or {}

    def read(self):
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class MockHTTPError(Exception):
    """Mock HTTPError for testing."""

    def __init__(self, code, body, headers=None):
        self.code = code
        self._body = body.encode("utf-8") if isinstance(body, str) else body
        self.headers = headers or {}

    def read(self):
        return self._body


class TestErrorHandling:
    """Tests for error handling."""

    def test_raises_bad_request_on_400(self):
        client = HttpClient(api_key="test-key")
        error = MockHTTPError(400, json.dumps({"error": {"message": "Bad request"}}))

        with pytest.raises(BadRequestError) as exc_info:
            client._handle_error_response(error)

        assert exc_info.value.status_code == 400

    def test_raises_authentication_error_on_401(self):
        client = HttpClient(api_key="test-key")
        error = MockHTTPError(401, json.dumps({"error": {"message": "Invalid API key"}}))

        with pytest.raises(AuthenticationError) as exc_info:
            client._handle_error_response(error)

        assert exc_info.value.status_code == 401

    def test_raises_forbidden_error_on_403(self):
        client = HttpClient(api_key="test-key")
        error = MockHTTPError(403, json.dumps({"error": {"message": "Forbidden"}}))

        with pytest.raises(ForbiddenError):
            client._handle_error_response(error)

    def test_raises_not_found_on_404(self):
        client = HttpClient(api_key="test-key")
        error = MockHTTPError(404, json.dumps({"error": {"message": "Not found"}}))

        with pytest.raises(NotFoundError):
            client._handle_error_response(error)

    def test_raises_conflict_on_409(self):
        client = HttpClient(api_key="test-key")
        error = MockHTTPError(409, json.dumps({"error": {"message": "Conflict"}}))

        with pytest.raises(ConflictError):
            client._handle_error_response(error)

    def test_raises_validation_error_on_422(self):
        client = HttpClient(api_key="test-key")
        error = MockHTTPError(422, json.dumps({"error": {"message": "Validation failed"}}))

        with pytest.raises(ValidationError):
            client._handle_error_response(error)

    def test_raises_rate_limit_error_on_429(self):
        client = HttpClient(api_key="test-key")
        error = MockHTTPError(
            429,
            json.dumps({"error": {"message": "Rate limited"}}),
            headers={"Retry-After": "60"},
        )

        with pytest.raises(RateLimitError) as exc_info:
            client._handle_error_response(error)

        assert exc_info.value.retry_after == 60.0

    def test_raises_server_error_on_500(self):
        client = HttpClient(api_key="test-key")
        error = MockHTTPError(500, json.dumps({"error": {"message": "Internal error"}}))

        with pytest.raises(ServerError):
            client._handle_error_response(error)

    def test_raises_server_error_on_503(self):
        client = HttpClient(api_key="test-key")
        error = MockHTTPError(503, json.dumps({"error": {"message": "Service unavailable"}}))

        with pytest.raises(ServerError):
            client._handle_error_response(error)


class TestResponseHandling:
    """Tests for response handling."""

    def test_returns_none_for_empty_body(self):
        client = HttpClient(api_key="test-key")
        response = MockResponse(204, "")

        result = client._handle_response(response)

        assert result is None

    def test_parses_json_response(self):
        client = HttpClient(api_key="test-key")
        response = MockResponse(200, json.dumps({"data": {"uuid": "test-123"}}))

        result = client._handle_response(response)

        assert result["data"]["uuid"] == "test-123"


class TestLogging:
    """Tests for logging."""

    def test_logs_request_when_logger_provided(self):
        logger = MagicMock()
        client = HttpClient(api_key="test-key", logger=logger)

        client._log_request("GET", "https://aho.com/api/v1/test")

        logger.debug.assert_called_once()

    def test_does_not_log_when_no_logger(self):
        client = HttpClient(api_key="test-key")

        # Should not raise
        client._log_request("GET", "https://aho.com/api/v1/test")

    def test_logs_retry_when_logger_provided(self):
        logger = MagicMock()
        client = HttpClient(api_key="test-key", logger=logger)

        client._log_retry("GET", "https://aho.com/api/v1/test", 1, 1.0)

        logger.warning.assert_called_once()
