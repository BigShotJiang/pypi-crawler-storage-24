"""Tests for Page pagination class."""

import pytest

from aho_sdk.page import Page


class TestPage:
    """Tests for Page class."""

    @pytest.fixture
    def meta(self):
        return {
            "current_page": 1,
            "per_page": 25,
            "total_count": 75,
            "total_pages": 3,
        }

    @pytest.fixture
    def data(self):
        return [{"uuid": "1"}, {"uuid": "2"}]

    @pytest.fixture
    def fetch_next(self):
        return lambda p: None

    def test_stores_data_and_meta(self, data, meta, fetch_next):
        page = Page(data=data, meta=meta, fetch_next=fetch_next)

        assert page.data == data
        assert page.meta == meta

    def test_current_page(self, data, meta, fetch_next):
        page = Page(data=data, meta=meta, fetch_next=fetch_next)

        assert page.current_page == 1

    def test_total_pages(self, data, meta, fetch_next):
        page = Page(data=data, meta=meta, fetch_next=fetch_next)

        assert page.total_pages == 3

    def test_total_count(self, data, meta, fetch_next):
        page = Page(data=data, meta=meta, fetch_next=fetch_next)

        assert page.total_count == 75

    def test_per_page(self, data, meta, fetch_next):
        page = Page(data=data, meta=meta, fetch_next=fetch_next)

        assert page.per_page == 25

    def test_is_last_page_returns_false_when_not_last(self, data, meta, fetch_next):
        page = Page(data=data, meta=meta, fetch_next=fetch_next)

        assert page.is_last_page() is False

    def test_is_last_page_returns_true_on_last_page(self, data, meta, fetch_next):
        last_meta = {**meta, "current_page": 3}
        page = Page(data=data, meta=last_meta, fetch_next=fetch_next)

        assert page.is_last_page() is True

    def test_is_last_page_returns_true_when_exceeds_total(self, data, meta, fetch_next):
        beyond_meta = {**meta, "current_page": 4}
        page = Page(data=data, meta=beyond_meta, fetch_next=fetch_next)

        assert page.is_last_page() is True

    def test_next_page_returns_none_on_last_page(self, data, meta, fetch_next):
        last_meta = {**meta, "current_page": 3}
        page = Page(data=data, meta=last_meta, fetch_next=fetch_next)

        assert page.next_page() is None

    def test_next_page_calls_fetch_next(self, data, meta):
        page2_data = [{"uuid": "3"}, {"uuid": "4"}]
        page2_meta = {**meta, "current_page": 2}
        page2 = Page(data=page2_data, meta=page2_meta, fetch_next=lambda p: None)

        def fetcher(page_num):
            return page2 if page_num == 2 else None

        page1 = Page(data=data, meta=meta, fetch_next=fetcher)
        result = page1.next_page()

        assert result == page2
        assert result.data == page2_data

    def test_len_returns_items_on_page(self, data, meta, fetch_next):
        page = Page(data=data, meta=meta, fetch_next=fetch_next)

        assert len(page) == 2

    def test_bool_returns_true_when_has_items(self, data, meta, fetch_next):
        page = Page(data=data, meta=meta, fetch_next=fetch_next)

        assert bool(page) is True

    def test_bool_returns_false_when_empty(self, meta, fetch_next):
        page = Page(data=[], meta=meta, fetch_next=fetch_next)

        assert bool(page) is False


class TestPageIteration:
    """Tests for Page iteration."""

    def test_iterates_single_page(self):
        data = [{"uuid": "1"}, {"uuid": "2"}]
        meta = {"current_page": 1, "per_page": 25, "total_count": 2, "total_pages": 1}
        page = Page(data=data, meta=meta, fetch_next=lambda p: None)

        items = list(page)

        assert items == data

    def test_iterates_multiple_pages(self):
        meta_base = {"per_page": 2, "total_count": 5, "total_pages": 3}

        page3 = Page(
            data=[{"uuid": "5"}],
            meta={**meta_base, "current_page": 3},
            fetch_next=lambda p: None,
        )

        page2 = Page(
            data=[{"uuid": "3"}, {"uuid": "4"}],
            meta={**meta_base, "current_page": 2},
            fetch_next=lambda p: page3,
        )

        page1 = Page(
            data=[{"uuid": "1"}, {"uuid": "2"}],
            meta={**meta_base, "current_page": 1},
            fetch_next=lambda p: page2,
        )

        uuids = [item["uuid"] for item in page1]

        assert uuids == ["1", "2", "3", "4", "5"]

    def test_works_with_list_comprehension(self):
        data = [
            {"uuid": "1", "active": True},
            {"uuid": "2", "active": False},
            {"uuid": "3", "active": True},
        ]
        meta = {"current_page": 1, "per_page": 25, "total_count": 3, "total_pages": 1}
        page = Page(data=data, meta=meta, fetch_next=lambda p: None)

        active_items = [item for item in page if item["active"]]

        assert len(active_items) == 2

    def test_works_with_next(self):
        data = [{"uuid": "1"}, {"uuid": "2"}]
        meta = {"current_page": 1, "per_page": 25, "total_count": 2, "total_pages": 1}
        page = Page(data=data, meta=meta, fetch_next=lambda p: None)

        first = next(iter(page))

        assert first["uuid"] == "1"
