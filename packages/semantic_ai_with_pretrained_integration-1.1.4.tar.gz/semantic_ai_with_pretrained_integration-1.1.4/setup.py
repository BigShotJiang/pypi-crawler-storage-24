"""
The SAPI (Semantic AI With Pretrained Integration) is an architectural module for training, fine-tuning, and inference of language models from the Sapiens family.
In inference, it combines multiple pre-trained models dynamically selected based on the semantics of the input prompt, thereby contributing to more accurate responses that meet the user's needs.
In training, it uses proprietary architectures with direct calculations capable of completely eradicating dependence on backpropagation,
which makes the training process much faster and with lower computational resource demand. Beneath the module's abstraction layer,
submodels stored in the Frankenstein class structure are being operated on and managed by the Entity algorithm.
The Frankenstein stores submodels of distinct architectures, ranging from traditional transformer models to models that partially or even completely eliminate backpropagation.
And the Entity decides which model is most suitable for the current situation.

The Sapiens Technology®️ does not allow the copying, sharing, editing, customization, or manipulation of this and all its other algorithms by third parties without the company's prior authorization.
Reverse engineering, or public posts and comments that in any way reveal the company's technical concepts, are also strictly prohibited. Failure to comply with these guidelines will result in legal action taken by our team of lawyers.
"""
from setuptools import setup, find_packages
package_name = 'semantic_ai_with_pretrained_integration'
version = '1.1.4'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    install_requires=[
        'sapiens-tokenizer',
        'mgt',
        'sapiens-model',
        'sapiens-transformers',
        'utilities-nlp',
        'INFINITE-CONTEXT-WINDOW',
        'FRANKENSTEIN-MODEL',
        'SCHIZOPHRENIC-AI',
        'sapitensors',
        'certifi'
    ],
    url='https://github.com/sapiens-technology/semantic_ai_with_pretrained_integration',
    license='Proprietary Software'
)
"""
The SAPI (Semantic AI With Pretrained Integration) is an architectural module for training, fine-tuning, and inference of language models from the Sapiens family.
In inference, it combines multiple pre-trained models dynamically selected based on the semantics of the input prompt, thereby contributing to more accurate responses that meet the user's needs.
In training, it uses proprietary architectures with direct calculations capable of completely eradicating dependence on backpropagation,
which makes the training process much faster and with lower computational resource demand. Beneath the module's abstraction layer,
submodels stored in the Frankenstein class structure are being operated on and managed by the Entity algorithm.
The Frankenstein stores submodels of distinct architectures, ranging from traditional transformer models to models that partially or even completely eliminate backpropagation.
And the Entity decides which model is most suitable for the current situation.

The Sapiens Technology®️ does not allow the copying, sharing, editing, customization, or manipulation of this and all its other algorithms by third parties without the company's prior authorization.
Reverse engineering, or public posts and comments that in any way reveal the company's technical concepts, are also strictly prohibited. Failure to comply with these guidelines will result in legal action taken by our team of lawyers.
"""
