import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton
from PyQt5.QtGui import QIcon, QKeySequence, QPixmap
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QLineEdit
from PyQt5.QtCore import QTimer
from PyQt5.QtGui import QPainter, QColor, QBrush, QPen


class CustomWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.key_callback = None
        self.mouse_callback = None
    def keyPressEvent(self, event):
        if self.key_callback:
            self.key_callback(event.key()) 

    def keyPressEvent(self, event):
        if self.key_callback:
            key_name = QKeySequence(event.key()).toString()
            self.key_callback(key_name)

    def mousePressEvent(self, event):
        if self.mouse_callback:
            btn = event.button()
            if btn == Qt.LeftButton: name = "LeftClick"
            elif btn == Qt.RightButton: name = "RightClick"
            elif btn == Qt.MidButton: name = "MiddleClick"
            else: name = "UnknownClick"
            self.mouse_callback(name)

class Window:
    def __init__(self):
        self.app = QApplication.instance() or QApplication(sys.argv)
        self.window = CustomWidget()
        self.window.setWindowTitle("PyApp")
        self.window.resize(500, 500)
    
    def on_key(self, func): self.window.key_callback = func
    def on_click(self, func): self.window.mouse_callback = func
    def FullScreen(self): self.window.showFullScreen()
    def NormalScreen(self): self.window.showNormal()
    def MaxScreen(self): self.window.showMaximized()
    def logo(self, path): self.window.setWindowIcon(QIcon(path))
    def title(self, t): self.window.setWindowTitle(t)
    def size(self, w, h): self.window.resize(w, h)
    def bg(self, c): self.window.setStyleSheet(f"background-color: {c};")
    def destroy(self): self.window.deleteLater()
    def transparency(self, t): self.window.setWindowOpacity(t)
    def run(self):
        self.window.show()
        sys.exit(self.app.exec_())

class Text:
    def __init__(self, parent_window, tx):
        self.obj = QLabel(tx, parent=parent_window.window)
        self.obj.show()

    def _get_btn_name(self, btn):
        if btn == Qt.LeftButton: return "LeftClick"
        elif btn == Qt.RightButton: return "RightClick"
        elif btn == Qt.MidButton: return "MiddleClick"
        return "UnknownClick"

    def on_click(self, func):
        self.obj.mousePressEvent = lambda event: func(self._get_btn_name(event.button()))
    
    def on_double_click(self, func):
        self.obj.mouseDoubleClickEvent = lambda event: func(self._get_btn_name(event.button()))

    def color(self, c1): self.obj.setStyleSheet(f"color: {c1};")
    def bg(self, b1): self.obj.setStyleSheet(f"background-color: {b1};")
    def position(self, x, y): self.obj.move(x, y)
    def size(self, w, h): self.obj.resize(w, h)
    def destroy(self): self.obj.deleteLater()

class Button:
    def __init__(self, parent_window, tx):
        self.obj = QPushButton(tx, parent=parent_window.window)
        self.obj.show()

    def _get_btn_name(self, btn):
        if btn == Qt.LeftButton: return "LeftClick"
        elif btn == Qt.RightButton: return "RightClick"
        elif btn == Qt.MidButton: return "MiddleClick"
        return "UnknownClick"

    def on_click(self, func):
        self.obj.mousePressEvent = lambda event: func(self._get_btn_name(event.button()))

    def color(self, c1): self.obj.setStyleSheet(f"color: {c1};")
    def bg(self, b1): self.obj.setStyleSheet(f"background-color: {b1};")
    def position(self, x, y): self.obj.move(x, y)
    def size(self, w, h): self.obj.resize(w, h)
    def destroy(self): self.obj.deleteLater()

class Img:
    def __init__(self, parent_window, path):
        self.obj = QLabel(parent=parent_window.window)
        self.pixmap = QPixmap(path)
        self.obj.setPixmap(self.pixmap)
        self.obj.resize(self.pixmap.width(), self.pixmap.height())
        self.obj.show()

    def _get_btn_name(self, btn):
        if btn == Qt.LeftButton: return "LeftClick"
        elif btn == Qt.RightButton: return "RightClick"
        elif btn == Qt.MidButton: return "MiddleClick"
        return "UnknownClick"
    def on_click(self, func):
        self.obj.mousePressEvent = lambda event: func(self._get_btn_name(event.button()))
    def on_double_click(self, func):
        self.obj.mouseDoubleClickEvent = lambda event: func(self._get_btn_name(event.button()))
    def position(self, x, y): self.obj.move(x, y)
    def size(self, w, h): 
        self.obj.setPixmap(self.pixmap.scaled(w, h, Qt.KeepAspectRatio))
        self.obj.resize(w, h)
    def destroy(self): self.obj.deleteLater()

class Entry:
    def __init__(self, parent_window, placeholder=""):
        self.obj = QLineEdit(parent=parent_window.window)
        self.obj.setPlaceholderText(placeholder)
        self.obj.show()

    def get_text(self): return self.obj.text()

    def set_text(self, text): self.obj.setText(text)

    # Событие при нажатии Enter
    def on_enter(self, func):
        self.obj.returnPressed.connect(func)

    # Стандартные методы для позиции и размера (как у тебя в Button/Text)
    def position(self, x, y): self.obj.move(x, y)
    def size(self, w, h): self.obj.resize(w, h)
    
    # Скрытие текста (например, для паролей)
    def password_mode(self):
        self.obj.setEchoMode(QLineEdit.Password)

class Timer:
    def __init__(self, interval, func, once=False):
        self.timer = QTimer()
        self.timer.timeout.connect(func)
        
        self.timer.setSingleShot(once)
        
        self.timer.start(interval)

    def stop(self): self.timer.stop()
    def start(self, interval=None): 
        if interval: self.timer.start(interval)
        else: self.timer.start()

    def is_active(self): return self.timer.isActive()

    def set_speed(self, ms): self.timer.setInterval(ms)

class Square:
    def __init__(self, parent_window, color="red"):
        self.obj = QLabel(parent=parent_window.window)
        self.color_val = color
        self.obj.setStyleSheet(f"background-color: {color};")
        self.obj.show()

    def position(self, x, y): self.obj.move(x, y)
    def size(self, w, h): self.obj.resize(w, h)
    def bg(self, c): 
        self.color_val = c
        self.obj.setStyleSheet(f"background-color: {c};")
    def destroy(self): self.obj.deleteLater()
    def _get_btn_name(self, btn):
        if btn == Qt.LeftButton: return "LeftClick"
        elif btn == Qt.RightButton: return "RightClick"
        elif btn == Qt.MidButton: return "MiddleClick"
        return "UnknownClick"

    def on_click(self, func):
        self.obj.mousePressEvent = lambda event: func(self._get_btn_name(event.button()))
    
    def on_double_click(self, func):
        self.obj.mouseDoubleClickEvent = lambda event: func(self._get_btn_name(event.button()))

class Circle:
    def __init__(self, parent_window, color="blue"):
        self.obj = QLabel(parent=parent_window.window)
        self.color_val = color
        self.obj.show()

    def size(self, w, h):
        self.obj.resize(w, h)
        self.obj.setStyleSheet(f"background-color: {self.color_val};")

    def position(self, x, y): self.obj.move(x, y)
    def bg(self, c):
        self.color_val = c
        self.obj.setStyleSheet(f"background-color: {c}; border-radius: {self.obj.width() // 2}px;")
    def destroy(self): self.obj.deleteLater()
    def _get_btn_name(self, btn):
        if btn == Qt.LeftButton: return "LeftClick"
        elif btn == Qt.RightButton: return "RightClick"
        elif btn == Qt.MidButton: return "MiddleClick"
        return "UnknownClick"

    def on_click(self, func):
        self.obj.mousePressEvent = lambda event: func(self._get_btn_name(event.button()))
    
    def on_double_click(self, func):
        self.obj.mouseDoubleClickEvent = lambda event: func(self._get_btn_name(event.button()))


