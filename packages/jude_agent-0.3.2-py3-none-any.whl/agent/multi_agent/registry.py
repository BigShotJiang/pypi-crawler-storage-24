"""子 Agent 注册表"""

import logging
from pathlib import Path
from typing import Dict, List, Optional

from .config import SubAgentConfig, load_agents_from_yaml

logger = logging.getLogger(__name__)


class SubAgentRegistry:
    """子 Agent 注册表

    负责子 Agent 的加载、注册和管理
    """

    def __init__(self, config_path: Optional[str] = None):
        self._agents: Dict[str, SubAgentConfig] = {}
        if config_path:
            self._load(config_path)

    def _load(self, config_path: str):
        """加载配置文件"""
        try:
            agents = load_agents_from_yaml(config_path)
            for agent in agents:
                self.register(agent)
            logger.info(f"已加载 {len(agents)} 个子 Agent 配置")
        except Exception as e:
            logger.error(f"加载子 Agent 配置失败: {e}")
            raise

    def register(self, config: SubAgentConfig):
        """注册子 Agent

        Args:
            config: 子 Agent 配置
        """
        self._agents[config.name] = config
        logger.debug(f"已注册子 Agent: {config.name}")

    def get_agent(self, name: str) -> Optional[SubAgentConfig]:
        """获取子 Agent 配置

        Args:
            name: Agent 名称

        Returns:
            子 Agent 配置，如果不存在则返回 None
        """
        return self._agents.get(name)

    def list_agents(self) -> List[SubAgentConfig]:
        """列出所有可用子 Agent

        Returns:
            子 Agent 配置列表
        """
        return list(self._agents.values())

    def match_agents(self, task: str) -> List[SubAgentConfig]:
        """根据任务匹配合适的子 Agent

        简单实现：根据 description 关键词匹配
        未来可以接入 LLM 进行语义匹配

        Args:
            task: 任务描述

        Returns:
            匹配的子 Agent 配置列表
        """
        task_lower = task.lower()
        matched = []

        for agent in self._agents.values():
            # 简单关键词匹配
            desc_lower = agent.description.lower()
            # 检查任务是否包含 agent 描述中的关键词
            keywords = [w for w in desc_lower.split() if len(w) > 2]
            if any(kw in task_lower for kw in keywords):
                matched.append(agent)

        # 如果没有匹配，返回所有 agent（让主 Agent 决定）
        return matched if matched else list(self._agents.values())

    def __len__(self) -> int:
        """返回注册表中 Agent 数量"""
        return len(self._agents)

    def __contains__(self, name: str) -> bool:
        """检查 Agent 是否已注册"""
        return name in self._agents
