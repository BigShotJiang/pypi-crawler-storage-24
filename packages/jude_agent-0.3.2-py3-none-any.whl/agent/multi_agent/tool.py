"""SubAgent LangChain 工具封装"""

import logging
from typing import Any, Dict, Optional

from .agent import SubAgent
from .config import SubAgentConfig
from ..tools.base import BaseTool, ToolOutput

logger = logging.getLogger(__name__)


class SubAgentTool(BaseTool):
    """子 Agent LangChain 工具

    将子 Agent 封装为 LangChain 工具，供主 Agent 调用
    """

    def __init__(self, config: SubAgentConfig, **kwargs):
        self._config = config
        self._agent: Optional[SubAgent] = None

        # 设置 BaseTool 属性
        self.name = f"sub_agent:{config.name}"
        self.description = (
            f"调用子 Agent [{config.name}]：{config.description}。"
            "当需要特定领域专业知识时使用此工具。"
        )
        self.input_schema = {
            "type": "object",
            "properties": {
                "input": {
                    "type": "string",
                    "description": "需要子 Agent 处理的内容或问题",
                }
            },
            "required": ["input"],
        }
        self.category = "multi_agent"

    def _get_agent(self) -> SubAgent:
        """获取或创建子 Agent 实例"""
        if self._agent is None:
            # depth=0 表示这是顶层代理，由主 Agent 调用
            # 子 Agent 内部可以再嵌套调用（最大 2 层）
            self._agent = SubAgent(self._config, depth=0)
        return self._agent

    def execute(self, parameters: Dict[str, Any], context: Optional[Dict] = None) -> ToolOutput:
        """执行子 Agent"""
        try:
            input_text = parameters.get("input", "")

            if not input_text:
                return ToolOutput(
                    success=False,
                    result=None,
                    error="缺少输入参数",
                )

            agent = self._get_agent()
            result = agent.invoke(input_text)

            return ToolOutput(
                success=True,
                result=result,
            )

        except Exception as e:
            logger.error(f"SubAgentTool 执行失败: {e}")
            return ToolOutput(
                success=False,
                result=None,
                error=str(e),
            )

    def reset(self):
        """重置子 Agent"""
        if self._agent:
            self._agent.reset()
            self._agent = None


# 导出便捷函数
def create_sub_agent_tool(config: SubAgentConfig) -> SubAgentTool:
    """创建子 Agent 工具的便捷函数"""
    return SubAgentTool(config)
