"""子 Agent 封装"""

import logging
from typing import Optional

from .config import SubAgentConfig
from core.agent import Agent as CoreAgent
from config import AgentConfig

logger = logging.getLogger(__name__)

# 最大嵌套层级
MAX_AGENT_DEPTH = 2


class SubAgent:
    """子 Agent 封装

    将子 Agent 封装为可调用的实体，包含独立记忆
    """

    def __init__(
        self,
        config: SubAgentConfig,
        depth: int = 0,
        llm_client=None,
    ):
        """
        初始化子 Agent

        Args:
            config: 子 Agent 配置
            depth: 当前嵌套深度
            llm_client: LLM 客户端（可选）
        """
        self.config = config
        self._depth = depth
        self._agent: Optional[CoreAgent] = None
        self._llm_client = llm_client
        self._session_id = f"subagent_{config.name}"

    def _create_agent(self) -> CoreAgent:
        """创建底层 Agent 实例"""
        config = AgentConfig.from_env()

        # 创建 Agent
        return CoreAgent(
            session_id=self._session_id,
            tools=[],  # TODO: 未来支持工具
            max_iterations=self.config.max_iterations,
            show_thinking=False,
            enable_memory=self.config.memory_enabled,
            enable_mcp=False,  # 子 Agent 默认不启用 MCP
            config=config,
        )

    def invoke(self, input_text: str) -> str:
        """
        执行子 Agent

        Args:
            input_text: 输入文本

        Returns:
            Agent 响应
        """
        # 检查层级限制
        if self._depth >= MAX_AGENT_DEPTH - 1:
            raise RuntimeError(f"已达到最大 Agent 层级 ({MAX_AGENT_DEPTH})")

        # 延迟创建 Agent
        if self._agent is None:
            self._agent = self._create_agent()

        logger.info(f"子 Agent [{self.config.name}] 接收输入: {input_text[:50]}...")

        try:
            result = self._agent.process(input_text)
            logger.info(f"子 Agent [{self.config.name}] 返回结果: {result[:50]}...")
            return result
        except Exception as e:
            logger.error(f"子 Agent [{self.config.name}] 执行失败: {e}")
            return f"子 Agent 执行失败: {str(e)}"

    def reset(self):
        """重置子 Agent"""
        if self._agent:
            self._agent.reset()
        logger.debug(f"子 Agent [{self.config.name}] 已重置")

    def __repr__(self) -> str:
        return f"<SubAgent(name={self.config.name}, depth={self._depth})>"
