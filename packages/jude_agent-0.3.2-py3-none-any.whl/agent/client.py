"""Agent CLI 客户端（直接调用模式）

直接创建 Agent 实例进行交互，无需 HTTP 服务
"""

import logging

from config.agent import config

logger = logging.getLogger("agent")


def create_agent_instance(enable_rag: bool = True, enable_calculator: bool = True):
    """创建 Agent 实例"""
    from core.agent import Agent

    # 使用新的 ToolLoader 加载工具
    from .tools import get_tool_loader
    loader = get_tool_loader()

    # 如果禁用了 RAG，从工具列表中移除
    tools = list(loader.get_langchain_tools())

    if not enable_rag:
        # 移除 search_documents
        tools = [t for t in tools if t.name != "search_documents"]

    if not enable_calculator:
        # 移除 calculator
        tools = [t for t in tools if t.name != "calculator"]

    return Agent(
        tools=tools,
        max_iterations=config.max_iterations,
        show_thinking=config.show_thinking,
        enable_multi_agent=config.enable_multi_agent,
    )


class AgentClient:
    """Agent 客户端（直接调用）"""

    def __init__(
        self,
        session_id: str = None,
        enable_rag: bool = True,
        enable_calculator: bool = True,
    ):
        """
        初始化客户端

        Args:
            session_id: 会话 ID（可选）
            enable_rag: 是否启用 RAG
            enable_calculator: 是否启用计算器
        """
        self._session_id = session_id
        self._agent = create_agent_instance(enable_rag, enable_calculator)

        # 如果提供了 session_id，设置到 agent
        if session_id:
            self._agent._session_id = session_id

    @property
    def base_url(self) -> str:
        """返回本地模式标识"""
        return "local (direct)"

    def chat(self, message: str) -> str:
        """
        发送消息并获取响应（直接调用 Agent）

        Args:
            message: 用户消息

        Returns:
            Agent 响应
        """
        try:
            return self._agent.process(message)
        except Exception as e:
            logger.error(f"Agent 执行错误: {e}")
            return f"错误: {str(e)}"

    def reset(self) -> None:
        """重置对话"""
        # 直接创建新的 agent 实例
        self._agent = create_agent_instance()


def run_cli_client(
    session_id: str = None,
    enable_rag: bool = True,
    enable_calculator: bool = True,
):
    """
    运行 CLI 客户端（直接模式）

    Args:
        session_id: 会话 ID
        enable_rag: 是否启用 RAG
        enable_calculator: 是否启用计算器
    """
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    console.print(Panel.fit(
        "[bold blue]Agent CLI 客户端[/bold blue]\n"
        "模式: 直接调用\n"
        "输入 'quit' 或 'exit' 退出\n"
        "输入 'reset' 重置对话",
        border_style="blue"
    ))

    client = AgentClient(session_id, enable_rag, enable_calculator)

    while True:
        try:
            user_input = input("\n你: ").strip()

            if not user_input:
                continue

            if user_input.lower() in ["quit", "exit", "退出"]:
                print("再见!")
                break

            if user_input.lower() == "reset":
                client.reset()
                print("对话已重置")
                continue

            response = client.chat(user_input)
            print(f"\nAgent: {response}")

        except KeyboardInterrupt:
            print("\n\n退出")
            break
        except Exception as e:
            logger.error(f"错误: {e}")


def run_single_query(
    message: str,
    enable_rag: bool = True,
    enable_calculator: bool = True,
) -> str:
    """
    单次问答（直接调用 Agent）

    Args:
        message: 问题
        enable_rag: 是否启用 RAG
        enable_calculator: 是否启用计算器

    Returns:
        Agent 响应
    """
    client = AgentClient(enable_rag=enable_rag, enable_calculator=enable_calculator)
    return client.chat(message)
