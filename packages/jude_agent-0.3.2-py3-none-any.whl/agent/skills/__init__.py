"""Agent Skill 系统

提供用户可调用的命令（以 / 开头），支持多种来源：
- builtin: 内置 Skill
- local: 本地 Skill (~/.jude_agent/skills/)
- pip: pip 安装的 Skill (entry_points)

主要模块：
- base: Skill 基类和标准接口
- loader: Skill 加载器
- registry: Skill 注册表
- builtin: 内置 Skill 实现

使用方式：
    from src.agent.skills import (
        get_skill_registry,
        SkillRegistry,
        SkillLoader,
        BaseSkill,
        SkillContext,
        SkillResult,
    )

    # 获取注册表
    registry = get_skill_registry()

    # 执行 Skill
    result = await registry.execute(
        "help",
        {},
        SkillContext(source="cli")
    )
"""

from .base import (
    BaseSkill,
    SkillArgument,
    SkillCollection,
    SkillContext,
    SkillResult,
    SkillType,
)
from .builtin import (
    HelpSkill,
    ReloadSkill,
    StatusSkill,
)
from .loader import (
    BuiltinSkillSource,
    LocalSkillSource,
    PipSkillSource,
    SkillLoader,
    SkillPackageInfo,
    SkillSource,
    get_skill_loader,
    reload_skill_loader,
)
from .registry import (
    SkillRegistry,
    get_skill_registry,
    reload_skill_registry,
)

__all__ = [
    # 基类
    "BaseSkill",
    "SkillArgument",
    "SkillContext",
    "SkillResult",
    "SkillCollection",
    "SkillType",
    # 加载器
    "SkillLoader",
    "SkillPackageInfo",
    "SkillSource",
    "BuiltinSkillSource",
    "LocalSkillSource",
    "PipSkillSource",
    "get_skill_loader",
    "reload_skill_loader",
    # 注册表
    "SkillRegistry",
    "get_skill_registry",
    "reload_skill_registry",
    # 内置 Skill
    "HelpSkill",
    "ReloadSkill",
    "StatusSkill",
]
