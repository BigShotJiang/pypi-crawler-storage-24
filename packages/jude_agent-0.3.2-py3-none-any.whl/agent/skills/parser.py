"""Skill 命令解析器

解析用户输入的 Skill 命令（以 / 开头）
"""

import shlex
from typing import Any, Dict, Optional, Tuple


class SkillCommandParser:
    """Skill 命令解析器

    将用户输入解析为 Skill 名称和参数

    示例:
        /help                    -> ("help", {})
        /help help              -> ("help", {"skill_name": "help"})
        /status                 -> ("status", {})
    """

    @staticmethod
    def parse(user_input: str) -> Optional[Tuple[str, Dict[str, Any]]]:
        """解析用户输入

        Args:
            user_input: 用户输入字符串

        Returns:
            (skill_name, args) 元组，如果不是 Skill 命令返回 None
        """
        user_input = user_input.strip()

        # 检查是否以 / 开头
        if not user_input.startswith("/"):
            return None

        # 移除开头的 /
        command = user_input[1:].strip()

        if not command:
            return None

        # 使用 shlex 解析（支持引号）
        try:
            parts = shlex.split(command)
        except ValueError:
            # 如果 shlex 解析失败，使用简单的空格分割
            parts = command.split()

        if not parts:
            return None

        skill_name = parts[0]
        args = {}

        # 解析参数
        # 格式: /skill arg1 arg2 key=value key2="value with space"
        positional = parts[1:]

        # 简单参数解析：将位置参数转换为 skill_name（如果 Skill 需要）
        # 或者解析 key=value 格式
        for i, arg in enumerate(positional):
            # 检查是否是 key=value 格式
            if "=" in arg:
                key, value = arg.split("=", 1)
                # 移除可能的引号
                value = value.strip('"\'')
                args[key] = value
            else:
                # 位置参数，尝试确定参数名
                # 这里假设第一个位置参数是 skill_name
                if i == 0:
                    args["skill_name"] = arg
                else:
                    args[f"arg{i}"] = arg

        return skill_name, args

    @staticmethod
    def is_skill_command(user_input: str) -> bool:
        """检查是否是 Skill 命令"""
        return user_input.strip().startswith("/")

    @staticmethod
    def extract_skill_name(user_input: str) -> Optional[str]:
        """提取 Skill 名称"""
        result = SkillCommandParser.parse(user_input)
        if result:
            return result[0]
        return None
