"""通道基类"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..agent import Agent


class Channel(ABC):
    """通道基类"""

    @abstractmethod
    def send(self, message: str) -> None:
        """发送消息"""
        pass

    def receive(self) -> str:
        """接收消息（可选实现）"""
        raise NotImplementedError("此通道不支持接收消息")

    def run(self, agent: "Agent") -> None:
        """运行通道（可选实现）"""
        raise NotImplementedError("此通道不支持运行模式")
