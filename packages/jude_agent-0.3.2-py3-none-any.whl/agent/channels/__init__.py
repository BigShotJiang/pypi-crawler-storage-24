"""Agent 通道模块

提供多种交互通道：
- CLI 通道
- 飞书通道（Stream 模式）
"""

from .base import Channel
from .cli import CLIChannel
from .feishu import FeishuStreamChannel

__all__ = [
    "Channel",
    "CLIChannel",
    "FeishuStreamChannel",
]
