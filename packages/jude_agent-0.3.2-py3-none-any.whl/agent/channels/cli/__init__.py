"""CLI 通道"""

from .channel import CLIChannel

__all__ = ["CLIChannel"]
