"""飞书通道"""

from .channel import FeishuStreamChannel

__all__ = ["FeishuStreamChannel"]
