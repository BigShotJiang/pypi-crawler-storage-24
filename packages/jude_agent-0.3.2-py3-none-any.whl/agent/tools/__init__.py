"""Agent 工具系统

提供统一的工具接口，支持多种调用形式：
- LangChain Tool
- Function Call（OpenAI/MiniMax）
- MCP

主要模块：
- base: 工具基类和标准接口
- adapters: 格式适配器
- loader: 动态工具加载器
- builtin: 内置工具实现

使用方式：
    # 旧版 API（LangChain @tool 装饰器）
    from src.agent.tools import calculator, search_documents, get_default_tools

    # 新版 API（BaseTool 抽象）
    from src.agent.tools import get_tool_loader, ToolCollection, BaseTool
"""

from .adapters import (
    FunctionCallAdapter,
    LangChainAdapter,
    MCPAdapter,
    ToolAdapter,
)
from .base import (
    BaseTool,
    FunctionCallDefinition,
    ToolCollection,
    ToolInput,
    ToolOutput,
)
from .builtin import (
    CalculatorTool,
    CreateToolTool,
    DeletePluginTool,
    ExecuteCommandTool,
    FetchUrlTool,
    GetCurrentTimeTool,
    ListDirectoryTool,
    ListPluginsTool,
    ParseDateTool,
    ReadFileTool,
    SearchDocumentsTool,
    WebSearchTool,
    WriteFileTool,
)
from .code_generator import (
    ToolCodeGenerator,
    generate_tool_code,
)
from .loader import (
    ToolLoader,
    ToolRegistry,
    get_tool_loader,
    reload_tools,
)
from .plugin_manager import (
    PluginInfo,
    PluginManager,
    get_plugin_manager,
)
from .registry import (
    BuiltinToolSource,
    LocalPluginSource,
    MCPToolSource,
    PipToolSource,
    PluginToolRegistry,
    ToolPackageInfo,
    ToolSource,
    get_plugin_registry,
    reload_plugin_registry,
)
from .validator import (
    ToolCodeValidator,
    ToolValidationResult,
    validate_tool_code,
)


# 从 agent_tools.py 导入旧版 API（延迟导入避免循环依赖）
def __getattr__(name):
    """延迟导入旧版 API"""
    if name in ("calculator", "search_documents", "get_default_tools", "create_default_tools", "ToolRegistry", "load_mcp_tools"):
        # 动态导入 - 使用相对导入避免 src 模块问题
        import importlib
        import sys
        # 将当前包路径添加到 sys.path 以便相对导入
        if __name__.startswith("src."):
            # 从 src.agent.tools 转换为 src.agent.agent_tools
            agent_tools = importlib.import_module(".agent_tools", package="src.agent")
        else:
            # 回退方案
            agent_tools = importlib.import_module("src.agent.agent_tools")
        return getattr(agent_tools, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


# 预导出新架构常用组件

__all__ = [
    # 基类
    "BaseTool",
    "ToolInput",
    "ToolOutput",
    "FunctionCallDefinition",
    "ToolCollection",
    # 适配器
    "ToolAdapter",
    "LangChainAdapter",
    "FunctionCallAdapter",
    "MCPAdapter",
    # 加载器
    "ToolLoader",
    "ToolRegistry",
    "get_tool_loader",
    "reload_tools",
    # 插件注册表
    "PluginToolRegistry",
    "ToolPackageInfo",
    "ToolSource",
    "BuiltinToolSource",
    "LocalPluginSource",
    "PipToolSource",
    "MCPToolSource",
    "get_plugin_registry",
    "reload_plugin_registry",
    # 内置工具
    "CalculatorTool",
    "SearchDocumentsTool",
    "WebSearchTool",
    "GetCurrentTimeTool",
    "ParseDateTool",
    "ReadFileTool",
    "WriteFileTool",
    "ListDirectoryTool",
    "FetchUrlTool",
    "ExecuteCommandTool",
    # 动态工具创建
    "CreateToolTool",
    "ListPluginsTool",
    "DeletePluginTool",
    # 代码生成和验证
    "ToolCodeGenerator",
    "ToolCodeValidator",
    "ToolValidationResult",
    # 插件管理
    "PluginManager",
    "get_plugin_manager",
]
