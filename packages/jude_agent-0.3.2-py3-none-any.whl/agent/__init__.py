"""Agent 模块

支持以下功能：
- RAG 问答功能
- 工具调用能力
- 多轮对话支持
- 记忆/上下文管理
"""

# 从 core 模块导入 Agent（新版本）
from core.agent import Agent

# 从 memory 模块导入
from .memory import generate_session_id

# 直接从 agent_tools.py 导入旧版 API
from .agent_tools import (
    # 兼容旧 API
    ToolRegistry,
    # LangChain 工具
    calculator,
    create_default_tools,
    get_default_tools,
    load_mcp_tools,
    search_documents,
)

# 从统一配置模块导入
from config.agent import (
    AgentConfig,
    AGENT_MODEL,
    AGENT_TEMPERATURE,
    ANTHROPIC_API_KEY,
    ANTHROPIC_BASE_URL,
    MAX_ITERATIONS,
    SHOW_THINKING,
    config,
)

__version__ = "0.2.0"

__all__ = [
    # Agent 核心
    "Agent",
    # 配置
    "config",
    "AGENT_MODEL",
    "AGENT_TEMPERATURE",
    "MAX_ITERATIONS",
    "SHOW_THINKING",
    "ANTHROPIC_API_KEY",
    "ANTHROPIC_BASE_URL",
    # LangChain 工具
    "calculator",
    "search_documents",
    "get_default_tools",
    # 兼容旧 API
    "ToolRegistry",
    "create_default_tools",
    "load_mcp_tools",
]
