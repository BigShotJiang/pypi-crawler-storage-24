"""Agent 核心模块

精简版的 Agent 编排器，仅负责流程控制
整合了 core 架构和 agent 高级功能
"""

import logging
import sys
from typing import Any, Dict, List, Optional

from langchain.agents import create_agent
from langchain.agents.middleware import ToolCallLimitMiddleware
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import HumanMessage
from langchain_core.runnables import Runnable


# ============================================================================
# 日志处理
# ============================================================================


class SafeStreamHandler(logging.StreamHandler):
    """安全的日志处理器，处理 Unicode 代理字符"""

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            safe_msg = msg.encode('utf-8', errors='replace').decode('utf-8')
            stream = self.stream
            stream.write(safe_msg + self.terminator)
            self.flush()
        except Exception:
            self.handleError(record)


# _setup_safe_logging() 在 agent/agent.py 中调用，避免重复日志
# 延迟导入避免循环依赖
# from .executor import ToolExecutor
from config import AgentConfig

# 事件系统
from events import (
    AgentEndEvent,
    AgentErrorEvent,
    AgentStartEvent,
    AgentToolCallEvent,
    AgentToolResultEvent,
    EventBus,
)

from .llm import LLMClient
from .memory import MemoryManager
from .middleware import DynamicToolMiddleware

logger = logging.getLogger("core.agent")


# ============================================================================
# 回调处理器
# ============================================================================


class ThinkingCallbackHandler(BaseCallbackHandler):
    """回调处理器：捕获 Agent 思考过程"""

    def __init__(self, thinking_store: List[str]):
        self.thinking_store = thinking_store

    def on_agent_action(self, action, **kwargs):
        """Agent 执行动作时调用（工具调用）"""
        tool_name = action.tool
        tool_input = action.tool_input

        thinking = f"🔧 调用工具: {tool_name}"
        if tool_input:
            input_str = str(tool_input)[:200]
            thinking += f"\n   输入: {input_str}"

        self.thinking_store.append(thinking)
        logger.debug(f"工具调用: {thinking}")

    def on_tool_end(self, output: str, **kwargs):
        """工具执行完成时调用"""
        if output:
            output_str = str(output)
            if "content=" in output_str:
                import re
                match = re.search(r"content='([^']+)'", output_str)
                if match:
                    output_str = match.group(1)

            output_str = output_str[:300]
            self.thinking_store.append(f"   → 结果: {output_str}")

    def on_agent_finish(self, finish, **kwargs):
        """Agent 完成时调用"""
        output = finish.return_values.get("output", "")
        if output:
            self.thinking_store.append(f"[完成] {str(output)[:200]}...")


class MiniMaxThinkingCallbackHandler(BaseCallbackHandler):
    """专门捕获 MiniMax thinking 字段的回调处理器"""

    def __init__(self, thinking_store: List[str]):
        self.thinking_store = thinking_store

    def on_llm_end(self, response, **kwargs):
        """LLM 调用结束"""
        if hasattr(response, "generations") and response.generations:
            for generation in response.generations[0]:
                if hasattr(generation, "message") and generation.message:
                    msg = generation.message
                    if isinstance(msg.content, list):
                        for item in msg.content:
                            if isinstance(item, dict) and item.get("type") == "thinking":
                                thinking_text = item.get("thinking", "")
                                if thinking_text:
                                    self.thinking_store.append(thinking_text)


# ============================================================================
# Agent 类
# ============================================================================


class Agent:
    """Agent 编排器（整合版）

    职责：
    - 流程编排
    - LLM 调用
    - 工具调度
    - 记忆管理

    整合了 core 架构和 agent 高级功能
    """

    def __init__(
        self,
        llm_client: LLMClient = None,
        memory_manager: MemoryManager = None,
        tool_executor=None,
        tools: List = None,
        max_iterations: int = None,
        show_thinking: bool = None,
        session_id: str = "default",
        enable_memory: bool = True,
        enable_mcp: bool = True,
        enable_multi_agent: bool = None,
        config: AgentConfig = None,
        event_bus: EventBus = None,
    ):
        """
        初始化 Agent

        Args:
            llm_client: LLM 客户端
            memory_manager: 记忆管理器
            tool_executor: 工具执行器（可选）
            tools: LangChain 工具列表
            max_iterations: 最大迭代次数
            show_thinking: 是否显示思考过程
            session_id: 会话 ID
            enable_memory: 是否启用记忆
            enable_mcp: 是否启用 MCP 工具
            enable_multi_agent: 是否启用 Multi-Agent 子 Agent
            config: 配置对象
            event_bus: 事件总线（可选，默认使用全局事件总线）
        """
        self._config = config or AgentConfig.from_env()

        # LLM 客户端
        self._llm_client = llm_client or LLMClient(config=self._config)

        # 事件总线
        self._event_bus = event_bus

        # 记忆管理器
        self._memory_manager = None
        self._enable_memory = enable_memory
        if enable_memory:
            self._memory_manager = memory_manager or MemoryManager(
                session_id=session_id,
                llm_client=self._llm_client,
                config=self._config,
            )

        # 工具列表（暂不使用 ToolExecutor）
        self._tools = tools or []

        # 配置
        self._max_iterations = max_iterations or self._config.max_iterations
        self._show_thinking = show_thinking if show_thinking is not None else self._config.show_thinking
        self._session_id = session_id
        self._enable_mcp = enable_mcp

        # Multi-Agent 配置
        self._enable_multi_agent = enable_multi_agent if enable_multi_agent is not None else self._config.enable_multi_agent
        self._multi_agent_registry = None
        self._multi_agent_tools = []
        if self._enable_multi_agent:
            self._init_multi_agent()

        # 内部状态
        self._agent: Optional[Runnable] = None
        self._last_tool_version = 0

        # 保存 tool_loader 引用，用于热更新
        from agent.tools.loader import get_tool_loader
        self._tool_loader = get_tool_loader()

        # Middleware 模式（默认启用动态工具加载）
        self._enable_mcp = enable_mcp

    def _init_multi_agent(self):
        """初始化 Multi-Agent 子 Agent"""
        import os
        from agent.multi_agent import SubAgentRegistry, SubAgentTool

        config_path = self._config.multi_agent_config_path
        if not config_path or not os.path.exists(config_path):
            logger.warning(f"Multi-Agent 配置不存在: {config_path}")
            return

        try:
            self._multi_agent_registry = SubAgentRegistry(config_path)
            # 为每个子 Agent 创建工具
            for agent_config in self._multi_agent_registry.list_agents():
                tool = SubAgentTool(agent_config)
                self._multi_agent_tools.append(tool)
            logger.info(f"已加载 {len(self._multi_agent_tools)} 个子 Agent 工具")
        except Exception as e:
            logger.error(f"加载 Multi-Agent 配置失败: {e}")

    @property
    def llm_client(self) -> LLMClient:
        """获取 LLM 客户端"""
        return self._llm_client

    @property
    def memory_manager(self) -> Optional[MemoryManager]:
        """获取记忆管理器"""
        return self._memory_manager

    @property
    def tool_executor(self):
        """获取工具列表"""
        return self._tools

    @property
    def session_id(self) -> str:
        """获取会话 ID"""
        return self._session_id

    @property
    def event_bus(self) -> EventBus:
        """获取事件总线"""
        return self._event_bus

    def _get_event_bus(self) -> EventBus:
        """获取事件总线（优先使用注入的，否则使用全局）"""
        if self._event_bus is not None:
            return self._event_bus
        from events.base import get_event_bus
        return get_event_bus()

    def _get_agent(self) -> Runnable:
        """获取 LangChain Agent

        使用 Middleware 动态加载工具，无需每次重新创建 agent
        """
        if self._agent is None:
            # 获取初始工具列表
            tools = self._tool_loader.get_langchain_tools()

            # 预加载 MCP 工具（只加载一次，避免每次 LLM 调用都重新加载）
            mcp_tools = []
            if self._enable_mcp:
                from agent.agent_tools import load_mcp_tools
                mcp_tools = load_mcp_tools(self._config.mcp_servers)
                tools.extend(mcp_tools)

            # 添加 Multi-Agent 子 Agent 工具
            if self._enable_multi_agent and self._multi_agent_tools:
                # 转换为 LangChain 工具
                for sub_agent_tool in self._multi_agent_tools:
                    lc_tool = sub_agent_tool.to_langchain_tool()
                    tools.append(lc_tool)
                logger.info(f"[Agent] 已添加 {len(self._multi_agent_tools)} 个子 Agent 工具")

            # 创建 Agent，添加动态工具 Middleware（传入预加载的 MCP 工具和子 Agent 工具）
            dynamic_middleware = DynamicToolMiddleware(
                self._tool_loader,
                mcp_tools=mcp_tools,
                multi_agent_tools=[t.to_langchain_tool() for t in self._multi_agent_tools],
            )

            self._agent = create_agent(
                model=self._llm_client.client,
                tools=tools,
                middleware=[
                    ToolCallLimitMiddleware(
                        thread_limit=self._max_iterations,
                        run_limit=self._max_iterations,
                    ),
                    dynamic_middleware,
                ],
            )
            logger.info(f"[Agent] 已创建 Agent（动态工具 Middleware 已启用）")

        return self._agent

    def _safe_log_string(self, s: str, max_len: int = 200) -> str:
        """安全地处理字符串用于日志输出"""
        if not s:
            return ""
        try:
            return s[:max_len].encode('utf-8', errors='replace').decode('utf-8')
        except Exception:
            return s[:max_len].encode('ascii', errors='replace').decode('ascii')

    def process(self, user_input: str) -> str:
        """
        处理用户输入

        Args:
            user_input: 用户输入

        Returns:
            Agent 响应
        """
        # 使用 LangChain Agent（动态工具 Middleware 已内置）
        result = self._process_core(user_input, include_thinking=self._show_thinking)

        if self._show_thinking:
            thinking = result.get("thinking", [])
            if thinking:
                thinking_text = "💭 **思考过程**\n" + "\n".join(thinking)
                return f"{thinking_text}\n\n---\n\n{result.get('response', '')}"

        return result.get("response", "")

    def process_with_thinking(self, user_input: str) -> Dict[str, Any]:
        """处理用户输入，返回思考过程"""
        return self._process_core(user_input, include_thinking=True)

    def _process_core(self, user_input: str, include_thinking: bool = False) -> Dict[str, Any]:
        """核心处理方法"""
        import time
        thinking_store: List[str] = []
        start_time = time.time()
        tool_calls_count = 0
        event_bus = self._get_event_bus()

        try:
            logger.info("=" * 60)
            logger.info(f"[收到用户消息] {self._safe_log_string(user_input)}...")
            logger.info("=" * 60)

            # 发布 Agent 启动事件
            event_bus.publish(AgentStartEvent(payload={
                "session_id": self._session_id,
                "user_input": user_input[:500] if user_input else "",
                "enable_memory": self._enable_memory,
            }))

            # 注意：工具版本检查已移至 DynamicToolMiddleware，
            # 每次 LLM 调用时自动获取最新工具列表

            # 添加用户消息到记忆
            if self._memory_manager:
                self._memory_manager.add_user_message(user_input)

            # 调用 Agent
            agent = self._get_agent()
            result = agent.invoke({
                "messages": [HumanMessage(content=user_input)]
            })

            # 处理响应
            messages = result.get("messages", [])
            if not messages:
                # 发布 Agent 结束事件（无响应）
                event_bus.publish(AgentEndEvent(payload={
                    "session_id": self._session_id,
                    "response": "无响应",
                    "duration_ms": (time.time() - start_time) * 1000,
                    "tool_calls_count": 0,
                }))
                return {"response": "无响应", "thinking": thinking_store}

            # 如果需要收集 thinking
            if include_thinking:
                for msg in messages:
                    msg_type = getattr(msg, "type", "unknown")

                    # 提取 LLM 的 thinking
                    if hasattr(msg, "content") and isinstance(msg.content, list):
                        for item in msg.content:
                            if isinstance(item, dict) and item.get("type") == "thinking":
                                thinking_text = item.get("thinking", "")
                                if thinking_text:
                                    thinking_store.append(thinking_text)

                    # 检查工具调用
                    if hasattr(msg, "tool_calls") and msg.tool_calls:
                        for tc in msg.tool_calls:
                            tool_calls_count += 1
                            tool_name = tc.get("name", "unknown")
                            tool_input = tc.get("args", {})
                            thinking_store.append(f"🔧 调用工具: {tool_name}")
                            if tool_input:
                                thinking_store.append(f"   输入: {str(tool_input)[:200]}")

                            # 发布工具调用事件
                            event_bus.publish(AgentToolCallEvent(payload={
                                "session_id": self._session_id,
                                "tool_name": tool_name,
                                "tool_input": tool_input,
                                "tool_call_id": tc.get("id", ""),
                            }))

                    # 检查工具结果
                    if msg_type == "tool":
                        tool_output = getattr(msg, "content", "")
                        output_str = str(tool_output)
                        if "content=" in output_str:
                            import re
                            match = re.search(r"content='([^']+)'", output_str)
                            if match:
                                output_str = match.group(1)
                        output_str = output_str[:300]
                        thinking_store.append(f"   → 结果: {output_str}")

                        # 发布工具结果事件
                        event_bus.publish(AgentToolResultEvent(payload={
                            "session_id": self._session_id,
                            "tool_name": getattr(msg, "name", "unknown"),
                            "tool_output": output_str[:500],
                            "tool_call_id": getattr(msg, "tool_call_id", ""),
                        }))

            # 提取响应内容
            last_message = messages[-1]
            content = last_message.content
            response_text = self._extract_text(content)

            # 添加助手响应到记忆
            if self._memory_manager:
                self._memory_manager.add_assistant_message(response_text)
                if self._memory_manager.should_summarize():
                    logger.info("[开始生成摘要]")
                    self._memory_manager.summarize()
                    logger.info("[摘要生成完成]")
                self._memory_manager.save()

            # 发布 Agent 结束事件
            event_bus.publish(AgentEndEvent(payload={
                "session_id": self._session_id,
                "response": response_text[:500] if response_text else "",
                "duration_ms": (time.time() - start_time) * 1000,
                "tool_calls_count": tool_calls_count,
                "thinking": thinking_store if include_thinking else [],
            }))

            return {
                "response": response_text,
                "thinking": thinking_store
            }

        except Exception as e:
            logger.error(f"Agent 执行错误: {e}", exc_info=True)

            # 发布 Agent 错误事件
            event_bus.publish(AgentErrorEvent(payload={
                "session_id": self._session_id,
                "error": str(e),
                "error_type": type(e).__name__,
                "user_input": user_input[:500] if user_input else "",
            }))

            return {"response": f"执行错误: {str(e)}", "thinking": thinking_store}

    def _extract_text(self, content: Any) -> str:
        """从消息内容中提取文本"""
        if isinstance(content, str):
            return content
        elif isinstance(content, list):
            text_parts = []
            for item in content:
                if isinstance(item, dict):
                    if item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
                elif isinstance(item, str):
                    text_parts.append(item)
            return "".join(text_parts)
        return str(content)

    def stream(self, user_input: str):
        """流式输出"""
        agent = self._get_agent()

        for event in agent.stream({
            "messages": [HumanMessage(content=user_input)]
        }):
            if "messages" in event:
                for message in event["messages"]:
                    if hasattr(message, "content") and message.content:
                        yield message.content

    def reset(self):
        """重置对话"""
        self._agent = None
        if self._memory_manager:
            self._memory_manager.clear_all()

    def refresh_tools(self):
        """刷新工具列表"""
        self._agent = None
        logger.info("[Agent] 工具列表已刷新")

    # ===== 记忆控制方法 =====

    def get_memory_stats(self) -> Dict[str, Any]:
        """获取记忆统计信息"""
        if not self._memory_manager:
            return {"enabled": False}
        return self._memory_manager.get_stats()

    def set_memory_enabled(self, enabled: bool):
        """启用/禁用记忆功能"""
        if enabled and not self._memory_manager:
            self._memory_manager = MemoryManager(
                session_id=self._session_id,
                llm_client=self._llm_client,
                config=self._config,
            )
        elif not enabled and self._memory_manager:
            self._memory_manager.clear_all()
            self._memory_manager = None
        self._enable_memory = enabled

    def force_summarize(self) -> str:
        """强制生成摘要"""
        if not self._memory_manager:
            return "记忆未启用"
        return self._memory_manager.summarize()

    def clear_memory(self):
        """清除记忆"""
        if self._memory_manager:
            self._memory_manager.clear_all()

    def __repr__(self) -> str:
        return f"<Agent(session_id={self._session_id}, memory={self._enable_memory})>"


# ============================================================================
# 便捷函数
# ============================================================================


def create_core_agent(
    session_id: str = "default",
    enable_rag: bool = True,
    enable_calculator: bool = True,
    **kwargs
) -> Agent:
    """创建 Agent 的便捷函数"""
    config = AgentConfig.from_env()

    # 添加工具
    tools = []
    if enable_calculator:
        from agent.agent_tools import calculator
        tools.append(calculator)
    if enable_rag:
        from agent.agent_tools import search_documents
        tools.append(search_documents)

    return Agent(
        session_id=session_id,
        tools=tools,
        config=config,
        **kwargs
    )
