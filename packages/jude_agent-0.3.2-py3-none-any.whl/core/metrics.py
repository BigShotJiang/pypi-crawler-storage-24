"""指标收集模块

提供系统性能指标收集功能
"""

import logging
import threading
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional

logger = logging.getLogger("core.metrics")


@dataclass
class MetricsCollector:
    """指标收集器

    线程安全的指标收集器，支持记录：
    - LLM 调用
    - 工具执行
    - RAG 查询
    - 网关请求
    """

    # LLM 指标
    _llm_calls: Dict[str, List[float]] = field(default_factory=lambda: defaultdict(list))
    _llm_success: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    _llm_failure: Dict[str, int] = field(default_factory=lambda: defaultdict(int))

    # 工具指标
    _tool_calls: Dict[str, List[float]] = field(default_factory=lambda: defaultdict(list))
    _tool_success: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    _tool_failure: Dict[str, int] = field(default_factory=lambda: defaultdict(int))

    # RAG 指标
    _rag_queries: List[float] = field(default_factory=list)
    _rag_results_count: List[int] = field(default_factory=list)

    # 网关指标
    _gateway_requests: Dict[str, List[float]] = field(default_factory=lambda: defaultdict(list))
    _gateway_status: Dict[str, Dict[int, int]] = field(default_factory=lambda: defaultdict(lambda: defaultdict(int)))

    # 锁
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def record_llm_call(self, duration: float, model: str, success: bool = True):
        """记录 LLM 调用

        Args:
            duration: 调用耗时（秒）
            model: 模型名称
            success: 是否成功
        """
        with self._lock:
            self._llm_calls[model].append(duration)
            if success:
                self._llm_success[model] += 1
            else:
                self._llm_failure[model] += 1

    def record_tool_execution(self, tool_name: str, duration: float, success: bool = True):
        """记录工具执行

        Args:
            tool_name: 工具名称
            duration: 执行耗时（秒）
            success: 是否成功
        """
        with self._lock:
            self._tool_calls[tool_name].append(duration)
            if success:
                self._tool_success[tool_name] += 1
            else:
                self._tool_failure[tool_name] += 1

    def record_rag_query(self, duration: float, results_count: int = 0):
        """记录 RAG 查询

        Args:
            duration: 查询耗时（秒）
            results_count: 返回结果数量
        """
        with self._lock:
            self._rag_queries.append(duration)
            self._rag_results_count.append(results_count)

    def record_gateway_request(self, endpoint: str, duration: float, status_code: int):
        """记录网关请求

        Args:
            endpoint: 端点路径
            duration: 请求耗时（秒）
            status_code: HTTP 状态码
        """
        with self._lock:
            self._gateway_requests[endpoint].append(duration)
            self._gateway_status[endpoint][status_code] += 1

    def get_stats(self) -> dict:
        """获取统计信息

        Returns:
            包含所有指标的字典
        """
        with self._lock:
            stats = {
                "timestamp": datetime.now().isoformat(),
                "llm": self._compute_llm_stats(),
                "tools": self._compute_tool_stats(),
                "rag": self._compute_rag_stats(),
                "gateway": self._compute_gateway_stats(),
            }
        return stats

    def _compute_llm_stats(self) -> dict:
        """计算 LLM 统计信息"""
        result = {}
        for model, durations in self._llm_calls.items():
            if durations:
                result[model] = {
                    "calls": len(durations),
                    "success": self._llm_success.get(model, 0),
                    "failure": self._llm_failure.get(model, 0),
                    "avg_duration": sum(durations) / len(durations),
                    "min_duration": min(durations),
                    "max_duration": max(durations),
                }
        return result

    def _compute_tool_stats(self) -> dict:
        """计算工具统计信息"""
        result = {}
        for tool_name, durations in self._tool_calls.items():
            if durations:
                result[tool_name] = {
                    "calls": len(durations),
                    "success": self._tool_success.get(tool_name, 0),
                    "failure": self._tool_failure.get(tool_name, 0),
                    "avg_duration": sum(durations) / len(durations),
                    "min_duration": min(durations),
                    "max_duration": max(durations),
                }
        return result

    def _compute_rag_stats(self) -> dict:
        """计算 RAG 统计信息"""
        if not self._rag_queries:
            return {}

        return {
            "queries": len(self._rag_queries),
            "avg_duration": sum(self._rag_queries) / len(self._rag_queries),
            "min_duration": min(self._rag_queries),
            "max_duration": max(self._rag_queries),
            "total_results": sum(self._rag_results_count),
            "avg_results": sum(self._rag_results_count) / len(self._rag_results_count) if self._rag_results_count else 0,
        }

    def _compute_gateway_stats(self) -> dict:
        """计算网关统计信息"""
        result = {}
        for endpoint, durations in self._gateway_requests.items():
            if durations:
                status_codes = self._gateway_status.get(endpoint, {})
                result[endpoint] = {
                    "requests": len(durations),
                    "avg_duration": sum(durations) / len(durations),
                    "min_duration": min(durations),
                    "max_duration": max(durations),
                    "status_codes": dict(status_codes),
                }
        return result

    def reset(self):
        """重置所有统计"""
        with self._lock:
            self._llm_calls.clear()
            self._llm_success.clear()
            self._llm_failure.clear()
            self._tool_calls.clear()
            self._tool_success.clear()
            self._tool_failure.clear()
            self._rag_queries.clear()
            self._rag_results_count.clear()
            self._gateway_requests.clear()
            self._gateway_status.clear()


# ============================================================================
# 全局单例
# ============================================================================

_default_collector: Optional[MetricsCollector] = None


def get_metrics_collector() -> MetricsCollector:
    """获取默认的指标收集器（单例）"""
    global _default_collector
    if _default_collector is None:
        _default_collector = MetricsCollector()
    return _default_collector
