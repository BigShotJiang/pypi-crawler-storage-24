"""记忆管理模块

封装对话记忆管理功能
"""

import logging
from typing import Any, Dict, List, Optional

# 延迟导入避免循环依赖
from config import AgentConfig

logger = logging.getLogger("core.memory")


class MemoryManager:
    """记忆管理器

    封装 ConversationMemory，提供更简洁的接口
    """

    def __init__(
        self,
        session_id: str = "default",
        max_messages: int = None,
        summary_threshold: int = None,
        db_path: str = None,
        llm_client=None,
        config: AgentConfig = None,
    ):
        """
        初始化记忆管理器

        Args:
            session_id: 会话 ID
            max_messages: 最大消息数
            summary_threshold: 摘要阈值
            db_path: 数据库路径
            llm_client: LLM 客户端（可选）
            config: AgentConfig 配置（可选）
        """
        self._config = config or AgentConfig.from_env()
        self._session_id = session_id

        # 从配置或参数获取设置
        self._max_messages = max_messages or self._config.memory_max_messages
        self._summary_threshold = summary_threshold or self._config.memory_summary_threshold
        self._db_path = db_path

        # LLM 客户端（可选）
        self._llm_client = llm_client

        # 延迟导入避免循环依赖
        from ..memory import ConversationMemory as CM

        # 创建底层 ConversationMemory
        self._memory = CM(
            session_id=session_id,
            max_messages=self._max_messages,
            summary_threshold=self._summary_threshold,
            db_path=db_path,
            llm=llm_client.client if llm_client else None,
        )

        # 加载已有记忆
        self._memory.load(session_id)

    @property
    def memory(self):
        """获取底层 ConversationMemory"""
        return self._memory

    @property
    def session_id(self) -> str:
        """获取当前会话 ID"""
        return self._session_id

    def add_user_message(self, content: str):
        """添加用户消息"""
        self._memory.add_user_message(content)

    def add_assistant_message(self, content: str):
        """添加助手消息"""
        self._memory.add_assistant_message(content)

    def add_message(self, role: str, content: str):
        """添加消息（通用方法）"""
        if role == "user":
            self._memory.add_user_message(content)
        elif role == "assistant":
            self._memory.add_assistant_message(content)
        elif role == "system":
            self._memory.add_system_message(content)

    def get_messages(self, n: int = None) -> List[Dict[str, Any]]:
        """获取最近 n 条消息"""
        return self._memory.get_messages_for_context()

    def should_summarize(self) -> bool:
        """是否应该进行摘要"""
        return self._memory.should_summarize()

    def summarize(self) -> str:
        """生成摘要"""
        return self._memory.summarize()

    def save(self, **kwargs):
        """保存记忆"""
        self._memory.save(**kwargs)

    def load(self, session_id: str = None):
        """加载记忆"""
        self._memory.load(session_id or self._session_id)

    def clear(self):
        """清空内存中的记忆"""
        self._memory.clear()

    def clear_all(self):
        """清空所有记忆（包括持久化）"""
        self._memory.clear_all()

    def get_stats(self) -> Dict[str, Any]:
        """获取记忆统计"""
        return {
            "session_id": self._session_id,
            "message_count": len(self._memory.messages),
            "has_summary": self._memory.summary is not None,
            "summary_length": len(self._memory.summary) if self._memory.summary else 0,
        }

    def switch_session(self, session_id: str, **kwargs):
        """切换会话"""
        from ..memory import ConversationMemory as CM

        self._session_id = session_id
        self._memory = CM(
            session_id=session_id,
            max_messages=self._max_messages,
            summary_threshold=self._summary_threshold,
            db_path=self._db_path,
            llm=self._llm_client.client if self._llm_client else None,
        )
        self._memory.load(session_id)
        if kwargs:
            self._memory.save(**kwargs)

    @staticmethod
    def find_session(directory: str = None, user_id: str = None, chat_id: str = None) -> Optional[str]:
        """查找现有会话"""
        from ..memory import ConversationMemory as CM

        if directory:
            return CM.find_session_by_directory(directory)
        elif user_id:
            return CM.find_session_by_user_id(user_id)
        elif chat_id:
            return CM.find_session_by_chat_id(chat_id)
        return None

    @staticmethod
    def get_or_create_session(
        source: str,
        directory: str = None,
        user_id: str = None,
        chat_id: str = None,
    ) -> tuple:
        """获取或创建会话"""
        from ..memory import ConversationMemory as CM

        return CM.get_or_create_session(
            source=source,
            directory=directory,
            user_id=user_id,
            chat_id=chat_id,
        )

    def __repr__(self) -> str:
        return f"<MemoryManager(session_id={self._session_id}, messages={len(self._memory)})>"
