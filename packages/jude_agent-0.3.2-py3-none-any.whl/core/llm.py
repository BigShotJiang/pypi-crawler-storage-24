"""LLM 客户端模块

封装 LLM 调用，支持多种 LLM Provider
"""

import logging
import time
from typing import Any, Dict, List, Optional, Union

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage

from config import AgentConfig
from core.cache import LLMCache, get_llm_cache
from core.exceptions import LLMRateLimitError
from core.metrics import get_metrics_collector
from core.retry import RetryConfig

logger = logging.getLogger("core.llm")

# LLM 重试配置
LLM_RETRY_CONFIG = RetryConfig(
    max_attempts=3,
    base_delay=1.0,
    exponential_base=2.0,
    max_delay=30.0,
    retryable_exceptions=(LLMRateLimitError, Exception),
)


class LLMClient:
    """LLM 客户端封装

    支持：
    - 多种 LLM Provider（Anthropic/MiniMax 等）
    - 流式输出
    - 配置化
    - 缓存支持
    - 指标收集
    """

    def __init__(
        self,
        model: str = None,
        temperature: float = None,
        api_key: str = None,
        base_url: str = None,
        config: AgentConfig = None,
        cache: LLMCache = None,
        enable_cache: bool = True,
    ):
        """
        初始化 LLM 客户端

        Args:
            model: 模型名称
            temperature: 温度参数
            api_key: API 密钥
            base_url: API 基础 URL
            config: AgentConfig 配置对象（可选）
            cache: LLM 缓存实例（可选）
            enable_cache: 是否启用缓存（默认启用）
        """
        self._config = config or AgentConfig.from_env()

        self._model = model or self._config.agent_model
        self._temperature = temperature if temperature is not None else self._config.temperature
        self._api_key = api_key or self._config.anthropic_api_key
        self._base_url = base_url or self._config.anthropic_base_url

        self._client: Optional[ChatAnthropic] = None

        # 缓存和指标收集
        self._cache = cache
        self._enable_cache = enable_cache

    @property
    def cache(self) -> LLMCache:
        """获取缓存实例"""
        if self._cache is None and self._enable_cache:
            self._cache = get_llm_cache()
        return self._cache

    @property
    def client(self) -> ChatAnthropic:
        """获取 LLM 客户端实例"""
        if self._client is None:
            self._client = self._create_client()
        return self._client

    def _create_client(self) -> ChatAnthropic:
        """创建 LLM 客户端"""
        return ChatAnthropic(
            model=self._model,
            temperature=self._temperature,
            anthropic_api_key=self._api_key,
            base_url=self._base_url,
        )

    def invoke(
        self,
        messages: Union[str, List[Dict[str, str]], List[BaseMessage]],
        **kwargs
    ) -> BaseMessage:
        """
        同步调用 LLM（带重试机制和缓存）

        Args:
            messages: 消息列表或单个消息字符串
            **kwargs: 其他参数

        Returns:
            LLM 响应消息
        """
        # 获取指标收集器
        metrics = get_metrics_collector()
        start_time = time.time()

        # 尝试从缓存获取
        cached_response = None
        if self._enable_cache and self.cache:
            cache_key = self.cache._make_key(
                messages=messages,
                model=self._model,
                temperature=self._temperature,
                **kwargs
            )
            cached_response = self.cache.get(cache_key)

        if cached_response is not None:
            # 缓存命中
            duration = time.time() - start_time
            metrics.record_llm_call(duration, self._model, success=True)
            logger.debug(f"[LLM] 缓存命中: {self._model}")
            # 从缓存恢复响应（需要重新构造消息对象）
            # 这里返回缓存的字符串内容，重新构造 AIMessage
            return AIMessage(content=cached_response)

        # 缓存未命中，调用 LLM
        formatted_messages = self._format_messages(messages)
        last_exception = None
        success = False

        for attempt in range(1, LLM_RETRY_CONFIG.max_attempts + 1):
            try:
                logger.debug(f"[LLM] 调用模型: {self._model} (尝试 {attempt}/{LLM_RETRY_CONFIG.max_attempts})")
                response = self.client.invoke(formatted_messages, **kwargs)
                logger.debug(f"[LLM] 响应: {response.content[:100] if hasattr(response, 'content') else '...'}...")

                # 记录指标
                duration = time.time() - start_time
                metrics.record_llm_call(duration, self._model, success=True)
                success = True

                # 存入缓存
                if self._enable_cache and self.cache and hasattr(response, 'content'):
                    self.cache.set(cache_key, response.content)

                return response

            except Exception as e:
                last_exception = e
                error_msg = str(e).lower()

                # 检测速率限制
                is_rate_limit = any(
                    keyword in error_msg
                    for keyword in ["rate_limit", "rate limit", "too many requests", "429"]
                )

                if is_rate_limit:
                    logger.warning(f"[LLM] 检测到速率限制: {e}")
                    # 记录失败指标
                    duration = time.time() - start_time
                    metrics.record_llm_call(duration, self._model, success=False)
                    raise LLMRateLimitError(str(e)) from e

                # 如果是最后一次尝试，记录失败并抛出
                if attempt >= LLM_RETRY_CONFIG.max_attempts:
                    logger.error(f"[LLM] 达到最大重试次数 ({LLM_RETRY_CONFIG.max_attempts}), 错误: {e}")
                    # 记录失败指标
                    duration = time.time() - start_time
                    metrics.record_llm_call(duration, self._model, success=False)
                    break

                # 计算延迟时间
                delay = LLM_RETRY_CONFIG.calculate_delay(attempt)
                logger.warning(f"[LLM] 第 {attempt}/{LLM_RETRY_CONFIG.max_attempts} 次尝试失败: {e}, {delay:.1f}秒后重试...")

                time.sleep(delay)

        # 所有重试都失败
        raise last_exception

    def stream(
        self,
        messages: Union[str, List[Dict[str, str]], List[BaseMessage]],
        **kwargs
    ) -> Any:
        """
        流式调用 LLM（带重试机制）

        注意：流式调用目前不支持缓存

        Args:
            messages: 消息列表或单个消息字符串
            **kwargs: 其他参数

        Returns:
            流式响应迭代器
        """
        # 获取指标收集器
        metrics = get_metrics_collector()
        start_time = time.time()

        # 流式调用目前不支持完整重试，因为流已经开始了
        # 这里的重试主要用于处理连接错误
        formatted_messages = self._format_messages(messages)

        try:
            logger.debug(f"[LLM] 流式调用模型: {self._model}")
            response = self.client.stream(formatted_messages, **kwargs)

            # 记录指标（流式调用在完成后记录）
            return response

        except Exception as e:
            # 记录失败指标
            duration = time.time() - start_time
            metrics.record_llm_call(duration, self._model, success=False)

            error_msg = str(e).lower()
            is_rate_limit = any(
                keyword in error_msg
                for keyword in ["rate_limit", "rate limit", "too many requests", "429"]
            )
            if is_rate_limit:
                raise LLMRateLimitError(str(e)) from e
            raise

    def _format_messages(
        self,
        messages: Union[str, List[Dict[str, str]], List[BaseMessage]]
    ) -> List[BaseMessage]:
        """格式化消息为 LangChain 格式"""
        if isinstance(messages, str):
            # 单个字符串视为用户消息
            return [HumanMessage(content=messages)]

        if isinstance(messages, list) and messages:
            # 检查是否已经是 BaseMessage 列表
            if isinstance(messages[0], BaseMessage):
                return messages

            # 转换为 BaseMessage
            result = []
            for msg in messages:
                if isinstance(msg, dict):
                    role = msg.get("role", "user")
                    content = msg.get("content", "")

                    if role == "user":
                        result.append(HumanMessage(content=content))
                    elif role == "assistant":
                        result.append(AIMessage(content=content))
                    elif role == "system":
                        result.append(SystemMessage(content=content))
                    else:
                        result.append(HumanMessage(content=content))
                else:
                    result.append(msg)
            return result

        return [HumanMessage(content=str(messages))]

    def update_config(self, **kwargs):
        """更新配置"""
        for key, value in kwargs.items():
            if hasattr(self, f"_{key}"):
                setattr(self, f"_{key}", value)
        # 重置客户端，强制重建
        self._client = None

    @property
    def model(self) -> str:
        """获取当前模型"""
        return self._model

    def __repr__(self) -> str:
        return f"<LLMClient(model={self._model}, temperature={self._temperature})>"


# ============================================================================
# 便捷函数
# ============================================================================


def create_llm_client(
    model: str = None,
    temperature: float = None,
    **kwargs
) -> LLMClient:
    """创建 LLM 客户端的便捷函数"""
    return LLMClient(
        model=model,
        temperature=temperature,
        **kwargs
    )
