"""Core 模块异常定义

定义项目中使用的自定义异常类
"""


class AgentError(Exception):
    """基础 Agent 异常"""

    pass


class LLMRateLimitError(AgentError):
    """LLM 速率限制异常

    当 LLM API 返回速率限制错误时抛出
    """

    def __init__(self, message: str = "LLM API 速率限制", retry_after: int = None):
        super().__init__(message)
        self.retry_after = retry_after


class ToolExecutionError(AgentError):
    """工具执行异常

    当工具执行失败时抛出
    """

    def __init__(self, message: str = "工具执行失败", tool_name: str = None):
        super().__init__(message)
        self.tool_name = tool_name


class VectorStoreError(AgentError):
    """向量存储异常

    当向量存储操作失败时抛出
    """

    pass


class ConfigurationError(AgentError):
    """配置异常

    当配置错误或缺失时抛出
    """

    pass


class ChannelError(AgentError):
    """渠道异常

    当渠道通信失败时抛出
    """

    pass


class RAGError(AgentError):
    """RAG 服务异常

    当 RAG 服务操作失败时抛出
    """

    pass
