"""工具执行器模块

封装工具执行逻辑
"""

import logging
from typing import Any, Callable, Dict, List, Optional

# 延迟导入避免循环依赖
from agent.tools.base import BaseTool, ToolOutput

logger = logging.getLogger("core.executor")


class ToolExecutor:
    """工具执行器

    负责：
    - 工具注册和查找
    - 工具执行
    - 结果格式化
    """

    def __init__(self):
        """初始化工具执行器"""
        self._tools: Dict[str, BaseTool] = {}
        self._tool_functions: Dict[str, Callable] = {}

    def register_tool(self, tool: BaseTool):
        """注册 BaseTool"""
        self._tools[tool.name] = tool
        logger.debug(f"[ToolExecutor] 注册工具: {tool.name}")

    def register_function(self, name: str, func: Callable, description: str = ""):
        """注册普通函数为工具"""
        self._tool_functions[name] = func
        logger.debug(f"[ToolExecutor] 注册函数: {name}")

    def get_tool(self, name: str) -> Optional[BaseTool]:
        """获取工具"""
        return self._tools.get(name)

    def get_function(self, name: str) -> Optional[Callable]:
        """获取函数"""
        return self._tool_functions.get(name)

    def has_tool(self, name: str) -> bool:
        """检查工具是否存在"""
        return name in self._tools or name in self._tool_functions

    def list_tools(self) -> List[str]:
        """列出所有工具名称"""
        return list(self._tools.keys()) + list(self._tool_functions.keys())

    def execute(self, tool_name: str, parameters: Dict[str, Any] = None, context: Dict = None) -> Any:
        """
        执行工具

        Args:
            tool_name: 工具名称
            parameters: 工具参数
            context: 执行上下文

        Returns:
            工具执行结果
        """
        parameters = parameters or {}

        # 先尝试 BaseTool
        tool = self._tools.get(tool_name)
        if tool:
            try:
                logger.info(f"[ToolExecutor] 执行工具: {tool_name}, 参数: {parameters}")
                output = tool.execute(parameters, context)
                if output.success:
                    return output.result
                else:
                    logger.error(f"[ToolExecutor] 工具执行失败: {output.error}")
                    return f"错误: {output.error}"
            except Exception as e:
                logger.error(f"[ToolExecutor] 工具执行异常: {e}", exc_info=True)
                return f"执行错误: {str(e)}"

        # 再尝试普通函数
        func = self._tool_functions.get(tool_name)
        if func:
            try:
                logger.info(f"[ToolExecutor] 执行函数: {tool_name}, 参数: {parameters}")
                return func(**parameters)
            except TypeError:
                # 参数不匹配，尝试不传参数
                try:
                    return func(parameters)
                except Exception as e2:
                    logger.error(f"[ToolExecutor] 函数执行失败: {e2}")
                    return f"执行错误: {str(e2)}"
            except Exception as e:
                logger.error(f"[ToolExecutor] 函数执行异常: {e}", exc_info=True)
                return f"执行错误: {str(e)}"

        # 工具不存在
        logger.warning(f"[ToolExecutor] 工具不存在: {tool_name}")
        return f"工具不存在: {tool_name}"

    def execute_tool_call(self, tool_call: Dict[str, Any]) -> Any:
        """
        执行工具调用（兼容 LangChain 格式）

        Args:
            tool_call: 工具调用描述，包含 name 和 args

        Returns:
            执行结果
        """
        tool_name = tool_call.get("name", "")
        tool_args = tool_call.get("args", {})

        # 处理参数格式
        if isinstance(tool_args, str):
            # 尝试解析 JSON
            import json
            try:
                tool_args = json.loads(tool_args)
            except json.JSONDecodeError:
                tool_args = {"input": tool_args}

        return self.execute(tool_name, tool_args)

    def add_tools_from_collection(self, tool_collection):
        """从工具集合添加工具"""
        for tool in tool_collection.list_tools():
            self.register_tool(tool)

    def add_langchain_tools(self, tools: List):
        """从 LangChain 工具添加工具"""
        for tool in tools:
            # LangChain @tool 装饰器创建的函数
            if hasattr(tool, "name") and hasattr(tool, "func"):
                # 包装为 BaseTool

                from src.agent.tools.base import BaseTool

                class WrappedTool(BaseTool):
                    name = tool.name
                    description = tool.description or ""
                    input_schema = {}

                    def execute(self, parameters, context=None):
                        try:
                            result = tool.func(**parameters)
                            return ToolOutput(success=True, result=result)
                        except Exception as e:
                            return ToolOutput(success=False, result=None, error=str(e))

                self.register_tool(WrappedTool())

    def __repr__(self) -> str:
        return f"<ToolExecutor(tools={len(self._tools)}, functions={len(self._tool_functions)})>"
