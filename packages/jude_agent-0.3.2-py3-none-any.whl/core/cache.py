"""缓存模块

提供 LLM 响应缓存功能，支持 LRU 淘汰和 TTL 过期
"""

import hashlib
import json
import logging
import threading
import time
from collections import OrderedDict
from typing import Any, Optional

logger = logging.getLogger("core.cache")


class LLMCache:
    """LLM 响应缓存

    特性：
    - LRU（最近最少使用）淘汰机制
    - TTL（生存时间）过期
    - 基于请求参数的键生成
    - 线程安全
    """

    def __init__(self, max_size: int = 1000, ttl: int = 3600):
        """初始化缓存

        Args:
            max_size: 最大缓存条目数
            ttl: 默认生存时间（秒）
        """
        self._cache: OrderedDict[str, tuple] = OrderedDict()
        self._max_size = max_size
        self._ttl = ttl
        self._lock = threading.Lock()

        # 统计信息
        self._hits = 0
        self._misses = 0

    def _make_key(
        self,
        messages: Any,
        model: str,
        temperature: float = 0.7,
        **kwargs
    ) -> str:
        """生成缓存键

        将请求参数序列化为字符串后计算 MD5 哈希

        Args:
            messages: 消息内容
            model: 模型名称
            temperature: 温度参数
            **kwargs: 其他参数

        Returns:
            缓存键（MD5 哈希字符串）
        """
        # 构建包含所有参数的字典
        key_data = {
            "messages": self._serialize_messages(messages),
            "model": model,
            "temperature": temperature,
        }

        # 添加其他参数
        for k, v in sorted(kwargs.items()):
            # 排除不适合缓存的参数
            if k not in ("callbacks", "config", "metadata"):
                key_data[k] = v

        # 序列化为 JSON
        try:
            serialized = json.dumps(key_data, sort_keys=True, ensure_ascii=False)
        except (TypeError, ValueError):
            # 如果序列化失败，使用字符串表示
            serialized = str(key_data)

        # 计算哈希
        return hashlib.md5(serialized.encode("utf-8")).hexdigest()

    def _serialize_messages(self, messages: Any) -> Any:
        """序列化消息为可缓存的格式

        Args:
            messages: 原始消息

        Returns:
            可序列化的消息
        """
        if isinstance(messages, str):
            return messages

        if isinstance(messages, list):
            result = []
            for msg in messages:
                if hasattr(msg, "content"):
                    # BaseMessage 对象
                    result.append({
                        "type": type(msg).__name__,
                        "content": msg.content,
                    })
                elif isinstance(msg, dict):
                    result.append(msg)
                else:
                    result.append(str(msg))
            return result

        return str(messages)

    def get(self, key: str) -> Optional[str]:
        """获取缓存

        Args:
            key: 缓存键

        Returns:
            缓存值，如果不存在或已过期返回 None
        """
        with self._lock:
            if key not in self._cache:
                self._misses += 1
                return None

            # 获取缓存值和过期时间
            value, expire_at = self._cache[key]

            # 检查是否过期
            if expire_at and time.time() > expire_at:
                # 已过期，删除
                del self._cache[key]
                self._misses += 1
                return None

            # LRU: 移动到末尾（最近使用）
            self._cache.move_to_end(key)

            self._hits += 1
            return value

    def set(
        self,
        key: str,
        value: str,
        ttl: Optional[int] = None
    ):
        """设置缓存

        Args:
            key: 缓存键
            value: 缓存值
            ttl: 生存时间（秒），使用默认值
        """
        with self._lock:
            # 如果键已存在，先删除
            if key in self._cache:
                del self._cache[key]

            # 计算过期时间
            expire_at = time.time() + (ttl if ttl is not None else self._ttl)

            # 添加到缓存
            self._cache[key] = (value, expire_at)

            # LRU 淘汰：如果超过最大 size，删除最旧的
            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)

    def clear(self):
        """清空缓存"""
        with self._lock:
            self._cache.clear()
            self._hits = 0
            self._misses = 0

    def stats(self) -> dict:
        """获取缓存统计信息

        Returns:
            包含缓存命中、未命中、容量等信息的字典
        """
        with self._lock:
            total = self._hits + self._misses
            hit_rate = self._hits / total if total > 0 else 0.0

            return {
                "size": len(self._cache),
                "max_size": self._max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": hit_rate,
                "ttl": self._ttl,
            }

    def __len__(self) -> int:
        """返回缓存条目数"""
        return len(self._cache)


# ============================================================================
# 全局单例
# ============================================================================

_default_cache: Optional[LLMCache] = None


def get_llm_cache() -> LLMCache:
    """获取默认的 LLM 缓存（单例）"""
    global _default_cache
    if _default_cache is None:
        _default_cache = LLMCache()
    return _default_cache
