"""重试机制模块

提供基于指数退避的重试装饰器
"""

import logging
import time
from dataclasses import dataclass
from functools import wraps
from typing import Callable, Tuple, Type

logger = logging.getLogger("core.retry")


@dataclass
class RetryConfig:
    """重试配置

    Attributes:
        max_attempts: 最大尝试次数
        base_delay: 基础延迟时间（秒）
        exponential_base: 指数退避基数
        max_delay: 最大延迟时间（秒）
        retryable_exceptions: 可重试的异常类型元组
    """

    max_attempts: int = 3
    base_delay: float = 1.0
    exponential_base: float = 2.0
    max_delay: float = 30.0
    retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,)

    def calculate_delay(self, attempt: int) -> float:
        """计算延迟时间

        使用指数退避策略

        Args:
            attempt: 当前尝试次数（从 1 开始）

        Returns:
            延迟时间（秒）
        """
        delay = self.base_delay * (self.exponential_base ** (attempt - 1))
        return min(delay, self.max_delay)


def with_retry(config: RetryConfig = None):
    """重试装饰器

    使用指数退避策略进行重试

    Args:
        config: RetryConfig 配置对象

    Returns:
        装饰器函数

    Example:
        @with_retry(RetryConfig(max_attempts=3, base_delay=1.0))
        def call_api():
            return api.request()

        # 或者使用默认配置
        @with_retry()
        def call_api():
            return api.request()
    """
    if config is None:
        config = RetryConfig()

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None

            for attempt in range(1, config.max_attempts + 1):
                try:
                    return func(*args, **kwargs)

                except config.retryable_exceptions as e:
                    last_exception = e

                    # 如果是最后一次尝试，记录失败并抛出异常
                    if attempt >= config.max_attempts:
                        logger.error(
                            f"[{func.__name__}] 达到最大重试次数 ({config.max_attempts}), "
                            f"最终错误: {e}"
                        )
                        break

                    # 计算延迟时间
                    delay = config.calculate_delay(attempt)
                    logger.warning(
                        f"[{func.__name__}] 第 {attempt}/{config.max_attempts} 次尝试失败: {e}, "
                        f"{delay:.1f}秒后重试..."
                    )
                    time.sleep(delay)

            # 所有重试都失败，抛出最后一个异常
            raise last_exception

        return wrapper

    return decorator


# ============================================================================
# 便捷函数
# ============================================================================


def retry_on_exception(
    func: Callable = None,
    *,
    max_attempts: int = 3,
    base_delay: float = 1.0,
    exceptions: Tuple[Type[Exception], ...] = (Exception,),
) -> Callable:
    """便捷的重试装饰器

    Args:
        func: 被装饰的函数
        max_attempts: 最大尝试次数
        base_delay: 基础延迟时间
        exceptions: 可重试的异常类型

    Returns:
        装饰后的函数

    Example:
        @retry_on_exception(max_attempts=5, base_delay=2.0)
        def unreliable_operation():
            ...
    """
    config = RetryConfig(
        max_attempts=max_attempts,
        base_delay=base_delay,
        retryable_exceptions=exceptions,
    )
    return with_retry(config)(func)
