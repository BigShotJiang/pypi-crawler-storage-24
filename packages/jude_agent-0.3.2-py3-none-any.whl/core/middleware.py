"""LangChain v1 动态工具 Middleware

特点：
- 每次 LLM 调用时从 ToolLoader 获取最新工具列表
- 支持动态创建工具后立即使用
- 处理动态工具调用
"""

import logging
from typing import Any, Callable, Dict, List, Optional

from langchain.agents.middleware import AgentMiddleware
from langchain.agents.middleware.types import ModelRequest, ModelResponse, ModelCallResult, ToolCallRequest

logger = logging.getLogger("core.middleware")


class DynamicToolMiddleware(AgentMiddleware):
    """动态工具加载 Middleware

    每次 LLM 调用时从 ToolLoader 获取最新工具列表，
    实现动态工具创建后立即使用的功能。
    """

    def __init__(self, tool_loader, mcp_tools: List = None, multi_agent_tools: List = None):
        """初始化 Middleware

        Args:
            tool_loader: 工具加载器实例（ToolLoader）
            mcp_tools: 预加载的 MCP 工具列表（避免每次都重新加载）
            multi_agent_tools: Multi-Agent 子 Agent 工具列表
        """
        self.tool_loader = tool_loader
        self._mcp_tools = mcp_tools or []
        self._multi_agent_tools = multi_agent_tools or []

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelCallResult],
    ) -> ModelCallResult:
        """拦截 LLM 调用，动态更新工具列表

        Args:
            request: 原始请求（包含工具列表）
            handler: 处理请求的回调函数

        Returns:
            ModelCallResult: LLM 响应结果
        """
        # 检查是否需要强制刷新工具缓存
        # 当 _tool_version 为 0 时，表示有新的动态工具被创建
        tool_version = getattr(self.tool_loader, '_tool_version', -1)
        if tool_version == 0:
            # 清空缓存，强制重新生成工具列表
            self.tool_loader._langchain_tools = []
            logger.debug("[DynamicToolMiddleware] 检测到工具版本变更，清空缓存")

        # 每次都获取最新工具列表（支持动态添加工具）
        tools = self._get_latest_tools()

        # 动态更新工具列表
        updated_request = request.override(tools=tools)

        logger.debug(f"[DynamicToolMiddleware] 动态加载 {len(tools)} 个工具")

        return handler(updated_request)

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Any],
    ) -> Any:
        """拦截工具调用，执行动态添加工具

        当 Agent 不知道如何执行某个工具时，尝试从 loader 中获取并执行
        """
        tool_name = request.tool_call.get("name", "")

        # 尝试获取动态工具
        tool = self._get_dynamic_tool(tool_name)
        if tool:
            # 替换为动态工具并执行
            logger.debug(f"[DynamicToolMiddleware] 执行动态工具: {tool_name}")
            updated_request = request.override(tool=tool)
            return handler(updated_request)

        # 如果不是动态工具，交给原始 handler 处理
        return handler(request)

    def _get_dynamic_tool(self, tool_name: str):
        """获取动态工具实例

        Args:
            tool_name: 工具名称

        Returns:
            LangChain 工具实例，如果不存在则返回 None
        """
        # 从 loader 的工具字典中获取
        tools_dict = self.tool_loader._tools
        if tool_name in tools_dict:
            return tools_dict[tool_name].to_langchain_tool()
        return None

    def _get_latest_tools(self) -> List:
        """获取最新的工具列表

        Returns:
            LangChain 工具列表
        """
        # 从 loader 获取最新工具
        tools = self.tool_loader.get_langchain_tools()

        # 使用预加载的 MCP 工具（避免每次都重新加载）
        tools.extend(self._mcp_tools)

        # 添加 Multi-Agent 子 Agent 工具
        tools.extend(self._multi_agent_tools)

        return tools
