"""工具配置模块

工具系统配置：
- 内置工具启用/禁用
- MCP 服务器配置
- 工具加载器配置
"""

import os
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional

from . import get_project_root, load_yaml_config


@dataclass
class ToolConfig:
    """工具配置"""

    # 内置工具启用/禁用
    enable_rag: bool = True
    enable_calculator: bool = True

    # MCP 配置
    mcp_servers: Dict[str, Any] = field(default_factory=dict)
    mcp_config_path: str = ""

    # 工具配置文件路径
    tools_config_path: str = ""

    @classmethod
    def from_env(cls) -> "ToolConfig":
        """从环境变量加载工具配置"""
        project_root = get_project_root()

        mcp_config_path = os.getenv("MCP_CONFIG_PATH", str(project_root / "mcp_servers.yaml"))
        tools_config_path = os.getenv("TOOLS_CONFIG_PATH", str(project_root / "tools.yaml"))

        mcp_servers = cls._load_mcp_config(mcp_config_path)

        return cls(
            enable_rag=os.getenv("AGENT_ENABLE_RAG", "true").lower() == "true",
            enable_calculator=os.getenv("AGENT_ENABLE_CALCULATOR", "true").lower() == "true",
            mcp_servers=mcp_servers,
            mcp_config_path=mcp_config_path,
            tools_config_path=tools_config_path,
        )

    @classmethod
    def from_yaml(cls) -> "ToolConfig":
        """从 YAML 加载工具配置"""
        config = cls.from_env()

        yaml_config = load_yaml_config("tools")
        if yaml_config:
            config.enable_rag = yaml_config.get("enable_rag", config.enable_rag)
            config.enable_calculator = yaml_config.get("enable_calculator", config.enable_calculator)

            # MCP 配置从 YAML 覆盖
            if "mcp_servers" in yaml_config:
                config.mcp_servers = yaml_config["mcp_servers"]

        return config

    @classmethod
    def _load_mcp_config(cls, config_path: str) -> Dict[str, Any]:
        """加载 MCP 配置文件"""
        import logging
        import yaml
        logger = logging.getLogger("tool")

        if not os.path.exists(config_path):
            return {}

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f)
                return config.get("servers", {}) if config else {}
        except Exception as e:
            logger.warning(f"加载 MCP 配置失败: {e}")
            return {}


# 全局配置实例
config = ToolConfig.from_env()
