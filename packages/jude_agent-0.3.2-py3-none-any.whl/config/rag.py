"""RAG 配置模块

RAG 核心功能所需的配置项：
- 嵌入模型配置
- LLM 模型配置
- 分块参数
- API 配置
"""

import os
from dataclasses import dataclass

from . import get_project_root


@dataclass
class RAGConfig:
    """RAG 配置类"""

    # 嵌入模型（用于将文本转为向量）
    embedding_model: str = "nomic-embed-text"

    # 大语言模型
    llm_model: str = "MiniMax-M2.2"

    # 文本分块大小（字符数）
    chunk_size: int = 500

    # 相邻分块之间的重叠字符数（保持上下文连贯）
    chunk_overlap: int = 50

    # 检索返回的文档数量
    top_k: int = 3

    # 分块策略
    chunk_strategy: str = "recursive"

    # 语义分块配置
    semantic_breakpoint_threshold: int = 95
    semantic_buffer_size: int = 1

    # MiniMax Anthropic API 配置
    anthropic_api_key: str = ""
    anthropic_base_url: str = "https://api.minimaxi.com/anthropic"

    # 向量数据库路径（可继承 Agent 配置）
    chroma_dir: str = ""

    @classmethod
    def from_env(cls) -> "RAGConfig":
        """从环境变量创建配置"""
        project_root = get_project_root()
        chroma_dir = os.getenv("CHROMA_DIR", str(project_root / "db" / "chroma"))

        return cls(
            embedding_model=os.getenv("EMBEDDING_MODEL", cls.embedding_model),
            llm_model=os.getenv("LLM_MODEL", cls.llm_model),
            chunk_size=int(os.getenv("CHUNK_SIZE", str(cls.chunk_size))),
            chunk_overlap=int(os.getenv("CHUNK_OVERLAP", str(cls.chunk_overlap))),
            top_k=int(os.getenv("TOP_K", str(cls.top_k))),
            chunk_strategy=os.getenv("CHUNK_STRATEGY", cls.chunk_strategy),
            semantic_breakpoint_threshold=int(os.getenv("SEMANTIC_BREAKPOINT_THRESHOLD", str(cls.semantic_breakpoint_threshold))),
            semantic_buffer_size=int(os.getenv("SEMANTIC_BUFFER_SIZE", str(cls.semantic_buffer_size))),
            anthropic_api_key=os.getenv("ANTHROPIC_API_KEY", cls.anthropic_api_key),
            anthropic_base_url=os.getenv("ANTHROPIC_BASE_URL", cls.anthropic_base_url),
            chroma_dir=chroma_dir,
        )

    @classmethod
    def from_yaml(cls, config: dict = None) -> "RAGConfig":
        """从 YAML 配置创建（扩展环境变量）"""
        cfg = cls.from_env()

        if config:
            for key, value in config.items():
                if hasattr(cfg, key) and value is not None:
                    setattr(cfg, key, value)

        return cfg


# 全局默认配置实例（从环境变量加载）
config = RAGConfig.from_env()

# 导出常用配置常量（保持向后兼容）
EMBEDDING_MODEL = config.embedding_model
LLM_MODEL = config.llm_model
CHUNK_SIZE = config.chunk_size
CHUNK_OVERLAP = config.chunk_overlap
TOP_K = config.top_k
CHUNK_STRATEGY = config.chunk_strategy
SEMANTIC_BREAKPOINT_THRESHOLD = config.semantic_breakpoint_threshold
SEMANTIC_BUFFER_SIZE = config.semantic_buffer_size
ANTHROPIC_API_KEY = config.anthropic_api_key
ANTHROPIC_BASE_URL = config.anthropic_base_url
