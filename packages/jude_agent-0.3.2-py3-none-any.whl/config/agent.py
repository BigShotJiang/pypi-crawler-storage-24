"""Agent 配置模块

Agent 所需的核心配置：
- LLM 模型配置
- 生成参数配置
- 记忆配置
- MCP 配置
"""

import os
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List

from . import get_project_root, load_yaml_config


@dataclass
class AgentConfig:
    """Agent 配置类"""

    # LLM 模型配置
    agent_model: str = "MiniMax-M2.5"
    temperature: float = 0.7

    # 迭代限制
    max_iterations: int = 10

    # 显示配置
    show_thinking: bool = True

    # 记忆配置
    memory_max_messages: int = 20
    memory_summary_threshold: int = 10

    # API 配置
    anthropic_api_key: str = ""
    anthropic_base_url: str = "https://api.minimaxi.com/anthropic"

    # 存储路径
    chroma_dir: str = ""
    data_dir: str = ""

    # 工具配置
    enable_rag: bool = True
    enable_calculator: bool = True

    # 服务器配置
    agent_server_port: int = 8080
    agent_server_url: str = "http://localhost:8080"

    # 飞书配置
    feishu_app_id: str = ""
    feishu_app_secret: str = ""

    # 渠道配置
    enabled_channels: List[str] = field(default_factory=lambda: ["cli"])

    # MCP 配置
    mcp_servers: Dict[str, Any] = field(default_factory=dict)
    mcp_config_path: str = ""

    # Multi-Agent 配置
    enable_multi_agent: bool = False
    multi_agent_config_path: str = ""

    # 动态工具 Middleware（默认启用，不再需要显式配置）
    # use_function_agent 已移除，改用 langchain v1 Middleware

    @classmethod
    def from_env(cls) -> "AgentConfig":
        """从环境变量创建配置（同时加载 YAML 配置）"""
        # 先从环境变量创建基础配置
        config = cls._from_env_impl()

        # 尝试从 tools.yaml 加载 agent 配置
        config = cls._merge_yaml_config(config)

        return config

    @classmethod
    def _from_env_impl(cls) -> "AgentConfig":
        """从环境变量创建配置的内部实现"""
        project_root = get_project_root()

        # 设置默认值
        chroma_dir = os.path.join(str(project_root), "db", "chroma")
        data_dir = os.path.join(str(project_root), "db", "sqlite")

        # 加载 MCP 配置
        mcp_config_path = os.getenv("MCP_CONFIG_PATH", os.path.join(str(project_root), "mcp_servers.yaml"))
        mcp_servers = cls._load_mcp_config(mcp_config_path)

        # Multi-Agent 配置
        multi_agent_config_path = os.getenv("MULTI_AGENT_CONFIG_PATH", os.path.join(str(project_root), "config", "agents.yaml"))

        return cls(
            agent_model=os.getenv("AGENT_MODEL", cls.agent_model),
            temperature=float(os.getenv("AGENT_TEMPERATURE", str(cls.temperature))),
            max_iterations=int(os.getenv("AGENT_MAX_ITERATIONS", str(cls.max_iterations))),
            show_thinking=os.getenv("AGENT_SHOW_THINKING", str(cls.show_thinking)).lower() == "true",
            memory_max_messages=int(os.getenv("AGENT_MEMORY_MAX_MESSAGES", str(cls.memory_max_messages))),
            memory_summary_threshold=int(os.getenv("AGENT_MEMORY_SUMMARY_THRESHOLD", str(cls.memory_summary_threshold))),
            anthropic_api_key=os.getenv("ANTHROPIC_API_KEY", cls.anthropic_api_key),
            anthropic_base_url=os.getenv("ANTHROPIC_BASE_URL", cls.anthropic_base_url),
            chroma_dir=os.getenv("CHROMA_DIR", chroma_dir),
            data_dir=os.getenv("DATA_DIR", data_dir),
            enable_rag=os.getenv("AGENT_ENABLE_RAG", str(cls.enable_rag)).lower() == "true",
            enable_calculator=os.getenv("AGENT_ENABLE_CALCULATOR", str(cls.enable_calculator)).lower() == "true",
            agent_server_port=int(os.getenv("AGENT_SERVER_PORT", str(cls.agent_server_port))),
            agent_server_url=os.getenv("AGENT_SERVER_URL", cls.agent_server_url),
            feishu_app_id=os.getenv("FEISHU_APP_ID", cls.feishu_app_id),
            feishu_app_secret=os.getenv("FEISHU_APP_SECRET", cls.feishu_app_secret),
            enabled_channels=[c.strip() for c in os.getenv("ENABLED_CHANNELS", "cli").split(",") if c.strip()],
            mcp_servers=mcp_servers,
            mcp_config_path=mcp_config_path,
            enable_multi_agent=os.getenv("ENABLE_MULTI_AGENT", str(cls.enable_multi_agent)).lower() == "true",
            multi_agent_config_path=os.getenv("MULTI_AGENT_CONFIG_PATH", multi_agent_config_path),
        )

    @classmethod
    def _merge_yaml_config(cls, config: "AgentConfig") -> "AgentConfig":
        """从 tools.yaml 合并配置"""
        import yaml as yaml_module

        project_root = get_project_root()
        tools_yaml_path = project_root / "tools.yaml"

        if tools_yaml_path.exists():
            try:
                with open(tools_yaml_path, "r", encoding="utf-8") as f:
                    tools_config = yaml_module.safe_load(f) or {}
                    if tools_config and "agent" in tools_config:
                        agent_config = tools_config["agent"]
                        if agent_config:
                            for key, value in agent_config.items():
                                if hasattr(config, key):
                                    setattr(config, key, value)
            except Exception:
                pass  # 忽略加载错误

        return config

    @classmethod
    def from_yaml(cls, config_path: str = None) -> "AgentConfig":
        """从 YAML 文件加载配置（扩展环境变量）"""
        config = cls.from_env()

        # 尝试加载 YAML 配置
        yaml_config = load_yaml_config("agent") if config_path is None else {}
        if config_path and os.path.exists(config_path):
            yaml_config = load_yaml_config(os.path.splitext(os.path.basename(config_path))[0])

        # 也尝试从 tools.yaml 加载 agent 配置
        import os as config_os
        project_root = get_project_root()
        tools_yaml_path = project_root / "tools.yaml"
        if tools_yaml_path.exists():
            try:
                with open(tools_yaml_path, "r", encoding="utf-8") as f:
                    import yaml
                    tools_config = yaml.safe_load(f) or {}
                    if tools_config and "agent" in tools_config:
                        agent_config = tools_config["agent"]
                        if agent_config:
                            yaml_config.update(agent_config)
            except Exception as e:
                pass  # 忽略加载错误

        # 覆盖配置（YAML 配置优先级高于默认值但低于环境变量）
        if yaml_config:
            for key, value in yaml_config.items():
                if hasattr(config, key) and value is not None:
                    setattr(config, key, value)

        return config

    @classmethod
    def _load_mcp_config(cls, config_path: str) -> Dict[str, Any]:
        """加载 MCP 配置文件"""
        import logging
        logger = logging.getLogger("agent")

        if not os.path.exists(config_path):
            logger.info(f"MCP 配置文件不存在: {config_path}")
            return {}

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                import yaml
                config = yaml.safe_load(f)
                return config.get("servers", {}) if config else {}
        except Exception as e:
            logger.warning(f"加载 MCP 配置失败: {e}")
            return {}


# 全局默认配置实例
config = AgentConfig.from_env()

# 导出常用配置常量（保持向后兼容）
AGENT_MODEL = config.agent_model
AGENT_TEMPERATURE = config.temperature
MAX_ITERATIONS = config.max_iterations
SHOW_THINKING = config.show_thinking
ANTHROPIC_API_KEY = config.anthropic_api_key
ANTHROPIC_BASE_URL = config.anthropic_base_url


def get_channel_config(channel_name: str) -> dict:
    """获取指定渠道的配置

    Args:
        channel_name: 通道名称

    Returns:
        通道配置字典
    """
    if channel_name == "feishu":
        return {
            "enabled": "feishu" in config.enabled_channels,
            "app_id": config.feishu_app_id,
            "app_secret": config.feishu_app_secret,
        }
    elif channel_name == "cli":
        return {
            "enabled": "cli" in config.enabled_channels,
        }
    return {"enabled": False}
