"""渠道配置模块

支持多渠道配置：
- CLI
- 飞书
- HTTP Gateway
"""

import os
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional

from . import get_project_root, load_yaml_config


@dataclass
class ChannelConfig:
    """渠道配置基类"""
    enabled: bool = False


@dataclass
class CLIChannelConfig(ChannelConfig):
    """CLI 渠道配置"""
    enabled: bool = True


@dataclass
class FeishuChannelConfig(ChannelConfig):
    """飞书渠道配置"""
    enabled: bool = False
    app_id: str = ""
    app_secret: str = ""
    verification_token: str = ""


@dataclass
class GatewayChannelConfig(ChannelConfig):
    """HTTP Gateway 渠道配置"""
    enabled: bool = True
    host: str = "0.0.0.0"
    port: int = 8080


@dataclass
class ChannelsConfig:
    """所有渠道的统一配置"""

    cli: CLIChannelConfig = field(default_factory=CLIChannelConfig)
    feishu: FeishuChannelConfig = field(default_factory=FeishuChannelConfig)
    gateway: GatewayChannelConfig = field(default_factory=GatewayChannelConfig)

    @classmethod
    def from_env(cls) -> "ChannelsConfig":
        """从环境变量加载渠道配置"""
        enabled_channels = [c.strip() for c in os.getenv("ENABLED_CHANNELS", "cli").split(",") if c.strip()]

        return cls(
            cli=CLIChannelConfig(enabled="cli" in enabled_channels),
            feishu=FeishuChannelConfig(
                enabled="feishu" in enabled_channels,
                app_id=os.getenv("FEISHU_APP_ID", ""),
                app_secret=os.getenv("FEISHU_APP_SECRET", ""),
            ),
            gateway=GatewayChannelConfig(
                enabled="gateway" in enabled_channels or "http" in enabled_channels,
                host=os.getenv("GATEWAY_HOST", "0.0.0.0"),
                port=int(os.getenv("GATEWAY_PORT", "8080")),
            ),
        )

    @classmethod
    def from_yaml(cls) -> "ChannelsConfig":
        """从 YAML 加载渠道配置"""
        config = cls.from_env()

        yaml_config = load_yaml_config("channels")
        if yaml_config:
            for channel_name, channel_config in yaml_config.items():
                if channel_config is None:
                    continue

                if channel_name == "cli" and hasattr(config, "cli"):
                    config.cli.enabled = channel_config.get("enabled", config.cli.enabled)

                elif channel_name == "feishu" and hasattr(config, "feishu"):
                    config.feishu.enabled = channel_config.get("enabled", config.feishu.enabled)
                    config.feishu.app_id = channel_config.get("app_id", config.feishu.app_id)
                    config.feishu.app_secret = channel_config.get("app_secret", config.feishu.app_secret)
                    config.feishu.verification_token = channel_config.get("verification_token", config.feishu.verification_token)

                elif channel_name == "gateway" and hasattr(config, "gateway"):
                    config.gateway.enabled = channel_config.get("enabled", config.gateway.enabled)
                    config.gateway.host = channel_config.get("host", config.gateway.host)
                    config.gateway.port = channel_config.get("port", config.gateway.port)

        return config


# 全局配置实例
config = ChannelsConfig.from_env()
