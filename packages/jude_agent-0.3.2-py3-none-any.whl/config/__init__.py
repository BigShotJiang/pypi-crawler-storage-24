"""统一配置管理模块

支持从多个来源加载配置：
- 环境变量 (.env)
- YAML 配置文件
- 默认值

配置优先级：命令行 > 环境变量 > 文件 > 默认值
"""

import os
import logging
from pathlib import Path
from typing import Any, Dict, Optional, List
from dataclasses import dataclass, field

import yaml
from dotenv import load_dotenv

# 项目根目录
PROJECT_ROOT = Path(__file__).parent.parent.parent
load_dotenv(PROJECT_ROOT / ".env")

logger = logging.getLogger("config")


# ============================================================================
# 配置源加载器
# ============================================================================


class ConfigSource:
    """配置源基类"""

    def load(self) -> Dict[str, Any]:
        raise NotImplementedError


class EnvConfigSource(ConfigSource):
    """环境变量配置源"""

    def __init__(self, prefix: str = ""):
        self.prefix = prefix.upper()

    def load(self) -> Dict[str, Any]:
        """从环境变量加载配置"""
        config = {}
        for key, value in os.environ.items():
            if self.prefix and not key.startswith(self.prefix):
                continue
            # 移除前缀
            config_key = key[len(self.prefix):] if self.prefix else key
            config_key = config_key.lower()
            config[config_key] = value
        return config


class YamlConfigSource(ConfigSource):
    """YAML 配置文件源"""

    def __init__(self, file_path: Path):
        self.file_path = file_path

    def load(self) -> Dict[str, Any]:
        """从 YAML 文件加载配置"""
        if not self.file_path.exists():
            logger.debug(f"配置文件不存在: {self.file_path}")
            return {}

        try:
            with open(self.file_path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f)
                return config if config else {}
        except Exception as e:
            logger.warning(f"加载配置文件失败 {self.file_path}: {e}")
            return {}


# ============================================================================
# 配置管理器
# ============================================================================


class ConfigManager:
    """统一配置管理器

    支持多配置源，按优先级合并配置：
    1. 默认值（优先级最低）
    2. YAML 配置文件
    3. 环境变量（优先级最高）
    """

    def __init__(self, name: str):
        self.name = name
        self._config: Dict[str, Any] = {}
        self._sources: List[ConfigSource] = []

    def add_source(self, source: ConfigSource) -> "ConfigManager":
        """添加配置源"""
        self._sources.append(source)
        return self

    def add_yaml(self, file_path: Path) -> "ConfigManager":
        """添加 YAML 配置源"""
        return self.add_source(YamlConfigSource(file_path))

    def add_env(self, prefix: str = "") -> "ConfigManager":
        """添加环境变量配置源"""
        return self.add_source(EnvConfigSource(prefix))

    def load(self) -> Dict[str, Any]:
        """加载所有配置源并合并"""
        # 按添加顺序加载（优先级低的先加载）
        for source in self._sources:
            try:
                config = source.load()
                self._config = self._merge(self._config, config)
            except Exception as e:
                logger.warning(f"加载配置源失败: {e}")

        return self._config

    def _merge(self, base: Dict, override: Dict) -> Dict:
        """深度合并配置"""
        result = base.copy()
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge(result[key], value)
            else:
                result[key] = value
        return result

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置值"""
        keys = key.split(".")
        value = self._config
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        return value

    def __getitem__(self, key: str) -> Any:
        """支持 dict 风格访问"""
        return self.get(key)

    def __contains__(self, key: str) -> bool:
        """支持 in 操作符"""
        return self.get(key) is not None


# ============================================================================
# 便捷函数
# ============================================================================


def get_project_root() -> Path:
    """获取项目根目录"""
    return PROJECT_ROOT


def get_config_dir() -> Path:
    """获取配置目录"""
    return PROJECT_ROOT / "config"


def load_yaml_config(config_name: str) -> Dict[str, Any]:
    """便捷函数：加载 YAML 配置"""
    config_path = get_config_dir() / f"{config_name}.yaml"
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return {}


# ============================================================================
# 导出各领域配置
# ============================================================================

from .agent import AgentConfig, get_channel_config
from .rag import RAGConfig
from .channel import ChannelsConfig
from .tools import ToolConfig
from .skills import SkillConfig

__all__ = [
    "ConfigManager",
    "ConfigSource",
    "EnvConfigSource",
    "YamlConfigSource",
    "AgentConfig",
    "RAGConfig",
    "ChannelsConfig",
    "ToolConfig",
    "SkillConfig",
    "get_channel_config",
    "get_project_root",
    "get_config_dir",
    "load_yaml_config",
]
