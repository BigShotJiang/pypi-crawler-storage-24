"""Skills 配置模块

技能系统配置：
- 技能文件路径
- 技能加载器配置
"""

import os
from dataclasses import dataclass, field
from typing import List, Optional

from . import get_project_root, load_yaml_config


@dataclass
class SkillConfig:
    """技能配置"""

    # 技能配置文件路径
    skills_file_path: str = ""

    # 是否启用技能系统
    enabled: bool = True

    # 技能参数
    skill_args: List[str] = field(default_factory=list)

    @classmethod
    def from_env(cls) -> "SkillConfig":
        """从环境变量加载技能配置"""
        project_root = get_project_root()

        skills_file_path = os.getenv("SKILLS_FILE_PATH", str(project_root / "skills.yaml"))

        return cls(
            skills_file_path=skills_file_path,
            enabled=os.getenv("SKILLS_ENABLED", "true").lower() == "true",
            skill_args=os.getenv("SKILL_ARGS", "").split(",") if os.getenv("SKILL_ARGS") else [],
        )

    @classmethod
    def from_yaml(cls) -> "SkillConfig":
        """从 YAML 加载技能配置"""
        config = cls.from_env()

        yaml_config = load_yaml_config("skills")
        if yaml_config:
            config.enabled = yaml_config.get("enabled", config.enabled)

        return config


# 全局配置实例
config = SkillConfig.from_env()
