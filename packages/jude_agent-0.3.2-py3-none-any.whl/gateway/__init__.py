"""Gateway 抽象层

提供统一的 HTTP Gateway 接口，支持：
- 多租户（通过 AgentFactory 创建独立实例）
- 中间件支持（认证、限流、日志）
- 易于扩展新渠道
"""

import logging
from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional, Protocol

logger = logging.getLogger("gateway")


# ============================================================================
# 协议定义 (Protocol)
# ============================================================================


class AgentFactory(Protocol):
    """Agent 工厂协议"""

    def create_agent(self, session_id: str, **kwargs) -> Any:
        """创建 Agent 实例"""
        ...

    def get_agent(self, session_id: str) -> Optional[Any]:
        """获取已存在的 Agent 实例"""
        ...

    def release_agent(self, session_id: str) -> None:
        """释放 Agent 实例"""
        ...


class Request:
    """请求对象封装"""

    def __init__(self, data: Dict[str, Any], headers: Dict[str, str] = None):
        self._data = data
        self._headers = headers or {}
        self._session_id: Optional[str] = None

    @property
    def session_id(self) -> Optional[str]:
        return self._session_id

    @session_id.setter
    def session_id(self, value: str):
        self._session_id = value

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    @property
    def headers(self) -> Dict[str, str]:
        return self._headers


class Response:
    """响应对象封装"""

    def __init__(
        self,
        data: Any = None,
        status_code: int = 200,
        headers: Dict[str, str] = None
    ):
        self._data = data
        self._status_code = status_code
        self._headers = headers or {}

    @property
    def data(self) -> Any:
        return self._data

    @property
    def status_code(self) -> int:
        return self._status_code

    @property
    def headers(self) -> Dict[str, str]:
        return self._headers


# ============================================================================
# 中间件
# ============================================================================


class Middleware(ABC):
    """中间件基类"""

    @abstractmethod
    def process_request(self, request: Request) -> Optional[Response]:
        """处理请求，返回 None 表示继续处理"""
        pass

    @abstractmethod
    def process_response(self, request: Request, response: Response) -> Response:
        """处理响应"""
        pass


class LoggingMiddleware(Middleware):
    """日志中间件"""

    def process_request(self, request: Request) -> Optional[Response]:
        logger.info(f"[Gateway] 请求: session_id={request.session_id}")
        return None

    def process_response(self, request: Request, response: Response) -> Response:
        logger.info(f"[Gateway] 响应: status={response.status_code}")
        return response


class AuthMiddleware(Middleware):
    """认证中间件"""

    def __init__(self, api_key: str = None):
        self._api_key = api_key

    def process_request(self, request: Request) -> Optional[Response]:
        if self._api_key:
            auth_header = request.headers.get("Authorization", "")
            if not auth_header.startswith("Bearer "):
                return Response(
                    data={"error": "unauthorized"},
                    status_code=401
                )
            token = auth_header[7:]
            if token != self._api_key:
                return Response(
                    data={"error": "invalid token"},
                    status_code=401
                )
        return None

    def process_response(self, request: Request, response: Response) -> Response:
        return response


class RateLimitMiddleware(Middleware):
    """限流中间件（简单实现）"""

    def __init__(self, max_requests: int = 100, window_seconds: int = 60):
        self._max_requests = max_requests
        self._window_seconds = window_seconds
        self._requests: Dict[str, List[float]] = {}

    def process_request(self, request: Request) -> Optional[Response]:
        import time

        # 使用固定窗口限流（简化实现）
        now = time.time()
        session_id = request.session_id or "default"

        if session_id not in self._requests:
            self._requests[session_id] = []

        # 清理过期请求
        self._requests[session_id] = [
            t for t in self._requests[session_id]
            if now - t < self._window_seconds
        ]

        if len(self._requests[session_id]) >= self._max_requests:
            return Response(
                data={"error": "rate limit exceeded"},
                status_code=429
            )

        self._requests[session_id].append(now)
        return None

    def process_response(self, request: Request, response: Response) -> Response:
        return response


# ============================================================================
# Gateway 抽象基类
# ============================================================================


class Gateway(ABC):
    """Gateway 抽象基类

    职责：
    - 处理 HTTP 请求
    - 管理 Agent 生命周期
    - 应用中间件
    - 路由分发

    不承担：
    - Agent 业务逻辑（由 AgentFactory 负责）
    - 具体 HTTP 框架细节（由子类负责）
    """

    def __init__(
        self,
        agent_factory: AgentFactory = None,
        middlewares: List[Middleware] = None,
    ):
        """
        初始化 Gateway

        Args:
            agent_factory: Agent 工厂实例
            middlewares: 中间件列表
        """
        self._agent_factory = agent_factory
        self._middlewares = middlewares or []
        self._initialized = False

    @property
    def agent_factory(self) -> Optional[AgentFactory]:
        return self._agent_factory

    @agent_factory.setter
    def agent_factory(self, factory: AgentFactory):
        self._agent_factory = factory

    def add_middleware(self, middleware: Middleware):
        """添加中间件"""
        self._middlewares.append(middleware)

    def initialize(self):
        """初始化 Gateway"""
        if self._initialized:
            return

        logger.info("[Gateway] 初始化中...")
        self._setup_routes()
        self._initialized = True
        logger.info("[Gateway] 初始化完成")

    @abstractmethod
    def _setup_routes(self):
        """设置路由（子类实现）"""
        pass

    @abstractmethod
    def run(self, host: str = "0.0.0.0", port: int = 8080, **kwargs):
        """启动 Gateway"""
        pass

    def handle_request(
        self,
        endpoint: str,
        request: Request
    ) -> Response:
        """
        处理请求（应用中间件链）

        Args:
            endpoint: 端点路径
            request: 请求对象

        Returns:
            响应对象
        """
        # 应用请求中间件
        for middleware in self._middlewares:
            response = middleware.process_request(request)
            if response:
                return response

        # 处理请求
        response = self._dispatch(endpoint, request)

        # 应用响应中间件
        for middleware in reversed(self._middlewares):
            response = middleware.process_response(request, response)

        return response

    @abstractmethod
    def _dispatch(self, endpoint: str, request: Request) -> Response:
        """分发请求到具体处理方法"""
        pass


# ============================================================================
# 便捷函数
# ============================================================================


def create_gateway(
    gateway_type: str = "flask",
    agent_factory: AgentFactory = None,
    middlewares: List[Middleware] = None,
    **kwargs
) -> Gateway:
    """
    创建 Gateway 实例

    Args:
        gateway_type: Gateway 类型 ("flask")
        agent_factory: Agent 工厂
        middlewares: 中间件列表
        **kwargs: 其他参数

    Returns:
        Gateway 实例
    """
    if gateway_type == "flask":
        from .flask import FlaskGateway
        return FlaskGateway(
            agent_factory=agent_factory,
            middlewares=middlewares,
            **kwargs
        )

    raise ValueError(f"不支持的 Gateway 类型: {gateway_type}")
