"""Flask Gateway 实现

基于 Flask 的 HTTP Gateway
"""

import logging
import time
import uuid
from typing import Any, Dict, List, Optional

from flask import Flask, g, jsonify, request

from . import (
    AgentFactory,
    Gateway,
    Middleware,
    Request,
    Response,
)

logger = logging.getLogger("gateway.flask")


class SimpleAgentFactory:
    """简单的 Agent 工厂实现

    负责创建和管理 Agent 实例
    """

    def __init__(
        self,
        agent_class=None,
        tools: List = None,
        max_iterations: int = 10,
        show_thinking: bool = False,
        config=None,
    ):
        """
        初始化工厂

        Args:
            agent_class: Agent 类（默认为 core.agent.Agent）
            tools: 工具列表
            max_iterations: 最大迭代次数
            show_thinking: 是否显示思考过程
            config: 配置对象
        """
        self._agent_class = agent_class
        self._tools = tools or []
        self._max_iterations = max_iterations
        self._show_thinking = show_thinking
        self._config = config
        self._agents: Dict[str, Any] = {}

    def create_agent(self, session_id: str, **kwargs) -> Any:
        """创建 Agent 实例"""
        # 如果已有实例，直接返回
        if session_id in self._agents:
            return self._agents[session_id]

        # 创建新的 Agent 实例
        if self._agent_class is None:
            # 默认使用 core.agent.Agent
            from src.core.agent import Agent as CoreAgent
            self._agent_class = CoreAgent

        agent = self._agent_class(
            session_id=session_id,
            tools=self._tools,
            max_iterations=kwargs.get("max_iterations", self._max_iterations),
            show_thinking=kwargs.get("show_thinking", self._show_thinking),
            config=kwargs.get("config", self._config),
            **kwargs
        )

        self._agents[session_id] = agent
        logger.info(f"[AgentFactory] 创建 Agent: {session_id}")
        return agent

    def get_agent(self, session_id: str) -> Optional[Any]:
        """获取已存在的 Agent 实例"""
        return self._agents.get(session_id)

    def release_agent(self, session_id: str) -> None:
        """释放 Agent 实例"""
        if session_id in self._agents:
            agent = self._agents.pop(session_id)
            if hasattr(agent, "reset"):
                agent.reset()
            logger.info(f"[AgentFactory] 释放 Agent: {session_id}")

    def list_sessions(self) -> List[str]:
        """列出所有会话"""
        return list(self._agents.keys())

    def clear_all(self) -> int:
        """清除所有会话"""
        count = len(self._agents)
        self._agents.clear()
        return count


class FlaskGateway(Gateway):
    """Flask Gateway 实现

    提供 HTTP API，支持：
    - /health 健康检查
    - /v1/chat/completions OpenAI 兼容 API
    - /v1/agent/chat Agent 专用 API
    - /v1/agent/stream 流式响应
    - /v1/agent/memory/* 记忆管理
    """

    def __init__(
        self,
        agent_factory: AgentFactory = None,
        middlewares: List[Middleware] = None,
        enable_rag: bool = True,
        enable_calculator: bool = True,
        max_iterations: int = 10,
        show_thinking: bool = False,
        config=None,
    ):
        """
        初始化 Flask Gateway

        Args:
            agent_factory: Agent 工厂
            middlewares: 中间件列表
            enable_rag: 是否启用 RAG
            enable_calculator: 是否启用计算器
            max_iterations: 最大迭代次数
            show_thinking: 是否显示思考过程
            config: 配置对象
        """
        super().__init__(agent_factory, middlewares)

        self._enable_rag = enable_rag
        self._enable_calculator = enable_calculator
        self._max_iterations = max_iterations
        self._show_thinking = show_thinking
        self._config = config
        self._app: Optional[Flask] = None

    def _setup_routes(self):
        """设置 Flask 路由"""
        self._app = Flask(__name__)

        # 如果没有指定 agent_factory，自动创建一个
        if self._agent_factory is None:
            self._agent_factory = self._create_default_factory()

        # 添加默认中间件
        self._add_default_middlewares()

        # 设置路由
        self._register_routes()

    def _create_default_factory(self) -> SimpleAgentFactory:
        """创建默认 Agent 工厂"""
        # 加载工具
        tools = []
        if self._enable_calculator:
            from src.agent.agent_tools import calculator
            tools.append(calculator)
        if self._enable_rag:
            from src.agent.agent_tools import search_documents
            tools.append(search_documents)

        return SimpleAgentFactory(
            tools=tools,
            max_iterations=self._max_iterations,
            show_thinking=self._show_thinking,
            config=self._config,
        )

    def _add_default_middlewares(self):
        """添加默认中间件"""
        # 添加日志中间件
        from . import LoggingMiddleware
        self.add_middleware(LoggingMiddleware())

        # 添加指标中间件
        self._add_metrics_middleware()

    def _add_metrics_middleware(self):
        """添加指标收集中间件"""
        from src.core.metrics import get_metrics_collector

        metrics = get_metrics_collector()

        @self._app.before_request
        def before_request():
            """在请求开始时记录时间"""
            g.start_time = time.time()

        @self._app.after_request
        def after_request(response):
            """在请求结束后记录指标"""
            if hasattr(g, 'start_time'):
                duration = time.time() - g.start_time
                # 获取端点名称
                endpoint = request.endpoint or request.path
                metrics.record_gateway_request(
                    endpoint=endpoint,
                    duration=duration,
                    status_code=response.status_code
                )

            return response

    def _register_routes(self):
        """注册路由"""
        app = self._app

        @app.route("/health", methods=["GET"])
        def health():
            """健康检查"""
            return jsonify({
                "status": "healthy",
                "sessions": len(self._agent_factory.list_sessions()) if self._agent_factory else 0
            })

        @app.route("/v1/metrics", methods=["GET"])
        def metrics_stats():
            """获取系统指标统计"""
            from src.core.cache import get_llm_cache
            from src.core.metrics import get_metrics_collector

            metrics = get_metrics_collector()
            cache = get_llm_cache()

            return jsonify({
                "metrics": metrics.get_stats(),
                "cache": cache.stats(),
            })

        @app.route("/v1/metrics/reset", methods=["POST"])
        def metrics_reset():
            """重置指标统计"""
            from src.core.metrics import get_metrics_collector

            metrics = get_metrics_collector()
            metrics.reset()

            return jsonify({"status": "reset"})

        @app.route("/v1/chat/completions", methods=["POST"])
        def chat_completions():
            """Chat Completions API（OpenAI 兼容格式）"""
            data = request.json or {}
            messages = data.get("messages", [])

            # 获取最后一条用户消息
            user_message = None
            for msg in reversed(messages):
                if msg.get("role") == "user":
                    user_message = msg.get("content", "")
                    break

            if not user_message:
                return jsonify({"error": "no user message"}), 400

            # 获取 session_id
            session_id = data.get("session_id", "default")

            # 获取或创建 Agent
            agent = self._agent_factory.create_agent(session_id)

            # 调用 Agent
            response = agent.process(user_message)

            # 返回 OpenAI 兼容格式
            return jsonify({
                "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": "jude-agent",
                "choices": [{
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": response
                    },
                    "finish_reason": "stop"
                }]
            })

        @app.route("/v1/agent/chat", methods=["POST"])
        def agent_chat():
            """Agent 专用聊天 API"""
            data = request.json or {}
            message = data.get("message", "")
            session_id = data.get("session_id", "default")

            if not message:
                return jsonify({"error": "no message"}), 400

            # 获取或创建 Agent
            agent = self._agent_factory.create_agent(session_id)

            # 调用 Agent
            response = agent.process(message)

            return jsonify({
                "response": response,
                "session_id": session_id,
            })

        @app.route("/v1/agent/reset", methods=["POST"])
        def agent_reset():
            """重置 Agent（清除对话历史）"""
            data = request.json or {}
            session_id = data.get("session_id")

            if session_id:
                self._agent_factory.release_agent(session_id)
                return jsonify({"status": "reset", "session_id": session_id})
            else:
                count = self._agent_factory.clear_all()
                return jsonify({"status": "reset", "cleared_sessions": count})

        @app.route("/v1/agent/stream", methods=["POST"])
        def agent_stream():
            """流式响应 API"""
            data = request.json or {}
            message = data.get("message", "")
            session_id = data.get("session_id", "default")

            if not message:
                return jsonify({"error": "no message"}), 400

            agent = self._agent_factory.create_agent(session_id)

            def generate():
                for chunk in agent.stream(message):
                    yield f"data: {chunk}\n\n"

            return generate(), {
                "Content-Type": "text/event-stream",
                "Cache-Control": "no-cache",
            }

        @app.route("/v1/agent/memory/stats", methods=["GET"])
        def memory_stats():
            """获取记忆统计信息"""
            session_id = request.args.get("session_id", "default")
            agent = self._agent_factory.get_agent(session_id)

            if agent and hasattr(agent, "get_memory_stats"):
                return jsonify(agent.get_memory_stats())
            return jsonify({"enabled": False})

        @app.route("/v1/agent/memory/clear", methods=["POST"])
        def memory_clear():
            """清除记忆"""
            data = request.json or {}
            session_id = data.get("session_id", "default")

            agent = self._agent_factory.get_agent(session_id)
            if agent and hasattr(agent, "clear_memory"):
                agent.clear_memory()
                return jsonify({"status": "cleared", "session_id": session_id})
            return jsonify({"error": "agent not found"}), 404

        @app.route("/v1/agent/memory/enable", methods=["POST"])
        def memory_enable():
            """启用/禁用记忆"""
            data = request.json or {}
            enabled = data.get("enabled", True)
            session_id = data.get("session_id", "default")

            agent = self._agent_factory.get_agent(session_id)
            if agent and hasattr(agent, "set_memory_enabled"):
                agent.set_memory_enabled(enabled)
                return jsonify({"enabled": enabled})
            return jsonify({"error": "agent not found"}), 404

        @app.route("/v1/agent/memory/summarize", methods=["POST"])
        def memory_summarize():
            """强制生成摘要"""
            data = request.json or {}
            session_id = data.get("session_id", "default")

            agent = self._agent_factory.get_agent(session_id)
            if agent and hasattr(agent, "force_summarize"):
                summary = agent.force_summarize()
                return jsonify({"summary": summary})
            return jsonify({"error": "agent not found"}), 404

    def _dispatch(self, endpoint: str, request: Request) -> Response:
        """分发请求（Flask 实现不使用此方法）"""
        # Flask 通过装饰器直接处理，此方法保留为接口兼容
        raise NotImplementedError("Flask Gateway 使用装饰器路由")

    def run(self, host: str = "0.0.0.0", port: int = 8080, **kwargs):
        """
        启动 Flask Gateway

        Args:
            host: 主机地址
            port: 端口号
            **kwargs: 其他 Flask 参数
        """
        self.initialize()
        logger.info(f"启动 Flask Gateway: http://{host}:{port}")
        self._app.run(host=host, port=port, **kwargs)

    @property
    def app(self) -> Flask:
        """获取 Flask 应用实例"""
        return self._app


# ============================================================================
# 便捷函数
# ============================================================================


def create_flask_gateway(
    enable_rag: bool = True,
    enable_calculator: bool = True,
    max_iterations: int = 10,
    show_thinking: bool = False,
    **kwargs
) -> FlaskGateway:
    """
    创建 Flask Gateway 的便捷函数

    Args:
        enable_rag: 是否启用 RAG
        enable_calculator: 是否启用计算器
        max_iterations: 最大迭代次数
        show_thinking: 是否显示思考过程
        **kwargs: 其他参数

    Returns:
        FlaskGateway 实例
    """
    return FlaskGateway(
        enable_rag=enable_rag,
        enable_calculator=enable_calculator,
        max_iterations=max_iterations,
        show_thinking=show_thinking,
        **kwargs
    )


# 向后兼容：保持原有接口
def run_server(
    host: str = "0.0.0.0",
    port: int = 8080,
    enable_rag: bool = True,
    enable_calculator: bool = True,
):
    """
    运行 HTTP 服务器（向后兼容接口）

    Args:
        host: 主机地址
        port: 端口号
        enable_rag: 是否启用 RAG
        enable_calculator: 是否启用计算器
    """
    gateway = create_flask_gateway(
        enable_rag=enable_rag,
        enable_calculator=enable_calculator,
    )
    gateway.run(host=host, port=port)
