"""Agent 事件定义

定义 Agent 生命周期内发生的各种事件：
- 启动/结束事件
- 错误事件
- 工具调用事件
- 消息事件
"""

from typing import Any, Dict

from .base import Event


class AgentEvent(Event):
    """Agent 事件基类

    所有 Agent 相关事件的父类。
    """
    pass


class AgentStartEvent(AgentEvent):
    """Agent 启动事件

    在 Agent 开始处理用户请求时触发。

    Payload:
        session_id (str): 会话 ID
        user_input (str): 用户输入（可能截断）
        enable_memory (bool): 是否启用记忆
        enable_rag (bool): 是否启用 RAG
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "agent_start")
        super().__init__(type="agent_start", payload=payload, **kwargs)


class AgentEndEvent(AgentEvent):
    """Agent 结束事件

    在 Agent 完成处理用户请求时触发。

    Payload:
        session_id (str): 会话 ID
        response (str): Agent 响应内容
        duration_ms (float): 处理时长（毫秒）
        tool_calls_count (int): 工具调用次数
        thinking (List[str]): 思考过程（如果启用）
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "agent_end")
        super().__init__(type="agent_end", payload=payload, **kwargs)


class AgentErrorEvent(AgentEvent):
    """Agent 错误事件

    在 Agent 处理过程中发生错误时触发。

    Payload:
        session_id (str): 会话 ID
        error (str): 错误信息
        error_type (str): 错误类型
        user_input (str): 导致错误的用户输入
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "agent_error")
        super().__init__(type="agent_error", payload=payload, **kwargs)


class AgentToolCallEvent(AgentEvent):
    """Agent 工具调用事件

    在 Agent 调用工具时触发。

    Payload:
        session_id (str): 会话 ID
        tool_name (str): 工具名称
        tool_input (Dict): 工具输入参数
        tool_call_id (str): 工具调用 ID
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "agent_tool_call")
        super().__init__(type="agent_tool_call", payload=payload, **kwargs)


class AgentToolResultEvent(AgentEvent):
    """Agent 工具结果事件

    在 Agent 获得工具执行结果时触发。

    Payload:
        session_id (str): 会话 ID
        tool_name (str): 工具名称
        tool_output (str): 工具输出结果
        tool_call_id (str): 工具调用 ID
        duration_ms (float): 执行时长（毫秒）
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "agent_tool_result")
        super().__init__(type="agent_tool_result", payload=payload, **kwargs)


class AgentMessageEvent(AgentEvent):
    """Agent 消息事件

    在 Agent 发送或接收消息时触发。

    Payload:
        session_id (str): 会话 ID
        message_type (str): 消息类型 (user/assistant/system)
        content (str): 消息内容
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "agent_message")
        super().__init__(type="agent_message", payload=payload, **kwargs)
