"""事件驱动架构

提供统一的事件系统，用于解耦 Agent、RAG、工具等组件。
"""

from .agent import (
    AgentEndEvent,
    AgentErrorEvent,
    AgentEvent,
    AgentMessageEvent,
    AgentStartEvent,
    AgentToolCallEvent,
    AgentToolResultEvent,
)
from .base import Event, EventBus
from .rag import (
    RagAddDocumentsEvent,
    RagErrorEvent,
    RagEvent,
    RagQueryEvent,
    RagResultEvent,
)
from .tool import (
    ToolEndEvent,
    ToolErrorEvent,
    ToolEvent,
    ToolStartEvent,
)

__all__ = [
    "Event",
    "EventBus",
    # Agent events
    "AgentEvent",
    "AgentStartEvent",
    "AgentEndEvent",
    "AgentErrorEvent",
    "AgentToolCallEvent",
    "AgentToolResultEvent",
    "AgentMessageEvent",
    # Tool events
    "ToolEvent",
    "ToolStartEvent",
    "ToolEndEvent",
    "ToolErrorEvent",
    # RAG events
    "RagEvent",
    "RagQueryEvent",
    "RagResultEvent",
    "RagErrorEvent",
    "RagAddDocumentsEvent",
]
