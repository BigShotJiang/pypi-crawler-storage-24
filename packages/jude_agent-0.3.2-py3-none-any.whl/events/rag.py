"""RAG 事件定义

定义 RAG 服务中发生的各种事件：
- 查询事件
- 结果事件
- 错误事件
"""

from typing import Any, Dict

from .base import Event


class RagEvent(Event):
    """RAG 事件基类

    所有 RAG 相关事件的父类。
    """
    pass


class RagQueryEvent(RagEvent):
    """RAG 查询事件

    在 RAG 服务开始查询时触发。

    Payload:
        query (str): 查询文本
        session_id (str): 会话 ID（如果有）
        top_k (int): 请求的 top_k 数量
        filters (Dict): 过滤条件（如果有）
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "rag_query")
        super().__init__(type="rag_query", payload=payload, **kwargs)


class RagResultEvent(RagEvent):
    """RAG 结果事件

    在 RAG 服务返回查询结果时触发。

    Payload:
        query (str): 查询文本
        session_id (str): 会话 ID（如果有）
        result_count (int): 返回的文档数量
        results (List[Dict]): 检索结果列表，每项包含:
            - content: 文档内容
            - source: 文档来源
            - score: 相似度分数（如果有）
        duration_ms (float): 查询时长（毫秒）
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "rag_result")
        super().__init__(type="rag_result", payload=payload, **kwargs)


class RagErrorEvent(RagEvent):
    """RAG 错误事件

    在 RAG 服务发生错误时触发。

    Payload:
        query (str): 查询文本（可能截断）
        session_id (str): 会话 ID（如果有）
        error (str): 错误信息
        error_type (str): 错误类型
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "rag_error")
        super().__init__(type="rag_error", payload=payload, **kwargs)


class RagAddDocumentsEvent(RagEvent):
    """RAG 添加文档事件

    在 RAG 服务添加文档到索引时触发。

    Payload:
        file_paths (List[str]): 添加的文件路径
        chunk_count (int): 分块数量
        status (str): 添加状态 (success/error)
        session_id (str): 会话 ID（如果有）
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "rag_add_documents")
        super().__init__(type="rag_add_documents", payload=payload, **kwargs)
