"""工具事件定义

定义工具执行过程中发生的各种事件：
- 开始执行事件
- 结束执行事件
- 执行错误事件
"""

from typing import Any, Dict

from .base import Event


class ToolEvent(Event):
    """工具事件基类

    所有工具相关事件的父类。
    """
    pass


class ToolStartEvent(ToolEvent):
    """工具开始执行事件

    在工具开始执行时触发。

    Payload:
        tool_name (str): 工具名称
        tool_input (Dict): 工具输入参数
        tool_call_id (str): 工具调用 ID（如果有）
        session_id (str): 会话 ID（如果有）
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "tool_start")
        super().__init__(type="tool_start", payload=payload, **kwargs)


class ToolEndEvent(ToolEvent):
    """工具结束执行事件

    在工具执行完成时触发。

    Payload:
        tool_name (str): 工具名称
        tool_output (str): 工具输出结果
        tool_call_id (str): 工具调用 ID（如果有）
        session_id (str): 会话 ID（如果有）
        duration_ms (float): 执行时长（毫秒）
        success (bool): 是否执行成功
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "tool_end")
        super().__init__(type="tool_end", payload=payload, **kwargs)


class ToolErrorEvent(ToolEvent):
    """工具执行错误事件

    在工具执行过程中发生错误时触发。

    Payload:
        tool_name (str): 工具名称
        error (str): 错误信息
        error_type (str): 错误类型
        tool_input (Dict): 工具输入参数（可能包含敏感信息）
        tool_call_id (str): 工具调用 ID（如果有）
        session_id (str): 会话 ID（如果有）
    """

    def __init__(self, payload: Dict[str, Any] = None, **kwargs):
        payload = payload or {}
        payload.setdefault("type", "tool_error")
        super().__init__(type="tool_error", payload=payload, **kwargs)
