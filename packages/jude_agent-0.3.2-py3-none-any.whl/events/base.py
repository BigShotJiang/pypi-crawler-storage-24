"""事件基类和事件总线

提供基础的事件基础设施：
- Event: 事件基类
- EventBus: 同步事件总线
"""

import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List


@dataclass
class Event:
    """事件基类

    所有事件的父类，包含基本的事件属性。

    Attributes:
        type: 事件类型标识符
        timestamp: 事件发生时间
        payload: 事件携带的数据
    """
    type: str
    timestamp: datetime = field(default_factory=datetime.now)
    payload: Dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        return f"Event(type={self.type}, timestamp={self.timestamp.isoformat()})"


class EventBus:
    """同步事件总线

    提供事件的发布/订阅功能，采用同步处理模式。
    支持线程安全的订阅和发布。

    Usage:
        # 订阅事件
        event_bus.subscribe("agent_start", on_agent_start)

        # 发布事件
        event_bus.publish(AgentStartEvent(payload={"session_id": "xxx"}))

        # 取消订阅
        event_bus.unsubscribe("agent_start", on_agent_start)
    """

    def __init__(self):
        self._handlers: Dict[str, List[Callable]] = {}
        self._lock = threading.RLock()
        self._logger = logging.getLogger(__name__)

    def subscribe(self, event_type: str, handler: Callable) -> None:
        """订阅事件

        Args:
            event_type: 事件类型（通常使用事件类名作为类型）
            handler: 事件处理函数，接受一个 Event 参数
        """
        with self._lock:
            if event_type not in self._handlers:
                self._handlers[event_type] = []
            if handler not in self._handlers[event_type]:
                self._handlers[event_type].append(handler)
                self._logger.debug(f"订阅事件: {event_type}, handler: {handler.__name__}")

    def unsubscribe(self, event_type: str, handler: Callable) -> None:
        """取消订阅

        Args:
            event_type: 事件类型
            handler: 要移除的处理函数
        """
        with self._lock:
            if event_type in self._handlers:
                if handler in self._handlers[event_type]:
                    self._handlers[event_type].remove(handler)
                    self._logger.debug(f"取消订阅: {event_type}, handler: {handler.__name__}")
                if not self._handlers[event_type]:
                    del self._handlers[event_type]

    def publish(self, event: Event) -> None:
        """发布事件

        同步调用所有订阅的处理函数。
        处理函数中的异常会被捕获并记录，但不会中断其他处理函数的执行。

        Args:
            event: 要发布的事件对象
        """
        event_type = type(event).__name__

        # 如果 payload 中没有 type，设置为类名
        if "type" not in event.payload:
            event.payload["type"] = event_type

        with self._lock:
            handlers = self._handlers.get(event_type, []).copy()

        if not handlers:
            self._logger.debug(f"无处理器订阅事件: {event_type}")
            return

        self._logger.debug(f"发布事件: {event_type}, 处理器数量: {len(handlers)}")

        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                self._logger.error(
                    f"事件处理器执行错误: {event_type}, handler: {handler.__name__}, error: {e}",
                    exc_info=True
                )

    def clear(self) -> None:
        """清除所有处理器"""
        with self._lock:
            self._handlers.clear()
            self._logger.debug("已清除所有事件处理器")

    def get_handlers(self, event_type: str) -> List[Callable]:
        """获取指定事件类型的处理器列表

        Args:
            event_type: 事件类型

        Returns:
            处理器列表（副本）
        """
        with self._lock:
            return self._handlers.get(event_type, []).copy()

    def list_subscriptions(self) -> Dict[str, int]:
        """列出所有订阅

        Returns:
            事件类型到处理器数量的映射
        """
        with self._lock:
            return {event_type: len(handlers) for event_type, handlers in self._handlers.items()}


# ============================================================================
# 全局事件总线实例
# ============================================================================

# 模块级别的全局事件总线，供各组件共享使用
_global_event_bus: EventBus = None


def get_event_bus() -> EventBus:
    """获取全局事件总线实例（单例）"""
    global _global_event_bus
    if _global_event_bus is None:
        _global_event_bus = EventBus()
    return _global_event_bus


def set_event_bus(bus: EventBus) -> None:
    """设置全局事件总线实例

    用于测试或自定义事件总线实现。

    Args:
        bus: 事件总线实例
    """
    global _global_event_bus
    _global_event_bus = bus
