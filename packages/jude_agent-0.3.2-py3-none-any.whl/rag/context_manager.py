"""Claude Code 上下文管理增强模块

管理 Claude Code 的对话上下文：
- 读取对话历史（从 JSONL 文件）
- 多维度阈值检测（消息数量、token 估算、主题漂移、时间间隔）
- 使用项目 LLM 进行摘要
- 存储为 YAML 头 + Markdown 内容格式
"""

import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from agent.prompts import get_loader

# 默认阈值配置（MiniMax M2.5 上下文为 200K tokens）
DEFAULT_THRESHOLDS = {
    "msg_count": 100,  # 消息数量阈值
    "token_estimate": 150000,  # 200K * 75%
    "topic_shift": 0.7,  # 语义相似度阈值
    "time_gap_minutes": 60,  # 时间间隔阈值
}

# 默认配置
DEFAULT_MEMORY_DIR = os.path.expanduser("~/.claude/projects/-Users-jude-Work-git-jude-rag/memory")
DEFAULT_PROJECT_PATH = "/Users/jude/Work/git/jude_rag"


@dataclass
class ContextMetrics:
    """上下文指标"""

    message_count: int = 0
    token_estimate: int = 0
    topic_shift_score: float = 1.0  # 1.0 表示无变化
    last_message_time: Optional[datetime] = None
    current_time: Optional[datetime] = None
    time_gap_minutes: float = 0


@dataclass
class ConversationMessage:
    """单条对话消息"""

    role: str  # "user" | "assistant"
    content: str
    timestamp: datetime
    message_type: str  # 原始消息类型


@dataclass
class MemoryMetadata:
    """记忆元数据"""

    version: int = 1
    updated_at: str = ""
    message_count: int = 0
    token_estimate: int = 0
    topics: List[str] = field(default_factory=list)
    needs_summary: bool = False


class ClaudeCodeContextManager:
    """Claude Code 上下文管理器

    负责：
    - 读取对话历史
    - 检测是否需要摘要
    - 生成对话摘要
    - 持久化存储
    """

    def __init__(
        self,
        project_path: str = DEFAULT_PROJECT_PATH,
        memory_dir: str = DEFAULT_MEMORY_DIR,
        thresholds: Dict[str, Any] = None,
    ):
        """
        初始化上下文管理器

        Args:
            project_path: 项目路径（用于加载 LLM 配置）
            memory_dir: 记忆存储目录
            thresholds: 阈值配置
        """
        self.project_path = project_path
        self.memory_dir = Path(memory_dir)
        self.thresholds = thresholds or DEFAULT_THRESHOLDS

        # 懒加载 LLM
        self._llm = None

        # 加载环境变量
        self._load_env()

    def _load_env(self):
        """加载项目环境变量"""
        env_path = Path(self.project_path) / ".env"
        if env_path.exists():
            from dotenv import load_dotenv

            load_dotenv(env_path)

    @property
    def llm(self):
        """获取 LLM（懒加载）"""
        if self._llm is None:
            from langchain_anthropic import ChatAnthropic

            api_key = os.getenv("ANTHROPIC_API_KEY", "")
            base_url = os.getenv("ANTHROPIC_BASE_URL", "https://api.minimaxi.com/anthropic")
            model = os.getenv("AGENT_MODEL", "MiniMax-M2.5")

            self._llm = ChatAnthropic(
                model=model,
                temperature=0.3,
                anthropic_api_key=api_key,
                base_url=base_url,
            )
        return self._llm

    def get_latest_session_jsonl(self) -> Optional[Path]:
        """获取最新的会话 JSONL 文件"""
        project_dir = Path(os.path.expanduser("~/.claude/projects/-Users-jude-Work-git-jude-rag"))

        if not project_dir.exists():
            return None

        # 查找最新的非目录 JSONL 文件
        jsonl_files = [
            (f, datetime.fromtimestamp(f.stat().st_mtime))
            for f in project_dir.glob("*.jsonl")
            if f.is_file()
        ]

        if not jsonl_files:
            return None

        # 返回最新的文件
        latest = max(jsonl_files, key=lambda x: x[1])
        return latest[0]

    def load_conversation_history(self, jsonl_path: Path = None) -> List[ConversationMessage]:
        """
        加载对话历史

        Args:
            jsonl_path: JSONL 文件路径（默认最新会话）

        Returns:
            对话消息列表
        """
        if jsonl_path is None:
            jsonl_path = self.get_latest_session_jsonl()

        if jsonl_path is None or not jsonl_path.exists():
            return []

        messages = []

        with open(jsonl_path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue

                try:
                    data = json.loads(line)

                    # 提取消息内容
                    msg_type = data.get("type", "")
                    message = data.get("message", {})

                    # 只处理用户和助手消息
                    role = message.get("role", "")
                    content_obj = message.get("content", [])

                    if role not in ("user", "assistant"):
                        continue

                    # 提取文本内容
                    content = ""
                    if isinstance(content_obj, list):
                        for item in content_obj:
                            if isinstance(item, dict) and item.get("type") == "text":
                                content = item.get("text", "")
                                break
                    elif isinstance(content_obj, str):
                        content = content_obj

                    if not content:
                        continue

                    # 解析时间戳
                    timestamp_str = data.get("timestamp", "")
                    try:
                        timestamp = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
                    except (ValueError, TypeError):
                        timestamp = datetime.now()

                    messages.append(
                        ConversationMessage(
                            role=role,
                            content=content,
                            timestamp=timestamp,
                            message_type=msg_type,
                        )
                    )
                except json.JSONDecodeError:
                    continue

        return messages

    def estimate_tokens(self, text: str) -> int:
        """
        估算 token 数量

        简单估算：中文约 1.5 字符/token，英文约 4 字符/token
        """
        # 中文字符
        chinese_chars = len(re.findall(r"[\u4e00-\u9fff]", text))
        # 非中文字符
        other_chars = len(text) - chinese_chars

        # 估算
        tokens = chinese_chars // 1.5 + other_chars // 4
        return int(tokens)

    def calculate_metrics(self, messages: List[ConversationMessage]) -> ContextMetrics:
        """
        计算上下文指标

        Returns:
            上下文指标
        """
        metrics = ContextMetrics()

        if not messages:
            return metrics

        # 1. 消息数量
        metrics.message_count = len(messages)

        # 2. Token 估算
        total_text = "\n".join([f"{msg.role}: {msg.content}" for msg in messages])
        metrics.token_estimate = self.estimate_tokens(total_text)

        # 3. 时间信息
        metrics.last_message_time = messages[-1].timestamp

        # 统一为 naive datetime
        last_time = metrics.last_message_time.replace(tzinfo=None)
        current_time = datetime.now()
        metrics.current_time = current_time

        if metrics.last_message_time:
            time_diff = current_time - last_time
            metrics.time_gap_minutes = time_diff.total_seconds() / 60

        # 4. 主题漂移检测（简化版：检查最新消息与历史消息的关键词变化）
        if len(messages) >= 10:
            # 提取最近 10 条消息的关键词
            recent_keywords = self._extract_keywords(
                " ".join([msg.content for msg in messages[-10:]])
            )
            # 提取早期消息的关键词
            early_keywords = self._extract_keywords(
                " ".join([msg.content for msg in messages[:10]])
            )

            if early_keywords and recent_keywords:
                # 计算交集比例
                overlap = len(set(recent_keywords) & set(early_keywords))
                total = len(set(recent_keywords) | set(early_keywords))
                metrics.topic_shift_score = overlap / total if total > 0 else 1.0
            else:
                metrics.topic_shift_score = 1.0
        else:
            metrics.topic_shift_score = 1.0

        return metrics

    def _extract_keywords(self, text: str, top_n: int = 10) -> List[str]:
        """提取关键词（简化版）"""
        # 移除常见停用词和特殊字符
        text = re.sub(r"[^\w\s]", " ", text)
        words = text.split()

        # 过滤短词
        words = [w for w in words if len(w) >= 2]

        # 统计词频
        word_freq = {}
        for word in words:
            word_freq[word] = word_freq.get(word, 0) + 1

        # 返回高频词
        sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
        return [w[0] for w in sorted_words[:top_n]]

    def should_summarize(self, metrics: ContextMetrics) -> bool:
        """
        判断是否需要摘要

        使用多维度加权评分
        """
        score = 0.0

        # 1. 消息数量评分
        if metrics.message_count >= self.thresholds["msg_count"]:
            score += 0.4

        # 2. Token 估算评分
        if metrics.token_estimate >= self.thresholds["token_estimate"]:
            score += 0.3

        # 3. 主题漂移评分
        if metrics.topic_shift_score < self.thresholds["topic_shift"]:
            score += 0.2

        # 4. 时间间隔评分
        if metrics.time_gap_minutes >= self.thresholds["time_gap_minutes"]:
            score += 0.1

        # 阈值：总分超过 0.5
        return score >= 0.5

    def generate_summary(self, messages: List[ConversationMessage]) -> str:
        """
        使用 LLM 生成对话摘要

        Args:
            messages: 对话消息列表

        Returns:
            生成的摘要
        """
        if not messages:
            return ""

        # 构建对话历史文本
        conversation_text = "\n".join(
            [f"{msg.role}: {msg.content}" for msg in messages]
        )

        # 摘要提示词
        loader = get_loader()
        default_prompt = f"""请简洁地总结以下 Claude Code 对话的关键要点：

{conversation_text}

请按以下格式输出：
1. 主要讨论话题
2. 关键决策或结论
3. 待处理事项（如果有）

摘要："""
        prompt = loader.get("claude_code_summary", default_prompt, conversation=conversation_text)

        try:
            from langchain_core.messages import HumanMessage

            response = self.llm.invoke([HumanMessage(content=prompt)])

            # 处理响应
            content = response.content
            if isinstance(content, list):
                summary = " ".join(
                    [
                        block.get("text", "")
                        for block in content
                        if isinstance(block, dict) and block.get("type") == "text"
                    ]
                ).strip()
            else:
                summary = content.strip()

            return summary
        except Exception as e:
            import logging

            logging.getLogger("context_manager").error(f"摘要生成失败: {e}")
            return ""

    def extract_topics(self, messages: List[ConversationMessage]) -> List[str]:
        """
        提取对话主题

        Args:
            messages: 对话消息列表

        Returns:
            主题列表
        """
        if not messages:
            return []

        # 使用关键词提取作为主题
        all_text = "\n".join([msg.content for msg in messages])
        keywords = self._extract_keywords(all_text, top_n=5)

        return keywords

    def save_memory(
        self,
        messages: List[ConversationMessage],
        summary: str = "",
        metadata: MemoryMetadata = None,
    ):
        """
        保存记忆到文件

        格式：YAML 头 + Markdown 内容

        Args:
            messages: 对话消息
            summary: 摘要
            metadata: 元数据
        """
        # 确保目录存在
        self.memory_dir.mkdir(parents=True, exist_ok=True)

        if metadata is None:
            metadata = MemoryMetadata()

        # 更新元数据
        metadata.updated_at = datetime.now().isoformat()
        metadata.message_count = len(messages)
        metadata.token_estimate = self.estimate_tokens(
            "\n".join([f"{msg.role}: {msg.content}" for msg in messages])
        )
        metadata.topics = self.extract_topics(messages)
        metadata.needs_summary = self.should_summarize(self.calculate_metrics(messages))

        # 构建文件内容
        yaml_header = yaml.dump(
            {
                "version": metadata.version,
                "updated_at": metadata.updated_at,
                "message_count": metadata.message_count,
                "token_estimate": metadata.token_estimate,
                "topics": metadata.topics,
                "needs_summary": metadata.needs_summary,
            },
            default_flow_style=False,
            allow_unicode=True,
        )

        # Markdown 内容
        content_lines = [
            "# 对话记忆",
            "",
            "## 摘要",
            summary or "（暂无摘要）",
            "",
            "## 最近消息",
            "",
        ]

        # 添加最近的消息（限制数量）
        recent_messages = messages[-20:] if len(messages) > 20 else messages
        for msg in recent_messages:
            role_emoji = "👤" if msg.role == "user" else "🤖"
            time_str = msg.timestamp.strftime("%Y-%m-%d %H:%M")
            content_lines.append(f"### {role_emoji} {time_str}")
            content_lines.append("")
            content_lines.append(msg.content[:500] + "..." if len(msg.content) > 500 else msg.content)
            content_lines.append("")

        # 写入文件
        memory_file = self.memory_dir / "MEMORY.md"
        with open(memory_file, "w", encoding="utf-8") as f:
            f.write("---\n")
            f.write(yaml_header)
            f.write("---\n")
            f.write("\n".join(content_lines))

    def load_memory(self) -> tuple[Optional[str], MemoryMetadata]:
        """
        加载记忆

        Returns:
            (摘要内容, 元数据)
        """
        memory_file = self.memory_dir / "MEMORY.md"

        if not memory_file.exists():
            return None, MemoryMetadata()

        with open(memory_file, "r", encoding="utf-8") as f:
            content = f.read()

        # 解析 YAML 头
        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                yaml_str = parts[1].strip()
                markdown_content = parts[2].strip()

                try:
                    metadata_dict = yaml.safe_load(yaml_str)
                    metadata = MemoryMetadata(
                        version=metadata_dict.get("version", 1),
                        updated_at=metadata_dict.get("updated_at", ""),
                        message_count=metadata_dict.get("message_count", 0),
                        token_estimate=metadata_dict.get("token_estimate", 0),
                        topics=metadata_dict.get("topics", []),
                        needs_summary=metadata_dict.get("needs_summary", False),
                    )
                except yaml.YAMLError:
                    metadata = MemoryMetadata()
                    markdown_content = content

                # 提取摘要
                summary = ""
                if "## 摘要" in markdown_content:
                    summary_parts = markdown_content.split("## 摘要", 1)
                    if len(summary_parts) > 1:
                        summary = summary_parts[1].split("##")[0].strip()

                return summary, metadata

        return None, MemoryMetadata()

    def check_and_summarize(self) -> Dict[str, Any]:
        """
        检查并执行摘要

        Returns:
            检查结果字典
        """
        # 1. 加载对话历史
        messages = self.load_conversation_history()

        if not messages:
            return {
                "status": "no_messages",
                "message": "没有找到对话历史",
            }

        # 2. 计算指标
        metrics = self.calculate_metrics(messages)

        # 3. 检查是否需要摘要
        needs_summary = self.should_summarize(metrics)

        result = {
            "status": "checked",
            "message_count": metrics.message_count,
            "token_estimate": metrics.token_estimate,
            "topic_shift_score": metrics.topic_shift_score,
            "time_gap_minutes": metrics.time_gap_minutes,
            "needs_summary": needs_summary,
        }

        # 4. 如果需要摘要，执行摘要
        if needs_summary:
            summary = self.generate_summary(messages)
            self.save_memory(messages, summary=summary)
            result["status"] = "summarized"
            result["summary"] = summary[:200] + "..." if len(summary) > 200 else summary
        else:
            # 仍然保存当前状态
            self.save_memory(messages)

        return result


# 便捷函数
def check_context():
    """快速检查上下文状态"""
    manager = ClaudeCodeContextManager()
    return manager.check_and_summarize()


if __name__ == "__main__":
    # 测试
    result = check_context()
    print(json.dumps(result, indent=2, ensure_ascii=False))
