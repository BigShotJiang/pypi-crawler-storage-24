"""RAG 模块

独立的 RAG 核心功能模块，包含：
- 文档加载 (loader)
- 文本分块 (chunker)
- 向量存储 (vectorstore)
- 检索器 (retriever)
- 问答系统 (qa)
- 配置 (config)
- RAG 服务 (service)
"""

from .config import (
    RAGConfig,
    config,
    EMBEDDING_MODEL,
    LLM_MODEL,
    CHUNK_SIZE,
    CHUNK_OVERLAP,
    TOP_K,
    CHUNK_STRATEGY,
    SEMANTIC_BREAKPOINT_THRESHOLD,
    SEMANTIC_BUFFER_SIZE,
    ANTHROPIC_API_KEY,
    ANTHROPIC_BASE_URL,
)

from .loader import DocumentLoader, load_documents

from .chunker import (
    ChunkStrategy,
    get_text_splitter,
    split_documents,
    select_strategy,
)

from .vectorstore import (
    VectorStoreManager,
    create_vector_store,
    load_vector_store,
)

from .retriever import (
    RetrievalStrategy,
    create_retriever,
    get_relevant_documents,
    RetrieverFactory,
)

from .qa import (
    QASystem,
    create_qa_system,
)

from .service import RAGService, create_rag_service, get_default_rag_service

__version__ = "0.3.0"

__all__ = [
    # 配置
    "RAGConfig",
    "config",
    "EMBEDDING_MODEL",
    "LLM_MODEL",
    "CHUNK_SIZE",
    "CHUNK_OVERLAP",
    "TOP_K",
    "CHUNK_STRATEGY",
    "SEMANTIC_BREAKPOINT_THRESHOLD",
    "SEMANTIC_BUFFER_SIZE",
    "ANTHROPIC_API_KEY",
    "ANTHROPIC_BASE_URL",
    # 加载器
    "DocumentLoader",
    "load_documents",
    # 分块器
    "ChunkStrategy",
    "get_text_splitter",
    "split_documents",
    "select_strategy",
    # 向量存储
    "VectorStoreManager",
    "create_vector_store",
    "load_vector_store",
    # 检索器
    "RetrievalStrategy",
    "create_retriever",
    "get_relevant_documents",
    "RetrieverFactory",
    # 问答系统
    "QASystem",
    "create_qa_system",
    # RAG 服务
    "RAGService",
    "create_rag_service",
    "get_default_rag_service",
]
