"""Claude Code 上下文管理增强 CLI

用法：
    uv run python -m rag.context_manager_cli check    # 检查上下文状态
    uv run python -m rag.context_manager_cli summarize # 强制生成摘要
    uv run python -m rag.context_manager_cli status   # 查看记忆状态
"""

import argparse
import json
import sys
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from rag.context_manager import ClaudeCodeContextManager


def cmd_check(args):
    """检查上下文状态"""
    manager = ClaudeCodeContextManager()
    result = manager.check_and_summarize()

    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


def cmd_summarize(args):
    """强制生成摘要"""
    manager = ClaudeCodeContextManager()

    # 加载最新会话
    jsonl_path = manager.get_latest_session_jsonl()
    if jsonl_path is None:
        print("错误：找不到会话文件")
        return 1

    messages = manager.load_conversation_history(jsonl_path)
    if not messages:
        print("错误：没有消息")
        return 1

    print(f"加载了 {len(messages)} 条消息")

    # 生成摘要
    summary = manager.generate_summary(messages)
    print(f"\n摘要：\n{summary}\n")

    # 保存
    manager.save_memory(messages, summary=summary)
    print("已保存到 memory/MEMORY.md")

    return 0


def cmd_status(args):
    """查看记忆状态"""
    manager = ClaudeCodeContextManager()

    # 加载记忆
    summary, metadata = manager.load_memory()

    print("=== 记忆状态 ===")
    print(f"版本: {metadata.version}")
    print(f"更新时间: {metadata.updated_at}")
    print(f"消息数: {metadata.message_count}")
    print(f"Token 估算: {metadata.token_estimate}")
    print(f"主题: {', '.join(metadata.topics)}")
    print(f"需要摘要: {metadata.needs_summary}")

    if summary:
        print(f"\n摘要:\n{summary[:500]}...")

    return 0


def main():
    parser = argparse.ArgumentParser(description="Claude Code 上下文管理")
    subparsers = parser.add_subparsers(dest="command", help="子命令")

    # check 命令
    subparsers.add_parser("check", help="检查上下文状态")

    # summarize 命令
    subparsers.add_parser("summarize", help="强制生成摘要")

    # status 命令
    subparsers.add_parser("status", help="查看记忆状态")

    args = parser.parse_args()

    if args.command == "check":
        return cmd_check(args)
    elif args.command == "summarize":
        return cmd_summarize(args)
    elif args.command == "status":
        return cmd_status(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
