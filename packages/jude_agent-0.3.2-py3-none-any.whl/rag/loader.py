"""文档加载模块

支持从目录加载文档：
- Markdown (.md)
- 纯文本 (.txt)
- 可扩展支持 PDF、HTML 等格式
"""

import logging
from pathlib import Path
from typing import List, Union, Optional

from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_community.document_loaders.markdown import UnstructuredMarkdownLoader
from langchain_core.documents import Document

logger = logging.getLogger("rag")


class DocumentLoader:
    """文档加载器"""

    def __init__(
        self,
        encoding: str = "utf-8",
        glob_pattern: str = "**/*.md",
    ):
        """
        初始化文档加载器

        Args:
            encoding: 文件编码
            glob_pattern: 文件匹配模式
        """
        self.encoding = encoding
        self.glob_pattern = glob_pattern

    def load(self, path: Union[str, Path]) -> List[Document]:
        """
        加载目录下的所有文档

        Args:
            path: 目录路径

        Returns:
            Document 列表
        """
        path = Path(path)
        logger.info(f"📂 正在加载文档: {path}")

        if not path.exists():
            raise FileNotFoundError(f"目录不存在: {path}")

        if path.is_file():
            return [self._load_file(path)]

        # 使用 DirectoryLoader 加载目录
        loader = DirectoryLoader(
            str(path),
            glob=self.glob_pattern,
            loader_cls=TextLoader,
            loader_kwargs={"encoding": self.encoding},
            show_progress=True,
        )

        documents = loader.load()
        logger.info(f"   ✅ 成功加载 {len(documents)} 个文档")
        return documents

    def _load_file(self, file_path: Path) -> Document:
        """加载单个文件"""
        suffix = file_path.suffix.lower()

        if suffix == ".md":
            loader = UnstructuredMarkdownLoader(
                str(file_path),
                encoding=self.encoding,
            )
        else:
            loader = TextLoader(
                str(file_path),
                encoding=self.encoding,
            )

        docs = loader.load()
        return docs[0] if docs else None


def load_documents(
    data_dir: Union[str, Path],
    glob_pattern: str = "**/*.md",
    encoding: str = "utf-8",
) -> List[Document]:
    """
    便捷函数：加载目录下的文档

    Args:
        data_dir: 数据目录
        glob_pattern: 文件匹配模式
        encoding: 文件编码

    Returns:
        Document 列表
    """
    loader = DocumentLoader(encoding=encoding, glob_pattern=glob_pattern)
    return loader.load(data_dir)
