"""RAG 配置模块

本模块已废弃，请使用 src.config.rag
保留此模块仅为向后兼容
"""

# 向后兼容：从新模块导入
from config.rag import RAGConfig, config as _config
from config.rag import (
    EMBEDDING_MODEL,
    LLM_MODEL,
    CHUNK_SIZE,
    CHUNK_OVERLAP,
    TOP_K,
    CHUNK_STRATEGY,
    SEMANTIC_BREAKPOINT_THRESHOLD,
    SEMANTIC_BUFFER_SIZE,
    ANTHROPIC_API_KEY,
    ANTHROPIC_BASE_URL,
)

# 重新导出，保持 API 不变
config = _config

__all__ = [
    "config",
    "RAGConfig",
    "EMBEDDING_MODEL",
    "LLM_MODEL",
    "CHUNK_SIZE",
    "CHUNK_OVERLAP",
    "TOP_K",
    "CHUNK_STRATEGY",
    "SEMANTIC_BREAKPOINT_THRESHOLD",
    "SEMANTIC_BUFFER_SIZE",
    "ANTHROPIC_API_KEY",
    "ANTHROPIC_BASE_URL",
]
