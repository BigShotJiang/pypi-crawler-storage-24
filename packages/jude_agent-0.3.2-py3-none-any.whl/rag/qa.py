"""问答系统模块

支持基于 RAG 的问答：
- 可配置的 LLM
- 支持流式输出
- 返回源文档
"""

import logging
from typing import Any, Dict, List, Optional, Union

from langchain_core.language_models import BaseChatModel
from langchain_core.retrievers import BaseRetriever
from langchain_core.runnables import Runnable
from langchain_anthropic import ChatAnthropic

from .config import (
    LLM_MODEL,
    ANTHROPIC_API_KEY,
    ANTHROPIC_BASE_URL,
    TOP_K,
)

logger = logging.getLogger("rag")


class QASystem:
    """问答系统"""

    def __init__(
        self,
        llm: Optional[BaseChatModel] = None,
        retriever: Optional[BaseRetriever] = None,
        chain_type: str = "stuff",
        return_source_documents: bool = True,
    ):
        """
        初始化问答系统

        Args:
            llm: 大语言模型（如果为 None，会自动创建）
            retriever: 检索器（如果为 None，会自动创建）
            chain_type: 链类型
            return_source_documents: 是否返回源文档
        """
        self._llm = llm
        self._retriever = retriever
        self._qa_chain: Optional[Runnable] = None
        self.chain_type = chain_type
        self.return_source_documents = return_source_documents

    @property
    def llm(self) -> BaseChatModel:
        """获取 LLM"""
        if self._llm is None:
            self._llm = self._create_default_llm()
        return self._llm

    @property
    def retriever(self) -> BaseRetriever:
        """获取检索器"""
        if self._retriever is None:
            raise RuntimeError("检索器未设置")
        return self._retriever

    def _create_default_llm(self) -> ChatAnthropic:
        """创建默认 LLM"""
        return ChatAnthropic(
            model=LLM_MODEL,
            temperature=0.7,
            anthropic_api_key=ANTHROPIC_API_KEY,
            base_url=ANTHROPIC_BASE_URL,
        )

    def setup(self, retriever: BaseRetriever, llm: Optional[BaseChatModel] = None):
        """
        设置问答链

        Args:
            retriever: 检索器
            llm: LLM（可选）
        """
        if llm is not None:
            self._llm = llm

        self._retriever = retriever
        self._qa_chain = None  # 重置链

    def _get_qa_chain(self) -> Runnable:
        """获取或创建问答链"""
        if self._qa_chain is not None:
            return self._qa_chain

        if self._retriever is None:
            raise RuntimeError("请先设置检索器")

        from langchain_classic.chains import RetrievalQA

        self._qa_chain = RetrievalQA.from_chain_type(
            llm=self.llm,
            retriever=self._retriever,
            chain_type=self.chain_type,
            return_source_documents=self.return_source_documents,
            verbose=True,
        )

        logger.info("   ✅ 问答系统设置完成")
        return self._qa_chain

    def invoke(self, query: str) -> Dict[str, Any]:
        """
        执行问答

        Args:
            query: 用户问题

        Returns:
            包含 answer 和 source_documents 的字典
        """
        qa_chain = self._get_qa_chain()
        return qa_chain.invoke(query)

    def stream(self, query: str):
        """
        流式输出回答

        Args:
            query: 用户问题
        """
        qa_chain = self._get_qa_chain()

        # 使用 stream 方法
        for chunk in qa_chain.stream(query):
            if "result" in chunk:
                yield chunk["result"]


def create_qa_system(
    retriever: BaseRetriever,
    llm: Optional[BaseChatModel] = None,
    llm_model: str = LLM_MODEL,
    api_key: str = ANTHROPIC_API_KEY,
    base_url: str = ANTHROPIC_BASE_URL,
    chain_type: str = "stuff",
    return_source_documents: bool = True,
) -> QASystem:
    """
    便捷函数：创建问答系统

    Args:
        retriever: 检索器
        llm: LLM（可选）
        llm_model: LLM 模型名称
        api_key: API 密钥
        base_url: API 基础 URL
        chain_type: 链类型
        return_source_documents: 是否返回源文档

    Returns:
        QASystem 实例
    """
    # 创建 LLM（如果未提供）
    if llm is None:
        llm = ChatAnthropic(
            model=llm_model,
            temperature=0.7,
            anthropic_api_key=api_key,
            base_url=base_url,
        )

    qa_system = QASystem(
        llm=llm,
        chain_type=chain_type,
        return_source_documents=return_source_documents,
    )
    qa_system.setup(retriever)

    return qa_system
