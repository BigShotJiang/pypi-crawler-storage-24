"""分块策略模块

支持多种分块策略：
- RECURSIVE: 递归分块（默认）
- MARKDOWN: Markdown 文档分块
- MARKDOWN_HEADERS: 按标题层级分块
- SEMANTIC: 基于嵌入相似度的语义分块
- SPACY: 基于 spaCy 的句子分割
- NLTK: 基于 NLTK 的句子分割
"""

import logging
import re
from pathlib import Path
from typing import List, Optional, Dict, Any

from langchain_text_splitters import (
    RecursiveCharacterTextSplitter,
    MarkdownHeaderTextSplitter,
    MarkdownTextSplitter,
    NLTKTextSplitter,
)
from langchain_experimental.text_splitter import SemanticChunker
from langchain_ollama import OllamaEmbeddings

from agent.prompts import get_loader

# spaCy 是可选依赖
try:
    from langchain_text_splitters import SpacyTextSplitter
    SPACY_AVAILABLE = True
except ImportError:
    SPACY_AVAILABLE = False

# spaCy 中文模型（自动检查和安装）
SPACY_MODEL = "zh_core_web_sm"
from .config import (
    CHUNK_SIZE,
    CHUNK_OVERLAP,
    SEMANTIC_BREAKPOINT_THRESHOLD,
    SEMANTIC_BUFFER_SIZE,
    EMBEDDING_MODEL,
)

logger = logging.getLogger("rag")


def _get_recursive_splitter(config: dict) -> RecursiveCharacterTextSplitter:
    """获取递归分块器（回退用）"""
    default_config = CHUNK_CONFIGS[ChunkStrategy.RECURSIVE]
    return RecursiveCharacterTextSplitter(
        chunk_size=config.get("chunk_size", default_config["chunk_size"]),
        chunk_overlap=config.get("chunk_overlap", default_config["chunk_overlap"]),
        separators=default_config["separators"],
        length_function=default_config["length_function"],
    )


class ChunkStrategy:
    """分块策略常量"""

    RECURSIVE = "recursive"
    MARKDOWN = "markdown"
    MARKDOWN_HEADERS = "headers"
    SEMANTIC = "semantic"
    SPACY = "spacy"
    NLTK = "nltk"
    LLM = "llm"           # LLM 驱动分块
    HYBRID = "hybrid"     # 混合分块策略


# 各策略的默认配置
CHUNK_CONFIGS = {
    ChunkStrategy.RECURSIVE: {
        "chunk_size": CHUNK_SIZE,
        "chunk_overlap": CHUNK_OVERLAP,
        "separators": ["\n\n", "\n", "。", "！", "？", ".", "!", "?", " "],
        "length_function": len,
    },
    ChunkStrategy.MARKDOWN: {
        "chunk_size": CHUNK_SIZE,
        "chunk_overlap": CHUNK_OVERLAP,
        "length_function": len,
    },
    ChunkStrategy.MARKDOWN_HEADERS: {
        "headers_to_split_on": [
            ("#", "H1"),
            ("##", "H2"),
            ("###", "H3"),
            ("####", "H4"),
        ],
        "chunk_size": CHUNK_SIZE,
        "chunk_overlap": CHUNK_OVERLAP,
        "length_function": len,
    },
    ChunkStrategy.SEMANTIC: {
        "breakpoint_threshold_percentile": SEMANTIC_BREAKPOINT_THRESHOLD,
        "buffer_size": SEMANTIC_BUFFER_SIZE,
    },
    ChunkStrategy.SPACY: {
        "chunk_size": CHUNK_SIZE,
        "chunk_overlap": CHUNK_OVERLAP,
        "pipeline": "zh_core_web_sm",  # 默认中文模型
    },
    ChunkStrategy.NLTK: {
        "chunk_size": CHUNK_SIZE,
        "chunk_overlap": CHUNK_OVERLAP,
    },
    ChunkStrategy.LLM: {
        "chunk_size": CHUNK_SIZE,
        "chunk_overlap": CHUNK_OVERLAP,
        "llm_model": "MiniMax-M2.2",  # 默认 LLM 模型
        "threshold": 0.7,  # 相似度阈值
    },
    ChunkStrategy.HYBRID: {
        "chunk_size": CHUNK_SIZE,
        "chunk_overlap": CHUNK_OVERLAP,
        "strategies": ["spacy", "recursive"],  # 默认混合策略
    },
}


def get_text_splitter(
    strategy: str = ChunkStrategy.RECURSIVE,
    embedding_model: str = EMBEDDING_MODEL,
    **kwargs
):
    """
    工厂函数：根据策略返回对应的 text_splitter

    参数:
        strategy: 分块策略名称（支持 "recursive", "RECURSIVE", ChunkStrategy.RECURSIVE 等格式）
        embedding_model: 嵌入模型名称（用于语义分块）
        **kwargs: 覆盖默认配置的参数

    返回:
        实现了 split_documents 方法的 text_splitter
    """
    # 规范化策略名称（支持大小写不敏感）
    strategy = strategy.lower() if isinstance(strategy, str) else strategy

    # 尝试匹配 ChunkStrategy 常量
    strategy_map = {
        "recursive": ChunkStrategy.RECURSIVE,
        "markdown": ChunkStrategy.MARKDOWN,
        "headers": ChunkStrategy.MARKDOWN_HEADERS,
        "semantic": ChunkStrategy.SEMANTIC,
        "spacy": ChunkStrategy.SPACY,
        "nltk": ChunkStrategy.NLTK,
        "llm": ChunkStrategy.LLM,
        "hybrid": ChunkStrategy.HYBRID,
    }
    normalized_strategy = strategy_map.get(strategy, strategy)

    logger.info(f"🎯 选择分块策略: {normalized_strategy}")

    config = CHUNK_CONFIGS.get(normalized_strategy, CHUNK_CONFIGS[ChunkStrategy.RECURSIVE]).copy()
    config.update(kwargs)

    if strategy == ChunkStrategy.RECURSIVE:
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=config["chunk_size"],
            chunk_overlap=config["chunk_overlap"],
            separators=config["separators"],
            length_function=config["length_function"],
        )
    elif strategy == ChunkStrategy.MARKDOWN:
        splitter = MarkdownTextSplitter(
            chunk_size=config["chunk_size"],
            chunk_overlap=config["chunk_overlap"],
            length_function=config["length_function"],
        )
    elif strategy == ChunkStrategy.MARKDOWN_HEADERS:
        splitter = MarkdownHeaderTextSplitter(
            headers_to_split_on=config["headers_to_split_on"]
        )
        # MarkdownHeaderTextSplitter 需要包装一下以支持 from_documents
        return HeadersAwareSplitter(splitter, config)
    elif strategy == ChunkStrategy.SEMANTIC:
        # 创建 embeddings 模型用于语义分块
        embeddings = OllamaEmbeddings(model=embedding_model)
        splitter = SemanticChunker(
            embeddings=embeddings,
            breakpoint_threshold_type="percentile",
            breakpoint_threshold_amount=config["breakpoint_threshold_percentile"],
            buffer_size=config.get("buffer_size", 1),
        )
        logger.info(f"🔍 使用语义分块，阈值: {config['breakpoint_threshold_percentile']}%")
    elif strategy == ChunkStrategy.SPACY:
        if not SPACY_AVAILABLE:
            logger.warning("⚠️ spaCy 未安装，使用递归分块")
            splitter = _get_recursive_splitter(config)
        else:
            # 尝试加载模型
            model_name = config.get("pipeline", SPACY_MODEL)
            try:
                splitter = SpacyTextSplitter(
                    chunk_size=config["chunk_size"],
                    chunk_overlap=config["chunk_overlap"],
                    pipeline=model_name,
                )
                # 测试是否能用
                splitter.split_text("测试。")
                logger.info(f"📝 使用 spaCy 分块，模型: {model_name}")
            except Exception as e:
                # 加载失败，回退到递归分块
                logger.warning(f"⚠️ spaCy 模型加载失败: {e}，使用递归分块")
                splitter = _get_recursive_splitter(config)
    elif strategy == ChunkStrategy.NLTK:
        try:
            splitter = NLTKTextSplitter(
                chunk_size=config["chunk_size"],
                chunk_overlap=config["chunk_overlap"],
            )
            # 测试是否能正常工作
            splitter.split_text("测试。")
            logger.info("📝 使用 NLTK 分块")
        except Exception as e:
            logger.warning(f"⚠️ NLTK 不可用: {e}，使用递归分块")
            # 回退到递归分块
            default_config = CHUNK_CONFIGS[ChunkStrategy.RECURSIVE]
            splitter = RecursiveCharacterTextSplitter(
                chunk_size=config["chunk_size"],
                chunk_overlap=config["chunk_overlap"],
                separators=default_config["separators"],
                length_function=default_config["length_function"],
            )
    elif strategy == ChunkStrategy.LLM:
        # LLM 驱动分块：使用 LLM 识别语义边界
        splitter = LLMChunker(
            chunk_size=config["chunk_size"],
            chunk_overlap=config["chunk_overlap"],
            llm_model=config.get("llm_model", "MiniMax-M2.2"),
            threshold=config.get("threshold", 0.7),
        )
        logger.info(f"🤖 使用 LLM 驱动分块，模型: {config.get('llm_model')}")
    elif strategy == ChunkStrategy.HYBRID:
        # 混合分块：结合多种策略
        splitter = HybridChunker(
            chunk_size=config["chunk_size"],
            chunk_overlap=config["chunk_overlap"],
            strategies=config.get("strategies", ["spacy", "recursive"]),
        )
        logger.info(f"🔀 使用混合分块策略: {config.get('strategies')}")
    else:
        logger.warning(f"⚠️ 未知策略 {strategy}，使用默认递归分块")
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=config["chunk_size"],
            chunk_overlap=config["chunk_overlap"],
            separators=config["separators"],
            length_function=config["length_function"],
        )

    return splitter


class HeadersAwareSplitter:
    """MarkdownHeaderTextSplitter 的包装器，支持 split_documents 方法"""

    def __init__(self, header_splitter, config):
        self.header_splitter = header_splitter
        self.config = config

    def split_documents(self, documents):
        """分块文档，支持 Headers 级别的重叠处理"""
        all_chunks = []
        for doc in documents:
            # 先按 header 分割
            chunks = self.header_splitter.split_text(doc.page_content)
            # 添加元数据
            for chunk in chunks:
                chunk.metadata = {**doc.metadata, **chunk.metadata}
                all_chunks.append(chunk)

        # 如果需要重叠，进行二次处理
        if self.config.get("chunk_overlap", 0) > 0:
            all_chunks = self._apply_overlap(all_chunks)

        return all_chunks

    def _apply_overlap(self, chunks):
        """应用重叠"""
        if not chunks:
            return chunks

        overlap = self.config.get("chunk_overlap", 0)
        if overlap <= 0:
            return chunks

        result = [chunks[0]]
        for i in range(1, len(chunks)):
            prev_chunk = result[-1]
            curr_chunk = chunks[i]

            # 如果前一个块超过 overlap 大小，截取末尾
            if len(prev_chunk.page_content) > overlap:
                overlap_text = prev_chunk.page_content[-overlap:]
            else:
                overlap_text = prev_chunk.page_content

            # 合并重叠
            merged_content = overlap_text + "\n" + curr_chunk.page_content
            from langchain_core.documents import Document

            result.append(
                Document(
                    page_content=merged_content,
                    metadata=curr_chunk.metadata
                )
            )

        return result


def split_documents(
    documents,
    strategy: str = ChunkStrategy.RECURSIVE,
    chunk_size: int = CHUNK_SIZE,
    chunk_overlap: int = CHUNK_OVERLAP,
    embedding_model: str = EMBEDDING_MODEL,
):
    """
    便捷函数：分块文档

    Args:
        documents: 原始文档列表
        strategy: 分块策略
        chunk_size: 块大小
        chunk_overlap: 重叠大小
        embedding_model: 嵌入模型

    Returns:
        分块后的文档列表
    """
    text_splitter = get_text_splitter(
        strategy=strategy,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        embedding_model=embedding_model,
    )
    return text_splitter.split_documents(documents)


def select_strategy(file_path: Path, content: str = None) -> str:
    """
    智能选择分块策略

    参数:
        file_path: 文件路径
        content: 文件内容（可选，用于进一步判断）

    返回:
        建议的分块策略
    """
    params = auto_tune_params(file_path, content)
    return params["strategy"]


def auto_tune_params(file_path: Path, content: str = None) -> Dict[str, Any]:
    """
    根据文档特征自动选择最优参数

    参数:
        file_path: 文件路径
        content: 文件内容（用于分析特征）

    返回:
        包含 strategy, chunk_size, chunk_overlap 等参数的字典
    """
    # 默认参数
    params = {
        "strategy": ChunkStrategy.RECURSIVE,
        "chunk_size": CHUNK_SIZE,
        "chunk_overlap": int(CHUNK_SIZE * 0.15),  # 默认为 chunk_size 的 15%
    }

    if not content:
        return params

    suffix = file_path.suffix.lower()
    content_length = len(content)

    # 1. 根据文件类型和内容结构选择策略
    if suffix in [".md", ".markdown"]:
        # 检查标题结构
        h1_count = content.count("\n# ")
        h2_count = content.count("\n## ")
        h3_count = content.count("\n### ")

        if h2_count >= 2:
            params["strategy"] = ChunkStrategy.MARKDOWN_HEADERS
            logger.info(f"📊 检测到多级标题结构 (H2: {h2_count}个)，选择 MARKDOWN_HEADERS")
        elif "#" in content:
            params["strategy"] = ChunkStrategy.MARKDOWN
            logger.info("📄 检测到 Markdown 格式，选择 MARKDOWN")

    # 2. 根据内容长度调整 chunk_size 和 overlap
    if content_length < 2000:
        # 短文档：用较小的块，更精确
        params["chunk_size"] = 256
        params["chunk_overlap"] = 38
    elif content_length > 10000:
        # 长文档：用较大的块，保留更多上下文
        params["chunk_size"] = 800
        params["chunk_overlap"] = 120
    else:
        # 中等长度文档
        params["chunk_size"] = 500
        params["chunk_overlap"] = 75

    # 3. 检测代码块比例，如果代码占比高使用混合分块
    code_pattern = r'```[\s\S]*?```'
    code_matches = re.findall(code_pattern, content)
    if code_matches:
        code_length = sum(len(m) for m in code_matches)
        code_ratio = code_length / content_length
        if code_ratio > 0.3:
            params["strategy"] = ChunkStrategy.HYBRID
            logger.info(f"📦 检测到高代码比例 ({code_ratio:.1%})，使用混合分块")

    # 4. 检测是否适合 spaCy（中文文档）
    if suffix not in [".md", ".markdown"] and not code_matches:
        # 非 Markdown 且代码不多，尝试 spaCy
        chinese_ratio = sum(1 for c in content[:1000] if '\u4e00' <= c <= '\u9fff') / min(1000, len(content))
        if chinese_ratio > 0.3:
            params["strategy"] = ChunkStrategy.SPACY
            logger.info(f"📝 检测到高中文比例 ({chinese_ratio:.1%})，优先使用 spaCy 分块")

    return params


class LLMChunker:
    """LLM 驱动分块器

    使用 LLM 识别语义边界，将文本分割成语义连贯的块。
    """

    def __init__(
        self,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        llm_model: str = "MiniMax-M2.2",
        threshold: float = 0.7,
    ):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.llm_model = llm_model
        self.threshold = threshold
        self._llm = None

    @property
    def llm(self):
        """懒加载 LLM"""
        if self._llm is None:
            from langchain_ollama import ChatOllama
            self._llm = ChatOllama(
                model=self.llm_model,
                temperature=0.3,
            )
        return self._llm

    def split_documents(self, documents):
        """分块文档"""
        from langchain_core.documents import Document

        all_chunks = []
        for doc in documents:
            chunks = self._split_text(doc.page_content)
            for chunk_text in chunks:
                all_chunks.append(
                    Document(
                        page_content=chunk_text,
                        metadata=doc.metadata.copy()
                    )
                )
        return all_chunks

    def _split_text(self, text: str) -> List[str]:
        """使用 LLM 分割文本"""
        # 如果文本很短，直接返回
        if len(text) < self.chunk_size:
            return [text]

        # 将文本分成较小的段落
        paragraphs = self._split_into_paragraphs(text)
        if len(paragraphs) <= 1:
            return [text]

        # 使用 LLM 判断是否应该合并相邻段落
        chunks = [paragraphs[0]]
        for para in paragraphs[1:]:
            # 构建判断 prompt
            prompt = self._build_merge_prompt(chunks[-1], para)

            try:
                response = self.llm.invoke(prompt)
                should_merge = self._parse_response(response.content)

                if should_merge:
                    # 合并到当前块（如果不超过大小限制）
                    if len(chunks[-1]) + len(para) < self.chunk_size * 1.5:
                        chunks[-1] = chunks[-1] + "\n\n" + para
                    else:
                        # 新建一个块
                        chunks.append(para)
                else:
                    chunks.append(para)
            except Exception as e:
                logger.warning(f"LLM 分块失败: {e}，使用简单分块")
                # 回退到简单分块
                return self._simple_split(text)

        # 应用 overlap
        return self._apply_overlap(chunks)

    def _split_into_paragraphs(self, text: str) -> List[str]:
        """将文本分割成段落"""
        # 按双换行符分割
        paragraphs = re.split(r'\n\n+', text)
        # 过滤空段落
        return [p.strip() for p in paragraphs if p.strip()]

    def _build_merge_prompt(self, text1: str, text2: str) -> str:
        """构建判断是否合并的 prompt"""
        default_prompt = f"""请判断以下两段文本是否属于同一个主题/话题，应该合并为一个语义连贯的块。

第一段:
{text1[:200]}

第二段:
{text2[:200]}

请只回答"是"或"否"，不要其他内容。"""
        loader = get_loader()
        return loader.get(
            "chunk_merge",
            default_prompt,
            text1=text1[:200],
            text2=text2[:200]
        )

    def _parse_response(self, response: str) -> bool:
        """解析 LLM 响应"""
        response = response.strip().lower()
        return "是" in response or "yes" in response or "true" in response

    def _simple_split(self, text: str) -> List[str]:
        """简单分块作为回退"""
        chunks = []
        start = 0
        while start < len(text):
            end = start + self.chunk_size
            chunks.append(text[start:end])
            start = end - self.chunk_overlap
        return chunks

    def _apply_overlap(self, chunks: List[str]) -> List[str]:
        """应用 overlap"""
        if not chunks or self.chunk_overlap <= 0:
            return chunks

        result = [chunks[0]]
        for chunk in chunks[1:]:
            # 获取前一个块的末尾部分
            overlap_text = result[-1][-self.chunk_overlap:]
            merged = overlap_text + "\n" + chunk
            result.append(merged)

        return result


class HybridChunker:
    """混合分块器

    结合多种分块策略，根据内容类型选择最合适的分块方式。
    代码块和表格保持完整，普通文本使用配置的策略分割。
    """

    def __init__(
        self,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        strategies: List[str] = None,
    ):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.strategies = strategies or ["spacy", "recursive"]

    def split_documents(self, documents):
        """分块文档"""
        from langchain_core.documents import Document

        all_chunks = []
        for doc in documents:
            chunks = self._split_text(doc.page_content)
            for chunk_text in chunks:
                all_chunks.append(
                    Document(
                        page_content=chunk_text,
                        metadata=doc.metadata.copy()
                    )
                )
        return all_chunks

    def _split_text(self, text: str) -> List[Dict]:
        """混合分块，返回带类型的分块列表"""
        # 1. 首先识别并分离特殊结构（代码块、表格）
        segments = self._preprocess_segments(text)

        result = []
        for segment in segments:
            if segment["type"] == "code":
                # 代码块保持完整
                result.append({
                    "type": "code",
                    "content": segment["content"]
                })
            elif segment["type"] == "table":
                # 表格保持完整
                result.append({
                    "type": "table",
                    "content": segment["content"]
                })
            else:
                # 普通文本使用配置的策略
                text_chunks = self._split_with_strategy(segment["content"])
                for chunk in text_chunks:
                    result.append({
                        "type": "text",
                        "content": chunk
                    })

        # 合并连续相同类型的块，并应用 overlap
        return self._merge_and_overlap(result)

    def _preprocess_segments(self, text: str) -> List[Dict]:
        """预处理：分离代码块、标题和普通文本"""
        segments = []
        last_end = 0

        # 匹配代码块 - 支持有语言标识和无语言标识
        code_pattern = r'```[\s\S]*?```'

        # 匹配 Markdown 标题
        header_pattern = r'^#{1,6}\s+.+$'

        for match in re.finditer(code_pattern, text):
            # 添加前面的内容，先分离标题
            if match.start() > last_end:
                before_text = text[last_end:match.start()]
                text_segments = self._extract_headers_and_text(before_text)
                segments.extend(text_segments)

            # 添加代码块
            segments.append({
                "type": "code",
                "content": match.group(0)
            })
            last_end = match.end()

        # 添加剩余的内容
        if last_end < len(text):
            remaining = text[last_end:]
            text_segments = self._extract_headers_and_text(remaining)
            segments.extend(text_segments)

        # 如果没有匹配到任何内容，整个作为普通文本
        if not segments:
            segments = [{"type": "text", "content": text}]

        return segments

    def _extract_headers_and_text(self, text: str) -> List[Dict]:
        """从文本中提取标题和普通文本"""
        segments = []
        if not text.strip():
            return segments

        lines = text.split('\n')
        current_text = []

        for line in lines:
            # 检测 Markdown 标题
            if re.match(r'^#{1,6}\s+', line):
                # 保存之前的文本
                if current_text:
                    text_content = '\n'.join(current_text).strip()
                    if text_content:
                        segments.append({"type": "text", "content": text_content})
                    current_text = []
                # 添加标题
                segments.append({"type": "header", "content": line})
            else:
                current_text.append(line)

        # 保存剩余的文本
        if current_text:
            text_content = '\n'.join(current_text).strip()
            if text_content:
                segments.append({"type": "text", "content": text_content})

        return segments if segments else [{"type": "text", "content": text}]

    def _extract_tables(self, text: str) -> List[Dict]:
        """从文本中提取表格"""
        segments = []
        if not text.strip():
            return segments

        # 简单的表格检测：检查是否有 | 符号且有分隔符
        lines = text.split('\n')
        current_text = []

        for line in lines:
            # 检测表格行（包含 | 且有 - 分隔符或多个 |）
            if '|' in line and (re.match(r'\|[\s:-]+\|', line) or line.count('|') > 1):
                if current_text:
                    # 保存之前的文本
                    text_content = '\n'.join(current_text)
                    if text_content.strip():
                        segments.append({"type": "text", "content": text_content})
                    current_text = []
                # 添加表格
                segments.append({"type": "table", "content": line})
            else:
                current_text.append(line)

        # 保存剩余的文本
        if current_text:
            text_content = '\n'.join(current_text)
            if text_content.strip():
                segments.append({"type": "text", "content": text_content})

        return segments if segments else [{"type": "text", "content": text}]

    def _split_with_strategy(self, text: str) -> List[str]:
        """使用指定策略分块，保护 Markdown 标题"""
        if not text or not text.strip():
            return []

        # 检查是否包含 Markdown 标题
        has_header = bool(re.search(r'^#{1,6}\s+', text, re.MULTILINE))

        # 如果文本很短或者包含标题，使用特殊处理
        if len(text) < self.chunk_size or has_header:
            # 直接返回整个文本作为一个块
            return [text]

        # 尝试使用第一个可用的策略
        for strategy_name in self.strategies:
            try:
                if strategy_name == "spacy":
                    if SPACY_AVAILABLE:
                        splitter = SpacyTextSplitter(
                            chunk_size=self.chunk_size,
                            chunk_overlap=self.chunk_overlap,
                            pipeline="zh_core_web_sm"
                        )
                        result = splitter.split_text(text)
                        return result.tolist() if hasattr(result, 'tolist') else result
                elif strategy_name == "recursive":
                    # 使用保护标题的分隔符
                    splitter = RecursiveCharacterTextSplitter(
                        chunk_size=self.chunk_size,
                        chunk_overlap=self.chunk_overlap,
                        # 优先按段落分割，保护标题
                        separators=["\n\n", "## ", "### ", "#### ", "##### ", "###### ", "\n", "。", "！", "？", ".", "!", "?", " "],
                    )
                    return splitter.split_text(text)
                elif strategy_name == "nltk":
                    splitter = NLTKTextSplitter(
                        chunk_size=self.chunk_size,
                        chunk_overlap=self.chunk_overlap,
                    )
                    return splitter.split_text(text)
            except Exception as e:
                logger.warning(f"策略 {strategy_name} 失败: {e}，尝试下一个")
                continue

        # 所有策略都失败，使用简单分块
        return self._simple_split(text)

    def _simple_split(self, text: str) -> List[str]:
        """简单分块作为回退"""
        chunks = []
        start = 0
        while start < len(text):
            end = min(start + self.chunk_size, len(text))
            chunks.append(text[start:end])
            start = end - self.chunk_overlap if end < len(text) else end
        return chunks

    def _merge_and_overlap(self, segments: List[Dict]) -> List[str]:
        """合并相邻的同类型块，并应用 overlap（不跨代码块/表格/标题）"""
        if not segments:
            return []

        # 1. 合并标题到后面的文本
        merged = []
        for seg in segments:
            if seg["type"] == "header":
                # 标题暂时不添加，等后面和文本合并
                merged.append(seg.copy())
            elif seg["type"] == "text":
                if merged and merged[-1]["type"] == "header":
                    # 合并标题到文本
                    merged[-1]["content"] = merged[-1]["content"] + "\n\n" + seg["content"]
                    merged[-1]["type"] = "text"  # 变成文本类型
                else:
                    merged.append(seg.copy())
            else:
                # 代码块、表格直接添加
                merged.append(seg.copy())

        # 2. 合并相邻的文本块
        final_segments = []
        for seg in merged:
            if seg["type"] == "text" and final_segments and final_segments[-1]["type"] == "text":
                final_segments[-1]["content"] = final_segments[-1]["content"] + "\n\n" + seg["content"]
            else:
                final_segments.append(seg.copy())

        # 3. 应用 overlap（只在文本块之间应用）
        result = []
        prev_type = None

        for seg in final_segments:
            if seg["type"] == "text":
                if result and self.chunk_overlap > 0 and prev_type == "text":
                    # 前一个是文本块，添加 overlap
                    prev_content = result[-1]
                    if len(prev_content) > self.chunk_overlap:
                        overlap = prev_content[-self.chunk_overlap:]
                    else:
                        overlap = prev_content
                    result.append(overlap + "\n" + seg["content"])
                else:
                    result.append(seg["content"])
            else:
                # 代码块、表格、标题直接添加，不做 overlap
                result.append(seg["content"])

            prev_type = seg["type"]

            prev_type = seg["type"]

        return result


# ============ 质量优化函数 ============

def merge_small_chunks(
    chunks: List,
    min_size: int = 20,
    min_words: int = 3,
) -> List:
    """合并太小的块到前一个块

    只有当块非常小（如单个标题、单个字符）时才合并。

    参数:
        chunks: 分块后的文档列表
        min_size: 最小字符数阈值
        min_words: 最小词数

    返回:
        合并后的文档列表
    """
    from langchain_core.documents import Document

    if not chunks or len(chunks) <= 1:
        return chunks

    result = [chunks[0]]

    for chunk in chunks[1:]:
        content = chunk.page_content.strip()
        word_count = len(content.split())

        # 只有非常小（如单个标题、符号、单词）才合并
        is_tiny = len(content) < min_size or word_count < min_words

        # 且前一个块已经有实质内容
        prev_content = result[-1].page_content.strip()
        prev_has_content = len(prev_content) > min_size * 2

        if is_tiny and prev_has_content and result:
            # 合并到前一个块
            merged_content = prev_content + "\n\n" + content
            result[-1] = Document(
                page_content=merged_content,
                metadata={**result[-1].metadata, **chunk.metadata}
            )
            logger.debug(f"🔗 合并小块: {content[:30]}...")
        else:
            result.append(chunk)

    return result


def enhance_metadata(
    chunks: List,
    source_file: str = None,
    add_index: bool = True,
    add_headers: bool = True,
) -> List:
    """增强每个 chunk 的元数据

    参数:
        chunks: 分块后的文档列表
        source_file: 来源文件路径
        add_index: 是否添加块索引
        add_headers: 是否提取并添加标题层级

    返回:
        元数据增强后的文档列表
    """
    if not chunks:
        return chunks

    total = len(chunks)
    current_headers = []

    for i, chunk in enumerate(chunks):
        metadata = chunk.metadata.copy()

        # 添加块索引
        if add_index:
            metadata["chunk_index"] = i
            metadata["total_chunks"] = total

        # 添加来源文件
        if source_file:
            metadata["source_file"] = source_file

        # 提取标题层级
        if add_headers:
            # 从元数据中提取当前标题
            h1 = metadata.get("H1", "")
            h2 = metadata.get("H2", "")
            h3 = metadata.get("H3", "")

            # 更新当前标题层级
            if h1:
                current_headers = [h1]
            if h2:
                if len(current_headers) > 0:
                    current_headers[0] = h2
                else:
                    current_headers.append(h2)
            if h3:
                if len(current_headers) > 1:
                    current_headers[1] = h3
                else:
                    current_headers.append(h3)

            # 添加当前标题层级到元数据
            if current_headers:
                metadata["current_headers"] = current_headers
                metadata["breadcrumb"] = " > ".join(filter(None, current_headers))

        chunk.metadata = metadata

    return chunks


def headers_with_context(
    chunks: List,
    separator: str = " | ",
) -> List:
    """为每个块添加标题前缀（上下文）

    参数:
        chunks: 分块后的文档列表
        separator: 标题分隔符

    返回:
        添加标题前缀后的文档列表
    """
    if not chunks:
        return chunks

    current_headers = []

    for chunk in chunks:
        metadata = chunk.metadata

        # 更新当前标题层级
        h1 = metadata.get("H1")
        h2 = metadata.get("H2")
        h3 = metadata.get("H3")

        if h1:
            current_headers = [h1]
        if h2:
            if current_headers:
                current_headers[0] = h2
            else:
                current_headers.append(h2)
        if h3:
            if len(current_headers) > 1:
                current_headers[1] = h3
            else:
                current_headers.append(h3)

        # 添加标题前缀
        if current_headers:
            prefix = separator.join(current_headers)
            chunk.page_content = f"[{prefix}]{separator}{chunk.page_content}"

    return chunks


def post_process_chunks(
    chunks: List,
    merge_small: bool = True,
    enhance_meta: bool = True,
    add_context: bool = False,
    source_file: str = None,
    min_chunk_size: int = 50,
) -> List:
    """后处理分块结果

    组合多个后处理步骤的便捷函数。

    参数:
        chunks: 分块后的文档列表
        merge_small: 是否合并小块
        enhance_meta: 是否增强元数据
        add_context: 是否添加标题上下文
        source_file: 来源文件路径
        min_chunk_size: 小块的最小字符数

    返回:
        处理后的文档列表
    """
    if not chunks:
        return chunks

    # 1. 合并小块
    if merge_small:
        chunks = merge_small_chunks(chunks, min_size=min_chunk_size)

    # 2. 增强元数据
    if enhance_meta:
        chunks = enhance_metadata(chunks, source_file=source_file)

    # 3. 添加标题上下文
    if add_context:
        chunks = headers_with_context(chunks)

    logger.info(f"✅ 后处理完成: {len(chunks)} 个块")

    return chunks
