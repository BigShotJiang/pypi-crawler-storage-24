"""RAG 服务模块

RAG 独立服务封装，支持：
- 文档索引
- 问答检索
- 向量存储管理
"""

import logging
import time
from typing import Any, Dict, List, Union

from config import RAGConfig
from core.exceptions import RAGError, VectorStoreError

# 事件系统
from events import (
    EventBus,
    RagErrorEvent,
    RagQueryEvent,
    RagResultEvent,
)

logger = logging.getLogger("rag.service")


class RAGService:
    """RAG 独立服务

    提供统一的 RAG 接口，支持：
    - 文档添加和索引
    - 问答检索
    - 向量存储管理

    通过依赖注入使用，无需关心底层实现
    """

    def __init__(
        self,
        config: RAGConfig = None,
        vector_store=None,
        retriever=None,
        event_bus: EventBus = None,
    ):
        """
        初始化 RAG 服务

        Args:
            config: RAG 配置
            vector_store: 向量存储实例（可选）
            retriever: 检索器实例（可选）
            event_bus: 事件总线（可选，默认使用全局事件总线）
        """
        self._config = config or RAGConfig.from_env()
        self._vector_store = vector_store
        self._retriever = retriever
        self._event_bus = event_bus
        self._initialized = False

    def _get_event_bus(self) -> EventBus:
        """获取事件总线（优先使用注入的，否则使用全局）"""
        if self._event_bus is not None:
            return self._event_bus
        from src.events.base import get_event_bus
        return get_event_bus()

    @property
    def config(self) -> RAGConfig:
        """获取配置"""
        return self._config

    @property
    def is_initialized(self) -> bool:
        """检查是否已初始化"""
        return self._initialized

    def _ensure_initialized(self):
        """确保已初始化"""
        if not self._initialized:
            self.initialize()

    def initialize(self):
        """初始化向量存储和检索器"""
        if self._initialized:
            return

        try:
            from langchain_chroma import Chroma
            from langchain_ollama import OllamaEmbeddings

            # 创建嵌入函数
            embeddings = OllamaEmbeddings(
                model=self._config.embedding_model
            )

            # 创建向量存储
            self._vector_store = Chroma(
                persist_directory=self._config.chroma_dir,
                embedding_function=embeddings,
            )

            # 创建检索器
            self._retriever = self._create_retriever()

            self._initialized = True
            logger.info("RAG 服务初始化完成")

        except VectorStoreError:
            # 向量存储错误直接重新抛出
            raise
        except Exception as e:
            logger.error(f"RAG 服务初始化失败: {e}")
            raise RAGError(f"RAG 服务初始化失败: {e}") from e

    def _create_retriever(self):
        """创建检索器"""
        from .retriever import create_retriever
        return create_retriever(
            vector_store=self._vector_store,
            top_k=self._config.top_k,
        )

    def query(self, question: str, session_id: str = None) -> str:
        """
        问答查询

        Args:
            question: 问题
            session_id: 会话 ID（可选）

        Returns:
            检索到的相关内容

        Raises:
            RAGError: 检索过程中发生错误
        """
        self._ensure_initialized()
        event_bus = self._get_event_bus()
        start_time = time.time()

        if self._retriever is None:
            raise RAGError("RAG 服务未正确初始化")

        try:
            # 发布查询事件
            event_bus.publish(RagQueryEvent(payload={
                "query": question,
                "session_id": session_id,
                "top_k": self._config.top_k,
            }))

            logger.info(f"[RAG] 查询: {question}")
            docs = self._retriever.invoke(question)
            duration_ms = (time.time() - start_time) * 1000
            logger.info(f"[RAG] 找到 {len(docs)} 个文档")

            if not docs:
                # 发布结果事件（空结果）
                event_bus.publish(RagResultEvent(payload={
                    "query": question,
                    "session_id": session_id,
                    "result_count": 0,
                    "results": [],
                    "duration_ms": duration_ms,
                }))
                return "未找到相关内容"

            results = []
            result_data = []
            for i, doc in enumerate(docs, 1):
                content = doc.page_content[:500]
                source = doc.metadata.get("source", "未知来源")
                score = doc.metadata.get("score", None)
                results.append(f"--- 文档 {i} (来源: {source}) ---\n{content}")
                result_data.append({
                    "content": content,
                    "source": source,
                    "score": score,
                })

            # 发布结果事件
            event_bus.publish(RagResultEvent(payload={
                "query": question,
                "session_id": session_id,
                "result_count": len(docs),
                "results": result_data,
                "duration_ms": duration_ms,
            }))

            return "\n\n".join(results)

        except VectorStoreError:
            # 向量存储错误直接重新抛出
            raise
        except Exception as e:
            logger.error(f"[RAG] 检索错误: {e}", exc_info=True)

            # 发布错误事件
            event_bus.publish(RagErrorEvent(payload={
                "query": question[:500] if question else "",
                "session_id": session_id,
                "error": str(e),
                "error_type": type(e).__name__,
            }))

            raise RAGError(f"RAG 检索失败: {e}") from e

    def add_documents(
        self,
        file_paths: Union[str, List[str]],
        **kwargs
    ) -> Dict[str, Any]:
        """
        添加文档到索引

        Args:
            file_paths: 文件路径列表
            **kwargs: 其他参数（如 chunk_size, overlap 等）

        Returns:
            添加结果
        """
        from .chunker import TextChunker
        from .loader import DocumentLoader

        file_paths = [file_paths] if isinstance(file_paths, str) else file_paths

        results = []
        for file_path in file_paths:
            try:
                # 加载文档
                loader = DocumentLoader()
                documents = loader.load(file_path)

                # 分块
                chunker = TextChunker(
                    chunk_size=kwargs.get("chunk_size", self._config.chunk_size),
                    chunk_overlap=kwargs.get("chunk_overlap", self._config.chunk_overlap),
                )
                chunks = chunker.chunk(documents)

                # 添加到向量存储
                self._ensure_initialized()
                self._vector_store.add_documents(chunks)

                results.append({
                    "file": file_path,
                    "status": "success",
                    "chunks": len(chunks),
                })

                logger.info(f"[RAG] 已添加文档: {file_path}, {len(chunks)} 个块")

            except Exception as e:
                logger.error(f"[RAG] 添加文档失败: {file_path}, {e}")
                results.append({
                    "file": file_path,
                    "status": "error",
                    "error": str(e),
                })

        return {
            "total": len(file_paths),
            "results": results,
        }

    def delete_documents(self, source: str = None, **kwargs) -> int:
        """
        删除文档

        Args:
            source: 文档来源过滤
            **kwargs: 其他参数

        Returns:
            删除的文档数量
        """
        self._ensure_initialized()

        if source:
            # 删除指定来源的文档
            # 需要向量存储支持
            self._vector_store.delete(where={"source": source})
            return 1

        return 0

    def search(self, query: str, top_k: int = None) -> List[Any]:
        """
        搜索文档

        Args:
            query: 查询
            top_k: 返回数量

        Returns:
            文档列表
        """
        self._ensure_initialized()

        k = top_k or self._config.top_k
        return self._vector_store.similarity_search(query, k=k)

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        try:
            collection = self._vector_store.get()
            doc_count = len(collection.get("ids", []))
        except Exception:
            doc_count = 0

        return {
            "initialized": self._initialized,
            "document_count": doc_count,
            "embedding_model": self._config.embedding_model,
            "chunk_size": self._config.chunk_size,
            "top_k": self._config.top_k,
        }

    # ===== 上下文管理器支持 =====

    def __enter__(self):
        """进入上下文"""
        self.initialize()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出上下文"""
        pass


# ============================================================================
# 便捷函数
# ============================================================================


def create_rag_service(
    config: RAGConfig = None,
    **kwargs
) -> RAGService:
    """创建 RAG 服务的便捷函数"""
    return RAGService(config=config, **kwargs)


def get_default_rag_service() -> RAGService:
    """获取默认 RAG 服务（单例）"""
    if not hasattr(get_default_rag_service, "_instance"):
        get_default_rag_service._instance = RAGService()
    return get_default_rag_service._instance
