"""检索器模块

支持不同检索策略：
- 相似度检索 (similarity)
- MMR 检索 (mmr)
- 相似度阈值检索 (similarity_score_threshold)
"""

import logging
from typing import Any, Dict, List, Optional, Union

from langchain_core.retrievers import BaseRetriever
from langchain_core.vectorstores import VectorStore

from .config import TOP_K

logger = logging.getLogger("rag")


class RetrievalStrategy:
    """检索策略常量"""

    SIMILARITY = "similarity"  # 相似度检索
    MMR = "mmr"  # 最大边际相关性
    SIMILARITY_THRESHOLD = "similarity_score_threshold"  # 相似度阈值


def create_retriever(
    vector_store: VectorStore,
    strategy: str = RetrievalStrategy.SIMILARITY,
    top_k: int = TOP_K,
    search_kwargs: Optional[Dict[str, Any]] = None,
    **kwargs
) -> BaseRetriever:
    """
    创建检索器

    Args:
        vector_store: 向量存储
        strategy: 检索策略
        top_k: 返回的文档数量
        search_kwargs: 额外的检索参数
        **kwargs: 额外的向量存储参数

    Returns:
        检索器实例
    """
    logger.info(f"🔍 正在创建检索器 (策略: {strategy}, top_k: {top_k})")

    # 构建搜索参数
    if search_kwargs is None:
        search_kwargs = {}

    if "k" not in search_kwargs:
        search_kwargs["k"] = top_k

    # 创建检索器
    retriever = vector_store.as_retriever(
        search_type=strategy,
        search_kwargs=search_kwargs,
        **kwargs,
    )

    logger.info("   ✅ 检索器创建完成")
    return retriever


def get_relevant_documents(
    retriever: BaseRetriever,
    query: str,
) -> List[Any]:
    """
    获取相关文档

    Args:
        retriever: 检索器
        query: 查询文本

    Returns:
        相关文档列表
    """
    return retriever.invoke(query)


class RetrieverFactory:
    """检索器工厂类"""

    def __init__(self, vector_store: VectorStore):
        """
        初始化工厂

        Args:
            vector_store: 向量存储
        """
        self.vector_store = vector_store

    def create(
        self,
        strategy: str = RetrievalStrategy.SIMILARITY,
        top_k: int = TOP_K,
        **kwargs
    ) -> BaseRetriever:
        """
        创建检索器

        Args:
            strategy: 检索策略
            top_k: 返回文档数
            **kwargs: 额外参数

        Returns:
            检索器实例
        """
        return create_retriever(
            vector_store=self.vector_store,
            strategy=strategy,
            top_k=top_k,
            **kwargs,
        )
