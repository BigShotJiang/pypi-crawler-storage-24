"""向量存储模块

支持向量存储的创建、加载和持久化：
- Chroma 向量数据库
- 可配置的嵌入模型
- 增量更新支持
"""

import logging
import time
from pathlib import Path
from typing import List, Optional, Union

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_ollama import OllamaEmbeddings

from core.exceptions import VectorStoreError
from core.retry import RetryConfig

from .config import EMBEDDING_MODEL

logger = logging.getLogger("rag")

# 向量存储重试配置
VECTORSTORE_RETRY_CONFIG = RetryConfig(
    max_attempts=3,
    base_delay=1.0,
    exponential_base=2.0,
    max_delay=30.0,
    retryable_exceptions=(VectorStoreError, ConnectionError, TimeoutError, Exception),
)


class VectorStoreManager:
    """向量存储管理器"""

    def __init__(
        self,
        persist_directory: Union[str, Path],
        embedding_model: str = EMBEDDING_MODEL,
    ):
        """
        初始化向量存储管理器

        Args:
            persist_directory: 持久化目录
            embedding_model: 嵌入模型名称
        """
        self.persist_directory = Path(persist_directory)
        self.embedding_model = embedding_model
        self._vector_store: Optional[Chroma] = None

    @property
    def vector_store(self) -> Chroma:
        """获取向量存储实例"""
        if self._vector_store is None:
            raise RuntimeError("向量存储未初始化，请先调用 create() 或 load()")
        return self._vector_store

    @property
    def embeddings(self):
        """获取嵌入模型"""
        return OllamaEmbeddings(model=self.embedding_model)

    def create(self, documents: List[Document], force_recreate: bool = False) -> Chroma:
        """
        创建向量存储（带重试机制）

        Args:
            documents: 文档列表
            force_recreate: 是否强制重建（删除已有数据）

        Returns:
            Chroma 向量存储
        """
        logger.info("🗃️  正在创建向量数据库...")

        # 检查是否已存在
        if self.persist_directory.exists() and not force_recreate:
            logger.info("   📌 加载已存在的向量数据库...")
            self._vector_store = Chroma(
                persist_directory=str(self.persist_directory),
                embedding_function=self.embeddings,
            )
            return self._vector_store

        # 创建新的向量存储
        if force_recreate and self.persist_directory.exists():
            import shutil
            shutil.rmtree(self.persist_directory)
            logger.info("   🗑️ 已删除旧的向量数据库")

        logger.info("   🔨 创建新的向量数据库...")

        last_exception = None
        for attempt in range(1, VECTORSTORE_RETRY_CONFIG.max_attempts + 1):
            try:
                self._vector_store = Chroma.from_documents(
                    documents=documents,
                    embedding=self.embeddings,
                    persist_directory=str(self.persist_directory),
                )
                logger.info("   ✅ 向量数据库创建完成")
                return self._vector_store

            except Exception as e:
                last_exception = e

                if attempt >= VECTORSTORE_RETRY_CONFIG.max_attempts:
                    logger.error(f"[VectorStore] 达到最大重试次数 ({VECTORSTORE_RETRY_CONFIG.max_attempts}), 错误: {e}")
                    break

                delay = VECTORSTORE_RETRY_CONFIG.calculate_delay(attempt)
                logger.warning(f"[VectorStore] 第 {attempt}/{VECTORSTORE_RETRY_CONFIG.max_attempts} 次尝试失败: {e}, {delay:.1f}秒后重试...")
                time.sleep(delay)

        raise VectorStoreError(f"向量存储创建失败: {last_exception}") from last_exception

    def load(self) -> Chroma:
        """
        加载已存在的向量存储（带重试机制）

        Returns:
            Chroma 向量存储
        """
        if not self.persist_directory.exists():
            raise FileNotFoundError(f"向量存储目录不存在: {self.persist_directory}")

        logger.info("📌 加载已存在的向量数据库...")

        last_exception = None
        for attempt in range(1, VECTORSTORE_RETRY_CONFIG.max_attempts + 1):
            try:
                self._vector_store = Chroma(
                    persist_directory=str(self.persist_directory),
                    embedding_function=self.embeddings,
                )
                return self._vector_store

            except Exception as e:
                last_exception = e

                if attempt >= VECTORSTORE_RETRY_CONFIG.max_attempts:
                    logger.error(f"[VectorStore] 达到最大重试次数 ({VECTORSTORE_RETRY_CONFIG.max_attempts}), 错误: {e}")
                    break

                delay = VECTORSTORE_RETRY_CONFIG.calculate_delay(attempt)
                logger.warning(f"[VectorStore] 第 {attempt}/{VECTORSTORE_RETRY_CONFIG.max_attempts} 次尝试失败: {e}, {delay:.1f}秒后重试...")
                time.sleep(delay)

        raise VectorStoreError(f"向量存储加载失败: {last_exception}") from last_exception

    def add_documents(self, documents: List[Document]):
        """
        添加文档到向量存储

        Args:
            documents: 文档列表
        """
        if self._vector_store is None:
            raise RuntimeError("向量存储未初始化")

        self._vector_store.add_documents(documents)
        logger.info(f"   ✅ 添加了 {len(documents)} 个文档")

    def as_retriever(self, search_type: str = "similarity", **search_kwargs):
        """
        创建检索器

        Args:
            search_type: 检索类型
            **search_kwargs: 检索参数

        Returns:
            检索器
        """
        return self.vector_store.as_retriever(
            search_type=search_type,
            search_kwargs=search_kwargs,
        )

    def get_collection_count(self) -> int:
        """获取向量存储中的文档数量"""
        if self._vector_store is None:
            return 0
        return self._vector_store._collection.count()


def create_vector_store(
    documents: List[Document],
    persist_directory: Union[str, Path],
    embedding_model: str = EMBEDDING_MODEL,
    force_recreate: bool = False,
) -> Chroma:
    """
    便捷函数：创建向量存储

    Args:
        documents: 文档列表
        persist_directory: 持久化目录
        embedding_model: 嵌入模型
        force_recreate: 是否强制重建

    Returns:
        Chroma 向量存储
    """
    manager = VectorStoreManager(
        persist_directory=persist_directory,
        embedding_model=embedding_model,
    )
    return manager.create(documents, force_recreate=force_recreate)


def load_vector_store(
    persist_directory: Union[str, Path],
    embedding_model: str = EMBEDDING_MODEL,
) -> Chroma:
    """
    便捷函数：加载向量存储

    Args:
        persist_directory: 持久化目录
        embedding_model: 嵌入模型

    Returns:
        Chroma 向量存储
    """
    manager = VectorStoreManager(
        persist_directory=persist_directory,
        embedding_model=embedding_model,
    )
    return manager.load()
