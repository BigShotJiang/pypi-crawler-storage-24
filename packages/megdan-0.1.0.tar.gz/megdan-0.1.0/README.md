# Megdan — CTF Line

Part of the Megdan CTF Line.

Megdan is the CTF competition toolkit for digital forensics practitioners.

> Placeholder release — full build coming soon.

## Megdan CTF Line

| Package | Role |
|---|---|
| **Phalanx** | CTF dashboard |
| **Treska** | CTF parser |
| **Poligon** | Practice simulator |

## Author

GitHub: [ShadowStrike-CTF](https://github.com/ShadowStrike-CTF)
