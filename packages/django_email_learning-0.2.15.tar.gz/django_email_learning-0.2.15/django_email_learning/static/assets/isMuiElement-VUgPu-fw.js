import{t as e}from"./isMuiElement-Cdow2dG3.js";var t=e;export{t};
//# sourceMappingURL=isMuiElement-VUgPu-fw.js.map