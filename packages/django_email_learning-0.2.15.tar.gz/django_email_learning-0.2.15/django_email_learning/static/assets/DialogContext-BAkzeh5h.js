import{_t as e,yt as t}from"./render-BuxckV-w.js";var n=t(e()).createContext({});export{n as t};
//# sourceMappingURL=DialogContext-BAkzeh5h.js.map