# mRNA folding: ViennaRNA-based MFE, delta-MFE scoring, and variant analysis pipeline.
from .vienna import fold, fold_full, fold_available
from .delta_mfe import compute_delta_mfe, compute_folding_profile, FoldingProfile, WindowResult
from .codons import classify_substitution, get_amino_acid, CODON_TABLE
from .reference import (
    normalize_transcript_id,
    load_cds_sequences,
    load_mrna_sequences,
    find_cds_offset,
    parse_fasta_metadata,
    select_transcripts,
    load_cds_genome_map,
    genome_to_cds_position,
    cds_to_genome_position,
    complement,
)
from .conserved import load_step1_results, is_conserved, ConservedPositionIndex
from .precompute import (
    precompute_ref_window_mfes,
    precompute_transcript_deltas,
    precompute_batch,
)
from .query import (
    DeltaTableIndex,
    query_mutation,
    compute_empirical_p_value,
    OK,
    ERR_NOT_CONSERVED_FOLDING_POSITION,
    ERR_TRANSCRIPT_NOT_PRECOMPUTED,
    ERR_POSITION_NOT_IN_TRANSCRIPT,
    ERR_REF_MISMATCH_CDS,
    ERR_INVALID_ALLELE,
    ERR_NULL_POOL_EMPTY,
    ERR_INTERNAL,
)
from .pipeline import (
    set_folding_data_dir,
    get_folding_data_dir,
    folding_pipeline,
    folding_query_batch,
)

__all__ = [
    # Core folding
    "fold",
    "fold_full",
    "fold_available",
    "compute_delta_mfe",
    "compute_folding_profile",
    "FoldingProfile",
    "WindowResult",
    # Codons
    "classify_substitution",
    "get_amino_acid",
    "CODON_TABLE",
    # Reference data loading
    "normalize_transcript_id",
    "load_cds_sequences",
    "load_mrna_sequences",
    "find_cds_offset",
    "parse_fasta_metadata",
    "select_transcripts",
    "load_cds_genome_map",
    "genome_to_cds_position",
    "cds_to_genome_position",
    "complement",
    # Step 1 conserved positions
    "load_step1_results",
    "is_conserved",
    "ConservedPositionIndex",
    # Precomputation
    "precompute_ref_window_mfes",
    "precompute_transcript_deltas",
    "precompute_batch",
    # Query / scoring
    "DeltaTableIndex",
    "query_mutation",
    "compute_empirical_p_value",
    # Pipeline
    "set_folding_data_dir",
    "get_folding_data_dir",
    "folding_pipeline",
    "folding_query_batch",
    # Status codes
    "OK",
    "ERR_NOT_CONSERVED_FOLDING_POSITION",
    "ERR_TRANSCRIPT_NOT_PRECOMPUTED",
    "ERR_POSITION_NOT_IN_TRANSCRIPT",
    "ERR_REF_MISMATCH_CDS",
    "ERR_INVALID_ALLELE",
    "ERR_NULL_POOL_EMPTY",
    "ERR_INTERNAL",
]
