# geney/transcription/pipeline.py — Standalone transcription pipeline entry point.
"""
Standalone entry point for Borzoi transcription-effect prediction.

Analogous to :func:`geney.folding.pipeline.folding_pipeline` and
:func:`geney.pipelines.tis_pipeline`.
"""
from __future__ import annotations

from ..variants import MutationalEvent
from .prediction import predict_transcription_effect


def transcription_pipeline(mut_id: str, organism: str = "hg38") -> dict:
    """Run the Borzoi transcription-effect pipeline for a mutation.

    Parses a standard geney mutation ID, extracts genomic coordinates,
    and calls :func:`predict_transcription_effect`.

    Args:
        mut_id: Mutation ID (``GENE:CHR:POS:REF:ALT``).
        organism: Genome build (default ``"hg38"``).

    Returns:
        Result dict with ``status``, ``tissue_fold_changes``,
        ``regulatory_score``, etc.
    """
    m = MutationalEvent(mut_id)
    chrom = str(m.chrom)

    try:
        result = predict_transcription_effect(
            chrom=chrom, pos=m.central_position,
            mutations=m.mutation_args(), organism=organism,
        )
        result["mut_id"] = mut_id
        result["gene"] = m.gene
        return result
    except Exception as e:
        return {
            "status": "error",
            "reason": str(e),
            "mut_id": mut_id,
            "gene": m.gene,
        }
