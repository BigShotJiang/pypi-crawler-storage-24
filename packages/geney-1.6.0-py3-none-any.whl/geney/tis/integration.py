# geney/tis/integration.py — Integration with transcript objects.
from __future__ import annotations

from .metrics import TISShiftResult, compute_tis_shift_metrics


# ============================================================================
# Integration with Transcripts
# ============================================================================

def analyze_transcript_tis(
    reference_transcript,
    variant_transcript,
    probability_threshold: float = 0.1,
) -> TISShiftResult:
    """
    Analyze TIS shift for a transcript variant.

    Args:
        reference_transcript: Reference transcript object with mature_mrna attribute
        variant_transcript: Variant transcript object with mature_mrna attribute
        probability_threshold: Minimum probability threshold (default 0.1)

    Returns:
        TISShiftResult with all metrics
    """
    # Get mRNA sequences
    ref_mrna = getattr(reference_transcript, 'mature_mrna', None)
    var_mrna = getattr(variant_transcript, 'mature_mrna', None)

    if ref_mrna is None:
        raise ValueError("Reference transcript must have mature_mrna attribute")
    if var_mrna is None:
        raise ValueError("Variant transcript must have mature_mrna attribute")

    # Handle sequence objects vs strings
    if hasattr(ref_mrna, 'seq'):
        ref_mrna = ref_mrna.seq
    if hasattr(var_mrna, 'seq'):
        var_mrna = var_mrna.seq

    # Get canonical start position
    canonical_start = getattr(reference_transcript, 'cds_start', None)

    return compute_tis_shift_metrics(
        ref_mrna=ref_mrna,
        var_mrna=var_mrna,
        canonical_start=canonical_start,
        probability_threshold=probability_threshold,
    )
