"""
Global pairwise alignment with affine gap penalties using BioPython's
C-backed PairwiseAligner.

Parameters match the original Oncosplice convention:
    match=1, mismatch=-1, gap_open=-3, gap_extend=0

This means opening a gap is expensive but extending is free, so the
aligner prefers fewer, longer gaps over many short ones.
"""

from collections import namedtuple
from Bio.Align import PairwiseAligner

Alignment = namedtuple('Alignment', ['seqA', 'seqB', 'score'])


def _extract_aligned_strings(alignment) -> tuple[str, str]:
    """Extract gapped alignment strings from Bio.Align.Alignment coordinates."""
    coords = alignment.coordinates
    target_seq = str(alignment.target)
    query_seq = str(alignment.query)

    aligned_a = []
    aligned_b = []

    for k in range(coords.shape[1] - 1):
        t_start, t_end = coords[0, k], coords[0, k + 1]
        q_start, q_end = coords[1, k], coords[1, k + 1]

        t_len = t_end - t_start
        q_len = q_end - q_start

        if t_len > 0 and q_len > 0:
            aligned_a.append(target_seq[t_start:t_end])
            aligned_b.append(query_seq[q_start:q_end])
        elif t_len > 0:
            aligned_a.append(target_seq[t_start:t_end])
            aligned_b.append('-' * t_len)
        elif q_len > 0:
            aligned_a.append('-' * q_len)
            aligned_b.append(query_seq[q_start:q_end])

    return ''.join(aligned_a), ''.join(aligned_b)


def global_align(seq_a: str, seq_b: str,
                 match: float = 1, mismatch: float = -1,
                 gap_open: float = -3, gap_extend: float = 0,
                 penalize_end_gaps: bool = True) -> list[Alignment]:
    """
    Global pairwise alignment with affine gap penalties.

    Returns
    -------
    list[Alignment]
        Single-element list with the optimal alignment.
    """
    aligner = PairwiseAligner()
    aligner.mode = 'global'
    aligner.match_score = match
    aligner.mismatch_score = mismatch
    aligner.open_gap_score = gap_open
    aligner.extend_gap_score = gap_extend

    if not penalize_end_gaps:
        aligner.target_end_gap_score = 0.0
        aligner.query_end_gap_score = 0.0

    al = aligner.align(seq_a, seq_b)[0]
    al_a, al_b = _extract_aligned_strings(al)

    return [Alignment(al_a, al_b, al.score)]
