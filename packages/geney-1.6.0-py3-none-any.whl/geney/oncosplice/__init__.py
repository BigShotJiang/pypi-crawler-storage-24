# geney/oncosplice/ — Protein-level impact scoring.
from .scoring import Oncosplice

__all__ = ["Oncosplice"]
