"""MetricHub Quant MCP Server — China A-Share market data tools"""
import json
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent
from .client import MHFinClient, ApiKeyMissingError, ApiKeyInvalidError

app = Server("mh-fin-quant")
client: MHFinClient | None = None


def _client() -> MHFinClient:
    global client
    if client is None:
        client = MHFinClient()
    return client


def _text(data) -> list[TextContent]:
    return [TextContent(type="text", text=json.dumps(data, ensure_ascii=False, indent=2))]


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="get_setup_guide",
            description="Get setup instructions for MetricHub Quant MCP Server. Call this when the API key is not configured or the user needs help getting started.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="get_trade_dates",
            description="Get all available trade dates. Returns a list of dates in YYYYMMDD format, newest first.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="get_market_overview",
            description="Get market overview for a trade date: major indices, limit-up/down counts, market breadth, northbound flow, sentiment score, and style exposure.",
            inputSchema={
                "type": "object",
                "properties": {"date": {"type": "string", "description": "Trade date in YYYYMMDD format"}},
                "required": ["date"],
            },
        ),
        Tool(
            name="get_industry_ranking",
            description="Get industry (申万行业) rotation ranking for a trade date: avg return, up/down ratio, limit-up count per industry.",
            inputSchema={
                "type": "object",
                "properties": {"date": {"type": "string", "description": "Trade date in YYYYMMDD format"}},
                "required": ["date"],
            },
        ),
        Tool(
            name="get_sector_hotspots",
            description="Get concept sector (概念板块) hotspots for a trade date: limit-up count, earliest stock, related stocks.",
            inputSchema={
                "type": "object",
                "properties": {"date": {"type": "string", "description": "Trade date in YYYYMMDD format"}},
                "required": ["date"],
            },
        ),
        Tool(
            name="get_stock_list",
            description="Get paginated stock data for all 5000+ A-shares on a trade date. Sortable by pct_chg, amount, PE, PB, market cap, main money flow, etc.",
            inputSchema={
                "type": "object",
                "properties": {
                    "date": {"type": "string", "description": "Trade date in YYYYMMDD format"},
                    "sort": {"type": "string", "description": "Sort field (pct_chg, amount_yi, pe, pb, circ_mv_yi, main_net_yi, etc.)", "default": "pct_chg"},
                    "order": {"type": "string", "enum": ["asc", "desc"], "default": "desc"},
                    "page": {"type": "integer", "default": 1},
                    "size": {"type": "integer", "default": 50, "description": "Page size, max 200"},
                },
                "required": ["date"],
            },
        ),
        Tool(
            name="search_stock",
            description="Search stocks by name or code. Returns matching stocks with full daily data.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Stock name (Chinese) or code (e.g. 000001)"},
                    "date": {"type": "string", "description": "Trade date in YYYYMMDD format"},
                },
                "required": ["query", "date"],
            },
        ),
        Tool(
            name="get_limitup_analysis",
            description="Get limit-up (涨停) stock analysis with 13 quantitative factors: seal strength, timing, volume, turnover, etc.",
            inputSchema={
                "type": "object",
                "properties": {
                    "date": {"type": "string", "description": "Trade date in YYYYMMDD format"},
                    "type": {"type": "string", "enum": ["all", "first", "consecutive"], "default": "all", "description": "all=all limit-up, first=first board only, consecutive=2+ boards"},
                },
                "required": ["date"],
            },
        ),
        Tool(
            name="get_factor_ic",
            description="Get factor effectiveness history (IC values) for quantitative factors over recent trade days.",
            inputSchema={
                "type": "object",
                "properties": {
                    "days": {"type": "integer", "default": 20, "description": "Number of recent trade days (max 120)"},
                },
                "required": [],
            },
        ),
        Tool(
            name="get_risk_alerts",
            description="Get risk alerts for stocks: shareholder reduction (R1), performance warning (R2), etc.",
            inputSchema={
                "type": "object",
                "properties": {
                    "date": {"type": "string", "description": "Trade date in YYYYMMDD format"},
                    "rule": {"type": "string", "enum": ["all", "R1", "R2"], "default": "all"},
                },
                "required": ["date"],
            },
        ),
    ]


SETUP_GUIDE = """# MetricHub Quant MCP Server Setup

## Step 1: Register
Visit https://quant.metrichub.app/register to create an account.

## Step 2: Create API Key
After login, go to https://quant.metrichub.app/api-keys and click "Create". Copy the API Key.

## Step 3: Configure MCP Server
Add to your Claude Desktop config (claude_desktop_config.json):

```json
{
  "mcpServers": {
    "mh-fin": {
      "command": "mh-fin-mcp",
      "env": {
        "MH_FIN_API_KEY": "mhfk_your_key_here"
      }
    }
  }
}
```

Or for Claude Code (.claude/settings.json):

```json
{
  "mcpServers": {
    "mh-fin": {
      "command": "mh-fin-mcp",
      "env": {
        "MH_FIN_API_KEY": "mhfk_your_key_here"
      }
    }
  }
}
```

## Step 4: Restart
Restart Claude Desktop or Claude Code to activate the MCP Server.

## Available Data
- Market overview (indices, breadth, sentiment, northbound flow)
- Industry rotation ranking (Shenwan industries)
- Concept sector hotspots
- Full stock data for 5000+ A-shares
- Limit-up analysis with 13 quantitative factors
- Factor IC effectiveness history
- Risk alerts (shareholder reduction, performance warnings)

Data updates daily at 17:30 CST (Mon-Fri).
"""


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name == "get_setup_guide":
        return [TextContent(type="text", text=SETUP_GUIDE)]

    try:
        c = _client()
    except (ApiKeyMissingError, ApiKeyInvalidError) as e:
        return [TextContent(type="text", text=f"{e}\n\nCall get_setup_guide for detailed setup instructions.")]

    if name == "get_trade_dates":
        return _text(c.get_dates())

    elif name == "get_market_overview":
        return _text(c.get_market_overview(arguments["date"]))

    elif name == "get_industry_ranking":
        return _text(c.get_industry(arguments["date"]))

    elif name == "get_sector_hotspots":
        return _text(c.get_sector(arguments["date"]))

    elif name == "get_stock_list":
        return _text(c.get_stock_list(
            date=arguments["date"],
            sort=arguments.get("sort", "pct_chg"),
            order=arguments.get("order", "desc"),
            page=arguments.get("page", 1),
            size=arguments.get("size", 50),
        ))

    elif name == "search_stock":
        return _text(c.search_stock(arguments["query"], arguments["date"]))

    elif name == "get_limitup_analysis":
        return _text(c.get_limitup(
            date=arguments["date"],
            type=arguments.get("type", "all"),
        ))

    elif name == "get_factor_ic":
        return _text(c.get_factor_ic(arguments.get("days", 20)))

    elif name == "get_risk_alerts":
        return _text(c.get_risk_alerts(
            date=arguments["date"],
            rule=arguments.get("rule", "all"),
        ))

    else:
        return [TextContent(type="text", text=f"Unknown tool: {name}")]


def main():
    import asyncio
    asyncio.run(_run())


async def _run():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())
