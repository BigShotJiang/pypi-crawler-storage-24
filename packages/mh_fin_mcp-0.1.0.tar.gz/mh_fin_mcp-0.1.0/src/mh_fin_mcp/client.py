"""HTTP client for MetricHub Quant Open API"""
import os
import httpx

DEFAULT_BASE_URL = "https://api.quant.metrichub.app/api/v1/open"


class ApiKeyMissingError(Exception):
    pass


class ApiKeyInvalidError(Exception):
    pass


class MHFinClient:
    def __init__(self):
        self.base_url = os.environ.get("MH_FIN_API_URL", DEFAULT_BASE_URL).rstrip("/")
        api_key = os.environ.get("MH_FIN_API_KEY", "")
        if not api_key:
            raise ApiKeyMissingError(
                "MH_FIN_API_KEY environment variable is not set.\n"
                "Please register at https://quant.metrichub.app and create an API Key, "
                "then set it in your MCP server config."
            )
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"X-API-Key": api_key},
            timeout=30.0,
        )

    def _get(self, path: str, params: dict | None = None) -> dict | list:
        resp = self._client.get(path, params=params)
        if resp.status_code == 401:
            raise ApiKeyInvalidError(
                "API Key is invalid or revoked. "
                "Please check your key at https://quant.metrichub.app/api-keys"
            )
        resp.raise_for_status()
        return resp.json()

    def get_dates(self) -> list[str]:
        return self._get("/market/dates")

    def get_market_overview(self, date: str) -> dict:
        return self._get("/market/overview", {"date": date})

    def get_industry(self, date: str) -> list[dict]:
        return self._get("/market/industry", {"date": date})

    def get_sector(self, date: str) -> list[dict]:
        return self._get("/market/sector", {"date": date})

    def get_stock_list(self, date: str, sort: str = "pct_chg",
                       order: str = "desc", page: int = 1, size: int = 50) -> dict:
        return self._get("/stock/list", {
            "date": date, "sort": sort, "order": order,
            "page": page, "size": size,
        })

    def search_stock(self, query: str, date: str) -> list[dict]:
        return self._get("/stock/search", {"q": query, "date": date})

    def get_limitup(self, date: str, type: str = "all") -> list[dict]:
        return self._get("/limitup/list", {"date": date, "type": type})

    def get_factor_ic(self, days: int = 20) -> dict:
        return self._get("/factor/ic", {"days": days})

    def get_risk_alerts(self, date: str, rule: str = "all") -> list[dict]:
        return self._get("/risk/alerts", {"date": date, "rule": rule})
