# mh-fin-mcp

[中文文档](./README_CN.md)

MCP Server for China A-Share quantitative market data, powered by [MetricHub Quant](https://quant.metrichub.app).

## Features

- **Market Overview**: Major indices, limit-up/down stats, breadth, northbound flow, sentiment
- **Industry Rotation**: Shenwan industry ranking with up/down ratio and limit-up counts
- **Sector Hotspots**: Concept sector analysis with leading stocks
- **Stock Data**: Full daily data for 5000+ A-shares (OHLCV, PE, PB, market cap, money flow)
- **Stock Search**: Search by name or code
- **Limit-Up Analysis**: 13-factor quantitative scoring for limit-up stocks
- **Factor IC**: Factor effectiveness history
- **Risk Alerts**: Shareholder reduction, performance warnings

## Installation

```bash
pip install mh-fin-mcp
```

## Configuration

### 1. Get API Key

Register at [quant.metrichub.app](https://quant.metrichub.app), then go to [API Key management](https://quant.metrichub.app/api-keys) to create a key.

### 2. Claude Desktop

Edit `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "mh-fin": {
      "command": "mh-fin-mcp",
      "env": {
        "MH_FIN_API_KEY": "your_api_key_here"
      }
    }
  }
}
```

### 3. Claude Code

Edit `.claude/settings.json` in your project:

```json
{
  "mcpServers": {
    "mh-fin": {
      "command": "mh-fin-mcp",
      "env": {
        "MH_FIN_API_KEY": "your_api_key_here"
      }
    }
  }
}
```

### 4. Restart Claude to activate

## Available Tools

| Tool | Description |
|------|-------------|
| `get_setup_guide` | Get setup instructions |
| `get_trade_dates` | List available trade dates |
| `get_market_overview` | Market overview: indices, breadth, sentiment, northbound flow |
| `get_industry_ranking` | Industry rotation ranking (Shenwan industries) |
| `get_sector_hotspots` | Concept sector hotspots with leading stocks |
| `get_stock_list` | Paginated stock data for 5000+ A-shares |
| `search_stock` | Search stocks by name or code |
| `get_limitup_analysis` | Limit-up analysis with 13 quantitative factors |
| `get_factor_ic` | Factor IC effectiveness history |
| `get_risk_alerts` | Risk alerts (shareholder reduction, etc.) |

## Data

- Covers all 5000+ A-shares
- Updated daily after 17:30 CST (Mon-Fri)
- 13 quantitative factors for limit-up scoring
- Data only, no investment advice

## License

MIT
