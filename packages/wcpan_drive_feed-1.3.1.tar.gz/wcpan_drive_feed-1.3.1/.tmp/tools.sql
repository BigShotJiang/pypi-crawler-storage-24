-- compress changes
  BEGIN;
  DELETE FROM changes;
  INSERT INTO changes (node_id, is_removed)
  SELECT node_id, 0 FROM nodes
  WHERE node_id != '00000000-0000-0000-0000-000000000000';
  COMMIT;


--  1. Inspect first (dry run):
  WITH RECURSIVE reachable(node_id) AS (
      SELECT '00000000-0000-0000-0000-000000000000'
      UNION ALL
      SELECT n.node_id FROM nodes n
      JOIN reachable r ON n.parent_id = r.node_id
  )
  SELECT node_id, name, is_directory FROM nodes
  WHERE node_id NOT IN (SELECT node_id FROM reachable);

--  2. Emit removal changes for them:
  WITH RECURSIVE reachable(node_id) AS (
      SELECT '00000000-0000-0000-0000-000000000000'
      UNION ALL
      SELECT n.node_id FROM nodes n
      JOIN reachable r ON n.parent_id = r.node_id
  )
  INSERT INTO changes (node_id, is_removed)
  SELECT node_id, 1 FROM nodes
  WHERE node_id NOT IN (SELECT node_id FROM reachable);

--  3. Delete them:
  WITH RECURSIVE reachable(node_id) AS (
      SELECT '00000000-0000-0000-0000-000000000000'
      UNION ALL
      SELECT n.node_id FROM nodes n
      JOIN reachable r ON n.parent_id = r.node_id
  )
  DELETE FROM nodes
  WHERE node_id NOT IN (SELECT node_id FROM reachable);
