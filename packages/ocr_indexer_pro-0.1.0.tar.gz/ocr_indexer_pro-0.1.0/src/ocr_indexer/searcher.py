"""
@RAG_CONTEXT
{
  "archivo": "buscador_pro.py",
  "lineas": 24,
  "tokens_estimados": 174,
  "hash_contenido": "22efedbb7238509bbd80021caa7a927d27f12b01a088d355459872c6c46b3d73",
  "creacion": "2026-03-13",
  "modificacion": "2026-03-13",
  "tags": [
    "json"
  ],
  "descripcion_corta": "Buscador de texto en archivos indexados JSON",
  "descripcion_larga": "Script Python que busca texto en archivos indexados mediante un archivo JSON. Requiere ruta del índice como argumento, carga datos JSON, permite búsqueda de texto y exclusión de palabras. Filtra resultados por contenido OCR en minúsculas y muestra nombre de archivo y ruta para coincidencias."
}
"""
import json, sys, os

if len(sys.argv) < 2:
    print("Error: No se especificó el archivo de índice.")
    sys.exit(1)

INDEX_PATH = sys.argv[1]

if not os.path.exists(INDEX_PATH):
    print("❌ El índice está vacío o no existe.")
    sys.exit(1)

with open(INDEX_PATH, 'r', encoding='utf-8') as f:
    data = json.load(f)

query = input("\n🔎 Buscar texto: ").lower()
excluir = input("🚫 Excluir palabra: ").lower()

for ruta, info in data.items():
    texto = info.get('contenido', {}).get('texto_ocr', '').lower()
    if query in texto and (not excluir or excluir not in texto):
        print(f"\n✅ ENCONTRADO: {info['archivo']['nombre']}")
        print(f"📁 Ruta: {ruta}")
        print("-" * 30)
