"""
Strelka — Fastest open-source differentiable photonic optimizer.
A Pushinka project.

JAX-accelerated 2D TE FDTD with free adjoint gradients via jax.grad.
Designed for inverse design of photonic neural network chips.

Named after Strelka ("little arrow"), the Soviet space dog who survived
orbital flight in 1960. Her puppy Pushinka was gifted to the Kennedy
family — a symbol of international scientific collaboration.

Quick start:
    from strelka import optimize, simulate, cascade

    # Optimize an 8-port photonic matrix
    result = optimize(n_ports=8, design_um=14.0, resolution=10)

    # Decompose a 64×64 unitary into 8×8 blocks
    decomp = cascade.decompose_64x64(your_weight_matrix)
"""

__version__ = "0.1.0"
__author__ = "Pushinka"

from strelka.core import optimize, simulate, FDTDConfig
from strelka import cascade
