#!/usr/bin/env python3
"""Validation script for main refactoring."""

import sys
import os

# Add parent directory to path to import utils
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.validation_common import (
    validate_jsx_component,
    count_complexity,
    print_validation_header,
    print_complexity_analysis,
    print_summary_footer,
    run_validation,
    run_validation_main,
)

def main():
    """Validate main refactoring."""
    return run_validation_main(
        title="Main Refactoring",
        components={
            'TicketsPanelRefactored.jsx': ['TicketsPanelRefactored'],
            'TicketFilters.jsx': ['TicketFilters'],
            'BulkOperations.jsx': ['BulkOperations'],
            'TicketList.jsx': ['TicketList'],
            'TicketStats.jsx': ['TicketStats']
        },
        base_path='src/proxym/dashboard/components/tickets',
        original_file='src/proxym/dashboard/components/tickets.jsx',
        benefits_bullet='ticket management'
    )

if __name__ == "__main__":
    main()
