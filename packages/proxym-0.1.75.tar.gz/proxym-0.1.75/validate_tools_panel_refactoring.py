#!/usr/bin/env python3
"""Validation script for ToolsPanel refactoring."""

import sys
import os

# Add parent directory to path to import utils
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.validation_common import (
    validate_jsx_component,
    count_complexity,
    print_validation_header,
    print_complexity_analysis,
    print_summary_footer,
    run_validation,
    run_validation_main,
)


def main():
    """Validate ToolsPanel refactoring."""
    return run_validation_main(
        title="ToolsPanel Refactoring",
        components={
            'ToolsRegistry.jsx': ['ToolsRegistry'],
            'ToolsJobQueue.jsx': ['ToolsJobQueue'],
            'ToolsDispatch.jsx': ['ToolsDispatch'],
            'ToolsPanelRefactored.jsx': ['ToolsPanelRefactored']
        },
        base_path='src/proxym/dashboard/components/tools',
        original_file='src/proxym/dashboard/components/tools.jsx',
        benefits_bullet='tool management'
    )

if __name__ == "__main__":
    main()
