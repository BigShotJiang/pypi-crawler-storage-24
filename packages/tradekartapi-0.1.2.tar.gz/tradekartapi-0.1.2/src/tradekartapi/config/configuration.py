# for future configuration like retry, timeout, env config

DEFAULT_TIMEOUT_SECONDS = 5
PACKAGE_NAME = 'tradekartapi'