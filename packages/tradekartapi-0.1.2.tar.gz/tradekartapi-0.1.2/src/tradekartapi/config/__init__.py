from .configuration import DEFAULT_TIMEOUT_SECONDS, PACKAGE_NAME

__all__ = [
    'DEFAULT_TIMEOUT_SECONDS',
    'PACKAGE_NAME',
]