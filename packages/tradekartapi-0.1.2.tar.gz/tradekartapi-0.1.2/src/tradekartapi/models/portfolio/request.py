from dataclasses import dataclass
from pydantic import field_validator

from ..annexures import Segment
from ...exceptions import ValidationError

@dataclass(frozen=True, slots=True)
class GetPositionsRequest:
    segment : Segment | None = None

    @field_validator('segment', mode='before')
    @classmethod
    def validate_segment(cls, val: Segment | None) -> Segment | None:
        if val is not None and val not in Segment:
            raise ValidationError(
                'Invalid segment',
                status_code=400,
                operation='GET_POSITIONS',
                details={'reason': 'Invalid segment'},
            )
        return val

@dataclass(frozen=True, slots=True)
class GetPositionsForSymbolRequest:
    trading_symbol: str
    segment: Segment

    @field_validator('trading_symbol', mode='before')
    @classmethod
    def validate_trading_symbol(cls, val: str) -> str:
        if not val or not val.strip():
            raise ValidationError(
                'Trading symbol is required and cannot be empty',
                status_code=400,
                operation='GET_POSITIONS_FOR_SYMBOL',
                details={'reason': 'Trading symbol is required and cannot be empty'},
            )
        return val

    @field_validator('segment', mode='before')
    @classmethod
    def validate_segment(cls, val: Segment) -> Segment:
        if val not in Segment:
            raise ValidationError(
                'Invalid segment',
                status_code=400,   
                operation='GET_POSITIONS_FOR_SYMBOL',
                details={'reason': 'Invalid segment'},
            )
        return val