import json
from dataclasses import dataclass
from ...exceptions import ValidationError
from ..annexures import Segment, Exchange, Product

@dataclass(frozen=True, slots=True)
class GetHoldingsResponse:
    isin: str
    trading_symbol: str
    quantity: float
    average_price: float
    pledge_quantity: float
    demat_locked_quantity: float
    groww_locked_quantity: float
    repledge_quantity: float
    t1_quantity: float
    demat_free_quantity: float
    corporate_action_additional_quantity: int
    active_demat_transfer_quantity: int

    def __post_init__(self) -> None:
        if self.quantity < 0:
            raise ValidationError(
                'Quantity must be greater than 0',
                status_code=400,
                details={'reason': 'Quantity must be greater than 0'},
            )

    def to_dict(self) -> dict:
        return {
            'isin': self.isin,
            'trading_symbol': self.trading_symbol,
            'quantity': self.quantity,
            'average_price': self.average_price,
            'pledge_quantity': self.pledge_quantity,
            'demat_locked_quantity': self.demat_locked_quantity,
            'groww_locked_quantity': self.groww_locked_quantity,
            'repledge_quantity': self.repledge_quantity,
            't1_quantity': self.t1_quantity,
            'demat_free_quantity': self.demat_free_quantity,
            'corporate_action_additional_quantity': self.corporate_action_additional_quantity,
            'active_demat_transfer_quantity': self.active_demat_transfer_quantity,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    #Todo Add validators for other fields


@dataclass(frozen=True, slots=True)
class GetPositionsResponse:
    trading_symbol: str
    segment: Segment
    credit_quantity: int
    credit_price: int
    debit_quantity: int
    debit_price: int
    carry_forward_credit_quantity: int
    carry_forward_credit_price: int
    carry_forward_debit_quantity: int
    carry_forward_debit_price: int
    exchange: Exchange
    symbol_isin: str
    quantity: int
    product: Product
    net_carry_forward_quantity: int
    net_price: int
    net_carry_forward_price: int
    realised_pnl: int

    def to_dict(self) -> dict:
        return {
            'trading_symbol': self.trading_symbol,
            'segment': self.segment.value,
            'credit_quantity': self.credit_quantity,
            'credit_price': self.credit_price,
            'debit_quantity': self.debit_quantity,
            'debit_price': self.debit_price,
            'carry_forward_credit_quantity': self.carry_forward_credit_quantity,
            'carry_forward_credit_price': self.carry_forward_credit_price,
            'carry_forward_debit_quantity': self.carry_forward_debit_quantity,
            'carry_forward_debit_price': self.carry_forward_debit_price,
            'exchange': self.exchange.value,
            'symbol_isin': self.symbol_isin,
            'quantity': self.quantity,
            'product': self.product.value,
            'net_carry_forward_quantity': self.net_carry_forward_quantity,
            'net_price': self.net_price,
            'net_carry_forward_price': self.net_carry_forward_price,
            'realised_pnl': self.realised_pnl,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict())