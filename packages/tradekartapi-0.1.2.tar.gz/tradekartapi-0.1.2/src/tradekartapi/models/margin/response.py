from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class GetAvailableMarginResponse:
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class GetOrderMarginResponse:
    raw: dict[str, Any]