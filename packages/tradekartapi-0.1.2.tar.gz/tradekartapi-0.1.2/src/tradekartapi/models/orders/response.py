from dataclasses import dataclass

@dataclass(frozen=True, slots=True)
class PlaceOrderResponse:
    pass


@dataclass(frozen=True, slots=True)
class ModifyOrderResponse:
    pass

@dataclass(frozen=True, slots=True)
class CancelOrderResponse:
    pass

@dataclass(frozen=True, slots=True)
class OrderStatusResponse:
    pass

@dataclass(frozen=True, slots=True)
class OrderListResponse:
    pass

@dataclass(frozen=True, slots=True)
class OrderDetailResponse:
    pass

@dataclass(frozen=True, slots=True)
class TradeResponse:
    pass