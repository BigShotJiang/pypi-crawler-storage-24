from __future__ import annotations

from enum import Enum

class Validity(str, Enum):
    DAY = 'DAY'

class Exchange(str, Enum):
    NSE = 'NSE'
    BSE = 'BSE'
    MCX = 'MCX'

class Segment(str, Enum):
    CASH = 'CASH'
    FNO = 'FNO'
    COMMODITY = 'COMMODITY'

class Product(str, Enum):
    CNC = 'CNC'
    MIS = 'MIS'
    NRML = 'NRML'

class OrderType(str, Enum):
    MARKET = 'MARKET'
    LIMIT = 'LIMIT'
    STOP_LOSS = 'SL'
    STOP_LIMIT = 'SL_M'

class TransactionType(str, Enum):
    BUY = 'BUY'
    SELL = 'SELL'