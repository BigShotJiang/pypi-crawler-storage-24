from typing import Any

from ..utils import validate_access_token

class GrowwSDKAdapter:
    """
    Thin adapter over official GrowwAPI SDK object.
    This keeps our services decoupled from direct SDK construction.
    """

    def __init__(self, sdk_client: Any) -> None:
        self._sdk_client = sdk_client

    @classmethod
    def from_access_token(cls, access_token: str, groww_sdk_client: Any) -> 'GrowwSDKAdapter':
        #validate access token
        validate_access_token(access_token)
        #initialize sdk client
        sdk_client = groww_sdk_client(access_token)
        return cls(sdk_client=sdk_client)

    @property
    def client(self) -> Any:
        return self._sdk_client