from typing import Any

from ..models.margin import (
    GetAvailableMarginRequest,
    GetOrderMarginRequest,
    GetAvailableMarginResponse,
    GetOrderMarginResponse,
)
from ..exceptions import ServiceError


class MarginService:
    def __init__(self, sdk: Any) -> None:
        self._sdk = sdk.client

    def get_available_margin(
        self, request: GetAvailableMarginRequest
    ) -> GetAvailableMarginResponse:
        try:
            response = self._sdk.get_available_margin_details(
                **request.to_payload()
            )
            return GetAvailableMarginResponse(raw=response)
        except Exception as exc:
            raise ServiceError(
                'Error in fetching available margin',
                status_code=500,
                operation='GET_AVAILABLE_MARGIN',
                details={'reason': 'Error in get available margin method'},
            ) from exc

    def get_order_margin(
        self, request: GetOrderMarginRequest
    ) -> GetOrderMarginResponse:
        try:
            response = self._sdk.get_order_margin_details(
                **request.to_payload()
            )
            return GetOrderMarginResponse(raw=response)
        except Exception as exc:
            raise ServiceError(
                'Error in fetching order margin',
                status_code=500,
                operation='GET_ORDER_MARGIN',
                details={'reason': 'Error in get order margin method'},
            ) from exc