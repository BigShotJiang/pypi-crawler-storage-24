from typing import Any

from .adapter import GrowwSDKAdapter
from .services import OrderService, PortfolioService
from .services import MarginService


class TradeKartClient:
    """
    Main facade for app developers.

    Example:
        from tradekartapi.client import TradeKartClient
        client = TradeKartClient.from_access_token("token", TradeKartAPI)
    """

    def __init__(self, adapter: GrowwSDKAdapter):
        self._adapter = adapter
        self.order_service = OrderService(adapter)
        self.portfolio_service = PortfolioService(adapter)
        self.margin_service = MarginService(adapter)

    @classmethod
    def from_access_token(cls, access_token: str, groww_sdk_client: Any) -> 'TradeKartClient':
        adapter = GrowwSDKAdapter.from_access_token(access_token, groww_sdk_client)
        return cls(adapter=adapter)

    @property
    def raw_sdk(self) -> Any:
        return self._adapter.client
        