"""EWS Scoreboard Pipeline."""
__version__ = "0.12.0"
