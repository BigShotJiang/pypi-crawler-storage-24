"""
Generate the preflop equity lookup table from the oscar6echo reference dataset.

Source: https://github.com/oscar6echo/Poker2/blob/master/Tables/df_two_hand_equity.csv
14,366 matchups computed via exhaustive enumeration.

Usage:
    python -m py_poker_equity.generate_preflop_table

The output is saved to src/py_poker_equity/data/preflop_table.json
"""
import csv
import json
import os


def _normalize_hand(hand):
    """Convert CSV notation to our canonical form. AAo -> AA, KAo -> AKo."""
    if len(hand) == 3 and hand[0] == hand[1] and hand[2] == 'o':
        return hand[:2]
    # Ensure higher rank first for non-pairs
    if len(hand) == 3 and hand[2] in ('s', 'o'):
        ranks = '23456789TJQKA'
        i1 = ranks.index(hand[0])
        i2 = ranks.index(hand[1])
        if i1 < i2:
            return hand[1] + hand[0] + hand[2]
    return hand


def generate():
    """Convert the reference CSV into our preflop_table.json format."""
    csv_path = os.path.join(os.path.dirname(__file__), '..', '..', '..',
                            'tests', 'fixtures', 'preflop_reference.csv')

    if not os.path.exists(csv_path):
        # Try alternate location
        csv_path = os.path.join(os.path.dirname(__file__), '..', '..', 'tests',
                                'fixtures', 'preflop_reference.csv')

    if not os.path.exists(csv_path):
        print(f"ERROR: Reference CSV not found. Expected at:")
        print(f"  {os.path.abspath(csv_path)}")
        print(f"\nDownload it from:")
        print(f"  https://raw.githubusercontent.com/oscar6echo/Poker2/master/Tables/df_two_hand_equity.csv")
        return

    table = {}
    count = 0

    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key_a = _normalize_hand(row['HandA'])
            key_b = _normalize_hand(row['HandB'])

            if key_a <= key_b:
                lookup_key = f"{key_a}_vs_{key_b}"
                a_win = round(float(row['Hand1_Wins']) * 100, 2)
                b_win = round(float(row['Hand2_Wins']) * 100, 2)
            else:
                lookup_key = f"{key_b}_vs_{key_a}"
                a_win = round(float(row['Hand2_Wins']) * 100, 2)
                b_win = round(float(row['Hand1_Wins']) * 100, 2)

            tie = round(float(row['Ties']) * 100, 2)

            table[lookup_key] = {
                'a_win': a_win,
                'b_win': b_win,
                'tie': tie,
            }
            count += 1

    # Save
    data_dir = os.path.join(os.path.dirname(__file__), 'data')
    os.makedirs(data_dir, exist_ok=True)
    output_path = os.path.join(data_dir, 'preflop_table.json')
    with open(output_path, 'w') as f:
        json.dump(table, f, separators=(',', ':'))

    size_kb = os.path.getsize(output_path) / 1024
    print(f"Generated preflop_table.json from reference CSV")
    print(f"  {count} matchups loaded")
    print(f"  {len(table)} unique lookup keys")
    print(f"  Saved to {output_path} ({size_kb:.1f} KB)")


if __name__ == '__main__':
    generate()
