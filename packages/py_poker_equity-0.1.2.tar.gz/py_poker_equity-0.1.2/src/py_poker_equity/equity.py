"""
Equity calculator for heads-up Texas Hold'em.

- Preflop: uses a precomputed lookup table for instant results
- Flop/Turn/River: exact enumeration of remaining board cards
"""
import json
import os
from itertools import combinations

from py_poker_equity.evaluator import parse_card, evaluate_hand, compute_winner, RANK_MAP

# Build full deck as notation strings
RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
SUITS = ['h', 'd', 'c', 's']
FULL_DECK = [f"{r}{s}" for r in RANKS for s in SUITS]

# Lazy-loaded preflop table
_preflop_table = None


def _load_preflop_table():
    global _preflop_table
    if _preflop_table is not None:
        return _preflop_table
    table_path = os.path.join(os.path.dirname(__file__), 'data', 'preflop_table.json')
    if not os.path.exists(table_path):
        raise FileNotFoundError(
            f"Preflop lookup table not found at {table_path}. "
            "Run 'python -m py_poker_equity.generate_preflop_table' to generate it."
        )
    with open(table_path, 'r') as f:
        _preflop_table = json.load(f)
    return _preflop_table


def _canonicalize_hole_cards(hole_cards):
    """
    Convert hole cards to a canonical key for preflop lookup.

    Canonical form: higher rank first, then 's' for suited or 'o' for offsuit.
    Pairs are just the rank repeated (e.g. 'AA', '77').

    Examples:
        ["Ah", "Kh"] -> "AKs"
        ["Kd", "Ah"] -> "AKo"
        ["7s", "7d"] -> "77"
    """
    c1 = parse_card(hole_cards[0])
    c2 = parse_card(hole_cards[1])

    # Reverse lookup: rank int -> canonical key char (10 -> T for standard notation)
    rank_reverse = {v: k for k, v in RANK_MAP.items()}
    rank_reverse[10] = 'T'  # standard poker notation
    r1 = rank_reverse[c1.rank]
    r2 = rank_reverse[c2.rank]

    if c1.rank == c2.rank:
        return f"{r1}{r2}"

    # Higher rank first
    if c1.rank > c2.rank:
        high, low = r1, r2
        high_suit, low_suit = c1.suit, c2.suit
    else:
        high, low = r2, r1
        high_suit, low_suit = c2.suit, c1.suit

    suffix = 's' if high_suit == low_suit else 'o'
    return f"{high}{low}{suffix}"


def get_preflop_equity(hand_a, hand_b):
    """
    Look up preflop equity from the precomputed table.

    Args:
        hand_a: list of 2 card notation strings, e.g. ["Ah", "Kh"]
        hand_b: list of 2 card notation strings, e.g. ["Qd", "Qs"]

    Returns:
        dict with keys 'a_win', 'b_win', 'tie' (percentages 0-100)
    """
    table = _load_preflop_table()
    key_a = _canonicalize_hole_cards(hand_a)
    key_b = _canonicalize_hole_cards(hand_b)

    # Table is keyed as "AKs_vs_QQ" with the lexicographically first hand first
    if key_a <= key_b:
        lookup_key = f"{key_a}_vs_{key_b}"
        flipped = False
    else:
        lookup_key = f"{key_b}_vs_{key_a}"
        flipped = True

    entry = table.get(lookup_key)
    if entry is None:
        raise ValueError(
            f"Preflop matchup not found in table: {lookup_key}. "
            "The table may be corrupted or incomplete."
        )

    if flipped:
        return {'a_win': entry['b_win'], 'b_win': entry['a_win'], 'tie': entry['tie']}
    return {'a_win': entry['a_win'], 'b_win': entry['b_win'], 'tie': entry['tie']}


def get_equity(hand_a, hand_b, board=None):
    """
    Calculate equity for a heads-up matchup at any stage.

    Args:
        hand_a: list of 2 card notation strings, e.g. ["Ah", "Kh"]
        hand_b: list of 2 card notation strings, e.g. ["Qd", "Qs"]
        board: list of 0-5 card notation strings (default: empty = preflop)

    Returns:
        dict with keys 'a_win', 'b_win', 'tie' (percentages 0-100, rounded to 2 decimal places)

    Raises:
        ValueError: if duplicate cards are detected or invalid card count
    """
    if board is None:
        board = []

    if len(board) == 0:
        return get_preflop_equity(hand_a, hand_b)

    if len(board) not in (3, 4, 5):
        raise ValueError(f"Board must have 0, 3, 4, or 5 cards, got {len(board)}")

    # Validate no duplicate cards
    all_known = hand_a + hand_b + board
    all_parsed = [parse_card(c) for c in all_known]
    all_tuples = [(c.rank, c.suit) for c in all_parsed]
    if len(set(all_tuples)) != len(all_tuples):
        raise ValueError("Duplicate cards detected")

    # Build remaining deck
    known_set = set(all_tuples)
    remaining = [c for c in FULL_DECK if (parse_card(c).rank, parse_card(c).suit) not in known_set]

    cards_needed = 5 - len(board)

    if cards_needed == 0:
        # River — just evaluate
        ha = evaluate_hand(hand_a, board)
        hb = evaluate_hand(hand_b, board)
        winner = compute_winner(ha, hb)
        if winner is None:
            return {'a_win': 0.0, 'b_win': 0.0, 'tie': 100.0}
        elif winner is ha:
            return {'a_win': 100.0, 'b_win': 0.0, 'tie': 0.0}
        else:
            return {'a_win': 0.0, 'b_win': 100.0, 'tie': 0.0}

    # Enumerate all possible remaining board cards
    a_wins = 0
    b_wins = 0
    ties = 0

    for extra in combinations(remaining, cards_needed):
        full_board = board + list(extra)
        ha = evaluate_hand(hand_a, full_board)
        hb = evaluate_hand(hand_b, full_board)
        winner = compute_winner(ha, hb)
        if winner is None:
            ties += 1
        elif winner is ha:
            a_wins += 1
        else:
            b_wins += 1

    total = a_wins + b_wins + ties
    return {
        'a_win': round(a_wins / total * 100, 2),
        'b_win': round(b_wins / total * 100, 2),
        'tie': round(ties / total * 100, 2),
    }
