from py_poker_equity.generate_preflop_table import generate

generate()
