"""
Texas Hold'em hand evaluator.

Evaluates 5-card hands from 7 cards (2 hole + 5 board),
classifies hand types, and compares hands to determine winners.
"""
from collections import namedtuple, Counter
from itertools import combinations

Card = namedtuple('Card', ['rank', 'suit'])

HandResult = namedtuple('HandResult', ['hand_rank', 'hand_name', 'best_five', 'tiebreaker'])

# hand_rank: 1 = best (Royal Flush), 10 = worst (High Card)
HAND_RANKS = {
    1: 'Royal Flush',
    2: 'Straight Flush',
    3: 'Four of a Kind',
    4: 'Full House',
    5: 'Flush',
    6: 'Straight',
    7: 'Three of a Kind',
    8: 'Two Pair',
    9: 'Pair',
    10: 'High Card',
}

RANK_MAP = {
    '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
    '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14,
}

VALID_SUITS = {'h', 'd', 'c', 's'}


def parse_card(notation):
    """
    Parse card notation string to Card namedtuple.
    Examples: "Ah" -> Card(14, 'h'), "10s" -> Card(10, 's'), "2c" -> Card(2, 'c')
    """
    notation = notation.strip()
    if len(notation) < 2 or len(notation) > 3:
        raise ValueError(f"Invalid card notation: '{notation}'")

    suit = notation[-1].lower()
    rank_str = notation[:-1].upper()

    if suit not in VALID_SUITS:
        raise ValueError(f"Invalid suit: '{suit}' in '{notation}'")

    if rank_str not in RANK_MAP:
        raise ValueError(f"Invalid rank: '{rank_str}' in '{notation}'")

    return Card(RANK_MAP[rank_str], suit)


def _evaluate_five(cards):
    """
    Evaluate exactly 5 cards and return (hand_rank, tiebreaker).
    tiebreaker is a tuple used for comparing hands of the same rank.
    """
    ranks = sorted([c.rank for c in cards], reverse=True)
    suits = [c.suit for c in cards]
    rank_counts = Counter(ranks)

    is_flush = len(set(suits)) == 1

    # Check for straight (including ace-low A-2-3-4-5)
    is_straight = False
    straight_high = 0
    unique_ranks = sorted(set(ranks), reverse=True)
    if len(unique_ranks) == 5:
        if unique_ranks[0] - unique_ranks[4] == 4:
            is_straight = True
            straight_high = unique_ranks[0]
        # Ace-low straight: A-2-3-4-5
        elif unique_ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            straight_high = 5  # 5-high straight

    # Classify the hand
    counts_desc = sorted(rank_counts.values(), reverse=True)

    if is_flush and is_straight:
        if straight_high == 14:
            return (1, (14,))  # Royal Flush
        return (2, (straight_high,))  # Straight Flush

    if counts_desc == [4, 1]:
        quad_rank = [r for r, c in rank_counts.items() if c == 4][0]
        kicker = [r for r, c in rank_counts.items() if c == 1][0]
        return (3, (quad_rank, kicker))  # Four of a Kind

    if counts_desc == [3, 2]:
        trip_rank = [r for r, c in rank_counts.items() if c == 3][0]
        pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
        return (4, (trip_rank, pair_rank))  # Full House

    if is_flush:
        return (5, tuple(ranks))  # Flush

    if is_straight:
        return (6, (straight_high,))  # Straight

    if counts_desc == [3, 1, 1]:
        trip_rank = [r for r, c in rank_counts.items() if c == 3][0]
        kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
        return (7, (trip_rank,) + tuple(kickers))  # Three of a Kind

    if counts_desc == [2, 2, 1]:
        pairs = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
        kicker = [r for r, c in rank_counts.items() if c == 1][0]
        return (8, tuple(pairs) + (kicker,))  # Two Pair

    if counts_desc == [2, 1, 1, 1]:
        pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
        kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
        return (9, (pair_rank,) + tuple(kickers))  # Pair

    return (10, tuple(ranks))  # High Card


def evaluate_hand(hole_cards, board):
    """
    Find the best 5-card hand from hole cards + board.

    Args:
        hole_cards: list of card notation strings, e.g. ["Ah", "Kd"]
        board: list of card notation strings, e.g. ["7s", "2c", "Jh", "Qd", "10s"]

    Returns:
        HandResult namedtuple with hand_rank, hand_name, best_five, tiebreaker
    """
    all_cards = [parse_card(c) for c in hole_cards] + [parse_card(c) for c in board]

    if len(all_cards) < 5:
        raise ValueError(f"Need at least 5 cards, got {len(all_cards)}")

    best_rank = None
    best_tiebreaker = None
    best_five = None

    for combo in combinations(all_cards, 5):
        hand_rank, tiebreaker = _evaluate_five(combo)
        if best_rank is None or hand_rank < best_rank or (hand_rank == best_rank and tiebreaker > best_tiebreaker):
            best_rank = hand_rank
            best_tiebreaker = tiebreaker
            best_five = list(combo)

    return HandResult(
        hand_rank=best_rank,
        hand_name=HAND_RANKS[best_rank],
        best_five=best_five,
        tiebreaker=best_tiebreaker,
    )


def compute_winner(hand_a, hand_b):
    """
    Determine the winner between two HandResult objects.
    Returns: the winning HandResult, or None if it's a tie.
    """
    if hand_a.hand_rank < hand_b.hand_rank:
        return hand_a
    if hand_a.hand_rank > hand_b.hand_rank:
        return hand_b
    if hand_a.tiebreaker > hand_b.tiebreaker:
        return hand_a
    if hand_a.tiebreaker < hand_b.tiebreaker:
        return hand_b
    return None
