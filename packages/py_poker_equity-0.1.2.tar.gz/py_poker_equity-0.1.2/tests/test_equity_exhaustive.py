"""
Exhaustive equity calculation tests.

Tests post-flop equity across many scenarios with various board textures,
hand types, and edge cases.
"""
import pytest
from py_poker_equity.equity import get_equity


# ═══════════════════════════════════════════════════════════════════
# RIVER — DETERMINISTIC (only one outcome possible)
# ═══════════════════════════════════════════════════════════════════

RIVER_A_WINS_CASES = [
    # (id, hand_a, hand_b, board)
    # Overpairs
    ("AA_vs_KK_dry", ["Ah", "Ad"], ["Kh", "Kd"], ["9c", "7s", "5h", "2c", "3d"]),
    ("KK_vs_QQ_dry", ["Kh", "Kd"], ["Qh", "Qd"], ["9c", "7s", "5h", "2c", "3d"]),
    ("QQ_vs_JJ_dry", ["Qh", "Qd"], ["Jh", "Jd"], ["9c", "7s", "5h", "2c", "3d"]),
    # Set vs overpair
    ("set_vs_overpair", ["7h", "7d"], ["Ah", "Ad"], ["7c", "Ks", "9h", "2c", "3d"]),
    # Flush vs straight
    ("flush_vs_straight", ["Ah", "9h"], ["Kc", "Qd"], ["7h", "4h", "2h", "Js", "10s"]),
    # Full house vs flush
    ("full_house_vs_flush", ["Ah", "Ad"], ["Kh", "Qh"], ["Ac", "Jh", "Jd", "9h", "3d"]),
    # Quads vs full house
    ("quads_vs_full_house", ["Jh", "Jd"], ["Ah", "Ad"], ["Jc", "Js", "Ac", "2c", "3d"]),
    # Straight vs two pair
    ("straight_vs_two_pair", ["9h", "8d"], ["Ah", "Kd"], ["7c", "6s", "5h", "Ac", "Kc"]),
    # Two pair vs pair
    ("two_pair_vs_pair", ["Ah", "Kd"], ["Qh", "Jd"], ["Ac", "Ks", "Qc", "2s", "3d"]),
    # Pair vs high card
    ("pair_vs_high_card", ["Ah", "Ad"], ["Kh", "Qd"], ["9c", "7s", "5h", "2c", "3d"]),
    # Higher pair vs lower pair
    ("higher_pair_vs_lower", ["Ah", "Ad"], ["2h", "2d"], ["Kc", "9s", "7h", "5c", "3d"]),
    # Higher kicker
    ("AK_vs_AQ_paired_board", ["Ah", "Kd"], ["As", "Qd"], ["Ac", "9s", "7h", "2c", "3d"]),
    # Set over set
    ("higher_set_vs_lower_set", ["Kh", "Kd"], ["9h", "9d"], ["Kc", "9c", "7h", "2c", "3d"]),
    # Straight flush vs quads
    ("straight_flush_vs_quads", ["8h", "7h"], ["Ac", "Ad"], ["6h", "5h", "4h", "As", "Ah"]),

    # ── Partial counterfeiting — one hole card still plays ──
    # Board flush but player A has a heart that extends it
    ("board_4_flush_A_has_higher_heart",
     ["Ah", "2c"], ["Kc", "Kd"], ["3h", "5h", "7h", "9h", "Jd"]),
    # Board straight but player A has a higher card that makes a better straight
    ("board_straight_A_extends",
     ["Jh", "2c"], ["3c", "4d"], ["6d", "7c", "8s", "9h", "10d"]),
    # Board has 4 to a flush, A completes with ace, B has nothing
    ("A_completes_board_flush_B_cant",
     ["Ah", "2c"], ["Kc", "Qd"], ["3h", "5h", "7h", "9h", "Jd"]),
    # Both have a heart but A's is higher
    ("both_have_flush_card_A_higher",
     ["Ah", "2c"], ["3h", "4c"], ["5h", "7h", "9h", "Jd", "Kd"]),
    # Board pair counterfeits lower pair, higher pair still wins
    ("board_pair_counterfeits_lower_pair",
     ["Ah", "Ad"], ["Kh", "Kd"], ["Qs", "Qd", "9c", "7s", "2h"]),
]

@pytest.mark.parametrize("name,ha,hb,board", RIVER_A_WINS_CASES,
                         ids=[c[0] for c in RIVER_A_WINS_CASES])
def test_river_a_wins(name, ha, hb, board):
    result = get_equity(ha, hb, board)
    assert result['a_win'] == 100.0, f"Expected a_win=100, got {result}"
    assert result['b_win'] == 0.0
    assert result['tie'] == 0.0


RIVER_TIE_CASES = [
    # Board plays (both hands irrelevant)
    ("board_straight_plays", ["2h", "3d"], ["4c", "6s"], ["Ah", "Kd", "Qc", "Js", "10h"]),
    ("board_flush_plays", ["2c", "3d"], ["4c", "6d"], ["Ah", "Kh", "Qh", "Jh", "9h"]),
    # Same hand different suits
    ("same_hand_diff_suits", ["Ah", "Kd"], ["As", "Kc"], ["Qh", "Js", "10c", "2d", "3h"]),
    # Both have same pair, same kickers
    ("same_pair_same_kickers", ["Ah", "2c"], ["As", "2d"], ["Ac", "Kh", "Qd", "Js", "10c"]),

    # ── Board counterfeiting scenarios ──
    # Board flush counterfeits pocket pairs
    ("board_flush_counterfeits_AA_vs_KK",
     ["Ac", "Ad"], ["Kc", "Kd"], ["4h", "5h", "7h", "9h", "2h"]),
    # Board flush counterfeits overpair vs underpair
    ("board_flush_counterfeits_QQ_vs_22",
     ["Qc", "Qd"], ["2c", "2s"], ["3h", "6h", "8h", "Jh", "Ah"]),
    # Board straight counterfeits pocket pairs
    ("board_straight_counterfeits_AA_vs_KK",
     ["Ac", "Ad"], ["Kc", "Kd"], ["5h", "6d", "7c", "8s", "9h"]),
    # Board full house counterfeits everything
    ("board_full_house_counterfeits",
     ["2c", "3d"], ["4c", "5d"], ["Ah", "Ad", "Ac", "Kh", "Kd"]),
    # Board quads + kicker counterfeits everything
    ("board_quads_counterfeits",
     ["2c", "3d"], ["4c", "5d"], ["Ah", "Ad", "Ac", "As", "Kh"]),
    # Board straight flush counterfeits everything
    ("board_straight_flush_counterfeits",
     ["2c", "3d"], ["4c", "5d"], ["5h", "6h", "7h", "8h", "9h"]),
    # Board flush counterfeits two pair
    ("board_flush_counterfeits_two_pair_vs_pair",
     ["Ac", "Kc"], ["Qc", "Jc"], ["3h", "6h", "8h", "10h", "2h"]),
    # Both players have a suited card matching board flush suit,
    # but board flush is higher than either can make
    ("board_flush_higher_than_hole_flush_cards",
     ["2h", "3d"], ["4h", "5d"], ["Ah", "Kh", "Qh", "Jh", "9h"]),
    # Board has a straight, both players have pairs that don't matter
    ("board_straight_beats_both_pairs",
     ["Ac", "Ad"], ["Kc", "Kd"], ["6h", "7d", "8c", "9s", "10h"]),
    # Board counterfeits a flopped set — board makes higher trips
    ("board_trips_higher_than_set",
     ["2c", "3d"], ["4c", "5d"], ["Ah", "Ad", "Ac", "9s", "8h"]),
]

@pytest.mark.parametrize("name,ha,hb,board", RIVER_TIE_CASES,
                         ids=[c[0] for c in RIVER_TIE_CASES])
def test_river_tie(name, ha, hb, board):
    result = get_equity(ha, hb, board)
    assert result['tie'] == 100.0, f"Expected tie=100, got {result}"


# ═══════════════════════════════════════════════════════════════════
# TURN — KNOWN RANGES (one card to come, ~44 outcomes)
# ═══════════════════════════════════════════════════════════════════

class TestTurnEquityRanges:
    """Turn equity should fall within expected ranges based on poker theory."""

    def test_flush_draw_vs_overpair(self):
        """~20% for flush draw (9 outs / ~44 cards)."""
        result = get_equity(
            ["Ah", "Kh"],  # flush draw
            ["Qc", "Qd"],  # overpair
            board=["7h", "4h", "9c", "2d"]
        )
        assert 15 < result['a_win'] < 40  # flush draw + overcards

    def test_overpair_vs_underpair_turn(self):
        """Overpair is ~90%+ favorite with one card to come."""
        result = get_equity(
            ["Ah", "Ad"],
            ["Kh", "Kd"],
            board=["9c", "7s", "5h", "2d"]
        )
        assert result['a_win'] > 85

    def test_set_vs_overpair_turn(self):
        """Set is ~95%+ on the turn."""
        result = get_equity(
            ["7h", "7d"],
            ["Ah", "Ad"],
            board=["7c", "Ks", "9h", "2d"]
        )
        assert result['a_win'] > 90

    def test_open_ended_straight_draw_vs_pair(self):
        """Open-ended straight draw has ~17% (8 outs)."""
        result = get_equity(
            ["Jh", "10d"],  # OESD (needs 8 or K)
            ["Ah", "Ad"],   # overpair
            board=["9c", "8s", "2h", "4d"]
        )
        assert 10 < result['a_win'] < 30

    def test_two_pair_vs_overpair_turn(self):
        """Two pair should be ~80%+ vs overpair."""
        result = get_equity(
            ["Kh", "9d"],  # two pair
            ["Ah", "Ad"],  # overpair
            board=["Kd", "9c", "3h", "2d"]
        )
        assert result['a_win'] > 70

    def test_drawing_dead(self):
        """Completely drawing dead (no outs possible)."""
        # A has quads, B has a pair — B can never win
        result = get_equity(
            ["Ah", "Ad"],
            ["Kh", "Kd"],
            board=["Ac", "As", "9h", "2d"]
        )
        assert result['a_win'] > 95  # B can only tie with board quads if A somehow... no


# ═══════════════════════════════════════════════════════════════════
# FLOP — KNOWN RANGES (~946 outcomes)
# ═══════════════════════════════════════════════════════════════════

class TestFlopEquityRanges:
    """Flop equity ranges based on common poker scenarios."""

    def test_overpair_vs_underpair_dry_flop(self):
        """Overpair ~80% on a dry flop."""
        result = get_equity(
            ["Ah", "Ad"],
            ["Kh", "Kd"],
            board=["7c", "4s", "2h"]
        )
        assert 75 < result['a_win'] < 95

    def test_set_vs_overpair_flop(self):
        """Set ~90%+ vs overpair."""
        result = get_equity(
            ["7h", "7d"],
            ["Ah", "Ad"],
            board=["7c", "Ks", "9h"]
        )
        assert result['a_win'] > 85

    def test_flush_draw_vs_top_pair_flop(self):
        """Flush draw ~35% vs top pair on the flop."""
        result = get_equity(
            ["Ah", "Kh"],  # nut flush draw + overcards
            ["Qc", "Jd"],  # no pair yet, just overcards
            board=["7h", "4h", "2c"]
        )
        # AK with flush draw is actually favorite here
        assert result['a_win'] > 40

    def test_made_hand_vs_draw(self):
        """Top pair vs flush draw — pair should be ~55-65%."""
        result = get_equity(
            ["Ah", "7d"],  # top pair
            ["Kh", "Qh"],  # flush draw
            board=["Ad", "9h", "4h"]
        )
        assert 50 < result['a_win'] < 75

    def test_combo_draw_vs_overpair(self):
        """Flush draw + straight draw is ~45-55% vs overpair."""
        result = get_equity(
            ["Jh", "10h"],  # flush draw + OESD
            ["Ah", "Ad"],   # overpair
            board=["9h", "8h", "2c"]
        )
        # Combo draw is very strong
        assert result['a_win'] > 35

    def test_dominated_hand_flop(self):
        """AK vs AQ on ace-high flop — AK should be ~85%+."""
        result = get_equity(
            ["Ah", "Kd"],
            ["Ac", "Qd"],
            board=["As", "7h", "2c"]
        )
        assert result['a_win'] > 80

    def test_coin_flip_on_flop(self):
        """Pair vs two overcards on a blank flop."""
        result = get_equity(
            ["Jh", "Jd"],
            ["Ah", "Kd"],
            board=["9c", "7s", "2h"]
        )
        # Pair should be ~70%+ with 2 cards to come
        assert 60 < result['a_win'] < 85

    def test_set_over_set_on_flop(self):
        """Higher set is ~95%+ vs lower set."""
        result = get_equity(
            ["Kh", "Kd"],
            ["7h", "7d"],
            board=["Kc", "7c", "2h"]
        )
        assert result['a_win'] > 90


# ═══════════════════════════════════════════════════════════════════
# PERCENTAGE SUM VALIDATION
# ═══════════════════════════════════════════════════════════════════

PERCENTAGE_SUM_CASES = [
    ("flop_1", ["Ah", "Kh"], ["2c", "7d"], ["Qh", "Jh", "5c"]),
    ("flop_2", ["Ah", "Ad"], ["Kh", "Kd"], ["7c", "4s", "2h"]),
    ("flop_3", ["10h", "10d"], ["Ah", "Kd"], ["9c", "8s", "2h"]),
    ("flop_4", ["5h", "5d"], ["Ah", "Ad"], ["5c", "Ks", "Qh"]),
    ("flop_5", ["Jh", "10h"], ["Ah", "Ad"], ["9h", "8h", "2c"]),
    ("turn_1", ["Ah", "Kh"], ["2c", "7d"], ["Qh", "Jh", "5c", "8d"]),
    ("turn_2", ["Ah", "Ad"], ["Kh", "Kd"], ["7c", "4s", "2h", "9d"]),
    ("turn_3", ["7h", "7d"], ["Ah", "Ad"], ["7c", "Ks", "9h", "2d"]),
    ("river_1", ["Ah", "Ad"], ["Kh", "Kd"], ["9c", "7s", "5h", "2c", "3d"]),
    ("river_2", ["2h", "3d"], ["2c", "3s"], ["Ah", "Kd", "Qc", "Js", "10h"]),
]

@pytest.mark.parametrize("name,ha,hb,board", PERCENTAGE_SUM_CASES,
                         ids=[c[0] for c in PERCENTAGE_SUM_CASES])
def test_percentages_sum_to_100(name, ha, hb, board):
    result = get_equity(ha, hb, board)
    total = result['a_win'] + result['b_win'] + result['tie']
    assert abs(total - 100) < 0.1, f"Sum is {total} for {ha} vs {hb} on {board}"
    assert result['a_win'] >= 0
    assert result['b_win'] >= 0
    assert result['tie'] >= 0


# ═══════════════════════════════════════════════════════════════════
# SYMMETRY — swapping hands should swap a_win/b_win
# ═══════════════════════════════════════════════════════════════════

SYMMETRY_CASES = [
    ("overpair_flop", ["Ah", "Ad"], ["Kh", "Kd"], ["7c", "4s", "2h"]),
    ("flush_draw_turn", ["Ah", "Kh"], ["Qc", "Qd"], ["7h", "4h", "9c", "2d"]),
    ("set_vs_overpair", ["7h", "7d"], ["Ah", "Ad"], ["7c", "Ks", "9h"]),
    ("river_clear_winner", ["Ah", "Ad"], ["Kh", "Kd"], ["9c", "7s", "5h", "2c", "3d"]),
]

@pytest.mark.parametrize("name,ha,hb,board", SYMMETRY_CASES,
                         ids=[c[0] for c in SYMMETRY_CASES])
def test_equity_symmetry(name, ha, hb, board):
    """Swapping hands should swap a_win and b_win, tie stays the same."""
    result_ab = get_equity(ha, hb, board)
    result_ba = get_equity(hb, ha, board)
    assert abs(result_ab['a_win'] - result_ba['b_win']) < 0.01
    assert abs(result_ab['b_win'] - result_ba['a_win']) < 0.01
    assert abs(result_ab['tie'] - result_ba['tie']) < 0.01


# ═══════════════════════════════════════════════════════════════════
# ERROR HANDLING
# ═══════════════════════════════════════════════════════════════════

class TestEquityErrors:
    def test_duplicate_in_hands(self):
        with pytest.raises(ValueError, match="Duplicate"):
            get_equity(["Ah", "Kh"], ["Ah", "Qd"], board=["7c", "4s", "2h"])

    def test_duplicate_in_board(self):
        with pytest.raises(ValueError, match="Duplicate"):
            get_equity(["Ah", "Kh"], ["Qc", "Qd"], board=["7c", "7c", "2h"])

    def test_hand_card_in_board(self):
        with pytest.raises(ValueError, match="Duplicate"):
            get_equity(["Ah", "Kh"], ["Qc", "Qd"], board=["Ah", "4s", "2h"])

    def test_board_size_1(self):
        with pytest.raises(ValueError, match="Board must have"):
            get_equity(["Ah", "Kh"], ["Qc", "Qd"], board=["7c"])

    def test_board_size_2(self):
        with pytest.raises(ValueError, match="Board must have"):
            get_equity(["Ah", "Kh"], ["Qc", "Qd"], board=["7c", "4s"])

    def test_board_size_6(self):
        with pytest.raises(ValueError, match="Board must have"):
            get_equity(["Ah", "Kh"], ["Qc", "Qd"], board=["7c", "4s", "2h", "9d", "3c", "Jh"])
