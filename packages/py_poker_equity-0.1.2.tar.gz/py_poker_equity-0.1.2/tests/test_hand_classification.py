"""
Exhaustive hand classification tests.

Verifies that evaluate_hand correctly identifies every hand type
across many different card combinations.
"""
import pytest
from py_poker_equity.evaluator import evaluate_hand


# ═══════════════════════════════════════════════════════════════════
# ROYAL FLUSH (rank 1)
# ═══════════════════════════════════════════════════════════════════

ROYAL_FLUSH_CASES = [
    # (id, hole_cards, board)
    ("hearts", ["Ah", "Kh"], ["Qh", "Jh", "10h", "2c", "3d"]),
    ("diamonds", ["Ad", "Kd"], ["Qd", "Jd", "10d", "2c", "3h"]),
    ("clubs", ["Ac", "Kc"], ["Qc", "Jc", "10c", "2h", "3d"]),
    ("spades", ["As", "Ks"], ["Qs", "Js", "10s", "2h", "3d"]),
    # Hole cards contribute partially
    ("hole_has_A_only", ["Ah", "2c"], ["Kh", "Qh", "Jh", "10h", "3d"]),
    ("hole_has_10_only", ["10h", "2c"], ["Ah", "Kh", "Qh", "Jh", "3d"]),
    # Board has the royal flush (hole cards irrelevant)
    ("board_has_royal", ["2c", "3d"], ["Ah", "Kh", "Qh", "Jh", "10h"]),
    # Junk hole cards, board is royal
    ("junk_holes_board_royal", ["7c", "8d"], ["As", "Ks", "Qs", "Js", "10s"]),
]

@pytest.mark.parametrize("name,hole,board", ROYAL_FLUSH_CASES, ids=[c[0] for c in ROYAL_FLUSH_CASES])
def test_royal_flush(name, hole, board):
    result = evaluate_hand(hole, board)
    assert result.hand_name == "Royal Flush", f"Expected Royal Flush, got {result.hand_name}"
    assert result.hand_rank == 1


# ═══════════════════════════════════════════════════════════════════
# STRAIGHT FLUSH (rank 2)
# ═══════════════════════════════════════════════════════════════════

STRAIGHT_FLUSH_CASES = [
    ("9_high_hearts", ["9h", "8h"], ["7h", "6h", "5h", "2c", "3d"]),
    ("8_high_diamonds", ["8d", "7d"], ["6d", "5d", "4d", "2c", "3h"]),
    ("7_high_clubs", ["7c", "6c"], ["5c", "4c", "3c", "2h", "Ad"]),
    ("6_high_spades", ["6s", "5s"], ["4s", "3s", "2s", "Ah", "Kd"]),
    ("K_high", ["Kh", "Qh"], ["Jh", "10h", "9h", "2c", "3d"]),
    ("Q_high", ["Qh", "Jh"], ["10h", "9h", "8h", "2c", "3d"]),
    # Ace-low straight flush (wheel flush): A-2-3-4-5
    ("ace_low_wheel", ["Ah", "2h"], ["3h", "4h", "5h", "Kc", "Qd"]),
    # Board contributes most of the straight flush
    ("board_heavy", ["9h", "2c"], ["8h", "7h", "6h", "5h", "3d"]),
    # 6 suited cards — picks the highest straight flush
    ("six_suited_picks_highest", ["9h", "8h"], ["7h", "6h", "5h", "4h", "2c"]),
]

@pytest.mark.parametrize("name,hole,board", STRAIGHT_FLUSH_CASES, ids=[c[0] for c in STRAIGHT_FLUSH_CASES])
def test_straight_flush(name, hole, board):
    result = evaluate_hand(hole, board)
    assert result.hand_name == "Straight Flush", f"Expected Straight Flush, got {result.hand_name}"
    assert result.hand_rank == 2


# ═══════════════════════════════════════════════════════════════════
# FOUR OF A KIND (rank 3)
# ═══════════════════════════════════════════════════════════════════

FOUR_OF_A_KIND_CASES = [
    ("quad_aces", ["Ah", "Ad"], ["Ac", "As", "Kh", "2c", "3d"]),
    ("quad_kings", ["Kh", "Kd"], ["Kc", "Ks", "Ah", "2c", "3d"]),
    ("quad_queens", ["Qh", "Qd"], ["Qc", "Qs", "Ah", "2c", "3d"]),
    ("quad_tens", ["10h", "10d"], ["10c", "10s", "Ah", "2c", "3d"]),
    ("quad_twos", ["2h", "2d"], ["2c", "2s", "Ah", "Kc", "3d"]),
    ("quad_fives", ["5h", "5d"], ["5c", "5s", "Ah", "Kc", "Qd"]),
    # Board has 3 of the quads
    ("board_has_three", ["Ah", "2c"], ["Ad", "Ac", "As", "Kh", "3d"]),
    # Board has all 4 (hole cards are kickers)
    ("board_has_all_four", ["Kh", "Qd"], ["Ah", "Ad", "Ac", "As", "2c"]),
    # Quad jacks
    ("quad_jacks", ["Jh", "Jd"], ["Jc", "Js", "Ah", "Kc", "2d"]),
]

@pytest.mark.parametrize("name,hole,board", FOUR_OF_A_KIND_CASES, ids=[c[0] for c in FOUR_OF_A_KIND_CASES])
def test_four_of_a_kind(name, hole, board):
    result = evaluate_hand(hole, board)
    assert result.hand_name == "Four of a Kind", f"Expected Four of a Kind, got {result.hand_name}"
    assert result.hand_rank == 3


# ═══════════════════════════════════════════════════════════════════
# FULL HOUSE (rank 4)
# ═══════════════════════════════════════════════════════════════════

FULL_HOUSE_CASES = [
    ("aces_full_of_kings", ["Ah", "Ad"], ["Ac", "Kh", "Kd", "2c", "3d"]),
    ("kings_full_of_aces", ["Kh", "Kd"], ["Kc", "Ah", "Ad", "2c", "3d"]),
    ("queens_full_of_jacks", ["Qh", "Qd"], ["Qc", "Jh", "Jd", "2c", "3d"]),
    ("twos_full_of_threes", ["2h", "2d"], ["2c", "3h", "3d", "Ac", "Ks"]),
    ("tens_full_of_nines", ["10h", "10d"], ["10c", "9h", "9d", "2c", "3d"]),
    # Pocket pair + board trips
    ("pocket_pair_board_trips", ["Kh", "Kd"], ["Ah", "Ad", "Ac", "2c", "3d"]),
    # Board has a pair, pocket pair + board pair = two pair, third board card matches pocket = full house
    ("pocket_pair_board_pair_full_house", ["Ah", "Ad"], ["Ac", "9h", "9d", "2c", "3d"]),
    # Board has a pair, hole makes trips
    ("board_pair_hole_trips", ["Ah", "Ad"], ["Ac", "Kh", "Kd", "2c", "3d"]),
    # Two possible full houses — picks the best
    ("two_possible_picks_best", ["Ah", "Kh"], ["Ad", "Ac", "Kd", "Kc", "2s"]),
]

@pytest.mark.parametrize("name,hole,board", FULL_HOUSE_CASES, ids=[c[0] for c in FULL_HOUSE_CASES])
def test_full_house(name, hole, board):
    result = evaluate_hand(hole, board)
    assert result.hand_name == "Full House", f"Expected Full House, got {result.hand_name}"
    assert result.hand_rank == 4


# ═══════════════════════════════════════════════════════════════════
# FLUSH (rank 5)
# ═══════════════════════════════════════════════════════════════════

FLUSH_CASES = [
    ("ace_high_hearts", ["Ah", "9h"], ["7h", "4h", "2h", "Kc", "3d"]),
    ("king_high_diamonds", ["Kd", "9d"], ["7d", "4d", "2d", "Ac", "3h"]),
    ("queen_high_clubs", ["Qc", "9c"], ["7c", "4c", "2c", "Ah", "3d"]),
    ("jack_high_spades", ["Js", "9s"], ["7s", "4s", "2s", "Ah", "Kd"]),
    ("ten_high", ["10h", "8h"], ["6h", "4h", "2h", "Ac", "Kd"]),
    # 6 suited cards — picks best 5
    ("six_suited", ["Ah", "Kh"], ["Qh", "9h", "7h", "4h", "2c"]),
    # 7 suited cards — picks best 5
    ("seven_suited", ["Ah", "Kh"], ["Qh", "Jh", "9h", "7h", "4h"]),
    # Low flush
    ("low_flush", ["7h", "5h"], ["4h", "3h", "2h", "Ac", "Kd"]),
    # Board has 4 to a flush, hole completes
    ("board_four_flush", ["Ah", "2c"], ["Kh", "Qh", "Jh", "9h", "3d"]),
    # Board has 3 to a flush, both hole cards same suit
    ("both_holes_complete", ["Ah", "Kh"], ["Qh", "4c", "3h", "9d", "2h"]),
]

@pytest.mark.parametrize("name,hole,board", FLUSH_CASES, ids=[c[0] for c in FLUSH_CASES])
def test_flush(name, hole, board):
    result = evaluate_hand(hole, board)
    assert result.hand_name == "Flush", f"Expected Flush, got {result.hand_name}"
    assert result.hand_rank == 5


# ═══════════════════════════════════════════════════════════════════
# STRAIGHT (rank 6)
# ═══════════════════════════════════════════════════════════════════

STRAIGHT_CASES = [
    ("ace_high_broadway", ["Ah", "Kd"], ["Qc", "Js", "10h", "2c", "3d"]),
    ("king_high", ["Kh", "Qd"], ["Jc", "10s", "9h", "2c", "3d"]),
    ("queen_high", ["Qh", "Jd"], ["10c", "9s", "8h", "2c", "3d"]),
    ("jack_high", ["Jh", "10d"], ["9c", "8s", "7h", "2c", "3d"]),
    ("ten_high", ["10h", "9d"], ["8c", "7s", "6h", "2c", "3d"]),
    ("nine_high", ["9h", "8d"], ["7c", "6s", "5h", "2c", "Ad"]),
    ("eight_high", ["8h", "7d"], ["6c", "5s", "4h", "2c", "Ad"]),
    ("seven_high", ["7h", "6d"], ["5c", "4s", "3h", "Ac", "Kd"]),
    ("six_high", ["6h", "5d"], ["4c", "3s", "2h", "Ac", "Kd"]),
    # Ace-low straight (wheel): A-2-3-4-5
    ("ace_low_wheel", ["Ah", "2d"], ["3c", "4s", "5h", "Kc", "9d"]),
    ("ace_low_wheel_v2", ["Ah", "5d"], ["4c", "3s", "2h", "Kc", "9d"]),
    # Board has the straight
    ("board_straight", ["2c", "7d"], ["Ah", "Kd", "Qc", "Js", "10h"]),
    # Two possible straights — picks the higher one
    ("two_straights_picks_higher", ["Ah", "9d"], ["Kc", "Qs", "Jh", "10c", "8d"]),
]

@pytest.mark.parametrize("name,hole,board", STRAIGHT_CASES, ids=[c[0] for c in STRAIGHT_CASES])
def test_straight(name, hole, board):
    result = evaluate_hand(hole, board)
    assert result.hand_name == "Straight", f"Expected Straight, got {result.hand_name}"
    assert result.hand_rank == 6


# Verify ace-low straight is 5-high, not ace-high
def test_ace_low_straight_is_5_high():
    result = evaluate_hand(["Ah", "2d"], ["3c", "4s", "5h", "Kc", "9d"])
    assert result.tiebreaker == (5,)


def test_ace_high_straight_is_14_high():
    result = evaluate_hand(["Ah", "Kd"], ["Qc", "Js", "10h", "2c", "3d"])
    assert result.tiebreaker == (14,)


# NOT a straight: K-A-2-3-4 wrapping is invalid
def test_wrap_around_is_not_straight():
    result = evaluate_hand(["Kh", "Ad"], ["2c", "3s", "4h", "8c", "9d"])
    assert result.hand_name != "Straight"


# ═══════════════════════════════════════════════════════════════════
# THREE OF A KIND (rank 7)
# ═══════════════════════════════════════════════════════════════════

THREE_OF_A_KIND_CASES = [
    ("trip_aces", ["Ah", "Ad"], ["Ac", "Ks", "9h", "2c", "3d"]),
    ("trip_kings", ["Kh", "Kd"], ["Kc", "As", "9h", "2c", "3d"]),
    ("trip_queens", ["Qh", "Qd"], ["Qc", "As", "9h", "2c", "3d"]),
    ("trip_twos", ["2h", "2d"], ["2c", "As", "Kh", "9c", "7d"]),
    ("trip_tens", ["10h", "10d"], ["10c", "As", "Kh", "2c", "3d"]),
    ("trip_fives", ["5h", "5d"], ["5c", "As", "Kh", "2c", "3d"]),
    # Board has a pair, hole has the third
    ("board_pair_hole_third", ["Ah", "2c"], ["Ad", "Ac", "Ks", "9h", "3d"]),
    # Board has trips (hole cards are kickers)
    ("board_trips", ["Kh", "Qd"], ["Ah", "Ad", "Ac", "9s", "3d"]),
]

@pytest.mark.parametrize("name,hole,board", THREE_OF_A_KIND_CASES, ids=[c[0] for c in THREE_OF_A_KIND_CASES])
def test_three_of_a_kind(name, hole, board):
    result = evaluate_hand(hole, board)
    assert result.hand_name == "Three of a Kind", f"Expected Three of a Kind, got {result.hand_name}"
    assert result.hand_rank == 7


# ═══════════════════════════════════════════════════════════════════
# TWO PAIR (rank 8)
# ═══════════════════════════════════════════════════════════════════

TWO_PAIR_CASES = [
    ("aces_and_kings", ["Ah", "Kh"], ["Ad", "Kd", "9c", "2s", "3s"]),
    ("aces_and_queens", ["Ah", "Qh"], ["Ad", "Qd", "9c", "2s", "3s"]),
    ("kings_and_queens", ["Kh", "Qh"], ["Kd", "Qd", "9c", "2s", "3s"]),
    ("tens_and_nines", ["10h", "9h"], ["10d", "9d", "Ac", "2s", "3s"]),
    ("fives_and_fours", ["5h", "4h"], ["5d", "4d", "Ac", "9s", "Ks"]),
    ("twos_and_threes", ["2h", "3h"], ["2d", "3d", "Ac", "Ks", "9s"]),
    # Board has one pair, hole has another pair
    ("board_pair_hole_pair", ["Ah", "Ad"], ["Kh", "Kd", "9c", "2s", "3s"]),
    # Board has two pair
    ("board_two_pair", ["Qh", "2c"], ["Ah", "Ad", "Kh", "Kd", "9c"]),
    # Three pairs available (7 cards can have 3 pairs) — picks best two
    ("three_pairs_picks_best_two", ["Ah", "Kh"], ["Ad", "Kd", "Qc", "Qd", "2s"]),
]

@pytest.mark.parametrize("name,hole,board", TWO_PAIR_CASES, ids=[c[0] for c in TWO_PAIR_CASES])
def test_two_pair(name, hole, board):
    result = evaluate_hand(hole, board)
    assert result.hand_name == "Two Pair", f"Expected Two Pair, got {result.hand_name}"
    assert result.hand_rank == 8


# ═══════════════════════════════════════════════════════════════════
# PAIR (rank 9)
# ═══════════════════════════════════════════════════════════════════

PAIR_CASES = [
    ("pair_aces", ["Ah", "Ad"], ["Kc", "9s", "7h", "2c", "3d"]),
    ("pair_kings", ["Kh", "Kd"], ["Ac", "9s", "7h", "2c", "3d"]),
    ("pair_queens", ["Qh", "Qd"], ["Ac", "9s", "7h", "2c", "3d"]),
    ("pair_jacks", ["Jh", "Jd"], ["Ac", "9s", "7h", "2c", "3d"]),
    ("pair_tens", ["10h", "10d"], ["Ac", "9s", "7h", "2c", "3d"]),
    ("pair_nines", ["9h", "9d"], ["Ac", "Ks", "7h", "2c", "3d"]),
    ("pair_twos", ["2h", "2d"], ["Ac", "Ks", "Qh", "9c", "7d"]),
    # Pair on the board, hole cards are kickers
    ("board_pair", ["Ah", "Kd"], ["Qh", "Qd", "9c", "7s", "2h"]),
    # Hole card pairs with board card
    ("hole_pairs_board", ["Ah", "2c"], ["Ad", "Ks", "9h", "7c", "3d"]),
]

@pytest.mark.parametrize("name,hole,board", PAIR_CASES, ids=[c[0] for c in PAIR_CASES])
def test_pair(name, hole, board):
    result = evaluate_hand(hole, board)
    assert result.hand_name == "Pair", f"Expected Pair, got {result.hand_name}"
    assert result.hand_rank == 9


# ═══════════════════════════════════════════════════════════════════
# HIGH CARD (rank 10)
# ═══════════════════════════════════════════════════════════════════

HIGH_CARD_CASES = [
    ("ace_high", ["Ah", "Kd"], ["9c", "7s", "5h", "2c", "3d"]),
    ("king_high", ["Kh", "Qd"], ["9c", "7s", "5h", "2c", "3d"]),
    ("queen_high", ["Qh", "Jd"], ["9c", "7s", "4h", "2c", "3d"]),
    ("jack_high", ["Jh", "10d"], ["8c", "6s", "4h", "2c", "3d"]),
    ("ten_high", ["10h", "8d"], ["6c", "4s", "2h", "3c", "9d"]),
    # All low cards
    ("low_cards", ["7h", "5d"], ["4c", "3s", "2h", "9c", "8d"]),
    # Near-straight (4 consecutive, but not 5)
    ("near_straight_not_straight", ["Ah", "Kd"], ["Qc", "Js", "8h", "2c", "3d"]),
    # Near-flush (4 suited, but not 5)
    ("near_flush_not_flush", ["Ah", "Kh"], ["Qh", "Jh", "8c", "2c", "3d"]),
]

@pytest.mark.parametrize("name,hole,board", HIGH_CARD_CASES, ids=[c[0] for c in HIGH_CARD_CASES])
def test_high_card(name, hole, board):
    result = evaluate_hand(hole, board)
    assert result.hand_name == "High Card", f"Expected High Card, got {result.hand_name}"
    assert result.hand_rank == 10
