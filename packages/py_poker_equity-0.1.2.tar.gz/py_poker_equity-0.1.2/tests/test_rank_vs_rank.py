"""
Exhaustive rank-vs-rank tests.

Every hand rank must beat every lower hand rank.
This generates all 45 unique matchups (10 choose 2).
"""
import pytest
from py_poker_equity.evaluator import evaluate_hand, compute_winner

# Representative hands for each rank — carefully chosen to avoid
# accidentally making a better hand with the 7 cards.
RANK_EXAMPLES = {
    1: {
        "name": "Royal Flush",
        "hole": ["Ah", "Kh"],
        "board": ["Qh", "Jh", "10h", "2c", "3d"],
    },
    2: {
        "name": "Straight Flush",
        "hole": ["9s", "8s"],
        "board": ["7s", "6s", "5s", "2c", "3d"],
    },
    3: {
        "name": "Four of a Kind",
        "hole": ["Jh", "Jd"],
        "board": ["Jc", "Js", "4h", "2c", "3d"],
    },
    4: {
        "name": "Full House",
        "hole": ["10h", "10d"],
        "board": ["10c", "8h", "8d", "2c", "3d"],
    },
    5: {
        "name": "Flush",
        "hole": ["Kd", "9d"],
        "board": ["7d", "4d", "2d", "Ac", "3h"],
    },
    6: {
        "name": "Straight",
        "hole": ["Qc", "Jh"],
        "board": ["10d", "9s", "8c", "2h", "4d"],
    },
    7: {
        "name": "Three of a Kind",
        "hole": ["7h", "7d"],
        "board": ["7c", "Ks", "9h", "2c", "4d"],
    },
    8: {
        "name": "Two Pair",
        "hole": ["6h", "5h"],
        "board": ["6d", "5d", "Kc", "2s", "3s"],
    },
    9: {
        "name": "Pair",
        "hole": ["4h", "4d"],
        "board": ["Ac", "Ks", "9h", "7c", "2d"],
    },
    10: {
        "name": "High Card",
        "hole": ["Ah", "Qd"],
        "board": ["9c", "7s", "5h", "3c", "2d"],
    },
}

# Verify examples are classified correctly
@pytest.mark.parametrize("rank", range(1, 11))
def test_example_hand_classification(rank):
    ex = RANK_EXAMPLES[rank]
    result = evaluate_hand(ex["hole"], ex["board"])
    assert result.hand_name == ex["name"], (
        f"Rank {rank}: expected {ex['name']}, got {result.hand_name}"
    )


# Generate all 45 matchups where higher rank beats lower rank
MATCHUP_CASES = []
for higher_rank in range(1, 10):
    for lower_rank in range(higher_rank + 1, 11):
        h = RANK_EXAMPLES[higher_rank]
        l = RANK_EXAMPLES[lower_rank]
        MATCHUP_CASES.append((
            f"{h['name']}_beats_{l['name']}",
            higher_rank, lower_rank,
        ))

@pytest.mark.parametrize("name,higher_rank,lower_rank", MATCHUP_CASES,
                         ids=[c[0] for c in MATCHUP_CASES])
def test_higher_rank_beats_lower(name, higher_rank, lower_rank):
    h = RANK_EXAMPLES[higher_rank]
    l = RANK_EXAMPLES[lower_rank]
    winner_hand = evaluate_hand(h["hole"], h["board"])
    loser_hand = evaluate_hand(l["hole"], l["board"])
    result = compute_winner(winner_hand, loser_hand)
    assert result is winner_hand, (
        f"{h['name']} (rank {higher_rank}) should beat "
        f"{l['name']} (rank {lower_rank})"
    )
