"""
Tests that the evaluator correctly selects the best 5-card hand
from 7 available cards.

These are tricky scenarios where the board offers multiple possible
hands and the evaluator must pick the strongest one.
"""
import pytest
from py_poker_equity.evaluator import evaluate_hand


class TestBestFiveFromSeven:
    """The evaluator must pick the best 5 from 7 cards."""

    def test_flush_over_straight(self):
        """Board has both a straight and flush possible — flush wins."""
        # 5h 6h 7h 8h = 4 hearts, need one more for flush
        # 5 6 7 8 9 = straight
        result = evaluate_hand(["Ah", "9c"], ["5h", "6h", "7h", "8h", "2d"])
        assert result.hand_name == "Flush"

    def test_full_house_over_flush(self):
        """Board allows both flush and full house — full house wins."""
        result = evaluate_hand(["Ah", "Ad"], ["Ac", "Kh", "Kd", "Qh", "Jh"])
        assert result.hand_name == "Full House"

    def test_straight_flush_over_quads(self):
        """Extremely rare: both straight flush and quads possible — SF wins."""
        result = evaluate_hand(["9h", "8h"], ["7h", "6h", "5h", "5c", "5d"])
        assert result.hand_name == "Straight Flush"

    def test_higher_straight_selected(self):
        """Two straights possible, picks the higher one."""
        # 5-6-7-8-9 and 6-7-8-9-10 both possible
        result = evaluate_hand(["10h", "5d"], ["6c", "7s", "8h", "9c", "2d"])
        assert result.hand_name == "Straight"
        assert result.tiebreaker == (10,)  # 10-high, not 9-high

    def test_higher_flush_selected_from_six_suited(self):
        """Six suited cards — picks the best 5."""
        result = evaluate_hand(["Ah", "Kh"], ["Qh", "9h", "7h", "4h", "2c"])
        assert result.hand_name == "Flush"
        # Should be A K Q 9 7, not including 4
        assert result.tiebreaker == (14, 13, 12, 9, 7)

    def test_higher_flush_selected_from_seven_suited(self):
        """All 7 cards same suit — picks top 5."""
        result = evaluate_hand(["Ah", "Kh"], ["Qh", "Jh", "9h", "7h", "4h"])
        assert result.hand_name == "Flush"
        assert result.tiebreaker == (14, 13, 12, 11, 9)

    def test_board_plays_full_house_over_hole_pair(self):
        """Board has a full house that beats using the hole pair."""
        result = evaluate_hand(["2h", "2d"], ["Ah", "Ad", "Ac", "Kh", "Kd"])
        # Board has AAA KK — full house. Hole 22 doesn't help.
        assert result.hand_name == "Full House"
        assert result.tiebreaker == (14, 13)  # Aces full of kings

    def test_one_hole_card_contributes(self):
        """Only one hole card is part of the best hand."""
        result = evaluate_hand(["Ah", "2c"], ["Kh", "Qh", "Jh", "10h", "3d"])
        # Royal flush using Ah + board
        assert result.hand_name == "Royal Flush"

    def test_neither_hole_card_contributes(self):
        """Board is the best hand — hole cards are irrelevant."""
        result = evaluate_hand(["2c", "3d"], ["Ah", "Kh", "Qh", "Jh", "10h"])
        assert result.hand_name == "Royal Flush"

    def test_pocket_pair_becomes_set_not_two_pair(self):
        """Pocket pair hits the board — set beats two pair."""
        result = evaluate_hand(["7h", "7d"], ["7c", "Ah", "Kd", "2c", "3d"])
        assert result.hand_name == "Three of a Kind"

    def test_two_pair_on_board_plus_pocket_pair_makes_two_pair(self):
        """Board has two pair, pocket pair is lower — best is board's two pair."""
        result = evaluate_hand(["2h", "2d"], ["Ah", "Ad", "Kh", "Kd", "9c"])
        # Board has AA KK — two pair aces and kings with 9 kicker
        # Pocket 22 doesn't improve this
        assert result.hand_name == "Two Pair"
        assert result.tiebreaker[0] == 14  # top pair is aces
        assert result.tiebreaker[1] == 13  # second pair is kings

    def test_three_pairs_available_picks_best_two(self):
        """7 cards with 3 pairs — picks the two highest pairs."""
        result = evaluate_hand(["Ah", "Kd"], ["Ad", "Kc", "Qh", "Qs", "2c"])
        assert result.hand_name == "Two Pair"
        assert result.tiebreaker[0] == 14  # aces
        assert result.tiebreaker[1] == 13  # kings (not queens)

    def test_trips_on_board_pocket_pair_makes_full_house(self):
        """Board trips + pocket pair = full house."""
        result = evaluate_hand(["Kh", "Kd"], ["Ah", "Ad", "Ac", "9c", "3d"])
        assert result.hand_name == "Full House"
        assert result.tiebreaker == (14, 13)  # aces full of kings

    def test_four_to_flush_on_board_hole_completes(self):
        """Board has 4 suited, one hole card completes the flush."""
        result = evaluate_hand(["Ah", "2c"], ["Kh", "Qh", "Jh", "9h", "3d"])
        assert result.hand_name == "Flush"

    def test_four_to_straight_on_board_hole_completes(self):
        """Board has 4 to a straight, hole card completes it."""
        result = evaluate_hand(["Ah", "2c"], ["Kd", "Qc", "Js", "10h", "3d"])
        assert result.hand_name == "Straight"
        assert result.tiebreaker == (14,)


class TestBoardCounterfeiting:
    """Tests where the board counterfeits one or both players' hands."""

    def test_board_flush_counterfeits_pocket_aces(self):
        """Board is all hearts, AA with no hearts is worthless."""
        result = evaluate_hand(["Ac", "Ad"], ["4h", "5h", "7h", "9h", "2h"])
        assert result.hand_name == "Flush"
        # The flush is the board's flush — pocket aces don't contribute
        assert result.tiebreaker == (9, 7, 5, 4, 2)

    def test_board_flush_one_hole_card_plays(self):
        """Board has 4 hearts, one hole card is a higher heart."""
        result = evaluate_hand(["Ah", "Kc"], ["4h", "5h", "7h", "9h", "2d"])
        assert result.hand_name == "Flush"
        # Ah plays — flush is A 9 7 5 4
        assert result.tiebreaker == (14, 9, 7, 5, 4)

    def test_board_flush_both_holes_play(self):
        """Board has 3 hearts, both hole cards are hearts and improve the flush."""
        result = evaluate_hand(["Ah", "Kh"], ["4h", "5h", "7h", "9c", "2d"])
        assert result.hand_name == "Flush"
        assert result.tiebreaker == (14, 13, 7, 5, 4)

    def test_board_straight_counterfeits_set(self):
        """Board straight is better than a set made with hole cards."""
        result = evaluate_hand(["7c", "7d"], ["8h", "9d", "10c", "Js", "Qh"])
        assert result.hand_name == "Straight"
        assert result.tiebreaker == (12,)  # Q-high straight from board

    def test_board_two_pair_counterfeits_lower_pocket_pair(self):
        """Board has two pair higher than pocket pair — board plays."""
        result = evaluate_hand(["2c", "2d"], ["Ah", "Ad", "Kh", "Kd", "Qc"])
        assert result.hand_name == "Two Pair"
        assert result.tiebreaker[0] == 14  # aces
        assert result.tiebreaker[1] == 13  # kings

    def test_board_counterfeits_two_pair_with_higher_two_pair(self):
        """Player has two pair but board has a higher two pair."""
        result = evaluate_hand(["3c", "4d"], ["Ah", "Ad", "Kh", "Kd", "Qc"])
        assert result.hand_name == "Two Pair"
        assert result.tiebreaker[0] == 14
        assert result.tiebreaker[1] == 13

    def test_board_trips_plus_pocket_pair_makes_full_house(self):
        """Board trips + pocket pair = full house, not just trips."""
        result = evaluate_hand(["2c", "2d"], ["Ah", "Ad", "Ac", "Ks", "Qh"])
        # AAA 22 is a full house — pocket 22 actually helps here!
        assert result.hand_name == "Full House"
        assert result.tiebreaker == (14, 2)


class TestBoardPlaysScenarios:
    """Tests where the best 5-card hand is entirely on the board."""

    def test_board_straight(self):
        result = evaluate_hand(["2h", "3d"], ["Ah", "Kd", "Qc", "Js", "10h"])
        assert result.hand_name == "Straight"
        assert result.tiebreaker == (14,)

    def test_board_flush(self):
        result = evaluate_hand(["2c", "3d"], ["Ah", "Kh", "Qh", "Jh", "9h"])
        assert result.hand_name == "Flush"

    def test_board_full_house(self):
        result = evaluate_hand(["2c", "3d"], ["Ah", "Ad", "Ac", "Kh", "Kd"])
        assert result.hand_name == "Full House"

    def test_board_quads(self):
        result = evaluate_hand(["2c", "3d"], ["Ah", "Ad", "Ac", "As", "Kh"])
        assert result.hand_name == "Four of a Kind"

    def test_board_two_pair(self):
        result = evaluate_hand(["2c", "3d"], ["Ah", "Ad", "Kh", "Kd", "9c"])
        assert result.hand_name == "Two Pair"

    def test_board_trips(self):
        result = evaluate_hand(["2c", "3d"], ["Ah", "Ad", "Ac", "Ks", "9h"])
        assert result.hand_name == "Three of a Kind"

    def test_board_pair(self):
        result = evaluate_hand(["2c", "3d"], ["Ah", "Ad", "Ks", "9h", "7c"])
        assert result.hand_name == "Pair"
