import pytest
from py_poker_equity.evaluator import evaluate_hand, compute_winner, parse_card


class TestParseCard:
    def test_ace_of_hearts(self):
        c = parse_card("Ah")
        assert c.rank == 14
        assert c.suit == 'h'

    def test_ten_of_spades(self):
        c = parse_card("10s")
        assert c.rank == 10
        assert c.suit == 's'

    def test_two_of_clubs(self):
        c = parse_card("2c")
        assert c.rank == 2
        assert c.suit == 'c'

    def test_invalid_suit(self):
        with pytest.raises(ValueError):
            parse_card("Ax")

    def test_invalid_rank(self):
        with pytest.raises(ValueError):
            parse_card("1h")


class TestEvaluateHand:
    def test_royal_flush(self):
        result = evaluate_hand(["Ah", "Kh"], ["Qh", "Jh", "10h", "2c", "3d"])
        assert result.hand_name == "Royal Flush"
        assert result.hand_rank == 1

    def test_straight_flush(self):
        result = evaluate_hand(["9h", "8h"], ["7h", "6h", "5h", "2c", "3d"])
        assert result.hand_name == "Straight Flush"

    def test_four_of_a_kind(self):
        result = evaluate_hand(["Ah", "Ad"], ["Ac", "As", "5h", "2c", "3d"])
        assert result.hand_name == "Four of a Kind"

    def test_full_house(self):
        result = evaluate_hand(["Ah", "Ad"], ["Ac", "Ks", "Kh", "2c", "3d"])
        assert result.hand_name == "Full House"

    def test_flush(self):
        result = evaluate_hand(["Ah", "9h"], ["7h", "4h", "2h", "Kc", "3d"])
        assert result.hand_name == "Flush"

    def test_straight(self):
        result = evaluate_hand(["9h", "8d"], ["7c", "6s", "5h", "2c", "Kd"])
        assert result.hand_name == "Straight"

    def test_ace_low_straight(self):
        result = evaluate_hand(["Ah", "2d"], ["3c", "4s", "5h", "9c", "Kd"])
        assert result.hand_name == "Straight"

    def test_three_of_a_kind(self):
        result = evaluate_hand(["Ah", "Ad"], ["Ac", "Ks", "7h", "2c", "3d"])
        assert result.hand_name == "Three of a Kind"

    def test_two_pair(self):
        result = evaluate_hand(["Ah", "Kd"], ["Ac", "Ks", "7h", "2c", "3d"])
        assert result.hand_name == "Two Pair"

    def test_pair(self):
        result = evaluate_hand(["Ah", "Kd"], ["Ac", "9s", "7h", "2c", "3d"])
        assert result.hand_name == "Pair"

    def test_high_card(self):
        result = evaluate_hand(["Ah", "Kd"], ["9c", "7s", "5h", "2c", "3d"])
        assert result.hand_name == "High Card"


class TestComputeWinner:
    def test_higher_hand_rank_wins(self):
        flush = evaluate_hand(["Ah", "9h"], ["7h", "4h", "2h", "Kc", "3d"])
        pair = evaluate_hand(["Ah", "Ad"], ["9c", "7s", "5h", "2c", "3d"])
        assert compute_winner(flush, pair) is flush

    def test_same_rank_higher_tiebreaker_wins(self):
        high_pair = evaluate_hand(["Ah", "Ad"], ["9c", "7s", "5h", "2c", "3d"])
        low_pair = evaluate_hand(["Kh", "Kd"], ["9c", "7s", "5h", "2c", "3d"])
        assert compute_winner(high_pair, low_pair) is high_pair

    def test_tie(self):
        # Same board, same hole cards (different suits)
        a = evaluate_hand(["Ah", "Kd"], ["9c", "7s", "5h", "2c", "3d"])
        b = evaluate_hand(["As", "Kc"], ["9c", "7s", "5h", "2c", "3d"])
        assert compute_winner(a, b) is None
