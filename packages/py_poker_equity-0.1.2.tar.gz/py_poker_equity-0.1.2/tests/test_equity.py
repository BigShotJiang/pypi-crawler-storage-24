import pytest
from py_poker_equity.equity import get_equity, _canonicalize_hole_cards


class TestCanonicalizeHoleCards:
    def test_pair(self):
        assert _canonicalize_hole_cards(["Ah", "Ad"]) == "AA"

    def test_suited_ordered(self):
        assert _canonicalize_hole_cards(["Ah", "Kh"]) == "AKs"

    def test_suited_reversed(self):
        assert _canonicalize_hole_cards(["Kh", "Ah"]) == "AKs"

    def test_offsuit_ordered(self):
        assert _canonicalize_hole_cards(["Ah", "Kd"]) == "AKo"

    def test_offsuit_reversed(self):
        assert _canonicalize_hole_cards(["Kd", "Ah"]) == "AKo"

    def test_ten(self):
        assert _canonicalize_hole_cards(["10h", "9h"]) == "T9s"

    def test_ten_pair(self):
        assert _canonicalize_hole_cards(["10h", "10d"]) == "TT"

    def test_ten_offsuit(self):
        assert _canonicalize_hole_cards(["10h", "9d"]) == "T9o"

    def test_low_pair(self):
        assert _canonicalize_hole_cards(["2h", "2d"]) == "22"


class TestGetEquityPostFlop:
    def test_river_clear_winner(self):
        # A has a flush, B has a pair
        result = get_equity(
            ["Ah", "Kh"],
            ["2c", "3d"],
            ["Qh", "Jh", "10h", "5c", "8d"]
        )
        assert result['a_win'] == 100.0
        assert result['b_win'] == 0.0

    def test_river_tie(self):
        # Board plays — both have same best 5 cards
        result = get_equity(
            ["2h", "3d"],
            ["2c", "3s"],
            ["Ah", "Kd", "Qc", "Js", "10h"]
        )
        assert result['tie'] == 100.0

    def test_turn_returns_percentages(self):
        result = get_equity(
            ["Ah", "Kh"],
            ["2c", "7d"],
            ["Qh", "Jh", "5c", "8d"]
        )
        assert 0 <= result['a_win'] <= 100
        assert 0 <= result['b_win'] <= 100
        assert 0 <= result['tie'] <= 100
        assert abs(result['a_win'] + result['b_win'] + result['tie'] - 100) < 0.1

    def test_flop_returns_percentages(self):
        result = get_equity(
            ["Ah", "Kh"],
            ["2c", "7d"],
            ["Qh", "Jh", "5c"]
        )
        total = result['a_win'] + result['b_win'] + result['tie']
        assert abs(total - 100) < 0.1

    def test_duplicate_cards_raises(self):
        with pytest.raises(ValueError, match="Duplicate"):
            get_equity(
                ["Ah", "Kh"],
                ["Ah", "7d"],
                ["Qh", "Jh", "5c"]
            )

    def test_invalid_board_size_raises(self):
        with pytest.raises(ValueError, match="Board must have"):
            get_equity(["Ah", "Kh"], ["2c", "7d"], ["Qh", "Jh"])
