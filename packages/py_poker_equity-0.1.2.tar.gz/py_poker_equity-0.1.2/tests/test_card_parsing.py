"""
Exhaustive card parsing tests.

Tests every valid card in the deck and many invalid inputs.
"""
import pytest
from py_poker_equity.evaluator import parse_card, RANK_MAP, VALID_SUITS


# ═══════════════════════════════════════════════════════════════════
# ALL 52 VALID CARDS
# ═══════════════════════════════════════════════════════════════════

ALL_VALID_CARDS = []
for rank_str, rank_val in RANK_MAP.items():
    for suit in sorted(VALID_SUITS):
        ALL_VALID_CARDS.append((f"{rank_str}{suit}", rank_val, suit))

@pytest.mark.parametrize("notation,expected_rank,expected_suit", ALL_VALID_CARDS,
                         ids=[c[0] for c in ALL_VALID_CARDS])
def test_valid_card(notation, expected_rank, expected_suit):
    card = parse_card(notation)
    assert card.rank == expected_rank
    assert card.suit == expected_suit


# ═══════════════════════════════════════════════════════════════════
# CASE INSENSITIVITY
# ═══════════════════════════════════════════════════════════════════

CASE_CASES = [
    ("Ah", 14, 'h'),
    ("AH", 14, 'h'),
    ("ah", 14, 'h'),  # lowercase rank won't work since rank_str.upper() is called
    ("kD", 13, 'd'),
    ("KD", 13, 'd'),
    ("10S", 10, 's'),
    ("10s", 10, 's'),
    ("jC", 11, 'c'),
    ("JC", 11, 'c'),
    ("qH", 12, 'h'),
]

@pytest.mark.parametrize("notation,expected_rank,expected_suit", CASE_CASES,
                         ids=[c[0] for c in CASE_CASES])
def test_case_handling(notation, expected_rank, expected_suit):
    card = parse_card(notation)
    assert card.rank == expected_rank
    assert card.suit == expected_suit


# ═══════════════════════════════════════════════════════════════════
# WHITESPACE HANDLING
# ═══════════════════════════════════════════════════════════════════

WHITESPACE_CASES = [
    (" Ah", 14, 'h'),
    ("Ah ", 14, 'h'),
    (" Ah ", 14, 'h'),
    ("  10s  ", 10, 's'),
]

@pytest.mark.parametrize("notation,expected_rank,expected_suit", WHITESPACE_CASES,
                         ids=[f"'{c[0]}'" for c in WHITESPACE_CASES])
def test_whitespace_stripped(notation, expected_rank, expected_suit):
    card = parse_card(notation)
    assert card.rank == expected_rank
    assert card.suit == expected_suit


# ═══════════════════════════════════════════════════════════════════
# INVALID INPUTS
# ═══════════════════════════════════════════════════════════════════

INVALID_CASES = [
    ("empty_string", ""),
    ("single_char", "A"),
    ("too_long", "10hx"),
    ("invalid_suit_x", "Ax"),
    ("invalid_suit_z", "Az"),
    ("invalid_suit_1", "A1"),
    ("invalid_rank_1", "1h"),
    ("invalid_rank_0", "0h"),
    ("invalid_rank_11", "11h"),
    ("invalid_rank_15", "15h"),
    ("invalid_rank_X", "Xh"),
    ("just_suit", "h"),
    ("numbers_only", "12"),
    ("suit_first", "hA"),
    ("special_chars", "!@"),
]

@pytest.mark.parametrize("name,notation", INVALID_CASES, ids=[c[0] for c in INVALID_CASES])
def test_invalid_card_raises(name, notation):
    with pytest.raises(ValueError):
        parse_card(notation)
