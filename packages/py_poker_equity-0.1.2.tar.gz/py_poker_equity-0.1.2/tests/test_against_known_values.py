"""
Tests against known, trusted equity values from CardFight.com and FlopTurnRiver.com.

These sources use exhaustive enumeration of all board runouts.
The published figures are suit-averaged (e.g. "AA vs KK" averages across
all specific suited combos). Our calculator uses specific cards, so we
test with a tolerance of ±1.5% to account for suit-specific variance.

Sources:
    - https://www.cardfight.com/AA_KK.html (and other matchup pages)
    - https://flopturnriver.com/poker-strategy/poker-hands-odds-19535/
    - https://caniwin.com/texasholdem/preflop/heads-up.php
"""
import pytest
from py_poker_equity.equity import get_equity
from py_poker_equity.evaluator import evaluate_hand, compute_winner


# ── Tolerance for suit-averaged vs specific-card variance ──
# Suit-averaged equity and specific-card equity can differ by ~1-2%.
# For example, AhAd vs KhKd = 82.64% but AhAd vs KcKs = 81.26%.
# We use 1.5% tolerance to account for this.
TOLERANCE = 1.5


def _assert_equity_close(result, expected_a_win, expected_b_win, expected_tie, tol=TOLERANCE):
    """Assert equity percentages are within tolerance of expected values."""
    assert abs(result['a_win'] - expected_a_win) < tol, (
        f"a_win: expected ~{expected_a_win}%, got {result['a_win']}%"
    )
    assert abs(result['b_win'] - expected_b_win) < tol, (
        f"b_win: expected ~{expected_b_win}%, got {result['b_win']}%"
    )
    assert abs(result['tie'] - expected_tie) < tol, (
        f"tie: expected ~{expected_tie}%, got {result['tie']}%"
    )
    # Percentages must sum to ~100
    total = result['a_win'] + result['b_win'] + result['tie']
    assert abs(total - 100) < 0.1, f"Percentages sum to {total}, expected ~100"


# ═══════════════════════════════════════════════════════════════════
# EVALUATOR CORRECTNESS — verify hand ranking is correct
# ═══════════════════════════════════════════════════════════════════

class TestHandRankingCorrectness:
    """Verify the evaluator picks the right hand from 7 cards."""

    def test_royal_flush_beats_straight_flush(self):
        royal = evaluate_hand(["Ah", "Kh"], ["Qh", "Jh", "10h", "2c", "3d"])
        sf = evaluate_hand(["9h", "8h"], ["7h", "6h", "5h", "2c", "3d"])
        assert royal.hand_rank == 1
        assert sf.hand_rank == 2
        assert compute_winner(royal, sf) is royal

    def test_four_of_a_kind_beats_full_house(self):
        quads = evaluate_hand(["Ah", "Ad"], ["Ac", "As", "Kh", "2c", "3d"])
        boat = evaluate_hand(["Kh", "Kd"], ["Kc", "As", "Ah", "2c", "3d"])
        assert quads.hand_rank == 3
        assert boat.hand_rank == 4
        assert compute_winner(quads, boat) is quads

    def test_flush_beats_straight(self):
        flush = evaluate_hand(["Ah", "9h"], ["7h", "4h", "2h", "Kc", "3d"])
        straight = evaluate_hand(["9c", "8d"], ["7s", "6h", "5c", "2d", "Kh"])
        assert flush.hand_rank == 5
        assert straight.hand_rank == 6
        assert compute_winner(flush, straight) is flush

    def test_full_house_beats_flush(self):
        boat = evaluate_hand(["Ah", "Ad"], ["Ac", "Ks", "Kh", "2c", "3d"])
        flush = evaluate_hand(["Qh", "9h"], ["7h", "4h", "2h", "Kc", "3d"])
        assert compute_winner(boat, flush) is boat

    def test_straight_beats_three_of_a_kind(self):
        straight = evaluate_hand(["9c", "8d"], ["7s", "6h", "5c", "2d", "Kh"])
        trips = evaluate_hand(["Ah", "Ad"], ["Ac", "9s", "7c", "2c", "3d"])
        assert compute_winner(straight, trips) is straight

    def test_two_pair_beats_one_pair(self):
        two_pair = evaluate_hand(["Ah", "Kd"], ["Ac", "Ks", "7h", "2c", "3d"])
        one_pair = evaluate_hand(["Ah", "Qd"], ["Ac", "9s", "7h", "2c", "3d"])
        assert compute_winner(two_pair, one_pair) is two_pair

    def test_pair_beats_high_card(self):
        pair = evaluate_hand(["Ah", "Ad"], ["9c", "7s", "5h", "2c", "3d"])
        high = evaluate_hand(["Ah", "Kd"], ["9c", "7s", "5h", "2c", "3d"])
        assert compute_winner(pair, high) is pair

    def test_higher_pair_wins(self):
        aces = evaluate_hand(["Ah", "Ad"], ["9c", "7s", "5h", "2c", "3d"])
        kings = evaluate_hand(["Kh", "Kd"], ["9c", "7s", "5h", "2c", "3d"])
        assert compute_winner(aces, kings) is aces

    def test_higher_kicker_wins_same_pair(self):
        ak = evaluate_hand(["Ah", "Kd"], ["Ac", "9s", "7h", "2c", "3d"])
        aq = evaluate_hand(["As", "Qd"], ["Ad", "9s", "7h", "2c", "3d"])
        assert compute_winner(ak, aq) is ak

    def test_ace_low_straight(self):
        result = evaluate_hand(["Ah", "2d"], ["3c", "4s", "5h", "9c", "Kd"])
        assert result.hand_name == "Straight"
        assert result.tiebreaker == (5,)  # 5-high straight

    def test_ace_high_straight(self):
        result = evaluate_hand(["Ah", "Kd"], ["Qc", "Js", "10h", "2c", "3d"])
        assert result.hand_name == "Straight"
        assert result.tiebreaker == (14,)  # ace-high straight

    def test_board_plays_tie(self):
        """When the board is the best hand for both, it's a tie."""
        board = ["Ah", "Kd", "Qc", "Js", "10h"]
        a = evaluate_hand(["2h", "3d"], board)
        b = evaluate_hand(["2c", "3s"], board)
        assert compute_winner(a, b) is None

    def test_picks_best_five_from_seven(self):
        """Verify the evaluator picks the best 5 from 7 cards, not just any 5."""
        # Hole cards make a flush, but board also has a full house available
        result = evaluate_hand(["Ah", "Kh"], ["Qh", "Qd", "Qc", "2h", "3h"])
        # Best hand is three queens with AK kickers, not the flush
        # Actually: Ah Kh Qh 2h 3h = flush (A-high), vs Qh Qd Qc Ah Kh = trips
        # Flush (rank 5) beats Three of a Kind (rank 7)
        assert result.hand_name == "Flush"


# ═══════════════════════════════════════════════════════════════════
# POST-FLOP EQUITY — deterministic river scenarios
# ═══════════════════════════════════════════════════════════════════

class TestRiverEquity:
    """River equity is deterministic — one player wins or it's a tie."""

    def test_overpair_beats_underpair(self):
        result = get_equity(
            ["Ah", "Ad"],
            ["Kh", "Kd"],
            board=["9c", "7s", "5h", "2c", "3d"]
        )
        assert result['a_win'] == 100.0

    def test_flush_beats_straight(self):
        result = get_equity(
            ["Ah", "9h"],
            ["8c", "6d"],
            board=["7h", "4h", "2h", "5s", "Kd"]
        )
        assert result['a_win'] == 100.0

    def test_set_beats_two_pair(self):
        result = get_equity(
            ["9h", "9d"],
            ["Ah", "Kd"],
            board=["9c", "Ac", "Ks", "2c", "3d"]
        )
        assert result['a_win'] == 100.0

    def test_board_plays_is_tie(self):
        result = get_equity(
            ["2h", "3d"],
            ["2c", "4s"],
            board=["Ah", "Kd", "Qc", "Js", "10h"]
        )
        assert result['tie'] == 100.0

    def test_bad_beat_scenario(self):
        """Player A has full house (aces full), player B has full house (kings full)."""
        result = get_equity(
            ["Ah", "Ad"],
            ["Kh", "Kd"],
            board=["Ac", "Ks", "9c", "9h", "3d"]
        )
        assert result['a_win'] == 100.0  # AAA 99 beats KKK 99


class TestTurnEquity:
    """Turn equity enumerates ~44 remaining cards."""

    def test_nut_flush_draw_vs_pair(self):
        """Flush draw should win roughly 20-25% of the time on the turn."""
        result = get_equity(
            ["Ah", "Kh"],  # nut flush draw
            ["Qc", "Qd"],  # pair of queens
            board=["7h", "4h", "9c", "2d"]
        )
        # Flush draw hits ~20% of the time (9 outs / ~44 cards)
        # Plus some overcard outs
        assert result['a_win'] > 15
        assert result['a_win'] < 45
        total = result['a_win'] + result['b_win'] + result['tie']
        assert abs(total - 100) < 0.1

    def test_set_vs_flush_draw_on_turn(self):
        """Set is a heavy favorite vs flush draw on the turn."""
        result = get_equity(
            ["9h", "9d"],  # set of nines
            ["Ah", "Kh"],  # nut flush draw
            board=["9c", "7h", "4h", "2d"]
        )
        assert result['a_win'] > 60  # set should be big favorite


class TestFlopEquity:
    """Flop equity enumerates ~946 remaining board combos."""

    def test_overpair_vs_underpair_on_flop(self):
        """Overpair should be ~80% favorite vs underpair on a dry flop."""
        result = get_equity(
            ["Ah", "Ad"],
            ["Kh", "Kd"],
            board=["7c", "4s", "2h"]
        )
        assert result['a_win'] > 75
        assert result['a_win'] < 95

    def test_set_vs_overpair_on_flop(self):
        """Set should be massive favorite vs overpair."""
        result = get_equity(
            ["7h", "7d"],  # set
            ["Ah", "Ad"],  # overpair
            board=["7c", "4s", "2h"]
        )
        assert result['a_win'] > 85


# ═══════════════════════════════════════════════════════════════════
# PREFLOP EQUITY — against CardFight.com trusted values
# (These tests require the preflop table to be generated)
# ═══════════════════════════════════════════════════════════════════

def _has_preflop_table():
    """Check if preflop table exists."""
    import os
    table_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        'src', 'py_poker_equity', 'data', 'preflop_table.json'
    )
    return os.path.exists(table_path)


@pytest.mark.skipif(not _has_preflop_table(), reason="Preflop table not generated yet")
class TestPreflopEquityVsCardFight:
    """
    Verify preflop equity against CardFight.com published values.

    CardFight values are suit-averaged. Our calculator uses specific cards.
    Tolerance is ±1.5% to account for suit-specific variance.

    Sources:
        https://www.cardfight.com/AA_KK.html
        https://www.cardfight.com/AA_QQ.html
        https://www.cardfight.com/KK_QQ.html
        etc.
    """

    # ── Pair vs Pair ──

    def test_aa_vs_kk(self):
        # CardFight: AA 81.71% win, 0.46% tie, KK 17.82% win
        result = get_equity(["Ah", "Ad"], ["Kh", "Kd"])
        _assert_equity_close(result, 81.71, 17.82, 0.46)

    def test_aa_vs_qq(self):
        # CardFight: AA 81.33% win, 0.43% tie, QQ 18.24% win
        result = get_equity(["Ah", "Ad"], ["Qh", "Qd"])
        _assert_equity_close(result, 81.33, 18.24, 0.43)

    def test_aa_vs_22(self):
        # CardFight: AA 81.95% win, 0.54% tie, 22 17.51% win
        result = get_equity(["Ah", "Ad"], ["2h", "2d"])
        _assert_equity_close(result, 81.95, 17.51, 0.54)

    def test_kk_vs_qq(self):
        # CardFight: KK 81.70% win, 0.46% tie, QQ 17.83% win
        result = get_equity(["Kh", "Kd"], ["Qh", "Qd"])
        _assert_equity_close(result, 81.70, 17.83, 0.46)

    def test_qq_vs_jj(self):
        # CardFight: QQ 81.75% win, 0.44% tie, JJ 17.81% win
        result = get_equity(["Qh", "Qd"], ["Jh", "Jd"])
        _assert_equity_close(result, 81.75, 17.81, 0.44)

    # ── Pair vs Overcards ("coin flip") ──

    def test_jj_vs_aks(self):
        # CardFight: JJ 53.83% win, 0.42% tie, AKs 45.75% win
        result = get_equity(["Jh", "Jd"], ["Ah", "Kh"])
        _assert_equity_close(result, 53.83, 45.75, 0.42)

    def test_jj_vs_ako(self):
        # CardFight: JJ 56.65% win, 0.41% tie, AKo 42.95% win
        result = get_equity(["Jh", "Jd"], ["Ah", "Kd"])
        _assert_equity_close(result, 56.65, 42.95, 0.41)

    def test_tt_vs_aks(self):
        # CardFight: TT 53.86% win, 0.41% tie, AKs 45.73% win
        result = get_equity(["10h", "10d"], ["Ah", "Kh"])
        _assert_equity_close(result, 53.86, 45.73, 0.41)

    def test_22_vs_aks(self):
        # CardFight: 22 49.78% win, 0.65% tie, AKs 49.57% win
        result = get_equity(["2h", "2d"], ["Ah", "Kh"])
        _assert_equity_close(result, 49.78, 49.57, 0.65)

    # ── Domination matchups ──

    def test_aa_vs_aks(self):
        # CardFight: AA 87.23% win, 1.26% tie, AKs 11.51% win
        result = get_equity(["Ah", "Ad"], ["Ac", "Kc"])
        _assert_equity_close(result, 87.23, 11.51, 1.26)

    def test_kk_vs_aks(self):
        # CardFight: KK 65.48% win, 0.82% tie, AKs 33.69% win
        result = get_equity(["Kh", "Kd"], ["Ah", "Kh"])
        # Note: card conflict — Kh used twice. Use different suits.
        result = get_equity(["Kh", "Kd"], ["Ac", "Kc"])
        _assert_equity_close(result, 65.48, 33.69, 0.82)

    def test_kk_vs_ako(self):
        # CardFight: KK 69.46% win, 0.85% tie, AKo 29.70% win
        result = get_equity(["Kh", "Kd"], ["Ac", "Ks"])
        _assert_equity_close(result, 69.46, 29.70, 0.85)

    def test_qq_vs_aks(self):
        # CardFight: QQ 53.73% win, 0.43% tie, AKs 45.83% win
        result = get_equity(["Qh", "Qd"], ["Ah", "Kh"])
        _assert_equity_close(result, 53.73, 45.83, 0.43)

    def test_qq_vs_ako(self):
        # CardFight: QQ 56.55% win, 0.42% tie, AKo 43.03% win
        result = get_equity(["Qh", "Qd"], ["Ah", "Kd"])
        _assert_equity_close(result, 56.55, 43.03, 0.42)

    def test_ako_vs_aqo(self):
        # CardFight: AKo 72.06% win, 4.67% tie, AQo 23.27% win
        result = get_equity(["Ah", "Kd"], ["Ac", "Qs"])
        _assert_equity_close(result, 72.06, 23.27, 4.67)

    def test_aks_vs_qjs(self):
        # CardFight: AKs 63.27% win, 0.52% tie, QJs 36.21% win
        result = get_equity(["Ah", "Kh"], ["Qd", "Jd"])
        _assert_equity_close(result, 63.27, 36.21, 0.52)


# ═══════════════════════════════════════════════════════════════════
# EDGE CASES
# ═══════════════════════════════════════════════════════════════════

class TestEdgeCases:
    def test_duplicate_cards_raises(self):
        with pytest.raises(ValueError, match="Duplicate"):
            get_equity(["Ah", "Kh"], ["Ah", "Qd"], board=["7c", "4s", "2h"])

    def test_invalid_board_size_raises(self):
        with pytest.raises(ValueError, match="Board must have"):
            get_equity(["Ah", "Kh"], ["Qd", "Qc"], board=["7c", "4s"])

    def test_results_always_sum_to_100(self):
        """Spot check that results sum to 100 across various flop scenarios."""
        scenarios = [
            (["Ah", "Kh"], ["2c", "7d"], ["Qh", "Jh", "5c"]),
            (["Ah", "Ad"], ["Kh", "Kd"], ["7c", "4s", "2h"]),
            (["10h", "10d"], ["Ah", "Kd"], ["9c", "8s", "2h"]),
            (["5h", "5d"], ["Ah", "Ad"], ["5c", "Ks", "Qh"]),
        ]
        for hand_a, hand_b, board in scenarios:
            result = get_equity(hand_a, hand_b, board)
            total = result['a_win'] + result['b_win'] + result['tie']
            assert abs(total - 100) < 0.1, f"Sum is {total} for {hand_a} vs {hand_b} on {board}"
