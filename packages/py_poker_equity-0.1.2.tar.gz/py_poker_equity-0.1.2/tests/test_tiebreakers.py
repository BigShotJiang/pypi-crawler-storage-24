"""
Exhaustive tiebreaker tests.

When two hands have the same hand rank, the tiebreaker tuple determines
the winner. These tests verify correct tiebreaker behavior within each
hand rank.
"""
import pytest
from py_poker_equity.evaluator import evaluate_hand, compute_winner


# ═══════════════════════════════════════════════════════════════════
# STRAIGHT FLUSH TIEBREAKERS
# ═══════════════════════════════════════════════════════════════════

STRAIGHT_FLUSH_TIEBREAKER_CASES = [
    # (id, winner_hole, winner_board, loser_hole, loser_board)
    ("K_high_beats_Q_high",
     ["Kh", "Qh"], ["Jh", "10h", "9h", "2c", "3d"],
     ["Qd", "Jd"], ["10d", "9d", "8d", "2c", "3h"]),
    ("9_high_beats_8_high",
     ["9h", "8h"], ["7h", "6h", "5h", "2c", "3d"],
     ["8d", "7d"], ["6d", "5d", "4d", "2c", "3h"]),
    ("6_high_beats_5_high_wheel",
     ["6h", "5h"], ["4h", "3h", "2h", "Ac", "Kd"],
     ["Ad", "2d"], ["3d", "4d", "5d", "Kc", "Qh"]),
]

@pytest.mark.parametrize("name,wh,wb,lh,lb", STRAIGHT_FLUSH_TIEBREAKER_CASES,
                         ids=[c[0] for c in STRAIGHT_FLUSH_TIEBREAKER_CASES])
def test_straight_flush_tiebreaker(name, wh, wb, lh, lb):
    winner = evaluate_hand(wh, wb)
    loser = evaluate_hand(lh, lb)
    assert winner.hand_name == "Straight Flush"
    assert loser.hand_name == "Straight Flush"
    assert compute_winner(winner, loser) is winner


def test_straight_flush_tie():
    # Same straight flush on two different boards (same cards effectively)
    a = evaluate_hand(["9h", "8h"], ["7h", "6h", "5h", "2c", "3d"])
    b = evaluate_hand(["9h", "8h"], ["7h", "6h", "5h", "Ac", "Kd"])
    # Same hole+flush cards, should tie
    assert a.tiebreaker == b.tiebreaker


# ═══════════════════════════════════════════════════════════════════
# FOUR OF A KIND TIEBREAKERS
# ═══════════════════════════════════════════════════════════════════

QUADS_TIEBREAKER_CASES = [
    # Higher quads beat lower quads
    ("quad_aces_beat_quad_kings",
     ["Ah", "Ad"], ["Ac", "As", "9h", "2c", "3d"],
     ["Kh", "Kd"], ["Kc", "Ks", "Ah", "2c", "3d"]),
    ("quad_kings_beat_quad_queens",
     ["Kh", "Kd"], ["Kc", "Ks", "Ah", "2c", "3d"],
     ["Qh", "Qd"], ["Qc", "Qs", "Ah", "2c", "3d"]),
    ("quad_tens_beat_quad_nines",
     ["10h", "10d"], ["10c", "10s", "Ah", "2c", "3d"],
     ["9h", "9d"], ["9c", "9s", "Ah", "2c", "3d"]),
]

@pytest.mark.parametrize("name,wh,wb,lh,lb", QUADS_TIEBREAKER_CASES,
                         ids=[c[0] for c in QUADS_TIEBREAKER_CASES])
def test_quads_rank_tiebreaker(name, wh, wb, lh, lb):
    winner = evaluate_hand(wh, wb)
    loser = evaluate_hand(lh, lb)
    assert winner.hand_name == "Four of a Kind"
    assert loser.hand_name == "Four of a Kind"
    assert compute_winner(winner, loser) is winner


QUADS_KICKER_CASES = [
    # Same quads, higher kicker wins
    ("quad_aces_K_kicker_beats_Q_kicker",
     ["Ah", "Ad"], ["Ac", "As", "Kh", "2c", "3d"],
     ["Ah", "Ad"], ["Ac", "As", "Qh", "2c", "3d"]),
    ("quad_kings_A_kicker_beats_Q_kicker",
     ["Kh", "Kd"], ["Kc", "Ks", "Ah", "2c", "3d"],
     ["Kh", "Kd"], ["Kc", "Ks", "Qh", "2c", "3d"]),
]

@pytest.mark.parametrize("name,wh,wb,lh,lb", QUADS_KICKER_CASES,
                         ids=[c[0] for c in QUADS_KICKER_CASES])
def test_quads_kicker_tiebreaker(name, wh, wb, lh, lb):
    winner = evaluate_hand(wh, wb)
    loser = evaluate_hand(lh, lb)
    assert compute_winner(winner, loser) is winner


# ═══════════════════════════════════════════════════════════════════
# FULL HOUSE TIEBREAKERS
# ═══════════════════════════════════════════════════════════════════

FULL_HOUSE_TIEBREAKER_CASES = [
    # Higher trips wins
    ("aces_full_beats_kings_full",
     ["Ah", "Ad"], ["Ac", "Kh", "Kd", "2c", "3d"],
     ["Kh", "Kd"], ["Kc", "Qh", "Qd", "2c", "3d"]),
    ("kings_full_beats_queens_full",
     ["Kh", "Kd"], ["Kc", "Ah", "Ad", "2c", "3d"],
     ["Qh", "Qd"], ["Qc", "Ah", "Ad", "2c", "3d"]),
    # Same trips, higher pair wins
    ("aces_full_of_kings_beats_aces_full_of_queens",
     ["Ah", "Ad"], ["Ac", "Kh", "Kd", "2c", "3d"],
     ["Ah", "Ad"], ["Ac", "Qh", "Qd", "2c", "3d"]),
    ("kings_full_of_queens_beats_kings_full_of_jacks",
     ["Kh", "Kd"], ["Kc", "Qh", "Qd", "2c", "3d"],
     ["Kh", "Kd"], ["Kc", "Jh", "Jd", "2c", "3d"]),
]

@pytest.mark.parametrize("name,wh,wb,lh,lb", FULL_HOUSE_TIEBREAKER_CASES,
                         ids=[c[0] for c in FULL_HOUSE_TIEBREAKER_CASES])
def test_full_house_tiebreaker(name, wh, wb, lh, lb):
    winner = evaluate_hand(wh, wb)
    loser = evaluate_hand(lh, lb)
    assert winner.hand_name == "Full House"
    assert loser.hand_name == "Full House"
    assert compute_winner(winner, loser) is winner


# ═══════════════════════════════════════════════════════════════════
# FLUSH TIEBREAKERS
# ═══════════════════════════════════════════════════════════════════

FLUSH_TIEBREAKER_CASES = [
    # Higher top card wins
    ("ace_high_flush_beats_king_high",
     ["Ah", "9h"], ["7h", "4h", "2h", "Kc", "3d"],
     ["Kd", "9d"], ["7d", "4d", "2d", "Ac", "3h"]),
    # Same top card, second card decides
    ("AK_flush_beats_AQ_flush",
     ["Ah", "Kh"], ["7h", "4h", "2h", "Qc", "3d"],
     ["Ad", "Qd"], ["7d", "4d", "2d", "Kc", "3h"]),
    # Same top two, third card decides
    ("AKQ_flush_beats_AKJ_flush",
     ["Ah", "Kh"], ["Qh", "4h", "2h", "Jc", "3d"],
     ["Ad", "Kd"], ["Jd", "4d", "2d", "Qc", "3h"]),
    # Same top three, fourth card decides
    ("AKQ10_flush_beats_AKQ9_flush",
     ["Ah", "Kh"], ["Qh", "10h", "2h", "9c", "3d"],
     ["Ad", "Kd"], ["Qd", "9d", "2d", "10c", "3h"]),
    # Same top four, fifth card decides
    ("AKQJ9_flush_beats_AKQJ8_flush",
     ["Ah", "Kh"], ["Qh", "Jh", "9h", "8c", "3d"],
     ["Ad", "Kd"], ["Qd", "Jd", "8d", "9c", "3h"]),
]

@pytest.mark.parametrize("name,wh,wb,lh,lb", FLUSH_TIEBREAKER_CASES,
                         ids=[c[0] for c in FLUSH_TIEBREAKER_CASES])
def test_flush_tiebreaker(name, wh, wb, lh, lb):
    winner = evaluate_hand(wh, wb)
    loser = evaluate_hand(lh, lb)
    assert winner.hand_name == "Flush"
    assert loser.hand_name == "Flush"
    assert compute_winner(winner, loser) is winner


def test_flush_exact_tie():
    """Same flush ranks, different suits — tie."""
    a = evaluate_hand(["Ah", "Kh"], ["Qh", "Jh", "9h", "2c", "3d"])
    b = evaluate_hand(["Ad", "Kd"], ["Qd", "Jd", "9d", "2c", "3h"])
    assert compute_winner(a, b) is None


# ═══════════════════════════════════════════════════════════════════
# STRAIGHT TIEBREAKERS
# ═══════════════════════════════════════════════════════════════════

STRAIGHT_TIEBREAKER_CASES = [
    ("ace_high_beats_king_high",
     ["Ah", "Kd"], ["Qc", "Js", "10h", "2c", "3d"],
     ["Kh", "Qd"], ["Jc", "10s", "9h", "2c", "3d"]),
    ("king_high_beats_queen_high",
     ["Kh", "Qd"], ["Jc", "10s", "9h", "2c", "3d"],
     ["Qh", "Jd"], ["10c", "9s", "8h", "2c", "3d"]),
    ("6_high_beats_5_high_wheel",
     ["6h", "5d"], ["4c", "3s", "2h", "Ac", "Kd"],
     ["Ah", "2d"], ["3c", "4s", "5h", "Kc", "9d"]),
]

@pytest.mark.parametrize("name,wh,wb,lh,lb", STRAIGHT_TIEBREAKER_CASES,
                         ids=[c[0] for c in STRAIGHT_TIEBREAKER_CASES])
def test_straight_tiebreaker(name, wh, wb, lh, lb):
    winner = evaluate_hand(wh, wb)
    loser = evaluate_hand(lh, lb)
    assert winner.hand_name == "Straight"
    assert loser.hand_name == "Straight"
    assert compute_winner(winner, loser) is winner


def test_straight_exact_tie():
    """Same straight, different suits — tie."""
    a = evaluate_hand(["Ah", "Kd"], ["Qc", "Js", "10h", "2c", "3d"])
    b = evaluate_hand(["As", "Kc"], ["Qd", "Jh", "10s", "2c", "3d"])
    assert compute_winner(a, b) is None


# ═══════════════════════════════════════════════════════════════════
# THREE OF A KIND TIEBREAKERS
# ═══════════════════════════════════════════════════════════════════

TRIPS_TIEBREAKER_CASES = [
    # Higher trips wins
    ("trip_aces_beat_trip_kings",
     ["Ah", "Ad"], ["Ac", "Ks", "9h", "2c", "3d"],
     ["Kh", "Kd"], ["Kc", "As", "9h", "2c", "3d"]),
    # Same trips, higher first kicker wins
    ("trip_aces_K_kicker_beats_Q_kicker",
     ["Ah", "Ad"], ["Ac", "Kh", "9s", "2c", "3d"],
     ["Ah", "Ad"], ["Ac", "Qh", "9s", "2c", "3d"]),
    # Same trips, same first kicker, second kicker wins
    ("trip_aces_KQ_kickers_beat_KJ_kickers",
     ["Ah", "Ad"], ["Ac", "Kh", "Qs", "2c", "3d"],
     ["Ah", "Ad"], ["Ac", "Kh", "Js", "2c", "3d"]),
]

@pytest.mark.parametrize("name,wh,wb,lh,lb", TRIPS_TIEBREAKER_CASES,
                         ids=[c[0] for c in TRIPS_TIEBREAKER_CASES])
def test_trips_tiebreaker(name, wh, wb, lh, lb):
    winner = evaluate_hand(wh, wb)
    loser = evaluate_hand(lh, lb)
    assert winner.hand_name == "Three of a Kind"
    assert loser.hand_name == "Three of a Kind"
    assert compute_winner(winner, loser) is winner


# ═══════════════════════════════════════════════════════════════════
# TWO PAIR TIEBREAKERS
# ═══════════════════════════════════════════════════════════════════

TWO_PAIR_TIEBREAKER_CASES = [
    # Higher top pair wins
    ("AA_KK_beats_KK_QQ",
     ["Ah", "Kh"], ["Ad", "Kd", "9c", "2s", "3s"],
     ["Kh", "Qh"], ["Kd", "Qd", "9c", "2s", "3s"]),
    # Same top pair, higher bottom pair wins
    ("AA_KK_beats_AA_QQ",
     ["Ah", "Kh"], ["Ad", "Kd", "9c", "2s", "3s"],
     ["Ah", "Qh"], ["Ad", "Qd", "9c", "2s", "3s"]),
    # Same two pair, higher kicker wins
    ("AA_KK_Q_kicker_beats_AA_KK_J_kicker",
     ["Ah", "Kh"], ["Ad", "Kd", "Qc", "2s", "3s"],
     ["Ah", "Kh"], ["Ad", "Kd", "Jc", "2s", "3s"]),
    # Low two pair comparisons
    ("55_44_beats_44_33",
     ["5h", "4h"], ["5d", "4d", "Ac", "9s", "Ks"],
     ["4h", "3h"], ["4d", "3d", "Ac", "9s", "Ks"]),
]

@pytest.mark.parametrize("name,wh,wb,lh,lb", TWO_PAIR_TIEBREAKER_CASES,
                         ids=[c[0] for c in TWO_PAIR_TIEBREAKER_CASES])
def test_two_pair_tiebreaker(name, wh, wb, lh, lb):
    winner = evaluate_hand(wh, wb)
    loser = evaluate_hand(lh, lb)
    assert winner.hand_name == "Two Pair"
    assert loser.hand_name == "Two Pair"
    assert compute_winner(winner, loser) is winner


# ═══════════════════════════════════════════════════════════════════
# PAIR TIEBREAKERS
# ═══════════════════════════════════════════════════════════════════

PAIR_TIEBREAKER_CASES = [
    # Higher pair wins
    ("aces_beat_kings",
     ["Ah", "Ad"], ["Kc", "9s", "7h", "2c", "3d"],
     ["Kh", "Kd"], ["Ac", "9s", "7h", "2c", "3d"]),
    ("kings_beat_queens",
     ["Kh", "Kd"], ["Ac", "9s", "7h", "2c", "3d"],
     ["Qh", "Qd"], ["Ac", "9s", "7h", "2c", "3d"]),
    # Same pair, first kicker
    ("AA_K_kicker_beats_AA_Q_kicker",
     ["Ah", "Ad"], ["Kc", "9s", "7h", "2c", "3d"],
     ["Ah", "Ad"], ["Qc", "9s", "7h", "2c", "3d"]),
    # Same pair, second kicker
    ("AA_KQ_beats_AA_KJ",
     ["Ah", "Ad"], ["Kc", "Qs", "7h", "2c", "3d"],
     ["Ah", "Ad"], ["Kc", "Js", "7h", "2c", "3d"]),
    # Same pair, third kicker
    ("AA_KQJ_beats_AA_KQ10",
     ["Ah", "Ad"], ["Kc", "Qs", "Jh", "2c", "3d"],
     ["Ah", "Ad"], ["Kc", "Qs", "10h", "2c", "3d"]),
]

@pytest.mark.parametrize("name,wh,wb,lh,lb", PAIR_TIEBREAKER_CASES,
                         ids=[c[0] for c in PAIR_TIEBREAKER_CASES])
def test_pair_tiebreaker(name, wh, wb, lh, lb):
    winner = evaluate_hand(wh, wb)
    loser = evaluate_hand(lh, lb)
    assert winner.hand_name == "Pair"
    assert loser.hand_name == "Pair"
    assert compute_winner(winner, loser) is winner


# ═══════════════════════════════════════════════════════════════════
# HIGH CARD TIEBREAKERS
# ═══════════════════════════════════════════════════════════════════

HIGH_CARD_TIEBREAKER_CASES = [
    # First card decides
    ("ace_high_beats_king_high",
     ["Ah", "Jd"], ["9c", "7s", "5h", "2c", "3d"],
     ["Kh", "Jd"], ["9c", "7s", "5h", "2c", "3d"]),
    # Second card decides
    ("AK_beats_AQ",
     ["Ah", "Kd"], ["9c", "7s", "5h", "2c", "3d"],
     ["Ah", "Qd"], ["9c", "7s", "5h", "2c", "3d"]),
    # Third card decides
    ("AKQ_beats_AKJ",
     ["Ah", "Kd"], ["Qc", "7s", "5h", "2c", "3d"],
     ["Ah", "Kd"], ["Jc", "7s", "5h", "2c", "3d"]),
    # Fourth card decides
    ("AKQ10_beats_AKQ9",
     ["Ah", "Kd"], ["Qc", "10s", "5h", "2c", "3d"],
     ["Ah", "Kd"], ["Qc", "9s", "5h", "2c", "3d"]),
    # Fifth card decides
    ("AKQJ9_beats_AKQJ8",
     ["Ah", "Kd"], ["Qc", "Js", "9h", "2c", "3d"],
     ["Ah", "Kd"], ["Qc", "Js", "8h", "2c", "3d"]),
]

@pytest.mark.parametrize("name,wh,wb,lh,lb", HIGH_CARD_TIEBREAKER_CASES,
                         ids=[c[0] for c in HIGH_CARD_TIEBREAKER_CASES])
def test_high_card_tiebreaker(name, wh, wb, lh, lb):
    winner = evaluate_hand(wh, wb)
    loser = evaluate_hand(lh, lb)
    assert winner.hand_name == "High Card"
    assert loser.hand_name == "High Card"
    assert compute_winner(winner, loser) is winner


def test_high_card_exact_tie():
    """Same ranks, different suits — tie."""
    a = evaluate_hand(["Ah", "Kd"], ["9c", "7s", "5h", "2c", "3d"])
    b = evaluate_hand(["As", "Kc"], ["9d", "7h", "5s", "2c", "3d"])
    assert compute_winner(a, b) is None
