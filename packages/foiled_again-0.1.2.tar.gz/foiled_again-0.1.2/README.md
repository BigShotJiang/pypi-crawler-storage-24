# Foiled Again

[![PyPI - Python](https://img.shields.io/pypi/pyversions/Foiled-Again.svg?logo=Python&label=Python&style=flat-square)](https://pypi.org/p/Foiled-Again)
[![PyPI - Status](https://img.shields.io/pypi/status/Foiled-Again.svg?logo=Python&label=Status&style=flat-square)](https://pypi.org/p/Foiled-Again)
[![PyPI - Version](https://img.shields.io/pypi/v/Foiled-Again.svg?logo=Python&label=Version&style=flat-square)](https://pypi.org/p/Foiled-Again)
[![PyPI - License](https://img.shields.io/pypi/l/Foiled-Again.svg?logo=Python&label=License&style=flat-square)](https://opensource.org/licenses/MIT)

[![prek](https://img.shields.io/badge/prek-enabled-informational?logo=prek&style=flat-square)](https://github.com/j178/prek)
[![Ruff](https://img.shields.io/badge/ruff-enabled-informational?logo=ruff&style=flat-square)](https://github.com/astral-sh/ruff)
[![Ty](https://img.shields.io/badge/ty-enabled-informational?logo=ruff&style=flat-square)](https://github.com/astral-sh/ty)

[![status-badge](https://ci.codeberg.org/api/badges/15232/status.svg)](https://ci.codeberg.org/repos/15232)

A simple cli tool to collect and track pricing of TCG cards.

## Installation

### Pipx

1. Ensure you have [Pipx](https://pipx.pypa.io/stable/) installed: `pipx --version`
2. Install the project: `pipx install Foiled-Again`

## Usage

<details><summary>foiled-again Commands</summary>

  <!-- RICH-CODEX hide_command: true -->
  ![`foiled-again --help`](docs/img/foiled-again.svg)

</details>
<details><summary>foiled-again add</summary>

  <!-- RICH-CODEX hide_command: true -->
  ![`foiled-again add --help`](docs/img/foiled-again_add.svg)

</details>
<details><summary>foiled-again view</summary>

  <!-- RICH-CODEX hide_command: true -->
  ![`foiled-again view --help`](docs/img/foiled-again_view.svg)

</details>
<details><summary>foiled-again refresh</summary>

  <!-- RICH-CODEX hide_command: true -->
  ![`foiled-again refresh --help`](docs/img/foiled-again_refresh.svg)

</details>
<details><summary>foiled-again summary</summary>

  <!-- RICH-CODEX hide_command: true -->
  ![`foiled-again summary --help`](docs/img/foiled-again_summary.svg)

</details>
<details><summary>foiled-again settings</summary>

  <!-- RICH-CODEX hide_command: true -->
  ![`foiled-again settings --help`](docs/img/foiled-again_settings.svg)

</details>

## Socials

[![Social - Fosstodon](https://img.shields.io/badge/%40BuriedInCode-teal?label=Fosstodon&logo=mastodon&style=for-the-badge)](https://fosstodon.org/@BuriedInCode)
[![Social - Matrix](https://img.shields.io/matrix/The-Dev-Environment:matrix.org?label=The-Dev-Environment&logo=matrix&style=for-the-badge)](https://matrix.to/#/#The-Dev-Environment:matrix.org)
