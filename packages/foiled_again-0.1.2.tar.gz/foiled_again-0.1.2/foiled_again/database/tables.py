__all__ = ["Card", "Expansion", "Game", "Rarity", "Style"]

import logging
from datetime import date
from decimal import Decimal
from enum import Enum

from sqlmodel import Field, Relationship, Session, select

from foiled_again.tcg_player.schemas import Group, Product, ProductPrices
from foiled_again.utils import BaseSQLModel

try:
    from typing import Self  # Python >= 3.11  # ty: ignore[unresolved-import]
except ImportError:
    from typing_extensions import Self  # Python < 3.11

LOGGER = logging.getLogger(__name__)


class Game(Enum):
    POKEMON = ("Pokemon", 3)
    DIGIMON = ("Digimon", 63)
    DRAGON_BALL_SUPER = ("Dragon Ball Super", 27)
    MAGIC = ("Magic", 1)
    FLESH_AND_BLOOD = ("Flesh and Blood", 62)

    @property
    def clean_name(self) -> str:
        return self.value[0]

    @property
    def category_id(self) -> int:
        return self.value[1]

    def __str__(self) -> str:
        return self.value[0]


class Expansion(BaseSQLModel, table=True):
    __tablename__ = "expansions"

    expansion_id: int = Field(primary_key=True)
    game: Game
    code: str
    name: str
    release_date: date | None = None

    cards: list["Card"] = Relationship(back_populates="expansion", cascade_delete=True)

    @property
    def display_name(self) -> str:
        return f"[{self.code}] {self.name}"

    @property
    def quantity(self) -> int:
        return sum(x.quantity for x in self.cards)

    @property
    def price(self) -> Decimal:
        return sum(x.quantity * x.market_price for x in self.cards)

    @classmethod
    def find_by_code(cls, session: Session, game: Game, code: str) -> Self | None:
        query = select(cls).where(cls.game == game, cls.code == code)
        return session.exec(query).first()

    @classmethod
    def find_by_name(cls, session: Session, game: Game, name: str) -> Self | None:
        query = select(cls).where(cls.game == game, cls.name == name)
        return session.exec(query).first()

    @classmethod
    def create(cls, session: Session, game: Game, group: Group) -> Self:
        if existing := session.get(cls, group.group_id):
            return existing
        if existing := cls.find_by_code(session=session, game=game, code=group.abbreviation):
            return existing
        if existing := cls.find_by_name(session=session, game=game, name=group.name):
            return existing
        expansion = cls(
            expansion_id=group.group_id,
            game=game,
            code=group.abbreviation,
            name=group.name,
            release_date=group.release_date.date(),
        )
        LOGGER.info("Created %s", expansion.display_name)
        session.add(expansion)
        session.commit()
        session.refresh(expansion)
        return expansion

    def update(self, session: Session, game: Game, group: Group) -> Self:  # noqa: ARG002
        self.code = group.abbreviation
        self.release_date = group.release_date.date()
        session.add(self)
        session.commit()
        session.refresh(self)
        return self


class Rarity(str, Enum):
    def __str__(self) -> str:
        return self.value


class PokemonRarity(Rarity):
    COMMON = "Common"
    UNCOMMON = "Uncommon"
    DOUBLE_RARE = "Double Rare"
    HOLO_RARE = "Holo Rare"
    PROMO = "Promo"
    RADIANT_RARE = "Radiant Rare"
    RARE = "Rare"
    SECRET_RARE = "Secret Rare"  # noqa: S105
    ULTRA_RARE = "Ultra Rare"


class DigimonRarity(Rarity):
    COMMON = "Common"
    UNCOMMON = "Uncommon"
    RARE = "Rare"
    SUPER_RARE = "Super Rare"
    SECRET_RARE = "Secret Rare"  # noqa: S105
    PROMO = "Promo"


class DragonBallSuperRarity(Rarity):
    STARTER_RARE = "Starter Rare"
    UNCOMMON = "Uncommon"
    SUPER_RARE = "Super Rare"
    DUO_POWER_RARE = "Duo Power Rare"


class MagicRarity(Rarity):
    COMMON = "C"
    UNCOMMON = "U"
    RARE = "R"
    MYTHIC = "M"
    BONUS = "B"
    SPECIAL = "S"


class FleshAndBloodRarity(Rarity):
    RARE = "Rare"
    SUPER_RARE = "Super Rare"
    MAJESTIC = "Majestic"
    LEGENDARY = "Legendary"


def get_rarity(game: Game, rarity: str) -> Rarity:
    mapping = {
        Game.POKEMON: PokemonRarity,
        Game.DIGIMON: DigimonRarity,
        Game.DRAGON_BALL_SUPER: DragonBallSuperRarity,
        Game.MAGIC: MagicRarity,
        Game.FLESH_AND_BLOOD: FleshAndBloodRarity,
    }
    for entry in mapping[game]:
        if entry.value == rarity:
            return entry
    raise ValueError(f"Unknown rarity '{rarity}' for game '{game}'")


class Style(str, Enum):
    NORMAL = "Normal"
    HOLOFOIL = "Holofoil"
    REVERSE_HOLOFOIL = "Reverse Holofoil"
    FIRST_ED_NORMAL = "1st Edition Normal"
    FIRST_ED_HOLOFOIL = "1st Edition Holofoil"
    FOIL = "Foil"
    UNLIMITED_NORMAL = "Unlimited Edition Normal"
    UNLIMITED_RAINBOW_FOIL = "Unlimited Edition Rainbow Foil"
    RAINBOW_FOIL = "Rainbow Foil"

    def __str__(self) -> str:
        return self.value


class Card(BaseSQLModel, table=True):
    __tablename__ = "cards"

    card_id: int = Field(primary_key=True)
    style: Style = Field(primary_key=True)
    expansion_id: int = Field(foreign_key="expansions.expansion_id", ondelete="CASCADE")
    expansion: Expansion = Relationship(back_populates="cards")
    number: str
    name: str
    rarity: str
    quantity: int = 0
    low_price: Decimal
    mid_price: Decimal
    high_price: Decimal
    market_price: Decimal

    @property
    def game_rarity(self) -> Rarity:
        return get_rarity(game=self.expansion.game, rarity=self.rarity)

    @game_rarity.setter
    def game_rarity(self, value: Rarity) -> None:
        self.rarity = str(value)

    @property
    def display_name(self) -> str:
        return f"[{self.number}] {self.name} ({self.style})"

    @classmethod
    def create(
        cls, session: Session, expansion: Expansion, product: Product, product_prices: ProductPrices
    ) -> Self:
        if existing := session.get(cls, (product.product_id, product_prices.sub_type_name)):
            return existing
        card = cls(
            card_id=product.product_id,
            style=product_prices.sub_type_name,
            expansion=expansion,
            number=str(int(product.number)) if product.number.isdigit() else product.number,
            name=product.name,
            rarity=str(get_rarity(game=expansion.game, rarity=product.rarity)),
            low_price=product_prices.low_price or Decimal(0),
            mid_price=product_prices.mid_price or Decimal(0),
            high_price=product_prices.high_price or Decimal(0),
            market_price=product_prices.market_price or Decimal(0),
        )
        LOGGER.info("Created %s", card.display_name)
        session.add(card)
        session.commit()
        session.refresh(card)
        return card

    def update(self, session: Session, expansion: Expansion, product: Product) -> Self:
        self.number = str(int(product.number)) if product.number.isdigit() else product.number
        self.name = product.name
        self.game_rarity = get_rarity(game=expansion.game, rarity=product.rarity)
        session.add(self)
        session.commit()
        session.refresh(self)
        return self

    def update_prices(self, session: Session, product_prices: ProductPrices) -> Self:
        self.low_price = product_prices.low_price or Decimal(0)
        self.mid_price = product_prices.mid_price or Decimal(0)
        self.high_price = product_prices.high_price or Decimal(0)
        self.market_price = product_prices.market_price or Decimal(0)
        session.add(self)
        session.commit()
        session.refresh(self)
        return self
