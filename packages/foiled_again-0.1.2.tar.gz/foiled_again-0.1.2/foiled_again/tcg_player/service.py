__all__ = ["TCGPlayer"]

import logging
from json import JSONDecodeError
from platform import release, system
from urllib.parse import urlencode

from httpx import Client, HTTPStatusError, RequestError, TimeoutException, post
from pydantic import TypeAdapter, ValidationError
from ratelimit import limits, sleep_and_retry

from foiled_again import __version__
from foiled_again.errors import AuthenticationError, ServiceError
from foiled_again.sqlite_cache import SQLiteCache
from foiled_again.tcg_player.schemas import Category, Group, Product, ProductPrices

LOGGER = logging.getLogger(__name__)
MINUTE = 60


class TCGPlayer:
    BASE_URL = "https://api.tcgplayer.com"

    def __init__(
        self,
        client_id: str | None = None,
        client_secret: str | None = None,
        access_token: str | None = None,
        cache: SQLiteCache | None = None,
    ) -> None:
        if not access_token:
            access_token = self.authenticate(client_id=client_id, client_secret=client_secret)
        self.access_token = access_token
        self.client = Client(
            base_url=self.BASE_URL + "/v1.39.0",
            headers={
                "Accept": "application/json",
                "Authorization": f"Bearer {self.access_token}",
                "User-Agent": f"Foiled-Again/{__version__}/{system()}: {release()}",
            },
        )
        self.cache = cache

    @sleep_and_retry
    @limits(calls=60, period=MINUTE)
    def _perform_get_request(
        self, endpoint: str, params: dict[str, int | str] | None = None
    ) -> dict:
        if params is None:
            params = {}

        try:
            response = self.client.get(endpoint, params=params)
            response.raise_for_status()
            return response.json()
        except RequestError as err:
            raise ServiceError(f"Unable to connect to '{err.request.url.path}'") from err
        except HTTPStatusError as err:
            try:
                error_msg = err.response.json()["errors"][0]
                if err.response.status_code in (401, 403):
                    raise AuthenticationError(f"{err.response.status_code}: {error_msg}")
                raise ServiceError(f"{err.response.status_code}: {error_msg}")
            except JSONDecodeError as err:
                raise ServiceError("Unable to parse response as Json") from err
        except JSONDecodeError as err:
            raise ServiceError("Unable to parse response as Json") from err
        except TimeoutException as err:
            raise ServiceError("Service took too long to respond") from err

    def _get_request(
        self, endpoint: str, params: dict[str, int | str] | None = None, skip_cache: bool = False
    ) -> dict:
        params = params or {}

        cache_params = f"?{urlencode({k: params[k] for k in sorted(params)})}" if params else ""
        cache_key = endpoint + cache_params

        if self.cache and not skip_cache:
            cached_response = self.cache.select(key=cache_key)
            if cached_response:
                return cached_response

        response = self._perform_get_request(endpoint=endpoint, params=params)
        if not response:
            raise ServiceError(response)

        if self.cache and not skip_cache:
            self.cache.insert(key=cache_key, value=response)

        return response

    def _get_paged_request(
        self, endpoint: str, params: dict[str, int | str] | None = None
    ) -> list[dict]:
        params = params or {}
        offset = int(params.get("offset", "0"))
        limit = int(params.get("limit", "100"))
        params["offset"] = offset
        params["limit"] = limit

        response = self._get_request(endpoint=endpoint, params=params)
        results = response["results"]
        while response["results"] and len(results) < response["totalItems"]:
            params["offset"] += limit
            response = self._get_request(endpoint=endpoint, params=params)
            results.extend(response["results"])
        return results

    def authenticate(self, client_id: str, client_secret: str) -> str:
        LOGGER.info("Authenticating TCGPlayer")
        try:
            response = post(
                self.BASE_URL + "/token",
                data=f"grant_type=client_credentials&client_id={client_id}&client_secret={client_secret}",
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/x-www-form-urlencoded",
                    "User-Agent": f"Foiled-Again/{__version__}/{system()}: {release()}",
                },
            )
            response.raise_for_status()
            return response.json()["access_token"]
        except RequestError as err:
            raise ServiceError(f"Unable to connect to '{err.request.url.path}'") from err
        except HTTPStatusError as err:
            try:
                error_msg = f"{err.response.json()['title']}: {err.response.json()['detail']}"
                if err.response.status_code in (401, 403):
                    raise AuthenticationError(f"{err.response.status_code}: {error_msg}")
                raise ServiceError(f"{err.response.status_code}: {error_msg}")
            except JSONDecodeError as err:
                raise ServiceError("Unable to parse response as Json") from err
        except JSONDecodeError as err:
            raise ServiceError("Unable to parse response as Json") from err
        except TimeoutException as err:
            raise ServiceError("Service took too long to respond") from err

    def list_categories(self) -> list[Category]:
        try:
            results = self._get_paged_request(endpoint="/catalog/categories")
            return TypeAdapter(list[Category]).validate_python(results)
        except ValidationError as err:
            raise ServiceError(err) from err

    def get_category(self, category_id: int) -> Category:
        try:
            result = self._get_request(endpoint=f"/catalog/categories/{category_id}").get(
                "results", []
            )[0]
            return TypeAdapter(Category).validate_python(result)
        except ValidationError as err:
            raise ServiceError(err) from err

    def list_groups(self, category_id: int) -> list[Group]:
        try:
            results = self._get_paged_request(endpoint=f"/catalog/categories/{category_id}/groups")
            return TypeAdapter(list[Group]).validate_python(results)
        except ValidationError as err:
            raise ServiceError(err) from err

    def get_group(self, group_id: int) -> Group:
        try:
            result = self._get_request(endpoint=f"/catalog/groups/{group_id}").get("results", [])[0]
            return TypeAdapter(Group).validate_python(result)
        except ValidationError as err:
            raise ServiceError(err) from err

    def list_products(
        self, category_id: int, group_id: int, filter_product_types: bool = True
    ) -> list[Product]:
        params: dict[str, int | bool | str] = {
            "categoryId": category_id,
            "groupId": group_id,
            "getExtendedFields": True,
        }
        if filter_product_types:
            params["productTypes"] = "Cards"
        try:
            results = self._get_paged_request(endpoint="/catalog/products", params=params)
            return TypeAdapter(list[Product]).validate_python(results)
        except ValidationError as err:
            raise ServiceError(err) from err
        except ServiceError as err:
            if str(err) == "404: No products were found.":
                return self.list_products(
                    category_id=category_id, group_id=group_id, filter_product_types=False
                )
            raise

    def get_product(self, product_id: int) -> Product:
        try:
            result = self._get_request(
                endpoint=f"/catalog/products/{product_id}", params={"getExtendedFields": True}
            ).get("results", [])[0]
            return TypeAdapter(Product).validate_python(result)
        except ValidationError as err:
            raise ServiceError(err) from err

    def get_product_prices(self, group_id: int, product_id: int) -> list[ProductPrices]:
        try:
            results = self._get_request(endpoint=f"/pricing/group/{group_id}", skip_cache=True).get(
                "results", []
            )
            results = [x for x in results if x["productId"] == product_id]
            return TypeAdapter(list[ProductPrices]).validate_python(results)
        except ValidationError as err:
            raise ServiceError(err) from err
