__all__ = ["Category", "Group", "Product", "ProductPrices"]

from datetime import datetime
from decimal import Decimal

from pydantic import Field, HttpUrl, field_validator, model_validator
from pydantic.alias_generators import to_camel

from foiled_again.utils import BaseModel


class TCGPlayerModel(BaseModel, alias_generator=to_camel, extra="ignore"): ...


class Category(TCGPlayerModel):
    category_id: int
    name: str
    modified_on: datetime
    display_name: str
    seo_category_name: str
    category_description: str | None
    category_page_title: str | None
    sealed_label: str | None
    non_sealed_label: str | None
    condition_guide_url: HttpUrl
    is_scannable: bool
    popularity: int
    is_direct: bool


class Group(TCGPlayerModel):
    group_id: int
    name: str
    abbreviation: str
    is_supplemental: bool
    release_date: datetime = Field(alias="publishedOn")
    modified_on: datetime

    @property
    def display_name(self) -> str:
        return f"{self.name} [{self.abbreviation}]"


class Product(TCGPlayerModel):
    product_id: int
    name: str
    clean_name: str
    image_url: HttpUrl
    url: HttpUrl
    modified_on: datetime
    image_count: int
    number: str
    rarity: str

    @model_validator(mode="before")
    def extended_data(cls, value: object) -> object:
        if isinstance(value, dict) and "extendedData" in value:
            value["number"] = next(
                iter(x["value"] for x in value["extendedData"] if x["name"] == "Number"), "---"
            )
            value["rarity"] = next(
                iter(x["value"] for x in value["extendedData"] if x["name"] == "Rarity"), None
            )
            del value["extendedData"]
        return value

    @field_validator("number", mode="after")
    def split_number(cls, value: str) -> str:
        return value.split("/", maxsplit=1)[0]

    @property
    def display_name(self) -> str:
        return f"[{self.number}] {self.clean_name} - {self.rarity}"


class ProductPrices(TCGPlayerModel):
    product_id: int
    low_price: Decimal | None
    mid_price: Decimal | None
    high_price: Decimal | None
    market_price: Decimal | None
    direct_low_price: Decimal | None
    sub_type_name: str
