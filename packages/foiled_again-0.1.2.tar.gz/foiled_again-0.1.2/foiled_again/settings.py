__all__ = ["PricingColours", "Settings"]

from decimal import Decimal
from pathlib import Path
from typing import Annotated, Any, ClassVar

import tomli_w as tomlwriter
from pydantic import BeforeValidator, HttpUrl
from rich.panel import Panel

from foiled_again import get_config_root, get_data_root
from foiled_again.console import CONSOLE
from foiled_again.utils import BaseModel, blank_is_none, flatten_dict

try:
    from typing import Self  # Python >= 3.11  # ty: ignore[unresolved-import]
except ImportError:
    from typing_extensions import Self  # Python < 3.11

try:
    import tomllib as tomlreader  # Python >= 3.11  # ty: ignore[unresolved-import]
except ModuleNotFoundError:
    import tomli as tomlreader  # Python < 3.11


class SettingsModel(BaseModel, extra="ignore"): ...


class Database(SettingsModel):
    url: Path = get_data_root() / "foiled-again.sqlite"

    @property
    def db_url(self) -> str:
        return f"sqlite:///{self.url}"


class PokemonTCG(SettingsModel):
    base_url: HttpUrl = HttpUrl("https://api.pokemontcg.io/v2")
    api_key: Annotated[str | None, BeforeValidator(blank_is_none)] = None


class PricingColours(SettingsModel):
    low_style: str = "logging.level.debug"
    mid_pricing: Decimal = Decimal(1)
    mid_style: str = "logging.level.info"
    high_pricing: Decimal = Decimal(10)
    high_style: str = "logging.level.warning"


class TCGPlayer(SettingsModel):
    access_token: Annotated[str | None, BeforeValidator(blank_is_none)] = None
    client_id: Annotated[str | None, BeforeValidator(blank_is_none)] = None
    client_secret: Annotated[str | None, BeforeValidator(blank_is_none)] = None


def _stringify_values(content: dict[str, Any]) -> dict[str, Any]:
    output = {}
    for key, value in content.items():
        if isinstance(value, bool):
            value = str(value)
        if not value:
            continue
        if isinstance(value, dict):
            value = _stringify_values(content=value)
        elif isinstance(value, list):
            value = [_stringify_values(content=x) if isinstance(x, dict) else str(x) for x in value]
        else:
            value = str(value)
        output[key] = value
    return output


class Settings(SettingsModel):
    _file: ClassVar[Path] = get_config_root() / "settings.toml"

    database: Database = Database()
    pokemon_tcg: PokemonTCG = PokemonTCG()
    pricing_colours: PricingColours = PricingColours()
    tcg_player: TCGPlayer = TCGPlayer()

    @classmethod
    def load(cls) -> Self:
        if not cls._file.exists():
            cls().save()
        with cls._file.open("rb") as stream:
            content = tomlreader.load(stream)
        return cls(**content)

    def save(self) -> Self:
        with self._file.open("wb") as stream:
            content = self.model_dump(by_alias=False)
            content = _stringify_values(content=content)
            tomlwriter.dump(content, stream)
        return self

    @classmethod
    def display(cls) -> None:
        default = flatten_dict(content=cls().model_dump())
        file_overrides = flatten_dict(content=cls.load().model_dump())
        default_vals = [
            f"[repr.attrib_name]{k}[/]: [repr.attrib_value]{v}[/]"
            if k in file_overrides and file_overrides[k] == v
            else f"[dim][repr.attrib_name]{k}[/]: [repr.attrib_value]{v}[/][/]"
            for k, v in default.items()
        ]
        override_vals = [
            f"[repr.attrib_name]{k}[/]: [repr.attrib_value]{v}[/]"
            for k, v in file_overrides.items()
            if k not in default or default[k] != v
        ]

        CONSOLE.print(Panel.fit("\n".join(default_vals), title="Default"))
        CONSOLE.print(Panel.fit("\n".join(override_vals), title=str(cls._file)))
