__all__ = ["BaseModel", "blank_is_none", "flatten_dict"]

import logging
from typing import Any

from pydantic import BaseModel as PydanticModel
from rich.panel import Panel
from sqlmodel import SQLModel

from foiled_again.console import CONSOLE

LOGGER = logging.getLogger(__name__)


class BaseModel(
    PydanticModel,
    populate_by_name=True,
    str_strip_whitespace=True,
    validate_assignment=True,
    revalidate_instances="always",
    extra="forbid",
):
    def display(self) -> None:
        content = flatten_dict(content=self.model_dump())
        content_vals = [
            f"[repr.attrib_name]{k}[/]: [repr.attrib_value]{v}[/]" for k, v in content.items()
        ]
        CONSOLE.print(Panel.fit("\n".join(content_vals), title=type(self).__name__))


class BaseSQLModel(SQLModel, BaseModel): ...


def blank_is_none(value: str) -> str | None:
    return value or None


def flatten_dict(content: dict[str, Any], parent_key: str = "") -> dict[str, Any]:
    items = {}
    for key, value in content.items():
        new_key = f"{parent_key}.{key}" if parent_key else key
        if isinstance(value, dict):
            items.update(flatten_dict(content=value, parent_key=new_key))
        elif isinstance(value, list) and value and isinstance(value[0], dict):
            for index, entry in enumerate(value):
                items.update(flatten_dict(content=entry, parent_key=f"{new_key}[{index}]"))  # ty: ignore[invalid-argument-type]
        else:
            items[new_key] = value
    return dict(sorted(items.items()))
