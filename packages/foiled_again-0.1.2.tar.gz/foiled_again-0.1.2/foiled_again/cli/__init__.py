__all__ = ["app"]

from foiled_again.cli._typer import app
from foiled_again.cli.add import add_card  # noqa: F401
from foiled_again.cli.refresh import refresh_cards  # noqa: F401
from foiled_again.cli.settings import settings  # noqa: F401
from foiled_again.cli.summary import summary  # noqa: F401
from foiled_again.cli.view import view_cards  # noqa: F401
