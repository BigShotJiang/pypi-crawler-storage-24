__all__ = []

import logging
from enum import Enum
from typing import Annotated

from rich.progress import BarColumn, MofNCompleteColumn, Progress, SpinnerColumn, TextColumn
from sqlmodel import Session, select
from typer import Argument, Option

from foiled_again.cli._typer import app
from foiled_again.cli.common import GameChoice, _get_game_by_choice, setup
from foiled_again.database import Card, Expansion, Game
from foiled_again.errors import ServiceError
from foiled_again.tcg_player import TCGPlayer

LOGGER = logging.getLogger(__name__)


class TypeChoice(str, Enum):
    EXPANSION = "expansion"
    CARD = "card"
    PRICE = "price"


def _update_expansion(
    tcg_player: TCGPlayer,
    session: Session,
    expansion: Expansion,
    game: Game,
    skip_types: list[TypeChoice],
) -> Expansion:
    if TypeChoice.EXPANSION not in skip_types:
        try:
            group = tcg_player.get_group(group_id=expansion.expansion_id)
            expansion = expansion.update(session=session, game=game, group=group)
        except ServiceError as err:
            LOGGER.error("Unable to update expansion %s: %s", expansion.display_name, err)

    return expansion


def _update_card(
    tcg_player: TCGPlayer,
    session: Session,
    card: Card,
    expansion: Expansion,
    skip_types: list[TypeChoice],
) -> None:
    if TypeChoice.CARD not in skip_types:
        try:
            product = tcg_player.get_product(product_id=card.card_id)
            card = card.update(session=session, expansion=expansion, product=product)
        except ServiceError as err:
            LOGGER.error("Unable to update card %s: %s", card.display_name, err)

    if TypeChoice.PRICE not in skip_types:
        try:
            product_prices = tcg_player.get_product_prices(
                group_id=expansion.expansion_id, product_id=card.card_id
            )
            product_price = next((x for x in product_prices if x.sub_type_name == card.style), None)
            if product_price:
                card = card.update_prices(session=session, product_prices=product_price)
            else:
                LOGGER.warning("Unable to find Card prices, style: %s", card.style)
        except ServiceError as err:
            LOGGER.error("Unable to retrieve prices for %s: %s", card.display_name, err)


@app.command(name="refresh")
def refresh_cards(
    game: Annotated[GameChoice, Argument(case_sensitive=False)],
    skip_types: Annotated[
        list[TypeChoice],
        Option("--skip-type", "-T", show_default=False, case_sensitive=False, default_factory=list),
    ],
) -> None:
    _settings, tcg_player, db_engine = setup()
    game = _get_game_by_choice(game)

    with (
        Session(db_engine) as session,
        Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            MofNCompleteColumn(),
            expand=True,
        ) as progress,
    ):
        expansions = sorted(
            session.exec(select(Expansion).where(Expansion.game == game)).all(),
            key=lambda x: x.display_name,
        )
        expansions_task = progress.add_task("Updating Expansions", total=len(expansions))

        for expansion in expansions:
            expansion = _update_expansion(tcg_player, session, expansion, game, skip_types)

            cards = sorted(expansion.cards, key=lambda x: (x.number.zfill(3), not x.style))
            cards_task = progress.add_task(
                f"Updating {expansion.display_name} Cards", total=len(cards)
            )

            for card in cards:
                _update_card(tcg_player, session, card, expansion, skip_types)
                progress.advance(cards_task)

            progress.advance(expansions_task)
