__all__ = ["settings"]

from foiled_again.cli._typer import app
from foiled_again.settings import Settings


@app.command(help="Display app settings and defaults.")
def settings() -> None:
    settings = Settings.load()
    settings.display()
