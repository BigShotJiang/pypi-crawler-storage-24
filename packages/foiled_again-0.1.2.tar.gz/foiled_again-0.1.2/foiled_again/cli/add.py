__all__ = []

import logging
from typing import Annotated

from sqlmodel import Session
from typer import Abort, Argument, Option

from foiled_again.cli._typer import app
from foiled_again.cli.common import GameChoice, _get_game_by_choice, _select_from_menu, setup
from foiled_again.database import Card, Expansion
from foiled_again.errors import ServiceError

LOGGER = logging.getLogger(__name__)


@app.command(name="add")
def add_card(
    game: Annotated[GameChoice, Argument(case_sensitive=False)],
    number: Annotated[str, Option("--number", "-n", prompt=True)],
    set_code: Annotated[str | None, Option("--set-code", "-c")] = None,
    set_name: Annotated[str | None, Option("--set-name", "-s")] = None,
    quantity: Annotated[int, Option("--quantity", "-q")] = 1,
) -> None:
    if not set_code and not set_name:
        LOGGER.warning("Add requires either a set-code or a set-name")
        raise Abort

    _settings, tcg_player, db_engine = setup()
    game = _get_game_by_choice(game)

    try:
        groups = tcg_player.list_groups(category_id=game.category_id)
        if set_code:
            groups = [x for x in groups if set_code.casefold() in x.abbreviation.casefold()]
        elif set_name:
            groups = [x for x in groups if set_name.casefold() in x.name.casefold()]
    except ServiceError as err:
        LOGGER.error("Unable to retrieve groups for %s: %s", game.display_name, err)
        return

    group = _select_from_menu(groups, "display_name", "Select Expansion")
    if not group:
        return
    LOGGER.info("Selected %s", group.display_name)

    try:
        products = tcg_player.list_products(category_id=game.category_id, group_id=group.group_id)
        products = sorted(
            [x for x in products if number.casefold() in x.number.casefold()],
            key=lambda x: x.number.zfill(3),
        )
    except ServiceError as err:
        LOGGER.error("Unable to retrieve products for %s: %s", group.display_name, err)
        return

    product = _select_from_menu(products, "name", "Select Card")
    if not product:
        return
    LOGGER.info("Selected %s", product.name)

    try:
        product_prices = sorted(
            tcg_player.get_product_prices(group_id=group.group_id, product_id=product.product_id),
            key=lambda x: x.sub_type_name,
        )
    except ServiceError as err:
        LOGGER.error("Unable to retrieve prices for %s: %s", product.name, err)
        return

    product_price = _select_from_menu(
        product_prices, "sub_type_name", "Select Style", skip_one=False
    )
    if not product_price:
        return
    LOGGER.info("Selected %s", product_price.sub_type_name)

    with Session(db_engine) as session:
        expansion = Expansion.create(session=session, game=game, group=group)
        card = Card.create(
            session=session, expansion=expansion, product=product, product_prices=product_price
        )
        card.quantity += quantity
        session.add(card)
        session.commit()
        session.refresh(card)
        LOGGER.info(
            "Added %d '%s' card%s",
            quantity,
            card.display_name.replace("'", "\\'"),
            "s" if quantity > 1 else "",
        )
