__all__ = []

import logging
from decimal import Decimal
from typing import Annotated

from currency_converter import CurrencyConverter
from rich.table import Column, Table
from sqlmodel import Session, select
from typer import Argument

from foiled_again.cli._typer import app
from foiled_again.cli.common import GameChoice, _get_game_by_choice, setup
from foiled_again.console import CONSOLE
from foiled_again.database import Expansion
from foiled_again.settings import PricingColours, Settings

LOGGER = logging.getLogger(__name__)


@app.command(name="view")
def view_cards(game: Annotated[GameChoice, Argument(case_sensitive=False)]) -> None:
    settings, _, db_engine = setup()
    game = _get_game_by_choice(game)

    exchange = CurrencyConverter()
    exchange_rate = Decimal(exchange.convert(1, "USD", "NZD"))
    CONSOLE.print(f"Exchange Rate: 1 USD == {exchange_rate:.2f} NZD")

    total_cards = total_quantity = 0
    total_price = Decimal(0)

    with Session(db_engine) as session:
        expansions = sorted(
            session.exec(select(Expansion).where(Expansion.game == game)).all(),
            key=lambda x: (x.release_date, x.display_name),
        )

        for expansion in expansions:
            table, _card_count, _price_count = _create_expansion_table(
                expansion, exchange_rate, settings
            )
            CONSOLE.print(table)

        game_table = Table(
            "Release Date",
            "Code",
            "Name",
            Column("Cards", justify="right"),
            Column("Quantity", justify="right"),
            Column("Price", justify="right"),
            expand=True,
        )

        for expansion in sorted(
            expansions, key=lambda x: (x.price, x.release_date, x.display_name)
        ):
            total_cards += len(expansion.cards)
            total_quantity += expansion.quantity
            total_price += expansion.price

            game_table.add_row(
                str(expansion.release_date),
                expansion.code,
                expansion.name,
                f"{len([x for x in expansion.cards if x.quantity >= 1]):,}",
                f"{expansion.quantity:,}",
                f"${exchange_rate * expansion.price:,.2f}",
            )

        game_table.add_section()
        game_table.add_row(
            "Total",
            "",
            "",
            f"{total_cards:,}",
            f"{total_quantity:,}",
            f"${exchange_rate * total_price:,.2f}",
        )
        CONSOLE.print(game_table)


def _get_price_style(settings: PricingColours, value: Decimal) -> str:
    if value >= settings.high_pricing:
        return settings.high_style
    if value >= settings.mid_pricing:
        return settings.mid_style
    return settings.low_style


def _create_expansion_table(
    expansion: Expansion, exchange_rate: Decimal, settings: Settings
) -> tuple[Table, int, Decimal]:
    table = Table(
        Column("Number", justify="right"),
        "Name",
        "Rarity",
        "Style",
        Column("Price", justify="right"),
        Column("Quantity", justify="right"),
        Column("Total", justify="right"),
        title=expansion.display_name,
        expand=True,
    )

    card_count = 0
    price_count = Decimal(0)

    for card in sorted(expansion.cards, key=lambda x: (x.number.zfill(3), not x.style)):
        card_count += card.quantity
        total_price = card.market_price * card.quantity
        price_count += total_price

        table.add_row(
            card.number,
            card.name,
            card.game_rarity,
            card.style,
            f"${exchange_rate * card.market_price:.2f}",
            str(card.quantity),
            f"${exchange_rate * total_price:.2f}",
            style=_get_price_style(settings.pricing_colours, exchange_rate * total_price),
        )

    table.add_section()
    table.add_row("Total", "", "", "", "", str(card_count), f"${exchange_rate * price_count:.2f}")
    return table, card_count, price_count
