__all__ = ["setup"]

import logging
from enum import Enum
from platform import python_version
from typing import TypeVar

from sqlalchemy import Engine
from sqlmodel import SQLModel, create_engine
from typer import Abort

from foiled_again import __version__, setup_logging
from foiled_again.console import create_menu
from foiled_again.database import Game
from foiled_again.errors import AuthenticationError
from foiled_again.settings import Settings
from foiled_again.sqlite_cache import SQLiteCache
from foiled_again.tcg_player import TCGPlayer

LOGGER = logging.getLogger(__name__)


def setup(debug: bool = False) -> tuple[Settings, TCGPlayer, Engine]:
    setup_logging(debug=debug)
    LOGGER.info("Python v%s", python_version())
    LOGGER.info("Foiled Again v%s", __version__)

    settings = Settings.load().save()
    tcg_player = _initialize_tcg_player(settings)

    engine = create_engine(
        settings.database.db_url, echo=False, connect_args={"check_same_thread": False}
    )
    SQLModel.metadata.create_all(engine)
    return settings, tcg_player, engine


def _initialize_tcg_player(settings: Settings) -> TCGPlayer:
    if settings.tcg_player.access_token:
        tcg_player = TCGPlayer(access_token=settings.tcg_player.access_token, cache=SQLiteCache())
        try:
            tcg_player.list_categories()
            return tcg_player
        except AuthenticationError:
            pass

    if not (settings.tcg_player.client_id and settings.tcg_player.client_secret):
        LOGGER.critical(
            "Foiled Again requires both a TCGPlayer Client Id and Client Secret to be set."
        )
        raise Abort

    tcg_player = TCGPlayer(
        client_id=settings.tcg_player.client_id,
        client_secret=settings.tcg_player.client_secret,
        cache=SQLiteCache(),
    )
    settings.tcg_player.access_token = tcg_player.access_token
    settings.save()
    return tcg_player


class GameChoice(str, Enum):
    DIGIMON = Game.DIGIMON.clean_name
    POKEMON = Game.POKEMON.clean_name
    MAGIC = Game.MAGIC.clean_name
    FLESH_AND_BLOOD = Game.FLESH_AND_BLOOD.clean_name
    DRAGON_BALL_SUPER = Game.DRAGON_BALL_SUPER.clean_name


def _get_game_by_choice(game_choice: GameChoice) -> Game:
    game = next((x for x in Game if x.clean_name == game_choice.value), None)
    if not game:
        raise Abort
    return game


T = TypeVar("T")


def _select_from_menu(
    items: list[T], display_attr: str, prompt: str, skip_one: bool = True
) -> T | None:
    if not items:
        return None

    options = [getattr(item, display_attr) for item in items]
    index = create_menu(
        options=options, default="None of the Above", prompt=prompt, skip_one_option=skip_one
    )
    return items[index - 1] if index != 0 else None
