__all__ = []

from decimal import Decimal

from currency_converter import CurrencyConverter
from rich.table import Column, Table
from sqlmodel import Session, select

from foiled_again.cli._typer import app
from foiled_again.cli.common import GameChoice, _get_game_by_choice, setup
from foiled_again.console import CONSOLE
from foiled_again.database import Expansion


@app.command()
def summary() -> None:
    _settings, _, db_engine = setup()

    exchange = CurrencyConverter()
    exchange_rate = Decimal(exchange.convert(1, "USD", "NZD"))
    CONSOLE.print(f"Exchange Rate: 1 USD == {exchange_rate:.2f} NZD")

    total_cards = total_quantity = 0
    total_price = Decimal(0)

    summary_table = Table(
        "Game",
        Column("Cards", justify="right"),
        Column("Quantity", justify="right"),
        Column("Price", justify="right"),
        Column("Price/Card", justify="right"),
        expand=True,
    )

    for game in GameChoice:
        game = _get_game_by_choice(game)
        cards = quantity = 0
        price = Decimal(0)

        with Session(db_engine) as session:
            expansions = sorted(
                session.exec(select(Expansion).where(Expansion.game == game)).all(),
                key=lambda x: (x.release_date, x.display_name),
            )
            for expansion in sorted(
                expansions, key=lambda x: (x.price, x.release_date, x.display_name)
            ):
                cards += len(expansion.cards)
                quantity += expansion.quantity
                price += expansion.price
        total_cards += cards
        total_quantity += quantity
        total_price += price

        summary_table.add_row(
            str(game),
            f"{cards:,}",
            f"{quantity:,}",
            f"${exchange_rate * price:,.2f}",
            f"${exchange_rate * (price / quantity):,.2f}",
        )
    summary_table.add_section()
    summary_table.add_row(
        "Total",
        f"{total_cards:,}",
        f"{total_quantity:,}",
        f"${exchange_rate * total_price:,.2f}",
        f"${exchange_rate * (total_price / total_quantity):,.2f}",
    )
    CONSOLE.print(summary_table)
