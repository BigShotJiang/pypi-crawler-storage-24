from foiled_again.cli import app

if __name__ == "__main__":
    app(prog_name="foiled-again")
