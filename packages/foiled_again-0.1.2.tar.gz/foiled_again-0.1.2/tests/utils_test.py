import pytest

from foiled_again.utils import blank_is_none, flatten_dict


@pytest.mark.parametrize(("input_val", "expected"), [("hello", "hello"), (" ", " "), ("", None)])
def test_blank_is_none(input_val: str, expected: str | None) -> None:
    assert blank_is_none(value=input_val) == expected


@pytest.mark.parametrize(
    ("data", "expected"),
    [
        ({"a": 1, "b": 2}, {"a": 1, "b": 2}),
        ({"a": {"b": {"c": 1}}, "d": 2}, {"a.b.c": 1, "d": 2}),
        ({"users": [{"id": 1}, {"id": 2}]}, {"users[0].id": 1, "users[1].id": 2}),
        (
            {"a": {"x": 1, "y": {"z": 2}}, "b": [1, 2, 3], "c": [{"m": 10}, {"n": 20}]},
            {"a.x": 1, "a.y.z": 2, "b": [1, 2, 3], "c[0].m": 10, "c[1].n": 20},
        ),
        ({}, {}),
    ],
)
def test_flatten_dict(data: dict, expected: dict) -> None:
    assert flatten_dict(content=data) == expected
