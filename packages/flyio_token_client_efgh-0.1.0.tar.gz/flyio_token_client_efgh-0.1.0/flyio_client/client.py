import requests



class FlyIOClient:
    """Synchronous client for the Honeybee task API."""

    def __init__(self, host: str = "localhost", port: int = 8000, base_path: str = ""):
        self.host = host
        self.port = port
        self.base_path = base_path.rstrip("/")
        self.base_url = f"http://{self.host}:{self.port}{self.base_path}" or "http://localhost:8000"

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def get_token(self) -> str:
        resp = requests.get(self._url("/api/token"))
        resp.raise_for_status()
        data = resp.json()
        return data

