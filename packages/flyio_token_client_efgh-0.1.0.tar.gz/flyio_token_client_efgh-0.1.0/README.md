# FlyCTL Token Manager

A small fly.io client for ssh token retrieval.

## Installation

```bash
pip install .
```

## Usage

```python
from flyio_client import FlyIOClient

client = FlyIOClient(host="localhost", port=8000)

token = client.get_token()
```

Configure `host`, `port`, or `base_path` if your API is served elsewhere.

