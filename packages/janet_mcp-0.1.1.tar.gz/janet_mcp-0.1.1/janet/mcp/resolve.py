"""Resolution helpers for MCP tool handlers.

Extracted from cli.py with exception-based error handling instead of typer.Exit().
"""

import re
from typing import Dict, List, Optional

from janet.config.manager import ConfigManager
from janet.utils.errors import JanetError


class ResolutionError(JanetError):
    """Failed to resolve a key, assignee, or status."""

    pass




def resolve_project(project_key: str, config_mgr: ConfigManager) -> Dict:
    """Resolve a project key like 'PROJ' to its project dict.

    Returns the project dict from the API (has id, project_identifier, project_name, etc.).
    """
    from janet.api.projects import ProjectAPI

    project_api = ProjectAPI(config_mgr)
    projects = project_api.list_projects()

    key_upper = project_key.upper()
    for p in projects:
        if p.get("project_identifier", "").upper() == key_upper:
            return p

    available = ", ".join(p.get("project_identifier", "?") for p in projects) or "none"
    raise ResolutionError(
        f"Project '{project_key}' not found. Available projects: {available}"
    )


def resolve_ticket_key(ticket_key: str, config_mgr: ConfigManager) -> Dict:
    """Resolve a ticket key like PROJ-123 to its IDs.

    Returns dict with: project_id, project_key, ticket_id, ticket_identifier.
    """
    from janet.api.tickets import TicketAPI

    # UUID pass-through
    if "-" in ticket_key and len(ticket_key) == 36:
        return {
            "ticket_id": ticket_key,
            "project_id": None,
            "project_key": None,
            "ticket_identifier": None,
        }

    # Parse PROJ-123 format
    parts = ticket_key.upper().rsplit("-", 1)
    if len(parts) != 2 or not parts[1].isdigit():
        raise ResolutionError(
            f"Invalid ticket key format: {ticket_key}. Expected format: PROJ-123"
        )

    project_key_str, ticket_num = parts

    # Use the by-key endpoint (single DB lookup, no full sync)
    ticket_api = TicketAPI(config_mgr)
    try:
        result = ticket_api.get_ticket_by_key(project_key_str, int(ticket_num))
        return {
            "project_id": result.get("project_id"),
            "project_key": project_key_str,
            "ticket_id": result.get("ticket", {}).get("id"),
            "ticket_identifier": ticket_num,
        }
    except Exception:
        # Fallback to full sync if by-key endpoint not available
        project = resolve_project(project_key_str, config_mgr)
        project_id = project["id"]

        sync_result = ticket_api.sync_all_tickets(project_id)
        tickets = sync_result.get("tickets", [])
        for t in tickets:
            if str(t.get("ticket_identifier")) == ticket_num:
                return {
                    "project_id": project_id,
                    "project_key": project_key_str,
                    "ticket_id": t["id"],
                    "ticket_identifier": ticket_num,
                }

        raise ResolutionError(f"Ticket '{ticket_key}' not found in project {project_key_str}")


def resolve_ticket_keys_batch(ticket_keys: List[str], config_mgr: ConfigManager) -> List[Dict]:
    """Resolve multiple ticket keys efficiently (one sync call).

    All tickets must be from the same project.
    """
    from janet.api.tickets import TicketAPI

    if not ticket_keys:
        return []

    parsed = []
    for key in ticket_keys:
        parts = key.upper().rsplit("-", 1)
        if len(parts) != 2 or not parts[1].isdigit():
            raise ResolutionError(
                f"Invalid ticket key format: {key}. Expected format: PROJ-123"
            )
        parsed.append((parts[0], parts[1]))

    project_key_str = parsed[0][0]
    project = resolve_project(project_key_str, config_mgr)
    project_id = project["id"]

    ticket_api = TicketAPI(config_mgr)
    sync_result = ticket_api.sync_all_tickets(project_id)

    ticket_map = {
        str(t.get("ticket_identifier")): t["id"]
        for t in sync_result.get("tickets", [])
    }

    results = []
    for pkey, num in parsed:
        tid = ticket_map.get(num)
        if not tid:
            raise ResolutionError(f"Ticket '{pkey}-{num}' not found")
        results.append({
            "project_id": project_id,
            "project_key": project_key_str,
            "ticket_id": tid,
            "ticket_identifier": num,
        })

    return results


def resolve_child_task_key(child_task_key: str, config_mgr: ConfigManager) -> Dict:
    """Resolve a child task key like PROJ-123A to its IDs."""
    from janet.api.child_tasks import ChildTaskAPI

    parts = child_task_key.upper().rsplit("-", 1)
    if len(parts) != 2:
        raise ResolutionError(
            f"Invalid child task key format: {child_task_key}. Expected format: PROJ-123A"
        )

    project_key_str = parts[0]
    remainder = parts[1]

    match = re.match(r"^(\d+)([A-Z]+)$", remainder)
    if not match:
        raise ResolutionError(
            f"Invalid child task key format: {child_task_key}. Expected format: PROJ-123A"
        )

    ticket_num = match.group(1)
    child_suffix = match.group(2)

    parent_key = f"{project_key_str}-{ticket_num}"
    ticket_info = resolve_ticket_key(parent_key, config_mgr)

    child_task_api = ChildTaskAPI(config_mgr)
    child_tasks = child_task_api.list_child_tasks(ticket_info["ticket_id"])

    full_id = f"{project_key_str}-{ticket_num}{child_suffix}"
    for ct in child_tasks:
        if ct.get("fullIdentifier", "").upper() == full_id:
            return {
                **ticket_info,
                "child_task_id": ct["id"],
                "full_identifier": full_id,
            }

    if child_tasks:
        available = ", ".join(ct.get("fullIdentifier", "?") for ct in child_tasks)
        raise ResolutionError(f"Child task '{full_id}' not found. Available: {available}")
    raise ResolutionError(f"No child tasks found for ticket {parent_key}")


def resolve_sub_task_key(sub_task_key: str, config_mgr: ConfigManager) -> Dict:
    """Resolve a sub-task key like PROJ-123A-1 to its IDs."""
    from janet.api.child_tasks import ChildTaskAPI

    parts = sub_task_key.upper().split("-")
    if len(parts) < 3:
        raise ResolutionError(
            f"Invalid sub-task key format: {sub_task_key}. Expected format: PROJ-123A-1"
        )

    sub_num = parts[-1]
    if not sub_num.isdigit():
        raise ResolutionError(
            f"Invalid sub-task key format: {sub_task_key}. Expected format: PROJ-123A-1"
        )

    child_task_key_str = "-".join(parts[:-1])
    child_info = resolve_child_task_key(child_task_key_str, config_mgr)

    child_task_api = ChildTaskAPI(config_mgr)
    sub_tasks = child_task_api.list_sub_tasks(child_info["child_task_id"])

    full_id = f"{child_info['full_identifier']}-{sub_num}"
    for st in sub_tasks:
        if st.get("fullIdentifier", "").upper() == full_id:
            return {
                **child_info,
                "sub_task_id": st["id"],
                "sub_task_full_identifier": full_id,
            }

    if sub_tasks:
        available = ", ".join(st.get("fullIdentifier", "?") for st in sub_tasks)
        raise ResolutionError(f"Sub-task '{full_id}' not found. Available: {available}")
    raise ResolutionError(f"No sub-tasks found for child task {child_info['full_identifier']}")


def resolve_assignees(
    assignees: List[str], project_id: str, config_mgr: ConfigManager
) -> List[str]:
    """Resolve assignee names/emails to project member emails.

    Non-interactive only (for MCP/agent use).
    """
    from janet.api.projects import ProjectAPI

    try:
        project_api = ProjectAPI(config_mgr)
        members = project_api.list_project_members(project_id)
    except Exception:
        return assignees

    active_members = [m for m in members if m.get("status") == "active"]

    config = config_mgr.get()
    current_user_email = config.auth.user_email if config.auth else None

    resolved: List[str] = []
    for raw in assignees:
        raw_lower = raw.strip().lower()

        # "me" / "myself" -> current user
        if raw_lower in ("me", "myself"):
            if not current_user_email:
                # Fallback: fetch from API
                try:
                    from janet.api.client import APIClient
                    client = APIClient(config_mgr)
                    profile = client.get("/api/v1/user/profile", include_org=True)
                    current_user_email = profile.get("user", {}).get("email")
                except Exception:
                    pass
            if current_user_email:
                resolved.append(current_user_email)
                continue
            raise ResolutionError("Cannot resolve 'me' - not authenticated.")

        # Exact email
        email_match = next(
            (m for m in active_members if m.get("userEmail", "").lower() == raw_lower),
            None,
        )
        if email_match:
            resolved.append(email_match["userEmail"])
            continue

        # Full name
        name_matches = [
            m for m in active_members
            if m.get("fullName") and raw_lower == m["fullName"].strip().lower()
        ]
        if len(name_matches) == 1:
            resolved.append(name_matches[0]["userEmail"])
            continue

        # First name
        first_name_matches = [
            m for m in active_members
            if m.get("fullName") and raw_lower == m["fullName"].strip().lower().split()[0]
        ]
        if len(first_name_matches) == 1:
            resolved.append(first_name_matches[0]["userEmail"])
            continue

        # Partial / substring
        partial_matches = [
            m for m in active_members
            if m.get("fullName") and raw_lower in m["fullName"].strip().lower()
        ]
        if len(partial_matches) == 1:
            resolved.append(partial_matches[0]["userEmail"])
            continue

        # Ambiguous
        all_matches = partial_matches or name_matches or first_name_matches
        if all_matches:
            names = ", ".join(
                f"{m.get('fullName', '?')} ({m['userEmail']})" for m in all_matches
            )
            raise ResolutionError(
                f"Ambiguous assignee '{raw}' matched multiple members: {names}. "
                f"Specify the exact full name or email."
            )

        # No match
        member_list = ", ".join(
            f"{m.get('fullName', '?')} ({m['userEmail']})" for m in active_members
        )
        raise ResolutionError(
            f"No project member found matching '{raw}'. Available members: {member_list}"
        )

    return resolved


def resolve_status(
    status: Optional[str], project_id: str, config_mgr: ConfigManager
) -> str:
    """Resolve and validate a status against project columns.

    If status is None, returns the first valid status.
    """
    from janet.api.projects import ProjectAPI

    try:
        project_api = ProjectAPI(config_mgr)
        columns = project_api.get_project_columns(project_id)
        valid_statuses = [c.get("status_value", "") for c in columns if c.get("status_value")]
    except Exception:
        if status:
            return status
        raise ResolutionError("Could not fetch project statuses. Provide a status explicitly.")

    if not valid_statuses:
        if status:
            return status
        raise ResolutionError("No statuses configured for this project.")

    if status:
        for vs in valid_statuses:
            if vs.lower() == status.lower():
                return vs
        raise ResolutionError(
            f"Invalid status '{status}'. Valid statuses: {', '.join(valid_statuses)}"
        )

    return valid_statuses[0]


def resolve_sprint(
    sprint_name: str, project_id: str, config_mgr: ConfigManager
) -> Dict:
    """Resolve a sprint name to its sprint dict."""
    from janet.api.sprints import SprintAPI

    sprint_api = SprintAPI(config_mgr)
    sprints = sprint_api.list_sprints(project_id)

    name_lower = sprint_name.strip().lower()
    for s in sprints:
        if s.get("sprint_name", "").strip().lower() == name_lower:
            return s

    available = ", ".join(s.get("sprint_name", "?") for s in sprints) or "none"
    raise ResolutionError(
        f"Sprint '{sprint_name}' not found. Available sprints: {available}"
    )
