"""Pydantic models for configuration."""

import os
from typing import Optional
from pydantic import BaseModel, Field


class AuthConfig(BaseModel):
    """Authentication configuration."""

    access_token: Optional[str] = None
    user_email: Optional[str] = None


class OrganizationInfo(BaseModel):
    """Organization information."""

    id: str
    name: str
    uuid: str


class APIConfig(BaseModel):
    """API configuration."""

    base_url: str = Field(
        default_factory=lambda: os.getenv(
            "JANET_API_BASE_URL",
            "https://janet-ai-backend-prod-service-11399-85b8d46f-d4i7j6xw.onporter.run"
        )
    )
    timeout: int = 30


class Config(BaseModel):
    """Complete configuration model."""

    version: str = "1.0"
    auth: AuthConfig = Field(default_factory=AuthConfig)
    selected_organization: Optional[OrganizationInfo] = None
    api: APIConfig = Field(default_factory=APIConfig)
