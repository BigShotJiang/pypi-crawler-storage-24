"""Base API client with authentication headers."""

from typing import Dict, Optional

import httpx

from janet.config.manager import ConfigManager
from janet.utils.errors import NetworkError, AuthenticationError

# Shared HTTP client for connection pooling (reused across all API calls)
_http_client: Optional[httpx.Client] = None


def _get_http_client(timeout: int = 30) -> httpx.Client:
    global _http_client
    if _http_client is None or _http_client.is_closed:
        _http_client = httpx.Client(timeout=timeout)
    return _http_client


class APIClient:
    """Base API client for Janet AI."""

    def __init__(self, config_manager: ConfigManager):
        """
        Initialize API client.

        Args:
            config_manager: Configuration manager instance
        """
        self.config_manager = config_manager
        self.config = config_manager.get()
        self.base_url = self.config.api.base_url
        self.timeout = self.config.api.timeout

    def _get_headers(self, include_org: bool = False) -> Dict[str, str]:
        """
        Get request headers with authentication.

        Args:
            include_org: Whether to include organization ID header

        Returns:
            Dictionary of headers
        """
        config = self.config_manager.get()
        access_token = config.auth.access_token
        if not access_token:
            raise AuthenticationError("No API key configured. Set JANET_API_KEY environment variable.")

        from janet import __version__

        # API key auth — use X-API-Key header instead of Bearer
        if access_token and access_token.startswith("jnt_"):
            headers = {
                "X-API-Key": access_token,
                "Content-Type": "application/json",
                "X-Client-Type": "mcp",
                "User-Agent": f"janet-cli/{__version__}",
            }
        else:
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
                "X-Client-Type": "cli",
                "User-Agent": f"janet-cli/{__version__}",
            }

        if include_org and self.config.selected_organization:
            headers["X-Organization-ID"] = self.config.selected_organization.id

        return headers

    def get(self, endpoint: str, include_org: bool = False, **kwargs) -> Dict:
        """
        Make GET request.

        Args:
            endpoint: API endpoint (relative to base_url)
            include_org: Whether to include organization ID header
            **kwargs: Additional arguments for httpx.get

        Returns:
            Response JSON

        Raises:
            NetworkError: If request fails
        """
        url = f"{self.base_url}{endpoint}"
        headers = self._get_headers(include_org=include_org)

        try:
            response = _get_http_client(self.timeout).get(url, headers=headers, **kwargs)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthenticationError("Authentication failed. Please log in again.")
            raise NetworkError(f"API request failed: {e.response.status_code} {e.response.text}")
        except httpx.TimeoutException:
            raise NetworkError(f"Request timeout after {self.timeout}s")
        except Exception as e:
            raise NetworkError(f"Network error: {e}")

    def post(
        self, endpoint: str, data: Optional[Dict] = None, include_org: bool = False, **kwargs
    ) -> Dict:
        """
        Make POST request.

        Args:
            endpoint: API endpoint (relative to base_url)
            data: Request body data
            include_org: Whether to include organization ID header
            **kwargs: Additional arguments for httpx.post

        Returns:
            Response JSON

        Raises:
            NetworkError: If request fails
        """
        url = f"{self.base_url}{endpoint}"
        headers = self._get_headers(include_org=include_org)

        try:
            response = _get_http_client(self.timeout).post(
                url, headers=headers, json=data, **kwargs
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthenticationError("Authentication failed. Please log in again.")
            raise NetworkError(f"API request failed: {e.response.status_code} {e.response.text}")
        except httpx.TimeoutException:
            raise NetworkError(f"Request timeout after {self.timeout}s")
        except Exception as e:
            raise NetworkError(f"Network error: {e}")

    def put(
        self, endpoint: str, data: Optional[Dict] = None, include_org: bool = False, **kwargs
    ) -> Dict:
        """
        Make PUT request.

        Args:
            endpoint: API endpoint (relative to base_url)
            data: Request body data
            include_org: Whether to include organization ID header
            **kwargs: Additional arguments for httpx.put

        Returns:
            Response JSON

        Raises:
            NetworkError: If request fails
        """
        url = f"{self.base_url}{endpoint}"
        headers = self._get_headers(include_org=include_org)

        try:
            response = _get_http_client(self.timeout).put(
                url, headers=headers, json=data, **kwargs
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthenticationError("Authentication failed. Please log in again.")
            raise NetworkError(f"API request failed: {e.response.status_code} {e.response.text}")
        except httpx.TimeoutException:
            raise NetworkError(f"Request timeout after {self.timeout}s")
        except Exception as e:
            raise NetworkError(f"Network error: {e}")

    def delete(self, endpoint: str, data: Optional[Dict] = None, include_org: bool = False, **kwargs) -> Dict:
        """
        Make DELETE request.

        Args:
            endpoint: API endpoint (relative to base_url)
            data: Optional request body data
            include_org: Whether to include organization ID header
            **kwargs: Additional arguments for httpx

        Returns:
            Response JSON

        Raises:
            NetworkError: If request fails
        """
        url = f"{self.base_url}{endpoint}"
        headers = self._get_headers(include_org=include_org)

        try:
            response = _get_http_client(self.timeout).request("DELETE", url, headers=headers, json=data, **kwargs)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthenticationError("Authentication failed. Please log in again.")
            raise NetworkError(f"API request failed: {e.response.status_code} {e.response.text}")
        except httpx.TimeoutException:
            raise NetworkError(f"Request timeout after {self.timeout}s")
        except Exception as e:
            raise NetworkError(f"Network error: {e}")
