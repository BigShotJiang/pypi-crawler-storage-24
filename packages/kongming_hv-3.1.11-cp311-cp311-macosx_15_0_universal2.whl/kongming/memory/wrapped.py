from contextlib import contextmanager
from typing import Iterable

from kongming.api import aletheia_pb2, chunk_pb2
from kongming.ext import hv, memory, badger
from kongming.hv import helpers
from kongming.memory import base


@contextmanager
def managed_memory(path: str, read_only: bool):
    ctx = hv.background()
    m = badger.connect(ctx, path, read_only, None)
    wrapped = WrappedMemory(m)
    try:
        yield wrapped
    finally:
        m.close(ctx)


class WrappedMemory(base.Memory):
    """WrappedMemory implements base.Memory by wrapping a Go-native memory."""

    def __init__(self, core: memory.Memory):
        self._core = core

    def name(self) -> str:
        return self._core.name()

    def id(self) -> int:
        return self._core.id()

    def get(
        self,
        picker: memory.CodePicker | aletheia_pb2.CodePickerProto,
        session: aletheia_pb2.Session = None,
    ) -> Iterable[chunk_pb2.Chunk]:
        if isinstance(picker, memory.CodePicker):
            pass
        elif isinstance(picker, aletheia_pb2.CodePickerProto):
            picker = memory.to_code_picker(helpers.from_native_picker(picker))
        else:
            raise ValueError(f"picker: unhandled type {type(picker)}")

        resp = self._core.get(
            hv.background(), picker, helpers.from_native_session(session)
        )
        native_resp = helpers.to_native_msg("GetResponse", resp)
        for item in native_resp.read:
            yield item

    def set(
        self,
        producer: memory.ChunkProducer | aletheia_pb2.ChunkProducerProto,
        session: aletheia_pb2.Session = None,
    ) -> chunk_pb2.Chunk:
        if isinstance(producer, memory.CodePicker):
            pass
        elif isinstance(producer, aletheia_pb2.CodeProducerProto):
            producer = memory.to_chunk_producer(helpers.from_native_producer(producer))
        else:
            raise ValueError(f"producer: unhandled type {type(producer)}")

        resp = self._core.set(
            hv.background(), producer, helpers.from_native_session(session)
        )
        native_resp = helpers.to_native_msg("SetResponse", resp)
        return native_resp.written
