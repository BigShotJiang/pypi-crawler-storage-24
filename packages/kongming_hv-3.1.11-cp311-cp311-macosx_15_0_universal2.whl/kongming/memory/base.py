from abc import ABC, abstractmethod
from typing import Iterable

from kongming.api import aletheia_pb2, chunk_pb2
from kongming.ext import memory


class Memory(ABC):
    """Memory is a Pythonic abstract class, modeled after the Go counterpart of `memory.Memory`."""

    @abstractmethod
    def name(self) -> str:
        raise NotImplementedError("Memory.name()")

    @abstractmethod
    def id(self) -> int:
        raise NotImplementedError("Memory.id()")

    @abstractmethod
    def get(
        self,
        picker: memory.CodePicker | aletheia_pb2.CodePickerProto,
        session: aletheia_pb2.Session = None,
    ) -> Iterable[chunk_pb2.Chunk]:
        raise NotImplementedError("Memory.get()")

    @abstractmethod
    def set(
        self,
        producer: memory.ChunkProducer | aletheia_pb2.ChunkProducerProto,
        session: aletheia_pb2.Session = None,
    ) -> chunk_pb2.Chunk:
        raise NotImplementedError("Memory.set()")
