from contextlib import contextmanager
from typing import Iterable

import grpc

from kongming.api import aletheia_pb2, aletheia_pb2_grpc, chunk_pb2
from kongming.ext import hv, memory
from kongming.hv import helpers
from kongming.memory import base


@contextmanager
def managed_remote_memory(target: str, credentials=None):
    if credentials is None:
        channel = grpc.insecure_channel(target)
    else:
        channel = grpc.secure_channel(target, credentials)

    with channel:
        stub = aletheia_pb2_grpc.AletheiaServiceStub(channel)
        yield RemoteMemory(target, stub)


class RemoteMemory(base.Memory):
    """RemoteMemory implements base.Memory by a local agent that interacts with a remote memory service.

    The 'remote' memory can be located anywhere, even locally. However, the communication is done through gRPC.
    """

    def __init__(self, target: str, stub):
        self._target = target
        self._stub = stub

    # Perform initial request to retriev name/id from the remote memory service.
    def name(self) -> str:
        return self._target

    def id(self) -> int:
        return hv.hash64_from_string(self._target)

    def get(
        self,
        picker: memory.CodePicker | aletheia_pb2.CodePickerProto,
        session: aletheia_pb2.Session = None,
    ) -> Iterable[chunk_pb2.Chunk]:
        """get gets all chunks that matches the criteria implied by picker."""
        if isinstance(picker, memory.CodePicker):
            picker = helpers.to_native_picker(picker.proto_load())
        elif isinstance(picker, aletheia_pb2.CodePickerProto):
            pass
        else:
            raise ValueError(f"picker: unhandled type {type(picker)}")

        resp = self._stub.Get(aletheia_pb2.GetRequest(picker=picker, session=session))
        for item in resp.read:
            yield item

    def set(
        self,
        producer: memory.ChunkProducer | aletheia_pb2.ChunkProducerProto,
        session: aletheia_pb2.Session = None,
    ) -> chunk_pb2.Chunk:
        """set sets the chunk produced by producer, return the chunk upon success."""
        if isinstance(producer, memory.ChunkProducer):
            producer = helpers.to_native_producer(producer.proto_load())
        elif isinstance(producer, aletheia_pb2.ChunkProducerProto):
            pass
        else:
            raise ValueError(f"producer: unhandled type {type(producer)}")

        resp = self._stub.Set(
            aletheia_pb2.SetRequest(producer=producer, session=session)
        )
        return resp.written
