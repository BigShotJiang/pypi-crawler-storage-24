from importlib.metadata import version as _version, PackageNotFoundError

try:
    __version__ = _version("kongming-hv")
except PackageNotFoundError:
    __version__ = "dev"
