from google.protobuf import message

from kongming.api import hv_pb2
from kongming.ext import go, hv


def from_message(msg: message.Message):
    """from_message returns the Python native obj from the supplied proto message."""
    serialized = msg.SerializeToString()
    if isinstance(msg, hv_pb2.HyperBinaryProto):
        return hv.unload_hyper_binary(
            hv.background(), hv.unmarshal_hyper_binary_proto(go.Slice_byte(serialized))
        )
    elif isinstance(msg, hv_pb2.HyperBinarySetProto):
        return hv.unload_hyper_binary_set(
            hv.background(),
            hv.unmarshal_hyper_binary_set_proto(go.Slice_byte(serialized)),
        )
    else:
        raise ValueError(f"unknown branch for {type(msg)}")


def to_message(obj) -> message.Message:
    """to_message returns the proto message for the supplied Python native obj."""
    if not hasattr(obj, "proto_load"):
        raise ValueError("no proto_load()?")

    loaded = obj.proto_load(hv.background())
    if isinstance(loaded, hv.go.Ptr_api_HyperBinaryProto):
        msg = hv_pb2.HyperBinaryProto()
        msg.ParseFromString(bytes(hv.marshal_hyper_binary_proto(loaded)))
    elif isinstance(loaded, hv.go.Ptr_api_HyperBinarySetProto):
        msg = hv_pb2.HyperBinarySetProto()
        msg.ParseFromString(bytes(hv.marshal_hyper_binary_set_proto(loaded)))
    else:
        raise ValueError(f"unknown branch for {type(obj)}")

    return msg


def weights(weights: list[float]) -> go.Slice_float64:
    """weights is used to supply a list of weight into underlying Go methods that expects weights."""
    return go.Slice_float64(weights)


def keys(keys: list[str]) -> go.Slice_string:
    """keys is used to supply a list of keys into underlying Go methods that expects keys."""
    return go.Slice_string(keys)


# ── Pythonic aliases (class-level constructors) ───────────────────────
#
# Each wrapper subclasses the gopy-generated class and overrides __init__ so
# that natural positional call syntax works (e.g. Seed128(high, low)) while
# the gopy internal paths (handle=, single-GoClass copy) still fall through to
# super().  After each class definition we patch it back into the hv module so
# that hv.py-internal factory functions also return wrapper instances.
#
from kongming.ext import hv as _hv


class Seed128(_hv.Seed128):
    """Seed128(high, low) constructs a 128-bit seed directly."""
    def __init__(self, *args, **kwargs):
        if len(args) == 2 and not kwargs:
            super().__init__(handle=_hv._hv.hv_NewSeed128(args[0], args[1]))
        else:
            super().__init__(*args, **kwargs)

    zero   = staticmethod(_hv.seed128_zero)
    create = staticmethod(_hv.new_seed128)


_hv.Seed128 = Seed128


class SparseOperation(_hv.SparseOperation):
    """SparseOperation(model, seed_high, seed_low) constructs a SparseOperation directly."""
    def __init__(self, *args, **kwargs):
        if len(args) == 3 and not kwargs:
            super().__init__(handle=_hv._hv.hv_NewSparseOperation(args[0], args[1], args[2]))
        else:
            super().__init__(*args, **kwargs)

    create = staticmethod(_hv.new_sparse_operation)


_hv.SparseOperation = SparseOperation


class Exp(_hv.Exp):
    """Exp(n) constructs an Exp directly from an integer exponent."""
    def __init__(self, *args, **kwargs):
        if len(args) == 1 and not kwargs and not isinstance(args[0], go.GoClass):
            super().__init__(handle=_hv._hv.hv_NewExp(args[0]))
        else:
            super().__init__(*args, **kwargs)

    create = staticmethod(_hv.new_exp)


_hv.Exp = Exp


class Set(_hv.Set):
    """Set(d, pod, *members) constructs a Set directly."""
    def __init__(self, *args, **kwargs):
        if len(args) >= 2 and not kwargs:
            _tmp = _hv.new_set(*args)
            super().__init__(handle=_tmp.handle)
        else:
            super().__init__(*args, **kwargs)

    create = staticmethod(_hv.new_set)


_hv.Set = Set


class Sequence(_hv.Sequence):
    """Sequence(d, pod, *members) constructs a Sequence directly."""
    def __init__(self, *args, **kwargs):
        if len(args) >= 2 and not kwargs:
            _tmp = _hv.new_sequence(*args)
            super().__init__(handle=_tmp.handle)
        else:
            super().__init__(*args, **kwargs)

    create = staticmethod(_hv.new_sequence)


_hv.Sequence = Sequence


class Octopus(_hv.Octopus):
    """Octopus(d, pod, keys, *values) constructs an Octopus directly."""
    def __init__(self, *args, **kwargs):
        if len(args) >= 3 and not kwargs:
            _tmp = _hv.new_octopus(*args)
            super().__init__(handle=_tmp.handle)
        else:
            super().__init__(*args, **kwargs)

    create = staticmethod(_hv.new_octopus)


_hv.Octopus = Octopus


class Knot(_hv.Knot):
    """Knot(d, pod, *parts) constructs a Knot directly."""
    def __init__(self, *args, **kwargs):
        if len(args) >= 2 and not kwargs:
            _tmp = _hv.new_knot(*args)
            super().__init__(handle=_tmp.handle)
        else:
            super().__init__(*args, **kwargs)

    create = staticmethod(_hv.new_knot)


_hv.Knot = Knot


class Parcel(_hv.Parcel):
    """Parcel(d, pod, *pearls) constructs a Parcel directly."""
    def __init__(self, *args, **kwargs):
        if len(args) >= 2 and not kwargs:
            _tmp = _hv.new_parcel(*args)
            super().__init__(handle=_tmp.handle)
        else:
            super().__init__(*args, **kwargs)

    create    = staticmethod(_hv.new_parcel)
    template  = staticmethod(_hv.new_template)


_hv.Parcel = Parcel


class Dart(_hv.Dart):
    """Dart(d, pod, origin, axisX, axisY, x, y) constructs a Dart directly."""
    def __init__(self, *args, **kwargs):
        if len(args) == 7 and not kwargs:
            _tmp = _hv.new_dart(*args)
            super().__init__(handle=_tmp.handle)
        else:
            super().__init__(*args, **kwargs)

    create = staticmethod(_hv.new_dart)


_hv.Dart = Dart


class Cyclone(_hv.Cyclone):
    """Cyclone(model, d, pod, period) constructs a Cyclone directly."""
    def __init__(self, *args, **kwargs):
        if len(args) == 4 and not kwargs:
            _tmp = _hv.new_cyclone(*args)
            super().__init__(handle=_tmp.handle)
        else:
            super().__init__(*args, **kwargs)

    create = staticmethod(_hv.new_cyclone)


_hv.Cyclone = Cyclone


class Learner(_hv.Learner):
    """Learner(model, d, pod) constructs a Learner directly."""
    def __init__(self, *args, **kwargs):
        if len(args) == 3 and not kwargs:
            _tmp = _hv.new_learner(*args)
            super().__init__(handle=_tmp.handle)
        else:
            super().__init__(*args, **kwargs)

    create    = staticmethod(_hv.new_learner)
    from_seed = staticmethod(_hv.new_learner_with_seed)
    full      = staticmethod(_hv.new_learner_full)
    random    = staticmethod(_hv.new_random_learner)


_hv.Learner = Learner


_hv.Domain.from_name = staticmethod(_hv.new_domain_by_name)
_hv.Domain.from_id   = staticmethod(_hv.new_domain_by_id)

_hv.Pod.from_seed     = staticmethod(_hv.new_pod_by_seed)
_hv.Pod.from_word     = staticmethod(_hv.new_pod_by_word)
_hv.Pod.from_prewired = staticmethod(_hv.new_pod_by_prewired)

_hv.SparseSegmented.identity = staticmethod(_hv.new_sparse_segmented_identity)

_hv.Sparkle.from_domain_pod = staticmethod(_hv.new_sparkle_from_domain_pod)
_hv.Sparkle.from_word       = staticmethod(_hv.new_sparkle_with_word)
_hv.Sparkle.from_prewired   = staticmethod(_hv.new_sparkle_with_prewired)
_hv.Sparkle.from_seed       = staticmethod(_hv.new_sparkle_with_seed)
_hv.Sparkle.identity        = staticmethod(_hv.new_sparkle_identity)
_hv.Sparkle.random          = staticmethod(_hv.new_random_sparkle)
