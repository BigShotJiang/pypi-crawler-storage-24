"""Tests for OpenHands CLI."""
