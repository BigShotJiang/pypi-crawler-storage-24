# Universal Error Handler Decorator (UEHD)

[![Python Version](https://img.shields.io/badge/python-3.7%2B-blue)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)
[![PyPI](https://img.shields.io/badge/pypi-v0.1.0-orange)](https://pypi.org/project/UEHD/)

A Python decorator that intercepts exceptions and provides beautiful, human-readable error reports for beginners and developers alike.

## 📦 Installation

```bash
pip install UEHD
```

## 🚀 Quick Start

```python
from UEHD import Universal_Err_Handler

@Universal_Err_Handler()
def divide_numbers(a, b):
    return a / b

# This will show a clean error report instead of crashing
divide_numbers(10, 0)
```

## 🎯 Features

- **Clean Error Reports**: Get formatted error information instead of messy tracebacks
- **Customizable Output**: Choose what error information to display
- **Beginner-Friendly**: Clear error messages with helpful tips
- **Non-Intrusive**: Option to ignore errors or show full tracebacks when needed
- **Production Ready**: Control program termination on errors

## 📝 Usage Examples

### Basic Error Handling

```python
from UEHD import Universal_Err_Handler

@Universal_Err_Handler()
def risky_function():
    x = 1 / 0  # ZeroDivisionError
    return x

risky_function()
# Output:
# --- ERROR REPORT ---
# Error Type : ZeroDivisionError
# Message    : division by zero
# File       : example.py
# Line       : 4
# Code       :     x = 1 / 0
# Tip        : division by zero
# --- ERROR REPORT ---
# [Execution stopped due to error]
```

### Customizing Error Reports

```python
# Show only specific information
@Universal_Err_Handler(
    Err_Typ=True,           # Show error type
    Err_Msg=True,           # Show error message
    Err_File_Location=False,# Hide file location
    Err_Line=True,          # Show line number
    Show_Traceback=False,   # Don't show full traceback
    Show_Code_Line=True     # Show the code that caused error
)
def process_data():
    my_list = [1, 2, 3]
    return my_list[10]  # IndexError

process_data()
```

### Ignoring Errors (Development Mode)

```python
# Set Ignore=True to let errors pass through normally
@Universal_Err_Handler(Ignore=True)
def debug_function():
    # This will show normal Python traceback
    return 1 / 0

debug_function()
```

### Full Debug Mode

```python
# Show everything including full traceback
@Universal_Err_Handler(
    Show_Traceback=True,    # Show full traceback
    Err_Typ=True,           # Show error type
    Err_Msg=True,           # Show error message
    Err_File_Location=True, # Show file location
    Err_Line=True,          # Show line number
    Show_Code_Line=True,    # Show the code
    Err_Tip=True            # Show error tip
)
def complex_function():
    # Your complex logic here
    raise ValueError("Custom error message")
```

## ⚙️ Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `Ignore` | bool | False | If True, bypass error handling and show normal Python traceback |
| `Err_Typ` | bool | True | Show the type of error (e.g., ZeroDivisionError) |
| `Err_Msg` | bool | True | Show the error message |
| `Err_File_Location` | bool | True | Show the file where error occurred |
| `Err_Line` | bool | True | Show the line number of the error |
| `Err_Tip` | bool | True | Show a helpful tip about the error |
| `Show_Traceback` | bool | False | Show the full Python traceback |
| `Show_Code_Line` | bool | True | Show the actual line of code that caused the error |

## 🎓 For Beginners

### Why use UEHD?

When you're learning Python, error messages can be scary and hard to understand. UEHD makes them friendly and easy to read!

**Without UEHD:**
```
Traceback (most recent call last):
  File "example.py", line 4, in <module>
    print(10 / 0)
ZeroDivisionError: division by zero
```

**With UEHD:**
```
--- ERROR REPORT ---
Error Type : ZeroDivisionError
Message    : division by zero
File       : example.py
Line       : 4
Code       :     print(10 / 0)
Tip        : division by zero
--- ERROR REPORT ---
```

### Common Use Cases

1. **Learning Python**: Understand errors without being overwhelmed by tracebacks
2. **Debugging**: Quickly identify where and why errors occur
3. **Teaching**: Show clean error reports to students
4. **Production**: Control how errors are displayed to users

## 📋 Requirements

- Python 3.7 or higher
- No external dependencies required!

## 📊 Version History

- **v0.1.0** (Latest) - Initial release with core functionality
  - Basic error interception and reporting
  - Customizable output parameters
  - Option to ignore errors or show tracebacks

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 📬 Contact

For questions, suggestions, or feedback, please email: your.email@example.com

## ⭐ Show Your Support

If you find this package helpful, consider sharing it with others who might benefit from it!

---

**Latest Version: v0.1.0** | Python 3.7+ Required | MIT License

Made with ❤️ for Python beginners and developers
