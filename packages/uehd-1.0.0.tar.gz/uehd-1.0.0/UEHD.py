import builtins
import traceback
import linecache
from functools import wraps
from typing import Optional, Callable, Any

def Universal_Err_Handler(
    Ignore: bool = False,
    Err_Typ: bool = True,
    Err_Msg: bool = True,
    Err_File_Location: bool = True,
    Err_Line: bool = True,
    Err_Tip: bool = True,
    Show_Traceback: bool = False,
    Show_Code_Line: bool = True
):
    """
    A decorator that intercepts exceptions in decorated functions, providing a human-readable
    diagnostic report and controlling program termination upon error detection.
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if Ignore:
                return func(*args, **kwargs)

            try:
                return func(*args, **kwargs)
            except Exception as e:
                exc_type, exc_value, exc_traceback = traceback.sys.exc_info()
                frame = traceback.extract_tb(exc_traceback)[-1]

                print(f"\n--- ERROR REPORT ---")
                if Err_Typ: print(f"Error Type : {type(e).__name__}")
                if Err_Msg: print(f"Message    : {str(e)}")
                if Err_File_Location: print(f"File       : {frame.filename}")
                if Err_Line: print(f"Line       : {frame.lineno}")
                if Show_Code_Line:
                    line = linecache.getline(frame.filename, frame.lineno).strip()
                    print(f"Code       :  {line}")
                if Err_Tip: print(f"Tip        : {e.args[0] if e.args else 'Check code logic'}")
                print(f"--- ERROR REPORT ---")

                if Show_Traceback:
                    print("--- FULL TRACEBACK ---")
                    traceback.print_exception(exc_type, exc_value, exc_traceback)
                    print("--- FULL TRACEBACK ---")

                raise SystemExit("[Execution stopped due to error]")
        return wrapper
    return decorator
