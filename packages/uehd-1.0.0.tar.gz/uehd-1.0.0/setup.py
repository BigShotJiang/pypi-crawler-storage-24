from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="UEHD",
    version="1.0.0",
    author="Lingaraj Sa",
    author_email="infofusiontechlab@gmail.com",
    description="Universal Error Handler Decorator - Beautiful error reports for Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://pypi.org/project/UEHD",
    py_modules=["UEHD"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Topic :: Software Development :: Debuggers",
        "Topic :: Education",
    ],
    python_requires=">=3.7",
    keywords="error-handler, debugging, beginner-friendly, exception-handling",
    project_urls={
        "Homepage": "https://pypi.org/project/UEHD",
        "Bug Reports": "https://pypi.org/project/UEHD",
        "Source": "https://pypi.org/project/UEHD",
    },
)
