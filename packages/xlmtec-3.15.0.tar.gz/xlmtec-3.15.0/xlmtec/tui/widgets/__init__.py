"""TUI widgets package."""
