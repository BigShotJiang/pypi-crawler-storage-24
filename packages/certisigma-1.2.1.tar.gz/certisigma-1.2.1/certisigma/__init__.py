"""CertiSigma Python SDK — Attestation & Verification client."""

from .client import CertiSigmaClient, AsyncCertiSigmaClient
from .exceptions import CertiSigmaError, AuthenticationError, RateLimitError, QuotaExceededError
from .hash import hash_file, hash_bytes

__version__ = "1.2.1"
__all__ = [
    "CertiSigmaClient",
    "AsyncCertiSigmaClient",
    "CertiSigmaError",
    "AuthenticationError",
    "RateLimitError",
    "QuotaExceededError",
    "hash_file",
    "hash_bytes",
]
