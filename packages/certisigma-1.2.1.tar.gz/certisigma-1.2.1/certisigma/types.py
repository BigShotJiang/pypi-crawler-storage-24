"""CertiSigma SDK — Type definitions."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AttestResult:
    id: str
    hash_hex: str
    timestamp: str
    status: str
    signature: Optional[str] = None
    signing_key_id: Optional[str] = None
    format_version: str = "1.0.0"
    claim_id: Optional[int] = None
    source: Optional[str] = None
    extra_data: Optional[dict] = None
    client_encrypted: bool = False


@dataclass
class VerifyResult:
    exists: bool
    hash_hex: str
    id: Optional[str] = None
    timestamp: Optional[str] = None
    source: Optional[str] = None
    level: Optional[str] = None
    verified_at: Optional[str] = None


@dataclass
class BatchAttestResult:
    batch_id: str
    count: int
    created: int
    existing: int
    attestations: list = field(default_factory=list)


@dataclass
class BatchVerifyResult:
    count: int
    found: int
    not_found: int
    results: list = field(default_factory=list)


@dataclass
class MetadataPatchResult:
    success: bool
    claim_id: int
    attestation_id: str
    source: Optional[str] = None
    extra_data: Optional[dict] = None
    client_encrypted: bool = False
    deleted: bool = False
    audit_entries: int = 0


@dataclass
class EvidenceResult:
    hash_hex: str
    level: str
    t0: dict = field(default_factory=dict)
    t1: Optional[dict] = None
    t2: Optional[dict] = None
    id: Optional[str] = None


@dataclass
class AttestationStatus:
    id: str
    hash_hex: str
    level: str
    t0_timestamp: str
    t1_timestamp: Optional[str] = None
    t2_timestamp: Optional[str] = None
    t2_bitcoin_block: Optional[int] = None
    signature_available: bool = False
    tsa_available: bool = False
    merkle_proof_available: bool = False
