from typing import Any

from colorado.base.populated_place import PopulatedPlace, PopulatedPlaceEnum


class CensusDesignatedPlace(PopulatedPlace):
    """
    Represents a census-designated place in the state of Colorado.
    """

    def __init__(self, /, **data: Any):
        super().__init__(**data)


class CensusDesignatedPlaces(PopulatedPlaceEnum):
    """
    An enumeration of census-designated places in the state of Colorado.
    """
    """
    ACRES_GREEN = CensusDesignatedPlace(
        name="Acres Green",
        abbreviations=Abbreviations(
            three_letter="ACR",
            five_letter="ACRES",
            seven_letter="ACRES G",
            fourteen_letter="ACRES GREEN"
        ),
        latitude=39.556661500356654,
        longitude=-104.89610036561157,
        counties=[Counties.DOUGLAS],
        nearest_airport=Airports.DENVER
    )
    ALLENSPARK = CensusDesignatedPlace(
        name="Allenspark",
        abbreviations=Abbreviations(
            three_letter="ALL",
            five_letter="ALLEN",
            seven_letter="ALLENSP",
            fourteen_letter="ALLENSPARK"
        ),
        latitude=40.19443584305941,
        longitude=-105.52556518619838,
        counties=[Counties.BOULDER],
        nearest_airport=Airports.NORTHERN_COLORADO
    )
    BROOK_FOREST = CensusDesignatedPlace(
        name="Brook Forest",
        abbreviations=Abbreviations(
            three_letter="BRO",
            five_letter="BROOK",
            seven_letter="BROOK F",
            fourteen_letter="BROOK FOREST"
        ),
        latitude=39.579439170047124,
        longitude=-105.38194938014254,
        counties=[Counties.JEFFERSON, Counties.CLEAR_CREEK],
        nearest_airport=Airports.DENVER
    )
    # Coal Creek Canyon
    COAL_CREEK = CensusDesignatedPlace(
        name="Coal Creek",
        abbreviations=Abbreviations(
            three_letter="COA",
            five_letter="COAL ",
            seven_letter="COAL CR",
            fourteen_letter="COAL CREEK"
        ),
        latitude=39.90638211473009,
        longitude=-105.37750361780144,
        counties=[Counties.JEFFERSON, Counties.BOULDER, Counties.GILPIN],
        nearest_airport=Airports.NORTHERN_COLORADO
    )
    COLUMBINE = CensusDesignatedPlace(
        name="Columbine",
        abbreviations=Abbreviations(
            three_letter="COL",
            five_letter="COLUM",
            seven_letter="COLUMBI",
            fourteen_letter="COLUMBINE"
        ),
        latitude=39.58777209263394,
        longitude=-105.06943960892369,
        counties=[Counties.JEFFERSON, Counties.ARAPAHOE],
        nearest_airport=Airports.DENVER
    )
    HIGHLANDS_RANCH = CensusDesignatedPlace(
        name="Highlands Ranch",
        abbreviations=Abbreviations(
            three_letter="HLD",
            five_letter="HGHLN",
            seven_letter="HGHLND",
            fourteen_letter="HIGHLANDSRANCH"
        ),
        latitude=39.55388349459594,
        longitude=-104.96943648260083,
        counties=[Counties.DOUGLAS],
        nearest_airport=Airports.DENVER
    )
    STRASBURG = CensusDesignatedPlace(
        name="Strasburg",
        abbreviations=Abbreviations(
            three_letter="STR",
            five_letter="STRAS",
            seven_letter="STRASBU",
            fourteen_letter="STRASBURG"
        ),
        latitude=39.73832276453544,
        longitude=-104.32330245353336,
        counties=[Counties.ARAPAHOE, Counties.ADAMS],
        nearest_airport=Airports.DENVER
    )
    """
