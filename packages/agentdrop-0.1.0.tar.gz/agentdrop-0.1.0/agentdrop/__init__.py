"""AgentDrop — Encrypted file transfer for AI agents."""

from .client import AgentDrop, AgentDropError, ShieldBlockError, Transfer
from .crypto import KeyPair
from .shield import (
    Shield,
    ShieldError,
    ScanConfig,
    ScanResult,
    InjectionFinding,
    ThreatLevel,
    Strictness,
)

__version__ = "0.1.0"
__all__ = [
    "AgentDrop",
    "AgentDropError",
    "ShieldBlockError",
    "Transfer",
    "KeyPair",
    "Shield",
    "ShieldError",
    "ScanConfig",
    "ScanResult",
    "InjectionFinding",
    "ThreatLevel",
    "Strictness",
]
