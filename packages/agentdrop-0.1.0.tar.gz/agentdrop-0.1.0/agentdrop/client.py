"""
AgentDrop Python SDK — main client.

Usage:
    from agentdrop import AgentDrop

    client = AgentDrop(api_key="agd_...", agent_id="my-agent")
    client.connect(token="agt_...")   # one-time setup
    client.send("other-agent", ["report.pdf"])
    transfers = client.inbox()
    client.listen(on_transfer=handle_file)
"""

import os
import json
import time
import base64
import warnings
import threading
from pathlib import Path
from typing import Callable, Optional

import requests

from .crypto import (
    KeyPair,
    encrypt_file,
    decrypt_file,
    encrypt_symmetric_key,
    decrypt_symmetric_key,
    derive_shared_secret,
    derive_transfer_key,
    ALGORITHM,
    CHANNEL_ALGORITHM,
    SALT_BYTES,
)
from .shield import Shield, ScanConfig, ScanResult, Strictness, ThreatLevel, ShieldError


API_BASE = "https://api.agent-drop.com"
CONFIG_DIR = ".agentdrop"
CONFIG_FILE = "config.json"


class AgentDropError(Exception):
    """Base exception for AgentDrop SDK errors."""
    def __init__(self, message: str, code: str = None, status: int = None):
        super().__init__(message)
        self.code = code
        self.status = status


class ShieldBlockError(AgentDropError):
    """Raised when Shield blocks a file download due to detected threats.

    Attributes:
        scan_result: The full ScanResult with threat details and findings.
        filename: The file that was blocked.
    """
    def __init__(self, filename: str, scan_result: ScanResult):
        self.scan_result = scan_result
        self.filename = filename
        super().__init__(
            f"Shield blocked '{filename}': {scan_result.summary()}",
            code="SHIELD_BLOCKED",
        )


class Transfer:
    """A file transfer from the inbox."""

    def __init__(self, data: dict):
        self.id = data["id"]
        self.sender = data["sender"]
        self.recipient = data["recipient"]
        self.mode = data.get("mode", "agent-to-agent")
        self.status = data.get("status", "active")
        self.message = data.get("message")
        self.is_encrypted = data.get("is_encrypted", False)
        self.files = data.get("files", [])
        self.total_size = data.get("total_size", 0)
        self.download_url = data.get("download_url")
        self.expires_at = data.get("expires_at")
        self.created_at = data.get("created_at")
        # Pairwise channel encryption fields
        self.channel_id = data.get("channel_id")
        self.encryption_salt = data.get("encryption_salt")
        self._raw = data

    def __repr__(self):
        return f"<Transfer {self.id} from={self.sender} files={len(self.files)}>"


class AgentDrop:
    """AgentDrop SDK client for AI agents."""

    def __init__(
        self,
        api_key: str,
        agent_id: str = None,
        agent_uuid: str = None,
        inbox_url: str = None,
        api_base: str = API_BASE,
        config_dir: str = CONFIG_DIR,
        shield: bool = True,
        shield_strictness: str = "standard",
        shield_config: Optional[ScanConfig] = None,
    ):
        self.api_key = api_key
        self.agent_id = agent_id
        self.agent_uuid = agent_uuid
        self.inbox_url = inbox_url
        self.api_base = api_base.rstrip("/")
        self.config_dir = Path(config_dir)
        self._keys: Optional[KeyPair] = None
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "User-Agent": "agentdrop-python/0.1.0",
        })
        self._listener_thread = None
        self._listening = False

        # Pairwise channel cache: {recipient_agent_id: channel_data}
        self._channel_cache: dict[str, dict] = {}

        # Shield file security scanner
        self._shield_enabled = shield
        self._shield: Optional[Shield] = None
        if shield:
            if shield_config:
                self._shield = Shield(config=shield_config)
            else:
                strictness_map = {s.value: s for s in Strictness}
                strictness_key = shield_strictness.lower()
                if strictness_key not in strictness_map:
                    raise AgentDropError(
                        f"Invalid shield_strictness '{shield_strictness}'. "
                        f"Valid options: {', '.join(strictness_map.keys())}"
                    )
                self._shield = Shield(
                    config=ScanConfig(strictness=strictness_map[strictness_key])
                )

        # Try to load saved config
        self._load_config()

    def _load_config(self):
        """Load saved agent config from disk."""
        config_path = self.config_dir / CONFIG_FILE
        if config_path.exists():
            with open(config_path) as f:
                config = json.load(f)
            self.agent_id = self.agent_id or config.get("agent_id")
            self.agent_uuid = self.agent_uuid or config.get("agent_uuid")
            self.inbox_url = self.inbox_url or config.get("inbox_url")
            if config.get("private_key"):
                self._keys = KeyPair.from_private_bytes(config["private_key"])

    def _save_config(self):
        """Persist agent config to disk."""
        self.config_dir.mkdir(parents=True, exist_ok=True)
        config = {
            "agent_id": self.agent_id,
            "agent_uuid": self.agent_uuid,
            "inbox_url": self.inbox_url,
            "public_key": self._keys.public_key_b64 if self._keys else None,
            "private_key": self._keys.private_key_b64 if self._keys else None,
        }
        config_path = self.config_dir / CONFIG_FILE
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """Make an authenticated API request."""
        url = f"{self.api_base}{path}" if path.startswith("/") else path
        resp = self._session.request(method, url, **kwargs)
        if resp.status_code >= 400:
            try:
                err = resp.json().get("error", {})
                raise AgentDropError(
                    err.get("message", resp.text),
                    code=err.get("code"),
                    status=resp.status_code,
                )
            except (ValueError, KeyError):
                raise AgentDropError(resp.text, status=resp.status_code)
        return resp.json()

    # ─── Connection ─────────────────────────────────────────────

    def connect(self, token: str) -> dict:
        """
        Connect to AgentDrop using a one-time connection token.

        Generates encryption keys, registers them with the server,
        and saves everything to disk. Call this once.

        Args:
            token: The agt_ connection token from registration.

        Returns:
            Connection response with agent_id and status.
        """
        # Generate fresh encryption keys
        self._keys = KeyPair.generate()

        # Connect with the token
        resp = requests.post(
            f"{self.api_base}/v1/agents/connect",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json={
                "public_key": self._keys.public_key_b64,
                "public_key_algorithm": "X25519",
            },
        )

        if resp.status_code >= 400:
            try:
                err = resp.json().get("error", {})
                raise AgentDropError(
                    err.get("message", resp.text),
                    code=err.get("code"),
                    status=resp.status_code,
                )
            except (ValueError, KeyError):
                raise AgentDropError(resp.text, status=resp.status_code)

        data = resp.json()
        self.agent_id = data.get("agent_id", self.agent_id)
        self.agent_uuid = data.get("agent_uuid", self.agent_uuid)

        # Save config to disk
        self._save_config()

        return data

    # ─── Pairwise Channels ─────────────────────────────────────

    def _resolve_agent_uuid(self, agent_id: str) -> Optional[str]:
        """Resolve an agent_id to its UUID via the resolve endpoint."""
        try:
            data = self._request("GET", f"/v1/agents/resolve?agent_id={agent_id}")
            return data.get("id") or data.get("agent_uuid")
        except AgentDropError:
            return None

    def _get_or_create_channel(self, recipient_agent_id: str) -> Optional[dict]:
        """
        Get an active pairwise channel with the recipient, creating one if needed.

        Returns channel dict with at minimum: id, their_public_key, status.
        Returns None if channel setup fails (caller should fall back to per-transfer).
        """
        # Check in-memory cache first
        cached = self._channel_cache.get(recipient_agent_id)
        if cached and cached.get("status") == "active":
            return cached

        try:
            # List existing channels and find a match
            resp = self._request("GET", "/v1/channels")
            channels = resp.get("channels", [])

            for ch in channels:
                if ch["status"] != "active":
                    continue
                # Check if this channel involves the recipient
                peer_id = None
                their_key = None
                if ch["agent_a_id"] == self.agent_id:
                    peer_id = ch["agent_b_id"]
                    their_key = ch["agent_b_public_key"]
                elif ch["agent_b_id"] == self.agent_id:
                    peer_id = ch["agent_a_id"]
                    their_key = ch["agent_a_public_key"]

                if peer_id == recipient_agent_id and their_key:
                    channel = {
                        "id": ch["id"],
                        "their_public_key": their_key,
                        "status": ch["status"],
                    }
                    self._channel_cache[recipient_agent_id] = channel
                    return channel

            # No active channel found — create one
            create_resp = self._request("POST", "/v1/channels", json={
                "agent_id": self.agent_id,
                "target_agent_id": recipient_agent_id,
            })

            if create_resp.get("status") != "active":
                # Channel is pending (cross-account, needs confirmation from other side)
                # Can't use it yet — fall back to per-transfer
                return None

            channel = {
                "id": create_resp["id"],
                "their_public_key": create_resp["their_public_key"],
                "status": "active",
            }
            self._channel_cache[recipient_agent_id] = channel
            return channel

        except AgentDropError:
            return None

    def _get_channel_by_id(self, channel_id: str) -> Optional[dict]:
        """Fetch a channel by ID. Returns the raw channel data or None."""
        try:
            return self._request("GET", f"/v1/channels/{channel_id}")
        except AgentDropError:
            return None

    # ─── Sending Files ──────────────────────────────────────────

    def send(
        self,
        recipient: str,
        files: list[str],
        message: str = None,
        encrypt: bool = True,
        expires_in: str = "24h",
    ) -> dict:
        """
        Send files to another agent.

        Attempts pairwise channel encryption first (X25519 DH shared secret
        with per-transfer HKDF-derived keys). Falls back to per-transfer
        encryption if channel setup fails.

        Args:
            recipient: The recipient's agent_id.
            files: List of file paths to send.
            message: Optional message.
            encrypt: Whether to encrypt (default True).
            expires_in: Expiry duration (default "24h").

        Returns:
            Transfer response with ID and status.
        """
        if not self.agent_id:
            raise AgentDropError("Agent not connected. Call connect() first.")

        # ── Encryption strategy: try channel first, fall back to per-transfer ──
        channel = None
        shared_secret = None
        transfer_salt = None
        symmetric_key = None
        use_channel = False

        if encrypt and self._keys:
            # Try pairwise channel
            channel = self._get_or_create_channel(recipient)
            if channel and channel.get("their_public_key"):
                try:
                    shared_secret = derive_shared_secret(
                        self._keys.private_key_b64,
                        channel["their_public_key"],
                    )
                    transfer_salt = os.urandom(SALT_BYTES)
                    symmetric_key = derive_transfer_key(shared_secret, transfer_salt)
                    use_channel = True
                except Exception:
                    # DH or HKDF failed — fall back
                    warnings.warn(
                        "Channel key derivation failed, falling back to per-transfer encryption",
                        stacklevel=2,
                    )
                    channel = None
                    shared_secret = None
                    transfer_salt = None
                    symmetric_key = None

            # Fall back to legacy per-transfer encryption
            if not use_channel:
                try:
                    resolve = self._request("GET", f"/v1/agents/resolve?agent_id={recipient}")
                    recipient_pub = resolve.get("public_key")
                    if recipient_pub:
                        symmetric_key = os.urandom(32)
                    else:
                        encrypt = False
                except AgentDropError:
                    encrypt = False

        if encrypt and not symmetric_key:
            encrypt = False

        # ── Build multipart form ──
        form_data = {
            "sender": self.agent_id,
            "recipient": recipient,
            "mode": "agent-to-agent",
            "expires_in": expires_in,
        }

        if message:
            form_data["message"] = message

        if encrypt and symmetric_key and self._keys:
            form_data["is_encrypted"] = "true"

            if use_channel:
                # Channel-based: send channel_id + salt, no encrypted_key needed
                form_data["encryption_algorithm"] = CHANNEL_ALGORITHM
                form_data["channel_id"] = channel["id"]
                form_data["encryption_salt"] = base64.b64encode(transfer_salt).decode()
            else:
                # Legacy per-transfer: encrypt the AES key with recipient's public key
                form_data["encryption_algorithm"] = ALGORITHM
                form_data["encrypted_key"] = encrypt_symmetric_key(
                    symmetric_key, self._keys, recipient_pub
                )

        # ── Prepare files — encrypt if needed ──
        file_tuples = []
        file_nonces = {}
        for file_path in files:
            path = Path(file_path)
            if not path.exists():
                raise AgentDropError(f"File not found: {file_path}")

            data = path.read_bytes()

            if encrypt and symmetric_key:
                ciphertext, nonce = encrypt_file(data, symmetric_key)
                file_nonces[path.name] = base64.b64encode(nonce).decode()
                file_tuples.append(("files", (path.name, ciphertext, "application/octet-stream")))
            else:
                file_tuples.append(("files", (path.name, data, "application/octet-stream")))

        # Include per-file encryption IVs (nonces) so the recipient can decrypt
        if file_nonces:
            # Order must match the file_tuples order
            ordered_nonces = [file_nonces.get(Path(fp).name, "") for fp in files]
            form_data["encryption_ivs"] = json.dumps(ordered_nonces)

        # ── Send the transfer ──
        resp = self._session.post(
            f"{self.api_base}/v1/transfers",
            data=form_data,
            files=file_tuples,
        )

        if resp.status_code >= 400:
            try:
                err = resp.json().get("error", {})
                raise AgentDropError(
                    err.get("message", resp.text),
                    code=err.get("code"),
                    status=resp.status_code,
                )
            except (ValueError, KeyError):
                raise AgentDropError(resp.text, status=resp.status_code)

        return resp.json()

    # ─── Receiving Files ────────────────────────────────────────

    def inbox(self, status: str = "active", limit: int = 50) -> list[Transfer]:
        """
        Check inbox for incoming transfers.

        Args:
            status: Filter by status (default "active").
            limit: Max results (default 50).

        Returns:
            List of Transfer objects.
        """
        if not self.inbox_url and not self.agent_uuid:
            raise AgentDropError("No inbox URL or agent UUID. Call connect() first or provide inbox_url.")

        url = self.inbox_url or f"{self.api_base}/v1/agents/{self.agent_uuid}/inbox"
        data = self._request("GET", url, params={"status": status, "limit": limit})
        return [Transfer(t) for t in data.get("transfers", [])]

    def download(
        self,
        transfer: Transfer,
        output_dir: str = ".",
        sender_public_key: str = None,
    ) -> list[dict]:
        """
        Download, decrypt, and security-scan files from a transfer.

        Supports both pairwise channel encryption (preferred) and legacy
        per-transfer encryption. The method auto-detects which scheme
        was used based on the transfer metadata.

        When Shield is enabled (default), each file is scanned after
        decryption but BEFORE being written to disk.  If a file is
        blocked by Shield, a ``ShieldBlockError`` is raised and the
        file is never persisted.

        Args:
            transfer: Transfer object from inbox().
            output_dir: Directory to save files (default current dir).
            sender_public_key: Sender's public key for decryption
                (auto-resolved if not provided).

        Returns:
            List of dicts, one per file::

                {
                    "path": "/absolute/path/to/file.pdf",
                    "name": "file.pdf",
                    "scan_result": ScanResult | None,
                }

            ``scan_result`` is ``None`` when Shield is disabled.

        Raises:
            ShieldBlockError: If Shield detects a HIGH or CRITICAL
                threat (depending on strictness).
            AgentDropError: On network or decryption failures.
        """
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        # Get download URLs + encryption metadata
        headers = {"Authorization": f"Bearer {self.api_key}"}
        if self.agent_id:
            headers["X-AgentDrop-Agent"] = self.agent_id

        resp = requests.get(
            f"{self.api_base}/v1/transfers/{transfer.id}/download",
            headers=headers,
        )
        if resp.status_code >= 400:
            raise AgentDropError(f"Download failed: {resp.text}", status=resp.status_code)

        download_data = resp.json()

        # ── Derive the file encryption key ──
        symmetric_key = None
        if download_data.get("is_encrypted") and self._keys:
            channel_id = download_data.get("channel_id")
            encryption_salt = download_data.get("encryption_salt")
            encryption_algo = download_data.get("encryption_algorithm", "")

            if channel_id and encryption_salt and CHANNEL_ALGORITHM in encryption_algo:
                # ── Channel-based decryption ──
                # Look up the channel to get the sender's public key
                channel_data = self._get_channel_by_id(channel_id)
                if not channel_data:
                    raise AgentDropError(
                        f"Cannot decrypt: channel {channel_id} not found or inaccessible"
                    )

                # Determine which side we are and get the peer's public key
                their_pub = None
                if channel_data.get("agent_a_id") == self.agent_id:
                    their_pub = channel_data.get("agent_b_public_key")
                elif channel_data.get("agent_b_id") == self.agent_id:
                    their_pub = channel_data.get("agent_a_public_key")

                if not their_pub:
                    raise AgentDropError(
                        "Cannot decrypt: unable to determine peer public key from channel"
                    )

                salt_bytes = base64.b64decode(encryption_salt)
                shared_secret = derive_shared_secret(
                    self._keys.private_key_b64, their_pub
                )
                symmetric_key = derive_transfer_key(shared_secret, salt_bytes)
            else:
                # ── Legacy per-transfer decryption ──
                encrypted_key = download_data.get("encrypted_key")
                if encrypted_key:
                    if not sender_public_key:
                        try:
                            resolve = self._request(
                                "GET",
                                f"/v1/agents/resolve?agent_id={transfer.sender}"
                            )
                            sender_public_key = resolve.get("public_key")
                        except AgentDropError:
                            raise AgentDropError(
                                "Cannot decrypt: unable to resolve sender's public key"
                            )

                    symmetric_key = decrypt_symmetric_key(
                        encrypted_key, self._keys, sender_public_key
                    )

        # ── Download each file ──
        saved = []
        for file_info in download_data.get("files", []):
            file_url = file_info["download_url"]
            file_resp = requests.get(file_url)
            if file_resp.status_code != 200:
                raise AgentDropError(f"File download failed: {file_info['name']}")

            data = file_resp.content

            # Decrypt if needed
            if symmetric_key and file_info.get("encryption_iv"):
                nonce = base64.b64decode(file_info["encryption_iv"])
                data = decrypt_file(data, symmetric_key, nonce)

            # ── Shield scan (post-decrypt, pre-disk) ─────────────
            scan_result: Optional[ScanResult] = None
            filename = file_info["name"]

            if self._shield_enabled and self._shield:
                scan_result = self._shield.scan(data, filename)

                if scan_result.blocked:
                    raise ShieldBlockError(filename, scan_result)

            # Safe to write — either Shield passed or is disabled
            file_path = out / filename
            file_path.write_bytes(data)

            saved.append({
                "path": str(file_path),
                "name": filename,
                "scan_result": scan_result,
            })

        return saved

    # ─── Shield (Manual Scanning) ──────────────────────────────

    def scan(self, data: bytes, filename: str) -> ScanResult:
        """
        Manually scan file bytes through the Shield security pipeline.

        Use this to scan files received through channels other than
        ``download()`` (e.g. HTTP uploads, message attachments, tool
        outputs from other agents).

        Args:
            data: Raw file bytes.
            filename: Original filename including extension.

        Returns:
            ScanResult with threat level, findings, and warnings.

        Raises:
            AgentDropError: If Shield is not enabled on this client.
        """
        if not self._shield_enabled or not self._shield:
            raise AgentDropError(
                "Shield is disabled. Initialize AgentDrop with shield=True to use scan().",
                code="SHIELD_DISABLED",
            )
        return self._shield.scan(data, filename)

    # ─── Polling / Listening ────────────────────────────────────

    def listen(
        self,
        on_transfer: Callable[[Transfer], None],
        interval: int = 30,
        auto_download: bool = False,
        download_dir: str = "./inbox",
    ):
        """
        Start polling inbox for new transfers.

        This runs in a background thread. The callback is called
        for each new transfer. This is a plain HTTP poll — no LLM tokens used.

        Args:
            on_transfer: Callback function called with each new Transfer.
            interval: Seconds between polls (default 30).
            auto_download: Automatically download files (default False).
            download_dir: Where to save auto-downloaded files.
        """
        self._listening = True
        seen_ids = set()

        def _poll():
            while self._listening:
                try:
                    transfers = self.inbox()
                    for t in transfers:
                        if t.id not in seen_ids:
                            seen_ids.add(t.id)
                            if auto_download:
                                try:
                                    t.files_local = self.download(t, download_dir)
                                except Exception:
                                    t.files_local = []
                            on_transfer(t)
                except Exception:
                    pass  # Silent retry on network errors
                time.sleep(interval)

        self._listener_thread = threading.Thread(target=_poll, daemon=True)
        self._listener_thread.start()

    def stop(self):
        """Stop the inbox listener."""
        self._listening = False
        if self._listener_thread:
            self._listener_thread.join(timeout=5)
            self._listener_thread = None
