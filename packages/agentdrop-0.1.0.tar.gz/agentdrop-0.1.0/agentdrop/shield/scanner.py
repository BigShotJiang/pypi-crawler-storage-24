"""
AgentDrop Shield -- Main scanning engine.

Orchestrates the multi-layer scanning pipeline:

    Layer 0:  Resource Guards      (size, zip bombs, depth)
    Layer 1:  Format Validation    (magic bytes, mismatch, polyglot)
    Layer 3:  Text Extraction      (decode, normalize, strip evasion chars)
    Layer 3b: Image Metadata       (PNG/JPEG/SVG text metadata extraction)
    Layer 4:  Injection Detection  (the crown jewel -- regex patterns)
    Layer 4b: Intent Classification (heuristic AI-instruction scoring)
    Layer 5b: Behavioral Tracking  (cross-transfer sender reputation)

Layer 2 (YARA/binary signatures) is a placeholder -- it requires
external YARA rules that ship separately.  The pipeline handles its
absence gracefully.

Usage:
    from agentdrop.shield import Shield, ScanConfig, Strictness

    shield = Shield()                              # default config
    result = shield.scan(file_bytes, "report.pdf")

    if result.blocked:
        quarantine(file_bytes)
    elif result.injection_findings:
        review(result)
    else:
        process(file_bytes)
"""

from __future__ import annotations

import logging
import time
import threading
from typing import Optional

from .models import (
    InjectionFinding,
    ScanConfig,
    ScanResult,
    Strictness,
    ThreatLevel,
    STRICTNESS_THRESHOLDS,
)
from .resource_guard import ResourceGuard
from .format_validator import FormatValidator
from .text_extractor import TextExtractor
from .injection_detector import InjectionDetector
from .intent_classifier import IntentClassifier, IntentClassification
from .behavioral_tracker import BehavioralTracker, BehavioralAssessment

logger = logging.getLogger("agentdrop.shield")


class ShieldError(Exception):
    """Raised when the Shield scanner itself encounters a fatal error."""


class Shield:
    """AgentDrop Shield -- production file security scanner.

    Runs a multi-layer pipeline on raw file bytes and returns a
    composite ``ScanResult`` with a threat level, injection findings,
    warnings, and timing data.

    Thread-safe: the scanner holds no mutable state between calls
    (behavioral tracker is optional shared state with its own lock).

    Args:
        config: Optional ``ScanConfig`` overriding defaults.
        tracker: Optional ``BehavioralTracker`` for cross-transfer analysis.
            If provided, pass ``sender_id`` to ``scan()`` for per-sender
            behavioral tracking and reputation scoring.
    """

    def __init__(
        self,
        config: Optional[ScanConfig] = None,
        tracker: Optional[BehavioralTracker] = None,
    ) -> None:
        self._cfg = config or ScanConfig()
        self._resource_guard = ResourceGuard(self._cfg)
        self._format_validator = FormatValidator(self._cfg)
        self._text_extractor = TextExtractor(self._cfg)
        self._injection_detector = InjectionDetector(self._cfg)
        self._intent_classifier = IntentClassifier()
        self._tracker = tracker

    @property
    def config(self) -> ScanConfig:
        """Active scan configuration (immutable)."""
        return self._cfg

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def scan(
        self,
        data: bytes,
        filename: str,
        sender_id: Optional[str] = None,
    ) -> ScanResult:
        """Scan a file through the full security pipeline.

        Args:
            data: Raw file bytes (post-decryption, pre-LLM).
            filename: Original filename including extension.
            sender_id: Optional sender identifier for behavioral tracking.
                When provided with a BehavioralTracker, enables cross-transfer
                reputation scoring and threat escalation.

        Returns:
            ``ScanResult`` with the composite verdict.

        Raises:
            ShieldError: If the scanner itself fails fatally (not a
                file-level threat -- those are reported in the result).
        """
        t0 = time.monotonic()

        result = ScanResult(
            threat_level=ThreatLevel.CLEAN,
            malware_clean=True,  # Layer 2 placeholder
        )

        try:
            result = self._run_pipeline(data, filename, result, sender_id)
        except Exception as exc:
            logger.error("Shield pipeline error: %s", exc, exc_info=True)
            result.warnings.append(f"Pipeline error: {exc}")
            result.threat_level = max(result.threat_level, ThreatLevel.MEDIUM)

        # Enforce scan timeout -- if we somehow exceeded the limit,
        # flag it but still return what we have.
        elapsed_ms = int((time.monotonic() - t0) * 1000)
        result.scan_time_ms = elapsed_ms

        if elapsed_ms > self._cfg.max_scan_time_seconds * 1000:
            result.warnings.append(
                f"Scan exceeded time limit ({elapsed_ms}ms > "
                f"{int(self._cfg.max_scan_time_seconds * 1000)}ms)"
            )

        # Apply strictness filter to the overall threat level.
        result = self._apply_strictness(result)

        logger.info(
            "Shield scan complete: %s [%s] %dms",
            filename,
            result.threat_level.name,
            result.scan_time_ms,
        )
        return result

    def scan_with_timeout(
        self,
        data: bytes,
        filename: str,
        sender_id: Optional[str] = None,
    ) -> ScanResult:
        """Scan with a hard timeout enforced via a background thread.

        If the scan exceeds ``config.max_scan_time_seconds``, a result
        with a MEDIUM threat level and a timeout warning is returned.
        """
        container: dict = {}
        error_container: dict = {}

        def _worker() -> None:
            try:
                container["result"] = self.scan(data, filename, sender_id)
            except Exception as exc:
                error_container["error"] = exc

        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()
        thread.join(timeout=self._cfg.max_scan_time_seconds)

        if thread.is_alive():
            logger.warning("Shield scan timed out for %s", filename)
            return ScanResult(
                threat_level=ThreatLevel.MEDIUM,
                malware_clean=True,
                warnings=[
                    f"Scan timed out after {self._cfg.max_scan_time_seconds}s "
                    "-- file should be treated with caution"
                ],
                scan_time_ms=int(self._cfg.max_scan_time_seconds * 1000),
            )

        if "error" in error_container:
            raise ShieldError(str(error_container["error"])) from error_container["error"]

        return container["result"]

    # ------------------------------------------------------------------
    # Pipeline
    # ------------------------------------------------------------------

    def _run_pipeline(
        self,
        data: bytes,
        filename: str,
        result: ScanResult,
        sender_id: Optional[str] = None,
    ) -> ScanResult:
        """Execute each layer in sequence, short-circuiting on block."""

        # ── Layer 0: Resource Guards ─────────────────────────────────
        rg = self._resource_guard.check(data, filename)
        result.details["resource_guard"] = {
            "passed": rg.passed,
            "reason": rg.reason,
            **rg.details,
        }
        result.warnings.extend(rg.warnings)

        if not rg.passed:
            result.threat_level = max(result.threat_level, rg.threat_level)
            logger.info(
                "Layer 0 blocked %s: %s", filename, rg.reason
            )
            return result  # Short-circuit

        # ── Layer 1: Format Validation ───────────────────────────────
        fv = self._format_validator.validate(data, filename)
        result.details["format_validation"] = {
            "detected_mime": fv.detected_mime,
            "declared_extension": fv.declared_extension,
            "type_mismatch": fv.type_mismatch,
            "is_polyglot": fv.is_polyglot,
            "parseable_as": fv.parseable_as,
        }
        result.warnings.extend(fv.warnings)
        result.threat_level = max(result.threat_level, fv.threat_level)

        # If polyglot or executable, still continue scanning for more detail
        # but the threat level is already elevated.

        # ── Layer 2: YARA / Binary Signatures (placeholder) ─────────
        # This layer requires external YARA rules.  When integrated,
        # it would run here.  For now we record the placeholder.
        result.details["yara_scan"] = {"status": "not_configured"}

        # ── Layer 3: Text Extraction & Normalization ─────────────────
        te = self._text_extractor.extract(data, filename, fv.detected_mime)
        result.details["text_extraction"] = {
            "sources": te.details.get("sources", 0),
            "total_chars": te.details.get("total_chars", 0),
            "anomaly_count": len(te.anomalies),
        }
        result.warnings.extend(te.warnings)
        result.threat_level = max(result.threat_level, te.threat_level)

        if not te.texts:
            # No text extracted -- nothing for Layer 4 to scan.
            # This is normal for binary files like images.
            # Still run behavioral tracking if available.
            result = self._apply_behavioral_tracking(
                result, sender_id, filename
            )
            return result

        # ── Layer 4: Injection Detection ─────────────────────────────
        findings = self._injection_detector.detect(te.texts)
        result.injection_findings = findings

        if findings:
            max_finding_level = max(f.threat_level for f in findings)
            result.threat_level = max(result.threat_level, max_finding_level)
            result.details["injection_detection"] = {
                "total_findings": len(findings),
                "max_confidence": max(f.confidence for f in findings),
                "max_threat_level": max_finding_level.name,
                "patterns_matched": list({f.pattern_name for f in findings}),
            }
        else:
            result.details["injection_detection"] = {
                "total_findings": 0,
            }

        # ── Layer 4b: Intent Classification ──────────────────────────
        intent = self._intent_classifier.classify(te.texts)
        result.intent_score = intent.intent_score
        result.details["intent_classification"] = {
            "intent_score": intent.intent_score,
            "is_instructive": intent.is_instructive,
            "signals": [
                {"name": s.signal_name, "score": s.score, "detail": s.detail}
                for s in intent.signals
            ],
        }

        # Blend intent score into injection threat level.
        # The intent classifier acts as a 30% weighted sub-score
        # that can elevate the threat level when pattern-based
        # detection alone is borderline.
        if intent.is_instructive and intent.intent_score >= 0.6:
            # If injection findings exist, boost the overall level
            if findings:
                max_injection_conf = max(f.confidence for f in findings)
                blended = max_injection_conf * 0.7 + intent.intent_score * 0.3
                if blended >= 0.8:
                    result.threat_level = max(
                        result.threat_level, ThreatLevel.HIGH
                    )
                elif blended >= 0.5:
                    result.threat_level = max(
                        result.threat_level, ThreatLevel.MEDIUM
                    )
            else:
                # No regex findings but high intent score -- flag as suspicious
                if intent.intent_score >= 0.8:
                    result.threat_level = max(
                        result.threat_level, ThreatLevel.MEDIUM
                    )
                    result.warnings.append(
                        f"Intent classifier flagged as highly instructive "
                        f"(score={intent.intent_score:.2f}) with no pattern match"
                    )
                elif intent.intent_score >= 0.6:
                    result.threat_level = max(
                        result.threat_level, ThreatLevel.LOW
                    )
                    result.warnings.append(
                        f"Intent classifier flagged as moderately instructive "
                        f"(score={intent.intent_score:.2f})"
                    )

        # ── Layer 5b: Behavioral Tracking ────────────────────────────
        result = self._apply_behavioral_tracking(
            result, sender_id, filename
        )

        return result

    # ------------------------------------------------------------------
    # Behavioral tracking helper
    # ------------------------------------------------------------------

    def _apply_behavioral_tracking(
        self,
        result: ScanResult,
        sender_id: Optional[str],
        filename: str,
    ) -> ScanResult:
        """Apply behavioral tracker assessment and record this scan."""
        if not self._tracker or not sender_id:
            return result

        # Assess sender reputation BEFORE recording this scan
        assessment = self._tracker.assess(sender_id)
        result.sender_reputation = assessment.reputation
        result.details["behavioral_tracking"] = {
            "sender_id": sender_id,
            "reputation": assessment.reputation,
            "escalation": assessment.escalation.name,
            "burst_detected": assessment.burst_detected,
            "history_size": assessment.history_size,
            "flags": assessment.flags,
        }

        # Apply escalation
        if assessment.escalation > ThreatLevel.CLEAN:
            result.threat_level = max(
                result.threat_level, assessment.escalation
            )
            result.warnings.extend(assessment.flags)

        # Record this scan for future assessments
        self._tracker.record(
            sender_id=sender_id,
            threat_level=result.threat_level,
            filename=filename,
            injection_count=len(result.injection_findings),
            intent_score=result.intent_score,
        )

        return result

    # ------------------------------------------------------------------
    # Strictness enforcement
    # ------------------------------------------------------------------

    def _apply_strictness(self, result: ScanResult) -> ScanResult:
        """Downgrade threat level if below the strictness threshold.

        In PERMISSIVE mode, a MEDIUM finding is downgraded to CLEAN.
        The findings are still present in the result for inspection,
        but the top-level ``threat_level`` reflects the policy.
        """
        threshold = STRICTNESS_THRESHOLDS[self._cfg.strictness]

        if result.threat_level < threshold:
            # Below threshold -- treat as clean for policy purposes,
            # but keep findings and warnings for auditability.
            result.threat_level = ThreatLevel.CLEAN

        return result
