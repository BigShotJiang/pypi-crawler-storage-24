import{at as r}from"./index-BQyF8Bx-.js";var a=4;function n(o){return r(o,a)}export{n as c};
