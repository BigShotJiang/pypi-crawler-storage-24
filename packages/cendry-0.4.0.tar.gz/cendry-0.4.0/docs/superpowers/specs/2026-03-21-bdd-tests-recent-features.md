# BDD Tests for Recent Features — Spec

## Overview

Add BDD feature files and step definitions for features added after the initial ODM spec: DX improvements (aliases, order_by, limit, paginate, get_many, to_dict, dunder shortcuts, context manager, Query repr), type handler system (register_type with handlers, container handlers, enum conversion), and set/tuple serialization.

## Scope

Unit tests exist for all these features. This spec adds **BDD scenarios** (`tests/features/*.feature` + `tests/test_bdd_*.py`) for user-facing behavior.

## Feature Files to Create

| File | Covers |
|------|--------|
| `tests/features/aliases.feature` | Field aliases in filters, ordering, serialization |
| `tests/features/query_object.feature` | filter(), order_by(), limit(), first(), one(), exists(), count(), paginate() |
| `tests/features/get_many.feature` | Batch fetch, missing IDs |
| `tests/features/serialization.feature` | from_dict, to_dict, by_alias, include_id |
| `tests/features/type_handlers.feature` | register_type with handler, kwargs, container types |
| `tests/features/enums.feature` | Enum fields, by value, by name |

## Approach

Follow existing BDD patterns in `tests/test_bdd_model.py`, `tests/test_bdd_filters.py`, etc. Each feature file gets a corresponding `test_bdd_*.py` step definition file.
