# Firestore Emulator Support — Spec

## Overview

Add support for the Firestore emulator for local development and testing without a real Google Cloud project.

## API

```python
from cendry import Cendry, AsyncCendry

# Explicit
ctx = Cendry(emulator="localhost:8080")
ctx = AsyncCendry(emulator="localhost:8080")

# Via environment variable (standard Firestore SDK behavior)
# FIRESTORE_EMULATOR_HOST=localhost:8080
ctx = Cendry()  # auto-detects emulator
```

## Behavior

- When `emulator=` is set, Cendry creates a Firestore client pointing to the emulator.
- When `FIRESTORE_EMULATOR_HOST` env var is set and no explicit client is provided, the Firestore SDK already connects to the emulator. Cendry doesn't need to do anything extra.
- The emulator parameter is for convenience — it sets the env var and creates the client.

## Testing

With emulator support, integration tests can run against a real (emulated) Firestore:

```python
@pytest.fixture
def ctx():
    with Cendry(emulator="localhost:8080") as ctx:
        yield ctx

def test_save_and_get(ctx):
    city = City(name="SF", state="CA", ...)
    ctx.save(city)
    result = ctx.get(City, city.id)
    assert result.name == "SF"
```

## Topics to brainstorm

- Should Cendry provide a pytest fixture for the emulator?
- Auto-clear emulator data between tests?
- Docker compose integration for CI?
