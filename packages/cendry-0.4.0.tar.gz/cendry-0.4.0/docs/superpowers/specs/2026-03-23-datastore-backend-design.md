# Datastore Backend Support — Design Spec

**Date:** 2026-03-23
**Status:** Approved
**Goal:** Support Firestore in Datastore mode as an alternative backend, enabling users to migrate from Datastore to Native mode using Cendry as the bridge.

## Context

Cendry currently only supports Firestore in Native mode via `google-cloud-firestore`. Users with existing data in Firestore Datastore mode cannot use Cendry without first migrating their database — a one-way, irreversible operation.

By supporting Datastore mode as a backend, users can:

1. Define Cendry models against their existing Datastore data
2. Run their app on the Datastore backend
3. Migrate the database to Native mode (via Google's migration tool)
4. Swap one line of config to switch backends
5. Unlock Native-only features (real-time listeners, collection groups, async, transforms)

### Design principle trade-off

Cendry's design principle is "thin wrapper over Firestore — don't abstract away Firestore's API." This spec deliberately adds an abstraction layer. The justification: enabling migration from Datastore to Native mode is a high-value use case, and the abstraction is bounded (the Backend protocol is the only new interface). Once a user migrates, the Firestore backend is a pass-through — the abstraction cost is near zero at runtime.

## Approach

**Backend Protocol + Adapter Pattern.** Extract all database client interactions into a `Backend` protocol. Create `FirestoreBackend` and `DatastoreBackend` implementations. `Cendry`/`AsyncCendry` delegate to the backend instead of calling `self._client` directly.

Alternatives considered:

- **Subclass Cendry** — rejected due to combinatorial explosion (Cendry, AsyncCendry, Query, AsyncQuery, Batch, AsyncBatch, Txn, AsyncTxn would all need Datastore variants)
- **Adapter mimicking Firestore Client API** — rejected because the Firestore API surface is deep (~10 fake classes needed) and fragile across SDK version changes

### Implementation phasing

To reduce risk:

1. **Phase 1**: Introduce `Backend`/`AsyncBackend` protocols + `FirestoreBackend`/`FirestoreAsyncBackend`. Refactor Cendry to use the protocol. Zero behavior change — all existing tests pass.
2. **Phase 2**: Add `DatastoreBackend` + tests + migration how-to.

This keeps the test suite green throughout and isolates the refactoring from the new backend.

## Async Support

`google-cloud-datastore` (v2.23.0, latest) has **zero async support**. No `AsyncClient`, no `async def` methods, no plans from Google to add it (GitHub issue [#2](https://github.com/googleapis/python-datastore/issues/2) open since 2020).

Therefore:

- `Cendry(backend=DatastoreBackend())` — supported
- `AsyncCendry(backend=DatastoreBackend())` — raises `CendryError("Datastore backend does not support async. Use Cendry (sync) or migrate to Native mode.")`

This is an intentional migration nudge.

## Backend Protocol

### Result types (`src/cendry/backends/types.py`)

```python
@dataclasses.dataclass
class DocResult:
    exists: bool
    doc_id: str
    data: dict[str, Any] | None
    update_time: datetime.datetime | None
    create_time: datetime.datetime | None
    raw: Any  # underlying snapshot/entity, used for cursor pagination

@dataclasses.dataclass
class WriteResult:
    update_time: datetime.datetime | None
```

### `Backend` protocol (`src/cendry/backend.py`)

Sync protocol. Both `FirestoreBackend` and `DatastoreBackend` implement it.

```python
class Backend(Protocol):
    # Collection/doc references
    def get_collection_ref(self, collection: str, parent_collection: str | None, parent_id: str | None) -> Any: ...
    def get_doc_ref(self, col_ref: Any, doc_id: str | None) -> Any: ...
    def doc_ref_id(self, doc_ref: Any) -> str: ...

    # Reads
    def get_doc(self, doc_ref: Any, *, transaction: Any | None = None) -> DocResult: ...
    def get_all(self, doc_refs: list[Any], *, transaction: Any | None = None) -> Iterator[DocResult]: ...

    # Writes — batch/transaction writers use the same methods
    def set_doc(self, doc_ref: Any, data: dict, *, writer: Any | None = None) -> WriteResult: ...
    def create_doc(self, doc_ref: Any, data: dict, *, writer: Any | None = None) -> WriteResult: ...
    def update_doc(self, doc_ref: Any, updates: dict, *, writer: Any | None = None, precondition: Any | None = None) -> WriteResult: ...
    def delete_doc(self, doc_ref: Any, *, writer: Any | None = None, precondition: Any | None = None) -> None: ...

    # Queries
    def query(self, col_ref: Any) -> Any: ...
    def query_group(self, collection: str) -> Any: ...
    def apply_filter(self, query: Any, field: str, op: str, value: Any) -> Any: ...
    def apply_composite(self, query: Any, op: str, filters: list[Any]) -> Any: ...
    def apply_order(self, query: Any, field: str, direction: str) -> Any: ...
    def apply_limit(self, query: Any, n: int) -> Any: ...
    def apply_cursor(self, query: Any, cursor_type: Literal["start_at", "start_after", "end_at", "end_before"], value: Any) -> Any: ...
    def stream(self, query: Any) -> Iterator[DocResult]: ...
    def select_fields(self, query: Any, fields: list[str]) -> Any: ...
    def count(self, query: Any) -> int: ...

    # Batch & Transaction
    def new_batch(self) -> Any: ...
    def new_transaction(self, max_attempts: int, read_only: bool) -> Any: ...
    def commit_batch(self, batch: Any) -> None: ...

    # Listeners
    def on_doc_snapshot(self, doc_ref: Any, callback: Any) -> Any: ...
    def on_query_snapshot(self, query: Any, callback: Any) -> Any: ...

    # Preconditions
    def make_precondition(self, update_time: datetime.datetime) -> Any: ...

    # Lifecycle
    def close(self) -> None: ...
```

**Key protocol design decisions:**

- **`get_doc` has a `transaction` parameter** — needed for transactional reads. Firestore passes it to `doc_ref.get(transaction=txn)`. Datastore passes it to `client.get(key, transaction=txn)`.
- **Write methods have a `writer` parameter** — when `None`, writes go directly to the client. When set, writes go through the batch/transaction writer. This unifies direct writes, batch writes, and transaction writes through the same protocol methods.
- **`apply_composite` takes `list[Any]`** — the `Any` items are Cendry's own `FieldFilterResult`, `And`, `Or` objects. The backend recursively resolves them to native filters. This supports nested composites (`And(Or(...), FieldFilterResult(...))`).
- **`apply_cursor` receives `DocResult.raw`** — for Firestore, this is the raw `DocumentSnapshot`. For Datastore, `DocResult.raw` stores the cursor token obtained from the query iterator (not the entity itself). The `DatastoreBackend.stream()` method is responsible for extracting the cursor from the query iterator and placing it in `DocResult.raw`.
- **`cursor_type` uses `Literal`** — restricted to `"start_at"`, `"start_after"`, `"end_at"`, `"end_before"` to prevent typos.
- **`new_transaction` returns a single object** that serves as both `transaction` (for reads via `get_doc(transaction=...)`) and `writer` (for writes via `set_doc(writer=...)`). In both Firestore and Datastore, the transaction object is also the write batch — this is not an accident but a shared design between both SDKs.
- **`get_all` also accepts `transaction`** — for transactional multi-gets.
- **`make_precondition` replaces `_resolve_precondition`** — precondition construction is now backend-specific. Firestore returns `LastUpdateOption`. Datastore raises `CendryError`.

### `AsyncBackend` protocol (same file)

Mirrors `Backend`. Query-building methods (`apply_filter`, `apply_order`, etc.) remain sync — they just build objects. I/O methods are `async def`: `get_doc`, `get_all`, `set_doc`, `create_doc`, `update_doc`, `delete_doc`, `stream` (returns `AsyncIterator[DocResult]`), `count`, `close`, `commit_batch`.

Only `FirestoreAsyncBackend` implements this. `DatastoreBackend` does not.

## Backend Implementations

### Package layout

```
src/cendry/
├── backend.py           # Backend, AsyncBackend protocols
├── backends/
│   ├── __init__.py      # exports FirestoreBackend, FirestoreAsyncBackend (DatastoreBackend NOT eagerly imported)
│   ├── firestore.py     # FirestoreBackend, FirestoreAsyncBackend
│   ├── datastore.py     # DatastoreBackend
│   └── types.py         # DocResult, WriteResult
├── context.py           # Cendry, AsyncCendry (refactored)
├── ...
```

### `FirestoreBackend` (`src/cendry/backends/firestore.py`)

Thin wrapper around `google.cloud.firestore.Client`. Each method delegates to the Firestore calls currently inline in `context.py`. Example:

```python
class FirestoreBackend:
    def __init__(self, client: Client | None = None):
        self._client = client or Client()

    def get_collection_ref(self, collection, parent_collection, parent_id):
        if parent_collection and parent_id:
            parent_ref = self._client.collection(parent_collection).document(parent_id)
            return parent_ref.collection(collection)
        return self._client.collection(collection)

    def get_doc(self, doc_ref, *, transaction=None):
        doc = doc_ref.get(transaction=transaction)
        return DocResult(
            exists=doc.exists, doc_id=doc.id, data=doc.to_dict(),
            update_time=doc.update_time, create_time=doc.create_time, raw=doc,
        )

    def apply_filter(self, query, field, op, value):
        return query.where(filter=FieldFilter(field, op, value))

    def apply_composite(self, query, op, filters):
        """Recursively resolve Cendry filter objects to Firestore filters."""
        fs_filters = [self._resolve_filter(f) for f in filters]
        cls = FsAnd if op == "AND" else FsOr
        return query.where(filter=cls(filters=fs_filters))

    def make_precondition(self, update_time):
        return LastUpdateOption(update_time)

    # ... each method is 2-5 lines
```

`FirestoreAsyncBackend` mirrors this with `async def` for I/O methods, using `AsyncClient`.

### `DatastoreBackend` (`src/cendry/backends/datastore.py`)

Wraps `google.cloud.datastore.Client`. Key translations:

| Cendry concept | Firestore | Datastore |
|---|---|---|
| Collection ref | `client.collection("cities")` | Kind `"cities"` (stored, used in queries) |
| Doc ref | `col_ref.document("SF")` | `client.key("cities", "SF")` |
| Auto-ID | `col_ref.document()` | `client.allocate_ids(incomplete_key, 1)` |
| Get | `doc_ref.get()` → DocumentSnapshot | `client.get(key)` → Entity |
| Set (upsert) | `doc_ref.set(data)` | `client.put(entity)` |
| Create (insert) | `doc_ref.create(data)` | `client.get(key)` + check + `client.put(entity)` |
| Update | `doc_ref.update(updates)` | `client.get(key)` + merge + `client.put(entity)` |
| Delete | `doc_ref.delete()` | `client.delete(key)` |
| Batch | `client.batch()` → WriteBatch | `client.batch()` → Batch |
| Transaction | `client.transaction()` | `client.transaction()` |
| Query filter | `query.where(filter=FieldFilter(...))` | `query.add_filter(field, op, value)` |
| Query order | `query.order_by(field, direction=)` | `query.order = [field]` or `["-field"]` |
| Query limit | `query.limit(n)` | `query.fetch(limit=n)` |
| Stream | `query.stream()` | `query.fetch()` |
| Projection | `query.select([fields])` | `query.projection = [fields]` |
| Count | `query.count().get()` | `aggregation_query.count()` |
| Parent/ancestor | Subcollection: `doc_ref.collection(...)` | Ancestor key: `client.key("Parent", id, "Child", child_id)` |

#### Unsupported features

These raise `CendryError` with a migration nudge message:

- `query_group()` — "Collection group queries are not supported in Datastore mode. Migrate to Native mode."
- `on_doc_snapshot()` / `on_query_snapshot()` — "Real-time listeners are not supported in Datastore mode. Migrate to Native mode."
- `make_precondition()` — "Optimistic locking (if_unchanged) is not supported in Datastore mode. Migrate to Native mode."
- `apply_composite()` with `op="OR"` — "OR queries are not supported in Datastore mode. Migrate to Native mode."

#### Datastore-specific nuances

- **`create_doc`**: No atomic "create if not exists" in Datastore. Implementation: `client.get(key)` → if exists, raise `DocumentAlreadyExistsError` → else `client.put(entity)`. **This is a TOCTOU race outside transactions.** The migration how-to and API docs must warn users to wrap `create()` calls in transactions on the Datastore backend for safety.
- **`update_doc`**: No partial update in Datastore. Implementation: `client.get(key)` → merge updates → `client.put(entity)`. Same TOCTOU caveat — use transactions for atomicity.
- **Entity ↔ dict**: Datastore `Entity` behaves like a dict. `dict(entity)` extracts data, `entity.update(data)` sets fields. The serialization layer works unchanged.
- **`update_time`/`create_time`**: Not available on Datastore entities. `WriteResult.update_time` and `DocResult.update_time`/`create_time` will be `None`. Metadata tracking has gaps — another migration nudge.
- **Integer key IDs**: Datastore supports both string names and integer IDs for entity keys. Cendry's `Model.id` is `str | None`. Integer IDs are coerced to strings via `str(key.id_or_name)`.
- **`close()`**: `google.cloud.datastore.Client` has no `close()` method. `DatastoreBackend.close()` is a no-op.

## Cendry / AsyncCendry Refactoring

### Constructor changes

```python
class Cendry:
    def __init__(
        self,
        *,
        backend: Backend | None = None,
        client: Client | None = None,       # backward compat
        type_registry: TypeRegistry | None = None,
    ) -> None:
        if backend and client:
            raise CendryError("Cannot specify both backend and client")
        if backend is None:
            backend = FirestoreBackend(client=client)
        self._backend = backend
        self.type_registry = type_registry or default_registry

class AsyncCendry:
    def __init__(
        self,
        *,
        backend: AsyncBackend | None = None,
        client: Any = None,                  # backward compat
        type_registry: TypeRegistry | None = None,
    ) -> None:
        if backend and client:
            raise CendryError("Cannot specify both backend and client")
        if backend is None:
            backend = FirestoreAsyncBackend(client=client)
        self._backend = backend
        self.type_registry = type_registry or default_registry
```

Existing code `Cendry(client=my_client)` still works — wraps in `FirestoreBackend` automatically.

### Method refactoring pattern

All methods replace `self._client.collection(...)` chains with `self._backend.method(...)` calls. ODM logic (deserialization, metadata, validation) stays in Cendry. Example:

```python
# Before
def get(self, model_class, document_id, *, parent=None):
    col_ref = self._get_collection_ref(model_class, parent)
    doc = col_ref.document(document_id).get()
    if not doc.exists: raise DocumentNotFoundError(...)
    result = deserialize(model_class, doc.id, doc.to_dict(), ...)
    _set_metadata(result, update_time=doc.update_time, create_time=doc.create_time)
    return result

# After
def get(self, model_class, document_id, *, parent=None):
    col_ref = self._col_ref(model_class, parent)
    doc_ref = self._backend.get_doc_ref(col_ref, document_id)
    doc = self._backend.get_doc(doc_ref)
    if not doc.exists: raise DocumentNotFoundError(...)
    result = deserialize(model_class, doc.doc_id, doc.data, ...)
    _set_metadata(result, update_time=doc.update_time, create_time=doc.create_time)
    return result
```

### `_BaseCendry` changes

- `_client` → `_backend`
- `_get_collection_ref` → thin helper unpacking `parent` into `parent_collection` + `parent_id`, calls `self._backend.get_collection_ref`
- `_build_query` → calls `self._backend.query()` / `self._backend.query_group()`, applies filters/ordering/limits/cursors via backend methods
- `_apply_filter` → decomposes `FieldFilterResult` / `And` / `Or` into primitives, calls `self._backend.apply_filter` / `self._backend.apply_composite`
- `_resolve_precondition` → replaced by `self._backend.make_precondition()`. The `if_unchanged` logic (look up metadata, extract `update_time`) stays in Cendry; only the `LastUpdateOption` construction moves to the backend.

### Query refactoring

`Query` and `AsyncQuery` receive the backend alongside the opaque query object. The query object (`self._query`) remains backend-specific — Firestore returns a Firestore query, Datastore returns a Datastore query. Each `Query` method delegates to the backend to manipulate it:

```python
# Before
def order_by(self, *orders):
    query = self._query
    for order in orders:
        query = query.order_by(order.field, direction=order.direction)
    return Query(query, ...)

# After
def order_by(self, *orders):
    query = self._query
    for order in orders:
        query = self._backend.apply_order(query, order.field, order.direction)
    return Query(query, self._backend, ...)

# Before
def __iter__(self):
    for doc in self._query.stream():
        instance = deserialize(self._model_class, doc.id, doc.to_dict(), ...)
        yield instance

# After
def __iter__(self):
    for doc in self._backend.stream(self._query):
        instance = deserialize(self._model_class, doc.doc_id, doc.data, ...)
        yield instance
```

`Query.on_snapshot()` delegates to `self._backend.on_query_snapshot()`. `ProjectedQuery` delegates to `self._backend.stream()` and `self._backend.select_fields()`.

Pagination: `Query.paginate()` uses `DocResult.raw` as the cursor value. After iterating a page, the last `DocResult.raw` is passed to `self._backend.apply_cursor(query, "start_after", last_doc.raw)`.

### Batch / Transaction / WritesMixin refactoring

`WritesMixin` currently calls `col_ref.document()` and `self._writer.set(doc_ref, data)` directly. After refactoring:

- `WritesMixin` receives the backend reference
- Doc ref creation goes through `self._backend.get_doc_ref(col_ref, doc_id)`
- Write calls go through `self._backend.set_doc(doc_ref, data, writer=self._writer)`, etc.
- `Txn.get()` calls `self._backend.get_doc(doc_ref, transaction=self._transaction)`

The `writer` parameter lets the backend route writes through the batch/transaction object when present, or directly to the client when `None`.

### Filters refactoring

`_apply_filter` in `_BaseCendry` no longer imports Firestore filter classes (`FsFieldFilter`, `FsAnd`, `FsOr`). Instead:

- `FieldFilterResult` → `self._backend.apply_filter(query, f.field_name, f.op, f.value)`
- `And(filters)` → `self._backend.apply_composite(query, "AND", f.filters)`
- `Or(filters)` → `self._backend.apply_composite(query, "OR", f.filters)`
- Raw `FieldFilter` (Firestore-native, for backward compat) → passed through as-is to the backend

The backend's `apply_composite` receives Cendry's own filter objects and recursively resolves nested composites to native filter types.

### `FieldFilter` import in `filters.py`

Currently `filters.py` re-exports `FieldFilter` from `google.cloud.firestore_v1.base_query`. This creates a hard dependency on `google-cloud-firestore` even for Datastore-only users.

Fix: make the import lazy. `from cendry import FieldFilter` still works (it's a Firestore type), but the module doesn't fail at import time if the user hasn't imported it. Users on Datastore mode use `City.state == "CA"` (which produces `FieldFilterResult`, a Cendry type) and never need `FieldFilter` directly.

## Serialization & Transforms

### `serialize.py` — no changes needed

Already works with plain dicts. `to_dict()` returns `dict[str, Any]`, `deserialize()` takes `dict[str, Any]`, `DocResult.data` is `dict[str, Any]`.

The only Firestore dependency (`_is_firestore_transform`) stays as-is. The Datastore backend never produces or receives transform types. If a user passes `SERVER_TIMESTAMP` to a Datastore backend, the client rejects it.

### `__init__.py` — transforms stay exported

`DELETE_FIELD`, `SERVER_TIMESTAMP`, `ArrayRemove`, `ArrayUnion`, `Increment`, `Maximum`, `Minimum` remain in the public API. Users on Datastore mode simply can't use them.

### `types.py` — edge cases

- `GeoPoint`: Firestore and Datastore have different `GeoPoint` classes. Handle conversion at the backend boundary during implementation.
- `DocumentReference`: Datastore uses `Key` instead. Decide during implementation whether to support or leave unsupported on Datastore.

## Public API & Dependencies

### New exports in `cendry.__init__`

```python
from .backend import Backend, AsyncBackend
from .backends.types import DocResult, WriteResult
from .backends.firestore import FirestoreBackend, FirestoreAsyncBackend
# DatastoreBackend NOT imported here — lazy import only
```

All new public types are added to `__all__`: `Backend`, `AsyncBackend`, `DocResult`, `WriteResult`, `FirestoreBackend`, `FirestoreAsyncBackend`. `DatastoreBackend` is NOT in `__all__` — it's a lazy import from `cendry.backends.datastore`.

Note: `DocumentAlreadyExistsError` is already in the codebase and exported — no new exception needed.

### Optional dependency

```toml
# pyproject.toml
[project.optional-dependencies]
datastore = ["google-cloud-datastore>=2.19"]
```

`DatastoreBackend` import fails with a clear error if `google-cloud-datastore` is not installed. `backends/__init__.py` does **not** eagerly import it. Users import it explicitly:

```python
from cendry.backends.datastore import DatastoreBackend
```

### Backward compatibility

| Current code | After refactor | Works? |
|---|---|---|
| `Cendry()` | Creates `FirestoreBackend()` internally | Yes |
| `Cendry(client=my_client)` | Wraps in `FirestoreBackend(client=my_client)` | Yes |
| `AsyncCendry()` | Creates `FirestoreAsyncBackend()` internally | Yes |
| `AsyncCendry(client=my_client)` | Wraps in `FirestoreAsyncBackend(client=my_client)` | Yes |
| `from cendry import FieldFilter` | Still re-exported | Yes |
| `from cendry import SERVER_TIMESTAMP` | Still re-exported | Yes |

No breaking changes.

## Testing Strategy

### Unit tests

- **`tests/test_firestore_backend.py`** — Tests `FirestoreBackend` and `FirestoreAsyncBackend` by mocking `google.cloud.firestore.Client` / `AsyncClient`. Same mocks as existing tests, targeting backend methods.
- **`tests/test_datastore_backend.py`** — Tests `DatastoreBackend` by mocking `google.cloud.datastore.Client`. Covers CRUD, query building, ancestor keys, batch/transaction, unsupported feature errors, integer key ID coercion.

### Existing tests

Existing `Cendry` / `AsyncCendry` tests continue to work via `client=` backward compat path. They become implicit integration tests for FirestoreBackend + Cendry.

### Integration tests

- Existing Firestore emulator tests unchanged
- **`tests/integration/test_datastore.py`** (new) — same scenarios against Datastore emulator via testcontainers (`google/cloud-sdk:emulators` with `gcloud beta emulators datastore start`)

### Coverage

100% coverage requirement stays. `DatastoreBackend` fully unit-tested with mocks. Integration tests outside coverage scope.

## Documentation

### New page: `docs/how-to/migrate-datastore-to-native.md`

Step-by-step migration guide:

1. **Define models in Cendry** — map existing Kinds to `Model` classes, using Kind names as `collection=`
2. **Validate with Datastore backend** — read existing data, confirm models deserialize
3. **Run app on Datastore backend** — swap data access layer to Cendry
4. **Migrate the database** — use Google's one-way migration tool (Cloud Console)
5. **Switch to Firestore backend** — change `DatastoreBackend()` to `FirestoreBackend()`
6. **Unlock Native-only features** — `on_snapshot`, `select_group`, `AsyncCendry`, transforms, `if_unchanged`

Includes:
- `!!! warning` for the irreversible migration step
- `!!! warning` for `create()` / `update()` TOCTOU race on Datastore — recommend transactions
- `!!! tip` for testing with emulators before migrating production
- `!!! info` for feature differences table (what works on both vs. Native-only)

### Collection naming convention

`collection=` value is used as-is for both Firestore collection name and Datastore Kind. No `kind=` parameter. Users choose their naming convention — the value is the same on both backends.
