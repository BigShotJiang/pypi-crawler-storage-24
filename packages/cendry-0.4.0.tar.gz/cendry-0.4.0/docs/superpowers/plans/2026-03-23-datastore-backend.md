# Datastore Backend Support — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a Backend protocol abstraction so Cendry can support both Firestore Native mode and Firestore Datastore mode, enabling migration from Datastore to Native.

**Architecture:** Extract all direct Firestore client calls into a `Backend`/`AsyncBackend` protocol. `FirestoreBackend` wraps the existing Firestore client. `DatastoreBackend` wraps `google-cloud-datastore`. `Cendry`/`AsyncCendry` delegate to the backend instead of calling `self._client` directly. Backward compatible — `Cendry(client=...)` still works.

**Tech Stack:** Python >= 3.13, google-cloud-firestore >= 2.19, google-cloud-datastore >= 2.19 (optional), pytest, pytest-bdd, anyio, testcontainers

**Spec:** `docs/superpowers/specs/2026-03-23-datastore-backend-design.md`

**Phases:**
- Phase 1 (Tasks 1–8): Introduce protocols + FirestoreBackend, refactor Cendry to use them. Zero behavior change.
- Phase 2 (Tasks 9–13): Add DatastoreBackend + tests + migration how-to + release prep.

**Key decisions (resolved upfront):**
- **Exception handling**: `NotFound` and `Conflict` exception catching moves INTO the backend. `FirestoreBackend.create_doc` catches `Conflict` and raises `DocumentAlreadyExistsError`. `FirestoreBackend.update_doc` catches `NotFound` and raises `DocumentNotFoundError`. Context.py no longer imports or catches these exceptions.
- **AsyncCendry rejection**: `AsyncCendry.__init__` validates that the backend implements `AsyncBackend`. Passing a sync-only `DatastoreBackend` raises `CendryError`.
- **GeoPoint/DocumentReference**: Deferred to a follow-up task. Not in scope for this plan. Document as known limitation.

---

## Phase 1: Backend Protocol + Firestore Backend

### Task 1: Result types and Backend protocols

**Files:**
- Create: `src/cendry/backends/__init__.py`
- Create: `src/cendry/backends/types.py`
- Create: `src/cendry/backend.py`
- Test: `tests/test_backend_types.py`

- [ ] **Step 1: Write tests for DocResult and WriteResult**

```python
# tests/test_backend_types.py
import datetime
from cendry.backends.types import DocResult, WriteResult


def test_doc_result_fields():
    doc = DocResult(
        exists=True,
        doc_id="SF",
        data={"name": "San Francisco"},
        update_time=datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC),
        create_time=datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC),
        raw=None,
    )
    assert doc.exists is True
    assert doc.doc_id == "SF"
    assert doc.data == {"name": "San Francisco"}


def test_doc_result_not_exists():
    doc = DocResult(exists=False, doc_id="NOPE", data=None, update_time=None, create_time=None, raw=None)
    assert doc.exists is False
    assert doc.data is None


def test_write_result():
    wr = WriteResult(update_time=datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC))
    assert wr.update_time is not None


def test_write_result_none():
    wr = WriteResult(update_time=None)
    assert wr.update_time is None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_backend_types.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'cendry.backends'`

- [ ] **Step 3: Create the backends package and types**

```python
# src/cendry/backends/__init__.py
"""Backend implementations for Cendry."""
```

```python
# src/cendry/backends/types.py
"""Result types shared by all backends."""

import dataclasses
import datetime
from typing import Any


@dataclasses.dataclass
class DocResult:
    """Result of reading a document from any backend."""

    exists: bool
    doc_id: str
    data: dict[str, Any] | None
    update_time: datetime.datetime | None
    create_time: datetime.datetime | None
    raw: Any  # underlying snapshot/entity, used for cursor pagination


@dataclasses.dataclass
class WriteResult:
    """Result of writing a document to any backend."""

    update_time: datetime.datetime | None
```

- [ ] **Step 4: Create the Backend and AsyncBackend protocols**

```python
# src/cendry/backend.py
"""Backend protocols for Cendry."""

import datetime
from collections.abc import AsyncIterator, Iterator
from typing import Any, Literal, Protocol

from .backends.types import DocResult, WriteResult


class Backend(Protocol):
    """Sync backend protocol."""

    # Collection/doc references
    def get_collection_ref(
        self, collection: str, parent_collection: str | None, parent_id: str | None
    ) -> Any: ...

    def get_doc_ref(self, col_ref: Any, doc_id: str | None) -> Any: ...

    def doc_ref_id(self, doc_ref: Any) -> str: ...

    # Reads
    def get_doc(self, doc_ref: Any, *, transaction: Any | None = None) -> DocResult: ...

    def get_all(
        self, doc_refs: list[Any], *, transaction: Any | None = None
    ) -> Iterator[DocResult]: ...

    # Writes
    def set_doc(
        self, doc_ref: Any, data: dict[str, Any], *, writer: Any | None = None
    ) -> WriteResult: ...

    def create_doc(
        self, doc_ref: Any, data: dict[str, Any], *, writer: Any | None = None
    ) -> WriteResult: ...

    def update_doc(
        self,
        doc_ref: Any,
        updates: dict[str, Any],
        *,
        writer: Any | None = None,
        precondition: Any | None = None,
    ) -> WriteResult: ...

    def delete_doc(
        self, doc_ref: Any, *, writer: Any | None = None, precondition: Any | None = None
    ) -> None: ...

    # Queries
    def query(self, col_ref: Any) -> Any: ...

    def query_group(self, collection: str) -> Any: ...

    def apply_filter(self, query: Any, field: str, op: str, value: Any) -> Any: ...

    def apply_composite(self, query: Any, op: str, filters: list[Any]) -> Any: ...

    def apply_order(self, query: Any, field: str, direction: str) -> Any: ...

    def apply_limit(self, query: Any, n: int) -> Any: ...

    def apply_cursor(
        self,
        query: Any,
        cursor_type: Literal["start_at", "start_after", "end_at", "end_before"],
        value: Any,
    ) -> Any: ...

    def stream(self, query: Any) -> Iterator[DocResult]: ...

    def select_fields(self, query: Any, fields: list[str]) -> Any: ...

    def count(self, query: Any) -> int: ...

    # Batch & Transaction
    def new_batch(self) -> Any: ...

    def new_transaction(self, max_attempts: int, read_only: bool) -> Any: ...

    def commit_batch(self, batch: Any) -> None: ...

    # Listeners
    def on_doc_snapshot(self, doc_ref: Any, callback: Any) -> Any: ...

    def on_query_snapshot(self, query: Any, callback: Any) -> Any: ...

    # Preconditions
    def make_precondition(self, update_time: datetime.datetime) -> Any: ...

    # Lifecycle
    def close(self) -> None: ...


class AsyncBackend(Protocol):
    """Async backend protocol."""

    # Collection/doc references (sync — just build objects)
    def get_collection_ref(
        self, collection: str, parent_collection: str | None, parent_id: str | None
    ) -> Any: ...

    def get_doc_ref(self, col_ref: Any, doc_id: str | None) -> Any: ...

    def doc_ref_id(self, doc_ref: Any) -> str: ...

    # Reads (async)
    async def get_doc(self, doc_ref: Any, *, transaction: Any | None = None) -> DocResult: ...

    async def get_all(
        self, doc_refs: list[Any], *, transaction: Any | None = None
    ) -> AsyncIterator[DocResult]: ...

    # Writes (async)
    async def set_doc(
        self, doc_ref: Any, data: dict[str, Any], *, writer: Any | None = None
    ) -> WriteResult: ...

    async def create_doc(
        self, doc_ref: Any, data: dict[str, Any], *, writer: Any | None = None
    ) -> WriteResult: ...

    async def update_doc(
        self,
        doc_ref: Any,
        updates: dict[str, Any],
        *,
        writer: Any | None = None,
        precondition: Any | None = None,
    ) -> WriteResult: ...

    async def delete_doc(
        self, doc_ref: Any, *, writer: Any | None = None, precondition: Any | None = None
    ) -> None: ...

    # Queries (sync — just build objects)
    def query(self, col_ref: Any) -> Any: ...

    def query_group(self, collection: str) -> Any: ...

    def apply_filter(self, query: Any, field: str, op: str, value: Any) -> Any: ...

    def apply_composite(self, query: Any, op: str, filters: list[Any]) -> Any: ...

    def apply_order(self, query: Any, field: str, direction: str) -> Any: ...

    def apply_limit(self, query: Any, n: int) -> Any: ...

    def apply_cursor(
        self,
        query: Any,
        cursor_type: Literal["start_at", "start_after", "end_at", "end_before"],
        value: Any,
    ) -> Any: ...

    async def stream(self, query: Any) -> AsyncIterator[DocResult]: ...

    def select_fields(self, query: Any, fields: list[str]) -> Any: ...

    async def count(self, query: Any) -> int: ...

    # Batch & Transaction
    def new_batch(self) -> Any: ...

    def new_transaction(self, max_attempts: int, read_only: bool) -> Any: ...

    async def commit_batch(self, batch: Any) -> None: ...

    # Listeners
    def on_doc_snapshot(self, doc_ref: Any, callback: Any) -> Any: ...

    def on_query_snapshot(self, query: Any, callback: Any) -> Any: ...

    # Preconditions
    def make_precondition(self, update_time: datetime.datetime) -> Any: ...

    # Lifecycle
    async def close(self) -> None: ...
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/test_backend_types.py -v`
Expected: PASS (4 tests)

- [ ] **Step 6: Run full test suite to confirm nothing is broken**

Run: `uv run pytest -q`
Expected: All existing tests pass

- [ ] **Step 7: Run linters and type checkers**

Run: `uv run ruff check src/cendry/backend.py src/cendry/backends/ && uv run ruff format src/cendry/backend.py src/cendry/backends/`
Run: `uv run mypy src/cendry/backend.py src/cendry/backends/ && uv run ty check src/cendry/backend.py src/cendry/backends/`

- [ ] **Step 8: Commit**

```bash
git add src/cendry/backend.py src/cendry/backends/ tests/test_backend_types.py
git commit -m "feat: add Backend/AsyncBackend protocols and result types"
```

---

### Task 2: FirestoreBackend — refs, reads, writes

**Files:**
- Create: `src/cendry/backends/firestore.py`
- Create: `tests/test_firestore_backend.py`

This task implements the sync `FirestoreBackend` class with ref management, read operations, and write operations. Query methods come in Task 3.

- [ ] **Step 1: Write tests for FirestoreBackend ref, read, and write methods**

```python
# tests/test_firestore_backend.py
import datetime
from unittest.mock import MagicMock

import pytest

from cendry.backends.firestore import FirestoreBackend
from cendry.backends.types import DocResult


def _mock_client():
    return MagicMock()


def _mock_doc(doc_id, data, exists=True):
    doc = MagicMock()
    doc.id = doc_id
    doc.exists = exists
    doc.to_dict.return_value = data if exists else None
    doc.update_time = datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC) if exists else None
    doc.create_time = datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC) if exists else None
    return doc


class TestFirestoreBackendRefs:
    def test_get_collection_ref(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        backend.get_collection_ref("cities", None, None)
        client.collection.assert_called_once_with("cities")

    def test_get_collection_ref_with_parent(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        backend.get_collection_ref("neighborhoods", "cities", "SF")
        client.collection.assert_called_once_with("cities")
        client.collection.return_value.document.assert_called_once_with("SF")

    def test_get_doc_ref_with_id(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        col_ref = MagicMock()
        backend.get_doc_ref(col_ref, "SF")
        col_ref.document.assert_called_once_with("SF")

    def test_get_doc_ref_auto_id(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        col_ref = MagicMock()
        backend.get_doc_ref(col_ref, None)
        col_ref.document.assert_called_once_with()

    def test_doc_ref_id(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc_ref = MagicMock()
        doc_ref.id = "SF"
        assert backend.doc_ref_id(doc_ref) == "SF"


class TestFirestoreBackendReads:
    def test_get_doc_exists(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        mock_doc = _mock_doc("SF", {"name": "San Francisco"})
        doc_ref = MagicMock()
        doc_ref.get.return_value = mock_doc

        result = backend.get_doc(doc_ref)
        assert result.exists is True
        assert result.doc_id == "SF"
        assert result.data == {"name": "San Francisco"}
        assert result.raw is mock_doc

    def test_get_doc_not_exists(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        mock_doc = _mock_doc("NOPE", {}, exists=False)
        doc_ref = MagicMock()
        doc_ref.get.return_value = mock_doc

        result = backend.get_doc(doc_ref)
        assert result.exists is False

    def test_get_doc_with_transaction(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        mock_doc = _mock_doc("SF", {"name": "SF"})
        doc_ref = MagicMock()
        doc_ref.get.return_value = mock_doc
        txn = MagicMock()

        backend.get_doc(doc_ref, transaction=txn)
        doc_ref.get.assert_called_once_with(transaction=txn)

    def test_get_all(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc1 = _mock_doc("SF", {"name": "SF"})
        doc2 = _mock_doc("LA", {"name": "LA"})
        client.get_all.return_value = [doc1, doc2]

        results = list(backend.get_all([MagicMock(), MagicMock()]))
        assert len(results) == 2
        assert results[0].doc_id == "SF"
        assert results[1].doc_id == "LA"


class TestFirestoreBackendWrites:
    def test_set_doc(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc_ref = MagicMock()
        mock_write = MagicMock()
        mock_write.update_time = datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC)
        doc_ref.set.return_value = mock_write

        result = backend.set_doc(doc_ref, {"name": "SF"})
        doc_ref.set.assert_called_once_with({"name": "SF"})
        assert result.update_time is not None

    def test_set_doc_with_writer(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc_ref = MagicMock()
        writer = MagicMock()

        backend.set_doc(doc_ref, {"name": "SF"}, writer=writer)
        writer.set.assert_called_once_with(doc_ref, {"name": "SF"})

    def test_create_doc(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc_ref = MagicMock()
        mock_write = MagicMock()
        mock_write.update_time = datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC)
        doc_ref.create.return_value = mock_write

        result = backend.create_doc(doc_ref, {"name": "SF"})
        doc_ref.create.assert_called_once_with({"name": "SF"})

    def test_update_doc(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc_ref = MagicMock()
        mock_write = MagicMock()
        mock_write.update_time = datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC)
        doc_ref.update.return_value = mock_write

        result = backend.update_doc(doc_ref, {"name": "LA"})
        doc_ref.update.assert_called_once_with({"name": "LA"}, option=None)

    def test_update_doc_with_precondition(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc_ref = MagicMock()
        mock_write = MagicMock()
        mock_write.update_time = datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC)
        doc_ref.update.return_value = mock_write
        precond = MagicMock()

        backend.update_doc(doc_ref, {"name": "LA"}, precondition=precond)
        doc_ref.update.assert_called_once_with({"name": "LA"}, option=precond)

    def test_delete_doc(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc_ref = MagicMock()

        backend.delete_doc(doc_ref)
        doc_ref.delete.assert_called_once_with(option=None)

    def test_make_precondition(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        dt = datetime.datetime(2024, 1, 1, tzinfo=datetime.UTC)
        result = backend.make_precondition(dt)
        assert result is not None  # returns LastUpdateOption

    def test_close(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        backend.close()
        client.close.assert_called_once()

    def test_new_batch(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        backend.new_batch()
        client.batch.assert_called_once()

    def test_commit_batch(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        batch = MagicMock()
        backend.commit_batch(batch)
        batch.commit.assert_called_once()

    def test_new_transaction(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        backend.new_transaction(max_attempts=5, read_only=False)
        client.transaction.assert_called_once_with(max_attempts=5, read_only=False)


class TestFirestoreBackendExceptionTranslation:
    def test_create_doc_conflict_raises_already_exists(self):
        from google.cloud.exceptions import Conflict
        from cendry import DocumentAlreadyExistsError

        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc_ref = MagicMock()
        doc_ref.id = "SF"
        doc_ref.create.side_effect = Conflict("exists")

        with pytest.raises(DocumentAlreadyExistsError):
            backend.create_doc(doc_ref, {"name": "SF"})

    def test_update_doc_not_found_raises_doc_not_found(self):
        from google.api_core.exceptions import NotFound
        from cendry import DocumentNotFoundError

        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc_ref = MagicMock()
        doc_ref.update.side_effect = NotFound("gone")

        with pytest.raises(DocumentNotFoundError):
            backend.update_doc(doc_ref, {"name": "LA"})
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_firestore_backend.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'cendry.backends.firestore'`

- [ ] **Step 3: Implement FirestoreBackend — refs, reads, writes, lifecycle**

Create `src/cendry/backends/firestore.py` with:
- `__init__(self, client=None)` — wraps `google.cloud.firestore.Client`
- `get_collection_ref`, `get_doc_ref`, `doc_ref_id` — ref management
- `get_doc`, `get_all` — reads, wrapping snapshots into `DocResult`
- `set_doc`, `create_doc`, `update_doc`, `delete_doc` — writes with `writer` parameter
- `make_precondition` — returns `LastUpdateOption`
- `new_batch`, `commit_batch`, `new_transaction` — batch/txn creation
- `close` — delegates to client
- Query methods as stubs (implemented in Task 3)
- Listener methods as stubs (implemented in Task 3)

Each method should be 2-5 lines, delegating to the Firestore client. See the spec for exact signatures.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_firestore_backend.py -v`
Expected: PASS

- [ ] **Step 5: Run full test suite**

Run: `uv run pytest -q`
Expected: All existing tests still pass

- [ ] **Step 6: Lint and format**

Run: `uv run ruff check src/cendry/backends/firestore.py tests/test_firestore_backend.py && uv run ruff format src/cendry/backends/firestore.py tests/test_firestore_backend.py`

- [ ] **Step 7: Commit**

```bash
git add src/cendry/backends/firestore.py tests/test_firestore_backend.py
git commit -m "feat: add FirestoreBackend — refs, reads, writes, lifecycle"
```

---

### Task 3: FirestoreBackend — queries, filters, listeners

**Files:**
- Modify: `src/cendry/backends/firestore.py`
- Modify: `tests/test_firestore_backend.py`

- [ ] **Step 1: Write tests for query, filter, and listener methods**

Add to `tests/test_firestore_backend.py`:

```python
class TestFirestoreBackendQueries:
    def test_query(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        col_ref = MagicMock()
        # query() just returns the collection ref itself (it IS the base query in Firestore)
        result = backend.query(col_ref)
        assert result is col_ref

    def test_query_group(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        backend.query_group("cities")
        client.collection_group.assert_called_once_with("cities")

    def test_apply_filter(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        backend.apply_filter(query, "state", "==", "CA")
        query.where.assert_called_once()

    def test_apply_order(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        backend.apply_order(query, "population", "DESCENDING")
        query.order_by.assert_called_once_with("population", direction="DESCENDING")

    def test_apply_limit(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        backend.apply_limit(query, 10)
        query.limit.assert_called_once_with(10)

    def test_apply_cursor_start_after(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        cursor = MagicMock()
        backend.apply_cursor(query, "start_after", cursor)
        query.start_after.assert_called_once_with(cursor)

    def test_apply_cursor_start_at(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        cursor = MagicMock()
        backend.apply_cursor(query, "start_at", cursor)
        query.start_at.assert_called_once_with(cursor)

    def test_apply_cursor_end_before(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        cursor = MagicMock()
        backend.apply_cursor(query, "end_before", cursor)
        query.end_before.assert_called_once_with(cursor)

    def test_apply_cursor_end_at(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        cursor = MagicMock()
        backend.apply_cursor(query, "end_at", cursor)
        query.end_at.assert_called_once_with(cursor)

    def test_stream(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc1 = _mock_doc("SF", {"name": "SF"})
        doc2 = _mock_doc("LA", {"name": "LA"})
        query = MagicMock()
        query.stream.return_value = [doc1, doc2]

        results = list(backend.stream(query))
        assert len(results) == 2
        assert results[0].doc_id == "SF"

    def test_select_fields(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        backend.select_fields(query, ["name", "state"])
        query.select.assert_called_once_with(["name", "state"])

    def test_count(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        agg_result = MagicMock()
        agg_result.value = 42
        query.count.return_value.get.return_value = [[agg_result]]

        assert backend.count(query) == 42

    def test_on_doc_snapshot(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        doc_ref = MagicMock()
        callback = MagicMock()
        backend.on_doc_snapshot(doc_ref, callback)
        doc_ref.on_snapshot.assert_called_once_with(callback)

    def test_on_query_snapshot(self):
        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        callback = MagicMock()
        backend.on_query_snapshot(query, callback)
        query.on_snapshot.assert_called_once_with(callback)

    def test_apply_composite_and(self):
        from cendry.model import FieldFilterResult

        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        filters = [
            FieldFilterResult("state", "==", "CA"),
            FieldFilterResult("population", ">", 100000),
        ]
        backend.apply_composite(query, "AND", filters)
        query.where.assert_called_once()

    def test_apply_composite_nested(self):
        from cendry import And, Or
        from cendry.model import FieldFilterResult

        client = _mock_client()
        backend = FirestoreBackend(client=client)
        query = MagicMock()
        nested = And(
            Or(FieldFilterResult("state", "==", "CA"), FieldFilterResult("state", "==", "NY")),
            FieldFilterResult("population", ">", 100000),
        )
        backend.apply_composite(query, "AND", list(nested.filters))
        query.where.assert_called_once()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_firestore_backend.py::TestFirestoreBackendQueries -v`
Expected: FAIL — methods not implemented

- [ ] **Step 3: Implement query, filter, and listener methods**

Add to `FirestoreBackend` in `src/cendry/backends/firestore.py`:
- `query(col_ref)` — returns `col_ref` (it IS the base query)
- `query_group(collection)` — `self._client.collection_group(collection)`
- `apply_filter(query, field, op, value)` — `query.where(filter=FieldFilter(field, op, value))`
- `apply_composite(query, op, filters)` — recursively resolve Cendry filters to Firestore `And`/`Or`
- `apply_order(query, field, direction)` — `query.order_by(field, direction=direction)`
- `apply_limit(query, n)` — `query.limit(n)`
- `apply_cursor(query, cursor_type, value)` — dispatch to `query.start_at/start_after/end_at/end_before`
- `stream(query)` — iterate `query.stream()`, yield `DocResult`
- `select_fields(query, fields)` — `query.select(fields)`
- `count(query)` — `query.count().get()`, extract int
- `on_doc_snapshot(doc_ref, callback)` — `doc_ref.on_snapshot(callback)`
- `on_query_snapshot(query, callback)` — `query.on_snapshot(callback)`

For `apply_composite`, add a private `_resolve_filter` method that handles recursive nesting of `FieldFilterResult`, `And`, `Or` into Firestore's native filter types.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_firestore_backend.py -v`
Expected: All PASS

- [ ] **Step 5: Lint, format, full suite**

Run: `uv run ruff check src/cendry/backends/firestore.py && uv run ruff format src/cendry/backends/firestore.py && uv run pytest -q`

- [ ] **Step 6: Commit**

```bash
git add src/cendry/backends/firestore.py tests/test_firestore_backend.py
git commit -m "feat: add FirestoreBackend — queries, filters, listeners"
```

---

### Task 4: FirestoreAsyncBackend

**Files:**
- Modify: `src/cendry/backends/firestore.py`
- Modify: `tests/test_firestore_backend.py`

- [ ] **Step 1: Write tests for FirestoreAsyncBackend**

Add async test class to `tests/test_firestore_backend.py`. Mirror the sync tests but use `async def`, `AsyncMock`, and `await`. Key methods to test: `get_doc`, `get_all`, `set_doc`, `create_doc`, `update_doc`, `delete_doc`, `stream`, `count`, `close`, `commit_batch`. Sync query-building methods (`apply_filter`, `apply_order`, etc.) reuse the same logic, test a few to confirm.

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_firestore_backend.py -k "Async" -v`
Expected: FAIL

- [ ] **Step 3: Implement FirestoreAsyncBackend**

Add `FirestoreAsyncBackend` to `src/cendry/backends/firestore.py`. It wraps `google.cloud.firestore.AsyncClient`. Query-building methods are identical to `FirestoreBackend` (consider a shared mixin or base class for `apply_filter`, `apply_order`, etc.). I/O methods use `async def` and `await`.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_firestore_backend.py -v`
Expected: All PASS

- [ ] **Step 5: Lint, format, full suite**

Run: `uv run ruff check src/cendry/backends/firestore.py && uv run ruff format src/cendry/backends/firestore.py && uv run pytest -q`

- [ ] **Step 6: Commit**

```bash
git add src/cendry/backends/firestore.py tests/test_firestore_backend.py
git commit -m "feat: add FirestoreAsyncBackend"
```

---

### Task 5: Refactor context.py — _BaseCendry, Cendry constructor, reads

**Files:**
- Modify: `src/cendry/context.py`
- Modify: `tests/test_context.py` (if needed — existing tests should pass via backward compat)

This is the core refactoring. Change `_BaseCendry` to use `self._backend` instead of `self._client`. Refactor `Cendry.__init__` to accept `backend=`. Refactor read methods (`get`, `find`, `get_many`). Refactor `_get_collection_ref`, `_build_query`, `_apply_filter`, `_resolve_precondition`.

- [ ] **Step 1: Refactor Cendry constructor and _BaseCendry**

In `src/cendry/context.py`:
- Add `from .backend import AsyncBackend, Backend` import
- Add `from .backends.firestore import FirestoreAsyncBackend, FirestoreBackend` import
- Change `_BaseCendry._client` to `_backend`
- Replace `_get_collection_ref` to unpack `parent` into `parent_collection` + `parent_id` and call `self._backend.get_collection_ref`
- Replace `_build_query` to use `self._backend.query()`, `self._backend.query_group()`, `self._backend.apply_filter`, `self._backend.apply_order`, `self._backend.apply_limit`, `self._backend.apply_cursor`
- Replace `_apply_filter` to decompose `FieldFilterResult` → `self._backend.apply_filter(query, f.field_name, f.op, f.value)`, `And` → `self._backend.apply_composite(query, "AND", f.filters)`, `Or` → `self._backend.apply_composite(query, "OR", f.filters)`
- Replace `_resolve_precondition` to use `self._backend.make_precondition(update_time)` instead of `LastUpdateOption`
- Update `Cendry.__init__` to accept `backend=` with backward compat `client=`
- Update `__enter__`/`__exit__` to use `self._backend.close()`

- [ ] **Step 2: Refactor Cendry read methods**

Refactor `get`, `find`, `get_many` to use:
- `self._backend.get_doc_ref(col_ref, doc_id)` instead of `col_ref.document(doc_id)`
- `self._backend.get_doc(doc_ref)` instead of `doc_ref.get()`
- `doc.doc_id`, `doc.data`, `doc.update_time`, `doc.create_time` instead of `doc.id`, `doc.to_dict()`, etc.
- `self._backend.get_all(doc_refs)` instead of `self._client.get_all(doc_refs)`

- [ ] **Step 3: Run existing tests to verify backward compat**

Run: `uv run pytest tests/test_context.py -v`
Expected: All existing tests pass (they use `client=` which wraps in FirestoreBackend)

Note: Some tests may need minor mock adjustments since the call chain changes slightly (e.g., `client.collection` now called inside `FirestoreBackend`). Fix as needed.

- [ ] **Step 4: Run full test suite**

Run: `uv run pytest -q`
Expected: All pass

- [ ] **Step 5: Lint, format, and type check**

Run: `uv run ruff check src/cendry/context.py && uv run ruff format src/cendry/context.py`
Run: `uv run mypy src/cendry/ tests/ && uv run ty check src/cendry/ tests/`

- [ ] **Step 6: Commit**

```bash
git add src/cendry/context.py
git commit -m "refactor: Cendry uses Backend protocol — constructor, reads"
```

---

### Task 6: Refactor context.py — Cendry writes, delete, update, refresh, listeners, batch, transaction

**Files:**
- Modify: `src/cendry/context.py`

- [ ] **Step 1: Refactor Cendry write methods**

Refactor `save`, `create`, `delete`, `update`, `refresh` to use backend methods:
- `self._backend.get_doc_ref(col_ref, doc_id)` for doc refs
- `self._backend.set_doc(doc_ref, data)` for save
- `self._backend.create_doc(doc_ref, data)` for create
- `self._backend.update_doc(doc_ref, updates, precondition=option)` for update
- `self._backend.delete_doc(doc_ref, precondition=option)` for delete
- `self._backend.make_precondition(update_time)` instead of `LastUpdateOption`

- [ ] **Step 2: Refactor on_snapshot, batch, transaction, save_many, delete_many**

- `on_snapshot` → use `self._backend.on_doc_snapshot(doc_ref, wrapper_callback)`
- `batch()` → use `self._backend.new_batch()`, pass backend to `Batch`
- `transaction()` → use `self._backend.new_transaction(...)`, pass backend to `Txn`
- `save_many`, `delete_many` — no changes needed (they delegate to `batch()`)

- [ ] **Step 3: Refactor AsyncCendry similarly**

Same pattern: `AsyncCendry.__init__` accepts `backend=`, defaults to `FirestoreAsyncBackend`. All methods use `self._backend` with `await` where needed.

- [ ] **Step 4: Remove unused Firestore imports from context.py**

Remove direct imports of `Client`, `FsFieldFilter`, `FsAnd`, `FsOr`, `LastUpdateOption`, `NotFound`, `Conflict` from `context.py`. These now live in `FirestoreBackend`.

Exception handling has moved to the backend (decided upfront — see Key Decisions above):
- `Cendry.create()` no longer catches `Conflict` — `FirestoreBackend.create_doc` catches it and raises `DocumentAlreadyExistsError`
- `Cendry.update()` no longer catches `NotFound` — `FirestoreBackend.update_doc` catches it and raises `DocumentNotFoundError`

- [ ] **Step 4b: Add AsyncCendry backend validation**

In `AsyncCendry.__init__`, after resolving the backend, validate it is not a sync-only backend:

```python
if not isinstance(backend, AsyncBackend):
    raise CendryError(
        "Datastore backend does not support async. "
        "Use Cendry (sync) or migrate to Native mode."
    )
```

Note: Since `AsyncBackend` is a `Protocol`, use `runtime_checkable` or duck-type check (e.g., check for `async` methods). The exact mechanism should match Python 3.13 protocol checking conventions.

- [ ] **Step 5: Run all tests**

Run: `uv run pytest -q`
Expected: All pass

- [ ] **Step 6: Lint and format**

Run: `uv run ruff check src/cendry/context.py && uv run ruff format src/cendry/context.py`

- [ ] **Step 7: Commit**

```bash
git add src/cendry/context.py
git commit -m "refactor: Cendry uses Backend protocol — writes, batch, transaction"
```

---

### Task 7: Refactor query.py, _writes.py, batch.py, transaction.py

**Files:**
- Modify: `src/cendry/query.py`
- Modify: `src/cendry/_writes.py`
- Modify: `src/cendry/batch.py`
- Modify: `src/cendry/transaction.py`

- [ ] **Step 1: Refactor Query and AsyncQuery**

`Query.__init__` receives the backend. Change:
- `__iter__` → `self._backend.stream(self._query)` instead of `self._query.stream()`
- `filter()` → `self._backend.apply_filter(...)` instead of `self._apply_filter(...)`
- `order_by()` → `self._backend.apply_order(query, field, direction)` instead of `query.order_by(...)`
- `limit()` → `self._backend.apply_limit(query, n)` instead of `query.limit(n)`
- `project()` → `self._backend.select_fields(query, paths)`, wrap in `ProjectedQuery` with backend
- `count()` → `self._backend.count(self._query)`
- `paginate()` → use `self._backend.apply_cursor(query, "start_after", last_doc.raw)`
- `on_snapshot()` → `self._backend.on_query_snapshot(self._query, wrapper)`
- `first()`, `one()` → use `self._backend.apply_limit()`

Same changes for `AsyncQuery` (with `async`).

Refactor `ProjectedQuery` and `AsyncProjectedQuery` to receive the backend and use `self._backend.stream()` and `self._backend.apply_limit()`.

- [ ] **Step 2: Refactor WritesMixin**

In `src/cendry/_writes.py`, `WritesMixin` needs the backend:
- Add `_backend` attribute
- `save` → `self._backend.get_doc_ref(col_ref, doc_id)` and `self._backend.set_doc(doc_ref, data, writer=self._writer)`
- `create` → `self._backend.create_doc(doc_ref, data, writer=self._writer)`
- `update` → `self._backend.update_doc(doc_ref, resolved, writer=self._writer)`
- `delete` → `self._backend.delete_doc(doc_ref, writer=self._writer)`
- `doc_ref.id` → `self._backend.doc_ref_id(doc_ref)`

- [ ] **Step 3: Refactor Batch, AsyncBatch**

In `src/cendry/batch.py`:
- `Batch.__init__` receives the backend alongside the writer
- `commit` → `self._backend.commit_batch(self._writer)` instead of `self._writer.commit()`
- Same for `AsyncBatch` with `await`

- [ ] **Step 4: Refactor Txn, AsyncTxn**

In `src/cendry/transaction.py`:
- `Txn.__init__` receives the backend
- `Txn.get()` → `self._backend.get_doc(doc_ref, transaction=self._transaction)` instead of `doc_ref.get(transaction=...)`
- Transaction lifecycle (`_begin`, `_commit`, `_rollback`) stays as direct calls on the transaction object (these are standard across backends)
- Same for `AsyncTxn`

- [ ] **Step 5: Run all tests**

Run: `uv run pytest -q`
Expected: All pass. Some existing tests may need mock adjustments.

- [ ] **Step 6: Lint and format**

Run: `uv run ruff check src/cendry/query.py src/cendry/_writes.py src/cendry/batch.py src/cendry/transaction.py && uv run ruff format src/cendry/query.py src/cendry/_writes.py src/cendry/batch.py src/cendry/transaction.py`

- [ ] **Step 7: Commit**

```bash
git add src/cendry/query.py src/cendry/_writes.py src/cendry/batch.py src/cendry/transaction.py
git commit -m "refactor: Query, WritesMixin, Batch, Txn use Backend protocol"
```

---

### Task 8: Update __init__.py, filters.py, public API, coverage check

**Files:**
- Modify: `src/cendry/__init__.py`
- Modify: `src/cendry/filters.py`
- Modify: `src/cendry/backends/__init__.py`
- Modify: `tests/test_public_api.py`

- [ ] **Step 1: Update `__init__.py` exports**

Add to `src/cendry/__init__.py`:
```python
from .backend import AsyncBackend, Backend
from .backends.firestore import FirestoreAsyncBackend, FirestoreBackend
from .backends.types import DocResult, WriteResult
```

Add to `__all__`: `"AsyncBackend"`, `"Backend"`, `"DocResult"`, `"FirestoreAsyncBackend"`, `"FirestoreBackend"`, `"WriteResult"`.

- [ ] **Step 2: Make FieldFilter import lazy in filters.py**

Change `src/cendry/filters.py` line 1 from:
```python
from google.cloud.firestore_v1.base_query import FieldFilter as FieldFilter
```
to a lazy import pattern so the module doesn't fail if `google-cloud-firestore` is not the only backend.

Note: Since `google-cloud-firestore` is still a required dependency (not optional), this is a future-proofing step. For now, the import can stay but should be documented as a known coupling point.

- [ ] **Step 3: Update backends/__init__.py**

```python
from .firestore import FirestoreAsyncBackend, FirestoreBackend
from .types import DocResult, WriteResult

__all__ = [
    "DocResult",
    "FirestoreAsyncBackend",
    "FirestoreBackend",
    "WriteResult",
]
```

- [ ] **Step 4: Update test_public_api.py if it exists**

Check `tests/test_public_api.py` — if it validates `__all__`, add the new exports.

- [ ] **Step 5: Run full test suite + coverage**

Run: `uv run coverage run -m pytest && uv run coverage report --show-missing`
Expected: 100% coverage, all tests pass

- [ ] **Step 6: Run mypy and ty**

Run: `uv run mypy src/cendry/ tests/ && uv run ty check src/cendry/ tests/`
Expected: Both pass

- [ ] **Step 7: Run ruff**

Run: `uv run ruff check src/ tests/ && uv run ruff format src/ tests/`

- [ ] **Step 8: Commit**

```bash
git add src/cendry/__init__.py src/cendry/filters.py src/cendry/backends/__init__.py tests/test_public_api.py
git commit -m "feat: export Backend protocol types in public API"
```

---

## Phase 2: Datastore Backend

### Task 9: Add optional dependency and DatastoreBackend — refs, reads, writes

**Files:**
- Modify: `pyproject.toml`
- Create: `src/cendry/backends/datastore.py`
- Create: `tests/test_datastore_backend.py`

- [ ] **Step 1: Add optional dependency to pyproject.toml**

```toml
[project.optional-dependencies]
datastore = ["google-cloud-datastore>=2.19"]
```

Also add `google-cloud-datastore` to `[dependency-groups] dev` for testing.

- [ ] **Step 2: Install the dependency**

Run: `uv sync`

- [ ] **Step 3: Write tests for DatastoreBackend — refs, reads, writes, unsupported features**

Create `tests/test_datastore_backend.py` with tests for:
- `get_collection_ref` — returns a tuple/object representing (kind, ancestor_key)
- `get_collection_ref` with parent — builds ancestor key
- `get_doc_ref` — creates a `Key` via `client.key(kind, doc_id)`
- `get_doc_ref` with `None` — allocates ID via `client.allocate_ids`
- `doc_ref_id` — returns `str(key.id_or_name)`
- `get_doc` — calls `client.get(key)`, returns `DocResult` with `update_time=None`, `create_time=None`
- `get_doc` returns `exists=False` when `client.get` returns `None`
- `get_all` — calls `client.get_multi(keys)`
- `set_doc` — creates Entity, calls `client.put(entity)`
- `create_doc` — checks existence first, raises `DocumentAlreadyExistsError` if exists
- `update_doc` — fetches entity, merges, puts
- `delete_doc` — calls `client.delete(key)`
- `close` — no-op
- Unsupported features raise `CendryError`:
  - `query_group`
  - `on_doc_snapshot`
  - `on_query_snapshot`
  - `make_precondition`
  - `apply_composite` with `op="OR"`
- Integer key ID coercion to string

- [ ] **Step 4: Run tests to verify they fail**

Run: `uv run pytest tests/test_datastore_backend.py -v`
Expected: FAIL

- [ ] **Step 5: Implement DatastoreBackend**

Create `src/cendry/backends/datastore.py`. The module starts with a try/import guard:
```python
try:
    from google.cloud import datastore
except ImportError as e:
    raise ImportError(
        "google-cloud-datastore is required for DatastoreBackend. "
        "Install it with: pip install cendry[datastore]"
    ) from e
```

Implement all `Backend` protocol methods per the translation table in the spec.

- [ ] **Step 6: Run tests to verify they pass**

Run: `uv run pytest tests/test_datastore_backend.py -v`
Expected: All PASS

- [ ] **Step 7: Run full suite + coverage**

Run: `uv run coverage run -m pytest && uv run coverage report --show-missing`
Expected: 100% coverage

- [ ] **Step 8: Lint, format, type check**

Run: `uv run ruff check src/cendry/backends/datastore.py tests/test_datastore_backend.py && uv run ruff format src/cendry/backends/datastore.py tests/test_datastore_backend.py`

- [ ] **Step 9: Commit**

```bash
git add pyproject.toml src/cendry/backends/datastore.py tests/test_datastore_backend.py
git commit -m "feat: add DatastoreBackend — refs, reads, writes"
```

---

### Task 10: DatastoreBackend — queries and filters

**Files:**
- Modify: `src/cendry/backends/datastore.py`
- Modify: `tests/test_datastore_backend.py`

- [ ] **Step 1: Write tests for Datastore query methods**

Tests for:
- `query(col_ref)` — creates `client.query(kind=...)`
- `apply_filter` — calls `query.add_filter(field, op, value)`
- `apply_composite` with `op="AND"` — applies multiple filters sequentially
- `apply_composite` with `op="OR"` — raises `CendryError`
- `apply_order` with `ASCENDING` — appends field to `query.order`
- `apply_order` with `DESCENDING` — appends `-field` to `query.order`
- `apply_limit` — stores limit for `query.fetch(limit=n)`
- `stream` — iterates `query.fetch()`, yields `DocResult` with cursor in `raw`
- `select_fields` — sets `query.projection`
- `count` — uses `aggregation_query.count()`
- `apply_cursor` — uses `start_cursor`/`end_cursor` from Datastore

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_datastore_backend.py -k "query" -v`
Expected: FAIL

- [ ] **Step 3: Implement query methods**

Note: Datastore queries work differently from Firestore:
- `query.add_filter(field, op, value)` instead of `query.where(filter=...)`
- `query.order = ["field"]` or `["-field"]` instead of `query.order_by(field, direction=...)`
- `query.fetch(limit=n)` returns an iterator, not a stream
- Pagination uses `start_cursor` / `end_cursor` from the fetch result iterator
- Projection uses `query.projection = [fields]`

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_datastore_backend.py -v`
Expected: All PASS

- [ ] **Step 5: Full suite + coverage**

Run: `uv run coverage run -m pytest && uv run coverage report --show-missing`

- [ ] **Step 6: Commit**

```bash
git add src/cendry/backends/datastore.py tests/test_datastore_backend.py
git commit -m "feat: add DatastoreBackend — queries and filters"
```

---

### Task 11: DatastoreBackend — batch, transaction, end-to-end test with Cendry

**Files:**
- Modify: `src/cendry/backends/datastore.py`
- Modify: `tests/test_datastore_backend.py`

- [ ] **Step 1: Write tests for batch and transaction**

Tests for:
- `new_batch` — `client.batch()`
- `commit_batch` — `batch.commit()`
- `new_transaction` — `client.transaction()`
- `get_doc` with `transaction=` parameter
- Transactional reads and writes via `writer=` parameter

- [ ] **Step 2: Write end-to-end test using Cendry with DatastoreBackend**

```python
def test_cendry_with_datastore_backend():
    """End-to-end: Cendry(backend=DatastoreBackend(...)) can get/save/select."""
    mock_ds_client = MagicMock()
    # Set up mocks for a full get() flow
    # ...
    backend = DatastoreBackend(client=mock_ds_client)
    ctx = Cendry(backend=backend)
    # Test ctx.get, ctx.save, ctx.select work through the backend
```

Also test that `AsyncCendry(backend=DatastoreBackend(...))` raises `CendryError`.

- [ ] **Step 3: Run tests, implement, iterate**

Run: `uv run pytest tests/test_datastore_backend.py -v`
Fix until all pass.

- [ ] **Step 4: Full suite + coverage**

Run: `uv run coverage run -m pytest && uv run coverage report --show-missing`
Expected: 100% coverage

- [ ] **Step 5: Type check**

Run: `uv run mypy src/cendry/ tests/ && uv run ty check src/cendry/ tests/`

- [ ] **Step 6: Commit**

```bash
git add src/cendry/backends/datastore.py tests/test_datastore_backend.py
git commit -m "feat: DatastoreBackend — batch, transaction, end-to-end"
```

---

### Task 12: Migration how-to documentation

**Files:**
- Create: `docs/how-to/migrate-datastore-to-native.md`
- Modify: `docs/how-to/index.md`
- Modify: `mkdocs.yml` (add nav entry)

- [ ] **Step 1: Write the migration how-to**

Create `docs/how-to/migrate-datastore-to-native.md` following the outline in the spec:

1. Prerequisites (GCP project, `pip install cendry[datastore]`, Docker)
2. Define models — map Kinds to `Model` classes
3. Validate with DatastoreBackend — read existing data
4. Run app on DatastoreBackend
5. Migrate database (Google's Cloud Console tool)
6. Switch to FirestoreBackend — one-line change
7. Unlock Native-only features

Include admonitions:
- `!!! warning` for irreversible migration
- `!!! warning` for `create()`/`update()` TOCTOU race — recommend transactions
- `!!! tip` for testing with emulators first
- `!!! info` for feature differences table

- [ ] **Step 2: Add to docs/how-to/index.md**

Add a link to the new page in the index.

- [ ] **Step 3: Add nav entry to mkdocs.yml**

Add under `How-To Guides` section.

- [ ] **Step 4: Build docs**

Run: `uv run zensical build --strict`
Expected: Builds with no warnings

- [ ] **Step 5: Commit**

```bash
git add docs/how-to/migrate-datastore-to-native.md docs/how-to/index.md mkdocs.yml
git commit -m "docs: add migration guide — Datastore to Native mode"
```

---

### Task 13: Release prep — CHANGELOG, version bump, API reference docs

**Files:**
- Modify: `CHANGELOG.md`
- Modify: `pyproject.toml` (version bump)
- Create: `docs/reference/backends.md` (if using mkdocstrings for new types)

- [ ] **Step 1: Update CHANGELOG.md**

Add a new `## [Unreleased]` section (or version section) with:
```markdown
### Added
- Backend protocol (`Backend`, `AsyncBackend`) for pluggable database backends
- `FirestoreBackend` and `FirestoreAsyncBackend` — explicit Firestore backend classes
- `DatastoreBackend` — support for Firestore in Datastore mode (`pip install cendry[datastore]`)
- `DocResult` and `WriteResult` result types
- Migration guide: How to migrate from Datastore to Native mode

### Changed
- `Cendry` and `AsyncCendry` now accept `backend=` parameter (backward compatible — `client=` still works)
```

- [ ] **Step 2: Bump version in pyproject.toml**

Bump version from `0.2.0` to `0.3.0` (new feature).

- [ ] **Step 3: Add API reference docs for new types (if needed)**

If the project uses mkdocstrings auto-generated reference pages, create `docs/reference/backends.md` with `::: cendry.backend.Backend` and `::: cendry.backends.types.DocResult` directives. Add to `mkdocs.yml` nav.

- [ ] **Step 4: Build docs**

Run: `uv run zensical build --strict`
Expected: No warnings

- [ ] **Step 5: Commit**

```bash
git add CHANGELOG.md pyproject.toml docs/reference/backends.md mkdocs.yml
git commit -m "chore: prepare v0.3.0 release — CHANGELOG, version bump, API docs"
```

---

## Final Verification

After all tasks are complete:

- [ ] `uv run pytest -q` — all tests pass
- [ ] `uv run coverage run -m pytest && uv run coverage report --show-missing` — 100% coverage
- [ ] `uv run mypy src/cendry/ tests/` — passes
- [ ] `uv run ty check src/cendry/ tests/` — passes
- [ ] `uv run ruff check src/ tests/` — clean
- [ ] `uv run ruff format --check src/ tests/` — formatted
- [ ] `uv run zensical build --strict` — docs build clean
- [ ] Existing `Cendry(client=...)` code works without changes (backward compat)
- [ ] `Cendry(backend=DatastoreBackend(...))` works for CRUD + queries
- [ ] `AsyncCendry(backend=DatastoreBackend(...))` raises `CendryError`
