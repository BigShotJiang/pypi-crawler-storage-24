TREE_HTML_TEMPLATE = """
<div id="{tree_id}" style="width: 100%; height: {height}px; overflow: hidden;">
    <script>
        (function() {{
            const loadD3 = (callback) => {{
                if (window.d3) return callback(window.d3);
                const script = document.createElement("script");
                script.src = "https://d3js.org/d3.v7.min.js";
                script.onload = () => callback(window.d3);
                document.head.appendChild(script);
            }};

            loadD3((d3) => {{
                const data = {tree_data};
                const width = {width};
                const height = {height};
                const nodeW = {node_width};
                const nodeH = 150;
                const rx = {node_radius};

                const container = d3.select("#{tree_id}");
                container.selectAll("svg").remove(); // Clean up for re-runs

                const svg = container.append("svg")
                    .attr("width", "100%")
                    .attr("height", "100%")
                    .attr("viewBox", `0 0 ${{width}} ${{height}}`)
                    .call(d3.zoom().on("zoom", (e) => g.attr("transform", e.transform)));

                const g = svg.append("g");
                const tree = d3.tree().nodeSize([nodeW + 40, nodeH]);
                const root = d3.hierarchy(data);
                tree(root);

                // Dynamic calculation for centering
                const initialTransform = d3.zoomIdentity.translate(width/2, 60).scale(0.9);
                svg.call(d3.zoom().transform, initialTransform);
                g.attr("transform", initialTransform);

                // Draw Links
                g.selectAll(".link")
                    .data(root.links())
                    .join("path")
                    .attr("fill", "none")
                    .attr("stroke", "{edge_colour}")
                    .attr("stroke-width", {edge_width})
                    .attr("d", d3.linkVertical().x(d => d.x).y(d => d.y));

                // Create Nodes
                const node = g.selectAll(".node")
                    .data(root.descendants())
                    .join("g")
                    .attr("transform", d => `translate(${{d.x}},${{d.y}})`);

                // Calculate attributes to display (excluding structural keys)
                const getAttrs = (d) => Object.entries(d.data)
                    .filter(([k]) => !['name', 'children'{attr_to_ignore}].includes(k));

                // Node Background
                node.append("rect")
                    .attr("x", -nodeW / 2)
                    .attr("y", d => -20)
                    .attr("width", nodeW)
                    .attr("height", d => 40 + (getAttrs(d).length * 15))
                    .attr("rx", rx)
                    .style("fill", d => d.data.{node_colour_attr} || "{node_colour}")
                    .style("stroke", d => d.data.{border_colour_attr} || "{border_colour}")
                    .style("stroke-width", d => d.data.{border_width_attr} || "{border_width}px");

                // Node Title (Name)
                node.append("text")
                    .attr("dy", "3")
                    .attr("text-anchor", "middle")
                    .style("font-family", "sans-serif")
                    .style("font-weight", "bold")
                    .style("font-size", "{font_title_size}px")
                    .style("fill", d => d.data.{font_colour_attr} || "{font_colour}")
                    .text(d => d.data.name);

                // Dynamic Attributes (Loop through anything else)
                node.each(function(d) {{
                    const attrs = getAttrs(d);
                    const el = d3.select(this);
                    attrs.forEach(([key, val], i) => {{
                        el.append("text")
                            .attr("dy", 20 + (i * 15))
                            .attr("text-anchor", "middle")
                            .style("font-family", "monospace")
                            .style("font-size", "{font_size}px")
                            .style("fill", d.data.{font_colour_attr} || "{font_colour}")
                            .text(`${{key}}: ${{val}}`);
                    }});
                }});
            }});
        }})();
    </script>
</div>
"""
