#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author: Benjamin Vial
# This file is part of gyptis
# Version: 1.2.0
# License: MIT
# See the documentation at gyptis.gitlab.io
"""
Information about the package.
"""

import importlib.metadata as metadata
from email.utils import parseaddr

try:
    data = metadata.metadata("gyptis")
    __version__ = metadata.version("gyptis")
    __author__, _ = parseaddr(data.get("Author-Email"))
    __description__ = data.get("summary")
except Exception:
    __version__ = "unknown"
    __author__ = "unknown"
    __description__ = "unknown"

__name__ = "gyptis"
