"""Short-term memory abstractions."""
