# eTAIL Marketplaces SDK

Welcome to the documentation for the `etail-marketplaces-sdk`.

This is a unified Python SDK for eCommerce marketplace and aggregator APIs. Its core purpose is to provide a single, consistent interface to **fetch, normalise, and sink** data streams across multiple platforms.

## Key Features

- **Unified Interface**: One way to fetch orders, stock, catalogue, etc., regardless of the underlying platform.
- **Aggregators & Marketplaces**: Support for Lengow, ShoppingFeed, ChannelEngine, ManoMano, Mirakl.
- **Built-in Sinks**: Write data directly to Supabase, PostgreSQL, or BigQuery.
- **Idempotent**: All sink connectors use upsert semantics so pipelines can be safely re-run.
- **Traceability**: Every canonical model stores the unmodified platform payload in a `raw` field.
- **Tested**: CI runs **pytest** over mapper and small client tests (mocked HTTP). Run `uv run pytest` locally after installing dev dependencies; see **Architecture** and the repo **CONTRIBUTING.md**.
- **Auditable mappings**: Every stream has a companion CSV table in `docs/field_mappings/` documenting the exact raw API field path → canonical model field for each platform.

## Field Mapping Tables

Cross-platform field mapping tables live in `docs/field_mappings/` and cover every stream supported by the SDK:

| File | Stream | Platforms |
|---|---|---|
| `orders.csv` | `Order` — header fields | Lengow, ShoppingFeed, CE (shipments + orders API), Mirakl, ManoMano |
| `order_items.csv` | `OrderItem` — line fields | Lengow, ShoppingFeed, CE (shipments + orders API), Mirakl, ManoMano |
| `catalogue.csv` | `Product` — catalogue fields | Lengow, ShoppingFeed, ChannelEngine, Mirakl |
| `stock.csv` | `StockLevel` — stock fields | ShoppingFeed, ChannelEngine, Mirakl |
| `shipments.csv` | `Shipment` — shipment fields | ChannelEngine only |
| `invoices.csv` | `Invoice` + `InvoiceItem` fields | Lengow, ShoppingFeed, CE (shipments + orders API), Mirakl, ManoMano |

Each row maps one canonical model field to its raw source path per platform, with a `notes` column explaining derivation logic, fallbacks, and known caveats (e.g. Lengow `amount` is a line total, not a unit price; ChannelEngine `Phone`/`Email` are at the order root, not inside the address block).

## Quick Install

```bash
pip install etail-marketplaces-sdk
```

With optional sinks:
```bash
pip install "etail-marketplaces-sdk[supabase]"
pip install "etail-marketplaces-sdk[postgres]"
pip install "etail-marketplaces-sdk[bigquery]"
pip install "etail-marketplaces-sdk[all]"
```
