import os
import sys
import json
from datetime import datetime
from enum import Enum
from typing import Callable
import logging

logger = logging.getLogger("profiler")
stdout = logging.StreamHandler()
stdout.setFormatter(logging.Formatter("%(asctime)s - %(process)d - %(message)s"))
stdout.setStream(sys.stdout)
logger.addHandler(stdout)
logger.setLevel(logging.INFO)


class ProfilerAction(Enum):
    NONE = 0
    WARMUP = 1
    RECORD = 2
    RECORD_AND_SAVE = 3

def schedule(
    *, durations: list[tuple[int, int]], steps: list[tuple[int, int]] 
) -> Callable:
    start_time = None
    cnt = 0
    prev_action = ProfilerAction.NONE
    def schedule_fn(step: int) -> ProfilerAction:
        assert step >= 0
        if steps and len(steps) > 0:
            for start, end in steps:
                if step == start - 1:
                    return ProfilerAction.WARMUP
                elif step >= start and step < end:
                    return ProfilerAction.RECORD
                elif step == end:
                    return ProfilerAction.RECORD_AND_SAVE
            return ProfilerAction.NONE
        if durations and len(durations) > 0:
            nonlocal start_time, cnt, prev_action
            now = datetime.now().timestamp()
            if step == 0:
                start_time = now
                prev_action = ProfilerAction.NONE
                return ProfilerAction.NONE
            if cnt >= len(durations):
                return None
            if start_time is None:
                start_time = now
            delay, duration = durations[cnt]
            if now - start_time < delay:
                prev_action = ProfilerAction.WARMUP
                return ProfilerAction.WARMUP
            elif now - start_time < delay + duration:
                prev_action = ProfilerAction.RECORD
                return ProfilerAction.RECORD
            elif prev_action == ProfilerAction.RECORD:
                prev_action = ProfilerAction.RECORD_AND_SAVE
                return ProfilerAction.RECORD_AND_SAVE
            elif prev_action == ProfilerAction.RECORD_AND_SAVE:
                start_time = None
                cnt += 1
                prev_action = ProfilerAction.NONE
                return ProfilerAction.NONE
        return ProfilerAction.NONE
    return schedule_fn

class Config:
    def __init__(self, 
                 steps:list[tuple[int, int]]=None,
                 durations:list[tuple[int, int]]=None,
                 ranks:list[int]=None,
                 profiler_args: dict[str, str]=None,
                 nsys:bool=False,
                 tccl:bool=False, 
                 local_path:str="/mnt/data/profiler",
                 cos_path:str=None,
                 report_prefix:str=None):
        if cos_path:
            assert cos_path.startswith("cos://"), "cos_path must be cos://"
        if steps:
            for step in steps:
                assert len(step) == 2, "step must be valid"
                assert step[0] > 0 and step[1] > 0, "step must be greater than 0"
                assert step[0] < step[1], "step must be valid"
            # sort steps by start step
            steps.sort(key=lambda x: x[0])
            # check steps has overlap
            for i in range(len(steps) - 1):
                assert steps[i][1] < steps[i + 1][0], "step must not overlap"
        if durations:
            for duration in durations:
                assert len(duration) == 2, "duration must be valid"
                assert duration[0] >= 0 and duration[1] > 0, "duration must be greater than 0"
        self.steps = steps
        self.durations = durations
        self.ranks = ranks
        self.profiler_args = profiler_args
        if profiler_args is None:
            self.profiler_args = {}
        self.nsys = nsys
        self.tccl = tccl
        self.local_path = local_path
        self.cos_path = cos_path
        self.report_prefix = report_prefix
        if self.report_prefix is None:
            node_name = os.getenv("NODE_NAME")
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            if node_name:
                self.report_prefix = f"profile_{node_name}.{timestamp}"
            else:
                self.report_prefix = f"profile.{timestamp}"

    def __str__(self):
        return f"Config(steps={self.steps}, durations={self.durations}, ranks={self.ranks}, nsys={self.nsys}, tccl={self.tccl})"

    def __repr__(self):
        return self.__str__()
    
def load_config_from_file() -> Config:
    config_file = os.getenv("TI_PROFILER_CONFIG")
    if config_file is None:
        config_file = "/etc/tiprofiler.json"
    if os.path.exists(config_file):
        with open(config_file, "r") as f:
            config = Config(**json.load(f))
            if config.steps:
                config.steps = [tuple(item) for item in config.steps]
            if config.durations:
                config.durations = [tuple(item) for item in config.durations]
            return config
    return Config()

class Profiler:
    def __init__(self):
        config = load_config_from_file()
        if config.ranks and len(config.ranks) > 0 and int(os.getenv("RANK", 0)) not in config.ranks:
            return

        self.config = config
        self.initialized = False
        self.cur_step = 0
        self.profiler = None
        self.curr_action = ProfilerAction.NONE
        self.action_map = {}
        self.nvtx_action = {}
        self._enter_step = None
        self._exit_step = None

        import torch.optim.optimizer as optim
        optim.register_optimizer_step_post_hook(self.step)


    def _init_nsys(self, cuprof):
        self.profiler = cuprof.profiler
        def _nvtx_range_push(name):
            self.nvtx_action[name] = cuprof.nvtx.range_start(name)
        def _nvtx_range_pop(name):
            nvtx_id = self.nvtx_action.get(name)
            if nvtx_id is not None:
                cuprof.nvtx.range_end(nvtx_id)
                del self.nvtx_action[name]
        self._enter_step = _nvtx_range_push
        self._exit_step = _nvtx_range_pop

    def _init_torch(self, torchprof):
        def wrapper_schedule(step: int):
            if self.curr_action:
                return torchprof.ProfilerAction(self.curr_action.value)
            else:
                return None
        
        worker_name = f"{self.config.report_prefix}.{os.getenv('RANK', '0')}"
        trace_ready = torchprof.tensorboard_trace_handler(dir_name=self.config.local_path, worker_name=worker_name)
        def wrapper_trace_ready(prof):
            trace_ready(prof)
            self._save_report_file()
        activities = [torchprof.ProfilerActivity.CPU, torchprof.ProfilerActivity.CUDA]
        profiler_args = {
            "record_shapes": True,
            "with_stack": True,
        }
        if self.config.profiler_args:
            activities_str = self.config.profiler_args.get("activities", None)
            if activities_str:
                activities = [torchprof.ProfilerActivity[act.strip().upper()] for act in activities_str.split(",")]
            for key in ["record_shapes", "with_stack", "profile_memory", "with_flops", "with_modules", "acc_events"]:
                if key in self.config.profiler_args:
                    profiler_args[key] = bool(self.config.profiler_args[key])
        
        logger.info(f"torch profiler with parameters: {profiler_args}")
        self.profiler = torchprof.profile(activities=activities,
                                        schedule=wrapper_schedule,
                                        on_trace_ready=wrapper_trace_ready,
                                        **profiler_args) 
    def lazy_init(self):
        if self.initialized:
            return
        logger.info(f"rank {os.getenv('RANK', '-1')} starting profiling")

        self._update_env()
        os.makedirs(self.config.local_path, exist_ok=True)

        self.action_map: dict[
            tuple[ProfilerAction, ProfilerAction], list[any]
        ] = {
            # key is (prev_action, current_action), value is action list corresponding to the state pair.
            (ProfilerAction.NONE, ProfilerAction.RECORD): [self._start_trace],
            (ProfilerAction.NONE, ProfilerAction.RECORD_AND_SAVE): [self._start_trace],
            (ProfilerAction.WARMUP, ProfilerAction.RECORD): [self._start_trace],
            (ProfilerAction.WARMUP, ProfilerAction.RECORD_AND_SAVE): [self._start_trace],
            (ProfilerAction.RECORD_AND_SAVE, ProfilerAction.NONE): [self._stop_trace],
            (ProfilerAction.RECORD_AND_SAVE, ProfilerAction.WARMUP): [self._stop_trace],
            (ProfilerAction.RECORD_AND_SAVE, ProfilerAction.RECORD): [
                self._stop_trace,
                self._start_trace,
            ],
            (ProfilerAction.RECORD_AND_SAVE, ProfilerAction.RECORD_AND_SAVE): [
                self._stop_trace,
                self._start_trace,
            ],
            (ProfilerAction.RECORD, None): [self._stop_trace],
            (ProfilerAction.RECORD_AND_SAVE, None): [self._stop_trace],
        }
        self.schedule = schedule(durations=self.config.durations, steps=self.config.steps)
        import torch
        if self.config.nsys:
            self._init_nsys(torch.cuda)
        else:
            self._init_torch(torch.profiler)

        torch.profiler.tensorboard_trace_handler
        self.initialized = True
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()

    def stop(self):
        if self.profiler is None:
            return
        self.profiler.stop()
        if self.config.nsys:
            self._save_report_file()
        self.profiler = None

    def step(self, optimizer, args, kwargs):
        self.lazy_init()
        if self.profiler is None:
            return

        if self._exit_step is not None:
            self._exit_step(f"{optimizer.__class__.__name__}.step{self.cur_step}")

        self.cur_step += 1

        if self.schedule:
            prev_action = self.curr_action
            self.curr_action = self.schedule(self.cur_step)
            for action in self.action_map.get((prev_action, self.curr_action), []):
                action()

            if hasattr(self.profiler, "step"):
                self.profiler.step()

        if self._enter_step is not None:
            self._enter_step(f"{optimizer.__class__.__name__}.step{self.cur_step}")

    def _start_trace(self):
        logger.info(f"start profiler at step {self.cur_step}")
        if self.config.nsys:
            self.profiler.start()

    def _stop_trace(self):
        logger.info(f"stop profiler at step {self.cur_step}")
        if self.config.nsys:
            self.profiler.stop()
            self._save_report_file()
    
    def _update_env(self):
        if os.getenv("NCCL_DEBUG_SUBSYS") is None:
            os.environ['NCCL_DEBUG_SUBSYS'] = 'INIT,ENV,NET,BOOTSTRAP,GRAPH,PROFILE,INSPECTOR'
        else:
            os.environ['NCCL_DEBUG_SUBSYS'] = os.getenv('NCCL_DEBUG_SUBSYS') + ',INIT,ENV,NET,BOOTSTRAP,GRAPH,PROFILE,INSPECTOR'
        os.environ['NCCL_DEBUG_FILE'] = f'{self.config.local_path}/nccl-%p.log'
        os.environ['NCCL_TOPO_AFFINITY'] = '1'
        os.environ['NVSHMEM_NVTX'] = 'common'
        os.environ['NCCL_DEBUG'] = 'INFO'
        os.environ['NCCL_SET_THREAD_NAME'] = '1'
        os.environ['LOGLEVEL'] = 'INFO'
        os.environ['TORCH_CPP_LOG_LEVEL'] = 'INFO'
        if os.getenv("RANK", "0") == "0":
            self._dump_relevant_env_vars()

    def _dump_relevant_env_vars(self):
        relevant_env_vars = [
            "PYTHONPATH",
            "NODE_NAME",
            "NSYS_ENABLED",
            "TCCL_ENABLED",
            "LD_AUDIT",
            "LD_PRELOAD",
            "PYTHONPATH",
            "GPU_NUM_PER_NODE",
            "RANK",
            "LOCAL_RANK",
            "WORLD_SIZE",
            "MASTER_PORT",
            "MASTER_ADDR",
            "CUDA_VISIBLE_DEVICES",
            "GLOO_SOCKET_IFNAME",
            "GLOO_DEVICE_TRANSPORT",
            "TORCH_NCCL_BLOCKING_WAIT",
            "TORCH_NCCL_ASYNC_ERROR_HANDLING",
        ]
        for var in relevant_env_vars:
            if var in os.environ:
                logger.info(f"env:{var}={os.environ[var]}")
        for var in os.environ:
            if var.startswith("NCCL"):
                logger.info(f"env:{var}={os.environ[var]}")
    
    def _save_report_file(self):
        if self.config.cos_path is None:
            return
        if os.getenv("LOCAL_RANK", "0") != "0":
            logger.info("only local rank 0 will upload to cos")
            return
        cred = None
        try:
            cred = self._get_temporary_secret_and_token()
        except Exception as e:
            logger.error(f"failed to get temporary access token for cos: {e}")
            return
        region = None
        for r in ["REGION", "TI_REGION"]:
            if r in os.environ:
                region = os.environ[r]
                break
        if region is None:
            logger.error("failed to upload to cos: unknown region")
            return
        
        from qcloud_cos import CosConfig
        from qcloud_cos import CosS3Client
        from qcloud_cos.cos_threadpool import SimpleThreadPool
        config = CosConfig(Region=region, SecretId=cred[0], SecretKey=cred[1], Token=cred[2], Scheme='https')
        client = CosS3Client(config)

        cos_info = self.config.cos_path.replace("cos://", "").split("/", 1)
        bucket = cos_info[0]
        cos_dir = cos_info[1] if len(cos_info) > 1 else ""
        g = os.walk(self.config.local_path)
        pool = SimpleThreadPool(16)
        files = []
        for path, _, file_list in g:
            for file_name in file_list:
                if file_name.startswith(self.config.report_prefix):
                    localFilePath = os.path.join(path, file_name) # 本地文件路径名
                    files.append(localFilePath)
                    cosObjectKey =  os.path.join(cos_dir, file_name)      # 以本地文件路径名作为 COS 对象名
                    pool.add_task(client.upload_file, bucket, cosObjectKey, localFilePath)
                    # get file size
                    file_size = os.path.getsize(localFilePath)
                    logger.info(f"found profiler report file: {localFilePath} (size: {file_size/1024/1024:.2f} MB)")
        pool.wait_completion()
        result = pool.get_result()
        if not result['success_all']:
            logger.error(f"failed to upload to cos: {result}")
        else:
            logger.info(f"successfully upload report file to cos: {files}")
            for file in files:
                os.remove(file)

    def _get_temporary_secret_and_token(self):
        import requests
        if "QCLOUD_CONTAINER_INSTANCE_CREDENTIALS_URL" not in os.environ:
            raise Exception("QCLOUD_CONTAINER_INSTANCE_CREDENTIALS_URL environment not exist")
        cred_url = os.environ["QCLOUD_CONTAINER_INSTANCE_CREDENTIALS_URL"]
        response = requests.get(cred_url)
        resp_json = response.json()
        if resp_json.get("Code", "") != "Success":
            raise Exception(f"failed to get credential info: {resp_json}")
        return [
            resp_json.get("TmpSecretId", None),
            resp_json.get("TmpSecretKey", None),
            resp_json.get("Token", None),
        ]
