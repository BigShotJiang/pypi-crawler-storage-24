#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# @File: hook.py
# @Author: will
# @Date: 2026-01-12

ti_prof=None
def hook():
    global ti_prof
    if ti_prof is not None:
        return
    from tiprofiler.profiler import Profiler
    ti_prof = Profiler()

hook()