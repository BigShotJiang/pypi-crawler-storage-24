#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# @File: command.py
# @Author: will
# @Date: 2026-01-12

"""
TI Profiler CLI - Command line interface for tiprofiler package

This module implements the tiprof command line tool for easy profiling
of PyTorch training scripts without code modification.
"""

import argparse
import sys
import os
import json
import logging
import importlib.resources
from datetime import datetime
import tiprofiler

logger = logging.getLogger("profiler")

def create_parser() -> argparse.ArgumentParser:
    """
    Create and configure the main argument parser for tiprof CLI.
    
    Returns:
        argparse.ArgumentParser: Configured argument parser
    """
    parser = argparse.ArgumentParser(
        prog='tiprof',
        description='TI Profiler - PyTorch training profiler with CUDA, NVTX, and NCCL support',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Profile specific steps
  tiprof --steps 10-15,20-25 python train.py
  
  # Profile with Nsight Systems
  tiprof --nsys true python train.py
  
  # Profile specific ranks in distributed training
  tiprof --ranks 0,1,2 python train.py
  
  # Save output to specific location
  tiprof --output file:///path/to/output python train.py
  
  # Upload to Tencent Cloud COS
  tiprof --output cos://bucket/path python train.py

For more information, visit: https://github.com/your-org/ti-profiler
        """
    )
    
    # Global options
    parser.add_argument(
        '--version',
        action='version',
        version=f'tiprof {tiprofiler.__version__}',
        help='Show version information and exit'
    )
    
    # Profiling options
    parser.add_argument(
        '--steps',
        type=str,
        default=None,
        metavar='RANGES',
        help='Step ranges to profile, first value is start step, seconds value is end step (e.g., "10-15,20-25"). steps and durations are mutually exclusive.'
    )
    
    parser.add_argument(
        '--durations',
        type=str,
        default=None,
        metavar='RANGES',
        help='Duration ranges to profile, first value is delay, second value is duration (e.g., "30-60,90-120"). steps and durations are mutually exclusive.'
    )
    
    parser.add_argument(
        '--ranks',
        type=str,
        default=None,
        metavar='RANKS',
        help='Comma-separated list of ranks to profile (e.g., "0,1,2"). Default: all ranks'
    )
    
    parser.add_argument(
        '--nsys',
        type=str,
        choices=['true', 'false'],
        default='false',
        metavar='BOOL',
        help='Enable/disable Nsight Systems profiling (true/false). Default: false'
    )
    
    parser.add_argument(
        '--tccl',
        action='store_true',
        help='Enable TCCL (NCCL enhanced version) support'
    )
    
    parser.add_argument(
        '--output',
        type=str,
        default="file:///mnt/data/profiler",
        metavar='URI',
        help='Output location (file:///path or cos://bucket/path). Default: file:///mnt/data/profiler'
    )
    
    parser.add_argument(
        '--profiler-args',
        type=str,
        default=None,
        metavar='ARGS',
        help='Additional arguments to pass to the profiler. Default: None'
    )

    # User command (positional, captures everything after options)
    parser.add_argument(
        'command',
        nargs=argparse.REMAINDER,
        help='User command to execute with profiling'
    )
    
    return parser


def parse_steps(steps_str: str) -> list[tuple[int, int]]:
    """
    Parse step ranges string into list of (start, end) tuples.
    
    Args:
        steps_str: Step ranges string (e.g., "10-15,20-25")
        
    Returns:
        List of (start, end) tuples
        
    Raises:
        ValidationError: If format is invalid
    """
    if not steps_str:
        return []
    
    ranges = []
    for range_str in steps_str.split(','):
        range_str = range_str.strip()
        if '-' in range_str:
            start, end = range_str.split('-', 1)
            start, end = int(start.strip()), int(end.strip())
            assert start <= end, f"Invalid range: {range_str} (start > end)"
            ranges.append((start, end))
        else:
            step = int(range_str)
            ranges.append((step, step))
    
    return ranges


def parse_ranks(ranks_str: str) -> list[int]:
    """
    Parse comma-separated ranks string into list of integers.
    
    Args:
        ranks_str: Comma-separated ranks (e.g., "0,1,2")
        
    Returns:
        List of rank integers
        
    Raises:
        ValidationError: If format is invalid
    """
    if not ranks_str:
        return []
    
    ranks = [int(r.strip()) for r in ranks_str.split(',')]
    if any(r < 0 for r in ranks):
        raise ValueError("Ranks must be non-negative integers")
    return ranks

def parse_durations(durations_str: str) -> list[tuple[int, int]]:
    if not durations_str:
        return []
    
    ranges = []
    for range_str in durations_str.split(','):
        range_str = range_str.strip()
        if '-' in range_str:
            delay, duration = range_str.split('-', 1)
            delay, duration = int(delay.strip()), int(duration.strip())
            assert delay >= 0 and duration > 0, f"Invalid range: {range_str} (delay >= 0 and duration > 0)"
            ranges.append((delay, duration))
        else:
            raise ValueError(f"Invalid range: {range_str}")
    
    return ranges

def build_config_from_args(args: argparse.Namespace) -> tiprofiler.Config:
    # Parse steps if provided
    steps = None
    if args.steps:
        steps = parse_steps(args.steps)
   
    # Parse ranks if provided
    ranks = None
    if args.ranks:
        ranks = parse_ranks(args.ranks)
    
    durations = None
    if args.durations:
        durations = parse_durations(args.durations)

    if (steps is None or len(steps) == 0) and (durations is None or len(durations) == 0):
        raise ValueError("steps or durations must be set")

    if steps and durations:
        logger.warning("both steps and durations set, durations will be ignored")

    task_id = os.environ["TI_INSTANCE_ID"] if "TI_INSTANCE_ID" in os.environ else datetime.now().strftime("%Y%m%d")
    local_path = None
    cos_path = None
    if args.output.startswith("file://"):
        local_path = os.path.join(args.output[len("file://"):], task_id)
    elif args.output.startswith("cos://"):
        local_path = os.path.join("/mnt/data/profiler", task_id)
        cos_path = os.path.join(args.output, task_id)

    profiler_args = None
    if args.profiler_args:
        # parse profiler_args format like k1=v1;k2=v2;... to dict
        profiler_args = {}
        for kv in args.profiler_args.split(';'):
            k, v = kv.split('=')
            profiler_args[k] = v
    return tiprofiler.Config(steps=steps, durations=durations, ranks=ranks, profiler_args=profiler_args, nsys=args.nsys == 'true', tccl=args.tccl, local_path=local_path, cos_path=cos_path)


def _get_resource_url(file_name):
    url = ""
    endpoint = os.getenv("PROFILER_RESOURCE_ENDPOINT")
    if endpoint is None:
        for u in ["cluster-addons-1308945662.cos-internal.accelerate.tencentcos.cn", "cluster-addons-1308945662.cos.accelerate.tencentcos.cn", "addons-shadc-1308945662.cos.ap-shanghai-adc.myqcloud.com"]:
            # try ping u, if success, then endpoint=u
            import socket
            try:
                socket.gethostbyname(u)
                endpoint = u
                break
            except socket.gaierror:
                continue

    if endpoint:
        url = f"https://{endpoint}"
    else:
        url = "https://cluster-addons-1308945662.cos.accelerate.tencentcos.cn"

    url = url + f"/tiprofiler/{file_name}"
    return url

# download gzip file from url, then unzip it to local_path
def _download_from_cos(file_name, local_path):
    import requests
    import tarfile

    url = _get_resource_url(file_name)
    tmp_file = os.path.join("/tmp", file_name)
    try:
        logger.info(f"downloading {url} -> {local_path}")

        response = requests.get(url, stream=True, timeout=300)
        if response.status_code != 200:
            raise RuntimeError(f"failed to download from {url}")

        total_size = int(response.headers.get("Content-Length", 0))
        downloaded = 0
        last_log_threshold = 0
        chunk_size = 8 * 1024  # 8KB 分块

        with open(tmp_file, "wb") as f:
            for chunk in response.iter_content(chunk_size=chunk_size):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)

                    if downloaded - last_log_threshold >= 10 * 1024 * 1024:
                        last_log_threshold = downloaded
                        downloaded_mb = downloaded / (1024 * 1024)
                        if total_size > 0:
                            total_mb = total_size / (1024 * 1024)
                            logger.info(f"download progress: {downloaded_mb:.1f} MB / {total_mb:.1f} MB")
                        else:
                            logger.info(f"downloaded: {downloaded_mb:.1f} MB")

        logger.info(f"download finished")

        os.makedirs(local_path, exist_ok=True)
        if url.endswith(".tar.gz") or url.endswith(".tgz"):
            with tarfile.open(tmp_file, "r:gz") as tar:
                tar.extractall(path=local_path)

        os.remove(tmp_file)
    except Exception as e:
        if os.path.exists(tmp_file):
            os.remove(tmp_file)
        raise

def _inject_tccl(_: tiprofiler.Config, cmd: list[str]) -> list[str] | None:
    tccl_lib = "/opt/profiler/tccl/libnccl.so"
    if not os.path.isfile(tccl_lib):
        logger.info(
            "tccl lib not found. try to install tccl:\n"
        )
        try:
            _download_from_cos("tccl.tar.gz", "/opt/profiler/tccl")
        except Exception as e:
            logger.error(f"failed to download tccl: {e}")
            return None

    if not os.path.isfile(tccl_lib):
        logger.error(
            "tccl lib not found, tccl disabled\n"
        )
        return None

    os.environ["TCCL_ENABLED"] = "true"
    if os.getenv('LD_PRELOAD') is None:
        os.environ['LD_PRELOAD'] = tccl_lib
    else:
        os.environ['LD_PRELOAD'] = tccl_lib + ':' + os.getenv('LD_PRELOAD')
    return cmd

def _has_rdma():
    for dev in os.listdir("/sys/class/infiniband/"):
        for port in os.listdir(f"/sys/class/infiniband/{dev}/ports/"):
            for gid in os.listdir(f"/sys/class/infiniband/{dev}/ports/{port}/gids/"):
                gid_file = f"/sys/class/infiniband/{dev}/ports/{port}/gids/{gid}"
                gid_content = open(gid_file, "r").read().strip()
                if gid_content == "0000:0000:0000:0000:0000:0000:0000:0000":
                    continue
                if gid_content == "fe80:0000:0000:0000:0000:0000:0000:0000":
                    continue
                return True
    return False


def _inject_nsys(config: tiprofiler.Config, cmd: list[str]) -> list[str] | None:
    nsys_bin = "/opt/profiler/nsight-systems/target-linux-x64/nsys"
    if not os.path.isfile(nsys_bin):
        logger.info(
            "nsys executable not found, try to install nsight systems"
        )
        try:
            _download_from_cos("nsight-systems.tar.gz", "/opt/profiler/nsight-systems")
        except Exception as e:
            logger.error(f"failed to download nsight systems: {e}")
            return None

    if not os.path.isfile(nsys_bin):
        logger.error(
            "nsys executable not found, nsys disabled\n"
        )
        return None
 
    nsys_args = {
        "--start-later": "false",
        "--trace": "cuda,nvtx,osrt",
        "--capture-range": "cudaProfilerApi",
        "--pytorch": "autograd-nvtx",
        "--trace-fork-before-exec": "true",
        "--stop-on-exit": "true",
        "--output": f"{config.local_path}/{config.report_prefix}.nsys-rep"
    }

    import torch
    if torch.__version__ >= "2.4":
        nsys_args["--pytorch"] = "autograd-nvtx,functions-trace"

    if config.steps and len(config.steps) > 0:
        nsys_args["--capture-range-end"] = f"repeat:{len(config.steps)}:sync"
    elif config.durations and len(config.durations):
        nsys_args["--capture-range-end"] = f"repeat:{len(config.durations)}:sync"
    if _has_rdma():
        nsys_args["--nic-metrics"] = "true"
       
    if config.profiler_args:
        for k, v in config.profiler_args.items():
            if k not in nsys_args:
                nsys_args[k] = v

    os.environ["NSYS_ENABLED"] = "true"
    args = [nsys_bin] + ["profile"] + [f"{k}={v}" for k, v in nsys_args.items()] + cmd
    logger.info(f"inject nsys profiler {' '.join(args)}")
    return args

def main():
    """
    Main entry point for tiprof CLI.
    
    Returns:
        Exit code (0 for success, non-zero for failure)
    """
    parser = create_parser()
    
    # If no arguments provided, show help
    if len(sys.argv) == 1:
        parser.print_help()
        return 0
    
    args = parser.parse_args()
    
    # Check if user command is provided
    if not args.command:
        print("No command specified. Please provide a command to execute.")
        parser.print_help()
        return 1
    
    # Build configuration from arguments
    config = build_config_from_args(args)
    
    # dump config to /etc/tiprofiler.json
    with open("/etc/tiprofiler.json", "w") as f:
        json.dump(config.__dict__, f, indent=2)

    args = args.command 
    if config.tccl:
        args = _inject_tccl(config, args)

    if config.nsys:
        args = _inject_nsys(config, args)

    if "PYTHONPATH" in os.environ:
        os.environ["PYTHONPATH"] = getattr(tiprofiler, "__path__", [""])[0] + ":" + os.environ["PYTHONPATH"]
    else:
        os.environ["PYTHONPATH"] = getattr(tiprofiler, "__path__", [""])[0]
    os.execvpe(args[0], args, dict(os.environ))
    
if __name__ == '__main__':
    sys.exit(main())
