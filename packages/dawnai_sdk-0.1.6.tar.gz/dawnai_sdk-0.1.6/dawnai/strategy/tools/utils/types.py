"""Utility function types."""

from pydantic import BaseModel


class ClassifyTextResponse(BaseModel):
    """Response from classify_text function."""

    category: str
