"""Web search and content extraction types."""

from typing import Any

from pydantic import BaseModel


class BrowserSearchResult(BaseModel):
    """Individual search result from browser_search."""

    title: str
    url: str
    published_date: str | None = None


class BrowserSearchResponse(BaseModel):
    """Response from browser_search function."""

    success: bool
    results: list[BrowserSearchResult]
    error: str | None = None


class ExtractTextContent(BaseModel):
    """Individual content result from extract_text_from_urls."""

    url: str
    title: str | None
    text: str


class ExtractTextResponse(BaseModel):
    """Response from extract_text_from_urls function."""

    success: bool
    contents: list[ExtractTextContent]
    error: str | None = None


class ExtractStructuredDataResponse(BaseModel):
    """Response from extract_structured_data_from_url function."""

    success: bool
    data: Any | None = None
    error: str | None = None
    url: str
