"""Sign and broadcast EVM transactions via the OWS SDK for live-local trading.

No private keys are exposed — all key operations stay inside the OWS keychain.
"""

from __future__ import annotations

import base64
from typing import Any

from ows import sign_and_send

POLYGON_RPC = "https://polygon-bor-rpc.publicnode.com"


def _sign_and_broadcast(tx_b64: str, wallet_name: str) -> str:
    """Sign a base64-encoded unsigned EIP-1559 RLP tx and broadcast it on Polygon.

    Returns the transaction hash.
    """
    tx_hex = "0x" + base64.b64decode(tx_b64).hex()
    result = sign_and_send(wallet_name, "evm", tx_hex, rpc_url=POLYGON_RPC)
    return str(result["tx_hash"])


def sign_and_submit_tx(pending_tx: dict[str, Any], wallet_name: str) -> str:
    """Sign an unsigned EVM transaction with the OWS SDK and broadcast it to Polygon.

    If ``approval_raw_tx_b64`` is present, signs and broadcasts the ERC-20 approval
    transaction first, then the main swap transaction.

    Expects the API to return either:
    - ``raw_tx``: hex-encoded RLP-encoded unsigned transaction bytes, OR
    - ``raw_tx_b64``: base64-encoded RLP-encoded unsigned transaction bytes

    Args:
        pending_tx: Dict returned from the Dawn API containing the unsigned transaction.
        wallet_name: The OWS wallet name (from ``dawn wallet current``).

    Returns:
        Transaction hash string (0x...) of the main swap transaction.

    Raises:
        ValueError: If the tx data is missing or OWS returns an error.
    """
    # Step 0: If an ERC-20 approval is needed, broadcast it first
    if pending_tx.get("approval_raw_tx_b64"):
        _sign_and_broadcast(pending_tx["approval_raw_tx_b64"], wallet_name)

    # Build base64 representation of the unsigned swap tx
    if "raw_tx_b64" in pending_tx:
        tx_b64 = pending_tx["raw_tx_b64"]
    elif "raw_tx" in pending_tx:
        raw_bytes = bytes.fromhex(pending_tx["raw_tx"].removeprefix("0x"))
        tx_b64 = base64.b64encode(raw_bytes).decode()
    else:
        raise ValueError(
            "pending_tx must contain 'raw_tx' (hex) or 'raw_tx_b64' (base64). "
            f"Got keys: {list(pending_tx.keys())}"
        )

    return _sign_and_broadcast(tx_b64, wallet_name)
