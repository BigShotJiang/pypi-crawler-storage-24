"""Base types for SDK tool responses with Decimal serialization support."""

from decimal import Decimal
from typing import Any

from pydantic import BaseModel, ConfigDict


class DecimalModel(BaseModel):
    """Base model that serializes Decimal fields as strings to preserve precision.

    All SDK response types should inherit from this to ensure Decimal values
    are serialized as strings in JSON, preventing floating-point precision loss.
    """

    model_config = ConfigDict(
        # Serialize Decimal as string using fixed-point format to avoid scientific notation
        json_encoders={Decimal: lambda v: format(v, "f")}
    )


def serialize_decimals(obj: Any) -> Any:
    """Recursively convert Decimal to string in dicts/lists.

    Used for serializing dict/list responses that may contain Decimal values
    but aren't Pydantic models.

    Args:
        obj: The object to serialize (dict, list, Decimal, or other)

    Returns:
        The same object with all Decimal values converted to strings
    """
    if isinstance(obj, Decimal):
        # Use fixed-point format to avoid scientific notation (e.g., '0E-8')
        # which fails MCP validation regex
        return format(obj, "f")
    if isinstance(obj, dict):
        return {k: serialize_decimals(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [serialize_decimals(item) for item in obj]
    return obj
