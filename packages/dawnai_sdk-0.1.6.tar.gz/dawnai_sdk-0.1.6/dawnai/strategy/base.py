"""Base Strategy class for building trading strategies."""

from __future__ import annotations

import inspect
from abc import ABCMeta
from typing import Any

from .triggers import TriggerConfig


class StrategyMeta(ABCMeta):
    """Metaclass for Strategy to collect trigger methods and risk functions."""

    def __new__(
        mcs: type[StrategyMeta],
        name: str,
        bases: tuple[type[Any], ...],
        namespace: dict[str, Any],
    ) -> StrategyMeta:
        cls = super().__new__(mcs, name, bases, namespace)

        # Collect all methods with trigger decorators
        triggers: list[TriggerConfig] = []

        for attr_name in dir(cls):
            if attr_name.startswith("_"):
                continue

            try:
                attr = getattr(cls, attr_name)
                if hasattr(attr, "_triggers"):
                    # Add all triggers from this method
                    triggers.extend(attr._triggers)
            except AttributeError:
                continue

        # Store triggers on the class
        cls._strategy_triggers = triggers  # type: ignore[attr-defined]

        return cls


class Strategy(metaclass=StrategyMeta):
    """Base class for all trading strategies.

    Subclasses should define methods decorated with triggers like @cron or @market_price_update.
    The SDK runtime will automatically detect and execute these methods based on their triggers.

    Risk functions can be labeled with the @risk decorator to indicate they handle risk management.

    Example:
        class MyStrategy(Strategy):
            def __init__(self):
                super().__init__()
                self.position = 0

            @cron(interval="5m")
            def check_market(self):
                # This runs every 5 minutes
                pass

            @risk
            def calculate_position_size(self, account_balance: float) -> float:
                # This is a risk function
                return account_balance * 0.02

            @market_price_update(symbol="BTCUSDT")
            def on_price_update(self, price: float):
                # This runs when BTCUSDT price updates
                pass
    """

    _strategy_triggers: list[TriggerConfig]

    def __init__(self) -> None:
        """Initialize the strategy."""
        self._initialized: bool = False

    def initialize(self) -> None:
        """Initialize the strategy.

        Override this method to perform any setup required before the strategy starts.
        """
        self._initialized = True

    def shutdown(self) -> None:
        """Shutdown the strategy.

        Override this method to perform any cleanup when the strategy stops.
        """
        pass

    def get_triggers(self) -> list[TriggerConfig]:
        """Get all triggers defined for this strategy."""
        return getattr(self, "_strategy_triggers", [])

    @classmethod
    def validate(cls) -> list[str]:
        """Validate the strategy configuration.

        Returns:
            List of validation errors (empty if valid)
        """
        errors: list[str] = []

        # Note: Multiple methods with the same cron trigger are allowed
        # This is a valid pattern for organizing related operations

        triggers = cls._strategy_triggers

        # Validate method signatures
        for trigger in triggers:
            method = getattr(cls, trigger.method_name, None)
            if method is None:
                errors.append(f"Method {trigger.method_name} not found")
                continue

            sig = inspect.signature(method)
            params = list(sig.parameters.keys())

            # Remove 'self' parameter
            if params and params[0] == "self":
                params = params[1:]

            # Cron methods should have no required parameters
            if params:
                # Check if all remaining params have defaults
                sig_params = sig.parameters
                for param_name in params:
                    param = sig_params[param_name]
                    if param.default == inspect.Parameter.empty:
                        errors.append(
                            f"Method {trigger.method_name} for cron trigger "
                            f"should not have required parameters (found: {param_name})"
                        )

        return errors
