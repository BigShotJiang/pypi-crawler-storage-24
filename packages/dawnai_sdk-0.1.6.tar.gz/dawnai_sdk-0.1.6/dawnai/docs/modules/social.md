# Social Module

**Path**: `dawnai.strategy.tools.social`

## Module Description

Social media integration functions.

## Available Functions

### `get_tweet_info(tweet_ids: list[str]) -> TweetInfoResponse`

Get detailed information about specific tweets.

Args:
    tweet_ids: List of tweet IDs to get information about

Returns:
    TweetInfoResponse containing detailed tweet info and optional error

### `get_user_tweets(handle: str, cursor: str | None = None) -> UserTweetsResponse`

Get recent tweets from a specific Twitter user.

Args:
    handle: Twitter handle (without @ symbol)
    cursor: Optional pagination cursor for next page

Returns:
    UserTweetsResponse containing tweets,  optional pagination cursor and error

### `search_tweets(query: str, query_type: str = 'Latest', cursor: str | None = None) -> SearchTweetsResponse`

Search for tweets based on a query string.

Args:
    query: Search query for finding tweets
    query_type: Type of query to search for
    cursor: Optional pagination cursor for next page

Returns:
    SearchTweetsResponse containing tweets, count, optional pagination cursor and error

## Available Types

### `SearchTweetsResponse`

Response from search_tweets function.

Fields:
    success: bool
    tweets: list[Tweet]
    count: int
    next_cursor: str | None
    error: str | None

### `Tweet`

Twitter tweet information.

Fields:
    id: str
    text: str
    created_at: str | None
    author: TwitterUser
    like_count: int
    quote_count: int
    view_count: int
    reply_count: int
    retweet_count: int
    quoted_tweet: Optional['Tweet'] = None
    retweeted_tweet: Optional['Tweet'] = None

### `TweetInfoResponse`

Response from get_tweet_info function.

Fields:
    success: bool
    tweets: list[Tweet]
    error: str | None

### `TwitterUser`

Twitter user information.

Fields:
    user_name: str
    url: str
    name: str
    description: str
    followers: int
    following: int
    is_verified: bool
    is_automated: bool
    tweets_count: int

### `UserTweetsResponse`

Response from get_user_tweets function.

Fields:
    success: bool
    tweets: list[Tweet]
    has_next_page: bool
    next_cursor: str | None
    error: str | None
