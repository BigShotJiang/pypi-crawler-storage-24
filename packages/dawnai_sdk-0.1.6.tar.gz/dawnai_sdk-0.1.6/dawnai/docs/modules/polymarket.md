# Polymarket Module

**Path**: `dawnai.strategy.tools.polymarket`

## Module Description

Polymarket prediction market trading and data functions.

## Available Functions

### `get_polymarket_market_details(market_id: str) -> PolymarketMarket | None`

Get detailed information about a Polymarket market and its tokens.

Args:
    market_id: Market ID to get details for (e.g. "123456")

Returns:
    PolymarketMarket object containing market details and tokens or None if not found

Example:
    >>> market_details = get_polymarket_market_details("123456")
    >>> print(market_details.question)
    >>> print(market_details.tokens)

### `get_polymarket_order_book(market_id: str, side: str) -> OrderBookResponse`

Get order book for a Polymarket market side (outcome).

Args:
    market_id: Market ID to get order book for (e.g., "123456")
    side: Side (outcome) to get order book for (e.g., "Yes", "No", "Up", "Down").
    Matched case-insensitively (with whitespace trimmed) against the market's
    available outcomes. For binary markets (2 outcomes), if no exact match is found,
    falls back to: "yes" -> first outcome, anything else -> second outcome.
    For markets with more than 2 outcomes, an exact match is required.

Returns:
    OrderBookResponse containing order book data and optional error message.
    The order book includes bids/asks with price and size information,
    along with market metadata like tick_size and min_order_size.

Example:
    >>> # Standard Yes/No market
    >>> result = get_polymarket_order_book("123456", side="Yes")
    >>> if result.order_book:
    ...     print(f"Tick size: {result.order_book.tick_size}")
    ...     print(f"Min order size: {result.order_book.min_order_size}")
    ...     if result.order_book.bids:
    ...         best_bid = result.order_book.bids[0]
    ...         print(f"Best bid: {best_bid.price} (size: {best_bid.size})")
    ...     if result.order_book.asks:
    ...         best_ask = result.order_book.asks[0]
    ...         print(f"Best ask: {best_ask.price} (size: {best_ask.size})")
    ...
    >>> # Market with custom outcomes
    >>> result = get_polymarket_order_book("789012", side="Up")

### `get_polymarket_prices(market_id: str) -> GetPolymarketPricesResponse`

Get current prices for all tokens in a Polymarket market.

Args:
    market_id: Polymarket market ID (must be a numeric string)

Returns:
    GetPolymarketPricesResponse containing:
    - prices: Dictionary mapping token IDs to MarketPriceData (BUY/SELL prices).
    The BUY price is the best bid price and the SELL price is the best ask price.
Note: This dictionary will be empty if the market has closed.
    - error: Optional error message if the request failed

Example:
    >>> result = get_polymarket_prices("123456")
    >>> print(result.prices)
    {
    "token_abc123": MarketPriceData(BUY="0.55", SELL="0.54"),
    "token_def456": MarketPriceData(BUY="0.45", SELL="0.46")
    }

### `get_polymarket_timeseries(market_id: str, side: str, interval: Literal['1m', '1h', '6h', '1d', '1w', 'max'] = '1h', fidelity: int = 60) -> list[TimeseriesPoint]`

Get time series data for a Polymarket market side (outcome).

Args:
    market_id: Market ID to get time series data for (e.g., "123456")
    side: Side (outcome) to get time series data for (e.g., "Yes", "No", "Up", "Down").
    Matched case-insensitively (with whitespace trimmed) against the market's
    available outcomes. For binary markets (2 outcomes), if no exact match is found,
    falls back to: "yes" -> first outcome, anything else -> second outcome.
    For markets with more than 2 outcomes, an exact match is required.
    interval: Time interval for the data ("max", "1d", "1h", "6h", "1w", "1m")
    fidelity: Fidelity in seconds for data resolution

Returns:
    List of time series data points with timestamp and price

Example:
    >>> # Standard Yes/No market
    >>> timeseries = get_polymarket_timeseries("123456", side="Yes", interval="1h")
    >>> for point in timeseries:
    ...     print(f"Time: {point.t}, Price: {point.p}")
    ...
    >>> # Market with custom outcomes
    >>> timeseries = get_polymarket_timeseries("789012", side="Down", interval="1d")

### `polymarket_buy_token(token_id: str, amount: Decimal) -> BuyTokenResult`

Execute a real buy trade for specific Polymarket tokens by token ID.

    This will spend real USDC to purchase tokens on Polymarket.

Args:
    token_id: The specific token ID to buy
    amount: How much should be traded in USDC (as Decimal). Must be at least $1.

Returns:
    BuyTokenResult containing:
    - result: Order execution result with success, order_id, transaction_hash,
    executed_price, executed_amount
    - error: Optional error message if trade failed

### `polymarket_event_markets(event_id: int, limit: int = 10, offset: int = 0, order: Literal['volume24hr', 'volume', 'liquidity', 'startDate', 'endDate'] | None = None, ascending: bool = False, active: bool | None = None, closed: bool | None = None) -> PolymarketEventMarketsResponse`

Get markets for a specific Polymarket event with pagination and filtering options.

Args:
    event_id: The ID of the event to get markets for
    limit: Maximum number of markets to return (default: 10)
    offset: Number of markets to skip for pagination (default: 0)
    order: Sort markets by 'volume24hr', 'volume', 'liquidity', 'startDate', or 'endDate'
    ascending: Sort in ascending order (default: False for descending)
    active: Filter for active markets only
    closed: Filter for closed markets only

Returns:
    PolymarketEventMarketsResponse containing:
    - markets: List of market information for the event
    - count: Number of markets returned in this page
    - totalMarkets: Total number of markets for this event (after filtering)
    - eventInfo: Information about the event (id, title, description, slug)
    - error: Optional error message if the request failed

Example:
    >>> result = polymarket_event_markets(12345, limit=5, active=True)
    >>> print(f"Event: {result.event_info.title}")
    >>> print(f"Found {result.total_markets} active markets")
    >>> for market in result.markets:
    ...     print(f"Market: {market.question}")

### `polymarket_event_search(query: str, limit: int = 10, events_status: str = 'active', sort: str | None = None, ascending: bool = False, page: int = 1) -> PolymarketEventSearchResponse`

Search for Polymarket events and tags.

Args:
    query: Search query for finding Polymarket events and tags
    limit: Maximum number of events to return (default: 10)
    events_status: Status filter for events ('active' or 'resolved', default: 'active')
    sort: Sort order for resulting events ('volume_24hr', 'volume', 'liquidity',
    'start_date', 'end_date')
    ascending: Sort in ascending order (default: False for descending if sort is specified)
    page: Page number for pagination (default: 1)

Returns:
    PolymarketEventSearchResponse containing matching events with their associated tags,
    plus a top-level tags array of all matching tags. By default, returns active events.

### `polymarket_list_events(limit: int = 10, offset: int = 0, order: str | None = None, ascending: bool = False, id: list[int] | None = None, slug: list[str] | None = None, tag_id: int | None = None, exclude_tag_id: list[int] | None = None, related_tags: bool | None = None, featured: bool | None = None, cyom: bool | None = None, include_chat: bool | None = None, include_template: bool | None = None, recurrence: str | None = None, closed: bool | None = None, start_date_min: str | None = None, start_date_max: str | None = None, end_date_min: str | None = None, end_date_max: str | None = None) -> PolymarketListEventsResponse`

List Polymarket events with advanced filtering and sorting options.

Args:
    limit: Maximum number of events to return (default: 10)
    offset: Number of events to skip for pagination (default: 0)
    order: Comma-separated fields to sort by (e.g., "volume", "volume_24hr", "liquidity",
    "start_date", "end_date"). Both snake_case and camelCase are supported.
    ascending: Sort in ascending order (default: False for descending)
    id: Filter by event IDs (array of numbers)
    slug: Filter by event slugs (array of strings)
    tag_id: Filter by tag ID
    exclude_tag_id: Exclude events with these tag IDs (array of numbers)
    related_tags: Include related tags in response
    featured: Filter for featured events only
    cyom: Filter for Create Your Own Market events
    include_chat: Include chat information
    include_template: Include template information
    recurrence: Filter by recurrence type
    closed: Filter for closed events
    start_date_min: Minimum start date (ISO date-time)
    start_date_max: Maximum start date (ISO date-time)
    end_date_min: Minimum end date (ISO date-time)
    end_date_max: Maximum end date (ISO date-time)

Returns:
    PolymarketListEventsResponse containing matching events.
    Returns simplified event metadata including marketCount but not nested market details.

### `polymarket_sell_token(token_id: str, amount: Decimal) -> SellTokenResult`

Execute a real sell trade for specific Polymarket tokens by token ID.

    This will sell real tokens on Polymarket for USDC.

Args:
    token_id: The specific token ID to sell
    amount: How many tokens to sell (as Decimal)

Returns:
    SellTokenResult containing:
    - result: Order execution result with success, order_id, transaction_hash,
    executed_price, executed_amount
    - error: Optional error message if trade failed

### `polymarket_simulate_buy(token_id: str, usd_amount: Decimal) -> SimulateTradeResult`

Simulate buying Polymarket tokens without executing the trade.

    Use this to preview order book consumption, slippage, and price impact
    before committing real funds to a buy order.

Args:
    token_id: The specific token ID to simulate buying
    usd_amount: Amount of USDC to spend on this purchase (as Decimal)

Returns:
    SimulateTradeResult containing:
    - average_price: Weighted average execution price per token
    - tokens_traded: Number of tokens you would receive
    - usd_amount: Total USD spent (should match input)
    - market_price_after: Next ask price after your buy order
    - consumed_orders: List of ask orders that would be consumed
    - price_impact_percent: Price impact as percentage
    - error: Optional error message if simulation failed

Example:
    >>> result = polymarket_simulate_buy("0x123...", Decimal("100"))
    >>> print(f"You'll get {result.tokens_traded} tokens")
    >>> print(f"Avg price: ${result.average_price}")
    >>> print(f"Market moves to: ${result.market_price_after}")
    >>> print(f"Price impact: {result.price_impact_percent}%")

### `polymarket_simulate_sell(token_id: str, token_amount: Decimal) -> SimulateTradeResult`

Simulate selling Polymarket tokens without executing the trade.

    Use this to preview order book consumption, slippage, and price impact
    before committing to a sell order.

Args:
    token_id: The specific token ID to simulate selling
    token_amount: Number of tokens to sell (as Decimal, NOT USD amount)

Returns:
    SimulateTradeResult containing:
    - average_price: Weighted average execution price per token
    - tokens_traded: Number of tokens you would sell (should match input)
    - usd_amount: Total USD you would receive
    - market_price_after: Next bid price after your sell order
    - consumed_orders: List of bid orders that would be consumed
    - price_impact_percent: Price impact as percentage
    - error: Optional error message if simulation failed

Example:
    >>> result = polymarket_simulate_sell("0x123...", Decimal("100"))
    >>> print(f"You'll get ${result.usd_amount} USDC")
    >>> print(f"Avg price: ${result.average_price}")
    >>> print(f"Market moves to: ${result.market_price_after}")
    >>> print(f"Price impact: {result.price_impact_percent}%")

## Available Types

### `BuyTokenResult`

Response from polymarket_buy_token function.

Fields:
    result: OrderResult
    error: str | None = None

### `EventInfo`

Event information for event markets API response.

Fields:
    id: str
    title: str
    description: str | None = None
    slug: str

### `GetPolymarketPricesResponse`

Response from get_polymarket_prices function.

Fields:
    prices: dict[str, MarketPriceData]
    error: str | None = None

### `MarketPriceData`

Market price data for buy/sell sides.

Fields:
    BUY: str
    SELL: str

### `Order`

Single order entry for order book.

Fields:
    price: Decimal
    size: Decimal

### `OrderBookData`

Order book data matching Polymarket CLOB API response.

Fields:
    market: str
    asset_id: str
    hash: str
    timestamp: str
    bids: list[Order]
    asks: list[Order]
    min_order_size: str
    tick_size: str
    neg_risk: bool

### `OrderBookResponse`

Response from get_polymarket_order_book function.

Fields:
    order_book: OrderBookData | None = None
    error: str | None = None

### `OrderResult`

Result of executing a Polymarket buy/sell trade.

Fields:
    success: bool
    order_id: str
    transaction_hash: str | None = None
    executed_price: Decimal
    executed_amount: Decimal

### `PolymarketEvent`

Polymarket event details from event search (matches SimpleEvent from API).

Fields:
    model_config = ConfigDict(extra='allow')
    id: str
    ticker: str | None = None
    slug: str
    title: str
    description: str | None = None
    volume: float | None = None
    volume24hr: float | None = None
    liquidity: float | None = None
    active: bool
    closed: bool
    start_date: str | None = None
    end_date: str | None = None
    tags: list[Tag]
    market_count: int

### `PolymarketEventMarketsResponse`

Response from polymarket_event_markets function.

Fields:
    markets: list[PolymarketMarket]
    count: int
    total_markets: int
    event_info: EventInfo
    error: str | None = None

### `PolymarketEventSearchResponse`

Response from polymarket_event_search function.

Fields:
    events: list[PolymarketEvent]
    tags: list[Tag]
    count: int
    error: str | None = None

### `PolymarketListEventsResponse`

Response from polymarket_list_events function.

Fields:
    events: list[PolymarketEvent]
    count: int
    error: str | None = None

### `PolymarketMarket`

Polymarket market details from event markets (matches SimpleMarket from API).

Fields:
    model_config = ConfigDict(extra='allow')
    id: str
    question: str
    slug: str
    description: str | None = None
    active: bool
    closed: bool
    start_date: str | None = None
    end_date: str | None = None
    volume: str | None = None
    volume24hr: float | None = None
    liquidity: str | None = None
    price: str | None = None
    spread: float | None = None
    tokens: list[TokenInfo] | None = None

### `SellTokenResult`

Response from polymarket_sell_token function.

Fields:
    result: OrderResult
    error: str | None = None

### `SimulateTradeResult`

Response from simulate_trade function.

Fields:
    average_price: Decimal
    tokens_traded: Decimal
    usd_amount: Decimal
    market_price_after: Decimal | None = None
    consumed_orders: list[Order]
    price_impact_percent: Decimal | None = None
    error: str | None = None

### `Tag`

Polymarket tag information.

Fields:
    id: str
    label: str
    slug: str

### `TimeseriesPoint`

Time series data point for market price history.

Fields:
    t: int
    p: Decimal

### `TokenInfo`

Token information with id and outcome.

Fields:
    id: str
    outcome: str
