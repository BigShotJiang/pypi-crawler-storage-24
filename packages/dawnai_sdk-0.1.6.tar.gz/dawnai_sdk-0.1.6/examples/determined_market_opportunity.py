from datetime import datetime, timedelta
from typing import Literal

from dawnai.strategy import Strategy, cron
from dawnai.strategy.tools import (
    get_polymarket_market_details,
    get_polymarket_order_book,
    get_polymarket_prices,
    polymarket_event_markets,
    polymarket_event_search,
    run_agent,
)
from dawnai.strategy.tools.polymarket.types import (
    MarketPriceData,
    PolymarketEvent,
    PolymarketMarket,
    TokenInfo,
)


class DeterminedMarketOpportunityStrategy(Strategy):
    """Capitalizes on Polymarket inefficiency where markets may still be open.

    Despite being determined in real-life, the markets are still open and haven't been resolved.
    Finds events closest to end date (<1hr), and checks if
    price is >90% in either direction, verifies liquidity availability, then uses
    agent to make directional trades after browser validation that the market outcome
    is basically determined.
    """

    def __init__(self) -> None:
        super().__init__()
        self.initial_capital = 1000.0  # USDC
        self.max_position_size = self.initial_capital * 0.2  # 20% of capital per trade
        self.price_threshold = 0.90  # 90% threshold for considering a market "determined"

    @cron(interval="5m")
    def find_determined_markets_and_trade(self) -> None:
        """Main cron function that runs every 5 minutes to find determined market opportunities."""
        # Find events ending within 1 hour
        now = datetime.now()

        # Search for events ending soon, sorted by end date
        events = polymarket_event_search(
            query="sports",  # Get all events
            limit=50,
            events_status="active",
            sort="endDate",
            ascending=True,
        )

        print(f"Found {len(events.events)} active events")

        # Filter events ending within 1 hour
        soon_ending_events = []
        for event in events.events:
            if event.end_date:
                end_date = datetime.fromisoformat(event.end_date)
                time_until_end = end_date - now.replace(tzinfo=end_date.tzinfo)
                if timedelta(0) < time_until_end < timedelta(hours=1):
                    soon_ending_events.append(event)

        print(f"Found {len(soon_ending_events)} events ending within 1 hour")

        # Check each event's markets for opportunities
        for event in soon_ending_events[:10]:  # Limit to 10 events to avoid hitting API limits
            self._check_event_for_opportunities(event)

    def _check_event_for_opportunities(self, event: PolymarketEvent) -> None:
        """Check an individual event for trading opportunities."""
        event_id = event.id
        event_title = event.title

        print(f"Checking event: {event_title}")

        try:
            # Get markets for this event
            print(event_id)
            markets_response = polymarket_event_markets(event_id=int(event_id))
            print(markets_response)

            # Check if there was an error getting markets
            if markets_response.error:
                print(f"Error getting markets for event {event_title}: {markets_response.error}")
                return

            markets = markets_response.markets

            for market in markets[:3]:  # Check up to 3 markets per event
                try:
                    self._check_market_for_opportunity(market, event_title)
                except Exception as market_error:
                    print(f"Error checking market {market.question}: {market_error!s}")
                    continue

        except Exception as e:
            # This might be a validation error from the SDK
            print(str(e))
            if "validation error" in str(e):
                print(
                    f"Data validation issue for event {event_title} - skipping "
                    f"(this is a known SDK issue with spread field types)"
                )
            else:
                print(f"Error checking event {event_title}: {e!s}")

    def _check_market_for_opportunity(self, market: PolymarketMarket, event_title: str) -> None:
        """Check an individual market for trading opportunity."""
        market_id = market.id
        question = market.question
        print()

        try:
            market_data = self._get_market_data(market_id)
            if not market_data:
                return

            market_details, prices = market_data
            opportunity = self._analyze_market_opportunity(market_details, prices, question)
            if not opportunity:
                return

            determined_side, determined_price = opportunity
            liquidity_ok = self._check_liquidity(
                market_id,
                determined_side,
                question,
                market_details.tokens,  # type: ignore[arg-type]
            )
            if not liquidity_ok:
                return

            total_liquidity = liquidity_ok
            print(f"  Sufficient liquidity: {total_liquidity:.2f} USDC available")

            # Use agent to validate and execute trade
            self._execute_determined_market_trade(
                market_id=market_id,
                question=question,
                event_title=event_title,
                determined_side=determined_side,
                determined_price=determined_price,
                available_liquidity=total_liquidity,
            )

        except Exception as e:
            print(f"Error checking market {question}: {e!s}")

    def _get_market_data(
        self, market_id: str
    ) -> tuple[PolymarketMarket, dict[str, MarketPriceData]] | None:
        """Get market details and prices."""
        market_details = get_polymarket_market_details(market_id=str(market_id))
        if not market_details:
            return None

        prices_response = get_polymarket_prices(market_id=str(market_id))
        prices = prices_response.prices
        return market_details, prices

    def _analyze_market_opportunity(
        self, market_details: PolymarketMarket, prices: dict[str, MarketPriceData], question: str
    ) -> tuple[str, float] | None:
        """Analyze if market presents a determined opportunity."""
        tokens = market_details.tokens
        if not tokens or len(tokens) != 2:
            return None  # Skip non-binary markets

        # Get both tokens regardless of their outcome labels
        token_a = tokens[0]
        token_b = tokens[1]

        token_a_id = token_a.id
        token_b_id = token_b.id

        # Get prices for both tokens
        token_a_prices = prices.get(token_a_id)
        token_b_prices = prices.get(token_b_id)

        if not token_a_prices or not token_b_prices:
            return None

        # Use BUY price as the market price (what we'd pay)
        token_a_price = float(token_a_prices.BUY)
        token_b_price = float(token_b_prices.BUY)

        # Check if either side is above 90% threshold
        if token_a_price > self.price_threshold:
            determined_side = token_a.outcome
            determined_price = token_a_price
        elif token_b_price > self.price_threshold:
            determined_side = token_b.outcome
            determined_price = token_b_price
        else:
            return None  # Not determined enough

        print(f"Found determined market: {question}")
        print(f"  {determined_side} side at {determined_price:.2%}")
        return determined_side, determined_price

    def _map_outcome_to_api_side(
        self, determined_side: str, tokens: list[TokenInfo]
    ) -> Literal["YES", "NO"] | None:
        """Map outcome name to YES/NO format expected by order book API."""
        # Find which token matches our determined side
        for token in tokens:
            if token.outcome == determined_side:
                # The API uses YES for the first token, NO for the second token in most cases
                # But we need to check the token order to be sure
                if tokens[0].outcome == determined_side:
                    return "YES"
                return "NO"
        return None

    def _check_liquidity(
        self, market_id: str, determined_side: str, _question: str, tokens: list[TokenInfo]
    ) -> float | None:
        """Check if there's sufficient liquidity for the trade."""
        # Map outcome names to YES/NO format for order book API
        # The API expects uppercase YES/NO regardless of actual token outcome names
        api_side = self._map_outcome_to_api_side(determined_side, tokens)
        if not api_side:
            print(f"  Could not map outcome '{determined_side}' to API format")
            return None

        order_book = get_polymarket_order_book(market_id=str(market_id), side=api_side)

        order_book_data = order_book.order_book
        if not order_book_data:
            return None

        asks = order_book_data.asks
        if not asks or len(asks) == 0:
            print(f"  No liquidity available for {determined_side} side")
            return None

        # Calculate available liquidity
        total_liquidity = sum(float(ask.size) for ask in asks[:5])  # Top 5 asks
        min_liquidity_threshold = self.max_position_size * 0.5  # At least 50% of position size

        if total_liquidity < min_liquidity_threshold:
            print(f"  Insufficient liquidity: {total_liquidity:.2f} USDC available")
            return None

        return total_liquidity

    def _execute_determined_market_trade(
        self,
        market_id: str,
        question: str,
        event_title: str,
        determined_side: str,
        determined_price: float,
        available_liquidity: float,
    ) -> None:
        """Execute trade on a determined market using agent validation."""
        trade_prompt = f"""
        I've identified a potentially determined Polymarket opportunity:

        Event: {event_title}
        Market: {question}

        Current situation:
        - The "{determined_side}" outcome is priced at {determined_price:.2%}
        - Available liquidity: {available_liquidity:.2f} USDC
        - Market ends within 1 hour

        Please:
        1. Use browser search to verify if this market outcome is actually determined
        2. Look for recent news, official announcements, or clear evidence about the outcome
        3. If the outcome appears genuinely determined, execute a trade for the
           "{determined_side}" outcome
        4. Use a position size of maximum {self.max_position_size:.2f} USDC
        5. Provide a summary of your research and decision

        Market ID: {market_id}
        Target outcome: {determined_side}

        Only trade if you're highly confident the outcome is determined based on your research.
        """

        try:
            result = run_agent(prompt=trade_prompt, informational_tools=True, execution_tools=True)

            print(f"Agent result for {question}:")
            print(result)

        except Exception as e:
            print(f"Error executing agent trade for {question}: {e!s}")


if __name__ == "__main__":
    strategy = DeterminedMarketOpportunityStrategy()
    strategy.find_determined_markets_and_trade()
