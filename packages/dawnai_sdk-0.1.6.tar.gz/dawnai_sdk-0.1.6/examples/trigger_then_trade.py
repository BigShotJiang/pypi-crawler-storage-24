from decimal import Decimal
from typing import Any

from dawnai.strategy import Strategy, cron
from dawnai.strategy.tools import (
    ScoreEvent,
    get_polymarket_prices,
    get_scores,
    get_sports,
    get_state,
    polymarket_buy_token,
    polymarket_sell_token,
    read_portfolio,
    run_agent,
    set_state,
)


class MyStrategy(Strategy):
    """Monitor live sports for first score and trade with 20% take profit.

    Rules implemented:
    - discover_and_track_new_live_games (5m): Find 0-0 live games, map to Polymarket,
      record baseline BUY prices for both team tokens.
    - monitor_tracked_games_for_first_score (1m): For tracked games, detect first score and
      buy $8 of the scoring team's token only if price increased <= 10% from baseline.
    - monitor_open_positions_and_take_profit (5m): For open positions created by this strategy,
      monitor prices and take 20% profit when reached.
    """

    def _get_tracked_games(self) -> dict[str, dict[str, Any]]:
        """Get tracked games from persistent state.

        tracked_games schema:
          key: odds API event id (str)
          value: {
            'sport_key': str,
            'market_id': str,
            'home_token': str,
            'away_token': str,
            'home_team': str,
            'away_team': str,
            'baseline_home_buy': str (Decimal serialized as string),
            'baseline_away_buy': str (Decimal serialized as string),
          }
        """
        return get_state("tracked_games") or {}

    def _set_tracked_games(self, tracked_games: dict[str, dict[str, Any]]) -> None:
        """Save tracked games to persistent state."""
        set_state("tracked_games", tracked_games)

    def _get_open_positions(self) -> dict[str, dict[str, Any]]:
        """Get open positions from persistent state.

        open_positions schema:
          key: token_id (str)
          value: {
            'market_id': str,
            'team': str,
            'entry_price': str (Decimal serialized as string),
            'amount': str (Decimal serialized as string),
          }
        """
        return get_state("open_positions") or {}

    def _set_open_positions(self, open_positions: dict[str, dict[str, Any]]) -> None:
        """Save open positions to persistent state."""
        set_state("open_positions", open_positions)

    def _extract_scores(
        self, score_event: ScoreEvent, home_team: str, away_team: str
    ) -> tuple[int, int]:
        print(f"[_extract_scores] Parsing scores for event_id={score_event.id}")
        scores = score_event.scores
        if scores is None or not isinstance(scores, list) or len(scores) < 2:
            raise ValueError("Scores must be a list of at least two entries")
        # Map by team name to ensure proper alignment
        home_score_str: str | None = None
        away_score_str: str | None = None
        for score in scores:
            if score.name == home_team:
                home_score_str = score.score
            elif score.name == away_team:
                away_score_str = score.score
        if home_score_str is None or away_score_str is None:
            raise ValueError("Unable to align scores to home/away teams")
        if not home_score_str.isdigit() or not away_score_str.isdigit():
            raise ValueError("Score values must be numeric strings")
        home_score = int(home_score_str)
        away_score = int(away_score_str)
        print(f"[_extract_scores] Extracted home={home_score}, away={away_score}")
        return home_score, away_score

    def _find_polymarket_event_for_teams(self, home_team: str, away_team: str) -> str:
        """Use an agent to find the Polymarket event ID for a sports game.

        Returns the event ID as a string.
        """
        print(
            f"[_find_polymarket_event_for_teams] Using agent to find event "
            f"for {away_team} @ {home_team}"
        )
        prompt = (
            f"Find the active Polymarket event for the sports game "
            f"between {away_team} and {home_team}.\n\n"
            f"The home team is {home_team} and the away team is {away_team}.\n\n"
            "Search for relevant active Polymarket events and return "
            "ONLY the event ID (as a number) of the matching event.\n"
            'If no suitable event is found, respond with "NOT_FOUND".\n'
            'Your response should be just the event ID number or "NOT_FOUND", '
            "nothing else."
        )

        response = run_agent(
            prompt=prompt,
            informational_tools=True,
            execution_tools=False,
        )

        print(f"[_find_polymarket_event_for_teams] Agent response: {response}")

        # Parse the response to extract event ID
        response = response.strip()
        if response == "NOT_FOUND" or "NOT_FOUND" in response.upper():
            raise ValueError(
                f"Agent could not find Polymarket event for {away_team} vs {home_team}"
            )

        # Extract the event ID from the response
        # The agent should return just the ID, but handle various formats
        try:
            event_id = int(response.split()[0])  # Take first token and convert to int
            print(f"[_find_polymarket_event_for_teams] Extracted event_id={event_id}")
            return str(event_id)
        except (ValueError, IndexError):
            raise ValueError(
                f"Agent response did not contain a valid event ID: {response}"
            ) from None

    def _map_market_tokens_to_teams(
        self, event_id: str, home_team: str, away_team: str
    ) -> tuple[str, str, str]:
        """Use an agent to find the market and token IDs for a Polymarket event.

        Returns (market_id, home_token_id, away_token_id) as strings.
        """
        print(
            f"[_map_market_tokens_to_teams] Using agent to map tokens " f"for event_id={event_id}"
        )
        prompt = (
            f"For Polymarket event ID {event_id}, find the active market "
            "where users can bet on which team wins.\n\n"
            f"The home team is {home_team} and the away team is {away_team}.\n\n"
            "Get the markets for this event and identify:\n"
            "1. The market ID for the winner market\n"
            f"2. The token ID for {home_team} winning\n"
            f"3. The token ID for {away_team} winning\n\n"
            "Return your response in this EXACT format "
            "(just these three IDs separated by commas, nothing else):\n"
            "market_id,home_token_id,away_token_id\n\n"
            'If you cannot find the required information, respond with "NOT_FOUND".'
        )

        response = run_agent(
            prompt=prompt,
            informational_tools=True,
            execution_tools=False,
        )

        print(f"[_map_market_tokens_to_teams] Agent response: {response}")

        # Parse the response
        response = response.strip()
        if response == "NOT_FOUND" or "NOT_FOUND" in response.upper():
            raise ValueError(f"Agent could not map tokens for event {event_id}")

        # Extract the IDs from the response
        parts = [p.strip() for p in response.split(",")]
        if len(parts) != 3:
            raise ValueError(f"Expected 3 comma-separated values, got {len(parts)}")

        try:
            market_id, home_token, away_token = parts
        except (ValueError, IndexError) as e:
            raise ValueError(
                f"Agent response did not contain valid IDs: {response}. Error: {e}"
            ) from e
        else:
            print(
                f"[_map_market_tokens_to_teams] Mapped tokens -> "
                f"market:{market_id} home:{home_token} away:{away_token}"
            )
            return market_id, home_token, away_token

    def _determine_first_scorer(
        self, last_home: int, last_away: int, cur_home: int, cur_away: int
    ) -> str | None:
        print(
            f"[_determine_first_scorer] last=({last_home},{last_away}) -> "
            f"current=({cur_home},{cur_away})"
        )
        if last_home == 0 and last_away == 0:
            if cur_home > 0 and cur_away == 0:
                return "HOME"
            if cur_away > 0 and cur_home == 0:
                return "AWAY"
        return None

    def _find_zero_zero_live_games(self) -> list[dict[str, Any]]:
        """Find all live games with 0-0 score."""
        sports_resp = get_sports()
        if not sports_resp.success:
            raise ValueError("get_sports failed")
        sports = [s for s in sports_resp.data if s.active]
        print(f"[discover] Active sports count: {len(sports)}")

        zero_zero_games: list[dict[str, Any]] = []
        for sport in sports:
            scores_resp = get_scores(sport=sport.key)
            if not scores_resp.success:
                raise ValueError(f"get_scores failed for sport={sport.key}")
            for score_event in scores_resp.data:
                if (
                    score_event.completed
                    or score_event.last_update is None
                    or score_event.scores is None
                ):
                    continue
                home_score, away_score = self._extract_scores(
                    score_event, score_event.home_team, score_event.away_team
                )
                if home_score == 0 and away_score == 0:
                    print(
                        f"[discover] Found 0-0 live game {score_event.id}: "
                        f"{score_event.away_team} @ {score_event.home_team} ({sport.key})"
                    )
                    zero_zero_games.append(
                        {
                            "sport_key": sport.key,
                            "event_id": score_event.id,
                            "home_team": score_event.home_team,
                            "away_team": score_event.away_team,
                        }
                    )
        return zero_zero_games

    def _get_baseline_prices(
        self, market_id: str, home_token: str, away_token: str
    ) -> tuple[Decimal, Decimal] | None:
        """Fetch baseline BUY prices for home and away tokens.

        Returns None if prices unavailable.
        """
        prices_resp = get_polymarket_prices(market_id=market_id)
        if prices_resp.error is not None:
            print(
                f"[discover] Price fetch error for market {market_id}: "
                f"{prices_resp.error}; skipping"
            )
            return None
        home_price_entry = prices_resp.prices.get(home_token)
        away_price_entry = prices_resp.prices.get(away_token)
        if home_price_entry is None or away_price_entry is None:
            print(f"[discover] Missing price entries for tokens in market {market_id}; skipping")
            return None
        return Decimal(home_price_entry.BUY), Decimal(away_price_entry.BUY)

    def _track_game_with_baseline(
        self,
        event_id: str,
        sport_key: str,
        home_team: str,
        away_team: str,
        market_id: str,
        home_token: str,
        away_token: str,
        baseline_home_buy: Decimal,
        baseline_away_buy: Decimal,
    ) -> None:
        """Store a game in tracked_games with its baseline prices."""
        tracked_games = self._get_tracked_games()
        tracked_games[event_id] = {
            "sport_key": sport_key,
            "market_id": market_id,
            "home_token": home_token,
            "away_token": away_token,
            "home_team": home_team,
            "away_team": away_team,
            "baseline_home_buy": str(baseline_home_buy),
            "baseline_away_buy": str(baseline_away_buy),
        }
        self._set_tracked_games(tracked_games)
        print(
            f"[discover] Tracking game {event_id} -> market {market_id} | "
            f"home_token={home_token} away_token={away_token}"
        )
        print(
            f"[discover] Baselines -> home_buy={baseline_home_buy} " f"away_buy={baseline_away_buy}"
        )

    # ----------------------------------------------
    # Execution Rule 1: Discover & Track New Games
    # ----------------------------------------------
    @cron(interval="5m")
    def discover_and_track_new_live_games(self) -> None:
        print("[discover_and_track_new_live_games] ENTER")

        zero_zero_games = self._find_zero_zero_live_games()
        tracked_games = self._get_tracked_games()

        for game in zero_zero_games:
            event_id = game["event_id"]
            if event_id in tracked_games:
                print(f"[discover] Already tracking game {event_id}; skipping")
                continue

            home_team = game["home_team"]
            away_team = game["away_team"]
            sport_key = game["sport_key"]

            try:
                polymarket_event_id = self._find_polymarket_event_for_teams(home_team, away_team)
                market_id, home_token, away_token = self._map_market_tokens_to_teams(
                    polymarket_event_id, home_team, away_team
                )
            except ValueError as e:
                print(f"[discover] Error mapping game {event_id}: {e}; skipping")
                continue

            baseline_prices = self._get_baseline_prices(market_id, home_token, away_token)
            if baseline_prices is None:
                continue
            baseline_home_buy, baseline_away_buy = baseline_prices

            self._track_game_with_baseline(
                event_id,
                sport_key,
                home_team,
                away_team,
                market_id,
                home_token,
                away_token,
                baseline_home_buy,
                baseline_away_buy,
            )

        print("[discover_and_track_new_live_games] EXIT")

    def _get_current_score_event(self, event_id: str, sport_key: str) -> Any | None:
        """Retrieve the current score event for a tracked game. Returns None if not found."""
        scores_resp = get_scores(sport=sport_key, days_from=1)
        if not scores_resp.success:
            raise ValueError(f"get_scores failed for sport={sport_key}")
        for ev in scores_resp.data:
            if ev.id == event_id:
                return ev
        print(f"[first_score] Event {event_id} not found in current {sport_key} scores; skipping")
        return None

    def _identify_first_scorer(self, cur_home: int, cur_away: int, event_id: str) -> str | None:
        """Determine which team scored first. Returns 'HOME', 'AWAY', or None.

        Returns None if still 0-0 or if both teams have scored (ambiguous).
        Removes event from tracking if ambiguous.
        """
        if cur_home > 0 and cur_away == 0:
            return "HOME"
        if cur_away > 0 and cur_home == 0:
            return "AWAY"
        if cur_home > 0 and cur_away > 0:
            print(
                f"[first_score] Both teams scored for {event_id}; "
                f"removing from tracking (ambiguous first scorer)"
            )
            tracked_games = self._get_tracked_games()
            del tracked_games[event_id]
            self._set_tracked_games(tracked_games)
            return None
        print(f"[first_score] Still 0-0 for {event_id}; continue monitoring")
        return None

    def _execute_conditional_buy(
        self,
        token_id: str,
        team: str,
        baseline: Decimal,
        market_id: str,
    ) -> None:
        """Execute buy order if price increase is <= 10% from baseline."""
        prices_resp = get_polymarket_prices(market_id=market_id)
        if prices_resp.error is not None:
            raise ValueError(f"get_polymarket_prices error: {prices_resp.error}")
        price_entry = prices_resp.prices.get(token_id)
        if price_entry is None:
            raise ValueError(f"No price data for token {token_id} in market {market_id}")

        current_buy = Decimal(price_entry.BUY)
        pct_increase = (current_buy - baseline) / baseline * Decimal(100)
        print(
            f"[first_score] Team '{team}' scored first. Baseline={baseline} "
            f"CurrentBUY={current_buy} Increase%={pct_increase}"
        )

        if pct_increase <= Decimal(10):
            amount = Decimal(8)
            print(f"[first_score] Threshold met (<=10%). Buying {amount} USDC of token {token_id}")
            buy_res = polymarket_buy_token(token_id=token_id, amount=amount)
            if buy_res.error is not None:
                raise ValueError(f"Buy error for token {token_id}: {buy_res.error}")
            order = buy_res.result
            print(
                f"[first_score] BUY EXECUTED | success={order.success} "
                f"order_id={order.order_id} executed_price={order.executed_price} "
                f"executed_amount={order.executed_amount}"
            )
            open_positions = self._get_open_positions()
            open_positions[token_id] = {
                "market_id": market_id,
                "team": team,
                "entry_price": str(order.executed_price),
                "amount": str(order.executed_amount),
            }
            self._set_open_positions(open_positions)
        else:
            print(
                f"[first_score] Threshold NOT met (>10%). "
                f"No buy for token {token_id} at price {current_buy}"
            )

    # -------------------------------------------------
    # Execution Rule 2: Monitor First Score & Conditional Buy
    # -------------------------------------------------
    @cron(interval="1m")
    def monitor_tracked_games_for_first_score(self) -> None:
        print("[monitor_tracked_games_for_first_score] ENTER")

        tracked_games = self._get_tracked_games()
        for event_id in list(tracked_games.keys()):
            tg = tracked_games[event_id]
            sport_key = tg["sport_key"]
            market_id = tg["market_id"]
            home_token = tg["home_token"]
            away_token = tg["away_token"]
            home_team = tg["home_team"]
            away_team = tg["away_team"]
            baseline_home_buy: Decimal = Decimal(tg["baseline_home_buy"])
            baseline_away_buy: Decimal = Decimal(tg["baseline_away_buy"])

            target_event = self._get_current_score_event(event_id, sport_key)
            if target_event is None:
                continue

            cur_home, cur_away = self._extract_scores(target_event, home_team, away_team)
            print(f"[first_score] Scores for {event_id}: home={cur_home} away={cur_away}")

            scorer = self._identify_first_scorer(cur_home, cur_away, event_id)
            if scorer is None:
                continue

            token_id = home_token if scorer == "HOME" else away_token
            team = home_team if scorer == "HOME" else away_team
            baseline = baseline_home_buy if scorer == "HOME" else baseline_away_buy

            self._execute_conditional_buy(token_id, team, baseline, market_id)
            tracked_games = self._get_tracked_games()
            del tracked_games[event_id]
            self._set_tracked_games(tracked_games)

        print("[monitor_tracked_games_for_first_score] EXIT")

    def _log_portfolio_summary(self) -> None:
        """Read and log current portfolio summary."""
        portfolio = read_portfolio()
        strategy_data = portfolio.strategy
        wallet_data = portfolio.wallet
        print(
            f"[take_profit] Portfolio | strategy_value={strategy_data.current_value} "
            f"wallet_balance={wallet_data.current_balance}"
        )

    def _calculate_pnl_percent(self, current_price: Decimal, entry_price: Decimal) -> Decimal:
        """Calculate profit/loss percentage."""
        return (current_price - entry_price) / entry_price * Decimal(100)

    def _execute_take_profit_sell(
        self, token_id: str, amount: Decimal, pnl_percent: Decimal
    ) -> None:
        """Execute sell order if 20% profit target is reached."""
        if pnl_percent >= Decimal(20):
            print(f"[take_profit] Target reached (>=20%). Selling ALL {amount} of token {token_id}")
            sell_res = polymarket_sell_token(token_id=token_id, amount=amount)
            if sell_res.error is not None:
                raise ValueError(f"Sell error for token {token_id}: {sell_res.error}")
            sell_order = sell_res.result
            print(
                f"[take_profit] SELL EXECUTED | success={sell_order.success} "
                f"order_id={sell_order.order_id} executed_price={sell_order.executed_price} "
                f"executed_amount={sell_order.executed_amount}"
            )
            open_positions = self._get_open_positions()
            del open_positions[token_id]
            self._set_open_positions(open_positions)
        else:
            print(
                f"[take_profit] Target not reached for token {token_id}. "
                f"Holding position. PnL%={pnl_percent}"
            )

    # -------------------------------------
    # Execution Rule 3: 20% Take-Profit Sell
    # -------------------------------------
    @cron(interval="5m")
    def monitor_open_positions_and_take_profit(self) -> None:
        print("[monitor_open_positions_and_take_profit] ENTER")

        self._log_portfolio_summary()

        open_positions = self._get_open_positions()
        tokens_to_check = list(open_positions.keys())
        print(f"[take_profit] Tracked open positions: {len(tokens_to_check)}")

        for token_id in tokens_to_check:
            pos = open_positions[token_id]
            market_id = pos["market_id"]
            entry_price: Decimal = Decimal(pos["entry_price"])
            amount: Decimal = Decimal(pos["amount"])
            team = pos["team"]
            print(
                f"[take_profit] Checking token {token_id} for team '{team}' | "
                f"entry_price={entry_price} amount={amount}"
            )

            prices_resp = get_polymarket_prices(market_id=market_id)
            if prices_resp.error is not None:
                raise ValueError(f"get_polymarket_prices error: {prices_resp.error}")
            price_entry = prices_resp.prices.get(token_id)
            if price_entry is None:
                raise ValueError(f"No price data for token {token_id} in market {market_id}")

            current_price = Decimal(price_entry.SELL)
            print(f"[take_profit] Current SELL price: {current_price}")

            pnl_percent = self._calculate_pnl_percent(current_price, entry_price)
            print(f"[take_profit] PnL% computed: {pnl_percent}")

            self._execute_take_profit_sell(token_id, amount, pnl_percent)

        print("[monitor_open_positions_and_take_profit] EXIT")
