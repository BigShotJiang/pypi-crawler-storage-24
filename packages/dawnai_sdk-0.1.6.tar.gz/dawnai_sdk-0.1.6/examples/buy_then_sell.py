"""Simple buy-then-sell example strategy on polymarket prediction markets.

Strategy rules:

Name: Buy then sell Yes token for Bitcoin $130k
Condition:
1. Read portfolio to see if we have an open position for the yes token (market ID: 516865)
2. If we don't have an open position: buy $1000 of the yes token
3. If we do have an open position and if PnL > +10% or PnL < -10%,
    sell all tokens and terminate the strategy
4. Otherwise, hold position
5. Run this rule every 5 minutes
"""

import sys
from decimal import Decimal

from dawnai.strategy import Strategy, cron
from dawnai.strategy.tools import (
    WalletPosition,
    get_polymarket_market_details,
    get_state,
    polymarket_buy_token,
    polymarket_sell_token,
    read_portfolio,
    set_state,
    terminate_strategy,
)


class MyStrategy(Strategy):
    def __init__(self) -> None:
        super().__init__()
        self.BITCOIN_130K_MARKET_ID = "516865"  # ID of the market to trade
        self.INITIAL_CAPITAL = Decimal("1000.0")  # USDC
        self.MAX_POSITION_SIZE = self.INITIAL_CAPITAL * Decimal("1.0")  # 100% of initial capital
        self.TAKE_PROFIT_THRESHOLD = Decimal("10.0")  # 10% profit target
        self.STOP_LOSS_THRESHOLD = Decimal("-10.0")  # 10% loss target

    def _get_yes_token_id(self, market_id: str) -> str | None:
        # Get the yes token ID from state if it exists
        yes_token_id: str | None = get_state("yes_token_id")

        if yes_token_id is None:
            # Get and cache the yes token ID
            market_details = get_polymarket_market_details(market_id)
            yes_token_id = None

            if market_details is None:
                print(f"[Error] Failed to get market details for market {market_id}")
                return None

            if market_details.tokens is None or len(market_details.tokens) < 2:
                print(f"[Error] Failed to get tokens for market {market_id}")
                return None

            yes_token_id = (
                market_details.tokens[0].id
                if market_details.tokens[0].outcome.lower() == "yes"
                else market_details.tokens[1].id
            )
            set_state("yes_token_id", yes_token_id)

        return yes_token_id

    def _step_1_read_portfolio_for_open_position(self, yes_token_id: str) -> WalletPosition | None:
        print(
            f"Step 1: Reading portfolio to see if we have a position yet for token {yes_token_id}"
        )
        portfolio = read_portfolio()

        for position in portfolio.wallet.positions:
            if position.token_id == yes_token_id:
                print(f"Found market position: {position}")
                return position

        print(f"No market position found for token {yes_token_id}")
        return None

    def _step_2_buy_if_no_position(
        self, yes_token_id: str, position: WalletPosition | None
    ) -> bool:
        print(
            f"""Step 2: If we don't have an open position, buy {
                self.MAX_POSITION_SIZE
            } of the yes token."""
        )
        if position is None or position.amount == Decimal("0.0"):
            print("No market position found, buying yes token")
            buy_token_result = polymarket_buy_token(yes_token_id, self.MAX_POSITION_SIZE)

            if not buy_token_result.result.success:
                print(f"[Error] Failed to buy yes token: {buy_token_result.error}")
                return False

            executed_amount = buy_token_result.result.executed_amount.quantize(Decimal("0.01"))
            executed_cost = buy_token_result.result.executed_price * executed_amount
            executed_cost = executed_cost.quantize(Decimal("0.01"))
            print(f"Bought {executed_amount} yes tokens for ${executed_cost}")
            return True

        return False

    def _step_3_sell_if_threshold_hit(self, yes_token_id: str, position: WalletPosition) -> bool:
        """Return True if we sold, False otherwise."""
        print(
            f"""Step 3: If we have a position and PnL > {self.TAKE_PROFIT_THRESHOLD}% or PnL < {
                self.STOP_LOSS_THRESHOLD
            }%, sell all tokens and terminate."""
        )
        if position.amount > Decimal("0.0"):
            hit_take_profit = position.pnl_percent > self.TAKE_PROFIT_THRESHOLD
            hit_stop_loss = position.pnl_percent < self.STOP_LOSS_THRESHOLD

            if hit_take_profit or hit_stop_loss:
                if hit_take_profit:
                    print("Hit take profit")
                if hit_stop_loss:
                    print("Hit stop loss")

                print("Liquidating position...")
                sell_token_result = polymarket_sell_token(yes_token_id, position.amount)

                if not sell_token_result.result.success:
                    print(f"[Error] Failed to sell yes token: {sell_token_result.error}")
                    return False

                executed_amount = sell_token_result.result.executed_amount.quantize(Decimal("0.01"))
                executed_cost = sell_token_result.result.executed_price * executed_amount
                executed_cost = executed_cost.quantize(Decimal("0.01"))
                print(f"Liquidated {executed_amount} yes tokens for ${executed_cost}")
                print("Terminating strategy...")
                terminate_strategy()
                sys.exit(0)

        return False

    def _step_4_hold_position(self) -> None:
        print("Step 4: No threshold hit, holding position")

    @cron(interval="5m")
    def buy_then_sell_yes_token_for_bitcoin_130k(self) -> None:
        """Execute the buy-then-sell strategy following the documented steps."""
        yes_token_id = self._get_yes_token_id(self.BITCOIN_130K_MARKET_ID)
        if yes_token_id is None:
            print(f"[Error] Failed to get yes token ID for market {self.BITCOIN_130K_MARKET_ID}")
            return

        # Step 1: Read portfolio to see if we have an open position
        position = self._step_1_read_portfolio_for_open_position(yes_token_id)

        # Step 2: If we don't have an open position, buy $1000 of the yes token
        bought = self._step_2_buy_if_no_position(yes_token_id, position)
        if bought:
            return

        # Step 3: If we have a position and PnL thresholds are hit, sell and terminate
        if position is not None:
            sold = self._step_3_sell_if_threshold_hit(yes_token_id, position)
            if sold:
                return

            # Step 4: Otherwise, hold position
            self._step_4_hold_position()


if __name__ == "__main__":
    strategy = MyStrategy()
    strategy.buy_then_sell_yes_token_for_bitcoin_130k()
