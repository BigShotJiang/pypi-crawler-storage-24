"""Example strategy that uses the run_agent tool to find catalyst events and trade on them.

The run_agent tool should be used when working with qualitative data
    that requires dynamic multi-step reasoning.

Strategy rules:

1. Find top trending news that has been published on baseball in the last 5 minutes
3. Based on the news, find relevant event market(s)
4. Assess whether the events are mispriced
    - E.g. if the news indicates an outcome that is not aligned with the market / event probability
5. If there is a mis-price, make a trade on the market(s)
6. Respond with a summary of your analysis
"""

from dawnai.strategy import Strategy, cron
from dawnai.strategy.tools import (
    get_tweet_info,
    get_user_tweets,
    run_agent,
    search_tweets,
)


class CatalystStrategy(Strategy):
    """Find trending news, correlate with relevant mis-priced markets, and trade on them."""

    def __init__(self) -> None:
        super().__init__()
        self.initial_capital = 1000.0  # USDC
        self.max_position_size = self.initial_capital * 1.0  # 100% of initial capital

    @cron(interval="1h")
    def find_trending_news_and_trade(self) -> None:
        # This task requires dynamic multi-step reasoning, so we use the run_agent tool.
        print("Finding trending news and trading on them...")
        run_agent_prompt = """
            Find top trending news that has been published on baseball in the last 5 minutes.
            Based on the news, find relevant event market(s).
            Assess whether the events are mis-priced, e.g. if the news indicates
                an outcome that is not aligned with the market / event probability.
            If there is a mis-price, make a trade on the market(s).
            Respond with a summary of your analysis.
        """
        trending_news = run_agent(
            prompt=run_agent_prompt,
            informational_tools=True,
            execution_tools=True,
        )
        print(trending_news)

    def explore_twitter_search(self) -> None:
        """Demonstrate Twitter search with various parameters and queries."""
        print("=== Twitter Search Examples ===\n")

        # Example 1: Basic search for trending topics
        print("1. Searching for Bitcoin trends:")
        try:
            bitcoin_results = search_tweets(query="Bitcoin OR BTC trending", query_type="Top")
            print(f"Raw result: {bitcoin_results}")
            if bitcoin_results.success:
                print(f"Found {bitcoin_results.count} Bitcoin tweets")
                for i, tweet in enumerate(bitcoin_results.tweets[:3], 1):
                    print(f"  {i}. @{tweet.author.name}: {tweet.text[:100]}...")
            else:
                print(f"Search failed with error: {(bitcoin_results.error or 'Unknown error')}")
        except Exception as e:
            print(f"Exception occurred: {type(e).__name__}: {e}")
        print()

        # Example 2: Search for breaking news
        print("2. Searching for breaking news:")
        news_results = search_tweets(query="BREAKING news OR urgent", query_type="Top")
        if news_results.success:
            print(f"Found {news_results.count} breaking news tweets")
            for tweet in news_results.tweets[:2]:
                print(f"  📢 @{tweet.author.name}: {tweet.text[:120]}...")
                print(
                    f"     ❤️ {tweet.like_count} | 🔄 {tweet.retweet_count} | "
                    f"👁️ {tweet.view_count}"
                )
        print()

        # Example 3: Search for sports events with different parameters
        print("3. Searching for sports events:")
        sports_results = search_tweets(query="MLB OR baseball OR World Series", query_type="Top")
        if sports_results.success:
            print(f"Found {sports_results.count} sports tweets")
            # Show engagement metrics
            total_engagement = sum(t.like_count + t.retweet_count for t in sports_results.tweets)
            print(f"  Total engagement: {total_engagement}")

            # Find most engaged tweet
            if sports_results.tweets:
                most_engaged = max(
                    sports_results.tweets, key=lambda t: t.like_count + t.retweet_count
                )
                total_engagement = most_engaged.like_count + most_engaged.retweet_count
                print(
                    f"  Most engaged: @{most_engaged.author.name} with "
                    f"{total_engagement} total engagement"
                )
        print()

        # Example 4: Search for market-related keywords
        print("4. Searching for market sentiment:")
        market_results = search_tweets(
            query="market crash OR bull market OR bear market", query_type="Top"
        )
        if market_results.success:
            sentiment_keywords = ["bullish", "bearish", "crash", "moon", "pump", "dump"]
            sentiment_counts = dict.fromkeys(sentiment_keywords, 0)

            for tweet in market_results.tweets:
                tweet_text = tweet.text.lower()
                for keyword in sentiment_keywords:
                    if keyword in tweet_text:
                        sentiment_counts[keyword] += 1

            print(f"Found {market_results.count} market sentiment tweets")
            print("  Sentiment analysis:")
            for keyword, count in sentiment_counts.items():
                if count > 0:
                    print(f"    {keyword}: {count} mentions")
        print()

        # Example 5: Pagination example
        print("5. Testing pagination:")
        page1_results = search_tweets(query="cryptocurrency", query_type="Top")
        if page1_results.success and page1_results.next_cursor:
            print(f"Page 1: {page1_results.count} results")

            # Get next page
            page2_results = search_tweets(
                query="cryptocurrency", cursor=page1_results.next_cursor, query_type="Top"
            )
            if page2_results.success:
                print(f"Page 2: {page2_results.count} results")
                print(f"  Next cursor available: {bool(page2_results.next_cursor)}")
        print()

        # Example 6: User mentions and hashtag search
        print("6. Searching for hashtags and mentions:")
        hashtag_results = search_tweets(
            query="#AI OR #MachineLearning OR @elonmusk", query_type="Top"
        )
        if hashtag_results.success:
            print(f"Found {hashtag_results.count} hashtag/mention tweets")
            for tweet in hashtag_results.tweets[:3]:
                created_time = tweet.created_at
                print(f"  📅 {created_time}: @{tweet.author.name}")
                print(f"     {tweet.text[:80]}...")
        print()

    def test_twitter_user_and_info_functions(self) -> None:
        """Test the get_user_tweets and get_tweet_info functions."""
        print("=== Testing Twitter User and Tweet Info Functions ===\n")

        # Test 1: Get user tweets
        print("1. Testing get_user_tweets function:")
        test_handles = ["elonmusk", "OpenAI", "naval"]

        for handle in test_handles:
            print(f"\n   Getting tweets from @{handle}:")
            try:
                user_tweets = get_user_tweets(handle)
                print(f"   Raw result: {user_tweets}")

                if user_tweets.success:
                    tweets = user_tweets.tweets
                    print(f"   ✅ Found {len(tweets)} tweets from @{handle}")

                    if tweets:
                        # Show first tweet details
                        first_tweet = tweets[0]
                        print(f"   📝 Latest tweet: {first_tweet.text[:100]}...")
                        print(f"   📅 Posted: {first_tweet.created_at}")
                        print(
                            f"   📊 Engagement: ❤️{first_tweet.like_count} "
                            f"🔄{first_tweet.retweet_count} 👁️{first_tweet.view_count}"
                        )

                        # Test pagination if available
                        if user_tweets.has_next_page and user_tweets.next_cursor:
                            next_cursor = user_tweets.next_cursor
                            if next_cursor:
                                cursor_preview = next_cursor[:20]
                                print(f"   📄 Next page available with cursor: {cursor_preview}...")
                    else:
                        print("   📭 No tweets found")
                else:
                    print(f"   ❌ Failed to get tweets: {(user_tweets.error or 'Unknown error')}")
            except Exception as e:
                print(f"   💥 Exception: {type(e).__name__}: {e}")

        print("\n" + "-" * 50)

        # Test 2: Get tweet info
        print("\n2. Testing get_tweet_info function:")

        # First, collect some tweet IDs from the user tweets we just fetched
        tweet_ids: list[str] = []
        print("   🔍 Collecting tweet IDs from previous searches...")

        for handle in test_handles[:2]:  # Only test first 2 handles to avoid too many API calls
            try:
                user_tweets = get_user_tweets(handle)
                if user_tweets.success and user_tweets.tweets:
                    # Get first 2 tweet IDs from each user
                    tweet_ids.extend(tweet.id for tweet in user_tweets.tweets[:2] if tweet.id)
            except Exception as e:
                print(f"   ⚠️ Error collecting tweet IDs from @{handle}: {e}")

        if tweet_ids:
            print(f"   📋 Collected {len(tweet_ids)} tweet IDs: {tweet_ids[:3]}...")

            try:
                tweet_info = get_tweet_info(tweet_ids)
                print(f"   Raw result: {tweet_info}")

                if tweet_info.success:
                    tweets = tweet_info.tweets
                    print(f"   ✅ Retrieved detailed info for {len(tweets)} tweets")

                    # Analyze the tweets
                    for i, tweet in enumerate(tweets, 1):
                        print(f"\n   Tweet {i}:")
                        print(f"     🆔 ID: {tweet.id}")
                        author_info = f"@{tweet.author.user_name} ({tweet.author.name})"
                        print(f"     👤 Author: {author_info}")
                        print(f"     📝 Text: {tweet.text[:80]}...")
                        print(f"     📅 Created: {tweet.created_at}")
                        print(
                            f"     📊 Stats: ❤️{tweet.like_count} 💬{tweet.reply_count} "
                            f"🔄{tweet.retweet_count} 👁️{tweet.view_count}"
                        )

                        # Check for quoted or retweeted content
                        quoted_tweet = tweet.quoted_tweet
                        if quoted_tweet and quoted_tweet.author:
                            print(f"     📎 Quotes: @{quoted_tweet.author.user_name}")
                        retweeted_tweet = tweet.retweeted_tweet
                        if retweeted_tweet and retweeted_tweet.author:
                            retweet_author = retweeted_tweet.author.user_name
                            print(f"     🔄 Retweets: @{retweet_author}")

                    # Summary statistics
                    total_likes = sum(t.like_count for t in tweets)
                    total_retweets = sum(t.retweet_count for t in tweets)
                    total_views = sum(t.view_count for t in tweets)

                    print("\n   📈 Summary Statistics:")
                    print(f"     Total Likes: {total_likes:,}")
                    print(f"     Total Retweets: {total_retweets:,}")
                    print(f"     Total Views: {total_views:,}")
                    avg_engagement = (total_likes + total_retweets) / len(tweets)
                    print(f"     Average Engagement Rate: {avg_engagement:,.1f}")

                else:
                    error_msg = tweet_info.error or "Unknown error"
                    print(f"   ❌ Failed to get tweet info: {error_msg}")

            except Exception as e:
                print(f"   💥 Exception getting tweet info: {type(e).__name__}: {e}")

        else:
            print("   ⚠️ No tweet IDs collected, skipping tweet info test")

        print("\n" + "-" * 50)

        # Test 3: Combined workflow example
        print("\n3. Combined workflow example:")
        print("   🔄 Finding viral tweets from a specific user and analyzing them...")

        try:
            # Get tweets from a popular tech account
            viral_user = "naval"
            user_tweets = get_user_tweets(viral_user)

            if user_tweets.success and user_tweets.tweets:
                # Filter for high-engagement tweets
                high_engagement_tweets = [
                    tweet
                    for tweet in user_tweets.tweets
                    if (tweet.like_count + tweet.retweet_count) > 100
                ]

                tweet_count = len(high_engagement_tweets)
                print(f"   📊 Found {tweet_count} high-engagement tweets from @{viral_user}")

                if high_engagement_tweets:
                    # Get detailed info for the most viral tweets
                    viral_ids = [tweet.id for tweet in high_engagement_tweets[:3]]
                    detailed_info = get_tweet_info(viral_ids)

                    if detailed_info.success:
                        print(f"   🔍 Analyzed {len(detailed_info.tweets)} viral tweets in detail")

                        for tweet in detailed_info.tweets:
                            engagement = tweet.like_count + tweet.retweet_count
                            tweet_preview = tweet.text[:60]
                            print(
                                f"     🚀 Viral tweet (engagement: {engagement:,}): "
                                f"{tweet_preview}..."
                            )
                else:
                    print(f"   📉 No high-engagement tweets found from @{viral_user}")

        except Exception as e:
            print(f"   💥 Exception in combined workflow: {type(e).__name__}: {e}")

        print("\n" + "=" * 50)


if __name__ == "__main__":
    strategy = CatalystStrategy()
    # Run the original catalyst finding

    # Demonstrate Twitter search functionality

    # Test Twitter user tweets and tweet info functions
    print("\n" + "=" * 50)
    strategy.test_twitter_user_and_info_functions()
