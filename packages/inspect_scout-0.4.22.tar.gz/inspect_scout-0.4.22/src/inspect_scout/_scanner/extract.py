import json
import re
from dataclasses import dataclass
from functools import reduce
from typing import Awaitable, Callable, Generic, Literal, TypeAlias, TypeVar, overload

from inspect_ai.model import (
    ChatMessage,
    ChatMessageAssistant,
    ChatMessageTool,
    Content,
)

from inspect_scout._scanner.result import Reference
from inspect_scout._transcript.types import Transcript

from .util import _message_id

T = TypeVar("T", Transcript, list[ChatMessage])


@dataclass(frozen=True)
class MessageFormatOptions:
    """Message formatting options for controlling message content display.

    These options control which parts of messages are included when
    formatting messages to strings.
    """

    exclude_system: bool = True
    """Exclude system messages (defaults to `True`)"""

    exclude_reasoning: bool = False
    """Exclude reasoning content (defaults to `False`)."""

    exclude_tool_usage: bool = False
    """Exclude tool usage (defaults to `False`)"""


@dataclass(frozen=True)
class MessagesPreprocessor(MessageFormatOptions, Generic[T]):
    """ChatMessage preprocessing transformations.

    Provide a `transform` function for fully custom transformations.
    Use the higher-level options (e.g. `exclude_system`) to
    perform various common content removal transformations.

    The default `MessagesPreprocessor` will exclude system
    messages and do no other transformations.
    """

    transform: Callable[[T], Awaitable[list[ChatMessage]]] | None = None
    """Transform the list of messages."""


@overload
async def messages_as_str(
    input: T,
    *,
    preprocessor: MessagesPreprocessor[T] | None = None,
    as_json: bool = False,
) -> str: ...


@overload
async def messages_as_str(
    input: T,
    *,
    preprocessor: MessagesPreprocessor[T] | None = None,
    include_ids: Literal[True],
    as_json: bool = False,
) -> tuple[str, Callable[[str], list[Reference]]]: ...


async def messages_as_str(
    input: T,
    *,
    preprocessor: MessagesPreprocessor[T] | None = None,
    include_ids: Literal[True] | None = None,
    as_json: bool = False,
) -> str | tuple[str, Callable[[str], list[Reference]]]:
    """Concatenate list of chat messages into a string.

    Args:
       input: The Transcript with the messages or a list of messages.
       preprocessor: Content filter for messages.
       include_ids: If True, prepend ordinal references (e.g., [M1], [M2])
          to each message and return a function to extract references from text.
          If None (default), return plain formatted string.
       as_json: If True, output as JSON string instead of plain text.

    Returns:
       If include_ids is False: Messages concatenated as a formatted string.
       If include_ids is True: Tuple of (formatted string with [M1], [M2], etc.
          prefixes, function that takes text and returns list of Reference objects
          for any [M1], [M2], etc. references found in the text).
    """
    messages = (
        await preprocessor.transform(input)
        if preprocessor is not None and preprocessor.transform is not None
        else input.messages
        if isinstance(input, Transcript)
        else input
    )

    def reduce_message(
        acc: tuple[list[dict[str, str]], dict[str, str]], message: ChatMessage
    ) -> tuple[list[dict[str, str]], dict[str, str]]:
        items, id_map = acc
        if (content := message_as_str(message, preprocessor)) is not None:
            item: dict[str, str] = {"role": message.role, "content": content}
            if include_ids:
                ordinal = f"M{len(id_map) + 1}"
                id_map[ordinal] = _message_id(message)
                item["id"] = ordinal
            items.append(item)
        return items, id_map

    items, id_map = reduce(
        reduce_message, messages, (list[dict[str, str]](), dict[str, str]())
    )

    result = (
        json.dumps(items)
        if as_json
        else "\n".join(
            f"[{item['id']}] {item['content']}" if "id" in item else item["content"]
            for item in items
        )
    )

    return (
        (result, lambda text: _extract_references(text, id_map))
        if include_ids
        else result
    )


MessagesAsStr: TypeAlias = Callable[[list[ChatMessage]], Awaitable[str]]
ExtractReferences: TypeAlias = Callable[[str], list[Reference]]


def message_numbering(
    preprocessor: MessagesPreprocessor[list[ChatMessage]] | None = None,
) -> tuple[MessagesAsStr, ExtractReferences]:
    """Create a messages_as_str / extract_references pair with shared numbering.

    Returns two functions that share a closure-captured counter and id_map.
    Each call to the returned messages_as_str auto-increments message IDs
    globally, so multiple calls produce M1..M5, then M6..M10, etc.

    The returned extract_references resolves citations from ANY prior
    messages_as_str call within this numbering scope.

    Args:
        preprocessor: Message preprocessing options applied to every call
            (e.g., exclude_system, exclude_reasoning). Defaults to excluding
            system messages when no preprocessor is provided.

    Returns:
        Tuple of:
            - messages_as_str: takes list[ChatMessage], returns formatted string with globally unique [M1], [M2], etc. prefixes.
            - extract_refs: takes text, returns list of Reference objects for any [M1], [M2], etc. references found across all prior calls.
    """
    counter = [0]
    id_map: dict[str, str] = {}

    async def _messages_as_str(messages: list[ChatMessage]) -> str:
        if preprocessor is not None and preprocessor.transform is not None:
            messages = await preprocessor.transform(messages)

        items: list[str] = []
        for message in messages:
            content = message_as_str(message, preprocessor)
            if content is not None:
                counter[0] += 1
                ordinal = f"M{counter[0]}"
                id_map[ordinal] = _message_id(message)
                items.append(f"[{ordinal}] {content}")

        return "\n".join(items)

    def _extract_refs(text: str) -> list[Reference]:
        return _extract_references(text, id_map)

    return _messages_as_str, _extract_refs


def message_as_str(
    message: ChatMessage,
    preprocessor: MessageFormatOptions | None = None,
) -> str | None:
    """Convert a ChatMessage to a formatted string representation.

    Args:
        message: The `ChatMessage` to convert.
        preprocessor: Content filter for messages. Defaults to removing system messages.

    Returns:
        A formatted string with the message role and content, or None if the message
        should be excluded based on the provided flags.
    """
    preprocessor = preprocessor or MessageFormatOptions()

    if preprocessor.exclude_system and message.role == "system":
        return None

    content = _better_content_text(
        message.content, preprocessor.exclude_tool_usage, preprocessor.exclude_reasoning
    )

    if (
        not preprocessor.exclude_tool_usage
        and isinstance(message, ChatMessageAssistant)
        and message.tool_calls
    ):
        entry = f"{message.role.upper()}:\n{content}\n"

        for tool in message.tool_calls:
            func_name = tool.function
            args = tool.arguments

            if isinstance(args, dict):
                args_text = "\n".join(f"{k}: {v}" for k, v in args.items())
                entry += f"\nTool Call: {func_name}\nArguments:\n{args_text}\n"
            else:
                entry += f"\nTool Call: {func_name}\nArguments: {args}\n"

        return entry

    elif isinstance(message, ChatMessageTool):
        if preprocessor.exclude_tool_usage:
            return None
        func_name = message.function or "unknown"
        error_part = (
            f"\n\nError in tool call '{func_name}':\n{message.error.message}\n"
            if message.error
            else ""
        )
        return f"{message.role.upper()}:\n{content}{error_part}\n"

    else:
        return f"{message.role.upper()}:\n{content}\n"


def _text_from_content(
    content: Content, exclude_tool_usage: bool, exclude_reasoning: bool
) -> str | None:
    match content.type:
        case "text":
            return content.text
        case "reasoning":
            return (
                None
                if (
                    exclude_reasoning
                    or not (
                        reasoning := content.summary
                        if content.redacted
                        else content.reasoning
                    )
                )
                # We need to bracket it with a start/finish since it could be multiple
                # lines long, and we need to distinguish it from content text's
                else f"\n<think>{reasoning}</think>"
            )

        case "tool_use":
            return (
                None
                if exclude_tool_usage
                else f"\nTool Use: {content.name}({content.arguments}) -> {content.result} {content.error if content.error else ''}"
            )
        case "image" | "audio" | "video" | "data" | "document":
            return f"<{content.type} />"


def _better_content_text(
    content: str | list[Content],
    exclude_tool_usage: bool,
    exclude_reasoning: bool,
) -> str:
    if isinstance(content, str):
        return content
    else:
        all_text = [
            text
            for c in content
            if (text := _text_from_content(c, exclude_tool_usage, exclude_reasoning))
            is not None
        ]
        return "\n".join(all_text)


def _extract_references(text: str, id_map: dict[str, str]) -> list[Reference]:
    """Extract message and event references from text.

    Args:
        text: Text containing [M{n}], [E{n}], M{n}, or E{n} style references
        id_map: Dict mapping ordinal IDs (e.g., "M1", "M2", "E1", "E2") to actual IDs

    Returns:
        List of Reference objects with type="message" or type="event"
    """
    # Match bracketed [M1]/[E1] or bare M1/E1 with word boundaries
    pattern = r"\[(M|E)\d+\]|\b(M|E)\d+\b"
    matches = re.finditer(pattern, text)

    references = []
    seen_ids = set()

    for match in matches:
        cite = match.group(0)
        # Extract ordinal key: "M1" from "[M1]" or "M1" from bare "M1"
        ordinal_key = cite[1:-1] if cite.startswith("[") else cite

        # Look up actual ID
        if ordinal_key in id_map:
            actual_id = id_map[ordinal_key]
            # Avoid duplicate references
            if actual_id not in seen_ids:
                ref_type: Literal["message", "event"] = (
                    "message" if ordinal_key.startswith("M") else "event"
                )
                references.append(Reference(type=ref_type, cite=cite, id=actual_id))
                seen_ids.add(actual_id)

    return references


def tool_callers(
    transcript: Transcript,
) -> dict[str, tuple[ChatMessageAssistant, int]]:
    """
    Build a mapping from tool_call_id to the assistant message that made the call.

    This is useful for scanners that need to reference the assistant message
    that initiated a tool call, rather than the tool message itself.

    Args:
        transcript: The transcript containing all messages.

    Returns:
        A dictionary mapping tool_call_id to a tuple of (assistant_message, message_index).
        The message_index is 1-indexed to match the [M1], [M2], etc. citation format.
    """
    tool_call_to_assistant: dict[str, tuple[ChatMessageAssistant, int]] = {}

    for i, message in enumerate(transcript.messages, start=1):
        if isinstance(message, ChatMessageAssistant) and message.tool_calls:
            for tool_call in message.tool_calls:
                tool_call_to_assistant[tool_call.id] = (message, i)

    return tool_call_to_assistant
