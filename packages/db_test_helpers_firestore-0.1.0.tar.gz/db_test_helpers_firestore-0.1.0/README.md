# db-test-helpers-firestore

Firestore adapter for [db-test-helpers](https://github.com/takaaa220/db-test-helpers).

## Installation

```bash
pip install db-test-helpers-firestore
```

## Documentation

See the [main repository](https://github.com/takaaa220/db-test-helpers) for usage and documentation.
