"""Shared fixtures for Firestore adapter tests."""

from __future__ import annotations

import os

import pytest
from google.cloud import firestore


@pytest.fixture
def db():
    port = os.environ.get("FIRESTORE_PORT", "8080")
    os.environ.setdefault("FIRESTORE_EMULATOR_HOST", f"localhost:{port}")
    client = firestore.Client(project="demo-project")
    yield client
    _cleanup(client)


def _cleanup(client: firestore.Client) -> None:
    for collection in client.collections():
        _delete_collection(client, collection)


def _delete_collection(client: firestore.Client, col_ref) -> None:
    for doc in col_ref.stream():
        for sub_col in doc.reference.collections():
            _delete_collection(client, sub_col)
        doc.reference.delete()
