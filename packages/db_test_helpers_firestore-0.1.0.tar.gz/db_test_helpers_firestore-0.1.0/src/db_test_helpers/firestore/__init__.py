"""db-test-helpers-firestore: Firestore adapter for db-test-helpers."""

from db_test_helpers.firestore._adapter import FirestoreAdapter

__all__ = ["FirestoreAdapter"]
