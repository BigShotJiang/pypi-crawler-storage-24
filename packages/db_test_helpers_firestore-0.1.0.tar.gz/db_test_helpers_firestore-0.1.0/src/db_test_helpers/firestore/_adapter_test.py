"""Tests for FirestoreAdapter."""

from __future__ import annotations

from db_test_helpers.firestore._adapter import FirestoreAdapter


class TestWriteRecord:
    def test_write_with_doc_id(self, db):
        adapter = FirestoreAdapter(db)
        result = adapter.write_record("users", "", {"__document_id__": "user-1", "name": "Alice"})

        assert result["__document_id__"] == "user-1"
        assert result["name"] == "Alice"

        doc = db.collection("users").document("user-1").get()
        assert doc.exists
        assert doc.to_dict()["name"] == "Alice"
        assert "__document_id__" not in doc.to_dict()

    def test_write_without_doc_id_auto_generates(self, db):
        adapter = FirestoreAdapter(db)
        result = adapter.write_record("users", "", {"name": "Bob"})

        assert "__document_id__" in result
        assert result["__document_id__"] is not None
        assert len(result["__document_id__"]) > 0
        assert result["name"] == "Bob"

    def test_write_with_none_doc_id_auto_generates(self, db):
        adapter = FirestoreAdapter(db)
        result = adapter.write_record("users", "", {"__document_id__": None, "name": "Carol"})

        assert result["__document_id__"] is not None
        assert len(result["__document_id__"]) > 0

    def test_write_with_parent_path(self, db):
        adapter = FirestoreAdapter(db)
        db.collection("users").document("user-1").set({"name": "Alice"})
        result = adapter.write_record("posts", "users/user-1", {"__document_id__": "post-1", "title": "Hello"})

        doc = db.collection("users").document("user-1").collection("posts").document("post-1").get()
        assert doc.exists
        assert doc.to_dict()["title"] == "Hello"
        assert result["__document_id__"] == "post-1"

    def test_write_iso8601_to_timestamp(self, db):
        adapter = FirestoreAdapter(db)
        adapter.write_record(
            "users", "", {"__document_id__": "user-1", "created_at": "2024-01-01T00:00:00Z"}
        )

        doc = db.collection("users").document("user-1").get()
        data = doc.to_dict()
        from datetime import datetime

        assert isinstance(data["created_at"], datetime)


class TestReadRecords:
    def test_read_empty(self, db):
        adapter = FirestoreAdapter(db)
        result = adapter.read_records("users", "")
        assert result == []

    def test_read_records(self, db):
        adapter = FirestoreAdapter(db)
        db.collection("users").document("user-1").set({"name": "Alice", "age": 30})
        db.collection("users").document("user-2").set({"name": "Bob", "age": 25})

        result = adapter.read_records("users", "")
        assert len(result) == 2

        ids = {r["__document_id__"] for r in result}
        assert ids == {"user-1", "user-2"}

        for r in result:
            assert "__document_id__" in r
            assert "name" in r

    def test_read_with_parent_path(self, db):
        adapter = FirestoreAdapter(db)
        db.collection("users").document("user-1").set({"name": "Alice"})
        db.collection("users").document("user-1").collection("posts").document("post-1").set({"title": "Hello"})

        result = adapter.read_records("posts", "users/user-1")
        assert len(result) == 1
        assert result[0]["__document_id__"] == "post-1"
        assert result[0]["title"] == "Hello"

    def test_read_timestamp_to_iso8601(self, db):
        from datetime import UTC, datetime

        adapter = FirestoreAdapter(db)
        db.collection("users").document("user-1").set({"created_at": datetime(2024, 1, 1, tzinfo=UTC)})

        result = adapter.read_records("users", "")
        assert isinstance(result[0]["created_at"], str)
        assert result[0]["created_at"] == "2024-01-01T00:00:00Z"

    def test_read_timestamp_roundtrip(self, db):
        """write with ISO 8601 Z -> read back as same Z format"""
        adapter = FirestoreAdapter(db)
        adapter.write_record("users", "", {"__document_id__": "u1", "ts": "2024-06-15T12:30:00Z"})

        result = adapter.read_records("users", "")
        assert result[0]["ts"] == "2024-06-15T12:30:00Z"

    def test_nested_timestamp_conversion(self, db):
        from datetime import UTC, datetime

        adapter = FirestoreAdapter(db)
        db.collection("users").document("user-1").set({
            "meta": {"created_at": datetime(2024, 1, 1, tzinfo=UTC)},
            "timestamps": [datetime(2024, 6, 1, tzinfo=UTC)],
        })

        result = adapter.read_records("users", "")
        assert result[0]["meta"]["created_at"] == "2024-01-01T00:00:00Z"
        assert result[0]["timestamps"][0] == "2024-06-01T00:00:00Z"


class TestClearGroup:
    def test_clear_group(self, db):
        adapter = FirestoreAdapter(db)
        db.collection("users").document("user-1").set({"name": "Alice"})
        db.collection("users").document("user-2").set({"name": "Bob"})

        adapter.clear_group("users", "")
        docs = list(db.collection("users").get())
        assert len(docs) == 0

    def test_clear_group_recursive(self, db):
        adapter = FirestoreAdapter(db)
        db.collection("users").document("user-1").set({"name": "Alice"})
        db.collection("users").document("user-1").collection("posts").document("post-1").set({"title": "Hello"})

        adapter.clear_group("users", "")
        docs = list(db.collection("users").get())
        assert len(docs) == 0


class TestBuildChildPath:
    def test_root_level(self):
        adapter = FirestoreAdapter(None)
        result = adapter.build_child_path("", "users", {"__document_id__": "user-1", "name": "Alice"})
        assert result == "users/user-1"

    def test_nested(self):
        adapter = FirestoreAdapter(None)
        result = adapter.build_child_path("users/user-1", "posts", {"__document_id__": "post-1", "title": "Hello"})
        assert result == "users/user-1/posts/post-1"
