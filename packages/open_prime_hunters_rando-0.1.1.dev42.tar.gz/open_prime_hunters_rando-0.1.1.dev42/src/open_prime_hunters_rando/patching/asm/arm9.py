from pathlib import Path

from ndspy.rom import NintendoDSRom

from open_prime_hunters_rando.patching.asm.asm_patching import NOP, create_asm_patch, read_asm_file
from open_prime_hunters_rando.patching.version_checking import get_rom_save_data_addresses

asm_patches = Path(__file__).parent.joinpath("patches")


def patch_arm9(rom: NintendoDSRom, configuration: dict) -> None:
    addresses = get_rom_save_data_addresses(rom)

    starting_items = configuration["starting_items"]
    game_patches = configuration["game_patches"]
    ammo_sizes = configuration["ammo_sizes"]

    # Validate starting items
    _validate_starting_items(starting_items)

    etanks = starting_items["energy_tanks"]
    tanks_to_energy = etanks * 100 if etanks > 0 else 100
    starting_energy = tanks_to_energy.to_bytes(4, "little")

    starting_ammo = str(hex(starting_items["ammo"] * 10))[2:-1]

    reordered_instructions = read_asm_file("reordered_instructions.s")

    custom_missile_launcher = read_asm_file("missile_launcher.s").replace("#0x32", f"#{ammo_sizes['missile_launcher']}")

    ARM9_PATCHES: dict[int, bytes] = {
        addresses.missiles_per_expansion: create_asm_patch(
            f"add r2, r2, #{ammo_sizes['missile_expansion'] * 10}"
        ),  # Missiles per expansion
        addresses.ammo_per_expansion: create_asm_patch(
            f"add r2, r2, #{ammo_sizes['ua_expansion'] * 10}"
        ),  # UA per expansion
        addresses.starting_octoliths: _bitfield_to_hex(starting_items["octoliths"]),  # Starting Octoliths (0-8)
        addresses.starting_weapons: _bitfield_to_hex(starting_items["weapons"]),  # Starting weapons
        addresses.weapon_slots: NOP,  # Prevents deleting the weapons when changing Octoliths
        addresses.starting_ammo: bytes.fromhex(starting_ammo),  # Starting Universal Ammo
        addresses.starting_energy: NOP,  # Normally loads value of etank (100)
        addresses.starting_missiles: (starting_items["missiles"] * 10).to_bytes(),  # Starting Missiles
        addresses.reordered_instructions: create_asm_patch(
            reordered_instructions
        ),  # Changing R0 affects later instructions, so reorder
        addresses.unlock_planets: _unlock_planets(game_patches["unlock_planets"]),  # Unlock planets from start
        addresses.starting_energy_ptr: starting_energy,  # Starting energy - 1
        addresses.missile_launcher: create_asm_patch(
            custom_missile_launcher
        ),  # Load instructions to create a custom Missile Launcher
        addresses.nothing: create_asm_patch(read_asm_file("nothing.s")),  # Add Nothing item
    }

    # Decompress arm9.bin for editing
    arm9 = rom.loadArm9()
    # Load the addresses and bytes
    for target_address, bytes_to_change in ARM9_PATCHES.items():
        # Search for the offset to modify
        for section in arm9.sections:
            if section.ramAddress <= target_address < section.ramAddress + len(section.data):
                offset_in_section = target_address - section.ramAddress
                section.data = bytearray(section.data)
                # Edit the offset with the new bytes
                section.data[offset_in_section : offset_in_section + len(bytes_to_change)] = bytes_to_change
                break

    # Save arm9.bin with the new changes
    rom.arm9 = arm9.save()


def _validate_starting_items(starting_items: dict) -> None:
    bitfields = ["weapons", "octoliths"]
    # Validate weapons and octoliths bitfields
    for bitfield in bitfields:
        if len(starting_items[bitfield]) != 8:
            raise ValueError(
                f"Invalid starting {bitfield} bitfield. Must contain 8 numbers, got {len(starting_items[bitfield])}!"
            )

        for bitflag in starting_items[bitfield]:
            if bitflag not in ["0", "1"]:
                raise ValueError(f"Invalid starting {bitfield} bitfield. Must only contain 0 or 1, got {bitflag}!")

    # Validate starting ammo
    if starting_items["ammo"] > 400:
        raise ValueError(f"Starting ammo must be 400 or less! Got {starting_items['ammo']}")


def _bitfield_to_hex(bitfield: str) -> bytes:
    return int(bitfield, 2).to_bytes()


def _unlock_planets(unlock_planets: dict) -> bytes:
    planets = [
        unlock_planets["Arcterra"],  # Arcterra 1
        unlock_planets["Arcterra"],  # Arcterra 2
        unlock_planets["Vesper Defense Outpost"],  # Vesper Defense Outpost 1
        unlock_planets["Vesper Defense Outpost"],  # Vesper Defense Outpost 2
        True,  # Celestial Archives 1 (Always unlocked)
        True,  # Celestial Archives 2 (Always unlocked)
        unlock_planets["Alinos"],  # Alinos 1
        unlock_planets["Alinos"],  # Alinos 2
    ]

    fmt = "{:d}" * 8
    planets_to_unlock = fmt.format(*planets)
    return _bitfield_to_hex(planets_to_unlock)
