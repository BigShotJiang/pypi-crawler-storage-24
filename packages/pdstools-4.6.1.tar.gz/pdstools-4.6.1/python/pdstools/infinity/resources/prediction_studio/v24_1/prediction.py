from typing import TYPE_CHECKING, Any, Literal
from collections.abc import Callable

import polars as pl
from pydantic import validate_call

from .....utils import cdh_utils
from ....internal._constants import METRIC
from ....internal._exceptions import NoMonitoringInfo
from ....internal._resource import api_method
from ..base import AsyncPrediction as AsyncPredictionBase
from ..base import Prediction as PredictionBase


class _PredictionV24_1Mixin:
    """v24.1 Prediction business logic — defined once."""

    # Declared for mypy — provided by concrete base classes at runtime
    if TYPE_CHECKING:
        prediction_id: str
        _a_get: Callable[..., Any]

    @api_method
    @validate_call
    async def get_metric(
        self,
        *,
        metric: METRIC,
        timeframe: Literal["7d", "4w", "3m", "6m"],
    ) -> pl.DataFrame:
        endpoint = f"/prweb/api/PredictionStudio/v1/predictions/{self.prediction_id}/metric/{metric}"
        try:
            info = await self._a_get(endpoint, time_frame=timeframe)
            data = (
                pl.DataFrame(
                    info["monitoringData"],
                    schema={
                        "value": pl.Utf8,
                        "snapshotTime": pl.Utf8,
                        "dataUsage": pl.Utf8,
                    },
                )
                .with_columns(
                    snapshotTime=cdh_utils.parse_pega_date_time_formats(
                        "snapshotTime",
                        "%Y-%m-%dT%H:%M:%S%.fZ",
                    ),
                    value=pl.col("value").replace("", None).cast(pl.Float64),
                    category=pl.col("dataUsage"),
                )
                .drop("dataUsage")
            )
            return data
        except NoMonitoringInfo:
            data = pl.DataFrame(
                schema={
                    "value": pl.Float64,
                    "snapshotTime": pl.Datetime("ns"),
                    "category": pl.Utf8,
                },
            )
            return data

    @api_method
    async def describe(self):
        endpoint = f"/prweb/api/PredictionStudio/v3/predictions/{self.prediction_id}"
        return await self._a_get(endpoint)


class Prediction(_PredictionV24_1Mixin, PredictionBase):
    pass


class AsyncPrediction(_PredictionV24_1Mixin, AsyncPredictionBase):
    pass
