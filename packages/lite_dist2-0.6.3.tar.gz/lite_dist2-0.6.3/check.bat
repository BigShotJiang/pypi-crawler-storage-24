uv run ruff format
uv run ruff check --fix
uv run ty check
uv run pytest