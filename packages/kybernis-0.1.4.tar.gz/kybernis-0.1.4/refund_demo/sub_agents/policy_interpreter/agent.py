from google.adk.agents.llm_agent import Agent
from google.adk.tools import FunctionTool
from google.adk.tools.agent_tool import AgentTool

from .prompt import PROMPT
from .tools import fetch_policy_snapshot


policy_tool = FunctionTool(func=fetch_policy_snapshot)

policy_interpreter_agent = Agent(
    model="gemini-2.5-flash",
    name="refund_policy_interpreter",
    description="Interprets versioned refund policy into structured decision signals.",
    instruction=PROMPT,
    tools=[policy_tool],
    output_key="policy_interpreter_output",
)

agent = policy_interpreter_agent
tool = AgentTool(agent=policy_interpreter_agent)
PROMPT = PROMPT

