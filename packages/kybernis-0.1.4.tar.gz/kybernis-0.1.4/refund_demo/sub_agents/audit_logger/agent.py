from google.adk.agents.llm_agent import Agent
from google.adk.tools.agent_tool import AgentTool

from .prompt import PROMPT


audit_logger_agent = Agent(
    model="gemini-2.5-flash",
    name="refund_audit_logger",
    description="Builds a structured audit summary for refund decisions.",
    instruction=PROMPT,
    tools=[],
    output_key="audit_logger_output",
)

agent = audit_logger_agent
tool = AgentTool(agent=audit_logger_agent)
PROMPT = PROMPT

