import importlib
from google.adk.agents.llm_agent import Agent
from google.adk.tools import FunctionTool
from google.adk.tools.agent_tool import AgentTool
from .prompt import PROMPT
from .tools import lookup_recent_payments, issue_refund


lookup_tool = FunctionTool(func=lookup_recent_payments)
refund_tool = FunctionTool(func=issue_refund)

executor_agent = Agent(
    model="gemini-2.5-flash",
    name="refund_executor",
    description="Finds duplicate charge and attempts one refund.",
    instruction=PROMPT,
    tools=[lookup_tool, refund_tool],
    output_key="executor_output",
)

agent = executor_agent
tool = AgentTool(agent=executor_agent)
PROMPT = PROMPT