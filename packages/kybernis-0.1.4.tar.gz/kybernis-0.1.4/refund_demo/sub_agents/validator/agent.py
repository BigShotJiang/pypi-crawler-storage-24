from google.adk.agents.llm_agent import Agent
from google.adk.tools.agent_tool import AgentTool
from .prompt import PROMPT

validator_agent = Agent(
    model="gemini-2.5-flash",
    name="refund_validator",
    description="Checks if we have enough context to proceed safely.",
    instruction=PROMPT,
    tools=[],
    output_key="validator_output",
)

agent = validator_agent
tool = AgentTool(agent=validator_agent)
PROMPT = PROMPT