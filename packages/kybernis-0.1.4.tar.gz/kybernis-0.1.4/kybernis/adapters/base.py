from typing import Callable, Dict, Optional


class FrameworkAdapter:
    def __init__(
        self,
        name: str,
        available_fn: Callable[[], bool],
        wrap_tool_fn: Callable[[Callable[..., object]], Callable[..., object]],
    ) -> None:
        self.name = name
        self._available_fn = available_fn
        self._wrap_tool_fn = wrap_tool_fn

    def available(self) -> bool:
        return self._available_fn()

    def wrap_tool(self, fn: Callable[..., object]) -> Callable[..., object]:
        return self._wrap_tool_fn(fn)


class AdapterRegistry:
    def __init__(self) -> None:
        self._adapters: Dict[str, FrameworkAdapter] = {}

    def register(self, adapter: FrameworkAdapter) -> None:
        self._adapters[adapter.name] = adapter

    def get(self, name: str) -> Optional[FrameworkAdapter]:
        return self._adapters.get(name)

    def all(self) -> Dict[str, FrameworkAdapter]:
        return dict(self._adapters)


adapter_registry = AdapterRegistry()
