from .http_patch import install_httpx_patch, install_requests_patch


def install() -> None:
    install_requests_patch()
    install_httpx_patch()


# Install on import for zero-code routing
install()
