from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Optional, Protocol


@dataclass
class AgentCard:
    name: str
    description: str
    endpoint: str
    methods: Iterable[str] = field(default_factory=list)
    version: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ProtocolRequest:
    method: str
    params: Dict[str, Any] = field(default_factory=dict)
    id: Optional[str] = None


@dataclass
class ProtocolResponse:
    result: Any = None
    error: Optional[Dict[str, Any]] = None
    id: Optional[str] = None


class ProtocolGateway(Protocol):
    def discovery(self) -> AgentCard:
        ...

    def handle(self, request: ProtocolRequest) -> ProtocolResponse:
        ...

    def stream(self, request: ProtocolRequest) -> Iterable[Dict[str, Any]]:
        ...
