from dataclasses import asdict
from typing import Any, Dict, Iterable

from .base import AgentCard, ProtocolGateway, ProtocolRequest, ProtocolResponse


class A2AGateway(ProtocolGateway):
    def __init__(self, card: AgentCard) -> None:
        self._card = card

    def discovery(self) -> AgentCard:
        return self._card

    def handle(self, request: ProtocolRequest) -> ProtocolResponse:
        return ProtocolResponse(
            error={"code": -32601, "message": f"Method not implemented: {request.method}"},
            id=request.id,
        )

    def stream(self, request: ProtocolRequest) -> Iterable[Dict[str, Any]]:
        yield {
            "jsonrpc": "2.0",
            "method": "event",
            "params": {"type": "error", "message": "Streaming not implemented"},
            "id": request.id,
        }

    def discovery_payload(self) -> Dict[str, Any]:
        return asdict(self._card)
