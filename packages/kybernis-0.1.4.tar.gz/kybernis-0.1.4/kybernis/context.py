# kybernis/context.py
import contextvars
from typing import Optional

kyb_run_id = contextvars.ContextVar[Optional[str]]("kyb_run_id", default=None)
kyb_session_id = contextvars.ContextVar[Optional[str]]("kyb_session_id", default=None)

kyb_span_id = contextvars.ContextVar[Optional[str]]("kyb_span_id", default=None)
kyb_parent_span_id = contextvars.ContextVar[Optional[str]]("kyb_parent_span_id", default=None)

kyb_invocation_id = contextvars.ContextVar[Optional[str]]("kyb_invocation_id", default=None)