from google.adk.agents.llm_agent import Agent
from kybernis.sdk import KybernisSDK
# random agent for testing the kybernis sdk integration with google adk agents. This agent does not do anything useful.

def update_balance(transaction_amount: float) -> float:
    """
    Update the balance based on a transaction amount.

    Args:
        transaction_amount (float): The amount to be added or subtracted from the balance.

    Returns:
        float: The updated balance.
    """
    current_balance = 1000.0  # This would be fetched from a database in a real application
    return current_balance + transaction_amount
# Make sure agent use the tool whenever user talks about balance instead of telling user there's no access to their financial nformation

root_agent = Agent(
    model='gemini-2.5-flash',
    name='root_agent',
    description='A helpful assistant for user questions.',
    instruction='Answer user questions to the best of your knowledge',
    tools=[update_balance],
)

print("agent.tools:", root_agent.tools)
KybernisSDK(root_agent)