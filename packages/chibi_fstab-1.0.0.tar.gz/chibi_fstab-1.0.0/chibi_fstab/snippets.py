# -*- coding: utf-8 -*-
import logging
import itertools

from chibi_atlas import Chibi_atlas


logger = logging.getLogger( "chibi_fstab.snippets" )


def from_string( content ):
    lines = content.split( "\n" )
    lines = map( str.strip, lines )
    lines = filter( bool, lines )
    lines = itertools.filterfalse( line_is_commnet, lines )
    return list( map( parse_line, lines ) )


def to_string( content ):
    return "\n".join( map( to_line, content ) )


def line_is_commnet( line ):
    return line.startswith( "#" )


def parse_line( line ):
    spec, mount, kind, options, required, passno = line.split()
    uuid = None
    block = None
    if spec.startswith( 'UUID=' ):
        uuid = spec.replace( 'UUID=', '' )
    elif "=" in spec:
        logger.warning(
            "chibi_fstab no sabe como parsear completamente la "
            f"linea: '{line}'" )
        block = spec
    else:
        block = spec

    result = Chibi_atlas( {
        "uuid": uuid,
        "mount": mount,
        "fstype": kind,
        "options": options,
        "required": int( required ),
        "fs_passno": int( passno ),
    } )

    if block:
        result.block = block
    return result


def to_line( block ):
    if block.uuid:
        first = f"UUID={block.uuid}"
    else:
        first = block.block
    return (
        f"{first}\t{block.mount}\t{block.fstype}\t{block.options}"
        f"\t{block.required} {block.fs_passno}"
    )
