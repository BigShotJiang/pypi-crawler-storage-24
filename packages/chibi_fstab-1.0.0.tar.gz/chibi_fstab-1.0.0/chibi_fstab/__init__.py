# -*- coding: utf-8 -*-
from chibi_fstab.file import Chibi_fstab


__all__ = [ 'Chibi_fstab' ]
__author__ = """dem4ply"""
__email__ = 'dem4ply@gmail.com'
__version__ = '1.0.0'
