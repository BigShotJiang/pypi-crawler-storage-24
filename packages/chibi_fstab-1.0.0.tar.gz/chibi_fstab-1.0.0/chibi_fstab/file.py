# -*- coding: utf-8 -*-
from chibi.file import Chibi_file
from chibi_fstab.snippets import to_string, from_string
from chibi_hybrid import Class_property


class Chibi_fstab( Chibi_file ):
    @Class_property
    def default( cls ):
        """
        atajo para leer el fstab del sistema
        """
        return cls( "/etc/fstab" )

    def read( self ):
        string = super().read()
        result = from_string( string )
        return result

    def write( self, data ):
        result = to_string( data )
        super().write( result )
