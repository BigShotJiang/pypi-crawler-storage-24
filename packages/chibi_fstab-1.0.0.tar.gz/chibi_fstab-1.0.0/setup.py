#!/usr/bin/env python
# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

with open('README.rst') as readme_file:
    readme = readme_file.read()

with open('HISTORY.rst') as history_file:
    history = history_file.read()

requirements = [
    'chibi>=0.17.0', "chibi_atlas>=1.1.0", "chibi_hybrid>=1.2.1"
]

setup(
    author="dem4ply",
    author_email='dem4ply@gmail.com',
    classifiers=[
        'Development Status :: 2 - Pre-Alpha',
        'Intended Audience :: Developers',
        'License :: Public Domain',
        'Natural Language :: English',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
    ],
    description="small lib for read and write fstab files",
    install_requires=requirements,
    license="WTFPL",
    long_description=readme + '\n\n' + history,
    include_package_data=True,
    keywords='chibi_fstab',
    name='chibi_fstab',
    packages=find_packages(include=['chibi_fstab', 'chibi_fstab.*']),
    url='https://github.com/dem4ply/chibi_fstab',
    version='1.0.0',
    zip_safe=False,
)
