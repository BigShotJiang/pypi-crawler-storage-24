=====
Usage
=====

To use chibi_fstab in a project::

    import chibi_fstab
