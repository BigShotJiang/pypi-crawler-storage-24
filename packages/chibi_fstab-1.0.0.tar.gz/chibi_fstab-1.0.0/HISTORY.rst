=======
History
=======


********************
1.0.0 ( 2026-03-20 )
********************

* implementacion basica de lectura del archivo de fstab
* implementacion basica de escritura del archivo de fstab
