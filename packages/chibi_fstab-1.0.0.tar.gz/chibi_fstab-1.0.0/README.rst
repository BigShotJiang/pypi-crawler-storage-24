===========
chibi_fstab
===========


.. image:: https://img.shields.io/pypi/v/chibi_fstab.svg
        :target: https://pypi.python.org/pypi/chibi_fstab

.. image:: https://readthedocs.org/projects/chibi-fstab/badge/?version=latest
        :target: https://chibi-fstab.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status


small lib for read and write fstab files


* Free software: WTFPL
* Documentation: https://chibi-fstab.readthedocs.io.


=======
Install
=======


.. code-block:: bash

	pip install chibi_fstab


=====
Usage
=====


.. code-block:: bash

	cat > /etc/fstab << 'endmsg'
	# /dev/sdd2 LABEL=ROOT
	UUID=00000000-aaaa-3333-9999-111111111111	/		ext4	rw,relatime	0 1

	# /dev/sdc2 LABEL=VAR
	UUID=11111111-2222-3333-4444-666666666666	/var	ext4	rw,relatime	0 2

	UUID=99999999-3333-5555-aaaa-ffffffffffff	/home	ext4	rw,relatime	0 2
	/dev/mapper/games		/home/misuzu/games		ext4		rw,relatime	0 2

	# /dev/sda1 LABEL=BOOT
	UUID=aaaa-bbbb		/boot	vfat	rw,relatime,fmask=0022,dmask=0022,codepage=437,iocharset=ascii,shortname=mixed,utf8,errors=remount-ro	0 2

	# /dev/sdc1 LABEL=SWAP
	UUID=aaaaaaaa-bbbb-cccc-dddd-ffffffffffff	none	swap	defaults	0 0

	endmsg

.. code-block:: python

	from chibi_fstab import Chibi_fstab

	blocks = Chibi_fstab.default.read()
	assert block[0] == {
		"uuid": '00000000-aaaa-3333-9999-111111111111',
		"mount": '/',
		"fstype": 'ext4',
		"options": 'rw,relatime',
		"required": 0,
		"fs_passno": 1,
	}
	# change var to tmp
	blocks[1].mount = "/tmp"
	Chibi_fstab.default.write( blocks )

****************
result of script
****************

.. code-block:: text

	UUID=00000000-aaaa-3333-9999-111111111111	/	ext4	rw,relatime	0 1
	UUID=11111111-2222-3333-4444-666666666666	/tmp	ext4	rw,relatime	0 2
	UUID=99999999-3333-5555-aaaa-ffffffffffff	/home	ext4	rw,relatime	0 2
	/dev/mapper/games	/home/misuzu/games	ext4	rw,relatime	0 2
	UUID=aaaa-bbbb	/boot	vfat	rw,relatime,fmask=0022,dmask=0022,codepage=437,iocharset=ascii,shortname=mixed,utf8,errors=remount-ro	0 2
	UUID=aaaaaaaa-bbbb-cccc-dddd-ffffffffffff	none	swap	defaults	0 0


****************
alternative read
****************


.. code-block:: python

	from chibi.file import Chibi_path
	from chibi_fstab import Chibi_fstab

	blocks = Chibi_path.open( chibi_file_class=Chibi_fstab ).read()
	assert block[0] == {
		"uuid": '00000000-aaaa-3333-9999-111111111111',
		"mount": '/',
		"fstype": 'ext4',
		"options": 'rw,relatime',
		"required": 0,
		"fs_passno": 1,
	}
