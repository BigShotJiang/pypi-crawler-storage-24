from __future__ import annotations

import io
from contextlib import redirect_stdout

from gungi.fen import BEGINNER_POSITION
from gungi.gungi import Gungi


def test_print_matches_js_console_log_behavior() -> None:
    game = Gungi(BEGINNER_POSITION)
    output = io.StringIO()

    with redirect_stdout(output):
        game.print()

    assert output.getvalue() == game.ascii() + "\n"
