import gungi
from gungi import BEGINNER_POSITION, Gungi


def test_top_level_js_style_aliases_are_exported():
    expected_aliases = (
        "parseFEN",
        "encodeFEN",
        "validateFen",
        "is_square_attacked",
        "isSquareAttacked",
    )

    for alias in expected_aliases:
        assert alias in gungi.__all__
        assert hasattr(gungi, alias)


def test_top_level_aliases_match_underlying_helpers():
    game = Gungi(BEGINNER_POSITION)

    parsed = gungi.parseFEN(BEGINNER_POSITION)

    assert gungi.encodeFEN(parsed) == gungi.encode_fen(parsed)
    assert gungi.validateFen(BEGINNER_POSITION) == gungi.validate_fen(BEGINNER_POSITION)
    assert gungi.isSquareAttacked("9-5", "b", game.board()) == gungi.is_square_attacked(
        "9-5", "b", game.board()
    )
