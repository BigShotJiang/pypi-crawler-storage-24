"""
Section renderers for landing pages.

Each ``_render_*`` function accepts a section dict (and optionally a CTA HTML
string) and returns an HTML fragment.  The ``SECTION_RENDERERS`` dict maps
section type names to their renderer.
"""

import html as html_mod
import os
import re

try:
    from pygments import highlight as _pygments_highlight
    from pygments.lexers import get_lexer_by_name, TextLexer
    from pygments.formatters import HtmlFormatter
    _HAS_PYGMENTS = True
except ImportError:
    _HAS_PYGMENTS = False


# ---------------------------------------------------------------------------
# Inline helpers
# ---------------------------------------------------------------------------

def _esc(text):
    """HTML-escape *text*."""
    return html_mod.escape(str(text))


def _inline(text):
    """Process inline markdown: links, bold, code. Returns HTML-safe string."""
    t = html_mod.escape(str(text))
    # Links: [text](url) — must process before bold since links may contain bold
    t = re.sub(r'\[(.+?)\]\((.+?)\)', r'<a href="\2">\1</a>', t)
    # Bold: **text**
    t = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', t)
    # Inline code: `text`
    t = re.sub(r'`(.+?)`', r'<code>\1</code>', t)
    return t


def _highlight_code(code, language):
    """Syntax highlight code using Pygments, mapped to DTCG token classes.
    Falls back to escaped plain text if Pygments unavailable."""
    if not _HAS_PYGMENTS or not language:
        return html_mod.escape(code)
    try:
        lexer = get_lexer_by_name(language, stripall=True)
    except Exception:
        return html_mod.escape(code)
    formatter = HtmlFormatter(nowrap=True, classprefix="hl-")
    return _pygments_highlight(code, lexer, formatter)


# ---------------------------------------------------------------------------
# Partner logos
# ---------------------------------------------------------------------------

_PARTNER_LOGOS = [
    {"name": "Samsung", "url": "https://mcdn.signalwire.com/images/icons/partners/new_homepage/Logo_Samsung.svg"},
    {"name": "Audi", "url": "https://mcdn.signalwire.com/Testimonial-Logos/audi-logo.svg"},
    {"name": "T-Mobile", "url": "https://mcdn.signalwire.com/images/T-Mobile_2020.svg"},
    {"name": "Deutsche Telekom", "url": "https://mcdn.signalwire.com/images/Deutsche_Telekom_2022.svg", "height": "60px"},
    {"name": "Sprinklr", "url": "https://mcdn.signalwire.com/images/Sprinklr_Logo.svg"},
    {"name": "Filevine", "url": "https://mcdn.signalwire.com/images/icons/partners/new_homepage/Logo_Filevine.svg"},
    {"name": "Phoenix Children's", "url": "https://mcdn.signalwire.com/images/icons/partners/new_homepage/Logo_PhoenixChildrens.svg"},
    {"name": "Textline", "url": "https://mcdn.signalwire.com/images/icons/partners/new_homepage/Logo_Textline.svg"},
    {"name": "Replicant", "url": "https://mcdn.signalwire.com/images/icons/partners/new_homepage/Logo_Replicant.svg"},
    {"name": "Growthzilla", "url": "https://mcdn.signalwire.com/images/icons/partners/new_homepage/Logo_Growthzilla.svg"},
    {"name": "Prompt.io", "url": "https://mcdn.signalwire.com/images/icons/partners/new_homepage/Logo_PromptIO.svg"},
    {"name": "Vultik", "url": "https://mcdn.signalwire.com/images/icons/partners/new_homepage/Logo_Vultik.svg"},
    {"name": "McFarland Clinic", "url": "https://mcdn.signalwire.com/images/icons/partners/new_homepage/Logo_McFarlandClinic.svg"},
]

# Cache for inline SVGs read from local files
_INLINE_SVG_CACHE = {}


def _load_partner_svg(filepath):
    """Read a local SVG and return cleaned inline markup."""
    if filepath in _INLINE_SVG_CACHE:
        return _INLINE_SVG_CACHE[filepath]
    if not os.path.exists(filepath):
        return None
    with open(filepath) as f:
        svg = f.read()
    svg = re.sub(r'<\?xml[^?]*\?>\s*', '', svg)
    svg = re.sub(r'<!DOCTYPE[^>]*>\s*', '', svg)
    # Normalize <svg\n to <svg so class injection works
    svg = re.sub(r'<svg\s', '<svg ', svg)
    svg = svg.strip()
    _INLINE_SVG_CACHE[filepath] = svg
    return svg


# ---------------------------------------------------------------------------
# Section renderers
# ---------------------------------------------------------------------------

def _render_hero(s, cta_html):
    headline = _esc(s.get("headline", ""))
    subtitle = _esc(s.get("subtitle", ""))
    eyebrow = s.get("eyebrow", "")
    # Wrap last phrase in <em> for emphasis color if headline has a colon or comma
    if ":" in headline:
        parts = headline.split(":", 1)
        headline = f'{parts[0]}: <em>{parts[1].strip()}</em>'
    eyebrow_html = f'<div class="lp-hero__eyebrow">{_esc(eyebrow)}</div>' if eyebrow else ""
    return f"""<section class="lp-hero">
  <div class="lp-container">
    {eyebrow_html}
    <h1 class="lp-hero__title">{headline}</h1>
    <p class="lp-hero__subtitle">{subtitle}</p>
    {cta_html if s.get("cta", True) else ""}
  </div>
</section>"""


def _render_features(s):
    title = _esc(s.get("title", ""))
    eyebrow = s.get("eyebrow", "")
    items = s.get("items", [])
    cards = ""
    for item in items:
        icon = _esc(item.get("icon", ""))
        label = _esc(item.get("title", ""))
        desc = _inline(item.get("desc", ""))
        icon_html = f'<div class="lp-feature__icon">{icon}</div>' if icon else ""
        cards += f"""<div class="lp-feature">
      {icon_html}
      <h3 class="lp-feature__title">{label}</h3>
      <p class="lp-feature__desc">{desc}</p>
    </div>"""
    eyebrow_html = f'<div class="lp-section__eyebrow">{_esc(eyebrow)}</div>' if eyebrow else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {eyebrow_html}
    <h2 class="lp-section__title">{title}</h2>
    <div class="lp-features-grid">{cards}</div>
  </div>
</section>"""


def _render_comparison(s):
    title = _esc(s.get("title", ""))
    columns = s.get("columns", [])
    cols_html = ""
    for col in columns:
        label = _esc(col.get("label", ""))
        style = col.get("style", "neutral")
        items = col.get("items", [])
        marker = "&#x2717;" if style == "negative" else "&#x2713;"
        li_class = "negative" if style == "negative" else "positive"
        items_html = "".join(f'<li class="lp-compare__item lp-compare__item--{li_class}"><span class="lp-compare__marker">{marker}</span> {_esc(i)}</li>' for i in items)
        col_class = f"lp-compare__col lp-compare__col--{style}"
        cols_html += f"""<div class="{col_class}">
      <h3 class="lp-compare__label">{label}</h3>
      <ul class="lp-compare__list">{items_html}</ul>
    </div>"""
    return f"""<section class="lp-section">
  <div class="lp-container">
    <h2 class="lp-section__title">{title}</h2>
    <div class="lp-compare">{cols_html}</div>
  </div>
</section>"""


def _render_stats(s):
    title = s.get("title", "")
    items = s.get("items", [])
    stats = ""
    for item in items:
        val = _esc(item.get("value", ""))
        label = _esc(item.get("label", ""))
        stats += f'<div class="lp-stat"><div class="lp-stat__value">{val}</div><div class="lp-stat__label">{label}</div></div>'
    title_html = f'<h2 class="lp-section__title">{_esc(title)}</h2>' if title else ""
    return f"""<section class="lp-section lp-section--stats">
  <div class="lp-container">
    {title_html}
    <div class="lp-stats-row">{stats}</div>
  </div>
</section>"""


def _render_code(s):
    title = _esc(s.get("title", ""))
    lang = s.get("language", "")
    code = _highlight_code(s.get("code", ""), lang)
    lang = _esc(lang)
    desc = s.get("desc", "")
    desc_html = f'<p class="lp-code__desc">{_esc(desc)}</p>' if desc else ""
    lang_label = f'<span class="lp-code__lang">{lang}</span>' if lang else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    <h2 class="lp-section__title">{title}</h2>
    {desc_html}
    <div class="lp-code-block">
      {lang_label}
      <pre><button class="lp-copy-btn" onclick="lpCopy(this)">Copy</button><code>{code}</code></pre>
    </div>
  </div>
</section>"""


def _render_testimonial(s):
    quote = _inline(s.get("quote", ""))
    name = _esc(s.get("name", ""))
    role = _esc(s.get("role", ""))
    return f"""<section class="lp-section">
  <div class="lp-container">
    <blockquote class="lp-testimonial">
      <p class="lp-testimonial__quote">{quote}</p>
      <footer class="lp-testimonial__attr">
        <strong>{name}</strong>{f", {role}" if role else ""}
      </footer>
    </blockquote>
  </div>
</section>"""


def _render_logos(s):
    title = _esc(s.get("title", "Trusted by"))
    # Build marquee: duplicate the set for seamless loop
    items = ""
    for l in _PARTNER_LOGOS:
        alt = _esc(l["name"])
        h = l.get("height", "")
        style = f' style="max-height:{h}"' if h else ""
        if "file" in l:
            svg = _load_partner_svg(l["file"])
            if svg:
                svg = svg.replace('<svg ', f'<svg class="lp-logo-img" role="img" aria-label="{alt}"{style} ', 1)
                items += svg
            else:
                items += f'<span class="lp-logo-name">{alt}</span>'
        else:
            items += f'<img src="{l["url"]}" alt="{alt}" class="lp-logo-img"{style}>'
    track = f'{items}{items}'
    return f"""<section class="lp-section lp-section--logos">
  <div class="lp-container">
    <p class="lp-logos__title">{title}</p>
  </div>
  <div class="lp-marquee"><div class="lp-marquee__track">{track}</div></div>
</section>"""


def _render_steps(s):
    title = _esc(s.get("title", ""))
    items = s.get("items", [])
    steps = ""
    for i, item in enumerate(items):
        label = _esc(item.get("label", ""))
        desc = _esc(item.get("desc", ""))
        steps += f"""<div class="lp-step">
      <div class="lp-step__number">{i + 1}</div>
      <div class="lp-step__content">
        <h3 class="lp-step__label">{label}</h3>
        <p class="lp-step__desc">{desc}</p>
      </div>
    </div>"""
    return f"""<section class="lp-section">
  <div class="lp-container">
    <h2 class="lp-section__title">{title}</h2>
    <div class="lp-steps">{steps}</div>
  </div>
</section>"""


def _render_faq(s):
    title = _esc(s.get("title", "FAQ"))
    items = s.get("items", [])
    faqs = ""
    for item in items:
        q = _esc(item.get("q", ""))
        a = _esc(item.get("a", ""))
        faqs += f"""<details class="lp-faq__item">
      <summary class="lp-faq__q">{q}</summary>
      <p class="lp-faq__a">{a}</p>
    </details>"""
    return f"""<section class="lp-section">
  <div class="lp-container">
    <h2 class="lp-section__title">{title}</h2>
    <div class="lp-faq">{faqs}</div>
  </div>
</section>"""


def _render_text(s):
    """Generic text section with title + paragraphs."""
    title = _esc(s.get("title", ""))
    body = s.get("body", [])
    if isinstance(body, str):
        body = [body]
    paras = "".join(f"<p>{_inline(p)}</p>" for p in body)
    return f"""<section class="lp-section">
  <div class="lp-container">
    <h2 class="lp-section__title">{title}</h2>
    {paras}
  </div>
</section>"""


def _render_table(s):
    """Data table with styled header and hover rows."""
    title = _esc(s.get("title", ""))
    headers = s.get("headers", [])
    rows = s.get("rows", [])
    th = "".join(f"<th>{_esc(h)}</th>" for h in headers)
    tbody = ""
    for row in rows:
        cells = "".join(f'<td>{_inline(c)}</td>' for c in row)
        tbody += f"<tr>{cells}</tr>"
    title_html = f'<h2 class="lp-section__title">{title}</h2>' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {title_html}
    <div class="lp-table-wrap">
      <table class="lp-table">
        <thead><tr>{th}</tr></thead>
        <tbody>{tbody}</tbody>
      </table>
    </div>
  </div>
</section>"""


def _render_callout(s):
    """Colored callout box: info, warn, danger, success."""
    ctype = s.get("style", "info")
    text = _inline(s.get("text", ""))
    title = s.get("title", "")
    icons = {"info": "&#x1F4A1;", "warn": "&#x26A0;&#xFE0F;", "danger": "&#x1F6A8;", "success": "&#x2705;"}
    icon = icons.get(ctype, "")
    title_html = f'<strong>{_esc(title)}</strong> ' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    <div class="lp-callout lp-callout--{_esc(ctype)}">
      <span class="lp-callout__icon">{icon}</span>
      <div class="lp-callout__body">{title_html}{text}</div>
    </div>
  </div>
</section>
</div>"""


def _render_badges(s):
    """Row of badge pills."""
    items = s.get("items", [])
    colors = ["fuchsia", "blue", "turquoise", "gold", "neutral"]
    badges = ""
    for i, item in enumerate(items):
        text = _esc(item if isinstance(item, str) else item.get("text", ""))
        color = item.get("color", colors[i % len(colors)]) if isinstance(item, dict) else colors[i % len(colors)]
        badges += f'<span class="lp-badge lp-badge--{_esc(color)}">{text}</span>'
    return f'<div class="lp-badge-row">{badges}</div>'


def _render_tabs(s):
    """Tabbed code examples (Python/Node/YAML etc). Pure CSS, no JS."""
    title = _esc(s.get("title", ""))
    tabs = s.get("tabs", [])
    group = f"tg{abs(hash(title)) % 99999}"
    # Radios, labels, and panels as siblings for CSS ~ combinator
    radios_and_labels = ""
    panels = ""
    for i, tab in enumerate(tabs):
        label = _esc(tab.get("label", f"Tab {i+1}"))
        lang = tab.get("language", "")
        code = _highlight_code(tab.get("code", ""), lang)
        lang = _esc(lang)
        checked = " checked" if i == 0 else ""
        tid = f"{group}-{i}"
        radios_and_labels += f'<input type="radio" name="{group}" id="{tid}"{checked} class="lp-tab__radio"><label for="{tid}" class="lp-tab__btn">{label}</label>'
        lang_html = f'<span class="lp-code__lang">{lang}</span>' if lang else ""
        panels += f'<div class="lp-tab__panel">{lang_html}<pre><button class="lp-copy-btn" onclick="lpCopy(this)">Copy</button><code>{code}</code></pre></div>'
    title_html = f'<h2 class="lp-section__title">{title}</h2>' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {title_html}
    <div class="lp-tabs">
      {radios_and_labels}
      {panels}
    </div>
  </div>
</section>"""


def _render_pricing(s):
    """Pricing tier cards in a row."""
    title = _esc(s.get("title", ""))
    tiers = s.get("tiers", [])
    cards = ""
    for i, tier in enumerate(tiers):
        name = _esc(tier.get("name", ""))
        price = _esc(tier.get("price", ""))
        unit = _esc(tier.get("unit", ""))
        desc = _esc(tier.get("desc", ""))
        features = tier.get("features", [])
        featured = tier.get("featured", False)
        cta_text = _esc(tier.get("cta", "Get Started"))
        cta_url = tier.get("url", "#")

        feat_html = "".join(f'<li class="lp-pricing__feat"><span class="lp-pricing__check">&#x2713;</span> {_inline(f)}</li>' for f in features)
        featured_class = " lp-pricing__card--featured" if featured else ""
        badge_html = '<span class="lp-badge lp-badge--fuchsia" style="margin-bottom:1rem;display:inline-block">Popular</span>' if featured else ""
        btn_class = "lp-btn lp-btn--primary" if featured else "lp-btn lp-btn--secondary"

        cards += f"""<div class="lp-pricing__card{featured_class}">
      {badge_html}
      <h3 class="lp-pricing__name">{name}</h3>
      <div class="lp-pricing__price">{price}<span class="lp-pricing__unit">{unit}</span></div>
      <p class="lp-pricing__desc">{desc}</p>
      <ul class="lp-pricing__feats">{feat_html}</ul>
      <a href="{cta_url}" class="{btn_class}" style="width:100%;justify-content:center;margin-top:auto">{cta_text}</a>
    </div>"""
    title_html = f'<h2 class="lp-section__title" style="text-align:center">{title}</h2>' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {title_html}
    <div class="lp-pricing">{cards}</div>
  </div>
</section>"""


def _render_links(s):
    """Row of link cards."""
    title = s.get("title", "")
    items = s.get("items", [])
    links = ""
    for item in items:
        text = _esc(item.get("text", ""))
        url = item.get("url", "#")
        desc = item.get("desc", "")
        desc_html = f'<p class="lp-link-card__desc">{_esc(desc)}</p>' if desc else ""
        links += f"""<a href="{url}" class="lp-link-card">
      <span class="lp-link-card__text">{text}</span>
      {desc_html}
      <span class="lp-link-card__arrow">&rarr;</span>
    </a>"""
    title_html = f'<h2 class="lp-section__title">{_esc(title)}</h2>' if title else ""
    return f"""<section class="lp-section">
  <div class="lp-container">
    {title_html}
    <div class="lp-links-grid">{links}</div>
  </div>
</section>"""


def _render_cta(s, cta_html):
    headline = _esc(s.get("headline", "Ready to build?"))
    subtitle = s.get("subtitle", "")
    sub_html = f'<p class="lp-cta__subtitle">{_esc(subtitle)}</p>' if subtitle else ""
    return f"""<section class="lp-section lp-section--cta">
  <div class="lp-container lp-cta">
    <h2 class="lp-cta__title">{headline}</h2>
    {sub_html}
    {cta_html}
  </div>
</section>"""


# ---------------------------------------------------------------------------
# Renderer dispatch table
# ---------------------------------------------------------------------------

SECTION_RENDERERS = {
    "hero": lambda s, cta: _render_hero(s, cta),
    "features": lambda s, cta: _render_features(s),
    "comparison": lambda s, cta: _render_comparison(s),
    "stats": lambda s, cta: _render_stats(s),
    "code": lambda s, cta: _render_code(s),
    "testimonial": lambda s, cta: _render_testimonial(s),
    "logos": lambda s, cta: _render_logos(s),
    "steps": lambda s, cta: _render_steps(s),
    "faq": lambda s, cta: _render_faq(s),
    "text": lambda s, cta: _render_text(s),
    "table": lambda s, cta: _render_table(s),
    "callout": lambda s, cta: _render_callout(s),
    "badges": lambda s, cta: _render_badges(s),
    "tabs": lambda s, cta: _render_tabs(s),
    "pricing": lambda s, cta: _render_pricing(s),
    "links": lambda s, cta: _render_links(s),
    "cta": lambda s, cta: _render_cta(s, cta),
}
