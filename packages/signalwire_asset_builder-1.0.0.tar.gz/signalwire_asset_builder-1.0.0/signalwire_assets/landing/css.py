"""
Landing page component CSS and token-to-CSS bridge.

``COMPONENT_CSS`` is the full set of component styles (reset, navbar, hero,
features, comparison, stats, code, testimonials, logos, steps, FAQ, tables,
callouts, badges, tabs, pricing, links, CTA, footer, and mobile overrides).

``generate_css`` is re-exported from ``.tokens`` for convenience so callers
can do ``from signalwire_assets.landing.css import generate_css``.
"""

from .tokens import generate_css  # noqa: F401 – re-export

COMPONENT_CSS = """
/* ═══ RESET ═══ */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;-webkit-font-smoothing:antialiased}

body{font-family:var(--font-body);color:var(--fg-default);background:var(--bg-page);line-height:1.8;font-size:18px;overflow-x:hidden}

/* ═══ ACCENT BAR ═══ */
@keyframes lp-grad{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
.lp-accent-bar{height:2px;background:linear-gradient(90deg,var(--sw-blue),var(--sw-fuchsia),var(--sw-blue));background-size:300% 100%;animation:lp-grad 6s ease infinite}
.lp-navbar__links a.lp-navbar__cta{font-family:var(--font-heading);font-size:0.8rem;font-weight:600;color:#fff;background:var(--sw-fuchsia);padding:0.4rem 1rem;border-radius:100px;text-decoration:none;transition:opacity 0.15s;white-space:nowrap}
.lp-navbar__links a.lp-navbar__cta:hover{opacity:0.85;color:#fff}

/* ═══ NAVBAR ═══ */
.lp-navbar{position:sticky;top:0;z-index:99;background:var(--bg-page);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);padding:0.875rem 0}
.lp-navbar__inner{display:flex;align-items:center;justify-content:space-between}
.lp-navbar__logo svg{height:28px;width:auto}
.lp-navbar__links{display:flex;align-items:center;gap:1.75rem}
.lp-navbar__links a{font-family:var(--font-heading);font-size:0.875rem;font-weight:600;color:var(--role-nav-link);text-decoration:none;transition:color 0.15s}
.lp-navbar__links a:hover{color:var(--role-nav-link-hover)}
.lp-navbar__links button{background:none;border:1px solid var(--border-default);border-radius:100px;padding:0.3rem 0.6rem;cursor:pointer;font-size:0.8rem;line-height:1;transition:border-color 0.15s}
.lp-navbar__links button:hover{border-color:var(--fg-emphasis-small)}

/* ═══ CONTAINER ═══ */
.lp-container{width:75%;max-width:1100px;margin:0 auto;padding:0 2rem}
@media(max-width:768px){.lp-container{width:92%;padding:0 1rem}}

/* ═══ HERO ═══ */
.lp-hero{padding:7rem 0 5rem;position:relative;overflow:hidden}
.lp-hero::before{content:'';position:absolute;top:-50%;right:-20%;width:600px;height:600px;background:radial-gradient(circle,var(--sw-fuchsia) 0%,transparent 70%);opacity:0.04;pointer-events:none}
.lp-hero::after{content:'';position:absolute;bottom:-30%;left:-10%;width:500px;height:500px;background:radial-gradient(circle,var(--sw-blue) 0%,transparent 70%);opacity:0.04;pointer-events:none}
.lp-hero__eyebrow{font-family:var(--font-code);font-size:0.8rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:var(--role-eyebrow-label);margin-bottom:1rem;display:flex;align-items:center;gap:0.75rem}
.lp-hero__eyebrow::before{content:'';width:24px;height:2px;background:var(--role-eyebrow-label)}
.lp-hero__title{font-family:var(--font-heading);font-size:clamp(2.5rem,6vw,4.25rem);font-weight:700;color:var(--role-heading-h1);line-height:1.08;margin-bottom:1.5rem;max-width:850px}
.lp-hero__title em{font-style:normal;color:var(--role-heading-keyword)}
.lp-hero__subtitle{font-size:1.25rem;color:var(--role-body-text);max-width:600px;margin-bottom:2.5rem;line-height:1.7}

/* ═══ SECTIONS ═══ */
.lp-section{padding:5rem 0}
.lp-section:nth-child(even){background:var(--bg-surface)}
.lp-section__eyebrow{font-family:var(--font-code);font-size:0.8rem;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:var(--role-eyebrow-label);margin-bottom:0.75rem}
.lp-section__title{font-family:var(--font-heading);font-size:clamp(1.5rem,3.5vw,2.5rem);font-weight:700;color:var(--role-heading-h2);margin-bottom:1.5rem;line-height:1.15}
.lp-section__title em{font-style:normal;color:var(--role-heading-keyword)}
.lp-section p{color:var(--role-body-text);margin-bottom:1rem;max-width:750px}
.lp-section strong{color:var(--role-body-bold)}
.lp-section a{color:var(--role-link-default);text-decoration:none;border-bottom:1px solid transparent;transition:all 0.15s}
.lp-section a:hover{color:var(--role-link-hover);border-color:var(--role-link-hover)}

/* ═══ FEATURES GRID ═══ */
.lp-features-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:1.25rem;margin-top:1.5rem}
.lp-feature{background:var(--bg-surface);border:1px solid var(--border-default);border-top:3px solid var(--sw-fuchsia);border-radius:10px;padding:2rem 1.75rem;transition:all 0.2s}
.lp-feature:nth-child(2){border-top-color:var(--sw-turquoise)}
.lp-feature:nth-child(3){border-top-color:var(--sw-blue)}
.lp-feature:nth-child(4){border-top-color:var(--sw-gold)}
.lp-feature:nth-child(5){border-top-color:var(--sw-turquoise)}
.lp-feature:nth-child(6){border-top-color:var(--sw-fuchsia)}
.lp-feature:hover{border-color:var(--fg-emphasis-small);transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,0.12)}
.lp-feature__icon{font-size:2rem;margin-bottom:1rem;display:inline-block;width:3rem;height:3rem;line-height:3rem;text-align:center;background:var(--bg-surface-raised);border-radius:10px}
.lp-feature__title{font-family:var(--font-heading);font-size:1.1rem;font-weight:700;color:var(--fg-default);margin-bottom:0.625rem}
.lp-feature__desc{font-size:0.9375rem;color:var(--role-body-text);line-height:1.65}

/* ═══ COMPARISON ═══ */
.lp-compare{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:1.25rem}
.lp-compare__col{background:var(--bg-surface);border:1px solid var(--border-default);border-radius:10px;padding:2rem 1.75rem;position:relative}
.lp-compare__col--positive{border-top:3px solid var(--sw-turquoise)}
.lp-compare__col--positive .lp-compare__label{color:var(--role-card-title)}
.lp-compare__col--negative{border-top:3px solid var(--fg-muted);opacity:0.85}
.lp-compare__col--negative .lp-compare__label{color:var(--fg-muted)}
.lp-compare__label{font-family:var(--font-heading);font-size:1.1rem;font-weight:700;margin-bottom:1.25rem}
.lp-compare__list{list-style:none;padding:0}
.lp-compare__item{display:flex;align-items:flex-start;gap:0.625rem;margin-bottom:0.875rem;font-size:0.9375rem;color:var(--role-body-text)}
.lp-compare__marker{flex-shrink:0;font-weight:700;font-size:1.2rem;line-height:1.2}
.lp-compare__item--positive .lp-compare__marker{color:var(--role-compare-positive)}
.lp-compare__item--negative .lp-compare__marker{color:var(--role-compare-negative)}

/* ═══ STATS ═══ */
.lp-section--stats{padding:3.5rem 0}
.lp-stats-row{display:flex;justify-content:center;gap:4rem;flex-wrap:wrap;padding:1.5rem 0}
.lp-stat{text-align:center;position:relative}
.lp-stat::after{content:'';position:absolute;top:50%;right:-2rem;transform:translateY(-50%);width:1px;height:60%;background:var(--border-default)}
.lp-stat:last-child::after{display:none}
.lp-stat__value{font-family:var(--font-heading);font-size:clamp(2.25rem,5vw,3.5rem);font-weight:700;color:var(--role-stat-value);line-height:1}
.lp-stat__label{font-size:0.8125rem;color:var(--role-stat-label);margin-top:0.5rem;font-weight:500}

/* ═══ CODE ═══ */
.lp-code-block{position:relative;margin:1.5rem 0;border-radius:12px;overflow:hidden;border:1px solid var(--border-default)}
.lp-code__lang{position:absolute;top:0;right:0;font-family:var(--font-code);font-size:0.65rem;color:var(--fg-subtle);text-transform:uppercase;letter-spacing:0.1em;padding:0.5rem 1rem;background:rgba(255,255,255,0.03);border-bottom-left-radius:8px}
.lp-code__desc{color:var(--role-body-text);margin-bottom:1.25rem;max-width:750px}
.lp-code-block pre{background:var(--role-code-block-bg);color:var(--role-code-block-text);padding:1.75rem 1.5rem;overflow-x:auto;font-family:var(--font-code);font-size:0.8125rem;line-height:1.75;margin:0;border-radius:0;position:relative}
.lp-copy-btn{position:absolute;top:0.5rem;right:6.5rem;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:var(--fg-subtle);font-family:var(--font-code);font-size:0.65rem;padding:0.25rem 0.6rem;border-radius:4px;cursor:pointer;transition:all 0.15s;text-transform:uppercase;letter-spacing:0.05em}
.lp-copy-btn:hover{background:rgba(255,255,255,0.12);color:var(--fg-secondary)}
.lp-copy-btn--done{color:var(--sw-turquoise);border-color:var(--sw-turquoise)}
.lp-code-block code{background:none;padding:0;color:inherit;font-size:inherit}

/* ═══ TESTIMONIAL ═══ */
.lp-testimonial{border-left:3px solid var(--role-testimonial-border);padding:2rem 2.5rem;max-width:700px;background:var(--bg-surface);border-radius:0 10px 10px 0;position:relative}
.lp-testimonial::before{content:'"';position:absolute;top:-0.25rem;left:1rem;font-family:var(--font-heading);font-size:4rem;color:var(--role-testimonial-border);opacity:0.15;line-height:1}
.lp-testimonial__quote{font-size:1.125rem;color:var(--role-testimonial-text);font-style:italic;line-height:1.7;margin-bottom:1.25rem}
.lp-testimonial__attr{font-size:0.875rem;color:var(--role-testimonial-attr)}

/* ═══ LOGOS ═══ */
.lp-section--logos{text-align:center;padding:3.5rem 0;background:transparent !important;overflow:hidden}
.lp-logos__title{font-family:var(--font-code);font-size:0.75rem;color:var(--fg-muted);text-transform:uppercase;letter-spacing:0.15em;margin-bottom:2rem;font-weight:600}
.lp-marquee{position:relative;width:100%;overflow:hidden;mask-image:linear-gradient(90deg,transparent,black 10%,black 90%,transparent);-webkit-mask-image:linear-gradient(90deg,transparent,black 10%,black 90%,transparent)}
.lp-marquee__track{display:flex;align-items:center;gap:3.5rem;width:max-content;animation:lp-scroll 30s linear infinite}
.lp-marquee:hover .lp-marquee__track{animation-play-state:paused}
img.lp-logo-img{height:auto;width:auto;max-height:140px;max-width:160px;object-fit:contain}
svg.lp-logo-img{height:140px;width:auto;max-width:160px}
.lp-logo-img{opacity:0.5;filter:brightness(0) invert(1);transition:opacity 0.3s,filter 0.3s;flex-shrink:0}
.lp-logo-img:hover{opacity:0.8}
[data-theme="light"] .lp-logo-img{filter:brightness(0) invert(0)}
[data-theme="light"] .lp-logo-img:hover{opacity:0.8}
@keyframes lp-scroll{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}

/* ═══ STEPS ═══ */
.lp-steps{display:flex;flex-direction:column;gap:0;max-width:700px;position:relative}
.lp-steps::before{content:'';position:absolute;left:1.25rem;top:2.5rem;bottom:1.25rem;width:2px;background:var(--border-default)}
.lp-step{display:flex;gap:1.5rem;align-items:flex-start;padding:1.25rem 0;position:relative}
.lp-step__number{flex-shrink:0;width:2.5rem;height:2.5rem;background:var(--sw-fuchsia);color:#fff;font-family:var(--font-heading);font-weight:700;font-size:0.9375rem;border-radius:50%;display:flex;align-items:center;justify-content:center;position:relative;z-index:1;box-shadow:0 0 0 4px var(--bg-page)}
.lp-step:nth-child(2) .lp-step__number{background:var(--sw-turquoise)}
.lp-step:nth-child(3) .lp-step__number{background:var(--sw-blue)}
.lp-step:nth-child(4) .lp-step__number{background:var(--sw-gold)}
.lp-step__label{font-family:var(--font-heading);font-weight:700;color:var(--fg-default);margin-bottom:0.375rem;font-size:1.0625rem}
.lp-step__desc{font-size:0.9375rem;color:var(--role-body-text);line-height:1.6}

/* ═══ FAQ ═══ */
.lp-faq{max-width:700px}
.lp-faq__item{border:1px solid var(--border-default);border-radius:8px;margin-bottom:0.75rem;overflow:hidden;transition:border-color 0.2s}
.lp-faq__item:hover{border-color:var(--fg-emphasis-small)}
.lp-faq__item[open]{border-color:var(--fg-emphasis-small)}
.lp-faq__q{font-family:var(--font-heading);font-weight:600;color:var(--fg-default);cursor:pointer;font-size:1rem;list-style:none;padding:1rem 1.25rem;display:flex;align-items:center;gap:0.75rem}
.lp-faq__q::marker{content:""}
.lp-faq__q::before{content:"+";color:var(--role-faq-marker);font-weight:700;font-size:1.25rem;flex-shrink:0;width:1.5rem;text-align:center}
.lp-faq__item[open] .lp-faq__q::before{content:"\u2212"}
.lp-faq__a{padding:0 1.25rem 1rem 3.5rem;color:var(--role-body-text);font-size:0.9375rem;line-height:1.7}

/* ═══ TABLE ═══ */
.lp-table-wrap{overflow-x:auto;margin:1.5rem 0;-webkit-overflow-scrolling:touch}
.lp-table{width:100%;border-collapse:collapse}
.lp-table thead th{font-family:var(--font-code);font-size:0.7rem;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;text-align:left;color:var(--role-table-header);padding:0.75rem 1rem;border-bottom:2px solid var(--role-table-header-line)}
.lp-table tbody td{padding:0.75rem 1rem;border-bottom:1px solid var(--border-default);color:var(--role-table-cell);font-size:0.9375rem}
.lp-table tbody tr{transition:background 0.15s}
.lp-table tbody tr:hover{background:var(--bg-surface)}
.lp-table tbody tr:last-child td{border-bottom:none}
.lp-table code{font-family:var(--font-code);font-size:0.8125em;background:var(--role-code-inline-bg);color:var(--role-code-inline-text);padding:0.15em 0.4em;border-radius:4px}
.lp-table strong{color:var(--role-table-cell-bold)}

/* ═══ CALLOUT ═══ */
.lp-callout{display:flex;gap:0.75rem;padding:1.25rem 1.5rem;border-radius:10px;border:1px solid;margin:1.5rem 0}
.lp-callout--info{background:var(--callout-info-bg);border-color:var(--callout-info-border)}
.lp-callout--warn{background:var(--callout-warn-bg);border-color:var(--callout-warn-border)}
.lp-callout--danger{background:var(--callout-danger-bg);border-color:var(--callout-danger-border)}
.lp-callout--success{background:var(--callout-success-bg);border-color:var(--callout-success-border)}
.lp-callout__icon{flex-shrink:0;font-size:1.25rem;line-height:1.5}
.lp-callout__body{color:var(--fg-secondary);font-size:0.9375rem;line-height:1.65}
.lp-callout__body strong{color:var(--fg-default)}

/* ═══ BADGES ═══ */
.lp-badge-row{display:flex;flex-wrap:wrap;gap:0.5rem;margin:1rem 0}
.lp-badge{display:inline-block;font-family:var(--font-code);font-size:0.75rem;font-weight:600;padding:0.25rem 0.75rem;border-radius:100px;background:var(--badge-bg);border:1px solid var(--badge-border)}
.lp-badge--fuchsia{color:var(--badge-text-fuchsia)}
.lp-badge--blue{color:var(--badge-text-blue)}
.lp-badge--turquoise{color:var(--badge-text-turquoise)}
.lp-badge--gold{color:var(--badge-text-gold)}
.lp-badge--neutral{color:var(--fg-secondary)}

/* ═══ SYNTAX HIGHLIGHTING (Pygments hl- prefix mapped to DTCG tokens) ═══ */
.hl-k,.hl-kn,.hl-kd,.hl-kr,.hl-kc,.hl-kt,.hl-kp{color:var(--tok-keyword)}
.hl-s,.hl-s1,.hl-s2,.hl-sb,.hl-sc,.hl-sd,.hl-se,.hl-sh,.hl-si,.hl-sx,.hl-sr,.hl-sa,.hl-dl{color:var(--tok-string)}
.hl-n,.hl-na,.hl-nb,.hl-nc,.hl-ni,.hl-ne,.hl-nl,.hl-nn,.hl-nt,.hl-nv,.hl-no,.hl-nd,.hl-bp,.hl-fm,.hl-vc,.hl-vg,.hl-vi,.hl-vm,.hl-py{color:var(--tok-property)}
.hl-nf,.hl-nx{color:var(--tok-function)}
.hl-o,.hl-p,.hl-ow{color:var(--tok-operator)}
.hl-c,.hl-c1,.hl-ch,.hl-cm,.hl-cp,.hl-cpf,.hl-cs{color:var(--tok-comment);font-style:italic}
.hl-m,.hl-mi,.hl-mf,.hl-mh,.hl-mo,.hl-mb,.hl-il{color:var(--tok-number)}
.hl-l,.hl-ld{color:var(--tok-value)}
.hl-w{color:inherit}
.hl-err{color:var(--sw-brand-fuchsia)}

/* ═══ TABS (pure CSS, no JS) ═══ */
.lp-tabs{margin:1.5rem 0;display:flex;flex-wrap:wrap;border-bottom:1px solid var(--border-default)}
.lp-tab__radio{display:none}
.lp-tab__btn{padding:0.625rem 1.25rem;font-family:var(--font-code);font-size:0.8125rem;font-weight:600;color:var(--role-tab-default);cursor:pointer;border-bottom:2px solid transparent;transition:all 0.15s;order:-1}
.lp-tab__btn:hover{color:var(--fg-default)}
.lp-tab__radio:checked+.lp-tab__btn{color:var(--role-tab-active);border-bottom-color:var(--role-tab-active)}
.lp-tab__panel{display:none;width:100%;position:relative;order:99}
.lp-tab__panel pre{background:var(--role-code-block-bg);color:var(--role-code-block-text);border:1px solid var(--border-default);border-top:none;border-radius:0 0 10px 10px;padding:1.5rem;overflow-x:auto;font-family:var(--font-code);font-size:0.8125rem;line-height:1.75;margin:0}
.lp-tab__panel code{background:none;padding:0;color:inherit}
.lp-tab__panel .lp-code__lang{position:absolute;top:0.75rem;right:1rem;font-family:var(--font-code);font-size:0.65rem;color:var(--fg-subtle);text-transform:uppercase;letter-spacing:0.1em}
/* Radio checked shows its next sibling label's next sibling panel via ~ */
.lp-tab__radio:nth-of-type(1):checked~.lp-tab__panel:nth-of-type(1){display:block}
.lp-tab__radio:nth-of-type(2):checked~.lp-tab__panel:nth-of-type(2){display:block}
.lp-tab__radio:nth-of-type(3):checked~.lp-tab__panel:nth-of-type(3){display:block}
.lp-tab__radio:nth-of-type(4):checked~.lp-tab__panel:nth-of-type(4){display:block}
.lp-tab__radio:nth-of-type(5):checked~.lp-tab__panel:nth-of-type(5){display:block}
.lp-tab__radio:nth-of-type(6):checked~.lp-tab__panel:nth-of-type(6){display:block}
.lp-tab__radio:nth-of-type(7):checked~.lp-tab__panel:nth-of-type(7){display:block}
.lp-tab__radio:nth-of-type(8):checked~.lp-tab__panel:nth-of-type(8){display:block}

/* ═══ PRICING ═══ */
.lp-pricing{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:1.25rem;margin-top:1.5rem}
.lp-pricing__card{background:var(--bg-surface);border:1px solid var(--border-default);border-radius:12px;padding:2rem 1.75rem;display:flex;flex-direction:column;transition:all 0.2s}
.lp-pricing__card:hover{border-color:var(--fg-emphasis-small);transform:translateY(-2px)}
.lp-pricing__card--featured{border-top:3px solid var(--role-pricing-featured-accent);box-shadow:0 4px 24px rgba(247,42,114,0.08)}
.lp-pricing__name{font-family:var(--font-heading);font-size:1.125rem;font-weight:700;color:var(--fg-default);margin-bottom:0.5rem}
.lp-pricing__price{font-family:var(--font-heading);font-size:clamp(2rem,3vw,2.75rem);font-weight:700;color:var(--role-pricing-price);line-height:1.1;margin-bottom:0.25rem}
.lp-pricing__unit{font-size:0.875rem;font-weight:500;color:var(--fg-muted);margin-left:0.25rem}
.lp-pricing__desc{font-size:0.875rem;color:var(--fg-muted);margin-bottom:1.5rem;line-height:1.5}
.lp-pricing__feats{list-style:none;padding:0;margin-bottom:2rem;flex-grow:1}
.lp-pricing__feat{display:flex;gap:0.5rem;align-items:flex-start;font-size:0.875rem;color:var(--role-body-text);margin-bottom:0.625rem;line-height:1.5}
.lp-pricing__check{color:var(--role-pricing-check);font-weight:700;flex-shrink:0}

/* ═══ LINKS ═══ */
.lp-links-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:1rem;margin-top:1.5rem}
.lp-link-card{display:flex;flex-direction:column;gap:0.375rem;padding:1.25rem 1.5rem;background:var(--bg-surface);border:1px solid var(--border-default);border-left:3px solid var(--fg-emphasis-small);border-radius:0 8px 8px 0;text-decoration:none;transition:all 0.2s;position:relative}
.lp-link-card:hover{border-color:var(--fg-emphasis-small);transform:translateX(4px)}
.lp-link-card__text{font-family:var(--font-heading);font-weight:700;font-size:1rem;color:var(--role-link-default)}
.lp-link-card__desc{font-size:0.8125rem;color:var(--fg-muted);line-height:1.5}
.lp-link-card__arrow{position:absolute;right:1.25rem;top:50%;transform:translateY(-50%);color:var(--fg-subtle);font-size:1.25rem;transition:color 0.15s}
.lp-link-card:hover .lp-link-card__arrow{color:var(--fg-emphasis-small)}

/* ═══ CTA ═══ */
.lp-section--cta{text-align:center;padding:6rem 0;border-bottom:none;position:relative;overflow:hidden}
.lp-section--cta::before{content:'';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:800px;height:400px;background:radial-gradient(ellipse,var(--sw-fuchsia) 0%,transparent 70%);opacity:0.03;pointer-events:none}
.lp-cta__title{font-family:var(--font-heading);font-size:clamp(1.75rem,4vw,2.75rem);font-weight:700;color:var(--role-heading-h1);margin-bottom:0.75rem}
.lp-cta__subtitle{color:var(--role-body-text);margin-bottom:2rem;font-size:1.125rem}

.lp-cta-row{display:flex;gap:1rem;flex-wrap:wrap;margin-top:2rem}
.lp-section--cta .lp-cta-row{justify-content:center}
.lp-btn{display:inline-flex;align-items:center;padding:0.875rem 2.25rem;font-family:var(--font-heading);font-size:0.9375rem;font-weight:700;border-radius:8px;text-decoration:none;transition:all 0.2s;cursor:pointer;border:1px solid transparent}
.lp-btn--primary{background:var(--role-button-primary-bg);color:var(--role-button-primary-text);box-shadow:0 0 20px rgba(247,42,114,0.15)}
.lp-btn--primary:hover{transform:translateY(-2px);box-shadow:0 4px 24px rgba(247,42,114,0.25)}
.lp-btn--secondary{background:transparent;color:var(--role-button-secondary-text);border-color:var(--role-button-secondary-border)}
.lp-btn--secondary:hover{border-color:var(--fg-emphasis-small);transform:translateY(-1px)}

/* ═══ FOOTER ═══ */
.lp-footer{padding:2.5rem 0;border-top:1px solid var(--border-default)}
.lp-footer__inner{display:flex;justify-content:space-between;align-items:center;font-size:0.8125rem;color:var(--role-footer-text)}
.lp-footer__links{display:flex;gap:1.75rem}
.lp-footer__links a{color:var(--role-footer-text);text-decoration:none;transition:color 0.15s}
.lp-footer__links a:hover{color:var(--role-footer-link-hover)}

/* ═══ MOBILE ═══ */
@media(max-width:768px){
  .lp-hero{padding:4rem 0 3rem}
  .lp-hero::before,.lp-hero::after{display:none}
  .lp-section{padding:3rem 0}
  .lp-navbar{padding:0.75rem 1rem}
  .lp-navbar__links{gap:0.75rem}
  .lp-footer__inner{flex-direction:column;gap:0.75rem;text-align:center}
  .lp-cta-row{flex-direction:column}
  .lp-btn{width:100%;justify-content:center}
  .lp-stats-row{gap:2rem}
  .lp-stat::after{display:none}
  .lp-compare{grid-template-columns:1fr}
  .lp-steps::before{left:1.2rem}
}
"""
