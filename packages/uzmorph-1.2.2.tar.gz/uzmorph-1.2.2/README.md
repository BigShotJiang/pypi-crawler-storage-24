# Uzbek Morphological Analyzer using Complete Set of Ending (CSE)

[![GitHub](https://img.shields.io/badge/GitHub-Repository-blue?logo=github)](https://github.com/UlugbekSalaev/uzmorph)
[![Hugging Face](https://img.shields.io/badge/%F0%9F%A4%97%20Hugging%20Face-Space-orange)](https://huggingface.co/spaces/ulugbeksalaev/uzmorph)
[![PyPI](https://img.shields.io/badge/PyPI-Project-green?logo=python)](https://pypi.org/project/uzmorph/)
[![Website](https://img.shields.io/badge/Website-morph.uz-lightgrey)](https://morph.uz)

## Project Description
**uzmorph** is a professional-grade morphological analyzer for the Uzbek language that combines a massive lexicon (~122k stems) with **CSE (Complete Set of Endings)** morphological rules. It supports robust suffix stripping and multi-POS disambiguation for high-accuracy linguistic analysis.

You can try the live demo here: [Hugging Face Space](https://huggingface.co/spaces/ulugbeksalaev/uzmorph)

## Key Features
- **High Accuracy:** Achieved **93% Word Coverage Accuracy** on a sample of 20K unique Uzbek words.
- **Massive Lexicon:** Built with over **122K unique stem-POS pairs**.
- **Rule-Based CSE Engine:** Implements the **Complete Set of Endings** paradigm for agglutinative suffix analysis.
- **Multi-POS Support:** Handles ambiguous words (e.g., `ot` as both Noun "horse" and Verb "throw") by validating suffix rules against lexicon POS.
- **Rich Morphological Tagging:** Extracts detailed features including part-of-speech (POS), tense, person, possession, case, and voice.
- **Flat JSON Output:** Returns analysis results in a developer-friendly, flattened JSON-compatible format.

## Installation
```bash
pip install uzmorph
```

## Quick Start
```python
from uzmorph import UzMorph

# Initialize the analyzer
analyzer = UzMorph()

# Analyze a word
results = analyzer.analyze("maktabimda")

# Formatted console print
analyzer.print_result(results)
```

## JSON Result Sample
Each analysis result is a dictionary containing the following structure:
```json
[
    {
        "word": "maktabimda",
        "stem": "maktab",
        "lemma": "maktab",
        "cse": "imda",
        "cse_formula": "(i)mda",
        "pos": "NOUN",
        "possession": "1",
        "cases": "Locative",
        "singular": "1",
        "syntactical_affixes": "(i)m da",
        "note": null,
        "ball": 308
    }
]
```

## API Reference
### `UzMorph` Class
- `analyze(word, pos_filter=None)`: Performs morphological analysis and returns a list of results.
- `print_result(results)`: Prints formatted output to the console.
- `get_pos_list()`: Returns a formatted string of all available POS tags.
- `get_features_list()`: Returns a list of all possible property keys in the result.

## Project Structure (for PyPI)
For a clean PyPI contribution, only the following files are included in the package:
- `uzmorph/` - Core package directory containing implementation and data files (`root.csv`, `cse.csv`, etc.)
- `pyproject.toml` - Package metadata and build configuration.
- `LICENSE` - MIT License file.
- `README.md` - Documentation.
- `MANIFEST.in` - File inclusion rules for the source distribution.

## License
MIT