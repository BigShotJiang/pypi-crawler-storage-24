# Changelog

## 0.1.7

- Trim keywords to match pyproject template guide

## 0.1.3

- Add Development section to README

## 0.1.1 (2026-03-15)

- Fix column alignment for CJK and wide Unicode characters

## 0.1.0 (2026-03-13)

- Initial release
- `format_table()` for string output
- `table()` for quick printing
- Dict list and headers+rows input modes
- Column alignment (left, right, center)
- Cell truncation with max_width
- Border styles: simple, markdown, none
