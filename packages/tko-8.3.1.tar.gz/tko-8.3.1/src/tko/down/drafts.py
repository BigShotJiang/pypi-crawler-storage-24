import os

class Drafts:

    draft_readme: str = r"""Escreva aqui as informações que você quer salvar, esse é o seu rascunho.
O texto abaixo é informativo e você pode apagar depois de aprender como usar os rascunhos.

## Como usar os rascunhos

- Para renomear seu rascunho, basta renomear a pasta do rascunho.
- Para reorganizar, você pode criar subpastas dentro do sandbox e mover as pastas de rascunhos pra lá.
- Você pode usar o atalho R(Reload) no TKO para recarregar os rascunhos depois de criar, renomear ou reorganizar eles.
- Tudo que você fizer nos rascunhos também será rastreado pela ferramenta.

## Como criar seus próprios testes

Um teste é composto de um `input` (o texto que será fornecido para o programa) e um `output` (o texto que o programa deve retornar para esse input) e pode ter opcionalmente um `label` para facilitar a identificação do teste.

Seus casos de teste personalizados podem ser escritos diretamente aqui na descrição do problema dentro de um fenced code block com a linguagem `toml` ou em um arquivo `tests.toml` na pasta do problema. O TKO irá carregar automaticamente os testes quando a tarefa for aberta ou executada novamente.

Exemplo de teste para ler dois números, um por linha, e imprimir a soma e a subtração deles.

Se quiser habilitar esses casos de teste e ver funcionando, altere o fenced abaixo de `bash` para `toml` e execute novamente a tarefa no TKO.

```bash
[[tests]]
input = '''
3
2
'''
output = '''
5
1
'''

[[tests]]
label = 'números negativos'
input = '''
-3
-4
'''
output = '''
-7
1
'''
```

"""

    ts_draft = r"""
const input = () => ""; //essa função será gerada pelo tko na execução
export {};

function main() {
    console.log("qxcode");
}
main();
"""[1:]

    c_draft = r"""
#include <stdio.h>

int main() {
    puts("qxcode");
    return 0;
}

"""[1:]

    cpp_draft = r"""
#include <iostream>

int main() {
    std::cout << "qxcode\n";
}

"""[1:]

    java_draft = r"""
public class draft {
    public static void main(String args[]) {
        System.out.println("qxcode");
    }
}

"""[1:]

    go_draft = (
        r"package main""\n"
        r'import "fmt"'"\n"
        r"func main() {""\n"
        r'    fmt.Println("qxcode")''\n'
        r"}""\n"
    )
    
    yaml_draft = r"""
build: comando para construir o executável
run: comando para rodar o programa
"""[1:]
    
    hs_draft = r"""
main :: IO ()
main = putStrLn "qxcode"
"""[1:]


    drafts = {'c': c_draft, 'cpp': cpp_draft, 'ts': ts_draft, 'java': java_draft, 'go': go_draft, 'hs': hs_draft, 'yaml': yaml_draft}

    @staticmethod
    def load_drafts_only(folder: str, lang: str, extra: list[str] | None = None) -> list[str]:
        if extra is None:
            extra = []
        folder = os.path.normpath(os.path.abspath(folder))
        draft_list: list[str] = []
        allowed = extra
        if lang != "":
            allowed.append(lang)
        if "c" in allowed:
            allowed.append("h")
        if "cpp" in allowed:
            allowed.append("h")
            allowed.append("hpp")
        if not os.path.isdir(folder):
            return []
        for root, _, files in os.walk(folder):
            cut_root = root[len(folder):]
            pieces = cut_root.split(os.sep)
            if any([piece.startswith(".") for piece in pieces]) or any([piece.startswith("_") for piece in pieces]):
                continue
            for file in files:
                if file.endswith(tuple(allowed)):
                    draft_list.append(os.path.join(root, file))
        return draft_list
    
    @staticmethod
    def create_sandbox_draft(dir: str, key: str):
        with open (os.path.join(dir, "README.md"), "w", encoding="utf-8") as f:
            f.write(f"---\n# Não altere essa chave, ela deve ser única para cada rascunho\nkey={key}\n---\n\n# {os.path.basename(dir)}\n\n" + Drafts.draft_readme)
