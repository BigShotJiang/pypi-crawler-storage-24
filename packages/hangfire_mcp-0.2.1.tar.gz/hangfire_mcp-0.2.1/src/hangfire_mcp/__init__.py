"""Hangfire MCP Server - Manage Hangfire background jobs via MCP."""

from hangfire_mcp.server import main

try:
    from hangfire_mcp._version import __version__
except ImportError:
    __version__ = "0.0.0"

__all__ = ["main"]
