---
name: Bug Report
about: Report a bug or issue
title: "[Bug] "
labels: bug
assignees: ""
---

## Description
A clear description of the bug.

## Steps to Reproduce
1. ...
2. ...
3. ...

## Expected Behavior
What you expected to happen.

## Actual Behavior
What actually happened.

## Environment
- OS: [e.g. Windows 11, macOS 14]
- Python version: [e.g. 3.12]
- hangfire-mcp version: [e.g. 0.1.0]
- SQL Server version: [e.g. 2022]

## Logs / Error Output
```
Paste any error messages here
```
