# pyprocessors_capitalizer

[![license](https://img.shields.io/github/license/oterrier/pyprocessors_capitalizer)](https://github.com/oterrier/pyprocessors_capitalizer/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyprocessors_capitalizer/workflows/tests/badge.svg)](https://github.com/oterrier/pyprocessors_capitalizer/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyprocessors_capitalizer)](https://codecov.io/gh/oterrier/pyprocessors_capitalizer)
[![docs](https://img.shields.io/readthedocs/pyprocessors_capitalizer)](https://pyprocessors_capitalizer.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyprocessors_capitalizer)](https://pypi.org/project/pyprocessors_capitalizer/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyprocessors_capitalizer)](https://pypi.org/project/pyprocessors_capitalizer/)

Processor that replaces document text with capitalized versions of annotated spans.

## Installation

You can simply `pip install pyprocessors_capitalizer`.

## Developing

### Pre-requisites

You will need to install [uv](https://docs.astral.sh/uv/) (for managing the virtual environment and running tasks):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyprocessors_capitalizer
```

### Running the test suite

Install dependencies and run the full test suite against Python 3.12:

```
uv sync --extra test
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

To auto-fix formatting:

```
uv run ruff format .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.
