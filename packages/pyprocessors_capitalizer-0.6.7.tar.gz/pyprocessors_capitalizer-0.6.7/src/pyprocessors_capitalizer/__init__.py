"""Replace document text with capitalized annotations"""

__version__ = "0.6.7"
