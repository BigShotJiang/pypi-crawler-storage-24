"""Performance benchmark tests."""
