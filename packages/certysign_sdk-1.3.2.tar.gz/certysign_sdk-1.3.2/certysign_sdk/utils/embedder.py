"""CertySign SDK — local signature embedding.

Embeds CMS/PKCS#7 signatures into documents on the subscriber's system.
Documents NEVER leave the subscriber's infrastructure.

Supports:
  - PDF  (PAdES-style with cryptographic PKCS#7 embedding)
  - XML  (XMLDSig enveloped signature)
  - JSON (JWS-like detached signature)

Visual stamp format (matches the CertySign platform):
  ┌──────────────────────────────────────────┐
  │ Digitally signed by: user@example.com    │
  │ Date: 2026-03-13T11:07:28.927Z          │
  │ Certificate: 9EF9C8E88478FC08C6759942   │
  │ Standard: PAdES Baseline B-B             │
  └──────────────────────────────────────────┘

Requirements:
  pip install pypdf cryptography
"""

import hashlib
import struct
import re
import json as _json
from datetime import datetime, timezone
from typing import Callable, Optional, Union

# Placeholder size for PKCS#7 signature content (16384 bytes = 32768 hex chars)
SIG_PLACEHOLDER_LENGTH = 32768

# Visual stamp constants
STAMP_WIDTH = 260
STAMP_HEIGHT = 56     # 4 lines × 10pt + 2 × 8pt padding
STAMP_PADDING_X = 8
STAMP_PADDING_Y = 8
STAMP_FONT_SIZE = 7
STAMP_LINE_HEIGHT = 10


class SignatureEmbedder:
    """Embed digital signatures into PDF, XML, and JSON documents locally."""

    def __init__(self, *, tsa_url: str = None):
        """Initialise the embedder.

        Args:
            tsa_url: TSA Service base URL for PAdES-T timestamps.
                     When set, signatures are upgraded from PAdES B-B to
                     PAdES B-T (RFC 3161 timestamp embedded).
        """
        self.tsa_url = tsa_url

    # ── PDF ───────────────────────────────────────────────────────────────

    def embed_in_pdf(
        self,
        pdf_buffer: bytes,
        *,
        signature: str = None,
        signatures: list = None,
        signer_email: str = None,
        signer_name: str = None,
        certificate: str = None,
        chain: str = None,
        cert_serial_number: str = None,
        reason: str = "Digital signature",
        location: str = "",
        document_hash: str = None,
        hash_algorithm: str = "sha256",
        algorithm: str = None,
        standard: str = None,
        timestamp: str = None,
        sign_callback: Callable = None,
        tsa_url: str = None,
        signature_position: dict = None,
    ) -> bytes:
        """Embed one or more digital signatures into a PDF document.

        Creates a PDF /Sig dictionary with /ByteRange and /Contents that
        Adobe Reader, Foxit, and other PDF readers recognise as a valid
        digital signature (PAdES compliant).

        **Recommended:** Pass a sign_callback — the embedder will:
          1. Prepare the PDF with visual stamp and /Sig placeholder
          2. Compute SHA-256 hash of the ByteRange regions
          3. Call your sign_callback(hash_hex) to get the HSM signature
          4. Build PKCS#7 and patch it into /Contents

        Args:
            pdf_buffer: Original unsigned PDF bytes.
            signature: Pre-computed Base64 CMS/PKCS#7 signature.
            signatures: List of signature dicts for multi-recipient.
            signer_email: Signer email (for visual stamp).
            signer_name: Fallback signer display name.
            certificate: PEM certificate string.
            chain: PEM certificate chain string.
            cert_serial_number: Certificate serial number.
            reason: Signing reason.
            location: Physical signing location.
            sign_callback: Callable(hash_hex) → sign result dict.
                           Receives the ByteRange hash and must return
                           {'data': {'signature': '...', 'certificate': '...'}}.
            tsa_url: Override TSA URL for this call.
            signature_position: Dict with optional 'page', 'x', 'y', 'width'.

        Returns:
            Signed PDF as bytes.

        Example (recommended — PAdES Baseline B-T)::

            cert = client.certificates.get_active()
            signed_pdf = client.embedder.embed_in_pdf(
                pdf_bytes,
                cert_serial_number=cert["data"]["certSerialNumber"],
                signer_name="Dr. Amina Okonkwo",
                reason="Health claim approval",
                sign_callback=lambda h: client.sign.sign_hash(
                    document_hash=h, hash_algorithm="sha256"
                ),
            )
            open("signed.pdf", "wb").write(signed_pdf)
        """
        try:
            from pypdf import PdfReader, PdfWriter
            from pypdf.generic import (
                NameObject, DictionaryObject, ArrayObject,
                ByteStringObject, NumberObject, DecodedStreamObject,
            )
        except ImportError:
            raise ImportError(
                "pypdf is required for PDF embedding. "
                "Install it: pip install pypdf"
            )

        try:
            from cryptography import x509 as cx509
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.backends import default_backend
        except ImportError:
            raise ImportError(
                "cryptography is required for PDF embedding. "
                "Install it: pip install cryptography"
            )

        if not pdf_buffer:
            raise ValueError("embed_in_pdf: pdf_buffer is required")

        # Normalise to a single entry
        entry = (signatures[0] if signatures else None) or {}
        sig_email = (
            entry.get("signer_email")
            or entry.get("recipient_email")
            or signer_email
            or signer_name
            or "CertySign"
        )
        cert_serial = entry.get("cert_serial_number") or cert_serial_number or ""
        sign_date_str = entry.get("timestamp") or entry.get("signed_at") or timestamp
        sign_date = (
            datetime.fromisoformat(sign_date_str.replace("Z", "+00:00"))
            if sign_date_str
            else datetime.now(timezone.utc)
        )
        sig_reason = entry.get("reason") or reason
        sig_location = entry.get("location") or location
        cert_pem = entry.get("certificate") or certificate
        chain_pem = entry.get("chain") or chain
        _sign_callback = entry.get("sign_callback") or sign_callback
        precomputed_sig = entry.get("signature") or signature
        resolv_tsa = entry.get("tsa_url") or tsa_url or self.tsa_url
        sig_standard = entry.get("standard") or standard or (
            "PAdES Baseline B-T" if resolv_tsa else "PAdES Baseline B-B"
        )
        pos = signature_position or entry.get("signature_position") or {}

        if not _sign_callback and not precomputed_sig:
            raise ValueError(
                "embed_in_pdf: either sign_callback or signature is required"
            )

        # Auto-resolve cert serial from PEM
        if not cert_serial and cert_pem:
            cert_serial = _cert_serial_from_pem(cert_pem, cx509, default_backend)

        # signCallback pre-flight: discover cert serial before drawing stamp
        if _sign_callback and not cert_serial:
            dummy_hash = "0" * 64
            preflight = _sign_callback(dummy_hash)
            pf_cert_pem = (
                preflight.get("data", {}).get("certificate")
                if isinstance(preflight, dict)
                else None
            ) or preflight.get("certificate", "") if isinstance(preflight, dict) else ""
            cert_serial = (
                preflight.get("data", {}).get("certSerialNumber", "")
                if isinstance(preflight, dict)
                else ""
            )
            if not cert_serial and pf_cert_pem:
                cert_serial = _cert_serial_from_pem(pf_cert_pem, cx509, default_backend)

        # ── Build the PDF with stamp + signature placeholder ───────────────
        reader = PdfReader(pdf_buffer if not isinstance(pdf_buffer, bytes)
                           else __import__("io").BytesIO(pdf_buffer))
        writer = PdfWriter()
        writer.append_pages_from_reader(reader)

        pages = writer.pages
        page_idx = max(0, min((pos.get("page", len(pages)) - 1), len(pages) - 1))
        sig_page = pages[page_idx]

        # Draw stamp as a content stream overlay
        x = pos.get("x", 20)
        y = pos.get("y", 20)
        stamp_w = pos.get("width", STAMP_WIDTH)
        stamp_h = STAMP_HEIGHT

        text_lines = [
            f"Digitally signed by: {sig_email}",
            f"Date: {_node_iso_timestamp(sign_date)}",
            f"Certificate: {cert_serial}",
            f"Standard: {sig_standard}",
        ]

        appearance_ref = _build_stamp_appearance(writer, stamp_w, stamp_h, text_lines)

        # ── Create /Sig dictionary with placeholder ─────────────────────────
        placeholder_hex = "0" * SIG_PLACEHOLDER_LENGTH
        sig_dict = DictionaryObject()
        sig_dict[NameObject("/Type")] = NameObject("/Sig")
        sig_dict[NameObject("/Filter")] = NameObject("/Adobe.PPKLite")
        sig_dict[NameObject("/SubFilter")] = NameObject("/adbe.pkcs7.detached")
        # ByteRange placeholder values — will be patched after save
        sig_dict[NameObject("/ByteRange")] = ArrayObject([
            NumberObject(0), NumberObject(9999999999),
            NumberObject(9999999999), NumberObject(9999999999),
        ])
        sig_dict[NameObject("/Contents")] = ByteStringObject(
            bytes.fromhex(placeholder_hex)
        )
        sig_dict[NameObject("/Reason")] = _pdf_string(sig_reason)
        sig_dict[NameObject("/M")] = _pdf_string(_pdf_date(sign_date))
        sig_dict[NameObject("/Name")] = _pdf_string(sig_email)
        if sig_location:
            sig_dict[NameObject("/Location")] = _pdf_string(sig_location)

        # Add AcroForm signature widget without relying on removed pypdf internals.
        _add_signature_field(writer, sig_page, sig_dict, x, y, stamp_w, stamp_h, appearance_ref)

        # ── Phase 1: Save with placeholder ────────────────────────────────
        import io
        buf = io.BytesIO()
        writer.write(buf)
        pdf_bytes = bytearray(buf.getvalue())

        # ── Phase 2: Locate placeholder and compute ByteRange ─────────────
        # The /Contents value is stored as a hex string or raw bytes in the PDF.
        # Find the placeholder hex or the raw zero bytes.
        pdf_latin = bytes(pdf_bytes).decode("latin-1")
        placeholder_idx = pdf_latin.find(placeholder_hex)

        if placeholder_idx == -1:
            # Try finding raw zero bytes (some PDF writers store as binary)
            zero_bytes = b"\x00" * (SIG_PLACEHOLDER_LENGTH // 2)
            placeholder_idx = bytes(pdf_bytes).find(zero_bytes)
            if placeholder_idx == -1:
                raise RuntimeError(
                    "embed_in_pdf: could not locate signature placeholder in saved PDF"
                )
            # Work in raw mode — replace raw bytes, not hex
            use_hex_mode = False
            contents_start = placeholder_idx - 1  # '<' marker
            contents_end = placeholder_idx + len(zero_bytes) + 1
        else:
            use_hex_mode = True
            contents_start = placeholder_idx - 1  # '<'
            contents_end = placeholder_idx + SIG_PLACEHOLDER_LENGTH + 1  # '>'

        total_len = len(pdf_bytes)
        br0, br1 = 0, contents_start
        br2, br3 = contents_end, total_len - contents_end

        # Patch ByteRange in-place
        _patch_byte_range(pdf_bytes, pdf_latin, placeholder_idx, br0, br1, br2, br3)

        # ── Phase 3: Compute ByteRange hash ───────────────────────────────
        h = hashlib.sha256()
        h.update(bytes(pdf_bytes[br0: br0 + br1]))
        h.update(bytes(pdf_bytes[br2: br2 + br3]))
        hash_hex = h.hexdigest()

        # ── Phase 4: Get the signature ────────────────────────────────────
        raw_sig_b64 = None
        if _sign_callback:
            sign_result = _sign_callback(hash_hex)
            raw_sig_b64 = (
                sign_result.get("data", {}).get("signature")
                if isinstance(sign_result, dict)
                else None
            ) or (sign_result.get("signature") if isinstance(sign_result, dict) else None)
            if not cert_pem:
                cert_pem = (
                    sign_result.get("data", {}).get("certificate")
                    if isinstance(sign_result, dict) else None
                )
            if not chain_pem:
                chain_pem = (
                    sign_result.get("data", {}).get("chain")
                    if isinstance(sign_result, dict) else None
                )
        else:
            raw_sig_b64 = precomputed_sig

        # ── Phase 4.5: Fetch TSA timestamp (PAdES B-B → PAdES B-T) ───────
        timestamp_token_der = None
        if resolv_tsa and raw_sig_b64:
            import base64
            raw_sig_bytes = base64.b64decode(raw_sig_b64)
            sig_hash = hashlib.sha256(raw_sig_bytes).hexdigest()
            timestamp_token_der = _fetch_timestamp(resolv_tsa, sig_hash)

        # ── Phase 5: Build PKCS#7 and patch into /Contents ────────────────
        p7_hex = _build_pkcs7_hex(
            raw_sig_b64, cert_pem, chain_pem, sign_date,
            sig_email, sig_reason, sig_location, cert_serial,
            timestamp_token_der, cx509, default_backend,
        )

        if len(p7_hex) > SIG_PLACEHOLDER_LENGTH:
            raise RuntimeError(
                f"PKCS#7 signature too large ({len(p7_hex)} hex chars > "
                f"{SIG_PLACEHOLDER_LENGTH} placeholder). "
                "Increase SIG_PLACEHOLDER_LENGTH."
            )

        padded_hex = p7_hex.ljust(SIG_PLACEHOLDER_LENGTH, "0")

        if use_hex_mode:
            padded_bytes = padded_hex.encode("latin-1")
            pdf_bytes[placeholder_idx: placeholder_idx + SIG_PLACEHOLDER_LENGTH] = padded_bytes
        else:
            raw_p7_bytes = bytes.fromhex(padded_hex)
            pdf_bytes[placeholder_idx: placeholder_idx + len(zero_bytes)] = raw_p7_bytes

        return bytes(pdf_bytes)

    def embedInPdf(self, pdf_buffer: bytes, options: dict = None, /, **kwargs) -> bytes:
        """Node-style alias for :meth:`embed_in_pdf`."""
        opts = _merge_options(options, kwargs)
        return self.embed_in_pdf(
            pdf_buffer,
            signature=opts.get("signature"),
            signatures=opts.get("signatures"),
            signer_email=opts.get("signer_email") or opts.get("signerEmail"),
            signer_name=opts.get("signer_name") or opts.get("signerName"),
            certificate=opts.get("certificate"),
            chain=opts.get("chain"),
            cert_serial_number=opts.get("cert_serial_number") or opts.get("certSerialNumber"),
            reason=opts.get("reason", "Digital signature"),
            location=opts.get("location", ""),
            document_hash=opts.get("document_hash") or opts.get("documentHash"),
            hash_algorithm=opts.get("hash_algorithm") or opts.get("hashAlgorithm") or "sha256",
            algorithm=opts.get("algorithm"),
            standard=opts.get("standard"),
            timestamp=opts.get("timestamp"),
            sign_callback=opts.get("sign_callback") or opts.get("signCallback"),
            tsa_url=opts.get("tsa_url") or opts.get("tsaUrl"),
            signature_position=opts.get("signature_position") or opts.get("signaturePosition"),
        )

    # ── XML ───────────────────────────────────────────────────────────────

    def embed_in_xml(
        self,
        xml_string: str,
        *,
        signature: str = None,
        signatures: list = None,
        certificate: str = None,
        document_hash: str = None,
        hash_algorithm: str = "sha256",
        cert_serial_number: str = "",
        signer_email: str = None,
        signer_name: str = None,
        timestamp: str = None,
        standard: str = None,
    ) -> str:
        """Embed digital signatures into an XML document (XMLDSig enveloped).

        Supports multiple signatures — each signer gets their own
        <ds:Signature> element.

        Args:
            xml_string: Original XML content.
            signature: Single Base64 signature value.
            signatures: List of signature entry dicts for multi-recipient.
            certificate: PEM certificate.
            document_hash: Hex document hash.
            hash_algorithm: sha256 | sha384 | sha512.
            cert_serial_number: Certificate serial number.
            signer_email: Signer email.
            signer_name: Fallback signer name.
            timestamp: ISO 8601 signing timestamp.
            standard: Signature standard label.

        Returns:
            Signed XML string with embedded <ds:Signature> element(s).
        """
        if not xml_string:
            raise ValueError("embed_in_xml: xml_string is required")

        sig_entries = signatures if signatures else [
            {
                "signature": signature,
                "certificate": certificate,
                "document_hash": document_hash,
                "hash_algorithm": hash_algorithm,
                "cert_serial_number": cert_serial_number,
                "signer_email": signer_email or signer_name or "CertySign",
                "timestamp": timestamp,
                "standard": standard,
            }
        ]

        result = xml_string
        for idx, entry in enumerate(sig_entries):
            if not entry.get("signature"):
                raise ValueError(f"embed_in_xml: signature is required (entry {idx})")

            _signer_email = (
                entry.get("signer_email")
                or entry.get("recipient_email")
                or entry.get("signer_name")
                or "CertySign"
            )
            _standard = entry.get("standard") or "PAdES Baseline B-B"
            _ts = entry.get("timestamp") or entry.get("signed_at")
            _sign_date = (
                datetime.fromisoformat(_ts.replace("Z", "+00:00"))
                if _ts
                else datetime.now(timezone.utc)
            )
            _algo = (entry.get("hash_algorithm") or "sha256").lower()
            _cert_pem = entry.get("certificate") or ""
            _doc_hash = entry.get("document_hash") or ""
            _serial = entry.get("cert_serial_number") or ""

            algorithm_uri = {
                "sha256": "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256",
                "sha384": "http://www.w3.org/2001/04/xmldsig-more#rsa-sha384",
                "sha512": "http://www.w3.org/2001/04/xmldsig-more#rsa-sha512",
            }.get(_algo, "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256")

            digest_uri = {
                "sha256": "http://www.w3.org/2001/04/xmlenc#sha256",
                "sha384": "http://www.w3.org/2001/04/xmldsig-more#sha384",
                "sha512": "http://www.w3.org/2001/04/xmlenc#sha512",
            }.get(_algo, "http://www.w3.org/2001/04/xmlenc#sha256")

            import base64
            cert_value = ""
            if _cert_pem:
                cert_value = (
                    _cert_pem
                    .replace("-----BEGIN CERTIFICATE-----", "")
                    .replace("-----END CERTIFICATE-----", "")
                    .replace("\n", "")
                    .replace("\r", "")
                    .strip()
                )

            digest_b64 = ""
            if _doc_hash:
                try:
                    digest_b64 = base64.b64encode(bytes.fromhex(_doc_hash)).decode()
                except ValueError:
                    digest_b64 = _doc_hash

            sig_xml = (
                f'\n  <ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#" '
                f'Id="CertySign-Signature-{idx}">\n'
                f"    <ds:SignedInfo>\n"
                f'      <ds:CanonicalizationMethod Algorithm="http://www.w3.org/2001/10/xml-exc-c14n#"/>\n'
                f'      <ds:SignatureMethod Algorithm="{algorithm_uri}"/>\n'
                f'      <ds:Reference URI="">\n'
                f"        <ds:Transforms>\n"
                f'          <ds:Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>\n'
                f"        </ds:Transforms>\n"
                f'        <ds:DigestMethod Algorithm="{digest_uri}"/>\n'
                f"        <ds:DigestValue>{digest_b64}</ds:DigestValue>\n"
                f"      </ds:Reference>\n"
                f"    </ds:SignedInfo>\n"
                f"    <ds:SignatureValue>{entry['signature']}</ds:SignatureValue>\n"
                f"    <ds:KeyInfo>\n"
                f"      <ds:X509Data>\n"
                f"        <ds:X509Certificate>{cert_value}</ds:X509Certificate>\n"
                f"        <ds:X509SerialNumber>{_xml_escape(_serial)}</ds:X509SerialNumber>\n"
                f"      </ds:X509Data>\n"
                f"    </ds:KeyInfo>\n"
                f"    <ds:Object>\n"
                f'      <SignatureProperties xmlns="urn:certysign:signature:1.0">\n'
                f"        <SignerEmail>{_xml_escape(_signer_email)}</SignerEmail>\n"
                f"        <Timestamp>{_sign_date.isoformat()}</Timestamp>\n"
                f"        <CertSerial>{_xml_escape(_serial)}</CertSerial>\n"
                f"        <Standard>{_xml_escape(_standard)}</Standard>\n"
                f"        <Provider>CertySign</Provider>\n"
                f"      </SignatureProperties>\n"
                f"    </ds:Object>\n"
                f"  </ds:Signature>"
            )

            # Insert before closing root tag
            match = list(re.finditer(r"</([^\s>]+)\s*>\s*$", result))
            if match:
                last_match = match[-1]
                pos = last_match.start()
                result = result[:pos] + sig_xml + "\n" + result[pos:]
            else:
                result += sig_xml

        return result

    def embedInXml(self, xml_string: str, options: dict = None, /, **kwargs) -> str:
        """Node-style alias for :meth:`embed_in_xml`."""
        opts = _merge_options(options, kwargs)
        return self.embed_in_xml(
            xml_string,
            signature=opts.get("signature"),
            signatures=opts.get("signatures"),
            certificate=opts.get("certificate"),
            document_hash=opts.get("document_hash") or opts.get("documentHash"),
            hash_algorithm=opts.get("hash_algorithm") or opts.get("hashAlgorithm") or "sha256",
            cert_serial_number=opts.get("cert_serial_number") or opts.get("certSerialNumber", ""),
            signer_email=opts.get("signer_email") or opts.get("signerEmail"),
            signer_name=opts.get("signer_name") or opts.get("signerName"),
            timestamp=opts.get("timestamp"),
            standard=opts.get("standard"),
        )

    # ── JSON ──────────────────────────────────────────────────────────────

    def embed_in_json(
        self,
        json_data,
        *,
        signature: str = None,
        signatures: list = None,
        certificate: str = None,
        chain: str = None,
        document_hash: str = None,
        hash_algorithm: str = "sha256",
        algorithm: str = None,
        signer_email: str = None,
        signer_name: str = None,
        cert_serial_number: str = "",
        timestamp: str = None,
        standard: str = None,
    ) -> dict:
        """Create a signed JSON envelope with one or more signatures.

        Args:
            json_data: Original JSON content as dict or JSON string.
            signature: Single Base64 signature.
            signatures: List of signature entry dicts for multi-recipient.
            certificate: PEM certificate.
            chain: PEM certificate chain.
            document_hash: Hex document hash.
            hash_algorithm: sha256 | sha384 | sha512.
            algorithm: Signature algorithm label.
            signer_email: Signer email.
            signer_name: Fallback signer name.
            cert_serial_number: Certificate serial number.
            timestamp: ISO 8601 signing timestamp.
            standard: Signature standard label.

        Returns:
            Signed JSON envelope dict with 'data', 'signatures', 'metadata'.
        """
        data = _json.loads(json_data) if isinstance(json_data, str) else json_data

        sig_entries = signatures if signatures else [
            {
                "signature": signature,
                "certificate": certificate,
                "chain": chain,
                "document_hash": document_hash,
                "hash_algorithm": hash_algorithm,
                "algorithm": algorithm,
                "signer_email": signer_email or signer_name or "CertySign",
                "cert_serial_number": cert_serial_number,
                "timestamp": timestamp,
                "standard": standard,
            }
        ]

        sigs_array = []
        for idx, entry in enumerate(sig_entries):
            if not entry.get("signature"):
                raise ValueError(
                    f"embed_in_json: signature is required (entry {idx})"
                )

            _signer_email = (
                entry.get("signer_email")
                or entry.get("recipient_email")
                or entry.get("signer_name")
                or "CertySign"
            )
            _ts = entry.get("timestamp") or entry.get("signed_at")
            _sign_date = (
                datetime.fromisoformat(_ts.replace("Z", "+00:00"))
                if _ts
                else datetime.now(timezone.utc)
            )

            sigs_array.append(
                {
                    "value": entry["signature"],
                    "algorithm": entry.get("algorithm") or "SHA256withRSA",
                    "hashAlgorithm": entry.get("hash_algorithm") or "sha256",
                    "documentHash": entry.get("document_hash") or "",
                    "timestamp": _sign_date.isoformat(),
                    "signer": {
                        "email": _signer_email,
                        "name": (
                            entry.get("recipient_name")
                            or entry.get("signer_name")
                            or _signer_email
                        ),
                        "certSerialNumber": entry.get("cert_serial_number") or "",
                    },
                    "certificate": entry.get("certificate"),
                    "chain": entry.get("chain"),
                    "standard": entry.get("standard") or "PAdES Baseline B-B",
                }
            )

        return {
            "data": data,
            "signatures": sigs_array,
            "metadata": {
                "provider": "CertySign Trust Services",
                "version": "2.0.0",
                "signatureCount": len(sigs_array),
                "signedAt": datetime.now(timezone.utc).isoformat(),
            },
        }

    def embedInJson(self, json_data, options: dict = None, /, **kwargs) -> dict:
        """Node-style alias for :meth:`embed_in_json`."""
        opts = _merge_options(options, kwargs)
        return self.embed_in_json(
            json_data,
            signature=opts.get("signature"),
            signatures=opts.get("signatures"),
            certificate=opts.get("certificate"),
            chain=opts.get("chain"),
            document_hash=opts.get("document_hash") or opts.get("documentHash"),
            hash_algorithm=opts.get("hash_algorithm") or opts.get("hashAlgorithm") or "sha256",
            algorithm=opts.get("algorithm"),
            signer_email=opts.get("signer_email") or opts.get("signerEmail"),
            signer_name=opts.get("signer_name") or opts.get("signerName"),
            cert_serial_number=opts.get("cert_serial_number") or opts.get("certSerialNumber", ""),
            timestamp=opts.get("timestamp"),
            standard=opts.get("standard"),
        )


def _merge_options(options: dict, kwargs: dict) -> dict:
    if options is None:
        merged = {}
    elif isinstance(options, dict):
        merged = dict(options)
    else:
        raise TypeError("options must be a dict")
    merged.update(kwargs)
    return merged


# ── PDF helpers ───────────────────────────────────────────────────────────────


def _build_stamp_stream(w, h, text_lines, font_name: str) -> bytes:
    """Build a PDF appearance stream for the visual stamp."""
    stream = (
        "q\n"
        "0.97 0.97 0.97 rg\n"
        "0.4 0.4 0.4 RG\n"
        f"0.75 w\n"
        f"0 0 {w:.2f} {h:.2f} re B\n"
        "BT\n"
        f"/{font_name} {STAMP_FONT_SIZE} Tf\n"
        "0.4 0.4 0.4 rg\n"
        f"{STAMP_PADDING_X:.2f} {h - STAMP_PADDING_Y - STAMP_FONT_SIZE:.2f} Td\n"
    )
    for line in text_lines:
        safe_line = line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        stream += f"({safe_line}) Tj\n0 -{STAMP_LINE_HEIGHT} Td\n"
    stream += "ET\nQ\n"
    return stream.encode("latin-1")


def _build_stamp_appearance(writer, width, height, text_lines):
    """Create a Form XObject appearance stream for the signature widget."""
    from pypdf.generic import (
        DictionaryObject,
        NameObject,
        NumberObject,
        FloatObject,
        ArrayObject,
        DecodedStreamObject,
    )

    font_key = NameObject("/CSHelvetica")
    font_obj = DictionaryObject()
    font_obj[NameObject("/Type")] = NameObject("/Font")
    font_obj[NameObject("/Subtype")] = NameObject("/Type1")
    font_obj[NameObject("/BaseFont")] = NameObject("/Helvetica")
    font_ref = writer._add_object(font_obj)

    resources = DictionaryObject()
    fonts = DictionaryObject()
    fonts[font_key] = font_ref
    resources[NameObject("/Font")] = fonts

    stream_obj = DecodedStreamObject()
    stream_obj.set_data(_build_stamp_stream(width, height, text_lines, "CSHelvetica"))
    stream_obj[NameObject("/Type")] = NameObject("/XObject")
    stream_obj[NameObject("/Subtype")] = NameObject("/Form")
    stream_obj[NameObject("/FormType")] = NumberObject(1)
    stream_obj[NameObject("/BBox")] = ArrayObject([
        FloatObject(0),
        FloatObject(0),
        FloatObject(width),
        FloatObject(height),
    ])
    stream_obj[NameObject("/Resources")] = resources
    return writer._add_object(stream_obj)

def _add_signature_field(writer, page, sig_dict, x, y, w, h, appearance_ref=None):
    """Attach a /Sig widget annotation and AcroForm entry to the page."""
    from pypdf.generic import (
        ArrayObject,
        DictionaryObject,
        FloatObject,
        IndirectObject,
        NameObject,
        NumberObject,
    )

    sig_ref = writer._add_object(sig_dict)

    widget = DictionaryObject()
    widget[NameObject("/Type")] = NameObject("/Annot")
    widget[NameObject("/Subtype")] = NameObject("/Widget")
    widget[NameObject("/FT")] = NameObject("/Sig")
    widget[NameObject("/Rect")] = ArrayObject([
        FloatObject(x),
        FloatObject(y),
        FloatObject(x + w),
        FloatObject(y + h),
    ])
    widget[NameObject("/V")] = sig_ref
    widget[NameObject("/T")] = _pdf_string("CertySign-Sig-0")
    widget[NameObject("/F")] = NumberObject(4)
    if appearance_ref is not None:
        ap = DictionaryObject()
        ap[NameObject("/N")] = appearance_ref
        widget[NameObject("/AP")] = ap

    page_ref = getattr(page, "indirect_reference", None)
    if page_ref is not None:
        widget[NameObject("/P")] = page_ref

    widget_ref = writer._add_object(widget)

    annots = page.get("/Annots")
    if isinstance(annots, IndirectObject):
        annots = annots.get_object()
    if annots is None:
        annots = ArrayObject()
        page[NameObject("/Annots")] = annots
    elif not isinstance(annots, ArrayObject):
        annots = ArrayObject([annots])
        page[NameObject("/Annots")] = annots
    annots.append(widget_ref)

    root = writer._root_object
    acro_form = root.get("/AcroForm")
    if isinstance(acro_form, IndirectObject):
        acro_form_obj = acro_form.get_object()
    elif acro_form is None:
        acro_form_obj = DictionaryObject()
        acro_form_ref = writer._add_object(acro_form_obj)
        root[NameObject("/AcroForm")] = acro_form_ref
    else:
        acro_form_obj = acro_form

    fields = acro_form_obj.get("/Fields")
    if isinstance(fields, IndirectObject):
        fields = fields.get_object()
    if fields is None:
        fields = ArrayObject()
        acro_form_obj[NameObject("/Fields")] = fields
    elif not isinstance(fields, ArrayObject):
        fields = ArrayObject([fields])
        acro_form_obj[NameObject("/Fields")] = fields
    fields.append(widget_ref)
    acro_form_obj[NameObject("/SigFlags")] = NumberObject(3)


def _pdf_string(value: str):
    """Create a PDF string object."""
    from pypdf.generic import TextStringObject
    return TextStringObject(value)


def _pdf_date(dt: datetime) -> str:
    """Format a datetime as PDF date string (D:YYYYMMDDHHmmss+00'00')."""
    return (
        f"D:{dt.strftime('%Y%m%d%H%M%S')}+00'00'"
    )


def _node_iso_timestamp(dt: datetime) -> str:
    """Format timestamps like JavaScript Date.toISOString()."""
    dt = dt.astimezone(timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:23] + "Z"


def _cert_serial_from_pem(cert_pem: str, cx509, backend) -> str:
    """Extract the serial number (hex) from a PEM certificate."""
    try:
        cert = cx509.load_pem_x509_certificate(
            cert_pem.encode() if isinstance(cert_pem, str) else cert_pem,
            backend(),
        )
        return format(cert.serial_number, "X").upper()
    except Exception:
        return ""


def _patch_byte_range(
    pdf_bytes: bytearray,
    pdf_latin: str,
    placeholder_idx: int,
    br0: int,
    br1: int,
    br2: int,
    br3: int,
) -> None:
    """Patch /ByteRange values in the PDF buffer in-place."""
    search_start = max(0, placeholder_idx - 500)
    search_region = pdf_latin[search_start:placeholder_idx]
    br_rel_idx = search_region.rfind("/ByteRange")
    if br_rel_idx == -1:
        return

    abs_idx = search_start + br_rel_idx
    close_bracket = pdf_latin.find("]", abs_idx)
    if close_bracket == -1:
        return

    old_br_len = close_bracket + 1 - abs_idx
    new_br_value = f"/ByteRange [{br0} {br1} {br2} {br3}]"
    new_br = new_br_value.ljust(old_br_len)
    patch = new_br.encode("latin-1")
    pdf_bytes[abs_idx: abs_idx + old_br_len] = patch


# ── PKCS#7 builder ────────────────────────────────────────────────────────────
# Builds a minimal CMS SignedData structure without requiring the private key.
# The HSM already produced the raw RSA signature; we wrap it in PKCS#7.


def _build_pkcs7_hex(
    raw_sig_b64: str,
    cert_pem: str,
    chain_pem: str,
    sign_date: datetime,
    signer_email: str,
    reason: str,
    location: str,
    cert_serial: str,
    timestamp_token_der: bytes,
    cx509,
    backend,
) -> str:
    """Build a PKCS#7 SignedData and return it as a hex string."""
    import base64

    if not raw_sig_b64:
        return ""

    raw_sig = base64.b64decode(raw_sig_b64)

    # Parse certificates
    certs_der = []
    if cert_pem:
        try:
            cert_obj = cx509.load_pem_x509_certificate(
                cert_pem.encode() if isinstance(cert_pem, str) else cert_pem,
                backend(),
            )
            certs_der.append(cert_obj.public_bytes(
                __import__("cryptography").hazmat.primitives.serialization.Encoding.DER
            ))
        except Exception:
            pass

    if chain_pem:
        import re as _re
        blocks = _re.findall(
            r"-----BEGIN CERTIFICATE-----[\s\S]*?-----END CERTIFICATE-----",
            chain_pem,
        )
        for block in blocks:
            try:
                c = cx509.load_pem_x509_certificate(
                    block.encode(), backend()
                )
                certs_der.append(c.public_bytes(
                    __import__("cryptography").hazmat.primitives.serialization.Encoding.DER
                ))
            except Exception:
                pass

    # Build the PKCS#7 DER manually using ASN.1 primitives
    try:
        from asn1crypto import cms, core, algos, x509 as asn1x509, pem as asn1pem
        return _build_pkcs7_asn1crypto(
            raw_sig, certs_der, sign_date, cert_serial, timestamp_token_der
        )
    except ImportError:
        # Fallback: build minimal DER without asn1crypto
        return _build_pkcs7_minimal_der(raw_sig, certs_der).hex()


def _build_pkcs7_asn1crypto(
    raw_sig: bytes,
    certs_der: list,
    sign_date: datetime,
    cert_serial: str,
    timestamp_token_der: bytes,
) -> str:
    """Build PKCS#7 using asn1crypto (recommended path)."""
    from asn1crypto import cms, core, algos, x509 as asn1x509

    # Build CertificateSet
    cert_list = []
    signer_cert = None
    for der in certs_der:
        cert_obj = asn1x509.Certificate.load(der)
        cert_list.append(cms.CertificateChoices(
            name="certificate", value=cert_obj
        ))
        if signer_cert is None:
            signer_cert = cert_obj

    # Build SignerInfo
    signer_infos = []
    if signer_cert is not None:
        issuer = signer_cert["tbs_certificate"]["issuer"]
        serial = signer_cert["tbs_certificate"]["serial_number"]

        issuer_serial = cms.IssuerAndSerialNumber({
            "issuer": issuer,
            "serial_number": serial,
        })

        sig_alg = cms.SignedDigestAlgorithm({
            "algorithm": "rsassa_pkcs1v15",
        })

        digest_alg = algos.DigestAlgorithm({"algorithm": "sha256"})

        signer_info_map = {
            "version": "v1",
            "sid": cms.SignerIdentifier(name="issuer_and_serial_number",
                                        value=issuer_serial),
            "digest_algorithm": digest_alg,
            "signature_algorithm": sig_alg,
            "signature": core.OctetString(raw_sig),
        }

        # Add unauthenticated attribute for TSA timestamp (PAdES B-T)
        if timestamp_token_der:
            tst_token = cms.ContentInfo.load(timestamp_token_der)
            unauth_attrs = cms.CMSAttributes([
                cms.CMSAttribute({
                    "type": cms.CMSAttributeType("1.2.840.113549.1.9.16.2.14"),
                    "values": cms.SetOfAny([tst_token]),
                })
            ])
            signer_info_map["unsigned_attrs"] = unauth_attrs

        signer_infos.append(cms.SignerInfo(signer_info_map))

    # asn1crypto changed the expected type for SignedData.encap_content_info
    # across releases. Prefer the installed library's accepted type.
    encap_content_info_value = {"content_type": "data"}
    try:
        encap_content_info = cms.ContentInfo(encap_content_info_value)
    except Exception:
        encap_content_info = cms.EncapsulatedContentInfo(encap_content_info_value)

    # Build SignedData
    signed_data = cms.SignedData({
        "version": "v1",
        "digest_algorithms": cms.DigestAlgorithms([
            algos.DigestAlgorithm({"algorithm": "sha256"})
        ]),
        "encap_content_info": encap_content_info,
        "certificates": cms.CertificateSet(cert_list) if cert_list else None,
        "signer_infos": cms.SignerInfos(signer_infos),
    })

    content_info = cms.ContentInfo({
        "content_type": "signed_data",
        "content": signed_data,
    })

    return content_info.dump().hex()


def _build_pkcs7_minimal_der(raw_sig: bytes, certs_der: list) -> bytes:
    """Build a minimal PKCS#7 SignedData DER without external libraries.

    This is the fallback path when asn1crypto is not installed.
    Produces a valid but minimal CMS structure.
    """
    def _asn1_len(content_len: int) -> bytes:
        if content_len < 0x80:
            return bytes([content_len])
        elif content_len < 0x100:
            return bytes([0x81, content_len])
        elif content_len < 0x10000:
            return bytes([0x82, content_len >> 8, content_len & 0xFF])
        else:
            return bytes([0x83,
                          (content_len >> 16) & 0xFF,
                          (content_len >> 8) & 0xFF,
                          content_len & 0xFF])

    def _tlv(tag: int, value: bytes) -> bytes:
        return bytes([tag]) + _asn1_len(len(value)) + value

    def _seq(value: bytes) -> bytes:
        return _tlv(0x30, value)

    def _set(value: bytes) -> bytes:
        return _tlv(0x31, value)

    def _oid(oid_str: str) -> bytes:
        parts = [int(p) for p in oid_str.split(".")]
        first = parts[0] * 40 + parts[1]
        encoded = [first]
        for part in parts[2:]:
            if part == 0:
                encoded.append(0)
            else:
                buf = []
                while part > 0:
                    buf.append(part & 0x7F)
                    part >>= 7
                buf.reverse()
                for i, b in enumerate(buf):
                    encoded.append(b | (0x80 if i < len(buf) - 1 else 0))
        return _tlv(0x06, bytes(encoded))

    def _int(value: int) -> bytes:
        n = value
        result = []
        while n:
            result.append(n & 0xFF)
            n >>= 8
        if not result:
            result = [0]
        result.reverse()
        if result[0] & 0x80:
            result.insert(0, 0)
        return _tlv(0x02, bytes(result))

    # OIDs
    oid_signed_data = _oid("1.2.840.113549.1.7.2")
    oid_data = _oid("1.2.840.113549.1.7.1")
    oid_sha256 = _oid("2.16.840.1.101.3.4.2.1")
    oid_rsa = _oid("1.2.840.113549.1.1.1")

    null_val = _tlv(0x05, b"")  # NULL

    # digestAlgorithms SET
    digest_algs = _set(_seq(oid_sha256 + null_val))

    # contentInfo (empty detached)
    content_info_inner = _seq(oid_data)

    # certificates [0] IMPLICIT
    certs_content = b"".join(certs_der)
    certs_block = _tlv(0xA0, certs_content) if certs_content else b""

    # SignerInfos SET (empty if no cert — minimal valid structure)
    signer_info_content = b""
    if certs_der:
        # version = 1
        si_version = _int(1)
        # issuerAndSerialNumber — minimal placeholder
        ias = _seq(b"\x30\x00" + b"\x02\x01\x01")  # empty issuer + serial 1
        # digestAlgorithm
        da = _seq(oid_sha256 + null_val)
        # signatureAlgorithm
        sa = _seq(oid_rsa + null_val)
        # signature OCTET STRING
        sig_val = _tlv(0x04, raw_sig)
        signer_info = _seq(si_version + ias + da + sa + sig_val)
        signer_info_content = signer_info

    signer_infos = _set(signer_info_content)

    # version = 1
    sd_version = _int(1)

    signed_data_content = sd_version + digest_algs + content_info_inner + certs_block + signer_infos
    signed_data = _seq(signed_data_content)

    # Wrap in ContentInfo
    content_info_outer = _seq(
        oid_signed_data + _tlv(0xA0, signed_data)
    )

    return content_info_outer


# ── TSA timestamp ─────────────────────────────────────────────────────────────


def _fetch_timestamp(tsa_url: str, sig_hash_hex: str) -> bytes:
    """Fetch an RFC 3161 timestamp token from the TSA Service."""
    import urllib.request
    import urllib.error

    url = f"{tsa_url.rstrip('/')}/v1/tsa/json"
    body = _json.dumps({
        "hash": sig_hash_hex,
        "hashAlgorithm": "sha-256",
        "mode": "classical",
        "certReq": True,
    }).encode()

    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/json",
            "Content-Length": str(len(body)),
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            tsa_resp = _json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"TSA request failed: HTTP {e.code}") from e
    except Exception as e:
        raise RuntimeError(f"TSA request failed: {e}") from e

    if not tsa_resp.get("success") or not tsa_resp.get("token"):
        raise RuntimeError(
            f"TSA timestamp request failed: {tsa_resp.get('error', 'no token returned')}"
        )

    import base64
    resp_der = base64.b64decode(tsa_resp["token"])
    # TSAResp[1] = TimeStampToken = ContentInfo
    # Parse to extract the TimeStampToken
    # Simple DER traversal: SEQUENCE { PKIStatusInfo, ContentInfo }
    idx = 0
    # Skip outer SEQUENCE tag + length
    if resp_der[0] != 0x30:
        return resp_der
    idx += 1
    # Skip length
    if resp_der[idx] & 0x80:
        num_bytes = resp_der[idx] & 0x7F
        idx += num_bytes + 1
    else:
        idx += 1
    # Skip PKIStatusInfo (first SEQUENCE)
    if resp_der[idx] != 0x30:
        return resp_der
    idx += 1
    pkg_len = resp_der[idx]
    if pkg_len & 0x80:
        num_bytes = pkg_len & 0x7F
        pkg_len = int.from_bytes(resp_der[idx + 1: idx + 1 + num_bytes], "big")
        idx += num_bytes + 1
    else:
        idx += 1
    idx += pkg_len  # skip PKIStatusInfo body
    # Remaining bytes are the TimeStampToken ContentInfo
    return resp_der[idx:]


# ── XML helpers ───────────────────────────────────────────────────────────────


def _xml_escape(s: str) -> str:
    return (
        str(s)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )
