"""CertySign SDK — local document hashing.

Hashes documents on the subscriber's system so the raw document
NEVER leaves their infrastructure. Only the hash is sent to CertySign.

Supports: SHA-256, SHA-384, SHA-512
"""

import hashlib
import os
from pathlib import Path
from typing import Union

SUPPORTED_ALGORITHMS = ("sha256", "sha384", "sha512")


class DocumentHasher:
    """Hash documents locally before sending the hash to CertySign."""

    def __init__(self, algorithm: str = "sha256"):
        """Initialise the hasher.

        Args:
            algorithm: Default hash algorithm — sha256 | sha384 | sha512.

        Raises:
            ValueError: If the algorithm is not supported.
        """
        algo = algorithm.lower()
        if algo not in SUPPORTED_ALGORITHMS:
            raise ValueError(
                f"Unsupported algorithm: {algorithm}. "
                f"Use: {', '.join(SUPPORTED_ALGORITHMS)}"
            )
        self.algorithm = algo

    # ── Hash from bytes ────────────────────────────────────────────────────

    def hash(
        self,
        data: Union[bytes, str],
        algorithm: str = None,
    ) -> dict:
        """Hash a document from bytes or a string.

        Args:
            data: Document contents as bytes or str.
            algorithm: Override the default algorithm.

        Returns:
            Dict with keys 'hash' (hex), 'algorithm', 'size' (bytes).

        Example::

            hasher = DocumentHasher()
            result = hasher.hash(open("contract.pdf", "rb").read())
            print(result["hash"])  # "a1b2c3..."
        """
        algo = (algorithm or self.algorithm).lower()
        _check_algorithm(algo)

        if isinstance(data, str):
            data = data.encode()

        digest = hashlib.new(algo, data).hexdigest()
        return {"hash": digest, "algorithm": algo, "size": len(data)}

    # ── Hash from file path ────────────────────────────────────────────────

    def hash_file(self, file_path: Union[str, Path], algorithm: str = None) -> dict:
        """Hash a document from a file path (streaming — memory-efficient).

        Args:
            file_path: Path to the file.
            algorithm: Override the default algorithm.

        Returns:
            Dict with 'hash', 'algorithm', 'size', 'file_name'.

        Example::

            hasher = DocumentHasher()
            result = hasher.hash_file("./contract.pdf")
            print(result["hash"])
            print(result["file_name"])  # "contract.pdf"
        """
        algo = (algorithm or self.algorithm).lower()
        _check_algorithm(algo)

        file_path = Path(file_path)
        h = hashlib.new(algo)
        size = 0
        chunk_size = 65536  # 64 KB

        with file_path.open("rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                h.update(chunk)
                size += len(chunk)

        return {
            "hash": h.hexdigest(),
            "algorithm": algo,
            "size": size,
            "file_name": file_path.name,
            "fileName": file_path.name,
        }

    # ── Hash many buffers ──────────────────────────────────────────────────

    def hash_many(self, documents: list, algorithm: str = None) -> list:
        """Hash multiple documents (bytes).

        Args:
            documents: List of dicts with 'data' (bytes) and 'file_name' (str).
            algorithm: Override the default algorithm.

        Returns:
            List of dicts with 'hash', 'algorithm', 'size', 'file_name'.
        """
        results = []
        for doc in documents:
            result = self.hash(doc["data"], algorithm)
            file_name = doc.get("file_name", doc.get("fileName", ""))
            result["file_name"] = file_name
            result["fileName"] = file_name
            results.append(result)
        return results

    # ── Hash many files ────────────────────────────────────────────────────

    def hash_files(self, file_paths: list, algorithm: str = None) -> list:
        """Hash multiple files by path.

        Args:
            file_paths: List of file paths (str or Path).
            algorithm: Override the default algorithm.

        Returns:
            List of dicts with 'hash', 'algorithm', 'size', 'file_name'.
        """
        return [self.hash_file(fp, algorithm) for fp in file_paths]

    def hashFile(self, file_path: Union[str, Path], algorithm: str = None) -> dict:
        """Node-style alias for :meth:`hash_file`."""
        return self.hash_file(file_path, algorithm)

    def hashMany(self, documents: list, algorithm: str = None) -> list:
        """Node-style alias for :meth:`hash_many`."""
        return self.hash_many(documents, algorithm)

    def hashFiles(self, file_paths: list, algorithm: str = None) -> list:
        """Node-style alias for :meth:`hash_files`."""
        return self.hash_files(file_paths, algorithm)


# ── Helpers ──────────────────────────────────────────────────────────────────


def _check_algorithm(algo: str) -> None:
    if algo not in SUPPORTED_ALGORITHMS:
        raise ValueError(
            f"Unsupported algorithm: {algo}. "
            f"Use: {', '.join(SUPPORTED_ALGORITHMS)}"
        )
