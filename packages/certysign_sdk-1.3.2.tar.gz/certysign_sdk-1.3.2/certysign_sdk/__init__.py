"""CertySign SDK for Python.

Drop-in Python equivalent of the @certysign/sdk Node.js package.

Quick start::

    from certysign_sdk import CertySignClient

    client = CertySignClient(
        public_key="your-api-key-id",
        secret_key="your-api-key-secret",
    )

    # Hash-based signing (recommended — document never leaves your system)
    with open("/path/to/document.pdf", "rb") as f:
        pdf_bytes = f.read()

    result = client.sign.hash_and_sign(
        document=pdf_bytes,
        file_name="document.pdf",
    )

    # Embed the signature back into the document locally
    signed_pdf = client.embedder.embed_in_pdf(
        pdf_bytes,
        sign_callback=lambda h: client.sign.sign_hash(
            document_hash=h,
            hash_algorithm="sha256",
        ),
    )

    with open("/path/to/signed-document.pdf", "wb") as f:
        f.write(signed_pdf)
"""

from __future__ import annotations

from .http_client import HttpClient
from .exceptions import CertySignError
from .resources import (
    HashSigningResource,
    SigningResource,
    CertificateResource,
    PkiResource,
    EnvelopeResource,
    SigningSessionResource,
    DashboardResource,
)
from .utils import DocumentHasher, SignatureEmbedder

__all__ = [
    "CertySignClient",
    "CertySignError",
    "DocumentHasher",
    "SignatureEmbedder",
]

__version__ = "1.3.2"

_BASE_URLS = {
    "production": "https://core.certysign.io",
    "staging": "https://service.certysign.io",
    "development": "http://localhost:8000",
    "test": "http://localhost:8000",
}

_TSA_URLS = {
    "production": "https://tsa.certysign.io",
    "staging": "https://tsa-staging.certysign.io",
    "development": "http://localhost:5015",
    "test": "http://localhost:5015",
}


class CertySignClient:
    """The main entry point for the CertySign SDK.

    Instantiate once and reuse across your application.

    Args:
        public_key: Your API key ID (``X-API-Key-Id`` header value).
        secret_key: Your API key secret (``X-API-Key-Secret`` header value).
        environment: ``'production'`` | ``'staging'`` | ``'development'`` | ``'test'``.
                     Ignored when *base_url* is given. Default: ``'production'``.
        base_url: Override the computed base URL completely.
        timeout: HTTP request timeout in seconds. Default: 30.
        retries: Maximum retry count for transient failures. Default: 3.
        debug: Enable verbose request logging to stdout. Default: False.
        tsa_url: Base URL of the TSA service for PAdES-T timestamps.
                 When set, :attr:`embedder` will upgrade PDF signatures from
                 PAdES Baseline B-B to B-T automatically.

    Example::

        client = CertySignClient(
            public_key=os.getenv("CERTYSIGN_KEY_ID"),
            secret_key=os.getenv("CERTYSIGN_KEY_SECRET"),
            environment="staging",
            tsa_url="https://tsa.certysign.io",
        )
    """

    def __init__(
        self,
        *,
        public_key: str,
        secret_key: str,
        environment: str = "production",
        base_url: str = None,
        timeout: int = 30,
        retries: int = 3,
        debug: bool = False,
        tsa_url: str = None,
    ):
        if base_url:
            resolved_url = base_url
        else:
            resolved_url = _BASE_URLS.get(environment)
            if resolved_url is None:
                known = ", ".join(sorted(_BASE_URLS))
                raise ValueError(
                    f"CertySignClient: unknown environment {environment!r}. "
                    f"Expected one of: {known}, or provide base_url."
                )

        self._http = HttpClient(
            public_key=public_key,
            secret_key=secret_key,
            base_url=resolved_url,
            timeout=timeout,
            retries=retries,
            debug=debug,
        )

        # Resources
        self._sign = HashSigningResource(self._http)
        self._legacy_sign = SigningResource(self._http)
        self._certificates = CertificateResource(self._http)
        self._pki = PkiResource(self._http)
        self._envelopes = EnvelopeResource(self._http)
        self._sessions = SigningSessionResource(self._http)
        self._dashboard = DashboardResource(self._http)

        # Local utilities (no network required)
        self._hasher = DocumentHasher()
        resolved_tsa_url = tsa_url if tsa_url is not None else _TSA_URLS.get(environment)
        self._embedder = SignatureEmbedder(tsa_url=resolved_tsa_url)
        self.public_key = public_key
        self.environment = environment
        self.base_url = resolved_url
        self.tsa_url = resolved_tsa_url

    # ── Properties ────────────────────────────────────────────────────────

    @property
    def sign(self) -> HashSigningResource:
        """Hash-based signing operations (recommended)."""
        return self._sign

    @property
    def legacy_sign(self) -> SigningResource:
        """Legacy document-upload signing operations."""
        return self._legacy_sign

    @property
    def legacySign(self) -> SigningResource:
        """Node-style alias for :attr:`legacy_sign`."""
        return self._legacy_sign

    @property
    def certificates(self) -> CertificateResource:
        """Certificate lifecycle management."""
        return self._certificates

    @property
    def pki(self) -> PkiResource:
        """PKI infrastructure (CRL, OCSP, chain)."""
        return self._pki

    @property
    def envelopes(self) -> EnvelopeResource:
        """Signature envelope management."""
        return self._envelopes

    @property
    def sessions(self) -> SigningSessionResource:
        """Signing session management (OTP, multi-recipient)."""
        return self._sessions

    @property
    def dashboard(self) -> DashboardResource:
        """Dashboard analytics and reporting."""
        return self._dashboard

    @property
    def hasher(self) -> DocumentHasher:
        """Local document hashing (no network)."""
        return self._hasher

    @property
    def embedder(self) -> SignatureEmbedder:
        """Local signature embedding (no network)."""
        return self._embedder

    def ping(self) -> dict:
        """Check whether the configured API key can reach the PKI info endpoint."""
        try:
            result = self._http.get("/sdk/v1/pki/info")
            data = result.get("data", {}) if isinstance(result, dict) else {}
            status = data.get("status", {}) if isinstance(data, dict) else {}
            return {
                "success": True,
                "data": {
                    "keyName": data.get("keyName"),
                    "permissions": data.get("permissions"),
                    "environment": data.get("environment", self.environment),
                    "tenantId": data.get("tenantId"),
                    "caInitialized": status.get("initialized"),
                },
            }
        except Exception as err:
            return {
                "success": False,
                "error": str(err),
                "code": getattr(err, "code", None),
            }

    def __repr__(self) -> str:
        return (
            f"CertySignClient(base_url={self._http.base_url!r})"
        )
