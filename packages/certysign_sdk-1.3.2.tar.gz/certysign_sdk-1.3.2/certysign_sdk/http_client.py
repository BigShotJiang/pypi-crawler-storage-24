"""CertySign SDK — HTTP client layer.

Wraps requests with:
  - Automatic API key header injection
  - Idempotency key support
  - Retry with exponential back-off (network errors, 429, 502, 503, 504)
  - Consistent error normalisation
"""

import secrets
import time
import platform
from typing import Any, Dict, Optional

import requests

from .exceptions import CertySignError

DEFAULT_BASE_URL = "https://core.certysign.io"
RETRYABLE_STATUS = {429, 502, 503, 504}
SDK_VERSION = "1.3.2"
PYTHON_VERSION = platform.python_version()


class HttpClient:
    """Low-level HTTP client for the CertySign API."""

    def __init__(
        self,
        *,
        public_key: str,
        secret_key: str,
        base_url: str = None,
        timeout: int = 30,
        retries: int = 3,
        debug: bool = False,
    ):
        if not public_key:
            raise ValueError("CertySign SDK: public_key is required")
        if not secret_key:
            raise ValueError("CertySign SDK: secret_key is required")

        self.public_key = public_key
        self.secret_key = secret_key
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self.retries = retries
        self.debug = debug

        self._session = requests.Session()
        self._session.headers.update(
            {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": (
                    f"CertySign-SDK-Python/{SDK_VERSION} "
                    f"Python/{PYTHON_VERSION}"
                ),
            }
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        data: Any = None,
        params: Dict = None,
        headers: Dict = None,
        files: Dict = None,
        idempotency_key: str = None,
        accept: str = None,
        raw_response: bool = False,
    ) -> Any:
        """Execute an HTTP request with retry logic.

        Args:
            method: HTTP verb (GET, POST, PUT, DELETE, PATCH).
            path: Path relative to base_url.
            data: JSON-serialisable body.
            params: Query parameters.
            headers: Extra headers.
            files: Multipart files dict (requests format).
            idempotency_key: Idempotency key (auto-generated if omitted).
            accept: Override Accept header.
            raw_response: If True, return raw bytes instead of parsed body.

        Returns:
            Parsed JSON, text, or raw bytes depending on Content-Type.

        Raises:
            CertySignError: On any API or network error.
        """
        idempotency_key = idempotency_key or secrets.token_hex(16)

        req_headers = {
            "X-API-Key-Id": self.public_key,
            "X-API-Key-Secret": self.secret_key,
            "X-Idempotency-Key": idempotency_key,
        }
        if accept:
            req_headers["Accept"] = accept
        if headers:
            req_headers.update(headers)

        url = f"{self.base_url}{path}"
        attempt = 0

        while True:
            attempt += 1
            if self.debug:
                print(
                    f"[CertySign SDK] {method.upper()} {path} (attempt {attempt})"
                )

            try:
                if files:
                    # Remove Content-Type for multipart — requests sets boundary automatically
                    mpart_headers = {
                        k: v
                        for k, v in req_headers.items()
                        if k != "Content-Type"
                    }
                    resp = self._session.request(
                        method,
                        url,
                        headers=mpart_headers,
                        files=files,
                        params=params,
                        timeout=self.timeout,
                    )
                elif data is not None:
                    resp = self._session.request(
                        method,
                        url,
                        headers=req_headers,
                        json=data,
                        params=params,
                        timeout=self.timeout,
                    )
                else:
                    resp = self._session.request(
                        method,
                        url,
                        headers=req_headers,
                        params=params,
                        timeout=self.timeout,
                    )

                if resp.status_code in RETRYABLE_STATUS and attempt <= self.retries:
                    delay = min(0.2 * (2 ** (attempt - 1)), 4.0)
                    if self.debug:
                        print(
                            f"[CertySign SDK] Retrying in {delay}s "
                            f"(status={resp.status_code})"
                        )
                    time.sleep(delay)
                    continue

                resp.raise_for_status()

                if raw_response:
                    return resp.content

                content_type = resp.headers.get("Content-Type", "")
                if "application/json" in content_type:
                    return resp.json()
                elif (
                    "text/" in content_type
                    or "application/x-pem-file" in content_type
                ):
                    return resp.text
                else:
                    return resp.content

            except requests.exceptions.HTTPError as exc:
                raise _normalise_error(exc) from exc
            except requests.exceptions.ConnectionError as exc:
                if attempt <= self.retries:
                    delay = min(0.2 * (2 ** (attempt - 1)), 4.0)
                    time.sleep(delay)
                    continue
                raise CertySignError(
                    f"Connection error: {exc}", 0, "NETWORK_ERROR"
                ) from exc
            except requests.exceptions.Timeout as exc:
                if attempt <= self.retries:
                    delay = min(0.2 * (2 ** (attempt - 1)), 4.0)
                    time.sleep(delay)
                    continue
                raise CertySignError(
                    f"Request timed out: {exc}", 0, "TIMEOUT"
                ) from exc

    # ── Convenience methods ────────────────────────────────────────────────

    def get(self, path: str, **kwargs) -> Any:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs) -> Any:
        return self.request("POST", path, **kwargs)

    def put(self, path: str, **kwargs) -> Any:
        return self.request("PUT", path, **kwargs)

    def patch(self, path: str, **kwargs) -> Any:
        return self.request("PATCH", path, **kwargs)

    def delete(self, path: str, **kwargs) -> Any:
        return self.request("DELETE", path, **kwargs)


# ── Helpers ──────────────────────────────────────────────────────────────────


def _normalise_error(err: requests.exceptions.HTTPError) -> CertySignError:
    """Normalise a requests HTTPError into a CertySignError."""
    resp = err.response
    if resp is not None:
        try:
            body = resp.json()
        except Exception:
            body = {"message": resp.text}
        message = body.get("message", f"HTTP {resp.status_code}")
        e = CertySignError(message, resp.status_code, body.get("code"))
        e.details = body
        e.headers = dict(resp.headers)
        return e
    return CertySignError(str(err), 0, "SDK_INTERNAL_ERROR")
