"""CertySign SDK — exception classes."""


class CertySignError(Exception):
    """Raised by all CertySign SDK methods on failure.

    Attributes:
        status_code: HTTP status code (0 for network errors).
        code: Machine-readable error code (e.g. 'INVALID_API_KEY').
        details: Full error body from the API.
        headers: Response headers (if available).
    """

    def __init__(self, message: str, status_code: int = 0, code: str = None):
        super().__init__(message)
        self.name = "CertySignError"
        self.status_code = status_code
        self.code = code
        self.details = None
        self.headers = None

    def __repr__(self):
        return (
            f"CertySignError(message={str(self)!r}, "
            f"status_code={self.status_code}, code={self.code!r})"
        )
