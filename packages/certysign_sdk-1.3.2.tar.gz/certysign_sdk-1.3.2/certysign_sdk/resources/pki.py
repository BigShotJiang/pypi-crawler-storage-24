"""CertySign SDK — PKI infrastructure endpoints.

Covers:
  - crl()   GET /sdk/v1/pki/crl      — X.509 v2 CRL (RFC 5280)
  - ocsp()  GET /sdk/v1/pki/ocsp/:sn — OCSP response (RFC 6960)
  - chain() GET /sdk/v1/pki/chain    — CA certificate chain (PEM bundle)
  - info()  GET /sdk/v1/pki/info     — CA hierarchy metadata
"""

from urllib.parse import quote


class PkiResource:
    """PKI infrastructure — CRL, OCSP, CA chain."""

    def __init__(self, http):
        self._http = http

    # ── CRL ────────────────────────────────────────────────────────────────

    def crl(self, format: str = "pem"):
        """Download the current Certificate Revocation List.

        Args:
            format: 'der' | 'pem' | 'json' (default: 'pem').
                    - 'der'  → bytes containing DER-encoded CRL
                    - 'pem'  → string with PEM-encoded CRL
                    - 'json' → dict with structured revocation list

        Returns:
            Bytes (der), string (pem), or dict (json).

        Example::

            # Download DER CRL and write to disk
            der_buf = client.pki.crl("der")
            open("/etc/pki/certysign-intermediate.crl", "wb").write(der_buf)

            # Get JSON for application-level revocation checks
            result = client.pki.crl("json")
            revoked = {e["serialNumber"] for e in result["data"]["crl"]}
        """
        if format == "der":
            return self._http.get(
                "/sdk/v1/pki/crl",
                accept="application/pkix-crl",
                raw_response=True,
            )
        if format == "pem":
            return self._http.get(
                "/sdk/v1/pki/crl",
                accept="application/x-pem-file",
            )
        # JSON
        return self._http.get("/sdk/v1/pki/crl")

    # ── OCSP ───────────────────────────────────────────────────────────────

    def ocsp(self, serial_number: str, format: str = "json"):
        """Query the OCSP responder for a specific certificate.

        Returns an RFC 6960 BasicOCSPResponse signed by CertySign Intermediate CA.

        Args:
            serial_number: Certificate serial number (hex string).
            format: 'der' | 'json' (default: 'json').

        Returns:
            Bytes (der) or dict (json).

        Example::

            result = client.pki.ocsp("A1B2C3D4E5F6...")
            print(result["data"]["status"])    # 'good', 'revoked', or 'unknown'
            print(result["data"]["nextUpdate"]) # ISO 8601 — cache until this time
        """
        if not serial_number:
            raise ValueError("pki.ocsp: serial_number is required")

        path = f"/sdk/v1/pki/ocsp/{quote(serial_number, safe='')}"

        if format == "der":
            return self._http.get(
                path,
                accept="application/ocsp-response",
                raw_response=True,
            )
        return self._http.get(path)

    # ── CA Chain ───────────────────────────────────────────────────────────

    def chain(self) -> str:
        """Download the CertySign CA certificate chain as a PEM bundle.

        The bundle contains (in order):
          1. CertySign Intermediate CA certificate
          2. CertySign Root CA certificate

        Returns:
            PEM-encoded certificate chain string.

        Example::

            chain = client.pki.chain()
            open("/etc/ssl/certs/certysign-chain.pem", "w").write(chain)
        """
        return self._http.get(
            "/sdk/v1/pki/chain",
            accept="application/x-pem-file",
        )

    # ── CA Info ────────────────────────────────────────────────────────────

    def info(self) -> dict:
        """Get metadata about the CertySign CA hierarchy.

        Returns information about the Root CA and Intermediate CA including
        subject DN, validity period, key algorithm, CRL and OCSP URLs.

        Returns:
            API response with intermediateCA and rootCA details.

        Example::

            result = client.pki.info()
            print(result["data"]["intermediateCA"]["subject"]["commonName"])
            print(result["data"]["intermediateCA"]["crlUrl"])
        """
        return self._http.get("/sdk/v1/pki/info")
