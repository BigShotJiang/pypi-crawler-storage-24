"""CertySign SDK — full envelope lifecycle management.

Covers:
  - create()           POST /sdk/v1/envelopes
  - get()              GET  /sdk/v1/envelopes/:id
  - list()             GET  /sdk/v1/envelopes
  - upload_documents() POST /sdk/v1/envelopes/:id/documents
  - send()             POST /sdk/v1/envelopes/:id/send
  - sign()             POST /sdk/v1/envelopes/:id/sign
  - get_document()     GET  /sdk/v1/envelopes/:id/documents/:docId
  - get_audit_trail()  GET  /sdk/v1/envelopes/:id/audit
"""

from urllib.parse import quote


class EnvelopeResource:
    """Envelope lifecycle — create, upload, send, sign, retrieve."""

    def __init__(self, http):
        self._http = http

    # ── Create ─────────────────────────────────────────────────────────────

    def create(
        self,
        options: dict = None,
        *,
        title: str = None,
        signers: list = None,
        message: str = None,
        metadata: dict = None,
    ) -> dict:
        """Create a new signing envelope.

        Args:
            title: Envelope title (required).
            signers: List of signer dicts with 'name', optionally 'email', 'role'.
            message: Message to signers.
            metadata: Custom key/value metadata.

        Returns:
            API response with envelope object and _id.

        Example::

            result = client.envelopes.create(
                title="NHIF Reimbursement Claim Q1-2026",
                signers=[{
                    "name": "Dr. Grace Mwangi",
                    "email": "g.mwangi@nhif.or.ke",
                    "role": "primary",
                }],
            )
            envelope_id = result["data"]["envelope"]["_id"]
        """
        opts = _coerce_options(options)
        title = title or opts.get("title")
        signers = signers if signers is not None else opts.get("signers")
        message = message if message is not None else opts.get("message")
        metadata = metadata if metadata is not None else opts.get("metadata")

        if not title:
            raise ValueError("envelopes.create: title is required")

        body = {
            "title": title,
            "signers": signers or [],
            "metadata": metadata or {},
        }
        if message:
            body["message"] = message

        return self._http.post("/sdk/v1/envelopes", data=body)

    # ── Get ────────────────────────────────────────────────────────────────

    def get(self, envelope_id: str) -> dict:
        """Get a single envelope by ID with full status and document list.

        Args:
            envelope_id: Envelope ID.

        Returns:
            API response with envelope object.
        """
        if not envelope_id:
            raise ValueError("envelopes.get: envelope_id is required")
        return self._http.get(f"/sdk/v1/envelopes/{quote(envelope_id, safe='')}")

    # ── List ───────────────────────────────────────────────────────────────

    def list(
        self,
        options: dict = None,
        *,
        status: str = None,
        page: int = 1,
        limit: int = 20,
        search: str = None,
    ) -> dict:
        """List envelopes for the authenticated tenant.

        Args:
            status: Filter by status: 'draft' | 'sent' | 'in_progress' |
                    'completed' | 'cancelled'.
            page: Page number (default: 1).
            limit: Results per page (default: 20).
            search: Free-text search.

        Returns:
            API response with envelopes list and pagination.

        Example::

            result = client.envelopes.list(status="completed", limit=20)
            for env in result["data"]["envelopes"]:
                print(env["_id"], env["status"])
        """
        opts = _coerce_options(options)
        status = opts.get("status", status)
        page = opts.get("page", page)
        limit = opts.get("limit", limit)
        search = opts.get("search", search)

        params = {"page": page, "limit": limit}
        if status:
            params["status"] = status
        if search:
            params["search"] = search

        return self._http.get("/sdk/v1/envelopes", params=params)

    # ── Upload Documents ───────────────────────────────────────────────────

    def upload_documents(self, envelope_id: str, documents: list) -> dict:
        """Upload one or more PDF documents to an existing envelope.

        Must be called after create() and before send().

        Args:
            envelope_id: Target envelope ID.
            documents: List of dicts with 'data' (bytes or file-like) and
                       optionally 'filename' (str).

        Returns:
            API response confirming upload.

        Example::

            client.envelopes.upload_documents("env_abc123", [
                {"data": open("report.pdf", "rb").read(), "filename": "Q1-report.pdf"},
            ])
        """
        if not envelope_id:
            raise ValueError("envelopes.upload_documents: envelope_id is required")
        if not documents:
            raise ValueError("envelopes.upload_documents: documents list is required")

        files = []
        for doc in documents:
            buf = doc["data"]
            fname = doc.get("filename") or doc.get("name", "document.pdf")
            if isinstance(buf, (bytes, bytearray)):
                files.append(("documents", (fname, buf, "application/pdf")))
            elif hasattr(buf, "read"):
                files.append(("documents", (fname, buf, "application/pdf")))
            else:
                raise TypeError(
                    f'Document "{fname}" must be bytes or a file-like object'
                )

        return self._http.post(
            f"/sdk/v1/envelopes/{quote(envelope_id, safe='')}/documents",
            files=files,
        )

    def uploadDocuments(self, envelope_id: str, documents: list) -> dict:
        """Node-style alias for :meth:`upload_documents`."""
        return self.upload_documents(envelope_id, documents)

    # ── Send ───────────────────────────────────────────────────────────────

    def send(self, envelope_id: str) -> dict:
        """Transition an envelope to 'sent' status, ready for signing.

        Args:
            envelope_id: Envelope ID.

        Returns:
            API response with updated envelope.
        """
        if not envelope_id:
            raise ValueError("envelopes.send: envelope_id is required")
        return self._http.post(
            f"/sdk/v1/envelopes/{quote(envelope_id, safe='')}/send"
        )

    # ── Sign ───────────────────────────────────────────────────────────────

    def sign(
        self,
        envelope_id: str,
        options: dict = None,
        *,
        reason: str = "Digital signature",
        location: str = "Nairobi, Kenya",
    ) -> dict:
        """Apply a cryptographic signature to all documents in the envelope.

        For SDK requests, interactive 2FA is bypassed — the API key alone
        authorises the signature.

        Args:
            envelope_id: Envelope ID.
            reason: Signing reason.
            location: Physical signing location.

        Returns:
            API response with signatures and certificate details.

        Example::

            result = client.envelopes.sign(
                "env_abc123",
                reason="Claims approval — NHIF Kenya",
                location="Nairobi, Kenya",
            )
            print(result["data"]["signatures"][0]["certificate"]["serialNumber"])
        """
        opts = _coerce_options(options)
        reason = opts.get("reason", reason)
        location = opts.get("location", location)

        if not envelope_id:
            raise ValueError("envelopes.sign: envelope_id is required")
        return self._http.post(
            f"/sdk/v1/envelopes/{quote(envelope_id, safe='')}/sign",
            data={"reason": reason, "location": location},
        )

    # ── Download Document ──────────────────────────────────────────────────

    def get_document(self, envelope_id: str, document_id: str) -> bytes:
        """Download a signed document as bytes.

        Args:
            envelope_id: Envelope ID.
            document_id: Document ID within the envelope.

        Returns:
            Raw PDF bytes.

        Example::

            pdf_bytes = client.envelopes.get_document("env_abc123", "doc_xyz789")
            open("./signed-claim.pdf", "wb").write(pdf_bytes)
        """
        if not envelope_id:
            raise ValueError("envelopes.get_document: envelope_id is required")
        if not document_id:
            raise ValueError("envelopes.get_document: document_id is required")

        return self._http.get(
            f"/sdk/v1/envelopes/{quote(envelope_id, safe='')}"
            f"/documents/{quote(document_id, safe='')}",
            raw_response=True,
        )

    def getDocument(self, envelope_id: str, document_id: str) -> bytes:
        """Node-style alias for :meth:`get_document`."""
        return self.get_document(envelope_id, document_id)

    # ── Audit Trail ────────────────────────────────────────────────────────

    def get_audit_trail(self, envelope_id: str) -> dict:
        """Retrieve the cryptographically verifiable audit trail.

        The audit chain is a Merkle-linked log of all envelope events
        (created, document_uploaded, sent, signed, completed).

        Args:
            envelope_id: Envelope ID.

        Returns:
            API response with auditTrail list and chainIntegrity status.

        Example::

            result = client.envelopes.get_audit_trail("env_abc123")
            for event in result["data"]["auditTrail"]:
                print(event["timestamp"], event["action"], event["eventHash"])
            if result["data"]["chainIntegrity"]["valid"]:
                print("Audit chain intact")
        """
        if not envelope_id:
            raise ValueError("envelopes.get_audit_trail: envelope_id is required")
        return self._http.get(
            f"/sdk/v1/envelopes/{quote(envelope_id, safe='')}/audit"
        )

    def getAuditTrail(self, envelope_id: str) -> dict:
        """Node-style alias for :meth:`get_audit_trail`."""
        return self.get_audit_trail(envelope_id)


def _coerce_options(options: dict) -> dict:
    if options is None:
        return {}
    if not isinstance(options, dict):
        raise TypeError("options must be a dict")
    return dict(options)
