"""CertySign SDK — hash-based document signing.

Documents NEVER leave the subscriber's system.
Flow: hash locally → send hash to CertySign → receive signature → embed locally.

Covers:
  - hash_and_sign()        Hash a document and sign in one call
  - sign_hash()            Sign a pre-computed hash
  - batch_hash_and_sign()  Hash and sign multiple documents
  - batch_sign_hashes()    Sign multiple pre-computed hashes
  - verify_by_id()         Verify an envelope's signatures
"""

from ..utils.hasher import DocumentHasher


class HashSigningResource:
    """Hash-based signing — documents never leave your system."""

    def __init__(self, http):
        self._http = http
        self._hasher = DocumentHasher()

    # ── Hash + Sign (single document) ─────────────────────────────────────

    def hash_and_sign(
        self,
        *,
        document: bytes,
        file_name: str = "document.pdf",
        reason: str = "Digital signature",
        location: str = "Nairobi, Kenya",
        hash_algorithm: str = "sha256",
        signer_name: str = None,
        signer_email: str = None,
        metadata: dict = None,
    ) -> dict:
        """Hash a document locally and send the hash to CertySign for signing.

        The document never leaves your system.

        Args:
            document: Document contents as bytes.
            file_name: File name for reference.
            reason: Signing reason.
            location: Physical signing location.
            hash_algorithm: sha256 | sha384 | sha512.
            signer_name: Full name of the signer.
            signer_email: Email address of the signer.
            metadata: Custom key/value metadata.

        Returns:
            API response with signature, certificate, and documentHash.

        Example::

            result = client.sign.hash_and_sign(
                document=open("contract.pdf", "rb").read(),
                file_name="contract.pdf",
                reason="Contract approval",
            )
            print(result["data"]["signature"])   # Base64 CMS/PKCS#7
            print(result["data"]["certificate"]) # PEM certificate
        """
        if not document:
            raise ValueError("hash_and_sign: document (bytes) is required")

        result = self._hasher.hash(document, hash_algorithm)
        doc_hash = result["hash"]

        body = {
            "documentHash": doc_hash,
            "hashAlgorithm": hash_algorithm,
            "fileName": file_name,
            "reason": reason,
            "location": location,
            "metadata": metadata or {},
        }
        if signer_name:
            body["signerName"] = signer_name
        if signer_email:
            body["signerEmail"] = signer_email

        return self._http.post("/sdk/v1/sign/hash", data=body)

    def hashAndSign(self, options: dict = None, /, **kwargs) -> dict:
        """Node-style alias for :meth:`hash_and_sign`."""
        opts = _coerce_options(options, kwargs)
        return self.hash_and_sign(
            document=opts["document"],
            file_name=opts.get("file_name") or opts.get("fileName", "document.pdf"),
            reason=opts.get("reason", "Digital signature"),
            location=opts.get("location", "Nairobi, Kenya"),
            hash_algorithm=opts.get("hash_algorithm") or opts.get("hashAlgorithm") or "sha256",
            signer_name=opts.get("signer_name") or opts.get("signerName"),
            signer_email=opts.get("signer_email") or opts.get("signerEmail"),
            metadata=opts.get("metadata"),
        )

    # ── Sign pre-computed hash ─────────────────────────────────────────────

    def sign_hash(
        self,
        *,
        document_hash: str,
        hash_algorithm: str = "sha256",
        file_name: str = None,
        reason: str = "Digital signature",
        location: str = "Nairobi, Kenya",
        signer_name: str = None,
        signer_email: str = None,
        metadata: dict = None,
    ) -> dict:
        """Sign a pre-computed document hash.

        Use this when you have already computed the hash yourself.

        Args:
            document_hash: Hex-encoded hash string.
            hash_algorithm: sha256 | sha384 | sha512.
            file_name: File name for reference.
            reason: Signing reason.
            location: Physical signing location.
            signer_name: Full name of the signer.
            signer_email: Email address of the signer.
            metadata: Custom key/value metadata.

        Returns:
            API response with signature and certificate.

        Example::

            import hashlib
            h = hashlib.sha256(pdf_bytes).hexdigest()
            result = client.sign.sign_hash(
                document_hash=h,
                file_name="invoice.pdf",
                reason="Invoice approval",
            )
        """
        if not document_hash:
            raise ValueError("sign_hash: document_hash is required")

        body = {
            "documentHash": document_hash,
            "hashAlgorithm": hash_algorithm,
            "reason": reason,
            "location": location,
            "metadata": metadata or {},
        }
        if file_name:
            body["fileName"] = file_name
        if signer_name:
            body["signerName"] = signer_name
        if signer_email:
            body["signerEmail"] = signer_email

        return self._http.post("/sdk/v1/sign/hash", data=body)

    def signHash(self, options: dict = None, /, **kwargs) -> dict:
        """Node-style alias for :meth:`sign_hash`."""
        opts = _coerce_options(options, kwargs)
        return self.sign_hash(
            document_hash=opts.get("document_hash") or opts.get("documentHash"),
            hash_algorithm=opts.get("hash_algorithm") or opts.get("hashAlgorithm") or "sha256",
            file_name=opts.get("file_name") or opts.get("fileName"),
            reason=opts.get("reason", "Digital signature"),
            location=opts.get("location", "Nairobi, Kenya"),
            signer_name=opts.get("signer_name") or opts.get("signerName"),
            signer_email=opts.get("signer_email") or opts.get("signerEmail"),
            metadata=opts.get("metadata"),
        )

    # ── Batch hash + sign ──────────────────────────────────────────────────

    def batch_hash_and_sign(
        self,
        *,
        documents: list,
        reason: str = "Batch digital signature",
        hash_algorithm: str = "sha256",
        signer_name: str = None,
        signer_email: str = None,
        metadata: dict = None,
    ) -> dict:
        """Hash and sign multiple documents in one API call.

        All documents are hashed locally — none leave your system.

        Args:
            documents: List of dicts with keys 'data' (bytes) and
                       optionally 'file_name' (str).
            reason: Signing reason for all documents.
            hash_algorithm: sha256 | sha384 | sha512.
            signer_name: Full name of the signer.
            signer_email: Email address of the signer.
            metadata: Custom key/value metadata.

        Returns:
            API response with signatures for all documents.

        Example::

            result = client.sign.batch_hash_and_sign(
                documents=[
                    {"data": open("doc1.pdf", "rb").read(), "file_name": "doc1.pdf"},
                    {"data": open("doc2.pdf", "rb").read(), "file_name": "doc2.pdf"},
                ],
                reason="Batch approval",
            )
        """
        if not documents:
            raise ValueError("batch_hash_and_sign: documents list is required")

        hashed_docs = []
        for doc in documents:
            result = self._hasher.hash(doc["data"], hash_algorithm)
            hashed_docs.append(
                {
                    "documentHash": result["hash"],
                    "hashAlgorithm": hash_algorithm,
                    "fileName": doc.get("file_name", doc.get("fileName", "document.pdf")),
                }
            )

        body = {
            "documents": hashed_docs,
            "reason": reason,
            "metadata": metadata or {},
        }
        if signer_name:
            body["signerName"] = signer_name
        if signer_email:
            body["signerEmail"] = signer_email

        return self._http.post("/sdk/v1/sign/hash/batch", data=body)

    def batchHashAndSign(self, options: dict = None, /, **kwargs) -> dict:
        """Node-style alias for :meth:`batch_hash_and_sign`."""
        opts = _coerce_options(options, kwargs)
        return self.batch_hash_and_sign(
            documents=_normalise_document_batch(opts.get("documents") or []),
            reason=opts.get("reason", "Batch digital signature"),
            hash_algorithm=opts.get("hash_algorithm") or opts.get("hashAlgorithm") or "sha256",
            signer_name=opts.get("signer_name") or opts.get("signerName"),
            signer_email=opts.get("signer_email") or opts.get("signerEmail"),
            metadata=opts.get("metadata"),
        )

    def batch_sign_hashes(
        self,
        *,
        documents: list,
        reason: str = "Batch digital signature",
        signer_name: str = None,
        signer_email: str = None,
        metadata: dict = None,
    ) -> dict:
        """Sign multiple pre-computed hashes in one API call.

        Args:
            documents: List of dicts with keys 'document_hash',
                       optionally 'hash_algorithm' and 'file_name'.
            reason: Signing reason.
            signer_name: Full name of the signer.
            signer_email: Email address of the signer.
            metadata: Custom key/value metadata.

        Returns:
            API response with signatures for all documents.
        """
        if not documents:
            raise ValueError("batch_sign_hashes: documents list is required")

        body = {
            "documents": documents,
            "reason": reason,
            "metadata": metadata or {},
        }
        if signer_name:
            body["signerName"] = signer_name
        if signer_email:
            body["signerEmail"] = signer_email

        return self._http.post("/sdk/v1/sign/hash/batch", data=body)

    def batchSignHashes(self, options: dict = None, /, **kwargs) -> dict:
        """Node-style alias for :meth:`batch_sign_hashes`."""
        opts = _coerce_options(options, kwargs)
        return self.batch_sign_hashes(
            documents=opts.get("documents") or [],
            reason=opts.get("reason", "Batch digital signature"),
            signer_name=opts.get("signer_name") or opts.get("signerName"),
            signer_email=opts.get("signer_email") or opts.get("signerEmail"),
            metadata=opts.get("metadata"),
        )

    # ── Verify ─────────────────────────────────────────────────────────────

    def verify_by_id(self, envelope_id: str) -> dict:
        """Verify the signature of a previously signed envelope.

        Args:
            envelope_id: Envelope ID to verify.

        Returns:
            Verification result from the API.
        """
        if not envelope_id:
            raise ValueError("verify_by_id: envelope_id is required")
        from urllib.parse import quote
        return self._http.get(f"/sdk/v1/verify/{quote(envelope_id, safe='')}")

    def verifyById(self, envelope_id: str) -> dict:
        """Node-style alias for :meth:`verify_by_id`."""
        return self.verify_by_id(envelope_id)


def _coerce_options(options: dict, kwargs: dict) -> dict:
    if options is None:
        merged = {}
    elif isinstance(options, dict):
        merged = dict(options)
    else:
        raise TypeError("options must be a dict")
    merged.update(kwargs)
    return merged


def _normalise_document_batch(documents: list) -> list:
    normalised = []
    for doc in documents:
        item = dict(doc)
        if "document" in item and "data" not in item:
            item["data"] = item.pop("document")
        if "fileName" in item and "file_name" not in item:
            item["file_name"] = item["fileName"]
        normalised.append(item)
    return normalised
