"""CertySign SDK — X.509 certificate operations.

Covers:
  - issue()      POST /sdk/v1/certificates/issue
  - verify()     GET  /sdk/v1/certificates/:sn/verify
  - status()     GET  /sdk/v1/certificates/:sn/status
  - get_active() GET  /sdk/v1/certificates/active
"""

from urllib.parse import quote
from datetime import datetime


class CertificateResource:
    """X.509 certificate lifecycle management."""

    def __init__(self, http):
        self._http = http

    # ── Issue ──────────────────────────────────────────────────────────────

    def issue(
        self,
        options: dict = None,
        *,
        common_name: str = None,
        organisation: str = None,
        country: str = "KE",
        state: str = "Nairobi",
        locality: str = "Nairobi",
        email: str = None,
        validity_days: int = 365,
        key_size: int = 2048,
        metadata: dict = None,
    ) -> dict:
        """Issue a per-document X.509 certificate signed by CertySign Intermediate CA.

        The certificate includes CRL Distribution Points and OCSP AIA extensions.
        The private key is returned ONCE in the response — CertySign does not
        retain it after issuance.

        Args:
            common_name: Subject CN (e.g. 'DHA Kenya Claims System').
            organisation: Subject O (e.g. 'Department of Health Affairs').
            country: ISO 3166 alpha-2 country code (default: 'KE').
            state: State or province (default: 'Nairobi').
            locality: City (default: 'Nairobi').
            email: Subscriber email address.
            validity_days: Certificate validity in days (default: 365).
            key_size: RSA key size in bits (default: 2048).
            metadata: Custom metadata stored with the certificate record.

        Returns:
            API response with serialNumber, pemCertificate, privateKey, validUntil.

        Example::

            cert = client.certificates.issue(
                common_name="DHA Kenya Claims System",
                organisation="Department of Health Affairs",
                email="pki@dha.go.ke",
            )
            serial = cert["data"]["serialNumber"]
            pem    = cert["data"]["pemCertificate"]
            key    = cert["data"]["privateKey"]  # shown ONCE
        """
        opts = _coerce_options(options)
        common_name = common_name or opts.get("common_name") or opts.get("commonName")
        organisation = organisation or opts.get("organisation")
        country = opts.get("country", country)
        state = opts.get("state", state)
        locality = opts.get("locality", locality)
        email = email if email is not None else opts.get("email")
        validity_days = opts.get("validity_days", opts.get("validityDays", validity_days))
        key_size = opts.get("key_size", opts.get("keySize", key_size))
        metadata = metadata if metadata is not None else opts.get("metadata")

        if not common_name:
            raise ValueError("certificates.issue: common_name is required")
        if not organisation:
            raise ValueError("certificates.issue: organisation is required")

        body = {
            "commonName": common_name,
            "organisation": organisation,
            "country": country,
            "state": state,
            "locality": locality,
            "validityDays": validity_days,
            "keySize": key_size,
            "metadata": metadata or {},
        }
        if email:
            body["email"] = email

        return self._http.post("/sdk/v1/certificates/issue", data=body)

    # ── Verify ─────────────────────────────────────────────────────────────

    def verify(self, serial_number: str, at_time=None) -> dict:
        """Verify a certificate's validity at a specific point in time.

        Checks certificate chain, revocation status (CRL + OCSP),
        validity period, and key usage constraints.

        Args:
            serial_number: Certificate serial number (hex string).
            at_time: Point-in-time check as datetime or ISO string
                     (default: now).

        Returns:
            API response with valid flag and verification details.

        Example::

            result = client.certificates.verify(
                "A1B2C3D4E5F6...",
                at_time=datetime(2026, 1, 15, 10, 30),
            )
            if result["data"]["valid"]:
                print("Certificate was valid at signing time")
        """
        if not serial_number:
            raise ValueError("certificates.verify: serial_number is required")

        params = {}
        if at_time is not None:
            if isinstance(at_time, datetime):
                params["atTime"] = at_time.isoformat()
            else:
                params["atTime"] = at_time

        return self._http.get(
            f"/sdk/v1/certificates/{quote(serial_number, safe='')}/verify",
            params=params if params else None,
        )

    # ── Status ─────────────────────────────────────────────────────────────

    def status(self, serial_number: str) -> dict:
        """Get the current status of a certificate.

        Args:
            serial_number: Certificate serial number (hex string).

        Returns:
            API response with status: 'good' | 'revoked' | 'expired' | 'unknown'.

        Example::

            result = client.certificates.status("A1B2C3...")
            print(result["data"]["status"])          # 'good'
            print(result["data"]["revocationDate"])  # ISO 8601 if revoked
        """
        if not serial_number:
            raise ValueError("certificates.status: serial_number is required")
        return self._http.get(
            f"/sdk/v1/certificates/{quote(serial_number, safe='')}/status"
        )

    # ── Active Certificate ─────────────────────────────────────────────────

    def get_active(self) -> dict:
        """Get the tenant's active signing certificate.

        The certificate is resolved based on the API keys used for authentication.

        Returns:
            API response with certSerialNumber, certificate (PEM), validUntil.

        Example::

            result = client.certificates.get_active()
            print(result["data"]["certSerialNumber"])
            print(result["data"]["certificate"])  # PEM
        """
        return self._http.get("/sdk/v1/certificates/active")

    def getActive(self) -> dict:
        """Node-style alias for :meth:`get_active`."""
        return self.get_active()


def _coerce_options(options: dict) -> dict:
    if options is None:
        return {}
    if not isinstance(options, dict):
        raise TypeError("options must be a dict")
    return dict(options)
