"""CertySign SDK — SDK usage analytics dashboard.

Access dashboard statistics for your SDK-based signing operations:
  - Documents signed (total, today, this month)
  - Unique recipients across all signing sessions
  - Success / failure rates
  - Daily signing trends
  - Signed document listing with recipient details
"""


class DashboardResource:
    """SDK analytics — stats, recipients, documents."""

    def __init__(self, http):
        self._http = http

    def get_stats(
        self,
        options: dict = None,
        *,
        from_date: str = None,
        to_date: str = None,
    ) -> dict:
        """Get aggregate statistics for SDK signing activity.

        Args:
            from_date: ISO date — start of range (default: 30 days ago).
            to_date: ISO date — end of range (default: now).

        Returns:
            API response with documentsSignedToday, uniqueRecipientsCount,
            successRate, and daily trend data.

        Example::

            result = client.dashboard.get_stats()
            print("Documents signed today:", result["data"]["documentsSignedToday"])
            print("Unique recipients:", result["data"]["uniqueRecipientsCount"])
            print("Success rate:", str(result["data"]["successRate"]) + "%")
        """
        opts = _coerce_options(options)
        from_date = opts.get("from") or opts.get("from_date") or from_date
        to_date = opts.get("to") or opts.get("to_date") or to_date

        params = {}
        if from_date:
            params["from"] = from_date
        if to_date:
            params["to"] = to_date

        return self._http.get(
            "/sdk/v1/dashboard/stats",
            params=params if params else None,
        )

    def getStats(self, options: dict = None, /, **kwargs) -> dict:
        """Node-style alias for :meth:`get_stats`."""
        return self.get_stats(_merge_options(options, kwargs))

    def get_recipients(
        self,
        options: dict = None,
        *,
        page: int = None,
        limit: int = None,
        search: str = None,
    ) -> dict:
        """List unique recipients across all signing sessions.

        Args:
            page: Page number (default: 1).
            limit: Results per page (default: 50).
            search: Search by email or name.

        Returns:
            API response with recipients list and pagination.

        Example::

            result = client.dashboard.get_recipients(search="ceo")
            for r in result["data"]["recipients"]:
                print(f"{r['email']}: signed {r['signedSessions']} sessions")
        """
        opts = _coerce_options(options)
        page = opts.get("page", page)
        limit = opts.get("limit", limit)
        search = opts.get("search", search)

        params = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        if search:
            params["search"] = search

        return self._http.get(
            "/sdk/v1/dashboard/recipients",
            params=params if params else None,
        )

    def getRecipients(self, options: dict = None, /, **kwargs) -> dict:
        """Node-style alias for :meth:`get_recipients`."""
        return self.get_recipients(_merge_options(options, kwargs))

    def get_documents(
        self,
        options: dict = None,
        *,
        page: int = None,
        limit: int = None,
        status: str = None,
    ) -> dict:
        """List documents across all signing sessions with signature details.

        Args:
            page: Page number (default: 1).
            limit: Results per page (default: 20).
            status: Filter by status: 'active' | 'completed' | 'expired'.

        Returns:
            API response with documents list.

        Example::

            result = client.dashboard.get_documents(status="completed")
            for doc in result["data"]["documents"]:
                print(f"{doc['fileName']}: {doc['signatureCount']} signatures")
        """
        opts = _coerce_options(options)
        page = opts.get("page", page)
        limit = opts.get("limit", limit)
        status = opts.get("status", status)

        params = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        if status:
            params["status"] = status

        return self._http.get(
            "/sdk/v1/dashboard/documents",
            params=params if params else None,
        )

    def getDocuments(self, options: dict = None, /, **kwargs) -> dict:
        """Node-style alias for :meth:`get_documents`."""
        return self.get_documents(_merge_options(options, kwargs))


def _coerce_options(options: dict) -> dict:
    if options is None:
        return {}
    if not isinstance(options, dict):
        raise TypeError("options must be a dict")
    return dict(options)


def _merge_options(options: dict, kwargs: dict) -> dict:
    merged = _coerce_options(options)
    merged.update(kwargs)
    return merged
