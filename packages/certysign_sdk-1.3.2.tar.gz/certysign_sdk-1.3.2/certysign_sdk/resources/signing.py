"""CertySign SDK — document signing operations (legacy file-upload approach).

Covers:
  - quick_sign()      POST /sdk/v1/sign
  - batch_sign()      POST /sdk/v1/sign/batch
  - verify_by_id()    GET  /sdk/v1/verify/:envelopeId
  - verify_document() POST /sdk/v1/verify
"""

from io import IOBase
from urllib.parse import quote


class SigningResource:
    """Legacy file-upload signing — for backward compatibility."""

    def __init__(self, http):
        self._http = http

    # ── Quick Sign ─────────────────────────────────────────────────────────

    def quick_sign(
        self,
        *,
        document,
        filename: str = "document.pdf",
        signer_name: str,
        signer_email: str = None,
        reason: str = "Digital signature",
        location: str = "Nairobi, Kenya",
        metadata: dict = None,
    ) -> dict:
        """Sign a single document in one call.

        Uploads the document, creates an envelope, sends it, and signs it —
        all in a single API round-trip.

        Args:
            document: Document as bytes or file-like object.
            filename: File name for storage.
            signer_name: Full name of the signer (required).
            signer_email: Email address of the signer.
            reason: Signing reason.
            location: Physical signing location.
            metadata: Custom key/value metadata.

        Returns:
            API response with envelopeId and certificate.

        Example::

            result = client.legacy_sign.quick_sign(
                document=open("claim.pdf", "rb").read(),
                filename="claim.pdf",
                signer_name="Dr. Amina Okonkwo",
                signer_email="amina@dha.go.ke",
                reason="Health records approval",
            )
            print(result["data"]["envelopeId"])
        """
        if not document:
            raise ValueError("quick_sign: document (bytes or file) is required")
        if not signer_name:
            raise ValueError("quick_sign: signer_name is required")

        files = _build_files(document, filename)
        files["signerName"] = (None, signer_name)
        if signer_email:
            files["signerEmail"] = (None, signer_email)
        files["reason"] = (None, reason)
        files["location"] = (None, location)
        if metadata:
            import json
            files["metadata"] = (None, json.dumps(metadata))

        return self._http.post("/sdk/v1/sign", files=files)

    def quickSign(self, options: dict = None, /, **kwargs) -> dict:
        """Node-style alias for :meth:`quick_sign`."""
        opts = _coerce_options(options, kwargs)
        return self.quick_sign(
            document=opts.get("document"),
            filename=opts.get("filename", "document.pdf"),
            signer_name=opts.get("signer_name") or opts.get("signerName"),
            signer_email=opts.get("signer_email") or opts.get("signerEmail"),
            reason=opts.get("reason", "Digital signature"),
            location=opts.get("location", "Nairobi, Kenya"),
            metadata=opts.get("metadata"),
        )

    # ── Batch Sign ─────────────────────────────────────────────────────────

    def batch_sign(
        self,
        *,
        documents: list,
        signer_name: str,
        signer_email: str = None,
        reason: str = "Digital signature",
        location: str = "Nairobi, Kenya",
        metadata: dict = None,
    ) -> dict:
        """Sign multiple documents in one call.

        Args:
            documents: List of dicts with 'data' (bytes/file) and
                       optionally 'filename' (str).
            signer_name: Full name of the signer (required).
            signer_email: Email address of the signer.
            reason: Signing reason.
            location: Physical signing location.
            metadata: Custom key/value metadata.

        Returns:
            API response with signatures for all documents.
        """
        if not documents:
            raise ValueError("batch_sign: documents list is required")
        if not signer_name:
            raise ValueError("batch_sign: signer_name is required")

        import json as _json

        files = []
        for doc in documents:
            fname = doc.get("filename", "document.pdf")
            buf = doc["data"]
            if isinstance(buf, (bytes, bytearray)):
                files.append(("documents", (fname, buf, "application/pdf")))
            else:
                files.append(("documents", (fname, buf, "application/pdf")))

        files.append(("signerName", (None, signer_name)))
        if signer_email:
            files.append(("signerEmail", (None, signer_email)))
        files.append(("reason", (None, reason)))
        files.append(("location", (None, location)))
        if metadata:
            files.append(("metadata", (None, _json.dumps(metadata))))

        return self._http.post("/sdk/v1/sign/batch", files=files)

    def batchSign(self, options: dict = None, /, **kwargs) -> dict:
        """Node-style alias for :meth:`batch_sign`."""
        opts = _coerce_options(options, kwargs)
        return self.batch_sign(
            documents=_normalise_batch_documents(opts.get("documents") or []),
            signer_name=opts.get("signer_name") or opts.get("signerName"),
            signer_email=opts.get("signer_email") or opts.get("signerEmail"),
            reason=opts.get("reason", "Digital signature"),
            location=opts.get("location", "Nairobi, Kenya"),
            metadata=opts.get("metadata"),
        )

    # ── Verify ─────────────────────────────────────────────────────────────

    def verify_by_id(self, envelope_id: str) -> dict:
        """Verify the signature of a previously signed envelope.

        Args:
            envelope_id: Envelope ID returned from signing.

        Returns:
            Verification result from the API.
        """
        if not envelope_id:
            raise ValueError("verify_by_id: envelope_id is required")
        return self._http.get(f"/sdk/v1/verify/{quote(envelope_id, safe='')}")

    def verifyById(self, envelope_id: str) -> dict:
        """Node-style alias for :meth:`verify_by_id`."""
        return self.verify_by_id(envelope_id)

    def verify_document(self, document, filename: str = "document.pdf") -> dict:
        """Verify a document by uploading it (checks embedded signature).

        Args:
            document: Document as bytes or file-like object.
            filename: File name hint.

        Returns:
            Verification result from the API.
        """
        files = _build_files(document, filename)
        return self._http.post("/sdk/v1/verify", files=files)

    def verifyDocument(self, document, filename: str = "document.pdf") -> dict:
        """Node-style alias for :meth:`verify_document`."""
        return self.verify_document(document, filename)


# ── Helpers ──────────────────────────────────────────────────────────────────


def _build_files(document, filename: str) -> dict:
    """Build a files dict for requests multipart upload."""
    if isinstance(document, (bytes, bytearray)):
        return {"document": (filename, document, "application/pdf")}
    elif hasattr(document, "read"):
        return {"document": (filename, document, "application/pdf")}
    else:
        raise TypeError(
            f"document must be bytes or a file-like object, got {type(document)}"
        )


def _coerce_options(options: dict, kwargs: dict) -> dict:
    if options is None:
        merged = {}
    elif isinstance(options, dict):
        merged = dict(options)
    else:
        raise TypeError("options must be a dict")
    merged.update(kwargs)
    return merged


def _normalise_batch_documents(documents: list) -> list:
    normalised = []
    for doc in documents:
        item = dict(doc)
        if "fileName" in item and "filename" not in item:
            item["filename"] = item["fileName"]
        normalised.append(item)
    return normalised
