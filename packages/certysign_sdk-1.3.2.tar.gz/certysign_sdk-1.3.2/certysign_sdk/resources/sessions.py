"""CertySign SDK — multi-recipient hash-based signing sessions.

Manages signing sessions where:
  - Document hashes are registered (documents stay local)
  - Recipients are added with sequential or parallel signing order
  - OTP verification is required before each recipient can sign
  - HSM signs the hash for each verified recipient

Covers:
  - create()         POST /sdk/v1/signing-sessions
  - get()            GET  /sdk/v1/signing-sessions/:id
  - list()           GET  /sdk/v1/signing-sessions
  - send_otp()       POST /sdk/v1/signing-sessions/:id/recipients/:rid/send-otp
  - verify_otp()     POST /sdk/v1/signing-sessions/:id/recipients/:rid/verify-otp
  - recipient_sign() POST /sdk/v1/signing-sessions/:id/recipients/:rid/sign
"""

from urllib.parse import quote


class SigningSessionResource:
    """Multi-recipient signing sessions with OTP verification."""

    def __init__(self, http):
        self._http = http

    def create(
        self,
        options: dict = None,
        *,
        name: str = None,
        documents: list = None,
        recipients: list = None,
        description: str = None,
        signing_order: str = "parallel",
        expires_at: str = None,
        signingOrder: str = None,
        expiresAt: str = None,
    ) -> dict:
        """Create a signing session with document hashes and recipients.

        Args:
            name: Session name (required).
            documents: List of dicts with 'hash', 'file_name',
                       optionally 'hash_algorithm' and 'mime_type'.
            recipients: List of dicts with 'email', 'name',
                        optionally 'role' and 'order'.
            description: Optional session description.
            signing_order: 'sequential' | 'parallel' (default: 'parallel').
            expires_at: ISO 8601 expiry datetime string.

        Returns:
            API response with session _id and recipients (with recipientId).

        Example::

            session = client.sessions.create(
                name="Q1 Contract",
                documents=[
                    {"hash": "abc123...", "file_name": "contract.pdf",
                     "hash_algorithm": "sha256"},
                ],
                recipients=[
                    {"email": "ceo@example.com", "name": "Jane CEO",
                     "role": "signer", "order": 1},
                ],
                signing_order="sequential",
            )
            session_id    = session["data"]["_id"]
            recipient_id  = session["data"]["recipients"][0]["recipientId"]
        """
        opts = _coerce_options(options)
        name = name or opts.get("name")
        documents = documents if documents is not None else opts.get("documents")
        recipients = recipients if recipients is not None else opts.get("recipients")
        description = description if description is not None else opts.get("description")
        signing_order = signingOrder or opts.get("signingOrder") or signing_order
        expires_at = expiresAt or opts.get("expiresAt") or expires_at

        if not name:
            raise ValueError("sessions.create: name is required")
        if not documents:
            raise ValueError("sessions.create: documents list is required")
        if not recipients:
            raise ValueError("sessions.create: recipients list is required")

        body = {
            "name": name,
            "documents": [_normalise_session_document(doc) for doc in documents],
            "recipients": recipients,
            "signingOrder": signing_order,
        }
        if description:
            body["description"] = description
        if expires_at:
            body["expiresAt"] = expires_at

        return self._http.post("/sdk/v1/signing-sessions", data=body)

    def get(self, session_id: str) -> dict:
        """Get a signing session by ID.

        Args:
            session_id: Session ID.

        Returns:
            API response with full session details.
        """
        if not session_id:
            raise ValueError("sessions.get: session_id is required")
        return self._http.get(
            f"/sdk/v1/signing-sessions/{quote(session_id, safe='')}"
        )

    def list(
        self,
        options: dict = None,
        *,
        page: int = 1,
        limit: int = 20,
        status: str = None,
    ) -> dict:
        """List signing sessions with pagination.

        Args:
            page: Page number (default: 1).
            limit: Results per page (default: 20).
            status: Filter by status.

        Returns:
            API response with sessions list and pagination.
        """
        opts = _coerce_options(options)
        page = opts.get("page", page)
        limit = opts.get("limit", limit)
        status = opts.get("status", status)

        params = {"page": page, "limit": limit}
        if status:
            params["status"] = status
        return self._http.get("/sdk/v1/signing-sessions", params=params)

    def send_otp(self, session_id: str, recipient_id: str) -> dict:
        """Send an OTP verification code to a recipient's email.

        Args:
            session_id: Session ID.
            recipient_id: Recipient ID from the session.

        Returns:
            API response confirming OTP was sent.

        Example::

            client.sessions.send_otp(session_id, recipient_id)
            # Recipient receives a 6-digit code at their email
        """
        if not session_id:
            raise ValueError("sessions.send_otp: session_id is required")
        if not recipient_id:
            raise ValueError("sessions.send_otp: recipient_id is required")
        return self._http.post(
            f"/sdk/v1/signing-sessions/{quote(session_id, safe='')}"
            f"/recipients/{quote(recipient_id, safe='')}/send-otp"
        )

    def sendOtp(self, session_id: str, recipient_id: str) -> dict:
        """Node-style alias for :meth:`send_otp`."""
        return self.send_otp(session_id, recipient_id)

    def verify_otp(
        self, session_id: str, recipient_id: str, code: str
    ) -> dict:
        """Verify a recipient's OTP code.

        On success, returns a short-lived signing token.

        Args:
            session_id: Session ID.
            recipient_id: Recipient ID.
            code: 6-digit OTP received via email.

        Returns:
            API response with signingToken and expiresAt.

        Example::

            result = client.sessions.verify_otp(session_id, recipient_id, "123456")
            signing_token = result["data"]["signingToken"]
        """
        if not session_id:
            raise ValueError("sessions.verify_otp: session_id is required")
        if not recipient_id:
            raise ValueError("sessions.verify_otp: recipient_id is required")
        if not code:
            raise ValueError("sessions.verify_otp: code is required")

        return self._http.post(
            f"/sdk/v1/signing-sessions/{quote(session_id, safe='')}"
            f"/recipients/{quote(recipient_id, safe='')}/verify-otp",
            data={"code": str(code)},
        )

    def verifyOtp(self, session_id: str, recipient_id: str, code: str) -> dict:
        """Node-style alias for :meth:`verify_otp`."""
        return self.verify_otp(session_id, recipient_id, code)

    def recipient_sign(
        self, session_id: str, recipient_id: str, signing_token: str
    ) -> dict:
        """Recipient signs all documents in the session.

        Requires the signing token obtained from verify_otp().

        Args:
            session_id: Session ID.
            recipient_id: Recipient ID.
            signing_token: Token from verify_otp().

        Returns:
            API response with signedDocuments, certificate, chain.

        Example::

            result = client.sessions.recipient_sign(
                session_id, recipient_id, signing_token
            )
            for doc in result["data"]["signedDocuments"]:
                signed_pdf = client.embedder.embed_in_pdf(
                    pdf_bytes,
                    signature=doc["signature"],
                    certificate=result["data"]["certificate"],
                    chain=result["data"]["chain"],
                    reason="Contract signing",
                    signer_name="Jane CEO",
                )
                open(f"signed-{doc['fileName']}", "wb").write(signed_pdf)
        """
        if not session_id:
            raise ValueError("sessions.recipient_sign: session_id is required")
        if not recipient_id:
            raise ValueError("sessions.recipient_sign: recipient_id is required")
        if not signing_token:
            raise ValueError("sessions.recipient_sign: signing_token is required")

        return self._http.post(
            f"/sdk/v1/signing-sessions/{quote(session_id, safe='')}"
            f"/recipients/{quote(recipient_id, safe='')}/sign",
            data={"signingToken": signing_token},
        )

    def recipientSign(
        self, session_id: str, recipient_id: str, signing_token: str
    ) -> dict:
        """Node-style alias for :meth:`recipient_sign`."""
        return self.recipient_sign(session_id, recipient_id, signing_token)


def _coerce_options(options: dict) -> dict:
    if options is None:
        return {}
    if not isinstance(options, dict):
        raise TypeError("options must be a dict")
    return dict(options)


def _normalise_session_document(document: dict) -> dict:
    item = dict(document)
    if "document_id" in item and "documentId" not in item:
        item["documentId"] = item.pop("document_id")
    if "file_name" in item and "fileName" not in item:
        item["fileName"] = item.pop("file_name")
    if "hash_algorithm" in item and "hashAlgorithm" not in item:
        item["hashAlgorithm"] = item.pop("hash_algorithm")
    if "mime_type" in item and "mimeType" not in item:
        item["mimeType"] = item.pop("mime_type")
    return item
