"""CertySign Python SDK tests.

Unit tests use the `responses` library to intercept HTTP calls so no
network access is required.  Integration tests require env vars
CERTYSIGN_PUBLIC_KEY and CERTYSIGN_SECRET_KEY and are skipped otherwise.
"""

import hashlib
import json
import os
import tempfile
import time
from unittest.mock import Mock

import pytest
import responses as resp_lib

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from certysign_sdk import CertySignClient, CertySignError, DocumentHasher, SignatureEmbedder

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

BASE = "https://core.certysign.io"


def make_client(**kwargs):
    """Return a CertySignClient pointed at production base URL by default."""
    defaults = {"public_key": "test-pub", "secret_key": "test-sec"}
    defaults.update(kwargs)
    return CertySignClient(**defaults)


def json_body(data):
    return json.dumps(data).encode()


# ---------------------------------------------------------------------------
# 1. Client construction
# ---------------------------------------------------------------------------

class TestClientConstruction:
    def test_requires_public_key(self):
        with pytest.raises((ValueError, TypeError)):
            CertySignClient(secret_key="sk")

    def test_requires_secret_key(self):
        with pytest.raises((ValueError, TypeError)):
            CertySignClient(public_key="pk")

    def test_valid_client(self):
        c = make_client()
        assert c is not None

    def test_environment_urls(self):
        expected = {
            "production": ("https://core.certysign.io", "https://tsa.certysign.io"),
            "staging": ("https://service.certysign.io", "https://tsa-staging.certysign.io"),
            "development": ("http://localhost:8000", "http://localhost:5015"),
            "test": ("http://localhost:8000", "http://localhost:5015"),
        }
        for env, (base_url, tsa_url) in expected.items():
            c = CertySignClient(public_key="pk", secret_key="sk", environment=env)
            assert c.base_url == base_url
            assert c.tsa_url == tsa_url

    def test_base_url_override(self):
        c = CertySignClient(
            public_key="pk", secret_key="sk",
            base_url="http://custom.example.com"
        )
        assert c is not None

    def test_unknown_environment_raises(self):
        with pytest.raises(ValueError):
            CertySignClient(public_key="pk", secret_key="sk", environment="qa")


# ---------------------------------------------------------------------------
# 2. Auth headers
# ---------------------------------------------------------------------------

class TestAuthHeaders:
    @resp_lib.activate
    def test_auth_headers_sent(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/stats",
            json={"ok": True},
            status=200,
        )
        c = make_client()
        c.dashboard.get_stats()

        req = resp_lib.calls[0].request
        assert req.headers["X-API-Key-Id"] == "test-pub"
        assert req.headers["X-API-Key-Secret"] == "test-sec"
        assert req.headers["X-Idempotency-Key"] != ""

    @resp_lib.activate
    def test_idempotency_key_unique_per_request(self):
        for _ in range(3):
            resp_lib.add(
                resp_lib.GET,
                f"{BASE}/sdk/v1/dashboard/stats",
                json={},
                status=200,
            )

        c = make_client()
        for _ in range(3):
            c.dashboard.get_stats()

        keys = [call.request.headers["X-Idempotency-Key"]
                for call in resp_lib.calls]
        assert len(set(keys)) == 3, "idempotency keys must be unique per request"

    @resp_lib.activate
    def test_ping_success(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/pki/info",
            json={
                "data": {
                    "keyName": "SDK Key",
                    "permissions": ["pki:info"],
                    "environment": "production",
                    "tenantId": "tenant_123",
                    "status": {"initialized": True},
                }
            },
            status=200,
        )
        c = make_client()
        result = c.ping()
        assert result["success"] is True
        assert result["data"]["keyName"] == "SDK Key"
        assert result["data"]["caInitialized"] is True

    @resp_lib.activate
    def test_ping_failure(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/pki/info",
            json={"message": "Unauthorized", "code": "AUTH_REQUIRED"},
            status=401,
        )
        c = make_client()
        result = c.ping()
        assert result["success"] is False
        assert result["code"] == "AUTH_REQUIRED"


# ---------------------------------------------------------------------------
# 3. Hasher (no network)
# ---------------------------------------------------------------------------

class TestDocumentHasher:
    def test_hash_bytes_default_sha256(self):
        hasher = DocumentHasher()
        data = b"hello certysign"
        result = hasher.hash(data)
        expected = hashlib.sha256(data).hexdigest()
        assert result["hash"] == expected
        assert result["algorithm"] == "sha256"
        assert result["size"] == len(data)

    def test_hash_lowercase_hex(self):
        hasher = DocumentHasher()
        result = hasher.hash(b"data")
        assert result["hash"] == result["hash"].lower()

    def test_hash_explicit_sha384(self):
        hasher = DocumentHasher()
        data = b"test"
        result = hasher.hash(data, algorithm="sha384")
        assert result["algorithm"] == "sha384"
        assert result["hash"] == hashlib.sha384(data).hexdigest()

    def test_hash_file(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as f:
            f.write(b"file content for hashing")
            path = f.name
        try:
            hasher = DocumentHasher()
            result = hasher.hash_file(path)
            expected = hashlib.sha256(b"file content for hashing").hexdigest()
            assert result["hash"] == expected
            assert result["file_name"] != ""
            assert result["algorithm"] == "sha256"
        finally:
            os.unlink(path)

    def test_hash_many(self):
        hasher = DocumentHasher()
        docs = [
            {"data": b"doc1", "file_name": "a.pdf"},
            {"data": b"doc2", "file_name": "b.pdf"},
        ]
        results = hasher.hash_many(docs)
        assert len(results) == 2
        assert results[0]["hash"] == hashlib.sha256(b"doc1").hexdigest()
        assert results[1]["hash"] == hashlib.sha256(b"doc2").hexdigest()

    def test_hash_files(self):
        paths = []
        expected = []
        for i in range(2):
            with tempfile.NamedTemporaryFile(delete=False) as f:
                data = f"content {i}".encode()
                f.write(data)
                paths.append(f.name)
                expected.append(hashlib.sha256(data).hexdigest())

        try:
            hasher = DocumentHasher()
            results = hasher.hash_files(paths)
            for i, res in enumerate(results):
                assert res["hash"] == expected[i]
        finally:
            for p in paths:
                os.unlink(p)

    def test_hash_via_client(self):
        """Hasher accessible from client."""
        c = make_client()
        result = c.hasher.hash(b"hello")
        assert result["hash"] == hashlib.sha256(b"hello").hexdigest()

    def test_hash_file_includes_node_alias_key(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as f:
            f.write(b"file content for hashing")
            path = f.name
        try:
            hasher = DocumentHasher()
            result = hasher.hashFile(path)
            assert result["fileName"] == result["file_name"]
        finally:
            os.unlink(path)

    def test_hash_many_accepts_node_style_file_name(self):
        hasher = DocumentHasher()
        results = hasher.hashMany([{"data": b"doc1", "fileName": "node.pdf"}])
        assert results[0]["fileName"] == "node.pdf"


# ---------------------------------------------------------------------------
# 4. Hash signing resource
# ---------------------------------------------------------------------------

class TestHashSigning:
    @resp_lib.activate
    def test_sign_hash_posts_to_correct_endpoint(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/sign/hash",
            json={"id": "sign_001", "status": "pending"},
            status=200,
        )
        c = make_client()
        result = c.sign.sign_hash(
            document_hash="aabbccddeeff",
            hash_algorithm="sha256",
            file_name="contract.pdf",
            reason="Approval",
        )
        assert result["id"] == "sign_001"
        req = resp_lib.calls[0].request
        body = json.loads(req.body)
        assert body["documentHash"] == "aabbccddeeff"
        assert body["hashAlgorithm"] == "sha256"

    @resp_lib.activate
    def test_sign_hash_requires_document_hash(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.sign.sign_hash(document_hash="")

    @resp_lib.activate
    def test_hash_and_sign_posts_hash(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/sign/hash",
            json={"id": "sign_002"},
            status=200,
        )
        data = b"document bytes"
        c = make_client()
        result = c.sign.hash_and_sign(
            document=data,
            file_name="invoice.pdf",
            reason="Invoice approval",
        )
        assert result["id"] == "sign_002"
        body = json.loads(resp_lib.calls[0].request.body)
        # The hash sent must equal the sha256 of the document
        expected_hash = hashlib.sha256(data).hexdigest()
        assert body["documentHash"] == expected_hash

    @resp_lib.activate
    def test_hash_and_sign_requires_document(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.sign.hash_and_sign(document=b"")

    @resp_lib.activate
    def test_batch_hash_and_sign_posts_to_batch_endpoint(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/sign/hash/batch",
            json={"results": []},
            status=200,
        )
        c = make_client()
        c.sign.batch_hash_and_sign(
            documents=[
                {"data": b"doc1", "file_name": "a.pdf"},
                {"data": b"doc2", "file_name": "b.pdf"},
            ]
        )
        req = resp_lib.calls[0].request
        body = json.loads(req.body)
        assert len(body["documents"]) == 2
        assert body["documents"][0]["documentHash"] == hashlib.sha256(b"doc1").hexdigest()

    @resp_lib.activate
    def test_batch_hash_and_sign_requires_documents(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.sign.batch_hash_and_sign(documents=[])

    @resp_lib.activate
    def test_verify_by_id_get(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/verify/sign_abc",
            json={"valid": True},
            status=200,
        )
        c = make_client()
        result = c.sign.verify_by_id("sign_abc")
        assert result["valid"] is True

    @resp_lib.activate
    def test_batch_sign_hashes_alias(self):
        """batch_sign_hashes must POST to /sdk/v1/sign/hash/batch."""
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/sign/hash/batch",
            json={},
            status=200,
        )
        c = make_client()
        c.sign.batch_sign_hashes(
            documents=[{"documentHash": "aa", "hashAlgorithm": "sha256"}]
        )
        assert "/sdk/v1/sign/hash/batch" in resp_lib.calls[0].request.url

    @resp_lib.activate
    def test_hash_and_sign_node_alias_accepts_options_object(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/sign/hash",
            json={"id": "sign_alias"},
            status=200,
        )
        c = make_client()
        c.sign.hashAndSign(
            {
                "document": b"node-bytes",
                "fileName": "claim.pdf",
                "signerEmail": "qa@example.com",
                "reason": "Approval",
            }
        )
        body = json.loads(resp_lib.calls[0].request.body)
        assert body["fileName"] == "claim.pdf"
        assert body["signerEmail"] == "qa@example.com"

    @resp_lib.activate
    def test_batch_hash_and_sign_node_alias_normalises_document_keys(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/sign/hash/batch",
            json={"results": []},
            status=200,
        )
        c = make_client()
        c.sign.batchHashAndSign(
            {
                "documents": [
                    {"document": b"doc1", "fileName": "node-a.pdf"},
                ]
            }
        )
        body = json.loads(resp_lib.calls[0].request.body)
        assert body["documents"][0]["fileName"] == "node-a.pdf"


# ---------------------------------------------------------------------------
# 5. Signing sessions resource
# ---------------------------------------------------------------------------

class TestSessions:
    @resp_lib.activate
    def test_create_posts_to_correct_endpoint(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/signing-sessions",
            json={"id": "sess_001"},
            status=201,
        )
        c = make_client()
        result = c.sessions.create(
            name="Contract Signing",
            documents=[{"hash": "aabb", "file_name": "contract.pdf"}],
            recipients=[{"email": "alice@example.com", "name": "Alice"}],
            signing_order="sequential",
        )
        assert result["id"] == "sess_001"
        body = json.loads(resp_lib.calls[0].request.body)
        assert body["name"] == "Contract Signing"
        assert body["signingOrder"] == "sequential"

    def test_create_requires_name(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.sessions.create(name="", documents=[{"hash": "a"}], recipients=[{}])

    def test_create_requires_documents(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.sessions.create(name="Test", documents=[], recipients=[{}])

    def test_create_requires_recipients(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.sessions.create(name="Test", documents=[{"hash": "a"}], recipients=[])

    @resp_lib.activate
    def test_get_session(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/signing-sessions/sess_abc",
            json={"id": "sess_abc"},
            status=200,
        )
        c = make_client()
        result = c.sessions.get("sess_abc")
        assert result["id"] == "sess_abc"

    def test_get_requires_session_id(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.sessions.get("")

    @resp_lib.activate
    def test_list_sessions(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/signing-sessions",
            json={"items": []},
            status=200,
        )
        c = make_client()
        c.sessions.list()
        assert "/sdk/v1/signing-sessions" in resp_lib.calls[0].request.url

    @resp_lib.activate
    def test_send_otp(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/signing-sessions/sess_1/recipients/rec_1/send-otp",
            json={"sent": True},
            status=200,
        )
        c = make_client()
        result = c.sessions.send_otp("sess_1", "rec_1")
        assert result["sent"] is True

    def test_send_otp_validation(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.sessions.send_otp("", "rec_1")
        with pytest.raises(ValueError):
            c.sessions.send_otp("sess_1", "")

    @resp_lib.activate
    def test_verify_otp(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/signing-sessions/sess_1/recipients/rec_1/verify-otp",
            json={"signingToken": "tok_xyz"},
            status=200,
        )
        c = make_client()
        result = c.sessions.verify_otp("sess_1", "rec_1", "123456")
        assert result["signingToken"] == "tok_xyz"
        body = json.loads(resp_lib.calls[0].request.body)
        assert body["code"] == "123456"

    def test_verify_otp_validation(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.sessions.verify_otp("", "r", "c")
        with pytest.raises(ValueError):
            c.sessions.verify_otp("s", "", "c")
        with pytest.raises(ValueError):
            c.sessions.verify_otp("s", "r", "")

    @resp_lib.activate
    def test_recipient_sign(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/signing-sessions/sess_1/recipients/rec_1/sign",
            json={"status": "signed"},
            status=200,
        )
        c = make_client()
        result = c.sessions.recipient_sign("sess_1", "rec_1", "tok_xyz")
        assert result["status"] == "signed"
        body = json.loads(resp_lib.calls[0].request.body)
        assert body["signingToken"] == "tok_xyz"

    def test_recipient_sign_validation(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.sessions.recipient_sign("", "r", "t")
        with pytest.raises(ValueError):
            c.sessions.recipient_sign("s", "", "t")
        with pytest.raises(ValueError):
            c.sessions.recipient_sign("s", "r", "")

    @resp_lib.activate
    def test_create_accepts_node_options_object(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/signing-sessions",
            json={"id": "sess_node"},
            status=201,
        )
        c = make_client()
        c.sessions.create(
            {
                "name": "Node Session",
                "documents": [
                    {
                        "document_id": "doc1",
                        "file_name": "contract.pdf",
                        "hash": "aabb",
                        "hash_algorithm": "sha256",
                        "mime_type": "application/pdf",
                    }
                ],
                "recipients": [{"email": "alice@example.com", "name": "Alice"}],
                "signingOrder": "sequential",
                "expiresAt": "2026-04-01T00:00:00Z",
            }
        )
        body = json.loads(resp_lib.calls[0].request.body)
        assert body["documents"][0]["documentId"] == "doc1"
        assert body["documents"][0]["fileName"] == "contract.pdf"
        assert body["documents"][0]["hashAlgorithm"] == "sha256"
        assert body["documents"][0]["mimeType"] == "application/pdf"
        assert body["signingOrder"] == "sequential"
        assert body["expiresAt"] == "2026-04-01T00:00:00Z"

    @resp_lib.activate
    def test_send_otp_node_alias(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/signing-sessions/sess_1/recipients/rec_1/send-otp",
            json={"sent": True},
            status=200,
        )
        c = make_client()
        result = c.sessions.sendOtp("sess_1", "rec_1")
        assert result["sent"] is True


# ---------------------------------------------------------------------------
# 6. Certificates resource
# ---------------------------------------------------------------------------

class TestCertificates:
    @resp_lib.activate
    def test_issue_posts_to_correct_endpoint(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/certificates/issue",
            json={"serialNumber": "SN001"},
            status=201,
        )
        c = make_client()
        result = c.certificates.issue(
            common_name="Alice Doe",
            organisation="ACME Corp",
            email="alice@example.com",
        )
        assert result["serialNumber"] == "SN001"
        body = json.loads(resp_lib.calls[0].request.body)
        assert body["commonName"] == "Alice Doe"
        assert body["organisation"] == "ACME Corp"

    def test_issue_requires_common_name(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.certificates.issue(common_name="", organisation="ACME")

    def test_issue_requires_organisation(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.certificates.issue(common_name="Alice", organisation="")

    @resp_lib.activate
    def test_verify_get(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/certificates/SN001/verify",
            json={"valid": True},
            status=200,
        )
        c = make_client()
        result = c.certificates.verify("SN001")
        assert result["valid"] is True
        assert "/sdk/v1/certificates/SN001/verify" in resp_lib.calls[0].request.url

    @resp_lib.activate
    def test_status_get(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/certificates/SN001/status",
            json={"status": "active"},
            status=200,
        )
        c = make_client()
        result = c.certificates.status("SN001")
        assert result["status"] == "active"

    @resp_lib.activate
    def test_get_active(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/certificates/active",
            json={"serialNumber": "SN999"},
            status=200,
        )
        c = make_client()
        result = c.certificates.get_active()
        assert result["serialNumber"] == "SN999"

    @resp_lib.activate
    def test_issue_accepts_node_options_object(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/certificates/issue",
            json={"serialNumber": "SN002"},
            status=201,
        )
        c = make_client()
        c.certificates.issue(
            {
                "commonName": "Alice Doe",
                "organisation": "ACME Corp",
                "validityDays": 90,
                "keySize": 4096,
            }
        )
        body = json.loads(resp_lib.calls[0].request.body)
        assert body["commonName"] == "Alice Doe"
        assert body["validityDays"] == 90
        assert body["keySize"] == 4096


# ---------------------------------------------------------------------------
# 7. Envelopes resource
# ---------------------------------------------------------------------------

class TestEnvelopes:
    @resp_lib.activate
    def test_create_posts_to_correct_endpoint(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/envelopes",
            json={"id": "env_001"},
            status=201,
        )
        c = make_client()
        result = c.envelopes.create(
            title="Sales Contract",
            signers=[{"email": "bob@example.com", "name": "Bob"}],
        )
        assert result["id"] == "env_001"
        body = json.loads(resp_lib.calls[0].request.body)
        assert body["title"] == "Sales Contract"

    def test_create_requires_title(self):
        c = make_client()
        with pytest.raises(ValueError):
            c.envelopes.create(title="")

    @resp_lib.activate
    def test_get_envelope(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/envelopes/env_abc",
            json={"id": "env_abc"},
            status=200,
        )
        c = make_client()
        result = c.envelopes.get("env_abc")
        assert result["id"] == "env_abc"

    @resp_lib.activate
    def test_list_envelopes(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/envelopes",
            json={"items": []},
            status=200,
        )
        c = make_client()
        c.envelopes.list()
        assert "/sdk/v1/envelopes" in resp_lib.calls[0].request.url

    @resp_lib.activate
    def test_send_envelope(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/envelopes/env_001/send",
            json={"status": "sent"},
            status=200,
        )
        c = make_client()
        result = c.envelopes.send("env_001")
        assert result["status"] == "sent"

    @resp_lib.activate
    def test_sign_envelope(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/envelopes/env_001/sign",
            json={"status": "signed"},
            status=200,
        )
        c = make_client()
        result = c.envelopes.sign(
            "env_001",
            reason="Approval",
            location="Nairobi, Kenya",
        )
        assert result["status"] == "signed"
        body = json.loads(resp_lib.calls[0].request.body)
        assert body["reason"] == "Approval"
        assert body["location"] == "Nairobi, Kenya"

    @resp_lib.activate
    def test_get_document(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/envelopes/env_001/documents/doc_001",
            body=b"%PDF-stub",
            status=200,
            content_type="application/pdf",
        )
        c = make_client()
        data = c.envelopes.get_document("env_001", "doc_001")
        assert len(data) > 0

    @resp_lib.activate
    def test_get_audit_trail(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/envelopes/env_001/audit",
            json={"events": []},
            status=200,
        )
        c = make_client()
        c.envelopes.get_audit_trail("env_001")
        assert "/sdk/v1/envelopes/env_001/audit" in resp_lib.calls[0].request.url

    @resp_lib.activate
    def test_upload_documents_node_alias_accepts_name_key(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/envelopes/env_001/documents",
            json={"uploaded": True},
            status=200,
        )
        c = make_client()
        result = c.envelopes.uploadDocuments(
            "env_001",
            [{"name": "node.pdf", "data": b"%PDF-1.4"}],
        )
        assert result["uploaded"] is True

    @resp_lib.activate
    def test_sign_accepts_node_options_object(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/envelopes/env_001/sign",
            json={"status": "signed"},
            status=200,
        )
        c = make_client()
        c.envelopes.sign("env_001", {"reason": "Node approval", "location": "Nairobi"})
        body = json.loads(resp_lib.calls[0].request.body)
        assert body["reason"] == "Node approval"
        assert body["location"] == "Nairobi"


# ---------------------------------------------------------------------------
# 8. Dashboard resource
# ---------------------------------------------------------------------------

class TestDashboard:
    @resp_lib.activate
    def test_get_stats(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/stats",
            json={"total": 42},
            status=200,
        )
        c = make_client()
        result = c.dashboard.get_stats(from_date="2024-01-01")
        assert result["total"] == 42
        assert "from=2024-01-01" in resp_lib.calls[0].request.url

    @resp_lib.activate
    def test_get_recipients(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/recipients",
            json={"items": []},
            status=200,
        )
        c = make_client()
        c.dashboard.get_recipients()
        assert "/sdk/v1/dashboard/recipients" in resp_lib.calls[0].request.url

    @resp_lib.activate
    def test_get_documents(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/documents",
            json={"items": []},
            status=200,
        )
        c = make_client()
        c.dashboard.get_documents()
        assert "/sdk/v1/dashboard/documents" in resp_lib.calls[0].request.url

    @resp_lib.activate
    def test_get_stats_node_alias_accepts_from_to(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/stats",
            json={"total": 42},
            status=200,
        )
        c = make_client()
        result = c.dashboard.getStats({"from": "2024-01-01", "to": "2024-01-31"})
        assert result["total"] == 42
        assert "from=2024-01-01" in resp_lib.calls[0].request.url
        assert "to=2024-01-31" in resp_lib.calls[0].request.url


# ---------------------------------------------------------------------------
# 9. PKI resource
# ---------------------------------------------------------------------------

class TestPKI:
    @resp_lib.activate
    def test_crl_default_pem(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/pki/crl",
            body="-----BEGIN X509 CRL-----\n-----END X509 CRL-----\n",
            status=200,
            content_type="application/x-pem-file",
        )
        c = make_client()
        data = c.pki.crl("pem")
        assert "X509 CRL" in data

    @resp_lib.activate
    def test_crl_der(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/pki/crl",
            body=b"\x30\x82\x01",  # DER stub
            status=200,
            content_type="application/pkix-crl",
        )
        c = make_client()
        data = c.pki.crl("der")
        assert isinstance(data, bytes)

    @resp_lib.activate
    def test_ocsp(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/pki/ocsp/SN001",
            json={"status": "good"},
            status=200,
        )
        c = make_client()
        result = c.pki.ocsp("SN001")
        assert result["status"] == "good"
        assert "/sdk/v1/pki/ocsp/SN001" in resp_lib.calls[0].request.url

    @resp_lib.activate
    def test_chain(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/pki/chain",
            json={"chain": []},
            status=200,
        )
        c = make_client()
        c.pki.chain()
        assert "/sdk/v1/pki/chain" in resp_lib.calls[0].request.url

    @resp_lib.activate
    def test_info(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/pki/info",
            json={"version": "1.0"},
            status=200,
        )
        c = make_client()
        result = c.pki.info()
        assert result["version"] == "1.0"


# ---------------------------------------------------------------------------
# 10. Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    @resp_lib.activate
    def test_api_error_raised(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/stats",
            json={"message": "Unauthorized", "code": "AUTH_REQUIRED"},
            status=401,
        )
        c = make_client()
        with pytest.raises(CertySignError) as exc_info:
            c.dashboard.get_stats()
        err = exc_info.value
        assert err.status_code == 401
        assert err.code == "AUTH_REQUIRED"

    @resp_lib.activate
    def test_404_raises_error(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/signing-sessions/bad_id",
            json={"message": "Not found"},
            status=404,
        )
        c = make_client()
        with pytest.raises(CertySignError):
            c.sessions.get("bad_id")

    @resp_lib.activate
    def test_non_json_error_body(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/stats",
            body="Internal Server Error",
            status=500,
            content_type="text/plain",
        )
        c = make_client()
        with pytest.raises(CertySignError):
            c.dashboard.get_stats()


class TestNodeStyleAliases:
    def test_client_exposes_legacy_sign_alias(self):
        c = make_client()
        assert c.legacySign is c.legacy_sign

    @resp_lib.activate
    def test_legacy_sign_node_aliases_exist(self):
        resp_lib.add(
            resp_lib.POST,
            f"{BASE}/sdk/v1/sign",
            json={"ok": True},
            status=200,
        )
        c = make_client()
        result = c.legacySign.quickSign(
            {
                "document": b"%PDF-1.4",
                "filename": "legacy.pdf",
                "signerName": "Legacy User",
            }
        )
        assert result["ok"] is True

    def test_embedder_node_style_pdf_alias_maps_options(self):
        embedder = SignatureEmbedder()
        embedder.embed_in_pdf = Mock(return_value=b"signed-pdf")
        result = embedder.embedInPdf(
            b"%PDF-1.4",
            {
                "signerEmail": "qa@example.com",
                "signCallback": lambda _: {"data": {"signature": "sig"}},
                "signaturePosition": {"page": 1, "x": 30, "y": 40, "width": 260},
            },
        )
        assert result == b"signed-pdf"
        _, kwargs = embedder.embed_in_pdf.call_args
        assert kwargs["signer_email"] == "qa@example.com"
        assert kwargs["signature_position"]["page"] == 1

    def test_embedder_node_style_xml_alias_maps_options(self):
        embedder = SignatureEmbedder()
        embedder.embed_in_xml = Mock(return_value="<signed/>")
        result = embedder.embedInXml(
            "<root/>",
            {"certSerialNumber": "ABC", "signerEmail": "qa@example.com", "signature": "sig"},
        )
        assert result == "<signed/>"
        _, kwargs = embedder.embed_in_xml.call_args
        assert kwargs["cert_serial_number"] == "ABC"
        assert kwargs["signer_email"] == "qa@example.com"

    def test_embedder_node_style_json_alias_maps_options(self):
        embedder = SignatureEmbedder()
        embedder.embed_in_json = Mock(return_value={"ok": True})
        result = embedder.embedInJson(
            {"hello": "world"},
            {"documentHash": "abc", "hashAlgorithm": "sha256", "signature": "sig"},
        )
        assert result == {"ok": True}
        _, kwargs = embedder.embed_in_json.call_args
        assert kwargs["document_hash"] == "abc"
        assert kwargs["hash_algorithm"] == "sha256"


# ---------------------------------------------------------------------------
# 11. Retry behaviour
# ---------------------------------------------------------------------------

class TestRetry:
    @resp_lib.activate
    def test_retries_on_429(self):
        # First two calls return 429, third returns 200
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/stats",
            json={},
            status=429,
        )
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/stats",
            json={},
            status=429,
        )
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/stats",
            json={"ok": True},
            status=200,
        )
        c = CertySignClient(
            public_key="pk", secret_key="sk",
            retries=3,
        )
        start = time.time()
        result = c.dashboard.get_stats()
        elapsed = time.time() - start
        assert result["ok"] is True
        assert len(resp_lib.calls) == 3
        # There should be at least some back-off delay
        assert elapsed >= 0.15

    @resp_lib.activate
    def test_no_retry_on_400(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/stats",
            json={"message": "Bad Request"},
            status=400,
        )
        c = CertySignClient(
            public_key="pk", secret_key="sk",
            retries=3,
        )
        with pytest.raises(CertySignError):
            c.dashboard.get_stats()
        # Only one call — no retry for 400
        assert len(resp_lib.calls) == 1

    @resp_lib.activate
    def test_retries_on_503(self):
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/stats",
            json={},
            status=503,
        )
        resp_lib.add(
            resp_lib.GET,
            f"{BASE}/sdk/v1/dashboard/stats",
            json={"ok": True},
            status=200,
        )
        c = CertySignClient(
            public_key="pk", secret_key="sk",
            retries=2,
        )
        result = c.dashboard.get_stats()
        assert result["ok"] is True
        assert len(resp_lib.calls) == 2


# ---------------------------------------------------------------------------
# 12. Integration tests (skipped unless API keys provided)
# ---------------------------------------------------------------------------

def _integration_client():
    pub = os.environ.get("CERTYSIGN_PUBLIC_KEY")
    sec = os.environ.get("CERTYSIGN_SECRET_KEY")
    env = os.environ.get("CERTYSIGN_ENV", "staging")
    if not pub or not sec:
        pytest.skip("integration test requires CERTYSIGN_PUBLIC_KEY and CERTYSIGN_SECRET_KEY")
    return CertySignClient(public_key=pub, secret_key=sec, environment=env)


class TestIntegration:
    def test_dashboard_stats(self):
        c = _integration_client()
        result = c.dashboard.get_stats()
        assert result is not None

    def test_hash_and_sign(self):
        c = _integration_client()
        data = f"integration test {time.time()}".encode()
        result = c.sign.hash_and_sign(
            document=data,
            file_name="integration-test.pdf",
            reason="Python SDK integration test",
        )
        assert result is not None

    def test_pki_info(self):
        c = _integration_client()
        result = c.pki.info()
        assert result is not None

    def test_certificates_get_active(self):
        c = _integration_client()
        result = c.certificates.get_active()
        assert result is not None
