#!/usr/bin/env python3
"""
Plugin para integración con Azure DevOps.
Se activa automáticamente si AZURE_DEVOPS_ENABLED=true en .env
"""
import os
from .base_plugin import BasePlugin
from hakalab_framework.core.azure_devops_manager import AzureDevOpsManager


class AzureDevOpsPlugin(BasePlugin):
    """
    Plugin para integración automática con Azure DevOps.
    
    Funcionalidades:
    - Actualiza work items (test cases) con el estado del test
    - Adjunta reportes a work items (tasks)
    - Se configura completamente desde .env
    """
    
    def _is_enabled(self) -> bool:
        """Plugin habilitado si AZURE_DEVOPS_ENABLED=true."""
        return os.getenv('AZURE_DEVOPS_ENABLED', 'false').lower() == 'true'
    
    def before_all(self, context) -> None:
        """Inicializa el gestor de Azure DevOps."""
        if self.enabled:
            context.azure_devops = AzureDevOpsManager(context)
            if context.azure_devops.enabled:
                context.azure_devops.logger.info("🔵 Azure DevOps Plugin inicializado")
            else:
                context.azure_devops.logger.warning(
                    "⚠️ Azure DevOps Plugin habilitado pero configuración incompleta"
                )
    
    def after_scenario(self, context, scenario) -> None:
        """
        Procesa el escenario después de su ejecución.
        
        Convención de tags:
        - Primer tag: ID del test case (ej: @TC-123)
        - Segundo tag: ID de la task para adjuntar reporte (ej: @TASK-456)
        
        NOTA: El reporte se adjunta en after_all, no aquí, porque el reporte
        HTML se genera después de todos los escenarios.
        """
        if not self.enabled or not hasattr(context, 'azure_devops'):
            return
        
        if not context.azure_devops.enabled:
            return
        
        try:
            # Determinar el estado del test
            status = context.azure_devops.config['status_passed']
            if scenario.status == 'failed':
                status = context.azure_devops.config['status_failed']
            
            # Log de debug
            context.azure_devops.logger.info(f"🔍 Procesando escenario: {scenario.name}")
            context.azure_devops.logger.info(f"🔍 Tags: {scenario.tags if hasattr(scenario, 'tags') else 'Sin tags'}")
            
            # Procesar tags y actualizar SOLO el test case (sin reporte)
            results = context.azure_devops.process_scenario_tags(
                scenario,
                status,
                None  # No adjuntar reporte aquí
            )
            
            # Log de resultados
            if results.get('test_case_updated'):
                context.azure_devops.logger.info(
                    f"✅ Test case {results['test_case_id']} actualizado: {status}"
                )
            
            # Guardar info del escenario para adjuntar reporte después
            if not hasattr(context, '_azure_scenarios_to_attach'):
                context._azure_scenarios_to_attach = []
            
            # Guardar el segundo tag (task) si existe
            if hasattr(scenario, 'tags') and len(scenario.tags) >= 2:
                task_id = scenario.tags[1]
                context._azure_scenarios_to_attach.append({
                    'task_id': task_id,
                    'scenario_name': scenario.name
                })
                context.azure_devops.logger.info(
                    f"📋 Task {task_id} marcada para adjuntar reporte después"
                )
                
        except Exception as e:
            if hasattr(context, 'logger'):
                context.logger.error(f"❌ Error en Azure DevOps Plugin: {e}")
            else:
                print(f"❌ Error en Azure DevOps Plugin: {e}")
            import traceback
            traceback.print_exc()
    
    def after_all(self, context) -> None:
        """
        Adjunta el reporte HTML a las tasks después de que se genere.
        """
        if not self.enabled or not hasattr(context, 'azure_devops'):
            return
        
        if not context.azure_devops.enabled:
            return
        
        # Verificar si hay tasks pendientes para adjuntar reporte
        if not hasattr(context, '_azure_scenarios_to_attach'):
            return
        
        try:
            # Buscar el reporte HTML más reciente
            report_path = self._find_latest_html_report(context)
            
            if not report_path:
                context.azure_devops.logger.warning(
                    "⚠️ No se encontró reporte HTML para adjuntar"
                )
                return
            
            context.azure_devops.logger.info(f"📄 Reporte encontrado: {report_path}")
            
            # Adjuntar reporte a cada task
            for scenario_info in context._azure_scenarios_to_attach:
                task_id = scenario_info['task_id']
                scenario_name = scenario_info['scenario_name']
                
                try:
                    success = context.azure_devops.attach_report_to_task(
                        task_id,
                        report_path
                    )
                    
                    if success:
                        context.azure_devops.logger.info(
                            f"✅ Reporte adjuntado a task {task_id} ({scenario_name})"
                        )
                    else:
                        context.azure_devops.logger.warning(
                            f"⚠️ No se pudo adjuntar reporte a task {task_id}"
                        )
                except Exception as e:
                    context.azure_devops.logger.error(
                        f"❌ Error adjuntando reporte a task {task_id}: {e}"
                    )
        
        except Exception as e:
            if hasattr(context, 'logger'):
                context.logger.error(f"❌ Error en Azure DevOps Plugin (after_all): {e}")
            else:
                print(f"❌ Error en Azure DevOps Plugin (after_all): {e}")
            import traceback
            traceback.print_exc()
    
    def _find_latest_html_report(self, context) -> str:
        """
        Busca el reporte HTML más reciente en el directorio de reportes.
        
        Prioridad:
        1. context.html_report_path (si existe)
        2. Buscar en directorio configurado el archivo más reciente
        3. Buscar en reports/html-reports/ el archivo más reciente
        """
        from pathlib import Path
        import os
        
        # 1. Intentar obtener del contexto
        if hasattr(context, 'html_report_path'):
            report_path = Path(context.html_report_path)
            if report_path.exists():
                context.azure_devops.logger.info(
                    f"📄 Usando reporte del contexto: {report_path}"
                )
                return str(report_path)
        
        # 2. Buscar en directorio configurado
        report_dir = context.azure_devops.config.get('report_path')
        if report_dir:
            report_dir = Path(report_dir).parent
        else:
            # 3. Directorio por defecto
            report_dir = Path('reports/html-reports')
        
        if not report_dir.exists():
            context.azure_devops.logger.warning(
                f"⚠️ Directorio de reportes no existe: {report_dir}"
            )
            return None
        
        # Buscar archivos HTML en el directorio
        html_files = list(report_dir.glob('*.html'))
        
        if not html_files:
            context.azure_devops.logger.warning(
                f"⚠️ No se encontraron archivos HTML en: {report_dir}"
            )
            return None
        
        # Obtener el archivo más reciente
        latest_file = max(html_files, key=lambda p: p.stat().st_mtime)
        
        context.azure_devops.logger.info(
            f"📄 Reporte más reciente encontrado: {latest_file}"
        )
        
        return str(latest_file)
