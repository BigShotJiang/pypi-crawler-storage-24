# language: es

@azure_devops
Característica: Ejemplo de Integración con Azure DevOps
  Como QA Engineer
  Quiero que mis tests se integren automáticamente con Azure DevOps
  Para mantener actualizado el estado de los test cases y adjuntar reportes

  Antecedentes:
    Given navego a "https://example.com"

  # ============================================================================
  # EJEMPLO 1: Test Case + Task (Integración Completa)
  # ============================================================================
  # - Primer tag (@TC-1234): ID del Test Case a actualizar
  # - Segundo tag (@TASK-5678): ID de la Task donde adjuntar reporte
  
  @TC-1234 @TASK-5678
  Escenario: Login exitoso con integración completa
    When ingreso "user@example.com" en el campo "email"
    And ingreso "password123" en el campo "password"
    And hago click en el botón "Login"
    Then veo el elemento "Dashboard"
    
    # Resultado esperado:
    # ✅ Test Case 1234 actualizado con estado "Passed"
    # ✅ Reporte adjuntado a Task 5678

  # ============================================================================
  # EJEMPLO 2: Solo Test Case (Sin adjuntar reporte)
  # ============================================================================
  # Si solo pones un tag, solo se actualiza el Test Case
  
  @TC-1235
  Escenario: Login con credenciales inválidas
    When ingreso "invalid@example.com" en el campo "email"
    And ingreso "wrongpassword" en el campo "password"
    And hago click en el botón "Login"
    Then veo el elemento "Error message"
    
    # Resultado esperado:
    # ✅ Test Case 1235 actualizado con estado "Passed"
    # ❌ No se adjunta reporte (no hay segundo tag)

  # ============================================================================
  # EJEMPLO 3: Test que falla (Estado Failed)
  # ============================================================================
  
  @TC-1236 @TASK-5679
  Escenario: Recuperación de contraseña
    When hago click en el enlace "Forgot Password"
    And ingreso "user@example.com" en el campo "email"
    And hago click en el botón "Send Reset Link"
    Then veo el elemento "Check your email"
    
    # Si este test falla:
    # ✅ Test Case 1236 actualizado con estado "Failed"
    # ✅ Reporte adjuntado a Task 5679

  # ============================================================================
  # EJEMPLO 4: Múltiples tests para la misma Task
  # ============================================================================
  # Varios tests pueden adjuntar reportes a la misma Task
  
  @TC-1237 @TASK-5680
  Escenario: Registro de usuario - Paso 1
    When hago click en el botón "Sign Up"
    And ingreso "newuser@example.com" en el campo "email"
    Then veo el elemento "Continue"
  
  @TC-1238 @TASK-5680
  Escenario: Registro de usuario - Paso 2
    Given estoy en la página de registro
    When ingreso "John Doe" en el campo "name"
    And ingreso "password123" en el campo "password"
    Then veo el elemento "Create Account"
    
    # Resultado esperado:
    # ✅ Test Case 1237 actualizado
    # ✅ Test Case 1238 actualizado
    # ✅ Ambos reportes adjuntados a Task 5680

  # ============================================================================
  # EJEMPLO 5: Formatos de tags soportados
  # ============================================================================
  
  @123 @456
  Escenario: Test con tags numéricos simples
    Then veo el elemento "Home"
    # Soporta: @123 (solo número)
  
  @US-789 @BUG-101
  Escenario: Test con diferentes prefijos
    Then veo el elemento "Home"
    # Soporta: @US-789, @BUG-101, @TASK-456, etc.

  # ============================================================================
  # EJEMPLO 6: Test sin tags (No se actualiza Azure DevOps)
  # ============================================================================
  
  Escenario: Test exploratorio sin integración
    When navego a "https://example.com/about"
    Then veo el elemento "About Us"
    
    # Sin tags = No se actualiza Azure DevOps
    # Útil para tests exploratorios o en desarrollo

  # ============================================================================
  # EJEMPLO 7: Test con @no_browser (API Testing)
  # ============================================================================
  
  @TC-1239 @TASK-5681 @no_browser
  Escenario: Validar API de usuarios
    When realizo una petición GET a "https://api.example.com/users"
    Then el código de respuesta debe ser 200
    And el JSON de respuesta debe contener la clave "users"
    
    # Funciona con @no_browser para tests de API
    # ✅ Test Case 1239 actualizado
    # ✅ Reporte adjuntado a Task 5681

  # ============================================================================
  # EJEMPLO 8: Test con validación semántica
  # ============================================================================
  
  @TC-1240 @TASK-5682
  Escenario: Validar mensaje de bienvenida
    Given uso la configuración semántica por defecto
    When navego a "https://example.com/dashboard"
    And extraigo el texto del elemento "Welcome Message" y lo guardo en "mensaje"
    Then el texto de la variable "mensaje" debe ser semánticamente similar a "Bienvenido al sistema"
    
    # Combina validación semántica con Azure DevOps
    # ✅ Test Case 1240 actualizado
    # ✅ Reporte adjuntado a Task 5682

  # ============================================================================
  # EJEMPLO 9: Test con Gemini como Juez
  # ============================================================================
  
  @TC-1241 @TASK-5683 @no_browser
  Escenario: Validar respuesta de chatbot
    Given el contexto de reglas de negocio "support" está cargado desde el archivo "context/support_rules.txt"
    When establezco la respuesta del SUT como "Nuestro horario es de 9am a 6pm"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8
    
    # Combina Gemini Judge con Azure DevOps
    # ✅ Test Case 1241 actualizado
    # ✅ Reporte adjuntado a Task 5683
