#!/usr/bin/env python3
"""
Environment.py SIMPLIFICADO con Azure DevOps Plugin

Este es el environment.py más simple posible.
El plugin de Azure DevOps se activa automáticamente si AZURE_DEVOPS_ENABLED=true en .env

NO NECESITAS CÓDIGO ADICIONAL - Todo funciona automáticamente.
"""

# ============================================================================
# OPCIÓN 1: ULTRA SIMPLE (RECOMENDADO)
# ============================================================================
# Solo importa los hooks del framework y listo

from hakalab_framework.behave_plugin import (
    before_all,
    after_all,
    before_feature,
    after_feature,
    before_scenario,
    after_scenario,
    before_step,
    after_step
)
from hakalab_framework.steps import *

# ¡ESO ES TODO! 
# El plugin de Azure DevOps se activa automáticamente si está habilitado en .env


# ============================================================================
# OPCIÓN 2: CON PERSONALIZACIÓN (OPCIONAL)
# ============================================================================
# Si necesitas personalizar algo, puedes agregar funciones adicionales

# from hakalab_framework.behave_plugin import (
#     before_all as framework_before_all,
#     after_all as framework_after_all,
#     before_feature as framework_before_feature,
#     after_feature as framework_after_feature,
#     before_scenario as framework_before_scenario,
#     after_scenario as framework_after_scenario,
#     before_step as framework_before_step,
#     after_step as framework_after_step
# )
# from hakalab_framework.steps import *
# 
# def before_all(context):
#     """Personalización antes de todas las features"""
#     framework_before_all(context)
#     # Tu código personalizado aquí
#     # context.mi_variable = "valor"
# 
# def after_scenario(context, scenario):
#     """Personalización después de cada escenario"""
#     # Tu código personalizado aquí (ANTES del framework)
#     # if scenario.status == 'failed':
#     #     print(f"Test fallido: {scenario.name}")
#     
#     framework_after_scenario(context, scenario)
#     # El plugin de Azure DevOps se ejecuta automáticamente aquí


# ============================================================================
# OPCIÓN 3: PERSONALIZACIÓN AVANZADA DE AZURE DEVOPS (OPCIONAL)
# ============================================================================
# Si necesitas lógica muy específica para Azure DevOps

# from hakalab_framework.behave_plugin import (
#     before_all as framework_before_all,
#     after_scenario as framework_after_scenario
# )
# from hakalab_framework.steps import *
# 
# def before_all(context):
#     """Inicialización con personalización"""
#     framework_before_all(context)
#     
#     # Personalizar ruta de reporte por proyecto
#     if hasattr(context, 'azure_devops') and context.azure_devops.enabled:
#         context.azure_devops.config['report_path'] = 'custom/path/report.html'
# 
# def after_scenario(context, scenario):
#     """Personalización de Azure DevOps por escenario"""
#     
#     # Lógica personalizada ANTES de Azure DevOps
#     if hasattr(context, 'azure_devops') and context.azure_devops.enabled:
#         # Ejemplo: Solo actualizar Azure DevOps si el test tiene cierto tag
#         if 'critical' in [tag.lower() for tag in scenario.tags]:
#             # Cambiar el reporte para tests críticos
#             context.azure_devops.config['report_path'] = f'reports/critical/{scenario.name}.html'
#     
#     # Ejecutar el framework (incluye Azure DevOps plugin)
#     framework_after_scenario(context, scenario)


# ============================================================================
# CONFIGURACIÓN EN .ENV
# ============================================================================
# Para activar Azure DevOps, agrega esto a tu .env:
#
# AZURE_DEVOPS_ENABLED=true
# AZURE_DEVOPS_ORG=tu-organizacion
# AZURE_DEVOPS_PROJECT=tu-proyecto
# AZURE_DEVOPS_PAT=tu-personal-access-token
# AZURE_DEVOPS_STATUS_FIELD=Custom.TestStatus
# AZURE_DEVOPS_STATUS_PASSED=Passed
# AZURE_DEVOPS_STATUS_FAILED=Failed
# AZURE_DEVOPS_ATTACH_REPORT=true
# AZURE_DEVOPS_REPORT_PATH=reports/report.html


# ============================================================================
# USO EN FEATURES
# ============================================================================
# Usa tags en tus escenarios:
#
# @TC-1234 @TASK-5678
# Scenario: Mi test
#   Given ...
#   When ...
#   Then ...
#
# - Primer tag (@TC-1234): ID del Test Case a actualizar
# - Segundo tag (@TASK-5678): ID de la Task donde adjuntar reporte


# ============================================================================
# VENTAJAS DEL SISTEMA DE PLUGINS
# ============================================================================
# ✅ No necesitas código adicional en environment.py
# ✅ Se activa/desactiva solo con variables de entorno
# ✅ No interfiere con otros plugins (Jira/Xray, HTML Report, etc.)
# ✅ Fácil de mantener y actualizar
# ✅ Cada proyecto puede tener su propia configuración en .env
