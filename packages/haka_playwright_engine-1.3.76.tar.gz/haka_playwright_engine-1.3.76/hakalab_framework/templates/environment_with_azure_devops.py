#!/usr/bin/env python3
"""
Template de environment.py con integración de Azure DevOps

Este template muestra cómo integrar Azure DevOps Manager en tu proyecto.
Puedes personalizar la lógica según tus necesidades.
"""

from hakalab_framework.core.environment_config import (
    setup_framework_context,
    setup_scenario_context,
    cleanup_scenario_context
)
from hakalab_framework.core.azure_devops_manager import (
    setup_azure_devops,
    process_scenario_azure_devops
)


def before_all(context):
    """
    Configuración inicial del framework + Azure DevOps
    """
    # Configurar framework básico
    setup_framework_context(context)
    
    # Configurar Azure DevOps
    setup_azure_devops(context)
    
    # Personalización adicional (opcional)
    # context.custom_report_path = "custom/path/report.html"


def before_scenario(context, scenario):
    """
    Configuración antes de cada escenario
    """
    setup_scenario_context(context, scenario)


def after_scenario(context, scenario):
    """
    Limpieza después de cada escenario + Actualización de Azure DevOps
    """
    # Procesar Azure DevOps automáticamente
    process_scenario_azure_devops(context, scenario)
    
    # Limpieza del framework
    cleanup_scenario_context(context, scenario)


# ============================================================================
# PERSONALIZACIÓN AVANZADA (OPCIONAL)
# ============================================================================

def after_scenario_custom(context, scenario):
    """
    Ejemplo de personalización avanzada de la integración con Azure DevOps
    
    Usa esto si necesitas:
    - Lógica personalizada para determinar el estado
    - Rutas de reporte dinámicas
    - Procesamiento condicional
    - Múltiples reportes
    """
    if not hasattr(context, 'azure_devops') or not context.azure_devops.enabled:
        return
    
    # === PERSONALIZACIÓN 1: Estado personalizado ===
    # Puedes tener lógica más compleja para determinar el estado
    if scenario.status == 'failed':
        status = 'Failed'
    elif scenario.status == 'skipped':
        status = 'Skipped'  # Si tienes un estado "Skipped" en Azure DevOps
    else:
        status = 'Passed'
    
    # === PERSONALIZACIÓN 2: Ruta de reporte dinámica ===
    # Puedes generar rutas de reporte específicas por escenario
    report_path = f"reports/{scenario.feature.name}/{scenario.name}.html"
    
    # === PERSONALIZACIÓN 3: Procesamiento condicional ===
    # Solo procesar ciertos escenarios
    if 'azure' in [tag.lower() for tag in scenario.tags]:
        results = context.azure_devops.process_scenario_tags(
            scenario,
            status,
            report_path
        )
    
    # === PERSONALIZACIÓN 4: Adjuntar múltiples archivos ===
    # Si necesitas adjuntar varios archivos
    if len(scenario.tags) >= 2:
        task_id = context.azure_devops._extract_work_item_id(scenario.tags[1])
        if task_id:
            # Adjuntar reporte HTML
            context.azure_devops.attach_file_to_work_item(
                task_id,
                "reports/report.html",
                "Reporte HTML"
            )
            # Adjuntar screenshots
            context.azure_devops.attach_file_to_work_item(
                task_id,
                "screenshots/screenshot.png",
                "Screenshot del test"
            )
            # Adjuntar logs
            context.azure_devops.attach_file_to_work_item(
                task_id,
                "logs/test.log",
                "Logs de ejecución"
            )


# ============================================================================
# EJEMPLO: INTEGRACIÓN CON REPORTES HTML
# ============================================================================

def after_feature_with_report(context, feature):
    """
    Ejemplo de cómo adjuntar un reporte HTML generado después de cada feature
    """
    if not hasattr(context, 'azure_devops') or not context.azure_devops.enabled:
        return
    
    # Generar reporte HTML (ejemplo)
    report_path = f"reports/{feature.name}_report.html"
    
    # Adjuntar a todas las tasks mencionadas en los escenarios de esta feature
    task_ids = set()
    for scenario in feature.scenarios:
        if len(scenario.tags) >= 2:
            task_id = context.azure_devops._extract_work_item_id(scenario.tags[1])
            if task_id:
                task_ids.add(task_id)
    
    # Adjuntar el reporte a cada task única
    for task_id in task_ids:
        context.azure_devops.attach_file_to_work_item(
            task_id,
            report_path,
            f"Reporte de feature: {feature.name}"
        )


# ============================================================================
# EJEMPLO: VALIDACIÓN DE TAGS
# ============================================================================

def before_scenario_validate_tags(context, scenario):
    """
    Valida que los escenarios tengan los tags correctos para Azure DevOps
    """
    if not hasattr(context, 'azure_devops') or not context.azure_devops.enabled:
        return
    
    # Verificar que el escenario tenga al menos un tag
    if not hasattr(scenario, 'tags') or len(scenario.tags) == 0:
        context.azure_devops.logger.warning(
            f"⚠️ Escenario '{scenario.name}' no tiene tags. "
            "No se actualizará Azure DevOps."
        )
        return
    
    # Verificar formato de tags
    test_case_id = context.azure_devops._extract_work_item_id(scenario.tags[0])
    if not test_case_id:
        context.azure_devops.logger.warning(
            f"⚠️ Primer tag '{scenario.tags[0]}' no contiene un ID válido"
        )
    
    if len(scenario.tags) >= 2:
        task_id = context.azure_devops._extract_work_item_id(scenario.tags[1])
        if not task_id:
            context.azure_devops.logger.warning(
                f"⚠️ Segundo tag '{scenario.tags[1]}' no contiene un ID válido"
            )
