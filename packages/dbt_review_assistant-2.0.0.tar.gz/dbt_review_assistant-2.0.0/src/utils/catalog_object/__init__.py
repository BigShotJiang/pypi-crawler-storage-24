"""Classes representing catalog objects."""
