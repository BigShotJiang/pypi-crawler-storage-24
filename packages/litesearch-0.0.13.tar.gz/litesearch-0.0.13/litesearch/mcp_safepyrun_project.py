"""Project-specific safepyrun MCP server.

Extends the base safepyrun MCP server with litesearch project packages
pre-loaded into the sandbox globals, so they're usable without import statements.
"""
from __future__ import annotations
import json
import sys

try:
    from mcp.server.fastmcp import FastMCP
    HAS_MCP = True
except ImportError:
    HAS_MCP = False

try:
    from safepyrun import RunPython, allow
    HAS_SAFEPYRUN = True
except ImportError:
    HAS_SAFEPYRUN = False

_runner: 'RunPython | None' = None


def _build_globals() -> dict:
    """Pre-import project packages into globals dict for the sandbox."""
    g: dict = {}
    try:
        import numpy as np
        import fastlite
        import litesearch
        from litesearch import database
        from litesearch.utils import FastEncode
        from litesearch.data import pyparse, pkg2chunks, pre
        from apswutils.db import Database

        g.update({
            'litesearch': litesearch,
            'database': database,
            'FastEncode': FastEncode,
            'pyparse': pyparse,
            'pkg2chunks': pkg2chunks,
            'pre': pre,
            'fastlite': fastlite,
            'np': np,
            'numpy': np,
        })

        # Register callables with safepyrun's allowlist
        allow(
            {Database: [m for m in dir(Database) if not m.startswith('_')]},
            {FastEncode: ['encode', 'encode_query', 'encode_document']},
            'database', 'pyparse', 'pkg2chunks', 'pre',
        )
    except Exception as e:
        print(f'Warning: could not load project packages: {e}', file=sys.stderr)
    return g


def get_runner() -> 'RunPython':
    global _runner
    if _runner is None:
        if not HAS_SAFEPYRUN:
            raise ImportError('safepyrun not installed. Run: uv add --group dev safepyrun')
        _runner = RunPython(g=_build_globals())
    return _runner


def create_server() -> 'FastMCP':
    mcp = FastMCP('safepyrun')

    @mcp.tool()
    async def run_python(code: str) -> str:
        """Execute Python code in a safepyrun sandbox with litesearch project packages
        pre-loaded. litesearch, FastEncode, database, pyparse, pkg2chunks, pre, numpy,
        fastlite are available directly — no import needed. Variables ending with _
        are exported to session namespace for reuse across calls.
        """
        try:
            runner = get_runner()
            result = await runner(code)
            return json.dumps({
                'success': True,
                'stdout': result.stdout if hasattr(result, 'stdout') else str(result),
                'stderr': result.stderr if hasattr(result, 'stderr') else '',
                'result': result.result if hasattr(result, 'result') else None,
            }, indent=2)
        except ImportError as e:
            return json.dumps({'success': False, 'error': str(e)}, indent=2)
        except Exception as e:
            return json.dumps({'success': False, 'error': f'{type(e).__name__}: {e}'}, indent=2)

    @mcp.tool()
    def reset_sandbox() -> str:
        """Reset the Python sandbox, clearing all session state and re-loading project packages."""
        global _runner
        _runner = None
        return json.dumps({'success': True, 'message': 'Sandbox reset'}, indent=2)

    return mcp


def main():
    if not HAS_MCP:
        print('mcp package not installed. Run: uv add mcp', file=sys.stderr)
        sys.exit(1)
    mcp = create_server()
    mcp.run()


if __name__ == '__main__':
    main()