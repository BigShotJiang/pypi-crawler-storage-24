# FELLO-Engine

A Python-based 3D game engine with clean, readable naming conventions.

## Features

- **GameObject System**: Entity-based game object management
- **Script System**: Dynamic script loading with start/update/finish lifecycle
- **Window Management**: Simple window handling with title and size control
- **Clean Architecture**: Readable class and function names

## Quick Start

1. Install the engine:
   ```bash
   setup.bat
   ```

2. Create a game object:
   ```python
   from Object import GameObject, RegisterGameObject
   
   player = GameObject("Player")
   RegisterGameObject(player)
   ```

3. Add a script:
   ```python
   player.add_script("path/to/script.py")
   ```

4. Run the engine:
   ```python
   from runtime import run
   run()
   ```

## Script Structure

Scripts should follow this structure:

```python
def start():
    # Called when the program starts, before window creation
    pass

def update():
    # Called every frame before window update
    pass

def finish():
    # Called when the program ends, before window closes
    pass
```

## API Reference

### GameObject

- `GameObject(object_name)`: Create a new game object
- `set_model(model)`: Set the object's model
- `add_script(script_path)`: Attach a script to the object
- `set_texture(texture)`: Set the object's texture
- `set_visible(visible)`: Set object visibility

### Window

- `set_title(title)`: Set window title
- `get_title()`: Get window title
- `set_size(width, height)`: Set window size
- `get_size()`: Get window size
- `update()`: Update window state
- `close()`: Close the window

### Utility Functions

- `GetObject(object_name)`: Retrieve a game object by name
- `RegisterGameObject(game_object)`: Register a game object

## Installation

To install for development:
```bash
pip install -e .
```

To install from PyPI (when published):
```bash
pip install fello-engine
```
