"""
Kinetic Cipher v1.1 — Dual Physics Stream Cipher

A novel symmetric encryption scheme using two independent physics
simulations as keystream generators:
  - Skeleton layer: Elastic collision of 14 particles on a 1D ring
  - Armor layer: Fermi-Pasta-Ulam nonlinear lattice with 32 nodes

Security: PBKDF2-SHA256 KDF, HMAC-SHA256 Encrypt-then-MAC, SHA-256 PRF
Quantum: Post-Grover 2^173 (skeleton) + 2^512 (armor)

v1.1 changes:
  - Keystream extraction: FNV-1a → SHA-256 (cryptographic hash)
  - IV: 8 bytes → 16 bytes (128-bit, birthday-attack resistant)
  - Block feedback: FNV-1a → SHA-256

⚠ EDUCATIONAL / EXPERIMENTAL — No formal security proof.
   For production use, prefer AES-256-GCM.
"""

__version__ = "1.1.0"
__all__ = ["encrypt", "decrypt", "encrypt_file", "decrypt_file"]

import hashlib
import hmac
import os
import struct

# ── Constants ──────────────────────────────────────────────
CC_RING = 16384
CC_NP = 14
CC_VMAX = 120
CC_CD = 8
WARMUP = 64
LS_N = 32
LS_K1 = 7
LS_K3 = 3
BLOCK = 64
KDF_ITER = 100_000
VERSION = 0x06
HMAC_LEN = 32
SALT_LEN = 16
IV_LEN = 16
HEADER_LEN = 1 + SALT_LEN + IV_LEN


# ── Utilities ──────────────────────────────────────────────
def _clamp(v):
    v = max(-CC_VMAX, min(CC_VMAX, v))
    return v if v != 0 else 1

def _sha(data: bytes, n: int = 16) -> bytes:
    return hashlib.sha256(data).digest()[:n]

def _cc_state_bytes(ps) -> bytes:
    return b"".join(struct.pack("<ihB", p.pos, p.vel, p.mass) for p in ps)

def _ls_state_bytes(ls) -> bytes:
    return b"".join(struct.pack("<HH", ls.x[i] & 0xFFFF, ls.v[i] & 0xFFFF) for i in range(LS_N))


# ── Collision Cipher (Skeleton) ────────────────────────────
class _Particle:
    __slots__ = ("pos", "vel", "mass")
    def __init__(self, pos, vel, mass):
        self.pos = pos
        self.vel = vel
        self.mass = mass

def _h32(ps):
    return struct.unpack("<I", _sha(_cc_state_bytes(ps), 4))[0]

def _pump(ps, step):
    h = struct.unpack("<I", _sha(_cc_state_bytes(ps) + struct.pack("<I", step), 4))[0]
    idx = h % len(ps)
    sign = 1 - 2 * ((h >> 8) & 1)
    mag = ((h >> 12) % 11) + 3
    ps[idx].vel = _clamp(ps[idx].vel + sign * mag)

def _cc_step(ps, n):
    for p in ps:
        p.pos = (p.pos + p.vel) % CC_RING
    for i in range(len(ps)):
        for j in range(i + 1, len(ps)):
            d = abs(ps[i].pos - ps[j].pos)
            if min(d, CC_RING - d) < CC_CD:
                m1, m2 = ps[i].mass, ps[j].mass
                M = m1 + m2
                v1, v2 = ps[i].vel, ps[j].vel
                ps[i].vel = _clamp(round(((m1 - m2) * v1 + 2 * m2 * v2) / M))
                ps[j].vel = _clamp(round(((m2 - m1) * v2 + 2 * m1 * v1) / M))
                if ps[i].mass > 2 and ps[j].mass < 8:
                    ps[i].mass -= 1
                    ps[j].mass += 1
                ps[j].pos = (ps[j].pos + CC_CD + 2) % CC_RING
    if n % 4 == 0:
        _pump(ps, n)

def _cc_init(key, iv):
    ps = []
    for i in range(CC_NP):
        b = i * 4
        base = ((key[b] << 8) | key[b + 1]) % CC_RING
        rv = (key[b + 2] % (CC_VMAX * 2 + 1)) - CC_VMAX
        m = (key[b + 3] % 7) + 2
        iv_off = ((iv[i % len(iv)] << 4) | (iv[(i + 3) % len(iv)] >> 4)) % CC_RING
        ps.append(_Particle((base + iv_off) % CC_RING, _clamp(rv), m))
    for i in range(1, len(ps)):
        while any(min(abs(ps[i].pos - ps[j].pos),
                      CC_RING - abs(ps[i].pos - ps[j].pos)) < CC_CD + 2
                  for j in range(i)):
            ps[i].pos = (ps[i].pos + 37) % CC_RING
    return ps

def _cc_x16(ps):
    return _sha(_cc_state_bytes(ps), 16)


# ── Lattice Spring Cipher (Armor) ─────────────────────────
class _LS:
    __slots__ = ("x", "v")
    def __init__(self, seed):
        self.x = [0] * LS_N
        self.v = [0] * LS_N
        for i in range(LS_N):
            self.x[i] = ((seed[i % len(seed)] << 8) | seed[(i + 7) % len(seed)]) & 0xFFFF
            self.v[i] = ((seed[(i + 3) % len(seed)] << 4) ^ seed[(i + 11) % len(seed)]) & 0xFFFF

    def step(self):
        x, v = self.x, self.v
        new_v = [0] * LS_N
        for i in range(LS_N):
            l = x[(i + LS_N - 1) % LS_N]
            r = x[(i + 1) % LS_N]
            dl = (x[i] - l) & 0xFFFF
            dr = (x[i] - r) & 0xFFFF
            sl = dl - 65536 if dl > 32767 else dl
            sr = dr - 65536 if dr > 32767 else dr
            cl = ((sl * sl) & 0xFFFF) * sl >> 16
            cr = ((sr * sr) & 0xFFFF) * sr >> 16
            new_v[i] = (v[i] - LS_K1 * (sl + sr) - LS_K3 * (cl + cr) - (v[i] >> 8)) & 0xFFFF
        self.v = new_v
        for i in range(LS_N):
            x[i] = (x[i] + self.v[i]) & 0xFFFF

    def extract16(self):
        return _sha(_ls_state_bytes(self), 16)


# ── Block Feedback (SHA-256) ──────────────────────────────
def _block_feedback(ps, cipher_block, step_num):
    fb = hashlib.sha256(bytes(cipher_block) + struct.pack("<I", step_num)).digest()
    for k in range(4):
        pi = (step_num * 4 + k) % CC_NP
        bk = fb[k]
        ps[pi].vel = _clamp(ps[pi].vel + ((bk & 31) - 15))
        ps[pi].pos = (ps[pi].pos + ((bk >> 5) & 7)) % CC_RING


# ── Core Cipher Pipeline ──────────────────────────────────
def _derive_keys(passphrase: str, salt: bytes) -> tuple:
    raw = hashlib.pbkdf2_hmac("sha256", passphrase.encode("utf-8"), salt, KDF_ITER, dklen=104)
    return raw[:56], raw[56:]

def _cipher_core(data: bytearray, cc_key: bytes, ls_key: bytes, iv: bytes, is_decrypt: bool):
    ps = _cc_init(cc_key, iv)
    for w in range(WARMUP):
        _cc_step(ps, w)

    cc_state = _cc_state_bytes(ps)
    ls_seed_hash = hashlib.sha256(cc_state + cc_key[:48]).digest()
    ls_seed = bytearray(48)
    for i in range(48):
        ls_seed[i] = ls_key[i % len(ls_key)] ^ ls_seed_hash[i % 32]
    ls = _LS(ls_seed)
    for _ in range(32):
        ls.step()

    st = WARMUP
    length = len(data)

    for bs in range(0, length, BLOCK):
        be = min(bs + BLOCK, length)
        bl = be - bs

        ks = bytearray(BLOCK)
        cc_ks = _cc_x16(ps)
        ks[:16] = cc_ks
        for e in range(3):
            ls.step()
            ls_ks = ls.extract16()
            ks[16 + e * 16:16 + (e + 1) * 16] = ls_ks

        if is_decrypt:
            saved = bytes(data[bs:be])
            for i in range(bl):
                data[bs + i] ^= ks[i]
            _block_feedback(ps, saved, st)
        else:
            for i in range(bl):
                data[bs + i] ^= ks[i]
            _block_feedback(ps, data[bs:be], st)

        _cc_step(ps, st)
        st += 1


# ── Public API ─────────────────────────────────────────────
def encrypt(plaintext: bytes, passphrase: str) -> bytes:
    """Encrypt bytes with a passphrase.

    Format: [version 1B][salt 16B][iv 16B][cipher NB][hmac 32B]
    """
    salt = os.urandom(SALT_LEN)
    iv = os.urandom(IV_LEN)
    cc_key, ls_key = _derive_keys(passphrase, salt)
    hmac_key = bytes(a ^ b for a, b in zip(cc_key[:32], ls_key[:32]))

    data = bytearray(plaintext)
    _cipher_core(data, cc_key, ls_key, iv, False)

    header = bytes([VERSION]) + salt + iv + bytes(data)
    mac = hmac.new(hmac_key, header, hashlib.sha256).digest()
    return header + mac


def decrypt(ciphertext: bytes, passphrase: str) -> bytes:
    """Decrypt bytes with a passphrase."""
    if len(ciphertext) < HEADER_LEN + HMAC_LEN:
        raise ValueError("Data too short")
    if ciphertext[0] != VERSION:
        raise ValueError(f"Version mismatch (expected 0x{VERSION:02x}, got 0x{ciphertext[0]:02x})")

    salt = ciphertext[1:1 + SALT_LEN]
    iv = ciphertext[1 + SALT_LEN:1 + SALT_LEN + IV_LEN]
    cipher_data = ciphertext[HEADER_LEN:-HMAC_LEN]
    stored_mac = ciphertext[-HMAC_LEN:]

    cc_key, ls_key = _derive_keys(passphrase, salt)
    hmac_key = bytes(a ^ b for a, b in zip(cc_key[:32], ls_key[:32]))

    header = ciphertext[:-HMAC_LEN]
    expected_mac = hmac.new(hmac_key, header, hashlib.sha256).digest()
    if not hmac.compare_digest(stored_mac, expected_mac):
        raise ValueError("HMAC verification failed — wrong passphrase or tampered data")

    data = bytearray(cipher_data)
    _cipher_core(data, cc_key, ls_key, iv, True)
    return bytes(data)


def encrypt_file(input_path: str, output_path: str, passphrase: str) -> int:
    """Encrypt a file. Original filename is preserved."""
    with open(input_path, "rb") as f:
        plaintext = f.read()
    name = os.path.basename(input_path).encode("utf-8")
    payload = struct.pack("<H", len(name)) + name + plaintext
    enc = encrypt(payload, passphrase)
    with open(output_path, "wb") as f:
        f.write(enc)
    return len(enc)


def decrypt_file(input_path: str, output_dir: str, passphrase: str) -> str:
    """Decrypt a file. Original filename is restored."""
    with open(input_path, "rb") as f:
        ciphertext = f.read()
    payload = decrypt(ciphertext, passphrase)
    name_len = struct.unpack("<H", payload[:2])[0]
    name = payload[2:2 + name_len].decode("utf-8")
    data = payload[2 + name_len:]
    os.makedirs(output_dir, exist_ok=True)
    out_path = os.path.join(output_dir, name)
    with open(out_path, "wb") as f:
        f.write(data)
    return out_path
