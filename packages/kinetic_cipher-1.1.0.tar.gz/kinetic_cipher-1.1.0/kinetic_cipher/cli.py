"""Kinetic Cipher CLI — encrypt and decrypt from the terminal."""

import argparse
import getpass
import os
import sys
import time

from . import encrypt, decrypt, encrypt_file, decrypt_file, __version__


def main():
    parser = argparse.ArgumentParser(
        prog="kinetic-cipher",
        description="Kinetic Cipher v{} — Dual Physics Stream Cipher".format(__version__),
        epilog="⚠ Educational / experimental. For production, use AES-256-GCM.",
    )
    parser.add_argument("--version", action="version", version=f"kinetic-cipher {__version__}")

    sub = parser.add_subparsers(dest="command", help="Command")

    # encrypt
    enc = sub.add_parser("enc", help="Encrypt a file or text")
    enc.add_argument("input", nargs="?", help="Input file (omit for stdin text mode)")
    enc.add_argument("-o", "--output", help="Output file (default: <input>.kc)")
    enc.add_argument("-t", "--text", help="Encrypt text directly")

    # decrypt
    dec = sub.add_parser("dec", help="Decrypt a file or hex text")
    dec.add_argument("input", nargs="?", help="Input .kc file (omit for stdin hex mode)")
    dec.add_argument("-o", "--output", help="Output directory (default: current dir)")
    dec.add_argument("-t", "--text", help="Decrypt hex string directly")

    # bench
    sub.add_parser("bench", help="Run a quick benchmark")

    # test
    sub.add_parser("test", help="Run self-test")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return

    if args.command == "bench":
        _benchmark()
        return

    if args.command == "test":
        _selftest()
        return

    pw = getpass.getpass("Passphrase: ")
    if not pw:
        print("Error: passphrase cannot be empty", file=sys.stderr)
        sys.exit(1)

    if args.command == "enc":
        if args.text:
            enc_bytes = encrypt(args.text.encode("utf-8"), pw)
            print(enc_bytes.hex())
        elif args.input:
            out = args.output or args.input + ".kc"
            t0 = time.time()
            size = encrypt_file(args.input, out, pw)
            elapsed = time.time() - t0
            print(f"✓ Encrypted → {out} ({size:,} bytes, {elapsed:.1f}s)")
        else:
            print("Reading from stdin (Ctrl+D to end)...", file=sys.stderr)
            data = sys.stdin.buffer.read()
            enc_bytes = encrypt(data, pw)
            print(enc_bytes.hex())

    elif args.command == "dec":
        if args.text:
            try:
                raw = bytes.fromhex(args.text)
                result = decrypt(raw, pw)
                sys.stdout.buffer.write(result)
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                sys.exit(1)
        elif args.input:
            out_dir = args.output or "."
            try:
                t0 = time.time()
                path = decrypt_file(args.input, out_dir, pw)
                elapsed = time.time() - t0
                print(f"✓ Decrypted → {path} ({elapsed:.1f}s)")
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                sys.exit(1)
        else:
            print("Paste hex ciphertext (Ctrl+D to end):", file=sys.stderr)
            hex_str = sys.stdin.read().strip()
            try:
                raw = bytes.fromhex(hex_str)
                result = decrypt(raw, pw)
                sys.stdout.buffer.write(result)
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                sys.exit(1)


def _benchmark():
    print(f"Kinetic Cipher v{__version__} — Benchmark\n")
    sizes = [1024, 10240, 102400, 1048576]
    pw = "benchmark-key-2024"
    for sz in sizes:
        data = os.urandom(sz)
        t0 = time.time()
        enc = encrypt(data, pw)
        t_enc = time.time() - t0
        t1 = time.time()
        dec = decrypt(enc, pw)
        t_dec = time.time() - t1
        ok = dec == data
        label = f"{sz/1024:.0f}KB" if sz < 1048576 else f"{sz/1048576:.0f}MB"
        mbps = (sz / 1048576) / t_enc if t_enc > 0 else 0
        print(f"  {label:>6}: enc {t_enc:.2f}s  dec {t_dec:.2f}s  {mbps:.1f} MB/s  {'✓' if ok else '✗'}")


def _selftest():
    print(f"Kinetic Cipher v{__version__} — Self-Test\n")
    pw = "test-passphrase"
    passed = 0
    total = 0

    for sz in [0, 1, 15, 16, 17, 63, 64, 65, 255, 256, 1000, 4096]:
        total += 1
        data = bytes([i & 0xFF for i in range(sz)])
        try:
            enc = encrypt(data, pw)
            dec = decrypt(enc, pw)
            if dec == data:
                passed += 1
            else:
                print(f"  ✗ size={sz}: decrypt mismatch")
        except Exception as e:
            print(f"  ✗ size={sz}: {e}")

    # Wrong key test
    total += 1
    try:
        enc = encrypt(b"secret", pw)
        decrypt(enc, "wrong-key")
        print("  ✗ wrong key: should have raised ValueError")
    except ValueError:
        passed += 1

    # Tamper test
    total += 1
    try:
        enc = bytearray(encrypt(b"secret", pw))
        enc[30] ^= 0xFF
        decrypt(bytes(enc), pw)
        print("  ✗ tamper: should have raised ValueError")
    except ValueError:
        passed += 1

    print(f"  {passed}/{total} tests passed {'✓' if passed == total else '✗'}")


if __name__ == "__main__":
    main()
