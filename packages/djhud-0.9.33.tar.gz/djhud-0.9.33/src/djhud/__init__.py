"""DJ HUD — Lightweight screen/webcam region capture and virtual camera tool for DJs."""

__version__ = "0.9.33"
APP_NAME = "DJ HUD Builder"
