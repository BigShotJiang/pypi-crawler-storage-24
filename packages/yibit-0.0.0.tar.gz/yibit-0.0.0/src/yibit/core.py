from typing import Optional

from argparse import ArgumentParser
import asyncio
from asyncio import StreamReader, StreamWriter
from dataclasses import dataclass

from ._meta import package, version


@dataclass
class HTTPResponse:
    status_code: int
    status_text: str
    headers: dict[str, str]
    body: bytes

    def text(self, encoding: str = "utf-8") -> str:
        return self.body.decode(encoding)

    def json(self) -> dict:
        import json

        return json.loads(self.text())


class HttpStreamClient:

    def __init__(self, user_agent: str = f"{package}/{version}") -> None:
        self._user_agent = user_agent

    async def request(
        self,
        reader: StreamReader,
        writer: StreamWriter,
        host: str,
        path: str = "/",
        method: str = "GET",
        headers: Optional[dict[str, str]] = None,
        body: Optional[bytes] = None,
    ) -> HTTPResponse:

        request_headers = {
            "Host": host,
            "Connection": "close",
            "User-Agent": self._user_agent,
        }
        if headers:
            request_headers.update(headers)
        if body:
            request_headers["Content-Length"] = str(len(body))

        request_line = f"{method} {path} HTTP/1.1\r\n"
        header_lines = "".join(f"{k}: {v}\r\n" for k, v in request_headers.items())
        request = request_line + header_lines + "\r\n"
        if body:
            request = request.encode() + body
        else:
            request = request.encode()

        writer.write(request)
        await writer.drain()

        response = await self._read_response(reader)
        return response

    async def _read_response(self, reader: asyncio.StreamReader) -> HTTPResponse:
        status_line = await reader.readline()
        if not status_line:
            raise Exception("Empty response")
        status_line = status_line.decode().strip()

        parts = status_line.split(" ", 2)
        if len(parts) < 2:
            raise Exception(f"Invalid status line: {status_line}")
        status_code = int(parts[1])
        status_text = parts[2] if len(parts) > 2 else ""

        headers = {}
        while True:
            line = await reader.readline()
            if line == b"\r\n" or line == b"":
                break
            line = line.decode().strip()
            if ":" in line:
                key, value = line.split(":", 1)
                headers[key.strip().lower()] = value.strip()

        body = await self._read_body(reader, headers, status_code)

        return HTTPResponse(status_code, status_text, headers, body)

    async def _read_body(
        self, reader: asyncio.StreamReader, headers: dict[str, str], status_code: int
    ) -> bytes:
        if status_code in (204, 304) or headers.get("content-length") == "0":
            return b""

        if headers.get("transfer-encoding") == "chunked":
            return await self._read_chunked(reader)

        # Content-Length
        content_length = headers.get("content-length")
        if content_length:
            length = int(content_length)
            return await reader.readexactly(length)
        return await reader.read()

    async def _read_chunked(self, reader: asyncio.StreamReader) -> bytes:
        body = b""
        while True:
            chunk_size_line = await reader.readline()
            if not chunk_size_line:
                break
            chunk_size = int(chunk_size_line.strip().decode().split(";")[0], 16)
            if chunk_size == 0:
                await reader.readline()  # read blank line at the end
                break
            chunk = await reader.readexactly(chunk_size)
            body += chunk
            await reader.readline()  # read CRLF
        return body


async def _main():
    parser = ArgumentParser()
    parser.add_argument("host")
    parser.add_argument("--path", type=str, default="/")
    parser.add_argument("--port", type=int, default=80)
    parser.add_argument("--timeout", type=float, default=30.0)
    args = parser.parse_args()

    print(f"{package}/{version}")

    # TODO: DNS override
    # TODO: local address, port
    # TODO: connection counting
    # TODO: connection reusing
    # TODO: proxy support
    # TODO: keep alive
    reader, writer = await asyncio.wait_for(
        asyncio.open_connection(args.host, args.port), timeout=args.timeout
    )
    client = HttpStreamClient()
    resp = await client.request(reader, writer, args.host, args.path, method="GET")
    print(resp)
    writer.close()
    await writer.wait_closed()


if __name__ == "__main__":
    asyncio.run(_main())
