if __package__ is None:
    raise ImportError("__package__ is None")

package = __package__
from importlib.metadata import version as getversion

version = getversion(__package__)
