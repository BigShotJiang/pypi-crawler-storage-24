"""CRDT document converter for cross-platform transformation.

This module provides the DocumentConverter class and top-level convenience
functions for converting parsed CRDT documents between platform formats.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pycrdt import Doc

from marqetive.utils.crdt.builders.bluesky import BlueskyCRDTBuilder
from marqetive.utils.crdt.builders.instagram import InstagramCRDTBuilder
from marqetive.utils.crdt.builders.linkedin import LinkedInCRDTBuilder
from marqetive.utils.crdt.builders.threads import ThreadsCRDTBuilder
from marqetive.utils.crdt.builders.tiktok import TikTokCRDTBuilder
from marqetive.utils.crdt.builders.twitter import TwitterCRDTBuilder
from marqetive.utils.crdt.exceptions import CRDTConversionError
from marqetive.utils.crdt.models import (
    BlueSkyCardContent,
    ContentType,
    ConversionExtras,
    ConversionResult,
    ConversionWarning,
    InstagramPostContent,
    LinkedInPostContent,
    ParsedBlueSkyDocument,
    ParsedDocument,
    ParsedInstagramDocument,
    ParsedLinkedInDocument,
    ParsedThreadsDocument,
    ParsedTikTokDocument,
    ParsedTwitterDocument,
    Platform,
    PostVisibility,
    ThreadsCardContent,
    TikTokPostContent,
    TwitterCardContent,
)
from marqetive.utils.crdt.parser import parse_crdt_binary


def _deduplicate_ordered(items: list[str]) -> list[str]:
    """Deduplicate a list while preserving order."""
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


_PLATFORM_MEDIA_LIMITS: dict[Platform, int] = {
    Platform.TWITTER: 4,
    Platform.BLUESKY: 4,
    Platform.LINKEDIN: 9,
    Platform.INSTAGRAM: 10,
    Platform.TIKTOK: 1,
    Platform.THREADS: 20,
}


def _trim_media(
    media: list[str],
    target: Platform,
    warnings: list[ConversionWarning],
) -> list[str]:
    """Trim media list to platform limit, appending a warning if trimmed."""
    limit = _PLATFORM_MEDIA_LIMITS.get(target)
    if limit is not None and len(media) > limit:
        warnings.append(
            ConversionWarning(
                code="media_trimmed",
                field="media",
                message=(
                    f"Media trimmed from {len(media)} to {limit} "
                    f"(max for {target.value})"
                ),
            )
        )
        return media[:limit]
    return media


class DocumentConverter:
    """Converts parsed CRDT documents between platform formats."""

    def convert(
        self,
        source: ParsedDocument,
        target_platform: Platform | str,
    ) -> ConversionResult:
        """Convert a parsed document to another platform format.

        Args:
            source: The parsed source document.
            target_platform: Target platform name or enum.

        Returns:
            ConversionResult containing the converted document, warnings, and extras.

        Raises:
            CRDTConversionError: If conversion fails or same-platform conversion.
        """
        if isinstance(target_platform, str):
            target_platform = Platform(target_platform.lower())

        source_platform = self._detect_source_platform(source)

        if source_platform == target_platform:
            raise CRDTConversionError(
                f"Cannot convert {source_platform.value} to itself",
                source_platform=source_platform.value,
                target_platform=target_platform.value,
            )

        method_name = f"_{source_platform.value}_to_{target_platform.value}"
        method = getattr(self, method_name, None)
        if method is None:
            raise CRDTConversionError(
                f"No conversion path from {source_platform.value} to {target_platform.value}",
                source_platform=source_platform.value,
                target_platform=target_platform.value,
            )

        return method(source)

    def _detect_source_platform(self, source: ParsedDocument) -> Platform:
        """Detect the platform of a parsed document."""
        match source:
            case ParsedTwitterDocument():
                return Platform.TWITTER
            case ParsedLinkedInDocument():
                return Platform.LINKEDIN
            case ParsedInstagramDocument():
                return Platform.INSTAGRAM
            case ParsedTikTokDocument():
                return Platform.TIKTOK
            case ParsedBlueSkyDocument():
                return Platform.BLUESKY
            case ParsedThreadsDocument():
                return Platform.THREADS
            case _:
                raise CRDTConversionError("Unknown document type")

    def _extract_text_body(self, source: ParsedDocument) -> str:
        """Extract the main text content from any parsed document."""
        match source:
            case ParsedTwitterDocument(cards=cards):
                return "\n\n".join(card.text for card in cards if card.text)
            case ParsedLinkedInDocument(post=post):
                return post.text
            case ParsedInstagramDocument(post=post):
                return post.caption
            case ParsedTikTokDocument(post=post):
                return post.title
            case ParsedBlueSkyDocument(cards=cards):
                return "\n\n".join(card.text for card in cards if card.text)
            case ParsedThreadsDocument(cards=cards):
                return "\n\n".join(card.text for card in cards if card.text)

    def _extract_all_media(self, source: ParsedDocument) -> list[str]:
        """Extract all media URLs from any parsed document, deduplicated."""
        media: list[str] = []
        match source:
            case ParsedTwitterDocument(cards=cards):
                for card in cards:
                    media.extend(card.media)
            case ParsedLinkedInDocument(post=post):
                media = list(post.media)
            case ParsedInstagramDocument(post=post):
                media = list(post.media)
            case ParsedTikTokDocument(post=post):
                media = list(post.media)
            case ParsedBlueSkyDocument(cards=cards):
                for card in cards:
                    media.extend(card.media)
            case ParsedThreadsDocument(cards=cards):
                for card in cards:
                    media.extend(card.media)
        return _deduplicate_ordered(media)

    def _collect_extras(
        self,
        source: ParsedDocument,
        target: Platform,
    ) -> tuple[dict[str, Any], list[ConversionWarning]]:
        """Collect unmappable fields and generate field_dropped warnings."""
        extras: dict[str, Any] = {}
        warnings: list[ConversionWarning] = []
        source_platform = self._detect_source_platform(source)

        def _drop(field: str, value: Any) -> None:
            extras[field] = value
            warnings.append(
                ConversionWarning(
                    code="field_dropped",
                    field=field,
                    message=(
                        f"'{field}' from {source_platform.value} has no "
                        f"equivalent in {target.value}"
                    ),
                )
            )

        match source:
            case ParsedTwitterDocument(cards=cards, auto_number_config=anc):
                if target not in (Platform.TWITTER, Platform.BLUESKY, Platform.THREADS):
                    if anc is not None:
                        _drop("auto_number_config", anc.model_dump())
                    if len(cards) > 1:
                        _drop("thread_card_count", len(cards))
                if target != Platform.TWITTER:
                    # Carry quoted tweet data (platform-specific)
                    for i, card in enumerate(cards):
                        if card.is_quoted:
                            _drop(
                                f"card_{i}_quoted",
                                {
                                    "is_quoted": card.is_quoted,
                                    "quoted_card_id": card.quoted_card_id,
                                    "quoted_tweet_id": card.quoted_tweet_id,
                                },
                            )

            case ParsedLinkedInDocument(post=post, comment=comment):
                if target not in (Platform.LINKEDIN,):
                    if post.visibility != PostVisibility.PUBLIC:
                        _drop("visibility", post.visibility.value)
                    if post.pdf is not None:
                        _drop("pdf", post.pdf)
                    if comment is not None:
                        _drop("comment", comment.model_dump())

            case ParsedInstagramDocument(post=post):
                if target not in (Platform.INSTAGRAM,):
                    if post.location is not None and target not in (Platform.TIKTOK,):
                        _drop("location", post.location)
                    if post.music is not None and target not in (Platform.TIKTOK,):
                        _drop("music", post.music)
                    if post.content_type != ContentType.POST:
                        _drop("content_type", post.content_type.value)

            case ParsedTikTokDocument(post=post):
                if target not in (Platform.TIKTOK,):
                    if post.location is not None and target not in (
                        Platform.INSTAGRAM,
                    ):
                        _drop("location", post.location)
                    if post.music is not None and target not in (Platform.INSTAGRAM,):
                        _drop("music", post.music)

            case ParsedBlueSkyDocument(cards=cards, auto_number_config=anc):
                if target not in (Platform.TWITTER, Platform.BLUESKY, Platform.THREADS):
                    if anc is not None:
                        _drop("auto_number_config", anc.model_dump())
                    if len(cards) > 1:
                        _drop("thread_card_count", len(cards))
                if target not in (Platform.BLUESKY, Platform.THREADS):
                    # Carry og link card data (platform-specific)
                    for i, card in enumerate(cards):
                        if card.og is not None:
                            _drop(f"card_{i}_og", card.og)

            case ParsedThreadsDocument(cards=cards, auto_number_config=anc):
                if target not in (
                    Platform.TWITTER,
                    Platform.BLUESKY,
                    Platform.THREADS,
                ):
                    if anc is not None:
                        _drop("auto_number_config", anc.model_dump())
                    if len(cards) > 1:
                        _drop("thread_card_count", len(cards))
                if target not in (Platform.BLUESKY, Platform.THREADS):
                    # Carry og link card data (platform-specific)
                    for i, card in enumerate(cards):
                        if card.og is not None:
                            _drop(f"card_{i}_og", card.og)

        return extras, warnings

    def _make_result(
        self,
        document: ParsedDocument,
        source: ParsedDocument,
        target: Platform,
        extra_warnings: list[ConversionWarning] | None = None,
    ) -> ConversionResult:
        """Build a ConversionResult with extras and validation warnings."""
        source_platform = self._detect_source_platform(source)

        extras_dict, extras_warnings = self._collect_extras(source, target)

        all_warnings = (extra_warnings or []) + extras_warnings

        return ConversionResult(
            document=document,
            warnings=all_warnings,
            extras=ConversionExtras(
                source_platform=source_platform,
                source_fields=extras_dict,
            ),
            source_platform=source_platform,
            target_platform=target,
            converted_at=datetime.now(UTC),
        )

    # ==================== Twitter → Others ====================

    def _twitter_to_linkedin(self, source: ParsedTwitterDocument) -> ConversionResult:
        text = self._extract_text_body(source)
        media = self._extract_all_media(source)
        extra_warnings: list[ConversionWarning] = []

        if len(source.cards) > 1:
            extra_warnings.append(
                ConversionWarning(
                    code="thread_merged",
                    field="cards",
                    message=f"Merged {len(source.cards)} Twitter cards into single LinkedIn post",
                )
            )

        media = _trim_media(media, Platform.LINKEDIN, extra_warnings)

        doc = ParsedLinkedInDocument(
            post=LinkedInPostContent(text=text, media=media),
        )
        return self._make_result(doc, source, Platform.LINKEDIN, extra_warnings)

    def _twitter_to_instagram(self, source: ParsedTwitterDocument) -> ConversionResult:
        text = self._extract_text_body(source)
        media = self._extract_all_media(source)
        extra_warnings: list[ConversionWarning] = []

        if len(source.cards) > 1:
            extra_warnings.append(
                ConversionWarning(
                    code="thread_merged",
                    field="cards",
                    message=f"Merged {len(source.cards)} Twitter cards into single Instagram post",
                )
            )

        media = _trim_media(media, Platform.INSTAGRAM, extra_warnings)
        content_type = self._infer_instagram_content_type(media, extra_warnings)

        doc = ParsedInstagramDocument(
            post=InstagramPostContent(
                caption=text,
                media=media,
                content_type=content_type,
            ),
        )
        return self._make_result(doc, source, Platform.INSTAGRAM, extra_warnings)

    def _twitter_to_tiktok(self, source: ParsedTwitterDocument) -> ConversionResult:
        text = self._extract_text_body(source)
        media = self._extract_all_media(source)
        extra_warnings: list[ConversionWarning] = []

        if len(source.cards) > 1:
            extra_warnings.append(
                ConversionWarning(
                    code="thread_merged",
                    field="cards",
                    message=f"Merged {len(source.cards)} Twitter cards into single TikTok post",
                )
            )

        media = _trim_media(media, Platform.TIKTOK, extra_warnings)

        doc = ParsedTikTokDocument(
            post=TikTokPostContent(title=text, media=media),
        )
        return self._make_result(doc, source, Platform.TIKTOK, extra_warnings)

    # ==================== LinkedIn → Others ====================

    def _linkedin_to_twitter(self, source: ParsedLinkedInDocument) -> ConversionResult:
        text = source.post.text
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.TWITTER, extra_warnings)

        doc = ParsedTwitterDocument(
            cards=[TwitterCardContent(text=text, media=media)],
        )
        return self._make_result(doc, source, Platform.TWITTER, extra_warnings)

    def _linkedin_to_instagram(
        self, source: ParsedLinkedInDocument
    ) -> ConversionResult:
        text = source.post.text
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.INSTAGRAM, extra_warnings)
        content_type = self._infer_instagram_content_type(media, extra_warnings)

        doc = ParsedInstagramDocument(
            post=InstagramPostContent(
                caption=text,
                media=media,
                content_type=content_type,
            ),
        )
        return self._make_result(doc, source, Platform.INSTAGRAM, extra_warnings)

    def _linkedin_to_tiktok(self, source: ParsedLinkedInDocument) -> ConversionResult:
        text = source.post.text
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.TIKTOK, extra_warnings)

        doc = ParsedTikTokDocument(
            post=TikTokPostContent(title=text, media=media),
        )
        return self._make_result(doc, source, Platform.TIKTOK, extra_warnings)

    # ==================== Instagram → Others ====================

    def _instagram_to_twitter(
        self, source: ParsedInstagramDocument
    ) -> ConversionResult:
        text = source.post.caption
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.TWITTER, extra_warnings)

        doc = ParsedTwitterDocument(
            cards=[TwitterCardContent(text=text, media=media)],
        )
        return self._make_result(doc, source, Platform.TWITTER, extra_warnings)

    def _instagram_to_linkedin(
        self, source: ParsedInstagramDocument
    ) -> ConversionResult:
        text = source.post.caption
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.LINKEDIN, extra_warnings)

        doc = ParsedLinkedInDocument(
            post=LinkedInPostContent(text=text, media=media),
        )
        return self._make_result(doc, source, Platform.LINKEDIN, extra_warnings)

    def _instagram_to_tiktok(self, source: ParsedInstagramDocument) -> ConversionResult:
        text = source.post.caption
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.TIKTOK, extra_warnings)

        doc = ParsedTikTokDocument(
            post=TikTokPostContent(
                title=text,
                media=media,
                location=source.post.location,
                music=source.post.music,
            ),
        )
        return self._make_result(doc, source, Platform.TIKTOK, extra_warnings)

    # ==================== TikTok → Others ====================

    def _tiktok_to_twitter(self, source: ParsedTikTokDocument) -> ConversionResult:
        text = source.post.title
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.TWITTER, extra_warnings)

        doc = ParsedTwitterDocument(
            cards=[TwitterCardContent(text=text, media=media)],
        )
        return self._make_result(doc, source, Platform.TWITTER, extra_warnings)

    def _tiktok_to_linkedin(self, source: ParsedTikTokDocument) -> ConversionResult:
        text = source.post.title
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.LINKEDIN, extra_warnings)

        doc = ParsedLinkedInDocument(
            post=LinkedInPostContent(text=text, media=media),
        )
        return self._make_result(doc, source, Platform.LINKEDIN, extra_warnings)

    def _tiktok_to_instagram(self, source: ParsedTikTokDocument) -> ConversionResult:
        text = source.post.title
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.INSTAGRAM, extra_warnings)
        content_type = self._infer_instagram_content_type(media, extra_warnings)

        doc = ParsedInstagramDocument(
            post=InstagramPostContent(
                caption=text,
                media=media,
                content_type=content_type,
                location=source.post.location,
                music=source.post.music,
            ),
        )
        return self._make_result(doc, source, Platform.INSTAGRAM, extra_warnings)

    # ==================== Bluesky → Others ====================

    def _bluesky_to_twitter(self, source: ParsedBlueSkyDocument) -> ConversionResult:
        extra_warnings: list[ConversionWarning] = []
        cards = [
            TwitterCardContent(
                id=card.id,
                text=card.text,
                media=_trim_media(list(card.media), Platform.TWITTER, extra_warnings),
                auto_number=card.auto_number,
            )
            for card in source.cards
        ]
        doc = ParsedTwitterDocument(
            cards=cards,
            auto_number_config=source.auto_number_config,
        )
        return self._make_result(doc, source, Platform.TWITTER, extra_warnings)

    def _bluesky_to_linkedin(self, source: ParsedBlueSkyDocument) -> ConversionResult:
        text = self._extract_text_body(source)
        media = self._extract_all_media(source)
        extra_warnings: list[ConversionWarning] = []

        if len(source.cards) > 1:
            extra_warnings.append(
                ConversionWarning(
                    code="thread_merged",
                    field="cards",
                    message=f"Merged {len(source.cards)} Bluesky cards into single LinkedIn post",
                )
            )

        media = _trim_media(media, Platform.LINKEDIN, extra_warnings)

        doc = ParsedLinkedInDocument(
            post=LinkedInPostContent(text=text, media=media),
        )
        return self._make_result(doc, source, Platform.LINKEDIN, extra_warnings)

    def _bluesky_to_instagram(self, source: ParsedBlueSkyDocument) -> ConversionResult:
        text = self._extract_text_body(source)
        media = self._extract_all_media(source)
        extra_warnings: list[ConversionWarning] = []

        if len(source.cards) > 1:
            extra_warnings.append(
                ConversionWarning(
                    code="thread_merged",
                    field="cards",
                    message=f"Merged {len(source.cards)} Bluesky cards into single Instagram post",
                )
            )

        media = _trim_media(media, Platform.INSTAGRAM, extra_warnings)
        content_type = self._infer_instagram_content_type(media, extra_warnings)

        doc = ParsedInstagramDocument(
            post=InstagramPostContent(
                caption=text,
                media=media,
                content_type=content_type,
            ),
        )
        return self._make_result(doc, source, Platform.INSTAGRAM, extra_warnings)

    def _bluesky_to_tiktok(self, source: ParsedBlueSkyDocument) -> ConversionResult:
        text = self._extract_text_body(source)
        media = self._extract_all_media(source)
        extra_warnings: list[ConversionWarning] = []

        if len(source.cards) > 1:
            extra_warnings.append(
                ConversionWarning(
                    code="thread_merged",
                    field="cards",
                    message=f"Merged {len(source.cards)} Bluesky cards into single TikTok post",
                )
            )

        media = _trim_media(media, Platform.TIKTOK, extra_warnings)

        doc = ParsedTikTokDocument(
            post=TikTokPostContent(title=text, media=media),
        )
        return self._make_result(doc, source, Platform.TIKTOK, extra_warnings)

    # ==================== Others → Bluesky ====================

    def _twitter_to_bluesky(self, source: ParsedTwitterDocument) -> ConversionResult:
        extra_warnings: list[ConversionWarning] = []
        cards = [
            BlueSkyCardContent(
                id=card.id,
                text=card.text,
                media=_trim_media(list(card.media), Platform.BLUESKY, extra_warnings),
                auto_number=card.auto_number,
            )
            for card in source.cards
        ]
        doc = ParsedBlueSkyDocument(
            cards=cards,
            auto_number_config=source.auto_number_config,
        )
        return self._make_result(doc, source, Platform.BLUESKY, extra_warnings)

    def _linkedin_to_bluesky(self, source: ParsedLinkedInDocument) -> ConversionResult:
        text = source.post.text
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.BLUESKY, extra_warnings)

        doc = ParsedBlueSkyDocument(
            cards=[BlueSkyCardContent(text=text, media=media)],
        )
        return self._make_result(doc, source, Platform.BLUESKY, extra_warnings)

    def _instagram_to_bluesky(
        self, source: ParsedInstagramDocument
    ) -> ConversionResult:
        text = source.post.caption
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.BLUESKY, extra_warnings)

        doc = ParsedBlueSkyDocument(
            cards=[BlueSkyCardContent(text=text, media=media)],
        )
        return self._make_result(doc, source, Platform.BLUESKY, extra_warnings)

    def _tiktok_to_bluesky(self, source: ParsedTikTokDocument) -> ConversionResult:
        text = source.post.title
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.BLUESKY, extra_warnings)

        doc = ParsedBlueSkyDocument(
            cards=[BlueSkyCardContent(text=text, media=media)],
        )
        return self._make_result(doc, source, Platform.BLUESKY, extra_warnings)

    # ==================== Threads → Others ====================

    def _threads_to_twitter(self, source: ParsedThreadsDocument) -> ConversionResult:
        extra_warnings: list[ConversionWarning] = []
        cards = [
            TwitterCardContent(
                id=card.id,
                text=card.text,
                media=_trim_media(list(card.media), Platform.TWITTER, extra_warnings),
                auto_number=card.auto_number,
            )
            for card in source.cards
        ]
        doc = ParsedTwitterDocument(
            cards=cards,
            auto_number_config=source.auto_number_config,
        )
        return self._make_result(doc, source, Platform.TWITTER, extra_warnings)

    def _threads_to_bluesky(self, source: ParsedThreadsDocument) -> ConversionResult:
        extra_warnings: list[ConversionWarning] = []
        cards = [
            BlueSkyCardContent(
                id=card.id,
                text=card.text,
                media=_trim_media(list(card.media), Platform.BLUESKY, extra_warnings),
                og=card.og,
                auto_number=card.auto_number,
            )
            for card in source.cards
        ]
        doc = ParsedBlueSkyDocument(
            cards=cards,
            auto_number_config=source.auto_number_config,
        )
        return self._make_result(doc, source, Platform.BLUESKY, extra_warnings)

    def _threads_to_linkedin(self, source: ParsedThreadsDocument) -> ConversionResult:
        text = self._extract_text_body(source)
        media = self._extract_all_media(source)
        extra_warnings: list[ConversionWarning] = []

        if len(source.cards) > 1:
            extra_warnings.append(
                ConversionWarning(
                    code="thread_merged",
                    field="cards",
                    message=f"Merged {len(source.cards)} Threads cards into single LinkedIn post",
                )
            )

        media = _trim_media(media, Platform.LINKEDIN, extra_warnings)

        doc = ParsedLinkedInDocument(
            post=LinkedInPostContent(text=text, media=media),
        )
        return self._make_result(doc, source, Platform.LINKEDIN, extra_warnings)

    def _threads_to_instagram(self, source: ParsedThreadsDocument) -> ConversionResult:
        text = self._extract_text_body(source)
        media = self._extract_all_media(source)
        extra_warnings: list[ConversionWarning] = []

        if len(source.cards) > 1:
            extra_warnings.append(
                ConversionWarning(
                    code="thread_merged",
                    field="cards",
                    message=f"Merged {len(source.cards)} Threads cards into single Instagram post",
                )
            )

        media = _trim_media(media, Platform.INSTAGRAM, extra_warnings)
        content_type = self._infer_instagram_content_type(media, extra_warnings)

        doc = ParsedInstagramDocument(
            post=InstagramPostContent(
                caption=text,
                media=media,
                content_type=content_type,
            ),
        )
        return self._make_result(doc, source, Platform.INSTAGRAM, extra_warnings)

    def _threads_to_tiktok(self, source: ParsedThreadsDocument) -> ConversionResult:
        text = self._extract_text_body(source)
        media = self._extract_all_media(source)
        extra_warnings: list[ConversionWarning] = []

        if len(source.cards) > 1:
            extra_warnings.append(
                ConversionWarning(
                    code="thread_merged",
                    field="cards",
                    message=f"Merged {len(source.cards)} Threads cards into single TikTok post",
                )
            )

        media = _trim_media(media, Platform.TIKTOK, extra_warnings)

        doc = ParsedTikTokDocument(
            post=TikTokPostContent(title=text, media=media),
        )
        return self._make_result(doc, source, Platform.TIKTOK, extra_warnings)

    # ==================== Others → Threads ====================

    def _twitter_to_threads(self, source: ParsedTwitterDocument) -> ConversionResult:
        extra_warnings: list[ConversionWarning] = []
        cards = [
            ThreadsCardContent(
                id=card.id,
                text=card.text,
                media=_trim_media(list(card.media), Platform.THREADS, extra_warnings),
                auto_number=card.auto_number,
            )
            for card in source.cards
        ]
        doc = ParsedThreadsDocument(
            cards=cards,
            auto_number_config=source.auto_number_config,
        )
        return self._make_result(doc, source, Platform.THREADS, extra_warnings)

    def _bluesky_to_threads(self, source: ParsedBlueSkyDocument) -> ConversionResult:
        extra_warnings: list[ConversionWarning] = []
        cards = [
            ThreadsCardContent(
                id=card.id,
                text=card.text,
                media=_trim_media(list(card.media), Platform.THREADS, extra_warnings),
                og=card.og,
                auto_number=card.auto_number,
            )
            for card in source.cards
        ]
        doc = ParsedThreadsDocument(
            cards=cards,
            auto_number_config=source.auto_number_config,
        )
        return self._make_result(doc, source, Platform.THREADS, extra_warnings)

    def _linkedin_to_threads(self, source: ParsedLinkedInDocument) -> ConversionResult:
        text = source.post.text
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.THREADS, extra_warnings)

        doc = ParsedThreadsDocument(
            cards=[ThreadsCardContent(text=text, media=media)],
        )
        return self._make_result(doc, source, Platform.THREADS, extra_warnings)

    def _instagram_to_threads(
        self, source: ParsedInstagramDocument
    ) -> ConversionResult:
        text = source.post.caption
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.THREADS, extra_warnings)

        doc = ParsedThreadsDocument(
            cards=[ThreadsCardContent(text=text, media=media)],
        )
        return self._make_result(doc, source, Platform.THREADS, extra_warnings)

    def _tiktok_to_threads(self, source: ParsedTikTokDocument) -> ConversionResult:
        text = source.post.title
        media = list(source.post.media)
        extra_warnings: list[ConversionWarning] = []

        media = _trim_media(media, Platform.THREADS, extra_warnings)

        doc = ParsedThreadsDocument(
            cards=[ThreadsCardContent(text=text, media=media)],
        )
        return self._make_result(doc, source, Platform.THREADS, extra_warnings)

    # ==================== Helpers ====================

    def _infer_instagram_content_type(
        self,
        media: list[str],
        warnings: list[ConversionWarning],
    ) -> ContentType:
        """Infer Instagram content type from media count."""
        if len(media) > 1:
            content_type = ContentType.CAROUSEL
        elif len(media) == 1:
            content_type = ContentType.POST
        else:
            content_type = ContentType.POST

        if content_type == ContentType.CAROUSEL:
            warnings.append(
                ConversionWarning(
                    code="content_type_inferred",
                    field="content_type",
                    message=f"Instagram content_type set to {content_type.value} based on media count",
                )
            )
        return content_type


# ==================== Builder Registry ====================

_BUILDERS: dict[Platform, Any] = {
    Platform.TWITTER: TwitterCRDTBuilder(),
    Platform.LINKEDIN: LinkedInCRDTBuilder(),
    Platform.INSTAGRAM: InstagramCRDTBuilder(),
    Platform.TIKTOK: TikTokCRDTBuilder(),
    Platform.BLUESKY: BlueskyCRDTBuilder(),
    Platform.THREADS: ThreadsCRDTBuilder(),
}

# Global converter instance
_converter = DocumentConverter()


def convert_document(
    source: ParsedDocument,
    target_platform: Platform | str,
) -> ConversionResult:
    """Convert a parsed document to another platform format."""
    return _converter.convert(source, target_platform)


def convert_crdt_binary(
    source_platform: str,
    binary_data: bytes,
    target_platform: str,
    fragment_name: str = "default",
) -> ConversionResult:
    """Parse binary CRDT data then convert to target platform."""
    parsed = parse_crdt_binary(source_platform, binary_data, fragment_name)
    return _converter.convert(parsed, target_platform)


def convert_crdt_to_crdt(
    source_platform: str,
    target_platform: str,
    binary_data: bytes,
    fragment_name: str = "default",
) -> tuple[Doc[Any], ConversionResult]:
    """Full pipeline: binary → parse → convert → build new CRDT Doc."""
    parsed = parse_crdt_binary(source_platform, binary_data, fragment_name)
    result = _converter.convert(parsed, target_platform)

    target = Platform(target_platform.lower())
    builder = _BUILDERS[target]
    doc = builder.build_document(result.document, fragment_name)

    return doc, result
