"""Threads-specific CRDT document parser.

This module provides parsing for CRDT documents containing Threads
post data with threadcard nodes.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from marqetive.utils.crdt.exceptions import CRDTEmptyDocumentError, CRDTParseError
from marqetive.utils.crdt.models import (
    AutoNumberConfig,
    ParsedThreadsDocument,
    ThreadsCardContent,
)
from marqetive.utils.crdt.platforms.base import BaseCRDTParser

if TYPE_CHECKING:
    from pycrdt import Doc, XmlElement


class ThreadsCRDTParser(BaseCRDTParser[ParsedThreadsDocument]):
    """Parser for Threads CRDT documents.

    Handles parsing of threadcard nodes which represent individual posts
    in a thread. Supports media attachments and link card embeds.

    Validation rules:
        - Max 500 characters per card
        - Max 20 media attachments per card
        - Threads supported (multiple cards)
    """

    @property
    def platform_name(self) -> str:
        """Return the platform name."""
        return "threads"

    @property
    def root_node_type(self) -> str:
        """Return the root node type for Threads."""
        return "threadcard"

    def parse_document(
        self, doc: Doc[Any], fragment_name: str = "default"
    ) -> ParsedThreadsDocument:
        """Parse a Threads CRDT document.

        Args:
            doc: The pycrdt Doc object to parse
            fragment_name: Name of the XML fragment to parse

        Returns:
            ParsedThreadsDocument with parsed cards

        Raises:
            CRDTEmptyDocumentError: If no cards found
            CRDTParseError: If parsing fails
        """
        fragment = self._get_fragment(doc, fragment_name)
        raw_attributes = self._get_node_attributes(fragment)

        # Parse auto-number config from threadContainer node if present
        auto_number_config: AutoNumberConfig | None = None
        thread_nodes = self._find_nodes_by_type(fragment, "threadContainer")
        if thread_nodes:
            auto_number_config = self._parse_auto_number_config(thread_nodes[0])

        # Find all threadcard nodes
        card_nodes = self._find_nodes_by_type(fragment, self.root_node_type)

        if not card_nodes:
            raise CRDTEmptyDocumentError(
                "No Threads cards found in document",
                fragment_name=fragment_name,
            )

        # Parse each card
        cards: list[ThreadsCardContent] = []
        for i, node in enumerate(card_nodes):
            try:
                card = self._parse_card(node, i)
                cards.append(card)
            except Exception as e:
                raise CRDTParseError(
                    f"Failed to parse Threads card at position {i}: {e}",
                    platform=self.platform_name,
                    node_type=self.root_node_type,
                    position=i,
                ) from e

        return ParsedThreadsDocument(
            cards=cards,
            auto_number_config=auto_number_config,
            raw_attributes=raw_attributes,
            parsed_at=datetime.now(UTC),
        )

    def validate_schema(
        self,
        doc: Doc[Any],  # noqa: ARG002
        fragment_name: str = "default",  # noqa: ARG002
    ) -> list[str]:
        """Validate a Threads CRDT document."""
        return []

    def _parse_card(self, node: XmlElement, index: int) -> ThreadsCardContent:
        """Parse a single threadcard node.

        Args:
            node: The threadcard XML node
            index: Position of the card in the thread

        Returns:
            ThreadsCardContent with parsed data
        """
        attrs = self._get_node_attributes(node)

        # Extract text content
        text = self._extract_text(node)

        # Parse media via space-separated URL strings
        media = self._parse_media_urls(node, "media")

        # Parse og link card URL
        og: str | None = None
        og_value = attrs.get("og")
        if og_value is not None:
            og = str(og_value)

        # Read autoNumber from card attrs
        auto_number = attrs.get("autoNumber")
        if auto_number is not None:
            auto_number = str(auto_number)

        # Get card ID if available
        card_id = attrs.get("id") or attrs.get("cardId") or f"card_{index}"

        return ThreadsCardContent(
            id=card_id,
            text=text,
            media=media,
            og=og,
            auto_number=auto_number,
        )

    def _parse_auto_number_config(self, node: XmlElement) -> AutoNumberConfig | None:
        """Parse auto-number configuration from a threadContainer node.

        Args:
            node: The threadContainer XML element

        Returns:
            AutoNumberConfig or None
        """
        config = self._safe_get_attribute(node, "autoNumberConfig")
        if not config:
            return None
        if isinstance(config, str):
            try:
                config = json.loads(config)
            except json.JSONDecodeError:
                return None
        if isinstance(config, dict):
            return AutoNumberConfig(
                enabled=bool(config.get("enabled", False)),
                position=config.get("position", "start"),
                format_style=config.get("formatStyle", "#1"),
                skip_first=config.get("skipFirst", 1),
                skip_last=config.get("skipLast", 1),
            )
        return None
