"""CRDT Document Parser and Converter for Social Media Platforms.

This module provides utilities for parsing, converting, and building Y.js CRDT
documents containing ProseMirror schema structures for Twitter, LinkedIn,
Instagram, and TikTok.

Main API:
    - parse_crdt_document: Parse a CRDT document for a specific platform
    - parse_crdt_binary: Parse from binary Y.js update data
    - validate_crdt_document: Validate document against platform rules
    - detect_platform: Auto-detect platform from document structure

Converter API:
    - convert_document: Convert a parsed document to another platform
    - convert_crdt_binary: Parse binary then convert
    - convert_crdt_to_crdt: Full pipeline binary → parse → convert → build

Platform-specific functions (with better type inference):
    - parse_twitter_document: Parse Twitter document
    - parse_linkedin_document: Parse LinkedIn document
    - parse_instagram_document: Parse Instagram document
    - parse_tiktok_document: Parse TikTok document

Factory:
    - CRDTParserFactory: Create platform-specific parsers

Models:
    - ParsedTwitterDocument, ParsedLinkedInDocument, etc.
    - TwitterCardContent, LinkedInPostContent, etc.
    - AutoNumberConfig
    - ConversionWarning, ConversionExtras, ConversionResult

Exceptions:
    - CRDTError, CRDTParseError, CRDTValidationError, etc.
    - CRDTConversionError

Builders:
    - BaseCRDTBuilder, TwitterCRDTBuilder, LinkedInCRDTBuilder, etc.

Example:
    >>> from marqetive.utils.crdt import parse_crdt_binary
    >>>
    >>> # Parse Twitter thread from binary data
    >>> with open("thread.yjs", "rb") as f:
    ...     result = parse_crdt_binary("twitter", f.read())
    >>>
    >>> for card in result.cards:
    ...     print(f"Tweet: {card.text[:50]}...")
    ...     print(f"  Media: {len(card.media)} items")
"""

# Exceptions
# Builders
from marqetive.utils.crdt.builders import (
    BlueskyCRDTBuilder,
    InstagramCRDTBuilder,
    LinkedInCRDTBuilder,
    ThreadsCRDTBuilder,
    TikTokCRDTBuilder,
    TwitterCRDTBuilder,
)
from marqetive.utils.crdt.builders.base import BaseCRDTBuilder

# Converter API
from marqetive.utils.crdt.converter import (
    DocumentConverter,
    convert_crdt_binary,
    convert_crdt_to_crdt,
    convert_document,
)
from marqetive.utils.crdt.exceptions import (
    CRDTConversionError,
    CRDTEmptyDocumentError,
    CRDTError,
    CRDTParseError,
    CRDTSchemaError,
    CRDTUnsupportedPlatformError,
    CRDTValidationError,
)

# Models - Enums
# Models - Platform content
# Models - Document results
# Models - Conversion
from marqetive.utils.crdt.models import (
    AutoNumberConfig,
    BlueSkyCardContent,
    ContentType,
    ConversionExtras,
    ConversionResult,
    ConversionWarning,
    InstagramPostContent,
    LinkedInCommentContent,
    LinkedInPostContent,
    ParsedBlueSkyDocument,
    ParsedDocument,
    ParsedInstagramDocument,
    ParsedLinkedInDocument,
    ParsedThreadsDocument,
    ParsedTikTokDocument,
    ParsedTwitterDocument,
    Platform,
    PostVisibility,
    ThreadsCardContent,
    TikTokPostContent,
    TwitterCardContent,
)

# Factory
# Main API functions
# Platform-specific functions
from marqetive.utils.crdt.parser import (
    SUPPORTED_PLATFORMS,
    CRDTParserFactory,
    detect_platform,
    parse_bluesky_document,
    parse_crdt_binary,
    parse_crdt_document,
    parse_instagram_document,
    parse_linkedin_document,
    parse_threads_document,
    parse_tiktok_document,
    parse_twitter_document,
    validate_crdt_document,
)

# Platform parsers
from marqetive.utils.crdt.platforms import (
    BlueskyCRDTParser,
    InstagramCRDTParser,
    LinkedInCRDTParser,
    ThreadsCRDTParser,
    TikTokCRDTParser,
    TwitterCRDTParser,
)

# Base parser (for custom implementations)
from marqetive.utils.crdt.platforms.base import BaseCRDTParser

__all__ = [
    # Exceptions
    "CRDTError",
    "CRDTParseError",
    "CRDTValidationError",
    "CRDTSchemaError",
    "CRDTUnsupportedPlatformError",
    "CRDTEmptyDocumentError",
    "CRDTConversionError",
    # Enums
    "Platform",
    "ContentType",
    "PostVisibility",
    # Models
    "AutoNumberConfig",
    # Platform content models
    "TwitterCardContent",
    "BlueSkyCardContent",
    "ThreadsCardContent",
    "LinkedInPostContent",
    "LinkedInCommentContent",
    "InstagramPostContent",
    "TikTokPostContent",
    # Document result models
    "ParsedTwitterDocument",
    "ParsedBlueSkyDocument",
    "ParsedThreadsDocument",
    "ParsedLinkedInDocument",
    "ParsedInstagramDocument",
    "ParsedTikTokDocument",
    "ParsedDocument",
    # Conversion models
    "ConversionWarning",
    "ConversionExtras",
    "ConversionResult",
    # Factory
    "CRDTParserFactory",
    "SUPPORTED_PLATFORMS",
    # Main API functions
    "parse_crdt_document",
    "parse_crdt_binary",
    "validate_crdt_document",
    "detect_platform",
    # Platform-specific functions
    "parse_twitter_document",
    "parse_bluesky_document",
    "parse_threads_document",
    "parse_linkedin_document",
    "parse_instagram_document",
    "parse_tiktok_document",
    # Converter API
    "DocumentConverter",
    "convert_document",
    "convert_crdt_binary",
    "convert_crdt_to_crdt",
    # Base and platform parsers
    "BaseCRDTParser",
    "TwitterCRDTParser",
    "BlueskyCRDTParser",
    "ThreadsCRDTParser",
    "LinkedInCRDTParser",
    "InstagramCRDTParser",
    "TikTokCRDTParser",
    # Builders
    "BaseCRDTBuilder",
    "TwitterCRDTBuilder",
    "BlueskyCRDTBuilder",
    "ThreadsCRDTBuilder",
    "LinkedInCRDTBuilder",
    "InstagramCRDTBuilder",
    "TikTokCRDTBuilder",
]
