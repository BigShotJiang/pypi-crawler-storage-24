"""Threads CRDT document builder.

Builds pycrdt Doc objects from ParsedThreadsDocument models.
"""

from __future__ import annotations

import json
from typing import Any

from pycrdt import Doc, XmlElement

from marqetive.utils.crdt.builders.base import BaseCRDTBuilder
from marqetive.utils.crdt.models import ParsedThreadsDocument


class ThreadsCRDTBuilder(BaseCRDTBuilder[ParsedThreadsDocument]):
    """Builder for Threads CRDT documents."""

    @property
    def platform_name(self) -> str:
        return "threads"

    @property
    def root_node_type(self) -> str:
        return "threadcard"

    def build_document(
        self, parsed: ParsedThreadsDocument, fragment_name: str = "default"
    ) -> Doc[Any]:
        """Build a Threads CRDT Doc from a parsed document.

        Creates threadcard nodes for each card, and optionally a
        threadContainer node if auto_number_config is present.
        """
        children: list[XmlElement] = []

        # Build threadContainer node if auto_number_config present
        if parsed.auto_number_config is not None:
            config = parsed.auto_number_config
            config_dict = {
                "enabled": config.enabled,
                "position": config.position,
                "formatStyle": config.format_style,
                "skipFirst": config.skip_first,
                "skipLast": config.skip_last,
            }
            thread_attrs = {"autoNumberConfig": json.dumps(config_dict)}
            children.append(XmlElement("threadContainer", attributes=thread_attrs))

        # Build card nodes
        for i, card in enumerate(parsed.cards):
            attrs: dict[str, str] = {}
            if card.id is not None:
                attrs["id"] = card.id
            else:
                attrs["id"] = f"card_{i}"

            if card.media:
                attrs["media"] = self._build_media_attribute(card.media)

            if card.og is not None:
                attrs["og"] = card.og

            if card.auto_number is not None:
                attrs["autoNumber"] = card.auto_number

            paragraphs = self._build_text_paragraphs(card.text)
            children.append(
                XmlElement("threadcard", attributes=attrs, contents=paragraphs)
            )

        return self._create_doc_with_fragment(fragment_name, children)
