import unittest

from https.http_manager import forecast


class TestWeatherForecast(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_forecast_shanghai(self):
        weather = forecast("上海")
        print(f"weather:{weather}")
        expect_weather = """{"date":"2026-03-18","temperature":"6/13℃","weather":"小雨","wid":{"day":"07","night":"07"},"direct":"西北风转东北风"}"""
        self.assertEqual(expect_weather, weather, "获取天气信息失败")  # add assertion here


if __name__ == '__main__':
    unittest.main()
