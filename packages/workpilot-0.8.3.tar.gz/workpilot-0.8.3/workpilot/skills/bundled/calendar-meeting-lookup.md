---
name: calendar-meeting-lookup
description: Look up Outlook calendar events and meetings using WorkIQ, calendar API, and mail search.
metadata:
  workpilot:
    activation:
      keywords: [calendar, meeting, 日程, 今日安排, 今日日程, meeting today, next meeting, 查日历, 查日程, 会议查询, meeting lookup, schedule, agenda]
    always: false
---

# Calendar Meeting Lookup

Use this skill for Outlook calendar and meeting-context queries.

## Tool priority

1. **`MCP_workiq_ask_work_iq`** — primary read path for natural-language calendar questions.
2. **`MCP_calendar_ListEvents`** — structured fallback/readback API.
3. **`MCP_mail_SearchMessages`** — invite/reminder/context fallback.

## Known issues

- `MCP_calendar_ListCalendarView` may return empty even when events exist — do not use as proof of absence.
- `attendeeEmails` is not a strict filter — do not rely on it alone.
- `meetingTitle` works as a partial title filter in `ListEvents`.
- Returned event times may come back in UTC even when another timezone is requested.
- Recurring instance lookup is unreliable (`ListEvents` may only expose the master).

## WorkIQ EULA

- Do not call `MCP_workiq_accept_eula` again after one successful acceptance.
- Only re-accept if access was explicitly revoked.

## Core rules

1. For read-only questions, use `MCP_workiq_ask_work_iq` first.
2. For structured fields or verification, use `MCP_calendar_ListEvents`.
3. For invite/reminder/history, use `MCP_mail_SearchMessages`.
4. Get user timezone first: `MCP_calendar_GetUserDateAndTimeZoneSettings(userIdentifier="me")`.
5. Query a slightly wider time window than the exact boundary when correctness matters.
6. Convert returned times to user timezone before replying.
7. For summaries, return `time + title` only unless more detail is requested.
8. If a result is uncertain, mention that briefly once.

## Read workflows

### Today / tomorrow / a date

Preferred:
1. Ask `MCP_workiq_ask_work_iq` for meetings on that date.
2. Return a brief summary.

Fallback:
1. Get mailbox timezone via `MCP_calendar_GetUserDateAndTimeZoneSettings`.
2. Query `MCP_calendar_ListEvents` with:
   - `startDateTime = "YYYY-MM-DDT00:00:00"`
   - `endDateTime = "YYYY-MM-DDT23:59:59"`
   - `timeZone = mailbox timezone`
   - `select = "id,subject,start,end,location,organizer,isAllDay,showAs,type,recurrence"`
3. Interpret returned times carefully (may be UTC).

### Find a meeting by title

Preferred:
1. Ask `MCP_workiq_ask_work_iq` for the meeting by title/date.

Fallback:
1. Use `MCP_calendar_ListEvents` with `meetingTitle = partial title` and a reasonable time window.
2. If mail context matters, also search `MCP_mail_SearchMessages`.

### Find meeting invite / reminder / recap

Use `MCP_mail_SearchMessages` for invite emails, reminders, webinar registrations, and recap emails with decks/recordings.

## Safe creation rule

1. Create the event with calendar APIs.
2. Immediately read it back.
3. Verify subject, start/end time, and timezone interpretation.
4. Only confirm to the user after verification.

## Safe modify/delete rule

1. Find the target with WorkIQ and/or a narrow `ListEvents` query.
2. If recurring, be cautious — exact instance resolution may be unreliable.
3. If exact target is unclear, ask once before taking action.

## Avoid

- Using `ListCalendarView` as proof that no events exist
- Using `attendeeEmails` as a strict filter
- Trusting event creation time without read-back verification
- Assuming recurring instances can be resolved safely

## Reply style

- Be brief.
- For summaries: `HH:mm–HH:mm Title`
- Mention reliability caveats only if they affect the answer.
