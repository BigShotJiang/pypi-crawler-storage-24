"""
DEPRECATED: Environment parameter management for MCard.

This module is deprecated in favor of `mcard.config.settings`.
All new code should use:
    from mcard.config.settings import settings

This module delegates to the unified Settings singleton for backward compatibility.
It will be removed in a future release.
"""

import warnings

warnings.warn(
    "mcard.config.env_parameters.EnvParameters is deprecated. "
    "Use mcard.config.settings.settings instead.",
    DeprecationWarning,
    stacklevel=2,
)

from .settings import settings


class EnvParameters:
    """Backward-compatible shim that delegates to the unified Settings singleton."""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def load_env_variables(self):
        """No-op: settings singleton already loads env vars on init."""

    def get_db_path(self):
        return settings.database.path

    def get_test_db_path(self):
        return settings.database.test_path

    def get_log_level(self):
        return settings.logging.level

    def get_default_page_size(self):
        return settings.pagination.default_page_size

    def get_default_pool_size(self):
        return settings.database.pool_size

    def get_default_timeout(self):
        return settings.database.timeout

    def get_hash_algorithm(self):
        return settings.hashing.algorithm

    def get_hash_custom_module(self):
        return settings.hashing.custom_module

    def get_hash_custom_function(self):
        return settings.hashing.custom_function

    def get_hash_custom_length(self):
        return settings.hashing.custom_length

    def get_api_port(self):
        return settings.api.port

    def get_store_max_connections(self):
        return settings.database.max_connections

    def get_api_key(self):
        return settings.api.api_key

    def get_wrap_width_default(self) -> int:
        return settings.file_processing.wrap_width_default

    def get_wrap_width_known(self) -> int:
        return settings.file_processing.wrap_width_known

    def get_max_problem_text_bytes(self) -> int:
        return settings.file_processing.max_problem_text_bytes

    def get_read_timeout_secs(self) -> float:
        return settings.file_processing.read_timeout_secs
