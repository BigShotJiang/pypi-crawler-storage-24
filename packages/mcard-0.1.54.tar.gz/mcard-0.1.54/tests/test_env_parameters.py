"""Test environment parameter management."""

import os

import pytest
from dotenv import load_dotenv

from mcard.config.config_constants import (
    DEFAULT_DB_PATH,
    DEFAULT_POOL_SIZE,
    DEFAULT_TIMEOUT,
    ENV_DB_PATH,
    ENV_DB_TIMEOUT,
    ENV_HASH_ALGORITHM,
    ENV_HASH_CUSTOM_FUNCTION,
    ENV_HASH_CUSTOM_LENGTH,
    ENV_HASH_CUSTOM_MODULE,
    ENV_SERVICE_LOG_LEVEL,
    TEST_DB_PATH,
)
from mcard.config.env_parameters import EnvParameters


@pytest.fixture(autouse=True)
def reset_singleton():
    """Reset the EnvParameters singleton before each test"""
    EnvParameters._instance = None
    yield


@pytest.fixture(scope="module", autouse=True)
def setup_env():
    """Load environment variables from .env file"""
    load_dotenv()
    yield


def test_env_parameters():
    """Test that environment parameters are loaded correctly."""
    # Test database paths
    assert EnvParameters().get_db_path() == os.getenv(ENV_DB_PATH, DEFAULT_DB_PATH)
    assert EnvParameters().get_test_db_path() == os.getenv("TEST_DB_PATH", TEST_DB_PATH)

    # Test logging
    assert EnvParameters().get_log_level() == os.getenv(ENV_SERVICE_LOG_LEVEL, "DEBUG")

    # Test pool and timeout settings
    assert EnvParameters().get_default_pool_size() == int(
        os.getenv("DEFAULT_POOL_SIZE", DEFAULT_POOL_SIZE)
    )
    assert EnvParameters().get_default_timeout() == float(
        os.getenv(ENV_DB_TIMEOUT, DEFAULT_TIMEOUT)
    )

    # Test hash settings
    assert EnvParameters().get_hash_algorithm() == os.getenv(
        ENV_HASH_ALGORITHM, "sha256"
    )
    assert EnvParameters().get_hash_custom_module() == os.getenv(
        ENV_HASH_CUSTOM_MODULE, "custom_module"
    )
    assert EnvParameters().get_hash_custom_function() == os.getenv(
        ENV_HASH_CUSTOM_FUNCTION, "custom_function"
    )
    assert EnvParameters().get_hash_custom_length() == int(
        os.getenv(ENV_HASH_CUSTOM_LENGTH, 64)
    )
