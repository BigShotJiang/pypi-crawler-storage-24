import hashlib  # Import hashlib for comparison

import pytest

from mcard.model.hash.algorithms.local_sha256 import (
    localized_sha256,
)

# Test cases for SHA-256 implementation


def test_localized_sha256():
    # Known test cases
    test_cases = [
        (
            "Hello World, SHA-256!",
            hashlib.sha256(b"Hello World, SHA-256!").hexdigest(),
        ),
        ("Hello, SHA-256!", hashlib.sha256(b"Hello, SHA-256!").hexdigest()),
        ("", hashlib.sha256(b"").hexdigest()),  # SHA-256 of an empty string
        (
            "The quick brown fox jumps over the lazy dog",
            hashlib.sha256(b"The quick brown fox jumps over the lazy dog").hexdigest(),
        ),
        # Binary test cases
        (
            b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n",
            hashlib.sha256(
                b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n"
            ).hexdigest(),
        ),  # PDF
        (
            b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00H\x00H\x00\x00\xff\xdb\x00C\x00\x08\x06\x06\x07\x06\x05\x08\x07\x07\x07\t\t\x08\n\x0c\x14\r\x0c\x0b\x0b\x0c\x19\x12\x13\x0f\x14\x1d\x1a\x1f\x1e\x1d\x1a\x1c\x1c $.",
            hashlib.sha256(
                b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00H\x00H\x00\x00\xff\xdb\x00C\x00\x08\x06\x06\x07\x06\x05\x08\x07\x07\x07\t\t\x08\n\x0c\x14\r\x0c\x0b\x0b\x0c\x19\x12\x13\x0f\x14\x1d\x1a\x1f\x1e\x1d\x1a\x1c\x1c $."
            ).hexdigest(),
        ),  # JPG
        (
            b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x00\x00\x02\x00\x01\xe5\xde\xfc\x00\x00\x00\x00IEND\xaeB`\x82-PNG",
            hashlib.sha256(
                b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x00\x00\x02\x00\x01\xe5\xde\xfc\x00\x00\x00\x00IEND\xaeB`\x82-PNG"
            ).hexdigest(),
        ),  # PNG
    ]

    for input_str, expected_hash in test_cases:
        assert localized_sha256(input_str) == expected_hash  # Update function call


if __name__ == "__main__":
    pytest.main()
