import pytest

from mcard.model.dots import CardPlane, DOTSRole
from mcard.model.pcard import PCard


def test_pcard_initialization():
    clm_content = """
    abstract_spec:
      name: Test CLM
    concrete_impl:
      runtime: python
      code: print('hello')
    tight_deps:
      - hash123
    """
    card = PCard(clm_content)

    assert card.hash is not None
    assert card.clm["abstract_spec"]["name"] == "Test CLM"

    # Check DOTS metadata
    meta = card.get_dots_metadata()
    assert meta.role == DOTSRole.LENS
    assert meta.plane == CardPlane.CONTROL
    assert meta.tight_refs == ["hash123"]


def test_pcard_invalid_content():
    with pytest.raises(ValueError):
        PCard("Not a YAML dictionary")


if __name__ == "__main__":
    # fast manual run
    test_pcard_initialization()
    test_pcard_invalid_content()
    print("PCard tests passed!")
