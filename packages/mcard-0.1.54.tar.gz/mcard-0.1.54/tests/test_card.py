import pytest

from mcard.model.card import MCard


def test_create_with_string():
    card = MCard("test content")
    assert card.content == b"test content"  # Check for bytes
    assert isinstance(card.content, bytes)
    assert card.content == b"test content"


def test_create_with_bytes():
    content = b"binary content"
    card = MCard(content)
    assert card.content == content
    assert card.content == content


def test_empty_content():
    with pytest.raises(ValueError, match="Content cannot be empty"):
        MCard("")

    with pytest.raises(ValueError, match="Content cannot be empty"):
        MCard(b"")


def test_none_content():
    with pytest.raises(ValueError, match="Content cannot be None"):
        MCard(None)


def test_hash_computation():
    card = MCard("test content")
    assert isinstance(card.hash, str)
    assert len(card.hash) > 0


def test_g_time_computation():
    card = MCard("test content")
    g_time = card.g_time
    assert isinstance(g_time, str)
    assert "|" in g_time  # Format should be hash_function|timestamp|region
