"""Typer-based CLI for cited."""

from __future__ import annotations

import json
import sys
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from . import __version__
from .client import fetch_blueprint, search_agents, AgentNotFoundError, PlatformError
from .runner import run_agent, check_env_vars, RunError
from . import cache as cache_module

app = typer.Typer(
    name="cited",
    help="Run cited AI agents with one command.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
console = Console()
err_console = Console(stderr=True)

# ── Helpers ──────────────────────────────────────────────────────────────────

def _parse_agent_ref(ref: str) -> tuple[str, str | None]:
    """Parse 'slug@version' into (slug, version). Version is optional."""
    if "@" in ref:
        slug, version = ref.split("@", 1)
        return slug.strip(), version.strip()
    return ref.strip(), None


# ── run ──────────────────────────────────────────────────────────────────────

@app.command()
def run(
    agent_ref: str = typer.Argument(
        help="Agent to run, e.g. [bold]dfmea-agent@1.0.0[/bold]",
    ),
    input_file: Optional[str] = typer.Option(
        None, "--input", "-i",
        help="Path to input JSON file. If omitted, reads from stdin.",
    ),
    no_validate: bool = typer.Option(
        False, "--no-validate",
        help="Skip input/output schema validation.",
    ),
    output_mode: Optional[str] = typer.Option(
        None, "--output-mode",
        help="Output mode: 'data' (default, structured JSON only) or 'full' (JSON + visual artifacts).",
    ),
) -> None:
    """Run a cited agent.

    Fetches the blueprint, installs the agent in an isolated environment,
    pipes input JSON via stdin, and prints output JSON to stdout.

    \b
    Examples:
        cited run dfmea-agent@1.0.0 < input.json
        cited run dfmea-agent@1.0.0 --input input.json
        echo '{"system_name": "test"}' | cited run dfmea-agent
    """
    slug, version = _parse_agent_ref(agent_ref)

    # Read input
    input_data = _read_input(input_file)

    # Fetch blueprint
    try:
        err_console.print(f"[blue]Fetching blueprint for {slug}" + (f"@{version}" if version else "") + "...[/blue]")
        blueprint = fetch_blueprint(slug, version)
    except AgentNotFoundError:
        err_console.print(f"[red]Agent '{slug}' not found on the platform.[/red]")
        raise typer.Exit(1)
    except PlatformError as e:
        err_console.print(f"[red]Platform error: {e.message}[/red]")
        raise typer.Exit(1)

    # Run
    try:
        output = run_agent(
            slug, version, input_data, blueprint,
            skip_validation=no_validate,
            output_mode=output_mode,
        )
    except RunError as e:
        err_console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    # Print output JSON to stdout (machine-readable)
    print(json.dumps(output, indent=2))


# ── search ───────────────────────────────────────────────────────────────────

@app.command()
def search(
    query: str = typer.Argument(help="Search query (keywords, topic, DOI, etc.)"),
    tag: Optional[str] = typer.Option(None, "--tag", "-t", help="Filter by tag"),
    limit: int = typer.Option(10, "--limit", "-n", help="Max results"),
) -> None:
    """Search the catalog of cited agents."""
    try:
        result = search_agents(query=query, tag=tag, limit=limit)
    except PlatformError as e:
        err_console.print(f"[red]Search failed: {e.message}[/red]")
        raise typer.Exit(1)

    agents = result.get("data", [])
    total = result.get("total", 0)

    if not agents:
        console.print("[yellow]No agents found.[/yellow]")
        return

    table = Table(title=f"Search results ({total} total)")
    table.add_column("Slug", style="cyan")
    table.add_column("Title")
    table.add_column("Tags", style="dim")
    table.add_column("License", style="green")

    for agent in agents:
        tags_str = ", ".join(agent.get("tags", [])[:3])
        table.add_row(
            agent.get("slug", "?"),
            agent.get("title", "?"),
            tags_str,
            agent.get("license", "—"),
        )

    console.print(table)


# ── info ─────────────────────────────────────────────────────────────────────

@app.command()
def info(
    agent_ref: str = typer.Argument(help="Agent slug, e.g. dfmea-agent or dfmea-agent@1.0.0"),
) -> None:
    """Show detailed info about an agent (metadata, schemas, examples)."""
    slug, version = _parse_agent_ref(agent_ref)

    try:
        bp = fetch_blueprint(slug, version)
    except AgentNotFoundError:
        err_console.print(f"[red]Agent '{slug}' not found.[/red]")
        raise typer.Exit(1)
    except PlatformError as e:
        err_console.print(f"[red]Platform error: {e.message}[/red]")
        raise typer.Exit(1)

    console.print(f"\n[bold cyan]{bp.get('title', slug)}[/bold cyan]  [dim]v{bp.get('version', '?')}[/dim]")
    console.print(f"  {bp.get('description', '')}\n")

    # Metadata
    console.print(f"  [bold]License:[/bold]     {bp.get('license', '—')}")
    console.print(f"  [bold]GitHub:[/bold]      {bp.get('github_url', '—')}")
    console.print(f"  [bold]Commit:[/bold]      {bp.get('commit_hash', '—')[:12]}")
    console.print(f"  [bold]Entrypoint:[/bold]  {bp.get('entrypoint', '—')}")

    # Spawn protocol
    spawn = bp.get("spawn_protocol", {})
    if spawn:
        console.print(f"\n  [bold]Install:[/bold]  [green]{spawn.get('install', '—')}[/green]")
        console.print(f"  [bold]Run:[/bold]      [green]{spawn.get('run', '—')}[/green]")
        env_vars = spawn.get("required_env", [])
        if env_vars:
            console.print(f"  [bold]Env vars:[/bold]  {', '.join(env_vars)}")

    # Runtime
    runtime = bp.get("runtime", {})
    capacity = runtime.get("capacity", {})
    if capacity:
        console.print(f"\n  [bold]Capacity:[/bold]")
        if capacity.get("typical_latency_seconds"):
            console.print(f"    Typical latency: ~{capacity['typical_latency_seconds']}s")
        if capacity.get("max_inputs_tested"):
            console.print(f"    Max inputs tested: {capacity['max_inputs_tested']}")

    # References
    refs = bp.get("references", [])
    if refs:
        console.print(f"\n  [bold]References:[/bold]")
        for ref in refs:
            console.print(f"    [{ref.get('type', '?')}] {ref.get('id', '?')}")

    # Examples
    examples = bp.get("examples", [])
    if examples:
        console.print(f"\n  [bold]Examples:[/bold]")
        for ex in examples:
            console.print(f"    {ex.get('label', '?')}")

    # Input schema summary
    input_schema = bp.get("input_schema", {})
    props = input_schema.get("properties", {})
    required = set(input_schema.get("required", []))
    if props:
        console.print(f"\n  [bold]Input schema:[/bold]")
        for name, prop in props.items():
            req = " [red]*[/red]" if name in required else ""
            console.print(f"    {name}{req}: {prop.get('type', '?')} — {prop.get('description', '')}")

    console.print()


# ── validate ─────────────────────────────────────────────────────────────────

@app.command()
def validate(
    agent_ref: str = typer.Argument(help="Agent slug, e.g. dfmea-agent@1.0.0"),
    input_file: Optional[str] = typer.Option(
        None, "--input", "-i",
        help="Path to input JSON file. If omitted, reads from stdin.",
    ),
) -> None:
    """Validate input JSON against an agent's schema (without running it)."""
    slug, version = _parse_agent_ref(agent_ref)
    input_data = _read_input(input_file)

    try:
        bp = fetch_blueprint(slug, version)
    except AgentNotFoundError:
        err_console.print(f"[red]Agent '{slug}' not found.[/red]")
        raise typer.Exit(1)
    except PlatformError as e:
        err_console.print(f"[red]Platform error: {e.message}[/red]")
        raise typer.Exit(1)

    from .validator import validate_input, ValidationError
    try:
        validate_input(input_data, bp.get("input_schema", {}))
        console.print("[green]Input is valid.[/green]")
    except ValidationError as e:
        console.print(f"[red]Input validation failed:[/red]\n{e}")
        raise typer.Exit(1)


# ── cache ────────────────────────────────────────────────────────────────────

cache_app = typer.Typer(help="Manage the local agent cache.")
app.add_typer(cache_app, name="cache")


@cache_app.command("list")
def cache_list() -> None:
    """List all cached agents."""
    entries = cache_module.list_cached()
    if not entries:
        console.print("[dim]Cache is empty.[/dim]")
        return

    table = Table(title="Cached agents")
    table.add_column("Agent", style="cyan")
    table.add_column("Version")
    table.add_column("Size", style="dim")
    table.add_column("Path", style="dim")

    for entry in entries:
        table.add_row(entry["slug"], entry["version"], entry["size"], entry["path"])

    console.print(table)


@cache_app.command("clear")
def cache_clear(
    agent: Optional[str] = typer.Argument(None, help="Agent slug to clear (omit for all)"),
) -> None:
    """Clear cached agents."""
    removed = cache_module.clear_cache(agent)
    if removed:
        console.print(f"[green]Cleared {removed} cached agent(s).[/green]")
    else:
        console.print("[dim]Nothing to clear.[/dim]")


# ── config ───────────────────────────────────────────────────────────────────

config_app = typer.Typer(help="View and set CLI configuration.")
app.add_typer(config_app, name="config")


@config_app.command("show")
def config_show() -> None:
    """Show current configuration."""
    from .config import get_config
    cfg = get_config()
    console.print(f"[bold]API URL:[/bold]    {cfg.api_url}")
    console.print(f"[bold]Cache dir:[/bold]  {cfg.cache_dir}")
    console.print(f"\n[dim]Override via environment variables:[/dim]")
    console.print(f"  CITED_API_URL   — platform base URL")
    console.print(f"  CITED_CACHE_DIR — cache directory path")


@config_app.command("set")
def config_set(
    key: str = typer.Argument(help="Config key (api-url, cache-dir)"),
    value: str = typer.Argument(help="Config value"),
) -> None:
    """Set a config value (via env var hint — config file coming soon)."""
    env_map = {
        "api-url": "CITED_API_URL",
        "cache-dir": "CITED_CACHE_DIR",
    }
    env_var = env_map.get(key)
    if not env_var:
        console.print(f"[red]Unknown config key: {key}[/red]")
        console.print(f"Valid keys: {', '.join(env_map.keys())}")
        raise typer.Exit(1)

    console.print(f"To set [bold]{key}[/bold], add to your shell profile:")
    console.print(f"  [green]export {env_var}={value}[/green]")


# ── version ──────────────────────────────────────────────────────────────────

@app.command()
def version() -> None:
    """Show the cited CLI version."""
    console.print(f"cited v{__version__}")


# ── Input reading helper ─────────────────────────────────────────────────────

def _read_input(input_file: str | None) -> dict:
    """Read input JSON from a file or stdin."""
    if input_file:
        try:
            with open(input_file) as f:
                return json.load(f)
        except FileNotFoundError:
            err_console.print(f"[red]Input file not found: {input_file}[/red]")
            raise typer.Exit(1)
        except json.JSONDecodeError as e:
            err_console.print(f"[red]Invalid JSON in {input_file}: {e}[/red]")
            raise typer.Exit(1)

    # Read from stdin
    if sys.stdin.isatty():
        err_console.print("[red]No input provided. Pipe JSON via stdin or use --input file.json[/red]")
        raise typer.Exit(1)

    try:
        raw = sys.stdin.read()
        return json.loads(raw)
    except json.JSONDecodeError as e:
        err_console.print(f"[red]Invalid JSON on stdin: {e}[/red]")
        raise typer.Exit(1)
