"""Tests for ISA syntax highlighting."""

from __future__ import annotations

import pytest

from isareplace.highlight import _highlight_line


def _names(highlights: list) -> list[str]:
    """Extract just the highlight names from a highlight list."""
    return [h[2] for h in highlights]


def _text_for(line: str, name: str) -> list[str]:
    """Extract the text fragments highlighted with a given name."""
    return [line[h[0]:h[1]] for h in _highlight_line(line) if h[2] == name]


class TestComments:
    def test_double_slash_comment(self) -> None:
        line = "  s_mov_b32 s0, 0x1  // setup"
        names = _names(_highlight_line(line))
        assert "comment" in names

    def test_semicolon_comment(self) -> None:
        line = "  v_add_f32 v0, v1, v2 ; add"
        names = _names(_highlight_line(line))
        assert "comment" in names

    def test_full_line_comment(self) -> None:
        line = "// this is a comment"
        hl = _highlight_line(line)
        assert len(hl) == 1
        assert hl[0][2] == "comment"
        assert hl[0][0] == 0


class TestScalarOps:
    def test_s_mov(self) -> None:
        assert "keyword" in _names(_highlight_line("  s_mov_b32 s0, 0x1"))

    def test_s_waitcnt(self) -> None:
        assert "keyword" in _names(_highlight_line("  s_waitcnt vmcnt(0)"))

    def test_s_endpgm(self) -> None:
        assert "keyword" in _names(_highlight_line("  s_endpgm"))

    def test_s_cbranch(self) -> None:
        assert "keyword" in _names(_highlight_line("  s_cbranch_scc1 label_0001"))


class TestVectorOps:
    def test_v_add(self) -> None:
        assert "function" in _names(_highlight_line("  v_add_f32 v0, v1, v2"))

    def test_v_mul(self) -> None:
        assert "function" in _names(_highlight_line("  v_mul_f32 v3, v4, v5"))

    def test_v_cmp(self) -> None:
        assert "function" in _names(_highlight_line("  v_cmp_gt_f32 vcc, v0, v1"))

    def test_v_interp(self) -> None:
        assert "function" in _names(_highlight_line("  v_interp_p1_f32 v0, v1, attr0.x"))

    def test_v_mov(self) -> None:
        assert "function" in _names(_highlight_line("  v_mov_b32 v0, 0"))


class TestMemoryOps:
    def test_image_sample(self) -> None:
        assert "type" in _names(
            _highlight_line("  image_sample v[0:3], v4, s[0:7], s[8:11]")
        )

    def test_buffer_load(self) -> None:
        assert "type" in _names(
            _highlight_line("  buffer_load_dword v0, off, s[0:3], 0")
        )

    def test_s_buffer_load(self) -> None:
        # Must be classified as memory, not scalar
        names = _names(_highlight_line("  s_buffer_load_dword s0, s[4:7], 0x0"))
        assert "type" in names

    def test_global_load(self) -> None:
        assert "type" in _names(
            _highlight_line("  global_load_dword v0, v[1:2], off")
        )

    def test_ds_read(self) -> None:
        assert "type" in _names(
            _highlight_line("  ds_read_b32 v0, v1")
        )


class TestRegisters:
    def test_vector_register(self) -> None:
        frags = _text_for("  v_add_f32 v0, v1, v2", "variable.builtin")
        assert "v0" in frags
        assert "v1" in frags
        assert "v2" in frags

    def test_vector_register_range(self) -> None:
        frags = _text_for("  image_sample v[0:3], v4", "variable.builtin")
        assert any("v[0:3]" in f for f in frags)

    def test_scalar_register(self) -> None:
        frags = _text_for("  s_mov_b32 s0, s1", "variable")
        assert "s0" in frags
        assert "s1" in frags

    def test_scalar_register_range(self) -> None:
        frags = _text_for("  s_load_dword s0, s[4:5], 0x0", "variable")
        assert any("s[4:5]" in f for f in frags)

    def test_special_registers(self) -> None:
        for reg in ("exec", "vcc", "scc", "m0"):
            frags = _text_for(f"  s_mov_b64 {reg}, 0", "variable")
            assert reg in frags, f"{reg} not highlighted as variable"

    def test_exec_lo_hi(self) -> None:
        assert "exec_lo" in _text_for("  s_mov_b32 exec_lo, s0", "variable")


class TestLiterals:
    def test_hex_literal(self) -> None:
        frags = _text_for("  s_mov_b32 s0, 0xFF00FF00", "number")
        assert "0xFF00FF00" in frags

    def test_decimal_literal(self) -> None:
        frags = _text_for("  s_waitcnt vmcnt(0)", "number")
        assert "0" in frags


class TestLabels:
    def test_label_definition(self) -> None:
        hl = _highlight_line("label_0001:")
        names = _names(hl)
        assert "tag" in names

    def test_label_reference(self) -> None:
        frags = _text_for("  s_cbranch_scc1 label_0002", "tag")
        assert "label_0002" in frags


class TestAttributes:
    def test_attr(self) -> None:
        frags = _text_for("  v_interp_p1_f32 v0, v1, attr0.x", "string")
        assert "attr0.x" in frags

    def test_dmask(self) -> None:
        frags = _text_for("  image_sample v[0:3], v4, s[0:7], s[8:11] dmask:0xf", "string")
        assert any("dmask:" in f for f in frags)


class TestMixedLines:
    def test_full_instruction(self) -> None:
        """A realistic instruction should have multiple highlight types."""
        line = "  v_mul_f32 v0, s[0:1], v2  // multiply"
        names = set(_names(_highlight_line(line)))
        assert "function" in names  # v_mul_f32
        assert "variable.builtin" in names  # v0, v2
        assert "variable" in names  # s[0:1]
        assert "comment" in names  # // multiply

    def test_empty_line(self) -> None:
        assert _highlight_line("") == []
        assert _highlight_line("   ") == []
