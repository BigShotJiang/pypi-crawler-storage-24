"""Tests for CLI argument parsing."""

from __future__ import annotations

import pytest

from isareplace.cli import build_parser


class TestArgParsing:
    def test_minimal_args(self) -> None:
        args = build_parser().parse_args([
            "--gfxip=4040", "--wave_size=32", "--shader_type=PS",
            "input.bin", "output.bin",
        ])
        assert args.gfxip == 4040
        assert args.wave_size == 32
        assert args.shader_type == "PS"
        assert args.input_bin == "input.bin"
        assert args.output_bin == "output.bin"
        assert args.sp3 is None

    def test_with_sp3(self) -> None:
        args = build_parser().parse_args([
            "--gfxip=4020", "--wave_size=64", "--shader_type=CS",
            "--sp3=prev.sp3",
            "input.bin", "output.bin",
        ])
        assert args.sp3 == "prev.sp3"

    def test_all_shader_types(self) -> None:
        for st in ("PS", "GS", "CS"):
            args = build_parser().parse_args([
                "--gfxip=4010", "--wave_size=32", f"--shader_type={st}",
                "in.bin", "out.bin",
            ])
            assert args.shader_type == st

    def test_invalid_wave_size(self) -> None:
        with pytest.raises(SystemExit):
            build_parser().parse_args([
                "--gfxip=4040", "--wave_size=16", "--shader_type=PS",
                "in.bin", "out.bin",
            ])

    def test_invalid_shader_type(self) -> None:
        with pytest.raises(SystemExit):
            build_parser().parse_args([
                "--gfxip=4040", "--wave_size=32", "--shader_type=VS",
                "in.bin", "out.bin",
            ])

    def test_missing_required(self) -> None:
        with pytest.raises(SystemExit):
            build_parser().parse_args(["input.bin", "output.bin"])

    def test_headless_flag(self) -> None:
        args = build_parser().parse_args([
            "--gfxip=4040", "--wave_size=32", "--shader_type=PS",
            "--headless",
            "input.bin", "output.bin",
        ])
        assert args.headless is True

    def test_no_headless_by_default(self) -> None:
        args = build_parser().parse_args([
            "--gfxip=4040", "--wave_size=32", "--shader_type=PS",
            "input.bin", "output.bin",
        ])
        assert args.headless is False
