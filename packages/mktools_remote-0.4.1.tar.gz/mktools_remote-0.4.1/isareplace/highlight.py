"""ISA syntax highlighting for the Textual TextArea.

Provides a custom TextArea subclass with regex-based syntax coloring
for shader assembly, and a matching dark theme.
"""

from __future__ import annotations

import re
from collections import defaultdict

from rich.style import Style
from textual.widgets import TextArea
from textual.widgets.text_area import TextAreaTheme

# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------

ISA_THEME = TextAreaTheme(
    name="isa_dark",
    base_style=Style(color="#f8f8f2", bgcolor="#1e1e2e"),
    gutter_style=Style(color="#6c7086", bgcolor="#181825"),
    cursor_style=Style(color="#1e1e2e", bgcolor="#f5e0dc"),
    cursor_line_style=Style(bgcolor="#262637"),
    cursor_line_gutter_style=Style(color="#cdd6f4", bgcolor="#262637", bold=True),
    bracket_matching_style=Style(bgcolor="#45475a", bold=True),
    selection_style=Style(bgcolor="#45475a"),
    syntax_styles={
        # ISA categories mapped to highlight names
        "comment": Style(color="#6c7086", italic=True),
        "keyword": Style(color="#cba6f7"),           # scalar ops — purple
        "function": Style(color="#f9e2af"),           # vector ALU — gold
        "type": Style(color="#f38ba8"),               # memory/texture ops — rose
        "variable": Style(color="#89b4fa"),           # scalar registers — blue
        "variable.builtin": Style(color="#94e2d5"),   # vector registers — teal
        "number": Style(color="#fab387"),             # literals — peach
        "tag": Style(color="#a6e3a1"),                # labels — green
        "string": Style(color="#a6e3a1"),             # attributes — green
        "operator": Style(color="#f8f8f2"),           # punctuation
    },
)

# ---------------------------------------------------------------------------
# Classification patterns
# ---------------------------------------------------------------------------

# Memory ops must be checked before generic s_* to avoid misclassifying
# s_buffer_load, s_load, etc.
_MEMORY_OPS = re.compile(
    r"\b("
    r"image_\w+|"
    r"buffer_\w+|tbuffer_\w+|"
    r"global_\w+|flat_\w+|scratch_\w+|"
    r"ds_\w+|"
    r"s_buffer_load\w*|s_buffer_store\w*|"
    r"s_load_\w+|s_store_\w+|"
    r"s_atomic_\w+"
    r")\b"
)

_SCALAR_OPS = re.compile(r"\b(s_\w+)\b")
_VECTOR_OPS = re.compile(r"\b(v_\w+)\b")

_VREG = re.compile(r"\bv(?:\d+\b|\[\d+:\d+\])")
_SREG = re.compile(
    r"\b(?:s(?:\d+\b|\[\d+:\d+\])"
    r"|exec(?:_lo|_hi)?\b|vcc(?:_lo|_hi)?\b|scc\b|m0\b|null\b)"
)

_HEX_LITERAL = re.compile(r"\b0x[0-9a-fA-F]+\b")
_NUM_LITERAL = re.compile(r"(?<![a-zA-Z_])\d+(\.\d+)?\b")

_LABEL_DEF = re.compile(r"^(\s*)(label_\w+|BB\d+_\d+|\.L\w+)\s*:")
_LABEL_REF = re.compile(r"\b(label_\w+|BB\d+_\d+|\.L\w+)\b")

_ATTRIBUTE = re.compile(r"\b(attr\d+\.\w+|dmask:\S+|format:\S+|offset:\S+|glc|slc|dlc|unorm)\b")

_COMMENT = re.compile(r"(//|;).*$")


def _highlight_line(text: str) -> list[tuple[int, int | None, str]]:
    """Compute highlight ranges for a single line of ISA assembly.

    Returns list of (start_col, end_col, highlight_name) tuples.
    """
    highlights: list[tuple[int, int | None, str]] = []

    # Comments — everything from // or ; to end of line
    cm = _COMMENT.search(text)
    comment_start = cm.start() if cm else len(text)
    if cm:
        highlights.append((cm.start(), len(text), "comment"))

    # Only process non-comment portion
    code = text[:comment_start]
    if not code.strip():
        return highlights

    # Track which character positions are already highlighted (higher priority wins)
    claimed: set[int] = set()
    if cm:
        claimed.update(range(cm.start(), len(text)))

    def add(match: re.Match, name: str) -> None:
        s, e = match.start(), match.end()
        if not any(i in claimed for i in range(s, e)):
            highlights.append((s, e, name))
            claimed.update(range(s, e))

    # Label definitions (highest priority in code region)
    m = _LABEL_DEF.match(code)
    if m:
        highlights.append((m.start(2), m.end(2) + 1, "tag"))  # include colon
        claimed.update(range(m.start(2), m.end(2) + 1))

    # Memory ops (before generic s_* / v_*)
    for m in _MEMORY_OPS.finditer(code):
        add(m, "type")

    # Scalar ops
    for m in _SCALAR_OPS.finditer(code):
        add(m, "keyword")

    # Vector ops
    for m in _VECTOR_OPS.finditer(code):
        add(m, "function")

    # Attributes (before registers, so dmask:0xf doesn't split)
    for m in _ATTRIBUTE.finditer(code):
        add(m, "string")

    # Vector registers
    for m in _VREG.finditer(code):
        add(m, "variable.builtin")

    # Scalar registers
    for m in _SREG.finditer(code):
        add(m, "variable")

    # Label references (in branch targets, etc.)
    for m in _LABEL_REF.finditer(code):
        add(m, "tag")

    # Hex literals
    for m in _HEX_LITERAL.finditer(code):
        add(m, "number")

    # Numeric literals (only unclaimed positions)
    for m in _NUM_LITERAL.finditer(code):
        add(m, "number")

    return highlights


# ---------------------------------------------------------------------------
# Custom TextArea subclass
# ---------------------------------------------------------------------------

class ISATextArea(TextArea):
    """TextArea with ISA assembly syntax highlighting."""

    def __init__(self, *args, **kwargs) -> None:
        # Register theme before super().__init__ sets it via reactive watcher
        kwargs.pop("theme", None)
        super().__init__(*args, **kwargs)
        self.register_theme(ISA_THEME)
        self.theme = "isa_dark"

    def _build_highlight_map(self) -> None:
        """Override tree-sitter highlighting with regex-based ISA highlighting."""
        if hasattr(self, "_line_cache"):
            self._line_cache.clear()
        self._highlights.clear()

        lines = self.document.text.split("\n")
        for i, line in enumerate(lines):
            line_hl = _highlight_line(line)
            if line_hl:
                self._highlights[i] = line_hl
