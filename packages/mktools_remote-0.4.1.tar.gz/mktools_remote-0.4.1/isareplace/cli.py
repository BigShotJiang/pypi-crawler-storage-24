"""CLI entry point for isareplace."""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from isareplace.binary import (
    PaddingSeverity,
    assemble_output,
    compute_padding,
    parse_binary,
)
from isareplace.external import (
    assemble as ext_assemble,
    disassemble as ext_disassemble,
    gfxip_to_generation,
    resolve_tool_path,
)

VALID_SHADER_TYPES = ("PS", "GS", "CS")
VALID_WAVE_SIZES = (32, 64)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="isareplace",
        description="Edit and patch shader assembly binaries.",
    )
    parser.add_argument(
        "--gfxip",
        type=int,
        required=True,
        help="Architecture IP version (e.g. 4010, 4020, 4030, 4040, 4050)",
    )
    parser.add_argument(
        "--wave_size",
        type=int,
        choices=VALID_WAVE_SIZES,
        required=True,
        help="Wave size (32 or 64)",
    )
    parser.add_argument(
        "--shader_type",
        type=str,
        choices=VALID_SHADER_TYPES,
        required=True,
        help="Shader type (PS, GS, or CS)",
    )
    parser.add_argument(
        "--sp3",
        type=str,
        default=None,
        metavar="FILE",
        help="Previously-edited assembly file to resume from",
    )
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Use $EDITOR instead of the built-in TUI",
    )
    parser.add_argument(
        "input_bin",
        help="Original shader binary (source of padding and constants)",
    )
    parser.add_argument(
        "output_bin",
        help="Output path for the patched binary",
    )
    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    input_path = Path(args.input_bin)
    output_path = Path(args.output_bin)

    # Validate inputs
    if not input_path.is_file():
        _die(f"Input binary not found: {input_path}")

    if args.sp3 and not Path(args.sp3).is_file():
        _die(f"Assembly file not found: {args.sp3}")

    # Resolve gfxip and external tool
    try:
        generation = gfxip_to_generation(args.gfxip)
    except ValueError as e:
        _die(str(e))

    tool_path = resolve_tool_path(generation)

    # Parse the original binary
    original_data = input_path.read_bytes()
    try:
        layout = parse_binary(original_data)
    except ValueError as e:
        _die(f"Failed to parse input binary: {e}")

    # Get the assembly text — either disassemble or use --sp3
    if args.sp3:
        assembly_text = Path(args.sp3).read_text()
        sp3_source = args.sp3
    else:
        with tempfile.TemporaryDirectory() as tmpdir:
            sp3_path = Path(tmpdir) / "disassembly.sp3"
            print("Disassembling...", end=" ", flush=True)
            result = ext_disassemble(tool_path, generation, input_path, sp3_path)
            if not result.ok:
                _die(f"Disassembly failed:\n{result.stdout}\n{result.stderr}")
            if result.has_warnings:
                print("done (with warnings)")
                print(f"  {result.stderr.strip()}")
            else:
                print("done")
            assembly_text = sp3_path.read_text()
            sp3_source = None

    if args.headless:
        _run_headless(
            args, layout, original_data, assembly_text,
            tool_path, generation, output_path,
        )
    else:
        _run_tui(
            args, layout, original_data, assembly_text, sp3_source,
            tool_path, generation, output_path,
        )


def _run_tui(
    args,
    layout,
    original_data: bytes,
    assembly_text: str,
    sp3_source: str | None,
    tool_path: str,
    generation: int,
    output_path: Path,
) -> None:
    from isareplace.tui import IsareplaceApp, TuiContext

    ctx = TuiContext(
        layout=layout,
        original_data=original_data,
        assembly_text=assembly_text,
        tool_path=tool_path,
        generation=generation,
        shader_type=args.shader_type,
        wave_size=args.wave_size,
        gfxip=args.gfxip,
        output_path=output_path,
        sp3_source=sp3_source,
    )

    app = IsareplaceApp(ctx)
    app.run()

    # Post-exit summary
    if app.result.wrote_output:
        _print_summary(
            app.result.output_path,
            app.result.output_sp3,
            app.result.output_size,
            app.result.padding_result,
        )
    else:
        print("Exited without writing output.")


def _run_headless(
    args,
    layout,
    original_data: bytes,
    assembly_text: str,
    tool_path: str,
    generation: int,
    output_path: Path,
) -> None:
    _print_binary_info(layout, len(original_data))

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        work_sp3 = tmpdir / "edit.sp3"
        work_sp3.write_text(assembly_text)

        # Open in $EDITOR
        editor = os.environ.get("EDITOR", os.environ.get("VISUAL", ""))
        if not editor:
            for candidate in ("vi", "vim", "nano"):
                if shutil.which(candidate):
                    editor = candidate
                    break
        if not editor:
            _die(
                "No editor found. Set $EDITOR or $VISUAL, "
                "or ensure vi/vim/nano is on PATH."
            )

        print(f"Opening editor ({editor})...")
        editor_ret = subprocess.run([editor, str(work_sp3)])
        if editor_ret.returncode != 0:
            _die(f"Editor exited with code {editor_ret.returncode}")

        # Reassemble
        new_bin_path = tmpdir / "reassembled.bin"
        print("Assembling...", end=" ", flush=True)
        result = ext_assemble(
            tool_path, generation, args.shader_type, args.wave_size,
            work_sp3, new_bin_path,
        )
        if not result.ok:
            _die(f"Assembly failed:\n{result.stdout}\n{result.stderr}")
        if result.has_warnings:
            print("done (with warnings)")
            print(f"  {result.stderr.strip()}")
        else:
            print("done")

        # Compute padding and write output
        new_instructions = new_bin_path.read_bytes()
        try:
            padding_result = compute_padding(layout, len(new_instructions))
        except ValueError as e:
            _die(f"Padding error: {e}")

        final = assemble_output(
            new_instructions,
            padding_result.remaining_dwords,
            layout.constants_blob,
        )

        output_path.write_bytes(final)
        output_sp3 = output_path.with_suffix(".sp3")
        shutil.copy2(work_sp3, output_sp3)

    _print_summary(output_path, output_sp3, len(final), padding_result)


def _print_binary_info(layout, total_size: int) -> None:
    """Print information about the original binary."""
    print(f"Original binary: {total_size} bytes ({total_size // 4} DWORDs)")
    print(f"  Instructions: {layout.instruction_size} bytes ({layout.instruction_dwords} DWORDs)")
    print(f"  Padding: {layout.padding_dwords} DWORDs")
    if layout.padding_dwords == 0:
        print("  \033[31mWARNING: Original binary has zero padding — any size increase will fail.\033[0m")
    if layout.constants_blob:
        print(f"  Constants: {len(layout.constants_blob)} bytes")
    else:
        print("  Constants: none")


def _print_summary(output_path, output_sp3, output_size: int, padding_result) -> None:
    """Print post-write summary to the terminal."""
    print()
    print(f"Wrote {output_path} ({output_size} bytes)")
    print(f"Wrote {output_sp3}")

    sign = "+" if padding_result.delta_dwords >= 0 else ""
    print(f"Size delta: {sign}{padding_result.delta_dwords} DWORDs")

    remaining = padding_result.remaining_dwords
    total = padding_result.original_dwords
    severity = padding_result.severity

    color_code = {
        PaddingSeverity.GREEN: "\033[32m",
        PaddingSeverity.YELLOW: "\033[33m",
        PaddingSeverity.RED: "\033[31m",
    }[severity]
    reset = "\033[0m"
    print(f"Padding: {color_code}{remaining} / {total} DWORDs remaining{reset}")


def _die(msg: str) -> None:
    print(f"Error: {msg}", file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    main()
