"""Module: memoryfm.normalise.normalise_lastfmstats"""

from __future__ import annotations
import pandas as pd
from memoryfm.errors import SchemaError
from memoryfm.core.objects import ScrobbleLog
from memoryfm.util.date_input_check import (
    normalise_timestamps,
)


def normalise_lastfmstats(
    df: pd.DataFrame,
    username: str,
    tz: str | None = None,
    unit: str | None = "ms",
    source: str | None = "lastfmstats.com",
) -> ScrobbleLog:
    """ """
    df = df.rename(str.lower, axis=1)
    if "date" in df.columns:
        df["date"] = normalise_timestamps(df["date"], tz=tz, unit=unit)
    else:
        raise SchemaError("Column not found", "date")
    df = df.rename(columns={"date": "timestamp"})
    df = df.sort_values(by="timestamp")
    df = df.drop_duplicates(
        subset=["timestamp", "track", "artist", "album"], ignore_index=True
    )
    log = ScrobbleLog(df=df, username=username, tz=tz, source=source)
    return log


def normalise_spotify(
    df: pd.DataFrame,
    username: str | None = None,
    tz: str | None = None,
    min_duration_ms: int | None = 60000,
) -> ScrobbleLog:
    """ """
    expected_cols = [
        "ts",
        "ms_played",
        "master_metadata_album_artist_name",
        "master_metadata_album_artist_name",
        "master_metadata_track_name",
        "reason_end",
    ]
    column_map = {
        "ts": "timestamp",
        "ms_played": "duration",
        "master_metadata_track_name": "track",
        "master_metadata_album_artist_name": "artist",
        "master_metadata_album_album_name": "album",
    }
    for column in expected_cols:
        if column not in df.columns:
            raise SchemaError(f"Missing expected column: {column}", column)
    if min_duration_ms is not None and pd.api.types.is_numeric_dtype(df["ms_played"]):
        df = df[df["ms_played"] >= min_duration_ms]
    elif not pd.api.types.is_numeric_dtype(df["ms_played"]):
        raise SchemaError(
            "Column expected to contain only numeric values: 'ms_played'", "ms_played"
        )
    df = df.rename(columns=column_map)
    df = df[df["reason_end"] == "trackdone"]
    df["timestamp"] = normalise_timestamps(df["timestamp"], tz=tz, unit=None)
    df = df[["timestamp", "track", "artist", "album", "duration"]]
    return ScrobbleLog(df=df, username=username, tz=tz, source="spotify")
