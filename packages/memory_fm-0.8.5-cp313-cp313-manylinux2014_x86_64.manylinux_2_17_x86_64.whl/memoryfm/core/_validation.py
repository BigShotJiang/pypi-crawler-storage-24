from __future__ import annotations
import pandas as pd
from memoryfm.errors import SchemaError, InvalidDataError, InvalidTypeError
from memoryfm._version import __version__
from memoryfm.util.date_input_check import (
    validate_tz,
    normalise_timestamps,
)


def validate_df(df: pd.DataFrame, tz: str | None) -> pd.DataFrame:
    """
    Validate ScrobbleLog DataFrame
    """
    if not isinstance(df, pd.DataFrame):
        raise InvalidTypeError("Expecting a pandas DataFrame.")
    required_columns = ["timestamp", "track", "artist"]
    for column in required_columns:
        if column not in df.columns:
            raise SchemaError(f"Required DataFrame column not found: {column}", column)
    df = df.replace(r"^\s*$", None, regex=True)
    df = df.dropna(subset=required_columns)
    if not df.empty:
        tz = validate_tz(tz)
        with pd.option_context("mode.copy_on_write", True):
            df["timestamp"] = normalise_timestamps(df["timestamp"], tz=tz, unit="ms")
    if "album" not in df.columns:
        df["album"] = pd.NA
    if "duration" not in df.columns or df.dropna(subset=["duration"]).empty:
        df = df[["timestamp", "track", "artist", "album"]]
    else:
        df = df[["timestamp", "track", "artist", "album", "duration"]]
    df = df.convert_dtypes()
    df = df.reset_index(drop=True)
    return df


def validate_text(text: str, field: str) -> str:
    """ """

    if not isinstance(text, str | None):
        raise InvalidTypeError(f"Expecting string type value for {text}")
    elif text is not None and not text.strip():
        raise InvalidDataError(f"{field} cannot be just white-space")
    else:
        return text


def meta_generator(
    df: pd.DataFrame,
    username: str | None = None,
    tz: str | None = "Etc/UTC",
    source: str | None = "manual",
) -> dict:
    """
    Generate metadata for ScrobbleLog init
    """
    if not isinstance(df, pd.DataFrame):
        raise InvalidTypeError("Expecting a pandas DataFrame")
    if source == "spotify":
        listens = "num_listens"
    else:
        listens = "num_scrobbles"
    meta = {
        "username": validate_text(username, "username"),
        "tz": validate_tz(tz),
        listens: len(df),
        "date_range": {"start": None, "end": None},
        "source": source,
        "duration_present": False,
        "memory.fm_version": __version__,
        "schema_version": 2,
    }
    if df.get("duration") is not None:
        meta["duration_present"] = True
    if source is None:
        meta["source"] = "manual"
    if len(df):
        if "timestamp" in df.columns:
            meta["date_range"]["start"] = df["timestamp"].min().isoformat()
            meta["date_range"]["end"] = df["timestamp"].max().isoformat()
        else:
            raise SchemaError("Missing required column: timestamp", "timestamp")
    meta = validate_meta(meta)
    return meta


def validate_meta(meta: dict) -> dict:
    """
    Validate meta schema
    """
    if not isinstance(meta, dict):
        raise InvalidTypeError("Expecting a dict type value")
    if meta.get("source") == "spotify":
        listens = "num_listens"
    else:
        listens = "num_scrobbles"

    types = {
        "tz": [str, "str"],
        "memory.fm_version": [str, "str"],
        "schema_version": [int, "int"],
        listens: [int, "int"],
        "date_range": [dict, "dict"],
        "source": [str, "str"],
    }
    if "username" not in meta.keys():
        raise SchemaError("Missing key: username", "username")
    meta["username"] = validate_text(meta["username"], "username")
    for key in types.keys():
        if key not in meta.keys():
            raise SchemaError(f"Missing key: {key}", key)
        elif not isinstance(meta[key], types[key][0]):
            raise InvalidTypeError(
                f"Expecting {types[key][1]} type value for key: {key}]", key
            )
    meta["tz"] = validate_tz(meta["tz"])
    if meta[listens] < 0:
        raise InvalidDataError(
            f"Expecting non-negative integer value for key: {listens}", listens
        )
    for key in ["start", "end"]:
        if key not in meta["date_range"].keys():
            raise SchemaError(f'meta["date_range"] key not found: {key}', key)
        elif meta[listens] > 0 and not isinstance(meta["date_range"][key], str):
            raise InvalidTypeError(
                f'Expecting string type value for: meta["date_range"]["{key}"]'
            )
        elif not meta[listens] and meta["date_range"][key] is not None:
            raise InvalidDataError(f"If num_scrobbles is 0, {key} must be None type")
    if {"start", "end"} != set(meta["date_range"].keys()):
        raise SchemaError("date_range keys must be one of these : 'start', 'end'")
    validate_text(meta["source"], "source")
    return meta
