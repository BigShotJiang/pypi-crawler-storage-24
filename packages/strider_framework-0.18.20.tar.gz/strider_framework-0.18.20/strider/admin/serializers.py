"""
Auto-geração de schemas Pydantic a partir de models SQLAlchemy.

Introspecta Mapped[] columns e gera:
- ListSchema: campos para list view
- DetailSchema: todos os campos (read)
- WriteSchema: campos editáveis (create/update)
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, create_model

logger = logging.getLogger("strider.admin")


def _convert_value(value: Any) -> Any:
    """
    Converte valores para tipos serializáveis.
    
    - StructSchema -> dict (via to_dict())
    - datetime -> ISO string
    - UUID -> string
    - list/set -> lista serializada recursivamente
    - outros -> valor original
    """
    if value is None:
        return None
    
    # StructSchema (e classes similares com to_dict)
    if hasattr(value, "to_dict") and callable(value.to_dict):
        return value.to_dict()
    
    # datetime
    if isinstance(value, datetime):
        return value.isoformat()
    
    # UUID
    if isinstance(value, UUID):
        return str(value)
    
    # list/set - processar recursivamente
    if isinstance(value, (list, set)):
        return [_convert_value(item) for item in value]
    
    # dict - processar valores recursivamente
    if isinstance(value, dict):
        return {k: _convert_value(v) for k, v in value.items()}
    
    return value

# Mapa de tipos SQLAlchemy para tipos Python
_TYPE_MAP: dict[str, type] = {
    "INTEGER": int,
    "BIGINT": int,
    "SMALLINT": int,
    "VARCHAR": str,
    "STRING": str,
    "TEXT": str,
    "BOOLEAN": bool,
    "FLOAT": float,
    "NUMERIC": float,
    "DECIMAL": float,
    "DATETIME": datetime,
    "TIMESTAMP": datetime,
    "DATE": datetime,
    "JSON": dict,
    "JSONB": dict,
    "UUID": str,
}


def _get_python_type(col: Any) -> type:
    """Resolve o tipo Python de uma coluna SQLAlchemy."""
    col_type = str(col.type).upper()
    
    for key, python_type in _TYPE_MAP.items():
        if key in col_type:
            return python_type
    
    return str  # fallback


def generate_list_schema(
    model: type,
    admin: Any,
) -> type[BaseModel]:
    """
    Gera schema Pydantic para list view.
    
    Inclui apenas colunas em list_display.
    """
    model_name = model.__name__
    fields: dict[str, Any] = {}
    
    try:
        columns = {col.name: col for col in model.__table__.columns}
    except Exception:
        # Model sem tabela — retorna schema vazio
        return create_model(f"{model_name}ListSchema", __base__=_AdminSchema)
    
    display_fields = admin.list_display if admin.list_display else tuple(columns.keys())
    
    for field_name in display_fields:
        if field_name in columns:
            col = columns[field_name]
            python_type = _get_python_type(col)
            if col.nullable:
                fields[field_name] = (Optional[python_type], None)
            else:
                fields[field_name] = (python_type, ...)
        else:
            # Campo computado (método no ModelAdmin)
            fields[field_name] = (Optional[str], None)
    
    return create_model(
        f"{model_name}ListSchema",
        __base__=_AdminSchema,
        **fields,
    )


def generate_detail_schema(
    model: type,
    admin: Any,
) -> type[BaseModel]:
    """
    Gera schema Pydantic para detail view.
    
    Inclui todos os campos visíveis.
    """
    model_name = model.__name__
    fields: dict[str, Any] = {}
    
    try:
        columns = {col.name: col for col in model.__table__.columns}
    except Exception:
        return create_model(f"{model_name}DetailSchema", __base__=_AdminSchema)
    
    display_fields = admin.get_display_fields() if admin.get_display_fields() else list(columns.keys())
    
    for field_name in display_fields:
        if field_name in columns:
            col = columns[field_name]
            python_type = _get_python_type(col)
            if col.nullable:
                fields[field_name] = (Optional[python_type], None)
            else:
                fields[field_name] = (python_type, ...)
    
    return create_model(
        f"{model_name}DetailSchema",
        __base__=_AdminSchema,
        **fields,
    )


def generate_write_schema(
    model: type,
    admin: Any,
) -> type[BaseModel]:
    """
    Gera schema Pydantic para create/update.
    
    Exclui readonly_fields e campos em exclude.
    Garante proteção contra mass assignment.
    """
    model_name = model.__name__
    fields: dict[str, Any] = {}
    
    try:
        columns = {col.name: col for col in model.__table__.columns}
    except Exception:
        return create_model(f"{model_name}WriteSchema", __base__=_AdminSchema)
    
    editable = admin.get_editable_fields()
    
    for field_name in editable:
        if field_name in columns:
            col = columns[field_name]
            python_type = _get_python_type(col)
            
            # Campos com default ou nullable são opcionais no write
            if col.nullable or col.default is not None or col.server_default is not None:
                fields[field_name] = (Optional[python_type], None)
            else:
                fields[field_name] = (python_type, ...)
    
    return create_model(
        f"{model_name}WriteSchema",
        __base__=_AdminSchema,
        **fields,
    )


# Campos sensíveis: nunca serializar o valor real
_SENSITIVE_PATTERNS = frozenset({
    "password", "password_hash", "hashed_password", "password_digest",
    "passwd", "pwd", "new_password",
})
_SENSITIVE_SUFFIXES = ("_secret", "_token", "_hash", "_key", "_digest")


def _is_sensitive_field(name: str) -> bool:
    """Detecta se um campo contém dados sensíveis que não devem ser expostos."""
    lower = name.lower()
    if lower in _SENSITIVE_PATTERNS:
        return True
    return any(lower.endswith(s) for s in _SENSITIVE_SUFFIXES)


def serialize_instance(
    obj: Any,
    schema_fields: list[str],
    admin: Any = None,
    m2m_data: dict[str, list] | None = None,
) -> dict[str, Any]:
    """
    Serializa uma instância de model para dict.
    
    Suporta campos computados (métodos no ModelAdmin).
    Campos sensíveis (password, tokens, hashes) são mascarados.
    
    Args:
        obj: Instância do model
        schema_fields: Lista de campos para serializar
        admin: Instância do ModelAdmin (opcional)
        m2m_data: Dados M2M já conhecidos para evitar lazy load (opcional)
    """
    from sqlalchemy import inspect as sa_inspect
    from sqlalchemy.orm import RelationshipProperty
    
    data: dict[str, Any] = {}
    m2m_data = m2m_data or {}
    
    # Detecta campos M2M do model para evitar lazy load
    m2m_fields: set[str] = set()
    try:
        mapper = sa_inspect(type(obj))
        for rel_name, rel in mapper.relationships.items():
            if isinstance(rel, RelationshipProperty) and rel.secondary is not None:
                m2m_fields.add(rel_name)
    except Exception:
        pass
    
    for field_name in schema_fields:
        # Campos sensíveis — nunca expor valor real
        if _is_sensitive_field(field_name):
            data[field_name] = "••••••••"
            continue
        
        # Campos M2M — usa dados fornecidos ou lista vazia (evita lazy load)
        if field_name in m2m_fields:
            if field_name in m2m_data:
                data[field_name] = m2m_data[field_name]
            else:
                # Não tenta acessar o atributo para evitar lazy load
                data[field_name] = []
            continue
        
        # Tenta campo do model primeiro
        if hasattr(obj, field_name):
            value = getattr(obj, field_name)
            # M2M relationships — serialize as list of IDs (Issue #21)
            if isinstance(value, (list, set)):
                serialized = []
                for item in value:
                    if hasattr(item, "id"):
                        serialized.append(item.id if not isinstance(item.id, UUID) else str(item.id))
                    else:
                        serialized.append(str(item))
                data[field_name] = serialized
                continue
            # Converte tipos não serializáveis (StructSchema, datetime, UUID, etc.)
            data[field_name] = _convert_value(value)
        # Tenta método do ModelAdmin
        elif admin and hasattr(admin, field_name) and callable(getattr(admin, field_name)):
            method = getattr(admin, field_name)
            try:
                value = method(obj)
                data[field_name] = value
            except Exception:
                data[field_name] = None
        else:
            data[field_name] = None
    
    return data


class _AdminSchema(BaseModel):
    """Base schema para schemas auto-gerados do admin."""
    model_config = ConfigDict(from_attributes=True, arbitrary_types_allowed=True)
