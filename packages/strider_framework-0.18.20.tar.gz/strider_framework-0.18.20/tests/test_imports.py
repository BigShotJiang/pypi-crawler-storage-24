"""
Tests for module imports.

These tests ensure there are no circular imports or missing dependencies.
Run these BEFORE committing any changes!
"""

import pytest


class TestCoreImports:
    """Test that core modules can be imported without errors."""
    
    def test_import_core(self):
        """Test importing the main stride module."""
        import strider
        assert hasattr(strider, "__version__")
    
    def test_import_core_models(self):
        """Test importing stride.models."""
        from strider.models import Model, Field
        assert Model is not None
        assert Field is not None
    
    def test_import_core_views(self):
        """Test importing stride.views."""
        from strider.views import ViewSet, ModelViewSet, action
        assert ViewSet is not None
        assert ModelViewSet is not None
        assert action is not None
    
    def test_import_core_permissions(self):
        """Test importing stride.permissions."""
        from strider.permissions import (
            Permission,
            AllowAny,
            DenyAll,
            IsAuthenticated,
            IsAuthenticatedOrReadOnly,
            IsAdmin,
            IsOwner,
            HasRole,
            check_permissions,
        )
        assert Permission is not None
        assert IsAuthenticated is not None
    
    def test_import_core_exceptions(self):
        """Test importing stride.exceptions."""
        from strider.exceptions import (
            StrideException,
            ValidationException,
            DatabaseException,
            AuthException,
            InvalidToken,
            TokenExpired,
            PermissionDenied,
            NotFound,
            Unauthorized,
        )
        assert StrideException is not None
        assert InvalidToken is not None


class TestAuthImports:
    """Test that auth modules can be imported without circular import errors."""
    
    def test_import_auth_module(self):
        """Test importing the main auth module."""
        from strider.auth import (
            configure_auth,
            get_auth_config,
            AuthBackend,
            TokenBackend,
        )
        assert configure_auth is not None
    
    def test_import_auth_models(self):
        """Test importing auth models."""
        from strider.auth.models import (
            AbstractUser,
            AbstractUUIDUser,
            PermissionsMixin,
            Group,
            Permission,
        )
        assert AbstractUser is not None
        assert AbstractUUIDUser is not None
    
    def test_import_auth_tokens(self):
        """Test importing auth tokens."""
        from strider.auth.tokens import (
            create_access_token,
            create_refresh_token,
            decode_token,
            verify_token,
            JWTBackend,
        )
        assert create_access_token is not None
        assert JWTBackend is not None
    
    def test_import_auth_middleware(self):
        """Test importing auth middleware."""
        from strider.auth.middleware import (
            AuthenticationMiddleware,
            OptionalAuthenticationMiddleware,
            JWTAuthBackend,
            AuthenticatedUser,
        )
        assert AuthenticationMiddleware is not None
        assert JWTAuthBackend is not None
    
    def test_import_auth_decorators(self):
        """Test importing auth decorators."""
        from strider.auth.decorators import (
            HasPermission,
            IsInGroup,
            IsSuperuser,
            IsStaff,
            IsActive,
            require_permission,
            require_group,
            login_required,
        )
        assert HasPermission is not None
        assert login_required is not None
    
    def test_import_auth_helpers(self):
        """Test importing auth helpers."""
        from strider.auth.helpers import (
            get_request_user,
            is_authenticated,
            set_request_user,
        )
        assert get_request_user is not None
        assert is_authenticated is not None
    
    def test_import_auth_schemas(self):
        """Test importing auth schemas."""
        from strider.auth.schemas import (
            BaseRegisterInput,
            BaseLoginInput,
            TokenResponse,
            BaseUserOutput,
        )
        assert BaseRegisterInput is not None
        assert TokenResponse is not None
    
    def test_import_auth_views(self):
        """Test importing auth views."""
        from strider.auth.views import AuthViewSet
        assert AuthViewSet is not None


class TestMiddlewareImports:
    """Test that middleware modules can be imported."""
    
    def test_import_middleware(self):
        """Test importing stride.middleware."""
        from strider.middleware import (
            BaseMiddleware,
            configure_middleware,
            apply_middlewares,
            TimingMiddleware,
            RequestIDMiddleware,
            LoggingMiddleware,
        )
        assert BaseMiddleware is not None
        assert configure_middleware is not None


class TestDependenciesImports:
    """Test that dependencies can be imported."""
    
    def test_import_dependencies(self):
        """Test importing stride.dependencies."""
        from strider.dependencies import (
            get_db,
            get_current_user,
            get_optional_user,
            DatabaseSession,
            CurrentUser,
        )
        assert get_db is not None
        assert get_current_user is not None


class TestTenancyImports:
    """Test that tenancy modules can be imported."""
    
    def test_import_tenancy(self):
        """Test importing stride.tenancy."""
        from strider.tenancy import (
            TenantMixin,
            set_tenant,
            get_tenant,
            clear_tenant,
        )
        assert TenantMixin is not None
        assert set_tenant is not None


class TestMigrationsImports:
    """Test that migrations modules can be imported."""
    
    def test_import_migrations(self):
        """Test importing stride.migrations."""
        from strider.migrations import (
            MigrationEngine,
            Operation,
            CreateTable,
            DropTable,
        )
        assert MigrationEngine is not None
        assert CreateTable is not None


class TestImportOrder:
    """Test that imports work in various orders (to catch hidden circular deps)."""
    
    def test_permissions_before_auth(self):
        """Test importing permissions before auth."""
        from strider.permissions import IsAuthenticated
        from strider.auth import AuthViewSet
        assert IsAuthenticated is not None
        assert AuthViewSet is not None
    
    def test_auth_before_permissions(self):
        """Test importing auth before permissions."""
        from strider.auth import AuthViewSet
        from strider.permissions import IsAuthenticated
        assert AuthViewSet is not None
        assert IsAuthenticated is not None
    
    def test_views_before_auth(self):
        """Test importing views before auth."""
        from strider.views import ViewSet
        from strider.auth import AuthViewSet
        assert ViewSet is not None
        assert AuthViewSet is not None
    
    def test_all_together(self):
        """Test importing everything at once."""
        from stride import (
            Model,
            ViewSet,
            ModelViewSet,
        )
        from strider.auth import (
            AbstractUser,
            AuthViewSet,
            configure_auth,
        )
        from strider.permissions import (
            IsAuthenticated,
            AllowAny,
        )
        from strider.middleware import (
            BaseMiddleware,
        )
        assert Model is not None
        assert AuthViewSet is not None
        assert IsAuthenticated is not None
