# ViewSets

Auto-generate CRUD endpoints from models.

## Request Lifecycle

```mermaid
flowchart TB
    REQ[Request] --> PERM{Permission<br/>Check}
    PERM -->|Denied| R403[403 Forbidden]
    PERM -->|OK| ACTION{Action Type}
    
    ACTION -->|list| LIST[get_queryset → serialize_list]
    ACTION -->|create| CREATE[validate → perform_create → serialize]
    ACTION -->|retrieve| GET[get_object → serialize]
    ACTION -->|update| UPDATE[get_object → validate → perform_update]
    ACTION -->|destroy| DELETE[get_object → perform_destroy]
    
    LIST --> RESP[Response]
    CREATE --> RESP
    GET --> RESP
    UPDATE --> RESP
    DELETE --> RESP
    
    style PERM fill:#fff3e0
    style RESP fill:#c8e6c9
```

## Basic ViewSet

```python
from strider import ModelViewSet
from .models import Post

class PostViewSet(ModelViewSet):
    model = Post
```

Generated endpoints:

| Method | Path | Action |
|--------|------|--------|
| GET | /posts/ | `list` |
| POST | /posts/ | `create` |
| GET | /posts/{id} | `retrieve` |
| PUT | /posts/{id} | `update` |
| PATCH | /posts/{id} | `partial_update` |
| DELETE | /posts/{id} | `destroy` |

## Schemas

Control input/output data:

```python
from strider import ModelViewSet, InputSchema, OutputSchema
from .models import Post

class PostInput(InputSchema):
    title: str
    content: str
    published: bool = False

class PostOutput(OutputSchema):
    id: int
    title: str
    content: str
    published: bool
    created_at: datetime

class PostViewSet(ModelViewSet):
    model = Post
    input_schema = PostInput
    output_schema = PostOutput
```

## Permissions

```python
from strider import ModelViewSet
from strider.permissions import AllowAny, IsAuthenticated, IsAdminUser

class PostViewSet(ModelViewSet):
    model = Post
    
    # Default for all actions
    permission_classes = [IsAuthenticated]
    
    # Override per action
    permission_classes_by_action = {
        "list": [AllowAny],
        "retrieve": [AllowAny],
        "create": [IsAuthenticated],
        "update": [IsAuthenticated],
        "destroy": [IsAdminUser],
    }
```

## Custom Actions

```python
from strider import ModelViewSet, action
from fastapi import Response

class PostViewSet(ModelViewSet):
    model = Post
    
    @action(detail=True, methods=["POST"])
    async def publish(self, request, pk: int) -> dict:
        """POST /posts/{pk}/publish/"""
        post = await self.get_object(pk)
        post.published = True
        await post.save()
        return {"status": "published"}
    
    @action(detail=False, methods=["GET"])
    async def recent(self, request) -> list[dict]:
        """GET /posts/recent/"""
        posts = await Post.objects.filter(published=True).order_by("-created_at").limit(5).all()
        return [self.serialize(p) for p in posts]
```

### Action Options

```python
@action(
    detail=True,           # True: /posts/{pk}/action/, False: /posts/action/
    methods=["POST"],      # HTTP methods
    url_path="custom-path", # Override URL path
    permission_classes=[IsAdminUser],  # Override permissions
)
```

### Automatic Route Resolution (No Manual Priority)

Custom actions are now registered with an automatic specificity sorter:

- static paths first (`/posts/list`)
- dynamic paths later (`/posts/{slug}`)
- wildcard/regex patterns last (`/posts/{path:path}`)

This avoids common collisions like `list` being captured by a dynamic `{name}` route.

Optional ViewSet knobs:

```python
class PostViewSet(ModelViewSet):
    model = Post
    # warn | raise | ignore
    route_conflict_policy = "warn"

    # Optional custom sorter:
    # (action_name, url_path, detail) -> tuple
    custom_action_sort_key = staticmethod(
        lambda action_name, url_path, detail: (0, action_name)
    )
```

## Hooks

Override lifecycle methods:

```python
class PostViewSet(ModelViewSet):
    model = Post
    
    async def perform_create(self, instance, validated_data: dict) -> None:
        """Called after create, before save."""
        instance.author_id = self.request.user.id
        await instance.save()
    
    async def perform_update(self, instance, validated_data: dict) -> None:
        """Called after update, before save."""
        instance.updated_by = self.request.user.id
        await instance.save()
    
    async def perform_destroy(self, instance) -> None:
        """Called before delete."""
        # Soft delete instead
        instance.deleted = True
        await instance.save()
```

## QuerySet Filtering

```python
class PostViewSet(ModelViewSet):
    model = Post
    
    def get_queryset(self, db):
        """Filter queryset based on request."""
        qs = super().get_queryset(db)
        
        # Only show user's own posts
        if not self.request.user.is_staff:
            qs = qs.filter(author_id=self.request.user.id)
        
        return qs
```

## Pagination

```python
class PostViewSet(ModelViewSet):
    model = Post
    page_size = 20  # Default: 25
```

Query params: `?page=1&per_page=20`

Response:

```json
{
  "items": [...],
  "total": 100,
  "page": 1,
  "per_page": 20,
  "pages": 5
}
```

## Read-Only ViewSet

```python
from strider import ReadOnlyModelViewSet

class PostViewSet(ReadOnlyModelViewSet):
    model = Post
    # Only list and retrieve, no create/update/delete
```

## Routes

```python
# src/apps/posts/routes.py
from strider import AutoRouter
from .views import PostViewSet

router = AutoRouter(prefix="/posts", tags=["Posts"])
router.register("", PostViewSet)
```

```python
# src/main.py
from strider import StrideApp, AutoRouter
from src.apps.posts.routes import router as posts_router

api = AutoRouter(prefix="/api/v1")
api.include_router(posts_router)

app = StrideApp(routers=[api])
```

## Next

- [Auth](05-auth.md) — Authentication
- [Permissions](08-permissions.md) — Access control
