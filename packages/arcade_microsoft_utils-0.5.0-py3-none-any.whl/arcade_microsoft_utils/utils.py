import urllib.parse
from typing import Any

from arcade_mcp_server.exceptions import ToolExecutionError

# Official Microsoft Graph service root hostnames for all national clouds.
# Source: https://learn.microsoft.com/en-us/graph/deployments
# Archived: https://web.archive.org/web/2025/https://learn.microsoft.com/en-us/graph/deployments
ALLOWED_GRAPH_HOSTS = frozenset({
    "graph.microsoft.com",  # Global
    "graph.microsoft.us",  # US Government L4 (GCC High)
    "dod-graph.microsoft.us",  # US Government L5 (DOD)
    "microsoftgraph.chinacloudapi.cn",  # China (21Vianet)
})


def validate_pagination_url(url: str) -> None:
    """Reject pagination tokens that don't point to the Microsoft Graph API.

    The Microsoft Graph SDK attaches the caller's OAuth bearer token to every
    outgoing request, including those constructed via ``with_url()``.  If a
    pagination token is replaced with an attacker-controlled URL (e.g. via
    prompt injection), the token would be sent to that host.  This guard
    ensures only legitimate Graph API hosts are accepted.
    """
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https":
        raise ToolExecutionError(
            f"Invalid pagination token: scheme '{parsed.scheme}' is not allowed. "
            f"Only HTTPS is accepted."
        )
    if parsed.hostname not in ALLOWED_GRAPH_HOSTS:
        raise ToolExecutionError(
            f"Invalid pagination token: URL host '{parsed.hostname}' is not a "
            f"recognized Microsoft Graph endpoint."
        )


def human_friendly_bytes_size(size: int) -> str:
    """Convert a bytes size to a human friendly string using binary units."""
    if size < 1024:
        value, unit = f"{size}", "B"
    elif size < 1024 * 1024:
        value, unit = f"{size / 1024:.1f}", "KiB"
    elif size < 1024 * 1024 * 1024:
        value, unit = f"{size / (1024 * 1024):.1f}", "MiB"
    elif size < 1024 * 1024 * 1024 * 1024:
        value, unit = f"{size / (1024 * 1024 * 1024):.1f}", "GiB"
    else:
        value, unit = f"{size / (1024 * 1024 * 1024 * 1024):.1f}", "TiB"

    return f"{value.replace('.0', '')} {unit}"


def remove_none_values(data: dict[str, Any]) -> dict[str, Any]:
    """Remove None values from a dictionary."""
    return {k: v for k, v in data.items() if v is not None}
