"""HTTP client for trace upload to the Canary QA API."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import httpx

from canary_sdk.buffer import TraceBuffer
from canary_sdk.types import SDKConfig, TraceData

if TYPE_CHECKING:
    from canary_sdk.decorators import trace_decorator
    from canary_sdk.litellm_callback import CanaryCallback
    from canary_sdk.redaction import RedactionEngine

logger = logging.getLogger("canary_sdk.client")


class CanaryClient:
    """Main SDK client that owns the buffer, HTTP transport, and optional redaction."""

    def __init__(self, config: SDKConfig) -> None:
        self._config = config
        self._http = httpx.Client(
            base_url=config.endpoint,
            timeout=httpx.Timeout(10.0),
            headers={"X-API-Key": config.api_key},
        )
        self._buffer = TraceBuffer(
            upload_fn=self._upload,
            max_batch=config.flush_batch_size,
            flush_interval=config.flush_interval,
            max_buffer=config.buffer_size,
        )
        self._redaction_engine: RedactionEngine | None = None
        if config.redact_phi:
            try:
                from canary_sdk.redaction import RedactionEngine
                self._redaction_engine = RedactionEngine()
            except Exception:
                logger.warning("Failed to initialize PHI redaction engine; redaction disabled")

    def capture(
        self,
        ai_input: str,
        ai_output: str,
        **kwargs,
    ) -> None:
        """Capture a trace. NEVER raises -- wraps everything in try/except."""
        try:
            trace = TraceData(ai_input=ai_input, ai_output=ai_output, **kwargs)
            trace_dict = trace.model_dump(exclude_none=True)

            if self._redaction_engine:
                redacted_input, input_manifest = self._redaction_engine.redact(trace_dict["ai_input"])
                redacted_output, output_manifest = self._redaction_engine.redact(trace_dict["ai_output"])
                trace_dict["ai_input"] = redacted_input
                trace_dict["ai_output"] = redacted_output
                manifest = input_manifest + output_manifest
                if manifest:
                    if "metadata" not in trace_dict or trace_dict["metadata"] is None:
                        trace_dict["metadata"] = {}
                    trace_dict["metadata"]["_redaction_manifest"] = manifest

            self._buffer.add(trace_dict)
        except Exception:
            logger.debug("capture() failed silently")

    def _upload(self, batch: list[dict]) -> None:
        """POST batch to /v1/traces. Silent on any error."""
        self._http.post("/v1/traces", json={"traces": batch})

    def litellm_callback(self) -> CanaryCallback:
        """Return a LiteLLM-compatible callback handler."""
        from canary_sdk.litellm_callback import CanaryCallback
        return CanaryCallback(client=self)

    def trace_decorator(self, func=None, *, name: str | None = None, tags: list[str] | None = None):
        """Return a @trace decorator that captures function I/O."""
        from canary_sdk.decorators import trace_decorator
        return trace_decorator(client=self, func=func, name=name, tags=tags)

    def capture_agent_task(
        self,
        task: str,
        claim: str,
        verify_fn=None,
        verification_result=None,
        sync: bool = False,
        **kwargs,
    ) -> None:
        """Capture an agent task completion claim for honesty evaluation.

        Submits a trace tagged 'agent_task' with the verification result
        in metadata. Canary's Gemini judge will verdict the claim as
        honest, exaggerated, or fabricated.

        Args:
            task:                Task description given to the agent.
            claim:               Agent's completion claim.
            verify_fn:           Optional callable returning actual result.
            verification_result: Pre-computed verification string.
            sync:                If True, flush immediately after capture.
            **kwargs:            Additional trace fields (model, tags, etc.).
        """
        from canary_sdk.agent import capture_agent_task
        capture_agent_task(
            client=self,
            task=task,
            claim=claim,
            verify_fn=verify_fn,
            verification_result=verification_result,
            sync=sync,
            **kwargs,
        )

    def flush(self) -> None:
        """Flush all buffered traces immediately."""
        self._buffer.flush()

    def shutdown(self, timeout: float = 5.0) -> None:
        """Shut down the background buffer and HTTP client."""
        self._buffer.shutdown(timeout=timeout)
        try:
            self._http.close()
        except Exception:
            pass
