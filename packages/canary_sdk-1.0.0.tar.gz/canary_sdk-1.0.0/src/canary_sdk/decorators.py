"""@trace decorator for sync and async functions.

Captures function input arguments and return value as a trace,
with timing information. If capture fails, the original function's
return value is still returned unmodified.
"""

from __future__ import annotations

import asyncio
import functools
import logging
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from canary_sdk.client import CanaryClient

logger = logging.getLogger("canary_sdk.decorators")


def trace_decorator(
    client: CanaryClient,
    func=None,
    *,
    name: str | None = None,
    tags: list[str] | None = None,
):
    """Create a decorator that captures function I/O as a trace.

    Supports both sync and async functions. If the function is passed
    directly (no parentheses), wraps it immediately. Otherwise returns
    a decorator.
    """

    def decorator(fn):
        trace_name = name or fn.__name__
        trace_tags = tags or []

        if asyncio.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(*args, **kwargs):
                start = time.monotonic()
                result = await fn(*args, **kwargs)
                elapsed_ms = int((time.monotonic() - start) * 1000)
                try:
                    client.capture(
                        ai_input=str(args) + (str(kwargs) if kwargs else ""),
                        ai_output=str(result),
                        metadata={"trace_name": trace_name},
                        tags=trace_tags,
                        latency_ms=elapsed_ms,
                    )
                except Exception:
                    logger.debug("Trace capture failed for async %s", trace_name)
                return result

            return async_wrapper
        else:

            @functools.wraps(fn)
            def sync_wrapper(*args, **kwargs):
                start = time.monotonic()
                result = fn(*args, **kwargs)
                elapsed_ms = int((time.monotonic() - start) * 1000)
                try:
                    client.capture(
                        ai_input=str(args) + (str(kwargs) if kwargs else ""),
                        ai_output=str(result),
                        metadata={"trace_name": trace_name},
                        tags=trace_tags,
                        latency_ms=elapsed_ms,
                    )
                except Exception:
                    logger.debug("Trace capture failed for %s", trace_name)
                return result

            return sync_wrapper

    if func is not None:
        return decorator(func)
    return decorator
