"""Daemon thread buffer with batch flush for zero-latency trace capture.

The buffer uses a queue.Queue (thread-safe) with a daemon thread that
flushes batches either when max_batch is reached or flush_interval
seconds have passed -- whichever comes first.
"""

from __future__ import annotations

import logging
import queue
import threading
import time
from typing import Callable

logger = logging.getLogger("canary_sdk.buffer")


class TraceBuffer:
    """Fire-and-forget buffer that batches traces and flushes via upload_fn.

    Args:
        upload_fn: Callable that receives a list[dict] and sends them to the API.
        max_batch: Number of traces per flush batch (default 25).
        flush_interval: Seconds between deadline-based flushes (default 5.0).
        max_buffer: Maximum queue capacity; traces beyond this are silently dropped (default 1000).
    """

    def __init__(
        self,
        upload_fn: Callable[[list[dict]], None],
        max_batch: int = 25,
        flush_interval: float = 5.0,
        max_buffer: int = 1000,
    ) -> None:
        self._upload_fn = upload_fn
        self._max_batch = max_batch
        self._flush_interval = flush_interval
        self._queue: queue.Queue[dict] = queue.Queue(maxsize=max_buffer)
        self._shutdown_event = threading.Event()
        self._thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._thread.start()

    def add(self, trace: dict) -> bool:
        """Add a trace to the buffer. Returns False if buffer is full (silent drop)."""
        try:
            self._queue.put_nowait(trace)
            return True
        except queue.Full:
            return False

    def _flush_loop(self) -> None:
        """Background loop: collect traces and flush when batch is full or deadline expires."""
        while not self._shutdown_event.is_set():
            batch: list[dict] = []
            deadline = time.monotonic() + self._flush_interval

            while len(batch) < self._max_batch:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                try:
                    item = self._queue.get(timeout=min(remaining, 0.1))
                    batch.append(item)
                except queue.Empty:
                    if self._shutdown_event.is_set():
                        break
                    continue

            if batch:
                self._do_upload(batch)

    def _do_upload(self, batch: list[dict]) -> None:
        """Upload a batch, silently swallowing any exception."""
        try:
            self._upload_fn(batch)
        except Exception:
            logger.debug("Upload failed, silently dropping %d traces", len(batch))

    def flush(self) -> None:
        """Manually drain the queue and upload all pending traces."""
        batch: list[dict] = []
        while True:
            try:
                batch.append(self._queue.get_nowait())
            except queue.Empty:
                break
        if batch:
            self._do_upload(batch)

    def shutdown(self, timeout: float = 5.0) -> None:
        """Signal shutdown, flush remaining traces, and join the background thread."""
        self._shutdown_event.set()
        self._thread.join(timeout=timeout)
        # Drain anything left after the thread stops
        self.flush()
