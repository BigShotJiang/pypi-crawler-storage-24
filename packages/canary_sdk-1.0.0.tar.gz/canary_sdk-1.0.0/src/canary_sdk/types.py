"""Pydantic models for the Canary SDK."""

from __future__ import annotations

from pydantic import BaseModel, Field


class SDKConfig(BaseModel):
    """Configuration for the Canary SDK."""

    api_key: str
    endpoint: str = "https://api.canaryqa.ai"
    redact_phi: bool = True
    buffer_size: int = 1000
    flush_interval: float = 5.0
    flush_batch_size: int = 25


class TraceData(BaseModel):
    """A single trace captured by the SDK."""

    ai_input: str
    ai_output: str
    metadata: dict | None = None
    model: str | None = None
    provider: str | None = None
    tags: list[str] = Field(default_factory=list)
    latency_ms: int | None = None
    token_count_input: int | None = None
    token_count_output: int | None = None
    cost_cents: float | None = None
