"""Canary SDK -- The QA SDK for AI.

Python client for the Canary QA Platform. Wraps any AI call
to capture I/O telemetry with zero added latency.

Public API:
    init(api_key, **kwargs)                 - Initialize the SDK
    callback()                              - Get a LiteLLM-compatible callback handler
    trace(func)                             - Decorator to capture function I/O
    capture_agent_task(task, claim, ...)    - Capture agent task for honesty eval
    flush()                                 - Flush all buffered traces
    shutdown(timeout=5.0)                   - Shut down the SDK gracefully

Agent support:
    AgentTaskCapture                        - Context manager for agent task capture

Drop-in wrappers (no LiteLLM required):
    from canary_sdk.wrappers.openai import OpenAI      - drop-in for openai.OpenAI
    from canary_sdk.wrappers.openai import AsyncOpenAI  - drop-in for openai.AsyncOpenAI
    from canary_sdk.wrappers.anthropic import Anthropic - drop-in for anthropic.Anthropic
    from canary_sdk.wrappers.anthropic import AsyncAnthropic
    All wrappers accept canary_api_key= or auto-detect canary_sdk.init() global client.
    OpenRouter: OpenAI(base_url="https://openrouter.ai/api/v1", api_key="sk-or-...",
                       canary_api_key="cny_live_sk_...")
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from canary_sdk.agent import AgentTaskCapture

if TYPE_CHECKING:
    from canary_sdk.client import CanaryClient

__version__ = "0.1.0"

_client: CanaryClient | None = None


def init(api_key: str, **kwargs) -> None:
    """Initialize the Canary SDK.

    Args:
        api_key: Your Canary API key (e.g., cny_live_sk_...).
        **kwargs: Optional overrides -- endpoint, redact_phi, buffer_size,
                  flush_interval, flush_batch_size.
    """
    global _client
    from canary_sdk.client import CanaryClient
    from canary_sdk.types import SDKConfig

    config = SDKConfig(api_key=api_key, **kwargs)
    _client = CanaryClient(config)


def callback():
    """Return a LiteLLM-compatible callback handler.

    Raises:
        RuntimeError: If init() has not been called yet.
    """
    if _client is None:
        raise RuntimeError(
            "Canary SDK not initialized. Call canary_sdk.init(api_key=...) first."
        )
    return _client.litellm_callback()


def trace(func=None, *, name: str | None = None, tags: list[str] | None = None):
    """Decorator to capture function input/output as a trace.

    Can be used with or without parentheses:
        @canary_sdk.trace
        def my_func(): ...

        @canary_sdk.trace(name="custom", tags=["prod"])
        def my_func(): ...

    Raises:
        RuntimeError: If init() has not been called yet.
    """
    if _client is None:
        raise RuntimeError(
            "Canary SDK not initialized. Call canary_sdk.init(api_key=...) first."
        )
    return _client.trace_decorator(func=func, name=name, tags=tags)


def capture_agent_task(
    task: str,
    claim: str,
    verify_fn=None,
    verification_result=None,
    sync: bool = False,
    **kwargs,
) -> None:
    """Capture an agent task completion claim for honesty evaluation.

    Submits a trace tagged 'agent_task' so Canary can independently verify
    whether the agent's completion claim was honest, exaggerated, or fabricated.

    Args:
        task:                Task description given to the agent.
        claim:               The agent's completion claim.
        verify_fn:           Optional callable returning actual result.
        verification_result: Pre-computed verification result string.
        sync:                If True, flush immediately after capture.
        **kwargs:            Additional trace fields (model, tags, metadata).

    Raises:
        RuntimeError: If init() has not been called yet.
        ValueError: If neither verify_fn nor verification_result is provided.
    """
    if _client is None:
        raise RuntimeError(
            "Canary SDK not initialized. Call canary_sdk.init(api_key=...) first."
        )
    _client.capture_agent_task(
        task=task,
        claim=claim,
        verify_fn=verify_fn,
        verification_result=verification_result,
        sync=sync,
        **kwargs,
    )


def flush() -> None:
    """Flush all buffered traces immediately."""
    if _client is not None:
        _client.flush()


def shutdown(timeout: float = 5.0) -> None:
    """Shut down the SDK gracefully, flushing remaining traces."""
    if _client is not None:
        _client.shutdown(timeout=timeout)


__all__ = [
    "init",
    "callback",
    "trace",
    "capture_agent_task",
    "flush",
    "shutdown",
    "AgentTaskCapture",
]
