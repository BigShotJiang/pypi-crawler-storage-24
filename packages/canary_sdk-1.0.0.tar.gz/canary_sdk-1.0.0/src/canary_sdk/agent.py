"""Agent task capture helpers for the Canary SDK.

Provides capture_agent_task() for submitting agent completion claims
along with independent verification results for honesty evaluation.

Exports:
    capture_agent_task: Submit an agent task trace with verification result.
    AgentTaskCapture:   Context manager for wrapping agent task execution.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

logger = logging.getLogger("canary_sdk.agent")


def capture_agent_task(
    client,
    task: str,
    claim: str,
    verify_fn: Callable[[], Any] | None = None,
    verification_result: str | None = None,
    sync: bool = False,
    **kwargs,
) -> dict | None:
    """Capture an agent task completion claim for honesty evaluation.

    Submits a trace tagged with "agent_task" so Canary can independently
    verify whether the agent's completion claim was honest.

    Either verify_fn or verification_result must be provided. If verify_fn
    is given, it is called synchronously to produce the actual result string.

    Args:
        client:              The CanaryClient instance.
        task:                The task description given to the agent.
        claim:               The agent's completion claim (what it said it did).
        verify_fn:           Optional callable returning the actual result.
                             Called immediately; result is str()-converted.
        verification_result: Pre-computed verification result string.
                             Used when verify_fn is not provided.
        sync:                If True, flush immediately after capture so the
                             trace uploads before this call returns.
        **kwargs:            Additional trace fields (model, tags, metadata).

    Returns:
        None normally. The trace is buffered and uploaded asynchronously
        unless sync=True.

    Raises:
        ValueError: If neither verify_fn nor verification_result is provided.
    """
    if verify_fn is None and verification_result is None:
        raise ValueError(
            "capture_agent_task requires either verify_fn or verification_result"
        )

    # Run the verification function to get ground truth
    actual_result: str
    if verify_fn is not None:
        try:
            raw = verify_fn()
            actual_result = str(raw)
        except Exception as exc:
            actual_result = f"verification_error: {exc}"
    else:
        actual_result = str(verification_result)

    # Merge agent_task tag + verification_result into metadata
    existing_tags: list[str] = list(kwargs.pop("tags", []))
    if "agent_task" not in existing_tags:
        existing_tags = ["agent_task"] + existing_tags

    existing_meta: dict = dict(kwargs.pop("metadata", {}) or {})
    existing_meta["verification_result"] = actual_result

    client.capture(
        ai_input=task,
        ai_output=claim,
        tags=existing_tags,
        metadata=existing_meta,
        **kwargs,
    )

    if sync:
        client.flush()

    return None


class AgentTaskCapture:
    """Context manager for capturing agent task execution.

    Usage:
        with AgentTaskCapture(canary, task="write file test.txt") as cap:
            # agent does work here...
            cap.claim = "I created test.txt with the requested content"
        # On exit: calls verify_fn and captures the trace automatically

    The verify_fn is called on context exit, after the agent has run,
    which is the natural point for filesystem or command verification.
    """

    def __init__(
        self,
        client,
        task: str,
        verify_fn: Callable[[], Any] | None = None,
        sync: bool = False,
        **kwargs,
    ) -> None:
        self._client = client
        self._task = task
        self._verify_fn = verify_fn
        self._sync = sync
        self._kwargs = kwargs
        self.claim: str = ""

    def __enter__(self) -> AgentTaskCapture:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if exc_type is not None:
            # Don't capture on exception — agent didn't complete
            return

        try:
            capture_agent_task(
                client=self._client,
                task=self._task,
                claim=self.claim,
                verify_fn=self._verify_fn,
                sync=self._sync,
                **self._kwargs,
            )
        except Exception:
            logger.debug("AgentTaskCapture.__exit__ failed silently")
