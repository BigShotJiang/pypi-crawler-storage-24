"""Drop-in OpenAI wrapper for Canary SDK.

Usage:
    from canary_sdk.wrappers.openai import OpenAI
    client = OpenAI(api_key="sk-...", canary_api_key="cny_live_sk_...")

    # Or if canary_sdk.init() was already called:
    from canary_sdk.wrappers.openai import OpenAI
    client = OpenAI(api_key="sk-...")

This is a drop-in replacement for openai.OpenAI. It captures every
chat.completions.create() call via a background queue — zero latency added.
Works with OpenRouter (base_url="https://openrouter.ai/api/v1") and any
OpenAI-compatible endpoint.
"""
from __future__ import annotations

import time
import logging

from canary_sdk.wrappers._base import _CaptureMixin, _SENTINEL  # noqa: F401

logger = logging.getLogger("canary_sdk.wrappers.openai")


try:
    import openai as _openai_module

    class OpenAI(_CaptureMixin, _openai_module.OpenAI):
        """Drop-in replacement for openai.OpenAI with automatic Canary capture."""

        def __init__(self, *args, canary_api_key=None, canary_endpoint=None,
                     canary_feature_tag: str | None = None, **kwargs):
            self._canary_feature_tag = canary_feature_tag
            super().__init__(*args, canary_api_key=canary_api_key, canary_endpoint=canary_endpoint, **kwargs)

        @property
        def chat(self):
            parent_chat = super().chat
            wrapper = self

            class _WrappedCompletions:
                def create(self_, messages, **kwargs):
                    tags = [wrapper._canary_feature_tag] if wrapper._canary_feature_tag else []
                    return wrapper._wrap_create(
                        parent_chat.completions.create, messages=messages, tags=tags, **kwargs,
                    )

            class _WrappedChat:
                completions = _WrappedCompletions()

            return _WrappedChat()

    class AsyncOpenAI(_CaptureMixin, _openai_module.AsyncOpenAI):
        """Drop-in replacement for openai.AsyncOpenAI with automatic Canary capture."""

        def __init__(self, *args, canary_api_key=None, canary_endpoint=None,
                     canary_feature_tag: str | None = None, **kwargs):
            self._canary_feature_tag = canary_feature_tag
            super().__init__(*args, canary_api_key=canary_api_key, canary_endpoint=canary_endpoint, **kwargs)

        @property
        def chat(self):
            parent_chat = super().chat
            wrapper = self

            class _WrappedCompletions:
                async def create(self_, messages, **kwargs):
                    tags = [wrapper._canary_feature_tag] if wrapper._canary_feature_tag else []
                    ai_input = str(messages)
                    start = time.monotonic()
                    response = await parent_chat.completions.create(messages=messages, **kwargs)
                    if not kwargs.get("stream"):
                        wrapper._extract_and_enqueue(response=response, ai_input=ai_input, start_time=start, tags=tags)
                    return response

            class _WrappedChat:
                completions = _WrappedCompletions()

            return _WrappedChat()

except ImportError:
    class OpenAI:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs):
            raise ImportError("openai package is required: pip install openai")

    class AsyncOpenAI:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs):
            raise ImportError("openai package is required: pip install openai")
