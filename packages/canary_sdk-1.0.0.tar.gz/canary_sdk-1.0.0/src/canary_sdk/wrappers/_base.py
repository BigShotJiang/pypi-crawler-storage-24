"""Shared capture infrastructure for Canary SDK wrappers.

This module owns _CaptureMixin — the background-queue capture base class used
by both the OpenAI and Anthropic wrappers.  Nothing here is provider-specific.
"""
from __future__ import annotations

import queue
import threading
import time
import logging
from typing import Any

logger = logging.getLogger("canary_sdk.wrappers._base")

_SENTINEL = object()


def _get_global_client():
    """Return the global CanaryClient if canary_sdk.init() was called, else None."""
    try:
        import canary_sdk
        return canary_sdk._client
    except Exception:
        return None


class _CaptureMixin:
    """Mixin that adds background capture to an OpenAI client subclass."""

    def __init__(self, *args, canary_api_key: str | None = None, canary_endpoint: str | None = None, **kwargs):
        self._canary_api_key = canary_api_key
        self._canary_endpoint = canary_endpoint
        self._canary_client = None
        self._capture_queue: queue.SimpleQueue = queue.SimpleQueue()
        super().__init__(*args, **kwargs)  # call before starting thread
        self._drain_thread = threading.Thread(target=self._drain_loop, daemon=True)
        self._drain_thread.start()

    def _resolve_client(self):
        if self._canary_client is not None:
            return self._canary_client
        global_client = _get_global_client()
        if global_client is not None:
            self._canary_client = global_client
            return global_client
        if self._canary_api_key:
            try:
                from canary_sdk.client import CanaryClient
                from canary_sdk.types import SDKConfig
                cfg = SDKConfig(
                    api_key=self._canary_api_key,
                    **({"endpoint": self._canary_endpoint} if self._canary_endpoint else {}),
                )
                self._canary_client = CanaryClient(cfg)
                return self._canary_client
            except Exception:
                logger.debug("Failed to build CanaryClient from wrapper")
        return None

    def _extract_and_enqueue(self, response: Any, ai_input: str, start_time: float, tags: list[str]) -> None:
        """Extract fields from response and push to background queue. Never raises."""
        try:
            if response is None:
                return
            latency_ms = int((time.monotonic() - start_time) * 1000)
            model = getattr(response, "model", "unknown") or "unknown"
            ai_output = ""
            try:
                ai_output = response.choices[0].message.content or ""
            except Exception:
                pass
            token_count_input = None
            token_count_output = None
            cost_cents = None
            if hasattr(response, "usage") and response.usage is not None:
                usage = response.usage
                token_count_input = getattr(usage, "prompt_tokens", None)
                token_count_output = getattr(usage, "completion_tokens", None)
                try:
                    extra = getattr(usage, "model_extra", None) or {}
                    raw_cost = extra.get("total_cost")
                    if raw_cost is not None:
                        cost_cents = float(raw_cost) * 100.0
                except Exception:
                    pass
            self._enqueue_capture(
                ai_input=ai_input, ai_output=ai_output, model=model,
                latency_ms=latency_ms, token_count_input=token_count_input,
                token_count_output=token_count_output, cost_cents=cost_cents, tags=tags,
            )
        except Exception:
            logger.debug("_extract_and_enqueue failed silently")

    def _enqueue_capture(self, **kwargs) -> None:
        try:
            self._capture_queue.put_nowait(kwargs)
        except Exception:
            pass

    def _drain_loop(self) -> None:
        while True:
            try:
                item = self._capture_queue.get()
                if item is _SENTINEL:
                    break
                client = self._resolve_client()
                if client is not None:
                    client.capture(**item)
            except Exception:
                logger.debug("_drain_loop error (silent)")

    def close(self, timeout: float = 10.0) -> None:
        """Signal the drain thread to stop and wait for it to finish."""
        try:
            self._capture_queue.put_nowait(_SENTINEL)
            self._drain_thread.join(timeout=timeout)
            if self._drain_thread.is_alive():
                logger.warning("canary_sdk: drain thread still running after close(); some captures may be lost")
        except Exception:
            pass

    def _wrap_create(self, original_create, messages, tags, **kwargs):
        ai_input = str(messages)
        start = time.monotonic()
        response = original_create(messages=messages, **kwargs)
        # Skip capture for streaming responses — ai_output not available synchronously
        if not kwargs.get("stream"):
            self._extract_and_enqueue(response=response, ai_input=ai_input, start_time=start, tags=tags)
        return response
