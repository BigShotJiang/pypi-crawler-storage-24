"""Drop-in Anthropic wrapper for Canary SDK.

Usage:
    from canary_sdk.wrappers.anthropic import Anthropic
    client = Anthropic(api_key="sk-ant-...", canary_api_key="cny_live_sk_...")

    # Or if canary_sdk.init() was already called:
    from canary_sdk.wrappers.anthropic import Anthropic
    client = Anthropic(api_key="sk-ant-...")

This is a drop-in replacement for anthropic.Anthropic. It captures every
messages.create() call via a background queue — zero latency added.
"""
from __future__ import annotations

import time
import logging
from typing import Any

from canary_sdk.wrappers._base import _CaptureMixin

logger = logging.getLogger("canary_sdk.wrappers.anthropic")


def _do_extract_anthropic(
    enqueue_fn,
    response: Any,
    ai_input: str,
    start_time: float,
    tags: list[str],
) -> None:
    """Extract fields from Anthropic response and enqueue for capture. Never raises."""
    try:
        if response is None:
            return
        latency_ms = int((time.monotonic() - start_time) * 1000)
        model = getattr(response, "model", "unknown") or "unknown"
        ai_output = "".join(
            getattr(b, "text", "") for b in (response.content or [])
        )
        token_count_input = getattr(
            getattr(response, "usage", None), "input_tokens", None
        )
        token_count_output = getattr(
            getattr(response, "usage", None), "output_tokens", None
        )
        enqueue_fn(
            ai_input=ai_input,
            ai_output=ai_output,
            model=model,
            latency_ms=latency_ms,
            token_count_input=token_count_input,
            token_count_output=token_count_output,
            cost_cents=None,  # Anthropic SDK does not return cost in response objects
            tags=tags,
        )
    except Exception:
        logger.debug("_extract_and_enqueue_anthropic failed silently")


try:
    import anthropic as _anthropic_module

    class Anthropic(_CaptureMixin, _anthropic_module.Anthropic):
        """Drop-in replacement for anthropic.Anthropic with automatic Canary capture."""

        def __init__(self, *args, canary_api_key=None, canary_endpoint=None,
                     canary_feature_tag: str | None = None, **kwargs):
            self._canary_feature_tag = canary_feature_tag
            super().__init__(*args, canary_api_key=canary_api_key,
                             canary_endpoint=canary_endpoint, **kwargs)

        def _extract_and_enqueue_anthropic(self, response, ai_input, start_time, tags):
            _do_extract_anthropic(self._enqueue_capture, response, ai_input, start_time, tags)

        @property
        def messages(self):
            if not hasattr(self, "_wrapped_messages_instance"):
                parent_messages = super().messages
                wrapper = self

                class _WrappedMessages:
                    def create(self_, **kwargs):
                        prompt = kwargs.get("messages", [])
                        ai_input = str(prompt)
                        tags = [wrapper._canary_feature_tag] if wrapper._canary_feature_tag else []
                        start = time.monotonic()
                        response = parent_messages.create(**kwargs)
                        if not kwargs.get("stream"):
                            wrapper._extract_and_enqueue_anthropic(
                                response=response, ai_input=ai_input,
                                start_time=start, tags=tags,
                            )
                        return response

                self._wrapped_messages_instance = _WrappedMessages()
            return self._wrapped_messages_instance

    class AsyncAnthropic(_CaptureMixin, _anthropic_module.AsyncAnthropic):
        """Drop-in replacement for anthropic.AsyncAnthropic with automatic Canary capture."""

        def __init__(self, *args, canary_api_key=None, canary_endpoint=None,
                     canary_feature_tag: str | None = None, **kwargs):
            self._canary_feature_tag = canary_feature_tag
            super().__init__(*args, canary_api_key=canary_api_key,
                             canary_endpoint=canary_endpoint, **kwargs)

        def _extract_and_enqueue_anthropic(self, response, ai_input, start_time, tags):
            _do_extract_anthropic(self._enqueue_capture, response, ai_input, start_time, tags)

        @property
        def messages(self):
            if not hasattr(self, "_wrapped_messages_instance"):
                parent_messages = super().messages
                wrapper = self

                class _WrappedMessages:
                    async def create(self_, **kwargs):
                        prompt = kwargs.get("messages", [])
                        ai_input = str(prompt)
                        tags = [wrapper._canary_feature_tag] if wrapper._canary_feature_tag else []
                        start = time.monotonic()
                        response = await parent_messages.create(**kwargs)
                        if not kwargs.get("stream"):
                            wrapper._extract_and_enqueue_anthropic(
                                response=response, ai_input=ai_input,
                                start_time=start, tags=tags,
                            )
                        return response

                self._wrapped_messages_instance = _WrappedMessages()
            return self._wrapped_messages_instance

except ImportError:
    class Anthropic:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs):
            raise ImportError("anthropic package is required: pip install anthropic")

    class AsyncAnthropic:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs):
            raise ImportError("anthropic package is required: pip install anthropic")
