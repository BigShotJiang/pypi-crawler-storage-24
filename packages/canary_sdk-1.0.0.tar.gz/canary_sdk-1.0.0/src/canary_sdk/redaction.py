"""Presidio PHI redaction with healthcare-safe configuration.

Strips HIPAA Safe Harbor identifiers from trace data BEFORE it leaves
the client. Includes a healthcare term whitelist to prevent over-redaction
of drug names, disease names, ICD-10 codes, and clinical terminology.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from presidio_analyzer import (
    AnalyzerEngine,
    EntityRecognizer,
    PatternRecognizer,
    RecognizerResult,
    Pattern,
)
from presidio_analyzer.nlp_engine import SpacyNlpEngine, NlpArtifacts
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

logger = logging.getLogger("canary_sdk.redaction")

# Top drug names (generic + brand) that Presidio might misidentify as PERSON/ORG
HEALTHCARE_TERMS = {
    # Brand-name drugs commonly confused with proper nouns
    "humira", "keytruda", "eliquis", "jardiance", "ozempic", "mounjaro",
    "xarelto", "entresto", "dupixent", "skyrizi", "rinvoq", "stelara",
    "trulicity", "repatha", "biktarvy", "tecfidera", "ocrevus", "imbruvica",
    "darzalex", "tagrisso", "lynparza", "farxiga", "revlimid", "opdivo",
    "eylea", "ibrance", "xtandi", "calquence", "pomalyst", "venclexta",
    "brukinsa", "enhertu", "lumakras", "nexleta", "orencia", "actemra",
    "cosentyx", "taltz", "tremfya", "ilumya", "cimzia", "simponi",
    # Generic drug names
    "metformin", "lisinopril", "atorvastatin", "amlodipine", "metoprolol",
    "omeprazole", "losartan", "albuterol", "gabapentin", "hydrochlorothiazide",
    "sertraline", "simvastatin", "montelukast", "escitalopram", "rosuvastatin",
    "bupropion", "pantoprazole", "duloxetine", "tamsulosin", "meloxicam",
    "trazodone", "pravastatin", "clopidogrel", "carvedilol", "fluticasone",
    "tramadol", "prednisone", "furosemide", "amoxicillin", "azithromycin",
    "doxycycline", "ciprofloxacin", "cephalexin", "clindamycin", "levofloxacin",
    "acetaminophen", "ibuprofen", "naproxen", "aspirin", "warfarin",
    "apixaban", "rivaroxaban", "insulin", "glipizide", "pioglitazone",
    "sitagliptin", "empagliflozin", "dapagliflozin", "semaglutide", "dulaglutide",
    "liraglutide", "tirzepatide", "adalimumab", "pembrolizumab", "nivolumab",
    "rituximab", "trastuzumab", "bevacizumab", "infliximab", "etanercept",
    # Disease/condition names that might trigger NER
    "diabetes", "hypertension", "asthma", "copd", "pneumonia",
    "melanoma", "lymphoma", "leukemia", "carcinoma", "sarcoma",
    "alzheimer", "parkinson", "huntington", "crohn", "addison",
    "cushing", "hashimoto", "graves", "hodgkin", "tourette",
    "marfan", "ehlers", "danlos", "raynaud", "sjogren",
    "lupus", "fibromyalgia", "psoriasis", "eczema", "dermatitis",
}

# ICD-10 code pattern: letter + 2 digits + optional (dot + 1-4 alphanum)
ICD10_PATTERN = re.compile(r"\b[A-Z]\d{2}(?:\.\d{1,4})?\b", re.IGNORECASE)


class HealthcareWhitelistRecognizer(EntityRecognizer):
    """Custom Presidio recognizer that whitelists healthcare terms.

    When spaCy's NER detects a PERSON or ORGANIZATION entity that matches
    a known medical term, this recognizer overrides with a higher confidence
    to prevent redaction.
    """

    ENTITIES = ["PERSON", "ORGANIZATION", "LOCATION", "DATE_TIME", "US_DRIVER_LICENSE"]

    def __init__(self):
        super().__init__(
            supported_entities=self.ENTITIES,
            name="HealthcareWhitelistRecognizer",
            supported_language="en",
        )

    def load(self) -> None:
        pass

    def analyze(
        self,
        text: str,
        entities: list[str],
        nlp_artifacts: NlpArtifacts = None,
    ) -> list[RecognizerResult]:
        """Return empty results -- this recognizer is used only for filtering."""
        return []


class SSNPatternRecognizer(PatternRecognizer):
    """Broader SSN recognizer that catches NNN-NN-NNNN patterns."""

    def __init__(self):
        patterns = [
            Pattern(
                name="ssn_pattern_dashes",
                regex=r"\b\d{3}-\d{2}-\d{4}\b",
                score=0.85,
            ),
            Pattern(
                name="ssn_pattern_no_dashes",
                regex=r"\b\d{9}\b",
                score=0.4,
            ),
        ]
        super().__init__(
            supported_entity="US_SSN",
            patterns=patterns,
            name="CustomSSNRecognizer",
            supported_language="en",
        )


class MRNPatternRecognizer(PatternRecognizer):
    """Recognizer for Medical Record Numbers (MRN patterns)."""

    def __init__(self):
        patterns = [
            Pattern(
                name="mrn_pattern",
                regex=r"\b(?:MRN|MR#|Medical Record)\s*[:#]?\s*\d{6,12}\b",
                score=0.85,
            ),
        ]
        super().__init__(
            supported_entity="MEDICAL_RECORD_NUMBER",
            patterns=patterns,
            name="MRNRecognizer",
            supported_language="en",
        )


class RedactionEngine:
    """PHI redaction engine using Microsoft Presidio with healthcare-safe configuration.

    Detects and redacts HIPAA Safe Harbor identifiers while preserving
    healthcare-specific terminology (drug names, disease names, ICD-10 codes).
    """

    # Entity types to detect
    ENTITIES = [
        "PERSON",
        "PHONE_NUMBER",
        "EMAIL_ADDRESS",
        "US_SSN",
        "CREDIT_CARD",
        "US_DRIVER_LICENSE",
        "LOCATION",
        "IP_ADDRESS",
        "MEDICAL_RECORD_NUMBER",
        "URL",
    ]

    def __init__(self) -> None:
        # Create NLP engine explicitly to avoid pip dependency check
        nlp_engine = SpacyNlpEngine(
            models=[{"lang_code": "en", "model_name": "en_core_web_sm"}]
        )
        self._analyzer = AnalyzerEngine(nlp_engine=nlp_engine)

        # Register custom recognizers
        self._analyzer.registry.add_recognizer(HealthcareWhitelistRecognizer())
        self._analyzer.registry.add_recognizer(SSNPatternRecognizer())
        self._analyzer.registry.add_recognizer(MRNPatternRecognizer())

        self._anonymizer = AnonymizerEngine()
        self._operator_config = {
            "DEFAULT": OperatorConfig("replace", {"new_value": "[REDACTED]"})
        }

    def _is_healthcare_term(self, text: str, start: int, end: int) -> bool:
        """Check if the detected entity is actually a healthcare term."""
        token = text[start:end].strip().lower()

        # Check against healthcare terms set
        if token in HEALTHCARE_TERMS:
            return True

        # Check individual words in multi-word entities
        words = token.split()
        if any(w in HEALTHCARE_TERMS for w in words):
            return True

        # Check if it matches ICD-10 code pattern
        candidate = text[start:end].strip()
        if ICD10_PATTERN.fullmatch(candidate):
            return True

        return False

    def _is_icd10_context(self, text: str, start: int, end: int) -> bool:
        """Check if the detected entity is in an ICD-10 code context."""
        candidate = text[start:end].strip()
        # ICD-10 codes: letter + 2+ digits, optionally with dot
        if ICD10_PATTERN.fullmatch(candidate):
            return True
        # Check if it's part of a comma-separated list of ICD-10 codes
        # Look at surrounding context
        context_start = max(0, start - 30)
        context = text[context_start:end + 10]
        if re.search(r"(?:diagnosis|icd|code)", context, re.IGNORECASE):
            return True
        return False

    def redact(self, text: str) -> tuple[str, list[dict]]:
        """Redact PHI from text, preserving healthcare terms.

        Args:
            text: The text to redact.

        Returns:
            Tuple of (redacted_text, manifest) where manifest is a list
            of dicts with entity_type, start, end, original_length.
        """
        if not text:
            return "", []

        # Run Presidio analyzer
        results = self._analyzer.analyze(
            text=text,
            language="en",
            entities=self.ENTITIES,
            score_threshold=0.35,
        )

        # Filter out healthcare terms and ICD-10 codes
        filtered_results = []
        for result in results:
            # Skip if it's a known healthcare term
            if self._is_healthcare_term(text, result.start, result.end):
                continue
            # Skip if it looks like an ICD-10 code
            if self._is_icd10_context(text, result.start, result.end):
                continue
            # Skip URL entities that are just domains in email context
            if result.entity_type == "URL":
                # Skip URL if it's part of an email that's already being caught
                email_covered = any(
                    r.entity_type == "EMAIL_ADDRESS"
                    and r.start <= result.start
                    and r.end >= result.end
                    for r in results
                )
                if email_covered:
                    continue
                # Skip standalone URLs (not PHI)
                continue
            filtered_results.append(result)

        if not filtered_results:
            return text, []

        # Build manifest before anonymization (positions will shift after)
        manifest = [
            {
                "entity_type": r.entity_type,
                "start": r.start,
                "end": r.end,
                "original_length": r.end - r.start,
            }
            for r in filtered_results
        ]

        # Run anonymizer with filtered results
        anonymized = self._anonymizer.anonymize(
            text=text,
            analyzer_results=filtered_results,
            operators=self._operator_config,
        )

        return anonymized.text, manifest
