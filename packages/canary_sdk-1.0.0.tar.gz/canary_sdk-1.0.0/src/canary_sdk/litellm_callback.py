"""LiteLLM-compatible callback handler for the Canary SDK.

Extracts model, input, and output from LiteLLM kwargs and response objects,
then captures them as traces via the CanaryClient. All methods are wrapped
in try/except -- the callback NEVER crashes LiteLLM.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from datetime import datetime

    from canary_sdk.client import CanaryClient

logger = logging.getLogger("canary_sdk.litellm_callback")


class CanaryCallback:
    """LiteLLM callback handler that captures AI call traces."""

    def __init__(self, client: CanaryClient) -> None:
        self._client = client

    def _extract_token_cost(self, response_obj: Any) -> tuple[int | None, int | None, float | None]:
        """Extract token counts and cost from LiteLLM response. Returns (input, output, cost_cents)."""
        token_count_input = None
        token_count_output = None
        cost_cents = None
        try:
            if hasattr(response_obj, "usage") and response_obj.usage is not None:
                token_count_input = getattr(response_obj.usage, "prompt_tokens", None)
                token_count_output = getattr(response_obj.usage, "completion_tokens", None)
        except Exception:
            pass
        try:
            hidden = getattr(response_obj, "_hidden_params", None)
            if isinstance(hidden, dict):
                raw_cost = hidden.get("response_cost")
                if raw_cost is not None:
                    cost_cents = float(raw_cost) * 100.0
        except Exception:
            pass
        return token_count_input, token_count_output, cost_cents

    def log_success_event(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: datetime,
        end_time: datetime,
    ) -> None:
        """Called by LiteLLM after a successful completion. Extracts trace data."""
        try:
            # Prefer response.model (actual model) over kwargs model (e.g. "openrouter/auto")
            model = getattr(response_obj, "model", None) or kwargs.get("model", "unknown")
            messages = kwargs.get("messages", [])
            ai_input = str(messages)

            # Extract output from response
            ai_output = ""
            try:
                if hasattr(response_obj, "choices") and response_obj.choices:
                    choice = response_obj.choices[0]
                    if hasattr(choice, "message") and hasattr(choice.message, "content"):
                        ai_output = choice.message.content or ""
            except Exception:
                ai_output = str(response_obj)

            latency_ms = int((end_time - start_time).total_seconds() * 1000)

            # Extract feature_tag from LiteLLM metadata
            # Access pattern: kwargs["litellm_params"]["metadata"]["feature_tag"]
            # Use .get() at each level — these keys may be absent
            metadata = kwargs.get("litellm_params", {}).get("metadata", {}) or {}
            feature_tag = metadata.get("feature_tag")

            # Extract token counts and cost
            token_count_input, token_count_output, cost_cents = self._extract_token_cost(response_obj)

            self._client.capture(
                ai_input=ai_input,
                ai_output=ai_output,
                model=model,
                latency_ms=latency_ms,
                tags=[feature_tag] if feature_tag else [],
                token_count_input=token_count_input,
                token_count_output=token_count_output,
                cost_cents=cost_cents,
            )
        except Exception:
            logger.debug("log_success_event failed silently")

    async def async_log_success_event(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: datetime,
        end_time: datetime,
    ) -> None:
        """Async variant called by LiteLLM GLOBAL_LOGGING_WORKER. Same logic as sync."""
        self.log_success_event(kwargs, response_obj, start_time, end_time)

    def log_failure_event(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: datetime,
        end_time: datetime,
    ) -> None:
        """Called by LiteLLM after a failed completion. Captures failure for error tracking."""
        try:
            model = kwargs.get("model", "unknown")
            messages = kwargs.get("messages", [])
            ai_input = str(messages)
            ai_output = f"ERROR: {response_obj}"
            latency_ms = int((end_time - start_time).total_seconds() * 1000)

            # Extract feature_tag from LiteLLM metadata (same pattern as log_success_event)
            metadata = kwargs.get("litellm_params", {}).get("metadata", {}) or {}
            feature_tag = metadata.get("feature_tag")

            self._client.capture(
                ai_input=ai_input,
                ai_output=ai_output,
                model=model,
                latency_ms=latency_ms,
                tags=[feature_tag, "error"] if feature_tag else ["error"],
            )
        except Exception:
            logger.debug("log_failure_event failed silently")
