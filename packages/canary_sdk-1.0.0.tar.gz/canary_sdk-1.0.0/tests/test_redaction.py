"""Tests for client-side PHI redaction via Presidio.

Presidio strips HIPAA Safe Harbor identifiers BEFORE data leaves the
customer's system. Healthcare-specific terms (drugs, diseases, ICD-10 codes)
must NOT be over-redacted.
"""

import canary_sdk
from canary_sdk.redaction import RedactionEngine


# --- PHI Redaction Tests ---

def test_ssn_redacted():
    """Social Security Numbers are redacted from trace data."""
    engine = RedactionEngine()
    result, manifest = engine.redact("Patient SSN: 123-45-6789")
    assert "123-45-6789" not in result
    assert "[REDACTED]" in result


def test_phone_redacted():
    """Phone numbers are redacted from trace data."""
    engine = RedactionEngine()
    result, manifest = engine.redact("Call me at (555) 123-4567")
    assert "(555) 123-4567" not in result
    assert "[REDACTED]" in result


def test_email_redacted():
    """Email addresses are redacted from trace data."""
    engine = RedactionEngine()
    result, manifest = engine.redact("Contact patient@example.com for records")
    assert "patient@example.com" not in result
    assert "[REDACTED]" in result


# --- Healthcare Term Preservation Tests ---

def test_medical_terms_preserved():
    """Medical terminology is NOT redacted -- drug names, diseases, clinical terms."""
    engine = RedactionEngine()
    terms = [
        "Humira",
        "metformin",
        "Type 2 Diabetes Mellitus",
    ]
    for term in terms:
        result, _ = engine.redact(f"Patient is prescribed {term} for treatment")
        assert term in result, f"Medical term '{term}' was incorrectly redacted"


def test_icd10_codes_preserved():
    """ICD-10 codes like E11.9, I25.10, F32.1 are NOT redacted."""
    engine = RedactionEngine()
    text = "Diagnosis codes: E11.9, I25.10, F32.1"
    result, _ = engine.redact(text)
    assert "E11.9" in result, "ICD-10 code E11.9 was redacted"
    assert "I25.10" in result, "ICD-10 code I25.10 was redacted"
    assert "F32.1" in result, "ICD-10 code F32.1 was redacted"


# --- Integration with Client ---

def test_redaction_default_on(mock_api_key, mock_api_url):
    """CanaryClient with default config applies redaction before buffering."""
    canary_sdk._client = None
    canary_sdk.init(api_key=mock_api_key, endpoint=mock_api_url, redact_phi=True)
    try:
        added_traces = []
        original_add = canary_sdk._client._buffer.add

        def tracking_add(trace):
            added_traces.append(trace)
            return original_add(trace)

        canary_sdk._client._buffer.add = tracking_add

        canary_sdk._client.capture(
            ai_input="Patient SSN is 123-45-6789",
            ai_output="Acknowledged SSN 123-45-6789",
        )
        assert len(added_traces) == 1
        assert "123-45-6789" not in added_traces[0]["ai_input"]
        assert "123-45-6789" not in added_traces[0]["ai_output"]
        assert "[REDACTED]" in added_traces[0]["ai_input"]
    finally:
        canary_sdk.shutdown(timeout=1.0)
        canary_sdk._client = None


def test_redaction_opt_out(mock_api_key, mock_api_url):
    """CanaryClient with redact_phi=False does NOT apply redaction."""
    canary_sdk._client = None
    canary_sdk.init(api_key=mock_api_key, endpoint=mock_api_url, redact_phi=False)
    try:
        added_traces = []
        original_add = canary_sdk._client._buffer.add

        def tracking_add(trace):
            added_traces.append(trace)
            return original_add(trace)

        canary_sdk._client._buffer.add = tracking_add

        canary_sdk._client.capture(
            ai_input="Patient SSN is 123-45-6789",
            ai_output="Acknowledged",
        )
        assert len(added_traces) == 1
        assert "123-45-6789" in added_traces[0]["ai_input"]
    finally:
        canary_sdk.shutdown(timeout=1.0)
        canary_sdk._client = None


def test_redaction_returns_manifest():
    """Redaction returns both redacted text and a manifest of what was removed."""
    engine = RedactionEngine()
    result, manifest = engine.redact("SSN: 123-45-6789 and email: test@example.com")
    assert isinstance(manifest, list)
    assert len(manifest) >= 2
    for item in manifest:
        assert "entity_type" in item
        assert "start" in item
        assert "end" in item


def test_empty_string_safe():
    """Empty string input does not crash redaction."""
    engine = RedactionEngine()
    result, manifest = engine.redact("")
    assert result == ""
    assert manifest == []


def test_no_phi_unchanged():
    """Input with no PHI is returned unchanged."""
    engine = RedactionEngine()
    text = "The patient has been feeling well. No complaints today."
    result, manifest = engine.redact(text)
    assert result == text
    assert manifest == []
