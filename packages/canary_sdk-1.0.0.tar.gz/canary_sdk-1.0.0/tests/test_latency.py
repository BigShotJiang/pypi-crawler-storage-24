"""Tests for SDK zero-latency requirement.

The SDK must add zero measurable latency to the developer's AI calls (fire-and-forget).
"""

import time


def test_add_trace_under_1ms():
    """Adding a trace to the buffer completes in under 1ms (fire-and-forget)."""
    from canary_sdk.buffer import TraceBuffer

    def mock_upload(batch):
        pass

    buf = TraceBuffer(upload_fn=mock_upload, max_batch=25, flush_interval=60.0, max_buffer=1000)
    try:
        trace = {"ai_input": "test input", "ai_output": "test output"}
        # Warm up
        buf.add(trace)
        # Measure
        times = []
        for _ in range(100):
            start = time.monotonic()
            buf.add(trace)
            elapsed = time.monotonic() - start
            times.append(elapsed)
        avg_ms = (sum(times) / len(times)) * 1000
        assert avg_ms < 1.0, f"Average add() time was {avg_ms:.3f}ms, expected < 1ms"
    finally:
        buf.shutdown(timeout=2.0)
