"""Tests for SDK graceful failure behavior.

The SDK must NEVER crash the customer's application, regardless of network or auth failures.
"""

import canary_sdk
from canary_sdk.buffer import TraceBuffer


def test_network_failure_silent():
    """Network failure during flush is handled silently without raising."""
    flushed = []

    def failing_upload(batch):
        flushed.append(batch)
        raise ConnectionError("Network is down")

    buf = TraceBuffer(upload_fn=failing_upload, max_batch=2, flush_interval=60.0, max_buffer=100)
    try:
        buf.add({"ai_input": "test", "ai_output": "test"})
        buf.add({"ai_input": "test2", "ai_output": "test2"})
        import time
        time.sleep(0.5)
        # Buffer should have attempted upload but not crashed
        assert len(flushed) >= 1  # upload was called
        # Buffer thread should still be alive
        assert buf._thread.is_alive()
    finally:
        buf.shutdown(timeout=2.0)


def test_sdk_never_raises(mock_api_url):
    """init() with invalid endpoint, then capture() -- no exception raised."""
    canary_sdk._client = None
    try:
        # Init with unreachable endpoint
        canary_sdk.init(api_key="cny_test_sk_invalid", endpoint="http://192.0.2.1:1", redact_phi=False)
        # capture should not raise even though the endpoint is invalid
        canary_sdk._client.capture(
            ai_input="test input",
            ai_output="test output",
        )
        # flush should not raise even though the endpoint is invalid
        canary_sdk.flush()
    except Exception as e:
        raise AssertionError(f"SDK raised an exception: {e}")
    finally:
        canary_sdk.shutdown(timeout=1.0)
        canary_sdk._client = None


def test_init_with_bad_key_format():
    """init() with malformed key still works (validation is server-side)."""
    canary_sdk._client = None
    try:
        canary_sdk.init(api_key="not-a-valid-key-format", endpoint="http://localhost:9999", redact_phi=False)
        assert canary_sdk._client is not None
    except Exception as e:
        raise AssertionError(f"SDK raised on bad key format: {e}")
    finally:
        canary_sdk.shutdown(timeout=1.0)
        canary_sdk._client = None


def test_callback_before_init_raises():
    """callback() before init() raises RuntimeError with helpful message."""
    canary_sdk._client = None
    try:
        canary_sdk.callback()
        raise AssertionError("Should have raised RuntimeError")
    except RuntimeError as e:
        assert "init" in str(e).lower()
