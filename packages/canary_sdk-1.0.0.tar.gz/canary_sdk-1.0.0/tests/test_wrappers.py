"""Tests for drop-in OpenAI/Anthropic wrappers."""
from __future__ import annotations

import queue
import time
from unittest.mock import MagicMock, patch

import pytest


def _make_fake_response(model: str = "gpt-4o", content: str = "Hello", prompt_tokens: int = 10, completion_tokens: int = 5):
    """Build a fake openai ChatCompletion response object."""
    usage = MagicMock()
    usage.prompt_tokens = prompt_tokens
    usage.completion_tokens = completion_tokens
    usage.model_extra = {"total_cost": 0.00042}

    choice = MagicMock()
    choice.message.content = content

    resp = MagicMock()
    resp.model = model
    resp.choices = [choice]
    resp.usage = usage
    resp.id = "chatcmpl-abc123"
    return resp


class TestOpenAIWrapper:
    def test_wrapper_class_is_importable(self):
        from canary_sdk.wrappers.openai import OpenAI
        assert OpenAI is not None

    def test_wrapper_captures_model(self):
        from canary_sdk.wrappers.openai import OpenAI
        client = OpenAI(api_key="sk-test")
        fake_resp = _make_fake_response(model="anthropic/claude-3-haiku")

        client._enqueue_capture(
            ai_input="hi", ai_output="hello",
            model=fake_resp.model,
            latency_ms=100, token_count_input=10, token_count_output=5,
            cost_cents=4.2, tags=[],
        )

        item = client._capture_queue.get_nowait()
        assert item["model"] == "anthropic/claude-3-haiku"

    def test_wrapper_captures_tokens(self):
        from canary_sdk.wrappers.openai import OpenAI
        client = OpenAI(api_key="sk-test")
        client._enqueue_capture(
            ai_input="test input", ai_output="test output",
            model="gpt-4o", latency_ms=123,
            token_count_input=15, token_count_output=8, cost_cents=1.5, tags=[],
        )
        item = client._capture_queue.get_nowait()
        assert item["token_count_input"] == 15
        assert item["token_count_output"] == 8
        assert item["cost_cents"] == 1.5

    def test_wrapper_never_raises_on_bad_response(self):
        from canary_sdk.wrappers.openai import OpenAI
        client = OpenAI(api_key="sk-test")
        # Must not raise even with None response
        client._extract_and_enqueue(response=None, ai_input="x", start_time=0.0, tags=[])

    def test_openrouter_actual_model_captured(self):
        """Simulates OpenRouter response where .model contains the actual routed LLM."""
        from canary_sdk.wrappers.openai import OpenAI
        client = OpenAI(api_key="sk-or-test", base_url="https://openrouter.ai/api/v1")
        fake_resp = _make_fake_response(model="openai/gpt-4o-mini")

        client._extract_and_enqueue(
            response=fake_resp,
            ai_input="user: what is 2+2",
            start_time=time.monotonic() - 0.5,
            tags=["router-test"],
        )

        item = client._capture_queue.get_nowait()
        assert item["model"] == "openai/gpt-4o-mini"

    def test_cost_extracted_from_openrouter_usage(self):
        """OpenRouter puts cost in usage.model_extra['total_cost'] (dollars)."""
        from canary_sdk.wrappers.openai import OpenAI
        client = OpenAI(api_key="sk-or-test")
        fake_resp = _make_fake_response()
        fake_resp.usage.model_extra = {"total_cost": 0.00042}

        client._extract_and_enqueue(
            response=fake_resp,
            ai_input="x",
            start_time=time.monotonic() - 0.1,
            tags=[],
        )

        item = client._capture_queue.get_nowait()
        # 0.00042 dollars * 100 = 0.042 cents
        assert abs(item["cost_cents"] - 0.042) < 0.0001

    def test_async_openai_wrapper_is_importable_and_captures(self):
        """AsyncOpenAI exists and shares the same capture machinery."""
        from canary_sdk.wrappers.openai import AsyncOpenAI
        client = AsyncOpenAI(api_key="sk-test")
        # Use the same _extract_and_enqueue method — shared via _CaptureMixin
        fake_resp = _make_fake_response(model="gpt-4o-async")
        client._extract_and_enqueue(
            response=fake_resp,
            ai_input="async prompt",
            start_time=time.monotonic() - 0.1,
            tags=["async-test"],
        )
        item = client._capture_queue.get_nowait()
        assert item["model"] == "gpt-4o-async"


class TestAnthropicWrapper:
    def test_wrapper_class_is_importable(self):
        from canary_sdk.wrappers.anthropic import Anthropic
        assert Anthropic is not None

    def test_wrapper_captures_model(self):
        from canary_sdk.wrappers.anthropic import Anthropic
        client = Anthropic(api_key="sk-ant-test")
        fake_resp = MagicMock()
        fake_resp.model = "claude-3-haiku-20240307"
        fake_resp.content = [MagicMock(text="Hello there")]
        fake_resp.usage = MagicMock(input_tokens=12, output_tokens=4)

        client._extract_and_enqueue_anthropic(
            response=fake_resp, ai_input="Hi",
            start_time=time.monotonic() - 0.2, tags=["test"],
        )
        item = client._capture_queue.get_nowait()
        assert item["model"] == "claude-3-haiku-20240307"

    def test_wrapper_captures_input_output_tokens(self):
        from canary_sdk.wrappers.anthropic import Anthropic
        client = Anthropic(api_key="sk-ant-test")
        fake_resp = MagicMock()
        fake_resp.model = "claude-3-opus-20240229"
        fake_resp.content = [MagicMock(text="Result")]
        fake_resp.usage = MagicMock(input_tokens=50, output_tokens=20)

        client._extract_and_enqueue_anthropic(
            response=fake_resp, ai_input="prompt",
            start_time=time.monotonic() - 0.3, tags=[],
        )
        item = client._capture_queue.get_nowait()
        assert item["token_count_input"] == 50
        assert item["token_count_output"] == 20

    def test_wrapper_never_raises_on_bad_response(self):
        from canary_sdk.wrappers.anthropic import Anthropic
        client = Anthropic(api_key="sk-ant-test")
        client._extract_and_enqueue_anthropic(
            response=None, ai_input="x", start_time=0.0, tags=[]
        )

    def test_cost_cents_is_none_for_anthropic(self):
        """Anthropic SDK doesn't return cost — cost_cents must always be None."""
        from canary_sdk.wrappers.anthropic import Anthropic
        client = Anthropic(api_key="sk-ant-test")
        fake_resp = MagicMock()
        fake_resp.model = "claude-3-haiku-20240307"
        fake_resp.content = [MagicMock(text="Done")]
        fake_resp.usage = MagicMock(input_tokens=10, output_tokens=3)

        client._extract_and_enqueue_anthropic(
            response=fake_resp, ai_input="test",
            start_time=time.monotonic() - 0.1, tags=[],
        )
        item = client._capture_queue.get_nowait()
        assert item["cost_cents"] is None
