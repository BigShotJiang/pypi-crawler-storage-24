"""Shared test fixtures for the Canary SDK test suite."""

import pytest


@pytest.fixture
def mock_api_key():
    """Test API key for SDK testing."""
    return "cny_test_sk_abcdef1234567890abcdef1234567890"


@pytest.fixture
def mock_api_url():
    """Test API URL for SDK testing."""
    return "http://localhost:8000"
