"""Tests for SDK package import and version."""


def test_canary_sdk_imports():
    """canary_sdk package can be imported without errors."""
    import canary_sdk  # noqa: F401


def test_canary_sdk_version():
    """canary_sdk.__version__ is set to expected value."""
    import canary_sdk

    assert canary_sdk.__version__ == "0.1.0"


def test_public_api_exports():
    """All public API functions are importable: init, callback, trace, flush, shutdown."""
    from canary_sdk import init, callback, trace, flush, shutdown, __version__

    assert callable(init)
    assert callable(callback)
    assert callable(trace)
    assert callable(flush)
    assert callable(shutdown)
    assert isinstance(__version__, str)
