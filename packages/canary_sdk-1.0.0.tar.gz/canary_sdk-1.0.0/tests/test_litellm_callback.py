"""Tests for enhanced CanaryCallback — token extraction, cost, actual model."""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest


def _make_litellm_response(
    model: str = "gpt-4o",
    content: str = "Hello",
    prompt_tokens: int = 20,
    completion_tokens: int = 10,
    response_cost: float = 0.0005,
):
    usage = MagicMock()
    usage.prompt_tokens = prompt_tokens
    usage.completion_tokens = completion_tokens

    choice = MagicMock()
    choice.message.content = content

    resp = MagicMock()
    resp.model = model
    resp.choices = [choice]
    resp.usage = usage
    resp._hidden_params = {"response_cost": response_cost}
    return resp


def _make_kwargs(model: str = "gpt-4o", feature_tag: str | None = None):
    return {
        "model": model,
        "messages": [{"role": "user", "content": "hi"}],
        "litellm_params": {
            "metadata": {"feature_tag": feature_tag} if feature_tag else {}
        },
    }


class TestCanaryCallbackEnhanced:
    def _make_callback(self):
        client = MagicMock()
        from canary_sdk.litellm_callback import CanaryCallback
        cb = CanaryCallback(client=client)
        return cb, client

    def test_log_success_extracts_prompt_tokens(self):
        cb, client = self._make_callback()
        resp = _make_litellm_response(prompt_tokens=42, completion_tokens=7)
        now = datetime.now(timezone.utc)
        cb.log_success_event(_make_kwargs(), resp, now, now)
        call_kwargs = client.capture.call_args[1]
        assert call_kwargs["token_count_input"] == 42

    def test_log_success_extracts_completion_tokens(self):
        cb, client = self._make_callback()
        resp = _make_litellm_response(prompt_tokens=10, completion_tokens=33)
        now = datetime.now(timezone.utc)
        cb.log_success_event(_make_kwargs(), resp, now, now)
        call_kwargs = client.capture.call_args[1]
        assert call_kwargs["token_count_output"] == 33

    def test_log_success_extracts_cost_cents(self):
        cb, client = self._make_callback()
        # response_cost = 0.005 dollars → 0.5 cents
        resp = _make_litellm_response(response_cost=0.005)
        now = datetime.now(timezone.utc)
        cb.log_success_event(_make_kwargs(), resp, now, now)
        call_kwargs = client.capture.call_args[1]
        assert abs(call_kwargs["cost_cents"] - 0.5) < 0.001

    def test_log_success_uses_response_model_not_kwargs_model(self):
        """OpenRouter: kwargs['model'] = 'openrouter/auto', response.model = actual model."""
        cb, client = self._make_callback()
        resp = _make_litellm_response(model="anthropic/claude-3-haiku")
        now = datetime.now(timezone.utc)
        cb.log_success_event(_make_kwargs(model="openrouter/auto"), resp, now, now)
        call_kwargs = client.capture.call_args[1]
        assert call_kwargs["model"] == "anthropic/claude-3-haiku"

    def test_log_success_falls_back_to_kwargs_model_when_response_model_absent(self):
        cb, client = self._make_callback()
        resp = _make_litellm_response()
        resp.model = None
        now = datetime.now(timezone.utc)
        cb.log_success_event(_make_kwargs(model="gpt-4-turbo"), resp, now, now)
        call_kwargs = client.capture.call_args[1]
        assert call_kwargs["model"] == "gpt-4-turbo"

    def test_async_log_success_event_method_exists(self):
        import inspect
        from canary_sdk.litellm_callback import CanaryCallback
        assert hasattr(CanaryCallback, "async_log_success_event")
        assert inspect.iscoroutinefunction(CanaryCallback.async_log_success_event)

    def test_async_log_success_captures_same_fields(self):
        cb, client = self._make_callback()
        resp = _make_litellm_response(prompt_tokens=15, completion_tokens=8, response_cost=0.001)
        now = datetime.now(timezone.utc)
        asyncio.run(cb.async_log_success_event(_make_kwargs(), resp, now, now))
        call_kwargs = client.capture.call_args[1]
        assert call_kwargs["token_count_input"] == 15
        assert call_kwargs["token_count_output"] == 8
        assert abs(call_kwargs["cost_cents"] - 0.1) < 0.001

    def test_no_crash_when_hidden_params_absent(self):
        """Graceful handling when _hidden_params is missing (older LiteLLM)."""
        cb, client = self._make_callback()
        resp = _make_litellm_response()
        del resp._hidden_params
        now = datetime.now(timezone.utc)
        cb.log_success_event(_make_kwargs(), resp, now, now)
        assert client.capture.called

    def test_no_crash_when_usage_is_none(self):
        """When usage=None, capture is still called with None token fields."""
        cb, client = self._make_callback()
        resp = _make_litellm_response()
        resp.usage = None
        now = datetime.now(timezone.utc)
        cb.log_success_event(_make_kwargs(), resp, now, now)
        assert client.capture.called
        call_kwargs = client.capture.call_args[1]
        assert call_kwargs.get("token_count_input") is None
        assert call_kwargs.get("token_count_output") is None
