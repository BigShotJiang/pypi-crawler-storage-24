"""Tests for SDK integration patterns.

The SDK supports three integration patterns: direct wrap, LiteLLM callback, and decorator.
"""

import asyncio
from unittest.mock import patch
import canary_sdk


def _init_sdk(mock_api_key, mock_api_url):
    """Helper to init SDK with test config (redaction off)."""
    canary_sdk._client = None
    canary_sdk.init(
        api_key=mock_api_key,
        endpoint=mock_api_url,
        redact_phi=False,
    )


def _shutdown_sdk():
    """Helper to cleanly shut down SDK."""
    canary_sdk.shutdown(timeout=1.0)
    canary_sdk._client = None


def test_direct_wrap(mock_api_key, mock_api_url):
    """Direct wrap pattern captures AI call input and output as a trace."""
    _init_sdk(mock_api_key, mock_api_url)
    try:
        original_add = canary_sdk._client._buffer.add
        added_traces = []

        def tracking_add(trace):
            added_traces.append(trace)
            return original_add(trace)

        canary_sdk._client._buffer.add = tracking_add

        canary_sdk._client.capture(
            ai_input="What is diabetes?",
            ai_output="Diabetes is a chronic condition...",
            model="gpt-4",
            provider="openai",
        )
        assert len(added_traces) == 1
        assert added_traces[0]["ai_input"] == "What is diabetes?"
        assert added_traces[0]["ai_output"] == "Diabetes is a chronic condition..."
        assert added_traces[0]["model"] == "gpt-4"
    finally:
        _shutdown_sdk()


def test_litellm_callback(mock_api_key, mock_api_url):
    """LiteLLM callback handler extracts model, input, output from kwargs."""
    _init_sdk(mock_api_key, mock_api_url)
    try:
        original_add = canary_sdk._client._buffer.add
        added_traces = []

        def tracking_add(trace):
            added_traces.append(trace)
            return original_add(trace)

        canary_sdk._client._buffer.add = tracking_add

        cb = canary_sdk.callback()
        assert cb is not None

        kwargs = {
            "model": "gpt-4",
            "messages": [{"role": "user", "content": "Hello"}],
            "optional_params": {},
        }

        class MockResponse:
            choices = [type("Choice", (), {"message": type("Msg", (), {"content": "Hi there!"})()})]

        from datetime import datetime
        start = datetime.now()
        end = datetime.now()
        cb.log_success_event(kwargs=kwargs, response_obj=MockResponse(), start_time=start, end_time=end)
        assert len(added_traces) == 1
        assert "gpt-4" in str(added_traces[0].get("model", ""))
    finally:
        _shutdown_sdk()


def test_decorator_sync(mock_api_key, mock_api_url):
    """@trace decorated sync function captures input args and return value."""
    _init_sdk(mock_api_key, mock_api_url)
    try:
        original_add = canary_sdk._client._buffer.add
        added_traces = []

        def tracking_add(trace):
            added_traces.append(trace)
            return original_add(trace)

        canary_sdk._client._buffer.add = tracking_add

        @canary_sdk.trace
        def my_ai_call(prompt: str) -> str:
            return f"Response to: {prompt}"

        result = my_ai_call("test prompt")
        assert result == "Response to: test prompt"
        assert len(added_traces) == 1
        assert "test prompt" in added_traces[0]["ai_input"]
        assert "Response to: test prompt" in added_traces[0]["ai_output"]
    finally:
        _shutdown_sdk()


def test_decorator_async(mock_api_key, mock_api_url):
    """@trace decorated async function captures input args and return value."""
    _init_sdk(mock_api_key, mock_api_url)
    try:
        original_add = canary_sdk._client._buffer.add
        added_traces = []

        def tracking_add(trace):
            added_traces.append(trace)
            return original_add(trace)

        canary_sdk._client._buffer.add = tracking_add

        @canary_sdk.trace
        async def my_async_call(prompt: str) -> str:
            return f"Async response to: {prompt}"

        loop = asyncio.new_event_loop()
        try:
            result = loop.run_until_complete(my_async_call("test prompt"))
        finally:
            loop.close()
        assert result == "Async response to: test prompt"
        assert len(added_traces) == 1
        assert "test prompt" in added_traces[0]["ai_input"]
        assert "Async response to: test prompt" in added_traces[0]["ai_output"]
    finally:
        _shutdown_sdk()
