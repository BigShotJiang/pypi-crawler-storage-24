"""Tests for SDK async buffer and batch flush.

The buffer flushes on 25 traces OR 5 seconds (whichever first), capped at 1000 traces.
"""

import time
import threading


def test_flush_on_25_traces():
    """Buffer flushes automatically when 25 traces are accumulated."""
    from canary_sdk.buffer import TraceBuffer

    flushed_batches = []

    def mock_upload(batch):
        flushed_batches.append(batch)

    buf = TraceBuffer(upload_fn=mock_upload, max_batch=25, flush_interval=60.0, max_buffer=1000)
    try:
        for i in range(25):
            buf.add({"ai_input": f"input_{i}", "ai_output": f"output_{i}"})
        # Give flush thread time to process
        time.sleep(0.5)
        assert len(flushed_batches) == 1
        assert len(flushed_batches[0]) == 25
    finally:
        buf.shutdown(timeout=2.0)


def test_flush_on_5_seconds():
    """Buffer flushes automatically after 5 seconds even if < 25 traces."""
    from canary_sdk.buffer import TraceBuffer

    flushed_batches = []

    def mock_upload(batch):
        flushed_batches.append(batch)

    buf = TraceBuffer(upload_fn=mock_upload, max_batch=25, flush_interval=0.5, max_buffer=1000)
    try:
        buf.add({"ai_input": "test", "ai_output": "test"})
        # Wait for flush interval + margin
        time.sleep(1.0)
        assert len(flushed_batches) >= 1
        assert len(flushed_batches[0]) == 1
    finally:
        buf.shutdown(timeout=2.0)


def test_buffer_cap_1000():
    """Buffer silently drops traces beyond the 1000-trace capacity."""
    from canary_sdk.buffer import TraceBuffer

    def mock_upload(batch):
        pass  # never actually called because flush_interval is very long

    buf = TraceBuffer(upload_fn=mock_upload, max_batch=25, flush_interval=600.0, max_buffer=1000)
    try:
        for i in range(1000):
            result = buf.add({"ai_input": f"input_{i}", "ai_output": f"output_{i}"})
            assert result is True
        # The 1001st should be silently dropped
        result = buf.add({"ai_input": "overflow", "ai_output": "overflow"})
        assert result is False
    finally:
        buf.shutdown(timeout=2.0)


def test_shutdown_flushes_remaining():
    """shutdown() flushes any buffered traces before stopping."""
    from canary_sdk.buffer import TraceBuffer

    flushed_batches = []

    def mock_upload(batch):
        flushed_batches.append(batch)

    buf = TraceBuffer(upload_fn=mock_upload, max_batch=25, flush_interval=600.0, max_buffer=1000)
    for i in range(5):
        buf.add({"ai_input": f"input_{i}", "ai_output": f"output_{i}"})
    buf.shutdown(timeout=5.0)
    total_flushed = sum(len(b) for b in flushed_batches)
    assert total_flushed == 5
