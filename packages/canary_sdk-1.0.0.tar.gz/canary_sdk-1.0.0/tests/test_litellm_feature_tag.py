"""Tests for feature_tag extraction in CanaryCallback.

Covers:
  - TestFeatureTagExtraction: feature_tag flows from LiteLLM metadata to trace tags
  - TestFailureEventFeatureTag: log_failure_event merges feature_tag with 'error' tag
  - TestEdgeCases: missing keys, None values, no KeyError raised
"""

from __future__ import annotations

from datetime import datetime
from unittest.mock import MagicMock, patch

import canary_sdk


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_client(mock_api_key="cny_test_sk_abc123", mock_api_url="http://localhost:8000"):
    """Initialize SDK and return (client, captured_traces list)."""
    canary_sdk._client = None
    canary_sdk.init(api_key=mock_api_key, endpoint=mock_api_url, redact_phi=False)
    client = canary_sdk._client
    captured = []
    original_add = client._buffer.add

    def tracking_add(trace):
        captured.append(trace)
        return original_add(trace)

    client._buffer.add = tracking_add
    return client, captured


def _shutdown():
    canary_sdk.shutdown(timeout=1.0)
    canary_sdk._client = None


def _make_response(content: str = "test response"):
    """Minimal LiteLLM-style response object."""
    msg = type("Msg", (), {"content": content})()
    choice = type("Choice", (), {"message": msg})()
    return type("Response", (), {"choices": [choice]})()


def _times():
    t = datetime.now()
    return t, t


# ---------------------------------------------------------------------------
# TestFeatureTagExtraction
# ---------------------------------------------------------------------------


class TestFeatureTagExtraction:
    """feature_tag flows from LiteLLM metadata through to trace tags in log_success_event."""

    def test_extracts_feature_tag_from_metadata(self):
        """feature_tag='diagnosis_check' in metadata → tags=['diagnosis_check'] in trace."""
        client, captured = _make_client()
        try:
            cb = canary_sdk.callback()
            kwargs = {
                "model": "gpt-4",
                "messages": [{"role": "user", "content": "Check ICD code"}],
                "litellm_params": {
                    "metadata": {"feature_tag": "diagnosis_check"}
                },
            }
            start, end = _times()
            cb.log_success_event(kwargs=kwargs, response_obj=_make_response(), start_time=start, end_time=end)
            assert len(captured) == 1
            assert captured[0]["tags"] == ["diagnosis_check"]
        finally:
            _shutdown()

    def test_feature_tag_icd10_lookup(self):
        """feature_tag='icd10_lookup' flows through to trace tags."""
        client, captured = _make_client()
        try:
            cb = canary_sdk.callback()
            kwargs = {
                "model": "claude-haiku",
                "messages": [{"role": "user", "content": "Look up E11.9"}],
                "litellm_params": {
                    "metadata": {"feature_tag": "icd10_lookup"}
                },
            }
            start, end = _times()
            cb.log_success_event(kwargs=kwargs, response_obj=_make_response(), start_time=start, end_time=end)
            assert len(captured) == 1
            assert captured[0]["tags"] == ["icd10_lookup"]
        finally:
            _shutdown()

    def test_handles_empty_metadata_dict(self):
        """Empty metadata dict → tags=[] (no feature_tag, no exception)."""
        client, captured = _make_client()
        try:
            cb = canary_sdk.callback()
            kwargs = {
                "model": "gpt-4",
                "messages": [{"role": "user", "content": "Hello"}],
                "litellm_params": {"metadata": {}},
            }
            start, end = _times()
            cb.log_success_event(kwargs=kwargs, response_obj=_make_response(), start_time=start, end_time=end)
            assert len(captured) == 1
            assert captured[0]["tags"] == []
        finally:
            _shutdown()

    def test_handles_missing_litellm_params_key(self):
        """litellm_params key entirely absent → tags=[], no KeyError."""
        client, captured = _make_client()
        try:
            cb = canary_sdk.callback()
            kwargs = {
                "model": "gpt-4",
                "messages": [{"role": "user", "content": "Hello"}],
                # No litellm_params key at all
            }
            start, end = _times()
            cb.log_success_event(kwargs=kwargs, response_obj=_make_response(), start_time=start, end_time=end)
            assert len(captured) == 1
            assert captured[0]["tags"] == []
        finally:
            _shutdown()

    def test_handles_missing_metadata_key(self):
        """litellm_params present but no metadata key → tags=[], no KeyError."""
        client, captured = _make_client()
        try:
            cb = canary_sdk.callback()
            kwargs = {
                "model": "gpt-4",
                "messages": [],
                "litellm_params": {},  # no metadata key
            }
            start, end = _times()
            cb.log_success_event(kwargs=kwargs, response_obj=_make_response(), start_time=start, end_time=end)
            assert len(captured) == 1
            assert captured[0]["tags"] == []
        finally:
            _shutdown()

    def test_handles_none_metadata_value(self):
        """metadata=None → treated as empty dict → tags=[], no AttributeError."""
        client, captured = _make_client()
        try:
            cb = canary_sdk.callback()
            kwargs = {
                "model": "gpt-4",
                "messages": [],
                "litellm_params": {"metadata": None},
            }
            start, end = _times()
            cb.log_success_event(kwargs=kwargs, response_obj=_make_response(), start_time=start, end_time=end)
            assert len(captured) == 1
            assert captured[0]["tags"] == []
        finally:
            _shutdown()

    def test_handles_none_feature_tag_value(self):
        """metadata={'feature_tag': None} → tags=[], not tags=[None]."""
        client, captured = _make_client()
        try:
            cb = canary_sdk.callback()
            kwargs = {
                "model": "gpt-4",
                "messages": [],
                "litellm_params": {"metadata": {"feature_tag": None}},
            }
            start, end = _times()
            cb.log_success_event(kwargs=kwargs, response_obj=_make_response(), start_time=start, end_time=end)
            assert len(captured) == 1
            assert captured[0]["tags"] == []
        finally:
            _shutdown()

    def test_other_trace_fields_still_extracted(self):
        """After feature_tag addition, model/ai_input/ai_output/latency_ms still extracted."""
        client, captured = _make_client()
        try:
            cb = canary_sdk.callback()
            kwargs = {
                "model": "claude-haiku",
                "messages": [{"role": "user", "content": "What is HCC 85?"}],
                "litellm_params": {"metadata": {"feature_tag": "coding_assistant"}},
            }
            start, end = _times()
            cb.log_success_event(kwargs=kwargs, response_obj=_make_response("HCC 85 is..."), start_time=start, end_time=end)
            assert len(captured) == 1
            trace = captured[0]
            assert trace["model"] == "claude-haiku"
            assert "HCC 85" in trace["ai_input"]
            assert "HCC 85 is" in trace["ai_output"]
            assert "latency_ms" in trace
            assert trace["tags"] == ["coding_assistant"]
        finally:
            _shutdown()


# ---------------------------------------------------------------------------
# TestFailureEventFeatureTag
# ---------------------------------------------------------------------------


class TestFailureEventFeatureTag:
    """log_failure_event extracts feature_tag and merges with 'error' tag."""

    def test_failure_event_merges_feature_tag_with_error(self):
        """feature_tag + failure → tags=[feature_tag, 'error']."""
        client, captured = _make_client()
        try:
            cb = canary_sdk.callback()
            kwargs = {
                "model": "gpt-4",
                "messages": [],
                "litellm_params": {"metadata": {"feature_tag": "risk_adjustment"}},
            }
            start, end = _times()
            cb.log_failure_event(kwargs=kwargs, response_obj=Exception("timeout"), start_time=start, end_time=end)
            assert len(captured) == 1
            assert "error" in captured[0]["tags"]
            assert "risk_adjustment" in captured[0]["tags"]
        finally:
            _shutdown()

    def test_failure_event_without_feature_tag_has_only_error(self):
        """No feature_tag + failure → tags=['error'] only."""
        client, captured = _make_client()
        try:
            cb = canary_sdk.callback()
            kwargs = {
                "model": "gpt-4",
                "messages": [],
                "litellm_params": {"metadata": {}},
            }
            start, end = _times()
            cb.log_failure_event(kwargs=kwargs, response_obj=Exception("timeout"), start_time=start, end_time=end)
            assert len(captured) == 1
            assert captured[0]["tags"] == ["error"]
        finally:
            _shutdown()

    def test_failure_event_missing_litellm_params_no_crash(self):
        """Missing litellm_params on failure → tags=['error'], no exception."""
        client, captured = _make_client()
        try:
            cb = canary_sdk.callback()
            kwargs = {"model": "gpt-4", "messages": []}
            start, end = _times()
            cb.log_failure_event(kwargs=kwargs, response_obj=Exception("error"), start_time=start, end_time=end)
            assert len(captured) == 1
            assert captured[0]["tags"] == ["error"]
        finally:
            _shutdown()
