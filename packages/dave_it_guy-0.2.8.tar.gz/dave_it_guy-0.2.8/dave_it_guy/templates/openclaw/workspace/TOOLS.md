# Workspace tools (auto-discovered)

**OpenClaw: search for and run these tools only in this location:** `/home/node/.openclaw/workspace` (no other path). All workspace scripts live here. Run commands from that directory (e.g. `cd /home/node/.openclaw/workspace` then `python3 simple_qdrant.py list`) or use the full path: `python3 /home/node/.openclaw/workspace/simple_search.py "<query>"`.

## simple_qdrant.py

Qdrant vector store: list collections, upsert text, semantic search.

- **List collections:** `python3 simple_qdrant.py list`
- **Upsert:** `python3 simple_qdrant.py upsert <collection> <text> [id]`
- **Search:** `python3 simple_qdrant.py search <collection> <query> [limit]`

Uses `QDRANT_URL` (primary) and `QDRANT_FALLBACK_URL` from env. Embeddings: sentence-transformers.

## simple_search.py

DuckDuckGo web search. Returns JSON.

- **Usage:** `python3 simple_search.py "<query>" [max_results]`

Requires `duckduckgo-search`. Output: `{"engine":"duckduckgo","results":[...]}`.

## simple_subagent.py

Request a sub-agent task via MasterClaw. MasterClaw can spin off either a lightweight Ollama worker or a **full OpenClaw container** (with tools and memory).

- **Usage:** `python3 simple_subagent.py "<task>" [context] [model]`
- **Options:** `--timeout N`, `--no-wait`, `--full-openclaw` (use full OpenClaw container instead of Ollama-only worker).
- **Example (lightweight):** `python3 simple_subagent.py "Summarize this" "Context: ..." llama3.2`
- **Example (full OpenClaw):** `python3 simple_subagent.py "Research X and summarize" "" "" --full-openclaw`
- Output: JSON with `status`, `result` (contains `output`, `model`) or `error`.

Requires `httpx`. Uses `MASTERCLAW_URL` (default http://masterclaw:8090).

---

Load this file at startup so the agent knows these tools are available.
