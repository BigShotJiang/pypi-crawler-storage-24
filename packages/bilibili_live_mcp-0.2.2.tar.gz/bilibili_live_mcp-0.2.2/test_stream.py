import asyncio
import sys
import io
import os
import tempfile

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
sys.path.insert(0, "src")

from bilibili_mcp.live_content import _get_stream_url, _record_video

async def test():
    print("获取流地址...")
    stream_url, buvid3 = await _get_stream_url(510)
    print(f"流地址: {stream_url[:100]}...")
    print(f"buvid3 长度: {len(buvid3)}")

    with tempfile.TemporaryDirectory() as tmpdir:
        video_path = os.path.join(tmpdir, "test.mp4")
        print("录制5秒...")
        _record_video(stream_url, 5, video_path, buvid3)
        size = os.path.getsize(video_path)
        print(f"录制成功！文件大小: {size/1024:.1f} KB")

asyncio.run(test())
