"""Database engine: singleton pattern, SQLite (dev) or MySQL (prod)."""

from __future__ import annotations

import logging
import os

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from flyfun_common.db.models import Base, UserPreferencesRow, UserRow

logger = logging.getLogger(__name__)

_engine: Engine | None = None
SessionLocal: sessionmaker[Session] = sessionmaker()

DEV_USER_ID = "dev-user-001"


def is_dev_mode() -> bool:
    return os.environ.get("ENVIRONMENT", "development") != "production"


def get_engine(db_url: str | None = None) -> Engine:
    """Return a singleton SQLAlchemy engine.

    Dev: sqlite:///{DATA_DIR}/flyfun.db
    Prod: DATABASE_URL env var (MySQL / PostgreSQL)
    """
    global _engine
    if _engine is not None:
        return _engine

    if db_url is None:
        if not is_dev_mode():
            db_url = os.environ.get("DATABASE_URL")
            if not db_url:
                raise ValueError("DATABASE_URL must be set in production")
        else:
            data_dir = os.environ.get("DATA_DIR", "data")
            os.makedirs(data_dir, exist_ok=True)
            db_url = f"sqlite:///{data_dir}/flyfun.db"

    connect_args = {}
    if db_url.startswith("sqlite"):
        connect_args["check_same_thread"] = False
        connect_args["timeout"] = 30

    _engine = create_engine(db_url, connect_args=connect_args)
    SessionLocal.configure(bind=_engine)

    if db_url.startswith("sqlite"):

        @event.listens_for(_engine, "connect")
        def _set_sqlite_pragma(dbapi_conn, _connection_record):
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    safe_url = db_url.split("@")[-1] if "@" in db_url else db_url.split("///")[-1]
    logger.info("Shared DB engine created: %s", safe_url)
    return _engine


def reset_engine() -> None:
    """Reset the singleton engine (for testing)."""
    global _engine
    if _engine is not None:
        _engine.dispose()
    _engine = None
    SessionLocal.configure(bind=None)


def init_shared_db(engine: Engine | None = None) -> None:
    """Create shared tables (users, api_tokens). Dev only; prod uses Alembic."""
    engine = engine or get_engine()
    Base.metadata.create_all(engine)
    logger.info("Shared tables created")


def ensure_dev_user(session: Session) -> None:
    """Create dev user for local development."""
    user = session.get(UserRow, DEV_USER_ID)
    if user is None:
        user = UserRow(
            id=DEV_USER_ID,
            provider="local",
            provider_sub="dev",
            email="dev@localhost",
            display_name="Dev User",
            approved=True,
        )
        session.add(user)
        session.flush()
        session.add(UserPreferencesRow(user_id=DEV_USER_ID))
        session.commit()
        logger.info("Dev user created: %s", DEV_USER_ID)


def find_orphaned_user_ids(db: Session, model: type, user_id_col: str = "user_id") -> list[str]:
    """Return user IDs referenced in *model* that no longer exist in the users table.

    Usage::

        from flyfun_common.db import find_orphaned_user_ids
        from myapp.models import UsageRow

        orphaned = find_orphaned_user_ids(db, UsageRow)
        # → ["deleted-user-abc", "deleted-user-xyz"]

    Args:
        db: SQLAlchemy session.
        model: Any mapped class with a ``user_id`` column.
        user_id_col: Column name on *model* that holds the user ID
                     (default ``"user_id"``).
    """
    col = getattr(model, user_id_col)
    rows = (
        db.query(col)
        .distinct()
        .outerjoin(UserRow, col == UserRow.id)
        .filter(UserRow.id.is_(None))
        .all()
    )
    return [r[0] for r in rows]
