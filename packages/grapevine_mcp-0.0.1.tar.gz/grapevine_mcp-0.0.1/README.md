# grapevine-mcp

MCP server for Microsoft Office integration

> This is a placeholder release. The full package is coming soon.
