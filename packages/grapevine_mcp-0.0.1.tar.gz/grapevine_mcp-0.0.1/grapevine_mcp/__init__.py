"""MCP server for Microsoft Office integration"""

__version__ = "0.0.1"
