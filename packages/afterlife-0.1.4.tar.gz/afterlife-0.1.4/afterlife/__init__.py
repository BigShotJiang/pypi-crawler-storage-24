"""
Afterlife — Precision astrological chart engine with a terminal CLI.

Fluent API::

    from afterlife.sky import Birth, Moment, MoonPhase

    chart = (
        Birth()
        .date("01-01-1990")
        .time("12:00")
        .location(41.0, 29.0)
        .timezone(3.0)
        .compute()
    )

    chart.planets          # dict of planet bodies
    chart.centaurs         # dict of centaur bodies
    chart["asteroids"]     # dict-style access
    chart.summary()        # Sun / Moon / ASC / MC quick dict
    chart.to_json()        # raw JSON string

Low-level API::

    from afterlife import Afterlife
    import json

    eng   = Afterlife()
    chart = json.loads(eng.compute_astro_chart(
        date_str="01-01-1990",
        time_str="12:00",
        lat=41.0,
        lon=29.0,
        house_system="placidus",
        tz_offset=3.0,
    ))
"""
from afterlife._version import __version__
from afterlife.engine import Afterlife
from afterlife.sky import Birth, Chart, Moment, MoonPhase
from afterlife.formats import SVG, PNG, JSON, PlainText, CSV

__all__ = [
    "Afterlife",
    "Birth", "Chart", "Moment", "MoonPhase",
    "SVG", "PNG", "JSON", "PlainText", "CSV",
    "__version__",
]
