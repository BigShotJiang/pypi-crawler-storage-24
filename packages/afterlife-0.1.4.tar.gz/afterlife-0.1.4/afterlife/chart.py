"""
afterlife.chart — deprecated compatibility shim.

Use ``afterlife.sky`` instead::

    from afterlife.sky import Birth, Chart, Moment, MoonPhase
"""
import warnings as _warnings
from afterlife.sky import Birth as _Birth, Chart as _Chart


class ChartResult(_Chart):
    """Deprecated alias for :class:`afterlife.sky.Chart`."""

    def __repr__(self) -> str:
        cats = list(self._data.get("bodies", {}).keys())
        return f"<ChartResult jd={self._data.get('jd', '?')!r} categories={cats}>"


class BirthChart(_Chart):
    """Deprecated alias for :class:`afterlife.sky.Chart`."""

    def __repr__(self) -> str:
        inp  = self._data.get("input", {})
        date = inp.get("date", "?")
        cats = list(self._data.get("bodies", {}).keys())
        return f"<BirthChart {date} categories={cats}>"


class Chart(_Birth):
    """Deprecated alias for :class:`afterlife.sky.Birth`."""

    def compute(self) -> ChartResult:  # type: ignore[override]
        _warnings.warn(
            "afterlife.chart.Chart is deprecated — use afterlife.sky.Birth instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        import json
        from afterlife.engine import Afterlife as _Engine

        if not self._date:
            raise ValueError("Chart: date() must be set before compute()")
        if self._lat is None or self._lon is None:
            raise ValueError("Chart: location(lat, lon) must be set before compute()")

        engine = _Engine(ephe_dir=self._ephe_dir)
        engine._show_flags = self._show_flags

        raw = engine.compute_astro_chart(
            date_str=self._date,
            time_str=self._time,
            lat=self._lat,
            lon=self._lon,
            house_system=self._house_system,
            tz_offset=self._tz,
            fixed_star_orb=self._fixed_star_orb,
            exclude=",".join(self._exclude),
            include=",".join(self._include),
            sort_by=self._sort,
            limit=self._limit,
            **{f"{cat}_limit": n for cat, n in self._cat_limits.items()},
        )

        return ChartResult(json.loads(raw))
