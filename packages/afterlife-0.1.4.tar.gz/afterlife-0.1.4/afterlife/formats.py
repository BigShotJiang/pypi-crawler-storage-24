"""
Afterlife output formatters — fluent builders for every export format.

Usage::

    from afterlife.birth import Birth
    from afterlife.formats import SVG, PNG, JSON, PlainText, CSV

    chart = (
        Birth()
        .date("01-01-2000").time("10:10")
        .location(41.0, 29.0).timezone(3.0)
        .compute()
    )

    # SVG birth chart wheel
    path = (
        SVG(chart)
        .theme("dark")
        .label(True)
        .categories("planets", "points", "centaurs")
        .aspects("Conjunction", "Opposition", "Trine", "Square", "Sextile")
        .output("~/Downloads/chart.svg")
        .render()
    )

    # PNG (requires: pip install afterlife[png])
    path = PNG(chart).scale(2.0).output("chart.png").render()

    # JSON
    path = JSON(chart).indent(2).save("chart.json")
    text = JSON(chart).dumps()               # string, no file

    # Plain text (terminal-style table)
    text = PlainText(chart).categories("planets", "centaurs").render()
    PlainText(chart).print()

    # CSV — one row per body
    path = CSV(chart).categories("planets", "centaurs", "asteroids").save("chart.csv")
    text = CSV(chart).dumps()                # string, no file
"""
from __future__ import annotations

import csv as _csv
import io
import json as _json
import math
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from afterlife.constants import (
    ASPECT_GLYPH,
    ASPECTS,
    BODY_COLORS,
    CATEGORY_COLORS,
    PLANET_GLYPH,
    SIGN_COLORS,
    SIGNS_GLYPH,
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _to_dict(chart: Any) -> Dict[str, Any]:
    """Accept BirthChart/ChartResult or plain dict."""
    if hasattr(chart, "to_dict"):
        return chart.to_dict()
    if isinstance(chart, dict):
        return chart
    raise TypeError(f"Expected BirthChart or dict, got {type(chart).__name__}")


def _ts() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _downloads() -> Path:
    p = Path.home() / "Downloads"
    p.mkdir(exist_ok=True)
    return p


def _write(path: Optional[str], default_name: str, content: str, encoding: str = "utf-8") -> str:
    out = Path(path).expanduser().resolve() if path else _downloads() / default_name
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(content, encoding=encoding)
    return str(out)


# ---------------------------------------------------------------------------
# Base mixin — shared chart + output path handling
# ---------------------------------------------------------------------------

class _Base:
    def __init__(self, chart: Any = None) -> None:
        self._chart: Any          = chart
        self._output: Optional[str] = None

    def from_result(self, chart: Any) -> "_Base":
        """Set or replace the BirthChart / dict."""
        self._chart = chart
        return self

    def output(self, path: str) -> "_Base":
        """Explicit output path. Supports ~ expansion."""
        self._output = path
        return self

    def _require_chart(self) -> Dict[str, Any]:
        if self._chart is None:
            raise ValueError(
                f"{type(self).__name__}: no chart — pass BirthChart to "
                f"{type(self).__name__}(chart) or call .from_result(chart)"
            )
        return _to_dict(self._chart)


# ---------------------------------------------------------------------------
# SVG rendering engine (moved from svg.py)
# ---------------------------------------------------------------------------

_THEMES: Dict[str, Dict[str, str]] = {
    "dark": {
        "bg":          "#0a0a0f",
        "zodiac_bg":   "0d",
        "zodiac_ring": "44",
        "house_line":  "#1e1e2e",
        "axis_line":   "#4a4a6a",
        "house_num":   "#444466",
        "title":       "#333355",
        "tick":        "#555577",
        "aspect_circle": "#12121e",
        "dms_label":   "#555577",
    },
    "light": {
        "bg":          "#f8f8f2",
        "zodiac_bg":   "18",
        "zodiac_ring": "88",
        "house_line":  "#ccccdd",
        "axis_line":   "#888899",
        "house_num":   "#aaaacc",
        "title":       "#888899",
        "tick":        "#aaaacc",
        "aspect_circle": "#e8e8f0",
        "dms_label":   "#aaaacc",
    },
}

_BASE_R      = 320.0
_MARGIN_FRAC = 0.22

_F_ZOD_OUT   = 1.000
_F_ZOD_IN    = 0.830
_F_HOUSE_NUM = 0.755
_F_ASPECT    = 0.340

_CAT_BAND: Dict[str, float] = {
    "planets":         0.755,
    "points":          0.700,
    "lilith":          0.655,
    "advanced_points": 0.615,
    "moons":           0.575,
    "centaurs":        0.535,
    "dwarfs":          0.495,
    "asteroids":       0.455,
    "planetary_nodes": 0.420,
    "arabic_lots":     0.420,
    "exoplanets":      0.420,
    "interstellar":    0.420,
    "eclipses":        0.420,
    "fixed_stars":     1.100,
}

_RADIAL_STEP = 0.048

_ASPECT_COLORS: Dict[str, str] = {
    "Conjunction":     "#ffffff",
    "Opposition":      "#ef4444",
    "Trine":           "#22c55e",
    "Square":          "#ef4444",
    "Sextile":         "#3b82f6",
    "Quincunx":        "#f59e0b",
    "Semi-Sextile":    "#3b82f6",
    "Semi-Square":     "#f59e0b",
    "Sesquiquadrate":  "#f59e0b",
}
_ASPECT_OPACITY: Dict[str, float] = {
    "Conjunction":     0.90,
    "Opposition":      0.72,
    "Trine":           0.68,
    "Square":          0.68,
    "Sextile":         0.60,
    "Quincunx":        0.45,
    "Semi-Sextile":    0.40,
    "Semi-Square":     0.35,
    "Sesquiquadrate":  0.35,
}


def _system_font() -> str:
    try:
        r = subprocess.run(
            ["fc-match", "--format=%{family}", "sans-serif"],
            capture_output=True, text=True, timeout=2,
        )
        name = r.stdout.strip().split(",")[0].strip()
        if name:
            return name
    except Exception:
        pass
    return "sans-serif"


def _auto_scale(n_bodies: int) -> float:
    if n_bodies <= 50:
        return 1.0
    return min(round(n_bodies / 180.0 + 0.9, 1), 3.5)


def _lon_to_svg_angle(lon: float, asc_lon: float) -> float:
    shifted = (lon - asc_lon + 180.0) % 360.0
    return math.radians(shifted)


def _pt(cx: float, cy: float, r: float, a: float) -> Tuple[float, float]:
    return cx + r * math.cos(a), cy + r * math.sin(a)


def _hsl(h: float, s: float, l: float) -> str:
    c = (1.0 - abs(2.0 * l - 1.0)) * s
    x = c * (1.0 - abs((h / 60.0) % 2.0 - 1.0))
    m = l - c / 2.0
    if   h < 60:  r, g, b = c, x, 0.0
    elif h < 120: r, g, b = x, c, 0.0
    elif h < 180: r, g, b = 0.0, c, x
    elif h < 240: r, g, b = 0.0, x, c
    elif h < 300: r, g, b = x, 0.0, c
    else:         r, g, b = c, 0.0, x
    return "#{:02x}{:02x}{:02x}".format(
        int((r + m) * 255 + 0.5),
        int((g + m) * 255 + 0.5),
        int((b + m) * 255 + 0.5),
    )


def _body_color(name: str, cat: str, lon: float) -> str:
    c = BODY_COLORS.get(name)
    if c:
        return c
    if cat in ("asteroids", "fixed_stars", "exoplanets", "interstellar"):
        return _hsl(lon % 360.0, 0.70, 0.62)
    return CATEGORY_COLORS.get(cat, "#cccccc")


def _esc(s: str) -> str:
    return (s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;")
             .replace('"', "&quot;"))


def _label_anchor(angle_rad: float) -> str:
    cos = math.cos(angle_rad)
    if cos > 0.15:
        return "start"
    if cos < -0.15:
        return "end"
    return "middle"


def _place_glyphs(
    bodies: List[Dict[str, Any]],
    R: float,
    glyph_px: float = 12.0,
) -> List[Dict[str, Any]]:
    from collections import defaultdict

    r_aspect  = R * _F_ASPECT
    MIN_SEP_DEG = max(5.0, math.degrees(glyph_px * 1.2 / (R * 0.755)))

    cat_groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for b in bodies:
        cat_groups[b.get("_cat", "planets")].append(b)

    result: List[Dict[str, Any]] = []

    for cat, group in cat_groups.items():
        frac   = _CAT_BAND.get(cat, 0.74)
        r_base = frac * R
        r_step = _RADIAL_STEP * R
        r_min  = r_aspect + 10.0

        if frac > 1.0:
            r_draw = frac * R
            for b in sorted(group, key=lambda x: x["lon"]):
                out = dict(b)
                out["_draw_lon"] = b["lon"]
                out["_draw_r"]   = r_draw
                result.append(out)
            continue

        sorted_group = sorted(group, key=lambda x: float(x["lon"]))
        placed_positions: List[Tuple[float, float]] = []

        for b in sorted_group:
            lon = float(b["lon"])
            draw_r = r_base
            for layer in range(12):
                r_candidate = max(r_base - layer * r_step, r_min)
                collision   = False
                for prev_lon, prev_r in placed_positions:
                    if abs(prev_r - r_candidate) > r_step * 0.5:
                        continue
                    sep = abs((lon - prev_lon + 180.0) % 360.0 - 180.0)
                    if sep < MIN_SEP_DEG:
                        collision = True
                        break
                if not collision:
                    draw_r = r_candidate
                    break

            placed_positions.append((lon, draw_r))
            out = dict(b)
            out["_draw_lon"] = lon
            out["_draw_r"]   = draw_r
            result.append(out)

    return result


class _SVGBuilder:
    __slots__ = ("size", "font", "_p")

    def __init__(self, size: float, font: str, bg: str) -> None:
        self.size = size
        self.font = font
        self._p: List[str] = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'width="{size:.0f}" height="{size:.0f}" '
            f'viewBox="0 0 {size:.0f} {size:.0f}">',
            f'<rect width="{size:.0f}" height="{size:.0f}" fill="{bg}"/>',
        ]

    def circle(
        self, cx: float, cy: float, r: float,
        fill: str = "none", stroke: str = "#ffffff",
        sw: float = 1.0, op: float = 1.0,
    ) -> None:
        o = f' opacity="{op:.2f}"' if op < 0.999 else ""
        self._p.append(
            f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r:.2f}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="{sw:.1f}"{o}/>'
        )

    def line(
        self, x1: float, y1: float, x2: float, y2: float,
        stroke: str = "#ffffff", sw: float = 1.0,
        op: float = 1.0, dash: str = "",
    ) -> None:
        o = f' opacity="{op:.2f}"' if op < 0.999 else ""
        d = f' stroke-dasharray="{dash}"' if dash else ""
        self._p.append(
            f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
            f'stroke="{stroke}" stroke-width="{sw:.1f}"{o}{d}/>'
        )

    def sector(
        self, cx: float, cy: float,
        r_out: float, r_in: float,
        a1: float, a2: float,
        fill: str, stroke: str = "none", sw: float = 0.5,
    ) -> None:
        diff = (a2 - a1) % (2 * math.pi)
        if diff < 1e-6:
            diff = 2 * math.pi
        large = 1 if diff > math.pi else 0

        ox1, oy1 = _pt(cx, cy, r_out, a1)
        ox2, oy2 = _pt(cx, cy, r_out, a1 + diff)
        ix1, iy1 = _pt(cx, cy, r_in,  a1 + diff)
        ix2, iy2 = _pt(cx, cy, r_in,  a1)
        d = (
            f"M {ox1:.2f} {oy1:.2f} "
            f"A {r_out:.2f} {r_out:.2f} 0 {large} 1 {ox2:.2f} {oy2:.2f} "
            f"L {ix1:.2f} {iy1:.2f} "
            f"A {r_in:.2f} {r_in:.2f} 0 {large} 0 {ix2:.2f} {iy2:.2f} Z"
        )
        self._p.append(
            f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw:.1f}"/>'
        )

    def text(
        self, x: float, y: float, s: str,
        color: str = "#ffffff", size: float = 12.0,
        anchor: str = "middle", baseline: str = "central",
        bold: bool = False, op: float = 1.0,
    ) -> None:
        fw = "bold" if bold else "normal"
        o  = f' opacity="{op:.2f}"' if op < 0.999 else ""
        self._p.append(
            f'<text x="{x:.1f}" y="{y:.1f}" '
            f'font-family="{_esc(self.font)},sans-serif" '
            f'font-size="{size:.1f}" font-weight="{fw}" fill="{color}" '
            f'text-anchor="{anchor}" dominant-baseline="{baseline}"{o}>'
            f'{_esc(str(s))}</text>'
        )

    def close(self) -> str:
        self._p.append("</svg>")
        return "\n".join(self._p)


def _render_svg(
    chart: Any,
    *,
    scale: Optional[float] = None,
    label: bool = False,
    aspects: Optional[List[str]] = None,
    include_cats: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None,
    output_path: Optional[str] = None,
    theme: str = "dark",
) -> str:
    """
    Render a birth chart SVG, write to disk, return the absolute file path.

    Accepts either a BirthChart (from Birth.compute()) or a plain dict.
    """
    if hasattr(chart, "to_dict"):
        data = chart.to_dict()
    elif isinstance(chart, dict):
        data = chart
    else:
        raise TypeError(f"render_svg: expected BirthChart or dict, got {type(chart)}")

    bodies_data: Dict[str, Any] = data.get("bodies", {})
    houses_data: Dict[str, Any] = data.get("houses", {})
    inp:         Dict[str, Any] = data.get("input",  {})

    t = _THEMES.get(theme, _THEMES["dark"])

    cats     = list(include_cats) if include_cats else ["planets", "points", "lilith"]
    excl_set = set(exclude or [])

    visible: List[Dict[str, Any]] = []
    for cat in cats:
        objs = bodies_data.get(cat, {})
        if not isinstance(objs, dict):
            continue
        for name, obj in objs.items():
            if name in excl_set or not isinstance(obj, dict):
                continue
            lon = obj.get("lon")
            if lon is None:
                continue
            visible.append({**obj, "name": name, "_cat": cat})

    s = max(1.0, float(scale)) if scale is not None else _auto_scale(len(visible))

    R        = _BASE_R * s
    margin   = R * _MARGIN_FRAC
    size     = 2.0 * (R + margin)
    cx = cy  = size / 2.0

    r_zod_out = R * _F_ZOD_OUT
    r_zod_in  = R * _F_ZOD_IN
    r_aspect  = R * _F_ASPECT

    sz_sign   = max(11.0, 13.0 * s)
    sz_glyph  = max(10.0, 11.5 * s)
    sz_label  = max( 6.0,  7.0 * s)
    sz_house  = max( 7.0,  8.0 * s)
    sz_axis   = max( 8.5, 10.0 * s)

    font = _system_font()
    svg  = _SVGBuilder(size, font, t["bg"])

    angles = houses_data.get("angles", {})
    cusps  = houses_data.get("cusps", [])

    asc_lon = float(angles.get("ASC", cusps[0]  if cusps else 0.0))
    mc_lon  = float(angles.get("MC",  cusps[9]  if len(cusps) > 9 else (asc_lon + 90.0) % 360.0))

    def ang(lon: float) -> float:
        return _lon_to_svg_angle(float(lon), asc_lon)

    # Zodiac band
    for i in range(12):
        a1    = ang(i * 30.0)
        a2    = ang(i * 30.0 + 30.0)
        color = SIGN_COLORS[i]
        glyph = SIGNS_GLYPH[i]

        svg.sector(cx, cy, r_zod_out, r_zod_in, a1, a2,
                   fill=f"{color}{t['zodiac_bg']}",
                   stroke=f"{color}{t['zodiac_ring']}", sw=0.7)

        a_mid = ang(i * 30.0 + 15.0)
        r_mid = (r_zod_out + r_zod_in) / 2.0
        gx, gy = _pt(cx, cy, r_mid, a_mid)
        svg.text(gx, gy, glyph, color=color, size=sz_sign)

    svg.circle(cx, cy, r_zod_out, stroke=t["axis_line"],  sw=1.5)
    svg.circle(cx, cy, r_zod_in,  stroke=t["house_line"], sw=0.8)

    # Degree tick marks
    for deg in range(360):
        is_5  = (deg % 5  == 0)
        is_30 = (deg % 30 == 0)
        if not (is_5 or is_30):
            continue
        a     = ang(float(deg))
        r_out_tick = r_zod_in - (7.0 * s if is_5 else 4.0 * s)
        x1, y1 = _pt(cx, cy, r_zod_in,    a)
        x2, y2 = _pt(cx, cy, r_out_tick,  a)
        sw = 0.8 * s if is_5 else 0.4 * s
        svg.line(x1, y1, x2, y2, stroke=t["tick"], sw=sw, op=0.6)

    # House cusp lines
    for i, cusp_lon in enumerate(cusps):
        a      = ang(cusp_lon)
        x_out, y_out = _pt(cx, cy, r_zod_in, a)
        x_in,  y_in  = _pt(cx, cy, r_aspect, a)
        is_axis = (i % 3 == 0)

        svg.line(x_out, y_out, x_in, y_in,
                 stroke=t["axis_line"] if is_axis else t["house_line"],
                 sw=0.9 if is_axis else 0.45,
                 op=0.85 if is_axis else 0.55)

        if len(cusps) == 12:
            nc   = cusps[(i + 1) % 12]
            diff = (nc - cusp_lon) % 360.0
            a_m  = ang(cusp_lon + diff / 2.0)
            hx, hy = _pt(cx, cy, R * _F_HOUSE_NUM, a_m)
            svg.text(hx, hy, str(i + 1), color=t["house_num"], size=sz_house)

    # ASC / DSC / MC / IC labels
    _AXES = [
        (asc_lon,                       "ASC", "#ffffff"),
        ((asc_lon + 180.0) % 360.0,     "DSC", "#999999"),
        (mc_lon,                         "MC",  "#dddddd"),
        ((mc_lon  + 180.0) % 360.0,      "IC",  "#777777"),
    ]
    r_label_base = r_zod_out + margin * 0.38

    for lon, lbl, col in _AXES:
        a          = ang(lon)
        x_c,  y_c  = _pt(cx, cy, 0.0,        a)
        x_end, y_end = _pt(cx, cy, r_zod_out, a)
        svg.line(x_c, y_c, x_end, y_end, stroke=col, sw=0.9, op=0.40)

        lx, ly   = _pt(cx, cy, r_label_base, a)
        anchor   = _label_anchor(a)
        svg.text(lx, ly, lbl, color=col, size=sz_axis, anchor=anchor, bold=True)

    # Aspect lines
    asp_names = set(aspects) if aspects is not None else set(ASPECTS.keys())
    lon_map: Dict[str, float] = {b["name"]: float(b["lon"]) for b in visible}

    from afterlife.engine import Afterlife as _Eng
    computed_aspects = _Eng.compute_aspects(lon_map)

    for asp in computed_aspects:
        aname = asp.get("aspect", "")
        if aname not in asp_names:
            continue
        b1 = asp.get("a", "")
        b2 = asp.get("b", "")
        if b1 not in lon_map or b2 not in lon_map:
            continue
        color   = _ASPECT_COLORS.get(aname, "#666666")
        opacity = _ASPECT_OPACITY.get(aname, 0.40)
        x1, y1  = _pt(cx, cy, r_aspect, ang(lon_map[b1]))
        x2, y2  = _pt(cx, cy, r_aspect, ang(lon_map[b2]))
        svg.line(x1, y1, x2, y2, stroke=color, sw=0.7 * s, op=opacity)

    svg.circle(cx, cy, r_aspect, stroke=t["aspect_circle"], sw=0.6)

    # Body glyphs
    placed = _place_glyphs(visible, R, sz_glyph)

    for body in placed:
        name      = body["name"]
        real_lon  = float(body["lon"])
        draw_lon  = float(body.get("_draw_lon", real_lon))
        draw_r    = float(body.get("_draw_r",   R * _CAT_BAND.get(body.get("_cat","planets"), 0.74)))
        cat       = body.get("_cat", "planets")
        color     = _body_color(name, cat, real_lon)
        glyph     = PLANET_GLYPH.get(name, name[:3])
        is_retro  = bool(body.get("retro", False))
        is_outside = draw_r > r_zod_out

        a_real = ang(real_lon)
        a_draw = ang(draw_lon)

        if is_outside:
            tick_r = r_zod_out + 3.5 * s
            tx, ty = _pt(cx, cy, tick_r, a_real)
            svg.circle(tx, ty, 1.8 * s, fill=color, stroke="none", op=0.85)

            lx, ly  = _pt(cx, cy, draw_r, a_draw)
            svg.line(tx, ty, lx, ly, stroke=color, sw=0.3 * s, op=0.22)
            svg.text(lx, ly, name, color=color,
                     size=sz_label * 0.85,
                     anchor=_label_anchor(a_draw), op=0.75)
        else:
            bx, by = _pt(cx, cy, draw_r, a_draw)
            svg.text(bx, by, glyph, color=color, size=sz_glyph)

            if is_retro:
                perp = a_draw + math.pi / 2
                rx = bx + math.cos(perp) * sz_glyph * 0.55
                ry = by + math.sin(perp) * sz_glyph * 0.55
                svg.text(rx, ry, "℞", color=color,
                         size=sz_glyph * 0.50, op=0.72)

            if label:
                label_r = draw_r - sz_glyph * 1.15
                label_r = max(label_r, r_aspect + sz_label + 4.0)
                lx, ly  = _pt(cx, cy, label_r, a_draw)
                deg_in_sign = body.get("lon", real_lon) % 30.0
                deg_str = f"{int(deg_in_sign):02d}°"
                svg.text(lx, ly, name, color=color, size=sz_label,
                         anchor=_label_anchor(a_draw), op=0.85)
                deg_r = label_r - sz_label * 1.2
                if deg_r > r_aspect + 4.0:
                    dlx, dly = _pt(cx, cy, deg_r, a_draw)
                    svg.text(dlx, dly, deg_str, color=color,
                             size=sz_label * 0.85,
                             anchor=_label_anchor(a_draw), op=0.55)

            dot_r  = r_zod_in - 3.0 * s
            dx, dy = _pt(cx, cy, dot_r, a_real)
            svg.circle(dx, dy, 1.5 * s, fill=color, stroke="none", op=0.85)

            sep_deg = abs((draw_lon - real_lon + 180.0) % 360.0 - 180.0)
            if sep_deg > 1.0:
                svg.line(dx, dy, bx, by,
                         stroke=color, sw=0.35 * s, op=0.22)

    # Aspect legend
    leg_x = size - margin * 0.9
    leg_y = size - margin * 0.5
    svg.text(leg_x, leg_y - sz_label * (len(asp_names) + 0.5),
             "aspects", color=t["title"], size=sz_label * 0.9,
             anchor="end", op=0.5)
    for i, aname in enumerate(sorted(asp_names)):
        g   = ASPECT_GLYPH.get(aname, "")
        col = _ASPECT_COLORS.get(aname, "#888888")
        op  = _ASPECT_OPACITY.get(aname, 0.4)
        svg.text(leg_x, leg_y - sz_label * i,
                 f"{g} {aname}", color=col, size=sz_label,
                 anchor="end", op=op)

    # Title
    date_str = inp.get("date", "")
    lat_v    = inp.get("lat",  "")
    lon_v    = inp.get("lon",  "")
    hs       = inp.get("house_system", "")
    subtitle = f"{lat_v}° / {lon_v}°  ·  {hs}" if lat_v else ""

    svg.text(sz_axis, sz_axis * 1.2,
             f"Birth Chart  {date_str}",
             color=t["title"], size=sz_axis * 0.85,
             anchor="start", bold=True)
    if subtitle:
        svg.text(sz_axis, sz_axis * 2.2,
                 subtitle,
                 color=t["title"], size=sz_axis * 0.65,
                 anchor="start", op=0.6)

    # Write file
    if output_path:
        out = Path(output_path).expanduser().resolve()
    else:
        dl = Path.home() / "Downloads"
        dl.mkdir(exist_ok=True)
        ts  = datetime.now().strftime("%Y%m%d_%H%M%S")
        out = dl / f"afterlife_chart_{ts}.svg"

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(svg.close(), encoding="utf-8")
    return str(out)


# ---------------------------------------------------------------------------
# SVG — birth chart wheel
# ---------------------------------------------------------------------------

class SVG(_Base):
    """
    Fluent SVG birth chart renderer::

        SVG(chart)
        .theme("dark")          # "dark" | "light"
        .label(True)            # show body name + degree
        .scale(1.2)             # override auto-scale (≥ 1.0)
        .categories("planets", "points", "centaurs", "asteroids", "fixed_stars")
        .exclude("South Node", "Mean Node")
        .aspects("Conjunction", "Opposition", "Trine", "Square", "Sextile")
        .no_aspects()           # disable all aspect lines
        .output("~/Downloads/chart.svg")
        .render()               # → absolute file path (str)
    """

    def __init__(self, chart: Any = None) -> None:
        super().__init__(chart)
        self._theme:   str                   = "dark"
        self._label:   bool                  = False
        self._scale:   Optional[float]       = None
        self._cats:    Optional[List[str]]   = None
        self._exclude_names: List[str]       = []
        self._aspects: Optional[List[str]]   = None

    def from_result(self, chart: Any) -> "SVG":
        self._chart = chart
        return self

    def output(self, path: str) -> "SVG":
        self._output = path
        return self

    def theme(self, name: str) -> "SVG":
        """``"dark"`` (default) or ``"light"``."""
        self._theme = name
        return self

    def label(self, show: bool = True) -> "SVG":
        """Draw body name + degree inside each glyph band."""
        self._label = show
        return self

    def scale(self, factor: float) -> "SVG":
        """Override auto-scale. Values ≥ 1.0."""
        self._scale = max(1.0, float(factor))
        return self

    def categories(self, *cats: str) -> "SVG":
        """
        Body categories to render.

        Defaults: ``planets``, ``points``, ``lilith``.
        Options: ``planets``, ``points``, ``lilith``, ``centaurs``,
        ``asteroids``, ``dwarfs``, ``fixed_stars``, ``arabic_lots``,
        ``advanced_points``, ``planetary_nodes``, ``exoplanets``,
        ``interstellar``, ``eclipses``, ``moons``.
        """
        self._cats = list(cats)
        return self

    def exclude(self, *names: str) -> "SVG":
        """Body names to skip (e.g. ``"South Node"``)."""
        self._exclude_names.extend(names)
        return self

    def aspects(self, *names: str) -> "SVG":
        """
        Aspect types to draw.  No args = all aspects::

            .aspects()                             # all
            .aspects("Conjunction", "Trine")       # only these
        """
        self._aspects = list(names) if names else None
        return self

    def no_aspects(self) -> "SVG":
        """Disable all aspect lines."""
        self._aspects = []
        return self

    def render(self) -> str:
        """Write SVG to disk, return absolute path."""
        self._require_chart()
        return _render_svg(
            self._chart,
            scale        = self._scale,
            label        = self._label,
            aspects      = self._aspects,
            include_cats = self._cats,
            exclude      = self._exclude_names or None,
            output_path  = self._output,
            theme        = self._theme,
        )


# ---------------------------------------------------------------------------
# PNG — rasterised chart (requires cairosvg)
# ---------------------------------------------------------------------------

class PNG(_Base):
    """
    Rasterised PNG chart.  Renders SVG internally then converts via ``cairosvg``::

        PNG(chart).scale(2.0).dpi(150).output("chart.png").render()

    Install the optional dependency::

        pip install cairosvg
    """

    def __init__(self, chart: Any = None) -> None:
        super().__init__(chart)
        self._theme:   str                   = "dark"
        self._label:   bool                  = False
        self._scale:   float                 = 2.0
        self._cats:    Optional[List[str]]   = None
        self._exclude_names: List[str]       = []
        self._aspects: Optional[List[str]]   = None
        self._dpi:     int                   = 96

    def from_result(self, chart: Any) -> "PNG":
        self._chart = chart
        return self

    def output(self, path: str) -> "PNG":
        self._output = path
        return self

    def theme(self, name: str) -> "PNG":
        self._theme = name
        return self

    def label(self, show: bool = True) -> "PNG":
        self._label = show
        return self

    def scale(self, factor: float) -> "PNG":
        """Resolution multiplier. Default 2.0 (2× SVG size)."""
        self._scale = max(1.0, float(factor))
        return self

    def dpi(self, value: int) -> "PNG":
        """Output DPI hint passed to cairosvg. Default 96."""
        self._dpi = int(value)
        return self

    def categories(self, *cats: str) -> "PNG":
        self._cats = list(cats)
        return self

    def exclude(self, *names: str) -> "PNG":
        self._exclude_names.extend(names)
        return self

    def aspects(self, *names: str) -> "PNG":
        self._aspects = list(names) if names else None
        return self

    def no_aspects(self) -> "PNG":
        self._aspects = []
        return self

    def render(self) -> str:
        """Render PNG, return absolute path."""
        self._require_chart()
        try:
            import cairosvg  # type: ignore
        except ImportError:
            raise ImportError(
                "PNG export requires cairosvg.\n"
                "Install it with:  pip install cairosvg\n"
                "or:               pip install afterlife[png]"
            ) from None

        import tempfile, os

        with tempfile.NamedTemporaryFile(suffix=".svg", delete=False) as tmp:
            tmp_svg = tmp.name

        try:
            _render_svg(
                self._chart,
                scale        = self._scale,
                label        = self._label,
                aspects      = self._aspects,
                include_cats = self._cats,
                exclude      = self._exclude_names or None,
                output_path  = tmp_svg,
                theme        = self._theme,
            )
            out = (
                Path(self._output).expanduser().resolve()
                if self._output
                else _downloads() / f"afterlife_chart_{_ts()}.png"
            )
            out.parent.mkdir(parents=True, exist_ok=True)
            cairosvg.svg2png(
                url=tmp_svg,
                write_to=str(out),
                dpi=self._dpi,
            )
        finally:
            os.unlink(tmp_svg)

        return str(out)


# ---------------------------------------------------------------------------
# JSON — structured data export
# ---------------------------------------------------------------------------

class JSON(_Base):
    """
    Export chart data as JSON::

        # Save to file
        path = JSON(chart).indent(2).save("chart.json")

        # Get string
        text = JSON(chart).dumps()

        # Pretty-print to stdout
        JSON(chart).print()

        # Only specific categories
        JSON(chart).categories("planets", "centaurs").save("planets.json")
    """

    def __init__(self, chart: Any = None) -> None:
        super().__init__(chart)
        self._indent:    int                 = 2
        self._cats:      Optional[List[str]] = None
        self._exclude_names: List[str]       = []
        self._bodies_only: bool              = False

    def from_result(self, chart: Any) -> "JSON":
        self._chart = chart
        return self

    def output(self, path: str) -> "JSON":
        self._output = path
        return self

    def indent(self, n: int) -> "JSON":
        """JSON indentation spaces. Default 2. Use 0 for compact."""
        self._indent = int(n)
        return self

    def categories(self, *cats: str) -> "JSON":
        """Only include these body categories in the output."""
        self._cats = list(cats)
        return self

    def exclude(self, *names: str) -> "JSON":
        """Body names to remove from output."""
        self._exclude_names.extend(names)
        return self

    def bodies_only(self) -> "JSON":
        """Strip metadata — return only the ``bodies`` dict."""
        self._bodies_only = True
        return self

    def _build(self) -> Dict[str, Any]:
        data = dict(self._require_chart())
        bodies = dict(data.get("bodies", {}))

        if self._cats is not None:
            bodies = {k: v for k, v in bodies.items() if k in self._cats}

        if self._exclude_names:
            excl = set(self._exclude_names)
            bodies = {
                cat: {n: o for n, o in objs.items() if n not in excl}
                for cat, objs in bodies.items()
                if isinstance(objs, dict)
            }

        if self._bodies_only:
            return bodies

        data["bodies"] = bodies
        return data

    def dumps(self) -> str:
        """Return JSON string without writing a file."""
        indent = self._indent if self._indent > 0 else None
        return _json.dumps(self._build(), ensure_ascii=False, indent=indent)

    def save(self, path: Optional[str] = None) -> str:
        """Write JSON to disk, return absolute path."""
        target = path or self._output
        return _write(target, f"afterlife_chart_{_ts()}.json", self.dumps())

    def print(self) -> None:
        """Pretty-print to stdout."""
        print(self.dumps())

    def render(self) -> str:
        return self.save()


# ---------------------------------------------------------------------------
# PlainText — human-readable table (terminal style)
# ---------------------------------------------------------------------------

class PlainText(_Base):
    """
    Human-readable plain-text chart summary::

        # Print to terminal
        PlainText(chart).print()

        # Only planets + centaurs
        PlainText(chart).categories("planets", "centaurs").print()

        # Save to file
        path = PlainText(chart).save("chart.txt")

        # Get string
        text = PlainText(chart).render()
    """

    _CAT_ORDER = [
        "planets", "centaurs", "asteroids", "dwarfs", "moons",
        "points", "advanced_points", "lilith", "planetary_nodes",
        "arabic_lots", "fixed_stars", "exoplanets", "interstellar",
        "eclipses",
    ]

    def __init__(self, chart: Any = None) -> None:
        super().__init__(chart)
        self._cats:          Optional[List[str]] = None
        self._exclude_names: List[str]           = []
        self._show_house:    bool                = True
        self._show_retro:    bool                = True
        self._width:         int                 = 72

    def from_result(self, chart: Any) -> "PlainText":
        self._chart = chart
        return self

    def output(self, path: str) -> "PlainText":
        self._output = path
        return self

    def categories(self, *cats: str) -> "PlainText":
        """Categories to include. Default: all."""
        self._cats = list(cats)
        return self

    def exclude(self, *names: str) -> "PlainText":
        self._exclude_names.extend(names)
        return self

    def width(self, n: int) -> "PlainText":
        """Line width for header/separator. Default 72."""
        self._width = int(n)
        return self

    def render(self) -> str:
        """Return formatted string."""
        data    = self._require_chart()
        bodies  = data.get("bodies", {})
        inp     = data.get("input", {})
        houses  = data.get("houses", {})
        excl    = set(self._exclude_names)
        cats    = self._cats if self._cats is not None else self._CAT_ORDER
        w       = self._width

        lines: List[str] = []
        sep   = "─" * w

        date = inp.get("date", "?")
        time = inp.get("time", "?")
        lat  = inp.get("lat",  "?")
        lon  = inp.get("lon",  "?")
        tz   = inp.get("tz_offset", "?")
        hs   = inp.get("house_system", "?")
        lines.append(sep)
        lines.append(f"  BIRTH CHART  {date}  {time}  UTC{tz:+.1f}" if isinstance(tz, float) else f"  BIRTH CHART  {date}  {time}")
        lines.append(f"  Lat {lat}°  Lon {lon}°  Houses: {hs.title()}")
        lines.append(sep)

        cusps  = houses.get("cusps", [])
        angles = houses.get("angles", {})
        if cusps or angles:
            lines.append("")
            lines.append("  ANGLES")
            for k, v in angles.items():
                from afterlife.engine import Afterlife as _E
                lines.append(f"    {k:<12} {_E.lon_to_sign_dms(v)}")
            lines.append("")

        col_w = [20, 22, 6, 8]
        hdr   = (f"  {'Body':<{col_w[0]}} {'Position':<{col_w[1]}} "
                 f"{'House':<{col_w[2]}} {'':>{col_w[3]}}")

        for cat in cats:
            objs = bodies.get(cat)
            if not isinstance(objs, dict) or not objs:
                continue
            visible = {n: o for n, o in objs.items()
                       if n not in excl and isinstance(o, dict)}
            if not visible:
                continue

            lines.append(f"  {cat.upper().replace('_', ' ')}")
            lines.append(hdr)
            lines.append("  " + "·" * (w - 2))

            for name, obj in visible.items():
                dms   = obj.get("dms", "")
                house = obj.get("house")
                retro = "℞" if obj.get("retro") else ""
                h_str = f"H{house}" if house else ""
                lines.append(
                    f"  {name:<{col_w[0]}} {dms:<{col_w[1]}} "
                    f"{h_str:<{col_w[2]}} {retro:>{col_w[3]}}"
                )
            lines.append("")

        lines.append(sep)
        return "\n".join(lines)

    def print(self) -> None:
        """Print to stdout."""
        print(self.render())

    def save(self, path: Optional[str] = None) -> str:
        """Write to file, return absolute path."""
        target = path or self._output
        return _write(target, f"afterlife_chart_{_ts()}.txt", self.render())

    def render_to_file(self) -> str:
        return self.save()


# ---------------------------------------------------------------------------
# CSV — one row per celestial body
# ---------------------------------------------------------------------------

class CSV(_Base):
    """
    Export chart bodies as CSV (one row per body)::

        # Save to file
        path = CSV(chart).categories("planets", "centaurs").save("chart.csv")

        # Get string
        text = CSV(chart).dumps()

        # All categories, save to Downloads
        CSV(chart).render()

    Columns: category, name, lon, lat, sign, dms, house, retro, speed, type
    """

    _CAT_ORDER = [
        "planets", "centaurs", "asteroids", "dwarfs", "moons",
        "points", "advanced_points", "lilith", "planetary_nodes",
        "arabic_lots", "fixed_stars", "exoplanets", "interstellar",
        "eclipses",
    ]

    _FIELDS = ["category", "name", "lon", "lat", "sign", "dms",
               "house", "retro", "speed", "type"]

    def __init__(self, chart: Any = None) -> None:
        super().__init__(chart)
        self._cats:          Optional[List[str]] = None
        self._exclude_names: List[str]           = []
        self._delimiter:     str                 = ","
        self._fields:        Optional[List[str]] = None

    def from_result(self, chart: Any) -> "CSV":
        self._chart = chart
        return self

    def output(self, path: str) -> "CSV":
        self._output = path
        return self

    def categories(self, *cats: str) -> "CSV":
        """Categories to export. Default: all."""
        self._cats = list(cats)
        return self

    def exclude(self, *names: str) -> "CSV":
        self._exclude_names.extend(names)
        return self

    def delimiter(self, char: str) -> "CSV":
        """Column delimiter. Default ``,``. Use ``\\t`` for TSV."""
        self._delimiter = char
        return self

    def fields(self, *names: str) -> "CSV":
        """
        Choose which columns to include and their order.

        Available: ``category``, ``name``, ``lon``, ``lat``, ``sign``,
        ``dms``, ``house``, ``retro``, ``speed``, ``type``.
        """
        self._fields = list(names)
        return self

    def _rows(self) -> List[Dict[str, Any]]:
        data   = self._require_chart()
        bodies = data.get("bodies", {})
        cats   = self._cats if self._cats is not None else self._CAT_ORDER
        excl   = set(self._exclude_names)
        rows: List[Dict[str, Any]] = []

        for cat in cats:
            objs = bodies.get(cat)
            if not isinstance(objs, dict):
                continue
            for name, obj in objs.items():
                if name in excl or not isinstance(obj, dict):
                    continue
                rows.append({
                    "category": cat,
                    "name":     name,
                    "lon":      round(float(obj.get("lon") or 0), 6),
                    "lat":      round(float(obj.get("lat") or 0), 6),
                    "sign":     obj.get("sign", ""),
                    "dms":      obj.get("dms",  ""),
                    "house":    obj.get("house", ""),
                    "retro":    "R" if obj.get("retro") else "",
                    "speed":    round(float(obj.get("speed") or 0), 6),
                    "type":     obj.get("type", ""),
                })
        return rows

    def dumps(self) -> str:
        """Return CSV string without writing a file."""
        fields = self._fields or self._FIELDS
        rows   = self._rows()
        buf    = io.StringIO()
        writer = _csv.DictWriter(
            buf, fieldnames=fields,
            delimiter=self._delimiter,
            extrasaction="ignore",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)
        return buf.getvalue()

    def save(self, path: Optional[str] = None) -> str:
        """Write CSV to disk, return absolute path."""
        target = path or self._output
        return _write(target, f"afterlife_chart_{_ts()}.csv", self.dumps())

    def render(self) -> str:
        return self.save()
