from __future__ import annotations

import json
from collections import defaultdict
from typing import Any, Dict, List, Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------

PURPLE  = "#ae00ff"
VIOLET  = "#7c3aed"
WHITE   = "#ffffff"
SILVER  = "#cccccc"
DIM     = "dim white"
ACCENT  = f"bold {PURPLE}"
ERROR   = "bold red"

console = Console(highlight=False)

# Category display order and labels
_CAT_LABEL: Dict[str, str] = {
    "planets":         "Planets",
    "moons":           "Moons",
    "dwarfs":          "Dwarfs / TNO",
    "asteroids":       "Asteroids",
    "centaurs":        "Centaurs",
    "points":          "Points",
    "advanced_points": "Advanced Points",
    "lilith":          "Lilith",
    "planetary_nodes": "Planetary Nodes",
    "arabic_lots":     "Arabic Lots",
    "fixed_stars":     "Fixed Stars",
    "exoplanets":      "Exoplanets",
    "interstellar":    "Interstellar",
    "eclipses":        "Eclipses",
}

_CAT_ORDER = list(_CAT_LABEL)

# Category colour accents
_CAT_COLOR: Dict[str, str] = {
    "planets":         "#ae00ff",
    "moons":           "#6366f1",
    "dwarfs":          "#8b5cf6",
    "asteroids":       "#a78bfa",
    "centaurs":        "#c4b5fd",
    "points":          "#e879f9",
    "advanced_points": "#f0abfc",
    "lilith":          "#f472b6",
    "planetary_nodes": "#fb7185",
    "arabic_lots":     "#fbbf24",
    "fixed_stars":     "#facc15",
    "exoplanets":      "#4ade80",
    "interstellar":    "#22d3ee",
    "eclipses":        "#f87171",
}

# Sign glyphs for compact display
_SIGN_GLYPH: Dict[str, str] = {
    "Aries": "♈", "Taurus": "♉", "Gemini": "♊", "Cancer": "♋",
    "Leo": "♌", "Virgo": "♍", "Libra": "♎", "Scorpio": "♏",
    "Sagittarius": "♐", "Capricorn": "♑", "Aquarius": "♒", "Pisces": "♓",
}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _glyph(name: str) -> str:
    from afterlife.constants import PLANET_GLYPH
    return PLANET_GLYPH.get(name, "")


def _sign_g(sign: str) -> str:
    return _SIGN_GLYPH.get(sign, "")


def _retro(obj: Dict[str, Any]) -> str:
    return "[dim]℞[/dim]" if obj.get("retro") else ""


def _cat_color(cat: str) -> str:
    return _CAT_COLOR.get(cat, PURPLE)


def _table(
    title: str,
    columns: List[tuple],
    color: str = PURPLE,
    box_style: Any = box.SIMPLE_HEAD,
) -> Table:
    t = Table(
        title        = title,
        title_style  = f"bold {color}",
        box          = box_style,
        border_style = color,
        header_style = f"bold {color}",
        show_lines   = False,
        pad_edge     = False,
        expand       = False,
    )
    for header, style, justify in columns:
        t.add_column(header, style=style, justify=justify, no_wrap=True)
    return t


# ---------------------------------------------------------------------------
# Error / info
# ---------------------------------------------------------------------------

def show_error(msg: str) -> None:
    console.print(Panel(
        f"[{ERROR}]{msg}[/]",
        title="[bold red]Error[/]",
        border_style="red",
    ))


def show_json(data: Any) -> None:
    console.print_json(json.dumps(data, ensure_ascii=False, indent=2))


# ---------------------------------------------------------------------------
# Input panel
# ---------------------------------------------------------------------------

def show_input_panel(inp: Dict[str, Any]) -> None:
    tz  = inp.get("tz_offset", 0)
    tz_str = f"UTC{float(tz):+.1f}" if tz is not None else "UTC"
    lines = [
        f"[{DIM}]Date    [/]  [bold {WHITE}]{inp.get('date', '')}[/]  "
        f"[{DIM}]Time[/]  [bold {WHITE}]{inp.get('time', '')}[/]  "
        f"[{DIM}]{tz_str}[/]",
        f"[{DIM}]Lat[/]   [bold {WHITE}]{inp.get('lat', '')}°[/]  "
        f"[{DIM}]Lon[/]  [bold {WHITE}]{inp.get('lon', '')}°[/]  "
        f"[{DIM}]Houses:[/] [bold {WHITE}]{inp.get('house_system', 'placidus').title()}[/]",
    ]
    console.print(Panel(
        "\n".join(lines),
        title=f"[bold {PURPLE}]Birth Chart[/]",
        border_style=PURPLE,
        padding=(0, 1),
    ))


# ---------------------------------------------------------------------------
# Bodies table — rich category sections
# ---------------------------------------------------------------------------

def show_bodies(bodies: Dict[str, Any], title: str = "Bodies") -> None:
    # Respect defined order; append unknowns at the end
    ordered_cats = [c for c in _CAT_ORDER if c in bodies]
    ordered_cats += [c for c in bodies if c not in _CAT_ORDER]

    for cat in ordered_cats:
        objs = bodies.get(cat)
        if not isinstance(objs, dict) or not objs:
            continue

        color     = _cat_color(cat)
        cat_label = _CAT_LABEL.get(cat, cat.replace("_", " ").title())
        count     = len(objs)

        t = _table(
            f"{cat_label}  [dim]({count})[/dim]",
            [
                ("",      f"{color}",  "center"),   # glyph
                ("Body",  WHITE,       "left"),
                ("",      DIM,         "left"),      # sign glyph
                ("Sign",  DIM,         "left"),
                ("Pos",   SILVER,      "left"),
                ("House", color,       "right"),
                ("Lon",   DIM,         "right"),
                ("",      "dim",       "left"),      # retro
            ],
            color=color,
        )

        for name, obj in objs.items():
            if not isinstance(obj, dict):
                continue
            sign    = obj.get("sign", "")
            raw_dms = obj.get("dms", "")
            # Strip sign prefix from dms for cleaner "Pos" column
            pos = raw_dms[len(sign):].strip() if sign and raw_dms.startswith(sign) else raw_dms
            lon = obj.get("lon")
            lon_str = f"{float(lon):.2f}°" if lon is not None else ""
            house   = obj.get("house")

            t.add_row(
                _glyph(name),
                name,
                _sign_g(sign),
                sign,
                pos,
                str(house) if house else "",
                lon_str,
                _retro(obj),
            )

        console.print(t)


# ---------------------------------------------------------------------------
# Houses panel
# ---------------------------------------------------------------------------

def show_houses(houses: Dict[str, Any]) -> None:
    if not houses or not houses.get("cusps"):
        return

    angles = houses.get("angles", {})
    cusps  = houses.get("cusps", [])
    system = houses.get("system", "").title()

    t = _table(
        f"Houses — {system}",
        [
            ("House", PURPLE, "right"),
            ("Cusp",  WHITE,  "left"),
            ("Sign",  DIM,    "left"),
        ],
        color=VIOLET,
        box_style=box.SIMPLE,
    )

    from afterlife.engine import Afterlife as _E
    for i, cusp_lon in enumerate(cusps, 1):
        sign, *_ = _E.zodiac_sign(float(cusp_lon))
        t.add_row(
            f"[bold {PURPLE}]{i}[/]",
            f"{float(cusp_lon):.4f}°",
            f"{_sign_g(sign)} {sign}",
        )

    for key in ("ASC", "MC", "DSC", "IC"):
        val = angles.get(key)
        if val is None:
            continue
        sign, *_ = _E.zodiac_sign(float(val))
        t.add_row(
            f"[bold white]{key}[/]",
            f"{float(val):.4f}°",
            f"{_sign_g(sign)} {sign}",
        )

    console.print(t)


# ---------------------------------------------------------------------------
# Aspects table
# ---------------------------------------------------------------------------

def show_aspects(aspects: List[Dict[str, Any]]) -> None:
    if not aspects:
        return

    from afterlife.constants import ASPECT_GLYPH

    _ASPECT_COLOR: Dict[str, str] = {
        "Conjunction":    "#ffffff",
        "Opposition":     "#ef4444",
        "Trine":          "#22c55e",
        "Square":         "#ef4444",
        "Sextile":        "#3b82f6",
        "Quincunx":       "#f59e0b",
        "Semi-Sextile":   "#3b82f6",
        "Semi-Square":    "#f59e0b",
        "Sesquiquadrate": "#f59e0b",
    }

    t = _table(
        f"Aspects  [dim]({len(aspects)})[/dim]",
        [
            ("Body A",  WHITE,  "right"),
            ("",        PURPLE, "center"),   # glyph
            ("Aspect",  DIM,    "left"),
            ("Body B",  WHITE,  "left"),
            ("Orb",     DIM,    "right"),
        ],
        color=VIOLET,
    )

    for asp in aspects:
        name = asp.get("aspect", "")
        col  = _ASPECT_COLOR.get(name, SILVER)
        t.add_row(
            asp.get("a", ""),
            ASPECT_GLYPH.get(name, ""),
            f"[{col}]{name}[/]",
            asp.get("b", ""),
            f"{asp.get('orb', 0):.2f}°",
        )

    console.print(t)


# ---------------------------------------------------------------------------
# Moon cycle
# ---------------------------------------------------------------------------

_PHASE_ICON: Dict[str, str] = {
    "New Moon":      "🌑",
    "Waxing Crescent": "🌒",
    "First Quarter": "🌓",
    "Waxing Gibbous": "🌔",
    "Full Moon":     "🌕",
    "Waning Gibbous": "🌖",
    "Last Quarter":  "🌗",
    "Waning Crescent": "🌘",
}

def show_moon_cycle(data: Dict[str, Any]) -> None:
    t = _table(
        f"Moon Cycle — {data.get('year')}/{data.get('month')}",
        [
            ("Date",    WHITE,  "left"),
            ("",        WHITE,  "center"),   # phase icon
            ("Phase",   PURPLE, "left"),
            ("Illum",   DIM,    "right"),
            ("Sign",    DIM,    "left"),
            ("DMS",     DIM,    "left"),
            ("Day",     DIM,    "right"),
        ],
        color=VIOLET,
    )

    for day in data.get("days", []):
        if day.get("missing"):
            continue
        phase = day.get("phase", "")
        sign  = day.get("moon", {}).get("sign", "")
        t.add_row(
            day["date"],
            _PHASE_ICON.get(phase, ""),
            phase,
            f"{day.get('illumination', 0):.0f}%",
            f"{_sign_g(sign)} {sign}",
            day.get("moon", {}).get("dms", ""),
            str(day.get("lunar_day", "")),
        )

    console.print(t)


# ---------------------------------------------------------------------------
# Transit events
# ---------------------------------------------------------------------------

def show_transit_events(data: Dict[str, Any]) -> None:
    events = data.get("transit", {}).get("events", [])
    t = _table(
        f"Transit Events  [dim]({len(events)})[/dim]",
        [
            ("Date",   WHITE,  "left"),
            ("Type",   PURPLE, "left"),
            ("Sign",   DIM,    "left"),
            ("House",  DIM,    "right"),
            ("Degree", DIM,    "left"),
            ("With",   DIM,    "left"),
            ("Orb",    DIM,    "right"),
        ],
        color=VIOLET,
    )
    for ev in events:
        sign = ev.get("sign", "")
        t.add_row(
            ev.get("date", ""),
            ev.get("type", ""),
            f"{_sign_g(sign)} {sign}" if sign else "",
            str(ev.get("house", "")) if ev.get("house") else "",
            str(ev.get("degree", "")) if ev.get("degree") is not None else "",
            ev.get("with", ""),
            f"{ev.get('orb', ''):.2f}°" if isinstance(ev.get("orb"), (int, float)) else "",
        )
    console.print(t)


# ---------------------------------------------------------------------------
# Yearly transits
# ---------------------------------------------------------------------------

def show_yearly_transits(data: Dict[str, Any]) -> None:
    console.print(Panel(
        f"[{WHITE}]Year [bold {PURPLE}]{data.get('year')}[/]  "
        f"[dim]·[/]  [bold {PURPLE}]{len(data.get('transits', {}))}[/] bodies tracked",
        title=f"[bold {PURPLE}]Yearly Transits[/]",
        border_style=PURPLE,
        padding=(0, 1),
    ))

    for body, events in (data.get("transits") or {}).items():
        color = PURPLE
        t = _table(
            f"[bold]{_glyph(body)} {body}[/]  [dim]({len(events or [])} events)[/dim]",
            [
                ("Date",   WHITE,  "left"),
                ("Type",   color,  "left"),
                ("Sign",   DIM,    "left"),
                ("House",  DIM,    "right"),
                ("Degree", DIM,    "left"),
                ("With",   DIM,    "left"),
                ("Orb",    DIM,    "right"),
            ],
            color=color,
        )
        for ev in (events or []):
            sign = ev.get("sign", "")
            t.add_row(
                ev.get("date", ""),
                ev.get("type", ""),
                f"{_sign_g(sign)} {sign}" if sign else "",
                str(ev.get("house", "")) if ev.get("house") else "",
                str(ev.get("degree", "")) if ev.get("degree") is not None else "",
                ev.get("with", ""),
                f"{ev.get('orb', ''):.2f}°" if isinstance(ev.get("orb"), (int, float)) else "",
            )
        console.print(t)


# ---------------------------------------------------------------------------
# Object list — alphabetically grouped by first letter
# ---------------------------------------------------------------------------

def show_object_list(data: Dict[str, Any]) -> None:
    objects: List[Dict[str, Any]] = data.get("objects", [])
    total = data.get("count", len(objects))

    # Group by first letter
    by_letter: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for obj in objects:
        name   = obj if isinstance(obj, str) else obj.get("name", "")
        letter = name[0].upper() if name else "#"
        cat    = obj.get("category", "") if isinstance(obj, dict) else ""
        by_letter[letter].append({"name": name, "category": cat})

    console.print()
    console.print(Rule(
        f"[bold {PURPLE}]Supported Objects[/]  [dim]{total} total[/]",
        style=PURPLE,
    ))
    console.print()

    for letter in sorted(by_letter):
        entries = sorted(by_letter[letter], key=lambda x: x["name"])

        # Header for this letter group
        console.print(f"  [bold {PURPLE}]{letter}[/]  [dim]({len(entries)})[/]")

        rows: List[Text] = []
        for entry in entries:
            name = entry["name"]
            cat  = entry["category"]
            color = _CAT_COLOR.get(cat, SILVER)
            cat_label = _CAT_LABEL.get(cat, cat.replace("_", " ").title()) if cat else ""

            t = Text()
            t.append(f"  {name}", style=f"bold {WHITE}")
            if cat_label:
                t.append(f"  {cat_label}", style=f"dim {color}")
            rows.append(t)

        # Print in columns (3 columns max, auto-wrap)
        console.print(Columns(rows, equal=False, expand=False, padding=(0, 2)))
        console.print()


# ---------------------------------------------------------------------------
# Search results — grouped by category
# ---------------------------------------------------------------------------

def show_search_results(data: Dict[str, Any]) -> None:
    results: List[Dict[str, Any]] = data.get("results", [])
    query   = data.get("query", "")
    count   = data.get("count", len(results))

    console.print()
    console.print(Rule(
        f"[bold {PURPLE}]Search:[/] [white]{query}[/]  [dim]{count} result{'s' if count != 1 else ''}[/]",
        style=PURPLE,
    ))
    console.print()

    if not results:
        console.print(f"  [dim]No objects matching [bold]{query!r}[/bold][/dim]")
        return

    # Group by category
    by_cat: Dict[str, List[str]] = defaultdict(list)
    for obj in results:
        name = obj.get("name", obj) if isinstance(obj, dict) else obj
        cat  = obj.get("category", "unknown") if isinstance(obj, dict) else "unknown"
        by_cat[cat].append(name)

    for cat in _CAT_ORDER:
        names = by_cat.get(cat)
        if not names:
            continue
        color     = _cat_color(cat)
        cat_label = _CAT_LABEL.get(cat, cat.replace("_", " ").title())
        console.print(f"  [bold {color}]{cat_label}[/]  [dim]({len(names)})[/]")
        for name in sorted(names):
            # Case-insensitive highlight: find position, wrap that slice
            idx = name.lower().find(query.lower())
            if idx >= 0:
                hl = (
                    name[:idx]
                    + f"[bold {PURPLE}]{name[idx:idx+len(query)]}[/]"
                    + name[idx+len(query):]
                )
            else:
                hl = name
            console.print(f"    [white]{hl}[/]")
        console.print()

    # Unknown category fallback
    for name in sorted(by_cat.get("unknown", [])):
        console.print(f"    [white]{name}[/]")


# ---------------------------------------------------------------------------
# Quick snapshot
# ---------------------------------------------------------------------------

def show_quick_snapshot(data: Dict[str, Any]) -> None:
    r = data.get("range", {})
    console.print(Panel(
        f"[{WHITE}]Mode [bold {PURPLE}]{data.get('quick_mode')}[/]  "
        f"[dim]{r.get('start', '')[:10]} → {r.get('end', '')[:10]}[/]",
        title=f"[bold {PURPLE}]Quick Snapshot[/]",
        border_style=PURPLE,
        padding=(0, 1),
    ))

    snap = data.get("snapshot", {})
    if snap:
        t = _table(
            "Current Positions",
            [
                ("",       PURPLE, "center"),
                ("Planet", WHITE,  "left"),
                ("",       DIM,    "left"),   # sign glyph
                ("Sign",   DIM,    "left"),
                ("DMS",    SILVER, "left"),
            ],
            color=PURPLE,
        )
        for name, obj in snap.items():
            if not isinstance(obj, dict):
                continue
            sign = obj.get("sign", "")
            t.add_row(
                _glyph(name),
                name,
                _sign_g(sign),
                sign,
                obj.get("dms", ""),
            )
        console.print(t)


# ---------------------------------------------------------------------------
# Master dispatcher
# ---------------------------------------------------------------------------

def render(payload: Dict[str, Any], output_json: bool = False) -> None:
    if output_json:
        show_json(payload)
        return

    if "error" in payload:
        show_error(str(payload["error"]))
        return

    mode = payload.get("mode", "chart")

    if mode == "chart":
        chart = payload.get("chart", payload)
        inp   = chart.get("input", {})
        if inp:
            show_input_panel(inp)
        if chart.get("bodies"):
            show_bodies(chart["bodies"])
        if chart.get("houses"):
            show_houses(chart["houses"])
        if chart.get("aspects"):
            show_aspects(chart["aspects"])
        totals = chart.get("totals", {})
        if totals:
            console.print(
                f"  [dim]Total objects: [bold {PURPLE}]{totals.get('overall', '')}[/][/dim]\n"
            )

    elif mode == "chart_find":
        show_bodies(payload.get("chart", {}).get("bodies", {}))

    elif mode == "moon_cycle":
        show_moon_cycle(payload)

    elif mode == "transit_snapshot":
        show_transit_events(payload)

    elif mode == "yearly_transits":
        show_yearly_transits(payload)

    elif mode == "quick_transits":
        show_quick_snapshot(payload)

    elif mode == "list":
        show_object_list(payload)

    elif mode == "search":
        show_search_results(payload)

    else:
        show_json(payload)
