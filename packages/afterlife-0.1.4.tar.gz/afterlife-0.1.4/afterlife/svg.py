"""
afterlife.svg — compatibility shim.

All SVG rendering has moved to :mod:`afterlife.formats`.

``render_chart`` and ``ChartRenderer`` remain importable from this module
so existing code keeps working without changes.
"""
import warnings as _warnings
from afterlife.formats import SVG as _SVG, _render_svg


def render_chart(chart, **kwargs) -> str:
    """
    Deprecated. Use ``afterlife.formats.SVG`` instead.

    Kept for backwards compatibility — delegates directly to the
    internal ``_render_svg`` function in ``afterlife.formats``.
    """
    _warnings.warn(
        "afterlife.svg.render_chart is deprecated. "
        "Use 'from afterlife.formats import SVG' instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return _render_svg(chart, **kwargs)


def ChartRenderer(chart=None):
    """Deprecated. Use ``from afterlife.formats import SVG`` instead."""
    _warnings.warn(
        "ChartRenderer is deprecated. Use 'from afterlife.formats import SVG' instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return _SVG(chart)
