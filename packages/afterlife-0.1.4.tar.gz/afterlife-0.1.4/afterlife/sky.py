"""
afterlife.sky — fluent builders for sky calculations.

Three builders, one result type::

    from afterlife.sky import Birth, Moment, MoonPhase

    # Birth chart
    chart = (
        Birth()
        .date("27-07-2006")
        .time("10:10")
        .location(41.0, 29.0)
        .timezone(3.0)
        .houses("placidus")
        .compute()
    )
    chart.planets                  # dict of planet bodies
    chart.centaurs                 # dict of centaur bodies
    chart["asteroids"]             # dict-style access
    chart.bodies                   # all categories
    chart.houses                   # house cusps + angles
    chart.summary()                # Sun / Moon / ASC / MC placements
    chart.body("Chiron")           # find any body by name
    chart.retrograde()             # retrograde bodies
    chart.in_sign("Leo")           # bodies in a sign
    chart.in_house(7)              # bodies in a house
    chart.aspects()                # aspect list sorted by orb
    chart.to_json()                # JSON string
    chart.to_dict()                # plain dict

    # Snapshot of the sky at any moment (transit / electional / current sky)
    now = Moment().location(41.0, 29.0).compute()
    sky = Moment().at("26-03-2026", "14:30").timezone(3.0).location(41.0, 29.0).compute()

    # Lunar phase calendar — exact moments, not daily buckets
    phases = MoonPhase().year(2026).compute()
    phases = MoonPhase().year(2026).month(7).compute()
    phases = MoonPhase().year(2026).only("Full Moon").compute()
    for p in phases:
        print(p["phase"], p["date"], p["time"], p["sign"])

House systems
-------------
placidus (default), whole, equal, koch, porphyry, regiomontanus,
campanus, alcabitius, morinus, topocentric, axial, vehlow

Sort keys
---------
name | lon | house | sign
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any, Dict, FrozenSet, Iterator, List, Literal, Optional, Tuple

from afterlife.engine import Afterlife as _Engine

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_DATE_RE = re.compile(r"^\d{2}-\d{2}-\d{4}$")
_TIME_RE = re.compile(r"^\d{2}:\d{2}$")

_VALID_SORT_KEYS: FrozenSet[str] = frozenset({"name", "lon", "house", "sign", ""})
_VALID_HOUSE_SYSTEMS: FrozenSet[str] = frozenset({
    "placidus", "whole", "equal", "koch", "porphyry",
    "regiomontanus", "campanus", "alcabitius", "morinus",
    "topocentric", "axial", "vehlow",
})

_PHASE_NAMES: Tuple[str, ...] = (
    "New Moon", "First Quarter", "Full Moon", "Last Quarter"
)
_PHASE_ANGLES: Tuple[float, ...] = (0.0, 90.0, 180.0, 270.0)

# Mean Moon speed in degrees per day (used to estimate days to next phase)
_MOON_DEG_PER_DAY: float = 13.176396
# Mean synodic month in days
_SYNODIC_MONTH: float = 29.530589


# ---------------------------------------------------------------------------
# Internal validation helpers
# ---------------------------------------------------------------------------

def _require_date(date_str: str, caller: str) -> None:
    if not _DATE_RE.match(date_str):
        raise ValueError(
            f"{caller}: invalid date {date_str!r} — expected DD-MM-YYYY"
        )


def _require_time(time_str: str, caller: str) -> None:
    if not _TIME_RE.match(time_str):
        raise ValueError(
            f"{caller}: invalid time {time_str!r} — expected HH:MM"
        )


def _require_location(lat: Optional[float], lon: Optional[float], caller: str) -> None:
    if lat is None or lon is None:
        raise ValueError(f"{caller}: location(lat, lon) must be set before compute()")
    if not (-90.0 <= lat <= 90.0):
        raise ValueError(f"{caller}: latitude {lat} out of range [-90, 90]")
    if not (-180.0 <= lon <= 180.0):
        raise ValueError(f"{caller}: longitude {lon} out of range [-180, 180]")


def _require_tz(offset: float, caller: str) -> None:
    if not (-14.0 <= offset <= 14.0):
        raise ValueError(
            f"{caller}: timezone offset {offset} out of range [-14, 14]"
        )


# ---------------------------------------------------------------------------
# Chart — immutable result returned by Birth.compute() and Moment.compute()
# ---------------------------------------------------------------------------

class Chart:
    """
    Immutable sky snapshot.

    Returned by :meth:`Birth.compute` and :meth:`Moment.compute`.
    Never instantiate directly — always use a builder.

    Attribute access::

        chart.planets       # dict[str, Any]
        chart.centaurs
        chart.fixed_stars

    Dict-style access::

        chart["planets"]

    Iteration yields ``(category_name, bodies_dict)`` pairs::

        for category, bodies in chart:
            ...
    """

    __slots__ = ("_data",)

    def __init__(self, data: Dict[str, Any]) -> None:
        object.__setattr__(self, "_data", data)

    # ---- attribute / dict / iter access ----------------------------------

    def __getattr__(self, name: str) -> Any:
        bodies = object.__getattribute__(self, "_data").get("bodies", {})
        if name in bodies:
            return bodies[name]
        raise AttributeError(
            f"Chart has no body category {name!r}. "
            f"Available: {list(bodies)}"
        )

    def __getitem__(self, key: str) -> Dict[str, Any]:
        bodies = self._data.get("bodies", {})
        try:
            return bodies[key]
        except KeyError:
            raise KeyError(
                f"Chart has no body category {key!r}. "
                f"Available: {list(bodies)}"
            ) from None

    def __iter__(self) -> Iterator[Tuple[str, Dict[str, Any]]]:
        return iter(self._data.get("bodies", {}).items())

    def __contains__(self, key: str) -> bool:
        return key in self._data.get("bodies", {})

    def __repr__(self) -> str:
        inp  = self._data.get("input", {})
        date = inp.get("date", "?")
        cats = list(self._data.get("bodies", {}).keys())
        return f"<Chart date={date!r} categories={cats}>"

    # ---- top-level properties --------------------------------------------

    @property
    def bodies(self) -> Dict[str, Any]:
        """All body categories as a nested ``{category: {name: body}}`` dict."""
        return self._data.get("bodies", {})

    @property
    def houses(self) -> Dict[str, Any]:
        """House cusps, angles and system name."""
        return self._data.get("houses", {})

    @property
    def jd(self) -> float:
        """Julian Day Number of the chart moment."""
        return float(self._data.get("jd", 0.0))

    @property
    def input(self) -> Dict[str, Any]:
        """Original input parameters (date, time, lat, lon, tz, house_system…)."""
        return self._data.get("input", {})

    # ---- convenience queries ---------------------------------------------

    def summary(self) -> Dict[str, Any]:
        """
        The four most commonly referenced placements in a single dict::

            {
                "Sun":  {"sign": "Leo",   "house": 11, "dms": "Leo 4°8′8″",  "retro": False},
                "Moon": {"sign": "Leo",   "house": 12, "dms": "Leo 27°47′",  "retro": False},
                "ASC":  {"sign": "Virgo", "lon": 173.1, "dms": "Virgo 23°8′"},
                "MC":   {"sign": "Gemini","lon": 82.0,  "dms": "Gemini 22°2′"},
            }

        ASC and MC are omitted when house data is unavailable.
        """
        bodies  = self._data.get("bodies", {})
        planets = bodies.get("planets", {})
        angles  = self._data.get("houses", {}).get("angles", {})

        def _pick(d: Dict[str, Any], name: str) -> Dict[str, Any]:
            obj = d.get(name) or {}
            return {
                "sign":  obj.get("sign",  ""),
                "house": obj.get("house"),
                "lon":   obj.get("lon"),
                "dms":   obj.get("dms",  ""),
                "retro": bool(obj.get("retro", False)),
            }

        out: Dict[str, Any] = {
            "Sun":  _pick(planets, "Sun"),
            "Moon": _pick(planets, "Moon"),
        }

        asc_lon = angles.get("ASC")
        mc_lon  = angles.get("MC")
        if asc_lon is not None:
            out["ASC"] = {
                "lon":  asc_lon,
                "sign": _Engine.zodiac_sign(asc_lon)[0],
                "dms":  _Engine.lon_to_sign_dms(asc_lon),
            }
        if mc_lon is not None:
            out["MC"] = {
                "lon":  mc_lon,
                "sign": _Engine.zodiac_sign(mc_lon)[0],
                "dms":  _Engine.lon_to_sign_dms(mc_lon),
            }
        return out

    def body(self, name: str) -> Optional[Dict[str, Any]]:
        """
        Find a body by name across all categories.

        Returns the body dict augmented with a ``"_category"`` key,
        or ``None`` if not found::

            chart.body("Chiron")
            # → {"name": "Chiron", "sign": "Aquarius", ..., "_category": "centaurs"}
        """
        for cat, objs in self._data.get("bodies", {}).items():
            if not isinstance(objs, dict):
                continue
            if name in objs:
                return {**objs[name], "_category": cat}
        return None

    def retrograde(self) -> List[Dict[str, Any]]:
        """
        All retrograde bodies as a flat list.

        Each item includes a ``"_category"`` key::

            chart.retrograde()
            # [{"name": "Mercury", "_category": "planets", ...}, ...]
        """
        out: List[Dict[str, Any]] = []
        for cat, objs in self._data.get("bodies", {}).items():
            if not isinstance(objs, dict):
                continue
            for name, obj in objs.items():
                if isinstance(obj, dict) and obj.get("retro"):
                    out.append({**obj, "_category": cat})
        return out

    def in_sign(self, sign: str) -> List[Dict[str, Any]]:
        """
        All bodies in a given zodiac sign (case-insensitive)::

            chart.in_sign("Leo")
            chart.in_sign("scorpio")
        """
        target = sign.strip().title()
        out: List[Dict[str, Any]] = []
        for cat, objs in self._data.get("bodies", {}).items():
            if not isinstance(objs, dict):
                continue
            for name, obj in objs.items():
                if isinstance(obj, dict) and obj.get("sign", "").title() == target:
                    out.append({**obj, "_category": cat})
        return out

    def in_house(self, house: int) -> List[Dict[str, Any]]:
        """
        All bodies in a given house (1–12)::

            chart.in_house(7)

        :raises ValueError: If house is not between 1 and 12.
        """
        if not (1 <= house <= 12):
            raise ValueError(f"house must be between 1 and 12, got {house}")
        out: List[Dict[str, Any]] = []
        for cat, objs in self._data.get("bodies", {}).items():
            if not isinstance(objs, dict):
                continue
            for name, obj in objs.items():
                if isinstance(obj, dict) and obj.get("house") == house:
                    out.append({**obj, "_category": cat})
        return out

    def aspects(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Compute aspects between planets and points, sorted by orb (tightest first).

        :param limit: Maximum number of aspects to return (default 100).
        :raises ValueError: If limit < 1.

        ::

            chart.aspects()
            chart.aspects(limit=20)
        """
        if limit < 1:
            raise ValueError(f"limit must be >= 1, got {limit}")
        lon_map: Dict[str, float] = {}
        for cat in ("planets", "points"):
            for name, obj in self._data.get("bodies", {}).get(cat, {}).items():
                if isinstance(obj, dict) and obj.get("lon") is not None:
                    lon_map[name] = float(obj["lon"])
        return _Engine.compute_aspects(lon_map, limit=limit)

    # ---- serialisation ---------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """Return the underlying data as a plain Python dict."""
        return self._data

    def to_json(self, indent: int = 2) -> str:
        """
        Serialise to a JSON string.

        :param indent: Indentation level (default 2). Use ``0`` for compact.
        """
        return json.dumps(
            self._data, ensure_ascii=False,
            indent=indent if indent > 0 else None,
        )


# ---------------------------------------------------------------------------
# _SkyBuilder — shared state and validation for Birth / Moment
# ---------------------------------------------------------------------------

class _SkyBuilder:
    """Internal base class — do not instantiate directly."""

    def __init__(self, ephe_dir: Optional[str] = None) -> None:
        self._ephe_dir:       Optional[str]   = ephe_dir
        self._lat:            Optional[float] = None
        self._lon:            Optional[float] = None
        self._tz:             float           = 0.0
        self._house_system:   str             = "placidus"
        self._show_flags:     Dict[str, bool] = {}
        self._fixed_star_orb: float           = 2.5

    def location(self, lat: float, lon: float) -> "_SkyBuilder":
        """Geographic coordinates in decimal degrees."""
        self._lat = float(lat)
        self._lon = float(lon)
        return self

    def lat(self, lat: float) -> "_SkyBuilder":
        """Latitude in decimal degrees (−90 … +90)."""
        self._lat = float(lat)
        return self

    def lon(self, lon: float) -> "_SkyBuilder":
        """Longitude in decimal degrees (−180 … +180)."""
        self._lon = float(lon)
        return self

    def timezone(self, offset: float) -> "_SkyBuilder":
        """UTC offset in hours (e.g. ``3.0`` for UTC+3, ``-5.0`` for UTC-5)."""
        self._tz = float(offset)
        return self

    def houses(self, system: str) -> "_SkyBuilder":
        """
        House system (default ``placidus``).

        Valid values: ``placidus``, ``whole``, ``equal``, ``koch``,
        ``porphyry``, ``regiomontanus``, ``campanus``, ``alcabitius``,
        ``morinus``, ``topocentric``, ``axial``, ``vehlow``.

        :raises ValueError: If the system name is not recognised.
        """
        key = system.strip().lower()
        if key not in _VALID_HOUSE_SYSTEMS:
            raise ValueError(
                f"Unknown house system {system!r}. "
                f"Valid options: {sorted(_VALID_HOUSE_SYSTEMS)}"
            )
        self._house_system = key
        return self

    def show(self, **flags: bool) -> "_SkyBuilder":
        """
        Toggle body-category visibility::

            .show(fixed_stars=False, arabic_lots=False, eclipses=True)

        Key names accept both ``fixed_stars`` and ``show_fixed_stars`` forms.
        """
        for k, v in flags.items():
            key = k if k.startswith("show_") else f"show_{k}"
            self._show_flags[key] = bool(v)
        return self

    def fixed_star_orb(self, degrees: float) -> "_SkyBuilder":
        """
        Conjunction orb for fixed-star hits in degrees (default ``2.5``).

        :raises ValueError: If degrees < 0.
        """
        if degrees < 0:
            raise ValueError(f"fixed_star_orb must be >= 0, got {degrees}")
        self._fixed_star_orb = float(degrees)
        return self

    def _build_engine(self) -> _Engine:
        engine = _Engine(ephe_dir=self._ephe_dir)
        engine._show_flags = dict(self._show_flags)
        return engine


# ---------------------------------------------------------------------------
# Birth — fluent builder for a birth chart
# ---------------------------------------------------------------------------

class Birth(_SkyBuilder):
    """
    Fluent builder for a birth (natal) chart.

    Every setter returns ``self`` — calls can be chained.
    Nothing is computed until :meth:`compute` is called::

        from afterlife.sky import Birth

        chart = (
            Birth()
            .date("27-07-2006")
            .time("10:10")
            .location(41.0, 29.0)
            .timezone(3.0)
            .houses("placidus")
            .show(fixed_stars=False)
            .compute()
        )

        chart.planets
        chart.summary()
        chart.retrograde()
    """

    def __init__(self, ephe_dir: Optional[str] = None) -> None:
        super().__init__(ephe_dir)
        self._date:       Optional[str]    = None
        self._time:       str              = "12:00"
        self._include:    List[str]        = []
        self._exclude:    List[str]        = []
        self._sort:       str              = ""
        self._limit:      int              = 0
        self._cat_limits: Dict[str, int]   = {}

    # ---- required fields -------------------------------------------------

    def date(self, date_str: str) -> "Birth":
        """
        Birth date in ``DD-MM-YYYY`` format.

        :raises ValueError: If the format does not match.
        """
        _require_date(date_str, "Birth.date()")
        self._date = date_str
        return self

    def time(self, time_str: str) -> "Birth":
        """
        Birth time in ``HH:MM`` (24-hour clock).

        :raises ValueError: If the format does not match.
        """
        _require_time(time_str, "Birth.time()")
        self._time = time_str
        return self

    # Override return types so chaining stays typed correctly
    def location(self, lat: float, lon: float) -> "Birth":
        super().location(lat, lon); return self

    def lat(self, lat: float) -> "Birth":
        super().lat(lat); return self

    def lon(self, lon: float) -> "Birth":
        super().lon(lon); return self

    def timezone(self, offset: float) -> "Birth":
        super().timezone(offset); return self

    def houses(self, system: str) -> "Birth":
        super().houses(system); return self

    def show(self, **flags: bool) -> "Birth":
        super().show(**flags); return self

    def fixed_star_orb(self, degrees: float) -> "Birth":
        super().fixed_star_orb(degrees); return self

    # ---- optional filters ------------------------------------------------

    def include(self, *categories_or_names: str) -> "Birth":
        """
        Whitelist — only return these categories or specific body names.

        Pass category names (``"planets"``, ``"centaurs"``…) or body
        names (``"Sun"``, ``"Chiron"``…).  When set, all other bodies
        are excluded from the result.
        """
        self._include.extend(categories_or_names)
        return self

    def exclude(self, *names: str) -> "Birth":
        """Blacklist — remove specific body names from results."""
        self._exclude.extend(names)
        return self

    def sort_by(self, key: Literal["name", "lon", "house", "sign"]) -> "Birth":
        """
        Sort bodies within each category.

        :param key: One of ``name``, ``lon``, ``house``, ``sign``.
        :raises ValueError: If key is not recognised.
        """
        if key not in _VALID_SORT_KEYS:
            raise ValueError(
                f"Invalid sort key {key!r}. "
                f"Valid options: {sorted(_VALID_SORT_KEYS - {''})}"
            )
        self._sort = key
        return self

    def limit(self, n: int) -> "Birth":
        """
        Cap every category to *n* bodies. ``0`` means unlimited (default).

        :raises ValueError: If n < 0.
        """
        if n < 0:
            raise ValueError(f"limit must be >= 0, got {n}")
        self._limit = int(n)
        return self

    def limit_category(self, category: str, n: int) -> "Birth":
        """
        Cap a single *category* to *n* bodies.

        :raises ValueError: If n < 0.
        """
        if n < 0:
            raise ValueError(f"limit must be >= 0, got {n}")
        self._cat_limits[category] = int(n)
        return self

    # ---- compute ---------------------------------------------------------

    def compute(self) -> Chart:
        """
        Execute the calculation and return an immutable :class:`Chart`.

        :raises ValueError: If ``date()`` or ``location()`` have not been set,
            or if any parameter fails validation.
        """
        if not self._date:
            raise ValueError(
                "Birth.compute(): date() must be called before compute()"
            )
        _require_location(self._lat, self._lon, "Birth.compute()")
        _require_tz(self._tz, "Birth.compute()")

        engine = self._build_engine()
        raw = engine.compute_astro_chart(
            date_str       = self._date,
            time_str       = self._time,
            lat            = self._lat,
            lon            = self._lon,
            house_system   = self._house_system,
            tz_offset      = self._tz,
            fixed_star_orb = self._fixed_star_orb,
            exclude        = ",".join(self._exclude),
            include        = ",".join(self._include),
            sort_by        = self._sort,
            limit          = self._limit,
            **{f"{cat}_limit": n for cat, n in self._cat_limits.items()},
        )
        return Chart(json.loads(raw))


# ---------------------------------------------------------------------------
# Moment — snapshot of the sky at any instant (default: right now, UTC)
# ---------------------------------------------------------------------------

class Moment(_SkyBuilder):
    """
    Snapshot of the sky at a specific instant.

    Use this for transit lookups, electional work, current planetary positions,
    or any calculation that is not tied to a birth event::

        from afterlife.sky import Moment

        # Current sky (UTC)
        now = Moment().location(41.0, 29.0).compute()
        now.planets

        # A specific moment
        sky = (
            Moment()
            .at("26-03-2026", "14:30")
            .timezone(3.0)
            .location(41.0, 29.0)
            .compute()
        )

    Returns the same :class:`Chart` result type as :class:`Birth`.
    """

    def __init__(self, ephe_dir: Optional[str] = None) -> None:
        super().__init__(ephe_dir)
        _now = datetime.now(timezone.utc)
        self._date: str = _now.strftime("%d-%m-%Y")
        self._time: str = _now.strftime("%H:%M")

    def at(self, date_str: str, time_str: str = "12:00") -> "Moment":
        """
        Set an explicit date and time (UTC unless :meth:`timezone` is set).

        :param date_str: ``DD-MM-YYYY``
        :param time_str: ``HH:MM`` (default ``"12:00"``)
        :raises ValueError: If either format is invalid.
        """
        _require_date(date_str, "Moment.at()")
        _require_time(time_str, "Moment.at()")
        self._date = date_str
        self._time = time_str
        return self

    # Override return types
    def location(self, lat: float, lon: float) -> "Moment":
        super().location(lat, lon); return self

    def lat(self, lat: float) -> "Moment":
        super().lat(lat); return self

    def lon(self, lon: float) -> "Moment":
        super().lon(lon); return self

    def timezone(self, offset: float) -> "Moment":
        super().timezone(offset); return self

    def houses(self, system: str) -> "Moment":
        super().houses(system); return self

    def show(self, **flags: bool) -> "Moment":
        super().show(**flags); return self

    def fixed_star_orb(self, degrees: float) -> "Moment":
        super().fixed_star_orb(degrees); return self

    def compute(self) -> Chart:
        """
        Compute the sky snapshot and return an immutable :class:`Chart`.

        :raises ValueError: If ``location()`` has not been set.
        """
        _require_location(self._lat, self._lon, "Moment.compute()")
        _require_tz(self._tz, "Moment.compute()")

        engine = self._build_engine()
        raw = engine.compute_astro_chart(
            date_str       = self._date,
            time_str       = self._time,
            lat            = self._lat,
            lon            = self._lon,
            house_system   = self._house_system,
            tz_offset      = self._tz,
            fixed_star_orb = self._fixed_star_orb,
        )
        return Chart(json.loads(raw))


# ---------------------------------------------------------------------------
# MoonPhase — lunar phase calendar with minute-level accuracy
# ---------------------------------------------------------------------------

class MoonPhase:
    """
    Lunar phase calendar.

    Computes exact UTC moments for New Moon, First Quarter, Full Moon and
    Last Quarter using binary-search bisection against Swiss Ephemeris data.
    Accuracy is better than 1 minute::

        from afterlife.sky import MoonPhase

        # All phases in 2026
        phases = MoonPhase().year(2026).compute()

        # Phases in July 2026 only
        phases = MoonPhase().year(2026).month(7).compute()

        # Only full moons
        phases = MoonPhase().year(2026).only("Full Moon").compute()

        # New and Full moons
        phases = MoonPhase().year(2026).only("New Moon", "Full Moon").compute()

        for p in phases:
            print(p["phase"], p["date"], p["time"], p["sign"])

    Each result is a dict::

        {
            "phase": "Full Moon",           # phase name
            "date":  "03-03-2026",           # DD-MM-YYYY (UTC)
            "time":  "11:37",                # HH:MM (UTC)
            "jd":    2461107.98...,          # Julian Day (UTC)
            "lon":   162.897...,             # Moon ecliptic longitude at exact phase
            "sign":  "Virgo",               # zodiac sign
            "dms":   "Virgo 12°53′53″",     # degree-minute-second string
        }
    """

    def __init__(self, ephe_dir: Optional[str] = None) -> None:
        self._ephe_dir: Optional[str]            = ephe_dir
        self._year:     Optional[int]            = None
        self._month:    Optional[int]            = None
        self._only:     Optional[FrozenSet[str]] = None

    # ---- builder ---------------------------------------------------------

    def year(self, y: int) -> "MoonPhase":
        """
        Year to calculate phases for (default: current year).

        :raises ValueError: If year is outside the supported ephemeris range.
        """
        y = int(y)
        if not (-4712 <= y <= 3000):
            raise ValueError(
                f"year {y} is outside the supported ephemeris range (−4712 … 3000)"
            )
        self._year = y
        return self

    def month(self, m: int) -> "MoonPhase":
        """
        Restrict results to a single month (1–12).

        :raises ValueError: If month is not in range 1–12.
        """
        m = int(m)
        if not (1 <= m <= 12):
            raise ValueError(f"month must be between 1 and 12, got {m}")
        self._month = m
        return self

    def only(self, *phase_names: str) -> "MoonPhase":
        """
        Return only the specified phase type(s).

        :param phase_names: One or more of ``"New Moon"``, ``"First Quarter"``,
            ``"Full Moon"``, ``"Last Quarter"`` (case-sensitive).
        :raises ValueError: If an unrecognised phase name is given.
        """
        unknown = set(phase_names) - set(_PHASE_NAMES)
        if unknown:
            raise ValueError(
                f"Unknown phase name(s): {sorted(unknown)}. "
                f"Valid options: {list(_PHASE_NAMES)}"
            )
        self._only = frozenset(phase_names)
        return self

    # ---- compute ---------------------------------------------------------

    def compute(self) -> List[Dict[str, Any]]:
        """
        Compute lunar phases and return a list of dicts sorted by Julian Day.

        Uses Swiss Ephemeris for all position data.
        Each phase appears exactly once (duplicate-safe across cycle boundaries).
        """
        import swisseph as swe  # type: ignore

        year  = self._year if self._year is not None else datetime.now().year
        month = self._month

        if month is not None:
            import calendar
            last_day = calendar.monthrange(year, month)[1]
            jd_start = swe.julday(year, month, 1,        0.0)
            jd_end   = swe.julday(year, month, last_day, 24.0)
        else:
            jd_start = swe.julday(year,  1,  1,  0.0)
            jd_end   = swe.julday(year, 12, 31, 24.0)

        flags = swe.FLG_SWIEPH

        def _elongation(jd: float) -> float:
            """Moon–Sun elongation in degrees [0, 360)."""
            moon, _ = swe.calc_ut(jd, swe.MOON, flags)
            sun,  _ = swe.calc_ut(jd, swe.SUN,  flags)
            return (moon[0] - sun[0]) % 360.0

        def _find_exact(jd_approx: float, target: float) -> float:
            """
            Bisect to find the JD at which elongation == target.

            60 iterations give sub-second precision (~0.4 s error).
            The search window is ±3 days around the estimate.
            """
            lo, hi = jd_approx - 3.0, jd_approx + 3.0
            for _ in range(60):
                mid   = (lo + hi) / 2.0
                delta = (_elongation(mid) - target) % 360.0
                if delta > 180.0:
                    delta -= 360.0
                if abs(delta) < 1e-7:
                    break
                if delta > 0.0:
                    hi = mid
                else:
                    lo = mid
            return (lo + hi) / 2.0

        def _make_entry(phase_jd: float, phase_name: str) -> Dict[str, Any]:
            moon_pos, _ = swe.calc_ut(phase_jd, swe.MOON, flags)
            lon  = moon_pos[0]
            sign, *_ = _Engine.zodiac_sign(lon)
            dms  = _Engine.lon_to_sign_dms(lon)
            y_, m_, d_, h_ = swe.revjul(phase_jd)
            hour   = int(h_)
            minute = int((h_ - hour) * 60.0 + 0.5)  # round to nearest minute
            if minute == 60:
                hour  += 1
                minute = 0
            return {
                "phase": phase_name,
                "date":  f"{int(d_):02d}-{int(m_):02d}-{int(y_)}",
                "time":  f"{hour:02d}:{minute:02d}",
                "jd":    round(phase_jd, 6),
                "lon":   round(lon, 4),
                "sign":  sign,
                "dms":   dms,
            }

        results: List[Dict[str, Any]] = []
        # (phase_name, calendar_day_int) — prevents duplicates at cycle boundaries
        seen: set = set()

        # Walk one synodic month at a time.  Start one full cycle before
        # jd_start so phases right at the window boundary are not missed.
        jd = jd_start - _SYNODIC_MONTH

        while jd < jd_end + _SYNODIC_MONTH:
            current_elong = _elongation(jd)

            for phase_idx, target in enumerate(_PHASE_ANGLES):
                days_ahead = ((target - current_elong) % 360.0) / _MOON_DEG_PER_DAY
                phase_jd   = _find_exact(jd + days_ahead, target)

                if not (jd_start <= phase_jd <= jd_end):
                    continue

                phase_name = _PHASE_NAMES[phase_idx]
                dedup_key  = (phase_name, int(phase_jd))
                if dedup_key in seen:
                    continue
                seen.add(dedup_key)

                if self._only is not None and phase_name not in self._only:
                    continue

                results.append(_make_entry(phase_jd, phase_name))

            jd += _SYNODIC_MONTH

        results.sort(key=lambda x: x["jd"])
        return results
