# Afterlife

[![PyPI](https://img.shields.io/pypi/v/afterlife)](https://pypi.org/project/afterlife/)
[![Python](https://img.shields.io/pypi/pyversions/afterlife)](https://pypi.org/project/afterlife/)
[![License](https://img.shields.io/github/license/mustafayavuzak/Afterlife)](LICENSE)
[![Downloads](https://img.shields.io/pypi/dm/afterlife)](https://pypi.org/project/afterlife/)
[![Platform](https://img.shields.io/badge/platform-linux%20%7C%20macos%20%7C%20windows-lightgrey)](https://pypi.org/project/afterlife/)

```text
       db          ad88                                  88  88     ad88             
      d88b        d8"      ,d                            88  ""    d8"               
     d8'`8b       88       88                            88        88                
    d8'  `8b    MM88MMM  MM88MMM  ,adPPYba,  8b,dPPYba,  88  88  MM88MMM  ,adPPYba,  
   d8YaaaaY8b     88       88    a8P_____88  88P'   "Y8  88  88    88    a8P_____88  
  d8""""""""8b    88       88    8PP"""""""  88          88  88    88    8PP"""""""  
 d8'        `8b   88       88,   "8b,   ,aa  88          88  88    88    "8b,   ,aa  
d8'          `8b  88       "Y888  `"Ybbd8"'  88          88  88    88     `"Ybbd8"'  
```

**Precision astrological chart engine with a Python API and terminal CLI.**

Built on [Swiss Ephemeris](https://www.astro.com/swisseph/) — the same data source used by professional astrology software.
Supports 176+ celestial bodies: planets, dwarf planets, asteroids, centaurs, fixed stars, exoplanets, interstellar objects, Arabic lots, eclipses, and more.

> [!NOTE]
> **Early Development — v0.1.0** — APIs and output formats may change between versions.

---

## How it works

Afterlife has **three builders** and **one result type**.

| Builder | What it computes |
| ------- | ---------------- |
| `Birth` | Astrological chart for a specific person / event (date + time + location) |
| `Moment` | Snapshot of the sky at any instant — useful for transits, current sky, electional work |
| `MoonPhase` | Exact UTC times for New Moon, First Quarter, Full Moon, Last Quarter |

All builders use a **fluent (chainable) API** — you set parameters one by one, then call `.compute()` at the end. Nothing is calculated until you call `.compute()`.

`Birth` and `Moment` both return a **`Chart`** object — an immutable result with the same query methods regardless of how it was computed.

---

## Install

```bash
pip install afterlife
afterlife setup        # fetch ephemeris data (~58 MB), required once
```

Ephemeris data is cached in `~/.cache/afterlife/ephe/`. It is not bundled in the package because of its size.

---

## Birth chart

Compute a chart for a specific date, time and location:

```python
from afterlife.sky import Birth

chart = (
    Birth()
    .date("15-04-1452")           # DD-MM-YYYY, required
    .time("09:15")                 # HH:MM, 24-hour, default "12:00"
    .location(43.7696, 11.2558)   # lat, lon in decimal degrees, required
    .timezone(0.0)                 # UTC offset in hours, default 0.0
    .houses("placidus")            # house system, default "placidus"
    .compute()                     # → Chart
)
```

### Reading the result

```python
# Access body categories by attribute or dict key
chart.planets           # {"Sun": {...}, "Moon": {...}, "Mercury": {...}, ...}
chart.centaurs          # {"Chiron": {...}, "Pholus": {...}, ...}
chart["asteroids"]      # same as chart.asteroids

# Top-level data
chart.bodies            # all categories: {"planets": {...}, "centaurs": {...}, ...}
chart.houses            # {"cusps": [...], "angles": {"ASC": 173.1, "MC": 82.0}, ...}
chart.jd                # Julian Day number (float)
chart.input             # original input parameters as dict

# Quick summary — Sun, Moon, ASC, MC
chart.summary()
# {
#   "Sun":  {"sign": "Aries", "house": 1,  "dms": "Aries 25°12′", "retro": False},
#   "Moon": {"sign": "Pisces","house": 12, "dms": "Pisces 4°37′",  "retro": False},
#   "ASC":  {"sign": "Aries", "lon": 5.2,  "dms": "Aries 5°12′"},
#   "MC":   {"sign": "Capricorn", "lon": 275.0, "dms": "Capricorn 5°0′"},
# }

# Find any body by name across all categories
chart.body("Chiron")
# {"name": "Chiron", "sign": "Scorpio", "house": 8, "lon": 214.3, "_category": "centaurs"}
# Returns None if not found

# Filter helpers
chart.retrograde()       # list of all retrograde bodies (each has "_category" key)
chart.in_sign("Aries")   # all bodies in a given sign (case-insensitive)
chart.in_house(7)        # all bodies in house 7

# Aspects between planets and points, sorted by orb (tightest first)
chart.aspects()          # list of dicts: [{"a": "Sun", "b": "Moon", "aspect": "Trine", "orb": 0.3}, ...]
chart.aspects(limit=10)  # cap at 10

# Serialise
chart.to_dict()          # plain Python dict — full data
chart.to_json()          # JSON string, indent=2
chart.to_json(indent=0)  # compact JSON
```

### Filtering what gets computed

```python
chart = (
    Birth()
    .date("15-04-1452").time("09:15")
    .location(43.7696, 11.2558)
    # Only return planets and centaurs
    .include("planets", "centaurs")
    # Remove specific bodies from results
    .exclude("South Node", "Mean Node")
    # Sort bodies within each category by ecliptic longitude
    .sort_by("lon")          # "name" | "lon" | "house" | "sign"
    # Cap all categories at 20 bodies
    .limit(20)
    # Or cap one specific category
    .limit_category("asteroids", 5)
    # Toggle entire categories on/off
    .show(fixed_stars=False, arabic_lots=False, eclipses=False)
    # Fixed star conjunction orb in degrees (default 2.5)
    .fixed_star_orb(1.5)
    .compute()
)
```

### House systems

`placidus` (default) · `whole` · `equal` · `koch` · `porphyry` · `regiomontanus` · `campanus` · `alcabitius` · `morinus` · `topocentric` · `axial` · `vehlow`

---

## Current sky / Moment

Use `Moment` when you don't have a birth date — for the current sky, transit work, or any arbitrary point in time:

```python
from afterlife.sky import Moment

# Current sky right now (UTC)
now = Moment().location(48.8566, 2.3522).compute()
now.planets
now.summary()

# A specific moment in the past or future
sky = (
    Moment()
    .at("21-12-2020", "18:17")    # DD-MM-YYYY, HH:MM
    .timezone(1.0)                 # UTC+1
    .location(48.8566, 2.3522)     # Paris
    .compute()
)
```

`Moment` returns the same `Chart` object as `Birth` — all the same methods work:
`summary()`, `body()`, `retrograde()`, `in_sign()`, `in_house()`, `aspects()`, `to_json()`, etc.

---

## Lunar phase calendar

`MoonPhase` finds the exact UTC moment of each lunar phase using Swiss Ephemeris data and binary-search bisection. Accuracy is better than 1 minute.

```python
from afterlife.sky import MoonPhase

# All four phases for a full year
phases = MoonPhase().year(2026).compute()

# Only one month
phases = MoonPhase().year(2026).month(3).compute()

# Filter by phase type
phases = MoonPhase().year(2026).only("Full Moon").compute()
phases = MoonPhase().year(2026).only("New Moon", "Full Moon").compute()

for p in phases:
    print(p["phase"], p["date"], p["time"], p["sign"])
# New Moon  19-03-2026  01:23  Pisces
# Full Moon 03-03-2026  11:37  Virgo
# ...
```

Each result dict:

| Key | Type | Example | Description |
| --- | ---- | ------- | ----------- |
| `phase` | `str` | `"Full Moon"` | `"New Moon"` · `"First Quarter"` · `"Full Moon"` · `"Last Quarter"` |
| `date` | `str` | `"03-03-2026"` | DD-MM-YYYY, UTC |
| `time` | `str` | `"11:37"` | HH:MM, UTC |
| `jd` | `float` | `2461107.985` | Julian Day |
| `lon` | `float` | `162.897` | Moon ecliptic longitude at exact phase |
| `sign` | `str` | `"Virgo"` | Zodiac sign |
| `dms` | `str` | `"Virgo 12°53′53″"` | Degree-minute-second string |

---

## Export formats

Every format accepts the `Chart` object from `Birth` or `Moment` and uses the same fluent pattern.

```python
from afterlife.sky import Birth
from afterlife.formats import SVG, PNG, JSON, PlainText, CSV

chart = Birth().date("15-04-1452").time("09:15").location(43.7696, 11.2558).compute()
```

### SVG — birth chart wheel

```python
path = (
    SVG(chart)
    .theme("dark")                     # "dark" (default) | "light"
    .label(True)                        # show body name + degree next to each glyph
    .scale(1.5)                         # override auto-scale (≥ 1.0)
    .categories("planets", "centaurs", "fixed_stars")   # which bodies to draw
    .exclude("South Node")              # skip specific bodies
    .aspects("Conjunction", "Trine", "Opposition", "Square", "Sextile")
    .no_aspects()                       # or disable aspect lines entirely
    .output("~/Downloads/chart.svg")    # default: ~/Downloads/afterlife_chart_<ts>.svg
    .render()                           # writes file, returns absolute path
)
```

### PNG — rasterised chart

Requires `cairosvg`: `pip install afterlife[png]`

```python
path = (
    PNG(chart)
    .theme("dark")
    .scale(2.0)          # resolution multiplier (default 2.0)
    .dpi(150)
    .output("chart.png")
    .render()
)
```

### JSON

```python
# Save to file
path = JSON(chart).indent(2).save("chart.json")

# String only, no file
text = JSON(chart).dumps()

# Filter categories before exporting
text = JSON(chart).categories("planets", "centaurs").dumps()

# Strip metadata — bodies dict only
text = JSON(chart).bodies_only().dumps()

# Print to stdout
JSON(chart).print()
```

### PlainText — terminal table

```python
# Print to terminal
PlainText(chart).print()

# Filter categories
PlainText(chart).categories("planets", "centaurs").print()

# Get string
text = PlainText(chart).render()

# Save to file
path = PlainText(chart).save("chart.txt")
```

Output looks like:

```text
────────────────────────────────────────────────────────────────────────
  BIRTH CHART  15-04-1452  09:15  UTC+0.0
  Lat 43.7696°  Lon 11.2558°  Houses: Placidus
────────────────────────────────────────────────────────────────────────

  ANGLES
    ASC          Aries 5°12′0″
    MC           Capricorn 5°0′0″

  PLANETS
  Body                 Position               House
  ·····················································
  Sun                  Aries 25°12′0″         H1
  Moon                 Pisces 4°37′0″         H12
  ...
```

### CSV

```python
# Save to file
path = CSV(chart).categories("planets", "centaurs").save("chart.csv")

# String only
text = CSV(chart).dumps()

# TSV
text = CSV(chart).delimiter("\t").dumps()

# Choose columns
text = CSV(chart).fields("name", "sign", "house", "retro").dumps()
```

Columns: `category` · `name` · `lon` · `lat` · `sign` · `dms` · `house` · `retro` · `speed` · `type`

---

## CLI

```bash
# Birth chart (terminal output)
afterlife chart --date 15-04-1452 --time 09:15 --lat 43.7696 --lon 11.2558

# Same, JSON output
afterlife chart --date 15-04-1452 --time 09:15 --lat 43.7696 --lon 11.2558 --json

# Moon phase calendar for a month
afterlife moon 2026-3

# Current sky snapshot
afterlife quick today --lat 48.8566 --lon 2.3522

# Transit events for a single body over a date range
afterlife transit --body Saturn \
    --date 15-04-1452 --time 09:15 --lat 43.7696 --lon 11.2558 \
    --from 2026-01-01 --to 2026-12-31

# All planetary transits for a year
afterlife transits --year 2026 \
    --date 15-04-1452 --time 09:15 --lat 43.7696 --lon 11.2558

# List all 176+ supported objects
afterlife list

# Search by name
afterlife search chiron
```

### Key flags

| Flag | Default | Description |
| ---- | ------- | ----------- |
| `--tz` | `0.0` | UTC offset in hours |
| `--house-system` | `placidus` | House system |
| `--sort-by` | — | `name` \| `lon` \| `house` \| `sign` |
| `--limit` | `0` | Max bodies per category (0 = unlimited) |
| `--include` | — | Comma-separated categories or body names to include |
| `--exclude` | — | Comma-separated body names to exclude |
| `--sign` | — | Filter output to a zodiac sign |
| `--house` | — | Filter output to a house number |
| `--no-planets` | — | Exclude planets |
| `--no-asteroids` | — | Exclude asteroids |
| `--no-fixed-stars` | — | Exclude fixed stars |
| `--no-arabic-lots` | — | Exclude Arabic lots |
| `--no-aspects` | — | Exclude aspects |
| `--json` | — | Raw JSON output |

Per-category limits: `--planets-limit`, `--asteroids-limit`, `--centaurs-limit`, `--moons-limit`, `--dwarfs-limit`, `--fixed-stars-limit`, `--arabic-lots-limit`, `--planetary-nodes-limit`, `--exoplanets-limit`, `--interstellar-limit`, `--points-limit`, `--advanced-points-limit`, `--lilith-limit`

---

## Supported body categories

| Category | Count | Examples |
| -------- | ----- | -------- |
| `planets` | 10 | Sun, Moon, Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, Pluto |
| `dwarfs` | 16 | Eris, Haumea, Makemake, Sedna, Quaoar, Orcus, Gonggong, Varuna, Ixion… |
| `asteroids` | 4 | Ceres, Pallas, Juno, Vesta |
| `centaurs` | 2 | Chiron, Pholus |
| `moons` | 11 | Personal Moon, Shadow Sun, Shadow Moon, Shadow Mercury, Shadow Venus… (antiscia) |
| `fixed_stars` | 68 | Aldebaran, Regulus, Antares, Spica, Algol, Sirius, Vega, Arcturus… |
| `points` | 6 | Ascendant, Midheaven, Mean Node, True Node, North Node, South Node |
| `advanced_points` | 2 | Vertex, East Point |
| `lilith` | 2 | Mean Lilith, True Lilith |
| `arabic_lots` | 21 | Fortuna, Spirit, Eros, Victory, Nemesis, Marriage, Death… |
| `planetary_nodes` | 16 | Mercury Ascending Node, Mercury Descending Node, Venus Ascending Node… |
| `eclipses` | 4 | Prenatal Solar Eclipse, Prenatal Lunar Eclipse, Postnatal Solar Eclipse… |
| `exoplanets` | 40 | Kepler-22b, Kepler-452b, Proxima Centauri b, TRAPPIST-1 e, K2-18 b… |
| `interstellar` | 2 | ʻOumuamua, 2I/Borisov |

---

## Ephemeris data

Not bundled in the PyPI package. Run once after install:

```bash
afterlife setup        # ~58 MB, saved to ~/.cache/afterlife/ephe/
```

Custom path:

```bash
afterlife chart ... --ephe-dir /path/to/ephe
```

```python
from afterlife.sky import Birth
chart = Birth(ephe_dir="/path/to/ephe").date(...).compute()
```

---

## License

MIT © 2026 Mustafa Yavuz Ak
