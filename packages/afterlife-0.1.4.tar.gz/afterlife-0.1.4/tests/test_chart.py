"""Tests for Birth and Moment chart builders."""
from __future__ import annotations

import pytest

from afterlife.sky import Birth, Moment


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _da_vinci() -> Birth:
    """Leonardo da Vinci, 15 Apr 1452, Anchiano, Italy."""
    return (
        Birth()
        .date("15-04-1452")
        .time("09:15")
        .location(43.7696, 11.2558)
        .timezone(0.0)
        .houses("placidus")
    )


# ---------------------------------------------------------------------------
# Chart structure
# ---------------------------------------------------------------------------

class TestChartStructure:
    def test_compute_returns_chart(self):
        chart = _da_vinci().compute()
        assert chart is not None

    def test_planets_present(self):
        chart = _da_vinci().compute()
        assert "planets" in chart.bodies
        assert "Sun" in chart.planets
        assert "Moon" in chart.planets

    def test_houses_present(self):
        chart = _da_vinci().compute()
        assert chart.houses
        assert "cusps" in chart.houses
        assert len(chart.houses["cusps"]) == 12

    def test_jd_is_float(self):
        chart = _da_vinci().compute()
        assert isinstance(chart.jd, float)
        assert chart.jd > 0

    def test_input_preserved(self):
        chart = _da_vinci().compute()
        inp = chart.input
        assert inp["date"] == "15-04-1452"
        assert inp["time"] == "09:15"

    def test_to_dict_is_dict(self):
        chart = _da_vinci().compute()
        d = chart.to_dict()
        assert isinstance(d, dict)
        assert "bodies" in d

    def test_to_json_is_str(self):
        import json
        chart = _da_vinci().compute()
        s = chart.to_json()
        parsed = json.loads(s)
        assert "bodies" in parsed


# ---------------------------------------------------------------------------
# Planet signs and attributes
# ---------------------------------------------------------------------------

class TestPlanetAttributes:
    def test_sun_sign_aries(self):
        chart = _da_vinci().compute()
        assert chart.planets["Sun"]["sign"] == "Aries"

    def test_planet_has_lon(self):
        chart = _da_vinci().compute()
        sun = chart.planets["Sun"]
        assert "lon" in sun
        assert 0.0 <= sun["lon"] < 360.0

    def test_planet_has_house(self):
        chart = _da_vinci().compute()
        sun = chart.planets["Sun"]
        assert "house" in sun
        assert 1 <= sun["house"] <= 12

    def test_planet_has_dms(self):
        chart = _da_vinci().compute()
        sun = chart.planets["Sun"]
        assert "dms" in sun
        assert "Aries" in sun["dms"]


# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------

class TestSummary:
    def test_summary_keys(self):
        chart = _da_vinci().compute()
        s = chart.summary()
        assert "Sun" in s
        assert "Moon" in s
        assert "ASC" in s
        assert "MC" in s

    def test_summary_sun_sign(self):
        chart = _da_vinci().compute()
        assert chart.summary()["Sun"]["sign"] == "Aries"

    def test_summary_asc_has_lon(self):
        chart = _da_vinci().compute()
        assert "lon" in chart.summary()["ASC"]


# ---------------------------------------------------------------------------
# Filter helpers
# ---------------------------------------------------------------------------

class TestFilterHelpers:
    def test_in_sign_aries(self):
        chart = _da_vinci().compute()
        aries = chart.in_sign("Aries")
        assert any(b["name"] == "Sun" for b in aries)

    def test_in_sign_case_insensitive(self):
        chart = _da_vinci().compute()
        assert chart.in_sign("aries") == chart.in_sign("Aries")

    def test_in_house_returns_list(self):
        chart = _da_vinci().compute()
        bodies = chart.in_house(1)
        assert isinstance(bodies, list)

    def test_in_house_invalid_raises(self):
        chart = _da_vinci().compute()
        with pytest.raises(ValueError):
            chart.in_house(13)
        with pytest.raises(ValueError):
            chart.in_house(0)

    def test_retrograde_returns_list(self):
        chart = _da_vinci().compute()
        retros = chart.retrograde()
        assert isinstance(retros, list)
        for b in retros:
            assert b.get("retro") is True

    def test_body_found(self):
        chart = _da_vinci().compute()
        chiron = chart.body("Chiron")
        assert chiron is not None
        assert chiron["name"] == "Chiron"
        assert "_category" in chiron

    def test_body_not_found(self):
        chart = _da_vinci().compute()
        assert chart.body("NonExistentXYZ123") is None


# ---------------------------------------------------------------------------
# Aspects
# ---------------------------------------------------------------------------

class TestAspects:
    def test_aspects_returns_list(self):
        chart = _da_vinci().compute()
        aspects = chart.aspects()
        assert isinstance(aspects, list)

    def test_aspects_have_keys(self):
        chart = _da_vinci().compute()
        aspects = chart.aspects()
        if aspects:
            a = aspects[0]
            assert "a" in a
            assert "b" in a
            assert "aspect" in a
            assert "orb" in a

    def test_aspects_limit(self):
        chart = _da_vinci().compute()
        limited = chart.aspects(limit=3)
        assert len(limited) <= 3

    def test_aspects_sorted_by_orb(self):
        chart = _da_vinci().compute()
        aspects = chart.aspects()
        orbs = [a["orb"] for a in aspects]
        assert orbs == sorted(orbs)


# ---------------------------------------------------------------------------
# Builder filters
# ---------------------------------------------------------------------------

class TestBuilderFilters:
    def test_include_by_name(self):
        # include() filters by body name, not category
        chart = _da_vinci().include("Sun", "Moon", "Mercury").compute()
        assert "planets" in chart.bodies
        assert list(chart.planets.keys()) == ["Sun", "Moon", "Mercury"]
        # Other categories should not be present
        assert "asteroids" not in chart.bodies
        assert "centaurs" not in chart.bodies

    def test_exclude_removes_body(self):
        chart = _da_vinci().exclude("South Node").compute()
        all_names = [
            name
            for cat in chart.bodies.values()
            if isinstance(cat, dict)
            for name in cat
        ]
        assert "South Node" not in all_names

    def test_limit_caps_results(self):
        chart = _da_vinci().limit(3).compute()
        for cat, objs in chart.bodies.items():
            if not isinstance(objs, dict):
                continue
            # Eclipses are always exactly 4 (prenatal/postnatal solar/lunar)
            # and do not participate in the generic limit
            if cat == "eclipses":
                continue
            assert len(objs) <= 3, f"Category {cat!r} has {len(objs)} items, expected ≤ 3"

    def test_sort_by_lon(self):
        chart = _da_vinci().sort_by("lon").compute()
        lons = [v["lon"] for v in chart.planets.values() if isinstance(v, dict) and "lon" in v]
        assert lons == sorted(lons)

    def test_invalid_sort_by_raises(self):
        with pytest.raises(ValueError):
            _da_vinci().sort_by("invalid_key").compute()

    def test_invalid_house_system_raises(self):
        with pytest.raises(ValueError):
            Birth().date("15-04-1452").time("09:15").location(43.7696, 11.2558).houses("unknown_system").compute()

    def test_invalid_date_raises(self):
        with pytest.raises(ValueError):
            Birth().date("1452-04-15")  # wrong format

    def test_invalid_time_raises(self):
        with pytest.raises(ValueError):
            Birth().time("9:5")  # wrong format


# ---------------------------------------------------------------------------
# Moment builder
# ---------------------------------------------------------------------------

class TestMoment:
    def test_moment_no_location_raises(self):
        from afterlife.sky import Moment
        with pytest.raises(ValueError):
            Moment().compute()

    def test_moment_current_sky(self):
        from afterlife.sky import Moment
        chart = Moment().location(48.8566, 2.3522).compute()
        assert "Sun" in chart.planets

    def test_moment_at_specific_time(self):
        from afterlife.sky import Moment
        # Jupiter-Saturn conjunction
        chart = (
            Moment()
            .at("21-12-2020", "18:17")
            .timezone(1.0)
            .location(48.8566, 2.3522)
            .compute()
        )
        assert chart.planets["Jupiter"]["sign"] == "Aquarius"
        assert chart.planets["Saturn"]["sign"] == "Aquarius"
