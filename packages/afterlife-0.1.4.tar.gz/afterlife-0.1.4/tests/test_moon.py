"""Tests for MoonPhase builder."""
from __future__ import annotations

import pytest

from afterlife.sky import MoonPhase


VALID_PHASES = {"New Moon", "First Quarter", "Full Moon", "Last Quarter"}


class TestMoonPhaseStructure:
    def test_year_returns_list(self):
        phases = MoonPhase().year(2026).compute()
        assert isinstance(phases, list)
        assert len(phases) > 0

    def test_phase_keys(self):
        phases = MoonPhase().year(2026).month(1).compute()
        for p in phases:
            assert "phase" in p
            assert "date" in p
            assert "time" in p
            assert "jd" in p
            assert "lon" in p
            assert "sign" in p
            assert "dms" in p

    def test_phase_names_valid(self):
        phases = MoonPhase().year(2026).compute()
        for p in phases:
            assert p["phase"] in VALID_PHASES

    def test_month_filter(self):
        phases = MoonPhase().year(2026).month(3).compute()
        for p in phases:
            assert "-03-" in p["date"] or p["date"].endswith("-03-2026") or "03-2026" in p["date"]

    def test_only_filter_new_moon(self):
        phases = MoonPhase().year(2026).only("New Moon").compute()
        for p in phases:
            assert p["phase"] == "New Moon"
        assert len(phases) > 0

    def test_only_filter_multiple(self):
        phases = MoonPhase().year(2026).only("New Moon", "Full Moon").compute()
        for p in phases:
            assert p["phase"] in {"New Moon", "Full Moon"}

    def test_lon_in_range(self):
        phases = MoonPhase().year(2026).compute()
        for p in phases:
            assert 0.0 <= p["lon"] < 360.0

    def test_sign_is_zodiac(self):
        signs = {
            "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
            "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces",
        }
        phases = MoonPhase().year(2026).compute()
        for p in phases:
            assert p["sign"] in signs

    def test_jd_monotone(self):
        phases = MoonPhase().year(2026).compute()
        jds = [p["jd"] for p in phases]
        assert jds == sorted(jds)

    def test_time_format(self):
        import re
        phases = MoonPhase().year(2026).month(1).compute()
        for p in phases:
            assert re.match(r"^\d{2}:\d{2}$", p["time"]), f"Bad time format: {p['time']}"

    def test_date_format(self):
        import re
        phases = MoonPhase().year(2026).month(1).compute()
        for p in phases:
            assert re.match(r"^\d{2}-\d{2}-\d{4}$", p["date"]), f"Bad date format: {p['date']}"

    def test_invalid_only_raises(self):
        with pytest.raises(ValueError):
            MoonPhase().year(2026).only("Waxing Crescent").compute()

    def test_no_year_defaults_to_current(self):
        from datetime import datetime
        phases = MoonPhase().compute()
        current_year = str(datetime.now().year)
        # All results should be from the current year
        for p in phases:
            assert current_year in p["date"], f"Expected current year in date: {p['date']}"

    def test_full_year_count(self):
        # A year has ~12-13 of each phase, so 48-54 total
        phases = MoonPhase().year(2026).compute()
        assert 45 <= len(phases) <= 55
