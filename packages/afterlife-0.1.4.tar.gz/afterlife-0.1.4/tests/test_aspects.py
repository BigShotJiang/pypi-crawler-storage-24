"""Tests for aspect computation."""
from __future__ import annotations

import pytest

from afterlife.engine import Afterlife


eng = Afterlife()

KNOWN_ASPECTS = {
    "Conjunction", "Opposition", "Trine", "Square", "Sextile",
    "Quincunx", "Semi-Sextile", "Semi-Square", "Sesquiquadrate",
}


class TestComputeAspects:
    def test_empty_input(self):
        result = eng.compute_aspects({})
        assert result == []

    def test_single_body_no_aspects(self):
        result = eng.compute_aspects({"Sun": 0.0})
        assert result == []

    def test_conjunction(self):
        # Two bodies 0° apart → Conjunction
        result = eng.compute_aspects({"Sun": 100.0, "Moon": 100.5})
        assert any(a["aspect"] == "Conjunction" for a in result)

    def test_opposition(self):
        # 180° apart → Opposition
        result = eng.compute_aspects({"Sun": 0.0, "Moon": 180.0})
        assert any(a["aspect"] == "Opposition" for a in result)

    def test_trine(self):
        # 120° apart → Trine
        result = eng.compute_aspects({"Sun": 0.0, "Moon": 120.0})
        assert any(a["aspect"] == "Trine" for a in result)

    def test_square(self):
        # 90° apart → Square
        result = eng.compute_aspects({"Sun": 0.0, "Moon": 90.0})
        assert any(a["aspect"] == "Square" for a in result)

    def test_sextile(self):
        # 60° apart → Sextile
        result = eng.compute_aspects({"Sun": 0.0, "Moon": 60.0})
        assert any(a["aspect"] == "Sextile" for a in result)

    def test_aspect_structure(self):
        result = eng.compute_aspects({"Sun": 0.0, "Moon": 120.0})
        for a in result:
            assert "a" in a
            assert "b" in a
            assert "aspect" in a
            assert "orb" in a
            assert a["aspect"] in KNOWN_ASPECTS
            assert isinstance(a["orb"], float)
            assert a["orb"] >= 0.0

    def test_aspects_sorted_by_orb(self):
        bodies = {"Sun": 0.0, "Moon": 60.5, "Mercury": 120.3, "Venus": 180.1}
        result = eng.compute_aspects(bodies)
        orbs = [a["orb"] for a in result]
        assert orbs == sorted(orbs)

    def test_wrap_around(self):
        # 358° and 2° are 4° apart → Conjunction
        result = eng.compute_aspects({"Sun": 358.0, "Moon": 2.0})
        assert any(a["aspect"] == "Conjunction" for a in result)

    def test_no_self_aspect(self):
        result = eng.compute_aspects({"Sun": 0.0, "Moon": 120.0})
        for a in result:
            assert a["a"] != a["b"]

    def test_no_duplicate_pairs(self):
        result = eng.compute_aspects({"Sun": 0.0, "Moon": 60.0, "Mercury": 120.0})
        pairs = {(a["a"], a["b"]) for a in result}
        # Each pair should only appear once
        assert len(pairs) == len(result)
