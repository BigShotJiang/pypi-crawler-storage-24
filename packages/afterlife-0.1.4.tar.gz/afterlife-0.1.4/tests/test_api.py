"""Integration tests for the Afterlife REST API."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from api.main import app

client = TestClient(app)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

class TestHealth:
    def test_health_ok(self):
        r = client.get("/health")
        assert r.status_code == 200
        data = r.json()
        assert data["status"] == "ok"
        assert "version" in data

    def test_process_time_header(self):
        r = client.get("/health")
        assert "X-Process-Time" in r.headers


# ---------------------------------------------------------------------------
# /chart
# ---------------------------------------------------------------------------

DA_VINCI = {
    "date": "15-04-1452",
    "time": "09:15",
    "lat":  43.7696,
    "lon":  11.2558,
    "tz":   0.0,
}

class TestChart:
    def test_chart_ok(self):
        r = client.post("/chart", json=DA_VINCI)
        assert r.status_code == 200

    def test_chart_has_bodies(self):
        r = client.post("/chart", json=DA_VINCI)
        data = r.json()
        assert "bodies" in data
        assert "planets" in data["bodies"]

    def test_chart_sun_sign_aries(self):
        r = client.post("/chart", json=DA_VINCI)
        assert r.json()["bodies"]["planets"]["Sun"]["sign"] == "Aries"

    def test_chart_has_houses(self):
        r = client.post("/chart", json=DA_VINCI)
        assert "houses" in r.json()
        assert "cusps" in r.json()["houses"]

    def test_chart_has_aspects(self):
        r = client.post("/chart", json=DA_VINCI)
        aspects = r.json()["aspects"]
        assert isinstance(aspects, list)
        assert len(aspects) > 0

    def test_chart_aspects_have_orb(self):
        r = client.post("/chart", json=DA_VINCI)
        for a in r.json()["aspects"]:
            assert "orb" in a
            assert "aspect" in a

    def test_chart_invalid_date_format(self):
        payload = {**DA_VINCI, "date": "1452-04-15"}
        r = client.post("/chart", json=payload)
        assert r.status_code == 422

    def test_chart_invalid_time_format(self):
        payload = {**DA_VINCI, "time": "9:5"}
        r = client.post("/chart", json=payload)
        assert r.status_code == 422

    def test_chart_lat_out_of_range(self):
        payload = {**DA_VINCI, "lat": 95.0}
        r = client.post("/chart", json=payload)
        assert r.status_code == 422

    def test_chart_lon_out_of_range(self):
        payload = {**DA_VINCI, "lon": 200.0}
        r = client.post("/chart", json=payload)
        assert r.status_code == 422

    def test_chart_missing_date(self):
        r = client.post("/chart", json={"lat": 43.0, "lon": 11.0})
        assert r.status_code == 422

    def test_chart_jd_is_float(self):
        r = client.post("/chart", json=DA_VINCI)
        assert isinstance(r.json()["jd"], float)

    def test_chart_house_system(self):
        r = client.post("/chart", json={**DA_VINCI, "house_system": "whole"})
        assert r.status_code == 200


# ---------------------------------------------------------------------------
# /moment
# ---------------------------------------------------------------------------

class TestMoment:
    def test_moment_current(self):
        r = client.post("/moment", json={"lat": 48.8566, "lon": 2.3522})
        assert r.status_code == 200
        assert "planets" in r.json()["bodies"]

    def test_moment_at_conjunction(self):
        r = client.post("/moment", json={
            "date": "21-12-2020",
            "time": "18:17",
            "lat":  48.8566,
            "lon":  2.3522,
            "tz":   1.0,
        })
        assert r.status_code == 200
        planets = r.json()["bodies"]["planets"]
        assert planets["Jupiter"]["sign"] == "Aquarius"
        assert planets["Saturn"]["sign"] == "Aquarius"

    def test_moment_missing_location(self):
        r = client.post("/moment", json={})
        assert r.status_code == 422


# ---------------------------------------------------------------------------
# /moon
# ---------------------------------------------------------------------------

VALID_PHASES = {"New Moon", "First Quarter", "Full Moon", "Last Quarter"}

class TestMoon:
    def test_moon_year(self):
        r = client.post("/moon", json={"year": 2026})
        assert r.status_code == 200
        data = r.json()
        assert data["year"] == 2026
        assert data["count"] > 0

    def test_moon_phase_names(self):
        r = client.post("/moon", json={"year": 2026, "month": 1})
        for p in r.json()["phases"]:
            assert p["phase"] in VALID_PHASES

    def test_moon_only_filter(self):
        r = client.post("/moon", json={"year": 2026, "only": ["Full Moon"]})
        assert r.status_code == 200
        for p in r.json()["phases"]:
            assert p["phase"] == "Full Moon"

    def test_moon_invalid_phase(self):
        r = client.post("/moon", json={"year": 2026, "only": ["Waxing Crescent"]})
        assert r.status_code == 422

    def test_moon_year_out_of_range(self):
        r = client.post("/moon", json={"year": 1700})
        assert r.status_code == 422

    def test_moon_phase_has_sign(self):
        r = client.post("/moon", json={"year": 2026, "month": 3})
        for p in r.json()["phases"]:
            assert "sign" in p
            assert "lon" in p


# ---------------------------------------------------------------------------
# /objects and /search
# ---------------------------------------------------------------------------

class TestObjects:
    def test_objects_ok(self):
        r = client.get("/objects")
        assert r.status_code == 200
        data = r.json()
        assert data["count"] > 0
        assert len(data["objects"]) == data["count"]

    def test_objects_have_category(self):
        r = client.get("/objects")
        for obj in r.json()["objects"]:
            assert "name" in obj
            assert "category" in obj

    def test_objects_count_matches_engine(self):
        r = client.get("/objects")
        assert r.json()["count"] == 339

    def test_search_chiron(self):
        r = client.get("/search", params={"q": "chiron"})
        assert r.status_code == 200
        data = r.json()
        assert data["count"] >= 1
        names = [o["name"].lower() for o in data["results"]]
        assert any("chiron" in n for n in names)

    def test_search_case_insensitive(self):
        r1 = client.get("/search", params={"q": "sun"})
        r2 = client.get("/search", params={"q": "SUN"})
        assert r1.json()["count"] == r2.json()["count"]

    def test_search_no_results(self):
        r = client.get("/search", params={"q": "xyznonexistent"})
        assert r.status_code == 200
        assert r.json()["count"] == 0

    def test_search_empty_query(self):
        r = client.get("/search", params={"q": ""})
        assert r.status_code == 422


# ---------------------------------------------------------------------------
# /aspects
# ---------------------------------------------------------------------------

class TestAspects:
    def test_aspects_conjunction(self):
        r = client.post("/aspects", json={"bodies": {"Sun": 100.0, "Moon": 100.5}})
        assert r.status_code == 200
        aspects = r.json()["aspects"]
        assert any(a["aspect"] == "Conjunction" for a in aspects)

    def test_aspects_trine(self):
        r = client.post("/aspects", json={"bodies": {"Sun": 0.0, "Moon": 120.0}})
        aspects = r.json()["aspects"]
        assert any(a["aspect"] == "Trine" for a in aspects)

    def test_aspects_empty(self):
        r = client.post("/aspects", json={"bodies": {}})
        assert r.status_code == 200
        assert r.json()["count"] == 0

    def test_aspects_sorted_by_orb(self):
        r = client.post("/aspects", json={
            "bodies": {"Sun": 0.0, "Moon": 60.5, "Mercury": 120.3, "Venus": 180.1}
        })
        orbs = [a["orb"] for a in r.json()["aspects"]]
        assert orbs == sorted(orbs)

    def test_aspects_count_matches(self):
        r = client.post("/aspects", json={"bodies": {"Sun": 0.0, "Moon": 120.0}})
        data = r.json()
        assert data["count"] == len(data["aspects"])

    def test_aspects_invalid_body(self):
        # lon > 360 should still work (engine handles wrap)
        r = client.post("/aspects", json={"bodies": {"Sun": 0.0, "Moon": 400.0}})
        assert r.status_code == 200
