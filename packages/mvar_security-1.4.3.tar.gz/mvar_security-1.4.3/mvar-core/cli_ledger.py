"""
MVAR Decision Ledger CLI

Command-line tools for inspecting and managing MVAR decision ledger.

Commands:
- mvar-report: List recent decisions
- mvar-explain <decision_id>: Show full details of a decision
- mvar-allow add <decision_id>: Create override for a blocked decision
- mvar-allow list: List active overrides
- mvar-allow expire <override_id>: Revoke an override

Usage:
    export MVAR_ENABLE_LEDGER=1
    export QSEAL_SECRET=$(openssl rand -hex 32)

    # Run agent, generate some BLOCK decisions
    # ...

    # Inspect decisions
    mvar-report

    # Explain a specific decision
    mvar-explain MVAR_DEC_20260224T120000Z_a1b2c3d4

    # Create 24h override
    mvar-allow add MVAR_DEC_20260224T120000Z_a1b2c3d4

    # List active overrides
    mvar-allow list

    # Revoke override
    mvar-allow expire MVAR_OVR_20260224T120500Z_e5f6g7h8
"""

import sys
import os
import json
import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


def _principal_id() -> str:
    return os.getenv(
        "MVAR_PRINCIPAL_ID",
        f"local_install:{hashlib.sha256(str(Path.cwd()).encode('utf-8')).hexdigest()[:12]}",
    )


def _init_ledger_or_exit() -> Any:
    try:
        # Lazy import avoids module side effects (QSEAL banner) for --help paths.
        from .decision_ledger import MVARDecisionLedger

        return MVARDecisionLedger()
    except Exception as exc:
        print(f"❌ Unable to initialize decision ledger: {exc}")
        print("Tip: set QSEAL_SECRET when MVAR_ENABLE_LEDGER=1")
        raise SystemExit(1)


def format_timestamp(iso_timestamp: str) -> str:
    """Format ISO timestamp for display"""
    try:
        dt = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M:%S UTC")
    except Exception:
        return iso_timestamp


def mvar_report():
    """List recent MVAR decisions"""
    if os.getenv("MVAR_ENABLE_LEDGER") != "1":
        print("⚠️  MVAR_ENABLE_LEDGER not set to 1")
        print("Export MVAR_ENABLE_LEDGER=1 to enable decision ledger")
        sys.exit(1)

    ledger = _init_ledger_or_exit()
    decisions = ledger.load_decisions(limit=20)

    if not decisions:
        raw_scrolls = ledger._load_scrolls_raw()
        if raw_scrolls:
            print("No verified decisions available.")
            print()
            print("Possible cause: signature verification mismatch.")
            print("If running HMAC fallback mode, ensure QSEAL_SECRET matches the value")
            print("used when decisions were recorded.")
        else:
            print("No decisions recorded yet.")
        sys.exit(0)

    print(f"\n{'='*80}")
    print(f"MVAR Decision Ledger Report (most recent {len(decisions)} decisions)")
    print(f"{'='*80}\n")

    for i, decision in enumerate(decisions, 1):
        outcome = decision["decision_outcome"]
        outcome_upper = str(outcome).upper()
        timestamp = format_timestamp(decision["timestamp"])
        sink = decision["sink_target"]
        tool_action = f"{sink['tool']}.{sink['action']}"
        target_hash = sink["target_hash"][:8] + "..."
        reason = decision["reason"][:60] + "..." if len(decision["reason"]) > 60 else decision["reason"]

        # Color-code outcomes
        if outcome_upper == "BLOCK":
            outcome_display = f"🛑 {outcome_upper}"
        elif outcome_upper == "STEP_UP":
            outcome_display = f"⚠️  {outcome_upper}"
        else:
            outcome_display = f"✅ {outcome_upper}"

        print(f"{i}. {timestamp}")
        print(f"   {outcome_display} :: {tool_action} (target: {target_hash})")
        print(f"   Reason: {reason}")
        print(f"   ID: {decision['scroll_id']}")
        print()

    print(f"{'='*80}\n")
    print(f"Use 'mvar-explain <decision_id>' for full details")
    print(f"Use 'mvar-allow add <decision_id>' to create override\n")


def mvar_explain(decision_id: str):
    """Explain a specific decision"""
    if os.getenv("MVAR_ENABLE_LEDGER") != "1":
        print("⚠️  MVAR_ENABLE_LEDGER not set to 1")
        sys.exit(1)

    ledger = _init_ledger_or_exit()
    decision = ledger.get_decision(decision_id)

    if not decision:
        print(f"❌ Decision {decision_id} not found")
        sys.exit(1)

    print(f"\n{'='*80}")
    print(f"MVAR Decision Details")
    print(f"{'='*80}\n")

    print(f"Decision ID:  {decision['scroll_id']}")
    print(f"Timestamp:    {format_timestamp(decision['timestamp'])}")
    print(f"Outcome:      {decision['decision_outcome']}")
    print()

    print(f"Sink Target:")
    sink = decision["sink_target"]
    print(f"  Tool:        {sink['tool']}")
    print(f"  Action:      {sink['action']}")
    print(f"  Target Hash: {sink['target_hash']}")
    print()

    print(f"Provenance:   {decision['provenance_node_id']}")
    print(f"Principal:    {decision.get('principal_id', 'local_install')}")
    print(f"Reason:       {decision['reason']}")
    print()

    print(f"Evaluation Trace:")
    for step in decision.get("evaluation_trace", []):
        print(f"  - {step}")
    print()

    # Verify QSEAL signature
    print(f"QSEAL Signature:")
    print(f"  Algorithm:   {decision.get('qseal_algorithm', 'unknown')}")
    print(f"  Meta Hash:   {decision.get('meta_hash', 'none')[:16]}...")
    verified = ledger._verify_scroll(decision)
    print(f"  Verified:    {'✅ VALID' if verified else '❌ INVALID'}")
    print()

    if decision["decision_outcome"] in ("BLOCK", "STEP_UP"):
        print(f"To create 24h override: mvar-allow add {decision['scroll_id']}\n")


def mvar_allow_add():
    """Create override for a blocked decision"""
    if os.getenv("MVAR_ENABLE_LEDGER") != "1":
        print("⚠️  MVAR_ENABLE_LEDGER not set to 1")
        sys.exit(1)

    if len(sys.argv) < 3:
        print("Usage: mvar-allow add <decision_id> [ttl_hours]")
        print("Example: mvar-allow add MVAR_DEC_20260224T120000Z_a1b2c3d4 24")
        sys.exit(1)

    decision_id = sys.argv[2]
    ttl_hours = int(sys.argv[3]) if len(sys.argv) > 3 else 24

    ledger = _init_ledger_or_exit()

    # Validate decision exists
    decision = ledger.get_decision(decision_id)
    if not decision:
        print(f"❌ Decision {decision_id} not found")
        sys.exit(1)

    if decision["decision_outcome"] not in ("BLOCK", "STEP_UP"):
        print(f"❌ Can only override BLOCK/STEP_UP decisions, got {decision['decision_outcome']}")
        sys.exit(1)

    # Show what will be overridden
    print(f"\n{'='*80}")
    print(f"Create Override")
    print(f"{'='*80}\n")
    print(f"Original Decision:")
    print(f"  ID:       {decision['scroll_id']}")
    print(f"  Outcome:  {decision['decision_outcome']}")
    print(f"  Reason:   {decision['reason']}")
    print()

    sink = decision["sink_target"]
    print(f"Override Scope (exact matching):")
    print(f"  Tool:        {sink['tool']}")
    print(f"  Action:      {sink['action']}")
    print(f"  Target Hash: {sink['target_hash']}")
    print(f"  TTL:         {ttl_hours} hours")
    print()

    # Confirm with user
    response = input("Create override? [y/N]: ").strip().lower()
    if response not in ("y", "yes"):
        print("Cancelled.")
        sys.exit(0)

    # Create override
    try:
        override_id = ledger.create_override(
            original_decision_id=decision_id,
            principal_id=_principal_id(),
            ttl_hours=ttl_hours
        )
        print(f"\n✅ Override created: {override_id}")
        print(f"   Expires in {ttl_hours} hours")
        print(f"\n   Use 'mvar-allow expire {override_id}' to revoke early\n")
    except Exception as e:
        print(f"❌ Failed to create override: {e}")
        sys.exit(1)


def mvar_allow_list():
    """List active overrides"""
    if os.getenv("MVAR_ENABLE_LEDGER") != "1":
        print("⚠️  MVAR_ENABLE_LEDGER not set to 1")
        sys.exit(1)

    ledger = _init_ledger_or_exit()
    overrides = ledger.load_overrides()

    # Load expiries (revocations)
    expiries = ledger._load_scrolls(scroll_type="expiry")
    revoked_ids = {e["revoked_override_id"] for e in expiries}

    # Filter active overrides (not expired, not revoked)
    now = datetime.now(timezone.utc)
    active = []
    for override in overrides:
        expiry_time = datetime.fromisoformat(override["ttl_expiry"].replace("Z", "+00:00"))
        if now < expiry_time and override["scroll_id"] not in revoked_ids:
            active.append(override)

    if not active:
        print("No active overrides.")
        sys.exit(0)

    print(f"\n{'='*80}")
    print(f"Active MVAR Overrides ({len(active)})")
    print(f"{'='*80}\n")

    for i, override in enumerate(active, 1):
        expiry = format_timestamp(override["ttl_expiry"])
        criteria = override["match_criteria"]
        tool_action = f"{criteria['tool']}.{criteria['action']}"
        target_hash = criteria["target_hash"][:8] + "..."

        print(f"{i}. Override ID: {override['scroll_id']}")
        print(f"   Created:     {format_timestamp(override['timestamp'])}")
        print(f"   Expires:     {expiry}")
        print(f"   Scope:       {tool_action} (target: {target_hash})")
        print(f"   Original:    {override['parent_decision_id']}")
        print()

    print(f"{'='*80}\n")
    print(f"Use 'mvar-allow expire <override_id>' to revoke\n")


def mvar_allow_expire():
    """Revoke an override"""
    if os.getenv("MVAR_ENABLE_LEDGER") != "1":
        print("⚠️  MVAR_ENABLE_LEDGER not set to 1")
        sys.exit(1)

    if len(sys.argv) < 3:
        print("Usage: mvar-allow expire <override_id>")
        print("Example: mvar-allow expire MVAR_OVR_20260224T120500Z_e5f6g7h8")
        sys.exit(1)

    override_id = sys.argv[2]

    ledger = _init_ledger_or_exit()

    # Validate override exists
    overrides = ledger.load_overrides()
    override = None
    for o in overrides:
        if o["scroll_id"] == override_id:
            override = o
            break

    if not override:
        print(f"❌ Override {override_id} not found")
        sys.exit(1)

    # Confirm revocation
    print(f"\n{'='*80}")
    print(f"Revoke Override")
    print(f"{'='*80}\n")
    print(f"Override ID:  {override['scroll_id']}")
    print(f"Created:      {format_timestamp(override['timestamp'])}")
    print(f"Expires:      {format_timestamp(override['ttl_expiry'])}")
    print()

    response = input("Revoke this override? [y/N]: ").strip().lower()
    if response not in ("y", "yes"):
        print("Cancelled.")
        sys.exit(0)

    # Revoke
    try:
        expiry_id = ledger.expire_override(override_id)
        print(f"\n✅ Override {override_id} revoked")
        print(f"   Expiry ID: {expiry_id}\n")
    except Exception as e:
        print(f"❌ Failed to revoke override: {e}")
        sys.exit(1)


def _load_witness_scrolls(witness_path: str) -> Tuple[List[Tuple[str, Dict[str, Any]]], List[str]]:
    path = Path(witness_path)
    if not path.exists():
        return [], ["missing_file"]

    content = path.read_text(encoding="utf-8").strip()
    if not content:
        return [], ["witness_file_empty"]

    if path.suffix.lower() == ".jsonl":
        records: List[Tuple[str, Dict[str, Any]]] = []
        for idx, line in enumerate(content.splitlines(), start=1):
            label = f"line_{idx}"
            if not line.strip():
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                return [], [f"malformed_json:{label}"]
            if not isinstance(item, dict):
                return [], [f"non_object_jsonl_line:{label}"]
            records.append((label, item))
        if not records:
            return [], ["witness_file_empty"]
        return records, []

    try:
        payload = json.loads(content)
    except json.JSONDecodeError:
        return [], ["malformed_json"]

    if isinstance(payload, dict):
        return [("line_1", payload)], []

    if isinstance(payload, list):
        records = []
        for idx, item in enumerate(payload, start=1):
            label = f"index_{idx}"
            if not isinstance(item, dict):
                return [], [f"non_object_json_list_item:{label}"]
            records.append((label, item))
        if not records:
            return [], ["witness_file_empty"]
        return records, []

    return [], ["non_object_json"]


def verify_witness_file(witness_path: str, *, require_chain: bool = False) -> Dict[str, Any]:
    """
    Verify portable witness artifacts (JSON/JSONL) produced by MVAR ledger paths.

    Returns machine-readable report fields for signature validity and optional
    chain integrity checks.
    """
    records, load_errors = _load_witness_scrolls(witness_path)
    if load_errors:
        return {
            "witness_path": witness_path,
            "total_scrolls": 0,
            "verified_scrolls": 0,
            "all_signatures_valid": False,
            "chain_valid": False,
            "errors": load_errors,
        }

    ledger = _init_ledger_or_exit()
    errors: List[str] = []
    verified = 0

    for label, scroll in records:
        scroll_id = str(scroll.get("scroll_id", label))
        if not scroll.get("qseal_signature"):
            errors.append(f"missing_signature:{label}")
            continue
        # Reuse existing ledger verification logic for signature/meta checks.
        if ledger._verify_scroll(scroll):  # noqa: SLF001
            verified += 1
        else:
            errors.append(f"signature_invalid:{scroll_id}")

    chain_errors: List[str] = []
    previous_sig = None
    for idx, (label, scroll) in enumerate(records, start=1):
        current_sig = scroll.get("qseal_signature")
        prev_pointer = scroll.get("qseal_prev_signature")
        if idx == 1:
            previous_sig = current_sig
            continue
        if prev_pointer is None:
            if require_chain:
                chain_errors.append(f"chain_missing_prev_signature:{label}")
        elif previous_sig is not None and prev_pointer != previous_sig:
            chain_errors.append(f"chain_mismatch:{label}")
        previous_sig = current_sig

    errors.extend(chain_errors)
    all_signatures_valid = verified == len(records)
    chain_valid = len(chain_errors) == 0

    return {
        "witness_path": witness_path,
        "total_scrolls": len(records),
        "verified_scrolls": verified,
        "all_signatures_valid": all_signatures_valid,
        "chain_valid": chain_valid,
        "errors": errors,
    }


_VERIFY_WITNESS_HELP_TEXT = """Usage: mvar-verify-witness <ledger.jsonl> [options]

Options:
  --require-chain     Require valid signature chain
  --qseal-key PATH    Verify using provided QSEAL key
  --quiet             Minimal output
  --json              JSON verification output
  -h, --help          Show help"""


def _print_verify_witness_help() -> None:
    print(_VERIFY_WITNESS_HELP_TEXT)


def _parse_verify_witness_args(argv: List[str]) -> Dict[str, Any]:
    if not argv:
        raise ValueError("missing_witness_path")

    if len(argv) == 1 and argv[0] in ("-h", "--help"):
        return {"help": True}

    witness_path: Optional[str] = None
    require_chain = False
    quiet = False
    json_out = False
    qseal_key_path: Optional[str] = None

    idx = 0
    while idx < len(argv):
        token = argv[idx]
        if token in ("-h", "--help"):
            raise ValueError("help_with_extra_args")
        if token == "--require-chain":
            require_chain = True
        elif token == "--quiet":
            quiet = True
        elif token == "--json":
            json_out = True
        elif token == "--qseal-key":
            idx += 1
            if idx >= len(argv):
                raise ValueError("missing_qseal_key_path")
            qseal_key_path = argv[idx]
        elif token.startswith("-"):
            raise ValueError(f"unknown_option:{token}")
        elif witness_path is None:
            witness_path = token
        else:
            raise ValueError(f"unexpected_argument:{token}")
        idx += 1

    if witness_path is None:
        raise ValueError("missing_witness_path")

    return {
        "help": False,
        "witness_path": witness_path,
        "require_chain": require_chain,
        "quiet": quiet,
        "json_out": json_out,
        "qseal_key_path": qseal_key_path,
    }


def _apply_qseal_key_path(qseal_key_path: Optional[str]) -> Tuple[Optional[str], bool]:
    """
    Apply optional --qseal-key for HMAC verification mode by temporarily setting
    QSEAL_SECRET from file contents.
    """
    if not qseal_key_path:
        return None, False

    key_path = Path(qseal_key_path)
    try:
        qseal_secret = key_path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise ValueError(f"invalid_qseal_key_path:{qseal_key_path}") from exc

    previous = os.environ.get("QSEAL_SECRET")
    os.environ["QSEAL_SECRET"] = qseal_secret
    return previous, True


def main_verify_witness():
    """Entry point for 'mvar-verify-witness' binary."""
    try:
        parsed = _parse_verify_witness_args(sys.argv[1:])
    except ValueError:
        _print_verify_witness_help()
        sys.exit(2)

    if parsed["help"]:
        _print_verify_witness_help()
        sys.exit(0)

    previous_qseal_secret: Optional[str] = None
    qseal_overridden = False
    try:
        try:
            previous_qseal_secret, qseal_overridden = _apply_qseal_key_path(parsed["qseal_key_path"])
        except ValueError:
            _print_verify_witness_help()
            sys.exit(2)

        report = verify_witness_file(parsed["witness_path"], require_chain=parsed["require_chain"])
    finally:
        if qseal_overridden:
            if previous_qseal_secret is None:
                os.environ.pop("QSEAL_SECRET", None)
            else:
                os.environ["QSEAL_SECRET"] = previous_qseal_secret

    ok = report["all_signatures_valid"] and (report["chain_valid"] or not parsed["require_chain"])

    if parsed["json_out"]:
        print(json.dumps(report))
    elif not parsed["quiet"]:
        print(f"witness verification {'PASS' if ok else 'FAIL'}")

    sys.exit(0 if ok else 1)


# Entry points for setup.py console_scripts
def main_report():
    """Entry point for 'mvar report'"""
    mvar_report()


def main_explain():
    """Entry point for 'mvar-explain' binary"""
    if len(sys.argv) < 2:
        print("Usage: mvar-explain <decision_id>")
        sys.exit(1)
    mvar_explain(sys.argv[1])


def main_allow():
    """Entry point for 'mvar-allow' binary"""
    if len(sys.argv) < 2:
        print("Usage: mvar-allow <add|list|expire> [args...]")
        print()
        print("Subcommands:")
        print("  add <decision_id> [ttl_hours]  - Create override")
        print("  list                           - List active overrides")
        print("  expire <override_id>           - Revoke override")
        sys.exit(1)

    subcommand = sys.argv[1]
    if subcommand == "add":
        mvar_allow_add()
    elif subcommand == "list":
        mvar_allow_list()
    elif subcommand == "expire":
        mvar_allow_expire()
    else:
        print(f"❌ Unknown subcommand: {subcommand}")
        print("Valid subcommands: add, list, expire")
        sys.exit(1)
