from .ctor import isctormethod
from .iface import NoSuchInstanceException, Special, unset
from .match import ExactMatch, SourceArg, wrap
from foyndation import innerclass, solo
try:
    from inspect import getfullargspec as getargspec
except ImportError:
    from inspect import getargspec
from itertools import chain, repeat

class Source:

    def __init__(self, type):
        def addtype(type):
            self.types.add(type)
            for base in getattr(type, '__bases__', ()):
                if base not in self.types:
                    addtype(base)
        self.types = set()
        addtype(type)
        self.typelabel = Special.gettypelabel(type)
        self.type = type

class Instance(Source):

    def __init__(self, instance, type):
        super().__init__(type)
        self.instance = instance

    def plan(self, depth, trigger):
        pass

class Proxy(Source):

    @property
    def instance(self):
        return self._othersource().instance

    def __init__(self, otherdi, type):
        super().__init__(type)
        self.otherdi = otherdi

    def _othersource(self):
        s, = ExactMatch(self.type).getsources(self.otherdi)
        return s

    def plan(self, depth, trigger):
        return self._othersource().plan(depth, trigger)

class Creator(Source):

    @property
    def instance(self):
        return self.di.state.getinstance(self)

    def __init__(self, instantiator, di):
        super().__init__(instantiator.resulttype)
        self.instantiator = instantiator
        self.di = di

    def plan(self, depth, trigger):
        try:
            self.instance
        except NoSuchInstanceException:
            self.di.log.debug("%sRequest: %s%s", depth, self.typelabel, '' if trigger == self.type else "(%s)" % Special.gettypelabel(trigger))
            return self.instantiator.Plan(depth)

    def setmanagedinstance(self, instance):
        self.di.state.context.instances[self] = instance

    def setfreeinstance(self, instance):
        self.setmanagedinstance(instance)
        try:
            dispose = instance.dispose
        except AttributeError:
            return
        def callback():
            self.di.log.debug("Dispose: %s", self.typelabel)
            dispose()
        self.di.state.context.stack.callback(callback)

    def toargs(self, deptypes, defaults):
        if defaults is None:
            defaults = ()
        return [t.di_get(self.di, default) for t, default in zip(deptypes, chain(repeat(unset, len(deptypes) - len(defaults)), defaults))]

class CreatorPlan:

    def __init__(self, depth):
        self.depth = depth

    def make(self):
        self.di.log.debug("%s%s: %s", self.depth, type(self.instantiator).__name__, self.typelabel)
        self.fire()

class Class(Creator):

    @innerclass
    class Instantiate:

        @property
        def resulttype(self):
            return self.cls

        def __init__(self, cls, ctor):
            self.cls = cls
            self.ctor = ctor

        @innerclass
        class Plan(CreatorPlan):

            @property
            def args(self):
                for a in self.ctorargs:
                    yield a
                for _, eargs in self.enhancers:
                    for a in eargs:
                        yield a

            def __init__(self, depth):
                super().__init__(depth)
                methods = {}
                for name in dir(self.cls):
                    if name != self.ctor.method.__name__:
                        m = getattr(self.cls, name)
                        if isctormethod(m):
                            methods[name] = m
                self.ctorargs = self.toargs(self.ctor.method.di_deptypes, getargspec(self.ctor.method).defaults)
                self.enhancers = []
                if methods:
                    for ancestor in reversed(self.cls.mro()):
                        for name in dir(ancestor):
                            try:
                                m = methods.pop(name)
                            except KeyError:
                                pass
                            else:
                                self.enhancers.append([m, self.toargs(m.di_deptypes, getargspec(m).defaults)])

            def fire(self):
                instance = self.ctor.invoke(*(a.resolve() for a in self.ctorargs))
                if self.enhancers:
                    self.di.log.debug("%sEnhance: %s", self.depth, self.typelabel)
                    for m, eargs in self.enhancers:
                        m(instance, *(a.resolve() for a in eargs))
                self.setfreeinstance(instance)

    def __init__(self, cls, ctor, di):
        super().__init__(self.Instantiate(cls, ctor), di)

class Factory(Creator):

    @innerclass
    class Fabricate:

        @property
        def resulttype(self):
            f = self.function
            try:
                return f.di_owntype
            except AttributeError:
                return f

        def __init__(self, function):
            self.function = function

        @innerclass
        class Plan(CreatorPlan):

            def __init__(self, depth):
                super().__init__(depth)
                self.args = self.toargs(self.function.di_deptypes, getargspec(self.function).defaults)

            def fire(self):
                self.setfreeinstance(self.function(*(a.resolve() for a in self.args)))

    def __init__(self, function, di):
        super().__init__(self.Fabricate(function), di)

class ContextManager(Creator):

    @innerclass
    class Yield:

        @property
        def resulttype(self):
            return solo(self.cmsource.type.__args__)

        def __init__(self, cmsource):
            self.cmsource = cmsource

        @innerclass
        class Plan(CreatorPlan):

            def __init__(self, depth):
                super().__init__(depth)
                self.args = [SourceArg(self.cmsource, self.cmsource.type)]

            def fire(self):
                self.setmanagedinstance(self.di.state.context.stack.enter_context(solo(self.args).resolve()))

    def __init__(self, cmsource, di):
        super().__init__(self.Yield(cmsource), di)

class Builder(Creator):

    @innerclass
    class Build:

        @property
        def resulttype(self):
            return self.method.di_owntype

        def __init__(self, receivertype, method):
            self.receivermatch = wrap(receivertype)
            self.method = method

        @innerclass
        class Plan(CreatorPlan):

            def __init__(self, depth):
                super().__init__(depth)
                self.args = self.toargs((self.receivermatch,) + self.method.di_deptypes, getargspec(self.method).defaults)

            def fire(self):
                self.setfreeinstance(self.method(*(a.resolve() for a in self.args)))

    def __init__(self, receivertype, method, di):
        super().__init__(self.Build(receivertype, method), di)
