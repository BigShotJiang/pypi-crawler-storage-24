from types import GenericAlias

class MissingAnnotationException(Exception): pass

def _clslabel(cls):
    return f"{_clslabel(cls.__origin__)}[{', '.join(map(_clslabel, cls.__args__))}]" if isinstance(cls, GenericAlias) else f"{cls.__module__}:{cls.__name__}"

class Special:

    @classmethod
    def gettypelabel(cls, type):
        try:
            subclass = issubclass(type, cls)
        except TypeError:
            subclass = False
        return type.__name__ if subclass else _clslabel(type)

class UnsatisfiableRequestException(Exception): pass

class ImpasseException(Exception): pass

class NoSuchInstanceException(Exception): pass

unset = object()
