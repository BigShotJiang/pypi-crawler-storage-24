# entry-door

[![License: Apache-2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)

> **[𓉸 Passage Protocol](https://cellar-door.dev)** · [exit-door](https://github.com/CellarDoorExits/exit-door) · [entry-door](https://github.com/CellarDoorExits/entry-door) · [mcp](https://github.com/CellarDoorExits/mcp-server) · [langchain](https://github.com/CellarDoorExits/langchain) · [vercel](https://github.com/CellarDoorExits/vercel-ai-sdk) · [eliza](https://github.com/CellarDoorExits/eliza-exit) · [eas](https://github.com/CellarDoorExits/eas-adapter) · [erc-8004](https://github.com/CellarDoorExits/erc-8004-adapter) · [sign](https://github.com/CellarDoorExits/sign-protocol-adapter) · [python](https://github.com/CellarDoorExits/exit-python)

> ⚠️ **Pre-release**: This package is under active development and has not undergone a formal security audit. Use in production at your own risk.

Verifiable Arrival Markers — the **ENTRY** primitive for [Cellar Door](https://cellar-door.dev).

`entry-door` is the receiving side of the Cellar Door protocol. It verifies
[exit-door](https://github.com/nichochar/exit-door-python) departure markers,
creates cryptographically signed arrival markers, and runs a composable policy
engine to decide whether an agent should be admitted.

## Install

```bash
pip install entry-door
```

> Requires Python 3.10+. Pulls in `exit-door` and `pydantic` automatically.

## Quick Start

### 1. One-liner — `quick_entry()`

```python
from entry_door import quick_entry

result = quick_entry(exit_marker_json)

print(result.arrival_marker.id)       # arrival marker ID
print(result.verification.valid)      # departure signature OK?
```

### 2. Full admission with a policy

```python
from entry_door import admit, AdmitOpts, CAUTIOUS

result = admit(exit_marker, AdmitOpts(policy=CAUTIOUS))

if result.admission.admitted:
    print("Welcome!", result.arrival_marker.id)
else:
    print("Denied:", result.admission.reason_codes)
```

### 3. Build a custom policy

```python
from entry_door import create_policy

policy = (
    create_policy("my-platform")
    .require_verified_departure()
    .require_confirmation("mutual")
    .max_age("24h")
    .on_disputed("quarantine", max_duration="7d")
    .allow_minting(require_justification=True)
    .build()
)

result = admit(exit_marker, AdmitOpts(policy=policy))
```

### 4. Preset policies

| Name | Description |
|------|-------------|
| `CAUTIOUS` | Verified departure, probation for self-only, quarantine disputes |
| `REQUIRE_MUTUAL` | Requires mutual confirmation + verified departure |
| `PERMISSIVE` | Admits by default, probation for self-only |
| `LOCKDOWN` | Denies everything |
| `OPEN_DOOR_V2` | Admits everything |

### 5. Persistent storage

```python
from entry_door import SqliteClaimStore, admit, AdmitOpts

store = SqliteClaimStore("claims.db")
store.init()

result = admit(exit_marker, AdmitOpts(store=store, policy=policy))
```

## JSON Serialization

All key models (`AdmissionRecord`, `AdmitResult`, `PolicyJSON`, `ArrivalMarker`)
serialize to **camelCase** JSON for wire compatibility with the TypeScript
implementation:

```python
record = result.admission
print(record.model_dump(by_alias=True))
# {"id": "...", "exitMarkerId": "...", "arrivalMarkerId": "...", ...}
```

Snake_case attribute access is always available in Python:

```python
record.exit_marker_id   # works
record.arrival_marker_id  # works
```

## Dependencies

- [exit-door](https://pypi.org/project/exit-door/) — departure markers & crypto
- [pydantic](https://docs.pydantic.dev/) — data validation & serialization

## Links

- [Cellar Door protocol](https://cellar-door.dev)
- [exit-door (Python)](https://github.com/nichochar/exit-door-python)

## License

Apache-2.0 — see [LICENSE](LICENSE).
