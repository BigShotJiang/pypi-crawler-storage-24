"""Tests for sign.py."""

from entry_door import (
    create_arrival_marker,
    sign_arrival_marker,
    verify_arrival_marker,
)
from tests.conftest import DESTINATION


def test_sign_and_verify_ed25519(signed_exit, entry_keypair):
    marker = create_arrival_marker(signed_exit, DESTINATION)
    signed = sign_arrival_marker(marker, entry_keypair.private_key, entry_keypair.public_key)
    assert signed.proof is not None
    assert signed.proof.type == "Ed25519Signature2020"
    result = verify_arrival_marker(signed)
    assert result.valid is True
    assert result.errors == []


def test_sign_and_verify_p256(signed_exit, entry_p256_keypair):
    marker = create_arrival_marker(signed_exit, DESTINATION)
    signed = sign_arrival_marker(
        marker, entry_p256_keypair.private_key, entry_p256_keypair.public_key, "P-256"
    )
    assert signed.proof is not None
    assert signed.proof.type == "EcdsaP256Signature2019"
    result = verify_arrival_marker(signed)
    assert result.valid is True


def test_verify_missing_proof(signed_exit):
    marker = create_arrival_marker(signed_exit, DESTINATION)
    result = verify_arrival_marker(marker)
    assert result.valid is False
    assert "Missing proof" in result.errors


def test_verify_tampered_marker(signed_exit, entry_keypair):
    marker = create_arrival_marker(signed_exit, DESTINATION)
    signed = sign_arrival_marker(marker, entry_keypair.private_key, entry_keypair.public_key)
    # Tamper with the destination
    tampered = signed.model_copy(update={"destination": "https://evil.example.com"})
    result = verify_arrival_marker(tampered)
    assert result.valid is False


def test_sign_preserves_fields(signed_exit, entry_keypair):
    marker = create_arrival_marker(signed_exit, DESTINATION)
    signed = sign_arrival_marker(marker, entry_keypair.private_key, entry_keypair.public_key)
    assert signed.id == marker.id
    assert signed.subject == marker.subject
    assert signed.destination == marker.destination
