"""Tests for admit() ceremony."""

import pytest
from exit_door import (
    ExitMarker,
    generate_key_pair,
    quick_exit,
    add_counter_signature,
)

from entry_door import (
    admit,
    AdmitOpts,
    InMemoryClaimStore,
    SqliteClaimStore,
    AdmissionEventEmitter,
    is_admission_store,
)
from entry_door.policy_builder import (
    CAUTIOUS,
    OPEN_DOOR_V2,
    LOCKDOWN,
    PERMISSIVE,
    create_policy,
)


@pytest.fixture
def signed_exit():
    return quick_exit("https://origin.example.com").marker


@pytest.fixture
def platform_kp():
    kp = generate_key_pair()
    return {"private_key": kp.private_key, "public_key": kp.public_key}


@pytest.fixture
def sqlite_store():
    s = SqliteClaimStore(":memory:")
    s.init()
    yield s
    s.close()


class TestAdmitWithExitMarker:
    def test_basic_admit_with_counter_sign(self, signed_exit, platform_kp):
        result = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
        ))
        assert result["admission"]["admitted"] is True
        assert result["admission"]["counter_signed"] is True
        assert result["arrival_marker"] is not None
        assert result["counter_signed_exit_marker"] is not None

    def test_admit_no_counter_sign(self, signed_exit, platform_kp):
        result = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
            counter_sign=False,
        ))
        assert result["admission"]["admitted"] is True
        assert result["admission"]["counter_signed"] is False

    def test_admit_no_platform_identity(self, signed_exit):
        result = admit(signed_exit, AdmitOpts(policy=OPEN_DOOR_V2))
        assert result["admission"]["admitted"] is True
        assert result["admission"]["counter_signed"] is False

    def test_admit_with_open_door(self, signed_exit):
        result = admit(signed_exit, AdmitOpts(policy=OPEN_DOOR_V2))
        assert result["admission"]["admitted"] is True

    def test_admit_with_lockdown_rejects(self, signed_exit):
        result = admit(signed_exit, AdmitOpts(policy=LOCKDOWN))
        assert result["admission"]["admitted"] is False
        assert result["arrival_marker"] is None

    def test_arrival_marker_has_correct_fields(self, signed_exit, platform_kp):
        result = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
            destination="https://dest.example.com",
        ))
        am = result["arrival_marker"]
        assert am.destination == "https://dest.example.com"
        assert am.subject == signed_exit.subject

    def test_admission_record_fields(self, signed_exit, platform_kp):
        result = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
            counter_sign_meaning="terms_acknowledged",
        ))
        rec = result["admission"]
        assert rec["admission_type"] == "standard"
        assert rec["counter_sign_meaning"] == "terms_acknowledged"
        assert rec["policy_applied"] == "cautious"
        assert rec["id"].startswith("admission-")


class TestAdmitMinting:
    def test_minting_with_permissive(self, platform_kp):
        result = admit(None, AdmitOpts(
            platform_identity=platform_kp,
            policy=PERMISSIVE,
            minting_subject="did:test:newagent",
            minting_justification="migration",
        ))
        assert result["admission"]["admitted"] is True
        assert result["admission"]["admission_type"] == "minted"
        am = result["arrival_marker"]
        assert am.subject == "did:test:newagent"
        assert am.verification_result.valid is False
        assert "minted-no-departure" in am.verification_result.errors

    def test_minting_requires_subject(self, platform_kp):
        with pytest.raises(ValueError, match="minting_subject"):
            admit(None, AdmitOpts(
                platform_identity=platform_kp,
                policy=PERMISSIVE,
            ))

    def test_minting_rejected_by_lockdown(self, platform_kp):
        result = admit(None, AdmitOpts(
            platform_identity=platform_kp,
            policy=LOCKDOWN,
            minting_subject="did:test:newagent",
        ))
        assert result["admission"]["admitted"] is False

    def test_minting_with_justification(self, platform_kp):
        policy = create_policy("minting-policy").allow_minting(require_justification=True).build()
        result = admit(None, AdmitOpts(
            platform_identity=platform_kp,
            policy=policy,
            minting_subject="did:test:agent",
            minting_justification="needed for test",
        ))
        assert result["admission"]["admitted"] is True
        assert result["admission"]["minting_justification"] == "needed for test"


class TestReplayProtection:
    def test_replay_detected(self, signed_exit, platform_kp, sqlite_store):
        opts = AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
            store=sqlite_store,
        )
        r1 = admit(signed_exit, opts)
        assert r1["admission"]["admitted"] is True

        r2 = admit(signed_exit, opts)
        assert r2["admission"]["admitted"] is False
        assert "replay-detected" in r2["admission"]["reason_codes"]

    def test_replay_with_in_memory_store(self, signed_exit, platform_kp):
        store = InMemoryClaimStore()
        opts = AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
            store=store,
        )
        r1 = admit(signed_exit, opts)
        assert r1["admission"]["admitted"] is True

        r2 = admit(signed_exit, opts)
        assert r2["admission"]["admitted"] is False


class TestADV02ClaimRelease:
    def test_claim_released_on_policy_rejection(self, signed_exit, platform_kp):
        store = InMemoryClaimStore()
        # First attempt: lockdown rejects
        r1 = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=LOCKDOWN,
            store=store,
        ))
        assert r1["admission"]["admitted"] is False

        # Claim should be released — second attempt with open policy should work
        r2 = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=OPEN_DOOR_V2,
            store=store,
        ))
        assert r2["admission"]["admitted"] is True

    def test_claim_not_released_on_replay(self, signed_exit, platform_kp):
        store = InMemoryClaimStore()
        # First: admit
        r1 = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
            store=store,
        ))
        assert r1["admission"]["admitted"] is True

        # Second: replay detected — claim stays consumed
        r2 = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
            store=store,
        ))
        assert r2["admission"]["admitted"] is False
        assert "replay-detected" in r2["admission"]["reason_codes"]

        # Third: still replay
        r3 = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=OPEN_DOOR_V2,
            store=store,
        ))
        assert r3["admission"]["admitted"] is False

    def test_claim_released_on_verification_failure(self, platform_kp):
        """An unsigned marker fails verification — claim should be released."""
        from exit_door import create_marker, ExitType
        unsigned = create_marker(origin="https://origin.example.com", subject="did:test:agent", exit_type=ExitType.VOLUNTARY)

        policy = create_policy("strict").require_verified_departure().build()
        store = InMemoryClaimStore()

        r1 = admit(unsigned, AdmitOpts(
            platform_identity=platform_kp,
            policy=policy,
            store=store,
        ))
        assert r1["admission"]["admitted"] is False
        assert "departure-verification-failed" in r1["admission"]["reason_codes"]

        # Should be able to re-present
        r2 = admit(unsigned, AdmitOpts(
            platform_identity=platform_kp,
            policy=OPEN_DOOR_V2,
            store=store,
        ))
        assert r2["admission"]["admitted"] is True


class TestQuarantine:
    def test_quarantine_on_disputed(self, platform_kp):
        from exit_door import ExitMarker, quick_exit, create_marker, sign_marker
        kp = generate_key_pair()
        # Create a marker with dispute data
        marker = quick_exit("https://origin.example.com").marker
        # Use a policy that quarantines disputed markers
        policy = (
            create_policy("quarantine-test")
            .on_disputed("quarantine", max_duration="7d")
            .default_decision("admit")
            .build()
        )
        # Marker without dispute should pass
        result = admit(marker, AdmitOpts(
            platform_identity=platform_kp,
            policy=policy,
        ))
        assert result["admission"]["admitted"] is True


class TestEventEmission:
    def test_admitted_event(self, signed_exit, platform_kp):
        events = []
        emitter = AdmissionEventEmitter()
        emitter.on("agent:admitted", lambda e: events.append(e))

        admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
            emitter=emitter,
        ))
        assert len(events) == 1
        assert events[0].type == "agent:admitted"

    def test_rejected_event(self, signed_exit, platform_kp):
        events = []
        emitter = AdmissionEventEmitter()
        emitter.on("agent:rejected", lambda e: events.append(e))

        admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=LOCKDOWN,
            emitter=emitter,
        ))
        assert len(events) == 1
        assert events[0].type == "agent:rejected"

    def test_minted_event(self, platform_kp):
        events = []
        emitter = AdmissionEventEmitter()
        emitter.on("agent:minted", lambda e: events.append(e))

        admit(None, AdmitOpts(
            platform_identity=platform_kp,
            policy=PERMISSIVE,
            minting_subject="did:test:minted",
            emitter=emitter,
        ))
        assert len(events) == 1
        assert events[0].type == "agent:minted"

    def test_replay_rejected_event(self, signed_exit, platform_kp):
        events = []
        emitter = AdmissionEventEmitter()
        emitter.on("agent:rejected", lambda e: events.append(e))
        store = InMemoryClaimStore()

        admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp, policy=CAUTIOUS, store=store, emitter=emitter,
        ))
        admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp, policy=CAUTIOUS, store=store, emitter=emitter,
        ))
        assert len(events) == 1
        assert events[0].data["record"]["reason_codes"] == ["replay-detected"]


class TestDeepClone:
    def test_exit_marker_not_mutated(self, signed_exit, platform_kp):
        """The caller's exit marker should not be mutated by admit()."""
        original_id = signed_exit.id
        original_subject = signed_exit.subject
        admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
        ))
        assert signed_exit.id == original_id
        assert signed_exit.subject == original_subject


class TestPolicySnapshot:
    def test_snapshot_included(self, signed_exit, platform_kp):
        result = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
        ))
        snapshot = result["admission"]["policy_snapshot"]
        assert snapshot is not None
        import json
        parsed = json.loads(snapshot)
        assert parsed["name"] == "cautious"


class TestStoreIntegration:
    def test_admission_stored_in_sqlite(self, signed_exit, platform_kp, sqlite_store):
        result = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=CAUTIOUS,
            store=sqlite_store,
        ))
        record_id = result["admission"]["id"]
        stored = sqlite_store.get_admission(record_id)
        assert stored is not None
        assert stored["admitted"] is True

    def test_rejection_stored_in_sqlite(self, signed_exit, platform_kp, sqlite_store):
        result = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=LOCKDOWN,
            store=sqlite_store,
        ))
        record_id = result["admission"]["id"]
        stored = sqlite_store.get_admission(record_id)
        assert stored is not None
        assert stored["admitted"] is False

    def test_minting_claim_stored(self, platform_kp, sqlite_store):
        result = admit(None, AdmitOpts(
            platform_identity=platform_kp,
            policy=PERMISSIVE,
            minting_subject="did:test:minted",
            store=sqlite_store,
        ))
        am = result["arrival_marker"]
        assert sqlite_store.is_claimed(am.id)
