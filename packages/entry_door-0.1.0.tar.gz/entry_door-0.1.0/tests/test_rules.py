"""Tests for individual policy rules."""

import pytest
from datetime import datetime, timezone
from exit_door import ExitMarker, quick_exit, StatusConfirmation

from entry_door.rules.types import RuleContext
from entry_door.rules.condition import Condition, format_condition, parse_condition
from entry_door.rules.confirmation_rule import ConfirmationRuleConfig, create_confirmation_rule
from entry_door.rules.origin_rule import BlockedOriginEntry, BlockReason, OriginRuleConfig, create_origin_rule
from entry_door.rules.dispute_rule import DisputeRuleConfig, create_dispute_rule
from entry_door.rules.trust_level_rule import TrustLevelRuleConfig, create_trust_level_rule
from entry_door.rules.minting_rule import MintingRuleConfig, create_minting_rule
from entry_door.rules.custom_rule import CustomRuleResult, create_custom_rule


def _marker() -> ExitMarker:
    return quick_exit("https://origin.example.com").marker


def _ctx(**kw) -> RuleContext:
    return RuleContext(**kw)


# ─── Condition ────────────────────────────────────────────────────────────────

class TestCondition:
    def test_format_simple(self):
        assert format_condition(Condition(type="quarantine")) == "quarantine"

    def test_format_with_params(self):
        c = Condition(type="probation", params={"duration": "7d"})
        assert format_condition(c) == "probation-duration:7d"

    def test_parse_simple(self):
        c = parse_condition("quarantine")
        assert c.type == "quarantine"
        assert c.params is None

    def test_parse_with_params(self):
        c = parse_condition("probation-duration:7d")
        assert c.type == "probation"
        assert c.params == {"duration": "7d"}

    def test_roundtrip(self):
        original = Condition(type="quarantine", params={"max": "7d"})
        assert parse_condition(format_condition(original)).params == original.params


# ─── Confirmation Rule ───────────────────────────────────────────────────────

class TestConfirmationRule:
    def test_abstains_on_minting(self):
        rule = create_confirmation_rule(ConfirmationRuleConfig(required_level=StatusConfirmation.MUTUAL))
        result = rule.evaluate(None, _ctx(is_minting=True))
        assert result.decision == "abstain"

    def test_self_only_below_mutual(self):
        rule = create_confirmation_rule(ConfirmationRuleConfig(required_level=StatusConfirmation.MUTUAL))
        marker = _marker()  # self_only by default
        result = rule.evaluate(marker, _ctx())
        assert result.decision == "deny"

    def test_self_only_meets_self_only(self):
        rule = create_confirmation_rule(ConfirmationRuleConfig(required_level=StatusConfirmation.SELF_ONLY))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "admit"


# ─── Origin Rule ─────────────────────────────────────────────────────────────

class TestOriginRule:
    def test_abstains_on_minting(self):
        rule = create_origin_rule(OriginRuleConfig())
        result = rule.evaluate(None, _ctx(is_minting=True))
        assert result.decision == "abstain"

    def test_blocked_origin(self):
        rule = create_origin_rule(OriginRuleConfig(
            blocked_origins=[BlockedOriginEntry(origin="https://origin.example.com", reason="bad")]
        ))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "deny"
        assert "blocked" in result.reason

    def test_blocked_with_structured_reason(self):
        rule = create_origin_rule(OriginRuleConfig(
            blocked_origins=[BlockedOriginEntry(
                origin="https://origin.example.com",
                reason=BlockReason(category="security", detail="compromised")
            )]
        ))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "deny"
        assert "security" in result.reason

    def test_expired_block_ignored(self):
        rule = create_origin_rule(OriginRuleConfig(
            blocked_origins=[BlockedOriginEntry(
                origin="https://origin.example.com",
                reason="old",
                expires_at="2020-01-01T00:00:00Z",
            )]
        ))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "admit"

    def test_allowed_origins_pass(self):
        rule = create_origin_rule(OriginRuleConfig(allowed_origins=["https://origin.example.com"]))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "admit"

    def test_allowed_origins_deny_unknown(self):
        rule = create_origin_rule(OriginRuleConfig(allowed_origins=["https://other.com"]))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "deny"


# ─── Dispute Rule ────────────────────────────────────────────────────────────

class TestDisputeRule:
    def test_abstains_no_dispute(self):
        rule = create_dispute_rule(DisputeRuleConfig(action="reject"))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "abstain"

    def test_abstains_on_minting(self):
        rule = create_dispute_rule(DisputeRuleConfig(action="reject"))
        result = rule.evaluate(None, _ctx(is_minting=True))
        assert result.decision == "abstain"


# ─── Trust Level Rule ────────────────────────────────────────────────────────

class TestTrustLevelRule:
    def test_abstains_on_minting(self):
        rule = create_trust_level_rule(TrustLevelRuleConfig(action="reject"))
        result = rule.evaluate(None, _ctx(is_minting=True))
        assert result.decision == "abstain"

    def test_reject_self_only(self):
        rule = create_trust_level_rule(TrustLevelRuleConfig(action="reject"))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "deny"

    def test_probation_self_only(self):
        rule = create_trust_level_rule(TrustLevelRuleConfig(action="probation", probation_duration="7d"))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "admit"
        assert any("probation" in c for c in result.conditions)

    def test_admit_self_only(self):
        rule = create_trust_level_rule(TrustLevelRuleConfig(action="admit"))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "admit"


# ─── Minting Rule ────────────────────────────────────────────────────────────

class TestMintingRule:
    def test_abstains_when_not_minting(self):
        rule = create_minting_rule(MintingRuleConfig(allowed=True))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "abstain"

    def test_deny_when_not_allowed(self):
        rule = create_minting_rule(MintingRuleConfig(allowed=False))
        result = rule.evaluate(None, _ctx(is_minting=True))
        assert result.decision == "deny"

    def test_allow_minting(self):
        rule = create_minting_rule(MintingRuleConfig(allowed=True))
        result = rule.evaluate(None, _ctx(is_minting=True))
        assert result.decision == "admit"

    def test_require_justification_missing(self):
        rule = create_minting_rule(MintingRuleConfig(allowed=True, require_justification=True))
        result = rule.evaluate(None, _ctx(is_minting=True))
        assert result.decision == "deny"

    def test_require_justification_present(self):
        rule = create_minting_rule(MintingRuleConfig(allowed=True, require_justification=True))
        result = rule.evaluate(None, _ctx(is_minting=True, minting_justification="new user"))
        assert result.decision == "admit"

    def test_enhanced_probation(self):
        rule = create_minting_rule(MintingRuleConfig(allowed=True, enhanced_probation="14d"))
        result = rule.evaluate(None, _ctx(is_minting=True))
        assert result.decision == "admit"
        assert "probation" in result.conditions
        assert "probation-duration:14d" in result.conditions


# ─── Custom Rule ─────────────────────────────────────────────────────────────

class TestCustomRule:
    def test_custom_pass(self):
        rule = create_custom_rule("my-rule", lambda m, c: CustomRuleResult(admitted=True, reason="ok"))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "admit"
        assert result.reason == "ok"

    def test_custom_fail(self):
        rule = create_custom_rule("my-rule", lambda m, c: CustomRuleResult(admitted=False))
        result = rule.evaluate(_marker(), _ctx())
        assert result.decision == "deny"

    def test_custom_with_conditions(self):
        rule = create_custom_rule("my-rule", lambda m, c: CustomRuleResult(admitted=True, conditions=["watch"]))
        result = rule.evaluate(_marker(), _ctx())
        assert "watch" in result.conditions
