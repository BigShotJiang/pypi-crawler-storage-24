"""Tests for quick_admit() convenience function."""

import warnings
import pytest
from exit_door import generate_key_pair, quick_exit

from entry_door import quick_admit
from entry_door.convenience import QuickAdmitOpts
from entry_door.policy_builder import CAUTIOUS, PERMISSIVE


@pytest.fixture
def signed_exit():
    return quick_exit("https://origin.example.com").marker


@pytest.fixture
def platform_kp():
    kp = generate_key_pair()
    return {"private_key": kp.private_key, "public_key": kp.public_key}


class TestQuickAdmit:
    def test_basic_quick_admit(self, signed_exit, platform_kp):
        result = quick_admit(signed_exit, QuickAdmitOpts(platform_identity=platform_kp))
        assert result["admission"]["admitted"] is True

    def test_quick_admit_with_string(self, platform_kp):
        from exit_door import to_json
        exit_result = quick_exit("https://origin.example.com")
        json_str = to_json(exit_result.marker)
        result = quick_admit(json_str, QuickAdmitOpts(platform_identity=platform_kp))
        assert result["admission"]["admitted"] is True

    def test_quick_admit_generates_ephemeral_keys(self, signed_exit):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = quick_admit(signed_exit)
            assert result["admission"]["admitted"] is True
            assert any("ephemeral" in str(warning.message) for warning in w)

    def test_quick_admit_minting(self, platform_kp):
        result = quick_admit(None, QuickAdmitOpts(
            platform_identity=platform_kp,
            policy=PERMISSIVE,
            minting_subject="did:test:new",
        ))
        assert result["admission"]["admitted"] is True
        assert result["arrival_marker"].subject == "did:test:new"

    def test_quick_admit_with_none_marker(self, platform_kp):
        result = quick_admit(None, QuickAdmitOpts(
            platform_identity=platform_kp,
            policy=PERMISSIVE,
            minting_subject="did:test:agent",
        ))
        assert result["admission"]["admitted"] is True
