"""Tests for verify_departure.py."""

from exit_door import to_json

from entry_door import verify_departure, verify_departure_json
from tests.conftest import DESTINATION


def test_verify_departure_valid(signed_exit):
    result = verify_departure(signed_exit)
    assert result.valid is True
    assert result.errors == []


def test_verify_departure_json_valid(exit_json):
    result = verify_departure_json(exit_json)
    assert result.parsed is True
    assert result.result.valid is True
    assert result.marker is not None


def test_verify_departure_json_invalid():
    result = verify_departure_json("not json")
    assert result.parsed is False
    assert result.result.valid is False
    assert len(result.result.errors) > 0


def test_verify_departure_json_empty_object():
    result = verify_departure_json("{}")
    assert result.parsed is False
    assert result.result.valid is False
