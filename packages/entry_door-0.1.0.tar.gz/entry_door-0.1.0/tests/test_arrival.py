"""Tests for arrival.py."""

from entry_door import (
    ENTRY_CONTEXT_V1,
    canonicalize,
    compute_arrival_id,
    create_arrival_marker,
    CreateArrivalOpts,
)
from tests.conftest import DESTINATION


def test_canonicalize_null():
    assert canonicalize(None) == "null"


def test_canonicalize_string():
    assert canonicalize("hello") == '"hello"'


def test_canonicalize_number():
    assert canonicalize(42) == "42"


def test_canonicalize_bool():
    assert canonicalize(True) == "true"
    assert canonicalize(False) == "false"


def test_canonicalize_sorted_keys():
    result = canonicalize({"b": 1, "a": 2})
    assert result == '{"a":2,"b":1}'


def test_canonicalize_nested():
    result = canonicalize({"z": {"b": 1, "a": 2}})
    assert result == '{"z":{"a":2,"b":1}}'


def test_canonicalize_array():
    result = canonicalize([3, 1, 2])
    assert result == "[3,1,2]"


def test_compute_arrival_id_deterministic():
    body = {"a": 1, "b": 2}
    id1 = compute_arrival_id(body)
    id2 = compute_arrival_id(body)
    assert id1 == id2
    assert len(id1) == 64  # sha256 hex


def test_create_arrival_marker_basic(signed_exit):
    marker = create_arrival_marker(signed_exit, DESTINATION)
    assert marker.context == ENTRY_CONTEXT_V1
    assert marker.type == "ArrivalMarker"
    assert marker.id.startswith("urn:entry:")
    assert marker.departure_ref == signed_exit.id
    assert marker.departure_origin == signed_exit.origin
    assert marker.destination == DESTINATION
    assert marker.subject == signed_exit.subject
    assert marker.admission_type == "automatic"
    assert marker.verification_result.valid is True
    assert marker.proof is None


def test_create_arrival_marker_with_opts(signed_exit):
    opts = CreateArrivalOpts(
        admission_type="reviewed",
        conditions=["manual-check"],
        timestamp="2024-06-01T00:00:00Z",
    )
    marker = create_arrival_marker(signed_exit, DESTINATION, opts)
    assert marker.admission_type == "reviewed"
    assert marker.conditions == ["manual-check"]
    assert marker.timestamp == "2024-06-01T00:00:00Z"


def test_create_arrival_marker_deterministic_id(signed_exit):
    opts = CreateArrivalOpts(timestamp="2024-06-01T00:00:00Z")
    m1 = create_arrival_marker(signed_exit, DESTINATION, opts)
    m2 = create_arrival_marker(signed_exit, DESTINATION, opts)
    assert m1.id == m2.id
