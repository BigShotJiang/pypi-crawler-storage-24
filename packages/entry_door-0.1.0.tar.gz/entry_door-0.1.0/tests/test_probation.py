"""Tests for probation.py."""

from datetime import datetime, timezone, timedelta

from entry_door import (
    ProbationConfig,
    create_probationary_arrival,
    is_probation_complete,
)
from tests.conftest import DESTINATION


def test_create_probationary_arrival(signed_exit):
    config = ProbationConfig(duration=3600000, restrictions=["read-only"], review_required=True)
    marker = create_probationary_arrival(signed_exit, DESTINATION, config)
    assert marker.admission_type == "conditional"
    assert marker.probation is not None
    assert marker.probation.duration == 3600000
    assert marker.probation.review_required is True
    assert "probation-3600000ms" in marker.conditions
    assert "restriction:read-only" in marker.conditions


def test_is_probation_complete_not_yet(signed_exit):
    config = ProbationConfig(duration=3600000, restrictions=[], review_required=False)
    marker = create_probationary_arrival(signed_exit, DESTINATION, config)
    assert is_probation_complete(marker) is False


def test_is_probation_complete_elapsed(signed_exit):
    config = ProbationConfig(duration=1, restrictions=[], review_required=False)
    from entry_door import CreateArrivalOpts
    opts = CreateArrivalOpts(timestamp="2020-01-01T00:00:00Z")
    marker = create_probationary_arrival(signed_exit, DESTINATION, config, opts)
    assert is_probation_complete(marker) is True


def test_no_probation_is_complete(signed_exit):
    from entry_door import create_arrival_marker
    marker = create_arrival_marker(signed_exit, DESTINATION)
    assert is_probation_complete(marker) is True
