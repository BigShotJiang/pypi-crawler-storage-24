"""Tests for revocation.py."""

import pytest

from entry_door import (
    create_arrival_marker,
    create_revocation_marker,
    is_revoked,
    sign_arrival_marker,
    verify_revocation_marker,
)
from tests.conftest import DESTINATION


def test_create_and_verify_revocation_ed25519(signed_exit, entry_keypair):
    arrival = create_arrival_marker(signed_exit, DESTINATION)
    signed = sign_arrival_marker(arrival, entry_keypair.private_key, entry_keypair.public_key)
    revocation = create_revocation_marker(
        signed, "fraud", entry_keypair.private_key, entry_keypair.public_key
    )
    assert revocation.type == "RevocationMarker"
    assert revocation.arrival_ref == signed.id
    result = verify_revocation_marker(revocation, signed)
    assert result.valid is True


def test_create_and_verify_revocation_p256(signed_exit, entry_p256_keypair):
    arrival = create_arrival_marker(signed_exit, DESTINATION)
    signed = sign_arrival_marker(
        arrival, entry_p256_keypair.private_key, entry_p256_keypair.public_key, "P-256"
    )
    revocation = create_revocation_marker(
        signed, "policy violation", entry_p256_keypair.private_key, entry_p256_keypair.public_key, "P-256"
    )
    result = verify_revocation_marker(revocation, signed)
    assert result.valid is True


def test_revocation_authority_mismatch(signed_exit, entry_keypair):
    from exit_door import generate_key_pair
    other = generate_key_pair()
    arrival = create_arrival_marker(signed_exit, DESTINATION)
    signed = sign_arrival_marker(arrival, entry_keypair.private_key, entry_keypair.public_key)
    with pytest.raises(ValueError, match="Authority mismatch"):
        create_revocation_marker(signed, "fraud", other.private_key, other.public_key)


def test_is_revoked(signed_exit, entry_keypair):
    arrival = create_arrival_marker(signed_exit, DESTINATION)
    signed = sign_arrival_marker(arrival, entry_keypair.private_key, entry_keypair.public_key)
    revocation = create_revocation_marker(
        signed, "test", entry_keypair.private_key, entry_keypair.public_key
    )
    assert is_revoked(signed.id, [revocation]) is True
    assert is_revoked("urn:entry:other", [revocation]) is False


def test_verify_revocation_missing_proof(signed_exit, entry_keypair):
    from entry_door.revocation import RevocationMarker
    marker = RevocationMarker(arrival_ref="x", subject="y", authority="z", reason="r", timestamp="t")
    result = verify_revocation_marker(marker)
    assert result.valid is False
    assert "Missing proof" in result.errors
