"""Tests for transfer.py."""

from entry_door import (
    create_arrival_marker,
    sign_arrival_marker,
    verify_transfer,
)
from tests.conftest import DESTINATION


def test_verify_transfer_valid(signed_exit, entry_keypair):
    arrival = create_arrival_marker(signed_exit, DESTINATION)
    signed = sign_arrival_marker(arrival, entry_keypair.private_key, entry_keypair.public_key)
    record = verify_transfer(signed_exit, signed)
    assert record.verified is True
    assert record.errors == []
    assert record.transfer_time >= 0


def test_verify_transfer_unsigned_arrival(signed_exit):
    arrival = create_arrival_marker(signed_exit, DESTINATION)
    record = verify_transfer(signed_exit, arrival)
    assert record.verified is False
    assert any("ARRIVAL" in e for e in record.errors)


def test_verify_transfer_continuity_failure(signed_exit, entry_keypair):
    arrival = create_arrival_marker(signed_exit, DESTINATION)
    signed = sign_arrival_marker(arrival, entry_keypair.private_key, entry_keypair.public_key)
    tampered = signed.model_copy(update={"subject": "did:key:z6MkWrong"})
    # Re-sign won't match but let's test continuity errors
    record = verify_transfer(signed_exit, tampered)
    assert record.verified is False
