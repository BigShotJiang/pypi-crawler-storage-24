"""Cross-language test vectors: verify Python matches TypeScript golden output."""

import json
from pathlib import Path

import pytest

from entry_door.arrival import canonicalize, compute_arrival_id
from entry_door.sign import verify_arrival_marker
from entry_door.models import ArrivalMarker

VECTORS = json.loads(
    (Path(__file__).parent / "test-vectors.json").read_text()
)


class TestCanonicalization:
    @pytest.mark.parametrize(
        "vec", VECTORS["canonicalization"], ids=lambda v: v["description"]
    )
    def test_canonicalize(self, vec):
        assert canonicalize(vec["input"]) == vec["expected"]


class TestArrivalMarkerHashing:
    @pytest.mark.parametrize("alg", ["ed25519", "p256"])
    def test_content_hash(self, alg):
        data = VECTORS["arrivalMarkers"][alg]
        assert compute_arrival_id(data["unsigned"]) == data["contentHash"]

    @pytest.mark.parametrize("alg", ["ed25519", "p256"])
    def test_canonicalized_form(self, alg):
        data = VECTORS["arrivalMarkers"][alg]
        assert canonicalize(data["unsigned"]) == data["canonicalized"]


class TestSignatureVerification:
    def test_ed25519_signed_marker_verifies(self):
        data = VECTORS["arrivalMarkers"]["ed25519"]
        marker = ArrivalMarker.model_validate(data["signed"])
        result = verify_arrival_marker(marker)
        assert result.valid, f"Verification failed: {result.errors}"
        assert result.errors == []

    def test_p256_signed_marker_verifies(self):
        data = VECTORS["arrivalMarkers"]["p256"]
        marker = ArrivalMarker.model_validate(data["signed"])
        result = verify_arrival_marker(marker)
        assert result.valid, f"Verification failed: {result.errors}"
        assert result.errors == []
