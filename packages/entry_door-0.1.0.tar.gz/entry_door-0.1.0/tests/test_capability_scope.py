"""Tests for capability_scope.py."""

from entry_door import (
    CapabilityScope,
    create_restricted_scope,
    merge_scopes,
    scope_from_exit_marker,
)


def test_scope_from_exit_marker_basic(signed_exit):
    scope = scope_from_exit_marker(signed_exit)
    assert "basic-interaction" in scope.allowed
    assert scope.denied == []


def test_create_restricted_scope():
    scope = create_restricted_scope(["read"], ["write"], "2025-01-01T00:00:00Z")
    assert scope.allowed == ["read"]
    assert scope.denied == ["write"]
    assert scope.expires == "2025-01-01T00:00:00Z"


def test_create_restricted_scope_no_expires():
    scope = create_restricted_scope(["a"], ["b"])
    assert scope.expires is None


def test_merge_scopes_denied_wins():
    a = CapabilityScope(allowed=["read", "write"], denied=[])
    b = CapabilityScope(allowed=["execute"], denied=["write"])
    merged = merge_scopes(a, b)
    assert "write" not in merged.allowed
    assert "write" in merged.denied
    assert "read" in merged.allowed
    assert "execute" in merged.allowed


def test_merge_scopes_earliest_expiry():
    a = CapabilityScope(allowed=["a"], denied=[], expires="2025-06-01T00:00:00Z")
    b = CapabilityScope(allowed=["b"], denied=[], expires="2025-01-01T00:00:00Z")
    merged = merge_scopes(a, b)
    assert merged.expires == "2025-01-01T00:00:00Z"


def test_merge_scopes_one_expiry():
    a = CapabilityScope(allowed=["a"], denied=[], expires="2025-06-01T00:00:00Z")
    b = CapabilityScope(allowed=["b"], denied=[])
    merged = merge_scopes(a, b)
    assert merged.expires == "2025-06-01T00:00:00Z"


def test_merge_scopes_deduplicates():
    a = CapabilityScope(allowed=["read", "write"], denied=["admin"])
    b = CapabilityScope(allowed=["read", "execute"], denied=["admin"])
    merged = merge_scopes(a, b)
    assert merged.allowed.count("execute") == 1
    assert merged.denied.count("admin") == 1
