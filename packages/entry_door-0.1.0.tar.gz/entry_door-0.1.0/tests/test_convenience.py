"""Tests for convenience.py."""

import warnings

from entry_door import quick_entry, quick_entry_p256
from tests.conftest import DESTINATION


def test_quick_entry(exit_json):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result = quick_entry(exit_json, DESTINATION)
    assert result.arrival_marker.proof is not None
    assert result.arrival_marker.proof.type == "Ed25519Signature2020"
    assert result.continuity.valid is True


def test_quick_entry_p256(exit_json):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result = quick_entry_p256(exit_json, DESTINATION)
    assert result.arrival_marker.proof is not None
    assert result.arrival_marker.proof.type == "EcdsaP256Signature2019"
    assert result.continuity.valid is True


def test_quick_entry_emits_warning(exit_json):
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        quick_entry(exit_json, DESTINATION)
    assert any("ephemeral" in str(warning.message) for warning in w)
