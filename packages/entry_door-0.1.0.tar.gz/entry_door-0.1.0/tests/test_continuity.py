"""Tests for continuity.py."""

from entry_door import (
    CreateArrivalOpts,
    create_arrival_marker,
    verify_continuity,
)
from tests.conftest import DESTINATION


def test_continuity_valid(signed_exit):
    marker = create_arrival_marker(signed_exit, DESTINATION)
    result = verify_continuity(signed_exit, marker)
    assert result.valid is True
    assert result.errors == []


def test_continuity_wrong_departure_ref(signed_exit):
    marker = create_arrival_marker(signed_exit, DESTINATION)
    tampered = marker.model_copy(update={"departure_ref": "urn:exit:wrong"})
    result = verify_continuity(signed_exit, tampered)
    assert result.valid is False
    assert any("Departure reference mismatch" in e for e in result.errors)


def test_continuity_wrong_subject(signed_exit):
    marker = create_arrival_marker(signed_exit, DESTINATION)
    tampered = marker.model_copy(update={"subject": "did:key:z6MkWrong"})
    result = verify_continuity(signed_exit, tampered)
    assert result.valid is False
    assert any("Subject mismatch" in e for e in result.errors)


def test_continuity_wrong_origin(signed_exit):
    marker = create_arrival_marker(signed_exit, DESTINATION)
    tampered = marker.model_copy(update={"departure_origin": "https://wrong.example.com"})
    result = verify_continuity(signed_exit, tampered)
    assert result.valid is False
    assert any("Origin mismatch" in e for e in result.errors)


def test_continuity_temporal_violation(signed_exit):
    opts = CreateArrivalOpts(timestamp="2000-01-01T00:00:00Z")
    marker = create_arrival_marker(signed_exit, DESTINATION, opts)
    result = verify_continuity(signed_exit, marker)
    assert result.valid is False
    assert any("Temporal violation" in e for e in result.errors)
