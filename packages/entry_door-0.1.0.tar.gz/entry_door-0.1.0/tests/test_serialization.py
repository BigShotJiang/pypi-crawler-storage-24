"""Tests for camelCase JSON serialization of key models."""

from entry_door import AdmissionRecord, AdmitResult, PolicyJSON


def test_admission_record_camel_case_serialization():
    record = AdmissionRecord(
        id="admission-123",
        exit_marker_id="exit-456",
        arrival_marker_id="arrival-789",
        subject_did="did:key:z123",
        origin_did="did:key:z456",
        policy_applied="cautious",
        policy_version="abc123",
        admitted=True,
        admission_type="standard",
        counter_signed=True,
        reason_codes=["ok"],
        conditions=[],
        timestamp="2026-01-01T00:00:00Z",
        confirmation_level="mutual",
        counter_sign_meaning="receipt_only",
    )
    d = record.model_dump(by_alias=True)
    assert "exitMarkerId" in d
    assert "arrivalMarkerId" in d
    assert "subjectDid" in d
    assert "originDid" in d
    assert "policyApplied" in d
    assert "policyVersion" in d
    assert "admissionType" in d
    assert "counterSigned" in d
    assert "reasonCodes" in d
    assert "confirmationLevel" in d
    assert "counterSignMeaning" in d

    # Snake case should NOT appear in aliased output
    assert "exit_marker_id" not in d
    assert "arrival_marker_id" not in d
    assert "subject_did" not in d

    # Snake case attribute access still works
    assert record.exit_marker_id == "exit-456"
    assert record.arrival_marker_id == "arrival-789"


def test_admission_record_from_camel_case():
    record = AdmissionRecord.model_validate({
        "id": "admission-123",
        "exitMarkerId": "exit-456",
        "arrivalMarkerId": "arrival-789",
        "subjectDid": "did:key:z123",
        "originDid": None,
        "policyApplied": "cautious",
        "policyVersion": "v1",
        "admitted": True,
        "admissionType": "standard",
        "counterSigned": False,
        "reasonCodes": [],
        "conditions": [],
        "timestamp": "2026-01-01T00:00:00Z",
    })
    assert record.exit_marker_id == "exit-456"
    assert record.policy_applied == "cautious"


def test_admit_result_camel_case():
    record = AdmissionRecord(
        id="a1",
        arrival_marker_id="arr-1",
        policy_applied="test",
        policy_version="v1",
        admitted=True,
        admission_type="standard",
        counter_signed=False,
        reason_codes=[],
        conditions=[],
        timestamp="2026-01-01T00:00:00Z",
    )
    result = AdmitResult(
        counter_signed_exit_marker=None,
        arrival_marker=None,
        admission=record,
    )
    d = result.model_dump(by_alias=True)
    assert "counterSignedExitMarker" in d
    assert "arrivalMarker" in d
    assert "admission" in d
    # Nested record should also be camelCase
    assert "arrivalMarkerId" in d["admission"]


def test_policy_json_camel_case():
    pj = PolicyJSON(
        name="test",
        conflict_strategy="deny-overrides",
        rules=[],
        custom_rules_omitted=[],
        default_decision="deny",
    )
    d = pj.model_dump(by_alias=True)
    assert "conflictStrategy" in d
    assert "customRulesOmitted" in d
    assert "defaultDecision" in d
    assert "conflict_strategy" not in d
