"""Tests for models.py."""

from entry_door.models import (
    ENTRY_CONTEXT_V1,
    ArrivalMarker,
    ArrivalProof,
    CapabilityScope,
    ContinuityResult,
    ProbationInfo,
    VerificationResult,
)


def test_entry_context_v1():
    assert ENTRY_CONTEXT_V1 == "https://cellar-door.dev/entry/v1"


def test_verification_result_defaults():
    vr = VerificationResult(valid=True)
    assert vr.valid is True
    assert vr.errors == []


def test_verification_result_with_errors():
    vr = VerificationResult(valid=False, errors=["bad"])
    assert not vr.valid
    assert vr.errors == ["bad"]


def test_arrival_proof_aliases():
    p = ArrivalProof(
        type="Ed25519Signature2020",
        created="2024-01-01T00:00:00Z",
        verification_method="did:key:z6Mk...",
        proof_value="abc123",
    )
    assert p.verification_method == "did:key:z6Mk..."
    d = p.model_dump(by_alias=True)
    assert d["verificationMethod"] == "did:key:z6Mk..."
    assert d["proofValue"] == "abc123"


def test_probation_info():
    pi = ProbationInfo(duration=3600000, restrictions=["read-only"], review_required=True, started_at="2024-01-01T00:00:00Z")
    assert pi.review_required is True
    d = pi.model_dump(by_alias=True)
    assert d["reviewRequired"] is True
    assert d["startedAt"] == "2024-01-01T00:00:00Z"


def test_capability_scope():
    cs = CapabilityScope(allowed=["a"], denied=["b"], expires="2025-01-01T00:00:00Z")
    assert cs.expires is not None


def test_continuity_result():
    cr = ContinuityResult(valid=True)
    assert cr.errors == []


def test_arrival_marker_round_trip():
    m = ArrivalMarker(
        id="urn:entry:abc",
        departure_ref="urn:exit:xyz",
        departure_origin="https://origin.example.com",
        destination="https://dest.example.com",
        subject="did:key:z6MkTest",
        timestamp="2024-01-01T00:00:00Z",
        admission_type="automatic",
        verification_result=VerificationResult(valid=True),
    )
    d = m.model_dump(by_alias=True)
    assert d["@context"] == ENTRY_CONTEXT_V1
    assert d["departureRef"] == "urn:exit:xyz"
    assert d["admissionType"] == "automatic"
    assert d["verificationResult"]["valid"] is True
