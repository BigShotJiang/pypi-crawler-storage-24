"""Tests for AdmissionEventEmitter."""

import pytest
from entry_door import AdmissionEventEmitter


class TestAdmissionEventEmitter:
    def test_on_and_emit(self):
        emitter = AdmissionEventEmitter()
        events = []
        emitter.on("agent:admitted", lambda e: events.append(e))
        emitter.emit("agent:admitted", {"id": "123"})
        assert len(events) == 1
        assert events[0].type == "agent:admitted"
        assert events[0].data["id"] == "123"

    def test_on_any(self):
        emitter = AdmissionEventEmitter()
        events = []
        emitter.on_any(lambda e: events.append(e))
        emitter.emit("agent:admitted")
        emitter.emit("agent:rejected")
        assert len(events) == 2

    def test_off(self):
        emitter = AdmissionEventEmitter()
        events = []
        handler = lambda e: events.append(e)
        emitter.on("agent:admitted", handler)
        emitter.off("agent:admitted", handler)
        emitter.emit("agent:admitted")
        assert len(events) == 0

    def test_off_any(self):
        emitter = AdmissionEventEmitter()
        events = []
        handler = lambda e: events.append(e)
        emitter.on_any(handler)
        emitter.off_any(handler)
        emitter.emit("agent:admitted")
        assert len(events) == 0

    def test_error_isolation(self):
        errors = []
        emitter = AdmissionEventEmitter(on_error=lambda err, ev: errors.append(err))
        emitter.on("agent:admitted", lambda e: (_ for _ in ()).throw(ValueError("boom")))
        # The bad handler above won't actually throw with that lambda, let's use a proper one
        emitter = AdmissionEventEmitter(on_error=lambda err, ev: errors.append(err))
        def bad_handler(e):
            raise ValueError("boom")
        events = []
        def good_handler(e):
            events.append(e)
        emitter.on("agent:admitted", bad_handler)
        emitter.on("agent:admitted", good_handler)
        emitter.emit("agent:admitted")
        assert len(errors) == 1
        assert len(events) == 1

    def test_remove_all_listeners(self):
        emitter = AdmissionEventEmitter()
        events = []
        emitter.on("agent:admitted", lambda e: events.append(e))
        emitter.on_any(lambda e: events.append(e))
        emitter.remove_all_listeners()
        emitter.emit("agent:admitted")
        assert len(events) == 0

    def test_listener_count(self):
        emitter = AdmissionEventEmitter()
        assert emitter.listener_count("agent:admitted") == 0
        emitter.on("agent:admitted", lambda e: None)
        emitter.on("agent:admitted", lambda e: None)
        assert emitter.listener_count("agent:admitted") == 2

    def test_timestamp_present(self):
        emitter = AdmissionEventEmitter()
        events = []
        emitter.on("agent:minted", lambda e: events.append(e))
        emitter.emit("agent:minted")
        assert events[0].timestamp

    def test_chaining(self):
        emitter = AdmissionEventEmitter()
        result = emitter.on("agent:admitted", lambda e: None)
        assert result is emitter

    def test_multiple_event_types(self):
        emitter = AdmissionEventEmitter()
        admitted = []
        rejected = []
        emitter.on("agent:admitted", lambda e: admitted.append(e))
        emitter.on("agent:rejected", lambda e: rejected.append(e))
        emitter.emit("agent:admitted")
        emitter.emit("agent:rejected")
        emitter.emit("agent:admitted")
        assert len(admitted) == 2
        assert len(rejected) == 1
