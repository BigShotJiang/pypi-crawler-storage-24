"""Tests for conflict resolution strategies."""

import pytest
from entry_door import RuleResult, resolve_conflict


def _result(name: str, decision: str, reason: str = "test", conditions: list[str] | None = None) -> RuleResult:
    return RuleResult(name=name, decision=decision, reason=reason, conditions=conditions or [])


class TestResolveConflict:
    def test_deny_overrides_single_deny(self):
        results = [_result("a", "admit"), _result("b", "deny")]
        resolved = resolve_conflict(results, "deny-overrides")
        assert not resolved.admitted

    def test_deny_overrides_all_admit(self):
        results = [_result("a", "admit"), _result("b", "admit")]
        resolved = resolve_conflict(results, "deny-overrides")
        assert resolved.admitted

    def test_first_match_takes_first_decisive(self):
        results = [_result("a", "abstain"), _result("b", "deny"), _result("c", "admit")]
        resolved = resolve_conflict(results, "first-match")
        assert not resolved.admitted
        assert "[b]" in resolved.reasons[0]

    def test_first_match_admit(self):
        results = [_result("a", "admit"), _result("b", "deny")]
        resolved = resolve_conflict(results, "first-match")
        assert resolved.admitted

    def test_permit_overrides_one_admit(self):
        results = [_result("a", "deny"), _result("b", "admit")]
        resolved = resolve_conflict(results, "permit-overrides")
        assert resolved.admitted

    def test_permit_overrides_all_deny(self):
        results = [_result("a", "deny"), _result("b", "deny")]
        resolved = resolve_conflict(results, "permit-overrides")
        assert not resolved.admitted

    def test_all_abstain_default_deny(self):
        results = [_result("a", "abstain")]
        resolved = resolve_conflict(results, "deny-overrides")
        assert not resolved.admitted
        assert "default deny" in resolved.reasons[0]

    def test_all_abstain_default_admit(self):
        results = [_result("a", "abstain")]
        resolved = resolve_conflict(results, "deny-overrides", default_decision="admit")
        assert resolved.admitted

    def test_empty_results_default_deny(self):
        resolved = resolve_conflict([], "deny-overrides")
        assert not resolved.admitted

    def test_conditions_collected(self):
        results = [
            _result("a", "admit", conditions=["quarantine"]),
            _result("b", "admit", conditions=["probation"]),
        ]
        resolved = resolve_conflict(results, "deny-overrides")
        assert "quarantine" in resolved.conditions
        assert "probation" in resolved.conditions

    def test_first_match_uses_first_conditions(self):
        results = [
            _result("a", "admit", conditions=["cond-a"]),
            _result("b", "admit", conditions=["cond-b"]),
        ]
        resolved = resolve_conflict(results, "first-match")
        assert resolved.conditions == ["cond-a"]

    def test_rule_results_preserved(self):
        results = [_result("a", "admit"), _result("b", "deny")]
        resolved = resolve_conflict(results, "deny-overrides")
        assert len(resolved.rule_results) == 2
