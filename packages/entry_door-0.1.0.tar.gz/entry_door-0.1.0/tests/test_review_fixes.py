"""Tests for dev review panel fixes (PE-01 through DP-02)."""

import pytest
from datetime import datetime, timezone
from exit_door import quick_exit, generate_key_pair

from entry_door import (
    admit,
    AdmitOpts,
    AdmitResult,
    AdmissionRecord,
    SqliteClaimStore,
    create_policy,
    PolicyBuilder,
)
from entry_door.policy_builder import (
    CAUTIOUS,
    LOCKDOWN,
    OPEN_DOOR_V2,
    PERMISSIVE,
    REQUIRE_MUTUAL,
    _PresetProxy,
)
from entry_door.rules.custom_rule import CustomRuleResult


@pytest.fixture
def signed_exit():
    return quick_exit("https://origin.example.com").marker


@pytest.fixture
def platform_kp():
    kp = generate_key_pair()
    return {"private_key": kp.private_key, "public_key": kp.public_key}


@pytest.fixture
def sqlite_store():
    s = SqliteClaimStore(":memory:", retention_period=1)  # 1ms retention
    s.init()
    yield s
    s.close()


# ─── PE-04: Preset policies are independent ──────────────────────────────────

class TestPresetIndependence:
    def test_presets_are_proxies(self):
        assert isinstance(CAUTIOUS, _PresetProxy)

    def test_mutating_preset_does_not_affect_another(self):
        p1 = CAUTIOUS()  # get a fresh copy via call
        p2 = CAUTIOUS()  # another fresh copy
        p1.name = "mutated"
        assert p2.name == "cautious"

    def test_attribute_access_returns_fresh(self):
        name1 = CAUTIOUS.name
        # Mutate via a copy
        copy = CAUTIOUS()
        copy.name = "changed"
        name2 = CAUTIOUS.name
        assert name1 == name2 == "cautious"


# ─── PE-03: default_decision preserved on JSON round-trip ────────────────────

class TestDefaultDecisionRoundTrip:
    def test_default_decision_in_json(self):
        policy = create_policy("test").default_decision("admit").build()
        json_data = policy.to_json()
        assert json_data.default_decision == "admit"

    def test_default_decision_roundtrip(self):
        policy = create_policy("test").default_decision("admit").build()
        json_data = policy.to_json()
        rebuilt = PolicyBuilder.from_json(json_data).build()
        assert rebuilt.default_decision == "admit"
        result = rebuilt.evaluate(None, {"is_minting": True})
        assert result.admitted

    def test_default_deny_roundtrip(self):
        policy = create_policy("test").default_decision("deny").build()
        json_data = policy.to_json()
        rebuilt = PolicyBuilder.from_json(json_data).build()
        assert rebuilt.default_decision == "deny"


# ─── RP-02: admit() returns typed results ────────────────────────────────────

class TestAdmitResultTypes:
    def test_admit_returns_admit_result(self, signed_exit, platform_kp):
        result = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=OPEN_DOOR_V2,
        ))
        assert isinstance(result, AdmitResult)

    def test_admission_is_admission_record(self, signed_exit, platform_kp):
        result = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=OPEN_DOOR_V2,
        ))
        assert isinstance(result.admission, AdmissionRecord)
        assert isinstance(result["admission"], AdmissionRecord)

    def test_admission_record_dict_access(self, signed_exit, platform_kp):
        result = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=OPEN_DOOR_V2,
        ))
        rec = result["admission"]
        assert rec["admitted"] is True
        assert rec["policy_applied"] == "open-door"

    def test_rejected_result_typed(self, signed_exit, platform_kp):
        result = admit(signed_exit, AdmitOpts(
            platform_identity=platform_kp,
            policy=LOCKDOWN,
        ))
        assert isinstance(result, AdmitResult)
        assert isinstance(result.admission, AdmissionRecord)
        assert result.admission.admitted is False


# ─── RP-01: AdmitOpts validation ─────────────────────────────────────────────

class TestAdmitOptsValidation:
    def test_valid_platform_identity(self, platform_kp):
        opts = AdmitOpts(platform_identity=platform_kp)
        assert opts.platform_identity is not None

    def test_missing_key_in_platform_identity(self):
        with pytest.raises(ValueError, match="private_key"):
            AdmitOpts(platform_identity={"public_key": b"key"})

    def test_wrong_type_in_platform_identity(self):
        with pytest.raises((TypeError, Exception)):
            AdmitOpts(platform_identity={"private_key": 12345, "public_key": b"key"})

    def test_none_platform_identity_ok(self):
        opts = AdmitOpts()
        assert opts.platform_identity is None


# ─── DP-01: purge_expired ────────────────────────────────────────────────────

class TestPurgeExpired:
    def test_purge_expired_deletes_old_records(self):
        store = SqliteClaimStore(":memory:", retention_period=1)
        store.init()
        # Insert a record with already-expired retention
        rec = {
            "id": "adm-1",
            "exit_marker_id": "exit-1",
            "arrival_marker_id": "arr-1",
            "subject_did": "did:test:alice",
            "policy_applied": "test",
            "admitted": True,
            "admission_type": "standard",
            "timestamp": "2020-01-01T00:00:00Z",
            "reason_codes": [],
            "conditions": [],
        }
        store.put_admission(rec)
        # retention_expires should be ~2020 + 1ms, definitely expired
        assert store.get_admission("adm-1") is not None
        purged = store.purge_expired()
        assert purged == 1
        assert store.get_admission("adm-1") is None
        store.close()

    def test_purge_does_not_delete_unexpired(self):
        store = SqliteClaimStore(":memory:")
        store.init()
        rec = {
            "id": "adm-2",
            "exit_marker_id": "exit-2",
            "arrival_marker_id": "arr-2",
            "subject_did": "did:test:bob",
            "policy_applied": "test",
            "admitted": True,
            "admission_type": "standard",
            "timestamp": "2020-01-01T00:00:00Z",
            "reason_codes": [],
            "conditions": [],
            "retention_expires": "2099-01-01T00:00:00Z",
        }
        store.put_admission(rec)
        purged = store.purge_expired()
        assert purged == 0
        assert store.get_admission("adm-2") is not None
        store.close()


# ─── DP-02: Atomic erasure ───────────────────────────────────────────────────

class TestAtomicErasure:
    def test_erase_subject_is_atomic(self):
        store = SqliteClaimStore(":memory:")
        store.init()
        store.claim("exit-1", "arr-1", "did:test:alice")
        store.put_admission({
            "id": "adm-1",
            "exit_marker_id": "exit-1",
            "arrival_marker_id": "arr-1",
            "subject_did": "did:test:alice",
            "policy_applied": "test",
            "admitted": True,
            "admission_type": "standard",
            "timestamp": "2024-01-01T00:00:00Z",
            "reason_codes": [],
            "conditions": [],
        })
        result = store.erase_subject("did:test:alice")
        assert result["claims"] == 1
        assert result["admissions"] == 1
        assert not store.is_claimed("exit-1")
        assert store.get_admission("adm-1") is None
        store.close()


# ─── PE-02: Custom rules can abstain ─────────────────────────────────────────

class TestCustomRuleAbstain:
    def test_abstain_result(self):
        r = CustomRuleResult()
        assert r.admitted is None
        assert r.abstained is True

    def test_custom_rule_abstain_in_policy(self):
        policy = (
            create_policy("abstain-test")
            .custom("maybe", lambda m, c: CustomRuleResult())  # abstain
            .default_decision("admit")
            .build()
        )
        result = policy.evaluate(None, {"is_minting": True})
        # With no decisive rules and default=admit, should admit
        assert result.admitted

    def test_custom_rule_abstain_does_not_force_decision(self):
        policy = (
            create_policy("abstain-test")
            .custom("maybe", lambda m, c: CustomRuleResult())  # abstain
            .default_decision("deny")
            .build()
        )
        result = policy.evaluate(None, {"is_minting": True})
        assert not result.admitted
