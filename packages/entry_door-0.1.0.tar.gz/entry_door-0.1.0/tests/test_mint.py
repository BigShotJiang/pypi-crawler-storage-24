"""Tests for mint_agent() and bulk_mint()."""

import pytest
from exit_door import generate_key_pair

from entry_door import mint_agent, bulk_mint, MintOpts, BulkMintAgent, InMemoryClaimStore
from entry_door.policy_builder import PERMISSIVE, LOCKDOWN, create_policy
from entry_door import AdmissionEventEmitter


@pytest.fixture
def platform_kp():
    kp = generate_key_pair()
    return {"private_key": kp.private_key, "public_key": kp.public_key}


class TestMintAgent:
    def test_basic_mint(self, platform_kp):
        result = mint_agent(MintOpts(
            subject_did="did:test:agent",
            platform_identity=platform_kp,
            policy=PERMISSIVE,
        ))
        assert result["admission"]["admitted"] is True
        assert result["subject_did"] == "did:test:agent"
        assert result["arrival_marker"].subject == "did:test:agent"

    def test_mint_rejected_by_policy(self, platform_kp):
        result = mint_agent(MintOpts(
            subject_did="did:test:agent",
            platform_identity=platform_kp,
            policy=LOCKDOWN,
        ))
        assert result["admission"]["admitted"] is False

    def test_mint_with_justification(self, platform_kp):
        policy = create_policy("mint-just").allow_minting(require_justification=True).build()
        result = mint_agent(MintOpts(
            subject_did="did:test:agent",
            platform_identity=platform_kp,
            policy=policy,
            justification="needed",
        ))
        assert result["admission"]["admitted"] is True

    def test_mint_emits_event(self, platform_kp):
        events = []
        emitter = AdmissionEventEmitter()
        emitter.on("agent:minted", lambda e: events.append(e))

        mint_agent(MintOpts(
            subject_did="did:test:agent",
            platform_identity=platform_kp,
            policy=PERMISSIVE,
            emitter=emitter,
        ))
        assert len(events) == 1


class TestBulkMint:
    def test_bulk_mint_multiple(self, platform_kp):
        agents = [
            BulkMintAgent(subject_did="did:test:a1"),
            BulkMintAgent(subject_did="did:test:a2"),
            BulkMintAgent(subject_did="did:test:a3"),
        ]
        result = bulk_mint(agents, platform_identity=platform_kp, policy=PERMISSIVE)
        assert result["succeeded"] == 3
        assert result["failed"] == 0
        assert len(result["results"]) == 3

    def test_bulk_mint_with_store(self, platform_kp):
        store = InMemoryClaimStore()
        agents = [
            BulkMintAgent(subject_did="did:test:a1"),
            BulkMintAgent(subject_did="did:test:a2"),
        ]
        result = bulk_mint(agents, platform_identity=platform_kp, policy=PERMISSIVE, store=store)
        assert result["succeeded"] == 2
        assert store.size == 2

    def test_bulk_mint_migration_type(self, platform_kp):
        agents = [BulkMintAgent(subject_did="did:test:a1")]
        result = bulk_mint(agents, platform_identity=platform_kp, policy=PERMISSIVE)
        assert result["results"][0]["admission"]["admission_type"] == "migration"

    def test_bulk_mint_partial_failure(self, platform_kp):
        """If policy rejects some, they count as failed."""
        agents = [
            BulkMintAgent(subject_did="did:test:a1"),
        ]
        result = bulk_mint(agents, platform_identity=platform_kp, policy=LOCKDOWN)
        assert result["succeeded"] == 0
        assert result["failed"] == 1
