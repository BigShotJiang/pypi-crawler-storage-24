"""Tests for validation.py."""

from entry_door import (
    ENTRY_CONTEXT_V1,
    create_arrival_marker,
    validate_arrival_marker,
)
from tests.conftest import DESTINATION


def _make_valid_dict(signed_exit):
    marker = create_arrival_marker(signed_exit, DESTINATION)
    return marker.model_dump(by_alias=True, exclude_none=True)


def test_validate_valid_marker(signed_exit):
    d = _make_valid_dict(signed_exit)
    result = validate_arrival_marker(d)
    assert result.valid is True, result.errors


def test_validate_null():
    result = validate_arrival_marker(None)
    assert result.valid is False
    assert "non-null object" in result.errors[0]


def test_validate_wrong_context(signed_exit):
    d = _make_valid_dict(signed_exit)
    d["@context"] = "wrong"
    result = validate_arrival_marker(d)
    assert not result.valid
    assert any("@context" in e for e in result.errors)


def test_validate_bad_id(signed_exit):
    d = _make_valid_dict(signed_exit)
    d["id"] = "bad-id"
    result = validate_arrival_marker(d)
    assert not result.valid
    assert any("urn:entry:" in e for e in result.errors)


def test_validate_missing_subject(signed_exit):
    d = _make_valid_dict(signed_exit)
    del d["subject"]
    result = validate_arrival_marker(d)
    assert not result.valid
    assert any("subject" in e.lower() for e in result.errors)


def test_validate_bad_did_format(signed_exit):
    d = _make_valid_dict(signed_exit)
    d["subject"] = "not-a-did"
    result = validate_arrival_marker(d)
    assert not result.valid
    assert any("DID format" in e for e in result.errors)


def test_validate_bad_timestamp(signed_exit):
    d = _make_valid_dict(signed_exit)
    d["timestamp"] = "not-a-timestamp"
    result = validate_arrival_marker(d)
    assert not result.valid
    assert any("timestamp" in e.lower() for e in result.errors)


def test_validate_bad_admission_type(signed_exit):
    d = _make_valid_dict(signed_exit)
    d["admissionType"] = "invalid"
    result = validate_arrival_marker(d)
    assert not result.valid


def test_validate_missing_verification_result(signed_exit):
    d = _make_valid_dict(signed_exit)
    del d["verificationResult"]
    result = validate_arrival_marker(d)
    assert not result.valid


def test_validate_control_chars(signed_exit):
    d = _make_valid_dict(signed_exit)
    d["subject"] = "did:key:z6Mk\x00bad"
    result = validate_arrival_marker(d)
    assert not result.valid
    assert any("control characters" in e for e in result.errors)


def test_validate_oversized(signed_exit):
    d = _make_valid_dict(signed_exit)
    d["destination"] = "x" * 10000
    result = validate_arrival_marker(d)
    assert not result.valid
    assert any("maximum size" in e for e in result.errors)


def test_validate_conditions_must_be_strings(signed_exit):
    d = _make_valid_dict(signed_exit)
    d["conditions"] = [123]
    result = validate_arrival_marker(d)
    assert not result.valid
    assert any("conditions" in e for e in result.errors)
