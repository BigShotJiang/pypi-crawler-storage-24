"""Tests for PolicyBuilder and preset policies."""

import pytest
from exit_door import quick_exit

from entry_door import (
    CAUTIOUS,
    LOCKDOWN,
    OPEN_DOOR_V2,
    PERMISSIVE,
    QUARANTINE_UNKNOWN,
    REQUIRE_MUTUAL,
    REQUIRE_MUTUAL_WITH_ONRAMP,
    PolicyBuilder,
    create_policy,
)
from entry_door.rules.custom_rule import CustomRuleResult


def _marker():
    return quick_exit("https://origin.example.com").marker


class TestPolicyBuilder:
    def test_empty_policy_denies(self):
        policy = create_policy("empty").build()
        result = policy.evaluate(_marker())
        assert not result.admitted

    def test_chaining(self):
        policy = (
            create_policy("chained")
            .require_verified_departure()
            .on_self_only("probation", duration="7d")
            .allow_minting(require_justification=True)
            .build()
        )
        assert len(policy.rules) == 3

    def test_conflict_resolution_setting(self):
        policy = create_policy("test").conflict_resolution("permit-overrides").build()
        assert policy.conflict_strategy == "permit-overrides"

    def test_default_decision_setting(self):
        policy = create_policy("test").default_decision("admit").build()
        assert policy.default_decision == "admit"
        result = policy.evaluate(_marker())
        assert result.admitted

    def test_dry_run(self):
        policy = create_policy("test").require_verified_departure().build()
        trace = policy.dry_run(_marker())
        assert trace.policy_name == "test"
        assert len(trace.rules) == 1
        assert trace.decision is not None

    def test_to_json_and_from_json(self):
        policy = (
            create_policy("round-trip")
            .require_verified_departure()
            .on_self_only("probation", duration="7d")
            .allow_minting(require_justification=True)
            .build()
        )
        json_data = policy.to_json()
        assert json_data.name == "round-trip"
        assert len(json_data.rules) == 3

        rebuilt = PolicyBuilder.from_json(json_data).build()
        assert rebuilt.name == "round-trip"
        assert len(rebuilt.rules) == 3

    def test_custom_rule_omitted_from_json(self):
        policy = (
            create_policy("with-custom")
            .custom("my-fn", lambda m, c: CustomRuleResult(admitted=True))
            .build()
        )
        json_data = policy.to_json()
        assert "my-fn" in json_data.custom_rules_omitted

    def test_minting_context(self):
        policy = create_policy("minting-test").allow_minting().build()
        result = policy.evaluate(None, {"is_minting": True})
        assert result.admitted

    def test_block_origins(self):
        policy = create_policy("origin-test").block_origins(["https://origin.example.com"], reason="bad").build()
        result = policy.evaluate(_marker())
        assert not result.admitted

    def test_allow_origins(self):
        policy = create_policy("origin-test").allow_origins(["https://origin.example.com"]).build()
        result = policy.evaluate(_marker())
        assert result.admitted


# ─── Preset Policies ──────────────────────────────────────────────────────────

class TestPresets:
    """Test each preset policy against a standard self-only marker."""

    def test_require_mutual_denies_self_only(self):
        result = REQUIRE_MUTUAL.evaluate(_marker())
        assert not result.admitted

    def test_require_mutual_with_onramp_denies_self_only(self):
        result = REQUIRE_MUTUAL_WITH_ONRAMP.evaluate(_marker())
        assert not result.admitted

    def test_require_mutual_with_onramp_allows_minting_with_justification(self):
        result = REQUIRE_MUTUAL_WITH_ONRAMP.evaluate(None, {"is_minting": True, "minting_justification": "new"})
        assert result.admitted
        assert any("probation" in c for c in result.conditions)

    def test_cautious_admits_signed_self_only_with_probation(self):
        result = CAUTIOUS.evaluate(_marker())
        assert result.admitted
        assert any("probation" in c for c in result.conditions)

    def test_cautious_allows_minting_with_justification(self):
        result = CAUTIOUS.evaluate(None, {"is_minting": True, "minting_justification": "reason"})
        assert result.admitted

    def test_cautious_denies_minting_without_justification(self):
        result = CAUTIOUS.evaluate(None, {"is_minting": True})
        assert not result.admitted

    def test_open_door_admits_anything(self):
        result = OPEN_DOOR_V2.evaluate(_marker())
        assert result.admitted

    def test_open_door_admits_minting(self):
        result = OPEN_DOOR_V2.evaluate(None, {"is_minting": True})
        assert result.admitted

    def test_quarantine_unknown_admits_signed(self):
        result = QUARANTINE_UNKNOWN.evaluate(_marker())
        assert result.admitted

    def test_permissive_admits_with_probation(self):
        result = PERMISSIVE.evaluate(_marker())
        assert result.admitted
        assert any("probation" in c for c in result.conditions)

    def test_permissive_allows_minting(self):
        result = PERMISSIVE.evaluate(None, {"is_minting": True})
        assert result.admitted

    def test_lockdown_denies_marker(self):
        result = LOCKDOWN.evaluate(_marker())
        assert not result.admitted

    def test_lockdown_denies_minting(self):
        result = LOCKDOWN.evaluate(None, {"is_minting": True})
        assert not result.admitted
