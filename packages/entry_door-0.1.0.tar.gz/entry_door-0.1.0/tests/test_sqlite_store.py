"""Tests for SqliteClaimStore."""

import pytest
from entry_door import SqliteClaimStore


@pytest.fixture
def store():
    s = SqliteClaimStore(":memory:")
    s.init()
    yield s
    s.close()


class TestInitGuard:
    def test_claim_before_init(self):
        s = SqliteClaimStore(":memory:")
        with pytest.raises(RuntimeError, match="init"):
            s.claim("x", "y")

    def test_is_claimed_before_init(self):
        s = SqliteClaimStore(":memory:")
        with pytest.raises(RuntimeError, match="init"):
            s.is_claimed("x")

    def test_put_admission_before_init(self):
        s = SqliteClaimStore(":memory:")
        with pytest.raises(RuntimeError, match="init"):
            s.put_admission({})

    def test_get_admission_before_init(self):
        s = SqliteClaimStore(":memory:")
        with pytest.raises(RuntimeError, match="init"):
            s.get_admission("x")


class TestClaimCRUD:
    def test_claim_and_is_claimed(self, store):
        assert store.claim("exit-1", "arrival-1", "did:test:alice")
        assert store.is_claimed("exit-1")
        assert not store.is_claimed("exit-2")

    def test_claim_duplicate_returns_false(self, store):
        assert store.claim("exit-1", "arrival-1")
        assert not store.claim("exit-1", "arrival-2")

    def test_get_arrival_id(self, store):
        store.claim("exit-1", "arrival-1")
        assert store.get_arrival_id("exit-1") == "arrival-1"
        assert store.get_arrival_id("exit-2") is None

    def test_revoke(self, store):
        store.claim("exit-1", "arrival-1")
        assert store.revoke("arrival-1")
        assert not store.is_claimed("exit-1")

    def test_revoke_nonexistent(self, store):
        assert not store.revoke("nonexistent")

    def test_delete_by_subject(self, store):
        store.claim("exit-1", "arrival-1", "did:test:alice")
        store.claim("exit-2", "arrival-2", "did:test:alice")
        store.claim("exit-3", "arrival-3", "did:test:bob")
        assert store.delete_by_subject("did:test:alice") == 2
        assert not store.is_claimed("exit-1")
        assert store.is_claimed("exit-3")


class TestAdmissionRecords:
    def _make_record(self, **overrides):
        base = {
            "id": "admission-test-1",
            "exit_marker_id": "exit-1",
            "arrival_marker_id": "arrival-1",
            "subject_did": "did:test:alice",
            "origin_did": "did:test:origin",
            "confirmation_level": "mutual",
            "policy_applied": "cautious",
            "policy_version": "abc123",
            "admitted": True,
            "admission_type": "standard",
            "counter_signed": True,
            "counter_sign_meaning": "receipt_only",
            "reason_codes": ["verified"],
            "conditions": [],
            "timestamp": "2024-01-01T00:00:00Z",
        }
        base.update(overrides)
        return base

    def test_put_and_get(self, store):
        rec = self._make_record()
        store.put_admission(rec)
        got = store.get_admission("admission-test-1")
        assert got is not None
        assert got["subject_did"] == "did:test:alice"
        assert got["admitted"] is True
        assert got["reason_codes"] == ["verified"]

    def test_get_nonexistent(self, store):
        assert store.get_admission("nonexistent") is None

    def test_get_admission_history(self, store):
        store.put_admission(self._make_record(id="a1", timestamp="2024-01-01T00:00:00Z"))
        store.put_admission(self._make_record(id="a2", timestamp="2024-01-02T00:00:00Z"))
        store.put_admission(self._make_record(id="a3", subject_did="did:test:bob", timestamp="2024-01-03T00:00:00Z"))
        history = store.get_admission_history("did:test:alice")
        assert len(history) == 2
        assert history[0]["id"] == "a2"  # Most recent first

    def test_erase_subject_gdpr(self, store):
        store.claim("exit-1", "arrival-1", "did:test:alice")
        store.put_admission(self._make_record())
        result = store.erase_subject("did:test:alice")
        assert result["claims"] == 1
        assert result["admissions"] == 1
        assert not store.is_claimed("exit-1")
        assert store.get_admission("admission-test-1") is None

    def test_contest_admission(self, store):
        store.put_admission(self._make_record())
        assert store.contest_admission("admission-test-1", "unfair")
        got = store.get_admission("admission-test-1")
        assert got["contested"] is True
        assert got["contest_reason"] == "unfair"

    def test_contest_quarantined(self, store):
        store.put_admission(self._make_record(quarantined=True))
        store.contest_admission("admission-test-1", "wrong")
        got = store.get_admission("admission-test-1")
        assert got["quarantine_resolution"] == "contested"

    def test_contest_nonexistent(self, store):
        assert not store.contest_admission("nonexistent", "reason")
