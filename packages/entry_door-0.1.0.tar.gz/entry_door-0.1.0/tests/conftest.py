"""Shared fixtures for entry-door tests."""

import pytest
from exit_door import (
    ExitMarker,
    generate_key_pair,
    generate_p256_key_pair,
    quick_exit,
    to_json,
)


@pytest.fixture
def exit_keypair():
    return generate_key_pair()


@pytest.fixture
def exit_p256_keypair():
    return generate_p256_key_pair()


@pytest.fixture
def entry_keypair():
    return generate_key_pair()


@pytest.fixture
def entry_p256_keypair():
    return generate_p256_key_pair()


@pytest.fixture
def signed_exit() -> ExitMarker:
    result = quick_exit("https://origin.example.com")
    return result.marker


@pytest.fixture
def exit_json(signed_exit) -> str:
    return to_json(signed_exit)


DESTINATION = "https://destination.example.com"
