"""Tests for admission_policy.py."""

import pytest
from datetime import datetime, timezone

from entry_door import (
    AdmissionPolicy,
    EMERGENCY_ONLY,
    OPEN_DOOR,
    STRICT,
    evaluate_admission,
    parse_duration,
)


def test_parse_duration_ms():
    assert parse_duration("100ms") == 100


def test_parse_duration_seconds():
    assert parse_duration("5s") == 5000


def test_parse_duration_minutes():
    assert parse_duration("30m") == 1_800_000


def test_parse_duration_hours():
    assert parse_duration("24h") == 86_400_000


def test_parse_duration_days():
    assert parse_duration("7d") == 604_800_000


def test_parse_duration_int():
    assert parse_duration(42) == 42


def test_parse_duration_invalid():
    with pytest.raises(ValueError):
        parse_duration("bad")


def test_open_door_admits_signed(signed_exit):
    result = evaluate_admission(signed_exit, OPEN_DOOR)
    assert result.admitted is True


def test_strict_rejects_non_voluntary(signed_exit):
    if signed_exit.exit_type != "voluntary":
        result = evaluate_admission(signed_exit, STRICT)
        assert result.admitted is False


def test_strict_admits_voluntary(signed_exit):
    # quick_exit creates voluntary exits
    result = evaluate_admission(signed_exit, STRICT)
    # May fail if lineage/stateSnapshot modules missing
    if not result.admitted:
        assert any("module" in r.lower() for r in result.reasons)


def test_emergency_only_rejects_voluntary(signed_exit):
    result = evaluate_admission(signed_exit, EMERGENCY_ONLY)
    assert result.admitted is False
    assert any("exit type" in r.lower() or "Exit type" in r for r in result.reasons)


def test_custom_policy_max_age(signed_exit):
    policy = AdmissionPolicy(max_departure_age=1)  # 1ms — should be expired
    import time
    time.sleep(0.01)
    result = evaluate_admission(signed_exit, policy)
    assert result.admitted is False
    assert any("old" in r for r in result.reasons)


def test_custom_policy_allowed_exit_types(signed_exit):
    policy = AdmissionPolicy(allowed_exit_types=["forced"])
    result = evaluate_admission(signed_exit, policy)
    assert result.admitted is False
