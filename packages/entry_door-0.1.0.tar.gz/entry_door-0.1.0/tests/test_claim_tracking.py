"""Tests for claim_tracking.py."""

from entry_door import InMemoryClaimStore


def test_claim_and_check():
    store = InMemoryClaimStore()
    assert store.claim("exit-1", "arrival-1") is True
    assert store.is_claimed("exit-1") is True
    assert store.is_claimed("exit-2") is False


def test_double_claim_fails():
    store = InMemoryClaimStore()
    assert store.claim("exit-1", "arrival-1") is True
    assert store.claim("exit-1", "arrival-2") is False


def test_get_arrival_id():
    store = InMemoryClaimStore()
    store.claim("exit-1", "arrival-1")
    assert store.get_arrival_id("exit-1") == "arrival-1"
    assert store.get_arrival_id("exit-2") is None


def test_revoke():
    store = InMemoryClaimStore()
    store.claim("exit-1", "arrival-1")
    assert store.revoke("arrival-1") is True
    assert store.is_claimed("exit-1") is False
    assert store.revoke("arrival-1") is False


def test_delete_by_subject():
    store = InMemoryClaimStore()
    store.claim("exit-1", "arrival-1", "did:key:z6MkAlice")
    store.claim("exit-2", "arrival-2", "did:key:z6MkAlice")
    store.claim("exit-3", "arrival-3", "did:key:z6MkBob")
    count = store.delete_by_subject("did:key:z6MkAlice")
    assert count == 2
    assert store.is_claimed("exit-1") is False
    assert store.is_claimed("exit-2") is False
    assert store.is_claimed("exit-3") is True


def test_size_and_clear():
    store = InMemoryClaimStore()
    store.claim("exit-1", "arrival-1")
    store.claim("exit-2", "arrival-2")
    assert store.size == 2
    store.clear()
    assert store.size == 0


def test_delete_by_subject_empty():
    store = InMemoryClaimStore()
    assert store.delete_by_subject("did:key:z6MkNobody") == 0
