"""Arrival Marker Creation — create, canonicalize, compute IDs."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Optional

from rfc8785 import dumps as _rfc8785_dumps

from exit_door import ExitMarker

from .models import (
    ENTRY_CONTEXT_V1,
    ArrivalMarker,
    CreateArrivalOpts,
    VerificationResult,
)
from .verify_departure import verify_departure


def canonicalize(obj: Any) -> str:
    """RFC 8785 JSON Canonicalization Scheme (JCS)."""
    return _rfc8785_dumps(obj).decode("utf-8")


def compute_arrival_id(marker_dict: dict[str, Any]) -> str:
    """Compute content-addressed ID for an arrival marker (excluding proof and id)."""
    canonical = canonicalize(marker_dict)
    h = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return h


def _marker_to_body_dict(
    exit_marker: ExitMarker,
    destination: str,
    verification_result: VerificationResult,
    admission_type: str,
    timestamp: str,
    opts: Optional[CreateArrivalOpts],
) -> dict[str, Any]:
    """Build the body dict (no id, no proof) for an arrival marker."""
    body: dict[str, Any] = {
        "@context": ENTRY_CONTEXT_V1,
        "type": "ArrivalMarker",
        "departureRef": exit_marker.id,
        "departureOrigin": exit_marker.origin,
        "destination": destination,
        "subject": exit_marker.subject,
        "timestamp": timestamp,
        "admissionType": admission_type,
    }
    if opts and opts.conditions:
        body["conditions"] = opts.conditions
    body["verificationResult"] = {
        "valid": verification_result.valid,
        "errors": verification_result.errors,
    }
    if opts and opts.probation:
        body["probation"] = {
            "duration": opts.probation.duration,
            "restrictions": opts.probation.restrictions,
            "reviewRequired": opts.probation.review_required,
            "startedAt": opts.probation.started_at,
        }
    if opts and opts.capability_scope:
        scope: dict[str, Any] = {
            "allowed": opts.capability_scope.allowed,
            "denied": opts.capability_scope.denied,
        }
        if opts.capability_scope.expires:
            scope["expires"] = opts.capability_scope.expires
        body["capabilityScope"] = scope
    return body


def create_arrival_marker(
    exit_marker: ExitMarker,
    destination: str,
    opts: Optional[CreateArrivalOpts] = None,
) -> ArrivalMarker:
    """Create an arrival marker linked to a verified EXIT marker.

    Verifies the EXIT marker, then produces an unsigned ArrivalMarker.
    """
    # Deep clone to prevent mutation (ADV-006)
    exit_copy = ExitMarker.model_validate(exit_marker.model_dump(by_alias=True), strict=False)

    verification_result = verify_departure(exit_copy)
    admission_type = (
        opts.admission_type
        if opts and opts.admission_type
        else ("automatic" if verification_result.valid else "reviewed")
    )
    timestamp = (
        opts.timestamp
        if opts and opts.timestamp
        else datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    )

    body = _marker_to_body_dict(exit_copy, destination, verification_result, admission_type, timestamp, opts)
    arrival_id = f"urn:entry:{compute_arrival_id(body)}"

    return ArrivalMarker(
        context=ENTRY_CONTEXT_V1,
        type="ArrivalMarker",
        id=arrival_id,
        departure_ref=exit_copy.id,
        departure_origin=exit_copy.origin,
        destination=destination,
        subject=exit_copy.subject,
        timestamp=timestamp,
        admission_type=admission_type,
        conditions=opts.conditions if opts else None,
        verification_result=verification_result,
        probation=opts.probation if opts else None,
        capability_scope=opts.capability_scope if opts else None,
    )
