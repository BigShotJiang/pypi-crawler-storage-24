"""Admission Policy Engine — composable rules for gate-keeping entry."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Optional, Protocol, Union

from exit_door import ExitMarker


@dataclass
class AdmissionPolicy:
    """An admission policy — composable rules for gate-keeping entry."""
    require_verified_departure: bool = False
    max_departure_age: Optional[int] = None  # milliseconds
    allowed_exit_types: Optional[list[str]] = None
    required_modules: Optional[list[str]] = None


@dataclass
class AdmissionResult:
    """Result of evaluating an admission policy."""
    admitted: bool
    conditions: list[str] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)


def parse_duration(dur: Union[str, int]) -> int:
    """Parse a duration string like '24h', '7d', '30m' to milliseconds."""
    if isinstance(dur, int):
        return dur
    match = re.match(r"^(\d+)(ms|s|m|h|d)$", dur)
    if not match:
        raise ValueError(f"Invalid duration: {dur}")
    val = int(match.group(1))
    unit = match.group(2)
    multipliers = {"ms": 1, "s": 1000, "m": 60_000, "h": 3_600_000, "d": 86_400_000}
    return val * multipliers[unit]


MODULE_KEYS = ("lineage", "stateSnapshot", "dispute", "economic", "metadata", "crossDomain")

# Map camelCase module names to ExitMarker snake_case attribute names
_MODULE_ATTR_MAP = {
    "lineage": "lineage",
    "stateSnapshot": "state_snapshot",
    "dispute": "dispute",
    "economic": "economic",
    "metadata": "metadata",
    "crossDomain": "cross_domain",
}


class BuiltPolicyProtocol(Protocol):
    """Protocol for v2 BuiltPolicy objects that have an evaluate method."""
    name: str
    def evaluate(self, exit_marker: ExitMarker, context: Any) -> AdmissionResult: ...


def evaluate_admission(
    exit_marker: ExitMarker,
    policy: Union[AdmissionPolicy, BuiltPolicyProtocol],
    now: Optional[Any] = None,
) -> AdmissionResult:
    """Evaluate whether an EXIT marker should be admitted under a given policy."""
    if hasattr(policy, "evaluate") and callable(getattr(policy, "evaluate")):
        from datetime import datetime, timezone
        result = policy.evaluate(exit_marker, {"now": now or datetime.now(timezone.utc)})  # type: ignore[union-attr]
        return AdmissionResult(
            admitted=result.admitted,
            conditions=result.conditions,
            reasons=result.reasons,
        )
    return _evaluate_flat(exit_marker, policy, now)  # type: ignore[arg-type]


def _evaluate_flat(
    exit_marker: ExitMarker,
    policy: AdmissionPolicy,
    now: Optional[Any] = None,
) -> AdmissionResult:
    from datetime import datetime, timezone

    reasons: list[str] = []
    conditions: list[str] = []
    current_time = int((now or datetime.now(timezone.utc)).timestamp() * 1000)

    # Check allowed exit types
    if policy.allowed_exit_types and len(policy.allowed_exit_types) > 0:
        if exit_marker.exit_type not in policy.allowed_exit_types:
            reasons.append(
                f'Exit type "{exit_marker.exit_type}" is not in allowed types: '
                f"{', '.join(policy.allowed_exit_types)}"
            )

    # Check departure age
    if policy.max_departure_age is not None:
        departure_time = int(
            datetime.fromisoformat(exit_marker.timestamp.replace("Z", "+00:00")).timestamp() * 1000
        )
        age = current_time - departure_time
        if age > policy.max_departure_age:
            reasons.append(
                f"Departure is {age}ms old, exceeds maximum of {policy.max_departure_age}ms"
            )

    # Check required modules
    if policy.required_modules:
        for mod in policy.required_modules:
            attr_name = _MODULE_ATTR_MAP.get(mod)
            if attr_name and not getattr(exit_marker, attr_name, None):
                reasons.append(f'Required module "{mod}" is missing')

    # Check verified departure
    if policy.require_verified_departure:
        if not exit_marker.proof or not exit_marker.proof.proof_value:
            reasons.append("Departure marker has no proof/signature")
        conditions.append("departure-verified")

    return AdmissionResult(
        admitted=len(reasons) == 0,
        conditions=conditions,
        reasons=reasons,
    )


# ─── Preset Policies ─────────────────────────────────────────────────────────

OPEN_DOOR = AdmissionPolicy(require_verified_departure=True)

STRICT = AdmissionPolicy(
    require_verified_departure=True,
    max_departure_age=86_400_000,  # 24h
    allowed_exit_types=["voluntary"],
    required_modules=["lineage", "stateSnapshot"],
)

EMERGENCY_ONLY = AdmissionPolicy(
    require_verified_departure=True,
    allowed_exit_types=["emergency"],
)
