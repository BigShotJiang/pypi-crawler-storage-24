"""Passage Verification — end-to-end EXIT → ENTRY verification."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from exit_door import ExitMarker, verify_marker

from .continuity import verify_continuity
from .models import ArrivalMarker, ContinuityResult
from .sign import verify_arrival_marker


@dataclass
class TransferRecord:
    """A complete Passage record linking EXIT and ENTRY."""
    exit: ExitMarker
    arrival: ArrivalMarker
    continuity: ContinuityResult
    transfer_time: int  # milliseconds
    verified: bool
    errors: list[str] = field(default_factory=list)


def verify_transfer(exit_marker: ExitMarker, arrival_marker: ArrivalMarker) -> TransferRecord:
    """Verify a complete Passage: exit signature, arrival signature, and continuity."""
    errors: list[str] = []

    # 1. Verify EXIT marker
    exit_result = verify_marker(exit_marker)
    if not exit_result.valid:
        errors.extend(f"EXIT: {e}" for e in exit_result.errors)

    # 2. Verify ARRIVAL marker
    arrival_result = verify_arrival_marker(arrival_marker)
    if not arrival_result.valid:
        errors.extend(f"ARRIVAL: {e}" for e in arrival_result.errors)

    # 3. Verify continuity
    continuity = verify_continuity(exit_marker, arrival_marker)
    if not continuity.valid:
        errors.extend(f"CONTINUITY: {e}" for e in continuity.errors)

    # 4. Compute passage time
    try:
        exit_time = datetime.fromisoformat(exit_marker.timestamp.replace("Z", "+00:00"))
        arrival_time = datetime.fromisoformat(arrival_marker.timestamp.replace("Z", "+00:00"))
        transfer_time = int((arrival_time - exit_time).total_seconds() * 1000)
    except (ValueError, AttributeError):
        transfer_time = 0

    return TransferRecord(
        exit=exit_marker,
        arrival=arrival_marker,
        continuity=continuity,
        transfer_time=transfer_time,
        verified=len(errors) == 0,
        errors=errors,
    )
