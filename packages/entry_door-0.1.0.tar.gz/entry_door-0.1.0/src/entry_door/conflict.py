"""Conflict resolution strategies for policy rule results."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


ConflictStrategy = Literal["deny-overrides", "first-match", "permit-overrides"]
RuleDecision = Literal["admit", "deny", "abstain"]


class RuleResult(BaseModel):
    """Result from a single policy rule evaluation."""

    name: str
    decision: RuleDecision
    reason: str
    conditions: list[str] = Field(default_factory=list)


class ResolvedDecision(BaseModel):
    """Final resolved decision after conflict resolution."""

    admitted: bool
    reasons: list[str]
    conditions: list[str]
    rule_results: list[RuleResult]


def resolve_conflict(
    results: list[RuleResult],
    strategy: ConflictStrategy = "deny-overrides",
    default_decision: Literal["admit", "deny"] = "deny",
) -> ResolvedDecision:
    """Resolve a set of rule results using the given strategy."""
    conditions: list[str] = []
    for r in results:
        conditions.extend(r.conditions)

    decisive = [r for r in results if r.decision != "abstain"]

    if not decisive:
        admitted = default_decision == "admit"
        return ResolvedDecision(
            admitted=admitted,
            reasons=["No rules produced a decision — default admit" if admitted else "No rules produced a decision — default deny"],
            conditions=conditions,
            rule_results=results,
        )

    if strategy == "deny-overrides":
        denied = [r for r in decisive if r.decision == "deny"]
        if denied:
            return ResolvedDecision(
                admitted=False,
                reasons=[f"[{r.name}] {r.reason}" for r in denied],
                conditions=conditions,
                rule_results=results,
            )
        admitted_rules = [r for r in decisive if r.decision == "admit"]
        return ResolvedDecision(
            admitted=True,
            reasons=[f"[{r.name}] {r.reason}" for r in admitted_rules],
            conditions=conditions,
            rule_results=results,
        )

    if strategy == "first-match":
        first = decisive[0]
        return ResolvedDecision(
            admitted=first.decision == "admit",
            reasons=[f"[{first.name}] {first.reason}"],
            conditions=first.conditions,
            rule_results=results,
        )

    # permit-overrides
    admitted_rules = [r for r in decisive if r.decision == "admit"]
    if admitted_rules:
        return ResolvedDecision(
            admitted=True,
            reasons=[f"[{r.name}] {r.reason}" for r in admitted_rules],
            conditions=conditions,
            rule_results=results,
        )
    denied = [r for r in decisive if r.decision == "deny"]
    return ResolvedDecision(
        admitted=False,
        reasons=[f"[{r.name}] {r.reason}" for r in denied],
        conditions=conditions,
        rule_results=results,
    )
