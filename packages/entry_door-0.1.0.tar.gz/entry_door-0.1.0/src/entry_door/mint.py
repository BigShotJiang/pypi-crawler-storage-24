"""Minting — create arrival markers for fresh agents with no departure history."""

from __future__ import annotations

from typing import Any, Optional

from .admit import admit, AdmitOpts
from .claim_tracking import ClaimStore
from .events import AdmissionEventEmitter
from .policy_builder import BuiltPolicy


class MintOpts:
    """Options for minting a single agent."""

    def __init__(
        self,
        *,
        subject_did: str,
        destination: Optional[str] = None,
        justification: Optional[str] = None,
        platform_identity: Optional[dict[str, bytes]] = None,
        policy: Optional[BuiltPolicy] = None,
        store: Optional[ClaimStore] = None,
        emitter: Optional[AdmissionEventEmitter] = None,
        timestamp: Optional[str] = None,
        admission_type: Optional[str] = None,
    ) -> None:
        self.subject_did = subject_did
        self.destination = destination
        self.justification = justification
        self.platform_identity = platform_identity
        self.policy = policy
        self.store = store
        self.emitter = emitter
        self.timestamp = timestamp
        self.admission_type = admission_type


class BulkMintAgent:
    """Agent descriptor for bulk minting."""

    def __init__(self, *, subject_did: str, justification: Optional[str] = None) -> None:
        self.subject_did = subject_did
        self.justification = justification


def mint_agent(opts: MintOpts) -> dict[str, Any]:
    """Mint a fresh agent — create an arrival marker with no departure history."""
    result = admit(None, AdmitOpts(
        platform_identity=opts.platform_identity,
        policy=opts.policy,
        store=opts.store,
        destination=opts.destination,
        emitter=opts.emitter,
        timestamp=opts.timestamp,
        minting_justification=opts.justification,
        minting_subject=opts.subject_did,
        admission_type=opts.admission_type,
    ))
    result["subject_did"] = opts.subject_did
    return result


def bulk_mint(
    agents: list[BulkMintAgent],
    *,
    platform_identity: Optional[dict[str, bytes]] = None,
    policy: Optional[BuiltPolicy] = None,
    store: Optional[ClaimStore] = None,
    destination: Optional[str] = None,
    emitter: Optional[AdmissionEventEmitter] = None,
    timestamp: Optional[str] = None,
) -> dict[str, Any]:
    """Batch mint multiple agents for migration scenarios."""
    results: list[dict[str, Any]] = []
    succeeded = 0
    failed = 0

    for agent in agents:
        result = mint_agent(MintOpts(
            subject_did=agent.subject_did,
            justification=agent.justification,
            platform_identity=platform_identity,
            policy=policy,
            store=store,
            destination=destination,
            emitter=emitter,
            timestamp=timestamp,
            admission_type="migration",
        ))
        results.append(result)
        if result["admission"]["admitted"]:
            succeeded += 1
        else:
            failed += 1

    return {"results": results, "succeeded": succeeded, "failed": failed}
