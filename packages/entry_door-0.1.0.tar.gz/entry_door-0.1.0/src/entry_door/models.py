"""Core Arrival Marker types — Pydantic v2 models."""

from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field

ENTRY_CONTEXT_V1 = "https://cellar-door.dev/entry/v1"

AdmissionType = Literal["automatic", "reviewed", "conditional"]
ArrivalProofType = Literal["Ed25519Signature2020", "EcdsaP256Signature2019"]


class VerificationResult(BaseModel):
    valid: bool
    errors: list[str] = Field(default_factory=list)


class ArrivalProof(BaseModel):
    type: ArrivalProofType
    created: str
    verification_method: str = Field(alias="verificationMethod")
    proof_value: str = Field(alias="proofValue")

    model_config = {"populate_by_name": True}


class ProbationInfo(BaseModel):
    duration: int
    restrictions: list[str]
    review_required: bool = Field(alias="reviewRequired")
    started_at: str = Field(alias="startedAt")

    model_config = {"populate_by_name": True}


class CapabilityScope(BaseModel):
    allowed: list[str]
    denied: list[str]
    expires: Optional[str] = None


class ArrivalMarker(BaseModel):
    context: str = Field(alias="@context", default=ENTRY_CONTEXT_V1)
    type: Optional[Literal["ArrivalMarker"]] = "ArrivalMarker"
    id: str
    departure_ref: str = Field(alias="departureRef")
    departure_origin: str = Field(alias="departureOrigin")
    destination: str
    subject: str
    timestamp: str
    admission_type: AdmissionType = Field(alias="admissionType")
    conditions: Optional[list[str]] = None
    verification_result: VerificationResult = Field(alias="verificationResult")
    probation: Optional[ProbationInfo] = None
    capability_scope: Optional[CapabilityScope] = Field(default=None, alias="capabilityScope")
    proof: Optional[ArrivalProof] = None

    model_config = {"populate_by_name": True}


class ContinuityResult(BaseModel):
    valid: bool
    errors: list[str] = Field(default_factory=list)


class CreateArrivalOpts(BaseModel):
    admission_type: Optional[AdmissionType] = Field(default=None, alias="admissionType")
    conditions: Optional[list[str]] = None
    timestamp: Optional[str] = None
    probation: Optional[ProbationInfo] = None
    capability_scope: Optional[CapabilityScope] = Field(default=None, alias="capabilityScope")

    model_config = {"populate_by_name": True}
