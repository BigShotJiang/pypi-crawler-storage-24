"""Claim Tracking — prevents replay attacks on EXIT markers."""

from __future__ import annotations

from typing import Optional, Protocol


class ClaimStore(Protocol):
    """Interface for claim storage backends."""

    def claim(self, exit_marker_id: str, arrival_marker_id: str, subject_did: Optional[str] = None) -> bool: ...
    def is_claimed(self, exit_marker_id: str) -> bool: ...
    def get_arrival_id(self, exit_marker_id: str) -> Optional[str]: ...
    def revoke(self, arrival_marker_id: str) -> bool: ...
    def delete_by_subject(self, subject_did: str) -> int: ...


class InMemoryClaimStore:
    """In-memory claim store (dict-based). For testing/prototyping only."""

    def __init__(self) -> None:
        self._claims: dict[str, str] = {}  # exit_id -> arrival_id
        self._reverse: dict[str, str] = {}  # arrival_id -> exit_id
        self._subjects: dict[str, set[str]] = {}  # subject_did -> set of exit_ids

    def claim(
        self, exit_marker_id: str, arrival_marker_id: str, subject_did: Optional[str] = None
    ) -> bool:
        """Claim an EXIT marker for an arrival. Returns True if successful."""
        if exit_marker_id in self._claims:
            return False
        self._claims[exit_marker_id] = arrival_marker_id
        self._reverse[arrival_marker_id] = exit_marker_id
        if subject_did:
            self._subjects.setdefault(subject_did, set()).add(exit_marker_id)
        return True

    def is_claimed(self, exit_marker_id: str) -> bool:
        """Check if an EXIT marker has been claimed."""
        return exit_marker_id in self._claims

    def get_arrival_id(self, exit_marker_id: str) -> Optional[str]:
        """Get the arrival marker ID that claimed this exit marker."""
        return self._claims.get(exit_marker_id)

    def revoke(self, arrival_marker_id: str) -> bool:
        """Revoke an arrival, unclaiming the associated EXIT marker."""
        exit_id = self._reverse.get(arrival_marker_id)
        if exit_id is None:
            return False
        del self._claims[exit_id]
        del self._reverse[arrival_marker_id]
        return True

    def delete_by_subject(self, subject_did: str) -> int:
        """GDPR Art. 17 — delete all claims involving a given subject DID."""
        exit_ids = self._subjects.get(subject_did)
        if not exit_ids:
            return 0
        count = 0
        for exit_id in list(exit_ids):
            arrival_id = self._claims.get(exit_id)
            if arrival_id:
                self._reverse.pop(arrival_id, None)
            self._claims.pop(exit_id, None)
            count += 1
        del self._subjects[subject_did]
        return count

    @property
    def size(self) -> int:
        """Number of active claims."""
        return len(self._claims)

    def clear(self) -> None:
        """Clear all claims."""
        self._claims.clear()
        self._reverse.clear()
        self._subjects.clear()
