"""SQLite Claim Store — persistent claim and admission record storage."""

from __future__ import annotations

import json
import sqlite3
from typing import Any, Optional


class SqliteClaimStore:
    """SQLite-backed claim store with admission record storage.

    Implements both ClaimStore and AdmissionStore protocols.

    .. note:: **Path safety** — ``db_path`` is passed directly to
       ``sqlite3.connect``.  This is a library, not a network service;
       callers are responsible for ensuring ``db_path`` is safe and does
       not point to unintended locations.
    """

    def __init__(self, db_path: str, *, retention_period: Optional[int] = None) -> None:
        self._db_path = db_path
        self._retention_period = retention_period
        self._initialized = False
        self._db: Optional[sqlite3.Connection] = None

    def _assert_init(self) -> None:
        if not self._initialized:
            raise RuntimeError("SqliteClaimStore.init() must be called before use")

    def init(self) -> None:
        """Initialize database: create tables, indexes, set pragmas."""
        self._db = sqlite3.connect(self._db_path)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode = WAL")
        self._db.execute("PRAGMA busy_timeout = 5000")
        self._db.execute("PRAGMA foreign_keys = ON")

        self._db.executescript("""
            CREATE TABLE IF NOT EXISTS claims (
                exit_marker_id TEXT PRIMARY KEY,
                arrival_marker_id TEXT NOT NULL,
                subject_did TEXT,
                origin_did TEXT,
                timestamp TEXT DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS admissions (
                id TEXT PRIMARY KEY,
                exit_marker_id TEXT,
                arrival_marker_id TEXT NOT NULL,
                subject_did TEXT NOT NULL,
                origin_did TEXT,
                confirmation_level TEXT,
                policy_name TEXT NOT NULL,
                policy_version TEXT,
                admitted INTEGER NOT NULL DEFAULT 1,
                admission_type TEXT NOT NULL DEFAULT 'standard',
                counter_signed INTEGER NOT NULL DEFAULT 0,
                counter_sign_meaning TEXT,
                reason_codes TEXT,
                conditions TEXT,
                timestamp TEXT NOT NULL,
                quarantined INTEGER DEFAULT 0,
                quarantine_expires TEXT,
                quarantine_resolution TEXT,
                minting_justification TEXT,
                retention_expires TEXT,
                contested INTEGER DEFAULT 0,
                contest_reason TEXT,
                policy_snapshot TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_claims_subject ON claims(subject_did);
            CREATE INDEX IF NOT EXISTS idx_claims_arrival ON claims(arrival_marker_id);
            CREATE INDEX IF NOT EXISTS idx_admissions_subject ON admissions(subject_did);
            CREATE INDEX IF NOT EXISTS idx_admissions_origin ON admissions(origin_did);
            CREATE INDEX IF NOT EXISTS idx_admissions_policy_time ON admissions(policy_name, timestamp);
            CREATE INDEX IF NOT EXISTS idx_admissions_quarantine ON admissions(quarantined, quarantine_expires);
            CREATE INDEX IF NOT EXISTS idx_admissions_confirmation ON admissions(confirmation_level);
        """)
        self._initialized = True

    # ─── ClaimStore Interface ─────────────────────────────────────────────

    def claim(self, exit_marker_id: str, arrival_marker_id: str, subject_did: Optional[str] = None) -> bool:
        self._assert_init()
        assert self._db is not None
        try:
            self._db.execute(
                "INSERT INTO claims (exit_marker_id, arrival_marker_id, subject_did) VALUES (?, ?, ?)",
                (exit_marker_id, arrival_marker_id, subject_did),
            )
            self._db.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def is_claimed(self, exit_marker_id: str) -> bool:
        self._assert_init()
        assert self._db is not None
        row = self._db.execute("SELECT 1 FROM claims WHERE exit_marker_id = ?", (exit_marker_id,)).fetchone()
        return row is not None

    def get_arrival_id(self, exit_marker_id: str) -> Optional[str]:
        self._assert_init()
        assert self._db is not None
        row = self._db.execute(
            "SELECT arrival_marker_id FROM claims WHERE exit_marker_id = ?", (exit_marker_id,)
        ).fetchone()
        return row["arrival_marker_id"] if row else None

    def revoke(self, arrival_marker_id: str) -> bool:
        self._assert_init()
        assert self._db is not None
        cursor = self._db.execute("DELETE FROM claims WHERE arrival_marker_id = ?", (arrival_marker_id,))
        self._db.commit()
        return cursor.rowcount > 0

    def delete_by_subject(self, subject_did: str) -> int:
        self._assert_init()
        assert self._db is not None
        cursor = self._db.execute("DELETE FROM claims WHERE subject_did = ?", (subject_did,))
        self._db.commit()
        return cursor.rowcount

    # ─── Admission Records ────────────────────────────────────────────────

    def put_admission(self, record: dict[str, Any]) -> None:
        self._assert_init()
        assert self._db is not None
        from datetime import datetime, timezone

        retention_expires = record.get("retention_expires")
        if self._retention_period and not retention_expires:
            ts = datetime.fromisoformat(record["timestamp"].replace("Z", "+00:00"))
            retention_expires = (
                datetime.fromtimestamp(ts.timestamp() + self._retention_period / 1000, tz=timezone.utc)
                .isoformat()
            )

        self._db.execute(
            """INSERT INTO admissions (
                id, exit_marker_id, arrival_marker_id, subject_did, origin_did,
                confirmation_level, policy_name, policy_version, admitted, admission_type,
                counter_signed, counter_sign_meaning, reason_codes, conditions,
                timestamp, quarantined, quarantine_expires, quarantine_resolution,
                minting_justification, retention_expires, policy_snapshot
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                record["id"],
                record.get("exit_marker_id"),
                record["arrival_marker_id"],
                record["subject_did"],
                record.get("origin_did"),
                record.get("confirmation_level"),
                record["policy_applied"],
                record.get("policy_version"),
                1 if record["admitted"] else 0,
                record["admission_type"],
                1 if record.get("counter_signed") else 0,
                record.get("counter_sign_meaning"),
                json.dumps(record.get("reason_codes", [])),
                json.dumps(record.get("conditions", [])),
                record["timestamp"],
                1 if record.get("quarantined") else 0,
                record.get("quarantine_expires"),
                record.get("quarantine_resolution"),
                record.get("minting_justification"),
                retention_expires,
                record.get("policy_snapshot"),
            ),
        )
        self._db.commit()

    def get_admission(self, record_id: str) -> Optional[dict[str, Any]]:
        self._assert_init()
        assert self._db is not None
        row = self._db.execute("SELECT * FROM admissions WHERE id = ?", (record_id,)).fetchone()
        return self._row_to_record(row) if row else None

    def get_admission_history(self, subject_did: str) -> list[dict[str, Any]]:
        self._assert_init()
        assert self._db is not None
        rows = self._db.execute(
            "SELECT * FROM admissions WHERE subject_did = ? ORDER BY timestamp DESC",
            (subject_did,),
        ).fetchall()
        return [self._row_to_record(r) for r in rows]

    def get_admissions_by_policy(self, policy_name: str, *, limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
        self._assert_init()
        assert self._db is not None
        rows = self._db.execute(
            "SELECT * FROM admissions WHERE policy_name = ? ORDER BY timestamp DESC LIMIT ? OFFSET ?",
            (policy_name, limit, offset),
        ).fetchall()
        return [self._row_to_record(r) for r in rows]

    def get_quarantined(self) -> list[dict[str, Any]]:
        self._assert_init()
        assert self._db is not None
        rows = self._db.execute(
            "SELECT * FROM admissions WHERE quarantined = 1 AND quarantine_resolution IS NULL ORDER BY timestamp DESC"
        ).fetchall()
        return [self._row_to_record(r) for r in rows]

    def contest_admission(self, record_id: str, reason: str) -> bool:
        self._assert_init()
        assert self._db is not None
        row = self._db.execute("SELECT quarantined FROM admissions WHERE id = ?", (record_id,)).fetchone()
        if not row:
            return False
        if row["quarantined"]:
            self._db.execute(
                "UPDATE admissions SET contested = 1, contest_reason = ?, quarantine_resolution = 'contested' WHERE id = ?",
                (reason, record_id),
            )
        else:
            self._db.execute(
                "UPDATE admissions SET contested = 1, contest_reason = ? WHERE id = ?",
                (reason, record_id),
            )
        self._db.commit()
        return True

    def purge_expired(self) -> int:
        """Delete claims and admissions whose retention has expired (DP-01)."""
        self._assert_init()
        assert self._db is not None
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).isoformat()
        adm_cursor = self._db.execute(
            "DELETE FROM admissions WHERE retention_expires IS NOT NULL AND retention_expires < ?",
            (now,),
        )
        count = adm_cursor.rowcount
        self._db.commit()
        return count

    def erase_subject(self, subject_did: str) -> dict[str, int]:
        """GDPR right-to-erasure: atomically delete all data for a subject (DP-02)."""
        self._assert_init()
        assert self._db is not None
        self._db.execute("BEGIN")
        try:
            claims_cursor = self._db.execute("DELETE FROM claims WHERE subject_did = ?", (subject_did,))
            claims = claims_cursor.rowcount
            adm_cursor = self._db.execute("DELETE FROM admissions WHERE subject_did = ?", (subject_did,))
            admissions = adm_cursor.rowcount
            self._db.execute("COMMIT")
        except Exception:
            self._db.execute("ROLLBACK")
            raise
        return {"claims": claims, "admissions": admissions}

    def delete_admissions_by_subject(self, subject_did: str) -> int:
        self._assert_init()
        assert self._db is not None
        cursor = self._db.execute("DELETE FROM admissions WHERE subject_did = ?", (subject_did,))
        self._db.commit()
        return cursor.rowcount

    def close(self) -> None:
        if self._db:
            self._db.close()

    def _row_to_record(self, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": row["id"],
            "exit_marker_id": row["exit_marker_id"],
            "arrival_marker_id": row["arrival_marker_id"],
            "subject_did": row["subject_did"],
            "origin_did": row["origin_did"],
            "confirmation_level": row["confirmation_level"],
            "policy_applied": row["policy_name"],
            "policy_version": row["policy_version"] or "",
            "admitted": bool(row["admitted"]),
            "admission_type": row["admission_type"],
            "counter_signed": bool(row["counter_signed"]),
            "counter_sign_meaning": row["counter_sign_meaning"],
            "reason_codes": json.loads(row["reason_codes"]) if row["reason_codes"] else [],
            "conditions": json.loads(row["conditions"]) if row["conditions"] else [],
            "timestamp": row["timestamp"],
            "quarantined": bool(row["quarantined"]) or None,
            "quarantine_expires": row["quarantine_expires"],
            "quarantine_resolution": row["quarantine_resolution"],
            "minting_justification": row["minting_justification"],
            "retention_expires": row["retention_expires"],
            "contested": bool(row["contested"]) or None,
            "contest_reason": row["contest_reason"],
            "policy_snapshot": row["policy_snapshot"],
        }
