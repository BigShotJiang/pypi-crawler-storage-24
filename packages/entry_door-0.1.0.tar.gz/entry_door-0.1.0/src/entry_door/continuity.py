"""Continuity Verification — verify EXIT → ENTRY continuity."""

from __future__ import annotations

from datetime import datetime

from exit_door import ExitMarker, verify_marker

from .models import ArrivalMarker, ContinuityResult


def verify_continuity(
    exit_marker: ExitMarker,
    arrival_marker: ArrivalMarker,
) -> ContinuityResult:
    """Verify continuity between an EXIT marker and an ARRIVAL marker.

    Checks:
    1. The arrival references the correct departure (by ID)
    2. The subject DID matches
    3. Origin matches
    4. Timestamps are sequential (arrival after departure)
    5. The departure marker is cryptographically valid
    """
    errors: list[str] = []

    # 1. Departure reference matches
    if arrival_marker.departure_ref != exit_marker.id:
        errors.append(
            f'Departure reference mismatch: arrival references "{arrival_marker.departure_ref}" '
            f'but exit marker has id "{exit_marker.id}"'
        )

    # 2. Subject DID matches
    if arrival_marker.subject != exit_marker.subject:
        errors.append(
            f'Subject mismatch: arrival subject "{arrival_marker.subject}" '
            f'does not match departure subject "{exit_marker.subject}"'
        )

    # 3. Origin matches
    if arrival_marker.departure_origin != exit_marker.origin:
        errors.append(
            f'Origin mismatch: arrival claims origin "{arrival_marker.departure_origin}" '
            f'but exit marker has origin "{exit_marker.origin}"'
        )

    # 4. Timestamps are sequential
    try:
        exit_time = datetime.fromisoformat(exit_marker.timestamp.replace("Z", "+00:00"))
        arrival_time = datetime.fromisoformat(arrival_marker.timestamp.replace("Z", "+00:00"))
        if arrival_time < exit_time:
            errors.append(
                f"Temporal violation: arrival timestamp ({arrival_marker.timestamp}) "
                f"is before departure timestamp ({exit_marker.timestamp})"
            )
    except (ValueError, AttributeError):
        pass  # Skip timestamp check if parsing fails

    # 5. Departure marker is cryptographically valid
    exit_verification = verify_marker(exit_marker)
    if not exit_verification.valid:
        errors.append(f"Departure marker is invalid: {'; '.join(exit_verification.errors)}")

    return ContinuityResult(valid=len(errors) == 0, errors=errors)
