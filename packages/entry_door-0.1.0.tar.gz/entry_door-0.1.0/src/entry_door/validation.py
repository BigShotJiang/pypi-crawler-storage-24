"""Input Validation — validates ArrivalMarker fields."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

from .models import ENTRY_CONTEXT_V1

MAX_MARKER_SIZE = 8192

DID_REGEX = re.compile(r"^did:[a-z0-9]+:[a-zA-Z0-9._:%-]+$")
ISO_TIMESTAMP_REGEX = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$")
CONTROL_CHAR_REGEX = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


@dataclass
class ValidationResult:
    valid: bool
    errors: list[str] = field(default_factory=list)


def validate_arrival_marker(marker: Any) -> ValidationResult:
    """Validate an ArrivalMarker's fields."""
    errors: list[str] = []

    if not marker or not isinstance(marker, dict):
        return ValidationResult(valid=False, errors=["Marker must be a non-null object"])

    m: dict[str, Any] = marker

    # Size check
    try:
        serialized = json.dumps(m)
        byte_length = len(serialized.encode("utf-8"))
        if byte_length > MAX_MARKER_SIZE:
            errors.append(f"Marker exceeds maximum size of {MAX_MARKER_SIZE} bytes (got {byte_length})")
    except (TypeError, ValueError):
        errors.append("Marker cannot be serialized to JSON")

    # ADV-002: control characters
    for fld in ("subject", "departureRef", "departureOrigin", "destination", "id"):
        val = m.get(fld)
        if isinstance(val, str) and CONTROL_CHAR_REGEX.search(val):
            errors.append(f"{fld} contains invalid control characters")

    # Context
    if m.get("@context") != ENTRY_CONTEXT_V1:
        errors.append(f'Invalid @context: expected "{ENTRY_CONTEXT_V1}", got "{m.get("@context")}"')

    # ID
    mid = m.get("id")
    if not isinstance(mid, str) or not mid.startswith("urn:entry:"):
        errors.append(f'Invalid id: must be a string starting with "urn:entry:", got "{mid}"')

    # departureRef
    if not isinstance(m.get("departureRef"), str) or not m.get("departureRef"):
        errors.append("Missing or invalid departureRef")

    # departureOrigin
    if not isinstance(m.get("departureOrigin"), str) or not m.get("departureOrigin"):
        errors.append("Missing or invalid departureOrigin")

    # destination
    if not isinstance(m.get("destination"), str) or not m.get("destination"):
        errors.append("Missing or invalid destination")

    # subject
    subj = m.get("subject")
    if not isinstance(subj, str):
        errors.append("Missing subject")
    elif not DID_REGEX.match(subj):
        errors.append(f'Invalid subject DID format: "{subj}"')

    # timestamp
    ts = m.get("timestamp")
    if not isinstance(ts, str):
        errors.append("Missing timestamp")
    elif not ISO_TIMESTAMP_REGEX.match(ts):
        errors.append(f'Invalid timestamp format (must be ISO 8601 UTC): "{ts}"')

    # admissionType
    valid_types = ("automatic", "reviewed", "conditional")
    if m.get("admissionType") not in valid_types:
        errors.append(f'Invalid admissionType: "{m.get("admissionType")}"')

    # verificationResult
    vr = m.get("verificationResult")
    if not vr or not isinstance(vr, dict):
        errors.append("Missing verificationResult")
    else:
        if not isinstance(vr.get("valid"), bool):
            errors.append("verificationResult.valid must be a boolean")
        if not isinstance(vr.get("errors"), list):
            errors.append("verificationResult.errors must be an array")

    # conditions
    conds = m.get("conditions")
    if conds is not None:
        if not isinstance(conds, list) or not all(isinstance(c, str) for c in conds):
            errors.append("conditions must be an array of strings")

    return ValidationResult(valid=len(errors) == 0, errors=errors)
