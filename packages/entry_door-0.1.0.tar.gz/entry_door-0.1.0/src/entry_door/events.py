"""Admission Event Emitter — simple typed event emitter for admission lifecycle."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Callable, Literal, Optional

from pydantic import BaseModel


AdmissionEventType = Literal[
    "agent:admitted",
    "agent:quarantined",
    "agent:rejected",
    "agent:minted",
    "quarantine:expired",
    "admission:contested",
]


class AdmissionEvent(BaseModel):
    """An admission lifecycle event."""

    type: AdmissionEventType
    timestamp: str
    data: dict[str, object]


EventHandler = Callable[[AdmissionEvent], None]
ErrorHandler = Callable[[Exception, AdmissionEvent], None]


def _default_error_handler(error: Exception, event: AdmissionEvent) -> None:
    import sys
    print(f"AdmissionEventEmitter: handler error for {event.type}: {error}", file=sys.stderr)


class AdmissionEventEmitter:
    """Simple EventEmitter for admission events."""

    def __init__(self, *, on_error: Optional[ErrorHandler] = None) -> None:
        self._handlers: dict[AdmissionEventType, list[EventHandler]] = {}
        self._all_handlers: list[EventHandler] = []
        self._error_handler = on_error or _default_error_handler

    def on(self, event_type: AdmissionEventType, handler: EventHandler) -> "AdmissionEventEmitter":
        self._handlers.setdefault(event_type, []).append(handler)
        return self

    def on_any(self, handler: EventHandler) -> "AdmissionEventEmitter":
        self._all_handlers.append(handler)
        return self

    def off(self, event_type: AdmissionEventType, handler: EventHandler) -> "AdmissionEventEmitter":
        handlers = self._handlers.get(event_type)
        if handlers:
            self._handlers[event_type] = [h for h in handlers if h is not handler]
        return self

    def off_any(self, handler: EventHandler) -> "AdmissionEventEmitter":
        self._all_handlers = [h for h in self._all_handlers if h is not handler]
        return self

    def emit(self, event_type: AdmissionEventType, data: Optional[dict[str, object]] = None) -> None:
        event = AdmissionEvent(
            type=event_type,
            timestamp=datetime.now(timezone.utc).isoformat(),
            data=data or {},
        )
        for handler in self._handlers.get(event_type, []):
            try:
                handler(event)
            except Exception as e:
                self._error_handler(e, event)
        for handler in self._all_handlers:
            try:
                handler(event)
            except Exception as e:
                self._error_handler(e, event)

    def remove_all_listeners(self) -> None:
        self._handlers.clear()
        self._all_handlers.clear()

    def listener_count(self, event_type: AdmissionEventType) -> int:
        return len(self._handlers.get(event_type, []))
