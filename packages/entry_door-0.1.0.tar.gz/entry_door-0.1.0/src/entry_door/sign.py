"""Signing and Verification for Arrival Markers — Ed25519 + P-256."""

from __future__ import annotations

import base64
from datetime import datetime, timezone
from typing import Literal

from exit_door import (
    algorithm_from_did,
    did_from_p256_public_key,
    did_from_public_key,
    public_key_from_did,
    sign,
    sign_p256,
    verify,
    verify_p256,
)

from .arrival import canonicalize
from .models import ArrivalMarker, ArrivalProof, ArrivalProofType, VerificationResult

SignatureAlgorithm = Literal["Ed25519", "P-256"]

DOMAIN_PREFIX = "entry-marker-v1.0:"


def _marker_to_sign_dict(marker: ArrivalMarker) -> dict:
    """Convert marker to dict for signing (exclude proof)."""
    d = marker.model_dump(by_alias=True, exclude_none=True)
    d.pop("proof", None)
    return d


def sign_arrival_marker(
    marker: ArrivalMarker,
    private_key: bytes,
    public_key: bytes,
    algorithm: SignatureAlgorithm = "Ed25519",
) -> ArrivalMarker:
    """Sign an arrival marker. Returns a new marker with proof attached."""
    body = _marker_to_sign_dict(marker)
    canonical = canonicalize(body)
    data = (DOMAIN_PREFIX + canonical).encode("utf-8")

    if algorithm == "P-256":
        did = did_from_p256_public_key(public_key)
        sig_bytes = sign_p256(data, private_key)
        proof_type: ArrivalProofType = "EcdsaP256Signature2019"
    else:
        did = did_from_public_key(public_key)
        sig_bytes = sign(data, private_key)
        proof_type = "Ed25519Signature2020"

    proof_value = base64.b64encode(sig_bytes).decode("ascii")

    proof = ArrivalProof(
        type=proof_type,
        created=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        verification_method=did,
        proof_value=proof_value,
    )

    return marker.model_copy(update={"proof": proof})


class ArrivalVerificationResult:
    """Result of verifying an arrival marker signature."""

    def __init__(self, valid: bool, errors: list[str]) -> None:
        self.valid = valid
        self.errors = errors


def verify_arrival_marker(marker: ArrivalMarker) -> ArrivalVerificationResult:
    """Verify the signature on an arrival marker. Supports Ed25519 and P-256."""
    errors: list[str] = []

    if not marker.proof:
        return ArrivalVerificationResult(valid=False, errors=["Missing proof"])

    supported: list[ArrivalProofType] = ["Ed25519Signature2020", "EcdsaP256Signature2019"]
    if marker.proof.type not in supported:
        return ArrivalVerificationResult(
            valid=False, errors=[f"Unsupported proof type: {marker.proof.type}"]
        )

    if not marker.proof.verification_method or not marker.proof.proof_value:
        return ArrivalVerificationResult(valid=False, errors=["Incomplete proof"])

    try:
        did = marker.proof.verification_method
        alg = algorithm_from_did(did)
        pub_key = public_key_from_did(did)

        body = _marker_to_sign_dict(marker)
        canonical = canonicalize(body)
        data = (DOMAIN_PREFIX + canonical).encode("utf-8")
        signature = base64.b64decode(marker.proof.proof_value)

        if alg == "P-256":
            valid = verify_p256(data, signature, pub_key)
        else:
            valid = verify(data, signature, pub_key)

        if not valid:
            errors.append("Signature verification failed")
    except Exception as e:
        errors.append(f"Verification error: {e}")

    return ArrivalVerificationResult(valid=len(errors) == 0, errors=errors)
