"""Probationary Status Tracking."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from exit_door import ExitMarker

from .arrival import create_arrival_marker
from .models import ArrivalMarker, CreateArrivalOpts, ProbationInfo

logger = logging.getLogger(__name__)

# Maximum probation duration: 180 days in milliseconds (soft cap).
MAX_PROBATION_DURATION_MS = 180 * 24 * 60 * 60 * 1000  # 15_552_000_000


@dataclass
class ProbationConfig:
    """Configuration for creating a probationary arrival."""
    duration: int  # milliseconds
    restrictions: list[str]
    review_required: bool


def create_probationary_arrival(
    exit_marker: ExitMarker,
    destination: str,
    probation: ProbationConfig,
    opts: Optional[CreateArrivalOpts] = None,
    max_probation_duration: int = MAX_PROBATION_DURATION_MS,
) -> ArrivalMarker:
    """Create an arrival marker with probation metadata."""
    if probation.duration > max_probation_duration:
        logger.warning(
            "Probation duration %dms exceeds soft cap of %dms (%d days). Proceeding anyway.",
            probation.duration,
            max_probation_duration,
            max_probation_duration // 86_400_000,
        )
    timestamp = (
        opts.timestamp
        if opts and opts.timestamp
        else datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    )

    probation_info = ProbationInfo(
        duration=probation.duration,
        restrictions=probation.restrictions,
        review_required=probation.review_required,
        started_at=timestamp,
    )

    conditions = list(opts.conditions) if opts and opts.conditions else []
    conditions.append(f"probation-{probation.duration}ms")
    conditions.extend(f"restriction:{r}" for r in probation.restrictions)

    return create_arrival_marker(
        exit_marker,
        destination,
        CreateArrivalOpts(
            admission_type="conditional",
            conditions=conditions,
            timestamp=timestamp,
            probation=probation_info,
            capability_scope=opts.capability_scope if opts else None,
        ),
    )


def is_probation_complete(arrival: ArrivalMarker, now: Optional[datetime] = None) -> bool:
    """Check if probation has elapsed for an arrival marker."""
    if not arrival.probation:
        return True
    start = datetime.fromisoformat(arrival.probation.started_at.replace("Z", "+00:00"))
    current = now or datetime.now(timezone.utc)
    elapsed_ms = (current - start).total_seconds() * 1000
    return elapsed_ms >= arrival.probation.duration
