"""EXIT Marker Verification — wraps exit-door's verify functions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Union

from exit_door import ExitMarker, from_json, verify_marker

from .models import VerificationResult


def verify_departure(exit_marker: ExitMarker) -> VerificationResult:
    """Verify an EXIT marker (object form). Returns structured result."""
    result = verify_marker(exit_marker)
    return VerificationResult(valid=result.valid, errors=list(result.errors))


@dataclass
class VerifyDepartureJSONResultParsed:
    marker: ExitMarker
    result: VerificationResult
    parsed: bool = True


@dataclass
class VerifyDepartureJSONResultFailed:
    marker: None
    result: VerificationResult
    parsed: bool = False


VerifyDepartureJSONResult = Union[VerifyDepartureJSONResultParsed, VerifyDepartureJSONResultFailed]


def verify_departure_json(exit_marker_json: str) -> VerifyDepartureJSONResult:
    """Parse and verify an EXIT marker from JSON string."""
    try:
        marker = from_json(exit_marker_json)
        result = verify_departure(marker)
        return VerifyDepartureJSONResultParsed(marker=marker, result=result)
    except Exception as e:
        return VerifyDepartureJSONResultFailed(
            marker=None,
            result=VerificationResult(valid=False, errors=[str(e)]),
        )
