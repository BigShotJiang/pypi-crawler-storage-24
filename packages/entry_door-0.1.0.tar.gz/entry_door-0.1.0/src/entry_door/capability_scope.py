"""Capability Scoping — determines what an arriving agent is allowed to do."""

from __future__ import annotations

from typing import Optional

from exit_door import ExitMarker

from .models import CapabilityScope


def scope_from_exit_marker(marker: ExitMarker) -> CapabilityScope:
    """Extract capability hints from an EXIT marker's modules."""
    allowed: list[str] = []

    if marker.lineage:
        allowed.append("identity-continuity")
    if marker.state_snapshot:
        allowed.append("state-portability")
    if marker.dispute:
        allowed.append("dispute-context")
    if marker.economic:
        allowed.append("economic-portability")
    if marker.metadata:
        allowed.append("metadata-access")
    if marker.cross_domain:
        allowed.append("cross-domain-reference")

    allowed.append("basic-interaction")

    return CapabilityScope(allowed=allowed, denied=[])


def create_restricted_scope(
    allowed: list[str],
    denied: list[str],
    expires: Optional[str] = None,
) -> CapabilityScope:
    """Create a restricted capability scope."""
    return CapabilityScope(allowed=allowed, denied=denied, expires=expires)


def merge_scopes(a: CapabilityScope, b: CapabilityScope) -> CapabilityScope:
    """Merge two capability scopes. Denied always wins over allowed."""
    all_allowed = list(dict.fromkeys([*a.allowed, *b.allowed]))  # dedupe, preserve order
    all_denied = list(dict.fromkeys([*a.denied, *b.denied]))
    allowed = [cap for cap in all_allowed if cap not in all_denied]

    expires: Optional[str] = None
    if a.expires and b.expires:
        expires = a.expires if a.expires < b.expires else b.expires
    else:
        expires = a.expires or b.expires

    return CapabilityScope(allowed=allowed, denied=all_denied, expires=expires)
