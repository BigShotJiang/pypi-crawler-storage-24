"""Shared types for policy rules."""

from __future__ import annotations

from datetime import datetime
from typing import Optional, Protocol, runtime_checkable

from exit_door import ExitMarker

from ..conflict import RuleResult


class RuleContext:
    """Context passed to each rule during evaluation."""

    __slots__ = ("is_minting", "now", "minting_justification", "verified")

    def __init__(
        self,
        *,
        is_minting: bool = False,
        now: Optional[datetime] = None,
        minting_justification: Optional[str] = None,
        verified: Optional[bool] = None,
    ) -> None:
        self.is_minting = is_minting
        self.now = now or datetime.utcnow()
        self.minting_justification = minting_justification
        self.verified = verified


@runtime_checkable
class PolicyRule(Protocol):
    """Protocol for policy rules."""

    name: str

    def evaluate(self, marker: Optional[ExitMarker], ctx: RuleContext) -> RuleResult: ...
