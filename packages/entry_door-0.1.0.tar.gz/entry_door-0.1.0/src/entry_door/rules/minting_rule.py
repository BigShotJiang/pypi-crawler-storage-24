"""Minting rule — controls whether minting (admission without departure) is allowed."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from exit_door import ExitMarker

from ..conflict import RuleResult
from .types import RuleContext


@dataclass
class MintingRuleConfig:
    allowed: bool
    require_justification: Optional[bool] = None
    enhanced_probation: Optional[str] = None


def create_minting_rule(config: MintingRuleConfig) -> "_MintingRule":
    return _MintingRule(config)


@dataclass
class _MintingRule:
    _config: MintingRuleConfig
    name: str = "minting"

    def evaluate(self, marker: Optional[ExitMarker], ctx: RuleContext) -> RuleResult:
        if not ctx.is_minting:
            return RuleResult(name=self.name, decision="abstain", reason="Not a minting operation")
        if not self._config.allowed:
            return RuleResult(name=self.name, decision="deny", reason="Minting is not allowed by policy")
        if self._config.require_justification and not ctx.minting_justification:
            return RuleResult(name=self.name, decision="deny", reason="Minting requires a justification")
        conditions: list[str] = []
        if self._config.enhanced_probation:
            conditions.extend(["probation", f"probation-duration:{self._config.enhanced_probation}"])
        return RuleResult(name=self.name, decision="admit", reason="Minting allowed by policy", conditions=conditions)

    def to_json(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": "minting", "allowed": self._config.allowed}
        if self._config.require_justification is not None:
            d["requireJustification"] = self._config.require_justification
        if self._config.enhanced_probation is not None:
            d["enhancedProbation"] = self._config.enhanced_probation
        return d
