"""Typed conditions for policy rule results."""

from __future__ import annotations

import re
from typing import Literal, Optional

from pydantic import BaseModel, Field


ConditionType = Literal["quarantine", "probation", "review", "enhanced-monitoring", "risk-accepted"]


class Condition(BaseModel):
    """A typed condition attached to an admission decision."""

    type: ConditionType
    params: Optional[dict[str, str]] = None


def format_condition(c: Condition) -> str:
    """Format a Condition into a string like 'quarantine' or 'probation-duration:7d'."""
    if not c.params:
        return c.type
    return ",".join(f"{c.type}-{k}:{v}" for k, v in c.params.items())


_PARAM_RE = re.compile(r"^([a-z-]+?)-([a-z]+):(.+)$")


def parse_condition(s: str) -> Condition:
    """Parse a condition string back into a Condition."""
    m = _PARAM_RE.match(s)
    if m:
        return Condition(type=m.group(1), params={m.group(2): m.group(3)})  # type: ignore[arg-type]
    return Condition(type=s)  # type: ignore[arg-type]
