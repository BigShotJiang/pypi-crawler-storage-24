"""Confirmation level rule — checks StatusConfirmation minimum."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from exit_door import ExitMarker, StatusConfirmation, derive_status_confirmation

from ..conflict import RuleResult
from .types import RuleContext

_LEVEL_ORDER = [
    StatusConfirmation.SELF_ONLY,
    StatusConfirmation.ORIGIN_ONLY,
    StatusConfirmation.MUTUAL,
    StatusConfirmation.WITNESSED,
]


def _level_index(level: StatusConfirmation) -> int:
    try:
        return _LEVEL_ORDER.index(level)
    except ValueError:
        return 0


@dataclass
class ConfirmationRuleConfig:
    required_level: StatusConfirmation


def create_confirmation_rule(config: ConfirmationRuleConfig) -> "_ConfirmationRule":
    return _ConfirmationRule(config)


@dataclass
class _ConfirmationRule:
    _config: ConfirmationRuleConfig
    name: str = "confirmation-level"

    def evaluate(self, marker: Optional[ExitMarker], ctx: RuleContext) -> RuleResult:
        if ctx.is_minting or marker is None:
            return RuleResult(name=self.name, decision="abstain", reason="No marker to check confirmation")
        actual = derive_status_confirmation(marker)
        if _level_index(actual) >= _level_index(self._config.required_level):
            return RuleResult(name=self.name, decision="admit", reason=f"Confirmation level {actual} meets minimum {self._config.required_level}")
        return RuleResult(name=self.name, decision="deny", reason=f"Confirmation level {actual} below required {self._config.required_level}")

    def to_json(self) -> dict[str, Any]:
        return {"type": "confirmation-level", "requiredLevel": self._config.required_level}
