"""Origin rule — allowlist/blocklist with required reasons for blocks."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Optional

from exit_door import ExitMarker

from ..conflict import RuleResult
from .types import RuleContext

BlockReasonCategory = Literal["security", "compliance", "operational", "other"]


@dataclass
class BlockReason:
    category: BlockReasonCategory
    detail: str


@dataclass
class BlockedOriginEntry:
    origin: str
    reason: str | BlockReason
    expires_at: Optional[str] = None


@dataclass
class OriginRuleConfig:
    blocked_origins: Optional[list[BlockedOriginEntry]] = None
    allowed_origins: Optional[list[str]] = None


def create_origin_rule(config: OriginRuleConfig) -> "_OriginRule":
    return _OriginRule(config)


@dataclass
class _OriginRule:
    _config: OriginRuleConfig
    name: str = "origin-check"

    def evaluate(self, marker: Optional[ExitMarker], ctx: RuleContext) -> RuleResult:
        if ctx.is_minting or marker is None:
            return RuleResult(name=self.name, decision="abstain", reason="No marker to check origin")

        origin = marker.origin

        if self._config.blocked_origins:
            from datetime import datetime
            now_ts = ctx.now.timestamp() * 1000  # ms
            for b in self._config.blocked_origins:
                if b.origin != origin:
                    continue
                if b.expires_at:
                    from datetime import timezone
                    exp = datetime.fromisoformat(b.expires_at.replace("Z", "+00:00")).timestamp() * 1000
                    if exp <= now_ts:
                        continue
                reason_str = b.reason if isinstance(b.reason, str) else f"[{b.reason.category}] {b.reason.detail}"
                return RuleResult(name=self.name, decision="deny", reason=f'Origin "{origin}" is blocked: {reason_str}')

        if self._config.allowed_origins and len(self._config.allowed_origins) > 0:
            if origin not in self._config.allowed_origins:
                return RuleResult(name=self.name, decision="deny", reason=f'Origin "{origin}" not in allowed list')

        return RuleResult(name=self.name, decision="admit", reason=f'Origin "{origin}" is acceptable')

    def to_json(self) -> dict[str, Any]:
        result: dict[str, Any] = {"type": "origin-check"}
        if self._config.blocked_origins:
            result["blockedOrigins"] = [
                {"origin": b.origin, "reason": b.reason if isinstance(b.reason, str) else {"category": b.reason.category, "detail": b.reason.detail}, **({"expiresAt": b.expires_at} if b.expires_at else {})}
                for b in self._config.blocked_origins
            ]
        if self._config.allowed_origins:
            result["allowedOrigins"] = self._config.allowed_origins
        return result
