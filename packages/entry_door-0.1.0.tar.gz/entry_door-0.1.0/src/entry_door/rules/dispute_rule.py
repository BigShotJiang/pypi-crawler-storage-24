"""Dispute rule — handles disputed markers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Optional

from exit_door import ExitMarker

from ..conflict import RuleResult
from .condition import Condition, format_condition
from .types import RuleContext

DisputeAction = Literal["reject", "quarantine", "manual_review"]


@dataclass
class DisputeRuleConfig:
    action: DisputeAction
    max_duration: Optional[str] = None
    review_required: Optional[bool] = None


def _is_disputed(marker: ExitMarker) -> bool:
    return bool(marker.dispute and getattr(marker.dispute, "disputes", None) and len(marker.dispute.disputes) > 0)


def create_dispute_rule(config: DisputeRuleConfig) -> "_DisputeRule":
    return _DisputeRule(config)


@dataclass
class _DisputeRule:
    _config: DisputeRuleConfig
    name: str = "dispute-check"

    def evaluate(self, marker: Optional[ExitMarker], ctx: RuleContext) -> RuleResult:
        if ctx.is_minting or marker is None:
            return RuleResult(name=self.name, decision="abstain", reason="No marker to check disputes")
        if not _is_disputed(marker):
            return RuleResult(name=self.name, decision="abstain", reason="Marker is not disputed")

        action = self._config.action
        if action == "reject":
            return RuleResult(name=self.name, decision="deny", reason="Disputed marker rejected by policy")
        if action == "quarantine":
            conds = [format_condition(Condition(type="quarantine"))]
            if self._config.max_duration:
                conds.append(format_condition(Condition(type="quarantine", params={"max": self._config.max_duration})))
            if self._config.review_required:
                conds.append(format_condition(Condition(type="review")))
            return RuleResult(name=self.name, decision="admit", reason="Disputed marker quarantined for review", conditions=conds)
        # manual_review
        return RuleResult(name=self.name, decision="admit", reason="Disputed marker admitted pending manual review", conditions=["manual-review-required"])

    def to_json(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": "dispute-check", "action": self._config.action}
        if self._config.max_duration:
            d["maxDuration"] = self._config.max_duration
        if self._config.review_required:
            d["reviewRequired"] = self._config.review_required
        return d
