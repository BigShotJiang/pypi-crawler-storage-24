"""Custom rule — user-defined evaluation functions. NOT serializable."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

from exit_door import ExitMarker

from ..conflict import RuleResult
from .types import RuleContext

CustomRuleFn = Callable[[Optional[ExitMarker], RuleContext], "CustomRuleResult"]


@dataclass
class CustomRuleResult:
    admitted: Optional[bool] = None
    """True=admit, False=deny, None=abstain."""
    conditions: Optional[list[str]] = None
    reason: Optional[str] = None

    @property
    def abstained(self) -> bool:
        return self.admitted is None


def create_custom_rule(name: str, fn: CustomRuleFn) -> "_CustomRule":
    return _CustomRule(rule_name=name, fn=fn)


@dataclass
class _CustomRule:
    rule_name: str
    fn: CustomRuleFn

    @property
    def name(self) -> str:
        return self.rule_name

    def evaluate(self, marker: Optional[ExitMarker], ctx: RuleContext) -> RuleResult:
        result = self.fn(marker, ctx)
        if result.admitted is None:
            decision = "abstain"
            default_reason = "Custom rule abstained"
        elif result.admitted:
            decision = "admit"
            default_reason = "Custom rule passed"
        else:
            decision = "deny"
            default_reason = "Custom rule failed"
        return RuleResult(
            name=self.rule_name,
            decision=decision,
            reason=result.reason or default_reason,
            conditions=result.conditions or [],
        )
