"""Trust level rule — self_only → probation mapping."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Optional

from exit_door import ExitMarker, StatusConfirmation, derive_status_confirmation

from ..conflict import RuleResult
from .condition import Condition, format_condition
from .types import RuleContext

SelfOnlyAction = Literal["probation", "reject", "admit"]


@dataclass
class TrustLevelRuleConfig:
    action: SelfOnlyAction
    probation_duration: Optional[str] = None


def create_trust_level_rule(config: TrustLevelRuleConfig) -> "_TrustLevelRule":
    return _TrustLevelRule(config)


@dataclass
class _TrustLevelRule:
    _config: TrustLevelRuleConfig
    name: str = "trust-level"

    def evaluate(self, marker: Optional[ExitMarker], ctx: RuleContext) -> RuleResult:
        if ctx.is_minting or marker is None:
            return RuleResult(name=self.name, decision="abstain", reason="No marker to check trust level")
        level = derive_status_confirmation(marker)
        if level != StatusConfirmation.SELF_ONLY:
            return RuleResult(name=self.name, decision="abstain", reason=f"Trust level {level} is not self_only")

        action = self._config.action
        if action == "reject":
            return RuleResult(name=self.name, decision="deny", reason="Self-only markers rejected by policy")
        if action == "probation":
            conds = [format_condition(Condition(type="probation"))]
            if self._config.probation_duration:
                conds.append(format_condition(Condition(type="probation", params={"duration": self._config.probation_duration})))
            return RuleResult(name=self.name, decision="admit", reason="Self-only marker admitted with probation", conditions=conds)
        # admit
        return RuleResult(name=self.name, decision="admit", reason="Self-only marker admitted")

    def to_json(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": "trust-level", "action": self._config.action}
        if self._config.probation_duration:
            d["probationDuration"] = self._config.probation_duration
        return d
