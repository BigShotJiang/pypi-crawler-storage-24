"""Policy Builder v2 — fluent builder for composable, serializable admission policies."""

from __future__ import annotations

import copy
from datetime import datetime
from dataclasses import dataclass, field
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field
from exit_door import ExitMarker, StatusConfirmation

from .admission_policy import parse_duration
from .conflict import ConflictStrategy, ResolvedDecision, RuleResult, resolve_conflict
from .rules.types import PolicyRule, RuleContext
from .rules.confirmation_rule import ConfirmationRuleConfig, create_confirmation_rule
from .rules.origin_rule import BlockedOriginEntry, OriginRuleConfig, create_origin_rule
from .rules.dispute_rule import DisputeAction, DisputeRuleConfig, create_dispute_rule
from .rules.trust_level_rule import SelfOnlyAction, TrustLevelRuleConfig, create_trust_level_rule
from .rules.minting_rule import MintingRuleConfig, create_minting_rule
from .rules.custom_rule import CustomRuleFn, create_custom_rule


@dataclass
class EvaluationTrace:
    policy_name: str
    rules: list[RuleResult]
    decision: ResolvedDecision
    timestamp: str


class PolicyJSON(BaseModel):
    """Serializable policy snapshot with camelCase JSON keys."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    conflict_strategy: ConflictStrategy = Field(alias="conflictStrategy")
    rules: list[dict[str, Any]]
    custom_rules_omitted: list[str] = Field(alias="customRulesOmitted")
    default_decision: Literal["admit", "deny"] = Field(default="deny", alias="defaultDecision")


def _build_context(partial: Optional[dict[str, Any]] = None) -> RuleContext:
    p = partial or {}
    return RuleContext(
        is_minting=p.get("is_minting", False),
        now=p.get("now"),
        minting_justification=p.get("minting_justification"),
        verified=p.get("verified"),
    )


class BuiltPolicy:
    """An immutable, evaluated admission policy."""

    def __init__(
        self,
        name: str,
        rules: list[Any],
        conflict_strategy: ConflictStrategy,
        default_decision: Literal["admit", "deny"],
        rule_configs: list[Optional[dict[str, Any]]],
        warnings: Optional[list[str]] = None,
    ) -> None:
        self.name = name
        self.rules = rules
        self.conflict_strategy = conflict_strategy
        self.default_decision = default_decision
        self._rule_configs = rule_configs
        self._warnings = warnings

    def evaluate(self, marker: Optional[ExitMarker] = None, ctx: Optional[dict[str, Any]] = None) -> ResolvedDecision:
        context = _build_context(ctx)
        results = [r.evaluate(marker, context) for r in self.rules]
        return resolve_conflict(results, self.conflict_strategy, self.default_decision)

    def dry_run(self, marker: Optional[ExitMarker] = None, ctx: Optional[dict[str, Any]] = None) -> EvaluationTrace:
        context = _build_context(ctx)
        results = [r.evaluate(marker, context) for r in self.rules]
        decision = resolve_conflict(results, self.conflict_strategy, self.default_decision)
        return EvaluationTrace(
            policy_name=self.name,
            rules=results,
            decision=decision,
            timestamp=datetime.utcnow().isoformat(),
        )

    def to_json(self) -> PolicyJSON:
        serializable: list[dict[str, Any]] = []
        custom_omitted: list[str] = []
        for i, rule in enumerate(self.rules):
            cfg = self._rule_configs[i] if i < len(self._rule_configs) else None
            if cfg is not None:
                serializable.append({**cfg.get("config", {}), "type": cfg["type"]})
            else:
                custom_omitted.append(rule.name)
        return PolicyJSON(
            name=self.name,
            conflict_strategy=self.conflict_strategy,
            rules=serializable,
            custom_rules_omitted=custom_omitted,
            default_decision=self.default_decision,
        )


_CONFIRMATION_MAP: dict[str, StatusConfirmation] = {
    "self_only": StatusConfirmation.SELF_ONLY,
    "origin_only": StatusConfirmation.ORIGIN_ONLY,
    "mutual": StatusConfirmation.MUTUAL,
    "witnessed": StatusConfirmation.WITNESSED,
}


class PolicyBuilder:
    """Fluent policy builder."""

    def __init__(self, name: str) -> None:
        self._name = name
        self._rules: list[Any] = []
        self._strategy: ConflictStrategy = "deny-overrides"
        self._default_decision: Literal["admit", "deny"] = "deny"
        self._rule_configs: list[Optional[dict[str, Any]]] = []
        self._warnings: list[str] = []

    def require_confirmation(self, level: str | StatusConfirmation) -> "PolicyBuilder":
        resolved = _CONFIRMATION_MAP.get(level, level) if isinstance(level, str) else level
        self._rules.append(create_confirmation_rule(ConfirmationRuleConfig(required_level=resolved)))
        self._rule_configs.append({"type": "confirmation-level", "config": {"requiredLevel": resolved}})
        return self

    def require_verified_departure(self) -> "PolicyBuilder":
        self._rules.append(_VerifiedDepartureRule())
        self._rule_configs.append({"type": "verified-departure", "config": {}})
        return self

    def max_age(self, duration: str | int) -> "PolicyBuilder":
        max_ms = parse_duration(duration) if isinstance(duration, str) else duration
        dur_str = duration if isinstance(duration, str) else f"{duration}ms"
        self._rules.append(_MaxAgeRule(max_ms=max_ms, dur_str=dur_str))
        self._rule_configs.append({"type": "max-age", "config": {"duration": dur_str}})
        return self

    def allow_exit_types(self, types: list[str]) -> "PolicyBuilder":
        self._rules.append(_ExitTypeRule(allowed_types=types))
        self._rule_configs.append({"type": "exit-type", "config": {"allowedTypes": types}})
        return self

    def block_origins(self, origins: list[str], *, reason: str) -> "PolicyBuilder":
        blocked = [BlockedOriginEntry(origin=o, reason=reason) for o in origins]
        self._rules.append(create_origin_rule(OriginRuleConfig(blocked_origins=blocked)))
        self._rule_configs.append({"type": "origin-check", "config": {"blockedOrigins": [{"origin": o, "reason": reason} for o in origins]}})
        return self

    def allow_origins(self, origins: list[str]) -> "PolicyBuilder":
        self._rules.append(create_origin_rule(OriginRuleConfig(allowed_origins=origins)))
        self._rule_configs.append({"type": "origin-check", "config": {"allowedOrigins": origins}})
        return self

    def require_modules(self, modules: list[str]) -> "PolicyBuilder":
        self._rules.append(_RequiredModulesRule(modules=modules))
        self._rule_configs.append({"type": "required-modules", "config": {"modules": modules}})
        return self

    def on_disputed(self, action: DisputeAction, *, max_duration: Optional[str] = None, review_required: Optional[bool] = None) -> "PolicyBuilder":
        self._rules.append(create_dispute_rule(DisputeRuleConfig(action=action, max_duration=max_duration, review_required=review_required)))
        cfg: dict[str, Any] = {"action": action}
        if max_duration:
            cfg["maxDuration"] = max_duration
        if review_required:
            cfg["reviewRequired"] = review_required
        self._rule_configs.append({"type": "dispute-check", "config": cfg})
        return self

    def on_self_only(self, action: SelfOnlyAction, *, duration: Optional[str] = None) -> "PolicyBuilder":
        self._rules.append(create_trust_level_rule(TrustLevelRuleConfig(action=action, probation_duration=duration)))
        cfg: dict[str, Any] = {"action": action}
        if duration:
            cfg["probationDuration"] = duration
        self._rule_configs.append({"type": "trust-level", "config": cfg})
        return self

    def allow_minting(self, *, require_justification: Optional[bool] = None, enhanced_probation: Optional[str] = None) -> "PolicyBuilder":
        self._rules.append(create_minting_rule(MintingRuleConfig(allowed=True, require_justification=require_justification, enhanced_probation=enhanced_probation)))
        cfg: dict[str, Any] = {"allowed": True}
        if require_justification is not None:
            cfg["requireJustification"] = require_justification
        if enhanced_probation is not None:
            cfg["enhancedProbation"] = enhanced_probation
        self._rule_configs.append({"type": "minting", "config": cfg})
        return self

    def custom(self, name: str, fn: CustomRuleFn) -> "PolicyBuilder":
        self._rules.append(create_custom_rule(name, fn))
        self._rule_configs.append(None)
        return self

    def conflict_resolution(self, strategy: ConflictStrategy) -> "PolicyBuilder":
        self._strategy = strategy
        return self

    def default_decision(self, decision: Literal["admit", "deny"]) -> "PolicyBuilder":
        self._default_decision = decision
        return self

    def build(self) -> BuiltPolicy:
        return BuiltPolicy(
            name=self._name,
            rules=list(self._rules),
            conflict_strategy=self._strategy,
            default_decision=self._default_decision,
            rule_configs=list(self._rule_configs),
            warnings=list(self._warnings) if self._warnings else None,
        )

    @classmethod
    def from_json(cls, json_data: PolicyJSON) -> "PolicyBuilder":
        builder = cls(json_data.name)
        builder._strategy = json_data.conflict_strategy
        builder._default_decision = json_data.default_decision
        for rule in json_data.rules:
            rule_type = rule.get("type")
            if rule_type == "confirmation-level":
                builder.require_confirmation(rule["requiredLevel"])
            elif rule_type == "verified-departure":
                builder.require_verified_departure()
            elif rule_type == "max-age":
                builder.max_age(rule["duration"])
            elif rule_type == "exit-type":
                builder.allow_exit_types(rule["allowedTypes"])
            elif rule_type == "origin-check":
                if "blockedOrigins" in rule:
                    blocked = rule["blockedOrigins"]
                    origins = [b["origin"] for b in blocked]
                    builder.block_origins(origins, reason=blocked[0].get("reason", "Blocked") if blocked else "Blocked")
                if "allowedOrigins" in rule:
                    builder.allow_origins(rule["allowedOrigins"])
            elif rule_type == "required-modules":
                builder.require_modules(rule["modules"])
            elif rule_type == "dispute-check":
                builder.on_disputed(rule["action"], max_duration=rule.get("maxDuration"), review_required=rule.get("reviewRequired"))
            elif rule_type == "trust-level":
                builder.on_self_only(rule["action"], duration=rule.get("probationDuration"))
            elif rule_type == "minting":
                builder.allow_minting(require_justification=rule.get("requireJustification"), enhanced_probation=rule.get("enhancedProbation"))
            else:
                builder._warnings.append(f"Unknown rule type: {rule_type}")
        return builder


def create_policy(name: str) -> PolicyBuilder:
    """Create a new policy builder."""
    return PolicyBuilder(name)


# ─── Helper rule classes ──────────────────────────────────────────────────────


@dataclass
class _VerifiedDepartureRule:
    """Checks that a departure marker has a proof attached (non-empty proof_value).

    NOTE (PE-01): This rule only checks for *proof presence*, not cryptographic
    validity.  Full signature verification happens in ``admit()`` step 0.5 using
    ``verify_departure()``, which has access to the actual key material.  The
    purpose of this rule is to reject markers that carry no proof at all before
    the more expensive crypto verification runs.
    """

    name: str = "verified-departure"

    def evaluate(self, marker: Optional[ExitMarker], ctx: RuleContext) -> RuleResult:
        if ctx.is_minting or marker is None:
            return RuleResult(name=self.name, decision="abstain", reason="No marker to verify")
        # Only checks proof *presence* – crypto verification is in admit() step 0.5
        if not (marker.proof and marker.proof.proof_value):
            return RuleResult(name=self.name, decision="deny", reason="Departure marker has no proof")
        return RuleResult(name=self.name, decision="admit", reason="Departure is signed")

    def to_json(self) -> dict[str, Any]:
        return {"type": "verified-departure"}


@dataclass
class _MaxAgeRule:
    max_ms: int
    dur_str: str
    name: str = "max-age"

    def evaluate(self, marker: Optional[ExitMarker], ctx: RuleContext) -> RuleResult:
        if ctx.is_minting or marker is None:
            return RuleResult(name=self.name, decision="abstain", reason="No marker to check age")
        marker_ts = datetime.fromisoformat(marker.timestamp.replace("Z", "+00:00"))
        age_ms = int((ctx.now.timestamp() - marker_ts.timestamp()) * 1000)
        if age_ms > self.max_ms:
            return RuleResult(name=self.name, decision="deny", reason=f"Marker is {age_ms}ms old, exceeds {self.dur_str}")
        return RuleResult(name=self.name, decision="admit", reason=f"Marker age {age_ms}ms within {self.dur_str}")

    def to_json(self) -> dict[str, Any]:
        return {"type": "max-age", "duration": self.dur_str}


@dataclass
class _ExitTypeRule:
    allowed_types: list[str]
    name: str = "exit-type"

    def evaluate(self, marker: Optional[ExitMarker], ctx: RuleContext) -> RuleResult:
        if ctx.is_minting or marker is None:
            return RuleResult(name=self.name, decision="abstain", reason="No marker to check exit type")
        if marker.exit_type in self.allowed_types:
            return RuleResult(name=self.name, decision="admit", reason=f'Exit type "{marker.exit_type}" is allowed')
        return RuleResult(name=self.name, decision="deny", reason=f'Exit type "{marker.exit_type}" not in {", ".join(self.allowed_types)}')

    def to_json(self) -> dict[str, Any]:
        return {"type": "exit-type", "allowedTypes": self.allowed_types}


@dataclass
class _RequiredModulesRule:
    modules: list[str]
    name: str = "required-modules"

    def evaluate(self, marker: Optional[ExitMarker], ctx: RuleContext) -> RuleResult:
        if ctx.is_minting or marker is None:
            return RuleResult(name=self.name, decision="abstain", reason="No marker to check modules")
        missing = [m for m in self.modules if not getattr(marker, m, None)]
        if missing:
            return RuleResult(name=self.name, decision="deny", reason=f"Missing modules: {', '.join(missing)}")
        return RuleResult(name=self.name, decision="admit", reason="All required modules present")

    def to_json(self) -> dict[str, Any]:
        return {"type": "required-modules", "modules": self.modules}


# ─── Preset Policy Factories ──────────────────────────────────────────────────
# Each function returns a *fresh* BuiltPolicy so callers cannot mutate shared
# state (PE-04).


def _make_require_mutual() -> BuiltPolicy:
    return (
        create_policy("require-mutual")
        .require_confirmation("mutual")
        .require_verified_departure()
        .build()
    )


def _make_require_mutual_with_onramp() -> BuiltPolicy:
    return (
        create_policy("require-mutual-with-onramp")
        .require_confirmation("mutual")
        .require_verified_departure()
        .allow_minting(require_justification=True, enhanced_probation="14d")
        .build()
    )


def _make_cautious() -> BuiltPolicy:
    return (
        create_policy("cautious")
        .require_verified_departure()
        .on_self_only("probation", duration="7d")
        .on_disputed("quarantine", max_duration="7d", review_required=True)
        .allow_minting(require_justification=True, enhanced_probation="14d")
        .build()
    )


def _make_open_door_v2() -> BuiltPolicy:
    return (
        create_policy("open-door")
        .default_decision("admit")
        .build()
    )


def _make_quarantine_unknown() -> BuiltPolicy:
    return (
        create_policy("quarantine-unknown")
        .require_verified_departure()
        .on_disputed("quarantine", max_duration="7d", review_required=True)
        .build()
    )


def _make_permissive() -> BuiltPolicy:
    return (
        create_policy("permissive")
        .default_decision("admit")
        .on_self_only("probation", duration="7d")
        .allow_minting()
        .build()
    )


def _make_lockdown() -> BuiltPolicy:
    return create_policy("lockdown").build()


class _PresetProxy:
    """Module-level descriptor that builds a fresh BuiltPolicy on every access.

    This keeps the ``CAUTIOUS``, ``LOCKDOWN``, etc. names importable and
    usable exactly as before, but each access yields an independent copy so
    mutations never leak across callers.
    """

    def __init__(self, factory):
        self._factory = factory

    def __repr__(self):
        return repr(self._factory())

    # Make instances behave like BuiltPolicy via __getattr__ delegation
    def __getattr__(self, name):
        return getattr(self._factory(), name)

    def __call__(self, *args, **kwargs):
        # Allow using as factory directly: CAUTIOUS() also works
        return self._factory()


# Backward-compatible module-level names.  Every attribute access builds a
# fresh policy so mutations are isolated (PE-04).
REQUIRE_MUTUAL = _PresetProxy(_make_require_mutual)
REQUIRE_MUTUAL_WITH_ONRAMP = _PresetProxy(_make_require_mutual_with_onramp)
CAUTIOUS = _PresetProxy(_make_cautious)
OPEN_DOOR_V2 = _PresetProxy(_make_open_door_v2)
QUARANTINE_UNKNOWN = _PresetProxy(_make_quarantine_unknown)
PERMISSIVE = _PresetProxy(_make_permissive)
LOCKDOWN = _PresetProxy(_make_lockdown)
