"""Convenience Methods — quickEntry, quickEntryP256, quickAdmit."""

from __future__ import annotations

import warnings
from dataclasses import dataclass
from typing import Any, Optional

from exit_door import (
    ExitMarker,
    from_json,
    generate_key_pair,
    generate_p256_key_pair,
)

from .arrival import create_arrival_marker
from .continuity import verify_continuity
from .models import ArrivalMarker, ContinuityResult, CreateArrivalOpts
from .sign import SignatureAlgorithm, sign_arrival_marker


@dataclass
class QuickEntryResult:
    arrival_marker: ArrivalMarker
    exit_marker: ExitMarker
    continuity: ContinuityResult


class QuickEntryOpts(CreateArrivalOpts):
    algorithm: Optional[SignatureAlgorithm] = None


def quick_entry(
    exit_marker_json: str,
    destination: str,
    opts: Optional[QuickEntryOpts] = None,
) -> QuickEntryResult:
    """One-shot: parse EXIT marker JSON, verify, create signed arrival, verify continuity.

    ⚠️ WARNING: Generates ephemeral keys for testing only.
    """
    algorithm: SignatureAlgorithm = (opts.algorithm if opts and opts.algorithm else "Ed25519")
    exit_marker = from_json(exit_marker_json)
    arrival = create_arrival_marker(exit_marker, destination, opts)

    warnings.warn(
        "[entry-door] quick_entry() uses an ephemeral keypair that is discarded after signing. "
        "For production, use create_arrival_marker() + sign_arrival_marker() with a persistent key.",
        stacklevel=2,
    )

    if algorithm == "P-256":
        kp = generate_p256_key_pair()
    else:
        kp = generate_key_pair()

    signed = sign_arrival_marker(arrival, kp.private_key, kp.public_key, algorithm)
    continuity = verify_continuity(exit_marker, signed)

    return QuickEntryResult(
        arrival_marker=signed,
        exit_marker=exit_marker,
        continuity=continuity,
    )


class QuickAdmitOpts:
    """Options for quick_admit convenience function."""

    def __init__(
        self,
        *,
        platform_identity: Optional[dict[str, bytes]] = None,
        policy: Optional[Any] = None,
        counter_sign_meaning: Optional[str] = None,
        destination: Optional[str] = None,
        counter_sign: Optional[bool] = None,
        minting_subject: Optional[str] = None,
        minting_justification: Optional[str] = None,
    ) -> None:
        self.platform_identity = platform_identity
        self.policy = policy
        self.counter_sign_meaning = counter_sign_meaning
        self.destination = destination
        self.counter_sign = counter_sign
        self.minting_subject = minting_subject
        self.minting_justification = minting_justification


def quick_admit(
    exit_marker: Optional[ExitMarker | str] = None,
    opts: Optional[QuickAdmitOpts] = None,
) -> dict[str, Any]:
    """One-shot admit ceremony with sensible defaults.

    Works in three modes:
    1. With exit marker + counter-sign (default when marker provided)
    2. With exit marker, no counter-sign
    3. No exit marker — minting

    Generates ephemeral platform identity if none provided.
    """
    from .admit import admit, AdmitOpts
    from .policy_builder import CAUTIOUS

    marker: Optional[ExitMarker] = None
    if isinstance(exit_marker, str):
        marker = from_json(exit_marker)
    elif exit_marker is not None:
        marker = exit_marker

    if opts is None:
        opts = QuickAdmitOpts()

    platform_identity = opts.platform_identity
    if platform_identity is None:
        warnings.warn(
            "[entry-door] quick_admit() is generating an ephemeral keypair. "
            "For production, pass platform_identity with persistent keys.",
            stacklevel=2,
        )
        kp = generate_key_pair()
        platform_identity = {"private_key": kp.private_key, "public_key": kp.public_key}

    return admit(marker, AdmitOpts(
        platform_identity=platform_identity,
        policy=opts.policy or CAUTIOUS,
        counter_sign_meaning=opts.counter_sign_meaning or "receipt_only",
        destination=opts.destination or "https://destination.example.com",
        counter_sign=opts.counter_sign,
        minting_subject=opts.minting_subject,
        minting_justification=opts.minting_justification,
    ))


def quick_entry_p256(
    exit_marker_json: str,
    destination: str,
    opts: Optional[CreateArrivalOpts] = None,
) -> QuickEntryResult:
    """Convenience alias: create a P-256 ENTRY marker in one call.

    ⚠️ WARNING: Generates ephemeral keys for testing only.
    """
    qe_opts = QuickEntryOpts(
        admission_type=opts.admission_type if opts else None,
        conditions=opts.conditions if opts else None,
        timestamp=opts.timestamp if opts else None,
        probation=opts.probation if opts else None,
        capability_scope=opts.capability_scope if opts else None,
        algorithm="P-256",
    )
    return quick_entry(exit_marker_json, destination, qe_opts)
