"""entry-door — Verifiable Arrival Markers for Cellar Door."""

__version__ = "0.1.0"

# ── Core – Arrival Markers ────────────────────────────────────────────────────
from .models import (
    ENTRY_CONTEXT_V1,
    AdmissionType,
    ArrivalMarker,
    ArrivalProof,
    ArrivalProofType,
    CapabilityScope,
    ContinuityResult,
    CreateArrivalOpts,
    ProbationInfo,
    VerificationResult,
)

from .arrival import (
    canonicalize,
    compute_arrival_id,
    create_arrival_marker,
)

# ── Verification ──────────────────────────────────────────────────────────────
from .verify_departure import (
    verify_departure,
    verify_departure_json,
    VerifyDepartureJSONResult,
    VerifyDepartureJSONResultFailed,
    VerifyDepartureJSONResultParsed,
)

from .validation import (
    MAX_MARKER_SIZE,
    ValidationResult,
    validate_arrival_marker,
)

from .continuity import verify_continuity

# ── Signing ───────────────────────────────────────────────────────────────────
from .sign import (
    ArrivalVerificationResult,
    SignatureAlgorithm,
    sign_arrival_marker,
    verify_arrival_marker,
)

# ── Convenience (start here!) ─────────────────────────────────────────────────
from .convenience import (
    QuickAdmitOpts,
    QuickEntryOpts,
    QuickEntryResult,
    quick_admit,
    quick_entry,
    quick_entry_p256,
)

# ── Policy Engine ─────────────────────────────────────────────────────────────
from .admission_policy import (
    AdmissionPolicy,
    AdmissionResult,
    EMERGENCY_ONLY,
    OPEN_DOOR,
    STRICT,
    evaluate_admission,
    parse_duration,
)

from .conflict import (
    ConflictStrategy,
    ResolvedDecision,
    RuleDecision,
    RuleResult,
    resolve_conflict,
)

from .rules import (
    PolicyRule,
    RuleContext,
    Condition,
    ConditionType,
    format_condition,
    parse_condition,
    ConfirmationRuleConfig,
    create_confirmation_rule,
    BlockReason,
    BlockReasonCategory,
    BlockedOriginEntry,
    OriginRuleConfig,
    create_origin_rule,
    DisputeAction,
    DisputeRuleConfig,
    create_dispute_rule,
    SelfOnlyAction,
    TrustLevelRuleConfig,
    create_trust_level_rule,
    MintingRuleConfig,
    create_minting_rule,
    CustomRuleFn,
    CustomRuleResult,
    create_custom_rule,
)

from .policy_builder import (
    BuiltPolicy,
    EvaluationTrace,
    PolicyBuilder,
    PolicyJSON,
    create_policy,
    CAUTIOUS,
    LOCKDOWN,
    OPEN_DOOR_V2,
    PERMISSIVE,
    QUARANTINE_UNKNOWN,
    REQUIRE_MUTUAL,
    REQUIRE_MUTUAL_WITH_ONRAMP,
)

# ── Admission Ceremony ────────────────────────────────────────────────────────
from .admit import (
    AdmissionRecord,
    AdmissionStore,
    AdmitOpts,
    AdmitResult,
    CounterSignMeaning,
    admit,
    is_admission_store,
)

from .mint import (
    BulkMintAgent,
    MintOpts,
    bulk_mint,
    mint_agent,
)

# ── Probation & Capability Scoping ───────────────────────────────────────────
from .probation import (
    ProbationConfig,
    create_probationary_arrival,
    is_probation_complete,
)

from .capability_scope import (
    create_restricted_scope,
    merge_scopes,
    scope_from_exit_marker,
)

# ── Storage ───────────────────────────────────────────────────────────────────
from .claim_tracking import (
    ClaimStore,
    InMemoryClaimStore,
)

from .sqlite_store import SqliteClaimStore

# ── Revocation & Transfer ────────────────────────────────────────────────────
from .revocation import (
    RevocationAlgorithm,
    RevocationMarker,
    RevocationProof,
    RevocationVerificationResult,
    create_revocation_marker,
    is_revoked,
    verify_revocation_marker,
)

from .transfer import (
    TransferRecord,
    verify_transfer,
)

# ── Events ────────────────────────────────────────────────────────────────────
from .events import (
    AdmissionEvent,
    AdmissionEventEmitter,
    AdmissionEventType,
    EventHandler,
    ErrorHandler,
)

__all__ = [
    # Constants
    "ENTRY_CONTEXT_V1",
    "MAX_MARKER_SIZE",
    # Core – Arrival Markers
    "AdmissionType",
    "ArrivalMarker",
    "ArrivalProof",
    "ArrivalProofType",
    "CapabilityScope",
    "ContinuityResult",
    "CreateArrivalOpts",
    "ProbationInfo",
    "VerificationResult",
    "ValidationResult",
    "canonicalize",
    "compute_arrival_id",
    "create_arrival_marker",
    # Verification
    "verify_departure",
    "verify_departure_json",
    "VerifyDepartureJSONResult",
    "VerifyDepartureJSONResultFailed",
    "VerifyDepartureJSONResultParsed",
    "verify_continuity",
    "validate_arrival_marker",
    # Signing
    "ArrivalVerificationResult",
    "SignatureAlgorithm",
    "sign_arrival_marker",
    "verify_arrival_marker",
    # Convenience (start here!)
    "QuickAdmitOpts",
    "QuickEntryOpts",
    "QuickEntryResult",
    "quick_admit",
    "quick_entry",
    "quick_entry_p256",
    # Policy Engine
    "AdmissionPolicy",
    "AdmissionResult",
    "EMERGENCY_ONLY",
    "OPEN_DOOR",
    "STRICT",
    "evaluate_admission",
    "parse_duration",
    "ConflictStrategy",
    "ResolvedDecision",
    "RuleDecision",
    "RuleResult",
    "resolve_conflict",
    "PolicyRule",
    "RuleContext",
    "Condition",
    "ConditionType",
    "format_condition",
    "parse_condition",
    "ConfirmationRuleConfig",
    "create_confirmation_rule",
    "BlockReason",
    "BlockReasonCategory",
    "BlockedOriginEntry",
    "OriginRuleConfig",
    "create_origin_rule",
    "DisputeAction",
    "DisputeRuleConfig",
    "create_dispute_rule",
    "SelfOnlyAction",
    "TrustLevelRuleConfig",
    "create_trust_level_rule",
    "MintingRuleConfig",
    "create_minting_rule",
    "CustomRuleFn",
    "CustomRuleResult",
    "create_custom_rule",
    "BuiltPolicy",
    "EvaluationTrace",
    "PolicyBuilder",
    "PolicyJSON",
    "create_policy",
    "CAUTIOUS",
    "LOCKDOWN",
    "OPEN_DOOR_V2",
    "PERMISSIVE",
    "QUARANTINE_UNKNOWN",
    "REQUIRE_MUTUAL",
    "REQUIRE_MUTUAL_WITH_ONRAMP",
    # Admission Ceremony
    "AdmissionRecord",
    "AdmissionStore",
    "AdmitOpts",
    "AdmitResult",
    "CounterSignMeaning",
    "admit",
    "is_admission_store",
    "BulkMintAgent",
    "MintOpts",
    "bulk_mint",
    "mint_agent",
    # Probation & Capability Scoping
    "ProbationConfig",
    "create_probationary_arrival",
    "is_probation_complete",
    "create_restricted_scope",
    "merge_scopes",
    "scope_from_exit_marker",
    # Storage
    "ClaimStore",
    "InMemoryClaimStore",
    "SqliteClaimStore",
    # Revocation & Transfer
    "RevocationAlgorithm",
    "RevocationMarker",
    "RevocationProof",
    "RevocationVerificationResult",
    "create_revocation_marker",
    "is_revoked",
    "verify_revocation_marker",
    "TransferRecord",
    "verify_transfer",
    # Events
    "AdmissionEvent",
    "AdmissionEventEmitter",
    "AdmissionEventType",
    "EventHandler",
    "ErrorHandler",
]
