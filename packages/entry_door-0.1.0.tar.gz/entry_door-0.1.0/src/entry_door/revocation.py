"""Revocation — revoke arrivals after the fact."""

from __future__ import annotations

import base64
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Literal, Optional

from exit_door import (
    algorithm_from_did,
    did_from_p256_public_key,
    did_from_public_key,
    public_key_from_did,
    sign,
    sign_p256,
    verify,
    verify_p256,
)

from .arrival import canonicalize
from .models import ArrivalMarker

RevocationAlgorithm = Literal["Ed25519", "P-256"]

DOMAIN_PREFIX = "entry-revocation-v1.0:"


@dataclass
class RevocationProof:
    type: Literal["Ed25519Signature2020", "EcdsaP256Signature2019"]
    created: str
    verification_method: str
    proof_value: str


@dataclass
class RevocationMarker:
    type: Literal["RevocationMarker"] = "RevocationMarker"
    arrival_ref: str = ""
    subject: str = ""
    authority: str = ""
    reason: str = ""
    timestamp: str = ""
    proof: Optional[RevocationProof] = None


def _revocation_body_dict(marker: RevocationMarker) -> dict:
    """Convert revocation marker to dict for signing (no proof)."""
    return {
        "type": marker.type,
        "arrivalRef": marker.arrival_ref,
        "subject": marker.subject,
        "authority": marker.authority,
        "reason": marker.reason,
        "timestamp": marker.timestamp,
    }


def create_revocation_marker(
    arrival_marker: ArrivalMarker,
    reason: str,
    private_key: bytes,
    public_key: bytes,
    algorithm: RevocationAlgorithm = "Ed25519",
) -> RevocationMarker:
    """Create a signed revocation marker for an arrival."""
    if algorithm == "P-256":
        did = did_from_p256_public_key(public_key)
    else:
        did = did_from_public_key(public_key)

    # Verify authority matches arrival signer
    if arrival_marker.proof and arrival_marker.proof.verification_method:
        if arrival_marker.proof.verification_method != did:
            raise ValueError(
                f"Authority mismatch: revoker DID {did} does not match arrival signer "
                f"{arrival_marker.proof.verification_method}. "
                "Only the destination platform that signed the arrival can revoke it."
            )

    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    marker = RevocationMarker(
        type="RevocationMarker",
        arrival_ref=arrival_marker.id,
        subject=arrival_marker.subject,
        authority=did,
        reason=reason,
        timestamp=now,
    )

    body = _revocation_body_dict(marker)
    canonical = canonicalize(body)
    data = (DOMAIN_PREFIX + canonical).encode("utf-8")

    if algorithm == "P-256":
        sig_bytes = sign_p256(data, private_key)
        proof_type: Literal["Ed25519Signature2020", "EcdsaP256Signature2019"] = "EcdsaP256Signature2019"
    else:
        sig_bytes = sign(data, private_key)
        proof_type = "Ed25519Signature2020"

    proof_value = base64.b64encode(sig_bytes).decode("ascii")

    marker.proof = RevocationProof(
        type=proof_type,
        created=now,
        verification_method=did,
        proof_value=proof_value,
    )

    return marker


@dataclass
class RevocationVerificationResult:
    valid: bool
    errors: list[str] = field(default_factory=list)


def verify_revocation_marker(
    marker: RevocationMarker,
    arrival_marker: Optional[ArrivalMarker] = None,
) -> RevocationVerificationResult:
    """Verify a revocation marker's signature."""
    errors: list[str] = []

    if not marker.proof or not marker.proof.proof_value:
        return RevocationVerificationResult(valid=False, errors=["Missing proof"])

    # Check authority matches arrival signer
    if arrival_marker and arrival_marker.proof and arrival_marker.proof.verification_method:
        if marker.authority != arrival_marker.proof.verification_method:
            errors.append(
                f"Authority mismatch: revocation authority {marker.authority} "
                f"does not match arrival signer {arrival_marker.proof.verification_method}"
            )

    # Check proof signer matches claimed authority
    if marker.authority and marker.proof.verification_method != marker.authority:
        errors.append(
            f"Proof signer {marker.proof.verification_method} "
            f"does not match claimed authority {marker.authority}"
        )

    try:
        did = marker.proof.verification_method
        alg = algorithm_from_did(did)
        pub_key = public_key_from_did(did)

        body = _revocation_body_dict(marker)
        canonical = canonicalize(body)
        data = (DOMAIN_PREFIX + canonical).encode("utf-8")
        signature = base64.b64decode(marker.proof.proof_value)

        if alg == "P-256":
            valid = verify_p256(data, signature, pub_key)
        else:
            valid = verify(data, signature, pub_key)

        if not valid:
            errors.append("Revocation signature verification failed")
    except Exception as e:
        errors.append(f"Revocation verification error: {e}")

    return RevocationVerificationResult(valid=len(errors) == 0, errors=errors)


def is_revoked(arrival_id: str, revocations: list[RevocationMarker]) -> bool:
    """Check if an arrival has been revoked."""
    return any(r.arrival_ref == arrival_id for r in revocations)
