"""Admit Ceremony — the core admission ceremony for cellar-door-entry."""

from __future__ import annotations

import copy
import hashlib
import json
import logging
import warnings
from typing import Any, Literal, Optional, Protocol

from pydantic import BaseModel, ConfigDict, Field, model_validator

logger = logging.getLogger(__name__)
from uuid import uuid4

from exit_door import (
    ExitMarker,
    add_counter_signature,
    algorithm_from_did,
    derive_status_confirmation,
    public_key_from_did,
    verify_counter_signature,
)

from .arrival import create_arrival_marker
from .claim_tracking import ClaimStore
from .events import AdmissionEventEmitter
from .models import ArrivalMarker, CreateArrivalOpts, ENTRY_CONTEXT_V1, VerificationResult
from .policy_builder import BuiltPolicy, CAUTIOUS
from .admission_policy import parse_duration
from .sign import sign_arrival_marker
from .verify_departure import verify_departure

CounterSignMeaning = Literal["receipt_only", "terms_acknowledged", "terms_reviewed"]


class AdmissionStore(Protocol):
    """Extended store that supports admission record storage."""

    def claim(self, exit_marker_id: str, arrival_marker_id: str, subject_did: Optional[str] = None) -> bool: ...
    def is_claimed(self, exit_marker_id: str) -> bool: ...
    def get_arrival_id(self, exit_marker_id: str) -> Optional[str]: ...
    def revoke(self, arrival_marker_id: str) -> bool: ...
    def delete_by_subject(self, subject_did: str) -> int: ...
    def put_admission(self, record: dict[str, Any]) -> None: ...
    def get_admission(self, record_id: str) -> Optional[dict[str, Any]]: ...
    def get_admission_history(self, subject_did: str) -> list[dict[str, Any]]: ...
    def erase_subject(self, subject_did: str) -> dict[str, int]: ...


def is_admission_store(store: Any) -> bool:
    """Check if a store supports putAdmission."""
    return hasattr(store, "put_admission") and callable(getattr(store, "put_admission"))


class AdmitOpts(BaseModel):
    """Options for the admit ceremony."""

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)

    platform_identity: Optional[dict[str, bytes]] = None
    policy: Optional[Any] = None  # BuiltPolicy
    store: Optional[Any] = None  # ClaimStore
    counter_sign_meaning: Optional[CounterSignMeaning] = None
    destination: Optional[str] = None
    emitter: Optional[Any] = None  # AdmissionEventEmitter
    counter_sign: Optional[bool] = None
    timestamp: Optional[str] = None
    minting_justification: Optional[str] = None
    minting_subject: Optional[str] = None
    admission_type: Optional[Literal["standard", "minted", "migration"]] = None

    @model_validator(mode="after")
    def _validate_platform_identity(self) -> "AdmitOpts":
        if self.platform_identity is not None:
            if not isinstance(self.platform_identity, dict):
                raise TypeError("platform_identity must be a dict")
            for key in ("private_key", "public_key"):
                if key not in self.platform_identity:
                    raise ValueError(f"platform_identity missing required key: {key}")
                if not isinstance(self.platform_identity[key], bytes):
                    raise TypeError(f"platform_identity['{key}'] must be bytes")
        return self


class AdmissionRecord(BaseModel):
    """Structured admission record with camelCase JSON serialization."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    exit_marker_id: Optional[str] = Field(default=None, alias="exitMarkerId")
    arrival_marker_id: str = Field(alias="arrivalMarkerId")
    subject_did: Optional[str] = Field(default=None, alias="subjectDid")
    origin_did: Optional[str] = Field(default=None, alias="originDid")
    policy_applied: str = Field(alias="policyApplied")
    policy_version: str = Field(alias="policyVersion")
    admitted: bool
    admission_type: str = Field(alias="admissionType")
    counter_signed: bool = Field(alias="counterSigned")
    reason_codes: list[str] = Field(default_factory=list, alias="reasonCodes")
    conditions: list[str] = Field(default_factory=list)
    timestamp: str
    confirmation_level: Optional[str] = Field(default=None, alias="confirmationLevel")
    counter_sign_meaning: Optional[str] = Field(default=None, alias="counterSignMeaning")
    quarantined: Optional[bool] = None
    quarantine_expires: Optional[str] = Field(default=None, alias="quarantineExpires")
    minting_justification: Optional[str] = Field(default=None, alias="mintingJustification")
    policy_snapshot: Optional[str] = Field(default=None, alias="policySnapshot")

    def to_dict(self) -> dict[str, Any]:
        """Convert to snake_case dict for backward compatibility and storage."""
        return {k: v for k, v in self.__dict__.items()}

    def __getitem__(self, key: str) -> Any:
        """Dict-style access for backward compatibility."""
        return self.__dict__[key]

    def __contains__(self, key: str) -> bool:
        return key in self.__dict__

    def get(self, key: str, default: Any = None) -> Any:
        return self.__dict__.get(key, default)


class AdmitResult(BaseModel):
    """Result of the admit ceremony with camelCase JSON serialization."""

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)

    counter_signed_exit_marker: Optional[Any] = Field(default=None, alias="counterSignedExitMarker")
    arrival_marker: Optional[Any] = Field(default=None, alias="arrivalMarker")
    admission: AdmissionRecord

    def __getitem__(self, key: str) -> Any:
        """Dict-style access for backward compatibility."""
        return self.__dict__[key]

    def __setitem__(self, key: str, value: Any) -> None:
        """Dict-style assignment for backward compatibility."""
        self.__dict__[key] = value

    def __contains__(self, key: str) -> bool:
        return key in self.__dict__

    def get(self, key: str, default: Any = None) -> Any:
        return self.__dict__.get(key, default)

    def keys(self):
        return self.__dict__.keys()


def _generate_record_id() -> str:
    return f"admission-{uuid4()}"


def _compute_policy_snapshot(policy: BuiltPolicy) -> Optional[str]:
    if not hasattr(policy, "to_json"):
        return None
    try:
        pj = policy.to_json()
        return json.dumps({
            "name": pj.name,
            "conflict_strategy": pj.conflict_strategy,
            "rules": pj.rules,
            "custom_rules_omitted": pj.custom_rules_omitted,
        })
    except Exception:
        return None


def _compute_policy_version(policy: BuiltPolicy) -> str:
    try:
        pj = policy.to_json()
        j = json.dumps({
            "name": pj.name,
            "conflict_strategy": pj.conflict_strategy,
            "rules": pj.rules,
            "custom_rules_omitted": pj.custom_rules_omitted,
        })
        return hashlib.sha256(j.encode()).hexdigest()[:16]
    except Exception:
        return "unknown"


def _record_from_dict(d: dict[str, Any]) -> AdmissionRecord:
    """Build an AdmissionRecord from a plain dict."""
    return AdmissionRecord(
        id=d["id"],
        exit_marker_id=d.get("exit_marker_id"),
        arrival_marker_id=d.get("arrival_marker_id", ""),
        subject_did=d.get("subject_did"),
        origin_did=d.get("origin_did"),
        policy_applied=d["policy_applied"],
        policy_version=d.get("policy_version", ""),
        admitted=d["admitted"],
        admission_type=d["admission_type"],
        counter_signed=d.get("counter_signed", False),
        reason_codes=d.get("reason_codes", []),
        conditions=d.get("conditions", []),
        timestamp=d["timestamp"],
        confirmation_level=d.get("confirmation_level"),
        counter_sign_meaning=d.get("counter_sign_meaning"),
        quarantined=d.get("quarantined"),
        quarantine_expires=d.get("quarantine_expires"),
        minting_justification=d.get("minting_justification"),
        policy_snapshot=d.get("policy_snapshot"),
    )


def _persist_rejection(record: AdmissionRecord, store: Optional[Any]) -> None:
    if store and is_admission_store(store):
        store.put_admission(record.to_dict())


def admit(
    exit_marker_input: Optional[ExitMarker],
    opts: Optional[AdmitOpts] = None,
) -> AdmitResult:
    """Admit an agent — the core ceremony.

    Three modes:
    1. With exit marker + counter-sign (platformIdentity provided)
    2. With exit marker, no counter-sign
    3. No exit marker — minting (exitMarker is None)

    Returns an AdmitResult (also supports dict-style access for backward compat).
    """
    if opts is None:
        opts = AdmitOpts()

    # Deep clone to prevent caller mutation
    exit_marker: Optional[ExitMarker] = None
    if exit_marker_input is not None:
        exit_marker = ExitMarker.model_validate(exit_marker_input.model_dump(by_alias=True), strict=False)

    policy = opts.policy or CAUTIOUS
    destination = opts.destination or "https://destination.example.com"
    from datetime import datetime, timezone
    timestamp = opts.timestamp or datetime.now(timezone.utc).isoformat()
    is_minting = exit_marker is None

    # Require mintingSubject for minting
    if is_minting and not opts.minting_subject:
        raise ValueError("minting_subject is required when minting (no exit marker)")

    # Step 0: Replay protection
    pending_claim_id = f"pending-{uuid4()}"
    if opts.store and exit_marker:
        subject_did = exit_marker.subject or "unknown"
        claimed = opts.store.claim(exit_marker.id, pending_claim_id, subject_did)
        if not claimed:
            record = _record_from_dict({
                "id": _generate_record_id(),
                "exit_marker_id": exit_marker.id,
                "arrival_marker_id": "",
                "subject_did": exit_marker.subject or "unknown",
                "origin_did": exit_marker.origin,
                "policy_applied": policy.name,
                "policy_version": _compute_policy_version(policy),
                "admitted": False,
                "admission_type": "standard",
                "counter_signed": False,
                "reason_codes": ["replay-detected"],
                "conditions": [],
                "timestamp": timestamp,
                "policy_snapshot": _compute_policy_snapshot(policy),
            })
            _persist_rejection(record, opts.store)
            if opts.emitter:
                opts.emitter.emit("agent:rejected", {"record": record, "exit_marker_id": exit_marker.id})
            return AdmitResult(
                counter_signed_exit_marker=exit_marker,
                arrival_marker=None,
                admission=record,
            )

    # Step 0.5: Cryptographic verification
    verified = True
    if exit_marker:
        verification_result = verify_departure(exit_marker)
        verified = verification_result.valid

        # Re-verify without counter-sigs if initial verification fails
        if not verified and exit_marker.dispute and hasattr(exit_marker.dispute, 'counterparty_acks') and exit_marker.dispute.counterparty_acks:
            stripped_data = exit_marker.model_dump(by_alias=True)
            dispute_data = dict(stripped_data.get("dispute", {}))
            dispute_data.pop("counterpartyAcks", None)
            if dispute_data:
                stripped_data["dispute"] = dispute_data
            else:
                stripped_data.pop("dispute", None)
            stripped_marker = ExitMarker.model_validate(stripped_data)
            stripped_result = verify_departure(stripped_marker)
            if stripped_result.valid:
                verified = True

        # Step 0.6: Verify counter-signatures, strip forged ones
        if exit_marker.dispute and hasattr(exit_marker.dispute, 'counterparty_acks') and exit_marker.dispute.counterparty_acks:
            verified_acks = []
            for i, ack in enumerate(exit_marker.dispute.counterparty_acks):
                try:
                    algo = algorithm_from_did(ack.verification_method)
                    pub_key = public_key_from_did(ack.verification_method)
                    result = verify_counter_signature(exit_marker, pub_key, i)
                    if result.valid:
                        verified_acks.append(ack)
                except Exception as exc:
                    logger.warning(
                        "Counter-signature verification failed for ack %d (method=%s): %s",
                        i,
                        getattr(ack, "verification_method", "unknown"),
                        exc,
                    )

            if len(verified_acks) != len(exit_marker.dispute.counterparty_acks):
                marker_data = exit_marker.model_dump(by_alias=True)
                dispute_data = dict(marker_data.get("dispute", {}))
                if verified_acks:
                    dispute_data["counterpartyAcks"] = [a.model_dump(by_alias=True) for a in verified_acks]
                else:
                    dispute_data.pop("counterpartyAcks", None)
                remaining = {k: v for k, v in dispute_data.items() if v is not None}
                if remaining:
                    marker_data["dispute"] = remaining
                else:
                    marker_data.pop("dispute", None)
                exit_marker = ExitMarker.model_validate(marker_data)

        # Check if policy requires verified departure
        policy_requires_verification = any(r.name == "verified-departure" for r in policy.rules)
        if not verified and policy_requires_verification:
            record = _record_from_dict({
                "id": _generate_record_id(),
                "exit_marker_id": exit_marker.id,
                "arrival_marker_id": "",
                "subject_did": exit_marker.subject or "unknown",
                "origin_did": exit_marker.origin,
                "policy_applied": policy.name,
                "policy_version": _compute_policy_version(policy),
                "admitted": False,
                "admission_type": "standard",
                "counter_signed": False,
                "reason_codes": ["departure-verification-failed"],
                "conditions": [],
                "timestamp": timestamp,
                "policy_snapshot": _compute_policy_snapshot(policy),
            })
            # ADV-02: Release pre-claim on verification failure
            if opts.store:
                try:
                    opts.store.revoke(pending_claim_id)
                except Exception:
                    pass
            _persist_rejection(record, opts.store)
            if opts.emitter:
                opts.emitter.emit("agent:rejected", {"record": record, "exit_marker_id": exit_marker.id})
            return AdmitResult(
                counter_signed_exit_marker=exit_marker,
                arrival_marker=None,
                admission=record,
            )

    # Step 1: Evaluate policy
    policy_result = policy.evaluate(exit_marker, {
        "is_minting": is_minting,
        "now": datetime.fromisoformat(timestamp.replace("Z", "+00:00")),
        "minting_justification": opts.minting_justification,
        "verified": verified,
    })

    if not policy_result.admitted:
        confirmation = None
        if exit_marker:
            try:
                confirmation = derive_status_confirmation(exit_marker)
            except Exception:
                pass

        record = _record_from_dict({
            "id": _generate_record_id(),
            "exit_marker_id": exit_marker.id if exit_marker else None,
            "arrival_marker_id": "",
            "subject_did": exit_marker.subject if exit_marker else "unknown",
            "origin_did": exit_marker.origin if exit_marker else None,
            "confirmation_level": confirmation,
            "policy_applied": policy.name,
            "policy_version": _compute_policy_version(policy),
            "admitted": False,
            "admission_type": "minted" if is_minting else "standard",
            "counter_signed": False,
            "reason_codes": policy_result.reasons,
            "conditions": policy_result.conditions,
            "timestamp": timestamp,
            "policy_snapshot": _compute_policy_snapshot(policy),
        })
        # ADV-02: Release pre-claim on policy rejection
        if opts.store and exit_marker:
            try:
                opts.store.revoke(pending_claim_id)
            except Exception:
                pass
        _persist_rejection(record, opts.store)
        if opts.emitter:
            opts.emitter.emit("agent:rejected", {"record": record, "exit_marker_id": exit_marker.id if exit_marker else None})
        return AdmitResult(
            counter_signed_exit_marker=exit_marker,
            arrival_marker=None,
            admission=record,
        )

    # Step 2: Check quarantine
    is_quarantined = "quarantine" in policy_result.conditions
    quarantine_expires: Optional[str] = None
    if is_quarantined:
        for c in policy_result.conditions:
            if c.startswith("quarantine-max:"):
                dur_str = c.split(":")[1]
                ms = parse_duration(dur_str)
                ts_dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                quarantine_expires = datetime.fromtimestamp(
                    ts_dt.timestamp() + ms / 1000, tz=timezone.utc
                ).isoformat()
                break

    # Step 3: Counter-sign exit marker
    counter_signed_exit = exit_marker
    did_counter_sign = False
    if exit_marker and opts.platform_identity and opts.counter_sign is not False:
        counter_signed_exit = add_counter_signature(
            exit_marker,
            opts.platform_identity["private_key"],
            opts.platform_identity["public_key"],
        )
        did_counter_sign = True

    # Step 4: Create arrival marker
    if exit_marker:
        arrival_marker = create_arrival_marker(exit_marker, destination, CreateArrivalOpts(
            admission_type="conditional" if is_quarantined else "automatic",
            conditions=policy_result.conditions if policy_result.conditions else None,
            timestamp=timestamp,
        ))
    else:
        # Minting — synthetic arrival
        arrival_marker = ArrivalMarker(
            context=ENTRY_CONTEXT_V1,
            id=f"urn:entry:minted-{uuid4()}",
            departure_ref="urn:entry:minted",
            departure_origin="urn:entry:minted",
            destination=destination,
            subject=opts.minting_subject,  # type: ignore
            timestamp=timestamp,
            admission_type="reviewed",
            verification_result=VerificationResult(valid=False, errors=["minted-no-departure"]),
        )

    # Step 5: Sign arrival marker
    if opts.platform_identity:
        arrival_marker = sign_arrival_marker(
            arrival_marker,
            opts.platform_identity["private_key"],
            opts.platform_identity["public_key"],
        )

    # Step 6: Store minting claims
    if opts.store:
        if is_minting:
            opts.store.claim(arrival_marker.id, arrival_marker.id, arrival_marker.subject)

    # Step 7: Build admission record
    confirmation = None
    if exit_marker:
        try:
            confirmation = derive_status_confirmation(exit_marker)
        except Exception:
            pass

    record = _record_from_dict({
        "id": _generate_record_id(),
        "exit_marker_id": exit_marker.id if exit_marker else None,
        "arrival_marker_id": arrival_marker.id,
        "subject_did": exit_marker.subject if exit_marker else arrival_marker.subject,
        "origin_did": exit_marker.origin if exit_marker else None,
        "confirmation_level": confirmation,
        "policy_applied": policy.name,
        "policy_version": _compute_policy_version(policy),
        "admitted": True,
        "admission_type": opts.admission_type or ("minted" if is_minting else "standard"),
        "counter_signed": did_counter_sign,
        "counter_sign_meaning": (opts.counter_sign_meaning or "receipt_only") if did_counter_sign else None,
        "reason_codes": policy_result.reasons,
        "conditions": policy_result.conditions,
        "timestamp": timestamp,
        "quarantined": is_quarantined or None,
        "quarantine_expires": quarantine_expires,
        "minting_justification": opts.minting_justification if is_minting else None,
        "policy_snapshot": _compute_policy_snapshot(policy),
    })

    # Step 8: Auto-store admission record
    if opts.store and is_admission_store(opts.store):
        opts.store.put_admission(record.to_dict())

    # Step 9: Emit events
    if opts.emitter:
        if is_quarantined:
            opts.emitter.emit("agent:quarantined", {"record": record})
        elif is_minting:
            opts.emitter.emit("agent:minted", {"record": record})
        else:
            opts.emitter.emit("agent:admitted", {"record": record})

    return AdmitResult(
        counter_signed_exit_marker=counter_signed_exit,
        arrival_marker=arrival_marker,
        admission=record,
    )
