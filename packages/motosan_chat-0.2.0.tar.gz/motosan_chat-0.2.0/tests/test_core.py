from __future__ import annotations

from collections.abc import AsyncIterator

import pytest

from motosan_chat.core import Bot, IncomingEvent


class MockChannel:
    def __init__(self, events: list[IncomingEvent]) -> None:
        self._events = events
        self.chunks: list[tuple[str, str]] = []
        self.done: list[str] = []
        self.sent: list[tuple[str, str]] = []

    @property
    def name(self) -> str:
        return "mock"

    async def listen(self) -> AsyncIterator[IncomingEvent]:
        for event in self._events:
            yield event

    async def stream_chunk(self, user_id: str, chunk: str) -> None:
        self.chunks.append((user_id, chunk))

    async def stream_done(self, user_id: str) -> None:
        self.done.append(user_id)

    async def send(self, user_id: str, text: str) -> None:
        self.sent.append((user_id, text))


@pytest.mark.asyncio
async def test_bot_dispatches_events_to_handler() -> None:
    channel = MockChannel(
        [
            IncomingEvent(user_id="u1", content="hi", channel_name="mock"),
            IncomingEvent(user_id="u2", content="yo", channel_name="mock"),
        ]
    )
    handled: list[str] = []

    async def handler(thread) -> None:  # type: ignore[no-untyped-def]
        handled.append(thread.event.content)
        await thread.send(f"echo:{thread.event.content}")

    bot = Bot.builder().channel(channel).handler(handler).build()
    await bot.run()

    assert handled == ["hi", "yo"]
    assert channel.sent == [("u1", "echo:hi"), ("u2", "echo:yo")]


def test_bot_builder_requires_channel_and_handler() -> None:
    with pytest.raises(ValueError):
        Bot.builder().build()
