from __future__ import annotations

from collections.abc import AsyncIterator

import pytest

from motosan_chat.agent import AgentLoop, LlmResponse, Message
from motosan_chat.core import IncomingEvent, Thread
from motosan_chat.tool import ToolContext, ToolDef, ToolResult


class DummyChannel:
    @property
    def name(self) -> str:
        return "web"

    async def listen(self) -> AsyncIterator[IncomingEvent]:
        if False:
            yield IncomingEvent(user_id="", content="", channel_name="web")

    async def stream_chunk(self, user_id: str, chunk: str) -> None:
        _ = (user_id, chunk)

    async def stream_done(self, user_id: str) -> None:
        _ = user_id

    async def send(self, user_id: str, text: str) -> None:
        _ = (user_id, text)


class EchoTool:
    def def_(self) -> ToolDef:
        return ToolDef(name="echo", description="echo", schema={"type": "object"})

    async def call(self, args: dict, ctx: ToolContext) -> ToolResult:
        _ = ctx
        return ToolResult.text(f"echo:{args['value']}")


class MockLlm:
    def __init__(self) -> None:
        self.calls = 0
        self.snapshots: list[list[Message]] = []

    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        _ = tools
        self.snapshots.append(list(messages))
        self.calls += 1
        if self.calls == 1:
            return LlmResponse.tool_call("call-1", "echo", {"value": "hi"})
        return LlmResponse.message("done")

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        _ = messages
        if False:
            yield ""


@pytest.mark.asyncio
async def test_agent_loop_multi_turn_tool_chain() -> None:
    loop_ = AgentLoop(tools=[EchoTool()])
    llm = MockLlm()
    thread = Thread(IncomingEvent("u1", "hello", "web"), DummyChannel())

    result = await loop_.run(llm, thread, [Message.user("hello")])

    assert result.answer == "done"
    assert result.iterations == 2

    second_call_messages = llm.snapshots[1]
    assistant_tool = [m for m in second_call_messages if m.role == "assistant" and m.tool_calls]
    tool_result = [m for m in second_call_messages if m.role == "tool"]

    assert assistant_tool[0].tool_calls[0].id == "call-1"
    assert tool_result[0].tool_call_id == "call-1"


class NeverEndingLlm:
    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        _ = (messages, tools)
        return LlmResponse.tool_call("x", "missing", {})

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        _ = messages
        if False:
            yield ""


@pytest.mark.asyncio
async def test_agent_loop_max_iterations_guard() -> None:
    loop_ = AgentLoop(tools=[], max_iterations=2)
    thread = Thread(IncomingEvent("u1", "hello", "web"), DummyChannel())

    with pytest.raises(RuntimeError, match="max iterations"):
        await loop_.run(NeverEndingLlm(), thread, [Message.user("hello")])
