from __future__ import annotations

from dataclasses import dataclass

import pytest

from motosan_chat.agent import Message
from motosan_chat.ai import MotosanAiClient, _to_ai_message, _to_ai_tool
from motosan_chat.tool import ToolDef


@dataclass
class MockToolCall:
    id: str
    name: str
    input: dict


@dataclass
class MockChatResp:
    content: str
    tool_calls: list[MockToolCall]


@dataclass
class MockStreamEvent:
    content: str


class MockAiClient:
    def __init__(self) -> None:
        self.chat_response = MockChatResp(content="hello", tool_calls=[])

    async def chat(self, messages, tools=None, system=None):  # type: ignore[no-untyped-def]
        _ = (messages, tools, system)
        return self.chat_response

    async def stream(self, messages, system=None):  # type: ignore[no-untyped-def]
        _ = (messages, system)
        for chunk in ["A", "B"]:
            yield MockStreamEvent(content=chunk)


@pytest.mark.asyncio
async def test_chat_maps_message_response() -> None:
    client = MotosanAiClient(MockAiClient())
    response = await client.chat([Message.user("hi")], [])
    assert response.kind == "message"
    assert response.content == "hello"


@pytest.mark.asyncio
async def test_chat_maps_tool_call_response() -> None:
    ai = MockAiClient()
    ai.chat_response = MockChatResp(
        content="",
        tool_calls=[MockToolCall(id="tc-1", name="echo", input={"x": 1})],
    )
    client = MotosanAiClient(ai)
    response = await client.chat([Message.user("hi")], [])
    assert response.kind == "tool_call"
    assert response.tool_call_id == "tc-1"
    assert response.tool_name == "echo"
    assert response.tool_args == {"x": 1}


@pytest.mark.asyncio
async def test_stream_passthrough() -> None:
    client = MotosanAiClient(MockAiClient())
    chunks = [chunk async for chunk in client.stream([Message.user("hi")])]
    assert chunks == ["A", "B"]


def test_to_ai_conversions() -> None:
    tool = _to_ai_tool(ToolDef(name="lookup", description="desc", schema={"type": "object"}))
    assert tool["name"] == "lookup"

    assistant_with_tool = Message.assistant_with_tool_call("tc-1", "echo")
    converted = _to_ai_message(assistant_with_tool)
    assert converted["tool_calls"][0]["id"] == "tc-1"

    tool_msg = Message.tool_result("tc-1", "ok")
    converted_tool = _to_ai_message(tool_msg)
    assert converted_tool["role"] == "tool"
