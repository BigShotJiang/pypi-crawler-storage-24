from __future__ import annotations

import asyncio

import httpx
import pytest

from motosan_chat.channels.line import LineChannel


class MockLineApi:
    def __init__(self) -> None:
        self.pushed: list[tuple[str, str]] = []

    async def push_message(self, user_id: str, text: str) -> None:
        self.pushed.append((user_id, text))


@pytest.mark.asyncio
async def test_line_webhook_maps_text_message_to_event() -> None:
    channel = LineChannel("secret", "token", api=MockLineApi())
    app = channel.app()
    transport = httpx.ASGITransport(app=app)

    payload = {
        "events": [
            {
                "type": "message",
                "source": {"userId": "u1"},
                "message": {"type": "text", "text": "hello line"},
            }
        ]
    }

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post("/line/webhook", json=payload)
        assert response.status_code == 200

    event = await asyncio.wait_for(channel.listen().__anext__(), timeout=1)
    assert event.user_id == "u1"
    assert event.content == "hello line"
    assert event.channel_name == "line"


@pytest.mark.asyncio
async def test_line_stream_chunk_accumulates_and_pushes() -> None:
    api = MockLineApi()
    channel = LineChannel("secret", "token", api=api)

    await channel.stream_chunk("u1", "A")
    await channel.stream_chunk("u1", "B")
    await channel.stream_done("u1")
    await channel.send("u1", "final")

    assert api.pushed == [("u1", "A"), ("u1", "AB"), ("u1", "final")]
