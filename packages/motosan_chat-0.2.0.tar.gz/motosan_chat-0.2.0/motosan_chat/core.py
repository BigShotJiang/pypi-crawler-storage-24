from __future__ import annotations

from dataclasses import dataclass
from typing import AsyncIterator, Awaitable, Callable, Literal, Protocol, Self


class Channel(Protocol):
    @property
    def name(self) -> str: ...

    async def listen(self) -> AsyncIterator["IncomingEvent"]: ...

    async def stream_chunk(self, user_id: str, chunk: str) -> None: ...

    async def stream_done(self, user_id: str) -> None: ...

    async def send(self, user_id: str, text: str) -> None: ...


@dataclass(slots=True)
class IncomingEvent:
    user_id: str
    content: str
    channel_name: str
    chat_type: Literal["dm", "group"] = "dm"


class Thread:
    def __init__(self, event: IncomingEvent, channel: Channel) -> None:
        self.event = event
        self.user_id = event.user_id
        self.channel = channel

    async def stream_chunk(self, chunk: str) -> None:
        await self.channel.stream_chunk(self.user_id, chunk)

    async def stream_done(self) -> None:
        await self.channel.stream_done(self.user_id)

    async def send(self, text: str) -> None:
        await self.channel.send(self.user_id, text)


Handler = Callable[[Thread], Awaitable[None]]


class BotBuilder:
    def __init__(self) -> None:
        self._channel: Channel | None = None
        self._handler: Handler | None = None

    def channel(self, ch: Channel) -> Self:
        self._channel = ch
        return self

    def handler(self, fn: Handler) -> Self:
        self._handler = fn
        return self

    def build(self) -> "Bot":
        if self._channel is None:
            raise ValueError("channel is required")
        if self._handler is None:
            raise ValueError("handler is required")
        return Bot(channel=self._channel, handler=self._handler)


class Bot:
    def __init__(self, channel: Channel, handler: Handler) -> None:
        self._channel = channel
        self._handler = handler

    @classmethod
    def builder(cls) -> BotBuilder:
        return BotBuilder()

    async def run(self) -> None:
        async for event in self._channel.listen():
            thread = Thread(event=event, channel=self._channel)
            await self._handler(thread)
