from __future__ import annotations

from typing import Any, AsyncIterator

from .agent import LlmResponse, Message
from .tool import ToolDef


def _require_motosan_ai() -> Any:
    try:
        import motosan_ai  # type: ignore

        return motosan_ai
    except ImportError as exc:
        raise ImportError(
            "motosan-ai is required. Install with: pip install 'motosan-chat[ai]'"
        ) from exc


class MotosanAiClient:
    def __init__(self, client: Any, system: str | None = None) -> None:
        self._client = client
        self._system = system

    def with_system(self, system: str) -> "MotosanAiClient":
        return MotosanAiClient(self._client, system)

    @classmethod
    def from_motosan_ai_client(cls, client: Any, system: str | None = None) -> "MotosanAiClient":
        _require_motosan_ai()
        return cls(client=client, system=system)

    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse:
        ai_messages = [_to_ai_message(message) for message in messages]
        ai_tools = [_to_ai_tool(tool) for tool in tools]
        response = await self._client.chat(
            ai_messages,
            tools=ai_tools,
            system=self._system,
        )
        tool_calls = getattr(response, "tool_calls", [])
        if tool_calls:
            tool_call = tool_calls[0]
            return LlmResponse.tool_call(
                id=tool_call.id,
                name=tool_call.name,
                args=getattr(tool_call, "input", {}),
            )
        return LlmResponse.message(getattr(response, "content", ""))

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        ai_messages = [_to_ai_message(message) for message in messages]
        async for event in self._client.stream(ai_messages, system=self._system):
            yield getattr(event, "content", "")


def _to_ai_message(message: Message) -> Any:
    if message.role == "tool":
        return {
            "role": "tool",
            "content": message.content,
            "tool_call_id": message.tool_call_id or "",
            "tool_calls": [],
        }

    if message.role == "assistant" and message.tool_calls:
        return {
            "role": "assistant",
            "content": message.content,
            "tool_call_id": None,
            "tool_calls": [
                {"id": ref.id, "name": ref.name, "input": {}}
                for ref in message.tool_calls
            ],
        }

    return {
        "role": message.role,
        "content": message.content,
        "tool_call_id": message.tool_call_id,
        "tool_calls": [],
    }


def _to_ai_tool(tool: ToolDef) -> Any:
    return {
        "name": tool.name,
        "description": tool.description,
        "input_schema": tool.schema,
    }
