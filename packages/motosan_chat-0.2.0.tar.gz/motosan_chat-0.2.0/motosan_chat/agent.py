from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Literal, Protocol

from .core import Thread
from .tool import Tool, ToolContext, ToolDef, ToolResult


@dataclass(slots=True)
class ToolCallRef:
    id: str
    name: str


@dataclass(slots=True)
class Message:
    role: Literal["system", "user", "assistant", "tool"]
    content: str
    tool_call_id: str | None = None
    tool_calls: list[ToolCallRef] = field(default_factory=list)

    @classmethod
    def system(cls, content: str) -> "Message":
        return cls(role="system", content=content)

    @classmethod
    def user(cls, content: str) -> "Message":
        return cls(role="user", content=content)

    @classmethod
    def assistant(cls, content: str) -> "Message":
        return cls(role="assistant", content=content)

    @classmethod
    def assistant_with_tool_call(
        cls,
        tool_call_id: str,
        tool_name: str,
        content: str = "",
    ) -> "Message":
        return cls(
            role="assistant",
            content=content,
            tool_calls=[ToolCallRef(id=tool_call_id, name=tool_name)],
        )

    @classmethod
    def tool_result(cls, tool_call_id: str, content: str) -> "Message":
        return cls(role="tool", content=content, tool_call_id=tool_call_id)


@dataclass(slots=True)
class LlmResponse:
    kind: Literal["message", "tool_call"]
    content: str = ""
    tool_call_id: str | None = None
    tool_name: str | None = None
    tool_args: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def message(cls, content: str) -> "LlmResponse":
        return cls(kind="message", content=content)

    @classmethod
    def tool_call(cls, id: str, name: str, args: dict[str, Any]) -> "LlmResponse":
        return cls(kind="tool_call", tool_call_id=id, tool_name=name, tool_args=args)


class LlmClient(Protocol):
    async def chat(self, messages: list[Message], tools: list[ToolDef]) -> LlmResponse: ...

    async def stream(self, messages: list[Message]) -> AsyncIterator[str]: ...


class ContextProvider(Protocol):
    async def build(self, query: str) -> str: ...


@dataclass(slots=True)
class AgentResult:
    answer: str
    tool_calls: list[tuple[str, dict[str, Any]]]
    iterations: int


class AgentLoop:
    def __init__(
        self,
        tools: list[Tool] | None = None,
        context_providers: list[ContextProvider] | None = None,
        max_iterations: int = 10,
    ) -> None:
        self._tools = tools or []
        self._context_providers = context_providers or []
        self._max_iterations = max_iterations

    async def run(
        self,
        llm: LlmClient,
        thread: Thread,
        messages: list[Message],
    ) -> AgentResult:
        tool_calls: list[tuple[str, dict[str, Any]]] = []

        user_query = ""
        for message in reversed(messages):
            if message.role == "user":
                user_query = message.content
                break

        for provider in self._context_providers:
            context = await provider.build(user_query)
            if context:
                messages.append(Message.system(context))

        for iteration in range(1, self._max_iterations + 1):
            defs = [tool.def_() for tool in self._tools]
            response = await llm.chat(messages, defs)

            if response.kind == "message":
                return AgentResult(
                    answer=response.content,
                    tool_calls=tool_calls,
                    iterations=iteration,
                )

            tool_name = response.tool_name or ""
            tool_call_id = response.tool_call_id or ""
            await thread.stream_chunk(f"🔧 {tool_name}...")
            output = await self._run_tool(
                tool_name,
                response.tool_args,
                ToolContext(caller_id=thread.user_id, channel_name=thread.channel.name),
            )
            tool_calls.append((tool_name, response.tool_args))

            messages.extend(
                [
                    Message.assistant_with_tool_call(tool_call_id, tool_name),
                    Message.tool_result(tool_call_id, self._tool_result_to_message(output)),
                ]
            )

        raise RuntimeError(f"max iterations reached ({self._max_iterations})")

    async def _run_tool(
        self,
        tool_name: str,
        args: dict[str, Any],
        ctx: ToolContext,
    ) -> ToolResult:
        for tool in self._tools:
            if tool.def_().name == tool_name:
                return await tool.call(args, ctx)
        return ToolResult.error(f"unknown tool: {tool_name}")

    @staticmethod
    def _tool_result_to_message(result: ToolResult) -> str:
        parts: list[str] = []
        for item in result.content:
            if isinstance(item, dict):
                parts.append(json.dumps(item, ensure_ascii=False))
            else:
                parts.append(str(item))
        return "\n".join(parts)
