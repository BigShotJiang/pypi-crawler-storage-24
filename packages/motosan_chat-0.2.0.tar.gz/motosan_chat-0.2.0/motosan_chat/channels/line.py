from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any, Protocol

from motosan_chat.core import IncomingEvent


class LineApi(Protocol):
    async def push_message(self, user_id: str, text: str) -> None: ...


@dataclass
class _StreamState:
    buffer: str = ""


class LineChannel:
    def __init__(
        self,
        channel_secret: str,
        access_token: str,
        api: LineApi | None = None,
    ) -> None:
        self._channel_secret = channel_secret
        self._access_token = access_token
        self._api = api or _LineMessagingApi(access_token)
        self._incoming_events: asyncio.Queue[IncomingEvent] = asyncio.Queue()
        self._stream_states: dict[str, _StreamState] = {}

    @property
    def name(self) -> str:
        return "line"

    async def listen(self) -> AsyncIterator[IncomingEvent]:
        while True:
            yield await self._incoming_events.get()

    async def stream_chunk(self, user_id: str, chunk: str) -> None:
        state = self._stream_states.setdefault(user_id, _StreamState())
        state.buffer += chunk
        await self._api.push_message(user_id, state.buffer)

    async def stream_done(self, user_id: str) -> None:
        self._stream_states.pop(user_id, None)

    async def send(self, user_id: str, text: str) -> None:
        await self._api.push_message(user_id, text)

    def app(self):  # type: ignore[no-untyped-def]
        try:
            from fastapi import FastAPI
            from fastapi.responses import JSONResponse
        except ImportError as exc:
            raise ImportError(
                "line extras are required. Install with: pip install 'motosan-chat[line]'"
            ) from exc

        app = FastAPI()

        @app.post("/line/webhook")
        async def webhook(payload: dict[str, Any]):
            events = payload.get("events", [])
            for event in events:
                if event.get("type") != "message":
                    continue
                message = event.get("message", {})
                if message.get("type") != "text":
                    continue
                source = event.get("source", {})
                user_id = source.get("userId")
                text = message.get("text", "")
                if not user_id or not text:
                    continue
                await self._incoming_events.put(
                    IncomingEvent(
                        user_id=str(user_id),
                        content=str(text),
                        channel_name=self.name,
                        chat_type="dm",
                    )
                )
            return JSONResponse({"ok": True})

        return app


class _LineMessagingApi:
    def __init__(self, access_token: str) -> None:
        self._access_token = access_token

    async def push_message(self, user_id: str, text: str) -> None:
        try:
            from linebot.v3.messaging import (
                ApiClient,
                Configuration,
                MessagingApi,
                PushMessageRequest,
                TextMessage,
            )
        except ImportError as exc:
            raise ImportError(
                "line extras are required. Install with: pip install 'motosan-chat[line]'"
            ) from exc

        configuration = Configuration(access_token=self._access_token)
        with ApiClient(configuration) as api_client:
            api = MessagingApi(api_client)
            api.push_message(
                PushMessageRequest(
                    to=user_id,
                    messages=[TextMessage(text=text)],
                )
            )
