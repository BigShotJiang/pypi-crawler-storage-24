# Manim Euclid

Euclidian Geometry Drawing Tool

This project is a Porting of the excellent Lua/TikZ package `tkz-elements` in python to use with Manim.

## Neues Projekt

```shell
uv init --python 3.13 manim-euclid
uv add manim
uv run manim checkhealth
uv add poetry
uv add pip
uv add pytest
```

## Status

Experimental


## For devloper: Howto ...

* Create venv
```shell
uv venv
```

* Install all dependencies

```shell
uv sync
```

* Run Unittest
 
```shell
# fast
python -m unittest
# with coverage
coverage run -m unittest
coverage report -m
coverage html
```


* Import Repository Token

```shell
uv run poetry config pypi-token.pypi pypi-AgEIcHl...
uv run poetry config pypi-token.testpypi pypi-AgEIcHl...
```

* Deploy to test PyPi

```shell
rm -rf dist/* ; uv build  --all
twine upload --repository testpypi dist/* 
```

* Deploy to Pypi

```shell
rm -rf dist/* ; uv build --all
twine upload dist/* 
```


