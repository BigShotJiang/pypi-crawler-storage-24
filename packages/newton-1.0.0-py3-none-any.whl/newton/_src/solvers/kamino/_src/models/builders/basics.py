# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Factory methods for building 'basic' models.

This module provides a set of functions to create simple mechanical assemblies
using the ModelBuilderKamino interface. These include fundamental configurations such
as a box on a plane, a box pendulum, a cartpole, and various linked box systems.

Each function constructs a specific model by adding rigid bodies, joints,
and collision geometries to a ModelBuilderKamino instance. The models are designed
to serve as foundational examples for testing and demonstration purposes,
and each features a certain subset of ill-conditioned dynamics.
"""

import math

import warp as wp

from ...core import ModelBuilderKamino, inertia
from ...core.joints import JointActuationType, JointDoFType
from ...core.math import FLOAT32_MAX, FLOAT32_MIN, I_3
from ...core.shapes import BoxShape, SphereShape
from ...core.types import Axis, transformf, vec3f, vec6f

###
# Module interface
###

__all__ = [
    "build_box_on_plane",
    "build_box_pendulum",
    "build_box_pendulum_vertical",
    "build_boxes_fourbar",
    "build_boxes_hinged",
    "build_boxes_nunchaku",
    "build_boxes_nunchaku_vertical",
]


###
# Functions
###


def build_box_on_plane(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    ground: bool = True,
    new_world: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a free-floating 'box' body and a ground box geom.

    Args:
        builder (ModelBuilderKamino | None):
            An optional existing model builder to populate.\n
            If `None`, a new builder is created.
        z_offset (float):
            A vertical offset to apply to the initial position of the box.
        ground (bool):
            Whether to add a static ground plane to the model.
        new_world (bool):
            Whether to create a new world in the builder for this model.\n
            If `False`, the model is added to the existing world specified by `world_index`.\n
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.\n
        world_index (int):
            The index of the world to which the model should be added if `new_world` is False.\n
            If `new_world` is True, this argument is ignored.\n
            If the value does not correspond to an existing world, an error will be raised.\n
            Defaults to `0`.

    Returns:
        ModelBuilderKamino: The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="box_on_plane")

    # Add first body
    bid0 = _builder.add_rigid_body(
        m_i=1.0,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(1.0, 0.2, 0.2, 0.2),
        q_i_0=transformf(0.0, 0.0, 0.1 + z_offset, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(body=bid0, shape=BoxShape(0.2, 0.2, 0.2), world_index=world_index)

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            body=-1,
            shape=BoxShape(20.0, 20.0, 1.0),
            offset=transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_box_pendulum(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.7,
    ground: bool = True,
    new_world: bool = True,
    dynamic_joints: bool = False,
    implicit_pd: bool = False,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a single box pendulum body with a unary revolute joint.

    This version initializes the pendulum in a horizontal configuration.

    Args:
        builder (ModelBuilderKamino | None):
            An optional existing model builder to populate.\n
            If `None`, a new builder is created.
        z_offset (float):
            A vertical offset to apply to the initial position of the box.
        ground (bool):
            Whether to add a static ground plane to the model.
        new_world (bool):
            Whether to create a new world in the builder for this model.\n
            If `False`, the model is added to the existing world specified by `world_index`.\n
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.\n
        world_index (int):
            The index of the world to which the model should be added if `new_world` is False.\n
            If `new_world` is True, this argument is ignored.\n
            If the value does not correspond to an existing world, an error will be raised.\n
            Defaults to `0`.

    Returns:
        ModelBuilderKamino: The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="box_pendulum")

    # Model constants
    m = 1.0
    d = 0.5
    w = 0.1
    h = 0.1
    z_0 = z_offset  # Initial z offset for the body

    # Add box pendulum body
    bid0 = _builder.add_rigid_body(
        name="pendulum",
        m_i=m,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m, d, w, h),
        q_i_0=transformf(0.5 * d, 0.0, 0.5 * h + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a joint between the two bodies
    _builder.add_joint(
        name="world_to_pendulum",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.POSITION_VELOCITY if implicit_pd else JointActuationType.FORCE,
        bid_B=-1,
        bid_F=bid0,
        B_r_Bj=vec3f(0.0, 0.0, 0.5 * h + z_0),
        F_r_Fj=vec3f(-0.5 * d, 0.0, 0.0),
        X_j=Axis.Y.to_mat33(),
        a_j=1.0 if dynamic_joints else None,
        b_j=0.1 if dynamic_joints else None,
        k_p_j=100.0 if implicit_pd else None,
        k_d_j=1.0 if implicit_pd else None,
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="box",
        body=bid0,
        shape=BoxShape(d, w, h),
        world_index=world_index,
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(20.0, 20.0, 1.0),
            offset=transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_box_pendulum_vertical(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.7,
    ground: bool = True,
    new_world: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a single box pendulum body with a unary revolute joint.

    This version initializes the pendulum in a vertical configuration.

    Args:
        builder (ModelBuilderKamino | None):
            An optional existing model builder to populate.\n
            If `None`, a new builder is created.
        z_offset (float):
            A vertical offset to apply to the initial position of the box.
        ground (bool):
            Whether to add a static ground plane to the model.
        new_world (bool):
            Whether to create a new world in the builder for this model.\n
            If `False`, the model is added to the existing world specified by `world_index`.\n
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.\n
        world_index (int):
            The index of the world to which the model should be added if `new_world` is False.\n
            If `new_world` is True, this argument is ignored.\n
            If the value does not correspond to an existing world, an error will be raised.\n
            Defaults to `0`.

    Returns:
        ModelBuilderKamino: The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="box_pendulum_vertical")

    # Model constants
    m = 1.0
    d = 0.1
    w = 0.1
    h = 0.5
    z_0 = z_offset  # Initial z offset for the body

    # Add box pendulum body
    bid0 = _builder.add_rigid_body(
        name="pendulum",
        m_i=m,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m, d, w, h),
        q_i_0=transformf(0.0, 0.0, -0.5 * h + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a joint between the two bodies
    _builder.add_joint(
        name="world_to_pendulum",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.FORCE,
        bid_B=-1,
        bid_F=bid0,
        B_r_Bj=vec3f(0.0, 0.0, 0.0 + z_0),
        F_r_Fj=vec3f(0.0, 0.0, 0.5 * h),
        X_j=Axis.Y.to_mat33(),
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="box",
        body=bid0,
        shape=BoxShape(d, w, h),
        world_index=world_index,
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(20.0, 20.0, 1.0),
            offset=transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_cartpole(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    ground: bool = True,
    new_world: bool = True,
    limits: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a cartpole mounted onto a rail.

    Args:
        builder (ModelBuilderKamino | None):
            An optional existing model builder to populate.\n
            If `None`, a new builder is created.
        z_offset (float):
            A vertical offset to apply to the initial position of the box.
        ground (bool):
            Whether to add a static ground plane to the model.
        new_world (bool):
            Whether to create a new world in the builder for this model.\n
            If `False`, the model is added to the existing world specified by `world_index`.\n
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.\n
        world_index (int):
            The index of the world to which the model should be added if `new_world` is False.\n
            If `new_world` is True, this argument is ignored.\n
            If the value does not correspond to an existing world, an error will be raised.\n
            Defaults to `0`.

    Returns:
        ModelBuilderKamino: The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="cartpole")

    # Model constants
    m_cart = 1.0
    m_pole = 0.2
    dims_rail = (0.03, 8.0, 0.03)
    dims_cart = (0.2, 0.5, 0.2)
    dims_pole = (0.05, 0.05, 0.75)

    # Add box cart body
    bid0 = _builder.add_rigid_body(
        name="cart",
        m_i=m_cart,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_cart, *dims_cart),
        q_i_0=transformf(0.0, 0.0, z_offset, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add box pole body
    x_0_pole = 0.5 * dims_pole[0] + 0.5 * dims_cart[0]
    z_0_pole = 0.5 * dims_pole[2] + z_offset
    bid1 = _builder.add_rigid_body(
        name="pole",
        m_i=m_pole,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_pole, *dims_pole),
        q_i_0=transformf(x_0_pole, 0.0, z_0_pole, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a prismatic joint for the cart
    _builder.add_joint(
        name="rail_to_cart",
        dof_type=JointDoFType.PRISMATIC,
        act_type=JointActuationType.FORCE,
        bid_B=-1,
        bid_F=bid0,
        B_r_Bj=vec3f(0.0, 0.0, z_offset),
        F_r_Fj=vec3f(0.0, 0.0, 0.0),
        X_j=Axis.Y.to_mat33(),
        q_j_min=[-4.0] if limits else [float(FLOAT32_MIN)],
        q_j_max=[4.0] if limits else [float(FLOAT32_MAX)],
        tau_j_max=[1000.0],
        world_index=world_index,
    )

    # Add a revolute joint for the pendulum
    _builder.add_joint(
        name="cart_to_pole",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.PASSIVE,
        bid_B=bid0,
        bid_F=bid1,
        B_r_Bj=vec3f(0.5 * dims_cart[0], 0.0, 0.0),
        F_r_Fj=vec3f(-0.5 * dims_pole[0], 0.0, -0.5 * dims_pole[2]),
        X_j=Axis.X.to_mat33(),
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="cart",
        body=bid0,
        shape=BoxShape(*dims_cart),
        group=2,
        collides=2,
        world_index=world_index,
    )
    _builder.add_geometry(
        name="pole",
        body=bid1,
        shape=BoxShape(*dims_pole),
        group=3,
        collides=3,
        world_index=world_index,
    )
    _builder.add_geometry(
        name="rail",
        body=-1,
        shape=BoxShape(*dims_rail),
        offset=transformf(0.0, 0.0, z_offset, 0.0, 0.0, 0.0, 1.0),
        group=1,
        collides=1,
        world_index=world_index,
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(20.0, 20.0, 1.0),
            offset=transformf(0.0, 0.0, -1.0 + z_offset, 0.0, 0.0, 0.0, 1.0),
            group=1,
            collides=1,
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_boxes_hinged(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    ground: bool = True,
    dynamic_joints: bool = False,
    implicit_pd: bool = False,
    new_world: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a two floating boxes connected via revolute joint.

    Args:
        builder (ModelBuilderKamino | None):
            An optional existing model builder to populate.\n
            If `None`, a new builder is created.
        z_offset (float):
            A vertical offset to apply to the initial position of the box.
        ground (bool):
            Whether to add a static ground plane to the model.
        new_world (bool):
            Whether to create a new world in the builder for this model.\n
            If `False`, the model is added to the existing world specified by `world_index`.\n
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.\n
        world_index (int):
            The index of the world to which the model should be added if `new_world` is False.\n
            If `new_world` is True, this argument is ignored.\n
            If the value does not correspond to an existing world, an error will be raised.\n
            Defaults to `0`.

    Returns:
        ModelBuilderKamino: The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="boxes_hinged")

    # Model constants
    m_0 = 1.0
    m_1 = 1.0
    d = 0.5
    w = 0.1
    h = 0.1
    z0 = z_offset  # Initial z offset for the bodies

    # Add first body
    bid0 = _builder.add_rigid_body(
        name="base",
        m_i=m_0,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_0, d, w, h),
        q_i_0=transformf(0.25, -0.05, 0.05 + z0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add second body
    bid1 = _builder.add_rigid_body(
        name="follower",
        m_i=m_1,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_1, d, w, h),
        q_i_0=transformf(0.75, 0.05, 0.05 + z0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a joint between the two bodies
    _builder.add_joint(
        name="hinge",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.POSITION_VELOCITY if implicit_pd else JointActuationType.FORCE,
        bid_B=bid0,
        bid_F=bid1,
        B_r_Bj=vec3f(0.25, 0.05, 0.0),
        F_r_Fj=vec3f(-0.25, -0.05, 0.0),
        X_j=Axis.Y.to_mat33(),
        a_j=1.0 if dynamic_joints else None,
        b_j=0.1 if dynamic_joints else None,
        k_p_j=100.0 if implicit_pd else None,
        k_d_j=1.0 if implicit_pd else None,
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="base/box", body=bid0, shape=BoxShape(d, w, h), group=2, collides=3, world_index=world_index
    )
    _builder.add_geometry(
        name="follower/box", body=bid1, shape=BoxShape(d, w, h), group=3, collides=5, world_index=world_index
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(20.0, 20.0, 1.0),
            offset=transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            group=1,
            collides=7,
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_boxes_nunchaku(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    ground: bool = True,
    new_world: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a faux nunchaku consisting of
    two boxes and one sphere connected via spherical joints.

    This version initializes the nunchaku in a horizontal configuration.

    Args:
        builder (ModelBuilderKamino | None):
            An optional existing model builder to populate.\n
            If `None`, a new builder is created.
        z_offset (float):
            A vertical offset to apply to the initial position of the box.
        ground (bool):
            Whether to add a static ground plane to the model.
        new_world (bool):
            Whether to create a new world in the builder for this model.\n
            If `False`, the model is added to the existing world specified by `world_index`.\n
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.\n
        world_index (int):
            The index of the world to which the model should be added if `new_world` is False.\n
            If `new_world` is True, this argument is ignored.\n
            If the value does not correspond to an existing world, an error will be raised.\n
            Defaults to `0`.

    Returns:
        ModelBuilderKamino: The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="boxes_nunchaku")

    # Model constants
    m_0 = 1.0
    m_1 = 1.0
    m_2 = 1.0
    d = 0.5
    w = 0.1
    h = 0.1
    r = 0.05

    # Constant to set an initial z offset for the bodies
    # NOTE: for testing purposes, recommend values are {0.0, -0.001}
    z_0 = z_offset

    # Add first body
    bid0 = _builder.add_rigid_body(
        name="box_bottom",
        m_i=m_0,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_0, d, w, h),
        q_i_0=transformf(0.5 * d, 0.0, 0.5 * h + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add second body
    bid1 = _builder.add_rigid_body(
        name="sphere_middle",
        m_i=m_1,
        i_I_i=inertia.solid_sphere_body_moment_of_inertia(m_1, r),
        q_i_0=transformf(r + d, 0.0, r + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add third body
    bid2 = _builder.add_rigid_body(
        name="box_top",
        m_i=m_2,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_2, d, w, h),
        q_i_0=transformf(1.5 * d + 2.0 * r, 0.0, 0.5 * h + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a joint between the first and second body
    _builder.add_joint(
        name="box_bottom_to_sphere_middle",
        dof_type=JointDoFType.SPHERICAL,
        act_type=JointActuationType.PASSIVE,
        bid_B=bid0,
        bid_F=bid1,
        B_r_Bj=vec3f(0.5 * d, 0.0, 0.0),
        F_r_Fj=vec3f(-r, 0.0, 0.0),
        X_j=I_3,
        world_index=world_index,
    )

    # Add a joint between the second and third body
    _builder.add_joint(
        name="sphere_middle_to_box_top",
        dof_type=JointDoFType.SPHERICAL,
        act_type=JointActuationType.PASSIVE,
        bid_B=bid1,
        bid_F=bid2,
        B_r_Bj=vec3f(r, 0.0, 0.0),
        F_r_Fj=vec3f(-0.5 * d, 0.0, 0.0),
        X_j=I_3,
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="box_bottom", body=bid0, shape=BoxShape(d, w, h), group=2, collides=3, world_index=world_index
    )
    _builder.add_geometry(
        name="sphere_middle", body=bid1, shape=SphereShape(r), group=3, collides=5, world_index=world_index
    )
    _builder.add_geometry(
        name="box_top", body=bid2, shape=BoxShape(d, w, h), group=2, collides=3, world_index=world_index
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(20.0, 20.0, 1.0),
            offset=transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            group=1,
            collides=7,
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_boxes_nunchaku_vertical(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    ground: bool = True,
    new_world: bool = True,
    world_index: int = 0,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a faux nunchaku consisting of
    two boxes and one sphere connected via spherical joints.

    This version initializes the nunchaku in a vertical configuration.

    Args:
        builder (ModelBuilderKamino | None):
            An optional existing model builder to populate.\n
            If `None`, a new builder is created.
        z_offset (float):
            A vertical offset to apply to the initial position of the box.
        ground (bool):
            Whether to add a static ground plane to the model.
        new_world (bool):
            Whether to create a new world in the builder for this model.\n
            If `False`, the model is added to the existing world specified by `world_index`.\n
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.\n
        world_index (int):
            The index of the world to which the model should be added if `new_world` is False.\n
            If `new_world` is True, this argument is ignored.\n
            If the value does not correspond to an existing world, an error will be raised.\n
            Defaults to `0`.

    Returns:
        ModelBuilderKamino: The populated model builder.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="boxes_nunchaku_vertical")

    # Model constants
    m_0 = 1.0
    m_1 = 1.0
    m_2 = 1.0
    d = 0.1
    w = 0.1
    h = 0.5
    r = 0.05

    # Constant to set an initial z offset for the bodies
    # NOTE: for testing purposes, recommend values are {0.0, -0.001}
    z_0 = z_offset

    # Add first body
    bid0 = _builder.add_rigid_body(
        name="box_bottom",
        m_i=m_0,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_0, d, w, h),
        q_i_0=transformf(0.0, 0.0, 0.5 * h + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add second body
    bid1 = _builder.add_rigid_body(
        name="sphere_middle",
        m_i=m_1,
        i_I_i=inertia.solid_sphere_body_moment_of_inertia(m_1, r),
        q_i_0=transformf(0.0, 0.0, h + r + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add third body
    bid2 = _builder.add_rigid_body(
        name="box_top",
        m_i=m_2,
        i_I_i=inertia.solid_cuboid_body_moment_of_inertia(m_2, d, w, h),
        q_i_0=transformf(0.0, 0.0, 1.5 * h + 2.0 * r + z_0, 0.0, 0.0, 0.0, 1.0),
        u_i_0=vec6f(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        world_index=world_index,
    )

    # Add a joint between the first and second body
    _builder.add_joint(
        name="box_bottom_to_sphere_middle",
        dof_type=JointDoFType.SPHERICAL,
        act_type=JointActuationType.PASSIVE,
        bid_B=bid0,
        bid_F=bid1,
        B_r_Bj=vec3f(0.0, 0.0, 0.5 * h),
        F_r_Fj=vec3f(0.0, 0.0, -r),
        X_j=I_3,
        world_index=world_index,
    )

    # Add a joint between the second and third body
    _builder.add_joint(
        name="sphere_middle_to_box_top",
        dof_type=JointDoFType.SPHERICAL,
        act_type=JointActuationType.PASSIVE,
        bid_B=bid1,
        bid_F=bid2,
        B_r_Bj=vec3f(0.0, 0.0, r),
        F_r_Fj=vec3f(0.0, 0.0, -0.5 * h),
        X_j=I_3,
        world_index=world_index,
    )

    # Add collision geometries
    _builder.add_geometry(
        name="box_bottom", body=bid0, shape=BoxShape(d, w, h), group=2, collides=3, world_index=world_index
    )
    _builder.add_geometry(
        name="sphere_middle", body=bid1, shape=SphereShape(r), group=3, collides=5, world_index=world_index
    )
    _builder.add_geometry(
        name="box_top", body=bid2, shape=BoxShape(d, w, h), group=2, collides=3, world_index=world_index
    )

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(20.0, 20.0, 1.0),
            offset=transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            group=1,
            collides=7,
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def build_boxes_fourbar(
    builder: ModelBuilderKamino | None = None,
    z_offset: float = 0.0,
    fixedbase: bool = False,
    floatingbase: bool = False,
    limits: bool = True,
    ground: bool = True,
    dynamic_joints: bool = False,
    implicit_pd: bool = False,
    verbose: bool = False,
    new_world: bool = True,
    world_index: int = 0,
    actuator_ids: list[int] | None = None,
) -> ModelBuilderKamino:
    """
    Constructs a basic model of a four-bar linkage.

    Args:
        builder (ModelBuilderKamino | None):
            An optional existing model builder to populate.\n
            If `None`, a new builder is created.
        z_offset (float):
            A vertical offset to apply to the initial position of the box.
        ground (bool):
            Whether to add a static ground plane to the model.
        new_world (bool):
            Whether to create a new world in the builder for this model.\n
            If `False`, the model is added to the existing world specified by `world_index`.\n
            If `True`, a new world is created and added to the builder. In this case the `world_index`
            argument is ignored, and the index of the newly created world will be used instead.\n
        world_index (int):
            The index of the world to which the model should be added if `new_world` is False.\n
            If `new_world` is True, this argument is ignored.\n
            If the value does not correspond to an existing world, an error will be raised.\n
            Defaults to `0`.

    Returns:
        ModelBuilderKamino: A model builder containing the four-bar linkage.
    """
    # Create a new builder if none is provided
    if builder is None:
        _builder = ModelBuilderKamino(default_world=False)
    else:
        _builder = builder

    # Create a new world in the builder if requested or if a new builder was created
    if new_world or builder is None:
        world_index = _builder.add_world(name="boxes_fourbar")

    # Set default actuator IDs if none are provided
    if actuator_ids is None:
        actuator_ids = [1, 3]
    elif not isinstance(actuator_ids, list):
        raise TypeError("actuator_ids, if specified, must be provided as a list of integers.")

    ###
    # Base Parameters
    ###

    # Constant to set an initial z offset for the bodies
    # NOTE: for testing purposes, recommend values are {0.0, -0.001}
    z_0 = z_offset

    # Box dimensions
    d = 0.01
    w = 0.01
    h = 0.1

    # Margins
    mj = 0.001
    dj = 0.5 * d + mj

    ###
    # Body parameters
    ###

    # Box dimensions
    d_1 = h
    w_1 = w
    h_1 = d
    d_2 = d
    w_2 = w
    h_2 = h
    d_3 = h
    w_3 = w
    h_3 = d
    d_4 = d
    w_4 = w
    h_4 = h

    # Inertial properties
    m_i = 1.0
    i_I_i_1 = inertia.solid_cuboid_body_moment_of_inertia(m_i, d_1, w_1, h_1)
    i_I_i_2 = inertia.solid_cuboid_body_moment_of_inertia(m_i, d_2, w_2, h_2)
    i_I_i_3 = inertia.solid_cuboid_body_moment_of_inertia(m_i, d_3, w_3, h_3)
    i_I_i_4 = inertia.solid_cuboid_body_moment_of_inertia(m_i, d_4, w_4, h_4)
    if verbose:
        print(f"i_I_i_1:\n{i_I_i_1}")
        print(f"i_I_i_2:\n{i_I_i_2}")
        print(f"i_I_i_3:\n{i_I_i_3}")
        print(f"i_I_i_4:\n{i_I_i_4}")

    # Initial body positions
    r_0 = vec3f(0.0, 0.0, z_0)
    dr_b1 = vec3f(0.0, 0.0, 0.5 * d)
    dr_b2 = vec3f(0.5 * h + dj, 0.0, 0.5 * h + dj)
    dr_b3 = vec3f(0.0, 0.0, 0.5 * d + h + dj + mj)
    dr_b4 = vec3f(-0.5 * h - dj, 0.0, 0.5 * h + dj)

    # Initial positions of the bodies
    r_b1 = r_0 + dr_b1
    r_b2 = r_b1 + dr_b2
    r_b3 = r_b1 + dr_b3
    r_b4 = r_b1 + dr_b4
    if verbose:
        print(f"r_b1: {r_b1}")
        print(f"r_b2: {r_b2}")
        print(f"r_b3: {r_b3}")
        print(f"r_b4: {r_b4}")

    # Initial body poses
    q_i_1 = transformf(r_b1, wp.quat_identity())
    q_i_2 = transformf(r_b2, wp.quat_identity())
    q_i_3 = transformf(r_b3, wp.quat_identity())
    q_i_4 = transformf(r_b4, wp.quat_identity())

    # Initial joint positions
    r_j1 = vec3f(r_b2.x, 0.0, r_b1.z)
    r_j2 = vec3f(r_b2.x, 0.0, r_b3.z)
    r_j3 = vec3f(r_b4.x, 0.0, r_b3.z)
    r_j4 = vec3f(r_b4.x, 0.0, r_b1.z)
    if verbose:
        print(f"r_j1: {r_j1}")
        print(f"r_j2: {r_j2}")
        print(f"r_j3: {r_j3}")
        print(f"r_j4: {r_j4}")

    # Joint axes matrix
    X_j = Axis.Y.to_mat33()

    ###
    # Bodies
    ###

    bid1 = _builder.add_rigid_body(
        name="link_1",
        m_i=m_i,
        i_I_i=i_I_i_1,
        q_i_0=q_i_1,
        u_i_0=vec6f(0.0),
        world_index=world_index,
    )

    bid2 = _builder.add_rigid_body(
        name="link_2",
        m_i=m_i,
        i_I_i=i_I_i_2,
        q_i_0=q_i_2,
        u_i_0=vec6f(0.0),
        world_index=world_index,
    )

    bid3 = _builder.add_rigid_body(
        name="link_3",
        m_i=m_i,
        i_I_i=i_I_i_3,
        q_i_0=q_i_3,
        u_i_0=vec6f(0.0),
        world_index=world_index,
    )

    bid4 = _builder.add_rigid_body(
        name="link_4",
        m_i=m_i,
        i_I_i=i_I_i_4,
        q_i_0=q_i_4,
        u_i_0=vec6f(0.0),
        world_index=world_index,
    )

    ###
    # Joints
    ###

    if limits:
        qmin = -0.25 * math.pi
        qmax = 0.25 * math.pi
    else:
        qmin = float(FLOAT32_MIN)
        qmax = float(FLOAT32_MAX)

    if fixedbase:
        _builder.add_joint(
            name="world_to_link1",
            dof_type=JointDoFType.FIXED,
            act_type=JointActuationType.PASSIVE,
            bid_B=-1,
            bid_F=bid1,
            B_r_Bj=vec3f(0.0),
            F_r_Fj=-r_b1,
            X_j=I_3,
            world_index=world_index,
        )

    if floatingbase:
        _builder.add_joint(
            name="world_to_link1",
            dof_type=JointDoFType.FREE,
            act_type=JointActuationType.FORCE if 0 in actuator_ids else JointActuationType.PASSIVE,
            bid_B=-1,
            bid_F=bid1,
            B_r_Bj=vec3f(0.0),
            F_r_Fj=vec3f(0.0),
            X_j=I_3,
            world_index=world_index,
        )

    joint_1_type_if_implicit_pd = JointActuationType.POSITION_VELOCITY if implicit_pd else JointActuationType.FORCE
    joint_1_type = joint_1_type_if_implicit_pd if 1 in actuator_ids else JointActuationType.PASSIVE
    _builder.add_joint(
        name="link1_to_link2",
        dof_type=JointDoFType.REVOLUTE,
        act_type=joint_1_type,
        bid_B=bid1,
        bid_F=bid2,
        B_r_Bj=r_j1 - r_b1,
        F_r_Fj=r_j1 - r_b2,
        X_j=X_j,
        q_j_min=[qmin],
        q_j_max=[qmax],
        a_j=0.1 if dynamic_joints else None,
        b_j=0.001 if dynamic_joints else None,
        k_p_j=1000.0 if implicit_pd else None,
        k_d_j=20.0 if implicit_pd else None,
        world_index=world_index,
    )

    _builder.add_joint(
        name="link2_to_link3",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.FORCE if 2 in actuator_ids else JointActuationType.PASSIVE,
        bid_B=bid2,
        bid_F=bid3,
        B_r_Bj=r_j2 - r_b2,
        F_r_Fj=r_j2 - r_b3,
        X_j=X_j,
        q_j_min=[qmin],
        q_j_max=[qmax],
        world_index=world_index,
    )

    _builder.add_joint(
        name="link3_to_link4",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.FORCE if 3 in actuator_ids else JointActuationType.PASSIVE,
        bid_B=bid3,
        bid_F=bid4,
        B_r_Bj=r_j3 - r_b3,
        F_r_Fj=r_j3 - r_b4,
        X_j=X_j,
        q_j_min=[qmin],
        q_j_max=[qmax],
        world_index=world_index,
    )

    _builder.add_joint(
        name="link4_to_link1",
        dof_type=JointDoFType.REVOLUTE,
        act_type=JointActuationType.FORCE if 4 in actuator_ids else JointActuationType.PASSIVE,
        bid_B=bid4,
        bid_F=bid1,
        B_r_Bj=r_j4 - r_b4,
        F_r_Fj=r_j4 - r_b1,
        X_j=X_j,
        q_j_min=[qmin],
        q_j_max=[qmax],
        world_index=world_index,
    )

    ###
    # Geometries
    ###

    # Add collision geometries
    _builder.add_geometry(name="box_1", body=bid1, shape=BoxShape(d_1, w_1, h_1), world_index=world_index)
    _builder.add_geometry(name="box_2", body=bid2, shape=BoxShape(d_2, w_2, h_2), world_index=world_index)
    _builder.add_geometry(name="box_3", body=bid3, shape=BoxShape(d_3, w_3, h_3), world_index=world_index)
    _builder.add_geometry(name="box_4", body=bid4, shape=BoxShape(d_4, w_4, h_4), world_index=world_index)

    # Add a static collision geometry for the plane
    if ground:
        _builder.add_geometry(
            name="ground",
            body=-1,
            shape=BoxShape(20.0, 20.0, 1.0),
            offset=transformf(0.0, 0.0, -0.5, 0.0, 0.0, 0.0, 1.0),
            world_index=world_index,
        )

    # Return the lists of element indices
    return _builder


def make_basics_heterogeneous_builder(
    ground: bool = True,
    dynamic_joints: bool = False,
    implicit_pd: bool = False,
) -> ModelBuilderKamino:
    """
    Creates a multi-world builder with different worlds in each model.

    This function constructs a model builder containing all basic models.

    Returns:
        ModelBuilderKamino: The constructed model builder.
    """
    builder = ModelBuilderKamino(default_world=False)
    builder.add_builder(build_boxes_fourbar(ground=ground, dynamic_joints=dynamic_joints, implicit_pd=implicit_pd))
    builder.add_builder(build_boxes_nunchaku(ground=ground))
    builder.add_builder(build_boxes_hinged(ground=ground, dynamic_joints=dynamic_joints, implicit_pd=implicit_pd))
    builder.add_builder(build_box_pendulum(ground=ground, dynamic_joints=dynamic_joints, implicit_pd=implicit_pd))
    builder.add_builder(build_box_on_plane(ground=ground))
    builder.add_builder(build_cartpole(z_offset=0.5, ground=ground))
    return builder
