"""
Tests for the visualization module.

We test that heatmap functions return valid matplotlib figures
without errors, using synthetic activation tensors.
"""

import pytest
import torch
import matplotlib
import matplotlib.figure

from neuronview.visualize import heatmap, _activation_to_2d

# Use non-interactive backend so tests don't pop up windows
matplotlib.use("Agg")


@pytest.fixture
def fake_activation():
    """A synthetic activation tensor: batch=1, channels=16, 8x8 spatial."""
    return torch.randn(1, 16, 8, 8)


class TestActivationTo2D:
    def test_mean_across_channels(self, fake_activation):
        arr = _activation_to_2d(fake_activation, channel=None)
        assert arr.shape == (8, 8)
        assert arr.min() >= 0.0
        assert arr.max() <= 1.0

    def test_single_channel(self, fake_activation):
        arr = _activation_to_2d(fake_activation, channel=3)
        assert arr.shape == (8, 8)

    def test_invalid_channel_raises(self, fake_activation):
        with pytest.raises(IndexError, match="out of range"):
            _activation_to_2d(fake_activation, channel=99)

    def test_constant_activation(self):
        """If all activations are the same value, result should be all zeros."""
        constant = torch.ones(1, 4, 8, 8) * 5.0
        arr = _activation_to_2d(constant)
        assert arr.sum() == 0.0  # normalized constant → all zeros


class TestHeatmap:
    def test_returns_figure(self, fake_activation):
        fig = heatmap(fake_activation)
        assert isinstance(fig, matplotlib.figure.Figure)

    def test_custom_cmap(self, fake_activation):
        fig = heatmap(fake_activation, cmap="inferno")
        assert isinstance(fig, matplotlib.figure.Figure)

    def test_specific_channel(self, fake_activation):
        fig = heatmap(fake_activation, channel=0)
        assert isinstance(fig, matplotlib.figure.Figure)

    def test_save_path(self, fake_activation, tmp_path):
        path = str(tmp_path / "test_heatmap.png")
        fig = heatmap(fake_activation, save_path=path)
        assert isinstance(fig, matplotlib.figure.Figure)
        import os
        assert os.path.exists(path)
