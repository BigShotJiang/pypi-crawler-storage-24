"""
Tests for the neuronview library.

These tests use a tiny custom CNN so they run fast without downloading
pretrained weights. The test model has a known structure:
    SimpleCNN
    ├── conv1 (Conv2d)
    ├── relu1 (ReLU)
    ├── conv2 (Conv2d)
    ├── relu2 (ReLU)
    └── fc (Linear)
"""

import pytest
import torch
import torch.nn as nn

from neuronview import Inspector, list_layers


# ------------------------------------------------------------------
# Test fixtures: a tiny CNN we fully control
# ------------------------------------------------------------------


class SimpleCNN(nn.Module):
    """Minimal CNN for testing. Two conv layers + one linear layer."""

    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 8, kernel_size=3, padding=1)
        self.relu1 = nn.ReLU()
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.relu2 = nn.ReLU()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(16, 5)

    def forward(self, x):
        x = self.relu1(self.conv1(x))
        x = self.relu2(self.conv2(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x


@pytest.fixture
def model():
    return SimpleCNN()


@pytest.fixture
def sample_input():
    """A random 32x32 RGB image as a batch of 1."""
    return torch.randn(1, 3, 32, 32)


# ------------------------------------------------------------------
# Tests for list_layers
# ------------------------------------------------------------------


class TestListLayers:
    def test_finds_all_leaf_layers(self, model):
        layers = list_layers(model)
        assert "conv1" in layers
        assert "conv2" in layers
        assert "relu1" in layers
        assert "fc" in layers

    def test_excludes_containers_by_default(self, model):
        """Container modules (Sequential, etc.) should be skipped."""
        layers = list_layers(model)
        # Our SimpleCNN has no Sequential, but verify no empty names
        assert "" not in layers

    def test_returns_list_of_strings(self, model):
        layers = list_layers(model)
        assert isinstance(layers, list)
        assert all(isinstance(name, str) for name in layers)


# ------------------------------------------------------------------
# Tests for Inspector
# ------------------------------------------------------------------


class TestInspector:
    def test_watch_and_run(self, model, sample_input):
        """Core functionality: watch a layer, run input, get activations."""
        inspector = Inspector(model)
        inspector.watch("conv1")
        inspector.run(sample_input)

        act = inspector.get_activations("conv1")
        # conv1 outputs 8 channels, input is 32x32 with padding=1 → 32x32
        assert act.shape == (1, 8, 32, 32)

    def test_activations_are_detached(self, model, sample_input):
        """Activations should not require gradients."""
        inspector = Inspector(model)
        inspector.watch("conv1")
        inspector.run(sample_input)

        act = inspector.get_activations("conv1")
        assert not act.requires_grad

    def test_watch_multiple_layers(self, model, sample_input):
        """Can watch several layers simultaneously."""
        inspector = Inspector(model)
        inspector.watch("conv1").watch("conv2")
        inspector.run(sample_input)

        act1 = inspector.get_activations("conv1")
        act2 = inspector.get_activations("conv2")
        assert act1.shape[1] == 8   # conv1 has 8 output channels
        assert act2.shape[1] == 16  # conv2 has 16 output channels

    def test_get_activations_auto_select_single(self, model, sample_input):
        """If only one layer is watched, layer_name can be omitted."""
        inspector = Inspector(model)
        inspector.watch("conv1")
        inspector.run(sample_input)

        act = inspector.get_activations()  # no name needed
        assert act.shape == (1, 8, 32, 32)

    def test_get_activations_requires_name_for_multiple(self, model, sample_input):
        """If multiple layers watched, must specify which one."""
        inspector = Inspector(model)
        inspector.watch("conv1").watch("conv2")
        inspector.run(sample_input)

        with pytest.raises(ValueError, match="Multiple layers"):
            inspector.get_activations()

    def test_run_without_watch_raises(self, model, sample_input):
        """Running without watching any layer should raise an error."""
        inspector = Inspector(model)
        with pytest.raises(RuntimeError, match="No layers are being watched"):
            inspector.run(sample_input)

    def test_invalid_layer_name_raises(self, model):
        """Watching a nonexistent layer should raise ValueError."""
        inspector = Inspector(model)
        with pytest.raises(ValueError, match="not found"):
            inspector.watch("nonexistent_layer")

    def test_unwatch_removes_hook(self, model, sample_input):
        """After unwatching, activations should no longer be captured."""
        inspector = Inspector(model)
        inspector.watch("conv1")
        inspector.run(sample_input)
        assert "conv1" in inspector._activations

        inspector.unwatch("conv1")
        assert "conv1" not in inspector._hooks
        assert "conv1" not in inspector._activations

    def test_clear_keeps_hooks(self, model, sample_input):
        """clear() should remove activations but keep hooks active."""
        inspector = Inspector(model)
        inspector.watch("conv1")
        inspector.run(sample_input)
        assert "conv1" in inspector._activations

        inspector.clear()
        assert "conv1" not in inspector._activations
        assert "conv1" in inspector._hooks  # hook still there

    def test_chaining(self, model):
        """watch() and unwatch() should return self for chaining."""
        inspector = Inspector(model)
        result = inspector.watch("conv1").watch("conv2")
        assert result is inspector

    def test_repr(self, model):
        """__repr__ should include model name and watched layers."""
        inspector = Inspector(model)
        inspector.watch("conv1")
        r = repr(inspector)
        assert "SimpleCNN" in r
        assert "conv1" in r
