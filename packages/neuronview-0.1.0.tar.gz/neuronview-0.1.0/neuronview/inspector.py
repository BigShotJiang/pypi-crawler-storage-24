"""
inspector.py — The core of neuronview.

This module contains the Inspector class, which uses PyTorch's forward hook
mechanism to capture activations from any layer in a model.

HOW FORWARD HOOKS WORK:
    PyTorch lets you register a callback on any nn.Module. Every time a
    forward pass runs through that module, your callback receives:
        - module: the layer itself
        - input:  the tensor(s) going INTO the layer
        - output: the tensor(s) coming OUT of the layer (the "activations")

    We grab `output`, detach it from the computation graph (so it doesn't
    affect gradients), and store it. That's it — that's the whole trick.
"""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn

from neuronview.visualize import heatmap, heatmap_overlay
from neuronview.utils import list_layers, _get_layer_by_name


class Inspector:
    """Attach to a PyTorch model and capture activations from watched layers.

    Parameters
    ----------
    model : nn.Module
        The PyTorch model to inspect.

    Example
    -------
    >>> import torchvision.models as models
    >>> model = models.resnet18(pretrained=True)
    >>> inspector = Inspector(model)
    >>> inspector.watch("layer2.0.conv1")
    >>> inspector.run(my_image_tensor)
    >>> inspector.heatmap()
    """

    def __init__(self, model: nn.Module) -> None:
        self.model = model
        self.model.eval()  # always inspect in eval mode

        # Maps layer name -> captured activation tensor
        self._activations: dict[str, torch.Tensor] = {}

        # Maps layer name -> hook handle (so we can remove hooks later)
        self._hooks: dict[str, torch.utils.hooks.RemovableHook] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def watch(self, layer_name: str) -> "Inspector":
        """Register a forward hook on the named layer.

        Parameters
        ----------
        layer_name : str
            Dot-separated path to the layer, e.g. "layer2.0.conv1".
            Use ``Inspector.layers()`` to discover valid names.

        Returns
        -------
        Inspector
            Returns self so you can chain calls:
            ``inspector.watch("layer1").watch("layer2")``
        """
        if layer_name in self._hooks:
            return self  # already watching

        layer = _get_layer_by_name(self.model, layer_name)

        def hook_fn(module, input, output, name=layer_name):
            """Capture the output tensor when this layer runs."""
            # .detach() prevents this from being part of the gradient graph
            # .cpu() moves it off GPU so we don't hold GPU memory
            if isinstance(output, torch.Tensor):
                self._activations[name] = output.detach().cpu()
            elif isinstance(output, tuple):
                # Some layers return tuples; grab the first tensor
                self._activations[name] = output[0].detach().cpu()

        handle = layer.register_forward_hook(hook_fn)
        self._hooks[layer_name] = handle
        return self

    def run(self, x: torch.Tensor) -> torch.Tensor:
        """Run a forward pass through the model and capture activations.

        Parameters
        ----------
        x : torch.Tensor
            Input tensor. For image models, typically shape (1, C, H, W).

        Returns
        -------
        torch.Tensor
            The model's output (predictions).
        """
        if not self._hooks:
            raise RuntimeError(
                "No layers are being watched. "
                "Call inspector.watch('layer_name') first."
            )

        with torch.no_grad():
            output = self.model(x)
        return output

    def get_activations(self, layer_name: Optional[str] = None) -> torch.Tensor:
        """Retrieve captured activations.

        Parameters
        ----------
        layer_name : str, optional
            Which layer's activations to return. If None and only one layer
            is being watched, returns that layer's activations.

        Returns
        -------
        torch.Tensor
            The activation tensor, typically shape (batch, channels, H, W).
        """
        if layer_name is None:
            if len(self._activations) == 1:
                return next(iter(self._activations.values()))
            raise ValueError(
                f"Multiple layers watched: {list(self._activations.keys())}. "
                "Specify which one with layer_name=."
            )

        if layer_name not in self._activations:
            raise KeyError(
                f"No activations for '{layer_name}'. "
                "Did you call inspector.run() after inspector.watch()?"
            )
        return self._activations[layer_name]

    def heatmap(
        self,
        layer_name: Optional[str] = None,
        channel: Optional[int] = None,
        **kwargs,
    ):
        """Show a heatmap of the captured activations.

        Parameters
        ----------
        layer_name : str, optional
            Which layer to visualize. Can be omitted if only one is watched.
        channel : int, optional
            Specific channel to show. If None, averages across all channels.
        **kwargs
            Passed to matplotlib (cmap, figsize, etc.)

        Returns
        -------
        matplotlib.figure.Figure
        """
        act = self.get_activations(layer_name)
        return heatmap(act, channel=channel, **kwargs)

    def heatmap_overlay(
        self,
        original_image: torch.Tensor,
        layer_name: Optional[str] = None,
        channel: Optional[int] = None,
        alpha: float = 0.5,
        **kwargs,
    ):
        """Overlay the activation heatmap on the original image.

        Parameters
        ----------
        original_image : torch.Tensor
            The input image tensor, shape (C, H, W) or (1, C, H, W).
        layer_name : str, optional
            Which layer to visualize.
        channel : int, optional
            Specific channel. If None, averages across all channels.
        alpha : float
            Transparency of the heatmap overlay (0 = invisible, 1 = opaque).

        Returns
        -------
        matplotlib.figure.Figure
        """
        act = self.get_activations(layer_name)
        return heatmap_overlay(
            act, original_image, channel=channel, alpha=alpha, **kwargs
        )

    def layers(self) -> list[str]:
        """List all hookable layers in the model.

        Returns
        -------
        list[str]
            Layer names you can pass to ``watch()``.
        """
        return list_layers(self.model)

    def unwatch(self, layer_name: Optional[str] = None) -> "Inspector":
        """Remove hooks and free captured activations.

        Parameters
        ----------
        layer_name : str, optional
            Specific layer to unwatch. If None, removes ALL hooks.
        """
        if layer_name is None:
            for handle in self._hooks.values():
                handle.remove()
            self._hooks.clear()
            self._activations.clear()
        else:
            if layer_name in self._hooks:
                self._hooks[layer_name].remove()
                del self._hooks[layer_name]
            self._activations.pop(layer_name, None)
        return self

    def clear(self) -> "Inspector":
        """Clear stored activations without removing hooks.

        Useful between forward passes when you want fresh data.
        """
        self._activations.clear()
        return self

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        watched = list(self._hooks.keys())
        captured = list(self._activations.keys())
        return (
            f"Inspector(model={self.model.__class__.__name__}, "
            f"watching={watched}, captured={captured})"
        )

    def __del__(self) -> None:
        """Clean up hooks when the Inspector is garbage-collected."""
        self.unwatch()
