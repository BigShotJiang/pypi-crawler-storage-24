"""
visualize.py — Heatmap rendering for activation tensors.

This module turns raw activation tensors into matplotlib figures.
The key idea: take a 4D tensor (batch, channels, H, W), reduce it
to a 2D heatmap, and render it with matplotlib's imshow.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import torch
import matplotlib.pyplot as plt
import matplotlib.figure


def _activation_to_2d(
    activation: torch.Tensor,
    channel: Optional[int] = None,
    batch_index: int = 0,
) -> np.ndarray:
    """Convert a 4D activation tensor to a 2D numpy array for plotting.

    Parameters
    ----------
    activation : torch.Tensor
        Shape (batch, channels, H, W) — the raw captured activation.
    channel : int, optional
        If given, show only this channel. If None, average across all channels.
        Averaging gives a "summary" of what the layer sees overall.
    batch_index : int
        Which image in the batch to visualize (default: first).

    Returns
    -------
    np.ndarray
        2D array of shape (H, W), normalized to [0, 1].
    """
    # Grab one image from the batch
    act = activation[batch_index]  # shape: (channels, H, W)

    if channel is not None:
        if channel < 0 or channel >= act.shape[0]:
            raise IndexError(
                f"Channel {channel} out of range. "
                f"This layer has {act.shape[0]} channels (0-{act.shape[0]-1})."
            )
        arr = act[channel].numpy()  # shape: (H, W)
    else:
        # Average across all channels — this is the standard approach
        # for getting a single "activation intensity" map
        arr = act.mean(dim=0).numpy()  # shape: (H, W)

    # Normalize to [0, 1] for consistent color mapping
    arr_min, arr_max = arr.min(), arr.max()
    if arr_max - arr_min > 0:
        arr = (arr - arr_min) / (arr_max - arr_min)
    else:
        arr = np.zeros_like(arr)

    return arr


def heatmap(
    activation: torch.Tensor,
    channel: Optional[int] = None,
    cmap: str = "viridis",
    figsize: tuple[int, int] = (6, 5),
    title: Optional[str] = None,
    save_path: Optional[str] = None,
    **kwargs,
) -> matplotlib.figure.Figure:
    """Render an activation tensor as a heatmap.

    Parameters
    ----------
    activation : torch.Tensor
        Shape (batch, channels, H, W).
    channel : int, optional
        Specific channel index. None = average all channels.
    cmap : str
        Matplotlib colormap name (default "viridis").
        Try "inferno", "magma", "plasma", or "hot" for alternatives.
    figsize : tuple
        Figure size in inches.
    title : str, optional
        Title for the plot.
    save_path : str, optional
        If given, saves the figure to this path.

    Returns
    -------
    matplotlib.figure.Figure
    """
    arr = _activation_to_2d(activation, channel=channel)

    fig, ax = plt.subplots(1, 1, figsize=figsize)
    im = ax.imshow(arr, cmap=cmap, **kwargs)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    if title:
        ax.set_title(title)
    elif channel is not None:
        ax.set_title(f"Channel {channel}")
    else:
        ax.set_title("Mean activation across all channels")

    ax.axis("off")
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig


def heatmap_overlay(
    activation: torch.Tensor,
    original_image: torch.Tensor,
    channel: Optional[int] = None,
    alpha: float = 0.5,
    cmap: str = "jet",
    figsize: tuple[int, int] = (6, 5),
    title: Optional[str] = None,
    save_path: Optional[str] = None,
    **kwargs,
) -> matplotlib.figure.Figure:
    """Overlay an activation heatmap on top of the original image.

    This is especially useful for understanding WHAT region of the input
    image triggered the strongest activations.

    Parameters
    ----------
    activation : torch.Tensor
        Shape (batch, channels, H, W).
    original_image : torch.Tensor
        The input image, shape (C, H, W) or (1, C, H, W).
        Values should be in [0, 1] or standard ImageNet range.
    channel : int, optional
        Specific channel. None = average all.
    alpha : float
        Heatmap opacity (0 = transparent, 1 = fully opaque).
    cmap : str
        Colormap for the heatmap overlay (default "jet" for vivid colors).
    figsize : tuple
        Figure size.
    title : str, optional
        Plot title.
    save_path : str, optional
        Save the figure to this path.

    Returns
    -------
    matplotlib.figure.Figure
    """
    # Prepare the heatmap
    act_2d = _activation_to_2d(activation, channel=channel)

    # Prepare the original image for display
    img = original_image.detach().cpu()
    if img.dim() == 4:
        img = img[0]  # remove batch dim
    # Convert from (C, H, W) to (H, W, C) for matplotlib
    img = img.permute(1, 2, 0).numpy()

    # Normalize image to [0, 1] if needed
    if img.max() > 1.0:
        img = (img - img.min()) / (img.max() - img.min())
    img = np.clip(img, 0, 1)

    # Resize heatmap to match image dimensions
    from PIL import Image

    heatmap_resized = np.array(
        Image.fromarray((act_2d * 255).astype(np.uint8)).resize(
            (img.shape[1], img.shape[0]), Image.BILINEAR
        )
    ) / 255.0

    # Plot
    fig, ax = plt.subplots(1, 1, figsize=figsize)
    ax.imshow(img)
    ax.imshow(heatmap_resized, cmap=cmap, alpha=alpha, **kwargs)

    if title:
        ax.set_title(title)
    else:
        ax.set_title("Activation overlay")

    ax.axis("off")
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")

    return fig
