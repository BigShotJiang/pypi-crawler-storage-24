"""
neuronview — A lightweight PyTorch activation heatmap visualizer.

Inspect what your neural network sees by hooking into any layer
and visualizing its activations as heatmaps.

Basic usage:
    >>> from neuronview import Inspector
    >>> inspector = Inspector(model)
    >>> inspector.watch("layer2.0.conv1")
    >>> inspector.run(input_tensor)
    >>> inspector.heatmap()
"""

from neuronview.inspector import Inspector
from neuronview.visualize import heatmap, heatmap_overlay
from neuronview.utils import list_layers

__version__ = "0.1.0"
__all__ = ["Inspector", "heatmap", "heatmap_overlay", "list_layers"]
