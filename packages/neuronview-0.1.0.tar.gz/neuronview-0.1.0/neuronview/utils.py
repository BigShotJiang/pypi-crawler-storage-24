"""
utils.py — Helper utilities for neuronview.

The main utility here is `list_layers`, which walks a PyTorch model
and returns the dot-path names of every hookable layer.

UNDERSTANDING PYTORCH'S MODULE TREE:
    A PyTorch model is a tree of nn.Module objects. For example, ResNet18:
        model.layer1.0.conv1  →  a Conv2d module
        model.layer1.0.bn1    →  a BatchNorm2d module
        model.fc              →  a Linear module

    The `named_modules()` method walks this tree and yields
    (name, module) pairs. We use these names as the "address"
    to hook into specific layers.
"""

from __future__ import annotations

import torch.nn as nn


def list_layers(model: nn.Module, include_containers: bool = False) -> list[str]:
    """List all hookable layers in a model by their dot-path name.

    Parameters
    ----------
    model : nn.Module
        The PyTorch model to inspect.
    include_containers : bool
        If False (default), skip container modules like Sequential,
        ModuleList, etc. — these are just wrappers and rarely useful
        to hook into. Set True to include everything.

    Returns
    -------
    list[str]
        Sorted list of layer names you can pass to ``Inspector.watch()``.

    Example
    -------
    >>> import torchvision.models as models
    >>> model = models.resnet18()
    >>> layers = list_layers(model)
    >>> print(layers[:5])
    ['conv1', 'bn1', 'relu', 'maxpool', 'layer1.0.conv1']
    """
    # Container types that are just structural, not computational
    _CONTAINER_TYPES = (
        nn.Sequential,
        nn.ModuleList,
        nn.ModuleDict,
    )

    layer_names = []
    for name, module in model.named_modules():
        if not name:
            continue  # skip the root module itself

        if not include_containers and isinstance(module, _CONTAINER_TYPES):
            continue

        layer_names.append(name)

    return layer_names


def _get_layer_by_name(model: nn.Module, layer_name: str) -> nn.Module:
    """Retrieve a specific layer from a model by its dot-path name.

    Parameters
    ----------
    model : nn.Module
        The model.
    layer_name : str
        Dot-separated path, e.g. "layer2.0.conv1".

    Returns
    -------
    nn.Module
        The target layer.

    Raises
    ------
    ValueError
        If the layer name doesn't exist in the model.
    """
    parts = layer_name.split(".")
    current = model

    for part in parts:
        try:
            # Try numeric index first (for Sequential / ModuleList)
            if part.isdigit():
                current = current[int(part)]
            else:
                current = getattr(current, part)
        except (AttributeError, IndexError, TypeError):
            available = list_layers(model)
            raise ValueError(
                f"Layer '{layer_name}' not found in {model.__class__.__name__}. "
                f"Available layers include: {available[:10]}..."
            )

    return current
