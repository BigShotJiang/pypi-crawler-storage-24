"""
AzerAI Reminder Plugin - Azərbaycan dilində hatırlatma sistemi

Plugin əsaslı, çoxdilli AI asistenti üçün hatırlatma modulu.
"""

__version__ = "3.0.5"
__author__ = "AzStudio Dev"
__email__ = "info.azstudiodev@gmail.com"

from .plugins.reminder.main import (
    create_reminder,
    create_daily_reminder,
    list_reminders,
    delete_reminder,
    pause_reminder,
    resume_reminder,
    reminder_tools
)

__all__ = [
    "create_reminder",
    "create_daily_reminder", 
    "list_reminders",
    "delete_reminder",
    "pause_reminder",
    "resume_reminder",
    "reminder_tools"
]
