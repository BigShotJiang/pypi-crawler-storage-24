import unittest

from pilot_status.webhooks.parse import WebhookParseError, is_customer_webhook_event, parse_customer_webhook


class TestWebhooks(unittest.TestCase):
    def test_parse_message_failed(self):
        payload = {
            "event": "message.failed",
            "data": {
                "messageId": "m_123",
                "correlationId": "c_123",
                "environment": "TEST",
                "destinationNumber": "+5511999999999",
                "projectSlug": "my-project",
                "content": "hello",
                "status": "FAILED",
                "failedAt": "2026-01-01T00:00:00.000Z",
                "errorMessage": "oops",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "message.failed")
        self.assertEqual(event["data"]["status"], "FAILED")

    def test_is_customer_webhook_event_true(self):
        payload = {
            "event": "message.sent",
            "data": {
                "messageId": "m_123",
                "correlationId": "c_123",
                "environment": "LIVE",
                "destinationNumber": "+5511999999999",
                "projectSlug": "my-project",
                "content": "hello",
                "status": "SENT",
                "sentAt": "2026-01-01T00:00:00.000Z",
            },
        }
        self.assertTrue(is_customer_webhook_event(payload))

    def test_parse_invalid_payload_raises(self):
        with self.assertRaises(WebhookParseError) as ctx:
            parse_customer_webhook({"event": "message.sent", "data": {}})
        self.assertGreaterEqual(len(ctx.exception.issues), 1)


if __name__ == "__main__":
    unittest.main()

