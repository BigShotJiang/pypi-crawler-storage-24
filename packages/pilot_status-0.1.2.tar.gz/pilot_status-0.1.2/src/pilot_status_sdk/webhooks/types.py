from __future__ import annotations

from typing import Literal, TypedDict, Union

from ..types import Environment


class MessageSentData(TypedDict):
    messageId: str
    correlationId: str
    environment: Environment
    destinationNumber: str
    projectSlug: str
    content: str
    status: Literal["SENT"]
    sentAt: str


class MessageSentEvent(TypedDict):
    event: Literal["message.sent"]
    data: MessageSentData


class MessageReadData(TypedDict):
    messageId: str
    correlationId: str
    environment: Environment
    destinationNumber: str
    projectSlug: str
    content: str
    status: Literal["READ"]
    readAt: str


class MessageReadEvent(TypedDict):
    event: Literal["message.read"]
    data: MessageReadData


class MessageFailedData(TypedDict):
    messageId: str
    correlationId: str
    environment: Environment
    destinationNumber: str
    projectSlug: str
    content: str
    status: Literal["FAILED"]
    failedAt: str
    errorMessage: str


class MessageFailedEvent(TypedDict):
    event: Literal["message.failed"]
    data: MessageFailedData


MessageReplyData = TypedDict(
    "MessageReplyData",
    {
        "from": str,
        "destinationNumber": str,
        "projectSlug": str,
        "content": str,
        "replyContent": str,
        "receivedAt": str,
        "lastMessageId": str,
        "correlationId": str,
        "environment": Environment,
    },
)


class MessageReplyEvent(TypedDict):
    event: Literal["message.reply"]
    data: MessageReplyData


CustomerWebhookEvent = Union[MessageSentEvent, MessageReadEvent, MessageFailedEvent, MessageReplyEvent]
