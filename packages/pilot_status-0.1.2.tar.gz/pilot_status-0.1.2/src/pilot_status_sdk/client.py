from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import urllib.request

from .http import HttpClient, HttpClientOptions
from .resources import AnalyticsResource, MessagesResource


@dataclass(frozen=True)
class PilotStatusClientOptions:
    api_key: str
    timeout_s: float = 30.0
    user_agent: str | None = None
    get_retries: int = 2
    transport: Callable[[urllib.request.Request, float], tuple[int, dict[str, str], str]] | None = None


class PilotStatusClient:
    def __init__(self, options: PilotStatusClientOptions):
        base_url = "https://pilotstatus.online"
        http = HttpClient(
            HttpClientOptions(
                base_url=base_url,
                api_key=options.api_key,
                timeout_s=options.timeout_s,
                user_agent=options.user_agent,
                get_retries=options.get_retries,
                transport=options.transport,
            )
        )
        self.messages = MessagesResource(http)
        self.analytics = AnalyticsResource(http)

