from __future__ import annotations

from ..http import HttpClient
from ..types import DashboardStats


class AnalyticsResource:
    def __init__(self, http: HttpClient):
        self._http = http

    def get_dashboard_stats(self, *, tz: str | None = None) -> DashboardStats:
        query = None if tz is None else {"tz": tz}
        return self._http.request_json(method="GET", path="/v1/analytics/dashboard", query=query)
