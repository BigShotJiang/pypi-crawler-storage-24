from __future__ import annotations

from typing import Any

from ..http import HttpClient
from ..types import CreateProjectInput, Project


class ProjectsResource:
    def __init__(self, http: HttpClient):
        self._http = http

    def list(self) -> list[Project]:
        return self._http.request_json(method="GET", path="/v1/projects")

    def create(self, input: CreateProjectInput) -> Project:
        body: dict[str, Any] = {"name": input["name"]}
        if "description" in input:
            body["description"] = input["description"]
        return self._http.request_json(method="POST", path="/v1/projects", body=body)
