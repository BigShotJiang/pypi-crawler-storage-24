from __future__ import annotations

from typing import Literal, TypedDict

Environment = Literal["TEST", "LIVE"]

MessageStatus = Literal["QUEUED", "SENT", "FAILED", "READ"]


class SendMessageInput(TypedDict, total=False):
    templateId: str
    destinationNumber: str
    variables: dict[str, str]


class SendMessageAccepted(TypedDict):
    id: str
    correlationId: str
    status: MessageStatus
    createdAt: str
    origin: str


class MessageDetails(TypedDict):
    id: str
    status: MessageStatus
    correlationId: str
    destinationNumber: str
    template: str
    createdAt: str
    sentAt: str | None
    readAt: str | None
    errorMessage: str | None


class DashboardDailyMessages(TypedDict):
    date: str
    count: int


class DashboardStatusDistribution(TypedDict):
    queued: int
    sent: int
    failed: int
    read: int


class DashboardStats(TypedDict):
    totalSent: int
    totalFailed: int
    sentPercentChange: float
    failedPercentChange: float
    failureRate: float
    dailyMessages: list[DashboardDailyMessages]
    statusDistribution: DashboardStatusDistribution


OptInCheckReason = Literal[
    "OPTIN_DISABLED",
    "NON_DEFAULT_INSTANCE",
    "NOT_LIVE",
    "MISSING_PROJECT",
    "INVALID_PHONE",
    "NO_OPTIN",
]


class OptInCheckResult(TypedDict):
    authorized: bool
    required: bool
    enabled: bool
    reason: OptInCheckReason | None
    firstOptInAt: str | None
    lastSeenAt: str | None


class Project(TypedDict):
    id: str
    name: str
    slug: str
    description: str
    productionApproved: bool
    createdAt: str


class CreateProjectInput(TypedDict, total=False):
    name: str
    description: str


class ApiKeyCreateInput(TypedDict, total=False):
    name: str
    webhookId: str | None
    whatsappInstanceId: str | None
    retentionDays: int


class ApiKeyCreated(TypedDict):
    id: str
    name: str
    environment: Environment
    key: str
    keyPrefix: str
    createdAt: str
    webhookId: str | None
    whatsappInstanceId: str | None
    retentionDays: int


class ApiKeyLinkedWebhook(TypedDict):
    id: str
    name: str
    url: str


class ApiKeyLinkedWhatsAppInstance(TypedDict):
    id: str
    instanceName: str
    displayName: str
    number: str
    state: str


class ApiKeyListItem(TypedDict):
    id: str
    name: str
    keyPrefix: str
    environment: Environment
    lastUsedAt: str | None
    createdAt: str
    webhookId: str | None
    projectId: str | None
    webhook: ApiKeyLinkedWebhook | None
    whatsappInstanceId: str | None
    whatsappInstance: ApiKeyLinkedWhatsAppInstance | None
    retentionDays: int


class WhatsAppNumberInstance(TypedDict):
    id: str
    tenantId: str
    instanceName: str
    number: str
    displayName: str
    state: str
    integration: str
    createdAt: str
    updatedAt: str
    name: str
    status: str
    quality: Literal["GOOD", "UNKNOWN"]


class CreateNumberInput(TypedDict, total=False):
    name: str
    number: str
    linkToApiKey: bool


class CreateNumberResult(TypedDict):
    instance: WhatsAppNumberInstance
    qrcodeBase64: str | None
    linkedApiKeyId: str | None


class NumberStatusResult(TypedDict):
    id: str
    state: str
