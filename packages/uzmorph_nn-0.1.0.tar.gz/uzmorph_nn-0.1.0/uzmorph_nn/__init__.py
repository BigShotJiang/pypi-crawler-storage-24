from .uzmorph_nn import uzmorph_nn, MorphResult
from .model import MorphBiLSTM

__version__ = "0.1.0"
