# AromaTools

AromaTools is a Python package designed for the **analysis of aromaticity** using three main approaches.

---

## Aromaticity Criteria

### Magnetic Criteria (AroMagnetic)

- Compute the **induced magnetic field** in x, y, or z directions
- Calculate:

  - NICS at a single point (NICS-SP)
  - NICS-XY-Scan (1D and 2D)
  - NICS-3D

- Compute the **ring current strength** by numerical integration

---

### Geometric Criteria (AroGeometric)

- Bond Length Alternation (BLA)
- HOMA index
- HOMER index (excited state aromaticity)
- HOMAc index

Interpretation:

- HOMA = 1 → aromatic
- HOMA = 0 → non-aromatic
- HOMAc = −1 → antiaromatic

---

### Electronic Criteria (AroElectronics)

Coming soon.

---

## Installation

Install using pip:

```bash
pip install aromatools