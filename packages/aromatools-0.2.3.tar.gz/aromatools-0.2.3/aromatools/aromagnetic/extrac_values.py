#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Python modules
import os
import re
import numpy as np
from ase import io as ase_io

# AromaTools modules
from .amg_read_input import read_input

def build_distances(profile_block):
    scale = str(profile_block.get("SCALE", "Linear")).strip().upper()
    if scale == "LINEAR":
        start = float(profile_block.get("START", 0.0))
        dz = float(profile_block.get("DELTA_Z", 0.1))
        npts = int(profile_block.get("NUM_GA", 100))
        return [start + i * dz for i in range(npts)]

    if scale == "LOGARITHMIC":
        start = float(profile_block.get("START", 0.1))
        end = float(profile_block.get("END", 5.0))
        npts = int(profile_block.get("NUM_GA", 100))
        zpos = np.logspace(np.log10(start), np.log10(end), npts)
        return [float(z) for z in zpos]

    raise SystemExit("ERROR: PROFILE:SCALE must be Linear or Logarithmic")

def find_ring_outputs(name):
    rx = re.compile(rf"^({re.escape(name)}_ring\d{{4}})(?:_(\d{{4}}))?\.(out|log)$", re.IGNORECASE)
    groups = {}
    for fn in os.listdir(os.getcwd()):
        m = rx.match(fn)
        if not m:
            continue
        prefix = m.group(1)
        chunk = m.group(2)
        chunk_idx = int(chunk) if chunk is not None else -1
        groups.setdefault(prefix, []).append((chunk_idx, fn))
    out = {}
    for prefix, items in groups.items():
        items.sort(key=lambda x: x[0])
        out[prefix] = [fn for _, fn in items]
    return out

def read_real_atom_count(xyz_file):
    ats = ase_io.read(xyz_file, index=0)
    return len(ats)

_float_rx = re.compile(r"[-+]?\d+(?:\.\d+)?(?:[Ee][-+]?\d+)?")

def _parse_orca_one_file(filename):
    diags = []
    with open(filename, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if "Total shielding tensor (ppm):" in line:
            tensor_lines = []
            for j in range(i + 1, i + 4):
                if j < len(lines):
                    tline = lines[j].strip()
                    if tline:
                        tensor_lines.append(tline)
            if len(tensor_lines) == 3:
                r1 = _float_rx.findall(tensor_lines[0])
                r2 = _float_rx.findall(tensor_lines[1])
                r3 = _float_rx.findall(tensor_lines[2])
                if len(r1) >= 3 and len(r2) >= 3 and len(r3) >= 3:
                    xx = float(r1[0])
                    yy = float(r2[1])
                    zz = float(r3[2])
                    diags.append((xx, yy, zz))
            i += 4
        else:
            i += 1

    return diags

def read_orca_dummy_diags(out_files, n_real_atoms):
    diags = []
    for fn in out_files:
        all_diags = _parse_orca_one_file(fn)
        if not all_diags:
            continue
        dummy = all_diags[n_real_atoms:]
        diags.extend(dummy)
    return diags

def _read_gaussian_one_file(filename): 
    num = r"[-+]?\d+(?:\.\d+)?(?:[EeDd][-+]?\d+)?"
    rx_zz = re.compile(rf"ZZ=\s*({num})")
    rx_bq_iso_line = re.compile(rf"^\s*(?:\d+\s+)?Bq\b.*?Isotropic\s*=\s*({num})", re.IGNORECASE)

    with open(filename, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()
    iso_list = []
    for line in lines:
        m = rx_bq_iso_line.search(line)
        if m:
            iso_raw = m.group(1).replace("D", "E").replace("d", "e")
            iso_list.append(float(iso_raw))
    bq_data = []
    for i, line in enumerate(lines):
        if "Bq" not in line:
            continue
        zz = None
        for j in range(i + 1, min(i + 4, len(lines))):
            if "ZZ=" in lines[j]:
                mzz = rx_zz.search(lines[j])
                if mzz:
                    zz_raw = mzz.group(1).replace("D", "E").replace("d", "e")
                    zz = float(zz_raw)
                break
        if zz is not None:
            bq_data.append({"zz": zz, "iso": None})
    n_pair = min(len(bq_data), len(iso_list))
    for k in range(n_pair):
        bq_data[k]["iso"] = iso_list[k]

    return bq_data

def read_gaussian_dummy_diags(out_files):
    data = []
    for fn in out_files:
        data.extend(_read_gaussian_one_file(fn))
    return data

def save_csv(prefix, distances, bindz, nics):
    csv_name = f"{prefix}.csv"
    with open(csv_name, "w", encoding="utf-8") as f:
        f.write("distance_A,Bindz_ppm,NICS_microT\n")
        for d, b, n in zip(distances, bindz, nics):
            if np.isnan(n):
                f.write(f"{d:.8f},{b:.8f},\n")
            else:
                f.write(f"{d:.8f},{b:.8f},{n:.8f}\n")
    return csv_name

def main():
    cfg = read_input("INPUT.txt")
    if not cfg:
        raise SystemExit("ERROR: INPUT.txt not found")

    general = cfg.get("general", {})
    profile = cfg.get("PROFILE", {})

    name = str(general.get("NAME_MOLECULE", "molecule")).strip()
    program = str(general.get("PROGRAM", "orca")).strip().lower()
    xyz_file = general.get("MOLECULAR_COORDINATES")

    if not xyz_file or not os.path.isfile(xyz_file):
        raise SystemExit("ERROR: MOLECULAR_COORDINATES must exist for profile extraction.")

    distances = build_distances(profile)
    groups = find_ring_outputs(name)
    if not groups:
        raise SystemExit(f"ERROR: No ring output files found. Expected {name}_ring####.out/.log")

    n_real = read_real_atom_count(xyz_file)

    print("\n=== EXTRAC_VALUES (profiles) ===")
    print(f"Molecule: {name}")
    print(f"PROGRAM : {program}")
    print(f"XYZ     : {xyz_file} (real atoms: {n_real})")
    print("Convention: profiles use Bext=(0,0,1) => Bindz = -sigma_zz\n")

    for prefix, out_files in sorted(groups.items()):
        print(f"[info] {prefix}: reading {len(out_files)} file(s)")

        if "orca" in program:
            diags = read_orca_dummy_diags(out_files, n_real_atoms=n_real)
            if not diags:
                print(f"[warn] {prefix}: no dummy tensors found. Skipping.")
                continue

            n_use = min(len(diags), len(distances))
            if len(diags) != len(distances):
                print(f"[warn] {prefix}: distances={len(distances)} tensors={len(diags)} using {n_use}")

            bindz = []
            nics = []
            for (xx, yy, zz) in diags[:n_use]:
                bindz.append(-float(zz))
                iso = (float(xx) + float(yy) + float(zz)) / 3.0
                nics.append(-float(iso))

            save_csv(prefix, distances[:n_use], bindz, nics)
            print(f"[ok] wrote {prefix}.csv")

        elif "gaussian" in program:
            data = read_gaussian_dummy_diags(out_files)
            if not data:
                print(f"[warn] {prefix}: no Bq ZZ found. Skipping.")
                continue

            n_use = min(len(data), len(distances))
            if len(data) != len(distances):
                print(f"[warn] {prefix}: distances={len(distances)} tensors={len(data)} using {n_use}")

            bindz = []
            nics = []
            for item in data[:n_use]:
                zz = float(item["zz"])
                iso = item["iso"]
                bindz.append(-zz)
                if iso is not None:
                    nics.append(-iso)
                else:
                    nics.append(float("nan"))
            save_csv(prefix, distances[:n_use], bindz, nics)
            print(f"[ok] wrote {prefix}.csv")
        else:
            raise SystemExit("ERROR: PROGRAM must be ORCA or GAUSSIAN.")
    print("\nDone.")

if __name__ == "__main__":
    main()