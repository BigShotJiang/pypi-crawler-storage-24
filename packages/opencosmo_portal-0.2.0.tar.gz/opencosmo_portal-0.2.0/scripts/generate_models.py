"""Generate Pydantic models from the backend OpenAPI spec."""

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
OPENAPI_JSON = REPO_ROOT / "backend" / "openapi.json"
OUTPUT_FILE = Path(__file__).resolve().parent.parent / "src" / "ocp" / "api" / "_generated.py"


def main() -> None:
    """Run datamodel-codegen to generate Pydantic v2 models."""
    if not OPENAPI_JSON.exists():
        print(f"Error: {OPENAPI_JSON} not found.", file=sys.stderr)
        print("Run: cd backend && uv run python scripts/export_openapi.py", file=sys.stderr)
        sys.exit(1)

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable,
        "-m",
        "datamodel_code_generator",
        "--input",
        str(OPENAPI_JSON),
        "--input-file-type",
        "openapi",
        "--output",
        str(OUTPUT_FILE),
        "--output-model-type",
        "pydantic_v2.BaseModel",
        "--target-python-version",
        "3.11",
        "--use-annotated",
        "--use-union-operator",
        "--snake-case-field",
        "--capitalize-enum-members",
        "--disable-timestamp",
        "--use-double-quotes",
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        print("datamodel-codegen failed:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        sys.exit(1)

    # Normalize formatting so output matches ruff's style exactly
    fmt_result = subprocess.run(
        [sys.executable, "-m", "ruff", "format", str(OUTPUT_FILE)],
        capture_output=True,
        text=True,
    )
    if fmt_result.returncode != 0:
        print("ruff format failed:", file=sys.stderr)
        print(fmt_result.stderr, file=sys.stderr)
        sys.exit(1)

    print(f"Generated {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
