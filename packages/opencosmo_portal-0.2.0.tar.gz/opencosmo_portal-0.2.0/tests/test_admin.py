"""Tests for admin CLI commands."""

import json
from typing import Any
from unittest.mock import MagicMock, patch

from click.testing import CliRunner, Result

from ocp.main import cli

# ==================== Helpers ====================


def _mock_response(status_code: int = 200, json_data: object = None) -> MagicMock:
    """Create a mock httpx response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data
    resp.text = str(json_data)
    return resp


def _run(
    args: list[str],
    obj: dict[str, str] | None = None,
    input: str | None = None,
) -> Result:
    """Invoke the CLI with the given args."""
    runner = CliRunner()
    return runner.invoke(cli, args, obj=obj or {}, input=input, catch_exceptions=False)


def _setup_client(mock_cls: MagicMock) -> MagicMock:
    """Set up APIClient context manager mock, return the client instance."""
    mock_client = MagicMock()
    mock_cls.return_value.__enter__ = MagicMock(return_value=mock_client)
    mock_cls.return_value.__exit__ = MagicMock(return_value=False)
    return mock_client


# ==================== Sample Data ====================

SAMPLE_RUN: dict[str, Any] = {
    "run_id": "run-abc-123-def-456",
    "task_slug": "galaxy-query",
    "task_name": "Galaxy Query",
    "run_label": "test run",
    "input_data": {},
    "status": "succeeded",
    "created_at": "2026-03-01T00:00:00Z",
    "completed_at": "2026-03-01T00:05:00Z",
    "files_deleted_at": None,
    "archived_at": None,
    "external_run_url": None,
    "duration_seconds": 300.0,
    "error_message": None,
    "user_id": "user-001-abc-def",
    "user_email": "alice@example.com",
    "user_name": "Alice",
    "client_type": "web",
}

SAMPLE_RUN_2 = {
    **SAMPLE_RUN,
    "run_id": "run-xyz-789-ghi-012",
    "status": "failed",
    "user_email": "bob@example.com",
    "user_name": "Bob",
    "client_type": "python",
    "error_message": "Something went wrong",
}

SAMPLE_USER = {
    "id": "user-001-abc-def",
    "email": "alice@example.com",
    "name": "Alice",
    "created_at": "2026-01-01T00:00:00Z",
    "last_login_at": "2026-03-10T00:00:00Z",
    "run_count": 5,
    "identity_count": 1,
}

SAMPLE_USER_2 = {
    **SAMPLE_USER,
    "id": "user-002-xyz-ghi",
    "email": "bob@example.com",
    "name": "Bob",
    "run_count": 12,
}

SAMPLE_USER_DETAIL = {
    **SAMPLE_USER,
    "identities": [
        {
            "id": "ident-001",
            "provider": "globus",
            "email": "alice@example.com",
            "linked_at": "2026-01-01T00:00:00Z",
            "last_used_at": "2026-03-10T00:00:00Z",
        }
    ],
    "recent_runs": [SAMPLE_RUN],
}

SAMPLE_TASK = {
    "id": 1,
    "slug": "galaxy-query",
    "name": "Galaxy Query",
    "description": "Query galaxy data",
    "executor_type": "globus_flows",
    "category": "cosmology",
    "disabled_at": None,
    "created_at": "2026-01-01T00:00:00Z",
    "updated_at": None,
    "run_count": 10,
}

SAMPLE_TASK_DISABLED = {
    **SAMPLE_TASK,
    "id": 2,
    "slug": "halo-query",
    "name": "Halo Query",
    "disabled_at": "2026-02-15T00:00:00Z",
    "run_count": 3,
}

SAMPLE_AUDIT = {
    "id": "log-001",
    "user_id": "user-001-abc-def",
    "user_email": "alice@example.com",
    "client_id": None,
    "method": "GET",
    "path": "/api/v1/tasks",
    "status_code": 200,
    "ip_address": None,
    "user_agent": None,
    "created_at": "2026-03-10T12:00:00Z",
}

SAMPLE_RUN_STATS = {
    "total_runs": 100,
    "active_runs": 3,
    "by_status": [
        {"status": "succeeded", "count": 80},
        {"status": "failed", "count": 15},
    ],
    "by_task": [
        {"task_slug": "galaxy-query", "task_name": "Galaxy Query", "count": 60},
    ],
    "by_client_type": [
        {"client_type": "web", "count": 70},
        {"client_type": "python", "count": 30},
    ],
    "avg_duration_by_task": [
        {"task_slug": "galaxy-query", "task_name": "Galaxy Query", "avg_seconds": 120.5},
    ],
}

SAMPLE_SYSTEM_STATS = {
    "total_users": 42,
    "active_users_24h": 5,
    "active_users_7d": 18,
    "total_tasks": 12,
    "enabled_tasks": 10,
    "disabled_tasks": 2,
    "daily_runs": [
        {"date": "2026-03-10", "count": 8},
        {"date": "2026-03-11", "count": 12},
    ],
    "run_summary": SAMPLE_RUN_STATS,
}


# ==================== Tests: admin runs list ====================


class TestAdminRunsList:
    """Tests for 'ocp admin runs list' command."""

    @patch("ocp.admin.commands.APIClient")
    def test_table_output(self, mock_cls: MagicMock) -> None:
        """Displays runs in table format."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(
            json_data={"runs": [SAMPLE_RUN, SAMPLE_RUN_2], "total": 2}
        )

        result = _run(["admin", "runs", "list"])

        assert result.exit_code == 0
        assert "RUN ID" in result.output
        assert "galaxy-query" in result.output
        assert "alice@example.com" in result.output
        assert "Total: 2 runs" in result.output

    @patch("ocp.admin.commands.APIClient")
    def test_json_output(self, mock_cls: MagicMock) -> None:
        """Outputs runs as JSON."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data={"runs": [SAMPLE_RUN], "total": 1})

        result = _run(["--format", "json", "admin", "runs", "list"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 1
        assert data[0]["run_id"] == "run-abc-123-def-456"

    @patch("ocp.admin.commands.APIClient")
    def test_empty(self, mock_cls: MagicMock) -> None:
        """Shows message when no runs found."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data={"runs": [], "total": 0})

        result = _run(["admin", "runs", "list"])

        assert result.exit_code == 0
        assert "No runs found." in result.output

    @patch("ocp.admin.commands.APIClient")
    def test_filters_passed(self, mock_cls: MagicMock) -> None:
        """Filters are passed as query params."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data={"runs": [], "total": 0})

        _run(
            [
                "admin",
                "runs",
                "list",
                "--status",
                "failed",
                "--user-id",
                "user-001",
                "--task-slug",
                "galaxy-query",
                "--client-type",
                "web",
                "--include-archived",
            ]
        )

        call_kwargs = mock_client.get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["status"] == "failed"
        assert params["user_id"] == "user-001"
        assert params["task_slug"] == "galaxy-query"
        assert params["client_type"] == "web"
        assert params["include_archived"] == "true"

    @patch("ocp.admin.commands.APIClient")
    def test_permission_denied(self, mock_cls: MagicMock) -> None:
        """403 response results in error."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(
            status_code=403, json_data={"detail": "Forbidden"}
        )

        result = _run(["admin", "runs", "list"])

        assert result.exit_code != 0
        assert "admin" in result.output.lower() or "monitor" in result.output.lower()


# ==================== Tests: admin runs stats ====================


class TestAdminRunsStats:
    """Tests for 'ocp admin runs stats' command."""

    @patch("ocp.admin.commands.APIClient")
    def test_output(self, mock_cls: MagicMock) -> None:
        """Displays run statistics."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data=SAMPLE_RUN_STATS)

        result = _run(["admin", "runs", "stats"])

        assert result.exit_code == 0
        assert "Run Statistics" in result.output
        assert "Total runs:" in result.output
        assert "100" in result.output
        assert "By status:" in result.output
        assert "galaxy-query" in result.output

    @patch("ocp.admin.commands.APIClient")
    def test_json_output(self, mock_cls: MagicMock) -> None:
        """Outputs stats as JSON."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data=SAMPLE_RUN_STATS)

        result = _run(["--format", "json", "admin", "runs", "stats"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["total_runs"] == 100


# ==================== Tests: admin users list ====================


class TestAdminUsersList:
    """Tests for 'ocp admin users list' command."""

    @patch("ocp.admin.commands.APIClient")
    def test_table_output(self, mock_cls: MagicMock) -> None:
        """Displays users in table format."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(
            json_data={"users": [SAMPLE_USER, SAMPLE_USER_2], "total": 2}
        )

        result = _run(["admin", "users", "list"])

        assert result.exit_code == 0
        assert "NAME" in result.output
        assert "EMAIL" in result.output
        assert "Alice" in result.output
        assert "bob@example.com" in result.output
        assert "Total: 2 users" in result.output

    @patch("ocp.admin.commands.APIClient")
    def test_search_param(self, mock_cls: MagicMock) -> None:
        """Search parameter is passed to API."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data={"users": [], "total": 0})

        _run(["admin", "users", "list", "--search", "alice"])

        call_kwargs = mock_client.get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["search"] == "alice"

    @patch("ocp.admin.commands.APIClient")
    def test_empty(self, mock_cls: MagicMock) -> None:
        """Shows message when no users found."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data={"users": [], "total": 0})

        result = _run(["admin", "users", "list"])

        assert result.exit_code == 0
        assert "No users found." in result.output


# ==================== Tests: admin users info ====================


class TestAdminUsersInfo:
    """Tests for 'ocp admin users info' command."""

    @patch("ocp.admin.commands.APIClient")
    def test_output(self, mock_cls: MagicMock) -> None:
        """Displays user detail."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data=SAMPLE_USER_DETAIL)

        result = _run(["admin", "users", "info", "user-001-abc-def"])

        assert result.exit_code == 0
        assert "User Detail" in result.output
        assert "alice@example.com" in result.output
        assert "Identities:" in result.output
        assert "globus" in result.output
        assert "Recent runs:" in result.output

    @patch("ocp.admin.commands.APIClient")
    def test_not_found(self, mock_cls: MagicMock) -> None:
        """404 response for unknown user."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(
            status_code=404, json_data={"detail": "Not found"}
        )

        result = _run(["admin", "users", "info", "nonexistent"])

        assert result.exit_code != 0

    @patch("ocp.admin.commands.APIClient")
    def test_json_output(self, mock_cls: MagicMock) -> None:
        """Outputs user detail as JSON."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data=SAMPLE_USER_DETAIL)

        result = _run(["--format", "json", "admin", "users", "info", "user-001-abc-def"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["email"] == "alice@example.com"
        assert len(data["identities"]) == 1


# ==================== Tests: admin tasks list ====================


class TestAdminTasksList:
    """Tests for 'ocp admin tasks list' command."""

    @patch("ocp.admin.commands.APIClient")
    def test_table_output(self, mock_cls: MagicMock) -> None:
        """Displays tasks in table format with enabled/disabled status."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(
            json_data={"tasks": [SAMPLE_TASK, SAMPLE_TASK_DISABLED], "total": 2}
        )

        result = _run(["admin", "tasks", "list"])

        assert result.exit_code == 0
        assert "SLUG" in result.output
        assert "galaxy-query" in result.output
        assert "halo-query" in result.output
        assert "enabled" in result.output
        assert "disabled" in result.output
        assert "Total: 2 tasks" in result.output

    @patch("ocp.admin.commands.APIClient")
    def test_enabled_only_flag(self, mock_cls: MagicMock) -> None:
        """--enabled-only passes include_disabled=false."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data={"tasks": [], "total": 0})

        _run(["admin", "tasks", "list", "--enabled-only"])

        call_kwargs = mock_client.get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["include_disabled"] == "false"


# ==================== Tests: admin tasks enable ====================


class TestAdminTasksEnable:
    """Tests for 'ocp admin tasks enable' command."""

    @patch("ocp.admin.commands.APIClient")
    def test_enable(self, mock_cls: MagicMock) -> None:
        """Enables a task."""
        mock_client = _setup_client(mock_cls)
        mock_client.patch.return_value = _mock_response(
            json_data={"slug": "galaxy-query", "disabled": False, "disabled_at": None}
        )

        result = _run(["admin", "tasks", "enable", "galaxy-query"])

        assert result.exit_code == 0
        assert "enabled" in result.output
        mock_client.patch.assert_called_once()


# ==================== Tests: admin tasks disable ====================


class TestAdminTasksDisable:
    """Tests for 'ocp admin tasks disable' command."""

    @patch("ocp.admin.commands.APIClient")
    def test_disable_with_confirmation(self, mock_cls: MagicMock) -> None:
        """Disables a task after confirmation."""
        mock_client = _setup_client(mock_cls)
        mock_client.patch.return_value = _mock_response(
            json_data={
                "slug": "galaxy-query",
                "disabled": True,
                "disabled_at": "2026-03-12T00:00:00Z",
            }
        )

        result = _run(["admin", "tasks", "disable", "galaxy-query"], input="y\n")

        assert result.exit_code == 0
        assert "disabled" in result.output
        mock_client.patch.assert_called_once()

    @patch("ocp.admin.commands.APIClient")
    def test_disable_skip_confirm(self, mock_cls: MagicMock) -> None:
        """--yes flag skips confirmation."""
        mock_client = _setup_client(mock_cls)
        mock_client.patch.return_value = _mock_response(
            json_data={
                "slug": "galaxy-query",
                "disabled": True,
                "disabled_at": "2026-03-12T00:00:00Z",
            }
        )

        result = _run(["admin", "tasks", "disable", "--yes", "galaxy-query"])

        assert result.exit_code == 0
        assert "disabled" in result.output
        mock_client.patch.assert_called_once()

    @patch("ocp.admin.commands.APIClient")
    def test_disable_abort(self, mock_cls: MagicMock) -> None:
        """Aborting confirmation does not call API."""
        mock_client = _setup_client(mock_cls)

        result = _run(["admin", "tasks", "disable", "galaxy-query"], input="n\n")

        assert result.exit_code == 0
        assert "Cancelled" in result.output
        mock_client.patch.assert_not_called()


# ==================== Tests: admin audit-logs list ====================


class TestAdminAuditLogsList:
    """Tests for 'ocp admin audit-logs list' command."""

    @patch("ocp.admin.commands.APIClient")
    def test_table_output(self, mock_cls: MagicMock) -> None:
        """Displays audit logs in table format."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(
            json_data={"entries": [SAMPLE_AUDIT], "total": 1}
        )

        result = _run(["admin", "audit-logs", "list"])

        assert result.exit_code == 0
        assert "METHOD" in result.output
        assert "PATH" in result.output
        assert "alice@example.com" in result.output
        assert "/api/v1/tasks" in result.output
        assert "Total: 1 entries" in result.output

    @patch("ocp.admin.commands.APIClient")
    def test_filters(self, mock_cls: MagicMock) -> None:
        """Filters are passed as query params."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data={"entries": [], "total": 0})

        _run(
            [
                "admin",
                "audit-logs",
                "list",
                "--method",
                "POST",
                "--path-prefix",
                "/api/v1/tasks",
                "--status-code",
                "200",
            ]
        )

        call_kwargs = mock_client.get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["method"] == "POST"
        assert params["path_prefix"] == "/api/v1/tasks"
        assert params["status_code"] == 200

    @patch("ocp.admin.commands.APIClient")
    def test_empty(self, mock_cls: MagicMock) -> None:
        """Shows message when no entries found."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data={"entries": [], "total": 0})

        result = _run(["admin", "audit-logs", "list"])

        assert result.exit_code == 0
        assert "No audit log entries found." in result.output


# ==================== Tests: admin stats ====================


class TestAdminStats:
    """Tests for 'ocp admin stats' command."""

    @patch("ocp.admin.commands.APIClient")
    def test_output(self, mock_cls: MagicMock) -> None:
        """Displays system statistics."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data=SAMPLE_SYSTEM_STATS)

        result = _run(["admin", "stats"])

        assert result.exit_code == 0
        assert "System Stats" in result.output
        assert "Total users:" in result.output
        assert "42" in result.output
        assert "10 enabled, 2 disabled" in result.output
        assert "Run Summary" in result.output
        assert "Daily runs" in result.output

    @patch("ocp.admin.commands.APIClient")
    def test_days_option(self, mock_cls: MagicMock) -> None:
        """--days option is passed as param."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data=SAMPLE_SYSTEM_STATS)

        _run(["admin", "stats", "--days", "7"])

        call_kwargs = mock_client.get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["days"] == 7

    @patch("ocp.admin.commands.APIClient")
    def test_json_output(self, mock_cls: MagicMock) -> None:
        """Outputs stats as JSON."""
        mock_client = _setup_client(mock_cls)
        mock_client.get.return_value = _mock_response(json_data=SAMPLE_SYSTEM_STATS)

        result = _run(["--format", "json", "admin", "stats"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["total_users"] == 42
        assert data["run_summary"]["total_runs"] == 100
