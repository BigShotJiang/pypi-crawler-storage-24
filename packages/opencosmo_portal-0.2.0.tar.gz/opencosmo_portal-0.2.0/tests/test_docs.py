"""Tests for documentation CLI commands."""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner, Result

from ocp.main import cli

# ==================== Helpers ====================


def _mock_response(status_code: int = 200, json_data: object = None) -> MagicMock:
    """Create a mock httpx response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data
    resp.text = str(json_data)
    return resp


def _run(args: list[str], obj: dict[str, str] | None = None) -> Result:
    """Invoke the CLI with the given args."""
    runner = CliRunner()
    return runner.invoke(cli, args, obj=obj or {}, catch_exceptions=False)


# ==================== List Docs Tests ====================


class TestListDocs:
    """Tests for 'ocp docs list' command."""

    @patch("ocp.docs.commands.APIClient")
    def test_table_output(self, mock_client_cls: MagicMock) -> None:
        """List command displays nested TOC as a flattened table."""
        toc = [
            {
                "label": "Welcome",
                "url": "/documentation",
                "children": [
                    {"title": "Glossary", "url": "/documentation/glossary"},
                ],
            },
            {
                "label": "User Guide",
                "url": "/documentation/user-guide",
                "children": [
                    {"title": "Tasks", "url": "/documentation/user-guide/tasks"},
                ],
            },
        ]
        mock_client = MagicMock()
        mock_client.get.return_value = _mock_response(json_data=toc)
        mock_client_cls.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_client_cls.return_value.__exit__ = MagicMock(return_value=False)

        result = _run(["docs", "list"])

        assert result.exit_code == 0
        assert "CATEGORY" in result.output
        assert "TITLE" in result.output
        assert "Welcome" in result.output
        assert "Glossary" in result.output
        assert "User Guide" in result.output
        assert "Tasks" in result.output
        mock_client.get.assert_called_once_with("/api/v1/content/documentation")

    @patch("ocp.docs.commands.APIClient")
    def test_json_output(self, mock_client_cls: MagicMock) -> None:
        """List command outputs JSON when --format json is used."""
        toc = [{"label": "Welcome", "url": "/documentation", "children": []}]
        mock_client = MagicMock()
        mock_client.get.return_value = _mock_response(json_data=toc)
        mock_client_cls.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_client_cls.return_value.__exit__ = MagicMock(return_value=False)

        result = _run(["--format", "json", "docs", "list"])

        assert result.exit_code == 0
        assert '"label"' in result.output
        assert '"Welcome"' in result.output

    @patch("ocp.docs.commands.APIClient")
    def test_empty_list(self, mock_client_cls: MagicMock) -> None:
        """List command shows message when no docs available."""
        mock_client = MagicMock()
        mock_client.get.return_value = _mock_response(json_data=[])
        mock_client_cls.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_client_cls.return_value.__exit__ = MagicMock(return_value=False)

        result = _run(["docs", "list"])

        assert result.exit_code == 0
        assert "No documentation available" in result.output


# ==================== Show Doc Tests ====================


class TestShowDoc:
    """Tests for 'ocp docs show' command."""

    @patch("ocp.docs.commands.APIClient")
    def test_text_output(self, mock_client_cls: MagicMock) -> None:
        """Show command displays title and content."""
        doc = {
            "slug": "user-guide/tasks",
            "title": "Submitting Tasks",
            "content": "# How to submit tasks\n\nFollow these steps...",
        }
        mock_client = MagicMock()
        mock_client.get.return_value = _mock_response(json_data=doc)
        mock_client_cls.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_client_cls.return_value.__exit__ = MagicMock(return_value=False)

        result = _run(["docs", "show", "user-guide/tasks"])

        assert result.exit_code == 0
        assert "Submitting Tasks" in result.output
        assert "How to submit tasks" in result.output
        mock_client.get.assert_called_once_with("/api/v1/content/documentation/user-guide/tasks")

    @patch("ocp.docs.commands.APIClient")
    def test_json_output(self, mock_client_cls: MagicMock) -> None:
        """Show command outputs JSON when --format json is used."""
        doc = {
            "slug": "index",
            "title": "Welcome",
            "content": "# Welcome",
        }
        mock_client = MagicMock()
        mock_client.get.return_value = _mock_response(json_data=doc)
        mock_client_cls.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_client_cls.return_value.__exit__ = MagicMock(return_value=False)

        result = _run(["--format", "json", "docs", "show", "index"])

        assert result.exit_code == 0
        assert '"title"' in result.output
        assert '"Welcome"' in result.output

    @patch("ocp.docs.commands.APIClient")
    def test_not_found(self, mock_client_cls: MagicMock) -> None:
        """Show command raises error for 404 response."""
        mock_client = MagicMock()
        mock_client.get.return_value = _mock_response(
            status_code=404, json_data={"detail": "Not found"}
        )
        mock_client_cls.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_client_cls.return_value.__exit__ = MagicMock(return_value=False)

        result = _run(["docs", "show", "nonexistent"])

        assert result.exit_code != 0
