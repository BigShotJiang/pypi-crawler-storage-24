"""Tests for CLI logging configuration."""

import logging
import sys
from unittest.mock import patch

from click.testing import CliRunner

from ocp.main import cli
from ocp.utils.logging import get_logger, setup_logging


def test_setup_logging_default_level() -> None:
    """Default logging level should be WARNING."""
    setup_logging()
    ocp_logger = logging.getLogger("ocp")
    assert ocp_logger.level == logging.WARNING


def test_setup_logging_verbose() -> None:
    """Verbose flag should set INFO level."""
    setup_logging(verbose=True)
    ocp_logger = logging.getLogger("ocp")
    assert ocp_logger.level == logging.INFO


def test_setup_logging_debug() -> None:
    """Debug flag should set DEBUG level."""
    setup_logging(debug=True)
    ocp_logger = logging.getLogger("ocp")
    assert ocp_logger.level == logging.DEBUG


def test_setup_logging_outputs_to_stderr() -> None:
    """Logging handlers should write to stderr, not stdout."""
    setup_logging(verbose=True)
    ocp_logger = logging.getLogger("ocp")
    assert len(ocp_logger.handlers) == 1
    handler = ocp_logger.handlers[0]
    assert isinstance(handler, logging.StreamHandler)
    assert handler.stream is sys.stderr


def test_get_logger_prefixes_ocp() -> None:
    """get_logger should ensure ocp. prefix."""
    logger = get_logger("mymodule")
    assert logger.name == "ocp.mymodule"


def test_get_logger_preserves_existing_prefix() -> None:
    """get_logger should not double-prefix names already under ocp."""
    logger = get_logger("ocp.auth")
    assert logger.name == "ocp.auth"


def test_get_logger_does_not_match_ocp_like_names() -> None:
    """get_logger should prefix names that merely start with 'ocp' but are not in the namespace."""
    logger = get_logger("ocpython")
    assert logger.name == "ocp.ocpython"


def test_setup_logging_disables_propagation() -> None:
    """Propagation should be disabled to prevent duplicate log output."""
    setup_logging()
    ocp_logger = logging.getLogger("ocp")
    assert ocp_logger.propagate is False


def test_setup_logging_clears_previous_handlers() -> None:
    """Calling setup_logging multiple times should not accumulate handlers."""
    setup_logging(verbose=True)
    setup_logging(debug=True)
    ocp_logger = logging.getLogger("ocp")
    assert len(ocp_logger.handlers) == 1


# ==================== CLI flag integration tests ====================


@patch("ocp.main.setup_logging")
def test_cli_verbose_flag_calls_setup_logging(mock_setup) -> None:
    """--verbose flag should pass verbose=True to setup_logging."""
    runner = CliRunner()
    # A subcommand is required for Click to invoke the group callback.
    # "config" is a safe subgroup that doesn't perform I/O.
    runner.invoke(cli, ["--verbose", "config"])
    mock_setup.assert_called_once_with(debug=False, verbose=True)


@patch("ocp.main.setup_logging")
def test_cli_debug_flag_calls_setup_logging(mock_setup) -> None:
    """--debug flag should pass debug=True to setup_logging."""
    runner = CliRunner()
    runner.invoke(cli, ["--debug", "config"])
    mock_setup.assert_called_once_with(debug=True, verbose=False)
