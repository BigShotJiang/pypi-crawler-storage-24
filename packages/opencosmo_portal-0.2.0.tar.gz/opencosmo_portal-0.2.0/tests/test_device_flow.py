"""Tests for device code authentication flow."""

from unittest.mock import MagicMock, patch

import pytest

from ocp.auth.device import DeviceCodeFlow, DeviceCodeResponse

# ==================== Request Device Code Tests ====================


class TestRequestDeviceCode:
    """Tests for DeviceCodeFlow.request_device_code()."""

    @patch("ocp.auth.device.get_api_url", return_value="http://localhost:8000")
    @patch("ocp.auth.device.httpx.post")
    def test_success(self, mock_post: MagicMock, mock_url: MagicMock) -> None:
        """Successful device code request returns DeviceCodeResponse."""
        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: {
                "device_code": "dev123",
                "user_code": "ABCD-EFGH",
                "verification_uri": "http://localhost:3000/auth/verify",
                "verification_uri_complete": "http://localhost:3000/auth/verify?user_code=ABCD-EFGH",
                "expires_in": 900,
                "interval": 5,
            },
        )
        flow = DeviceCodeFlow(profile="default")
        result = flow.request_device_code()

        assert result.device_code == "dev123"
        assert result.user_code == "ABCD-EFGH"
        assert result.interval == 5
        assert result.expires_in == 900

    @patch("ocp.auth.device.get_api_url", return_value="http://localhost:8000")
    @patch("ocp.auth.device.httpx.post")
    def test_403_device_auth_disabled(self, mock_post: MagicMock, mock_url: MagicMock) -> None:
        """403 response raises ValueError about disabled device auth."""
        mock_post.return_value = MagicMock(status_code=403, text="Forbidden")
        flow = DeviceCodeFlow(profile="default")

        with pytest.raises(ValueError, match="not enabled"):
            flow.request_device_code()

    @patch("ocp.auth.device.get_api_url", return_value="http://localhost:8000")
    @patch("ocp.auth.device.httpx.post")
    def test_error_response(self, mock_post: MagicMock, mock_url: MagicMock) -> None:
        """Non-200/403 response raises ValueError with detail."""
        mock_post.return_value = MagicMock(
            status_code=400,
            json=lambda: {"detail": "Invalid client"},
            text="Invalid client",
        )
        flow = DeviceCodeFlow(profile="default")

        with pytest.raises(ValueError, match="Invalid client"):
            flow.request_device_code()


# ==================== Poll For Token Tests ====================


class TestPollForToken:
    """Tests for DeviceCodeFlow.poll_for_token()."""

    def _make_device_response(self, **kwargs: object) -> DeviceCodeResponse:
        """Create a DeviceCodeResponse with defaults."""
        defaults = {
            "device_code": "dev123",
            "user_code": "ABCD-EFGH",
            "verification_uri": "http://localhost:3000/auth/verify",
            "verification_uri_complete": "http://localhost:3000/auth/verify?user_code=ABCD-EFGH",
            "expires_in": 900,
            "interval": 1,
        }
        defaults.update(kwargs)
        return DeviceCodeResponse(**defaults)  # type: ignore[arg-type]

    @patch("ocp.auth.device.get_api_url", return_value="http://localhost:8000")
    @patch("ocp.auth.device.time.sleep")
    @patch("ocp.auth.device.httpx.post")
    def test_immediate_success(
        self, mock_post: MagicMock, mock_sleep: MagicMock, mock_url: MagicMock
    ) -> None:
        """Token returned on first poll."""
        mock_post.return_value = MagicMock(
            status_code=200,
            json=lambda: {
                "access_token": "tok123",
                "token_type": "Bearer",
                "expires_in": 3600,
                "refresh_token": "ref456",
            },
        )
        flow = DeviceCodeFlow(profile="default")
        result = flow.poll_for_token(self._make_device_response())

        assert result["access_token"] == "tok123"
        assert result["refresh_token"] == "ref456"

    @patch("ocp.auth.device.get_api_url", return_value="http://localhost:8000")
    @patch("ocp.auth.device.time.sleep")
    @patch("ocp.auth.device.httpx.post")
    def test_pending_then_success(
        self, mock_post: MagicMock, mock_sleep: MagicMock, mock_url: MagicMock
    ) -> None:
        """Polls through authorization_pending then succeeds."""
        pending = MagicMock(
            status_code=400,
            json=lambda: {
                "detail": {
                    "error": "authorization_pending",
                    "error_description": "Authorization pending",
                }
            },
        )
        success = MagicMock(
            status_code=200,
            json=lambda: {"access_token": "tok", "expires_in": 3600},
        )
        mock_post.side_effect = [pending, pending, success]

        flow = DeviceCodeFlow(profile="default")
        result = flow.poll_for_token(self._make_device_response())

        assert result["access_token"] == "tok"
        assert mock_sleep.call_count == 3

    @patch("ocp.auth.device.get_api_url", return_value="http://localhost:8000")
    @patch("ocp.auth.device.time.sleep")
    @patch("ocp.auth.device.httpx.post")
    def test_expired_token(
        self, mock_post: MagicMock, mock_sleep: MagicMock, mock_url: MagicMock
    ) -> None:
        """expired_token error raises ValueError."""
        mock_post.return_value = MagicMock(
            status_code=400,
            json=lambda: {
                "detail": {
                    "error": "expired_token",
                    "error_description": "Device code has expired",
                }
            },
        )
        flow = DeviceCodeFlow(profile="default")

        with pytest.raises(ValueError, match="expired"):
            flow.poll_for_token(self._make_device_response())

    @patch("ocp.auth.device.get_api_url", return_value="http://localhost:8000")
    @patch("ocp.auth.device.time.sleep")
    @patch("ocp.auth.device.httpx.post")
    def test_slow_down_increases_interval(
        self, mock_post: MagicMock, mock_sleep: MagicMock, mock_url: MagicMock
    ) -> None:
        """slow_down error increases polling interval by 5 seconds."""
        slow = MagicMock(
            status_code=400,
            json=lambda: {
                "detail": {
                    "error": "slow_down",
                    "error_description": "Slow down",
                }
            },
        )
        success = MagicMock(
            status_code=200,
            json=lambda: {"access_token": "tok", "expires_in": 3600},
        )
        mock_post.side_effect = [slow, success]

        flow = DeviceCodeFlow(profile="default")
        flow.poll_for_token(self._make_device_response(interval=5))

        # First sleep: original interval (5), second sleep: increased (10)
        assert mock_sleep.call_args_list[0][0][0] == 5
        assert mock_sleep.call_args_list[1][0][0] == 10

    @patch("ocp.auth.device.get_api_url", return_value="http://localhost:8000")
    @patch("ocp.auth.device.click.prompt", return_value="ABC-DEF")
    @patch("ocp.auth.device.time.sleep")
    @patch("ocp.auth.device.httpx.post")
    def test_confirmation_pending_then_success(
        self,
        mock_post: MagicMock,
        mock_sleep: MagicMock,
        mock_prompt: MagicMock,
        mock_url: MagicMock,
    ) -> None:
        """authorization_pending with confirmation_pending prompts user and re-polls."""
        confirmation_pending = MagicMock(
            status_code=400,
            json=lambda: {
                "detail": {
                    "error": "authorization_pending",
                    "error_description": "Confirmation code required",
                    "confirmation_pending": True,
                }
            },
        )
        success = MagicMock(
            status_code=200,
            json=lambda: {"access_token": "tok", "expires_in": 3600},
        )
        mock_post.side_effect = [confirmation_pending, success]

        flow = DeviceCodeFlow(profile="default")
        result = flow.poll_for_token(self._make_device_response())

        assert result["access_token"] == "tok"
        mock_prompt.assert_called_once()

        # Second call should include confirmation_code in request body
        second_call_kwargs = mock_post.call_args_list[1]
        body = (
            second_call_kwargs[1]["json"]
            if "json" in second_call_kwargs[1]
            else second_call_kwargs.kwargs["json"]
        )
        assert body["confirmation_code"] == "ABC-DEF"

    @patch("ocp.auth.device.get_api_url", return_value="http://localhost:8000")
    @patch("ocp.auth.device.click.prompt", side_effect=["WRONG", "RIGHT"])
    @patch("ocp.auth.device.click.echo")
    @patch("ocp.auth.device.time.sleep")
    @patch("ocp.auth.device.httpx.post")
    def test_confirmation_invalid_then_retry(
        self,
        mock_post: MagicMock,
        mock_sleep: MagicMock,
        mock_echo: MagicMock,
        mock_prompt: MagicMock,
        mock_url: MagicMock,
    ) -> None:
        """Invalid confirmation code retries with remaining attempts."""
        confirmation_pending = MagicMock(
            status_code=400,
            json=lambda: {
                "detail": {
                    "error": "authorization_pending",
                    "error_description": "Confirmation code required",
                    "confirmation_pending": True,
                }
            },
        )
        access_denied = MagicMock(
            status_code=400,
            json=lambda: {
                "detail": {
                    "error": "access_denied",
                    "error_description": "Invalid confirmation code",
                }
            },
        )
        success = MagicMock(
            status_code=200,
            json=lambda: {"access_token": "tok", "expires_in": 3600},
        )
        mock_post.side_effect = [confirmation_pending, access_denied, success]

        flow = DeviceCodeFlow(profile="default")
        result = flow.poll_for_token(self._make_device_response())

        assert result["access_token"] == "tok"
        assert mock_prompt.call_count == 2

    @patch("ocp.auth.device.get_api_url", return_value="http://localhost:8000")
    @patch("ocp.auth.device.click.prompt", side_effect=["BAD", "BAD", "BAD"])
    @patch("ocp.auth.device.click.echo")
    @patch("ocp.auth.device.time.sleep")
    @patch("ocp.auth.device.httpx.post")
    def test_confirmation_all_attempts_fail(
        self,
        mock_post: MagicMock,
        mock_sleep: MagicMock,
        mock_echo: MagicMock,
        mock_prompt: MagicMock,
        mock_url: MagicMock,
    ) -> None:
        """All confirmation attempts failing raises ValueError."""
        confirmation_pending = MagicMock(
            status_code=400,
            json=lambda: {
                "detail": {
                    "error": "authorization_pending",
                    "error_description": "Confirmation code required",
                    "confirmation_pending": True,
                }
            },
        )
        access_denied = MagicMock(
            status_code=400,
            json=lambda: {
                "detail": {
                    "error": "access_denied",
                    "error_description": "Invalid confirmation code",
                }
            },
        )
        mock_post.side_effect = [confirmation_pending, access_denied, access_denied, access_denied]

        flow = DeviceCodeFlow(profile="default")

        with pytest.raises(ValueError, match="Invalid confirmation code"):
            flow.poll_for_token(self._make_device_response())
