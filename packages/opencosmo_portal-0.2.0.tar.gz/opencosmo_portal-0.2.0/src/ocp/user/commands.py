"""User commands for the OpenCosmo CLI."""

import click

from ocp.api import UserService
from ocp.utils.api import APIClient
from ocp.utils.output import format_datetime, output


@click.command()
@click.pass_context
def whoami(ctx: click.Context) -> None:
    """Show authenticated user information.

    Displays your user profile including permissions, groups, and linked identities.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = UserService(client)
        user = service.whoami()

        if ctx.obj.get("format") == "json":
            output(ctx, user.model_dump(mode="json"))
        else:
            click.echo(f"User ID: {user.id}")
            click.echo(f"Name: {user.name or '(not set)'}")
            click.echo(f"Email: {user.email or '(not set)'}")
            click.echo()

            if user.permissions:
                click.echo("Permissions:")
                for perm in user.permissions:
                    click.echo(f"  - {perm}")
            else:
                click.echo("Permissions: none")

            click.echo()

            if user.groups:
                click.echo(f"Groups: {len(user.groups)}")
            else:
                click.echo("Groups: none")

            click.echo()
            click.echo(f"Created: {format_datetime(user.created_at)}")
            if user.last_login_at:
                click.echo(f"Last login: {format_datetime(user.last_login_at)}")

            if user.identities:
                click.echo()
                click.echo("Linked identities:")
                for identity in user.identities:
                    email = identity.email or "(no email)"
                    click.echo(f"  - {identity.provider}: {email}")
