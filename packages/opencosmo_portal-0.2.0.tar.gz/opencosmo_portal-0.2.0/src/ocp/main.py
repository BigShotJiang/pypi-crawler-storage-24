"""OpenCosmo Portal CLI entry point."""

import click

from ocp import __version__
from ocp.auth.commands import auth
from ocp.config.commands import config
from ocp.config.store import get_current_profile
from ocp.utils.logging import setup_logging


@click.group()
@click.option(
    "--profile",
    "-p",
    default=None,
    help="Configuration profile to use",
)
@click.option(
    "--format",
    "-f",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format (default: table)",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Enable verbose logging (INFO level)",
)
@click.option(
    "--debug",
    is_flag=True,
    help="Enable debug logging (DEBUG level)",
)
@click.version_option(version=__version__, prog_name="ocp")
@click.pass_context
def cli(
    ctx: click.Context,
    profile: str | None,
    output_format: str,
    verbose: bool,
    debug: bool,
) -> None:
    """OpenCosmo Portal CLI - Access cosmological simulation data.

    Authenticate with OpenCosmo, browse tasks, and manage runs from the
    command line.

    Use --profile to switch between different environments (dev, prod, etc.).

    Examples:

        ocp auth login

        ocp task list

        ocp run status abc123
    """
    ctx.ensure_object(dict)
    ctx.obj["profile"] = profile or get_current_profile()
    ctx.obj["format"] = output_format

    setup_logging(debug=debug, verbose=verbose)


# Register command groups
cli.add_command(auth)
cli.add_command(config)


# Import and register other commands (will be added incrementally)
try:
    from ocp.user.commands import whoami

    cli.add_command(whoami)
except ImportError:
    pass

try:
    from ocp.task.commands import task

    cli.add_command(task)
except ImportError:
    pass

try:
    from ocp.run.commands import run

    cli.add_command(run)
except ImportError:
    pass

try:
    from ocp.docs.commands import docs

    cli.add_command(docs)
except ImportError:
    pass

try:
    from ocp.mcp.commands import mcp

    cli.add_command(mcp)
except ImportError:
    pass

try:
    from ocp.admin.commands import admin

    cli.add_command(admin)
except ImportError:
    pass


def main() -> None:
    """CLI entry point."""
    cli()


if __name__ == "__main__":
    main()
