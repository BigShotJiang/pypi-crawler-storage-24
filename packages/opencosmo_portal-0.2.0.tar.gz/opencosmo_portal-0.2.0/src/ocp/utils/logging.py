"""CLI logging configuration."""

import logging
import sys


def setup_logging(*, debug: bool = False, verbose: bool = False) -> None:
    """Configure CLI logging to stderr.

    Configures the ``ocp`` namespace logger. Output goes to stderr so
    it never mixes with CLI output on stdout.

    Args:
        debug: Enable DEBUG level with detailed format.
        verbose: Enable INFO level with compact format.
    """
    if debug:
        level = logging.DEBUG
        fmt = "%(asctime)s %(name)s %(levelname)s %(message)s"
    elif verbose:
        level = logging.INFO
        fmt = "%(name)s: %(message)s"
    else:
        level = logging.WARNING
        fmt = "%(name)s: %(message)s"

    ocp_logger = logging.getLogger("ocp")
    ocp_logger.handlers.clear()

    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter(fmt))
    ocp_logger.addHandler(handler)
    ocp_logger.setLevel(level)
    ocp_logger.propagate = False

    # Quiet httpx unless debugging
    if not debug:
        logging.getLogger("httpx").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """Get a logger in the ocp namespace.

    Args:
        name: Module name (typically ``__name__``).

    Returns:
        Logger instance under the ``ocp`` hierarchy.
    """
    if not (name == "ocp" or name.startswith("ocp.")):
        name = f"ocp.{name}"
    return logging.getLogger(name)
