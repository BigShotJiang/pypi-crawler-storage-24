"""Local stdio MCP server that proxies to the remote OpenCosmo API."""

import json
import logging
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import httpx
import mcp.types as mcp_types
from mcp.server.lowlevel.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server

from ocp import __version__
from ocp.api import AsyncRunService, AsyncTaskService, TaskResponse
from ocp.mcp.api_client import AsyncAPIClient

logger = logging.getLogger(__name__)


# ==================== Tool Schemas ====================

_LIST_TASKS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {},
}

_GET_RUN_STATUS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string", "description": "Run UUID"},
    },
    "required": ["run_id"],
}

_LIST_RUNS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "limit": {
            "type": "integer",
            "description": "Maximum number of runs to return (1-100)",
            "default": 20,
            "minimum": 1,
            "maximum": 100,
        },
        "status": {
            "type": "string",
            "description": ("Filter by status (pending, running, succeeded, failed, cancelled)"),
        },
    },
}

_CANCEL_RUN_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string", "description": "Run UUID"},
    },
    "required": ["run_id"],
}

_GET_RUN_RESULTS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string", "description": "Run UUID"},
    },
    "required": ["run_id"],
}

_GET_RUN_LOGS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string", "description": "Run UUID"},
    },
    "required": ["run_id"],
}

_GET_DOC_LIST_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {},
}

_GET_DOC_PAGE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "slug": {
            "type": "string",
            "description": "Documentation page slug (e.g. 'user-guide/submitting-tasks')",
        },
    },
    "required": ["slug"],
}


# ==================== Server Setup ====================


def _create_server(profile: str) -> Server:
    """Create and configure the MCP server with tool handlers.

    Args:
        profile: CLI profile name for authentication.

    Returns:
        Configured MCP Server instance.
    """
    # Closure-scoped state shared between lifespan and handlers
    task_cache: list[TaskResponse] = []
    client_ref: list[AsyncAPIClient | None] = [None]
    task_service_ref: list[AsyncTaskService | None] = [None]
    run_service_ref: list[AsyncRunService | None] = [None]

    @asynccontextmanager
    async def server_lifespan(server: Server) -> AsyncIterator[dict[str, Any]]:
        """Create async client on startup, fetch tasks, close on shutdown."""
        client = AsyncAPIClient(profile)
        client_ref[0] = client
        task_svc = AsyncTaskService(client)
        run_svc = AsyncRunService(client)
        task_service_ref[0] = task_svc
        run_service_ref[0] = run_svc

        try:
            result = await task_svc.list_tasks()
            task_cache.extend(result.tasks)
            logger.info("Loaded %d tasks", len(task_cache))
        except Exception:
            logger.exception("Failed to fetch tasks on startup")

        try:
            yield {}
        finally:
            await client.close()
            client_ref[0] = None
            task_service_ref[0] = None
            run_service_ref[0] = None

    server = Server(
        "opencosmo-local",
        version=__version__,
        instructions=(
            "OpenCosmo local MCP server. Provides tools to query cosmological "
            "simulation data, submit analysis tasks, and monitor task runs. "
            "Use list_tasks to discover available tasks, then use the "
            "corresponding run_<task> tool to submit."
        ),
        lifespan=server_lifespan,
    )

    def _get_client() -> AsyncAPIClient:
        """Get the shared async client from the lifespan closure."""
        client = client_ref[0]
        if client is None:
            raise RuntimeError("MCP server not initialized")
        return client

    def _get_task_service() -> AsyncTaskService:
        """Get the shared async task service."""
        svc = task_service_ref[0]
        if svc is None:
            raise RuntimeError("MCP server not initialized")
        return svc

    def _get_run_service() -> AsyncRunService:
        """Get the shared async run service."""
        svc = run_service_ref[0]
        if svc is None:
            raise RuntimeError("MCP server not initialized")
        return svc

    # ==================== list_tools ====================

    @server.list_tools()  # type: ignore[no-untyped-call, untyped-decorator]
    async def handle_list_tools() -> list[mcp_types.Tool]:
        """Return all available tools: static + dynamic per-task."""
        static_tools = [
            mcp_types.Tool(
                name="list_tasks",
                description="List all available tasks you can run.",
                inputSchema=_LIST_TASKS_SCHEMA,
            ),
            mcp_types.Tool(
                name="get_run_status",
                description=("Get the current status of a task run, including stage progress."),
                inputSchema=_GET_RUN_STATUS_SCHEMA,
            ),
            mcp_types.Tool(
                name="list_runs",
                description=("List your recent task runs with optional status filtering."),
                inputSchema=_LIST_RUNS_SCHEMA,
            ),
            mcp_types.Tool(
                name="cancel_run",
                description="Cancel an active task run.",
                inputSchema=_CANCEL_RUN_SCHEMA,
            ),
            mcp_types.Tool(
                name="get_run_results",
                description="Get result files for a completed task run.",
                inputSchema=_GET_RUN_RESULTS_SCHEMA,
            ),
            mcp_types.Tool(
                name="get_run_logs",
                description="Get execution logs for a task run.",
                inputSchema=_GET_RUN_LOGS_SCHEMA,
            ),
            mcp_types.Tool(
                name="get_documentation_list",
                description=("List documentation as a nested TOC with categories and page links."),
                inputSchema=_GET_DOC_LIST_SCHEMA,
            ),
            mcp_types.Tool(
                name="get_documentation_page",
                description="Get a documentation page by slug. Returns full markdown content.",
                inputSchema=_GET_DOC_PAGE_SCHEMA,
            ),
        ]

        dynamic_tools = [
            mcp_types.Tool(
                name=f"run_{task.slug.replace('-', '_')}",
                description=task.description or task.name,
                inputSchema=task.input_schema,
            )
            for task in task_cache
        ]

        return static_tools + dynamic_tools

    # ==================== call_tool ====================

    @server.call_tool()  # type: ignore[untyped-decorator]
    async def handle_call_tool(
        name: str, arguments: dict[str, Any] | None
    ) -> mcp_types.CallToolResult:
        """Dispatch tool calls to API handlers."""
        args = arguments or {}
        task_svc = _get_task_service()
        run_svc = _get_run_service()

        try:
            if name == "list_tasks":
                return await _handle_list_tasks(task_svc)
            elif name == "get_run_status":
                return await _handle_get_run_status(run_svc, args)
            elif name == "list_runs":
                return await _handle_list_runs(run_svc, args)
            elif name == "cancel_run":
                return await _handle_cancel_run(run_svc, args)
            elif name == "get_run_results":
                return await _handle_get_run_results(run_svc, args)
            elif name == "get_run_logs":
                return await _handle_get_run_logs(run_svc, args)
            elif name == "get_documentation_list":
                return await _handle_get_doc_list(_get_client())
            elif name == "get_documentation_page":
                return await _handle_get_doc_page(_get_client(), args)
            elif name.startswith("run_"):
                return await _handle_dynamic_submit(_get_client(), name, args)
            else:
                return _error_result(f"Unknown tool: {name}")
        except RuntimeError as e:
            return _error_result(str(e))
        except httpx.RequestError as e:
            logger.exception("Network error during tool call: %s", name)
            return _error_result(f"Network error: {e}")
        except Exception as e:
            logger.exception("Tool call failed: %s", name)
            return _error_result(f"Internal error: {e}")

    return server


# ==================== Tool Handlers ====================


async def _handle_list_tasks(
    task_svc: AsyncTaskService,
) -> mcp_types.CallToolResult:
    """Fetch and return the task list from the API."""
    result = await task_svc.list_tasks()
    return _json_result(result.model_dump(mode="json"))


async def _handle_dynamic_submit(
    client: AsyncAPIClient,
    tool_name: str,
    args: dict[str, Any],
) -> mcp_types.CallToolResult:
    """Submit a task via a dynamic run_{slug} tool."""
    slug = tool_name.removeprefix("run_").replace("_", "-")

    # Use raw client for submit to handle consent errors specially
    resp = await client.post(
        f"/api/v1/tasks/{slug}",
        json={"input_data": args},
    )
    if resp.status_code == 404:
        return _error_result(f"Task not found: {slug}")
    if resp.status_code == 403:
        return _error_result(f"Access denied to task: {slug}")
    if resp.status_code == 409:
        try:
            body = resp.json()
            detail = body.get("detail", {})
            if isinstance(detail, dict) and detail.get("error") == "consent_required":
                labels = ", ".join(
                    c.get("label", c.get("provider", "unknown"))
                    for c in detail.get("missing_consents", [])
                )
                return _error_result(
                    f"This task requires additional authorization for: {labels}. "
                    "Run `ocp auth consent` to grant access, then retry."
                )
        except Exception:
            pass
        return _error_result(f"Task submission failed: {_extract_error(resp)}")
    if resp.status_code >= 400:
        detail = _extract_error(resp)
        return _error_result(f"Task submission failed: {detail}")
    return _json_result(resp.json())


async def _handle_get_run_status(
    run_svc: AsyncRunService, args: dict[str, Any]
) -> mcp_types.CallToolResult:
    """Get run status from API."""
    run_id = args.get("run_id")
    if not run_id:
        return _error_result("run_id is required")
    result = await run_svc.get_run(run_id)
    return _json_result(result.model_dump(mode="json"))


async def _handle_list_runs(
    run_svc: AsyncRunService, args: dict[str, Any]
) -> mcp_types.CallToolResult:
    """List runs from API."""
    limit = args.get("limit", 20)
    status = args.get("status")
    result = await run_svc.list_runs(limit=limit, status=status)
    return _json_result(result.model_dump(mode="json"))


async def _handle_cancel_run(
    run_svc: AsyncRunService, args: dict[str, Any]
) -> mcp_types.CallToolResult:
    """Cancel a run via API."""
    run_id = args.get("run_id")
    if not run_id:
        return _error_result("run_id is required")
    result = await run_svc.cancel(run_id)
    return _json_result(result.model_dump(mode="json"))


async def _handle_get_run_results(
    run_svc: AsyncRunService, args: dict[str, Any]
) -> mcp_types.CallToolResult:
    """Get run results from API."""
    run_id = args.get("run_id")
    if not run_id:
        return _error_result("run_id is required")
    result = await run_svc.get_results(run_id)
    if result is None:
        return _json_result(None)
    return _json_result(result.model_dump(mode="json"))


async def _handle_get_run_logs(
    run_svc: AsyncRunService, args: dict[str, Any]
) -> mcp_types.CallToolResult:
    """Get run logs from API."""
    run_id = args.get("run_id")
    if not run_id:
        return _error_result("run_id is required")
    logs = await run_svc.get_logs(run_id)
    return _json_result(logs)


async def _handle_get_doc_list(
    client: AsyncAPIClient,
) -> mcp_types.CallToolResult:
    """List all documentation pages from API."""
    resp = await client.get("/api/v1/content/documentation")
    if resp.status_code >= 400:
        return _error_result(f"Failed to list documentation (HTTP {resp.status_code})")
    return _json_result(resp.json())


async def _handle_get_doc_page(
    client: AsyncAPIClient, args: dict[str, Any]
) -> mcp_types.CallToolResult:
    """Get a documentation page from API."""
    slug = args.get("slug")
    if not slug:
        return _error_result("slug is required")

    resp = await client.get(f"/api/v1/content/documentation/{slug}")
    if resp.status_code == 404:
        return _error_result(f"Documentation not found: {slug}")
    if resp.status_code >= 400:
        return _error_result(f"Failed to get documentation (HTTP {resp.status_code})")
    return _json_result(resp.json())


# ==================== Response Helpers ====================


def _json_result(data: Any) -> mcp_types.CallToolResult:
    """Wrap API response data as a successful MCP CallToolResult.

    Args:
        data: Serializable data.

    Returns:
        CallToolResult with JSON text content.
    """
    return mcp_types.CallToolResult(
        content=[
            mcp_types.TextContent(
                type="text",
                text=json.dumps(data, default=str),
            )
        ],
    )


def _error_result(message: str) -> mcp_types.CallToolResult:
    """Create an error MCP CallToolResult.

    Args:
        message: Error message.

    Returns:
        CallToolResult with isError=True.
    """
    return mcp_types.CallToolResult(
        content=[mcp_types.TextContent(type="text", text=message)],
        isError=True,
    )


def _extract_error(resp: httpx.Response) -> str:
    """Extract error detail from an API error response.

    Args:
        resp: HTTP error response.

    Returns:
        Human-readable error string.
    """
    try:
        data = resp.json()
        detail = data.get("detail", "")
        if isinstance(detail, dict):
            return str(detail.get("message", detail))
        return str(detail) or resp.text
    except Exception:
        return resp.text


# ==================== Entry Point ====================


async def run_stdio_server(profile: str, log_file: str | None = None) -> None:
    """Run the MCP server over stdio transport.

    Args:
        profile: CLI profile for authentication.
        log_file: Optional path to write diagnostic logs.
    """
    # Configure logging to stderr or file (never stdout — reserved for MCP)
    if log_file:
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format="%(asctime)s %(name)s %(levelname)s %(message)s",
        )
    else:
        logging.basicConfig(
            stream=sys.stderr,
            level=logging.WARNING,
            format="%(name)s: %(message)s",
        )

    server = _create_server(profile)

    init_options = InitializationOptions(
        server_name="opencosmo-local",
        server_version=__version__,
        capabilities=server.get_capabilities(
            notification_options=NotificationOptions(),
            experimental_capabilities={},
        ),
    )

    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, init_options)
