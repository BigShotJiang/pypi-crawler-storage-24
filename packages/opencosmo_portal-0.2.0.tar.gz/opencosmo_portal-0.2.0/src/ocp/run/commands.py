"""Run management commands for the OpenCosmo CLI."""

import time

import click

from ocp.api import RunService
from ocp.utils.api import APIClient
from ocp.utils.output import (
    format_datetime,
    format_relative_time,
    output,
    styled_status,
)


@click.group()
def run() -> None:
    """Manage task runs."""
    pass


@run.command("list")
@click.option(
    "--status",
    "-s",
    "filter_status",
    type=click.Choice(["pending", "running", "succeeded", "failed", "cancelled"]),
    help="Filter by status",
)
@click.option(
    "--include-archived",
    is_flag=True,
    help="Include archived runs",
)
@click.option(
    "--limit",
    "-n",
    default=20,
    type=click.IntRange(1, 100),
    help="Maximum number of runs to show (default: 20)",
)
@click.pass_context
def list_runs(
    ctx: click.Context,
    filter_status: str | None,
    include_archived: bool,
    limit: int,
) -> None:
    """List your task runs.

    Shows recent runs with their status and creation time.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = RunService(client)
        result = service.list_runs(
            limit=limit,
            status=filter_status,
            include_archived=include_archived,
        )

        if ctx.obj.get("format") == "json":
            output(ctx, [r.model_dump(mode="json") for r in result.runs])
        else:
            if not result.runs:
                click.echo("No runs found.")
                return

            # Format for display
            rows = []
            for r in result.runs:
                rows.append(
                    {
                        "run_id": r.run_id,
                        "status": r.status,
                        "status_display": styled_status(r.status),
                        "task_slug": r.task_slug,
                        "created": format_relative_time(r.created_at),
                    }
                )

            # Print table manually to support colored status
            click.echo(f"{'RUN ID':<38} {'STATUS':<12} {'TASK':<20} {'CREATED':<15}")
            for row in rows:
                # Extra width for status_display to account for ANSI color codes
                click.echo(
                    f"{row['run_id']:<38} {row['status_display']:<21} "
                    f"{row['task_slug']:<20} {row['created']:<15}"
                )

            click.echo()
            click.echo(f"Total: {result.total} runs")


@run.command()
@click.argument("run_id")
@click.option(
    "--watch",
    "-w",
    is_flag=True,
    help="Watch for status changes until completion",
)
@click.option(
    "--interval",
    default=5,
    type=int,
    help="Polling interval in seconds for --watch (default: 5)",
)
@click.pass_context
def status(ctx: click.Context, run_id: str, watch: bool, interval: int) -> None:
    """Get run status and progress.

    RUN_ID is the run identifier returned from task submission.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = RunService(client)

        while True:
            run_data = service.get_run(run_id)

            if ctx.obj.get("format") == "json":
                output(ctx, run_data.model_dump(mode="json"))
                if not watch or run_data.status in ("succeeded", "failed", "cancelled"):
                    break
            else:
                # Clear screen if watching
                if watch:
                    click.clear()

                click.echo(f"Run: {run_data.run_id}")
                click.echo(f"Task: {run_data.task_name} ({run_data.task_slug})")
                click.echo(f"Status: {styled_status(run_data.status)}")

                if run_data.current_stage:
                    click.echo(f"Current stage: {run_data.current_stage}")

                click.echo(f"Created: {format_relative_time(run_data.created_at)}")

                if run_data.completed_at:
                    click.echo(f"Completed: {format_relative_time(run_data.completed_at)}")

                if run_data.external_run_url:
                    click.echo(f"View run: {run_data.external_run_url}")

                # Show stages
                if run_data.stages:
                    click.echo()
                    click.echo("Stages:")
                    for stage in run_data.stages:
                        status_str = styled_status(stage.status.value)
                        click.echo(f"  {stage.name}: {status_str}")
                        if stage.message:
                            click.echo(f"    {stage.message}")

                # Check if done
                if run_data.status in ("succeeded", "failed", "cancelled"):
                    if not watch:
                        break

                    click.echo()
                    if run_data.status == "succeeded":
                        click.echo(click.style("Run completed successfully!", fg="green"))
                        click.echo(f"Get results with: ocp run results {run_id}")
                    elif run_data.status == "failed":
                        click.echo(click.style("Run failed.", fg="red"))
                        click.echo(f"Get logs with: ocp run logs {run_id}")
                    break

                if not watch:
                    break

            # Poll again
            if watch:
                time.sleep(interval)


@run.command()
@click.argument("run_id")
@click.pass_context
def logs(ctx: click.Context, run_id: str) -> None:
    """Get run execution logs.

    RUN_ID is the run identifier.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = RunService(client)
        logs_list = service.get_logs(run_id)

        if ctx.obj.get("format") == "json":
            output(ctx, logs_list)
        else:
            if not logs_list:
                click.echo("No logs available.")
                return

            for log_entry in logs_list:
                timestamp = log_entry.get("time", "")
                code = log_entry.get("code", "")
                description = log_entry.get("description", "")
                click.echo(f"[{timestamp}] {code}: {description}")


@run.command()
@click.argument("run_id")
@click.pass_context
def results(ctx: click.Context, run_id: str) -> None:
    """Get run results.

    RUN_ID is the run identifier. Only available for completed runs.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = RunService(client)
        data = service.get_results(run_id)

        if data is None:
            click.echo("Results not available yet. Run may still be in progress.")
            return

        if ctx.obj.get("format") == "json":
            output(ctx, data.model_dump(mode="json"))
        else:
            if not data.files:
                click.echo("No result files available.")
                return

            if data.message:
                click.echo(f"Message: {data.message}")
                click.echo()

            click.echo("Result files:")
            for f in data.files:
                size_str = _format_size(f.size_bytes)
                name = f.name or (f.local_path or "unknown")
                click.echo(f"  {name} ({size_str})")
                if f.url:
                    click.echo(f"    URL: {f.url}")

            click.echo()
            click.echo(f"Total size: {_format_size(data.total_bytes)}")

            if data.expires_at:
                click.echo(f"Expires: {format_datetime(data.expires_at)}")


@run.command()
@click.argument("run_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
@click.pass_context
def cancel(ctx: click.Context, run_id: str, yes: bool) -> None:
    """Cancel a running task.

    RUN_ID is the run identifier.
    """
    if not yes:
        if not click.confirm(f"Cancel run {run_id}?"):
            click.echo("Cancelled.")
            return

    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = RunService(client)
        result = service.cancel(run_id)

        if ctx.obj.get("format") == "json":
            output(ctx, result.model_dump(mode="json"))
        else:
            click.echo(click.style("Run cancelled.", fg="yellow"))


@run.command()
@click.argument("run_id")
@click.pass_context
def archive(ctx: click.Context, run_id: str) -> None:
    """Archive a completed run.

    RUN_ID is the run identifier. Archived runs are hidden from the default list.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = RunService(client)
        result = service.archive(run_id)

        if ctx.obj.get("format") == "json":
            output(ctx, result.model_dump(mode="json"))
        else:
            click.echo("Run archived.")


def _format_size(size_bytes: int) -> str:
    """Format byte size as human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"
