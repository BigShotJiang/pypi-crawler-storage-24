"""Admin management commands for the OpenCosmo CLI."""
