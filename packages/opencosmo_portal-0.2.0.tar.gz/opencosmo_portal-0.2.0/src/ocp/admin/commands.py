"""Admin commands for the OpenCosmo CLI."""

import click

from ocp.api import AdminService
from ocp.utils.api import APIClient
from ocp.utils.output import (
    format_datetime,
    format_relative_time,
    format_table,
    output,
    styled_status,
)


@click.group()
def admin() -> None:
    """Administrative commands (requires elevated permissions)."""
    pass


# ==================== Runs ====================


@click.group("runs")
def admin_runs() -> None:
    """Monitor runs across all users."""
    pass


admin.add_command(admin_runs)


@admin_runs.command("list")
@click.option("--user-id", help="Filter by user ID")
@click.option(
    "--status",
    "-s",
    "filter_status",
    type=click.Choice(["pending", "running", "succeeded", "failed", "cancelled"]),
    help="Filter by status",
)
@click.option("--task-slug", help="Filter by task slug")
@click.option(
    "--client-type",
    type=click.Choice(["web", "mcp", "python"]),
    help="Filter by client type",
)
@click.option("--include-archived", is_flag=True, help="Include archived runs")
@click.option(
    "--limit",
    "-n",
    default=50,
    type=click.IntRange(1, 100),
    help="Maximum number of runs (default: 50)",
)
@click.option("--offset", default=0, type=click.IntRange(min=0), help="Offset for pagination")
@click.pass_context
def list_runs(
    ctx: click.Context,
    user_id: str | None,
    filter_status: str | None,
    task_slug: str | None,
    client_type: str | None,
    include_archived: bool,
    limit: int,
    offset: int,
) -> None:
    """List all runs across all users."""
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = AdminService(client)
        result = service.list_runs(
            user_id=user_id,
            status=filter_status,
            task_slug=task_slug,
            client_type=client_type,
            include_archived=include_archived,
            limit=limit,
            offset=offset,
        )

        if ctx.obj.get("format") == "json":
            output(ctx, [r.model_dump(mode="json") for r in result.runs])
        else:
            if not result.runs:
                click.echo("No runs found.")
                return

            rows = []
            for r in result.runs:
                rows.append(
                    {
                        "run_id": r.run_id,
                        "status": r.status,
                        "status_display": styled_status(r.status),
                        "task": r.task_slug,
                        "user": r.user_email or r.user_id[:8],
                        "client": r.client_type,
                        "created": format_relative_time(r.created_at),
                    }
                )

            # Manual table to support colored status
            click.echo(
                f"{'RUN ID':<38} {'STATUS':<21} {'TASK':<20} "
                f"{'USER':<25} {'CLIENT':<8} {'CREATED':<15}"
            )
            for row in rows:
                click.echo(
                    f"{row['run_id']:<38} {row['status_display']:<21} "
                    f"{row['task']:<20} {row['user']:<25} "
                    f"{row['client']:<8} {row['created']:<15}"
                )

            click.echo()
            click.echo(f"Total: {result.total} runs")


@admin_runs.command("stats")
@click.pass_context
def run_stats(ctx: click.Context) -> None:
    """Show aggregated run statistics."""
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = AdminService(client)
        stats = service.get_run_stats()

        if ctx.obj.get("format") == "json":
            output(ctx, stats.model_dump(mode="json"))
        else:
            click.echo(click.style("=== Run Statistics ===", bold=True))
            click.echo(f"Total runs:  {stats.total_runs}")
            click.echo(f"Active runs: {stats.active_runs}")

            if stats.by_status:
                click.echo()
                click.echo(click.style("By status:", bold=True))
                for s in stats.by_status:
                    click.echo(f"  {styled_status(s.status):<21} {s.count}")

            if stats.by_task:
                click.echo()
                click.echo(click.style("By task:", bold=True))
                for t in stats.by_task:
                    click.echo(f"  {t.task_slug:<30} {t.count}")

            if stats.by_client_type:
                click.echo()
                click.echo(click.style("By client type:", bold=True))
                for c in stats.by_client_type:
                    click.echo(f"  {c.client_type:<15} {c.count}")

            if stats.avg_duration_by_task:
                click.echo()
                click.echo(click.style("Avg duration by task (last 30 days):", bold=True))
                for d in stats.avg_duration_by_task:
                    click.echo(f"  {d.task_slug:<30} {d.avg_seconds:.1f}s")


# ==================== Users ====================


@click.group("users")
def admin_users() -> None:
    """Manage users."""
    pass


admin.add_command(admin_users)


@admin_users.command("list")
@click.option("--search", help="Search by email or name")
@click.option(
    "--limit",
    "-n",
    default=50,
    type=click.IntRange(1, 100),
    help="Maximum number of users (default: 50)",
)
@click.option("--offset", default=0, type=click.IntRange(min=0), help="Offset for pagination")
@click.pass_context
def list_users(
    ctx: click.Context,
    search: str | None,
    limit: int,
    offset: int,
) -> None:
    """List all users."""
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = AdminService(client)
        result = service.list_users(search=search, limit=limit, offset=offset)

        if ctx.obj.get("format") == "json":
            output(ctx, [u.model_dump(mode="json") for u in result.users])
        else:
            if not result.users:
                click.echo("No users found.")
                return

            rows = []
            for u in result.users:
                rows.append(
                    {
                        "id": u.id[:8] + "...",
                        "name": u.name or "-",
                        "email": u.email or "-",
                        "runs": str(u.run_count),
                        "identities": str(u.identity_count),
                        "last_login": format_relative_time(u.last_login_at),
                    }
                )

            columns = [
                ("id", "ID"),
                ("name", "NAME"),
                ("email", "EMAIL"),
                ("runs", "RUNS"),
                ("identities", "IDENTITIES"),
                ("last_login", "LAST LOGIN"),
            ]
            click.echo(format_table(rows, columns))
            click.echo()
            click.echo(f"Total: {result.total} users")


@admin_users.command("info")
@click.argument("user_id")
@click.pass_context
def user_info(ctx: click.Context, user_id: str) -> None:
    """Show detailed user information.

    USER_ID is the user's unique identifier.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = AdminService(client)
        user = service.get_user(user_id)

        if ctx.obj.get("format") == "json":
            output(ctx, user.model_dump(mode="json"))
        else:
            click.echo(click.style("=== User Detail ===", bold=True))
            click.echo(f"ID:         {user.id}")
            click.echo(f"Name:       {user.name or '-'}")
            click.echo(f"Email:      {user.email or '-'}")
            click.echo(f"Created:    {format_datetime(user.created_at)}")
            click.echo(f"Last login: {format_relative_time(user.last_login_at)}")
            click.echo(f"Runs:       {user.run_count}")

            if user.identities:
                click.echo()
                click.echo(click.style("Identities:", bold=True))
                for ident in user.identities:
                    click.echo(f"  {ident.provider}: {ident.email or ident.id}")
                    if ident.last_used_at:
                        click.echo(f"    Last used: {format_relative_time(ident.last_used_at)}")

            if user.recent_runs:
                click.echo()
                click.echo(click.style("Recent runs:", bold=True))
                for r in user.recent_runs:
                    click.echo(
                        f"  {r.run_id}  {styled_status(r.status):<21} "
                        f"{r.task_slug:<20} {format_relative_time(r.created_at)}"
                    )


# ==================== Tasks ====================


@click.group("tasks")
def admin_tasks() -> None:
    """Manage tasks."""
    pass


admin.add_command(admin_tasks)


@admin_tasks.command("list")
@click.option(
    "--include-disabled/--enabled-only",
    default=True,
    help="Include disabled tasks (default: include)",
)
@click.option(
    "--limit",
    "-n",
    default=50,
    type=click.IntRange(1, 100),
    help="Maximum number of tasks (default: 50)",
)
@click.option("--offset", default=0, type=click.IntRange(min=0), help="Offset for pagination")
@click.pass_context
def list_tasks(
    ctx: click.Context,
    include_disabled: bool,
    limit: int,
    offset: int,
) -> None:
    """List all tasks including disabled ones."""
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = AdminService(client)
        result = service.list_tasks(
            include_disabled=include_disabled,
            limit=limit,
            offset=offset,
        )

        if ctx.obj.get("format") == "json":
            output(ctx, [t.model_dump(mode="json") for t in result.tasks])
        else:
            if not result.tasks:
                click.echo("No tasks found.")
                return

            rows = []
            for t in result.tasks:
                enabled = (
                    click.style("disabled", fg="red")
                    if t.disabled_at
                    else click.style("enabled", fg="green")
                )
                rows.append(
                    {
                        "slug": t.slug,
                        "name": t.name,
                        "category": t.category,
                        "executor": t.executor_type,
                        "runs": str(t.run_count),
                        "status": enabled,
                    }
                )

            # Manual table for colored status
            click.echo(
                f"{'SLUG':<25} {'NAME':<25} {'CATEGORY':<15} "
                f"{'EXECUTOR':<18} {'RUNS':<6} {'STATUS':<10}"
            )
            for row in rows:
                click.echo(
                    f"{row['slug']:<25} {row['name']:<25} {row['category']:<15} "
                    f"{row['executor']:<18} {row['runs']:<6} {row['status']}"
                )

            click.echo()
            click.echo(f"Total: {result.total} tasks")


@admin_tasks.command("enable")
@click.argument("slug")
@click.pass_context
def enable_task(ctx: click.Context, slug: str) -> None:
    """Enable a disabled task.

    SLUG is the task identifier.
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = AdminService(client)
        result = service.toggle_task(slug, disabled=False)

        if ctx.obj.get("format") == "json":
            output(ctx, result.model_dump(mode="json"))
        else:
            click.echo(click.style(f"Task '{result.slug}' enabled.", fg="green"))


@admin_tasks.command("disable")
@click.argument("slug")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
@click.pass_context
def disable_task(ctx: click.Context, slug: str, yes: bool) -> None:
    """Disable a task.

    SLUG is the task identifier. Disabled tasks cannot accept new runs.
    """
    if not yes:
        if not click.confirm(f"Disable task '{slug}'?"):
            click.echo("Cancelled.")
            return

    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = AdminService(client)
        result = service.toggle_task(slug, disabled=True)

        if ctx.obj.get("format") == "json":
            output(ctx, result.model_dump(mode="json"))
        else:
            click.echo(click.style(f"Task '{result.slug}' disabled.", fg="yellow"))


# ==================== Audit Logs ====================


@click.group("audit-logs")
def admin_audit_logs() -> None:
    """Query audit logs."""
    pass


admin.add_command(admin_audit_logs)


@admin_audit_logs.command("list")
@click.option("--user-id", help="Filter by user ID")
@click.option(
    "--method",
    type=click.Choice(["GET", "POST", "PATCH", "DELETE", "PUT"]),
    help="Filter by HTTP method",
)
@click.option("--path-prefix", help="Filter by path prefix (e.g., /api/v1/tasks)")
@click.option("--status-code", type=int, help="Filter by HTTP status code")
@click.option(
    "--limit",
    "-n",
    default=50,
    type=click.IntRange(1, 100),
    help="Maximum number of entries (default: 50)",
)
@click.option("--offset", default=0, type=click.IntRange(min=0), help="Offset for pagination")
@click.pass_context
def list_audit_logs(
    ctx: click.Context,
    user_id: str | None,
    method: str | None,
    path_prefix: str | None,
    status_code: int | None,
    limit: int,
    offset: int,
) -> None:
    """List audit log entries."""
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = AdminService(client)
        result = service.list_audit_logs(
            user_id=user_id,
            method=method,
            path_prefix=path_prefix,
            status_code=status_code,
            limit=limit,
            offset=offset,
        )

        if ctx.obj.get("format") == "json":
            output(ctx, [e.model_dump(mode="json") for e in result.entries])
        else:
            if not result.entries:
                click.echo("No audit log entries found.")
                return

            rows = []
            for e in result.entries:
                rows.append(
                    {
                        "time": format_relative_time(e.created_at),
                        "user": e.user_email or e.user_id or "-",
                        "method": e.method,
                        "path": e.path,
                        "status": str(e.status_code or "-"),
                    }
                )

            columns = [
                ("time", "TIME"),
                ("user", "USER"),
                ("method", "METHOD"),
                ("path", "PATH"),
                ("status", "STATUS"),
            ]
            click.echo(format_table(rows, columns))
            click.echo()
            click.echo(f"Total: {result.total} entries")


# ==================== System Stats ====================


@admin.command("stats")
@click.option(
    "--days",
    default=30,
    type=click.IntRange(1, 365),
    help="Days of history (default: 30)",
)
@click.pass_context
def system_stats(ctx: click.Context, days: int) -> None:
    """Show system-wide statistics."""
    with APIClient(profile=ctx.obj.get("profile")) as client:
        service = AdminService(client)
        stats = service.get_system_stats(days=days)

        if ctx.obj.get("format") == "json":
            output(ctx, stats.model_dump(mode="json"))
        else:
            click.echo(click.style("=== System Stats ===", bold=True))
            click.echo(f"Total users:     {stats.total_users}")
            click.echo(f"Active (24h):    {stats.active_users_24h}")
            click.echo(f"Active (7d):     {stats.active_users_7d}")
            click.echo(
                f"Tasks:           {stats.enabled_tasks} enabled, {stats.disabled_tasks} disabled"
            )

            rs = stats.run_summary
            click.echo()
            click.echo(click.style("=== Run Summary ===", bold=True))
            click.echo(f"Total runs:  {rs.total_runs}")
            click.echo(f"Active runs: {rs.active_runs}")

            if rs.by_status:
                click.echo()
                click.echo(click.style("By status:", bold=True))
                for s in rs.by_status:
                    click.echo(f"  {styled_status(s.status):<21} {s.count}")

            if rs.by_task:
                click.echo()
                click.echo(click.style("By task:", bold=True))
                for t in rs.by_task:
                    click.echo(f"  {t.task_slug:<30} {t.count}")

            if stats.daily_runs:
                click.echo()
                click.echo(click.style(f"Daily runs (last {days} days):", bold=True))
                for d in stats.daily_runs[-10:]:
                    bar = "#" * min(d.count, 50)
                    click.echo(f"  {d.date}  {bar} {d.count}")
                if len(stats.daily_runs) > 10:
                    click.echo(f"  ... ({len(stats.daily_runs) - 10} more days)")
