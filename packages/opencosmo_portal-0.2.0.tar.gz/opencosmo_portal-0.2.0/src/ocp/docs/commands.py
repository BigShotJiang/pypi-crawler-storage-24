"""Documentation commands for the OpenCosmo CLI."""

import click

from ocp.utils.api import APIClient, check_response
from ocp.utils.output import output


@click.group()
def docs() -> None:
    """Browse documentation."""
    pass


@docs.command("list")
@click.pass_context
def list_docs(ctx: click.Context) -> None:
    """List available documentation pages."""
    with APIClient(profile=ctx.obj.get("profile")) as client:
        response = client.get("/api/v1/content/documentation")
        check_response(response, "Documentation")

        data = response.json()

        if ctx.obj.get("format") == "json":
            output(ctx, data)
        else:
            if not data:
                click.echo("No documentation available.")
                return

            # Flatten nested TOC for table display
            rows: list[dict[str, str]] = []
            for category in data:
                label = category["label"]
                if category.get("url"):
                    rows.append({"category": label, "title": label, "url": category["url"]})
                for child in category.get("children", []):
                    rows.append({"category": label, "title": child["title"], "url": child["url"]})

            columns = [
                ("category", "CATEGORY"),
                ("title", "TITLE"),
                ("url", "URL"),
            ]
            output(ctx, rows, columns)


@docs.command("show")
@click.argument("slug")
@click.pass_context
def show_doc(ctx: click.Context, slug: str) -> None:
    """Show a documentation page.

    Args:
        slug: Documentation page slug (e.g. 'user-guide/submitting-tasks').
    """
    with APIClient(profile=ctx.obj.get("profile")) as client:
        response = client.get(f"/api/v1/content/documentation/{slug}")
        check_response(response, "Documentation page")

        data = response.json()

        if ctx.obj.get("format") == "json":
            output(ctx, data)
        else:
            click.echo(click.style(data["title"], bold=True))
            click.echo()
            click.echo(data["content"])
